from __future__ import annotations

import contextlib
import shutil
import sys
from collections.abc import Callable, Coroutine
from dataclasses import dataclass
from functools import partial
from typing import Any, cast

from prompt_toolkit.application import Application
from prompt_toolkit.application.current import get_app
from prompt_toolkit.buffer import Buffer
from prompt_toolkit.document import Document
from prompt_toolkit.filters import Always, Condition
from prompt_toolkit.key_binding import KeyBindings, KeyPressEvent, merge_key_bindings
from prompt_toolkit.key_binding.defaults import load_key_bindings
from prompt_toolkit.keys import Keys
from prompt_toolkit.layout import ConditionalContainer, Float, FloatContainer, HSplit, Layout, VSplit, Window
from prompt_toolkit.layout.containers import Container, ScrollOffsets
from prompt_toolkit.layout.controls import BufferControl, FormattedTextControl
from prompt_toolkit.layout.dimension import Dimension
from prompt_toolkit.output.color_depth import ColorDepth
from prompt_toolkit.styles import Style, merge_styles
from prompt_toolkit.styles.base import BaseStyle

from klaude_code.config.formatters import format_model_params
from klaude_code.tui.input.pt_theme import get_default_picker_style


def _default_picker_style_factory() -> Style:
    """Backwards-compatible alias kept for call sites.

    Historically this module exported a module-level ``DEFAULT_PICKER_STYLE``
    constant. Because the theme is resolved at runtime, we expose it as a
    callable returning the current theme's Style, and keep a convenience
    module-level alias that callers can still import.
    """

    return get_default_picker_style()


# Rows reserved above the list for picker chrome (top spacer, header, search
# input) plus a small buffer for caller-printed content (errors, hints). Keeps
# the picker from consuming the full terminal height.
_LIST_RESERVED_ROWS = 10
_LIST_MIN_ROWS = 8


def _list_max_height() -> Dimension:
    """Compute the list window's max height based on current terminal size."""

    rows = shutil.get_terminal_size((80, 24)).lines
    return Dimension(max=max(_LIST_MIN_ROWS, rows - _LIST_RESERVED_ROWS))


# NOTE: intentionally a *function* object, not a Style instance. Call sites
# that currently pass it as ``style=DEFAULT_PICKER_STYLE`` must instead call
# it (``style=DEFAULT_PICKER_STYLE()``). A callable makes the theme-binding
# explicit: the palette is resolved on each call rather than frozen at
# module import time.
DEFAULT_PICKER_STYLE = _default_picker_style_factory


@dataclass(frozen=True, slots=True)
class SelectItem[T]:
    """One selectable item for terminal selection UI."""

    title: list[tuple[str, str]]
    value: T | None
    search_text: str
    summary: str | None = None
    selectable: bool = True
    markdown: str | None = None


@dataclass(frozen=True, slots=True)
class QuestionSelectResult[T]:
    selected_values: list[T]
    input_text: str


@dataclass(frozen=True, slots=True)
class QuestionPrompt[T]:
    header: str
    message: str
    items: list[SelectItem[T]]
    multi_select: bool
    input_placeholder: str = "Type something."
    other_value: T | None = None


# ---------------------------------------------------------------------------
# Model selection items builder
# ---------------------------------------------------------------------------


def build_model_select_items(
    models: list[Any],
    *,
    highlighted_selectors: set[str] | None = None,
) -> list[SelectItem[str]]:
    """Build SelectItem list from ModelEntry objects.

    Args:
        models: List of ModelEntry objects (from config.iter_model_entries).
        highlighted_selectors: Selectors to visually emphasize (e.g. recommended
            alternatives when the configured main_model is unavailable). Matching
            rows get a yellow background plus a star badge but remain in place
            so users still see the full list.

    Returns:
        List of SelectItem[str] with model selector as the value.
    """
    if not models:
        return []

    highlighted = highlighted_selectors or set()
    max_model_name_length = max(len(m.model_name) for m in models)
    num_width = len(str(len(models)))

    # Group models by provider in stable insertion order.
    provider_grouped: dict[str, list[Any]] = {}
    for m in models:
        provider = str(getattr(m, "provider", ""))
        provider_grouped.setdefault(provider, []).append(m)

    all_groups: list[tuple[str, list[Any]]] = list(provider_grouped.items())

    # Calculate max header width for alignment across all groups.
    max_header_len = max(len(f"{name.upper()} ({len(ms)})") for name, ms in all_groups)

    items: list[SelectItem[str]] = []
    model_idx = 0
    separator_base_len = 80
    for group_name, group_models in all_groups:
        group_text = group_name.lower()
        count_text = f"({len(group_models)})"
        header_len = len(group_text) + 1 + len(count_text)
        separator_len = separator_base_len + max_header_len - header_len
        separator = "-" * separator_len
        items.append(
            SelectItem(
                title=[
                    ("class:meta class:accent.yellow", group_text + " "),
                    ("class:meta", count_text + " "),
                    # Dashes use the faintest grey3 (``class:lines``) so the
                    # provider header reads as: bright group name, dim count,
                    # faintest divider -- matching rich's ``ThemeKey.LINES``.
                    ("class:lines", separator),
                    ("class:meta", "\n"),
                ],
                value=None,
                search_text=group_name,
                selectable=False,
            )
        )

        for m in group_models:
            model_idx += 1
            model_id_str = m.model_id or "N/A"
            display_name = m.model_name
            first_line_prefix = f"{display_name:<{max_model_name_length}}"
            meta_parts = format_model_params(m)
            meta_str = " · ".join(meta_parts) if meta_parts else ""
            title: list[tuple[str, str]] = [
                ("class:meta", f"{model_idx:>{num_width}}. "),
                ("class:msg", first_line_prefix),
                ("class:msg", " → "),
                ("class:msg class:accent.blue", model_id_str),
            ]

            if meta_str:
                title.append(("class:msg", " · "))
                title.append(("class:meta", meta_str))

            title.append(("class:meta", "\n"))

            if m.selector in highlighted:
                # Prefix a star badge and tag every fragment with
                # ``class:picker.suggested`` so prompt_toolkit paints a yellow
                # background across the whole row. The badge class is styled
                # independently (bold yellow fg) so it stands out even when the
                # row becomes the pointer target.
                title = [("class:picker.suggested class:picker.suggested.badge", "★ ")] + [
                    (f"{style} class:picker.suggested", text) for style, text in title
                ]
            elif highlighted:
                # When other rows carry a star badge, pad non-highlighted rows
                # with the same-width gutter so numbering stays vertically
                # aligned.
                title = [("class:meta", "  "), *title]

            provider = str(getattr(m, "provider", ""))
            search_text = f"{m.selector} {m.model_name} {model_id_str} {provider}"
            items.append(SelectItem(title=title, value=m.selector, search_text=search_text))

    return items


# ---------------------------------------------------------------------------
# Shared helpers for select_one() and SelectOverlay
# ---------------------------------------------------------------------------


def _restyle_title(title: list[tuple[str, str]], cls: str) -> list[tuple[str, str]]:
    """Re-apply a style class while keeping existing style tokens.

    This is used to highlight the currently-pointed item. We want to:
    - preserve explicit colors (e.g. ``class:meta``) defined by callers
    - preserve existing classes (e.g. `class:msg`, `class:meta`) so their
      non-color attributes remain in effect
    - preserve text attributes like bold/italic/dim
    """

    keep_attrs = {"bold", "italic", "underline", "reverse", "blink", "strike"}
    restyled: list[tuple[str, str]] = []
    for old_style, text in title:
        tokens = old_style.split()
        attrs = [tok for tok in tokens if tok in keep_attrs]
        style_tokens = [tok for tok in tokens if tok not in keep_attrs]

        if cls in style_tokens:
            style_tokens = [tok for tok in style_tokens if tok != cls]

        # Place the highlight class first, so existing per-token styles (classes
        # or explicit fg/bg) keep their precedence. This prevents highlight from
        # accidentally overriding caller-defined colors.
        combined = [cls, *style_tokens, *attrs]
        style = " ".join(tok for tok in combined if tok)
        restyled.append((style, text))
    return restyled


def _indent_multiline_tokens(
    tokens: list[tuple[str, str]],
    indent: str,
    *,
    indent_style: str = "class:text",
) -> list[tuple[str, str]]:
    """Indent continuation lines inside formatted tokens.

    This is needed when an item's title contains embedded newlines. The selector
    prefixes each *item* with the pointer padding, but continuation lines inside
    a single item would otherwise start at column 0.
    """
    if not tokens or all("\n" not in text for _style, text in tokens):
        return tokens

    def _has_non_newline_text(s: str) -> bool:
        return bool(s.replace("\n", ""))

    has_text_after_token: list[bool] = [False] * len(tokens)
    remaining = False
    for i in range(len(tokens) - 1, -1, -1):
        has_text_after_token[i] = remaining
        remaining = remaining or _has_non_newline_text(tokens[i][1])

    out: list[tuple[str, str]] = []
    for token_index, (style, text) in enumerate(tokens):
        if "\n" not in text:
            out.append((style, text))
            continue

        parts = text.split("\n")
        for part_index, part in enumerate(parts):
            if part:
                out.append((style, part))

            # If this was a newline, re-add it.
            if part_index < len(parts) - 1:
                out.append((style, "\n"))

                # Only indent when there is more text remaining within this item.
                has_text_later_in_token = any(p for p in parts[part_index + 1 :])
                if has_text_later_in_token or has_text_after_token[token_index]:
                    out.append((indent_style, indent))

    return out


def _normalize_search_key(value: str) -> str:
    """Normalize a search key for loose matching.

    This enables aliases like:
    - gpt52 -> gpt-5.2
    - gpt5.2 -> gpt-5.2

    Strategy: case-fold + keep only alphanumeric characters.
    """

    return "".join(ch for ch in value.casefold() if ch.isalnum())


def _matches_search_component(haystack: str, needle: str) -> bool:
    component = needle.casefold().strip()
    if not component:
        return False
    if component in haystack:
        return True

    component_norm = _normalize_search_key(component)
    if not component_norm:
        return False
    return component_norm in _normalize_search_key(haystack)


def _extract_selector_parts(search_text: str) -> tuple[str, str] | None:
    selector = search_text.split(None, 1)[0].strip()
    if "@" not in selector:
        return None

    model_name, provider_name = selector.rsplit("@", 1)
    model_name = model_name.strip()
    provider_name = provider_name.strip()
    if not model_name or not provider_name:
        return None
    return model_name, provider_name


def _matches_generic_search(haystack: str, needle: str) -> bool:
    if needle in haystack:
        return True

    needle_norm = _normalize_search_key(needle)
    if not needle_norm:
        return False
    return needle_norm in _normalize_search_key(haystack)


def _matches_search_token(search_text: str, token: str) -> bool:
    haystack = search_text.casefold()
    normalized_token = token.casefold().strip()
    if not normalized_token:
        return False

    if "@" in normalized_token:
        left, right = normalized_token.rsplit("@", 1)
        if left.strip() and right.strip():
            selector_parts = _extract_selector_parts(search_text)
            if selector_parts is None:
                return False

            model_name, provider_name = selector_parts
            return _matches_search_component(model_name, left) and _matches_search_component(provider_name, right)

    return _matches_generic_search(haystack, normalized_token)


def _filter_items[T](
    items: list[SelectItem[T]],
    filter_text: str,
) -> tuple[list[int], bool]:
    """Return visible item indices and whether any matched the filter."""
    if not items:
        return [], True
    if not filter_text:
        return list(range(len(items))), True

    tokens = filter_text.split()
    if not tokens:
        return list(range(len(items))), True

    def _is_match(it: SelectItem[T]) -> bool:
        return all(_matches_search_token(it.search_text, token) for token in tokens)

    matched_selectable = [i for i, it in enumerate(items) if it.selectable and _is_match(it)]
    if not matched_selectable:
        return [], False

    matched_set = set(matched_selectable)
    visible: list[int] = []

    # If we have non-selectable header rows, keep a header visible only when its
    # group has at least one matched selectable item.
    i = 0
    while i < len(items):
        it = items[i]
        if not it.selectable:
            header_idx = i
            group_start = i + 1
            group_end = next((j for j in range(group_start, len(items)) if not items[j].selectable), len(items))
            group_matches = [j for j in range(group_start, group_end) if j in matched_set]
            if group_matches:
                visible.append(header_idx)
                visible.extend(group_matches)
            i = group_end
            continue

        if i in matched_set:
            visible.append(i)
        i += 1

    return visible, True


def _coerce_pointed_at_to_selectable[T](
    items: list[SelectItem[T]],
    visible_indices: list[int],
    pointed_at: int,
) -> int:
    """Return a valid pointed_at position for selectable items.

    pointed_at is an index into visible_indices (not into items).
    """

    if not visible_indices:
        return 0

    start = pointed_at % len(visible_indices)
    for offset in range(len(visible_indices)):
        pos = (start + offset) % len(visible_indices)
        idx = visible_indices[pos]
        if items[idx].selectable:
            return pos
    return start


def _build_choices_tokens[T](
    items: list[SelectItem[T]],
    visible_indices: list[int],
    pointed_at: int,
    pointer: str,
    *,
    empty_message: str = "(no items)",
    highlight_pointed_item: bool = True,
) -> list[tuple[str, str]]:
    """Build formatted tokens for the choice list."""
    if not visible_indices:
        return [("class:text", empty_message + "\n")]

    tokens: list[tuple[str, str]] = []
    pointer_pad = " " * (2 + len(pointer))
    pointed_prefix = f" {pointer} "

    for pos, idx in enumerate(visible_indices):
        is_pointed = pos == pointed_at
        if is_pointed:
            tokens.append(("class:pointer", pointed_prefix))
            tokens.append(("[SetCursorPosition]", ""))
        else:
            tokens.append(("class:text", pointer_pad))

        if is_pointed and highlight_pointed_item:
            title_tokens = _restyle_title(items[idx].title, "class:highlighted")
        else:
            title_tokens = items[idx].title

        title_tokens = _indent_multiline_tokens(title_tokens, pointer_pad)
        tokens.extend(title_tokens)

    return tokens


def _build_rounded_frame(body: Container, *, padding_x: int = 0, padding_y: int = 0) -> HSplit:
    """Build a rounded border frame around the given container."""
    border = partial(Window, style="class:frame.border", height=1)
    pad = partial(Window, style="class:frame", char=" ", always_hide_cursor=Always())

    inner: Container = body
    if padding_y > 0:
        inner = HSplit(
            [
                pad(height=padding_y, dont_extend_height=Always()),
                body,
                pad(height=padding_y, dont_extend_height=Always()),
            ],
            padding=0,
            style="class:frame",
        )

    middle_children: list[Container] = [border(width=1, char="│")]
    if padding_x > 0:
        middle_children.append(pad(width=padding_x))
    middle_children.append(inner)
    if padding_x > 0:
        middle_children.append(pad(width=padding_x))
    middle_children.append(border(width=1, char="│"))

    top = VSplit(
        [
            border(width=1, char="╭"),
            border(char="─"),
            border(width=1, char="╮"),
        ],
        height=1,
        padding=0,
    )
    middle = VSplit(middle_children, padding=0)
    bottom = VSplit(
        [
            border(width=1, char="╰"),
            border(char="─"),
            border(width=1, char="╯"),
        ],
        height=1,
        padding=0,
    )
    return HSplit([top, middle, bottom], padding=0, style="class:frame")


def _build_search_container(
    search_buffer: Buffer,
    search_placeholder: str,
    *,
    frame: bool = True,
) -> tuple[Window, Container]:
    """Build the search input container with placeholder."""
    placeholder_text = f"{search_placeholder} · ↑/↓ to select · enter/tab to confirm · esc to quit"

    search_prefix_window = Window(
        FormattedTextControl([("class:search_prefix", "/ ")]),
        width=2,
        height=1,
        dont_extend_height=Always(),
        always_hide_cursor=Always(),
    )
    input_window = Window(
        BufferControl(buffer=search_buffer),
        height=1,
        dont_extend_height=Always(),
        style="class:search_input",
    )
    placeholder_window = ConditionalContainer(
        content=Window(
            FormattedTextControl([("class:search_placeholder", placeholder_text)]),
            height=1,
            dont_extend_height=Always(),
            always_hide_cursor=Always(),
        ),
        filter=Condition(lambda: search_buffer.text == ""),
    )
    search_input_container = FloatContainer(
        content=input_window,
        floats=[Float(content=placeholder_window, top=0, left=0)],
    )
    search_row: Container = VSplit([search_prefix_window, search_input_container], padding=0)
    if frame:
        return input_window, _build_rounded_frame(search_row)
    return input_window, search_row


# ---------------------------------------------------------------------------
# select_one: standalone single-choice selector
# ---------------------------------------------------------------------------


def select_one[T](
    *,
    message: str,
    items: list[SelectItem[T]],
    pointer: str = "→",
    style: BaseStyle | None = None,
    use_search_filter: bool = True,
    initial_value: T | None = None,
    initial_search_text: str | None = None,
    search_placeholder: str = "type to search",
    highlight_pointed_item: bool = True,
) -> T | None:
    """Terminal single-choice selector based on prompt_toolkit."""
    if not items:
        return None

    # Non-interactive environments should not enter an interactive prompt.
    if not sys.stdin.isatty() or not sys.stdout.isatty():
        return None

    pointed_at = 0
    initial_search = initial_search_text or ""

    search_buffer: Buffer | None = (
        Buffer(document=Document(text=initial_search, cursor_position=len(initial_search)))
        if use_search_filter
        else None
    )

    def get_filter_text() -> str:
        return search_buffer.text if (use_search_filter and search_buffer is not None) else ""

    def get_header_tokens() -> list[tuple[str, str]]:
        return [("class:question", message + " ")]

    def get_choices_tokens() -> list[tuple[str, str]]:
        nonlocal pointed_at
        filter_text = get_filter_text()
        indices, matched = _filter_items(items, filter_text)
        if indices:
            pointed_at = _coerce_pointed_at_to_selectable(items, indices, pointed_at)
        return _build_choices_tokens(
            items,
            indices,
            pointed_at,
            pointer,
            empty_message="(no match)" if filter_text and not matched else "(no items)",
            highlight_pointed_item=highlight_pointed_item,
        )

    def move_pointed_at(delta: int) -> None:
        nonlocal pointed_at
        indices, _ = _filter_items(items, get_filter_text())
        if not indices:
            return

        pointed_at = _coerce_pointed_at_to_selectable(items, indices, pointed_at)
        for _ in range(len(indices)):
            pointed_at = (pointed_at + delta) % len(indices)
            idx = indices[pointed_at]
            if items[idx].selectable:
                return

    def on_search_changed(_buf: Buffer) -> None:
        nonlocal pointed_at
        pointed_at = 0
        with contextlib.suppress(Exception):
            get_app().invalidate()

    kb = KeyBindings()

    @kb.add(Keys.ControlC, eager=True)
    def _(event: KeyPressEvent) -> None:
        event.app.exit(result=None)

    @kb.add(Keys.ControlQ, eager=True)
    def _(event: KeyPressEvent) -> None:
        event.app.exit(result=None)

    @kb.add(Keys.Down, eager=True)
    def _(event: KeyPressEvent) -> None:
        move_pointed_at(+1)
        event.app.invalidate()

    @kb.add(Keys.Up, eager=True)
    def _(event: KeyPressEvent) -> None:
        move_pointed_at(-1)
        event.app.invalidate()

    @kb.add(Keys.Enter, eager=True)
    def _(event: KeyPressEvent) -> None:
        indices, _ = _filter_items(items, get_filter_text())
        if not indices:
            return

        nonlocal pointed_at
        pointed_at = _coerce_pointed_at_to_selectable(items, indices, pointed_at)
        idx = indices[pointed_at % len(indices)]
        value = items[idx].value
        if value is None:
            event.app.exit(result=None)
            return
        event.app.exit(result=value)

    @kb.add(Keys.Tab, eager=True)
    def _(event: KeyPressEvent) -> None:
        """Accept the currently pointed item."""
        indices, _ = _filter_items(items, get_filter_text())
        if not indices:
            return

        nonlocal pointed_at
        pointed_at = _coerce_pointed_at_to_selectable(items, indices, pointed_at)
        idx = indices[pointed_at % len(indices)]
        value = items[idx].value
        if value is None:
            event.app.exit(result=None)
            return
        event.app.exit(result=value)

    @kb.add(Keys.Escape, eager=True)
    def _(event: KeyPressEvent) -> None:
        nonlocal pointed_at
        if use_search_filter and search_buffer is not None and search_buffer.text:
            search_buffer.reset(append_to_history=False)
            pointed_at = 0
            event.app.invalidate()
            return
        event.app.exit(result=None)

    if use_search_filter and search_buffer is not None:
        search_buffer.on_text_changed += on_search_changed

    if initial_value is not None:
        try:
            full_index = next(i for i, it in enumerate(items) if it.value == initial_value)
            indices, _filtered = _filter_items(items, get_filter_text())
            pointed_at = indices.index(full_index) if full_index in indices else 0
        except StopIteration:
            pointed_at = 0

    header_window = Window(
        FormattedTextControl(get_header_tokens),
        height=1,
        dont_extend_height=Always(),
        always_hide_cursor=Always(),
    )
    top_spacer_window = Window(
        FormattedTextControl([("", "")]),
        height=1,
        dont_extend_height=Always(),
        always_hide_cursor=Always(),
    )
    list_window = Window(
        FormattedTextControl(get_choices_tokens),
        # Keep 1 line of context above the cursor so non-selectable header rows
        # (e.g. provider group labels) remain visible when wrapping back to the
        # first selectable item in a scrolled list.
        scroll_offsets=ScrollOffsets(top=1, bottom=2),
        allow_scroll_beyond_bottom=True,
        dont_extend_height=Always(),
        always_hide_cursor=Always(),
        # Cap the list height so the picker does not consume the whole terminal
        # and push earlier output (errors, hints) off-screen. Evaluated on each
        # render so terminal resizes take effect immediately. The reserved rows
        # cover the picker's own chrome (top spacer, header, optional search
        # input) plus a small buffer for whatever the caller printed above.
        height=_list_max_height,
    )

    search_container: Container | None = None
    search_input_window: Window | None = None
    if use_search_filter and search_buffer is not None:
        search_input_window, search_container = _build_search_container(
            search_buffer,
            search_placeholder,
            frame=False,
        )

    base_style = get_default_picker_style()
    merged_style = merge_styles([base_style, style] if style is not None else [base_style])

    root_children: list[Container] = [top_spacer_window, header_window]
    if search_container is not None:
        root_children.append(search_container)
    root_children.append(list_window)

    app: Application[T | None] = Application(
        layout=Layout(HSplit(root_children), focused_element=search_input_window or list_window),
        key_bindings=merge_key_bindings([load_key_bindings(), kb]),
        style=merged_style,
        mouse_support=False,
        full_screen=False,
        erase_when_done=True,
        # Force 24-bit color so hex styles render exactly as specified
        # instead of being snapped to the xterm-256 palette.
        color_depth=ColorDepth.TRUE_COLOR,
    )
    app.renderer.cpr_not_supported_callback = lambda: None
    return app.run()


def select_questions[T](
    *,
    questions: list[QuestionPrompt[T]],
    pointer: str = "→",
    style: BaseStyle | None = None,
) -> list[QuestionSelectResult[T]] | None:
    from klaude_code.tui.terminal.ask_user_question import select_questions as _select_questions

    return _select_questions(questions=questions, pointer=pointer, style=style)


def select_question[T](
    *,
    message: str,
    items: list[SelectItem[T]],
    multi_select: bool,
    pointer: str = "→",
    style: BaseStyle | None = None,
    input_placeholder: str = "Type something.",
    other_value: T | None = None,
) -> QuestionSelectResult[T] | None:
    from klaude_code.tui.terminal.ask_user_question import select_question as _select_question

    return _select_question(
        message=message,
        items=items,
        multi_select=multi_select,
        pointer=pointer,
        style=style,
        input_placeholder=input_placeholder,
        other_value=other_value,
    )


# ---------------------------------------------------------------------------
# SelectOverlay: embedded overlay for existing prompt_toolkit Application
# ---------------------------------------------------------------------------


class SelectOverlay[T]:
    """Embedded single-choice selector overlay for an existing prompt_toolkit Application.

    Unlike `select_one()`, this does not create or run a new Application.
    It is designed for use inside an already-running PromptSession.app.
    """

    def __init__(
        self,
        *,
        pointer: str = "→",
        use_search_filter: bool = True,
        search_placeholder: str = "type to search",
        list_height: int = 8,
        highlight_pointed_item: bool = True,
        on_select: Callable[[T], Coroutine[Any, Any, None] | None] | None = None,
        on_cancel: Callable[[], Coroutine[Any, Any, None] | None] | None = None,
    ) -> None:
        self._pointer = pointer
        self._use_search_filter = use_search_filter
        self._search_placeholder = search_placeholder
        self._list_height = max(1, list_height)
        self._highlight_pointed_item = highlight_pointed_item
        self._on_select = on_select
        self._on_cancel = on_cancel

        self._is_open = False
        self._message: str = ""
        self._items: list[SelectItem[T]] = []
        self._pointed_at = 0

        self._prev_focus: Window | None = None
        self._search_buffer: Buffer | None = Buffer() if use_search_filter else None

        self._list_window: Window | None = None
        self._search_input_window: Window | None = None

        self.key_bindings = self._build_key_bindings()
        self.container = self._build_layout()

        if self._use_search_filter and self._search_buffer is not None:
            self._search_buffer.on_text_changed += self._on_search_changed

    def _get_filter_text(self) -> str:
        if self._use_search_filter and self._search_buffer is not None:
            return self._search_buffer.text
        return ""

    def _get_visible_indices(self) -> tuple[list[int], bool]:
        return _filter_items(self._items, self._get_filter_text())

    def _on_search_changed(self, _buf: Buffer) -> None:
        self._pointed_at = 0
        with contextlib.suppress(Exception):
            get_app().invalidate()

    def _build_key_bindings(self) -> KeyBindings:
        kb = KeyBindings()
        is_open_filter = Condition(lambda: self._is_open)

        def move_pointed_at(delta: int) -> None:
            indices, _ = self._get_visible_indices()
            if not indices:
                return

            self._pointed_at = _coerce_pointed_at_to_selectable(self._items, indices, self._pointed_at)
            for _ in range(len(indices)):
                self._pointed_at = (self._pointed_at + delta) % len(indices)
                idx = indices[self._pointed_at]
                if self._items[idx].selectable:
                    return

        @kb.add(Keys.Down, filter=is_open_filter, eager=True)
        def _(event: KeyPressEvent) -> None:
            move_pointed_at(+1)
            event.app.invalidate()

        @kb.add(Keys.Up, filter=is_open_filter, eager=True)
        def _(event: KeyPressEvent) -> None:
            move_pointed_at(-1)
            event.app.invalidate()

        @kb.add(Keys.Enter, filter=is_open_filter, eager=True)
        def _(event: KeyPressEvent) -> None:
            indices, _ = self._get_visible_indices()
            if not indices:
                return

            self._pointed_at = _coerce_pointed_at_to_selectable(self._items, indices, self._pointed_at)
            idx = indices[self._pointed_at % len(indices)]
            value = self._items[idx].value
            if value is None:
                self.close()
                return
            self.close()

            if self._on_select is None:
                return

            result = self._on_select(value)
            if hasattr(result, "__await__"):
                event.app.create_background_task(result)

        @kb.add(Keys.Tab, filter=is_open_filter, eager=True)
        def _(event: KeyPressEvent) -> None:
            indices, _ = self._get_visible_indices()
            if not indices:
                return

            self._pointed_at = _coerce_pointed_at_to_selectable(self._items, indices, self._pointed_at)
            idx = indices[self._pointed_at % len(indices)]
            value = self._items[idx].value
            if value is None:
                self.close()
                return
            self.close()

            if self._on_select is None:
                return

            result = self._on_select(value)
            if hasattr(result, "__await__"):
                event.app.create_background_task(result)

        @kb.add(Keys.Escape, filter=is_open_filter, eager=True)
        def _(event: KeyPressEvent) -> None:
            if self._use_search_filter and self._search_buffer is not None and self._search_buffer.text:
                self._search_buffer.reset(append_to_history=False)
                self._pointed_at = 0
                event.app.invalidate()
                return
            self._close_and_invoke_cancel(event)

        @kb.add(Keys.ControlL, filter=is_open_filter, eager=True)
        def _(event: KeyPressEvent) -> None:
            self.close()
            event.app.invalidate()

        @kb.add(Keys.ControlC, filter=is_open_filter, eager=True)
        def _(event: KeyPressEvent) -> None:
            self._close_and_invoke_cancel(event)

        return kb

    def _close_and_invoke_cancel(self, event: KeyPressEvent) -> None:
        self.close()
        if self._on_cancel is not None:
            result = self._on_cancel()
            if hasattr(result, "__await__"):
                event.app.create_background_task(result)

    def _build_layout(self) -> ConditionalContainer:
        def get_header_tokens() -> list[tuple[str, str]]:
            return [("class:question", self._message + " ")]

        def get_choices_tokens() -> list[tuple[str, str]]:
            filter_text = self._get_filter_text()
            indices, matched = self._get_visible_indices()
            if indices:
                self._pointed_at = _coerce_pointed_at_to_selectable(self._items, indices, self._pointed_at)
            return _build_choices_tokens(
                self._items,
                indices,
                self._pointed_at,
                self._pointer,
                empty_message="(no match)" if filter_text and not matched else "(no items)",
                highlight_pointed_item=self._highlight_pointed_item,
            )

        header_window = Window(
            FormattedTextControl(get_header_tokens),
            height=1,
            dont_extend_height=Always(),
            always_hide_cursor=Always(),
        )

        def get_list_height() -> int:
            # Dynamic height: min of configured height and available terminal space
            # Overhead: header(1) + search(1) + frame borders(2) + prompt area(3)
            overhead = 7
            try:
                terminal_height = get_app().output.get_size().rows
                available = max(3, terminal_height - overhead)
                cap = min(self._list_height, available)
            except Exception:
                cap = self._list_height

            # Shrink list height when content is shorter than the configured cap.
            # This is especially helpful for small pickers (e.g. thinking level)
            # where a fixed list_height would otherwise render extra blank rows.
            indices, _ = self._get_visible_indices()
            if not indices:
                return 1

            visible_lines = 0
            for idx in indices:
                item = self._items[idx]
                newlines = sum(text.count("\n") for _style, text in item.title)
                visible_lines += max(1, newlines)
                if visible_lines >= cap:
                    break

            return max(1, min(cap, visible_lines))

        list_window = Window(
            FormattedTextControl(get_choices_tokens),
            height=get_list_height,
            # See select_one(): keep header rows visible when wrapping.
            # For embedded overlays, avoid reserving extra blank lines near the
            # bottom when the list height is tight (e.g. short pickers).
            scroll_offsets=ScrollOffsets(top=1, bottom=0),
            allow_scroll_beyond_bottom=False,
            dont_extend_height=Always(),
            always_hide_cursor=Always(),
        )
        self._list_window = list_window

        search_container: Container | None = None
        if self._use_search_filter and self._search_buffer is not None:
            self._search_input_window, search_container = _build_search_container(
                self._search_buffer,
                self._search_placeholder,
                frame=False,
            )

        root_children: list[Container] = [header_window]
        if search_container is not None:
            root_children.append(search_container)
        root_children.append(list_window)

        framed_content = _build_rounded_frame(HSplit(root_children, padding=0), padding_x=1)
        return ConditionalContainer(content=framed_content, filter=Condition(lambda: self._is_open))

    @property
    def is_open(self) -> bool:
        return self._is_open

    def set_content(self, *, message: str, items: list[SelectItem[T]], initial_value: T | None = None) -> None:
        self._message = message
        self._items = items

        self._pointed_at = 0
        if initial_value is not None:
            try:
                full_index = next(i for i, it in enumerate(items) if it.value == initial_value)
                self._pointed_at = full_index
            except StopIteration:
                self._pointed_at = 0

        if self._use_search_filter and self._search_buffer is not None:
            self._search_buffer.reset(append_to_history=False)

    def open(self) -> None:
        if self._is_open:
            return
        self._is_open = True
        app = get_app()
        self._prev_focus = cast(Window | None, getattr(app.layout, "current_window", None))
        with contextlib.suppress(Exception):
            if self._search_input_window is not None:
                app.layout.focus(self._search_input_window)
            elif self._list_window is not None:
                app.layout.focus(self._list_window)
        app.invalidate()

    def close(self) -> None:
        if not self._is_open:
            return
        self._is_open = False
        app = get_app()
        prev = self._prev_focus
        self._prev_focus = None
        if prev is not None:
            with contextlib.suppress(Exception):
                app.layout.focus(prev)
        app.invalidate()
