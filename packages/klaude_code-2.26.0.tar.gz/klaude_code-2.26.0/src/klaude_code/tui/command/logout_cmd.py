import asyncio

import typer

from klaude_code.app.auth_flow import execute_logout
from klaude_code.protocol import events, message

from .auth_selector import select_provider
from .command_abc import Agent, CommandABC, CommandResult
from .types import CommandName


class LogoutCommand(CommandABC):
    """Logout from OAuth providers."""

    @property
    def name(self) -> CommandName:
        return CommandName.LOGOUT

    @property
    def summary(self) -> str:
        return "Logout from provider"

    @property
    def is_interactive(self) -> bool:
        return True

    @property
    def support_addition_params(self) -> bool:
        return True

    @property
    def placeholder(self) -> str:
        return "provider"

    async def run(self, agent: Agent, user_input: message.UserInputPayload) -> CommandResult:
        provider = user_input.text.strip() or None

        if provider is None:
            try:
                provider = await asyncio.to_thread(
                    select_provider,
                    include_api_keys=True,
                    configured_only=True,
                    prompt="Select provider to logout:",
                )
            except KeyboardInterrupt:
                provider = None
            if provider is None:
                return CommandResult(
                    events=[
                        events.NoticeEvent(
                            session_id=agent.session.id,
                            content="(cancelled)",
                        )
                    ]
                )

        try:
            execute_logout(provider)
        except (KeyboardInterrupt, typer.Abort):
            return CommandResult(
                events=[
                    events.NoticeEvent(
                        session_id=agent.session.id,
                        content="(cancelled)",
                    )
                ]
            )
        except typer.Exit as e:
            if e.exit_code not in (None, 0):
                return CommandResult(
                    events=[
                        events.NoticeEvent(
                            session_id=agent.session.id,
                            content=f"Logout failed (exit code: {e.exit_code}).",
                            is_error=True,
                        )
                    ]
                )
            return CommandResult(
                events=[
                    events.NoticeEvent(
                        session_id=agent.session.id,
                        content="(cancelled)",
                    )
                ]
            )

        return CommandResult(
            events=[
                events.NoticeEvent(
                    session_id=agent.session.id,
                    content="Logout flow completed.",
                )
            ]
        )
