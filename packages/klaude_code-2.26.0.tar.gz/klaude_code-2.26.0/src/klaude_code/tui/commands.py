from __future__ import annotations

from dataclasses import dataclass

from rich.console import RenderableType
from rich.text import Text

from klaude_code.protocol import events


@dataclass(frozen=True, slots=True)
class RenderCommand:
    pass


@dataclass(frozen=True, slots=True)
class FlushOpenBlocks(RenderCommand):
    pass


@dataclass(frozen=True, slots=True)
class RenderWelcome(RenderCommand):
    event: events.WelcomeEvent


@dataclass(frozen=True, slots=True)
class RenderUserMessage(RenderCommand):
    event: events.UserMessageEvent


@dataclass(frozen=True, slots=True)
class RenderTaskStart(RenderCommand):
    event: events.TaskStartEvent


@dataclass(frozen=True, slots=True)
class RenderDeveloperMessage(RenderCommand):
    event: events.DeveloperMessageEvent


@dataclass(frozen=True, slots=True)
class RenderNotice(RenderCommand):
    event: events.NoticeEvent


@dataclass(frozen=True, slots=True)
class RenderAwaySummary(RenderCommand):
    event: events.AwaySummaryEvent


@dataclass(frozen=True, slots=True)
class RenderSessionStats(RenderCommand):
    event: events.SessionStatsEvent


@dataclass(frozen=True, slots=True)
class RenderBashCommandStart(RenderCommand):
    event: events.BashCommandStartEvent


@dataclass(frozen=True, slots=True)
class AppendBashCommandOutput(RenderCommand):
    event: events.BashCommandOutputDeltaEvent


@dataclass(frozen=True, slots=True)
class RenderBashCommandEnd(RenderCommand):
    event: events.BashCommandEndEvent


@dataclass(frozen=True, slots=True)
class RenderToolCall(RenderCommand):
    event: events.ToolCallEvent


@dataclass(frozen=True, slots=True)
class RenderToolResult(RenderCommand):
    event: events.ToolResultEvent
    is_sub_agent_session: bool


@dataclass(frozen=True, slots=True)
class RenderTaskMetadata(RenderCommand):
    event: events.TaskMetadataEvent


@dataclass(frozen=True, slots=True)
class RenderTaskFinish(RenderCommand):
    event: events.TaskFinishEvent


@dataclass(frozen=True, slots=True)
class RenderInterrupt(RenderCommand):
    pass


@dataclass(frozen=True, slots=True)
class RenderError(RenderCommand):
    event: events.ErrorEvent


@dataclass(frozen=True, slots=True)
class StartThinkingStream(RenderCommand):
    session_id: str


@dataclass(frozen=True, slots=True)
class AppendThinking(RenderCommand):
    session_id: str
    content: str


@dataclass(frozen=True, slots=True)
class EndThinkingStream(RenderCommand):
    session_id: str


@dataclass(frozen=True, slots=True)
class StartAssistantStream(RenderCommand):
    session_id: str


@dataclass(frozen=True, slots=True)
class AppendAssistant(RenderCommand):
    session_id: str
    content: str


@dataclass(frozen=True, slots=True)
class EndAssistantStream(RenderCommand):
    session_id: str


@dataclass(frozen=True, slots=True)
class SpinnerStart(RenderCommand):
    pass


@dataclass(frozen=True, slots=True)
class SpinnerStop(RenderCommand):
    pass


@dataclass(frozen=True, slots=True)
class SpinnerStatusLine:
    text: str | Text
    session_id: str | None = None


@dataclass(frozen=True, slots=True)
class SpinnerUpdate(RenderCommand):
    right_text: RenderableType | None
    status_lines: tuple[SpinnerStatusLine, ...] = ()
    reset_bottom_height: bool = False
    leading_blank_line: bool = False
    top_blank_line: bool = False


@dataclass(frozen=True, slots=True)
class PrintBlankLine(RenderCommand):
    pass


@dataclass(frozen=True, slots=True)
class PrintRuleLine(RenderCommand):
    pass


@dataclass(frozen=True, slots=True)
class TaskClockStart(RenderCommand):
    pass


@dataclass(frozen=True, slots=True)
class TaskClockClear(RenderCommand):
    pass


@dataclass(frozen=True, slots=True)
class RenderCompactionSummary(RenderCommand):
    summary: str
    kept_items_brief: tuple[tuple[str, int, str], ...] = ()  # (item_type, count, preview)


@dataclass(frozen=True, slots=True)
class RenderForkCacheHitRate(RenderCommand):
    fork_label: str
    cache_read_tokens: int
    cache_creation_tokens: int
    input_tokens: int
    cache_hit_rate: float
    fallback_used: bool


@dataclass(frozen=True, slots=True)
class RenderHandoff(RenderCommand):
    summary: str


@dataclass(frozen=True, slots=True)
class RenderRewind(RenderCommand):
    checkpoint_id: int
    note: str
    rationale: str
    original_user_message: str
    messages_discarded: int | None = None


@dataclass(frozen=True, slots=True)
class UpdateTerminalTitlePrefix(RenderCommand):
    prefix: str | None
    model_name: str | None
    session_title: str | None = None


@dataclass(frozen=True, slots=True)
class StartTitleBlink(RenderCommand):
    model_name: str | None
    session_title: str | None = None


@dataclass(frozen=True, slots=True)
class StopTitleBlink(RenderCommand):
    pass
