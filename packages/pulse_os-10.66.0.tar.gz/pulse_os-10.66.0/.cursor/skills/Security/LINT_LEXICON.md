---
type: skill
domain: security
links: [Corpus_Callosum/CONSTITUTION.md, PULSE_OS.md]
---

# LINT_LEXICON
> **ROLE:** CODE QUALITY SENTINEL
> **TRIGGER:** "LINT"

## Core Mandate
Consistency is the prerequisite for speed. Every line of code passes automated quality gates before a human ever reads it.

## Step-by-Step Protocol
1. **Brain check**: `python pulse/brain/brain_query.py --query "lint rules for <language/module>"`
2. **Run ruff** with strict config: `ruff check --select E,W,F,C901,I,N,UP --fix <path>`. Auto-fix stylistic issues; manually fix logic issues.
3. **Run mypy** for type safety: `mypy --strict <path>`. Zero `Any` types in public APIs.
4. **Check for dependency cycles**: A imports B, B imports A is a Law 1 violation. Use `ruff check --select I` to catch circular imports.
5. **Report or relay**: Log violations to brain via `pulse_save.py`, post fix tasks via `pulse_relay.py` for remaining issues.

## Tool-Specific Rulesets

### Ruff (Python -- primary)
```toml
[tool.ruff]
select = ["E", "W", "F", "C901", "I", "N", "UP", "B", "SIM"]
line-length = 120
target-version = "py311"
[tool.ruff.mccabe]
max-complexity = 10
```

### Mypy (Python type checking)
```toml
[tool.mypy]
strict = true
warn_return_any = true
disallow_untyped_defs = true
no_implicit_optional = true
```

### ESLint (JS/TS if applicable)
```json
{ "rules": { "no-unused-vars": "error", "no-console": "warn", "complexity": ["error", 10] } }
```

## Metrics & Thresholds
| Metric | Limit |
|---|---|
| Ruff violations after auto-fix | 0 |
| Mypy errors | 0 in public APIs |
| Unused imports/variables | 0 |
| Line length | 120 chars max |
| McCabe complexity | 10 max |

## Anti-Patterns
- **`# type: ignore` without reason**: Every ignore must have a comment explaining why.
- **`noqa` blankets**: `# noqa` on a line disables ALL checks. Use specific codes: `# noqa: E501`.
- **Dead code left "for later"**: Delete it. Git remembers.

## Tools to Use
- `ruff check --fix <path>` -- auto-fix lint issues
- `mypy --strict <path>` -- type checking
- `brain_query.py --query "lint patterns"` -- check brain for known lint lessons
- `pulse_relay.py` -- post lint fix tasks for other agents

## Verification Checklist
- [ ] `ruff check` returns 0 violations on changed files
- [ ] `mypy` returns 0 errors on public-facing modules
- [ ] No unused imports or dead code in changed files
- [ ] No dependency cycles (A imports B, B imports A)
- [ ] All `# type: ignore` comments have justification
