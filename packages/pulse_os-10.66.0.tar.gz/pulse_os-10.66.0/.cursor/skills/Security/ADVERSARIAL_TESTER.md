---
type: skill
domain: security
links: [Corpus_Callosum/CONSTITUTION.md, PULSE_OS.md]
---

# ADVERSARIAL_TESTER
> **ROLE:** RED TEAM LEAD
> **TRIGGER:** "SECURITY AUDIT"

## Core Mandate
If it can be broken, break it first. Every input is hostile. Every agent is potentially rogue.

## Step-by-Step Protocol
1. **Brain recon**: `python pulse/brain/brain_query.py --query "known vulnerabilities in <target module>"`
2. **Map attack surface**: List all entry points (CLI args, JSON inputs, file reads, API endpoints). Each one gets tested.
3. **Run OWASP-mapped attacks**: Test each entry point against the relevant OWASP categories below.
4. **Verify crypto integrity**: Confirm `PulseCrypto` detects single bit-flips, rejects empty/null signatures, and uses HMAC-SHA256 (not MD5/SHA1).
5. **Document and save**: `python pulse/brain/pulse_save.py --agent adversarial --learnings "finding" --failures "what broke"`

## OWASP Top 10 Mapping (PULSE-relevant)
| OWASP Category | PULSE Attack Vector | Test |
|---|---|---|
| A01 Broken Access | Rogue agent claims premium task without tier match | Post task tier=premium, claim with tier=fast agent |
| A03 Injection | Malicious `--query` input to brain_query.py | `--query "; rm -rf /"`, `--query "$(cat /etc/passwd)"` |
| A04 Insecure Design | Unsigned task dispatch bypasses HMAC | Post task without PULSE_BRAIN_KEY, verify rejection |
| A05 Security Misconfig | .env secrets in git, stale .env.sig | Check .gitignore covers .env*, run seal_env verification |
| A08 Data Integrity | Tampered constitution hash accepted | Flip 1 bit in CONSTITUTION.md, verify boot fails |
| A09 Logging Failures | PII leaked in session logs | Grep logs for emails, API keys, passwords |

## Specific Attack Vectors
```python
# Boundary condition tests for ANY input handler:
EVIL_INPUTS = [
    "",                     # empty string
    None,                   # null
    "A" * 100_000,          # buffer overflow attempt
    "\x00\x01\x02",        # null bytes
    '{"__proto__": {}}',   # prototype pollution
    "../../../etc/passwd",  # path traversal
    2**63,                  # MAX_INT overflow
]
```

## Metrics & Thresholds
| Metric | Threshold |
|---|---|
| Input validation coverage | 100% of entry points |
| HMAC bypass attempts blocked | 100% |
| PII in logs | 0 instances |
| Crash on malformed input | 0 (must fail gracefully) |

## Anti-Patterns
- **Testing only happy paths**: If you only test valid JSON, you have tested nothing.
- **`eval()` or `exec()` on user input**: Immediate Law 8 violation. Use `json.loads()` or `ast.literal_eval()`.
- **Trusting agent self-reported tier**: Always verify tier server-side, never trust the claim.

## Tools to Use
- `brain_query.py --query "security audit for <module>"` -- prior findings
- `pulse_save.py --agent adversarial --learnings "..." --failures "..."` -- record results
- `pulse_relay.py --tasks "Fix vuln:security:premium"` -- escalate critical findings
- `Hippocampus/Patterns/` -- check known bad patterns

## Verification Checklist
- [ ] All entry points tested with EVIL_INPUTS list
- [ ] HMAC signature validation rejects tampered payloads
- [ ] No `eval()`, `exec()`, or `os.system()` with user-controlled input
- [ ] PulseCrypto detects single bit-flip in signed content
- [ ] Zero PII found in any log file under state/
- [ ] Path traversal attempts blocked on all file-read operations
