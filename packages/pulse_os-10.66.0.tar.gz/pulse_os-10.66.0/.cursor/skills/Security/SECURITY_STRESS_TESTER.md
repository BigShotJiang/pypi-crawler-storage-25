---
type: skill
domain: security
links: [Corpus_Callosum/CONSTITUTION.md, PULSE_OS.md]
---

# SECURITY_STRESS_TESTER
> **ROLE:** PENETRATION TESTER
> **TRIGGER:** "HARDEN CORE"

## Core Mandate
Security is the foundation, not a feature. Every component must survive hostile conditions, concurrent access, and data corruption.

## Step-by-Step Protocol
1. **Brain recon**: `python pulse/brain/brain_query.py --query "stress test results for <module>"`
2. **Scan for insecure deserialization**: Grep for `json.loads()`, `pickle.load()`, `yaml.load()` without safe loaders. Every `yaml.load` must use `Loader=yaml.SafeLoader`.
3. **Test race conditions**: Run 10 concurrent workers claiming the same task via `atomic_update_json`. Verify exactly 1 succeeds, 9 fail gracefully.
4. **Audit crypto entropy**: Verify `PulseCrypto` uses `secrets` or `os.urandom()`, never `random.random()` for key material.
5. **Verify zero-retention**: After a session ends, confirm no API keys, tokens, or passwords persist in State/ logs or memory.

## Concrete Stress Scenarios
| Scenario | Method | Pass Criteria |
|---|---|---|
| Task board race | 10 threads claim same task_id | Exactly 1 claim succeeds |
| Large payload | Post 1MB task body to task_board.json | Rejected or handled in <2s |
| Corrupt JSON | Write invalid JSON to task_board.json, restart | System recovers, no crash |
| Key rotation | Change PULSE_BRAIN_KEY mid-session | Old signatures rejected, new ones accepted |
| Disk full | Fill State/ partition, attempt pulse_save | Graceful error, no data corruption |
| Rapid fire | 100 brain_query calls in 10 seconds | No crash, responses <500ms each |

## Metrics & Thresholds
| Metric | Threshold |
|---|---|
| Race condition: duplicate claims | 0 allowed |
| Insecure deserialization instances | 0 (`pickle.load` banned, `yaml.safe_load` only) |
| Secrets in log files | 0 (grep for API key patterns) |
| Recovery from corrupt state file | <5 seconds |
| Filelock acquisition timeout | <2 seconds |

## Good Example
```python
# CORRECT: atomic task claiming with filelock
from filelock import FileLock
import json

def claim_task(task_id: str, agent: str) -> bool:
    lock = FileLock("task_board.json.lock", timeout=2)
    with lock:
        board = json.loads(Path("task_board.json").read_text())
        task = next((t for t in board["tasks"] if t["task_id"] == task_id), None)
        if not task or task["status"] != "open":
            return False  # Already claimed or missing
        task["status"] = "claimed"
        task["claimed_by"] = agent
        Path("task_board.json").write_text(json.dumps(board, indent=2))
        return True
```

## Anti-Patterns
- **`pickle.load()` on untrusted data**: Arbitrary code execution. Use `json.loads()` only.
- **`random.random()` for security**: Predictable. Use `secrets.token_hex()` for keys/tokens.
- **Catching `Exception` and continuing silently**: Security failures must be loud -- log and halt.

## Tools to Use
- `brain_query.py --query "race conditions in <module>"` -- check prior findings
- `pulse_save.py --agent stress_tester --failures "..."` -- record vulnerabilities
- `pulse_relay.py --tasks "Fix race condition:security:standard"` -- delegate fixes
- `Hippocampus/Patterns/` -- check known vulnerable patterns

## Verification Checklist
- [ ] Zero `pickle.load()` in entire codebase
- [ ] All `yaml.load()` calls use `Loader=yaml.SafeLoader`
- [ ] No `random.random()` used for crypto/security purposes
- [ ] Race condition test passes (10 concurrent claims, 1 winner)
- [ ] Zero secrets/API keys found in State/ log files
- [ ] Law 9 (Privacy) enforced: no PII in any log or brain file
