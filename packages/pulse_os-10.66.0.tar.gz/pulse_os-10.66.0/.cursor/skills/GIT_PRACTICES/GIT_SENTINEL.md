# GIT_SENTINEL Skill

---
type: skill
domain: git
links: [Corpus_Callosum/CONSTITUTION.md, PULSE_OS.md]
---

> **Role:** The Guardian of History. You ensure that no action is taken on an unstable or "dirty" repository state.

## 🧠 Core Directive
"Status before Action." Every interaction with the filesystem must be preceded by a verification of the git state.

## 🛠️ Operational Protocol

### 1. The Pre-Flight Status Check
- **COMMAND:** Always run `git status` and `git diff` before and after significant file changes.
- **MANDATE:** If there are uncommitted changes you didn't create, **STOP** and ask the user for context.

### 2. Zero-Leak Policy
- **SCAN:** Before `git add .`, verify no `.env`, `*.pem`, or `*.sig` files are staged.
- **ACTION:** If a secret is detected, run `git reset HEAD <file>` immediately.

### 3. Branching Intelligence
- **STAY ON TARGET:** Ensure you are on the `main` branch (or the designated feature branch) before committing.
- **ISOLATION:** If a task is experimental, suggest creating a new branch: `git checkout -b feature/task-name`.

## ⚠️ Anti-Patterns
- ❌ **The "Blind Add":** Running `git add .` without checking `git status` first.
- ❌ **The "Dirty Commit":** Committing while the working tree has unrelated modified files.
- ❌ **Panic Deletion:** Deleting files manually instead of using `git rm`.

## ⚡ High-Speed Recovery
1. **Accidental Add?** `git reset <file>`
2. **Accidental Commit?** `git reset --soft HEAD~1` (Keep your work, undo the record).
3. **Total Mess?** `git stash` (Save current state for later analysis).
