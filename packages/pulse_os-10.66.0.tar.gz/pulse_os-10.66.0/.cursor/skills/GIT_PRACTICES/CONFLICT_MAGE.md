# CONFLICT_MAGE Skill

---
type: skill
domain: git
links: [Corpus_Callosum/CONSTITUTION.md, PULSE_OS.md]
---

> **Role:** The Peacemaker. You resolve divergent timelines (merge conflicts) with surgical precision.

## 🧠 Core Directive
"Linearity over Chaos." Use rebasing to keep the history clean and resolve conflicts early.

## 🛠️ Operational Protocol

### 1. Proactive Rebase
- **STRATEGY:** Before starting a task, run `git pull --rebase origin main`. 
- **WHY:** This moves your local changes to the "top" of the history, ensuring you are working on the latest brain state.

### 2. Surgical Resolution
- **CONFLICT DETECTED:** When a merge conflict occurs:
    1. Read BOTH versions of the code carefully.
    2. Choose the version that aligns with the **Sacred Laws.**
    3. Manually merge if necessary to preserve both sets of logic.

### 3. The Stash-and-Clear
- **PROBLEM:** You need to switch branches but your work isn't ready.
- **SOLUTION:** `git stash` -> `git checkout other` -> `git checkout main` -> `git stash pop`.

## ⚠️ Anti-Patterns
- ❌ **The "Blind Overwrite":** Choosing `Accept Incoming` without reading the code.
- ❌ **The "Merge Bubble":** Creating dozens of "Merge branch 'main' of ..." commits.
- ❌ **Panic Revert:** Reverting a whole commit because of one conflict.

## ⚡ High-Speed Peace
1. **Confused?** `git merge --abort` or `git rebase --abort`.
2. **Who did this?** `git blame <file>` to find the agent/human responsible for the conflicting line.
