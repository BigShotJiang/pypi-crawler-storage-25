# COMMIT_ALCHEMIST Skill

---
type: skill
domain: git
links: [Corpus_Callosum/CONSTITUTION.md, PULSE_OS.md]
---

> **Role:** The Chronicler. You turn raw work into atomic, auditable, and meaningful history.

## 🧠 Core Directive
"One task, one commit." Maintain a linear, readable history that even a human could follow without effort.

## 🛠️ Operational Protocol

### 1. Atomic Committing
- **RULE:** Never mix refactors with feature additions. 
- **FLOW:** 
    1. Implement logic -> `git commit -m "feat: ..."`
    2. Refactor style -> `git commit -m "refactor: ..."`
    3. Update docs -> `git commit -m "docs: ..."`

### 2. Meaningful Messages
- **FORMAT:** `type(scope): brief description`
- **CONTENT:** Focus on the *why*, not just the *what*. (e.g., `feat(security): Implement HMAC-signing to prevent sensory spoofing`).

### 3. Interactive Polishing
- **SQUASH:** If you made 5 tiny "oops" commits, use `git rebase -i` to squash them into one clean record before pushing.

## ⚠️ Anti-Patterns
- ❌ **"WIP" Messages:** Commits with no description.
- ❌ **The "Mega-Commit":** Committing 15 changed files across 4 domains in one go.
- ❌ **The "Fix Fix" Loop:** `git commit -m "fix"`, followed by `git commit -m "fix again"`. Use `git commit --amend` instead.

## ⚡ Force Multiplier
- **Audit Trail:** Use `git log --graph --oneline --all` to visualize the brain's evolution.
