---
type: skill
domain: architecture
links: [Corpus_Callosum/CONSTITUTION.md, PULSE_OS.md]
---

# PATTERN_PIONEER.md
> **ROLE:** RECOGNITION EXPERT
> **TRIGGER:** "DETECT"

## Protocol

1. **Identify the code smell.** Scan for symptoms: long methods (>50 lines), god classes (>300 lines), switch/if-elif chains (>4 branches), tight coupling (module imports >5 others), duplicated logic (3+ occurrences).
2. **Map to a known pattern.** Match the smell to the GoF or architectural pattern that solves it:
   - Switch/if-elif chains -> **Strategy** or **State** pattern
   - Object creation complexity -> **Factory** or **Builder** pattern
   - Multiple similar classes -> **Template Method** pattern
   - Event-driven reactions -> **Observer** pattern
   - Wrapping behavior around calls -> **Decorator** pattern
3. **Check PULSE brain for precedent.** Query brain for prior pattern applications in this codebase. Reuse existing patterns before introducing new ones. Max 3 active design patterns per module.
4. **Refactor incrementally.** Apply the pattern in a single module first. Keep the old code path behind a flag if the change is risky. Run all tests before and after.
5. **Document and save.** Record which pattern was applied, where, and why in the brain. Post the pattern to `auto_patterns.md` so other agents learn from it.

## Metrics & Thresholds
- **Method length:** >50 lines = candidate for decomposition
- **Class size:** >300 lines = candidate for extraction (SRP violation)
- **Branch count:** >4 if-elif branches = candidate for Strategy/State
- **Coupling:** Module importing >5 other project modules = too tightly coupled
- **Pattern limit:** Max 3 design patterns per module (avoid over-engineering)

## Good Example
```python
# BEFORE: 6-branch if-elif chain for provider dispatch
if provider == "anthropic":
    return call_anthropic(prompt)
elif provider == "google":
    return call_google(prompt)
elif provider == "openai":
    return call_openai(prompt)
# ... 3 more branches

# AFTER: Strategy pattern
PROVIDERS: dict[str, Callable[[str], str]] = {
    "anthropic": call_anthropic,
    "google": call_google,
    "openai": call_openai,
}

def dispatch(provider: str, prompt: str) -> str:
    handler = PROVIDERS.get(provider)
    if not handler:
        raise ValueError(f"Unknown provider: {provider}")
    return handler(prompt)
```

## Anti-Patterns
- **Pattern for pattern's sake:** Applying Factory pattern to a class instantiated in one place. Patterns solve recurring problems, not theoretical ones.
- **Over-abstraction:** Creating 5 interfaces for 2 implementations. Only abstract when you have 3+ concrete variants.
- **Ignoring existing patterns:** Introducing Observer when the codebase already uses callbacks. Be consistent with what exists.

## Tools
- `python pulse/brain/brain_query.py --query "patterns used in <module>"`
- `python pulse/brain/pulse_save.py --agent <you> --learnings "applied Strategy pattern to <module> provider dispatch"`
- `python pulse/tasks/pulse_relay.py --tasks "Refactor <module> to Strategy:architecture:standard"`

## Verification Checklist
- [ ] Code smell identified with specific metric (line count, branch count, coupling count)
- [ ] Pattern chosen matches the smell (not forced or over-engineered)
- [ ] Brain queried for prior pattern usage in this codebase
- [ ] All tests pass after refactoring
- [ ] Pattern application documented in brain via pulse_save
