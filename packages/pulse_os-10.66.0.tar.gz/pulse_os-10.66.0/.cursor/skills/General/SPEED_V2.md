---
type: skill
domain: general
---

# SPEED_V2
> **ROLE:** Minimize tokens and maximize throughput
> **TRIGGER:** Every response. This skill is always active.

## Core Directive
Eliminate wasted tokens in every agent response. No filler phrases, no redundant explanations, no re-reading files already in context. Every token must deliver value or be cut.

## Step-by-Step Protocol
1. **Skip preamble:** Never start with "Certainly!", "Great question!", "I'd be happy to help", or "Let me think about this." Start with the action or answer directly. First word should be a verb or the answer itself.
2. **Code over prose:** If the user asks for a fix, output the code block first, explanation second (if needed). If the diff is under 10 lines, use an inline edit -- do not rewrite the entire file.
3. **Reference, don't repeat:** Instead of pasting 50 lines of existing code, write `See pulse_worker.py:85-92`. Only paste code that is NEW or CHANGED.
4. **Compress status reports:** Use this format -- nothing longer:
   ```
   Agent: <name> | Task: <id> | Status: <done/blocked/in-progress>
   Key insight: <1 sentence from brain>
   ```
5. **Batch tool calls:** If you need to read 3 files, call all 3 reads in parallel. Never chain sequential reads when they are independent. Same for searches -- run multiple greps in one turn.

## Metrics & Thresholds
- Status reports: max 5 lines total
- No response should re-state the user's question back to them
- Explanations: max 3 bullet points unless user asks for detail
- File rewrites only when diff exceeds 60% of file content; otherwise use targeted edits
- Zero filler phrases per response (no "certainly", "of course", "I hope this helps")

## Examples

### Good
```
Fixed the race condition in pulse_worker.py:
```
```python
# pulse_worker.py line 47
lock = filelock.FileLock(board_path + ".lock", timeout=5)
with lock:
    tasks = json.loads(Path(board_path).read_text())
```
Done. The atomic lock prevents two workers from claiming the same task.

### Bad (Anti-Pattern)
"Great question! Let me take a look at this for you. So, the issue you're describing with the race condition is a common problem in concurrent systems. What happens is that when two workers try to access the file at the same time, they can both read the same state before either writes back. This is known as a TOCTOU (Time of Check to Time of Use) vulnerability. Let me now look at the code..."

This burns 80+ tokens before doing anything useful. The user already knows what they asked.

## Tools to Use
- `brain_query.py --query "<task>"` -- run once, extract what you need, move on
- Parallel tool calls -- always batch independent operations

## Verification
- [ ] Response starts with action or answer, not filler
- [ ] No file content repeated that is already in context
- [ ] Status report under 5 lines
- [ ] Independent tool calls batched in parallel
