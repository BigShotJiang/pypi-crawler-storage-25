---
type: skill
domain: general
links: [Corpus_Callosum/CONSTITUTION.md, PULSE_OS.md]
---

# CONSTITUTIONAL_CLARITY.md
> **ROLE:** CONSTITUTIONAL COMPLIANCE OFFICER
> **TRIGGER:** "RULE CHANGE"

## Protocol: 5-Step Compliance Check

1. **Load Governance** -- Read `CONSTITUTION.md` (Tier -1 moral anchor, Tier 0 meta-rules, Tier 1 sacred laws) and `LAWS.md` (10 law definitions). Do NOT print them to the user -- compliance is silent.
2. **Law Verification** -- For the current task, check each applicable law:
   - Law 1 (SoC): Does code stay in its layer?
   - Law 3 (No Regress): Do all existing tests still pass?
   - Law 7 (Small Files): Any file > 300 lines?
   - Law 8 (Cleanup): Any dead code left behind?
   - Law 9 (Propagation): All related files updated?
   - Law 10 (Report): Status report given before first action?
3. **Compliance Scoring** -- Rate compliance for each applicable law: PASS, WARN (minor gap), or FAIL (violation). Any FAIL blocks the task.
4. **Violation Reporting** -- If a violation is found: (a) Log to `Hippocampus/Patterns/`, (b) Run `pulse_save.py` with the failure, (c) Stop work and notify the user with specific law number and violation.
5. **Bypass Protocol** -- If a rule MUST be broken: Ask user explicitly: "This requires bypassing Law X. Approve? [Y/N]". If approved, log to `.claude/logs/RULE_VIOLATIONS.md` with timestamp, law, reason, and approval.

## Metrics & Thresholds

| Metric | Threshold | Consequence |
|--------|-----------|-------------|
| Laws checked per task | >= 4 of 10 | Minimum coverage for any code change |
| FAIL count to block | 1 | Any single FAIL stops the merge |
| Constitution hash | Must match .env | Orchestrator will not boot if stale |

## Good Example

```
Task: Add Redis caching to brain_query.py
Compliance check:
  Law 1 (SoC): PASS -- caching stays in Utilities layer
  Law 3 (No Regress): PASS -- existing tests pass
  Law 4 (License): PASS -- redis-py is MIT
  Law 7 (File Size): WARN -- brain_query.py at 280 lines, watch it
  Law 9 (Propagation): PASS -- BRAIN_MAP.md updated
Result: 4 PASS, 1 WARN, 0 FAIL -- proceed.
```

## Anti-Patterns

- **Ceremony spam** -- Printing law lists to the user. Compliance is SILENT. Verify internally, report only violations.
- **Skipping hash sync** -- Editing CONSTITUTION.md without running `update_constitution_hash.py`. Orchestrator dies on next boot.
- **Post-hoc compliance** -- Checking laws AFTER shipping. Check BEFORE writing code.

## Tools to Use

- `brain_query.py --query "constitutional violations <area>"` -- Find past violations in this domain
- `pulse_save.py --agent <you> --failures "Law X violation: <details>"` -- Record violations
- `update_constitution_hash.py` -- Sync constitution hash after any CONSTITUTION.md edit

## Verification Checklist

- [ ] CONSTITUTION.md and LAWS.md loaded (internally, not printed)
- [ ] >= 4 applicable laws checked with PASS/WARN/FAIL ratings
- [ ] Zero FAIL ratings (or explicit user bypass approval logged)
- [ ] Constitution hash matches .env (run `update_constitution_hash.py` if edited)
- [ ] Any violations recorded in Hippocampus/Patterns/anti_patterns.md
