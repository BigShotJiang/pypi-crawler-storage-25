---
type: skill
domain: general
links: [Corpus_Callosum/CONSTITUTION.md, PULSE_OS.md]
---

# REASONING_REFINER.md
> **ROLE:** LOGIC AUDITOR
> **TRIGGER:** "THINK"

## Protocol: 5-Step Chain-of-Thought

1. **Decompose** -- Break the problem into irreducible sub-problems. State each as a single sentence. If a sub-problem has more than one verb, split it further.
2. **Surface Assumptions** -- List every assumption explicitly. For each, ask: "What evidence supports this? What breaks if this is wrong?" Mark each as VERIFIED (evidence exists) or ASSUMED (no evidence).
3. **Reason Forward** -- For each sub-problem, state: Given X, then Y, because Z. Chain the logic. If any link is weak, flag it.
4. **Detect Fallacies** -- Scan your reasoning for these traps:
   - Confirmation bias: Did you only look for supporting evidence?
   - Sunk cost: Are you keeping bad code because of effort invested?
   - Appeal to complexity: Are you over-engineering because simple feels wrong?
   - Survivorship bias: Are you ignoring failed approaches in the brain?
5. **Validate Against Brain** -- Run `brain_query.py` to check if past decisions contradict your conclusion. If they do, resolve the conflict explicitly.

## Metrics & Thresholds

| Metric | Threshold | Why |
|--------|-----------|-----|
| Assumptions listed | >= 3 per decision | Unexamined assumptions cause regressions |
| VERIFIED vs ASSUMED ratio | >= 50% verified | Decisions need evidence, not guesses |
| Logical chain length | <= 5 steps | Longer chains = higher error probability |

## Good Example

```
Problem: "Should we add Redis caching to brain_query?"
Assumptions:
  1. brain_query is slow (ASSUMED -- no profiling data)
  2. Redis is available in prod (VERIFIED -- .env has REDIS_URL)
  3. Cache invalidation is simple (ASSUMED -- brain writes are frequent)
Reasoning: A1 is unverified. Profile first. A3 is risky given bridge writes.
Decision: Profile before adding complexity. Post profiling task.
```

## Anti-Patterns

- **Jumping to solutions** -- Coding before the reasoning chain is complete. Finish thinking, then implement.
- **Ignoring the brain** -- Past decisions exist for a reason. Check `auto_lessons.md` and `auto_fails.md` before concluding.
- **Unbounded reasoning** -- Thinking without a stopping condition. Set a 5-minute timebox, then decide.

## Tools to Use

- `brain_query.py --query "<decision topic>"` -- Check past reasoning on this topic
- `pulse_save.py --agent <you> --learnings "decision: <what and why>"` -- Record the decision
- `pulse_relay.py --tasks "Validate <assumption>:general:fast"` -- Delegate assumption verification

## Verification Checklist

- [ ] All assumptions listed and labeled VERIFIED or ASSUMED
- [ ] No logical fallacies detected (or explicitly acknowledged)
- [ ] Brain queried for contradicting past decisions
- [ ] Reasoning chain is <= 5 steps with no weak links
- [ ] Decision recorded via `pulse_save.py`
