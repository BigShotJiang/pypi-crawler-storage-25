---
type: skill
domain: general
links: [Corpus_Callosum/CONSTITUTION.md, PULSE_OS.md]
---

# STRATEGIST.md
> **ROLE:** CHIEF STRATEGY OFFICER
> **TRIGGER:** "DEFINE GOAL"

## Protocol: 5-Step Strategic Decision

1. **Define the Problem** -- State the root cause in one sentence. If you're describing symptoms, dig deeper. Use "5 Whys" until you hit the structural issue.
2. **SWOT Analysis** -- For the proposed solution, fill in:
   - **Strengths:** What does this leverage that already works?
   - **Weaknesses:** What new failure modes does this introduce?
   - **Opportunities:** What future work does this unlock?
   - **Threats:** What breaks if this assumption is wrong?
3. **Decision Matrix** -- Score each option (1-5) on: Impact, Effort, Risk, Alignment with PIPELINE.md. Pick the highest (Impact + Alignment) - (Effort + Risk).
4. **Risk Assessment** -- For top 3 risks: Rate probability (1-5) x impact (1-5). Any score >= 15 requires a mitigation plan before proceeding.
5. **Predict Consequences** -- Before committing, answer: (a) Does this create tech debt? (b) Does this violate any Sacred Law? (c) What does the codebase look like 3 tasks from now if we do this?

## Metrics & Thresholds

| Metric | Threshold | Action |
|--------|-----------|--------|
| Decision matrix options | >= 3 | Never evaluate fewer than 3 paths |
| Risk score (prob x impact) | < 15 to proceed | >= 15 requires mitigation plan |
| Pareto filter | 20% of files | Focus on high-leverage changes only |

## Good Example

```
Problem: Agents idle because orchestrator not running.
Root cause (5 Whys): Agent CLI never starts orchestrator.
Options:
  A) Auto-start orchestrator in cmd_agent() -- Impact:5 Effort:2 Risk:1 Align:5 = +7
  B) Docs telling user to start it -- Impact:2 Effort:1 Risk:0 Align:1 = +2
  C) Merge orchestrator into agent -- Impact:4 Effort:5 Risk:4 Align:3 = -2
Decision: Option A. Ship _ensure_orchestrator().
Risk: Double-launch (prob:3 x impact:2 = 6) -- acceptable, add PID check.
```

## Anti-Patterns

- **Solving symptoms** -- Fixing the error message instead of the broken pipeline. Always ask "why" until you hit structure.
- **Analysis paralysis** -- Scoring 10 options for a fast-tier task. Match analysis depth to task tier.
- **Ignoring PIPELINE.md** -- Building something not on the roadmap. Check alignment before starting.

## Tools to Use

- `brain_query.py --query "strategy for <domain>"` -- Find past strategic decisions
- `pulse_save.py --agent <you> --learnings "strategy: chose X over Y because Z"` -- Record the decision rationale
- `pulse_relay.py --tasks "Implement <chosen option>:development:standard"` -- Delegate execution

## Verification Checklist

- [ ] Root cause identified (not symptoms)
- [ ] >= 3 options evaluated in decision matrix
- [ ] Top risks scored, none >= 15 without mitigation
- [ ] Solution aligns with PIPELINE.md priorities
- [ ] Consequences predicted for next 3 tasks
