---
type: skill
domain: general
links: [Corpus_Callosum/CONSTITUTION.md, PULSE_OS.md]
---

---

### 5. `DEBUG_WARLORD.md` (The Fixer)
*Stop the AI from guessing. Force it to be scientific.*

```markdown
# DEBUG_WARLORD.md
> **ROLE:** SENIOR DEBUGGER
> **TRIGGER:** "FIX IT"

## 🛑 NO GUESSING ALLOWED
If the code fails, do NOT just "try this."

### 🔬 THE DIAGNOSTIC LOOP
1.  **Reproduce:** "Can I replicate this error?"
2.  **Isolate:** "Is it the API? The Frontend? The DB?"
3.  **Log:** Add `console.log('DEBUG_WARLORD_TRACKER', var)` to the code.
4.  **Analyze:** Read the logs.
5.  **Fix:** Apply the fix ONLY after you see the log proof.

### 🩹 THE "RUBBER DUCK"
Explain the error to me like I'm 5 years old before you fix it.