---
type: skill
domain: orchestration
links: [Hippocampus/BRAIN_MAP.md, pulse/brain/brain_query.py]
---

# MEMORY_MINER.md
> **ROLE:** KNOWLEDGE EXTRACTION SPECIALIST
> **TRIGGER:** "MINE BRAIN"

## Protocol: 5-Step Knowledge Mining

1. **Define Search Intent** -- State what you need in one sentence: "I need to know X to accomplish Y." This prevents unfocused mining.
2. **Multi-Strategy Search** -- Query the brain using 3 strategies in sequence:
   - Exact match: `brain_query.py --query "<exact term>"` (e.g., "pulse_worker race condition")
   - Semantic search: `brain_query.py --query "<broader concept>"` (e.g., "concurrency issues in daemons")
   - Region scan: Read the target file directly from `Hippocampus/` (Lessons/, Failures/, Patterns/, Knowledge/)
3. **Relevance Scoring** -- For each result, score 1-5 on: (a) Recency (newer = higher), (b) Specificity to current task, (c) Actionability (can you apply it now?). Discard anything scoring < 9 total.
4. **Knowledge Gap Detection** -- After searching, ask: "What do I still NOT know that could cause failure?" If gaps exist, check `Hippocampus/Evidence/` session logs or post a research task via `pulse_relay.py`.
5. **Apply and Record** -- Apply the mined knowledge to your task. After completion, save NEW knowledge back: `pulse_save.py --agent <you> --learnings "discovered: <insight>"`.

## Metrics & Thresholds

| Metric | Threshold | Action |
|--------|-----------|--------|
| Search strategies used | >= 2 of 3 | Single-query mining misses context |
| Relevance score cutoff | >= 9/15 | Below 9 = noise, discard it |
| Knowledge gaps identified | 0 before coding | Every gap is a potential regression |

## Good Example

```bash
# Step 1: Intent = "Need to know past issues with task claiming before modifying pulse_boot.py"
# Step 2: Multi-strategy search
python pulse/brain/brain_query.py --query "task claiming race condition"
python pulse/brain/brain_query.py --query "pulse_boot atomic operations"
# Step 3: Score results -- lesson about filelock (score: 14/15) > lesson about task_id field (11/15)
# Step 4: Gap -- no info on Windows-specific filelock behavior. Check Evidence/.
# Step 5: Apply filelock pattern, save new Windows insight.
```

## Anti-Patterns

- **Single-query mining** -- One query misses semantic neighbors. Always use at least 2 search strategies.
- **Ignoring low-relevance noise** -- Applying stale or tangential lessons wastes effort. Score and filter.
- **Mining without saving** -- You found something new but didn't write it back. The next agent loses it.

## Tools to Use

- `brain_query.py --query "<search term>"` -- Primary search tool (supports --file for bulk)
- `pulse_save.py --agent <you> --learnings "<new knowledge>"` -- Write back discoveries
- `pulse_relay.py --tasks "Research <gap>:general:fast"` -- Delegate gap-filling to another agent

## Verification Checklist

- [ ] Search intent stated before querying
- [ ] >= 2 search strategies used (exact + semantic or region scan)
- [ ] All results scored, noise below 9/15 discarded
- [ ] Knowledge gaps identified and resolved (or delegated)
- [ ] New knowledge saved back via `pulse_save.py`
