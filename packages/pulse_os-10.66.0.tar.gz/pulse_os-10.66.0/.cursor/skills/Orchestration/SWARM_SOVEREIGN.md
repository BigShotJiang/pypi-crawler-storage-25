---
type: skill
domain: orchestration
---

# SWARM_SOVEREIGN
> **ROLE:** Multi-agent task routing and coordination
> **TRIGGER:** When tasks need decomposition, delegation, or cross-agent coordination

## Core Directive
Route the right task to the right agent at the right tier. Prevent agent collisions on the same task, enforce atomic claiming, and ensure the task board stays clean and accurate.

## Step-by-Step Protocol
1. **Decompose the work:** Break multi-part requests into atomic tasks. Each task must be completable by ONE agent in ONE session. Use `python pulse/tasks/pulse_relay.py --tasks "Title:domain:complexity"` to post them.
   ```
   python pulse_relay.py --tasks "Add input validation to API:security:standard" "Write unit tests for validator:testing:fast" "Design auth flow:architecture:premium"
   ```
2. **Assign correct tiers:** Match task complexity to agent capability. `fast` = Haiku/Flash (docs, formatting, simple tests). `standard` = Sonnet/Gemini Pro (features, refactors). `premium` = Opus/GPT-4 (architecture, security audits). Never waste premium on a rename task.
3. **Check for collisions:** Before claiming, read `Prefrontal_Cortex/Action_Queue/task_board.json` and verify no other agent has `status: "in_progress"` on the target task. Use `atomic_update_json` (filelock) for claiming -- never raw read+write.
4. **Monitor completion:** After delegating, check the board periodically. Tasks stuck in `in_progress` for over 10 minutes with no file changes are likely stalled. Flag them for reassignment.
5. **Synthesize results:** When multiple agents complete related tasks, run `python pulse/daemons/synthesis/synthesize_plans.py` to merge findings. Save the synthesis to brain via `pulse_save.py`.

## Metrics & Thresholds
- Max 1 task claimed per agent at a time (ASOP Rule 2)
- Tasks must have: title, domain, complexity tier, and description
- Stale task threshold: 10 minutes with no file modification
- Max 5 tasks posted per relay call (prevents board flooding)
- Every completed task must call `pulse_save.py` with learnings

## Examples

### Good
```json
{
  "task_id": "T-20260215-001",
  "title": "Add rate limiting to pulse_api.py",
  "domain": "security",
  "recommended_tier": "standard",
  "status": "open",
  "description": "Add per-IP rate limiting (100 req/min) to all API endpoints"
}
```
Clear scope, correct tier, specific acceptance criteria.

### Bad (Anti-Pattern)
```json
{
  "task_id": "T-20260215-002",
  "title": "Fix everything in the API",
  "domain": "general",
  "recommended_tier": "fast",
  "status": "open",
  "description": "The API has issues"
}
```
Vague scope ("everything"), wrong tier (API redesign is not "fast"), no acceptance criteria. This task will be claimed and abandoned.

## Tools to Use
- `pulse_relay.py --tasks "Title:domain:tier"` -- post tasks to board
- `pulse_save.py --agent <you> --learnings "..."` -- save results and mark done
- `synthesize_plans.py` -- merge multi-agent outputs
- `brain_query.py --query "task <domain>"` -- check for prior work

## Verification
- [ ] Each task is atomic (one agent, one session)
- [ ] Tier matches complexity (no premium on formatting tasks)
- [ ] Task has title, domain, tier, and specific description
- [ ] Claiming uses atomic file locking
- [ ] Completed tasks saved learnings to brain
