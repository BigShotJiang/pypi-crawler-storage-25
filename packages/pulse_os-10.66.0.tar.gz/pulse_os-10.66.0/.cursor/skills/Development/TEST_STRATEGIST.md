---
type: skill
domain: development
---

# TEST_STRATEGIST
> **ROLE:** Test selection and coverage optimizer
> **TRIGGER:** Writing tests, reviewing test coverage, or validating changes

## Core Directive
Write the right tests at the right level. Not all code needs the same coverage. Critical paths get 100%, utilities get 80%, glue code gets smoke tests.

## Step-by-Step Protocol
1. **Classify the code:** Is it critical path (auth, payments, data integrity), business logic, or glue/utility?
2. **Choose test level:** Unit for pure functions, integration for component interactions, e2e for user flows.
3. **Write the test FIRST** (or immediately after): Name it `test_<what_it_verifies>`, not `test_function_name`.
4. **Assert behavior, not implementation:** Test what the function DOES, not HOW it does it. Mock external deps only.
5. **Run and verify:** `pytest --tb=short -q`. All green? Check coverage: `pytest --cov=module --cov-report=term-missing`.

## Metrics & Thresholds
- Test pyramid: 70% unit / 20% integration / 10% e2e
- Critical paths (auth, crypto, data writes): 100% branch coverage
- Business logic: 80% line coverage minimum
- Utility/glue code: smoke test (at least one happy path)
- Test execution time: unit <100ms each, integration <2s, e2e <30s
- Max test file length: 300 lines (split into focused test modules)

## Examples

### Good: Behavior-focused test
```python
def test_atomic_update_survives_concurrent_writes():
    """Verify data integrity under concurrent access."""
    results = []
    with ThreadPoolExecutor(max_workers=4) as pool:
        futures = [pool.submit(atomic_update, path, inc) for _ in range(4)]
        results = [f.result() for f in futures]
    assert load_json(path)["count"] == 4  # All writes persisted
```

### Bad: Implementation-coupled test
```python
def test_save():  # Vague name, tests implementation not behavior
    save(data)
    assert mock_file.write.called  # Testing HOW, not WHAT
    assert mock_file.write.call_args[0][0] == '{"key": "value"}'  # Brittle
```

## Anti-Patterns
- Testing private methods directly (test through public API)
- Mocking everything (if you mock the database, you're not testing the query)
- No assertions (a test that doesn't assert is not a test)
- Flaky tests: if it fails intermittently, fix the race condition, don't retry

## Tools to Use
- `brain_query.py --query "test patterns for <module>"` — Check existing patterns
- `pytest --tb=short -q` — Run tests with concise output
- `pytest --cov=<module> --cov-report=term-missing` — Coverage with uncovered lines

## Verification
- [ ] Tests named after behavior, not function names
- [ ] Critical paths have 100% branch coverage
- [ ] No test takes >2s (unit) or >30s (e2e)
- [ ] All tests pass: `pytest --tb=short -q`
