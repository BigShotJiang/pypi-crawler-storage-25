---
type: skill
domain: development
links: [Corpus_Callosum/CONSTITUTION.md, PULSE_OS.md]
---

# CI_CD_COMMANDER.md
> **ROLE:** RELEASE ENGINEER
> **TRIGGER:** "PIPELINE" / "DEPLOY" / "CI"

## Step-by-Step Protocol
1. **Audit current pipeline** — run `brain_query.py --query "CI/CD pipeline stages"`. Map every stage, its duration, and failure rate. Identify the slowest stage.
2. **Define pipeline stages** — enforce this order: (1) Lint + format check (<30s), (2) Type check (<60s), (3) Unit tests (<2min), (4) Integration tests (<3min), (5) Security scan (<2min), (6) Build artifact (<1min), (7) Deploy to staging, (8) Smoke test, (9) Deploy to production. Total: <5min for stages 1-6.
3. **Set build time budgets** — total CI <=5 minutes for PR checks. If exceeded: parallelize test suites, cache dependencies (`pip cache`, `node_modules` cache), use incremental builds. Alert if any single stage >2min.
4. **Configure rollback procedures** — every deploy creates a tagged artifact. Rollback = redeploy previous artifact (not revert commit). Rollback time target: <2 minutes. Automated rollback if health check fails 3x in 60 seconds.
5. **Wire post-deploy verification** — health endpoint returns `{"status": "ok", "version": "1.2.3"}`. Run `pulse_bridge.py` scan after successful deploy. Save deploy record with `pulse_save.py`.

## Metrics & Thresholds
- **Total CI time:** <5 minutes for PR checks (lint through build)
- **Deploy frequency:** >=1 per day (high-performing team benchmark)
- **Rollback time:** <2 minutes from decision to previous version running
- **Test pass rate on main:** >=99% (flaky test budget: <=1%)
- **Mean time to recovery (MTTR):** <30 minutes

## Good Example
```yaml
# .github/workflows/ci.yml — optimized pipeline
name: CI
on: [pull_request]
jobs:
  fast-checks:  # <90s total, parallelized
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with: { python-version: "3.11", cache: "pip" }
      - run: pip install -r requirements.txt
      - run: ruff check . --output-format=github    # lint <30s
      - run: mypy . --ignore-missing-imports         # type <60s
  tests:  # <3min total
    runs-on: ubuntu-latest
    needs: fast-checks
    steps:
      - uses: actions/checkout@v4
      - run: pytest tests/ -x --timeout=120 -q       # fail fast
  security:
    runs-on: ubuntu-latest
    needs: fast-checks
    steps:
      - run: pip-audit                                # <2min
```

## Anti-Patterns
1. **Sequential everything** — lint, type-check, and security scan are independent; run them in parallel.
2. **No dependency caching** — `pip install` from scratch on every run wastes 1-2 minutes; cache `~/.cache/pip`.
3. **Reverting commits as rollback** — creates merge conflicts and noise; deploy previous artifact instead.

## Tools to Use
- `python pulse/brain/brain_query.py --query "CI pipeline failures"` — check past pipeline issues
- `python pulse/tasks/pulse_relay.py --tasks "Pipeline Optimization:development:standard"` — delegate CI speedup
- `python pulse/brain/pulse_save.py --agent ci_commander --learnings "what you learned"` — record pipeline decisions

## Verification Checklist
- [ ] Total PR check time <5 minutes (measured, not estimated)
- [ ] Lint, type-check, and security scan run in parallel
- [ ] Rollback procedure documented and tested: <2min to previous version
- [ ] Flaky test rate <1% (quarantine or fix flaky tests immediately)
- [ ] Every deploy tagged with version, rollback artifact preserved
