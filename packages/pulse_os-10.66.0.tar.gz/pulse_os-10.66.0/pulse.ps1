param(
    [Parameter(ValueFromRemainingArguments = $true)]
    [string[]]$Args
)

# All commands go through pulse_cli.py — the single entry point.
# pulse_cli.py handles: status, post, start, stop, relay, workers,
# and agent autopilot (gemini, claude, codex, grok).
python "$PSScriptRoot\pulse_cli.py" @Args
exit $LASTEXITCODE
