# Rule Enforcement - Protocol
> **Context:** Tier 0 Constitutional Meta-Rules

## Mandate
No rule can be bypassed. No exceptions without explicit user approval.

---

## TIER 0: CONSTITUTIONAL META-RULES (Inviolable)

These rules govern how all other rules are enforced. They CANNOT be bypassed under any circumstances.

### Rule 0.1: No Bypass Without Approval
**Statement:** No rule shall be bypassed, modified, or ignored without explicit user approval.
**Severity:** CONSTITUTIONAL
**Rationale:** Eliminates agent discretion and prevents silent failures.
**Consequence:** Agent STOPS, reports violation, waits for approval, logs to `Neural_Logs/rule_violations.md`.

### Rule 0.2: Mandatory Rule Declaration
**Statement:** Every agent must declare which rules it's operating under before starting work.
**Severity:** CONSTITUTIONAL
**Rationale:** Transparency prevents excuses and establishes accountability.
**Consequence:** No work begins without the "Rule Reading Ceremony."

### Rule 0.3: Uncertainty = Ask
**Statement:** If uncertain about rule interpretation or applicability, ask user rather than guess.
**Severity:** CONSTITUTIONAL
**Rationale:** Forces explicit clarification in ambiguous scenarios.
**Consequence:** STOP and ask user before proceeding.

### Rule 0.4: Violation Logging
**Statement:** All rule violations (even minor) must be logged.
**Severity:** CONSTITUTIONAL
**Rationale:** Creates an audit trail for system health and evolution.
**Consequence:** Append incident to `Neural_Logs/rule_violations.md`.

---

## Violation Response Matrix

| Violation Type | Severity | Response |
|---|---|---|
| Using GPL in code | CRITICAL | STOP immediately, remove dependency, find MIT alternative |
| Language-specific hack | CRITICAL | STOP, find universal solution, ask approval |
| Skipped tests before commit | HIGH | STOP, run tests, ask if OK to proceed |
| Didn't propagate (Law 9) | HIGH | STOP, complete checklist, then proceed |
| Telegram import in core/ | CRITICAL | STOP, refactor to handlers/, ask approval |
| Missed rule declaration | MEDIUM | Log violation, show declaration now |
| Uncertainty about rule | N/A | STOP, ask user for clarification |
