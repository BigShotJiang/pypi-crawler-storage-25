# Rule Enforcement - Uncertainty Procedures
> **Context:** Rituals, Transparency & Anti-Patterns

---

## 🛠️ THE PRE-WORK RITUAL (REQUIRED)

Before starting ANY work, every agent MUST:
1. **Audit the System:** Verify core brain files using `_memory_manifest.md`.
2. **Synchronize Context:** Read `SESSION.md` for current state.
3. **Safety Check:** Read `history/FAILS/` to avoid repeats.
4. **Ceremony:** Declare 3-5 rules using the template below.

### Rule Reading Receipt Template
```
=== RULE READING CEREMONY ===
Agent: [Model Name]
Task: [Exact request]
Session Date: [YYYY-MM-DD]

Tier 0 (Meta-Rules): READ ✅
Tier 1 (Critical Laws): READ ✅

Task-Relevant Rules (For this work):
1. Law [X]: [Reason]
2. Law [Y]: [Reason]
3. ANTI_PATTERN [Z]: [Specific trap]

Ready to proceed under these rules. ✅
=== END CEREMONY ===
```

---

## AGENT TRANSPARENCY FORMAT (Mandatory)

Show this status block before execution:
```
[AGENT TYPE & TASK]
Agent: [Model]
User Task: [Description]
Session: [Date]

[RULES READ]
✅ Constitutional Rules (Tier 0)
✅ Critical Laws (Tier 1)

[PROCEEDING]
All rules understood. Starting work with rules in view.
```

---

## COMMON RULE-BYPASS PATTERNS (Anti-Patterns)

1. **"This is a quick fix":** Small changes DO need rule compliance (Law 9).
2. **"I assumed this was allowed":** Assumptions are violations. Ask (Rule 0.3).
3. **"The user implied approval":** Implied is not explicit. Ask (Rule 0.1).
4. **"This is too small to log":** Log everything (Rule 0.4).
5. **"I'll fix it later":** Technical debt accumulates. Fix now.

---

## WHAT OPUS MIGHT HAVE MISSED (Blind Spots)
- **Law 9 Propagation:** Completing 1-2 items and skipping the rest.
- **Rule 0.3 Uncertainty:** Making best guesses instead of asking user.
- **Law 2 Universality:** Validating against test cases instead of principles.
- **Commit Approval:** Interpreting "ready" as permission to commit.
