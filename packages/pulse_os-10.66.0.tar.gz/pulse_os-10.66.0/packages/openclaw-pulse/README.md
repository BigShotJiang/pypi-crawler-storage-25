# @pulse-os/openclaw-memory

PULSE persistent memory plugin for [OpenClaw](https://openclaw.ai). Your agent learns from every session and never forgets.

## What it does

- **Auto-recall**: Before each turn, PULSE injects relevant brain context (lessons, failures, anti-patterns, predictions) into the agent's system prompt
- **Auto-capture**: After each turn, PULSE extracts knowledge from the conversation and stores it in the brain
- **12-source search**: Queries lessons, failures, patterns, predictions, anti-patterns, evidence, domains, schemas, procedures, knowledge graph, and more
- **Cross-agent memory**: Claude, Gemini, Copilot, Codex, and OpenClaw all share the same brain

## Install

```bash
# 1. Install PULSE (Python)
pip install pulse-os

# 2. Install the OpenClaw plugin
openclaw plugins install @pulse-os/openclaw-memory
```

## Configure

In your `openclaw.json`:

```json
{
  "plugins": {
    "slots": {
      "memory": "memory-pulse"
    },
    "entries": {
      "memory-pulse": {
        "enabled": true,
        "config": {
          "autoRecall": true,
          "autoCapture": true,
          "maxResults": 10,
          "maxContextTokens": 2000
        }
      }
    }
  }
}
```

## Tools

| Tool | Description |
|------|-------------|
| `memory_search` | Search the brain for relevant memories |
| `memory_store` | Save a lesson or failure to persistent memory |
| `memory_get` | Read a specific brain region (lessons, failures, patterns, anti_patterns) |

## CLI

```bash
openclaw pulse status          # Check brain connection
openclaw pulse search "auth"   # Search brain
openclaw pulse stats           # Show brain statistics
```

## How it works

1. **Session start**: Plugin checks if PULSE API is running, auto-starts it if needed
2. **Before each turn**: Searches brain with conversation context, injects relevant knowledge
3. **Agent responds**: Has access to `memory_search`, `memory_store`, `memory_get` tools
4. **After each turn**: Captures the exchange, extracts wants/lessons/failures, routes to brain
5. **Background**: PULSE consolidation daemon deduplicates, mines patterns, promotes schemas every 6h

## Config options

| Option | Default | Description |
|--------|---------|-------------|
| `baseUrl` | `http://127.0.0.1:8000` | PULSE API endpoint |
| `autoRecall` | `true` | Inject brain context before each turn |
| `autoCapture` | `true` | Extract knowledge after each turn |
| `maxResults` | `10` | Max brain search results |
| `maxContextTokens` | `2000` | Max tokens for context injection |

## Requirements

- Python 3.10+
- `pip install pulse-os`
- OpenClaw >= 2026.2.3

## License

AGPL-3.0
