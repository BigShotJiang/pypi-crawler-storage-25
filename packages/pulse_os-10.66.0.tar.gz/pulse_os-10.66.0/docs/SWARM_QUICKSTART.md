# PULSE Swarm Quickstart

## What is PULSE?
PULSE is an AI operating system that coordinates multiple AI agents to work together. It acts as a "brain" that orchestrates specialized agents (like Claude, Gemini, GPT-4) to execute complex tasks autonomously, using a shared memory and constitutional governance system.

## Installation
```bash
git clone https://github.com/Honesty0x/PULSE.git
cd PULSE
pip install -r requirements.txt
copy .env.example .env
# Edit .env with your API keys
```

## Three Ways to Use Agents



### 1. Swarm Mode (Default)

The agent loops continuously: checks the task board, claims a task, executes it, and repeats.

```bash

python pulse_cli.py gemini

```



### 2. Interactive Mode

Talk to a single agent directly via chat. Good for quick questions or debugging.

```bash

python pulse_cli.py gemini --chat

```



### 3. API Workers (Headless Swarm)


Start multiple background daemons that poll for work. Best for high-throughput parallel processing.
```bash
python pulse_cli.py workers start 2 --provider google --model gemini-2.5-flash --tier fast
```

## How to Post Tasks
Add work to the shared task board. Agents will pick it up based on their capabilities and tier.
```bash
python pulse_cli.py post "Fix login bug:security:fast"
```

## Tier System
Assign tasks to the right level of intelligence to save costs.
*   **fast**: Simple tasks (docs, renames, formatting). Cheap models (Haiku, Flash).
*   **standard**: Features, refactoring, testing. Balanced models (Sonnet, GPT-4o).
*   **premium**: Architecture, security audits, complex reasoning. Smartest models (Opus, GPT-4, Gemini Pro).

Agents only grab tasks that match their tier.

## Example Workflow
1.  **Post tasks:**
    ```bash
    python pulse_cli.py post "Write README.md:docs:fast"
    python pulse_cli.py post "Refactor auth.py:code:standard"
    python pulse_cli.py post "Audit security protocols:security:premium"
    ```
2.  **Start agents:** Open two terminals and run:
    ```bash
    python pulse_cli.py gemini
    ```

3.  **Watch them work:** The agents will claim the tasks, execute them, and save the results.

## Check Status
See what the swarm is doing in real-time.
```bash
python pulse_cli.py status
```
