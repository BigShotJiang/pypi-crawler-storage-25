# PULSE Model Guide: Choosing Your Fleet

PULSE is model-agnostic. You can mix and match models from different providers (Anthropic, Google, OpenAI, Ollama) to balance intelligence vs. cost.

## The Tier System

PULSE organizes tasks into three tiers. Workers only pick up tasks that match their tier (or simpler ones).

### 1. Premium Tier (The Architects)
*   **Role:** Complex reasoning, architecture design, security audits, difficult debugging.
*   **Models:**
    *   Claude Opus 4.6
    *   Gemini 2.5 Pro / 3 Pro
    *   GPT-4o / O3
    *   Grok 4
*   **Cost:** High ($15-30/M tokens). Use sparingly (20% of tasks).

### 2. Standard Tier (The Engineers)
*   **Role:** Feature implementation, refactoring, writing tests, standard logic.
*   **Models:**
    *   Claude Sonnet 4.5
    *   GPT-4o
    *   Gemini 2.5 Flash / 3 Flash
    *   DeepSeek R1
*   **Cost:** Moderate ($3-10/M tokens). The workhorses (60% of tasks).

### 3. Fast Tier (The Interns)
*   **Role:** Documentation, formatting, bulk renaming, simple scripts.
*   **Models:**
    *   Claude Haiku 4.5
    *   Gemini 3 Flash
    *   GPT-4o-mini
    *   Gemini 2.5 Flash-Lite
*   **Cost:** Very Low ($0.1-0.5/M tokens). Use for volume (20% of tasks).

### 4. Local / Free (Self-Hosted)
*   **Role:** Privacy-critical or offline work.
*   **Models (via Ollama):**
    *   Llama 3.3 70B (Premium-ish)
    *   Qwen 2.5 32B (Standard)
    *   Mistral 7B (Fast)

---

## Recommended Fleet Compositions

### 1. The "Google Budget" Fleet ($5-20/mo)
Best for developers on a budget. Google's Flash models are extremely cheap and fast.
*   **Premium:** Gemini 2.5 Pro (API)
*   **Standard:** Gemini 3 Flash (API)
*   **Fast:** Gemini 2.5 Flash-Lite (API)
*   **Command:**
    ```bash
    python pulse_cli.py workers start 2 --provider google --model gemini-3-flash --tier standard
    python pulse_cli.py workers start 2 --provider google --model gemini-2.5-flash-lite --tier fast
    ```

### 2. The "Balanced" Fleet ($20-80/mo)
Best performance/cost ratio.
*   **Premium:** Claude Sonnet 4.5 (often smart enough for premium)
*   **Standard:** GPT-4o
*   **Fast:** Gemini 3 Flash
*   **Command:**
    ```bash
    python pulse_cli.py workers start 1 --provider anthropic --model claude-sonnet-4-5-20250929 --tier premium
    python pulse_cli.py workers start 2 --provider openai --model gpt-4o --tier standard
    ```

### 3. The "Power" Fleet ($100-500/mo)
For serious enterprise refactoring.
*   **Premium:** Claude Opus 4.6 + O3
*   **Standard:** Claude Sonnet 4.5
*   **Fast:** Claude Haiku 4.5
*   **Command:**
    ```bash
    python pulse_cli.py workers start 2 --provider anthropic --model claude-opus-4-6 --tier premium
    python pulse_cli.py workers start 4 --provider anthropic --model claude-sonnet-4-5-20250929 --tier standard
    ```

### 4. The "Local" Fleet ($0)
Requires a beefy GPU (24GB+ VRAM recommended).
*   **Command:**
    ```bash
    python pulse_cli.py workers start 1 --provider ollama --model llama3.3:70b --tier premium
    python pulse_cli.py workers start 2 --provider ollama --model qwen2.5:32b --tier standard
    ```

---

## 📉 The Pareto's Law Breakdown (80/20 Rule)
To get maximum efficiency, do not use the Premium models for everything. Apply the 80/20 rule to your token usage:

### The 20% of Tasks (Use Premium Models)
*   **Tasks:** Setting up the project skeleton, writing the core business logic, debugging that one error that has kept you awake for 4 hours, and security audits.
*   **Strategy:** These tasks create 80% of the value. Use **Claude 3.7** or **Gemini 3 Pro**. Do not scrimp here. The cost of a Premium inference ($0.03) is infinitely cheaper than refactoring bad architecture later.

### The 80% of Tasks (Use Standard/Fast Models)
*   **Tasks:** Writing unit tests, generating JSDoc/Docstrings, converting JSON to TypeScript interfaces, CSS adjustments, writing SQL migrations.
*   **Strategy:** These tasks are repetitive and high-volume. Use **Gemini 3 Flash** or **DeepSeek V3** here.

### 💡 Pro Move: The Handoff
Use a **Premium** model to write the plan or the interface (schema/types), then pass that plan to a **Fast** model (like Flash) and say *"Implement this exactly as described."*

Assign tasks correctly in the CLI:
```bash
python pulse_cli.py post "Fix typo in README:docs:fast"
python pulse_cli.py post "Redesign auth system:architecture:premium"
```
