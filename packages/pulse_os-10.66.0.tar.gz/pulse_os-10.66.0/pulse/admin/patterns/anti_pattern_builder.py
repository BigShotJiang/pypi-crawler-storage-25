#!/usr/bin/env python3
# Copyright (c) 2026 PULSE Contributors. Proprietary. All rights reserved.
# See LICENSE file for details.
"""
Anti-Pattern Builder: Convert DON'T_WANTS into anti-patterns (V43.13)

Flow: DON'T_WANTS evidence -> Check threshold (>=2 similar) -> Build anti-pattern
      -> Store in active registry -> Update ANTI_PATTERNS.md -> Alert agents
"""

import json
import logging
import sys
from datetime import datetime, timezone
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
ROOT_DIR = SCRIPT_DIR.parent.parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from pulse.core.brain_utils import (
    ANTI_PATTERNS_DIR,
    EVIDENCE_DIR,
    FAILS_JSONL,
    GROWTH_METRICS,
    HIPPOCAMPUS_DIR,
    INTENTS_DIR,
    load_config,
    load_json,
    load_json_dict,
    read_jsonl_entries,
    save_json,
)
from pulse.admin.patterns.anti_pattern_similarity import (
    check_against_anti_patterns,
    cluster_dont_wants,
)

log = logging.getLogger("anti_pattern_builder")

DONT_WANTS_FILE = INTENTS_DIR / "dont_wants.json"
ACTIVE_ANTI_PATTERNS = ANTI_PATTERNS_DIR / "anti_patterns_active.json"

MIN_DONT_WANTS = 2

def build_anti_patterns() -> dict:
    """
    Scan DON'T_WANTS evidence, find clusters, build anti-patterns.

    Returns dict with new anti-patterns created and stats.
    """
    from pulse.core.brain_db import get_dont_wants, get_active_anti_patterns
    dont_wants = get_dont_wants()
    existing = get_active_anti_patterns()
    existing_descriptions = {ap.get("description", "").lower() for ap in existing}

    results = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "dont_wants_scanned": len(dont_wants),
        "clusters_found": 0,
        "new_anti_patterns": 0,
        "anti_patterns": [],
    }

    if len(dont_wants) < MIN_DONT_WANTS:
        log.info("Not enough DON'T_WANTS (%d < %d)", len(dont_wants), MIN_DONT_WANTS)
        return results

    clusters = cluster_dont_wants(dont_wants)
    results["clusters_found"] = len(clusters)

    for cluster in clusters:
        if len(cluster) < MIN_DONT_WANTS:
            continue

        anti_pattern = _synthesize_anti_pattern(cluster)

        if anti_pattern["description"].lower() in existing_descriptions:
            continue

        existing.append(anti_pattern)
        results["new_anti_patterns"] += 1
        results["anti_patterns"].append(anti_pattern["description"])
        log.info("New anti-pattern: %s (from %d DON'T_WANTS)",
                 anti_pattern["description"], len(cluster))

    if results["new_anti_patterns"] > 0:
        # P47: SQLite-first write
        try:
            from pulse.brain.sqlite_writers import upsert_anti_pattern
            for ap in existing:
                if isinstance(ap, dict) and ap.get('description'):
                    upsert_anti_pattern(
                        description=ap['description'], rule=ap.get('rule', ''),
                        reason=ap.get('reason', ''), domain=ap.get('domain', 'general'),
                        severity=ap.get('severity', 'medium'), source='anti_pattern_builder',
                        evidence_count=ap.get('evidence_count', 1), keywords=ap.get('keywords', []))
        except Exception as e:
            log.warning("SQLite anti-pattern upsert failed: %s", e)
        _update_growth_metrics(results)
        log.info("Total active anti-patterns: %d", len(existing))

    return results

def _synthesize_anti_pattern(cluster: list) -> dict:
    """Synthesize a cluster of DON'T_WANTS into a formal anti-pattern."""
    now = datetime.now(timezone.utc).isoformat()

    descriptions = [dw.get("dont_want", "") for dw in cluster]
    reasons = [dw.get("reason", "") for dw in cluster]
    domains = [dw.get("domain", "general") for dw in cluster]

    domain_counts = {}
    for d in domains:
        domain_counts[d] = domain_counts.get(d, 0) + 1
    primary_domain = max(domain_counts, key=domain_counts.get)

    all_words = []
    for desc in descriptions:
        all_words.extend(desc.lower().split())
    word_counts = {}
    for w in all_words:
        if len(w) > 3:
            word_counts[w] = word_counts.get(w, 0) + 1
    keywords = [w for w, c in sorted(word_counts.items(),
                key=lambda x: -x[1]) if c >= 2][:5]

    description = max(descriptions, key=len) if descriptions else "unknown"

    return {
        "id": f"AP-{now[:10].replace('-', '')}-{len(descriptions):03d}",
        "description": description,
        "reason": reasons[0] if reasons else "accumulated user rejections",
        "evidence_count": len(cluster),
        "domain": primary_domain,
        "keywords": keywords,
        "severity": "high" if len(cluster) >= 4 else "medium",
        "status": "active",
        "created": now,
        "source_dont_wants": len(cluster),
        "rule": f"NEVER: {description}",
    }

def _update_growth_metrics(results: dict):
    """Update growth metrics with anti-pattern build stats (SQLite)."""
    try:
        from pulse.core.brain_db import get_conn
        from pulse.core.brain_utils import now_iso
        conn = get_conn()
        ts = now_iso()
        with conn:
            mapping = {
                "total_scans": 1,
                "total_anti_patterns_created": results.get("new_anti_patterns", 0),
            }
            for name, val in mapping.items():
                conn.execute("""
                    INSERT INTO growth_metrics (category, metric_name, value, last_updated)
                    VALUES ('anti_pattern_builder', ?, ?, ?)
                    ON CONFLICT(category, metric_name) DO UPDATE SET
                    value = value + EXCLUDED.value,
                    last_updated = EXCLUDED.last_updated
                """, (name, float(val), ts))
            conn.execute("""
                INSERT INTO growth_metrics (category, metric_name, value, last_updated)
                VALUES ('anti_pattern_builder', 'last_scan', 1.0, ?)
                ON CONFLICT(category, metric_name) DO UPDATE SET
                last_updated = EXCLUDED.last_updated
            """, (ts,))
    except Exception as e:
        log.debug("Failed to update anti-pattern growth metrics in SQLite: %s", e)

def promote_repeated_failures(min_occurrences=3) -> dict:
    """Promote repeated failures (3+ identical) to anti-patterns automatically."""
    # Read failures from SQLite (authoritative), fall back to JSONL
    try:
        from pulse.core.brain_db import get_conn
        conn = get_conn()
        entries = [dict(r) for r in conn.execute(
            "SELECT content, title, confidence FROM failures ORDER BY rowid DESC"
        ).fetchall()]
    except Exception:
        entries = read_jsonl_entries(FAILS_JSONL)
    if not entries:
        return {"promoted": 0, "reason": "no failures"}

    # Read existing anti-patterns from SQLite, fall back to JSON
    try:
        from pulse.core.brain_db import get_active_anti_patterns
        existing = get_active_anti_patterns()
    except Exception:
        existing = load_json(ACTIVE_ANTI_PATTERNS)
    existing_descriptions = {ap.get("description", "").lower() for ap in existing}

    fail_counts: dict[str, int] = {}
    for entry in entries:
        desc = (entry.get("title", "") or entry.get("content", "")).strip().lower()
        if len(desc) > 10:
            fail_counts[desc] = fail_counts.get(desc, 0) + 1

    promoted = 0
    now = datetime.now(timezone.utc).isoformat()
    for desc, count in fail_counts.items():
        if count < min_occurrences:
            continue
        if desc in existing_descriptions:
            continue
        anti_pattern = {
            "id": f"AP-FAIL-{now[:10].replace('-', '')}-{promoted:03d}",
            "description": desc,
            "reason": f"repeated failure ({count} occurrences)",
            "evidence_count": count,
            "domain": "general",
            "keywords": [w for w in desc.split() if len(w) > 4][:5],
            "severity": "high" if count >= 5 else "medium",
            "status": "active",
            "created": now,
            "source_dont_wants": 0,
            "source_failures": count,
            "rule": f"NEVER: {desc}",
        }
        existing.append(anti_pattern)
        existing_descriptions.add(desc)
        promoted += 1
        log.info("Failure->anti-pattern: %s (%dx)", desc[:60], count)

    if promoted > 0:
        # P47: SQLite-first write
        try:
            from pulse.brain.sqlite_writers import upsert_anti_pattern
            for ap in existing:
                if isinstance(ap, dict) and ap.get('description'):
                    upsert_anti_pattern(
                        description=ap['description'], rule=ap.get('rule', ''),
                        reason=ap.get('reason', ''), domain=ap.get('domain', 'general'),
                        severity=ap.get('severity', 'medium'), source='anti_pattern_builder',
                        evidence_count=ap.get('evidence_count', 1), keywords=ap.get('keywords', []))
        except Exception as e:
            log.warning("SQLite anti-pattern upsert failed: %s", e)

    return {"promoted": promoted, "failures_scanned": len(fail_counts)}

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--check":
        # Check a proposed action against anti-patterns
        if len(sys.argv) < 3:
            print("Usage: python anti_pattern_builder.py --check <proposed_action>")
            raise SystemExit(1)
        matches = check_against_anti_patterns(sys.argv[2])
        print(json.dumps(matches, indent=2))
    else:
        # Build anti-patterns from accumulated DON'T_WANTS
        result = build_anti_patterns()
        print(json.dumps(result, indent=2))
