"""Admin tools: audit, benchmark, cleanup, validation."""
