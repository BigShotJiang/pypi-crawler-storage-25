#!/usr/bin/env python3
"""One-shot script: clean garbage entries from wants.json and dont_wants.json."""
import json
from pathlib import Path

WANTS = Path("Hippocampus/Intents/wants.json")
DW = Path("Hippocampus/Intents/dont_wants.json")


def clean_list(filepath, key):
    data = json.loads(filepath.read_text(encoding="utf-8"))
    before = len(data)
    clean = []
    for item in data:
        text = item.get(key, "")
        words = text.split()
        if len(words) >= 3 and len(text) >= 10:
            clean.append(item)
    filepath.write_text(json.dumps(clean, indent=2), encoding="utf-8")
    after = len(clean)
    print(f"{filepath.name}: {before} -> {after} (removed {before - after} garbage)")


if __name__ == "__main__":
    clean_list(WANTS, "want")
    clean_list(DW, "dont_want")
