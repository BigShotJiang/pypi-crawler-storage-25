#!/usr/bin/env python3
# Copyright (c) 2026 PULSE Contributors. Proprietary. All rights reserved.
"""Benchmark Synthesizer CLI entry point and batch synthesis.

Split from benchmark_synthesizer.py for Law 7 compliance.
"""
from __future__ import annotations

import sys

from pulse.admin.benchmarks.benchmark_synthesizer import (
    load_benchmarks, find_completed_benchmarks,
)
from pulse.admin.benchmarks.benchmark_synthesizer_ops import synthesize_benchmark


def synthesize_all(dry_run: bool = False) -> list:
    """Synthesize all completed benchmarks."""
    data = load_benchmarks()
    completed = find_completed_benchmarks(data)
    if not completed:
        print("  No un-synthesized benchmarks found.")
        return []
    reports = []
    for bm in completed:
        report = synthesize_benchmark(bm, data, dry_run)
        reports.append(report)
    summary = {
        "total": len(reports),
        "achieved": sum(1 for r in reports if r["result"] == "achieved"),
        "failed": sum(1 for r in reports if r["result"] == "failed")
    }
    print(f"\n  Summary: {summary['total']} synthesized "
          f"({summary['achieved']} wins, {summary['failed']} fails)")
    return reports


def main():
    dry_run = "--dry-run" in sys.argv
    print("=== Benchmark Synthesizer V43.12 ===")
    if "--synthesize-all" in sys.argv:
        synthesize_all(dry_run)
        return
    if "--synthesize" in sys.argv:
        from pulse.admin.benchmarks.benchmark_synthesizer_ops import synthesize_one
        idx = sys.argv.index("--synthesize")
        bm_id = sys.argv[idx + 1] if idx + 1 < len(sys.argv) else ""
        synthesize_one(bm_id, dry_run)
        return
    print("  Usage: --synthesize-all | --synthesize BM-XXX [--dry-run]")


if __name__ == "__main__":
    main()
