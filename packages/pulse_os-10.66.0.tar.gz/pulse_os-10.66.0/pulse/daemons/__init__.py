"""Long-running daemons: orchestrator, bridge, neural, consolidation."""
