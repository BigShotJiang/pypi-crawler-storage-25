#!/usr/bin/env python3
# Copyright (c) 2026 PULSE Contributors. Proprietary.
"""Reflex extractor: real-time mistake detection via reflex arc patterns."""
import logging

from pulse.daemons.distiller.extractors.base import BaseExtractor

log = logging.getLogger('pulse.distiller.reflex')


class ReflexExtractor(BaseExtractor):
    """Calls check_reflex() which writes to anti_patterns + hot_cache automatically."""

    def __init__(self):
        super().__init__('reflex', 'anti_patterns')

    def extract(self, user_text: str, agent_text: str, metadata: dict) -> list:
        """Run reflex arc detection. Side-effects handle persistence directly."""
        source = metadata.get('source', 'distiller')
        try:
            from pulse.daemons.bridge.reflex_arc import check_reflex
            count = check_reflex(user_text, agent_text, source)
            self.extracted_count += count
        except Exception as exc:
            log.debug('check_reflex failed: %s', exc)
        # reflex_arc handles its own writes; return empty so write() is a no-op
        return []

    def write(self, items: list) -> int:
        """No-op: reflex_arc persists directly inside check_reflex()."""
        return 0
