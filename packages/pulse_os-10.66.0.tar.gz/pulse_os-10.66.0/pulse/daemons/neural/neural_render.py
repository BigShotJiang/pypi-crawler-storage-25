#!/usr/bin/env python3
import logging
# Copyright (c) 2026 PULSE Contributors. Proprietary. All rights reserved.
"""
Neural Render: State rendering and summarization for ACTIVE_NEURAL_STATE.md.

Extracted from pulse_neural.py per Law 7 (files <= 300 lines).

Functions:
  - _compress_learnings: Weight and select top learning summaries
  - _summarize_strategy: Load top strategic intents
  - _summarize_tasks: Read task board summary
  - _render_state: Build full neural state markdown content

Dependencies: Python stdlib + brain_utils (internal)
"""
import math
import sys
from datetime import datetime, timezone
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
ROOT_DIR = SCRIPT_DIR.parent.parent.parent

from pulse.core.brain_utils import load_json_dict, TASK_BOARD_FILE, HIPPOCAMPUS_DIR, now_iso as _now_iso

from pulse.core.brain_utils import (
    LESSONS_JSONL, FAILS_JSONL, PATTERNS_JSONL, read_jsonl_entries,
    _extract_jsonl_titles as extract_jsonl_titles,
)

LEARNING_JSONL_FILES = [LESSONS_JSONL, PATTERNS_JSONL, FAILS_JSONL]

STRATEGIC_INTENTS_FILE = HIPPOCAMPUS_DIR / "Intents" / "strategic_intents.json"


def _truncate(s: str, n: int = 140) -> str:
    s = " ".join(s.split())
    return s if len(s) <= n else s[: n - 3] + "..."



def _compress_learnings() -> list[str]:
    """Weight and select top learning summaries using shared JSONL loader."""
    entries = []
    for jsonl_path in LEARNING_JSONL_FILES:
        source_name = jsonl_path.stem.replace("auto_", "")
        for item in extract_jsonl_titles(jsonl_path, max_chars=120, min_chars=10):
            conf = item["confidence"]
            ev = item["evidence_count"]
            weight = max(0.5, conf) + min(1.0, ev / 10.0)
            weight = min(weight, 1.5)
            entries.append({"label": f"{source_name}: {item['title']}", "weight": weight})
    if not entries:
        return []
    entries.sort(key=lambda e: e["weight"], reverse=True)
    limit = min(20, max(1, math.ceil(len(entries) * 0.2)))
    selected = entries[:limit]
    return [_truncate(item["label"]) for item in selected]


def _summarize_strategy() -> list[str]:
    """Load top strategic intents for neural state."""
    data = load_json_dict(STRATEGIC_INTENTS_FILE)
    intents = data.get("intents", [])
    if not intents:
        return []
    lines = []
    for intent in intents[:5]:
        status = intent.get("status", "")
        text = intent.get("text", intent.get("title", "?"))
        lines.append(f"[{status}] {text[:100]}")
    return lines


def _summarize_tasks(max_lines: int = 10) -> list[str]:
    """Read task board and return summary lines for neural state.

    Capped at *max_lines* to prevent boot-context token bloat (QR14-P21).
    """
    board = load_json_dict(TASK_BOARD_FILE)
    dispatches = board.get("dispatches", [])
    if not dispatches:
        return []

    active: list[str] = []
    open_count = 0
    for dispatch in dispatches:
        for t in dispatch.get("tasks", []):
            status = t.get("status", "?")
            if status in ("done", "failed"):
                continue
            # Prioritize active/claimed tasks over open backlog
            claimed = t.get("claimed_by") or ""
            suffix = f" ({claimed})" if claimed else ""
            line = f"[{status}] {t.get('title', '?')}{suffix}"
            if status == "active":
                active.insert(0, line)  # active first
            else:
                open_count += 1
                if len(active) < max_lines:
                    active.append(line)

    if open_count > max_lines:
        active = active[:max_lines]
        active.append(f"... and {open_count - max_lines} more open tasks")
    return active


def _render_state(query: str, rec: dict, donts: list, learning_summaries: list[str]) -> str:
    updated = _now_iso()

    goals = []
    if query:
        goals.append(_truncate(query))
    while len(goals) < 3:
        goals.append("EMPTY")

    risks = []
    for w in rec.get("warnings", [])[:3]:
        title = w.get("title") or w.get("text") or "risk"
        risks.append(_truncate(title))
    while len(risks) < 3:
        risks.append("EMPTY")

    actions = []
    approach = rec.get("approach") or {}
    if approach.get("summary"):
        actions.append(_truncate(approach["summary"]))
    while len(actions) < 3:
        actions.append("EMPTY")

    dont_do = []
    for d in donts:
        dont_do.append(_truncate(d))
    while len(dont_do) < 3:
        dont_do.append("EMPTY")

    confidence = rec.get("confidence", 0.1)
    conf_line = f"{confidence} | based on wins/fails/evidence"
    state_line = "constraints: none"

    lines = []
    lines.append("# ACTIVE_NEURAL_STATE")
    lines.append(f"Updated: {updated}")
    lines.append(f"Query: {query or 'EMPTY'}")
    lines.append("")
    lines.append("TOP_GOALS:")
    lines.extend([f"- {g}" for g in goals])
    lines.append("")
    lines.append("RISKS:")
    lines.extend([f"- {r}" for r in risks])
    lines.append("")
    lines.append("NEXT_ACTIONS:")
    lines.extend([f"- {a}" for a in actions])
    lines.append("")
    lines.append("DONT_DO:")
    lines.extend([f"- {d}" for d in dont_do])
    lines.append("")
    lines.append(f"CONFIDENCE: {conf_line}")
    lines.append(f"STATE: {state_line}")
    lines.append("")
    lines.append("COMPRESSED_LEARNINGS:")
    for learning in learning_summaries:
        lines.append(f"- {learning}")
    if not learning_summaries:
        lines.append("- none")
    lines.append("")
    # Strategic Intents (from Plans Digestion)
    strategy_lines = _summarize_strategy()
    lines.append("STRATEGIC_INTENTS:")
    if strategy_lines:
        for sl in strategy_lines:
            lines.append(f"- {sl}")
    else:
        lines.append("- none (run synthesize_plans.py)")
    lines.append("")

    # ASOP Task Board
    task_lines = _summarize_tasks()
    lines.append("CURRENT_TASKS:")
    if task_lines:
        for tl in task_lines:
            lines.append(f"- {tl}")
    else:
        lines.append("- none")
    lines.append("")

    lines.append("SOURCE_EVIDENCE:")
    lines.append("- Hippocampus/Evidence/Sessions/current_session.json")
    lines.append("- Hippocampus/Anti_Patterns/anti_patterns_active.json")
    lines.append("- Hippocampus/Failures/auto_fails.jsonl")
    lines.append("")

    return "\n".join(lines)