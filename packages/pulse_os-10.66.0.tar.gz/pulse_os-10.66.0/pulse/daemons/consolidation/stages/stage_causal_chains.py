#!/usr/bin/env python3
# Copyright (c) 2026 PULSE Contributors. Proprietary. All rights reserved.
"""Stage: Causal Chains — extracts sequential event dependencies from sessions."""
import json
import logging
from pulse.core.brain_db import get_conn
from pulse.graph.causal_model import add_causal_edge

log = logging.getLogger("pulse.daemons.consolidation.stages.stage_causal_chains")

def stage_causal_chains(verbose: bool = False) -> dict:
    """Extracts CAUSES edges from sequential session turns."""
    conn = get_conn()
    # Get last 100 turns from completed sessions
    query = """
        SELECT t.id, t.session_id, t.domain, t.content 
        FROM session_turns t
        JOIN sessions s ON t.session_id = s.id
        WHERE s.status = 'completed'
        ORDER BY t.session_id, t.turn_index ASC
        LIMIT 100
    """
    rows = conn.execute(query).fetchall()
    
    chains_created = 0
    if len(rows) < 2:
        return {"status": "skipped", "reason": "not enough turns"}

    for i in range(len(rows) - 1):
        t1, t2 = rows[i], rows[i+1]
        if t1["session_id"] != t2["session_id"]:
            continue
        
        # Simple event label: domain or first 3 words
        label1 = t1["domain"] if t1["domain"] != "general" else " ".join(t1["content"].split()[:3])
        label2 = t2["domain"] if t2["domain"] != "general" else " ".join(t2["content"].split()[:3])
        
        if label1 and label2 and label1 != label2:
            try:
                add_causal_edge(label1.lower(), label2.lower(), 0.6)
                chains_created += 1
            except Exception: pass

    return {"status": "ok", "chains_created": chains_created}
