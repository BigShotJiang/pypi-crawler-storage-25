import logging
#!/usr/bin/env python3
# Copyright (c) 2026 PULSE Contributors. Proprietary. All rights reserved.
"""
Consolidation Mining: Sequence extraction and cross-session pattern discovery.

Extracted from consolidation_helpers.py per Law 7 (files <= 300 lines).
Dependencies: Python stdlib + brain_utils (internal)
"""
import re
import sys
from collections import Counter
from pulse.brain.extraction.wants_classify import _classify_domain
from datetime import datetime, timezone, timedelta
from pathlib import Path


from pulse.core.brain_utils import (
    HIPPOCAMPUS_DIR, PATTERNS_DIR, LESSONS_DIR,
    LESSONS_JSONL, PATTERNS_JSONL,
    load_json, text_similarity, load_json_dict,
    read_jsonl_entries, now_iso as _now_iso,
)

_log = logging.getLogger("consolidation_mining")

SESSIONS_FILE = HIPPOCAMPUS_DIR / "Evidence" / "Sessions" / "agent_sessions.json"
PATTERNS_FILE = PATTERNS_DIR / "auto_patterns.md"  # Legacy ref for _FILE_JSONL_MAP keys
LESSONS_FILE = LESSONS_DIR / "auto_lessons.md"    # Legacy ref for _FILE_JSONL_MAP keys


def extract_event_sequences(days=7, verbose=False):
    """Find recurring event sequences from agent sessions over past N days.

    Extracts bigrams of (domain, outcome) pairs from agent sessions.
    Sequences appearing 3+ times are considered procedural patterns.
    """
    cutoff = datetime.now(timezone.utc) - timedelta(days=days)
    sessions = load_json(SESSIONS_FILE)
    if not isinstance(sessions, list):
        return []

    recent = []
    for s in sessions:
        ts = s.get("timestamp", "")
        if ts:
            try:
                t = datetime.fromisoformat(ts.replace("Z", "+00:00"))
                if t >= cutoff:
                    recent.append(s)
            except (ValueError, TypeError):
                recent.append(s)

    if verbose:
        print(f"  [MINING] {len(recent)} sessions in last {days} days")

    event_tags = []
    for s in recent:
        agent = s.get("agent", "unknown")
        has_failures = bool(s.get("failures"))
        files = s.get("files_touched", [])
        # Classify domain using full classifier instead of 3-domain heuristic
        file_context = " ".join(files) if files else ""
        learnings = " ".join(str(l) for l in s.get("learnings", [])[:3])
        domain = _classify_domain(f"{file_context} {learnings}".strip()) if (file_context or learnings) else "general"
        event_tags.append(f"{agent}:{domain}:{'fail' if has_failures else 'ok'}")

    # Track n-grams for chain lengths 2-5 (U10: Dr. STDP)
    all_ngrams = Counter()
    for n in range(2, 6):
        for i in range(len(event_tags) - n + 1):
            chain = " -> ".join(event_tags[i:i + n])
            all_ngrams[chain] += 1

    sequences = []
    for seq, count in all_ngrams.most_common(30):
        if count >= 3:
            steps = seq.count(" -> ") + 1
            ok_steps = seq.count(":ok")
            success_rate = round(ok_steps / steps, 2) if steps > 0 else 0.0
            sequences.append({
                "sequence": seq, "count": count, "steps": steps,
                "success_rate": success_rate,
                "confidence": min(0.95, 0.5 + count * 0.05),
            })
    # Promote 3+ step chains with 5+ occurrences to procedural_log
    proc_log = HIPPOCAMPUS_DIR / "Evidence" / "Metrics" / "procedural_log.json"
    try:
        proc_data = load_json(proc_log)
        if not isinstance(proc_data, list):
            proc_data = []
        existing = {p.get("sequence", "") for p in proc_data}
        new_procs = 0
        for seq in sequences:
            if seq["steps"] >= 3 and seq["count"] >= 5 and seq["sequence"] not in existing:
                proc_data.append({
                    "sequence": seq["sequence"], "count": seq["count"],
                    "steps": seq["steps"], "success_rate": seq["success_rate"],
                    "promoted_at": _now_iso(),
                })
                new_procs += 1
        if new_procs > 0:
            proc_log.parent.mkdir(parents=True, exist_ok=True)
            # P47: SQLite-first write — proc_data is a list, not a dict
            try:
                from pulse.brain.sqlite_writers import bulk_upsert_procedures
                procs = proc_data if isinstance(proc_data, list) else proc_data.get("procedures", [])
                bulk_upsert_procedures(procs, source="consolidation_mining")
            except Exception as e:
                _log.warning("SQLite procedure upsert failed: %s", e)
    except Exception:
        logging.debug("Suppressed exception in consolidation_mining", exc_info=True)
    if verbose:
        print(f"  [MINING] Found {len(sequences)} recurring sequences (2-5 step chains)")
    return sequences


def _load_entries_for_mining(md_file, jsonl_path):
    """JSONL-only loader for mining."""
    rows = read_jsonl_entries(jsonl_path) if jsonl_path else []
    if not rows:
        return []
    return [{"title": (r.get("title") or r.get("content", ""))[:200],
             "body": (r.get("content") or r.get("title", ""))[:200],
             "date": str(r.get("timestamp", ""))[:10] if r.get("timestamp") else "",
             "confidence": r.get("confidence", 0.5),
             "consolidation_count": r.get("consolidation_count", 1),
             "source": md_file.stem} for r in rows]


_FILE_JSONL_MAP = {PATTERNS_FILE: PATTERNS_JSONL, LESSONS_FILE: LESSONS_JSONL}


def mine_cross_session_patterns(days=7, verbose=False):
    """Find patterns that appear across multiple sessions.

    Scans JSONL (then MD fallback) for similar entries
    from different dates, indicating cross-session reinforcement.
    """
    patterns_found = []
    for md_file in [PATTERNS_FILE, LESSONS_FILE]:
        entries = _load_entries_for_mining(md_file, _FILE_JSONL_MAP.get(md_file))
        for i, e1 in enumerate(entries):
            similar_count = 0
            dates = {e1["date"]}
            max_conf = e1["confidence"]
            total_consol = e1["consolidation_count"]
            for j, e2 in enumerate(entries):
                if i == j:
                    continue
                if text_similarity(e1["title"], e2["title"]) >= 0.6:
                    similar_count += 1
                    dates.add(e2["date"])
                    max_conf = max(max_conf, e2["confidence"])
                    total_consol += e2["consolidation_count"]
            if similar_count >= 2 and max_conf >= 0.6:
                patterns_found.append({
                    "title": e1["title"][:80], "occurrences": similar_count + 1,
                    "unique_dates": len(dates), "max_confidence": max_conf,
                    "total_consolidations": total_consol, "source": e1["source"],
                })
    seen = set()
    unique = []
    for p in patterns_found:
        key = p["title"][:40].lower()
        if key not in seen:
            seen.add(key)
            unique.append(p)
    if verbose:
        print(f"  [MINING] Found {len(unique)} cross-session patterns")
    return unique


def register_discovered_procedures(sequences, verbose=False):
    """Register discovered event sequences with procedural_tracker."""
    if not sequences:
        return 0
    try:
        from pulse.admin.procedural_tracker import record_execution
    except ImportError:
        if verbose:
            print("  [PROCEDURES] procedural_tracker not available")
        return 0
    registered = 0
    for seq in sequences:
        seq_name = seq.get("sequence", "")
        count = seq.get("count", 0)
        if not seq_name or count < 3:
            continue
        proc_id = re.sub(r"[^a-z0-9_]", "_", seq_name.lower().replace(" -> ", "_to_"))
        proc_id = re.sub(r"_+", "_", proc_id).strip("_")
        record_execution(proc_id, success=True)
        registered += 1
        if verbose:
            print(f"  [PROCEDURES] Registered: {proc_id} (count={count})")
    return registered


def _load_schemas():
    """Load schemas.json data and existing name set."""
    schemas_file = PATTERNS_DIR / "schemas.json"
    data = load_json_dict(schemas_file)
    if "schemas" not in data:
        data["schemas"] = []
    names = {s.get("name", "").lower() for s in data["schemas"]}
    return schemas_file, data, names


def _upsert_schema(schemas_data, existing_names, name, confidence, evidence,
                   extra_fields=None, verbose=False, label="SCHEMA"):
    """Insert or update a schema entry. Returns True if new."""
    if name.lower() in existing_names:
        for s in schemas_data["schemas"]:
            if s.get("name", "").lower() == name.lower():
                s["evidence_count"] = max(s.get("evidence_count", 0), evidence)
                s["confidence"] = max(s.get("confidence", 0), confidence)
                s["last_reinforced"] = _now_iso()
                break
        return False
    schema_id = f"S-{len(schemas_data['schemas']) + 1:03d}"
    schema = {"schema_id": schema_id, "name": name,
              "evidence_count": evidence, "confidence": round(confidence, 3),
              "created": _now_iso()}
    if extra_fields:
        schema.update(extra_fields)
    schemas_data["schemas"].append(schema)
    existing_names.add(name.lower())
    if verbose:
        print(f"  [{label}] Promoted: {name} (conf={confidence:.2f})")
    return True


# Schema promotion functions moved to consolidation_promotion.py (single source of truth)
# Backward-compat re-exports for any direct importers
from .consolidation_promotion import (  # noqa: F401
    promote_cross_patterns_to_schemas,
    promote_sequences_to_schemas,
)
