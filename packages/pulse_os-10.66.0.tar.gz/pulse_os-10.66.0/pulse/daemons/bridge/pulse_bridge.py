# Copyright (c) 2026 PULSE Contributors. Proprietary. All rights reserved.
"""PULSE Bridge Daemon (V7): Raw Logs → Structured Knowledge."""
import time, os, sys
import io
from pathlib import Path
if os.name == 'nt' and __name__ == '__main__':
    if hasattr(sys.stdout, 'reconfigure'): sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    if hasattr(sys.stderr, 'reconfigure'): sys.stderr.reconfigure(encoding='utf-8', errors='replace')
SCRIPT_DIR = Path(__file__).resolve().parent
ROOT_DIR = SCRIPT_DIR.parent.parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))
from pulse.core.pulse_crypto import PulseCrypto
from pulse.core.brain_utils import save_json, load_json_dict
from pulse.core.brain_io import _acquire
from pulse.daemons.bridge.interaction_processor import process_interaction
from concurrent.futures import ThreadPoolExecutor
_FLUSH_EXECUTOR = ThreadPoolExecutor(max_workers=4, thread_name_prefix="bridge_flush")
import atexit
atexit.register(_FLUSH_EXECUTOR.shutdown, wait=False)

STATE_DIR = ROOT_DIR / "state"
LOG_CLAUDE = STATE_DIR / "pulse_captured_claude.log"
LOG_GEMINI = STATE_DIR / "pulse_captured_gemini.log"
LOG_CODEX = STATE_DIR / "pulse_captured_codex.log"
LOG_GROK = STATE_DIR / "pulse_captured_grok.log"  # QR14-P23: was missing
STATE_FILE = STATE_DIR / "pulse_bridge_state.json"

_BASE_LOGS = [LOG_CLAUDE, LOG_GEMINI, LOG_CODEX, LOG_GROK]
def _get_all_log_paths():
    return _BASE_LOGS + [p.with_suffix('.log.1') for p in _BASE_LOGS if p.with_suffix('.log.1').exists()]
POLL_INTERVAL = 1.0

class PulseBridge:
    def __init__(self, verbose=False):
        self.verbose = verbose
        self.running = True
        self.state = self._load_state()
        self.crypto = PulseCrypto()
        import signal
        signal.signal(signal.SIGTERM, self._handle_shutdown)
        signal.signal(signal.SIGINT, self._handle_shutdown)
        self.source_map = {"CLAUDE": "claude_daemon", "GEMINI": "gemini_daemon", "CODEX": "codex_daemon", "GROK": "grok_daemon"}
        self.buffers = {
            "CLAUDE": {"user": None, "agent": []},
            "GEMINI": {"user": None, "agent": []},
            "CODEX": {"user": None, "agent": []},
            "GROK": {"user": None, "agent": []},
        }
        self.last_activity = {"CLAUDE": 0.0, "GEMINI": 0.0, "CODEX": 0.0, "GROK": 0.0}
        self.idle_timeout_seconds = 10  # QR10: reduced from 30s for faster error gating

    def _log(self, msg):
        if self.verbose: print(f"[BRIDGE] {msg}")

    def _handle_shutdown(self, signum, frame):
        self._log("Shutdown — flushing buffers...")
        self.running = False
        for source in self.buffers:
            if self.buffers[source]["user"] and self.buffers[source]["agent"]:
                self._flush_interaction(source)
        self._save_state()
        self._log("Goodbye.")
        sys.exit(0)

    def _load_state(self):
        default_pos = {str(f): 0 for f in [LOG_CLAUDE, LOG_GEMINI, LOG_CODEX, LOG_GROK]}
        data = load_json_dict(STATE_FILE)
        if not data:
            return {"positions": default_pos}
        positions = data.get("positions", {})
        for k, v in default_pos.items():
            positions.setdefault(k, v)
        return {"positions": positions}

    def _save_state(self):
        with _acquire(STATE_FILE):
            save_json(STATE_FILE, self.state)

    def _process_line(self, line, source):
        line = line.strip()
        if not line: return
        if " | SIG: " not in line:
            self._log(f"Dropping unsigned line from {source}")
            return
        content_part, signature = line.rsplit(" | SIG: ", 1)
        daemon_id = self.source_map.get(source)
        if not daemon_id and source.startswith("WORKER_"):
            daemon_id = source.lower()
        if not daemon_id:
            daemon_id = source.lower()  # Fallback for dynamic workers
        if not self.crypto.verify_string(content_part, signature, daemon_id):
            print(f"[BRIDGE] INVALID SIGNATURE from {source}! POSSIBLE SPOOFING.")
            return
        import re
        match = re.match(r"^\[(.*?)\] (.*?): (.*)$", content_part)
        if not match: return
        ts, role, content = match.groups()
        if re.match(r"^\s*\|", content): return  # Filter markdown table rows
        buffer = self.buffers[source]
        self.last_activity[source] = time.time()
        if role == "USER":
            if buffer["user"] and buffer["agent"]:
                self._flush_interaction(source)
            buffer["user"] = content
            buffer["agent"] = []
        elif role in ["CLAUDE", "GEMINI", "CODEX", "GROK", "ASSISTANT"]:
            if buffer["user"]:
                buffer["agent"].append(content)

    def _flush_interaction(self, source):
        buffer = self.buffers[source]
        if not buffer["user"]: return
        user_text = buffer["user"]
        agent_text = "\n".join(buffer["agent"])
        # Clear buffer immediately so the main loop can continue reading
        buffer["user"] = None
        buffer["agent"] = []
        # Submit all heavy processing to background thread
        _FLUSH_EXECUTOR.submit(process_interaction, source, user_text, agent_text, self.verbose)


    def _tail_file(self, filepath, source, chunk_size=500):
        if not filepath.exists(): return
        key = str(filepath)
        pos = self.state["positions"].get(key, 0)
        current_size = filepath.stat().st_size
        if current_size < pos: pos = 0
        if current_size == pos: return
        with open(filepath, "r", encoding="utf-8") as f:
            f.seek(pos)
            count = 0
            while True:
                line = f.readline()
                if not line: break
                self._process_line(line, source)
                count += 1
                if count % chunk_size == 0:
                    self.state["positions"][key] = f.tell()
                    self._save_state()
            self.state["positions"][key] = f.tell()
        self._save_state()

    def _discover_worker_logs(self):
        found, known = [], {str(p) for p in _BASE_LOGS} | {str(p.with_suffix(".log.1")) for p in _BASE_LOGS}
        for f in STATE_DIR.glob("pulse_captured_*.log"):
            if str(f) in known: continue
            src = f.stem.replace("pulse_captured_", "").upper()
            if src not in self.buffers: self.buffers[src] = {"user": None, "agent": []}; self.last_activity[src] = 0.0
            self.state["positions"].setdefault(str(f), 0); found.append((f, src))
        return found

    def run(self):
        print(f"[BRIDGE] Watching: {LOG_CLAUDE.name}, {LOG_GEMINI.name}, {LOG_CODEX.name} + workers")
        while self.running:
            for log_path in _get_all_log_paths():
                stem = log_path.stem.replace(".log", "")
                source = stem.replace("pulse_captured_", "").upper()
                if source not in self.buffers:
                    self.buffers[source] = {"user": None, "agent": []}
                    self.last_activity[source] = 0.0
                self.state["positions"].setdefault(str(log_path), 0)
                self._tail_file(log_path, source)
            for log_path, source in self._discover_worker_logs():
                self._tail_file(log_path, source)
            now = time.time()
            for source, buf in self.buffers.items():
                last = self.last_activity.get(source, 0.0)
                if buf["user"] and buf["agent"] and last > 0 and (now - last) >= self.idle_timeout_seconds:
                    self._log(f"Idle flush for {source} ({now - last:.0f}s idle)")
                    self._flush_interaction(source)
                    self.last_activity[source] = 0.0
            try:
                from pulse.brain.pending_failures import flush_to_sqlite
                flush_to_sqlite()
            except Exception as e:
                self._log(f"[BRIDGE] Dead-letter flush failed: {e}")
            time.sleep(POLL_INTERVAL)

if __name__ == "__main__": PulseBridge(verbose="--verbose" in sys.argv).run()
