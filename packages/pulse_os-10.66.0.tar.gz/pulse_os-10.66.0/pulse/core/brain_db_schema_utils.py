"""brain_db_schema_utils.py — Helper functions for brain_db_schema.py (SoC split)."""
import logging
log = logging.getLogger("pulse.core.brain_db_schema_utils")


def _validate_table(table: str, valid_tables: frozenset[str]) -> str:
    if table not in valid_tables:
        raise ValueError(f"Invalid table name: {table!r}")
    return table


def _knowledge_indexes(table: str, valid_tables: frozenset[str]) -> list:
    _validate_table(table, valid_tables)
    return [
        f"CREATE UNIQUE INDEX IF NOT EXISTS uq_{table}_fingerprint ON {table}(fingerprint);",
        f"CREATE INDEX IF NOT EXISTS idx_{table}_domain ON {table}(domain);",
        f"CREATE INDEX IF NOT EXISTS idx_{table}_timestamp ON {table}(timestamp DESC);",
        f"CREATE INDEX IF NOT EXISTS idx_{table}_valid_salience ON {table}(validity, salience DESC);"
    ]


def _tables_exist(conn) -> bool:
    """Quick read-only check if all required tables exist (no write lock)."""
    try:
        _REQUIRED = {
            "lessons", "failures", "patterns", "private", "intents",
            "decisions", "facts", "evidence", "predictions",
            "knowledge_fts", "retrieval_metrics", "graph_nodes",
            "graph_edges", "schemas", "anti_patterns", "procedures", "episodic",
            "sessions", "session_turns",
        }
        rows = conn.execute(
            "SELECT name FROM sqlite_master WHERE type IN ('table','view')"
        ).fetchall()
        existing = {r[0] for r in rows}
        return _REQUIRED.issubset(existing)
    except Exception:
        return False
