#!/usr/bin/env python3
# Copyright (c) 2026 PULSE Contributors. Proprietary. All rights reserved.
"""Brain file counting helpers.

Split from brain_analysis.py for Law 7 compliance.
"""
from pathlib import Path


def count_lines(path: Path) -> int:
    """Count lines in a file."""
    if not path.exists():
        return 0
    try:
        with open(path, "r", encoding="utf-8") as f:
            return sum(1 for _ in f)
    except OSError:
        return 0


def count_json_items(path: Path) -> int:
    """Count items in a JSON array file."""
    from pulse.core.brain_io import load_json
    data = load_json(path)
    return len(data) if isinstance(data, list) else 0


def count_md_sections(path: Path) -> int:
    """Count ## sections in a markdown file."""
    if not path.exists():
        return 0
    try:
        with open(path, "r", encoding="utf-8") as f:
            return sum(1 for line in f if line.startswith("## "))
    except OSError:
        return 0
