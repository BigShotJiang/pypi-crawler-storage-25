"""PULSE — Neural Operating System for AI agent governance."""

__version__ = "10.66.0"
