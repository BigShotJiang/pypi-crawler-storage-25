"""License status display helper for pulse status command."""
from __future__ import annotations


import logging
log = logging.getLogger("pulse.cli.status._license_display")

def show_license_status() -> None:
    """Print license plan, status, and trial end to stdout."""
    try:
        from pulse.core.paths import _is_dev_mode
        if _is_dev_mode():
            print("\n  License:       DEV (pro) — development repo")
            return

        from pulse.core.license import LicenseManager
        lic = LicenseManager().load_license()
        if lic:
            plan = lic.get("plan", "?").upper()
            status = lic.get("status", "?")
            trial_end = lic.get("trial_end")
            trial_str = ""
            if trial_end:
                from datetime import datetime, timezone
                te = datetime.fromtimestamp(trial_end, tz=timezone.utc)
                trial_str = f" | trial ends {te.strftime('%Y-%m-%d')}"
            warn = lic.get("_warning", "")
            warn_str = f" [{warn}]" if warn else ""
            print(f"\n  License:       {plan} ({status}){trial_str}{warn_str}")
        else:
            print("\n  License:       NONE — run 'pulse activate <KEY>'")
    except Exception as _exc:
        pass  # QR14: silent — consider log.debug("%s", _exc)
