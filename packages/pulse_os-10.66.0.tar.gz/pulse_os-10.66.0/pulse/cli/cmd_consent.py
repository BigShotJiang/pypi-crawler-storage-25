# Copyright (c) 2026 PULSE Contributors. Proprietary. All rights reserved.
"""Consent management — `pulse consent revoke` to delete brain data (QR14-P19)."""
from __future__ import annotations


def cmd_consent(args: list):
    """Manage data consent — `pulse consent revoke` to delete all brain data."""
    if not args or args[0] != "revoke":
        print("Usage: pulse consent revoke")
        print("  Deletes all brain data and resets consent.")
        return

    from pulse.core.paths import get_pulse_home, get_project_dir, _is_dev_mode
    import shutil

    print("[PULSE] Revoking consent and deleting brain data...")
    if _is_dev_mode():
        print("  Dev mode: brain lives in repo. Use 'pulse clean' to clear state/.")
        return

    project_dir = get_project_dir()
    if project_dir.exists():
        try:
            answer = input(f"  Delete {project_dir}? [y/N] ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print("\n  Cancelled.")
            return
        if answer == "y":
            shutil.rmtree(project_dir, ignore_errors=True)
            print(f"  Deleted: {project_dir}")
            print("  Consent revoked. Run 'pulse init' to start fresh.")
        else:
            print("  Cancelled.")
    else:
        print("  No project data found.")
