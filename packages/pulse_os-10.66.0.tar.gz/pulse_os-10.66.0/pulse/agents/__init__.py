"""Agent wrappers: claude, gemini, codex, grok."""
