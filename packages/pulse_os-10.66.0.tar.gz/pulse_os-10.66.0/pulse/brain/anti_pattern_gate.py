"""Backward-compat shim — moved to pulse.brain.integrity.anti_pattern_gate."""
from pulse.brain.integrity.anti_pattern_gate import *  # noqa: F401,F403
from pulse.brain.integrity.anti_pattern_gate import (
    main, _check_gate, _extract_content, _extract_file_path,
    _load_prediction_alerts, _gate3_prediction_alert, gate3_prediction_alert,
    _gate1_anti_pattern, _gate2_failure_scan, _gate4_decision_conflict,
    _gate5_temporal_advisory,
)

if __name__ == "__main__":
    main()
