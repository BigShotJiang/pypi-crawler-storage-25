# Copyright (c) 2026 PULSE Contributors. Proprietary. All rights reserved.
"""Reflex detection — inline reflex arc check on user prompts."""

try:
    from pulse.daemons.bridge.reflex_arc import detect_mistakes, check_reflex
except Exception:
    detect_mistakes = None
    check_reflex = None


def _inline_reflex(user_text: str) -> list:
    """Run reflex arc inline on user prompt — zero daemon latency."""
    if not detect_mistakes or not user_text or len(user_text) < 20:
        return []
    try:
        detections = detect_mistakes(user_text)
        if not detections:
            return []
        if check_reflex:
            try: check_reflex(user_text, "", "hook")
            except Exception: pass
        return [f"  !! REFLEX [{d.get('pattern_type', '')}]: {d.get('description', '')[:120]}"
                for d in detections[:3]]
    except Exception:
        return []
