# Copyright (c) 2026 PULSE Contributors. Proprietary. All rights reserved.
"""Brain Query package — public API for brain pre-action search."""

from .runner import run_query
from .briefing import format_briefing
from .briefing_signals import _format_explain
from .cli import main

__all__ = ["run_query", "format_briefing", "_format_explain", "main"]
