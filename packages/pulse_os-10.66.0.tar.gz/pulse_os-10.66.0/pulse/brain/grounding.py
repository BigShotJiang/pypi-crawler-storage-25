"""Backward-compat shim — moved to pulse.brain.integrity.grounding."""
from pulse.brain.integrity.grounding import *  # noqa: F401,F403
from pulse.brain.integrity.grounding import _check_criteria
