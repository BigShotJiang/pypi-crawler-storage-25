"""Backward-compat shim — moved to pulse.brain.integrity.provenance."""
from pulse.brain.integrity.provenance import *  # noqa: F401,F403
from pulse.brain.integrity.provenance import (
    _fingerprint, _load_index, _save_index, _validate_stage,
    INDEX_FILE, _EMPTY_INDEX, _CACHE, _CACHE_MTIME,
)
