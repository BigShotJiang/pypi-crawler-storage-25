# Copyright (c) 2026 PULSE Contributors. Proprietary. All rights reserved.
"""Backward-compatibility shim — re-exports from loaders_context and loaders_support.

Import from the specific modules for new code:
  from pulse.brain.boot.loaders_context import load_recent_brain, load_relevant_brain, load_daemon_injections
  from pulse.brain.boot.loaders_support import load_curriculum, load_session_continuity, load_swarm_competence, ...
"""
from pulse.brain.boot.loaders_context import (
    load_recent_brain,
    load_relevant_brain,
    load_daemon_injections,
)
from pulse.brain.boot.loaders_support import (
    _clean_titles,
    _get_confirmed_titles,
    _get_recent_titles,
    _load_jsonl_titles,
    _extract_search_hits,
    _load_cross_agent_intel,
    load_curriculum,
    _search_brain_for_task,
    load_session_continuity,
    load_swarm_competence,
)

__all__ = [
    "load_recent_brain",
    "load_relevant_brain",
    "load_daemon_injections",
    "_clean_titles",
    "_get_confirmed_titles",
    "_get_recent_titles",
    "_load_jsonl_titles",
    "_extract_search_hits",
    "_load_cross_agent_intel",
    "load_curriculum",
    "_search_brain_for_task",
    "load_session_continuity",
    "load_swarm_competence",
]
