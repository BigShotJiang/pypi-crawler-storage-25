"""Backward-compat shim — moved to pulse.brain.integrity.graph_rag_extractor."""
from pulse.brain.integrity.graph_rag_extractor import *  # noqa: F401,F403
from pulse.brain.integrity.graph_rag_extractor import SCANNER_PROVIDER, SCANNER_MODEL
