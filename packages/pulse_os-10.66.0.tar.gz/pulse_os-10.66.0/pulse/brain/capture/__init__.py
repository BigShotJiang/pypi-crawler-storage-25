"""Capture subpackage — evidence capture, routing, and batch processing.

Re-exports public API so callers can use::

    from pulse.brain.capture import capture
    from pulse.brain.capture import route_to_domain, batch_capture
"""

from pulse.brain.capture.auto_capture import (  # noqa: F401
    capture,
    batch_capture,
    batch_capture_from_log,
)
from pulse.brain.capture.capture_routing import (  # noqa: F401
    is_business_content,
    count_similar_wants,
    count_similar_dont_wants,
    route_to_domain,
    update_growth_metrics,
    WANTS_EVIDENCE,
    DONT_WANTS_EVIDENCE,
    SESSION_EVIDENCE,
    ANTI_PATTERNS_ACTIVE,
)
from pulse.brain.capture.capture_routing_batch import (  # noqa: F401
    batch_capture as _batch_capture_fn,
    batch_capture_from_log as _batch_capture_from_log_fn,
)
