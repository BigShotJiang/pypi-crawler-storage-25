#!/usr/bin/env python3
# Copyright (c) 2026 PULSE Contributors. Proprietary. All rights reserved.
# See LICENSE file for details.
"""
Auto-Capture CLI: Entry point for manual and batch evidence capture.
"""

import json
import sys
from pulse.brain.capture.auto_capture import capture, batch_capture, batch_capture_from_log

if __name__ == "__main__":
    if "--log-file" in sys.argv:
        idx = sys.argv.index("--log-file")
        if idx + 1 < len(sys.argv):
            result = batch_capture_from_log(sys.argv[idx + 1])
            print(json.dumps(result, indent=2))
        else:
            print("Error: --log-file requires a path argument")
            sys.exit(1)
    elif len(sys.argv) > 1 and sys.argv[1] == "--batch":
        result = batch_capture()
        print(json.dumps(result, indent=2))
    elif len(sys.argv) < 2:
        print("Usage: python auto_capture_cli.py <user_prompt> [agent_response] [session_id]")
        print("       python auto_capture_cli.py --batch")
        print("       python auto_capture_cli.py --log-file <path>")
        sys.exit(1)
    else:
        prompt = sys.argv[1]
        response = sys.argv[2] if len(sys.argv) > 2 else ""
        sid = sys.argv[3] if len(sys.argv) > 3 else ""

        result = capture(prompt, response, sid)
        print(json.dumps(result, indent=2))
