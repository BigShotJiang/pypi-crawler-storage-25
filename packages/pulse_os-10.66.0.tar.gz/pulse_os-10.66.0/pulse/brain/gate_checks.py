"""Backward-compat shim — moved to pulse.brain.integrity.gate_checks."""
from pulse.brain.integrity.gate_checks import *  # noqa: F401,F403
from pulse.brain.integrity.gate_checks import (
    _keyword_overlap, _extract_keywords, _get_domain_from_path,
    _open_db, _gate1_check, _resolve_root, _resolve_db_path,
)
from pulse.brain.integrity.gate_ap_query import (
    _build_fts_query, _is_code_prescriptive,
    _query_anti_patterns, _format_ap_block, _is_relevant_to_content,
    _graded_gate_result,
)
