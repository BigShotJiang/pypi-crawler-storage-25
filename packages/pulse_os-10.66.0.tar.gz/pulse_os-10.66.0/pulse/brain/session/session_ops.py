#!/usr/bin/env python3
# Copyright (c) 2026 PULSE Contributors. Proprietary. All rights reserved.
"""Session Operations — private helpers for session_lifecycle.py (SoC split)."""
import json
import hashlib
from datetime import datetime, timezone
from typing import Optional


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _session_id(agent: str) -> str:
    ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    h = hashlib.md5(f"{agent}:{ts}".encode()).hexdigest()[:6]
    return f"ses_{agent}_{ts}_{h}"


def _bubble_milestones(session_id: str, milestones: list):
    """Aggregate milestones into session metadata."""
    if not session_id or not milestones:
        return
    from pulse.core.brain_db import get_conn
    conn = get_conn()
    try:
        row = conn.execute("SELECT metadata FROM sessions WHERE id=?", (session_id,)).fetchone()
        if not row:
            return
        meta = json.loads(row[0]) if row[0] else {}
        existing = meta.get("milestones", [])
        for m in milestones:
            if m not in existing:
                existing.append(m)
        meta["milestones"] = existing[-20:] # Cap at 20
        with conn:
            conn.execute("UPDATE sessions SET metadata=? WHERE id=?", (json.dumps(meta), session_id))
    except Exception as _exc:
        pass


def _get_recent_turns(session_id: str, limit: int = 15) -> list:
    """Fetch recent turns for a session (for summary generation)."""
    try:
        from pulse.core.brain_db import get_conn
        conn = get_conn()
        rows = conn.execute(
            "SELECT role, content FROM session_turns WHERE session_id=? "
            "ORDER BY turn_index DESC LIMIT ?",
            (session_id, limit),
        ).fetchall()
        return [{"role": r[0], "content": r[1]} for r in reversed(rows)]
    except Exception:
        return []


def _synthesize_summary(turns: list, agent: str) -> str:
    """Generate a 2-sentence session summary from recent turns via LLM.

    Falls back to keyword extraction if LLM unavailable.
    """
    turn_text = "\n".join([
        f"{t['role'].upper()}: {t['content'][:200]}" for t in turns[-10:]
    ])
    prompt = (
        "Summarize this AI session in 2 sentences: what was shipped or decided, "
        "and what the next step is.\n\n" + turn_text
    )
    try:
        from pulse.core.llm_router import dispatch
        result = dispatch(prompt, task_type="fast", max_tokens=150)
        if result and len(result.strip()) > 10:
            return result.strip()[:500]
    except Exception as _exc:
        pass  # QR14: silent — consider log.debug("%s", _exc)
    # Fallback: extract meaningful keywords
    keywords = set()
    for t in turns:
        for word in t.get("content", "").split():
            if len(word) > 6 and word.isalpha() and word.lower() not in {
                "because", "should", "always", "getting", "through", "another",
                "between", "without", "however", "already", "before", "during",
            }:
                keywords.add(word.lower())
    kw_list = sorted(keywords)[:8]
    return f"Session with {len(turns)} turns. Topics: {', '.join(kw_list)}" if kw_list else ""


def get_active_session(agent: str) -> Optional[str]:
    """Get the active session ID for an agent, if any."""
    from pulse.core.brain_db import get_conn
    conn = get_conn()
    row = conn.execute(
        "SELECT id FROM sessions WHERE (agent = ? OR agent LIKE ? || '_%') "
        "AND status='active' ORDER BY started_at DESC LIMIT 1",
        (agent, agent),
    ).fetchone()
    return row[0] if row else None


def _get_session_turns(session_id: str, limit: int = 20) -> list:
    """Get the most recent turns from a session."""
    from pulse.core.brain_db import get_conn
    conn = get_conn()
    rows = conn.execute(
        "SELECT turn_index, role, content, timestamp FROM session_turns "
        "WHERE session_id=? ORDER BY turn_index DESC LIMIT ?",
        (session_id, limit),
    ).fetchall()
    return [dict(r) for r in reversed(rows)]
