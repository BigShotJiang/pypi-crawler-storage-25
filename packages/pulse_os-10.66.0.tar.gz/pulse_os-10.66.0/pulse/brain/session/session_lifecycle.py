#!/usr/bin/env python3
# Copyright (c) 2026 PULSE Contributors. Proprietary. All rights reserved.
"""Session Lifecycle — cross-session memory for PULSE agents.


P47: Every conversation gets a session record in SQLite. When a new agent
boots, it sees the last 3 sessions from ANY agent — not just its own.

Tables: sessions, session_turns (created by brain_db.init_db)
"""
import logging
log = logging.getLogger("pulse.brain.session.session_lifecycle")


import json
import hashlib
from datetime import datetime, timezone
from typing import Optional

from pulse.brain.session.session_ops import (
    _now, _session_id, _bubble_milestones, _get_recent_turns,
    _synthesize_summary, get_active_session, _get_session_turns
)


def start_session(agent: str, task: str = "", domain: str = "general") -> str:
    """Create a new session row. Returns session_id.

    Also detects orphaned 'active' sessions from the same agent and
    marks them as 'abandoned' (crash recovery).
    """
    from pulse.core.brain_db import get_conn

    conn = get_conn()
    sid = _session_id(agent)
    now = _now()

    # Orphan recovery: close any stale 'active' sessions from this agent
    try:
        with conn:
            conn.execute(
                "UPDATE sessions SET status='abandoned', ended_at=? "
                "WHERE agent=? AND status='active'",
                (now, agent),
            )
    except Exception as _exc:
        pass  # QR14: silent — consider log.debug("%s", _exc)

    # Find predecessor (most recent completed session from any agent)
    predecessor = None
    try:
        row = conn.execute(
            "SELECT id FROM sessions WHERE status IN ('completed','abandoned') "
            "ORDER BY started_at DESC LIMIT 1"
        ).fetchone()
        if row:
            predecessor = row[0]
    except Exception as _exc:
        pass  # QR14: silent — consider log.debug("%s", _exc)

    with conn:
        conn.execute(
            "INSERT OR IGNORE INTO sessions "
            "(id, agent, started_at, domain, status, predecessor_session, metadata) "
            "VALUES (?, ?, ?, ?, 'active', ?, '{}')",
            (sid, agent, now, domain, predecessor),
        )
    return sid


def record_turn(
    session_id: str,
    role: str,
    text: str,
    domain: str = "general",
    timestamp: str = "",
    valence: float = 0.0,
    arousal: float = 0.0,
    milestones: list = None,
    is_boundary: bool = False,
) -> None:
    """Record a conversation turn. Called by the bridge on each flush."""
    if not session_id or not text:
        return
    from pulse.core.brain_db import get_conn

    conn = get_conn()
    ts = timestamp or _now()

    # Get next turn index
    row = conn.execute(
        "SELECT MAX(turn_index) FROM session_turns WHERE session_id=?",
        (session_id,),
    ).fetchone()
    next_idx = (row[0] or 0) + 1 if row else 1

    # Truncate to 5000 chars to keep DB manageable
    trimmed = text[:5000]
    
    meta = {}
    if valence != 0.0 or arousal > 0.0:
        meta["valence"] = valence
        meta["arousal"] = arousal
    if milestones:
        meta["milestones"] = milestones
    if is_boundary:
        meta["is_boundary"] = True

    with conn:
        conn.execute(
            "INSERT INTO session_turns "
            "(session_id, turn_index, role, content, content_len, timestamp, domain, metadata) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (session_id, next_idx, role.lower(), trimmed, len(text), ts, domain, json.dumps(meta)),
        )
        # Update turn count on session
        conn.execute(
            "UPDATE sessions SET turn_count=turn_count+1 WHERE id=?", (session_id,)
        )
        
        # QR17: Bubble up milestones to session metadata
        if milestones:
            _bubble_milestones(session_id, milestones)


def end_session(
    session_id: str,
    summary: str = "",
    user_intent: str = "",
    key_decisions: list = None,
    key_discoveries: list = None,
    files_touched: list = None,
    status: str = "completed",
) -> None:
    """Mark session as completed with summary data.

    QR11 FIX 4: Auto-generates summary if empty and turns exist.
    """
    if not session_id:
        return
    from pulse.core.brain_db import get_conn

    # QR11 FIX 4: Auto-generate summary if caller didn't provide one
    if not summary:
        try:
            turns = _get_recent_turns(session_id, limit=15)
            if len(turns) >= 2:
                summary = _synthesize_summary(turns, "")
        except Exception as _exc:
            pass  # QR14: silent — consider log.debug("%s", _exc)

    conn = get_conn()
    now = _now()
    
    # QR17: Session Fingerprinting (Narrative Identity)
    fingerprint = hashlib.md5(f"{summary}:{user_intent}:{key_decisions}".encode()).hexdigest()[:12]

    with conn:
        # Retrieve existing metadata to preserve milestones
        row = conn.execute("SELECT metadata FROM sessions WHERE id=?", (session_id,)).fetchone()
        meta = json.loads(row[0]) if row and row[0] else {}
        meta["session_fingerprint"] = fingerprint
        
        conn.execute(
            "UPDATE sessions SET "
            "ended_at=?, summary=?, user_intent=?, "
            "key_decisions=?, key_discoveries=?, files_touched=?, "
            "status=?, metadata=? "
            "WHERE id=?",
            (
                now,
                (summary or "")[:2000],
                (user_intent or "")[:500],
                json.dumps((key_decisions or [])[:20]),
                json.dumps((key_discoveries or [])[:20]),
                json.dumps((files_touched or [])[:30]),
                status,
                json.dumps(meta),
                session_id,
            ),
        )


def get_recent_sessions(limit: int = 5, agent: str = None) -> list:
    """Get most recent completed/abandoned sessions across ALL agents.

    This is the core cross-session query. Returns dicts with:
    id, agent, started_at, ended_at, summary, user_intent, turn_count, domain, status
    """
    from pulse.core.brain_db import get_conn

    conn = get_conn()
    # QR11 FIX 4: Filter ghost sessions (0 turns + empty summary = noise in boot context)
    _ghost_filter = "AND (turn_count > 0 OR (summary != '' AND summary IS NOT NULL))"
    if agent:
        rows = conn.execute(
            "SELECT id, agent, started_at, ended_at, summary, user_intent, "
            "turn_count, domain, status FROM sessions "
            "WHERE agent=? AND status IN ('completed','abandoned') "
            f"{_ghost_filter} "
            "ORDER BY started_at DESC LIMIT ?",
            (agent, limit),
        ).fetchall()
    else:
        rows = conn.execute(
            "SELECT id, agent, started_at, ended_at, summary, user_intent, "
            "turn_count, domain, status FROM sessions "
            "WHERE status IN ('completed','abandoned') "
            f"{_ghost_filter} "
            "ORDER BY started_at DESC LIMIT ?",
            (limit,),
        ).fetchall()
    return [dict(r) for r in rows]


def _record_interaction(agent: str, user_text: str, agent_text: str = "",
                       domain: str = "general", timestamp: str = "",
                       valence: float = 0.0, arousal: float = 0.0,
                       milestones: list = None, is_boundary: bool = False) -> None:
    """Record a full interaction (user+agent turns) for the given agent.
    Called from bridge._flush_interaction. Auto-finds active session."""
    sid = get_active_session(agent)
    if not sid:
        return
    record_turn(sid, "user", user_text, domain=domain, timestamp=timestamp, 
                valence=valence, arousal=arousal, is_boundary=is_boundary)
    if agent_text:
        record_turn(sid, "agent", agent_text, domain=domain, timestamp=timestamp, 
                    valence=valence, arousal=arousal, milestones=milestones)
