#!/usr/bin/env python3
"""Called by Agent SessionEnd hook to close the active session."""
import sys
import pathlib
import logging
log = logging.getLogger("pulse.brain.session._session_end_hook")

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent.parent.parent))
try:
    from pulse.brain.session.session_lifecycle import end_session, get_active_session
    agent = sys.argv[1] if len(sys.argv) > 1 else "claude"
    sid = get_active_session(agent)
    if sid:
        end_session(sid)
except Exception as _exc:
    pass  # QR14: silent — consider log.debug("%s", _exc)
