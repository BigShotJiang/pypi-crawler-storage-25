"""Global Workspace Theory: competitive dynamics, specialists, attention, epistemic qualifiers."""

from pulse.brain.workspace.global_workspace import (
    run_workspace_ignition,
    compute_dynamic_threshold,
    RECURRENT_CYCLES,
    INHIBITION_FACTOR,
    IGNITION_GAP,
    MAX_BROADCAST_ITEMS,
)
from pulse.brain.workspace.specialists import (
    Coalition,
    get_memory_coalition,
    get_prediction_coalition,
    get_dmn_coalition,
    get_reflex_coalition,
    get_neural_state_coalition,
    get_working_memory_coalition,
    get_governance_coalition,
    gwt_broadcast,
)
from pulse.brain.workspace.workspace_integrator import (
    integrate,
    cluster_results,
    heuristic_synthesis,
)
from pulse.brain.workspace.attention import (
    get_attention_weights,
    apply_attention_to_results,
)
from pulse.brain.workspace.epistemic import (
    apply_epistemic_qualifiers,
)

__all__ = [
    # global_workspace
    "run_workspace_ignition",
    "compute_dynamic_threshold",
    "RECURRENT_CYCLES",
    "INHIBITION_FACTOR",
    "IGNITION_GAP",
    "MAX_BROADCAST_ITEMS",
    # specialists
    "Coalition",
    "get_memory_coalition",
    "get_prediction_coalition",
    "get_dmn_coalition",
    "get_reflex_coalition",
    "get_neural_state_coalition",
    "get_working_memory_coalition",
    "get_governance_coalition",
    "gwt_broadcast",
    # workspace_integrator
    "integrate",
    "cluster_results",
    "heuristic_synthesis",
    # attention
    "get_attention_weights",
    "apply_attention_to_results",
    # epistemic
    "apply_epistemic_qualifiers",
]
