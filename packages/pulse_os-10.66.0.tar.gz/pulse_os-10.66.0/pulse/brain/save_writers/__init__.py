#!/usr/bin/env python3
# Copyright (c) 2026 PULSE Contributors. Proprietary. All rights reserved.
"""save_writers package — re-exports all public symbols for backward compatibility.

Split from save_writers.py per Law 5 SoC (files <= 300 lines, one concern per file):
  quality.py    — quality gate logic
  jsonl_store.py — JSONL I/O, dedup cache, entry building
  writers.py    — high-level knowledge write APIs
  session.py    — session logging, skill tracking, save card
"""
from pulse.brain.save_writers.quality import (
    _QUALITY_SIGNALS,
    _passes_quality_gate,
)
from pulse.brain.save_writers.jsonl_store import (
    _CACHE_MAX,
    _TYPE_PREFIX,
    _MD_TO_TYPE,
    _JSONL_DEDUP_CACHE,
    _DEDUP_CACHE,
    _make_fingerprint,
    _make_entry_id,
    build_jsonl_entry,
    _load_jsonl_dedup_cache,
    rewrite_jsonl,
    _micro_consolidation_hook,
    append_knowledge_jsonl,
    append_to_json_list,
)
from pulse.brain.save_writers.writers import (
    LESSONS_FILE,
    FAILS_FILE,
    SESSIONS_FILE,
    PRIVATE_LESSONS_FILE,
    _write_entries_to_md,
    write_learnings,
    write_failures,
    write_private_learnings,
    append_knowledge_md,
    append_decision,
)
from pulse.brain.save_writers.session import (
    log_session,
    count_brain_queries,
    record_skill_usage,
    record_procedure,
    build_save_card,
)
# Re-export helpers that callers import directly from this module
from pulse.core.brain_utils import now_iso as _now_iso

__all__ = [
    # quality
    "_QUALITY_SIGNALS", "_passes_quality_gate",
    # jsonl_store
    "_CACHE_MAX", "_TYPE_PREFIX", "_MD_TO_TYPE",
    "_JSONL_DEDUP_CACHE", "_DEDUP_CACHE",
    "_make_fingerprint", "_make_entry_id",
    "build_jsonl_entry", "_load_jsonl_dedup_cache",
    "rewrite_jsonl", "_micro_consolidation_hook", "append_knowledge_jsonl",
    # writers
    "LESSONS_FILE", "FAILS_FILE", "SESSIONS_FILE", "PRIVATE_LESSONS_FILE",
    "_write_entries_to_md",
    "write_learnings", "write_failures", "write_private_learnings",
    "append_knowledge_md", "append_decision", "append_to_json_list",
    # session
    "log_session", "count_brain_queries", "record_skill_usage",
    "record_procedure", "build_save_card",
    # helpers
    "_now_iso",
]
