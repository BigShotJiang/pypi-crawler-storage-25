"""Metacognition subpackage — metamemory, calibration, procedures, schemas."""

from pulse.brain.metacognition.metamemory import (
    METAMEMORY_FILE,
    compute_metamemory,
    get_metamemory,
    _record_calibration,
    _get_calibration_factor,
    _record_knowledge_type_outcome,
    record_knowledge_type_outcome,
    get_knowledge_type_priority,
    get_brain_utilization,
    _save_metamemory,
    _decay_domain_expertise,
    _CALIBRATION_HISTORY,
    _KNOWLEDGE_TYPE_SUCCESS,
)

from pulse.brain.metacognition.metamemory_tracking import (
    _record_source_outcome,
    _get_source_reliability,
    _compute_domain_decay_stats,
    _record_agent_domain,
    get_agent_specialization,
    _compute_brain_health,
    apply_source_credibility_to_results,
    increment_consolidation_debt,
    _increment_consolidation_debt,
    reset_consolidation_debt,
    _reset_consolidation_debt,
    get_consolidation_debt,
    record_agent_session_domain,
    get_cognitive_flexibility_index,
    _SOURCE_RELIABILITY,
    _AGENT_SPECIALIZATION,
    _AGENT_SESSION_DOMAINS,
)

from pulse.brain.metacognition.metamemory_p34 import (
    get_decay_rate_24h,
    record_domain_valence,
    _record_domain_valence,
    get_domain_valence,
    record_agent_collaboration,
    get_collaboration_recommendations,
    compute_brain_entropy,
)

from pulse.brain.metacognition.metamemory_p36 import (
    get_confidence_histogram,
    get_cognitive_load_status,
    get_rehearsal_candidates,
    get_brain_age_metric,
    _AGENT_OVERLOAD_THRESHOLD,
)

from pulse.brain.metacognition.metacognitive_control import (
    SearchDirective,
    infer_domain,
    get_search_directive,
)

from pulse.brain.metacognition.agent_procedures import (
    get_agent_profile,
    get_weak_domains,
    get_strong_domains,
    match_procedures,
    format_agent_briefing,
)

from pulse.brain.metacognition.meta_schemas import (
    build_meta_schemas,
    get_meta_schemas,
    get_principles,
    QUALITY_GATE,
    MIN_SCHEMAS_PER_CLUSTER,
)

from pulse.brain.metacognition.knowledge_gap_map import (
    get_knowledge_gaps,
    _GAP_THRESHOLD,
)

from pulse.brain.metacognition.prediction_calibration import (
    record_domain_prediction,
    get_domain_calibration,
    compute_resolution,
)

from pulse.brain.metacognition.learned_prompt import (
    prioritize_by_credit,
    get_learned_weights,
    update_learned_weights,
    update_from_credits,
    resolve_items_from_text,
    LEARNED_WEIGHTS_FILE,
    BLEND_RATIO,
)

__all__ = [
    # metamemory
    "METAMEMORY_FILE", "compute_metamemory", "get_metamemory",
    "_record_calibration", "_get_calibration_factor",
    "_record_knowledge_type_outcome", "record_knowledge_type_outcome",
    "get_knowledge_type_priority", "get_brain_utilization", "_save_metamemory",
    "_decay_domain_expertise",
    # metamemory_tracking
    "_record_source_outcome", "_get_source_reliability",
    "_compute_domain_decay_stats", "_record_agent_domain",
    "get_agent_specialization", "_compute_brain_health",
    "apply_source_credibility_to_results",
    "increment_consolidation_debt", "reset_consolidation_debt",
    "get_consolidation_debt", "record_agent_session_domain",
    "get_cognitive_flexibility_index",
    # metamemory_p34
    "get_decay_rate_24h", "record_domain_valence", "get_domain_valence",
    "record_agent_collaboration", "get_collaboration_recommendations",
    "compute_brain_entropy",
    # metamemory_p36
    "get_confidence_histogram", "get_cognitive_load_status",
    "get_rehearsal_candidates", "get_brain_age_metric",
    # metacognitive_control
    "SearchDirective", "infer_domain", "get_search_directive",
    # agent_procedures
    "get_agent_profile", "get_weak_domains", "get_strong_domains",
    "match_procedures", "format_agent_briefing",
    # meta_schemas
    "build_meta_schemas", "get_meta_schemas", "get_principles",
    "QUALITY_GATE", "MIN_SCHEMAS_PER_CLUSTER",
    # knowledge_gap_map
    "get_knowledge_gaps",
    # prediction_calibration
    "record_domain_prediction", "get_domain_calibration", "compute_resolution",
    # learned_prompt
    "prioritize_by_credit", "get_learned_weights", "update_learned_weights",
    "update_from_credits", "resolve_items_from_text",
]
