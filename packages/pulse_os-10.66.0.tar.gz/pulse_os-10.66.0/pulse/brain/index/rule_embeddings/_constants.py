"""Shared constants for the rule_embeddings package."""
import os
from pulse.core.brain_utils import (
    STATE_DIR, LESSONS_JSONL, FAILS_JSONL, PATTERNS_JSONL,
)

EMBED_INDEX_FILE = STATE_DIR / "rule_embeddings.json"
EMBED_MODEL = os.environ.get("PULSE_EMBED_MODEL", "nomic-embed-text")
OLLAMA_ENDPOINT = os.environ.get("OLLAMA_ENDPOINT", "http://localhost:11434")

BRAIN_FILES = {
    "lessons": LESSONS_JSONL,
    "failures": FAILS_JSONL,
    "patterns": PATTERNS_JSONL,
}
