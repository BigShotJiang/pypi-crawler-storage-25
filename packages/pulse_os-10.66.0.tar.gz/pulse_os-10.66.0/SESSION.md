# SESSION.md (Router)

This file is the compatibility entrypoint for older references to `SESSION.md`.

Current session context is split into three files:
- `Hippocampus/Episodic/Current_Session/session_state.md`
- `Hippocampus/Episodic/Current_Session/active_tasks.md`
- `Hippocampus/Episodic/Current_Session/recent_changes.md`

Read all three for full context. Update the relevant one(s) instead of editing this file.
