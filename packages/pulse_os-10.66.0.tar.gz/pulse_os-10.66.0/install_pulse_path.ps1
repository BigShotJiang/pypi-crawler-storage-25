param(
    [switch]$Force
)

$root = (Get-Location).Path
$current = [Environment]::GetEnvironmentVariable("Path", "User")

if ($current -split ";" | Where-Object { $_ -eq $root }) {
    if (-not $Force) {
        Write-Output "[PULSE] PATH already contains repo root."
        exit 0
    }
}

$new = if ([string]::IsNullOrWhiteSpace($current)) { $root } else { "$current;$root" }
[Environment]::SetEnvironmentVariable("Path", $new, "User")

$env:Path = $new
Write-Output "[PULSE] Added repo root to user PATH."
Write-Output "[PULSE] You can now run: pulse activate claude --model haiku"
