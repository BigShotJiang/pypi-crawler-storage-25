\# Work in Progress

This package name is reserved for an upcoming modular Python library designed to download and compile webnovels into EPUB and PDF formats. Active development is underway.

