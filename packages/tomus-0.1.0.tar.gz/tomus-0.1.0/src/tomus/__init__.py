def main() -> None:
    print("Hello from tomus!")
