from __future__ import annotations

import sys
from pathlib import Path
from unittest.mock import MagicMock, patch, call

import docker
import docker.errors
import pytest
import typer

from synapps.onboarding.mcp_configurator import MCPClient


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_check_result(name: str, status: str = "pass", fix: str | None = None, group: str = "core"):
    from synapps.doctor.base import CheckResult
    return CheckResult(name=name, status=status, detail="detail", fix=fix, group=group)


def _make_report(results):
    from synapps.doctor.service import DoctorReport
    return DoctorReport(checks=results)


# ---------------------------------------------------------------------------
# _checks_for_languages
# ---------------------------------------------------------------------------

def test_checks_for_languages_python_only():
    from synapps.onboarding.init_wizard import _checks_for_languages
    from synapps.doctor.checks.docker_daemon import DockerDaemonCheck
    from synapps.doctor.checks.memgraph_bolt import MemgraphBoltCheck
    from synapps.doctor.checks.python3 import PythonCheck
    from synapps.doctor.checks.pylsp import PylspCheck
    from synapps.doctor.checks.dotnet import DotNetCheck
    from synapps.doctor.checks.node import NodeCheck
    from synapps.doctor.checks.java import JavaCheck

    checks = _checks_for_languages(["python"])

    check_types = [type(c) for c in checks]
    # Docker and Memgraph are handled by run_init, not in language checks
    assert DockerDaemonCheck not in check_types
    assert MemgraphBoltCheck not in check_types
    assert PythonCheck in check_types
    assert PylspCheck in check_types
    assert DotNetCheck not in check_types
    assert NodeCheck not in check_types
    assert JavaCheck not in check_types


def test_checks_for_languages_empty_returns_nothing():
    from synapps.onboarding.init_wizard import _checks_for_languages

    checks = _checks_for_languages([])
    assert checks == []


def test_checks_for_languages_multi():
    from synapps.onboarding.init_wizard import _checks_for_languages
    from synapps.doctor.checks.docker_daemon import DockerDaemonCheck
    from synapps.doctor.checks.memgraph_bolt import MemgraphBoltCheck
    from synapps.doctor.checks.python3 import PythonCheck
    from synapps.doctor.checks.pylsp import PylspCheck
    from synapps.doctor.checks.node import NodeCheck
    from synapps.doctor.checks.typescript_ls import TypeScriptLSCheck
    from synapps.doctor.checks.dotnet import DotNetCheck
    from synapps.doctor.checks.java import JavaCheck

    checks = _checks_for_languages(["python", "typescript"])

    check_types = [type(c) for c in checks]
    assert DockerDaemonCheck not in check_types
    assert MemgraphBoltCheck not in check_types
    assert PythonCheck in check_types
    assert PylspCheck in check_types
    assert NodeCheck in check_types
    assert TypeScriptLSCheck in check_types
    assert DotNetCheck not in check_types
    assert JavaCheck not in check_types


# ---------------------------------------------------------------------------
# run_init — various flows
# ---------------------------------------------------------------------------

def _common_patches(
    *,
    languages=None,
    mcp_clients=None,
    doctor_report=None,
    confirm_side_effect=None,
    isatty=True,
    smart_index_result="full-index",
):
    """Build a dict of all patches needed for run_init tests."""
    if languages is None:
        languages = [("python", 10)]
    if mcp_clients is None:
        mcp_clients = []
    if doctor_report is None:
        doctor_report = _make_report([_make_check_result("Docker daemon", "pass")])
    if confirm_side_effect is None:
        confirm_side_effect = [True]  # default: confirm everything

    return {
        "detect_languages": languages,
        "detect_mcp_clients": mcp_clients,
        "write_mcp_config": None,
        "doctor_report": doctor_report,
        "confirm_side_effect": confirm_side_effect,
        "isatty": isatty,
        "smart_index_result": smart_index_result,
    }


def _run_with_patches(project_path: str, opts: dict, *, has_existing_db_config: bool = True):
    mock_doctor_service = MagicMock()
    mock_doctor_service.return_value.run.return_value = opts["doctor_report"]

    mock_conn = MagicMock()
    mock_cm = MagicMock()
    mock_cm.return_value.get_connection.return_value = mock_conn

    mock_svc = MagicMock()
    mock_svc.return_value.smart_index.return_value = opts["smart_index_result"]

    mock_docker_client = MagicMock()

    with (
        patch("synapps.onboarding.init_wizard.detect_languages", return_value=opts["detect_languages"]),
        patch("synapps.onboarding.init_wizard.detect_mcp_clients", return_value=opts["detect_mcp_clients"]),
        patch("synapps.onboarding.init_wizard.write_mcp_config") as mock_write,
        patch("synapps.onboarding.init_wizard.DoctorService", mock_doctor_service),
        patch("synapps.onboarding.init_wizard.ConnectionManager", mock_cm),
        patch("synapps.onboarding.init_wizard.ensure_schema"),
        patch("synapps.onboarding.init_wizard.SynappsService", mock_svc),
        patch("synapps.onboarding.init_wizard.docker") as mock_docker_mod,
        patch("synapps.onboarding.init_wizard._has_existing_db_config", return_value=has_existing_db_config),
        patch("synapps.onboarding.init_wizard._write_db_config"),
        patch("synapps.onboarding.init_wizard._offer_hooks", return_value=[]),
        patch("typer.confirm", side_effect=opts["confirm_side_effect"]),
        patch("sys.stdin") as mock_stdin,
    ):
        mock_docker_mod.from_env.return_value = mock_docker_client
        mock_docker_mod.errors = docker.errors
        mock_stdin.isatty.return_value = opts["isatty"]

        from synapps.onboarding.init_wizard import run_init
        run_init(project_path)

    return mock_write, mock_svc, mock_cm


def test_wizard_calls_smart_index():
    opts = _common_patches(confirm_side_effect=[True, True, True, True])
    _, mock_svc, _ = _run_with_patches("/tmp/myproject", opts)
    mock_svc.return_value.smart_index.assert_called_once()
    call_args = mock_svc.return_value.smart_index.call_args
    assert "/tmp/myproject" in call_args[0] or "/tmp/myproject" in str(call_args)


def test_wizard_shows_fix_on_failure(capsys):
    from rich.console import Console

    fix_text = "brew install dotnet"
    failed_result = _make_check_result("DotNet", status="fail", fix=fix_text, group="csharp")
    report = _make_report([failed_result])

    # confirm_side_effect: [language confirm, continue-with-failures, mcp confirm (none)]
    opts = _common_patches(
        doctor_report=report,
        confirm_side_effect=[True, True],
    )

    mock_doctor_service = MagicMock()
    mock_doctor_service.return_value.run.return_value = report

    mock_conn = MagicMock()
    mock_cm = MagicMock()
    mock_cm.return_value.get_connection.return_value = mock_conn
    mock_svc = MagicMock()
    mock_svc.return_value.smart_index.return_value = "full-index"

    output_lines = []

    def capture_print(*args, **kwargs):
        output_lines.append(str(args))

    with (
        patch("synapps.onboarding.init_wizard.detect_languages", return_value=[("python", 10)]),
        patch("synapps.onboarding.init_wizard.detect_mcp_clients", return_value=[]),
        patch("synapps.onboarding.init_wizard.write_mcp_config"),
        patch("synapps.onboarding.init_wizard.DoctorService", mock_doctor_service),
        patch("synapps.onboarding.init_wizard.ConnectionManager", mock_cm),
        patch("synapps.onboarding.init_wizard.ensure_schema"),
        patch("synapps.onboarding.init_wizard.SynappsService", mock_svc),
        patch("synapps.onboarding.init_wizard.docker") as mock_docker_mod,
        patch("synapps.onboarding.init_wizard._has_existing_db_config", return_value=True),
        patch("synapps.onboarding.init_wizard._offer_hooks", return_value=[]),
        patch("typer.confirm", side_effect=[True, True]),
        patch("sys.stdin") as mock_stdin,
        patch("rich.console.Console.print", side_effect=capture_print) as mock_console_print,
    ):
        mock_docker_mod.from_env.return_value = MagicMock()
        mock_docker_mod.errors = docker.errors
        mock_stdin.isatty.return_value = True
        from synapps.onboarding.init_wizard import run_init
        run_init("/tmp/myproject")

    all_output = " ".join(output_lines)
    assert fix_text in all_output


def test_wizard_offers_mcp_config():
    client = MCPClient("Claude Code", Path("/tmp/.config/mcp.json"), "mcpServers")
    opts = _common_patches(
        mcp_clients=[client],
        confirm_side_effect=[True, True],  # language confirm, mcp confirm
    )
    mock_write, _, _ = _run_with_patches("/tmp/myproject", opts)
    mock_write.assert_called_once()


def test_wizard_skips_mcp_when_declined():
    client = MCPClient("Claude Code", Path("/tmp/.config/mcp.json"), "mcpServers")
    opts = _common_patches(
        mcp_clients=[client],
        confirm_side_effect=[True, False],  # language confirm, decline mcp
    )
    mock_write, _, _ = _run_with_patches("/tmp/myproject", opts)
    mock_write.assert_not_called()


def test_summary_printed():
    opts = _common_patches(confirm_side_effect=[True, True, True, True])

    mock_doctor_service = MagicMock()
    mock_doctor_service.return_value.run.return_value = _make_report(
        [_make_check_result("Docker daemon", "pass")]
    )
    mock_conn = MagicMock()
    mock_cm = MagicMock()
    mock_cm.return_value.get_connection.return_value = mock_conn
    mock_svc = MagicMock()
    mock_svc.return_value.smart_index.return_value = "full-index"

    printed_output = []

    def capture(*args, **kwargs):
        printed_output.append(str(args))

    with (
        patch("synapps.onboarding.init_wizard.detect_languages", return_value=[("python", 42)]),
        patch("synapps.onboarding.init_wizard.detect_mcp_clients", return_value=[]),
        patch("synapps.onboarding.init_wizard.write_mcp_config"),
        patch("synapps.onboarding.init_wizard.DoctorService", mock_doctor_service),
        patch("synapps.onboarding.init_wizard.ConnectionManager", mock_cm),
        patch("synapps.onboarding.init_wizard.ensure_schema"),
        patch("synapps.onboarding.init_wizard.SynappsService", mock_svc),
        patch("synapps.onboarding.init_wizard.docker") as mock_docker_mod,
        patch("synapps.onboarding.init_wizard._has_existing_db_config", return_value=True),
        patch("synapps.onboarding.init_wizard._offer_hooks", return_value=[]),
        patch("typer.confirm", return_value=True),
        patch("sys.stdin") as mock_stdin,
        patch("rich.console.Console.print", side_effect=capture),
    ):
        mock_docker_mod.from_env.return_value = MagicMock()
        mock_docker_mod.errors = docker.errors
        mock_stdin.isatty.return_value = True
        from synapps.onboarding.init_wizard import run_init
        run_init("/tmp/myproject")

    all_output = " ".join(printed_output)
    assert "python" in all_output.lower()


def test_non_interactive_stdin():
    with (
        patch("sys.stdin") as mock_stdin,
        patch("synapps.onboarding.init_wizard.detect_languages", return_value=[("python", 10)]),
    ):
        mock_stdin.isatty.return_value = False
        from synapps.onboarding.init_wizard import run_init
        with pytest.raises((typer.Exit, SystemExit)) as exc_info:
            run_init("/tmp/myproject")
        # Should exit with code 1
        exc = exc_info.value
        if isinstance(exc, typer.Exit):
            assert exc.exit_code == 1
        else:
            assert exc.code == 1


def test_docker_not_running_exits_with_error():
    """Init should fail early with a clear message when Docker is not running."""
    with (
        patch("sys.stdin") as mock_stdin,
        patch("synapps.onboarding.init_wizard.docker") as mock_docker_mod,
        patch("synapps.onboarding.init_wizard.detect_languages", return_value=[("python", 10)]),
    ):
        mock_stdin.isatty.return_value = True
        mock_docker_mod.from_env.return_value.ping.side_effect = docker.errors.DockerException("not running")
        mock_docker_mod.errors = docker.errors

        from synapps.onboarding.init_wizard import run_init
        with pytest.raises((typer.Exit, SystemExit)) as exc_info:
            run_init("/tmp/myproject")

        exc = exc_info.value
        if isinstance(exc, typer.Exit):
            assert exc.exit_code == 1
        else:
            assert exc.code == 1


def test_memgraph_auto_started_via_connection_manager():
    """Init should start Memgraph automatically instead of failing on a bolt check."""
    opts = _common_patches(confirm_side_effect=[True, True, True, True])
    _, _, mock_cm = _run_with_patches("/tmp/myproject", opts)
    # ConnectionManager.get_connection() is called (which auto-starts Memgraph)
    mock_cm.return_value.get_connection.assert_called_once()


# ---------------------------------------------------------------------------
# Database mode prompt
# ---------------------------------------------------------------------------

def test_db_mode_prompt_shown_when_no_existing_config():
    """Init should ask shared vs dedicated when no db config exists."""
    # confirm_side_effect: [language confirm, db mode (shared=True)]
    opts = _common_patches(confirm_side_effect=[True, True])
    _run_with_patches("/tmp/myproject", opts, has_existing_db_config=False)


def test_db_mode_prompt_skipped_when_config_exists():
    """Init should skip db mode prompt when project already has db config."""
    # confirm_side_effect: [language confirm] — no db mode confirm needed
    opts = _common_patches(confirm_side_effect=[True])
    _run_with_patches("/tmp/myproject", opts, has_existing_db_config=True)


def test_has_existing_db_config_returns_false_for_missing_file(tmp_path):
    from synapps.onboarding.init_wizard import _has_existing_db_config
    assert _has_existing_db_config(str(tmp_path)) is False


def test_has_existing_db_config_returns_false_without_key(tmp_path):
    from synapps.onboarding.init_wizard import _has_existing_db_config
    config_dir = tmp_path / ".synapps"
    config_dir.mkdir()
    (config_dir / "config.json").write_text('{"some_key": true}')
    assert _has_existing_db_config(str(tmp_path)) is False


def test_has_existing_db_config_returns_true_with_key(tmp_path):
    from synapps.onboarding.init_wizard import _has_existing_db_config
    config_dir = tmp_path / ".synapps"
    config_dir.mkdir()
    (config_dir / "config.json").write_text('{"dedicated_instance": false}')
    assert _has_existing_db_config(str(tmp_path)) is True


def test_write_db_config_creates_file(tmp_path):
    from synapps.onboarding.init_wizard import _write_db_config
    import json

    _write_db_config(str(tmp_path), dedicated=True)

    config = json.loads((tmp_path / ".synapps" / "config.json").read_text())
    assert config["dedicated_instance"] is True


def test_write_db_config_preserves_existing_keys(tmp_path):
    from synapps.onboarding.init_wizard import _write_db_config
    import json

    config_dir = tmp_path / ".synapps"
    config_dir.mkdir()
    (config_dir / "config.json").write_text('{"existing_key": "value"}')

    _write_db_config(str(tmp_path), dedicated=False)

    config = json.loads((config_dir / "config.json").read_text())
    assert config["dedicated_instance"] is False
    assert config["existing_key"] == "value"


class TestInitWizardHookOffer:
    def test_init_offers_hook_installation(self, tmp_path: Path) -> None:
        """Verify the wizard calls _offer_hooks after MCP config."""
        from unittest.mock import patch, MagicMock

        with patch("synapps.onboarding.init_wizard._offer_hooks") as mock_hooks, \
             patch("synapps.onboarding.init_wizard._offer_mcp_config", return_value=[]), \
             patch("synapps.onboarding.init_wizard.detect_languages", return_value=[("python", 10)]), \
             patch("synapps.onboarding.init_wizard._prompt_language_confirmation", return_value=["python"]), \
             patch("synapps.onboarding.init_wizard._checks_for_languages", return_value=[]), \
             patch("synapps.onboarding.init_wizard.DoctorService") as mock_doctor, \
             patch("synapps.onboarding.init_wizard.ConnectionManager") as mock_conn, \
             patch("synapps.onboarding.init_wizard.ensure_schema"), \
             patch("synapps.onboarding.init_wizard.SynappsService") as mock_svc, \
             patch("synapps.onboarding.init_wizard._has_existing_db_config", return_value=True), \
             patch("sys.stdin") as mock_stdin:
            mock_stdin.isatty.return_value = True
            mock_report = MagicMock()
            mock_report.checks = []
            mock_report.has_failures = False
            mock_doctor.return_value.run.return_value = mock_report
            mock_svc.return_value.smart_index.return_value = "42 symbols"

            from synapps.onboarding.init_wizard import run_init
            run_init(str(tmp_path))

        mock_hooks.assert_called_once()
