from typing import Any

from pydantic import field_validator, model_validator

from retrievalbase.connector.settings import MinioDatasetConnectorSettings
from retrievalbase.enums import FAISSIndexType
from retrievalbase.exceptions import LimitRerankerMismatchError
from retrievalbase.settings import FromConfigMixinSettings
from retrievalbase.types import TCDatasetConnector as TCDatasetConnector
from retrievalbase.types import TCDenseRetriever as TCDenseRetriever
from retrievalbase.types import TCEmbedder as TCEmbedder
from retrievalbase.types import TCProcessor as TCProcessor
from retrievalbase.types import TCReranker as TCReranker
from retrievalbase.types import TCRetriever as TCRetriever
from retrievalbase.types import TCVectorStore as TCVectorStore


class EmbedderSettings(FromConfigMixinSettings):
    model_name: str


class OpenAICompatibleEmbedderSettings(EmbedderSettings):
    base_url: str


class ProcessorSettings(FromConfigMixinSettings):
    pass


class NomicProcessorSettings(ProcessorSettings):
    pass


class ScoreSettings(FromConfigMixinSettings):
    ks: list[int]


class RecallAtKScoreSettings(ScoreSettings):
    pass


class PrecisionAtKScoreSettings(ScoreSettings):
    pass


class MRRAtKScoreSettings(ScoreSettings):
    pass


class NDCGAtKScoreSettings(ScoreSettings):
    pass


class VectorStoreSettings(FromConfigMixinSettings):
    pass


class QdrantVectorStoreSettings(VectorStoreSettings):
    url: str
    collection_name: str
    timeout: int | None


class FaissVectorStoreSettings(VectorStoreSettings):
    index_type: FAISSIndexType
    normalize: bool

    @field_validator("index_type", mode="before")
    @classmethod
    def normalize_index_type(cls, v: Any) -> FAISSIndexType:
        if isinstance(v, FAISSIndexType):
            return v
        if isinstance(v, str):
            try:
                return FAISSIndexType(v.lower())
            except ValueError as e:
                raise ValueError(f"Invalid FAISS index_type '{v}'.") from e
        raise TypeError(f"index_type must be a string or FAISSIndexType, got {type(v).__name__}")


class RerankerSettings(FromConfigMixinSettings):
    pass


class HFRerankerSettings(RerankerSettings):
    model_name: str
    revision: str | None
    device: str


class HTTPRerankerSettings(RerankerSettings):
    url: str
    timeout: float
    max_batch_size: int
    batch_timeout_ms: float


class RetrieverSettings[TCReranker: RerankerSettings](FromConfigMixinSettings):
    reranker: TCReranker | None


class BM25RetrieverSettings[TCDatasetConnector: FromConfigMixinSettings, TCReranker: RerankerSettings](
    RetrieverSettings[TCReranker],
):
    dataset_connector: TCDatasetConnector


class DenseRetrieverSettings[
    TCEmbedder: EmbedderSettings,
    TCVectorStore: VectorStoreSettings,
    TCProcessor: ProcessorSettings,
    TCReranker: RerankerSettings,
](
    RetrieverSettings[TCReranker],
):
    embedder: TCEmbedder
    vector_store: TCVectorStore
    processor: TCProcessor


class HybridRetrieverSettings[
    TCDenseRetriever: DenseRetrieverSettings[Any, Any, Any, Any],
    TCDatasetConnector: FromConfigMixinSettings,
    TCReranker: RerankerSettings,
](
    RetrieverSettings[TCReranker],
):
    dense_retriever: TCDenseRetriever
    bm25_retriever: BM25RetrieverSettings[TCDatasetConnector, TCReranker]
    rrf_k: int


class BM25QdrantVLLMHybridRetrieverSettings(
    HybridRetrieverSettings[
        DenseRetrieverSettings[
            OpenAICompatibleEmbedderSettings,
            QdrantVectorStoreSettings,
            NomicProcessorSettings,
            RerankerSettings,
        ],
        MinioDatasetConnectorSettings,
        RerankerSettings,
    ]
):
    pass


class EvaluatorSettings[TCDatasetConnector: FromConfigMixinSettings, TCRetriever: RetrieverSettings[Any]](
    FromConfigMixinSettings
):
    dataset_connector: TCDatasetConnector
    retriever: TCRetriever


class PythonEvaluatorSettings[TCDatasetConnector: FromConfigMixinSettings, TCRetriever: RetrieverSettings[Any]](
    EvaluatorSettings[TCDatasetConnector, TCRetriever],
):
    scores: list[ScoreSettings]
    limit: int | None

    @model_validator(mode="after")
    def validate_limit_and_reranker(self) -> "PythonEvaluatorSettings":
        if (self.limit is None) != (self.retriever.reranker is None):
            raise LimitRerankerMismatchError(
                limit=self.limit,
                reranker=self.retriever.reranker,
            )

        return self


class QdrantEvaluatorSettings(
    PythonEvaluatorSettings[
        MinioDatasetConnectorSettings,
        DenseRetrieverSettings[
            OpenAICompatibleEmbedderSettings,
            QdrantVectorStoreSettings,
            NomicProcessorSettings,
            RerankerSettings,
        ],
    ]
):
    pass


class FaissEvaluatorSettings[TCEmbedder: EmbedderSettings](
    PythonEvaluatorSettings[
        MinioDatasetConnectorSettings,
        DenseRetrieverSettings[
            TCEmbedder,
            FaissVectorStoreSettings,
            NomicProcessorSettings,
            RerankerSettings,
        ],
    ],
):
    pass


class BM25EvaluatorSettings(
    PythonEvaluatorSettings[
        MinioDatasetConnectorSettings,
        BM25RetrieverSettings[MinioDatasetConnectorSettings, RerankerSettings],
    ]
):
    pass


class HybridRetrieverEvaluatorSettings(
    PythonEvaluatorSettings[
        MinioDatasetConnectorSettings,
        BM25QdrantVLLMHybridRetrieverSettings,
    ]
):
    pass
