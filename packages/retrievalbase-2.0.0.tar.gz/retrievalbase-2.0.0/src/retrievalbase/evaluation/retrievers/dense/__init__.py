import asyncio
import logging
from typing import Any

from retrievalbase.evaluation import Embedder, Processor, VectorStore
from retrievalbase.evaluation.retrievers import Retriever
from retrievalbase.evaluation.settings import DenseRetrieverSettings
from retrievalbase.types import TCDenseRetriever as TCDenseRetriever
from retrievalbase.utils import load_class

_logger = logging.getLogger(__name__)


class DenseRetriever[TCDenseRetriever: DenseRetrieverSettings[Any, Any, Any, Any]](Retriever[TCDenseRetriever]):
    def __init__(self, config: TCDenseRetriever) -> None:
        super().__init__(config)
        _logger.info(f"Initializing Retriever | class={self.__class__.__name__}")

        self.embedder: Embedder[Any] = load_class(self.config.embedder.module_path).from_config(self.config.embedder)

        self.vector_store: VectorStore[Any] = load_class(self.config.vector_store.module_path).from_config(
            self.config.vector_store
        )

        self.processor: Processor[Any] = load_class(self.config.processor.module_path).from_config(
            self.config.processor
        )

        _logger.info(
            f"Retriever initialized | embedder={type(self.embedder).__name__} | "
            f"vector_store={type(self.vector_store).__name__}"
        )

    async def retrieve_batch(
        self, queries: list[str], limit: int, reranker_limit: int | None = None
    ) -> list[VectorStore.QueryResponse]:
        embedding = await self.embedder.aembed_queries(queries, self.processor)
        responses = await self.vector_store.abatch_query_points(embedding, limit)
        if self.reranker:
            if reranker_limit is None:
                raise ValueError("reranker_limit must be provided when a reranker is configured.")
            responses = await asyncio.gather(
                *[
                    self.reranker.rerank(query, response, reranker_limit)
                    for query, response in zip(queries, responses, strict=True)
                ]
            )
        return responses

    async def _retrieve(self, query: str, limit: int) -> VectorStore.QueryResponse:
        embedding = await self.embedder.aembed_query(query, self.processor)
        return await self.vector_store.aquery_points(embedding, limit)

    async def aclose(self) -> None:
        await self.embedder.aclose()
        await self.vector_store.aclose()
