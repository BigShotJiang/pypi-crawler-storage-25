import asyncio
import logging
from typing import Any

from retrievalbase.evaluation import VectorStore
from retrievalbase.evaluation.retrievers import BM25Retriever, Retriever
from retrievalbase.evaluation.retrievers.dense import DenseRetriever
from retrievalbase.evaluation.settings import HybridRetrieverSettings
from retrievalbase.utils import load_class

_logger = logging.getLogger(__name__)


class HybridRetriever[TCHybridRetriever: HybridRetrieverSettings[Any, Any, Any]](Retriever[TCHybridRetriever]):
    """
    Hybrid retriever combining DenseRetriever and BM25Retriever
    using Reciprocal Rank Fusion (RRF).
    """

    def __init__(self, config: TCHybridRetriever) -> None:
        super().__init__(config)

        self.dense: DenseRetriever = load_class(self.config.dense_retriever.module_path).from_config(
            self.config.dense_retriever
        )
        self.bm25: BM25Retriever = load_class(self.config.bm25_retriever.module_path).from_config(
            self.config.bm25_retriever
        )

        _logger.info(
            f"HybridRetriever initialized | dense={type(self.dense).__name__} "
            f"| bm25={type(self.bm25).__name__} | rrf_k={self.config.rrf_k}"
        )

    # --------------------------------------------------
    # Retrieval API
    # --------------------------------------------------

    async def _retrieve(self, query: str, limit: int) -> VectorStore.QueryResponse:
        dense, bm25 = await asyncio.gather(
            self.dense.retrieve(query, limit),
            self.bm25.retrieve(query, limit),
        )
        fused = self._fuse(dense, bm25, limit)
        return fused

    # --------------------------------------------------
    # Fusion logic (RRF)
    # --------------------------------------------------

    def _fuse(
        self,
        dense: VectorStore.QueryResponse,
        bm25: VectorStore.QueryResponse,
        limit: int,
    ) -> VectorStore.QueryResponse:
        scores: dict[str, float] = {}
        documents: dict[str, VectorStore.ScoredPoint] = {}

        def add_results(response: VectorStore.QueryResponse) -> None:
            for rank, point in enumerate(response.points):
                doc_id = point.document.page_content
                rrf_score = 1.0 / (self.config.rrf_k + rank + 1)
                scores[doc_id] = scores.get(doc_id, 0.0) + rrf_score
                documents[doc_id] = point

        add_results(dense)
        add_results(bm25)
        fused = sorted(
            scores.items(),
            key=lambda x: x[1],
            reverse=True,
        )[:limit]
        return VectorStore.QueryResponse(
            points=[
                VectorStore.ScoredPoint(
                    score=scores[doc_id],
                    document=documents[doc_id].document,
                )
                for doc_id, _ in fused
            ]
        )

    async def aclose(self) -> None:
        await self.dense.aclose()
        await self.bm25.aclose()
