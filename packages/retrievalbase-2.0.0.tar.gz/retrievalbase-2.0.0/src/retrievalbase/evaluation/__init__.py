import logging
from abc import ABC, abstractmethod
from typing import Any, cast

from langchain_core.documents import Document
from pydantic import BaseModel, Field

from retrievalbase.enums import EmbeddingPurposeEnum
from retrievalbase.evaluation.async_batcher import AsyncBatcher
from retrievalbase.evaluation.settings import (
    EmbedderSettings,
    ProcessorSettings,
    RerankerSettings,
    VectorStoreSettings,
)
from retrievalbase.mixins import FromConfigMixin
from retrievalbase.types import TCEmbedder as TCEmbedder
from retrievalbase.types import TCProcessor as TCProcessor
from retrievalbase.types import TCVectorStore as TCVectorStore

_logger = logging.getLogger(__name__)


class Processor[TCProcessor: ProcessorSettings](FromConfigMixin[TCProcessor], ABC):
    def __init__(self, config: TCProcessor) -> None:
        self.config = config

    @abstractmethod
    def __call__(self, text: str, purpose: EmbeddingPurposeEnum) -> str:
        raise NotImplementedError


class Embedder[TCEmbedder: EmbedderSettings](FromConfigMixin[TCEmbedder], ABC):
    MAX_BATCH_SIZE: int = 15
    BATCH_TIMEOUT_MS: float = 4.921875

    def __init__(self, config: TCEmbedder) -> None:
        self.config = config
        self._batcher = AsyncBatcher[str, list[float]](
            batch_fn=self._aembed,
            max_batch_size=self.__class__.MAX_BATCH_SIZE,
            batch_timeout_ms=self.__class__.BATCH_TIMEOUT_MS,
        )
        _logger.info(f"Initialized Embedder | class={self.__class__.__name__}")

    # ---------------- ABSTRACT ----------------

    @abstractmethod
    async def _aembed(self, texts: list[str]) -> list[list[float]]:
        raise NotImplementedError

    # ---------------- LIFECYCLE ----------------
    async def aclose(self) -> None:
        return None

    # ---------------- PUBLIC API ----------------

    async def aembed(self, texts: list[str]) -> list[list[float]]:
        return await self._batcher.submit(texts)

    async def aembed_queries(
        self,
        queries: list[str],
        processor: Processor[Any] | None = None,
    ) -> list[list[float]]:
        if processor:
            queries = [
                processor(
                    text=query,
                    purpose=cast(EmbeddingPurposeEnum, EmbeddingPurposeEnum.QUERY),
                )
                for query in queries
            ]
        return await self.aembed(queries)

    async def aembed_query(
        self,
        query: str,
        processor: Processor[Any] | None = None,
    ) -> list[float]:
        return (await self.aembed_queries([query], processor))[0]

    async def aembed_documents(
        self,
        docs: list[str],
        processor: Processor[Any] | None = None,
    ) -> list[list[float]]:
        if processor:
            docs = [
                processor(
                    text=doc,
                    purpose=cast(EmbeddingPurposeEnum, EmbeddingPurposeEnum.DOCUMENT),
                )
                for doc in docs
            ]
        return await self.aembed(docs)


class VectorStore[TCVectorStore: VectorStoreSettings](FromConfigMixin[TCVectorStore], ABC):
    MAX_BATCH_SIZE: int = 3
    BATCH_TIMEOUT_MS: float = 0.984

    class VectorQuery(BaseModel):
        vector: list[float]
        limit: int

    class ScoredPoint(BaseModel):
        score: float = Field(..., description="Points vector distance to the query vector")
        document: Document

    class QueryResponse(BaseModel):
        points: list["VectorStore.ScoredPoint"]

    def __init__(self, config: TCVectorStore) -> None:
        self.config = config
        self._batcher = AsyncBatcher[
            VectorStore.VectorQuery,
            VectorStore.QueryResponse,
        ](
            batch_fn=self._abatch_query_points,
            max_batch_size=self.__class__.MAX_BATCH_SIZE,
            batch_timeout_ms=self.__class__.BATCH_TIMEOUT_MS,
        )
        _logger.info(f"Initialized VectorStore | class={self.__class__.__name__} | config={config}")

    # -------- batching boundary --------

    @abstractmethod
    async def _abatch_query_points(
        self,
        requests: list["VectorStore.VectorQuery"],
    ) -> list["VectorStore.QueryResponse"]:
        raise NotImplementedError

    async def abatch_query_points(
        self,
        queries: list[list[float]],
        limit: int,
    ) -> list["VectorStore.QueryResponse"]:
        return await self._batcher.submit([self.VectorQuery(vector=q, limit=limit) for q in queries])

    async def aquery_points(
        self,
        query: list[float],
        limit: int,
    ) -> "VectorStore.QueryResponse":
        return (await self.abatch_query_points([query], limit))[0]

    # ---------------- LIFECYCLE ----------------
    async def aclose(self) -> None:
        """
        Close underlying async resources (HTTP clients, sockets, etc.).
        Default: no-op.
        """
        return None


class Reranker[TCReranker: RerankerSettings](FromConfigMixin[TCReranker], ABC):
    def __init__(self, config: TCReranker):
        super().__init__(config)

    @abstractmethod
    async def rerank(
        self,
        query: str,
        response: VectorStore.QueryResponse,
        limit: int,
    ) -> VectorStore.QueryResponse:
        raise NotImplementedError

    async def aclose(self) -> None:
        return None
