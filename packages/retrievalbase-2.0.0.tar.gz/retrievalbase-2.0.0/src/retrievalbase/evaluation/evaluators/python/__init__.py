import logging
from abc import ABC, abstractmethod
from collections.abc import Coroutine, Iterator
from typing import (
    Any,
    overload,
)

import numpy as np
from pydantic import BaseModel
from tqdm.asyncio import tqdm_asyncio

from retrievalbase.evaluation import VectorStore
from retrievalbase.evaluation.evaluators import Evaluator
from retrievalbase.evaluation.settings import PythonEvaluatorSettings, ScoreSettings
from retrievalbase.mixins import FromConfigMixin
from retrievalbase.types import TCPythonEvaluator as TCPythonEvaluator
from retrievalbase.types import TCScore as TCScore
from retrievalbase.utils import load_class

_logger = logging.getLogger(__name__)


class Score[TCScore: ScoreSettings](FromConfigMixin[TCScore], ABC):
    class ScoreResult(BaseModel):
        name: str
        value: float

    def __init__(self, config: TCScore) -> None:
        self.config = config
        _logger.info(f"Initialized Score | class={self.__class__.__name__} | config={config}")

    @overload
    def __call__(self, hits: list[bool]) -> list[ScoreResult]: ...

    @overload
    def __call__(self, hits: list[bool], total_relevant: int) -> list[ScoreResult]: ...

    # ---- runtime ----
    @abstractmethod
    def __call__(
        self,
        hits: list[bool],
        total_relevant: int | None = None,
    ) -> list[ScoreResult]:
        raise NotImplementedError


class PythonEvaluator[TCPythonEvaluator: PythonEvaluatorSettings[Any, Any]](Evaluator[TCPythonEvaluator], ABC):
    NB_LOGS_PER_QUERIES = 100
    BATCH_SIZE = 96
    MATCH_METADATA_FIELDS = ("doc_id", "chunk_id")

    def __init__(self, config: TCPythonEvaluator) -> None:
        super().__init__(config)
        self.scores: list[Score[ScoreSettings]] = [load_class(s.module_path)(s) for s in self.config.scores]
        _logger.info(
            f"Evaluator ready | dataset_size={len(self.dataset)} | scores={[type(s).__name__ for s in self.scores]}"
        )

    def batch_iter(self) -> Iterator[list[dict[str, Any]]]:
        batch: list[dict[str, Any]] = []
        for row in self.dataset.iter_rows(named=True):
            batch.append(row)
            if len(batch) == self.BATCH_SIZE:
                yield batch
                batch = []
        if batch:
            yield batch

    def _get_max_k(self) -> int:
        return max(max(score.config.ks) for score in self.scores)

    def _build_retrieval_tasks(
        self, max_k: int
    ) -> tuple[
        list[list[dict[str, Any]]],
        list[Coroutine[Any, Any, list[VectorStore.QueryResponse]]],
    ]:
        tasks: list[Coroutine[Any, Any, list[VectorStore.QueryResponse]]] = []
        batches: list[list[dict[str, Any]]] = []

        for batch in self.batch_iter():
            queries = [sample["metadata"]["query"] for sample in batch]

            if self.config.limit is None:
                limit, reranker_limit = max_k, None
            else:
                limit, reranker_limit = self.config.limit, max_k
            task = self.retriever.retrieve_batch(queries, limit=limit, reranker_limit=reranker_limit)
            tasks.append(task)
            batches.append(batch)

        return batches, tasks

    async def _collect_responses(
        self, tasks: list[Coroutine[Any, Any, list[VectorStore.QueryResponse]]]
    ) -> list[list[VectorStore.QueryResponse]]:
        return await tqdm_asyncio.gather(
            *tasks,
            desc="Evaluating batches",
        )

    @classmethod
    def _sample_match_key(cls, sample: dict[str, Any]) -> tuple[Any, ...]:
        metadata = sample["metadata"]
        try:
            return tuple(metadata[field] for field in cls.MATCH_METADATA_FIELDS)
        except KeyError as exc:
            fields = ", ".join(f"metadata.{field}" for field in cls.MATCH_METADATA_FIELDS)
            raise ValueError(f"Evaluation samples must include {fields}.") from exc

    @classmethod
    def _document_matches_sample(cls, sample: dict[str, Any], point: VectorStore.ScoredPoint) -> bool:
        sample_key = cls._sample_match_key(sample)
        document_metadata = point.document.metadata
        return all(
            document_metadata[field] == value
            for field, value in zip(cls.MATCH_METADATA_FIELDS, sample_key, strict=True)
        )

    def _score_batches(
        self,
        batches: list[list[dict[str, Any]]],
        responses: list[list[VectorStore.QueryResponse]],
    ) -> list[dict[str, float]]:
        scores_all: list[dict[str, float]] = []
        processed = 0

        for batch, batch_responses in zip(batches, responses, strict=True):
            for sample, response in zip(batch, batch_responses, strict=True):
                hits = [self._document_matches_sample(sample, p) for p in response.points]
                row_scores: dict[str, float] = {}
                for score in self.scores:
                    results = score(hits, total_relevant=1)
                    for r in results:
                        row_scores[r.name] = r.value
                scores_all.append(row_scores)
                processed += 1
                if processed % self.NB_LOGS_PER_QUERIES == 0:
                    _logger.info(f"Progress {processed}/{len(self.dataset)}")
        return scores_all

    def _aggregate_scores(
        self,
        scores_all: list[dict[str, float]],
    ) -> dict[str, float]:
        if not scores_all:
            return {}

        # collect all metric names
        metric_names = scores_all[0].keys()

        results: dict[str, float] = {}

        for name in metric_names:
            values = [row[name] for row in scores_all]
            results[name] = float(np.mean(values))

        return results

    async def eval(self) -> dict[str, float]:
        max_k = self._get_max_k()
        _logger.info(f"Starting Dense evaluation | max_k={max_k}")
        batches, tasks = self._build_retrieval_tasks(max_k)
        responses = await self._collect_responses(tasks)
        scores_all = self._score_batches(batches, responses)
        return self._aggregate_scores(scores_all)
