import math

from retrievalbase.evaluation.evaluators.python import Score
from retrievalbase.evaluation.settings import (
    MRRAtKScoreSettings,
    NDCGAtKScoreSettings,
    PrecisionAtKScoreSettings,
    RecallAtKScoreSettings,
)
from retrievalbase.exceptions import MetricConfigurationError


class RecallAtK(Score[RecallAtKScoreSettings]):
    def __call__(
        self,
        hits: list[bool],
        total_relevant: int | None = None,
    ) -> list[Score.ScoreResult]:
        if total_relevant is None:
            raise MetricConfigurationError("RecallAtK", "total_relevant is required")
        results = []
        for k in self.config.ks:
            hits_k = hits[:k]
            value = sum(hits_k) / total_relevant if total_relevant > 0 else 0.0

            results.append(
                Score.ScoreResult(
                    name=f"Recall@{k}",
                    value=value,
                )
            )
        return results


class PrecisionAtK(Score[PrecisionAtKScoreSettings]):
    def __call__(
        self,
        hits: list[bool],
        total_relevant: int | None = None,
    ) -> list[Score.ScoreResult]:
        results: list[Score.ScoreResult] = []

        for k in self.config.ks:
            hits_k = hits[:k]
            value = sum(hits_k) / len(hits_k) if hits_k else 0.0

            results.append(
                Score.ScoreResult(
                    name=f"Precision@{k}",
                    value=value,
                )
            )

        return results


class MRRAtK(Score[MRRAtKScoreSettings]):
    def __call__(
        self,
        hits: list[bool],
        total_relevant: int | None = None,
    ) -> list[Score.ScoreResult]:
        results: list[Score.ScoreResult] = []

        for k in self.config.ks:
            value = 0.0

            for rank, is_hit in enumerate(hits[:k], start=1):
                if is_hit:
                    value = 1.0 / rank
                    break

            results.append(
                Score.ScoreResult(
                    name=f"MRR@{k}",
                    value=value,
                )
            )

        return results


class NDCGAtK(Score[NDCGAtKScoreSettings]):
    def __call__(
        self,
        hits: list[bool],
        total_relevant: int | None = None,
    ) -> list[Score.ScoreResult]:
        if total_relevant is None:
            raise MetricConfigurationError("NDCGAtK", "total_relevant is required")

        results: list[Score.ScoreResult] = []

        for k in self.config.ks:
            # ---- DCG ----
            dcg = 0.0
            for i, hit in enumerate(hits[:k]):
                if hit:
                    dcg += 1.0 / math.log2(i + 2)

            # ---- IDCG ----
            ideal_hits = [True] * min(total_relevant, k)

            idcg = 0.0
            for i, hit in enumerate(ideal_hits):
                if hit:
                    idcg += 1.0 / math.log2(i + 2)

            value = dcg / idcg if idcg > 0 else 0.0

            results.append(
                Score.ScoreResult(
                    name=f"NDCG@{k}",
                    value=value,
                )
            )

        return results
