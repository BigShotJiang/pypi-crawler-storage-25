from typing import Any, Self, cast

import numpy as np
from langchain_core.documents import Document

from retrievalbase.dataset.polars import PolarsTextDataset
from retrievalbase.evaluation.evaluators.python import PythonEvaluator
from retrievalbase.evaluation.retrievers.dense import DenseRetriever
from retrievalbase.evaluation.settings import (
    BM25EvaluatorSettings,
    FaissEvaluatorSettings,
    HybridRetrieverEvaluatorSettings,
    QdrantEvaluatorSettings,
)
from retrievalbase.evaluation.vector_stores import FaissVectorStore
from retrievalbase.types import TCFaissEvaluator as TCFaissEvaluator
from retrievalbase.types import TCPythonDenseEvaluator


class DensePythonEvaluator(PythonEvaluator[TCPythonDenseEvaluator]):
    def __init__(self, config: TCPythonDenseEvaluator) -> None:
        super().__init__(config)
        if not isinstance(self.retriever, DenseRetriever):
            raise TypeError(
                f"{self.__class__.__name__} requires a DenseRetriever, got {type(self.retriever).__name__} instead."
            )


class QdrantPythonEvaluator(DensePythonEvaluator[QdrantEvaluatorSettings]):
    def __init__(self, config: QdrantEvaluatorSettings):
        super().__init__(config)


class FaissPythonEvaluator[TCFaissEvaluator: FaissEvaluatorSettings[Any]](DensePythonEvaluator[TCFaissEvaluator]):
    def __init__(self, config: TCFaissEvaluator):
        super().__init__(config)

    @classmethod
    async def create(cls, config: TCFaissEvaluator) -> Self:
        self = cls(config)
        docs = self.get_docs()
        texts = [d.page_content for d in docs]
        self.retriever = cast(DenseRetriever[Any], self.retriever)
        embeddings = np.asarray(
            await self.retriever.embedder.aembed_documents(texts, processor=self.retriever.processor),
            dtype="float32",
        )
        vector_store = cast(FaissVectorStore, self.retriever.vector_store)
        vector_store.index = vector_store.build_faiss_index(embeddings.shape[-1])
        vector_store.add_documents(docs, embeddings)
        return self

    def get_docs(self) -> list[Document]:
        docs_idx = []
        seen = set()
        for i, row in enumerate(self.dataset.iter_rows(named=True)):
            doc_id = row["metadata"]["doc_id"]
            if doc_id not in seen:
                seen.add(doc_id)
                docs_idx.append(i)
        return PolarsTextDataset(self.dataset.polars[docs_idx]).to_langchain_documents()


class BM25Evaluator(PythonEvaluator[BM25EvaluatorSettings]):
    def __init__(self, config: BM25EvaluatorSettings) -> None:
        super().__init__(config)


class HybridRetrieverEvaluator(PythonEvaluator[HybridRetrieverEvaluatorSettings]):
    def __init__(self, config: HybridRetrieverEvaluatorSettings) -> None:
        super().__init__(config)
