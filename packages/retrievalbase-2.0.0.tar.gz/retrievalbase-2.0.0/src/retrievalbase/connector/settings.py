from pydantic import SecretStr
from pydantic_settings import SettingsConfigDict

from retrievalbase.settings import FromConfigMixinSettings


class DatasetConnectorSettings(FromConfigMixinSettings):
    pass


class ParquetDatasetConnectorSettings(DatasetConnectorSettings):
    path: str
    lazy: bool


class MinioDatasetConnectorSettings(DatasetConnectorSettings):
    endpoint: str
    bucket: str
    key: str
    access_key: SecretStr
    secret_key: SecretStr
    model_config = SettingsConfigDict(env_prefix="MINIO_", extra="ignore")
