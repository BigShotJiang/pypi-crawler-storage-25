from abc import ABC
from typing import Any

import polars as pl
from datasets import Dataset as HFDataset

from retrievalbase.connector import DatasetConnector
from retrievalbase.dataset import TextDataset
from retrievalbase.dataset.settings import HuggingFaceDatasetAdaptaterSettings
from retrievalbase.exceptions import DatasetSchemaError
from retrievalbase.mixins import FromConfigMixin
from retrievalbase.utils import build_schema, extract_schema_columns, load_class


class HuggingFaceDatasetAdaptater[TCHFDatasetAdaptater: HuggingFaceDatasetAdaptaterSettings[Any]](
    FromConfigMixin[TCHFDatasetAdaptater],
    ABC,
):
    def __init__(self, config: TCHFDatasetAdaptater) -> None:
        super().__init__(config)
        self._dataset: TextDataset[pl.DataFrame | pl.LazyFrame] | None = None

    @property
    def dataset(self) -> TextDataset:
        if self._dataset is None:
            connector: DatasetConnector[Any] = load_class(self.config.connector.module_path).from_config(
                self.config.connector
            )

            self._dataset = connector.load_text()

        return self._dataset

    def to_hf(self) -> HFDataset:
        df = self.dataset.polars
        # schema mapping
        schema = self.config.columns_mapping
        # validation (top-level)
        available_columns = df.columns
        flattened_columns = extract_schema_columns(df.schema)
        missing_roots = {path.split(".")[0] for path in schema.values() if path.split(".")[0] not in available_columns}
        if missing_roots:
            raise DatasetSchemaError(
                missing_columns=missing_roots,
                available_columns=available_columns,
                flattened_columns=flattened_columns,
            )
        df = build_schema(df, schema)
        return HFDataset.from_dict(df.to_dict(as_series=False))
