from abc import ABC, abstractmethod
from typing import Any

from retrievalbase.dataset.polars import TextDataset
from retrievalbase.dataset.settings import TextPreprocessorSettings, TokenCounterSettings
from retrievalbase.mixins import FromConfigMixin
from retrievalbase.types import TCTextPreprocessor as TCTextPreprocessor
from retrievalbase.types import TCTokenCounter as TCTokenCounter


class TextPreprocessor[TCTextPreprocessor: TextPreprocessorSettings](FromConfigMixin[TCTextPreprocessor], ABC):
    def __init__(self, config: TCTextPreprocessor) -> None:
        self.config = config

    @abstractmethod
    def apply(self, ds: TextDataset[Any]) -> TextDataset[Any]:
        raise NotImplementedError


class TokenCounter[TCTokenCounter: TokenCounterSettings](FromConfigMixin[TCTokenCounter], ABC):
    def __init__(self, config: TCTokenCounter) -> None:
        self.config = config

    @abstractmethod
    def count(self, text: str) -> int:
        raise NotImplementedError

    def count_batch(self, texts: list[str]) -> list[int]:
        return [self.count(t) for t in texts]
