from typing import Literal

from retrievalbase.settings import FromConfigMixinSettings


class TextPreprocessorSettings(FromConfigMixinSettings):
    kind: str


class TokenCounterSettings(FromConfigMixinSettings):
    pass


class HeuristicTokenCounterSettings(TokenCounterSettings):
    chars_per_token: int


class HuggingFaceTokenCounterSettings(TokenCounterSettings):
    name: str
    add_special_tokens: bool
    revision: str | None


class TokenFilterSettings[TCTokenCounter: TokenCounterSettings](TextPreprocessorSettings):
    token_counter: TCTokenCounter


class MinTokenFilterSettings[TCTokenCounter: TokenCounterSettings](TokenFilterSettings[TCTokenCounter]):
    kind: Literal["min_tokens"]
    min_tokens: int


class MaxTokenFilterSettings[TCTokenCounter: TokenCounterSettings](TokenFilterSettings[TCTokenCounter]):
    kind: Literal["max_tokens"]
    max_tokens: int


class QuantileTokenFilterSettings[TCTokenCounter: TokenCounterSettings](TokenFilterSettings[TCTokenCounter]):
    kind: Literal["quantile"]
    q: float


class SigmaBandTokenFilterSettings[TCTokenCounter: TokenCounterSettings](TokenFilterSettings[TCTokenCounter]):
    kind: Literal["sigma"]
    z: float


BaseTextPreprocessorUnion = (
    MinTokenFilterSettings[HuggingFaceTokenCounterSettings]
    | MaxTokenFilterSettings[HuggingFaceTokenCounterSettings]
    | QuantileTokenFilterSettings[HuggingFaceTokenCounterSettings]
    | SigmaBandTokenFilterSettings[HuggingFaceTokenCounterSettings]
)


class PreprocessPipelineSettings[TCTextPreprocessor: TextPreprocessorSettings](TextPreprocessorSettings):
    kind: Literal["steps"]
    steps: list[TCTextPreprocessor]


class HuggingFaceDatasetAdaptaterSettings[TCDatasetConnector: FromConfigMixinSettings](FromConfigMixinSettings):
    connector: TCDatasetConnector
    columns_mapping: dict[str, str]
