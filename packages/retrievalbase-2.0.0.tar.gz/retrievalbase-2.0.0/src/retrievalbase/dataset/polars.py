from typing import Self

import polars as pl

from retrievalbase.dataset import Dataset, TextDataset


class PolarsDataset(Dataset[pl.DataFrame | pl.LazyFrame]):
    def __init__(self, service: pl.DataFrame | pl.LazyFrame):
        super().__init__(service)

    @classmethod
    def from_polars(cls, df: pl.DataFrame | pl.LazyFrame) -> Self:
        return cls(df)

    def to_polars(self) -> pl.DataFrame:
        if isinstance(self.service, pl.LazyFrame):
            return self.service.collect(background=False)  # ty: ignore[invalid-return-type]
        return self.service

    def to_lazy_polars(self) -> pl.LazyFrame:
        if isinstance(self.service, pl.LazyFrame):
            return self.service
        return self.service.lazy()


class PolarsTextDataset(TextDataset[pl.DataFrame | pl.LazyFrame]):
    def __init__(self, service: pl.DataFrame | pl.LazyFrame):
        super().__init__(service)

    @classmethod
    def from_polars(cls, df: pl.DataFrame | pl.LazyFrame) -> Self:
        return cls(df)

    def to_polars(self) -> pl.DataFrame:
        if isinstance(self.service, pl.LazyFrame):
            return self.service.collect(background=False)  # ty: ignore[invalid-return-type]
        return self.service

    def to_lazy_polars(self) -> pl.LazyFrame:
        if isinstance(self.service, pl.LazyFrame):
            return self.service
        return self.service.lazy()
