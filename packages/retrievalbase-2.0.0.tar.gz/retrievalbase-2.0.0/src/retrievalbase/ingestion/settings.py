from retrievalbase.dataset.settings import TextPreprocessorSettings
from retrievalbase.settings import FromConfigMixinSettings


class TextIngestionPipelineSettings[
    TCDatasetConnector: FromConfigMixinSettings,
    TCTextPreprocessor: TextPreprocessorSettings,
](FromConfigMixinSettings):
    connector: TCDatasetConnector
    preprocessor: TCTextPreprocessor
