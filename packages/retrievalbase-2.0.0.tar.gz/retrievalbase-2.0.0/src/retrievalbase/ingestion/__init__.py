import logging
from typing import Any

from retrievalbase.connector import DatasetConnector
from retrievalbase.dataset import TextDataset
from retrievalbase.dataset.preprocess import TextPreprocessor
from retrievalbase.ingestion.settings import TextIngestionPipelineSettings
from retrievalbase.mixins import FromConfigMixin
from retrievalbase.types import TCTextIngestionPipeline as TCTextIngestionPipeline
from retrievalbase.utils import load_class

_logger = logging.getLogger(__name__)


class TextIngestionPipeline[TCTextIngestionPipeline: TextIngestionPipelineSettings[Any, Any]](
    FromConfigMixin[TCTextIngestionPipeline]
):
    def __init__(self, config: TCTextIngestionPipeline) -> None:
        super().__init__(config)

        _logger.info(
            f"Initializing text ingestion pipeline | "
            f"class={self.__class__.__name__} | "
            f"module={self.__class__.__module__}"
        )

        _logger.info(f"Instantiating dataset connector | module_path={self.config.connector.module_path}")
        self.connector: DatasetConnector[Any] = load_class(self.config.connector.module_path).from_config(
            self.config.connector
        )

        _logger.info(f"Instantiating text preprocessor | module_path={self.config.preprocessor.module_path}")
        self.preprocessor: TextPreprocessor[Any] = load_class(self.config.preprocessor.module_path).from_config(
            self.config.preprocessor
        )

    def ingest(self) -> TextDataset[Any]:
        _logger.info("Starting text ingestion")

        ds = self.connector.load_text()

        _logger.info(f"Dataset loaded | rows={len(ds)}")

        _logger.info(f"Applying text preprocessing | preprocessor={self.preprocessor.__class__.__name__}")

        ds = self.preprocessor.apply(ds)

        _logger.info(f"Text ingestion completed | rows={len(ds)}")

        return ds
