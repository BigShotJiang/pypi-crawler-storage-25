# AGENTS.md

## Purpose

This file is the working agreement for contributors and coding agents in `retrievalbase`.
It describes the repository structure, the expected development commands, the coding rules,
the CI contract, and how runtime components are configured and composed.

## Project Structure

Top-level layout:

```text
.
├── AGENTS.md
├── Makefile
├── README.md
├── pyproject.toml
├── src/
│   └── retrievalbase/
│       ├── connector/
│       ├── dataset/
│       │   └── preprocess/
│       ├── evaluation/
│       │   ├── evaluators/
│       │   │   └── python/
│       │   ├── retrievers/
│       │   │   └── dense/
│       │   ├── async_batcher.py
│       │   ├── embedders.py
│       │   ├── processors.py
│       │   ├── rerankers.py
│       │   ├── settings.py
│       │   └── vector_stores.py
│       ├── ingestion/
│       ├── constants.py
│       ├── enums.py
│       ├── exceptions.py
│       ├── mixins.py
│       ├── settings.py
│       ├── types.py
│       └── utils.py
└── tests/
    ├── conftest.py
    ├── fixtures/
    │   ├── components.py
    │   └── data.py
    ├── integration/
    │   ├── test_dataset/
    │   └── test_evaluation/
    └── unit/
        ├── test_config/
        ├── test_connector/
        ├── test_dataset/
        ├── test_evaluation/
        ├── test_ingestion/
        └── test_utils/
```

Module responsibilities:

- `connector/`: I/O boundaries for loading and persisting datasets. Current implementations: parquet and MinIO.
- `dataset/`: dataset abstractions built on Polars, schema-aware text dataset helpers, Hugging Face adapter, preprocessing, token counting.
- `evaluation/`: retrieval/evaluation stack including embedders, processors, async batching, vector stores, rerankers, retrievers, and Python evaluator implementations.
- `ingestion/`: pipelines that load data through a connector and transform it through preprocessors.
- `settings.py`, `mixins.py`, `types.py`, `utils.py`: shared infrastructure for config-driven component loading and typing.
- `tests/unit/`: behavioral unit tests for contracts and isolated logic, grouped by module area under `test_*` subdirectories.
- `tests/integration/`: higher-level component integration tests, also grouped by module area under `test_*` subdirectories.
- `tests/fixtures/`: reusable fake runtimes, fake connectors, shared test data builders, and factories for constructing test components.
- `tests/conftest.py`: global test setup that should stay minimal and broadly reusable.

## Tooling And Commands

This project uses Python `3.11-3.12`, `uv`, `ruff`, `ty`, `bandit`, and `pytest`.

Primary commands:

```bash
make install        # production dependencies
make dev-install    # dev dependencies, extras, pre-commit hooks
make setup-hooks    # install pre-commit hooks only
make format         # ruff format + ruff --fix
make lint           # ruff check
make type-check     # ty check
make security       # bandit
make test           # pytest
make test-cov       # pytest with coverage, minimum 80%
make ci             # lint + type-check + security + test-cov
make ci-fast        # lint + type-check + test
make clean          # remove caches and generated coverage artifacts
```

Preferred execution style:

- Use `make` targets instead of ad hoc commands when possible.
- Treat `make ci` as the local definition of done.
- Use `uv run ...` for direct tool invocation when a `make` target is not enough.
- Run narrow tests during iteration, then run the broader suite before finishing.

## CI Expectations

There is no checked-in GitHub Actions workflow in this repository at the moment.
The effective CI contract is defined by `Makefile` and `pyproject.toml`.

A change is expected to satisfy:

- `make lint`
- `make type-check`
- `make security`
- `make test-cov`

Coverage expectation:

- `test-cov` enforces `--cov-fail-under=80`.
- New behavior should come with tests unless the change is pure refactoring with no externally observable impact.

If you add or change CI automation later:

- Keep the workflow aligned with `make ci`.
- Do not create a separate CI truth that diverges from local developer commands.

## Coding Rules

General rules:

- Keep code typed. New public functions, methods, and classes should have explicit type annotations.
- Prefer small focused classes and functions over large multi-responsibility objects.
- Make data flow obvious. Hidden side effects and implicit mutation should be minimized.
- Prefer composition over deep inheritance trees.
- Keep runtime classes thin; put configuration in settings models and behavior in the component itself.
- Fail early with clear exceptions when config, schema, or external service contracts are invalid.
- Preserve existing naming and module organization unless there is a concrete architectural reason to change it.

Clean code expectations:

- One module should have one clear responsibility.
- Public APIs should express intent directly and avoid clever shortcuts.
- Avoid boolean-flag APIs when separate methods or component types are clearer.
- Keep constructors lightweight. Expensive setup is acceptable only when the object is explicitly an integration boundary.
- Comments should explain non-obvious reasoning, not restate syntax.
- Reuse shared helpers in `utils.py`, `mixins.py`, and base abstractions before adding new duplication.

Inheritance and abstraction:

- Inheritance is used here for stable contracts such as `DatasetConnector`, `TextPreprocessor`, `TokenCounter`, `Embedder`, `VectorStore`, `Retriever`, `Reranker`, and `Evaluator`.
- New subclasses should only extend an existing base if they satisfy the same conceptual contract and lifecycle.
- Do not add inheritance just for code sharing. Use helper functions or composition if the shared logic is incidental.
- Base classes should define contracts and shared lifecycle behavior; subclasses should provide backend-specific implementation.
- When introducing a new component type, define the smallest abstract interface needed by current use cases.

Configuration rules:

- Runtime components are configured through Pydantic settings models derived from `FromConfigMixinSettings`.
- Every dynamically loaded component config must include `module_path`.
- Use `from_config`, `from_yaml`, `from_yaml_async`, `from_settings`, or `from_kwargs` consistently instead of custom factories.
- Respect the configured YAML source order defined in `FromConfigMixinSettings`: init, YAML, env, dotenv, secrets.
- Keep config validation in settings classes, not scattered across runtime code.

## Component Model

The project is config-driven.

Core pattern:

1. A settings model defines the schema for a component.
2. The settings carry a `module_path` string pointing to the concrete runtime class.
3. `load_class(...)` resolves that symbol dynamically.
4. The runtime class is instantiated through `FromConfigMixin`.

Common entry points:

- `retrievalbase.mixins.FromConfigMixin`
- `retrievalbase.settings.FromConfigMixinSettings`
- `retrievalbase.utils.load_class`
- `retrievalbase.utils.comp`

This means components are selected by configuration, not by hard-coded imports in top-level orchestration.

## How Interfaces Work

Important interfaces and base contracts:

- `DatasetConnector`: `_load()` returns Polars data, `to(ds)` persists a dataset, `load()` and `load_text()` wrap the result into repository dataset types.
- `Dataset` / `TextDataset`: expose a dataset abstraction over Polars with convenience methods and schema validation.
- `TextPreprocessor`: transforms a `TextDataset` and returns a `TextDataset`.
- `TokenCounter`: counts tokens for one or many strings.
- `Processor`: preprocesses text for an embedding purpose such as query vs document.
- `Embedder`: async embedding boundary with batching support.
- `VectorStore`: async vector query boundary with batching support and a normalized `QueryResponse`.
- `Reranker`: reranks retrieval candidates after initial retrieval.
- `Retriever`: orchestrates retrieval and optional reranking.
- `Evaluator`: loads dataset plus retriever and produces evaluation metrics.
- `TextIngestionPipeline`: loads a text dataset through a connector, then applies a configured preprocessor.

Interface expectations:

- Contracts should be explicit in abstract base classes.
- Concrete implementations should honor return types exactly.
- Batch APIs must preserve input ordering.
- Async resources should expose `aclose()` when they own clients or sockets.
- Text datasets must preserve `page_content` and `metadata` columns.

## Component Organization And Dependencies

Dependency direction should stay inward and predictable.

Current organization:

- `connector` depends on shared infrastructure and returns `dataset` abstractions.
- `dataset` depends on Polars and shared helpers, and may use connectors only through helper constructors.
- `dataset.preprocess` depends on `dataset` and token counters.
- `ingestion` depends on `connector`, `dataset.preprocess`, and shared dynamic loading.
- `evaluation` depends on `dataset`, shared config/factory utilities, and external retrieval backends.

Expected dependency rules:

- Shared infrastructure modules must not depend on feature modules.
- Concrete backend implementations may depend on external libraries, but abstract contracts should stay backend-agnostic.
- Evaluators depend on retrievers; retrievers may depend on rerankers, embedders, processors, vector stores, and connectors.
- Preprocessors may depend on token counters, but token counters should not depend on preprocessors.
- Connectors should handle transport/storage only, not business rules for preprocessing, retrieval, or scoring.
- Avoid circular dependencies. If a new feature creates one, the abstraction boundary is probably misplaced.

Typical composition chains:

- Ingestion:
  `TextIngestionPipeline -> DatasetConnector -> TextDataset -> TextPreprocessor`
- BM25 retrieval:
  `Retriever -> DatasetConnector -> TextDataset`
- Dense retrieval:
  `Retriever -> Embedder -> Processor -> VectorStore`
- Evaluation:
  `Evaluator -> DatasetConnector + Retriever -> Scores`

## Testing Rules

Testing strategy in this repository is split between unit and integration tests.

Rules:

- Put isolated behavioral tests in `tests/unit/test_<module_area>`.
- Put multi-component or backend-shape integration tests in `tests/integration/test_<module_area>`.
- Reuse `tests/fixtures` for fake runtimes, connectors, preprocessors, data builders, and component factories.
- Build test components through shared fixture factories instead of re-declaring them inline in each test file when the setup is reusable.
- Add a local `conftest.py` only for setup shared by a bounded test group; keep truly global setup in `tests/conftest.py`.
- Test contracts, not just happy paths. Validate schema errors, invalid config, ordering guarantees, and limit handling.
- When adding a new component type, add tests for the abstract contract and for at least one concrete implementation.
- When dynamic loading is involved, test both the settings object path and the runtime behavior.
- Parametrize tests when the same contract should hold across multiple inputs, thresholds, or component variants.

Testing focus areas for this codebase:

- `module_path` resolution and config factories.
- schema validation for text datasets and adapters.
- batching behavior for embedders, vector stores, and rerankers.
- retriever limit semantics, hybrid retrieval behavior, and reranker integration.
- Python evaluator runtime behavior and score calculation.
- connector load/save behavior.
- pipeline behavior for ingestion and preprocessing.

## Change Guidelines For Agents

When modifying this repository:

- Read the affected base class and its settings model before implementing a new concrete component.
- Keep new files inside the existing package slice unless you are introducing a genuinely new subsystem.
- Mirror the test location to the source area you changed using the `tests/unit/test_<module_area>` or `tests/integration/test_<module_area>` layout.
- Prefer extending the typed settings hierarchy over passing raw dicts around.
- Do not bypass the dynamic component model with hard-coded concrete imports in orchestration code unless the change is intentionally local and justified.
- If you add a new optional backend, keep import failures lazy and raise actionable installation guidance.
- Keep public behavior compatible unless a breaking change is explicitly intended and documented.

## Done Criteria

A change is complete when:

- the code follows the existing component and settings patterns,
- tests cover the new or changed behavior,
- `make ci` passes locally,
- no unnecessary dependency layering violations were introduced,
- and the change is understandable to the next contributor without reverse engineering hidden assumptions.
