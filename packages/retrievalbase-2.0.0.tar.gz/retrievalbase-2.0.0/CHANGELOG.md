# [2.0.0](https://gitlab.com/efysent/agentic-core/retrievalbase/compare/v1.0.0...v2.0.0) (2026-05-08)


* feat!: refactor chunk matching and rename retriever parameters ([6cd809d](https://gitlab.com/efysent/agentic-core/retrievalbase/commit/6cd809db72e5f97539d415a6d66cfed3403f6b6b))


### BREAKING CHANGES

* - Renamed retriever method parameters
- Updated chunk-to-retrieval point matching logic in evaluation pipeline

# 1.0.0 (2026-04-19)


### Bug Fixes

* fix deps in ci ([dc69d67](https://gitlab.com/efysent/agentic-core/retrievalbase/commit/dc69d67cc33794c6cd477c7391576db3cf317800))


### Features

* first commit, setup ci ([47b9e29](https://gitlab.com/efysent/agentic-core/retrievalbase/commit/47b9e29b747b07eef2689a6c332c7107d84abc2d))
