from __future__ import annotations

from pathlib import Path

import pytest

from tests.fixtures.components import (
    FAKE_RUNTIME_PATH,
    FakeRuntime,
    FakeRuntimeSettings,
)


def test_from_config_mixin_exposes_config_class() -> None:
    assert FakeRuntime.get_config_class() is FakeRuntimeSettings


def test_from_config_mixin_loads_from_yaml_and_kwargs(tmp_path: Path) -> None:
    config_path = tmp_path / "component.yaml"
    config_path.write_text(
        f"component:\n  module_path: {FAKE_RUNTIME_PATH}\n  value: 7\n",
        encoding="utf-8",
    )

    runtime = FakeRuntime.from_yaml(str(config_path), key="component")
    runtime_from_kwargs = FakeRuntime.from_kwargs(
        module_path=FAKE_RUNTIME_PATH,
        value=11,
    )

    assert runtime.config.value == 7
    assert runtime_from_kwargs.config.value == 11


@pytest.mark.asyncio
async def test_from_config_mixin_supports_async_yaml_factory(tmp_path: Path) -> None:
    config_path = tmp_path / "component.yaml"
    config_path.write_text(
        f"module_path: {FAKE_RUNTIME_PATH}\nvalue: 13\n",
        encoding="utf-8",
    )

    runtime = await FakeRuntime.from_yaml_async(str(config_path))

    assert runtime.config.value == 13
