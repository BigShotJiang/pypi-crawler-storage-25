from __future__ import annotations

import pytest

from retrievalbase.evaluation.settings import FaissVectorStoreSettings


def test_faiss_vector_store_settings_rejects_invalid_values() -> None:
    with pytest.raises(ValueError, match="Invalid FAISS index_type"):
        FaissVectorStoreSettings.model_validate(
            {
                "module_path": "x",
                "index_type": "bogus",
                "normalize": False,
            }
        )
