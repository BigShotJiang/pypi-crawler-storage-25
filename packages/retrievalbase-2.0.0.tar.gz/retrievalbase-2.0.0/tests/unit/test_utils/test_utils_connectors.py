from __future__ import annotations

from retrievalbase.utils import _get_minio_connector, _get_parquet_connector


def test_get_minio_connector_builds_connector_settings() -> None:
    connector = _get_minio_connector("bucket", "key", "endpoint", "ak", "sk")

    assert connector.config.bucket == "bucket"
    assert connector.config.key == "key"
    assert connector.config.endpoint == "endpoint"
    assert connector.config.access_key.get_secret_value() == "ak"
    assert connector.config.secret_key.get_secret_value() == "sk"


def test_get_parquet_connector_builds_connector_settings() -> None:
    connector = _get_parquet_connector("/tmp/data.parquet", lazy=False)

    assert connector.config.path == "/tmp/data.parquet"
    assert connector.config.lazy is False
