from __future__ import annotations

import polars as pl

from retrievalbase.utils import build_schema, comp, extract_schema_columns, load_class
from tests.fixtures.components import FAKE_RUNTIME_PATH, FakeRuntime


def test_load_class_and_comp_create_runtime_from_module_path(tmp_path) -> None:
    config_path = tmp_path / "component.yaml"
    config_path.write_text(
        f"component:\n  module_path: {FAKE_RUNTIME_PATH}\n  value: 17\n",
        encoding="utf-8",
    )

    loaded = load_class(FAKE_RUNTIME_PATH)
    instance = comp(str(config_path), key="component")

    assert loaded is FakeRuntime
    assert instance.config.value == 17


def test_extract_schema_columns_and_build_schema(sample_nested_df: pl.DataFrame) -> None:
    flattened = extract_schema_columns(sample_nested_df.schema)
    selected = build_schema(
        sample_nested_df,
        {
            "text": "page_content",
            "query": "metadata.query",
            "label": "payload.nested.label",
        },
    )

    assert flattened == [
        "page_content",
        "metadata.query",
        "metadata.doc_id",
        "payload.nested.label",
    ]
    assert selected.to_dict(as_series=False) == {
        "text": ["hello", "world"],
        "query": ["q1", "q2"],
        "label": ["x", "y"],
    }
