from __future__ import annotations

from retrievalbase.evaluation.retrievers.dense.retrievers import HybridRetriever


def test_hybrid_retriever_fuses_rankings(response_factory) -> None:
    retriever = object.__new__(HybridRetriever)
    retriever.config = type("Config", (), {"rrf_k": 60})()

    fused = retriever._fuse(
        response_factory("a", "b"),
        response_factory("b", "b"),
        limit=3,
    )

    assert [point.document.page_content for point in fused.points] == ["b", "a"]
