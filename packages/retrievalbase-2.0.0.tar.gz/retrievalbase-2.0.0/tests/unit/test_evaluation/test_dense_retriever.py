from __future__ import annotations

import pytest

from retrievalbase.evaluation.retrievers.dense import DenseRetriever
from tests.fixtures.components import (
    build_dense_retriever_settings,
    build_fake_component_mapping,
    build_load_class,
)


@pytest.mark.asyncio
async def test_dense_retriever_coordinates_embedder_store_and_reranker(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        "retrievalbase.evaluation.retrievers.dense.load_class",
        build_load_class(build_fake_component_mapping()),
    )
    retriever = DenseRetriever(build_dense_retriever_settings())

    batch = await retriever.retrieve_batch(["alpha", "beta"], limit=2, reranker_limit=1)
    single = await retriever.retrieve("alpha", limit=2, reranker_limit=1)

    assert len(batch) == 2
    assert batch[0].points[0].document.page_content.startswith("doc:")
    assert len(single.points) == 1


@pytest.mark.asyncio
async def test_dense_retriever_requires_reranker_limit_with_reranker_and_closes(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        "retrievalbase.evaluation.retrievers.dense.load_class",
        build_load_class(build_fake_component_mapping()),
    )
    retriever = DenseRetriever(build_dense_retriever_settings())

    with pytest.raises(ValueError, match="reranker_limit must be provided"):
        await retriever.retrieve_batch(["alpha"], limit=2)

    assert (await retriever._retrieve("alpha", 1)).points
    await retriever.aclose()
