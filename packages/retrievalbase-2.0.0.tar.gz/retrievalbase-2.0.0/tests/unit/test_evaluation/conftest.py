from __future__ import annotations

from collections.abc import Callable

import pytest
from langchain_core.documents import Document

from retrievalbase.evaluation import VectorStore


@pytest.fixture
def response_factory() -> Callable[..., VectorStore.QueryResponse]:
    def _build(*texts: str) -> VectorStore.QueryResponse:
        return VectorStore.QueryResponse(
            points=[
                VectorStore.ScoredPoint(
                    score=float(len(text)),
                    document=Document(page_content=text, metadata={}),
                )
                for text in texts
            ]
        )

    return _build
