from __future__ import annotations

import asyncio

import pytest

from retrievalbase.evaluation.async_batcher import AsyncBatcher


@pytest.mark.asyncio
async def test_async_batcher_batches_concurrent_calls() -> None:
    recorded_batches: list[list[int]] = []

    async def batch_fn(items: list[int]) -> list[int]:
        recorded_batches.append(items)
        await asyncio.sleep(0)
        return [item * 10 for item in items]

    batcher = AsyncBatcher(batch_fn=batch_fn, max_batch_size=10, batch_timeout_ms=50)
    result = await asyncio.gather(batcher.submit_one(1), batcher.submit_one(2))

    assert result == [10, 20]
    assert recorded_batches == [[1, 2]]


@pytest.mark.asyncio
async def test_async_batcher_propagates_batch_errors() -> None:
    async def failing_batch(items: list[int]) -> list[int]:
        raise RuntimeError("boom")

    batcher = AsyncBatcher(batch_fn=failing_batch, max_batch_size=2, batch_timeout_ms=10)

    with pytest.raises(RuntimeError, match="boom"):
        await batcher.submit([1, 2])


@pytest.mark.asyncio
async def test_async_batcher_rejects_wrong_output_size() -> None:
    async def bad_batch(items: list[int]) -> list[int]:
        return [1]

    batcher = AsyncBatcher(batch_fn=bad_batch, max_batch_size=2, batch_timeout_ms=10)

    with pytest.raises(RuntimeError, match="wrong size"):
        await batcher.submit([1, 2])
