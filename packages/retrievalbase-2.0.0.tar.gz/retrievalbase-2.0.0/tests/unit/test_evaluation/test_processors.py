from __future__ import annotations

from retrievalbase.enums import EmbeddingPurposeEnum
from retrievalbase.evaluation.processors import NomicProcessor
from retrievalbase.evaluation.settings import NomicProcessorSettings


def test_nomic_processor_prefixes_text_by_purpose() -> None:
    processor = NomicProcessor(NomicProcessorSettings(module_path="x"))

    assert processor("doc", EmbeddingPurposeEnum.DOCUMENT) == "search_document: doc"
    assert processor("query", EmbeddingPurposeEnum.QUERY) == "search_query: query"
