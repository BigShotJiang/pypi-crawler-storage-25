from __future__ import annotations

import asyncio
from types import SimpleNamespace

import numpy as np
import pytest
from langchain_core.documents import Document

from retrievalbase.enums import FAISSIndexType
from retrievalbase.evaluation.settings import FaissVectorStoreSettings, QdrantVectorStoreSettings
from retrievalbase.evaluation.vector_stores import FaissVectorStore, QdrantVectorStore
from tests.fixtures.components import EchoVectorStore, EchoVectorStoreSettings


@pytest.mark.asyncio
async def test_vector_store_query_helpers_wrap_request_objects() -> None:
    store = EchoVectorStore(EchoVectorStoreSettings(module_path="x"))

    batch_responses = await store.abatch_query_points([[1.0], [2.0, 3.0]], limit=4)
    single_response = await store.aquery_points([9.0], limit=2)

    assert [r.points[0].score for r in batch_responses] == [1.0, 5.0]
    assert single_response.points[0].document.metadata == {"limit": 2}


def test_faiss_vector_store_indexes_and_queries_documents() -> None:
    store = FaissVectorStore(
        FaissVectorStoreSettings(
            module_path="x",
            index_type=FAISSIndexType.FLAT_IP,
            normalize=False,
        )
    )
    embeddings = np.asarray([[1.0, 0.0], [0.0, 1.0]], dtype="float32")
    store.index = store.build_faiss_index(2)
    store.add_documents(
        [
            Document(page_content="x", metadata={}),
            Document(page_content="y", metadata={}),
        ],
        embeddings,
    )

    response = asyncio.run(store._aquery_points_one([1.0, 0.0], limit=1))

    assert response.points[0].document.page_content == "x"


def test_faiss_vector_store_handles_l2_errors_and_batch_queries() -> None:
    store = FaissVectorStore(
        FaissVectorStoreSettings(
            module_path="x",
            index_type=FAISSIndexType.FLAT_L2,
            normalize=True,
        )
    )

    assert "IndexFlatL2" in type(store.build_faiss_index(2)).__name__

    with pytest.raises(ValueError, match="created before adding"):
        store.add_documents([Document(page_content="x", metadata={})], np.asarray([[1.0, 0.0]], dtype="float32"))

    with pytest.raises(ValueError, match="created before querying"):
        asyncio.run(store._aquery_points_one([1.0, 0.0], limit=1))

    store.index = store.build_faiss_index(2)
    store.add_documents(
        [
            Document(page_content="x", metadata={}),
            Document(page_content="y", metadata={}),
        ],
        np.asarray([[1.0, 0.0], [0.0, 1.0]], dtype="float32"),
    )

    responses = asyncio.run(
        store._abatch_query_points(
            [
                store.VectorQuery(vector=[1.0, 0.0], limit=1),
                store.VectorQuery(vector=[0.0, 1.0], limit=1),
            ]
        )
    )

    assert [response.points[0].document.page_content for response in responses] == ["x", "y"]
    with pytest.raises(ValueError, match="empty list"):
        asyncio.run(store._abatch_query_points([]))


def test_qdrant_vector_store_parses_payloads_and_validates_required_fields() -> None:
    store = object.__new__(QdrantVectorStore)
    store.config = SimpleNamespace(collection_name="docs")

    valid_response = SimpleNamespace(
        points=[
            SimpleNamespace(
                score=0.7,
                payload={"page_content": "hello", "metadata": {"a": 1}},
            )
        ]
    )
    parsed = store._parse_query_response(valid_response)

    assert parsed.points[0].document.page_content == "hello"
    assert parsed.points[0].document.metadata == {"a": 1}

    with pytest.raises(ValueError, match="no payload"):
        store._parse_query_response(SimpleNamespace(points=[SimpleNamespace(score=0.7, payload=None)]))

    with pytest.raises(KeyError, match="page_content"):
        store._parse_query_response(SimpleNamespace(points=[SimpleNamespace(score=0.7, payload={"x": 1})]))


@pytest.mark.asyncio
async def test_qdrant_vector_store_batches_queries_and_closes(monkeypatch: pytest.MonkeyPatch) -> None:
    captured: dict[str, object] = {}

    class FakeClient:
        def __init__(self, *, url: str, timeout: int | None) -> None:
            captured["init"] = {"url": url, "timeout": timeout}

        async def query_batch_points(self, *, collection_name: str, requests: list[object]) -> list[object]:
            captured["collection_name"] = collection_name
            captured["requests_len"] = len(requests)
            return [
                SimpleNamespace(
                    points=[
                        SimpleNamespace(
                            score=0.9,
                            payload={"page_content": "hello", "metadata": {"doc_id": "1"}},
                        )
                    ]
                )
            ]

        async def close(self) -> None:
            captured["closed"] = True

    monkeypatch.setattr("retrievalbase.evaluation.vector_stores.AsyncQdrantClient", FakeClient)

    store = QdrantVectorStore(
        QdrantVectorStoreSettings(
            module_path="x",
            url="http://qdrant.local",
            collection_name="docs",
            timeout=5,
        )
    )

    responses = await store._abatch_query_points([store.VectorQuery(vector=[1.0], limit=2)])
    await store.aclose()

    assert responses[0].points[0].document.page_content == "hello"
    assert captured == {
        "init": {"url": "http://qdrant.local", "timeout": 5},
        "collection_name": "docs",
        "requests_len": 1,
        "closed": True,
    }
