from __future__ import annotations

from types import SimpleNamespace
from typing import Any, cast

import pytest
from langchain_core.documents import Document

from retrievalbase.evaluation import VectorStore
from retrievalbase.evaluation.retrievers.dense.retrievers import HybridRetriever


class FakeSubRetriever:
    def __init__(self, name: str) -> None:
        self.name = name
        self.closed = False

    @classmethod
    def from_config(cls, config: Any) -> FakeSubRetriever:
        return cls(config.module_path)

    async def retrieve(self, query: str, limit: int) -> VectorStore.QueryResponse:
        return VectorStore.QueryResponse(
            points=[
                VectorStore.ScoredPoint(
                    score=1.0,
                    document=Document(page_content=f"{self.name}:{query}", metadata={}),
                )
            ]
        )

    async def aclose(self) -> None:
        self.closed = True


@pytest.mark.asyncio
async def test_hybrid_retriever_initializes_retrieves_and_closes(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(
        "retrievalbase.evaluation.retrievers.dense.retrievers.load_class",
        lambda path: FakeSubRetriever,
    )
    retriever = HybridRetriever(
        cast(
            Any,
            SimpleNamespace(
                module_path="x",
                reranker=None,
                dense_retriever=SimpleNamespace(module_path="dense"),
                bm25_retriever=SimpleNamespace(module_path="bm25"),
                rrf_k=60,
            ),
        )
    )

    response = await retriever._retrieve("alpha", limit=2)
    await retriever.aclose()

    assert len(response.points) == 2
    assert cast(FakeSubRetriever, retriever.dense).closed is True
    assert cast(FakeSubRetriever, retriever.bm25).closed is True
