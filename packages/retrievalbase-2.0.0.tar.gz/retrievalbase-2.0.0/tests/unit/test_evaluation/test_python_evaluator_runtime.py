from __future__ import annotations

from types import SimpleNamespace
from typing import Any

import pytest
from langchain_core.documents import Document

from retrievalbase.connector.settings import DatasetConnectorSettings
from retrievalbase.evaluation import VectorStore
from retrievalbase.evaluation.evaluators import Evaluator
from retrievalbase.evaluation.evaluators.python import PythonEvaluator, Score
from retrievalbase.evaluation.settings import (
    EvaluatorSettings,
    PythonEvaluatorSettings,
    RerankerSettings,
    RetrieverSettings,
    ScoreSettings,
)
from tests.fixtures.components import build_fake_dataset_connector_settings
from tests.fixtures.data import make_text_dataset


class FakeRetrieverSettings(RetrieverSettings[RerankerSettings]):
    pass


class FakeScoreSettings(ScoreSettings):
    metric_name: str


class FakeRetriever:
    def __init__(self, config: FakeRetrieverSettings) -> None:
        self.config = config
        self.calls: list[tuple[list[str], int, int | None]] = []

    @classmethod
    def from_config(cls, config: FakeRetrieverSettings) -> FakeRetriever:
        return cls(config)

    async def retrieve_batch(
        self,
        queries: list[str],
        limit: int,
        reranker_limit: int | None = None,
    ) -> list[VectorStore.QueryResponse]:
        self.calls.append((queries, limit, reranker_limit))
        return [
            VectorStore.QueryResponse(
                points=[
                    VectorStore.ScoredPoint(
                        score=1.0,
                        document=Document(page_content=f"{query} text", metadata={"doc_id": query, "chunk_id": 0}),
                    )
                    for _ in range(reranker_limit if reranker_limit is not None else limit)
                ]
            )
            for query in queries
        ]


class FakeScore(Score[FakeScoreSettings]):
    def __call__(self, hits: list[bool], total_relevant: int | None = None) -> list[Score.ScoreResult]:
        return [self.ScoreResult(name=self.config.metric_name, value=float(sum(hits)))]


class ConcreteEvaluator(Evaluator[EvaluatorSettings[DatasetConnectorSettings, FakeRetrieverSettings]]):
    async def eval(self) -> dict[str, float]:
        return {"ok": 1.0}


class ConcretePythonEvaluator(
    PythonEvaluator[PythonEvaluatorSettings[DatasetConnectorSettings, FakeRetrieverSettings]]
):
    pass


def _mapping() -> dict[str, type[Any]]:
    return {
        "tests.fake.FakeRetriever": FakeRetriever,
        "tests.fake.FakeScore": FakeScore,
    }


def test_evaluator_loads_dataset_and_retriever(monkeypatch: pytest.MonkeyPatch) -> None:
    def fake_load_class(path: str) -> type[Any]:
        if path == "tests.fixtures.components.FakeDatasetConnector":
            from tests.fixtures.components import FakeDatasetConnector

            return FakeDatasetConnector
        return _mapping()[path]

    monkeypatch.setattr("retrievalbase.evaluation.evaluators.load_class", fake_load_class)

    evaluator = ConcreteEvaluator(
        EvaluatorSettings[DatasetConnectorSettings, FakeRetrieverSettings](
            module_path="x",
            dataset_connector=build_fake_dataset_connector_settings(),
            retriever=FakeRetrieverSettings(module_path="tests.fake.FakeRetriever", reranker=None),
        )
    )

    assert len(evaluator.dataset) == 3
    assert isinstance(evaluator.retriever, FakeRetriever)


def test_python_evaluator_batch_iter_get_max_k_and_empty_aggregate() -> None:
    evaluator = object.__new__(ConcretePythonEvaluator)
    evaluator.dataset = make_text_dataset()
    evaluator.BATCH_SIZE = 2
    evaluator.scores = [FakeScore(FakeScoreSettings(module_path="tests.fake.FakeScore", ks=[1, 3], metric_name="m"))]

    batches = list(evaluator.batch_iter())

    assert [len(batch) for batch in batches] == [2, 1]
    assert evaluator._get_max_k() == 3
    assert evaluator._aggregate_scores([]) == {}


def test_python_evaluator_build_retrieval_tasks_without_reranker() -> None:
    evaluator = object.__new__(ConcretePythonEvaluator)
    evaluator.dataset = make_text_dataset()
    evaluator.BATCH_SIZE = 2
    evaluator.scores = [FakeScore(FakeScoreSettings(module_path="tests.fake.FakeScore", ks=[2], metric_name="m"))]
    evaluator.retriever = FakeRetriever(FakeRetrieverSettings(module_path="tests.fake.FakeRetriever", reranker=None))
    evaluator.config = SimpleNamespace(retriever=SimpleNamespace(reranker=None), limit=5)

    batches, tasks = evaluator._build_retrieval_tasks(2)

    assert len(batches) == 2
    assert len(tasks) == 2
    for task in tasks:
        task.close()


def test_python_evaluator_build_retrieval_tasks_with_reranker() -> None:
    evaluator = object.__new__(ConcretePythonEvaluator)
    evaluator.dataset = make_text_dataset()
    evaluator.BATCH_SIZE = 2
    evaluator.scores = [FakeScore(FakeScoreSettings(module_path="tests.fake.FakeScore", ks=[2], metric_name="m"))]
    evaluator.retriever = FakeRetriever(FakeRetrieverSettings(module_path="tests.fake.FakeRetriever", reranker=None))
    evaluator.config = SimpleNamespace(retriever=SimpleNamespace(reranker=object()), limit=5)

    _, tasks = evaluator._build_retrieval_tasks(2)

    assert len(tasks) == 2
    for task in tasks:
        task.close()


def test_python_evaluator_scores_hits_by_doc_id_and_chunk_id() -> None:
    evaluator = object.__new__(ConcretePythonEvaluator)
    evaluator.dataset = make_text_dataset(
        [
            {"page_content": "alpha chunk 0", "metadata": {"doc_id": "a", "chunk_id": 0, "query": "alpha"}},
            {"page_content": "alpha chunk 1", "metadata": {"doc_id": "a", "chunk_id": 1, "query": "alpha"}},
        ]
    )
    evaluator.scores = [FakeScore(FakeScoreSettings(module_path="tests.fake.FakeScore", ks=[2], metric_name="m"))]
    evaluator.NB_LOGS_PER_QUERIES = 100
    dataset_rows = list(evaluator.dataset.iter_rows(named=True))

    scores_all = evaluator._score_batches(
        [[dataset_rows[0]]],
        [
            [
                VectorStore.QueryResponse(
                    points=[
                        VectorStore.ScoredPoint(
                            score=1.0,
                            document=Document(
                                page_content=dataset_rows[0]["page_content"],
                                metadata=dataset_rows[0]["metadata"],
                            ),
                        ),
                        VectorStore.ScoredPoint(
                            score=0.5,
                            document=Document(
                                page_content=dataset_rows[1]["page_content"],
                                metadata=dataset_rows[1]["metadata"],
                            ),
                        ),
                    ]
                )
            ]
        ],
    )

    assert scores_all == [{"m": 1.0}]


@pytest.mark.asyncio
async def test_python_evaluator_collects_and_evaluates(monkeypatch: pytest.MonkeyPatch) -> None:
    def fake_load_class(path: str) -> type[Any]:
        if path == "tests.fixtures.components.FakeDatasetConnector":
            from tests.fixtures.components import FakeDatasetConnector

            return FakeDatasetConnector
        return _mapping()[path]

    monkeypatch.setattr("retrievalbase.evaluation.evaluators.load_class", fake_load_class)
    monkeypatch.setattr("retrievalbase.evaluation.evaluators.python.load_class", fake_load_class)

    evaluator = ConcretePythonEvaluator(
        PythonEvaluatorSettings[DatasetConnectorSettings, FakeRetrieverSettings](
            module_path="x",
            dataset_connector=build_fake_dataset_connector_settings(
                [
                    {"page_content": "alpha text", "metadata": {"doc_id": "alpha", "chunk_id": 0, "query": "alpha"}},
                    {"page_content": "beta text", "metadata": {"doc_id": "beta", "chunk_id": 0, "query": "beta"}},
                    {"page_content": "gamma text", "metadata": {"doc_id": "gamma", "chunk_id": 0, "query": "gamma"}},
                ]
            ),
            retriever=FakeRetrieverSettings(module_path="tests.fake.FakeRetriever", reranker=None),
            scores=[FakeScoreSettings(module_path="tests.fake.FakeScore", ks=[1], metric_name="metric")],
            limit=None,
        )
    )

    gathered = await evaluator._collect_responses([evaluator.retriever.retrieve_batch(["alpha"], 1)])
    results = await evaluator.eval()

    assert gathered[0][0].points[0].document.page_content == "alpha text"
    assert results == {"metric": 1.0}
