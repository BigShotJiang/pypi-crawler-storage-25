from __future__ import annotations

import asyncio
from types import SimpleNamespace

import pytest

from retrievalbase.evaluation.embedders import OpenAICompatibleEmbedder
from retrievalbase.evaluation.settings import OpenAICompatibleEmbedderSettings
from tests.fixtures.components import (
    PrefixProcessor,
    PrefixProcessorSettings,
    RecordingEmbedder,
    RecordingEmbedderSettings,
)


@pytest.mark.asyncio
async def test_embedder_applies_processor_for_queries_and_documents() -> None:
    embedder = RecordingEmbedder(RecordingEmbedderSettings(module_path="x", model_name="dummy"))
    processor = PrefixProcessor(PrefixProcessorSettings(module_path="x", prefix="processed"))

    query_embedding = await embedder.aembed_query("alpha", processor=processor)
    document_embeddings = await embedder.aembed_documents(["beta"], processor=processor)

    assert embedder.calls == [
        ["query:processed:alpha"],
        ["document:processed:beta"],
    ]
    assert query_embedding == [float(len("query:processed:alpha"))]
    assert document_embeddings == [[float(len("document:processed:beta"))]]


def test_openai_compatible_embedder_uses_client_embeddings_api(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    captured: dict[str, object] = {}

    class FakeEmbeddings:
        async def create(self, *, model: str, input: list[str]) -> object:
            captured["model"] = model
            captured["input"] = input
            return SimpleNamespace(data=[SimpleNamespace(embedding=[1.0, 2.0])])

    class FakeClient:
        def __init__(self, *, base_url: str) -> None:
            captured["base_url"] = base_url
            self.embeddings = FakeEmbeddings()

    monkeypatch.setattr("retrievalbase.evaluation.embedders.AsyncOpenAI", FakeClient)
    embedder = OpenAICompatibleEmbedder(
        OpenAICompatibleEmbedderSettings(
            module_path="x",
            model_name="embed-model",
            base_url="https://api.local",
        )
    )

    result = asyncio.run(embedder._aembed(["hello"]))

    assert result == [[1.0, 2.0]]
    assert captured == {
        "base_url": "https://api.local",
        "model": "embed-model",
        "input": ["hello"],
    }
