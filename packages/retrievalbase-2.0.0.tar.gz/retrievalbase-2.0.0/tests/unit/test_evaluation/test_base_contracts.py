from __future__ import annotations

import asyncio

import polars as pl
import pytest
from langchain_core.documents import Document

from retrievalbase.connector import DatasetConnector
from retrievalbase.connector.settings import DatasetConnectorSettings
from retrievalbase.dataset.polars import PolarsTextDataset
from retrievalbase.dataset.preprocess import TextPreprocessor, TokenCounter
from retrievalbase.dataset.settings import TextPreprocessorSettings, TokenCounterSettings
from retrievalbase.enums import EmbeddingPurposeEnum
from retrievalbase.evaluation import Embedder, Processor, Reranker, VectorStore
from retrievalbase.evaluation.evaluators import Evaluator
from retrievalbase.evaluation.evaluators.python import Score
from retrievalbase.evaluation.settings import (
    EmbedderSettings,
    EvaluatorSettings,
    ProcessorSettings,
    RerankerSettings,
    RetrieverSettings,
    ScoreSettings,
    VectorStoreSettings,
)


class RaisingConnector(DatasetConnector[DatasetConnectorSettings]):
    def _load(self) -> pl.DataFrame | pl.LazyFrame:
        return super()._load()

    def to(self, ds) -> None:
        super().to(ds)


class RaisingPreprocessor(TextPreprocessor[TextPreprocessorSettings]):
    def apply(self, ds):
        return super().apply(ds)


class RaisingTokenCounter(TokenCounter[TokenCounterSettings]):
    def count(self, text: str) -> int:
        return super().count(text)


class RaisingProcessor(Processor[ProcessorSettings]):
    def __call__(self, text: str, purpose: EmbeddingPurposeEnum) -> str:
        return super().__call__(text, purpose)


class RaisingEmbedder(Embedder[EmbedderSettings]):
    async def _aembed(self, texts: list[str]) -> list[list[float]]:
        return await super()._aembed(texts)


class RaisingVectorStore(VectorStore[VectorStoreSettings]):
    async def _abatch_query_points(self, requests):
        return await super()._abatch_query_points(requests)


class RaisingReranker(Reranker[RerankerSettings]):
    async def rerank(self, query: str, response: VectorStore.QueryResponse, limit: int):
        return await super().rerank(query, response, limit)


class RaisingScore(Score[ScoreSettings]):
    def __call__(self, hits: list[bool], total_relevant: int | None = None):
        if total_relevant is None:
            return super().__call__(hits)
        return super().__call__(hits, total_relevant)


class RaisingEvaluator(Evaluator[EvaluatorSettings[DatasetConnectorSettings, RetrieverSettings[RerankerSettings]]]):
    async def eval(self) -> dict[str, float]:
        return await super().eval()


def test_base_contracts_raise_not_implemented_and_noops() -> None:
    connector = RaisingConnector(DatasetConnectorSettings(module_path="x"))
    preprocessor = RaisingPreprocessor(TextPreprocessorSettings(module_path="x", kind="noop"))
    counter = RaisingTokenCounter(TokenCounterSettings(module_path="x"))
    processor = RaisingProcessor(ProcessorSettings(module_path="x"))
    embedder = RaisingEmbedder(EmbedderSettings(module_path="x", model_name="m"))
    store = RaisingVectorStore(VectorStoreSettings(module_path="x"))
    reranker = RaisingReranker(RerankerSettings(module_path="x"))
    score = RaisingScore(ScoreSettings(module_path="x", ks=[1]))

    response = VectorStore.QueryResponse(
        points=[VectorStore.ScoredPoint(score=1.0, document=Document(page_content="x", metadata={}))]
    )

    with pytest.raises(NotImplementedError):
        connector._load()
    with pytest.raises(NotImplementedError):
        connector.to(PolarsTextDataset.from_records([("x", {"doc_id": "1"})]))
    with pytest.raises(NotImplementedError):
        preprocessor.apply(PolarsTextDataset.from_records([("x", {"doc_id": "1"})]))
    with pytest.raises(NotImplementedError):
        counter.count("x")
    with pytest.raises(NotImplementedError):
        processor("x", EmbeddingPurposeEnum.QUERY)
    with pytest.raises(NotImplementedError):
        asyncio.run(embedder._aembed(["x"]))
    with pytest.raises(NotImplementedError):
        asyncio.run(store._abatch_query_points([]))
    with pytest.raises(NotImplementedError):
        asyncio.run(reranker.rerank("q", response, 1))
    with pytest.raises(NotImplementedError):
        score([True], total_relevant=1)


def test_evaluator_eval_base_method_raises_not_implemented() -> None:
    evaluator = object.__new__(RaisingEvaluator)

    with pytest.raises(NotImplementedError):
        asyncio.run(evaluator.eval())


@pytest.mark.asyncio
async def test_base_async_noop_lifecycle_methods_return_none() -> None:
    class DummyEmbedder(Embedder[EmbedderSettings]):
        async def _aembed(self, texts: list[str]) -> list[list[float]]:
            return [[float(len(text))] for text in texts]

    class DummyVectorStore(VectorStore[VectorStoreSettings]):
        async def _abatch_query_points(self, requests):
            return [
                VectorStore.QueryResponse(
                    points=[VectorStore.ScoredPoint(score=1.0, document=Document(page_content="x", metadata={}))]
                )
                for _ in requests
            ]

    class DummyReranker(Reranker[RerankerSettings]):
        async def rerank(self, query: str, response: VectorStore.QueryResponse, limit: int):
            return response

    assert await DummyEmbedder(EmbedderSettings(module_path="x", model_name="m")).aclose() is None
    assert await DummyVectorStore(VectorStoreSettings(module_path="x")).aclose() is None
    assert await DummyReranker(RerankerSettings(module_path="x")).aclose() is None
