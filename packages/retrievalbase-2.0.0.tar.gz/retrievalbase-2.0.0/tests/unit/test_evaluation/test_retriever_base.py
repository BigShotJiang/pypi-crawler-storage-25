from __future__ import annotations

import pytest
from langchain_core.documents import Document

from retrievalbase.evaluation import VectorStore
from retrievalbase.evaluation.retrievers import Retriever
from retrievalbase.evaluation.settings import RerankerSettings, RetrieverSettings
from tests.fixtures.components import ReverseReranker, ReverseRerankerSettings


class DummyRetrieverSettings(RetrieverSettings[RerankerSettings]):
    pass


class DummyRetriever(Retriever[DummyRetrieverSettings]):
    def __init__(self, config: DummyRetrieverSettings) -> None:
        super().__init__(config)
        self.calls: list[tuple[str, int]] = []

    async def _retrieve(self, query: str, limit: int) -> VectorStore.QueryResponse:
        self.calls.append((query, limit))
        return VectorStore.QueryResponse(
            points=[
                VectorStore.ScoredPoint(
                    score=1.0,
                    document=Document(page_content=query, metadata={}),
                )
                for _ in range(limit)
            ]
        )


class SuperRetriever(Retriever[DummyRetrieverSettings]):
    async def _retrieve(self, query: str, limit: int) -> VectorStore.QueryResponse:
        result = await super()._retrieve(query, limit)
        return result


@pytest.mark.asyncio
async def test_retriever_validates_reranker_limit_usage() -> None:
    retriever = DummyRetriever(DummyRetrieverSettings(module_path="x", reranker=None))

    response = await retriever.retrieve("query", limit=2)
    assert response.points[0].document.page_content == "query"

    with pytest.raises(ValueError, match="cannot be used without a reranker"):
        await retriever.retrieve("query", limit=2, reranker_limit=1)


@pytest.mark.asyncio
async def test_retriever_uses_reranker_batch_and_aclose(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("retrievalbase.evaluation.retrievers.load_class", lambda path: ReverseReranker)
    retriever = DummyRetriever(
        DummyRetrieverSettings(module_path="x", reranker=ReverseRerankerSettings(module_path="x"))
    )

    response = await retriever.retrieve("query", limit=2, reranker_limit=1)
    batch = await retriever.retrieve_batch(["a", "b"], limit=2, reranker_limit=1)

    assert len(response.points) == 1
    assert len(batch) == 2
    assert await retriever.aclose() is None
