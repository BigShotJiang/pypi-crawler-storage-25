from __future__ import annotations

import sys
from types import ModuleType, SimpleNamespace
from typing import cast

import pytest
from langchain_core.documents import Document

from retrievalbase.evaluation import VectorStore
from retrievalbase.evaluation.rerankers import HFReranker
from retrievalbase.evaluation.settings import HFRerankerSettings


def _settings() -> HFRerankerSettings:
    return HFRerankerSettings(
        module_path="retrievalbase.evaluation.rerankers.HFReranker",
        model_name="dummy",
        revision="main",
        device="cpu",
    )


def _response(*texts: str) -> VectorStore.QueryResponse:
    return VectorStore.QueryResponse(
        points=[VectorStore.ScoredPoint(score=0.0, document=Document(page_content=text, metadata={})) for text in texts]
    )


def test_hf_reranker_raises_when_dependencies_missing(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setitem(sys.modules, "torch", None)
    monkeypatch.setitem(sys.modules, "transformers", None)

    with pytest.raises(ImportError, match="requires torch \\+ transformers"):
        HFReranker(_settings())


@pytest.mark.asyncio
async def test_hf_reranker_handles_empty_and_reranks(monkeypatch: pytest.MonkeyPatch) -> None:
    captured: dict[str, object] = {}

    class FakeTensor:
        def __init__(self, values: list[float]) -> None:
            self.values = values

        def to(self, device: str) -> FakeTensor:
            if "devices" not in captured:
                captured["devices"] = []
            cast(list[str], captured["devices"]).append(device)
            return self

        def squeeze(self, dim: int) -> FakeTensor:
            return self

        def cpu(self) -> FakeTensor:
            return self

        def tolist(self) -> list[float]:
            return self.values

    class FakeNoGrad:
        def __enter__(self) -> None:
            return None

        def __exit__(self, exc_type, exc, tb) -> None:
            return None

    class FakeModel:
        device = "cpu"

        def to(self, device: str) -> FakeModel:
            captured["model_device"] = device
            self.device = device
            return self

        def eval(self) -> None:
            captured["eval_called"] = True

        def __call__(self, **inputs: object) -> SimpleNamespace:
            captured["model_inputs"] = inputs
            return SimpleNamespace(logits=FakeTensor([0.1, 0.9]))

    class AutoModelForSequenceClassification:
        @staticmethod
        def from_pretrained(model_name: str, revision: str | None) -> FakeModel:
            captured["model_name"] = model_name
            captured["revision"] = revision
            return FakeModel()

    class FakeTokenizer:
        def __call__(self, batch: list[tuple[str, str]], **kwargs: object) -> dict[str, FakeTensor]:
            captured["batch"] = batch
            captured["tokenizer_kwargs"] = kwargs
            return {"input_ids": FakeTensor([1.0, 2.0]), "attention_mask": FakeTensor([1.0, 1.0])}

    class AutoTokenizer:
        @staticmethod
        def from_pretrained(model_name: str, revision: str | None = None) -> FakeTokenizer:
            captured["tokenizer_model_name"] = model_name
            captured["tokenizer_revision"] = revision
            return FakeTokenizer()

    fake_torch = ModuleType("torch")
    monkeypatch.setattr(fake_torch, "no_grad", lambda: FakeNoGrad(), raising=False)
    fake_transformers = ModuleType("transformers")
    monkeypatch.setattr(fake_transformers, "AutoTokenizer", AutoTokenizer, raising=False)
    monkeypatch.setattr(
        fake_transformers,
        "AutoModelForSequenceClassification",
        AutoModelForSequenceClassification,
        raising=False,
    )
    monkeypatch.setitem(sys.modules, "torch", fake_torch)
    monkeypatch.setitem(sys.modules, "transformers", fake_transformers)

    reranker = HFReranker(_settings())
    reranker.batch_size = 2

    assert reranker._batchify([("q", "a"), ("q", "b"), ("q", "c")]).__next__() == [("q", "a"), ("q", "b")]
    assert await reranker.rerank("query", _response(), 1) == _response()

    reranked = await reranker.rerank("query", _response("first", "second"), 1)

    assert reranked.points[0].document.page_content == "second"
    assert captured["eval_called"] is True
    assert captured["tokenizer_kwargs"] == {
        "padding": True,
        "truncation": True,
        "return_tensors": "pt",
    }
