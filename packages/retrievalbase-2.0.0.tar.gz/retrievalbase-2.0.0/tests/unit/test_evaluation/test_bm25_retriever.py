from __future__ import annotations

import pytest

from retrievalbase.connector.settings import DatasetConnectorSettings
from retrievalbase.dataset.polars import PolarsTextDataset
from retrievalbase.evaluation.retrievers import BM25Retriever
from retrievalbase.evaluation.settings import BM25RetrieverSettings, RerankerSettings
from tests.fixtures.data import make_text_dataset


def test_bm25_retriever_returns_best_matching_documents(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    dataset: PolarsTextDataset = make_text_dataset(
        [
            {"page_content": "alpha beta", "metadata": {"doc_id": "1", "query": "alpha"}},
            {"page_content": "gamma delta", "metadata": {"doc_id": "2", "query": "gamma"}},
        ]
    )

    class FakeConnector:
        @classmethod
        def from_config(cls, _config: object) -> FakeConnector:
            return cls()

        def load_text(self) -> PolarsTextDataset:
            return dataset

    monkeypatch.setattr(
        "retrievalbase.evaluation.retrievers.load_class",
        lambda path: FakeConnector,
    )
    retriever = BM25Retriever(
        BM25RetrieverSettings[DatasetConnectorSettings, RerankerSettings](
            module_path="x",
            dataset_connector=DatasetConnectorSettings(module_path="fake"),
            reranker=None,
        )
    )

    response = retriever._retrieve_sync("alpha", limit=1)

    assert response.points[0].document.page_content == "alpha beta"


@pytest.mark.asyncio
async def test_bm25_retriever_async_retrieve_and_build_response(monkeypatch: pytest.MonkeyPatch) -> None:
    dataset: PolarsTextDataset = make_text_dataset(
        [
            {"page_content": "alpha beta", "metadata": {"doc_id": "1", "query": "alpha"}},
            {"page_content": "gamma delta", "metadata": {"doc_id": "2", "query": "gamma"}},
        ]
    )

    class FakeConnector:
        @classmethod
        def from_config(cls, _config: object) -> FakeConnector:
            return cls()

        def load_text(self) -> PolarsTextDataset:
            return dataset

    monkeypatch.setattr("retrievalbase.evaluation.retrievers.load_class", lambda path: FakeConnector)
    retriever = BM25Retriever(
        BM25RetrieverSettings[DatasetConnectorSettings, RerankerSettings](
            module_path="x",
            dataset_connector=DatasetConnectorSettings(module_path="fake"),
            reranker=None,
        )
    )

    response = await retriever._retrieve("gamma", limit=1)
    built = retriever._build_response([0.2, 0.8], [1])

    assert len(response.points) == 1
    assert response.points[0].document.page_content in {"alpha beta", "gamma delta"}
    assert built.points[0].score == 0.8
