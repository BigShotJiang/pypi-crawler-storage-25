from __future__ import annotations

from types import SimpleNamespace
from typing import Any, cast

import numpy as np
import pytest

from retrievalbase.evaluation.evaluators.python.evaluators import (
    DensePythonEvaluator,
    FaissPythonEvaluator,
)
from tests.fixtures.data import make_text_dataset


def test_dense_python_evaluator_rejects_non_dense_retriever(monkeypatch: pytest.MonkeyPatch) -> None:
    def fake_init(self, config: object) -> None:
        self.retriever = object()
        self.dataset = make_text_dataset()

    monkeypatch.setattr("retrievalbase.evaluation.evaluators.python.evaluators.PythonEvaluator.__init__", fake_init)
    evaluator = object.__new__(DensePythonEvaluator)

    with pytest.raises(TypeError, match="requires a DenseRetriever"):
        DensePythonEvaluator.__init__(evaluator, SimpleNamespace())


@pytest.mark.asyncio
async def test_faiss_python_evaluator_create_indexes_documents(monkeypatch: pytest.MonkeyPatch) -> None:
    class FakeEmbedder:
        async def aembed_documents(self, texts: list[str], processor: object | None = None) -> list[list[float]]:
            return [[float(i + 1), 0.0] for i, _ in enumerate(texts)]

    class FakeVectorStore:
        def __init__(self) -> None:
            self.index = None
            self.added: tuple[list[object], np.ndarray] | None = None

        def build_faiss_index(self, dim: int) -> str:
            return f"index:{dim}"

        def add_documents(self, docs, embeddings: np.ndarray) -> None:
            self.added = (docs, embeddings)

    def fake_init(self, config: object) -> None:
        self.dataset = make_text_dataset(
            [
                {"page_content": "alpha", "metadata": {"doc_id": "1", "query": "alpha"}},
                {"page_content": "beta", "metadata": {"doc_id": "2", "query": "beta"}},
                {"page_content": "alpha duplicate", "metadata": {"doc_id": "1", "query": "alpha"}},
            ]
        )
        self.retriever = SimpleNamespace(embedder=FakeEmbedder(), processor=object(), vector_store=FakeVectorStore())

    monkeypatch.setattr(
        "retrievalbase.evaluation.evaluators.python.evaluators.FaissPythonEvaluator.__init__", fake_init
    )

    created = await FaissPythonEvaluator.create(SimpleNamespace())
    retriever = cast(Any, created.retriever)

    assert retriever.vector_store.index == "index:2"
    assert retriever.vector_store.added is not None
    assert [doc.metadata["doc_id"] for doc in retriever.vector_store.added[0]] == ["1", "2"]


def test_get_docs_returns_unique_documents_by_doc_id() -> None:
    evaluator = object.__new__(FaissPythonEvaluator)
    evaluator.dataset = make_text_dataset(
        [
            {"page_content": "alpha", "metadata": {"doc_id": "1", "query": "alpha"}},
            {"page_content": "beta", "metadata": {"doc_id": "2", "query": "beta"}},
            {"page_content": "alpha duplicate", "metadata": {"doc_id": "1", "query": "alpha"}},
        ]
    )

    docs = evaluator.get_docs()

    assert [doc.metadata["doc_id"] for doc in docs] == ["1", "2"]
