from __future__ import annotations

import io
from typing import TypedDict, cast

import polars as pl
import pytest
from pydantic import SecretStr

from retrievalbase.connector.minio import MinioDatasetConnector
from retrievalbase.connector.parquet import ParquetDatasetConnector
from retrievalbase.connector.settings import (
    MinioDatasetConnectorSettings,
    ParquetDatasetConnectorSettings,
)
from retrievalbase.dataset import Dataset, TextDataset
from retrievalbase.dataset.polars import PolarsDataset, PolarsTextDataset
from tests.fixtures.data import make_text_dataframe


class MinioInitCall(TypedDict):
    endpoint: str
    access_key: str
    secret_key: str
    secure: bool


class MinioPutCall(TypedDict):
    bucket_name: str
    object_name: str
    length: int
    content_type: str
    payload: dict[str, list[object]]


def test_dataset_factory_methods_delegate_to_connectors(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from retrievalbase import dataset as dataset_module

    sample_text_df = make_text_dataframe()

    class FakeConnector:
        def __init__(self) -> None:
            self.calls: list[str] = []

        def load(self) -> PolarsDataset:
            self.calls.append("load")
            return PolarsDataset.from_polars(sample_text_df)

        def load_text(self) -> PolarsTextDataset:
            self.calls.append("load_text")
            return PolarsTextDataset.from_polars(sample_text_df)

        def to(self, ds: Dataset[object]) -> None:
            self.calls.append(f"to:{len(ds)}")

    parquet_connector = FakeConnector()
    minio_connector = FakeConnector()
    monkeypatch.setattr(dataset_module, "_get_parquet_connector", lambda *args, **kwargs: parquet_connector)
    monkeypatch.setattr(dataset_module, "_get_minio_connector", lambda *args, **kwargs: minio_connector)

    dataset = Dataset.from_parquet("data.parquet")
    text_dataset = TextDataset.from_minio("bucket", "key", "endpoint", "ak", "sk")
    dataset.to_parquet("out.parquet")
    text_dataset.to_minio("bucket", "key", "endpoint", "ak", "sk")

    assert parquet_connector.calls == ["load", "to:3"]
    assert minio_connector.calls == ["load_text", "to:3"]


@pytest.mark.parametrize("lazy", [False, True])
def test_parquet_connector_round_trips_dataframe(tmp_path, lazy: bool) -> None:
    sample_text_df = make_text_dataframe()
    path = tmp_path / "dataset.parquet"
    settings = ParquetDatasetConnectorSettings(module_path="x", path=str(path), lazy=False)
    connector = ParquetDatasetConnector(settings)

    connector.to(PolarsTextDataset.from_polars(sample_text_df))
    loaded = ParquetDatasetConnector(ParquetDatasetConnectorSettings(module_path="x", path=str(path), lazy=lazy)).load()

    assert loaded.polars.to_dict(as_series=False) == sample_text_df.to_dict(as_series=False)


def test_minio_connector_reads_and_writes_parquet_payloads(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    sample_text_df = make_text_dataframe()
    writes: dict[str, object] = {}
    parquet_buffer = io.BytesIO()
    sample_text_df.write_parquet(parquet_buffer)
    payload = parquet_buffer.getvalue()

    class FakeResponse:
        def read(self) -> bytes:
            return payload

        def close(self) -> None:
            writes["closed"] = True

        def release_conn(self) -> None:
            writes["released"] = True

    class FakeMinio:
        def __init__(self, endpoint: str, access_key: str, secret_key: str, secure: bool) -> None:
            writes["init"] = {
                "endpoint": endpoint,
                "access_key": access_key,
                "secret_key": secret_key,
                "secure": secure,
            }

        def get_object(self, bucket: str, key: str) -> FakeResponse:
            writes["get"] = (bucket, key)
            return FakeResponse()

        def put_object(
            self,
            *,
            bucket_name: str,
            object_name: str,
            data: io.BytesIO,
            length: int,
            content_type: str,
        ) -> None:
            writes["put"] = {
                "bucket_name": bucket_name,
                "object_name": object_name,
                "length": length,
                "content_type": content_type,
                "payload": pl.read_parquet(data).to_dict(as_series=False),
            }

    monkeypatch.setattr("retrievalbase.connector.minio.Minio", FakeMinio)

    settings = MinioDatasetConnectorSettings(
        module_path="x",
        endpoint="https://minio.local",
        bucket="datasets",
        key="sample.parquet",
        access_key=SecretStr("access"),
        secret_key=SecretStr("secret"),
    )
    connector = MinioDatasetConnector(settings)

    loaded = connector.load_text()
    connector.to(loaded)
    init_call = cast(MinioInitCall, writes["init"])
    put_call = cast(MinioPutCall, writes["put"])

    assert init_call == {
        "endpoint": "minio.local",
        "access_key": "access",
        "secret_key": "secret",
        "secure": True,
    }
    assert writes["get"] == ("datasets", "sample.parquet")
    assert put_call["bucket_name"] == "datasets"
    assert put_call["payload"] == sample_text_df.to_dict(as_series=False)
    assert loaded.polars.to_dict(as_series=False) == sample_text_df.to_dict(as_series=False)
    assert writes["closed"] is True
    assert writes["released"] is True
