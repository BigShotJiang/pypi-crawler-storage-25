from __future__ import annotations

from typing import cast

import polars as pl
import pytest

from retrievalbase.dataset import Dataset
from retrievalbase.dataset.polars import PolarsTextDataset


class RaisingDataset(Dataset[pl.DataFrame]):
    @classmethod
    def from_polars(cls, df: pl.DataFrame | pl.LazyFrame):
        return super().from_polars(df)

    def to_polars(self) -> pl.DataFrame:
        return super().to_polars()

    def to_lazy_polars(self) -> pl.LazyFrame:
        return super().to_lazy_polars()


def test_dataset_abstract_contract_methods_raise_not_implemented() -> None:
    dataset = RaisingDataset(pl.DataFrame({"x": [1]}))

    with pytest.raises(NotImplementedError):
        RaisingDataset.from_polars(pl.DataFrame({"x": [1]}))
    with pytest.raises(NotImplementedError):
        dataset.to_polars()
    with pytest.raises(NotImplementedError):
        dataset.to_lazy_polars()


def test_dataset_from_minio_delegates_to_connector(monkeypatch: pytest.MonkeyPatch) -> None:
    loaded = cast(PolarsTextDataset, PolarsTextDataset.from_records([("hello", {"doc_id": "1"})]))

    class FakeConnector:
        def load(self) -> PolarsTextDataset:
            return loaded

    monkeypatch.setattr("retrievalbase.dataset._get_minio_connector", lambda *args: FakeConnector())

    dataset = Dataset.from_minio("bucket", "key", "endpoint", "ak", "sk")

    assert dataset.polars.to_dict(as_series=False) == loaded.polars.to_dict(as_series=False)


def test_text_dataset_from_parquet_delegates_to_text_connector(monkeypatch: pytest.MonkeyPatch) -> None:
    loaded = cast(PolarsTextDataset, PolarsTextDataset.from_records([("hello", {"doc_id": "1"})]))

    class FakeConnector:
        def load_text(self) -> PolarsTextDataset:
            return loaded

    monkeypatch.setattr("retrievalbase.dataset._get_parquet_connector", lambda *args, **kwargs: FakeConnector())

    dataset = PolarsTextDataset.from_parquet("data.parquet")

    assert dataset.polars.to_dict(as_series=False) == loaded.polars.to_dict(as_series=False)
