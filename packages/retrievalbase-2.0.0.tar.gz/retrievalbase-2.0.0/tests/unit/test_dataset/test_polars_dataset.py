from __future__ import annotations

from pathlib import Path

import polars as pl
import pytest

from retrievalbase.dataset.polars import PolarsDataset, PolarsTextDataset
from tests.fixtures.data import make_documents


def test_polars_dataset_supports_basic_dataframe_operations(
    sample_text_df: pl.DataFrame,
) -> None:
    dataset = PolarsDataset.from_polars(sample_text_df)

    augmented = dataset.with_columns(pl.lit("ok").alias("status"))
    filtered = dataset.filter(pl.col("page_content") == "alpha")
    dropped = augmented.drop("status")

    assert len(dataset) == 3
    assert dataset.polars_shape == (3, 2)
    assert augmented.polars["status"].to_list() == ["ok", "ok", "ok"]
    assert filtered.polars["page_content"].to_list() == ["alpha"]
    assert dropped.polars.to_dict(as_series=False) == sample_text_df.to_dict(as_series=False)


def test_polars_text_dataset_supports_document_helpers(tmp_path: Path) -> None:
    docs = make_documents(
        [
            {"page_content": "hello", "metadata": {"doc_id": "1"}},
            {"page_content": "world", "metadata": {"doc_id": "2"}},
        ]
    )
    dataset = PolarsTextDataset.from_documents(docs)

    records_dataset = PolarsTextDataset.from_records([("hello", {"doc_id": "1"}), ("world", {"doc_id": "2"})])
    dumped_dir = tmp_path / "docs"
    dataset.dump_documents(str(dumped_dir), prefix="sample")

    assert dataset.to_langchain_documents() == docs
    assert list(dataset.iter_documents()) == docs
    assert list(dataset.iter_rows(named=True))[0]["page_content"] == "hello"
    assert records_dataset.polars.to_dict(as_series=False) == dataset.polars.to_dict(as_series=False)
    assert (dumped_dir / "sample_00000.md").read_text(encoding="utf-8").startswith("###PAGE_CONTENT###")


def test_text_dataset_requires_page_content_and_metadata_columns() -> None:
    with pytest.raises(ValueError, match="requires columns"):
        PolarsTextDataset.from_polars(pl.DataFrame({"page_content": ["only text"]}))
    with pytest.raises(ValueError, match="requires columns"):
        PolarsTextDataset.from_polars(pl.DataFrame({"metadata": [{"doc_id": "1"}]}))
