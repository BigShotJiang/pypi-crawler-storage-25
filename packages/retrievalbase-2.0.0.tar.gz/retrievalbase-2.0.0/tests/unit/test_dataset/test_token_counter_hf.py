from __future__ import annotations

import sys
from types import ModuleType

import pytest

from retrievalbase.dataset.preprocess.token_counter import HuggingFaceTokenCounter
from retrievalbase.dataset.settings import HuggingFaceTokenCounterSettings


def _settings() -> HuggingFaceTokenCounterSettings:
    return HuggingFaceTokenCounterSettings(
        module_path="retrievalbase.dataset.preprocess.token_counter.HuggingFaceTokenCounter",
        name="dummy-tokenizer",
        add_special_tokens=True,
        revision="main",
    )


def test_huggingface_token_counter_raises_when_transformers_missing(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setitem(sys.modules, "transformers", None)

    with pytest.raises(ImportError, match="requires transformers"):
        HuggingFaceTokenCounter(_settings())


def test_huggingface_token_counter_counts_tokenizer_ids(monkeypatch: pytest.MonkeyPatch) -> None:
    captured: dict[str, object] = {}

    class FakeTokenizer:
        def __call__(self, text: str, **kwargs: object) -> dict[str, list[int]]:
            captured["text"] = text
            captured["kwargs"] = kwargs
            return {"input_ids": [1, 2, 3, 4]}

    class AutoTokenizer:
        @staticmethod
        def from_pretrained(name: str, revision: str | None, trust_remote_code: bool) -> FakeTokenizer:
            captured["name"] = name
            captured["revision"] = revision
            captured["trust_remote_code"] = trust_remote_code
            return FakeTokenizer()

    fake_transformers = ModuleType("transformers")
    monkeypatch.setattr(fake_transformers, "AutoTokenizer", AutoTokenizer, raising=False)
    monkeypatch.setitem(sys.modules, "transformers", fake_transformers)
    counter = HuggingFaceTokenCounter(_settings())
    assert counter.count("hello") == 4
    assert captured["name"] == "dummy-tokenizer"
    assert captured["kwargs"] == {
        "add_special_tokens": True,
        "truncation": False,
        "return_attention_mask": False,
        "return_token_type_ids": False,
    }
