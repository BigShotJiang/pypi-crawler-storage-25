from __future__ import annotations

import pytest

from retrievalbase.dataset.polars import PolarsTextDataset
from retrievalbase.dataset.settings import HeuristicTokenCounterSettings
from tests.fixtures.components import build_heuristic_token_counter_settings
from tests.fixtures.data import make_text_dataset


@pytest.fixture
def text_dataset() -> PolarsTextDataset:
    return make_text_dataset(
        [
            {"page_content": "aa", "metadata": {"i": 0}},
            {"page_content": "bbbb", "metadata": {"i": 1}},
            {"page_content": "cccccc", "metadata": {"i": 2}},
            {"page_content": "dddddddd", "metadata": {"i": 3}},
        ]
    )


@pytest.fixture
def token_counter_settings() -> HeuristicTokenCounterSettings:
    return build_heuristic_token_counter_settings(chars_per_token=2)
