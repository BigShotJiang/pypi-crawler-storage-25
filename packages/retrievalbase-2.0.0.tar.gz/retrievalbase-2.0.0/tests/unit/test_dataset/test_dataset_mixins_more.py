from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace
from typing import cast

import polars as pl
import pytest
from langchain_core.documents import Document

from retrievalbase.dataset.polars import PolarsTextDataset


def test_from_records_rejects_empty_records() -> None:
    with pytest.raises(ValueError, match="non-empty"):
        PolarsTextDataset.from_records([])


def test_dump_documents_serializes_non_json_metadata(tmp_path: Path) -> None:
    dataset = PolarsTextDataset.from_polars(
        pl.DataFrame(
            [
                pl.Series("page_content", ["hello"]),
                pl.Series("metadata", [{"bad": {1, 2}}], dtype=pl.Object),
            ]
        )
    )

    dataset.dump_documents(str(tmp_path), prefix="sample")
    content = (tmp_path / "sample_00000.md").read_text(encoding="utf-8")
    assert "{1, 2}" in content or "{2, 1}" in content


def test_from_documents_normalizes_missing_metadata_to_empty_dict() -> None:
    dataset = PolarsTextDataset.from_documents(
        cast(list[Document], [SimpleNamespace(page_content="hello", metadata=None)])
    )

    assert dataset.polars["metadata"].to_list() == [{}]
