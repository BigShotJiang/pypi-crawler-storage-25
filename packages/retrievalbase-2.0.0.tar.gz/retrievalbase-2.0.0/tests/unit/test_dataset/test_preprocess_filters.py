from __future__ import annotations

from collections.abc import Callable
from typing import Any

import pytest

from retrievalbase.dataset.preprocess.preprocess import (
    MaxTokenFilter,
    MinTokenFilter,
    PreprocessPipeline,
    QuantileTokenFilter,
    SigmaBandTokenFilter,
    TextPreprocessor,
)
from retrievalbase.dataset.settings import (
    HeuristicTokenCounterSettings,
    MaxTokenFilterSettings,
    MinTokenFilterSettings,
    PreprocessPipelineSettings,
    QuantileTokenFilterSettings,
    SigmaBandTokenFilterSettings,
)


@pytest.mark.parametrize(
    ("build_filter", "expected"),
    [
        (
            lambda token_counter_settings: MinTokenFilter(
                MinTokenFilterSettings(
                    module_path="retrievalbase.dataset.preprocess.preprocess.MinTokenFilter",
                    kind="min_tokens",
                    min_tokens=2,
                    token_counter=token_counter_settings,
                )
            ),
            ["bbbb", "cccccc", "dddddddd"],
        ),
        (
            lambda token_counter_settings: MaxTokenFilter(
                MaxTokenFilterSettings(
                    module_path="retrievalbase.dataset.preprocess.preprocess.MaxTokenFilter",
                    kind="max_tokens",
                    max_tokens=2,
                    token_counter=token_counter_settings,
                )
            ),
            ["aa", "bbbb"],
        ),
    ],
)
def test_min_and_max_token_filters_apply_thresholds(
    text_dataset,
    token_counter_settings: HeuristicTokenCounterSettings,
    build_filter: Callable[[HeuristicTokenCounterSettings], TextPreprocessor[Any]],
    expected: list[str],
) -> None:
    filter_instance = build_filter(token_counter_settings)

    assert filter_instance.apply(text_dataset).polars["page_content"].to_list() == expected


def test_quantile_and_sigma_filters_reduce_dataset(
    text_dataset,
    token_counter_settings: HeuristicTokenCounterSettings,
) -> None:
    quantile_filter = QuantileTokenFilter(
        QuantileTokenFilterSettings(
            module_path="retrievalbase.dataset.preprocess.preprocess.QuantileTokenFilter",
            kind="quantile",
            q=0.5,
            token_counter=token_counter_settings,
        )
    )
    sigma_filter = SigmaBandTokenFilter(
        SigmaBandTokenFilterSettings(
            module_path="retrievalbase.dataset.preprocess.preprocess.SigmaBandTokenFilter",
            kind="sigma",
            z=0.8,
            token_counter=token_counter_settings,
        )
    )

    assert quantile_filter.apply(text_dataset).polars["page_content"].to_list() == [
        "aa",
        "bbbb",
        "cccccc",
    ]
    assert sigma_filter.apply(text_dataset).polars["page_content"].to_list() == [
        "bbbb",
        "cccccc",
    ]


def test_preprocess_pipeline_applies_steps_in_order(
    text_dataset,
    token_counter_settings: HeuristicTokenCounterSettings,
) -> None:
    pipeline = PreprocessPipeline(
        PreprocessPipelineSettings(
            module_path="retrievalbase.dataset.preprocess.preprocess.PreprocessPipeline",
            kind="steps",
            steps=[
                MinTokenFilterSettings(
                    module_path="retrievalbase.dataset.preprocess.preprocess.MinTokenFilter",
                    kind="min_tokens",
                    min_tokens=2,
                    token_counter=token_counter_settings,
                ),
                MaxTokenFilterSettings(
                    module_path="retrievalbase.dataset.preprocess.preprocess.MaxTokenFilter",
                    kind="max_tokens",
                    max_tokens=3,
                    token_counter=token_counter_settings,
                ),
            ],
        )
    )

    assert pipeline.apply(text_dataset).polars["page_content"].to_list() == ["bbbb", "cccccc"]
