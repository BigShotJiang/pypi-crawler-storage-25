from __future__ import annotations

import polars as pl

from retrievalbase.dataset.polars import PolarsDataset, PolarsTextDataset


def test_polars_dataset_collects_lazy_frames() -> None:
    lazy = pl.DataFrame({"x": [1, 2]}).lazy()
    dataset = PolarsDataset.from_polars(lazy)

    assert dataset.to_polars().to_dict(as_series=False) == {"x": [1, 2]}
    assert isinstance(dataset.to_lazy_polars(), pl.LazyFrame)


def test_polars_text_dataset_round_trips_eager_and_lazy_frames() -> None:
    eager = pl.DataFrame({"page_content": ["a"], "metadata": [{"doc_id": "1"}]})
    dataset = PolarsTextDataset.from_polars(eager)
    lazy_dataset = PolarsTextDataset.from_polars(eager.lazy())

    assert isinstance(dataset.to_lazy_polars(), pl.LazyFrame)
    assert lazy_dataset.to_polars().to_dict(as_series=False) == eager.to_dict(as_series=False)
