from __future__ import annotations

import pytest

from retrievalbase.dataset.preprocess.token_counter import HeuristicTokenCounter
from retrievalbase.dataset.settings import HeuristicTokenCounterSettings


@pytest.mark.parametrize(
    ("text", "expected"),
    [
        ("a", 1),
        ("ab", 1),
        ("abcdef", 3),
    ],
)
def test_heuristic_token_counter_counts_single_text(
    token_counter_settings: HeuristicTokenCounterSettings,
    text: str,
    expected: int,
) -> None:
    counter = HeuristicTokenCounter(token_counter_settings)

    assert counter.count(text) == expected


def test_heuristic_token_counter_counts_batches(
    token_counter_settings: HeuristicTokenCounterSettings,
) -> None:
    counter = HeuristicTokenCounter(token_counter_settings)

    assert counter.count_batch(["ab", "abcdef"]) == [1, 3]
