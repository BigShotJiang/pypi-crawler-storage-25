from __future__ import annotations

import pytest

from retrievalbase.ingestion import TextIngestionPipeline
from tests.fixtures.components import (
    build_fake_component_mapping,
    build_load_class,
    build_text_ingestion_pipeline_settings,
)


def test_text_ingestion_pipeline_loads_connector_and_preprocessor(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr("retrievalbase.ingestion.load_class", build_load_class(build_fake_component_mapping()))
    pipeline = TextIngestionPipeline(
        build_text_ingestion_pipeline_settings(
            [
                {"page_content": "hello", "metadata": {"doc_id": "1"}},
                {"page_content": "world", "metadata": {"doc_id": "2"}},
            ]
        )
    )

    ingested = pipeline.ingest()

    assert ingested.polars["page_content"].to_list() == ["hello!", "world!"]
