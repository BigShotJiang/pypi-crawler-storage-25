from __future__ import annotations

import pytest

from retrievalbase.dataset.hf import HuggingFaceDatasetAdaptater
from retrievalbase.dataset.settings import HuggingFaceDatasetAdaptaterSettings
from retrievalbase.exceptions import DatasetSchemaError
from tests.fixtures.components import (
    FakeDatasetConnectorSettings,
    build_fake_component_mapping,
    build_fake_dataset_connector_settings,
    build_load_class,
)


class LocalHFDatasetAdapter(
    HuggingFaceDatasetAdaptater[HuggingFaceDatasetAdaptaterSettings[FakeDatasetConnectorSettings]]
):
    pass


def test_huggingface_adapter_maps_columns_to_hf_dataset(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr("retrievalbase.dataset.hf.load_class", build_load_class(build_fake_component_mapping()))
    adapter = LocalHFDatasetAdapter(
        HuggingFaceDatasetAdaptaterSettings[FakeDatasetConnectorSettings](
            module_path="x",
            connector=build_fake_dataset_connector_settings(),
            columns_mapping={
                "text": "page_content",
                "query": "metadata.query",
            },
        )
    )

    hf_dataset = adapter.to_hf()

    assert hf_dataset.column_names == ["text", "query"]
    assert hf_dataset[0] == {"text": "alpha", "query": "alpha"}


def test_huggingface_adapter_raises_for_missing_root_columns(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr("retrievalbase.dataset.hf.load_class", build_load_class(build_fake_component_mapping()))
    adapter = LocalHFDatasetAdapter(
        HuggingFaceDatasetAdaptaterSettings[FakeDatasetConnectorSettings](
            module_path="x",
            connector=build_fake_dataset_connector_settings(),
            columns_mapping={
                "text": "missing.value",
            },
        )
    )

    with pytest.raises(DatasetSchemaError, match="Missing columns"):
        adapter.to_hf()
