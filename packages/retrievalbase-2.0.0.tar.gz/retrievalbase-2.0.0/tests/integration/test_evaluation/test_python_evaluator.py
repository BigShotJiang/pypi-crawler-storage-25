from __future__ import annotations

from types import SimpleNamespace

from langchain_core.documents import Document

from retrievalbase.dataset.polars import PolarsTextDataset
from retrievalbase.evaluation import VectorStore
from retrievalbase.evaluation.evaluators.python import PythonEvaluator
from retrievalbase.evaluation.evaluators.python.evaluators import FaissPythonEvaluator


def test_python_evaluator_helpers_aggregate_scores(sample_text_df, metric_factory) -> None:
    evaluator = object.__new__(PythonEvaluator)
    evaluator.dataset = PolarsTextDataset.from_polars(sample_text_df)
    evaluator.scores = [lambda hits, total_relevant=None: [metric_factory(float(sum(hits)))]]
    evaluator.NB_LOGS_PER_QUERIES = 100
    evaluator.BATCH_SIZE = 2
    evaluator.config = SimpleNamespace(limit=2, retriever=SimpleNamespace(reranker=None))

    batches = list(evaluator.batch_iter())
    dataset_rows = list(evaluator.dataset.iter_rows(named=True))
    scores_all = evaluator._score_batches(
        [batches[0]],
        [
            [
                VectorStore.QueryResponse(
                    points=[
                        VectorStore.ScoredPoint(
                            score=1.0,
                            document=Document(
                                page_content=dataset_rows[0]["page_content"],
                                metadata=dataset_rows[0]["metadata"],
                            ),
                        )
                    ]
                ),
                VectorStore.QueryResponse(
                    points=[
                        VectorStore.ScoredPoint(
                            score=1.0,
                            document=Document(
                                page_content=dataset_rows[2]["page_content"],
                                metadata=dataset_rows[2]["metadata"],
                            ),
                        )
                    ]
                ),
            ]
        ],
    )
    aggregated = evaluator._aggregate_scores(scores_all)

    assert len(batches) == 2
    assert aggregated == {"metric": 0.5}


def test_faiss_python_evaluator_extracts_unique_documents(sample_text_df) -> None:
    evaluator = object.__new__(FaissPythonEvaluator)
    evaluator.dataset = PolarsTextDataset.from_polars(sample_text_df.vstack(sample_text_df.head(1)))
    docs = evaluator.get_docs()

    assert [doc.metadata["doc_id"] for doc in docs] == ["a", "b", "c"]
