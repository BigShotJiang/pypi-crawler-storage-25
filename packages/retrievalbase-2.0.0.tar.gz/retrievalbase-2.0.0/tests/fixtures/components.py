from __future__ import annotations

from collections.abc import Mapping
from typing import Any

import polars as pl
from langchain_core.documents import Document

from retrievalbase.connector import DatasetConnector
from retrievalbase.connector.settings import DatasetConnectorSettings
from retrievalbase.dataset import TextDataset
from retrievalbase.dataset.polars import PolarsTextDataset
from retrievalbase.dataset.preprocess import TextPreprocessor
from retrievalbase.dataset.settings import (
    HeuristicTokenCounterSettings,
    TextPreprocessorSettings,
)
from retrievalbase.enums import EmbeddingPurposeEnum
from retrievalbase.evaluation import Embedder, Processor, Reranker, VectorStore
from retrievalbase.evaluation.settings import (
    DenseRetrieverSettings,
    EmbedderSettings,
    ProcessorSettings,
    RerankerSettings,
    VectorStoreSettings,
)
from retrievalbase.ingestion.settings import TextIngestionPipelineSettings
from retrievalbase.mixins import FromConfigMixin
from retrievalbase.settings import FromConfigMixinSettings
from tests.fixtures.data import make_text_rows

FAKE_RUNTIME_PATH = "tests.fixtures.components.FakeRuntime"
FAKE_CONNECTOR_PATH = "tests.fixtures.components.FakeDatasetConnector"
FAKE_PREPROCESSOR_PATH = "tests.fixtures.components.FakeTextPreprocessor"
PREFIX_PROCESSOR_PATH = "tests.fixtures.components.PrefixProcessor"
RECORDING_EMBEDDER_PATH = "tests.fixtures.components.RecordingEmbedder"
ECHO_VECTOR_STORE_PATH = "tests.fixtures.components.EchoVectorStore"
REVERSE_RERANKER_PATH = "tests.fixtures.components.ReverseReranker"


class FakeRuntimeSettings(FromConfigMixinSettings):
    value: int


class FakeRuntime(FromConfigMixin[FakeRuntimeSettings]):
    pass


class FakeDatasetConnectorSettings(DatasetConnectorSettings):
    rows: list[dict[str, Any]]


class FakeDatasetConnector(DatasetConnector[FakeDatasetConnectorSettings]):
    last_written: pl.DataFrame | None = None

    def _load(self) -> pl.DataFrame:
        return pl.DataFrame(self.config.rows)

    def to(self, ds: Any) -> None:
        self.__class__.last_written = ds.polars


class FakeTextPreprocessorSettings(TextPreprocessorSettings):
    kind: str = "suffix"
    suffix: str


class FakeTextPreprocessor(TextPreprocessor[FakeTextPreprocessorSettings]):
    def apply(self, ds: TextDataset[Any]) -> TextDataset[Any]:
        return PolarsTextDataset.from_polars(
            ds.polars.with_columns((pl.col("page_content") + self.config.suffix).alias("page_content"))
        )


class PrefixProcessorSettings(ProcessorSettings):
    prefix: str


class PrefixProcessor(Processor[PrefixProcessorSettings]):
    def __call__(self, text: str, purpose: EmbeddingPurposeEnum) -> str:
        return f"{purpose}:{self.config.prefix}:{text}"


class RecordingEmbedderSettings(EmbedderSettings):
    pass


class RecordingEmbedder(Embedder[RecordingEmbedderSettings]):
    def __init__(self, config: RecordingEmbedderSettings) -> None:
        super().__init__(config)
        self.calls: list[list[str]] = []

    async def _aembed(self, texts: list[str]) -> list[list[float]]:
        self.calls.append(texts)
        return [[float(len(text))] for text in texts]


class EchoVectorStoreSettings(VectorStoreSettings):
    pass


class EchoVectorStore(VectorStore[EchoVectorStoreSettings]):
    def __init__(self, config: EchoVectorStoreSettings) -> None:
        super().__init__(config)
        self.calls: list[list[VectorStore.VectorQuery]] = []

    async def _abatch_query_points(
        self,
        requests: list[VectorStore.VectorQuery],
    ) -> list[VectorStore.QueryResponse]:
        self.calls.append(requests)
        return [
            VectorStore.QueryResponse(
                points=[
                    VectorStore.ScoredPoint(
                        score=float(sum(request.vector)),
                        document=Document(
                            page_content=f"doc:{request.vector}",
                            metadata={"limit": request.limit},
                        ),
                    )
                ]
            )
            for request in requests
        ]


class ReverseRerankerSettings(RerankerSettings):
    pass


class ReverseReranker(Reranker[ReverseRerankerSettings]):
    async def rerank(
        self,
        query: str,
        response: VectorStore.QueryResponse,
        limit: int,
    ) -> VectorStore.QueryResponse:
        return VectorStore.QueryResponse(points=list(reversed(response.points))[:limit])


def build_fake_runtime_settings(value: int = 1) -> FakeRuntimeSettings:
    return FakeRuntimeSettings(module_path=FAKE_RUNTIME_PATH, value=value)


def build_fake_runtime(value: int = 1) -> FakeRuntime:
    return FakeRuntime(build_fake_runtime_settings(value=value))


def build_fake_dataset_connector_settings(
    rows: list[dict[str, Any]] | None = None,
) -> FakeDatasetConnectorSettings:
    return FakeDatasetConnectorSettings(module_path=FAKE_CONNECTOR_PATH, rows=make_text_rows(rows))


def build_fake_text_preprocessor_settings(suffix: str = "!") -> FakeTextPreprocessorSettings:
    return FakeTextPreprocessorSettings(module_path=FAKE_PREPROCESSOR_PATH, suffix=suffix)


def build_heuristic_token_counter_settings(chars_per_token: int = 2) -> HeuristicTokenCounterSettings:
    return HeuristicTokenCounterSettings(
        module_path="retrievalbase.dataset.preprocess.token_counter.HeuristicTokenCounter",
        chars_per_token=chars_per_token,
    )


def build_text_ingestion_pipeline_settings(
    rows: list[dict[str, Any]] | None = None,
    *,
    suffix: str = "!",
) -> TextIngestionPipelineSettings[FakeDatasetConnectorSettings, FakeTextPreprocessorSettings]:
    return TextIngestionPipelineSettings[FakeDatasetConnectorSettings, FakeTextPreprocessorSettings](
        module_path="x",
        connector=build_fake_dataset_connector_settings(rows),
        preprocessor=build_fake_text_preprocessor_settings(suffix=suffix),
    )


def build_dense_retriever_settings(
    *,
    prefix: str = "p",
    model_name: str = "m",
) -> DenseRetrieverSettings[
    RecordingEmbedderSettings,
    EchoVectorStoreSettings,
    PrefixProcessorSettings,
    ReverseRerankerSettings,
]:
    return DenseRetrieverSettings[
        RecordingEmbedderSettings,
        EchoVectorStoreSettings,
        PrefixProcessorSettings,
        ReverseRerankerSettings,
    ](
        module_path="x",
        reranker=ReverseRerankerSettings(module_path=REVERSE_RERANKER_PATH),
        embedder=RecordingEmbedderSettings(module_path=RECORDING_EMBEDDER_PATH, model_name=model_name),
        vector_store=EchoVectorStoreSettings(module_path=ECHO_VECTOR_STORE_PATH),
        processor=PrefixProcessorSettings(module_path=PREFIX_PROCESSOR_PATH, prefix=prefix),
    )


def build_fake_component_mapping() -> dict[str, type[Any]]:
    return {
        FAKE_RUNTIME_PATH: FakeRuntime,
        FAKE_CONNECTOR_PATH: FakeDatasetConnector,
        FAKE_PREPROCESSOR_PATH: FakeTextPreprocessor,
        PREFIX_PROCESSOR_PATH: PrefixProcessor,
        RECORDING_EMBEDDER_PATH: RecordingEmbedder,
        ECHO_VECTOR_STORE_PATH: EchoVectorStore,
        REVERSE_RERANKER_PATH: ReverseReranker,
    }


def build_load_class(mapping: Mapping[str, type[Any]] | None = None) -> Any:
    resolved = dict(mapping or build_fake_component_mapping())
    return lambda path: resolved[path]
