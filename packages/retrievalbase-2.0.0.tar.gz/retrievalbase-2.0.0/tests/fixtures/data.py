from __future__ import annotations

from collections.abc import Iterable
from typing import Any

import polars as pl
import pytest
from langchain_core.documents import Document

from retrievalbase.dataset.polars import PolarsTextDataset


def make_text_rows(rows: Iterable[dict[str, Any]] | None = None) -> list[dict[str, Any]]:
    if rows is not None:
        return [dict(row) for row in rows]
    return [
        {"page_content": "alpha", "metadata": {"doc_id": "a", "chunk_id": 0, "query": "alpha"}},
        {"page_content": "beta beta", "metadata": {"doc_id": "b", "chunk_id": 0, "query": "beta"}},
        {"page_content": "gamma gamma gamma", "metadata": {"doc_id": "c", "chunk_id": 0, "query": "gamma"}},
    ]


def make_text_dataframe(rows: Iterable[dict[str, Any]] | None = None) -> pl.DataFrame:
    return pl.DataFrame(make_text_rows(rows))


def make_nested_dataframe() -> pl.DataFrame:
    return pl.DataFrame(
        {
            "page_content": ["hello", "world"],
            "metadata": [
                {"query": "q1", "doc_id": "d1"},
                {"query": "q2", "doc_id": "d2"},
            ],
            "payload": [
                {"nested": {"label": "x"}},
                {"nested": {"label": "y"}},
            ],
        }
    )


def make_text_dataset(rows: Iterable[dict[str, Any]] | None = None) -> PolarsTextDataset:
    return PolarsTextDataset.from_polars(make_text_dataframe(rows))


def make_documents(rows: Iterable[dict[str, Any]] | None = None) -> list[Document]:
    return [Document(page_content=row["page_content"], metadata=row["metadata"]) for row in make_text_rows(rows)]


@pytest.fixture
def sample_text_df() -> pl.DataFrame:
    return make_text_dataframe()


@pytest.fixture
def sample_nested_df() -> pl.DataFrame:
    return make_nested_dataframe()
