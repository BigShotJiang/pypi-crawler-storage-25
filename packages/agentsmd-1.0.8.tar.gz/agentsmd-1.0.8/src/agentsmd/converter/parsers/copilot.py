"""Parser for GitHub Copilot configuration files.

Reads:
- ``.github/copilot-instructions.md`` — primary freeform markdown (no frontmatter)
- ``.github/instructions/*.instructions.md`` — scoped files with YAML frontmatter
  containing ``applyTo``, ``name``, and ``description``.
"""

from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Optional

from agentsmd.converter.canonical import AgentSection, CanonicalModel
from agentsmd.converter.parsers.base import BaseParser
from agentsmd.converter.parsers.markdown_utils import (
    parse_frontmatter,
    split_by_headings,
)

HEADING_MAP: Dict[str, str] = {
    "overview": "overview",
    "project overview": "overview",
    "coding standards": "rules",
    "rules": "rules",
    "code style": "rules",
    "constraints": "constraints",
    "what not to do": "constraints",
    "workflow": "workflow",
    "testing": "testing",
    "file structure": "file_structure",
    "folder structure": "file_structure",
    "documentation": "documentation",
    "environment": "environment",
}


class CopilotParser(BaseParser):
    """Parse GitHub Copilot instruction files into a CanonicalModel."""

    file_patterns: List[str] = [".github/copilot-instructions.md"]
    dir_patterns: List[str] = [".github/instructions"]

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _normalize_apply_to(value: object) -> Optional[List[str]]:
        """Normalise the ``applyTo`` frontmatter field to a list of globs.

        - ``None`` → ``None``
        - ``str``  → split by comma, stripped → list
        - ``list`` → as-is
        """
        if value is None:
            return None
        if isinstance(value, str):
            return [p.strip() for p in value.split(",") if p.strip()]
        if isinstance(value, list):
            return value
        return None

    @staticmethod
    def _map_heading(heading: str) -> Optional[str]:
        """Map a markdown heading to a canonical section field name."""
        return HEADING_MAP.get(heading.lower().strip())

    # ------------------------------------------------------------------
    # Core parse logic
    # ------------------------------------------------------------------

    def _parse_sections_from_md(
        self,
        content: str,
        globs: Optional[List[str]] = None,
        description: Optional[str] = None,
    ) -> List[AgentSection]:
        """Parse markdown content into a list of AgentSections."""
        raw_sections = split_by_headings(content)
        sections: List[AgentSection] = []
        for raw in raw_sections:
            heading = raw["heading"]
            body = raw["content"]
            field = self._map_heading(heading) if heading else None
            section = AgentSection(
                heading=heading,
                content=body,
                globs=globs,
                description=description,
            )
            if field:
                sections.append((field, section))
            else:
                sections.append(section)
        return sections

    def _merge_section(
        self, model: CanonicalModel, field: str, section: AgentSection
    ) -> None:
        """Merge *section* into *model*, appending content if the field exists."""
        existing: Optional[AgentSection] = getattr(model, field, None)
        if existing is not None and existing.content:
            merged = AgentSection(
                heading=existing.heading,
                content=existing.content + "\n\n" + section.content,
                trigger=existing.trigger,
                globs=section.globs if existing.globs is None else existing.globs,
                description=existing.description,
            )
            setattr(model, field, merged)
        else:
            setattr(model, field, section)

    def _parse_primary(self, workspace_path: Path, model: CanonicalModel) -> None:
        """Parse the primary ``.github/copilot-instructions.md`` file."""
        primary = workspace_path / ".github" / "copilot-instructions.md"
        if not primary.exists():
            return

        content = primary.read_text(encoding="utf-8")
        results = self._parse_sections_from_md(content)
        for result in results:
            if isinstance(result, tuple):
                field, section = result
                self._merge_section(model, field, section)
            else:
                model.extras.append(result)

    def _parse_scoped(self, workspace_path: Path, model: CanonicalModel) -> None:
        """Parse scoped ``.github/instructions/*.instructions.md`` files."""
        instructions_dir = workspace_path / ".github" / "instructions"
        if not instructions_dir.is_dir():
            return

        for path in sorted(instructions_dir.glob("*.instructions.md")):
            raw = path.read_text(encoding="utf-8")
            fm, body = parse_frontmatter(raw)

            globs = self._normalize_apply_to(fm.get("applyTo"))
            name = fm.get("name")
            desc = fm.get("description")

            # If frontmatter is present but body is empty, treat the whole
            # file content (minus frontmatter) as the body.
            if not body.strip() and raw.strip():
                continue

            results = self._parse_sections_from_md(
                body, globs=globs, description=desc
            )
            for result in results:
                if isinstance(result, tuple):
                    field, section = result
                    # Preserve name as description if not already set
                    if name and not section.description:
                        section = AgentSection(
                            heading=section.heading,
                            content=section.content,
                            trigger=section.trigger,
                            globs=section.globs,
                            description=name,
                        )
                    self._merge_section(model, field, section)
                else:
                    if name and not result.description:
                        result = AgentSection(
                            heading=result.heading,
                            content=result.content,
                            trigger=result.trigger,
                            globs=result.globs,
                            description=name,
                        )
                    model.extras.append(result)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def parse(self, workspace_path: Path) -> CanonicalModel:
        """Parse Copilot configuration files into a CanonicalModel."""
        model = CanonicalModel()
        self._parse_primary(workspace_path, model)
        self._parse_scoped(workspace_path, model)
        return model
