"""AGENTS.md parser — reads AGENTS.md into a CanonicalModel."""

from __future__ import annotations

from pathlib import Path
from typing import Dict, List

from agentsmd.converter.canonical import AgentSection, CanonicalModel
from agentsmd.converter.parsers.base import BaseParser
from agentsmd.converter.parsers.markdown_utils import split_by_headings

HEADING_MAP: Dict[str, str] = {
    "overview": "overview",
    "project overview": "overview",
    "rules": "rules",
    "coding standards": "rules",
    "code style": "rules",
    "constraints": "constraints",
    "what never to do": "constraints",
    "context": "context",
    "what to remember": "context",
    "what agents should always remember": "context",
    "workflow": "workflow",
    "development workflow": "workflow",
    "build commands": "workflow",
    "testing": "testing",
    "testing guidelines": "testing",
    "testing instructions": "testing",
    "file structure": "file_structure",
    "project structure": "file_structure",
    "documentation": "documentation",
    "environment": "environment",
    "environment setup": "environment",
    "setup commands": "environment",
}


class AgentsMdParser(BaseParser):
    """Parse AGENTS.md into a CanonicalModel."""

    file_patterns: List[str] = ["AGENTS.md"]

    def parse(self, workspace_path: Path) -> CanonicalModel:
        """Read AGENTS.md and parse sections into a CanonicalModel."""
        agents_file = workspace_path / "AGENTS.md"
        content = agents_file.read_text(encoding="utf-8")
        raw_sections = split_by_headings(content)

        model = CanonicalModel()

        for section in raw_sections:
            heading = section["heading"]
            body = section["content"]

            if not heading:
                # Skip preamble content before any heading
                continue

            field_name = HEADING_MAP.get(heading.lower().strip())
            agent_section = AgentSection(heading=heading, content=body)

            if field_name is not None:
                model.set_section(field_name, agent_section)
            else:
                model.set_section(heading.lower().replace(" ", "_"), agent_section)

        return model
