"""Parser for Windsurf .windsurf/rules/*.md files."""

from __future__ import annotations

from pathlib import Path
from typing import Dict, List

from agentsmd.converter.canonical import AgentSection, CanonicalModel
from agentsmd.converter.parsers.base import BaseParser
from agentsmd.converter.parsers.markdown_utils import parse_frontmatter, split_by_headings

HEADING_MAP: Dict[str, str] = {
    "overview": "overview",
    "instructions": "rules",
    "rules": "rules",
    "coding standards": "rules",
    "constraints": "constraints",
    "what not to do": "constraints",
    "context": "context",
    "what to remember": "context",
    "workflow": "workflow",
    "development workflow": "workflow",
    "testing": "testing",
    "project files": "file_structure",
    "file structure": "file_structure",
    "documentation": "documentation",
    "environment": "environment",
}


def _normalize_globs(globs) -> List[str]:
    """Normalize globs to a list of strings."""
    if globs is None:
        return []
    if isinstance(globs, str):
        return [globs]
    return list(globs)


def _map_heading(heading: str) -> str:
    """Map a heading string to a canonical section name."""
    return HEADING_MAP.get(heading.lower().strip(), "")


class WindsurfParser(BaseParser):
    """Parse .windsurf/rules/*.md files into CanonicalModel."""

    dir_patterns: List[str] = [".windsurf/rules"]

    def parse(self, workspace_path: Path) -> CanonicalModel:
        """Parse all .md files from .windsurf/rules/ into a CanonicalModel."""
        model = CanonicalModel()
        rules_dir = workspace_path / ".windsurf" / "rules"

        if not rules_dir.is_dir():
            return model

        md_files = sorted(rules_dir.glob("*.md"))

        for md_file in md_files:
            content = md_file.read_text(encoding="utf-8")
            fm_data, body = parse_frontmatter(content)

            trigger = fm_data.get("trigger", "always_on")
            description = fm_data.get("description")
            globs = _normalize_globs(fm_data.get("globs"))

            self._parse_body_into_model(model, body, trigger, description, globs)

        return model

    def _parse_body_into_model(
        self,
        model: CanonicalModel,
        body: str,
        trigger: str,
        description: str | None,
        globs: List[str],
    ) -> None:
        """Parse markdown body into sections and merge into the model."""
        sections = split_by_headings(body)

        has_any_headings = any(s["heading"] for s in sections)

        if not has_any_headings:
            self._merge_section(
                model, "rules", "Rules", body.strip(), trigger, description, globs
            )
            return

        for section in sections:
            heading = section["heading"]
            content = section["content"].strip()

            if not heading:
                if content:
                    self._merge_section(
                        model, "rules", "Rules", content, trigger, description, globs
                    )
                continue

            section_name = _map_heading(heading)
            if not section_name:
                model.extras.append(AgentSection(
                    heading=heading,
                    content=content,
                    trigger=trigger,
                    description=description,
                    globs=globs if globs else None,
                ))
                continue

            self._merge_section(
                model, section_name, heading, content, trigger, description, globs
            )

    def _merge_section(
        self,
        model: CanonicalModel,
        section_name: str,
        heading: str,
        content: str,
        trigger: str,
        description: str | None,
        globs: List[str],
    ) -> None:
        """Merge content into a section, appending if it already exists."""
        existing: AgentSection | None = getattr(model, section_name, None)

        if existing is not None:
            # Append content to existing section
            existing.content = existing.content + "\n\n" + content if existing.content else content
            # Preserve metadata from first file
            if globs and not existing.globs:
                existing.globs = globs
            if description and not existing.description:
                existing.description = description
            if trigger and not existing.trigger:
                existing.trigger = trigger
        else:
            section_obj = AgentSection(
                heading=heading,
                content=content,
                trigger=trigger,
                description=description,
                globs=globs if globs else None,
            )
            model.set_section(section_name, section_obj)
