"""Parser for CLAUDE.md agent configuration files."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Dict, List, Optional

from agentsmd.converter.canonical import AgentSection, CanonicalModel
from agentsmd.converter.parsers.base import BaseParser
from agentsmd.converter.parsers.markdown_utils import split_by_headings, strip_frontmatter

# Maximum depth for @import resolution to prevent infinite recursion.
_MAX_IMPORT_DEPTH = 5

# Regex matching @import lines: lines like "@path/to/file.md" at the start of a line.
_IMPORT_RE = re.compile(r"^@(.+)$", re.MULTILINE)

# Regex for fenced code block openers/closers.
_FENCE_RE = re.compile(r"^```")

# Heading-to-field mapping. Lowercase heading text maps to a canonical field name
# or None (meaning the section should go to extras).
HEADING_MAP: Dict[str, Optional[str]] = {
    "overview": "overview",
    "project overview": "overview",
    "context": "context",
    "what to remember": "context",
    "constraints": "constraints",
    "what never to do": "constraints",
    "file organization": "file_structure",
    "file structure": "file_structure",
    "project structure": "file_structure",
    "key commands": "workflow",
    "workflow": "workflow",
    "development workflow": "workflow",
    "rules": "rules",
    "coding standards": "rules",
    "code style": "rules",
    "testing": "testing",
    "testing guidelines": "testing",
    "documentation": "documentation",
    "environment": "environment",
    "environment setup": "environment",
    "notes": None,
}


def _resolve_imports(text: str, workspace_path: Path, depth: int = 0) -> str:
    """Resolve @import directives in *text*, reading files relative to *workspace_path*.

    Lines matching ``@<path>`` outside fenced code blocks are replaced with the
    file content.  Nested imports are resolved recursively up to
    :data:`_MAX_IMPORT_DEPTH` levels.
    """
    if depth >= _MAX_IMPORT_DEPTH:
        return text

    lines = text.split("\n")
    resolved_lines: List[str] = []
    in_fence = False

    for line in lines:
        # Track fenced code block state.
        if _FENCE_RE.match(line):
            in_fence = not in_fence
            resolved_lines.append(line)
            continue

        if in_fence:
            resolved_lines.append(line)
            continue

        # Check for @import.
        m = _IMPORT_RE.match(line)
        if m:
            import_path = m.group(1).strip()
            file_path = workspace_path / import_path
            if file_path.is_file():
                imported = file_path.read_text(encoding="utf-8")
                # Recursively resolve imports in the imported content.
                imported = _resolve_imports(imported, workspace_path, depth + 1)
                resolved_lines.append(imported)
            else:
                # Keep the original @import line if the file doesn't exist.
                resolved_lines.append(line)
        else:
            resolved_lines.append(line)

    return "\n".join(resolved_lines)


class ClaudeMdParser(BaseParser):
    """Parse CLAUDE.md files into a CanonicalModel."""

    file_patterns: List[str] = ["CLAUDE.md"]

    def parse(self, workspace_path: Path) -> CanonicalModel:
        """Read CLAUDE.md, resolve @imports, split by headings, and build a CanonicalModel."""
        claude_file = workspace_path / "CLAUDE.md"
        raw = claude_file.read_text(encoding="utf-8")

        # Strip frontmatter (CLAUDE.md may have it).
        body = strip_frontmatter(raw)

        # Resolve @import directives.
        body = _resolve_imports(body, workspace_path)

        # Split into sections by headings.
        raw_sections = split_by_headings(body)

        model = CanonicalModel()

        for raw_sec in raw_sections:
            heading = raw_sec["heading"].strip()
            content = raw_sec["content"].strip()

            if not heading and not content:
                continue

            if not heading:
                # Preamble without heading goes to extras.
                model.extras.append(
                    AgentSection(heading="", content=content)
                )
                continue

            # Map heading to canonical field.
            field = HEADING_MAP.get(heading.lower())

            section = AgentSection(heading=heading, content=content)

            if field is None:
                # Explicitly mapped to None -> extras.
                model.extras.append(section)
            else:
                model.set_section(field, section)

        return model
