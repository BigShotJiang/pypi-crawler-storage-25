"""Markdown parsing utilities for splitting by headings and handling frontmatter."""

from __future__ import annotations

import re
from typing import Dict, List, Tuple

import yaml


_HEADING_RE = re.compile(r"^(#{1,2})\s+(.+?)(?:\s+#+)?$", re.MULTILINE)


def split_by_headings(markdown: str) -> List[Dict[str, str]]:
    """Split markdown by ## or # headings.

    Subheadings (###+) stay in the parent section. Content before any heading
    gets an empty string as its heading.

    Returns a list of dicts with "heading" and "content" keys.
    """
    matches = list(_HEADING_RE.finditer(markdown))

    if not matches:
        return [{"heading": "", "content": markdown}]

    sections: List[Dict[str, str]] = []

    # Content before the first heading
    first_match = matches[0]
    preamble = markdown[: first_match.start()].strip()
    if preamble:
        sections.append({"heading": "", "content": preamble})

    for i, match in enumerate(matches):
        heading = match.group(2).strip()
        start = match.end()
        end = matches[i + 1].start() if i + 1 < len(matches) else len(markdown)
        content = markdown[start:end].strip()
        sections.append({"heading": heading, "content": content})

    return sections


def parse_frontmatter(content: str) -> Tuple[Dict, str]:
    """Parse YAML frontmatter from content.

    Returns a tuple of (frontmatter_dict, body_content).
    If no frontmatter is found, returns ({}, original_content).
    """
    stripped = content.strip()
    if not stripped.startswith("---"):
        return {}, content

    # Find the closing --- delimiter
    end_match = re.search(r"\n---", stripped[3:])
    if end_match is None:
        return {}, content

    fm_text = stripped[3 : 3 + end_match.start()]
    body = stripped[3 + end_match.end() :].strip()

    fm_data = yaml.safe_load(fm_text)
    if fm_data is None:
        fm_data = {}

    return fm_data, body


def strip_frontmatter(content: str) -> str:
    """Remove YAML frontmatter from content and return the body."""
    _, body = parse_frontmatter(content)
    return body
