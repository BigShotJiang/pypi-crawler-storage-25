"""Abstract base class for agent config parsers."""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path
from typing import List

from agentsmd.converter.canonical import CanonicalModel


class BaseParser(ABC):
    """Base class for parsing agent configuration files into CanonicalModel."""

    file_patterns: List[str] = []
    dir_patterns: List[str] = []

    def detect(self, workspace_path: Path) -> bool:
        """Check if the expected files or directories exist in the workspace."""
        for pattern in self.file_patterns:
            if (workspace_path / pattern).exists():
                return True
        for pattern in self.dir_patterns:
            if (workspace_path / pattern).is_dir():
                return True
        return False

    @abstractmethod
    def parse(self, workspace_path: Path) -> CanonicalModel:
        """Parse workspace agent config files into a CanonicalModel."""
        ...
