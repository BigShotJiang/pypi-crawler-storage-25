"""Parser for Cursor .cursor/rules/*.mdc files."""

from __future__ import annotations

from pathlib import Path
from typing import Dict, List

from agentsmd.converter.canonical import AgentSection, CanonicalModel
from agentsmd.converter.parsers.base import BaseParser
from agentsmd.converter.parsers.markdown_utils import parse_frontmatter, split_by_headings

HEADING_MAP: Dict[str, str] = {
    "overview": "overview",
    "project overview": "overview",
    "rules": "rules",
    "coding standards": "rules",
    "code style": "rules",
    "constraints": "constraints",
    "what not to do": "constraints",
    "context": "context",
    "what to remember": "context",
    "workflow": "workflow",
    "development workflow": "workflow",
    "testing": "testing",
    "file structure": "file_structure",
    "documentation": "documentation",
    "environment": "environment",
    "ai behavior": "extras",
}


def _normalize_globs(globs) -> List[str]:
    """Normalize globs to a list of strings."""
    if globs is None:
        return []
    if isinstance(globs, str):
        return [globs]
    return list(globs)


def _map_heading(heading: str) -> str:
    """Map a heading string to a canonical section name."""
    return HEADING_MAP.get(heading.lower().strip(), "")


class CursorParser(BaseParser):
    """Parse .cursor/rules/*.mdc files into CanonicalModel."""

    dir_patterns: List[str] = [".cursor/rules"]

    def parse(self, workspace_path: Path) -> CanonicalModel:
        """Parse all .mdc files from .cursor/rules/ into a CanonicalModel."""
        model = CanonicalModel()
        rules_dir = workspace_path / ".cursor" / "rules"

        if not rules_dir.is_dir():
            return model

        mdc_files = sorted(rules_dir.glob("*.mdc"))

        for mdc_file in mdc_files:
            content = mdc_file.read_text(encoding="utf-8")
            fm_data, body = parse_frontmatter(content)

            description = fm_data.get("description")
            globs = _normalize_globs(fm_data.get("globs"))

            self._parse_body_into_model(model, body, description, globs)

        return model

    def _parse_body_into_model(
        self,
        model: CanonicalModel,
        body: str,
        description: str | None,
        globs: List[str],
    ) -> None:
        """Parse markdown body into sections and merge into the model."""
        sections = split_by_headings(body)

        # Check if there are any headings at all
        has_any_headings = any(s["heading"] for s in sections)

        if not has_any_headings:
            # No headings -- treat entire body as rules section
            self._merge_section(
                model, "rules", "Rules", body.strip(), description, globs
            )
            return

        for section in sections:
            heading = section["heading"]
            content = section["content"].strip()

            if not heading:
                # Preamble content before any heading goes to rules
                if content:
                    self._merge_section(
                        model, "rules", "Rules", content, description, globs
                    )
                continue

            section_name = _map_heading(heading)
            if not section_name:
                # Unrecognized heading → extras
                model.extras.append(AgentSection(
                    heading=heading,
                    content=content,
                    description=description,
                    globs=globs if globs else None,
                ))
                continue

            if section_name == "extras":
                section_obj = AgentSection(
                    heading=heading,
                    content=content,
                    description=description,
                    globs=globs if globs else None,
                )
                model.extras.append(section_obj)
            else:
                self._merge_section(
                    model, section_name, heading, content, description, globs
                )

    def _merge_section(
        self,
        model: CanonicalModel,
        section_name: str,
        heading: str,
        content: str,
        description: str | None,
        globs: List[str],
    ) -> None:
        """Merge content into a section, appending if it already exists."""
        existing: AgentSection | None = getattr(model, section_name, None)

        if existing is not None:
            # Append content to existing section
            existing.content = existing.content + "\n\n" + content if existing.content else content
            # Preserve trigger metadata if present
            if globs and not existing.globs:
                existing.globs = globs
            if description and not existing.description:
                existing.description = description
        else:
            section_obj = AgentSection(
                heading=heading,
                content=content,
                description=description,
                globs=globs if globs else None,
            )
            model.set_section(section_name, section_obj)
