"""Canonical model for agent configuration sections."""

from __future__ import annotations

from typing import List, Optional

from pydantic import BaseModel

SECTION_FIELDS: List[str] = [
    "overview",
    "rules",
    "constraints",
    "context",
    "workflow",
    "testing",
    "file_structure",
    "documentation",
    "environment",
]


class AgentSection(BaseModel):
    """A single section within an agent configuration."""

    heading: str
    content: str
    trigger: Optional[str] = None
    globs: Optional[List[str]] = None
    description: Optional[str] = None


class CanonicalModel(BaseModel):
    """Canonical representation of all agent configuration sections."""

    overview: Optional[AgentSection] = None
    rules: Optional[AgentSection] = None
    constraints: Optional[AgentSection] = None
    context: Optional[AgentSection] = None
    workflow: Optional[AgentSection] = None
    testing: Optional[AgentSection] = None
    file_structure: Optional[AgentSection] = None
    documentation: Optional[AgentSection] = None
    environment: Optional[AgentSection] = None
    extras: List[AgentSection] = []

    def all_sections(self) -> List[AgentSection]:
        """Return all non-None named sections plus extras."""
        sections: List[AgentSection] = []
        for field_name in SECTION_FIELDS:
            section = getattr(self, field_name)
            if section is not None:
                sections.append(section)
        sections.extend(self.extras)
        return sections

    def set_section(self, name: str, section: AgentSection) -> None:
        """Set a named field if it matches a known field, otherwise append to extras."""
        if name in SECTION_FIELDS:
            setattr(self, name, section)
        else:
            self.extras.append(section)
