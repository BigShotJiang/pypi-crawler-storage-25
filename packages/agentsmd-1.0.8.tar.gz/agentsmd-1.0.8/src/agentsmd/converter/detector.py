from __future__ import annotations

from pathlib import Path

from agentsmd.converter.registry import FORMATS


def detect_tools(workspace_path: Path) -> list[str]:
    """Auto-detect active tools from workspace file/directory presence."""
    detected: list[str] = []
    for format_name, info in FORMATS.items():
        found = False
        for file_pattern in info.get("files", []):
            if (workspace_path / file_pattern).exists():
                found = True
                break
        if not found:
            for dir_pattern in info.get("dirs", []):
                if (workspace_path / dir_pattern).is_dir():
                    found = True
                    break
        if found:
            detected.append(format_name)
    return detected
