from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from agentsmd.converter.detector import detect_tools
from agentsmd.converter.registry import get_parser, get_renderer


@dataclass
class ReconcileResult:
    success: bool
    files_written: list[str] = field(default_factory=list)
    error: Optional[str] = None
    changed_files: list[str] = field(default_factory=list)


def compute_file_hashes(workspace_path: Path, file_paths: list[str]) -> dict[str, str]:
    """Compute SHA256 hashes for the given files relative to workspace."""
    hashes = {}
    for rel_path in file_paths:
        full_path = workspace_path / rel_path
        if full_path.exists():
            content = full_path.read_bytes()
            digest = hashlib.sha256(content).hexdigest()
            hashes[rel_path] = f"sha256:{digest}"
    return hashes


def load_manifest(workspace_path: Path) -> dict[str, str]:
    """Load file hashes from .agentsmd/manifest.json."""
    manifest_path = workspace_path / ".agentsmd" / "manifest.json"
    if not manifest_path.exists():
        return {}
    try:
        data = json.loads(manifest_path.read_text(encoding="utf-8"))
        return data.get("files", {})
    except (json.JSONDecodeError, KeyError):
        return {}


def save_manifest(workspace_path: Path, file_hashes: dict[str, str]) -> None:
    """Save file hashes to .agentsmd/manifest.json."""
    agentsmd_dir = workspace_path / ".agentsmd"
    agentsmd_dir.mkdir(parents=True, exist_ok=True)
    manifest_path = agentsmd_dir / "manifest.json"

    existing = {}
    if manifest_path.exists():
        try:
            existing = json.loads(manifest_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            pass

    existing["version"] = 2
    existing["files"] = file_hashes
    existing["tools_detected"] = detect_tools(workspace_path)
    existing["last_reconcile"] = _utc_now_iso()

    manifest_path.write_text(json.dumps(existing, indent=2), encoding="utf-8")


def detect_changes(
    workspace_path: Path,
    old_manifest: dict[str, str],
    watch_paths: list[str],
) -> list[str]:
    """Compare current file hashes against manifest. Returns list of changed file paths."""
    current_hashes = compute_file_hashes(workspace_path, watch_paths)
    changed = []
    for path, current_hash in current_hashes.items():
        old_hash = old_manifest.get(path)
        if old_hash != current_hash:
            changed.append(path)
    # Also detect new files not in manifest
    for path in current_hashes:
        if path not in old_manifest:
            changed.append(path)
    return list(set(changed))


def _collect_watch_paths(workspace_path: Path) -> list[str]:
    """Collect all file paths that should be watched for changes."""
    from agentsmd.converter.registry import FORMATS

    paths = []
    for fmt_name, info in FORMATS.items():
        for file_pattern in info.get("files", []):
            full = workspace_path / file_pattern
            if full.exists():
                paths.append(file_pattern)
        for dir_pattern in info.get("dirs", []):
            full_dir = workspace_path / dir_pattern
            if full_dir.is_dir():
                for f in full_dir.rglob("*"):
                    if f.is_file():
                        try:
                            paths.append(str(f.relative_to(workspace_path)))
                        except ValueError:
                            pass
    return paths


def _determine_source_format(
    workspace_path: Path,
    changed_files: list[str],
    detected_tools: list[str],
) -> Optional[str]:
    """Determine which format should be the source of truth based on changes."""
    from agentsmd.converter.registry import FORMATS

    changed_tools = set()
    for fmt_name, info in FORMATS.items():
        for file_pattern in info.get("files", []):
            if file_pattern in changed_files:
                changed_tools.add(fmt_name)
        for dir_pattern in info.get("dirs", []):
            for changed in changed_files:
                if changed.startswith(dir_pattern):
                    changed_tools.add(fmt_name)

    if "agents" in changed_tools:
        return "agents"
    if len(changed_tools) == 1:
        return changed_tools.pop()
    if len(changed_tools) > 1:
        if "agents" in detected_tools:
            return "agents"
        return detected_tools[0] if detected_tools else None
    return None


def _utc_now_iso() -> str:
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).isoformat()


def reconcile(
    workspace_path: Path,
    source_format: Optional[str] = None,
) -> ReconcileResult:
    """Reconcile all tool config formats in the workspace."""
    detected = detect_tools(workspace_path)
    if not detected:
        return ReconcileResult(success=True)

    watch_paths = _collect_watch_paths(workspace_path)
    old_manifest = load_manifest(workspace_path)
    changed = detect_changes(workspace_path, old_manifest, watch_paths)

    if not changed and source_format is None:
        return ReconcileResult(success=True)

    src = source_format or _determine_source_format(workspace_path, changed, detected)
    if src is None:
        return ReconcileResult(success=False, error="Could not determine source format")

    if src not in detected:
        return ReconcileResult(success=False, error=f"Source format '{src}' not detected in workspace")

    parser = get_parser(src)
    if parser is None:
        return ReconcileResult(success=False, error=f"No parser for format '{src}'")

    model = parser.parse(workspace_path)

    if not model.all_sections():
        return ReconcileResult(success=False, error=f"Source file is empty or contains no parseable sections")

    files_written: list[str] = []
    for fmt in detected:
        if fmt == src:
            continue
        renderer = get_renderer(fmt)
        if renderer is None:
            continue
        files = renderer.render(model, workspace_path)
        for rel_path, content in files.items():
            full_path = workspace_path / rel_path
            full_path.parent.mkdir(parents=True, exist_ok=True)
            full_path.write_text(content, encoding="utf-8")
            files_written.append(rel_path)

    new_watch_paths = _collect_watch_paths(workspace_path)
    new_hashes = compute_file_hashes(workspace_path, new_watch_paths)
    save_manifest(workspace_path, new_hashes)

    return ReconcileResult(
        success=True,
        files_written=files_written,
        changed_files=changed,
    )
