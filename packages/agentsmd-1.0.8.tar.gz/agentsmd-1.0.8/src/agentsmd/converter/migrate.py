from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from agentsmd.converter.detector import detect_tools
from agentsmd.converter.registry import get_parser, get_renderer


@dataclass
class MigrateResult:
    success: bool
    output: Optional[str] = None
    error: Optional[str] = None
    files_written: list[str] = field(default_factory=list)


def run_migrate(
    workspace_path: Path,
    source_format: str,
    target_format: Optional[str] = None,
    dry_run: bool = False,
) -> MigrateResult:
    """Run migration from source format to target format.

    If target_format is None, converts to AGENTS.md and re-derives all detected tool files.
    """
    parser = get_parser(source_format)
    if parser is None:
        return MigrateResult(success=False, error=f"Unknown format: {source_format}")

    if not parser.detect(workspace_path):
        return MigrateResult(success=False, error=f"Source format '{source_format}' not detected in workspace")

    model = parser.parse(workspace_path)

    if not model.all_sections():
        return MigrateResult(success=False, error=f"Source file is empty or contains no parseable sections")

    if dry_run:
        if target_format:
            renderer = get_renderer(target_format)
            if renderer is None:
                return MigrateResult(success=False, error=f"Unknown target format: {target_format}")
            files = renderer.render(model, workspace_path)
        else:
            renderer = get_renderer("agents")
            files = renderer.render(model, workspace_path)
        output = "\n\n".join(f"=== {path} ===\n{content}" for path, content in files.items())
        return MigrateResult(success=True, output=output)

    if target_format:
        renderer = get_renderer(target_format)
        if renderer is None:
            return MigrateResult(success=False, error=f"Unknown target format: {target_format}")
        files = renderer.render(model, workspace_path)
        written = _write_files(workspace_path, files)
        return MigrateResult(success=True, files_written=written)

    # No target specified: convert to AGENTS.md and re-derive all detected tools
    agents_renderer = get_renderer("agents")
    agents_files = agents_renderer.render(model, workspace_path)
    written = _write_files(workspace_path, agents_files)

    # Re-derive all other detected tool formats
    detected = detect_tools(workspace_path)
    for fmt in detected:
        if fmt == source_format or fmt == "agents":
            continue
        renderer = get_renderer(fmt)
        if renderer:
            files = renderer.render(model, workspace_path)
            written.extend(_write_files(workspace_path, files))

    return MigrateResult(success=True, files_written=written)


def _write_files(workspace_path: Path, files: dict[str, str]) -> list[str]:
    """Write rendered files to workspace. Returns list of written file paths."""
    written = []
    for rel_path, content in files.items():
        full_path = workspace_path / rel_path
        full_path.parent.mkdir(parents=True, exist_ok=True)
        full_path.write_text(content, encoding="utf-8")
        written.append(rel_path)
    return written
