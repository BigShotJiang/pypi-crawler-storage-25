from __future__ import annotations

from typing import Optional

from agentsmd.converter.parsers.base import BaseParser
from agentsmd.converter.parsers.agents_md import AgentsMdParser
from agentsmd.converter.parsers.claude_md import ClaudeMdParser
from agentsmd.converter.parsers.cursor import CursorParser
from agentsmd.converter.parsers.windsurf import WindsurfParser
from agentsmd.converter.parsers.copilot import CopilotParser

from agentsmd.converter.renderers.base import BaseRenderer
from agentsmd.converter.renderers.agents_md import AgentsMdRenderer
from agentsmd.converter.renderers.claude_md import ClaudeMdRenderer
from agentsmd.converter.renderers.cursor import CursorRenderer
from agentsmd.converter.renderers.windsurf import WindsurfRenderer
from agentsmd.converter.renderers.copilot import CopilotRenderer


FORMATS: dict[str, dict] = {
    "agents": {
        "files": ["AGENTS.md"],
        "dirs": [],
        "parser": AgentsMdParser,
        "renderer": AgentsMdRenderer,
    },
    "claude": {
        "files": ["CLAUDE.md"],
        "dirs": [],
        "parser": ClaudeMdParser,
        "renderer": ClaudeMdRenderer,
    },
    "cursor": {
        "files": [],
        "dirs": [".cursor/rules"],
        "parser": CursorParser,
        "renderer": CursorRenderer,
    },
    "windsurf": {
        "files": [],
        "dirs": [".windsurf/rules"],
        "parser": WindsurfParser,
        "renderer": WindsurfRenderer,
    },
    "copilot": {
        "files": [".github/copilot-instructions.md"],
        "dirs": [".github/instructions"],
        "parser": CopilotParser,
        "renderer": CopilotRenderer,
    },
}


def list_formats() -> list[str]:
    return list(FORMATS.keys())


def get_parser(format_name: str) -> Optional[BaseParser]:
    entry = FORMATS.get(format_name)
    if entry is None:
        return None
    return entry["parser"]()


def get_renderer(format_name: str) -> Optional[BaseRenderer]:
    entry = FORMATS.get(format_name)
    if entry is None:
        return None
    return entry["renderer"]()


def get_format_info(format_name: str) -> Optional[dict]:
    return FORMATS.get(format_name)
