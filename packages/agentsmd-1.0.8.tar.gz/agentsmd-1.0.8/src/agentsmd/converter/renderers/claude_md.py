"""Renderer for CLAUDE.md agent configuration files."""

from __future__ import annotations

from pathlib import Path
from typing import Dict, List

from agentsmd.converter.canonical import CanonicalModel
from agentsmd.converter.renderers.base import BaseRenderer


class ClaudeMdRenderer(BaseRenderer):
    """Render a CanonicalModel into a CLAUDE.md file."""

    file_patterns: List[str] = ["CLAUDE.md"]

    def render(self, model: CanonicalModel, workspace_path: Path) -> Dict[str, str]:
        """Render the canonical model as a CLAUDE.md string.

        If AGENTS.md already exists in the workspace, the renderer emits
        ``@AGENTS.md`` at the top instead of duplicating content that the
        shared AGENTS.md already carries, and then appends any extras.

        If no AGENTS.md exists, all named sections plus extras are rendered
        normally under ``##`` headings.
        """
        agents_md_exists = (workspace_path / "AGENTS.md").is_file()

        if agents_md_exists:
            return {"CLAUDE.md": self._render_with_import(model)}

        return {"CLAUDE.md": self._render_full(model)}

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _render_with_import(self, model: CanonicalModel) -> str:
        """Render when AGENTS.md is present: use @import + extras only."""
        lines: List[str] = ["@AGENTS.md"]

        for section in model.extras:
            if section.heading:
                lines.append("")
                lines.append(f"## {section.heading}")
                lines.append("")
            lines.append(section.content)

        return "\n".join(lines) + "\n"

    def _render_full(self, model: CanonicalModel) -> str:
        """Render all sections with ## headings."""
        lines: List[str] = []

        for section in model.all_sections():
            if lines:
                lines.append("")
            if section.heading:
                lines.append(f"## {section.heading}")
                lines.append("")
            lines.append(section.content)

        return "\n".join(lines) + "\n"
