"""Renderer for Cursor .cursor/rules/*.mdc files."""

from __future__ import annotations

from pathlib import Path
from typing import Dict, List

import yaml

from agentsmd.converter.canonical import CanonicalModel
from agentsmd.converter.renderers.base import BaseRenderer


class CursorRenderer(BaseRenderer):
    """Render CanonicalModel into .cursor/rules/general.mdc."""

    dir_patterns: List[str] = [".cursor/rules"]

    def render(self, model: CanonicalModel, workspace_path: Path) -> Dict[str, str]:
        """Render a CanonicalModel into Cursor .mdc format."""
        sections = model.all_sections()

        if not sections:
            return {}

        # Build frontmatter
        frontmatter: Dict = {"alwaysApply": True}

        # Collect any globs from sections
        all_globs: List[str] = []
        for section in sections:
            if section.globs:
                for g in section.globs:
                    if g not in all_globs:
                        all_globs.append(g)

        if all_globs:
            frontmatter["globs"] = all_globs

        # Build body content
        body_parts: List[str] = []
        for section in sections:
            heading = section.heading
            content = section.content.strip()
            if heading:
                body_parts.append(f"## {heading}\n\n{content}")
            else:
                body_parts.append(content)

        body = "\n\n".join(body_parts)

        # Build full .mdc file
        fm_yaml = yaml.dump(frontmatter, default_flow_style=False).strip()
        full_content = f"---\n{fm_yaml}\n---\n\n{body}\n"

        return {".cursor/rules/general.mdc": full_content}
