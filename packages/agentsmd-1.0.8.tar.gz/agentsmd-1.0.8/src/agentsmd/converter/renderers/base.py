"""Abstract base class for agent config renderers."""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Dict, List

from agentsmd.converter.canonical import CanonicalModel


class BaseRenderer(ABC):
    """Base class for rendering CanonicalModel into agent config files."""

    file_patterns: List[str] = []
    dir_patterns: List[str] = []

    @abstractmethod
    def render(self, model: CanonicalModel, workspace_path: Path) -> Dict[str, str]:
        """Render a CanonicalModel into a dict of relative file paths to content.

        Returns:
            Dictionary mapping relative file paths (str) to file content (str).
        """
        ...
