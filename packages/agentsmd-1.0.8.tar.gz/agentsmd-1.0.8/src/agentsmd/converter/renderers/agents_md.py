"""AGENTS.md renderer — renders a CanonicalModel into AGENTS.md content."""

from __future__ import annotations

from pathlib import Path
from typing import Dict, List

from agentsmd.converter.canonical import CanonicalModel
from agentsmd.converter.renderers.base import BaseRenderer

# Ordered headings for rendering known sections.
_HEADING_MAP = {
    "overview": "Overview",
    "rules": "Rules",
    "constraints": "Constraints",
    "context": "Context",
    "workflow": "Workflow",
    "testing": "Testing",
    "file_structure": "File Structure",
    "documentation": "Documentation",
    "environment": "Environment",
}


class AgentsMdRenderer(BaseRenderer):
    """Render a CanonicalModel into AGENTS.md."""

    file_patterns: List[str] = ["AGENTS.md"]

    def render(self, model: CanonicalModel, workspace_path: Path) -> Dict[str, str]:
        """Render a CanonicalModel to a dict mapping 'AGENTS.md' to its content."""
        from agentsmd.converter.canonical import SECTION_FIELDS

        parts: List[str] = []

        for field_name in SECTION_FIELDS:
            section = getattr(model, field_name, None)
            if section is not None:
                heading = _HEADING_MAP.get(field_name, section.heading)
                parts.append(f"## {heading}\n\n{section.content}")

        for extra in model.extras:
            parts.append(f"## {extra.heading}\n\n{extra.content}")

        content = "\n\n".join(parts)
        if content:
            content += "\n"

        return {"AGENTS.md": content}
