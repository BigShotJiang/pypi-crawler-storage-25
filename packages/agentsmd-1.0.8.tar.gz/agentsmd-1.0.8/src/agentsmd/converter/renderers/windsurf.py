"""Renderer for Windsurf .windsurf/rules/*.md files."""

from __future__ import annotations

from pathlib import Path
from typing import Dict, List

import yaml

from agentsmd.converter.canonical import CanonicalModel
from agentsmd.converter.renderers.base import BaseRenderer


class WindsurfRenderer(BaseRenderer):
    """Render CanonicalModel into .windsurf/rules/general.md."""

    dir_patterns: List[str] = [".windsurf/rules"]

    def render(self, model: CanonicalModel, workspace_path: Path) -> Dict[str, str]:
        """Render a CanonicalModel into Windsurf .md format."""
        sections = model.all_sections()

        if not sections:
            return {}

        # Build frontmatter
        frontmatter: Dict = {"trigger": "always_on"}

        # Build body content
        body_parts: List[str] = []
        for section in sections:
            heading = section.heading
            content = section.content.strip()
            if heading:
                body_parts.append(f"## {heading}\n\n{content}")
            else:
                body_parts.append(content)

        body = "\n\n".join(body_parts)

        # Build full .md file with frontmatter
        fm_yaml = yaml.dump(frontmatter, default_flow_style=False).strip()
        full_content = f"---\n{fm_yaml}\n---\n\n{body}\n"

        return {".windsurf/rules/general.md": full_content}
