"""Renderer for GitHub Copilot configuration files.

Produces a single ``.github/copilot-instructions.md`` file (no frontmatter).
"""

from __future__ import annotations

from pathlib import Path
from typing import Dict, List

from agentsmd.converter.canonical import CanonicalModel
from agentsmd.converter.renderers.base import BaseRenderer


class CopilotRenderer(BaseRenderer):
    """Render a CanonicalModel into GitHub Copilot instruction format."""

    file_patterns: List[str] = [".github/copilot-instructions.md"]
    dir_patterns: List[str] = []

    def render(self, model: CanonicalModel, workspace_path: Path) -> Dict[str, str]:
        """Render the model into a single copilot-instructions.md file.

        Returns a dict mapping ``".github/copilot-instructions.md"`` to the
        rendered markdown content.
        """
        parts: List[str] = []

        for section in model.all_sections():
            heading = section.heading
            content = section.content
            if heading:
                parts.append(f"## {heading}\n\n{content}")
            else:
                parts.append(content)

        rendered = "\n\n".join(parts)
        return {".github/copilot-instructions.md": rendered}
