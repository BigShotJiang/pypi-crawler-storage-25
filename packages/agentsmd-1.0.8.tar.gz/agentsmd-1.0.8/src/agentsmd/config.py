"""Configuration and credential management for AgentsMD."""

import os
import json
from pathlib import Path
from typing import Optional

CONFIG_DIR = Path.home() / ".agentsmd"
CREDENTIALS_FILE = CONFIG_DIR / "credentials.json"

def _ensure_config_dir() -> None:
    """Ensure ~/.agentsmd directory exists."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)

def get_token(cli_token: Optional[str] = None) -> Optional[str]:
    """Get stored credentials from local storage, env var, or CLI flag.

    Order of precedence:
    1. CLI Flag
    2. AGENTSMD_API_TOKEN environment variable
    3. credentials.json file
    """
    if cli_token:
        return cli_token

    if "AGENTSMD_API_TOKEN" in os.environ:
        return os.environ["AGENTSMD_API_TOKEN"]

    if not CREDENTIALS_FILE.exists():
        return None

    try:
        with open(CREDENTIALS_FILE, "r") as f:
            data = json.load(f)
            return data.get("api_token")
    except (json.JSONDecodeError, KeyError):
        return None

def save_token(token: str) -> None:
    """Save token to local storage."""
    _ensure_config_dir()

    data = {
        "api_token": token,
    }

    with open(CREDENTIALS_FILE, "w") as f:
        json.dump(data, f, indent=2)

def clear_credentials() -> None:
    """Remove stored credentials."""
    if CREDENTIALS_FILE.exists():
        CREDENTIALS_FILE.unlink()


def get_api_url() -> str:
    """Get the backend API base URL."""
    return os.environ.get(
        "AGENTSMD_API_URL",
        "https://agentsmd-api-1007077428197.europe-west1.run.app",
    )