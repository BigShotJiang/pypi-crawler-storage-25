"""Local machine identity for multi-device sync."""

import json
import platform
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

CONFIG_DIR = Path.home() / ".agentsmd"
MACHINE_FILE = CONFIG_DIR / "machine.json"


def _ensure_config_dir() -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)


def get_machine_id() -> Optional[str]:
    """Read existing machine ID from local storage."""
    if not MACHINE_FILE.exists():
        return None

    try:
        with open(MACHINE_FILE, "r") as f:
            data = json.load(f)
            return data.get("machine_id")
    except (json.JSONDecodeError, KeyError):
        return None


def ensure_machine_id() -> str:
    """Get existing machine ID or generate and store a new one."""
    existing = get_machine_id()
    if existing:
        return existing

    machine_id = str(uuid.uuid4())
    _ensure_config_dir()

    data = {
        "machine_id": machine_id,
        "display_name": platform.node(),
        "created_at": datetime.now(timezone.utc).isoformat(),
    }

    with open(MACHINE_FILE, "w") as f:
        json.dump(data, f, indent=2)

    return machine_id
