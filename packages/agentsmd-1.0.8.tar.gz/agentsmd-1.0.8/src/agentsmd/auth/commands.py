"""Authentication command implementations."""

import sys
from typing import Optional
from agentsmd.config import get_token, save_token, clear_credentials

def require_token(cli_token: Optional[str] = None) -> str:
    """Ensure a token is present, otherwise exit with instructions."""
    token = get_token(cli_token)
    if token:
        return token

    print("Error: Authentication required.")
    print("Please generate an API token at https://agentsmd.live/settings/tokens")
    print("and provide it via the --token flag, or the AGENTSMD_API_TOKEN environment variable.")
    print("You can also save it globally using: agentsmd login --token <TOKEN>")
    sys.exit(1)

async def run_login(token: Optional[str] = None) -> None:
    """Run authentication token saving flow."""
    if not token:
        print("Error: No token provided.")
        print("Please generate an API token at https://agentsmd.live/settings/tokens")
        print("and run: agentsmd login --token <TOKEN>")
        sys.exit(1)

    save_token(token)
    print("Token saved successfully to ~/.agentsmd/credentials.json")
    print("You are now authenticated!")

async def run_logout() -> None:
    """Clear local credentials and logout."""
    token = get_token()
    if not token:
        print("Not logged in.")
        return

    clear_credentials()
    print("Credentials cleared from ~/.agentsmd/")
    print("You are now logged out.")
