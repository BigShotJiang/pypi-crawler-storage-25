"""AgentsMD CLI - Command-line interface.

Orchestrates workspace initialization, synchronization, and authentication.
"""

import sys
import logging
import typer
from pathlib import Path
from typing import Optional

logging.basicConfig(level=logging.INFO, format="%(message)s")
logging.getLogger("httpx").setLevel(logging.WARNING)
logger = logging.getLogger(__name__)

app = typer.Typer(
    name="agentsmd",
    help="AgentsMD - Intelligent workspace scaffolding and file synchronization",
    add_completion=False,
    no_args_is_help=True
)


@app.command(name="init")
def init_cmd(
    name: Optional[str] = typer.Option(
        None,
        "--name",
        "-n",
        help="Workspace name (skips interactive picker)",
    ),
    from_workspace: Optional[str] = typer.Option(
        None,
        "--from",
        help="Clone an existing workspace by name",
    ),
    directory: Optional[Path] = typer.Option(
        None,
        "--directory",
        "-d",
        help="Target directory (only with --from)",
    ),
    force: bool = typer.Option(
        False,
        "--force",
        "-f",
        help="Proceed even if directory is not empty",
    ),
):
    """Initialize a workspace (new or cloned from cloud)."""
    try:
        from agentsmd.init.commands import run
        import asyncio
        asyncio.run(run(name=name, from_workspace=from_workspace, directory=directory, force=force))
    except KeyboardInterrupt:
        print("\n\nInitialization cancelled.")
        sys.exit(0)
    except Exception as e:
        logger.error(f"Initialization failed: {e}")
        raise typer.Exit(code=1)


@app.command(name="link")
def link_cmd(
    name: Optional[str] = typer.Argument(
        None,
        help="Workspace name to bind this folder to",
    ),
    remove: bool = typer.Option(
        False,
        "--remove",
        help="Remove local workspace binding",
    ),
):
    """Link this folder to a cloud workspace, or remove the link."""
    try:
        from agentsmd.workspaces_cmd import run_link
        import asyncio
        asyncio.run(run_link(name=name, remove=remove))
    except Exception as e:
        logger.error(f"Link failed: {e}")
        raise typer.Exit(code=1)


@app.command(name="list")
def list_cmd():
    """List your cloud workspaces."""
    try:
        from agentsmd.workspaces_cmd import run_list
        import asyncio
        asyncio.run(run_list())
    except Exception as e:
        logger.error(f"List failed: {e}")
        raise typer.Exit(code=1)


@app.command(name="sync")
def sync_cmd(
    workspace_path: Optional[Path] = typer.Argument(
        None,
        help="Path to workspace directory"
    )
):
    """Bidirectional sync: upload local changes and download cloud changes."""
    try:
        from agentsmd.sync.commands import run as run_sync
        import asyncio
        asyncio.run(run_sync(workspace_path=str(workspace_path) if workspace_path else None))
    except Exception as e:
        logger.error("Sync failed.")
        raise typer.Exit(code=1)


@app.command(name="up")
def up_cmd(
    workspace_path: Optional[Path] = typer.Argument(
        None,
        help="Path to workspace directory"
    )
):
    """Upload local changes to cloud."""
    try:
        from agentsmd.sync.commands import run_up
        import asyncio
        asyncio.run(run_up(workspace_path=str(workspace_path) if workspace_path else None))
    except Exception as e:
        logger.error("Upload failed.")
        raise typer.Exit(code=1)


@app.command(name="down")
def down_cmd(
    workspace_path: Optional[Path] = typer.Argument(
        None,
        help="Path to workspace directory"
    )
):
    """Download cloud changes to local."""
    try:
        from agentsmd.sync.commands import run_down
        import asyncio
        asyncio.run(run_down(workspace_path=str(workspace_path) if workspace_path else None))
    except Exception as e:
        logger.error("Download failed.")
        raise typer.Exit(code=1)


@app.command(name="status")
def status_cmd(
    workspace_path: Optional[Path] = typer.Argument(
        None,
        help="Path to workspace directory"
    )
):
    """Show workspace synchronization status."""
    try:
        from agentsmd.sync.commands import run_status
        import asyncio
        asyncio.run(run_status(workspace_path=str(workspace_path) if workspace_path else None))
    except Exception:
        logger.error("Status check failed.")
        raise typer.Exit(code=1)


@app.command(name="login")
def login_cmd(
    token: Optional[str] = typer.Option(
        None,
        "--token",
        "-t",
        help="API token to save globally"
    )
):
    """Authenticate via API token."""
    try:
        from agentsmd.auth.commands import run_login
        import asyncio
        asyncio.run(run_login(token))
    except Exception as e:
        logger.error(f"Login failed: {e}")
        raise typer.Exit(code=1)


@app.command(name="logout")
def logout_cmd():
    """Clear local credentials."""
    try:
        from agentsmd.auth.commands import run_logout
        import asyncio
        asyncio.run(run_logout())
    except Exception as e:
        logger.error(f"Logout failed: {e}")
        raise typer.Exit(code=1)


@app.command(name="convert")
def convert_cmd(
    source: Optional[str] = typer.Option(
        None,
        "--from",
        help="Source format (agents, claude, cursor, windsurf, copilot)",
    ),
    target: Optional[str] = typer.Option(
        None,
        "--to",
        help="Target format (default: agents + re-derive all)",
    ),
    reconcile: bool = typer.Option(
        False,
        "--reconcile",
        help="Auto-detect source and re-derive all formats",
    ),
    dry_run: bool = typer.Option(
        False,
        "--dry-run",
        help="Print output without writing files",
    ),
):
    """Convert between AI tool config formats."""
    try:
        if reconcile:
            from agentsmd.converter.reconcile import reconcile as do_reconcile
            result = do_reconcile(Path.cwd(), source_format=source)

            if not result.success:
                print(f"Error: {result.error}")
                raise typer.Exit(code=1)

            if result.changed_files:
                print(f"Changed files: {result.changed_files}")
            if result.files_written:
                for f in result.files_written:
                    print(f"  Written: {f}")
                print(f"\nReconcile complete. {len(result.files_written)} file(s) updated.")
            else:
                print("All formats are in sync. No changes needed.")
        else:
            if not source:
                print("Error: --from is required (or use --reconcile)")
                raise typer.Exit(code=1)

            from agentsmd.converter.migrate import run_migrate
            result = run_migrate(Path.cwd(), source_format=source, target_format=target, dry_run=dry_run)

            if not result.success:
                print(f"Error: {result.error}")
                raise typer.Exit(code=1)

            if dry_run and result.output:
                print(result.output)
            else:
                for f in result.files_written:
                    print(f"  Written: {f}")
                print(f"\nConversion complete. {len(result.files_written)} file(s) written.")
    except Exception as e:
        logger.error(f"Convert failed: {e}")
        raise typer.Exit(code=1)


# --- Hidden backward-compat aliases ---

@app.command(name="clone", hidden=True)
def clone_cmd(
    name: str = typer.Argument(..., help="Workspace name to pull"),
    directory: Optional[Path] = typer.Argument(
        None,
        help="Directory to create (defaults to ./<name>)",
    ),
):
    """[Hidden] Use 'init --from' instead."""
    try:
        from agentsmd.workspaces_cmd import run_clone
        import asyncio
        asyncio.run(run_clone(name=name, directory=directory))
    except Exception as e:
        logger.error(f"Clone failed: {e}")
        raise typer.Exit(code=1)


@app.command(name="unlink", hidden=True)
def unlink_cmd():
    """[Hidden] Use 'link --remove' instead."""
    try:
        from agentsmd.workspaces_cmd import run_unlink
        import asyncio
        asyncio.run(run_unlink())
    except Exception as e:
        logger.error(f"Unlink failed: {e}")
        raise typer.Exit(code=1)


@app.command(name="migrate", hidden=True)
def migrate_cmd(
    source: str = typer.Option(..., "--from", help="Source format"),
    target: Optional[str] = typer.Option(None, "--to", help="Target format"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview only"),
):
    """[Hidden] Use 'convert --from' instead."""
    from agentsmd.converter.migrate import run_migrate
    result = run_migrate(Path.cwd(), source_format=source, target_format=target, dry_run=dry_run)

    if not result.success:
        print(f"Error: {result.error}")
        raise typer.Exit(code=1)

    if dry_run and result.output:
        print(result.output)
    else:
        for f in result.files_written:
            print(f"  Written: {f}")
        print(f"\nMigration complete. {len(result.files_written)} file(s) written.")


@app.command(name="reconcile", hidden=True)
def reconcile_cmd(
    source: Optional[str] = typer.Option(None, "--from", help="Source format"),
):
    """[Hidden] Use 'convert --reconcile' instead."""
    from agentsmd.converter.reconcile import reconcile
    result = reconcile(Path.cwd(), source_format=source)

    if not result.success:
        print(f"Error: {result.error}")
        raise typer.Exit(code=1)

    if result.changed_files:
        print(f"Changed files: {result.changed_files}")
    if result.files_written:
        for f in result.files_written:
            print(f"  Written: {f}")
        print(f"\nReconcile complete. {len(result.files_written)} file(s) updated.")
    else:
        print("All formats are in sync. No changes needed.")


@app.callback()
def main(ctx: typer.Context) -> None:
    """Main entry point."""
    if ctx.resilient_parsing:
        return

    import agentsmd
    typer.echo(f"AgentsMD v{agentsmd.__version__}")


if __name__ == "__main__":
    app()
