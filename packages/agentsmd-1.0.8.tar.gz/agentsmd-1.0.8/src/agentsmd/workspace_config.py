"""Per-workspace config — the local binding between a folder and a cloud workspace.

Each synced folder gets `<workspace>/.agentsmd/workspace.json` containing the
workspace_id and workspace_name. This makes folder renames safe (identity
travels with the directory) and removes the marker-file walk-up heuristic.

`.agentsmd/workspace.json` is appended to `.gitignore` on first write because
the binding is per-developer, not per-repo.
"""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

CONFIG_DIR_NAME = ".agentsmd"
CONFIG_FILE_NAME = "workspace.json"
GITIGNORE_PATTERN = ".agentsmd/workspace.json"

# Files whose presence indicates a folder is (or was) an AgentsMD workspace.
# Used only for the legacy-adoption fallback when no workspace.json exists.
MARKER_FILES = ("AGENTS.md", "CLAUDE.md", ".cursorrules", ".windsurfrules")


def config_path(workspace: Path) -> Path:
    return workspace / CONFIG_DIR_NAME / CONFIG_FILE_NAME


def read(workspace: Path) -> Optional[dict]:
    """Read workspace.json. Returns None if missing or unreadable."""
    path = config_path(workspace)
    if not path.exists():
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        # Sanity check: both fields are required for the file to be useful.
        if not data.get("workspace_id") or not data.get("workspace_name"):
            return None
        return data
    except (json.JSONDecodeError, OSError):
        return None


def write(workspace: Path, workspace_id: str, workspace_name: str) -> None:
    """Write workspace.json and ensure .agentsmd/ is gitignored."""
    path = config_path(workspace)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "workspace_id": workspace_id,
        "workspace_name": workspace_name,
        "linked_at": datetime.now(timezone.utc).isoformat(),
    }
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)
        f.write("\n")
    _ensure_gitignored(workspace)


def delete(workspace: Path) -> bool:
    """Remove the local binding (does not touch the cloud workspace).

    Returns True if a config existed and was removed.
    """
    path = config_path(workspace)
    if not path.exists():
        return False
    path.unlink()
    return True


def has_marker_files(workspace: Path) -> bool:
    """True if the directory looks like a (legacy) AgentsMD workspace."""
    return any((workspace / m).exists() for m in MARKER_FILES)


def legacy_workspace_id(workspace: Path) -> str:
    """Recompute the pre-1.0.6 workspace id (sha256 of folder basename, first 16 hex chars).

    Used during adoption — the backend keys legacy R2 paths by this id, so we
    have to send the same value to find the existing files.
    """
    name = workspace.resolve().name
    return hashlib.sha256(name.encode()).hexdigest()[:16]


def _ensure_gitignored(workspace: Path) -> None:
    """Append `.agentsmd/workspace.json` to .gitignore if not already present.

    Best-effort: silently no-op on permission errors so sync never fails
    because we couldn't update .gitignore.
    """
    gitignore = workspace / ".gitignore"
    try:
        existing = gitignore.read_text(encoding="utf-8") if gitignore.exists() else ""
        lines = {line.strip() for line in existing.splitlines() if line.strip()}
        if GITIGNORE_PATTERN in lines or ".agentsmd/" in lines:
            return

        prefix = "" if existing.endswith("\n") or not existing else "\n"
        with open(gitignore, "a", encoding="utf-8") as f:
            f.write(f"{prefix}{GITIGNORE_PATTERN}\n")
    except OSError:
        pass
