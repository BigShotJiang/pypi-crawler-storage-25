"""Deriver module for generating multiple format documentation."""

from typing import Dict

from agentsmd.init.interview import (
    InterviewData,
    format_agents_md_data,
    get_derived_templates,
    TEMPLATE_DIR,
)


def derive_all_formats(main_content: str, primary_tool: str) -> Dict[str, str]:
    """Generate derived format files from the main format content.

    Takes the already-rendered main format content and the primary tool name,
    then produces any additional format files that should be derived.

    Args:
        main_content: The rendered content of the primary format file.
        primary_tool: User's chosen primary agent tool.

    Returns:
        Dict mapping format name (e.g. "claude_md") to rendered content.
    """
    derived_template_names = get_derived_templates(primary_tool)
    results: Dict[str, str] = {}

    for template_name in derived_template_names:
        template_file = TEMPLATE_DIR / f"{template_name}.j2"
        # Re-render from template variables embedded in main_content is not
        # feasible, so for derived formats we return a minimal header that
        # points back to the main file.
        if template_name == "claude_md":
            results[template_name] = (
                f"# Project\n\n"
                f"This project uses AGENTS.md as the primary agent configuration.\n"
                f"Refer to AGENTS.md for full context.\n\n"
                f"---\n\n"
                f"{main_content}\n"
            )

    return results
