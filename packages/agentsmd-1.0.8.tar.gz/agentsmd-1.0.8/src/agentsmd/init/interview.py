"""Interactive interview for workspace generation."""

from typing import Dict, List, Optional
from pathlib import Path
from pydantic import BaseModel

TEMPLATE_DIR = Path(__file__).parent.parent / "templates"


class InterviewData(BaseModel):
    """Structured data from interview."""
    project_type: str
    agent_tools: List[str]
    primary_tool: str
    language_stack: str
    what_to_remember: str
    what_never_to_do: str
    install_prompts: bool

    # Derived fields
    project_overview: Optional[str] = None
    technology_stack: Optional[str] = None
    file_structure: Optional[str] = None
    coding_standards: Optional[str] = None
    development_workflow: Optional[str] = None
    testing_guidelines: Optional[str] = None
    documentation_conventions: Optional[str] = None
    environment_setup: Optional[str] = None
    additional_notes: Optional[str] = None
    key_commands: List[str] = []
    ai_behavior: Optional[str] = None


QUESTION_FLOW = [
    {
        "key": "project_type",
        "question": "What kind of project is this?",
        "options": ["SaaS", "API", "CLI", "Data Pipeline", "Agent", "Library"],
        "field": "project_type"
    },
    {
        "key": "agent_tools",
        "question": "Which agent tools do you use?",
        "options": ["Claude Code", "Cursor", "Copilot", "Gemini CLI", "Windsurf", "All of above"],
        "field": "agent_tools",
        "multiple": True
    },
    {
        "key": "primary_tool",
        "question": "What is your PRIMARY agent tool?",
        "options": ["Claude Code", "Cursor", "Windsurf"],
        "field": "primary_tool",
        "condition": lambda data: "Claude Code" in data.agent_tools
    },
    {
        "key": "language_stack",
        "question": "Primary language and stack?",
        "field": "language_stack",
        "example": "Python+FastAPI / TypeScript+Next / Rust / Go"
    },
    {
        "key": "what_to_remember",
        "question": "What should agents always remember about this project?",
        "field": "what_to_remember",
        "multiline": True
    },
    {
        "key": "what_never_to_do",
        "question": "What should agents never do?",
        "field": "what_never_to_do",
        "multiline": True
    },
    {
        "key": "install_prompts",
        "question": "Install a starter prompt library?",
        "field": "install_prompts",
        "options": ["yes", "no"],
        "default": "no"
    }
]


async def run_interview() -> InterviewData:
    """Run interactive interview with user.

    Returns:
        InterviewData with all user responses.
    """
    data = InterviewData(
        project_type="",
        agent_tools=[],
        primary_tool="",
        language_stack="",
        what_to_remember="",
        what_never_to_do="",
        install_prompts=False
    )

    print("AgentsMD Workspace Initialization")
    print("=" * 40)
    print()

    try:
        for question in QUESTION_FLOW:
            if "condition" in question and not question["condition"](data):
                continue

            prompt = question["question"]

            if "options" in question:
                print(f"\n{prompt}")
                for i, option in enumerate(question["options"], 1):
                    print(f"  [{i}] {option}")

                while True:
                    choice = input("\nYour choice (number): ").strip()

                    try:
                        choice_num = int(choice) - 1
                        if 0 <= choice_num < len(question["options"]):
                            selected_option = question["options"][choice_num]

                            if question.get("multiple", False):
                                current_value = getattr(data, question["field"], [])
                                if selected_option not in current_value:
                                    current_value.append(selected_option)
                                setattr(data, question["field"], current_value)
                                print(f"Added: {selected_option}")
                                print(f"Selected so far: {', '.join(current_value)}")

                                add_more = input("Add another tool? (y/n): ").strip().lower()
                                if add_more != 'y':
                                    break
                            else:
                                if question["field"] == "install_prompts":
                                    setattr(data, question["field"], selected_option.lower() == "yes")
                                else:
                                    setattr(data, question["field"], selected_option)
                                break
                        print(f"Please enter a number between 1 and {len(question['options'])}")
                    except ValueError:
                        print("Please enter a valid number.")
            else:
                if question.get("multiline", False):
                    print(f"\n{prompt}")
                    print("(Press Ctrl+D or Enter on empty line to finish)")
                    print()

                    lines = []
                    try:
                        while True:
                            line = input("> ").rstrip("\n")
                            if not line:
                                break
                            lines.append(line)
                    except EOFError:
                        pass

                    setattr(data, question["field"], "\n".join(lines))
                else:
                    print(f"\n{prompt}")
                    if "example" in question:
                        print(f"Example: {question['example']}")
                    value = input("> ").strip()
                    setattr(data, question["field"], value)

            print()
            print("-" * 40)
    except KeyboardInterrupt:
        print("\n\nInterview cancelled.")
        raise

    return data


def format_agents_md_data(data: InterviewData) -> Dict[str, str]:
    """Format interview data for AGENTS.md template.

    Args:
        data: InterviewData with user responses.

    Returns:
        Dict of template variables.
    """
    project_overview = f"This is a {data.project_type} project using {data.language_stack}."
    agent_tools_str = ", ".join(data.agent_tools)

    file_structure = """\
~/project/
├── AGENTS.md  # Primary format
├── CLAUDE.md  # Claude Code format (derived)
├── .agentsmd/
│   ├── config.yml
│   └── .gitignore
├── memory/
│   ├── project.md
│   ├── decisions.md
│   └── context.md
└── prompts/
    ├── code-review.md
    ├── debug.md
    └── refactor.md
"""

    return {
        "project_name": data.project_type,
        "project_overview": project_overview,
        "technology_stack": data.language_stack,
        "agent_tools": agent_tools_str,
        "what_to_remember": data.what_to_remember,
        "what_never_to_do": data.what_never_to_do,
        "file_structure": file_structure,
        "development_workflow": "TBD (add your workflow)",
        "coding_standards": "TBD (add your standards)",
        "testing_guidelines": "TBD (add your guidelines)",
        "documentation_conventions": "TBD",
        "environment_setup": "TBD",
        "additional_notes": data.additional_notes or "",
        "key_commands": data.key_commands,
        "ai_behavior": data.ai_behavior or ""
    }


def get_template_filename(primary_tool: str) -> str:
    """Get template filename based on primary tool.

    Args:
        primary_tool: User's chosen primary agent tool.

    Returns:
        Template filename (without .j2 extension).
    """
    template_map = {
        "Claude Code": "agents_md",
        "agents_md": "agents_md",
        "claude_md": "claude_md"
    }

    return template_map.get(primary_tool, "agents_md")


def get_derived_templates(primary_tool: str) -> List[str]:
    """Get list of derived template filenames.

    Args:
        primary_tool: User's chosen primary agent tool.

    Returns:
        List of template filenames to derive.
    """
    template_map = {
        "agents_md": ["claude_md"],
        "claude_md": [],
        "Claude Code": ["claude_md"]
    }

    return template_map.get(primary_tool, [])
