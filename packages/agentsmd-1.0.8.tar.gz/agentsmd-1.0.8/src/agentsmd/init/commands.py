"""Initialization command implementation."""

import sys
from pathlib import Path
from typing import Optional, Tuple

import httpx

from agentsmd import workspace_config
from agentsmd.init.interview import run_interview
from agentsmd.init.generator import write_workspace_files
from agentsmd.workspaces_cmd import _format_relative

PICKER_CREATE_NEW = "Create new workspace"


def _check_non_empty_dir(workspace: Path, force: bool) -> None:
    """Abort if directory is not empty, unless --force is set."""
    existing = [p for p in workspace.iterdir() if not p.name.startswith(".")]
    if not existing:
        return
    if not force:
        print(f"Directory is not empty ({len(existing)} item(s) found).")
        print("Use --force to proceed anyway.")
        sys.exit(1)
    print(f"Warning: {len(existing)} existing item(s) may be overwritten.")


def _format_picker(workspaces: list[dict]) -> list[str]:
    """Format workspace list for the picker. Returns printed lines."""
    lines = []
    for i, ws in enumerate(workspaces, 1):
        last_sync = _format_relative(ws.get("last_synced_at"))
        lines.append(f"  {i}. {ws['name']}  (synced {last_sync})")
    if workspaces:
        lines.append(f"  {len(workspaces) + 1}. {PICKER_CREATE_NEW}")
    return lines


def _parse_picker_choice(
    choice: str, workspaces: list[dict]
) -> Tuple[str, Optional[dict]]:
    """Parse the user's picker input.

    Returns:
        ("clone", workspace_dict) - clone an existing workspace
        ("create_new", name_or_none) - create a new workspace
    """
    create_idx = len(workspaces) + 1
    try:
        idx = int(choice)
        if 1 <= idx <= len(workspaces):
            return ("clone", workspaces[idx - 1])
        if idx == create_idx:
            return ("create_new", None)
    except ValueError:
        pass
    return ("create_new", choice)


async def run(
    name: Optional[str] = None,
    from_workspace: Optional[str] = None,
    directory: Optional[Path] = None,
    force: bool = False,
) -> None:
    """Run workspace initialization.

    Flow:
      - --from: clone an existing cloud workspace
      - otherwise: fetch cloud workspaces, show picker (with "Create new"),
        then either clone or create new
    """
    if from_workspace:
        from agentsmd.workspaces_cmd import run_clone
        await run_clone(name=from_workspace, directory=directory)
        return

    workspace = Path.cwd()

    if workspace_config.read(workspace) is not None:
        print("This folder is already linked to a workspace.")
        print("Run 'agentsmd link --remove' first if you want to start over.")
        sys.exit(1)

    _check_non_empty_dir(workspace, force)

    from agentsmd.auth.commands import require_token
    from agentsmd.api_client import APIClient

    token = require_token()
    client = APIClient(token=token)

    try:
        workspaces = await client.list_workspaces()
    except Exception as e:
        print(f"Failed to list workspaces: {e}")
        sys.exit(1)

    if workspaces:
        print()
        print("Your cloud workspaces:")
        for line in _format_picker(workspaces):
            print(line)
        print()
        choice = input("Pick a number: ").strip()

        if not choice:
            print("No choice made. Exiting.")
            sys.exit(1)

        action, payload = _parse_picker_choice(choice, workspaces)

        if action == "clone":
            from agentsmd.workspaces_cmd import run_clone
            print()
            await run_clone(name=payload["name"])
            return

        # action == "create_new"
        ws_name = payload if payload else input("New workspace name: ").strip()
        if not ws_name:
            print("Workspace name cannot be empty.")
            sys.exit(1)
        await _create_new(ws_name, client, workspace)
    else:
        ws_name = name.strip() if name else input("Workspace name: ").strip()
        if not ws_name:
            print("Workspace name cannot be empty.")
            sys.exit(1)
        await _create_new(ws_name, client, workspace)


async def _create_new(
    workspace_name: str, client, workspace: Path
) -> None:
    """Create a brand-new workspace with interview + scaffolding."""
    try:
        created = await client.create_workspace(workspace_name)
    except httpx.HTTPStatusError as e:
        _print_create_error(e, workspace_name)
        sys.exit(1)
    except Exception as e:
        print(f"Failed to create workspace: {e}")
        sys.exit(1)

    print("AgentsMD Workspace Initialization")
    print("=" * 40)
    print()
    print(f"Created workspace '{created['name']}' (id: {created['id'][:8]}...)")
    print()

    interview_data = await run_interview()

    print()
    print("Generating workspace files...")
    print()

    write_workspace_files(interview_data, str(workspace))
    workspace_config.write(workspace, created["id"], created["name"])

    print()
    print("Workspace created successfully!")
    print()
    print("Next steps:")
    print("  1. Review generated files")
    print("  2. Run 'agentsmd up' to push to the cloud")
    print(f"  3. On another machine: 'agentsmd init --from {created['name']}' to pull it down")


def _print_create_error(e: httpx.HTTPStatusError, name: str) -> None:
    """Pretty-print backend create errors."""
    try:
        detail = e.response.json().get("detail", {})
    except Exception:
        detail = {}

    if e.response.status_code == 403 and detail.get("error") == "workspace_limit":
        print("Free plan is limited to 1 workspace.")
        print("Upgrade to Pro for unlimited workspaces, or delete an existing workspace first.")
    elif e.response.status_code == 409 and detail.get("error") == "name_conflict":
        print(f"You already have a workspace named '{name}'.")
        print("Pick a different name with 'agentsmd init --name <other-name>'.")
    else:
        print(f"Failed to create workspace: HTTP {e.response.status_code}")
