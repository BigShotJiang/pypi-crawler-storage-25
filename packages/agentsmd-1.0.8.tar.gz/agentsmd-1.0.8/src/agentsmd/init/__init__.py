"""Initialization module for AgentsMD.

Handles user interview, workspace generation, and format derivation.
"""

from agentsmd.init.interview import run_interview, InterviewData, get_template_filename
from agentsmd.init.generator import (
    generate_agents_md,
    generate_main_format,
    write_workspace_files,
)
from agentsmd.init.deriver import derive_all_formats
from agentsmd.init.commands import run as run_init

__all__ = [
    "run_interview",
    "InterviewData",
    "get_template_filename",
    "generate_agents_md",
    "generate_main_format",
    "write_workspace_files",
    "derive_all_formats",
    "run_init",
]
