# src/agentsmd/init/generator.py
"""File generation from interview data."""

import jinja2
from pathlib import Path
from typing import Dict
from agentsmd.init.interview import InterviewData, format_agents_md_data, get_template_filename, TEMPLATE_DIR
from agentsmd.init.deriver import derive_all_formats


def generate_agents_md(data: InterviewData, workspace_path: str) -> str:
    """Generate AGENTS.md from interview data.

    Args:
        data: InterviewData with user responses.
        workspace_path: Path to workspace directory.

    Returns:
        Generated AGENTS.md content.
    """
    template_vars = format_agents_md_data(data)
    template_file = TEMPLATE_DIR / "agents_md.j2"

    with open(template_file, "r", encoding="utf-8") as f:
        template = jinja2.Template(f.read())

    return template.render(**template_vars)


def generate_main_format(data: InterviewData, workspace_path: str) -> str:
    """Generate main format file (AGENTS.md or CLAUDE.md).

    Args:
        data: InterviewData with user responses.
        workspace_path: Path to workspace directory.

    Returns:
        Generated main format content.
    """
    template_vars = format_agents_md_data(data)
    template_filename = get_template_filename(data.primary_tool)
    template_file = TEMPLATE_DIR / f"{template_filename}.j2"

    with open(template_file, "r", encoding="utf-8") as f:
        template = jinja2.Template(f.read())

    return template.render(**template_vars)


def generate_config_file(workspace_path: str) -> str:
    """Generate .agentsmd/config.yml file."""
    return "# AgentsMD Workspace Configuration\n\nworkspace_id: auto-generated\nlast_sync: never\n"


def generate_gitignore(workspace_path: str) -> str:
    """Generate .agentsmd/.gitignore file."""
    return "# Ignore sensitive and large files\n.env\n.env.*\n*.pyc\n__pycache__/\n.pytest_cache/\nnode_modules/\n*.log\n.DS_Store\n"


def generate_memory_files(workspace_path: Path, data: InterviewData) -> Dict[str, str]:
    """Generate memory directory files."""
    files = {}

    files["memory/project.md"] = (
        f"# Project Context\n\n"
        f"**Type:** {data.project_type}\n\n"
        f"**Stack:** {data.language_stack}\n\n"
        f"---\n\n## Key Decisions\n\n"
        f"<!-- Add architectural decisions here -->\n\n"
        f"---\n\n## Current Focus\n\n"
        f"<!-- Track current sprint or focus area -->\n"
    )

    files["memory/decisions.md"] = (
        "# Architectural Decisions Log\n\n"
        "<!-- Record important architectural decisions with rationale -->\n\n"
        "---\n\n## Decision Template\n\n"
        "| Date | Decision | Rationale |\n|-------|----------|-----------|\n"
        "| YYYY-MM-DD | [Description] | [Why] |\n"
    )

    files["memory/context.md"] = (
        "# Current Context\n\n"
        "<!-- Update with current sprint or focus area -->\n\n"
        f"**Sprint:** TBD\n**Goals:**\n- [ ] TBD\n- [ ] TBD\n"
    )

    return files


def generate_prompts_directory(workspace_path: Path, install_library: bool = False) -> None:
    """Generate prompts directory with optional library."""
    prompts_dir = workspace_path / "prompts"
    prompts_dir.mkdir(parents=True, exist_ok=True)

    core_prompts = {
        "code-review.md": (
            "# Code Review Checklist\n\n"
            "<!-- Customize this based on your project's needs -->\n\n"
            "## Code Quality\n"
            "- [ ] Follow project coding standards\n"
            "- [ ] No obvious bugs or errors\n"
            "- [ ] Proper error handling\n"
            "- [ ] Tests cover new functionality\n\n"
            "## Security\n"
            "- [ ] No hardcoded secrets\n"
            "- [ ] Proper input validation\n"
            "- [ ] Dependencies are up-to-date\n"
        ),
        "debug.md": (
            "# Debugging Checklist\n\n"
            "<!-- Customize this based on your project's needs -->\n\n"
            "## Before Debugging\n"
            "- [ ] Reproduce the issue\n"
            "- [ ] Check logs for errors\n"
            "- [ ] Understand expected behavior\n\n"
            "## During Debugging\n"
            "- [ ] Use breakpoints/print statements\n"
            "- [ ] Verify assumptions\n"
            "- [ ] Check edge cases\n\n"
            "## After Fixing\n"
            "- [ ] Test the fix thoroughly\n"
            "- [ ] Add regression tests if needed\n"
        ),
        "refactor.md": (
            "# Refactoring Checklist\n\n"
            "<!-- Customize this based on your project's needs -->\n\n"
            "## Before Refactoring\n"
            "- [ ] Tests exist and pass\n"
            "- [ ] Understand current implementation\n"
            "- [ ] Identify refactoring scope\n\n"
            "## During Refactoring\n"
            "- [ ] Make small, incremental changes\n"
            "- [ ] Run tests after each change\n"
            "- [ ] Don't change behavior\n\n"
            "## After Refactoring\n"
            "- [ ] All tests still pass\n"
            "- [ ] Code is more readable/maintainable\n"
            "- [ ] Performance is maintained or improved\n"
        )
    }

    for filename, content in core_prompts.items():
        with open(prompts_dir / filename, "w", encoding="utf-8") as f:
            f.write(content)

    # TODO: Install starter prompt library if install_library is True
    # This would fetch community packs from registry


def write_workspace_files(data: InterviewData, workspace_path: str) -> None:
    """Write all workspace files to disk."""
    workspace = Path(workspace_path)
    workspace.mkdir(parents=True, exist_ok=True)

    # Create .agentsmd directory
    agentsmd_dir = workspace / ".agentsmd"
    agentsmd_dir.mkdir(parents=True, exist_ok=True)

    # Generate and write config
    with open(agentsmd_dir / "config.yml", "w", encoding="utf-8") as f:
        f.write(generate_config_file(workspace))

    # Generate and write gitignore
    with open(agentsmd_dir / ".gitignore", "w", encoding="utf-8") as f:
        f.write(generate_gitignore(workspace))

    # Generate and write memory files
    memory_files = generate_memory_files(workspace, data)
    for file_path, content in memory_files.items():
        full_path = workspace / file_path
        full_path.parent.mkdir(parents=True, exist_ok=True)
        with open(full_path, "w", encoding="utf-8") as f:
            f.write(content)

    # Generate main format file
    main_format_content = generate_main_format(data, workspace)
    main_format_filename = get_template_filename(data.primary_tool)

    # Map template names to actual filenames
    filename_map = {
        "agents_md": "AGENTS.md",
        "claude_md": "CLAUDE.md"
    }
    actual_filename = filename_map.get(main_format_filename, "AGENTS.md")

    with open(workspace / actual_filename, "w", encoding="utf-8") as f:
        f.write(main_format_content)

    # Generate derived formats (only CLAUDE.md from AGENTS.md)
    derived_formats = derive_all_formats(main_format_content, data.primary_tool)

    for format_name, content in derived_formats.items():
        derived_filename = filename_map.get(format_name, format_name)
        with open(workspace / derived_filename, "w", encoding="utf-8") as f:
            f.write(content)

    # Generate prompts directory
    generate_prompts_directory(workspace, data.install_prompts)

    print(f"\nWorkspace created at: {workspace}")
    print(f"Main format: {actual_filename}")
    print(f"Derived formats: {[filename_map.get(k, k) for k in derived_formats.keys()]}")
