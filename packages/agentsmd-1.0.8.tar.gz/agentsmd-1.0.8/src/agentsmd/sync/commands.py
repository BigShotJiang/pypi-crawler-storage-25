"""Synchronization command implementations — thin client."""

import sys
from pathlib import Path
from typing import Optional

from agentsmd import workspace_config


async def _resolve_workspace_binding(workspace: Path) -> Optional[tuple[str, str, bool]]:
    """Determine (workspace_id, workspace_name, is_legacy_adoption) for this folder.

    Order:
      1. `.agentsmd/workspace.json` (the post-1.0.6 source of truth).
      2. Legacy fallback: if marker files exist, derive id from folder basename
         and treat this sync as an adoption (backend creates the DB row).
      3. None — caller decides what to do.
    """
    config = workspace_config.read(workspace)
    if config:
        return config["workspace_id"], config["workspace_name"], False

    if workspace_config.has_marker_files(workspace):
        legacy_id = workspace_config.legacy_workspace_id(workspace)
        name = workspace.resolve().name
        return legacy_id, name, True

    return None


async def _prepare_sync(workspace_path: Optional[str] = None) -> tuple:
    """Shared setup for all sync commands.

    Returns (token, workspace, workspace_id, workspace_name, is_legacy_adoption, machine_id, client).

    Exits on missing auth or unbound workspace.
    """
    from agentsmd.auth.commands import require_token
    from agentsmd.machine import ensure_machine_id
    from agentsmd.api_client import APIClient

    token = require_token()
    workspace = Path(workspace_path).resolve() if workspace_path else Path.cwd()

    # Reconcile tool formats before cloud sync (best-effort).
    try:
        from agentsmd.converter.reconcile import reconcile
        reconcile_result = reconcile(workspace)
        if reconcile_result.files_written:
            print(f"Reconciled {len(reconcile_result.files_written)} file(s)")
    except Exception:
        pass

    binding = await _resolve_workspace_binding(workspace)
    if binding is None:
        print("Not in an AgentsMD workspace.")
        print()
        print("Either:")
        print("  - Run 'agentsmd init' to create a new workspace here, or")
        print("  - Run 'agentsmd init --from <name>' to pull an existing workspace from the cloud.")
        sys.exit(1)

    workspace_id, workspace_name, is_legacy_adoption = binding
    machine_id = ensure_machine_id()
    client = APIClient(token=token)

    return (token, workspace, workspace_id, workspace_name, is_legacy_adoption, machine_id, client)


def _print_header(direction: str, workspace_name: str, workspace_path: Path, is_legacy_adoption: bool) -> None:
    """Print the sync header with a direction label."""
    header_labels = {"sync": "AgentsMD Sync", "up": "AgentsMD Upload", "down": "AgentsMD Download"}
    action_labels = {"sync": "Syncing", "up": "Uploading", "down": "Downloading"}
    print(header_labels.get(direction, "AgentsMD Sync"))
    print("=" * 40)
    print()
    print(f"Workspace: {workspace_name}  ({workspace_path})")
    if is_legacy_adoption:
        print("(adopting legacy workspace into new metadata table)")
    print(f"{action_labels.get(direction, 'Syncing')} with backend...")


async def _do_sync(
    client,
    workspace: Path,
    workspace_id: str,
    workspace_name: str,
    is_legacy_adoption: bool,
    machine_id: str,
    direction: Optional[str] = None,
) -> None:
    """Shared API call + workspace binding persistence logic."""
    try:
        result = await client.sync(
            workspace_id=workspace_id,
            machine_id=machine_id,
            workspace_path=str(workspace),
            workspace_name=workspace_name,
            direction=direction,
        )
    except Exception:
        print("Sync failed. Please try again or run 'agentsmd login'.")
        sys.exit(1)

    if not result.get("success", True) and result.get("error"):
        print(f"Error: {result.get('error')}")
        sys.exit(1)

    # On legacy adoption (and any first sync), persist the binding locally so
    # the next run skips the fallback path.
    server_workspace = result.get("workspace") or {}
    if is_legacy_adoption or workspace_config.read(workspace) is None:
        workspace_config.write(
            workspace,
            server_workspace.get("id", workspace_id),
            server_workspace.get("name", workspace_name),
        )

    uploaded = result.get("uploaded", 0)
    downloaded = result.get("downloaded", [])
    conflicts = result.get("conflicts", [])

    from agentsmd.api_client import write_downloaded_files
    dl_count = write_downloaded_files(str(workspace), downloaded)

    if direction == "up":
        print(f"Uploaded: {uploaded} files")
        if conflicts:
            print(f"Conflicts detected: {len(conflicts)}")
        else:
            print("No conflicts detected")
        print()
        print("Upload complete.")
    elif direction == "down":
        print(f"Downloaded: {dl_count} files")
        if conflicts:
            print(f"Conflicts detected: {len(conflicts)}")
        else:
            print("No conflicts detected")
        print()
        print("Download complete.")
    else:
        # Bidirectional sync — original output
        print(f"Uploaded: {uploaded} files")
        print(f"Downloaded: {dl_count} files")
        if conflicts:
            print(f"Conflicts detected: {len(conflicts)}")
        else:
            print("No conflicts detected")
        print()
        print("Sync complete.")


async def run(workspace_path: Optional[str] = None) -> None:
    """Run bidirectional workspace synchronization via backend API."""
    token, workspace, workspace_id, workspace_name, is_legacy_adoption, machine_id, client = await _prepare_sync(workspace_path)
    _print_header("sync", workspace_name, workspace, is_legacy_adoption)

    # Bidirectional sync passes direction=None for backward compatibility
    await _do_sync(
        client, workspace, workspace_id, workspace_name,
        is_legacy_adoption, machine_id, direction=None,
    )


async def run_up(workspace_path: Optional[str] = None) -> None:
    """Upload local changes to cloud (direction=up)."""
    token, workspace, workspace_id, workspace_name, is_legacy_adoption, machine_id, client = await _prepare_sync(workspace_path)
    _print_header("up", workspace_name, workspace, is_legacy_adoption)
    await _do_sync(
        client, workspace, workspace_id, workspace_name,
        is_legacy_adoption, machine_id, direction="up",
    )


async def run_down(workspace_path: Optional[str] = None) -> None:
    """Download cloud changes to local (direction=down)."""
    token, workspace, workspace_id, workspace_name, is_legacy_adoption, machine_id, client = await _prepare_sync(workspace_path)
    _print_header("down", workspace_name, workspace, is_legacy_adoption)
    await _do_sync(
        client, workspace, workspace_id, workspace_name,
        is_legacy_adoption, machine_id, direction="down",
    )


async def run_status(workspace_path: Optional[str] = None) -> None:
    """Display workspace synchronization status via backend API."""
    from agentsmd.auth.commands import require_token
    from agentsmd.machine import get_machine_id
    from agentsmd.api_client import APIClient

    token = require_token()
    workspace = Path(workspace_path).resolve() if workspace_path else Path.cwd()

    binding = await _resolve_workspace_binding(workspace)
    if binding is None:
        print("Not in an AgentsMD workspace.")
        sys.exit(1)

    workspace_id, workspace_name, _ = binding
    client = APIClient(token=token)

    try:
        result = await client.get_status(workspace_id)
    except Exception:
        print("Status check failed. Please try again or run 'agentsmd login'.")
        sys.exit(1)

    print("AgentsMD Status")
    print("=" * 40)
    print()
    print(f"Workspace: {workspace_name}  ({workspace})")
    print(f"Workspace ID: {result.get('workspace_id', workspace_id)}")
    print(f"Status: {result.get('status', 'unknown')}")
    print(f"Last sync: {result.get('last_sync', 'Never')}")
    print(f"File count: {result.get('files_count', 0)}")

    current_machine = get_machine_id()
    if current_machine:
        print(f"This machine: {current_machine}")
