"""Entry point for AgentsMD CLI."""
import sys
from agentsmd.cli import app

if __name__ == "__main__":
    sys.exit(app())
