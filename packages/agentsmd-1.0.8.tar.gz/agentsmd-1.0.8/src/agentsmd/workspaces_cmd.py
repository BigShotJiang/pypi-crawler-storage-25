"""Workspace lifecycle commands: list, clone, link, unlink.

These commands operate on the cloud-side workspace registry and the local
`.agentsmd/workspace.json` binding. None of them touch the file-sync code
directly; clone runs a sync as its last step so the existing pipeline handles
file transfer.
"""

from __future__ import annotations

import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import httpx

from agentsmd import workspace_config


def _find_by_name(workspaces: list[dict], name: str) -> Optional[dict]:
    name_lower = name.lower()
    matches = [w for w in workspaces if w["name"].lower() == name_lower]
    return matches[0] if matches else None


def _format_relative(iso_ts: Optional[str]) -> str:
    if not iso_ts:
        return "never"
    try:
        # Normalize 'Z' suffix to '+00:00' for fromisoformat compatibility.
        ts = datetime.fromisoformat(iso_ts.replace("Z", "+00:00"))
    except ValueError:
        return iso_ts
    delta = datetime.now(timezone.utc) - ts
    secs = int(delta.total_seconds())
    if secs < 60:
        return f"{secs}s ago"
    if secs < 3600:
        return f"{secs // 60}m ago"
    if secs < 86400:
        return f"{secs // 3600}h ago"
    return f"{secs // 86400}d ago"


async def run_list() -> None:
    """Print a table of the user's cloud workspaces."""
    from agentsmd.auth.commands import require_token
    from agentsmd.api_client import APIClient

    token = require_token()
    client = APIClient(token=token)

    try:
        workspaces = await client.list_workspaces()
    except Exception as e:
        print(f"Failed to list workspaces: {e}")
        sys.exit(1)

    if not workspaces:
        print("No workspaces yet. Run 'agentsmd init' to create one.")
        return

    name_w = max(8, max(len(w["name"]) for w in workspaces))
    print(f"{'NAME'.ljust(name_w)}  {'ID'.ljust(12)}  LAST SYNC")
    print(f"{'-' * name_w}  {'-' * 12}  ----------")
    for w in workspaces:
        last = _format_relative(w.get("last_synced_at"))
        short_id = w["id"][:8] + "..."
        print(f"{w['name'].ljust(name_w)}  {short_id.ljust(12)}  {last}")


async def run_clone(name: str, directory: Optional[Path] = None) -> None:
    """Pull a cloud workspace into a new local folder.

    Steps:
      1. Look up the workspace by name (case-insensitive).
      2. Create the target directory (must be empty or non-existent).
      3. Write workspace.json so the subsequent sync uses the right id.
      4. Run sync, which pulls all files down.
    """
    from agentsmd.auth.commands import require_token
    from agentsmd.api_client import APIClient
    from agentsmd.sync.commands import run as run_sync

    token = require_token()
    client = APIClient(token=token)

    try:
        workspaces = await client.list_workspaces()
    except Exception as e:
        print(f"Failed to list workspaces: {e}")
        sys.exit(1)

    workspace = _find_by_name(workspaces, name)
    if workspace is None:
        print(f"No workspace named '{name}' found in your account.")
        print("Run 'agentsmd list' to see available workspaces.")
        sys.exit(1)

    target = directory.resolve() if directory else (Path.cwd() / workspace["name"]).resolve()
    if target.exists() and any(target.iterdir()):
        print(f"Target directory '{target}' exists and is not empty.")
        print("Choose an empty directory or use 'agentsmd link' to bind an existing one.")
        sys.exit(1)

    target.mkdir(parents=True, exist_ok=True)
    workspace_config.write(target, workspace["id"], workspace["name"])

    print(f"Pulling workspace '{workspace['name']}' into {target}")
    print()
    await run_sync(workspace_path=str(target))


async def run_link(name: Optional[str] = None, remove: bool = False) -> None:
    """Bind the current folder to a cloud workspace, or remove binding.

    Args:
        name: Workspace name to link (ignored if remove=True).
        remove: If True, remove the local binding (replaces unlink).
    """
    if remove:
        workspace = Path.cwd()
        if workspace_config.delete(workspace):
            print(f"Unlinked {workspace} from its cloud workspace.")
            print("(Files were not deleted. The cloud workspace still exists.)")
        else:
            print("This folder is not linked to any workspace.")
            sys.exit(1)
        return

    if not name:
        print("Workspace name is required. Usage: agentsmd link <name>")
        sys.exit(1)

    from agentsmd.auth.commands import require_token
    from agentsmd.api_client import APIClient

    token = require_token()
    workspace = Path.cwd()

    if workspace_config.read(workspace) is not None:
        print("This folder is already linked to a workspace.")
        print("Run 'agentsmd link --remove' first if you want to change it.")
        sys.exit(1)

    client = APIClient(token=token)
    try:
        workspaces = await client.list_workspaces()
    except Exception as e:
        print(f"Failed to list workspaces: {e}")
        sys.exit(1)

    target = _find_by_name(workspaces, name)
    if target is None:
        print(f"No workspace named '{name}' found in your account.")
        sys.exit(1)

    workspace_config.write(workspace, target["id"], target["name"])
    print(f"Linked {workspace} → '{target['name']}'")
    print("Run 'agentsmd up' to push your files.")


async def run_unlink() -> None:
    """Backward-compatible wrapper for link --remove."""
    await run_link(remove=True)
