# AgentsMD

CLI tool for scaffolding and syncing AI agent workspace configuration files.

## Installation

```bash
pip install agentsmd
```

## Quick Start

```bash
# First, authenticate (get a token from https://agentsmd.live)
agentsmd login --token <your-token>

# Create a new workspace in the current folder
agentsmd init

# Push your workspace to the cloud
agentsmd sync
```

### On another machine

```bash
agentsmd login --token <same-token>
agentsmd list                    # see your cloud workspaces
agentsmd clone my-project        # pull one into ./my-project
```

## Features

- **Workspace Scaffolding** — Interactive interview to generate AGENTS.md, CLAUDE.md, .cursorrules, and more
- **Multi-Machine Sync** — Push and pull workspaces across machines with a single token
- **Cross-Tool Sync** — Convert between AI tool config formats (Claude Code, Cursor, Copilot, Windsurf)
- **Format Migration** — Migrate existing config files between formats
- **Reconciliation** — Re-derive all tool formats from a single source of truth

## How workspaces work

Each workspace is identified by a user-chosen name (not by folder name). The
local folder is bound to its cloud workspace via `.agentsmd/workspace.json`,
which is created on `init`/`clone`/`link` and added to your `.gitignore`. You
can rename or move the folder freely — the binding stays intact.

A free account includes one workspace; Pro unlocks unlimited.

## Commands

| Command | Description |
|---------|-------------|
| `agentsmd login --token <X>` | Authenticate via API token |
| `agentsmd logout` | Clear local credentials |
| `agentsmd init [--name NAME]` | Create a new workspace in the current folder |
| `agentsmd list` | List your cloud workspaces |
| `agentsmd clone <name> [dir]` | Pull an existing workspace into a new folder |
| `agentsmd link <name>` | Bind the current folder to an existing workspace |
| `agentsmd unlink` | Remove the local binding (cloud workspace is preserved) |
| `agentsmd sync` | Synchronize this workspace with the cloud |
| `agentsmd status` | Show sync status for the current workspace |
| `agentsmd migrate` | Convert between AI tool config formats |
| `agentsmd reconcile` | Re-derive all tool config formats from the source of truth |
| `agentsmd tool-list` | Show detected AI tools in this workspace |
| `agentsmd tool-add` | Register a custom AI tool interactively |

## Supported AI Tools

- Claude Code (CLAUDE.md)
- Cursor (.cursorrules)
- GitHub Copilot (.github/copilot-instructions.md)
- Windsurf (.windsurfrules)
- AGENTS.md (universal format)

## Requirements

- Python 3.13+
