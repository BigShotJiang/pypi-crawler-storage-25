"""Init command for ksm.

Handles `ksm init` — creates the `.kiro/` directory in the
current working directory, prints a success message, and
optionally offers the interactive bundle selector on TTY.

Requirements: 17.1, 17.2, 17.3, 17.4
"""

import argparse
import sys
from pathlib import Path

from ksm.color import SYM_CHECK, info, muted, subtle, success
from ksm.registry import RegistryIndex
from ksm.manifest import Manifest, build_installed_info
from ksm.scanner import scan_registry
from ksm.selector import interactive_select


def run_init(
    args: argparse.Namespace,
    *,
    target_dir: Path,
    registry_index: RegistryIndex | None = None,
    manifest: Manifest | None = None,
) -> int:
    """Create .kiro/ directory and offer selector. Returns exit code."""
    kiro_dir = target_dir / ".kiro"

    if kiro_dir.exists():
        print(
            muted("Already initialised — .kiro/ exists."),
            file=sys.stderr,
        )
    else:
        kiro_dir.mkdir(parents=True)
        check = success(SYM_CHECK)
        kiro = info(".kiro/")
        print(
            f"{check} Initialised {kiro} in current directory",
            file=sys.stderr,
        )
        print(
            subtle("Run 'ksm add' to install your first bundle."),
            file=sys.stderr,
        )

    # Offer interactive selector if TTY and registries available
    if sys.stdin.isatty() and registry_index is not None and manifest is not None:
        all_bundles = []
        for entry in registry_index.registries:
            registry_path = Path(entry.local_path)
            all_bundles.extend(
                scan_registry(
                    registry_path,
                    registry_name=entry.name,
                )
            )

        if all_bundles:
            installed_info = build_installed_info(manifest, str(target_dir.resolve()))
            interactive_select(all_bundles, installed_info)

    return 0
