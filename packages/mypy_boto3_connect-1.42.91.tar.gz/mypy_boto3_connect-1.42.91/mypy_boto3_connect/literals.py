"""
Type annotations for connect service literal definitions.

[Documentation](https://youtype.github.io/boto3_stubs_docs/mypy_boto3_connect/literals/)

Copyright 2026 Vlad Emelianov

Usage::

    ```python
    from mypy_boto3_connect.literals import AccessTypeType

    data: AccessTypeType = "ALLOW"
    ```
"""

import sys

if sys.version_info >= (3, 12):
    from typing import Literal
else:
    from typing_extensions import Literal


__all__ = (
    "AccessTypeType",
    "ActionTypeType",
    "AgentAvailabilityTimerType",
    "AgentStatusStateType",
    "AgentStatusTypeType",
    "AiUseCaseType",
    "AllowedUserActionType",
    "AnsweringMachineDetectionStatusType",
    "ApplicationTypeType",
    "ArtifactStatusType",
    "AutoEvaluationStatusType",
    "BehaviorTypeType",
    "BooleanComparisonTypeType",
    "ChannelType",
    "ChatEventTypeType",
    "ComparisonType",
    "ConfigurableNotificationPriorityType",
    "ConnectServiceName",
    "ContactFlowModuleStateType",
    "ContactFlowModuleStatusType",
    "ContactFlowStateType",
    "ContactFlowStatusType",
    "ContactFlowTypeType",
    "ContactInitiationMethodType",
    "ContactInteractionTypeType",
    "ContactMediaProcessingFailureModeType",
    "ContactMetricNameType",
    "ContactParticipantRoleType",
    "ContactRecordingTypeType",
    "ContactStateType",
    "CurrentMetricNameType",
    "DataTableAttributeValueTypeType",
    "DataTableLockLevelType",
    "DataTableStatusType",
    "DateComparisonTypeType",
    "DateTimeComparisonTypeType",
    "DecimalComparisonTypeType",
    "DeviceTypeType",
    "DirectoryTypeType",
    "DisconnectOnCustomerExitParticipantTypeType",
    "EmailHeaderTypeType",
    "EncryptionTypeType",
    "EndpointTypeType",
    "EntityTypeType",
    "EvaluationFormItemEnablementActionType",
    "EvaluationFormItemEnablementOperatorType",
    "EvaluationFormItemEnablementSourceTypeType",
    "EvaluationFormItemEnablementSourceValueTypeType",
    "EvaluationFormItemSourceValuesComparatorType",
    "EvaluationFormLanguageCodeType",
    "EvaluationFormMultiSelectQuestionDisplayModeType",
    "EvaluationFormQuestionAutomationAnswerSourceTypeType",
    "EvaluationFormQuestionTypeType",
    "EvaluationFormScoringModeType",
    "EvaluationFormScoringStatusType",
    "EvaluationFormSingleSelectQuestionDisplayModeType",
    "EvaluationFormVersionStatusType",
    "EvaluationQuestionAnswerAnalysisTypeType",
    "EvaluationReviewNotificationRecipientTypeType",
    "EvaluationStatusType",
    "EvaluationSuggestedAnswerStatusType",
    "EvaluationTranscriptTypeType",
    "EvaluationTypeType",
    "EventSourceNameType",
    "ExecutionRecordStatusType",
    "FailureReasonCodeType",
    "FileStatusTypeType",
    "FileUseCaseTypeType",
    "FilterV2StringConditionComparisonOperatorType",
    "FlowAssociationResourceTypeType",
    "FlowModuleTypeType",
    "GetMetricDataPaginatorName",
    "GroupingType",
    "HierarchyGroupMatchTypeType",
    "HistoricalMetricNameType",
    "HoursOfOperationDaysType",
    "InboundMessageSourceTypeType",
    "InitiateAsType",
    "InstanceAttributeTypeType",
    "InstanceReplicationStatusType",
    "InstanceStatusType",
    "InstanceStorageResourceTypeType",
    "IntegrationTypeType",
    "IntervalPeriodType",
    "IvrRecordingTrackType",
    "LexVersionType",
    "ListAgentStatusesPaginatorName",
    "ListApprovedOriginsPaginatorName",
    "ListAuthenticationProfilesPaginatorName",
    "ListBotsPaginatorName",
    "ListChildHoursOfOperationsPaginatorName",
    "ListContactEvaluationsPaginatorName",
    "ListContactFlowModuleAliasesPaginatorName",
    "ListContactFlowModuleVersionsPaginatorName",
    "ListContactFlowModulesPaginatorName",
    "ListContactFlowVersionsPaginatorName",
    "ListContactFlowsPaginatorName",
    "ListContactReferencesPaginatorName",
    "ListDataTableAttributesPaginatorName",
    "ListDataTablePrimaryValuesPaginatorName",
    "ListDataTableValuesPaginatorName",
    "ListDataTablesPaginatorName",
    "ListDefaultVocabulariesPaginatorName",
    "ListEntitySecurityProfilesPaginatorName",
    "ListEvaluationFormVersionsPaginatorName",
    "ListEvaluationFormsPaginatorName",
    "ListFlowAssociationResourceTypeType",
    "ListFlowAssociationsPaginatorName",
    "ListHoursOfOperationOverridesPaginatorName",
    "ListHoursOfOperationsPaginatorName",
    "ListInstanceAttributesPaginatorName",
    "ListInstanceStorageConfigsPaginatorName",
    "ListInstancesPaginatorName",
    "ListIntegrationAssociationsPaginatorName",
    "ListLambdaFunctionsPaginatorName",
    "ListLexBotsPaginatorName",
    "ListPhoneNumbersPaginatorName",
    "ListPhoneNumbersV2PaginatorName",
    "ListPredefinedAttributesPaginatorName",
    "ListPromptsPaginatorName",
    "ListQueueQuickConnectsPaginatorName",
    "ListQueuesPaginatorName",
    "ListQuickConnectsPaginatorName",
    "ListRoutingProfileManualAssignmentQueuesPaginatorName",
    "ListRoutingProfileQueuesPaginatorName",
    "ListRoutingProfilesPaginatorName",
    "ListRulesPaginatorName",
    "ListSecurityKeysPaginatorName",
    "ListSecurityProfileApplicationsPaginatorName",
    "ListSecurityProfileFlowModulesPaginatorName",
    "ListSecurityProfilePermissionsPaginatorName",
    "ListSecurityProfilesPaginatorName",
    "ListTaskTemplatesPaginatorName",
    "ListTestCasesPaginatorName",
    "ListTrafficDistributionGroupUsersPaginatorName",
    "ListTrafficDistributionGroupsPaginatorName",
    "ListUseCasesPaginatorName",
    "ListUserHierarchyGroupsPaginatorName",
    "ListUserProficienciesPaginatorName",
    "ListUsersPaginatorName",
    "ListViewVersionsPaginatorName",
    "ListViewsPaginatorName",
    "ListWorkspacePagesPaginatorName",
    "ListWorkspacesPaginatorName",
    "LocaleCodeType",
    "MediaStreamTypeType",
    "MediaTypeType",
    "MeetingFeatureStatusType",
    "MonitorCapabilityType",
    "MultiSelectQuestionRuleCategoryAutomationConditionType",
    "NextContactTypeType",
    "NotificationContentTypeType",
    "NotificationDeliveryTypeType",
    "NotificationPriorityType",
    "NotificationSourceType",
    "NotificationStatusType",
    "NumberComparisonTypeType",
    "NumericQuestionPropertyAutomationLabelType",
    "OperationalStatusType",
    "OutboundMessageSourceTypeType",
    "OutboundStrategyTypeType",
    "OverrideDaysType",
    "OverrideTypeType",
    "PaginatorName",
    "ParticipantRoleType",
    "ParticipantStateType",
    "ParticipantTimerActionType",
    "ParticipantTimerTypeType",
    "ParticipantTypeType",
    "PhoneNumberCountryCodeType",
    "PhoneNumberTypeType",
    "PhoneNumberWorkflowStatusType",
    "PhoneTypeType",
    "QuestionRuleCategoryAutomationConditionType",
    "QueueStatusType",
    "QueueTypeType",
    "QuickConnectTypeType",
    "RealTimeContactAnalysisOutputTypeType",
    "RealTimeContactAnalysisPostContactSummaryFailureCodeType",
    "RealTimeContactAnalysisPostContactSummaryStatusType",
    "RealTimeContactAnalysisSegmentTypeType",
    "RealTimeContactAnalysisSentimentLabelType",
    "RealTimeContactAnalysisStatusType",
    "RealTimeContactAnalysisSupportedChannelType",
    "RecordingStatusType",
    "RecurrenceFrequencyType",
    "ReferenceStatusType",
    "ReferenceTypeType",
    "RegionName",
    "RehydrationTypeType",
    "ResourceServiceName",
    "ResponseModeType",
    "RoutingCriteriaStepStatusType",
    "RulePublishStatusType",
    "ScreenShareCapabilityType",
    "SearchAgentStatusesPaginatorName",
    "SearchAvailablePhoneNumbersPaginatorName",
    "SearchContactFlowModulesPaginatorName",
    "SearchContactFlowsPaginatorName",
    "SearchContactsMatchTypeType",
    "SearchContactsPaginatorName",
    "SearchContactsTimeRangeConditionTypeType",
    "SearchContactsTimeRangeTypeType",
    "SearchDataTablesPaginatorName",
    "SearchHoursOfOperationOverridesPaginatorName",
    "SearchHoursOfOperationsPaginatorName",
    "SearchPredefinedAttributesPaginatorName",
    "SearchPromptsPaginatorName",
    "SearchQueuesPaginatorName",
    "SearchQuickConnectsPaginatorName",
    "SearchResourceTagsPaginatorName",
    "SearchRoutingProfilesPaginatorName",
    "SearchSecurityProfilesPaginatorName",
    "SearchTestCasesPaginatorName",
    "SearchUserHierarchyGroupsPaginatorName",
    "SearchUsersPaginatorName",
    "SearchViewsPaginatorName",
    "SearchVocabulariesPaginatorName",
    "SearchWorkspaceAssociationsPaginatorName",
    "SearchWorkspacesPaginatorName",
    "SearchableQueueTypeType",
    "ServiceName",
    "SingleSelectQuestionRuleCategoryAutomationConditionType",
    "SlaAssignmentTypeType",
    "SlaTypeType",
    "SortOrderType",
    "SortableFieldNameType",
    "SourceTypeType",
    "StatisticType",
    "StatusType",
    "StorageTypeType",
    "StringComparisonTypeType",
    "TargetListTypeType",
    "TaskTemplateFieldTypeType",
    "TaskTemplateStatusType",
    "TestCaseEntryPointTypeType",
    "TestCaseExecutionStatusType",
    "TestCaseStatusType",
    "TimerEligibleParticipantRolesType",
    "TrafficDistributionGroupStatusType",
    "TrafficTypeType",
    "UnitType",
    "UseCaseTypeType",
    "VideoCapabilityType",
    "ViewStatusType",
    "ViewTypeType",
    "VisibilityType",
    "VocabularyLanguageCodeType",
    "VocabularyStateType",
    "VoiceEnhancementModeType",
    "VoiceRecordingTrackType",
    "WorkspaceFontFamilyType",
)


AccessTypeType = Literal["ALLOW"]
ActionTypeType = Literal[
    "ASSIGN_CONTACT_CATEGORY",
    "ASSIGN_SLA",
    "CREATE_CASE",
    "CREATE_TASK",
    "END_ASSOCIATED_TASKS",
    "GENERATE_EVENTBRIDGE_EVENT",
    "SEND_NOTIFICATION",
    "SUBMIT_AUTO_EVALUATION",
    "UPDATE_CASE",
]
AgentAvailabilityTimerType = Literal["TIME_SINCE_LAST_ACTIVITY", "TIME_SINCE_LAST_INBOUND"]
AgentStatusStateType = Literal["DISABLED", "ENABLED"]
AgentStatusTypeType = Literal["CUSTOM", "OFFLINE", "ROUTABLE"]
AiUseCaseType = Literal["AgentAssistance", "SelfService"]
AllowedUserActionType = Literal["CALL", "DISCARD"]
AnsweringMachineDetectionStatusType = Literal[
    "AMD_ERROR",
    "AMD_NOT_APPLICABLE",
    "AMD_UNANSWERED",
    "AMD_UNRESOLVED",
    "ANSWERED",
    "ERROR",
    "FAX_MACHINE_DETECTED",
    "HUMAN_ANSWERED",
    "SIT_TONE_BUSY",
    "SIT_TONE_DETECTED",
    "SIT_TONE_INVALID_NUMBER",
    "UNDETECTED",
    "VOICEMAIL_BEEP",
    "VOICEMAIL_NO_BEEP",
]
ApplicationTypeType = Literal["MCP", "THIRD_PARTY_APPLICATION"]
ArtifactStatusType = Literal["APPROVED", "IN_PROGRESS", "REJECTED"]
AutoEvaluationStatusType = Literal["FAILED", "IN_PROGRESS", "SUCCEEDED"]
BehaviorTypeType = Literal["ROUTE_ANY_CHANNEL", "ROUTE_CURRENT_CHANNEL_ONLY"]
BooleanComparisonTypeType = Literal["IS_FALSE", "IS_TRUE"]
ChannelType = Literal["CHAT", "EMAIL", "TASK", "VOICE"]
ChatEventTypeType = Literal["DISCONNECT", "EVENT", "MESSAGE"]
ComparisonType = Literal["LT"]
ConfigurableNotificationPriorityType = Literal["HIGH", "LOW"]
ContactFlowModuleStateType = Literal["ACTIVE", "ARCHIVED"]
ContactFlowModuleStatusType = Literal["PUBLISHED", "SAVED"]
ContactFlowStateType = Literal["ACTIVE", "ARCHIVED"]
ContactFlowStatusType = Literal["PUBLISHED", "SAVED"]
ContactFlowTypeType = Literal[
    "AGENT_HOLD",
    "AGENT_TRANSFER",
    "AGENT_WHISPER",
    "CAMPAIGN",
    "CONTACT_FLOW",
    "CUSTOMER_HOLD",
    "CUSTOMER_QUEUE",
    "CUSTOMER_WHISPER",
    "OUTBOUND_WHISPER",
    "QUEUE_TRANSFER",
]
ContactInitiationMethodType = Literal[
    "AGENT_REPLY",
    "API",
    "CALLBACK",
    "DISCONNECT",
    "EXTERNAL_OUTBOUND",
    "FLOW",
    "INBOUND",
    "MONITOR",
    "OUTBOUND",
    "QUEUE_TRANSFER",
    "TRANSFER",
    "WEBRTC_API",
]
ContactInteractionTypeType = Literal["AGENT", "AUTOMATED", "CUSTOMER"]
ContactMediaProcessingFailureModeType = Literal[
    "DELIVER_UNPROCESSED_MESSAGE", "DO_NOT_DELIVER_UNPROCESSED_MESSAGE"
]
ContactMetricNameType = Literal["ESTIMATED_WAIT_TIME", "POSITION_IN_QUEUE"]
ContactParticipantRoleType = Literal["AGENT", "CUSTOMER", "CUSTOM_BOT", "SYSTEM"]
ContactRecordingTypeType = Literal["AGENT", "IVR", "SCREEN"]
ContactStateType = Literal[
    "CONNECTED",
    "CONNECTED_ONHOLD",
    "CONNECTING",
    "ENDED",
    "ERROR",
    "INCOMING",
    "MISSED",
    "PENDING",
    "REJECTED",
]
CurrentMetricNameType = Literal[
    "AGENTS_AFTER_CONTACT_WORK",
    "AGENTS_AVAILABLE",
    "AGENTS_ERROR",
    "AGENTS_NON_PRODUCTIVE",
    "AGENTS_ONLINE",
    "AGENTS_ON_CALL",
    "AGENTS_ON_CONTACT",
    "AGENTS_STAFFED",
    "CONTACTS_IN_QUEUE",
    "CONTACTS_SCHEDULED",
    "ESTIMATED_WAIT_TIME",
    "OLDEST_CONTACT_AGE",
    "SLOTS_ACTIVE",
    "SLOTS_AVAILABLE",
]
DataTableAttributeValueTypeType = Literal["BOOLEAN", "NUMBER", "NUMBER_LIST", "TEXT", "TEXT_LIST"]
DataTableLockLevelType = Literal["ATTRIBUTE", "DATA_TABLE", "NONE", "PRIMARY_VALUE", "VALUE"]
DataTableStatusType = Literal["PUBLISHED"]
DateComparisonTypeType = Literal[
    "EQUAL_TO", "GREATER_THAN", "GREATER_THAN_OR_EQUAL_TO", "LESS_THAN", "LESS_THAN_OR_EQUAL_TO"
]
DateTimeComparisonTypeType = Literal[
    "EQUAL_TO",
    "GREATER_THAN",
    "GREATER_THAN_OR_EQUAL_TO",
    "LESS_THAN",
    "LESS_THAN_OR_EQUAL_TO",
    "RANGE",
]
DecimalComparisonTypeType = Literal[
    "EQUAL", "GREATER", "GREATER_OR_EQUAL", "LESSER", "LESSER_OR_EQUAL", "NOT_EQUAL", "RANGE"
]
DeviceTypeType = Literal["APNS", "APNS_SANDBOX", "GCM"]
DirectoryTypeType = Literal["CONNECT_MANAGED", "EXISTING_DIRECTORY", "SAML"]
DisconnectOnCustomerExitParticipantTypeType = Literal["AGENT"]
EmailHeaderTypeType = Literal[
    "IN_REPLY_TO", "MESSAGE_ID", "REFERENCES", "X_SES_SPAM_VERDICT", "X_SES_VIRUS_VERDICT"
]
EncryptionTypeType = Literal["KMS"]
EndpointTypeType = Literal[
    "CONNECT_PHONENUMBER_ARN", "CONTACT_FLOW", "EMAIL_ADDRESS", "TELEPHONE_NUMBER", "VOIP"
]
EntityTypeType = Literal["AI_AGENT", "USER"]
EvaluationFormItemEnablementActionType = Literal["DISABLE", "ENABLE"]
EvaluationFormItemEnablementOperatorType = Literal["AND", "OR"]
EvaluationFormItemEnablementSourceTypeType = Literal["QUESTION_REF_ID"]
EvaluationFormItemEnablementSourceValueTypeType = Literal["OPTION_REF_ID"]
EvaluationFormItemSourceValuesComparatorType = Literal["ALL_IN", "EXACT", "IN", "NOT_IN"]
EvaluationFormLanguageCodeType = Literal[
    "de-DE", "en-US", "es-ES", "fr-FR", "it-IT", "ja-JP", "ko-KR", "pt-BR", "zh-CN"
]
EvaluationFormMultiSelectQuestionDisplayModeType = Literal["CHECKBOX", "DROPDOWN"]
EvaluationFormQuestionAutomationAnswerSourceTypeType = Literal["CONTACT_LENS_DATA", "GEN_AI"]
EvaluationFormQuestionTypeType = Literal[
    "DATETIME", "MULTISELECT", "NUMERIC", "SINGLESELECT", "TEXT"
]
EvaluationFormScoringModeType = Literal["QUESTION_ONLY", "SECTION_ONLY"]
EvaluationFormScoringStatusType = Literal["DISABLED", "ENABLED"]
EvaluationFormSingleSelectQuestionDisplayModeType = Literal["DROPDOWN", "RADIO"]
EvaluationFormVersionStatusType = Literal["ACTIVE", "DRAFT"]
EvaluationQuestionAnswerAnalysisTypeType = Literal["CONTACT_LENS_DATA", "GEN_AI"]
EvaluationReviewNotificationRecipientTypeType = Literal["USER_ID"]
EvaluationStatusType = Literal["DRAFT", "REVIEW_REQUESTED", "SUBMITTED", "UNDER_REVIEW"]
EvaluationSuggestedAnswerStatusType = Literal["FAILED", "IN_PROGRESS", "SUCCEEDED"]
EvaluationTranscriptTypeType = Literal["RAW", "REDACTED"]
EvaluationTypeType = Literal["CALIBRATION", "STANDARD"]
EventSourceNameType = Literal[
    "OnCaseCreate",
    "OnCaseUpdate",
    "OnContactEvaluationSubmit",
    "OnEmailAnalysisAvailable",
    "OnMetricDataUpdate",
    "OnPostCallAnalysisAvailable",
    "OnPostChatAnalysisAvailable",
    "OnRealTimeCallAnalysisAvailable",
    "OnRealTimeChatAnalysisAvailable",
    "OnSalesforceCaseCreate",
    "OnSlaBreach",
    "OnZendeskTicketCreate",
    "OnZendeskTicketStatusUpdate",
]
ExecutionRecordStatusType = Literal["FAILED", "IN_PROGRESS", "PASSED", "STOPPED"]
FailureReasonCodeType = Literal[
    "IDEMPOTENCY_EXCEPTION",
    "INTERNAL_ERROR",
    "INVALID_ATTRIBUTE_KEY",
    "INVALID_CUSTOMER_ENDPOINT",
    "INVALID_OUTBOUND_STRATEGY",
    "INVALID_QUEUE",
    "INVALID_SYSTEM_ENDPOINT",
    "MISSING_CAMPAIGN",
    "MISSING_CUSTOMER_ENDPOINT",
    "MISSING_QUEUE_ID_AND_SYSTEM_ENDPOINT",
    "REQUEST_THROTTLED",
]
FileStatusTypeType = Literal["APPROVED", "FAILED", "PROCESSING", "REJECTED"]
FileUseCaseTypeType = Literal[
    "ATTACHMENT",
    "CONTACT_ANALYSIS",
    "EMAIL_MESSAGE",
    "EMAIL_MESSAGE_PLAIN_TEXT",
    "EMAIL_MESSAGE_PLAIN_TEXT_REDACTED",
    "EMAIL_MESSAGE_REDACTED",
]
FilterV2StringConditionComparisonOperatorType = Literal["NOT_EXISTS"]
FlowAssociationResourceTypeType = Literal[
    "ANALYTICS_CONNECTOR",
    "INBOUND_EMAIL",
    "OUTBOUND_EMAIL",
    "SMS_PHONE_NUMBER",
    "WHATSAPP_MESSAGING_PHONE_NUMBER",
]
FlowModuleTypeType = Literal["MCP"]
GetMetricDataPaginatorName = Literal["get_metric_data"]
GroupingType = Literal[
    "AGENT_STATUS",
    "CHANNEL",
    "QUEUE",
    "ROUTING_PROFILE",
    "ROUTING_STEP_EXPRESSION",
    "SUBTYPE",
    "VALIDATION_TEST_TYPE",
]
HierarchyGroupMatchTypeType = Literal["EXACT", "WITH_CHILD_GROUPS"]
HistoricalMetricNameType = Literal[
    "ABANDON_TIME",
    "AFTER_CONTACT_WORK_TIME",
    "API_CONTACTS_HANDLED",
    "CALLBACK_CONTACTS_HANDLED",
    "CONTACTS_ABANDONED",
    "CONTACTS_AGENT_HUNG_UP_FIRST",
    "CONTACTS_CONSULTED",
    "CONTACTS_HANDLED",
    "CONTACTS_HANDLED_INCOMING",
    "CONTACTS_HANDLED_OUTBOUND",
    "CONTACTS_HOLD_ABANDONS",
    "CONTACTS_MISSED",
    "CONTACTS_QUEUED",
    "CONTACTS_TRANSFERRED_IN",
    "CONTACTS_TRANSFERRED_IN_FROM_QUEUE",
    "CONTACTS_TRANSFERRED_OUT",
    "CONTACTS_TRANSFERRED_OUT_FROM_QUEUE",
    "HANDLE_TIME",
    "HOLD_TIME",
    "INTERACTION_AND_HOLD_TIME",
    "INTERACTION_TIME",
    "OCCUPANCY",
    "QUEUED_TIME",
    "QUEUE_ANSWER_TIME",
    "SERVICE_LEVEL",
]
HoursOfOperationDaysType = Literal[
    "FRIDAY", "MONDAY", "SATURDAY", "SUNDAY", "THURSDAY", "TUESDAY", "WEDNESDAY"
]
InboundMessageSourceTypeType = Literal["RAW"]
InitiateAsType = Literal["COMPLETED", "CONNECTED_TO_USER"]
InstanceAttributeTypeType = Literal[
    "AUTO_RESOLVE_BEST_VOICES",
    "CONTACTFLOW_LOGS",
    "CONTACT_LENS",
    "EARLY_MEDIA",
    "ENHANCED_CHAT_MONITORING",
    "ENHANCED_CONTACT_MONITORING",
    "HIGH_VOLUME_OUTBOUND",
    "INBOUND_CALLS",
    "MESSAGE_STREAMING",
    "MULTI_PARTY_CHAT_CONFERENCE",
    "MULTI_PARTY_CONFERENCE",
    "OUTBOUND_CALLS",
    "USE_CUSTOM_TTS_VOICES",
]
InstanceReplicationStatusType = Literal[
    "INSTANCE_REPLICATION_COMPLETE",
    "INSTANCE_REPLICATION_DELETION_FAILED",
    "INSTANCE_REPLICATION_FAILED",
    "INSTANCE_REPLICATION_IN_PROGRESS",
    "INSTANCE_REPLICA_DELETING",
    "RESOURCE_REPLICATION_NOT_STARTED",
]
InstanceStatusType = Literal["ACTIVE", "CREATION_FAILED", "CREATION_IN_PROGRESS"]
InstanceStorageResourceTypeType = Literal[
    "AGENT_EVENTS",
    "ATTACHMENTS",
    "CALL_RECORDINGS",
    "CHAT_TRANSCRIPTS",
    "CONTACT_EVALUATIONS",
    "CONTACT_TRACE_RECORDS",
    "EMAIL_MESSAGES",
    "MEDIA_STREAMS",
    "REAL_TIME_CONTACT_ANALYSIS_CHAT_SEGMENTS",
    "REAL_TIME_CONTACT_ANALYSIS_SEGMENTS",
    "REAL_TIME_CONTACT_ANALYSIS_VOICE_SEGMENTS",
    "SCHEDULED_REPORTS",
    "SCREEN_RECORDINGS",
]
IntegrationTypeType = Literal[
    "ANALYTICS_CONNECTOR",
    "APPLICATION",
    "CALL_TRANSFER_CONNECTOR",
    "CASES_DOMAIN",
    "COGNITO_USER_POOL",
    "EVENT",
    "FILE_SCANNER",
    "MESSAGE_PROCESSOR",
    "PINPOINT_APP",
    "Q_MESSAGE_TEMPLATES",
    "SES_IDENTITY",
    "VOICE_ID",
    "WISDOM_ASSISTANT",
    "WISDOM_KNOWLEDGE_BASE",
    "WISDOM_QUICK_RESPONSES",
]
IntervalPeriodType = Literal["DAY", "FIFTEEN_MIN", "HOUR", "THIRTY_MIN", "TOTAL", "WEEK"]
IvrRecordingTrackType = Literal["ALL"]
LexVersionType = Literal["V1", "V2"]
ListAgentStatusesPaginatorName = Literal["list_agent_statuses"]
ListApprovedOriginsPaginatorName = Literal["list_approved_origins"]
ListAuthenticationProfilesPaginatorName = Literal["list_authentication_profiles"]
ListBotsPaginatorName = Literal["list_bots"]
ListChildHoursOfOperationsPaginatorName = Literal["list_child_hours_of_operations"]
ListContactEvaluationsPaginatorName = Literal["list_contact_evaluations"]
ListContactFlowModuleAliasesPaginatorName = Literal["list_contact_flow_module_aliases"]
ListContactFlowModuleVersionsPaginatorName = Literal["list_contact_flow_module_versions"]
ListContactFlowModulesPaginatorName = Literal["list_contact_flow_modules"]
ListContactFlowVersionsPaginatorName = Literal["list_contact_flow_versions"]
ListContactFlowsPaginatorName = Literal["list_contact_flows"]
ListContactReferencesPaginatorName = Literal["list_contact_references"]
ListDataTableAttributesPaginatorName = Literal["list_data_table_attributes"]
ListDataTablePrimaryValuesPaginatorName = Literal["list_data_table_primary_values"]
ListDataTableValuesPaginatorName = Literal["list_data_table_values"]
ListDataTablesPaginatorName = Literal["list_data_tables"]
ListDefaultVocabulariesPaginatorName = Literal["list_default_vocabularies"]
ListEntitySecurityProfilesPaginatorName = Literal["list_entity_security_profiles"]
ListEvaluationFormVersionsPaginatorName = Literal["list_evaluation_form_versions"]
ListEvaluationFormsPaginatorName = Literal["list_evaluation_forms"]
ListFlowAssociationResourceTypeType = Literal[
    "ANALYTICS_CONNECTOR",
    "INBOUND_EMAIL",
    "OUTBOUND_EMAIL",
    "VOICE_PHONE_NUMBER",
    "WHATSAPP_MESSAGING_PHONE_NUMBER",
]
ListFlowAssociationsPaginatorName = Literal["list_flow_associations"]
ListHoursOfOperationOverridesPaginatorName = Literal["list_hours_of_operation_overrides"]
ListHoursOfOperationsPaginatorName = Literal["list_hours_of_operations"]
ListInstanceAttributesPaginatorName = Literal["list_instance_attributes"]
ListInstanceStorageConfigsPaginatorName = Literal["list_instance_storage_configs"]
ListInstancesPaginatorName = Literal["list_instances"]
ListIntegrationAssociationsPaginatorName = Literal["list_integration_associations"]
ListLambdaFunctionsPaginatorName = Literal["list_lambda_functions"]
ListLexBotsPaginatorName = Literal["list_lex_bots"]
ListPhoneNumbersPaginatorName = Literal["list_phone_numbers"]
ListPhoneNumbersV2PaginatorName = Literal["list_phone_numbers_v2"]
ListPredefinedAttributesPaginatorName = Literal["list_predefined_attributes"]
ListPromptsPaginatorName = Literal["list_prompts"]
ListQueueQuickConnectsPaginatorName = Literal["list_queue_quick_connects"]
ListQueuesPaginatorName = Literal["list_queues"]
ListQuickConnectsPaginatorName = Literal["list_quick_connects"]
ListRoutingProfileManualAssignmentQueuesPaginatorName = Literal[
    "list_routing_profile_manual_assignment_queues"
]
ListRoutingProfileQueuesPaginatorName = Literal["list_routing_profile_queues"]
ListRoutingProfilesPaginatorName = Literal["list_routing_profiles"]
ListRulesPaginatorName = Literal["list_rules"]
ListSecurityKeysPaginatorName = Literal["list_security_keys"]
ListSecurityProfileApplicationsPaginatorName = Literal["list_security_profile_applications"]
ListSecurityProfileFlowModulesPaginatorName = Literal["list_security_profile_flow_modules"]
ListSecurityProfilePermissionsPaginatorName = Literal["list_security_profile_permissions"]
ListSecurityProfilesPaginatorName = Literal["list_security_profiles"]
ListTaskTemplatesPaginatorName = Literal["list_task_templates"]
ListTestCasesPaginatorName = Literal["list_test_cases"]
ListTrafficDistributionGroupUsersPaginatorName = Literal["list_traffic_distribution_group_users"]
ListTrafficDistributionGroupsPaginatorName = Literal["list_traffic_distribution_groups"]
ListUseCasesPaginatorName = Literal["list_use_cases"]
ListUserHierarchyGroupsPaginatorName = Literal["list_user_hierarchy_groups"]
ListUserProficienciesPaginatorName = Literal["list_user_proficiencies"]
ListUsersPaginatorName = Literal["list_users"]
ListViewVersionsPaginatorName = Literal["list_view_versions"]
ListViewsPaginatorName = Literal["list_views"]
ListWorkspacePagesPaginatorName = Literal["list_workspace_pages"]
ListWorkspacesPaginatorName = Literal["list_workspaces"]
LocaleCodeType = Literal[
    "de_DE",
    "en_US",
    "es_ES",
    "fr_FR",
    "id_ID",
    "it_IT",
    "ja_JP",
    "ko_KR",
    "pt_BR",
    "zh_CN",
    "zh_TW",
]
MediaStreamTypeType = Literal["AUDIO", "VIDEO"]
MediaTypeType = Literal[
    "IMAGE_LOGO_DARK_FAVICON",
    "IMAGE_LOGO_DARK_HORIZONTAL",
    "IMAGE_LOGO_LIGHT_FAVICON",
    "IMAGE_LOGO_LIGHT_HORIZONTAL",
]
MeetingFeatureStatusType = Literal["AVAILABLE", "UNAVAILABLE"]
MonitorCapabilityType = Literal["BARGE", "SILENT_MONITOR"]
MultiSelectQuestionRuleCategoryAutomationConditionType = Literal["NOT_PRESENT", "PRESENT"]
NextContactTypeType = Literal["QUICK_CONNECT"]
NotificationContentTypeType = Literal["PLAIN_TEXT"]
NotificationDeliveryTypeType = Literal["EMAIL"]
NotificationPriorityType = Literal["HIGH", "LOW", "URGENT"]
NotificationSourceType = Literal["CUSTOMER", "RULES", "SYSTEM"]
NotificationStatusType = Literal["HIDDEN", "READ", "UNREAD"]
NumberComparisonTypeType = Literal[
    "EQUAL", "GREATER", "GREATER_OR_EQUAL", "LESSER", "LESSER_OR_EQUAL", "NOT_EQUAL", "RANGE"
]
NumericQuestionPropertyAutomationLabelType = Literal[
    "AGENT_INTERACTION_AND_HOLD_DURATION",
    "AGENT_INTERACTION_DURATION",
    "CONTACT_DURATION",
    "CUSTOMER_HOLD_TIME",
    "CUSTOMER_SENTIMENT_SCORE_WITHOUT_AGENT",
    "CUSTOMER_SENTIMENT_SCORE_WITH_AGENT",
    "LONGEST_HOLD_DURATION",
    "NON_TALK_TIME",
    "NON_TALK_TIME_PERCENTAGE",
    "NUMBER_OF_HOLDS",
    "NUMBER_OF_INTERRUPTIONS",
    "OVERALL_AGENT_SENTIMENT_SCORE",
    "OVERALL_CUSTOMER_SENTIMENT_SCORE",
]
OperationalStatusType = Literal["CLOSED", "OPEN"]
OutboundMessageSourceTypeType = Literal["RAW", "TEMPLATE"]
OutboundStrategyTypeType = Literal["AGENT_FIRST"]
OverrideDaysType = Literal[
    "FRIDAY", "MONDAY", "SATURDAY", "SUNDAY", "THURSDAY", "TUESDAY", "WEDNESDAY"
]
OverrideTypeType = Literal["CLOSED", "OPEN", "STANDARD"]
ParticipantRoleType = Literal["AGENT", "CUSTOMER", "CUSTOM_BOT", "SUPERVISOR", "SYSTEM"]
ParticipantStateType = Literal["CONNECTED", "DISCONNECTED", "INITIAL", "MISSED"]
ParticipantTimerActionType = Literal["Unset"]
ParticipantTimerTypeType = Literal["DISCONNECT_NONCUSTOMER", "IDLE"]
ParticipantTypeType = Literal["AGENT", "ALL", "CUSTOMER", "MANAGER", "THIRDPARTY"]
PhoneNumberCountryCodeType = Literal[
    "AD",
    "AE",
    "AF",
    "AG",
    "AI",
    "AL",
    "AM",
    "AN",
    "AO",
    "AQ",
    "AR",
    "AS",
    "AT",
    "AU",
    "AW",
    "AZ",
    "BA",
    "BB",
    "BD",
    "BE",
    "BF",
    "BG",
    "BH",
    "BI",
    "BJ",
    "BL",
    "BM",
    "BN",
    "BO",
    "BR",
    "BS",
    "BT",
    "BW",
    "BY",
    "BZ",
    "CA",
    "CC",
    "CD",
    "CF",
    "CG",
    "CH",
    "CI",
    "CK",
    "CL",
    "CM",
    "CN",
    "CO",
    "CR",
    "CU",
    "CV",
    "CW",
    "CX",
    "CY",
    "CZ",
    "DE",
    "DJ",
    "DK",
    "DM",
    "DO",
    "DZ",
    "EC",
    "EE",
    "EG",
    "EH",
    "ER",
    "ES",
    "ET",
    "FI",
    "FJ",
    "FK",
    "FM",
    "FO",
    "FR",
    "GA",
    "GB",
    "GD",
    "GE",
    "GG",
    "GH",
    "GI",
    "GL",
    "GM",
    "GN",
    "GQ",
    "GR",
    "GT",
    "GU",
    "GW",
    "GY",
    "HK",
    "HN",
    "HR",
    "HT",
    "HU",
    "ID",
    "IE",
    "IL",
    "IM",
    "IN",
    "IO",
    "IQ",
    "IR",
    "IS",
    "IT",
    "JE",
    "JM",
    "JO",
    "JP",
    "KE",
    "KG",
    "KH",
    "KI",
    "KM",
    "KN",
    "KP",
    "KR",
    "KW",
    "KY",
    "KZ",
    "LA",
    "LB",
    "LC",
    "LI",
    "LK",
    "LR",
    "LS",
    "LT",
    "LU",
    "LV",
    "LY",
    "MA",
    "MC",
    "MD",
    "ME",
    "MF",
    "MG",
    "MH",
    "MK",
    "ML",
    "MM",
    "MN",
    "MO",
    "MP",
    "MR",
    "MS",
    "MT",
    "MU",
    "MV",
    "MW",
    "MX",
    "MY",
    "MZ",
    "NA",
    "NC",
    "NE",
    "NG",
    "NI",
    "NL",
    "NO",
    "NP",
    "NR",
    "NU",
    "NZ",
    "OM",
    "PA",
    "PE",
    "PF",
    "PG",
    "PH",
    "PK",
    "PL",
    "PM",
    "PN",
    "PR",
    "PT",
    "PW",
    "PY",
    "QA",
    "RE",
    "RO",
    "RS",
    "RU",
    "RW",
    "SA",
    "SB",
    "SC",
    "SD",
    "SE",
    "SG",
    "SH",
    "SI",
    "SJ",
    "SK",
    "SL",
    "SM",
    "SN",
    "SO",
    "SR",
    "ST",
    "SV",
    "SX",
    "SY",
    "SZ",
    "TC",
    "TD",
    "TG",
    "TH",
    "TJ",
    "TK",
    "TL",
    "TM",
    "TN",
    "TO",
    "TR",
    "TT",
    "TV",
    "TW",
    "TZ",
    "UA",
    "UG",
    "US",
    "UY",
    "UZ",
    "VA",
    "VC",
    "VE",
    "VG",
    "VI",
    "VN",
    "VU",
    "WF",
    "WS",
    "YE",
    "YT",
    "ZA",
    "ZM",
    "ZW",
]
PhoneNumberTypeType = Literal[
    "DID", "SHARED", "SHORT_CODE", "THIRD_PARTY_DID", "THIRD_PARTY_TF", "TOLL_FREE", "UIFN"
]
PhoneNumberWorkflowStatusType = Literal["CLAIMED", "FAILED", "IN_PROGRESS"]
PhoneTypeType = Literal["DESK_PHONE", "SOFT_PHONE"]
QuestionRuleCategoryAutomationConditionType = Literal["NOT_PRESENT", "PRESENT"]
QueueStatusType = Literal["DISABLED", "ENABLED"]
QueueTypeType = Literal["AGENT", "STANDARD"]
QuickConnectTypeType = Literal["FLOW", "PHONE_NUMBER", "QUEUE", "USER"]
RealTimeContactAnalysisOutputTypeType = Literal["Raw", "Redacted"]
RealTimeContactAnalysisPostContactSummaryFailureCodeType = Literal[
    "FAILED_SAFETY_GUIDELINES",
    "INSUFFICIENT_CONVERSATION_CONTENT",
    "INTERNAL_ERROR",
    "INVALID_ANALYSIS_CONFIGURATION",
    "QUOTA_EXCEEDED",
]
RealTimeContactAnalysisPostContactSummaryStatusType = Literal["COMPLETED", "FAILED"]
RealTimeContactAnalysisSegmentTypeType = Literal[
    "Attachments", "Categories", "Event", "Issues", "PostContactSummary", "Transcript"
]
RealTimeContactAnalysisSentimentLabelType = Literal["NEGATIVE", "NEUTRAL", "POSITIVE"]
RealTimeContactAnalysisStatusType = Literal["COMPLETED", "FAILED", "IN_PROGRESS"]
RealTimeContactAnalysisSupportedChannelType = Literal["CHAT", "VOICE"]
RecordingStatusType = Literal["AVAILABLE", "DELETED"]
RecurrenceFrequencyType = Literal["MONTHLY", "WEEKLY", "YEARLY"]
ReferenceStatusType = Literal[
    "APPROVED", "AVAILABLE", "DELETED", "FAILED", "PROCESSING", "REJECTED"
]
ReferenceTypeType = Literal[
    "ATTACHMENT",
    "CONTACT_ANALYSIS",
    "DATE",
    "EMAIL",
    "EMAIL_MESSAGE",
    "EMAIL_MESSAGE_PLAIN_TEXT",
    "EMAIL_MESSAGE_PLAIN_TEXT_REDACTED",
    "EMAIL_MESSAGE_REDACTED",
    "NUMBER",
    "STRING",
    "URL",
]
RehydrationTypeType = Literal["ENTIRE_PAST_SESSION", "FROM_SEGMENT"]
ResponseModeType = Literal["COMPLETE", "INCREMENTAL"]
RoutingCriteriaStepStatusType = Literal["ACTIVE", "EXPIRED", "INACTIVE", "JOINED"]
RulePublishStatusType = Literal["DRAFT", "PUBLISHED"]
ScreenShareCapabilityType = Literal["SEND"]
SearchAgentStatusesPaginatorName = Literal["search_agent_statuses"]
SearchAvailablePhoneNumbersPaginatorName = Literal["search_available_phone_numbers"]
SearchContactFlowModulesPaginatorName = Literal["search_contact_flow_modules"]
SearchContactFlowsPaginatorName = Literal["search_contact_flows"]
SearchContactsMatchTypeType = Literal["MATCH_ALL", "MATCH_ANY", "MATCH_EXACT", "MATCH_NONE"]
SearchContactsPaginatorName = Literal["search_contacts"]
SearchContactsTimeRangeConditionTypeType = Literal["NOT_EXISTS"]
SearchContactsTimeRangeTypeType = Literal[
    "CONNECTED_TO_AGENT_TIMESTAMP",
    "DISCONNECT_TIMESTAMP",
    "ENQUEUE_TIMESTAMP",
    "INITIATION_TIMESTAMP",
    "SCHEDULED_TIMESTAMP",
]
SearchDataTablesPaginatorName = Literal["search_data_tables"]
SearchHoursOfOperationOverridesPaginatorName = Literal["search_hours_of_operation_overrides"]
SearchHoursOfOperationsPaginatorName = Literal["search_hours_of_operations"]
SearchPredefinedAttributesPaginatorName = Literal["search_predefined_attributes"]
SearchPromptsPaginatorName = Literal["search_prompts"]
SearchQueuesPaginatorName = Literal["search_queues"]
SearchQuickConnectsPaginatorName = Literal["search_quick_connects"]
SearchResourceTagsPaginatorName = Literal["search_resource_tags"]
SearchRoutingProfilesPaginatorName = Literal["search_routing_profiles"]
SearchSecurityProfilesPaginatorName = Literal["search_security_profiles"]
SearchTestCasesPaginatorName = Literal["search_test_cases"]
SearchUserHierarchyGroupsPaginatorName = Literal["search_user_hierarchy_groups"]
SearchUsersPaginatorName = Literal["search_users"]
SearchViewsPaginatorName = Literal["search_views"]
SearchVocabulariesPaginatorName = Literal["search_vocabularies"]
SearchWorkspaceAssociationsPaginatorName = Literal["search_workspace_associations"]
SearchWorkspacesPaginatorName = Literal["search_workspaces"]
SearchableQueueTypeType = Literal["STANDARD"]
SingleSelectQuestionRuleCategoryAutomationConditionType = Literal["NOT_PRESENT", "PRESENT"]
SlaAssignmentTypeType = Literal["CASES"]
SlaTypeType = Literal["CaseField"]
SortOrderType = Literal["ASCENDING", "DESCENDING"]
SortableFieldNameType = Literal[
    "CHANNEL",
    "CONNECTED_TO_AGENT_TIMESTAMP",
    "DISCONNECT_TIMESTAMP",
    "EXPIRY_TIMESTAMP",
    "INITIATION_METHOD",
    "INITIATION_TIMESTAMP",
    "SCHEDULED_TIMESTAMP",
]
SourceTypeType = Literal["CASES", "SALESFORCE", "ZENDESK"]
StatisticType = Literal["AVG", "MAX", "SUM"]
StatusType = Literal["COMPLETE", "DELETED", "IN_PROGRESS"]
StorageTypeType = Literal["KINESIS_FIREHOSE", "KINESIS_STREAM", "KINESIS_VIDEO_STREAM", "S3"]
StringComparisonTypeType = Literal["CONTAINS", "EXACT", "STARTS_WITH"]
TargetListTypeType = Literal["PROFICIENCIES"]
TaskTemplateFieldTypeType = Literal[
    "BOOLEAN",
    "DATE_TIME",
    "DESCRIPTION",
    "EMAIL",
    "EXPIRY_DURATION",
    "NAME",
    "NUMBER",
    "QUICK_CONNECT",
    "SCHEDULED_TIME",
    "SELF_ASSIGN",
    "SINGLE_SELECT",
    "TEXT",
    "TEXT_AREA",
    "URL",
]
TaskTemplateStatusType = Literal["ACTIVE", "INACTIVE"]
TestCaseEntryPointTypeType = Literal["CHAT", "VOICE_CALL"]
TestCaseExecutionStatusType = Literal["FAILED", "INITIATED", "IN_PROGRESS", "PASSED", "STOPPED"]
TestCaseStatusType = Literal["PUBLISHED", "SAVED"]
TimerEligibleParticipantRolesType = Literal["AGENT", "CUSTOMER"]
TrafficDistributionGroupStatusType = Literal[
    "ACTIVE",
    "CREATION_FAILED",
    "CREATION_IN_PROGRESS",
    "DELETION_FAILED",
    "PENDING_DELETION",
    "UPDATE_IN_PROGRESS",
]
TrafficTypeType = Literal["CAMPAIGN", "GENERAL"]
UnitType = Literal["COUNT", "PERCENT", "SECONDS"]
UseCaseTypeType = Literal["CONNECT_CAMPAIGNS", "RULES_EVALUATION"]
VideoCapabilityType = Literal["SEND"]
ViewStatusType = Literal["PUBLISHED", "SAVED"]
ViewTypeType = Literal["AWS_MANAGED", "CUSTOMER_MANAGED"]
VisibilityType = Literal["ALL", "ASSIGNED", "NONE"]
VocabularyLanguageCodeType = Literal[
    "ar-AE",
    "ca-ES",
    "da-DK",
    "de-CH",
    "de-DE",
    "en-AB",
    "en-AU",
    "en-GB",
    "en-IE",
    "en-IN",
    "en-NZ",
    "en-US",
    "en-WL",
    "en-ZA",
    "es-ES",
    "es-US",
    "fi-FI",
    "fr-CA",
    "fr-FR",
    "hi-IN",
    "id-ID",
    "it-IT",
    "ja-JP",
    "ko-KR",
    "ms-MY",
    "nl-NL",
    "no-NO",
    "pl-PL",
    "pt-BR",
    "pt-PT",
    "sv-SE",
    "tl-PH",
    "zh-CN",
]
VocabularyStateType = Literal[
    "ACTIVE", "CREATION_FAILED", "CREATION_IN_PROGRESS", "DELETE_IN_PROGRESS"
]
VoiceEnhancementModeType = Literal["NOISE_SUPPRESSION", "NONE", "VOICE_ISOLATION"]
VoiceRecordingTrackType = Literal["ALL", "FROM_AGENT", "TO_AGENT"]
WorkspaceFontFamilyType = Literal[
    "Arial", "Courier New", "Georgia", "Times New Roman", "Trebuchet", "Verdana"
]
ConnectServiceName = Literal["connect"]
ServiceName = Literal[
    "accessanalyzer",
    "account",
    "acm",
    "acm-pca",
    "aiops",
    "amp",
    "amplify",
    "amplifybackend",
    "amplifyuibuilder",
    "apigateway",
    "apigatewaymanagementapi",
    "apigatewayv2",
    "appconfig",
    "appconfigdata",
    "appfabric",
    "appflow",
    "appintegrations",
    "application-autoscaling",
    "application-insights",
    "application-signals",
    "applicationcostprofiler",
    "appmesh",
    "apprunner",
    "appstream",
    "appsync",
    "arc-region-switch",
    "arc-zonal-shift",
    "artifact",
    "athena",
    "auditmanager",
    "autoscaling",
    "autoscaling-plans",
    "b2bi",
    "backup",
    "backup-gateway",
    "backupsearch",
    "batch",
    "bcm-dashboards",
    "bcm-data-exports",
    "bcm-pricing-calculator",
    "bcm-recommended-actions",
    "bedrock",
    "bedrock-agent",
    "bedrock-agent-runtime",
    "bedrock-agentcore",
    "bedrock-agentcore-control",
    "bedrock-data-automation",
    "bedrock-data-automation-runtime",
    "bedrock-runtime",
    "billing",
    "billingconductor",
    "braket",
    "budgets",
    "ce",
    "chatbot",
    "chime",
    "chime-sdk-identity",
    "chime-sdk-media-pipelines",
    "chime-sdk-meetings",
    "chime-sdk-messaging",
    "chime-sdk-voice",
    "cleanrooms",
    "cleanroomsml",
    "cloud9",
    "cloudcontrol",
    "clouddirectory",
    "cloudformation",
    "cloudfront",
    "cloudfront-keyvaluestore",
    "cloudhsm",
    "cloudhsmv2",
    "cloudsearch",
    "cloudsearchdomain",
    "cloudtrail",
    "cloudtrail-data",
    "cloudwatch",
    "codeartifact",
    "codebuild",
    "codecatalyst",
    "codecommit",
    "codeconnections",
    "codedeploy",
    "codeguru-reviewer",
    "codeguru-security",
    "codeguruprofiler",
    "codepipeline",
    "codestar-connections",
    "codestar-notifications",
    "cognito-identity",
    "cognito-idp",
    "cognito-sync",
    "comprehend",
    "comprehendmedical",
    "compute-optimizer",
    "compute-optimizer-automation",
    "config",
    "connect",
    "connect-contact-lens",
    "connectcampaigns",
    "connectcampaignsv2",
    "connectcases",
    "connecthealth",
    "connectparticipant",
    "controlcatalog",
    "controltower",
    "cost-optimization-hub",
    "cur",
    "customer-profiles",
    "databrew",
    "dataexchange",
    "datapipeline",
    "datasync",
    "datazone",
    "dax",
    "deadline",
    "detective",
    "devicefarm",
    "devops-agent",
    "devops-guru",
    "directconnect",
    "discovery",
    "dlm",
    "dms",
    "docdb",
    "docdb-elastic",
    "drs",
    "ds",
    "ds-data",
    "dsql",
    "dynamodb",
    "dynamodbstreams",
    "ebs",
    "ec2",
    "ec2-instance-connect",
    "ecr",
    "ecr-public",
    "ecs",
    "efs",
    "eks",
    "eks-auth",
    "elasticache",
    "elasticbeanstalk",
    "elb",
    "elbv2",
    "elementalinference",
    "emr",
    "emr-containers",
    "emr-serverless",
    "entityresolution",
    "es",
    "events",
    "evs",
    "finspace",
    "finspace-data",
    "firehose",
    "fis",
    "fms",
    "forecast",
    "forecastquery",
    "frauddetector",
    "freetier",
    "fsx",
    "gamelift",
    "gameliftstreams",
    "geo-maps",
    "geo-places",
    "geo-routes",
    "glacier",
    "globalaccelerator",
    "glue",
    "grafana",
    "greengrass",
    "greengrassv2",
    "groundstation",
    "guardduty",
    "health",
    "healthlake",
    "iam",
    "identitystore",
    "imagebuilder",
    "importexport",
    "inspector",
    "inspector-scan",
    "inspector2",
    "interconnect",
    "internetmonitor",
    "invoicing",
    "iot",
    "iot-data",
    "iot-jobs-data",
    "iot-managed-integrations",
    "iotdeviceadvisor",
    "iotevents",
    "iotevents-data",
    "iotfleetwise",
    "iotsecuretunneling",
    "iotsitewise",
    "iotthingsgraph",
    "iottwinmaker",
    "iotwireless",
    "ivs",
    "ivs-realtime",
    "ivschat",
    "kafka",
    "kafkaconnect",
    "kendra",
    "kendra-ranking",
    "keyspaces",
    "keyspacesstreams",
    "kinesis",
    "kinesis-video-archived-media",
    "kinesis-video-media",
    "kinesis-video-signaling",
    "kinesis-video-webrtc-storage",
    "kinesisanalytics",
    "kinesisanalyticsv2",
    "kinesisvideo",
    "kms",
    "lakeformation",
    "lambda",
    "launch-wizard",
    "lex-models",
    "lex-runtime",
    "lexv2-models",
    "lexv2-runtime",
    "license-manager",
    "license-manager-linux-subscriptions",
    "license-manager-user-subscriptions",
    "lightsail",
    "location",
    "logs",
    "lookoutequipment",
    "m2",
    "machinelearning",
    "macie2",
    "mailmanager",
    "managedblockchain",
    "managedblockchain-query",
    "marketplace-agreement",
    "marketplace-catalog",
    "marketplace-deployment",
    "marketplace-discovery",
    "marketplace-entitlement",
    "marketplace-reporting",
    "marketplacecommerceanalytics",
    "mediaconnect",
    "mediaconvert",
    "medialive",
    "mediapackage",
    "mediapackage-vod",
    "mediapackagev2",
    "mediastore",
    "mediastore-data",
    "mediatailor",
    "medical-imaging",
    "memorydb",
    "meteringmarketplace",
    "mgh",
    "mgn",
    "migration-hub-refactor-spaces",
    "migrationhub-config",
    "migrationhuborchestrator",
    "migrationhubstrategy",
    "mpa",
    "mq",
    "mturk",
    "mwaa",
    "mwaa-serverless",
    "neptune",
    "neptune-graph",
    "neptunedata",
    "network-firewall",
    "networkflowmonitor",
    "networkmanager",
    "networkmonitor",
    "notifications",
    "notificationscontacts",
    "nova-act",
    "oam",
    "observabilityadmin",
    "odb",
    "omics",
    "opensearch",
    "opensearchserverless",
    "organizations",
    "osis",
    "outposts",
    "panorama",
    "partnercentral-account",
    "partnercentral-benefits",
    "partnercentral-channel",
    "partnercentral-selling",
    "payment-cryptography",
    "payment-cryptography-data",
    "pca-connector-ad",
    "pca-connector-scep",
    "pcs",
    "personalize",
    "personalize-events",
    "personalize-runtime",
    "pi",
    "pinpoint",
    "pinpoint-email",
    "pinpoint-sms-voice",
    "pinpoint-sms-voice-v2",
    "pipes",
    "polly",
    "pricing",
    "proton",
    "qapps",
    "qbusiness",
    "qconnect",
    "quicksight",
    "ram",
    "rbin",
    "rds",
    "rds-data",
    "redshift",
    "redshift-data",
    "redshift-serverless",
    "rekognition",
    "repostspace",
    "resiliencehub",
    "resource-explorer-2",
    "resource-groups",
    "resourcegroupstaggingapi",
    "rolesanywhere",
    "route53",
    "route53-recovery-cluster",
    "route53-recovery-control-config",
    "route53-recovery-readiness",
    "route53domains",
    "route53globalresolver",
    "route53profiles",
    "route53resolver",
    "rtbfabric",
    "rum",
    "s3",
    "s3control",
    "s3files",
    "s3outposts",
    "s3tables",
    "s3vectors",
    "sagemaker",
    "sagemaker-a2i-runtime",
    "sagemaker-edge",
    "sagemaker-featurestore-runtime",
    "sagemaker-geospatial",
    "sagemaker-metrics",
    "sagemaker-runtime",
    "savingsplans",
    "scheduler",
    "schemas",
    "sdb",
    "secretsmanager",
    "security-ir",
    "securityagent",
    "securityhub",
    "securitylake",
    "serverlessrepo",
    "service-quotas",
    "servicecatalog",
    "servicecatalog-appregistry",
    "servicediscovery",
    "ses",
    "sesv2",
    "shield",
    "signer",
    "signer-data",
    "signin",
    "simpledbv2",
    "simspaceweaver",
    "snow-device-management",
    "snowball",
    "sns",
    "socialmessaging",
    "sqs",
    "ssm",
    "ssm-contacts",
    "ssm-guiconnect",
    "ssm-incidents",
    "ssm-quicksetup",
    "ssm-sap",
    "sso",
    "sso-admin",
    "sso-oidc",
    "stepfunctions",
    "storagegateway",
    "sts",
    "supplychain",
    "support",
    "support-app",
    "sustainability",
    "swf",
    "synthetics",
    "taxsettings",
    "textract",
    "timestream-influxdb",
    "timestream-query",
    "timestream-write",
    "tnb",
    "transcribe",
    "transfer",
    "translate",
    "trustedadvisor",
    "uxc",
    "verifiedpermissions",
    "voice-id",
    "vpc-lattice",
    "waf",
    "waf-regional",
    "wafv2",
    "wellarchitected",
    "wickr",
    "wisdom",
    "workdocs",
    "workmail",
    "workmailmessageflow",
    "workspaces",
    "workspaces-instances",
    "workspaces-thin-client",
    "workspaces-web",
    "xray",
]
ResourceServiceName = Literal[
    "cloudformation", "cloudwatch", "dynamodb", "ec2", "glacier", "iam", "s3", "sns", "sqs"
]
PaginatorName = Literal[
    "get_metric_data",
    "list_agent_statuses",
    "list_approved_origins",
    "list_authentication_profiles",
    "list_bots",
    "list_child_hours_of_operations",
    "list_contact_evaluations",
    "list_contact_flow_module_aliases",
    "list_contact_flow_module_versions",
    "list_contact_flow_modules",
    "list_contact_flow_versions",
    "list_contact_flows",
    "list_contact_references",
    "list_data_table_attributes",
    "list_data_table_primary_values",
    "list_data_table_values",
    "list_data_tables",
    "list_default_vocabularies",
    "list_entity_security_profiles",
    "list_evaluation_form_versions",
    "list_evaluation_forms",
    "list_flow_associations",
    "list_hours_of_operation_overrides",
    "list_hours_of_operations",
    "list_instance_attributes",
    "list_instance_storage_configs",
    "list_instances",
    "list_integration_associations",
    "list_lambda_functions",
    "list_lex_bots",
    "list_phone_numbers",
    "list_phone_numbers_v2",
    "list_predefined_attributes",
    "list_prompts",
    "list_queue_quick_connects",
    "list_queues",
    "list_quick_connects",
    "list_routing_profile_manual_assignment_queues",
    "list_routing_profile_queues",
    "list_routing_profiles",
    "list_rules",
    "list_security_keys",
    "list_security_profile_applications",
    "list_security_profile_flow_modules",
    "list_security_profile_permissions",
    "list_security_profiles",
    "list_task_templates",
    "list_test_cases",
    "list_traffic_distribution_group_users",
    "list_traffic_distribution_groups",
    "list_use_cases",
    "list_user_hierarchy_groups",
    "list_user_proficiencies",
    "list_users",
    "list_view_versions",
    "list_views",
    "list_workspace_pages",
    "list_workspaces",
    "search_agent_statuses",
    "search_available_phone_numbers",
    "search_contact_flow_modules",
    "search_contact_flows",
    "search_contacts",
    "search_data_tables",
    "search_hours_of_operation_overrides",
    "search_hours_of_operations",
    "search_predefined_attributes",
    "search_prompts",
    "search_queues",
    "search_quick_connects",
    "search_resource_tags",
    "search_routing_profiles",
    "search_security_profiles",
    "search_test_cases",
    "search_user_hierarchy_groups",
    "search_users",
    "search_views",
    "search_vocabularies",
    "search_workspace_associations",
    "search_workspaces",
]
RegionName = Literal[
    "af-south-1",
    "ap-northeast-1",
    "ap-northeast-2",
    "ap-southeast-1",
    "ap-southeast-2",
    "ca-central-1",
    "eu-central-1",
    "eu-west-2",
    "us-east-1",
    "us-west-2",
]
