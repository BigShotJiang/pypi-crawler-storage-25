# ACL Python SDK (`acl-layer-py`)

Official Python SDK for Adaptive Context Layer (ACL).

## Installation

```bash
pip install acl-layer-py
```

## Quick Start

```python
from acl import ACLClient

client = ACLClient(api_key="acl_live_...")

result = client.complete(
    prompt="Summarize this incident report.",
    model="gpt-4o",
    llm_api_key="sk-...",
    max_retries=3,
)

if result["success"]:
    print(result["response"])
else:
    print(f"{result['error_code']}: {result['error_message']}")
```

## Runtime Contract

`complete()` always returns a stable top-level response shape on both success and failure:

- `success`
- `error_code`
- `error_message`
- `provider`
- `model`
- `text` and `response`

## Validation and Safety

- Fail-fast validation for invalid/missing `prompt`, unresolved `model`, missing keys, and malformed provider key formats.
- Strict provider payload allowlist prevents internal ACL params from leaking to provider APIs.
- Secrets are redacted from surfaced error messages by default.
- Default ACL backend base URL: `http://backend.fridayaicore.in`.

## Retry Behavior

- Retries happen in SDK provider execution middleware (`complete()` path).
- Exponential backoff with jitter and cap:
- attempt 1: random delay `0-0.5s`
- attempt 2: random delay `0-1s`
- attempt 3: random delay `0-2s`
- max cap per attempt: `8s`

## Compatibility Policy

- Python: `>=3.8`
- Runtime dependencies: `requests`, `urllib3`, `typing_extensions`
- Release policy: include migration notes whenever response contract or validation behavior changes.

## Usage Terms

- This SDK is proprietary and licensed for ACL service access only.
- A valid ACL API key is required.
- Redistribution, resale, sublicensing, and derivative redistribution are not permitted without written approval from ACL Team.

## License

UNLICENSED / Proprietary. See `LICENSE`.
