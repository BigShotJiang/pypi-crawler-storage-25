import requests
from typing import Any, Dict, Optional
from acl.providers.base import BaseProvider
from acl.exceptions import (
    ACLAuthenticationError,
    ACLRateLimitError,
    ACLModelError,
    ACLTimeoutError,
    ACLConnectionError,
)
from acl.security import redact_secrets


class GoogleProvider(BaseProvider):
    """
    Google (Gemini) implementation for the ACL SDK.
    Phase 7: Modularized SDK - Direct provider execution.
    """

    def capabilities(self) -> Dict[str, bool]:
        return {
            "streaming": True,
            "tools": True,
            "json_mode": True,
            "vision": True,
            "embeddings": True,
            "function_calling": True,
        }

    def call(
        self,
        prompt: str,
        model: str,
        api_key: str,
        max_tokens: Optional[int] = None,
        temperature: float = 0.7,
        stream: bool = False,
        timeout: int = 30,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        """
        Executes a call to Google Gemini API via REST.
        Standardizes the response for ACL pipeline.
        """
        # Google API requires the model name in the URL
        url_model = model
        if not url_model.startswith("models/"):
            url_model = f"models/{url_model}"

        url = f"https://generativelanguage.googleapis.com/v1beta/{url_model}:generateContent?key={api_key}"

        payload = {
            "contents": [{"parts": [{"text": prompt}]}],
            "generationConfig": {
                "maxOutputTokens": max_tokens or 1024,
                "temperature": temperature,
                **kwargs,
            },
        }

        try:
            response = requests.post(
                url,
                headers={"Content-Type": "application/json"},
                json=payload,
                timeout=timeout,
            )
            response.raise_for_status()
            data = response.json()

            # Standardize response (ACL Universal Schema v1.1)
            candidates = data.get("candidates", [])
            if not candidates:
                # Check for safety filter / blocked
                if data.get("promptFeedback", {}).get("blockReason"):
                    raise ACLModelError(
                        f"Gemini blocked prompt: {data['promptFeedback']['blockReason']}"
                    )
                raise ACLModelError("Gemini returned no candidates (empty response)")

            first_candidate = candidates[0]
            content = first_candidate.get("content", {})
            parts = content.get("parts", [])
            text = parts[0].get("text", "") if parts else ""

            # Normalize finish_reason
            stop_reason = first_candidate.get("finishReason", "OTHER")
            reason_map = {
                "STOP": "stop",
                "MAX_TOKENS": "length",
                "SAFETY": "content_filter",
                "RECITATION": "content_filter",
                "OTHER": "unknown",
            }

            # Token usage info
            usage = data.get("usageMetadata", {})

            return {
                "text": text,
                "finish_reason": reason_map.get(stop_reason, "unknown"),
                "tokens_input": usage.get("promptTokenCount", 0),
                "tokens_output": usage.get("candidatesTokenCount", 0),
                "total_tokens": usage.get("totalTokenCount", 0),
                "raw_response": data,
            }
        except requests.exceptions.HTTPError as e:
            status_code = e.response.status_code
            if status_code == 401 or status_code == 403:
                raise ACLAuthenticationError(
                    f"Google Auth failed (Invalid Key): {redact_secrets(str(e))}"
                )
            elif status_code == 429:
                raise ACLRateLimitError(
                    f"Google Rate limit exceeded: {redact_secrets(str(e))}"
                )
            else:
                error_details = redact_secrets(e.response.text)
                raise ACLModelError(
                    f"Google Provider error ({status_code}): {error_details}"
                )
        except requests.exceptions.Timeout:
            raise ACLTimeoutError("Google request timed out")
        except requests.exceptions.ConnectionError:
            raise ACLConnectionError("Google connection failed")
        except Exception as e:
            raise ACLModelError(f"Unexpected Google error: {redact_secrets(str(e))}")

    def stream(self, **kwargs: Any) -> Any:
        raise NotImplementedError(
            "Streaming not yet supported. Use complete() for standard requests."
        )
