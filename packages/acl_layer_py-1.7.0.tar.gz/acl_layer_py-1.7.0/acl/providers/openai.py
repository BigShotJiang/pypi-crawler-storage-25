import requests
from typing import Any, Dict, Optional
from acl.providers.base import BaseProvider
from acl.exceptions import (
    ACLAuthenticationError,
    ACLRateLimitError,
    ACLModelError,
    ACLTimeoutError,
    ACLConnectionError,
)
from acl.security import redact_secrets


class OpenAIProvider(BaseProvider):
    """
    OpenAI implementation for the ACL SDK.
    Phase 2: Capability-aware.
    Phase 4: Finish reason normalization.
    """

    def capabilities(self) -> Dict[str, bool]:
        return {
            "streaming": True,
            "tools": True,
            "json_mode": True,
            "vision": True,
            "embeddings": True,
            "function_calling": True,
        }

    def call(
        self,
        prompt: str,
        model: str,
        api_key: str,
        max_tokens: Optional[int] = None,
        temperature: float = 0.7,
        stream: bool = False,
        timeout: int = 30,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        try:
            # Universal Adapter Support (Phase 7): Allow custom base URLs for OpenAI-compatible providers
            base_url = kwargs.pop("base_url", "https://api.openai.com/v1")
            if base_url.endswith("/"):
                base_url = base_url[:-1]

            endpoint = f"{base_url}/chat/completions"

            # Build request payload
            payload = {
                "model": model,
                "messages": [{"role": "user", "content": prompt}],
                "temperature": temperature,
                "stream": stream,
                **kwargs,
            }

            # Use max_completion_tokens for newer models (gpt-5+), max_tokens for older models
            if max_tokens is not None:
                if (
                    model.startswith("gpt-5")
                    or model.startswith("o1")
                    or model.startswith("o3")
                ):
                    payload["max_completion_tokens"] = max_tokens
                else:
                    payload["max_tokens"] = max_tokens

            response = requests.post(
                endpoint,
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/json",
                },
                json=payload,
                timeout=timeout,
            )
            response.raise_for_status()
            data = response.json()

            # Standardize response (ACL Universal Schema v1.1)
            usage = data.get("usage", {})
            choices = data.get("choices", [])
            choice = choices[0] if choices else {}

            # Normalize finish_reason (Phase 4)
            raw_reason = choice.get("finish_reason", "unknown")
            reason_map = {
                "stop": "stop",
                "length": "length",
                "function_call": "tool_call",
                "tool_calls": "tool_call",
                "content_filter": "content_filter",
            }

            return {
                "text": choice.get("message", {}).get("content", ""),
                "finish_reason": reason_map.get(raw_reason, "unknown"),
                "tokens_input": usage.get("prompt_tokens", 0),
                "tokens_output": usage.get("completion_tokens", 0),
                "total_tokens": usage.get("total_tokens", 0),
                "raw_response": data,
            }
        except requests.exceptions.HTTPError as e:
            status_code = e.response.status_code
            error_body = redact_secrets(
                e.response.text if hasattr(e.response, "text") else str(e)
            )
            if status_code == 401:
                raise ACLAuthenticationError(f"OpenAI Auth failed: {error_body}")
            elif status_code == 429:
                raise ACLRateLimitError(f"OpenAI Rate limit exceeded: {error_body}")
            else:
                raise ACLModelError(
                    f"OpenAI Provider error ({status_code}): {error_body}"
                )
        except requests.exceptions.Timeout:
            raise ACLTimeoutError("OpenAI request timed out")
        except requests.exceptions.ConnectionError:
            raise ACLConnectionError("OpenAI connection failed")
        except Exception as e:
            raise ACLModelError(f"Unexpected OpenAI error: {redact_secrets(str(e))}")

    def stream(self, **kwargs: Any) -> Any:
        raise NotImplementedError(
            "Streaming not yet supported. Use complete() for standard requests."
        )
