from typing import Any, Dict, Callable, List
from acl.middlewares.base import ACLMiddleware


class RecoveryMiddleware(ACLMiddleware):
    """
    Upgraded Loop Recovery (Phase 2)
    Uses 3 advanced prompt engineering strategies to break determinism:

    Step 1: Role Switch - Frame assistant as a replacement
    Step 2: Socratic Break - Force multi-step reasoning
    Step 3: Hard Context Wipe - reset history and start fresh
    """

    MAX_RECOVERY_ATTEMPTS = 3

    def __init__(self, session_manager: Any):
        self.session_manager = session_manager
        self._in_recovery = False

    def __call__(self, params: Dict[str, Any], next_call: Callable) -> Dict[str, Any]:
        if self._in_recovery:
            return next_call(params)

        session_id = params.get("session_id", "default")
        original_prompt = params.get("prompt", "")

        response = next_call(params)

        if not response.get("loop_detected"):
            return response

        self.session_manager.increment_metric(session_id, "loops_detected")

        recovery_result = self._attempt_recovery(
            params=params,
            response=response,
            next_call=next_call,
            session_id=session_id,
            original_prompt=original_prompt,
        )

        if recovery_result:
            self.session_manager.increment_metric(session_id, "loops_broken")
            original_tokens = response.get("total_tokens", 0)
            tokens_saved = max(
                0,
                original_tokens
                * (self.MAX_RECOVERY_ATTEMPTS - recovery_result["attempts"]),
            )

            return {
                **recovery_result["response"],
                "loop_detected": True,
                "loop_broken": True,
                "recovery_strategy": recovery_result["strategy"],
                "recovery_attempts": recovery_result["attempts"],
                "tokens_saved": tokens_saved,
            }

        return {
            **response,
            "loop_detected": True,
            "loop_broken": False,
            "recovery_strategy": None,
            "recovery_attempts": self.MAX_RECOVERY_ATTEMPTS,
            "tokens_saved": 0,
            "error_code": "ACL_ERR_LOOP_RECOVERY_FAILED",
            "error_message": "All loop recovery attempts exhausted. Loop persists.",
        }

    def _attempt_recovery(
        self,
        params: Dict[str, Any],
        response: Dict[str, Any],
        next_call: Callable,
        session_id: str,
        original_prompt: str,
    ) -> Dict[str, Any]:

        recovery_steps = [
            ("role_switch", self._step_role_switch),
            ("socratic_break", self._step_socratic_break),
            ("hard_wipe", self._step_hard_wipe),
        ]

        for step_idx, (strategy_name, step_func) in enumerate(recovery_steps):
            attempt = step_idx + 1

            recovery_params = step_func(
                params=params, session_id=session_id, original_prompt=original_prompt
            )

            recovery_params["_recovery_mode"] = True
            recovery_params["_recovery_attempt"] = attempt

            self._in_recovery = True

            try:
                new_response = next_call(recovery_params)
                self._in_recovery = False

                if not new_response.get("loop_detected"):
                    return {
                        "response": new_response,
                        "strategy": strategy_name,
                        "attempts": attempt,
                    }

                response = new_response
            except Exception:
                self._in_recovery = False
                continue

        return None

    def _step_role_switch(
        self, params: Dict[str, Any], session_id: str, original_prompt: str
    ) -> Dict[str, Any]:
        """Strategy 1: Role Switch."""
        new_prompt = (
            "You are a fresh AI assistant taking over this conversation. "
            "The previous assistant repeated the same response multiple times and got stuck.\n"
            f"Original task: {original_prompt}\n"
            "Provide a completely fresh and different response."
        )
        # Clear original prompt from params (if any) and replace
        # We also increase temperature slightly as a hidden bonus
        return {
            **params,
            "prompt": new_prompt,
            "temperature": 0.7,
        }

    def _step_socratic_break(
        self, params: Dict[str, Any], session_id: str, original_prompt: str
    ) -> Dict[str, Any]:
        """Strategy 2: Socratic Break."""
        socratic_prompt = (
            "STEP 1: In exactly one sentence, what is being asked?\n"
            "STEP 2: What would a completely different approach be?\n"
            "STEP 3: Answer using that different approach.\n"
            f"Original question: {original_prompt}"
        )

        return {
            **params,
            "prompt": socratic_prompt,
            "temperature": 0.5,
        }

    def _step_hard_wipe(
        self, params: Dict[str, Any], session_id: str, original_prompt: str
    ) -> Dict[str, Any]:
        """Strategy 3: Hard Context Wipe."""
        # Delete ALL session history
        self.session_manager.reset_history(session_id)

        wipe_prompt = (
            "Fresh start. No previous context.\n"
            f"Answer this directly: {original_prompt}"
        )

        return {
            **params,
            "prompt": wipe_prompt,
            "temperature": 0.4,
        }
