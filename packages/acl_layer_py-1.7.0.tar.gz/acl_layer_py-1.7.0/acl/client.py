import logging
import threading
from typing import Any, Dict, Optional, Tuple
from acl.config import ACLConfiguration
from acl.http import HttpClient
from acl.providers import ProviderRegistry
from acl.exceptions import ACLValidationError, ACLBaseError
from acl.session.manager import SessionManager
from acl.middlewares.retry import RetryMiddleware
from acl.middlewares.recovery import RecoveryMiddleware
from acl.middlewares.loop_detection import LoopDetectionMiddleware
from acl.middlewares.normalization import NormalizationMiddleware
from acl.security import redact_secrets


class ACLClient:
    """
    Phase 3 & 7 — Execution Middleware & Modular SDK.
    The client is now an orchestration layer that assembles a pipeline.
    """

    def __init__(
        self, 
        api_key: Optional[str] = None, 
        base_url: Optional[str] = None, 
        timeout_ms: Optional[int] = None,
        **kwargs
    ):
        """
        Initializes the ACLClient.
        Now supports direct keyword arguments for a true plug-and-play experience.
        """
        # 1. Resolve API Key (Options dict for backward compat, or direct arg)
        self.api_key = api_key or kwargs.get("api_key")
        
        if not self.api_key:
            raise ACLValidationError("API key is required. Pass api_key='...' or set ACL_API_KEY environment variable.")

        if not (self.api_key.startswith("sk-acl-") or self.api_key.startswith("acl_live-")):
            raise ACLValidationError(
                "Invalid ACL API key format. Expected prefix `sk-acl-` or `acl_live-`."
            )

        # 2. Configuration & HTTP
        self._config = ACLConfiguration(
            api_key=self.api_key,
            base_url=base_url or kwargs.get("base_url"),
            timeout_ms=timeout_ms or kwargs.get("timeout_ms") or (30 * 1000),
        )
        self._http_client = HttpClient(
            api_key=self._config.api_key,
            base_url=self._config.base_url,
            timeout=self._config.timeout_ms // 1000,
        )

        # 3. Session Manager (Phase 5)
        self._session_manager = SessionManager(
            policy=kwargs.get("session_policy", "FIFO"),
            limit=kwargs.get("session_limit", 200),
        )

        # Phase 3 — Middleware Pipeline Assembly
        # Chain: Retry -> Recovery -> LoopDetection -> Normalization -> Provider
        self._middlewares = [
            RetryMiddleware(),
            RecoveryMiddleware(self._session_manager),
            LoopDetectionMiddleware(self._session_manager),
            NormalizationMiddleware(),
        ]

        self._lock = threading.Lock()
        self._sdk_version = "1.7.0"
        self._environment = kwargs.get("environment", "production")
        self._secure_logging = kwargs.get("secure_logging", True)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False

    def adaptive_window(self, params: Optional[Dict[str, Any]] = None, **kwargs) -> Dict[str, Any]:
        """
        Calculates budget from the ACL Core.
        Supports both direct keyword arguments and a 'params' dictionary.
        """
        params = params or {}
        # Merge direct keyword arguments into params
        full_params = {**params, **kwargs}
        
        # Default integration mode for complete calls
        full_params.setdefault("integration_mode", "complete_mode")
        
        url = "/api/v1/adaptive/window"
        return self._http_client.post(url, json=full_params)

    def complete(self, params: Optional[Dict[str, Any]] = None, **kwargs) -> Dict[str, Any]:
        """
        Orchestrates an LLM completion request using the Universal Adaptation strategy.
        Now supports direct keyword argument usage for a plug-and-play developer experience.
        """
        params = params or {}
        # Merge direct keyword arguments into params for standard processing
        full_params = {**params, **kwargs}
        
        prompt = full_params.get("prompt")
        session_id = full_params.get("session_id", "default")

        validation_error = self._validate_complete_inputs(full_params)
        if validation_error:
            return self._error_response(
                error_code=validation_error["error_code"],
                error_message=validation_error["error_message"],
                provider=full_params.get("provider"),
                model=full_params.get("model"),
            )

        # 1. Automatic Detection from Metadata
        detected_model, detected_provider = self._detect_client_model(full_params)

        # 2. Pipeline Execution Context (Reactive mode)
        execution_context = {
            **full_params,
            "session_id": session_id,
            "model": full_params.get("model") or detected_model,
            "provider": full_params.get("provider") or detected_provider,
            "_context_health": {},
        }

        # 3. Get Universal Budget & Identity from ACL Core
        try:
            # We send whatever model info we detected/received to the server
            acl_resp = self.adaptive_window(
                {
                    "text": prompt,
                    "model": execution_context.get("model"),
                    "session_id": session_id,
                    "metadata": full_params.get("metadata", {}),
                }
            )

            # Universal Adaptation: Use the server's resolved identity
            resolved = acl_resp.get("resolved_model", {})
            execution_context["model"] = (
                resolved.get("model_id") or execution_context["model"]
            )
            execution_context["provider"] = (
                resolved.get("provider") or execution_context["provider"]
            )

            # Phase 2 — Budget Validation
            budget = acl_resp.get("window", {}).get("final_token_budget", 1000)
            is_fast_path = (
                acl_resp.get("is_fast_path", False)
                or acl_resp.get("window", {}).get("is_fast_path", False)
                or acl_resp.get("metadata", {}).get("is_fast_path", False)
                or full_params.get("is_fast_path", False)
            )

            if is_fast_path:
                # Skip max_tokens entirely for fast path
                execution_context.pop("max_tokens", None)
            else:
                # Finalize optimization strategy
                self._sync_context_security(execution_context, budget)

            execution_context["_context_health"] = acl_resp.get("context_health", {})

        except Exception as e:
            # Safe Fallback
            warning_message = "ACL Backend connection failed, falling back to local mode"
            if not self._secure_logging:
                warning_message = (
                    f"{warning_message}: {redact_secrets(str(e))}"
                )
            logging.getLogger(__name__).warning(warning_message)
            self._sync_context_security(execution_context, 1000)
            if not execution_context.get("model"):
                execution_context["model"] = "gpt-4o"
            if not execution_context.get("provider"):
                execution_context["provider"] = "openai"

        # 4. Smart Key Selection
        # If 'keys' dict is provided, pick the key based on the provider
        api_key_val = full_params.get("llm_api_key")
        if not api_key_val and "keys" in full_params:
            provider_key = execution_context["provider"].lower()
            api_key_val = full_params["keys"].get(provider_key) or full_params["keys"].get("default")

        if not api_key_val:
            return self._error_response(
                error_code="ACL_ERR_VALIDATION",
                error_message=(
                    "No LLM API key found for resolved provider. "
                    "Pass llm_api_key or keys={'provider': '...'}."
                ),
                provider=execution_context.get("provider"),
                model=execution_context.get("model"),
            )

        key_validation_error = self._validate_provider_key(
            execution_context.get("provider"), api_key_val
        )
        if key_validation_error:
            return self._error_response(
                error_code="ACL_ERR_VALIDATION",
                error_message=key_validation_error,
                provider=execution_context.get("provider"),
                model=execution_context.get("model"),
            )

        # 5. Create Execution Chain
        try:
            provider_instance = ProviderRegistry.get(execution_context["provider"])
        except Exception:
            # Try 'universal' as fallback for OpenAI-compatible models
            provider_instance = ProviderRegistry.get("universal")

        # Standard execution function
        def _execute_provider(ctx: Dict[str, Any]) -> Dict[str, Any]:
            allowlisted_params = self._provider_params_for_context(
                ctx, execution_context["provider"]
            )

            return provider_instance.call(
                prompt=ctx["prompt"],
                model=ctx["model"],
                api_key=api_key_val,
                max_tokens=ctx.get("max_tokens"),
                temperature=ctx.get("temperature", 0.7),
                stream=ctx.get("stream", False),
                # Strict provider allowlist to prevent ACL internals leaking upstream
                **allowlisted_params,
            )

        # 6. Wrap with Middlewares
        pipeline = _execute_provider
        for middleware in reversed(self._middlewares):

            def _wrap(m=middleware, n=pipeline):
                return lambda ctx: m(ctx, n)

            pipeline = _wrap()

        try:
            return pipeline(execution_context)
        except ACLBaseError as e:
            return self._error_response(
                error_code=e.error_code or "ACL_ERR_INTERNAL",
                error_message=redact_secrets(e.message),
                provider=execution_context.get("provider"),
                model=execution_context.get("model"),
            )
        except Exception as e:
            return self._error_response(
                error_code="ACL_ERR_INTERNAL",
                error_message=redact_secrets(str(e)),
                provider=execution_context.get("provider"),
                model=execution_context.get("model"),
            )

    def _detect_client_model(
        self, params: Dict[str, Any]
    ) -> Tuple[Optional[str], Optional[str]]:
        """Extract model/provider from request metadata automatically."""
        # Check standard headers or metadata
        metadata = params.get("metadata", {})
        headers = params.get("headers", {})

        # 1. Try metadata first
        model = metadata.get("model") or metadata.get("model_name")
        provider = metadata.get("provider")

        # 2. Try common header patterns
        if not model:
            model = headers.get("X-Model") or headers.get("x-model")

        # 3. Try to infer from API key prefix if present
        llm_key = params.get("llm_api_key", "")
        if not provider and llm_key:
            if llm_key.startswith("sk-ant-"):
                provider = "anthropic"
            elif llm_key.startswith("AIza"):
                provider = "google"
            elif llm_key.startswith("sk-"):
                provider = "openai"

        return model, provider

    def _validate_complete_inputs(self, params: Dict[str, Any]) -> Optional[Dict[str, str]]:
        prompt = params.get("prompt")
        if not isinstance(prompt, str) or not prompt.strip():
            return {
                "error_code": "ACL_ERR_VALIDATION",
                "error_message": "Invalid prompt. Pass a non-empty string in `prompt`.",
            }

        explicit_model = params.get("model")
        metadata_model = (params.get("metadata") or {}).get("model")
        metadata_model_name = (params.get("metadata") or {}).get("model_name")
        if explicit_model is not None and (not isinstance(explicit_model, str) or not explicit_model.strip()):
            return {
                "error_code": "ACL_ERR_VALIDATION",
                "error_message": "Invalid model. `model` must be a non-empty string when provided.",
            }
        if not explicit_model and not metadata_model and not metadata_model_name:
            return {
                "error_code": "ACL_ERR_VALIDATION",
                "error_message": "Model resolution failed. Pass `model` or `metadata.model`.",
            }

        max_retries = params.get("max_retries")
        if max_retries is not None and (not isinstance(max_retries, int) or max_retries < 1 or max_retries > 8):
            return {
                "error_code": "ACL_ERR_VALIDATION",
                "error_message": "Invalid max_retries. Use an integer between 1 and 8.",
            }

        llm_key = params.get("llm_api_key")
        keys = params.get("keys")
        if not llm_key and not keys:
            return {
                "error_code": "ACL_ERR_VALIDATION",
                "error_message": (
                    "No provider key found. Pass `llm_api_key` or `keys={'openai': '...', ...}`."
                ),
            }

        return None

    def _validate_provider_key(self, provider: Optional[str], llm_key: str) -> Optional[str]:
        if not isinstance(llm_key, str) or not llm_key.strip():
            return "Invalid llm_api_key. Provide a non-empty API key string."

        provider_name = (provider or "openai").lower()
        if provider_name in ("openai", "universal") and not llm_key.startswith("sk-"):
            return "Invalid OpenAI key format. Expected a key starting with `sk-`."
        if provider_name == "anthropic" and not llm_key.startswith("sk-ant-"):
            return "Invalid Anthropic key format. Expected a key starting with `sk-ant-`."
        if provider_name == "google" and not llm_key.startswith("AIza"):
            return "Invalid Google key format. Expected a key starting with `AIza`."
        return None

    def _provider_params_for_context(
        self, ctx: Dict[str, Any], provider: Optional[str]
    ) -> Dict[str, Any]:
        allowlists = {
            "openai": {
                "base_url",
                "top_p",
                "presence_penalty",
                "frequency_penalty",
                "stop",
                "n",
                "logit_bias",
                "user",
                "seed",
                "response_format",
                "tools",
                "tool_choice",
                "parallel_tool_calls",
            },
            "universal": {
                "base_url",
                "top_p",
                "presence_penalty",
                "frequency_penalty",
                "stop",
                "n",
                "logit_bias",
                "user",
                "seed",
                "response_format",
                "tools",
                "tool_choice",
                "parallel_tool_calls",
            },
            "anthropic": {
                "system",
                "top_p",
                "top_k",
                "stop_sequences",
                "metadata",
                "tools",
                "tool_choice",
            },
            "google": {
                "topP",
                "topK",
                "candidateCount",
                "stopSequences",
                "responseMimeType",
                "responseSchema",
                "presencePenalty",
                "frequencyPenalty",
                "seed",
                "safetySettings",
            },
        }
        allowed = allowlists.get((provider or "openai").lower(), allowlists["openai"])
        return {k: v for k, v in ctx.items() if k in allowed and v is not None}

    def _error_response(
        self,
        error_code: str,
        error_message: str,
        provider: Optional[str] = None,
        model: Optional[str] = None,
    ) -> Dict[str, Any]:
        return {
            "text": "",
            "response": "",
            "success": False,
            "provider": provider or "unknown",
            "model": model or "unknown",
            "finish_reason": "error",
            "tokens_input": 0,
            "tokens_output": 0,
            "total_tokens": 0,
            "latency_ms": 0,
            "retries": 0,
            "attempts_made": 0,
            "context_health": {},
            "loop_detected": False,
            "error_code": error_code,
            "error_message": redact_secrets(error_message),
            "budget_fallback_used": False,
            "raw_response": None,
        }

    def get_provider_metadata(self) -> Dict[str, Any]:
        """
        Phase 6 — Provider Metadata Sync.
        Optionally fetch dynamic capabilities from ACL Core.
        """
        url = "/api/v1/providers/metadata"
        try:
            return self._http_client.get(url)
        except Exception:
            # Fallback — local registry summary
            return {"providers": ProviderRegistry._registry.keys()}

    def close_session(self, session_id: str):
        self._session_manager.pop_session(session_id)

    def close(self):
        self.close_all_sessions()
        self._http_client.close()

    def close_all_sessions(self):
        for sid in self._session_manager.list_sessions():
            self.close_session(sid)

    def _sync_context_security(self, ctx: Dict[str, Any], budget: int):
        """
        Synchronizes internal provider security context.
        This ensures that the execution environment is isolated and valid.
        """
        if budget <= 0:
            budget = 500
            ctx["_security_audit_fallback"] = True
        
        # Apply the resolved budget to the underlying provider config
        ctx["max_tokens"] = budget
