from typing import Any, Dict

from acl.client import ACLClient
from acl.providers import ProviderRegistry


class _FakeProvider:
    def __init__(self):
        self.last_kwargs: Dict[str, Any] = {}

    def call(
        self,
        prompt: str,
        model: str,
        api_key: str,
        max_tokens: int = 128,
        temperature: float = 0.7,
        stream: bool = False,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        self.last_kwargs = kwargs
        return {
            "text": "ok",
            "finish_reason": "stop",
            "tokens_input": 1,
            "tokens_output": 1,
            "total_tokens": 2,
            "raw_response": {"id": "fake"},
        }


def test_complete_returns_stable_error_contract_when_key_missing():
    client = ACLClient(api_key="acl_live-12345678")
    result = client.complete(prompt="hello", model="gpt-4o")

    assert result["success"] is False
    assert "error_code" in result
    assert "error_message" in result
    assert "provider" in result
    assert "model" in result
    assert "text" in result
    assert "response" in result


def test_complete_filters_internal_acl_params(monkeypatch):
    client = ACLClient(api_key="acl_live-12345678")
    fake_provider = _FakeProvider()

    monkeypatch.setattr(
        client,
        "adaptive_window",
        lambda *_args, **_kwargs: {
            "resolved_model": {"model_id": "gpt-4o", "provider": "openai"},
            "window": {"final_token_budget": 64},
        },
    )
    monkeypatch.setattr(ProviderRegistry, "get", lambda *_args, **_kwargs: fake_provider)

    result = client.complete(
        prompt="hello",
        model="gpt-4o",
        llm_api_key="sk-test-key",
        max_retries=5,
        session_id="session-1",
        top_p=0.9,
        metadata={"x": "y"},
    )

    assert result["success"] is True
    assert fake_provider.last_kwargs.get("top_p") == 0.9
    assert "max_retries" not in fake_provider.last_kwargs
    assert "session_id" not in fake_provider.last_kwargs
    assert "metadata" not in fake_provider.last_kwargs


def test_complete_fails_fast_on_invalid_prompt():
    client = ACLClient(api_key="acl_live-12345678")
    result = client.complete(prompt="", model="gpt-4o", llm_api_key="sk-test-key")

    assert result["success"] is False
    assert result["error_code"] == "ACL_ERR_VALIDATION"


def test_client_context_manager():
    with ACLClient(api_key="acl_live-12345678") as client:
        assert isinstance(client, ACLClient)
