"""Workbench - lightweight multi-agent orchestrator."""

try:
    from workbench._version import version as __version__
except ImportError:
    __version__ = "0.0.0.dev0"
