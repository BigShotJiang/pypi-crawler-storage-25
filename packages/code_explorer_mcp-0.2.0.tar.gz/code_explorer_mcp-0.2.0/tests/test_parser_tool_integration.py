from __future__ import annotations

import asyncio
from dataclasses import FrozenInstanceError, asdict
from typing import Any, cast
from pathlib import Path

import pytest

from code_explorer_mcp.models import (
    FetchSymbolRequest,
    ParseFileRequest,
    ToolPlaceholderError,
)
from code_explorer_mcp.runtime_config import RuntimeConfig
from code_explorer_mcp.server import create_mcp_server
from code_explorer_mcp.tool_file_parse import parse_file
from code_explorer_mcp.tool_symbol_fetch import fetch_symbol

PYTHON_FILENAME = "tests/fixtures/python_sample.py"
TYPESCRIPT_FILENAME = "tests/fixtures/typescript_sample.ts"


@pytest.fixture
def runtime_config(pytestconfig: pytest.Config) -> RuntimeConfig:
    return RuntimeConfig(project_root=pytestconfig.rootpath)


def test_runtime_config_is_immutable() -> None:
    runtime_config = RuntimeConfig(project_root=Path("/tmp/original"))

    with pytest.raises(FrozenInstanceError):
        cast(Any, runtime_config).project_root = Path("/tmp/other")


def test_parse_file_routes_python_and_typescript_by_extension(
    runtime_config: RuntimeConfig,
) -> None:
    python_response = parse_file(
        ParseFileRequest(filename=PYTHON_FILENAME),
        runtime_config=runtime_config,
    )
    typescript_response = parse_file(
        ParseFileRequest(
            filename=TYPESCRIPT_FILENAME,
            content={"interfaces": True, "functions": True, "imports": False},
        ),
        runtime_config=runtime_config,
    )
    typescript_full_response = parse_file(
        ParseFileRequest(filename=TYPESCRIPT_FILENAME),
        runtime_config=runtime_config,
    )

    assert asdict(python_response) == {
        "filename": PYTHON_FILENAME,
        "language": "python",
        "available_symbol_types": ("imports", "globals", "classes", "functions"),
        "sections": {
            "imports": [
                {"module": "os", "name": None, "alias": None},
                {"module": "typing", "name": "Any", "alias": "TypingAny"},
                {"module": ".helpers", "name": "helper", "alias": "local_helper"},
            ],
            "globals": [
                {"name": "MY_GLOBAL"},
                {"name": "OTHER_GLOBAL"},
            ],
            "classes": [
                {
                    "name": "MyClass",
                    "members": [
                        {"name": "count"},
                        {"name": "label"},
                    ],
                    "methods": [
                        {"name": "my_method"},
                        {"name": "my_async_method"},
                    ],
                    "inner_classes": [
                        {
                            "name": "InnerClass",
                            "members": [{"name": "inner_value"}],
                            "methods": [],
                            "inner_classes": [],
                        }
                    ],
                }
            ],
            "functions": [{"name": "top_level_function"}],
        },
        "error": None,
    }
    assert asdict(typescript_response) == {
        "filename": TYPESCRIPT_FILENAME,
        "language": "typescript",
        "available_symbol_types": (
            "imports",
            "globals",
            "classes",
            "functions",
            "interfaces",
            "type_aliases",
            "enums",
            "re_exports",
        ),
        "sections": {
            "functions": [
                {"name": "namedFunction", "syntax": "function"},
                {"name": "arrowFunction", "syntax": "arrow"},
            ],
            "interfaces": [{"name": "MyInterface"}],
        },
        "error": None,
    }
    assert asdict(typescript_full_response) == {
        "filename": TYPESCRIPT_FILENAME,
        "language": "typescript",
        "available_symbol_types": (
            "imports",
            "globals",
            "classes",
            "functions",
            "interfaces",
            "type_aliases",
            "enums",
            "re_exports",
        ),
        "sections": {
            "imports": [
                {
                    "module": "./types",
                    "default": "Thing",
                    "namespace": None,
                    "named": ["Helper"],
                },
                {
                    "module": "./utils",
                    "default": None,
                    "namespace": "Utils",
                    "named": [],
                },
            ],
            "globals": [
                {"name": "TOP_LEVEL_CONST", "declaration_kind": "const"},
                {"name": "arrowFunction", "declaration_kind": "const"},
                {"name": "mutableValue", "declaration_kind": "let"},
            ],
            "classes": [
                {
                    "name": "MyClass",
                    "members": [{"name": "value"}],
                    "methods": [{"name": "run"}],
                    "accessors": [
                        {"name": "label", "kind": "getter"},
                        {"name": "label", "kind": "setter"},
                    ],
                    "inner_classes": [
                        {
                            "name": "InnerClass",
                            "members": [],
                            "methods": [{"name": "runInner"}],
                            "accessors": [],
                            "inner_classes": [],
                        }
                    ],
                }
            ],
            "functions": [
                {"name": "namedFunction", "syntax": "function"},
                {"name": "arrowFunction", "syntax": "arrow"},
            ],
            "interfaces": [{"name": "MyInterface"}],
            "type_aliases": [{"name": "MyType"}],
            "enums": [{"name": "MyEnum"}],
            "re_exports": [
                {"module": "./shared", "names": ["SharedThing"]},
                {"module": "./everything", "names": []},
            ],
        },
        "error": None,
    }


def test_parse_file_reports_invalid_request_for_unknown_symbol_type(
    runtime_config: RuntimeConfig,
) -> None:
    response = parse_file(
        ParseFileRequest(
            filename=TYPESCRIPT_FILENAME,
            content={"decorators": True},
        ),
        runtime_config=runtime_config,
    )

    assert response.error == ToolPlaceholderError(
        code="unsupported_request",
        message="Unknown symbol types requested: decorators",
    )


def test_parse_file_and_fetch_symbol_return_mcp_errors_for_file_read_failures(
    monkeypatch,
    runtime_config: RuntimeConfig,
) -> None:
    original_read_text = Path.read_text

    fixture_path = runtime_config.project_root / PYTHON_FILENAME

    def raise_read_error(path: Path, *, encoding: str = "utf-8") -> str:
        if path == fixture_path:
            raise OSError("Permission denied while reading fixture")
        return original_read_text(path, encoding=encoding)

    monkeypatch.setattr(Path, "read_text", raise_read_error)

    parse_response = parse_file(
        ParseFileRequest(filename=PYTHON_FILENAME),
        runtime_config=runtime_config,
    )
    fetch_response = fetch_symbol(
        FetchSymbolRequest(filename=PYTHON_FILENAME, symbol="MyClass"),
        runtime_config=runtime_config,
    )

    assert asdict(parse_response) == {
        "filename": PYTHON_FILENAME,
        "language": "unknown",
        "available_symbol_types": (),
        "sections": {},
        "error": {
            "code": "file_read_error",
            "message": (
                "Failed to read file tests/fixtures/python_sample.py: "
                "Permission denied while reading fixture"
            ),
        },
    }
    assert asdict(fetch_response) == {
        "filename": PYTHON_FILENAME,
        "language": "unknown",
        "symbol": "MyClass",
        "symbol_type": None,
        "code": None,
        "error": {
            "code": "file_read_error",
            "message": (
                "Failed to read file tests/fixtures/python_sample.py: "
                "Permission denied while reading fixture"
            ),
        },
    }


def test_fetch_symbol_routes_python_and_typescript_by_extension(
    runtime_config: RuntimeConfig,
) -> None:
    python_response = fetch_symbol(
        FetchSymbolRequest(filename=PYTHON_FILENAME, symbol="MyClass.my_async_method"),
        runtime_config=runtime_config,
    )
    typescript_response = fetch_symbol(
        FetchSymbolRequest(filename=TYPESCRIPT_FILENAME, symbol="MyEnum"),
        runtime_config=runtime_config,
    )

    assert asdict(python_response) == {
        "filename": PYTHON_FILENAME,
        "language": "python",
        "symbol": "MyClass.my_async_method",
        "symbol_type": "classes",
        "code": "async def my_async_method(self) -> str:\n        return self.label",
        "error": None,
    }
    assert asdict(typescript_response) == {
        "filename": TYPESCRIPT_FILENAME,
        "language": "typescript",
        "symbol": "MyEnum",
        "symbol_type": "enums",
        "code": 'export enum MyEnum {\n  Ready = "ready",\n}',
        "error": None,
    }


def test_fetch_symbol_returns_symbol_not_found_error(
    runtime_config: RuntimeConfig,
) -> None:
    response = fetch_symbol(
        FetchSymbolRequest(filename=TYPESCRIPT_FILENAME, symbol="Missing"),
        runtime_config=runtime_config,
    )

    assert asdict(response) == {
        "filename": TYPESCRIPT_FILENAME,
        "language": "typescript",
        "symbol": "Missing",
        "symbol_type": None,
        "code": None,
        "error": {
            "code": "symbol_not_found",
            "message": "Symbol not found: Missing",
        },
    }


def test_parse_file_exposes_only_one_level_of_python_inner_classes(
    tmp_path: Path,
    monkeypatch,
) -> None:
    runtime_root = tmp_path / "runtime-root"
    runtime_root.mkdir()
    fixture_path = runtime_root / "sample.py"
    fixture_path.write_text(
        "class Outer:\n    class Inner:\n        class TooDeep:\n            pass\n",
        encoding="utf-8",
    )
    runtime_config = RuntimeConfig(project_root=runtime_root)
    monkeypatch.chdir(tmp_path)

    response = parse_file(
        ParseFileRequest(filename="sample.py"),
        runtime_config=runtime_config,
    )

    assert asdict(response) == {
        "filename": "sample.py",
        "language": "python",
        "available_symbol_types": ("imports", "globals", "classes", "functions"),
        "sections": {
            "imports": [],
            "globals": [],
            "classes": [
                {
                    "name": "Outer",
                    "members": [],
                    "methods": [],
                    "inner_classes": [
                        {
                            "name": "Inner",
                            "members": [],
                            "methods": [],
                            "inner_classes": [],
                        }
                    ],
                }
            ],
            "functions": [],
        },
        "error": None,
    }


def test_parse_file_exposes_only_one_level_of_typescript_inner_classes(
    tmp_path: Path,
    monkeypatch,
) -> None:
    runtime_root = tmp_path / "runtime-root"
    runtime_root.mkdir()
    fixture_path = runtime_root / "sample.ts"
    fixture_path.write_text(
        "export class Outer {\n"
        "  Inner = class Inner {\n"
        "    TooDeep = class TooDeep {\n"
        "      run(): string {\n"
        '        return "ok";\n'
        "      }\n"
        "    };\n"
        "  };\n"
        "}\n",
        encoding="utf-8",
    )
    runtime_config = RuntimeConfig(project_root=runtime_root)
    monkeypatch.chdir(tmp_path)

    response = parse_file(
        ParseFileRequest(filename="sample.ts"),
        runtime_config=runtime_config,
    )

    assert asdict(response) == {
        "filename": "sample.ts",
        "language": "typescript",
        "available_symbol_types": (
            "imports",
            "globals",
            "classes",
            "functions",
            "interfaces",
            "type_aliases",
            "enums",
            "re_exports",
        ),
        "sections": {
            "imports": [],
            "globals": [],
            "classes": [
                {
                    "name": "Outer",
                    "members": [],
                    "methods": [],
                    "accessors": [],
                    "inner_classes": [
                        {
                            "name": "Inner",
                            "members": [],
                            "methods": [],
                            "accessors": [],
                            "inner_classes": [],
                        }
                    ],
                }
            ],
            "functions": [],
            "interfaces": [],
            "type_aliases": [],
            "enums": [],
            "re_exports": [],
        },
        "error": None,
    }


def test_fetch_symbol_omits_too_deep_typescript_inner_class_symbols(
    tmp_path: Path,
) -> None:
    runtime_root = tmp_path / "runtime-root"
    runtime_root.mkdir()
    fixture_path = runtime_root / "sample.ts"
    fixture_path.write_text(
        "export class Outer {\n"
        "  Inner = class Inner {\n"
        "    TooDeep = class TooDeep {\n"
        "      run(): string {\n"
        '        return "ok";\n'
        "      }\n"
        "    };\n"
        "  };\n"
        "}\n",
        encoding="utf-8",
    )
    runtime_config = RuntimeConfig(project_root=runtime_root)

    response = fetch_symbol(
        FetchSymbolRequest(filename="sample.ts", symbol="Outer.Inner.TooDeep"),
        runtime_config=runtime_config,
    )

    assert asdict(response) == {
        "filename": "sample.ts",
        "language": "typescript",
        "symbol": "Outer.Inner.TooDeep",
        "symbol_type": None,
        "code": None,
        "error": {
            "code": "symbol_not_found",
            "message": "Symbol not found: Outer.Inner.TooDeep",
        },
    }


def test_parse_and_fetch_use_supplied_runtime_config_instead_of_process_cwd(
    tmp_path: Path,
    monkeypatch,
) -> None:
    runtime_root = tmp_path / "runtime-root"
    runtime_root.mkdir()
    fixture_path = runtime_root / "sample.py"
    fixture_path.write_text("VALUE = 1\n", encoding="utf-8")
    runtime_config = RuntimeConfig(project_root=runtime_root)
    monkeypatch.chdir(tmp_path)

    parse_response = parse_file(
        ParseFileRequest(filename="sample.py"),
        runtime_config=runtime_config,
    )
    fetch_response = fetch_symbol(
        FetchSymbolRequest(filename="sample.py", symbol="VALUE"),
        runtime_config=runtime_config,
    )

    assert asdict(parse_response) == {
        "filename": "sample.py",
        "language": "python",
        "available_symbol_types": ("imports", "globals", "classes", "functions"),
        "sections": {
            "imports": [],
            "globals": [{"name": "VALUE"}],
            "classes": [],
            "functions": [],
        },
        "error": None,
    }
    assert asdict(fetch_response) == {
        "filename": "sample.py",
        "language": "python",
        "symbol": "VALUE",
        "symbol_type": "globals",
        "code": "VALUE = 1",
        "error": None,
    }


def test_fetch_symbol_handles_unicode_prefix_in_python_and_typescript(
    tmp_path: Path,
    monkeypatch,
) -> None:
    runtime_root = tmp_path / "runtime-root"
    runtime_root.mkdir()
    python_path = runtime_root / "unicode_sample.py"
    typescript_path = runtime_root / "unicode_sample.ts"
    python_path.write_text(
        'EMOJI = "😀"; VALUE = 1\n',
        encoding="utf-8",
    )
    typescript_path.write_text(
        'const emoji = "😀"; export function hello(): string { return "hi"; }\n',
        encoding="utf-8",
    )
    runtime_config = RuntimeConfig(project_root=runtime_root)
    monkeypatch.chdir(tmp_path)

    python_response = fetch_symbol(
        FetchSymbolRequest(filename="unicode_sample.py", symbol="VALUE"),
        runtime_config=runtime_config,
    )
    typescript_response = fetch_symbol(
        FetchSymbolRequest(filename="unicode_sample.ts", symbol="hello"),
        runtime_config=runtime_config,
    )

    assert asdict(python_response) == {
        "filename": "unicode_sample.py",
        "language": "python",
        "symbol": "VALUE",
        "symbol_type": "globals",
        "code": "VALUE = 1",
        "error": None,
    }
    assert asdict(typescript_response) == {
        "filename": "unicode_sample.ts",
        "language": "typescript",
        "symbol": "hello",
        "symbol_type": "functions",
        "code": 'export function hello(): string { return "hi"; }',
        "error": None,
    }


def test_servers_use_their_own_runtime_configs_without_global_mutation(
    tmp_path: Path,
) -> None:
    first_root = tmp_path / "first-root"
    second_root = tmp_path / "second-root"
    first_root.mkdir()
    second_root.mkdir()
    (first_root / "sample.py").write_text("FIRST = 1\n", encoding="utf-8")
    (second_root / "sample.py").write_text("SECOND = 2\n", encoding="utf-8")

    first_server = create_mcp_server(
        runtime_config=RuntimeConfig(project_root=first_root),
    )
    second_server = create_mcp_server(
        runtime_config=RuntimeConfig(project_root=second_root),
    )

    first_tool = asyncio.run(first_server.get_tool("parse_file"))
    second_tool = asyncio.run(second_server.get_tool("parse_file"))
    assert first_tool is not None
    assert second_tool is not None
    first_result = cast(Any, first_tool).fn(filename="sample.py")
    second_result = cast(Any, second_tool).fn(filename="sample.py")

    assert first_result == {"globals": ["FIRST"]}
    assert second_result == {"globals": ["SECOND"]}
