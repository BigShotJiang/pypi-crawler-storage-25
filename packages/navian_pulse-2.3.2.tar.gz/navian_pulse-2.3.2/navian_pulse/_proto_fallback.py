"""Minimal proto-compatible stubs for when grpc codegen isn't available.
Uses grpc reflection or manual message construction."""

import struct
from dataclasses import dataclass, field
from typing import Any


class Value:
    def __init__(self, number_value=None, string_value=None, bool_value=None, int_value=None):
        self.number_value = number_value
        self.string_value = string_value
        self.bool_value = bool_value
        self.int_value = int_value


class EventRequest:
    def __init__(self, entity_token="", event_type="", event_id="",
                 occurred_at_ms=0, payload=None, tenant_id="", send_mode=0, **kwargs):
        self.entity_token = entity_token
        self.event_type = event_type
        self.event_id = event_id
        self.occurred_at_ms = occurred_at_ms
        self.payload = payload or {}
        self.tenant_id = tenant_id
        self.send_mode = send_mode


class EventResponse:
    def __init__(self):
        self.event_id = ""
        self.response = ""
        self.persisted = False
        self.fired_rules = []
        self.score = 0.0
        self.latency_us = 0


class EventServiceStub:
    """Fallback stub that uses HTTP REST instead of gRPC."""

    def __init__(self, channel):
        self._target = getattr(channel, '_target', 'localhost:8080')
        # Extract host for HTTP fallback
        host = self._target.replace(':50051', ':8080')
        if not host.startswith('http'):
            host = f'http://{host}'
        self._http_base = host

    def SendEvent(self, request):
        import urllib.request
        import json

        payload = {}
        for k, v in request.payload.items():
            if v.number_value is not None:
                payload[k] = v.number_value
            elif v.int_value is not None:
                payload[k] = v.int_value
            elif v.bool_value is not None:
                payload[k] = v.bool_value
            elif v.string_value is not None:
                payload[k] = v.string_value

        body = json.dumps({
            "entity_token": request.entity_token,
            "event_type": request.event_type,
            "event_id": request.event_id,
            "occurred_at_ms": request.occurred_at_ms,
            "payload": payload,
        }).encode()

        req = urllib.request.Request(
            f"{self._http_base}/v1/events",
            data=body,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=5) as resp:
                data = json.loads(resp.read())
                r = EventResponse()
                r.event_id = data.get("event_id", request.event_id)
                # Engine's REST response uses "verdict"; gRPC schema uses "response".
                # Accept either so the SDK works against both transports.
                r.response = data.get("verdict") or data.get("response", "ALLOW")
                # Persistence is implied by a non-empty persist_hash on REST.
                r.persisted = bool(data.get("persist_hash")) or data.get("persisted", True)
                # fired_rules may arrive as list (correct, post-fix engine), as a
                # comma-separated string (older engine builds joined the array),
                # or as an empty string. Normalize to list[str].
                fr = data.get("fired_rules", [])
                if isinstance(fr, str):
                    fr = [s for s in fr.split(",") if s]
                elif not isinstance(fr, list):
                    fr = []
                r.fired_rules = fr
                r.score = float(data.get("score", 0.0))
                r.latency_us = int(data.get("latency_us", 0))
                return r
        except Exception as e:
            r = EventResponse()
            r.event_id = request.event_id
            r.response = f"ERROR: {e}"
            return r
