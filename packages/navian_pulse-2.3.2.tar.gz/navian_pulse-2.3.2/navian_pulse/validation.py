"""Event validation against TOML configuration.

Validates events before they're sent to the engine:
1. event_type must be in known_types
2. entity_token must be non-empty
3. Required payload fields (Sum/Distribution sources) must be present
4. Payload values must be the right type for their field definition
"""

from dataclasses import dataclass
from typing import Any

from .config import PulseConfig
from .event import NavianEvent


@dataclass
class ValidationResult:
    valid: bool
    errors: list[str]
    warnings: list[str]


def validate_event(event: NavianEvent, config: PulseConfig) -> ValidationResult:
    errors: list[str] = []
    warnings: list[str] = []

    # 1. Entity token
    if not event.entity_token or not event.entity_token.strip():
        errors.append("entity_token is required and must be non-empty")

    # 2. Event type
    if not event.event_type or not event.event_type.strip():
        errors.append("event_type is required and must be non-empty")
    else:
        errors.extend(config.validate_event_type(event.event_type))

    # 3. Required payload fields (from Sum/Distribution field definitions)
    if event.event_type:
        errors.extend(config.validate_payload(event.event_type, event.payload))

    # 4. Timestamp sanity
    if event.occurred_at_ms <= 0:
        errors.append("occurred_at_ms must be positive")
    elif event.occurred_at_ms < 1_000_000_000_000:
        warnings.append("occurred_at_ms looks like seconds, not milliseconds")

    # 5. Payload type checks — only for sources that EVERY using field requires
    # to be numeric. CardinalityHLL/Set/Flag fields accept strings, so don't
    # warn when a string source legitimately feeds one of those alongside (or
    # instead of) a numeric aggregator.
    numeric_required = config.numeric_required_sources(event.event_type)
    for field_name in numeric_required:
        if field_name in event.payload:
            val = event.payload[field_name]
            if not isinstance(val, (int, float)) or isinstance(val, bool):
                warnings.append(
                    f"Payload field '{field_name}' is type {type(val).__name__}, "
                    f"expected numeric (used as Sum/Distribution source)"
                )

    # 6. Event ID
    if not event.event_id:
        warnings.append("event_id is empty — engine may reject as duplicate")

    return ValidationResult(
        valid=len(errors) == 0,
        errors=errors,
        warnings=warnings,
    )


def validate_batch(events: list[NavianEvent], config: PulseConfig) -> list[ValidationResult]:
    return [validate_event(e, config) for e in events]
