"""NavianClient — gRPC client for sending events to Pulse.

Usage:
    from navian_pulse import NavianClient, PulseConfig
    from navian_pulse.generated_events import PulseEventFactory, CashDepositEvent

    config = PulseConfig.from_toml_file("config/fraud-comprehensive.toml")
    client = NavianClient("localhost:50051", config)

    # Type-checked at edit time — IDE catches wrong fields
    event = PulseEventFactory.cash_deposit(entity_token="cust-001", amount=9400.0)
    response = client.send(event)
"""

import logging
from typing import Any

import grpc

from .config import PulseConfig
from .event import NavianEvent
from .validation import validate_event, ValidationResult
from .field_protector import NavianFieldProtector, ProtectionMode

logger = logging.getLogger("navian_pulse")


class SendResult:
    def __init__(self, event_id: str, response: str, persisted: bool,
                 fired_rules: list[str], score: float, latency_us: int):
        self.event_id = event_id
        self.response = response
        self.persisted = persisted
        self.fired_rules = fired_rules
        self.score = score
        self.latency_us = latency_us

    def __repr__(self) -> str:
        return (f"SendResult(event_id={self.event_id!r}, response={self.response!r}, "
                f"rules={len(self.fired_rules)}, score={self.score:.2f})")


class ValidationError(Exception):
    def __init__(self, errors: list[str], warnings: list[str]):
        self.errors = errors
        self.warnings = warnings
        super().__init__(f"Event validation failed: {'; '.join(errors)}")


class NavianClient:
    def __init__(
        self,
        endpoint: str,
        config: PulseConfig,
        *,
        protector: NavianFieldProtector | None = None,
        validate: bool = True,
        fail_on_warning: bool = False,
        insecure: bool = True,
    ):
        self._endpoint = endpoint
        self._config = config
        self._protector = protector
        self._validate = validate
        self._fail_on_warning = fail_on_warning

        # Lazy gRPC init
        self._channel: grpc.Channel | None = None
        self._stub: Any = None
        self._insecure = insecure

    def _ensure_connected(self) -> None:
        if self._stub is not None:
            return

        # Prefer the bundled gRPC stubs (navian.v1.* — generated from
        # proto/navian/v1/*.proto and shipped in the wheel). Fall back to the
        # legacy navian_v1 layout if a customer pinned to that, then to the
        # HTTP-REST fallback as a last resort. Value lives in common.proto
        # under the real schema; the fallback stub provides its own Value.
        try:
            from navian.v1 import events_pb2, events_pb2_grpc, common_pb2
            self._pb2 = events_pb2
            self._pb2_grpc = events_pb2_grpc
            self._value_factory = common_pb2.Value
        except ImportError:
            try:
                from navian_v1 import events_pb2, events_pb2_grpc
                self._pb2 = events_pb2
                self._pb2_grpc = events_pb2_grpc
                # Old layout had Value re-exported from events_pb2
                self._value_factory = getattr(events_pb2, "Value", None)
                if self._value_factory is None:
                    from navian_v1 import common_pb2
                    self._value_factory = common_pb2.Value
            except ImportError:
                from . import _proto_fallback as fallback
                self._pb2 = fallback
                self._pb2_grpc = fallback
                self._value_factory = fallback.Value

        if self._insecure:
            self._channel = grpc.insecure_channel(self._endpoint)
        else:
            self._channel = grpc.secure_channel(
                self._endpoint, grpc.ssl_channel_credentials()
            )

        self._stub = self._pb2_grpc.EventServiceStub(self._channel)
        logger.info("Connected to %s", self._endpoint)

    def send(self, event: Any) -> SendResult:
        """Send a single event. Validates against TOML config before sending.

        Accepts either a NavianEvent or a generated typed event (with .to_dict()).
        """
        if hasattr(event, 'to_dict'):
            d = event.to_dict()
            nav_event = NavianEvent(
                event_type=d["event_type"],
                entity_token=d["entity_token"],
                event_id=d.get("event_id", ""),
                occurred_at_ms=d.get("occurred_at_ms", 0),
                payload=d.get("payload", {}),
            )
        elif isinstance(event, NavianEvent):
            nav_event = event
        else:
            raise TypeError(f"Expected NavianEvent or typed event, got {type(event)}")

        # Validate before sending
        if self._validate:
            result = validate_event(nav_event, self._config)
            if not result.valid:
                raise ValidationError(result.errors, result.warnings)
            if result.warnings:
                if self._fail_on_warning:
                    raise ValidationError(result.warnings, [])
                for w in result.warnings:
                    logger.warning("Event validation warning: %s", w)

        # Apply field protection
        if self._protector:
            nav_event = NavianEvent(
                event_type=nav_event.event_type,
                entity_token=self._protector.protect_entity_token(nav_event.entity_token),
                event_id=nav_event.event_id,
                occurred_at_ms=nav_event.occurred_at_ms,
                payload={
                    k: self._protector.protect_field(k, str(v))
                    for k, v in nav_event.payload.items()
                },
            )

        self._ensure_connected()
        return self._send_grpc(nav_event)

    def send_batch(self, events: list[Any]) -> list[SendResult]:
        results = []
        for event in events:
            results.append(self.send(event))
        return results

    def close(self) -> None:
        if self._channel:
            self._channel.close()
            self._channel = None
            self._stub = None

    def __enter__(self) -> "NavianClient":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    def _send_grpc(self, event: NavianEvent) -> SendResult:
        payload = {}
        for k, v in event.payload.items():
            if isinstance(v, bool):
                payload[k] = self._value_factory(bool_value=v)
            elif isinstance(v, int):
                payload[k] = self._value_factory(int_value=v)
            elif isinstance(v, float):
                payload[k] = self._value_factory(number_value=v)
            else:
                payload[k] = self._value_factory(string_value=str(v))

        req = self._pb2.EventRequest(
            entity_token=event.entity_token,
            event_type=event.event_type,
            event_id=event.event_id,
            occurred_at_ms=event.occurred_at_ms,
            payload=payload,
            tenant_id=self._config.tenant_id,
            send_mode=1,  # ACKNOWLEDGED
        )

        resp = self._stub.SendEvent(req)
        return SendResult(
            event_id=resp.event_id,
            response=resp.response,
            persisted=resp.persisted,
            fired_rules=list(resp.fired_rules),
            score=resp.score,
            latency_us=resp.latency_us,
        )
