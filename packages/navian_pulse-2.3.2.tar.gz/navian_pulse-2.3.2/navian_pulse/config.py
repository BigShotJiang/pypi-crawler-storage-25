"""TOML configuration loader — syncs the SDK with the engine's config file.

Parses known_types, field definitions (with source requirements),
agent scopes, and policies from the same TOML the engine uses.
This is the validation source of truth.
"""

from dataclasses import dataclass, field
from typing import Any
import tomllib
from pathlib import Path


@dataclass
class FieldDef:
    id: str
    field_type: str
    set_on: list[str] = field(default_factory=list)
    source: str | None = None
    window: str | None = None


@dataclass
class PolicyDef:
    id: str
    condition: str
    action: str
    severity: str = "MEDIUM"


@dataclass
class WorkflowDef:
    id: str
    name: str
    stages: list[str] = field(default_factory=list)


@dataclass
class AgentScope:
    read: list[str] = field(default_factory=list)
    write: list[str] = field(default_factory=list)
    deny: list[str] = field(default_factory=list)


@dataclass
class PulseConfig:
    """Parsed TOML configuration — everything the SDK needs to validate events."""

    tenant_id: str = ""
    tenant_name: str = ""
    known_types: list[str] = field(default_factory=list)
    fields: list[FieldDef] = field(default_factory=list)
    policies: list[PolicyDef] = field(default_factory=list)
    workflows: list[WorkflowDef] = field(default_factory=list)
    agent_scopes: dict[str, AgentScope] = field(default_factory=dict)

    # Derived lookup tables (built on load)
    _fields_by_event: dict[str, list[FieldDef]] = field(default_factory=dict, repr=False)
    _required_sources: dict[str, set[str]] = field(default_factory=dict, repr=False)

    @classmethod
    def from_toml_file(cls, path: str | Path) -> "PulseConfig":
        with open(path, "rb") as f:
            raw = tomllib.load(f)
        return cls.from_dict(raw)

    @classmethod
    def from_toml_string(cls, s: str) -> "PulseConfig":
        raw = tomllib.loads(s)
        return cls.from_dict(raw)

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "PulseConfig":
        cfg = cls()

        tenant = raw.get("tenant", {})
        cfg.tenant_id = tenant.get("id", "")
        cfg.tenant_name = tenant.get("name", "")

        events = raw.get("events", {})
        cfg.known_types = events.get("known_types", [])

        for fd in raw.get("field", []):
            cfg.fields.append(FieldDef(
                id=fd["id"],
                field_type=fd.get("field_type", "Counter"),
                set_on=fd.get("set_on", []),
                source=fd.get("source"),
                window=fd.get("window"),
            ))

        for pd in raw.get("policy", []):
            cfg.policies.append(PolicyDef(
                id=pd["id"],
                condition=pd.get("condition", ""),
                action=pd.get("action", "REVIEW"),
                severity=pd.get("severity", "MEDIUM"),
            ))

        for wd in raw.get("workflow", []):
            cfg.workflows.append(WorkflowDef(
                id=wd["id"],
                name=wd.get("name", wd["id"]),
                stages=wd.get("stages", []),
            ))

        for agent_id, scope in raw.get("agent_scopes", {}).items():
            cfg.agent_scopes[agent_id] = AgentScope(
                read=scope.get("read", []),
                write=scope.get("write", []),
                deny=scope.get("deny", []),
            )

        cfg._build_lookup_tables()
        return cfg

    # Field types whose source must be numeric (Sum, Distribution, drift, etc.).
    # Types not listed here accept non-numeric sources — CardinalityHLL counts
    # distinct strings, Set stores strings, Flag is boolean.
    _NUMERIC_FIELD_TYPES = frozenset({
        "Sum", "Average", "WelfordStat",
        "Distribution", "Lognormal", "Poisson", "Beta", "ExponentialDecay",
        "CUSUM", "MultivariateCUSUM", "PageHinkley",
        "Rate", "DDSketch", "Ema",
        "TrajectorySlope", "IsolationForest",
    })

    def _build_lookup_tables(self) -> None:
        self._fields_by_event = {}
        self._required_sources = {}

        for fd in self.fields:
            for et in fd.set_on:
                self._fields_by_event.setdefault(et, []).append(fd)
                if fd.source:
                    self._required_sources.setdefault(et, set()).add(fd.source)

    def numeric_required_sources(self, event_type: str) -> set[str]:
        """Sources that EVERY using field requires to be numeric.

        If even one CardinalityHLL/Set/Flag field shares the same source on
        this event, the value can legitimately be a string and we don't warn.
        """
        fields_for_event = self._fields_by_event.get(event_type, [])
        # Group fields by source on this event
        source_to_types: dict[str, set[str]] = {}
        for fd in fields_for_event:
            if fd.source:
                source_to_types.setdefault(fd.source, set()).add(fd.field_type)
        return {
            src for src, types in source_to_types.items()
            if types and all(t in self._NUMERIC_FIELD_TYPES for t in types)
        }

    def required_payload_fields(self, event_type: str) -> set[str]:
        """Return the set of payload field names required for this event type.
        These are the `source` fields from field definitions that trigger on this event."""
        return self._required_sources.get(event_type, set())

    def is_known_type(self, event_type: str) -> bool:
        if not self.known_types:
            return True
        return event_type in self.known_types

    def validate_event_type(self, event_type: str) -> list[str]:
        errors = []
        if self.known_types and event_type not in self.known_types:
            errors.append(
                f"event_type '{event_type}' not in known_types. "
                f"Valid types: {', '.join(sorted(self.known_types))}"
            )
        return errors

    def validate_payload(self, event_type: str, payload: dict[str, Any]) -> list[str]:
        errors = []
        required = self.required_payload_fields(event_type)
        for field_name in required:
            if field_name not in payload:
                errors.append(
                    f"Missing required payload field '{field_name}' for event_type "
                    f"'{event_type}' (needed by Sum/Distribution field)"
                )
            elif payload[field_name] is None:
                errors.append(
                    f"Payload field '{field_name}' is None for event_type '{event_type}'"
                )
        return errors
