from __future__ import annotations

from typing import Any, Optional

import httpx


class AcrossedError(Exception):
    def __init__(self, message: str, status: int, body: Any = None):
        super().__init__(message)
        self.status = status
        self.body = body


class AcrossedBilling:
    """Official Acrossed Billing API client."""

    def __init__(
        self,
        base_url: str,
        *,
        api_key: Optional[str] = None,
        clerk_user_id: Optional[str] = None,
        clerk_email: Optional[str] = None,
        clerk_name: Optional[str] = None,
        timeout: float = 30.0,
    ):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.clerk_user_id = clerk_user_id
        self.clerk_email = clerk_email
        self.clerk_name = clerk_name
        self.timeout = timeout

    def _headers(self, auth: bool = True) -> dict[str, str]:
        headers = {"Content-Type": "application/json"}
        if not auth:
            return headers
        if self.api_key:
            token = self.api_key if self.api_key.startswith("Bearer ") else f"Bearer {self.api_key}"
            headers["Authorization"] = token
        if self.clerk_user_id:
            headers["X-Clerk-User-Id"] = self.clerk_user_id
            if self.clerk_email:
                headers["X-Clerk-Email"] = self.clerk_email
            if self.clerk_name:
                headers["X-Clerk-Name"] = self.clerk_name
        return headers

    def _request(
        self,
        method: str,
        path: str,
        *,
        json: Any = None,
        auth: bool = True,
    ) -> Any:
        with httpx.Client(timeout=self.timeout) as client:
            res = client.request(
                method,
                f"{self.base_url}{path}",
                headers=self._headers(auth),
                json=json,
            )
        if res.status_code >= 400:
            try:
                body = res.json()
                msg = body.get("error", res.reason_phrase) if isinstance(body, dict) else res.text
            except Exception:
                body = res.text
                msg = res.reason_phrase
            raise AcrossedError(str(msg), res.status_code, body)
        if res.status_code == 204:
            return None
        return res.json()

    def health(self) -> dict[str, Any]:
        return self._request("GET", "/health", auth=False)

    def merchant_me(self) -> dict[str, Any]:
        return self._request("GET", "/v1/merchants/me")

    def create_merchant(self, business_name: str, slug: str | None = None) -> dict[str, Any]:
        return self._request("POST", "/v1/merchants", json={"business_name": business_name, "slug": slug})

    def metrics_overview(self) -> dict[str, Any]:
        return self._request("GET", "/v1/metrics/overview")

    def list_products(self) -> list[dict[str, Any]]:
        return self._request("GET", "/v1/products").get("items", [])

    def create_product(self, **kwargs: Any) -> dict[str, Any]:
        return self._request("POST", "/v1/products", json=kwargs)

    def list_customers(self) -> list[dict[str, Any]]:
        return self._request("GET", "/v1/customers").get("items", [])

    def create_customer(self, email: str, name: str = "", phone: str = "") -> dict[str, Any]:
        return self._request("POST", "/v1/customers", json={"email": email, "name": name, "phone": phone})

    def list_payment_links(self) -> list[dict[str, Any]]:
        data = self._request("GET", "/v1/payment-links")
        return data if isinstance(data, list) else data.get("items", [])

    def create_payment_link(self, **kwargs: Any) -> dict[str, Any]:
        return self._request("POST", "/v1/payment-links", json=kwargs)

    def create_checkout_session(self, **kwargs: Any) -> dict[str, Any]:
        return self._request("POST", "/v1/checkout/sessions", json=kwargs, auth=False)

    def list_orders(self) -> list[dict[str, Any]]:
        return self._request("GET", "/v1/orders").get("items", [])

    def list_transactions(self) -> list[dict[str, Any]]:
        return self._request("GET", "/v1/transactions").get("items", [])

    def list_subscriptions(self) -> list[dict[str, Any]]:
        return self._request("GET", "/v1/subscriptions").get("items", [])

    def create_subscription(self, **kwargs: Any) -> dict[str, Any]:
        return self._request("POST", "/v1/subscriptions", json=kwargs)

    def cancel_subscription(self, subscription_id: str) -> dict[str, Any]:
        return self._request("POST", f"/v1/subscriptions/{subscription_id}/cancel")

    def list_invoices(self) -> list[dict[str, Any]]:
        return self._request("GET", "/v1/invoices").get("items", [])

    def create_invoice(self, **kwargs: Any) -> dict[str, Any]:
        return self._request("POST", "/v1/invoices", json=kwargs)

    def list_discounts(self) -> list[dict[str, Any]]:
        return self._request("GET", "/v1/discounts").get("items", [])

    def create_api_key(self, name: str, scopes: str = "read,write") -> dict[str, Any]:
        return self._request("POST", "/v1/api-keys", json={"name": name, "scopes": scopes})
