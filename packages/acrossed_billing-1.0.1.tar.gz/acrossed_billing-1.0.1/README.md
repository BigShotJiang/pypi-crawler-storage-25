# acrossed-billing

Official Python SDK for Acrossed Billing.

## Install

```bash
pip install acrossed-billing
```

## Quick start

```python
from acrossed_billing import AcrossedBilling

client = AcrossedBilling(
    base_url="https://api.billing.acrossed.com",
    api_key="acx_your_key_here",
)

merchant = client.merchant_me()
links = client.list_payment_links()
```

## Automated releases

PyPI publishes are automated from GitHub Releases when `PYPI_API_TOKEN` is configured in repository secrets.
