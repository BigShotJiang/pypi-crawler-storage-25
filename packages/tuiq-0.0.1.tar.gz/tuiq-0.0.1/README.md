# tuiq

A fast, state-aware Terminal User Interface library. (Work in Progress)
