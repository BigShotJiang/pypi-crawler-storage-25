"""WhatsApp skill package for Zafiro."""

__all__ = ["register_whatsapp_skill", "register_whatsapp_tools"]


def register_whatsapp_skill(*args, **kwargs):
	from zafiro_skill_whatsapp.extensions.skills.whatsapp import register_whatsapp_skill as _impl

	return _impl(*args, **kwargs)


def register_whatsapp_tools(*args, **kwargs):
	from zafiro_skill_whatsapp.extensions.tools.whatsapp_tools import register_whatsapp_tools as _impl

	return _impl(*args, **kwargs)
