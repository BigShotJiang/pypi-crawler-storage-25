"""WhatsApp runtime admin helpers (start/stop/recover the channel, actor inspection).

Extracted from app.admin — the core app has no hardcoded WhatsApp knowledge.
These helpers are exposed via this package so any interface (chat REPL, REST API,
automation scripts) can drive the WhatsApp channel without the core knowing about it.
"""

from __future__ import annotations

import os
import signal
from datetime import datetime
from pathlib import Path
import time

_WA_PIDFILE = Path("logs/whatsapp.pid")
_WA_LOG = Path("logs/whatsapp.log")
_WA_QR = Path("logs/whatsapp_qr.png")


def _normalize_whatsapp_actor_id(external_user_id: str) -> str:
    from zafiro_skill_whatsapp.adapters.whatsapp.contacts import normalize_whatsapp_target

    return normalize_whatsapp_target(external_user_id)


def wa_is_running() -> bool:
    """True if WhatsApp is alive — either in-process thread or external PID."""
    try:
        from zafiro_skill_whatsapp.adapters.whatsapp import is_connected
        if is_connected():
            return True
    except Exception:
        pass

    runtime = None
    try:
        from zafiro_skill_whatsapp.adapters.whatsapp.runtime_ops.state import runtime as wa_runtime

        runtime = wa_runtime
    except Exception:
        runtime = None

    if not _WA_PIDFILE.exists():
        return False
    try:
        pid = int(_WA_PIDFILE.read_text().strip())
        if pid == os.getpid():
            if runtime is None:
                return False
            return runtime.connected.is_set() or runtime.client is not None
        os.kill(pid, 0)
        return True
    except (ProcessLookupError, ValueError, OSError):
        _WA_PIDFILE.unlink(missing_ok=True)
        return False


def _stop_external_wa() -> str | None:
    """SIGTERM the scripts/start.sh external process if its PID file exists and differs from ours."""
    if not _WA_PIDFILE.exists():
        return None
    try:
        pid = int(_WA_PIDFILE.read_text().strip())
    except (ValueError, OSError):
        return None
    if pid == os.getpid():
        return None
    try:
        os.kill(pid, 0)
    except (ProcessLookupError, OSError):
        _WA_PIDFILE.unlink(missing_ok=True)
        return None
    try:
        os.kill(pid, signal.SIGTERM)
        _WA_PIDFILE.unlink(missing_ok=True)
        return f"Proceso externo de WhatsApp (pid={pid}) detenido para evitar conflicto de sesión."
    except Exception as e:
        return f"No se pudo detener proceso externo (pid={pid}): {e}"


def wa_start() -> str:
    """Launch WhatsApp client in a background thread."""
    from zafiro_skill_whatsapp.adapters.whatsapp import is_connected, start_in_thread
    if is_connected():
        return "WhatsApp ya está conectado en este proceso."

    _WA_LOG.parent.mkdir(parents=True, exist_ok=True)

    notice = _stop_external_wa()
    import time
    if notice:
        time.sleep(1)

    start_in_thread()
    _WA_PIDFILE.write_text(str(os.getpid()))

    parts = ["WhatsApp iniciando en segundo plano."]
    if notice:
        parts.append(notice)
    parts.append(
        "Si es la primera vez, el QR se abrirá en Preview — escanéalo con tu teléfono. "
        "Espera unos segundos y luego pide al agente que reintente."
    )
    return " ".join(parts)


def wa_stop() -> str:
    """Stop the WhatsApp subprocess or disconnect in-process client."""
    from zafiro_skill_whatsapp.adapters.whatsapp import disconnect, is_connected
    if is_connected():
        try:
            disconnect()
        except Exception as e:
            return f"Error al desconectar WhatsApp: {e}"
        _WA_PIDFILE.unlink(missing_ok=True)
        return "WhatsApp desconectado."
    if not wa_is_running():
        _WA_PIDFILE.unlink(missing_ok=True)
        return "WhatsApp no estaba corriendo."
    try:
        pid = int(_WA_PIDFILE.read_text().strip())
        os.kill(pid, signal.SIGTERM)
        _WA_PIDFILE.unlink(missing_ok=True)
        return f"WhatsApp detenido (pid={pid})."
    except Exception as e:
        return f"Error al detener WhatsApp: {e}"


def _whatsapp_session_store_path() -> Path:
    try:
        from zafiro_skill_whatsapp.adapters.whatsapp.runtime_ops.config import WHATSAPP_SESSION_NAME
        return Path(WHATSAPP_SESSION_NAME).expanduser()
    except Exception:
        return Path("data/whatsapp/ia_orchestrator")


def wa_recover(*, reset_session: bool = False) -> str:
    """Recover WhatsApp from readonly sqlite/session issues and restart channel."""
    session_db = _whatsapp_session_store_path()
    session_dir = session_db.parent
    lines: list[str] = []

    lines.append(f"Deteniendo WhatsApp: {wa_stop()}")

    try:
        session_dir.mkdir(parents=True, exist_ok=True)
        os.chmod(session_dir, 0o700)
        lines.append(f"Permisos aplicados al directorio: {session_dir}")
    except Exception as error:
        lines.append(f"Aviso: no se pudieron ajustar permisos del directorio ({session_dir}): {error}")

    if reset_session and session_db.exists():
        backup_path = session_db.with_name(f"{session_db.name}.bak.{datetime.now().strftime('%Y%m%d%H%M%S')}")
        try:
            session_db.replace(backup_path)
            lines.append(f"Sesión respaldada: {backup_path}")
        except Exception as error:
            lines.append(f"Aviso: no se pudo respaldar la sesión ({session_db}): {error}")
    elif session_db.exists():
        try:
            os.chmod(session_db, 0o600)
            lines.append(f"Permisos aplicados al archivo de sesión: {session_db}")
        except Exception as error:
            lines.append(f"Aviso: no se pudieron ajustar permisos del archivo ({session_db}): {error}")

    for suffix in ("-wal", "-shm"):
        sidecar = Path(f"{session_db}{suffix}")
        if sidecar.exists():
            try:
                sidecar.unlink()
                lines.append(f"Eliminado: {sidecar}")
            except Exception as error:
                lines.append(f"Aviso: no se pudo eliminar {sidecar}: {error}")

    _WA_PIDFILE.unlink(missing_ok=True)
    lines.append("PID de WhatsApp limpiado.")
    lines.append(f"Reinicio de WhatsApp: {wa_start()}")

    if reset_session:
        lines.append(
            "Modo reset activado: escanea el QR nuevamente desde WhatsApp -> Dispositivos vinculados -> Vincular dispositivo."
        )

    return "\n".join(lines)


def wa_sync_full(
    *,
    count_per_chat: int = 200,
    max_chats: int = 100,
    wait_seconds: int = 8,
) -> str:
    """Run best-effort deep synchronization for contacts/groups/history/media."""
    from zafiro_skill_whatsapp.adapters.whatsapp.sync_ops.orchestrator import sync_all_whatsapp_data

    return sync_all_whatsapp_data(
        count_per_chat=count_per_chat,
        max_chats=max_chats,
        wait_seconds=wait_seconds,
    )


def wa_sync_all(
    *,
    rounds: int = 6,
    count_per_chat: int = 200,
    max_chats: int = 100,
    wait_seconds: int = 8,
) -> str:
    """Run multi-round best-effort synchronization with early stop on idle rounds."""
    from zafiro_skill_whatsapp.adapters.whatsapp.sync_ops.orchestrator import sync_all_whatsapp_data_multi

    return sync_all_whatsapp_data_multi(
        rounds=rounds,
        count_per_chat=count_per_chat,
        max_chats=max_chats,
        wait_seconds=wait_seconds,
    )


def wa_sync_auto_validate(
    *,
    max_rounds: int = 12,
    wait_seconds: int = 8,
    connect_timeout_seconds: int = 25,
    force_remote: bool = False,
    preferred_chat_jids: list[str] | None = None,
) -> str:
    """Run adaptive deep sync + automatic local history validation.

    This command attempts to connect WhatsApp automatically when disconnected,
    so users can run a single command without tuning parameters manually.
    """
    from zafiro_skill_whatsapp.adapters.whatsapp import is_connected
    from zafiro_skill_whatsapp.adapters.whatsapp.sync_ops.orchestrator import sync_all_whatsapp_data_auto_validate

    lines: list[str] = []
    if not is_connected():
        lines.append(f"Auto-start WhatsApp: {wa_start()}")
        timeout_at = time.time() + max(5, min(int(connect_timeout_seconds), 60))
        while time.time() < timeout_at:
            if is_connected():
                break
            time.sleep(1)
        if not is_connected():
            lines.append(
                "No se logró conectar WhatsApp automáticamente dentro del tiempo esperado. "
                "Si aparece QR pendiente, escanéalo y vuelve a ejecutar 'wa sync auto'."
            )
            return "\n".join(lines)

    result = sync_all_whatsapp_data_auto_validate(
        max_rounds=max_rounds,
        wait_seconds=wait_seconds,
        force_remote=force_remote,
        preferred_chat_jids=preferred_chat_jids,
    )
    if lines:
        lines.append(result)
        return "\n".join(lines)
    return result


def wa_sync_auto_read_archive(
    *,
    target: str = "Zafiro",
    limit: int = 50,
    max_rounds: int = 12,
    wait_seconds: int = 8,
) -> str:
    """Run sync-auto and then read archived messages for a target in one step."""
    from zafiro_skill_whatsapp.adapters.whatsapp import normalize_group_jid, resolve_contact, resolve_group
    from zafiro_skill_whatsapp.extensions.tools.whatsapp_tools_messaging import _read_whatsapp_archive
    from zafiro_skill_whatsapp.integrations import normalize_external_user_id

    safe_target = (target or "").strip() or "Zafiro"
    safe_limit = max(1, min(int(limit), 200))
    preferred_chat_jids: list[str] = []

    group = resolve_group(safe_target)
    if group is not None:
        group_jid = str(group.get("jid") or "").strip()
        if group_jid:
            preferred_chat_jids.append(group_jid)
    else:
        lower_target = safe_target.lower()
        if lower_target.endswith("@g.us"):
            normalized_group_jid = normalize_group_jid(safe_target)
            if normalized_group_jid:
                preferred_chat_jids.append(normalized_group_jid)
        elif lower_target.endswith("@s.whatsapp.net"):
            preferred_chat_jids.append(safe_target)
        else:
            contact = resolve_contact(safe_target)
            if contact is not None:
                normalized_phone = normalize_external_user_id(str(contact.get("phone") or ""))
                if normalized_phone:
                    preferred_chat_jids.append(f"{normalized_phone}@s.whatsapp.net")
            else:
                normalized_phone = normalize_external_user_id(safe_target)
                if normalized_phone:
                    preferred_chat_jids.append(f"{normalized_phone}@s.whatsapp.net")

    lines = [
        "One-shot WhatsApp (sync + read archive) iniciado:",
        f"- target={safe_target} limit={safe_limit} max_rounds={max_rounds} wait_seconds={wait_seconds}",
    ]
    if preferred_chat_jids:
        lines.append(f"- preferred_chat_jid={preferred_chat_jids[0]}")
    lines.append(
        wa_sync_auto_validate(
            max_rounds=max_rounds,
            wait_seconds=wait_seconds,
            force_remote=bool(preferred_chat_jids),
            preferred_chat_jids=preferred_chat_jids or None,
        )
    )
    lines.append(f"Lectura archive ({safe_target}|{safe_limit}):")
    lines.append(_read_whatsapp_archive(f"{safe_target}|{safe_limit}"))
    return "\n".join(lines)


def describe_whatsapp_actor(external_user_id: str) -> str:
    """Show the linked rule and effective runtime profile for a WhatsApp number."""
    from zafiro_skill_whatsapp.integrations import get_active_agents, get_user_agent_access

    normalized_user = _normalize_whatsapp_actor_id(external_user_id)
    if not normalized_user:
        return "Target de WhatsApp inválido (usa número o JID @g.us)."

    agents_by_name = {agent.get("name"): agent for agent in get_active_agents()}
    access = get_user_agent_access("whatsapp", normalized_user)

    is_group = normalized_user.endswith("@g.us")

    lines = [f"WhatsApp actor: {normalized_user}"]
    if is_group:
        lines.append("  tipo: group")
    else:
        lines.append("  tipo: contact")

    default_agent = None
    if access:
        default_agent_name = access.get("default_agent_name") or ""
        default_agent = agents_by_name.get(default_agent_name) or ({"name": default_agent_name} if default_agent_name else None)
        allowed_names = list(access.get("allowed_agent_names") or [])
        lines.append(f"  linked_default_agent: {default_agent['name'] if default_agent else '(sin default)'}")
        lines.append(f"  linked_allowed_agents: {', '.join(allowed_names) if allowed_names else '(vacío)'}")
    else:
        lines.append("  linked_default_agent: (sin regla explícita)")
        lines.append("  linked_allowed_agents: (sin regla explícita)")

    if is_group and default_agent:
        lines.append(f"  effective_mode: grupo vinculado ({default_agent['name']})")
    elif default_agent:
        lines.append(f"  effective_mode: agente vinculado por regla ({default_agent['name']})")
    elif access:
        lines.append("  effective_mode: agente vinculado por regla")
    else:
        lines.append("  effective_mode: sin auto-reply vinculado")
    return "\n".join(lines)


def auto_connect_whatsapp() -> None:
    """If an external WhatsApp process is alive, take it over in-thread automatically."""
    try:
        from zafiro_skill_whatsapp.adapters.whatsapp import is_connected
        if is_connected():
            return
    except Exception:
        return

    pidfile = Path("logs/whatsapp.pid")
    if not pidfile.exists():
        return

    try:
        pid = int(pidfile.read_text().strip())
        if pid == os.getpid():
            return
        os.kill(pid, 0)
    except (ProcessLookupError, ValueError, OSError):
        return

    print("  [WhatsApp] Proceso externo detectado — conectando en-hilo automáticamente...")
    print(f"  [WhatsApp] {wa_start()}")
