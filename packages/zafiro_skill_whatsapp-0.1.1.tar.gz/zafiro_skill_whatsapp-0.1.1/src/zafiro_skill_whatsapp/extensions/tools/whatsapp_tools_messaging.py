"""Messaging and diagnostics tool handlers for WhatsApp skill."""

from __future__ import annotations

from zafiro_skill_whatsapp.extensions.tools.whatsapp_tool_common import strip_kwargs


def _parse_target_limit(raw_args: str, *, default_limit: int) -> tuple[str, int]:
    raw = (raw_args or "").strip()
    if not raw:
        return "", default_limit

    target = raw
    limit_token = ""

    if "|" in raw:
        parts = [part.strip() for part in raw.split("|", 1)]
        target = parts[0]
        if len(parts) > 1:
            limit_token = parts[1]
    else:
        parts = raw.rsplit(None, 1)
        if len(parts) == 2 and parts[1].isdigit():
            target, limit_token = parts[0].strip(), parts[1].strip()

    limit = default_limit
    if limit_token.isdigit():
        limit = max(1, min(200, int(limit_token)))
    return target, limit


def _send_whatsapp(args: str) -> str:
    args = strip_kwargs(args)
    if "|" not in args and "," in args:
        args = args.replace(",", "|", 1)
    if "|" not in args:
        return "Format: send_whatsapp(number_or_alias|message)"
    recipient_ref, text = args.split("|", 1)
    recipient_ref = recipient_ref.strip().strip("'\"\u2018\u2019")
    number = recipient_ref.lstrip("+").replace(" ", "").replace("-", "")
    text = text.strip().strip("'\"\u2018\u2019")
    if not recipient_ref or not text:
        return "Recipient and message are required."

    if not number.isdigit() and "@g.us" not in number.lower():
        try:
            from zafiro_skill_whatsapp.adapters.whatsapp import resolve_recipient

            recipient = resolve_recipient(recipient_ref)
        except Exception as error:
            return f"Error resolving WhatsApp recipient: {error}"
        if recipient is None:
            return (
                f"Unknown WhatsApp alias '{recipient_ref}'. "
                "Save it first with a contact/group tool or use the real international number/JID."
            )
        number = recipient.get("jid") or recipient.get("phone") or number

    try:
        from zafiro_skill_whatsapp.adapters.whatsapp import is_connected, is_external_process_running, send_message
        from zafiro_skill_whatsapp.adapters.whatsapp.queue import enqueue_send_message

        if is_connected():
            return send_message(number, text)
        if is_external_process_running():
            command_id = enqueue_send_message(number, text, metadata={"source": "send_whatsapp_tool"})
            return f"Message queued for external WhatsApp channel to {number}. command_id={command_id}"
        return "WhatsApp channel is not active. Start it first."
    except Exception as error:
        return f"Error sending WhatsApp message: {error}"


def _reply_whatsapp(args: str) -> str:
    if "|" not in args:
        return "Format: reply_whatsapp(message_id|reply_text)"
    message_id, text = args.split("|", 1)
    message_id = message_id.strip().strip("'\"\u2018\u2019")
    text = text.strip().strip("'\"\u2018\u2019")
    if not message_id or not text:
        return "Message id and reply text are required."

    try:
        from zafiro_skill_whatsapp.adapters.whatsapp import is_connected, is_external_process_running, reply_to_message
        from zafiro_skill_whatsapp.adapters.whatsapp.queue import enqueue_reply_message

        if is_connected():
            return reply_to_message(message_id, text)
        if is_external_process_running():
            command_id = enqueue_reply_message(message_id, text, metadata={"source": "reply_whatsapp_tool"})
            return f"Reply queued for external WhatsApp channel to message {message_id}. command_id={command_id}"
        return "WhatsApp channel is not active. Start it first."
    except Exception as error:
        return f"Error replying on WhatsApp: {error}"


def _read_whatsapp(args: str) -> str:
    try:
        from zafiro_skill_whatsapp.integrations import read_archived_messages
        from zafiro_skill_whatsapp.adapters.whatsapp import (
            get_recent_messages,
            is_connected,
            is_external_process_running,
            list_groups,
            normalize_group_jid,
            resolve_contact,
            resolve_group,
        )
        from zafiro_skill_whatsapp.adapters.whatsapp.processing import get_recent_group_messages
    except Exception as error:
        return f"Error loading WhatsApp module: {error}"

    external_mode = not is_connected() and is_external_process_running()
    if not is_connected() and not external_mode:
        return "WhatsApp channel is not active."

    raw_arg = args.strip()
    target, n = _parse_target_limit(raw_arg, default_limit=5)
    from_number = None
    group_jid = None

    if target.isdigit() and len(target) <= 3 and "|" not in raw_arg and " " not in raw_arg:
        n = int(target)
        target = ""
    elif target:
        group = resolve_group(target)
        if "@g.us" in target.lower() or group is not None:
            group_jid = group["jid"] if group else normalize_group_jid(target)
        else:
            contact = resolve_contact(target)
            if contact is not None:
                from_number = str(contact.get("phone", ""))
            elif target.replace("+", "").replace(" ", "").replace("-", "").isdigit() and len(target) >= 7:
                from_number = target
            else:
                return f"Unknown WhatsApp contact/group '{target}'."

    if from_number:
        from_number = from_number.strip().lstrip("+").replace(" ", "").replace("-", "")

    if external_mode:
        msgs = read_archived_messages(from_number=from_number, chat_jid=group_jid, limit=n)
    elif group_jid:
        msgs = get_recent_group_messages(group_jid, n=n)
    else:
        msgs = get_recent_messages(n=n, from_number=from_number)

    if not msgs:
        if not external_mode and group_jid:
            return (
                f"No recent WhatsApp messages in current runtime buffer for group '{target}' ({group_jid}). "
                "Try read_whatsapp_archive(target|limit) for persisted history, "
                "or run whatsapp_recover() if the channel needs resync."
            )
        if not external_mode and from_number:
            return (
                f"No recent WhatsApp messages found in current runtime buffer for target '{from_number}'. "
                "Try read_whatsapp_archive(target|limit) for persisted history."
            )
        if external_mode and group_jid:
            return (
                f"No archived WhatsApp messages found for group '{target}' ({group_jid}) in current account. "
                "Run whatsapp_recover() to sync the channel, then retry."
            )
        if external_mode and from_number:
            return (
                f"No archived WhatsApp messages found for target '{from_number}' in current account. "
                "This tool only reads already archived data."
            )
        return "No matching WhatsApp messages found."

    header = "Archived WhatsApp messages:" if external_mode else "Recent incoming WhatsApp messages:"
    lines = [header]
    groups_by_jid = {group["jid"]: group["name"] for group in list_groups()}
    for message in msgs:
        ts = message.get("received_at", "")[:19].replace("T", " ")
        sender = message.get("from") or message.get("from_") or "?"
        message_id = message.get("message_id", "?")
        text = message.get("raw_text") or f"[{message.get('type', 'text')}]"
        chat_jid = message.get("chat_jid", "")
        group_label = f" group={groups_by_jid.get(chat_jid, chat_jid)}" if chat_jid.endswith("@g.us") else ""
        lines.append(f"  [{ts}] id={message_id}{group_label} {sender}: {text[:200]}")
    return "\n".join(lines)


def _read_whatsapp_archive(args: str) -> str:
    try:
        from zafiro_skill_whatsapp.integrations import read_archived_messages
        from zafiro_skill_whatsapp.adapters.whatsapp import normalize_group_jid, resolve_contact, resolve_group
    except Exception as error:
        return f"Error loading WhatsApp archive module: {error}"

    raw = args.strip()
    target, limit = _parse_target_limit(raw, default_limit=20)

    from_number = None
    chat_jid = None
    if target:
        group = resolve_group(target)
        if group is not None or "@g.us" in target.lower():
            chat_jid = group["jid"] if group else normalize_group_jid(target)
        else:
            contact = resolve_contact(target)
            if contact is not None:
                from_number = contact["phone"]
            elif target.replace("+", "").replace(" ", "").replace("-", "").isdigit():
                from_number = target.strip().lstrip("+").replace(" ", "").replace("-", "")
            else:
                return f"Unknown WhatsApp contact/group '{target}'."

    rows = read_archived_messages(from_number=from_number, chat_jid=chat_jid, limit=limit)
    if not rows:
        if chat_jid:
            return (
                f"No archived WhatsApp messages found for group '{target}' ({chat_jid}) in current account. "
                "Run whatsapp_recover() to sync the channel, then retry."
            )
        if from_number:
            return (
                f"No archived WhatsApp messages found for target '{from_number}' in current account. "
                "This tool only reads already archived data."
            )
        return "No archived WhatsApp messages found."

    lines = [f"Archived WhatsApp history ({len(rows)} messages):"]
    for row in rows:
        ts = row.get("received_at", "")[:19].replace("T", " ")
        sender = row.get("from_") or row.get("from") or "?"
        message_id = row.get("message_id", "?")
        text = row.get("raw_text") or f"[{row.get('type', 'text')}]"
        lines.append(f"  [{ts}] id={message_id} {sender}: {text[:200]}")
    return "\n".join(lines)


def _whatsapp_status(_args: str) -> str:
    try:
        from zafiro_skill_whatsapp.adapters.whatsapp import get_client, is_connected, is_external_process_running
        from zafiro_skill_whatsapp.adapters.whatsapp.runtime_ops.state import get_active_account_key
        from zafiro_skill_whatsapp.admin import wa_is_running

        running = wa_is_running()
        external_running = is_external_process_running()
        if not running and not external_running:
            return "WhatsApp: disconnected / not started."

        connected = is_connected()
        client = get_client()
        linked_number = "unknown"
        if connected and client is not None:
            try:
                me = client.get_me()
                linked_number = f"+{me.JID.User}" if me and me.JID else "unknown"
            except Exception:
                linked_number = "connected (JID unavailable)"

        if linked_number in {"unknown", "connected (JID unavailable)"}:
            active_account = get_active_account_key()
            if active_account:
                linked_number = f"+{active_account}"

        status = "connected" if connected else (
            "external process active" if external_running else "process active but not connected"
        )
        return f"WhatsApp: {status}\nLinked number: {linked_number}"
    except Exception as error:
        return f"Error checking WhatsApp status: {error}"


def _whatsapp_recover(args: str) -> str:
    mode = args.strip().lower()
    reset_session = mode in {"reset", "relink", "hard"}
    try:
        from zafiro_skill_whatsapp.admin import wa_recover

        return wa_recover(reset_session=reset_session)
    except Exception as error:
        return f"Error running WhatsApp recovery: {error}"


def _list_whatsapp_tools(_args: str) -> str:
    tools = [
        "save_whatsapp_contact",
        "save_whatsapp_contacts",
        "list_whatsapp_contacts",
        "save_whatsapp_group",
        "save_whatsapp_groups",
        "list_whatsapp_groups",
        "send_whatsapp",
        "read_whatsapp",
        "read_whatsapp_archive",
        "reply_whatsapp",
        "whatsapp_status",
        "whatsapp_recover",
        "wa_sync_auto",
        "get_group_recent_messages",
        "wa_policy",
        "wa_set_autoreply",
        "wa_allow_send",
        "wa_block_send",
        "wa_allow_reply",
        "wa_block_reply",
        "list_whatsapp_tools",
    ]
    lines = ["WhatsApp tools disponibles:"]
    lines.extend(f"- {name}" for name in tools)
    return "\n".join(lines)


def _wa_sync_auto(args: str) -> str:
    raw = strip_kwargs(args)
    if raw is None:
        raw = ""
    raw = raw.strip().strip("'\"")

    max_rounds = 12
    wait_seconds = 8
    force_remote = False

    if raw:
        tokens = [item.strip() for item in raw.split("|")]
        tokens = [item for item in tokens if item]
        if len(tokens) > 3:
            return "Usage: wa_sync_auto() or wa_sync_auto(max_rounds|wait_seconds|force_remote_optional)"

        if len(tokens) >= 1:
            if not tokens[0].isdigit():
                return "max_rounds must be an integer between 1 and 24"
            max_rounds = max(1, min(24, int(tokens[0])))

        if len(tokens) >= 2:
            if not tokens[1].isdigit():
                return "wait_seconds must be an integer between 1 and 30"
            wait_seconds = max(1, min(30, int(tokens[1])))

        if len(tokens) == 3:
            normalized = tokens[2].lower()
            if normalized in {"1", "true", "yes", "y", "on", "si", "s"}:
                force_remote = True
            elif normalized in {"0", "false", "no", "n", "off"}:
                force_remote = False
            else:
                return "force_remote must be one of: true|false|1|0|yes|no"

    try:
        from zafiro_skill_whatsapp.admin import wa_sync_auto_validate

        return wa_sync_auto_validate(
            max_rounds=max_rounds,
            wait_seconds=wait_seconds,
            force_remote=force_remote,
        )
    except Exception as error:
        return f"Error running wa_sync_auto: {error}"


def _get_group_recent_messages(args: str) -> str:
    """High-level tool: resolve group → archive → recover if empty → live fallback."""
    try:
        from zafiro_skill_whatsapp.adapters.whatsapp import resolve_group, normalize_group_jid, list_groups
        from zafiro_skill_whatsapp.integrations import read_archived_messages
    except Exception as error:
        return f"Error loading WhatsApp module: {error}"

    target, limit = _parse_target_limit(args.strip(), default_limit=10)
    if not target:
        return "Usage: get_group_recent_messages(group_alias_or_jid|limit)"

    # Step 1: resolve group JID
    group = resolve_group(target)
    if group is not None:
        group_jid = group["jid"]
        group_name = group.get("name") or group_jid
    elif "@g.us" in target.lower():
        group_jid = normalize_group_jid(target)
        group_name = target
    else:
        return (
            f"Group '{target}' not found in saved groups. "
            "Use list_whatsapp_groups() to verify the alias, "
            "or save_whatsapp_group(alias|group_jid) to register it first."
        )

    # Step 2: try archived messages
    rows = read_archived_messages(chat_jid=group_jid, limit=limit)

    # Step 3: if empty, trigger whatsapp_recover and retry once
    if not rows:
        try:
            from zafiro_skill_whatsapp.admin import wa_recover
            wa_recover(reset_session=False)
        except Exception:
            pass
        rows = read_archived_messages(chat_jid=group_jid, limit=limit)

    # Step 4: live buffer fallback
    if not rows:
        try:
            from zafiro_skill_whatsapp.adapters.whatsapp import is_connected
            from zafiro_skill_whatsapp.adapters.whatsapp.processing import get_recent_group_messages
            if is_connected():
                rows = get_recent_group_messages(group_jid, n=limit)
        except Exception:
            pass

    if not rows:
        return (
            f"No messages found for group '{group_name}' ({group_jid}). "
            "The channel may need a full resync; try whatsapp_recover(reset) if this persists."
        )

    groups_by_jid = {g["jid"]: g.get("name", g["jid"]) for g in list_groups()}
    display_name = groups_by_jid.get(group_jid, group_name)
    lines = [f"Last {len(rows)} messages — {display_name}:"]
    for row in rows:
        ts = row.get("received_at", "")[:19].replace("T", " ")
        sender = row.get("from_") or row.get("from") or "?"
        message_id = row.get("message_id", "?")
        text = row.get("raw_text") or f"[{row.get('type', 'text')}]"
        lines.append(f"  [{ts}] id={message_id} {sender}: {text[:200]}")
    return "\n".join(lines)
