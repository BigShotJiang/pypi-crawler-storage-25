"""WhatsApp tool registrations for the external WhatsApp skill package."""

from __future__ import annotations

from collections.abc import Callable

from zafiro_skill_whatsapp.extensions.tools.whatsapp_policy_tools import register_whatsapp_policy_tools
from zafiro_skill_whatsapp.extensions.tools.whatsapp_tools_contacts import (
    _list_whatsapp_contacts,
    _list_whatsapp_groups,
    _save_whatsapp_contact,
    _save_whatsapp_contacts,
    _save_whatsapp_group,
    _save_whatsapp_groups,
)
from zafiro_skill_whatsapp.extensions.tools.whatsapp_tools_messaging import (
    _get_group_recent_messages,
    _list_whatsapp_tools,
    _read_whatsapp,
    _read_whatsapp_archive,
    _reply_whatsapp,
    _send_whatsapp,
    _wa_sync_auto,
    _whatsapp_recover,
    _whatsapp_status,
)


def register_whatsapp_tools(register_tool: Callable[[str, str, Callable[[str], str]], None]) -> None:
    register_tool("send_whatsapp", "Send a WhatsApp message. Usage: send_whatsapp(number_or_alias|message)", _send_whatsapp)
    register_tool("save_whatsapp_contact", "Save or replace one WhatsApp contact. Usage: save_whatsapp_contact(name|phone|replace_optional|note_optional)", _save_whatsapp_contact)
    register_tool("save_whatsapp_contacts", "Save multiple WhatsApp contacts in batch. Usage: save_whatsapp_contacts(name|phone|note_optional;...)", _save_whatsapp_contacts)
    register_tool("list_whatsapp_contacts", "List saved WhatsApp contacts. Usage: list_whatsapp_contacts()", _list_whatsapp_contacts)
    register_tool("save_whatsapp_group", "Save or replace one WhatsApp group. Usage: save_whatsapp_group(name|group_jid|replace_optional|note_optional)", _save_whatsapp_group)
    register_tool("save_whatsapp_groups", "Save multiple WhatsApp groups in batch. Usage: save_whatsapp_groups(name|group_jid|note_optional;...)", _save_whatsapp_groups)
    register_tool("list_whatsapp_groups", "List saved WhatsApp groups. Usage: list_whatsapp_groups()", _list_whatsapp_groups)
    register_tool("reply_whatsapp", "Reply to a specific WhatsApp message id. Usage: reply_whatsapp(message_id|reply_text)", _reply_whatsapp)
    register_tool("read_whatsapp", "Read recent incoming WhatsApp messages. Usage: read_whatsapp() or read_whatsapp(target|limit)", _read_whatsapp)
    register_tool("read_whatsapp_archive", "Read archived WhatsApp messages. Usage: read_whatsapp_archive() or read_whatsapp_archive(target|limit)", _read_whatsapp_archive)
    register_tool("whatsapp_status", "Show WhatsApp connection status and linked number. Usage: whatsapp_status()", _whatsapp_status)
    register_tool("whatsapp_recover", "Repair common WhatsApp session/channel errors. Usage: whatsapp_recover() or whatsapp_recover(reset)", _whatsapp_recover)
    register_tool(
        "wa_sync_auto",
        "Run adaptive WhatsApp sync validation. Usage: wa_sync_auto() or wa_sync_auto(max_rounds|wait_seconds|force_remote_optional)",
        _wa_sync_auto,
    )
    register_tool(
        "get_group_recent_messages",
        "Fetch recent messages from a WhatsApp group by alias or JID. Auto-recovers if empty. Usage: get_group_recent_messages(alias_or_jid|limit)",
        _get_group_recent_messages,
    )
    register_tool(
        "list_whatsapp_tools",
        "List all WhatsApp tools exposed by this skill package. Usage: list_whatsapp_tools()",
        _list_whatsapp_tools,
    )
    register_whatsapp_policy_tools(register_tool)
