"""WhatsApp policy tool registrations extracted from legacy builtins."""

from __future__ import annotations

from collections.abc import Callable


def _wa_policy(_args: str) -> str:
    """Show current WhatsApp outbound/autoreply policy."""
    from zafiro_skill_whatsapp.adapters.whatsapp.contacts import (
        _load_contacts,
        _load_groups,
        list_reply_allowlist,
    )

    reply_targets = list_reply_allowlist()
    lines = [
        "Auto-respuesta inbound (user_agent_access):",
        "  - Solo responde a numeros/grupos vinculados explicitamente en BD.",
        "  - Grupos por defecto: solo lectura (sin respuesta automatica).",
        "",
        "Inbound - targets habilitados para auto-reply:",
    ]
    if reply_targets:
        for item in reply_targets:
            kind_icon = "[GROUP]" if item["kind"] == "group" else "[CONTACT]"
            lines.append(f"  {kind_icon} {item['label']}  [{item['target']}]")
    else:
        lines.append("  (ninguno - usa wa_allow_reply() o /wa link)")

    lines.extend([
        "",
        "Outbound - contactos con envio habilitado (can_receive=true):",
    ])
    contacts = [c for c in _load_contacts() if c.get("can_receive")]
    groups = [g for g in _load_groups() if g.get("can_receive")]
    if contacts:
        for contact in contacts:
            lines.append(f"  [CONTACT] {contact.get('name')}  +{contact.get('phone')}")
    if groups:
        for group in groups:
            lines.append(f"  [GROUP] {group.get('name')}  {group.get('jid')}")
    if not contacts and not groups:
        lines.append("  (ninguno - usa wa_allow_send() para habilitar)")
    return "\n".join(lines)


def _wa_set_autoreply(args: str) -> str:
    """Legacy no-op: global toggle deprecated in favor of user_agent_access."""
    val = args.strip().lower()
    if val not in {"on", "off", "true", "false", "1", "0", "activar", "desactivar"}:
        return "Uso: wa_set_autoreply(on) o wa_set_autoreply(off)"
    desired_state = "habilitar" if val in {"on", "true", "1", "activar"} else "deshabilitar"
    return (
        "wa_set_autoreply es legacy y ya no controla el auto-reply.\n"
        f"Para {desired_state} respuestas, administra reglas en user_agent_access con:\n"
        "- wa_allow_reply(target) / wa_block_reply(target), o\n"
        "- /wa link <target> <default> <allowed1,allowed2>."
    )


def _wa_allow_send(args: str) -> str:
    """Enable outbound sends to a contact or group."""
    target = args.strip()
    if not target:
        return "Uso: wa_allow_send(numero_o_nombre_o_jid_grupo)"
    from zafiro_skill_whatsapp.adapters.whatsapp.contacts import set_send_allowed

    return set_send_allowed(target, True)


def _wa_block_send(args: str) -> str:
    """Disable outbound sends to a contact or group."""
    target = args.strip()
    if not target:
        return "Uso: wa_block_send(numero_o_nombre_o_jid_grupo)"
    from zafiro_skill_whatsapp.adapters.whatsapp.contacts import set_send_allowed

    return set_send_allowed(target, False)


def _wa_allow_reply(args: str) -> str:
    """Enable inbound auto-reply for a contact or group target."""
    target = args.strip()
    if not target:
        return "Uso: wa_allow_reply(numero_o_alias_o_jid_grupo)"
    from zafiro_skill_whatsapp.adapters.whatsapp.contacts import set_reply_allowed

    return set_reply_allowed(target, True)


def _wa_block_reply(args: str) -> str:
    """Disable inbound auto-reply for a contact/group target."""
    target = args.strip()
    if not target:
        return "Uso: wa_block_reply(numero_o_alias_o_jid_grupo)"
    from zafiro_skill_whatsapp.adapters.whatsapp.contacts import set_reply_allowed

    return set_reply_allowed(target, False)


def register_whatsapp_policy_tools(register_tool: Callable[[str, str, Callable[[str], str]], None]) -> None:
    """Register extracted WhatsApp policy tools into the shared registry."""
    register_tool(
        "wa_policy",
        "Muestra la politica actual de WhatsApp: auto-respuesta inbound y contactos/grupos habilitados para envio. Uso: wa_policy()",
        _wa_policy,
    )
    register_tool(
        "wa_set_autoreply",
        "Legacy: ya no existe auto-reply global. Usa reglas por target en user_agent_access via wa_allow_reply/wa_block_reply o /wa link.",
        _wa_set_autoreply,
    )
    register_tool(
        "wa_allow_send",
        "Habilita el envio de mensajes salientes a un contacto o grupo. Uso: wa_allow_send(numero o alias o JID de grupo).",
        _wa_allow_send,
    )
    register_tool(
        "wa_block_send",
        "Deshabilita el envio de mensajes salientes a un contacto o grupo. Uso: wa_block_send(numero o alias o JID de grupo).",
        _wa_block_send,
    )
    register_tool(
        "wa_allow_reply",
        "Habilita auto-reply inbound para un numero o grupo creando/vinculando una regla en user_agent_access. Uso: wa_allow_reply(numero|alias|jid_grupo).",
        _wa_allow_reply,
    )
    register_tool(
        "wa_block_reply",
        "Deshabilita auto-reply inbound para un numero o grupo removiendo su regla de user_agent_access. Uso: wa_block_reply(numero|alias|jid_grupo).",
        _wa_block_reply,
    )
