"""Contact and group management tool handlers for WhatsApp skill."""

from __future__ import annotations

from zafiro_skill_whatsapp.extensions.tools.whatsapp_tool_common import strip_kwargs


def _save_whatsapp_contact(args: str) -> str:
    parts = [part.strip() for part in args.split("|")]
    if len(parts) < 2:
        return "Usage: save_whatsapp_contact(name|phone|replace_optional|note_optional)"
    replace = True
    if len(parts) > 2 and parts[2]:
        replace = parts[2].lower() in {"1", "true", "yes", "replace"}
    note = parts[3] if len(parts) > 3 else ""
    try:
        from zafiro_skill_whatsapp.adapters.whatsapp import upsert_contact

        contact = upsert_contact(parts[0], parts[1], replace=replace, note=note)
        return f"WhatsApp contact saved: {contact['name']} -> {contact['phone']}"
    except Exception as error:
        return f"Error saving WhatsApp contact: {error}"


def _save_whatsapp_contacts(args: str) -> str:
    raw = args.strip()
    if not raw:
        return "Usage: save_whatsapp_contacts(name|phone|note_optional;...)"
    entries: list[dict] = []
    for chunk in raw.split(";"):
        piece = chunk.strip()
        if not piece:
            continue
        parts = [part.strip() for part in piece.split("|")]
        if len(parts) < 2:
            return "Invalid format. Use: save_whatsapp_contacts(name|phone|note_optional;...)"
        entries.append({"name": parts[0], "phone": parts[1], "note": parts[2] if len(parts) > 2 else ""})
    try:
        from zafiro_skill_whatsapp.adapters.whatsapp import upsert_contacts

        saved = upsert_contacts(entries, replace=True)
        lines = [f"WhatsApp contacts saved: {len(saved)}"]
        lines.extend(f"  - {item['name']} -> {item['phone']}" for item in saved)
        return "\n".join(lines)
    except Exception as error:
        return f"Error saving WhatsApp contacts: {error}"


def _list_whatsapp_contacts(_args: str) -> str:
    try:
        from zafiro_skill_whatsapp.adapters.whatsapp import list_contacts

        contacts = list_contacts()
        if not contacts:
            return "No WhatsApp contacts saved."
        lines = ["Saved WhatsApp contacts:"]
        for contact in contacts:
            note = f" note={contact.get('note')}" if contact.get("note") else ""
            lines.append(f"  - {contact['name']} -> {contact['phone']}{note}")
        return "\n".join(lines)
    except Exception as error:
        return f"Error listing WhatsApp contacts: {error}"


def _save_whatsapp_group(args: str) -> str:
    args = strip_kwargs(args)
    parts = [part.strip() for part in args.split("|")]
    if len(parts) < 2:
        return "Usage: save_whatsapp_group(name|group_jid|replace_optional|note_optional)"
    replace = True
    if len(parts) > 2 and parts[2]:
        replace = parts[2].lower() in {"1", "true", "yes", "replace"}
    note = parts[3] if len(parts) > 3 else ""
    try:
        from zafiro_skill_whatsapp.adapters.whatsapp import upsert_group

        group = upsert_group(parts[0], parts[1], replace=replace, note=note)
        return f"WhatsApp group saved: {group['name']} -> {group['jid']}"
    except Exception as error:
        return f"Error saving WhatsApp group: {error}"


def _save_whatsapp_groups(args: str) -> str:
    args = strip_kwargs(args)
    raw = args.strip()
    if not raw:
        return "Usage: save_whatsapp_groups(name|group_jid|note_optional;...)"
    entries: list[dict] = []
    for chunk in raw.split(";"):
        piece = chunk.strip()
        if not piece:
            continue
        parts = [part.strip() for part in piece.split("|")]
        if len(parts) < 2:
            return "Invalid format. Use: save_whatsapp_groups(name|group_jid|note_optional;...)"
        entries.append({"name": parts[0], "jid": parts[1], "note": parts[2] if len(parts) > 2 else ""})
    try:
        from zafiro_skill_whatsapp.adapters.whatsapp import upsert_groups

        saved = upsert_groups(entries, replace=True)
        lines = [f"WhatsApp groups saved: {len(saved)}"]
        lines.extend(f"  - {item['name']} -> {item['jid']}" for item in saved)
        return "\n".join(lines)
    except Exception as error:
        return f"Error saving WhatsApp groups: {error}"


def _list_whatsapp_groups(_args: str) -> str:
    try:
        from zafiro_skill_whatsapp.adapters.whatsapp import list_groups

        groups = list_groups()
        if not groups:
            return "No WhatsApp groups saved."
        lines = ["Saved WhatsApp groups:"]
        for group in groups:
            note = f" note={group.get('note')}" if group.get("note") else ""
            lines.append(f"  - {group['name']} -> {group['jid']}{note}")
        return "\n".join(lines)
    except Exception as error:
        return f"Error listing WhatsApp groups: {error}"
