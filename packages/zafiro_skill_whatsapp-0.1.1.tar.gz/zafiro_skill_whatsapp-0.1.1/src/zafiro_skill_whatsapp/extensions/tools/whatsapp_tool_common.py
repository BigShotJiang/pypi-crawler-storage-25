"""Shared parsing helpers for WhatsApp tool handlers."""

from __future__ import annotations

import re

_KWARG_RE = re.compile(r"""\w[\w]*\s*=\s*f?['\"]([^'\"]*)['\"]\s*""")


def strip_kwargs(args: str) -> str:
    """Convert kwargs-style string args into `|`-separated arguments.

    Example:
      "name='Juan', phone='+5061234'" -> "Juan|+5061234"
    """
    if "|" in args or "=" not in args:
        return args
    values = _KWARG_RE.findall(args)
    if values:
        return "|".join(v.strip() for v in values)
    return args
