"""Tool extension namespace for WhatsApp skill package."""

from zafiro_skill_whatsapp.extensions.tools.whatsapp_tools import register_whatsapp_tools

__all__ = ["register_whatsapp_tools"]
