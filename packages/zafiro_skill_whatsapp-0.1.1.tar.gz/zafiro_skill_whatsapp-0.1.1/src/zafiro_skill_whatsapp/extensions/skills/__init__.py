"""Skill extension namespace for WhatsApp skill package."""

from zafiro_skill_whatsapp.extensions.skills.whatsapp import register_whatsapp_skill

__all__ = ["register_whatsapp_skill"]
