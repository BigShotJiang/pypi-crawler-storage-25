"""WhatsApp skill registration extracted from legacy builtins."""

from __future__ import annotations

from collections.abc import Callable


def register_whatsapp_skill(register_skill: Callable[..., None]) -> None:
    """Register the WhatsApp skill and methodology prompt."""
    register_skill(
        "WhatsApp",
        "Enviar, leer y responder mensajes de WhatsApp",
        [
            "save_whatsapp_contact",
            "save_whatsapp_contacts",
            "list_whatsapp_contacts",
            "save_whatsapp_group",
            "save_whatsapp_groups",
            "list_whatsapp_groups",
            "send_whatsapp",
            "read_whatsapp",
            "read_whatsapp_archive",
            "reply_whatsapp",
            "whatsapp_status",
            "whatsapp_recover",
            "wa_sync_auto",
            "get_group_recent_messages",
            "list_whatsapp_tools",
            "wa_policy",
            "wa_set_autoreply",
            "wa_allow_send",
            "wa_block_send",
            "wa_allow_reply",
            "wa_block_reply",
        ],
        prompt=(
            "IMPORTANTE: Este skill incluye TODAS las herramientas de WhatsApp. "
            "Si tienes este skill, ejecutalas directamente tu mismo. "
            "NUNCA uses invoke_agent para delegar tareas de WhatsApp a otro agente.\n"
            "\n"
            "Metodologia WhatsApp:\n"
            "- Si el usuario pide guardar un numero con un nombre, registrar un contacto o actualizar uno existente, usa save_whatsapp_contact(name|phone|replace_opcional|note_opcional). "
            "Confirma al final con el nombre y numero guardados.\n"
            "- Si el usuario comparte su propio numero y ademas pide una confirmacion por WhatsApp, primero guarda el contacto y luego envia tu mismo un mensaje breve de confirmacion con send_whatsapp; no le pidas que redacte el mensaje salvo que quiera un texto especifico.\n"
            "- Si el usuario te da varios nombres y numeros, usa save_whatsapp_contacts en lote.\n"
            "- Puedes guardar agenda propia del skill con save_whatsapp_contact o save_whatsapp_contacts. "
            "Usalo cuando el usuario quiera registrar varios numeros, mantener contactos frecuentes o reemplazar un numero viejo por uno nuevo.\n"
            "- Despues de guardar un contacto, ya puedes reutilizar ese alias directamente en send_whatsapp(nombre|mensaje) sin volver a pedir el numero.\n"
            "- Tambien puedes guardar grupos con save_whatsapp_group o save_whatsapp_groups para leerlos y enviar usando alias en vez de pegar el JID cada vez.\n"
            "- Si el usuario dice un nombre ya guardado, puedes usar send_whatsapp(nombre|mensaje) y resolverlo desde la agenda.\n"
            "- Si el usuario quiere verificar la agenda o duda de como quedo guardado un contacto, usa list_whatsapp_contacts.\n"
            "- Para grupos, read_whatsapp acepta un group_jid o alias guardado y send_whatsapp puede enviar al grupo por alias o JID `@g.us`.\n"
            "- Usa read_whatsapp_archive cuando necesites revisar historial archivado, no solo el buffer reciente en memoria. Tambien acepta alias o JID de grupo.\n"
            "- Para 'ultimos N mensajes de grupo', usa get_group_recent_messages(alias_o_jid|N) como herramienta preferida.\n"
            "- Si observas huecos de historial o lectura vacia persistente, usa wa_sync_auto() y luego reintenta la lectura.\n"
            "- Decide primero si el caso es OUTBOUND o REPLY. "
            "Usa send_whatsapp para iniciar un mensaje nuevo a un numero. "
            "Usa reply_whatsapp solo cuando el usuario quiera contestar un mensaje entrante especifico.\n"
            "- Si el usuario pide enviar un mensaje pero no indico el numero de telefono, "
            "preguntaselo ANTES de llamar send_whatsapp. Pide el numero en formato "
            "internacional sin + (solo digitos, ej: 50682480271).\n"
            "- El valor de retorno de send_whatsapp ES la confirmacion de envio. "
            "Reportalo directamente al usuario ('Mensaje enviado' o el error). "
            "NO llames read_whatsapp para verificar el envio - esa herramienta solo lee "
            "mensajes ENTRANTES, no confirma entregas.\n"
            "- Si el usuario quiere responder a un mensaje especifico, primero usa "
            "read_whatsapp para obtener el id exacto mostrado como id=... y luego usa "
            "reply_whatsapp(id|texto). No inventes ids ni supongas cual mensaje contestar.\n"
            "- Si hay varios mensajes posibles y el usuario no aclaro cual responder, "
            "muestra o consulta los recientes antes de responder.\n"
            "- Usa read_whatsapp cuando el usuario pida ver mensajes recibidos o cuando necesites "
            "identificar el message_id correcto para una respuesta.\n"
            "- Usa whatsapp_status() cuando el usuario pregunte si WhatsApp esta conectado, "
            "que numero esta vinculado, o como cambiar el numero linkeado al dispositivo.\n"
            "- Si aparecen errores de SQLite (por ejemplo 'attempt to write a readonly database'), "
            "usa whatsapp_recover() para reparar permisos y reiniciar el canal automaticamente. "
            "Usa whatsapp_recover(reset) solo si hace falta forzar relink con QR.\n"
            "- Si el usuario pregunta que herramientas de WhatsApp tienes, usa list_whatsapp_tools() y responde con ese inventario.\n"
            "\n"
            "Politica de envio (outbound):\n"
            "- Usa wa_policy() para ver el estado actual: targets con auto-reply habilitado en BD y "
            "lista de contactos/grupos habilitados para envio outbound.\n"
            "- Usa wa_allow_send(numero_o_alias_o_jid) para habilitar el envio saliente a un contacto o grupo.\n"
            "- Usa wa_block_send(numero_o_alias_o_jid) para deshabilitarlo.\n"
            "- Si send_whatsapp devuelve 'Envio bloqueado', usa wa_allow_send() primero y luego reintenta.\n"
            "- wa_set_autoreply() es legacy; el control real de auto-reply es por target en user_agent_access.\n"
            "\n"
            "Lista explicita de auto-respuesta inbound (BD):\n"
            "- Usa wa_allow_reply(target) para habilitar auto-reply a un numero o grupo especifico.\n"
            "- Usa wa_block_reply(target) para remover ese target de la lista (dejar de responder).\n"
            "- Si un numero o grupo NO esta en la lista de user_agent_access, NO se responde automaticamente.\n"
            "- Los grupos son solo lectura por defecto: hay que habilitarlos explicitamente para responder.\n"
            "\n"
            "Auto-reply inbound:\n"
            "- Cuando recibes un mensaje de un usuario externo (auto-reply), tu tarea es GENERAR "
            "una respuesta conversacional natural. El sistema se encarga de enviarla - NO uses "
            "send_whatsapp ni reply_whatsapp para responder al mismo usuario que te escribio.\n"
            "- Responde de forma directa, amigable y concisa. Si no tienes suficiente contexto "
            "para ayudar con algo especifico, di que lo pasaras al responsable o pide mas detalles.\n"
            "- Manten la conversacion en el idioma en que te habla el usuario."
        ),
    )
