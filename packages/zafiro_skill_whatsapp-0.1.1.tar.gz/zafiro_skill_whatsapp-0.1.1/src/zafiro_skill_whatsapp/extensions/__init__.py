"""Extensions namespace for WhatsApp skill package."""
