"""Package-local integration layer.

This module makes the WhatsApp skill package autonomous by providing:
- local normalization/session helpers
- ORM-backed storage helpers (messages, contacts, groups, access-rules)
- optional host runtime hooks that can be configured by an embedding app
"""

from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timezone
import json
import logging
import os
from pathlib import Path
import threading
import time
from typing import Any, Callable

from sqlalchemy import (
    Boolean,
    DateTime,
    ForeignKey,
    Integer,
    or_,
    String,
    Text,
    UniqueConstraint,
    create_engine,
    delete,
    select,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker


# Keep these constants local/env-backed so integrations can be imported first
# without triggering the heavy whatsapp adapter package import chain.
MESSAGE_ARCHIVE_PATH = os.getenv(
    "MESSAGE_ARCHIVE_PATH", "./data/message_archive/whatsapp_messages.jsonl"
)
RECENT_SESSION_HISTORY_LIMIT = int(os.getenv("RECENT_SESSION_HISTORY_LIMIT", "10"))
WHATSAPP_ACCESS_RULES_PATH = os.getenv(
    "WHATSAPP_ACCESS_RULES_PATH", "./data/whatsapp_access_rules.json"
)
WHATSAPP_LOCAL_DB_PATH = os.getenv("WHATSAPP_LOCAL_DB_PATH", "./data/whatsapp_storage.sqlite3")

logger = logging.getLogger(__name__)


class _StorageBase(DeclarativeBase):
    pass


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


class _WhatsAppAccount(_StorageBase):
    __tablename__ = "wa_storage_accounts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    account_key: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    source: Mapped[str] = mapped_column(String(32), default="whatsapp")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, onupdate=_utcnow)
    last_seen_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)


class _WhatsAppMessage(_StorageBase):
    __tablename__ = "wa_storage_messages"
    __table_args__ = (
        UniqueConstraint("account_id", "message_id", name="uq_wa_storage_messages_account_message"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    account_id: Mapped[int] = mapped_column(ForeignKey("wa_storage_accounts.id"), index=True)
    direction: Mapped[str] = mapped_column(String(16), default="inbound")
    delivery_status: Mapped[str] = mapped_column(String(32), default="received")
    from_: Mapped[str] = mapped_column(String(64), default="")
    normalized_from: Mapped[str] = mapped_column(String(64), default="", index=True)
    peer_number: Mapped[str] = mapped_column(String(64), default="")
    jid: Mapped[str] = mapped_column(String(128), default="")
    message_type: Mapped[str] = mapped_column(String(32), default="text")
    received_at: Mapped[str] = mapped_column(String(64), default="")
    raw_text: Mapped[str | None] = mapped_column(Text, nullable=True)
    audio_transcription: Mapped[str | None] = mapped_column(Text, nullable=True)
    image_analysis: Mapped[str | None] = mapped_column(Text, nullable=True)
    media_path: Mapped[str | None] = mapped_column(Text, nullable=True)
    mime_type: Mapped[str | None] = mapped_column(String(128), nullable=True)
    source_channel: Mapped[str] = mapped_column(String(32), default="whatsapp")
    message_id: Mapped[str] = mapped_column(String(128), default="")
    reply_to_message_id: Mapped[str | None] = mapped_column(String(128), nullable=True)
    chat_jid: Mapped[str] = mapped_column(String(128), default="", index=True)
    sender_jid: Mapped[str] = mapped_column(String(128), default="")
    session_id: Mapped[str] = mapped_column(String(128), default="")
    extra_json: Mapped[str] = mapped_column(Text, default="{}")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, onupdate=_utcnow)


class _WhatsAppContact(_StorageBase):
    __tablename__ = "wa_storage_contacts"
    __table_args__ = (
        UniqueConstraint("account_id", "phone", name="uq_wa_storage_contacts_account_phone"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    account_id: Mapped[int] = mapped_column(ForeignKey("wa_storage_accounts.id"), index=True)
    name: Mapped[str] = mapped_column(String(255), default="")
    name_normalized: Mapped[str] = mapped_column(String(255), default="", index=True)
    phone: Mapped[str] = mapped_column(String(64), default="")
    note: Mapped[str] = mapped_column(Text, default="")
    can_receive: Mapped[bool] = mapped_column(Boolean, default=False)
    auto_reply_allowed: Mapped[bool] = mapped_column(Boolean, default=False)
    extra_json: Mapped[str] = mapped_column(Text, default="{}")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, onupdate=_utcnow)


class _WhatsAppGroup(_StorageBase):
    __tablename__ = "wa_storage_groups"
    __table_args__ = (
        UniqueConstraint("account_id", "jid", name="uq_wa_storage_groups_account_jid"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    account_id: Mapped[int] = mapped_column(ForeignKey("wa_storage_accounts.id"), index=True)
    name: Mapped[str] = mapped_column(String(255), default="")
    name_normalized: Mapped[str] = mapped_column(String(255), default="", index=True)
    jid: Mapped[str] = mapped_column(String(128), default="")
    note: Mapped[str] = mapped_column(Text, default="")
    can_receive: Mapped[bool] = mapped_column(Boolean, default=False)
    auto_reply_allowed: Mapped[bool] = mapped_column(Boolean, default=False)
    extra_json: Mapped[str] = mapped_column(Text, default="{}")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, onupdate=_utcnow)


class _WhatsAppAccessRule(_StorageBase):
    __tablename__ = "wa_storage_access_rules"
    __table_args__ = (
        UniqueConstraint("account_id", "source", "external_user_id", name="uq_wa_storage_access_rules_scope"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    account_id: Mapped[int] = mapped_column(ForeignKey("wa_storage_accounts.id"), index=True)
    source: Mapped[str] = mapped_column(String(64), default="whatsapp")
    external_user_id: Mapped[str] = mapped_column(String(128), default="")
    allowed_agent_names_json: Mapped[str] = mapped_column(Text, default="[]")
    default_agent_name: Mapped[str] = mapped_column(String(255), default="")
    access_level: Mapped[str] = mapped_column(String(64), default="limited")
    extra_json: Mapped[str] = mapped_column(Text, default="{}")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, onupdate=_utcnow)


@dataclass
class HostRuntimeHooks:
    get_active_agents: Callable[[], list[dict]] | None = None
    execute_task: Callable[..., tuple[str, str | None]] | None = None
    resolve_effective_agent: Callable[[dict, str, list[dict]], dict | None] | None = None
    orm_session_factory: Callable[[], Any] | None = None
    orm_engine_factory: Callable[[], Any] | None = None
    resolve_storage_account_key: Callable[[], str | None] | None = None
    storage_schema_initializer: Callable[[], None] | None = None


_HOST_HOOKS = HostRuntimeHooks()
_STATE_LOCK = threading.Lock()
_SQLITE_FALLBACK_WARNING_EMITTED = False
_LOCAL_ENGINE = None
_LOCAL_SESSION_FACTORY = None
_LOCAL_DB_URL = ""
_HOST_ENGINE_SESSION_FACTORIES: dict[int, Any] = {}
_SCHEMA_READY_BIND_IDS: set[int] = set()

HOST_RUNTIME_CONTRACT_VERSION = "1.0"
HOST_RUNTIME_CONTRACT = {
    "version": HOST_RUNTIME_CONTRACT_VERSION,
    "python_dependencies": [
        "sqlalchemy>=2.0",
        "python-magic>=0.4.27",
        "neonize",
    ],
    "system_dependencies": [
        "libmagic (required by python-magic / neonize runtime)",
    ],
    "hooks": {
        "required_for_core_db": ["orm_session_factory|orm_engine_factory"],
        "required_for_multi_account": ["resolve_storage_account_key"],
        "optional": [
            "storage_schema_initializer",
            "get_active_agents",
            "execute_task",
            "resolve_effective_agent",
        ],
    },
}


_MESSAGE_BASE_FIELDS = {
    "direction",
    "delivery_status",
    "from_",
    "peer_number",
    "jid",
    "type",
    "received_at",
    "raw_text",
    "audio_transcription",
    "image_analysis",
    "media_path",
    "mime_type",
    "source_channel",
    "message_id",
    "reply_to_message_id",
    "chat_jid",
    "sender_jid",
    "session_id",
}
_CONTACT_BASE_FIELDS = {"name", "phone", "note", "can_receive", "auto_reply_allowed"}
_GROUP_BASE_FIELDS = {"name", "jid", "note", "can_receive", "auto_reply_allowed"}


def _normalize_name(value: str) -> str:
    return " ".join((value or "").lower().split())


def _as_bool(value: Any, *, default: bool = False) -> bool:
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    if isinstance(value, (int, float)):
        return bool(value)
    text = str(value).strip().lower()
    if text in {"1", "true", "yes", "on", "si", "sí"}:
        return True
    if text in {"0", "false", "no", "off"}:
        return False
    return default


def _json_loads(value: str | None, default: Any) -> Any:
    raw = (value or "").strip()
    if not raw:
        return default
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return default


def _json_dumps(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


def _split_extras(payload: dict, base_fields: set[str]) -> dict:
    return {key: value for key, value in payload.items() if key not in base_fields}


def configure_host_runtime(
    *,
    get_active_agents: Callable[[], list[dict]] | None = None,
    execute_task: Callable[..., tuple[str, str | None]] | None = None,
    resolve_effective_agent: Callable[[dict, str, list[dict]], dict | None] | None = None,
    orm_session_factory: Callable[[], Any] | None = None,
    orm_engine_factory: Callable[[], Any] | None = None,
    resolve_storage_account_key: Callable[[], str | None] | None = None,
    storage_schema_initializer: Callable[[], None] | None = None,
) -> None:
    _HOST_HOOKS.get_active_agents = get_active_agents
    _HOST_HOOKS.execute_task = execute_task
    _HOST_HOOKS.resolve_effective_agent = resolve_effective_agent
    _HOST_HOOKS.orm_session_factory = orm_session_factory
    _HOST_HOOKS.orm_engine_factory = orm_engine_factory
    _HOST_HOOKS.resolve_storage_account_key = resolve_storage_account_key
    _HOST_HOOKS.storage_schema_initializer = storage_schema_initializer


def get_host_runtime_contract() -> dict:
    """Return the explicit integration contract expected by this skill.

    The core project can call this during bootstrap to discover required
    hooks/dependencies before enabling the WhatsApp skill.
    """
    return dict(HOST_RUNTIME_CONTRACT)


def validate_host_runtime_contract(
    *,
    require_core_database: bool = False,
    require_multi_account: bool = False,
) -> dict:
    """Validate currently configured host hooks against the integration contract."""
    missing_hooks: list[str] = []
    warnings: list[str] = []

    if require_core_database and _HOST_HOOKS.orm_session_factory is None and _HOST_HOOKS.orm_engine_factory is None:
        missing_hooks.append("orm_session_factory|orm_engine_factory")

    if require_multi_account and _HOST_HOOKS.resolve_storage_account_key is None:
        missing_hooks.append("resolve_storage_account_key")

    if _HOST_HOOKS.orm_session_factory is None and _HOST_HOOKS.orm_engine_factory is None:
        warnings.append("core ORM hooks not configured; SQLite fallback will be used")
    if _HOST_HOOKS.resolve_storage_account_key is None:
        warnings.append("resolve_storage_account_key not configured; runtime auto-discovery will be used")

    return {
        "ok": len(missing_hooks) == 0,
        "missing_hooks": missing_hooks,
        "warnings": warnings,
        "contract_version": HOST_RUNTIME_CONTRACT_VERSION,
    }


def assert_host_runtime_contract(
    *,
    require_core_database: bool = False,
    require_multi_account: bool = False,
) -> None:
    """Raise RuntimeError when required contract hooks are missing."""
    result = validate_host_runtime_contract(
        require_core_database=require_core_database,
        require_multi_account=require_multi_account,
    )
    if result["ok"]:
        return

    missing = ", ".join(result["missing_hooks"])
    raise RuntimeError(
        "WhatsApp host runtime contract not satisfied. "
        f"Missing hooks: {missing}. Contract version: {HOST_RUNTIME_CONTRACT_VERSION}."
    )


def _local_sqlite_url() -> str:
    path = Path(WHATSAPP_LOCAL_DB_PATH).expanduser()
    path.parent.mkdir(parents=True, exist_ok=True)
    return f"sqlite+pysqlite:///{path}"


def _get_local_session_factory() -> Any:
    global _LOCAL_ENGINE, _LOCAL_SESSION_FACTORY, _LOCAL_DB_URL

    target_url = _local_sqlite_url()
    with _STATE_LOCK:
        if _LOCAL_SESSION_FACTORY is not None and _LOCAL_DB_URL == target_url:
            return _LOCAL_SESSION_FACTORY

        _LOCAL_ENGINE = create_engine(target_url, future=True)
        _LOCAL_SESSION_FACTORY = sessionmaker(bind=_LOCAL_ENGINE, autoflush=False, expire_on_commit=False)
        _LOCAL_DB_URL = target_url
        return _LOCAL_SESSION_FACTORY


def _warn_sqlite_fallback_once() -> None:
    global _SQLITE_FALLBACK_WARNING_EMITTED
    with _STATE_LOCK:
        if _SQLITE_FALLBACK_WARNING_EMITTED:
            return
        _SQLITE_FALLBACK_WARNING_EMITTED = True

    logger.warning(
        "WhatsApp skill storage is using local SQLite fallback at %s. "
        "Configure orm_session_factory/orm_engine_factory to reuse the core ORM database.",
        Path(WHATSAPP_LOCAL_DB_PATH).expanduser(),
    )


def _resolve_session_factory() -> tuple[Callable[[], Any], str]:
    if _HOST_HOOKS.orm_session_factory is not None:
        return _HOST_HOOKS.orm_session_factory, "host-session"

    if _HOST_HOOKS.orm_engine_factory is not None:
        engine = _HOST_HOOKS.orm_engine_factory()
        if engine is not None:
            engine_id = id(engine)
            with _STATE_LOCK:
                factory = _HOST_ENGINE_SESSION_FACTORIES.get(engine_id)
                if factory is None:
                    factory = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
                    _HOST_ENGINE_SESSION_FACTORIES[engine_id] = factory
            return factory, "host-engine"

    _warn_sqlite_fallback_once()
    return _get_local_session_factory(), "sqlite-fallback"


def _maybe_initialize_schema_with_host() -> None:
    initializer = _HOST_HOOKS.storage_schema_initializer
    if initializer is None:
        return
    try:
        initializer()
    except Exception as error:
        logger.warning("Host storage_schema_initializer failed: %s", error)


def _ensure_schema(session: Any) -> None:
    bind = session.get_bind()
    bind_id = id(bind)
    with _STATE_LOCK:
        ready = bind_id in _SCHEMA_READY_BIND_IDS
    if ready:
        return

    _maybe_initialize_schema_with_host()
    _StorageBase.metadata.create_all(bind=bind, checkfirst=True)

    with _STATE_LOCK:
        _SCHEMA_READY_BIND_IDS.add(bind_id)


@contextmanager
def _session_scope(*, write: bool) -> Any:
    session_factory, _mode = _resolve_session_factory()
    session_or_cm = session_factory()

    if hasattr(session_or_cm, "__enter__") and hasattr(session_or_cm, "__exit__"):
        with session_or_cm as session:
            _ensure_schema(session)
            try:
                yield session
                if write:
                    session.commit()
            except Exception:
                if write:
                    session.rollback()
                raise
        return

    session = session_or_cm
    try:
        _ensure_schema(session)
        yield session
        if write:
            session.commit()
    except Exception:
        if write:
            session.rollback()
        raise
    finally:
        try:
            session.close()
        except Exception:
            pass


def _normalize_storage_account(value: str) -> str:
    raw = (value or "").strip()
    if raw.startswith("whatsapp:"):
        raw = raw.split(":", 1)[1]
    normalized = normalize_external_user_id(raw)
    if normalized:
        return normalized
    return raw or "unknown"


def resolve_storage_account_key(explicit_account: str | None = None) -> str:
    if explicit_account:
        return _normalize_storage_account(explicit_account)

    resolver = _HOST_HOOKS.resolve_storage_account_key
    if resolver is not None:
        try:
            resolved = resolver()
        except Exception as error:
            logger.warning("Host resolve_storage_account_key failed: %s", error)
        else:
            if resolved:
                return _normalize_storage_account(resolved)

    try:
        from zafiro_skill_whatsapp.adapters.whatsapp.runtime_ops.state import get_active_account_key

        runtime_account = get_active_account_key()
    except Exception:
        runtime_account = ""
    if runtime_account:
        return _normalize_storage_account(runtime_account)

    return "unknown"


def _get_account(session: Any, account_key: str, *, create: bool) -> _WhatsAppAccount | None:
    row = session.execute(
        select(_WhatsAppAccount).where(_WhatsAppAccount.account_key == account_key)
    ).scalar_one_or_none()
    if row is None and create:
        row = _WhatsAppAccount(account_key=account_key, source="whatsapp")
        session.add(row)
        session.flush()
    if row is not None:
        row.last_seen_at = _utcnow()
    return row


def ensure_whatsapp_storage_schema() -> None:
    with _session_scope(write=False) as _session:
        return None


def normalize_external_user_id(value: str) -> str:
    return "".join(ch for ch in (value or "") if ch.isdigit())


def build_whatsapp_session_id(phone_number: str) -> str:
    normalized = normalize_external_user_id(phone_number)
    return f"whatsapp:{normalized}" if normalized else "whatsapp:unknown"


def _normalize_history_phone(phone_number: str) -> str:
    raw = (phone_number or "").strip()
    if raw.startswith("whatsapp:"):
        raw = raw.split(":", 1)[1]
    return normalize_external_user_id(raw)


def load_session_history(phone_number: str, limit: int = RECENT_SESSION_HISTORY_LIMIT) -> list[dict]:
    """Load chat history for one WhatsApp phone number.

    This package is sessionless, so history scoping is phone-based, not
    session-id based.
    """
    phone_filter = _normalize_history_phone(phone_number)
    if not phone_filter:
        return []

    rows = read_archived_messages(from_number=phone_filter, limit=max(limit * 5, limit))
    history: list[dict] = []
    for row in reversed(rows):
        text = row.get("raw_text") or row.get("audio_transcription") or row.get("image_analysis") or ""
        if not text:
            continue
        role = "assistant" if row.get("direction") == "outbound" else "user"
        history.append({"role": role, "content": text})
    return history[-limit:]


def archive_whatsapp_payload(payload: dict) -> None:
    account_key = resolve_storage_account_key()
    message_id = str(payload.get("message_id") or "").strip() or f"wa-{int(time.time() * 1000)}"
    normalized_from = normalize_external_user_id(
        str(payload.get("from_") or payload.get("from") or payload.get("peer_number") or "")
    )
    extras = _split_extras(payload, _MESSAGE_BASE_FIELDS)

    with _session_scope(write=True) as session:
        account = _get_account(session, account_key, create=True)
        if account is None:
            return

        row = session.execute(
            select(_WhatsAppMessage).where(
                _WhatsAppMessage.account_id == account.id,
                _WhatsAppMessage.message_id == message_id,
            )
        ).scalar_one_or_none()

        if row is None:
            row = _WhatsAppMessage(account_id=account.id, message_id=message_id)
            session.add(row)

        row.direction = str(payload.get("direction") or "inbound")
        row.delivery_status = str(payload.get("delivery_status") or "received")
        row.from_ = str(payload.get("from_") or payload.get("from") or "")
        row.normalized_from = normalized_from
        row.peer_number = str(payload.get("peer_number") or "")
        row.jid = str(payload.get("jid") or "")
        row.message_type = str(payload.get("type") or "text")
        row.received_at = str(payload.get("received_at") or _utcnow().isoformat())
        row.raw_text = payload.get("raw_text")
        row.audio_transcription = payload.get("audio_transcription")
        row.image_analysis = payload.get("image_analysis")
        row.media_path = payload.get("media_path")
        row.mime_type = payload.get("mime_type")
        row.source_channel = str(payload.get("source_channel") or "whatsapp")
        row.reply_to_message_id = payload.get("reply_to_message_id")
        row.chat_jid = str(payload.get("chat_jid") or "")
        row.sender_jid = str(payload.get("sender_jid") or "")
        row.session_id = str(payload.get("session_id") or "")
        row.extra_json = _json_dumps(extras)


def _message_row_to_dict(row: _WhatsAppMessage) -> dict:
    payload = {
        "direction": row.direction,
        "delivery_status": row.delivery_status,
        "from_": row.from_,
        "peer_number": row.peer_number,
        "jid": row.jid,
        "type": row.message_type,
        "received_at": row.received_at,
        "raw_text": row.raw_text,
        "audio_transcription": row.audio_transcription,
        "image_analysis": row.image_analysis,
        "media_path": row.media_path,
        "mime_type": row.mime_type,
        "source_channel": row.source_channel,
        "message_id": row.message_id,
        "reply_to_message_id": row.reply_to_message_id,
        "chat_jid": row.chat_jid,
        "sender_jid": row.sender_jid,
        "session_id": row.session_id,
    }
    payload.update(_json_loads(row.extra_json, {}))
    return payload


def read_archived_messages(
    *,
    from_number: str | None = None,
    chat_jid: str | None = None,
    limit: int = 20,
    account_key: str | None = None,
) -> list[dict]:
    safe_limit = max(1, int(limit))
    normalized_from = normalize_external_user_id(from_number or "") if from_number else ""
    scoped_account = resolve_storage_account_key(account_key)

    with _session_scope(write=False) as session:
        stmt = (
            select(_WhatsAppMessage)
            .join(_WhatsAppAccount, _WhatsAppMessage.account_id == _WhatsAppAccount.id)
            .where(_WhatsAppAccount.account_key == scoped_account)
        )
        if normalized_from and not chat_jid:
            # For contact-scoped queries, include the full direct chat timeline
            # (inbound and outbound) while skipping group messages from participants.
            direct_chat_jid = f"{normalized_from}@s.whatsapp.net"
            stmt = stmt.where(
                or_(
                    _WhatsAppMessage.chat_jid == direct_chat_jid,
                    (
                        (_WhatsAppMessage.normalized_from == normalized_from)
                        & (~_WhatsAppMessage.chat_jid.like("%@g.us"))
                    ),
                )
            )
        elif normalized_from:
            stmt = stmt.where(_WhatsAppMessage.normalized_from == normalized_from)
        if chat_jid:
            stmt = stmt.where(_WhatsAppMessage.chat_jid == str(chat_jid))

        # Sort by event time first so backfilled history does not hide newer messages.
        rows = session.execute(
            stmt.order_by(_WhatsAppMessage.received_at.desc(), _WhatsAppMessage.id.desc()).limit(safe_limit)
        ).scalars().all()

    return [_message_row_to_dict(row) for row in reversed(rows)]


def iter_archived_messages(*, account_key: str | None = None) -> list[dict]:
    scoped_account = resolve_storage_account_key(account_key)
    with _session_scope(write=False) as session:
        stmt = (
            select(_WhatsAppMessage)
            .join(_WhatsAppAccount, _WhatsAppMessage.account_id == _WhatsAppAccount.id)
            .where(_WhatsAppAccount.account_key == scoped_account)
            .order_by(_WhatsAppMessage.id.asc())
        )
        rows = session.execute(stmt).scalars().all()
    return [_message_row_to_dict(row) for row in rows]


def _contact_row_to_dict(row: _WhatsAppContact) -> dict:
    payload = {
        "name": row.name,
        "phone": row.phone,
        "note": row.note,
        "can_receive": bool(row.can_receive),
        "auto_reply_allowed": bool(row.auto_reply_allowed),
    }
    payload.update(_json_loads(row.extra_json, {}))
    return payload


def _group_row_to_dict(row: _WhatsAppGroup) -> dict:
    payload = {
        "name": row.name,
        "jid": row.jid,
        "note": row.note,
        "can_receive": bool(row.can_receive),
        "auto_reply_allowed": bool(row.auto_reply_allowed),
    }
    payload.update(_json_loads(row.extra_json, {}))
    return payload


def load_whatsapp_directory(*, account_key: str | None = None) -> dict:
    scoped_account = resolve_storage_account_key(account_key)
    with _session_scope(write=False) as session:
        account = _get_account(session, scoped_account, create=False)
        if account is None:
            return {"contacts": [], "groups": []}

        contacts = session.execute(
            select(_WhatsAppContact).where(_WhatsAppContact.account_id == account.id).order_by(_WhatsAppContact.id.asc())
        ).scalars().all()
        groups = session.execute(
            select(_WhatsAppGroup).where(_WhatsAppGroup.account_id == account.id).order_by(_WhatsAppGroup.id.asc())
        ).scalars().all()

    return {
        "contacts": [_contact_row_to_dict(row) for row in contacts],
        "groups": [_group_row_to_dict(row) for row in groups],
    }


def save_whatsapp_directory(directory: dict, *, account_key: str | None = None) -> None:
    scoped_account = resolve_storage_account_key(account_key)
    contacts = [item for item in (directory.get("contacts") or []) if isinstance(item, dict)]
    groups = [item for item in (directory.get("groups") or []) if isinstance(item, dict)]

    with _session_scope(write=True) as session:
        account = _get_account(session, scoped_account, create=True)
        if account is None:
            return

        session.execute(delete(_WhatsAppContact).where(_WhatsAppContact.account_id == account.id))
        session.execute(delete(_WhatsAppGroup).where(_WhatsAppGroup.account_id == account.id))

        for item in contacts:
            phone = normalize_external_user_id(str(item.get("phone") or ""))
            if not phone:
                continue
            name = " ".join(str(item.get("name") or "").split()) or phone
            note = str(item.get("note") or "")
            payload = dict(item)
            payload["name"] = name
            payload["phone"] = phone
            payload["note"] = note

            session.add(
                _WhatsAppContact(
                    account_id=account.id,
                    name=name,
                    name_normalized=_normalize_name(name),
                    phone=phone,
                    note=note,
                    can_receive=_as_bool(item.get("can_receive"), default=False),
                    auto_reply_allowed=_as_bool(item.get("auto_reply_allowed"), default=False),
                    extra_json=_json_dumps(_split_extras(payload, _CONTACT_BASE_FIELDS)),
                )
            )

        for item in groups:
            jid = "".join(str(item.get("jid") or "").split())
            if not jid:
                continue
            name = " ".join(str(item.get("name") or "").split()) or jid
            note = str(item.get("note") or "")
            payload = dict(item)
            payload["name"] = name
            payload["jid"] = jid
            payload["note"] = note

            session.add(
                _WhatsAppGroup(
                    account_id=account.id,
                    name=name,
                    name_normalized=_normalize_name(name),
                    jid=jid,
                    note=note,
                    can_receive=_as_bool(item.get("can_receive"), default=False),
                    auto_reply_allowed=_as_bool(item.get("auto_reply_allowed"), default=False),
                    extra_json=_json_dumps(_split_extras(payload, _GROUP_BASE_FIELDS)),
                )
            )


def analyze_image(path: str, caption: str = "") -> str:
    caption = (caption or "").strip()
    if caption:
        return caption
    return f"[image received: {Path(path).name}]"


def transcribe_audio(path: str) -> str:
    return f"[audio received: {Path(path).name}]"


def ingest_whatsapp_worker_report(_payload: dict) -> None:
    return None


def _access_row_to_dict(row: _WhatsAppAccessRule) -> dict:
    payload = {
        "source": row.source,
        "external_user_id": row.external_user_id,
        "allowed_agent_names": _json_loads(row.allowed_agent_names_json, []),
        "default_agent_name": row.default_agent_name,
        "access_level": row.access_level,
    }
    payload.update(_json_loads(row.extra_json, {}))
    if not isinstance(payload.get("allowed_agent_names"), list):
        payload["allowed_agent_names"] = []
    return payload


def list_user_agent_access(*, source: str, account_key: str | None = None) -> list[dict]:
    scoped_account = resolve_storage_account_key(account_key)
    with _session_scope(write=False) as session:
        account = _get_account(session, scoped_account, create=False)
        if account is None:
            return []

        rows = session.execute(
            select(_WhatsAppAccessRule)
            .where(
                _WhatsAppAccessRule.account_id == account.id,
                _WhatsAppAccessRule.source == source,
            )
            .order_by(_WhatsAppAccessRule.id.asc())
        ).scalars().all()
    return [_access_row_to_dict(row) for row in rows]


def get_user_agent_access(source: str, external_user_id: str) -> dict | None:
    for row in list_user_agent_access(source=source):
        if row.get("external_user_id") == external_user_id:
            return row
    return None


def upsert_user_agent_access(
    source: str,
    external_user_id: str,
    *,
    allowed_agent_names: list[str] | None = None,
    default_agent_name: str | None = None,
    access_level: str = "limited",
) -> dict:
    normalized_target = str(external_user_id or "").strip()
    scoped_account = resolve_storage_account_key()

    with _session_scope(write=True) as session:
        account = _get_account(session, scoped_account, create=True)
        if account is None:
            return {
                "source": source,
                "external_user_id": normalized_target,
                "allowed_agent_names": list(allowed_agent_names or []),
                "default_agent_name": default_agent_name or "",
                "access_level": access_level or "limited",
            }

        row = session.execute(
            select(_WhatsAppAccessRule).where(
                _WhatsAppAccessRule.account_id == account.id,
                _WhatsAppAccessRule.source == source,
                _WhatsAppAccessRule.external_user_id == normalized_target,
            )
        ).scalar_one_or_none()
        if row is None:
            row = _WhatsAppAccessRule(
                account_id=account.id,
                source=source,
                external_user_id=normalized_target,
            )
            session.add(row)

        current_allowed = _json_loads(row.allowed_agent_names_json, [])
        row.allowed_agent_names_json = _json_dumps(list(allowed_agent_names or current_allowed or []))
        row.default_agent_name = default_agent_name or row.default_agent_name or ""
        row.access_level = access_level or row.access_level or "limited"

        session.flush()
        return _access_row_to_dict(row)


def delete_user_agent_access(source: str, external_user_id: str) -> bool:
    scoped_account = resolve_storage_account_key()
    normalized_target = str(external_user_id or "").strip()

    with _session_scope(write=True) as session:
        account = _get_account(session, scoped_account, create=False)
        if account is None:
            return False

        row = session.execute(
            select(_WhatsAppAccessRule).where(
                _WhatsAppAccessRule.account_id == account.id,
                _WhatsAppAccessRule.source == source,
                _WhatsAppAccessRule.external_user_id == normalized_target,
            )
        ).scalar_one_or_none()
        if row is None:
            return False
        session.delete(row)
        return True


def reset_storage_for_tests(*, account_key: str | None = None) -> None:
    scoped_account = resolve_storage_account_key(account_key)
    with _session_scope(write=True) as session:
        account = _get_account(session, scoped_account, create=False)
        if account is None:
            return
        session.execute(delete(_WhatsAppMessage).where(_WhatsAppMessage.account_id == account.id))
        session.execute(delete(_WhatsAppContact).where(_WhatsAppContact.account_id == account.id))
        session.execute(delete(_WhatsAppGroup).where(_WhatsAppGroup.account_id == account.id))
        session.execute(delete(_WhatsAppAccessRule).where(_WhatsAppAccessRule.account_id == account.id))
        session.execute(delete(_WhatsAppAccount).where(_WhatsAppAccount.id == account.id))


def get_active_agents() -> list[dict]:
    if _HOST_HOOKS.get_active_agents is None:
        return []
    return _HOST_HOOKS.get_active_agents()


def resolve_effective_agent(agent: dict, access_level: str, agents: list[dict]) -> dict | None:
    if _HOST_HOOKS.resolve_effective_agent is None:
        return agent
    return _HOST_HOOKS.resolve_effective_agent(agent, access_level, agents)


def execute_task(*args: Any, **kwargs: Any) -> tuple[str, str | None]:
    if _HOST_HOOKS.execute_task is None:
        raise RuntimeError("Host runtime is not configured for auto-reply execution")
    return _HOST_HOOKS.execute_task(*args, **kwargs)
