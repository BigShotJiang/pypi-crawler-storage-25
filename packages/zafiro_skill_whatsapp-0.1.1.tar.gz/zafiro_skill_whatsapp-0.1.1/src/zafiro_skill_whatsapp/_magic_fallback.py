"""Fallback module compatible with python-magic API used by neonize.

This fallback is intentionally small and heuristic-based. It exists to keep the
skill importable in environments where libmagic is unavailable or has an
architecture mismatch.
"""

from __future__ import annotations

import mimetypes
from pathlib import Path


def _as_bytes(data) -> bytes:
    if data is None:
        return b""
    if isinstance(data, bytes):
        return data
    if isinstance(data, bytearray):
        return bytes(data)
    if isinstance(data, memoryview):
        return bytes(data.tobytes())
    if isinstance(data, str):
        return data.encode("utf-8", errors="ignore")
    return bytes(data)


def _detect_mime_from_bytes(data: bytes) -> str:
    if not data:
        return "application/octet-stream"

    head = data[:64]

    if head.startswith(b"\x89PNG\r\n\x1a\n"):
        return "image/png"
    if head.startswith(b"\xff\xd8\xff"):
        return "image/jpeg"
    if head.startswith((b"GIF87a", b"GIF89a")):
        return "image/gif"
    if head.startswith(b"RIFF") and len(head) >= 12 and head[8:12] == b"WEBP":
        return "image/webp"
    if head.startswith(b"BM"):
        return "image/bmp"
    if head.startswith((b"II*\x00", b"MM\x00*")):
        return "image/tiff"

    if head.startswith(b"OggS"):
        return "audio/ogg"
    if head.startswith((b"ID3",)):
        return "audio/mpeg"
    if len(head) >= 2 and head[0] == 0xFF and (head[1] & 0xE0) == 0xE0:
        return "audio/mpeg"
    if head.startswith(b"RIFF") and len(head) >= 12 and head[8:12] == b"WAVE":
        return "audio/wav"
    if head.startswith(b"fLaC"):
        return "audio/flac"

    if head.startswith(b"\x1a\x45\xdf\xa3"):
        return "video/webm"
    if len(head) >= 12 and head[4:8] == b"ftyp":
        brand = head[8:12]
        if brand in {b"M4A ", b"M4B ", b"M4P ", b"M4V ", b"mp4a"}:
            return "audio/mp4"
        return "video/mp4"

    if head.startswith(b"%PDF-"):
        return "application/pdf"
    if head.startswith(b"PK\x03\x04"):
        return "application/zip"
    if head.startswith((b"{", b"[")):
        return "application/json"

    return "application/octet-stream"


def _describe_mime(mime: str) -> str:
    if mime.startswith("image/"):
        return "image data"
    if mime.startswith("audio/"):
        return "audio data"
    if mime.startswith("video/"):
        return "video data"
    if mime == "application/pdf":
        return "PDF document"
    if mime == "application/zip":
        return "Zip archive data"
    if mime == "application/json":
        return "JSON text data"
    return "data"


def from_buffer(data, mime: bool = False):
    payload = _as_bytes(data)
    detected = _detect_mime_from_bytes(payload)
    if mime:
        return detected
    return _describe_mime(detected)


def from_file(filename: str, mime: bool = False):
    file_path = Path(str(filename or "")).expanduser()
    raw = b""
    if file_path.exists() and file_path.is_file():
        try:
            raw = file_path.read_bytes()[:8192]
        except Exception:
            raw = b""

    detected = _detect_mime_from_bytes(raw)
    guessed, _encoding = mimetypes.guess_type(str(file_path))
    if detected == "application/octet-stream" and guessed:
        detected = guessed

    if mime:
        return detected or "application/octet-stream"
    return _describe_mime(detected or "application/octet-stream")


class Magic:
    """Small compatibility wrapper for python-magic's Magic class."""

    def __init__(self, mime: bool = False, *args, **kwargs):
        self.mime = bool(mime)

    def from_buffer(self, data):
        return from_buffer(data, mime=self.mime)

    def from_file(self, filename):
        return from_file(filename, mime=self.mime)
