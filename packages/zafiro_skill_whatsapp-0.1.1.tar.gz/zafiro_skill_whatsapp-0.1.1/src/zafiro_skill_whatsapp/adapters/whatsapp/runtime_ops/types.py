from typing import Literal, TypedDict


class WhatsAppPayload(TypedDict):
    direction: Literal["inbound", "outbound"]
    delivery_status: str
    from_: str
    peer_number: str | None
    jid: str
    type: str
    received_at: str
    raw_text: str | None
    audio_transcription: str | None
    image_analysis: str | None
    media_path: str | None
    mime_type: str | None
    source_channel: Literal["whatsapp"]
    message_id: str
    reply_to_message_id: str | None
    chat_jid: str
    sender_jid: str
    session_id: str
