from collections import deque
from dataclasses import dataclass, field
from pathlib import Path
import threading

from zafiro_skill_whatsapp.adapters.whatsapp.runtime_ops.types import WhatsAppPayload
from zafiro_skill_whatsapp.adapters.whatsapp.runtime_ops.config import (
    WHATSAPP_ACTIVE_ACCOUNT_PATH,
    WHATSAPP_SESSION_NAME,
)
from zafiro_skill_whatsapp.integrations import build_whatsapp_session_id, load_session_history

from neonize.client import NewClient
from neonize.proto.Neonize_pb2 import JID, Message as IncomingMessage


def normalize_number(number: str) -> str:
    return number.strip().lstrip("+").replace(" ", "").replace("-", "")


def build_jid(number: str, server: str = "s.whatsapp.net") -> JID:
    return JID(
        User=number,
        Server=server,
        RawAgent=0,
        Device=0,
        Integrator=0,
        IsEmpty=False,
    )


def build_chat_jid(target: str) -> JID:
    clean = "".join((target or "").split())
    if clean.endswith("@g.us"):
        return build_jid(clean[:-5], server="g.us")
    if clean.endswith("@s.whatsapp.net"):
        return build_jid(clean[:-15], server="s.whatsapp.net")
    return build_jid(normalize_number(clean), server="s.whatsapp.net")


def jid_to_str(jid: JID) -> str:
    return f"{jid.User}@{jid.Server}"


def contact_session_id(phone_number: str) -> str:
    return build_whatsapp_session_id(phone_number)


@dataclass(slots=True)
class WhatsAppRuntime:
    session_name: str = WHATSAPP_SESSION_NAME
    qr_path: Path = Path("logs/whatsapp_qr.png")
    pid_path: Path = Path("logs/whatsapp.pid")
    client: NewClient | None = None
    connected: threading.Event = field(default_factory=threading.Event)
    message_buffer: deque[WhatsAppPayload] = field(default_factory=deque)
    message_cache: dict[str, IncomingMessage] = field(default_factory=dict)
    buffer_limit: int = 100
    active_account_key: str = ""


runtime = WhatsAppRuntime()


def get_client() -> NewClient | None:
    return runtime.client


def set_client(client: NewClient | None) -> None:
    runtime.client = client


def _active_account_path() -> Path:
    path = Path(WHATSAPP_ACTIVE_ACCOUNT_PATH)
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def set_active_account_key(phone_number: str) -> str:
    normalized = normalize_number(str(phone_number or ""))
    runtime.active_account_key = normalized
    if normalized:
        try:
            _active_account_path().write_text(normalized, encoding="utf-8")
        except Exception:
            pass
    return normalized


def get_active_account_key() -> str:
    if runtime.active_account_key:
        return runtime.active_account_key

    client = get_client()
    if client is None:
        try:
            persisted = _active_account_path().read_text(encoding="utf-8").strip()
        except Exception:
            return ""
        return normalize_number(persisted)

    try:
        me = client.get_me()
    except Exception:
        return ""

    jid = getattr(me, "JID", None)
    if jid is None:
        return ""

    user = str(getattr(jid, "User", "") or "")
    if not user:
        try:
            persisted = _active_account_path().read_text(encoding="utf-8").strip()
        except Exception:
            return ""
        return normalize_number(persisted)

    return set_active_account_key(user)


def cache_incoming_message(payload: WhatsAppPayload, message: IncomingMessage) -> None:
    while len(runtime.message_buffer) >= runtime.buffer_limit:
        oldest = runtime.message_buffer.popleft()
        runtime.message_cache.pop(oldest["message_id"], None)
    runtime.message_buffer.append(payload)
    runtime.message_cache[payload["message_id"]] = message


def get_incoming_message(message_id: str) -> IncomingMessage | None:
    return runtime.message_cache.get(message_id)


def load_contact_history(phone_number: str, limit: int = 10) -> list[dict]:
    return load_session_history(phone_number, limit=limit)
