"""Runtime operations for WhatsApp adapter."""

__all__: list[str] = []
