import logging
import os
from pathlib import Path
import subprocess
import threading

import segno

from zafiro_skill_whatsapp.adapters.whatsapp.message_ops.inbound import handle_message
from zafiro_skill_whatsapp.adapters.whatsapp.contacts_ops.discovery import sync_joined_groups
from zafiro_skill_whatsapp.adapters.whatsapp.message_ops.outbound import send_available_presence
from zafiro_skill_whatsapp.adapters.whatsapp.message_ops.queue import process_pending_messages
from zafiro_skill_whatsapp.adapters.whatsapp.sync_ops.history import handle_history_sync_event
from zafiro_skill_whatsapp.adapters.whatsapp.runtime_ops.state import get_client, runtime, set_client
from zafiro_skill_whatsapp.adapters.whatsapp.runtime_ops.config import (
    WHATSAPP_DEVICE_OS,
    WHATSAPP_DEVICE_PLATFORM,
    WHATSAPP_DEVICE_VERSION,
)
from zafiro_skill_whatsapp.integrations import ensure_whatsapp_storage_schema

from neonize.client import NewClient
from neonize.events import ConnectedEv, DisconnectedEv, HistorySyncEv, MessageEv, QREv
from neonize.proto.waCompanionReg.WAWebProtobufsCompanionReg_pb2 import DeviceProps as _WebDeviceProps

try:
    # Prefer the richer companion proto: it exposes extra HistorySyncConfig
    # capabilities (e.g. supportGroupHistory/onDemandReady) absent in the
    # WAWeb-flavored subset.
    from neonize.proto.waCompanionReg.WACompanionReg_pb2 import DeviceProps as _CompanionDeviceProps
except Exception:  # pragma: no cover - fallback for older neonize builds
    _CompanionDeviceProps = None


DeviceProps = _CompanionDeviceProps or _WebDeviceProps

logger = logging.getLogger(__name__)

_outbox_thread: threading.Thread | None = None
_outbox_stop = threading.Event()


def _prepare_session_store(session_name: str) -> str:
    """Ensure the Neonize session store path exists and is writable."""
    session_path = Path(session_name).expanduser()
    parent_dir = session_path.parent
    parent_dir.mkdir(parents=True, exist_ok=True)

    if not os.access(parent_dir, os.W_OK):
        raise PermissionError(f"Directory is not writable: {parent_dir}")
    if session_path.exists() and not os.access(session_path, os.W_OK):
        raise PermissionError(f"Session DB is not writable: {session_path}")

    return str(session_path)


def _parse_device_version(raw_version: str) -> DeviceProps.AppVersion:
    parts = [segment.strip() for segment in (raw_version or "").split(".") if segment.strip()]
    numbers = []
    for segment in parts[:5]:
        try:
            numbers.append(int(segment))
        except ValueError:
            numbers.append(0)
    while len(numbers) < 5:
        numbers.append(0)

    version_fields = {field.name for field in DeviceProps.AppVersion.DESCRIPTOR.fields}
    payload = {}
    if "primary" in version_fields:
        payload["primary"] = numbers[0]
    if "secondary" in version_fields:
        payload["secondary"] = numbers[1]
    if "tertiary" in version_fields:
        payload["tertiary"] = numbers[2]
    if "quaternary" in version_fields:
        payload["quaternary"] = numbers[3]
    if "quinary" in version_fields:
        payload["quinary"] = numbers[4]
    return DeviceProps.AppVersion(**payload)


def _resolve_platform_type(platform_name: str):
    normalized = (platform_name or "CHROME").strip().upper()
    return getattr(DeviceProps.PlatformType, normalized, DeviceProps.PlatformType.CHROME)


def _build_history_sync_config() -> DeviceProps.HistorySyncConfig | None:
    cfg_cls = getattr(DeviceProps, "HistorySyncConfig", None)
    if cfg_cls is None:
        return None

    fields = {field.name for field in cfg_cls.DESCRIPTOR.fields}
    preferred = {
        "fullSyncDaysLimit": 3650,
        "fullSyncSizeMbLimit": 2048,
        "storageQuotaMb": 2048,
        "inlineInitialPayloadInE2EeMsg": True,
        "recentSyncDaysLimit": 365,
        "supportCallLogHistory": True,
        "supportBotUserAgentChatHistory": True,
        "supportCagReactionsAndPolls": True,
        "supportBizHostedMsg": True,
        "supportRecentSyncChunkMessageCountTuning": True,
        "supportHostedGroupMsg": True,
        "supportFbidBotChatHistory": True,
        "supportAddOnHistorySyncMigration": True,
        "supportMessageAssociation": True,
        "supportGroupHistory": True,
        "onDemandReady": True,
        "supportGuestChat": True,
        "completeOnDemandReady": True,
        "thumbnailSyncDaysLimit": 365,
        "initialSyncMaxMessagesPerChat": 4000,
        "supportManusHistory": True,
        "supportHatchHistory": True,
    }
    payload = {key: value for key, value in preferred.items() if key in fields}
    if not payload:
        return None
    return cfg_cls(**payload)


def build_device_props() -> DeviceProps:
    history_sync_cfg = _build_history_sync_config()
    payload = dict(
        os=WHATSAPP_DEVICE_OS,
        version=_parse_device_version(WHATSAPP_DEVICE_VERSION),
        platformType=_resolve_platform_type(WHATSAPP_DEVICE_PLATFORM),
        requireFullSync=False,
    )
    if history_sync_cfg is not None:
        payload["historySyncConfig"] = history_sync_cfg
    return DeviceProps(**payload)


def _on_qr(client: NewClient, event: QREv) -> None:
    try:
        runtime.qr_path.parent.mkdir(parents=True, exist_ok=True)
        qr = segno.make(event.Codes, error="L")
        qr.save(str(runtime.qr_path), scale=10)
        logger.info("QR code saved -> %s", runtime.qr_path.resolve())
        subprocess.Popen(["open", str(runtime.qr_path)], close_fds=True)
    except Exception as error:
        logger.error("Failed to generate QR image: %s", error)


def _on_connected(client: NewClient, event: ConnectedEv) -> None:
    from zafiro_skill_whatsapp.adapters.whatsapp.runtime_ops.state import set_active_account_key

    runtime.connected.set()
    try:
        me = client.get_me()
        set_active_account_key(str(getattr(me.JID, "User", "") or ""))
    except Exception as error:
        logger.debug("Could not resolve active WhatsApp account key: %s", error)

    try:
        ensure_whatsapp_storage_schema()
    except Exception as error:
        logger.warning("Could not ensure WhatsApp storage schema: %s", error)

    send_available_presence()
    try:
        synced = sync_joined_groups(client)
        logger.info("WhatsApp group sync completed - %s groups cached", len(synced))
    except Exception as error:
        logger.warning("WhatsApp group sync failed: %s", error)
    _start_outbox_worker()
    logger.info("WhatsApp connected - JID: %s", client.get_me().JID)


def _on_disconnected(client: NewClient, event: DisconnectedEv) -> None:
    runtime.connected.clear()
    _outbox_stop.set()
    if get_client() is client:
        set_client(None)
    logger.warning("WhatsApp disconnected")


def _outbox_loop() -> None:
    while not _outbox_stop.is_set():
        client = get_client()
        if client is not None and runtime.connected.is_set():
            outbound = __import__(
                "zafiro_skill_whatsapp.adapters.whatsapp.message_ops.outbound",
                fromlist=["send_message", "reply_to_message"],
            )
            process_pending_messages(
                lambda number, text: outbound.send_message(number, text),
                lambda message_id, text: outbound.reply_to_message(message_id, text),
                limit=5,
            )
        _outbox_stop.wait(2.0)


def _start_outbox_worker() -> None:
    global _outbox_thread
    if _outbox_thread is not None and _outbox_thread.is_alive():
        return
    _outbox_stop.clear()
    _outbox_thread = threading.Thread(target=_outbox_loop, daemon=True, name="whatsapp-outbox-worker")
    _outbox_thread.start()


def register_handlers(client: NewClient) -> None:
    client.event(QREv)(_on_qr)
    client.event(ConnectedEv)(_on_connected)
    client.event(DisconnectedEv)(_on_disconnected)
    client.event(HistorySyncEv)(handle_history_sync_event)
    client.event(MessageEv)(handle_message)


def init_client() -> None:
    device_props = build_device_props()
    runtime.session_name = _prepare_session_store(runtime.session_name)
    client = NewClient(runtime.session_name, props=device_props)
    set_client(client)
    register_handlers(client)
    logger.info(
        "Starting WhatsApp client '%s' - scan QR if prompted (platform=%s, os=%s, version=%s)",
        runtime.session_name,
        WHATSAPP_DEVICE_PLATFORM,
        WHATSAPP_DEVICE_OS,
        WHATSAPP_DEVICE_VERSION,
    )
    client.connect()


def start() -> None:
    runtime.pid_path.parent.mkdir(parents=True, exist_ok=True)
    runtime.pid_path.write_text(str(os.getpid()))
    init_client()


def start_in_thread() -> threading.Thread:
    thread = threading.Thread(
        target=init_client,
        daemon=True,
        name="whatsapp-client",
    )
    thread.start()
    return thread


def disconnect() -> None:
    client = get_client()
    if client is not None:
        client.disconnect()
    _outbox_stop.set()
    runtime.connected.clear()
    set_client(None)
