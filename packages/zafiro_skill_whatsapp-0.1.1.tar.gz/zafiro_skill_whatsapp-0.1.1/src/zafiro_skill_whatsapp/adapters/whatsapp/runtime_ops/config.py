"""WhatsApp channel configuration (Neonize + outbox + contacts)."""

from __future__ import annotations

import importlib
import os
from pathlib import Path


def _load_dotenv_if_available() -> None:
    try:
        dotenv = importlib.import_module("dotenv")
    except ModuleNotFoundError:
        return
    load_dotenv = getattr(dotenv, "load_dotenv", None)
    if callable(load_dotenv):
        load_dotenv()


_load_dotenv_if_available()


def _env_bool(name: str, default: bool) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


# Session / binary identity
WHATSAPP_SESSION_NAME = os.getenv(
    "WHATSAPP_SESSION_NAME", "./data/whatsapp/ia_orchestrator"
)
WHATSAPP_DEVICE_PLATFORM = os.getenv("WHATSAPP_DEVICE_PLATFORM", "CHROME")
WHATSAPP_DEVICE_OS = os.getenv("WHATSAPP_DEVICE_OS", "Chrome")
WHATSAPP_DEVICE_VERSION = os.getenv("WHATSAPP_DEVICE_VERSION", "136.0.0")

# Paths
WHATSAPP_OUTBOX_DIR = os.getenv("WHATSAPP_OUTBOX_DIR", "./data/whatsapp_outbox")
WHATSAPP_CONTACTS_PATH = os.getenv(
    "WHATSAPP_CONTACTS_PATH", "./data/whatsapp_contacts.json"
)
WHATSAPP_ACCESS_RULES_PATH = os.getenv(
    "WHATSAPP_ACCESS_RULES_PATH", "./data/whatsapp_access_rules.json"
)
WHATSAPP_MEDIA_DIR = os.getenv("WHATSAPP_MEDIA_DIR", "./media")
WHATSAPP_ACTIVE_ACCOUNT_PATH = os.getenv(
    "WHATSAPP_ACTIVE_ACCOUNT_PATH", "./logs/whatsapp_active_account.txt"
)
MESSAGE_ARCHIVE_PATH = os.getenv(
    "MESSAGE_ARCHIVE_PATH", "./data/message_archive/whatsapp_messages.jsonl"
)
WHATSAPP_LOCAL_DB_PATH = os.getenv("WHATSAPP_LOCAL_DB_PATH", "./data/whatsapp_storage.sqlite3")
RECENT_SESSION_HISTORY_LIMIT = int(os.getenv("RECENT_SESSION_HISTORY_LIMIT", "10"))

# Downstream forwarding (optional HTTP webhook)
WHATSAPP_FORWARD_URL = os.getenv("WHATSAPP_FORWARD_URL", "")
WHATSAPP_FORWARD_SECRET = os.getenv("WHATSAPP_FORWARD_SECRET", "")

# Presence / typing simulation
WHATSAPP_SIMULATE_TYPING = _env_bool("WHATSAPP_SIMULATE_TYPING", True)
WHATSAPP_TYPING_MIN_MS = int(os.getenv("WHATSAPP_TYPING_MIN_MS", "800"))
WHATSAPP_TYPING_MAX_MS = int(os.getenv("WHATSAPP_TYPING_MAX_MS", "3500"))
WHATSAPP_TYPING_MS_PER_CHAR = int(os.getenv("WHATSAPP_TYPING_MS_PER_CHAR", "45"))
WHATSAPP_SEND_AVAILABLE_PRESENCE = _env_bool("WHATSAPP_SEND_AVAILABLE_PRESENCE", True)
WHATSAPP_AUTO_MARK_READ = _env_bool("WHATSAPP_AUTO_MARK_READ", True)

# Auto-reply policy
WHATSAPP_AUTO_REPLY_ENABLED = _env_bool("WHATSAPP_AUTO_REPLY_ENABLED", True)


def _resolve_session_path(raw_path: str) -> str:
    """Resolve WhatsApp session path to an absolute location from current cwd."""
    session_path = Path(raw_path).expanduser()
    if session_path.is_absolute():
        return str(session_path)
    return str((Path.cwd() / session_path).resolve())


WHATSAPP_SESSION_NAME = _resolve_session_path(WHATSAPP_SESSION_NAME)
