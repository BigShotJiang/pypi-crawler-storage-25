import logging

from zafiro_skill_whatsapp.adapters.whatsapp import start


def main() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )
    start()


if __name__ == "__main__":
    main()