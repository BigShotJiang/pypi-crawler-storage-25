"""Organized contact and policy operations for WhatsApp adapter."""

__all__: list[str] = []
