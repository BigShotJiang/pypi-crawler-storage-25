"""Auto-discovery helpers for WhatsApp contacts/groups."""

from __future__ import annotations

from zafiro_skill_whatsapp.integrations import normalize_external_user_id
from zafiro_skill_whatsapp.adapters.whatsapp.contacts_ops.directory import (
    _load_groups,
    _save_groups,
    normalize_group_jid,
    upsert_contact,
    upsert_group,
)


def remember_contact(phone: str, name: str = "", note: str = "auto-discovered") -> dict | None:
    normalized_phone = normalize_external_user_id(phone)
    if not normalized_phone:
        return None
    return upsert_contact(name or normalized_phone, normalized_phone, replace=True, note=note)


def remember_group(jid: str, name: str = "", note: str = "auto-discovered") -> dict | None:
    normalized_jid = normalize_group_jid(jid)
    if not normalized_jid:
        return None
    return upsert_group(name or normalized_jid, normalized_jid, replace=True, note=note)


def sync_joined_groups(client) -> list[dict]:
    groups = client.get_joined_groups()
    # Preserve manual outbound/legacy flags keyed by JID
    # so they survive re-syncs on reconnect.
    existing_by_jid = {g.get("jid"): g for g in _load_groups() if g.get("jid")}
    preserved_keys = ("can_receive", "auto_reply_allowed")

    synced: list[dict] = []
    for group in groups:
        jid = f"{group.JID.User}@{group.JID.Server}"
        name = getattr(group.GroupName, "Name", "") or jid
        entry = {"jid": jid, "name": name, "note": "synced-from-whatsapp"}
        prior = existing_by_jid.get(jid)
        if prior:
            for key in preserved_keys:
                if key in prior:
                    entry[key] = prior[key]
        synced.append(entry)

    # Replace the full groups list so stale groups from a previous linked number
    # are removed. Contacts (personal numbers) are preserved, and manual flags
    # on remaining groups are retained.
    _save_groups(synced)
    return synced
