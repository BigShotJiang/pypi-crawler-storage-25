"""WhatsApp outbound and inbound policy helpers."""

from __future__ import annotations

import logging

from zafiro_skill_whatsapp.integrations import (
    delete_user_agent_access,
    get_user_agent_access,
    list_user_agent_access,
    normalize_external_user_id,
    upsert_user_agent_access,
)
from zafiro_skill_whatsapp.adapters.whatsapp.contacts_ops.directory import (
    _load_contacts,
    _load_directory,
    _load_groups,
    _normalize_name,
    _save_directory,
    normalize_autoreply_target,
    normalize_group_jid,
    resolve_contact,
    resolve_group,
)

logger = logging.getLogger(__name__)
_legacy_autoreply_migrated = False


def get_wa_setting(_key: str, default: str = "") -> str:
    """Local runtime policy placeholder for compatibility."""
    return default


def set_wa_setting(_key: str, _value: str) -> None:
    """Local runtime policy placeholder for compatibility."""
    return None


def has_reply_whitelist() -> bool:
    """Return True if at least one WhatsApp actor is linked in user_agent_access."""
    return bool(list_user_agent_access(source="whatsapp"))


def is_autoreply_enabled() -> bool:
    """Legacy helper kept for compatibility.

    Auto-reply is now controlled by explicit entries in user_agent_access.
    """
    return has_reply_whitelist()


def is_send_allowed(target: str) -> bool:
    """Return True if the contact or group has can_receive=True in the directory.

    target — phone number (E.164 digits) or group JID / alias.
    Admins and local/API channels bypass this check; it only applies to
    proactive outbound WhatsApp sends by agents.
    """
    target = (target or "").strip()
    if not target:
        return False

    # Check contacts by phone
    number = normalize_external_user_id(target)
    if number:
        for contact in _load_contacts():
            if contact.get("phone") == number:
                return bool(contact.get("can_receive", False))

    # Check groups by JID or alias
    norm_jid = normalize_group_jid(target)
    norm_alias = _normalize_name(target)
    for group in _load_groups():
        if (norm_jid and group.get("jid") == norm_jid) or (
            norm_alias and _normalize_name(group.get("name", "")) == norm_alias
        ):
            return bool(group.get("can_receive", False))
    return False


def set_send_allowed(target: str, allowed: bool) -> str:
    """Set can_receive flag for a contact (by phone/name) or group (by JID/alias)."""
    target = (target or "").strip()
    if not target:
        return "Error: debes especificar un número, nombre o JID de grupo."

    directory = _load_directory()
    contacts = directory.get("contacts", [])
    groups = directory.get("groups", [])
    updated_entry: str | None = None

    # Try contacts first
    number = normalize_external_user_id(target)
    norm_name = _normalize_name(target)
    for contact in contacts:
        if (number and contact.get("phone") == number) or (
            norm_name and _normalize_name(contact.get("name", "")) == norm_name
        ):
            contact["can_receive"] = allowed
            updated_entry = contact.get("name") or contact.get("phone")
            break

    if updated_entry is None:
        # Try groups
        norm_jid = normalize_group_jid(target)
        for group in groups:
            if (norm_jid and group.get("jid") == norm_jid) or (
                norm_name and _normalize_name(group.get("name", "")) == norm_name
            ):
                group["can_receive"] = allowed
                updated_entry = group.get("name") or group.get("jid")
                break

    if updated_entry is None:
        return (
            f"No se encontró '{target}' en contactos ni grupos.\n"
            "Regístralo primero con save_whatsapp_contact() o save_whatsapp_group()."
        )

    _save_directory({"contacts": contacts, "groups": groups})
    action = "habilitado" if allowed else "bloqueado"
    return f"Envío {action} para '{updated_entry}'."


def migrate_legacy_autoreply_flags_to_db(*, force: bool = False) -> dict[str, int]:
    """One-shot migration from JSON auto_reply_allowed flags to user_agent_access."""
    global _legacy_autoreply_migrated

    if _legacy_autoreply_migrated and not force:
        return {"found": 0, "upserted": 0, "already_linked": 0}

    directory = _load_directory()
    contacts = [c for c in directory.get("contacts", []) if isinstance(c, dict)]
    groups = [g for g in directory.get("groups", []) if isinstance(g, dict)]

    targets: list[str] = []
    for contact in contacts:
        if contact.get("auto_reply_allowed"):
            normalized = normalize_autoreply_target(contact.get("phone", ""))
            if normalized:
                targets.append(normalized)
    for group in groups:
        if group.get("auto_reply_allowed"):
            normalized = normalize_autoreply_target(group.get("jid", ""))
            if normalized:
                targets.append(normalized)

    deduped_targets = sorted(set(targets))
    found = len(deduped_targets)
    if found == 0:
        _legacy_autoreply_migrated = True
        return {"found": 0, "upserted": 0, "already_linked": 0}

    default_agent_name = _resolve_default_autoreply_agent()

    upserted = 0
    already_linked = 0
    for target in deduped_targets:
        existing = get_user_agent_access("whatsapp", target)
        if existing is not None and existing.get("default_agent_name"):
            already_linked += 1
            continue

        allowed_agent_names = list(existing.get("allowed_agent_names") or []) if existing else []
        if default_agent_name and default_agent_name not in allowed_agent_names:
            allowed_agent_names.append(default_agent_name)

        upsert_user_agent_access(
            "whatsapp",
            target,
            allowed_agent_names=allowed_agent_names,
            default_agent_name=default_agent_name,
        )
        upserted += 1

    logger.info(
        "Legacy auto-reply migration completed: found=%s upserted=%s already_linked=%s default_agent=%s",
        found,
        upserted,
        already_linked,
        default_agent_name or "",
    )
    _legacy_autoreply_migrated = True
    return {"found": found, "upserted": upserted, "already_linked": already_linked}


def _resolve_autoreply_target(target: str) -> tuple[str, str]:
    raw = (target or "").strip()
    if not raw:
        return "", ""

    group = resolve_group(raw)
    if group is not None:
        jid = normalize_autoreply_target(group.get("jid", ""))
        return jid, group.get("name") or jid

    if "@g.us" in raw.lower():
        jid = normalize_autoreply_target(raw)
        return jid, jid

    contact = resolve_contact(raw)
    if contact is not None:
        phone = normalize_autoreply_target(contact.get("phone", ""))
        label = contact.get("name") or phone
        return phone, label

    phone = normalize_autoreply_target(raw)
    return phone, phone


def is_reply_allowed(sender: str) -> bool:
    normalized_target = normalize_autoreply_target(sender)
    if not normalized_target:
        return False
    return get_user_agent_access("whatsapp", normalized_target) is not None


def _resolve_default_autoreply_agent() -> str:
    return "Orchestrator"


def list_reply_allowlist() -> list[dict]:
    rows = list_user_agent_access(source="whatsapp")
    result: list[dict] = []
    for row in rows:
        target = row.get("external_user_id") or ""
        group = resolve_group(target) if target.endswith("@g.us") else None
        contact = resolve_contact(target) if not target.endswith("@g.us") else None
        if group is not None:
            label = group.get("name") or target
            kind = "group"
        elif contact is not None:
            label = contact.get("name") or target
            kind = "contact"
        else:
            label = target
            kind = "group" if target.endswith("@g.us") else "contact"

        result.append(
            {
                "target": target,
                "label": label,
                "kind": kind,
                "default_agent_name": row.get("default_agent_name"),
                "allowed_agent_names": row.get("allowed_agent_names") or [],
            }
        )
    return sorted(result, key=lambda item: (item["kind"], _normalize_name(item["label"]), item["target"]))


def set_reply_allowed(target: str, allowed: bool) -> str:
    normalized_target, target_label = _resolve_autoreply_target(target)
    if not normalized_target:
        return (
            "Error: target inválido. Usa número, alias de contacto, alias de grupo o JID @g.us.\n"
            "Si es un alias, regístralo primero con save_whatsapp_contact() o save_whatsapp_group()."
        )

    if not allowed:
        deleted = delete_user_agent_access("whatsapp", normalized_target)
        if not deleted:
            return f"No existía regla de auto-reply para '{target_label or normalized_target}'."
        return f"Auto-reply deshabilitado para '{target_label or normalized_target}' (regla removida de user_agent_access)."

    existing = get_user_agent_access("whatsapp", normalized_target)
    if existing is not None and existing.get("default_agent_name"):
        return (
            f"Auto-reply ya está habilitado para '{target_label or normalized_target}'.\n"
            "Puedes cambiar el agente con /wa link <target> <default> <allowed1,allowed2>."
        )

    default_agent_name = _resolve_default_autoreply_agent()
    allowed_agent_names = list(existing.get("allowed_agent_names") or []) if existing else []
    if default_agent_name and default_agent_name not in allowed_agent_names:
        allowed_agent_names.append(default_agent_name)

    upsert_user_agent_access(
        "whatsapp",
        normalized_target,
        allowed_agent_names=allowed_agent_names,
        default_agent_name=default_agent_name,
    )
    return (
        f"Auto-reply habilitado para '{target_label or normalized_target}' en user_agent_access.\n"
        f"Agente default: {default_agent_name}.\n"
        "Si quieres otro agente o permisos específicos, usa /wa link."
    )


is_autoreply_target_allowed = is_reply_allowed
migrate_legacy_autoreply_to_db = migrate_legacy_autoreply_flags_to_db
