"""Persistent contact/group directory helpers for the WhatsApp skill package."""

from __future__ import annotations

import unicodedata

from zafiro_skill_whatsapp.adapters.whatsapp.runtime_ops.config import WHATSAPP_CONTACTS_PATH
from zafiro_skill_whatsapp.integrations import (
    load_whatsapp_directory,
    normalize_external_user_id,
    save_whatsapp_directory,
)


def _load_directory() -> dict:
    payload = load_whatsapp_directory()
    if not isinstance(payload, dict):
        return {"contacts": [], "groups": []}
    return {
        "contacts": payload.get("contacts", []),
        "groups": payload.get("groups", []),
    }


def _load_contacts() -> list[dict]:
    contacts = _load_directory().get("contacts", [])
    return [item for item in contacts if isinstance(item, dict)]


def _load_groups() -> list[dict]:
    groups = _load_directory().get("groups", [])
    return [item for item in groups if isinstance(item, dict)]


def _save_directory(directory: dict) -> None:
    save_whatsapp_directory(directory)


def _save_contacts(contacts: list[dict]) -> None:
    directory = _load_directory()
    directory["contacts"] = contacts
    _save_directory(directory)


def _save_groups(groups: list[dict]) -> None:
    directory = _load_directory()
    directory["groups"] = groups
    _save_directory(directory)


def _normalize_name(value: str) -> str:
    normalized = unicodedata.normalize("NFKD", value or "")
    base = "".join(char for char in normalized if not unicodedata.combining(char))
    return " ".join(base.lower().split())


def list_contacts() -> list[dict]:
    contacts = _load_contacts()
    return sorted(contacts, key=lambda item: (_normalize_name(item.get("name", "")), item.get("phone", "")))


def normalize_group_jid(value: str) -> str:
    compact = "".join((value or "").split())
    if not compact:
        return ""
    lower = compact.lower()
    if lower.endswith("@g.us"):
        return f"{compact[:-5]}@g.us"
    if lower.endswith("@s.whatsapp.net"):
        return compact
    return f"{compact}@g.us"


def normalize_autoreply_target(value: str) -> str:
    compact = "".join((value or "").split())
    if not compact:
        return ""
    lower = compact.lower()
    if lower.endswith("@g.us"):
        return normalize_group_jid(compact)
    if lower.endswith("@s.whatsapp.net"):
        compact = compact[:-15]
    normalized_phone = normalize_external_user_id(compact)
    return normalized_phone if normalized_phone.isdigit() else ""


def list_groups() -> list[dict]:
    groups = _load_groups()
    return sorted(groups, key=lambda item: (_normalize_name(item.get("name", "")), item.get("jid", "")))


def resolve_contact(reference: str) -> dict | None:
    normalized_ref = normalize_external_user_id(reference)
    normalized_name = _normalize_name(reference)
    for contact in list_contacts():
        if normalized_ref and contact.get("phone") == normalized_ref:
            return contact
        if normalized_name and _normalize_name(contact.get("name", "")) == normalized_name:
            return contact
    for contact in list_contacts():
        if normalized_name and _normalize_name(contact.get("name", "")).startswith(normalized_name):
            return contact
    return None


def resolve_group(reference: str) -> dict | None:
    normalized_ref = normalize_group_jid(reference)
    normalized_name = _normalize_name(reference)
    for group in list_groups():
        if normalized_ref and group.get("jid") == normalized_ref:
            return group
        if normalized_name and _normalize_name(group.get("name", "")) == normalized_name:
            return group
    for group in list_groups():
        if normalized_name and _normalize_name(group.get("name", "")).startswith(normalized_name):
            return group
    return None


def resolve_recipient(reference: str) -> dict | None:
    group = resolve_group(reference)
    if group is not None:
        return {"kind": "group", **group}
    contact = resolve_contact(reference)
    if contact is not None:
        return {"kind": "contact", **contact}
    if "@g.us" in (reference or "").lower():
        jid = normalize_group_jid(reference)
        if jid:
            return {"kind": "group", "name": jid, "jid": jid, "note": ""}
    return None


def upsert_contact(name: str, phone: str, *, replace: bool = True, note: str = "") -> dict:
    clean_name = " ".join((name or "").split()).strip()
    clean_phone = normalize_external_user_id(phone)
    if not clean_name:
        raise ValueError("name is required")
    if not clean_phone:
        raise ValueError("phone is required")

    contacts = _load_contacts()
    normalized_name = _normalize_name(clean_name)
    normalized_phone = clean_phone

    existing_by_name = next(
        (item for item in contacts if _normalize_name(item.get("name", "")) == normalized_name),
        None,
    )
    existing_by_phone = next((item for item in contacts if item.get("phone") == normalized_phone), None)

    if existing_by_name is not None and existing_by_name is not existing_by_phone:
        if not replace:
            raise ValueError(f"contact '{clean_name}' already exists")
        existing_by_name["phone"] = clean_phone
        existing_by_name["name"] = clean_name
        existing_by_name["note"] = note.strip()
        if existing_by_phone is not None:
            contacts = [item for item in contacts if item is not existing_by_phone]
        _save_contacts(contacts)
        return existing_by_name

    target = existing_by_name or existing_by_phone
    if target is None:
        target = {"name": clean_name, "phone": clean_phone, "note": note.strip()}
        contacts.append(target)
    else:
        if existing_by_name is not None and existing_by_name.get("phone") != clean_phone and not replace:
            raise ValueError(f"contact '{clean_name}' already exists with another phone")
        target["name"] = clean_name
        target["phone"] = clean_phone
        target["note"] = note.strip()

    deduped: list[dict] = []
    seen: set[tuple[str, str]] = set()
    for item in contacts:
        key = (_normalize_name(item.get("name", "")), item.get("phone", ""))
        if key in seen:
            continue
        seen.add(key)
        deduped.append(item)
    _save_contacts(deduped)
    return target


def upsert_contacts(entries: list[dict], *, replace: bool = True) -> list[dict]:
    saved: list[dict] = []
    for entry in entries:
        saved.append(
            upsert_contact(
                entry.get("name", ""),
                entry.get("phone", ""),
                replace=replace,
                note=entry.get("note", ""),
            )
        )
    return saved


def upsert_group(name: str, jid: str, *, replace: bool = True, note: str = "") -> dict:
    clean_name = " ".join((name or "").split()).strip()
    clean_jid = normalize_group_jid(jid)
    if not clean_name:
        raise ValueError("name is required")
    if not clean_jid:
        raise ValueError("group jid is required")

    groups = _load_groups()
    normalized_name = _normalize_name(clean_name)

    existing_by_name = next(
        (item for item in groups if _normalize_name(item.get("name", "")) == normalized_name),
        None,
    )
    existing_by_jid = next((item for item in groups if item.get("jid") == clean_jid), None)

    if existing_by_name is not None and existing_by_name is not existing_by_jid:
        if not replace:
            raise ValueError(f"group '{clean_name}' already exists")
        existing_by_name["jid"] = clean_jid
        existing_by_name["name"] = clean_name
        existing_by_name["note"] = note.strip()
        if existing_by_jid is not None:
            groups = [item for item in groups if item is not existing_by_jid]
        _save_groups(groups)
        return existing_by_name

    target = existing_by_name or existing_by_jid
    if target is None:
        target = {"name": clean_name, "jid": clean_jid, "note": note.strip()}
        groups.append(target)
    else:
        if existing_by_name is not None and existing_by_name.get("jid") != clean_jid and not replace:
            raise ValueError(f"group '{clean_name}' already exists with another jid")
        target["name"] = clean_name
        target["jid"] = clean_jid
        target["note"] = note.strip()

    deduped: list[dict] = []
    seen: set[tuple[str, str]] = set()
    for item in groups:
        key = (_normalize_name(item.get("name", "")), item.get("jid", ""))
        if key in seen:
            continue
        seen.add(key)
        deduped.append(item)
    _save_groups(deduped)
    return target


def upsert_groups(entries: list[dict], *, replace: bool = True) -> list[dict]:
    saved: list[dict] = []
    for entry in entries:
        saved.append(
            upsert_group(
                entry.get("name", ""),
                entry.get("jid", ""),
                replace=replace,
                note=entry.get("note", ""),
            )
        )
    return saved


from zafiro_skill_whatsapp.adapters.whatsapp.contacts_ops.discovery import (  # noqa: E402
    remember_contact,
    remember_group,
    sync_joined_groups,
)
from zafiro_skill_whatsapp.adapters.whatsapp.contacts_ops.policy import (  # noqa: E402
    get_wa_setting,
    has_reply_whitelist,
    is_autoreply_enabled,
    is_reply_allowed,
    is_send_allowed,
    list_reply_allowlist,
    migrate_legacy_autoreply_flags_to_db,
    set_reply_allowed,
    set_send_allowed,
    set_wa_setting,
)

normalize_whatsapp_target = normalize_autoreply_target
migrate_legacy_autoreply_to_db = migrate_legacy_autoreply_flags_to_db
is_autoreply_target_allowed = is_reply_allowed
