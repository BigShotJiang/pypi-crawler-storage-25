"""Filesystem-backed outbound queue so cron jobs can send WhatsApp messages safely."""

from __future__ import annotations

import json
import uuid
from pathlib import Path

from zafiro_skill_whatsapp.adapters.whatsapp.runtime_ops.config import WHATSAPP_OUTBOX_DIR


def _outbox_root() -> Path:
    root = Path(WHATSAPP_OUTBOX_DIR)
    (root / "pending").mkdir(parents=True, exist_ok=True)
    (root / "processed").mkdir(parents=True, exist_ok=True)
    (root / "failed").mkdir(parents=True, exist_ok=True)
    return root


def enqueue_send_message(to_number: str, text: str, metadata: dict | None = None) -> str:
    command_id = str(uuid.uuid4())
    root = _outbox_root()
    payload = {
        "id": command_id,
        "kind": "send_message",
        "to_number": to_number,
        "text": text,
        "metadata": metadata or {},
    }
    path = root / "pending" / f"{command_id}.json"
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return command_id


def enqueue_reply_message(message_id: str, text: str, metadata: dict | None = None) -> str:
    command_id = str(uuid.uuid4())
    root = _outbox_root()
    payload = {
        "id": command_id,
        "kind": "reply_message",
        "message_id": message_id,
        "text": text,
        "metadata": metadata or {},
    }
    path = root / "pending" / f"{command_id}.json"
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return command_id


def list_pending_messages(limit: int = 20) -> list[dict]:
    root = _outbox_root()
    files = sorted((root / "pending").glob("*.json"))[:limit]
    rows = []
    for file_path in files:
        try:
            rows.append(json.loads(file_path.read_text(encoding="utf-8")))
        except json.JSONDecodeError:
            continue
    return rows


def process_pending_messages(send_callable, reply_callable=None, limit: int = 10) -> list[dict]:
    root = _outbox_root()
    pending = sorted((root / "pending").glob("*.json"))[:limit]
    results: list[dict] = []
    for file_path in pending:
        try:
            payload = json.loads(file_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            file_path.rename(root / "failed" / file_path.name)
            results.append({"file": file_path.name, "status": "failed", "reason": "invalid json"})
            continue

        try:
            kind = payload.get("kind", "send_message")
            if kind == "send_message":
                result = send_callable(payload["to_number"], payload["text"])
                ok = result.startswith("Mensaje enviado")
            elif kind == "reply_message" and reply_callable is not None:
                result = reply_callable(payload["message_id"], payload["text"])
                ok = result.startswith("Respuesta enviada")
            else:
                result = f"Unsupported queue command kind: {kind}"
                ok = False
        except Exception as error:
            result = str(error)
            ok = False

        payload["result"] = result
        destination = root / ("processed" if ok else "failed") / file_path.name
        destination.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        file_path.unlink(missing_ok=True)
        results.append({"file": file_path.name, "status": "processed" if ok else "failed", "result": result})
    return results
