"""Organized messaging operations for WhatsApp adapter."""

__all__: list[str] = []
