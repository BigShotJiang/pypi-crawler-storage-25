import logging

from zafiro_skill_whatsapp.adapters.whatsapp.message_ops.processing import (
    append_recent_message,
    build_base_payload,
    forward_payload,
    populate_payload_from_message,
)

from neonize.client import NewClient
from neonize.events import MessageEv

logger = logging.getLogger(__name__)


def should_ignore_message(info) -> bool:
    if info.MessageSource.IsFromMe:
        return True
    if info.MessageSource.Chat.Server in ("broadcast", "status"):
        return True
    return False


def handle_message(client: NewClient, event: MessageEv) -> None:
    info = event.Info
    msg = event.Message

    if should_ignore_message(info):
        return

    payload = build_base_payload(info)
    if not populate_payload_from_message(client, msg, payload):
        logger.debug("Unsupported message type - skipping")
        return

    append_recent_message(payload, event)
    forward_payload(payload)
