import logging
import mimetypes
from datetime import datetime, timezone
from pathlib import Path

import requests

from zafiro_skill_whatsapp.adapters.whatsapp.message_ops.auto_reply import maybe_auto_reply
from zafiro_skill_whatsapp.adapters.whatsapp.contacts import remember_contact, remember_group
from zafiro_skill_whatsapp.adapters.whatsapp.runtime_ops.state import (
    cache_incoming_message,
    contact_session_id,
    jid_to_str,
    load_contact_history,
    runtime,
)
from zafiro_skill_whatsapp.adapters.whatsapp.runtime_ops.types import WhatsAppPayload
from zafiro_skill_whatsapp.adapters.whatsapp.runtime_ops.config import (
    WHATSAPP_FORWARD_SECRET,
    WHATSAPP_FORWARD_URL,
    WHATSAPP_MEDIA_DIR,
)
from zafiro_skill_whatsapp.integrations import (
    RECENT_SESSION_HISTORY_LIMIT,
    analyze_image,
    archive_whatsapp_payload,
    transcribe_audio,
)

from neonize.client import NewClient
from neonize.proto.Neonize_pb2 import Message as IncomingMessage

logger = logging.getLogger(__name__)


def build_base_payload(info) -> WhatsAppPayload:
    sender_user = info.MessageSource.Sender.User
    return {
        "direction": "inbound",
        "delivery_status": "received",
        "from_": sender_user,
        "peer_number": sender_user,
        "jid": jid_to_str(info.MessageSource.Sender),
        "type": "text",
        "received_at": datetime.now(timezone.utc).isoformat(),
        "raw_text": None,
        "audio_transcription": None,
        "image_analysis": None,
        "media_path": None,
        "mime_type": None,
        "source_channel": "whatsapp",
        "message_id": info.ID,
        "reply_to_message_id": None,
        "chat_jid": jid_to_str(info.MessageSource.Chat),
        "sender_jid": jid_to_str(info.MessageSource.Sender),
        "session_id": contact_session_id(info.MessageSource.Sender.User),
    }


def _remember_payload_endpoints(payload: WhatsAppPayload) -> None:
    peer_number = payload.get("peer_number")
    if peer_number:
        remember_contact(peer_number, note="auto-discovered-from-message")
    chat_jid = payload.get("chat_jid", "")
    if isinstance(chat_jid, str) and chat_jid.endswith("@g.us"):
        remember_group(chat_jid, note="auto-discovered-from-message")


def append_recent_message(payload: WhatsAppPayload, message: IncomingMessage) -> None:
    cache_incoming_message(payload, message)
    _remember_payload_endpoints(payload)
    archive_whatsapp_payload(payload)

    # Mark message as read to appear as a real user
    try:
        from zafiro_skill_whatsapp.adapters.whatsapp.outbound import mark_message_as_read

        mark_message_as_read(
            message.ID,
            message.MessageSource.Chat,
            message.MessageSource.Sender,
            message.Timestamp,
        )
    except Exception as error:
        logger.debug("Could not mark message as read: %s", error)

    try:
        maybe_auto_reply(payload)
    except Exception as error:
        logger.error("WhatsApp auto-reply failed: %s", error)


def get_recent_messages(n: int = 10, from_number: str | None = None) -> list[dict]:
    msgs = list(runtime.message_buffer)
    if from_number:
        clean = from_number.strip().lstrip("+").replace(" ", "").replace("-", "")
        msgs = [msg for msg in msgs if msg.get("from_") == clean]

    normalized = []
    for msg in reversed(msgs):
        item = dict(msg)
        item["from"] = item.pop("from_")
        normalized.append(item)
    return normalized[:n]


def get_recent_group_messages(group_jid: str, n: int = 10) -> list[dict]:
    msgs = [msg for msg in reversed(runtime.message_buffer) if msg.get("chat_jid") == group_jid]
    normalized = []
    for msg in msgs[:n]:
        item = dict(msg)
        item["from"] = item.pop("from_")
        normalized.append(item)
    return normalized


def get_contact_execution_context(
    phone_number: str,
    *,
    history_limit: int = RECENT_SESSION_HISTORY_LIMIT,
) -> dict:
    return {
        "session_id": contact_session_id(phone_number),
        "history": load_contact_history(phone_number, limit=history_limit),
    }


def forward_payload(payload: WhatsAppPayload) -> None:
    if not WHATSAPP_FORWARD_URL:
        logger.debug("WHATSAPP_FORWARD_URL not set - skipping forward")
        return

    headers = {"Content-Type": "application/json"}
    if WHATSAPP_FORWARD_SECRET:
        headers["Authorization"] = f"Bearer {WHATSAPP_FORWARD_SECRET}"

    forwarded = dict(payload)
    forwarded["from"] = forwarded.pop("from_")

    try:
        response = requests.post(
            WHATSAPP_FORWARD_URL,
            json=forwarded,
            headers=headers,
            timeout=10,
        )
        response.raise_for_status()
        logger.info(
            "Forwarded message %s from %s -> %s",
            forwarded.get("message_id"),
            forwarded.get("from"),
            WHATSAPP_FORWARD_URL,
        )
    except Exception as error:
        logger.error("Forward failed: %s", error)


def save_media(data: bytes, ext: str) -> str:
    media_dir = Path(WHATSAPP_MEDIA_DIR or "./media")
    media_dir.mkdir(parents=True, exist_ok=True)
    filename = f"{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_%f')}{ext}"
    path = media_dir / filename
    path.write_bytes(data)
    return str(path)


def _guess_media_extension(mime_type: str | None, fallback: str) -> str:
    if mime_type:
        guessed = mimetypes.guess_extension(mime_type, strict=False)
        if guessed:
            return guessed
    return fallback


def populate_payload_from_message(client: NewClient, msg, payload: WhatsAppPayload) -> bool:
    if msg.conversation:
        payload["raw_text"] = msg.conversation
        payload["type"] = "text"
        return True

    if msg.extendedTextMessage.text:
        payload["raw_text"] = msg.extendedTextMessage.text
        payload["type"] = "text"
        return True

    if msg.HasField("audioMessage"):
        payload["type"] = "audio"
        payload["mime_type"] = msg.audioMessage.mimetype or None
        data = client.download_any(msg)
        if data:
            path = save_media(data, _guess_media_extension(payload["mime_type"], ".ogg"))
            payload["media_path"] = path
            try:
                payload["audio_transcription"] = transcribe_audio(path)
                payload["raw_text"] = payload["audio_transcription"]
            except Exception as error:
                logger.error("Audio transcription failed: %s", error)
        return True

    if msg.HasField("imageMessage"):
        payload["type"] = "image"
        payload["mime_type"] = msg.imageMessage.mimetype or None
        data = client.download_any(msg)
        if data:
            path = save_media(data, _guess_media_extension(payload["mime_type"], ".jpg"))
            payload["media_path"] = path
            caption = msg.imageMessage.caption or ""
            try:
                payload["image_analysis"] = analyze_image(path, caption)
                payload["raw_text"] = payload["image_analysis"]
            except Exception as error:
                logger.error("Image analysis failed: %s", error)
        return True

    if msg.HasField("videoMessage"):
        payload["type"] = "video"
        payload["mime_type"] = msg.videoMessage.mimetype or None
        payload["raw_text"] = msg.videoMessage.caption or None
        data = client.download_any(msg)
        if data:
            payload["media_path"] = save_media(data, _guess_media_extension(payload["mime_type"], ".mp4"))
        return True

    if msg.HasField("documentMessage"):
        payload["type"] = "document"
        payload["mime_type"] = msg.documentMessage.mimetype or None
        payload["raw_text"] = msg.documentMessage.fileName or None
        data = client.download_any(msg)
        if data:
            payload["media_path"] = save_media(data, _guess_media_extension(payload["mime_type"], ".bin"))
        return True

    if msg.HasField("stickerMessage"):
        payload["type"] = "sticker"
        payload["mime_type"] = msg.stickerMessage.mimetype or "image/webp"
        payload["raw_text"] = "[sticker]"
        data = client.download_any(msg)
        if data:
            payload["media_path"] = save_media(data, _guess_media_extension(payload["mime_type"], ".webp"))
        return True

    return False
