from __future__ import annotations

import logging

from zafiro_skill_whatsapp.integrations import (
    RECENT_SESSION_HISTORY_LIMIT,
    execute_task,
    get_active_agents,
    get_user_agent_access,
    load_session_history,
    resolve_effective_agent,
)
from zafiro_skill_whatsapp.adapters.whatsapp.runtime_ops.config import WHATSAPP_AUTO_REPLY_ENABLED

logger = logging.getLogger(__name__)

_WHATSAPP_SKILL = "WhatsApp"
_WHATSAPP_REPLY_SKILL = "WhatsAppReply"
_DELEGATION_SKILL = "AgentDelegation"


def _find_agent_by_name(agents: list[dict], name: str) -> dict | None:
    return next((a for a in agents if a["name"] == name), None)


def _agent_has_skill(agent: dict, skill_name: str) -> bool:
    return skill_name in (agent.get("allowed_skills") or [])


def resolve_auto_reply_agent(payload: dict, agents: list[dict]) -> tuple[dict | None, dict]:
    """Resolve which agent should handle an inbound WhatsApp auto-reply.

    Auto-reply is explicit opt-in via DB rules (user_agent_access).
    If the sender number (or group JID) is not linked in DB, do not reply.
    """
    from zafiro_skill_whatsapp.adapters.whatsapp.contacts import normalize_whatsapp_target

    sender = str(payload.get("from_") or payload.get("from") or "").strip()
    if not sender:
        return None, {"reason": "missing-sender"}

    # For group messages, the gate and routing use the group JID, not the
    # individual sender number. `from_` is the person who wrote; `chat_jid`
    # ending in @g.us is the group itself.
    chat_jid = str(payload.get("chat_jid") or "").strip()
    is_group_msg = chat_jid.endswith("@g.us")
    route_target = chat_jid if is_group_msg else sender
    normalized_target = normalize_whatsapp_target(route_target)
    if not normalized_target:
        return None, {"reason": "invalid-sender-or-group", "target": route_target}

    access = get_user_agent_access("whatsapp", normalized_target)
    if access is None:
        return None, {"reason": "not-in-autoreply-list", "target": normalized_target}

    access_level = str(access.get("access_level") or "limited").strip().lower()
    if access_level not in {"admin", "limited", "readonly"}:
        access_level = "limited"

    full_agents = list(agents)

    default_agent_name = str(access.get("default_agent_name") or "").strip()
    if not default_agent_name:
        return None, {"reason": "access-without-default-agent", "target": normalized_target}

    base_agent = _find_agent_by_name(full_agents, default_agent_name)
    if base_agent is None:
        return None, {
            "reason": "linked-agent-not-found",
            "target": normalized_target,
            "agent_name": default_agent_name,
        }
    base_agent = resolve_effective_agent(base_agent, access_level, full_agents) or base_agent

    # 6. Gate: agent must either own WhatsApp skill directly, or be able to
    # delegate to an agent that does (via AgentDelegation → e.g. Comms Officer).
    if not (
        _agent_has_skill(base_agent, _WHATSAPP_SKILL)
        or _agent_has_skill(base_agent, _WHATSAPP_REPLY_SKILL)
        or _agent_has_skill(base_agent, _DELEGATION_SKILL)
    ):
        return None, {"reason": "agent-lacks-whatsapp-or-delegation-skill", "agent": base_agent["name"]}

    if is_group_msg:
        return dict(base_agent), {"reason": "group-linked-access", "target": normalized_target}
    return dict(base_agent), {
        "reason": "explicit-access",
        "actor_profile": "linked-agent",
        "target": normalized_target,
    }


def maybe_auto_reply(payload: dict) -> dict | None:
    if not WHATSAPP_AUTO_REPLY_ENABLED:
        logger.debug("WhatsApp auto-reply disabled by WHATSAPP_AUTO_REPLY_ENABLED")
        return {"reason": "auto-reply-disabled"}

    query = (
        payload.get("raw_text")
        or payload.get("audio_transcription")
        or payload.get("image_analysis")
        or ""
    ).strip()
    if not query:
        return None

    from zafiro_skill_whatsapp.adapters.whatsapp import reply_to_message, start_composing

    agents = get_active_agents()
    if not agents:
        logger.debug("WhatsApp auto-reply skipped: no host agents configured")
        return {"reason": "no-host-agents"}
    effective_agent, meta = resolve_auto_reply_agent(payload, agents)
    if effective_agent is None:
        logger.debug("WhatsApp auto-reply skipped: %s", meta)
        return meta

    # Start "typing..." indicator NOW — before the slow LLM call — so the user
    # sees real activity during inference instead of silence followed by an
    # instant message (which flags the reply as AI-generated).
    chat_jid_str = str(payload.get("chat_jid") or payload.get("from_") or "")
    if chat_jid_str:
        start_composing(chat_jid_str)

    history_phone = str(
        payload.get("from_")
        or payload.get("from")
        or payload.get("peer_number")
        or ""
    )
    history = load_session_history(history_phone, limit=RECENT_SESSION_HISTORY_LIMIT)
    answer, used_agent = execute_task(
        agent=effective_agent,
        query=query,
        lang="Spanish",
        history=history,
        session_id=payload.get("session_id"),
        quiet=True,
    )
    answer = (answer or "").strip()
    if not answer or answer.startswith("Error:"):
        logger.warning("WhatsApp auto-reply skipped due to empty/error answer: %s", answer[:160])
        return {**meta, "reason": "empty-or-error", "agent": used_agent}

    send_result = reply_to_message(
        str(payload.get("message_id", "")),
        answer,
        already_composing=bool(chat_jid_str),
    )
    return {
        **meta,
        "reason": "sent",
        "agent": used_agent,
        "answer": answer,
        "send_result": send_result,
    }
