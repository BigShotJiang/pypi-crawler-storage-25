import logging
import random
import time
from datetime import datetime, timezone

from zafiro_skill_whatsapp.adapters.whatsapp.contacts import remember_contact, remember_group
from zafiro_skill_whatsapp.adapters.whatsapp.runtime_ops.state import (
    build_chat_jid,
    get_client,
    get_incoming_message,
    jid_to_str,
    normalize_number,
    runtime,
    set_active_account_key,
)
from zafiro_skill_whatsapp.adapters.whatsapp.runtime_ops.config import (
    WHATSAPP_AUTO_MARK_READ,
    WHATSAPP_SEND_AVAILABLE_PRESENCE,
    WHATSAPP_SIMULATE_TYPING,
    WHATSAPP_TYPING_MAX_MS,
    WHATSAPP_TYPING_MIN_MS,
    WHATSAPP_TYPING_MS_PER_CHAR,
)
from zafiro_skill_whatsapp.integrations import archive_whatsapp_payload

from neonize.utils.enum import ChatPresence, ChatPresenceMedia, Presence, ReceiptType

logger = logging.getLogger(__name__)


def _archive_outbound_payload(send_response, to_jid, text: str, *, reply_to_message_id: str | None = None) -> None:
    client = get_client()
    me = client.get_me().JID if client is not None else None
    if me is not None:
        set_active_account_key(str(me.User or ""))
    peer_number = to_jid.User if to_jid.Server == "s.whatsapp.net" else None
    payload = {
        "direction": "outbound",
        "delivery_status": "sent",
        "from_": me.User if me is not None else "me",
        "peer_number": peer_number,
        "jid": jid_to_str(to_jid),
        "type": "text",
        "received_at": datetime.now(timezone.utc).isoformat(),
        "raw_text": text,
        "audio_transcription": None,
        "image_analysis": None,
        "media_path": None,
        "mime_type": "text/plain",
        "source_channel": "whatsapp",
        "message_id": getattr(send_response, "ID", "") or f"outbound-{int(time.time() * 1000)}",
        "reply_to_message_id": reply_to_message_id,
        "chat_jid": jid_to_str(to_jid),
        "sender_jid": jid_to_str(me) if me is not None else "me@s.whatsapp.net",
        "session_id": f"whatsapp:{peer_number}" if peer_number else f"whatsapp:{to_jid.User}",
    }
    if peer_number:
        remember_contact(peer_number, note="auto-discovered-from-outbound")
    if to_jid.Server == "g.us":
        remember_group(jid_to_str(to_jid), note="auto-discovered-from-outbound")
    archive_whatsapp_payload(payload)


def send_available_presence() -> None:
    client = get_client()
    if not client or not WHATSAPP_SEND_AVAILABLE_PRESENCE:
        return
    try:
        client.send_presence(Presence.AVAILABLE)
    except Exception as error:
        logger.debug("Could not send available presence: %s", error)


def _send_chat_presence(to_jid, state: ChatPresence) -> None:
    client = get_client()
    if not client:
        return
    try:
        client.send_chat_presence(
            to_jid,
            state,
            ChatPresenceMedia.CHAT_PRESENCE_MEDIA_TEXT,
        )
    except Exception as error:
        logger.debug("Could not send chat presence: %s", error)


def mark_message_as_read(message_id: str, chat_jid, sender_jid, timestamp: int) -> None:
    """Mark an incoming message as read to appear as a real user."""
    if not WHATSAPP_AUTO_MARK_READ:
        return
    client = get_client()
    if not client:
        return
    try:
        client.mark_read(
            message_id,
            chat=chat_jid,
            sender=sender_jid,
            receipt=ReceiptType.READ,
            timestamp=timestamp,
        )
    except Exception as error:
        logger.debug("Could not mark message as read: %s", error)


def _typing_delay_seconds(text: str) -> float:
    estimated_ms = len(text) * WHATSAPP_TYPING_MS_PER_CHAR
    bounded_ms = max(WHATSAPP_TYPING_MIN_MS, min(WHATSAPP_TYPING_MAX_MS, estimated_ms))
    jitter_ms = random.randint(0, max(150, bounded_ms // 5))
    return (bounded_ms + jitter_ms) / 1000.0


def start_composing(chat_jid_str: str) -> None:
    """Send available + composing presence early (before LLM inference) so the
    user sees a live typing indicator while the model is still working."""
    client = get_client()
    if not client or not WHATSAPP_SIMULATE_TYPING:
        return
    to_jid = build_chat_jid(chat_jid_str)
    send_available_presence()
    _send_chat_presence(to_jid, ChatPresence.CHAT_PRESENCE_COMPOSING)


def _send_humanized(send_callable, to_jid, text: str, *, already_composing: bool = False) -> str:
    """Humanized send: available presence → composing → sleep → send → paused.

    Pass already_composing=True when start_composing() was already called
    (e.g. before a slow LLM call) to skip the redundant COMPOSING signal and
    only add a short post-inference typing delay before sending.
    """
    send_available_presence()
    try:
        if WHATSAPP_SIMULATE_TYPING:
            if not already_composing:
                _send_chat_presence(to_jid, ChatPresence.CHAT_PRESENCE_COMPOSING)
            time.sleep(_typing_delay_seconds(text))
        send_callable()
    finally:
        if WHATSAPP_SIMULATE_TYPING:
            _send_chat_presence(to_jid, ChatPresence.CHAT_PRESENCE_PAUSED)
    return "ok"


def send_message(to_number: str, text: str) -> str:
    client = get_client()
    if not client or not runtime.connected.is_set():
        return (
            "WhatsApp no está conectado en este proceso. "
            "Usa /wa on desde el chat o arráncalo con scripts/start.sh."
        )

    target = "".join((to_number or "").split())
    is_group = target.endswith("@g.us")
    number = normalize_number(to_number)
    if not is_group and not number.isdigit():
        return f"Número o grupo inválido: '{to_number}'. Usa formato internacional sin + o un JID de grupo válido."

    # Outbound allowlist gate — check can_receive in the contacts directory
    from zafiro_skill_whatsapp.adapters.whatsapp.contacts import is_send_allowed
    check_target = target if is_group else number
    if not is_send_allowed(check_target):
        return (
            f"Envío bloqueado: '{to_number}' no está en la lista de destinatarios autorizados.\n"
            "Usa wa_allow_send() para habilitarlo primero."
        )

    to_jid = build_chat_jid(target if is_group else number)
    try:
        response = None

        def _send() -> None:
            nonlocal response
            response = client.send_message(to_jid, text)

        _send_humanized(_send, to_jid, text)
        if response is not None:
            _archive_outbound_payload(response, to_jid, text)
        if is_group:
            return f"Mensaje enviado al grupo {target}."
        return f"Mensaje enviado a {number}."
    except Exception as error:
        return f"Error al enviar mensaje: {error}"


def reply_to_message(message_id: str, text: str, *, already_composing: bool = False) -> str:
    client = get_client()
    if not client or not runtime.connected.is_set():
        return (
            "WhatsApp no está conectado en este proceso. "
            "Usa /wa on desde el chat o arráncalo con scripts/start.sh."
        )
    if not text.strip():
        return "El texto de respuesta no puede estar vacío."

    quoted_message = get_incoming_message(message_id.strip())
    if quoted_message is None:
        return (
            f"No encontré el mensaje '{message_id}'. "
            "Usa read_whatsapp() para obtener un ID reciente y vuelve a intentar."
        )

    info = quoted_message.Info
    try:
        client.mark_read(
            info.ID,
            chat=info.MessageSource.Chat,
            sender=info.MessageSource.Sender,
            receipt=ReceiptType.READ,
            timestamp=info.Timestamp,
        )
    except Exception as error:
        logger.debug("Could not mark replied message as read: %s", error)

    try:
        response = None

        def _reply() -> None:
            nonlocal response
            response = client.reply_message(text, quoted_message)

        _send_humanized(_reply, info.MessageSource.Chat, text, already_composing=already_composing)
        if response is not None:
            _archive_outbound_payload(response, info.MessageSource.Chat, text, reply_to_message_id=info.ID)
        return f"Respuesta enviada al mensaje {info.ID}."
    except Exception as error:
        return f"Error al responder WhatsApp: {error}"
