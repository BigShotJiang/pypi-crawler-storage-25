"""Public facade for the WhatsApp tool adapter implementation."""

import importlib
import logging
import os
from pathlib import Path
import sys

logger = logging.getLogger(__name__)


def _ensure_libmagic_discovery_on_macos() -> None:
    """Best-effort setup so python-magic can find Homebrew libmagic.

    This keeps the skill usable in standalone mode without requiring users to
    export DYLD_LIBRARY_PATH manually every time.
    """
    if sys.platform != "darwin":
        return

    candidates = (
        Path("/opt/homebrew/lib/libmagic.dylib"),
        Path("/usr/local/lib/libmagic.dylib"),
    )
    library_path = next((path for path in candidates if path.exists()), None)
    if library_path is None:
        return

    lib_dir = str(library_path.parent)
    current = os.getenv("DYLD_LIBRARY_PATH", "").strip()
    if current:
        entries = [entry for entry in current.split(":") if entry]
        if lib_dir in entries:
            return
        os.environ["DYLD_LIBRARY_PATH"] = f"{lib_dir}:{current}"
    else:
        os.environ["DYLD_LIBRARY_PATH"] = lib_dir


_ensure_libmagic_discovery_on_macos()


def _install_magic_fallback_if_needed() -> None:
    """Provide a local compatibility fallback when python-magic is unusable."""
    try:
        import magic as _magic  # type: ignore

        # Smoke-test the loaded module; in some environments import succeeds
        # but native lib loading fails when the first API call is made.
        _magic.from_buffer(b"", mime=True)
        return
    except Exception as error:
        from zafiro_skill_whatsapp import _magic_fallback

        sys.modules["magic"] = _magic_fallback
        logger.warning(
            "python-magic/libmagic unavailable (%s). "
            "Using heuristic magic fallback for standalone mode.",
            error,
        )


_install_magic_fallback_if_needed()

_LEGACY_SUBMODULE_ALIASES = {
    "config": "zafiro_skill_whatsapp.adapters.whatsapp.runtime_ops.config",
    "contacts": "zafiro_skill_whatsapp.adapters.whatsapp.contacts_ops.directory",
    "contacts_discovery": "zafiro_skill_whatsapp.adapters.whatsapp.contacts_ops.discovery",
    "contacts_policy": "zafiro_skill_whatsapp.adapters.whatsapp.contacts_ops.policy",
    "auto_reply": "zafiro_skill_whatsapp.adapters.whatsapp.message_ops.auto_reply",
    "inbound": "zafiro_skill_whatsapp.adapters.whatsapp.message_ops.inbound",
    "outbound": "zafiro_skill_whatsapp.adapters.whatsapp.message_ops.outbound",
    "processing": "zafiro_skill_whatsapp.adapters.whatsapp.message_ops.processing",
    "queue": "zafiro_skill_whatsapp.adapters.whatsapp.message_ops.queue",
    "state": "zafiro_skill_whatsapp.adapters.whatsapp.runtime_ops.state",
    "connection": "zafiro_skill_whatsapp.adapters.whatsapp.runtime_ops.connection",
    "sync": "zafiro_skill_whatsapp.adapters.whatsapp.sync_ops.orchestrator",
    "sync_contacts": "zafiro_skill_whatsapp.adapters.whatsapp.sync_ops.contacts",
    "sync_history": "zafiro_skill_whatsapp.adapters.whatsapp.sync_ops.history",
    "types": "zafiro_skill_whatsapp.adapters.whatsapp.runtime_ops.types",
}


def _register_legacy_module_aliases() -> None:
    for legacy_name, target_module in _LEGACY_SUBMODULE_ALIASES.items():
        legacy_module_name = f"{__name__}.{legacy_name}"
        if legacy_module_name in sys.modules:
            module = sys.modules[legacy_module_name]
        else:
            module = importlib.import_module(target_module)
            sys.modules[legacy_module_name] = module

        # Keep old attribute access working: whatsapp.outbound, whatsapp.contacts, etc.
        globals()[legacy_name] = module


_register_legacy_module_aliases()


def __getattr__(name: str):
    if name == "_client":
        from zafiro_skill_whatsapp.adapters.whatsapp.runtime_ops.state import get_client
        return get_client()
    if name == "_connected":
        from zafiro_skill_whatsapp.adapters.whatsapp.runtime_ops.state import runtime
        return runtime.connected
    raise AttributeError(name)


def is_connected() -> bool:
    from zafiro_skill_whatsapp.adapters.whatsapp.runtime_ops.state import get_client, runtime

    return get_client() is not None and runtime.connected.is_set()


def is_external_process_running() -> bool:
    from zafiro_skill_whatsapp.adapters.whatsapp.runtime_ops.state import runtime

    if not runtime.pid_path.exists():
        return False
    try:
        pid = int(runtime.pid_path.read_text().strip())
        os.kill(pid, 0)
        return True
    except (ProcessLookupError, ValueError, OSError):
        runtime.pid_path.unlink(missing_ok=True)
        return False


def start() -> None:
    from zafiro_skill_whatsapp.adapters.whatsapp.runtime_ops.connection import start as _start

    _start()


def start_in_thread() -> None:
    from zafiro_skill_whatsapp.adapters.whatsapp.runtime_ops.connection import start_in_thread as _start_in_thread

    _start_in_thread()


def disconnect() -> None:
    from zafiro_skill_whatsapp.adapters.whatsapp.runtime_ops.connection import disconnect as _disconnect

    _disconnect()


def get_client():
    from zafiro_skill_whatsapp.adapters.whatsapp.runtime_ops.state import get_client as _get_client

    return _get_client()


def send_message(to_number: str, text: str) -> str:
    from zafiro_skill_whatsapp.adapters.whatsapp.message_ops.outbound import send_message as _send_message

    return _send_message(to_number, text)


def reply_to_message(message_id: str, text: str, *, already_composing: bool = False) -> str:
    from zafiro_skill_whatsapp.adapters.whatsapp.message_ops.outbound import reply_to_message as _reply_to_message

    return _reply_to_message(message_id, text, already_composing=already_composing)


def start_composing(chat_jid_str: str) -> None:
    from zafiro_skill_whatsapp.adapters.whatsapp.message_ops.outbound import start_composing as _start_composing

    _start_composing(chat_jid_str)


def list_contacts() -> list[dict]:
    from zafiro_skill_whatsapp.adapters.whatsapp.contacts_ops.directory import list_contacts as _list_contacts

    return _list_contacts()


def list_groups() -> list[dict]:
    from zafiro_skill_whatsapp.adapters.whatsapp.contacts_ops.directory import list_groups as _list_groups

    return _list_groups()


def normalize_group_jid(value: str) -> str:
    from zafiro_skill_whatsapp.adapters.whatsapp.contacts_ops.directory import normalize_group_jid as _normalize_group_jid

    return _normalize_group_jid(value)


def resolve_contact(reference: str) -> dict | None:
    from zafiro_skill_whatsapp.adapters.whatsapp.contacts_ops.directory import resolve_contact as _resolve_contact

    return _resolve_contact(reference)


def resolve_group(reference: str) -> dict | None:
    from zafiro_skill_whatsapp.adapters.whatsapp.contacts_ops.directory import resolve_group as _resolve_group

    return _resolve_group(reference)


def resolve_recipient(reference: str) -> dict | None:
    from zafiro_skill_whatsapp.adapters.whatsapp.contacts_ops.directory import resolve_recipient as _resolve_recipient

    return _resolve_recipient(reference)


def upsert_contact(name: str, phone: str, *, replace: bool = True, note: str = "") -> dict:
    from zafiro_skill_whatsapp.adapters.whatsapp.contacts_ops.directory import upsert_contact as _upsert_contact

    return _upsert_contact(name, phone, replace=replace, note=note)


def upsert_contacts(entries: list[dict], *, replace: bool = True) -> list[dict]:
    from zafiro_skill_whatsapp.adapters.whatsapp.contacts_ops.directory import upsert_contacts as _upsert_contacts

    return _upsert_contacts(entries, replace=replace)


def upsert_group(name: str, jid: str, *, replace: bool = True, note: str = "") -> dict:
    from zafiro_skill_whatsapp.adapters.whatsapp.contacts_ops.directory import upsert_group as _upsert_group

    return _upsert_group(name, jid, replace=replace, note=note)


def upsert_groups(entries: list[dict], *, replace: bool = True) -> list[dict]:
    from zafiro_skill_whatsapp.adapters.whatsapp.contacts_ops.directory import upsert_groups as _upsert_groups

    return _upsert_groups(entries, replace=replace)


def get_recent_messages(*, n: int = 5, from_number: str | None = None) -> list[dict]:
    from zafiro_skill_whatsapp.adapters.whatsapp.message_ops.processing import get_recent_messages as _get_recent_messages

    return _get_recent_messages(n=n, from_number=from_number)


def get_contact_execution_context(phone_number: str, *, history_limit: int = 10) -> dict:
    from zafiro_skill_whatsapp.adapters.whatsapp.message_ops.processing import (
        get_contact_execution_context as _get_contact_execution_context,
    )

    return _get_contact_execution_context(phone_number, history_limit=history_limit)


def contact_session_id(phone_number: str) -> str:
    from zafiro_skill_whatsapp.adapters.whatsapp.runtime_ops.state import contact_session_id as _contact_session_id

    return _contact_session_id(phone_number)


def load_contact_history(phone_number: str, limit: int = 10) -> list[dict]:
    from zafiro_skill_whatsapp.adapters.whatsapp.runtime_ops.state import load_contact_history as _load_contact_history

    return _load_contact_history(phone_number, limit=limit)


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )
    start()