"""Organized synchronization internals for WhatsApp adapter."""

from zafiro_skill_whatsapp.adapters.whatsapp.sync_ops.orchestrator import (
    sync_all_whatsapp_data,
    sync_all_whatsapp_data_multi,
)
from zafiro_skill_whatsapp.adapters.whatsapp.sync_ops.history import (
    get_history_sync_stats,
    handle_history_sync_event,
    request_on_demand_history,
    reset_history_sync_stats,
)
from zafiro_skill_whatsapp.adapters.whatsapp.sync_ops.contacts import sync_contacts_from_whatsapp

__all__ = [
    "sync_all_whatsapp_data",
    "sync_all_whatsapp_data_multi",
    "get_history_sync_stats",
    "handle_history_sync_event",
    "request_on_demand_history",
    "reset_history_sync_stats",
    "sync_contacts_from_whatsapp",
]
