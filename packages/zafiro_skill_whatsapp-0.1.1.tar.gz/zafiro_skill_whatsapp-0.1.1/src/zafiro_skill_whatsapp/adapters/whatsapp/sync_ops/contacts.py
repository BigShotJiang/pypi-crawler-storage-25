"""Contact synchronization helpers for WhatsApp deep sync."""

from __future__ import annotations

from zafiro_skill_whatsapp.adapters.whatsapp.contacts_ops.directory import upsert_contacts
from zafiro_skill_whatsapp.integrations import normalize_external_user_id


def _extract_contact_name(contact) -> str:
    info = getattr(contact, "Info", None)
    if info is None:
        return ""
    for candidate in (
        getattr(info, "FullName", ""),
        getattr(info, "PushName", ""),
        getattr(info, "FirstName", ""),
        getattr(info, "BusinessName", ""),
    ):
        value = str(candidate or "").strip()
        if value:
            return value
    return ""


def sync_contacts_from_whatsapp(client) -> int:
    contacts = client.contact.get_all_contacts()
    pending_by_phone: dict[str, dict] = {}

    for contact in contacts:
        jid = getattr(contact, "JID", None)
        if jid is None:
            continue

        server = str(getattr(jid, "Server", "") or "")
        if server not in {"s.whatsapp.net", "lid"}:
            continue

        phone = normalize_external_user_id(str(getattr(jid, "User", "") or ""))
        if not phone:
            continue

        name = _extract_contact_name(contact) or phone
        pending_by_phone[phone] = {
            "name": name,
            "phone": phone,
            "note": "synced-from-whatsapp",
        }

    if not pending_by_phone:
        return 0

    saved = upsert_contacts(list(pending_by_phone.values()), replace=True)
    return len(saved)
