"""Best-effort deep synchronization orchestration for WhatsApp data."""

from __future__ import annotations

import os
import time

from zafiro_skill_whatsapp.adapters.whatsapp.contacts_ops.discovery import sync_joined_groups
from zafiro_skill_whatsapp.adapters.whatsapp.runtime_ops.state import get_client, runtime
from zafiro_skill_whatsapp.adapters.whatsapp.sync_ops.contacts import sync_contacts_from_whatsapp
from zafiro_skill_whatsapp.adapters.whatsapp.sync_ops.history import (
    get_history_sync_stats,
    request_on_demand_history,
    reset_history_sync_stats,
)
from zafiro_skill_whatsapp.integrations import (
    iter_archived_messages,
    load_whatsapp_directory,
    normalize_external_user_id,
)


def _is_external_process_running() -> bool:
    if not runtime.pid_path.exists():
        return False
    try:
        pid = int(runtime.pid_path.read_text().strip())
        if pid <= 0:
            return False
        os.kill(pid, 0)
        return True
    except (ProcessLookupError, ValueError, OSError):
        runtime.pid_path.unlink(missing_ok=True)
        return False


def _resolve_client_or_error() -> tuple[object | None, str | None]:
    client = get_client()
    connected = client is not None and runtime.connected.is_set()
    if connected:
        return client, None
    if _is_external_process_running():
        return None, (
            "WhatsApp está activo en un proceso externo. "
            "Para sincronización profunda, ejecuta este comando en el mismo proceso que mantiene la sesión."
        )
    return None, "WhatsApp no está conectado. Usa /wa on y luego /wa sync."


def _run_single_sync_round(
    client,
    *,
    count_per_chat: int,
    max_chats: int,
    wait_seconds: int,
    preferred_chat_jids: list[str] | None = None,
) -> dict:
    groups_synced = 0
    contacts_synced = 0
    warnings: list[str] = []

    try:
        groups_synced = len(sync_joined_groups(client))
    except Exception as error:
        warnings.append(f"group-sync-error={error}")

    try:
        contacts_synced = sync_contacts_from_whatsapp(client)
    except Exception as error:
        warnings.append(f"contact-sync-error={error}")

    reset_history_sync_stats()
    history_request = request_on_demand_history(
        client,
        count_per_chat=max(1, int(count_per_chat)),
        max_chats=max(1, int(max_chats)),
        preferred_chat_jids=preferred_chat_jids,
    )

    if wait_seconds > 0:
        time.sleep(min(max(wait_seconds, 0), 30))

    stats = get_history_sync_stats()
    return {
        "groups_synced": groups_synced,
        "contacts_synced": contacts_synced,
        "history_request": history_request,
        "stats": stats,
        "warnings": warnings,
    }


def _archive_counts_by_chat() -> tuple[int, dict[str, int]]:
    total_archived = 0
    by_chat: dict[str, int] = {}

    for row in iter_archived_messages():
        if not isinstance(row, dict):
            continue

        chat_jid = str(row.get("chat_jid") or "").strip()
        if not chat_jid:
            peer = normalize_external_user_id(str(row.get("peer_number") or row.get("from_") or ""))
            if peer:
                chat_jid = f"{peer}@s.whatsapp.net"
        if not chat_jid:
            continue

        by_chat[chat_jid] = by_chat.get(chat_jid, 0) + 1
        total_archived += 1

    return total_archived, by_chat


def _history_validation_snapshot() -> dict:
    directory = load_whatsapp_directory()
    groups = directory.get("groups", []) if isinstance(directory, dict) else []

    group_name_by_jid: dict[str, str] = {}
    for group in groups:
        if not isinstance(group, dict):
            continue
        jid = str(group.get("jid") or "").strip()
        if not jid.endswith("@g.us"):
            continue
        name = str(group.get("name") or jid).strip() or jid
        group_name_by_jid[jid] = name

    total_archived, by_chat = _archive_counts_by_chat()
    known_group_jids = sorted(group_name_by_jid.keys())
    groups_with_archive = [jid for jid in known_group_jids if by_chat.get(jid, 0) > 0]
    groups_without_archive = [jid for jid in known_group_jids if by_chat.get(jid, 0) <= 0]

    return {
        "total_archived": total_archived,
        "known_groups": len(known_group_jids),
        "groups_with_archive": len(groups_with_archive),
        "groups_without_archive": groups_without_archive,
        "group_name_by_jid": group_name_by_jid,
    }


def sync_all_whatsapp_data_auto_validate(
    *,
    max_rounds: int = 12,
    wait_seconds: int = 8,
    force_remote: bool = False,
    preferred_chat_jids: list[str] | None = None,
) -> str:
    """Run adaptive sync rounds and validate local archive coverage automatically."""
    client, error = _resolve_client_or_error()
    if error:
        return error

    safe_max_rounds = max(1, min(int(max_rounds), 40))
    safe_wait_seconds = max(0, min(int(wait_seconds), 30))

    dynamic_count_per_chat = 250
    dynamic_max_chats = 120
    idle_rounds = 0
    rounds_executed = 0

    total_requested = 0
    total_request_errors = 0
    total_usync_timeouts = 0
    total_preferred_requested = 0
    total_preferred_errors = 0
    total_events = 0
    total_messages_seen = 0
    total_messages_archived = 0

    snapshot = _history_validation_snapshot()
    previous_archived_total = int(snapshot["total_archived"])

    lines = ["Sincronización + validación automática de historial iniciada:"]
    lines.append(
        f"- parámetros automáticos: max_rounds={safe_max_rounds} wait_seconds={safe_wait_seconds}"
    )
    lines.append(
        "- estado inicial: "
        f"archived_messages={snapshot['total_archived']} "
        f"groups_with_archive={snapshot['groups_with_archive']}/{snapshot['known_groups']}"
    )

    if (
        not force_remote
        and int(snapshot["known_groups"]) > 0
        and len(snapshot["groups_without_archive"]) == 0
    ):
        lines.append(
            "- corte automático inicial: todos los grupos conocidos ya tienen historial archivado local; "
            "se omiten solicitudes remotas en esta corrida."
        )
        lines.append("- rondas ejecutadas: 0")
        lines.append("- total solicitudes de historial: requested=0 errors=0 usync_timeouts=0")
        lines.append("- total ingestión HistorySync: events=0 messages=0/0")
        lines.append(
            "- estado final: "
            f"archived_messages={snapshot['total_archived']} "
            f"groups_with_archive={snapshot['groups_with_archive']}/{snapshot['known_groups']}"
        )
        lines.append("- validación automática: completa (todos los grupos conocidos tienen historial archivado).")
        return "\n".join(lines)

    for round_index in range(1, safe_max_rounds + 1):
        result = _run_single_sync_round(
            client,
            count_per_chat=dynamic_count_per_chat,
            max_chats=dynamic_max_chats,
            wait_seconds=safe_wait_seconds,
            preferred_chat_jids=preferred_chat_jids,
        )
        rounds_executed += 1

        stats = result["stats"]
        history_request = result["history_request"]
        snapshot = _history_validation_snapshot()
        current_archived_total = int(snapshot["total_archived"])
        growth = current_archived_total - previous_archived_total
        previous_archived_total = current_archived_total

        total_requested += int(history_request["requested"])
        total_request_errors += int(history_request["errors"])
        total_usync_timeouts += int(history_request.get("usync_timeouts", 0))
        total_preferred_requested += int(history_request.get("preferred_requested", 0))
        total_preferred_errors += int(history_request.get("preferred_errors", 0))
        total_events += int(stats["events"])
        total_messages_seen += int(stats["messages_seen"])
        total_messages_archived += int(stats["messages_archived"])

        lines.append(
            f"- ronda {round_index}: count_per_chat={dynamic_count_per_chat} max_chats={dynamic_max_chats} "
            f"requested={history_request['requested']} "
            f"preferred={history_request.get('preferred_requested', 0)}/{history_request.get('preferred_candidates', 0)} "
            f"group_fallback={history_request.get('group_fallback_requested', 0)}/{history_request.get('group_fallback_candidates', 0)} "
            f"usync_timeouts={history_request.get('usync_timeouts', 0)} "
            f"events={stats['events']} messages={stats['messages_archived']}/{stats['messages_seen']} "
            f"growth={growth} groups_with_archive={snapshot['groups_with_archive']}/{snapshot['known_groups']}"
        )
        if result["warnings"]:
            lines.append("  avisos: " + " | ".join(result["warnings"]))

        if history_request.get("abort_reason") == "usync-timeout":
            lines.append(
                "- corte automático: timeout consultando lista de dispositivos (usync). "
                "Se detienen solicitudes adicionales para evitar flood de errores."
            )
            break

        round_activity = (
            growth > 0
            or int(stats["messages_archived"]) > 0
            or int(stats["events"]) > 0
        )
        if round_activity:
            idle_rounds = 0
        else:
            idle_rounds += 1

        dynamic_count_per_chat = min(1200, dynamic_count_per_chat + 150)
        dynamic_max_chats = min(1000, dynamic_max_chats + 80)

        if int(snapshot["known_groups"]) > 0 and len(snapshot["groups_without_archive"]) == 0 and idle_rounds >= 1:
            lines.append("- corte automático: todos los grupos conocidos tienen historial archivado local.")
            break

        if idle_rounds >= 3:
            lines.append("- corte automático: 3 rondas seguidas sin crecimiento de historial local.")
            break

    lines.append(f"- rondas ejecutadas: {rounds_executed}")
    lines.append(
        "- total solicitudes de historial: "
        f"requested={total_requested} errors={total_request_errors} usync_timeouts={total_usync_timeouts} "
        f"preferred={total_preferred_requested} preferred_errors={total_preferred_errors}"
    )
    lines.append(
        "- total ingestión HistorySync: "
        f"events={total_events} messages={total_messages_archived}/{total_messages_seen}"
    )
    lines.append(
        "- estado final: "
        f"archived_messages={snapshot['total_archived']} "
        f"groups_with_archive={snapshot['groups_with_archive']}/{snapshot['known_groups']}"
    )

    pending_group_jids = list(snapshot["groups_without_archive"])
    if pending_group_jids:
        lines.append(f"- validación automática: incompleta ({len(pending_group_jids)} grupos sin historial archivado).")
        labels: list[str] = []
        group_name_by_jid = snapshot["group_name_by_jid"]
        for jid in pending_group_jids[:10]:
            labels.append(f"{group_name_by_jid.get(jid, jid)} ({jid})")
        lines.append("- grupos pendientes: " + " | ".join(labels))
        if len(pending_group_jids) > 10:
            lines.append(f"- grupos pendientes adicionales: {len(pending_group_jids) - 10}")
        if total_requested > 0 and total_events == 0:
            lines.append(
                "- diagnóstico: se enviaron solicitudes, pero WhatsApp no devolvió eventos HistorySync. "
                "No hay parámetro adicional local que fuerce ese backfill cuando el servidor no lo entrega."
            )
        if total_usync_timeouts > 0:
            lines.append(
                "- diagnóstico adicional: hubo timeout de usync (lista de dispositivos). "
                "Recomendado: /wa off, esperar 5s, /wa on y reintentar sync auto."
            )
    else:
        lines.append("- validación automática: completa (todos los grupos conocidos tienen historial archivado).")

    return "\n".join(lines)


def sync_all_whatsapp_data(
    *,
    count_per_chat: int = 200,
    max_chats: int = 100,
    wait_seconds: int = 8,
) -> str:
    client, error = _resolve_client_or_error()
    if error:
        return error

    result = _run_single_sync_round(
        client,
        count_per_chat=count_per_chat,
        max_chats=max_chats,
        wait_seconds=wait_seconds,
    )
    history_request = result["history_request"]
    stats = result["stats"]

    lines = ["Sincronización WhatsApp (best-effort) completada:"]
    lines.append(f"- grupos sincronizados: {result['groups_synced']}")
    lines.append(f"- contactos sincronizados: {result['contacts_synced']}")
    lines.append(
        "- solicitudes de historial: "
        f"anchors={history_request['anchors']} requested={history_request['requested']} errors={history_request['errors']}"
        f" group_fallback={history_request.get('group_fallback_requested', 0)}/{history_request.get('group_fallback_candidates', 0)}"
        f" usync_timeouts={history_request.get('usync_timeouts', 0)}"
    )
    lines.append(
        "- ingestión HistorySync: "
        f"events={stats['events']} conversations={stats['conversations']} "
        f"messages={stats['messages_archived']}/{stats['messages_seen']} media={stats['media_downloaded']} errors={stats['errors']}"
    )

    if int(history_request.get("group_fallback_candidates", 0)) > 0 and int(history_request.get("group_fallback_requested", 0)) == 0:
        lines.append(
            "- diagnóstico: hay grupos sin anchor local, pero el presupuesto de max_chats se agotó con anchors existentes."
        )

    if int(history_request.get("requested", 0)) > 0 and int(stats.get("events", 0)) == 0:
        lines.append(
            "- diagnóstico: se enviaron solicitudes HistorySync, pero WhatsApp no devolvió eventos. "
            "Esto suele indicar límite de backfill remoto o falta de ancla válida para ese chat."
        )

    if history_request.get("abort_reason") == "usync-timeout":
        lines.append(
            "- diagnóstico adicional: timeout de usync al enviar solicitudes. "
            "Recomendado: /wa off, esperar 5s, /wa on y reintentar."
        )

    if result["warnings"]:
        lines.append("- avisos: " + " | ".join(result["warnings"]))

    lines.append(
        "Nota: WhatsApp/Neonize puede limitar cuánto historial remoto entrega por corrida. "
        "Puedes repetir /wa sync para continuar backfill."
    )
    return "\n".join(lines)


def sync_all_whatsapp_data_multi(
    *,
    rounds: int = 6,
    count_per_chat: int = 200,
    max_chats: int = 100,
    wait_seconds: int = 8,
    idle_break_rounds: int = 2,
) -> str:
    client, error = _resolve_client_or_error()
    if error:
        return error

    safe_rounds = max(1, min(int(rounds), 30))
    safe_idle_break_rounds = max(1, min(int(idle_break_rounds), 5))

    totals = {
        "groups_synced": 0,
        "contacts_synced": 0,
        "anchors": 0,
        "requested": 0,
        "request_errors": 0,
        "usync_timeouts": 0,
        "group_fallback_candidates": 0,
        "group_fallback_requested": 0,
        "group_fallback_errors": 0,
        "events": 0,
        "conversations": 0,
        "messages_seen": 0,
        "messages_archived": 0,
        "media_downloaded": 0,
        "ingest_errors": 0,
    }

    lines = ["Sincronización WhatsApp ALL (best-effort) iniciada:"]
    lines.append(
        f"- parámetros: rounds={safe_rounds} count_per_chat={count_per_chat} "
        f"max_chats={max_chats} wait_seconds={wait_seconds}"
    )

    idle_rounds = 0
    executed_rounds = 0
    for round_index in range(1, safe_rounds + 1):
        result = _run_single_sync_round(
            client,
            count_per_chat=count_per_chat,
            max_chats=max_chats,
            wait_seconds=wait_seconds,
        )
        executed_rounds += 1
        stats = result["stats"]
        history_request = result["history_request"]

        totals["groups_synced"] += int(result["groups_synced"])
        totals["contacts_synced"] += int(result["contacts_synced"])
        totals["anchors"] += int(history_request["anchors"])
        totals["requested"] += int(history_request["requested"])
        totals["request_errors"] += int(history_request["errors"])
        totals["usync_timeouts"] += int(history_request.get("usync_timeouts", 0))
        totals["group_fallback_candidates"] += int(history_request.get("group_fallback_candidates", 0))
        totals["group_fallback_requested"] += int(history_request.get("group_fallback_requested", 0))
        totals["group_fallback_errors"] += int(history_request.get("group_fallback_errors", 0))
        totals["events"] += int(stats["events"])
        totals["conversations"] += int(stats["conversations"])
        totals["messages_seen"] += int(stats["messages_seen"])
        totals["messages_archived"] += int(stats["messages_archived"])
        totals["media_downloaded"] += int(stats["media_downloaded"])
        totals["ingest_errors"] += int(stats["errors"])

        lines.append(
            f"- ronda {round_index}: groups={result['groups_synced']} contacts={result['contacts_synced']} "
            f"requested={history_request['requested']} "
            f"group_fallback={history_request.get('group_fallback_requested', 0)}/{history_request.get('group_fallback_candidates', 0)} "
            f"usync_timeouts={history_request.get('usync_timeouts', 0)} "
            f"events={stats['events']} "
            f"messages={stats['messages_archived']}/{stats['messages_seen']} media={stats['media_downloaded']}"
        )
        if result["warnings"]:
            lines.append("  avisos: " + " | ".join(result["warnings"]))

        if history_request.get("abort_reason") == "usync-timeout":
            lines.append(
                "- corte temprano: timeout de usync en solicitudes de historial; se abortan rondas restantes."
            )
            break

        round_activity = (
            int(stats["messages_archived"]) > 0
            or int(stats["events"]) > 0
            or int(stats["media_downloaded"]) > 0
        )
        if round_activity:
            idle_rounds = 0
        else:
            idle_rounds += 1
            if idle_rounds >= safe_idle_break_rounds:
                lines.append(
                    f"- corte temprano: {safe_idle_break_rounds} rondas seguidas sin actividad nueva."
                )
                break

    lines.append(f"- rondas ejecutadas: {executed_rounds}")
    lines.append(f"- total grupos sincronizados: {totals['groups_synced']}")
    lines.append(f"- total contactos sincronizados: {totals['contacts_synced']}")
    lines.append(
        "- total solicitudes de historial: "
        f"anchors={totals['anchors']} requested={totals['requested']} errors={totals['request_errors']} "
        f"usync_timeouts={totals['usync_timeouts']} "
        f"group_fallback={totals['group_fallback_requested']}/{totals['group_fallback_candidates']}"
    )
    lines.append(
        "- total ingestión HistorySync: "
        f"events={totals['events']} conversations={totals['conversations']} "
        f"messages={totals['messages_archived']}/{totals['messages_seen']} "
        f"media={totals['media_downloaded']} errors={totals['ingest_errors']}"
    )
    if int(totals["requested"]) > 0 and int(totals["events"]) == 0:
        lines.append(
            "- diagnóstico: se enviaron solicitudes HistorySync pero no llegaron eventos de retorno en ninguna ronda. "
            "El servidor de WhatsApp puede no entregar backfill para esos chats en este estado."
        )
    if int(totals["usync_timeouts"]) > 0:
        lines.append(
            "- diagnóstico adicional: hubo timeout de usync (lista de dispositivos) durante la corrida. "
            "Recomendado: /wa off, esperar 5s, /wa on y reintentar /wa sync (auto) o /wa sync <target>."
        )
        snapshot = _history_validation_snapshot()
        lines.append(
            "- fallback sugerido: usa /wa sync para validación adaptativa (evita insistir en modo all). "
            f"Estado local actual: groups_with_archive={snapshot['groups_with_archive']}/{snapshot['known_groups']} "
            f"archived_messages={snapshot['total_archived']}."
        )
    lines.append(
        "Nota: aunque uses 'all', WhatsApp/Neonize puede limitar el backfill remoto. "
        "Si aún falta historial, prefiere /wa sync (auto) o /wa sync <target> para iterar por chat."
    )
    return "\n".join(lines)
