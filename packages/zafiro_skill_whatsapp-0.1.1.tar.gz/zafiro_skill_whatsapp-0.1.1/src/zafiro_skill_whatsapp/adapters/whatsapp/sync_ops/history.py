"""HistorySync ingestion and on-demand backfill helpers."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import logging
import threading
import time

from neonize.builder import build_history_sync_request
from neonize.proto import Neonize_pb2 as neonize_proto

from zafiro_skill_whatsapp.adapters.whatsapp.contacts_ops.discovery import remember_contact, remember_group
from zafiro_skill_whatsapp.adapters.whatsapp.message_ops.processing import populate_payload_from_message
from zafiro_skill_whatsapp.adapters.whatsapp.runtime_ops.state import (
    build_chat_jid,
    cache_incoming_message,
    contact_session_id,
)
from zafiro_skill_whatsapp.integrations import (
    archive_whatsapp_payload,
    iter_archived_messages,
    load_whatsapp_directory,
    normalize_external_user_id,
)

logger = logging.getLogger(__name__)


@dataclass
class HistorySyncStats:
    events: int = 0
    conversations: int = 0
    messages_seen: int = 0
    messages_archived: int = 0
    media_downloaded: int = 0
    errors: int = 0


_STATS = HistorySyncStats()
_STATS_LOCK = threading.Lock()


def reset_history_sync_stats() -> None:
    with _STATS_LOCK:
        _STATS.events = 0
        _STATS.conversations = 0
        _STATS.messages_seen = 0
        _STATS.messages_archived = 0
        _STATS.media_downloaded = 0
        _STATS.errors = 0


def get_history_sync_stats() -> dict:
    with _STATS_LOCK:
        return asdict(_STATS)


def _add_history_sync_stats(**delta: int) -> None:
    with _STATS_LOCK:
        for key, value in delta.items():
            setattr(_STATS, key, int(getattr(_STATS, key)) + int(value))


def _parse_timestamp_ms(raw_timestamp: int) -> str:
    timestamp = int(raw_timestamp or 0)
    if timestamp <= 0:
        return datetime.now(timezone.utc).isoformat()
    if timestamp > 10_000_000_000:
        timestamp /= 1000.0
    return datetime.fromtimestamp(timestamp, timezone.utc).isoformat()


def _parse_received_at_ms(raw_received_at: str) -> int:
    value = (raw_received_at or "").strip()
    if not value:
        return int(time.time() * 1000)
    if value.endswith("Z"):
        value = value[:-1] + "+00:00"
    try:
        parsed = datetime.fromisoformat(value)
    except ValueError:
        return int(time.time() * 1000)
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return int(parsed.timestamp() * 1000)


def _sender_jid_for_message(chat_jid: str, participant_jid: str) -> str:
    if chat_jid.endswith("@g.us") and participant_jid:
        return participant_jid
    return chat_jid


def _build_history_payload(web_message, conversation_id: str) -> dict:
    key = web_message.key
    chat_jid = str(getattr(key, "remoteJID", "") or conversation_id or "")
    participant_jid = str(getattr(key, "participant", "") or "")
    sender_jid = _sender_jid_for_message(chat_jid, participant_jid)
    sender_user = sender_jid.split("@", 1)[0] if sender_jid else ""
    message_id = str(getattr(key, "ID", "") or "").strip() or f"history-{int(time.time() * 1000)}"
    timestamp_iso = _parse_timestamp_ms(getattr(web_message, "messageTimestamp", 0))
    direction = "outbound" if bool(getattr(key, "fromMe", False)) else "inbound"

    return {
        "direction": direction,
        "delivery_status": "received" if direction == "inbound" else "sent",
        "from_": sender_user,
        "peer_number": sender_user,
        "jid": sender_jid,
        "type": "text",
        "received_at": timestamp_iso,
        "raw_text": None,
        "audio_transcription": None,
        "image_analysis": None,
        "media_path": None,
        "mime_type": None,
        "source_channel": "whatsapp",
        "message_id": message_id,
        "reply_to_message_id": None,
        "chat_jid": chat_jid,
        "sender_jid": sender_jid,
        "session_id": contact_session_id(sender_user),
    }


def _remember_payload_endpoints(payload: dict) -> None:
    peer_number = normalize_external_user_id(str(payload.get("peer_number") or ""))
    if peer_number:
        remember_contact(peer_number, note="history-sync")

    chat_jid = str(payload.get("chat_jid") or "")
    if chat_jid.endswith("@g.us"):
        remember_group(chat_jid, note="history-sync")


def _ingest_history_message(client, web_message, conversation_id: str) -> tuple[bool, bool]:
    payload = _build_history_payload(web_message, conversation_id)

    populated = False
    try:
        populated = populate_payload_from_message(client, web_message.message, payload)
    except Exception as error:
        logger.debug("HistorySync payload parsing failed for %s: %s", payload.get("message_id"), error)

    if not populated and payload.get("raw_text") is None:
        payload["type"] = "unknown"

    cache_incoming_message(payload, web_message)
    _remember_payload_endpoints(payload)
    archive_whatsapp_payload(payload)
    return True, bool(payload.get("media_path"))


def handle_history_sync_event(client, event) -> None:
    data = getattr(event, "Data", None)
    if data is None:
        return

    local_events = 1
    local_conversations = 0
    local_messages_seen = 0
    local_messages_archived = 0
    local_media = 0
    local_errors = 0

    for conversation in list(getattr(data, "conversations", []) or []):
        local_conversations += 1
        conversation_id = str(getattr(conversation, "ID", "") or getattr(conversation, "newJID", "") or "")
        if conversation_id.endswith("@g.us"):
            remember_group(conversation_id, name=str(getattr(conversation, "name", "") or conversation_id), note="history-sync")
        elif conversation_id.endswith("@s.whatsapp.net"):
            remember_contact(conversation_id.split("@", 1)[0], name=str(getattr(conversation, "name", "") or ""), note="history-sync")

        for history_msg in list(getattr(conversation, "messages", []) or []):
            local_messages_seen += 1
            try:
                archived, has_media = _ingest_history_message(client, history_msg.message, conversation_id)
                if archived:
                    local_messages_archived += 1
                if has_media:
                    local_media += 1
            except Exception as error:
                local_errors += 1
                logger.debug("HistorySync ingest error: %s", error)

    _add_history_sync_stats(
        events=local_events,
        conversations=local_conversations,
        messages_seen=local_messages_seen,
        messages_archived=local_messages_archived,
        media_downloaded=local_media,
        errors=local_errors,
    )


def _oldest_anchor_by_chat(max_chats: int) -> list[dict]:
    anchors: dict[str, tuple[int, dict]] = {}
    for row in iter_archived_messages():
        if not isinstance(row, dict):
            continue

        message_id = str(row.get("message_id") or "").strip()
        if not message_id:
            continue

        chat_jid = str(row.get("chat_jid") or "").strip()
        if not chat_jid:
            peer = normalize_external_user_id(str(row.get("peer_number") or row.get("from_") or ""))
            if not peer:
                continue
            chat_jid = f"{peer}@s.whatsapp.net"

        ts_ms = _parse_received_at_ms(str(row.get("received_at") or ""))
        current = anchors.get(chat_jid)
        if current is None or ts_ms < current[0]:
            anchors[chat_jid] = (ts_ms, row)

    ordered = sorted(anchors.items(), key=lambda item: item[1][0])
    return [row for _chat, (_ts, row) in ordered[: max(1, max_chats)]]


def _known_group_jids_without_anchor(*, anchored_chat_jids: set[str]) -> list[str]:
    try:
        directory = load_whatsapp_directory()
    except Exception:
        return []

    groups = directory.get("groups", []) if isinstance(directory, dict) else []
    seen: set[str] = set()
    ordered: list[str] = []
    for group in groups:
        if not isinstance(group, dict):
            continue
        jid = str(group.get("jid") or "").strip()
        if not jid or not jid.endswith("@g.us"):
            continue
        if jid in anchored_chat_jids or jid in seen:
            continue
        seen.add(jid)
        ordered.append(jid)
    return ordered


def _resolve_my_jid(client) -> str:
    try:
        me = client.get_me()
    except Exception:
        return ""

    jid = getattr(me, "JID", None)
    if jid is None:
        return ""

    user = str(getattr(jid, "User", "") or "")
    server = str(getattr(jid, "Server", "") or "")
    if not user or not server:
        return ""
    return f"{user}@{server}"


def _send_on_demand_history_request(
    client,
    *,
    chat_jid: str,
    message_id: str,
    sender_jid: str,
    direction: str,
    received_at: str,
    count_per_chat: int,
) -> None:
    source = neonize_proto.MessageSource(
        Chat=build_chat_jid(chat_jid),
        Sender=build_chat_jid(sender_jid or chat_jid),
        IsFromMe=str(direction or "").lower() == "outbound",
        IsGroup=chat_jid.endswith("@g.us"),
    )
    message_info = neonize_proto.MessageInfo(
        MessageSource=source,
        ID=message_id,
        Timestamp=_parse_received_at_ms(received_at),
    )
    sync_request = build_history_sync_request(message_info, max(1, int(count_per_chat)))
    client.send_message(build_chat_jid(chat_jid), sync_request)


def _is_usync_timeout_error(error: Exception) -> bool:
    message = str(error or "").lower()
    return "usync" in message and "timed out" in message


def _normalize_chat_jid_reference(value: str) -> str:
    raw = str(value or "").strip()
    if not raw:
        return ""

    lower = raw.lower()
    if lower.endswith("@g.us") or lower.endswith("@s.whatsapp.net"):
        return raw

    normalized = normalize_external_user_id(raw)
    if normalized:
        return f"{normalized}@s.whatsapp.net"
    return ""


def request_on_demand_history(
    client,
    *,
    count_per_chat: int,
    max_chats: int,
    preferred_chat_jids: list[str] | None = None,
) -> dict:
    safe_max_chats = max(1, int(max_chats))
    safe_count_per_chat = max(1, int(count_per_chat))

    preferred_targets: list[str] = []
    seen_preferred: set[str] = set()
    for raw_target in list(preferred_chat_jids or []):
        normalized_target = _normalize_chat_jid_reference(raw_target)
        if not normalized_target or normalized_target in seen_preferred:
            continue
        seen_preferred.add(normalized_target)
        preferred_targets.append(normalized_target)

    anchors = _oldest_anchor_by_chat(max_chats=safe_max_chats)
    anchored_chat_jids: set[str] = set()
    requested_chat_jids: set[str] = set()

    requested = 0
    errors = 0
    usync_timeouts = 0
    abort_reason = ""
    preferred_requested = 0
    preferred_errors = 0

    my_jid = _resolve_my_jid(client)
    now_iso = datetime.now(timezone.utc).isoformat()
    now_ms = int(time.time() * 1000)

    for index, preferred_chat_jid in enumerate(preferred_targets, start=1):
        if requested >= safe_max_chats:
            break
        synthetic_id = f"preferred-bootstrap-{now_ms}-{index}"
        try:
            _send_on_demand_history_request(
                client,
                chat_jid=preferred_chat_jid,
                message_id=synthetic_id,
                sender_jid=my_jid or preferred_chat_jid,
                direction="inbound",
                received_at=now_iso,
                count_per_chat=safe_count_per_chat,
            )
            requested += 1
            preferred_requested += 1
            requested_chat_jids.add(preferred_chat_jid)
        except Exception as error:
            logger.debug("Preferred on-demand request failed for %s: %s", preferred_chat_jid, error)
            errors += 1
            preferred_errors += 1
            if _is_usync_timeout_error(error):
                usync_timeouts += 1
                abort_reason = "usync-timeout"
                break

    if not abort_reason:
        for row in anchors:
            if requested >= safe_max_chats:
                break

            chat_jid = str(row.get("chat_jid") or "")
            message_id = str(row.get("message_id") or "")
            if not chat_jid or not message_id:
                continue
            anchored_chat_jids.add(chat_jid)
            if chat_jid in requested_chat_jids:
                continue

            try:
                _send_on_demand_history_request(
                    client,
                    chat_jid=chat_jid,
                    message_id=message_id,
                    sender_jid=str(row.get("sender_jid") or row.get("jid") or chat_jid),
                    direction=str(row.get("direction") or "inbound"),
                    received_at=str(row.get("received_at") or ""),
                    count_per_chat=safe_count_per_chat,
                )
                requested += 1
                requested_chat_jids.add(chat_jid)
            except Exception as error:
                logger.debug("On-demand history request failed for %s: %s", chat_jid, error)
                errors += 1
                if _is_usync_timeout_error(error):
                    usync_timeouts += 1
                    abort_reason = "usync-timeout"
                    break

    known_groups_without_anchor = _known_group_jids_without_anchor(
        anchored_chat_jids=anchored_chat_jids | requested_chat_jids
    )
    group_budget = 0 if abort_reason else max(0, safe_max_chats - requested)
    group_fallback_targets = known_groups_without_anchor[:group_budget]

    group_fallback_requested = 0
    group_fallback_errors = 0

    for index, group_jid in enumerate(group_fallback_targets, start=1):
        if group_jid in requested_chat_jids:
            continue
        synthetic_id = f"bootstrap-{now_ms}-{index}"
        try:
            _send_on_demand_history_request(
                client,
                chat_jid=group_jid,
                message_id=synthetic_id,
                sender_jid=my_jid or group_jid,
                direction="inbound",
                received_at=now_iso,
                count_per_chat=safe_count_per_chat,
            )
            requested += 1
            group_fallback_requested += 1
            requested_chat_jids.add(group_jid)
        except Exception as error:
            logger.debug("Group fallback on-demand request failed for %s: %s", group_jid, error)
            errors += 1
            group_fallback_errors += 1
            if _is_usync_timeout_error(error):
                usync_timeouts += 1
                abort_reason = "usync-timeout"
                break

    return {
        "anchors": len(anchors),
        "requested": requested,
        "errors": errors,
        "preferred_candidates": len(preferred_targets),
        "preferred_requested": preferred_requested,
        "preferred_errors": preferred_errors,
        "group_fallback_candidates": len(known_groups_without_anchor),
        "group_fallback_requested": group_fallback_requested,
        "group_fallback_errors": group_fallback_errors,
        "usync_timeouts": usync_timeouts,
        "aborted": bool(abort_reason),
        "abort_reason": abort_reason,
    }
