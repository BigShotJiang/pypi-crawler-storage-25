"""Adapter namespace for WhatsApp skill package."""
