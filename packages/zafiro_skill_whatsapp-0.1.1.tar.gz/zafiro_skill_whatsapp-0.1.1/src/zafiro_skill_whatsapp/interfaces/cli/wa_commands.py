"""WhatsApp admin command handlers extracted from chat CLI."""

from __future__ import annotations

import shlex

from zafiro_skill_whatsapp.adapters.whatsapp.contacts import normalize_whatsapp_target
from zafiro_skill_whatsapp.admin import (
    describe_whatsapp_actor,
    wa_is_running,
    wa_recover,
    wa_sync_auto_read_archive,
    wa_sync_auto_validate,
    wa_sync_all,
    wa_sync_full,
    wa_start,
    wa_stop,
)
from zafiro_skill_whatsapp.integrations import delete_user_agent_access, upsert_user_agent_access


def _parse_optional_int(
    values: list[str],
    index: int,
    *,
    default: int,
    minimum: int,
    maximum: int,
    label: str,
) -> tuple[int | None, str | None]:
    if len(values) <= index:
        return default, None
    raw = (values[index] or "").strip()
    try:
        parsed = int(raw)
    except ValueError:
        return None, f"{label} debe ser entero."
    if parsed < minimum or parsed > maximum:
        return None, f"{label} debe estar entre {minimum} y {maximum}."
    return parsed, None


def _print_sync_usage() -> None:
    print("  Uso recomendado: /wa sync [target] [limit] [max_rounds] [wait_seconds]")
    print("       /wa sync                            # sync global automático")
    print("       /wa sync Miguel                     # sync + lectura archive de target")
    print("       /wa sync Miguel 50 12 8             # target + overrides")
    print("  Compatibilidad: /wa sync auto [max_rounds] [wait_seconds]")
    print("                 /wa sync oneshot <target> [limit] [max_rounds] [wait_seconds]")
    print("                 /wa sync os <target> [limit] [max_rounds] [wait_seconds]")
    print("  Avanzado: /wa sync all [rounds] [count_per_chat] [max_chats] [wait_seconds]  # puede fallar por usync timeout")


def handle_wa_command(
    arg: str,
    *,
    wa_start_fn=wa_start,
    wa_stop_fn=wa_stop,
    wa_recover_fn=wa_recover,
    wa_sync_auto_read_archive_fn=wa_sync_auto_read_archive,
    wa_sync_auto_validate_fn=wa_sync_auto_validate,
    wa_sync_all_fn=wa_sync_all,
    wa_sync_full_fn=wa_sync_full,
    wa_is_running_fn=wa_is_running,
    set_access_rule_fn=upsert_user_agent_access,
    remove_access_rule_fn=delete_user_agent_access,
    describe_whatsapp_actor_fn=describe_whatsapp_actor,
) -> None:
    """Handle /wa subcommands and print user-facing output."""
    try:
        sub_parts = shlex.split(arg)
    except ValueError:
        sub_parts = []
    sub = sub_parts[0].lower() if sub_parts else ""

    if sub == "on":
        print(" ", wa_start_fn())
        return
    if sub == "off":
        print(" ", wa_stop_fn())
        return
    if sub in ("fix", "doctor", "repair"):
        print(" ", wa_recover_fn(reset_session=False))
        return
    if sub in ("reset", "relink"):
        print(" ", wa_recover_fn(reset_session=True))
        return
    if sub in ("sync", "resync", "pull"):
        mode = (sub_parts[1] if len(sub_parts) > 1 else "").strip().lower()

        if mode == "":
            print(
                " ",
                wa_sync_auto_validate_fn(
                    max_rounds=12,
                    wait_seconds=8,
                ),
            )
            return

        if mode in {"os", "quick", "fast"}:
            target = (sub_parts[2] if len(sub_parts) > 2 else "").strip()
            if not target:
                print("  Error: target es requerido (grupo, número o JID).")
                _print_sync_usage()
                return

            limit, error = _parse_optional_int(
                sub_parts,
                3,
                default=50,
                minimum=1,
                maximum=200,
                label="limit",
            )
            if error:
                print(f"  Error: {error}")
                _print_sync_usage()
                return

            max_rounds, error = _parse_optional_int(
                sub_parts,
                4,
                default=12,
                minimum=1,
                maximum=40,
                label="max_rounds",
            )
            if error:
                print(f"  Error: {error}")
                _print_sync_usage()
                return

            wait_seconds, error = _parse_optional_int(
                sub_parts,
                5,
                default=8,
                minimum=0,
                maximum=30,
                label="wait_seconds",
            )
            if error:
                print(f"  Error: {error}")
                _print_sync_usage()
                return

            print(
                " ",
                wa_sync_auto_read_archive_fn(
                    target=target,
                    limit=limit or 50,
                    max_rounds=max_rounds or 12,
                    wait_seconds=wait_seconds or 0,
                ),
            )
            return

        if mode in {"oneshot", "one-shot", "auto-read", "autorun"}:
            target = (sub_parts[2] if len(sub_parts) > 2 else "").strip()
            if not target:
                print("  Error: target es requerido (grupo, número o JID).")
                _print_sync_usage()
                return

            limit, error = _parse_optional_int(
                sub_parts,
                3,
                default=50,
                minimum=1,
                maximum=200,
                label="limit",
            )
            if error:
                print(f"  Error: {error}")
                _print_sync_usage()
                return

            max_rounds, error = _parse_optional_int(
                sub_parts,
                4,
                default=12,
                minimum=1,
                maximum=40,
                label="max_rounds",
            )
            if error:
                print(f"  Error: {error}")
                _print_sync_usage()
                return

            wait_seconds, error = _parse_optional_int(
                sub_parts,
                5,
                default=8,
                minimum=0,
                maximum=30,
                label="wait_seconds",
            )
            if error:
                print(f"  Error: {error}")
                _print_sync_usage()
                return

            print(
                " ",
                wa_sync_auto_read_archive_fn(
                    target=target,
                    limit=limit or 50,
                    max_rounds=max_rounds or 12,
                    wait_seconds=wait_seconds or 0,
                ),
            )
            return

        # Single-command UX: `/wa sync <target>` does one-shot sync+read for that target.
        # Keep short numeric forms as legacy tuning for the old deep-sync command.
        if mode not in {"all", "full", "auto", "validate", "audit"}:
            if mode.isdigit() and len(mode) <= 4:
                count_per_chat, error = _parse_optional_int(
                    sub_parts,
                    1,
                    default=200,
                    minimum=1,
                    maximum=2000,
                    label="count_per_chat",
                )
                if error:
                    print(f"  Error: {error}")
                    _print_sync_usage()
                    return
                max_chats, error = _parse_optional_int(
                    sub_parts,
                    2,
                    default=100,
                    minimum=1,
                    maximum=1000,
                    label="max_chats",
                )
                if error:
                    print(f"  Error: {error}")
                    _print_sync_usage()
                    return
                wait_seconds, error = _parse_optional_int(
                    sub_parts,
                    3,
                    default=8,
                    minimum=0,
                    maximum=30,
                    label="wait_seconds",
                )
                if error:
                    print(f"  Error: {error}")
                    _print_sync_usage()
                    return

                print(
                    " ",
                    wa_sync_full_fn(
                        count_per_chat=count_per_chat or 200,
                        max_chats=max_chats or 100,
                        wait_seconds=wait_seconds or 0,
                    ),
                )
                return

            target = (sub_parts[1] if len(sub_parts) > 1 else "").strip()
            if not target:
                print("  Error: target es requerido (grupo, número o JID).")
                _print_sync_usage()
                return

            limit, error = _parse_optional_int(
                sub_parts,
                2,
                default=50,
                minimum=1,
                maximum=200,
                label="limit",
            )
            if error:
                print(f"  Error: {error}")
                _print_sync_usage()
                return

            max_rounds, error = _parse_optional_int(
                sub_parts,
                3,
                default=12,
                minimum=1,
                maximum=40,
                label="max_rounds",
            )
            if error:
                print(f"  Error: {error}")
                _print_sync_usage()
                return

            wait_seconds, error = _parse_optional_int(
                sub_parts,
                4,
                default=8,
                minimum=0,
                maximum=30,
                label="wait_seconds",
            )
            if error:
                print(f"  Error: {error}")
                _print_sync_usage()
                return

            print(
                " ",
                wa_sync_auto_read_archive_fn(
                    target=target,
                    limit=limit or 50,
                    max_rounds=max_rounds or 12,
                    wait_seconds=wait_seconds or 0,
                ),
            )
            return

        if mode in {"auto", "validate", "audit"}:
            max_rounds, error = _parse_optional_int(
                sub_parts,
                2,
                default=12,
                minimum=1,
                maximum=40,
                label="max_rounds",
            )
            if error:
                print(f"  Error: {error}")
                _print_sync_usage()
                return

            wait_seconds, error = _parse_optional_int(
                sub_parts,
                3,
                default=8,
                minimum=0,
                maximum=30,
                label="wait_seconds",
            )
            if error:
                print(f"  Error: {error}")
                _print_sync_usage()
                return

            print(
                " ",
                wa_sync_auto_validate_fn(
                    max_rounds=max_rounds or 12,
                    wait_seconds=wait_seconds or 0,
                ),
            )
            return

        if mode in {"all", "full"}:
            rounds, error = _parse_optional_int(
                sub_parts,
                2,
                default=6,
                minimum=1,
                maximum=30,
                label="rounds",
            )
            if error:
                print(f"  Error: {error}")
                _print_sync_usage()
                return
            count_per_chat, error = _parse_optional_int(
                sub_parts,
                3,
                default=200,
                minimum=1,
                maximum=2000,
                label="count_per_chat",
            )
            if error:
                print(f"  Error: {error}")
                _print_sync_usage()
                return
            max_chats, error = _parse_optional_int(
                sub_parts,
                4,
                default=100,
                minimum=1,
                maximum=1000,
                label="max_chats",
            )
            if error:
                print(f"  Error: {error}")
                _print_sync_usage()
                return
            wait_seconds, error = _parse_optional_int(
                sub_parts,
                5,
                default=8,
                minimum=0,
                maximum=30,
                label="wait_seconds",
            )
            if error:
                print(f"  Error: {error}")
                _print_sync_usage()
                return

            print(
                " ",
                wa_sync_all_fn(
                    rounds=rounds or 6,
                    count_per_chat=count_per_chat or 200,
                    max_chats=max_chats or 100,
                    wait_seconds=wait_seconds or 0,
                ),
            )
            return
    if sub == "link":
        if len(sub_parts) < 4:
            print('  Uso: /wa link <numero_o_jid> "<default_agent>" "<allowed1,allowed2>"')
            return
        target = normalize_whatsapp_target(sub_parts[1])
        if not target:
            print("  Target inválido. Usa número o JID de grupo válido (@g.us).")
            return
        default_agent = sub_parts[2]
        allowed_agents = [item.strip() for item in sub_parts[3].split(",") if item.strip()]
        set_access_rule_fn(
            "whatsapp",
            target,
            allowed_agent_names=allowed_agents,
            default_agent_name=default_agent,
        )
        print(" ", f"Linked {target} to default agent {default_agent}.")
        return
    if sub in ("unlink", "rm", "remove"):
        if len(sub_parts) < 2:
            print("  Uso: /wa unlink <numero_o_jid>")
            return
        target = normalize_whatsapp_target(sub_parts[1])
        if not target:
            print("  Target inválido. Usa número o JID de grupo válido (@g.us).")
            return
        print(" ", remove_access_rule_fn("whatsapp", target))
        return
    if sub in ("actor", "whois"):
        if len(sub_parts) < 2:
            print("  Uso: /wa actor <numero_o_jid>")
            return
        print(describe_whatsapp_actor_fn(sub_parts[1]))
        return
    if sub in ("status", ""):
        state = "corriendo" if wa_is_running_fn() else "detenido"
        print(f"  WhatsApp: {state}")
        return

    print(
        "  Uso: /wa on | /wa off | /wa fix | /wa reset | /wa sync [target] | /wa sync all "
        "| /wa status | /wa link | /wa unlink | /wa actor"
    )
