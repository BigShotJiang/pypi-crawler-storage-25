"""CLI helpers for WhatsApp skill package."""
