"""Interfaces namespace for WhatsApp skill package."""
