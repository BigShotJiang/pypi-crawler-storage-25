from zafiro_skill_whatsapp.adapters.whatsapp.sync_ops import history as history_sync


def test_request_on_demand_history_aborts_on_usync_timeout(monkeypatch):
    monkeypatch.setattr(
        history_sync,
        "_oldest_anchor_by_chat",
        lambda max_chats: [
            {
                "chat_jid": "50611112222@s.whatsapp.net",
                "message_id": "anchor-1",
                "received_at": "2026-04-25T12:00:00+00:00",
                "direction": "inbound",
            }
        ],
    )
    monkeypatch.setattr(
        history_sync,
        "_known_group_jids_without_anchor",
        lambda anchored_chat_jids: ["120363000000000999@g.us"],
    )
    monkeypatch.setattr(history_sync, "_resolve_my_jid", lambda _client: "50582480271@s.whatsapp.net")

    attempted: list[str] = []

    def _fake_send(_client, **kwargs):
        attempted.append(str(kwargs.get("chat_jid") or ""))
        raise RuntimeError("failed to send usync query: info query timed out")

    monkeypatch.setattr(history_sync, "_send_on_demand_history_request", _fake_send)

    result = history_sync.request_on_demand_history(object(), count_per_chat=50, max_chats=10)

    assert result["aborted"] is True
    assert result["abort_reason"] == "usync-timeout"
    assert result["usync_timeouts"] == 1
    assert result["errors"] == 1
    assert result["requested"] == 0
    assert result["group_fallback_requested"] == 0
    assert attempted == ["50611112222@s.whatsapp.net"]


def test_request_on_demand_history_keeps_going_for_non_usync_errors(monkeypatch):
    monkeypatch.setattr(
        history_sync,
        "_oldest_anchor_by_chat",
        lambda max_chats: [
            {
                "chat_jid": "50611112222@s.whatsapp.net",
                "message_id": "anchor-1",
                "received_at": "2026-04-25T12:00:00+00:00",
                "direction": "inbound",
            },
            {
                "chat_jid": "50633334444@s.whatsapp.net",
                "message_id": "anchor-2",
                "received_at": "2026-04-25T12:01:00+00:00",
                "direction": "inbound",
            },
        ],
    )
    monkeypatch.setattr(
        history_sync,
        "_known_group_jids_without_anchor",
        lambda anchored_chat_jids: [],
    )
    monkeypatch.setattr(history_sync, "_resolve_my_jid", lambda _client: "50582480271@s.whatsapp.net")

    def _fake_send(_client, **kwargs):
        raise RuntimeError("generic request failure")

    monkeypatch.setattr(history_sync, "_send_on_demand_history_request", _fake_send)

    result = history_sync.request_on_demand_history(object(), count_per_chat=50, max_chats=10)

    assert result["aborted"] is False
    assert result["abort_reason"] == ""
    assert result["usync_timeouts"] == 0
    assert result["errors"] == 2
    assert result["requested"] == 0


def test_request_on_demand_history_prioritizes_preferred_chat_jid(monkeypatch):
    monkeypatch.setattr(
        history_sync,
        "_oldest_anchor_by_chat",
        lambda max_chats: [
            {
                "chat_jid": "50611112222@s.whatsapp.net",
                "message_id": "anchor-1",
                "received_at": "2026-04-25T12:00:00+00:00",
                "direction": "inbound",
            }
        ],
    )
    monkeypatch.setattr(
        history_sync,
        "_known_group_jids_without_anchor",
        lambda anchored_chat_jids: [],
    )
    monkeypatch.setattr(history_sync, "_resolve_my_jid", lambda _client: "50582480271@s.whatsapp.net")

    attempted: list[str] = []

    def _fake_send(_client, **kwargs):
        attempted.append(str(kwargs.get("chat_jid") or ""))

    monkeypatch.setattr(history_sync, "_send_on_demand_history_request", _fake_send)

    result = history_sync.request_on_demand_history(
        object(),
        count_per_chat=50,
        max_chats=1,
        preferred_chat_jids=["Miguel", "50577116731@s.whatsapp.net"],
    )

    assert attempted == ["50577116731@s.whatsapp.net"]
    assert result["preferred_candidates"] == 1
    assert result["preferred_requested"] == 1
    assert result["preferred_errors"] == 0
    assert result["requested"] == 1
