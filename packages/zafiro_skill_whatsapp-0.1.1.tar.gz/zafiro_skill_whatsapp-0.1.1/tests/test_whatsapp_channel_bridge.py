from zafiro_skill_whatsapp.adapters.whatsapp import contacts as wa_contacts
from zafiro_skill_whatsapp.extensions.skills.whatsapp import register_whatsapp_skill
from zafiro_skill_whatsapp.extensions.tools.whatsapp_policy_tools import register_whatsapp_policy_tools
from zafiro_skill_whatsapp.interfaces.cli.wa_commands import handle_wa_command


def test_contacts_back_compat_aliases_are_preserved():
    assert wa_contacts.normalize_whatsapp_target is wa_contacts.normalize_autoreply_target
    assert wa_contacts.migrate_legacy_autoreply_to_db is wa_contacts.migrate_legacy_autoreply_flags_to_db
    assert wa_contacts.is_autoreply_target_allowed is wa_contacts.is_reply_allowed


def test_policy_tools_registration_keeps_legacy_toggle_tool():
    registered = {}

    def _register_tool(name, _description, fn):
        registered[name] = fn

    register_whatsapp_policy_tools(_register_tool)

    assert "wa_policy" in registered
    assert "wa_set_autoreply" in registered
    assert "wa_allow_send" in registered
    assert "wa_block_send" in registered
    assert "wa_allow_reply" in registered
    assert "wa_block_reply" in registered


def test_skill_registration_keeps_whatsapp_tool_contract():
    captured = {}

    def _register_skill(name, description, tools, prompt=None):
        captured["name"] = name
        captured["description"] = description
        captured["tools"] = list(tools)
        captured["prompt"] = prompt

    register_whatsapp_skill(_register_skill)

    assert captured["name"] == "WhatsApp"
    assert "send_whatsapp" in captured["tools"]
    assert "read_whatsapp" in captured["tools"]
    assert "reply_whatsapp" in captured["tools"]
    assert "wa_set_autoreply" in captured["tools"]
    assert "NUNCA uses invoke_agent" in captured["prompt"]


def test_wa_link_normalizes_target_before_upsert(monkeypatch, capsys):
    captured = {}

    def _set_rule(source, external_user_id, **kwargs):
        captured["source"] = source
        captured["external_user_id"] = external_user_id
        captured.update(kwargs)

    handle_wa_command(
        'link "+506 1234-5678" "Orchestrator" "Orchestrator"',
        set_access_rule_fn=_set_rule,
        remove_access_rule_fn=lambda *_args, **_kwargs: True,
        wa_is_running_fn=lambda: False,
    )

    assert captured["source"] == "whatsapp"
    assert captured["external_user_id"] == "50612345678"
    assert captured["default_agent_name"] == "Orchestrator"


def test_wa_unlink_normalizes_target_before_delete(monkeypatch, capsys):
    captured = {}

    def _remove_rule(source, external_user_id):
        captured["source"] = source
        captured["external_user_id"] = external_user_id
        return True

    handle_wa_command(
        'unlink "+506 1234-5678"',
        set_access_rule_fn=lambda *_args, **_kwargs: None,
        remove_access_rule_fn=_remove_rule,
        wa_is_running_fn=lambda: False,
    )

    assert captured["source"] == "whatsapp"
    assert captured["external_user_id"] == "50612345678"


def test_wa_sync_invokes_auto_validation_with_defaults(capsys):
    captured = {}

    def _sync_auto(**kwargs):
        captured.update(kwargs)
        return "sync-auto-ok"

    handle_wa_command(
        "sync",
        wa_sync_auto_validate_fn=_sync_auto,
        wa_sync_all_fn=lambda **_kwargs: "sync-all-ok",
        wa_sync_full_fn=lambda **_kwargs: "sync-ok",
        wa_is_running_fn=lambda: True,
        set_access_rule_fn=lambda *_args, **_kwargs: None,
        remove_access_rule_fn=lambda *_args, **_kwargs: True,
    )

    out = capsys.readouterr().out
    assert "sync-auto-ok" in out
    assert captured["max_rounds"] == 12
    assert captured["wait_seconds"] == 8


def test_wa_sync_target_invokes_auto_read_with_defaults(capsys):
    captured = {}

    def _sync_oneshot(**kwargs):
        captured.update(kwargs)
        return "sync-target-ok"

    handle_wa_command(
        "sync Miguel",
        wa_sync_auto_read_archive_fn=_sync_oneshot,
        wa_sync_auto_validate_fn=lambda **_kwargs: "sync-auto-ok",
        wa_sync_all_fn=lambda **_kwargs: "sync-all-ok",
        wa_sync_full_fn=lambda **_kwargs: "sync-ok",
        wa_is_running_fn=lambda: True,
        set_access_rule_fn=lambda *_args, **_kwargs: None,
        remove_access_rule_fn=lambda *_args, **_kwargs: True,
    )

    out = capsys.readouterr().out
    assert "sync-target-ok" in out
    assert captured["target"] == "Miguel"
    assert captured["limit"] == 50
    assert captured["max_rounds"] == 12
    assert captured["wait_seconds"] == 8


def test_wa_sync_target_rejects_invalid_limit(capsys):
    called = {"oneshot": False}

    def _sync_oneshot(**_kwargs):
        called["oneshot"] = True
        return "sync-target-ok"

    handle_wa_command(
        "sync Miguel nope",
        wa_sync_auto_read_archive_fn=_sync_oneshot,
        wa_sync_auto_validate_fn=lambda **_kwargs: "sync-auto-ok",
        wa_sync_all_fn=lambda **_kwargs: "sync-all-ok",
        wa_sync_full_fn=lambda **_kwargs: "sync-ok",
        wa_is_running_fn=lambda: True,
        set_access_rule_fn=lambda *_args, **_kwargs: None,
        remove_access_rule_fn=lambda *_args, **_kwargs: True,
    )

    out = capsys.readouterr().out
    assert "limit debe ser entero" in out
    assert called["oneshot"] is False


def test_wa_sync_all_invokes_multi_sync_function_with_defaults(capsys):
    captured = {}

    def _sync_all(**kwargs):
        captured.update(kwargs)
        return "sync-all-ok"

    handle_wa_command(
        "sync all",
        wa_sync_all_fn=_sync_all,
        wa_sync_full_fn=lambda **_kwargs: "sync-ok",
        wa_is_running_fn=lambda: True,
        set_access_rule_fn=lambda *_args, **_kwargs: None,
        remove_access_rule_fn=lambda *_args, **_kwargs: True,
    )

    out = capsys.readouterr().out
    assert "sync-all-ok" in out
    assert captured["rounds"] == 6
    assert captured["count_per_chat"] == 200
    assert captured["max_chats"] == 100
    assert captured["wait_seconds"] == 8


def test_wa_sync_all_rejects_invalid_rounds(capsys):
    called = {"sync_all": False}

    def _sync_all(**_kwargs):
        called["sync_all"] = True
        return "sync-all-ok"

    handle_wa_command(
        "sync all nope",
        wa_sync_all_fn=_sync_all,
        wa_sync_full_fn=lambda **_kwargs: "sync-ok",
        wa_is_running_fn=lambda: True,
        set_access_rule_fn=lambda *_args, **_kwargs: None,
        remove_access_rule_fn=lambda *_args, **_kwargs: True,
    )

    out = capsys.readouterr().out
    assert "rounds debe ser entero" in out
    assert called["sync_all"] is False


def test_wa_sync_auto_invokes_auto_validation_with_defaults(capsys):
    captured = {}

    def _sync_auto(**kwargs):
        captured.update(kwargs)
        return "sync-auto-ok"

    handle_wa_command(
        "sync auto",
        wa_sync_auto_validate_fn=_sync_auto,
        wa_sync_all_fn=lambda **_kwargs: "sync-all-ok",
        wa_sync_full_fn=lambda **_kwargs: "sync-ok",
        wa_is_running_fn=lambda: True,
        set_access_rule_fn=lambda *_args, **_kwargs: None,
        remove_access_rule_fn=lambda *_args, **_kwargs: True,
    )

    out = capsys.readouterr().out
    assert "sync-auto-ok" in out
    assert captured["max_rounds"] == 12
    assert captured["wait_seconds"] == 8


def test_wa_sync_auto_rejects_invalid_max_rounds(capsys):
    called = {"sync_auto": False}

    def _sync_auto(**_kwargs):
        called["sync_auto"] = True
        return "sync-auto-ok"

    handle_wa_command(
        "sync auto nope",
        wa_sync_auto_validate_fn=_sync_auto,
        wa_sync_all_fn=lambda **_kwargs: "sync-all-ok",
        wa_sync_full_fn=lambda **_kwargs: "sync-ok",
        wa_is_running_fn=lambda: True,
        set_access_rule_fn=lambda *_args, **_kwargs: None,
        remove_access_rule_fn=lambda *_args, **_kwargs: True,
    )

    out = capsys.readouterr().out
    assert "max_rounds debe ser entero" in out
    assert called["sync_auto"] is False


def test_wa_sync_oneshot_invokes_auto_read_with_defaults(capsys):
    captured = {}

    def _sync_oneshot(**kwargs):
        captured.update(kwargs)
        return "sync-oneshot-ok"

    handle_wa_command(
        "sync oneshot Zafiro",
        wa_sync_auto_read_archive_fn=_sync_oneshot,
        wa_sync_auto_validate_fn=lambda **_kwargs: "sync-auto-ok",
        wa_sync_all_fn=lambda **_kwargs: "sync-all-ok",
        wa_sync_full_fn=lambda **_kwargs: "sync-ok",
        wa_is_running_fn=lambda: True,
        set_access_rule_fn=lambda *_args, **_kwargs: None,
        remove_access_rule_fn=lambda *_args, **_kwargs: True,
    )

    out = capsys.readouterr().out
    assert "sync-oneshot-ok" in out
    assert captured["target"] == "Zafiro"
    assert captured["limit"] == 50
    assert captured["max_rounds"] == 12
    assert captured["wait_seconds"] == 8


def test_wa_sync_oneshot_requires_target(capsys):
    called = {"oneshot": False}

    def _sync_oneshot(**_kwargs):
        called["oneshot"] = True
        return "sync-oneshot-ok"

    handle_wa_command(
        "sync oneshot",
        wa_sync_auto_read_archive_fn=_sync_oneshot,
        wa_sync_auto_validate_fn=lambda **_kwargs: "sync-auto-ok",
        wa_sync_all_fn=lambda **_kwargs: "sync-all-ok",
        wa_sync_full_fn=lambda **_kwargs: "sync-ok",
        wa_is_running_fn=lambda: True,
        set_access_rule_fn=lambda *_args, **_kwargs: None,
        remove_access_rule_fn=lambda *_args, **_kwargs: True,
    )

    out = capsys.readouterr().out
    assert "target es requerido" in out
    assert called["oneshot"] is False


def test_wa_sync_oneshot_rejects_invalid_limit(capsys):
    called = {"oneshot": False}

    def _sync_oneshot(**_kwargs):
        called["oneshot"] = True
        return "sync-oneshot-ok"

    handle_wa_command(
        "sync oneshot Zafiro nope",
        wa_sync_auto_read_archive_fn=_sync_oneshot,
        wa_sync_auto_validate_fn=lambda **_kwargs: "sync-auto-ok",
        wa_sync_all_fn=lambda **_kwargs: "sync-all-ok",
        wa_sync_full_fn=lambda **_kwargs: "sync-ok",
        wa_is_running_fn=lambda: True,
        set_access_rule_fn=lambda *_args, **_kwargs: None,
        remove_access_rule_fn=lambda *_args, **_kwargs: True,
    )

    out = capsys.readouterr().out
    assert "limit debe ser entero" in out
    assert called["oneshot"] is False


def test_wa_sync_os_alias_invokes_auto_read_with_defaults(capsys):
    captured = {}

    def _sync_oneshot(**kwargs):
        captured.update(kwargs)
        return "sync-z-ok"

    handle_wa_command(
        "sync os Zafiro",
        wa_sync_auto_read_archive_fn=_sync_oneshot,
        wa_sync_auto_validate_fn=lambda **_kwargs: "sync-auto-ok",
        wa_sync_all_fn=lambda **_kwargs: "sync-all-ok",
        wa_sync_full_fn=lambda **_kwargs: "sync-ok",
        wa_is_running_fn=lambda: True,
        set_access_rule_fn=lambda *_args, **_kwargs: None,
        remove_access_rule_fn=lambda *_args, **_kwargs: True,
    )

    out = capsys.readouterr().out
    assert "sync-z-ok" in out
    assert captured["target"] == "Zafiro"
    assert captured["limit"] == 50
    assert captured["max_rounds"] == 12
    assert captured["wait_seconds"] == 8


def test_wa_sync_os_alias_accepts_overrides(capsys):
    captured = {}

    def _sync_oneshot(**kwargs):
        captured.update(kwargs)
        return "sync-z-ok"

    handle_wa_command(
        "sync os Zafiro 20 9 3",
        wa_sync_auto_read_archive_fn=_sync_oneshot,
        wa_sync_auto_validate_fn=lambda **_kwargs: "sync-auto-ok",
        wa_sync_all_fn=lambda **_kwargs: "sync-all-ok",
        wa_sync_full_fn=lambda **_kwargs: "sync-ok",
        wa_is_running_fn=lambda: True,
        set_access_rule_fn=lambda *_args, **_kwargs: None,
        remove_access_rule_fn=lambda *_args, **_kwargs: True,
    )

    out = capsys.readouterr().out
    assert "sync-z-ok" in out
    assert captured["target"] == "Zafiro"
    assert captured["limit"] == 20
    assert captured["max_rounds"] == 9
    assert captured["wait_seconds"] == 3


def test_wa_sync_os_alias_requires_target(capsys):
    called = {"oneshot": False}

    def _sync_oneshot(**_kwargs):
        called["oneshot"] = True
        return "sync-z-ok"

    handle_wa_command(
        "sync os",
        wa_sync_auto_read_archive_fn=_sync_oneshot,
        wa_sync_auto_validate_fn=lambda **_kwargs: "sync-auto-ok",
        wa_sync_all_fn=lambda **_kwargs: "sync-all-ok",
        wa_sync_full_fn=lambda **_kwargs: "sync-ok",
        wa_is_running_fn=lambda: True,
        set_access_rule_fn=lambda *_args, **_kwargs: None,
        remove_access_rule_fn=lambda *_args, **_kwargs: True,
    )

    out = capsys.readouterr().out
    assert "target es requerido" in out
    assert called["oneshot"] is False
