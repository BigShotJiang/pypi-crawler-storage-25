from __future__ import annotations

from zafiro_skill_whatsapp.extensions.tools.whatsapp_tools import register_whatsapp_tools


def _build_registry() -> dict[str, callable]:
    registry: dict[str, callable] = {}

    def _register(name: str, _description: str, fn):
        registry[name] = fn

    register_whatsapp_tools(_register)
    return registry


def test_registry_includes_restored_and_new_tools() -> None:
    registry = _build_registry()

    assert "get_group_recent_messages" in registry
    assert "wa_sync_auto" in registry
    assert "list_whatsapp_tools" in registry


def test_list_whatsapp_tools_returns_inventory() -> None:
    registry = _build_registry()

    result = registry["list_whatsapp_tools"]("")
    assert "WhatsApp tools disponibles:" in result
    assert "- get_group_recent_messages" in result
    assert "- wa_sync_auto" in result
    assert "- list_whatsapp_tools" in result


def test_wa_sync_auto_calls_admin_with_defaults(monkeypatch) -> None:
    registry = _build_registry()
    captured: dict[str, object] = {}

    def _fake_sync_auto_validate(*, max_rounds: int, wait_seconds: int, force_remote: bool, **_kwargs) -> str:
        captured["max_rounds"] = max_rounds
        captured["wait_seconds"] = wait_seconds
        captured["force_remote"] = force_remote
        return "sync-ok"

    monkeypatch.setattr(
        "zafiro_skill_whatsapp.admin.wa_sync_auto_validate",
        _fake_sync_auto_validate,
    )

    result = registry["wa_sync_auto"]("")

    assert result == "sync-ok"
    assert captured == {
        "max_rounds": 12,
        "wait_seconds": 8,
        "force_remote": False,
    }


def test_wa_sync_auto_parses_numeric_and_bool_args(monkeypatch) -> None:
    registry = _build_registry()
    captured: dict[str, object] = {}

    def _fake_sync_auto_validate(*, max_rounds: int, wait_seconds: int, force_remote: bool, **_kwargs) -> str:
        captured["max_rounds"] = max_rounds
        captured["wait_seconds"] = wait_seconds
        captured["force_remote"] = force_remote
        return "sync-ok"

    monkeypatch.setattr(
        "zafiro_skill_whatsapp.admin.wa_sync_auto_validate",
        _fake_sync_auto_validate,
    )

    result = registry["wa_sync_auto"]("6|4|true")

    assert result == "sync-ok"
    assert captured == {
        "max_rounds": 6,
        "wait_seconds": 4,
        "force_remote": True,
    }


def test_wa_sync_auto_rejects_invalid_args() -> None:
    registry = _build_registry()

    invalid_rounds = registry["wa_sync_auto"]("abc|4")
    invalid_wait = registry["wa_sync_auto"]("6|abc")
    invalid_force = registry["wa_sync_auto"]("6|4|maybe")

    assert "max_rounds must be" in invalid_rounds
    assert "wait_seconds must be" in invalid_wait
    assert "force_remote must be" in invalid_force
