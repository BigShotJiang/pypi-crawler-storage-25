"""Integration smoke tests for the package-local wa.sh launcher.

These tests run the real shell wrapper and tool registry end-to-end.
By default they avoid destructive/live actions. Optional live checks can be
enabled with env flags documented below.
"""

from __future__ import annotations

import os
from pathlib import Path
import subprocess
import sys
import uuid

import pytest

from zafiro_skill_whatsapp import integrations
from zafiro_skill_whatsapp.adapters.whatsapp import state as whatsapp_state


ROOT_DIR = Path(__file__).resolve().parents[1]
WA_SH = ROOT_DIR / "scripts" / "wa.sh"
ALLOWED_TEST_NUMBER = "50577427779"
TEST_GROUP_NAME = "Zafiro"
TEST_GROUP_JID = "120363000000000999@g.us"


def _run_wa_sh(*args: str, timeout: int = 40) -> subprocess.CompletedProcess[str]:
    env = os.environ.copy()
    # Force wa.sh to use the same project-local interpreter/venv as pytest.
    env["PYTHON_BIN"] = sys.executable
    return subprocess.run(
        [str(WA_SH), *args],
        cwd=str(ROOT_DIR),
        env=env,
        capture_output=True,
        text=True,
        timeout=timeout,
    )


def _assert_clean_process(result: subprocess.CompletedProcess[str]) -> None:
    assert result.returncode == 0, (
        f"wa.sh exited with {result.returncode}\n"
        f"STDOUT:\n{result.stdout}\nSTDERR:\n{result.stderr}"
    )
    assert "Traceback" not in result.stdout
    assert "Traceback" not in result.stderr


def _seed_archived_message(
    *,
    message_id: str,
    raw_text: str,
    from_number: str,
    chat_jid: str,
    sender_jid: str,
) -> None:
    integrations.archive_whatsapp_payload(
        {
            "direction": "inbound",
            "delivery_status": "received",
            "from_": from_number,
            "peer_number": from_number,
            "jid": sender_jid,
            "type": "text",
            "received_at": "2026-04-25T12:00:00+00:00",
            "raw_text": raw_text,
            "audio_transcription": None,
            "image_analysis": None,
            "media_path": None,
            "mime_type": None,
            "source_channel": "whatsapp",
            "message_id": message_id,
            "reply_to_message_id": None,
            "chat_jid": chat_jid,
            "sender_jid": sender_jid,
            "session_id": f"whatsapp:{ALLOWED_TEST_NUMBER}",
        }
    )


@pytest.fixture(autouse=True)
def _isolate_test_storage(monkeypatch, tmp_path: Path):
    db_path = tmp_path / "whatsapp_skill_tests.sqlite3"
    account_path = tmp_path / "whatsapp_active_account.txt"
    outbox_dir = tmp_path / "whatsapp_outbox"

    monkeypatch.setenv("WHATSAPP_LOCAL_DB_PATH", str(db_path))
    monkeypatch.setenv("WHATSAPP_ACTIVE_ACCOUNT_PATH", str(account_path))
    monkeypatch.setenv("WHATSAPP_OUTBOX_DIR", str(outbox_dir))

    monkeypatch.setattr(integrations, "WHATSAPP_LOCAL_DB_PATH", str(db_path))
    monkeypatch.setattr(whatsapp_state, "WHATSAPP_ACTIVE_ACCOUNT_PATH", str(account_path))
    whatsapp_state.runtime.active_account_key = ""
    whatsapp_state.runtime.client = None

    account_path.write_text("", encoding="utf-8")
    integrations.reset_storage_for_tests(account_key="unknown")
    yield
    integrations.reset_storage_for_tests(account_key="unknown")


def test_wa_sh_lists_registered_tools() -> None:
    result = _run_wa_sh("tools")
    _assert_clean_process(result)

    expected_tools = {
        "send_whatsapp",
        "save_whatsapp_contact",
        "save_whatsapp_contacts",
        "list_whatsapp_contacts",
        "save_whatsapp_group",
        "save_whatsapp_groups",
        "list_whatsapp_groups",
        "reply_whatsapp",
        "read_whatsapp",
        "read_whatsapp_archive",
        "get_group_recent_messages",
        "whatsapp_status",
        "whatsapp_recover",
        "wa_sync_auto",
        "list_whatsapp_tools",
        "wa_policy",
        "wa_set_autoreply",
        "wa_allow_send",
        "wa_block_send",
        "wa_allow_reply",
        "wa_block_reply",
    }

    for tool_name in expected_tools:
        assert tool_name in result.stdout


def test_wa_sh_contacts_groups_and_archive_reads_number_and_group() -> None:
    save_contact = _run_wa_sh(
        "tool",
        "save_whatsapp_contact",
        f"Smoke QA|{ALLOWED_TEST_NUMBER}|true|integration-test",
    )
    _assert_clean_process(save_contact)
    assert "WhatsApp contact saved" in save_contact.stdout

    list_contacts = _run_wa_sh("tool", "list_whatsapp_contacts")
    _assert_clean_process(list_contacts)
    assert ALLOWED_TEST_NUMBER in list_contacts.stdout
    assert "Smoke QA" in list_contacts.stdout

    save_group = _run_wa_sh(
        "tool",
        "save_whatsapp_group",
        f"{TEST_GROUP_NAME}|{TEST_GROUP_JID}|true|integration-group",
    )
    _assert_clean_process(save_group)
    assert "WhatsApp group saved" in save_group.stdout

    list_groups = _run_wa_sh("tool", "list_whatsapp_groups")
    _assert_clean_process(list_groups)
    assert TEST_GROUP_NAME in list_groups.stdout
    assert TEST_GROUP_JID in list_groups.stdout

    number_message_id = f"wa-sh-number-{uuid.uuid4().hex[:8]}"
    group_message_id = f"wa-sh-group-{uuid.uuid4().hex[:8]}"

    _seed_archived_message(
        message_id=number_message_id,
        raw_text="mensaje de prueba numero",
        from_number=ALLOWED_TEST_NUMBER,
        chat_jid=f"{ALLOWED_TEST_NUMBER}@s.whatsapp.net",
        sender_jid=f"{ALLOWED_TEST_NUMBER}@s.whatsapp.net",
    )
    _seed_archived_message(
        message_id=group_message_id,
        raw_text="mensaje de prueba grupo zafiro",
        from_number=ALLOWED_TEST_NUMBER,
        chat_jid=TEST_GROUP_JID,
        sender_jid=f"{ALLOWED_TEST_NUMBER}@s.whatsapp.net",
    )

    read_archive_number = _run_wa_sh("tool", "read_whatsapp_archive", f"{ALLOWED_TEST_NUMBER}|20")
    _assert_clean_process(read_archive_number)
    assert number_message_id in read_archive_number.stdout
    assert ALLOWED_TEST_NUMBER in read_archive_number.stdout

    read_archive_group = _run_wa_sh("tool", "read_whatsapp_archive", f"{TEST_GROUP_NAME}|20")
    _assert_clean_process(read_archive_group)
    assert group_message_id in read_archive_group.stdout
    assert "mensaje de prueba grupo zafiro" in read_archive_group.stdout


def test_wa_sh_read_whatsapp_number_and_group_in_external_mode() -> None:
    _run_wa_sh(
        "tool",
        "save_whatsapp_contact",
        f"Smoke QA|{ALLOWED_TEST_NUMBER}|true|integration-read",
    )
    _run_wa_sh(
        "tool",
        "save_whatsapp_group",
        f"{TEST_GROUP_NAME}|{TEST_GROUP_JID}|true|integration-read",
    )

    number_message_id = f"wa-sh-live-number-{uuid.uuid4().hex[:8]}"
    group_message_id = f"wa-sh-live-group-{uuid.uuid4().hex[:8]}"

    _seed_archived_message(
        message_id=number_message_id,
        raw_text="mensaje nuevo numero",
        from_number=ALLOWED_TEST_NUMBER,
        chat_jid=f"{ALLOWED_TEST_NUMBER}@s.whatsapp.net",
        sender_jid=f"{ALLOWED_TEST_NUMBER}@s.whatsapp.net",
    )
    _seed_archived_message(
        message_id=group_message_id,
        raw_text="mensaje nuevo grupo",
        from_number=ALLOWED_TEST_NUMBER,
        chat_jid=TEST_GROUP_JID,
        sender_jid=f"{ALLOWED_TEST_NUMBER}@s.whatsapp.net",
    )

    pid_file = ROOT_DIR / "logs" / "whatsapp.pid"
    pid_file.parent.mkdir(parents=True, exist_ok=True)
    original_pid = pid_file.read_text(encoding="utf-8") if pid_file.exists() else None
    pid_file.write_text(str(os.getpid()), encoding="utf-8")

    try:
        read_number = _run_wa_sh("tool", "read_whatsapp", f"{ALLOWED_TEST_NUMBER}|20")
        _assert_clean_process(read_number)
        assert number_message_id in read_number.stdout
        assert ALLOWED_TEST_NUMBER in read_number.stdout

        read_group = _run_wa_sh("tool", "read_whatsapp", f"{TEST_GROUP_NAME}|20")
        _assert_clean_process(read_group)
        assert group_message_id in read_group.stdout
        assert "group=Zafiro" in read_group.stdout
    finally:
        if original_pid is None:
            pid_file.unlink(missing_ok=True)
        else:
            pid_file.write_text(original_pid, encoding="utf-8")


@pytest.mark.parametrize(
    ("tool_name", "args"),
    [
        ("save_whatsapp_contacts", f"Smoke Batch|{ALLOWED_TEST_NUMBER}|batch-note"),
        ("list_whatsapp_contacts", ""),
        ("save_whatsapp_group", "Smoke Group|120363000000000000@g.us|true|integration-test"),
        ("save_whatsapp_groups", "Smoke Group 2|120363000000000001@g.us|integration-batch"),
        ("list_whatsapp_groups", ""),
        ("reply_whatsapp", "missing-message-id|respuesta de prueba"),
        ("read_whatsapp", f"{ALLOWED_TEST_NUMBER}|5"),
        ("read_whatsapp_archive", f"{ALLOWED_TEST_NUMBER}|5"),
        ("whatsapp_status", ""),
        ("wa_policy", ""),
        ("wa_set_autoreply", "on"),
        ("wa_allow_send", ALLOWED_TEST_NUMBER),
        ("wa_block_send", ALLOWED_TEST_NUMBER),
        ("wa_allow_reply", ALLOWED_TEST_NUMBER),
        ("wa_block_reply", ALLOWED_TEST_NUMBER),
    ],
)
def test_wa_sh_tool_smoke_non_destructive(tool_name: str, args: str) -> None:
    result = _run_wa_sh("tool", tool_name, args)
    _assert_clean_process(result)


def test_wa_sh_send_whatsapp_allowed_number_safe_default() -> None:
    """Default mode avoids real sends unless explicitly enabled.

    Set WA_SH_ALLOW_SEND=1 to exercise live send path (to allowed number only).
    """
    if os.getenv("WA_SH_ALLOW_SEND") == "1":
        args = f"{ALLOWED_TEST_NUMBER}|[wa.sh integration test] mensaje permitido"
        result = _run_wa_sh("tool", "send_whatsapp", args)
        _assert_clean_process(result)
        # Connected and sent, queued for external process, or not active are all acceptable
        # for this environment-agnostic smoke test.
        assert any(
            token in result.stdout
            for token in (
                f"Mensaje enviado a {ALLOWED_TEST_NUMBER}",
                f"to {ALLOWED_TEST_NUMBER}. command_id=",
                "WhatsApp channel is not active",
            )
        )
        return

    # Safe-mode execution still verifies command routing without external side effects.
    result = _run_wa_sh("tool", "send_whatsapp", "invalid-format")
    _assert_clean_process(result)
    assert "Format: send_whatsapp(number_or_alias|message)" in result.stdout


def test_wa_sh_whatsapp_recover_optional() -> None:
    """Recovery can restart/alter runtime; run only when explicitly requested."""
    if os.getenv("WA_SH_RUN_RECOVER") != "1":
        pytest.skip("Set WA_SH_RUN_RECOVER=1 to run whatsapp_recover integration test")

    result = _run_wa_sh("tool", "whatsapp_recover", "", timeout=90)
    _assert_clean_process(result)
