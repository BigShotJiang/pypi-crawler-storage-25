from zafiro_skill_whatsapp.adapters.whatsapp.sync_ops import orchestrator


def test_sync_auto_validate_skips_remote_requests_when_coverage_is_already_complete(monkeypatch):
    monkeypatch.setattr(orchestrator, "_resolve_client_or_error", lambda: (object(), None))
    monkeypatch.setattr(
        orchestrator,
        "_history_validation_snapshot",
        lambda: {
            "total_archived": 2034,
            "known_groups": 2,
            "groups_with_archive": 2,
            "groups_without_archive": [],
            "group_name_by_jid": {
                "120363000000000111@g.us": "Zafiro",
                "120363000000000222@g.us": "Operaciones",
            },
        },
    )

    def _unexpected_round(*_args, **_kwargs):
        raise AssertionError("_run_single_sync_round should not be called when coverage is already complete")

    monkeypatch.setattr(orchestrator, "_run_single_sync_round", _unexpected_round)

    result = orchestrator.sync_all_whatsapp_data_auto_validate(max_rounds=12, wait_seconds=8)

    assert "corte automático inicial" in result
    assert "rondas ejecutadas: 0" in result
    assert "requested=0 errors=0 usync_timeouts=0" in result
    assert "validación automática: completa" in result


def test_sync_auto_validate_force_remote_bypasses_initial_short_circuit(monkeypatch):
    monkeypatch.setattr(orchestrator, "_resolve_client_or_error", lambda: (object(), None))
    monkeypatch.setattr(
        orchestrator,
        "_history_validation_snapshot",
        lambda: {
            "total_archived": 2034,
            "known_groups": 2,
            "groups_with_archive": 2,
            "groups_without_archive": [],
            "group_name_by_jid": {
                "120363000000000111@g.us": "Zafiro",
                "120363000000000222@g.us": "Operaciones",
            },
        },
    )

    def _fake_round(*_args, **_kwargs):
        return {
            "groups_synced": 2,
            "contacts_synced": 10,
            "history_request": {
                "requested": 1,
                "errors": 0,
                "usync_timeouts": 0,
                "preferred_requested": 1,
                "preferred_candidates": 1,
                "preferred_errors": 0,
                "group_fallback_requested": 0,
                "group_fallback_candidates": 0,
                "abort_reason": "",
            },
            "stats": {
                "events": 0,
                "messages_seen": 0,
                "messages_archived": 0,
            },
            "warnings": [],
        }

    monkeypatch.setattr(orchestrator, "_run_single_sync_round", _fake_round)

    result = orchestrator.sync_all_whatsapp_data_auto_validate(
        max_rounds=1,
        wait_seconds=0,
        force_remote=True,
        preferred_chat_jids=["50577116731@s.whatsapp.net"],
    )

    assert "corte automático inicial" not in result
    assert "- ronda 1:" in result
    assert "preferred=1/1" in result
