from pathlib import Path
from types import SimpleNamespace
import os

import pytest

from zafiro_skill_whatsapp.adapters import whatsapp as whatsapp_adapter
from zafiro_skill_whatsapp import admin as whatsapp_admin
from zafiro_skill_whatsapp import integrations
from zafiro_skill_whatsapp.adapters.whatsapp import auto_reply as whatsapp_auto_reply
from zafiro_skill_whatsapp.adapters.whatsapp import contacts as whatsapp_contacts
from zafiro_skill_whatsapp.adapters.whatsapp import connection as whatsapp_connection
from zafiro_skill_whatsapp.adapters.whatsapp import outbound as whatsapp_outbound
from zafiro_skill_whatsapp.adapters.whatsapp import processing as whatsapp_processing
from zafiro_skill_whatsapp.adapters.whatsapp import queue as whatsapp_queue
from zafiro_skill_whatsapp.adapters.whatsapp import state as whatsapp_state
from zafiro_skill_whatsapp.adapters.whatsapp.state import contact_session_id, runtime


@pytest.fixture(autouse=True)
def _isolate_active_account_path(monkeypatch, tmp_path: Path):
    path = tmp_path / "active-account.txt"
    monkeypatch.setattr(whatsapp_state, "WHATSAPP_ACTIVE_ACCOUNT_PATH", str(path))
    path.write_text("", encoding="utf-8")
    yield


class _FakeClient:
    def __init__(self):
        self.calls = []
        self.me = SimpleNamespace(JID=SimpleNamespace(User="50599990000", Server="s.whatsapp.net"))

    def send_presence(self, presence):
        self.calls.append(("presence", presence))

    def send_chat_presence(self, jid, state, media):
        self.calls.append(("chat_presence", jid.User, state, media))

    def send_message(self, jid, text):
        self.calls.append(("send_message", jid.User, text))
        return SimpleNamespace(ID=f"sent-{jid.User}")

    def mark_read(self, *message_ids, chat, sender, receipt, timestamp=None):
        self.calls.append(("mark_read", message_ids, chat.User, sender.User, receipt, timestamp))

    def reply_message(self, text, quoted):
        self.calls.append(("reply_message", text, quoted.Info.ID))
        return SimpleNamespace(ID=f"reply-{quoted.Info.ID}")

    def get_me(self):
        return self.me


def _build_payload(
    *,
    message_id: str,
    text: str,
    sender: str = "50612345678",
    chat_jid: str = "50612345678@s.whatsapp.net",
) -> dict:
    return {
        "direction": "inbound",
        "delivery_status": "received",
        "from_": sender,
        "peer_number": sender,
        "jid": f"{sender}@s.whatsapp.net",
        "type": "text",
        "received_at": "2026-04-18T12:00:00+00:00",
        "raw_text": text,
        "audio_transcription": None,
        "image_analysis": None,
        "media_path": None,
        "mime_type": None,
        "source_channel": "whatsapp",
        "message_id": message_id,
        "reply_to_message_id": None,
        "chat_jid": chat_jid,
        "sender_jid": f"{sender}@s.whatsapp.net",
        "session_id": f"whatsapp:{sender}",
    }


def _build_incoming_message(message_id: str, sender: str = "50612345678"):
    return SimpleNamespace(
        ID=message_id,
        Timestamp=1710000000,
        MessageSource=SimpleNamespace(
            Chat=SimpleNamespace(User=sender, Server="s.whatsapp.net"),
            Sender=SimpleNamespace(User=sender, Server="s.whatsapp.net"),
        ),
    )


def setup_function():
    runtime.message_buffer.clear()
    runtime.message_cache.clear()
    runtime.connected.clear()
    runtime.active_account_key = ""
    integrations.reset_storage_for_tests(account_key="unknown")
    integrations.reset_storage_for_tests(account_key="50599990000")
    integrations.reset_storage_for_tests(account_key="50611112222")
    integrations.reset_storage_for_tests(account_key="50633334444")


def test_active_account_key_persists_for_external_processes(monkeypatch, tmp_path: Path):
    path = tmp_path / "active-account.txt"
    monkeypatch.setattr(whatsapp_state, "WHATSAPP_ACTIVE_ACCOUNT_PATH", str(path))

    runtime.active_account_key = ""
    runtime.client = None

    persisted = whatsapp_state.set_active_account_key("+505 8248-0271")
    assert persisted == "50582480271"

    runtime.active_account_key = ""
    assert whatsapp_state.get_active_account_key() == "50582480271"


def test_build_device_props_enables_history_sync_capabilities():
    props = whatsapp_connection.build_device_props()

    assert bool(getattr(props, "requireFullSync", False)) is False
    history_cfg = getattr(props, "historySyncConfig", None)
    assert history_cfg is not None
    assert bool(getattr(history_cfg, "supportHostedGroupMsg", True)) is True
    assert bool(getattr(history_cfg, "supportMessageAssociation", True)) is True

    # Present only in richer companion proto; if available, keep them enabled.
    if hasattr(history_cfg, "supportGroupHistory"):
        assert bool(getattr(history_cfg, "supportGroupHistory")) is True
    if hasattr(history_cfg, "onDemandReady"):
        assert bool(getattr(history_cfg, "onDemandReady")) is True
    if hasattr(history_cfg, "completeOnDemandReady"):
        assert bool(getattr(history_cfg, "completeOnDemandReady")) is True


def test_append_recent_message_archives_and_autoreplies(monkeypatch):
    called = {}

    monkeypatch.setattr(
        whatsapp_processing,
        "archive_whatsapp_payload",
        lambda payload: called.setdefault("archived", payload["message_id"]),
    )
    monkeypatch.setattr(
        whatsapp_processing,
        "maybe_auto_reply",
        lambda payload: called.setdefault("auto_reply", payload["message_id"]),
    )
    monkeypatch.setattr(whatsapp_processing, "remember_contact", lambda *args, **kwargs: None)
    monkeypatch.setattr(whatsapp_processing, "remember_group", lambda *args, **kwargs: None)
    monkeypatch.setattr(
        "zafiro_skill_whatsapp.adapters.whatsapp.outbound.mark_message_as_read",
        lambda message_id, *_args, **_kwargs: called.setdefault("read", message_id),
    )

    payload = _build_payload(message_id="msg-2", text="hola")
    whatsapp_processing.append_recent_message(payload, _build_incoming_message("msg-2"))

    assert called["archived"] == "msg-2"
    assert called["auto_reply"] == "msg-2"
    assert called["read"] == "msg-2"
    assert not hasattr(whatsapp_processing, "ingest_whatsapp_worker_report")


def test_get_recent_messages_restores_from_key():
    runtime.message_buffer.append(_build_payload(message_id="msg-1", text="hola"))

    messages = whatsapp_processing.get_recent_messages()

    assert messages[0]["from"] == "50612345678"
    assert messages[0]["message_id"] == "msg-1"
    assert messages[0]["session_id"] == "whatsapp:50612345678"
    assert "from_" not in messages[0]


def test_contact_session_id_is_stable():
    assert contact_session_id("+506 1234-5678") == "whatsapp:50612345678"


def test_resolve_auto_reply_agent_allows_linked_sender(monkeypatch):
    agent = {
        "id": 8,
        "name": "Orchestrator",
        "allowed_skills": ["Utilities", "Memory", "AgentDelegation"],
    }

    monkeypatch.setattr(
        whatsapp_auto_reply,
        "get_user_agent_access",
        lambda source, user: {
            "default_agent_name": "Orchestrator",
            "allowed_agent_names": ["Orchestrator"],
            "access_level": "limited",
        },
    )
    monkeypatch.setattr(whatsapp_auto_reply, "resolve_effective_agent", lambda selected, *_args: selected)

    resolved, meta = whatsapp_auto_reply.resolve_auto_reply_agent({"from_": "+506 1234-5678"}, [agent])

    assert resolved is not None
    assert resolved["name"] == "Orchestrator"
    assert meta["reason"] == "explicit-access"
    assert meta["target"] == "50612345678"


def test_resolve_auto_reply_agent_blocks_agent_without_skills(monkeypatch):
    agent = {
        "id": 2,
        "name": "Limited",
        "allowed_skills": ["Utilities"],
    }

    monkeypatch.setattr(
        whatsapp_auto_reply,
        "get_user_agent_access",
        lambda source, user: {
            "default_agent_name": "Limited",
            "allowed_agent_names": ["Limited"],
            "access_level": "limited",
        },
    )

    resolved, meta = whatsapp_auto_reply.resolve_auto_reply_agent({"from_": "50612345678"}, [agent])

    assert resolved is None
    assert meta["reason"] == "agent-lacks-whatsapp-or-delegation-skill"


def test_maybe_auto_reply_returns_none_for_empty_query():
    result = whatsapp_auto_reply.maybe_auto_reply({"from_": "50612345678", "raw_text": "   "})

    assert result is None


def test_maybe_auto_reply_respects_env_gate(monkeypatch):
    monkeypatch.setattr(whatsapp_auto_reply, "WHATSAPP_AUTO_REPLY_ENABLED", False)

    result = whatsapp_auto_reply.maybe_auto_reply({"from_": "50612345678", "raw_text": "hola"})

    assert result == {"reason": "auto-reply-disabled"}


def test_maybe_auto_reply_returns_no_host_agents(monkeypatch):
    monkeypatch.setattr(whatsapp_auto_reply, "get_active_agents", lambda: [])

    result = whatsapp_auto_reply.maybe_auto_reply(
        {
            "from_": "50612345678",
            "raw_text": "hola",
            "message_id": "msg-9",
            "chat_jid": "50612345678@s.whatsapp.net",
            "session_id": "whatsapp:50612345678",
        }
    )

    assert result == {"reason": "no-host-agents"}


def test_maybe_auto_reply_sends_response(monkeypatch):
    agent = {
        "id": 10,
        "name": "Responder",
        "allowed_skills": ["WhatsAppReply"],
    }
    captured = {}

    monkeypatch.setattr(whatsapp_auto_reply, "get_active_agents", lambda: [agent])
    monkeypatch.setattr(
        whatsapp_auto_reply,
        "get_user_agent_access",
        lambda source, user: {
            "default_agent_name": "Responder",
            "allowed_agent_names": ["Responder"],
            "access_level": "limited",
        },
    )
    monkeypatch.setattr(whatsapp_auto_reply, "resolve_effective_agent", lambda selected, *_args: selected)
    monkeypatch.setattr(whatsapp_auto_reply, "load_session_history", lambda session_id, limit: [])

    def _execute_task(**kwargs):
        captured["agent_name"] = kwargs["agent"]["name"]
        captured["query"] = kwargs["query"]
        return "Claro, te ayudo.", kwargs["agent"]["name"]

    monkeypatch.setattr(whatsapp_auto_reply, "execute_task", _execute_task)
    monkeypatch.setattr(
        whatsapp_adapter,
        "start_composing",
        lambda chat_jid: captured.setdefault("typing", chat_jid),
        raising=False,
    )
    monkeypatch.setattr(
        whatsapp_adapter,
        "reply_to_message",
        lambda message_id, text, already_composing=False: f"reply:{message_id}:{text}:{already_composing}",
        raising=False,
    )

    result = whatsapp_auto_reply.maybe_auto_reply(
        {
            "from_": "50612345678",
            "raw_text": "que tareas tengo hoy",
            "message_id": "msg-10",
            "chat_jid": "50612345678@s.whatsapp.net",
            "session_id": "whatsapp:50612345678",
        }
    )

    assert captured["agent_name"] == "Responder"
    assert captured["query"] == "que tareas tengo hoy"
    assert result is not None
    assert result["reason"] == "sent"
    assert result["send_result"] == "reply:msg-10:Claro, te ayudo.:True"


def test_send_message_archives_outbound_payload(monkeypatch):
    fake_client = _FakeClient()
    archived = []
    runtime.connected.set()

    monkeypatch.setattr(whatsapp_outbound, "get_client", lambda: fake_client)
    monkeypatch.setattr(whatsapp_outbound, "_typing_delay_seconds", lambda _text: 0.0)
    monkeypatch.setattr(whatsapp_outbound, "archive_whatsapp_payload", lambda payload: archived.append(payload))
    monkeypatch.setattr(whatsapp_outbound, "remember_contact", lambda *args, **kwargs: None)
    monkeypatch.setattr(whatsapp_outbound, "remember_group", lambda *args, **kwargs: None)
    monkeypatch.setattr(whatsapp_outbound, "WHATSAPP_SIMULATE_TYPING", True)
    monkeypatch.setattr(whatsapp_outbound, "WHATSAPP_SEND_AVAILABLE_PRESENCE", True)
    monkeypatch.setattr("zafiro_skill_whatsapp.adapters.whatsapp.contacts.is_send_allowed", lambda _target: True)

    result = whatsapp_outbound.send_message("+506 1234-5678", "Hola")

    assert result == "Mensaje enviado a 50612345678."
    assert ("send_message", "50612345678", "Hola") in fake_client.calls
    assert archived[0]["direction"] == "outbound"
    assert archived[0]["peer_number"] == "50612345678"
    assert archived[0]["message_id"] == "sent-50612345678"


def test_reply_to_message_marks_read_and_archives(monkeypatch):
    fake_client = _FakeClient()
    archived = []
    runtime.connected.set()

    quoted = SimpleNamespace(
        Info=SimpleNamespace(
            ID="msg-42",
            Timestamp=1710000000,
            MessageSource=SimpleNamespace(
                Chat=SimpleNamespace(User="50612345678", Server="s.whatsapp.net"),
                Sender=SimpleNamespace(User="50612345678", Server="s.whatsapp.net"),
            ),
        )
    )

    monkeypatch.setattr(whatsapp_outbound, "get_client", lambda: fake_client)
    monkeypatch.setattr(whatsapp_outbound, "get_incoming_message", lambda _message_id: quoted)
    monkeypatch.setattr(whatsapp_outbound, "_typing_delay_seconds", lambda _text: 0.0)
    monkeypatch.setattr(whatsapp_outbound, "archive_whatsapp_payload", lambda payload: archived.append(payload))
    monkeypatch.setattr(whatsapp_outbound, "remember_contact", lambda *args, **kwargs: None)
    monkeypatch.setattr(whatsapp_outbound, "remember_group", lambda *args, **kwargs: None)

    result = whatsapp_outbound.reply_to_message("msg-42", "Te respondo aqui")

    assert result == "Respuesta enviada al mensaje msg-42."
    assert fake_client.calls[0][0] == "mark_read"
    assert any(call[0] == "reply_message" for call in fake_client.calls)
    assert archived[0]["reply_to_message_id"] == "msg-42"
    assert archived[0]["message_id"] == "reply-msg-42"


def test_queue_processes_reply_command(monkeypatch, tmp_path: Path):
    monkeypatch.setattr(whatsapp_queue, "WHATSAPP_OUTBOX_DIR", str(tmp_path))

    command_id = whatsapp_queue.enqueue_reply_message("msg-42", "Claro", metadata={"source": "test"})
    results = whatsapp_queue.process_pending_messages(
        lambda number, text: f"Mensaje enviado a {number}.",
        lambda message_id, text: f"Respuesta enviada al mensaje {message_id}.",
        limit=10,
    )

    assert results == [
        {
            "file": f"{command_id}.json",
            "status": "processed",
            "result": "Respuesta enviada al mensaje msg-42.",
        }
    ]


def test_contacts_upsert_and_resolve(monkeypatch, tmp_path: Path):
    monkeypatch.setattr(whatsapp_contacts, "WHATSAPP_CONTACTS_PATH", str(tmp_path / "contacts.json"))

    whatsapp_contacts.upsert_contact("Gerald", "+505 77427779")
    whatsapp_contacts.upsert_contact("Gerald", "50588889999", replace=True)
    whatsapp_contacts.upsert_group("Reservas", "120363000000000000@g.us")

    by_name = whatsapp_contacts.resolve_contact("gerald")
    by_phone = whatsapp_contacts.resolve_contact("+505 8888-9999")
    by_group = whatsapp_contacts.resolve_group("reservas")

    assert by_name is not None
    assert by_name["phone"] == "50588889999"
    assert by_phone is not None
    assert by_group is not None
    assert by_group["jid"] == "120363000000000000@g.us"


def test_load_session_history_scopes_by_phone(monkeypatch, tmp_path: Path):
    integrations.reset_storage_for_tests(account_key="unknown")

    integrations.archive_whatsapp_payload(
        {
            "direction": "inbound",
            "raw_text": "hola-a",
            "audio_transcription": None,
            "image_analysis": None,
            "from_": "50611112222",
            "session_id": "whatsapp:50611112222",
        }
    )
    integrations.archive_whatsapp_payload(
        {
            "direction": "inbound",
            "raw_text": "hola-b",
            "audio_transcription": None,
            "image_analysis": None,
            "from_": "50633334444",
            "session_id": "whatsapp:50633334444",
        }
    )

    history = integrations.load_session_history("+506 1111-2222", limit=10)

    assert history == [{"role": "user", "content": "hola-a"}]


def test_wa_is_running_does_not_false_positive_with_own_pid(monkeypatch, tmp_path: Path):
    pidfile = tmp_path / "whatsapp.pid"
    pidfile.write_text(str(os.getpid()), encoding="utf-8")
    runtime.connected.clear()
    runtime.client = None

    monkeypatch.setattr(whatsapp_admin, "_WA_PIDFILE", pidfile)

    assert whatsapp_admin.wa_is_running() is False
