"""Regression tests for WhatsApp read filters and archive matching."""

from zafiro_skill_whatsapp import integrations
from zafiro_skill_whatsapp.adapters import whatsapp as whatsapp_adapter
from zafiro_skill_whatsapp.extensions.tools import whatsapp_tools


def setup_function():
    integrations.reset_storage_for_tests(account_key="unknown")


def test_read_whatsapp_resolves_contact_alias_in_external_mode(monkeypatch):
    monkeypatch.setattr(whatsapp_adapter, "is_connected", lambda: False)
    monkeypatch.setattr(whatsapp_adapter, "is_external_process_running", lambda: True)
    monkeypatch.setattr(whatsapp_adapter, "list_groups", lambda: [])
    monkeypatch.setattr(whatsapp_adapter, "normalize_group_jid", lambda value: value)
    monkeypatch.setattr(whatsapp_adapter, "resolve_group", lambda _value: None)
    monkeypatch.setattr(
        whatsapp_adapter,
        "resolve_contact",
        lambda value: {"name": "Juan", "phone": "+506 1234-5678"} if value == "Juan" else None,
    )

    captured = {}

    def _fake_read_archived_messages(**kwargs):
        captured.update(kwargs)
        return [
            {
                "received_at": "2026-04-22T23:45:00Z",
                "from_": "50612345678",
                "message_id": "abc-1",
                "type": "text",
                "raw_text": "hola desde archivo",
            }
        ]

    monkeypatch.setattr(integrations, "read_archived_messages", _fake_read_archived_messages)

    result = whatsapp_tools._read_whatsapp("Juan|25")

    assert captured["from_number"] == "50612345678"
    assert captured["limit"] == 25
    assert "hola desde archivo" in result


def test_read_whatsapp_normalizes_direct_number_in_external_mode(monkeypatch):
    monkeypatch.setattr(whatsapp_adapter, "is_connected", lambda: False)
    monkeypatch.setattr(whatsapp_adapter, "is_external_process_running", lambda: True)
    monkeypatch.setattr(whatsapp_adapter, "list_groups", lambda: [])
    monkeypatch.setattr(whatsapp_adapter, "normalize_group_jid", lambda value: value)
    monkeypatch.setattr(whatsapp_adapter, "resolve_group", lambda _value: None)
    monkeypatch.setattr(whatsapp_adapter, "resolve_contact", lambda _value: None)

    captured = {}

    def _fake_read_archived_messages(**kwargs):
        captured.update(kwargs)
        return []

    monkeypatch.setattr(integrations, "read_archived_messages", _fake_read_archived_messages)

    whatsapp_tools._read_whatsapp("+506 1234-5678|12")

    assert captured["from_number"] == "50612345678"
    assert captured["limit"] == 12


def test_read_whatsapp_connected_mode_reads_number(monkeypatch):
    monkeypatch.setattr(whatsapp_adapter, "is_connected", lambda: True)
    monkeypatch.setattr(whatsapp_adapter, "is_external_process_running", lambda: False)
    monkeypatch.setattr(whatsapp_adapter, "list_groups", lambda: [])
    monkeypatch.setattr(whatsapp_adapter, "normalize_group_jid", lambda value: value)
    monkeypatch.setattr(whatsapp_adapter, "resolve_group", lambda _value: None)
    monkeypatch.setattr(whatsapp_adapter, "resolve_contact", lambda _value: None)
    monkeypatch.setattr(
        whatsapp_adapter,
        "get_recent_messages",
        lambda n, from_number=None: [
            {
                "received_at": "2026-04-25T10:00:00+00:00",
                "from": "50612345678",
                "message_id": "fresh-1",
                "raw_text": "mensaje nuevo numero",
            }
        ],
    )

    result = whatsapp_tools._read_whatsapp("50612345678|5")

    assert "Recent incoming WhatsApp messages:" in result
    assert "fresh-1" in result
    assert "mensaje nuevo numero" in result


def test_read_whatsapp_connected_mode_reads_group(monkeypatch):
    monkeypatch.setattr(whatsapp_adapter, "is_connected", lambda: True)
    monkeypatch.setattr(whatsapp_adapter, "is_external_process_running", lambda: False)
    monkeypatch.setattr(
        whatsapp_adapter,
        "list_groups",
        lambda: [{"name": "Zafiro", "jid": "120363000000000999@g.us"}],
    )
    monkeypatch.setattr(
        whatsapp_adapter,
        "resolve_group",
        lambda value: {"name": "Zafiro", "jid": "120363000000000999@g.us"} if value == "Zafiro" else None,
    )
    monkeypatch.setattr(whatsapp_adapter, "normalize_group_jid", lambda value: value)
    monkeypatch.setattr(whatsapp_adapter, "resolve_contact", lambda _value: None)

    monkeypatch.setattr(
        "zafiro_skill_whatsapp.adapters.whatsapp.processing.get_recent_group_messages",
        lambda group_jid, n=10: [
            {
                "received_at": "2026-04-25T10:05:00+00:00",
                "from": "50577427779",
                "message_id": "fresh-group-1",
                "raw_text": "mensaje nuevo grupo",
                "chat_jid": group_jid,
            }
        ],
    )

    result = whatsapp_tools._read_whatsapp("Zafiro|5")

    assert "Recent incoming WhatsApp messages:" in result
    assert "fresh-group-1" in result
    assert "group=Zafiro" in result


def test_read_whatsapp_connected_mode_group_empty_buffer_returns_hint(monkeypatch):
    monkeypatch.setattr(whatsapp_adapter, "is_connected", lambda: True)
    monkeypatch.setattr(whatsapp_adapter, "is_external_process_running", lambda: False)
    monkeypatch.setattr(
        whatsapp_adapter,
        "list_groups",
        lambda: [{"name": "Zafiro", "jid": "120363000000000999@g.us"}],
    )
    monkeypatch.setattr(
        whatsapp_adapter,
        "resolve_group",
        lambda value: {"name": "Zafiro", "jid": "120363000000000999@g.us"} if value == "Zafiro" else None,
    )
    monkeypatch.setattr(whatsapp_adapter, "normalize_group_jid", lambda value: value)
    monkeypatch.setattr(whatsapp_adapter, "resolve_contact", lambda _value: None)
    monkeypatch.setattr(
        "zafiro_skill_whatsapp.adapters.whatsapp.processing.get_recent_group_messages",
        lambda group_jid, n=10: [],
    )

    result = whatsapp_tools._read_whatsapp("Zafiro|5")

    assert "No recent WhatsApp messages found in current runtime buffer for group 'Zafiro'" in result
    assert "read_whatsapp_archive" in result


def test_read_whatsapp_returns_help_for_unknown_alias(monkeypatch):
    monkeypatch.setattr(whatsapp_adapter, "is_connected", lambda: False)
    monkeypatch.setattr(whatsapp_adapter, "is_external_process_running", lambda: True)
    monkeypatch.setattr(whatsapp_adapter, "list_groups", lambda: [])
    monkeypatch.setattr(whatsapp_adapter, "normalize_group_jid", lambda value: value)
    monkeypatch.setattr(whatsapp_adapter, "resolve_group", lambda _value: None)
    monkeypatch.setattr(whatsapp_adapter, "resolve_contact", lambda _value: None)

    result = whatsapp_tools._read_whatsapp("Persona Inexistente")

    assert "Unknown WhatsApp contact/group" in result


def test_read_whatsapp_archive_returns_help_for_unknown_alias(monkeypatch):
    monkeypatch.setattr(whatsapp_adapter, "normalize_group_jid", lambda value: value)
    monkeypatch.setattr(whatsapp_adapter, "resolve_group", lambda _value: None)
    monkeypatch.setattr(whatsapp_adapter, "resolve_contact", lambda _value: None)

    result = whatsapp_tools._read_whatsapp_archive("Persona Inexistente")

    assert "Unknown WhatsApp contact/group" in result


def test_read_whatsapp_archive_resolves_group_alias(monkeypatch):
    monkeypatch.setattr(
        whatsapp_adapter,
        "resolve_group",
        lambda value: {"name": "Reservas", "jid": "120363000000000000@g.us"} if value == "Reservas" else None,
    )
    monkeypatch.setattr(whatsapp_adapter, "resolve_contact", lambda _value: None)
    monkeypatch.setattr(whatsapp_adapter, "normalize_group_jid", lambda _value: "120363000000000000@g.us")

    captured = {}

    def _fake_read_archived_messages(**kwargs):
        captured.update(kwargs)
        return [
            {
                "received_at": "2026-04-18T12:00:00+00:00",
                "from_": "50611112222",
                "message_id": "a1",
                "type": "text",
                "raw_text": "hola grupo alias",
                "chat_jid": kwargs.get("chat_jid"),
            }
        ]

    monkeypatch.setattr(integrations, "read_archived_messages", _fake_read_archived_messages)

    result = whatsapp_tools._read_whatsapp_archive("Reservas|10")

    assert captured["chat_jid"] == "120363000000000000@g.us"
    assert "a1" in result


def test_read_whatsapp_archive_accepts_space_separated_limit(monkeypatch):
    monkeypatch.setattr(
        whatsapp_adapter,
        "resolve_group",
        lambda value: {"name": "Reservas", "jid": "120363000000000000@g.us"} if value == "Reservas" else None,
    )
    monkeypatch.setattr(whatsapp_adapter, "resolve_contact", lambda _value: None)
    monkeypatch.setattr(whatsapp_adapter, "normalize_group_jid", lambda _value: "120363000000000000@g.us")

    captured = {}

    def _fake_read_archived_messages(**kwargs):
        captured.update(kwargs)
        return [
            {
                "received_at": "2026-04-18T12:00:00+00:00",
                "from_": "50611112222",
                "message_id": "a1",
                "type": "text",
                "raw_text": "hola grupo alias",
                "chat_jid": kwargs.get("chat_jid"),
            }
        ]

    monkeypatch.setattr(integrations, "read_archived_messages", _fake_read_archived_messages)

    result = whatsapp_tools._read_whatsapp_archive("Reservas 10")

    assert captured["chat_jid"] == "120363000000000000@g.us"
    assert captured["limit"] == 10
    assert "a1" in result


def test_read_whatsapp_external_group_no_archive_returns_hint(monkeypatch):
    monkeypatch.setattr(whatsapp_adapter, "is_connected", lambda: False)
    monkeypatch.setattr(whatsapp_adapter, "is_external_process_running", lambda: True)
    monkeypatch.setattr(
        whatsapp_adapter,
        "resolve_group",
        lambda value: {"name": "Zafiro", "jid": "120363000000000999@g.us"} if value == "Zafiro" else None,
    )
    monkeypatch.setattr(whatsapp_adapter, "resolve_contact", lambda _value: None)
    monkeypatch.setattr(whatsapp_adapter, "normalize_group_jid", lambda value: value)
    monkeypatch.setattr(whatsapp_adapter, "list_groups", lambda: [{"name": "Zafiro", "jid": "120363000000000999@g.us"}])
    monkeypatch.setattr(integrations, "read_archived_messages", lambda **_kwargs: [])

    result = whatsapp_tools._read_whatsapp("Zafiro|20")

    assert "No archived WhatsApp messages found for group 'Zafiro'" in result
    assert "already archived data" in result


def test_read_archived_messages_matches_number_with_plus_format(monkeypatch, tmp_path):
    integrations.reset_storage_for_tests(account_key="unknown")
    integrations.archive_whatsapp_payload(
        {
            "direction": "inbound",
            "delivery_status": "received",
            "from_": "50612345678",
            "peer_number": "50612345678",
            "jid": "50612345678@s.whatsapp.net",
            "type": "text",
            "received_at": "2026-04-25T12:00:00+00:00",
            "raw_text": "hola",
            "audio_transcription": None,
            "image_analysis": None,
            "media_path": None,
            "mime_type": None,
            "source_channel": "whatsapp",
            "message_id": "m-1",
            "reply_to_message_id": None,
            "chat_jid": "50612345678@s.whatsapp.net",
            "sender_jid": "50612345678@s.whatsapp.net",
            "session_id": "whatsapp:50612345678",
        }
    )

    rows = integrations.read_archived_messages(from_number="+506 1234-5678", limit=10)

    assert any(row.get("message_id") == "m-1" for row in rows)


def test_read_archived_messages_for_contact_includes_direct_outbound_and_excludes_group(monkeypatch, tmp_path):
    integrations.reset_storage_for_tests(account_key="unknown")

    integrations.archive_whatsapp_payload(
        {
            "direction": "outbound",
            "delivery_status": "sent",
            "from_": "50582480271",
            "peer_number": "50612345678",
            "jid": "50612345678@s.whatsapp.net",
            "type": "text",
            "received_at": "2026-04-25T12:00:00+00:00",
            "raw_text": "hola outbound directo",
            "audio_transcription": None,
            "image_analysis": None,
            "media_path": None,
            "mime_type": None,
            "source_channel": "whatsapp",
            "message_id": "m-out-direct",
            "reply_to_message_id": None,
            "chat_jid": "50612345678@s.whatsapp.net",
            "sender_jid": "50582480271@s.whatsapp.net",
            "session_id": "whatsapp:50612345678",
        }
    )

    integrations.archive_whatsapp_payload(
        {
            "direction": "inbound",
            "delivery_status": "received",
            "from_": "50612345678",
            "peer_number": "50612345678",
            "jid": "50612345678@s.whatsapp.net",
            "type": "text",
            "received_at": "2026-04-25T12:01:00+00:00",
            "raw_text": "hola inbound directo",
            "audio_transcription": None,
            "image_analysis": None,
            "media_path": None,
            "mime_type": None,
            "source_channel": "whatsapp",
            "message_id": "m-in-direct",
            "reply_to_message_id": None,
            "chat_jid": "50612345678@s.whatsapp.net",
            "sender_jid": "50612345678@s.whatsapp.net",
            "session_id": "whatsapp:50612345678",
        }
    )

    integrations.archive_whatsapp_payload(
        {
            "direction": "inbound",
            "delivery_status": "received",
            "from_": "50612345678",
            "peer_number": "50612345678",
            "jid": "50612345678@s.whatsapp.net",
            "type": "text",
            "received_at": "2026-04-25T12:02:00+00:00",
            "raw_text": "mensaje en grupo",
            "audio_transcription": None,
            "image_analysis": None,
            "media_path": None,
            "mime_type": None,
            "source_channel": "whatsapp",
            "message_id": "m-in-group",
            "reply_to_message_id": None,
            "chat_jid": "120363000000000999@g.us",
            "sender_jid": "50612345678@s.whatsapp.net",
            "session_id": "whatsapp:120363000000000999@g.us",
        }
    )

    rows = integrations.read_archived_messages(from_number="50612345678", limit=10)
    message_ids = {row.get("message_id") for row in rows}

    assert "m-out-direct" in message_ids
    assert "m-in-direct" in message_ids
    assert "m-in-group" not in message_ids
