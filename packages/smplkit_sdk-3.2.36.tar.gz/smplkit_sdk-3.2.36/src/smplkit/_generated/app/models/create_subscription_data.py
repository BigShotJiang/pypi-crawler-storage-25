from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, TYPE_CHECKING

from attrs import define as _attrs_define
from attrs import field as _attrs_field


if TYPE_CHECKING:
    from ..models.create_subscription_attributes import CreateSubscriptionAttributes


T = TypeVar("T", bound="CreateSubscriptionData")


@_attrs_define
class CreateSubscriptionData:
    """Resource object for the create-subscription request.

    Example:
        {'attributes': {'payment_method': 'a1b2c3d4-e5f6-7890-abcd-ef1234567890', 'plan': 'pro', 'product': 'flags'},
            'type': 'subscription'}

    Attributes:
        type_ (str): Resource type; must be `subscription`.
        attributes (CreateSubscriptionAttributes): Attributes accepted when creating a new subscription. Example:
            {'payment_method': 'a1b2c3d4-e5f6-7890-abcd-ef1234567890', 'plan': 'pro', 'product': 'flags'}.
    """

    type_: str
    attributes: CreateSubscriptionAttributes
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        type_ = self.type_

        attributes = self.attributes.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "type": type_,
                "attributes": attributes,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.create_subscription_attributes import CreateSubscriptionAttributes

        d = dict(src_dict)
        type_ = d.pop("type")

        attributes = CreateSubscriptionAttributes.from_dict(d.pop("attributes"))

        create_subscription_data = cls(
            type_=type_,
            attributes=attributes,
        )

        create_subscription_data.additional_properties = d
        return create_subscription_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
