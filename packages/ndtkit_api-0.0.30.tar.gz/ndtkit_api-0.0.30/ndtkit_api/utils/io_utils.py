from mmap import mmap, ACCESS_READ
from array import array
import os
import tempfile


MEMORY_MAPPING_FILE = os.path.join(tempfile.gettempdir(), "ndtkit_memory_mapping.bin")


def read_full_memory_mapped_file(file_path=MEMORY_MAPPING_FILE) -> array:
    """Read the entire contents of a memory-mapped file into a list of floats."""
    try:
        with open(file_path, "rb") as f:
            mm = mmap(f.fileno(), 0, access=ACCESS_READ)
            float_array = array('f')
            # Read directly from the map into the array
            # This is a raw memory copy, much faster than unpack
            float_array.frombytes(mm)
            return float_array
    except Exception as e:
        print(f"Error reading memory-mapped file: {e}")
        return array('f')
