# Copyright 2025 LiveKit, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from typing import Literal

SarvamLLMModels = Literal[
    "sarvam-m",
    "sarvam-30b",
    "sarvam-30b-16k",  # deprecated, kept for backward compatibility
    "sarvam-105b",
    "sarvam-105b-32k",  # deprecated, kept for backward compatibility
]
