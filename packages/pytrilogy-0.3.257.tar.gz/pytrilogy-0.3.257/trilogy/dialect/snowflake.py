from jinja2 import Template

from trilogy.core.enums import FunctionType, UnnestMode
from trilogy.core.models.core import DataType
from trilogy.dialect.base import BaseDialect

ENV_SNOWFLAKE_PW = "PREQL_SNOWFLAKE_PW"
ENV_SNOWFLAKE_USER = "PREQL_SNOWFLAKE_USER"
ENV_SNOWFLAKE_ACCOUNT = "PREQL_SNOWFLAKE_ACCOUNT"

FUNCTION_MAP = {
    FunctionType.COUNT: lambda x, types: f"count({x[0]})",
    FunctionType.SUM: lambda x, types: f"sum({x[0]})",
    FunctionType.LENGTH: lambda x, types: f"length({x[0]})",
    FunctionType.AVG: lambda x, types: f"avg({x[0]})",
    FunctionType.LIKE: lambda x, types: (
        f" CASE WHEN {x[0]} like {x[1]} THEN True ELSE False END"
    ),
    FunctionType.MINUTE: lambda x, types: f"EXTRACT(MINUTE from {x[0]})",
    FunctionType.SECOND: lambda x, types: f"EXTRACT(SECOND from {x[0]})",
    FunctionType.HOUR: lambda x, types: f"EXTRACT(HOUR from {x[0]})",
    FunctionType.DAY_OF_WEEK: lambda x, types: f"EXTRACT(DAYOFWEEK from {x[0]})",
    FunctionType.DAY: lambda x, types: f"EXTRACT(DAY from {x[0]})",
    FunctionType.YEAR: lambda x, types: f"EXTRACT(YEAR from {x[0]})",
    FunctionType.MONTH: lambda x, types: f"EXTRACT(MONTH from {x[0]})",
    FunctionType.WEEK: lambda x, types: f"EXTRACT(WEEK from {x[0]})",
    FunctionType.QUARTER: lambda x, types: f"EXTRACT(QUARTER from {x[0]})",
    # math
    FunctionType.POWER: lambda x, types: f"POWER({x[0]}, {x[1]})",
    FunctionType.DIVIDE: lambda x, types: f"DIV0({x[0]},{x[1]})",
    FunctionType.UNNEST: lambda x, types: f"table(flatten({x[0]}))",
    FunctionType.ARRAY: lambda x, types: f"ARRAY_CONSTRUCT({', '.join(x)})",
    FunctionType.CURRENT_DATETIME: lambda x, types: "CURRENT_TIMESTAMP()",
    FunctionType.CURRENT_DATE: lambda x, types: "CURRENT_DATE()",
    FunctionType.CURRENT_TIMESTAMP: lambda x, types: "CURRENT_TIMESTAMP()",
    # Snowflake date functions use different argument order
    FunctionType.DATE_TRUNCATE: lambda x, types: f"DATE_TRUNC({x[1]}, {x[0]})",
    FunctionType.DATE_PART: lambda x, types: f"DATE_PART({x[1]}, {x[0]})",
    FunctionType.DATE_ADD: lambda x, types: f"DATEADD({x[1]}, {x[2]}, {x[0]})",
    FunctionType.DATE_SUB: lambda x, types: f"DATEADD({x[1]}, -{x[2]}, {x[0]})",
    FunctionType.DATE_DIFF: lambda x, types: f"DATEDIFF({x[2]}, {x[0]}, {x[1]})",
}

FUNCTION_GRAIN_MATCH_MAP = {
    **FUNCTION_MAP,
    FunctionType.COUNT_DISTINCT: lambda args, types: f"CASE WHEN{args[0]} IS NOT NULL THEN 1 ELSE 0 END",
    FunctionType.COUNT: lambda args, types: f"CASE WHEN {args[0]} IS NOT NULL THEN 1 ELSE 0 END",
    FunctionType.SUM: lambda args, types: f"{args[0]}",
    FunctionType.AVG: lambda args, types: f"{args[0]}",
}


SNOWFLAKE_SQL_TEMPLATE = Template("""{%- if output %}
{{output}}
{% endif %}{%- if ctes %}
WITH {% if recursive%}RECURSIVE{% endif %}{% for cte in ctes %}
"{{cte.name}}" as ({{cte.statement}}){% if not loop.last %},{% endif %}{% else %}
{% endfor %}{% endif %}
{%- if full_select -%}
{{full_select}}
{%- else -%}

SELECT
{%- for select in select_columns %}
    {{ select }}{% if not loop.last %},{% endif %}{% endfor %}
{% if base %}FROM
    {{ base }}{% endif %}{% if joins %}{% for join in joins %}
    {{ join }}{% endfor %}{% endif %}
{% if where %}WHERE
    {{ where }}
{% endif %}
{%- if group_by %}GROUP BY {% for group in group_by %}
    {{group}}{% if not loop.last %},{% endif %}{% endfor %}{% endif %}{% if having %}
HAVING
\t{{ having }}{% endif %}
{%- if order_by %}
ORDER BY {% for order in order_by %}
    {{ order }}{% if not loop.last %},{% endif %}{% endfor %}{% endif %}
{%- if limit is not none %}
LIMIT {{ limit }}{% endif %}{% endif %}
""")
MAX_IDENTIFIER_LENGTH = 50


class SnowflakeDialect(BaseDialect):
    FUNCTION_MAP = {**BaseDialect.FUNCTION_MAP, **FUNCTION_MAP}
    FUNCTION_GRAIN_MATCH_MAP = {
        **BaseDialect.FUNCTION_GRAIN_MATCH_MAP,
        **FUNCTION_GRAIN_MATCH_MAP,
    }
    QUOTE_CHARACTER = '"'
    SQL_TEMPLATE = SNOWFLAKE_SQL_TEMPLATE
    UNNEST_MODE = UnnestMode.SNOWFLAKE
    TABLE_NOT_FOUND_PATTERN = "does not exist"
    COLUMN_NOT_FOUND_PATTERN = "invalid identifier"

    def get_table_schema(
        self, executor, table_name: str, schema: str | None = None
    ) -> list[tuple]:
        """Snowflake stores unquoted identifiers as UPPER and quoted as lowercase.
        Use UPPER() comparison to find tables regardless of how they were created.
        """
        table_name_upper = table_name.upper()

        column_query = f"""
        SELECT
            column_name,
            data_type,
            is_nullable,
            comment as column_comment
        FROM information_schema.columns
        WHERE UPPER(table_name) = '{table_name_upper}'
        """
        if schema:
            schema_upper = schema.upper()
            column_query += f" AND UPPER(table_schema) = '{schema_upper}'"
        column_query += " ORDER BY ordinal_position"

        rows = executor.execute_raw_sql(column_query).fetchall()
        return rows

    # Snowflake information_schema reports internal type names that differ from DDL tokens.
    # e.g. INTEGER/NUMBER → "NUMBER", VARCHAR/TEXT → "TEXT", TIMESTAMP_NTZ → "TIMESTAMP_NTZ"
    DB_COLUMN_TYPE_MAP = {
        "text": DataType.STRING,
        "number": DataType.INTEGER,
        "float": DataType.FLOAT,
        "boolean": DataType.BOOL,
        "date": DataType.DATE,
        "timestamp_ntz": DataType.DATETIME,
        "timestamp_ltz": DataType.TIMESTAMP,
        "timestamp_tz": DataType.TIMESTAMP,
        "array": DataType.ARRAY,
    }

    def get_table_primary_keys(
        self, executor, table_name: str, schema: str | None = None
    ) -> list[str]:
        """Uses SHOW PRIMARY KEYS; note Snowflake PKs are not enforced."""
        table_name_upper = table_name.upper()

        # Use SHOW PRIMARY KEYS command (column_name is at index 4)
        if schema:
            schema_upper = schema.upper()
            pk_query = f"SHOW PRIMARY KEYS IN {schema_upper}.{table_name_upper}"
        else:
            pk_query = f"SHOW PRIMARY KEYS IN {table_name_upper}"

        rows = executor.execute_raw_sql(pk_query).fetchall()
        return [row[4] for row in rows] if rows else []
