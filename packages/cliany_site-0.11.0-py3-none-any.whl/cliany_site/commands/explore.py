import asyncio
import contextlib
import json
import os
import sys
from pathlib import Path
from urllib.parse import urlparse

import click

from cliany_site.config import get_config
from cliany_site.envelope import ErrorCode, err, ok
from cliany_site.response import print_response


def _post_save_agent_md(domain: str, commands_list: list[str]) -> None:
    from cliany_site.agent_md import regenerate
    from cliany_site.registry import Registry

    env_skip = bool(os.environ.get("CLIANY_NO_AGENT_MD"))
    registry = Registry()
    registry.collect([], [], [(name, domain) for name in commands_list])
    result = regenerate(Path.cwd(), registry, force=False, env_skip=env_skip)
    if result.conflict:
        click.echo("⚠ AGENT.md 충돌 감지: 수동 수정됨, 덮어쓰지 않음", err=True)


@click.command("explore")
@click.argument("url")
@click.argument("workflow_description")
@click.option("--force", is_flag=True, default=False, help="覆盖已有的 adapter（无需确认）")
@click.option("--json", "json_mode", is_flag=True, default=None, help="JSON 输出")
@click.option("--interactive", "-i", is_flag=True, default=False, help="交互式探索模式")
@click.option("--extend", type=str, help="扩展现有适配器")
@click.option("--record/--no-record", default=True, help="是否记录探索过程")
@click.pass_context
def explore_cmd(
    ctx: click.Context,
    url: str,
    workflow_description: str,
    force: bool,
    json_mode: bool | None,
    interactive: bool,
    extend: str | None,
    record: bool,
):
    """探索网站工作流并生成 CLI adapter"""
    root_ctx = ctx.find_root()
    root_obj = root_ctx.obj if isinstance(root_ctx.obj, dict) else {}
    effective_json_mode = json_mode if json_mode is not None else bool(root_obj.get("json_mode", False))

    if interactive and effective_json_mode:
        raise click.UsageError("--interactive 与 --json 不兼容，请删除 --json 标志")

    if interactive and not sys.stdin.isatty():
        raise click.UsageError("--interactive 需要 TTY 终端")

    async def _run():
        from cliany_site.browser.cdp import cdp_from_context
        from cliany_site.codegen.generator import (
            AdapterGenerator,
            _safe_domain,
            save_adapter,
        )
        from cliany_site.codegen.merger import AdapterMerger
        from cliany_site.explorer.engine import (
            WorkflowExplorer,
            _load_dotenv,
            _normalize_openai_base_url,
        )

        _load_dotenv()

        # Browser provider capability gate：非 Chrome provider 必须支持 AXTree 才允许 explore
        _browser_provider = get_config().browser_provider
        if _browser_provider and _browser_provider.lower() != "chrome":
            from cliany_site.providers.capabilities import feature_gate
            from cliany_site.providers.factory import get_provider
            try:
                _provider_inst = get_provider(_browser_provider)
                _snap = _provider_inst.get_capability_snapshot()
            except Exception as _exc:
                return err(
                    "explore",
                    ErrorCode.E_PROVIDER_NOT_FOUND,
                    f"Browser provider '{_browser_provider}' 初始化失败: {_exc}",
                    hint="请检查 CLIANY_BROWSER_PROVIDER 配置",
                )
            _gate = feature_gate("explore", _snap)
            if not _gate.allowed:
                return err(
                    "explore",
                    ErrorCode.E_MISSING_CAPABILITY,
                    f"当前 provider '{_browser_provider}' 不支持 explore 命令（缺少必要能力）",
                    hint=_gate.reason,
                )

        qa_offline = os.getenv("CLIANY_QA_OFFLINE") == "1"
        if qa_offline and not os.getenv("CLIANY_QA_FAKE_LLM_RESPONSES"):
            return err(
                "explore",
                ErrorCode.E_QA_OFFLINE_MISSING_FAKE_LLM,
                "CLIANY_QA_OFFLINE=1 requires CLIANY_QA_FAKE_LLM_RESPONSES",
                hint="set CLIANY_QA_FAKE_LLM_RESPONSES to a JSON file path",
                source="builtin",
            )

        cdp = cdp_from_context(ctx)
        if not await cdp.check_available():
            return err(
                "explore",
                ErrorCode.E_CDP_UNAVAILABLE,
                "Chrome CDP 不可用",
                hint="启动 Chrome 并开启 --remote-debugging-port=9222",
            )

        if not qa_offline:
            provider = os.getenv("CLIANY_LLM_PROVIDER", "anthropic").lower()
            if provider not in {"anthropic", "openai"}:
                return err(
                    "explore",
                    ErrorCode.E_LLM_DISABLED,
                    "LLM provider 配置无效",
                    hint="请将 CLIANY_LLM_PROVIDER 设置为 anthropic 或 openai",
                )

            has_anthropic_key = bool(os.getenv("CLIANY_ANTHROPIC_API_KEY") or os.getenv("ANTHROPIC_API_KEY"))
            has_openai_key = bool(os.getenv("CLIANY_OPENAI_API_KEY") or os.getenv("OPENAI_API_KEY"))

            if provider == "anthropic" and not has_anthropic_key:
                return err(
                    "explore",
                    ErrorCode.E_LLM_DISABLED,
                    "Anthropic API Key 未配置",
                    hint="设置 CLIANY_ANTHROPIC_API_KEY（或旧版 ANTHROPIC_API_KEY）",
                )

            if provider == "openai" and not has_openai_key:
                return err(
                    "explore",
                    ErrorCode.E_LLM_DISABLED,
                    "OpenAI API Key 未配置",
                    hint="设置 CLIANY_OPENAI_API_KEY（OpenRouter key 也可）",
                )

            if provider == "openai":
                try:
                    _normalize_openai_base_url(os.getenv("CLIANY_OPENAI_BASE_URL"))
                except (ValueError, TypeError) as e:
                    return err(
                        "explore",
                        ErrorCode.E_LLM_DISABLED,
                        f"OpenAI base URL 配置无效: {e}",
                        hint="请使用 https://host[:port]/v1 格式，例如 https://sub2api.chinahrt.com/v1",
                    )

        parsed = urlparse(url)
        domain = parsed.netloc or parsed.path

        if not effective_json_mode:
            from rich.console import Console

            console = Console(stderr=True)
            console.print(f"[cyan]正在探索: {url}[/cyan]")
        else:
            print(f"[explore] 正在探索: {url}", file=sys.stderr)

        from cliany_site.progress import NdjsonProgressReporter, RichProgressReporter

        reporter = NdjsonProgressReporter() if effective_json_mode else RichProgressReporter()

        try:
            cdp_url = root_obj.get("cdp_url")
            headless = root_obj.get("headless", False)
            explorer = WorkflowExplorer(
                cdp_url=cdp_url, headless=headless, interactive=interactive, extend_domain=extend
            )
            explore_result = await explorer.explore(url, workflow_description, progress=reporter, record=record)
        except ValueError as e:
            if "CLIANY_QA_FAKE_LLM_RESPONSES" in str(e):
                return err(
                    "explore",
                    ErrorCode.E_QA_OFFLINE_MISSING_FAKE_LLM,
                    str(e),
                    hint="set CLIANY_QA_FAKE_LLM_RESPONSES to a JSON file path",
                    source="builtin",
                )
            return err(
                "explore",
                ErrorCode.E_UNKNOWN,
                f"探索失败: {e}",
                hint="请检查 URL 是否可访问，LLM 配置是否正确",
            )
        except (OSError, RuntimeError) as e:
            return err(
                "explore",
                ErrorCode.E_UNKNOWN,
                f"探索失败: {e}",
                hint="请检查 URL 是否可访问，LLM 配置是否正确",
            )

        post_analysis = {
            "atoms_extracted": 0,
            "atoms_reused": 0,
            "validation_warnings": 0,
            "action_quality_score": 1.0,
        }

        try:
            reuse_count = sum(1 for action in explore_result.actions if action.action_type == "reuse_atom")
            post_analysis["atoms_reused"] = reuse_count

            from cliany_site.explorer.analyzer import AtomExtractor

            llm_client = getattr(explorer, "_llm", None)
            if llm_client is None:
                raise RuntimeError("LLM client unavailable")
            extractor = AtomExtractor(llm_client, domain)
            new_atoms = await extractor.extract_atoms(explore_result)
            post_analysis["atoms_extracted"] = len(new_atoms)
        except (
            RuntimeError,
            json.JSONDecodeError,
            KeyError,
            TypeError,
            ValueError,
            OSError,
        ):
            pass

        print(f"[explore] 发现 {len(explore_result.commands)} 个命令建议", file=sys.stderr)
        print(
            f"[explore] 后分析: 提取 {post_analysis['atoms_extracted']} 个原子, "
            f"复用 {post_analysis['atoms_reused']} 个原子",
            file=sys.stderr,
        )

        adapter_dir = get_config().adapters_dir / _safe_domain(domain)

        from cliany_site.activity_log import write_log

        if force or not adapter_dir.exists():
            gen = AdapterGenerator()
            code = gen.generate(explore_result, domain)
            metadata = {
                "source_url": url,
                "workflow": workflow_description,
            }
            try:
                adapter_path = save_adapter(domain, code, metadata, explore_result=explore_result)
            except Exception:
                if adapter_dir.exists():
                    for _tmp in adapter_dir.glob("*.tmp"):
                        _tmp.unlink(missing_ok=True)
                raise
            commands_list = [cmd.name for cmd in explore_result.commands]
            with contextlib.suppress(Exception):
                _post_save_agent_md(domain, commands_list)
            print(f"[explore] Adapter 已生成: {adapter_path}", file=sys.stderr)
            write_log(
                "explore",
                domain,
                workflow_description,
                "success",
                f"created {len(commands_list)} commands",
            )
            return ok(
                "explore",
                {
                    "domain": domain,
                    "adapter_path": adapter_path,
                    "adapter_mode": "created",
                    "commands": commands_list,
                    "commands_added": len(commands_list),
                    "commands_total": len(commands_list),
                    "pages_explored": len(explore_result.pages),
                    "actions_found": len(explore_result.actions),
                    "post_analysis": post_analysis,
                },
            )
        else:
            merger = AdapterMerger(domain)
            merge_result = merger.merge(
                explore_result,
                json_mode=effective_json_mode,
                workflow=workflow_description,
            )
            commands_list = [cmd.get("name", "") for cmd in merge_result.merged]
            adapter_path = str(merger.metadata_path.parent / "commands.py")
            with contextlib.suppress(Exception):
                _post_save_agent_md(domain, commands_list)
            print(f"[explore] Adapter 已合并: {adapter_path}", file=sys.stderr)
            write_log(
                "explore",
                domain,
                workflow_description,
                "success",
                f"merged {merge_result.added_count} new commands, total {merge_result.total_count}",
            )
            response_data: dict = {
                "domain": domain,
                "adapter_path": adapter_path,
                "adapter_mode": "merged",
                "commands": commands_list,
                "commands_added": merge_result.added_count,
                "commands_total": merge_result.total_count,
                "pages_explored": len(explore_result.pages),
                "actions_found": len(explore_result.actions),
                "post_analysis": post_analysis,
            }
            if merge_result.conflicts_resolved:
                response_data["conflicts_resolved"] = merge_result.conflicts_resolved
            return ok("explore", response_data)

    result = asyncio.run(_run())
    print_response(result, effective_json_mode)
