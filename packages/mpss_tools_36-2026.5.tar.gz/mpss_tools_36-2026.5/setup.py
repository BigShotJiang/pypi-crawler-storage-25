"""
SEE COPYRIGHT, LICENCE, and DOCUMENTATION NOTICES: files
README-COPYRIGHT-utf8.txt, README-LICENCE-utf8.txt, and README-DOCUMENTATION-utf8.txt
at project source root.
"""

from pypi_packaging_36 import SetupPackaging

if __name__ == "__main__":
    #
    SetupPackaging(__file__)
