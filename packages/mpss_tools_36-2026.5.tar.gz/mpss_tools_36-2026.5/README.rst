..
   SEE COPYRIGHT and LICENCE NOTICES: files README-COPYRIGHT-utf8.txt and
   README-LICENCE-utf8.txt at project source root.

.. |PROJECT_NAME|      replace:: mpss-tools-36
.. |SHORT_DESCRIPTION| replace:: Sharing Python objects, Numpy arrays, and progress bars for Python's multiprocessing

.. |PYPI_NAME_LITERAL| replace:: ``mpss-tools-36``
.. |PYPI_PROJECT_URL|  replace:: https://pypi.org/project/mpss-tools-36/
.. _PYPI_PROJECT_URL:  https://pypi.org/project/mpss-tools-36/

.. |DOCUMENTATION_URL| replace:: https://src.koda.cnrs.fr/eric.debreuve/mpss-tools-36/-/wikis/home
.. _DOCUMENTATION_URL: https://src.koda.cnrs.fr/eric.debreuve/mpss-tools-36/-/wikis/home

.. |DEPENDENCIES_MANDATORY| replace:: extension-36, logger-36, numpy
.. |DEPENDENCIES_OPTIONAL|  replace:: None



===================================
|PROJECT_NAME|: |SHORT_DESCRIPTION|
===================================



Documentation
=============

The documentation is available at |DOCUMENTATION_URL|_.



Installation
============

This project is published
on the `Python Package Index (PyPI) <https://pypi.org/>`_
at: |PYPI_PROJECT_URL|_.
It should be installable from Python distribution platforms or Integrated Development Environments (IDEs).
Otherwise, it can be installed from a command console using `pip <https://pip.pypa.io/>`_:

+--------------+-------------------------------------------------------+----------------------------------------------------------+
|              | For all users (after acquiring administrative rights) | For the current user (no administrative rights required) |
+==============+=======================================================+==========================================================+
| Installation | ``pip install`` |PYPI_NAME_LITERAL|                   | ``pip install --user`` |PYPI_NAME_LITERAL|               |
+--------------+-------------------------------------------------------+----------------------------------------------------------+
| Update       | ``pip install --upgrade`` |PYPI_NAME_LITERAL|         | ``pip install --user --upgrade`` |PYPI_NAME_LITERAL|     |
+--------------+-------------------------------------------------------+----------------------------------------------------------+



Dependencies
============

The development relies on several packages:

- Mandatory: |DEPENDENCIES_MANDATORY|
- Optional:  |DEPENDENCIES_OPTIONAL|

The mandatory dependencies, if any, are installed automatically by `pip <https://pip.pypa.io/>`_, if they are not already, as part of the installation of |PROJECT_NAME|.
Python distribution platforms or Integrated Development Environments (IDEs) should also take care of this.
The optional dependencies, if any, must be installed independently by following the related instructions, for added functionalities of |PROJECT_NAME|.



Packaging
=========

Missing files for packaging the project from source
(notably, ``documentation/wiki/description.asciidoc``, ``README-template.rst``, ``pyproject.toml``, and ``setup.py``)
can be found
on the `Python package template <https://src.koda.cnrs.fr/eric.debreuve/python-package-template>`_ repository
and as part of the `documentation wiki <https://src.koda.cnrs.fr/eric.debreuve/mpss-tools-36/-/wikis/home/../description.asciidoc>`_.



Acknowledgments
===============

.. image:: https://img.shields.io/badge/code%20style-black-000000.svg
   :target: https://github.com/psf/black
.. image:: https://img.shields.io/badge/%20imports-isort-%231674b1?style=flat&labelColor=ef8336
   :target: https://github.com/timothycrosley/isort/
.. image:: https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json
   :target: https://github.com/astral-sh/ruff

The project is developed with `PyCharm Community <https://www.jetbrains.com/pycharm/>`_.

The code is formatted by `Black <https://github.com/psf/black/>`_, *The Uncompromising Code Formatter*,
or `Ruff <https://github.com/astral-sh/ruff>`_, *An extremely fast Python linter and code formatter, written in Rust*.

The imports are ordered by `isort <https://github.com/timothycrosley/isort/>`_... *your imports, so you don't have to*,
or `Ruff <https://github.com/astral-sh/ruff>`_, *An extremely fast Python linter and code formatter, written in Rust*.
