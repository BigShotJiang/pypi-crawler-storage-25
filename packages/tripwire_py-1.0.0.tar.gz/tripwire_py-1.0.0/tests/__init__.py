"""Test suite for TripWire."""
