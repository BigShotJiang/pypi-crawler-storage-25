from sqlalchemy.ext.declarative import declared_attr
from sqlalchemy.orm import synonym

from hockey_blast_common_lib.models import db


class AggregationTimestampMixin:
    """Mixin to add aggregation timestamp tracking to all stats models."""
    aggregation_started_at = db.Column(db.DateTime, nullable=True)
    aggregation_completed_at = db.Column(db.DateTime, nullable=True)


class BaseStatsHuman(AggregationTimestampMixin, db.Model):
    __abstract__ = True
    id = db.Column(db.Integer, primary_key=True)
    human_id = db.Column(db.Integer, db.ForeignKey("humans.id"), nullable=False)
    games_total = db.Column(db.Integer, default=0)
    games_total_rank = db.Column(db.Integer, default=0)
    games_skater = db.Column(db.Integer, default=0)
    games_skater_rank = db.Column(db.Integer, default=0)
    games_referee = db.Column(db.Integer, default=0)
    games_referee_rank = db.Column(db.Integer, default=0)
    games_scorekeeper = db.Column(db.Integer, default=0)
    games_scorekeeper_rank = db.Column(db.Integer, default=0)
    games_goalie = db.Column(db.Integer, default=0)
    games_goalie_rank = db.Column(db.Integer, default=0)
    total_in_rank = db.Column(db.Integer, default=0)
    skaters_in_rank = db.Column(db.Integer, default=0)
    goalies_in_rank = db.Column(db.Integer, default=0)
    referees_in_rank = db.Column(db.Integer, default=0)
    scorekeepers_in_rank = db.Column(db.Integer, default=0)
    first_game_id = db.Column(db.Integer, db.ForeignKey("games.id"), nullable=True)
    last_game_id = db.Column(db.Integer, db.ForeignKey("games.id"), nullable=True)
    first_game_id_skater = db.Column(
        db.Integer, db.ForeignKey("games.id"), nullable=True
    )
    last_game_id_skater = db.Column(
        db.Integer, db.ForeignKey("games.id"), nullable=True
    )
    first_game_id_goalie = db.Column(
        db.Integer, db.ForeignKey("games.id"), nullable=True
    )
    last_game_id_goalie = db.Column(
        db.Integer, db.ForeignKey("games.id"), nullable=True
    )
    first_game_id_referee = db.Column(
        db.Integer, db.ForeignKey("games.id"), nullable=True
    )
    last_game_id_referee = db.Column(
        db.Integer, db.ForeignKey("games.id"), nullable=True
    )
    first_game_id_scorekeeper = db.Column(
        db.Integer, db.ForeignKey("games.id"), nullable=True
    )
    last_game_id_scorekeeper = db.Column(
        db.Integer, db.ForeignKey("games.id"), nullable=True
    )

    @declared_attr
    def __table_args__(cls):
        return (
            db.UniqueConstraint(
                "human_id",
                cls.get_aggregation_column(),
                name=f"_human_{cls.aggregation_type}_stats_uc1",
            ),
            db.Index(
                f"idx_{cls.aggregation_type}_games_total1",
                cls.get_aggregation_column(),
                "games_total",
            ),
            db.Index(
                f"idx_{cls.aggregation_type}_games_skater1",
                cls.get_aggregation_column(),
                "games_skater",
            ),
            db.Index(
                f"idx_{cls.aggregation_type}_games_referee1",
                cls.get_aggregation_column(),
                "games_referee",
            ),
            db.Index(
                f"idx_{cls.aggregation_type}_games_scorekeeper1",
                cls.get_aggregation_column(),
                "games_scorekeeper",
            ),
            db.Index(
                f"idx_{cls.aggregation_type}_games_goalie1",
                cls.get_aggregation_column(),
                "games_goalie",
            ),
        )

    @classmethod
    def get_aggregation_column(cls):
        raise NotImplementedError(
            "Subclasses should implement this method to return the aggregation column name."
        )


class BaseStatsSkater(AggregationTimestampMixin, db.Model):
    __abstract__ = True
    id = db.Column(db.Integer, primary_key=True)
    human_id = db.Column(db.Integer, db.ForeignKey("humans.id"), nullable=False)
    games_played = db.Column(
        db.Integer, default=0
    )  # DEPRECATED - use games_participated instead
    games_played_rank = db.Column(db.Integer, default=0)
    games_participated = db.Column(
        db.Integer, default=0
    )  # Count FINAL, FINAL_SO, FORFEIT, NOEVENTS
    games_participated_rank = db.Column(db.Integer, default=0)
    games_with_stats = db.Column(db.Integer, default=0)  # Count only FINAL, FINAL_SO
    games_with_stats_rank = db.Column(db.Integer, default=0)
    goals = db.Column(db.Integer, default=0)
    goals_rank = db.Column(db.Integer, default=0)
    assists = db.Column(db.Integer, default=0)
    assists_rank = db.Column(db.Integer, default=0)
    points = db.Column(db.Integer, default=0)
    points_rank = db.Column(db.Integer, default=0)
    penalties = db.Column(db.Integer, default=0)
    penalties_rank = db.Column(db.Integer, default=0)
    gm_penalties = db.Column(db.Integer, default=0)  # New field for GM penalties
    gm_penalties_rank = db.Column(
        db.Integer, default=0
    )  # New field for GM penalties rank
    goals_per_game = db.Column(db.Float, default=0.0)
    goals_per_game_rank = db.Column(db.Integer, default=0)
    points_per_game = db.Column(db.Float, default=0.0)
    points_per_game_rank = db.Column(db.Integer, default=0)
    assists_per_game = db.Column(db.Float, default=0.0)
    assists_per_game_rank = db.Column(db.Integer, default=0)
    penalties_per_game = db.Column(db.Float, default=0.0)
    penalties_per_game_rank = db.Column(db.Integer, default=0)
    gm_penalties_per_game = db.Column(db.Float, default=0.0)
    gm_penalties_per_game_rank = db.Column(db.Integer, default=0)
    total_in_rank = db.Column(db.Integer, default=0)
    current_point_streak = db.Column(db.Integer, default=0)
    current_point_streak_rank = db.Column(db.Integer, default=0)
    current_point_streak_avg_points = db.Column(db.Float, default=0.0)
    current_point_streak_avg_points_rank = db.Column(db.Integer, default=0)
    first_game_id = db.Column(db.Integer, db.ForeignKey("games.id"))
    last_game_id = db.Column(db.Integer, db.ForeignKey("games.id"))

    @declared_attr
    def __table_args__(cls):
        return (
            db.UniqueConstraint(
                "human_id",
                cls.get_aggregation_column(),
                name=f"_human_{cls.aggregation_type}_uc_skater1",
            ),
            db.Index(
                f"idx_{cls.aggregation_type}_goals_per_game3",
                cls.get_aggregation_column(),
                "goals_per_game",
            ),
            db.Index(
                f"idx_{cls.aggregation_type}_points_per_game3",
                cls.get_aggregation_column(),
                "points_per_game",
            ),
            db.Index(
                f"idx_{cls.aggregation_type}_assists_per_game3",
                cls.get_aggregation_column(),
                "assists_per_game",
            ),
            db.Index(
                f"idx_{cls.aggregation_type}_penalties_per_game3",
                cls.get_aggregation_column(),
                "penalties_per_game",
            ),
            db.Index(
                f"idx_{cls.aggregation_type}_gm_penalties_per_game3",
                cls.get_aggregation_column(),
                "gm_penalties_per_game",
            ),
            db.Index(
                f"idx_{cls.aggregation_type}_current_point_streak3",
                cls.get_aggregation_column(),
                "current_point_streak",
            ),
            db.Index(
                f"idx_{cls.aggregation_type}_current_point_streak_avg_points3",
                cls.get_aggregation_column(),
                "current_point_streak_avg_points",
            ),
            db.Index(
                f"idx_{cls.aggregation_type}_games_played3",
                cls.get_aggregation_column(),
                "games_played",
            ),
        )

    @classmethod
    def get_aggregation_column(cls):
        raise NotImplementedError(
            "Subclasses should implement this method to return the aggregation column name."
        )


class BaseStatsGoalie(AggregationTimestampMixin, db.Model):
    __abstract__ = True
    id = db.Column(db.Integer, primary_key=True)
    human_id = db.Column(db.Integer, db.ForeignKey("humans.id"), nullable=False)
    games_played = db.Column(
        db.Integer, default=0
    )  # DEPRECATED - use games_participated instead
    games_played_rank = db.Column(db.Integer, default=0)
    games_participated = db.Column(
        db.Integer, default=0
    )  # Count FINAL, FINAL_SO, FORFEIT, NOEVENTS
    games_participated_rank = db.Column(db.Integer, default=0)
    games_with_stats = db.Column(db.Integer, default=0)  # Count only FINAL, FINAL_SO
    games_with_stats_rank = db.Column(db.Integer, default=0)
    goals_allowed = db.Column(db.Integer, default=0)
    goals_allowed_rank = db.Column(db.Integer, default=0)
    goals_allowed_per_game = db.Column(db.Float, default=0.0)
    goals_allowed_per_game_rank = db.Column(db.Integer, default=0)
    shots_faced = db.Column(db.Integer, default=0)
    shots_faced_rank = db.Column(db.Integer, default=0)
    save_percentage = db.Column(db.Float, default=0.0)
    save_percentage_rank = db.Column(db.Integer, default=0)
    wins = db.Column(db.Integer, default=0)
    wins_rank = db.Column(db.Integer, default=0)
    losses = db.Column(db.Integer, default=0)
    losses_rank = db.Column(db.Integer, default=0)
    ties = db.Column(db.Integer, default=0)
    ot_losses = db.Column(db.Integer, default=0)
    ot_losses_rank = db.Column(db.Integer, default=0)
    shutouts = db.Column(db.Integer, default=0)
    shutouts_rank = db.Column(db.Integer, default=0)
    win_percentage = db.Column(db.Float, default=0.0)
    win_percentage_rank = db.Column(db.Integer, default=0)
    total_in_rank = db.Column(db.Integer, default=0)
    first_game_id = db.Column(db.Integer, db.ForeignKey("games.id"))
    last_game_id = db.Column(db.Integer, db.ForeignKey("games.id"))

    @declared_attr
    def __table_args__(cls):
        return (
            db.UniqueConstraint(
                "human_id",
                cls.get_aggregation_column(),
                name=f"_human_{cls.aggregation_type}_uc_goalie1",
            ),
            db.Index(
                f"idx_{cls.aggregation_type}_goals_allowed_per_game1",
                cls.get_aggregation_column(),
                "goals_allowed_per_game",
            ),
            db.Index(
                f"idx_{cls.aggregation_type}_save_percentage1",
                cls.get_aggregation_column(),
                "save_percentage",
            ),
            db.Index(
                f"idx_{cls.aggregation_type}_shots_faced1",
                cls.get_aggregation_column(),
                "shots_faced",
            ),
            db.Index(
                f"idx_{cls.aggregation_type}_games_played_goalie1",
                cls.get_aggregation_column(),
                "games_played",
            ),
            db.Index(
                f"idx_{cls.aggregation_type}_goals_allowed1",
                cls.get_aggregation_column(),
                "goals_allowed",
            ),
            db.Index(
                f"idx_{cls.aggregation_type}_wins_goalie1",
                cls.get_aggregation_column(),
                "wins",
            ),
            db.Index(
                f"idx_{cls.aggregation_type}_shutouts_goalie1",
                cls.get_aggregation_column(),
                "shutouts",
            ),
            db.Index(
                f"idx_{cls.aggregation_type}_win_percentage_goalie1",
                cls.get_aggregation_column(),
                "win_percentage",
            ),
        )

    @classmethod
    def get_aggregation_column(cls):
        raise NotImplementedError(
            "Subclasses should implement this method to return the aggregation column name."
        )


class BaseStatsReferee(AggregationTimestampMixin, db.Model):
    __abstract__ = True
    id = db.Column(db.Integer, primary_key=True)
    human_id = db.Column(db.Integer, db.ForeignKey("humans.id"), nullable=False)
    games_reffed = db.Column(
        db.Integer, default=0
    )  # DEPRECATED - use games_participated instead
    games_reffed_rank = db.Column(db.Integer, default=0)
    games_participated = db.Column(
        db.Integer, default=0
    )  # Count FINAL, FINAL_SO, FORFEIT, NOEVENTS
    games_participated_rank = db.Column(db.Integer, default=0)
    games_with_stats = db.Column(
        db.Integer, default=0
    )  # Count only FINAL, FINAL_SO (for per-game averages)
    games_with_stats_rank = db.Column(db.Integer, default=0)
    penalties_given = db.Column(db.Integer, default=0)
    penalties_given_rank = db.Column(db.Integer, default=0)
    penalties_per_game = db.Column(db.Float, default=0.0)
    penalties_per_game_rank = db.Column(db.Integer, default=0)
    gm_given = db.Column(db.Integer, default=0)
    gm_given_rank = db.Column(db.Integer, default=0)
    gm_per_game = db.Column(db.Float, default=0.0)
    gm_per_game_rank = db.Column(db.Integer, default=0)
    total_in_rank = db.Column(db.Integer, default=0)
    first_game_id = db.Column(db.Integer, db.ForeignKey("games.id"))
    last_game_id = db.Column(db.Integer, db.ForeignKey("games.id"))

    @declared_attr
    def __table_args__(cls):
        return (
            db.UniqueConstraint(
                "human_id",
                cls.get_aggregation_column(),
                name=f"_human_{cls.aggregation_type}_uc_referee1",
            ),
            db.Index(
                f"idx_{cls.aggregation_type}_games_reffed1",
                cls.get_aggregation_column(),
                "games_reffed",
            ),
            db.Index(
                f"idx_{cls.aggregation_type}_penalties_given1",
                cls.get_aggregation_column(),
                "penalties_given",
            ),
            db.Index(
                f"idx_{cls.aggregation_type}_penalties_per_game1",
                cls.get_aggregation_column(),
                "penalties_per_game",
            ),
            db.Index(
                f"idx_{cls.aggregation_type}_gm_given1",
                cls.get_aggregation_column(),
                "gm_given",
            ),
            db.Index(
                f"idx_{cls.aggregation_type}_gm_per_game1",
                cls.get_aggregation_column(),
                "gm_per_game",
            ),
        )

    @classmethod
    def get_aggregation_column(cls):
        raise NotImplementedError(
            "Subclasses should implement this method to return the aggregation column name."
        )


class BaseStatsScorekeeper(AggregationTimestampMixin, db.Model):
    __abstract__ = True
    id = db.Column(db.Integer, primary_key=True)
    human_id = db.Column(db.Integer, db.ForeignKey("humans.id"), nullable=False)
    games_recorded = db.Column(
        db.Integer, default=0
    )  # DEPRECATED - use games_participated instead
    games_recorded_rank = db.Column(db.Integer, default=0)
    games_participated = db.Column(
        db.Integer, default=0
    )  # Count FINAL, FINAL_SO, FORFEIT, NOEVENTS
    games_participated_rank = db.Column(db.Integer, default=0)
    games_with_stats = db.Column(
        db.Integer, default=0
    )  # Count only FINAL, FINAL_SO (for per-game averages)
    games_with_stats_rank = db.Column(db.Integer, default=0)
    sog_given = db.Column(db.Integer, default=0)
    sog_given_rank = db.Column(db.Integer, default=0)
    sog_per_game = db.Column(db.Float, default=0.0)
    sog_per_game_rank = db.Column(db.Integer, default=0)

    # Quality metrics fields
    total_saves_recorded = db.Column(db.Integer, default=0)
    total_saves_recorded_rank = db.Column(db.Integer, default=0)
    avg_saves_per_game = db.Column(db.Float, default=0.0)
    avg_saves_per_game_rank = db.Column(db.Integer, default=0)
    avg_max_saves_per_5sec = db.Column(db.Float, default=0.0)
    avg_max_saves_per_5sec_rank = db.Column(db.Integer, default=0)
    avg_max_saves_per_20sec = db.Column(db.Float, default=0.0)
    avg_max_saves_per_20sec_rank = db.Column(db.Integer, default=0)
    peak_max_saves_per_5sec = db.Column(db.Integer, default=0)
    peak_max_saves_per_5sec_rank = db.Column(db.Integer, default=0)
    peak_max_saves_per_20sec = db.Column(db.Integer, default=0)
    peak_max_saves_per_20sec_rank = db.Column(db.Integer, default=0)
    quality_score = db.Column(db.Float, default=0.0)
    quality_score_rank = db.Column(db.Integer, default=0)

    total_in_rank = db.Column(db.Integer, default=0)
    first_game_id = db.Column(db.Integer, db.ForeignKey("games.id"))
    last_game_id = db.Column(db.Integer, db.ForeignKey("games.id"))

    @declared_attr
    def __table_args__(cls):
        return (
            db.UniqueConstraint(
                "human_id",
                cls.get_aggregation_column(),
                name=f"_human_{cls.aggregation_type}_uc_scorekeeper1",
            ),
            db.Index(
                f"idx_{cls.aggregation_type}_games_recorded1",
                cls.get_aggregation_column(),
                "games_recorded",
            ),
            db.Index(
                f"idx_{cls.aggregation_type}_sog_given1",
                cls.get_aggregation_column(),
                "sog_given",
            ),
            db.Index(
                f"idx_{cls.aggregation_type}_sog_per_game1",
                cls.get_aggregation_column(),
                "sog_per_game",
            ),
            db.Index(
                f"idx_{cls.aggregation_type}_total_saves_recorded1",
                cls.get_aggregation_column(),
                "total_saves_recorded",
            ),
            db.Index(
                f"idx_{cls.aggregation_type}_avg_saves_per_game1",
                cls.get_aggregation_column(),
                "avg_saves_per_game",
            ),
            db.Index(
                f"idx_{cls.aggregation_type}_avg_max_saves_per_5sec1",
                cls.get_aggregation_column(),
                "avg_max_saves_per_5sec",
            ),
            db.Index(
                f"idx_{cls.aggregation_type}_avg_max_saves_per_20sec1",
                cls.get_aggregation_column(),
                "avg_max_saves_per_20sec",
            ),
            db.Index(
                f"idx_{cls.aggregation_type}_peak_max_saves_per_5sec1",
                cls.get_aggregation_column(),
                "peak_max_saves_per_5sec",
            ),
            db.Index(
                f"idx_{cls.aggregation_type}_peak_max_saves_per_20sec1",
                cls.get_aggregation_column(),
                "peak_max_saves_per_20sec",
            ),
            db.Index(
                f"idx_{cls.aggregation_type}_quality_score1",
                cls.get_aggregation_column(),
                "quality_score",
            ),
        )

    @classmethod
    def get_aggregation_column(cls):
        raise NotImplementedError(
            "Subclasses should implement this method to return the aggregation column name."
        )


class OrgStatsHuman(BaseStatsHuman):
    __tablename__ = "org_stats_human"
    org_id = db.Column(db.Integer, db.ForeignKey("organizations.id"), nullable=False)
    aggregation_id = synonym("org_id")

    @declared_attr
    def aggregation_type(cls):
        return "org"

    @classmethod
    def get_aggregation_column(cls):
        return "org_id"


class DivisionStatsHuman(BaseStatsHuman):
    __tablename__ = "division_stats_human"
    division_id = db.Column(db.Integer, db.ForeignKey("divisions.id"), nullable=False)
    aggregation_id = synonym("division_id")

    @declared_attr
    def aggregation_type(cls):
        return "division"

    @classmethod
    def get_aggregation_column(cls):
        return "division_id"


class LevelStatsHuman(BaseStatsHuman):
    __tablename__ = "level_stats_human"
    level_id = db.Column(db.Integer, db.ForeignKey("levels.id"), nullable=False)
    aggregation_id = synonym("level_id")

    @declared_attr
    def aggregation_type(cls):
        return "level"

    @classmethod
    def get_aggregation_column(cls):
        return "level_id"


class OrgStatsSkater(BaseStatsSkater):
    __tablename__ = "org_stats_skater"
    org_id = db.Column(db.Integer, db.ForeignKey("organizations.id"), nullable=False)
    aggregation_id = synonym("org_id")

    @declared_attr
    def aggregation_type(cls):
        return "org"

    @classmethod
    def get_aggregation_column(cls):
        return "org_id"


class DivisionStatsSkater(BaseStatsSkater):
    __tablename__ = "division_stats_skater"
    division_id = db.Column(db.Integer, db.ForeignKey("divisions.id"), nullable=False)
    aggregation_id = synonym("division_id")

    @declared_attr
    def aggregation_type(cls):
        return "division"

    @classmethod
    def get_aggregation_column(cls):
        return "division_id"


class LevelStatsSkater(BaseStatsSkater):
    __tablename__ = "level_stats_skater"
    level_id = db.Column(db.Integer, db.ForeignKey("levels.id"), nullable=False)
    aggregation_id = synonym("level_id")

    @declared_attr
    def aggregation_type(cls):
        return "level"

    @classmethod
    def get_aggregation_column(cls):
        return "level_id"


class OrgStatsGoalie(BaseStatsGoalie):
    __tablename__ = "org_stats_goalie"
    org_id = db.Column(db.Integer, db.ForeignKey("organizations.id"), nullable=False)
    aggregation_id = synonym("org_id")

    @declared_attr
    def aggregation_type(cls):
        return "org"

    @classmethod
    def get_aggregation_column(cls):
        return "org_id"


class DivisionStatsGoalie(BaseStatsGoalie):
    __tablename__ = "division_stats_goalie"
    division_id = db.Column(db.Integer, db.ForeignKey("divisions.id"), nullable=False)
    aggregation_id = synonym("division_id")

    @declared_attr
    def aggregation_type(cls):
        return "division"

    @classmethod
    def get_aggregation_column(cls):
        return "division_id"


class LevelStatsGoalie(BaseStatsGoalie):
    __tablename__ = "level_stats_goalie"
    level_id = db.Column(db.Integer, db.ForeignKey("levels.id"), nullable=False)
    aggregation_id = synonym("level_id")

    @declared_attr
    def aggregation_type(cls):
        return "level"

    @classmethod
    def get_aggregation_column(cls):
        return "level_id"


class OrgStatsReferee(BaseStatsReferee):
    __tablename__ = "org_stats_referee"
    org_id = db.Column(db.Integer, db.ForeignKey("organizations.id"), nullable=False)
    aggregation_id = synonym("org_id")

    @declared_attr
    def aggregation_type(cls):
        return "org"

    @classmethod
    def get_aggregation_column(cls):
        return "org_id"


class DivisionStatsReferee(BaseStatsReferee):
    __tablename__ = "division_stats_referee"
    division_id = db.Column(db.Integer, db.ForeignKey("divisions.id"), nullable=False)
    aggregation_id = synonym("division_id")

    @declared_attr
    def aggregation_type(cls):
        return "division"

    @classmethod
    def get_aggregation_column(cls):
        return "division_id"


class LevelStatsReferee(BaseStatsReferee):
    __tablename__ = "level_stats_referee"
    level_id = db.Column(db.Integer, db.ForeignKey("levels.id"), nullable=False)
    aggregation_id = synonym("level_id")

    @declared_attr
    def aggregation_type(cls):
        return "level"

    @classmethod
    def get_aggregation_column(cls):
        return "level_id"


class OrgStatsScorekeeper(BaseStatsScorekeeper):
    __tablename__ = "org_stats_scorekeeper"
    org_id = db.Column(db.Integer, db.ForeignKey("organizations.id"), nullable=False)
    aggregation_id = synonym("org_id")

    @declared_attr
    def aggregation_type(cls):
        return "org"

    @classmethod
    def get_aggregation_column(cls):
        return "org_id"


class OrgStatsDailyHuman(BaseStatsHuman):
    __tablename__ = "org_stats_daily_human"
    org_id = db.Column(db.Integer, db.ForeignKey("organizations.id"), nullable=False)
    aggregation_id = synonym("org_id")

    @classmethod
    def get_aggregation_column(cls):
        return "org_id"

    @declared_attr
    def aggregation_type(cls):
        return "org_daily"


class OrgStatsWeeklyHuman(BaseStatsHuman):
    __tablename__ = "org_stats_weekly_human"
    org_id = db.Column(db.Integer, db.ForeignKey("organizations.id"), nullable=False)
    aggregation_id = synonym("org_id")

    @classmethod
    def get_aggregation_column(cls):
        return "org_id"

    @declared_attr
    def aggregation_type(cls):
        return "org_weekly"


class DivisionStatsDailyHuman(BaseStatsHuman):
    __tablename__ = "division_stats_daily_human"
    division_id = db.Column(db.Integer, db.ForeignKey("divisions.id"), nullable=False)
    aggregation_id = synonym("division_id")

    @classmethod
    def get_aggregation_column(cls):
        return "division_id"

    @declared_attr
    def aggregation_type(cls):
        return "division_daily"


class DivisionStatsWeeklyHuman(BaseStatsHuman):
    __tablename__ = "division_stats_weekly_human"
    division_id = db.Column(db.Integer, db.ForeignKey("divisions.id"), nullable=False)
    aggregation_id = synonym("division_id")

    @classmethod
    def get_aggregation_column(cls):
        return "division_id"

    @declared_attr
    def aggregation_type(cls):
        return "division_weekly"


class OrgStatsDailySkater(BaseStatsSkater):
    __tablename__ = "org_stats_daily_skater"
    org_id = db.Column(db.Integer, db.ForeignKey("organizations.id"), nullable=False)
    aggregation_id = synonym("org_id")

    @declared_attr
    def aggregation_type(cls):
        return "org_daily"

    @classmethod
    def get_aggregation_column(cls):
        return "org_id"


class OrgStatsWeeklySkater(BaseStatsSkater):
    __tablename__ = "org_stats_weekly_skater"
    org_id = db.Column(db.Integer, db.ForeignKey("organizations.id"), nullable=False)
    aggregation_id = synonym("org_id")

    @declared_attr
    def aggregation_type(cls):
        return "org_weekly"

    @classmethod
    def get_aggregation_column(cls):
        return "org_id"


class DivisionStatsDailySkater(BaseStatsSkater):
    __tablename__ = "division_stats_daily_skater"
    division_id = db.Column(db.Integer, db.ForeignKey("divisions.id"), nullable=False)
    aggregation_id = synonym("division_id")

    @declared_attr
    def aggregation_type(cls):
        return "division_daily"

    @classmethod
    def get_aggregation_column(cls):
        return "division_id"


class DivisionStatsWeeklySkater(BaseStatsSkater):
    __tablename__ = "division_stats_weekly_skater"
    division_id = db.Column(db.Integer, db.ForeignKey("divisions.id"), nullable=False)
    aggregation_id = synonym("division_id")

    @declared_attr
    def aggregation_type(cls):
        return "division_weekly"

    @classmethod
    def get_aggregation_column(cls):
        return "division_id"


class OrgStatsDailyGoalie(BaseStatsGoalie):
    __tablename__ = "org_stats_daily_goalie"
    org_id = db.Column(db.Integer, db.ForeignKey("organizations.id"), nullable=False)
    aggregation_id = synonym("org_id")

    @declared_attr
    def aggregation_type(cls):
        return "org_daily"

    @classmethod
    def get_aggregation_column(cls):
        return "org_id"


class OrgStatsWeeklyGoalie(BaseStatsGoalie):
    __tablename__ = "org_stats_weekly_goalie"
    org_id = db.Column(db.Integer, db.ForeignKey("organizations.id"), nullable=False)
    aggregation_id = synonym("org_id")

    @declared_attr
    def aggregation_type(cls):
        return "org_weekly"

    @classmethod
    def get_aggregation_column(cls):
        return "org_id"


class DivisionStatsDailyGoalie(BaseStatsGoalie):
    __tablename__ = "division_stats_daily_goalie"
    division_id = db.Column(db.Integer, db.ForeignKey("divisions.id"), nullable=False)
    aggregation_id = synonym("division_id")

    @declared_attr
    def aggregation_type(cls):
        return "division_daily"

    @classmethod
    def get_aggregation_column(cls):
        return "division_id"


class DivisionStatsWeeklyGoalie(BaseStatsGoalie):
    __tablename__ = "division_stats_weekly_goalie"
    division_id = db.Column(db.Integer, db.ForeignKey("divisions.id"), nullable=False)
    aggregation_id = synonym("division_id")

    @declared_attr
    def aggregation_type(cls):
        return "division_weekly"

    @classmethod
    def get_aggregation_column(cls):
        return "division_id"


class OrgStatsDailyReferee(BaseStatsReferee):
    __tablename__ = "org_stats_daily_referee"
    org_id = db.Column(db.Integer, db.ForeignKey("organizations.id"), nullable=False)
    aggregation_id = synonym("org_id")

    @declared_attr
    def aggregation_type(cls):
        return "org_daily"

    @classmethod
    def get_aggregation_column(cls):
        return "org_id"


class OrgStatsWeeklyReferee(BaseStatsReferee):
    __tablename__ = "org_stats_weekly_referee"
    org_id = db.Column(db.Integer, db.ForeignKey("organizations.id"), nullable=False)
    aggregation_id = synonym("org_id")

    @declared_attr
    def aggregation_type(cls):
        return "org_weekly"

    @classmethod
    def get_aggregation_column(cls):
        return "org_id"


class DivisionStatsDailyReferee(BaseStatsReferee):
    __tablename__ = "division_stats_daily_referee"
    division_id = db.Column(db.Integer, db.ForeignKey("divisions.id"), nullable=False)
    aggregation_id = synonym("division_id")

    @declared_attr
    def aggregation_type(cls):
        return "division_daily"

    @classmethod
    def get_aggregation_column(cls):
        return "division_id"


class DivisionStatsWeeklyReferee(BaseStatsReferee):
    __tablename__ = "division_stats_weekly_referee"
    division_id = db.Column(db.Integer, db.ForeignKey("divisions.id"), nullable=False)
    aggregation_id = synonym("division_id")

    @declared_attr
    def aggregation_type(cls):
        return "division_weekly"

    @classmethod
    def get_aggregation_column(cls):
        return "division_id"


class OrgStatsDailyScorekeeper(BaseStatsScorekeeper):
    __tablename__ = "org_stats_daily_scorekeeper"
    org_id = db.Column(db.Integer, db.ForeignKey("organizations.id"), nullable=False)
    aggregation_id = synonym("org_id")

    @declared_attr
    def aggregation_type(cls):
        return "org_daily"

    @classmethod
    def get_aggregation_column(cls):
        return "org_id"


class OrgStatsWeeklyScorekeeper(BaseStatsScorekeeper):
    __tablename__ = "org_stats_weekly_scorekeeper"
    org_id = db.Column(db.Integer, db.ForeignKey("organizations.id"), nullable=False)
    aggregation_id = synonym("org_id")

    @declared_attr
    def aggregation_type(cls):
        return "org_weekly"

    @classmethod
    def get_aggregation_column(cls):
        return "org_id"


class LevelsGraphEdge(db.Model):
    __tablename__ = "levels_graph_edges"
    id = db.Column(db.Integer, primary_key=True)
    from_level_id = db.Column(db.Integer, db.ForeignKey("levels.id"), nullable=False)
    to_level_id = db.Column(db.Integer, db.ForeignKey("levels.id"), nullable=False)
    n_connections = db.Column(db.Integer, nullable=False)
    ppg_ratio = db.Column(db.Float, nullable=False)
    n_games = db.Column(
        db.Integer, nullable=False
    )  # New field to store the number of games

    __table_args__ = (
        db.UniqueConstraint("from_level_id", "to_level_id", name="_from_to_level_uc"),
    )


class SkillPropagationCorrelation(db.Model):
    __tablename__ = "skill_propagation_correlation"
    id = db.Column(db.Integer, primary_key=True)
    skill_value_from = db.Column(db.Float, nullable=False)
    skill_value_to = db.Column(db.Float, nullable=False)
    ppg_ratio = db.Column(db.Float, nullable=False)

    __table_args__ = (
        db.UniqueConstraint(
            "skill_value_from",
            "skill_value_to",
            "ppg_ratio",
            name="_skill_value_ppg_ratio_uc",
        ),
    )


# How PPG changes with INCREASING SKILL VALUES
class SkillValuePPGRatio(db.Model):
    __tablename__ = "skill_value_ppg_ratios"
    id = db.Column(db.Integer, primary_key=True)
    from_skill_value = db.Column(db.Float, nullable=False)
    to_skill_value = db.Column(db.Float, nullable=False)
    ppg_ratio = db.Column(db.Float, nullable=False)
    n_games = db.Column(
        db.Integer, nullable=False
    )  # New field to store the sum of games

    __table_args__ = (
        db.UniqueConstraint(
            "from_skill_value", "to_skill_value", name="_from_to_skill_value_uc"
        ),
    )


# Team-based statistics models (inherit from existing bases, add team_id field)
class OrgStatsSkaterTeam(BaseStatsSkater):
    __tablename__ = "org_stats_skater_team"
    org_id = db.Column(db.Integer, db.ForeignKey("organizations.id"), nullable=False)
    team_id = db.Column(db.Integer, db.ForeignKey("teams.id"), nullable=False)
    aggregation_id = synonym("org_id")

    @declared_attr
    def aggregation_type(cls):
        return "org_team"

    @classmethod
    def get_aggregation_column(cls):
        return "org_id"

    @declared_attr
    def __table_args__(cls):
        return (
            db.UniqueConstraint(
                "org_id",
                "team_id",
                "human_id",
                name="_org_team_human_uc_skater_team1",
            ),
            db.Index("idx_org_team_team_id", "team_id"),
            db.Index("idx_org_team_human_id", "human_id"),
            db.Index("idx_org_team_goals_per_game", "org_id", "goals_per_game"),
            db.Index("idx_org_team_points_per_game", "org_id", "points_per_game"),
            db.Index("idx_org_team_assists_per_game", "org_id", "assists_per_game"),
        )


class DivisionStatsSkaterTeam(BaseStatsSkater):
    __tablename__ = "division_stats_skater_team"
    division_id = db.Column(db.Integer, db.ForeignKey("divisions.id"), nullable=False)
    team_id = db.Column(db.Integer, db.ForeignKey("teams.id"), nullable=False)
    aggregation_id = synonym("division_id")

    @declared_attr
    def aggregation_type(cls):
        return "division_team"

    @classmethod
    def get_aggregation_column(cls):
        return "division_id"

    @declared_attr
    def __table_args__(cls):
        return (
            db.UniqueConstraint(
                "division_id",
                "team_id",
                "human_id",
                name="_division_team_human_uc_skater_team1",
            ),
            db.Index("idx_division_team_team_id", "team_id"),
            db.Index("idx_division_team_human_id", "human_id"),
            db.Index("idx_division_team_goals_per_game", "division_id", "goals_per_game"),
            db.Index("idx_division_team_points_per_game", "division_id", "points_per_game"),
            db.Index("idx_division_team_assists_per_game", "division_id", "assists_per_game"),
        )


class OrgStatsGoalieTeam(BaseStatsGoalie):
    __tablename__ = "org_stats_goalie_team"
    org_id = db.Column(db.Integer, db.ForeignKey("organizations.id"), nullable=False)
    team_id = db.Column(db.Integer, db.ForeignKey("teams.id"), nullable=False)
    aggregation_id = synonym("org_id")

    @declared_attr
    def aggregation_type(cls):
        return "org_team"

    @classmethod
    def get_aggregation_column(cls):
        return "org_id"

    @declared_attr
    def __table_args__(cls):
        return (
            db.UniqueConstraint(
                "org_id",
                "team_id",
                "human_id",
                name="_org_team_human_uc_goalie_team1",
            ),
            db.Index("idx_org_team_goalie_team_id", "team_id"),
            db.Index("idx_org_team_goalie_human_id", "human_id"),
            db.Index("idx_org_team_goalie_save_pct", "org_id", "save_percentage"),
            db.Index("idx_org_team_goalie_gaa", "org_id", "goals_allowed_per_game"),
        )


class DivisionStatsGoalieTeam(BaseStatsGoalie):
    __tablename__ = "division_stats_goalie_team"
    division_id = db.Column(db.Integer, db.ForeignKey("divisions.id"), nullable=False)
    team_id = db.Column(db.Integer, db.ForeignKey("teams.id"), nullable=False)
    aggregation_id = synonym("division_id")

    @declared_attr
    def aggregation_type(cls):
        return "division_team"

    @classmethod
    def get_aggregation_column(cls):
        return "division_id"

    @declared_attr
    def __table_args__(cls):
        return (
            db.UniqueConstraint(
                "division_id",
                "team_id",
                "human_id",
                name="_division_team_human_uc_goalie_team1",
            ),
            db.Index("idx_division_team_goalie_team_id", "team_id"),
            db.Index("idx_division_team_goalie_human_id", "human_id"),
            db.Index("idx_division_team_goalie_save_pct", "division_id", "save_percentage"),
            db.Index("idx_division_team_goalie_gaa", "division_id", "goals_allowed_per_game"),
        )


# Per-Game Statistics Models (for RAG system)
# These models store individual game performance data for each player/goalie
# CRITICAL: Only non-zero rows are saved (games where player recorded stats)


class GameStatsSkater(db.Model):
    """Per-game skater statistics.

    Stores individual game performance for skaters.
    Only records where player had non-zero stats are saved.
    Optimized for queries like "show me top N games by points for player X".
    """
    __tablename__ = "game_stats_skater"

    id = db.Column(db.Integer, primary_key=True)
    game_id = db.Column(db.Integer, db.ForeignKey("games.id"), nullable=False, index=True)
    human_id = db.Column(db.Integer, db.ForeignKey("humans.id"), nullable=False, index=True)
    team_id = db.Column(db.Integer, db.ForeignKey("teams.id"), nullable=False, index=True)
    org_id = db.Column(db.Integer, db.ForeignKey("organizations.id"), nullable=False, index=True)
    level_id = db.Column(db.Integer, db.ForeignKey("levels.id"), nullable=False, index=True)

    # Denormalized game metadata for sorting/filtering
    game_date = db.Column(db.Date, nullable=False, index=True)
    game_time = db.Column(db.Time, nullable=False)

    # Performance stats
    goals = db.Column(db.Integer, default=0, nullable=False)
    assists = db.Column(db.Integer, default=0, nullable=False)
    points = db.Column(db.Integer, default=0, nullable=False)
    penalty_minutes = db.Column(db.Integer, default=0, nullable=False)

    # Tracking
    created_at = db.Column(db.DateTime, nullable=False, default=db.func.current_timestamp())

    __table_args__ = (
        db.UniqueConstraint("game_id", "human_id", name="_game_human_uc_skater"),
        db.Index("idx_game_stats_skater_human_date", "human_id", "game_date", postgresql_using="btree"),
        db.Index("idx_game_stats_skater_human_team_date", "human_id", "team_id", "game_date", postgresql_using="btree"),
    )


class GameStatsGoalie(db.Model):
    """Per-game goalie statistics.

    Stores individual game performance for goalies.
    Only records where goalie faced shots are saved.
    Optimized for queries like "show me top N games by save% for goalie X".
    """
    __tablename__ = "game_stats_goalie"

    id = db.Column(db.Integer, primary_key=True)
    game_id = db.Column(db.Integer, db.ForeignKey("games.id"), nullable=False, index=True)
    human_id = db.Column(db.Integer, db.ForeignKey("humans.id"), nullable=False, index=True)
    team_id = db.Column(db.Integer, db.ForeignKey("teams.id"), nullable=False, index=True)
    org_id = db.Column(db.Integer, db.ForeignKey("organizations.id"), nullable=False, index=True)
    level_id = db.Column(db.Integer, db.ForeignKey("levels.id"), nullable=False, index=True)

    # Denormalized game metadata for sorting/filtering
    game_date = db.Column(db.Date, nullable=False, index=True)
    game_time = db.Column(db.Time, nullable=False)

    # Performance stats
    goals_allowed = db.Column(db.Integer, default=0, nullable=False)
    shots_faced = db.Column(db.Integer, default=0, nullable=False)
    saves = db.Column(db.Integer, default=0, nullable=False)  # Computed: shots_faced - goals_allowed
    save_percentage = db.Column(db.Float, default=0.0, nullable=False)  # Computed: saves / shots_faced

    # Game result
    result = db.Column(db.String(3), nullable=True)  # W, L, T, OTL
    shutout = db.Column(db.Boolean, default=False, nullable=False)  # goals_allowed == 0

    # Tracking
    created_at = db.Column(db.DateTime, nullable=False, default=db.func.current_timestamp())

    __table_args__ = (
        db.UniqueConstraint("game_id", "human_id", "team_id", name="_game_human_uc_goalie"),
        db.Index("idx_game_stats_goalie_human_date", "human_id", "game_date", postgresql_using="btree"),
        db.Index("idx_game_stats_goalie_human_team_date", "human_id", "team_id", "game_date", postgresql_using="btree"),
    )


class DivisionTeamStandings(db.Model):
    """Team standings per division (wins, losses, ties, points, goals, champion flag).

    Aggregated nightly from completed games. One row per (division_id, team_id).
    Supports queries like:
    - "which team won most games in Adult 4B this season?"
    - "show me Good Guys standings history across all seasons"
    - "who was champion of division X?"
    """
    __tablename__ = "division_team_standings"

    id = db.Column(db.Integer, primary_key=True)
    division_id = db.Column(db.Integer, db.ForeignKey("divisions.id"), nullable=False, index=True)
    team_id = db.Column(db.Integer, db.ForeignKey("teams.id"), nullable=False, index=True)

    # Record
    games_played = db.Column(db.Integer, default=0, nullable=False)
    wins = db.Column(db.Integer, default=0, nullable=False)
    losses = db.Column(db.Integer, default=0, nullable=False)
    ties = db.Column(db.Integer, default=0, nullable=False)
    ot_wins = db.Column(db.Integer, default=0, nullable=False)   # Won in OT/SO
    ot_losses = db.Column(db.Integer, default=0, nullable=False) # Lost in OT/SO

    # Standings points (2 for win, 1 for OT loss/tie, 0 for loss — configurable)
    points = db.Column(db.Integer, default=0, nullable=False)

    # Goals
    goals_for = db.Column(db.Integer, default=0, nullable=False)
    goals_against = db.Column(db.Integer, default=0, nullable=False)
    goal_differential = db.Column(db.Integer, default=0, nullable=False)

    # Rank within division (1 = first place)
    rank = db.Column(db.Integer, nullable=True)

    # Champion flag
    is_champion = db.Column(db.Boolean, default=False, nullable=False)

    # Tracking
    updated_at = db.Column(db.DateTime, nullable=False, default=db.func.current_timestamp(),
                           onupdate=db.func.current_timestamp())

    __table_args__ = (
        db.UniqueConstraint("division_id", "team_id", name="uq_division_team_standings"),
        db.Index("idx_div_team_standings_div", "division_id"),
        db.Index("idx_div_team_standings_team", "team_id"),
    )
