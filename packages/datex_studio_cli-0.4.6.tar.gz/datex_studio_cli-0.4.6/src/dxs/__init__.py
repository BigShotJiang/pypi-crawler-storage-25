"""Datex Studio CLI - Command-line interface for Datex Studio platform."""

__version__ = "0.4.6"
__app_name__ = "dxs"
