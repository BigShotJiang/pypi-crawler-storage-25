"""Shared CLI context object and pass decorator.

Defined in a standalone module so that command modules can import DxsContext
and pass_context without triggering the circular dependency that would arise
from importing the full cli module (which calls register_commands() at load
time and therefore imports every command module).
"""

from typing import Any

import click

from dxs.core.output import OutputFormat, format_error, format_output
from dxs.utils.errors import DxsError


class DxsContext:
    """Shared context passed to all commands."""

    def __init__(self) -> None:
        self.output_format: OutputFormat = OutputFormat.YAML
        self.verbose: bool = False
        self.quiet: bool = False
        self.concise: bool = True  # Concise output is default
        self.flat_fv: bool = (
            True  # Flatten Dynamics FormattedValue siblings (matches concise default)
        )
        self.org: str | None = None
        self.env: str | None = None
        self.branch: int | None = None
        self.repo: int | None = None
        self.save_path: str | None = None
        self.force_overwrite: bool = False
        self.explicit_output_format: bool = False
        self.no_update_check: bool = False

    def output(self, data: Any, include_metadata: bool = True) -> None:
        """Output data in the configured format.

        Args:
            data: Data to output.
            include_metadata: Include timestamp and version metadata.
        """
        from dxs.core.output.formatter import detect_format_from_extension

        # Determine format: --output flag > file extension > default
        if self.save_path and not self.explicit_output_format:
            output_format = detect_format_from_extension(self.save_path, self.output_format)
        else:
            output_format = self.output_format

        formatted = format_output(
            data,
            output_format,
            include_metadata,
            self.concise,
            flatten_formatted_values=self.flat_fv,
        )

        # Save to file if requested (suppresses stdout)
        if self.save_path:
            self._save_to_file(formatted)
            return

        click.echo(formatted)

    def _save_to_file(self, content: str) -> None:
        """Save content to file with overwrite protection.

        Args:
            content: Formatted content to save.

        Raises:
            ValidationError: If file exists and force_overwrite is False.
            DxsError: If file write fails.
            RestrictedModeError: If restricted mode is enabled.
        """
        from pathlib import Path

        from dxs.utils.config import is_restricted_mode
        from dxs.utils.errors import RestrictedModeError, ValidationError

        # Block file saving in restricted mode
        if is_restricted_mode():
            raise RestrictedModeError(
                command_name="--save option",
                reason="writes files to the filesystem",
            )

        assert self.save_path is not None  # Caller checks this
        path = Path(self.save_path)

        if path.exists() and not self.force_overwrite:
            raise ValidationError(
                message=f"File '{self.save_path}' already exists",
                code="DXS-FILE-001",
                suggestions=[
                    "Use --force flag to overwrite the file",
                    "Specify a different filename with --save",
                ],
            )

        path.parent.mkdir(parents=True, exist_ok=True)

        try:
            path.write_text(content, encoding="utf-8")
            self.debug(f"Output saved to: {self.save_path}")
        except OSError as e:
            raise DxsError(
                code="DXS-FILE-002",
                message=f"Failed to write file '{self.save_path}': {e}",
            ) from e

    def output_error(self, error: DxsError | Exception) -> None:
        """Output an error in the configured format.

        Args:
            error: Error to output.
        """
        formatted = format_error(error, self.output_format)
        click.echo(formatted, err=True)

    def log(self, message: str) -> None:
        """Log a message (respects quiet flag).

        Args:
            message: Message to log.
        """
        if not self.quiet:
            click.echo(message, err=True)

    def debug(self, message: str) -> None:
        """Log a debug message (only in verbose mode).

        Args:
            message: Debug message to log.
        """
        if self.verbose:
            click.echo(f"[DEBUG] {message}", err=True)


# Create a pass decorator for the context
pass_context = click.make_pass_decorator(DxsContext, ensure=True)
