"""Report preview rendering via server-side SVG generation.

Generates SVG from report definitions, with optional conversion to PNG or PDF.
No headless browser required.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from dxs.utils.errors import ValidationError

# ── Unit conversion ──────────────────────────────────────────────────────


_UNIT_TO_INCHES: dict[str, float] = {
    "in": 1.0,
    "cm": 1.0 / 2.54,
    "mm": 1.0 / 25.4,
    "pt": 1.0 / 72.0,
}

_UNIT_RE = re.compile(r"^([\d.]+)\s*(in|cm|mm|pt)$", re.IGNORECASE)

# Standard CSS DPI for pixel conversions.
_CSS_DPI = 96


def _parse_dimension(value: str) -> float:
    """Parse a dimension string (e.g. '4in', '10cm') to inches."""
    m = _UNIT_RE.match(value.strip())
    if not m:
        raise ValueError(f"Cannot parse dimension: {value!r}")
    number = float(m.group(1))
    unit = m.group(2).lower()
    return number * _UNIT_TO_INCHES[unit]


def page_size_to_pixels(
    page_width: str,
    page_height: str,
    target_width: int | None = None,
) -> tuple[int, int]:
    """Convert report page dimensions to pixel viewport size.

    When *target_width* is given the viewport is scaled so the width
    equals that value and the height preserves the page aspect ratio.
    When omitted, both dimensions are derived from ``_CSS_DPI`` so the
    viewport matches the viewer's native rendering size.

    Args:
        page_width: Page width with unit (e.g. '4in').
        page_height: Page height with unit (e.g. '6in').
        target_width: Optional pixel width override for the output.

    Returns:
        Tuple of (width_px, height_px).
    """
    w_in = _parse_dimension(page_width)
    h_in = _parse_dimension(page_height)
    if w_in <= 0:
        raise ValueError(f"Page width must be positive, got {page_width!r}")
    if target_width is not None:
        aspect = h_in / w_in
        return target_width, round(target_width * aspect)
    return round(w_in * _CSS_DPI), round(h_in * _CSS_DPI)


# ── Main render pipeline ────────────────────────────────────────────────


def render_preview(
    report_data: dict[str, Any],
    output_path: str | Path,
    sample_data: dict[str, Any] | None = None,
    target_width: int | None = None,
    per_page: bool = False,
    timeout: int = 30,
    bounding_boxes: list[dict[str, str]] | None = None,
) -> dict[str, Any]:
    """Render a report to PNG or PDF via server-side SVG generation.

    Args:
        report_data: Parsed report definition (RDLX-JSON content).
        output_path: Path for the output file (.png or .pdf).
        sample_data: Optional sample data keyed by dataset name.
        target_width: Optional pixel width override for PNG output.
        per_page: Unused (kept for API compatibility).
        timeout: Unused (kept for API compatibility).
        bounding_boxes: Optional list of bounding box annotations to overlay.

    Returns:
        Dict with output metadata (file, output_path, pages, dimensions).

    Raises:
        ValidationError: If required dependencies are missing or rendering fails.
    """
    from dxs.report.svg_renderer import render_report_to_svg

    output_path = Path(output_path)
    suffix = output_path.suffix.lower()

    page = report_data.get("Page", {})
    page_width = page.get("PageWidth", "8.5in")
    page_height = page.get("PageHeight", "11in")
    vp_width, vp_height = page_size_to_pixels(page_width, page_height, target_width)

    if suffix == ".pdf":
        from dxs.report.svg_renderer import render_report_to_pdf

        render_report_to_pdf(report_data, output_path, sample_data)
    elif suffix == ".svg":
        svg_str = render_report_to_svg(report_data, sample_data, bounding_boxes=bounding_boxes)
        output_path.write_text(svg_str, encoding="utf-8")
    else:
        # PNG output — generate SVG then convert via Pillow + cairosvg or Pillow alone
        svg_str = render_report_to_svg(report_data, sample_data, bounding_boxes=bounding_boxes)
        _svg_to_png(svg_str, output_path, vp_width, vp_height)

    return {
        "file": str(output_path),
        "output_path": str(output_path.resolve()),
        "pages": 1,
        "width_px": vp_width,
        "height_px": vp_height,
    }


def _svg_to_png(
    svg_str: str,
    output_path: Path,
    width: int,
    height: int,
) -> None:
    """Convert an SVG string to PNG.

    Tries cairosvg first, falls back to Pillow-based rendering.
    """
    # Try cairosvg (best quality)
    try:
        import cairosvg  # type: ignore[import-untyped]
    except ImportError:
        cairosvg = None  # type: ignore[assignment]

    if cairosvg is not None:
        # Rasterize at 2x for sharper text/lines, then downscale.
        scale = 2
        png_bytes = cairosvg.svg2png(
            bytestring=svg_str.encode("utf-8"),
            output_width=width * scale,
            output_height=height * scale,
        )
        from io import BytesIO

        from PIL import Image as PILImage  # type: ignore[import-untyped]

        img = PILImage.open(BytesIO(png_bytes))
        img = img.resize((width, height), PILImage.LANCZOS)
        img.save(str(output_path))
        return

    # Fallback: svglib + reportlab
    try:
        from io import BytesIO

        from reportlab.graphics import renderPM  # type: ignore[import-untyped]
        from svglib.svglib import svg2rlg  # type: ignore[import-untyped,import-not-found]
    except ImportError as exc:
        raise ValidationError(
            message="No SVG-to-PNG converter available",
            code="DXS-RPT-046",
            suggestions=[
                "Install cairosvg: pip install cairosvg",
                "Or install svglib + reportlab: pip install svglib reportlab",
            ],
        ) from exc

    drawing = svg2rlg(BytesIO(svg_str.encode("utf-8")))
    if drawing is not None:
        renderPM.drawToFile(drawing, str(output_path), fmt="PNG")
        return

    raise ValidationError(
        message="SVG-to-PNG conversion failed: svglib could not parse the SVG",
        code="DXS-RPT-047",
        suggestions=[
            "The generated SVG may contain unsupported elements",
            "Try installing cairosvg for better SVG support: pip install cairosvg",
        ],
    )
