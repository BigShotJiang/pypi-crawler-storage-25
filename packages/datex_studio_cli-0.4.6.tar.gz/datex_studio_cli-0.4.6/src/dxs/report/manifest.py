"""Manifest model for report folder format.

A report folder contains a manifest.json (this model) alongside the report
RDLX-JSON file and any owned datasource JSON files. The manifest captures
the metadata and datasource bindings previously passed as CLI flags.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, Field, field_validator, model_validator

from dxs.core.designer.parsers import is_valid_js_identifier

MANIFEST_FILENAME = "manifest.json"


class ManifestDatasource(BaseModel):
    """A datasource entry in the manifest.

    - ``owned``: file path to a local datasource JSON config (from dxs datasource generate).
    - ``external``: reference name of a standalone datasource on the branch.
    """

    file: str | None = None
    ref: str | None = None
    alias: str
    type: Literal["owned", "external"]

    # External DS metadata — populated from download roundtrip or API lookup.
    configOutParameters: list[dict[str, Any]] | None = None
    datasourceKeyDef: list[dict[str, Any]] | None = None
    dynamicOrderBys: list[dict[str, Any]] | None = None
    dynamicFilters: list[dict[str, Any]] | None = None
    datasourceMethodName: str | None = None

    @model_validator(mode="after")
    def _validate_type_fields(self) -> ManifestDatasource:
        if self.type == "owned" and not self.file:
            raise ValueError("owned datasource requires 'file' to be set")
        if self.type == "external" and not self.ref:
            raise ValueError("external datasource requires 'ref' to be set")
        return self


class ManifestParam(BaseModel):
    """A report input parameter entry in the manifest."""

    name: str
    type: str
    required: bool = True


class ManifestDatasourceParam(BaseModel):
    """A datasource parameter binding entry in the manifest."""

    key: str
    expression: str
    alias: str | None = None
    type: str | None = None
    required: bool | None = None


class Manifest(BaseModel):
    """Report folder manifest — describes a report and its dependencies."""

    name: str
    referenceName: str
    description: str | None = None
    reportType: str = "CPL"
    accessModifier: str = "public"
    report: str
    datasources: list[ManifestDatasource] = Field(default_factory=list)
    params: list[ManifestParam] = Field(default_factory=list)
    datasourceParams: list[ManifestDatasourceParam] = Field(default_factory=list)

    @field_validator("referenceName")
    @classmethod
    def _validate_reference_name(cls, v: str) -> str:
        if not is_valid_js_identifier(v):
            raise ValueError(
                f"referenceName '{v}' is not a valid JavaScript identifier. "
                "Use letters, digits, underscores, or $ (no hyphens, dots, or spaces). "
                "Example: 'SrsBol' or 'srs_bol'"
            )
        return v


def save_manifest(manifest: Manifest, folder: Path) -> None:
    """Write manifest.json to folder.

    Uses ``model_dump(mode="json", exclude_defaults=True)`` so that fields
    with default values (empty lists, None, etc.) are omitted from the file.

    Writes to a temporary file first, then renames atomically to prevent
    corruption if the process crashes mid-write.

    Args:
        manifest: The manifest to serialize.
        folder:   Directory to write ``manifest.json`` into.
    """
    data = manifest.model_dump(mode="json", exclude_defaults=True)
    content = json.dumps(data, indent=2) + "\n"
    target = folder / MANIFEST_FILENAME
    tmp = target.with_suffix(".tmp")
    tmp.write_text(content, encoding="utf-8")
    tmp.replace(target)


def load_manifest(folder: Path) -> Manifest:
    """Read manifest.json from folder and return a Manifest instance.

    Args:
        folder: Directory containing ``manifest.json``.

    Raises:
        FileNotFoundError: If ``manifest.json`` does not exist in the folder.
    """
    path = folder / MANIFEST_FILENAME
    if not path.exists():
        raise FileNotFoundError(f"No {MANIFEST_FILENAME} found in {folder}")
    data = json.loads(path.read_text(encoding="utf-8"))
    return Manifest.model_validate(data)
