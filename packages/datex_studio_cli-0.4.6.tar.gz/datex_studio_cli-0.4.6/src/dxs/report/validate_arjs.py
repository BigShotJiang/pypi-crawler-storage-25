"""Report validation via ActiveReportsJS in a headless browser.

Uses agent-browser to load an ARJS viewer page, run the report through
the ARJS rendering engine, and capture errors/warnings from the ARJS
errorHandler and browser console.
"""

from __future__ import annotations

import json
from typing import Any

from dxs.report.preview_arjs import (
    PreviewServer,
    _ab_exec,
    _check_agent_browser,
    _check_frontend_deps,
    _find_free_port,
    _get_frontend_dir,
    _parse_ab_output,
)
from dxs.utils.errors import ValidationError


def _run_validation(
    ab_path: str,
    url: str,
    timeout: int,
) -> dict[str, Any]:
    """Execute agent-browser commands to validate the report.

    Opens the validation page, waits for completion, reads the
    diagnostics JSON from a data attribute, and returns it.

    Returns:
        Parsed diagnostics dict.

    Raises:
        ValidationError: If agent-browser fails or diagnostics can't be parsed.
    """
    session = f"dxs-validate-{_find_free_port()}"

    try:
        # 1. Open the validation page
        _ab_exec(ab_path, ["open", url], timeout=15, session=session)

        # 2. Wait for validation to complete
        _ab_exec(
            ab_path,
            ["wait", "[data-validate-complete]"],
            timeout=timeout,
            session=session,
        )

        # 3. Read diagnostics JSON from data attribute
        result = _ab_exec(
            ab_path,
            ["get", "attr", "body", "data-diagnostics"],
            timeout=10,
            session=session,
        )
    finally:
        # 4. Always close the browser session
        try:
            _ab_exec(ab_path, ["close"], timeout=10, session=session)
        except Exception:
            pass  # best-effort cleanup

    raw = _parse_ab_output(result.stdout).strip("\"'")
    try:
        return json.loads(raw)  # type: ignore[no-any-return]
    except (json.JSONDecodeError, TypeError) as exc:
        raise ValidationError(
            message=f"Failed to parse ARJS validation diagnostics: {raw[:200]}",
            code="DXS-RPT-070",
            suggestions=[
                "The report may have caused the ARJS page to crash",
                "Try running 'dxs report validate <file>' for static checks",
            ],
        ) from exc


def validate_report_arjs(
    report_data: dict[str, Any],
    sample_data: dict[str, Any] | None = None,
    timeout: int = 30,
) -> dict[str, Any]:
    """Validate a report via ActiveReportsJS in a headless browser.

    Loads the report through the ARJS rendering engine and captures
    errors/warnings from the ARJS errorHandler and browser console.

    Args:
        report_data: Parsed report definition (RDLX-JSON content).
        sample_data: Optional sample data keyed by dataset name.
        timeout: Seconds to wait for ARJS rendering (default 30).

    Returns:
        Dict with keys: valid, page_count, errors, warnings, info.

    Raises:
        ValidationError: If prerequisites are missing or validation fails.
    """
    ab_path = _check_agent_browser()
    frontend_dir = _get_frontend_dir()
    _check_frontend_deps(frontend_dir)

    # Prepare JSON payloads
    report_json = json.dumps(report_data)
    data_json = json.dumps(sample_data) if sample_data else "null"

    # Start server serving the validation HTML page
    server = PreviewServer(
        serve_dir=frontend_dir,
        report_json=report_json,
        data_json=data_json,
        html_page="report-validate.html",
    )
    server.start()

    try:
        diagnostics = _run_validation(
            ab_path=ab_path,
            url=server.url,
            timeout=timeout,
        )
    finally:
        server.stop()

    # Categorize items by severity
    items = diagnostics.get("items", [])
    errors = [i for i in items if i.get("severity") == "error"]
    warnings = [i for i in items if i.get("severity") == "warn"]
    info = [i for i in items if i.get("severity") not in ("error", "warn")]

    return {
        "valid": len(errors) == 0,
        "page_count": diagnostics.get("pageCount", 0),
        "errors": errors,
        "warnings": warnings,
        "info": info,
    }
