"""Datex Studio report wrapper format translation.

Translates between local RDL (RDLX-JSON) format and the Datex Studio
report configuration wrapper format.

The Datex Studio format wraps the RDL definition inside a larger envelope:
{
    "datasourceConfigs": [...],
    "report": {
        "definition": { <RDL content> },
        "id": "reference_name",
        "displayName": "Display Name"
    },
    "reportType": "CPL",
    "configurationTypeId": 15,
    ...
}
"""

from __future__ import annotations

import re
from typing import Any


def _sanitize_reference_name(name: str) -> str:
    """Convert a display name to a valid reference name.

    Args:
        name: Display name to sanitize.

    Returns:
        Snake_case reference name.
    """
    # Replace non-alphanumeric with underscores, collapse multiples, strip edges
    ref = re.sub(r"[^a-zA-Z0-9]+", "_", name.strip())
    ref = ref.strip("_").lower()
    return ref


def rdl_to_datex_wrapper(
    rdl_definition: dict[str, Any],
    report_name: str,
    reference_name: str | None = None,
    description: str | None = None,
    report_type: str = "CPL",
    datasource_configs: list[dict[str, Any]] | None = None,
    in_params: list[dict[str, Any]] | None = None,
    datasources: list[dict[str, Any]] | None = None,
    access_modifier: str = "public",
) -> dict[str, Any]:
    """Wrap a local RDL definition into Datex Studio report format.

    Args:
        rdl_definition: The RDL JSON content (what goes in report.definition).
        report_name: Display name for the report.
        reference_name: Reference name (defaults to sanitized report_name).
        description: Report description.
        report_type: Report type code (default: CPL).
        datasource_configs: Optional datasource configuration mappings.
        in_params: Optional input parameters.
        datasources: Optional list of owned datasource configs to embed in the wrapper.
        access_modifier: Access modifier for the report (default: "public").

    Returns:
        Complete Datex Studio report wrapper dict.
    """
    if reference_name is None:
        reference_name = _sanitize_reference_name(report_name)

    wrapper: dict[str, Any] = {
        "datasourceConfigs": datasource_configs or [],
        "report": {
            "definition": rdl_definition,
            "id": reference_name,
            "displayName": report_name,
        },
        "reportType": report_type,
        "configurationTypeId": 15,
        "id": None,
        "referenceName": reference_name,
        "title": report_name,
        "description": description or report_name,
        "inParams": in_params or [],
        "outParams": None,
        "vars": None,
        "events": None,
        "accessModifier": access_modifier,
        "datasources": datasources if datasources else None,
    }

    return wrapper
