"""Folder-based report format: extract a wrapper dict to a folder on disk.

A report folder contains:
- ``report.rdlx-json``  — the RDLX report definition
- ``<referenceName>.json``  — one file per owned datasource
- ``manifest.json``  — metadata and datasource bindings (see :mod:`dxs.report.manifest`)
"""

from __future__ import annotations

import json
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from dxs.core.designer.parsers import is_valid_js_identifier
from dxs.report.datasource_binding import (
    VALID_DS_TYPES,
    build_datasource_config,
    build_owned_datasource_reference,
    ds_method_name,
)
from dxs.report.manifest import (
    Manifest,
    ManifestDatasource,
    ManifestDatasourceParam,
    ManifestParam,
    load_manifest,
    save_manifest,
)
from dxs.report.wrapper import rdl_to_datex_wrapper

REPORT_FILENAME = "report.rdlx-json"


def _write_json(path: Path, data: dict[str, Any]) -> None:
    """Write *data* as indented JSON to *path* with a trailing newline."""
    path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")


def extract_wrapper_to_folder(wrapper: dict[str, Any], folder: Path) -> None:
    """Extract a Datex Studio report wrapper dict into a folder.

    Creates *folder* (raises :exc:`FileExistsError` if it already exists),
    writes the RDLX-JSON report definition, each owned datasource config, and a
    ``manifest.json`` capturing all metadata and datasource bindings.

    Args:
        wrapper: The report wrapper dict as returned by ``dxs report get``.
        folder:  Destination directory to create (must not already exist).

    Raises:
        FileExistsError: If *folder* already exists.
    """
    if folder.exists():
        raise FileExistsError(f"Folder already exists: {folder}")
    folder.mkdir(parents=True)

    # 1. Write report definition
    _write_json(folder / REPORT_FILENAME, wrapper["report"]["definition"])

    # 2. Build a lookup of owned datasource configs keyed by referenceName
    owned_by_name: dict[str, dict[str, Any]] = {
        ds["referenceName"]: ds for ds in wrapper.get("datasources", [])
    }

    # 3. Write each owned datasource config to its own file
    datasource_configs: list[dict[str, Any]] = wrapper.get("datasourceConfigs", [])
    resolved_folder = folder.resolve()
    for entry in datasource_configs:
        cfg = entry["datasourceConfig"]
        if cfg.get("isOwned"):
            config_id: str = cfg["configId"]
            dest = (folder / f"{config_id}.json").resolve()
            if not dest.is_relative_to(resolved_folder):
                raise ValueError(f"Datasource configId escapes folder: {config_id!r}")
            if config_id in owned_by_name:
                _write_json(folder / f"{config_id}.json", owned_by_name[config_id])

    # 4. Build the manifest
    multiple_ds = len(datasource_configs) > 1

    manifest_datasources: list[ManifestDatasource] = []
    manifest_ds_params: list[ManifestDatasourceParam] = []

    for entry in datasource_configs:
        cfg = entry["datasourceConfig"]
        alias: str = entry["alias"]
        config_id = cfg["configId"]
        module_id: str | None = cfg.get("moduleId")

        if cfg.get("isOwned"):
            manifest_datasources.append(
                ManifestDatasource(
                    file=f"{config_id}.json",
                    alias=alias,
                    type="owned",
                )
            )
        else:
            ref = f"{module_id}/{config_id}" if module_id else config_id
            manifest_datasources.append(
                ManifestDatasource(
                    ref=ref,
                    alias=alias,
                    type="external",
                    configOutParameters=cfg.get("configOutParameters"),
                    datasourceKeyDef=cfg.get("datasourceKeyDef"),
                    dynamicOrderBys=cfg.get("dynamicOrderBys"),
                    dynamicFilters=cfg.get("dynamicFilters"),
                    datasourceMethodName=entry.get("datasourceMethodName"),
                )
            )

        for param_mapping in cfg.get("configParameters", []):
            param_info = param_mapping.get("parameter", {})
            manifest_ds_params.append(
                ManifestDatasourceParam(
                    key=param_info["id"],
                    expression=param_mapping["value"],
                    alias=alias if multiple_ds else None,
                    type=param_info.get("type"),
                    required=param_info.get("required"),
                )
            )

    manifest_params: list[ManifestParam] = [
        ManifestParam(
            name=p["id"],
            type=p.get("type", "string"),
            required=p.get("required", True),
        )
        for p in wrapper.get("inParams", [])
    ]

    manifest = Manifest(
        name=wrapper["title"],
        referenceName=wrapper["referenceName"],
        description=wrapper.get("description"),
        reportType=wrapper.get("reportType", "CPL"),
        accessModifier=wrapper.get("accessModifier", "public"),
        report=REPORT_FILENAME,
        datasources=manifest_datasources,
        params=manifest_params,
        datasourceParams=manifest_ds_params,
    )

    save_manifest(manifest, folder)


@dataclass
class FolderValidation:
    """Result of validating a report folder before assembly."""

    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return not self.errors


def validate_folder(folder: Path) -> FolderValidation:
    """Validate a report folder for consistency before assembly.

    Checks file existence, manifest consistency, alias uniqueness,
    and datasource param correctness. Returns a :class:`FolderValidation`
    containing errors (fatal) and warnings (non-fatal).
    """
    result = FolderValidation()

    # 1. Load manifest
    try:
        manifest = load_manifest(folder)
    except FileNotFoundError:
        result.errors.append("manifest.json not found in folder")
        return result
    except Exception as exc:
        result.errors.append(f"Invalid manifest.json: {exc}")
        return result

    # 2. Report file exists
    rdlx_path = folder / manifest.report
    if not rdlx_path.exists():
        result.errors.append(f"Report file not found: {manifest.report}")

    # 3. Owned datasource files exist and are valid
    all_ds_in_params: dict[str, set[str]] = {}  # alias -> set of inParam ids

    for ds in manifest.datasources:
        if ds.type == "owned" and ds.file:
            ds_path = folder / ds.file
            if not ds_path.exists():
                result.errors.append(f"Owned datasource file not found: {ds.file}")
                continue

            try:
                ds_config = json.loads(ds_path.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError) as exc:
                result.errors.append(f"Cannot read datasource file {ds.file}: {exc}")
                continue

            # DS must have referenceName
            ds_ref_name = ds_config.get("referenceName")
            if not ds_ref_name:
                result.errors.append(f"Datasource file {ds.file} is missing 'referenceName'")

            # DS referenceName must match alias
            if ds_ref_name and ds_ref_name != ds.alias:
                result.errors.append(
                    f"Datasource {ds.file} referenceName '{ds_ref_name}' "
                    f"does not match manifest alias '{ds.alias}'"
                )

            # DS type must be valid
            ds_type = ds_config.get("type")
            if ds_type not in VALID_DS_TYPES:
                result.errors.append(
                    f"Datasource {ds.file} has invalid type '{ds_type}' "
                    f"(expected one of: {', '.join(sorted(VALID_DS_TYPES))})"
                )

            # Collect inParam ids for ds-param validation
            in_params = ds_config.get("inParams") or []
            all_ds_in_params[ds.alias] = {
                p["id"] for p in in_params if isinstance(p, dict) and "id" in p
            }

    # 4. No duplicate aliases
    aliases = [ds.alias for ds in manifest.datasources]
    seen: set[str] = set()
    for alias in aliases:
        if alias in seen:
            result.errors.append(f"Duplicate datasource alias: '{alias}'")
        seen.add(alias)

    # 4b. Aliases are valid JS identifiers
    for alias in aliases:
        if not is_valid_js_identifier(alias):
            result.errors.append(f"Datasource alias '{alias}' is not a valid JavaScript identifier")

    all_aliases = set(aliases)

    # 5. Param names are valid identifiers
    for p in manifest.params:
        if not is_valid_js_identifier(p.name):
            result.errors.append(f"Parameter name '{p.name}' is not a valid JavaScript identifier")

    # 6. DatasourceParam alias references exist
    for dp in manifest.datasourceParams:
        if dp.alias is not None and dp.alias not in all_aliases:
            result.errors.append(f"datasourceParams entry references unknown alias '{dp.alias}'")

    # 7. DatasourceParam keys correspond to actual inParams in at least one DS
    if all_ds_in_params:
        all_in_param_ids = set()
        for ids in all_ds_in_params.values():
            all_in_param_ids.update(ids)

        for dp in manifest.datasourceParams:
            if dp.alias is not None:
                # Scoped: check against the specific DS
                target_params = all_ds_in_params.get(dp.alias, set())
                if target_params and dp.key not in target_params:
                    result.warnings.append(
                        f"datasourceParam key '{dp.key}' not found in "
                        f"inParams of datasource '{dp.alias}'"
                    )
            else:
                # Global: check against all owned DS
                if all_in_param_ids and dp.key not in all_in_param_ids:
                    result.warnings.append(
                        f"datasourceParam key '{dp.key}' not found in "
                        f"inParams of any owned datasource"
                    )

    # 8. Warnings: check DataSet references in RDLX-JSON
    if rdlx_path.exists():
        try:
            rdl = json.loads(rdlx_path.read_text(encoding="utf-8"))
            datasets = rdl.get("DataSets") or []
            ds_names_in_rdl = {ds.get("Name") for ds in datasets if isinstance(ds, dict)}

            # DataSet references alias not in manifest
            for ds_name in ds_names_in_rdl:
                if ds_name and ds_name not in all_aliases:
                    result.warnings.append(
                        f"DataSet '{ds_name}' in RDLX-JSON references alias "
                        f"not found in manifest datasources"
                    )

            # Owned DS not referenced by any DataSet
            for ds in manifest.datasources:
                if ds.type == "owned" and ds.alias not in ds_names_in_rdl:
                    result.warnings.append(
                        f"Owned datasource '{ds.alias}' is not referenced "
                        f"by any DataSet in RDLX-JSON"
                    )
        except (json.JSONDecodeError, OSError):
            pass  # RDLX-JSON read errors already caught elsewhere

    return result


def assemble_folder_to_wrapper(folder: Path) -> dict[str, Any]:
    """Assemble a report folder back into a Datex Studio wrapper dict.

    This is the reverse of :func:`extract_wrapper_to_folder`. It reads the
    ``manifest.json``, RDLX-JSON report definition, and any owned datasource
    JSON files, then builds the complete wrapper dict ready for upload.

    Args:
        folder: Directory containing ``manifest.json`` and associated files.

    Returns:
        The wrapper dict with ``report``, ``datasourceConfigs``, ``datasources``,
        ``inParams``, and all other required fields populated.

    Raises:
        FileNotFoundError: If ``manifest.json``, the RDLX-JSON file, or any
            owned datasource file referenced by the manifest is missing.
        ValueError: If folder validation finds consistency errors.
    """
    # 0. Validate folder consistency
    validation = validate_folder(folder)
    for warning in validation.warnings:
        print(f"Warning: {warning}", file=sys.stderr)
    if not validation.ok:
        raise ValueError(
            "Folder validation failed:\n" + "\n".join(f"  - {e}" for e in validation.errors)
        )

    # 1. Load manifest (raises FileNotFoundError if missing)
    manifest = load_manifest(folder)

    # 2. Read RDLX-JSON report definition
    rdlx_path = folder / manifest.report
    if not rdlx_path.exists():
        raise FileNotFoundError(f"Report file not found: {rdlx_path.name}")
    rdl_definition: dict[str, Any] = json.loads(rdlx_path.read_text(encoding="utf-8"))

    # 3. Build ds-params lookup: global (alias=None) and alias-specific
    global_ds_params: list[tuple[str, str]] = []  # (key, expression)
    alias_ds_params: dict[str, list[tuple[str, str]]] = {}
    for dp in manifest.datasourceParams:
        if dp.alias is None:
            global_ds_params.append((dp.key, dp.expression))
        else:
            alias_ds_params.setdefault(dp.alias, []).append((dp.key, dp.expression))

    # 4. Build datasourceConfigs and collect owned DS configs
    datasource_configs: list[dict[str, Any]] = []
    owned_ds_configs: list[dict[str, Any]] = []

    for ds_entry in manifest.datasources:
        # Collect ds params for this datasource: global + alias-specific
        ds_params_for_entry = global_ds_params + alias_ds_params.get(ds_entry.alias, [])

        if ds_entry.type == "owned":
            # Read the owned DS config file
            assert ds_entry.file is not None  # validated by ManifestDatasource
            ds_file_path = folder / ds_entry.file
            if not ds_file_path.exists():
                raise FileNotFoundError(f"Datasource file not found: {ds_entry.file}")
            ds_config: dict[str, Any] = json.loads(ds_file_path.read_text(encoding="utf-8"))
            owned_ds_configs.append(ds_config)

            # Resolve param types from inParams
            in_params_list: list[dict[str, Any]] = ds_config.get("inParams") or []
            param_types = {p["id"]: p.get("type", "string") for p in in_params_list if "id" in p}
            param_required = {p["id"]: p.get("required") for p in in_params_list if "id" in p}

            # Include ALL DS inParams in configParameters (bound + unbound).
            # Bound params get their expression from datasourceParams.
            # Unbound params are included with no value so the platform sees the
            # full contract (e.g. optional params from --param-filter).
            bound_keys = {key for key, _ in ds_params_for_entry}
            all_ds_params = list(ds_params_for_entry)
            for p in in_params_list:
                pid = p.get("id")
                if pid and pid not in bound_keys:
                    all_ds_params.append((pid, ""))

            datasource_configs.append(
                build_owned_datasource_reference(
                    config_id=ds_entry.alias,
                    alias=ds_entry.alias,
                    config_out_parameters=ds_config.get("outParams") or [],
                    datasource_params=all_ds_params,
                    param_types=param_types,
                    param_required=param_required,
                    key_def=ds_config.get("keyDef"),
                    dynamic_order_bys=ds_config.get("dynamicOrderBys"),
                    dynamic_filters=ds_config.get("dynamicFilters"),
                    datasource_method_name=ds_method_name(ds_config),
                )
            )

        else:
            # External datasource
            assert ds_entry.ref is not None  # validated by ManifestDatasource
            ref = ds_entry.ref
            if "/" in ref:
                module_id_str, config_id = ref.split("/", 1)
                module_id: str | None = module_id_str
            else:
                config_id = ref
                module_id = None

            # Build param type lookup from ManifestDatasourceParam metadata
            ds_param_meta: dict[str, ManifestDatasourceParam] = {}
            for dp in manifest.datasourceParams:
                if dp.alias == ds_entry.alias or dp.alias is None:
                    ds_param_meta[dp.key] = dp

            param_types_ext = {
                key: ds_param_meta[key].type or "string" if key in ds_param_meta else "string"
                for key, _ in ds_params_for_entry
            }
            param_required_ext: dict[str, bool | None] = {
                key: ds_param_meta[key].required if key in ds_param_meta else None
                for key, _ in ds_params_for_entry
            }

            datasource_configs.append(
                build_datasource_config(
                    config_id=config_id,
                    module_id=module_id,
                    alias=ds_entry.alias,
                    config_out_parameters=ds_entry.configOutParameters
                    if ds_entry.configOutParameters is not None
                    else [],
                    datasource_params=ds_params_for_entry,
                    param_types=param_types_ext,
                    param_required=param_required_ext,
                    key_def=ds_entry.datasourceKeyDef,
                    dynamic_order_bys=ds_entry.dynamicOrderBys,
                    dynamic_filters=ds_entry.dynamicFilters,
                    datasource_method_name=ds_entry.datasourceMethodName or "get",
                )
            )

    # 5. Build inParams
    in_params = [{"id": p.name, "type": p.type, "required": p.required} for p in manifest.params]

    # 6. Build wrapper via shared builder
    return rdl_to_datex_wrapper(
        rdl_definition=rdl_definition,
        report_name=manifest.name,
        reference_name=manifest.referenceName,
        description=manifest.description,
        report_type=manifest.reportType,
        datasource_configs=datasource_configs if datasource_configs else None,
        in_params=in_params if in_params else None,
        datasources=owned_ds_configs if owned_ds_configs else None,
        access_modifier=manifest.accessModifier,
    )
