"""Report preview rendering via ActiveReportsJS in a headless browser.

Uses agent-browser to load an ARJS viewer page, wait for render completion,
and screenshot the output as a PNG image.
"""

from __future__ import annotations

import json
import shutil
import subprocess
import tempfile
import threading
from dataclasses import dataclass
from http.server import HTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from typing import Any

from dxs.report.preview import page_size_to_pixels
from dxs.utils.errors import ValidationError

# Safety cap to prevent absurd viewport sizes from malformed reports.
_MAX_PAGE_COUNT = 100


# ── Preview HTTP server ──────────────────────────────────────────────────


class _PreviewHandler(SimpleHTTPRequestHandler):
    """HTTP handler that serves ARJS assets + report/data API endpoints."""

    report_json_data: str = "{}"
    data_json_data: str = "null"
    html_page: str = "report-preview.html"

    def do_GET(self) -> None:
        if self.path == "/api/report":
            self._json_response(self.report_json_data)
        elif self.path == "/api/data":
            self._json_response(self.data_json_data)
        elif self.path == "/":
            # Serve the configured HTML page
            self._serve_file(self.html_page, "text/html")
        else:
            super().do_GET()

    def _json_response(self, body: str) -> None:
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        encoded = body.encode("utf-8")
        self.send_header("Content-Length", str(len(encoded)))
        self.end_headers()
        self.wfile.write(encoded)

    def _serve_file(self, filename: str, content_type: str) -> None:
        """Serve a file from the public/ subdirectory."""
        path = Path(self.directory) / "public" / filename  # type: ignore[attr-defined]
        if path.exists():
            content = path.read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(content)))
            self.end_headers()
            self.wfile.write(content)
        else:
            self.send_error(404, f"File not found: {filename}")

    def log_message(self, format: str, *args: Any) -> None:
        """Suppress default logging."""


def _find_free_port() -> int:
    """Find an available TCP port."""
    import socket

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]  # type: ignore[no-any-return]


class PreviewServer:
    """Lightweight HTTP server for ARJS report preview/validation.

    Serves the ARJS viewer HTML page, node_modules assets, and
    API endpoints for the report definition and sample data.
    """

    def __init__(
        self,
        serve_dir: str | Path,
        report_json: str,
        data_json: str = "null",
        html_page: str = "report-preview.html",
    ) -> None:
        self.port = _find_free_port()
        serve_dir_str = str(serve_dir)
        page = html_page

        # Create a handler subclass with the data baked in
        class Handler(_PreviewHandler):
            report_json_data = report_json
            data_json_data = data_json
            html_page = page

            def __init__(self, *args: Any, **kwargs: Any) -> None:
                kwargs["directory"] = serve_dir_str
                super().__init__(*args, **kwargs)

        self._server = HTTPServer(("127.0.0.1", self.port), Handler)
        self._thread: threading.Thread | None = None

    @property
    def url(self) -> str:
        return f"http://127.0.0.1:{self.port}"

    def start(self) -> None:
        """Start serving in a background thread."""
        self._thread = threading.Thread(target=self._server.serve_forever, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        """Shut down the server."""
        self._server.shutdown()
        if self._thread is not None:
            self._thread.join(timeout=5)


# ── Prerequisite checks ─────────────────────────────────────────────────


def _check_agent_browser() -> str:
    """Verify agent-browser is installed and return its path.

    Returns:
        Path to the agent-browser executable.

    Raises:
        ValidationError: If agent-browser is not found.
    """
    path = shutil.which("agent-browser")
    if path is None:
        raise ValidationError(
            message="agent-browser is not installed",
            code="DXS-RPT-040",
            suggestions=[
                "Install with: npm install -g @anthropic-ai/agent-browser",
                "Then run: agent-browser install",
            ],
        )
    return path


def _check_frontend_deps(frontend_dir: Path) -> None:
    """Verify frontend node_modules contain ARJS.

    Raises:
        ValidationError: If node_modules or ARJS package is missing.
    """
    arjs_dir = frontend_dir / "node_modules" / "@mescius" / "activereportsjs"
    if not arjs_dir.exists():
        raise ValidationError(
            message="ActiveReportsJS not found in frontend node_modules",
            code="DXS-RPT-041",
            suggestions=[
                f"Run: cd {frontend_dir} && npm install",
                "This installs the @mescius/activereportsjs package needed for preview rendering",
            ],
        )


# ── Main render pipeline ────────────────────────────────────────────────


def _get_frontend_dir() -> Path:
    """Get the frontend directory path."""
    return Path(__file__).resolve().parent.parent / "web" / "frontend"


def _get_public_dir() -> Path:
    """Get the frontend public directory path (where report-preview.html lives)."""
    return _get_frontend_dir() / "public"


@dataclass
class _AbResult:
    """Result of an agent-browser command execution."""

    returncode: int
    stdout: str
    stderr: str


def _ab_exec(
    ab_path: str,
    args: list[str],
    timeout: int,
    session: str = "dxs-preview",
) -> _AbResult:
    """Run a single agent-browser command.

    Stdout/stderr are redirected to temp files instead of pipes.
    On Windows, agent-browser spawns a long-lived browser that inherits
    file handles.  With pipes, communicate() blocks forever waiting for
    EOF because the browser holds the write-end open.  With temp files,
    subprocess.run() just calls proc.wait() (no EOF semantics), and we
    read the output from the files after the process exits.
    """
    cmd = [ab_path, "--session", session, *args]
    stdout_fd, stdout_name = tempfile.mkstemp(suffix=".ab-out")
    stderr_fd, stderr_name = tempfile.mkstemp(suffix=".ab-err")
    stdout_path = Path(stdout_name)
    stderr_path = Path(stderr_name)
    stdout_text = ""
    stderr_text = ""
    returncode = 1
    try:
        with (
            open(stdout_fd, "w", closefd=True) as out_f,
            open(stderr_fd, "w", closefd=True) as err_f,
        ):
            proc = subprocess.run(
                cmd,
                stdout=out_f,
                stderr=err_f,
                timeout=timeout,
            )
        returncode = proc.returncode
        # Process exited. Read output from temp files.
        stdout_text = stdout_path.read_text(encoding="utf-8", errors="replace")
        stderr_text = stderr_path.read_text(encoding="utf-8", errors="replace")
    except subprocess.TimeoutExpired as exc:
        raise ValidationError(
            message=f"agent-browser '{args[0]}' timed out after {timeout}s",
            code="DXS-RPT-043",
            suggestions=[
                "The report may be too complex or agent-browser may be hung",
                "Try increasing --timeout or simplifying the report",
            ],
        ) from exc
    finally:
        # Best-effort cleanup — browser may still hold the file handles
        for p in (stdout_path, stderr_path):
            try:
                p.unlink()
            except OSError:
                pass

    result = _AbResult(returncode=returncode, stdout=stdout_text, stderr=stderr_text)

    if result.returncode != 0:
        stderr_s = result.stderr.strip()
        stdout_s = result.stdout.strip()
        detail = stderr_s or stdout_s or f"exit code {result.returncode}"
        raise ValidationError(
            message=f"agent-browser '{args[0]}' failed: {detail}",
            code="DXS-RPT-042",
            suggestions=[
                "Ensure agent-browser is installed: agent-browser install",
                "Check that the report file is valid: dxs report validate <file>",
            ],
        )

    return result


def _parse_ab_output(stdout: str) -> str:
    """Extract the last non-empty line from agent-browser stdout."""
    lines = [line.strip() for line in stdout.strip().splitlines() if line.strip()]
    return lines[-1] if lines else ""


def _run_agent_browser(
    ab_path: str,
    url: str,
    output_path: Path,
    vp_width: int,
    vp_height: int,
    per_page: bool,
    timeout: int,
) -> dict[str, Any]:
    """Execute agent-browser commands to capture the rendered report.

    Each command is a separate CLI invocation sharing the same named session.
    The HTML page renders in continuous mode and removes watermarks via
    MutationObserver. This function orchestrates the capture.

    Returns:
        Dict with output metadata.

    Raises:
        ValidationError: If agent-browser commands fail.
    """
    session = f"dxs-preview-{_find_free_port()}"  # unique session name

    try:
        # 1. Open the page
        _ab_exec(ab_path, ["open", url], timeout=15, session=session)

        # 2. Wait for report to finish rendering (continuous mode, all pages)
        _ab_exec(
            ab_path,
            ["wait", "[data-render-complete]"],
            timeout=timeout,
            session=session,
        )

        # 3. Read page count from HTML
        result = _ab_exec(
            ab_path,
            ["get", "attr", "body", "data-page-count"],
            timeout=10,
            session=session,
        )
        raw_count = _parse_ab_output(result.stdout).strip("\"'")
        try:
            page_count = min(max(1, int(raw_count)), _MAX_PAGE_COUNT)
        except (ValueError, TypeError):
            page_count = 1

        # 4. Set viewport to full document height (all pages visible)
        _ab_exec(
            ab_path,
            ["set", "viewport", str(vp_width), str(vp_height * page_count)],
            timeout=10,
            session=session,
        )

        # 5. Check for render errors — ARJS displays errors in the viewer UI
        #    rather than throwing JS exceptions, so data-render-error won't
        #    be set. Read the viewer text to detect error messages.
        render_error: str | None = None
        try:
            err_result = _ab_exec(
                ab_path,
                ["get", "text", "#viewer-host"],
                timeout=10,
                session=session,
            )
            viewer_text = _parse_ab_output(err_result.stdout).strip()
            if viewer_text.startswith("Failed to decode report:"):
                # Extract just the error message (before "Show Details..." UI text)
                error_msg = viewer_text
                for sentinel in ("Show Details", "Dismiss", "Search"):
                    idx = error_msg.find(sentinel)
                    if idx != -1:
                        error_msg = error_msg[:idx].strip()
                render_error = error_msg
        except Exception:
            pass  # non-fatal — proceed with screenshot

        # 6. Take full-page screenshot (captures entire scrollable content)
        _ab_exec(
            ab_path,
            ["screenshot", "--full", str(output_path)],
            timeout=15,
            session=session,
        )
    finally:
        # 7. Always close the browser session
        try:
            _ab_exec(ab_path, ["close"], timeout=10, session=session)
        except Exception:
            pass  # best-effort cleanup

    if not output_path.exists():
        raise ValidationError(
            message=f"Screenshot file was not created: {output_path}",
            code="DXS-RPT-044",
            suggestions=[
                "agent-browser may have failed silently",
                "Try running with --verbose for more details",
            ],
        )

    result: dict[str, Any] = {
        "file": str(output_path),
        "output_path": str(output_path.resolve()),
        "pages": page_count,
        "width_px": vp_width,
        "height_px": vp_height * page_count,
    }
    if render_error:
        result["render_error"] = render_error
    return result


def render_preview_arjs(
    report_data: dict[str, Any],
    output_path: str | Path,
    sample_data: dict[str, Any] | None = None,
    target_width: int | None = None,
    per_page: bool = False,
    timeout: int = 30,
) -> dict[str, Any]:
    """Render a report to PNG via ActiveReportsJS in a headless browser.

    Requires agent-browser CLI and @mescius/activereportsjs npm package
    installed in the frontend directory.

    Args:
        report_data: Parsed report definition (RDLX-JSON content).
        output_path: Path for the output PNG file.
        sample_data: Optional sample data keyed by dataset name.
        target_width: Optional pixel width override. When omitted the
            viewport matches the ARJS viewer's native rendering at 96 DPI.
        per_page: If True, output separate PNGs per page.
        timeout: Seconds to wait for render completion.

    Returns:
        Dict with output metadata (file, output_path, pages, dimensions).

    Raises:
        ValidationError: If prerequisites are missing or rendering fails.
    """
    ab_path = _check_agent_browser()
    frontend_dir = _get_frontend_dir()
    _check_frontend_deps(frontend_dir)

    output_path = Path(output_path)

    # Match the viewport to the viewer's rendered page size so the
    # screenshot crops exactly to the page.
    page = report_data.get("Page", {})
    page_width = page.get("PageWidth", "8.5in")
    page_height = page.get("PageHeight", "11in")
    vp_width, vp_height = page_size_to_pixels(page_width, page_height, target_width)

    # Prepare JSON payloads
    report_json = json.dumps(report_data)
    data_json = json.dumps(sample_data) if sample_data else "null"

    # Start preview server — serve from frontend dir so node_modules are accessible
    server = PreviewServer(
        serve_dir=frontend_dir,
        report_json=report_json,
        data_json=data_json,
    )
    server.start()

    try:
        result = _run_agent_browser(
            ab_path=ab_path,
            url=server.url,
            output_path=output_path,
            vp_width=vp_width,
            vp_height=vp_height,
            per_page=per_page,
            timeout=timeout,
        )
    finally:
        server.stop()

    return result
