"""Datasource binding helpers for report upload.

Parses --use-datasource, --param, and --datasource-param CLI flags
and builds datasourceConfigs entries for the Datex Studio wrapper envelope.
"""

from __future__ import annotations

from typing import Any

import click

# Re-export — canonical home is core.designer.parsers
from dxs.core.designer.parsers import parse_param as parse_param  # noqa: F401

VALID_DS_TYPES: frozenset[str] = frozenset({"oDataQuery", "flows"})


def ds_method_name(ds_config: dict[str, Any]) -> str:
    """Return the ``datasourceMethodName`` for a datasource config.

    Returns ``"get"`` when the config is an OData query or has a ``getFlow``;
    returns ``"getList"`` otherwise (flow-based list datasource).
    """
    if ds_config.get("type") == "oDataQuery":
        return "get"
    if ds_config.get("getFlow"):
        return "get"
    return "getList"


def parse_use_datasource(value: str) -> tuple[str, str | None, str]:
    """Parse '--use-datasource' value into (config_id, module_id, alias).

    Formats:
        'ds_ref:alias'          -> config_id='ds_ref', module_id=None, alias='alias'
        'pkg/ds_ref:alias'      -> config_id='ds_ref', module_id='pkg', alias='alias'
    """
    if ":" not in value:
        raise click.UsageError(
            f"--use-datasource must be 'ref:alias' or 'pkg/ref:alias', got: {value!r}"
        )
    ref_part, alias = value.rsplit(":", 1)
    if "/" in ref_part:
        module_id, config_id = ref_part.split("/", 1)
    else:
        config_id = ref_part
        module_id = None
    return config_id, module_id, alias


def parse_datasource_param(value: str) -> tuple[str, str, str]:
    """Parse '[Alias.]ds_param=expr' -> (alias_or_empty, ds_param, expr).

    Formats:
        'ds_param=expr'           -> ('', 'ds_param', 'expr')
        'Alias.ds_param=expr'     -> ('Alias', 'ds_param', 'expr')
    """
    if "=" not in value:
        raise click.UsageError(
            f"--datasource-param must be 'ds_param=expression' or "
            f"'Alias.ds_param=expression', got: {value!r}"
        )
    key, expr = value.split("=", 1)
    if "." in key:
        alias_prefix, ds_param = key.split(".", 1)
        return alias_prefix, ds_param, expr
    return "", key, expr


def build_owned_datasource_reference(
    *,
    config_id: str,
    alias: str,
    config_out_parameters: list[dict[str, Any]],
    datasource_params: list[tuple[str, str]],
    param_types: dict[str, str],
    param_required: dict[str, bool | None] | None = None,
    key_def: list[dict[str, Any]] | None = None,
    dynamic_order_bys: list[dict[str, Any]] | None = None,
    dynamic_filters: list[dict[str, Any]] | None = None,
    datasource_method_name: str = "get",
) -> dict[str, Any]:
    """Build a datasourceConfigs[] entry for an owned (embedded) datasource.

    Same shape as build_datasource_config() but with isOwned=True and
    moduleId always None (owned datasources are local to the report).
    """
    config_parameters = [
        {
            "parameter": {
                "id": ds_param,
                "type": param_types.get(ds_param, "string"),
                "required": (param_required or {}).get(ds_param),
            },
            "value": expr,
        }
        for ds_param, expr in datasource_params
    ]
    return {
        "datasourceConfig": {
            "configId": config_id,
            "moduleId": None,
            "isOwned": True,
            "configOutParameters": config_out_parameters,
            "configParameters": config_parameters,
            "datasourceKeyDef": key_def or None,
            "dynamicOrderBys": dynamic_order_bys,
            "dynamicFilters": dynamic_filters,
        },
        "alias": alias,
        "datasourceMethodName": datasource_method_name,
    }


def build_datasource_config(
    *,
    config_id: str,
    module_id: str | None,
    alias: str,
    config_out_parameters: list[dict[str, Any]],
    datasource_params: list[tuple[str, str]],
    param_types: dict[str, str],
    param_required: dict[str, bool | None] | None = None,
    key_def: list[dict[str, Any]] | None = None,
    dynamic_order_bys: list[dict[str, Any]] | None = None,
    dynamic_filters: list[dict[str, Any]] | None = None,
    datasource_method_name: str = "get",
) -> dict[str, Any]:
    """Build a single datasourceConfigs[] entry for the report wrapper.

    Args:
        config_id: Datasource reference name (e.g. 'ds_shipment_bol').
        module_id: Package/module ID for cross-package refs, or None.
        alias: Alias used to reference this datasource in the report.
        config_out_parameters: Copied from the datasource's outParams directly.
        datasource_params: List of (param_name, expression) tuples.
        param_types: Maps param name -> type string (from datasource inParams).
        param_required: Maps param name -> required flag.
        key_def: Entity key definition from datasource, or None.
        dynamic_order_bys: Dynamic order-by definitions from datasource.
        dynamic_filters: Dynamic filter definitions from datasource.
        datasource_method_name: Method name ('get' or 'getList').

    Returns:
        Dict suitable for inclusion in wrapper['datasourceConfigs'].
    """
    config_parameters = [
        {
            "parameter": {
                "id": ds_param,
                "type": param_types.get(ds_param, "string"),
                "required": (param_required or {}).get(ds_param),
            },
            "value": expr,
        }
        for ds_param, expr in datasource_params
    ]
    return {
        "datasourceConfig": {
            "configId": config_id,
            "moduleId": module_id,
            "isOwned": None,
            "configOutParameters": config_out_parameters,
            "configParameters": config_parameters,
            "datasourceKeyDef": key_def or None,
            "dynamicOrderBys": dynamic_order_bys,
            "dynamicFilters": dynamic_filters,
        },
        "alias": alias,
        "datasourceMethodName": datasource_method_name,
    }
