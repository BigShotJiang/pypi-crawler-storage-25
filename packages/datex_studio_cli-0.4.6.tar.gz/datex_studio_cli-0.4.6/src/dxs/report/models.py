"""Pydantic models for RDL (RDLX-JSON) report definitions.

These models represent the RDLX-JSON RDL format used by Datex Studio.
The structure follows the RDLX-JSON specification with PascalCase field names.

Note: Internal class names use underscored prefixes (_Body, _ConnProps, etc.)
to avoid Pydantic field-name/type-name collisions when a PascalCase field name
matches a class name (e.g., field `Body` vs class `Body`). Public aliases are
provided for external use.
"""

from collections.abc import Iterator
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class PageSettings(BaseModel):
    """Page dimensions and margins."""

    PageWidth: str = "8.5in"
    PageHeight: str = "11in"
    TopMargin: str = "0.5in"
    BottomMargin: str = "0.5in"
    LeftMargin: str = "0.5in"
    RightMargin: str = "0.5in"
    Columns: int = 1
    ColumnSpacing: str = "0in"
    PaperOrientation: str = "Portrait"

    model_config = ConfigDict(extra="allow")


class ReportItem(BaseModel):
    """A single report item (textbox, barcode, image, table, line, rectangle, shape).

    Type-specific properties are stored via extra="allow".
    """

    Type: str
    Name: str
    Left: str | None = None
    Top: str | None = None
    Width: str | None = None
    Height: str | None = None
    Value: str | None = None
    Style: dict[str, Any] | None = None
    ZIndex: int | None = None
    CanGrow: bool | None = None
    KeepTogether: bool | None = None
    Visibility: dict[str, Any] | None = None

    model_config = ConfigDict(extra="allow")


class TableColumn(BaseModel):
    """A column definition in a table."""

    Width: str

    model_config = ConfigDict(extra="allow")


class TableCell(BaseModel):
    """A cell in a table row."""

    Item: ReportItem | None = None
    ColSpan: int | None = None
    RowSpan: int | None = None

    model_config = ConfigDict(extra="allow")


class TableRow(BaseModel):
    """A row in a table."""

    Height: str = "0.25in"
    TableCells: list[TableCell] = Field(default_factory=list)

    model_config = ConfigDict(extra="allow")


class TableGroup(BaseModel):
    """Table header, detail, or footer group."""

    TableRows: list[TableRow] = Field(default_factory=list)
    RepeatOnNewPage: bool | None = None

    model_config = ConfigDict(extra="allow")


class _ConnProps(BaseModel):
    """Data source connection properties."""

    DataProvider: str = "JSONEMBED"
    ConnectString: str = "jsondata={}"

    model_config = ConfigDict(extra="allow")


ConnectionProperties = _ConnProps


class DataSource(BaseModel):
    """A data source definition."""

    Name: str
    ConnectionProperties: _ConnProps = Field(default_factory=_ConnProps)

    model_config = ConfigDict(extra="allow")


class DataSetField(BaseModel):
    """A field in a dataset."""

    Name: str
    DataField: str | None = None

    model_config = ConfigDict(extra="allow")


class DataSetQuery(BaseModel):
    """Query definition for a dataset."""

    DataSourceName: str = "Datasource"
    CommandText: str | None = None

    model_config = ConfigDict(extra="allow")


class DataSet(BaseModel):
    """A dataset definition."""

    Name: str
    Fields: list[DataSetField] = Field(default_factory=list)
    Query: DataSetQuery = Field(default_factory=DataSetQuery)

    model_config = ConfigDict(extra="allow")


class ReportParameter(BaseModel):
    """A report parameter."""

    Name: str
    DataType: str = "String"
    Hidden: bool = False
    ValidValues: dict[str, Any] | None = None

    model_config = ConfigDict(extra="allow")


class CustomProperty(BaseModel):
    """A custom property on the report."""

    Name: str
    Value: str


class Layer(BaseModel):
    """A report layer."""

    Name: str = "default"

    model_config = ConfigDict(extra="allow")


class _Body(BaseModel):
    """Report section body containing report items."""

    Height: str = "5in"
    ReportItems: list[ReportItem] = Field(default_factory=list)

    model_config = ConfigDict(extra="allow")


Body = _Body


class _PageHeader(BaseModel):
    """Page header section."""

    Height: str = "0.5in"
    ReportItems: list[ReportItem] = Field(default_factory=list)
    PrintOnFirstPage: bool = True
    PrintOnLastPage: bool = True

    model_config = ConfigDict(extra="allow")


PageHeader = _PageHeader


class _PageFooter(BaseModel):
    """Page footer section."""

    Height: str = "0.5in"
    ReportItems: list[ReportItem] = Field(default_factory=list)
    PrintOnFirstPage: bool = True
    PrintOnLastPage: bool = True

    model_config = ConfigDict(extra="allow")


PageFooter = _PageFooter


class ReportSection(BaseModel):
    """A section of the report (continuous or page-based)."""

    Type: str = "Continuous"
    Name: str = "Section1"
    Page: PageSettings | None = None
    Width: str | None = None
    Body: _Body = Field(default_factory=_Body)
    PageHeader: _PageHeader | None = None
    PageFooter: _PageFooter | None = None

    model_config = ConfigDict(extra="allow")


class EmbeddedImage(BaseModel):
    """An image embedded in the report as base64 data."""

    Name: str
    MIMEType: str
    ImageData: str


class ReportDefinition(BaseModel):
    """Top-level RDL report definition.

    This is the content stored in .rdlx-json files and placed at
    report.definition in the Datex Studio wrapper format.
    """

    Name: str = "Report"
    Width: str = "6.5in"
    Page: PageSettings = Field(default_factory=PageSettings)
    ReportSections: list[ReportSection] = Field(default_factory=list)
    DataSources: list[DataSource] = Field(default_factory=list)
    DataSets: list[DataSet] = Field(default_factory=list)
    ReportParameters: list[ReportParameter] = Field(default_factory=list)
    CustomProperties: list[CustomProperty] = Field(default_factory=list)
    Layers: list[Layer] = Field(default_factory=lambda: [Layer(Name="default")])
    EmbeddedImages: list[EmbeddedImage] | None = None
    Version: str = "10.0.1"

    model_config = ConfigDict(extra="allow")

    def model_post_init(self, __context: Any) -> None:
        """Normalize reports with top-level Body into ReportSections.

        Some RDLX-JSON files (e.g. SSRS-converted reports) place Body,
        PageHeader, and PageFooter at the top level instead of nesting
        them inside ReportSections. This normalizes them into a single
        ReportSection so _walk_items() can find all items.
        """
        extra = self.model_extra or {}
        top_body = extra.get("Body")
        if top_body and not self.ReportSections:
            section_data: dict[str, Any] = {
                "Type": "Continuous",
                "Name": "Section1",
                "Body": top_body,
            }
            top_header = extra.get("PageHeader")
            if top_header:
                section_data["PageHeader"] = top_header
            top_footer = extra.get("PageFooter")
            if top_footer:
                section_data["PageFooter"] = top_footer
            if self.Width:
                section_data["Width"] = self.Width
            self.ReportSections.append(ReportSection.model_validate(section_data))

    def get_section(self, index: int = 0) -> "ReportSection":
        """Get a report section by index, creating default if needed."""
        if not self.ReportSections:
            self.ReportSections.append(ReportSection())
        if index >= len(self.ReportSections):
            raise IndexError(f"Section index {index} out of range")
        return self.ReportSections[index]

    def _walk_items(
        self,
    ) -> "Iterator[tuple[ReportItem, list[ReportItem], int]]":
        """Recursively yield (item, parent_list, index) for all items."""

        def _recurse(
            items: list[ReportItem],
        ) -> "Iterator[tuple[ReportItem, list[ReportItem], int]]":
            for idx, item in enumerate(items):
                yield item, items, idx
                # Recurse into rectangle children
                if item.Type == "rectangle" and item.model_extra:
                    raw_children = item.model_extra.get("ReportItems", [])
                    children: list[ReportItem] = []
                    for child in raw_children:
                        if isinstance(child, ReportItem):
                            children.append(child)
                        elif isinstance(child, dict):
                            children.append(ReportItem.model_validate(child))
                    if raw_children:
                        item.model_extra["ReportItems"] = children
                    yield from _recurse(children)
                # Recurse into table cells
                if item.Type == "table" and item.model_extra:
                    for group_key in ("Header", "Details", "Footer"):
                        group = item.model_extra.get(group_key)
                        if not group or not isinstance(group, dict):
                            continue
                        for row in group.get("TableRows", []):
                            if isinstance(row, dict):
                                for cell in row.get("TableCells", []):
                                    if isinstance(cell, dict):
                                        cell_item = cell.get("Item")
                                        if isinstance(cell_item, dict):
                                            parsed = ReportItem.model_validate(cell_item)
                                            cell["Item"] = parsed
                                            wrapper: list[ReportItem] = [parsed]
                                            yield parsed, wrapper, 0
                                        elif isinstance(cell_item, ReportItem):
                                            wrapper2: list[ReportItem] = [cell_item]
                                            yield cell_item, wrapper2, 0

                # Recurse into list children
                if item.Type == "list" and item.model_extra:
                    raw_list_children = item.model_extra.get("ReportItems", [])
                    list_children: list[ReportItem] = []
                    for child in raw_list_children:
                        if isinstance(child, ReportItem):
                            list_children.append(child)
                        elif isinstance(child, dict):
                            list_children.append(ReportItem.model_validate(child))
                    if raw_list_children:
                        item.model_extra["ReportItems"] = list_children
                    yield from _recurse(list_children)

                # Recurse into tablix cells
                if item.Type == "tablix" and item.model_extra:
                    body = item.model_extra.get("Body")
                    if body and isinstance(body, dict):
                        # Body.Rows[].Cells[].Item
                        for row in body.get("Rows", []):
                            if isinstance(row, dict):
                                for cell in row.get("Cells", []):
                                    if isinstance(cell, dict):
                                        cell_item = cell.get("Item")
                                        if isinstance(cell_item, dict):
                                            parsed = ReportItem.model_validate(cell_item)
                                            cell["Item"] = parsed
                                            wrapper3: list[ReportItem] = [parsed]
                                            yield parsed, wrapper3, 0
                                        elif isinstance(cell_item, ReportItem):
                                            wrapper4: list[ReportItem] = [cell_item]
                                            yield cell_item, wrapper4, 0

        for section in self.ReportSections:
            yield from _recurse(section.Body.ReportItems)

    def find_item(self, name: str) -> ReportItem | None:
        """Find a report item by name across all sections and nesting levels."""
        for item, _parent, _idx in self._walk_items():
            if item.Name == name:
                return item
        return None

    def find_item_location(self, name: str) -> tuple[list[ReportItem], int] | None:
        """Find the parent list and index for a named item."""
        for item, parent_list, idx in self._walk_items():
            if item.Name == name:
                return (parent_list, idx)
        return None

    def all_items(self) -> list[ReportItem]:
        """Get all report items across all sections and nesting levels."""
        return [item for item, _parent, _idx in self._walk_items()]
