"""Core engine for reading, writing, and mutating RDL report definitions.

Handles report creation, scaffolding from templates, and element manipulation.
"""

from __future__ import annotations

import json
import re
from importlib import resources
from pathlib import Path
from typing import Any

from dxs.report.models import (
    Body,
    CustomProperty,
    DataSet,
    DataSetField,
    DataSource,
    Layer,
    PageFooter,
    PageHeader,
    PageSettings,
    ReportDefinition,
    ReportItem,
    ReportSection,
)
from dxs.report.schema import PAGE_SIZES
from dxs.utils.errors import ValidationError


def _parse_dim(s: str) -> tuple[float, str]:
    """Parse '11in' → (11.0, 'in'), '0.5cm' → (0.5, 'cm')."""
    m = re.match(r"^([0-9]*\.?[0-9]+)\s*(in|cm|mm|pt)$", s)
    if not m:
        raise ValueError(f"Cannot parse dimension: {s}")
    return float(m.group(1)), m.group(2)


def _format_dim(value: float, unit: str) -> str:
    """Format (7.5, 'in') → '7.5in'. Strips trailing zeros."""
    if value == int(value):
        return f"{int(value)}{unit}"
    return f"{value:.4f}".rstrip("0").rstrip(".") + unit


def _calc_body_height(page_height: str, top_margin: str, bottom_margin: str) -> str:
    """Calculate body height = page height - top margin - bottom margin."""
    h_val, h_unit = _parse_dim(page_height)
    t_val, t_unit = _parse_dim(top_margin)
    b_val, b_unit = _parse_dim(bottom_margin)
    if h_unit != t_unit or h_unit != b_unit:
        raise ValueError(f"Unit mismatch: {page_height} vs {top_margin}/{bottom_margin}")
    return _format_dim(h_val - t_val - b_val, h_unit)


def _calc_content_width(page_width: str, left_margin: str, right_margin: str) -> str:
    """Calculate content width = page width - left margin - right margin."""
    w_val, w_unit = _parse_dim(page_width)
    l_val, l_unit = _parse_dim(left_margin)
    r_val, r_unit = _parse_dim(right_margin)
    if w_unit != l_unit or w_unit != r_unit:
        raise ValueError(f"Unit mismatch: {page_width} vs {left_margin}/{right_margin}")
    return _format_dim(w_val - l_val - r_val, w_unit)


def _parse_margins(margins: str) -> tuple[str, str, str, str]:
    """Parse a margin string into (top, right, bottom, left).

    Supports CSS-style shorthand:
      - "0.5in"                    → all sides 0.5in
      - "0.5in 0.25in"            → top/bottom 0.5in, left/right 0.25in
      - "0.5in 0.25in 0.75in"     → top 0.5in, left/right 0.25in, bottom 0.75in
      - "0.5in 0.25in 0.75in 0.1in" → top right bottom left
    """
    parts = margins.strip().split()
    if len(parts) == 1:
        _parse_dim(parts[0])  # validate
        return parts[0], parts[0], parts[0], parts[0]
    if len(parts) == 2:
        _parse_dim(parts[0])
        _parse_dim(parts[1])
        return parts[0], parts[1], parts[0], parts[1]
    if len(parts) == 3:
        _parse_dim(parts[0])
        _parse_dim(parts[1])
        _parse_dim(parts[2])
        return parts[0], parts[1], parts[2], parts[1]
    if len(parts) == 4:
        for p in parts:
            _parse_dim(p)
        return parts[0], parts[1], parts[2], parts[3]
    raise ValueError(
        f"Cannot parse margins: {margins!r}. "
        "Use 1-4 values (CSS shorthand: top [right] [bottom] [left])."
    )


def parse_page_size(page_size: str) -> tuple[str, str]:
    """Parse a page size string into width and height.

    Args:
        page_size: Named size (letter, legal, a4, 4x6, 4x8) or WxH format.

    Returns:
        Tuple of (width, height) as strings.

    Raises:
        ValidationError: If page size format is invalid.
    """
    # Check named sizes
    if page_size.lower() in PAGE_SIZES:
        info = PAGE_SIZES[page_size.lower()]
        return info["width"], info["height"]

    # Try WxH format (e.g., "8.5inx11in" or "4inx6in")
    parts = page_size.lower().split("x")
    if len(parts) == 2:
        w, h = parts[0].strip(), parts[1].strip()
        # Ensure they have units
        if not any(w.endswith(u) for u in ("in", "cm", "mm", "pt")):
            w += "in"
        if not any(h.endswith(u) for u in ("in", "cm", "mm", "pt")):
            h += "in"
        return w, h

    raise ValidationError(
        message=f"Invalid page size: '{page_size}'",
        code="DXS-RPT-013",
        suggestions=[
            f"Named sizes: {', '.join(PAGE_SIZES.keys())}",
            "Or use WxH format: 8.5inx11in, 4inx6in",
        ],
    )


def create_blank_report(
    name: str = "Report",
    page_size: str = "letter",
    margins: str = "0.5in",
    landscape: bool = False,
) -> ReportDefinition:
    """Create a blank report definition with page setup.

    Args:
        name: Report name.
        page_size: Named size or WxH format.
        margins: Margin size — single value for all sides, or CSS-style
            shorthand (e.g. "0.5in 0.25in 0.75in 0.25in" for top right bottom left).
        landscape: Use landscape orientation.

    Returns:
        New ReportDefinition with one empty section.
    """
    width, height = parse_page_size(page_size)

    if landscape:
        width, height = height, width

    top, right, bottom, left = _parse_margins(margins)
    content_width = _calc_content_width(width, left, right)

    page = PageSettings(
        PageWidth=width,
        PageHeight=height,
        TopMargin=top,
        BottomMargin=bottom,
        LeftMargin=left,
        RightMargin=right,
    )

    section = ReportSection(
        Type="Continuous",
        Name="Section1",
        Width=content_width,
        Page=page,
        Body=Body(Height=_calc_body_height(height, top, bottom), ReportItems=[]),
    )

    return ReportDefinition(
        Name=name,
        Width=content_width,
        Page=page,
        ReportSections=[section],
        DataSources=[DataSource(Name="Datasource")],
        CustomProperties=[
            CustomProperty(Name="DisplayType", Value="Page"),
            CustomProperty(Name="SizeType", Value="Default"),
        ],
        Layers=[Layer(Name="default")],
    )


def scaffold_report(
    template_name: str,
    page_size_override: str | None = None,
) -> ReportDefinition:
    """Create a report from a built-in template.

    Args:
        template_name: Template identifier (bill-of-lading, shipping-label).
        page_size_override: Optional page size to override template default.

    Returns:
        ReportDefinition populated from the template.

    Raises:
        ValidationError: If template not found.
    """
    # Map template names to filenames
    template_files = {
        "bill-of-lading": "bill_of_lading.rdlx-json",
        "shipping-label": "shipping_label.rdlx-json",
    }

    filename = template_files.get(template_name.lower())
    if filename is None:
        raise ValidationError(
            message=f"Unknown template: '{template_name}'",
            code="DXS-RPT-014",
            suggestions=[f"Available templates: {', '.join(template_files.keys())}"],
        )

    # Load from package resources
    template_data = _load_template(filename)
    report_def = ReportDefinition.model_validate(template_data)

    # Apply page size override if provided
    if page_size_override:
        width, height = parse_page_size(page_size_override)
        report_def.Page.PageWidth = width
        report_def.Page.PageHeight = height
        report_def.Width = width
        for section in report_def.ReportSections:
            if section.Page:
                section.Page.PageWidth = width
                section.Page.PageHeight = height

    return report_def


def _load_template(filename: str) -> dict[str, Any]:
    """Load a template file from package resources.

    Args:
        filename: Template filename.

    Returns:
        Parsed template data.
    """
    template_pkg = resources.files("dxs.report.templates")
    template_file = template_pkg.joinpath(filename)
    content = template_file.read_text(encoding="utf-8")
    return json.loads(content)  # type: ignore[no-any-return]


def add_item(
    report_def: ReportDefinition, item_props: dict[str, Any], section_index: int = 0
) -> ReportItem:
    """Add a new report item to a section.

    Args:
        report_def: The report definition to modify.
        item_props: Properties for the new item.
        section_index: Which section to add to (default: first).

    Returns:
        The created ReportItem.

    Raises:
        ValidationError: If name already exists.
    """
    name = item_props.get("Name", "")

    # Check for duplicate names
    existing = report_def.find_item(name)
    if existing is not None:
        raise ValidationError(
            message=f"Element name '{name}' already exists in report",
            code="DXS-RPT-015",
            suggestions=[
                f"Choose a unique name (existing: {', '.join(i.Name for i in report_def.all_items())})"
            ],
        )

    # Ensure section exists
    section = report_def.get_section(section_index)

    item = ReportItem.model_validate(item_props)
    section.Body.ReportItems.append(item)
    return item


def add_child_item(
    report_def: ReportDefinition,
    parent_name: str,
    item_props: dict[str, Any],
) -> ReportItem:
    """Add a child item inside a rectangle or list container.

    Args:
        report_def: The report definition to modify.
        parent_name: Name of the parent container element.
        item_props: Properties for the new child item.

    Returns:
        The created child ReportItem.

    Raises:
        ValidationError: If parent not found, not a container, or child name duplicated.
    """
    parent = report_def.find_item(parent_name)
    if parent is None:
        raise ValidationError(
            message=f"Parent element '{parent_name}' not found",
            code="DXS-RPT-073",
        )
    if parent.Type not in ("rectangle", "list"):
        raise ValidationError(
            message=f"Parent '{parent_name}' is not a container (type: {parent.Type})",
            code="DXS-RPT-074",
            suggestions=["Only rectangle and list elements can contain children"],
        )
    child_name = item_props.get("Name", "")
    if child_name and report_def.find_item(child_name) is not None:
        raise ValidationError(
            message=f"Element '{child_name}' already exists",
            code="DXS-RPT-010",
        )
    child = ReportItem.model_validate(item_props)
    if parent.model_extra is None:
        object.__setattr__(parent, "__pydantic_extra__", {})
    if "ReportItems" not in parent.model_extra:
        parent.model_extra["ReportItems"] = []
    parent.model_extra["ReportItems"].append(child)
    return child


def add_page_header(
    report_def: ReportDefinition,
    height: str,
    print_on_first: bool = True,
    print_on_last: bool = True,
    section_index: int = 0,
) -> None:
    """Create a PageHeader on the given report section."""
    section = report_def.get_section(section_index)
    if section.PageHeader is not None:
        raise ValidationError(
            message=f"Section '{section.Name}' already has a PageHeader",
            code="DXS-RPT-085",
            suggestions=[
                "Use batch with 'parent': 'PageHeader' to add items to the existing header"
            ],
        )
    section.PageHeader = PageHeader(
        Height=height,
        PrintOnFirstPage=print_on_first,
        PrintOnLastPage=print_on_last,
    )


def add_page_footer(
    report_def: ReportDefinition,
    height: str,
    print_on_first: bool = True,
    print_on_last: bool = True,
    section_index: int = 0,
) -> None:
    """Create a PageFooter on the given report section."""
    section = report_def.get_section(section_index)
    if section.PageFooter is not None:
        raise ValidationError(
            message=f"Section '{section.Name}' already has a PageFooter",
            code="DXS-RPT-086",
            suggestions=[
                "Use batch with 'parent': 'PageFooter' to add items to the existing footer"
            ],
        )
    section.PageFooter = PageFooter(
        Height=height,
        PrintOnFirstPage=print_on_first,
        PrintOnLastPage=print_on_last,
    )


def add_page_section_item(
    report_def: ReportDefinition,
    section_type: str,
    item_props: dict[str, Any],
    section_index: int = 0,
) -> ReportItem:
    """Add an item to a PageHeader or PageFooter."""
    section = report_def.get_section(section_index)
    page_section = getattr(section, section_type, None)
    if page_section is None:
        raise ValidationError(
            message=f"Section '{section.Name}' does not have a {section_type}",
            code="DXS-RPT-087",
            suggestions=[
                f"Create it first: dxs report add {section_type.lower().replace('page', 'page-')} <file> --height 0.5in"
            ],
        )

    name = item_props.get("Name", "")
    existing = report_def.find_item(name)
    if existing is not None:
        raise ValidationError(
            message=f"Element name '{name}' already exists in report",
            code="DXS-RPT-015",
        )
    for ri in page_section.ReportItems:
        if ri.Name == name:
            raise ValidationError(
                message=f"Element name '{name}' already exists in {section_type}",
                code="DXS-RPT-015",
            )

    item = ReportItem.model_validate(item_props)
    page_section.ReportItems.append(item)
    return item


def set_item_properties(item: ReportItem, updates: dict[str, Any]) -> None:
    """Update properties on an existing report item.

    Args:
        item: The report item to update.
        updates: Dictionary of property updates.
    """
    for key, value in updates.items():
        if key == "Style":
            # Merge style properties rather than replacing
            if item.Style is None:
                item.Style = {}
            item.Style.update(value)
        elif key in ("StartPoint", "EndPoint"):
            existing = (item.model_extra or {}).get(key, {})
            merged = {**existing, **value}
            if item.model_extra is None:
                object.__setattr__(item, "__pydantic_extra__", {})
            if item.model_extra is not None:
                item.model_extra[key] = merged
        elif hasattr(item, key):
            setattr(item, key, value)
        else:
            # Store as extra field
            if item.model_extra is None:
                object.__setattr__(item, "__pydantic_extra__", {})
            if item.model_extra is not None:
                item.model_extra[key] = value


def set_table_cell(report_def: ReportDefinition, cell_name: str, updates: dict[str, Any]) -> None:
    """Update a table cell item by name.

    Args:
        report_def: The report definition to modify.
        cell_name: Name of the table cell item to update.
        updates: Dictionary of property updates.

    Raises:
        ValidationError: If the cell is not found.
    """
    from dxs.utils.errors import ValidationError

    item = report_def.find_item(cell_name)
    if item is None:
        raise ValidationError(message=f"Table cell '{cell_name}' not found", code="DXS-RPT-072")
    set_item_properties(item, updates)


def remove_item(report_def: ReportDefinition, name: str) -> bool:
    """Remove a report item by name.

    Args:
        report_def: The report definition to modify.
        name: Name of the item to remove.

    Returns:
        True if item was found and removed, False otherwise.
    """
    location = report_def.find_item_location(name)
    if location is None:
        return False

    parent_list, idx = location
    parent_list.pop(idx)
    return True


def build_outline(report_def: ReportDefinition) -> dict[str, Any]:
    """Build a hierarchical outline of all report elements."""
    sections = []
    for section in report_def.ReportSections:
        section_data: dict[str, Any] = {
            "name": section.Name,
            "type": section.Type,
            "items": [_outline_item(item) for item in section.Body.ReportItems],
        }
        sections.append(section_data)
    return {"sections": sections}


def _detect_collection_from_folder(report_path: Path, ds_name: str) -> bool:
    """Check the report folder for a matching owned DS config with isCollection."""
    folder = report_path.parent
    config_path = folder / f"{ds_name}.json"
    if not config_path.exists():
        return False
    try:
        config = json.loads(config_path.read_text(encoding="utf-8"))
        return bool(config.get("isCollection", False))
    except (json.JSONDecodeError, OSError):
        return False


def add_dataset(
    report_def: ReportDefinition,
    name: str,
    fields: list[str],
    *,
    datasource_name: str = "Datasource",
    command_text: str | None = None,
    is_collection: bool = False,
    report_path: Path | None = None,
) -> DataSet:
    """Add a dataset to the report definition.

    Args:
        report_def: The report definition to modify.
        name: Dataset name (used in expressions and CommandText).
        fields: List of field names. Dot-notation names get underscored Name
            (e.g., "Account.Name" → Name="Account_Name", DataField="Account.Name").
            Date annotations like [Date|YYYY-MM-DDTHH:mm:ss.fffffff] are stripped
            from Name but preserved in DataField.
        datasource_name: Data source to bind to.
        command_text: Override CommandText (default: $.{name}.result or
            $.{name}.result.* with is_collection=True).
        is_collection: If True, append .* to CommandText for collection datasets.
        report_path: Path to the report file. When provided and is_collection is
            False and command_text is None, auto-detects collection from a
            co-located {name}.json datasource config.
    """
    for ds in report_def.DataSets:
        if ds.Name == name:
            raise ValidationError(
                message=f"Dataset '{name}' already exists",
                code="DXS-RPT-070",
            )

    ds_fields = []
    for f in fields:
        data_field = f
        field_name = f
        if "[" in field_name:
            field_name = field_name[: field_name.index("[")]
        field_name = field_name.replace(".", "_")
        ds_fields.append({"Name": field_name, "DataField": data_field})

    # Auto-detect collection from owned DS config in report folder
    if not is_collection and not command_text and report_path is not None:
        is_collection = _detect_collection_from_folder(report_path, name)

    suffix = ".*" if is_collection else ""
    ct = command_text or f"$.{name}.result{suffix}"
    dataset = DataSet.model_validate(
        {
            "Name": name,
            "Fields": ds_fields,
            "Query": {"DataSourceName": datasource_name, "CommandText": ct},
            "CaseSensitivity": "Auto",
            "KanatypeSensitivity": "Auto",
            "AccentSensitivity": "Auto",
            "WidthSensitivity": "Auto",
        }
    )

    report_def.DataSets.append(dataset)
    return dataset


def add_child_dataset(
    report_def: ReportDefinition,
    parent_name: str,
    collection_name: str,
    fields: list[str],
) -> DataSet:
    """Add a child dataset for a collection property using $dataset: reference.

    Matches the platform's buildRdlFieldsAndDataSets behavior:
    - Name: "{parent_name}_{collection_name}"
    - DataSourceName: "$dataset:{parent_name}/{collection_name}"
    - No CommandText (omitted via exclude_none serialization)

    Args:
        report_def: The report definition to modify.
        parent_name: Name of the parent dataset.
        collection_name: Name of the collection property in the parent.
        fields: List of field names within the collection items.
    """
    name = f"{parent_name}_{collection_name}"
    for ds in report_def.DataSets:
        if ds.Name == name:
            raise ValidationError(
                message=f"Dataset '{name}' already exists",
                code="DXS-RPT-070",
            )

    ds_fields = []
    for f in fields:
        data_field = f
        field_name = f
        if "[" in field_name:
            field_name = field_name[: field_name.index("[")]
        field_name = field_name.replace(".", "_")
        ds_fields.append({"Name": field_name, "DataField": data_field})

    dataset = DataSet.model_validate(
        {
            "Name": name,
            "Fields": ds_fields,
            "Query": {"DataSourceName": f"$dataset:{parent_name}/{collection_name}"},
        }
    )

    report_def.DataSets.append(dataset)
    return dataset


def remove_dataset(report_def: ReportDefinition, name: str) -> bool:
    """Remove a dataset by name. Returns True if found and removed."""
    for i, ds in enumerate(report_def.DataSets):
        if ds.Name == name:
            report_def.DataSets.pop(i)
            return True
    return False


def add_dataset_field(
    report_def: ReportDefinition,
    dataset_name: str,
    field: str,
) -> dict[str, str]:
    """Add a field to an existing dataset.

    Args:
        report_def: The report definition to modify.
        dataset_name: Name of the dataset to add the field to.
        field: Field name. Dot-notation names get underscored Name
            (e.g., "Account.Name" → Name="Account_Name", DataField="Account.Name").
            Date annotations like [Date|...] are stripped from Name but preserved in DataField.

    Returns:
        The new field dict with Name and DataField keys.

    Raises:
        ValidationError: If dataset not found or field already exists.
    """
    ds = None
    for d in report_def.DataSets:
        if d.Name == dataset_name:
            ds = d
            break
    if ds is None:
        raise ValidationError(
            message=f"Dataset '{dataset_name}' not found",
            code="DXS-RPT-076",
        )

    # Parse field name (same logic as add_dataset)
    data_field = field
    field_name = field
    if "[" in field_name:
        field_name = field_name[: field_name.index("[")]
    field_name = field_name.replace(".", "_")

    # Check for duplicates
    existing_names = {f.Name for f in ds.Fields}
    if field_name in existing_names:
        raise ValidationError(
            message=f"Field '{field_name}' already exists in dataset '{dataset_name}'",
            code="DXS-RPT-077",
        )

    new_field = DataSetField(Name=field_name, DataField=data_field)
    ds.Fields.append(new_field)
    return {"Name": field_name, "DataField": data_field}


def add_tablix_column(
    report_def: ReportDefinition,
    tablix_name: str,
    width: str,
    position: int | None = None,
    header_value: str | None = None,
    detail_value: str | None = None,
    header_style: dict[str, Any] | None = None,
    detail_style: dict[str, Any] | None = None,
    shrink_existing: bool = False,
) -> None:
    """Add a column to an existing tablix or table element."""
    item = report_def.find_item(tablix_name)
    if item is None:
        raise ValidationError(
            message=f"Element '{tablix_name}' not found",
            code="DXS-RPT-074",
        )

    extra = item.model_extra or {}

    # Detect structure type
    body = extra.get("Body", {}) if isinstance(extra.get("Body"), dict) else {}
    is_tablix = "Columns" in body
    is_table = "TableColumns" in extra

    if is_tablix:
        columns = body["Columns"]
        rows = body["Rows"]
        hierarchy = extra.get("ColumnHierarchy", {}).get("Members", [])
    elif is_table:
        columns = extra["TableColumns"]
        header_rows = extra.get("Header", {}).get("TableRows", []) if "Header" in extra else []
        detail_rows = extra.get("Details", {}).get("TableRows", []) if "Details" in extra else []
        rows = None  # handle separately
        hierarchy = None
    else:
        raise ValidationError(
            message=f"Element '{tablix_name}' is not a table or tablix",
            code="DXS-RPT-074",
        )

    # Determine insert position
    if position is None:
        position = len(columns)
    if position < 0 or position > len(columns):
        raise ValidationError(
            message=f"Position {position} out of range (0-{len(columns)})",
            code="DXS-RPT-075",
        )

    # Shrink existing columns if requested
    if shrink_existing and columns:
        if is_table:
            total = sum(_parse_dim(c["Width"])[0] for c in columns)
        else:
            total = sum(_parse_dim(c)[0] for c in columns)
        new_val, new_unit = _parse_dim(width)
        factor = (total - new_val) / total
        if is_table:
            for c in columns:
                old_val, old_unit = _parse_dim(c["Width"])
                c["Width"] = _format_dim(old_val * factor, old_unit)
        else:
            for ci in range(len(columns)):
                old_val, old_unit = _parse_dim(columns[ci])
                columns[ci] = _format_dim(old_val * factor, old_unit)

    # Insert column definition
    if is_table:
        columns.insert(position, {"Width": width})
    else:
        columns.insert(position, width)

    # Cell name suffix = total columns after insertion (guaranteed unique)
    col_suffix = len(columns) - 1

    if is_tablix:
        # For tablix: insert a cell into each row
        for row_idx, row in enumerate(rows):
            cells = row.get("Cells", [])
            # First row with static member = header; rest = detail
            is_hdr = row_idx == 0 and len(rows) > 1
            val = header_value or "" if is_hdr else detail_value or ""
            sty = dict(header_style or {}) if is_hdr else dict(detail_style or {})
            suffix = f"Hdr{col_suffix}" if is_hdr else f"Det{col_suffix}"
            cell_name = f"{tablix_name}_{suffix}"
            cell_item: dict[str, Any] = {
                "Type": "textbox",
                "Name": cell_name,
                "Value": val,
            }
            if sty:
                cell_item["Style"] = sty
            new_cell: dict[str, Any] = {"Item": cell_item}
            cells.insert(position, new_cell)
            row["Cells"] = cells

        # Insert hierarchy member
        if hierarchy is not None:
            hierarchy.insert(position, {"BodyIndex": position, "Group": None})
            # Re-index BodyIndex for all column hierarchy members
            for hi, hm in enumerate(hierarchy):
                hm["BodyIndex"] = hi

    elif is_table:
        # For table: insert cells into header and detail rows separately
        for row in header_rows:
            cells = row.get("TableCells", [])
            cell_name = f"{tablix_name}_Hdr{col_suffix}"
            new_cell_t: dict[str, Any] = {
                "Item": {
                    "Type": "textbox",
                    "Name": cell_name,
                    "Value": header_value or "",
                }
            }
            if header_style:
                new_cell_t["Item"]["Style"] = dict(header_style)
            cells.insert(position, new_cell_t)
            row["TableCells"] = cells

        for row in detail_rows:
            cells = row.get("TableCells", [])
            cell_name = f"{tablix_name}_Det{col_suffix}"
            new_cell_t = {
                "Item": {
                    "Type": "textbox",
                    "Name": cell_name,
                    "Value": detail_value or "",
                }
            }
            if detail_style:
                new_cell_t["Item"]["Style"] = dict(detail_style)
            cells.insert(position, new_cell_t)
            row["TableCells"] = cells


def _flatten_row_indices(
    members: list[dict[str, Any]],
) -> list[tuple[list[dict[str, Any]], int]]:
    """Flatten hierarchy depth-first, returning (parent_members, idx) for each row."""
    indices: list[tuple[list[dict[str, Any]], int]] = []
    for i, m in enumerate(members):
        if "Group" not in m:
            # Static member (no Group key means static)
            indices.append((members, i))
        elif "Children" not in m:
            # Leaf group (detail) = one row
            indices.append((members, i))
        else:
            indices.extend(_flatten_row_indices(m["Children"]))
    return indices


def _find_group_members(
    members: list[dict[str, Any]], group_alias: str | None
) -> list[dict[str, Any]] | None:
    """Find the Members/Children array belonging to a group by alias.

    Matches Group.Name ending with '_{Alias}Group' (case-insensitive on alias).
    """
    if group_alias is None:
        return None
    suffix = f"_{group_alias.capitalize()}Group"
    for m in members:
        grp = m.get("Group")
        if isinstance(grp, dict) and grp.get("Name", "").endswith(suffix):
            return m.get("Children")
        children = m.get("Children")
        if children:
            result = _find_group_members(children, group_alias)
            if result is not None:
                return result
    return None


def add_tablix_group(
    report_def: ReportDefinition,
    tablix_name: str,
    group_name: str,
    group_expression: str,
    header_cells: list[dict[str, Any]] | None = None,
    footer_cells: list[dict[str, Any]] | None = None,
    header_colspan: bool = False,
    footer_colspan: bool = False,
) -> None:
    """Add a row group to an existing tablix, wrapping the detail group.

    Finds the detail group (empty GroupExpressions) in the RowHierarchy,
    wraps it in a new parent group, and inserts group header/footer
    Rows at the correct positions.
    """
    item = report_def.find_item(tablix_name)
    if item is None:
        raise ValidationError(
            message=f"Element '{tablix_name}' not found",
            code="DXS-RPT-083",
        )
    extra = item.model_extra or {}
    if "Body" not in extra or "RowHierarchy" not in extra:
        raise ValidationError(
            message=f"Element '{tablix_name}' is not a tablix",
            code="DXS-RPT-083",
        )

    row_hierarchy = extra["RowHierarchy"]
    body = extra["Body"]

    tablix_rows = body.get("Rows", [])
    num_cols = len(body.get("Columns", []))

    # Find the detail group and its index in the hierarchy
    def _find_detail(
        members: list[dict[str, Any]], path: list[int]
    ) -> tuple[list[dict[str, Any]], int] | None:
        """Find the member list containing the detail group and its index."""
        for i, m in enumerate(members):
            grp = m.get("Group")
            if isinstance(grp, dict) and grp.get("GroupExpressions") == []:
                return members, i
            sub = m.get("Children")
            if sub:
                result = _find_detail(sub, path + [i])
                if result is not None:
                    return result
        return None

    result = _find_detail(row_hierarchy["Members"], [])
    if result is None:
        raise ValidationError(
            message=f"No detail group found in tablix '{tablix_name}'",
            code="DXS-RPT-084",
        )
    parent_members, detail_idx = result

    flat = _flatten_row_indices(row_hierarchy["Members"])
    detail_row_idx = next(
        ri for ri, (pm, mi) in enumerate(flat) if pm is parent_members and mi == detail_idx
    )

    # Build the new group member wrapping the detail group
    # Collect the detail member and its adjacent static members
    # (static members with KeepWithGroup that are siblings of the detail)
    detail_member = parent_members[detail_idx]

    # Find static members adjacent to detail that should be wrapped
    inner_members: list[dict[str, Any]] = []
    indices_to_remove: list[int] = []

    # Check for static header before detail (KeepWithGroup: After at detail_idx-1)
    if detail_idx > 0:
        prev = parent_members[detail_idx - 1]
        if "Group" not in prev and prev.get("KeepWithGroup") == "After":
            # This is a group header from a previous inner group — don't steal it
            pass

    # Add group header static if we have header cells
    if header_cells:
        inner_members.append({"KeepWithGroup": "After"})

    inner_members.append(detail_member)
    indices_to_remove.append(detail_idx)

    if footer_cells:
        inner_members.append({"KeepWithGroup": "Before"})

    cap_alias = group_name.capitalize()
    new_group_member: dict[str, Any] = {
        "Group": {
            "Name": f"{tablix_name}_{cap_alias}Group",
            "GroupExpressions": [group_expression],
        },
        "Children": inner_members,
    }

    # Replace detail member with the new group member
    parent_members[detail_idx] = new_group_member

    # Null cell for colspan padding / column padding
    null_cell: dict[str, Any] | None = None

    # Build group header/footer rows
    def _build_group_row(cells: list[dict[str, Any]], prefix: str, colspan: bool) -> dict[str, Any]:
        row_cells: list[dict[str, Any] | None] = []
        for i, cell_def in enumerate(cells):
            if colspan and i == 0:
                cell_with_span = dict(cell_def)
                cell_with_span["ColSpan"] = num_cols
                row_cells.append(cell_with_span)
            elif colspan and i > 0:
                row_cells.append(null_cell)
            else:
                row_cells.append(cell_def)
        # Pad to num_cols if needed
        while len(row_cells) < num_cols:
            row_cells.append(null_cell)
        return {"Height": "0.25in", "Cells": row_cells}

    # Insert rows at correct positions
    insert_offset = 0
    if header_cells:
        hdr_row = _build_group_row(header_cells, f"G{cap_alias}Hdr", header_colspan)
        tablix_rows.insert(detail_row_idx + insert_offset, hdr_row)
        insert_offset += 1

    if footer_cells:
        ftr_row = _build_group_row(footer_cells, f"G{cap_alias}Ftr", footer_colspan)
        # Footer goes after the detail row
        tablix_rows.insert(detail_row_idx + insert_offset + 1, ftr_row)


def add_tablix_row(
    report_def: ReportDefinition,
    tablix_name: str,
    position: str,
    cells: list[str],
    group_name: str | None = None,
    height: str = "0.25in",
    cell_style: dict[str, Any] | None = None,
) -> None:
    """Add a row to an existing tablix at a specified position.

    Inserts both a TablixRow (physical) and a static TablixMember (logical)
    in sync, keeping the RowHierarchy consistent with the Rows array.
    """
    # Validate position/group_name combination
    if position in ("header", "footer") and not group_name:
        raise ValidationError(
            message=f"--group is required for position '{position}'",
            code="DXS-RPT-088",
            suggestions=[
                "Specify --group NAME, or use 'table-header'/'table-footer' for table-level rows"
            ],
        )
    if position in ("table-header", "table-footer") and group_name:
        raise ValidationError(
            message=f"--group must not be specified for position '{position}'",
            code="DXS-RPT-088",
        )

    item = report_def.find_item(tablix_name)
    if item is None:
        raise ValidationError(
            message=f"Element '{tablix_name}' not found",
            code="DXS-RPT-083",
        )
    extra = item.model_extra or {}
    if "Body" not in extra or "RowHierarchy" not in extra:
        raise ValidationError(
            message=f"Element '{tablix_name}' is not a tablix",
            code="DXS-RPT-083",
        )

    body = extra["Body"]

    tablix_rows = body.get("Rows", [])
    num_cols = len(body.get("Columns", []))
    row_hierarchy = extra["RowHierarchy"]

    # Validate cell count
    if len(cells) != num_cols:
        raise ValidationError(
            message=f"Expected {num_cols} cells (one per column), got {len(cells)}",
            code="DXS-RPT-089",
        )

    # Find the target members array
    if position in ("table-header", "table-footer"):
        target_members = row_hierarchy["Members"]
    else:
        target_members = _find_group_members(row_hierarchy["Members"], group_name)
        if target_members is None:
            raise ValidationError(
                message=f"Group '{group_name}' not found in tablix '{tablix_name}'",
                code="DXS-RPT-090",
                suggestions=[
                    "The --group value should be the alias used when creating the group (e.g., 'wh')",
                ],
            )

    # Determine insertion index within target_members
    is_header = position in ("header", "table-header")
    new_member: dict[str, Any] = {
        "KeepWithGroup": "After" if is_header else "Before",
    }

    if is_header:
        # Insert after the last existing header static (before first non-static)
        insert_idx = 0
        for i, m in enumerate(target_members):
            if "Group" not in m and m.get("KeepWithGroup") == "After":
                insert_idx = i + 1
            else:
                break
    else:
        # Insert after the last existing footer static (at the end of footers)
        insert_idx = len(target_members)
        for i in range(len(target_members) - 1, -1, -1):
            if (
                "Group" not in target_members[i]
                and target_members[i].get("KeepWithGroup") == "Before"
            ):
                insert_idx = i + 1
            else:
                break

    target_members.insert(insert_idx, new_member)

    # Flatten hierarchy to find the row index for the new member
    flat = _flatten_row_indices(row_hierarchy["Members"])
    row_insert_idx = next(
        ri for ri, (pm, mi) in enumerate(flat) if pm is target_members and mi == insert_idx
    )

    # Auto-name cells
    if position == "header":
        prefix = f"{tablix_name}_{group_name.capitalize()}_GHdr"
    elif position == "footer":
        prefix = f"{tablix_name}_{group_name.capitalize()}_GFtr"
    elif position == "table-header":
        prefix = f"{tablix_name}_THdr"
    else:
        prefix = f"{tablix_name}_TFtr"

    # Count existing rows with same prefix for unique naming
    existing_count = 0
    for row in tablix_rows:
        for cell in row.get("Cells", []):
            if cell is None:
                continue
            ci = cell.get("Item", {})
            if isinstance(ci, dict) and ci.get("Name", "").startswith(prefix):
                existing_count += 1
                break

    row_n = existing_count

    row_cells: list[dict[str, Any]] = []
    for col_i, val in enumerate(cells):
        cell_name = f"{prefix}{row_n}_{col_i}"
        cell_item_dict: dict[str, Any] = {
            "Type": "textbox",
            "Name": cell_name,
            "Value": val,
        }
        if cell_style:
            cell_item_dict["Style"] = dict(cell_style)
        row_cells.append({"Item": cell_item_dict})

    new_row = {"Height": height, "Cells": row_cells}
    tablix_rows.insert(row_insert_idx, new_row)


def _outline_item(item: ReportItem) -> dict[str, Any]:
    """Build outline entry for a single item, recursing into children."""
    entry: dict[str, Any] = {
        "name": item.Name,
        "type": item.Type,
    }
    if item.Left is not None:
        entry["left"] = item.Left
    if item.Top is not None:
        entry["top"] = item.Top
    if item.Width is not None:
        entry["width"] = item.Width
    if item.Height is not None:
        entry["height"] = item.Height

    # Rectangle children
    if item.Type == "rectangle" and item.model_extra:
        raw_children = item.model_extra.get("ReportItems", [])
        if raw_children:
            children = []
            for child in raw_children:
                if isinstance(child, ReportItem):
                    children.append(_outline_item(child))
                elif isinstance(child, dict):
                    children.append(_outline_item(ReportItem.model_validate(child)))
            entry["items"] = children

    # Table structure
    if item.Type == "table" and item.model_extra:
        for group_key, out_key in [
            ("Header", "header"),
            ("Details", "detail"),
            ("Footer", "footer"),
        ]:
            group = item.model_extra.get(group_key)
            if not group or not isinstance(group, dict):
                continue
            rows = []
            for ri, row in enumerate(group.get("TableRows", []), 1):
                if not isinstance(row, dict):
                    continue
                cells = []
                for cell in row.get("TableCells", []):
                    if not isinstance(cell, dict):
                        continue
                    cell_item = cell.get("Item")
                    if cell_item is None:
                        continue
                    if isinstance(cell_item, ReportItem):
                        cells.append({"name": cell_item.Name, "type": cell_item.Type})
                    elif isinstance(cell_item, dict):
                        cells.append(
                            {"name": cell_item.get("Name", ""), "type": cell_item.get("Type", "")}
                        )
                rows.append({"row": ri, "cells": cells})
            if rows:
                entry[out_key] = rows

    return entry
