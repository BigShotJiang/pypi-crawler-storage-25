"""Server-side SVG rendering of RDLX-JSON reports.

Delegates to the TypeScript React renderer via a Node.js subprocess.
The bundled render-cli.js uses ReactDOMServer.renderToStaticMarkup()
to produce SVG from the same components used in the web UI.
"""

from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path
from typing import Any

from dxs.utils.errors import ValidationError

# Location of the bundled render-cli.js relative to this file.
# Layout: src/dxs/report/svg_renderer.py -> src/dxs/web/static/render-cli.js
_RENDER_CLI = Path(__file__).resolve().parent.parent / "web" / "static" / "render-cli.js"


def _find_node() -> str:
    """Locate the Node.js executable, raising on failure."""
    node = shutil.which("node")
    if node is None:
        raise ValidationError(
            message="Node.js is required for SVG rendering but was not found",
            code="DXS-RPT-060",
            suggestions=[
                "Install Node.js: https://nodejs.org/ (v18+ recommended)",
                "Or: brew install node / winget install OpenJS.NodeJS",
            ],
        )
    return node


def _find_render_cli() -> Path:
    """Locate render-cli.js, raising on failure."""
    if _RENDER_CLI.exists():
        return _RENDER_CLI
    raise ValidationError(
        message=f"render-cli.js not found at {_RENDER_CLI}",
        code="DXS-RPT-061",
        suggestions=[
            "Run 'npm run build:render-cli' in src/dxs/web/frontend/",
            "The render-cli.js bundle may not have been built yet",
        ],
    )


def _normalize_report(report_data: dict[str, Any]) -> dict[str, Any]:
    """Normalize a report dict so legacy formats are converted for the renderer.

    Reports with top-level Body (no ReportSections) are valid RDLX-JSON that
    ActiveReportsJS accepts, but our TypeScript renderer requires ReportSections.
    Run through the Pydantic model which normalizes top-level Body into
    ReportSections[0], then serialize back.
    """
    if "Body" in report_data and "ReportSections" not in report_data:
        from dxs.report.models import ReportDefinition

        rd = ReportDefinition.model_validate(report_data)
        return rd.model_dump(exclude_none=True)  # type: ignore[no-any-return]
    return report_data


def render_report_to_svg(
    report_data: dict[str, Any],
    sample_data: dict[str, Any] | None = None,
    *,
    show_margins: bool = False,
    bounding_boxes: list[dict[str, str]] | None = None,
) -> str:
    """Render an RDLX-JSON report definition to an SVG string.

    Delegates to the TypeScript renderer via Node.js subprocess.

    Args:
        report_data: Parsed report definition (RDLX-JSON content).
        sample_data: Optional sample data for expression resolution.
        show_margins: If True, render the dashed margin guide border.
        bounding_boxes: Optional list of bounding box annotations to overlay.
    """
    node = _find_node()
    render_cli = _find_render_cli()

    payload = json.dumps(
        {
            "report": _normalize_report(report_data),
            "sampleData": sample_data,
            "showMargins": show_margins,
            "boundingBoxes": bounding_boxes,
        }
    )

    result = subprocess.run(
        [node, str(render_cli)],
        input=payload,
        capture_output=True,
        text=True,
        timeout=30,
    )

    if result.returncode != 0:
        stderr = result.stderr.strip()
        raise ValidationError(
            message=f"SVG rendering failed: {stderr or 'unknown error'}",
            code="DXS-RPT-062",
            suggestions=[
                "Check that the report JSON is valid",
                "Run with --verbose for more details",
            ],
        )

    return result.stdout


def render_report_to_pdf(
    report_data: dict[str, Any],
    output_path: str | Path,
    sample_data: dict[str, Any] | None = None,
) -> None:
    """Render an RDLX-JSON report to PDF via SVG conversion."""
    try:
        from io import BytesIO

        from reportlab.graphics import renderPDF  # type: ignore[import-untyped]
        from svglib.svglib import svg2rlg  # type: ignore[import-untyped]
    except ImportError as exc:
        raise ValidationError(
            message="svglib and reportlab are required for PDF rendering",
            code="DXS-RPT-050",
            suggestions=[
                "Install with: pip install svglib reportlab",
                "Or: uv pip install svglib reportlab",
            ],
        ) from exc

    svg_str = render_report_to_svg(report_data, sample_data)
    svg_bytes = BytesIO(svg_str.encode("utf-8"))
    drawing = svg2rlg(svg_bytes)
    if drawing is None:
        raise ValidationError(
            message="Failed to parse generated SVG for PDF conversion",
            code="DXS-RPT-051",
            suggestions=["The report definition may contain unsupported elements"],
        )
    renderPDF.drawToFile(drawing, str(output_path))
