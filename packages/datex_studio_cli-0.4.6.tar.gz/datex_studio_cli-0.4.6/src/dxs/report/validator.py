"""Validation for RDL report definitions.

Performs structural, spatial, and semantic checks.
"""

from __future__ import annotations

import re
from typing import Any

from dxs.report.models import ReportDefinition, ReportItem
from dxs.report.schema import BARCODE_SYMBOLOGIES


def validate_report(
    report_def: ReportDefinition,
    datasource_configs: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Validate a report definition.

    Args:
        report_def: The report definition to validate.
        datasource_configs: Optional datasource configs for CommandText path validation.
            Each dict should have 'configId' and 'configOutParameters' keys.

    Returns:
        Dict with keys: valid (bool), errors (list), warnings (list).
    """
    errors: list[dict[str, str]] = []
    warnings: list[dict[str, str]] = []

    _validate_structural(report_def, errors, warnings)
    _validate_datasources(report_def, errors, warnings)
    _validate_tablix_groups(report_def, errors, warnings)
    _validate_spatial(report_def, errors, warnings)
    _validate_semantic(report_def, errors, warnings)
    _validate_datasets(report_def, errors, warnings)
    if datasource_configs:
        _validate_commandtext_paths(report_def, datasource_configs, warnings)

    return {
        "valid": len(errors) == 0,
        "errors": errors,
        "warnings": warnings,
    }


# ── Size Parsing ─────────────────────────────────────────────────────────

_SIZE_PATTERN = re.compile(r"^(-?\d+(?:\.\d+)?)\s*(in|cm|mm|pt)$")


def _parse_size_inches(size_str: str | None) -> float | None:
    """Parse a size string to inches. Returns None if unparseable."""
    if not size_str:
        return None

    match = _SIZE_PATTERN.match(size_str.strip())
    if not match:
        return None

    value = float(match.group(1))
    unit = match.group(2)

    if unit == "in":
        return value
    elif unit == "cm":
        return value / 2.54
    elif unit == "mm":
        return value / 25.4
    elif unit == "pt":
        return value / 72.0
    return None


# ── Structural Checks ───────────────────────────────────────────────────


def _validate_structural(
    report_def: ReportDefinition,
    errors: list[dict[str, str]],
    warnings: list[dict[str, str]],
) -> None:
    """Check required fields and basic structure."""
    if not report_def.ReportSections:
        errors.append(
            {
                "element": "(report)",
                "message": "Report has no sections",
                "suggestion": "Add at least one ReportSection",
            }
        )
        return

    # Check for duplicate names
    names: dict[str, int] = {}
    for item in report_def.all_items():
        names[item.Name] = names.get(item.Name, 0) + 1

    for name, count in names.items():
        if count > 1:
            errors.append(
                {
                    "element": name,
                    "message": f"Duplicate element name (appears {count} times)",
                    "suggestion": "Element names must be unique within a report",
                }
            )

    # Check required fields per item type
    for item in report_def.all_items():
        _validate_item_required_fields(item, errors, warnings)


# ── DataSource Checks ────────────────────────────────────────────────────

_STRAY_DS_KEYS = {"DataProvider", "ConnectString"}


def _validate_datasources(
    report_def: ReportDefinition,
    errors: list[dict[str, str]],
    warnings: list[dict[str, str]],
) -> None:
    """Check DataSource ConnectionProperties are present and well-formed."""
    for ds in report_def.DataSources:
        if ds.ConnectionProperties is None:
            errors.append(
                {
                    "element": f"DataSource '{ds.Name}'",
                    "message": (
                        "Missing ConnectionProperties — DataProvider and "
                        "ConnectString must be nested inside ConnectionProperties"
                    ),
                    "suggestion": (
                        'Use {"ConnectionProperties": {"DataProvider": "JSONEMBED", '
                        '"ConnectString": "jsondata={}"}}'
                    ),
                }
            )
            continue

        extra = ds.model_extra or {}
        stray = _STRAY_DS_KEYS & extra.keys()
        if stray:
            errors.append(
                {
                    "element": f"DataSource '{ds.Name}'",
                    "message": (
                        f"Stray key(s) {sorted(stray)} found at DataSource root level "
                        f"— these belong inside ConnectionProperties"
                    ),
                    "suggestion": ("Move DataProvider/ConnectString inside ConnectionProperties"),
                }
            )


# ── Tablix Group Checks ──────────────────────────────────────────────────

_AGGREGATE_PATTERN = re.compile(r"=.*\b(?:Sum|Count|Avg|Min|Max|First|Last)\s*\(", re.IGNORECASE)


def _validate_tablix_groups(
    report_def: ReportDefinition,
    errors: list[dict[str, str]],
    warnings: list[dict[str, str]],
) -> None:
    """Check that tablix groups with aggregates have GroupExpressions."""
    for item in report_def.all_items():
        if item.Type != "tablix" or not item.model_extra:
            continue

        tablix_name = item.Name
        body = item.model_extra.get("Body")
        row_hierarchy = item.model_extra.get("RowHierarchy")
        if not isinstance(body, dict) or not isinstance(row_hierarchy, dict):
            continue

        rows = body.get("Rows", [])
        members = row_hierarchy.get("Members", [])

        for member in members:
            group = member.get("Group")
            if not isinstance(group, dict):
                continue

            group_name = group.get("Name", "unnamed")
            group_exprs = group.get("GroupExpressions", [])
            if group_exprs:
                continue

            # Group has no expressions — check if its row uses aggregates
            body_index = member.get("BodyIndex")
            if body_index is None or body_index >= len(rows):
                continue

            row = rows[body_index]
            if not isinstance(row, dict):
                continue

            for cell in row.get("Cells", []):
                if not isinstance(cell, dict):
                    continue
                cell_item = cell.get("Item")
                if cell_item is None:
                    continue
                value = (
                    cell_item.get("Value", "")
                    if isinstance(cell_item, dict)
                    else getattr(cell_item, "Value", "")
                )
                if isinstance(value, str) and _AGGREGATE_PATTERN.search(value):
                    errors.append(
                        {
                            "element": (f"Tablix '{tablix_name}' group '{group_name}'"),
                            "message": (
                                "Group has no GroupExpressions but contains "
                                "aggregate function(s) — this causes "
                                "'incompatible aggregates' at runtime"
                            ),
                            "suggestion": (
                                "Add GroupExpressions with the field to group by "
                                '(e.g., ["=Fields!Category.Value"])'
                            ),
                        }
                    )
                    break  # one error per group is enough


def _validate_item_required_fields(
    item: ReportItem,
    errors: list[dict[str, str]],
    warnings: list[dict[str, str]] | None = None,
) -> None:
    """Check required fields for a specific item type."""
    if warnings is None:
        warnings = []

    if item.Type == "barcode":
        extra = item.model_extra or {}
        if "Symbology" not in extra:
            errors.append(
                {
                    "element": item.Name,
                    "message": "Barcode missing required 'Symbology' property",
                    "suggestion": "Add --symbology (e.g., Code128, QRCode)",
                }
            )
        if not item.Value:
            errors.append(
                {
                    "element": item.Name,
                    "message": "Barcode missing required 'Value' property",
                    "suggestion": "Add --value with data to encode",
                }
            )

    elif item.Type == "image":
        extra = item.model_extra or {}
        if "Source" not in extra:
            errors.append(
                {
                    "element": item.Name,
                    "message": "Image missing required 'Source' property",
                    "suggestion": "Add --source (External, Embedded, or Database)",
                }
            )
        if not item.Value:
            errors.append(
                {
                    "element": item.Name,
                    "message": "Image missing required 'Value' property",
                    "suggestion": "Add --value with URL or expression",
                }
            )

    elif item.Type == "line":
        extra = item.model_extra or {}
        start = extra.get("StartPoint")
        end = extra.get("EndPoint")
        # Lines can use either StartPoint/EndPoint or Left/Top/Width/Height
        has_positional = item.Left is not None or item.Top is not None

        if not start and not has_positional:
            errors.append(
                {
                    "element": item.Name,
                    "message": "Line missing required 'StartPoint' property",
                    "suggestion": "Add StartPoint with X and Y coordinates (e.g., start-x, start-y in batch)",
                }
            )
        if not end and not has_positional:
            errors.append(
                {
                    "element": item.Name,
                    "message": "Line missing required 'EndPoint' property",
                    "suggestion": "Add EndPoint with X and Y coordinates (e.g., end-x, end-y in batch)",
                }
            )

        if start and end:
            sx = _parse_size_inches(start.get("X")) or 0
            sy = _parse_size_inches(start.get("Y")) or 0
            ex = _parse_size_inches(end.get("X")) or 0
            ey = _parse_size_inches(end.get("Y")) or 0

            if sx == ex and sy == ey:
                if sx == 0 and sy == 0:
                    warnings.append(
                        {
                            "element": item.Name,
                            "message": "Line has both StartPoint and EndPoint at (0,0) — invisible",
                            "suggestion": "Set start-x/start-y/end-x/end-y to actual coordinates",
                        }
                    )
                else:
                    warnings.append(
                        {
                            "element": item.Name,
                            "message": "Line has identical StartPoint and EndPoint — zero-length, invisible",
                            "suggestion": "Ensure start and end coordinates differ to create a visible line",
                        }
                    )

    elif item.Type == "table":
        extra = item.model_extra or {}
        if "DataSetName" not in extra:
            errors.append(
                {
                    "element": item.Name,
                    "message": "Table missing required 'DataSetName' property",
                    "suggestion": "Add --dataset with the name of the data source",
                }
            )


# ── Spatial Checks ───────────────────────────────────────────────────────


def _validate_spatial(
    report_def: ReportDefinition,
    errors: list[dict[str, str]],
    warnings: list[dict[str, str]],
) -> None:
    """Check element positions against page bounds.

    RDLX-JSON Body coordinates are relative to the content area
    (inside margins), so Left=0in means the left edge of the printable
    area.  The content area width = PageWidth - LeftMargin - RightMargin.
    """
    page = report_def.Page
    page_width = _parse_size_inches(page.PageWidth)
    page_height = _parse_size_inches(page.PageHeight)

    for section in report_def.ReportSections:
        section_page = section.Page or page
        s_width = _parse_size_inches(section_page.PageWidth)
        s_height = _parse_size_inches(section_page.PageHeight)
        s_left = _parse_size_inches(section_page.LeftMargin) or 0
        s_right = _parse_size_inches(section_page.RightMargin) or 0
        s_top = _parse_size_inches(section_page.TopMargin) or 0
        s_bottom = _parse_size_inches(section_page.BottomMargin) or 0

        effective_width = s_width or page_width
        effective_height = s_height or page_height

        if effective_width is None or effective_height is None:
            continue

        # Content area dimensions (body coordinates are relative to this)
        content_width = effective_width - s_left - s_right
        content_height = effective_height - s_top - s_bottom

        for item in section.Body.ReportItems:
            # Lines use StartPoint/EndPoint instead of Left/Top/Width/Height
            if item.Type == "line":
                extra = item.model_extra or {}
                sp = extra.get("StartPoint", {})
                ep = extra.get("EndPoint", {})
                for label, point in [("StartPoint", sp), ("EndPoint", ep)]:
                    if not isinstance(point, dict):
                        continue
                    px = _parse_size_inches(point.get("X"))
                    py = _parse_size_inches(point.get("Y"))
                    if px is not None and px > content_width:
                        overshoot = px - content_width
                        warnings.append(
                            {
                                "element": item.Name,
                                "message": f"{label}.X extends {overshoot:.2f}in beyond right content area",
                                "suggestion": f"Content area is {content_width:.2f}in wide",
                            }
                        )
                    if py is not None and py > content_height:
                        overshoot = py - content_height
                        warnings.append(
                            {
                                "element": item.Name,
                                "message": f"{label}.Y extends {overshoot:.2f}in beyond bottom content area",
                                "suggestion": f"Content area is {content_height:.2f}in tall",
                            }
                        )
                    if px is not None and px < 0:
                        warnings.append(
                            {
                                "element": item.Name,
                                "message": f"{label}.X ({px:.2f}in) extends outside content area",
                                "suggestion": "Move coordinate right to at least 0in",
                            }
                        )
                    if py is not None and py < 0:
                        warnings.append(
                            {
                                "element": item.Name,
                                "message": f"{label}.Y ({py:.2f}in) extends outside content area",
                                "suggestion": "Move coordinate down to at least 0in",
                            }
                        )
                continue

            item_left = _parse_size_inches(item.Left)
            item_top = _parse_size_inches(item.Top)
            item_width = _parse_size_inches(item.Width)
            item_height = _parse_size_inches(item.Height)

            if item_left is None or item_top is None:
                continue

            # Check right boundary (item exceeds content area width)
            if item_width is not None:
                item_right = item_left + item_width
                if item_right > content_width:
                    overshoot = item_right - content_width
                    warnings.append(
                        {
                            "element": item.Name,
                            "message": f"Extends {overshoot:.2f}in beyond right page margin",
                            "suggestion": f"Reduce width or move left (content area is {content_width:.2f}in wide)",
                        }
                    )

            # Check bottom boundary (item exceeds content area height)
            if item_height is not None:
                item_bottom = item_top + item_height
                if item_bottom > content_height:
                    overshoot = item_bottom - content_height
                    warnings.append(
                        {
                            "element": item.Name,
                            "message": f"Extends {overshoot:.2f}in beyond bottom page margin",
                            "suggestion": f"Reduce height or move up (content area is {content_height:.2f}in tall)",
                        }
                    )

            # Check negative positions (off-page to the left/top)
            if item_left < 0:
                warnings.append(
                    {
                        "element": item.Name,
                        "message": f"Negative left position ({item_left:.2f}in) extends outside content area",
                        "suggestion": "Move element right to at least 0in",
                    }
                )

            if item_top < 0:
                warnings.append(
                    {
                        "element": item.Name,
                        "message": f"Negative top position ({item_top:.2f}in) extends outside content area",
                        "suggestion": "Move element down to at least 0in",
                    }
                )


# ── Semantic Checks ──────────────────────────────────────────────────────

_EXPRESSION_PATTERN = re.compile(r"^=")
_FIELDS_REF_PATTERN = re.compile(r"Fields!\w+\.Value")


def _validate_semantic(
    report_def: ReportDefinition,
    errors: list[dict[str, str]],
    warnings: list[dict[str, str]],
) -> None:
    """Check expression syntax, barcode symbologies, and other semantic rules."""
    for item in report_def.all_items():
        # Check expression syntax
        if item.Value and _EXPRESSION_PATTERN.match(item.Value):
            _validate_expression(item, errors, warnings)

        # Check barcode symbology
        if item.Type == "barcode":
            extra = item.model_extra or {}
            symbology = extra.get("Symbology")
            if symbology and not _is_valid_symbology(symbology):
                # Find close matches
                close = _find_close_symbology(symbology)
                suggestion = (
                    f"Did you mean '{close}'?"
                    if close
                    else "See 'dxs report schema barcodes' for valid symbologies"
                )
                errors.append(
                    {
                        "element": item.Name,
                        "message": f"Unknown barcode symbology '{symbology}'",
                        "suggestion": suggestion,
                    }
                )

        # Check font size is parseable
        if item.Style and "FontSize" in item.Style:
            fs = item.Style["FontSize"]
            if not re.match(r"^\d+(\.\d+)?(pt|px|em|rem)$", str(fs)):
                warnings.append(
                    {
                        "element": item.Name,
                        "message": f"Font size '{fs}' may not be valid",
                        "suggestion": "Use format like '10pt', '12pt', '14pt'",
                    }
                )


def _validate_expression(
    item: ReportItem,
    errors: list[dict[str, str]],
    warnings: list[dict[str, str]],
) -> None:
    """Validate an expression value."""
    expr = item.Value
    if expr is None:
        return

    # Check for common mistakes
    if expr.startswith("=") and "Fields." in expr and "Fields!" not in expr:
        errors.append(
            {
                "element": item.Name,
                "message": "Expression uses 'Fields.' instead of 'Fields!'",
                "suggestion": "Use '=Fields!FieldName.Value' syntax (replace '.' after Fields with '!')",
            }
        )

    # Check for escaped backslashes before ! (e.g. Fields\\!Name.Value)
    # This happens when JSON contains literal backslashes — the expression
    # engine sees "Fields\!" instead of "Fields!" and fails to resolve fields.
    if "\\" in expr:
        errors.append(
            {
                "element": item.Name,
                "message": "Expression contains escaped backslash (\\\\! instead of !)",
                "suggestion": "Remove the backslash — use Fields!Name.Value, not Fields\\\\!Name.Value",
            }
        )

    # Check unbalanced parentheses
    if expr.count("(") != expr.count(")"):
        errors.append(
            {
                "element": item.Name,
                "message": "Unbalanced parentheses in expression",
                "suggestion": "Check for missing opening or closing parenthesis",
            }
        )


# ── DataSet Checks ──────────────────────────────────────────────────────


def _validate_datasets(
    report_def: ReportDefinition,
    errors: list[dict[str, str]],
    warnings: list[dict[str, str]],
) -> None:
    """Check DataSet CommandText patterns and consistency."""
    for dataset in report_def.DataSets:
        ct = dataset.Query.CommandText
        dsn = dataset.Query.DataSourceName

        # Child datasets use $dataset: DataSourceName — no CommandText needed
        if dsn.startswith("$dataset:"):
            continue

        # Root datasets must have CommandText
        if ct is None:
            errors.append(
                {
                    "element": f"DataSet '{dataset.Name}'",
                    "message": "Root dataset missing CommandText",
                    "suggestion": (
                        "Set CommandText to $.{ds_name}.result for single-entity "
                        "or $.{ds_name}.result.* for collections"
                    ),
                }
            )
            continue

        # Check for legacy jpath= format
        if ct.startswith("jpath="):
            errors.append(
                {
                    "element": f"DataSet '{dataset.Name}'",
                    "message": f"CommandText uses legacy 'jpath=' format: {ct}",
                    "suggestion": (
                        "Use JSONPath format: $.{ds_name}.result or $.{ds_name}.result.*"
                    ),
                }
            )
            continue

        # Check that CommandText starts with $. (valid JSONPath)
        if not ct.startswith("$."):
            warnings.append(
                {
                    "element": f"DataSet '{dataset.Name}'",
                    "message": (f"CommandText does not start with '$.' (JSONPath root): {ct}"),
                    "suggestion": (
                        "CommandText should be a JSONPath expression like "
                        "$.{ds_name}.result or $.{ds_name}.result.*"
                    ),
                }
            )


def _is_valid_symbology(symbology: str) -> bool:
    """Check if a barcode symbology is valid (case-insensitive)."""
    return any(name.lower() == symbology.lower() for name in BARCODE_SYMBOLOGIES)


def _find_close_symbology(symbology: str) -> str | None:
    """Find a close match for a misspelled symbology."""
    sym_lower = symbology.lower()
    for name in BARCODE_SYMBOLOGIES:
        # Simple prefix/suffix match
        if name.lower().startswith(sym_lower[:4]) or sym_lower.startswith(name.lower()[:4]):
            return name
    return None


# ── CommandText Path Validation ─────────────────────────────────

_CT_PATTERN = re.compile(r"^\$\.([^.]+)\.result(?:\.(\w[\w.]*))?(\.\*)?$")

_CT_DATASET_PATTERN = re.compile(r"^\$dataset:([^/]+)/(.+)$")


def _parse_commandtext(ct: str | None) -> tuple[str | None, str | None, bool]:
    """Parse CommandText into (ds_name, collection_path, is_collection).

    None                            → (None, None, False)
    $.ds_bol.result                 → ("ds_bol", None, False)
    $.ds_bol.result.*               → ("ds_bol", None, True)
    $.ds_bol.result.ShipmentLines.* → ("ds_bol", "ShipmentLines", True)
    """
    if ct is None:
        return None, None, False
    m = _CT_PATTERN.match(ct)
    if not m:
        return None, None, False
    return m.group(1), m.group(2), m.group(3) is not None


def _find_collection_in_out_params(
    config_out_parameters: list[dict[str, Any]], collection_name: str
) -> bool | None:
    """Check if collection_name exists as a field in outParams.

    Returns:
        True if found and isCollection, False if found but not isCollection,
        None if not found at all.
    """
    if not config_out_parameters:
        return None
    root = config_out_parameters[0]
    for field_def in root.get("objectTypeDef", []):
        if field_def.get("id") == collection_name:
            return bool(field_def.get("isCollection", False))
    return None


def _validate_commandtext_paths(
    report_def: ReportDefinition,
    datasource_configs: list[dict[str, Any]],
    warnings: list[dict[str, str]],
) -> None:
    """Cross-reference DataSet CommandText paths against datasource configs."""
    # Build lookup: configId → config, alias → config
    config_lookup: dict[str, dict[str, Any]] = {}
    for cfg in datasource_configs:
        config_id = cfg.get("configId")
        alias = cfg.get("alias")
        if config_id:
            config_lookup[config_id] = cfg
        # Also check nested datasourceConfig (for owned DS wrapper format)
        ds_cfg = cfg.get("datasourceConfig")
        if alias:
            # For wrapper format, use inner datasourceConfig for field lookups
            config_lookup[alias] = ds_cfg if isinstance(ds_cfg, dict) else cfg
        if isinstance(ds_cfg, dict):
            nested_id = ds_cfg.get("configId")
            if nested_id:
                config_lookup[nested_id] = ds_cfg

    # Build dataset name set for parent validation
    dataset_names = {ds.Name for ds in report_def.DataSets}

    for dataset in report_def.DataSets:
        dsn = dataset.Query.DataSourceName

        # Handle $dataset: child datasets
        m = _CT_DATASET_PATTERN.match(dsn)
        if m:
            parent_name = m.group(1)
            if parent_name not in dataset_names:
                warnings.append(
                    {
                        "element": f"DataSet '{dataset.Name}'",
                        "message": (
                            f"References parent dataset '{parent_name}' which does not exist"
                        ),
                        "suggestion": (
                            f"Add a dataset named '{parent_name}' or check the $dataset: reference"
                        ),
                    }
                )
            continue

        # Handle root datasets with CommandText
        ct = dataset.Query.CommandText
        ds_name, collection_path, _is_coll = _parse_commandtext(ct)
        if ds_name is None:
            continue

        matched_cfg = config_lookup.get(ds_name)
        if matched_cfg is None:
            warnings.append(
                {
                    "element": f"DataSet '{dataset.Name}' CommandText",
                    "message": (
                        f"References datasource '{ds_name}' which is not in the datasource configs"
                    ),
                    "suggestion": (
                        f"Check the CommandText path or add a datasource with "
                        f"configId/alias '{ds_name}'"
                    ),
                }
            )
            continue

        if collection_path is None:
            continue

        out_params = matched_cfg.get("configOutParameters", [])
        is_coll = _find_collection_in_out_params(out_params, collection_path)
        if is_coll is None:
            warnings.append(
                {
                    "element": f"DataSet '{dataset.Name}' CommandText",
                    "message": (
                        f"Collection '{collection_path}' not found in datasource "
                        f"'{ds_name}' output fields"
                    ),
                    "suggestion": ("Check the collection name against datasource-fields output"),
                }
            )
        elif not is_coll:
            warnings.append(
                {
                    "element": f"DataSet '{dataset.Name}' CommandText",
                    "message": (
                        f"'{collection_path}' in datasource '{ds_name}' is not a "
                        f"collection (isCollection: false)"
                    ),
                    "suggestion": (
                        "Use $.{ds_name}.result.* for the root entity, or reference "
                        "a field that is a collection"
                    ),
                }
            )
