"""Path utilities for configuration and credential storage."""

import json
import os
import sys
from pathlib import Path


def get_datex_home() -> Path:
    """Get the Datex home directory (~/.datex/).

    Creates the directory if it doesn't exist.
    """
    home = Path.home() / ".datex"
    home.mkdir(parents=True, exist_ok=True)
    return home


def get_config_path() -> Path:
    """Get the path to the config file (~/.datex/config.yaml)."""
    return get_datex_home() / "config.yaml"


def get_credentials_path() -> Path:
    """Get the path to the credentials file (~/.datex/credentials.yaml)."""
    return get_datex_home() / "credentials.yaml"


def get_cache_path() -> Path:
    """Get the path to the cache database (~/.datex/cache.db)."""
    return get_datex_home() / "cache.db"


def get_metadata_dir() -> Path:
    """Get the metadata cache directory (~/.datex/metadata/).

    Creates the directory if it doesn't exist.
    """
    metadata_dir = get_datex_home() / "metadata"
    metadata_dir.mkdir(parents=True, exist_ok=True)
    return metadata_dir


def get_dynamics_metadata_dir() -> Path:
    """Get the Dynamics CRM metadata cache root (~/.datex/dynamics_metadata/).

    Per-org subdirectories live inside this directory. Creates the root if
    it doesn't exist.
    """
    metadata_dir = get_datex_home() / "dynamics_metadata"
    metadata_dir.mkdir(parents=True, exist_ok=True)
    return metadata_dir


def ensure_secure_permissions(path: Path) -> None:
    """Set secure permissions (owner read/write only) on a file.

    Args:
        path: Path to the file to secure.
    """
    if path.exists():
        path.chmod(0o600)


def get_proxy_tokens_path() -> Path:
    """Get the path to the proxy tokens file (~/.datex/proxy_tokens.json)."""
    return get_datex_home() / "proxy_tokens.json"


def get_studio_lockfile() -> Path:
    """Get the path to the studio lockfile (~/.datex/studio.lock)."""
    return get_datex_home() / "studio.lock"


def write_studio_lock(port: int, pid: int) -> None:
    """Write the studio lockfile with server port and PID.

    Args:
        port: The port the studio server is listening on.
        pid: The process ID of the studio server.
    """
    lockfile = get_studio_lockfile()
    lockfile.write_text(json.dumps({"port": port, "pid": pid}))


def _is_pid_alive(pid: int) -> bool:
    """Check whether a process with the given PID is running.

    Uses ctypes on Windows (os.kill signal 0 is unreliable there)
    and os.kill on other platforms.
    """
    if sys.platform == "win32":
        import ctypes

        kernel32 = ctypes.windll.kernel32  # type: ignore[attr-defined]
        PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
        handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
        if handle:
            kernel32.CloseHandle(handle)
            return True
        return False

    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True  # process exists but we lack permission
    return True


def read_studio_lock() -> dict[str, int] | None:
    """Read the studio lockfile and validate the PID is still alive.

    Returns the lockfile contents if the file exists and the PID is alive,
    otherwise returns None. Stale lockfiles (where the PID is no longer
    running) are automatically deleted.
    """
    lockfile = get_studio_lockfile()
    if not lockfile.exists():
        return None

    try:
        data: dict[str, int] = json.loads(lockfile.read_text())
    except (json.JSONDecodeError, OSError):
        remove_studio_lock()
        return None

    pid = data.get("pid")
    if pid is None:
        remove_studio_lock()
        return None

    if not _is_pid_alive(pid):
        remove_studio_lock()
        return None

    return data


def remove_studio_lock() -> None:
    """Delete the studio lockfile, ignoring if it doesn't exist."""
    try:
        get_studio_lockfile().unlink()
    except FileNotFoundError:
        pass
