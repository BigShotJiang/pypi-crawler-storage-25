"""Image file encoding utilities."""

from __future__ import annotations

import base64
from pathlib import Path

from dxs.utils.errors import ValidationError

IMAGE_MIME_TYPES: dict[str, str] = {
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".gif": "image/gif",
    ".svg": "image/svg+xml",
    ".webp": "image/webp",
}

MAX_IMAGE_SIZE = 5 * 1024 * 1024  # 5 MB


def read_and_validate_image(path: Path) -> tuple[bytes, str]:
    """Read an image file, validate extension and size, return (bytes, mime_type)."""
    ext = path.suffix.lower()
    if ext not in IMAGE_MIME_TYPES:
        raise ValidationError(
            message=f"Unsupported image format: {ext}",
            code="DXS-RPT-071",
            suggestions=[f"Supported formats: {', '.join(sorted(IMAGE_MIME_TYPES))}"],
        )
    img_bytes = path.read_bytes()
    if len(img_bytes) > MAX_IMAGE_SIZE:
        raise ValidationError(
            message=f"Image file too large: {len(img_bytes)} bytes (max {MAX_IMAGE_SIZE})",
            code="DXS-RPT-072",
            suggestions=["Reduce image size or resolution"],
        )
    return img_bytes, IMAGE_MIME_TYPES[ext]


def encode_as_data_uri(img_bytes: bytes, mime_type: str) -> str:
    """Encode image bytes as a data URI string."""
    return f"data:{mime_type};base64,{base64.b64encode(img_bytes).decode('ascii')}"
