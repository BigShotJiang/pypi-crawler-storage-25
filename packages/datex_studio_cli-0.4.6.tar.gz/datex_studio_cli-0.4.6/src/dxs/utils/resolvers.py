"""Name-to-ID resolution utilities for organizations, repositories, and users."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import click

from dxs.utils.errors import ApiError, NotFoundError, ValidationError

if TYPE_CHECKING:
    from dxs.core.api import ApiClient


def resolve_api_setting_name(client: ApiClient, branch_id: int, connection_id: int) -> str | None:
    """Resolve the API setting name for a connection from branch AppConfig settings.

    PR 3754 collapsed app settings into the AppConfig JSON. The new payload
    items look like ``{"name": "...", "settingType": "...", "value": "..."}``
    where ``value`` is either the connection ID (legacy) or the connection name
    (post-migration, since references now store names instead of IDs). We try
    both shapes plus the old ``apiConnectionId`` field for backwards compat.
    """
    from dxs.core.api.app_config import fetch_settings
    from dxs.core.api.endpoints import ApiConnectionEndpoints

    settings = fetch_settings(client, branch_id)
    if not settings:
        return None

    connection_id_str = str(connection_id)
    connection_name: str | None = None
    for setting in settings:
        if setting.get("apiConnectionId") == connection_id:
            return setting.get("name")
        value = setting.get("value")
        if value is None:
            continue
        if str(value) == connection_id_str:
            return setting.get("name")
        if connection_name is None:
            try:
                info = client.get(ApiConnectionEndpoints.get(connection_id))
                if isinstance(info, dict):
                    connection_name = info.get("name")
            except Exception:
                connection_name = ""
        if connection_name and value == connection_name:
            return setting.get("name")
    return None


def resolve_connection_option(
    connection_id: int | None,
    connection: str | None,
    org: str | None,
) -> int:
    """Resolve --connection-id / --connection + --org CLI options to a connection ID.

    Args:
        connection_id: Direct connection ID (from --connection-id).
        connection: Connection name (from --connection, requires org).
        org: Organization name (from --org, required with connection).

    Returns:
        Resolved connection ID.

    Raises:
        click.UsageError: If options are missing or conflicting.
    """
    if connection_id is not None and connection is not None:
        raise click.UsageError("Use either --connection-id or --connection, not both.")

    if connection_id is not None:
        return connection_id

    if connection is not None:
        if org is None:
            raise click.UsageError("--org is required when using --connection by name.")
        resolver = EntityResolver()
        org_id = resolver.resolve_org(org)
        return resolver.resolve_connection(connection, org_id=org_id)

    raise click.UsageError("Provide either --connection-id or --connection (with --org).")


class EntityResolver:
    """Resolves entity names to IDs with caching.

    This class provides methods to resolve human-readable names (like organization
    names, repository names, or user emails) to their numeric IDs. Results are
    cached to minimize API calls when resolving multiple entities.

    Example:
        resolver = EntityResolver()
        org_id = resolver.resolve_org("Datex")  # Returns numeric ID
        repo_id = resolver.resolve_repo("FootprintManager", org_id=org_id)
        user_id = resolver.resolve_user_email("user@example.com")
    """

    def __init__(self, client: ApiClient | None = None):
        """Initialize the resolver.

        Args:
            client: Optional API client. If not provided, a new one will be created.
        """
        # Lazy import to avoid circular dependencies
        if client is None:
            from dxs.core.api import ApiClient

            client = ApiClient()

        self._client = client
        self._org_cache: dict[str, int] | None = None
        self._user_cache: dict[str, int] | None = None

    def resolve_org(self, name_or_id: str | int) -> int:
        """Resolve organization name to ID.

        Accepts either a numeric ID or organization name. If a numeric ID is
        provided (as int or numeric string), it is returned directly. Otherwise,
        the organization name is looked up (case-insensitive).

        Args:
            name_or_id: Organization name (string) or ID (int or numeric string)

        Returns:
            Organization ID as integer

        Raises:
            NotFoundError: If organization not found
            ValidationError: If multiple organizations match (ambiguous)
        """
        # If already int, return it
        if isinstance(name_or_id, int):
            return name_or_id

        # If string that looks like int, return int
        if name_or_id.isdigit():
            return int(name_or_id)

        # Search orgs by name (case-insensitive)
        if self._org_cache is None:
            self._build_org_cache()
        assert self._org_cache is not None  # Guaranteed after _build_org_cache()

        name_lower = name_or_id.lower()
        matches = [
            (name, id_) for name, id_ in self._org_cache.items() if name_lower == name.lower()
        ]

        # If no exact match, try substring match
        if not matches:
            matches = [
                (name, id_) for name, id_ in self._org_cache.items() if name_lower in name.lower()
            ]

        if not matches:
            raise NotFoundError(
                resource_type="Organization",
                resource_id=name_or_id,
                suggestions=[
                    "Use 'dxs org list' to see available organizations",
                    "Use 'dxs org search <name>' to search by name",
                ],
            )

        if len(matches) > 1:
            match_list = ", ".join(f"{name} (ID: {id_})" for name, id_ in matches[:5])
            raise ValidationError(
                message=f"Ambiguous organization name '{name_or_id}' matches: {match_list}",
                suggestions=[
                    "Use the numeric ID instead",
                    "Use a more specific name",
                ],
            )

        return matches[0][1]

    def resolve_repo(self, name_or_id: str | int, org_id: int | None = None) -> int:
        """Resolve repository name to ID.

        Accepts either a numeric ID or repository name. If a numeric ID is
        provided (as int or numeric string), it is returned directly. Otherwise,
        the repository name is looked up (case-insensitive), optionally scoped
        to a specific organization.

        Args:
            name_or_id: Repository name (string) or ID (int or numeric string)
            org_id: Optional organization ID to narrow search scope

        Returns:
            Repository ID as integer

        Raises:
            NotFoundError: If repository not found
            ValidationError: If multiple repositories match (ambiguous)
        """
        # If already int, return it
        if isinstance(name_or_id, int):
            return name_or_id

        # If string that looks like int, return int
        if name_or_id.isdigit():
            return int(name_or_id)

        # Fetch repos, optionally filtered by org
        from dxs.core.api import RepoEndpoints

        repos = self._client.get(*RepoEndpoints.list(org_id))
        if not isinstance(repos, list):
            repos = [repos] if repos else []

        name_lower = name_or_id.lower()

        # First try exact match
        matches = [r for r in repos if r.get("name", "").lower() == name_lower]

        # If no exact match, try substring match
        if not matches:
            matches = [r for r in repos if name_lower in r.get("name", "").lower()]

        if not matches:
            raise NotFoundError(
                resource_type="Repository",
                resource_id=name_or_id,
                suggestions=[
                    "Use 'dxs source repo list' to see available repositories",
                    "Use 'dxs source repo search <name>' to search by name",
                    "Try scoping search with --org flag",
                ],
            )

        if len(matches) > 1:
            match_list = ", ".join(f"{r['name']} (ID: {r['id']})" for r in matches[:5])
            raise ValidationError(
                message=f"Ambiguous repository name '{name_or_id}' matches: {match_list}",
                suggestions=[
                    "Use the numeric ID instead",
                    "Use a more specific name",
                    "Scope search with --org to reduce matches",
                ],
            )

        return int(matches[0]["id"])

    def resolve_connection(self, name_or_id: str | int, org_id: int | None = None) -> int:
        """Resolve API connection name to ID.

        Accepts either a numeric ID or connection name. If a numeric ID is
        provided (as int or numeric string), it is returned directly. Otherwise,
        the connection name is looked up (case-insensitive), optionally scoped
        to a specific organization.

        Args:
            name_or_id: Connection name (string) or ID (int or numeric string)
            org_id: Optional organization ID to narrow search scope

        Returns:
            Connection ID as integer

        Raises:
            NotFoundError: If connection not found
            ValidationError: If multiple connections match (ambiguous)
        """
        if isinstance(name_or_id, int):
            return name_or_id

        if name_or_id.isdigit():
            return int(name_or_id)

        from dxs.core.api.endpoints import ApiConnectionEndpoints

        connections = self._client.get(ApiConnectionEndpoints.list(org_id=org_id))
        if not isinstance(connections, list):
            connections = [connections] if connections else []

        name_lower = name_or_id.lower()

        # First try exact match
        matches = [c for c in connections if c.get("name", "").lower() == name_lower]

        # If no exact match, try substring match
        if not matches:
            matches = [c for c in connections if name_lower in c.get("name", "").lower()]

        if not matches:
            raise NotFoundError(
                resource_type="API Connection",
                resource_id=name_or_id,
                suggestions=[
                    "Use 'dxs organization connection list' to see available connections",
                    "Try scoping search with --org flag",
                ],
            )

        if len(matches) > 1:
            match_list = ", ".join(f"{c['name']} (ID: {c['id']})" for c in matches[:5])
            raise ValidationError(
                message=f"Ambiguous connection name '{name_or_id}' matches: {match_list}",
                suggestions=[
                    "Use --connection-id with the numeric ID instead",
                    "Use a more specific name",
                ],
            )

        return int(matches[0]["id"])

    def resolve_user_email(self, email: str) -> int | None:
        """Resolve user email to userId.

        Looks up users by email address (case-insensitive).

        Args:
            email: User's email address

        Returns:
            User ID as integer, or None if not found
        """
        if self._user_cache is None:
            self._build_user_cache()
        assert self._user_cache is not None  # Guaranteed after _build_user_cache()

        return self._user_cache.get(email.lower())

    def _build_org_cache(self) -> None:
        """Build organization name-to-ID cache."""
        from dxs.core.api import OrganizationEndpoints

        orgs = self._client.get(OrganizationEndpoints.list())
        if not isinstance(orgs, list):
            orgs = [orgs] if orgs else []
        self._org_cache = {org["name"]: org["id"] for org in orgs if "name" in org}

    def _build_user_cache(self) -> None:
        """Build user email-to-ID cache."""
        from dxs.core.api import UserEndpoints

        users = self._client.get(UserEndpoints.list())
        if not isinstance(users, list):
            users = [users] if users else []
        # API returns userPrincipalName instead of email
        self._user_cache = {
            u["userPrincipalName"].lower(): u["id"]
            for u in users
            if "userPrincipalName" in u and "id" in u
        }

    def resolve_environment(self, name_or_id: str | int, org_id: int) -> int:
        """Resolve environment name to ID within an organization.

        Accepts either a numeric ID or environment name. If a numeric ID is
        provided (as int or numeric string), it is returned directly. Otherwise,
        the environment name is looked up (case-insensitive).

        Args:
            name_or_id: Environment name (string) or ID (int or numeric string)
            org_id: Organization ID to scope the search

        Returns:
            Environment ID as integer

        Raises:
            NotFoundError: If environment not found
            ValidationError: If multiple environments match (ambiguous)
        """
        if isinstance(name_or_id, int):
            return name_or_id

        if str(name_or_id).isdigit():
            return int(name_or_id)

        from dxs.core.api.endpoints import EnvironmentEndpoints

        environments = self._client.get(EnvironmentEndpoints.list(org_id=org_id))
        if not isinstance(environments, list):
            environments = [environments] if environments else []

        name_lower = name_or_id.lower()

        # First try exact match
        matches = [e for e in environments if e.get("name", "").lower() == name_lower]

        # If no exact match, try substring match
        if not matches:
            matches = [e for e in environments if name_lower in e.get("name", "").lower()]

        if not matches:
            raise NotFoundError(
                resource_type="Environment",
                resource_id=name_or_id,
                suggestions=[
                    "Use 'dxs env list' to see available environments",
                    "Check the environment name spelling",
                ],
            )

        if len(matches) > 1:
            match_list = ", ".join(f"{e['name']} (ID: {e['id']})" for e in matches[:5])
            raise ValidationError(
                message=f"Ambiguous environment name '{name_or_id}' matches: {match_list}",
                suggestions=[
                    "Use the numeric ID instead",
                    "Use a more specific name",
                ],
            )

        return int(matches[0]["id"])

    def resolve_app_url(
        self, org_id: int, env_id: int, app_name: str
    ) -> tuple[str, dict[str, Any]]:
        """Get app URL from environment component definitions.

        Finds the deployed app component for the specified app within
        the given organization and environment.

        Args:
            org_id: Organization ID
            env_id: Environment ID
            app_name: Application name (case-insensitive match)

        Returns:
            Tuple of (websiteUrl, component_data) where component_data contains
            the full component definition details

        Raises:
            NotFoundError: If no matching app found
            ValidationError: If multiple matching apps found
        """
        from dxs.core.api.endpoints import EnvironmentComponentDefinitionsEndpoints

        # Get component definitions for the environment
        components = self._client.get(EnvironmentComponentDefinitionsEndpoints.list(env_id))
        if not isinstance(components, list):
            components = [components] if components else []

        # Filter by organization (the endpoint already filters by environment)
        filtered = [c for c in components if c.get("organizationId") == org_id]

        if not filtered:
            raise NotFoundError(
                resource_type="Environment Component",
                resource_id=f"org={org_id}, env={env_id}",
                suggestions=[
                    "Verify the organization and environment are correct",
                    "Check that you have access to the environment",
                ],
            )

        # Find by app name (case-insensitive)
        app_name_lower = app_name.lower()
        matches = [c for c in filtered if c.get("name", "").lower() == app_name_lower]

        # If no exact match, try substring match
        if not matches:
            matches = [c for c in filtered if app_name_lower in c.get("name", "").lower()]

        if not matches:
            available_apps = [c.get("name", "unknown") for c in filtered]
            raise NotFoundError(
                resource_type="Application",
                resource_id=app_name,
                suggestions=[
                    f"Available apps in this environment: {', '.join(available_apps)}"
                    if available_apps
                    else "No apps found in this environment",
                    "Check the application name spelling",
                ],
            )

        if len(matches) > 1:
            match_list = ", ".join(c.get("name", "unknown") for c in matches[:5])
            raise ValidationError(
                message=f"Ambiguous application name '{app_name}' matches: {match_list}",
                suggestions=[
                    "Use a more specific application name",
                ],
            )

        component = matches[0]
        website_url = component.get("websiteUrl")

        if not website_url:
            raise NotFoundError(
                resource_type="Application URL",
                resource_id=app_name,
                suggestions=[
                    "The application may not be deployed yet",
                    "Check the environment component configuration",
                ],
            )

        return (website_url, component)


def resolve_config_by_reference(
    api_client: Any,
    branch_id: int,
    config_type: str,
    ref_name: str,
) -> dict[str, Any]:
    """Look up a configuration by reference name, with list fallback on 404.

    Works around a server-side bug where get_by_reference returns 404
    for configs on branches with component modules (the API query
    filters on Application.ReferenceName == null).
    """
    from dxs.core.api.endpoints import ConfigurationEndpoints

    try:
        return api_client.get(
            ConfigurationEndpoints.get_by_reference(branch_id, config_type, ref_name)
        )
    except ApiError as e:
        if e.status_code != 404:
            raise
    # Fallback: list all and filter client-side
    items = api_client.get(ConfigurationEndpoints.list_all(branch_id, config_type))
    if isinstance(items, dict):
        items = items.get("value", [])
    match = next((c for c in items if c.get("referenceName") == ref_name), None)
    if match is None:
        raise ApiError(
            message=f"{config_type} '{ref_name}' not found on branch {branch_id}",
            code="DXS-404-001",
            status_code=404,
        )
    return match


def upsert_config(
    api_client: Any,
    branch_id: int,
    config_type: str,
    ref_name: str,
    data: dict[str, Any],
) -> tuple[dict[str, Any] | None, str]:
    """Create or update a configuration with proper lock management.

    Handles the Datex Studio locking protocol:
    - For updates: locks the config before PUT, so inherited (unlocked) configs
      can be modified.
    - For creates: attempts POST, and if blocked by a lock on another branch,
      raises a clear error with the branch that holds the lock.

    Returns:
        Tuple of (api_response, action) where action is "created" or "updated".
    """
    from dxs.core.api.endpoints import ConfigurationEndpoints, SourceControlEndpoints

    # Check if config already exists on this branch
    existing_id = None
    try:
        existing = resolve_config_by_reference(api_client, branch_id, config_type, ref_name)
        if isinstance(existing, dict):
            existing_id = existing.get("id")
    except ApiError as e:
        if e.status_code != 404 and e.code != "DXS-404-001":
            raise

    if existing_id is not None:
        # Update path: lock → PUT → (unlock on error)
        try:
            api_client.post(SourceControlEndpoints.lock_config(branch_id, ref_name))
        except ApiError as e:
            body = e.details.get("body") if isinstance(e.details, dict) else None
            message = body.get("message", "") if isinstance(body, dict) else ""
            if not (e.status_code == 400 and "already locked" in message.lower()):
                raise
            # Already locked by us (ModificationTypeId != null) — fine

        data["id"] = existing_id
        try:
            response = api_client.put(
                ConfigurationEndpoints.update(branch_id, config_type, existing_id),
                data=data,
            )
        except ApiError:
            # Unlock on failure so we don't leave a stale lock
            try:
                api_client.post(SourceControlEndpoints.unlock_config(branch_id, ref_name))
            except ApiError:
                pass
            raise
        return response, "updated"
    else:
        # Create path: POST, with better error on lock conflict
        try:
            response = api_client.post(
                ConfigurationEndpoints.create(branch_id, config_type),
                data=data,
            )
            return response, "created"
        except ApiError as e:
            if e.status_code == 400 and "locked" in (e.message or "").lower():
                raise ApiError(
                    message=(
                        f"Cannot create {config_type} '{ref_name}' — "
                        f"this reference name is locked on another branch. "
                        f"Use 'dxs source locks --repo <id>' to find the lock holder, "
                        f"then unlock or use a different reference name."
                    ),
                    code="DXS-LOCK-001",
                    status_code=400,
                    suggestions=[
                        "Check locks: dxs source locks --repo <repo_id>",
                        "Use a different --name to generate a unique reference name",
                    ],
                ) from e
            raise
