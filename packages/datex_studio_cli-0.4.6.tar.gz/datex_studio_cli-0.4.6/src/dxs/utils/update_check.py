"""PyPI update notifier.

After each command, if the on-disk cache says a newer version exists on
PyPI, print a one-time banner to stderr telling the user how to upgrade.
The actual upgrade is the user's responsibility — we never exec, spawn,
or otherwise touch the running install. This sidesteps every file-lock,
process-replacement, and platform-specific upgrade problem.

The PyPI fetch happens in a background daemon thread, so a stale cache is
refreshed for *next* time. The current run never blocks on the network.

Environment / flag controls:
- ``DXS_NO_UPDATE_CHECK=1`` disables both the check and the banner.
- ``--no-update-check`` (CLI flag) does the same per-invocation.
- ``DXS_UPDATE_CHECK_DEBUG=1`` surfaces sender errors (development only).
"""

from __future__ import annotations

import json
import os
import re
import sys
import threading
import time
from pathlib import Path
from typing import Any

import click

from dxs import __version__
from dxs.utils.paths import get_datex_home

PYPI_URL = "https://pypi.org/pypi/datex-studio-cli/json"
PACKAGE_NAME = "datex-studio-cli"
CACHE_TTL_SECONDS = 24 * 60 * 60
NOTIFY_DEDUPE_SECONDS = 60 * 60  # at most one banner per hour per machine
HTTP_TIMEOUT_SECONDS = 2.0

_CI_ENV_VARS = ("CI", "CONTINUOUS_INTEGRATION", "GITHUB_ACTIONS", "BUILDKITE", "TF_BUILD")


def _cache_path() -> Path:
    return get_datex_home() / "update_check.json"


def _debug(msg: str) -> None:
    if os.environ.get("DXS_UPDATE_CHECK_DEBUG", "").lower() in ("1", "true", "yes"):
        click.echo(f"[update-check] {msg}", err=True)


def is_disabled() -> bool:
    """Return True if the update check has been disabled via env var."""
    return os.environ.get("DXS_NO_UPDATE_CHECK", "").lower() in ("1", "true", "yes")


def _is_ci() -> bool:
    return any(os.environ.get(v) for v in _CI_ENV_VARS)


def _read_cache() -> dict[str, Any] | None:
    path = _cache_path()
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text())
        if isinstance(data, dict):
            return data
    except (json.JSONDecodeError, OSError) as e:
        _debug(f"cache read failed: {e}")
    return None


def _write_cache(data: dict[str, Any]) -> None:
    try:
        _cache_path().write_text(json.dumps(data))
    except OSError as e:
        _debug(f"cache write failed: {e}")


def _fetch_latest_version() -> str | None:
    """Fetch the latest version from PyPI. Returns None on any failure."""
    try:
        import httpx

        response = httpx.get(PYPI_URL, timeout=HTTP_TIMEOUT_SECONDS)
        response.raise_for_status()
        latest = response.json()["info"]["version"]
        return str(latest) if latest else None
    except Exception as e:  # noqa: BLE001 - never let telemetry break the CLI
        _debug(f"fetch failed: {e}")
        return None


def _refresh_cache_worker() -> None:
    latest = _fetch_latest_version()
    if not latest:
        return
    cache = _read_cache() or {}
    cache["latest"] = latest
    cache["checked_at"] = time.time()
    _write_cache(cache)


def _maybe_refresh_async(cache: dict[str, Any] | None) -> None:
    """Spawn a daemon thread to refresh the cache if it's missing or stale."""
    needs_refresh = (
        cache is None or (time.time() - float(cache.get("checked_at", 0))) > CACHE_TTL_SECONDS
    )
    if not needs_refresh:
        return
    thread = threading.Thread(target=_refresh_cache_worker, daemon=True, name="dxs-update-check")
    thread.start()


_VERSION_RE = re.compile(r"^(\d+)(?:\.(\d+))?(?:\.(\d+))?")


def _parse_version(v: str) -> tuple[int, int, int]:
    """Parse an X.Y.Z version into a tuple. Pre-release suffixes are ignored.

    Returns (0, 0, 0) on unparseable input — treated as oldest possible.
    """
    m = _VERSION_RE.match(v.strip())
    if not m:
        return (0, 0, 0)
    return (int(m.group(1) or 0), int(m.group(2) or 0), int(m.group(3) or 0))


def is_newer(candidate: str, current: str) -> bool:
    """Return True if `candidate` is a newer version than `current`."""
    return _parse_version(candidate) > _parse_version(current)


def detect_upgrade_command() -> str:
    """Best-effort detection of how dxs was installed.

    Returns the shell command the user should run to upgrade.
    """
    exe = sys.executable
    # uv tool installs land under ~/.local/share/uv/tools/<pkg>/...
    if "/uv/tools/" in exe or "\\uv\\tools\\" in exe:
        return f"uv tool upgrade {PACKAGE_NAME}"
    # pipx installs land under ~/.local/pipx/venvs/<pkg>/...
    if "/pipx/" in exe or "\\pipx\\" in exe:
        return f"pipx upgrade {PACKAGE_NAME}"
    # Fallback: pip in whatever interpreter the user is on
    return f"{exe} -m pip install --upgrade {PACKAGE_NAME}"


def _stderr_is_tty() -> bool:
    """True when stderr is attached to a TTY.

    Only stderr matters — the banner is written there. Piping stdout (e.g.
    ``dxs odata ... | jq``) leaves stderr untouched, so the user still sees
    the banner in their terminal. Redirecting stderr (``2>log``) suppresses
    it, as intended.
    """
    return sys.stderr.isatty()


def _print_banner(latest: str, upgrade_cmd: str) -> None:
    """Print the update banner to stderr."""
    click.echo("", err=True)
    click.echo(
        f"  A new release of dxs is available: {__version__} → {latest}",
        err=True,
    )
    click.echo(f"  To upgrade, run: {upgrade_cmd}", err=True)
    click.echo(f"  https://pypi.org/project/{PACKAGE_NAME}/{latest}/", err=True)


def maybe_show_update_notice(skip: bool = False) -> None:
    """If the cache shows a newer version, print a one-time banner to stderr.

    Always returns quickly — the PyPI fetch happens in a background thread
    that only writes to the cache. The first run on a stale cache prints
    nothing; the next run sees the refreshed cache and prints the banner.
    Dedupe keeps it to one banner per ``NOTIFY_DEDUPE_SECONDS`` window so
    fast-fire commands don't spam.

    Args:
        skip: If True, skip both the check and any cache refresh. Used to
            honor ``--no-update-check``.
    """
    if skip or is_disabled() or _is_ci():
        return
    if not _stderr_is_tty():
        return

    cache = _read_cache()
    _maybe_refresh_async(cache)

    if not cache:
        return

    latest = cache.get("latest")
    if not isinstance(latest, str) or not is_newer(latest, __version__):
        return

    last_notified = float(cache.get("last_notified_at", 0))
    if time.time() - last_notified < NOTIFY_DEDUPE_SECONDS:
        return

    _print_banner(latest, detect_upgrade_command())

    cache["last_notified_at"] = time.time()
    _write_cache(cache)
