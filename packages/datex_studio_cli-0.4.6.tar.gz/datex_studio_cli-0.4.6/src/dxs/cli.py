"""Main CLI entry point for Datex Studio CLI."""

import sys
from collections.abc import Callable
from typing import Any, TypeVar, cast

import click

from dxs import __app_name__, __version__
from dxs.context import DxsContext, pass_context  # re-exported for backward compat
from dxs.core.output import OutputFormat, format_error
from dxs.core.output.redaction import (
    AUTHOR_VERBOSE_FIELDS as _AUTHOR_VERBOSE_FIELDS,  # noqa: F401 — re-exported
)
from dxs.core.output.redaction import (
    _redact_secrets,  # noqa: F401 — re-exported
    _strip_concise,  # noqa: F401 — re-exported
)
from dxs.utils.config import get_settings
from dxs.utils.errors import DxsError

# Re-export so that existing `from dxs.cli import DxsContext, pass_context` still works
__all__ = ["DxsContext", "pass_context"]

F = TypeVar("F", bound=Callable[..., Any])

# Module-level output format, set during CLI initialization.
# Survives Click context teardown so main() error handler can read it.
_last_output_format: OutputFormat = OutputFormat.YAML


def set_last_output_format(fmt: OutputFormat) -> None:
    """Update module-level output format for error handler.

    Called from subgroup commands (e.g. schema) that accept their own -O flag.
    """
    global _last_output_format
    _last_output_format = fmt


def _format_set_in_env_or_config() -> bool:
    """Whether ``default_output_format`` was set explicitly outside CLI flags.

    Used to decide if TTY-auto-script mode should override the default format.
    Returns True when either ``DXS_DEFAULT_OUTPUT_FORMAT`` is in the environment
    or the config file contains a ``default_output_format`` entry.
    """
    import os

    from dxs.utils.config import load_config_file

    if os.environ.get("DXS_DEFAULT_OUTPUT_FORMAT"):
        return True
    try:
        return bool(load_config_file().get("default_output_format"))
    except Exception:  # noqa: BLE001 - config read should never block startup
        return False


def _stdout_is_pipe() -> bool:
    """Whether stdout looks like a non-interactive consumer (pipe/redirect).

    Pulled into a helper so tests can patch it independently of Click's
    CliRunner, which swaps ``sys.stdout`` with a non-TTY StringIO.
    """
    try:
        return not sys.stdout.isatty()
    except (AttributeError, ValueError):
        return False


# Global options shared across all commands
CONTEXT_SETTINGS = {
    "help_option_names": ["-h", "--help"],
    "max_content_width": 120,
}


class DxsGroup(click.Group):
    """Custom Group that shows global options in subcommand help."""

    def format_options(self, ctx: click.Context, formatter: click.HelpFormatter) -> None:
        """Write options to the formatter, including global options."""
        # First write local options
        super().format_options(ctx, formatter)

        # Then add global options section if we have a parent
        if ctx.parent is not None:
            # Get global options from the root command
            root_ctx = ctx
            while root_ctx.parent is not None:
                root_ctx = root_ctx.parent

            if root_ctx.command and hasattr(root_ctx.command, "params"):
                global_opts = []
                for param in root_ctx.command.params:
                    if isinstance(param, click.Option):
                        record = param.get_help_record(ctx)
                        if record:
                            global_opts.append(record)

                if global_opts:
                    with formatter.section("Global Options"):
                        formatter.write_dl(global_opts)


@click.group(cls=DxsGroup, context_settings=CONTEXT_SETTINGS)
@click.version_option(version=__version__, prog_name=__app_name__)
@click.option(
    "-o",
    "--org",
    type=str,
    envvar="DXS_ORG",
    help="Organization ID (overrides default)",
)
@click.option(
    "-e",
    "--env",
    type=str,
    envvar="DXS_ENV",
    help="Environment ID (overrides default)",
)
@click.option(
    "-b",
    "--branch",
    type=int,
    envvar="DXS_BRANCH",
    help="Branch ID (overrides default)",
)
@click.option(
    "-r",
    "--repo",
    type=int,
    envvar="DXS_REPO",
    help="Repository ID (overrides default)",
)
@click.option(
    "-t",
    "--target",
    type=click.Choice(["dev", "qa", "prod"], case_sensitive=False),
    envvar="DXS_TARGET",
    default=None,
    help="API target environment (dev, qa, or prod; default: prod)",
)
@click.option(
    "-O",
    "--output",
    "output_format",
    type=click.Choice(["yaml", "json", "csv"], case_sensitive=False),
    default=None,
    help="Output format (default: yaml)",
)
@click.option(
    "-v",
    "--verbose",
    is_flag=True,
    default=False,
    help="Enable verbose output (show progress messages)",
)
@click.option(
    "-q",
    "--quiet",
    is_flag=True,
    default=False,
    help="Suppress non-essential output (progress messages)",
)
@click.option(
    "-f",
    "--full",
    is_flag=True,
    default=False,
    help="Show full output including null values and verbose metadata",
)
@click.option(
    "--flat-fv/--no-flat-fv",
    "flat_fv",
    default=None,
    help="Flatten Dynamics @OData FormattedValue siblings into clean keys. "
    "Defaults to on with --concise (the default mode); pass --no-flat-fv to opt out.",
)
@click.option(
    "-s",
    "--save",
    "save_path",
    type=click.Path(dir_okay=False, writable=True, path_type=str),
    default=None,
    help="Save output to file (format auto-detected from extension)",
)
@click.option(
    "--force",
    "force_overwrite",
    is_flag=True,
    default=False,
    help="Force overwrite existing file when using --save",
)
@click.option(
    "--diagnose-auth",
    "diagnose_auth",
    is_flag=True,
    default=False,
    help="Show authentication environment variables for debugging",
)
@click.option(
    "--no-update-check",
    "no_update_check",
    is_flag=True,
    default=False,
    help="Skip the PyPI update check for this invocation",
)
@click.pass_context
def cli(
    ctx: click.Context,
    org: str | None,
    env: str | None,
    branch: int | None,
    repo: int | None,
    target: str | None,
    output_format: str | None,
    verbose: bool,
    quiet: bool,
    full: bool,
    flat_fv: bool | None,
    save_path: str | None,
    force_overwrite: bool,
    diagnose_auth: bool,
    no_update_check: bool,
) -> None:
    """Datex Studio CLI - Command-line interface for Datex Studio platform.

    Designed for LLM-based AI agents. Use --output yaml (default) or --output json
    for structured, parseable responses.

    \b
    Examples:
        dxs auth login
        dxs source log --repo 10
        dxs source history userGrid --branch 100
        dxs config list

    \b
    Environment Variables:
        DXS_ORG         Default organization ID
        DXS_ENV         Default environment ID
        DXS_BRANCH      Default branch ID
        DXS_REPO        Default repository ID
        DXS_TARGET      API target environment (dev, qa, prod)

    \b
    Configuration:
        Settings are stored in ~/.datex/config.yaml
        Credentials are stored in ~/.datex/credentials.yaml
    """
    import os

    # Initialize context
    ctx.ensure_object(DxsContext)
    dxs_ctx: DxsContext = ctx.obj

    # Set API base URL based on target environment
    if target:
        target_urls = {
            "dev": "https://dev.wavelength.host/api",
            "qa": "https://qa.wavelength.host/api",
            "prod": "https://wavelength.host/api",
        }
        os.environ["DXS_API_BASE_URL"] = target_urls[target.lower()]

    # Load settings
    settings = get_settings()

    # When stdout is not a TTY (piped/redirected), assume a script consumer:
    # default to JSON output and suppress progress banners unless the user
    # has explicitly chosen otherwise via CLI flag, env var, or config file.
    piped = _stdout_is_pipe()
    click_ctx = click.get_current_context()
    quiet_src = click_ctx.get_parameter_source("quiet")
    fmt_explicit_in_env_or_config = _format_set_in_env_or_config()

    # Set output format (CLI flag > env var > config > TTY auto > default)
    if output_format:
        dxs_ctx.output_format = OutputFormat(output_format.lower())
        dxs_ctx.explicit_output_format = True
    elif fmt_explicit_in_env_or_config and settings.default_output_format:
        dxs_ctx.output_format = OutputFormat(settings.default_output_format.lower())
    elif piped:
        dxs_ctx.output_format = OutputFormat.JSON
    elif settings.default_output_format:
        dxs_ctx.output_format = OutputFormat(settings.default_output_format.lower())
    set_last_output_format(dxs_ctx.output_format)

    # Set verbosity (--verbose enables debug output, --quiet suppresses progress)
    dxs_ctx.verbose = verbose
    if quiet_src == click.core.ParameterSource.COMMANDLINE:
        dxs_ctx.quiet = quiet
    else:
        dxs_ctx.quiet = quiet or piped
    # Concise output is default; --full disables it
    dxs_ctx.concise = not full
    # Flatten Dynamics FormattedValue siblings: follow --concise unless
    # --flat-fv / --no-flat-fv was passed explicitly.
    if flat_fv is None:
        dxs_ctx.flat_fv = dxs_ctx.concise
    else:
        dxs_ctx.flat_fv = flat_fv

    # Set save options
    dxs_ctx.save_path = save_path
    dxs_ctx.force_overwrite = force_overwrite

    # Set context values (CLI flag > env var > config)
    dxs_ctx.org = org or settings.default_org
    dxs_ctx.env = env or settings.default_env
    dxs_ctx.branch = branch or settings.default_branch
    dxs_ctx.repo = repo or settings.default_repo

    # Show auth diagnostics if requested
    if diagnose_auth:
        _show_auth_diagnostics()

    # Stash for the result_callback to honor --no-update-check
    dxs_ctx.no_update_check = no_update_check

    # Telemetry: record invocation start (must come before any subcommand runs).
    # Wrapped so a telemetry bug can never block the CLI.
    try:
        from dxs.core.telemetry import maybe_show_first_run_notice, record_start

        invoked = ctx.invoked_subcommand or "<root>"
        record_start(argv=sys.argv[1:], command=invoked)
        maybe_show_first_run_notice()
    except Exception:  # noqa: BLE001
        pass


def _mask_token(token: str | None, visible_chars: int = 8) -> str:
    """Mask a token for display, showing only first/last few characters.

    Args:
        token: The token to mask, or None.
        visible_chars: Number of characters to show at start and end.

    Returns:
        Masked token string or "(not set)".
    """
    if not token:
        return "(not set)"
    if len(token) <= visible_chars * 2:
        return "***"
    return f"{token[:visible_chars]}...{token[-visible_chars:]}"


def _show_auth_diagnostics() -> None:
    """Display authentication environment variables for debugging."""
    import os

    click.echo("Authentication Environment Variables:", err=True)
    click.echo("-" * 40, err=True)

    # Token environment variables
    env_vars = [
        ("DXS_ACCESS_TOKEN", os.environ.get("DXS_ACCESS_TOKEN")),
        ("DXS_REFRESH_TOKEN", os.environ.get("DXS_REFRESH_TOKEN")),
        ("DXS_DEVOPS_TOKEN", os.environ.get("DXS_DEVOPS_TOKEN")),
        ("DXS_DYNAMICS_TOKEN", os.environ.get("DXS_DYNAMICS_TOKEN")),
    ]

    for name, value in env_vars:
        if value:
            masked = _mask_token(value)
            click.echo(f"  {name}: SET ({masked})", err=True)
        else:
            click.echo(f"  {name}: NOT SET", err=True)

    click.echo("-" * 40, err=True)
    click.echo("", err=True)


# Error handler decorator
def handle_errors(f: F) -> F:
    """Decorator to handle errors and output them in the configured format."""
    import functools

    @click.pass_context
    @functools.wraps(f)
    def wrapper(ctx: click.Context, *args: Any, **kwargs: Any) -> Any:
        dxs_ctx: DxsContext = ctx.obj
        try:
            return ctx.invoke(f, *args, **kwargs)
        except DxsError as e:
            _record_error_silently(e)
            dxs_ctx.output_error(e)
            sys.exit(1)
        except click.ClickException:
            # Let Click handle its own exceptions
            raise
        except Exception as e:
            _record_error_silently(e)
            dxs_ctx.output_error(e)
            sys.exit(1)

    return cast(F, wrapper)


def _record_error_silently(exc: BaseException) -> None:
    """Emit a telemetry error event; never raises."""
    try:
        from dxs.core.telemetry import record_error

        record_error(exc)
    except Exception:  # noqa: BLE001
        pass


# Import and register command groups
# These imports are here to avoid circular imports
def register_commands() -> None:
    """Register all command groups with the CLI."""
    from dxs.commands import (
        api,
        auth,
        config,
        configuration,
        crm,
        datasource,
        devops,
        endpoint,
        env,
        function,
        marketplace,
        odata,
        organization,
        proxy,
        report,
        source,
        studio,
        user,
    )

    cli.add_command(api.api)
    cli.add_command(auth.auth)
    cli.add_command(config.config)
    cli.add_command(config.config, name="settings")
    cli.add_command(configuration.configuration)
    cli.add_command(crm.crm)
    cli.add_command(datasource.datasource)
    cli.add_command(devops.devops)
    cli.add_command(endpoint.endpoint)
    cli.add_command(env.env)
    cli.add_command(function.function)
    cli.add_command(marketplace.marketplace)
    cli.add_command(odata.odata)
    cli.add_command(organization.organization)
    cli.add_command(proxy.proxy)
    cli.add_command(report.report)
    cli.add_command(source.source)
    cli.add_command(studio.studio)
    cli.add_command(user.user)
    # branch and repo are registered as subcommands of source in source.py

    # Late import to avoid circular dependency with schema module
    from dxs.commands import schema

    cli.add_command(schema.schema)

    # Telemetry subcommands (status / enable / disable / test)
    from dxs.commands import telemetry as telemetry_cmd

    cli.add_command(telemetry_cmd.telemetry)


@cli.result_callback()
@click.pass_context
def _after_command(ctx: click.Context, result: Any, **kwargs: Any) -> Any:
    """Run post-command hooks (telemetry success event + PyPI update notice)."""
    from dxs.utils.update_check import maybe_show_update_notice

    dxs_ctx: DxsContext | None = ctx.find_object(DxsContext)

    # Emit a success event. handle_errors-decorated commands never reach here
    # on failure, so the only path through this branch is a successful run.
    try:
        from dxs.core.telemetry import record_end

        ctx_extras = _ctx_extras(dxs_ctx)
        record_end(exit_code=0, ctx_extras=ctx_extras)
    except Exception:  # noqa: BLE001
        pass

    skip = bool(dxs_ctx and dxs_ctx.no_update_check)
    try:
        maybe_show_update_notice(skip=skip)
    except Exception:  # noqa: BLE001 - never let the update check break the CLI
        pass
    return result


def _ctx_extras(dxs_ctx: "DxsContext | None") -> dict[str, Any]:
    """Pluck branch/repo/org/env from DxsContext for telemetry events."""
    if dxs_ctx is None:
        return {}
    return {
        "branch_id": dxs_ctx.branch,
        "repo_id": dxs_ctx.repo,
        "org": dxs_ctx.org,
        "env": dxs_ctx.env,
    }


@cli.command("update")
def update_cmd() -> None:
    """Check PyPI for a newer release and print the upgrade command.

    This command never performs the upgrade itself — run the printed
    command in a fresh shell. This avoids the running-binary file-lock
    issues that any in-process upgrade hits on Windows.
    """
    import time

    from dxs.utils.update_check import (
        PACKAGE_NAME,
        _fetch_latest_version,
        _read_cache,
        _write_cache,
        detect_upgrade_command,
        is_newer,
    )

    click.echo(f"Current version: {__version__}", err=True)
    click.echo("Checking PyPI...", err=True)
    latest = _fetch_latest_version()
    if latest is None:
        click.echo("Could not reach PyPI. Check your network and try again.", err=True)
        sys.exit(1)
    click.echo(f"Latest on PyPI: {latest}", err=True)

    if not is_newer(latest, __version__):
        click.echo("You are on the latest version.", err=True)
        return

    upgrade_cmd = detect_upgrade_command()
    click.echo("", err=True)
    click.echo(f"  A new release of dxs is available: {__version__} → {latest}", err=True)
    click.echo(f"  To upgrade, run: {upgrade_cmd}", err=True)
    click.echo(f"  https://pypi.org/project/{PACKAGE_NAME}/{latest}/", err=True)

    # Refresh the cache and suppress the auto-banner for the next dedupe
    # window — the user has explicitly seen the news.
    now = time.time()
    cache = _read_cache() or {}
    cache["latest"] = latest
    cache["checked_at"] = now
    cache["last_notified_at"] = now
    _write_cache(cache)


# Register commands when module loads
register_commands()


# Main entry point
def main() -> None:
    """Main entry point for the CLI."""
    try:
        try:
            cli()
        except DxsError as e:
            _record_error_silently(e)
            # Use the module-level format captured during CLI init
            # (Click context is torn down before exceptions reach here)
            formatted = format_error(e, _last_output_format)
            click.echo(formatted, err=True)
            sys.exit(1)
        except SystemExit:
            # SystemExit from sys.exit() inside handle_errors — telemetry already
            # recorded an error there; just propagate.
            raise
        except BaseException as e:
            # Anything else escaping cli() shouldn't take telemetry with it.
            _record_error_silently(e)
            raise
    finally:
        try:
            from dxs.core.telemetry import flush

            flush(timeout=0.5)
        except Exception:  # noqa: BLE001
            pass


if __name__ == "__main__":
    main()
