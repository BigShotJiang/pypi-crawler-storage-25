"""Telemetry commands: dxs telemetry [status|enable|disable|test|set-endpoint]."""

from __future__ import annotations

import click

from dxs.cli import DxsContext, pass_context
from dxs.core.telemetry import sender
from dxs.core.telemetry.config import (
    DEFAULT_ENDPOINT,
    load_config,
    set_disabled,
    set_endpoint,
    telemetry_state_path,
)
from dxs.core.telemetry.identity import get_install_id, get_session_id
from dxs.core.telemetry.recorder import build_test_event
from dxs.utils.responses import single


@click.group()
def telemetry() -> None:
    """Manage CLI usage telemetry sent to Datex.

    \b
    Telemetry events are POSTed to a Datex-owned endpoint that validates
    your Entra token and forwards to Datex's analytics backend. The CLI
    never talks to the analytics provider directly, so no third-party
    credentials ever ship in the CLI binary.

    \b
    What is collected: command name, scrubbed arguments, duration, exit
    code, your Datex UPN (when logged in), branch/repo/org IDs, and CLI
    version. See docs/telemetry.md for the complete list of fields.
    """
    pass


@telemetry.command("status")
@pass_context
def telemetry_status(ctx: DxsContext) -> None:
    """Show whether telemetry is enabled and how it's configured."""
    cfg = load_config()
    payload = {
        "enabled": cfg.enabled,
        "endpoint": cfg.endpoint,
        "anonymous_endpoint": cfg.anonymous_endpoint,
        "endpoint_default": DEFAULT_ENDPOINT,
        "disabled_via_env": cfg.disabled_via_env,
        "disabled_via_state_file": cfg.disabled_via_state,
        "debug": cfg.debug,
        "state_file": str(telemetry_state_path()),
        "install_id": get_install_id(),
        "session_id": get_session_id(),
    }
    ctx.output(single(item=payload, semantic_key="telemetry"))


@telemetry.command("disable")
@pass_context
def telemetry_disable(ctx: DxsContext) -> None:
    """Disable telemetry on this machine.

    Persists the opt-out flag to ~/.datex/telemetry.yaml.
    Equivalent to setting ``DXS_TELEMETRY=0`` permanently.
    """
    set_disabled(True)
    ctx.output(
        single(
            item={
                "disabled": True,
                "state_file": str(telemetry_state_path()),
                "message": "Telemetry disabled. Re-enable with: dxs telemetry enable",
            },
            semantic_key="telemetry",
        )
    )


@telemetry.command("enable")
@pass_context
def telemetry_enable(ctx: DxsContext) -> None:
    """Re-enable telemetry on this machine.

    Clears the local opt-out flag. Telemetry only emits when an endpoint
    is also configured (DXS_TELEMETRY_ENDPOINT env var, the state file
    ``endpoint:`` key, or the built-in default once it ships).
    """
    set_disabled(False)
    cfg = load_config()
    payload = {
        "disabled": False,
        "enabled": cfg.enabled,
        "endpoint": cfg.endpoint,
        "message": (
            "Telemetry enabled."
            if cfg.enabled
            else "Local opt-out cleared, but no endpoint is configured — events will not be sent."
        ),
    }
    ctx.output(single(item=payload, semantic_key="telemetry"))


@telemetry.command("set-endpoint")
@click.argument("url", required=False, default=None)
@click.option("--clear", is_flag=True, default=False, help="Remove the configured endpoint")
@pass_context
def telemetry_set_endpoint(ctx: DxsContext, url: str | None, clear: bool) -> None:
    """Set or clear the telemetry endpoint URL in ~/.datex/telemetry.yaml.

    \b
    Examples:
        dxs telemetry set-endpoint https://telemetry.cli.datexstudio.com/v1/events
        dxs telemetry set-endpoint --clear
    """
    if clear:
        set_endpoint(None)
        new_url: str | None = None
    elif url:
        set_endpoint(url)
        new_url = url
    else:
        ctx.output_error(click.UsageError("Provide a URL or pass --clear to remove the endpoint."))
        return

    cfg = load_config()
    ctx.output(
        single(
            item={
                "endpoint": new_url,
                "enabled": cfg.enabled,
                "message": "Endpoint cleared." if clear else f"Endpoint set to {new_url}",
            },
            semantic_key="telemetry",
        )
    )


@telemetry.command("test")
@pass_context
def telemetry_test(ctx: DxsContext) -> None:
    """Send a synthetic event to the telemetry endpoint and report the result.

    Bypasses the queue; emits synchronously so success/failure can be
    surfaced to the user.
    """
    cfg = load_config()
    if not cfg.endpoint:
        ctx.output(
            single(
                item={
                    "ok": False,
                    "reason": (
                        "No telemetry endpoint configured. Set DXS_TELEMETRY_ENDPOINT "
                        "or run: dxs telemetry set-endpoint <url>"
                    ),
                },
                semantic_key="telemetry_test",
            )
        )
        return

    event = build_test_event()
    ok = sender.send_sync(event)
    ctx.output(
        single(
            item={
                "ok": ok,
                "endpoint": cfg.endpoint,
                "anonymous_endpoint": cfg.anonymous_endpoint,
                "event_type": event.get("event_type"),
                "message": (
                    "Event accepted by telemetry service."
                    if ok
                    else "Telemetry service did not accept the event. "
                    "Run with DXS_TELEMETRY_DEBUG=1 to see why."
                ),
            },
            semantic_key="telemetry_test",
        )
    )
