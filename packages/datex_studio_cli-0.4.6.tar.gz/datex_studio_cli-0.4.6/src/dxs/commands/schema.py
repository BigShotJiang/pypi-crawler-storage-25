"""Schema discovery commands for progressive OData entity model exploration.

Provides token-efficient commands for AI agents to discover OData entity structures
by consuming metadata endpoints from datex-application-api.
"""

import argparse
import shlex
import urllib.parse
from collections.abc import Callable
from concurrent.futures import ThreadPoolExecutor
from typing import Any

import click
from pydantic import BaseModel

from dxs.cli import handle_errors
from dxs.context import DxsContext, pass_context
from dxs.core.api.client import ApiClient, classify_http_error
from dxs.core.api.endpoints import FootPrintMetadataEndpoints
from dxs.core.api.metadata_models import (
    ActionDto,
    ActionImportDto,
    AnnotationDto,
    ComplexTypeDto,
    EntitySetDto,
    EntityTypeDto,
    EnumTypeDto,
    FunctionDto,
    FunctionImportDto,
    NavigationPropertyDto,
    ODataListResponse,
    PropertyDto,
    ReferentialConstraintDto,
    SingletonDto,
)
from dxs.core.auth import require_auth
from dxs.utils.click_options import schema_connection_options, schema_list_options
from dxs.utils.errors import ApiError, ValidationError
from dxs.utils.resolvers import resolve_connection_option
from dxs.utils.responses import list_response, single

# ========== Batch Request Parsing ==========

BATCH_SUPPORTED_COMMANDS: frozenset[str] = frozenset(
    {
        "entities",
        "search",
        "describe-entity",
        "describe-relationships",
        "properties",
        "navigation-properties",
        "enums",
        "describe-enum",
        "actions",
        "describe-action",
        "functions",
        "describe-function",
        "complex-types",
        "describe-complex-type",
        "singletons",
        "describe-singleton",
        "action-imports",
        "describe-action-import",
        "function-imports",
        "describe-function-import",
        "describe-properties",
        "describe-navigation-properties",
    }
)

_COMMANDS_WITH_TWO_POSITIONALS: frozenset[str] = frozenset(
    {
        "describe-properties",
        "describe-navigation-properties",
    }
)

# Note: "search" is in _COMMANDS_WITH_POSITIONAL (its term is a positional arg)
# and _COMMANDS_WITH_LIST_OPTIONS (it supports --top/--skip/--orderby/--count),
# but NOT in _COMMANDS_WITH_FILTER or _COMMANDS_WITH_SEARCH because it uses
# its positional argument as the search term rather than --filter/--search flags.
_COMMANDS_WITH_POSITIONAL: frozenset[str] = frozenset(
    {
        "search",
        "describe-entity",
        "describe-relationships",
        "describe-enum",
        "describe-action",
        "describe-function",
        "describe-complex-type",
        "describe-singleton",
        "describe-action-import",
        "describe-function-import",
    }
)

_COMMANDS_WITH_LIST_OPTIONS: frozenset[str] = frozenset(
    {
        "entities",
        "search",
        "properties",
        "navigation-properties",
        "enums",
        "actions",
        "functions",
        "complex-types",
        "singletons",
        "action-imports",
        "function-imports",
    }
)

_COMMANDS_WITH_FILTER: frozenset[str] = frozenset(
    {
        "entities",
        "properties",
        "navigation-properties",
        "enums",
        "actions",
        "functions",
        "complex-types",
        "singletons",
        "action-imports",
        "function-imports",
    }
)

_COMMANDS_WITH_SEARCH: frozenset[str] = frozenset(
    {
        "entities",
        "properties",
        "navigation-properties",
        "enums",
        "actions",
        "functions",
        "complex-types",
        "singletons",
        "action-imports",
        "function-imports",
    }
)

_COMMANDS_WITH_ENTITY_TYPE: frozenset[str] = frozenset(
    {
        "properties",
        "navigation-properties",
    }
)

_COMMANDS_WITH_DESCRIBE_ENTITY_FLAGS: frozenset[str] = frozenset(
    {
        "describe-entity",
    }
)

_COMMANDS_WITH_DEPTH: frozenset[str] = frozenset(
    {
        "describe-relationships",
    }
)


class ParsedRequest(BaseModel):
    """A parsed --request string ready for batch URL assembly."""

    original: str
    command: str
    positional: str | None = None  # entity_name, type_id, query, etc.
    positional2: str | None = None  # second positional for composite-key commands
    top: int | None = None
    skip: int | None = None
    filter_expr: str | None = None
    search_term: str | None = None
    orderby: str | None = None
    entity_type: str | None = None  # --entity-type for properties/navigation-properties
    count: bool = False  # --count flag for all list commands
    # describe-entity display flags
    compact: bool = False
    no_udf: bool = False
    properties_only: bool = False
    nav_only: bool = False
    prop_top: int | None = None
    select: str | None = None
    depth: int | None = None


def _non_negative_int(value: str) -> int:
    """argparse type for non-negative integers (>= 0)."""
    n = int(value)
    if n < 0:
        raise argparse.ArgumentTypeError(f"{value} is not a non-negative integer")
    return n


def _positive_int(value: str) -> int:
    """argparse type for positive integers (>= 1)."""
    n = int(value)
    if n < 1:
        raise argparse.ArgumentTypeError(f"{value} is not a positive integer (minimum 1)")
    return n


def _parse_request(request_str: str) -> ParsedRequest:
    """Parse a --request string into a ParsedRequest.

    Args:
        request_str: A string like 'describe-entity Warehouses' or 'enums --search status'.

    Returns:
        ParsedRequest with all fields populated.

    Raises:
        ValidationError: If the command is unknown, missing required args, or has bad options.
    """
    try:
        tokens = shlex.split(request_str)
    except ValueError as e:
        raise ValidationError(
            message=f"Invalid --request syntax: {e}",
            code="DXS-BATCH-001",
            suggestions=["Check for unmatched quotes in the --request string"],
        ) from e

    if not tokens:
        raise ValidationError(
            message="Empty --request string",
            code="DXS-BATCH-001",
            suggestions=["Provide a command like 'describe-entity Warehouses' or 'enums'"],
        )

    command = tokens[0]
    if command not in BATCH_SUPPORTED_COMMANDS:
        raise ValidationError(
            message=f"Unknown or unsupported command '{command}' in --request",
            code="DXS-BATCH-002",
            suggestions=[f"Supported commands: {', '.join(sorted(BATCH_SUPPORTED_COMMANDS))}"],
        )

    parser = argparse.ArgumentParser(prog=command, add_help=False, exit_on_error=False)

    if command in _COMMANDS_WITH_POSITIONAL:
        parser.add_argument("positional")

    elif command in _COMMANDS_WITH_TWO_POSITIONALS:
        parser.add_argument("positional")
        parser.add_argument("positional2")

    if command in _COMMANDS_WITH_LIST_OPTIONS:
        parser.add_argument(
            "--limit", "--top", "-n", type=_non_negative_int, default=None, dest="top"
        )
        parser.add_argument("--skip", type=_non_negative_int, default=None)
        parser.add_argument("--orderby", type=str, default=None)

    if command in _COMMANDS_WITH_FILTER:
        parser.add_argument("--filter", dest="filter_expr", type=str, default=None)

    if command in _COMMANDS_WITH_SEARCH:
        parser.add_argument("--search", dest="search_term", type=str, default=None)

    if command in _COMMANDS_WITH_ENTITY_TYPE:
        parser.add_argument("--entity-type", "-e", dest="entity_type", type=str, default=None)

    if command in _COMMANDS_WITH_LIST_OPTIONS:
        parser.add_argument("--count", dest="count", action="store_true", default=False)

    if command in _COMMANDS_WITH_DESCRIBE_ENTITY_FLAGS:
        parser.add_argument("--compact", dest="compact", action="store_true", default=False)
        parser.add_argument("--no-udf", dest="no_udf", action="store_true", default=False)
        parser.add_argument(
            "--properties-only", "-P", dest="properties_only", action="store_true", default=False
        )
        parser.add_argument("--nav-only", "-N", dest="nav_only", action="store_true", default=False)
        parser.add_argument("--prop-top", dest="prop_top", type=_non_negative_int, default=None)
        parser.add_argument("--select", dest="select", type=str, default=None)

    if command in _COMMANDS_WITH_DEPTH:
        parser.add_argument("--depth", dest="depth", type=_positive_int, default=None)

    try:
        parsed_args = parser.parse_args(tokens[1:])
    except (argparse.ArgumentError, SystemExit) as e:
        raise ValidationError(
            message=f"Invalid arguments for '{command}' in --request '{request_str}': {e}",
            code="DXS-BATCH-003",
            suggestions=[f"Run 'dxs schema {command} --help' to see valid options"],
        ) from e

    # Post-parse mutual exclusion checks
    if getattr(parsed_args, "properties_only", False) and getattr(parsed_args, "nav_only", False):
        raise ValidationError(
            message=f"Invalid arguments for '{command}' in --request '{request_str}': "
            "--properties-only and --nav-only are mutually exclusive",
            code="DXS-BATCH-003",
            suggestions=[f"Run 'dxs schema {command} --help' to see valid options"],
        )

    return ParsedRequest(
        original=request_str,
        command=command,
        positional=getattr(parsed_args, "positional", None),
        positional2=getattr(parsed_args, "positional2", None),
        top=getattr(parsed_args, "top", None),
        skip=getattr(parsed_args, "skip", None),
        filter_expr=getattr(parsed_args, "filter_expr", None),
        search_term=getattr(parsed_args, "search_term", None),
        orderby=getattr(parsed_args, "orderby", None),
        entity_type=getattr(parsed_args, "entity_type", None),
        count=getattr(parsed_args, "count", False),
        compact=getattr(parsed_args, "compact", False),
        no_udf=getattr(parsed_args, "no_udf", False),
        properties_only=getattr(parsed_args, "properties_only", False),
        nav_only=getattr(parsed_args, "nav_only", False),
        prop_top=getattr(parsed_args, "prop_top", None),
        select=getattr(parsed_args, "select", None),
        depth=getattr(parsed_args, "depth", None),
    )


# ========== End Batch Request Parsing ==========


def _escape_odata_string(value: str) -> str:
    """Escape a string value for safe inclusion in an OData $filter expression."""
    return value.replace("'", "''")


def _to_batch_url(path: str, params: dict[str, str | int], connection_id: int) -> str:
    """Convert a full schema API path + params dict to a batch sub-request relative URL.

    URL-builder functions return full paths like
    /footprintapiconnections/32/schema/EntitySets. The OData $batch endpoint
    expects URLs relative to the schema service root, so we strip the prefix
    and encode params into the query string.

    Args:
        path: Full API path from a URL-builder (e.g., "/footprintapiconnections/32/schema/EntitySets").
        params: OData query params dict (e.g., {"$filter": "name eq 'X'"}).
        connection_id: Connection ID used to build the prefix to strip.

    Returns:
        Relative URL for the batch sub-request (e.g., "EntitySets?%24filter=name%20eq%20%27X%27").

    Note:
        OData $batch sub-request URLs are inline JSON strings, so httpx params= cannot be
        used here. We apply RFC 3986 percent-encoding (urllib.parse.quote, safe="") which
        encodes spaces as %20 rather than the + that httpx/urlencode would produce. The
        FootPrint API accepts both forms; this encoding is intentional and correct.
    """
    prefix = f"/footprintapiconnections/{connection_id}/schema/"
    relative = path.removeprefix(prefix)
    if not params:
        return relative
    query_parts = []
    for k, v in params.items():
        encoded_k = urllib.parse.quote(str(k), safe="")
        encoded_v = urllib.parse.quote(str(v), safe="")
        query_parts.append(f"{encoded_k}={encoded_v}")
    return f"{relative}?{'&'.join(query_parts)}"


def _resolve_connection(
    ctx: DxsContext, connection_id: int | None, connection: str | None, org: str | None
) -> int:
    """Resolve connection ID from either direct ID or name-based lookup."""
    return resolve_connection_option(connection_id, connection, org)


def _unwrap_collection_type(type_id: str) -> str:
    """Unwrap Collection(X) → X, or return type_id unchanged."""
    if type_id.startswith("Collection(") and type_id.endswith(")"):
        return type_id[11:-1]
    return type_id


def _fetch_entity_sets(
    client: ApiClient,
    connection_id: int,
    top: int | None = None,
    skip: int | None = None,
    filter_expr: str | None = None,
    orderby: str | None = None,
) -> list[EntitySetDto]:
    """Fetch entity sets for a connection.

    Args:
        client: Authenticated API client
        connection_id: Connection ID
        top: Maximum number of entity sets to return
        skip: Number of entity sets to skip (for pagination)
        filter_expr: OData $filter expression
        orderby: OData $orderby expression

    Returns:
        List of entity sets
    """
    path, params = _url_for_entity_sets_filtered(
        connection_id, top=top, skip=skip, filter_expr=filter_expr, orderby=orderby
    )
    response = client.get(path, params=params)
    odata_response = ODataListResponse[EntitySetDto](**response)
    return odata_response.value


def _fetch_entity_type(
    client: ApiClient, connection_id: int, type_id: str, expand: str | None = None
) -> EntityTypeDto | None:
    """Fetch a specific entity type by ID using the key endpoint.

    Args:
        client: Authenticated API client
        connection_id: Connection ID
        type_id: Entity type ID (e.g., "Demo.Warehouse")
        expand: Optional OData $expand expression (e.g., "Properties,NavigationProperties")

    Returns:
        Entity type or None if not found
    """
    path, params = FootPrintMetadataEndpoints.entity_type_by_key(
        connection_id, type_id, expand=expand
    )
    response = client.get(path, params=params)
    if not response:
        return None
    return EntityTypeDto(**response)


# ========== Bulk Fetch Functions (Optimized Pattern) ==========


def _fetch_all_entity_types(client: ApiClient, connection_id: int) -> list[EntityTypeDto]:
    """Fetch ALL entity types for a connection in a single HTTP call.

    This is more efficient than fetching entity types individually with filters
    when you need data for multiple entities.

    Args:
        client: Authenticated API client
        connection_id: Connection ID

    Returns:
        List of all entity types
    """
    path, params = _url_for_all_entity_types(connection_id)
    response = client.get(path, params=params)
    odata_response = ODataListResponse[EntityTypeDto](**response)
    return odata_response.value


def _fetch_all_properties(client: ApiClient, connection_id: int) -> list[PropertyDto]:
    """Fetch ALL properties for a connection in a single HTTP call.

    This is more efficient than fetching properties per-entity when you need
    property data for multiple entities. Use _group_by_key() to organize results.

    Args:
        client: Authenticated API client
        connection_id: Connection ID

    Returns:
        List of all properties across all entity types
    """
    path, params = FootPrintMetadataEndpoints.properties(connection_id)  # No filter!
    response = client.get(path, params=params)
    odata_response = ODataListResponse[PropertyDto](**response)
    return odata_response.value


def _fetch_all_navigation_properties(
    client: ApiClient, connection_id: int
) -> list[NavigationPropertyDto]:
    """Fetch ALL navigation properties for a connection in a single HTTP call.

    This is more efficient than fetching nav properties per-entity when you need
    nav property data for multiple entities. Use _group_by_key() to organize results.

    Args:
        client: Authenticated API client
        connection_id: Connection ID

    Returns:
        List of all navigation properties across all entity types
    """
    path, params = FootPrintMetadataEndpoints.navigation_properties(connection_id)  # No filter!
    response = client.get(path, params=params)
    odata_response = ODataListResponse[NavigationPropertyDto](**response)
    return odata_response.value


def _group_by_key(items: list[Any], key_attr: str) -> dict[str, list[Any]]:
    """Group a list of items by a key attribute.

    Args:
        items: List of objects to group
        key_attr: Attribute name to group by (e.g., 'entity_type_id')

    Returns:
        Dictionary mapping key values to lists of items
    """
    result: dict[str, list[Any]] = {}
    for item in items:
        key_value = getattr(item, key_attr)
        if key_value not in result:
            result[key_value] = []
        result[key_value].append(item)
    return result


def _parse_referential_constraints(
    constraints: list[ReferentialConstraintDto] | None,
) -> dict[str, str] | None:
    """Parse referential constraints list into a property→referencedProperty mapping.

    Args:
        constraints: List of ReferentialConstraintDto objects from the API.

    Returns:
        Dictionary mapping FK property name to referenced property name, or None
        if no valid constraints are present.
    """
    if not constraints:
        return None
    result = {
        c.property: c.referenced_property
        for c in constraints
        if c.property and c.referenced_property
    }
    return result if result else None


def _format_annotations(annotations: list[AnnotationDto] | None) -> list[dict] | None:
    """Format annotation list for output, returning None if empty."""
    if not annotations:
        return None
    return [
        {
            k: v
            for k, v in {"term": a.term, "value": a.value, "type": a.type}.items()
            if v is not None
        }
        for a in annotations
    ]


# Annotation terms to promote to top-level boolean flags
_PROMOTED_ANNOTATIONS: dict[str, str] = {
    "Datex.FootPrint.Api.IsUdf": "is_udf",
    "Org.OData.Core.V1.Computed": "is_computed",
    "Org.OData.Core.V1.Immutable": "is_immutable",
}


def _promote_annotations(
    annotations: list[AnnotationDto] | None,
    prop_dict: dict[str, Any],
) -> list[AnnotationDto] | None:
    """Promote known annotations to top-level boolean flags on prop_dict.

    Sets boolean flags for recognized annotation terms (e.g. is_udf, is_computed,
    is_immutable) and returns the remaining unpromoted annotations.
    """
    if not annotations:
        return None
    remaining: list[AnnotationDto] = []
    for ann in annotations:
        flag_name = _PROMOTED_ANNOTATIONS.get(ann.term)
        if flag_name is not None:
            prop_dict[flag_name] = True
        else:
            remaining.append(ann)
    return remaining if remaining else None


def _get_filter_example_value(edm_type: str) -> str:
    """Generate appropriate filter value example based on EDM type.

    Args:
        edm_type: OData EDM type (e.g., 'Edm.Int32', 'Edm.String')

    Returns:
        Example value in correct OData literal format
    """
    # Numeric types
    if edm_type in ("Edm.Int16", "Edm.Int32", "Edm.Int64", "Edm.Byte", "Edm.SByte"):
        return "123"
    if edm_type in ("Edm.Single", "Edm.Double", "Edm.Decimal"):
        return "99.99"

    # Boolean
    if edm_type == "Edm.Boolean":
        return "true"

    # Date/Time types
    if edm_type == "Edm.DateTimeOffset":
        return "2024-01-01T00:00:00Z"
    if edm_type == "Edm.Date":
        return "2024-01-01"
    if edm_type == "Edm.TimeOfDay":
        return "12:30:00"
    if edm_type == "Edm.Duration":
        return "duration'P1D'"

    # GUID
    if edm_type == "Edm.Guid":
        return "12345678-1234-1234-1234-123456789012"

    # Binary
    if edm_type == "Edm.Binary":
        return "binary'T0RhdGE'"

    # String and default
    return "'value'"


def _resolve_entity(
    client: ApiClient,
    connection_id: int,
    entity_name: str,
) -> tuple[EntitySetDto | None, str]:
    """Resolve entity name to entity set and entity type_id using server-side filtering.

    Tries exact match on entity set name first, then falls back to entity type name.
    Uses OData $filter to avoid fetching all entities.

    Args:
        client: Authenticated API client
        connection_id: Connection ID
        entity_name: Entity name (set or type)

    Returns:
        Tuple of (entity_set, type_id) -- entity_set may be None if resolved by type name only

    Raises:
        ValidationError: If entity not found
    """
    # Try exact match on entity set name (server-side filter)
    path, params = _url_for_relationships_resolve(connection_id, entity_name)
    response = client.get(path, params=params)
    entity_sets = ODataListResponse[EntitySetDto](**response).value

    if entity_sets:
        entity_set = entity_sets[0]
        return entity_set, entity_set.type_id

    # Try matching on entity type name or full type ID (case-insensitive)
    lower_name = _escape_odata_string(entity_name.lower())
    path, params = FootPrintMetadataEndpoints.entity_types(
        connection_id,
        filter=f"tolower(name) eq '{lower_name}' or tolower(typeId) eq '{lower_name}'",
    )
    response = client.get(path, params=params)
    matched_types = ODataListResponse[EntityTypeDto](**response).value

    if matched_types:
        entity_type = matched_types[0]
        # Find the entity set for this type
        path, params = FootPrintMetadataEndpoints.entity_sets(
            connection_id, filter=f"typeId eq '{_escape_odata_string(entity_type.type_id)}'"
        )
        response = client.get(path, params=params)
        entity_sets = ODataListResponse[EntitySetDto](**response).value
        matched_set: EntitySetDto | None = entity_sets[0] if entity_sets else None
        return matched_set, entity_type.type_id

    info = _schema_not_found_error("describe-entity", entity_name, connection_id)
    raise ValidationError(
        message=info["message"],
        code=info["code"],
        suggestions=info["suggestions"],
    )


# ========== URL-Builder Functions (shared by commands and batch assembler) ==========


def _url_for_list(
    connection_id: int,
    top: int | None = None,
    skip: int | None = None,
    filter_expr: str | None = None,
    orderby: str | None = None,
) -> tuple[str, dict[str, str | int]]:
    """URL for the schema entities command (entity sets with embedded EntityType)."""
    return FootPrintMetadataEndpoints.entity_sets(
        connection_id,
        top=top,
        skip=skip,
        filter=filter_expr,
        orderby=orderby,
        expand="EntityType",
    )


def _url_with_count(
    path_params: tuple[str, dict[str, str | int]],
) -> tuple[str, dict[str, str | int]]:
    """Wrap a (path, params) result to request only @odata.count.

    Strips $top/$skip, adds $count=true and $top=0 to return the count
    with minimal data transfer -- mirrors how individual --count commands work.
    """
    path, params = path_params
    new_params = {k: v for k, v in params.items() if k not in ("$top", "$skip")}
    new_params["$count"] = "true"
    new_params["$top"] = 0
    return path, new_params


def _url_for_search(
    connection_id: int,
    query: str,
    top: int | None = None,
    skip: int | None = None,
    orderby: str | None = None,
) -> tuple[str, dict[str, str | int]]:
    """URL for the schema search command."""
    return FootPrintMetadataEndpoints.entity_sets(
        connection_id,
        top=top,
        skip=skip,
        orderby=orderby,
        search=query.strip(),
        expand="EntityType",
    )


def _url_for_describe(
    connection_id: int,
    entity_name: str,
) -> tuple[str, dict[str, str | int]]:
    """URL for the schema describe-entity command (entity set + full type expand).

    Uses case-insensitive matching via tolower() for agent-friendly resolution.
    """
    lower_name = _escape_odata_string(entity_name.lower())
    return FootPrintMetadataEndpoints.entity_sets(
        connection_id,
        filter=f"tolower(name) eq '{lower_name}'",
        expand="EntityType($expand=Properties,NavigationProperties)",
    )


def _url_for_relationships_resolve(
    connection_id: int,
    entity_name: str,
) -> tuple[str, dict[str, str | int]]:
    """Phase-1 URL for relationships: resolve entity set → get type_id.

    Uses case-insensitive matching via tolower() for agent-friendly resolution.
    """
    lower_name = _escape_odata_string(entity_name.lower())
    return FootPrintMetadataEndpoints.entity_sets(
        connection_id,
        filter=f"tolower(name) eq '{lower_name}'",
    )


def _url_for_all_entity_sets(
    connection_id: int,
) -> tuple[str, dict[str, str | int]]:
    """Bulk fetch all entity sets (used by relationships phase-1)."""
    return FootPrintMetadataEndpoints.entity_sets(connection_id)


def _url_for_entity_sets_filtered(
    connection_id: int,
    top: int | None = None,
    skip: int | None = None,
    filter_expr: str | None = None,
    orderby: str | None = None,
) -> tuple[str, dict[str, str | int]]:
    """Filtered/paged fetch of entity sets without EntityType expand.

    Used by _fetch_entity_sets for filtered/paged queries that do not require
    embedded EntityType data (contrast with _url_for_list which adds expand=EntityType).
    """
    return FootPrintMetadataEndpoints.entity_sets(
        connection_id,
        top=top,
        skip=skip,
        filter=filter_expr,
        orderby=orderby,
    )


def _url_for_all_entity_types(
    connection_id: int,
) -> tuple[str, dict[str, str | int]]:
    """Bulk fetch all entity types (used by relationships phase-1)."""
    return FootPrintMetadataEndpoints.entity_types(connection_id)


def _url_for_nav_properties_by_type(
    connection_id: int,
    entity_type_id: str,
) -> tuple[str, dict[str, str | int]]:
    """Phase-2 URL for relationships: fetch nav properties for a resolved type_id."""
    return FootPrintMetadataEndpoints.navigation_properties(
        connection_id,
        filter=f"EntityTypeId eq '{_escape_odata_string(entity_type_id)}'",
    )


def _url_for_properties(
    connection_id: int,
    top: int | None = None,
    skip: int | None = None,
    filter_expr: str | None = None,
    search: str | None = None,
    orderby: str | None = None,
    entity_type: str | None = None,
) -> tuple[str, dict[str, str | int]]:
    """URL for the Properties endpoint, optionally filtered by entity type."""
    filter_parts = []
    if entity_type:
        filter_parts.append(f"EntityTypeId eq '{_escape_odata_string(entity_type)}'")
    if filter_expr:
        filter_parts.append(filter_expr)
    combined_filter = " and ".join(filter_parts) if filter_parts else None
    return FootPrintMetadataEndpoints.properties(
        connection_id, top=top, skip=skip, filter=combined_filter, search=search, orderby=orderby
    )


def _url_for_nav_properties(
    connection_id: int,
    top: int | None = None,
    skip: int | None = None,
    filter_expr: str | None = None,
    search: str | None = None,
    orderby: str | None = None,
    entity_type: str | None = None,
) -> tuple[str, dict[str, str | int]]:
    """URL for the NavigationProperties endpoint, optionally filtered by entity type."""
    filter_parts = []
    if entity_type:
        filter_parts.append(f"EntityTypeId eq '{_escape_odata_string(entity_type)}'")
    if filter_expr:
        filter_parts.append(filter_expr)
    combined_filter = " and ".join(filter_parts) if filter_parts else None
    return FootPrintMetadataEndpoints.navigation_properties(
        connection_id, top=top, skip=skip, filter=combined_filter, search=search, orderby=orderby
    )


def _url_for_enums(
    connection_id: int,
    top: int | None = None,
    skip: int | None = None,
    filter_expr: str | None = None,
    search: str | None = None,
    orderby: str | None = None,
) -> tuple[str, dict[str, str | int]]:
    """URL for the schema enums command."""
    return FootPrintMetadataEndpoints.enum_types(
        connection_id,
        top=top,
        skip=skip,
        filter=filter_expr,
        search=search,
        orderby=orderby,
    )


def _url_for_describe_enum(connection_id: int, type_id: str) -> tuple[str, dict[str, str | int]]:
    """URL for the schema describe-enum command."""
    return FootPrintMetadataEndpoints.enum_type_by_key(connection_id, type_id)


def _url_for_actions(
    connection_id: int,
    top: int | None = None,
    skip: int | None = None,
    filter_expr: str | None = None,
    search: str | None = None,
    orderby: str | None = None,
) -> tuple[str, dict[str, str | int]]:
    """URL for the schema actions command."""
    return FootPrintMetadataEndpoints.actions(
        connection_id,
        top=top,
        skip=skip,
        filter=filter_expr,
        search=search,
        orderby=orderby,
    )


def _url_for_describe_action(
    connection_id: int, action_id: str
) -> tuple[str, dict[str, str | int]]:
    """URL for the schema describe-action command."""
    return FootPrintMetadataEndpoints.action_by_key(connection_id, action_id)


def _url_for_functions(
    connection_id: int,
    top: int | None = None,
    skip: int | None = None,
    filter_expr: str | None = None,
    search: str | None = None,
    orderby: str | None = None,
) -> tuple[str, dict[str, str | int]]:
    """URL for the schema functions command."""
    return FootPrintMetadataEndpoints.functions(
        connection_id,
        top=top,
        skip=skip,
        filter=filter_expr,
        search=search,
        orderby=orderby,
    )


def _url_for_describe_function(
    connection_id: int, function_id: str
) -> tuple[str, dict[str, str | int]]:
    """URL for the schema describe-function command."""
    return FootPrintMetadataEndpoints.function_by_key(connection_id, function_id)


def _url_for_complex_types(
    connection_id: int,
    top: int | None = None,
    skip: int | None = None,
    filter_expr: str | None = None,
    search: str | None = None,
    orderby: str | None = None,
) -> tuple[str, dict[str, str | int]]:
    """URL for the schema complex-types command."""
    return FootPrintMetadataEndpoints.complex_types(
        connection_id,
        top=top,
        skip=skip,
        filter=filter_expr,
        search=search,
        orderby=orderby,
    )


def _url_for_describe_complex_type(
    connection_id: int, type_id: str
) -> tuple[str, dict[str, str | int]]:
    """URL for the schema describe-complex-type command."""
    return FootPrintMetadataEndpoints.complex_type_by_key(
        connection_id, type_id, expand="Properties,NavigationProperties"
    )


def _url_for_singletons(
    connection_id: int,
    top: int | None = None,
    skip: int | None = None,
    filter_expr: str | None = None,
    search: str | None = None,
    orderby: str | None = None,
) -> tuple[str, dict[str, str | int]]:
    """URL for the schema singletons command."""
    return FootPrintMetadataEndpoints.singletons(
        connection_id,
        top=top,
        skip=skip,
        filter=filter_expr,
        search=search,
        orderby=orderby,
    )


def _url_for_describe_singleton(
    connection_id: int, singleton_name: str
) -> tuple[str, dict[str, str | int]]:
    """URL for the schema describe-singleton command."""
    return FootPrintMetadataEndpoints.singleton_by_key(
        connection_id,
        singleton_name,
        expand="EntityType($expand=Properties,NavigationProperties)",
    )


def _url_for_action_imports(
    connection_id: int,
    top: int | None = None,
    skip: int | None = None,
    filter_expr: str | None = None,
    search: str | None = None,
    orderby: str | None = None,
) -> tuple[str, dict[str, str | int]]:
    """URL for the schema action-imports command."""
    return FootPrintMetadataEndpoints.action_imports(
        connection_id,
        top=top,
        skip=skip,
        filter=filter_expr,
        search=search,
        orderby=orderby,
    )


def _url_for_describe_action_import(
    connection_id: int, import_name: str
) -> tuple[str, dict[str, str | int]]:
    """URL for the schema describe-action-import command."""
    return FootPrintMetadataEndpoints.action_import_by_key(
        connection_id, import_name, expand="Action"
    )


def _url_for_function_imports(
    connection_id: int,
    top: int | None = None,
    skip: int | None = None,
    filter_expr: str | None = None,
    search: str | None = None,
    orderby: str | None = None,
) -> tuple[str, dict[str, str | int]]:
    """URL for the schema function-imports command."""
    return FootPrintMetadataEndpoints.function_imports(
        connection_id,
        top=top,
        skip=skip,
        filter=filter_expr,
        search=search,
        orderby=orderby,
    )


def _url_for_describe_function_import(
    connection_id: int, import_name: str
) -> tuple[str, dict[str, str | int]]:
    """URL for the schema describe-function-import command."""
    return FootPrintMetadataEndpoints.function_import_by_key(
        connection_id, import_name, expand="Function"
    )


def _url_for_describe_property(
    connection_id: int,
    entity_type_id: str,
    property_name: str,
) -> tuple[str, dict[str, str | int]]:
    """URL for the schema describe-properties command (single property by composite key)."""
    return FootPrintMetadataEndpoints.property_by_key(
        connection_id,
        entity_type_id,
        property_name,
    )


def _url_for_describe_navigation_property(
    connection_id: int,
    entity_type_id: str,
    property_name: str,
) -> tuple[str, dict[str, str | int]]:
    """URL for the schema describe-navigation-properties command (single nav property by composite key)."""
    return FootPrintMetadataEndpoints.navigation_property_by_key(
        connection_id,
        entity_type_id,
        property_name,
    )


# ========== Response-Formatter Functions (shared by commands and batch assembler) ==========


def _format_list_result(body: dict[str, Any]) -> list[dict[str, Any]]:
    """Format an EntitySets OData response into the list command's output."""
    entity_sets = ODataListResponse[EntitySetDto](**body).value
    return [
        {
            "name": es.name,
            "entity_type": es.entity_type.type_id,
            "key_properties": es.entity_type.key_names,
        }
        for es in entity_sets
        if es.entity_type
    ]


def _format_search_result(body: dict[str, Any]) -> list[dict[str, Any]]:
    """Format an EntitySets $search response into the search command's output."""
    return _format_list_result(body)  # identical shape


def _build_entity_details_from_type(
    entity_set_name: str | None,
    entity_type_id: str,
    entity_type: EntityTypeDto,
    *,
    concise: bool = True,
    all_entity_sets: list[EntitySetDto] | None = None,
) -> dict[str, Any]:
    """Build the entity_details dict from a resolved EntityTypeDto.

    Called by both _format_describe_result (happy path) and describe_entity
    fallback path to produce identical output.

    When concise=True (default), omits is_key: false, nullable: true, and
    empty annotations to reduce token usage.

    When all_entity_sets is provided, nav properties include target_entity_set
    and expand_path fields (avoiding the need for a separate describe-relationships call).
    """
    properties = entity_type.properties or []
    nav_properties = entity_type.navigation_properties or []

    # Build property list
    property_list = []
    for prop in properties:
        prop_dict: dict[str, Any] = {
            "name": prop.name,
            "type": prop.type_id,
        }
        # In concise mode, only show nullable when false (interesting case) and is_key when true
        if concise:
            if not prop.is_nullable:
                prop_dict["nullable"] = False
            if prop.is_key:
                prop_dict["is_key"] = True
        else:
            prop_dict["nullable"] = prop.is_nullable
            prop_dict["is_key"] = prop.is_key
        if prop.is_computed:
            prop_dict["is_computed"] = True
        if prop.is_udf:
            prop_dict["is_udf"] = True
        if prop.max_length is not None:
            prop_dict["max_length"] = prop.max_length
        if prop.precision is not None:
            prop_dict["precision"] = prop.precision
        if prop.scale is not None:
            prop_dict["scale"] = prop.scale
        if prop.unicode is not None:
            prop_dict["unicode"] = prop.unicode
        if prop.default_value is not None:
            prop_dict["default_value"] = prop.default_value
        if prop.srid is not None:
            prop_dict["srid"] = prop.srid
        # Promote known annotations to top-level booleans
        remaining = _promote_annotations(prop.annotations, prop_dict)
        if remaining:
            formatted = _format_annotations(remaining)
            if formatted:
                prop_dict["annotations"] = formatted
        property_list.append(prop_dict)

    # Build navigation property list
    entity_set_by_type: dict[str, EntitySetDto] | None = None
    if all_entity_sets:
        entity_set_by_type = {es.type_id: es for es in all_entity_sets}

    nav_property_list = []
    for nav in nav_properties:
        nav_dict: dict[str, Any] = {
            "name": nav.name,
            "type": nav.type_id,
            "multiplicity": "many" if nav.is_collection else "one",
            "partner": nav.partner_name,
        }
        if nav.referential_constraints:
            constraints = _parse_referential_constraints(nav.referential_constraints)
            if constraints:
                formatted_constraints = [
                    f"{fk_prop} -> {ref_prop}" for fk_prop, ref_prop in constraints.items()
                ]
                nav_dict["referential_constraint"] = (
                    formatted_constraints
                    if len(formatted_constraints) > 1
                    else formatted_constraints[0]
                    if formatted_constraints
                    else None
                )
        # Add expand_path and target_entity_set when entity sets are available
        if entity_set_by_type and entity_set_name:
            target_type_id = _unwrap_collection_type(nav.type_id)
            target_es = entity_set_by_type.get(target_type_id)
            if target_es:
                nav_dict["target_entity_set"] = target_es.name
            nav_dict["expand_path"] = f"{entity_set_name}?$expand={nav.name}"
        nav_property_list.append(nav_dict)

    entity_details: dict[str, Any] = {
        "entity_set_name": entity_set_name,
        "entity_type": entity_type_id,
        "namespace": entity_type.namespace,
        "keys": entity_type.key_names,
        "properties": property_list,
        "navigation_properties": nav_property_list,
    }

    if entity_type.base_type_id:
        entity_details["base_type"] = entity_type.base_type_id

    if entity_type.has_stream:
        entity_details["has_stream"] = True

    return entity_details


def _format_describe_result(
    body: dict[str, Any],
    *,
    concise: bool = True,
    all_entity_sets: list[EntitySetDto] | None = None,
) -> dict[str, Any] | None:
    """Format an EntitySets describe response (single entity with expanded type) into entity_details dict.

    Returns None if the response contains no matching entity set with an entity type,
    which triggers the fallback path in the describe_entity command.
    """
    result_sets = ODataListResponse[EntitySetDto](**body).value
    if not (result_sets and result_sets[0].entity_type):
        return None

    entity_set = result_sets[0]
    entity_type = entity_set.entity_type
    assert entity_type is not None  # guarded above

    return _build_entity_details_from_type(
        entity_set.name,
        entity_set.type_id,
        entity_type,
        concise=concise,
        all_entity_sets=all_entity_sets,
    )


def _format_relationships_result(
    entity_set: EntitySetDto | None,
    all_entity_sets: list[EntitySetDto],
    all_entity_types: list[EntityTypeDto],
    nav_props_body: dict[str, Any],
) -> list[dict[str, Any]]:
    """Format nav properties + entity lookups into the relationships command's output.

    Args:
        entity_set: The resolved entity set (from phase-1 resolve), or None if resolved by type only.
        all_entity_sets: All entity sets (for target lookup by type_id).
        all_entity_types: All entity types (for key property lookup).
        nav_props_body: Raw OData response body from NavigationProperties endpoint.

    Returns:
        List of relationship dicts, each with name, target_entity_type, target_entity_set,
        multiplicity, expand_path, etc.
    """
    if not nav_props_body:
        return []

    # Build lookups for efficient in-memory joins
    entity_set_by_type = {es.type_id: es for es in all_entity_sets}
    entity_type_by_id = {et.type_id: et for et in all_entity_types}

    # Parse nav properties from raw response body
    nav_properties = ODataListResponse[NavigationPropertyDto](**nav_props_body).value

    relationships = []
    for nav in nav_properties:
        # Extract target type ID (remove Collection() wrapper if present)
        target_type_id = _unwrap_collection_type(nav.type_id)

        # Lookup target entity set and type (no HTTP calls)
        target_entity_set_obj = entity_set_by_type.get(target_type_id)
        target_type = entity_type_by_id.get(target_type_id)

        # Get target keys if type found
        target_keys = target_type.key_names if target_type else None

        rel_dict: dict[str, Any] = {
            "name": nav.name,
            "target_entity_type": target_type_id,
            "target_entity_set": target_entity_set_obj.name if target_entity_set_obj else None,
            "multiplicity": "many" if nav.is_collection else "one",
            "partner": nav.partner_name,
            "expand_path": f"{entity_set.name}?$expand={nav.name}" if entity_set else None,
            "target_key_properties": target_keys,
        }

        # Parse and add referential constraints if present
        if nav.referential_constraints:
            constraints = _parse_referential_constraints(nav.referential_constraints)
            if constraints:
                # Format as readable "ForeignKeyProperty -> TargetKeyProperty" pairs
                rel_dict["referential_constraint"] = [
                    f"{fk_prop} -> {ref_prop}" for fk_prop, ref_prop in constraints.items()
                ]

        relationships.append(rel_dict)

    return relationships


def _format_enums_result(body: dict[str, Any], *, concise: bool = True) -> list[dict[str, Any]]:
    """Format EnumTypes list response."""
    _LIMIT = 5
    enum_types = ODataListResponse[EnumTypeDto](**body).value
    result = []
    for enum in enum_types:
        d: dict[str, Any] = {
            "name": enum.name,
            "type_id": enum.type_id,
            "namespace": enum.namespace,
            "underlying_type": enum.underlying_type,
        }
        if not concise or enum.is_flags:
            d["is_flags"] = enum.is_flags
        if enum.members:
            shown = enum.members[:_LIMIT]
            d["members"] = [{"name": m.name, "value": m.value} for m in shown]
            if len(enum.members) > _LIMIT:
                d["members_truncated"] = True
                d["members_total"] = len(enum.members)
        result.append(d)
    return result


def _format_describe_enum_result(body: dict[str, Any]) -> dict[str, Any]:
    """Format single EnumType response."""
    enum = EnumTypeDto(**body)
    d: dict[str, Any] = {
        "name": enum.name,
        "type_id": enum.type_id,
        "namespace": enum.namespace,
        "underlying_type": enum.underlying_type,
        "is_flags": enum.is_flags,
    }
    if enum.members:
        d["members"] = [{"name": m.name, "value": m.value} for m in enum.members]
    return d


def _format_action_summary(action: ActionDto, *, concise: bool = True) -> dict[str, Any]:
    """Format a single ActionDto into a summary dict."""
    d: dict[str, Any] = {
        "name": action.name,
        "namespace": action.namespace,
    }
    if action.action_id:
        d["action_id"] = action.action_id
    if not concise or action.is_bound:
        d["is_bound"] = action.is_bound
    parameters = []
    binding_type = None
    if action.parameters:
        for param in action.parameters:
            if param.name == "bindingParameter":
                binding_type = param.type_id
            else:
                p: dict[str, Any] = {
                    "name": param.name,
                    "type": param.type_id,
                }
                if not concise or not param.nullable:
                    p["nullable"] = param.nullable
                if not concise or param.is_collection:
                    p["is_collection"] = param.is_collection
                parameters.append(p)
    if binding_type:
        d["binding_type"] = binding_type
    if action.return_type:
        d["return_type"] = action.return_type.type_id
        if action.return_type.is_collection:
            d["return_type_collection"] = True
    if parameters:
        d["parameters"] = parameters
    return d


def _format_actions_result(body: dict[str, Any], *, concise: bool = True) -> list[dict[str, Any]]:
    """Format Actions list response."""
    actions = ODataListResponse[ActionDto](**body).value
    return [_format_action_summary(a, concise=concise) for a in actions]


def _format_describe_action_result(body: dict[str, Any], *, concise: bool = True) -> dict[str, Any]:
    """Format single Action response."""
    return _format_action_summary(ActionDto(**body), concise=concise)


def _format_function_summary(func: FunctionDto, *, concise: bool = True) -> dict[str, Any]:
    """Format a single FunctionDto into a summary dict."""
    d: dict[str, Any] = {
        "name": func.name,
        "namespace": func.namespace,
    }
    if func.function_id:
        d["function_id"] = func.function_id
    if not concise or func.is_bound:
        d["is_bound"] = func.is_bound
    if not concise or func.is_composable:
        d["is_composable"] = func.is_composable
    parameters = []
    binding_type = None
    if func.parameters:
        for param in func.parameters:
            if param.name == "bindingParameter":
                binding_type = param.type_id
            else:
                p: dict[str, Any] = {
                    "name": param.name,
                    "type": param.type_id,
                }
                if not concise or not param.nullable:
                    p["nullable"] = param.nullable
                if not concise or param.is_collection:
                    p["is_collection"] = param.is_collection
                parameters.append(p)
    if binding_type:
        d["binding_type"] = binding_type
    if func.return_type:
        d["return_type"] = func.return_type.type_id
        if func.return_type.is_collection:
            d["return_type_collection"] = True
    if parameters:
        d["parameters"] = parameters
    return d


def _format_functions_result(body: dict[str, Any], *, concise: bool = True) -> list[dict[str, Any]]:
    """Format Functions list response."""
    return [
        _format_function_summary(f, concise=concise)
        for f in ODataListResponse[FunctionDto](**body).value
    ]


def _format_describe_function_result(
    body: dict[str, Any], *, concise: bool = True
) -> dict[str, Any]:
    """Format single Function response."""
    return _format_function_summary(FunctionDto(**body), concise=concise)


def _format_complex_types_result(
    body: dict[str, Any], *, concise: bool = True
) -> list[dict[str, Any]]:
    """Format ComplexTypes list response."""
    types = ODataListResponse[ComplexTypeDto](**body).value
    result = []
    for ct in types:
        d: dict[str, Any] = {
            "name": ct.name,
            "type_id": ct.type_id,
            "namespace": ct.namespace,
        }
        if not concise or ct.is_open_type:
            d["is_open_type"] = ct.is_open_type
        if ct.base_type_id:
            d["base_type"] = ct.base_type_id
        result.append(d)
    return result


def _format_describe_complex_type_result(body: dict[str, Any]) -> dict[str, Any]:
    """Format single ComplexType response (with expanded Properties and NavigationProperties)."""
    complex_type = ComplexTypeDto(**body)
    type_details: dict[str, Any] = {
        "name": complex_type.name,
        "type_id": complex_type.type_id,
        "namespace": complex_type.namespace,
        "is_open_type": complex_type.is_open_type,
    }
    if complex_type.base_type_id:
        type_details["base_type"] = complex_type.base_type_id
    if complex_type.properties:
        property_list = []
        for prop in complex_type.properties:
            prop_dict: dict[str, Any] = {
                "name": prop.name,
                "type": prop.type_id,
                "nullable": prop.is_nullable,
            }
            if prop.is_key:
                prop_dict["is_key"] = True
            if prop.is_computed:
                prop_dict["is_computed"] = True
            if prop.is_udf:
                prop_dict["is_udf"] = True
            if prop.max_length is not None:
                prop_dict["max_length"] = prop.max_length
            if prop.precision is not None:
                prop_dict["precision"] = prop.precision
            if prop.scale is not None:
                prop_dict["scale"] = prop.scale
            if prop.unicode is not None:
                prop_dict["unicode"] = prop.unicode
            if prop.default_value is not None:
                prop_dict["default_value"] = prop.default_value
            if prop.srid is not None:
                prop_dict["srid"] = prop.srid
            # Promote known annotations to top-level booleans
            remaining = _promote_annotations(prop.annotations, prop_dict)
            if remaining:
                formatted = _format_annotations(remaining)
                if formatted:
                    prop_dict["annotations"] = formatted
            property_list.append(prop_dict)
        type_details["properties"] = property_list
    if complex_type.navigation_properties:
        nav_property_list = []
        for nav in complex_type.navigation_properties:
            nav_dict: dict[str, Any] = {
                "name": nav.name,
                "type": nav.type_id,
                "multiplicity": "many" if nav.is_collection else "one",
            }
            if nav.partner_name:
                nav_dict["partner"] = nav.partner_name
            nav_property_list.append(nav_dict)
        type_details["navigation_properties"] = nav_property_list
    return type_details


def _format_singletons_result(body: dict[str, Any]) -> list[dict[str, Any]]:
    """Format Singletons list response."""
    singletons = ODataListResponse[SingletonDto](**body).value
    return [
        {"name": s.name, "namespace": s.namespace, "entity_type": s.type_id} for s in singletons
    ]


def _format_describe_singleton_result(
    body: dict[str, Any], *, concise: bool = True
) -> dict[str, Any]:
    """Format single Singleton response (with expanded EntityType including Properties and NavigationProperties).

    Raises ValidationError if the entity type is missing from the response.
    """
    singleton = SingletonDto(**body)
    entity_type = singleton.entity_type
    if not entity_type:
        raise ValidationError(
            message=f"Entity type for singleton '{singleton.name}' could not be resolved",
            code="DXS-SCHEMA-007",
        )
    # Reuse entity details builder, then replace entity_set_name with singleton name/namespace
    details = _build_entity_details_from_type(
        None, entity_type.type_id, entity_type, concise=concise
    )
    details.pop("entity_set_name", None)
    details.pop("has_stream", None)
    return {"name": singleton.name, "namespace": singleton.namespace, **details}


def _format_action_imports_result(body: dict[str, Any]) -> list[dict[str, Any]]:
    """Format ActionImports list response."""
    imports = ODataListResponse[ActionImportDto](**body).value
    return [{"name": ai.name, "action_id": ai.action_id} for ai in imports]


def _format_describe_action_import_result(body: dict[str, Any]) -> dict[str, Any]:
    """Format single ActionImport response (with expanded Action)."""
    action_import = ActionImportDto(**body)
    import_details: dict[str, Any] = {
        "name": action_import.name,
        "action_id": action_import.action_id,
    }
    if action_import.action:
        import_details["action"] = _format_action_summary(action_import.action)
    return import_details


def _format_function_imports_result(body: dict[str, Any]) -> list[dict[str, Any]]:
    """Format FunctionImports list response."""
    imports = ODataListResponse[FunctionImportDto](**body).value
    return [{"name": fi.name, "function_id": fi.function_id} for fi in imports]


def _format_describe_function_import_result(body: dict[str, Any]) -> dict[str, Any]:
    """Format single FunctionImport response (with expanded Function)."""
    function_import = FunctionImportDto(**body)
    import_details: dict[str, Any] = {
        "name": function_import.name,
        "function_id": function_import.function_id,
    }
    if function_import.function:
        import_details["function"] = _format_function_summary(function_import.function)
    return import_details


def _format_properties_result(body: dict[str, Any]) -> list[dict[str, Any]]:
    """Format Properties list response (matches list_properties command output)."""
    props = ODataListResponse[PropertyDto](**body).value
    result = []
    for prop in props:
        prop_dict: dict[str, Any] = {
            "entity_type_id": prop.entity_type_id,
            "name": prop.name,
            "type": prop.type_id,
            "nullable": prop.is_nullable,
            "is_key": prop.is_key,
        }
        if prop.is_computed:
            prop_dict["is_computed"] = True
        if prop.is_udf:
            prop_dict["is_udf"] = True
        if prop.max_length is not None:
            prop_dict["max_length"] = prop.max_length
        result.append(prop_dict)
    return result


def _format_nav_properties_result(body: dict[str, Any]) -> list[dict[str, Any]]:
    """Format NavigationProperties list response (matches list_navigation_properties output)."""
    nav_props = ODataListResponse[NavigationPropertyDto](**body).value
    result = []
    for nav in nav_props:
        nav_dict: dict[str, Any] = {
            "entity_type_id": nav.entity_type_id,
            "name": nav.name,
            "target_type": nav.type_id,
            "multiplicity": "many" if nav.is_collection else "one",
        }
        if nav.partner_name:
            nav_dict["partner"] = nav.partner_name
        if nav.referential_constraints:
            constraints = _parse_referential_constraints(nav.referential_constraints)
            if constraints:
                nav_dict["referential_constraint"] = [
                    f"{fk} -> {ref}" for fk, ref in constraints.items()
                ]
        result.append(nav_dict)
    return result


def _format_describe_property_result(body: dict[str, Any]) -> dict[str, Any]:
    """Format single Property response (by composite key)."""
    prop = PropertyDto(**body)
    prop_dict: dict[str, Any] = {
        "entity_type_id": prop.entity_type_id,
        "name": prop.name,
        "type": prop.type_id,
        "nullable": prop.is_nullable,
        "is_key": prop.is_key,
    }
    if prop.is_computed:
        prop_dict["is_computed"] = True
    if prop.is_udf:
        prop_dict["is_udf"] = True
    if prop.max_length is not None:
        prop_dict["max_length"] = prop.max_length
    if prop.precision is not None:
        prop_dict["precision"] = prop.precision
    if prop.scale is not None:
        prop_dict["scale"] = prop.scale
    if prop.unicode is not None:
        prop_dict["unicode"] = prop.unicode
    if prop.default_value is not None:
        prop_dict["default_value"] = prop.default_value
    if prop.srid is not None:
        prop_dict["srid"] = prop.srid
    # Promote known annotations to top-level booleans
    remaining = _promote_annotations(prop.annotations, prop_dict)
    if remaining:
        formatted = _format_annotations(remaining)
        if formatted:
            prop_dict["annotations"] = formatted
    return prop_dict


def _format_describe_navigation_property_result(body: dict[str, Any]) -> dict[str, Any]:
    """Format single NavigationProperty response (by composite key)."""
    nav = NavigationPropertyDto(**body)
    nav_dict: dict[str, Any] = {
        "entity_type_id": nav.entity_type_id,
        "name": nav.name,
        "target_type": nav.type_id,
        "multiplicity": "many" if nav.is_collection else "one",
    }
    if nav.partner_name:
        nav_dict["partner"] = nav.partner_name
    if nav.referential_constraints:
        constraints = _parse_referential_constraints(nav.referential_constraints)
        if constraints:
            nav_dict["referential_constraint"] = [
                f"{fk_prop} -> {ref_prop}" for fk_prop, ref_prop in constraints.items()
            ]
    return nav_dict


# ========== Batch Assembler Functions ==========


def _build_url(
    command: str, connection_id: int, req: ParsedRequest
) -> tuple[str, dict[str, str | int]] | None:
    """Build URL for a batch sub-request using the command-specific URL builder."""
    builder = _BATCH_URL_BUILDERS.get(command)
    if builder is None:
        return None
    result: tuple[str, dict[str, str | int]] = builder(connection_id, req)
    return result


# Module-level URL builders: each accepts (connection_id, req) and returns (path, params).
_BATCH_URL_BUILDERS: dict[
    str,
    Callable[[int, "ParsedRequest"], tuple[str, dict[str, str | int]]],
] = {
    "entities": lambda cid, r: (
        _url_with_count(
            _url_for_search(cid, r.search_term, None, None, r.orderby)
            if r.search_term
            else _url_for_entity_sets_filtered(cid, filter_expr=r.filter_expr, orderby=r.orderby)
        )
        if r.count
        else (
            _url_for_search(cid, r.search_term, r.top, r.skip, r.orderby)
            if r.search_term
            else _url_for_list(cid, r.top, r.skip, r.filter_expr, r.orderby)
        )
    ),
    "search": lambda cid, r: (
        _url_with_count(_url_for_search(cid, r.positional or "", None, None, r.orderby))
        if r.count
        else _url_for_search(cid, r.positional or "", r.top, r.skip, r.orderby)
    ),
    "describe-entity": lambda cid, r: _url_for_describe(cid, r.positional or ""),
    "properties": lambda cid, r: (
        _url_with_count(
            _url_for_properties(
                cid, None, None, r.filter_expr, r.search_term, r.orderby, r.entity_type
            )
        )
        if r.count
        else _url_for_properties(
            cid, r.top, r.skip, r.filter_expr, r.search_term, r.orderby, r.entity_type
        )
    ),
    "navigation-properties": lambda cid, r: (
        _url_with_count(
            _url_for_nav_properties(
                cid, None, None, r.filter_expr, r.search_term, r.orderby, r.entity_type
            )
        )
        if r.count
        else _url_for_nav_properties(
            cid, r.top, r.skip, r.filter_expr, r.search_term, r.orderby, r.entity_type
        )
    ),
    "enums": lambda cid, r: (
        _url_with_count(_url_for_enums(cid, None, None, r.filter_expr, r.search_term, r.orderby))
        if r.count
        else _url_for_enums(cid, r.top, r.skip, r.filter_expr, r.search_term, r.orderby)
    ),
    "describe-enum": lambda cid, r: _url_for_describe_enum(cid, r.positional or ""),
    "actions": lambda cid, r: (
        _url_with_count(_url_for_actions(cid, None, None, r.filter_expr, r.search_term, r.orderby))
        if r.count
        else _url_for_actions(cid, r.top, r.skip, r.filter_expr, r.search_term, r.orderby)
    ),
    "describe-action": lambda cid, r: _url_for_describe_action(cid, r.positional or ""),
    "functions": lambda cid, r: (
        _url_with_count(
            _url_for_functions(cid, None, None, r.filter_expr, r.search_term, r.orderby)
        )
        if r.count
        else _url_for_functions(cid, r.top, r.skip, r.filter_expr, r.search_term, r.orderby)
    ),
    "describe-function": lambda cid, r: _url_for_describe_function(cid, r.positional or ""),
    "complex-types": lambda cid, r: (
        _url_with_count(
            _url_for_complex_types(cid, None, None, r.filter_expr, r.search_term, r.orderby)
        )
        if r.count
        else _url_for_complex_types(cid, r.top, r.skip, r.filter_expr, r.search_term, r.orderby)
    ),
    "describe-complex-type": lambda cid, r: _url_for_describe_complex_type(cid, r.positional or ""),
    "singletons": lambda cid, r: (
        _url_with_count(
            _url_for_singletons(cid, None, None, r.filter_expr, r.search_term, r.orderby)
        )
        if r.count
        else _url_for_singletons(cid, r.top, r.skip, r.filter_expr, r.search_term, r.orderby)
    ),
    "describe-singleton": lambda cid, r: _url_for_describe_singleton(cid, r.positional or ""),
    "action-imports": lambda cid, r: (
        _url_with_count(
            _url_for_action_imports(cid, None, None, r.filter_expr, r.search_term, r.orderby)
        )
        if r.count
        else _url_for_action_imports(cid, r.top, r.skip, r.filter_expr, r.search_term, r.orderby)
    ),
    "describe-action-import": lambda cid, r: _url_for_describe_action_import(
        cid, r.positional or ""
    ),
    "function-imports": lambda cid, r: (
        _url_with_count(
            _url_for_function_imports(cid, None, None, r.filter_expr, r.search_term, r.orderby)
        )
        if r.count
        else _url_for_function_imports(cid, r.top, r.skip, r.filter_expr, r.search_term, r.orderby)
    ),
    "describe-function-import": lambda cid, r: _url_for_describe_function_import(
        cid, r.positional or ""
    ),
    "describe-properties": lambda cid, r: _url_for_describe_property(
        cid, r.positional or "", r.positional2 or ""
    ),
    "describe-navigation-properties": lambda cid, r: _url_for_describe_navigation_property(
        cid, r.positional or "", r.positional2 or ""
    ),
}

# Module-level batch response formatters: command name → formatter function.
_BATCH_FORMATTERS: dict[str, Callable[[dict[str, Any]], Any]] = {
    "entities": _format_list_result,
    "search": _format_search_result,
    "properties": _format_properties_result,
    "navigation-properties": _format_nav_properties_result,
    "enums": _format_enums_result,
    "describe-enum": _format_describe_enum_result,
    "actions": _format_actions_result,
    "describe-action": _format_describe_action_result,
    "functions": _format_functions_result,
    "describe-function": _format_describe_function_result,
    "complex-types": _format_complex_types_result,
    "describe-complex-type": _format_describe_complex_type_result,
    "singletons": _format_singletons_result,
    "describe-singleton": _format_describe_singleton_result,
    "action-imports": _format_action_imports_result,
    "describe-action-import": _format_describe_action_import_result,
    "function-imports": _format_function_imports_result,
    "describe-function-import": _format_describe_function_import_result,
    "describe-properties": _format_describe_property_result,
    "describe-navigation-properties": _format_describe_navigation_property_result,
}


def _build_phase1_requests(
    parsed_requests: list[ParsedRequest],
    connection_id: int,
) -> tuple[list[dict[str, str]], bool]:
    """Build the phase-1 batch sub-request list.

    Returns:
        (batch_requests, has_relationships) -- has_relationships triggers phase 2.

    Request IDs follow the pattern "{index}:{command_name}" for per-request entries
    and "shared:{name}" for shared bulk-fetch entries added once for all relationships.
    """
    batch_requests: list[dict[str, str]] = []
    has_relationships = any(r.command == "describe-relationships" for r in parsed_requests)

    for i, req in enumerate(parsed_requests):
        if req.command == "describe-relationships":
            path, params = _url_for_relationships_resolve(connection_id, req.positional or "")
            batch_requests.append(
                {
                    "id": f"{i}:describe-relationships_resolve",
                    "method": "GET",
                    "url": _to_batch_url(path, params, connection_id),
                }
            )
        else:
            result = _build_url(req.command, connection_id, req)
            if result:
                path, params = result
                batch_requests.append(
                    {
                        "id": f"{i}:{req.command}",
                        "method": "GET",
                        "url": _to_batch_url(path, params, connection_id),
                    }
                )

    if has_relationships:
        path, params = _url_for_all_entity_sets(connection_id)
        batch_requests.append(
            {
                "id": "shared:all_entity_sets",
                "method": "GET",
                "url": _to_batch_url(path, params, connection_id),
            }
        )
        path, params = _url_for_all_entity_types(connection_id)
        batch_requests.append(
            {
                "id": "shared:all_entity_types",
                "method": "GET",
                "url": _to_batch_url(path, params, connection_id),
            }
        )

    return batch_requests, has_relationships


def _build_phase2_requests(
    parsed_requests: list[ParsedRequest],
    phase1_bodies: dict[str, dict[str, Any]],
    connection_id: int,
) -> list[dict[str, str]]:
    """Build the phase-2 batch sub-requests for navigation properties.

    Called only when has_relationships is True. Reads type_id from the phase-1
    entity-resolve responses and builds NavigationProperties URLs.

    Args:
        parsed_requests: Full list of parsed requests (same as phase 1).
        phase1_bodies: Dict mapping phase-1 request IDs to their response bodies.
        connection_id: Connection ID.

    Returns:
        List of batch sub-request dicts for phase 2.
    """
    phase2_requests: list[dict[str, str]] = []

    for i, req in enumerate(parsed_requests):
        if req.command != "describe-relationships":
            continue

        resolve_body = phase1_bodies.get(f"{i}:describe-relationships_resolve", {})
        if not resolve_body:
            continue

        entity_sets = ODataListResponse[EntitySetDto](**resolve_body).value
        if not entity_sets:
            continue

        type_id = entity_sets[0].type_id
        path, params = _url_for_nav_properties_by_type(connection_id, type_id)
        phase2_requests.append(
            {
                "id": f"{i}:describe-relationships_nav",
                "method": "GET",
                "url": _to_batch_url(path, params, connection_id),
            }
        )

    return phase2_requests


def _build_phase3_requests(
    parsed_requests: list[ParsedRequest],
    phase2_bodies: dict[str, dict[str, Any]],
    connection_id: int,
) -> list[dict[str, str]]:
    """Build phase-3 batch sub-requests for depth-2 relationship exploration.

    When describe-relationships requests have --depth >= 2, fetches navigation
    properties for each unique target entity type found in the phase-2 results.

    Args:
        parsed_requests: Full list of parsed requests (same as phases 1-2).
        phase2_bodies: Dict mapping phase-2 request IDs to their response bodies.
        connection_id: Connection ID.

    Returns:
        List of batch sub-request dicts for phase 3.
    """
    phase3_requests: list[dict[str, str]] = []
    seen_type_ids: set[str] = set()

    for i, req in enumerate(parsed_requests):
        if req.command != "describe-relationships":
            continue
        if req.depth is None or req.depth < 2:
            continue

        nav_resp = phase2_bodies.get(f"{i}:describe-relationships_nav", {})
        if not nav_resp:
            continue

        nav_props = ODataListResponse[NavigationPropertyDto](**nav_resp).value if nav_resp else []

        for nav in nav_props:
            target_type_id = _unwrap_collection_type(nav.type_id)

            if target_type_id in seen_type_ids:
                continue
            seen_type_ids.add(target_type_id)

            path, params = _url_for_nav_properties_by_type(connection_id, target_type_id)
            phase3_requests.append(
                {
                    "id": f"shared:depth2_nav_{target_type_id}",
                    "method": "GET",
                    "url": _to_batch_url(path, params, connection_id),
                }
            )

    return phase3_requests


def _execute_batch(
    client: ApiClient,
    connection_id: int,
    parsed_requests: list[ParsedRequest],
) -> tuple[list[dict[str, Any]], int]:
    """Execute all parsed requests in at most 3 OData $batch HTTP calls.

    Phase 1: All primary requests + entity resolution for describe-relationships.
    Phase 2: Nav properties for resolved relationship entities.
    Phase 3: Nav properties for target entity types (only when --depth >= 2).

    Args:
        client: Authenticated API client.
        connection_id: FootPrint API connection ID.
        parsed_requests: List of parsed --request entries.

    Returns:
        (results_list, http_calls_count) where results_list contains one entry
        per parsed_request, each with {request, success, data|error} keys.
    """
    batch_path = FootPrintMetadataEndpoints.batch(connection_id)

    # --- Pre-resolve short names for describe-action / describe-function ---
    # These commands accept short names (e.g. "CreateOrder") that must be resolved
    # to fully-qualified IDs (e.g. "Datex.FootPrint.Api.CreateOrder") before the
    # batch URL is built. Resolution requires individual HTTP calls.
    pre_resolve_errors: dict[int, dict[str, Any]] = {}
    for i, req in enumerate(parsed_requests):
        if req.command == "describe-action" and req.positional and "." not in req.positional:
            try:
                req.positional = _resolve_short_action_id(client, connection_id, req.positional)
            except (ValidationError, Exception) as exc:
                code = exc.code if isinstance(exc, ValidationError) else "DXS-BATCH-500"
                message = exc.message if isinstance(exc, ValidationError) else str(exc)
                suggestions = exc.suggestions if isinstance(exc, ValidationError) else None
                error_dict: dict[str, Any] = {"code": code, "message": message}
                if suggestions:
                    error_dict["suggestions"] = suggestions
                pre_resolve_errors[i] = {
                    "request": req.original,
                    "success": False,
                    "error": error_dict,
                }
        elif req.command == "describe-function" and req.positional and "." not in req.positional:
            try:
                req.positional = _resolve_short_function_id(client, connection_id, req.positional)
            except (ValidationError, Exception) as exc:
                code = exc.code if isinstance(exc, ValidationError) else "DXS-BATCH-500"
                message = exc.message if isinstance(exc, ValidationError) else str(exc)
                suggestions = exc.suggestions if isinstance(exc, ValidationError) else None
                error_dict = {"code": code, "message": message}
                if suggestions:
                    error_dict["suggestions"] = suggestions
                pre_resolve_errors[i] = {
                    "request": req.original,
                    "success": False,
                    "error": error_dict,
                }

    # --- Phase 1 ---
    phase1_requests, has_relationships = _build_phase1_requests(parsed_requests, connection_id)
    phase1_raw = client.post_batch(batch_path, phase1_requests)
    phase1_by_id: dict[str, dict[str, Any]] = {r["id"]: r for r in phase1_raw}
    http_calls = 1

    # --- Phase 2 (only when relationships are present) ---
    phase2_by_id: dict[str, dict[str, Any]] = {}
    if has_relationships:
        phase1_bodies = {k: (v.get("body") or {}) for k, v in phase1_by_id.items()}
        phase2_requests = _build_phase2_requests(parsed_requests, phase1_bodies, connection_id)
        if phase2_requests:
            phase2_raw = client.post_batch(batch_path, phase2_requests)
            phase2_by_id = {r["id"]: r for r in phase2_raw}
            http_calls = 2

    # --- Phase 3 (only when depth >= 2 relationships are present) ---
    phase3_by_id: dict[str, dict[str, Any]] = {}
    has_depth2 = has_relationships and any(
        r.command == "describe-relationships" and r.depth is not None and r.depth >= 2
        for r in parsed_requests
    )
    if has_depth2 and phase2_by_id:
        phase2_bodies = {k: (v.get("body") or {}) for k, v in phase2_by_id.items()}
        phase3_requests = _build_phase3_requests(parsed_requests, phase2_bodies, connection_id)
        if phase3_requests:
            phase3_raw = client.post_batch(batch_path, phase3_requests)
            phase3_by_id = {r["id"]: r for r in phase3_raw}
            http_calls = 3

    # --- Pre-fetch entity sets for describe-entity nav enrichment ---
    # When any request is describe-entity, fetch all entity sets once so
    # _format_describe_result can populate target_entity_set and expand_path
    # on navigation properties (matching the standalone command behaviour).
    nav_entity_sets: list[EntitySetDto] | None = None
    has_describe_entity = any(r.command == "describe-entity" for r in parsed_requests)
    if has_describe_entity:
        try:
            nav_entity_sets = _fetch_entity_sets(client, connection_id)
        except Exception:
            nav_entity_sets = None  # degrade gracefully -- nav enrichment omitted

    # --- Assemble results ---
    results: list[dict[str, Any]] = []
    for i, req in enumerate(parsed_requests):
        if i in pre_resolve_errors:
            results.append(pre_resolve_errors[i])
        else:
            results.append(
                _assemble_batch_result(
                    req,
                    i,
                    phase1_by_id,
                    phase2_by_id,
                    connection_id,
                    phase3_by_id,
                    all_entity_sets=nav_entity_sets,
                    client=client,
                )
            )

    return results, http_calls


# Single source of truth for domain-specific 404 errors across all schema describe-* commands.
# Used by both standalone commands (raise ValidationError) and batch assembler (_error dict).
_SCHEMA_NOT_FOUND: dict[str, tuple[str, str, str, str]] = {
    # command → (code, resource_label, list_command, hint)
    "describe-entity": (
        "DXS-SCHEMA-001",
        "Entity",
        "search",
        "Use 'dxs schema search <term>' to find entities",
    ),
    "describe-relationships": (
        "DXS-SCHEMA-001",
        "Entity",
        "search",
        "Use 'dxs schema search <term>' to find entities",
    ),
    "describe-enum": (
        "DXS-SCHEMA-002",
        "Enum type",
        "enums",
        "TypeIds are case-sensitive (e.g. Datex.FootPrint.Api.SomeName)",
    ),
    "describe-action": (
        "DXS-SCHEMA-003",
        "Action",
        "actions",
        "ActionIds are case-sensitive (e.g. Datex.FootPrint.Api.SomeName)",
    ),
    "describe-function": (
        "DXS-SCHEMA-004",
        "Function",
        "functions",
        "FunctionIds are case-sensitive (e.g. Datex.FootPrint.Api.SomeName)",
    ),
    "describe-complex-type": (
        "DXS-SCHEMA-005",
        "Complex type",
        "complex-types",
        "TypeIds are case-sensitive (e.g. Datex.FootPrint.Api.SomeName)",
    ),
    "describe-singleton": (
        "DXS-SCHEMA-006",
        "Singleton",
        "singletons",
        "Singleton names are case-sensitive",
    ),
    "describe-action-import": (
        "DXS-SCHEMA-008",
        "Action import",
        "action-imports",
        "Action import names are case-sensitive",
    ),
    "describe-function-import": (
        "DXS-SCHEMA-009",
        "Function import",
        "function-imports",
        "Function import names are case-sensitive",
    ),
    "describe-properties": (
        "DXS-SCHEMA-010",
        "Property",
        "properties",
        "If this is a navigation property, use 'dxs schema describe-navigation-properties' instead. Names are case-sensitive.",
    ),
    "describe-navigation-properties": (
        "DXS-SCHEMA-011",
        "Navigation property",
        "navigation-properties",
        "If this is a scalar property, use 'dxs schema describe-properties' instead. Names are case-sensitive.",
    ),
}


def _schema_not_found_error(
    command: str,
    name: str,
    connection_id: int | None = None,
    *,
    entity_type_id: str | None = None,
) -> dict[str, Any]:
    """Build a domain-specific not-found error for a schema command.

    Used by both standalone commands (to raise ValidationError) and the batch
    assembler (to return an error dict).  Single source of truth for error
    codes, messages, and suggestions.

    Args:
        command: The schema command name (e.g. "describe-function").
        name: The resource identifier that was not found.
        connection_id: Optional connection ID for richer suggestions.
        entity_type_id: For describe-properties/describe-navigation-properties,
            the entity type that was searched.
    """
    code, label, list_cmd, case_hint = _SCHEMA_NOT_FOUND[command]

    # Build message -- include entity_type_id context for property commands
    if entity_type_id and command in ("describe-properties", "describe-navigation-properties"):
        message = f"{label} '{name}' not found on entity type '{entity_type_id}'"
    else:
        message = f"{label} '{name}' not found"

    # Build suggestions -- include -c and --entity-type when available
    conn_flag = f" -c {connection_id}" if connection_id else ""
    if entity_type_id and command in ("describe-properties", "describe-navigation-properties"):
        suggestions = [
            f"Use 'dxs schema {list_cmd}{conn_flag} --entity-type {entity_type_id}' to list available {list_cmd.replace('-', ' ')}",
            case_hint,
        ]
    else:
        suggestions = [
            f"Use 'dxs schema {list_cmd}{conn_flag}' to find the {label}",
            case_hint,
        ]

    return {"code": code, "message": message, "suggestions": suggestions}


def _assemble_batch_result(
    req: ParsedRequest,
    index: int,
    phase1_by_id: dict[str, dict[str, Any]],
    phase2_by_id: dict[str, dict[str, Any]],
    connection_id: int | None = None,
    phase3_by_id: dict[str, dict[str, Any]] | None = None,
    all_entity_sets: list[EntitySetDto] | None = None,
    client: ApiClient | None = None,
) -> dict[str, Any]:
    """Assemble one result entry for a single parsed request."""

    def _error(
        code: str,
        message: str,
        suggestions: list[str] | None = None,
        details: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        error_dict: dict[str, Any] = {"code": code, "message": message}
        if suggestions:
            error_dict["suggestions"] = suggestions
        if details:
            error_dict["details"] = details
        return {
            "request": req.original,
            "success": False,
            "error": error_dict,
        }

    def _ok(data: Any, warnings: list[str] | None = None) -> dict[str, Any]:
        result: dict[str, Any] = {"request": req.original, "success": True, "data": data}
        if warnings:
            result["warnings"] = warnings
        return result

    def _http_error(response: dict[str, Any]) -> dict[str, Any]:
        status = response.get("status", 0)
        # For 404 on describe-* commands, use domain-specific errors.
        if status == 404 and req.command in _SCHEMA_NOT_FOUND:
            if req.command in _COMMANDS_WITH_TWO_POSITIONALS:
                # e.g. describe-properties Demo.Warehouse LookupCode
                name = req.positional2 or req.command
                entity_type = req.positional
            else:
                name = req.positional or req.command
                entity_type = None
            info = _schema_not_found_error(
                req.command,
                name,
                connection_id=connection_id,
                entity_type_id=entity_type,
            )
            return _error(info["code"], info["message"], suggestions=info["suggestions"])
        info = classify_http_error(
            status,
            body=response.get("body"),
        )
        return _error(
            info["code"],
            info["message"],
            suggestions=info.get("suggestions"),
            details=info.get("details"),
        )

    # --- describe-entity ---
    if req.command == "describe-entity":
        resp = phase1_by_id.get(f"{index}:describe-entity")
        if resp is None:
            return _error(
                "DXS-BATCH-MISSING",
                f"No batch response received for 'describe-entity' (index {index})",
            )
        if resp.get("status") != 200:
            return _http_error(resp)
        try:
            data = _format_describe_result(resp.get("body") or {}, all_entity_sets=all_entity_sets)
        except Exception as exc:
            return _error("DXS-BATCH-500", f"Failed to parse 'describe-entity' response: {exc}")
        if data is None:
            info = _schema_not_found_error(
                "describe-entity", req.positional or "", connection_id=connection_id
            )
            return _error(info["code"], info["message"], suggestions=info["suggestions"])
        # Apply describe-entity display flags (compact, no_udf, prop_top, select, etc.)
        select_warnings: list[str] = []
        if (
            req.compact
            or req.no_udf
            or req.properties_only
            or req.nav_only
            or req.prop_top is not None
            or req.select
        ):
            data = _apply_describe_filters(
                data,
                properties_only=req.properties_only,
                nav_only=req.nav_only,
                no_udf=req.no_udf,
                prop_top=req.prop_top,
                compact=req.compact,
                select=req.select,
            )
            # Detect unmatched --select fields (mirrors single-command warning logic)
            if req.select:
                select_set = {s.strip().lower() for s in req.select.split(",") if s.strip()}
                matched = {p["name"].lower() for p in data.get("properties", [])} | {
                    n["name"].lower() for n in data.get("navigation_properties", [])
                }
                unmatched = select_set - matched
                if unmatched:
                    select_warnings.append(
                        f"--select field(s) not found: {', '.join(sorted(unmatched))}"
                    )
        return _ok(data, warnings=select_warnings or None)

    # --- describe-relationships ---
    if req.command == "describe-relationships":
        resolve_resp = phase1_by_id.get(f"{index}:describe-relationships_resolve")
        if resolve_resp is None:
            return _error(
                "DXS-BATCH-MISSING",
                f"No batch response received for 'describe-relationships' (index {index})",
            )
        if resolve_resp.get("status") != 200:
            return _http_error(resolve_resp)

        try:
            resolve_body = resolve_resp.get("body") or {}
            entity_sets = (
                ODataListResponse[EntitySetDto](**resolve_body).value if resolve_body else []
            )
        except Exception as exc:
            return _error(
                "DXS-BATCH-500", f"Failed to parse 'describe-relationships' resolve response: {exc}"
            )
        if not entity_sets:
            info = _schema_not_found_error(
                "describe-relationships", req.positional or "", connection_id=connection_id
            )
            msg = (
                info["message"]
                + ". Note: batch 'describe-relationships' matches by entity set name only -- "
                "use the standalone 'dxs schema describe-relationships' command for type-name fallback."
            )
            return _error(info["code"], msg, suggestions=info["suggestions"])

        entity_set = entity_sets[0]
        all_sets_body = phase1_by_id.get("shared:all_entity_sets", {}).get("body") or {}
        all_types_body = phase1_by_id.get("shared:all_entity_types", {}).get("body") or {}
        nav_resp = phase2_by_id.get(f"{index}:describe-relationships_nav", {})

        try:
            all_sets = (
                ODataListResponse[EntitySetDto](**all_sets_body).value if all_sets_body else []
            )
            all_types = (
                ODataListResponse[EntityTypeDto](**all_types_body).value if all_types_body else []
            )
        except Exception as exc:
            return _error(
                "DXS-BATCH-500",
                f"Failed to parse shared metadata for 'describe-relationships': {exc}",
            )

        nav_body = nav_resp.get("body") or {} if nav_resp.get("status") == 200 else {}
        try:
            rel_data = _format_relationships_result(entity_set, all_sets, all_types, nav_body)
        except Exception as exc:
            return _error(
                "DXS-BATCH-500", f"Failed to format 'describe-relationships' result: {exc}"
            )

        # Depth-2: attach nested_relationships from phase-3 responses
        p3 = phase3_by_id or {}
        if req.depth is not None and req.depth >= 2 and rel_data and p3:
            entity_set_by_type = {es.type_id: es for es in all_sets}
            for rel in rel_data:
                target_type = rel.get("target_entity_type")
                if not target_type:
                    continue
                depth2_resp = p3.get(f"shared:depth2_nav_{target_type}", {})
                depth2_body = (
                    depth2_resp.get("body") or {} if depth2_resp.get("status") == 200 else {}
                )
                if not depth2_body:
                    continue
                try:
                    target_navs = (
                        ODataListResponse[NavigationPropertyDto](**depth2_body).value
                        if depth2_body
                        else []
                    )
                except Exception:
                    continue
                nested: list[dict[str, Any]] = []
                for nav in target_navs:
                    t_type_id = _unwrap_collection_type(nav.type_id)
                    target_es = entity_set_by_type.get(t_type_id)
                    nested.append(
                        {
                            "name": nav.name,
                            "target_type": t_type_id,
                            "multiplicity": "many" if nav.is_collection else "one",
                            "expand_path": f"$expand={nav.name}" if target_es else None,
                        }
                    )
                rel["nested_relationships"] = nested

        # Add nested expand hint (matches standalone command output)
        nested_expand_example = None
        if rel_data:
            expand_parts = [rel["name"] for rel in rel_data[:2]]
            nested_expand_example = f"{entity_set.name}?$expand={','.join(expand_parts)}"

        return {
            "request": req.original,
            "success": True,
            "data": rel_data,
            "query_hints": {"nested_expand_example": nested_expand_example},
        }

    # --- all other single-call commands ---
    resp = phase1_by_id.get(f"{index}:{req.command}")
    if resp is None:
        return _error(
            "DXS-BATCH-MISSING",
            f"No batch response received for '{req.command}' (index {index})",
        )
    if resp.get("status") != 200:
        return _http_error(resp)
    body = resp.get("body") or {}

    # --count returns @odata.count, not a value list (all list commands)
    if req.count and req.command in _COMMANDS_WITH_LIST_OPTIONS:
        count_data: dict[str, Any] = {"count": body.get("@odata.count", 0)}
        if req.command == "search":
            count_data["query"] = req.positional or ""
        return _ok(count_data)

    formatter = _BATCH_FORMATTERS.get(req.command)
    if formatter:
        try:
            data = formatter(body)
            # Inline complex type fields for describe-action/describe-function
            # (matches standalone behavior at lines 3717, 3918)
            if (
                req.command in ("describe-action", "describe-function")
                and client is not None
                and connection_id is not None
            ):
                type_cache: dict[str, list[dict[str, str]]] = {}
                _inline_complex_fields(client, connection_id, data, type_cache)
            return _ok(data)
        except ValidationError as exc:
            return _error(exc.code or "DXS-BATCH-500", exc.message)
        except Exception as exc:
            return _error("DXS-BATCH-500", f"Failed to parse '{req.command}' response: {exc}")

    return _error("DXS-BATCH-999", f"No formatter for command '{req.command}'")


def _is_complex_type_ref(type_id: str) -> bool:
    """Check if a type_id refers to a complex type (not an EDM primitive).

    Returns True if the type contains a '.' and doesn't start with 'Edm.'.
    Also unwraps Collection(...) wrapper.
    """
    unwrapped = _unwrap_collection_type(type_id)
    return "." in unwrapped and not unwrapped.startswith("Edm.")


def _inline_complex_fields(
    client: ApiClient,
    connection_id: int,
    operation_details: dict[str, Any],
    type_cache: dict[str, list[dict[str, str]]],
) -> None:
    """Inline complex type fields into action/function parameter and return type dicts.

    For each parameter or return type that references a complex type, fetches the
    complex type definition and adds a 'fields' key with [{name, type}, ...].
    Uses type_cache to avoid duplicate HTTP calls.
    """

    def _fetch_fields(ct_type_id: str) -> list[dict[str, str]]:
        if ct_type_id in type_cache:
            return type_cache[ct_type_id]
        try:
            path, params = FootPrintMetadataEndpoints.complex_type_by_key(
                connection_id, ct_type_id, expand="Properties"
            )
            body = client.get(path, params=params)
            ct = ComplexTypeDto(**body)
            fields = [{"name": p.name, "type": p.type_id} for p in (ct.properties or [])]
        except Exception:
            fields = []
        type_cache[ct_type_id] = fields
        return fields

    # Inline into parameters
    for param in operation_details.get("parameters", []):
        raw_type = param.get("type", "")
        unwrapped = _unwrap_collection_type(raw_type)
        if _is_complex_type_ref(raw_type):
            fields = _fetch_fields(unwrapped)
            if fields:
                param["fields"] = fields

    # Inline into return type
    rt = operation_details.get("return_type", "")
    if rt and _is_complex_type_ref(rt):
        unwrapped = _unwrap_collection_type(rt)
        fields = _fetch_fields(unwrapped)
        if fields:
            operation_details["return_type_fields"] = fields


def _resolve_short_action_id(client: ApiClient, connection_id: int, action_id: str) -> str:
    """Resolve a short action name to its fully-qualified ActionId.

    If action_id contains no '.', searches for an action with that name.
    Returns the qualified ID if exactly one match, raises on ambiguity or not found.
    If action_id already contains '.', returns it unchanged.
    """
    if "." in action_id:
        return action_id
    safe_name = _escape_odata_string(action_id)
    path, params = FootPrintMetadataEndpoints.actions(
        connection_id, filter=f"name eq '{safe_name}'"
    )
    response = client.get(path, params=params)
    matches = ODataListResponse[ActionDto](**response).value
    if len(matches) == 1:
        return matches[0].action_id or f"{matches[0].namespace}.{matches[0].name}"
    if len(matches) == 0:
        info = _schema_not_found_error("describe-action", action_id, connection_id)
        raise ValidationError(
            message=info["message"], code=info["code"], suggestions=info["suggestions"]
        )
    # Ambiguous -- list candidates
    candidates = [a.action_id or f"{a.namespace}.{a.name}" for a in matches]
    raise ValidationError(
        message=f"Ambiguous action name '{action_id}' matches {len(matches)} actions",
        code="DXS-SCHEMA-003",
        suggestions=[f"Use fully-qualified ID: {c}" for c in candidates[:5]],
    )


def _resolve_short_function_id(client: ApiClient, connection_id: int, function_id: str) -> str:
    """Resolve a short function name to its fully-qualified FunctionId.

    Same logic as _resolve_short_action_id but for functions.
    """
    if "." in function_id:
        return function_id
    safe_name = _escape_odata_string(function_id)
    path, params = FootPrintMetadataEndpoints.functions(
        connection_id, filter=f"name eq '{safe_name}'"
    )
    response = client.get(path, params=params)
    matches = ODataListResponse[FunctionDto](**response).value
    if len(matches) == 1:
        return matches[0].function_id or f"{matches[0].namespace}.{matches[0].name}"
    if len(matches) == 0:
        info = _schema_not_found_error("describe-function", function_id, connection_id)
        raise ValidationError(
            message=info["message"], code=info["code"], suggestions=info["suggestions"]
        )
    candidates = [f.function_id or f"{f.namespace}.{f.name}" for f in matches]
    raise ValidationError(
        message=f"Ambiguous function name '{function_id}' matches {len(matches)} functions",
        code="DXS-SCHEMA-004",
        suggestions=[f"Use fully-qualified ID: {c}" for c in candidates[:5]],
    )


def _resolve_short_enum_id(client: ApiClient, connection_id: int, type_id: str) -> str:
    """Resolve short enum name to fully-qualified TypeId.

    If type_id contains no '.', searches for an enum with that name.
    Returns the qualified ID if exactly one match, raises on ambiguity or not found.
    If type_id already contains '.', returns it unchanged.
    """
    if "." in type_id:
        return type_id
    safe_name = _escape_odata_string(type_id)
    path, params = FootPrintMetadataEndpoints.enum_types(
        connection_id, filter=f"name eq '{safe_name}'"
    )
    response = client.get(path, params=params)
    matches = ODataListResponse[EnumTypeDto](**response).value
    if len(matches) == 1:
        return matches[0].type_id
    if len(matches) == 0:
        info = _schema_not_found_error("describe-enum", type_id, connection_id)
        raise ValidationError(
            message=info["message"], code=info["code"], suggestions=info["suggestions"]
        )
    candidates = [e.type_id for e in matches[:5]]
    raise ValidationError(
        message=f"Ambiguous enum name '{type_id}' matches {len(matches)} types",
        code="DXS-SCHEMA-002",
        suggestions=[f"Use fully-qualified ID: {c}" for c in candidates],
    )


def _resolve_short_complex_type_id(client: ApiClient, connection_id: int, type_id: str) -> str:
    """Resolve short complex type name to fully-qualified TypeId.

    If type_id contains no '.', searches for a complex type with that name.
    Returns the qualified ID if exactly one match, raises on ambiguity or not found.
    If type_id already contains '.', returns it unchanged.
    """
    if "." in type_id:
        return type_id
    safe_name = _escape_odata_string(type_id)
    path, params = FootPrintMetadataEndpoints.complex_types(
        connection_id, filter=f"name eq '{safe_name}'"
    )
    response = client.get(path, params=params)
    matches = ODataListResponse[ComplexTypeDto](**response).value
    if len(matches) == 1:
        return matches[0].type_id
    if len(matches) == 0:
        info = _schema_not_found_error("describe-complex-type", type_id, connection_id)
        raise ValidationError(
            message=info["message"], code=info["code"], suggestions=info["suggestions"]
        )
    candidates = [ct.type_id for ct in matches[:5]]
    raise ValidationError(
        message=f"Ambiguous complex type name '{type_id}' matches {len(matches)} types",
        code="DXS-SCHEMA-005",
        suggestions=[f"Use fully-qualified ID: {c}" for c in candidates],
    )


def _apply_describe_filters(
    entity_details: dict[str, Any],
    *,
    properties_only: bool = False,
    nav_only: bool = False,
    no_udf: bool = False,
    prop_top: int | None = None,
    compact: bool = False,
    select: str | None = None,
) -> dict[str, Any]:
    """Apply post-fetch filters to describe-entity output.

    Modifies entity_details in-place and returns it.
    """
    # Parse --select into a set of lowercase names
    select_set: set[str] | None = None
    if select:
        select_set = {s.strip().lower() for s in select.split(",") if s.strip()}

    # Filter properties
    props = entity_details.get("properties", [])
    if select_set:
        props = [p for p in props if p["name"].lower() in select_set]
    if no_udf:
        props = [p for p in props if not p.get("is_udf")]

    total_props = len(props)
    if prop_top is not None and len(props) > prop_top:
        props = props[:prop_top]
        entity_details["properties_truncated"] = True
        entity_details["properties_total"] = total_props

    # Filter nav properties
    nav_props = entity_details.get("navigation_properties", [])
    if select_set:
        nav_props = [n for n in nav_props if n["name"].lower() in select_set]

    # Warn about --select field names that matched neither properties nor nav properties
    if select_set:
        matched = {p["name"].lower() for p in props} | {n["name"].lower() for n in nav_props}
        unmatched = select_set - matched
        if unmatched:
            click.echo(
                f"Warning: --select field(s) not found: {', '.join(sorted(unmatched))}",
                err=True,
            )

    # Apply --compact: reduce to name: type pairs
    if compact:
        props = [{"name": p["name"], "type": p["type"]} for p in props]
        nav_props = [{"name": n["name"], "type": n["type"]} for n in nav_props]

    # Apply --properties-only / --nav-only
    if properties_only:
        entity_details["properties"] = props
        entity_details.pop("navigation_properties", None)
    elif nav_only:
        entity_details.pop("properties", None)
        entity_details["navigation_properties"] = nav_props
    else:
        entity_details["properties"] = props
        entity_details["navigation_properties"] = nav_props

    return entity_details


@click.group(name="schema")
@pass_context
def schema(ctx: DxsContext) -> None:
    """Progressive OData entity model discovery.

    Commands for exploring entity structures with token-efficient output,
    optimized for AI agents building OData queries.
    """


@schema.command(name="entities")
@schema_list_options("entities")
@schema_connection_options()
@pass_context
@require_auth
@handle_errors
def list_entities(
    ctx: DxsContext,
    connection_id: int | None,
    connection: str | None,
    org: str | None,
    top: int | None,
    skip: int | None,
    filter_expr: str | None,
    orderby: str | None,
    search: str | None,
    count: bool,
) -> None:
    """List all entities in the catalog.

    Shows entity names, types, and key properties only.
    Optimized for minimal data transfer and token usage.

    Use --search for server-side substring matching on entity set name and type ID.
    Use --filter for OData $filter expressions (e.g. "contains(Name, 'Ship')").
    The separate 'search' command is equivalent to 'entities --search'.

    \b
    Examples:
        dxs schema entities --connection-id 32
        dxs schema entities --connection-id 32 --search "ship"
        dxs schema entities --connection-id 32 --top 10
        dxs schema entities --connection-id 32 --filter "contains(Name, 'Ship')"
        dxs schema entities --connection-id 32 --count
    """
    resolved_id = _resolve_connection(ctx, connection_id, connection, org)

    client = ApiClient()

    # If --search is provided, delegate to the search URL builder
    if search:
        search_term = search.strip()
        if count:
            path, params = FootPrintMetadataEndpoints.entity_sets(
                resolved_id, top=0, search=search_term, filter=filter_expr
            )
            params["$count"] = "true"
            result = client.get(path, params=params)
            count_resp = single(
                item={"count": result.get("@odata.count", 0)},
                semantic_key="entity_count",
                connection_id=resolved_id,
            )
            ctx.output(count_resp)
            return
        path, params = FootPrintMetadataEndpoints.entity_sets(
            resolved_id,
            top=top,
            skip=skip,
            filter=filter_expr,
            orderby=orderby,
            search=search_term,
            expand="EntityType",
        )
        raw_body = client.get(path, params=params)
        entities_summary = _format_list_result(raw_body)
        response = list_response(
            items=entities_summary,
            semantic_key="entity_sets",
            connection_id=resolved_id,
        )
        ctx.output(response)
        return

    # If count-only requested, use $count=true query parameter
    if count:
        path, params = FootPrintMetadataEndpoints.entity_sets(
            resolved_id, top=0, filter=filter_expr, orderby=orderby
        )
        params["$count"] = "true"
        result = client.get(path, params=params)
        count_value = result.get("@odata.count", 0)

        count_resp = single(
            item={"count": count_value},
            semantic_key="entity_count",
            connection_id=resolved_id,
        )
        ctx.output(count_resp)
        return

    # Single HTTP call: $expand=EntityType embeds key info so no separate entity type fetch
    path, params = _url_for_list(
        resolved_id, top=top, skip=skip, filter_expr=filter_expr, orderby=orderby
    )
    raw_body = client.get(path, params=params)
    entities_summary = _format_list_result(raw_body)

    # Build response
    response = list_response(
        items=entities_summary,
        semantic_key="entity_sets",
        connection_id=resolved_id,
    )

    ctx.output(response)


@schema.command(name="describe-entity")
@click.argument("entity_name")
@click.option(
    "--properties-only",
    "-P",
    is_flag=True,
    default=False,
    help="Show only properties (exclude navigation properties)",
)
@click.option(
    "--nav-only",
    "-N",
    is_flag=True,
    default=False,
    help="Show only navigation properties (exclude properties)",
)
@click.option(
    "--no-udf",
    is_flag=True,
    default=False,
    help="Exclude user-defined fields (is_udf=True)",
)
@click.option(
    "--prop-top",
    type=click.IntRange(min=0),
    default=None,
    help="Limit number of properties shown (adds truncation indicator)",
)
@click.option(
    "--compact",
    is_flag=True,
    default=False,
    help="Show only name: type pairs (minimal output)",
)
@click.option(
    "--select",
    type=str,
    default=None,
    help="Comma-separated property/nav-property names to include (case-insensitive)",
)
@schema_connection_options()
@pass_context
@require_auth
@handle_errors
def describe_entity(
    ctx: DxsContext,
    entity_name: str,
    connection_id: int | None,
    connection: str | None,
    org: str | None,
    properties_only: bool,
    nav_only: bool,
    no_udf: bool,
    prop_top: int | None,
    compact: bool,
    select: str | None,
) -> None:
    """Show complete schema for an entity.

    Displays properties (name, type, nullable), keys, and navigation properties.
    Includes query_hints in metadata with example OData queries.
    Entity name matching is case-insensitive.

    \b
    Examples:
        dxs schema describe-entity Warehouses --connection-id 32
        dxs schema describe-entity shipments -c 2 --compact --no-udf
        dxs schema describe-entity Items -c 2 --properties-only --prop-top 20
        dxs schema describe-entity Items -c 2 --select "Code,Name,OrderLines"
    """
    if properties_only and nav_only:
        raise ValidationError(
            message="--properties-only and --nav-only are mutually exclusive",
            code="DXS-SCHEMA-010",
            suggestions=[
                "Use --properties-only for properties or --nav-only for navigation properties, not both"
            ],
        )
    resolved_id = _resolve_connection(ctx, connection_id, connection, org)

    client = ApiClient()

    # Fetch all entity sets for nav property expand paths (unless --properties-only)
    nav_entity_sets: list[EntitySetDto] | None = None
    if not properties_only:
        nav_entity_sets = _fetch_entity_sets(client, resolved_id)

    # Single call: resolve entity set and fetch entity type with all metadata
    path, params = _url_for_describe(resolved_id, entity_name)
    result_sets_body = client.get(path, params=params)
    is_concise = ctx.concise
    entity_details = _format_describe_result(
        result_sets_body, concise=is_concise, all_entity_sets=nav_entity_sets
    )

    entity_set: EntitySetDto | None
    if entity_details is not None:
        # Happy path: entity set found with embedded entity type
        result_sets = ODataListResponse[EntitySetDto](**result_sets_body).value
        entity_set = result_sets[0]
        entity_type = entity_set.entity_type
        assert entity_type is not None  # guarded by _format_describe_result
    else:
        # Fallback: entity was passed as type name or qualified type ID
        entity_set, type_id = _resolve_entity(client, resolved_id, entity_name)
        entity_type = _fetch_entity_type(
            client, resolved_id, type_id, expand="Properties,NavigationProperties"
        )
        if not entity_type:
            info = _schema_not_found_error("describe-entity", type_id, resolved_id)
            raise ValidationError(
                message=f"Entity type '{type_id}' not found (metadata may be incomplete)",
                code=info["code"],
                suggestions=info["suggestions"],
            )

        entity_details = _build_entity_details_from_type(
            entity_set.name if entity_set else None,
            type_id,
            entity_type,
            concise=is_concise,
            all_entity_sets=nav_entity_sets,
        )

    # Apply describe filters (scoping, compact, select, no-udf, prop-top)
    entity_details = _apply_describe_filters(
        entity_details,
        properties_only=properties_only,
        nav_only=nav_only,
        no_udf=no_udf,
        prop_top=prop_top,
        compact=compact,
        select=select,
    )

    # Detect unmatched --select fields for response warnings
    warnings_list: list[str] = []
    if select:
        matched = {p["name"].lower() for p in entity_details.get("properties", [])} | {
            n["name"].lower() for n in entity_details.get("navigation_properties", [])
        }
        unmatched = [s for s in select.split(",") if s.strip().lower() not in matched]
        if unmatched:
            warnings_list.append(f"--select field(s) not found: {', '.join(unmatched)}")

    properties = entity_type.properties or []
    nav_properties = entity_type.navigation_properties or []

    # Generate query hints
    entity_name_for_query = entity_set.name if entity_set else entity_name
    non_udf_non_computed = [p for p in properties if not p.is_computed and not p.is_udf]
    if not non_udf_non_computed:
        non_udf_non_computed = [p for p in properties if not p.is_computed]
    property_names = [p.name for p in non_udf_non_computed][:5]

    # Select example
    select_hint = f"{entity_name_for_query}?$select={','.join(property_names)}"

    # Filter example with correct type-based literals
    filter_hint = None
    if non_udf_non_computed:
        first_prop = non_udf_non_computed[0]
        filter_value = _get_filter_example_value(first_prop.type_id)
        filter_hint = f"{entity_name_for_query}?$filter={first_prop.name} eq {filter_value}"

    # Expand examples - simple and nested
    expand_hints = []
    if nav_properties:
        # Simple expand
        expand_hints.append(f"$expand={nav_properties[0].name}")

        # Add nested select example
        expand_hints.append(f"$expand={nav_properties[0].name}($select=Id)")

        # Multiple expands (if at least 2 nav properties)
        if len(nav_properties) >= 2:
            expand_hints.append(f"$expand={nav_properties[0].name},{nav_properties[1].name}")

        # Filtered expand and nested select examples (for collection nav properties)
        collection_navs = [n for n in nav_properties if n.is_collection]
        if collection_navs:
            # Generic filter example (use common property names that likely exist)
            expand_hints.append(f"$expand={collection_navs[0].name}($filter=Id eq 123)")
            # Nested $select example - show pattern without fetching actual properties
            expand_hints.append(f"$expand={collection_navs[0].name}($select=Id,Name)")

    # Count example
    count_hint = f"{entity_name_for_query}?$count=true&$top=10"

    # Top/Skip pagination example
    pagination_hint = f"{entity_name_for_query}?$top=10&$skip=20"

    # OrderBy example
    orderby_hint = None
    if property_names:
        orderby_hint = f"{entity_name_for_query}?$orderby={property_names[0]} desc"

    query_hints = {
        "select_example": select_hint,
        "filter_example": filter_hint,
        "expand_examples": expand_hints if expand_hints else None,
        "orderby_example": orderby_hint,
        "count_example": count_hint,
        "pagination_example": pagination_hint,
    }

    # Build response
    response_kwargs: dict[str, Any] = {
        "connection_id": resolved_id,
        "query_hints": query_hints,
    }
    if warnings_list:
        response_kwargs["warnings"] = warnings_list
    response = single(
        item=entity_details,
        semantic_key="entity",
        **response_kwargs,
    )

    ctx.output(response)


@schema.command(name="describe-relationships")
@click.argument("entity_name")
@click.option(
    "--depth",
    type=click.IntRange(min=1),
    default=1,
    help="Relationship depth (1=direct, 2=include target entity relationships)",
)
@schema_connection_options()
@pass_context
@require_auth
@handle_errors
def list_relationships(
    ctx: DxsContext,
    entity_name: str,
    connection_id: int | None,
    connection: str | None,
    org: str | None,
    depth: int,
) -> None:
    """Show detailed relationship information for an entity.

    Displays navigation properties with target entity details and expand syntax.
    Optimized for building $expand queries.

    \b
    Examples:
        dxs schema describe-relationships Warehouses --connection-id 32
        dxs schema describe-relationships Items --connection Demo --org MyOrg
        dxs schema describe-relationships Orders -c 32 --depth 2
    """
    resolved_id = _resolve_connection(ctx, connection_id, connection, org)

    client = ApiClient()

    # Resolve entity using server-side filtering (returns entity_set + type_id)
    entity_set, type_id = _resolve_entity(client, resolved_id, entity_name)

    # Bulk fetch all metadata for target lookups -- run in parallel (independent calls)
    # Note: We fetch all entity sets/types to avoid N+1 queries when looking up
    # target entities for navigation properties (could be 50+ targets)
    with ThreadPoolExecutor(max_workers=2) as executor:
        future_sets = executor.submit(_fetch_entity_sets, client, resolved_id)
        future_types = executor.submit(_fetch_all_entity_types, client, resolved_id)
        entity_sets = future_sets.result()
        all_entity_types = future_types.result()

    # Fetch navigation properties raw response body for this specific entity
    path, params = _url_for_nav_properties_by_type(resolved_id, type_id)
    nav_props_body = client.get(path, params=params)

    # Build relationship details using in-memory lookups
    relationships = _format_relationships_result(
        entity_set, entity_sets, all_entity_types, nav_props_body
    )

    # Depth-2: fetch nav properties for each target entity type
    if depth >= 2 and relationships:
        # Collect unique target type IDs
        target_type_ids = {
            rel["target_entity_type"] for rel in relationships if rel.get("target_entity_type")
        }

        # Build lookup maps
        entity_set_by_type = {es.type_id: es for es in entity_sets}

        # Fetch nav properties for all target types concurrently
        target_nav_props: dict[str, list[dict[str, Any]]] = {}

        def _fetch_target_navs(target_type_id: str) -> tuple[str, list[dict[str, Any]]]:
            path_t, params_t = _url_for_nav_properties_by_type(resolved_id, target_type_id)
            body = client.get(path_t, params=params_t)
            nav_list = ODataListResponse[NavigationPropertyDto](**body).value if body else []
            nested = []
            for nav in nav_list:
                t_type_id = _unwrap_collection_type(nav.type_id)
                target_es = entity_set_by_type.get(t_type_id)
                nested.append(
                    {
                        "name": nav.name,
                        "target_type": t_type_id,
                        "multiplicity": "many" if nav.is_collection else "one",
                        "expand_path": f"$expand={nav.name}" if target_es else None,
                    }
                )
            return target_type_id, nested

        with ThreadPoolExecutor(max_workers=min(len(target_type_ids), 8)) as executor:
            futures = [executor.submit(_fetch_target_navs, tid) for tid in target_type_ids]
            for future in futures:
                tid, nested = future.result()
                target_nav_props[tid] = nested

        # Attach nested_relationships to each relationship
        for rel in relationships:
            t_type = rel.get("target_entity_type")
            if t_type and t_type in target_nav_props:
                rel["nested_relationships"] = target_nav_props[t_type]

    # Generate simple nested expand example (without fetching properties)
    nested_expand_example = None
    if relationships:
        expand_parts = [rel["name"] for rel in relationships[:2]]
        if expand_parts:
            nested_expand_example = (
                f"{entity_set.name if entity_set else entity_name}?$expand={','.join(expand_parts)}"
            )

    # Build response
    response = list_response(
        items=relationships,
        semantic_key="relationships",
        connection_id=resolved_id,
        entity=entity_set.name if entity_set else entity_name,
        query_hints={"nested_expand_example": nested_expand_example},
    )

    ctx.output(response)


@schema.command(name="search")
@click.argument("query")
@click.option(
    "--limit",
    "--top",
    "-n",
    "top",
    type=click.IntRange(min=0),
    default=None,
    help="Maximum number of results to return",
)
@click.option(
    "--skip",
    type=click.IntRange(min=0),
    default=None,
    help="Number of results to skip (for pagination)",
)
@click.option(
    "--orderby", type=str, default=None, help='OData $orderby expression (e.g. "Name desc")'
)
@click.option(
    "--count",
    is_flag=True,
    default=False,
    help="Return only the count of matching entities (no data)",
)
@schema_connection_options()
@pass_context
@require_auth
@handle_errors
def search_entities(
    ctx: DxsContext,
    query: str,
    connection_id: int | None,
    connection: str | None,
    org: str | None,
    top: int | None,
    skip: int | None,
    orderby: str | None,
    count: bool,
) -> None:
    """Search entities by name (case-insensitive substring match).

    Uses the server-side $search parameter for efficient full-text search across
    entity set name and type ID. Returns filtered entity list with same structure
    as 'entities' command.

    \b
    Examples:
        dxs schema search "warehouse" --connection-id 32
        dxs schema search "item" --connection Demo --org MyOrg
        dxs schema search "invoice" --connection-id 32 --top 10
        dxs schema search "invoice" --connection-id 32 --count
    """
    # Validate query parameter
    if not query or not query.strip():
        raise ValidationError(
            message="Search query cannot be empty. Provide a search term (e.g., 'invoice', 'warehouse')",
            code="DXS-SCHEMA-012",
        )

    resolved_id = _resolve_connection(ctx, connection_id, connection, org)

    client = ApiClient()

    search_term = query.strip()

    # If count-only requested, use $count=true with $search
    if count:
        path, params = FootPrintMetadataEndpoints.entity_sets(
            resolved_id, top=0, search=search_term
        )
        params["$count"] = "true"
        result = client.get(path, params=params)
        count_value = result.get("@odata.count", 0)

        # For multi-word queries, also search with spaces stripped and take max
        if " " in search_term:
            joined_term = search_term.replace(" ", "")
            path2, params2 = FootPrintMetadataEndpoints.entity_sets(
                resolved_id, top=0, search=joined_term
            )
            params2["$count"] = "true"
            result2 = client.get(path2, params=params2)
            count_value2 = result2.get("@odata.count", 0)
            count_value = max(count_value, count_value2)

        count_resp = single(
            item={"count": count_value, "query": query},
            semantic_key="search_result_count",
            connection_id=resolved_id,
        )
        ctx.output(count_resp)
        return

    # Single HTTP call: $search + $expand=EntityType
    # $search matches Name and TypeId (server-side substring match)
    # $expand=EntityType embeds key info so no separate entity type fetch needed
    path, params = _url_for_search(
        resolved_id, query=search_term, top=top, skip=skip, orderby=orderby
    )
    raw_body = client.get(path, params=params)
    entities_summary = _format_search_result(raw_body)

    # For multi-word queries, also search with spaces stripped and merge results
    if " " in search_term:
        joined_term = search_term.replace(" ", "")
        path2, params2 = _url_for_search(
            resolved_id, query=joined_term, top=top, skip=skip, orderby=orderby
        )
        response2 = client.get(path2, params=params2)
        extra_items = _format_search_result(response2)
        seen = {item["name"] for item in entities_summary}
        for item in extra_items:
            if item["name"] not in seen:
                entities_summary.append(item)
                seen.add(item["name"])

    # Build response with search metadata
    response = list_response(
        items=entities_summary,
        semantic_key="entity_sets",
        connection_id=resolved_id,
        query=query,
        count=len(entities_summary),
    )

    ctx.output(response)


@schema.command(name="enums")
@schema_list_options("enum types")
@schema_connection_options()
@pass_context
@require_auth
@handle_errors
def list_enums(
    ctx: DxsContext,
    connection_id: int | None,
    connection: str | None,
    org: str | None,
    top: int | None,
    skip: int | None,
    filter_expr: str | None,
    orderby: str | None,
    search: str | None,
    count: bool,
) -> None:
    """List all enumeration types in the OData model.

    Shows enum names, namespaces, and underlying types.
    Useful for understanding allowed values for enum properties.

    \b
    Examples:
        dxs schema enums --connection-id 32
        dxs schema enums --connection Demo --org MyOrg
        dxs schema enums --connection-id 32 --top 5
        dxs schema enums --connection-id 32 --search "status"
        dxs schema enums --connection-id 32 --filter "Name eq 'StatusType'"
        dxs schema enums --connection-id 32 --count
    """
    resolved_id = _resolve_connection(ctx, connection_id, connection, org)

    client = ApiClient()

    # If count-only requested, use $count=true query parameter
    if count:
        path, params = _url_for_enums(
            resolved_id, top=0, filter_expr=filter_expr, search=search, orderby=orderby
        )
        params["$count"] = "true"
        result = client.get(path, params=params)
        count_value = result.get("@odata.count", 0)

        count_resp = single(
            item={"count": count_value},
            semantic_key="enum_count",
            connection_id=resolved_id,
        )
        ctx.output(count_resp)
        return

    # Fetch enum types (1 HTTP call)
    path, params = _url_for_enums(
        resolved_id, top=top, skip=skip, filter_expr=filter_expr, search=search, orderby=orderby
    )
    raw_body = client.get(path, params=params)
    enums_summary = _format_enums_result(raw_body, concise=ctx.concise)

    # Build response
    response = list_response(
        items=enums_summary,
        semantic_key="enum_types",
        connection_id=resolved_id,
    )

    ctx.output(response)


@schema.command(name="describe-enum")
@click.argument("type_id")
@schema_connection_options()
@pass_context
@require_auth
@handle_errors
def describe_enum(
    ctx: DxsContext,
    type_id: str,
    connection_id: int | None,
    connection: str | None,
    org: str | None,
) -> None:
    """Show details for a specific enumeration type.

    TYPE_ID is the fully-qualified enum TypeId (e.g. Datex.FootPrint.Api.SomeName).
    Use 'dxs schema enums' to list available enums and their TypeIds.

    Displays enum members with their names and values.

    \b
    Examples:
        dxs schema describe-enum Datex.FootPrint.Api.AsnOutstandingQuantitiesBehaviorEnum --connection-id 32
        dxs schema describe-enum Datex.FootPrint.Api.ReserveIdEntityEnum --connection Demo --org MyOrg
    """
    resolved_id = _resolve_connection(ctx, connection_id, connection, org)

    client = ApiClient()

    qualified_id = _resolve_short_enum_id(client, resolved_id, type_id)
    path, params = _url_for_describe_enum(resolved_id, qualified_id)
    try:
        raw_body = client.get(path, params=params)
    except ApiError as e:
        if e.code == "DXS-404-001":
            info = _schema_not_found_error("describe-enum", qualified_id, resolved_id)
            raise ValidationError(
                message=info["message"], code=info["code"], suggestions=info["suggestions"]
            ) from e
        raise
    enum_details = _format_describe_enum_result(raw_body)

    # Build response
    response = single(
        item=enum_details,
        semantic_key="enum_type",
        connection_id=resolved_id,
    )

    ctx.output(response)


@schema.command(name="actions")
@schema_list_options("actions")
@schema_connection_options()
@pass_context
@require_auth
@handle_errors
def list_actions(
    ctx: DxsContext,
    connection_id: int | None,
    connection: str | None,
    org: str | None,
    top: int | None,
    skip: int | None,
    filter_expr: str | None,
    orderby: str | None,
    search: str | None,
    count: bool,
) -> None:
    """List all OData actions (state-changing operations).

    Shows action names, binding types, and return types.
    Actions are callable via POST requests.

    \b
    Examples:
        dxs schema actions --connection-id 32
        dxs schema actions --connection Demo --org MyOrg
        dxs schema actions --connection-id 32 --top 10
        dxs schema actions --connection-id 32 --search "create"
        dxs schema actions --connection-id 32 --filter "contains(Name, 'Create')"
        dxs schema actions --connection-id 32 --orderby "Name asc"
        dxs schema actions --connection-id 32 --count
    """
    resolved_id = _resolve_connection(ctx, connection_id, connection, org)

    client = ApiClient()

    # If count-only requested, use $count=true query parameter
    if count:
        path, params = _url_for_actions(
            resolved_id, top=0, filter_expr=filter_expr, search=search, orderby=orderby
        )
        params["$count"] = "true"
        result = client.get(path, params=params)
        count_value = result.get("@odata.count", 0)

        count_resp = single(
            item={"count": count_value},
            semantic_key="action_count",
            connection_id=resolved_id,
        )
        ctx.output(count_resp)
        return

    # Fetch actions (1 HTTP call)
    path, params = _url_for_actions(
        resolved_id, top=top, skip=skip, filter_expr=filter_expr, search=search, orderby=orderby
    )
    raw_body = client.get(path, params=params)
    actions_summary = _format_actions_result(raw_body, concise=ctx.concise)

    # Build response
    response = list_response(
        items=actions_summary,
        semantic_key="actions",
        connection_id=resolved_id,
    )

    ctx.output(response)


@schema.command(name="describe-action")
@click.argument("action_id")
@schema_connection_options()
@pass_context
@require_auth
@handle_errors
def describe_action(
    ctx: DxsContext,
    action_id: str,
    connection_id: int | None,
    connection: str | None,
    org: str | None,
) -> None:
    """Show details for a specific OData action.

    ACTION_ID can be a short name (e.g. CancelSalesOrderShipment) or
    fully-qualified (e.g. Datex.FootPrint.Api.CancelSalesOrderShipment).
    Short names are resolved automatically; if ambiguous, candidates are listed.
    Complex type parameters and return types include inline field definitions.

    \b
    Examples:
        dxs schema describe-action CancelSalesOrderShipment --connection-id 32
        dxs schema describe-action Datex.FootPrint.Api.ActivateBillingContract --connection-id 32
    """
    resolved_id = _resolve_connection(ctx, connection_id, connection, org)

    client = ApiClient()

    # Resolve short name (e.g. "CancelSalesOrderShipment") to fully-qualified ID
    qualified_id = _resolve_short_action_id(client, resolved_id, action_id)

    path, params = _url_for_describe_action(resolved_id, qualified_id)
    try:
        raw_body = client.get(path, params=params)
    except ApiError as e:
        if e.code == "DXS-404-001":
            info = _schema_not_found_error("describe-action", action_id, resolved_id)
            raise ValidationError(
                message=info["message"], code=info["code"], suggestions=info["suggestions"]
            ) from e
        raise
    action_details = _format_describe_action_result(raw_body, concise=ctx.concise)

    # Inline complex type fields for parameters and return type
    type_cache: dict[str, list[dict[str, str]]] = {}
    _inline_complex_fields(client, resolved_id, action_details, type_cache)

    # Build response
    response = single(
        item=action_details,
        semantic_key="action",
        connection_id=resolved_id,
    )

    ctx.output(response)


@schema.command(name="functions")
@schema_list_options("functions")
@schema_connection_options()
@pass_context
@require_auth
@handle_errors
def list_functions(
    ctx: DxsContext,
    connection_id: int | None,
    connection: str | None,
    org: str | None,
    top: int | None,
    skip: int | None,
    filter_expr: str | None,
    orderby: str | None,
    search: str | None,
    count: bool,
) -> None:
    """List all OData functions (read-only operations).

    Shows function names, binding types, return types, and composability.
    Functions are callable via GET requests.

    \b
    Examples:
        dxs schema functions --connection-id 32
        dxs schema functions --connection Demo --org MyOrg
        dxs schema functions --connection-id 32 --top 10
        dxs schema functions --connection-id 32 --search "get"
        dxs schema functions --connection-id 32 --filter "contains(Name, 'Get')"
        dxs schema functions --connection-id 32 --count
    """
    resolved_id = _resolve_connection(ctx, connection_id, connection, org)

    client = ApiClient()

    # If count-only requested, use $count=true query parameter
    if count:
        path, params = _url_for_functions(
            resolved_id, top=0, filter_expr=filter_expr, search=search, orderby=orderby
        )
        params["$count"] = "true"
        result = client.get(path, params=params)
        count_value = result.get("@odata.count", 0)

        count_resp = single(
            item={"count": count_value},
            semantic_key="function_count",
            connection_id=resolved_id,
        )
        ctx.output(count_resp)
        return

    # Fetch functions (1 HTTP call)
    path, params = _url_for_functions(
        resolved_id, top=top, skip=skip, filter_expr=filter_expr, search=search, orderby=orderby
    )
    raw_body = client.get(path, params=params)
    functions_summary = _format_functions_result(raw_body, concise=ctx.concise)

    # Build response
    response = list_response(
        items=functions_summary,
        semantic_key="functions",
        connection_id=resolved_id,
    )

    ctx.output(response)


@schema.command(name="describe-function")
@click.argument("function_id")
@schema_connection_options()
@pass_context
@require_auth
@handle_errors
def describe_function(
    ctx: DxsContext,
    function_id: str,
    connection_id: int | None,
    connection: str | None,
    org: str | None,
) -> None:
    """Show details for a specific OData function.

    FUNCTION_ID can be a short name (e.g. GetInvoiceTotal) or
    fully-qualified (e.g. Datex.FootPrint.Api.GetInvoiceTotal).
    Short names are resolved automatically; if ambiguous, candidates are listed.
    Complex type parameters and return types include inline field definitions.

    \b
    Examples:
        dxs schema describe-function GetInvoiceTotal --connection-id 32
        dxs schema describe-function Datex.FootPrint.Api.CalculateShipping --connection Demo --org MyOrg
    """
    resolved_id = _resolve_connection(ctx, connection_id, connection, org)

    client = ApiClient()

    # Resolve short name to fully-qualified ID
    qualified_id = _resolve_short_function_id(client, resolved_id, function_id)

    path, params = _url_for_describe_function(resolved_id, qualified_id)
    try:
        raw_body = client.get(path, params=params)
    except ApiError as e:
        if e.code == "DXS-404-001":
            info = _schema_not_found_error("describe-function", function_id, resolved_id)
            raise ValidationError(
                message=info["message"], code=info["code"], suggestions=info["suggestions"]
            ) from e
        raise
    func_details = _format_describe_function_result(raw_body, concise=ctx.concise)

    # Inline complex type fields for parameters and return type
    type_cache: dict[str, list[dict[str, str]]] = {}
    _inline_complex_fields(client, resolved_id, func_details, type_cache)

    # Build response
    response = single(
        item=func_details,
        semantic_key="function",
        connection_id=resolved_id,
    )

    ctx.output(response)


@schema.command(name="complex-types")
@schema_list_options("complex types")
@schema_connection_options()
@pass_context
@require_auth
@handle_errors
def list_complex_types(
    ctx: DxsContext,
    connection_id: int | None,
    connection: str | None,
    org: str | None,
    top: int | None,
    skip: int | None,
    filter_expr: str | None,
    orderby: str | None,
    search: str | None,
    count: bool,
) -> None:
    """List all complex types in the OData model.

    Complex types are structured types that are not entities (no keys, not directly queryable).
    They are used as property types within entities.

    \b
    Examples:
        dxs schema complex-types --connection-id 32
        dxs schema complex-types --connection Demo --org MyOrg
        dxs schema complex-types --connection-id 32 --top 20
        dxs schema complex-types --connection-id 32 --search "request"
        dxs schema complex-types --connection-id 32 --filter "contains(Name, 'Request')"
        dxs schema complex-types --connection-id 32 --count
    """
    resolved_id = _resolve_connection(ctx, connection_id, connection, org)

    client = ApiClient()

    # If count-only requested, use $count=true query parameter
    if count:
        path, params = _url_for_complex_types(
            resolved_id, top=0, filter_expr=filter_expr, search=search, orderby=orderby
        )
        params["$count"] = "true"
        result = client.get(path, params=params)
        count_value = result.get("@odata.count", 0)

        count_resp = single(
            item={"count": count_value},
            semantic_key="complex_type_count",
            connection_id=resolved_id,
        )
        ctx.output(count_resp)
        return

    # Fetch complex types (1 HTTP call)
    path, params = _url_for_complex_types(
        resolved_id, top=top, skip=skip, filter_expr=filter_expr, search=search, orderby=orderby
    )
    raw_body = client.get(path, params=params)
    complex_types_summary = _format_complex_types_result(raw_body, concise=ctx.concise)

    # Build response
    response = list_response(
        items=complex_types_summary,
        semantic_key="complex_types",
        connection_id=resolved_id,
    )

    ctx.output(response)


@schema.command(name="describe-complex-type")
@click.argument("type_id")
@schema_connection_options()
@pass_context
@require_auth
@handle_errors
def describe_complex_type(
    ctx: DxsContext,
    type_id: str,
    connection_id: int | None,
    connection: str | None,
    org: str | None,
) -> None:
    """Show details for a specific complex type.

    TYPE_ID is the fully-qualified complex type TypeId (e.g. Datex.FootPrint.Api.SomeName).
    Use 'dxs schema complex-types' to list available types and their TypeIds.

    Displays complex type properties, navigation properties, and inheritance information.

    \b
    Examples:
        dxs schema describe-complex-type Datex.FootPrint.Api.Address --connection-id 32
        dxs schema describe-complex-type Datex.FootPrint.Api.ContactInfo --connection Demo --org MyOrg
    """
    resolved_id = _resolve_connection(ctx, connection_id, connection, org)

    client = ApiClient()

    qualified_id = _resolve_short_complex_type_id(client, resolved_id, type_id)
    # Single call: key-based lookup + expand properties in one request
    path, params = _url_for_describe_complex_type(resolved_id, qualified_id)
    try:
        raw_body = client.get(path, params=params)
    except ApiError as e:
        if e.code == "DXS-404-001":
            info = _schema_not_found_error("describe-complex-type", qualified_id, resolved_id)
            raise ValidationError(
                message=info["message"], code=info["code"], suggestions=info["suggestions"]
            ) from e
        raise

    type_details = _format_describe_complex_type_result(raw_body)

    # Build response
    response = single(
        item=type_details,
        semantic_key="complex_type",
        connection_id=resolved_id,
    )

    ctx.output(response)


@schema.command(name="singletons")
@schema_list_options("singletons")
@schema_connection_options()
@pass_context
@require_auth
@handle_errors
def list_singletons(
    ctx: DxsContext,
    connection_id: int | None,
    connection: str | None,
    org: str | None,
    top: int | None,
    skip: int | None,
    filter_expr: str | None,
    orderby: str | None,
    search: str | None,
    count: bool,
) -> None:
    """List all singletons in the OData model.

    Singletons are single-instance entities exposed by the API.
    They are typically used for configuration or system-wide settings.

    \b
    Examples:
        dxs schema singletons --connection-id 32
        dxs schema singletons --connection Demo --org MyOrg
        dxs schema singletons --connection-id 32 --search "config"
        dxs schema singletons --connection-id 32 --filter "Name eq 'Config'"
        dxs schema singletons --connection-id 32 --count
    """
    resolved_id = _resolve_connection(ctx, connection_id, connection, org)

    client = ApiClient()

    # If count-only requested, use $count=true query parameter
    if count:
        path, params = _url_for_singletons(
            resolved_id, top=0, filter_expr=filter_expr, search=search, orderby=orderby
        )
        params["$count"] = "true"
        result = client.get(path, params=params)
        count_value = result.get("@odata.count", 0)

        count_resp = single(
            item={"count": count_value},
            semantic_key="singleton_count",
            connection_id=resolved_id,
        )
        ctx.output(count_resp)
        return

    # Fetch singletons (1 HTTP call)
    path, params = _url_for_singletons(
        resolved_id, top=top, skip=skip, filter_expr=filter_expr, search=search, orderby=orderby
    )
    raw_body = client.get(path, params=params)
    singletons_summary = _format_singletons_result(raw_body)

    # Build response
    response = list_response(
        items=singletons_summary,
        semantic_key="singletons",
        connection_id=resolved_id,
    )

    ctx.output(response)


@schema.command(name="describe-singleton")
@click.argument("singleton_name")
@schema_connection_options()
@pass_context
@require_auth
@handle_errors
def describe_singleton(
    ctx: DxsContext,
    singleton_name: str,
    connection_id: int | None,
    connection: str | None,
    org: str | None,
) -> None:
    """Show details for a specific singleton.

    Displays singleton entity type and properties.

    \b
    Examples:
        dxs schema describe-singleton SystemConfig --connection-id 32
        dxs schema describe-singleton Settings --connection Demo --org MyOrg
    """
    resolved_id = _resolve_connection(ctx, connection_id, connection, org)

    client = ApiClient()

    # Single HTTP call: $expand=EntityType with nested Properties and NavigationProperties
    path, params = _url_for_describe_singleton(resolved_id, singleton_name)
    try:
        raw_body = client.get(path, params=params)
    except ApiError as e:
        if e.code == "DXS-404-001":
            info = _schema_not_found_error("describe-singleton", singleton_name, resolved_id)
            raise ValidationError(
                message=info["message"], code=info["code"], suggestions=info["suggestions"]
            ) from e
        raise
    singleton_details = _format_describe_singleton_result(raw_body, concise=ctx.concise)

    # Build response
    response = single(
        item=singleton_details,
        semantic_key="singleton",
        connection_id=resolved_id,
    )

    ctx.output(response)


@schema.command(name="action-imports")
@schema_list_options("action imports")
@schema_connection_options()
@pass_context
@require_auth
@handle_errors
def list_action_imports(
    ctx: DxsContext,
    connection_id: int | None,
    connection: str | None,
    org: str | None,
    top: int | None,
    skip: int | None,
    filter_expr: str | None,
    orderby: str | None,
    search: str | None,
    count: bool,
) -> None:
    """List all OData action imports (named action entry points in EntityContainer).

    Action imports are unbound action references declared in the EntityContainer,
    providing named HTTP entry points for OData actions.

    \b
    Examples:
        dxs schema action-imports --connection-id 32
        dxs schema action-imports --connection Demo --org MyOrg
        dxs schema action-imports --connection-id 32 --top 10
        dxs schema action-imports --connection-id 32 --search "execute"
        dxs schema action-imports --connection-id 32 --filter "contains(Name, 'Execute')"
        dxs schema action-imports --connection-id 32 --count
    """
    resolved_id = _resolve_connection(ctx, connection_id, connection, org)

    client = ApiClient()

    # If count-only requested, use $count=true query parameter
    if count:
        path, params = _url_for_action_imports(
            resolved_id, top=0, filter_expr=filter_expr, search=search, orderby=orderby
        )
        params["$count"] = "true"
        result = client.get(path, params=params)
        count_value = result.get("@odata.count", 0)

        count_resp = single(
            item={"count": count_value},
            semantic_key="action_import_count",
            connection_id=resolved_id,
        )
        ctx.output(count_resp)
        return

    # Fetch action imports (1 HTTP call)
    path, params = _url_for_action_imports(
        resolved_id, top=top, skip=skip, filter_expr=filter_expr, search=search, orderby=orderby
    )
    raw_body = client.get(path, params=params)
    imports_summary = _format_action_imports_result(raw_body)

    response = list_response(
        items=imports_summary,
        semantic_key="action_imports",
        connection_id=resolved_id,
    )

    ctx.output(response)


@schema.command(name="function-imports")
@schema_list_options("function imports")
@schema_connection_options()
@pass_context
@require_auth
@handle_errors
def list_function_imports(
    ctx: DxsContext,
    connection_id: int | None,
    connection: str | None,
    org: str | None,
    top: int | None,
    skip: int | None,
    filter_expr: str | None,
    orderby: str | None,
    search: str | None,
    count: bool,
) -> None:
    """List all OData function imports (named function entry points in EntityContainer).

    Function imports are unbound function references declared in the EntityContainer,
    providing named HTTP entry points for OData functions.

    \b
    Examples:
        dxs schema function-imports --connection-id 32
        dxs schema function-imports --connection Demo --org MyOrg
        dxs schema function-imports --connection-id 32 --search "total"
        dxs schema function-imports --connection-id 32 --filter "Name eq 'GetTotal'"
        dxs schema function-imports --connection-id 32 --count
    """
    resolved_id = _resolve_connection(ctx, connection_id, connection, org)

    client = ApiClient()

    # If count-only requested, use $count=true query parameter
    if count:
        path, params = _url_for_function_imports(
            resolved_id, top=0, filter_expr=filter_expr, search=search, orderby=orderby
        )
        params["$count"] = "true"
        result = client.get(path, params=params)
        count_value = result.get("@odata.count", 0)

        count_resp = single(
            item={"count": count_value},
            semantic_key="function_import_count",
            connection_id=resolved_id,
        )
        ctx.output(count_resp)
        return

    # Fetch function imports (1 HTTP call)
    path, params = _url_for_function_imports(
        resolved_id, top=top, skip=skip, filter_expr=filter_expr, search=search, orderby=orderby
    )
    raw_body = client.get(path, params=params)
    imports_summary = _format_function_imports_result(raw_body)

    response = list_response(
        items=imports_summary,
        semantic_key="function_imports",
        connection_id=resolved_id,
    )

    ctx.output(response)


@schema.command(name="describe-action-import")
@click.argument("import_name")
@schema_connection_options()
@pass_context
@require_auth
@handle_errors
def describe_action_import(
    ctx: DxsContext,
    import_name: str,
    connection_id: int | None,
    connection: str | None,
    org: str | None,
) -> None:
    """Show details for a specific OData action import.

    Fetches the action import with its full action definition ($expand=Action)
    in a single call, including parameters and return type.

    \b
    Examples:
        dxs schema describe-action-import ExecuteShipment --connection-id 32
        dxs schema describe-action-import CreateOrder --connection Demo --org MyOrg
    """
    resolved_id = _resolve_connection(ctx, connection_id, connection, org)

    client = ApiClient()

    # Fetch action import with expanded Action in one call (key endpoint + $expand)
    path, params = _url_for_describe_action_import(resolved_id, import_name)
    try:
        response = client.get(path, params=params)
    except ApiError as e:
        if e.code == "DXS-404-001":
            info = _schema_not_found_error("describe-action-import", import_name, resolved_id)
            raise ValidationError(
                message=info["message"], code=info["code"], suggestions=info["suggestions"]
            ) from e
        raise
    import_details = _format_describe_action_import_result(response)

    # Inline complex type fields for the embedded action
    if "action" in import_details and isinstance(import_details["action"], dict):
        type_cache: dict[str, list[dict[str, str]]] = {}
        _inline_complex_fields(client, resolved_id, import_details["action"], type_cache)

    response_out = single(
        item=import_details,
        semantic_key="action_import",
        connection_id=resolved_id,
    )

    ctx.output(response_out)


@schema.command(name="describe-function-import")
@click.argument("import_name")
@schema_connection_options()
@pass_context
@require_auth
@handle_errors
def describe_function_import(
    ctx: DxsContext,
    import_name: str,
    connection_id: int | None,
    connection: str | None,
    org: str | None,
) -> None:
    """Show details for a specific OData function import.

    Fetches the function import with its full function definition ($expand=Function)
    in a single call, including parameters and return type.

    \b
    Examples:
        dxs schema describe-function-import GetShipmentCost --connection-id 32
        dxs schema describe-function-import CalculateTotal --connection Demo --org MyOrg
    """
    resolved_id = _resolve_connection(ctx, connection_id, connection, org)

    client = ApiClient()

    # Fetch function import with expanded Function in one call (key endpoint + $expand)
    path, params = _url_for_describe_function_import(resolved_id, import_name)
    try:
        response = client.get(path, params=params)
    except ApiError as e:
        if e.code == "DXS-404-001":
            info = _schema_not_found_error("describe-function-import", import_name, resolved_id)
            raise ValidationError(
                message=info["message"], code=info["code"], suggestions=info["suggestions"]
            ) from e
        raise
    import_details = _format_describe_function_import_result(response)

    response_out = single(
        item=import_details,
        semantic_key="function_import",
        connection_id=resolved_id,
    )

    ctx.output(response_out)


@schema.command(name="properties")
@schema_list_options("properties")
@click.option(
    "--entity-type",
    "-e",
    type=str,
    default=None,
    help="Filter by entity type ID (e.g. 'Demo.Warehouse')",
)
@schema_connection_options()
@pass_context
@require_auth
@handle_errors
def list_properties(
    ctx: DxsContext,
    connection_id: int | None,
    connection: str | None,
    org: str | None,
    entity_type: str | None,
    top: int | None,
    skip: int | None,
    filter_expr: str | None,
    orderby: str | None,
    search: str | None,
    count: bool,
) -> None:
    """List properties across all entity types.

    Queries the Properties endpoint directly -- useful for finding which entities
    have a specific property name or type without describing each entity individually.

    \b
    Examples:
        dxs schema properties -c 32 --entity-type Demo.Warehouse
        dxs schema properties -c 32 --search "status"
        dxs schema properties -c 32 --filter "TypeId eq 'Edm.String' and IsKey eq true"
        dxs schema properties -c 32 --entity-type Demo.Invoice --top 20
        dxs schema properties -c 32 --count
    """
    resolved_id = _resolve_connection(ctx, connection_id, connection, org)

    if entity_type and "." not in entity_type:
        raise ValidationError(
            message=f"--entity-type requires a fully-qualified TypeId (e.g. 'Namespace.ClassName'), got: {entity_type!r}",
            code="DXS-SCHEMA-011",
            suggestions=[
                "Use fully-qualified TypeId: 'Namespace.ClassName' (e.g. 'Datex.FootPrint.Api.Invoice')",
                f"Run 'dxs schema entities -c {resolved_id}' to see valid entity types",
            ],
        )

    client = ApiClient()

    # Build combined filter (entity_type filter + user filter)
    filter_parts = []
    if entity_type:
        filter_parts.append(f"EntityTypeId eq '{_escape_odata_string(entity_type)}'")
    if filter_expr:
        filter_parts.append(filter_expr)
    combined_filter = " and ".join(filter_parts) if filter_parts else None

    # If count-only requested, use $count=true query parameter
    if count:
        path, params = FootPrintMetadataEndpoints.properties(
            resolved_id, top=0, filter=combined_filter, orderby=orderby, search=search
        )
        params["$count"] = "true"
        result = client.get(path, params=params)
        count_value = result.get("@odata.count", 0)

        count_resp = single(
            item={"count": count_value},
            semantic_key="property_count",
            connection_id=resolved_id,
        )
        ctx.output(count_resp)
        return

    # Fetch properties (1 HTTP call)
    path, params = FootPrintMetadataEndpoints.properties(
        resolved_id, top=top, skip=skip, filter=combined_filter, orderby=orderby, search=search
    )
    response = client.get(path, params=params)

    # Build response using shared formatter
    items = _format_properties_result(response)
    extra = {}
    if entity_type and not items:
        extra["entity_type_hint"] = (
            f"No properties found for entity type '{entity_type}'. "
            "Ensure you use the fully-qualified TypeId (e.g. 'Datex.FootPrint.Api.Warehouse'). "
            f"Run 'dxs schema entities -c {resolved_id}' to list available entity types."
        )
    ctx.output(
        list_response(
            items=items,
            semantic_key="properties",
            connection_id=resolved_id,
            **extra,
        )
    )


@schema.command(name="navigation-properties")
@schema_list_options("navigation properties")
@click.option(
    "--entity-type",
    "-e",
    type=str,
    default=None,
    help="Filter by entity type ID (e.g. 'Demo.Warehouse')",
)
@schema_connection_options()
@pass_context
@require_auth
@handle_errors
def list_navigation_properties(
    ctx: DxsContext,
    connection_id: int | None,
    connection: str | None,
    org: str | None,
    entity_type: str | None,
    top: int | None,
    skip: int | None,
    filter_expr: str | None,
    orderby: str | None,
    search: str | None,
    count: bool,
) -> None:
    """List navigation properties across all entity types.

    Queries the NavigationProperties endpoint directly -- useful for discovering
    $expand paths and relationships without describing each entity individually.

    \b
    Examples:
        dxs schema navigation-properties -c 32 --entity-type Demo.Warehouse
        dxs schema navigation-properties -c 32 --search "order"
        dxs schema navigation-properties -c 32 --filter "IsCollection eq true"
        dxs schema navigation-properties -c 32 --count
    """
    resolved_id = _resolve_connection(ctx, connection_id, connection, org)

    if entity_type and "." not in entity_type:
        raise ValidationError(
            message=f"--entity-type requires a fully-qualified TypeId (e.g. 'Namespace.ClassName'), got: {entity_type!r}",
            code="DXS-SCHEMA-011",
            suggestions=[
                "Use fully-qualified TypeId: 'Namespace.ClassName' (e.g. 'Datex.FootPrint.Api.Invoice')",
                f"Run 'dxs schema entities -c {resolved_id}' to see valid entity types",
            ],
        )

    client = ApiClient()

    # Build combined filter (entity_type filter + user filter)
    filter_parts = []
    if entity_type:
        filter_parts.append(f"EntityTypeId eq '{_escape_odata_string(entity_type)}'")
    if filter_expr:
        filter_parts.append(filter_expr)
    combined_filter = " and ".join(filter_parts) if filter_parts else None

    # If count-only requested, use $count=true query parameter
    if count:
        path, params = FootPrintMetadataEndpoints.navigation_properties(
            resolved_id, top=0, filter=combined_filter, orderby=orderby, search=search
        )
        params["$count"] = "true"
        result = client.get(path, params=params)
        count_value = result.get("@odata.count", 0)

        count_resp = single(
            item={"count": count_value},
            semantic_key="nav_property_count",
            connection_id=resolved_id,
        )
        ctx.output(count_resp)
        return

    # Fetch navigation properties (1 HTTP call)
    path, params = FootPrintMetadataEndpoints.navigation_properties(
        resolved_id, top=top, skip=skip, filter=combined_filter, orderby=orderby, search=search
    )
    response = client.get(path, params=params)

    # Build response using shared formatter
    items = _format_nav_properties_result(response)
    extra = {}
    if entity_type and not items:
        extra["entity_type_hint"] = (
            f"No navigation properties found for entity type '{entity_type}'. "
            "Ensure you use the fully-qualified TypeId (e.g. 'Datex.FootPrint.Api.Warehouse'). "
            f"Run 'dxs schema entities -c {resolved_id}' to list available entity types."
        )
    ctx.output(
        list_response(
            items=items,
            semantic_key="navigation_properties",
            connection_id=resolved_id,
            **extra,
        )
    )


@schema.command(name="describe-properties")
@click.argument("entity_type_id")
@click.argument("property_name")
@schema_connection_options()
@pass_context
@require_auth
@handle_errors
def describe_property(
    ctx: DxsContext,
    entity_type_id: str,
    property_name: str,
    connection_id: int | None,
    connection: str | None,
    org: str | None,
) -> None:
    """Show details for a specific property.

    Fetches a single property by its composite key (EntityTypeId + Name).
    Use 'dxs schema properties' to list all properties and find the EntityTypeId.

    \b
    Examples:
        dxs schema describe-properties Demo.Warehouse LookupCode -c 32
        dxs schema describe-properties Demo.Item Description -c 32
    """
    resolved_id = _resolve_connection(ctx, connection_id, connection, org)

    client = ApiClient()

    # Verify the entity type exists before looking up the property
    try:
        et = _fetch_entity_type(client, resolved_id, entity_type_id)
    except ApiError as e:
        if e.code != "DXS-404-001":
            raise
        et = None
    if et is None:
        info = _schema_not_found_error(
            "describe-properties", property_name, resolved_id, entity_type_id=entity_type_id
        )
        raise ValidationError(
            message=info["message"], code=info["code"], suggestions=info["suggestions"]
        )

    path, params = _url_for_describe_property(resolved_id, entity_type_id, property_name)
    try:
        response = client.get(path, params=params)
    except ApiError as e:
        if e.code == "DXS-404-001":
            info = _schema_not_found_error(
                "describe-properties", property_name, resolved_id, entity_type_id=entity_type_id
            )
            raise ValidationError(
                message=info["message"], code=info["code"], suggestions=info["suggestions"]
            ) from e
        raise

    prop_dict = _format_describe_property_result(response)
    result = single(item=prop_dict, semantic_key="property", connection_id=resolved_id)
    ctx.output(result)


@schema.command(name="describe-navigation-properties")
@click.argument("entity_type_id")
@click.argument("property_name")
@schema_connection_options()
@pass_context
@require_auth
@handle_errors
def describe_navigation_property(
    ctx: DxsContext,
    entity_type_id: str,
    property_name: str,
    connection_id: int | None,
    connection: str | None,
    org: str | None,
) -> None:
    """Show details for a specific navigation property.

    Fetches a single navigation property by its composite key (EntityTypeId + Name).
    Use 'dxs schema navigation-properties' to list all navigation properties and find the EntityTypeId.

    \b
    Examples:
        dxs schema describe-navigation-properties Demo.Warehouse Items -c 32
        dxs schema describe-navigation-properties Demo.Warehouse Manager -c 32
    """
    resolved_id = _resolve_connection(ctx, connection_id, connection, org)

    client = ApiClient()

    # Verify the entity type exists before looking up the property
    try:
        et = _fetch_entity_type(client, resolved_id, entity_type_id)
    except ApiError as e:
        if e.code != "DXS-404-001":
            raise
        et = None
    if et is None:
        info = _schema_not_found_error(
            "describe-navigation-properties",
            property_name,
            resolved_id,
            entity_type_id=entity_type_id,
        )
        raise ValidationError(
            message=info["message"], code=info["code"], suggestions=info["suggestions"]
        )

    path, params = _url_for_describe_navigation_property(resolved_id, entity_type_id, property_name)
    try:
        response = client.get(path, params=params)
    except ApiError as e:
        if e.code == "DXS-404-001":
            info = _schema_not_found_error(
                "describe-navigation-properties",
                property_name,
                resolved_id,
                entity_type_id=entity_type_id,
            )
            raise ValidationError(
                message=info["message"], code=info["code"], suggestions=info["suggestions"]
            ) from e
        raise

    nav_dict = _format_describe_navigation_property_result(response)
    result = single(item=nav_dict, semantic_key="navigation_property", connection_id=resolved_id)
    ctx.output(result)


@schema.command(name="metadata")
@schema_connection_options()
@pass_context
@require_auth
@handle_errors
def get_metadata(
    ctx: DxsContext, connection_id: int | None, connection: str | None, org: str | None
) -> None:
    """Get raw OData metadata document (EDMX XML) for the schema discovery API.

    Returns the EDMX XML that describes the schema API itself -- i.e. the
    entity types, properties and navigation properties of the metadata
    endpoints (EntityTypeDto, PropertyDto, NavigationPropertyDto, etc.).

    This is NOT the Footprint business-domain EDMX (Warehouses, Orders, ...).
    Use 'dxs odata metadata' or the individual schema subcommands to explore
    the business model.

    \b
    Examples:
        dxs schema metadata --connection-id 32
        dxs schema metadata --connection Demo --org MyOrg
    """
    resolved_id = _resolve_connection(ctx, connection_id, connection, org)

    client = ApiClient()

    # Fetch raw metadata XML (1 HTTP call)
    path = FootPrintMetadataEndpoints.metadata(resolved_id)
    xml_content = client.get_text(path)

    # Build response
    response = single(
        item={"xml": xml_content},
        semantic_key="edmx",  # Changed from "metadata" to avoid collision with response metadata
        connection_id=resolved_id,
    )

    ctx.output(response)


@schema.command(name="batch")
@click.option(
    "--request",
    "-r",
    "requests",
    multiple=True,
    required=True,
    help=(
        "A schema sub-command to execute (repeatable). "
        "Syntax mirrors individual schema commands. "
        "Example: --request 'describe-entity Warehouses' --request 'enums --search status'"
    ),
)
@schema_connection_options()
@pass_context
@require_auth
@handle_errors
def batch_schema(
    ctx: DxsContext,
    requests: tuple[str, ...],
    connection_id: int | None,
    connection: str | None,
    org: str | None,
) -> None:
    """Execute multiple schema sub-commands in a single batch HTTP request.

    Accepts the same sub-commands as the individual schema commands (except 'batch').
    All sub-commands run against the same connection.
    Results are returned as an array -- one entry per --request, in the same order.

    \b
    Examples:
        dxs schema batch -c 32 \\
          --request 'describe-entity Warehouses' \\
          --request 'describe-entity Items' \\
          --request 'describe-relationships Shipments' \\
          --request 'enums --search status'
        dxs schema batch -c 32 \\
          --request 'entities --top 20' \\
          --request 'actions --search create'
        dxs schema batch -c 32 \\
          --request 'entities --count' \\
          --request 'properties --count' \\
          --request 'enums --count' \\
          --request 'actions --count'
    """
    resolved_id = _resolve_connection(ctx, connection_id, connection, org)

    # Validate all --request strings up-front (fail fast before any HTTP)
    parsed_requests: list[ParsedRequest] = []
    for req_str in requests:
        try:
            parsed_requests.append(_parse_request(req_str))
        except ValidationError as e:
            ctx.output_error(e)
            raise SystemExit(1) from e

    client = ApiClient()

    results, http_calls = _execute_batch(client, resolved_id, parsed_requests)

    import json as _json

    output_bytes = len(_json.dumps(results, default=str).encode("utf-8"))

    response = list_response(
        items=results,
        semantic_key="results",
        connection_id=resolved_id,
        batch_count=len(results),
        http_calls=http_calls,
        output_bytes=output_bytes,
    )
    ctx.output(response)


# Resource types to count in overview, with their URL builders and display names
_OVERVIEW_RESOURCES: list[tuple[str, str, Callable[[int], tuple[str, dict[str, str | int]]]]] = [
    ("entity_sets", "EntitySets", lambda cid: FootPrintMetadataEndpoints.entity_sets(cid)),
    ("entity_types", "EntityTypes", lambda cid: FootPrintMetadataEndpoints.entity_types(cid)),
    ("enum_types", "EnumTypes", lambda cid: FootPrintMetadataEndpoints.enum_types(cid)),
    ("actions", "Actions", lambda cid: FootPrintMetadataEndpoints.actions(cid)),
    ("functions", "Functions", lambda cid: FootPrintMetadataEndpoints.functions(cid)),
    ("complex_types", "ComplexTypes", lambda cid: FootPrintMetadataEndpoints.complex_types(cid)),
    ("singletons", "Singletons", lambda cid: FootPrintMetadataEndpoints.singletons(cid)),
    ("action_imports", "ActionImports", lambda cid: FootPrintMetadataEndpoints.action_imports(cid)),
    (
        "function_imports",
        "FunctionImports",
        lambda cid: FootPrintMetadataEndpoints.function_imports(cid),
    ),
]


@schema.command(name="overview")
@schema_connection_options()
@pass_context
@require_auth
@handle_errors
def schema_overview(
    ctx: DxsContext,
    connection_id: int | None,
    connection: str | None,
    org: str | None,
) -> None:
    """Show a high-level summary of the OData model in a single call.

    Returns counts for all resource types (entity sets, entity types, enums,
    actions, functions, complex types, singletons, action imports, function imports)
    using a single OData $batch request.

    \b
    Examples:
        dxs schema overview --connection-id 32
        dxs schema overview -c 2
    """
    resolved_id = _resolve_connection(ctx, connection_id, connection, org)

    client = ApiClient()
    batch_path = FootPrintMetadataEndpoints.batch(resolved_id)

    # Build count requests for all resource types
    batch_requests: list[dict[str, str]] = []
    for key, _display_name, url_builder in _OVERVIEW_RESOURCES:
        path, params = _url_with_count(url_builder(resolved_id))
        batch_requests.append(
            {
                "id": key,
                "method": "GET",
                "url": _to_batch_url(path, params, resolved_id),
            }
        )

    # Single batch HTTP call for all counts
    raw_responses = client.post_batch(batch_path, batch_requests)
    responses_by_id = {r["id"]: r for r in raw_responses}

    # Extract counts
    overview: dict[str, int] = {}
    for key, _display_name, _url_builder in _OVERVIEW_RESOURCES:
        resp = responses_by_id.get(key, {})
        body = resp.get("body", {}) if resp.get("status") == 200 else {}
        overview[key] = body.get("@odata.count", 0)

    response = single(
        item=overview,
        semantic_key="overview",
        connection_id=resolved_id,
    )
    ctx.output(response)
