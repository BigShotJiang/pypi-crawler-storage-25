"""Report batch command."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import click

from dxs.cli import DxsContext, handle_errors, pass_context
from dxs.commands.report import (
    _STYLE_KEY_MAP,
    _parse_report,
    _read_report,
    _sanitize_expression,
    _serialize_report,
    _write_report,
    report,
)
from dxs.utils.responses import single

_MAX_BATCH_OPS = 25
_BATCH_DELAY_DEFAULT = 0.3

# Non-style keys that map to item properties
_POSITION_KEYS = {"left", "top", "width", "height"}
_ITEM_KEY_MAP: dict[str, str] = {
    "left": "Left",
    "top": "Top",
    "width": "Width",
    "height": "Height",
    "value": "Value",
    "name": "Name",
    "symbology": "Symbology",
    "caption": "Caption",
    "can-grow": "CanGrow",
    "start-x": "StartPoint.X",
    "start-y": "StartPoint.Y",
    "end-x": "EndPoint.X",
    "end-y": "EndPoint.Y",
    "line-width": "LineWidth",
    "line-style": "LineStyle",
    "dataset": "DataSetName",
    "columns": "Columns",
}


def _op_to_item_props(op: dict[str, Any]) -> dict[str, Any]:
    """Convert a batch op dict to an engine-compatible item_props dict."""
    item_props: dict[str, Any] = {"Type": op["type"], "Name": op["name"]}
    style: dict[str, Any] = {}
    unknown_keys: list[str] = []

    for key, val in op.items():
        if key in ("action", "type", "name", "parent"):
            continue
        if key in _STYLE_KEY_MAP:
            mapped = _STYLE_KEY_MAP[key]
            if "." in mapped:
                parent, child = mapped.split(".", 1)
                style.setdefault(parent, {})[child] = val
            else:
                style[mapped] = val
        elif key in _ITEM_KEY_MAP:
            mapped = _ITEM_KEY_MAP[key]
            if mapped.startswith("StartPoint."):
                item_props.setdefault("StartPoint", {})[mapped.split(".")[1]] = val
            elif mapped.startswith("EndPoint."):
                item_props.setdefault("EndPoint", {})[mapped.split(".")[1]] = val
            else:
                item_props[mapped] = (
                    _sanitize_expression(val) if mapped == "Value" and isinstance(val, str) else val
                )
        # Unknown keys are passed through as-is (PascalCase)
        elif key[0].isupper():
            item_props[key] = val
        else:
            unknown_keys.append(key)

    if unknown_keys:
        click.echo(f"Warning: unrecognized keys ignored: {', '.join(unknown_keys)}", err=True)

    # Warn if line uses position keys instead of start/end
    if op.get("type") == "line" and any(k in op for k in ("left", "top", "width", "height")):
        if not any(k in op for k in ("start-x", "start-y", "end-x", "end-y")):
            click.echo(
                "Warning: line elements need start-x/start-y/end-x/end-y, "
                "not left/top/width/height. The SVG renderer requires endpoints.",
                err=True,
            )

    if style:
        item_props["Style"] = style
    return item_props


def _op_to_set_props(op: dict[str, Any]) -> dict[str, Any]:
    """Convert a batch set op dict to an engine-compatible updates dict.

    Unlike _op_to_item_props (for add), this omits Type and Name from the
    output since set operates on an existing element.
    """
    updates: dict[str, Any] = {}
    style: dict[str, Any] = {}
    unknown_keys: list[str] = []

    for key, val in op.items():
        if key in ("action", "name"):
            continue
        if key in _STYLE_KEY_MAP:
            mapped = _STYLE_KEY_MAP[key]
            if "." in mapped:
                parent, child = mapped.split(".", 1)
                style.setdefault(parent, {})[child] = val
            else:
                style[mapped] = val
        elif key in _ITEM_KEY_MAP:
            mapped = _ITEM_KEY_MAP[key]
            if mapped.startswith("StartPoint."):
                updates.setdefault("StartPoint", {})[mapped.split(".")[1]] = val
            elif mapped.startswith("EndPoint."):
                updates.setdefault("EndPoint", {})[mapped.split(".")[1]] = val
            else:
                updates[mapped] = (
                    _sanitize_expression(val) if mapped == "Value" and isinstance(val, str) else val
                )
        # Unknown keys are passed through as-is (PascalCase)
        elif key[0].isupper():
            updates[key] = val
        else:
            unknown_keys.append(key)

    if unknown_keys:
        click.echo(f"Warning: unrecognized keys ignored: {', '.join(unknown_keys)}", err=True)
    if style:
        updates["Style"] = style
    return updates


@report.command("batch")
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
@click.option("--ops", default=None, help='JSON array of operations (use "-" for stdin)')
@click.option(
    "--ops-file",
    type=click.Path(exists=True, dir_okay=False),
    default=None,
    help="Read operations from a JSON file",
)
@click.option(
    "--delay",
    type=float,
    default=_BATCH_DELAY_DEFAULT,
    help=f"Seconds between operations (default: {_BATCH_DELAY_DEFAULT})",
)
@pass_context
@handle_errors
def batch(ctx: DxsContext, file: str, ops: str | None, ops_file: str | None, delay: float) -> None:
    """Apply a batch of report operations in sequence.

    Each operation is applied and written to the file individually so
    the design canvas can show updates in real time. Operations are
    processed with a short delay between them.

    Supports add (textbox, line, barcode, rectangle, image), set, move, and remove.
    Maximum 25 operations per batch.

    Operations can be provided via --ops (inline JSON or "-" for stdin)
    or --ops-file (path to a JSON file). Exactly one must be specified.

    \b
    Examples:
        dxs report batch report.rdlx-json --ops '[
          {"action": "add", "type": "textbox", "name": "title",
           "value": "BILL OF LADING", "left": "0in", "top": "0in",
           "width": "4in", "height": "0.4in",
           "font-size": "18pt", "font-weight": "Bold"},
          {"action": "set", "name": "title", "color": "Navy"},
          {"action": "move", "name": "title", "top": "0.1in"},
          {"action": "remove", "name": "old_element"}
        ]'

        # Read from stdin (avoids shell escaping):
        dxs report batch report.rdlx-json --ops - <<'BATCH'
        [{"action": "add", "type": "textbox", "name": "t",
          "value": "=Fields!Code.Value", "left": "0in", "top": "0in",
          "width": "4in", "height": "0.4in"}]
        BATCH

        # Read from file:
        dxs report batch report.rdlx-json --ops-file /tmp/ops.json
    """
    import sys
    import time

    from dxs.report.engine import add_child_item, add_item, remove_item, set_item_properties
    from dxs.utils.errors import ValidationError

    if ops is not None and ops_file is not None:
        raise ValidationError(
            message="Cannot specify both --ops and --ops-file",
            code="DXS-RPT-060",
            suggestions=["Use --ops for inline JSON or --ops-file for a file, not both"],
        )
    if ops is None and ops_file is None:
        raise ValidationError(
            message="Must specify either --ops or --ops-file",
            code="DXS-RPT-060",
            suggestions=["Use --ops '{...}' or --ops-file path/to/ops.json"],
        )

    if ops_file is not None:
        raw = Path(ops_file).read_text()
    elif ops == "-":
        raw = sys.stdin.read()
    else:
        raw = ops  # type: ignore[assignment]

    try:
        operations: list[dict[str, Any]] = json.loads(raw)
    except json.JSONDecodeError as e:
        raise ValidationError(
            message=f"Invalid JSON in --ops: {e}",
            code="DXS-RPT-060",
            suggestions=["Provide a valid JSON array of operation objects"],
        ) from e

    if not isinstance(operations, list):
        raise ValidationError(
            message="--ops must be a JSON array",
            code="DXS-RPT-060",
            suggestions=["Wrap operations in [...]: --ops '[{...}, {...}]'"],
        )

    if len(operations) > _MAX_BATCH_OPS:
        raise ValidationError(
            message=f"Too many operations: {len(operations)} (max {_MAX_BATCH_OPS})",
            code="DXS-RPT-061",
            suggestions=[f"Split into batches of {_MAX_BATCH_OPS} or fewer"],
        )

    results: list[dict[str, Any]] = []

    for i, op in enumerate(operations):
        action = op.get("action", "")
        name = op.get("name", "")

        if not action:
            raise ValidationError(
                message=f"Operation {i} missing 'action' field",
                code="DXS-RPT-062",
            )
        if not name:
            raise ValidationError(
                message=f"Operation {i} missing 'name' field",
                code="DXS-RPT-062",
            )

        # Re-read for each op so the file watcher sees individual changes
        data = _read_report(file)
        report_def = _parse_report(data)

        if action == "add":
            element_type = op.get("type", "")
            if not element_type:
                raise ValidationError(
                    message=f"Operation {i} (add) missing 'type' field",
                    code="DXS-RPT-062",
                )
            item_props = _op_to_item_props(op)
            parent_name = op.get("parent")
            if parent_name in ("PageHeader", "PageFooter"):
                from dxs.report.engine import add_page_section_item

                add_page_section_item(report_def, parent_name, item_props)
            elif parent_name:
                add_child_item(report_def, parent_name=parent_name, item_props=item_props)
            else:
                add_item(report_def, item_props)
            results.append({"action": "add", "element": name, "type": element_type})

        elif action == "move":
            item = report_def.find_item(name)
            if item is None:
                raise ValidationError(
                    message=f"Element '{name}' not found",
                    code="DXS-RPT-020",
                )
            changed = {}
            for pos_key in ("left", "top", "width", "height"):
                if pos_key in op:
                    setattr(item, pos_key.capitalize(), op[pos_key])
                    changed[pos_key] = op[pos_key]
            for coord_key, prop, axis in [
                ("start-x", "StartPoint", "X"),
                ("start-y", "StartPoint", "Y"),
                ("end-x", "EndPoint", "X"),
                ("end-y", "EndPoint", "Y"),
            ]:
                if coord_key in op:
                    if item.model_extra is None:
                        object.__setattr__(item, "__pydantic_extra__", {})
                    pt = item.model_extra.get(prop, {})
                    pt[axis] = op[coord_key]
                    item.model_extra[prop] = pt
                    changed[coord_key] = op[coord_key]
            results.append({"action": "move", "element": name, "changes": changed})

        elif action == "set":
            item = report_def.find_item(name)
            if item is None:
                raise ValidationError(
                    message=f"Element '{name}' not found",
                    code="DXS-RPT-020",
                )
            updates = _op_to_set_props(op)
            set_item_properties(item, updates)
            results.append({"action": "set", "element": name, "changes": list(updates.keys())})

        elif action == "remove":
            if not remove_item(report_def, name):
                raise ValidationError(
                    message=f"Element '{name}' not found",
                    code="DXS-RPT-020",
                )
            results.append({"action": "remove", "element": name})

        else:
            raise ValidationError(
                message=f"Unknown action '{action}' in operation {i}",
                code="DXS-RPT-062",
                suggestions=["Supported actions: add, set, move, remove"],
            )

        _write_report(file, _serialize_report(report_def))

        # Delay between ops so the file watcher fires per change
        if i < len(operations) - 1:
            time.sleep(delay)

    ctx.output(
        single(
            {
                "file": file,
                "operations": len(results),
                "results": results,
            },
            "batch_results",
        )
    )
