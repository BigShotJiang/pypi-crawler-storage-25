"""Report authoring commands: dxs report [...].

Provides RDL (RDLX-JSON) report authoring for RDLX-JSON reports
in the Datex Studio platform. Commands support schema discovery,
scaffolding, element placement, validation, and upload/download.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import click


@click.group()
def report() -> None:
    """Report authoring commands (RDL/RDLX-JSON).

    Create, modify, validate, and upload ActiveReportsJS reports
    for the Datex Studio platform. Reports are .rdlx-json files
    containing positioned elements (textboxes, barcodes, images,
    tables, lines, rectangles, shapes) with data binding via
    expressions like =Fields!Name.Value.

    \b
    Workflow:
      1. Discover:  dxs report schema items/barcodes/expressions/document
      2. Create:    dxs report create <folder> [--page ...] OR
                    dxs report scaffold <folder> --template <name>
      3. Build:     dxs report add <type> <folder>/report.rdlx-json --name ... --left ... --top ...
                    dxs report set <folder>/report.rdlx-json <element> --value ...
                    dxs report move <folder>/report.rdlx-json <element> --left ...
                    dxs report remove <folder>/report.rdlx-json <element>
      4. Bind:      dxs report datasource add <folder> --owned ds.json:alias
      5. Inspect:   dxs report inspect <folder>/report.rdlx-json
      6. Validate:  dxs report validate <folder>/report.rdlx-json
      7. Deploy:    dxs report assemble <folder> -o wrapper.json
                    dxs report upload wrapper.json --branch <id>
                    dxs report download --branch <id> --reference-name <name>

    \b
    Coordinate system:
      Positions (--left, --top) are relative to the content area
      (inside margins). Left=0in, Top=0in is the top-left corner
      of the printable area. All sizes use CSS-like units (in, cm, mm, pt).

    \b
    Quick start:
        dxs report create bol_report --page letter --landscape
        dxs report add textbox bol_report/report.rdlx-json --name Title --left 0in --top 0in --width 3in --height 0.3in --value "Bill of Lading" --font-size 18pt --font-weight Bold
        dxs report add barcode bol_report/report.rdlx-json --name ProBarcode --symbology Code128 --left 5in --top 0in --width 2.5in --height 0.75in --value "=Fields!PRONumber.Value"
        dxs report validate bol_report/report.rdlx-json
    """


@report.group()
def schema() -> None:
    """RDL schema reference for agent discovery.

    Discover available report item types, barcode symbologies,
    expression syntax, and document structure.

    \b
    Examples:
        dxs report schema document
        dxs report schema items
        dxs report schema item textbox
        dxs report schema barcodes
        dxs report schema expressions
    """


# -- Shared helpers (imported by submodules) -------------------------------


def _read_report(file_path: str) -> dict[str, Any]:
    """Read and parse an RDLX-JSON file.

    Args:
        file_path: Path to the .rdlx-json file.

    Returns:
        Parsed report definition dict.

    Raises:
        ValidationError: If file doesn't exist or isn't valid JSON.
    """
    from dxs.utils.errors import ValidationError

    path = Path(file_path)
    if not path.exists():
        raise ValidationError(
            message=f"Report file not found: {file_path}",
            code="DXS-RPT-010",
            suggestions=[
                "Check the file path",
                "Use 'dxs report scaffold' or 'dxs report create' to create a new report",
            ],
        )

    try:
        text = path.read_text(encoding="utf-8")
        return json.loads(text)  # type: ignore[no-any-return]
    except json.JSONDecodeError as e:
        raise ValidationError(
            message=f"Invalid JSON in {file_path}: {e}",
            code="DXS-RPT-011",
        ) from e


def _write_report(file_path: str, data: dict[str, Any]) -> None:
    """Write report definition to an RDLX-JSON file.

    Args:
        file_path: Path to write the .rdlx-json file.
        data: Report definition dict.
    """
    path = Path(file_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=4) + "\n", encoding="utf-8")


def _sanitize_expression(value: str) -> str:
    """Strip zsh-escaped \\! back to ! in RDL expressions.

    zsh's -c mode escapes ! to \\! even in single-quoted strings.
    Since \\! is never valid in any RDL context, this is safe to
    apply to all string values.
    """
    return value.replace("\\!", "!")


# Maps kebab-case style keys to PascalCase Style dict keys
_STYLE_KEY_MAP: dict[str, str] = {
    "font-size": "FontSize",
    "font-weight": "FontWeight",
    "font-family": "FontFamily",
    "font-style": "FontStyle",
    "color": "Color",
    "background-color": "BackgroundColor",
    "text-align": "TextAlign",
    "vertical-align": "VerticalAlign",
    "text-decoration": "TextDecoration",
    "border-style": "Border.Style",
    "border-width": "Border.Width",
    "border-color": "Border.Color",
    "border-top-style": "TopBorder.Style",
    "border-top-width": "TopBorder.Width",
    "border-top-color": "TopBorder.Color",
    "border-bottom-style": "BottomBorder.Style",
    "border-bottom-width": "BottomBorder.Width",
    "border-bottom-color": "BottomBorder.Color",
    "border-left-style": "LeftBorder.Style",
    "border-left-width": "LeftBorder.Width",
    "border-left-color": "LeftBorder.Color",
    "border-right-style": "RightBorder.Style",
    "border-right-width": "RightBorder.Width",
    "border-right-color": "RightBorder.Color",
    "padding": "PaddingLeft",
    "padding-left": "PaddingLeft",
    "padding-right": "PaddingRight",
    "padding-top": "PaddingTop",
    "padding-bottom": "PaddingBottom",
    "format": "Format",
}


def _parse_style_string(style_str: str) -> dict[str, Any]:
    """Parse 'background-color:#f0f0f0;padding:2pt' into a Style dict.

    Uses _STYLE_KEY_MAP for key mapping. Expands padding to all four sides.
    Handles Border.* nesting.
    """
    style: dict[str, Any] = {}
    for part in style_str.split(";"):
        part = part.strip()
        if not part or ":" not in part:
            continue
        key, val = part.split(":", 1)
        key, val = key.strip(), val.strip()
        if key in _STYLE_KEY_MAP:
            mapped = _STYLE_KEY_MAP[key]
            if key == "padding":
                style["PaddingLeft"] = val
                style["PaddingRight"] = val
                style["PaddingTop"] = val
                style["PaddingBottom"] = val
            elif "." in mapped:
                parent, child = mapped.split(".", 1)
                style.setdefault(parent, {})[child] = val
            else:
                style[mapped] = val
        elif key[0].isupper():
            style[key] = val
        else:
            click.echo(f"Warning: unrecognized style key: {key}", err=True)
    return style


def _parse_sort_expression(expr: str) -> dict[str, str]:
    """Parse 'EXPRESSION:DIRECTION' into a SortExpression dict.

    Direction is case-insensitive: asc/desc → Ascending/Descending.
    """
    from dxs.utils.errors import ValidationError

    parts = expr.rsplit(":", 1)
    if len(parts) != 2 or parts[1].lower() not in ("asc", "desc"):
        raise ValidationError(
            message=f"Invalid sort expression: '{expr}'. Expected FORMAT:DIRECTION (asc/desc).",
            code="DXS-RPT-080",
            suggestions=["Example: '=Fields!Name.Value:asc'"],
        )
    direction = "Ascending" if parts[1].lower() == "asc" else "Descending"
    return {"Value": _sanitize_expression(parts[0]), "Direction": direction}


def _parse_named_value(value: str) -> tuple[str, str]:
    """Parse 'NAME:VALUE' into (name, value) tuple.

    Splits on the first colon only.
    """
    from dxs.utils.errors import ValidationError

    if ":" not in value:
        raise ValidationError(
            message=f"Expected NAME:VALUE format, got: '{value}'",
            code="DXS-RPT-081",
            suggestions=["Example: 'wh:=Fields!WarehouseId.Value'"],
        )
    name, val = value.split(":", 1)
    return name, val


def _derive_group_name(tablix_name: str, group_alias: str) -> str:
    """Derive a group name from tablix name and alias.

    PascalCases the alias: 'wh' → 'Wh', 'warehouse' → 'Warehouse'.
    """
    return f"{tablix_name}_{group_alias.capitalize()}Group"


def _parse_report(data: dict[str, Any]) -> Any:
    """Parse raw dict into a ReportDefinition model.

    Args:
        data: Raw report definition dict.

    Returns:
        ReportDefinition model instance.
    """
    from dxs.report.models import ReportDefinition

    return ReportDefinition.model_validate(data)


def _serialize_report(report_def: Any) -> dict[str, Any]:
    """Serialize a ReportDefinition model to dict.

    Args:
        report_def: ReportDefinition model instance.

    Returns:
        Serialized dict suitable for JSON output.
    """
    return report_def.model_dump(exclude_none=True)  # type: ignore[no-any-return]


@report.group("add")
def add() -> None:
    """Add an element to a report.

    \b
    Element types: textbox, barcode, image, table, line, rectangle, shape

    \b
    Examples:
        dxs report add textbox report.rdlx-json --name Title --left 1in --top 0.5in --width 3in --height 0.3in --value "Title"
        dxs report add barcode report.rdlx-json --name ProBarcode --symbology Code128 --left 5in --top 0.5in --width 2in --height 0.5in --value "=Fields!PRO.Value"
    """


@report.group("tablix")
def tablix() -> None:
    """Advanced tablix operations.

    \b
    Commands for modifying existing tablix elements:
      add-group    Add a row group to an existing tablix
      add-row      Add a row to an existing tablix group or table level
    """


@report.group("datasource")
def datasource_group() -> None:
    """Manage datasources within a report folder.

    \b
    Commands:
      add       Add an owned or external datasource to the folder
      remove    Remove a datasource by alias
      list      List all datasources in the folder
    """


def _position_options(f: Any) -> Any:
    """Add common position/size options to a command."""
    f = click.option("--left", default="0in", help="Left position (e.g., 1in, 2.5in)")(f)
    f = click.option("--top", default="0in", help="Top position")(f)
    f = click.option("--width", default="1in", help="Element width")(f)
    f = click.option("--height", default="0.25in", help="Element height")(f)
    return f


def _style_options(f: Any) -> Any:
    """Add common style options to a command."""
    f = click.option("--font-size", default=None, help="Font size (e.g., 10pt, 12pt)")(f)
    f = click.option(
        "--font-weight",
        default=None,
        type=click.Choice(["Normal", "Bold"], case_sensitive=False),
        help="Font weight",
    )(f)
    f = click.option("--font-family", default=None, help="Font family (e.g., Arial)")(f)
    f = click.option("--color", default=None, help="Text/foreground color")(f)
    f = click.option("--background-color", default=None, help="Background color")(f)
    f = click.option(
        "--text-align",
        default=None,
        type=click.Choice(["Left", "Center", "Right", "Justify"], case_sensitive=False),
        help="Text alignment",
    )(f)
    f = click.option(
        "--vertical-align",
        default=None,
        type=click.Choice(["Top", "Middle", "Bottom"], case_sensitive=False),
        help="Vertical alignment",
    )(f)
    f = click.option(
        "--border-style", default=None, help="Border style (None, Solid, Dashed, Dotted)"
    )(f)
    f = click.option("--border-color", default=None, help="Border color")(f)
    f = click.option("--border-width", default=None, help="Border width (e.g., 1pt)")(f)
    f = click.option("--padding", default=None, help="Padding all sides (e.g., 2pt)")(f)
    f = click.option(
        "--format",
        "format_str",
        default=None,
        help="Format string for numbers/dates (e.g., N2, C2, P1, MM/dd/yyyy)",
    )(f)
    return f


def _build_style(
    font_size: str | None = None,
    font_weight: str | None = None,
    font_family: str | None = None,
    color: str | None = None,
    background_color: str | None = None,
    text_align: str | None = None,
    vertical_align: str | None = None,
    border_style: str | None = None,
    border_color: str | None = None,
    border_width: str | None = None,
    padding: str | None = None,
    format_str: str | None = None,
) -> dict[str, str] | None:
    """Build a Style dict from individual options."""
    style: dict[str, str] = {}
    if font_size:
        style["FontSize"] = font_size
    if font_weight:
        style["FontWeight"] = font_weight
    if font_family:
        style["FontFamily"] = font_family
    if color:
        style["Color"] = color
    if background_color:
        style["BackgroundColor"] = background_color
    if text_align:
        style["TextAlign"] = text_align
    if vertical_align:
        style["VerticalAlign"] = vertical_align
    if border_style or border_color or border_width:
        border: dict[str, str] = {}
        if border_style:
            border["Style"] = border_style
        if border_width:
            border["Width"] = border_width
        if border_color:
            border["Color"] = border_color
        style["Border"] = border
    if padding:
        style["PaddingLeft"] = padding
        style["PaddingRight"] = padding
        style["PaddingTop"] = padding
        style["PaddingBottom"] = padding
    if format_str:
        style["Format"] = format_str
    return style or None


# -- Submodule imports (register commands on groups) -------------------------

from dxs.commands.report import add_cmds as _add_cmds  # noqa: F401, E402
from dxs.commands.report import api as _api  # noqa: F401, E402
from dxs.commands.report import batch as _batch  # noqa: F401, E402
from dxs.commands.report import create as _create  # noqa: F401, E402
from dxs.commands.report import data as _data  # noqa: F401, E402
from dxs.commands.report import dataset as _dataset  # noqa: F401, E402
from dxs.commands.report import edit as _edit  # noqa: F401, E402
from dxs.commands.report import folder as _folder  # noqa: F401, E402
from dxs.commands.report import preview as _preview  # noqa: F401, E402
from dxs.commands.report import schema_cmds as _schema_cmds  # noqa: F401, E402
