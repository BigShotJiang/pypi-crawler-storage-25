"""Report schema discovery commands."""

from __future__ import annotations

import click

from dxs.cli import DxsContext, handle_errors, pass_context
from dxs.commands.report import schema
from dxs.utils.responses import list_response, single


@schema.command("items")
@pass_context
@handle_errors
def schema_items(ctx: DxsContext) -> None:
    """List all available report item types."""
    from dxs.report.schema import list_item_types

    items = list_item_types()
    ctx.output(list_response(items, "item_types"))


@schema.command("item")
@click.argument("item_type")
@pass_context
@handle_errors
def schema_item(ctx: DxsContext, item_type: str) -> None:
    """Describe a report item type and its properties.

    \b
    Available types: textbox, barcode, image, table, line, rectangle, shape
    """
    from dxs.report.schema import get_item_type_info
    from dxs.utils.errors import ValidationError

    info = get_item_type_info(item_type)
    if info is None:
        from dxs.report.schema import ITEM_TYPES

        available = ", ".join(ITEM_TYPES.keys())
        raise ValidationError(
            message=f"Unknown item type: '{item_type}'",
            code="DXS-RPT-001",
            suggestions=[f"Available types: {available}"],
        )

    ctx.output(single({"type": item_type, **info}, "item_type"))


@schema.command("barcodes")
@pass_context
@handle_errors
def schema_barcodes(ctx: DxsContext) -> None:
    """List all barcode symbologies with details."""
    from dxs.report.schema import list_barcode_symbologies

    symbologies = list_barcode_symbologies()
    ctx.output(list_response(symbologies, "barcode_symbologies"))


@schema.command("expressions")
@pass_context
@handle_errors
def schema_expressions(ctx: DxsContext) -> None:
    """Expression syntax reference for data binding."""
    from dxs.report.schema import EXPRESSION_REFERENCE

    ctx.output(single(EXPRESSION_REFERENCE, "expression_reference"))


@schema.command("document")
@pass_context
@handle_errors
def schema_document(ctx: DxsContext) -> None:
    """Full RDL-JSON document structure reference.

    Shows the top-level structure of an RDLX-JSON report file:
    page settings, sections, body, data sources, datasets,
    parameters, and a minimal example.
    """
    from dxs.report.schema import get_document_structure

    structure = get_document_structure()
    ctx.output(single(structure, "document_structure"))
