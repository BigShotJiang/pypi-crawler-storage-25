"""Report folder commands: dxs report assemble, dxs report datasource *."""

from __future__ import annotations

import json
import re
import shutil
from pathlib import Path
from typing import Any

import click

from dxs.cli import DxsContext, handle_errors, pass_context
from dxs.commands.report import datasource_group, report
from dxs.report.datasource_binding import ds_method_name, parse_datasource_param
from dxs.utils.responses import list_response, single

_REPORT_IN_PARAM_RE = re.compile(r"^\$report\.inParams\.(\w+)$")

REPORT_FILENAME = "report.rdlx-json"


def _extract_dataset_fields(out_params: list[dict[str, Any]]) -> list[dict[str, str]]:
    """Extract DataSet Fields from datasource outParams.

    Reads the ``objectTypeDef`` from the first (``result``) outParam entry and
    returns a list of ``{"Name": id, "DataField": id}`` dicts suitable for the
    RDLX-JSON ``DataSets[].Fields`` array.
    """
    if not out_params:
        return []
    result_param = out_params[0]
    type_def = result_param.get("objectTypeDef") or []
    return [
        {"Name": f["id"], "DataField": f["id"]}
        for f in type_def
        if isinstance(f, dict) and "id" in f
    ]


def _add_dataset_to_rdlx(folder: Path, alias: str, fields: list[dict[str, str]]) -> None:
    """Add a DataSet entry to the RDLX-JSON file in *folder*."""
    rdlx_path = folder / REPORT_FILENAME
    if not rdlx_path.exists():
        return
    rdl = json.loads(rdlx_path.read_text(encoding="utf-8"))
    datasets: list[dict[str, Any]] = rdl.setdefault("DataSets", [])
    # Don't add if already exists
    if any(ds.get("Name") == alias for ds in datasets):
        return
    # Resolve the DataSourceName from the report's DataSources
    data_sources = rdl.get("DataSources") or []
    data_source_name = data_sources[0]["Name"] if data_sources else "Datasource"

    datasets.append(
        {
            "Name": alias,
            "Query": {"DataSourceName": data_source_name},
            "Fields": fields,
        }
    )
    rdlx_path.write_text(json.dumps(rdl, indent=2) + "\n", encoding="utf-8")


def _remove_dataset_from_rdlx(folder: Path, alias: str) -> None:
    """Remove a DataSet entry from the RDLX-JSON file in *folder*."""
    rdlx_path = folder / REPORT_FILENAME
    if not rdlx_path.exists():
        return
    rdl = json.loads(rdlx_path.read_text(encoding="utf-8"))
    datasets: list[dict[str, Any]] = rdl.get("DataSets", [])
    updated = [ds for ds in datasets if ds.get("Name") != alias]
    if len(updated) != len(datasets):
        rdl["DataSets"] = updated
        rdlx_path.write_text(json.dumps(rdl, indent=2) + "\n", encoding="utf-8")


@report.command("assemble")
@click.argument("folder", type=click.Path(exists=True, file_okay=False))
@click.option(
    "--output",
    "-o",
    required=True,
    type=click.Path(dir_okay=False),
    help="Output wrapper JSON file path.",
)
@pass_context
@handle_errors
def assemble(ctx: DxsContext, folder: str, output: str) -> None:
    """Assemble a report folder into a wrapper JSON file.

    Reads manifest.json, the RDLX-JSON report definition, and any owned
    datasource JSON files from FOLDER, then writes a complete Datex Studio
    report wrapper JSON to OUTPUT.

    This is the inverse of ``dxs report extract``.

    \b
    Example:
        dxs report assemble ./rep_bol -o rep_bol_wrapper.json
    """
    from dxs.report.folder import assemble_folder_to_wrapper

    folder_path = Path(folder)
    try:
        wrapper = assemble_folder_to_wrapper(folder_path)
    except (FileNotFoundError, ValueError) as e:
        raise click.ClickException(str(e)) from None

    output_path = Path(output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(wrapper, indent=2) + "\n", encoding="utf-8")

    ctx.output(
        single(
            {
                "folder": str(folder_path),
                "output": str(output_path),
                "reference_name": wrapper.get("referenceName"),
                "datasources": len(wrapper.get("datasourceConfigs") or []),
                "params": len(wrapper.get("inParams") or []),
            },
            "assembly",
        )
    )


# ---------------------------------------------------------------------------
# dxs report datasource add
# ---------------------------------------------------------------------------


@datasource_group.command("add")
@click.argument("folder", type=click.Path(exists=True, file_okay=False))
@click.option(
    "--owned",
    "owned_spec",
    default=None,
    metavar="FILE:ALIAS",
    help="Add an owned (embedded) datasource from a local JSON file.",
)
@click.option(
    "--use-datasource",
    "external_spec",
    default=None,
    metavar="REF:ALIAS",
    help="Add an external (standalone) datasource by reference name.",
)
@click.option(
    "--param",
    "params_raw",
    multiple=True,
    metavar="NAME:TYPE",
    help="Report input parameter (repeatable).",
)
@click.option(
    "--datasource-param",
    "ds_params_raw",
    multiple=True,
    metavar="KEY=EXPRESSION",
    help="Datasource parameter binding (repeatable).",
)
@click.option(
    "--branch",
    "-b",
    type=int,
    default=None,
    help="Branch ID — required for --use-datasource to fetch contract metadata.",
)
@pass_context
@handle_errors
def datasource_add(
    ctx: DxsContext,
    folder: str,
    owned_spec: str | None,
    external_spec: str | None,
    params_raw: tuple[str, ...],
    ds_params_raw: tuple[str, ...],
    branch: int | None,
) -> None:
    """Add a datasource to a report folder.

    Exactly one of --owned or --use-datasource must be provided.

    \b
    Examples:
        dxs report datasource add ./rep_bol --owned ds_bol.json:shipment --param id:number
        dxs report datasource add ./rep_bol --use-datasource ds_ext:ext_alias
    """
    from dxs.report.manifest import (
        ManifestDatasource,
        ManifestDatasourceParam,
        ManifestParam,
        load_manifest,
        save_manifest,
    )

    if owned_spec and external_spec:
        raise click.UsageError("Specify exactly one of --owned or --use-datasource, not both.")
    if not owned_spec and not external_spec:
        raise click.UsageError("One of --owned or --use-datasource is required.")

    folder_path = Path(folder)
    manifest = load_manifest(folder_path)

    # Determine alias and type
    if owned_spec:
        # Parse FILE:ALIAS — split on last colon so Windows absolute paths work
        if ":" not in owned_spec:
            raise click.UsageError(f"--owned must be in FILE:ALIAS format, got: '{owned_spec}'")
        # Split from the right once to get alias; everything else is the file path
        colon_idx = owned_spec.rfind(":")
        src_file_str = owned_spec[:colon_idx]
        alias = owned_spec[colon_idx + 1 :]
        if not src_file_str or not alias:
            raise click.UsageError(f"--owned must be in FILE:ALIAS format, got: '{owned_spec}'")

        src_path = Path(src_file_str)
        if not src_path.exists():
            raise click.ClickException(f"Source datasource file not found: {src_file_str}")

        # Validate DS file content
        try:
            ds_data = json.loads(src_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as e:
            raise click.ClickException(f"Invalid JSON in {src_file_str}: {e}") from None

        ds_ref_name = ds_data.get("referenceName")
        if not ds_ref_name:
            raise click.ClickException(
                f"File {src_file_str} is missing 'referenceName'. "
                "Use 'dxs datasource generate' to create a valid config."
            )

        ds_file_type = ds_data.get("type")
        from dxs.report.datasource_binding import VALID_DS_TYPES

        if ds_file_type not in VALID_DS_TYPES:
            raise click.ClickException(
                f"File {src_file_str} has unexpected type '{ds_file_type}'. "
                f"Expected one of: {', '.join(sorted(VALID_DS_TYPES))}."
            )

        if ds_ref_name != alias:
            raise click.ClickException(
                f"Datasource referenceName '{ds_ref_name}' does not match alias '{alias}'. "
                f"Use --owned {src_file_str}:{ds_ref_name} instead."
            )

        ds_type = "owned"
        dest_filename = f"{alias}.json"
    else:
        # external: REF:ALIAS — split on first colon
        assert external_spec is not None
        if ":" not in external_spec:
            raise click.UsageError(
                f"--use-datasource must be in REF:ALIAS format, got: '{external_spec}'"
            )
        ref, alias = external_spec.split(":", 1)
        if not ref or not alias:
            raise click.UsageError(
                f"--use-datasource must be in REF:ALIAS format, got: '{external_spec}'"
            )

        ds_type = "external"

        # Resolve branch ID for external DS metadata fetch
        ext_branch_id = branch or ctx.branch

    # Validate alias is a valid JS identifier
    from dxs.core.designer.parsers import is_valid_js_identifier

    if not is_valid_js_identifier(alias):
        raise click.ClickException(
            f"Alias '{alias}' is not a valid JavaScript identifier. "
            "Use letters, digits, underscores, or $ (no hyphens, dots, or spaces)."
        )

    # Check alias doesn't already exist
    existing_aliases = {ds.alias for ds in manifest.datasources}
    if alias in existing_aliases:
        raise click.ClickException(
            f"Datasource alias '{alias}' already exists in this folder. "
            "Use a different alias or remove the existing entry first."
        )

    # For owned: copy file into folder
    ext_ds_meta: dict[str, Any] = {}
    if ds_type == "owned":
        dest_path = folder_path / dest_filename
        shutil.copy2(str(src_path), str(dest_path))
        manifest.datasources.append(
            ManifestDatasource(file=dest_filename, alias=alias, type="owned")
        )
    else:
        # For external: fetch contract metadata from the branch if available
        if ext_branch_id:
            try:
                from dxs.core.api.client import ApiClient
                from dxs.utils.resolvers import resolve_config_by_reference

                api_client = ApiClient()
                raw = resolve_config_by_reference(api_client, ext_branch_id, "datasource", ref)
                ds_json = raw.get("json", raw)
                ext_ds_meta = {
                    "configOutParameters": ds_json.get("outParams"),
                    "datasourceKeyDef": ds_json.get("keyDef"),
                    "dynamicOrderBys": ds_json.get("dynamicOrderBys"),
                    "dynamicFilters": ds_json.get("dynamicFilters"),
                    "datasourceMethodName": ds_method_name(ds_json),
                    "_inParams": ds_json.get("inParams"),  # used for param type resolution below
                }
            except Exception as exc:
                click.echo(
                    f"Warning: Could not fetch metadata for '{ref}' from branch {ext_branch_id}: {exc}",
                    err=True,
                )

        manifest.datasources.append(
            ManifestDatasource(
                ref=ref,
                alias=alias,
                type="external",
                configOutParameters=ext_ds_meta.get("configOutParameters"),
                datasourceKeyDef=ext_ds_meta.get("datasourceKeyDef"),
                dynamicOrderBys=ext_ds_meta.get("dynamicOrderBys"),
                dynamicFilters=ext_ds_meta.get("dynamicFilters"),
                datasourceMethodName=ext_ds_meta.get("datasourceMethodName"),
            )
        )

    # Parse --param flags: NAME:TYPE
    existing_param_names = {p.name for p in manifest.params}
    for param_raw in params_raw:
        if ":" not in param_raw:
            raise click.UsageError(f"--param must be in NAME:TYPE format, got: '{param_raw}'")
        pname, ptype = param_raw.split(":", 1)
        pname, ptype = pname.strip(), ptype.strip()
        if pname not in existing_param_names:
            manifest.params.append(ManifestParam(name=pname, type=ptype))
            existing_param_names.add(pname)

    # Build a lookup of report param types for expression-based type inference
    report_param_types: dict[str, str] = {p.name: p.type for p in manifest.params}

    # Build lookups of external DS inParam types and required flags
    ext_in_param_types: dict[str, str] = {}
    ext_in_param_required: dict[str, bool | None] = {}
    if ds_type == "external" and ext_ds_meta.get("_inParams"):
        for p in ext_ds_meta["_inParams"]:
            if isinstance(p, dict) and "id" in p:
                ext_in_param_types[p["id"]] = p.get("type", "string")
                ext_in_param_required[p["id"]] = p.get("required")

    # Parse --datasource-param flags: [Alias.]KEY=EXPRESSION
    for ds_param_raw in ds_params_raw:
        alias_prefix, key, expression = parse_datasource_param(ds_param_raw)
        key, expression = key.strip(), expression.strip()

        # Dot-notation overrides the alias; otherwise scope to current datasource
        effective_alias = alias_prefix or alias

        # Resolve param type: prefer DS inParam type, then infer from expression
        param_type: str | None = ext_in_param_types.get(key)
        if param_type is None:
            m = _REPORT_IN_PARAM_RE.match(expression)
            if m:
                param_type = report_param_types.get(m.group(1))

        # Resolve required flag from DS inParams
        param_required: bool | None = ext_in_param_required.get(key)

        manifest.datasourceParams.append(
            ManifestDatasourceParam(
                key=key,
                expression=expression,
                alias=effective_alias,
                type=param_type,
                required=param_required,
            )
        )

    # Add DataSet entry to the RDLX-JSON
    if ds_type == "owned":
        ds_out_params = ds_data.get("outParams") or []
    else:
        ds_out_params = ext_ds_meta.get("configOutParameters") or []
    dataset_fields = _extract_dataset_fields(ds_out_params)
    _add_dataset_to_rdlx(folder_path, alias, dataset_fields)

    save_manifest(manifest, folder_path)

    ctx.output(
        single(
            {
                "folder": str(folder_path),
                "action": "added",
                "alias": alias,
                "type": ds_type,
            },
            "datasource",
        )
    )


# ---------------------------------------------------------------------------
# dxs report datasource remove
# ---------------------------------------------------------------------------


@datasource_group.command("remove")
@click.argument("folder", type=click.Path(exists=True, file_okay=False))
@click.argument("alias")
@pass_context
@handle_errors
def datasource_remove(ctx: DxsContext, folder: str, alias: str) -> None:
    """Remove a datasource from a report folder by alias.

    \b
    Example:
        dxs report datasource remove ./rep_bol shipment
    """
    from dxs.report.manifest import load_manifest, save_manifest

    folder_path = Path(folder)
    manifest = load_manifest(folder_path)

    # Find the entry
    entry = next((ds for ds in manifest.datasources if ds.alias == alias), None)
    if entry is None:
        raise click.ClickException(
            f"Datasource alias '{alias}' not found in this folder. "
            "Use 'dxs report datasource list' to see available datasources."
        )

    # For owned: delete the file from folder
    if entry.type == "owned" and entry.file:
        file_path = folder_path / entry.file
        if file_path.exists():
            file_path.unlink()

    # Remove DataSet from RDLX-JSON
    _remove_dataset_from_rdlx(folder_path, alias)

    # Remove from manifest
    manifest.datasources = [ds for ds in manifest.datasources if ds.alias != alias]

    # Remove scoped datasourceParams (where dp.alias == alias)
    manifest.datasourceParams = [dp for dp in manifest.datasourceParams if dp.alias != alias]

    save_manifest(manifest, folder_path)

    ctx.output(
        single(
            {
                "folder": str(folder_path),
                "action": "removed",
                "alias": alias,
            },
            "datasource",
        )
    )


# ---------------------------------------------------------------------------
# dxs report datasource list
# ---------------------------------------------------------------------------


@datasource_group.command("list")
@click.argument("folder", type=click.Path(exists=True, file_okay=False))
@pass_context
@handle_errors
def datasource_list(ctx: DxsContext, folder: str) -> None:
    """List all datasources in a report folder.

    \b
    Example:
        dxs report datasource list ./rep_bol
    """
    from dxs.report.manifest import load_manifest

    folder_path = Path(folder)
    manifest = load_manifest(folder_path)

    # Separate global (alias=None) and scoped params
    global_params = [
        {"key": dp.key, "expression": dp.expression}
        for dp in manifest.datasourceParams
        if dp.alias is None
    ]

    items = []
    for ds in manifest.datasources:
        # Gather ds params scoped to this alias + global ones
        scoped_params = [
            {"key": dp.key, "expression": dp.expression}
            for dp in manifest.datasourceParams
            if dp.alias == ds.alias
        ]
        combined_params = global_params + scoped_params
        entry: dict = {
            "alias": ds.alias,
            "type": ds.type,
        }
        if ds.file:
            entry["file"] = ds.file
        if ds.ref:
            entry["ref"] = ds.ref
        if combined_params:
            entry["datasource_params"] = combined_params
        items.append(entry)

    ctx.output(list_response(items, "datasources"))
