"""Report API commands: upload, download, datasource-fields, get, list."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import click

from dxs.cli import DxsContext, handle_errors, pass_context
from dxs.commands.report import (
    report,
)
from dxs.core.auth import require_auth
from dxs.utils.click_options import pagination_options
from dxs.utils.responses import list_response, single


@report.command("upload")
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
@click.option("--branch", "-b", type=int, default=None, help="Branch ID (falls back to global -b)")
@pass_context
@require_auth
@handle_errors
def upload(ctx: DxsContext, file: str, branch: int | None) -> None:
    """Upload a report wrapper JSON to Datex Studio.

    The FILE must be a wrapper JSON produced by 'dxs report assemble'.
    All report metadata, datasource bindings, and parameters are read
    from the wrapper.

    \b
    Examples:
        dxs report assemble srs_bol/ -o srs_bol.json
        dxs report upload srs_bol.json --branch 64
    """
    import json

    from dxs.core.api.client import ApiClient

    branch_id = branch or ctx.branch
    if not branch_id:
        raise click.UsageError("A branch is required. Use --branch or the global -b/--branch flag.")

    # Read wrapper JSON
    path = Path(file)
    try:
        wrapper = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        raise click.ClickException(f"Invalid JSON in {file}: {e}") from None

    # Validate it's a wrapper, not bare RDLX-JSON
    if not isinstance(wrapper.get("report"), dict) or "definition" not in wrapper.get("report", {}):
        raise click.ClickException(
            f"File is not a valid report wrapper. "
            f"Use 'dxs report assemble <folder> -o {file}' to create one."
        )

    ref_name = wrapper.get("referenceName")
    report_name = wrapper.get("title", ref_name)
    if not ref_name:
        raise click.ClickException("Wrapper is missing 'referenceName'.")

    # Upsert via API
    client = ApiClient()
    # Upload via API -- upsert with lock management
    ref_name = wrapper.get("referenceName")

    from dxs.utils.resolvers import upsert_config

    response, action = upsert_config(client, branch_id, "report", ref_name, wrapper)

    config_id_result = None
    if isinstance(response, dict):
        config_id_result = response.get("id", config_id_result)

    ctx.output(
        single(
            {
                "file": file,
                "branch_id": branch_id,
                "name": report_name,
                "reference_name": ref_name,
                "config_id": config_id_result,
                "action": action,
            },
            "report",
        )
    )


@report.command("download")
@click.argument("folder", type=click.Path(), required=False, default=None)
@click.option("--branch", "-b", type=int, default=None, help="Branch ID (falls back to global -b)")
@click.option("--report-id", type=int, default=None, help="Report configuration ID")
@click.option("--reference-name", default=None, help="Report reference name")
@click.option("--force", is_flag=True, default=False, help="Overwrite existing folder")
@pass_context
@require_auth
@handle_errors
def download(
    ctx: DxsContext,
    folder: str | None,
    branch: int | None,
    report_id: int | None,
    reference_name: str | None,
    force: bool,
) -> None:
    """Download a report from Datex Studio into a report folder.

    Fetches the report configuration from the API and extracts it into a
    folder containing the RDLX-JSON report definition, owned datasource
    configs, and a manifest.json. Either --report-id or --reference-name
    is required to identify the report.

    If FOLDER is omitted, the folder is named after the report's
    referenceName in the current working directory.

    \b
    Examples:
        dxs report download --branch 123 --report-id 456
        dxs report download my_report --branch 123 --reference-name receiving_report
        dxs report download --branch 123 --reference-name receiving_report --force
    """
    import shutil

    from dxs.core.api.client import ApiClient
    from dxs.core.api.endpoints import ConfigurationEndpoints
    from dxs.report.folder import extract_wrapper_to_folder
    from dxs.utils.errors import ValidationError

    branch_id = branch or ctx.branch
    if not branch_id:
        raise click.UsageError("A branch is required. Use --branch or the global -b/--branch flag.")

    if report_id is None and reference_name is None:
        raise ValidationError(
            message="Either --report-id or --reference-name is required",
            code="DXS-RPT-030",
            suggestions=["Provide --report-id <id> or --reference-name <name>"],
        )

    client = ApiClient()

    if report_id is not None:
        endpoint = ConfigurationEndpoints.get_content(branch_id, "report", report_id)
    else:
        assert reference_name is not None  # guaranteed by the check above
        endpoint = ConfigurationEndpoints.get_by_reference(branch_id, "report", reference_name)

    response = client.get(endpoint)

    if not isinstance(response, dict):
        raise ValidationError(
            message="Unexpected API response format",
            code="DXS-RPT-031",
        )

    # The get_content endpoint wraps the report wrapper inside a 'json' field;
    # the get_by_reference endpoint returns the wrapper directly.
    wrapper = response.get("json", response) if isinstance(response.get("json"), dict) else response

    # Determine folder path � default to referenceName in cwd
    ref = wrapper.get("referenceName", reference_name or f"report_{report_id}")
    folder_path = Path(folder) if folder else Path(ref)

    if folder_path.exists() and not force:
        raise ValidationError(
            message=f"Folder already exists: {folder_path}",
            code="DXS-RPT-012",
            suggestions=["Use --force to overwrite or choose a different folder name"],
        )
    if folder_path.exists() and force:
        if (
            not (folder_path / "manifest.json").exists()
            and not (folder_path / "report.rdlx-json").exists()
        ):
            raise ValidationError(
                message=f"Refusing to overwrite: {folder_path} does not look like a report folder",
                code="DXS-RPT-013",
                suggestions=[
                    "Remove the folder manually if you're sure, or choose a different path",
                ],
            )
        shutil.rmtree(folder_path)

    extract_wrapper_to_folder(wrapper, folder_path)

    ctx.output(
        single(
            {
                "folder": str(folder_path),
                "branch_id": branch_id,
                "name": wrapper.get("title"),
                "reference_name": ref,
            },
            "report",
        )
    )


# -- Datasource Fields / Get / List Commands --------------------------------


def _suggested_alias(reference_name: str) -> str:
    """Derive a suggested alias from datasource referenceName.

    'ds_shipment_bol' -> 'shipment_bol'
    'ds_orders' -> 'orders'
    'my_ds' -> 'my_ds' (no ds_ prefix to strip)
    """
    if reference_name.startswith("ds_"):
        return reference_name[3:]
    return reference_name


def _extract_owned_datasource(
    report_json: dict[str, Any], datasource_ref: str
) -> dict[str, Any] | None:
    """Find an owned datasource config within a report wrapper."""
    for entry in report_json.get("datasourceConfigs", []):
        ds_config: dict[str, Any] = entry.get("datasourceConfig", {})
        if ds_config.get("configId") == datasource_ref:
            return ds_config
    return None


@report.command("datasource-fields")
@click.argument("datasource_ref")
@click.option(
    "--branch",
    "-b",
    type=int,
    default=None,
    help="Branch ID (falls back to global -b)",
)
@click.option(
    "--report",
    "-r",
    "report_ref",
    default=None,
    help="Report reference name (for owned/embedded datasources)",
)
@pass_context
@require_auth
@handle_errors
def datasource_fields(
    ctx: DxsContext, datasource_ref: str, branch: int | None, report_ref: str | None
) -> None:
    """Show fields available from a datasource for use in report expressions.

    Fetches the uploaded datasource from the branch and displays its
    fields as a structured list. Use this to discover what
    =Fields!Name.Value expressions are available for RDLX-JSON binding.

    For owned (embedded) datasources, use --report to specify the report
    that contains the datasource config.

    \b
    Examples:
        # Standalone datasource
        dxs report datasource-fields ds_shipment_bol --branch 61

        # Owned datasource (embedded in a report)
        dxs report datasource-fields ds_bol --branch 61 --report bill_of_lading
    """
    from dxs.core.api.client import ApiClient
    from dxs.report.field_parser import ParsedCollection, ParsedField, parse_fields
    from dxs.utils.errors import ApiError, ValidationError

    branch_id = branch or ctx.branch
    if not branch_id:
        raise click.UsageError("A branch is required. Use --branch or the global -b/--branch flag.")

    from dxs.utils.resolvers import resolve_config_by_reference

    api_client = ApiClient()

    if report_ref:
        # Owned datasource: fetch report and extract DS config from it
        report_data = resolve_config_by_reference(api_client, branch_id, "report", report_ref)
        report_json: dict = report_data.get("json") or {}
        ds_config = _extract_owned_datasource(report_json, datasource_ref)
        if ds_config is None:
            raise ValidationError(
                message=(f"Datasource '{datasource_ref}' not found in report '{report_ref}'"),
                code="DXS-RPT-040",
                suggestions=[
                    "Check the datasource configId in the report's datasourceConfigs",
                    f"Use 'dxs report get {report_ref} --branch {branch_id}' to inspect the report",
                ],
            )
        config_out_parameters = ds_config.get("configOutParameters", [])
        # Extract in_params from configParameters
        config_parameters = ds_config.get("configParameters", [])
        in_params_out = [
            {
                "id": cp["parameter"]["id"],
                "type": cp["parameter"].get("type", "string"),
            }
            for cp in config_parameters
            if "parameter" in cp
        ]
    else:
        # Standalone datasource
        try:
            ds = resolve_config_by_reference(api_client, branch_id, "datasource", datasource_ref)
        except ApiError as exc:
            if exc.status_code == 404:
                raise ApiError(
                    message=exc.message,
                    code=exc.code,
                    status_code=exc.status_code,
                    details=exc.details,
                    suggestions=[
                        *(exc.suggestions or []),
                        "If this is an owned datasource, use --report <report_ref> to inspect it",
                    ],
                ) from exc
            raise

        ds_json: dict = ds.get("json") or {}
        config_out_parameters = ds_json.get("outParams") or []
        ds_in_params: list[dict] = ds_json.get("inParams") or []
        in_params_out = [
            {"id": p["id"], "type": p.get("type", "string")} for p in ds_in_params if "id" in p
        ]

    is_collection, flat_fields, collections = parse_fields(config_out_parameters)

    def _field_entry(f: ParsedField) -> dict:
        return {"path": f.path, "type": f.type}

    def _collection_entry(c: ParsedCollection) -> dict:
        return {
            "path": c.path,
            "fields": [_field_entry(f) for f in c.fields],
        }

    output = {
        "datasource": datasource_ref,
        "result_type": "collection" if is_collection else "single",
        "suggested_alias": _suggested_alias(datasource_ref),
        "in_params": in_params_out,
        "fields": [_field_entry(f) for f in flat_fields],
        "collections": [_collection_entry(c) for c in collections],
    }

    ctx.output(single(output, "datasource_fields"))


@report.command("get")
@click.argument("reference_name")
@click.option(
    "--branch",
    "-b",
    type=int,
    default=None,
    help="Branch ID (falls back to global -b)",
)
@pass_context
@require_auth
@handle_errors
def get_report(ctx: DxsContext, reference_name: str, branch: int | None) -> None:
    """Get a report configuration by reference name.

    Returns the full report envelope including datasource bindings,
    input parameters, and the RDLX-JSON definition. Use this to
    verify that an uploaded report has correct datasource bindings.

    \b
    Example:
        dxs report get rep_shipment_bol --branch 61
    """
    from dxs.core.api.client import ApiClient
    from dxs.core.api.endpoints import ConfigurationEndpoints

    branch_id = branch or ctx.branch
    if not branch_id:
        raise click.UsageError("A branch is required. Use --branch or the global -b/--branch flag.")

    api_client = ApiClient()
    result = api_client.get(
        ConfigurationEndpoints.get_by_reference(branch_id, "report", reference_name)
    )
    ctx.output(single(result, "report_config"))


@report.command("list")
@click.option(
    "--branch",
    "-b",
    type=int,
    default=None,
    help="Branch ID (falls back to global -b)",
)
@pagination_options(default_limit=0)
@pass_context
@require_auth
@handle_errors
def list_reports(ctx: DxsContext, branch: int | None, limit: int) -> None:
    """List all report configurations in a branch.

    \b
    Example:
        dxs report list --branch 61
    """
    from dxs.core.api.client import ApiClient
    from dxs.core.api.endpoints import ConfigurationEndpoints

    branch_id = branch or ctx.branch
    if not branch_id:
        raise click.UsageError("A branch is required. Use --branch or the global -b/--branch flag.")

    api_client = ApiClient()
    result = api_client.get(ConfigurationEndpoints.list_all(branch_id, "report"))
    items = result if isinstance(result, list) else result.get("value", [])
    if limit > 0:
        items = items[:limit]
    ctx.output(list_response(items, "report_configs"))
