"""Report validate, outline, preview, and preview-arjs commands."""

from __future__ import annotations

from pathlib import Path

import click

from dxs.cli import DxsContext, handle_errors, pass_context
from dxs.commands.report import (
    _parse_report,
    _read_report,
    report,
)
from dxs.utils.responses import single


@report.command("validate")
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
@pass_context
@handle_errors
def validate(ctx: DxsContext, file: str) -> None:
    """Validate report structure, layout, and expressions.

    Checks for: duplicate element names, missing required properties
    (e.g., barcode Symbology, image Source), elements positioned outside
    the page content area, invalid barcode symbologies, and malformed
    expressions. Returns errors (must fix) and warnings (may fix).

    \b
    Examples:
        dxs report validate bol.rdlx-json
    """
    from dxs.report.validator import validate_report

    data = _read_report(file)
    report_def = _parse_report(data)
    result = validate_report(report_def)

    ctx.output(
        single(
            {
                "file": file,
                "valid": result["valid"],
                "errors": result["errors"],
                "warnings": result["warnings"],
            },
            "validation",
        )
    )


@report.command("outline")
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
@pass_context
@handle_errors
def outline(ctx: DxsContext, file: str) -> None:
    """Show the hierarchical structure of all report elements.

    Displays every element in the report as an indented tree,
    including items nested inside rectangles and table cells.

    \b
    Examples:
        dxs report outline report.rdlx-json
    """
    from dxs.report.engine import build_outline

    data = _read_report(file)
    report_def = _parse_report(data)

    result = build_outline(report_def)
    ctx.output(single(result, "report_outline"))


@report.command("preview")
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
@click.option(
    "--data",
    type=click.Path(exists=True, dir_okay=False),
    help="Sample data JSON file for data binding",
)
@click.option(
    "--output",
    "-o",
    "output_path",
    type=click.Path(),
    help="Output path -- .svg (default), .png, or .pdf",
)
@click.option(
    "--per-page",
    is_flag=True,
    default=False,
    help="Separate PNG per page instead of single stitched image",
)
@click.option(
    "--width", type=int, default=None, help="Image width in pixels (default: match page at 96 DPI)"
)
@click.option("--timeout", type=int, default=30, help="Render timeout in seconds")
@click.option(
    "--bbox",
    multiple=True,
    help="Bounding box around element: NAME[:COLOR] (default color: #22c55e)",
)
@pass_context
@handle_errors
def preview(
    ctx: DxsContext,
    file: str,
    data: str | None,
    output_path: str | None,
    per_page: bool,
    width: int | None,
    timeout: int,
    bbox: tuple[str, ...],
) -> None:
    """Render report to PNG, SVG, or PDF via server-side SVG generation.

    Generates an SVG from the report definition and converts to the
    requested output format. No headless browser required.

    If --data is not provided, automatically loads a companion
    .data.json file if one exists alongside the report file.

    \b
    Examples:
        dxs report preview label.rdlx-json
        dxs report preview label.rdlx-json --data sample.json -o preview.png
        dxs report preview bol.rdlx-json -o report.svg
        dxs report preview bol.rdlx-json -o report.pdf --width 1200
    """
    from dxs.report.preview import render_preview

    # Read report definition
    report_data = _read_report(file)

    # Read sample data: explicit --data flag, or auto-discover .data.json
    sample_data = None
    if data:
        sample_data = _read_report(data)
    else:
        data_path = Path(file).with_suffix(".data.json")
        if data_path.exists():
            sample_data = _read_report(str(data_path))

    # Parse bounding box specifications
    bounding_boxes: list[dict[str, str]] | None = None
    if bbox:
        bounding_boxes = []
        for spec in bbox:
            if ":" in spec:
                name, color = spec.split(":", 1)
            else:
                name, color = spec, "#22c55e"
            bounding_boxes.append({"name": name, "color": color})

    # Determine output path (default to SVG -- native format, no extra deps)
    if output_path is None:
        stem = Path(file).stem
        output_path = f"{stem}-preview.svg"

    result = render_preview(
        report_data=report_data,
        output_path=output_path,
        sample_data=sample_data,
        target_width=width,
        per_page=per_page,
        timeout=timeout,
        bounding_boxes=bounding_boxes,
    )

    ctx.output(single(result, "preview"))


@report.command("preview-arjs")
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
@click.option(
    "--data",
    type=click.Path(exists=True, dir_okay=False),
    help="Sample data JSON file for data binding",
)
@click.option(
    "--output",
    "-o",
    "output_path",
    type=click.Path(),
    help="Output PNG path (default: <stem>-preview-arjs.png)",
)
@click.option(
    "--per-page",
    is_flag=True,
    default=False,
    help="Separate PNG per page instead of single stitched image",
)
@click.option(
    "--width", type=int, default=None, help="Image width in pixels (default: match page at 96 DPI)"
)
@click.option("--timeout", type=int, default=30, help="Render timeout in seconds")
@pass_context
@handle_errors
def preview_arjs(
    ctx: DxsContext,
    file: str,
    data: str | None,
    output_path: str | None,
    per_page: bool,
    width: int | None,
    timeout: int,
) -> None:
    """Render report to PNG via ActiveReportsJS headless browser.

    Uses agent-browser to load an ARJS viewer page, wait for render
    completion, and screenshot the output as a PNG image.

    Requires:
      - agent-browser: npm install -g @anthropic-ai/agent-browser && agent-browser install
      - @mescius/activereportsjs: npm install (in src/dxs/web/frontend/)

    If --data is not provided, automatically loads a companion
    .data.json file if one exists alongside the report file.

    \b
    Examples:
        dxs report preview-arjs label.rdlx-json
        dxs report preview-arjs label.rdlx-json --data sample.json -o preview.png
        dxs report preview-arjs bol.rdlx-json --width 1200
    """
    from dxs.report.preview_arjs import render_preview_arjs

    # Read report definition
    report_data = _read_report(file)

    # Read sample data: explicit --data flag, or auto-discover .data.json
    sample_data = None
    if data:
        sample_data = _read_report(data)
    else:
        data_path = Path(file).with_suffix(".data.json")
        if data_path.exists():
            sample_data = _read_report(str(data_path))

    # Determine output path (default to PNG -- ARJS renders via browser screenshot)
    if output_path is None:
        stem = Path(file).stem
        output_path = f"{stem}-preview-arjs.png"

    result = render_preview_arjs(
        report_data=report_data,
        output_path=output_path,
        sample_data=sample_data,
        target_width=width,
        per_page=per_page,
        timeout=timeout,
    )

    ctx.output(single(result, "preview_arjs"))


@report.command("validate-arjs")
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
@click.option(
    "--data",
    "-d",
    type=click.Path(exists=True, dir_okay=False),
    help="Sample data JSON file for data binding",
)
@click.option("--timeout", type=int, default=30, help="Render timeout in seconds")
@pass_context
@handle_errors
def validate_arjs(
    ctx: DxsContext,
    file: str,
    data: str | None,
    timeout: int,
) -> None:
    """Validate report via ActiveReportsJS rendering engine.

    Loads the report through ActiveReportsJS and captures runtime
    errors and warnings from the ARJS error handler and browser
    console. Catches expression errors, datasource binding failures,
    font issues, and layout problems that static validation misses.

    Requires:
      - agent-browser: npm install -g @anthropic-ai/agent-browser && agent-browser install
      - @mescius/activereportsjs: npm install (in src/dxs/web/frontend/)

    If --data is not provided, automatically loads a companion
    .data.json file if one exists alongside the report file.

    \b
    Examples:
        dxs report validate-arjs bol.rdlx-json
        dxs report validate-arjs bol.rdlx-json --data sample.json
        dxs report validate-arjs bol.rdlx-json --timeout 60
    """
    from dxs.report.validate_arjs import validate_report_arjs

    # Read report definition
    report_data = _read_report(file)

    # Read sample data: explicit --data flag, or auto-discover .data.json
    sample_data = None
    if data:
        sample_data = _read_report(data)
    else:
        data_path = Path(file).with_suffix(".data.json")
        if data_path.exists():
            sample_data = _read_report(str(data_path))

    result = validate_report_arjs(
        report_data=report_data,
        sample_data=sample_data,
        timeout=timeout,
    )

    ctx.output(
        single(
            {
                "file": file,
                **result,
            },
            "validation_arjs",
        )
    )
