"""Report create, scaffold, and inspect commands."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import click

from dxs.cli import DxsContext, handle_errors, pass_context
from dxs.commands.report import (
    _parse_report,
    _read_report,
    _serialize_report,
    _write_report,
    report,
)
from dxs.report.folder import REPORT_FILENAME
from dxs.utils.responses import single


def _validate_folder_name(ref_name: str) -> None:
    """Raise ValidationError if folder name is not a valid JS identifier."""
    from dxs.core.designer.parsers import is_valid_js_identifier
    from dxs.utils.errors import ValidationError

    if not is_valid_js_identifier(ref_name):
        raise ValidationError(
            message=(
                f"Folder name '{ref_name}' is not a valid JavaScript identifier. "
                "The folder name becomes the report's referenceName, which the platform "
                "uses to generate TypeScript service classes. "
                "Use letters, digits, underscores, or $ (no hyphens, dots, or spaces)."
            ),
            code="DXS-RPT-013",
            suggestions=[
                "Examples: srs_bol_report, outbound_bol_report, shipping_label_report",
            ],
        )


def _collect_tablix_cell_names(extra: dict[str, Any]) -> list[str]:
    """Extract cell item names from a tablix's model_extra."""
    from dxs.report.models import ReportItem

    def _get_name(cell_item: Any) -> str | None:
        if isinstance(cell_item, dict):
            return cell_item.get("Name")
        if isinstance(cell_item, ReportItem):
            return cell_item.Name
        return None

    names: list[str] = []
    body = extra.get("Body")
    if not body or not isinstance(body, dict):
        return names
    # Body.Rows[].Cells[].Item
    for row in body.get("Rows", []):
        if isinstance(row, dict):
            for cell in row.get("Cells", []):
                if isinstance(cell, dict):
                    name = _get_name(cell.get("Item"))
                    if name:
                        names.append(name)
    return names


@report.command("create")
@click.argument("folder", type=click.Path())
@click.option(
    "--page",
    "page_size",
    default="letter",
    help="Page size: letter, legal, a4, 4x6, 4x8, or WxH (e.g., 8.5inx11in)",
)
@click.option(
    "--margins",
    default="0.5in",
    help="Page margins: uniform (0.5in) or CSS-style (top right bottom left)",
)
@click.option(
    "--name", "report_name", default=None, help="Report display name (defaults to folder name)"
)
@click.option("--landscape", is_flag=True, default=False, help="Use landscape orientation")
@pass_context
@handle_errors
def create(
    ctx: DxsContext,
    folder: str,
    page_size: str,
    margins: str,
    report_name: str | None,
    landscape: bool,
) -> None:
    """Create a blank report folder with page setup.

    Creates a folder containing an empty report.rdlx-json and a manifest.json.
    Use 'dxs report add' to add elements afterward.
    For pre-built layouts, use 'dxs report scaffold' instead.

    \b
    Page sizes: letter (8.5x11), legal (8.5x14), a4, 4x6, 4x8,
    or custom WxH (e.g., 8.5inx11in).

    \b
    Examples:
        dxs report create srs_bol
        dxs report create label_report --page 4x6 --margins 0.25in
        dxs report create my_report --page letter --landscape
    """
    from dxs.report.engine import create_blank_report
    from dxs.report.manifest import Manifest, save_manifest
    from dxs.utils.errors import ValidationError

    folder_path = Path(folder)
    if folder_path.exists():
        raise ValidationError(
            message=f"Folder already exists: {folder}",
            code="DXS-RPT-012",
            suggestions=["Choose a different folder name or delete the existing folder"],
        )

    ref_name = folder_path.name
    _validate_folder_name(ref_name)
    display_name = report_name or ref_name

    report_def = create_blank_report(
        name=display_name,
        page_size=page_size,
        margins=margins,
        landscape=landscape,
    )

    folder_path.mkdir(parents=True)
    _write_report(str(folder_path / REPORT_FILENAME), _serialize_report(report_def))

    manifest = Manifest(name=display_name, referenceName=ref_name, report=REPORT_FILENAME)
    save_manifest(manifest, folder_path)

    ctx.output(
        single(
            {
                "folder": str(folder_path),
                "reference_name": ref_name,
                "page_size": page_size,
                "margins": margins,
                "name": display_name,
            },
            "report",
        )
    )


@report.command("scaffold")
@click.argument("folder", type=click.Path())
@click.option(
    "--template",
    "-t",
    "template_name",
    required=True,
    type=click.Choice(["bill-of-lading", "shipping-label"], case_sensitive=False),
    help="Template to use",
)
@click.option("--page", "page_size", default=None, help="Override page size (e.g., 4x6)")
@pass_context
@handle_errors
def scaffold(
    ctx: DxsContext,
    folder: str,
    template_name: str,
    page_size: str | None,
) -> None:
    """Create a report folder from a built-in template.

    \b
    Templates:
        bill-of-lading    Standard BOL layout (8.5x11, landscape)
        shipping-label    4x6 shipping label

    \b
    Examples:
        dxs report scaffold bol_report --template bill-of-lading
        dxs report scaffold label_report --template shipping-label
    """
    from dxs.report.engine import scaffold_report
    from dxs.report.manifest import Manifest, save_manifest
    from dxs.utils.errors import ValidationError

    folder_path = Path(folder)
    if folder_path.exists():
        raise ValidationError(
            message=f"Folder already exists: {folder}",
            code="DXS-RPT-012",
            suggestions=["Choose a different folder name or delete the existing folder"],
        )

    ref_name = folder_path.name
    _validate_folder_name(ref_name)

    report_def = scaffold_report(template_name, page_size_override=page_size)

    folder_path.mkdir(parents=True)
    _write_report(str(folder_path / REPORT_FILENAME), _serialize_report(report_def))
    manifest = Manifest(name=ref_name, referenceName=ref_name, report=REPORT_FILENAME)
    save_manifest(manifest, folder_path)

    item_count = len(report_def.all_items())
    ctx.output(
        single(
            {
                "folder": str(folder_path),
                "reference_name": ref_name,
                "template": template_name,
                "items_count": item_count,
            },
            "report",
        )
    )


@report.command("inspect")
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
@pass_context
@handle_errors
def inspect(ctx: DxsContext, file: str) -> None:
    """Show spatial overview of all elements in a report.

    Lists every element with its type, name, position (left, top),
    size (width, height), value, and page settings. Use this to
    understand the current layout before making changes.

    \b
    Examples:
        dxs report inspect bol.rdlx-json
    """
    data = _read_report(file)
    report_def = _parse_report(data)

    page = report_def.Page

    # First pass: collect tablix cell names so we can nest them under their parent
    tablix_cell_names: set[str] = set()
    tablix_cells_by_parent: dict[str, list[str]] = {}
    for item in report_def.all_items():
        if item.Type in ("tablix", "table"):
            extra = item.model_extra or {}
            cell_names = _collect_tablix_cell_names(extra)
            if cell_names:
                tablix_cells_by_parent[item.Name] = cell_names
                tablix_cell_names.update(cell_names)

    # Second pass: build items list, skipping tablix cell children
    items_info = []
    for item in report_def.all_items():
        if item.Name in tablix_cell_names:
            continue  # Shown nested under parent tablix instead
        item_dict: dict[str, Any] = {
            "name": item.Name,
            "type": item.Type,
            "position": {"left": item.Left or "0in", "top": item.Top or "0in"},
            "size": {"width": item.Width or "0in", "height": item.Height or "0in"},
        }
        if item.Value:
            item_dict["value"] = item.Value
        if item.Type == "barcode":
            extra = item.model_extra or {}
            if "Symbology" in extra:
                item_dict["symbology"] = extra["Symbology"]
        if item.Type == "table":
            extra = item.model_extra or {}
            if "DataSetName" in extra:
                item_dict["dataset"] = extra["DataSetName"]
            if item.Name in tablix_cells_by_parent:
                item_dict["cells"] = tablix_cells_by_parent[item.Name]
        if item.Type == "tablix":
            extra = item.model_extra or {}
            if "DataSetName" in extra:
                item_dict["dataset"] = extra["DataSetName"]
            if item.Name in tablix_cells_by_parent:
                item_dict["cells"] = tablix_cells_by_parent[item.Name]
        items_info.append(item_dict)

    result = {
        "file": file,
        "page": {
            "width": page.PageWidth,
            "height": page.PageHeight,
            "margins": {
                "top": page.TopMargin,
                "bottom": page.BottomMargin,
                "left": page.LeftMargin,
                "right": page.RightMargin,
            },
        },
        "items": items_info,
    }

    ctx.output(single(result, "report", count=len(items_info)))
