"""Report add element commands (textbox, barcode, image, table, etc.)."""

from __future__ import annotations

from typing import Any

import click

from dxs.cli import DxsContext, handle_errors, pass_context
from dxs.commands.report import (
    _build_style,
    _derive_group_name,
    _parse_named_value,
    _parse_report,
    _parse_sort_expression,
    _parse_style_string,
    _position_options,
    _read_report,
    _sanitize_expression,
    _serialize_report,
    _style_options,
    _write_report,
    add,
    tablix,
)
from dxs.utils.responses import single


@add.command("textbox")
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
@click.option("--name", required=True, help="Element name (unique identifier)")
@_position_options
@click.option("--value", default=None, help="Text content or expression (e.g., =Fields!Name.Value)")
@click.option("--can-grow", is_flag=True, default=False, help="Allow textbox to grow vertically")
@click.option("--parent", default=None, help="Parent rectangle name (for nesting)")
@_style_options
@pass_context
@handle_errors
def add_textbox(
    ctx: DxsContext,
    file: str,
    name: str,
    left: str,
    top: str,
    width: str,
    height: str,
    value: str | None,
    can_grow: bool,
    parent: str | None,
    **style_kwargs: Any,
) -> None:
    """Add a textbox element.

    \b
    Examples:
        dxs report add textbox report.rdlx-json --name Title --left 1in --top 0in --width 3in --height 0.3in --value "Bill of Lading"
        dxs report add textbox report.rdlx-json --name ShipperName --left 0.5in --top 1in --width 3in --height 0.3in --value "=Fields!ShipperName.Value" --font-size 12pt --font-weight Bold
    """
    from dxs.report.engine import add_child_item, add_item

    style = _build_style(**style_kwargs)
    item_props: dict[str, Any] = {
        "Type": "textbox",
        "Name": name,
        "Left": left,
        "Top": top,
        "Width": width,
        "Height": height,
    }
    if value is not None:
        item_props["Value"] = value
    if can_grow:
        item_props["CanGrow"] = True
    if style:
        item_props["Style"] = style

    data = _read_report(file)
    report_def = _parse_report(data)
    if parent:
        add_child_item(report_def, parent_name=parent, item_props=item_props)
    else:
        add_item(report_def, item_props)
    _write_report(file, _serialize_report(report_def))

    ctx.output(
        single(
            {
                "file": file,
                "element": name,
                "type": "textbox",
                "position": {"left": left, "top": top},
            },
            "element",
        )
    )


@add.command("barcode")
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
@click.option("--name", required=True, help="Element name (unique identifier)")
@click.option("--symbology", required=True, help="Barcode type (e.g., Code128, QRCode, PDF417)")
@_position_options
@click.option("--value", required=True, help="Data to encode (expression supported)")
@click.option("--caption/--no-caption", default=True, help="Show human-readable text")
@click.option("--parent", default=None, help="Parent rectangle name (for nesting)")
@_style_options
@pass_context
@handle_errors
def add_barcode(
    ctx: DxsContext,
    file: str,
    name: str,
    symbology: str,
    left: str,
    top: str,
    width: str,
    height: str,
    value: str,
    caption: bool,
    parent: str | None,
    **style_kwargs: Any,
) -> None:
    """Add a barcode element.

    \b
    Examples:
        dxs report add barcode report.rdlx-json --name ProBarcode --symbology Code128 --left 5in --top 0.5in --width 2.5in --height 0.75in --value "=Fields!PRONumber.Value"
        dxs report add barcode report.rdlx-json --name QR --symbology QRCode --left 6in --top 0in --width 1.5in --height 1.5in --value "=Fields!TrackingURL.Value" --no-caption
    """
    from dxs.report.engine import add_child_item, add_item

    style = _build_style(**style_kwargs)
    item_props: dict[str, Any] = {
        "Type": "barcode",
        "Name": name,
        "Left": left,
        "Top": top,
        "Width": width,
        "Height": height,
        "Value": value,
        "Symbology": symbology,
        "Caption": caption,
    }
    if style:
        item_props["Style"] = style

    data = _read_report(file)
    report_def = _parse_report(data)
    if parent:
        add_child_item(report_def, parent_name=parent, item_props=item_props)
    else:
        add_item(report_def, item_props)
    _write_report(file, _serialize_report(report_def))

    ctx.output(
        single(
            {"file": file, "element": name, "type": "barcode", "symbology": symbology},
            "element",
        )
    )


@add.command("image")
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
@click.option("--name", required=True, help="Element name (unique identifier)")
@_position_options
@click.option(
    "--source",
    default=None,
    type=click.Choice(["External", "Embedded", "Database"], case_sensitive=False),
    help="Image source type",
)
@click.option("--value", default=None, help="URL, embedded name, or expression")
@click.option(
    "--file",
    "image_file",
    default=None,
    type=click.Path(exists=True, dir_okay=False),
    help="Image file to embed (auto-encodes as base64)",
)
@click.option("--mime-type", default="image/png", help="Image MIME type")
@click.option(
    "--sizing",
    default="FitProportional",
    type=click.Choice(["AutoSize", "Fit", "FitProportional", "Clip"], case_sensitive=False),
    help="Image sizing mode",
)
@click.option("--parent", default=None, help="Parent rectangle name (for nesting)")
@_style_options
@pass_context
@handle_errors
def add_image(
    ctx: DxsContext,
    file: str,
    name: str,
    left: str,
    top: str,
    width: str,
    height: str,
    source: str | None,
    value: str | None,
    image_file: str | None,
    mime_type: str,
    sizing: str,
    parent: str | None,
    **style_kwargs: Any,
) -> None:
    """Add an image element.

    \b
    Examples:
        dxs report add image report.rdlx-json --name Logo --file logo.png --left 0in --top 0in --width 2in --height 1in
        dxs report add image report.rdlx-json --name Logo --source External --value "https://example.com/logo.png" --left 0in --top 0in --width 2in --height 1in
        dxs report add image report.rdlx-json --name Photo --source Database --value "=Fields!ProductImage.Value" --mime-type image/png --left 0in --top 0in --width 2in --height 2in
    """
    import base64
    from pathlib import Path

    from dxs.report.engine import add_child_item, add_item
    from dxs.report.models import EmbeddedImage
    from dxs.utils.errors import ValidationError
    from dxs.utils.image import read_and_validate_image

    # Validate mutual exclusion: --file and --value cannot both be specified
    if image_file and value:
        raise ValidationError(
            message="--file and --value are mutually exclusive",
            code="DXS-RPT-070",
            suggestions=[
                "Use --file to embed an image file, or --value to specify a URL/expression"
            ],
        )

    # Validate at least one of --file or --value is specified
    if not image_file and not value:
        raise ValidationError(
            message="Either --file or --value must be specified",
            code="DXS-RPT-073",
            suggestions=[
                "Use --file to embed an image file",
                "Use --source and --value to specify External URL or Database expression",
            ],
        )

    # Process --file: read, validate, and encode as base64
    image_data: bytes | None = None
    if image_file:
        img_path = Path(image_file)
        image_data, mime_type = read_and_validate_image(img_path)
        source = "Embedded"
        value = name

    # If --value provided without --source, error
    if value and not source:
        raise ValidationError(
            message="--source is required when --value is specified",
            code="DXS-RPT-074",
            suggestions=["Specify --source as one of: External, Embedded, Database"],
        )

    assert source is not None
    assert value is not None

    style = _build_style(**style_kwargs)
    item_props: dict[str, Any] = {
        "Type": "image",
        "Name": name,
        "Left": left,
        "Top": top,
        "Width": width,
        "Height": height,
        "Source": source,
        "Value": value,
        "MIMEType": mime_type,
        "Sizing": sizing,
    }
    if style:
        item_props["Style"] = style

    data = _read_report(file)
    report_def = _parse_report(data)
    if parent:
        add_child_item(report_def, parent_name=parent, item_props=item_props)
    else:
        add_item(report_def, item_props)

    # Append embedded image entry if --file was used
    if image_data is not None:
        if report_def.EmbeddedImages is None:
            report_def.EmbeddedImages = []
        report_def.EmbeddedImages.append(
            EmbeddedImage(
                Name=name,
                MIMEType=mime_type,
                ImageData=base64.b64encode(image_data).decode("ascii"),
            )
        )

    _write_report(file, _serialize_report(report_def))

    output_data: dict[str, Any] = {"file": file, "element": name, "type": "image", "source": source}
    if image_data is not None:
        output_data["mime_type"] = mime_type
        output_data["size_bytes"] = len(image_data)

    ctx.output(
        single(
            output_data,
            "element",
        )
    )


@add.command("table")
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
@click.option("--name", required=True, help="Element name (unique identifier)")
@_position_options
@click.option("--dataset", required=True, help="Dataset name to bind to")
@click.option(
    "--columns",
    default=None,
    help='Column widths as comma-separated values (e.g., "2in,3in,1.5in")',
)
@click.option(
    "--header-cell",
    "header_cells",
    multiple=True,
    help="Header cell value (repeat for multiple cells)",
)
@click.option(
    "--detail-cell",
    "detail_cells",
    multiple=True,
    help="Detail cell value/expression (repeat for multiple cells)",
)
@click.option("--header", default=None, hidden=True, help="Deprecated: use --header-cell")
@click.option("--detail", default=None, hidden=True, help="Deprecated: use --detail-cell")
@click.option(
    "--header-style",
    default=None,
    help='Header cell styles (e.g., "background-color:#f0f0f0;padding:2pt")',
)
@click.option(
    "--detail-style",
    default=None,
    help='Detail cell styles (e.g., "padding:2pt;vertical-align:Middle")',
)
@click.option("--parent", default=None, help="Parent rectangle name (for nesting)")
@_style_options
@pass_context
@handle_errors
def add_table(
    ctx: DxsContext,
    file: str,
    name: str,
    left: str,
    top: str,
    width: str,
    height: str,
    dataset: str,
    columns: str | None,
    header_cells: tuple[str, ...],
    detail_cells: tuple[str, ...],
    header: str | None,
    detail: str | None,
    header_style: str | None,
    detail_style: str | None,
    parent: str | None,
    **style_kwargs: Any,
) -> None:
    """Add a table element.

    \b
    Examples:
        dxs report add table report.rdlx-json --name LineItems --left 0.5in --top 3in --width 7in --height 4in --dataset Lines --columns "1in,3in,1in,1in,1in"
    """
    from dxs.report.engine import add_child_item, add_item

    # Merge deprecated --header/--detail with new --header-cell/--detail-cell
    if header and not header_cells:
        ctx.log(
            "Warning: --header is deprecated, use --header-cell instead.\n"
            "  Old: --header 'Col1,Col2,Col3'\n"
            "  New: --header-cell Col1 --header-cell Col2 --header-cell Col3"
        )
        header_cells = tuple(v.strip() for v in header.split(","))
    if detail and not detail_cells:
        ctx.log(
            "Warning: --detail is deprecated, use --detail-cell instead.\n"
            "  Old: --detail '=Fields!A.Value,=Fields!B.Value'\n"
            "  New: --detail-cell '=Fields!A.Value' --detail-cell '=Fields!B.Value'"
        )
        detail_cells = tuple(v.strip() for v in detail.split(","))

    style = _build_style(**style_kwargs)
    item_props: dict[str, Any] = {
        "Type": "table",
        "Name": name,
        "Left": left,
        "Top": top,
        "Width": width,
        "Height": height,
        "DataSetName": dataset,
    }

    if columns:
        col_widths = [c.strip() for c in columns.split(",")]
        item_props["TableColumns"] = [{"Width": w} for w in col_widths]

    if header_cells:
        header_values = [_sanitize_expression(v) for v in header_cells]
        base_hdr_style: dict[str, Any] = {
            "FontWeight": "Bold",
            "FontSize": style.get("FontSize", "10pt") if style else "10pt",
        }
        if header_style:
            base_hdr_style.update(_parse_style_string(header_style))
        header_row = {
            "Height": "0.25in",
            "TableCells": [
                {
                    "Item": {
                        "Type": "textbox",
                        "Name": f"{name}_Hdr{i}",
                        "Value": val,
                        "Style": dict(base_hdr_style),
                    }
                }
                for i, val in enumerate(header_values)
            ],
        }
        item_props["Header"] = {"TableRows": [header_row]}

    if detail_cells:
        detail_values = [_sanitize_expression(v) for v in detail_cells]
        base_det_style: dict[str, Any] = {
            "FontSize": style.get("FontSize", "10pt") if style else "10pt",
        }
        if detail_style:
            base_det_style.update(_parse_style_string(detail_style))
        detail_row = {
            "Height": "0.25in",
            "TableCells": [
                {
                    "Item": {
                        "Type": "textbox",
                        "Name": f"{name}_Det{i}",
                        "Value": val,
                        "Style": dict(base_det_style),
                    }
                }
                for i, val in enumerate(detail_values)
            ],
        }
        item_props["Details"] = {"TableRows": [detail_row]}

    if style:
        item_props["Style"] = style

    data = _read_report(file)
    report_def = _parse_report(data)
    if parent:
        add_child_item(report_def, parent_name=parent, item_props=item_props)
    else:
        add_item(report_def, item_props)
    _write_report(file, _serialize_report(report_def))

    ctx.output(
        single(
            {"file": file, "element": name, "type": "table", "dataset": dataset},
            "element",
        )
    )


@add.command("line")
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
@click.option("--name", required=True, help="Element name (unique identifier)")
@click.option("--start-x", required=True, help="Start X coordinate (e.g., 0in)")
@click.option("--start-y", required=True, help="Start Y coordinate (e.g., 1in)")
@click.option("--end-x", required=True, help="End X coordinate (e.g., 3.75in)")
@click.option("--end-y", required=True, help="End Y coordinate (e.g., 1in)")
@click.option("--line-width", default=None, help="Line thickness (e.g., 1pt, 2pt, 3pt)")
@click.option(
    "--line-style",
    default=None,
    type=click.Choice(["Solid", "Dashed", "Dotted"]),
    help="Line style",
)
@click.option("--parent", default=None, help="Parent rectangle name (for nesting)")
@pass_context
@handle_errors
def add_line(
    ctx: DxsContext,
    file: str,
    name: str,
    start_x: str,
    start_y: str,
    end_x: str,
    end_y: str,
    line_width: str | None,
    line_style: str | None,
    parent: str | None,
) -> None:
    """Add a line element.

    Lines use StartPoint/EndPoint coordinates, not Left/Top/Width/Height.

    \b
    Examples:
        dxs report add line report.rdlx-json --name Divider --start-x 0in --start-y 2in --end-x 7in --end-y 2in --line-width 2pt
        dxs report add line report.rdlx-json --name VLine --start-x 1.875in --start-y 0in --end-x 1.875in --end-y 0.7in
    """
    from dxs.report.engine import add_child_item, add_item

    item_props: dict[str, Any] = {
        "Type": "line",
        "Name": name,
        "StartPoint": {"X": start_x, "Y": start_y},
        "EndPoint": {"X": end_x, "Y": end_y},
    }
    if line_width:
        item_props["LineWidth"] = line_width
    if line_style:
        item_props["LineStyle"] = line_style

    data = _read_report(file)
    report_def = _parse_report(data)
    if parent:
        add_child_item(report_def, parent_name=parent, item_props=item_props)
    else:
        add_item(report_def, item_props)
    _write_report(file, _serialize_report(report_def))

    ctx.output(
        single(
            {"file": file, "element": name, "type": "line"},
            "element",
        )
    )


@add.command("rectangle")
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
@click.option("--name", required=True, help="Element name (unique identifier)")
@_position_options
@click.option("--parent", default=None, help="Parent rectangle name (for nesting)")
@_style_options
@pass_context
@handle_errors
def add_rectangle(
    ctx: DxsContext,
    file: str,
    name: str,
    left: str,
    top: str,
    width: str,
    height: str,
    parent: str | None,
    **style_kwargs: Any,
) -> None:
    """Add a rectangle element.

    \b
    Examples:
        dxs report add rectangle report.rdlx-json --name Section1 --left 0.5in --top 0.5in --width 7in --height 3in --border-style Solid --border-width 1pt
    """
    from dxs.report.engine import add_child_item, add_item

    style = _build_style(**style_kwargs)
    item_props: dict[str, Any] = {
        "Type": "rectangle",
        "Name": name,
        "Left": left,
        "Top": top,
        "Width": width,
        "Height": height,
    }
    if style:
        item_props["Style"] = style

    data = _read_report(file)
    report_def = _parse_report(data)
    if parent:
        add_child_item(report_def, parent_name=parent, item_props=item_props)
    else:
        add_item(report_def, item_props)
    _write_report(file, _serialize_report(report_def))

    ctx.output(
        single(
            {"file": file, "element": name, "type": "rectangle"},
            "element",
        )
    )


@add.command("shape")
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
@click.option("--name", required=True, help="Element name (unique identifier)")
@_position_options
@click.option(
    "--shape-type",
    default="Rectangle",
    type=click.Choice(
        [
            "Rectangle",
            "RoundedRectangle",
            "Ellipse",
            "Triangle",
            "Cross",
            "Diamond",
            "Pentagon",
            "Hexagon",
            "Star",
            "Arrow",
        ],
        case_sensitive=False,
    ),
    help="Shape type",
)
@click.option("--parent", default=None, help="Parent rectangle name (for nesting)")
@_style_options
@pass_context
@handle_errors
def add_shape(
    ctx: DxsContext,
    file: str,
    name: str,
    left: str,
    top: str,
    width: str,
    height: str,
    shape_type: str,
    parent: str | None,
    **style_kwargs: Any,
) -> None:
    """Add a shape element.

    \b
    Examples:
        dxs report add shape report.rdlx-json --name Bullet --shape-type Ellipse --left 0.5in --top 0.5in --width 0.25in --height 0.25in --background-color Red
    """
    from dxs.report.engine import add_child_item, add_item

    style = _build_style(**style_kwargs)
    item_props: dict[str, Any] = {
        "Type": "shape",
        "Name": name,
        "Left": left,
        "Top": top,
        "Width": width,
        "Height": height,
        "ShapeType": shape_type,
    }
    if style:
        item_props["Style"] = style

    data = _read_report(file)
    report_def = _parse_report(data)
    if parent:
        add_child_item(report_def, parent_name=parent, item_props=item_props)
    else:
        add_item(report_def, item_props)
    _write_report(file, _serialize_report(report_def))

    ctx.output(
        single(
            {"file": file, "element": name, "type": "shape", "shape_type": shape_type},
            "element",
        )
    )


@add.command("tablix")
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
@click.option("--name", required=True, help="Element name")
@_position_options
@click.option("--dataset", required=True, help="Dataset name to bind to")
@click.option("--columns", required=True, help="Comma-separated column widths")
@click.option(
    "--header-cell",
    "header_cells",
    multiple=True,
    help="Header cell value (repeat for multiple cells)",
)
@click.option(
    "--detail-cell",
    "detail_cells",
    multiple=True,
    help="Detail cell value/expression (repeat for multiple cells)",
)
@click.option(
    "--footer-cell",
    "footer_cells",
    multiple=True,
    help="Footer cell value/expression (repeat for multiple cells)",
)
@click.option("--header", default=None, hidden=True, help="Deprecated: use --header-cell")
@click.option("--detail", default=None, hidden=True, help="Deprecated: use --detail-cell")
@click.option(
    "--header-style",
    default=None,
    help='Header cell styles (e.g., "background-color:#f0f0f0;padding:2pt")',
)
@click.option(
    "--detail-style",
    default=None,
    help='Detail cell styles (e.g., "padding:2pt;vertical-align:Middle")',
)
@click.option(
    "--footer-style",
    default=None,
    help='Footer cell styles (e.g., "font-weight:Bold;background-color:#f0f0f0")',
)
@click.option(
    "--group-by",
    "group_bys",
    multiple=True,
    help="Named group: NAME:EXPRESSION (repeatable, outermost first)",
)
@click.option(
    "--group-header-cell",
    "group_header_cells",
    multiple=True,
    help="Group header cell: NAME:VALUE (repeat per column per group)",
)
@click.option(
    "--group-footer-cell",
    "group_footer_cells",
    multiple=True,
    help="Group footer cell: NAME:VALUE",
)
@click.option(
    "--group-header-style",
    "group_header_styles",
    multiple=True,
    help="Group header style: NAME:STYLE_STRING",
)
@click.option(
    "--group-footer-style",
    "group_footer_styles",
    multiple=True,
    help="Group footer style: NAME:STYLE_STRING",
)
@click.option(
    "--group-header-colspan",
    "group_header_colspans",
    multiple=True,
    help="Group name whose header spans all columns",
)
@click.option(
    "--group-footer-colspan",
    "group_footer_colspans",
    multiple=True,
    help="Group name whose footer spans all columns",
)
@click.option(
    "--sort",
    "sort_exprs",
    multiple=True,
    help="Detail sort: EXPRESSION:DIRECTION (asc/desc, repeatable)",
)
@click.option("--parent", default=None, help="Parent rectangle name")
@_style_options
@pass_context
@handle_errors
def add_tablix(
    ctx: DxsContext,
    file: str,
    name: str,
    left: str,
    top: str,
    width: str,
    height: str,
    dataset: str,
    columns: str,
    header_cells: tuple[str, ...],
    detail_cells: tuple[str, ...],
    footer_cells: tuple[str, ...],
    header: str | None,
    detail: str | None,
    header_style: str | None,
    detail_style: str | None,
    footer_style: str | None,
    group_bys: tuple[str, ...],
    group_header_cells: tuple[str, ...],
    group_footer_cells: tuple[str, ...],
    group_header_styles: tuple[str, ...],
    group_footer_styles: tuple[str, ...],
    group_header_colspans: tuple[str, ...],
    group_footer_colspans: tuple[str, ...],
    sort_exprs: tuple[str, ...],
    parent: str | None,
    **style_kwargs: Any,
) -> None:
    """Add a tablix (modern data grid) element.

    Supports row grouping (--group-by), group header/footer rows,
    colspan on group headers/footers, and sort expressions on detail rows.

    \b
    Examples:
        dxs report add tablix report.rdlx-json --name OrderLines --dataset ds_lines --left 0.5in --top 3in --width 7in --height 4in --columns "1.5in,3in,1.5in,1in" --header-cell "Item" --header-cell "Description" --header-cell "Qty" --header-cell "Total" --detail-cell "=Fields!ItemCode.Value" --detail-cell "=Fields!Description.Value" --detail-cell "=Fields!Quantity.Value" --detail-cell "=Fields!Total.Value"
        dxs report add tablix report.rdlx-json --name Summary --dataset ds_summary --left 0.5in --top 1in --width 4in --height 2in --columns "2in,2in" --header-style "background-color:#f0f0f0;padding:2pt"
    """
    from collections import OrderedDict

    from dxs.report.engine import add_child_item, add_item
    from dxs.utils.errors import ValidationError

    # Merge deprecated --header/--detail with new --header-cell/--detail-cell
    if header and not header_cells:
        ctx.log(
            "Warning: --header is deprecated, use --header-cell instead.\n"
            "  Old: --header 'Col1,Col2,Col3'\n"
            "  New: --header-cell Col1 --header-cell Col2 --header-cell Col3"
        )
        header_cells = tuple(v.strip() for v in header.split(","))
    if detail and not detail_cells:
        ctx.log(
            "Warning: --detail is deprecated, use --detail-cell instead.\n"
            "  Old: --detail '=Fields!A.Value,=Fields!B.Value'\n"
            "  New: --detail-cell '=Fields!A.Value' --detail-cell '=Fields!B.Value'"
        )
        detail_cells = tuple(v.strip() for v in detail.split(","))

    style = _build_style(**style_kwargs)
    col_widths = [c.strip() for c in columns.split(",")]
    num_cols = len(col_widths)

    # ── Parse group-by definitions ──────────────────────────────────────
    groups: OrderedDict[str, str] = OrderedDict()
    for gb in group_bys:
        alias, expr = _parse_named_value(gb)
        groups[alias] = expr

    # Parse group header/footer cells grouped by name
    ghdr_cells_by_group: dict[str, list[str]] = {}
    for gc in group_header_cells:
        alias, val = _parse_named_value(gc)
        if alias not in groups:
            raise ValidationError(
                message=f"Group header cell references unknown group '{alias}'",
                code="DXS-RPT-082",
                suggestions=[f"Known groups: {', '.join(groups.keys())}"]
                if groups
                else ["Add --group-by first"],
            )
        ghdr_cells_by_group.setdefault(alias, []).append(_sanitize_expression(val))

    gftr_cells_by_group: dict[str, list[str]] = {}
    for gc in group_footer_cells:
        alias, val = _parse_named_value(gc)
        if alias not in groups:
            raise ValidationError(
                message=f"Group footer cell references unknown group '{alias}'",
                code="DXS-RPT-082",
                suggestions=[f"Known groups: {', '.join(groups.keys())}"]
                if groups
                else ["Add --group-by first"],
            )
        gftr_cells_by_group.setdefault(alias, []).append(_sanitize_expression(val))

    # Parse group styles
    ghdr_styles_by_group: dict[str, dict[str, Any]] = {}
    for gs in group_header_styles:
        alias, style_str = _parse_named_value(gs)
        ghdr_styles_by_group[alias] = _parse_style_string(style_str)

    gftr_styles_by_group: dict[str, dict[str, Any]] = {}
    for gs in group_footer_styles:
        alias, style_str = _parse_named_value(gs)
        gftr_styles_by_group[alias] = _parse_style_string(style_str)

    ghdr_colspan_set = set(group_header_colspans)
    gftr_colspan_set = set(group_footer_colspans)

    # Parse sort expressions
    parsed_sorts = [_parse_sort_expression(s) for s in sort_exprs]

    # ── Build Rows ─────────────────────────────────────────────────────

    def _build_row(
        cells: list[str],
        prefix: str,
        base_style: dict[str, Any],
        height: str = "0.25in",
        colspan: bool = False,
    ) -> dict[str, Any]:
        """Build a tablix row dict from cell values."""
        row_cells: list[dict[str, Any] | None] = []
        for i, val in enumerate(cells):
            if colspan and i == 0:
                cell: dict[str, Any] = {
                    "ColSpan": num_cols,
                    "Item": {
                        "Type": "textbox",
                        "Name": f"{name}_{prefix}{i}",
                        "Value": val,
                        "Style": dict(base_style),
                    },
                }
                row_cells.append(cell)
            elif colspan and i > 0:
                row_cells.append(None)
            else:
                cell = {
                    "Item": {
                        "Type": "textbox",
                        "Name": f"{name}_{prefix}{i}",
                        "Value": val,
                        "Style": dict(base_style),
                    }
                }
                row_cells.append(cell)
        return {"Height": height, "Cells": row_cells}

    tablix_rows: list[dict[str, Any]] = []

    # Table header row
    if header_cells:
        base_hdr_style: dict[str, Any] = {
            "FontWeight": "Bold",
            "FontSize": style.get("FontSize", "10pt") if style else "10pt",
        }
        if header_style:
            base_hdr_style.update(_parse_style_string(header_style))
        tablix_rows.append(
            _build_row([_sanitize_expression(v) for v in header_cells], "Hdr", base_hdr_style)
        )

    # Group header rows (outermost → innermost)
    for alias in groups:
        if alias in ghdr_cells_by_group:
            g_style: dict[str, Any] = {
                "FontSize": style.get("FontSize", "10pt") if style else "10pt",
            }
            if alias in ghdr_styles_by_group:
                g_style.update(ghdr_styles_by_group[alias])
            cap_alias = alias.capitalize()
            is_colspan = alias in ghdr_colspan_set
            cells = ghdr_cells_by_group[alias]
            if is_colspan and len(cells) == 1:
                # Pad to num_cols for colspan rendering
                cells = cells + [""] * (num_cols - 1)
            tablix_rows.append(_build_row(cells, f"G{cap_alias}Hdr", g_style, colspan=is_colspan))

    # Detail row
    if detail_cells:
        base_det_style: dict[str, Any] = {
            "FontSize": style.get("FontSize", "10pt") if style else "10pt",
        }
        if detail_style:
            base_det_style.update(_parse_style_string(detail_style))
        tablix_rows.append(
            _build_row([_sanitize_expression(v) for v in detail_cells], "Det", base_det_style)
        )

    # Group footer rows (innermost → outermost)
    for alias in reversed(list(groups.keys())):
        if alias in gftr_cells_by_group:
            g_style_f: dict[str, Any] = {
                "FontWeight": "Bold",
                "FontSize": style.get("FontSize", "10pt") if style else "10pt",
            }
            if alias in gftr_styles_by_group:
                g_style_f.update(gftr_styles_by_group[alias])
            cap_alias = alias.capitalize()
            is_colspan = alias in gftr_colspan_set
            cells = gftr_cells_by_group[alias]
            if is_colspan and len(cells) == 1:
                cells = cells + [""] * (num_cols - 1)
            tablix_rows.append(_build_row(cells, f"G{cap_alias}Ftr", g_style_f, colspan=is_colspan))

    # Table footer row
    if footer_cells:
        base_ftr_style: dict[str, Any] = {
            "FontWeight": "Bold",
            "FontSize": style.get("FontSize", "10pt") if style else "10pt",
        }
        if footer_style:
            base_ftr_style.update(_parse_style_string(footer_style))
        tablix_rows.append(
            _build_row([_sanitize_expression(v) for v in footer_cells], "Ftr", base_ftr_style)
        )

    # ── Build RowHierarchy ──────────────────────────────────────────────

    detail_group: dict[str, Any] = {
        "Name": f"{name}_DetailGroup",
        "GroupExpressions": [],
    }
    if parsed_sorts:
        detail_group["SortExpressions"] = parsed_sorts

    row_idx = 0

    if groups:
        row_members: list[dict[str, Any]] = []
        if header_cells:
            row_members.append({"KeepWithGroup": "After", "BodyIndex": row_idx})
            row_idx += 1

        group_list = list(groups.keys())

        # Assign BodyIndex in physical row order:
        # table-header, group0-header, group1-header, ..., detail, ..., group1-footer, group0-footer, table-footer
        group_hdr_indices: dict[str, int] = {}
        for alias in group_list:
            if alias in ghdr_cells_by_group:
                group_hdr_indices[alias] = row_idx
                row_idx += 1

        detail_row_idx = row_idx
        row_idx += 1

        group_ftr_indices: dict[str, int] = {}
        for alias in reversed(group_list):
            if alias in gftr_cells_by_group:
                group_ftr_indices[alias] = row_idx
                row_idx += 1

        # Build inside-out: detail first, then wrap each group level
        innermost: list[dict[str, Any]] = [{"Group": detail_group, "BodyIndex": detail_row_idx}]

        for alias, expr in reversed(list(groups.items())):
            children: list[dict[str, Any]] = []
            if alias in ghdr_cells_by_group:
                children.append(
                    {
                        "KeepWithGroup": "After",
                        "BodyIndex": group_hdr_indices[alias],
                    }
                )
            children.extend(innermost)
            if alias in gftr_cells_by_group:
                children.append(
                    {
                        "KeepWithGroup": "Before",
                        "BodyIndex": group_ftr_indices[alias],
                    }
                )
            innermost = [
                {
                    "Group": {
                        "Name": _derive_group_name(name, alias),
                        "GroupExpressions": [_sanitize_expression(expr)],
                    },
                    "BodyCount": len(children),
                    "Children": children,
                }
            ]

        row_members.extend(innermost)
        if footer_cells:
            row_members.append({"KeepWithGroup": "Before", "BodyIndex": row_idx})
            row_idx += 1
    else:
        row_members = []
        if header_cells:
            row_members.append({"KeepWithGroup": "After", "BodyIndex": row_idx})
            row_idx += 1
        if detail_cells:
            row_members.append({"Group": detail_group, "BodyIndex": row_idx})
            row_idx += 1
        if footer_cells:
            row_members.append({"KeepWithGroup": "Before", "BodyIndex": row_idx})
            row_idx += 1

    item_props: dict[str, Any] = {
        "Type": "tablix",
        "Name": name,
        "Left": left,
        "Top": top,
        "Width": width,
        "Height": height,
        "DataSetName": dataset,
        "Body": {"Columns": col_widths, "Rows": tablix_rows},
        "ColumnHierarchy": {"Members": [{"BodyIndex": i, "Group": None} for i in range(num_cols)]},
        "RowHierarchy": {"Members": row_members},
    }
    if style:
        item_props["Style"] = style

    data = _read_report(file)
    report_def = _parse_report(data)
    if parent:
        add_child_item(report_def, parent_name=parent, item_props=item_props)
    else:
        add_item(report_def, item_props)
    _write_report(file, _serialize_report(report_def))
    ctx.output(
        single(
            {
                "file": file,
                "element": name,
                "type": "tablix",
                "dataset": dataset,
                "columns": num_cols,
                "has_footer": bool(footer_cells),
                "has_groups": bool(groups),
                "group_count": len(groups),
                "sort_count": len(parsed_sorts),
            },
            "element",
        )
    )


@add.command("list")
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
@click.option("--name", required=True, help="Element name")
@_position_options
@click.option("--dataset", required=True, help="Dataset name to bind to")
@click.option("--parent", default=None, help="Parent rectangle name")
@_style_options
@pass_context
@handle_errors
def add_list(
    ctx: DxsContext,
    file: str,
    name: str,
    left: str,
    top: str,
    width: str,
    height: str,
    dataset: str,
    parent: str | None,
    **style_kwargs: Any,
) -> None:
    """Add a list (repeating container) element.

    \b
    Examples:
        dxs report add list report.rdlx-json --name ItemList --dataset ds_items --left 0.5in --top 2in --width 7in --height 5in
        dxs report add list report.rdlx-json --name Details --dataset ds_lines --left 0in --top 0in --width 7in --height 3in --parent Section1
    """
    from dxs.report.engine import add_child_item, add_item

    style = _build_style(**style_kwargs)
    item_props: dict[str, Any] = {
        "Type": "list",
        "Name": name,
        "Left": left,
        "Top": top,
        "Width": width,
        "Height": height,
        "DataSetName": dataset,
        "ReportItems": [],
    }
    if style:
        item_props["Style"] = style

    data = _read_report(file)
    report_def = _parse_report(data)
    if parent:
        add_child_item(report_def, parent_name=parent, item_props=item_props)
    else:
        add_item(report_def, item_props)
    _write_report(file, _serialize_report(report_def))
    ctx.output(
        single(
            {"file": file, "element": name, "type": "list", "dataset": dataset},
            "element",
        )
    )


@add.command("page-header")
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
@click.option("--height", required=True, help="Header height (e.g., 0.5in)")
@click.option(
    "--no-first-page", is_flag=True, default=False, help="Don't print header on first page"
)
@click.option("--no-last-page", is_flag=True, default=False, help="Don't print header on last page")
@pass_context
@handle_errors
def add_page_header_cmd(
    ctx: DxsContext,
    file: str,
    height: str,
    no_first_page: bool,
    no_last_page: bool,
) -> None:
    """Add a page header section to the report.

    Creates a PageHeader on the first report section. Use batch with
    "parent": "PageHeader" to add child elements (textboxes, etc.).

    \b
    Examples:
        dxs report add page-header report.rdlx-json --height 0.5in
        dxs report add page-header report.rdlx-json --height 0.5in --no-first-page
    """
    from dxs.report.engine import add_page_header

    data = _read_report(file)
    report_def = _parse_report(data)
    add_page_header(
        report_def,
        height=height,
        print_on_first=not no_first_page,
        print_on_last=not no_last_page,
    )
    _write_report(file, _serialize_report(report_def))
    ctx.output(
        single(
            {"file": file, "section": "PageHeader", "height": height},
            "page_header_added",
        )
    )


@add.command("page-footer")
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
@click.option("--height", required=True, help="Footer height (e.g., 0.3in)")
@click.option(
    "--no-first-page", is_flag=True, default=False, help="Don't print footer on first page"
)
@click.option("--no-last-page", is_flag=True, default=False, help="Don't print footer on last page")
@pass_context
@handle_errors
def add_page_footer_cmd(
    ctx: DxsContext,
    file: str,
    height: str,
    no_first_page: bool,
    no_last_page: bool,
) -> None:
    """Add a page footer section to the report.

    Creates a PageFooter on the first report section. Use batch with
    "parent": "PageFooter" to add child elements (textboxes, etc.).

    \b
    Examples:
        dxs report add page-footer report.rdlx-json --height 0.3in
        dxs report add page-footer report.rdlx-json --height 0.3in --no-last-page
    """
    from dxs.report.engine import add_page_footer

    data = _read_report(file)
    report_def = _parse_report(data)
    add_page_footer(
        report_def,
        height=height,
        print_on_first=not no_first_page,
        print_on_last=not no_last_page,
    )
    _write_report(file, _serialize_report(report_def))
    ctx.output(
        single(
            {"file": file, "section": "PageFooter", "height": height},
            "page_footer_added",
        )
    )


# ── Tablix subcommands ──────────────────────────────────────────────────


@tablix.command("add-group")
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
@click.option("--tablix", "tablix_name", required=True, help="Tablix element name")
@click.option("--name", required=True, help="Group alias name")
@click.option(
    "--expression", required=True, help="Group expression (e.g., '=Fields!WarehouseId.Value')"
)
@click.option(
    "--header-cell",
    "header_cells",
    multiple=True,
    help="Group header cell value (repeat per column)",
)
@click.option(
    "--footer-cell",
    "footer_cells",
    multiple=True,
    help="Group footer cell value (repeat per column)",
)
@click.option("--header-style", default=None, help="Group header cell styles")
@click.option("--footer-style", default=None, help="Group footer cell styles")
@click.option("--header-colspan", is_flag=True, default=False, help="Header spans all columns")
@click.option("--footer-colspan", is_flag=True, default=False, help="Footer spans all columns")
@pass_context
@handle_errors
def tablix_add_group(
    ctx: DxsContext,
    file: str,
    tablix_name: str,
    name: str,
    expression: str,
    header_cells: tuple[str, ...],
    footer_cells: tuple[str, ...],
    header_style: str | None,
    footer_style: str | None,
    header_colspan: bool,
    footer_colspan: bool,
) -> None:
    """Add a row group to an existing tablix element.

    Wraps the detail group in a new parent group with optional
    header/footer rows.
    """
    from dxs.report.engine import add_tablix_group

    data = _read_report(file)
    report_def = _parse_report(data)

    # Build cell dicts for header/footer
    hdr_style = _parse_style_string(header_style) if header_style else {}
    ftr_style = _parse_style_string(footer_style) if footer_style else {}
    cap_alias = name.capitalize()

    hdr_cell_dicts: list[dict[str, Any]] | None = None
    if header_cells:
        hdr_cell_dicts = []
        for i, val in enumerate(header_cells):
            cell: dict[str, Any] = {
                "Item": {
                    "Type": "textbox",
                    "Name": f"{tablix_name}_G{cap_alias}Hdr{i}",
                    "Value": _sanitize_expression(val),
                    "Style": dict(hdr_style) if hdr_style else {},
                }
            }
            hdr_cell_dicts.append(cell)

    ftr_cell_dicts: list[dict[str, Any]] | None = None
    if footer_cells:
        ftr_cell_dicts = []
        for i, val in enumerate(footer_cells):
            cell = {
                "Item": {
                    "Type": "textbox",
                    "Name": f"{tablix_name}_G{cap_alias}Ftr{i}",
                    "Value": _sanitize_expression(val),
                    "Style": dict(ftr_style) if ftr_style else {},
                }
            }
            ftr_cell_dicts.append(cell)

    add_tablix_group(
        report_def,
        tablix_name=tablix_name,
        group_name=name,
        group_expression=_sanitize_expression(expression),
        header_cells=hdr_cell_dicts,
        footer_cells=ftr_cell_dicts,
        header_colspan=header_colspan,
        footer_colspan=footer_colspan,
    )

    _write_report(file, _serialize_report(report_def))
    ctx.output(
        single(
            {
                "file": file,
                "tablix": tablix_name,
                "group": name,
                "expression": expression,
                "has_header": bool(header_cells),
                "has_footer": bool(footer_cells),
            },
            "group_added",
        )
    )


@tablix.command("add-row")
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
@click.option("--tablix", "tablix_name", required=True, help="Tablix element name")
@click.option(
    "--position",
    required=True,
    type=click.Choice(["header", "footer", "table-header", "table-footer"], case_sensitive=False),
    help="Where to insert the row",
)
@click.option(
    "--group", "group_name", default=None, help="Group alias (required for header/footer)"
)
@click.option(
    "--cell",
    "cells",
    multiple=True,
    required=True,
    help="Cell value (repeat once per column, left-to-right)",
)
@click.option(
    "--cell-style",
    default=None,
    help="Style for all cells (e.g., 'font-size:9pt;font-weight:Bold')",
)
@click.option("--height", default="0.25in", help="Row height (default: 0.25in)")
@pass_context
@handle_errors
def tablix_add_row(
    ctx: DxsContext,
    file: str,
    tablix_name: str,
    position: str,
    group_name: str | None,
    cells: tuple[str, ...],
    cell_style: str | None,
    height: str,
) -> None:
    """Add a row to an existing tablix element.

    Inserts a new static row at the specified position within the tablix
    hierarchy. The number of --cell values must match the number of
    tablix columns.

    \b
    Positions:
      header        - Group header row (requires --group)
      footer        - Group footer row (requires --group)
      table-header  - Table-level header row (no --group)
      table-footer  - Table-level footer row (no --group)

    \b
    Examples:
        dxs report tablix add-row report.rdlx-json \\
          --tablix LocationsTable --group wh --position header \\
          --cell '=CountRows("LocationsTable_WhGroup")' \\
          --cell '' --cell '' \\
          --cell-style 'font-size:9pt;font-weight:Bold' --height 0.28in

        dxs report tablix add-row report.rdlx-json \\
          --tablix LocationsTable --position table-footer \\
          --cell 'Grand Total' --cell '' --cell '=Count(Fields!Id.Value)'
    """
    from dxs.report.engine import add_tablix_row

    data = _read_report(file)
    report_def = _parse_report(data)

    parsed_style = _parse_style_string(cell_style) if cell_style else None

    add_tablix_row(
        report_def,
        tablix_name=tablix_name,
        position=position,
        group_name=group_name,
        cells=list(cells),
        height=height,
        cell_style=parsed_style,
    )

    _write_report(file, _serialize_report(report_def))
    ctx.output(
        single(
            {
                "file": file,
                "tablix": tablix_name,
                "position": position,
                "group": group_name,
                "cells": len(cells),
            },
            "row_added",
        )
    )
