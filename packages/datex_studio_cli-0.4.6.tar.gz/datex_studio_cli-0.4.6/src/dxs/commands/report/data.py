"""Report sample data commands."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import click

from dxs.cli import DxsContext, handle_errors, pass_context
from dxs.commands.report import report
from dxs.utils.responses import single


@report.group("data")
def data() -> None:
    """Sample data file commands.

    Manage sample data files used for report preview rendering.
    """
    pass


@data.command("add-image")
@click.argument("data_file", type=click.Path(exists=True, dir_okay=False))
@click.option("--dataset", required=True, help="Dataset name in the data file")
@click.option("--field", required=True, help="Field name to set the image on")
@click.option(
    "--file",
    "image_file",
    required=True,
    type=click.Path(exists=True, dir_okay=False),
    help="Image file to encode",
)
@click.option("--row", type=int, default=0, help="Row index (default: 0)")
@pass_context
@handle_errors
def add_image(
    ctx: DxsContext,
    data_file: str,
    dataset: str,
    field: str,
    image_file: str,
    row: int,
) -> None:
    """Add an image to a sample data file as a data URI.

    Reads the image file, detects MIME type from extension, encodes as
    a data URI, and sets it on the specified dataset row and field.

    \b
    Examples:
        dxs report data add-image sample.data.json --dataset ds_header --field Logo --file logo.png
        dxs report data add-image sample.data.json --dataset ds_products --field Photo --file widget.jpg --row 2
    """
    from dxs.utils.errors import ValidationError
    from dxs.utils.image import encode_as_data_uri, read_and_validate_image

    img_bytes, mime_type = read_and_validate_image(Path(image_file))
    data_uri = encode_as_data_uri(img_bytes, mime_type)

    data_path = Path(data_file)
    file_data: dict[str, Any] = json.loads(data_path.read_text())

    datasets = file_data.get("dataSets", {})
    if dataset not in datasets:
        raise ValidationError(
            message=f"Dataset '{dataset}' not found in {data_file}",
            code="DXS-RPT-075",
            suggestions=[f"Available datasets: {', '.join(datasets.keys()) or '(none)'}"],
        )

    rows = datasets[dataset].get("data", [])
    if row < 0 or row >= len(rows):
        raise ValidationError(
            message=f"Row index {row} out of bounds (dataset has {len(rows)} rows)",
            code="DXS-RPT-076",
            suggestions=[f"Valid range: 0 to {len(rows) - 1}"],
        )

    rows[row][field] = data_uri
    data_path.write_text(json.dumps(file_data, indent=4) + "\n")

    ctx.output(
        single(
            {
                "file": data_file,
                "dataset": dataset,
                "field": field,
                "row": row,
                "mime_type": mime_type,
                "size_bytes": len(img_bytes),
            },
            "data_image",
        )
    )


@data.command("generate")
@click.argument("report_file", type=click.Path(exists=True, dir_okay=False))
@click.option(
    "--output",
    "-o",
    type=click.Path(dir_okay=False),
    default=None,
    help="Output path (default: <report>.data.json)",
)
@click.option("--force", is_flag=True, help="Overwrite existing file")
@pass_context
@handle_errors
def generate(ctx: DxsContext, report_file: str, output: str | None, force: bool) -> None:
    """Generate a sample data file from a report's DataSet definitions.

    Reads the DataSets in the RDLX-JSON report and produces a .data.json
    file with one placeholder row per dataset. Field names come from the
    DataSet Field Name values; placeholder values are inferred from names
    and types (0 for numeric-looking fields, "" for strings,
    "2026-01-01T00:00:00" for date fields).

    \b
    Examples:
        dxs report data generate my-report.rdlx-json
        dxs report data generate my-report.rdlx-json -o sample.data.json
        dxs report data generate my-report.rdlx-json --force
    """
    from dxs.utils.errors import ValidationError

    report_path = Path(report_file)
    report_data: dict = json.loads(report_path.read_text())
    datasets: list[dict] = report_data.get("DataSets", [])

    if not datasets:
        raise ValidationError(
            message=f"No DataSets found in {report_file}",
            code="DXS-RPT-080",
            suggestions=["Add datasets with 'dxs report dataset add' first"],
        )

    out_path = Path(output) if output else report_path.with_suffix("").with_suffix(".data.json")
    if out_path.exists() and not force:
        raise ValidationError(
            message=f"Output file already exists: {out_path}",
            code="DXS-RPT-081",
            suggestions=[
                "Use --force to overwrite",
                "Or specify a different path: -o another.data.json",
            ],
        )

    result: dict[str, Any] = {"dataSets": {}}
    for ds in datasets:
        name = ds.get("Name", "")
        fields: list[dict] = ds.get("Fields", [])
        row: dict[str, Any] = {}
        for field in fields:
            field_name = field.get("Name", "")
            data_field = field.get("DataField", field_name)
            row[field_name] = _placeholder_value(field_name, data_field)
        result["dataSets"][name] = {"data": [row]}

    out_path.write_text(json.dumps(result, indent=4) + "\n")
    ctx.output(
        single(
            {"file": str(out_path), "datasets": list(result["dataSets"].keys())},
            "data_generated",
        )
    )


# Date-like patterns in field names or DataField annotations
_DATE_SUFFIXES = ("DateTime", "Date", "Time", "Timestamp")
_NUMERIC_NAMES = (
    "Id",
    "Number",
    "LineNumber",
    "Count",
    "Total",
    "Amount",
    "Quantity",
    "Price",
    "Priority",
)


def _placeholder_value(field_name: str, data_field: str) -> Any:
    """Infer a placeholder value from the field name and DataField annotation."""
    # Date annotation in DataField (e.g. "CreatedSysDateTime[Date|...]")
    if "[Date|" in data_field or "[DateTime|" in data_field:
        return "2026-01-01T00:00:00"
    # Field name ends with a date-like suffix
    if any(field_name.endswith(s) for s in _DATE_SUFFIXES):
        return "2026-01-01T00:00:00"
    # Boolean-looking names
    if field_name.startswith("Is") or field_name.startswith("Has") or field_name == "Undone":
        return False
    # Numeric-looking names (exact match on last segment after underscore)
    bare = field_name.rsplit("_", 1)[-1] if "_" in field_name else field_name
    if bare in _NUMERIC_NAMES:
        return 0
    # Default: empty string
    return ""
