"""Report dataset and table operations commands."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import click

from dxs.cli import DxsContext, handle_errors, pass_context
from dxs.commands.report import (
    _build_style,
    _parse_report,
    _read_report,
    _sanitize_expression,
    _serialize_report,
    _style_options,
    _write_report,
    report,
)
from dxs.utils.responses import single


@report.group("dataset")
def dataset_group() -> None:
    """Manage report datasets.

    Datasets connect report elements to data fields from datasources.
    Use 'add' to create a dataset with fields, 'remove' to delete one,
    and 'add-field' to extend an existing dataset.

    \b
    Examples:
        dxs report dataset add report.rdlx-json --name ds_shipment --field Id --field LookupCode
        dxs report dataset remove report.rdlx-json --name ds_shipment
        dxs report dataset add-field report.rdlx-json --dataset ds_shipment --field Status
    """
    pass


@dataset_group.command("add")
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
@click.option("--name", required=True, help="Dataset name (e.g., ds_shipment)")
@click.option(
    "--field",
    "fields",
    multiple=True,
    required=True,
    help="Field name (repeat for each). Use dot.notation for nested; [Date|...] suffix for dates.",
)
@click.option("--datasource-name", default="Datasource", help="Data source name")
@click.option(
    "--command-text",
    default=None,
    help="Override CommandText (default: $.{name}.result or $.{name}.result.* with --is-collection)",
)
@click.option(
    "--is-collection",
    is_flag=True,
    default=False,
    help="Append .* to CommandText for collection datasets",
)
@click.option(
    "--config",
    type=click.Path(exists=True, dir_okay=False),
    default=None,
    help="Datasource config JSON file — auto-detects collection from resultIsCollection",
)
@pass_context
@handle_errors
def dataset_add(
    ctx: DxsContext,
    file: str,
    name: str,
    fields: tuple[str, ...],
    datasource_name: str,
    command_text: str | None,
    is_collection: bool,
    config: str | None,
) -> None:
    """Add a dataset to the report.

    When --config is provided, the command reads the datasource JSON file and
    auto-detects whether the result is a collection (sets CommandText .* suffix
    accordingly). This avoids the common mistake of omitting .* for collection
    datasources, which silently produces empty reports.

    \b
    Examples:
        dxs report dataset add report.rdlx-json --name ds_shipment --field Id --field LookupCode --field ShipperName
        dxs report dataset add report.rdlx-json --name ds_lines --field Id --field ItemCode --field Quantity --is-collection
        dxs report dataset add report.rdlx-json --name ds_pick_slip --config ds_pick_slip.json --field Id --field Material
    """
    import json

    from dxs.report.engine import add_dataset

    # Auto-detect collection from datasource config if provided
    if config and not is_collection and command_text is None:
        with open(config) as f:
            ds_config = json.load(f)
        if ds_config.get("resultIsCollection") is True:
            is_collection = True

    data = _read_report(file)
    report_def = _parse_report(data)
    add_dataset(
        report_def,
        name=name,
        fields=list(fields),
        datasource_name=datasource_name,
        command_text=command_text,
        is_collection=is_collection,
        report_path=Path(file),
    )
    _write_report(file, _serialize_report(report_def))
    ctx.output(single({"file": file, "dataset": name, "fields": len(fields)}, "dataset"))


@dataset_group.command("remove")
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
@click.option("--name", required=True, help="Dataset name to remove")
@pass_context
@handle_errors
def dataset_remove(ctx: DxsContext, file: str, name: str) -> None:
    """Remove a dataset from the report.

    \b
    Example:
        dxs report dataset remove report.rdlx-json --name ds_shipment
    """
    from dxs.report.engine import remove_dataset
    from dxs.utils.errors import ValidationError

    data = _read_report(file)
    report_def = _parse_report(data)
    if not remove_dataset(report_def, name):
        raise ValidationError(message=f"Dataset '{name}' not found", code="DXS-RPT-071")
    _write_report(file, _serialize_report(report_def))
    ctx.output(single({"file": file, "dataset": name}, "dataset"))


@dataset_group.command("add-field")
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
@click.option("--dataset", required=True, help="Dataset name")
@click.option(
    "--field",
    "fields",
    multiple=True,
    required=True,
    help="Field to add (repeat for multiple). Dot.notation for nested.",
)
@pass_context
@handle_errors
def dataset_add_field(ctx: DxsContext, file: str, dataset: str, fields: tuple[str, ...]) -> None:
    """Add fields to an existing dataset.

    \b
    Examples:
        dxs report dataset add-field report.rdlx-json --dataset ds_shipment --field Status --field OrderDate
        dxs report dataset add-field report.rdlx-json --dataset ds_lines --field Owner.Name
    """
    from dxs.report.engine import add_dataset_field

    data = _read_report(file)
    report_def = _parse_report(data)
    added = []
    for f in fields:
        result = add_dataset_field(report_def, dataset, f)
        added.append(result)
    _write_report(file, _serialize_report(report_def))
    ctx.output(
        single({"file": file, "dataset": dataset, "fields_added": len(added)}, "dataset_fields")
    )


# -- Table Operations --------------------------------------------------------


@report.group("table")
def table_group() -> None:
    """Table element operations.

    Modify table and tablix elements after creation.
    Use 'set-cell' to update cell content/style and 'add-column' to extend tables.

    \b
    Examples:
        dxs report table set-cell report.rdlx-json Header1 --value "Order ID"
        dxs report table add-column report.rdlx-json OrderTable --width 1.5in --header "Total" --detail "=Fields!Total.Value"
    """
    pass


@table_group.command("set-cell")
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
@click.argument("cell_name")
@click.option("--value", default=None, help="Cell value or expression")
@_style_options
@pass_context
@handle_errors
def table_set_cell_cmd(
    ctx: DxsContext, file: str, cell_name: str, value: str | None, **style_kwargs: Any
) -> None:
    """Update a table cell's value and/or style."""
    from dxs.report.engine import set_table_cell as _set_table_cell
    from dxs.utils.errors import ValidationError

    updates: dict[str, Any] = {}
    if value is not None:
        updates["Value"] = _sanitize_expression(value)
    style = _build_style(**style_kwargs)
    if style:
        updates["Style"] = style
    if not updates:
        raise ValidationError(message="No properties specified", code="DXS-RPT-021")
    data = _read_report(file)
    report_def = _parse_report(data)
    _set_table_cell(report_def, cell_name, updates)
    _write_report(file, _serialize_report(report_def))
    ctx.output(
        single({"file": file, "cell": cell_name, "updated": list(updates.keys())}, "table_cell")
    )


@table_group.command("add-column")
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
@click.argument("table_name")
@click.option("--width", required=True, help="Column width (e.g., 0.6in)")
@click.option("--position", type=int, default=None, help="Insert position (0-based, default: end)")
@click.option("--header", default=None, help="Header cell value")
@click.option("--detail", default=None, help="Detail cell value/expression")
@click.option("--shrink", is_flag=True, help="Auto-shrink existing columns proportionally")
@pass_context
@handle_errors
def table_add_column_cmd(
    ctx: DxsContext,
    file: str,
    table_name: str,
    width: str,
    position: int | None,
    header: str | None,
    detail: str | None,
    shrink: bool,
) -> None:
    """Add a column to an existing table or tablix element."""
    from dxs.report.engine import add_tablix_column

    data = _read_report(file)
    report_def = _parse_report(data)
    add_tablix_column(
        report_def,
        table_name,
        width=width,
        position=position,
        header_value=_sanitize_expression(header) if header else None,
        detail_value=_sanitize_expression(detail) if detail else None,
        shrink_existing=shrink,
    )
    _write_report(file, _serialize_report(report_def))
    ctx.output(
        single(
            {
                "file": file,
                "table": table_name,
                "column_width": width,
                "position": position if position is not None else "end",
            },
            "table_column",
        )
    )
