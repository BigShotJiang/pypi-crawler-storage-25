"""Report set/move/remove commands."""

from __future__ import annotations

from typing import Any

import click

from dxs.cli import DxsContext, handle_errors, pass_context
from dxs.commands.report import (
    _build_style,
    _parse_report,
    _read_report,
    _sanitize_expression,
    _serialize_report,
    _style_options,
    _write_report,
    report,
)
from dxs.utils.responses import single


@report.command("set")
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
@click.argument("element_name")
@click.option("--value", default=None, help="New value/text content")
@_style_options
@click.option("--can-grow", default=None, type=bool, help="Allow textbox to grow")
@click.option("--symbology", default=None, help="Barcode symbology")
@click.option("--caption", default=None, type=bool, help="Show barcode caption")
@click.option("--sizing", default=None, help="Image sizing mode")
@click.option("--dataset", default=None, help="Table dataset name")
@click.option("--shape-type", default=None, help="Shape type")
@click.option("--start-x", default=None, help="Line start X coordinate")
@click.option("--start-y", default=None, help="Line start Y coordinate")
@click.option("--end-x", default=None, help="Line end X coordinate")
@click.option("--end-y", default=None, help="Line end Y coordinate")
@click.option("--line-width", default=None, help="Line thickness (e.g., 2pt)")
@click.option("--line-style", default=None, help="Line style (Solid, Dashed, Dotted)")
@click.option("--width", "set_width", default=None, help="Element width (e.g., 3in)")
@click.option("--height", "set_height", default=None, help="Element height (e.g., 1in)")
@pass_context
@handle_errors
def set_props(
    ctx: DxsContext,
    file: str,
    element_name: str,
    value: str | None,
    can_grow: bool | None,
    symbology: str | None,
    caption: bool | None,
    sizing: str | None,
    dataset: str | None,
    shape_type: str | None,
    start_x: str | None,
    start_y: str | None,
    end_x: str | None,
    end_y: str | None,
    line_width: str | None,
    line_style: str | None,
    set_width: str | None,
    set_height: str | None,
    **style_kwargs: Any,
) -> None:
    """Modify properties of an existing element.

    Updates value, style, or type-specific properties on a named
    element. At least one property option must be provided. Style
    properties are merged (existing styles are preserved unless
    overridden).

    \b
    Examples:
        dxs report set report.rdlx-json ShipperName --font-size 12pt --font-weight Bold
        dxs report set report.rdlx-json ProBarcode --symbology QRCode
        dxs report set report.rdlx-json Title --value "Updated Title"
    """
    from dxs.report.engine import set_item_properties
    from dxs.utils.errors import ValidationError

    data = _read_report(file)
    report_def = _parse_report(data)

    item = report_def.find_item(element_name)
    if item is None:
        all_names = [i.Name for i in report_def.all_items()]
        raise ValidationError(
            message=f"Element '{element_name}' not found in {file}",
            code="DXS-RPT-020",
            suggestions=[f"Available elements: {', '.join(all_names)}"] if all_names else [],
        )

    # Build property updates
    updates: dict[str, Any] = {}
    if value is not None:
        updates["Value"] = _sanitize_expression(value)
    if can_grow is not None:
        updates["CanGrow"] = can_grow
    if symbology is not None:
        updates["Symbology"] = symbology
    if caption is not None:
        updates["Caption"] = caption
    if sizing is not None:
        updates["Sizing"] = sizing
    if dataset is not None:
        updates["DataSetName"] = dataset
    if shape_type is not None:
        updates["ShapeType"] = shape_type
    if set_width is not None:
        updates["Width"] = set_width
    if set_height is not None:
        updates["Height"] = set_height

    if start_x is not None or start_y is not None:
        sp: dict[str, Any] = {}
        if start_x is not None:
            sp["X"] = start_x
        if start_y is not None:
            sp["Y"] = start_y
        updates["StartPoint"] = sp
    if end_x is not None or end_y is not None:
        ep: dict[str, Any] = {}
        if end_x is not None:
            ep["X"] = end_x
        if end_y is not None:
            ep["Y"] = end_y
        updates["EndPoint"] = ep
    if line_width is not None:
        updates["LineWidth"] = line_width
    if line_style is not None:
        updates["LineStyle"] = line_style

    style = _build_style(**style_kwargs)
    if style:
        updates["Style"] = style

    if not updates:
        raise ValidationError(
            message="No properties specified to update",
            code="DXS-RPT-021",
            suggestions=["Specify at least one property to change (e.g., --value, --font-size)"],
        )

    set_item_properties(item, updates)
    _write_report(file, _serialize_report(report_def))

    ctx.output(
        single(
            {"file": file, "element": element_name, "updated_properties": list(updates.keys())},
            "element",
        )
    )


@report.command("move")
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
@click.argument("element_name")
@click.option("--left", default=None, help="New left position")
@click.option("--top", default=None, help="New top position")
@click.option("--width", default=None, help="New width")
@click.option("--height", default=None, help="New height")
@click.option("--start-x", default=None, help="Line start X coordinate")
@click.option("--start-y", default=None, help="Line start Y coordinate")
@click.option("--end-x", default=None, help="Line end X coordinate")
@click.option("--end-y", default=None, help="Line end Y coordinate")
@pass_context
@handle_errors
def move(
    ctx: DxsContext,
    file: str,
    element_name: str,
    left: str | None,
    top: str | None,
    width: str | None,
    height: str | None,
    start_x: str | None,
    start_y: str | None,
    end_x: str | None,
    end_y: str | None,
) -> None:
    """Reposition or resize an element.

    Changes position (--left, --top) and/or size (--width, --height)
    of a named element. At least one option is required. Only the
    specified properties are updated; others remain unchanged.

    \b
    Examples:
        dxs report move report.rdlx-json ProBarcode --left 5in --top 0.75in
        dxs report move report.rdlx-json Title --width 4in --height 0.5in
    """
    from dxs.utils.errors import ValidationError

    data = _read_report(file)
    report_def = _parse_report(data)

    item = report_def.find_item(element_name)
    if item is None:
        all_names = [i.Name for i in report_def.all_items()]
        raise ValidationError(
            message=f"Element '{element_name}' not found in {file}",
            code="DXS-RPT-020",
            suggestions=[f"Available elements: {', '.join(all_names)}"] if all_names else [],
        )

    changed: dict[str, str] = {}
    if left is not None:
        item.Left = left
        changed["left"] = left
    if top is not None:
        item.Top = top
        changed["top"] = top
    if width is not None:
        item.Width = width
        changed["width"] = width
    if height is not None:
        item.Height = height
        changed["height"] = height

    if start_x is not None or start_y is not None:
        sp = item.model_extra.get("StartPoint", {}) if item.model_extra else {}
        if start_x is not None:
            sp["X"] = start_x
            changed["start-x"] = start_x
        if start_y is not None:
            sp["Y"] = start_y
            changed["start-y"] = start_y
        if item.model_extra is None:
            object.__setattr__(item, "__pydantic_extra__", {})
        item.model_extra["StartPoint"] = sp

    if end_x is not None or end_y is not None:
        ep = item.model_extra.get("EndPoint", {}) if item.model_extra else {}
        if end_x is not None:
            ep["X"] = end_x
            changed["end-x"] = end_x
        if end_y is not None:
            ep["Y"] = end_y
            changed["end-y"] = end_y
        if item.model_extra is None:
            object.__setattr__(item, "__pydantic_extra__", {})
        item.model_extra["EndPoint"] = ep

    if not changed:
        raise ValidationError(
            message="No position/size changes specified",
            code="DXS-RPT-022",
            suggestions=[
                "Specify at least one of: --left, --top, --width, --height, --start-x, --start-y, --end-x, --end-y"
            ],
        )

    _write_report(file, _serialize_report(report_def))

    ctx.output(
        single(
            {"file": file, "element": element_name, "changes": changed},
            "element",
        )
    )


@report.command("remove")
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
@click.argument("element_name")
@pass_context
@handle_errors
def remove(ctx: DxsContext, file: str, element_name: str) -> None:
    """Remove an element by name.

    \b
    Examples:
        dxs report remove report.rdlx-json OldElement
    """
    from dxs.report.engine import remove_item
    from dxs.utils.errors import ValidationError

    data = _read_report(file)
    report_def = _parse_report(data)

    if not remove_item(report_def, element_name):
        all_names = [i.Name for i in report_def.all_items()]
        raise ValidationError(
            message=f"Element '{element_name}' not found in {file}",
            code="DXS-RPT-020",
            suggestions=[f"Available elements: {', '.join(all_names)}"] if all_names else [],
        )

    _write_report(file, _serialize_report(report_def))

    ctx.output(
        single(
            {"file": file, "element": element_name},
            "element",
        )
    )
