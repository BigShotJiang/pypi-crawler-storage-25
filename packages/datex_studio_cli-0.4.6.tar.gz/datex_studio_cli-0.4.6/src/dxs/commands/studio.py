"""Studio command: dxs studio — launch local web UI for OData exploration."""

import atexit
import shutil
import socket
import subprocess
import sys
from pathlib import Path

import click
import httpx

from dxs.utils.paths import read_studio_lock


def _launch_server(port: int, no_browser: bool, dev: bool) -> None:
    """Launch the studio web server.

    Args:
        port: Port to run the server on.
        no_browser: If True, don't auto-open browser on startup.
        dev: If True, spawn Next.js dev server and proxy frontend requests.
    """
    try:
        import uvicorn  # noqa: F401
    except ImportError as e:
        raise click.ClickException(
            "Studio requires extra dependencies. Install with:\n\n"
            "  uv pip install 'datex-studio-cli[studio]'\n\n"
            "Or if developing locally:\n\n"
            "  uv sync --extra studio"
        ) from e

    from dxs.core.auth.token_cache import MultiIdentityTokenCache

    # Verify auth before starting server
    cache = MultiIdentityTokenCache()
    identity = cache.get_active_identity()
    if identity is None:
        raise click.ClickException("Not authenticated. Run 'dxs auth login' first.")

    next_dev_url: str | None = None

    if dev:
        next_port = _find_free_port()
        frontend_dir = Path(__file__).resolve().parent.parent / "web" / "frontend"
        if not (frontend_dir / "package.json").exists():
            raise click.ClickException(
                f"Frontend directory not found at {frontend_dir}.\n"
                "Dev mode requires the frontend source checkout."
            )

        # Clear stale .next cache to prevent webpack HMR crashes
        next_cache = frontend_dir / ".next"
        if next_cache.exists():
            shutil.rmtree(next_cache)

        click.echo(
            f"Starting Next.js dev server on port {next_port}...",
            err=True,
        )
        npm_path = shutil.which("npm") or "npm"
        next_proc = subprocess.Popen(
            [npm_path, "run", "dev", "--", "--port", str(next_port)],
            cwd=str(frontend_dir),
            stdout=sys.stderr,
            stderr=sys.stderr,
        )
        atexit.register(next_proc.terminate)
        next_dev_url = f"http://localhost:{next_port}"

        click.echo(
            f"Starting Datex Studio in dev mode on http://127.0.0.1:{port}\n"
            f"  Proxying frontend to {next_dev_url}",
            err=True,
        )
    else:
        click.echo(f"Starting Datex Studio on http://127.0.0.1:{port}", err=True)

    if not no_browser:
        import threading
        import webbrowser

        def _open_browser() -> None:
            import time

            time.sleep(1)
            webbrowser.open(f"http://127.0.0.1:{port}")

        threading.Thread(target=_open_browser, daemon=True).start()

    from dxs.web.app import create_app

    app = create_app(dev_url=next_dev_url, port=port)
    uvicorn.run(app, host="127.0.0.1", port=port, log_level="warning", lifespan="on")


def _require_server() -> dict[str, int]:
    """Read the studio lockfile and return server info, or raise an error.

    Returns:
        dict with ``port`` and ``pid`` keys.

    Raises:
        click.ClickException: If no running studio server is found.
    """
    lock = read_studio_lock()
    if lock is None:
        raise click.ClickException("No studio server running. Start with: dxs studio")
    return lock


@click.group(invoke_without_command=True)
@click.option("--port", "-p", type=int, default=5051, help="Port to run the server on")
@click.option(
    "--no-browser",
    is_flag=True,
    default=False,
    help="Don't auto-open browser on startup",
)
@click.option(
    "--dev",
    is_flag=True,
    default=False,
    help="Dev mode: spawns Next.js dev server and proxies frontend requests to it",
)
@click.pass_context
def studio(ctx: click.Context, port: int, no_browser: bool, dev: bool) -> None:
    """Launch a local web UI for OData data exploration.

    Opens a browser-based interface for visually exploring OData data
    from Footprint API connections. Requires prior authentication
    via 'dxs auth login'.

    \b
    Examples:
        dxs studio
        dxs studio --port 5050
        dxs studio --no-browser
        dxs studio --dev
    """
    if ctx.invoked_subcommand is None:
        _launch_server(port, no_browser, dev)


@studio.command("open")
@click.argument("file", type=click.Path())
def studio_open(file: str) -> None:
    """Open a report file in the studio design canvas.

    FILE is the path to a report file (.rdlx-json) to open.
    """
    lock = _require_server()
    port = lock["port"]
    resolved = str(Path(file).resolve())

    try:
        resp = httpx.post(
            f"http://127.0.0.1:{port}/api/design/open",
            json={"path": resolved},
            timeout=10.0,
        )
        if resp.status_code >= 400:
            # Surface the server's error message instead of a generic HTTP status
            try:
                detail = resp.json().get("message", resp.text)
            except Exception:
                detail = resp.text
            raise click.ClickException(detail)
        resp.raise_for_status()
    except httpx.HTTPError as exc:
        raise click.ClickException(f"Failed to open file in studio: {exc}") from exc

    data = resp.json()
    file_path = data.get("path", resolved)
    click.echo(f"Opened {file_path} in studio (http://127.0.0.1:{port}/design)")


@studio.command("close")
def studio_close() -> None:
    """Close the current design session in studio."""
    lock = _require_server()
    port = lock["port"]

    try:
        resp = httpx.post(
            f"http://127.0.0.1:{port}/api/design/close",
            timeout=10.0,
        )
        resp.raise_for_status()
    except httpx.HTTPError as exc:
        raise click.ClickException(f"Failed to close design session: {exc}") from exc

    click.echo("Design session closed")


@studio.command("status")
def studio_status() -> None:
    """Show the current studio design session status."""
    lock = _require_server()
    port = lock["port"]

    try:
        resp = httpx.get(
            f"http://127.0.0.1:{port}/api/design/status",
            timeout=10.0,
        )
        resp.raise_for_status()
    except httpx.HTTPError as exc:
        raise click.ClickException(f"Failed to get studio status: {exc}") from exc

    data = resp.json()
    file_path = data.get("file")
    connections = data.get("connections", 0)

    if file_path:
        click.echo(f"File: {file_path}")
        click.echo(f"Connections: {connections}")
    else:
        click.echo("No design session active")


def _find_free_port() -> int:
    """Find an available TCP port."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        port: int = s.getsockname()[1]
        return port
