"""CLI commands for managing Datex application functions.

Functions are standalone flow configurations (configurationTypeId=9)
that execute backend business logic, accessible via $flows.pkg_name.fn_name().

Iterative function development workflow:

  1. generate   - Generate function config -> local JSON file
  2. context    - Get designer type definitions for writing code
  3. validate   - Validate config against the branch (server-side)
  4. upsert     - Upload config file to the branch

Inspection commands:

  5. get        - Get function config by reference name (peek at code)
  6. list       - List all functions on a branch
"""

import json as json_lib
from pathlib import Path
from typing import Any

import click

from dxs.cli import DxsContext, handle_errors, pass_context
from dxs.core.api.client import ApiClient
from dxs.core.api.endpoints import ConfigurationEndpoints
from dxs.core.auth import require_auth
from dxs.utils.click_options import pagination_options, resolve_branch
from dxs.utils.errors import ValidationError
from dxs.utils.responses import list_response, single

_MAX_CODE_FILE_BYTES = 512 * 1024


def _load_config_json(file: str) -> dict[str, Any]:
    """Load and parse a function config JSON file."""
    try:
        result: dict[str, Any] = json_lib.loads(Path(file).read_text(encoding="utf-8"))
        return result
    except OSError as e:
        raise ValidationError(
            message=f"Cannot read file '{file}': {e}",
            code="DXS-FN-001",
            suggestions=["Verify the file path is correct", "Check file permissions"],
        ) from None
    except json_lib.JSONDecodeError as e:
        raise ValidationError(
            message=f"Invalid JSON in {file}: {e}",
            code="DXS-FN-002",
            suggestions=["Check JSON syntax", "Use a JSON validator"],
        ) from None


def _read_code_file(path: str) -> str:
    """Read a code file, enforcing the size limit."""
    p = Path(path)
    if not p.is_file():
        raise ValidationError(
            message=f"Code file not found: {path}",
            code="DXS-FN-010",
            suggestions=["Verify the file path is correct", "Check file permissions"],
        )
    size = p.stat().st_size
    if size > _MAX_CODE_FILE_BYTES:
        raise ValidationError(
            message=f"Code file '{path}' exceeds 512 KB limit ({size:,} bytes)",
            code="DXS-FN-011",
            suggestions=["Split large functions into smaller ones"],
        )
    return p.read_text(encoding="utf-8")


@click.group()
def function() -> None:
    """Manage Datex application functions.

    Functions are backend business logic units accessible via
    $flows.pkg_name.fn_name() from other components.
    """


@function.command()
@click.option(
    "-r", "--reference-name", required=True, help="Function reference name (valid JS identifier)"
)
@click.option("-t", "--title", required=True, help="Display title")
@click.option("-d", "--description", default=None, help="Function description")
@click.option(
    "--code-file", required=True, type=click.Path(), help="Path to .ts file with function body code"
)
@click.option(
    "--in-param",
    multiple=True,
    help="Input parameter (name:type, name:type?, name:type[], name:type[]?)",
)
@click.option("--out-param", multiple=True, help="Output parameter (name:type or name:type[])")
@click.option("--private", "is_private", is_flag=True, help="Set access modifier to private")
@click.option("--enable-progress", is_flag=True, help="Enable progress and cancellation support")
@click.option("-o", "--output", required=True, type=click.Path(), help="Output JSON file path")
@pass_context
@handle_errors
def generate(
    ctx: DxsContext,
    reference_name: str,
    title: str,
    description: str | None,
    code_file: str,
    in_param: tuple[str, ...],
    out_param: tuple[str, ...],
    is_private: bool,
    enable_progress: bool,
    output: str,
) -> None:
    """Generate a function config JSON file.

    \b
    Example:
        dxs function generate -r my_func -t "My Function" \\
            --code-file fn.ts --in-param id:number -o fn.json
    """
    from dxs.core.designer.parsers import is_valid_js_identifier, parse_param, parse_simple_param
    from dxs.core.function.generator import generate as gen

    if not is_valid_js_identifier(reference_name):
        raise ValidationError(
            message=f"referenceName '{reference_name}' is not a valid JavaScript identifier.",
            code="DXS-FN-003",
            suggestions=[
                "Must start with letter, _, or $ and contain only letters, digits, _, or $",
                "Example: my_func, myFunc, _helper",
            ],
        )

    code = _read_code_file(code_file)

    parsed_in = [parse_param(v) for v in in_param] if in_param else None
    parsed_out = [parse_simple_param(v) for v in out_param] if out_param else None

    config = gen(
        reference_name=reference_name,
        title=title,
        code=code,
        description=description,
        in_params=parsed_in,
        out_params=parsed_out,
        access_modifier="private" if is_private else "public",
        enable_progress=enable_progress,
    )

    # Serialize
    data = config.model_dump(exclude_none=True)
    output_path = Path(output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json_lib.dumps(data, indent=2) + "\n", encoding="utf-8")

    ctx.output(
        single(
            item={
                "referenceName": reference_name,
                "title": title,
                "output": output,
            },
            semantic_key="function",
        )
    )


@function.command()
@click.argument("file", type=click.Path(exists=True))
@click.option("--branch", "-b", type=int, default=None, help="Branch ID (falls back to global -b)")
@pass_context
@require_auth
@handle_errors
def context(ctx: DxsContext, file: str, branch: int | None) -> None:
    """Get designer contexts (types/interfaces) for a function config file.

    \b
    Example:
        dxs function context fn.json --branch 64
    """
    branch_id = resolve_branch(ctx, branch, "DXS-FN-020")
    config_data = _load_config_json(file)

    api_client = ApiClient()
    response = api_client.post(
        ConfigurationEndpoints.contexts(branch_id, "flow"),
        data=config_data,
    )

    if not response or not isinstance(response, dict):
        ctx.output(single(item={"designer_contexts": []}, semantic_key="function_contexts"))
        return

    designer_contexts = []
    for dc in response.get("designerContexts", []):
        ctx_item: dict[str, Any] = {"id": dc["id"]}
        if dc.get("vars"):
            ctx_item["vars"] = [{"id": v["id"], "type": v["type"]} for v in dc["vars"]]
        if dc.get("text"):
            ctx_item["text"] = dc["text"]
        if dc.get("imports"):
            ctx_item["imports"] = dc["imports"]
        designer_contexts.append(ctx_item)

    output_data: dict[str, Any] = {"designer_contexts": designer_contexts}
    if response.get("globalContext"):
        output_data["global_context"] = response["globalContext"]

    ctx.output(single(item=output_data, semantic_key="function_contexts"))


@function.command(name="validate")
@click.argument("file", type=click.Path(exists=True))
@click.option("--branch", "-b", type=int, default=None, help="Branch ID (falls back to global -b)")
@pass_context
@require_auth
@handle_errors
def validate_cmd(ctx: DxsContext, file: str, branch: int | None) -> None:
    """Validate a function config file against a branch.

    \b
    Example:
        dxs function validate fn.json --branch 64
    """
    branch_id = resolve_branch(ctx, branch, "DXS-FN-020")
    config_data = _load_config_json(file)

    api_client = ApiClient()
    response = api_client.post(
        ConfigurationEndpoints.validate_config(branch_id, "flow"),
        data=config_data,
    )

    errors = response if isinstance(response, list) else []

    if not errors:
        ctx.output(
            single(
                item={"status": "valid", "message": "No validation errors"},
                semantic_key="validation_result",
            )
        )
    else:
        formatted = [
            {"message": e.get("message", str(e)) if isinstance(e, dict) else str(e)} for e in errors
        ]
        ctx.output(list_response(items=formatted, semantic_key="validation_errors"))


@function.command()
@click.argument("file", type=click.Path(exists=True))
@click.option("--branch", "-b", type=int, default=None, help="Branch ID (falls back to global -b)")
@pass_context
@require_auth
@handle_errors
def upsert(ctx: DxsContext, file: str, branch: int | None) -> None:
    """Upload a function config file to a branch (create or update).

    \b
    Example:
        dxs function upsert fn.json --branch 64
    """
    branch_id = resolve_branch(ctx, branch, "DXS-FN-020")
    config_data = _load_config_json(file)

    reference_name = config_data.get("referenceName")
    if not reference_name:
        raise ValidationError(
            message=f"File {file} is missing 'referenceName'.",
            code="DXS-FN-006",
            suggestions=["Use 'dxs function generate' to create a valid config file"],
        )

    from dxs.core.designer.parsers import is_valid_js_identifier

    if not is_valid_js_identifier(reference_name):
        raise ValidationError(
            message=f"referenceName '{reference_name}' is not a valid JavaScript identifier.",
            code="DXS-FN-007",
            suggestions=["Use 'dxs function generate' to create a valid config file"],
        )

    api_client = ApiClient()

    from dxs.utils.resolvers import upsert_config

    _response, action = upsert_config(api_client, branch_id, "flow", reference_name, config_data)

    ctx.output(
        single(
            item={
                "referenceName": reference_name,
                "title": config_data.get("title", ""),
                "branch_id": branch_id,
                "action": action,
            },
            semantic_key="function",
        )
    )


@function.command()
@click.argument("reference_name")
@click.option("--branch", "-b", type=int, default=None, help="Branch ID (falls back to global -b)")
@pass_context
@require_auth
@handle_errors
def get(ctx: DxsContext, reference_name: str, branch: int | None) -> None:
    """Get a function configuration by reference name.

    Returns the full config including code body, input/output parameters,
    and variables. Use this to inspect what a function does.

    \b
    Example:
        dxs function get my_func --branch 64
    """
    branch_id = resolve_branch(ctx, branch, "DXS-FN-020")

    from dxs.utils.resolvers import resolve_config_by_reference

    api_client = ApiClient()
    result = resolve_config_by_reference(api_client, branch_id, "flow", reference_name)
    ctx.output(single(item=result, semantic_key="function"))


@function.command(name="list")
@click.option("--branch", "-b", type=int, default=None, help="Branch ID (falls back to global -b)")
@pagination_options(default_limit=0)
@pass_context
@require_auth
@handle_errors
def list_functions(ctx: DxsContext, branch: int | None, limit: int) -> None:
    """List all functions on a branch.

    \b
    Example:
        dxs function list --branch 64
    """
    branch_id = resolve_branch(ctx, branch, "DXS-FN-020")

    api_client = ApiClient()
    result = api_client.get(ConfigurationEndpoints.list_all(branch_id, "flow"))
    if isinstance(result, list):
        items = result
    elif isinstance(result, dict):
        items = result.get("value", [])
    else:
        items = []
    if limit > 0:
        items = items[:limit]
    if not items:
        ctx.log(
            f"No functions found on branch {branch_id}. "
            "Verify the branch ID is correct with 'dxs source branch list'."
        )
    ctx.output(list_response(items=items, semantic_key="functions"))


@function.command()
@click.argument("reference_name", required=False, default=None)
@click.option(
    "--id",
    "config_id",
    type=int,
    default=None,
    help="Configuration ID (alternative to reference name)",
)
@click.option(
    "--branch",
    "-b",
    type=int,
    default=None,
    help="Branch ID (falls back to global -b)",
)
@pass_context
@require_auth
@handle_errors
def delete(
    ctx: DxsContext, reference_name: str | None, config_id: int | None, branch: int | None
) -> None:
    """Delete a function from a branch.

    Provide either a reference name (positional) or --id.

    \b
    Examples:
        dxs function delete my_func --branch 64
        dxs function delete --id 42 --branch 64
    """
    branch_id = resolve_branch(ctx, branch, "DXS-FN-020")

    if not reference_name and not config_id:
        raise ValidationError(
            message="Provide a reference name or --id.",
            code="DXS-FN-015",
            suggestions=[
                "Provide reference name: dxs function delete fn_name -b 64",
                "Or use --id: dxs function delete --id 456 -b 64",
            ],
        )

    api_client = ApiClient()

    if config_id is None:
        from dxs.utils.resolvers import resolve_config_by_reference

        assert reference_name is not None  # guaranteed by the guard above
        existing = resolve_config_by_reference(api_client, branch_id, "flow", reference_name)
        config_id = existing["id"]

    api_client.delete(ConfigurationEndpoints.delete(branch_id, "flow", config_id))
    ctx.output(
        single(
            item={
                "referenceName": reference_name or f"id:{config_id}",
                "branch_id": branch_id,
                "action": "deleted",
            },
            semantic_key="function",
        )
    )
