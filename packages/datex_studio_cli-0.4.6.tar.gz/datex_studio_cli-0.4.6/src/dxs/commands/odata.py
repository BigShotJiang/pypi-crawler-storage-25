"""OData commands: dxs odata [execute].

Implements OData query execution against Footprint API connections
using the user's delegated access token.

Flow:
1. Fetch connection details (connectionString) from Wavelength
2. Acquire Footprint API token via refresh token (delegated permissions)
3. Execute OData query directly against the Footprint API
"""

import base64
import json
from typing import Any

import click
import httpx

from dxs.cli import DxsContext, pass_context
from dxs.core.api import ApiClient
from dxs.core.api.endpoints import ApiConnectionEndpoints
from dxs.core.auth import require_auth
from dxs.core.footprint import get_footprint_token
from dxs.core.footprint.edmx_parser import parse_edmx
from dxs.core.footprint.metadata import MetadataCache
from dxs.utils.config import get_settings
from dxs.utils.errors import ApiError, AuthenticationError, ValidationError
from dxs.utils.resolvers import resolve_connection_option
from dxs.utils.responses import list_response, single


@click.group()
def odata() -> None:
    """OData query execution commands.

    Execute OData queries directly against Footprint API connections
    using delegated user authentication.

    \b
    Examples:
        dxs odata execute --connection-id 32 -q 'Warehouses?$top=10'
        dxs odata execute --org Datex --connection Prod -q 'Warehouses?$top=10'
    """
    pass


@odata.command()
@click.option(
    "--connection-id",
    "-c",
    type=int,
    default=None,
    help="API connection ID (use 'dxs organization connection list' to find IDs)",
)
@click.option(
    "--connection",
    type=str,
    default=None,
    help="API connection name (defaults --org to the active identity if omitted)",
)
@click.option(
    "--org",
    "-o",
    type=str,
    default=None,
    help=(
        "Organization name or ID. Optional when using --connection by name — "
        "defaults to the active identity's organization."
    ),
)
@click.option(
    "--query",
    "-q",
    type=str,
    required=True,
    help="OData query string (e.g., 'Warehouses?$select=Code,Name&$top=10')",
)
@click.option(
    "--oso-security/--no-oso-security",
    default=False,
    help="Apply OSO security rules (default: off)",
)
@click.option(
    "--show-caller-detail",
    is_flag=True,
    default=False,
    help="Print the x-caller JSON before executing the query",
)
@pass_context
@require_auth
def execute(
    ctx: DxsContext,
    connection_id: int | None,
    connection: str | None,
    org: str | None,
    query: str,
    oso_security: bool,
    show_caller_detail: bool,
) -> None:
    """Execute an OData query against a Footprint API connection.

    Uses the logged-in user's delegated permissions to authenticate
    with the Footprint API.

    When using --connection by name, --org defaults to the active identity's
    organization, so you can usually omit it.

    \b
    Examples:
        dxs odata execute --connection-id 32 -q 'Warehouses?$top=5'
        dxs odata execute --connection Demo -q 'Warehouses?$top=5'
        dxs odata execute --org Datex --connection Demo -q 'Warehouses?$top=5'
    """
    # Validate --org matches the active identity (if provided)
    if org:
        _validate_org_matches_identity(ctx, org)

    # Resolve connection ID
    resolved_connection_id = _resolve_connection(ctx, connection_id, connection, org)

    settings = get_settings()

    # Step 1: Fetch connection details
    ctx.log(f"Fetching API connection {resolved_connection_id}...")
    api_client = ApiClient()
    conn_data = api_client.get(ApiConnectionEndpoints.get(resolved_connection_id))
    connection_string = conn_data.get("connectionString", "").rstrip("/")

    if not connection_string:
        ctx.output_error(
            ValidationError(
                message=f"API connection {resolved_connection_id} has no connectionString",
                code="DXS-ODATA-003",
                suggestions=["Verify the API connection is properly configured"],
            )
        )
        raise SystemExit(1)

    # Step 2: Acquire Footprint token
    token = get_footprint_token()

    # Step 3: Execute OData query against Footprint
    if show_caller_detail:
        _show_caller_detail(ctx, token, oso_security)

    odata_url = f"{connection_string}/{query}"
    ctx.log(f"OData endpoint: {odata_url}")
    result = _execute_footprint_odata(
        connection_string=connection_string,
        query=query,
        token=token,
        timeout=settings.api_timeout,
        apply_oso_security=oso_security,
    )

    ctx.output(
        single(
            item=result,
            semantic_key="odata_result",
            query=query,
            connection_id=resolved_connection_id,
        )
    )


def _resolve_connection(
    ctx: DxsContext,
    connection_id: int | None,
    connection: str | None,
    org: str | None,
) -> int:
    """Resolve connection from either --connection-id or --org + --connection.

    If --connection is given without --org, falls back to the active identity's
    organization so users can omit --org for the common single-identity case.
    """
    if connection_id is None and connection is not None and org is None:
        from dxs.core.auth.token_cache import MultiIdentityTokenCache

        identity = MultiIdentityTokenCache().get_active_identity()
        if identity and identity.organization_name:
            org = identity.organization_name
            ctx.log(f"Using active identity's organization: {org}")
    return resolve_connection_option(connection_id, connection, org)


def _validate_org_matches_identity(ctx: DxsContext, org: str) -> None:
    """Validate that --org matches the active identity's organization.

    Prevents accidentally querying one org's connections with another org's credentials.
    """
    from dxs.core.auth.token_cache import MultiIdentityTokenCache

    cache = MultiIdentityTokenCache()
    identity = cache.get_active_identity()
    if not identity or not identity.organization_name:
        return  # Can't validate without org info

    if identity.organization_name.lower() != org.lower():
        ctx.output_error(
            ValidationError(
                message=(
                    f"Active identity is for '{identity.organization_name}' "
                    f"but --org '{org}' was specified"
                ),
                code="DXS-ODATA-ORG-MISMATCH",
                suggestions=[
                    f"Run 'dxs auth login {org}' or 'dxs auth switch {org}' first",
                    f"Or use '--org {identity.organization_name}' to match your active identity",
                ],
            )
        )
        raise SystemExit(1)


def _is_daemon_mode() -> bool:
    """Check if the active identity is using daemon (client credentials) auth."""
    from dxs.core.auth.token_cache import MultiIdentityTokenCache

    cache = MultiIdentityTokenCache()
    identity = cache.get_active_identity()
    return bool(identity and identity.footprint_client_id)


def _show_caller_detail(ctx: DxsContext, token: str, oso_security: bool) -> None:
    """Show x-caller diagnostic info when --show-caller-detail is used."""
    if _is_daemon_mode():
        x_caller_preview = _build_x_caller_header(token, apply_oso_security=oso_security)
        caller_json = json.loads(base64.b64decode(x_caller_preview))
        ctx.log(f"x-caller detail: {json.dumps(caller_json, indent=2)}")
    else:
        ctx.log(
            "x-caller header is not being sent because this identity uses "
            "delegated auth (home tenant). FootPrint reads user context "
            "directly from the JWT."
        )


def _build_x_caller_header(token: str, apply_oso_security: bool = False) -> str:
    """Build the x-caller header with user context from the token.

    The Footprint API requires an x-caller header containing base64-encoded JSON
    with user identity information. This is used for authorization and audit logging.

    In daemon mode (when active identity has footprint_client_id), the x-caller is
    built from the stored identity rather than from JWT claims, since the daemon
    JWT has no user context.

    Args:
        token: The Footprint API access token (JWT)
        apply_oso_security: Whether to enable OSO security rules

    Returns:
        Base64-encoded JSON string for the x-caller header
    """
    from dxs.core.auth.token_cache import MultiIdentityTokenCache

    # Check if active identity has daemon credentials
    cache = MultiIdentityTokenCache()
    identity = cache.get_active_identity()

    if identity and identity.footprint_client_id:
        # Daemon mode: build x-caller from stored identity (not from JWT)
        caller = {
            "id": identity.account_id,
            "tenantId": identity.tenant_id,
            "username": identity.account_username,
            "userDisplayName": identity.account_username,
            "roles": [],
            "applyOsoSecurity": False,  # Always false for daemon
            "integratorId": None,
        }
        return base64.b64encode(json.dumps(caller).encode()).decode()

    from dxs.core.auth.decorators import _decode_jwt_payload

    # Delegated user flow: decode token to extract user claims
    claims = _decode_jwt_payload(token) or {}

    # Build caller object matching wavelength's Caller structure
    caller = {
        "id": claims.get("oid"),  # User's Azure AD object ID
        "groups": claims.get("groups", []),  # Group memberships (if included in token)
        "tenantId": claims.get("tid"),  # Azure tenant ID
        "username": claims.get("preferred_username")
        or claims.get("email")
        or claims.get("unique_name"),
        "userDisplayName": claims.get("name"),
        "roles": [],  # Role claims (currently empty, matching wavelength behavior)
        "applyOsoSecurity": apply_oso_security,
        "integratorId": None,  # Service principal ID (null for user tokens)
    }

    return base64.b64encode(json.dumps(caller).encode()).decode()


def _raise_for_footprint_error(response: httpx.Response) -> None:
    """Raise ApiError for non-2xx Footprint API responses."""
    if response.status_code < 400:
        return

    if response.status_code in (401, 403):
        # Try to extract specific error from response body
        detail = None
        try:
            error_body = response.json()
            detail = error_body.get("error", {}).get("message") or error_body.get("message")
        except Exception:
            pass

        suggestions = [
            "Your Footprint token may have expired -- run 'dxs auth login' to re-authenticate",
        ]

        # Add context-specific suggestions for "unauthorized" errors
        if detail and "unauthorized" in detail.lower():
            suggestions.insert(
                0,
                "Your user ID is not registered in FootPrint's authorization system",
            )
            suggestions.append(
                "Use --show-caller-detail to see the identity being sent",
            )
            suggestions.append(
                "Contact your FootPrint admin to verify your user has 'Execute Component' permission",
            )

        message = "Footprint API authentication failed"
        if detail:
            message = f"Footprint API authentication failed: {detail}"

        raise AuthenticationError(
            message=message,
            code=f"DXS-AUTH-{response.status_code}",
            suggestions=suggestions,
        )

    # Try to extract error details from response body
    try:
        error_body = response.json()
        message = (
            error_body.get("error", {}).get("message")
            or error_body.get("message")
            or error_body.get("title")
            or error_body.get("detail")
            or f"Footprint API error: HTTP {response.status_code}"
        )
    except Exception:
        error_body = None
        message = f"Footprint API error: HTTP {response.status_code}"

    raise ApiError(
        message=message,
        code=f"DXS-API-{response.status_code}",
        status_code=response.status_code,
        details={
            "url": str(response.url),
            "status_code": response.status_code,
            "body": error_body,
        },
        suggestions=[
            "Check that the OData query is valid",
            "Verify the entity name exists (use 'dxs schema entities')",
            "If the problem persists, the Footprint API may be experiencing issues",
        ],
    )


def _execute_footprint_odata(
    connection_string: str,
    query: str,
    token: str,
    timeout: int = 30,
    apply_oso_security: bool = False,
) -> dict[str, Any]:
    """Execute an OData GET request against the Footprint API."""
    url = f"{connection_string}/{query}"

    headers: dict[str, str] = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
        "Accept": "application/json",
    }

    # Only send x-caller in daemon mode — delegated flow uses JWT claims directly
    if _is_daemon_mode():
        headers["x-caller"] = _build_x_caller_header(token, apply_oso_security=apply_oso_security)

    with httpx.Client(timeout=timeout) as client:
        response = client.get(url, headers=headers)
        _raise_for_footprint_error(response)
        result: dict[str, Any] = response.json()
        return result


@odata.group()
def metadata() -> None:
    """Explore OData $metadata for a connection.

    \b
    Examples:
        dxs odata metadata fetch --connection-id 32
        dxs odata metadata entities --connection-id 32
        dxs odata metadata describe Warehouses --connection-id 32
    """
    pass


def _fetch_metadata(
    ctx: DxsContext,
    connection_id: int | None,
    connection: str | None,
    org: str | None,
    refresh: bool,
) -> tuple[str, int]:
    """Fetch and cache $metadata XML for a connection.

    Returns:
        Tuple of (xml_text, resolved_connection_id).
    """
    resolved_id = _resolve_connection(ctx, connection_id, connection, org)
    cache = MetadataCache()

    if not refresh and cache.is_fresh(resolved_id):
        xml = cache.get(resolved_id)
        if xml is not None:
            ctx.log("Using cached metadata.")
            return xml, resolved_id

    # Fetch connection details
    ctx.log(f"Fetching connection {resolved_id}...")
    api_client = ApiClient()
    conn_data = api_client.get(ApiConnectionEndpoints.get(resolved_id))
    connection_string = conn_data.get("connectionString", "").rstrip("/")
    connection_name = conn_data.get("name")

    if not connection_string:
        raise ValidationError(
            message=f"API connection {resolved_id} has no connectionString",
            code="DXS-ODATA-003",
            suggestions=["Verify the API connection is properly configured"],
        )

    # Fetch $metadata
    ctx.log("Downloading $metadata...")
    token = get_footprint_token()
    settings = get_settings()
    url = f"{connection_string}/$metadata"

    x_caller = base64.b64encode(json.dumps({}).encode()).decode()

    with httpx.Client(timeout=settings.api_timeout) as client:
        response = client.get(
            url,
            headers={
                "Authorization": f"Bearer {token}",
                "x-caller": x_caller,
                "Accept": "application/xml",
            },
        )
        _raise_for_footprint_error(response)
        xml = response.text

    cache.put(resolved_id, xml, connection_name=connection_name)
    ctx.log("Metadata cached.")
    return xml, resolved_id


_CONNECTION_OPTIONS = [
    click.option(
        "--connection-id",
        "-c",
        type=int,
        default=None,
        help="API connection ID",
    ),
    click.option(
        "--connection",
        type=str,
        default=None,
        help="API connection name (defaults --org to the active identity if omitted)",
    ),
    click.option(
        "--org",
        "-o",
        type=str,
        default=None,
        help=(
            "Organization name or ID. Optional when using --connection by name — "
            "defaults to the active identity's organization."
        ),
    ),
    click.option(
        "--refresh",
        is_flag=True,
        default=False,
        help="Force re-download, ignoring cache",
    ),
]


def _add_connection_options(f: Any) -> Any:
    """Apply shared connection options to a command."""
    for option in reversed(_CONNECTION_OPTIONS):
        f = option(f)
    return f


@metadata.command()
@_add_connection_options
@pass_context
@require_auth
def fetch(
    ctx: DxsContext,
    connection_id: int | None,
    connection: str | None,
    org: str | None,
    refresh: bool,
) -> None:
    """Download and cache $metadata XML for a connection.

    \b
    Examples:
        dxs odata metadata fetch --connection-id 32
        dxs odata metadata fetch --org Datex --connection Prod --refresh
    """
    xml, resolved_id = _fetch_metadata(ctx, connection_id, connection, org, refresh)
    schema = parse_edmx(xml)
    ctx.output(
        single(
            item={
                "connection_id": resolved_id,
                "entity_type_count": len(schema.entity_types),
                "entity_set_count": len(schema.entity_sets),
                "status": "refreshed" if refresh else "cached",
            },
            semantic_key="metadata_fetch",
            connection_id=resolved_id,
        )
    )


@metadata.command()
@_add_connection_options
@pass_context
@require_auth
def entities(
    ctx: DxsContext,
    connection_id: int | None,
    connection: str | None,
    org: str | None,
    refresh: bool,
) -> None:
    """List entity sets from cached $metadata.

    Auto-fetches metadata if not cached.

    \b
    Examples:
        dxs odata metadata entities --connection-id 32
    """
    xml, resolved_id = _fetch_metadata(ctx, connection_id, connection, org, refresh)
    schema = parse_edmx(xml)

    items = []
    for es in schema.entity_sets.values():
        et = schema.entity_types.get(es.entity_type)
        items.append(
            {
                "name": es.name,
                "entity_type": es.entity_type,
                "property_count": len(et.properties) if et else 0,
            }
        )

    ctx.output(
        list_response(
            items=items,
            semantic_key="entity_sets",
            connection_id=resolved_id,
        )
    )


@metadata.command()
@click.argument("entity_name")
@_add_connection_options
@pass_context
@require_auth
def describe(
    ctx: DxsContext,
    entity_name: str,
    connection_id: int | None,
    connection: str | None,
    org: str | None,
    refresh: bool,
) -> None:
    """Show details for a specific entity type or entity set.

    \b
    Examples:
        dxs odata metadata describe Warehouses --connection-id 32
    """
    xml, resolved_id = _fetch_metadata(ctx, connection_id, connection, org, refresh)
    schema = parse_edmx(xml)

    # Try matching as entity set name first, then entity type name
    et = None
    matched_name = entity_name

    if entity_name in schema.entity_sets:
        es = schema.entity_sets[entity_name]
        et = schema.entity_types.get(es.entity_type)
        matched_name = es.name
    else:
        # Try matching as entity type (qualified or unqualified)
        for qualified, entity_type in schema.entity_types.items():
            if entity_type.name == entity_name or qualified == entity_name:
                et = entity_type
                matched_name = qualified
                break

    if et is None:
        raise ValidationError(
            message=f"Entity '{entity_name}' not found in metadata",
            code="DXS-ODATA-META-001",
            suggestions=[
                f"Run 'dxs odata metadata entities -c {resolved_id}' to list available entities",
            ],
        )

    ctx.output(
        single(
            item={
                "name": matched_name,
                "keys": et.keys,
                "properties": [p.model_dump() for p in et.properties],
                "navigation_properties": [n.model_dump() for n in et.navigation_properties],
            },
            semantic_key="entity_detail",
            connection_id=resolved_id,
        )
    )
