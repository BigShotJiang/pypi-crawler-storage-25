"""CRM commands: dxs crm [case|account|activity]."""

import re
from html.parser import HTMLParser
from pathlib import Path
from typing import TYPE_CHECKING, Any

import click

if TYPE_CHECKING:
    from dxs.cli import DxsContext
from markdownify import markdownify as md

from dxs.core.auth import require_auth
from dxs.core.dynamics.client import DynamicsClient
from dxs.core.output.yaml_fmt import LiteralString
from dxs.utils.responses import count_response, list_response, search_response, single
from dxs.utils.restricted import check_restricted_mode_for_option

# Regex pattern to extract attachment URLs from markdown
# Matches: ![...](/api/data/v9.1/msdyn_richtextfiles(UUID)/msdyn_imageblob/$value...)
_ATTACHMENT_URL_PATTERN = re.compile(
    r"!\[[^\]]*\]\((/api/data/v[\d.]+/msdyn_richtextfiles\(([a-f0-9-]+)\)/msdyn_imageblob/\$value[^)]*)\)"
)


# Case status code to human-readable mapping
_CASE_STATUS_LABELS = {
    0: "Active",
    1: "Resolved",
    2: "Cancelled",
}


def _extract_attachment_urls(markdown: str | None) -> list[dict[str, str]]:
    """Extract attachment URLs and UUIDs from markdown content.

    Parses markdown to find embedded rich text file references like:
    ![](/api/data/v9.1/msdyn_richtextfiles(uuid)/msdyn_imageblob/$value?size=full)

    Args:
        markdown: Markdown string to parse.

    Returns:
        List of dicts with 'url' (API path) and 'uuid' keys.
    """
    if not markdown:
        return []

    matches = _ATTACHMENT_URL_PATTERN.findall(markdown)
    return [{"url": url, "uuid": uuid} for url, uuid in matches]


def _replace_attachment_urls(
    markdown: str | LiteralString | None,
    url_to_path: dict[str, str],
) -> str | LiteralString | None:
    """Replace attachment URLs in markdown with local file paths.

    Args:
        markdown: Markdown string with embedded attachment URLs.
        url_to_path: Mapping of original URLs to local file paths.

    Returns:
        Updated markdown with URLs replaced by local paths.
    """
    if not markdown or not url_to_path:
        return markdown

    result = str(markdown)
    for url, path in url_to_path.items():
        result = result.replace(url, path)

    # Preserve LiteralString type for multiline content
    if isinstance(markdown, LiteralString):
        return LiteralString(result)
    return result


def _detect_file_extension(data: bytes) -> str:
    """Detect file extension from magic bytes.

    Args:
        data: Raw file bytes.

    Returns:
        File extension with leading dot (e.g., ".png"), or empty string if unknown.
    """
    # Common image magic bytes
    signatures = [
        (b"\x89PNG\r\n\x1a\n", ".png"),
        (b"\xff\xd8\xff", ".jpg"),
        (b"GIF87a", ".gif"),
        (b"GIF89a", ".gif"),
        (b"RIFF", ".webp"),  # Check for WEBP signature after RIFF
        (b"BM", ".bmp"),
        (b"\x00\x00\x01\x00", ".ico"),
        # PDF
        (b"%PDF", ".pdf"),
        # SVG (XML-based, check for svg tag)
        (b"<?xml", ".svg"),  # Needs secondary check for <svg
        (b"<svg", ".svg"),
    ]

    for magic, ext in signatures:
        if data.startswith(magic):
            # Special case: RIFF could be WEBP or other formats
            if magic == b"RIFF" and len(data) >= 12:
                if data[8:12] == b"WEBP":
                    return ".webp"
                continue  # Not WEBP, skip
            # Special case: XML could be SVG or other XML
            if magic == b"<?xml":
                if b"<svg" in data[:1000]:
                    return ".svg"
                return ".xml"
            return ext

    return ""


def _download_attachments(
    client: DynamicsClient,
    incidents: list[dict[str, Any]],
    save_dir: Path,
    ctx: "DxsContext",
) -> list[dict[str, Any]]:
    """Download all attachments from incident descriptions.

    Downloads attachments and updates incident descriptions in-place to
    replace API URLs with local file paths.

    Args:
        client: DynamicsClient instance for API calls.
        incidents: List of formatted incidents with markdown descriptions.
            Modified in-place to update description URLs.
        save_dir: Directory to save attachments.
        ctx: CLI context for logging.

    Returns:
        List of dicts with 'uuid', 'case_id', 'path' for each downloaded file.
    """
    downloaded = []

    for incident in incidents:
        description = incident.get("description")
        if not description:
            continue

        # Handle LiteralString or regular string
        desc_str = str(description)
        attachments = _extract_attachment_urls(desc_str)

        if not attachments:
            continue

        # Track URL to path mappings for this incident
        url_to_path: dict[str, str] = {}

        for attachment in attachments:
            uuid = attachment["uuid"]
            url = attachment["url"]

            try:
                ctx.debug(f"Downloading attachment {uuid}...")
                blob_data = client.download_blob(url)
                ext = _detect_file_extension(blob_data)
                file_path = save_dir / f"{uuid}{ext}"
                file_path.write_bytes(blob_data)
                downloaded.append(
                    {
                        "uuid": uuid,
                        "case_id": incident.get("id"),
                        "ticketnumber": incident.get("ticketnumber"),
                        "path": str(file_path),
                        "size": len(blob_data),
                    }
                )
                # Map original URL to local path
                url_to_path[url] = str(file_path)
                ctx.debug(f"Saved attachment to: {file_path}")
            except Exception as e:
                ctx.log(f"Warning: Failed to download attachment {uuid}: {e}")

        # Update incident description with local paths
        if url_to_path:
            incident["description"] = _replace_attachment_urls(incident["description"], url_to_path)

    return downloaded


def _html_to_markdown(html: str | None) -> str | LiteralString | None:
    """Convert HTML content to Markdown.

    Args:
        html: HTML string to convert.

    Returns:
        Markdown string (LiteralString for multiline), or None if input was None/empty.
    """
    if not html:
        return None

    # Convert HTML to Markdown, stripping script/style tags
    markdown = md(html, strip=["script", "style"]).strip()

    # Use LiteralString for multiline content (renders as YAML block scalar)
    # LiteralString automatically handles trailing whitespace cleanup
    if "\n" in markdown:
        return LiteralString(markdown)

    return markdown


# =============================================================================
# HTML → plain text stripping (for compact activity output)
# =============================================================================

_IMG_TAG_PATTERN = re.compile(r"<img[^>]*>", re.IGNORECASE | re.DOTALL)
_BASE64_PATTERN = re.compile(r"data:[^;]+;base64,[A-Za-z0-9+/=]+", re.IGNORECASE)

# Invisible Unicode characters used by email tracking services
_INVISIBLE_CHARS_PATTERN = re.compile(
    "[\u200b\u200c\u200d\u200e\u200f"  # ZWSP, ZWNJ, ZWJ, directional marks
    "\u00ad"  # Soft hyphen
    "\ufeff"  # BOM / ZWNBS
    "\u2060\u2061\u2062\u2063\u2064"  # Word joiner, invisible operators
    "\u180e"  # Mongolian vowel separator
    "\ufff9\ufffa\ufffb"  # Interlinear annotations
    "]+"
)

# HTML-level reply markers (most reliable — structural markers from mail clients)
_REPLY_HTML_PATTERNS = [
    # Outlook: <div id="divRplyFwdMsg"> or <div id="x_divRplyFwdMsg">
    re.compile(r'<div[^>]*\bid=["\']x?_?divRplyFwdMsg["\']', re.IGNORECASE),
    # Gmail: <div class="gmail_quote">
    re.compile(r'<div[^>]*\bclass=["\'][^"\']*gmail_quote', re.IGNORECASE),
    # Apple Mail: <blockquote type="cite">
    re.compile(r'<blockquote[^>]*\btype=["\']cite["\']', re.IGNORECASE),
    # Outlook web: <hr> followed by From: header
    re.compile(r"<hr\b[^>]*/?\s*>\s*(?:<[^>]+>\s*)*(?:<b>)?\s*From:", re.IGNORECASE),
]

# Text-level reply markers (fallback after HTML→text conversion)
_REPLY_TEXT_PATTERNS = [
    re.compile(r"-{5,}\s*Original Message\s*-{5,}", re.IGNORECASE),
    re.compile(r"-{5,}\s*Forwarded message\s*-{5,}", re.IGNORECASE),
    re.compile(r"^From:\s+.+\nSent:\s+", re.IGNORECASE | re.MULTILINE),
]


def _strip_reply_html(html: str) -> str:
    """Truncate HTML at the first reply/forward marker."""
    earliest = len(html)
    for pattern in _REPLY_HTML_PATTERNS:
        m = pattern.search(html)
        if m and m.start() < earliest:
            earliest = m.start()
    return html[:earliest]


def _strip_reply_text(text: str) -> str:
    """Truncate plain text at the first reply/forward marker."""
    earliest = len(text)
    for pattern in _REPLY_TEXT_PATTERNS:
        m = pattern.search(text)
        if m and m.start() < earliest:
            earliest = m.start()
    return text[:earliest]


# Block-level elements that should introduce whitespace
_BLOCK_TAGS = frozenset(
    {"p", "div", "br", "li", "ul", "ol", "h1", "h2", "h3", "h4", "h5", "h6", "tr", "blockquote"}
)


class _HTMLTextExtractor(HTMLParser):
    """HTMLParser subclass that extracts plain text from HTML."""

    def __init__(self) -> None:
        super().__init__()
        self._pieces: list[str] = []
        self._skip = False

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        tag_lower = tag.lower()
        if tag_lower in ("script", "style"):
            self._skip = True
        elif tag_lower in _BLOCK_TAGS:
            self._pieces.append(" ")

    def handle_endtag(self, tag: str) -> None:
        if tag.lower() in ("script", "style"):
            self._skip = False

    def handle_data(self, data: str) -> None:
        if not self._skip:
            self._pieces.append(data)

    def handle_entityref(self, name: str) -> None:
        from html import unescape

        self._pieces.append(unescape(f"&{name};"))

    def handle_charref(self, name: str) -> None:
        from html import unescape

        self._pieces.append(unescape(f"&#{name};"))

    def get_text(self) -> str:
        return "".join(self._pieces)


def _strip_html_to_text(
    html: str | None, max_length: int = 300, strip_replies: bool = False
) -> str | None:
    """Strip HTML to plain text for compact activity output.

    Unlike _html_to_markdown() which produces rich markdown, this strips ALL
    HTML to plain text (single-line) for token-efficient sentiment scanning.

    Args:
        html: HTML string to strip.
        max_length: Maximum output length (0 = unlimited). Truncates with "...".
        strip_replies: If True, remove quoted reply chains from the output.

    Returns:
        Plain text string, or None if input was None/empty.
    """
    if not html:
        return None

    # Strip reply chains at the HTML level (before losing structural markers)
    if strip_replies:
        html = _strip_reply_html(html)

    # Replace <img> tags with [image] placeholder
    text = _IMG_TAG_PATTERN.sub("[image]", html)

    # Replace base64 data URIs with [image] placeholder
    text = _BASE64_PATTERN.sub("[image]", text)

    # Parse remaining HTML to extract text
    extractor = _HTMLTextExtractor()
    extractor.feed(text)
    result = extractor.get_text()

    # Collapse whitespace to single spaces
    result = re.sub(r"\s+", " ", result).strip()

    # Strip invisible Unicode characters (tracking fingerprints, ZWJ, etc.)
    result = _INVISIBLE_CHARS_PATTERN.sub("", result)

    # Text-level reply stripping as fallback
    if strip_replies:
        result = _strip_reply_text(result).strip()

    # Truncate if needed
    if max_length > 0 and len(result) > max_length:
        result = result[:max_length] + "..."

    return result or None


def _auto_paginate(
    client: DynamicsClient, initial_result: dict[str, Any], ctx: "DxsContext"
) -> list[dict[str, Any]]:
    """Follow @odata.nextLink pagination until all records are fetched.

    Args:
        client: DynamicsClient instance.
        initial_result: First-page result dict with 'value' and optionally '@odata.nextLink'.
        ctx: DxsContext for logging progress.

    Returns:
        Combined list of all records across all pages.
    """
    all_records: list[dict[str, Any]] = list(initial_result.get("value", []))
    total_count = initial_result.get("@odata.count", len(all_records))
    result = initial_result

    while "@odata.nextLink" in result:
        ctx.log(f"Fetching next page ({len(all_records)} of {total_count} records)...")
        result = client.get_by_next_link(result["@odata.nextLink"])
        all_records.extend(result.get("value", []))

    return all_records


def _format_incident(incident: dict[str, Any]) -> dict[str, Any]:
    """Format a raw incident from Dynamics CRM for display.

    Args:
        incident: Raw incident data from Dynamics CRM API.

    Returns:
        Formatted incident dictionary.
    """
    # Get customer name from expanded relationship
    customer_name = None
    if incident.get("customerid_account"):
        customer_name = incident["customerid_account"].get("name")
    elif incident.get("customerid_contact"):
        customer_name = incident["customerid_contact"].get("fullname")

    # Get owner name from OData annotation (formatted value for lookup)
    owner_name = incident.get("_ownerid_value@OData.Community.Display.V1.FormattedValue")

    # Get human-readable labels from OData annotations for picklist fields
    priority_label = incident.get("prioritycode@OData.Community.Display.V1.FormattedValue")
    severity_label = incident.get("severitycode@OData.Community.Display.V1.FormattedValue")
    business_impact_label = incident.get(
        "daa_immediatebusinessimpact@OData.Community.Display.V1.FormattedValue"
    )
    case_type_label = incident.get("casetypecode@OData.Community.Display.V1.FormattedValue")

    # Get status label
    statecode = incident.get("statecode", 0)
    status_label = _CASE_STATUS_LABELS.get(statecode, f"Unknown ({statecode})")

    # Convert HTML description to Markdown
    description = _html_to_markdown(incident.get("description"))

    # Resolution text (may contain HTML)
    resolution = _html_to_markdown(incident.get("adx_resolution"))

    result = {
        "id": incident.get("incidentid"),
        "ticketnumber": incident.get("ticketnumber"),
        "title": incident.get("title"),
        "description": description,
        "status": status_label,
        "case_type": case_type_label,
        "statecode": statecode,
        "priority": priority_label,
        "severity": severity_label,
        "business_impact": business_impact_label,
        "owner": owner_name,
        "customer": customer_name,
        "customer_id": incident.get("_customerid_value"),
        "is_escalated": incident.get("isescalated"),
        "escalated_on": incident.get("escalatedon"),
        "resolve_by": incident.get("resolveby"),
        "response_by": incident.get("responseby"),
        "resolution": resolution,
        "resolution_date": incident.get("adx_resolutiondate"),
        "created": incident.get("createdon"),
        "modified": incident.get("modifiedon"),
    }

    # Include notes if present (from $expand)
    annotations = incident.get("Incident_Annotation", [])
    if annotations:
        result["notes"] = [_format_annotation(ann) for ann in annotations]

    return result


def _format_annotation(annotation: dict[str, Any]) -> dict[str, Any]:
    """Format a raw annotation from Dynamics CRM for display.

    Args:
        annotation: Raw annotation data from Dynamics CRM API.

    Returns:
        Formatted annotation dictionary.
    """
    note_text = annotation.get("notetext") or ""

    # Convert HTML to markdown if present
    if note_text and ("<" in note_text or "&" in note_text):
        note_text = _html_to_markdown(note_text)

    # Use LiteralString for multiline content
    if note_text and "\n" in note_text:
        note_text = LiteralString(note_text)

    # The OData annotation response may include the formatted value for lookups
    # Check for the OData annotation (@OData.Community.Display.V1.FormattedValue)
    author = annotation.get("_createdby_value@OData.Community.Display.V1.FormattedValue")
    if not author:
        # Fall back to looking up ID if formatted value not available
        author = annotation.get("_createdby_value")

    result: dict[str, Any] = {
        "id": annotation.get("annotationid"),
        "subject": annotation.get("subject"),
        "text": note_text,
        "author": author,
        "created": annotation.get("createdon"),
    }

    # Include attachment info if present
    if annotation.get("filename"):
        result["attachment"] = {
            "filename": annotation.get("filename"),
            "mimetype": annotation.get("mimetype"),
            "filesize": annotation.get("filesize"),
        }

    return result


@click.group()
def crm() -> None:
    """Dynamics CRM / Dataverse commands.

    Query support cases, accounts, and activities - or run raw OData against
    any Dataverse entity.

    \b
    Setup (one-time):
        dxs config set dynamics_crm_url https://yourorg.crm.dynamics.com
        dxs auth login        # grant Dynamics CRM consent

    \b
    Pick a command:
        case       Support cases (incidents): search, get, query, types
        account    Accounts (companies): list, search
        activity   Portal comments & emails - by date range or ticket
        metadata   Discover entities, fields, and relationships
        picklist   Resolve option-set (picklist) integer values <-> labels
        odata      Raw OData against ANY entity (escape hatch)

    \b
    Exploring an unfamiliar org/entity? Discover schema before you query:
        1. dxs crm metadata entities --search <keyword>   # find the entity
        2. dxs crm metadata <entity>  --search <keyword>  # find field names
        3. dxs crm picklist <entity> <field>              # enum values for filters
        4. dxs crm odata <entity> -f "<filter>" --count-only   # size it first
        5. dxs crm odata <entity> -f "<filter>" -s "<fields>" --limit 25

    \b
    Working efficiently (keeps responses small - matters for agents):
        - Prefer case/account/activity over odata: they pre-select fields
          and format output (HTML->markdown, lookups resolved).
        - WITHOUT --limit, queries auto-paginate and return ALL matching
          rows. Set --limit, or run --count-only first to size the result.
        - Always narrow odata with -f/--filter and -s/--select.
        - metadata is capped at 10 rows; use --search/--skip, not blind dumps.
        - Output is concise by default; pass global --full only when needed.
    """
    pass


@click.group()
def case() -> None:
    """Support case (incident) commands.

    Search and read support cases. These helpers pre-select sensible fields
    and convert HTML descriptions/notes to markdown - prefer them over
    'dxs crm odata incidents' for everyday case work.

    \b
    Subcommands:
        search  Find cases by text, account, status, date, or type
        get     Fetch one case by ticket number (+ activity / notes)
        query   Custom OData over incidents (full field control)
        types   List case-type picklist values

    \b
    Examples:
        dxs crm case get C260303_0017                      # Get single case
        dxs crm case get C260303_0017 --include-activity   # With comments & emails
        dxs crm case search "shipping"                     # Search all cases
        dxs crm case search "CAS-001"                      # Search by case number
        dxs crm case search --status active --limit 25     # Cap the result
        dxs crm case search --account "Contoso" --count-only   # Size before fetching
    """
    pass


# Register case as subcommand of crm
crm.add_command(case)


@case.command()
@click.argument("query", required=False, default=None)
@click.option(
    "--status",
    type=click.Choice(["active", "resolved", "cancelled", "all"], case_sensitive=False),
    default="all",
    help="Filter by case status (default: all)",
)
@click.option(
    "--account",
    "-a",
    type=str,
    default=None,
    help="Filter by account name (partial match)",
)
@click.option(
    "--since",
    type=str,
    default=None,
    help="Filter to cases created on or after this date (YYYY-MM-DD)",
)
@click.option(
    "--type",
    "case_type",
    type=int,
    default=None,
    help="Filter by case type code (use 'dxs crm case types' to see values)",
)
@click.option(
    "--limit",
    "-l",
    type=int,
    default=None,
    help="Limit to N records (no auto-pagination)",
)
@click.option(
    "--batch-size",
    type=int,
    default=None,
    help="Page size for auto-pagination (default: 500)",
)
@click.option(
    "--count-only",
    is_flag=True,
    default=False,
    help="Return only the count, no records",
)
@click.option(
    "--save-attachments",
    type=click.Path(file_okay=False, path_type=Path),
    default=None,
    help="Download attachments to specified directory (requires --save)",
)
@click.option(
    "--include-notes",
    is_flag=True,
    default=False,
    help="Include notes/annotations for each case in the output.",
)
@click.pass_obj
@require_auth
def search(
    ctx: "DxsContext",
    query: str | None,
    status: str,
    account: str | None,
    since: str | None,
    case_type: int | None,
    limit: int | None,
    batch_size: int | None,
    count_only: bool,
    save_attachments: Path | None,
    include_notes: bool,
) -> None:
    """Search for support cases in Dynamics CRM.

    Searches case number, title, and description fields. Results are ordered
    by most recently modified.

    By default, retrieves ALL matching records using automatic pagination
    with a batch size of 500. Use --limit to get only a specific number
    of records without pagination.

    \b
    Arguments:
        QUERY  Optional search text (searches case number, title, description)

    \b
    Examples:
        dxs crm case search "shipping delay"
        dxs crm case search --account "Crane Worldwide" --since 2025-01-01
        dxs crm case search --status active --limit 50    # First 50 only
        dxs crm case search --account "Contoso" --batch-size 100
        dxs crm case search --account "Crane" --count-only
        dxs crm case search --account "Crane" --save cases.yaml
    """
    client = DynamicsClient()

    # Normalize status
    status_filter = None if status == "all" else status

    if query:
        ctx.log(f"Searching cases for '{query}'...")
    else:
        ctx.log("Fetching cases...")

    if status_filter:
        ctx.log(f"Filtering by status: {status_filter}")
    if account:
        ctx.log(f"Filtering by account: {account}")
    if since:
        ctx.log(f"Filtering by created date >= {since}")
    if case_type is not None:
        ctx.log(f"Filtering by case type: {case_type}")

    # Count-only mode: just get the count
    if count_only:
        result = client.search_incidents(
            query=query,
            status=status_filter,
            account=account,
            since=since,
            case_type=case_type,
            limit=1,  # Minimal data, we just want the count
        )
        total = result.get("@odata.count", 0)
        ctx.output(
            count_response(
                total_count=total,
                semantic_key="cases",
                status_filter=status_filter,
                account_filter=account,
                since_filter=since,
                case_type_filter=case_type,
            )
        )
        return

    if limit:
        # Single request, no pagination
        result = client.search_incidents(
            query=query,
            status=status_filter,
            account=account,
            since=since,
            case_type=case_type,
            limit=limit,
            include_notes=include_notes,
        )
        raw_incidents = result.get("value", [])
        total_count = result.get("@odata.count", len(raw_incidents))
    else:
        # Auto-pagination: fetch all records
        page_size = batch_size or 500
        all_incidents: list[dict] = []

        result = client.search_incidents(
            query=query,
            status=status_filter,
            account=account,
            since=since,
            case_type=case_type,
            limit=page_size,
            include_notes=include_notes,
        )
        all_incidents.extend(result.get("value", []))
        total_count = result.get("@odata.count", len(all_incidents))

        # Follow @odata.nextLink until all records are fetched
        while "@odata.nextLink" in result:
            ctx.log(f"Fetching next page ({len(all_incidents)} of {total_count} records)...")
            result = client.get_by_next_link(result["@odata.nextLink"])
            all_incidents.extend(result.get("value", []))

        raw_incidents = all_incidents

    # Format incidents for display
    incidents = [_format_incident(inc) for inc in raw_incidents]

    # Download attachments if requested
    attachments_downloaded = []
    if save_attachments:
        check_restricted_mode_for_option("--save-attachments", "downloads files to the filesystem")
        if not ctx.save_path:
            from dxs.utils.errors import ValidationError

            raise ValidationError(
                message="--save-attachments requires --save to be specified",
                code="DXS-CRM-001",
                suggestions=[
                    "Add --save <filepath> to save output and attachments",
                    "Example: dxs --save cases.yaml crm case search --save-attachments ./attachments",
                ],
            )

        # Create attachments directory
        save_attachments.mkdir(parents=True, exist_ok=True)
        ctx.log(f"Downloading attachments to: {save_attachments}")

        attachments_downloaded = _download_attachments(client, incidents, save_attachments, ctx)

        if attachments_downloaded:
            ctx.log(f"Downloaded {len(attachments_downloaded)} attachment(s)")

    # Build search response
    response_kwargs = {
        "items": incidents,
        "query": query or "(all)",
        "total_count": total_count,
        "semantic_key": "cases",
        "status_filter": status_filter,
        "account_filter": account,
        "since_filter": since,
        "case_type_filter": case_type,
    }

    # Include attachment metadata if any were downloaded
    if attachments_downloaded:
        response_kwargs["attachments"] = attachments_downloaded

    ctx.output(search_response(**response_kwargs))


@case.command("types")
@click.pass_obj
@require_auth
def case_types(ctx: "DxsContext") -> None:
    """List available case type values.

    Shows the picklist options for the case type field (casetypecode)
    on the incident entity. Use the 'value' number with --type on
    the search command to filter by case type.

    \b
    Examples:
        dxs crm case types
        dxs crm case search --type 1    # Filter using a value from types list
    """
    client = DynamicsClient()
    ctx.log("Fetching case type picklist values...")
    options = client.get_picklist_options("incident", "casetypecode")
    ctx.output(list_response(items=options, semantic_key="case_types"))


@case.command("get")
@click.argument("ticket_number")
@click.option(
    "--include-activity",
    is_flag=True,
    default=False,
    help="Include portal comments and emails for this case.",
)
@click.option(
    "--include-notes",
    is_flag=True,
    default=False,
    help="Include notes/annotations for the case.",
)
@click.pass_obj
@require_auth
def case_get(
    ctx: "DxsContext",
    ticket_number: str,
    include_activity: bool,
    include_notes: bool,
) -> None:
    """Get a single support case by ticket number.

    Fetches the full case record by exact ticket number match. Optionally
    includes all portal comments and emails (--include-activity) and/or
    notes (--include-notes) in a single response.

    \b
    Arguments:
        TICKET_NUMBER  Case ticket number (e.g. C260303_0017)

    \b
    Examples:
        dxs crm case get C260303_0017
        dxs crm case get C260303_0017 --include-activity
        dxs crm case get C260303_0017 --include-activity --include-notes
    """
    client = DynamicsClient()

    ctx.log(f"Fetching case {ticket_number}...")
    raw_incident = client.get_incident_by_ticket(
        ticket_number,
        include_notes=include_notes,
    )
    item = _format_incident(raw_incident)

    if include_activity:
        incident_id = raw_incident["incidentid"]

        # Fetch portal comments (auto-paginate)
        ctx.log("Fetching portal comments...")
        pc_result = client.query_portal_comments_by_incident(incident_id, limit=500)
        raw_comments = _auto_paginate(client, pc_result, ctx)

        # Fetch emails (auto-paginate)
        ctx.log("Fetching emails...")
        email_result = client.query_emails_by_incident(incident_id, limit=500)
        raw_emails = _auto_paginate(client, email_result, ctx)

        item["portal_comments"] = [
            _format_portal_comment(r, 300, strip_replies=True) for r in raw_comments
        ]
        item["emails"] = [_format_email(r, 300, strip_replies=True) for r in raw_emails]
        item["activity_summary"] = {
            "portal_comments": len(raw_comments),
            "emails": len(raw_emails),
        }

    ctx.output(single(item, semantic_key="case"))


@case.command()
@click.option(
    "--select",
    type=str,
    default=None,
    help="OData $select - comma-separated field names to return",
)
@click.option(
    "--filter",
    "-f",
    type=str,
    default=None,
    help='OData $filter - filter expression (e.g., "statecode eq 0")',
)
@click.option(
    "--orderby",
    type=str,
    default=None,
    help='OData $orderby - sort expression (e.g., "modifiedon desc")',
)
@click.option(
    "--expand",
    type=str,
    default=None,
    help="OData $expand - related entities to include",
)
@click.option(
    "--limit",
    "-l",
    type=int,
    default=None,
    help="Limit to N records (no auto-pagination)",
)
@click.option(
    "--batch-size",
    type=int,
    default=None,
    help="Page size for auto-pagination (default: 500)",
)
@click.option(
    "--count-only",
    is_flag=True,
    default=False,
    help="Return only the count, no records",
)
@click.option(
    "--save-attachments",
    type=click.Path(file_okay=False, path_type=Path),
    default=None,
    help="Download attachments to specified directory (requires --save)",
)
@click.pass_obj
@require_auth
def query(
    ctx: "DxsContext",
    select: str | None,
    filter: str | None,
    orderby: str | None,
    expand: str | None,
    limit: int | None,
    batch_size: int | None,
    count_only: bool,
    save_attachments: Path | None,
) -> None:
    """Execute a custom OData query against cases.

    Provides full control over OData query parameters for AI-constructed queries.
    Use 'dxs crm metadata incident' to see available field names.

    By default, retrieves ALL matching records using automatic pagination
    with a batch size of 500. Use --limit to get only a specific number
    of records without pagination.

    \b
    OData Filter Operators:
        eq, ne, gt, ge, lt, le    Comparison
        and, or, not              Logical
        contains(), startswith(), endswith()  String functions

    \b
    Examples:
        dxs crm case query -s "ticketnumber,title" -f "statecode eq 0" --limit 10

        dxs crm case query -s "ticketnumber,title,prioritycode" \\
          -f "contains(title,'shipping') and statecode eq 0" \\
          -o "modifiedon desc"

        dxs crm case query -f "statecode eq 0" --count-only
    """
    client = DynamicsClient()

    ctx.log("Executing OData query...")
    if filter:
        ctx.log(f"Filter: {filter}")

    # Count-only mode: just get the count
    if count_only:
        result = client.query_incidents(
            select=select,
            filter=filter,
            orderby=orderby,
            expand=expand,
            top=1,
        )
        total = result.get("@odata.count", 0)
        ctx.output(count_response(total_count=total, semantic_key="cases"))
        return

    if limit:
        # Single request, no pagination
        result = client.query_incidents(
            select=select,
            filter=filter,
            orderby=orderby,
            expand=expand,
            top=limit,
        )
        raw_cases = result.get("value", [])
    else:
        # Auto-pagination: fetch all records
        page_size = batch_size or 500
        all_cases: list[dict] = []

        result = client.query_incidents(
            select=select,
            filter=filter,
            orderby=orderby,
            expand=expand,
            top=page_size,
        )
        all_cases.extend(result.get("value", []))
        total_count = result.get("@odata.count", len(all_cases))

        # Follow @odata.nextLink until all records are fetched
        while "@odata.nextLink" in result:
            ctx.log(f"Fetching next page ({len(all_cases)} of {total_count} records)...")
            result = client.get_by_next_link(result["@odata.nextLink"])
            all_cases.extend(result.get("value", []))

        raw_cases = all_cases

    # Light formatting: convert description HTML to markdown if present
    formatted_cases = []
    for case_data in raw_cases:
        formatted = dict(case_data)  # Copy the raw data

        # Convert description if present
        if "description" in formatted and formatted["description"]:
            formatted["description"] = _html_to_markdown(formatted["description"])

        formatted_cases.append(formatted)

    # Download attachments if requested
    attachments_downloaded = []
    if save_attachments:
        check_restricted_mode_for_option("--save-attachments", "downloads files to the filesystem")
        if not ctx.save_path:
            from dxs.utils.errors import ValidationError

            raise ValidationError(
                message="--save-attachments requires --save to be specified",
                code="DXS-CRM-001",
                suggestions=[
                    "Add --save <filepath> to save output and attachments",
                    "Example: dxs --save cases.yaml crm case query --save-attachments ./attachments",
                ],
            )

        # Create attachments directory
        save_attachments.mkdir(parents=True, exist_ok=True)
        ctx.log(f"Downloading attachments to: {save_attachments}")

        attachments_downloaded = _download_attachments(
            client, formatted_cases, save_attachments, ctx
        )

        if attachments_downloaded:
            ctx.log(f"Downloaded {len(attachments_downloaded)} attachment(s)")

    # Build response
    if attachments_downloaded:
        ctx.output(
            list_response(
                items=formatted_cases, semantic_key="cases", attachments=attachments_downloaded
            )
        )
    else:
        ctx.output(list_response(items=formatted_cases, semantic_key="cases"))


# =============================================================================
# Account Commands
# =============================================================================


def _format_account(account: dict[str, Any]) -> dict[str, Any]:
    """Format a raw account from Dynamics CRM for display.

    Args:
        account: Raw account data from Dynamics CRM API.

    Returns:
        Formatted account dictionary.
    """
    # Build location string
    city = account.get("address1_city")
    state = account.get("address1_stateorprovince")
    location = None
    if city and state:
        location = f"{city}, {state}"
    elif city:
        location = city
    elif state:
        location = state

    return {
        "id": account.get("accountid"),
        "name": account.get("name"),
        "account_number": account.get("accountnumber"),
        "phone": account.get("telephone1"),
        "email": account.get("emailaddress1"),
        "location": location,
        "created": account.get("createdon"),
        "modified": account.get("modifiedon"),
    }


@click.group()
def account() -> None:
    """Account (company) commands.

    List and search accounts. Returns active accounts with a curated field
    set; for other account fields drop down to 'dxs crm odata accounts'.

    \b
    Examples:
        dxs crm account list --limit 25       # First 25 (omit --limit = ALL)
        dxs crm account search "Contoso"      # Search by name
        dxs crm account search "Texas" -l 10  # Search with limit
        dxs crm account list --count-only     # Just the count
    """
    pass


# Register account as subcommand of crm
crm.add_command(account)


@account.command("list")
@click.option(
    "--limit",
    "-l",
    type=int,
    default=None,
    help="Limit to N records (no auto-pagination)",
)
@click.option(
    "--batch-size",
    "-B",
    type=int,
    default=None,
    help="Page size for auto-pagination (default: 500)",
)
@click.option(
    "--count-only",
    is_flag=True,
    default=False,
    help="Return only the count, no records",
)
@click.pass_obj
@require_auth
def account_list(
    ctx: "DxsContext", limit: int | None, batch_size: int | None, count_only: bool
) -> None:
    """List accounts in Dynamics CRM.

    Returns active accounts ordered by name.

    By default, retrieves ALL accounts using automatic pagination
    with a batch size of 500. Use --limit to get only a specific number
    of records without pagination.

    \b
    Examples:
        dxs crm account list
        dxs crm account list --limit 100
        dxs crm account list --count-only
    """
    client = DynamicsClient()

    ctx.log("Fetching accounts...")

    # Count-only mode
    if count_only:
        result = client.list_accounts(limit=1)
        total = result.get("@odata.count", 0)
        ctx.output(count_response(total_count=total, semantic_key="accounts"))
        return

    if limit:
        # Single request, no pagination
        result = client.list_accounts(limit=limit)
        raw_accounts = result.get("value", [])
    else:
        # Auto-pagination: fetch all records
        page_size = batch_size or 500
        all_accounts: list[dict] = []

        result = client.list_accounts(limit=page_size)
        all_accounts.extend(result.get("value", []))
        total_count = result.get("@odata.count", len(all_accounts))

        while "@odata.nextLink" in result:
            ctx.log(f"Fetching next page ({len(all_accounts)} of {total_count} records)...")
            result = client.get_by_next_link(result["@odata.nextLink"])
            all_accounts.extend(result.get("value", []))

        raw_accounts = all_accounts

    # Format accounts for display
    accounts = [_format_account(acc) for acc in raw_accounts]

    ctx.output(list_response(items=accounts, semantic_key="accounts"))


@account.command("search")
@click.argument("query")
@click.option(
    "--limit",
    "-l",
    type=int,
    default=None,
    help="Limit to N records (no auto-pagination)",
)
@click.option(
    "--batch-size",
    "-B",
    type=int,
    default=None,
    help="Page size for auto-pagination (default: 500)",
)
@click.option(
    "--count-only",
    is_flag=True,
    default=False,
    help="Return only the count, no records",
)
@click.pass_obj
@require_auth
def account_search(
    ctx: "DxsContext", query: str, limit: int | None, batch_size: int | None, count_only: bool
) -> None:
    """Search for accounts in Dynamics CRM.

    Searches account names for the given query.

    By default, retrieves ALL matching accounts using automatic pagination
    with a batch size of 500. Use --limit to get only a specific number
    of records without pagination.

    \b
    Arguments:
        QUERY  Search text to match against account name

    \b
    Examples:
        dxs crm account search "Contoso"
        dxs crm account search "Texas" --limit 10
        dxs crm account search "Corp" --count-only
    """
    client = DynamicsClient()

    ctx.log(f"Searching accounts for '{query}'...")

    # Count-only mode
    if count_only:
        result = client.search_accounts(query=query, limit=1)
        total = result.get("@odata.count", 0)
        ctx.output(count_response(total_count=total, semantic_key="accounts"))
        return

    if limit:
        # Single request, no pagination
        result = client.search_accounts(query=query, limit=limit)
        raw_accounts = result.get("value", [])
        total_count = result.get("@odata.count", len(raw_accounts))
    else:
        # Auto-pagination: fetch all records
        page_size = batch_size or 500
        all_accounts: list[dict] = []

        result = client.search_accounts(query=query, limit=page_size)
        all_accounts.extend(result.get("value", []))
        total_count = result.get("@odata.count", len(all_accounts))

        while "@odata.nextLink" in result:
            ctx.log(f"Fetching next page ({len(all_accounts)} of {total_count} records)...")
            result = client.get_by_next_link(result["@odata.nextLink"])
            all_accounts.extend(result.get("value", []))

        raw_accounts = all_accounts

    # Format accounts for display
    accounts = [_format_account(acc) for acc in raw_accounts]

    ctx.output(
        search_response(
            items=accounts,
            query=query,
            total_count=total_count,
            semantic_key="accounts",
        )
    )


# =============================================================================
# Metadata Commands
# =============================================================================


def _get_localized_label(obj: dict[str, Any] | None) -> str | None:
    """Extract localized label from Dynamics metadata object."""
    if not obj:
        return None
    localized_labels = obj.get("LocalizedLabels", [])
    if localized_labels:
        label = localized_labels[0].get("Label")
        return str(label) if label is not None else None
    return None


# Default page size for metadata exploration. Entity catalogs and attribute
# lists are large enough to blow out an agent's context window if returned in
# full, so callers must opt into more via --limit/--skip (or --limit 0 for all).
DEFAULT_METADATA_LIMIT = 10


def _paginate_metadata(
    items: list[dict[str, Any]],
    limit: int | None,
    skip: int,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Window a metadata list by skip/limit and build pagination metadata.

    Applies ``DEFAULT_METADATA_LIMIT`` when ``limit`` is None so unbounded
    metadata listings can't flood the caller's context. ``limit <= 0`` means
    "no limit" (return everything from ``skip`` onward).

    Args:
        items: Full list of formatted metadata records (after any search filter).
        limit: Page size, or None to apply the default, or <= 0 for unlimited.
        skip: Number of records to skip from the start.

    Returns:
        Tuple of (page, metadata_kwargs). ``metadata_kwargs`` carries
        ``total_count`` (matched before windowing), ``skip``, ``limit``,
        ``has_more``, and a ``pagination_hint`` string when truncated.
    """
    effective_limit = DEFAULT_METADATA_LIMIT if limit is None else limit
    matched = len(items)
    skip = max(skip, 0)

    if effective_limit <= 0:
        page = items[skip:]
    else:
        page = items[skip : skip + effective_limit]

    end = skip + len(page)
    has_more = end < matched

    meta: dict[str, Any] = {
        "total_count": matched,
        "skip": skip,
        "limit": effective_limit if effective_limit > 0 else None,
        "has_more": has_more,
    }
    if has_more:
        meta["pagination_hint"] = (
            f"Showing {skip + 1}-{end} of {matched}. "
            f"Use --skip {end} for the next page, --limit 0 for all, "
            "or --search <text> to narrow."
        )
    return page, meta


def _list_entities(
    ctx: "DxsContext",
    search: str | None = None,
    limit: int | None = None,
    skip: int = 0,
) -> None:
    """List entity definitions in Dynamics CRM (search + paginate)."""
    client = DynamicsClient()

    ctx.log("Fetching entity definitions...")

    result = client.list_entities()

    # Extract, format, and sort entities by logical name
    raw_entities = result.get("value", [])
    raw_entities.sort(key=lambda e: e.get("LogicalName", ""))

    formatted_entities = []
    for entity in raw_entities:
        formatted_entities.append(
            {
                "name": entity.get("LogicalName"),
                "display_name": _get_localized_label(entity.get("DisplayName")),
                "description": _get_localized_label(entity.get("Description")),
                "is_custom": entity.get("IsCustomEntity"),
            }
        )

    if search:
        needle = search.lower()
        formatted_entities = [
            e
            for e in formatted_entities
            if needle in (e.get("name") or "").lower()
            or needle in (e.get("display_name") or "").lower()
            or needle in (e.get("description") or "").lower()
        ]

    page, page_meta = _paginate_metadata(formatted_entities, limit, skip)

    ctx.output(list_response(items=page, semantic_key="entities", **page_meta))


def _get_entity_fields(
    ctx: "DxsContext",
    entity_name: str,
    search: str | None = None,
    limit: int | None = None,
    skip: int = 0,
) -> None:
    """Output the field/attribute metadata for an entity (search + paginate)."""
    client = DynamicsClient()

    ctx.log(f"Fetching fields for '{entity_name}'...")

    result = client.get_entity_fields(entity_name)

    # Extract and format fields (filter to readable attributes only, sort by name)
    raw_fields = result.get("value", [])
    readable_fields = [f for f in raw_fields if f.get("IsValidForRead")]
    readable_fields.sort(key=lambda f: f.get("LogicalName", ""))

    formatted_fields = []
    for field in readable_fields:
        formatted_fields.append(
            {
                "name": field.get("LogicalName"),
                "display_name": _get_localized_label(field.get("DisplayName")),
                "type": field.get("AttributeType"),
                "description": _get_localized_label(field.get("Description")),
            }
        )

    if search:
        needle = search.lower()
        formatted_fields = [
            f
            for f in formatted_fields
            if needle in (f.get("name") or "").lower()
            or needle in (f.get("display_name") or "").lower()
            or needle in (f.get("description") or "").lower()
        ]

    field_page, field_meta = _paginate_metadata(formatted_fields, limit, skip)
    ctx.output(list_response(items=field_page, semantic_key="fields", **field_meta))


def _get_entity_relationships(
    ctx: "DxsContext",
    entity_name: str,
    search: str | None = None,
    limit: int | None = None,
    skip: int = 0,
) -> None:
    """Output ONLY the relationship metadata for an entity (search + paginate).

    Relationships are returned on their own — fields are not mixed in — so the
    output (and skip/limit windowing) stays unambiguous.
    """
    client = DynamicsClient()

    ctx.log(f"Fetching relationships for '{entity_name}'...")
    rels = client.get_entity_relationships(entity_name)

    formatted_relationships = []

    # Format ManyToOne relationships (lookups - this entity references another)
    for rel in rels.get("many_to_one", []):
        formatted_relationships.append(
            {
                "name": rel.get("ReferencingAttribute"),
                "schema_name": rel.get("SchemaName"),
                "target_entity": rel.get("ReferencedEntity"),
                "target_attribute": rel.get("ReferencedAttribute"),
                "type": "ManyToOne",
            }
        )

    # Format OneToMany relationships (this entity is referenced by others)
    for rel in rels.get("one_to_many", []):
        formatted_relationships.append(
            {
                "name": rel.get("SchemaName"),
                "referencing_entity": rel.get("ReferencingEntity"),
                "referencing_attribute": rel.get("ReferencingAttribute"),
                "type": "OneToMany",
            }
        )

    if search:
        needle = search.lower()
        formatted_relationships = [
            r
            for r in formatted_relationships
            if any(
                needle in (r.get(k) or "").lower()
                for k in (
                    "name",
                    "schema_name",
                    "target_entity",
                    "referencing_entity",
                    "referencing_attribute",
                )
            )
        ]

    rel_page, rel_meta = _paginate_metadata(formatted_relationships, limit, skip)
    ctx.output(list_response(items=rel_page, semantic_key="relationships", **rel_meta))


@click.command("metadata")
@click.argument("entity_name", required=False, default=None)
@click.option(
    "--relationships",
    "-r",
    is_flag=True,
    default=False,
    help="Return ONLY the entity's relationships (navigation properties) "
    "instead of its fields. Requires a specific entity (not 'entities').",
)
@click.option(
    "--search",
    "-S",
    type=str,
    default=None,
    help="Filter entities/fields/relationships by case-insensitive substring "
    "match on name, display_name, or description.",
)
@click.option(
    "--limit",
    "-l",
    type=int,
    default=None,
    help=f"Max records to return (default: {DEFAULT_METADATA_LIMIT}). Use 0 for no limit.",
)
@click.option(
    "--skip",
    type=int,
    default=0,
    help="Number of records to skip (for paging past the default limit).",
)
@click.pass_obj
@require_auth
def metadata(
    ctx: "DxsContext",
    entity_name: str | None,
    relationships: bool,
    search: str | None,
    limit: int | None,
    skip: int,
) -> None:
    """Entity metadata exploration.

    Explore Dynamics CRM entity definitions, fields, and relationships.
    Useful for understanding the data model and constructing OData queries.

    Use "entities" as the argument to list all available entities.
    Use any other entity name to show its fields, or add --relationships to
    show its relationships instead. Fields and relationships are never mixed
    in one response.

    Results are capped at 10 records by default to protect your context
    window. Narrow with --search, page with --skip, or pass --limit 0 to
    return everything. The response metadata reports total_count, has_more,
    and a pagination_hint when results are truncated.

    \b
    Arguments:
        ENTITY_NAME  "entities" to list all, or an entity name (e.g., "incident")

    \b
    Examples:
        dxs crm metadata entities                    # First 10 entities
        dxs crm metadata entities --search shipment  # Find entities by keyword
        dxs crm metadata entities --skip 10          # Next page of entities
        dxs crm metadata incident                    # First 10 fields for cases
        dxs crm metadata incident --limit 0          # ALL fields (no cap)
        dxs crm metadata incident --relationships    # ONLY relationships (not fields)
        dxs crm metadata incident -r                 # Short form
        dxs crm metadata incident --search priority  # Filter fields by keyword
    """
    if entity_name is None:
        # Show help if no argument provided
        click.echo(click.get_current_context().get_help())
        return

    if entity_name == "entities":
        if relationships:
            from dxs.utils.errors import ValidationError

            raise ValidationError(
                message="--relationships requires a specific entity, not 'entities'.",
                code="DXS-CRM-002",
                suggestions=[
                    "List entities first: dxs crm metadata entities --search <keyword>",
                    "Then inspect one entity's relationships: "
                    "dxs crm metadata <entity> --relationships",
                ],
            )
        # Special case: list all entities
        _list_entities(ctx, search=search, limit=limit, skip=skip)
    elif relationships:
        # Show ONLY relationships for the specified entity (fields not mixed in)
        _get_entity_relationships(ctx, entity_name, search=search, limit=limit, skip=skip)
    else:
        # Show fields for the specified entity
        _get_entity_fields(ctx, entity_name, search=search, limit=limit, skip=skip)


# Register metadata as subcommand of crm
crm.add_command(metadata)


@click.command("picklist")
@click.argument("entity_name")
@click.argument("attribute_name")
@click.pass_obj
@require_auth
def picklist(ctx: "DxsContext", entity_name: str, attribute_name: str) -> None:
    """Show option set (picklist) values for an entity attribute.

    Lists the integer values and labels for a picklist/state/status field -
    use these numbers when building OData --filter expressions (e.g.
    'statecode eq 0'). Picklist fields are usually suffixed 'code'; find
    candidates with 'dxs crm metadata <entity> --search code'.

    \b
    Examples:
        dxs crm picklist incident statuscode
        dxs crm picklist salesorder statuscode
        dxs crm picklist incident prioritycode
    """
    from dxs.utils.errors import ApiError

    client = DynamicsClient()
    ctx.log(f"Fetching picklist options for {entity_name}.{attribute_name}...")
    try:
        options = client.get_picklist_options(entity_name, attribute_name)
    except (KeyError, TypeError) as exc:
        raise ApiError(
            message=(
                f"'{attribute_name}' on '{entity_name}' is not a picklist attribute "
                "(no OptionSet present in the response)."
            ),
            code="DXS-DYNAMICS-NOT-PICKLIST",
            suggestions=[
                f"Run 'dxs crm metadata {entity_name} --search {attribute_name}' "
                "to inspect the field's actual type.",
                "Picklist fields are typically suffixed 'code' (e.g., statuscode, casetypecode).",
            ],
        ) from exc
    ctx.output(list_response(items=options, semantic_key=f"{attribute_name}_options"))


# Register picklist as subcommand of crm
crm.add_command(picklist)


# =============================================================================
# Activity Commands (portal comments, emails)
# =============================================================================


def _format_portal_comment(
    record: dict[str, Any],
    max_description_length: int,
    strip_replies: bool = False,
) -> dict[str, Any]:
    """Format a raw portal comment record for display.

    Args:
        record: Raw portal comment from Dynamics CRM API.
        max_description_length: Max length for description text (0=unlimited).
        strip_replies: If True, remove quoted reply chains from description.

    Returns:
        Formatted portal comment dictionary.
    """
    # Use the lookuplogicalname annotation to verify the regarding entity is
    # an incident before resolving the ticket number.  The $expand on
    # regardingobjectid_incident can be unreliable, and the OData formatted-
    # value annotation returns the display name of *any* entity type (invoice,
    # sales order, etc.) which would leak non-case identifiers as ticket numbers.
    entity_type = record.get("_regardingobjectid_value@Microsoft.Dynamics.CRM.lookuplogicalname")
    regarding = record.get("regardingobjectid_incident")
    ticket = regarding.get("ticketnumber") if entity_type == "incident" and regarding else None

    # Extract author from activity parties (participationtypemask=1 = Sender)
    # Portal comments created through the portal have _createdby_value set to
    # the portal application service user, not the actual contact.  The real
    # contact is carried on the activity party with participationtypemask=1.
    author: str | None = None
    for party in record.get("adx_portalcomment_activity_parties", []):
        if party.get("participationtypemask") == 1:
            author = party.get("_partyid_value@OData.Community.Display.V1.FormattedValue")
            if not author:
                author = party.get("_partyid_value")
            break

    account: str | None = None
    if entity_type == "incident" and regarding:
        customer = regarding.get("customerid_account")
        if customer:
            account = customer.get("name")

    # Portal comment direction: 1 = incoming (received), 2 = outgoing (sent)
    raw_direction = record.get("adx_portalcommentdirectioncode")
    direction: str | None = None
    if raw_direction == 1:
        direction = "received"
    elif raw_direction == 2:
        direction = "sent"

    return {
        "author": author,
        "account": account,
        "direction": direction,
        "ticketnumber": ticket,
        "createdon": record.get("createdon"),
        "description": _strip_html_to_text(
            record.get("description"),
            max_length=max_description_length,
            strip_replies=strip_replies,
        ),
    }


def _format_email(
    record: dict[str, Any],
    max_description_length: int,
    strip_replies: bool = False,
) -> dict[str, Any]:
    """Format a raw email record for display.

    Args:
        record: Raw email from Dynamics CRM API.
        max_description_length: Max length for description text (0=unlimited).
        strip_replies: If True, remove quoted reply chains from description.

    Returns:
        Formatted email dictionary.
    """
    # Use the lookuplogicalname annotation to verify the regarding entity is
    # an incident before resolving the ticket number.  See _format_portal_comment.
    entity_type = record.get("_regardingobjectid_value@Microsoft.Dynamics.CRM.lookuplogicalname")
    regarding = record.get("regardingobjectid_incident")
    ticket = regarding.get("ticketnumber") if entity_type == "incident" and regarding else None

    author = record.get("_createdby_value@OData.Community.Display.V1.FormattedValue")
    if not author:
        author = record.get("_createdby_value")

    account: str | None = None
    if entity_type == "incident" and regarding:
        customer = regarding.get("customerid_account")
        if customer:
            account = customer.get("name")

    raw_direction = record.get("directioncode")
    direction: str | None = None
    if raw_direction is True:
        direction = "sent"
    elif raw_direction is False:
        direction = "received"

    sender: str | None = None
    for party in record.get("email_activity_parties", []):
        if party.get("participationtypemask") == 1:  # 1 = "From"
            sender = party.get("addressused")
            break

    return {
        "author": author,
        "sender": sender,
        "account": account,
        "direction": direction,
        "entity_type": entity_type,
        "ticketnumber": ticket,
        "createdon": record.get("createdon"),
        "subject": record.get("subject"),
        "description": _strip_html_to_text(
            record.get("description"),
            max_length=max_description_length,
            strip_replies=strip_replies,
        ),
    }


_DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
_DATETIME_RE = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$")


def _validate_date_or_datetime(
    ctx: click.Context, param: click.Parameter, value: str | None
) -> str | None:
    """Click callback to validate date (YYYY-MM-DD) or datetime (YYYY-MM-DDTHH:MM:SSZ)."""
    if value is None:
        return None
    if _DATE_RE.match(value) or _DATETIME_RE.match(value):
        return value
    raise click.BadParameter(
        f"'{value}' is not a valid date. Use YYYY-MM-DD or YYYY-MM-DDTHH:MM:SSZ."
    )


def _activity_query_options(f: Any) -> Any:
    """Shared Click options for activity query commands."""
    f = click.option(
        "--strip-replies",
        is_flag=True,
        default=False,
        help="Strip quoted reply chains from email/comment bodies",
    )(f)
    f = click.option(
        "--max-description-length",
        type=int,
        default=300,
        show_default=True,
        help="Truncate description to N characters (0=unlimited)",
    )(f)
    f = click.option(
        "--count-only",
        is_flag=True,
        default=False,
        help="Return only the count, no records",
    )(f)
    f = click.option(
        "--batch-size",
        type=int,
        default=None,
        help="Page size for auto-pagination (default: 500)",
    )(f)
    f = click.option(
        "--limit",
        "-l",
        type=int,
        default=None,
        help="Limit to N records (no auto-pagination)",
    )(f)
    f = click.option(
        "--until",
        type=str,
        default=None,
        callback=_validate_date_or_datetime,
        help="End date/time filter (YYYY-MM-DD or YYYY-MM-DDTHH:MM:SSZ)",
    )(f)
    f = click.option(
        "--since",
        type=str,
        required=True,
        callback=_validate_date_or_datetime,
        help="Start date/time filter (YYYY-MM-DD or YYYY-MM-DDTHH:MM:SSZ, required)",
    )(f)
    return f


def _activity_ticket_options(f: Any) -> Any:
    """Shared Click options for activity ticket commands."""
    f = click.option(
        "--strip-replies",
        is_flag=True,
        default=False,
        help="Strip quoted reply chains from email/comment bodies",
    )(f)
    f = click.option(
        "--max-description-length",
        type=int,
        default=300,
        show_default=True,
        help="Truncate description to N characters (0=unlimited)",
    )(f)
    f = click.option(
        "--count-only",
        is_flag=True,
        default=False,
        help="Return only the count, no records",
    )(f)
    f = click.option(
        "--batch-size",
        type=int,
        default=None,
        help="Page size for auto-pagination (default: 500)",
    )(f)
    f = click.option(
        "--limit",
        "-l",
        type=int,
        default=None,
        help="Limit to N records (no auto-pagination)",
    )(f)
    f = click.option(
        "--incident-id",
        type=str,
        default=None,
        help="Incident GUID (alternative to TICKET positional argument)",
    )(f)
    f = click.argument("ticket", required=False)(f)
    return f


@click.group()
def activity() -> None:
    """Activity queries (portal comments, emails).

    Query customer-authored activities across all cases (by date range) or
    for a specific ticket. HTML bodies are stripped to plain text and
    truncated for token-efficient sentiment scanning.

    \b
    Subcommands:
        portalcomment  Portal comment queries (query | ticket)
        email          Email queries (query | ticket)

    \b
    Tip: 'query' requires --since; add --count-only to size a range first.
    """
    pass


crm.add_command(activity)


@click.group()
def portalcomment() -> None:
    """Portal comment queries.

    Query portal comments from the Dynamics CRM activity pointer.

    \b
    Examples:
        dxs crm activity portalcomment query --since 2025-01-01
        dxs crm activity portalcomment query --since 2025-01-01 --until 2025-02-01
        dxs crm activity portalcomment ticket CAS-001
        dxs crm activity portalcomment ticket --incident-id <GUID>
    """
    pass


activity.add_command(portalcomment)


@portalcomment.command("query")
@_activity_query_options
@click.pass_obj
@require_auth
def portalcomment_query(
    ctx: "DxsContext",
    since: str,
    until: str | None,
    limit: int | None,
    batch_size: int | None,
    count_only: bool,
    max_description_length: int,
    strip_replies: bool,
) -> None:
    """Query portal comments from Dynamics CRM.

    Retrieves customer-authored portal comments for sentiment pre-screening.
    HTML is stripped to plain text and truncated for token efficiency.

    \b
    Examples:
        dxs crm activity portalcomment query --since 2025-01-01
        dxs crm activity portalcomment query --since 2025-01-01 --limit 50
        dxs crm activity portalcomment query --since 2025-01-01 --count-only
    """
    client = DynamicsClient()

    ctx.log(f"Querying portal comments since {since}...")

    # Count-only mode
    if count_only:
        result = client.query_portal_comments(
            since=since,
            until=until,
            limit=1,
        )
        total = result.get("@odata.count", 0)
        ctx.output(count_response(total_count=total, semantic_key="portal_comments"))
        return

    if limit:
        result = client.query_portal_comments(
            since=since,
            until=until,
            limit=limit,
        )
        raw_records = result.get("value", [])
    else:
        page_size = batch_size or 500
        all_records: list[dict] = []

        result = client.query_portal_comments(
            since=since,
            until=until,
            limit=page_size,
        )
        all_records.extend(result.get("value", []))
        total_count = result.get("@odata.count", len(all_records))

        while "@odata.nextLink" in result:
            ctx.log(f"Fetching next page ({len(all_records)} of {total_count} records)...")
            result = client.get_by_next_link(result["@odata.nextLink"])
            all_records.extend(result.get("value", []))

        raw_records = all_records

    items = [
        _format_portal_comment(r, max_description_length, strip_replies=strip_replies)
        for r in raw_records
    ]
    ctx.output(list_response(items=items, semantic_key="portal_comments"))


@portalcomment.command("ticket")
@_activity_ticket_options
@click.pass_obj
@require_auth
def portalcomment_ticket(
    ctx: "DxsContext",
    ticket: str | None,
    incident_id: str | None,
    limit: int | None,
    batch_size: int | None,
    count_only: bool,
    max_description_length: int,
    strip_replies: bool,
) -> None:
    """Get portal comments for a specific ticket.

    Retrieves all portal comments (inbound and outbound) for a case.

    \b
    Examples:
        dxs crm activity portalcomment ticket CAS-001
        dxs crm activity portalcomment ticket --incident-id <GUID>
        dxs crm activity portalcomment ticket CAS-001 --count-only
        dxs crm activity portalcomment ticket CAS-001 --strip-replies
    """
    if not ticket and not incident_id:
        raise click.UsageError("Provide either TICKET or --incident-id")
    if ticket and incident_id:
        raise click.UsageError("Provide either TICKET or --incident-id, not both")

    client = DynamicsClient()

    if incident_id:
        resolved_id = incident_id
        ctx.log(f"Querying portal comments for incident {incident_id}...")
    else:
        ctx.log(f"Resolving ticket {ticket}...")
        incident = client.resolve_ticket(ticket)  # type: ignore[arg-type]
        resolved_id = incident["incidentid"]
        ctx.log(f"Querying portal comments for {ticket} ({incident.get('title', '')})...")

    if count_only:
        result = client.query_portal_comments_by_incident(resolved_id, limit=1)
        total = result.get("@odata.count", 0)
        ctx.output(count_response(total_count=total, semantic_key="portal_comments"))
        return

    if limit:
        result = client.query_portal_comments_by_incident(resolved_id, limit=limit)
        raw_records = result.get("value", [])
    else:
        page_size = batch_size or 500
        result = client.query_portal_comments_by_incident(resolved_id, limit=page_size)
        raw_records = _auto_paginate(client, result, ctx)

    items = [
        _format_portal_comment(r, max_description_length, strip_replies=strip_replies)
        for r in raw_records
    ]
    ctx.output(list_response(items=items, semantic_key="portal_comments"))


@click.group()
def email() -> None:
    """Email queries.

    Query emails from the Dynamics CRM activity pointer.

    \b
    Examples:
        dxs crm activity email query --since 2025-01-01
        dxs crm activity email query --since 2025-01-01 --direction received
        dxs crm activity email ticket CAS-001
        dxs crm activity email ticket --incident-id <GUID>
    """
    pass


activity.add_command(email)


@email.command("query")
@_activity_query_options
@click.option(
    "--entity-type",
    "-e",
    multiple=True,
    default=("incident",),
    show_default=True,
    help="Filter by regarding entity type (e.g. incident, invoice). Repeatable.",
)
@click.option(
    "--direction",
    type=click.Choice(["sent", "received"], case_sensitive=False),
    default=None,
    help="Filter by email direction. Default: both sent and received.",
)
@click.option(
    "--exclude-subject",
    type=str,
    default=None,
    help="Exclude emails whose subject contains this substring (case-insensitive).",
)
@click.option(
    "--from",
    "sender_email",
    type=str,
    default=None,
    help="Include only emails where the From address contains this substring (case-insensitive).",
)
@click.option(
    "--exclude-from",
    type=str,
    default=None,
    help="Exclude emails where the From address contains this substring (case-insensitive).",
)
@click.pass_obj
@require_auth
def email_query(
    ctx: "DxsContext",
    since: str,
    until: str | None,
    limit: int | None,
    batch_size: int | None,
    count_only: bool,
    max_description_length: int,
    strip_replies: bool,
    entity_type: tuple[str, ...],
    direction: str | None,
    exclude_subject: str | None,
    sender_email: str | None,
    exclude_from: str | None,
) -> None:
    """Query emails from Dynamics CRM.

    Retrieves emails regarding cases. By default returns both sent and
    received. Use --direction to filter.
    HTML is stripped to plain text and truncated for token efficiency.

    \b
    Examples:
        dxs crm activity email query --since 2025-01-01
        dxs crm activity email query --since 2025-01-01 --direction received
        dxs crm activity email query --since 2025-01-01 --direction sent
        dxs crm activity email query --since 2025-01-01 -e invoice
        dxs crm activity email query --since 2025-01-01 --count-only
        dxs crm activity email query --since 2025-01-01 --exclude-subject "Case Update:"
        dxs crm activity email query --since 2025-01-01 --from customer@example.com
        dxs crm activity email query --since 2025-01-01 --exclude-from @datexcorp.com
    """
    client = DynamicsClient()

    direction_label = direction or "all"
    ctx.log(f"Querying {direction_label} emails since {since}...")

    # Count-only mode — return server-side count (unfiltered by entity type)
    if count_only:
        result = client.query_emails(
            since=since,
            until=until,
            limit=1,
            direction=direction,
        )
        total = result.get("@odata.count", 0)
        ctx.output(count_response(total_count=total, semantic_key="emails"))
        return

    if limit:
        result = client.query_emails(
            since=since,
            until=until,
            limit=limit,
            direction=direction,
        )
        raw_records = result.get("value", [])
    else:
        page_size = batch_size or 500
        all_records: list[dict] = []

        result = client.query_emails(
            since=since,
            until=until,
            limit=page_size,
            direction=direction,
        )
        all_records.extend(result.get("value", []))
        total_count = result.get("@odata.count", len(all_records))

        while "@odata.nextLink" in result:
            ctx.log(f"Fetching next page ({len(all_records)} of {total_count} records)...")
            result = client.get_by_next_link(result["@odata.nextLink"])
            all_records.extend(result.get("value", []))

        raw_records = all_records

    # Client-side entity type filtering
    if entity_type:
        raw_records = [
            r
            for r in raw_records
            if r.get("_regardingobjectid_value@Microsoft.Dynamics.CRM.lookuplogicalname")
            in entity_type
        ]

    # Client-side subject exclusion
    if exclude_subject:
        exclude_lower = exclude_subject.lower()
        raw_records = [
            r for r in raw_records if exclude_lower not in (r.get("subject") or "").lower()
        ]

    # Client-side sender filter (From party = participationtypemask 1)
    if sender_email:
        sender_lower = sender_email.lower()

        def _matches_sender(record: dict[str, Any]) -> bool:
            for party in record.get("email_activity_parties", []):
                if party.get("participationtypemask") == 1:
                    addr = (party.get("addressused") or "").lower()
                    if sender_lower in addr:
                        return True
            return False

        raw_records = [r for r in raw_records if _matches_sender(r)]

    # Client-side sender exclusion (From party = participationtypemask 1)
    if exclude_from:
        exclude_from_lower = exclude_from.lower()

        def _sender_excluded(record: dict[str, Any]) -> bool:
            for party in record.get("email_activity_parties", []):
                if party.get("participationtypemask") == 1:
                    addr = (party.get("addressused") or "").lower()
                    if exclude_from_lower in addr:
                        return True
            return False

        raw_records = [r for r in raw_records if not _sender_excluded(r)]

    items = [
        _format_email(r, max_description_length, strip_replies=strip_replies) for r in raw_records
    ]
    ctx.output(list_response(items=items, semantic_key="emails"))


@email.command("ticket")
@_activity_ticket_options
@click.pass_obj
@require_auth
def email_ticket(
    ctx: "DxsContext",
    ticket: str | None,
    incident_id: str | None,
    limit: int | None,
    batch_size: int | None,
    count_only: bool,
    max_description_length: int,
    strip_replies: bool,
) -> None:
    """Get emails for a specific ticket.

    Retrieves all emails (sent and received) for a case.

    \b
    Examples:
        dxs crm activity email ticket CAS-001
        dxs crm activity email ticket --incident-id <GUID>
        dxs crm activity email ticket CAS-001 --count-only
        dxs crm activity email ticket CAS-001 --strip-replies
    """
    if not ticket and not incident_id:
        raise click.UsageError("Provide either TICKET or --incident-id")
    if ticket and incident_id:
        raise click.UsageError("Provide either TICKET or --incident-id, not both")

    client = DynamicsClient()

    if incident_id:
        resolved_id = incident_id
        ctx.log(f"Querying emails for incident {incident_id}...")
    else:
        ctx.log(f"Resolving ticket {ticket}...")
        incident = client.resolve_ticket(ticket)  # type: ignore[arg-type]
        resolved_id = incident["incidentid"]
        ctx.log(f"Querying emails for {ticket} ({incident.get('title', '')})...")

    if count_only:
        result = client.query_emails_by_incident(resolved_id, limit=1)
        total = result.get("@odata.count", 0)
        ctx.output(count_response(total_count=total, semantic_key="emails"))
        return

    if limit:
        result = client.query_emails_by_incident(resolved_id, limit=limit)
        raw_records = result.get("value", [])
    else:
        page_size = batch_size or 500
        result = client.query_emails_by_incident(resolved_id, limit=page_size)
        raw_records = _auto_paginate(client, result, ctx)

    items = [
        _format_email(r, max_description_length, strip_replies=strip_replies) for r in raw_records
    ]
    ctx.output(list_response(items=items, semantic_key="emails"))


# =============================================================================
# Generic OData Command
# =============================================================================


@crm.command("odata")
@click.argument("entity")
@click.option(
    "--select",
    "-s",
    type=str,
    default=None,
    help="OData $select - comma-separated field names to return",
)
@click.option(
    "--filter",
    "-f",
    type=str,
    default=None,
    help='OData $filter - filter expression (e.g., "statecode eq 0")',
)
@click.option(
    "--orderby",
    type=str,
    default=None,
    help='OData $orderby - sort expression (e.g., "modifiedon desc")',
)
@click.option(
    "--expand",
    type=str,
    default=None,
    help="OData $expand - related entities to include",
)
@click.option(
    "--limit",
    "-l",
    type=int,
    default=None,
    help="Limit to N records (no auto-pagination)",
)
@click.option(
    "--batch-size",
    type=int,
    default=None,
    help="Page size for auto-pagination (default: 500)",
)
@click.option(
    "--count-only",
    is_flag=True,
    default=False,
    help="Return only the count, no records",
)
@click.pass_obj
@require_auth
def crm_odata(
    ctx: "DxsContext",
    entity: str,
    select: str | None,
    filter: str | None,
    orderby: str | None,
    expand: str | None,
    limit: int | None,
    batch_size: int | None,
    count_only: bool,
) -> None:
    """Execute a raw OData query against any Dataverse entity.

    The escape hatch for entities/fields the case/account/activity helpers
    don't cover. Returns raw API data with no field curation or HTML
    conversion - discover field names first with 'dxs crm metadata <entity>'.

    ENTITY is the entity path without leading slash (e.g., contacts,
    annotations, EntityDefinitions(...)/Attributes(...)).

    WARNING: without --limit this auto-paginates and returns ALL matching
    rows. Run --count-only first, then set --limit.

    \b
    Examples:
        dxs crm odata contacts -s "fullname,emailaddress1" -f "statecode eq 0" -l 10

        dxs crm odata annotations -f "_objectid_value eq 12345678-..." --orderby "createdon desc"

        dxs crm odata "EntityDefinitions(LogicalName='incident')/Attributes(LogicalName='casetypecode')/Microsoft.Dynamics.CRM.PicklistAttributeMetadata" \\
          -s LogicalName --expand 'OptionSet($select=Options)'
    """
    client = DynamicsClient()
    path = f"/{entity}"

    ctx.log(f"Querying {entity}...")
    if filter:
        ctx.log(f"Filter: {filter}")

    # Build OData params
    params: dict[str, str] = {"$count": "true"}
    if select:
        params["$select"] = select
    if filter:
        params["$filter"] = filter
    if orderby:
        params["$orderby"] = orderby
    if expand:
        params["$expand"] = expand

    # Count-only mode
    if count_only:
        result = client.get(path, params=params, page_size=1)
        total = result.get("@odata.count", 0)
        ctx.output(count_response(total_count=total, semantic_key="results"))
        return

    if limit:
        # Single request, no pagination
        result = client.get(path, params=params, page_size=limit)
    else:
        # Auto-pagination
        page_size = batch_size or 500
        result = client.get(path, params=params, page_size=page_size)

    # Non-collection response (e.g., metadata endpoints)
    if "value" not in result:
        ctx.output(single(item=result, semantic_key="odata_result"))
        return

    items = result.get("value", [])

    if not limit:
        total_count = result.get("@odata.count", len(items))
        # Follow @odata.nextLink until all records are fetched
        while "@odata.nextLink" in result:
            ctx.log(f"Fetching next page ({len(items)} of {total_count} records)...")
            result = client.get_by_next_link(result["@odata.nextLink"])
            items.extend(result.get("value", []))

    ctx.output(list_response(items=items, semantic_key="results"))
