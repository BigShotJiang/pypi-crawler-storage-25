"""Azure DevOps commands: dxs devops [workitem|workitems|attachments]."""

import pathlib

import click

from dxs.cli import DxsContext, pass_context
from dxs.core.auth import require_auth
from dxs.core.devops import AzureDevOpsClient
from dxs.core.devops.helpers import resolve_attachment, resolve_devops_org
from dxs.utils.errors import ValidationError
from dxs.utils.responses import list_response, single


@click.group()
def devops() -> None:
    """Azure DevOps work item commands.

    Query work items from Azure DevOps. Requires that the Azure
    app registration has delegated permissions for Azure DevOps.

    \b
    Examples:
        dxs devops workitem 1234 --org myorg
        dxs devops workitems 1234,1235,1236 --org myorg
        dxs devops attachments 1234 --org myorg
    """
    pass


@devops.command()
@click.argument("workitem_id", type=int)
@click.option(
    "--org",
    "organization",
    required=False,
    default=None,
    help="Azure DevOps organization name",
)
@click.option(
    "--expand",
    type=click.Choice(["None", "Relations", "Links", "All"], case_sensitive=False),
    default=None,
    help="Expand options for related data",
)
@click.option(
    "--full",
    is_flag=True,
    default=False,
    help="Show full content without truncation",
)
@click.option(
    "--discussions",
    is_flag=True,
    default=False,
    help="Include work item discussions",
)
@click.option(
    "--download-images",
    is_flag=True,
    default=False,
    help="Download inline images from description/design fields",
)
@click.option(
    "--out",
    "output_dir",
    type=click.Path(),
    default=None,
    help="Output directory for downloaded images (default: current directory)",
)
@pass_context
@require_auth
def workitem(
    ctx: DxsContext,
    workitem_id: int,
    organization: str | None,
    expand: str | None,
    full: bool,
    discussions: bool,
    download_images: bool,
    output_dir: str | None,
) -> None:
    """Get a single work item by ID.

    Fetches detailed information about an Azure DevOps work item
    including title, type, state, description, and metadata.
    HTML fields are converted to markdown and truncated by default.

    \b
    Arguments:
        WORKITEM_ID  Azure DevOps work item ID

    \b
    Options:
        --org ORG           Azure DevOps organization name (or set default_devops_org in config)
        --expand            Expand options (None, Relations, Links, All)
        --full              Show full content without truncation
        --discussions       Include work item discussions
        --download-images   Download inline images from description/design fields
        --out DIR           Output directory for downloaded images

    \b
    Example:
        dxs devops workitem 1234 --org myorg
        dxs devops workitem 1234 --org myorg --expand Relations
        dxs devops workitem 1234 --full
        dxs devops workitem 1234 --discussions
        dxs devops workitem 1234 --download-images --out ./images
    """
    org = resolve_devops_org(organization)
    ctx.log(f"Fetching work item {workitem_id} from {org}...")

    # Default to Relations so attachments and links are always available
    if expand is None:
        expand = "Relations"

    with AzureDevOpsClient(org) as client:
        item = client.get_workitem(workitem_id, expand=expand)

        if discussions:
            item.discussions = client.get_workitem_discussions(workitem_id)

        downloaded_images: list[dict[str, str]] = []
        if download_images:
            from dxs.core.devops.models import extract_inline_image_urls

            detail_data = item.to_detail(full=True)
            all_markdown = "\n".join(
                str(detail_data.get(k, ""))
                for k in ("description", "design", "acceptance_criteria")
            )
            image_urls = extract_inline_image_urls(all_markdown)

            out_dir = pathlib.Path(output_dir) if output_dir else pathlib.Path(".")
            out_dir.mkdir(parents=True, exist_ok=True)

            for idx, img_url in enumerate(image_urls, 1):
                ctx.log(f"Downloading image {idx}/{len(image_urls)}...")
                content, filename = client.download_attachment(img_url)
                out_path = out_dir / f"image_{idx:03d}_{filename}"
                out_path.write_bytes(content)
                downloaded_images.append(
                    {
                        "file": str(out_path),
                        "size_bytes": str(len(content)),
                    }
                )

    output = item.to_detail(full=full, include_discussions=discussions)
    if downloaded_images:
        output["downloaded_images"] = downloaded_images

    ctx.output(
        single(
            item=output,
            semantic_key="workitem",
            organization=org,
        )
    )


@devops.command()
@click.argument("ids", type=str)
@click.option(
    "--org",
    "organization",
    required=False,
    default=None,
    help="Azure DevOps organization name",
)
@click.option(
    "--description",
    is_flag=True,
    default=False,
    help="Include work item description (HTML)",
)
@click.option(
    "--discussions",
    is_flag=True,
    default=False,
    help="Include work item discussions",
)
@pass_context
@require_auth
def workitems(
    ctx: DxsContext,
    ids: str,
    organization: str | None,
    description: bool,
    discussions: bool,
) -> None:
    """Get multiple work items by IDs (batch).

    Fetches detailed information about multiple Azure DevOps work
    items in a single request. Maximum 200 work items per request.

    \b
    Arguments:
        IDS  Comma-separated work item IDs (e.g., 1234,1235,1236)

    \b
    Options:
        --org ORG       Azure DevOps organization name (or set default_devops_org in config)
        --description   Include work item descriptions
        --discussions   Include work item discussions

    \b
    Examples:
        dxs devops workitems 1234,1235,1236 --org myorg
        dxs devops workitems 1234 --org myorg --description
        dxs devops workitems 1234 --org myorg --description --discussions
    """
    org = resolve_devops_org(organization)

    # Parse comma-separated IDs
    try:
        id_list = [int(id_str.strip()) for id_str in ids.split(",") if id_str.strip()]
    except ValueError as e:
        raise ValidationError(
            message="Invalid work item IDs. Must be comma-separated integers.",
            code="DXS-VAL-002",
            suggestions=["Use format: 1234,1235,1236"],
        ) from e

    if not id_list:
        raise ValidationError(
            message="At least one work item ID is required.",
            code="DXS-VAL-003",
        )

    if len(id_list) > 200:
        raise ValidationError(
            message="Maximum 200 work items can be fetched in a single request.",
            code="DXS-VAL-004",
            suggestions=["Split your request into multiple batches"],
        )

    ctx.log(f"Fetching {len(id_list)} work items from {org}...")

    with AzureDevOpsClient(org) as client:
        items = client.get_workitems_batch(id_list)

        # Fetch discussions if requested
        if discussions:
            ctx.log(f"Fetching discussions for {len(items)} work items...")
            for item in items:
                item.discussions = client.get_workitem_discussions(item.id)

    # Convert to summaries with optional fields
    summaries = [
        item.to_summary(include_description=description, include_discussions=discussions)
        for item in items
    ]

    # Group IDs by type for metadata (avoid duplicating full data)
    ids_by_type: dict[str, list[int]] = {}
    for item in items:
        item_type = item.work_item_type
        if item_type not in ids_by_type:
            ids_by_type[item_type] = []
        ids_by_type[item_type].append(item.id)

    ctx.output(
        list_response(
            items=summaries,
            semantic_key="workitems",
            organization=org,
            requested_ids=id_list,
            ids_by_type=ids_by_type,
            type_summary={k: len(v) for k, v in ids_by_type.items()},
            includes_description=description,
            includes_discussions=discussions,
        )
    )


@devops.command()
@click.argument("workitem_id", type=int)
@click.option(
    "--org",
    "organization",
    required=False,
    default=None,
    help="Azure DevOps organization name",
)
@click.option(
    "--download",
    default=None,
    help="Download attachment by name or 1-based index",
)
@click.option(
    "--out",
    "output_path",
    type=click.Path(),
    default=None,
    help="Output file path for download (defaults to original filename)",
)
@pass_context
@require_auth
def attachments(
    ctx: DxsContext,
    workitem_id: int,
    organization: str | None,
    download: str | None,
    output_path: str | None,
) -> None:
    """List or download work item attachments.

    Without --download, lists all attachments on the work item.
    With --download, downloads a specific attachment by name or index.

    \b
    Arguments:
        WORKITEM_ID  Azure DevOps work item ID

    \b
    Options:
        --org ORG           Azure DevOps organization name
        --download NAME     Download attachment by name or 1-based index
        --out PATH          Output file path (defaults to original filename)

    \b
    Examples:
        dxs devops attachments 1234 --org myorg
        dxs devops attachments 1234 --download 1
        dxs devops attachments 1234 --download image.png --out ./img.png
    """
    org = resolve_devops_org(organization)
    ctx.log(f"Fetching attachments for work item {workitem_id} from {org}...")

    with AzureDevOpsClient(org) as client:
        item = client.get_workitem(workitem_id, expand="Relations")

        # Filter for attachments
        attachment_relations = [r for r in item.relations if r.get("rel") == "AttachedFile"]

        if not attachment_relations:
            ctx.output(
                single(
                    item={"message": "No attachments found on this work item"},
                    semantic_key="attachments",
                    organization=org,
                    workitem_id=workitem_id,
                )
            )
            return

        # Build attachment list
        attachment_list = []
        for i, rel in enumerate(attachment_relations, 1):
            attrs = rel.get("attributes", {})
            attachment_list.append(
                {
                    "index": i,
                    "name": attrs.get("name", "unknown"),
                    "url": rel.get("url", ""),
                    "comment": attrs.get("comment", None),
                }
            )

        if download is None:
            # List mode
            ctx.output(
                list_response(
                    items=attachment_list,
                    semantic_key="attachments",
                    organization=org,
                    workitem_id=workitem_id,
                )
            )
            return

        # Download mode — resolve attachment by name or index
        target = resolve_attachment(attachment_list, download)

        ctx.log(f"Downloading '{target['name']}'...")
        content, filename = client.download_attachment(str(target["url"]))

        # Determine output path
        out = pathlib.Path(output_path) if output_path else pathlib.Path(filename)
        out.write_bytes(content)

        ctx.output(
            single(
                item={
                    "downloaded": target["name"],
                    "size_bytes": len(content),
                    "path": str(out.resolve()),
                },
                semantic_key="attachment_download",
                organization=org,
                workitem_id=workitem_id,
            )
        )


@devops.command()
@click.argument("query")
@click.option(
    "--org",
    "organization",
    required=False,
    default=None,
    help="Azure DevOps organization name",
)
@click.option(
    "--project",
    default=None,
    help="Azure DevOps project name (optional)",
)
@pass_context
@require_auth
def search(
    ctx: DxsContext,
    query: str,
    organization: str | None,
    project: str | None,
) -> None:
    """Search work items by title (simplified search).

    Note: This is a simplified search that fetches recent work items
    and filters client-side. For complex queries, use WIQL directly
    through the Azure DevOps web interface.

    \b
    Arguments:
        QUERY  Search term to match against work item titles

    \b
    Options:
        --org ORG        Azure DevOps organization name
        --project PROJ   Azure DevOps project name (optional)

    \b
    Example:
        dxs devops search "login bug" --org myorg
    """
    org = resolve_devops_org(organization)

    ctx.output(
        single(
            item={
                "message": "Work item search is not yet implemented",
                "suggestion": "Use 'dxs devops workitem <id>' with known work item IDs",
            },
            semantic_key="search_status",
            query=query,
            organization=org,
            project=project,
        )
    )
