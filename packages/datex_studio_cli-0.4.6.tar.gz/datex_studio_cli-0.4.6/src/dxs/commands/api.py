"""Raw API request command: dxs api [METHOD] [URL] [PAYLOAD]."""

import json
import sys
from pathlib import Path
from typing import Any

import click
import httpx

from dxs.cli import DxsContext, pass_context
from dxs.core.auth import get_access_token, require_auth
from dxs.utils.config import get_settings, is_restricted_mode
from dxs.utils.errors import ApiError, RestrictedModeError
from dxs.utils.responses import single


@click.command()
@click.argument(
    "method", type=click.Choice(["GET", "POST", "PUT", "PATCH", "DELETE"], case_sensitive=False)
)
@click.argument("url")
@click.argument("payload", required=False, default=None)
@click.option(
    "--data-file",
    "-D",
    "data_file",
    type=click.Path(exists=True, dir_okay=False, readable=True, path_type=Path),
    default=None,
    help="Read JSON request body from a file (avoids shell escaping for large payloads).",
)
@click.option(
    "--output-file",
    "-O",
    "output_file",
    type=click.Path(dir_okay=False, writable=True, path_type=Path),
    default=None,
    help="Write the response body to a file. Implies --raw.",
)
@click.option(
    "--raw",
    is_flag=True,
    default=False,
    help="Print only the response body (no envelope) as JSON to stdout. Useful for piping to jq.",
)
@click.option(
    "--headers",
    "-H",
    multiple=True,
    help="Additional headers in format 'Key: Value'",
)
@pass_context
@require_auth
def api(
    ctx: DxsContext,
    method: str,
    url: str,
    payload: str | None,
    data_file: Path | None,
    output_file: Path | None,
    raw: bool,
    headers: tuple[str, ...],
) -> None:
    """Make raw API requests with automatic authentication.

    Automatically adds Bearer token authentication and handles the HTTP request.
    Useful for testing and exploring API endpoints.

    \b
    Arguments:
        METHOD   HTTP method (GET, POST, PUT, PATCH, DELETE)
        URL      Full URL or relative path (e.g., /organizations/mine)
        PAYLOAD  JSON payload for POST/PUT/PATCH (optional; alternative: --data-file)

    \b
    Options:
        -D, --data-file    Read JSON body from a file (recommended for large payloads)
        -O, --output-file  Write response body to a file (implies --raw)
        --raw              Emit only the response body (no envelope) for piping
        -H, --headers      Additional headers (repeatable)

    \b
    Examples:
        dxs api GET /organizations/mine
        dxs api GET /applications/64/hubconfigurations/8642750 --raw -O hub.json
        dxs api PUT /applications/64/hubconfigurations/8642750 --data-file hub.json
        dxs api POST /applications -D payload.json
        dxs api GET /branches -H "X-Custom: value"
    """
    if payload is not None and data_file is not None:
        raise ApiError(
            message="Pass either a positional PAYLOAD or --data-file, not both.",
            code="DXS-API-PAYLOAD-002",
            suggestions=["Drop one of the two arguments and re-run."],
        )

    # --output-file implies --raw (writing an envelope to disk would defeat the purpose).
    if output_file is not None:
        raw = True

    # Block mutating methods in restricted mode
    if is_restricted_mode() and method.upper() != "GET":
        raise RestrictedModeError(
            command_name=f"api {method.upper()}",
            reason="performs mutating API requests",
        )

    settings = get_settings()
    token = get_access_token()

    # Determine if URL is relative or absolute
    if url.startswith("http://") or url.startswith("https://"):
        full_url = url
    else:
        # Relative path - prepend base URL
        base_url = settings.api_base_url.rstrip("/")
        path = url if url.startswith("/") else f"/{url}"
        full_url = f"{base_url}{path}"

    ctx.log(f"Making {method} request to {full_url}")

    # Build headers
    request_headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
        "Accept": "application/json",
    }

    # Parse additional headers
    for header in headers:
        if ":" in header:
            key, value = header.split(":", 1)
            request_headers[key.strip()] = value.strip()

    # Resolve and parse payload from positional arg or --data-file
    payload_data = None
    payload_source: str | None = None
    if data_file is not None:
        payload_source = f"--data-file {data_file}"
        try:
            payload_data = json.loads(data_file.read_text(encoding="utf-8"))
        except json.JSONDecodeError as e:
            raise ApiError(
                message=f"Invalid JSON in {data_file}: {e}",
                code="DXS-API-PAYLOAD-001",
                suggestions=[f"Validate the file with: python -m json.tool {data_file}"],
            ) from e
    elif payload:
        payload_source = "positional argument"
        try:
            payload_data = json.loads(payload)
        except json.JSONDecodeError as e:
            raise ApiError(
                message=f"Invalid JSON payload: {e}",
                code="DXS-API-PAYLOAD-001",
                suggestions=[
                    "Ensure the payload is valid JSON",
                    "For large or complex bodies, use --data-file PATH instead.",
                ],
            ) from e

    # Make the request
    try:
        with httpx.Client(timeout=settings.api_timeout, verify=settings.verify_ssl) as client:
            response = client.request(
                method=method.upper(),
                url=full_url,
                headers=request_headers,
                json=payload_data if payload_data else None,
            )

            # Decode body once
            try:
                body: Any = response.json()
                body_is_json = True
            except Exception:
                body = response.text
                body_is_json = False

            if raw:
                _emit_raw(ctx, body, body_is_json, output_file)
                return

            response_data: dict[str, Any] = {
                "status_code": response.status_code,
                "headers": dict(response.headers),
                "url": str(response.url),
                "method": method.upper(),
                "body": body,
                "request": {
                    "url": full_url,
                    "method": method.upper(),
                    "headers": request_headers,
                },
            }
            if payload_data:
                response_data["request"]["payload"] = payload_data
            if payload_source:
                response_data["request"]["payload_source"] = payload_source

            ctx.output(
                single(
                    item=response_data,
                    semantic_key="api_response",
                )
            )

    except httpx.RequestError as e:
        raise ApiError(
            message=f"Request failed: {e}",
            code="DXS-API-REQUEST-001",
            details={"url": full_url, "error": str(e)},
        ) from e


def _emit_raw(
    ctx: DxsContext,
    body: Any,
    body_is_json: bool,
    output_file: Path | None,
) -> None:
    """Print or save the response body without the envelope."""
    if body_is_json:
        rendered = json.dumps(body, indent=2, sort_keys=False, ensure_ascii=False)
    else:
        rendered = body if isinstance(body, str) else str(body)

    if output_file is not None:
        output_file.write_text(rendered, encoding="utf-8")
        ctx.log(f"Wrote response body to {output_file}")
        return

    sys.stdout.write(rendered)
    if not rendered.endswith("\n"):
        sys.stdout.write("\n")
    sys.stdout.flush()
