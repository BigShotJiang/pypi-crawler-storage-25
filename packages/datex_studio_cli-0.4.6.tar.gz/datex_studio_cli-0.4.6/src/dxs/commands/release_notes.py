"""Release notes command: dxs source release-notes."""

import logging
from typing import Any

import click

from dxs.cli import DxsContext, pass_context
from dxs.commands.branch import enrich_branch_with_status
from dxs.core.api import (
    ApiClient,
    BranchEndpoints,
    SourceControlEndpoints,
    fetch_references,
)
from dxs.core.auth import require_auth
from dxs.core.release_notes import (
    aggregate_contributors,
    classify_dependencies,
    collect_workitems_batch,
    enrich_workitems_with_devops_data,
)
from dxs.utils.errors import ValidationError
from dxs.utils.responses import single

logger = logging.getLogger(__name__)


@click.command("release-notes")
@click.option(
    "--from",
    "from_branch",
    type=int,
    required=True,
    help="Source branch ID (earlier release)",
)
@click.option(
    "--to",
    "to_branch",
    type=int,
    required=True,
    help="Target branch ID (later release)",
)
@click.option(
    "--include-sync",
    is_flag=True,
    default=False,
    help="Include sync-only dependency changes in meaningful list",
)
@click.option(
    "--no-workitems",
    is_flag=True,
    default=False,
    help="Skip fetching work items (faster)",
)
@click.option(
    "--description",
    "-d",
    type=str,
    default=None,
    help="Optional description for the release notes",
)
@click.option(
    "--enrich-workitems",
    is_flag=True,
    default=False,
    help="Enrich work items with Azure DevOps data (type, state, assigned_to)",
)
@pass_context
@require_auth
def release_notes(
    ctx: DxsContext,
    from_branch: int,
    to_branch: int,
    include_sync: bool,
    no_workitems: bool,
    description: str | None,
    enrich_workitems: bool,
) -> None:
    """Generate release notes between two branches.

    Compares two release branches and produces structured release notes
    including committed branches, dependency changes, work items, and
    contributors.

    \b
    Options:
        --from ID          Source branch ID (earlier release)
        --to ID            Target branch ID (later release)
        --include-sync     Include sync-only deps in meaningful list
        --no-workitems     Skip work item fetching
        -d, --description  Optional description text
        --enrich-workitems Enrich work items with DevOps data

    \b
    Examples:
        dxs source release-notes --from 65445 --to 67134
        dxs source release-notes --from 100 --to 200 --no-workitems
    """
    # Validate: cannot compare a branch to itself
    if from_branch == to_branch:
        raise ValidationError(
            message="Cannot compare a branch to itself",
            code="DXS-VAL-002",
            suggestions=["Provide different --from and --to branch IDs"],
        )

    client = ApiClient()

    # 1. Fetch branch details
    ctx.log("Fetching branch details...")
    from_branch_data = client.get(BranchEndpoints.get(from_branch))
    to_branch_data = client.get(BranchEndpoints.get(to_branch))

    # 2. Enrich with status fields
    from_branch_data = enrich_branch_with_status(from_branch_data)
    to_branch_data = enrich_branch_with_status(to_branch_data)

    # 3. Compare logic: find releases and committed branches between dates
    from_is_release = from_branch_data.get("isRelease", False)
    to_is_release = to_branch_data.get("isRelease", False)

    releases_list: list[dict[str, Any]] = []
    committed_branches_list: list[dict[str, Any]] = []

    if from_is_release and to_is_release:
        group_id = from_branch_data.get("applicationGroupId") or to_branch_data.get(
            "applicationGroupId"
        )
        if group_id:
            all_branches = client.get(*BranchEndpoints.list(group_id))
            if not isinstance(all_branches, list):
                all_branches = [all_branches] if all_branches else []

            from_date = from_branch_data.get("createdDate", "")
            to_date = to_branch_data.get("createdDate", "")

            if from_date and to_date:
                # Find intermediate releases (all PublishedMain in the group)
                releases = [b for b in all_branches if b.get("applicationStatusId") == 3]
                releases_in_range = [
                    b for b in releases if from_date < b.get("createdDate", "") <= to_date
                ]
                releases_in_range.sort(key=lambda x: x.get("createdDate", ""))
                releases_list = [
                    {
                        "id": b.get("id"),
                        "title": b.get("description") or b.get("commitTitle"),
                        "date": b.get("createdDate"),
                    }
                    for b in releases_in_range
                ]

                # Find committed branches (WorkspaceHistory = status 4)
                ctx.log("Fetching feature branch commits...")
                commits = [b for b in all_branches if b.get("applicationStatusId") == 4]
                commits_in_range = [
                    b for b in commits if from_date < b.get("createdDate", "") <= to_date
                ]
                commits_in_range.sort(key=lambda x: x.get("createdDate", ""))

                # Fetch changes for each commit
                ctx.log(f"Fetching changes for {len(commits_in_range)} commits...")
                for commit_branch in commits_in_range:
                    commit_id = commit_branch.get("id")
                    title = commit_branch.get("description") or commit_branch.get("commitTitle")
                    commit_entry: dict[str, Any] = {
                        "id": commit_id,
                        "title": title,
                        "date": commit_branch.get("createdDate"),
                        "author": commit_branch.get("authorDisplayName"),
                        "changes": [],
                        "work_items": [],
                    }

                    try:
                        changes_data = client.get(
                            SourceControlEndpoints.history_branch_changes(commit_id)
                        )
                        if changes_data:
                            configs = (
                                changes_data.get("configs", [])
                                if isinstance(changes_data, dict)
                                else []
                            )
                            commit_entry["changes"] = [
                                {
                                    "reference_name": c.get("referenceName"),
                                    "type": c.get("configurationTypeId"),
                                    "modification": c.get("modificationTypeId"),
                                }
                                for c in configs
                            ]
                    except Exception:
                        logger.debug(
                            "Failed to fetch changes for commit %s", commit_id, exc_info=True
                        )

                    committed_branches_list.append(commit_entry)

    # 4. Get dependency changes
    dep_changes: dict[str, list[Any]] = {"added": [], "removed": [], "updated": []}
    ctx.log("Comparing dependencies...")
    try:
        from_deps = fetch_references(client, from_branch, direct_only=True)
        to_deps = fetch_references(client, to_branch, direct_only=True)

        from_by_ref = {d.get("referenceName"): d for d in from_deps}
        to_by_ref = {d.get("referenceName"): d for d in to_deps}

        for ref, dep in to_by_ref.items():
            if ref not in from_by_ref:
                dep_changes["added"].append(dep)
            else:
                from_dep = from_by_ref[ref]
                from_ver = from_dep.get("marketPlaceApplicationVersionId")
                to_ver = dep.get("marketPlaceApplicationVersionId")
                if from_ver != to_ver:
                    dep_changes["updated"].append(
                        {
                            "reference_name": ref,
                            "from_branch_id": from_dep.get("applicationId"),
                            "to_branch_id": dep.get("applicationId"),
                        }
                    )

        for ref in from_by_ref:
            if ref not in to_by_ref:
                dep_changes["removed"].append(from_by_ref[ref])
    except Exception:
        logger.debug("Failed to fetch dependencies", exc_info=True)

    # 5. Classify dependencies
    meaningful_deps: list[dict[str, Any]] = []
    sync_only_deps: list[dict[str, Any]] = []
    if dep_changes["updated"]:
        ctx.log(f"Classifying {len(dep_changes['updated'])} dependency updates...")
        meaningful_deps, sync_only_deps = classify_dependencies(client, dep_changes["updated"])

    if include_sync:
        # Move sync-only deps into meaningful list
        meaningful_deps.extend(sync_only_deps)
        sync_only_deps = []

    # 6. Collect work items
    workitems_by_branch: dict[int, list[dict[str, Any]]] = {}
    if not no_workitems:
        branch_ids = [b["id"] for b in committed_branches_list if b.get("id")]
        if branch_ids:
            ctx.log(f"Fetching work items for {len(branch_ids)} branches...")
            workitems_by_branch = collect_workitems_batch(client, branch_ids)

        # Attach work items to committed branches
        for branch in committed_branches_list:
            bid = branch.get("id")
            if bid and bid in workitems_by_branch:
                branch["work_items"] = workitems_by_branch[bid]

    # 7. Identify branches without work items
    branches_without_workitems = []
    if not no_workitems:
        branches_without_workitems = [
            {"id": b["id"], "title": b.get("title")}
            for b in committed_branches_list
            if not b.get("work_items")
        ]

    # 8. Aggregate all work items
    all_workitems: list[dict[str, Any]] = []
    seen_wi: set[str] = set()
    for items in workitems_by_branch.values():
        for wi in items:
            ext_id = wi.get("externalId")
            if ext_id and ext_id not in seen_wi:
                seen_wi.add(ext_id)
                all_workitems.append(wi)

    # 9. Group work items spanning multiple branches
    workitem_branches: dict[str, list[int]] = {}
    for branch in committed_branches_list:
        bid = branch.get("id")
        for wi in branch.get("work_items", []):
            ext_id = wi.get("externalId")
            if ext_id and bid:
                workitem_branches.setdefault(ext_id, []).append(bid)

    multi_branch_workitems = [
        {"workitem_id": wi_id, "branch_ids": bids}
        for wi_id, bids in workitem_branches.items()
        if len(bids) > 1
    ]

    # 10. Enrich work items with DevOps data (type, state, etc.)
    workitems_by_type: dict[str, int] = {}
    if enrich_workitems and all_workitems:
        ctx.log(f"Enriching {len(all_workitems)} work items with DevOps data...")
        all_workitems = enrich_workitems_with_devops_data(all_workitems)
        for wi in all_workitems:
            devops = wi.get("devops_data")
            if devops:
                wi_type = devops.get("type", "Unknown")
                workitems_by_type[wi_type] = workitems_by_type.get(wi_type, 0) + 1

    # 11. Aggregate contributors
    contributors = aggregate_contributors(committed_branches_list, meaningful_deps)

    # 12. Build output
    output_data: dict[str, Any] = {
        "from_branch": {
            "id": from_branch_data.get("id"),
            "name": from_branch_data.get("name"),
            "status": from_branch_data.get("statusName"),
            "date": from_branch_data.get("createdDate"),
        },
        "to_branch": {
            "id": to_branch_data.get("id"),
            "name": to_branch_data.get("name"),
            "status": to_branch_data.get("statusName"),
            "date": to_branch_data.get("createdDate"),
        },
        "summary": {
            "release_count": len(releases_list),
            "committed_branch_count": len(committed_branches_list),
            "meaningful_dependency_count": len(meaningful_deps),
            "sync_only_dependency_count": len(sync_only_deps),
            "workitem_count": len(all_workitems),
            "workitems_spanning_multiple_branches_count": len(multi_branch_workitems),
            "contributor_count": len(contributors),
        },
        "releases": releases_list,
        "committed_branches": committed_branches_list,
        "branches_without_workitems": branches_without_workitems,
        "dependencies": {
            "meaningful": meaningful_deps,
            "sync_only": [{"reference_name": d.get("reference_name")} for d in sync_only_deps],
            "added": dep_changes["added"],
            "removed": dep_changes["removed"],
        },
        "workitems": all_workitems,
        "contributors": contributors,
        "workitems_spanning_multiple_branches": multi_branch_workitems,
    }

    if workitems_by_type:
        output_data["summary"]["workitems_by_type"] = workitems_by_type

    if description:
        output_data["description"] = description

    ctx.output(
        single(
            item=output_data,
            semantic_key="release_notes",
            from_branch_id=from_branch,
            to_branch_id=to_branch,
        )
    )
