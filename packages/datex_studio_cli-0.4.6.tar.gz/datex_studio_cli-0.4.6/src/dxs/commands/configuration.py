"""Generic platform configuration commands: dxs configuration [get|update|list|delete].

Operates on any of the ConfigurationEndpoints.KNOWN_TYPES (hub, grid, form, editor,
flow, etc.). Provides the missing primitive that previously forced users to
hand-craft `dxs api` calls and reverse-engineer endpoint paths.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import click

from dxs.cli import DxsContext, pass_context
from dxs.core.api.client import ApiClient
from dxs.core.api.endpoints import ConfigurationEndpoints
from dxs.core.auth import require_auth
from dxs.utils.click_options import resolve_branch
from dxs.utils.errors import ValidationError
from dxs.utils.responses import single
from dxs.utils.restricted import restrict_in_restricted_mode


def _validate_type(config_type: str) -> str:
    normalized = ConfigurationEndpoints.normalize_type(config_type)
    if normalized not in ConfigurationEndpoints.KNOWN_TYPES:
        known = ", ".join(sorted(ConfigurationEndpoints.KNOWN_TYPES))
        raise ValidationError(
            message=f"Unknown configuration type: {config_type!r}",
            code="DXS-CFG-001",
            suggestions=[f"Use one of: {known}"],
        )
    return normalized


def _load_body(data_file: Path) -> Any:
    try:
        return json.loads(data_file.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        raise ValidationError(
            message=f"Invalid JSON in {data_file}: {e}",
            code="DXS-CFG-002",
            suggestions=[f"Validate the file with: python -m json.tool {data_file}"],
        ) from e


@click.group("configuration")
def configuration() -> None:
    """Manage platform configuration objects (hub, grid, form, editor, flow, etc.).

    These are the deployable artifacts on a Datex Studio branch — distinct from
    `dxs config`/`dxs settings`, which manage local CLI settings.

    Pair `get` (with --output-file) and `update` (with --data-file) to fetch a
    config, edit it locally, and push it back without shell-escaping a large
    JSON payload.

    \b
    Examples:
        dxs configuration types
        dxs configuration get hub 8642750 -b 64 --output-file hub.json
        dxs configuration update hub 8642750 -b 64 --data-file hub.json
    """


@configuration.command("types")
@pass_context
def configuration_types(ctx: DxsContext) -> None:
    """List the known platform configuration type names accepted by these commands."""
    types = sorted(ConfigurationEndpoints.KNOWN_TYPES)
    ctx.output(
        single(item={"types": types, "count": len(types)}, semantic_key="configuration_types")
    )


@configuration.command("get")
@click.argument("config_type")
@click.argument("config_id", type=int)
@click.option("--branch", "-b", type=int, default=None, help="Branch ID (falls back to global -b)")
@click.option(
    "--output-file",
    "-O",
    "output_file",
    type=click.Path(dir_okay=False, writable=True, path_type=Path),
    default=None,
    help="Write the full config JSON to a file (round-trips cleanly to `update --data-file`).",
)
@pass_context
@require_auth
def configuration_get(
    ctx: DxsContext,
    config_type: str,
    config_id: int,
    branch: int | None,
    output_file: Path | None,
) -> None:
    """Fetch a platform configuration by type and ID.

    \b
    Arguments:
        CONFIG_TYPE  Configuration type (e.g., hub, grid, form, editor, flow)
        CONFIG_ID    Numeric configuration ID

    \b
    Examples:
        dxs configuration get hub 8642750 -b 64
        dxs configuration get hub 8642750 -b 64 -O hub.json
    """
    config_type = _validate_type(config_type)
    branch_id = resolve_branch(ctx, branch, "DXS-CFG-010")

    api_client = ApiClient()
    path = ConfigurationEndpoints.get_content(branch_id, config_type, config_id)
    body = api_client.get(path)

    if output_file is not None:
        output_file.write_text(
            json.dumps(body, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
        ctx.log(f"Wrote {config_type} configuration {config_id} to {output_file}")
        return

    ctx.output(single(item=body, semantic_key="configuration"))


@configuration.command("update")
@click.argument("config_type")
@click.argument("config_id", type=int)
@click.option(
    "--data-file",
    "-D",
    "data_file",
    required=True,
    type=click.Path(exists=True, dir_okay=False, readable=True, path_type=Path),
    help="JSON file containing the full configuration body to PUT.",
)
@click.option("--branch", "-b", type=int, default=None, help="Branch ID (falls back to global -b)")
@pass_context
@require_auth
@restrict_in_restricted_mode("modifies platform configurations")
def configuration_update(
    ctx: DxsContext,
    config_type: str,
    config_id: int,
    data_file: Path,
    branch: int | None,
) -> None:
    """Update a platform configuration via PUT with a body read from a file.

    The body is read from disk (no shell escaping), so payloads with embedded
    \\r\\n sequences, nested quotes, or large flow code blocks round-trip
    cleanly.

    \b
    Examples:
        dxs configuration update hub 8642750 -b 64 -D hub.json
        dxs configuration update flow 12345 -b 64 -D flow_body.json
    """
    config_type = _validate_type(config_type)
    branch_id = resolve_branch(ctx, branch, "DXS-CFG-010")

    body = _load_body(data_file)
    api_client = ApiClient()
    path = ConfigurationEndpoints.update(branch_id, config_type, config_id)
    response = api_client.put(path, data=body)

    ctx.output(
        single(
            item={
                "id": config_id,
                "type": config_type,
                "branch_id": branch_id,
                "source_file": str(data_file),
                "response": response,
            },
            semantic_key="configuration_update",
        )
    )


@configuration.command("list")
@click.argument("config_type")
@click.option("--branch", "-b", type=int, default=None, help="Branch ID (falls back to global -b)")
@pass_context
@require_auth
def configuration_list(
    ctx: DxsContext,
    config_type: str,
    branch: int | None,
) -> None:
    """List configurations of a given type on a branch.

    \b
    Examples:
        dxs configuration list hub -b 64
        dxs configuration list flow -b 64
    """
    config_type = _validate_type(config_type)
    branch_id = resolve_branch(ctx, branch, "DXS-CFG-010")

    api_client = ApiClient()
    path = ConfigurationEndpoints.list_all(branch_id, config_type)
    body = api_client.get(path)

    ctx.output(single(item=body, semantic_key="configurations"))


@configuration.command("delete")
@click.argument("config_type")
@click.argument("config_id", type=int)
@click.option("--branch", "-b", type=int, default=None, help="Branch ID (falls back to global -b)")
@click.option("--yes", "-y", is_flag=True, help="Skip the confirmation prompt.")
@pass_context
@require_auth
@restrict_in_restricted_mode("deletes platform configurations")
def configuration_delete(
    ctx: DxsContext,
    config_type: str,
    config_id: int,
    branch: int | None,
    yes: bool,
) -> None:
    """Delete a platform configuration by type and ID."""
    config_type = _validate_type(config_type)
    branch_id = resolve_branch(ctx, branch, "DXS-CFG-010")

    if not yes:
        click.confirm(
            f"Delete {config_type} configuration {config_id} on branch {branch_id}?",
            abort=True,
        )

    api_client = ApiClient()
    path = ConfigurationEndpoints.update(branch_id, config_type, config_id)
    api_client.delete(path)

    ctx.output(
        single(
            item={
                "id": config_id,
                "type": config_type,
                "branch_id": branch_id,
                "deleted": True,
            },
            semantic_key="configuration_delete",
        )
    )
