"""Datasource configuration commands.

Commands for generating, enhancing, and uploading Datex datasource
configurations from OData queries in a single step.
"""

import json as json_lib
from pathlib import Path
from typing import Any

import click
import yaml

from dxs.cli import DxsContext, handle_errors, pass_context
from dxs.core.api.client import ApiClient
from dxs.core.api.endpoints import ConfigurationEndpoints
from dxs.core.auth import require_auth
from dxs.core.datasource import DatasourceGenerator
from dxs.core.datasource.models import (
    DatasourceConfig,
    DSDynamicOrderByConfig,
    DSLinkedDatasourceConfig,
    DSValueConfig,
    TypeConfig,
)
from dxs.core.datasource.parsers import (
    apply_enhancements,
    apply_param_filters,
    cb_custom_column,
    cb_dynamic_filter,
    cb_dynamic_orderby,
    cb_linked,
    cb_linked_param,
    cb_linked_skip,
    cb_linked_top,
    cb_param_filter,
)
from dxs.core.datasource.resolver import apply_linked_params, resolve_linked_ds_metadata
from dxs.core.datasource.validator import DatasourceValidator
from dxs.utils.click_options import pagination_options
from dxs.utils.click_options import resolve_branch as _resolve_branch
from dxs.utils.errors import DxsError, ValidationError
from dxs.utils.responses import list_response, single

_MAX_FLOW_FILE_BYTES = 512 * 1024  # 512 KB


def _read_file(path: str, label: str) -> str:
    """Read a text file with proper error handling."""
    p = Path(path)
    try:
        size = p.stat().st_size
    except OSError as e:
        raise ValidationError(
            message=f"Cannot read {label} file '{path}': {e}",
            code="DXS-DS-001",
            suggestions=["Verify the file path is correct", "Check file permissions"],
        ) from None
    if size > _MAX_FLOW_FILE_BYTES:
        raise ValidationError(
            message=f"{label} file '{path}' is {size // 1024} KB, exceeds 512 KB limit",
            code="DXS-DS-002",
            suggestions=["Reduce file size to under 512 KB", "Split into smaller files"],
        )
    try:
        return p.read_text(encoding="utf-8")
    except OSError as e:
        raise ValidationError(
            message=f"Cannot read {label} file '{path}': {e}",
            code="DXS-DS-001",
            suggestions=["Verify the file path is correct", "Check file permissions"],
        ) from None


def _load_config_json(file: str) -> dict[str, Any]:
    """Load and parse a datasource config JSON file."""
    try:
        return json_lib.loads(Path(file).read_text(encoding="utf-8"))
    except OSError as e:
        raise ValidationError(
            message=f"Cannot read file '{file}': {e}",
            code="DXS-DS-001",
            suggestions=["Verify the file path is correct", "Check file permissions"],
        ) from None
    except json_lib.JSONDecodeError as e:
        raise ValidationError(
            message=f"Invalid JSON in {file}: {e}",
            code="DXS-DS-003",
            suggestions=[
                "Check JSON syntax (mismatched brackets, trailing commas)",
                "Use a JSON validator",
            ],
        ) from None


def _build_upsert_summary(config: DatasourceConfig) -> dict[str, Any]:
    """Build a summary of the generated datasource configuration."""
    summary: dict[str, Any] = {"result_type": "single" if not config.isCollection else "collection"}
    if config.inParams:
        summary["in_params"] = [
            {"name": p.id, "type": p.type, "required": p.required} for p in config.inParams
        ]
    if config.queryOptionsObjectTypeDef:
        flat = sum(1 for f in config.queryOptionsObjectTypeDef if not f.isCollection)
        collections = sum(1 for f in config.queryOptionsObjectTypeDef if f.isCollection)
        summary["field_count"] = flat
        summary["collection_count"] = collections
    return summary


def _generate_config(
    ctx: DxsContext,
    api_client: ApiClient,
    branch_id: int,
    connection_id: int,
    query: str,
    reference_name: str,
    title: str,
    api_setting_name: str | None,
    description: str | None,
    detect_params: bool,
    param_keys: bool,
    key_param_name: str | None,
    output_single: bool,
    dynamic_filters: tuple[TypeConfig, ...],
    dynamic_orderbys: tuple[DSDynamicOrderByConfig, ...],
    all_dynamic_filters: bool,
    all_dynamic_orderbys: bool,
    linked_datasources: tuple[DSLinkedDatasourceConfig, ...],
    linked_tops: tuple[tuple[str, str], ...],
    linked_skips: tuple[tuple[str, str], ...],
    custom_columns: tuple[DSValueConfig, ...],
    param_filters: tuple[tuple[str, str, str, str], ...],
    linked_params: tuple[tuple[str, str, str], ...],
    is_private: bool,
) -> DatasourceConfig:
    """Run the full generation pipeline: parse, generate, enhance, validate.

    Returns:
        Validated DatasourceConfig ready for serialization.
    """
    if api_setting_name is None:
        from dxs.utils.resolvers import resolve_api_setting_name

        api_setting_name = resolve_api_setting_name(api_client, branch_id, connection_id)
        if api_setting_name is None:
            api_setting_name = "FootPrintAPI"
            ctx.log(
                f"Could not auto-resolve API setting name for connection {connection_id}, "
                f"using default: {api_setting_name}"
            )
        else:
            ctx.log(f"Auto-resolved API setting name: {api_setting_name}")

    generator = DatasourceGenerator(api_client)

    config = generator.generate(
        connection_id=connection_id,
        query=query,
        reference_name=reference_name,
        title=title,
        api_setting_name=api_setting_name,
        description=description,
        detect_params=detect_params,
        param_keys=param_keys,
        key_param_name=key_param_name,
        output_single=output_single,
    )

    for warning in generator.warnings:
        ctx.log(warning)

    if detect_params and not config.inParams:
        ctx.log(
            "Warning: --detect-params found no parameters in the filter expression. "
            "Use template patterns like ${$datasource.inParams.paramName} in your $filter, "
            "or use --param-filter for conditional filtering."
        )

    apply_enhancements(
        config,
        dynamic_filters=dynamic_filters,
        dynamic_orderbys=dynamic_orderbys,
        all_dynamic_filters=all_dynamic_filters,
        all_dynamic_orderbys=all_dynamic_orderbys,
        linked_datasources=linked_datasources,
        linked_tops=linked_tops,
        linked_skips=linked_skips,
        custom_columns=custom_columns,
    )

    if param_filters:
        apply_param_filters(config, param_filters)

    if linked_params:
        apply_linked_params(config, linked_params, api_client, branch_id)

    if is_private:
        config.accessModifier = "private"

    if config.linkedDatasources:
        for link in config.linkedDatasources:
            if link.datasourceConfig.configOutParameters is not None:
                continue
            target_ref = link.datasourceConfig.configId
            try:
                resolve_linked_ds_metadata(api_client, branch_id, link.datasourceConfig)
            except ValidationError:
                ctx.log(
                    f"Warning: Target datasource '{target_ref}' not found on branch {branch_id}. "
                    "The linked reference will be stored but may cause build errors."
                )
            except DxsError as exc:
                ctx.log(f"Warning: Could not verify target datasource '{target_ref}': {exc}")

    DatasourceValidator().validate_and_raise(config.model_dump())

    return config


@click.group()
def datasource() -> None:
    """Datasource configuration generation and management.

    Iterative datasource development workflow:
    1. generate       - Generate OData config -> local JSON file
    2. generate-flow  - Generate flow config -> local JSON file
    3. context        - Get $entity/$ccentity type definitions for expressions
    4. validate       - Validate config against the branch (server-side)
    5. upsert         - Upload config file to the branch

    \b
    Other subcommands:
        get          Retrieve an existing datasource by reference name
        list         List all datasources on a branch
        delete       Delete a datasource from a branch
    """
    pass


@datasource.command()
@click.option(
    "--connection-id",
    "-c",
    type=int,
    required=True,
    help="FootPrint API connection ID for schema/metadata lookup",
)
@click.option(
    "--query",
    "-q",
    type=str,
    required=False,
    default=None,
    help="OData query string (all $expand clauses MUST include $select with a field list)",
)
@click.option(
    "--query-file",
    "-Q",
    type=click.Path(exists=True),
    default=None,
    help="Path to file containing OData query string (alternative to -q)",
)
@click.option(
    "--reference-name",
    "-r",
    type=str,
    required=True,
    help="Unique datasource reference name (valid JS identifier)",
)
@click.option(
    "--title",
    "-t",
    type=str,
    required=True,
    help="Display title",
)
@click.option(
    "--description",
    "-d",
    type=str,
    default=None,
    help="Description of the datasource purpose",
)
@click.option(
    "--api-setting-name",
    type=str,
    default=None,
    help="API connection setting name (auto-resolved from branch settings if omitted)",
)
@click.option(
    "--param-keys",
    is_flag=True,
    default=False,
    help="Convert key segment values to input parameters",
)
@click.option(
    "--key-param-name",
    type=str,
    default=None,
    help="Custom parameter name for key",
)
@click.option(
    "--detect-params",
    is_flag=True,
    default=False,
    help="Auto-detect input parameters from filter expressions",
)
@click.option(
    "--dynamic-filter",
    "dynamic_filters",
    multiple=True,
    metavar="PROPERTY:TYPE",
    callback=cb_dynamic_filter,
    help=(
        "Add dynamic filter. Format: property:type (type: string|number|date|boolean). Repeatable."
    ),
)
@click.option(
    "--dynamic-orderby",
    "dynamic_orderbys",
    multiple=True,
    metavar="PROPERTY",
    callback=cb_dynamic_orderby,
    help="Add dynamic orderby. Use dot notation for nested: Owner.Name. Repeatable.",
)
@click.option(
    "--linked",
    "linked_datasources",
    multiple=True,
    metavar="NAME:TYPE:TARGET[:MERGE_BY]",
    callback=cb_linked,
    help=(
        "Add linked datasource. Format: NAME:TYPE:TARGET[:MERGE_BY] "
        "(type: oneToOne|oneToMany|oneToOneWithMerge; "
        "MERGE_BY required only for oneToOneWithMerge). Repeatable."
    ),
)
@click.option(
    "--custom-column",
    "custom_columns",
    multiple=True,
    metavar="NAME:TYPE:EXPRESSION",
    callback=cb_custom_column,
    help=(
        "Add custom computed column. Format: name:type:expression "
        "(splits on first 2 colons). Repeatable."
    ),
)
@click.option(
    "--output-single",
    "output_single",
    is_flag=True,
    default=False,
    help="Set outputResultAsSingleObject=True (single-entity result pattern).",
)
@click.option(
    "--all-dynamic-filters",
    "all_dynamic_filters",
    is_flag=True,
    default=False,
    help="Set allSelectedIsDynamicFilters=True (treat all result fields as potential filters).",
)
@click.option(
    "--all-dynamic-orderbys",
    "all_dynamic_orderbys",
    is_flag=True,
    default=False,
    help="Set allSelectedIsDynamicOrderBys=True (treat all result fields as potential orderbys).",
)
@click.option(
    "--linked-top",
    "linked_tops",
    multiple=True,
    metavar="NAME:VALUE",
    callback=cb_linked_top,
    help=(
        "Set top limit on a named linked datasource. "
        "Format: name:value (sets hasTop=True, top=value). Repeatable."
    ),
)
@click.option(
    "--linked-skip",
    "linked_skips",
    multiple=True,
    metavar="NAME:VALUE",
    callback=cb_linked_skip,
    help=(
        "Set skip offset on a named linked datasource. "
        "Format: name:value (sets hasSkip=True, skip=value). Repeatable."
    ),
)
@click.option(
    "--param-filter",
    "param_filters",
    multiple=True,
    metavar="PROPERTY:OPERATOR:PARAM:TYPE",
    callback=cb_param_filter,
    help=(
        "Add parameterized conditional filter. "
        "Format: property:operator:param_name:type. "
        "Operators: eq,ne,gt,ge,lt,le,in,contains,startswith,endswith. Repeatable."
    ),
)
@click.option(
    "--linked-param",
    "linked_params",
    multiple=True,
    metavar="LINKED:PARAM:EXPRESSION",
    callback=cb_linked_param,
    help="Map linked DS parameter value. Format: 'linked_name:param_id:expression'. Repeatable.",
)
@click.option(
    "--private",
    "is_private",
    is_flag=True,
    default=False,
    help="Set access modifier to private (default: public).",
)
@click.option(
    "--show-fields",
    is_flag=True,
    default=False,
    help="Include field summary in output (field counts, input params, result type).",
)
@click.option(
    "--branch",
    "-b",
    type=int,
    default=None,
    help="Branch ID (falls back to global -b)",
)
@click.option(
    "-o",
    "--output",
    "output_file",
    type=click.Path(),
    required=True,
    help="Output JSON file path",
)
@pass_context
@require_auth
@handle_errors
def generate(
    ctx: DxsContext,
    connection_id: int,
    query: str | None,
    query_file: str | None,
    reference_name: str,
    title: str,
    description: str | None,
    api_setting_name: str | None,
    param_keys: bool,
    key_param_name: str | None,
    detect_params: bool,
    dynamic_filters: tuple[TypeConfig, ...],
    dynamic_orderbys: tuple[DSDynamicOrderByConfig, ...],
    linked_datasources: tuple[DSLinkedDatasourceConfig, ...],
    custom_columns: tuple[DSValueConfig, ...],
    output_single: bool,
    all_dynamic_filters: bool,
    all_dynamic_orderbys: bool,
    linked_tops: tuple[tuple[str, str], ...],
    linked_skips: tuple[tuple[str, str], ...],
    param_filters: tuple[tuple[str, str, str, str], ...],
    linked_params: tuple[tuple[str, str, str], ...],
    is_private: bool,
    show_fields: bool,
    branch: int | None,
    output_file: str,
) -> None:
    """Generate a datasource configuration and write it to a local JSON file.

    Performs the full generation pipeline (parse, generate, enhance, validate)
    without uploading to a branch. The result is written as JSON to the
    specified output file.

    \b
    REQUIREMENTS:
    1. All $expand clauses MUST include $select with explicit field list
    2. Provide --description to document the datasource purpose (recommended)
    3. Reference names must be valid JavaScript identifiers
    \b
    Examples:
      # Generate to file
      dxs datasource generate -c 1 -r ds_orders -t "Orders" -d "Order list" \\
        -q 'Orders?$select=Id,Name&$top=10' --branch 123 -o ds_orders.json
      #
      # With dynamic filters
      dxs datasource generate -c 1 -r ds_orders -t "Orders" -d "With status" \\
        -q 'Orders?$select=Id,StatusId' --dynamic-filter StatusId:number \\
        --branch 123 -o ds_orders.json
    """
    if query and query_file:
        raise ValidationError(
            message="Use either --query/-q or --query-file/-Q, not both.",
            code="DXS-DS-010",
            suggestions=[
                "Use --query/-q for inline queries or --query-file/-Q for file-based queries"
            ],
        )
    if query_file:
        query = _read_file(query_file, "--query-file").strip()
    if not query:
        raise ValidationError(
            message="Provide either --query/-q or --query-file/-Q.",
            code="DXS-DS-011",
            suggestions=[
                "Provide an OData query with --query/-q or --query-file/-Q",
                "See examples: dxs datasource generate --help",
            ],
        )

    ctx.log(f"Generating datasource configuration for: {query[:80]}...")

    branch_id = _resolve_branch(ctx, branch, "DXS-DS-020")

    api_client = ApiClient()

    config = _generate_config(
        ctx=ctx,
        api_client=api_client,
        branch_id=branch_id,
        connection_id=connection_id,
        query=query,
        reference_name=reference_name,
        title=title,
        api_setting_name=api_setting_name,
        description=description,
        detect_params=detect_params,
        param_keys=param_keys,
        key_param_name=key_param_name,
        output_single=output_single,
        dynamic_filters=dynamic_filters,
        dynamic_orderbys=dynamic_orderbys,
        all_dynamic_filters=all_dynamic_filters,
        all_dynamic_orderbys=all_dynamic_orderbys,
        linked_datasources=linked_datasources,
        linked_tops=linked_tops,
        linked_skips=linked_skips,
        custom_columns=custom_columns,
        param_filters=param_filters,
        linked_params=linked_params,
        is_private=is_private,
    )

    config_dict = config.model_dump(by_alias=True, mode="python", exclude_none=False)
    output_path = Path(output_file)
    output_path.write_text(json_lib.dumps(config_dict, indent=2, default=str), encoding="utf-8")

    output_item: dict[str, Any] = {
        "referenceName": reference_name,
        "title": title,
        "output_file": str(output_path),
        "action": "generated",
    }
    if show_fields:
        output_item["fields"] = _build_upsert_summary(config)

    ctx.output(single(item=output_item, semantic_key="datasource"))


@datasource.command()
@click.argument("file", type=click.Path(exists=True))
@click.option("--branch", "-b", type=int, default=None, help="Branch ID (falls back to global -b)")
@pass_context
@require_auth
@handle_errors
def upsert(ctx: DxsContext, file: str, branch: int | None) -> None:
    """Upload a datasource configuration file to a branch.

    Reads a local datasource config JSON file (produced by 'dxs datasource generate')
    and performs an upsert (create or update) on the target branch.

    \b
    Example:
        dxs datasource upsert ds_orders.json --branch 123
    """
    branch_id = _resolve_branch(ctx, branch, "DXS-DS-020")

    config_data = _load_config_json(file)

    reference_name = config_data.get("referenceName")
    if not reference_name:
        raise ValidationError(
            message=f"File {file} is missing 'referenceName'. Use 'dxs datasource generate' to create valid config files.",
            code="DXS-DS-012",
            suggestions=[
                "Use 'dxs datasource generate' to create a valid config file",
                "Manually add 'referenceName' to the JSON",
            ],
        )

    api_client = ApiClient()

    from dxs.utils.resolvers import upsert_config

    _response, action = upsert_config(
        api_client, branch_id, "datasource", reference_name, config_data
    )

    ctx.output(
        single(
            item={
                "referenceName": reference_name,
                "title": config_data.get("title", ""),
                "branch_id": branch_id,
                "action": action,
            },
            semantic_key="datasource",
        )
    )


@datasource.command(name="generate-flow")
@click.option(
    "--reference-name",
    "-r",
    type=str,
    required=True,
    help="Unique datasource reference name (valid JS identifier)",
)
@click.option(
    "--title",
    "-t",
    type=str,
    required=True,
    help="Display title",
)
@click.option(
    "--description",
    "-d",
    type=str,
    default=None,
    help="Description of the datasource purpose",
)
@click.option(
    "--get-flow",
    type=click.Path(exists=True),
    default=None,
    help="File path to get method code",
)
@click.option(
    "--get-list-flow",
    type=click.Path(exists=True),
    default=None,
    help="File path to getList method code",
)
@click.option(
    "--get-by-keys-flow",
    type=click.Path(exists=True),
    default=None,
    help="File path to getByKeys method code",
)
@click.option(
    "--on-init-flow",
    type=click.Path(exists=True),
    default=None,
    help="File path to onInit code",
)
@click.option(
    "--type-def",
    type=click.Path(exists=True),
    required=True,
    help="YAML/JSON file defining output type shape",
)
@click.option(
    "--in-param",
    "in_params",
    multiple=True,
    metavar="NAME:TYPE",
    help="Input parameter (name:type, name:type?, name:type[], name:type[]?). Repeatable.",
)
@click.option(
    "--key",
    "keys",
    multiple=True,
    metavar="NAME:TYPE",
    help="Key field name:type. Repeatable.",
)
@click.option(
    "--collection",
    "is_collection",
    is_flag=True,
    default=False,
    help="Set resultIsCollection=true",
)
@click.option(
    "--single",
    "is_single",
    is_flag=True,
    default=False,
    help="Set resultIsCollection=false",
)
@click.option(
    "--dynamic-filter",
    "dynamic_filters",
    multiple=True,
    metavar="PROPERTY:TYPE",
    callback=cb_dynamic_filter,
    help=(
        "Add dynamic filter. Format: property:type (type: string|number|date|boolean). Repeatable."
    ),
)
@click.option(
    "--dynamic-orderby",
    "dynamic_orderbys",
    multiple=True,
    metavar="PROPERTY",
    callback=cb_dynamic_orderby,
    help="Add dynamic orderby. Use dot notation for nested: Owner.Name. Repeatable.",
)
@click.option(
    "--linked",
    "linked_datasources",
    multiple=True,
    metavar="NAME:TYPE:TARGET[:MERGE_BY]",
    callback=cb_linked,
    help=(
        "Add linked datasource. Format: NAME:TYPE:TARGET[:MERGE_BY] "
        "(type: oneToOne|oneToMany|oneToOneWithMerge; "
        "MERGE_BY required only for oneToOneWithMerge). Repeatable."
    ),
)
@click.option(
    "--custom-column",
    "custom_columns",
    multiple=True,
    metavar="NAME:TYPE:EXPRESSION",
    callback=cb_custom_column,
    help=(
        "Add custom computed column. Format: name:type:expression "
        "(splits on first 2 colons). Repeatable."
    ),
)
@click.option(
    "--all-dynamic-filters",
    "all_dynamic_filters",
    is_flag=True,
    default=False,
    help="Set allSelectedIsDynamicFilters=True (treat all result fields as potential filters).",
)
@click.option(
    "--all-dynamic-orderbys",
    "all_dynamic_orderbys",
    is_flag=True,
    default=False,
    help="Set allSelectedIsDynamicOrderBys=True (treat all result fields as potential orderbys).",
)
@click.option(
    "--linked-top",
    "linked_tops",
    multiple=True,
    metavar="NAME:VALUE",
    callback=cb_linked_top,
    help=(
        "Set top limit on a named linked datasource. "
        "Format: name:value (sets hasTop=True, top=value). Repeatable."
    ),
)
@click.option(
    "--linked-skip",
    "linked_skips",
    multiple=True,
    metavar="NAME:VALUE",
    callback=cb_linked_skip,
    help=(
        "Set skip offset on a named linked datasource. "
        "Format: name:value (sets hasSkip=True, skip=value). Repeatable."
    ),
)
@click.option(
    "--linked-param",
    "linked_params",
    multiple=True,
    metavar="LINKED:PARAM:EXPRESSION",
    callback=cb_linked_param,
    help="Map linked DS parameter value. Format: 'linked_name:param_id:expression'. Repeatable.",
)
@click.option(
    "--private",
    "is_private",
    is_flag=True,
    default=False,
    help="Set access modifier to private (default: public).",
)
@click.option(
    "--show-fields",
    is_flag=True,
    default=False,
    help="Include field summary in output (field counts, input params, result type).",
)
@click.option(
    "--branch",
    "-b",
    type=int,
    default=None,
    help="Branch ID (falls back to global -b)",
)
@click.option(
    "-o",
    "--output",
    "output_file",
    type=click.Path(),
    required=True,
    help="Output JSON file path",
)
@pass_context
@require_auth
@handle_errors
def generate_flow(
    ctx: DxsContext,
    reference_name: str,
    title: str,
    description: str | None,
    get_flow: str | None,
    get_list_flow: str | None,
    get_by_keys_flow: str | None,
    on_init_flow: str | None,
    type_def: str,
    in_params: tuple[str, ...],
    keys: tuple[str, ...],
    is_collection: bool,
    is_single: bool,
    dynamic_filters: tuple[TypeConfig, ...],
    dynamic_orderbys: tuple[DSDynamicOrderByConfig, ...],
    linked_datasources: tuple[DSLinkedDatasourceConfig, ...],
    custom_columns: tuple[DSValueConfig, ...],
    all_dynamic_filters: bool,
    all_dynamic_orderbys: bool,
    linked_tops: tuple[tuple[str, str], ...],
    linked_skips: tuple[tuple[str, str], ...],
    linked_params: tuple[tuple[str, str, str], ...],
    is_private: bool,
    show_fields: bool,
    branch: int | None,
    output_file: str,
) -> None:
    """Generate a flow-based datasource configuration and write it to a local JSON file.

    Flow datasources use custom JavaScript code for data retrieval instead
    of OData queries. Provide code files for one or more flow methods
    (get, getList, getByKeys) and a type definition file describing the
    output shape.

    \b
    REQUIREMENTS:
    1. At least one flow method (--get-flow, --get-list-flow, --get-by-keys-flow)
    2. A type definition file (--type-def) in YAML or JSON format
    3. Reference names must be valid JavaScript identifiers
    \b
    Examples:
      # Simple get flow
      dxs datasource generate-flow -r ds_lookup -t "Lookup" \\
        --type-def types.yaml --get-flow get.ts --branch 123 -o ds_lookup.json
      #
      # Collection with getList and getByKeys
      dxs datasource generate-flow -r ds_items -t "Items" --collection \\
        --type-def types.yaml --get-list-flow getList.ts \\
        --get-by-keys-flow getByKeys.ts --key Id:number --branch 123 -o ds_items.json
      #
      # With input parameters
      dxs datasource generate-flow -r ds_detail -t "Detail" \\
        --type-def types.yaml --get-flow get.ts \\
        --in-param id:number --in-param search:string? --branch 123 -o ds_detail.json
    """
    from dxs.core.datasource.flow_generator import FlowDatasourceGenerator
    from dxs.core.designer.parsers import parse_param, parse_type_def

    # 1. Validate mutual exclusivity
    if is_collection and is_single:
        raise ValidationError(
            message="--collection and --single are mutually exclusive",
            code="DXS-DS-013",
            suggestions=[
                "Use --collection for collection result or --single for single entity, not both"
            ],
        )

    # Determine result_is_collection (None = auto-detect in generator)
    result_is_collection: bool | None = None
    if is_collection:
        result_is_collection = True
    elif is_single:
        result_is_collection = False

    # 2. Resolve branch
    branch_id = _resolve_branch(ctx, branch, "DXS-DS-020")

    ctx.log(f"Generating flow datasource configuration: {reference_name}")

    # 3. Read files (command layer handles I/O)
    get_flow_code = _read_file(get_flow, "--get-flow") if get_flow else None
    get_list_flow_code = _read_file(get_list_flow, "--get-list-flow") if get_list_flow else None
    get_by_keys_flow_code = (
        _read_file(get_by_keys_flow, "--get-by-keys-flow") if get_by_keys_flow else None
    )
    on_init_flow_code = _read_file(on_init_flow, "--on-init-flow") if on_init_flow else None

    type_def_text = _read_file(type_def, "--type-def")
    try:
        type_def_raw = yaml.safe_load(type_def_text)
    except yaml.YAMLError as e:
        raise ValidationError(
            message=f"Invalid YAML in {type_def}: {e}",
            code="DXS-DS-004",
            suggestions=["Check YAML syntax (indentation, colons, quotes)", "Use a YAML validator"],
        ) from None
    if not isinstance(type_def_raw, list):
        raise ValidationError(
            message=f"--type-def must contain a YAML/JSON list of type definitions, got {type(type_def_raw).__name__}",
            code="DXS-DS-005",
            suggestions=[
                "Ensure --type-def file contains a top-level list/array",
                "Example: [{id: Id, type: number}, ...]",
            ],
        )
    try:
        type_def_parsed = parse_type_def(type_def_raw)
    except ValueError as e:
        raise ValidationError(
            message=str(e),
            code="DXS-DS-006",
            suggestions=[
                "Check type definition format",
                "See: dxs datasource generate-flow --help",
            ],
        ) from None

    # 4. Parse --in-param
    parsed_in_params: list[tuple[str, str, bool, bool]] | None = None
    if in_params:
        parsed_in_params = [parse_param(p) for p in in_params]

    # 5. Parse --key
    parsed_keys: list[tuple[str, str]] | None = None
    if keys:
        parsed_keys = []
        for k in keys:
            parts = k.split(":", 1)
            if len(parts) != 2 or not parts[0] or not parts[1]:
                raise ValidationError(
                    message=f"--key must be 'name:type', got: {k!r}",
                    code="DXS-DS-014",
                    suggestions=[
                        "Format: name:type (e.g. Id:number)",
                        "Use --key Id:number --key Code:string",
                    ],
                )
            parsed_keys.append((parts[0], parts[1]))

    # 6. Generate config
    generator = FlowDatasourceGenerator()
    try:
        config = generator.generate(
            reference_name=reference_name,
            title=title,
            type_def=type_def_parsed,
            get_flow_code=get_flow_code,
            get_list_flow_code=get_list_flow_code,
            get_by_keys_flow_code=get_by_keys_flow_code,
            on_init_flow_code=on_init_flow_code,
            in_params=parsed_in_params,
            key_defs=parsed_keys,
            result_is_collection=result_is_collection,
            description=description,
        )
    except ValueError as e:
        raise ValidationError(
            message=str(e),
            code="DXS-DS-007",
            suggestions=["Verify type definitions, flow code, and parameters"],
        ) from None

    # 7. Apply enhancements (shared, no param_filters)
    apply_enhancements(
        config,
        dynamic_filters=dynamic_filters,
        dynamic_orderbys=dynamic_orderbys,
        all_dynamic_filters=all_dynamic_filters,
        all_dynamic_orderbys=all_dynamic_orderbys,
        linked_datasources=linked_datasources,
        linked_tops=linked_tops,
        linked_skips=linked_skips,
        custom_columns=custom_columns,
    )

    # 8. Handle linked params
    api_client = ApiClient()

    if linked_params:
        apply_linked_params(config, linked_params, api_client, branch_id)

    # 9. Private flag
    if is_private:
        config.accessModifier = "private"

    # 10. Resolve linked DS metadata
    if config.linkedDatasources:
        for link in config.linkedDatasources:
            if link.datasourceConfig.configOutParameters is not None:
                continue
            target_ref = link.datasourceConfig.configId
            try:
                resolve_linked_ds_metadata(api_client, branch_id, link.datasourceConfig)
            except ValidationError:
                ctx.log(
                    f"Warning: Target datasource '{target_ref}' not found on branch {branch_id}. "
                    "The linked reference will be stored but may cause build errors."
                )
            except DxsError as exc:
                ctx.log(f"Warning: Could not verify target datasource '{target_ref}': {exc}")

    # 11. Validate the final configuration
    DatasourceValidator().validate_and_raise(config.model_dump())

    # Serialize to JSON
    config_dict = config.model_dump(by_alias=True, mode="python", exclude_none=False)
    output_path = Path(output_file)
    output_path.write_text(json_lib.dumps(config_dict, indent=2, default=str), encoding="utf-8")

    output_item: dict[str, Any] = {
        "referenceName": reference_name,
        "title": title,
        "output_file": str(output_path),
        "action": "generated",
        "type": "flows",
    }
    if show_fields:
        output_item["fields"] = _build_upsert_summary(config)

    ctx.output(single(item=output_item, semantic_key="datasource"))


def _format_validation_source(source: list[dict[str, Any]]) -> str:
    """Flatten validation source breadcrumb to readable string."""
    parts = []
    for s in source:
        parts.append(s.get("configType", "Unknown"))
        parts.append(s.get("configId", "?"))
    return " > ".join(parts)


def _annotate_validation_error(error: dict[str, Any]) -> dict[str, str]:
    """Format a validation error, annotating known benign warnings."""
    source = _format_validation_source(error.get("source", []))
    message = error.get("message", "Unknown error")
    if "Outdated contract" in message:
        message += (
            " (This is typically benign for freshly generated configs. "
            "Re-generate the datasource to sync contracts.)"
        )
    return {"source": source, "message": message}


@datasource.command(name="validate")
@click.argument("file", type=click.Path(exists=True))
@click.option("--branch", "-b", type=int, default=None, help="Branch ID (falls back to global -b)")
@pass_context
@require_auth
@handle_errors
def validate_cmd(ctx: DxsContext, file: str, branch: int | None) -> None:
    """Validate a datasource config file against a branch.

    Reads a local JSON file and POSTs to the validate API. Returns errors
    or confirms the config is valid.

    \b
    Example:
        dxs datasource validate ds_bol.json --branch 64
    """
    branch_id = _resolve_branch(ctx, branch, "DXS-DS-020")

    config_data = _load_config_json(file)

    api_client = ApiClient()
    response = api_client.post(
        ConfigurationEndpoints.validate_config(branch_id, "datasource"),
        data=config_data,
    )

    errors = response if isinstance(response, list) else []

    if not errors:
        ctx.output(
            single(
                item={"status": "valid", "message": "No validation errors"},
                semantic_key="validation_result",
            )
        )
    else:
        formatted_errors = [_annotate_validation_error(e) for e in errors]
        ctx.output(list_response(items=formatted_errors, semantic_key="validation_errors"))


@datasource.command()
@click.argument("file", type=click.Path(exists=True))
@click.option("--branch", "-b", type=int, default=None, help="Branch ID (falls back to global -b)")
@pass_context
@require_auth
@handle_errors
def context(ctx: DxsContext, file: str, branch: int | None) -> None:
    """Get designer contexts (type definitions) for a datasource config file.

    Reads a local datasource config JSON file and POSTs to the contexts API.
    Returns TypeScript type definitions for $entity, $ccentity, $datasource, $flow
    variables -- useful for writing expressions in linked datasources and custom columns.

    \b
    Example:
        dxs datasource context ds_bol.json --branch 64
    """
    branch_id = _resolve_branch(ctx, branch, "DXS-DS-020")

    config_data = _load_config_json(file)

    api_client = ApiClient()
    response = api_client.post(
        ConfigurationEndpoints.contexts(branch_id, "datasource"),
        data=config_data,
    )

    if not response:
        ctx.output(single(item={"designer_contexts": []}, semantic_key="datasource_contexts"))
        return

    designer_contexts = []
    for dc in response.get("designerContexts", []):
        ctx_item: dict[str, Any] = {"id": dc["id"]}
        if dc.get("vars"):
            ctx_item["vars"] = [{"id": v["id"], "type": v["type"]} for v in dc["vars"]]
        if dc.get("text"):
            ctx_item["text"] = dc["text"]
        if dc.get("imports"):
            ctx_item["imports"] = dc["imports"]
        designer_contexts.append(ctx_item)

    output: dict[str, Any] = {"designer_contexts": designer_contexts}
    if response.get("globalContext"):
        output["global_context"] = response["globalContext"]

    ctx.output(single(item=output, semantic_key="datasource_contexts"))


@datasource.command()
@click.argument("reference_name")
@click.option(
    "--branch",
    "-b",
    type=int,
    default=None,
    help="Branch ID (falls back to global -b)",
)
@pass_context
@require_auth
@handle_errors
def get(ctx: DxsContext, reference_name: str, branch: int | None) -> None:
    """Get a datasource configuration by reference name.

    \b
    Example:
        dxs datasource get ds_orders --branch 123
    """
    branch_id = _resolve_branch(ctx, branch, "DXS-DS-020")

    from dxs.utils.resolvers import resolve_config_by_reference

    api_client = ApiClient()
    result = resolve_config_by_reference(api_client, branch_id, "datasource", reference_name)
    ctx.output(single(item=result, semantic_key="datasource"))


@datasource.command(name="list")
@click.option(
    "--branch",
    "-b",
    type=int,
    default=None,
    help="Branch ID (falls back to global -b)",
)
@pagination_options(default_limit=0)
@pass_context
@require_auth
@handle_errors
def list_datasources(ctx: DxsContext, branch: int | None, limit: int) -> None:
    """List all datasource configurations in a branch.

    \b
    Example:
        dxs datasource list --branch 123
    """
    branch_id = _resolve_branch(ctx, branch, "DXS-DS-020")

    api_client = ApiClient()
    result = api_client.get(ConfigurationEndpoints.list_all(branch_id, "datasource"))
    items = result if isinstance(result, list) else result.get("value", [])
    if limit > 0:
        items = items[:limit]
    if not items:
        ctx.log(
            f"No datasources found on branch {branch_id}. "
            "Verify the branch ID is correct with 'dxs source branch list'."
        )
    ctx.output(list_response(items=items, semantic_key="datasources"))


@datasource.command()
@click.argument("reference_name", required=False, default=None)
@click.option(
    "--id",
    "config_id",
    type=int,
    default=None,
    help="Configuration ID (alternative to reference name)",
)
@click.option(
    "--branch",
    "-b",
    type=int,
    default=None,
    help="Branch ID (falls back to global -b)",
)
@pass_context
@require_auth
@handle_errors
def delete(
    ctx: DxsContext, reference_name: str | None, config_id: int | None, branch: int | None
) -> None:
    """Delete a datasource configuration from a branch.

    Provide either a reference name (positional) or --id.

    \b
    Examples:
        dxs datasource delete ds_orders --branch 123
        dxs datasource delete --id 42 --branch 123
    """
    branch_id = _resolve_branch(ctx, branch, "DXS-DS-020")

    if not reference_name and not config_id:
        raise ValidationError(
            message="Provide a reference name or --id.",
            code="DXS-DS-015",
            suggestions=[
                "Provide reference name: dxs datasource delete ds_name -b 123",
                "Or use --id: dxs datasource delete --id 456 -b 123",
            ],
        )

    api_client = ApiClient()

    if config_id is None:
        from dxs.utils.resolvers import resolve_config_by_reference

        existing = resolve_config_by_reference(api_client, branch_id, "datasource", reference_name)
        config_id = existing["id"]

    api_client.delete(ConfigurationEndpoints.delete(branch_id, "datasource", config_id))
    ctx.output(
        single(
            item={
                "referenceName": reference_name or f"id:{config_id}",
                "branch_id": branch_id,
                "action": "deleted",
            },
            semantic_key="datasource",
        )
    )
