"""CLI commands for managing API endpoints on Datex Studio branches.

Endpoints expose flows or datasources as HTTP API routes for API-type applications.
The platform stores all endpoints in a single EndpointsConfiguration (type=26)
per branch. These commands abstract individual endpoint entry management.

Commands:
  add     - Expose a flow or datasource as an API endpoint
  remove  - Remove an endpoint by alias
  update  - Modify an existing endpoint
  list    - List all endpoints on a branch
  get     - Get details of a specific endpoint by alias
"""

import re
from typing import Any

import click

from dxs.cli import DxsContext, handle_errors, pass_context
from dxs.core.api.client import ApiClient
from dxs.core.api.endpoints import (
    BranchEndpoints,
    ConfigurationEndpoints,
    SourceControlEndpoints,
)
from dxs.core.api.models import ApplicationDefinitionType
from dxs.core.auth import require_auth
from dxs.utils.click_options import resolve_branch
from dxs.utils.errors import ApiError, ValidationError
from dxs.utils.responses import list_response, single

_ALIAS_PATTERN = re.compile(r"^[a-zA-Z0-9]+(?:[/\-_~]*[a-zA-Z0-9]+)*$")
_CONFIG_TYPE = "endpoint"
_FLOW_TYPE = "flow"
_DATASOURCE_TYPE = "datasource"


def _require_api_application(api_client: ApiClient, branch_id: int) -> None:
    """Raise ValidationError if the branch is not an API-type application.

    Endpoints are only meaningful for applications with applicationDefinitionTypeId
    equal to ApplicationDefinitionType.API. Running endpoint commands against any
    other application type is a user error and is rejected up-front rather than
    leaking backend errors.
    """
    branch_data = api_client.get(BranchEndpoints.get(branch_id))
    app_def = branch_data.get("applicationDefinition") or {}
    type_id = app_def.get("applicationDefinitionTypeId")
    if type_id != ApplicationDefinitionType.API:
        raise ValidationError(
            message=(
                f"Branch {branch_id} is not an API application "
                "(endpoints apply only to API-type applications)"
            ),
            code="DXS-EP-011",
            suggestions=[
                f"Run 'dxs source branch show {branch_id}' to confirm app type",
                "Pick a branch where appTypeName is 'API'",
            ],
        )


def _verify_target_exists(
    api_client: ApiClient,
    branch_id: int,
    target: str,
    config_type: str,
    module: str | None,
) -> None:
    """Verify the target flow/datasource reference exists on the branch.

    Uses the configurations reference-name lookup; cross-module targets are
    resolved via the module-scoped variant.
    """
    if module:
        path = ConfigurationEndpoints.get_by_module_reference(
            branch_id, config_type, module, target
        )
    else:
        path = ConfigurationEndpoints.get_by_reference(branch_id, config_type, target)
    try:
        api_client.get(path)
    except ApiError as e:
        if e.status_code == 404:
            label = "flow" if config_type == _FLOW_TYPE else "datasource"
            where = f" in module '{module}'" if module else ""
            raise ValidationError(
                message=f"No {label} with reference name '{target}' found on branch {branch_id}{where}",
                code="DXS-EP-009",
                suggestions=[
                    f"Run 'dxs source branch show {branch_id}' to inspect the branch",
                    f"Check the {label} reference name is spelled correctly",
                ],
            ) from e
        raise


def _format_entry(entry: dict[str, Any]) -> dict[str, Any]:
    """Format an endpoint entry for CLI output."""
    ref = entry.get("componentReference", {})
    return {
        "alias": entry["alias"],
        "description": entry.get("description"),
        "type": entry.get("configurationTypeId"),
        "target": ref.get("configId"),
        "module": ref.get("moduleId"),
    }


def _fetch_endpoints_config(api_client: ApiClient, branch_id: int) -> dict[str, Any] | None:
    """Fetch the single EndpointsConfiguration from the branch, or None if missing.

    The API returns a wrapper with metadata at the top level and the actual
    designer config (including the endpoints array) nested under the "json" key.
    This function returns the inner "json" object enriched with the wrapper's "id".
    """
    try:
        config_id: int = api_client.get(
            ConfigurationEndpoints.get_config_id(branch_id, _CONFIG_TYPE)
        )
    except ApiError as e:
        if e.status_code == 404:
            return None
        raise
    # The server returns 200 with body 0 (not 404) when no endpoints config exists.
    if not config_id:
        return None
    wrapper: dict[str, Any] = api_client.get(
        ConfigurationEndpoints.get_content(branch_id, _CONFIG_TYPE, config_id)
    )
    # The designer config lives inside "json"; the wrapper "id" is needed for PUT
    config = wrapper.get("json") or wrapper
    if "id" not in config:
        config["id"] = wrapper.get("id")
    return config


def _find_entry_by_alias(endpoints: list[dict[str, Any]], alias: str) -> dict[str, Any] | None:
    """Find an endpoint entry by alias, or None."""
    for entry in endpoints:
        if entry.get("alias") == alias:
            return entry
    return None


def _find_entry_by_target(
    endpoints: list[dict[str, Any]],
    target: str,
    module: str | None,
    exclude_alias: str | None = None,
) -> dict[str, Any] | None:
    """Find an endpoint entry pointing at (target, module), ignoring exclude_alias."""
    for entry in endpoints:
        if exclude_alias is not None and entry.get("alias") == exclude_alias:
            continue
        ref = entry.get("componentReference") or {}
        if ref.get("configId") == target and ref.get("moduleId") == module:
            return entry
    return None


def _check_unique_target(
    endpoints: list[dict[str, Any]],
    target: str,
    module: str | None,
    exclude_alias: str | None = None,
) -> None:
    """Raise if another endpoint already points at the same (target, module).

    Studio UI enforces that each flow/datasource backs at most one endpoint.
    """
    clash = _find_entry_by_target(endpoints, target, module, exclude_alias)
    if clash is not None:
        raise ValidationError(
            message=(
                f"Target '{target}' is already used by endpoint "
                f"'{clash['alias']}'. Each flow/datasource may back at most one endpoint."
            ),
            code="DXS-EP-008",
            suggestions=[
                f"Remove or retarget endpoint '{clash['alias']}' first",
                "Or pick a different target",
            ],
        )


def _validate_alias(alias: str) -> None:
    """Validate alias format against the URL path pattern."""
    if not _ALIAS_PATTERN.match(alias):
        raise ValidationError(
            message=f"Invalid alias '{alias}': must match {_ALIAS_PATTERN.pattern}",
            code="DXS-EP-001",
            suggestions=[
                "Alias must start and end with alphanumeric characters",
                "Allowed separators: / - _ ~",
            ],
        )


def _make_entry(
    alias: str,
    description: str,
    config_type: str,
    target: str,
    module: str | None = None,
) -> dict[str, Any]:
    """Build an endpoint entry dict."""
    return {
        "configurationTypeId": config_type,
        "description": description,
        "alias": alias,
        "componentReference": {
            "configId": target,
            "moduleId": module,
            "isOwned": None,
        },
    }


def _lock_config(api_client: ApiClient, branch_id: int, ref_name: str) -> None:
    """Lock the endpoints config. Ignores already-locked-by-us errors."""
    try:
        api_client.post(SourceControlEndpoints.lock_config(branch_id, ref_name))
    except ApiError as e:
        body = e.details.get("body") if isinstance(e.details, dict) else None
        message = body.get("message", "") if isinstance(body, dict) else ""
        if e.status_code == 400 and "already locked" in message.lower():
            return
        raise


def _save_config(
    api_client: ApiClient,
    branch_id: int,
    config: dict[str, Any] | None,
    endpoints: list[dict[str, Any]],
) -> tuple[Any, str]:
    """Save the endpoints config — PUT to update, POST to create."""
    if config is not None:
        ref_name = config["referenceName"]
        _lock_config(api_client, branch_id, ref_name)
        config["endpoints"] = endpoints
        try:
            response = api_client.put(
                ConfigurationEndpoints.update(branch_id, _CONFIG_TYPE, config["id"]),
                data=config,
            )
        except ApiError:
            try:
                api_client.post(SourceControlEndpoints.unlock_config(branch_id, ref_name))
            except ApiError:
                pass
            raise
        return response, "updated"
    else:
        new_config = {
            "configurationTypeId": 26,
            "referenceName": "endpoints",
            "title": "Endpoints",
            "endpoints": endpoints,
        }
        response = api_client.post(
            ConfigurationEndpoints.create(branch_id, _CONFIG_TYPE),
            data=new_config,
        )
        return response, "created"


@click.group()
def endpoint() -> None:
    """Manage API endpoints on a branch.

    Endpoints expose flows or datasources as HTTP API routes
    for API-type applications.
    """


@endpoint.command(name="list")
@click.option("--branch", "-b", type=int, default=None, help="Branch ID (falls back to global -b)")
@pass_context
@require_auth
@handle_errors
def list_endpoints(ctx: DxsContext, branch: int | None) -> None:
    """List all endpoints on a branch.

    \b
    Example:
        dxs endpoint list --branch 64
    """
    branch_id = resolve_branch(ctx, branch, "DXS-EP-010")
    api_client = ApiClient()
    config = _fetch_endpoints_config(api_client, branch_id)

    entries = config.get("endpoints", []) if config else []
    items = [_format_entry(e) for e in entries]
    ctx.output(list_response(items=items, semantic_key="endpoints"))


@endpoint.command()
@click.option("--alias", required=True, help="Endpoint alias to look up")
@click.option("--branch", "-b", type=int, default=None, help="Branch ID (falls back to global -b)")
@pass_context
@require_auth
@handle_errors
def get(ctx: DxsContext, alias: str, branch: int | None) -> None:
    """Get details of a specific endpoint by alias.

    \b
    Example:
        dxs endpoint get --alias orders --branch 64
    """
    branch_id = resolve_branch(ctx, branch, "DXS-EP-010")
    api_client = ApiClient()
    config = _fetch_endpoints_config(api_client, branch_id)

    entries = config.get("endpoints", []) if config else []
    entry = _find_entry_by_alias(entries, alias)
    if entry is None:
        raise ValidationError(
            message=f"No endpoint with alias '{alias}' found on this branch",
            code="DXS-EP-002",
            suggestions=[
                f"Run 'dxs endpoint list --branch {branch_id}' to see available endpoints"
            ],
        )
    ctx.output(single(item=_format_entry(entry), semantic_key="endpoint"))


@endpoint.command()
@click.option("--alias", required=True, help="URL path alias for the endpoint")
@click.option("--flow", "flow_target", default=None, help="Target flow reference name")
@click.option("--datasource", "ds_target", default=None, help="Target datasource reference name")
@click.option("--description", "-d", required=True, help="Endpoint description")
@click.option("--module", default=None, help="Module reference for cross-module targets")
@click.option("--branch", "-b", type=int, default=None, help="Branch ID (falls back to global -b)")
@pass_context
@require_auth
@handle_errors
def add(
    ctx: DxsContext,
    alias: str,
    flow_target: str | None,
    ds_target: str | None,
    description: str,
    module: str | None,
    branch: int | None,
) -> None:
    """Expose a flow or datasource as an API endpoint.

    \b
    Examples:
        dxs endpoint add --alias orders --flow get_orders_flow -d "Get orders" --branch 64
        dxs endpoint add --alias materials --datasource ds_materials -d "Materials" --branch 64
    """
    _validate_alias(alias)

    if flow_target and ds_target:
        raise ValidationError(
            message="Specify exactly one of --flow or --datasource, not both",
            code="DXS-EP-003",
        )
    if not flow_target and not ds_target:
        raise ValidationError(
            message="--flow or --datasource is required",
            code="DXS-EP-004",
            suggestions=[
                "Use --flow <name> for flow targets",
                "Use --datasource <name> for datasource targets",
            ],
        )

    branch_id = resolve_branch(ctx, branch, "DXS-EP-010")
    api_client = ApiClient()
    config = _fetch_endpoints_config(api_client, branch_id)

    # Existence of an endpoints config proves the branch is an API app;
    # only bootstrap (POST-create) requires the explicit type check.
    if config is None:
        _require_api_application(api_client, branch_id)

    entries = list(config.get("endpoints", [])) if config else []

    if _find_entry_by_alias(entries, alias) is not None:
        raise ValidationError(
            message=f"Alias '{alias}' already exists on this branch",
            code="DXS-EP-005",
            suggestions=[f"Use 'dxs endpoint update --alias {alias}' to modify it"],
        )

    target = flow_target or ds_target
    assert target is not None  # validated above
    config_type = _FLOW_TYPE if flow_target else _DATASOURCE_TYPE

    _check_unique_target(entries, target, module)
    _verify_target_exists(api_client, branch_id, target, config_type, module)

    new_entry = _make_entry(alias, description, config_type, target, module)
    entries.append(new_entry)

    _save_config(api_client, branch_id, config, entries)

    result = _format_entry(new_entry)
    result["action"] = "added"
    ctx.output(single(item=result, semantic_key="endpoint"))


@endpoint.command()
@click.option("--alias", required=True, multiple=True, help="Alias(es) to remove (repeatable)")
@click.option("--branch", "-b", type=int, default=None, help="Branch ID (falls back to global -b)")
@pass_context
@require_auth
@handle_errors
def remove(ctx: DxsContext, alias: tuple[str, ...], branch: int | None) -> None:
    """Remove one or more endpoints by alias.

    \b
    Examples:
        dxs endpoint remove --alias orders --branch 64
        dxs endpoint remove --alias orders --alias materials --branch 64
    """
    seen: set[str] = set()
    for a in alias:
        if a in seen:
            raise ValidationError(
                message=f"Alias '{a}' specified multiple times in --alias",
                code="DXS-EP-012",
                suggestions=["Remove the duplicate --alias flag"],
            )
        seen.add(a)

    branch_id = resolve_branch(ctx, branch, "DXS-EP-010")
    api_client = ApiClient()
    config = _fetch_endpoints_config(api_client, branch_id)

    if config is None:
        raise ValidationError(
            message="No endpoints configuration found on this branch",
            code="DXS-EP-006",
        )

    entries = list(config.get("endpoints", []))
    removed: list[dict[str, Any]] = []

    for a in alias:
        entry = _find_entry_by_alias(entries, a)
        if entry is None:
            raise ValidationError(
                message=f"No endpoint with alias '{a}' found on this branch",
                code="DXS-EP-002",
                suggestions=[
                    f"Run 'dxs endpoint list --branch {branch_id}' to see available endpoints"
                ],
            )
        removed.append(_format_entry(entry))
        entries.remove(entry)

    _save_config(api_client, branch_id, config, entries)

    if len(removed) == 1:
        removed[0]["action"] = "removed"
        ctx.output(single(item=removed[0], semantic_key="endpoint"))
    else:
        for r in removed:
            r["action"] = "removed"
        ctx.output(list_response(items=removed, semantic_key="endpoints"))


@endpoint.command()
@click.option("--alias", required=True, help="Current alias of the endpoint to modify")
@click.option("--new-alias", default=None, help="Rename the alias")
@click.option("--flow", "flow_target", default=None, help="Change target to a flow")
@click.option("--datasource", "ds_target", default=None, help="Change target to a datasource")
@click.option("--description", "-d", default=None, help="Change description")
@click.option("--module", default=None, help="Change module reference")
@click.option(
    "--clear-module",
    is_flag=True,
    default=False,
    help="Remove the module reference (mutually exclusive with --module)",
)
@click.option("--branch", "-b", type=int, default=None, help="Branch ID (falls back to global -b)")
@pass_context
@require_auth
@handle_errors
def update(
    ctx: DxsContext,
    alias: str,
    new_alias: str | None,
    flow_target: str | None,
    ds_target: str | None,
    description: str | None,
    module: str | None,
    clear_module: bool,
    branch: int | None,
) -> None:
    """Modify an existing endpoint.

    At least one change flag is required. Use --flow or --datasource to change
    the target (including switching between types).

    \b
    Examples:
        dxs endpoint update --alias orders --description "Fetch all orders" --branch 64
        dxs endpoint update --alias orders --flow get_orders_v2_flow --branch 64
        dxs endpoint update --alias orders --datasource ds_orders --branch 64
        dxs endpoint update --alias orders --new-alias order-list --branch 64
        dxs endpoint update --alias orders --clear-module --branch 64
    """
    if not any([new_alias, flow_target, ds_target, description, module, clear_module]):
        raise ValidationError(
            message=(
                "At least one of --new-alias, --flow, --datasource, "
                "--description, --module, --clear-module is required"
            ),
            code="DXS-EP-007",
        )

    if flow_target and ds_target:
        raise ValidationError(
            message="Specify exactly one of --flow or --datasource, not both",
            code="DXS-EP-003",
        )

    if module and clear_module:
        raise ValidationError(
            message="Specify exactly one of --module or --clear-module, not both",
            code="DXS-EP-013",
        )

    if new_alias:
        _validate_alias(new_alias)

    branch_id = resolve_branch(ctx, branch, "DXS-EP-010")
    api_client = ApiClient()
    config = _fetch_endpoints_config(api_client, branch_id)

    if config is None:
        raise ValidationError(
            message="No endpoints configuration found on this branch",
            code="DXS-EP-006",
        )

    entries = list(config.get("endpoints", []))
    entry = _find_entry_by_alias(entries, alias)
    if entry is None:
        raise ValidationError(
            message=f"No endpoint with alias '{alias}' found on this branch",
            code="DXS-EP-002",
            suggestions=[
                f"Run 'dxs endpoint list --branch {branch_id}' to see available endpoints"
            ],
        )

    if new_alias and new_alias != alias and _find_entry_by_alias(entries, new_alias) is not None:
        raise ValidationError(
            message=f"Alias '{new_alias}' already exists on this branch",
            code="DXS-EP-005",
            suggestions=[
                "Pick a different alias",
                f"Or remove the existing endpoint first: dxs endpoint remove --alias {new_alias}",
            ],
        )

    ref = entry.get("componentReference") or {}
    if flow_target or ds_target or module is not None or clear_module:
        final_target = flow_target or ds_target or ref.get("configId")
        if clear_module:
            final_module = None
        elif module is not None:
            final_module = module
        else:
            final_module = ref.get("moduleId")
        assert final_target is not None
        _check_unique_target(entries, final_target, final_module, exclude_alias=alias)

    if flow_target or ds_target:
        new_target = flow_target or ds_target
        assert new_target is not None
        new_config_type = _FLOW_TYPE if flow_target else _DATASOURCE_TYPE
        if clear_module:
            verify_module: str | None = None
        elif module is not None:
            verify_module = module
        else:
            verify_module = ref.get("moduleId")
        _verify_target_exists(api_client, branch_id, new_target, new_config_type, verify_module)

    # Apply changes
    if new_alias:
        entry["alias"] = new_alias
    if description is not None:
        entry["description"] = description
    if flow_target:
        entry["configurationTypeId"] = _FLOW_TYPE
        entry["componentReference"]["configId"] = flow_target
    elif ds_target:
        entry["configurationTypeId"] = _DATASOURCE_TYPE
        entry["componentReference"]["configId"] = ds_target
    if clear_module:
        entry["componentReference"]["moduleId"] = None
    elif module is not None:
        entry["componentReference"]["moduleId"] = module

    _save_config(api_client, branch_id, config, entries)

    result = _format_entry(entry)
    result["action"] = "updated"
    ctx.output(single(item=result, semantic_key="endpoint"))
