"""Design session manager and report diff logic for the Report Design Canvas."""

from __future__ import annotations

import asyncio
import json
import logging
from pathlib import Path
from typing import Any

from fastapi import FastAPI, WebSocket
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from watchfiles import awatch

logger = logging.getLogger(__name__)


def _collect_items(report: dict[str, Any]) -> dict[str, dict[str, Any]]:
    """Walk ReportSections[*].Body.ReportItems recursively, returning items keyed by Name.

    Rectangles nest child items via their own ``ReportItems`` key; this function
    flattens the entire tree into a single dict.
    """
    result: dict[str, dict[str, Any]] = {}

    def _walk(items: list[dict[str, Any]]) -> None:
        for item in items:
            name = item.get("Name")
            if name is not None:
                result[name] = item
            # Recurse into nested ReportItems (e.g. rectangles)
            nested = item.get("ReportItems")
            if isinstance(nested, list):
                _walk(nested)

    for section in report.get("ReportSections", []):
        body = section.get("Body")
        if body is None:
            continue
        report_items = body.get("ReportItems")
        if isinstance(report_items, list):
            _walk(report_items)

    return result


def compute_diff(old: dict[str, Any] | None, new: dict[str, Any]) -> list[dict[str, Any]]:
    """Compute a list of add/remove/set changes between two report dicts.

    If *old* is ``None`` every item in *new* is treated as an "add".
    Returns an empty list when there are no changes.
    """
    new_items = _collect_items(new)

    if old is None:
        return [
            {"action": "add", "element": name, "type": item.get("Type")}
            for name, item in new_items.items()
        ]

    old_items = _collect_items(old)

    changes: list[dict[str, Any]] = []

    # Removed items
    for name in old_items:
        if name not in new_items:
            changes.append({"action": "remove", "element": name})

    # Added or changed items
    for name, new_item in new_items.items():
        if name not in old_items:
            changes.append({"action": "add", "element": name, "type": new_item.get("Type")})
        else:
            old_item = old_items[name]
            changed_keys: list[str] = []
            all_keys = set(old_item.keys()) | set(new_item.keys())
            for key in sorted(all_keys):
                if old_item.get(key) != new_item.get(key):
                    changed_keys.append(key)
            if changed_keys:
                changes.append({"action": "set", "element": name, "properties": changed_keys})

    return changes


class DesignSessionManager:
    """Manages a single design session: file watching, diffing, and broadcasting."""

    def __init__(self) -> None:
        self.file_path: Path | None = None
        self.last_report: dict[str, Any] | None = None
        self.connections: set[WebSocket] = set()
        self._watch_task: asyncio.Task[None] | None = None
        self.data_file_path: Path | None = None
        self.last_sample_data: dict[str, Any] | None = None
        self._data_watch_task: asyncio.Task[None] | None = None

    async def open(self, path: Path) -> None:
        """Open a report file for the design session.

        Validates the file exists, reads and parses its JSON content,
        stores it as ``last_report``, and starts the file watcher.
        Also loads companion ``.data.json`` if it exists.
        """
        if not path.exists():
            raise FileNotFoundError(f"Report file not found: {path}")

        text = path.read_text(encoding="utf-8")
        self.last_report = json.loads(text)
        self.file_path = path
        self._watch_task = asyncio.create_task(self._watch_loop())

        # Load companion sample data file if it exists
        data_path = path.with_suffix(".data.json")
        self.data_file_path = data_path
        if data_path.exists():
            try:
                data_text = data_path.read_text(encoding="utf-8")
                self.last_sample_data = json.loads(data_text)
            except (json.JSONDecodeError, OSError):
                logger.debug("Failed to load companion data file: %s", data_path)
                self.last_sample_data = None
        else:
            self.last_sample_data = None
        self._data_watch_task = asyncio.create_task(self._data_watch_loop())

        # Broadcast initial state to any already-connected clients
        await self.broadcast(
            {
                "type": "file-opened",
                "report": self.last_report,
                "changes": [],
            }
        )
        if self.last_sample_data is not None:
            await self.broadcast(
                {
                    "type": "sample-data-update",
                    "sampleData": self.last_sample_data,
                }
            )

    async def close(self) -> None:
        """Close the design session, cancel watchers, and broadcast file-closed."""
        if self._watch_task is not None:
            self._watch_task.cancel()
            try:
                await self._watch_task
            except asyncio.CancelledError:
                pass
            self._watch_task = None

        if self._data_watch_task is not None:
            self._data_watch_task.cancel()
            try:
                await self._data_watch_task
            except asyncio.CancelledError:
                pass
            self._data_watch_task = None

        await self.broadcast({"type": "file-closed"})

        self.file_path = None
        self.last_report = None
        self.data_file_path = None
        self.last_sample_data = None

    def add_connection(self, ws: WebSocket) -> None:
        """Register a WebSocket connection."""
        self.connections.add(ws)

    def remove_connection(self, ws: WebSocket) -> None:
        """Unregister a WebSocket connection."""
        self.connections.discard(ws)

    async def broadcast(self, message: dict[str, Any]) -> None:
        """Send a JSON message to all connected WebSockets.

        Dead connections are silently removed on send failure.
        """
        payload = json.dumps(message)
        dead: list[WebSocket] = []
        for ws in self.connections:
            try:
                await ws.send_text(payload)
            except Exception:
                dead.append(ws)
        for ws in dead:
            self.connections.discard(ws)

    async def _watch_loop(self) -> None:
        """Watch the report file for changes and broadcast diffs."""
        assert self.file_path is not None
        async for _changes in awatch(self.file_path, debounce=100):
            try:
                text = self.file_path.read_text(encoding="utf-8")
                new_report = json.loads(text)
            except (json.JSONDecodeError, OSError):
                # Skip update on corrupt read (truncate-then-write race)
                logger.debug("Skipping file update due to read/parse error")
                continue

            diff = compute_diff(self.last_report, new_report)
            self.last_report = new_report
            await self.broadcast({"type": "report-update", "report": new_report, "changes": diff})

    async def _data_watch_loop(self) -> None:
        """Watch the companion .data.json file for changes and broadcast updates."""
        assert self.data_file_path is not None
        # Watch the parent directory and filter for the data file
        async for changes in awatch(self.data_file_path.parent, debounce=100):
            # Only react to changes involving our data file
            data_name = self.data_file_path.name
            relevant = any(Path(path).name == data_name for _, path in changes)
            if not relevant:
                continue

            if not self.data_file_path.exists():
                if self.last_sample_data is not None:
                    self.last_sample_data = None
                    await self.broadcast({"type": "sample-data-update", "sampleData": None})
                continue

            try:
                text = self.data_file_path.read_text(encoding="utf-8")
                new_data = json.loads(text)
            except (json.JSONDecodeError, OSError):
                logger.debug("Skipping data file update due to read/parse error")
                continue

            self.last_sample_data = new_data
            await self.broadcast({"type": "sample-data-update", "sampleData": new_data})


class _OpenRequest(BaseModel):
    path: str


def register_design_routes(app: FastAPI, manager: DesignSessionManager) -> None:
    """Register design session API routes on the given FastAPI app.

    Security: These endpoints have no authentication. The server binds to
    127.0.0.1 only (see ``studio`` command), so access is limited to the
    local machine. This is intentional — ``dxs studio`` is a single-user
    local development tool, not a shared service.
    """

    @app.post("/api/design/open", response_model=None)
    async def design_open(body: _OpenRequest) -> dict[str, Any] | JSONResponse:
        resolved = Path(body.path).resolve()
        # Restrict to .rdlx-json files to prevent arbitrary file reads
        if resolved.suffix != ".rdlx-json":
            return JSONResponse(
                status_code=400,
                content={
                    "status": "error",
                    "message": "Only .rdlx-json files can be opened in the design canvas",
                },
            )
        try:
            await manager.open(resolved)
        except FileNotFoundError as exc:
            return JSONResponse(
                status_code=404,
                content={"status": "error", "message": str(exc)},
            )
        return {"status": "ok", "path": str(resolved)}

    @app.post("/api/design/close")
    async def design_close() -> dict[str, Any]:
        await manager.close()
        return {"status": "ok"}

    @app.get("/api/design/status")
    async def design_status() -> dict[str, Any]:
        return {
            "file": str(manager.file_path) if manager.file_path else None,
            "connections": len(manager.connections),
        }

    @app.get("/api/design/sample-data")
    async def design_get_sample_data() -> dict[str, Any]:
        return {"sampleData": manager.last_sample_data}

    @app.post("/api/design/sample-data")
    async def design_post_sample_data(body: dict[str, Any]) -> dict[str, Any]:
        if manager.data_file_path is None:
            return JSONResponse(
                status_code=400,
                content={"status": "error", "message": "No design session open"},
            )
        # Write to the companion file — the watcher will pick it up and broadcast
        try:
            manager.data_file_path.write_text(json.dumps(body, indent=2), encoding="utf-8")
        except OSError as exc:
            return JSONResponse(
                status_code=500,
                content={"status": "error", "message": str(exc)},
            )
        return {"status": "ok"}

    @app.get("/api/design/export-svg")
    async def design_export_svg() -> JSONResponse:
        if manager.last_report is None:
            return JSONResponse(
                status_code=400,
                content={"status": "error", "message": "No design session open"},
            )
        from dxs.report.svg_renderer import render_report_to_svg

        svg_str = render_report_to_svg(manager.last_report, manager.last_sample_data)
        from starlette.responses import Response

        return Response(content=svg_str, media_type="image/svg+xml")

    @app.websocket("/api/design/ws")
    async def design_ws(websocket: WebSocket) -> None:
        await websocket.accept()
        manager.add_connection(websocket)
        try:
            # Send current state immediately
            await websocket.send_json(
                {
                    "type": "report-update",
                    "report": manager.last_report,
                    "changes": [],
                }
            )
            # Send sample data if available
            if manager.last_sample_data is not None:
                await websocket.send_json(
                    {
                        "type": "sample-data-update",
                        "sampleData": manager.last_sample_data,
                    }
                )
            # Keep alive — read until disconnect
            while True:
                await websocket.receive_text()
        except Exception:
            pass
        finally:
            manager.remove_connection(websocket)
