"""Release notes core utilities.

Sync commit detection, concurrent dependency comparison, work item
aggregation, and contributor extraction for release note generation.
"""

import logging
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any

from dxs.core.api import ApiClient, SourceControlEndpoints, WorkitemEndpoints

logger = logging.getLogger(__name__)

SYNC_TITLE_PATTERN = re.compile(r"^\d{8}\.\d{6}$")


def is_sync_commit(commit: dict[str, Any]) -> bool:
    """True if commit title matches timestamp pattern and has no config changes.

    Sync commits have titles like '20260220.121240' (YYYYMMDD.HHMMSS) and
    contain no configuration changes -- they represent automated syncs from
    the base branch.
    """
    title = commit.get("title") or commit.get("commitTitle") or ""
    if not SYNC_TITLE_PATTERN.match(title):
        return False
    configs = commit.get("configs") or []
    return len(configs) == 0


def compare_dependency(
    client: ApiClient,
    from_branch_id: int,
    to_branch_id: int,
) -> dict[str, Any]:
    """Compare a single dependency pair.

    Fetches commit histories for both branches, finds unique commits in
    to_branch, classifies each as sync or meaningful, and collects work items.

    Returns dict with: committed_branches, commit_count, is_sync_only,
    has_meaningful_changes, workitem_ids
    """
    from_history = client.get(SourceControlEndpoints.branch_history(from_branch_id))
    to_history = client.get(SourceControlEndpoints.branch_history(to_branch_id))

    if not isinstance(from_history, list):
        from_history = [from_history] if from_history else []
    if not isinstance(to_history, list):
        to_history = [to_history] if to_history else []

    from_ids = {c.get("applicationId") for c in from_history if c.get("applicationId")}
    unique_commits = [c for c in to_history if c.get("applicationId") not in from_ids]

    committed_branches: list[dict[str, Any]] = []
    workitem_ids: set[str] = set()
    has_meaningful = False

    for commit in unique_commits:
        commit_id = commit.get("applicationId")
        title = commit.get("commitTitle") or commit.get("title") or ""

        entry: dict[str, Any] = {
            "id": commit_id,
            "title": title,
            "author": commit.get("authorDisplayName"),
        }

        # Fetch changes for this commit
        try:
            changes_data = client.get(SourceControlEndpoints.history_branch_changes(commit_id))
            configs = (
                (changes_data or {}).get("configs", []) if isinstance(changes_data, dict) else []
            )
        except Exception:
            logger.debug("Failed to fetch changes for commit %s", commit_id, exc_info=True)
            configs = []

        entry["configs"] = configs

        if not is_sync_commit({"title": title, "configs": configs}):
            has_meaningful = True

        # Fetch work items for this commit
        try:
            wi_data = client.get(WorkitemEndpoints.list(commit_id))
            if not isinstance(wi_data, list):
                wi_data = [wi_data] if wi_data else []
            for wi in wi_data:
                ext_id = wi.get("externalId")
                if ext_id:
                    workitem_ids.add(ext_id)
        except Exception:
            logger.debug("Failed to fetch work items for commit %s", commit_id, exc_info=True)

        committed_branches.append(entry)

    all_sync = (
        all(
            is_sync_commit({"title": b.get("title", ""), "configs": b.get("configs", [])})
            for b in committed_branches
        )
        if committed_branches
        else False
    )

    return {
        "committed_branches": committed_branches,
        "commit_count": len(committed_branches),
        "is_sync_only": all_sync,
        "has_meaningful_changes": has_meaningful,
        "workitem_ids": list(workitem_ids),
    }


def classify_dependencies(
    client: ApiClient,
    dep_updates: list[dict[str, Any]],
    max_workers: int = 8,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """Classify updated deps into meaningful vs sync-only.

    Uses ThreadPoolExecutor for concurrent API calls.

    Returns (meaningful_deps, sync_only_deps) where each entry is the
    original dep_update dict enriched with comparison results.
    """
    meaningful: list[dict[str, Any]] = []
    sync_only: list[dict[str, Any]] = []

    if not dep_updates:
        return meaningful, sync_only

    def _compare(dep: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
        result = compare_dependency(
            client,
            from_branch_id=dep["from_branch_id"],
            to_branch_id=dep["to_branch_id"],
        )
        return dep, result

    with ThreadPoolExecutor(max_workers=min(len(dep_updates), max_workers)) as executor:
        futures = [executor.submit(_compare, dep) for dep in dep_updates]
        for future in as_completed(futures):
            dep, result = future.result()
            enriched = {**dep, **result}
            if result["is_sync_only"]:
                sync_only.append(enriched)
            else:
                meaningful.append(enriched)

    return meaningful, sync_only


def collect_workitems_batch(
    client: ApiClient,
    branch_ids: list[int],
    max_workers: int = 8,
) -> dict[int, list[dict[str, Any]]]:
    """Fetch work items for multiple branches concurrently.

    Returns {branch_id: [workitem_dicts]}.
    """
    results: dict[int, list[dict[str, Any]]] = {}

    if not branch_ids:
        return results

    def _fetch(bid: int) -> tuple[int, list[dict[str, Any]]]:
        try:
            data = client.get(WorkitemEndpoints.list(bid))
            if not isinstance(data, list):
                data = [data] if data else []
            return bid, data
        except Exception:
            logger.debug("Failed to fetch work items for branch %s", bid, exc_info=True)
            return bid, []

    with ThreadPoolExecutor(max_workers=min(len(branch_ids), max_workers)) as executor:
        futures = [executor.submit(_fetch, bid) for bid in branch_ids]
        for future in as_completed(futures):
            bid, items = future.result()
            results[bid] = items

    return results


def aggregate_contributors(
    committed_branches: list[dict[str, Any]],
    dep_details: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Extract unique contributors with commit counts across all branches.

    Looks at 'author' field in committed_branches and in each
    dep_detail's 'committed_branches' list.
    """
    counts: dict[str, int] = {}

    for branch in committed_branches:
        author = branch.get("author")
        if author:
            counts[author] = counts.get(author, 0) + 1

    for dep in dep_details:
        for branch in dep.get("committed_branches", []):
            author = branch.get("author")
            if author:
                counts[author] = counts.get(author, 0) + 1

    return [{"name": name, "commit_count": count} for name, count in sorted(counts.items())]


def enrich_workitems_with_devops_data(
    workitems_data: list[dict[str, Any]],
    include_description: bool = False,
    include_comments: bool = False,
) -> list[dict[str, Any]]:
    """Enrich ApplicationWorkitem data with Azure DevOps fields.

    Reusable version that uses standard logging instead of CLI context.

    Args:
        workitems_data: List of ApplicationWorkitemDto dictionaries
        include_description: Whether to fetch and include descriptions
        include_comments: Whether to fetch and include comments

    Returns:
        List of enriched work item dictionaries
    """
    from dxs.core.devops.client import AzureDevOpsClient

    if not workitems_data:
        return []

    # Group work items by DevOps organization
    by_org: dict[str, list[dict[str, Any]]] = {}
    items_without_org: list[dict[str, Any]] = []
    for item in workitems_data:
        org = item.get("devOpsOrganization")
        if org:
            by_org.setdefault(org, []).append(item)
        else:
            items_without_org.append(item)

    enriched_items: list[dict[str, Any]] = list(items_without_org)

    for org, org_items in by_org.items():
        logger.info("Fetching %d work items from %s...", len(org_items), org)

        try:
            external_ids = [
                int(ext_id) for item in org_items if (ext_id := item.get("externalId")) is not None
            ]
        except ValueError:
            logger.warning("Invalid work item IDs for organization %s, skipping", org)
            enriched_items.extend(org_items)
            continue

        if not external_ids:
            enriched_items.extend(org_items)
            continue

        fields = [
            "System.Id",
            "System.Title",
            "System.WorkItemType",
            "System.State",
            "System.AssignedTo",
            "System.Tags",
            "System.AreaPath",
            "System.IterationPath",
            "System.CreatedDate",
            "System.ChangedDate",
        ]
        if include_description:
            fields.append("System.Description")

        devops_items_map: dict[str, Any] = {}
        try:
            with AzureDevOpsClient(org) as client:
                for i in range(0, len(external_ids), 200):
                    batch_ids = external_ids[i : i + 200]
                    batch_items = client.get_workitems_batch(batch_ids, fields=fields)

                    if include_comments:
                        for devops_item in batch_items:
                            discussions = client.get_workitem_discussions(devops_item.id)
                            devops_item.discussions = discussions

                    for devops_item in batch_items:
                        devops_items_map[str(devops_item.id)] = devops_item

        except Exception as e:
            logger.warning("Failed to fetch DevOps data for %s: %s", org, e)
            enriched_items.extend(org_items)
            continue

        for app_item in org_items:
            external_id = app_item.get("externalId")
            matched_devops_item = devops_items_map.get(str(external_id))

            if matched_devops_item:
                enriched = {
                    **app_item,
                    "devops_data": matched_devops_item.to_summary(
                        include_description=include_description,
                        include_discussions=include_comments,
                    ),
                }
                enriched_items.append(enriched)
            else:
                logger.warning("Work item %s not found in DevOps", external_id)
                enriched_items.append(
                    {
                        **app_item,
                        "devops_data": None,
                        "warning": f"Work item {external_id} not found in Azure DevOps",
                    }
                )

    return enriched_items
