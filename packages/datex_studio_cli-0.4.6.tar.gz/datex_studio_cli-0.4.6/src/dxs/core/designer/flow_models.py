"""Shared flow node models.

Used by both flow-based datasources (embedded flows) and standalone
functions (configurationTypeId=9).
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel


class FlowExecuteCodeConfig(BaseModel):
    """Inline code configuration for a flow step."""

    code: str


class FlowStepDesignerConfig(BaseModel):
    """Flow step configuration (ExecuteCodeActivity)."""

    type: Literal["ExecuteCodeActivity"] = "ExecuteCodeActivity"
    executeCodeConfig: FlowExecuteCodeConfig
    next: str | None = None
    error: str | None = None


class FlowNodeDesignerConfig(BaseModel):
    """A single node in the flow graph."""

    id: str
    type: Literal["step"] = "step"
    stepConfig: FlowStepDesignerConfig
