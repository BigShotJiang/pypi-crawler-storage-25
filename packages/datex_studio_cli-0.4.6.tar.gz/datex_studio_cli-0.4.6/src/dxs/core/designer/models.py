"""Shared designer configuration models.

Platform-level type primitives used by datasources, functions, and other
Datex configuration types.
"""

from __future__ import annotations

from typing import Any, Literal, get_args

from pydantic import BaseModel

# JSType values
JSType = Literal["string", "number", "boolean", "date", "object", "union", "blob"]
JS_TYPES: frozenset[str] = frozenset(get_args(JSType))


class TypeConfig(BaseModel):
    """Type configuration for input/output parameters and dynamic filters."""

    id: str
    type: JSType
    required: bool | None = None
    description: str | None = None
    oneOf: list[TypeConfig] | None = None  # Union types
    fromBaseConfiguration: bool | None = None  # Inherited from base config
    objectTypeDef: list[TypeConfig] | None = None
    objectType: str | None = None  # Type reference name
    isCollection: bool | None = None
    isSecured: bool | None = None  # Secure/encrypted field
    isConstant: bool | None = None  # Constant value indicator
    constantValue: Any | None = None  # Constant value if isConstant=true


# Fix forward reference
TypeConfig.model_rebuild()
