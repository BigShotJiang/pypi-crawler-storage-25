"""Shared parsers for designer configuration flags.

Used by datasource, function, and other configuration CLI commands.
"""

import datetime
import re
from typing import Any, cast

import click

from dxs.core.designer.models import JS_TYPES, JSType, TypeConfig

# Complete JS reserved words set (single source of truth)
JS_RESERVED_WORDS = {
    "abstract",
    "arguments",
    "await",
    "boolean",
    "break",
    "byte",
    "case",
    "catch",
    "char",
    "class",
    "const",
    "continue",
    "debugger",
    "default",
    "delete",
    "do",
    "double",
    "else",
    "enum",
    "eval",
    "export",
    "extends",
    "false",
    "final",
    "finally",
    "float",
    "for",
    "function",
    "goto",
    "if",
    "implements",
    "import",
    "in",
    "instanceof",
    "int",
    "interface",
    "let",
    "long",
    "native",
    "new",
    "null",
    "package",
    "private",
    "protected",
    "public",
    "return",
    "short",
    "static",
    "super",
    "switch",
    "synchronized",
    "this",
    "throw",
    "throws",
    "transient",
    "true",
    "try",
    "typeof",
    "var",
    "void",
    "volatile",
    "while",
    "with",
    "yield",
}

_JS_IDENT_RE = re.compile(r"^[a-zA-Z_$][a-zA-Z0-9_$]*$")


def is_valid_js_identifier(name: str) -> bool:
    """Check if name is a valid JS identifier (not reserved, case-insensitive)."""
    return bool(_JS_IDENT_RE.match(name)) and name.lower() not in JS_RESERVED_WORDS


def parse_param(value: str) -> tuple[str, str, bool, bool]:
    """Parse 'name:type' or 'name:type?' -> (name, type, required, is_collection).

    A trailing ``[]`` on the type marks the parameter as a collection.
    A trailing ``?`` (after ``[]`` if present) marks it as optional.

    Examples::

        'id:number'        -> ('id', 'number', True, False)
        'search:string?'   -> ('search', 'string', False, False)
        'flags:boolean[]'  -> ('flags', 'boolean', True, True)
        'tags:string[]?'   -> ('tags', 'string', False, True)
    """
    parts = value.split(":", 1)
    if len(parts) != 2:
        raise click.UsageError(f"--param must be 'name:type' or 'name:type?', got: {value!r}")
    name, ptype = parts
    if not name or not _JS_IDENT_RE.match(name):
        raise click.UsageError(f"Parameter name '{name}' is not a valid JavaScript identifier")
    required = True
    if ptype.endswith("?"):
        required = False
        ptype = ptype[:-1]
    is_collection = False
    if ptype.endswith("[]"):
        is_collection = True
        ptype = ptype[:-2]
    return name, ptype, required, is_collection


def parse_simple_param(value: str) -> tuple[str, str, bool]:
    """Parse 'name:type' -> (name, type, is_collection). No optional marker.

    A trailing ``[]`` on the type marks the parameter as a collection.
    Used for --out-param and --var where required does not apply.

    Examples::

        'result:string'  -> ('result', 'string', False)
        'count:number'   -> ('count', 'number', False)
        'items:number[]' -> ('items', 'number', True)
    """
    parts = value.split(":", 1)
    if len(parts) != 2 or not parts[0] or not parts[1]:
        raise click.UsageError(f"Must be 'name:type', got: {value!r}")
    name, typ = parts
    if not _JS_IDENT_RE.match(name):
        raise click.UsageError(f"Parameter name '{name}' is not a valid JavaScript identifier")
    is_collection = False
    if typ.endswith("[]"):
        is_collection = True
        typ = typ[:-2]
    if typ not in JS_TYPES:
        raise click.UsageError(
            f"Invalid type '{typ}' for '{name}'. Must be one of: {sorted(JS_TYPES)}"
        )
    return name, typ, is_collection


# ---------------------------------------------------------------------------
# Type definition parser (moved from type_def_parser.py)
# ---------------------------------------------------------------------------

VALID_TYPES = JS_TYPES

_YAML_TYPE_COERCIONS: dict[type, str] = {
    bool: "boolean",
    datetime.date: "date",
    datetime.datetime: "date",
}


def _coerce_type(value: Any) -> str:
    """Coerce a YAML-parsed type value back to a string type name."""
    if isinstance(value, str):
        result = value
    elif type(value) in _YAML_TYPE_COERCIONS:
        result = _YAML_TYPE_COERCIONS[type(value)]
    else:
        raise ValueError(f"Invalid type value: {value!r} (type {type(value).__name__})")
    if result not in VALID_TYPES:
        raise ValueError(f"Invalid type '{result}'. Must be one of: {sorted(VALID_TYPES)}")
    return result


_MAX_TYPE_DEF_ENTRIES = 1000


def parse_type_def(raw: list[dict[str, Any]], _depth: int = 0) -> list[TypeConfig]:
    """Parse a raw type definition list into TypeConfig models.

    Args:
        raw: List of dicts from yaml.safe_load() or json.load().
        _depth: Internal recursion depth tracker (do not pass manually).

    Returns:
        List of TypeConfig instances.

    Raises:
        ValueError: If the structure is invalid or nesting exceeds depth limit.
    """
    if _depth > 10:
        raise ValueError("objectTypeDef nesting exceeds maximum depth of 10")
    if len(raw) > _MAX_TYPE_DEF_ENTRIES:
        raise ValueError(
            f"Type definition has {len(raw)} entries, exceeding maximum of {_MAX_TYPE_DEF_ENTRIES}"
        )
    result: list[TypeConfig] = []
    for i, entry in enumerate(raw):
        if "id" not in entry:
            raise ValueError(f"Type definition entry {i}: missing required field 'id'")
        if "type" not in entry:
            raise ValueError(
                f"Type definition entry {i} ('{entry['id']}'): missing required field 'type'"
            )

        type_str = _coerce_type(entry["type"])

        nested = None
        if "objectTypeDef" in entry and entry["objectTypeDef"]:
            nested = parse_type_def(entry["objectTypeDef"], _depth + 1)

        result.append(
            TypeConfig(
                id=entry["id"],
                type=cast(JSType, type_str),
                isCollection=entry.get("isCollection"),
                objectTypeDef=nested,
            )
        )
    return result
