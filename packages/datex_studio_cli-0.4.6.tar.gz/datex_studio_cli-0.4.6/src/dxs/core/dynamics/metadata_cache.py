"""Disk cache for Dynamics CRM entity field metadata.

Mirrors the pattern of ``dxs.core.footprint.metadata.MetadataCache`` but keys
on a per-org slug derived from the Dynamics CRM URL and an entity logical
name.

Cache layout:
    ~/.datex/dynamics_metadata/{org_slug}/{entity_name}.json   - field list
    ~/.datex/dynamics_metadata/{org_slug}/index.json           - {entity: {cached_at}}
"""

from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from dxs.utils.paths import get_dynamics_metadata_dir

DEFAULT_TTL_HOURS = 24

# Permissive entity-name regex used to refuse path-traversal attempts.
_ENTITY_NAME_RE = re.compile(r"^[A-Za-z0-9_]+$")


def _dynamics_org_slug(url: str) -> str:
    """Derive a filesystem-safe per-org slug from a Dynamics CRM URL.

    Normalization:
    - scheme stripped
    - trailing slashes / paths dropped (hostname only)
    - lowercased

    Examples:
        https://yourorg.crm.dynamics.com/   -> yourorg.crm.dynamics.com
        HTTPS://YourOrg.CRM.DYNAMICS.COM    -> yourorg.crm.dynamics.com
        yourorg.crm.dynamics.com            -> yourorg.crm.dynamics.com
    """
    if not url:
        return "unknown"
    raw = url.strip()
    parsed = urlparse(raw if "://" in raw else f"https://{raw}")
    host = parsed.hostname or raw
    return host.lower()


class DynamicsMetadataCache:
    """Read/write cache for Dynamics entity field metadata."""

    def __init__(self, org_url: str | None, cache_root: Path | None = None) -> None:
        self._slug = _dynamics_org_slug(org_url or "")
        root = cache_root or get_dynamics_metadata_dir()
        self._dir = root / self._slug
        self._index_path = self._dir / "index.json"

    def _ensure_dir(self) -> None:
        self._dir.mkdir(parents=True, exist_ok=True)

    def _entity_path(self, entity_name: str) -> Path:
        if not _ENTITY_NAME_RE.match(entity_name):
            raise ValueError(f"Invalid entity name for cache: {entity_name!r}")
        return self._dir / f"{entity_name}.json"

    def _load_index(self) -> dict[str, Any]:
        if not self._index_path.exists():
            return {}
        try:
            data: dict[str, Any] = json.loads(self._index_path.read_text(encoding="utf-8"))
            return data
        except (json.JSONDecodeError, OSError):
            return {}

    def _save_index(self, index: dict[str, Any]) -> None:
        self._ensure_dir()
        self._index_path.write_text(
            json.dumps(index, indent=2, default=str),
            encoding="utf-8",
        )

    def get_entity_fields(self, entity_name: str) -> list[dict[str, Any]] | None:
        """Return cached field list for an entity, or None if missing/unreadable."""
        try:
            path = self._entity_path(entity_name)
        except ValueError:
            return None
        if not path.exists():
            return None
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return None
        if isinstance(data, list):
            return data
        return None

    def is_fresh(self, entity_name: str, ttl_hours: int = DEFAULT_TTL_HOURS) -> bool:
        """Whether the cached entry for an entity is within TTL."""
        index = self._load_index()
        entry = index.get(entity_name)
        if entry is None:
            return False
        try:
            cached_at = datetime.fromisoformat(entry["cached_at"])
        except (KeyError, ValueError, TypeError):
            return False
        age_hours = (datetime.now(timezone.utc) - cached_at).total_seconds() / 3600
        return age_hours < ttl_hours

    def put_entity_fields(self, entity_name: str, fields: list[dict[str, Any]]) -> None:
        """Persist a field list for an entity and update the index."""
        path = self._entity_path(entity_name)
        self._ensure_dir()
        path.write_text(json.dumps(fields, default=str), encoding="utf-8")
        index = self._load_index()
        index[entity_name] = {
            "cached_at": datetime.now(timezone.utc).isoformat(),
        }
        self._save_index(index)

    def remove(self, entity_name: str) -> None:
        """Remove a single entity's cached entry."""
        try:
            path = self._entity_path(entity_name)
        except ValueError:
            return
        if path.exists():
            path.unlink()
        index = self._load_index()
        index.pop(entity_name, None)
        self._save_index(index)
