"""Pydantic models for Footprint API metadata responses."""

from __future__ import annotations

from typing import Generic, TypeVar

from pydantic import BaseModel, Field

T = TypeVar("T")


class ODataListResponse(BaseModel, Generic[T]):
    """Standard OData list response from real OData endpoints.

    Format returned by [EnableQuery] OData endpoints:
    {
        "@odata.context": "...",
        "value": [...],
        "@odata.count": 123  // optional, when $count=true
    }
    """

    context: str | None = Field(alias="@odata.context", default=None)
    value: list[T]
    count: int | None = Field(alias="@odata.count", default=None)

    model_config = {"populate_by_name": True}


class AnnotationDto(BaseModel):
    """OData annotation on a schema element."""

    term: str = Field(alias="Term")
    value: str | None = Field(alias="Value", default=None)
    type: str | None = Field(
        alias="Type", default=None
    )  # "String" | "Bool" | "Int" | "Decimal" | "Path"

    model_config = {"populate_by_name": True}


class PropertyDto(BaseModel):
    """Property metadata from API.

    Supports both standard OData and FootPrint-specific extensions.
    FootPrint-specific fields are optional for compatibility with other OData APIs.
    """

    # Standard OData fields
    entity_type_id: str = Field(alias="EntityTypeId")
    name: str = Field(alias="Name")
    type_id: str = Field(alias="TypeId")
    is_nullable: bool = Field(alias="IsNullable")
    is_collection: bool = Field(alias="IsCollection")
    max_length: int | None = Field(alias="MaxLength", default=None)
    is_key: bool = Field(alias="IsKey")
    is_computed: bool = Field(alias="IsComputed", default=False)

    # OData v4 facets (added by API developer)
    precision: int | None = Field(
        alias="Precision", default=None
    )  # For Decimal, DateTimeOffset, Duration
    scale: int | None = Field(alias="Scale", default=None)  # For Decimal
    unicode: bool | None = Field(alias="Unicode", default=None)  # For String
    default_value: str | None = Field(alias="DefaultValue", default=None)  # Default value as string
    srid: str | None = Field(
        alias="SRID", default=None
    )  # For Geography/Geometry (e.g. "0", "4326")

    # FootPrint-specific extensions (optional for compatibility)
    is_udf: bool = Field(alias="IsUdf", default=False)  # User Defined Field
    annotations: list[AnnotationDto] | None = Field(alias="Annotations", default=None)

    model_config = {"populate_by_name": True}


class ReferentialConstraintDto(BaseModel):
    """A single referential constraint (FK → PK mapping)."""

    property: str | None = Field(alias="Property", default=None)
    referenced_property: str | None = Field(alias="ReferencedProperty", default=None)

    model_config = {"populate_by_name": True}


class NavigationPropertyDto(BaseModel):
    """Navigation property metadata from API."""

    entity_type_id: str = Field(alias="EntityTypeId")
    name: str = Field(alias="Name")
    type_id: str = Field(alias="TypeId")
    is_collection: bool = Field(alias="IsCollection")
    partner_name: str | None = Field(alias="PartnerName", default=None)
    referential_constraints: list[ReferentialConstraintDto] | None = Field(
        alias="ReferentialConstraints", default=None
    )

    model_config = {"populate_by_name": True}


class EntityTypeDto(BaseModel):
    """Entity type metadata from API."""

    type_id: str = Field(alias="TypeId")
    name: str = Field(alias="Name")
    namespace: str = Field(alias="Namespace")
    base_type_id: str | None = Field(alias="BaseTypeId", default=None)
    is_abstract: bool = Field(alias="IsAbstract", default=False)
    is_open_type: bool = Field(alias="IsOpenType", default=False)
    has_stream: bool = Field(alias="HasStream", default=False)
    key_names: list[str] = Field(alias="KeyNames", default_factory=list)
    annotations: list[AnnotationDto] | None = Field(alias="Annotations", default=None)
    properties: list[PropertyDto] | None = Field(alias="Properties", default=None)
    navigation_properties: list[NavigationPropertyDto] | None = Field(
        alias="NavigationProperties", default=None
    )

    model_config = {"populate_by_name": True}


class EntitySetDto(BaseModel):
    """Entity set metadata from API.

    Note: Namespace was removed from the backend DTO in the API refactoring.
    EntityType is available via $expand=EntityType.
    """

    name: str = Field(alias="Name")
    namespace: str | None = Field(alias="Namespace", default=None)
    type_id: str = Field(alias="TypeId")
    entity_type: EntityTypeDto | None = Field(alias="EntityType", default=None)

    model_config = {"populate_by_name": True}


class EnumMemberDto(BaseModel):
    """A single enum member with name and optional value."""

    name: str = Field(alias="Name")
    value: str | None = Field(alias="Value", default=None)

    model_config = {"populate_by_name": True}


class EnumTypeDto(BaseModel):
    """Enum type metadata from API.

    Members is now a typed list of EnumMemberDto (was a JSON string).
    """

    type_id: str = Field(alias="TypeId")
    name: str = Field(alias="Name")
    namespace: str = Field(alias="Namespace")
    underlying_type: str = Field(alias="UnderlyingType")
    is_flags: bool = Field(alias="IsFlags")
    members: list[EnumMemberDto] | None = Field(alias="Members", default=None)

    model_config = {"populate_by_name": True}


class OperationParameterDto(BaseModel):
    """A parameter for an OData action or function.

    Replaces the old JSON string representation.
    """

    name: str = Field(alias="Name")
    type_id: str = Field(alias="TypeId")
    nullable: bool = Field(alias="Nullable")
    is_collection: bool = Field(alias="IsCollection")
    max_length: int | None = Field(alias="MaxLength", default=None)

    model_config = {"populate_by_name": True}


class ReturnTypeInfoDto(BaseModel):
    """Return type information for an OData action or function.

    Replaces the old JSON string representation.
    """

    type_id: str = Field(alias="TypeId")
    nullable: bool = Field(alias="Nullable")
    is_collection: bool = Field(alias="IsCollection")

    model_config = {"populate_by_name": True}


class ActionDto(BaseModel):
    """OData action metadata from API.

    Parameters and ReturnType are now typed objects (not JSON strings).
    """

    # Standard OData fields
    name: str = Field(alias="Name")
    namespace: str = Field(alias="Namespace")
    is_bound: bool = Field(alias="IsBound")
    return_type: ReturnTypeInfoDto | None = Field(alias="ReturnType", default=None)
    parameters: list[OperationParameterDto] | None = Field(alias="Parameters", default=None)

    # FootPrint-specific extensions (optional for compatibility)
    action_id: str | None = Field(alias="ActionId", default=None)
    is_footprint_custom_operation: bool = Field(alias="IsFootPrintCustomOperation", default=False)

    model_config = {"populate_by_name": True}


class FunctionDto(BaseModel):
    """OData function metadata from API.

    Parameters and ReturnType are now typed objects (not JSON strings).
    IsComposable has been removed from the API — defaults to False.
    """

    function_id: str | None = Field(alias="FunctionId", default=None)
    name: str = Field(alias="Name")
    namespace: str = Field(alias="Namespace")
    is_bound: bool = Field(alias="IsBound")
    is_composable: bool = Field(alias="IsComposable", default=False)
    return_type: ReturnTypeInfoDto | None = Field(alias="ReturnType", default=None)
    parameters: list[OperationParameterDto] | None = Field(alias="Parameters", default=None)

    model_config = {"populate_by_name": True}


class ActionImportDto(BaseModel):
    """Action import metadata — a named entry point into an OData action."""

    name: str = Field(alias="Name")
    action_id: str = Field(alias="ActionId")
    action: ActionDto | None = Field(alias="Action", default=None)

    model_config = {"populate_by_name": True}


class FunctionImportDto(BaseModel):
    """Function import metadata — a named entry point into an OData function."""

    name: str = Field(alias="Name")
    function_id: str = Field(alias="FunctionId")
    function: FunctionDto | None = Field(alias="Function", default=None)

    model_config = {"populate_by_name": True}


class ComplexTypeDto(BaseModel):
    """Complex type metadata from API.

    Complex types are structured types that are not entities (no keys, not directly queryable).
    Properties and NavigationProperties are available via $expand on the by-key endpoint.
    """

    type_id: str = Field(alias="TypeId")
    name: str = Field(alias="Name")
    namespace: str = Field(alias="Namespace")
    base_type_id: str | None = Field(alias="BaseTypeId", default=None)
    is_abstract: bool = Field(alias="IsAbstract", default=False)
    is_open_type: bool = Field(alias="IsOpenType", default=False)
    annotations: list[AnnotationDto] | None = Field(alias="Annotations", default=None)
    properties: list[PropertyDto] | None = Field(alias="Properties", default=None)
    navigation_properties: list[NavigationPropertyDto] | None = Field(
        alias="NavigationProperties", default=None
    )

    model_config = {"populate_by_name": True}


class SingletonDto(BaseModel):
    """Singleton metadata from API.

    Singletons are single-instance entities exposed by the API.
    Note: Namespace was removed from the backend DTO in the API refactoring.
    EntityType is available via $expand=EntityType.
    """

    name: str = Field(alias="Name")
    namespace: str | None = Field(alias="Namespace", default=None)
    type_id: str = Field(alias="TypeId")
    entity_type: EntityTypeDto | None = Field(alias="EntityType", default=None)

    model_config = {"populate_by_name": True}
