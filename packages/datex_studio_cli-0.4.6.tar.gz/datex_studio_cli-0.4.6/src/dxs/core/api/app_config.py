"""Helpers for the AppConfig configuration.

Application settings and references were collapsed into a single ``AppConfig``
configuration in datex-application-api PR 3754. The configuration is fetched
via ``ConfigurationEndpoints``/``BranchEndpoints.app_config(branch_id)`` and the
payload looks like::

    {
        "id": 123,
        "json": {
            "settings":   [{"name": "...", "settingType": "...", "value": "..."}],
            "references": [{"uniqueIdentifier": "...", "version": "...",
                            "isDirect": true, "settings": [...]}]
        },
        ...
    }

The helpers in this module unwrap that envelope so callers can keep working in
terms of plain lists of settings / references.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from dxs.core.api.endpoints import BranchEndpoints

if TYPE_CHECKING:
    from dxs.core.api.client import ApiClient


def fetch_app_config(client: ApiClient, branch_id: int) -> dict[str, Any]:
    """Fetch the AppConfig configuration for a branch.

    Returns the inner ``json`` body (``{"settings": [...], "references": [...]}``)
    rather than the full configuration envelope, since every current caller only
    cares about the inner contents.
    """
    response = client.get(BranchEndpoints.app_config(branch_id))
    if not isinstance(response, dict):
        return {"settings": [], "references": []}
    body = response.get("json")
    if not isinstance(body, dict):
        return {"settings": [], "references": []}
    return body


def fetch_settings(client: ApiClient, branch_id: int) -> list[dict[str, Any]]:
    """Return the AppConfig settings list for a branch (possibly empty)."""
    body = fetch_app_config(client, branch_id)
    settings = body.get("settings")
    if not isinstance(settings, list):
        return []
    return [s for s in settings if isinstance(s, dict)]


def fetch_references(
    client: ApiClient,
    branch_id: int,
    *,
    direct_only: bool = False,
) -> list[dict[str, Any]]:
    """Return the AppConfig references list for a branch.

    The new payload merges direct and transitive references into one list,
    distinguished by ``isDirect``. Pass ``direct_only=True`` to filter to direct
    references (the equivalent of the old ``/references`` route).
    """
    body = fetch_app_config(client, branch_id)
    references = body.get("references")
    if not isinstance(references, list):
        return []
    refs = [r for r in references if isinstance(r, dict)]
    if direct_only:
        refs = [r for r in refs if r.get("isDirect")]
    return refs
