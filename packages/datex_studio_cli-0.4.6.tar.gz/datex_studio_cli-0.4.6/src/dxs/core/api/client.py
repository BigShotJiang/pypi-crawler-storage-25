"""HTTP client for Datex Studio API with automatic authentication."""

import json
import re
from typing import Any

import httpx

from dxs.core.auth import get_access_token
from dxs.utils.config import get_settings
from dxs.utils.errors import ApiError, AuthenticationError, ConfigurationError


def classify_http_error(
    status_code: int,
    *,
    body: Any = None,
    url: str | None = None,
) -> dict[str, Any]:
    """Classify an HTTP error status into a structured error dict.

    Shared by both single-request error raising and batch sub-request error handling
    so that error codes, messages, and suggestions are consistent.

    Args:
        status_code: The HTTP status code (must be >= 400).
        body: Parsed JSON response body, if available.
        url: The request URL, for inclusion in details.

    Returns:
        Dict with keys: code, message, suggestions, details.
    """
    details: dict[str, Any] = {"status_code": status_code}
    if url:
        details["url"] = url
    if body is not None:
        details["body"] = body

    if status_code == 401:
        return {
            "code": "DXS-AUTH-001",
            "message": "Authentication token is invalid or expired",
            "suggestions": ["Run 'dxs auth login' to refresh credentials"],
            "details": details,
        }

    if status_code == 403:
        return {
            "code": "DXS-AUTH-003",
            "message": "You don't have permission to access this resource",
            "suggestions": [
                "Check that you have the required permissions",
                "Contact your administrator if you believe this is an error",
            ],
            "details": details,
        }

    if status_code == 404:
        # Check if this is a connection-level 404 (not a schema sub-resource)
        if url:
            conn_match = re.search(r"/footprintapiconnections/(\d+)", url)
            if conn_match and "/schema/" not in url:
                conn_id = conn_match.group(1)
                return {
                    "code": "DXS-CONN-001",
                    "message": f"Connection ID {conn_id} not found",
                    "suggestions": [
                        "List available connections with 'dxs odata connections'",
                    ],
                    "details": details,
                }
        return {
            "code": "DXS-404-001",
            "message": "Resource not found",
            "suggestions": [],
            "details": details,
        }

    # Generic 4xx/5xx — try to extract a message from the body
    message = f"API error: {status_code}"
    if isinstance(body, dict):
        message = body.get("message") or body.get("title") or body.get("detail") or message

    return {
        "code": f"DXS-API-{status_code}",
        "message": message,
        "suggestions": [],
        "details": details,
    }


class ApiClient:
    """HTTP client with automatic token injection and error handling.

    Handles:
    - Automatic Bearer token injection
    - Response normalization
    - Error handling with DxsError types
    - Connection pooling (reuses httpx.Client instance)
    """

    def __init__(
        self,
        base_url: str | None = None,
        timeout: int | None = None,
    ) -> None:
        """Initialize the API client.

        Args:
            base_url: API base URL. Defaults to config value.
            timeout: Request timeout in seconds. Defaults to config value.
        """
        settings = get_settings()
        self._base_url = (base_url or settings.api_base_url).rstrip("/")
        self._timeout = timeout or settings.api_timeout
        self._verify_ssl = settings.verify_ssl
        self._client: httpx.Client | None = None

    def _get_client(self) -> httpx.Client:
        """Get or create the persistent HTTP client.

        Returns:
            Configured httpx.Client instance.
        """
        if self._client is None:
            self._client = httpx.Client(
                timeout=self._timeout,
                verify=self._verify_ssl,
            )
        return self._client

    def close(self) -> None:
        """Close the HTTP client and release connections."""
        if self._client is not None:
            self._client.close()
            self._client = None

    def __enter__(self) -> "ApiClient":
        """Context manager entry."""
        return self

    def __exit__(self, *args: Any) -> None:
        """Context manager exit - close client."""
        self.close()

    def __del__(self) -> None:
        """Cleanup on garbage collection."""
        self.close()

    def _get_headers(self) -> dict[str, str]:
        """Get request headers with authorization token."""
        token = get_access_token()
        return {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

    def _raise_for_http_error(self, response: httpx.Response) -> None:
        """Raise an appropriate DxsError for HTTP error status codes.

        Does nothing for 2xx responses.

        Args:
            response: The HTTP response to check.

        Raises:
            AuthenticationError: For 401/403 responses.
            ApiError: For other 4xx/5xx responses.
        """
        if response.status_code < 400:
            return

        # Parse body once for the classifier
        try:
            error_body = response.json()
        except Exception:
            error_body = None

        info = classify_http_error(
            response.status_code,
            body=error_body,
            url=str(response.url),
        )

        if response.status_code in (401, 403):
            raise AuthenticationError(
                message=info["message"],
                code=info["code"],
                suggestions=info["suggestions"],
            )

        raise ApiError(
            message=info["message"],
            code=info["code"],
            status_code=response.status_code,
            details=info["details"],
        )

    def _handle_response(self, response: httpx.Response) -> Any:
        """Handle API response, raising appropriate errors and parsing JSON.

        Args:
            response: The HTTP response.

        Returns:
            Parsed JSON response data.

        Raises:
            AuthenticationError: For 401/403 responses.
            ApiError: For other error responses.
        """
        self._raise_for_http_error(response)

        # Handle empty responses (204 No Content)
        if response.status_code == 204 or not response.content:
            return None

        # Parse JSON response with defensive error handling
        try:
            return response.json()
        except (json.JSONDecodeError, ValueError) as e:
            # API returned non-JSON content with success status
            content_type = response.headers.get("content-type", "")
            response_preview = response.text[:500] if response.text else "(empty)"

            raise ApiError(
                message=f"API returned non-JSON response (status {response.status_code})",
                code="DXS-API-JSON-001",
                status_code=response.status_code,
                details={
                    "url": str(response.url),
                    "content_type": content_type,
                    "response_preview": response_preview,
                    "parse_error": str(e),
                },
                suggestions=[
                    "This may indicate an API server error or misconfiguration",
                    "Verify the API endpoint URL is correct",
                    "Check that the API server is functioning properly",
                    "Contact support if this persists with error code DXS-API-JSON-001",
                ],
            ) from e

    def get(self, path: str, params: dict[str, Any] | None = None) -> Any:
        """Make a GET request.

        Args:
            path: API endpoint path (e.g., "/sourcecontrol/10/locks").
            params: Optional query parameters.

        Returns:
            Parsed JSON response.

        Raises:
            AuthenticationError: If not authenticated or token invalid.
            ApiError: For API errors.
        """
        url = f"{self._base_url}{path}"
        try:
            client = self._get_client()
            response = client.get(
                url,
                headers=self._get_headers(),
                params=params,
            )
            return self._handle_response(response)
        except httpx.ConnectError as e:
            raise ConfigurationError(
                message=f"Cannot connect to API at {self._base_url}",
                code="DXS-API-CONN",
                details={"url": url, "error": str(e)},
                suggestions=[
                    "Check that the Datex Studio API server is running",
                    f"Verify api_base_url is correct: {self._base_url}",
                    "Run 'dxs config set api_base_url <url>' to update",
                ],
            ) from e
        except httpx.TimeoutException as e:
            raise ApiError(
                message=f"Request timed out after {self._timeout} seconds",
                code="DXS-API-TIMEOUT",
                details={"url": url, "timeout": self._timeout, "error": str(e)},
                suggestions=[
                    "The API server may be slow or unresponsive",
                    "Try increasing timeout: dxs config set api_timeout 60",
                ],
            ) from e

    def get_text(self, path: str, params: dict[str, Any] | None = None) -> str:
        """Make a GET request and return raw text response.

        Args:
            path: API endpoint path (e.g., "/footprintapiconnections/1/schema/$metadata").
            params: Optional query parameters.

        Returns:
            Raw text response (XML, plain text, etc.).

        Raises:
            AuthenticationError: If not authenticated or token invalid.
            ApiError: For API errors.
        """
        url = f"{self._base_url}{path}"
        try:
            client = self._get_client()
            headers = self._get_headers()
            headers["Accept"] = "*/*"  # Accept any content type (XML, plain text, etc.)
            response = client.get(url, headers=headers, params=params)
            self._raise_for_http_error(response)
            return response.text
        except httpx.ConnectError as e:
            raise ConfigurationError(
                message=f"Cannot connect to API at {self._base_url}",
                code="DXS-API-CONN",
                details={"url": url, "error": str(e)},
                suggestions=[
                    "Check that the Datex Studio API server is running",
                    f"Verify api_base_url is correct: {self._base_url}",
                    "Run 'dxs config set api_base_url <url>' to update",
                ],
            ) from e
        except httpx.TimeoutException as e:
            raise ApiError(
                message=f"Request timed out after {self._timeout} seconds",
                code="DXS-API-TIMEOUT",
                details={"url": url, "timeout": self._timeout, "error": str(e)},
                suggestions=[
                    "The API server may be slow or unresponsive",
                    "Try increasing timeout: dxs config set api_timeout 60",
                ],
            ) from e

    def post(
        self,
        path: str,
        data: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> Any:
        """Make a POST request.

        Args:
            path: API endpoint path.
            data: Request body data.
            params: Optional query parameters.

        Returns:
            Parsed JSON response.

        Raises:
            AuthenticationError: If not authenticated or token invalid.
            ApiError: For API errors.
        """
        url = f"{self._base_url}{path}"
        try:
            client = self._get_client()
            response = client.post(
                url,
                headers=self._get_headers(),
                json=data,
                params=params,
            )
            return self._handle_response(response)
        except httpx.ConnectError as e:
            raise ConfigurationError(
                message=f"Cannot connect to API at {self._base_url}",
                code="DXS-API-CONN",
                details={"url": url, "error": str(e)},
                suggestions=[
                    "Check that the Datex Studio API server is running",
                    f"Verify api_base_url is correct: {self._base_url}",
                ],
            ) from e
        except httpx.TimeoutException as e:
            raise ApiError(
                message=f"Request timed out after {self._timeout} seconds",
                code="DXS-API-TIMEOUT",
                details={"url": url, "timeout": self._timeout, "error": str(e)},
            ) from e

    def post_batch(self, path: str, requests: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Send an OData $batch request with multiple sub-requests.

        Args:
            path: Batch endpoint path (e.g., "/footprintapiconnections/32/schema/$batch").
            requests: List of sub-request dicts with "id", "method", "url" keys.

        Returns:
            List of response dicts with "id", "status", "body" keys.
        """
        result = self.post(path, data={"requests": requests})
        if result is None:
            return []
        responses: list[dict[str, Any]] = result.get("responses", [])
        return responses

    def put(
        self,
        path: str,
        data: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> Any:
        """Make a PUT request.

        Args:
            path: API endpoint path.
            data: Request body data.
            params: Optional query parameters.

        Returns:
            Parsed JSON response.

        Raises:
            AuthenticationError: If not authenticated or token invalid.
            ApiError: For API errors.
        """
        url = f"{self._base_url}{path}"
        try:
            client = self._get_client()
            response = client.put(
                url,
                headers=self._get_headers(),
                json=data,
                params=params,
            )
            return self._handle_response(response)
        except httpx.ConnectError as e:
            raise ConfigurationError(
                message=f"Cannot connect to API at {self._base_url}",
                code="DXS-API-CONN",
                details={"url": url, "error": str(e)},
            ) from e
        except httpx.TimeoutException as e:
            raise ApiError(
                message=f"Request timed out after {self._timeout} seconds",
                code="DXS-API-TIMEOUT",
                details={"url": url, "timeout": self._timeout, "error": str(e)},
            ) from e

    def delete(self, path: str, params: dict[str, Any] | None = None) -> Any:
        """Make a DELETE request.

        Args:
            path: API endpoint path.
            params: Optional query parameters.

        Returns:
            Parsed JSON response (usually None for DELETE).

        Raises:
            AuthenticationError: If not authenticated or token invalid.
            ApiError: For API errors.
        """
        url = f"{self._base_url}{path}"
        try:
            client = self._get_client()
            response = client.delete(
                url,
                headers=self._get_headers(),
                params=params,
            )
            return self._handle_response(response)
        except httpx.ConnectError as e:
            raise ConfigurationError(
                message=f"Cannot connect to API at {self._base_url}",
                code="DXS-API-CONN",
                details={"url": url, "error": str(e)},
            ) from e
        except httpx.TimeoutException as e:
            raise ApiError(
                message=f"Request timed out after {self._timeout} seconds",
                code="DXS-API-TIMEOUT",
                details={"url": url, "timeout": self._timeout, "error": str(e)},
            ) from e
