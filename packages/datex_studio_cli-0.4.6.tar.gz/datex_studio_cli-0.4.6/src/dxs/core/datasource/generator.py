"""OData query parser and datasource JSON generator.

This module provides a complete OData query parser and datasource configuration
generator for Datex Studio. It transforms OData queries into structured JSON
configurations that define how Datex applications fetch and display data.

## Architecture

The generator consists of three main components:

1. **ODataQueryParser** - Lexical parser for OData query syntax
   - Tokenizes entity sets, keys, navigation paths, query options
   - Handles nested $expand with balanced parentheses
   - Supports $select, $filter, $orderby, $top, $skip, $count
   - Lines 67-440

2. **DatasourceGenerator** - Configuration builder with type inference
   - Fetches entity metadata from FootPrint API
   - Builds recursive type definitions for nested structures
   - Auto-detects and parameterizes entity keys
   - Validates all $expand clauses have $select (enforced)
   - Lines 442-1107

3. **Type Inference** - Maps OData EDM types to JavaScript types
   - Uses ODATA_TYPE_MAP constant for conversions
   - Handles primitive types (string, number, boolean, date)
   - Supports collection types with [] suffix

## OData Parsing Algorithm

The parser uses a recursive descent approach:

1. Parse entity set name (e.g., "Invoices")
2. Parse optional key segment (e.g., "(123)" or "({id})")
3. Parse optional navigation path (NOT SUPPORTED - raises error)
4. Parse query options ($select, $filter, $expand, $orderby, $top, $skip)
5. For each $expand:
   - Recursively parse nested entity with its own query options
   - Validate that $select is present (REQUIRED - raises DXS-DATASOURCE-008)
   - Build nested type definitions

## Key Parameterization

Static key values are automatically converted to input parameters:

- Query: `Invoices(1469)?$expand=...`
- Becomes: `Invoices({invoiceId})?$expand=...`
- Parameter added: `{ name: "invoiceId", type: "number", required: true }`

## Type Definition Building

Type definitions are built recursively (lines 917-1012):

1. Fetch entity properties from metadata API
2. For each property in $select list:
   - Map OData type to JavaScript type using ODATA_TYPE_MAP
   - Mark as required if non-nullable and is key
3. For each $expand:
   - Recursively build nested type definition
   - Handle collection vs single relationships (multiplicity)
   - Propagate nested selects into type structure

## Critical Requirements

1. ALL $expand clauses MUST include $select with field list
2. Description parameter recommended for documentation
3. Reference names must be valid JavaScript identifiers
4. Composite keys NOT supported (raises DXS-DATASOURCE-005)
5. Navigation properties in paths NOT supported (raises DXS-DATASOURCE-006)

## Example Flow

Input Query:
```
Invoices(1469)?$expand=Account($select=Name,Code),InvoiceLines($select=LineNumber,Amount;$expand=Product($select=Name))
```

Processing:
1. Parse: entity=Invoices, key=1469, expand=[Account, InvoiceLines]
2. Parameterize: 1469 → {invoiceId}
3. Fetch metadata: Properties, NavigationProperties for Invoices
4. Build root type: Invoice with properties from metadata
5. Build nested type: Account with [Name, Code]
6. Build nested type: InvoiceLines with [LineNumber, Amount]
7. Build deeply nested type: Product with [Name]
8. Assemble queryOptions: { select, expand objects, filters }
9. Generate JSON: DatasourceConfig with all metadata

Output: Complete datasource JSON ready for import into Datex Studio

## Error Codes

- DXS-DATASOURCE-001: Entity set not found
- DXS-DATASOURCE-002: Entity type not found
- DXS-DATASOURCE-003: Entity key not found
- DXS-DATASOURCE-005: Composite keys not supported
- DXS-DATASOURCE-006: Navigation properties in path not supported
- DXS-DATASOURCE-008: Expand missing required $select clause
"""

import re
from typing import Any

from dxs.core.api.client import ApiClient
from dxs.core.api.endpoints import FootPrintMetadataEndpoints
from dxs.core.api.metadata_models import (
    EntitySetDto,
    EntityTypeDto,
    NavigationPropertyDto,
    ODataListResponse,
    PropertyDto,
)
from dxs.core.datasource.models import (
    DatasourceConfig,
    DSAggregateConfig,
    DSApplyConfig,
    DSApplyGroupByConfig,
    DSExpandConfig,
    DSExpressionConfig,
    DSFilterConfig,
    DSKeyConfig,
    DSOrderByConfig,
    DSPathEntitySetConfig,
    DSPathKeyConfig,
    DSPathSegmentConfig,
    DSQueryOptionsConfig,
    ParsedAggregate,
    ParsedAggregateClause,
    ParsedApplyClause,
    ParsedFilterClause,
    ParsedGroupByClause,
    TypeConfig,
)
from dxs.utils.errors import ValidationError

# Constants
DEFAULT_CONNECTION_TYPE = "FootPrintAPI"
DEFAULT_ACCESS_MODIFIER = "public"

# OData EDM type to JavaScript type mapping
ODATA_TYPE_MAP: dict[str, str] = {
    "Edm.String": "string",
    "Edm.Int32": "number",
    "Edm.Int64": "number",
    "Edm.Decimal": "number",
    "Edm.Double": "number",
    "Edm.Single": "number",
    "Edm.Boolean": "boolean",
    "Edm.DateTime": "date",
    "Edm.DateTimeOffset": "date",
    "Edm.Date": "date",
    "Edm.Guid": "string",
    "Edm.Binary": "string",
    "Edm.Byte": "number",
    "Edm.SByte": "number",
    "Edm.Int16": "number",
    "Edm.Time": "string",
    "Edm.Duration": "string",
}


class ODataQueryParser:
    """Parse OData query strings into structured components."""

    def __init__(self, query: str):
        """Initialize parser with OData query string.

        Args:
            query: OData query string (e.g., 'Orders?$select=Id,Name&$top=10')
        """
        self.query = query
        self._parse()

    def _parse(self) -> None:
        """Parse the OData query into components."""
        if "?" in self.query:
            path_part, query_part = self.query.split("?", 1)
        else:
            path_part = self.query
            query_part = ""

        self.path_segments = self._parse_path(path_part)

        if query_part:
            self.params = self._parse_query_string(query_part)
        else:
            self.params = {}

        # Eagerly validate $expand content so invalid separators are
        # caught at construction time rather than lazily in get_expand().
        if "$expand" in self.params:
            self._parse_expand_list(self.params["$expand"])

    @staticmethod
    def _parse_query_string(query_string: str) -> dict[str, str]:
        """Parse OData query string, splitting on '&' only at parenthesis depth 0.

        Unlike urllib.parse.parse_qs, this method understands OData's
        parenthesized nesting in $expand() and preserves the full
        expand value including any characters inside parentheses.

        No URL percent-decoding is performed because CLI arguments
        are not URL-encoded (they come directly from shell arguments).
        """
        params: dict[str, str] = {}
        current = ""
        paren_depth = 0

        for char in query_string:
            if char == "(":
                paren_depth += 1
                current += char
            elif char == ")":
                paren_depth -= 1
                if paren_depth < 0:
                    raise ValidationError(
                        message=(f"Unmatched closing parenthesis in query: '{query_string}'"),
                        code="DXS-DATASOURCE-010",
                        suggestions=[
                            "Check for extra ')' characters in the query string",
                            "Ensure every '(' has a matching ')'",
                        ],
                    )
                current += char
            elif char == "&" and paren_depth == 0:
                if current:
                    key, _, value = current.partition("=")
                    params[key] = value
                current = ""
            else:
                current += char

        if current:
            key, _, value = current.partition("=")
            params[key] = value

        return params

    def _parse_path(self, path: str) -> list[dict[str, Any]]:
        """Parse OData path into segments.

        Examples:
            'Orders' -> [{'type': 'entitySet', 'name': 'Orders'}]
            'Orders(123)' -> [{'type': 'entitySet', 'name': 'Orders'}, {'type': 'key', 'value': '123'}]
            'Orders(123)/Owner' -> [entitySet, key, navProperty]
        """
        segments = []

        # Match entity set with optional key
        entity_key_pattern = r"^([A-Za-z_][A-Za-z0-9_]*)\(([^)]+)\)$"
        entity_pattern = r"^([A-Za-z_][A-Za-z0-9_]*)$"

        parts = path.split("/")

        for part in parts:
            # Try entity set with key: EntitySet(123)
            match = re.match(entity_key_pattern, part)
            if match:
                entity_set = match.group(1)
                key_value = match.group(2)
                segments.append({"type": "entitySet", "name": entity_set})
                segments.append({"type": "key", "value": key_value})
                continue

            # Try plain entity set: EntitySet
            match = re.match(entity_pattern, part)
            if match:
                entity_set = match.group(1)
                # Check if this is first segment (entity set) or later (navigation property)
                if not segments:
                    segments.append({"type": "entitySet", "name": entity_set})
                else:
                    segments.append({"type": "navigationProperty", "name": part})
                continue

            raise ValidationError(
                message=f"Invalid OData path segment: {part}",
                code="DXS-DATASOURCE-001",
                suggestions=["Use format: EntitySet, EntitySet(key), or /NavigationProperty"],
            )

        return segments

    @property
    def entity_set(self) -> str:
        """Get the entity set name from the first path segment."""
        if self.path_segments and self.path_segments[0]["type"] == "entitySet":
            return self.path_segments[0]["name"]
        raise ValidationError(
            message="No entity set found in OData query",
            code="DXS-DATASOURCE-002",
            suggestions=["Query must start with an entity set name"],
        )

    @property
    def has_key(self) -> bool:
        """Check if query includes a key segment (single entity)."""
        return any(seg["type"] == "key" for seg in self.path_segments)

    @property
    def is_collection(self) -> bool:
        """Determine if the query returns a collection or single entity."""
        # Collection if no key segment, or if last segment is entity set
        if not self.has_key:
            return True
        # If last segment is navigation property, need to check its cardinality
        # For now, assume single entity if key present
        return False

    def get_select_fields(self) -> list[str] | None:
        """Extract $select fields."""
        select = self.params.get("$select")
        if select:
            return [f.strip() for f in select.split(",")]
        return None

    def get_filter(self) -> str | None:
        """Extract $filter expression."""
        return self.params.get("$filter")

    def get_orderby(self) -> list[dict[str, str]] | None:
        """Extract $orderby clauses."""
        orderby = self.params.get("$orderby")
        if not orderby:
            return None

        result = []
        for clause in orderby.split(","):
            clause = clause.strip()
            lower = clause.lower()
            if lower.endswith(" desc"):
                prop = clause[: -len(" desc")].strip()
                result.append({"property": prop, "order": "desc"})
            elif lower.endswith(" asc"):
                prop = clause[: -len(" asc")].strip()
                result.append({"property": prop, "order": "asc"})
            else:
                result.append({"property": clause, "order": "asc"})
        return result

    def get_expand(self) -> list[dict[str, Any]] | None:
        """Extract $expand properties with nested structure.

        Parses $expand into a list of dictionaries with 'property' and optional 'nested' keys.
        Handles nested expands like: "Lines($expand=Product($expand=Category),Unit)"

        Returns:
            List of expand dictionaries with structure:
            [
                {"property": "Status"},
                {
                    "property": "Lines",
                    "nested": [
                        {
                            "property": "Product",
                            "nested": [{"property": "Category"}]
                        },
                        {"property": "Unit"}
                    ]
                }
            ]
        """
        expand = self.params.get("$expand")
        if not expand:
            return None

        return self._parse_expand_list(expand)

    def _parse_expand_list(self, expand_str: str) -> list[dict[str, Any]]:
        """Parse comma-separated expand list, respecting parentheses.

        Args:
            expand_str: Expand string (e.g., "A,B($expand=C),D")

        Returns:
            List of parsed expand dictionaries
        """
        result = []
        current = ""
        paren_depth = 0

        for char in expand_str:
            if char == "(":
                paren_depth += 1
                current += char
            elif char == ")":
                paren_depth -= 1
                current += char
            elif char == "," and paren_depth == 0:
                # Top-level comma - split here
                if current.strip():
                    result.append(self._parse_single_expand(current.strip()))
                current = ""
            else:
                current += char

        # Don't forget the last item
        if current.strip():
            result.append(self._parse_single_expand(current.strip()))

        return result

    def _parse_single_expand(self, expand_str: str) -> dict[str, Any]:
        """Parse a single expand expression.

        Args:
            expand_str: Single expand (e.g., "Property" or "Property($select=A,B;$expand=Nested)")

        Returns:
            Dictionary with 'property' and optional nested query options
        """
        # Check if this has nested options
        if "(" not in expand_str:
            # Simple property
            return {"property": expand_str}

        # Parse property name and nested content
        prop_name, _, nested_part = expand_str.partition("(")
        prop_name = prop_name.strip()

        # Remove trailing )
        if nested_part.endswith(")"):
            nested_part = nested_part[:-1]

        # Parse nested query options
        query_options = self._parse_nested_options(nested_part)

        result: dict[str, Any] = {"property": prop_name}
        if query_options:
            result.update(query_options)

        return result

    def _parse_nested_options(self, options_str: str) -> dict[str, Any] | None:
        """Parse nested query options like $select=A,B, $filter=..., $expand=...

        Args:
            options_str: Options string (e.g., "$select=Id,Name;$expand=Lines")

        Returns:
            Dictionary with parsed query options (select, filter, orderby, expands, top, skip, count)
        """
        if not options_str.strip():
            return None

        # Split by query option boundaries (look for $option= patterns)
        parts = self._split_query_options(options_str)

        # Parse each option
        result: dict[str, Any] = {}

        for part in parts:
            part = part.strip()
            if not part:
                continue

            if part.startswith("$select="):
                # Parse $select=Field1,Field2
                select_value = part[len("$select=") :]
                result["select"] = [f.strip() for f in select_value.split(",")]

            elif part.startswith("$filter="):
                # Parse $filter=expression
                filter_value = part[len("$filter=") :]
                result["filter"] = filter_value

            elif part.startswith("$orderby="):
                # Parse $orderby=Field1 asc,Field2 desc
                orderby_value = part[len("$orderby=") :]
                result["orderby"] = self._parse_orderby_string(orderby_value)

            elif part.startswith("$top="):
                # Parse $top=10
                top_value = part[len("$top=") :]
                result["top"] = top_value

            elif part.startswith("$skip="):
                # Parse $skip=20
                skip_value = part[len("$skip=") :]
                result["skip"] = skip_value

            elif part.startswith("$count="):
                # Parse $count=true
                count_value = part[len("$count=") :]
                result["count"] = count_value.lower() in ("true", "1")

            elif part.startswith("$expand="):
                # Parse $expand=Property1,Property2($expand=Nested)
                expand_value = part[len("$expand=") :]
                result["expands"] = self._parse_expand_list(expand_value)

            elif not part.startswith("$"):
                # Plain property name (shorthand for $expand=Property)
                # This handles cases like "Lines($select=Id,Product)" where "Product" is implied as $expand=Product
                if "expands" not in result:
                    result["expands"] = []
                result["expands"].append(self._parse_single_expand(part))

        return result if result else None

    def _split_query_options(self, options_str: str) -> list[str]:
        """Split nested query options by ';' boundaries, respecting parentheses.

        OData v4 specifies that nested system query options inside $expand()
        are separated by semicolons (;). This method enforces that strictly.

        Raises ValidationError if '&' or ',' is found as an option separator
        (i.e., at paren depth 0 followed by a system query option '$...').
        """
        parts = []
        current = ""
        paren_depth = 0

        for i, char in enumerate(options_str):
            if char == "(":
                paren_depth += 1
                current += char
            elif char == ")":
                paren_depth -= 1
                current += char
            elif char == ";" and paren_depth == 0:
                if current.strip():
                    parts.append(current.strip())
                current = ""
            elif char == "," and paren_depth == 0:
                rest = options_str[i + 1 :].lstrip()
                if rest.startswith("$"):
                    opt_name = rest[: rest.find("=") + 1] if "=" in rest else rest[:20]
                    raise ValidationError(
                        message=(
                            f"Invalid separator ',' before '{opt_name}' inside $expand(). "
                            f"OData v4 requires ';' to separate nested query options."
                        ),
                        code="DXS-DATASOURCE-012",
                        suggestions=[
                            "Use semicolons (;) to separate options inside $expand()",
                            "Example: $expand=Entity($select=Id,Name;$orderby=Name;$top=10)",
                            "Commas (,) are only valid within value lists like $select=Id,Name",
                        ],
                    )
                else:
                    current += char
            elif char == "&" and paren_depth == 0:
                raise ValidationError(
                    message=(
                        "Invalid separator '&' inside $expand(). "
                        "OData v4 requires ';' to separate nested query options."
                    ),
                    code="DXS-DATASOURCE-012",
                    suggestions=[
                        "Use semicolons (;) to separate options inside $expand()",
                        "Example: $expand=Entity($select=Id,Name;$orderby=Name;$top=10)",
                        "Ampersands (&) are only valid as top-level query string separators",
                    ],
                )
            else:
                current += char

        if current.strip():
            parts.append(current.strip())

        return parts

    def _parse_orderby_string(self, orderby_str: str) -> list[dict[str, str]]:
        """Parse $orderby string into structured format.

        Args:
            orderby_str: OrderBy string (e.g., "Field1 asc,Field2 desc")

        Returns:
            List of orderby dictionaries
        """
        result = []
        for clause in orderby_str.split(","):
            clause = clause.strip()
            lower = clause.lower()
            if lower.endswith(" desc"):
                prop = clause[: -len(" desc")].strip()
                result.append({"property": prop, "order": "desc"})
            elif lower.endswith(" asc"):
                prop = clause[: -len(" asc")].strip()
                result.append({"property": prop, "order": "asc"})
            else:
                result.append({"property": clause, "order": "asc"})
        return result

    def get_top(self) -> str | None:
        """Extract $top value."""
        val = self.params.get("$top")
        if val is not None:
            self._validate_numeric_option("$top", val)
        return val

    def get_skip(self) -> str | None:
        """Extract $skip value."""
        val = self.params.get("$skip")
        if val is not None:
            self._validate_numeric_option("$skip", val)
        return val

    @staticmethod
    def _validate_numeric_option(name: str, value: str) -> None:
        """Validate that a query option value is a non-negative integer."""
        if not value.isdigit():
            raise ValidationError(
                message=f"{name} must be a non-negative integer, got: {value!r}",
                code="DXS-DATASOURCE-011",
                suggestions=[
                    f"Use a numeric value for {name}, e.g. {name}=10",
                    "Check for stray characters like ')' in the query string",
                ],
            )

    def get_count(self) -> bool | None:
        """Extract $count flag. Returns None if $count is not present."""
        count = self.params.get("$count")
        if count is None:
            return None
        return count.lower() in ("true", "1")

    def get_apply(self) -> list[ParsedApplyClause] | None:
        """Extract $apply transformations.

        Parses $apply into a list of typed transformation models.
        Supports: filter, groupby (with optional aggregate), aggregate,
        and chained pipelines (e.g., filter(...)/groupby(...)).

        Returns:
            List of ParsedApplyClause models or None if no $apply present.
        """
        apply_str = self.params.get("$apply")
        if not apply_str:
            return None
        return self._parse_apply_string(apply_str)

    def _parse_apply_string(self, apply_str: str) -> list[ParsedApplyClause]:
        """Parse $apply expression into structured transformations.

        Supports chained pipelines separated by ``/`` at the top level:
        - ``filter(expression)``
        - ``groupby((paths),aggregate(...))``
        - ``aggregate(clauses)``

        Examples::

            groupby((Category),aggregate($count as Total))
            filter(Status eq 'Active')/groupby((Category),aggregate(Amount with sum as Total))
            aggregate(LineTotal with sum as GrandTotal,$count as RowCount)

        Args:
            apply_str: The $apply expression value.

        Returns:
            List of ParsedApplyClause models.
        """
        apply_str = apply_str.strip()
        segments = self._split_apply_pipeline(apply_str)
        result: list[ParsedApplyClause] = []
        for segment in segments:
            parsed = self._parse_single_apply_segment(segment)
            if parsed is None:
                raise ValidationError(
                    message=f"Unrecognized $apply transformation: {segment}",
                    code="DXS-DATASOURCE-010",
                    suggestions=[
                        "Supported transformations: filter(...), groupby(...), aggregate(...)",
                        "Check for typos in the transformation name",
                        "Chained pipelines use '/' as separator: filter(...)/groupby(...)",
                    ],
                )
            result.append(parsed)
        return result

    def _split_apply_pipeline(self, apply_str: str) -> list[str]:
        """Split a chained $apply pipeline on ``/`` respecting parenthesis nesting.

        ``filter(a/b eq 1)/groupby(...)`` splits into
        ``["filter(a/b eq 1)", "groupby(...)"]`` — slashes inside parens are preserved.
        """
        segments: list[str] = []
        depth = 0
        start = 0
        for i, c in enumerate(apply_str):
            if c == "(":
                depth += 1
            elif c == ")":
                depth -= 1
            elif c == "/" and depth == 0:
                seg = apply_str[start:i].strip()
                if seg:
                    segments.append(seg)
                start = i + 1
        tail = apply_str[start:].strip()
        if tail:
            segments.append(tail)
        return segments

    def _parse_single_apply_segment(self, segment: str) -> ParsedApplyClause | None:
        """Parse one transformation segment (filter, groupby, or aggregate)."""
        lower = segment.lower()

        # --- filter(...) ---
        if lower.startswith("filter(") and segment.endswith(")"):
            inner = segment[len("filter(") : -1]
            return ParsedFilterClause(filterExpression=inner)

        # --- aggregate(...) ---
        if lower.startswith("aggregate(") and segment.endswith(")"):
            agg_inner = segment[len("aggregate(") : -1]
            return ParsedAggregateClause(
                aggregates=self._parse_aggregate_clauses(agg_inner),
            )

        # --- groupby(...) ---
        if lower.startswith("groupby(") and segment.endswith(")"):
            inner = segment[len("groupby(") : -1]
            if not inner.startswith("("):
                raise ValidationError(
                    message=f"Malformed groupby: property list must start with '(' -- got: groupby({inner})",
                    code="DXS-DATASOURCE-011",
                    suggestions=[
                        "groupby requires double parens: groupby((Prop1,Prop2),aggregate(...))",
                        "The inner parentheses wrap the property list",
                    ],
                )

            prop_list_str, rest = self._extract_parenthesized(inner)
            property_paths = [
                [seg.strip() for seg in path.strip().split("/")]
                for path in prop_list_str.split(",")
                if path.strip()
            ]

            aggregates: list[ParsedAggregate] = []
            rest = rest.strip()
            if rest.startswith(","):
                tail = rest[1:].strip()
                if tail.lower().startswith("aggregate(") and tail.endswith(")"):
                    agg_inner = tail[len("aggregate(") : -1]
                    aggregates = self._parse_aggregate_clauses(agg_inner)

            return ParsedGroupByClause(
                propertyPaths=property_paths,
                aggregates=aggregates,
            )

        return None

    def _extract_parenthesized(self, s: str) -> tuple[str, str]:
        """Extract content of the first parenthesized group and return the remainder.

        Args:
            s: String starting with "(".

        Returns:
            Tuple of (content_inside_parens, rest_after_closing_paren).
        """
        if not s.startswith("("):
            return s, ""

        depth = 0
        for i, c in enumerate(s):
            if c == "(":
                depth += 1
            elif c == ")":
                depth -= 1
                if depth == 0:
                    return s[1:i], s[i + 1 :]

        return s[1:], ""  # unbalanced — return all as content

    def _split_aggregate_clauses(self, agg_str: str) -> list[str]:
        """Split aggregate clauses on commas, respecting parenthesis nesting.

        This avoids breaking on commas inside nested function calls, consistent
        with the parenthesis-aware splitting used elsewhere in the parser.
        """
        clauses: list[str] = []
        depth = 0
        start = 0
        for i, c in enumerate(agg_str):
            if c == "(":
                depth += 1
            elif c == ")":
                depth -= 1
            elif c == "," and depth == 0:
                clause = agg_str[start:i].strip()
                if clause:
                    clauses.append(clause)
                start = i + 1
        tail = agg_str[start:].strip()
        if tail:
            clauses.append(tail)
        return clauses

    def _parse_aggregate_clauses(self, agg_str: str) -> list[ParsedAggregate]:
        """Parse comma-separated aggregate clauses.

        Supports two forms:
        - ``Property with method as Alias``  (standard aggregate)
        - ``$count as Alias``  (row count — no property or method)

        Args:
            agg_str: E.g. "LineTotal with sum as TotalRevenue,$count as RowCount"

        Returns:
            List of ParsedAggregate models.
        """
        result: list[ParsedAggregate] = []
        for clause in self._split_aggregate_clauses(agg_str):
            clause = clause.strip()
            if not clause:
                continue
            # Pattern 1: Property with method as Alias
            match = re.match(r"^(.+?)\s+with\s+(\w+)\s+as\s+(\w+)$", clause, re.IGNORECASE)
            if match:
                prop_path = match.group(1).strip()
                method = match.group(2).lower()
                alias = match.group(3)
                result.append(
                    ParsedAggregate(
                        property=[seg.strip() for seg in prop_path.split("/")],
                        method=method,
                        alias=alias,
                    )
                )
                continue
            # Pattern 2: $count as Alias (no property path, no method)
            count_match = re.match(r"^\$count\s+as\s+(\w+)$", clause, re.IGNORECASE)
            if count_match:
                result.append(
                    ParsedAggregate(
                        property=["$count"],
                        alias=count_match.group(1),
                    )
                )
        return result


class DatasourceGenerator:
    """Generate Datex datasource JSON configurations from OData queries."""

    def __init__(self, api_client: ApiClient):
        """Initialize generator with API client for metadata lookup.

        Args:
            api_client: Authenticated API client for metadata queries
        """
        self.client = api_client
        self.warnings: list[str] = []

    def generate(
        self,
        connection_id: int,
        query: str,
        reference_name: str,
        title: str,
        api_setting_name: str = DEFAULT_CONNECTION_TYPE,
        description: str | None = None,
        detect_params: bool = False,
        param_keys: bool = False,
        key_param_name: str | None = None,
        output_single: bool = False,
    ) -> DatasourceConfig:
        """Generate datasource configuration from OData query.

        Args:
            connection_id: API connection ID for metadata lookup
            query: OData query string
            reference_name: Unique datasource reference name (e.g., 'ds_orders')
            title: Display title
            api_setting_name: API connection setting name
            description: Optional description
            detect_params: Auto-detect input parameters from filter expressions
            param_keys: Convert key segment values to input parameters
            key_param_name: Custom parameter name for key (auto-generated if None)
            output_single: Set outputResultAsSingleObject=True on the config

        Returns:
            Complete datasource configuration

        Raises:
            ValidationError: If query is invalid or entity not found
        """
        self.warnings = []
        parser = ODataQueryParser(query)

        # Fetch entity metadata
        entity_set_name = parser.entity_set
        key_def = self._get_entity_key_def(connection_id, entity_set_name)

        # Fetch entity type ID (needed for type inference)
        path, params = FootPrintMetadataEndpoints.entity_sets(
            connection_id, filter=f"Name eq '{entity_set_name}'"
        )
        response = self.client.get(path, params=params)
        entity_set_response = ODataListResponse[EntitySetDto](**response)
        if not entity_set_response.value:
            raise ValidationError(
                message=f"Entity set '{entity_set_name}' not found in metadata",
                code="DXS-DATASOURCE-002",
                suggestions=[
                    "Run 'dxs schema entities' to see available entity sets",
                    "Check the spelling of the entity set name in your query",
                ],
            )
        entity_type_id = entity_set_response.value[0].type_id

        # Build path configuration
        paths = self._build_paths(parser, key_def, param_keys, key_param_name, entity_set_name)

        # Detect $apply before building query options — it changes the type inference path
        apply_clauses = parser.get_apply()

        query_options_type_def = None
        out_params = None
        apply_key_def: list[DSKeyConfig] = []  # populated in $apply branch below

        if apply_clauses:
            apply_configs = self._build_apply_configs(apply_clauses)
            apply_key_def = self._build_apply_key_def(connection_id, entity_type_id, apply_clauses)

            # Determine if $apply changes the result shape.
            # filter-only pipelines preserve the entity shape — $select/$expand still apply.
            # groupby/aggregate pipelines produce a new shape — $select/$expand are irrelevant.
            shape_changing = any(
                c.transformation in ("groupby", "aggregate") for c in apply_clauses
            )

            if shape_changing:
                # Shape-changing: type def from aggregation, drop $select/$expand
                query_options = self._build_query_options_apply(
                    parser, apply_configs, apply_key_def
                )
                query_options_type_def = self._build_apply_type_definition(
                    connection_id, entity_type_id, apply_clauses
                )
                out_params = [
                    TypeConfig(
                        id="result",
                        type="object",
                        isCollection=True,
                        objectTypeDef=query_options_type_def,
                    )
                ]
            else:
                # Filter-only: preserve $select/$expand, type def from entity metadata
                query_options = self._build_query_options(parser, key_def)
                if query_options is None:
                    query_options = DSQueryOptionsConfig()
                # Inject apply configs into the standard query options
                query_options.apply = apply_configs
                query_options.applyKeyDef = apply_key_def or None

                selects = query_options.selects
                expands_raw = parser.get_expand()
                if selects or expands_raw:
                    query_options_type_def = self._build_type_definition(
                        connection_id, entity_type_id, selects, expands_raw
                    )
                    out_params = [
                        TypeConfig(
                            id="result",
                            type="object",
                            isCollection=parser.is_collection,
                            objectTypeDef=query_options_type_def,
                        )
                    ]
        else:
            # Standard path: build query options and infer types from entity metadata
            query_options = self._build_query_options(parser, key_def)

            if query_options:
                selects = query_options.selects
                expands_raw = parser.get_expand()

                query_options_type_def = self._build_type_definition(
                    connection_id, entity_type_id, selects, expands_raw
                )
                out_params = [
                    TypeConfig(
                        id="result",
                        type="object",
                        isCollection=parser.is_collection,
                        objectTypeDef=query_options_type_def,
                    )
                ]

        # Ensure isSecured is boolean for key definitions (not None)
        for key in key_def:
            if key.isSecured is None:
                key.isSecured = False

        # Detect input parameters
        in_params = None
        if detect_params and query_options and query_options.filters:
            in_params = self._detect_input_params(
                query_options.filters,
                connection_id=connection_id,
                entity_type_id=entity_type_id,
            )
            # Apply $utils.isDefined() guards to filters with detected params
            if in_params:
                detected_param_names = {p.id for p in in_params}
                for f in query_options.filters:
                    if f.hasCondition:
                        continue
                    expr = f.expression.value
                    matched = [
                        pname
                        for pname in detected_param_names
                        if re.search(rf"\.inParams\.{re.escape(pname)}\b", expr)
                    ]
                    if matched:
                        f.hasCondition = True
                        if len(matched) == 1:
                            f.condition = f"$utils.isDefined($datasource.inParams.{matched[0]})"
                        else:
                            f.condition = " && ".join(
                                f"$utils.isDefined($datasource.inParams.{p})" for p in matched
                            )

        # Add key parameters if parameterization requested
        if param_keys and parser.has_key:
            key_params = self._build_key_params(parser, key_def, key_param_name, entity_set_name)
            if in_params:
                in_params.extend(key_params)
            else:
                in_params = key_params
        elif param_keys and not parser.has_key:
            self.warnings.append(
                "Warning: --param-keys ignored -- query has no key segment (e.g., 'Entity(0)')."
            )

        if key_param_name and not param_keys:
            self.warnings.append("Warning: --key-param-name has no effect without --param-keys.")

        if output_single and parser.is_collection and not apply_clauses:
            self.warnings.append(
                "Warning: --output-single has no effect on collection queries (no key segment)."
            )

        # Determine top-level keyDef and hasKey based on query type:
        # - $apply/groupby: top-level key = groupby result identity (apply_key_def)
        # - single-entity (has key path segment): no top-level key (null/null)
        # - regular collection: top-level key = entity key
        if apply_clauses:
            _key_def: list[DSKeyConfig] | None = apply_key_def if apply_key_def else None
            _has_key: bool | None = True if apply_key_def else None
        elif not parser.is_collection:
            _key_def = None
            _has_key = None
        else:
            _key_def = key_def if key_def else None
            _has_key = True if key_def else None

        return DatasourceConfig(
            type="oDataQuery",
            fromBaseConfiguration=None,
            referenceName=reference_name,
            title=title,
            apiSettingName=api_setting_name,
            description=description,
            paths=paths,
            isCollection=parser.is_collection,
            queryOptions=query_options,
            queryOptionsObjectTypeDef=query_options_type_def,
            inParams=in_params,
            outParams=out_params,
            keyDef=_key_def,
            hasKey=_has_key,
            outputResultAsSingleObject=True if output_single else None,
            # $apply always returns a collection regardless of key segment in query path
            resultIsCollection=True if apply_clauses else parser.is_collection,
            accessModifier=DEFAULT_ACCESS_MODIFIER,
        )

    # ------------------------------------------------------------------
    # $apply support methods
    # ------------------------------------------------------------------

    def _build_apply_configs(self, apply_clauses: list[ParsedApplyClause]) -> list[DSApplyConfig]:
        """Build DSApplyConfig list from parsed apply clauses.

        Args:
            apply_clauses: Parsed apply clauses from ODataQueryParser.get_apply().

        Returns:
            List of DSApplyConfig ready for DSQueryOptionsConfig.apply.
        """
        result = []
        for clause in apply_clauses:
            if isinstance(clause, ParsedFilterClause):
                result.append(
                    DSApplyConfig(
                        transformation="filter",
                        filterConfig=[
                            DSFilterConfig(
                                expression=DSExpressionConfig(
                                    value=(
                                        f"`{clause.filterExpression}`"
                                        if "${" in clause.filterExpression
                                        else f"'{clause.filterExpression}'"
                                    )
                                ),
                            )
                        ],
                    )
                )

            elif isinstance(clause, ParsedAggregateClause):
                agg_configs = [
                    DSAggregateConfig(
                        method=agg.method,
                        alias=agg.alias,
                        property=agg.property,
                    )
                    for agg in clause.aggregates
                ]
                result.append(
                    DSApplyConfig(
                        transformation="aggregate",
                        aggregateConfig=agg_configs or None,
                    )
                )

            elif isinstance(clause, ParsedGroupByClause):
                agg_configs = [
                    DSAggregateConfig(
                        method=agg.method,
                        alias=agg.alias,
                        property=agg.property,
                    )
                    for agg in clause.aggregates
                ]
                result.append(
                    DSApplyConfig(
                        transformation="groupby",
                        groupByConfig=DSApplyGroupByConfig(
                            propertyPaths=clause.propertyPaths,
                            aggregate=agg_configs or None,
                        ),
                    )
                )
        return result

    def _build_apply_key_def(
        self,
        connection_id: int,
        entity_type_id: str,
        apply_clauses: list[ParsedApplyClause],
    ) -> list[DSKeyConfig]:
        """Build applyKeyDef from groupby paths.

        All groupby property paths become key entries (matching the API's ds_orders_by_status
        pattern where every groupby path is in both applyKeyDef and keyDef).  Path segments
        are joined with "." (dot), not "/" (slash), to match the API's dot-notation convention.

        Type inference uses metadata resolution (same as ``_build_apply_type_definition``)
        rather than heuristics, for consistency.

        Args:
            connection_id: API connection ID for metadata lookups.
            entity_type_id: Starting entity type ID.
            apply_clauses: Parsed apply clauses.

        Returns:
            List of DSKeyConfig for the aggregated result identity.
        """
        for clause in apply_clauses:
            if isinstance(clause, ParsedGroupByClause):
                property_paths = clause.propertyPaths
                return [
                    DSKeyConfig(
                        id=".".join(path),
                        type=self._resolve_property_path_type(connection_id, entity_type_id, path),
                        isSecured=False,
                    )
                    for path in property_paths
                ]
        return []

    def _build_query_options_apply(
        self,
        parser: "ODataQueryParser",
        apply_configs: list[DSApplyConfig],
        apply_key_def: list[DSKeyConfig],
    ) -> DSQueryOptionsConfig:
        """Build DSQueryOptionsConfig for a shape-changing $apply query (groupby/aggregate).

        Only $orderby, $top, $skip are carried; $select/$expand are dropped because
        groupby/aggregate produces a new result shape. For filter-only $apply
        pipelines, the caller uses _build_query_options() instead to preserve
        $select/$expand.

        Args:
            parser: Parsed OData query.
            apply_configs: Built DSApplyConfig list.
            apply_key_def: Built applyKeyDef list.

        Returns:
            DSQueryOptionsConfig with apply, applyKeyDef, orderBys, top, skip.
        """
        orderbys = parser.get_orderby()
        top = parser.get_top()
        skip = parser.get_skip()

        orderby_configs = None
        if orderbys:
            orderby_configs = [
                DSOrderByConfig(property=ob["property"].split("/"), order=ob["order"])  # type: ignore
                for ob in orderbys
            ]

        return DSQueryOptionsConfig(
            apply=apply_configs,
            applyKeyDef=apply_key_def,
            orderBys=orderby_configs,
            hasTop=True if top is not None else None,
            top=top,
            hasSkip=True if skip is not None else None,
            skip=skip,
        )

    def _build_apply_type_definition(
        self,
        connection_id: int,
        entity_type_id: str,
        apply_clauses: list[ParsedApplyClause],
    ) -> list[TypeConfig]:
        """Build type definition from $apply clauses.

        Resolves the leaf type of each groupby path by walking entity
        metadata, merges shared path prefixes into nested objects, then
        appends aggregate aliases as number fields.

        Args:
            connection_id: API connection ID for metadata lookup.
            entity_type_id: Base entity type ID (e.g. 'Demo.InvoiceLine').
            apply_clauses: Parsed apply clauses from get_apply().

        Returns:
            List of TypeConfig representing the aggregated result shape.
        """
        type_def: list[TypeConfig] = []

        for clause in apply_clauses:
            if isinstance(clause, ParsedGroupByClause):
                # Build a nested tree, resolving leaf types via metadata
                tree: dict[str, Any] = {}
                for path in clause.propertyPaths:
                    leaf_type = self._resolve_property_path_type(
                        connection_id, entity_type_id, path
                    )
                    self._insert_path_into_tree(tree, path, leaf_type)

                type_def.extend(self._tree_to_type_configs(tree))

                # Aggregate aliases are always "number" — covers sum/min/max/average/countdistinct
                # and $count. JS `number` encompasses both integers and floats, so no distinction needed.
                for agg in clause.aggregates:
                    type_def.append(TypeConfig(id=agg.alias, type="number", isCollection=False))

            elif isinstance(clause, ParsedAggregateClause):
                # Standalone aggregate — no groupby paths, just alias fields.
                # All aggregate results are JS "number" (see comment above).
                for agg in clause.aggregates:
                    type_def.append(TypeConfig(id=agg.alias, type="number", isCollection=False))

            # filter transformations don't change the output type shape

        return type_def

    def _resolve_property_path_type(
        self,
        connection_id: int,
        entity_type_id: str,
        path: list[str],
    ) -> str:
        """Walk a property path through metadata and return the JS type of the leaf.

        Intermediate segments are resolved as navigation properties; the final
        segment is resolved as a scalar property.

        Args:
            connection_id: API connection ID.
            entity_type_id: Starting entity type ID.
            path: Path segments, e.g. ["Invoice", "Project", "Owner", "Id"].

        Returns:
            JS type string.  Defaults to "string" on any lookup failure.
        """
        current_type_id = entity_type_id

        for i, segment in enumerate(path):
            is_last = i == len(path) - 1

            if is_last:
                prop_path, prop_params = FootPrintMetadataEndpoints.properties(
                    connection_id,
                    filter=f"EntityTypeId eq '{current_type_id}' and Name eq '{segment}'",
                )
                response = self.client.get(prop_path, params=prop_params)
                props = ODataListResponse[PropertyDto](**response).value
                if props:
                    return self._map_odata_type_to_jstype(props[0].type_id)
                return "string"
            else:
                nav_path, nav_params = FootPrintMetadataEndpoints.navigation_properties(
                    connection_id,
                    filter=f"EntityTypeId eq '{current_type_id}' and Name eq '{segment}'",
                )
                response = self.client.get(nav_path, params=nav_params)
                navs = ODataListResponse[NavigationPropertyDto](**response).value
                if navs:
                    current_type_id = navs[0].type_id
                else:
                    return "string"

        return "string"  # unreachable but satisfies type checker

    def _insert_path_into_tree(
        self,
        tree: dict[str, Any],
        path: list[str],
        leaf_type: str,
    ) -> None:
        """Insert a property path into the nested tree structure (in-place).

        Navigation segments become ``{"__nav": True, "__children": {...}}``.
        Leaf segments become ``{"__nav": False, "__type": leaf_type}``.

        Args:
            tree: Tree dict to insert into.
            path: Path segments.
            leaf_type: JS type of the leaf property.
        """
        node = tree
        for segment in path[:-1]:
            if segment not in node:
                node[segment] = {"__nav": True, "__children": {}}
            node = node[segment]["__children"]

        leaf = path[-1]
        node[leaf] = {"__nav": False, "__type": leaf_type}

    def _tree_to_type_configs(self, tree: dict[str, Any]) -> list[TypeConfig]:
        """Convert a nested path tree into a flat list of TypeConfig.

        Navigation nodes become TypeConfig with type="object" and
        nested objectTypeDef.  Leaf nodes become scalar TypeConfig.

        Args:
            tree: Tree built by _insert_path_into_tree.

        Returns:
            List of TypeConfig instances.
        """
        result: list[TypeConfig] = []
        for key, value in tree.items():
            if value.get("__nav"):
                nested = self._tree_to_type_configs(value["__children"])
                result.append(
                    TypeConfig(id=key, type="object", isCollection=False, objectTypeDef=nested)
                )
            else:
                result.append(TypeConfig(id=key, type=value["__type"], isCollection=False))
        return result

    # ------------------------------------------------------------------

    def _get_entity_key_def(self, connection_id: int, entity_set_name: str) -> list[DSKeyConfig]:
        """Fetch key definition for entity set from metadata.

        Args:
            connection_id: API connection ID
            entity_set_name: Entity set name

        Returns:
            List of key configurations

        Raises:
            ValidationError: If entity set not found
        """
        from dxs.core.api.metadata_models import PropertyDto

        # Fetch entity set
        path, params = FootPrintMetadataEndpoints.entity_sets(
            connection_id, filter=f"Name eq '{entity_set_name}'"
        )
        response = self.client.get(path, params=params)
        odata_response = ODataListResponse[EntitySetDto](**response)

        if not odata_response.value:
            raise ValidationError(
                message=f"Entity set '{entity_set_name}' not found",
                code="DXS-DATASOURCE-003",
                suggestions=[
                    "Use 'dxs schema entities' to see available entities",
                    "Check entity set name spelling",
                ],
            )

        entity_set = odata_response.value[0]
        type_id = entity_set.type_id

        # Fetch entity type to get key names
        path, params = FootPrintMetadataEndpoints.entity_types(
            connection_id, filter=f"TypeId eq '{type_id}'"
        )
        response = self.client.get(path, params=params)
        type_response = ODataListResponse[EntityTypeDto](**response)

        if not type_response.value:
            raise ValidationError(
                message=f"Entity type '{type_id}' not found",
                code="DXS-DATASOURCE-004",
                suggestions=["Entity set metadata may be incomplete"],
            )

        entity_type = type_response.value[0]

        key_names = entity_type.key_names

        if not key_names:
            raise ValidationError(
                message=f"Entity type '{type_id}' has no keys defined",
                code="DXS-DATASOURCE-005",
                suggestions=["Entity must have at least one key property"],
            )

        # Fetch properties to get key types
        path, params = FootPrintMetadataEndpoints.properties(
            connection_id, filter=f"EntityTypeId eq '{type_id}' and IsKey eq true"
        )
        response = self.client.get(path, params=params)
        props_response = ODataListResponse[PropertyDto](**response)

        # Build key configs
        key_configs = []
        for key_name in key_names:
            # Find matching property
            prop = next(
                (p for p in props_response.value if p.name == key_name),
                None,
            )
            if prop:
                js_type = self._map_odata_type_to_jstype(prop.type_id)
                key_configs.append(
                    DSKeyConfig(
                        id=key_name,
                        type=js_type,
                        isSecured=None,
                    )
                )
            else:
                # Fallback if property not found - assume string
                key_configs.append(
                    DSKeyConfig(
                        id=key_name,
                        type="string",
                        isSecured=None,
                    )
                )

        return key_configs

    def _map_odata_type_to_jstype(self, odata_type: str) -> str:
        """Map OData EDM type to JSType.

        Args:
            odata_type: OData EDM type (e.g., 'Edm.String', 'Edm.Int32')

        Returns:
            JSType value
        """
        return ODATA_TYPE_MAP.get(odata_type, "string")

    def _build_paths(
        self,
        parser: ODataQueryParser,
        key_def: list[DSKeyConfig],
        param_keys: bool = False,
        key_param_name: str | None = None,
        entity_set_name: str | None = None,
    ) -> list[DSPathSegmentConfig]:
        """Build path configuration from parsed query.

        Args:
            parser: Parsed OData query
            key_def: Entity key definition
            param_keys: Whether to parameterize key values
            key_param_name: Custom parameter name for key
            entity_set_name: Entity set name (for auto-generating param name)

        Returns:
            List of path segments
        """
        paths: list[DSPathSegmentConfig] = []

        for segment in parser.path_segments:
            if segment["type"] == "entitySet":
                paths.append(
                    DSPathEntitySetConfig(
                        type="entitySet",
                        entitySet=segment["name"],
                        keyDef=key_def,
                    )
                )
            elif segment["type"] == "key":
                # Build key segment
                # For now, assume single key
                if len(key_def) == 1:
                    key_config = key_def[0]

                    # Determine key value
                    if param_keys:
                        # Use parameter expression
                        param_name = key_param_name or self._generate_key_param_name(
                            entity_set_name or "entity", key_config.id
                        )
                        key_value = f"$datasource.inParams.{param_name}"
                    else:
                        # Use literal value from query
                        key_value = segment["value"]

                    paths.append(
                        DSPathKeyConfig(
                            type="key",
                            keys=[
                                {
                                    "name": key_config.id,
                                    "type": key_config.type,
                                    "value": key_value,
                                }
                            ],
                        )
                    )
                else:
                    # Composite key - would need more complex parsing
                    raise ValidationError(
                        message="Composite keys not yet supported",
                        code="DXS-DATASOURCE-006",
                        suggestions=["Use single-key entities for now"],
                    )
            elif segment["type"] == "navigationProperty":
                # Navigation property - would need metadata lookup for keyDef
                # For now, skip or use placeholder
                raise ValidationError(
                    message="Navigation properties not yet supported in path",
                    code="DXS-DATASOURCE-007",
                    suggestions=["Use $expand instead of navigation in path"],
                )

        return paths

    def _build_query_options(
        self, parser: ODataQueryParser, key_def: list[DSKeyConfig]
    ) -> DSQueryOptionsConfig | None:
        """Build query options from parsed query.

        Args:
            parser: Parsed OData query
            key_def: Entity key definition (used to default selects if needed)

        Returns:
            Query options configuration or None if no options
        """
        selects = parser.get_select_fields()
        filter_str = parser.get_filter()
        orderbys = parser.get_orderby()
        expands = parser.get_expand()
        top = parser.get_top()
        skip = parser.get_skip()
        count = parser.get_count()

        # CRITICAL FIX: UI requires at least one select field
        # If no selects but expands exist, default to entity keys
        if not selects and expands:
            selects = [key.id for key in key_def]

        # Build filters
        filters = None
        if filter_str:
            # Use backtick wrapping for JS template literals (contain ${...}),
            # single-quote wrapping for static OData filter expressions.
            quote = "`" if "${" in filter_str else "'"
            filters = [
                DSFilterConfig(
                    expression=DSExpressionConfig(
                        type="statement",
                        value=f"{quote}{filter_str}{quote}",
                    ),
                )
            ]

        # Build orderBys
        orderby_configs = None
        if orderbys:
            orderby_configs = [
                DSOrderByConfig(
                    property=ob["property"].split("/"),
                    order=ob["order"],  # type: ignore
                )
                for ob in orderbys
            ]

        # Build expands with nested structure
        expand_configs = None
        if expands:
            expand_configs = [self._build_expand_config(exp) for exp in expands]

        # Only create query options if we have something
        if any([selects, filters, orderby_configs, expand_configs, top, skip, count]):
            return DSQueryOptionsConfig(
                selects=selects,
                filters=filters,
                orderBys=orderby_configs,
                expands=expand_configs,
                hasTop=True if top is not None else None,
                top=top,
                hasSkip=True if skip is not None else None,
                skip=skip,
                count=count or None,
            )

        return None

    def _build_expand_config(self, expand_dict: dict[str, Any]) -> "DSExpandConfig":
        """Build expand configuration from parsed expand dictionary.

        Args:
            expand_dict: Parsed expand with 'property' and required 'select' fields

        Returns:
            Expand configuration dictionary for datasource JSON

        Raises:
            ValidationError: If expand is missing required $select clause
        """
        # Validate that expand has $select - this is required by Studio UI
        if "select" not in expand_dict or not expand_dict["select"]:
            raise ValidationError(
                message=f"Expand '{expand_dict['property']}' is missing required $select clause",
                code="DXS-DATASOURCE-008",
                suggestions=[
                    f"Add $select to expand: {expand_dict['property']}($select=Field1,Field2)",
                    "Use 'dxs schema describe-entity {entity}' to see available properties",
                    "Example: Orders?$expand=Owner($select=Name,Email)",
                ],
            )

        # Build filters
        filters = None
        if "filter" in expand_dict:
            filter_str = expand_dict["filter"]
            quote = "`" if "${" in filter_str else "'"
            filters = [
                DSFilterConfig(
                    expression=DSExpressionConfig(
                        type="statement",
                        value=f"{quote}{filter_str}{quote}",
                    ),
                )
            ]

        # Build orderBys
        orderby_configs = None
        if "orderby" in expand_dict:
            orderby_configs = [
                DSOrderByConfig(
                    property=ob["property"].split("/"),
                    order=ob["order"],  # type: ignore
                )
                for ob in expand_dict["orderby"]
            ]

        # Build nested expands (recursive)
        expand_configs = None
        if "expands" in expand_dict:
            expand_configs = [self._build_expand_config(exp) for exp in expand_dict["expands"]]

        # Build complete queryOptions structure (always present for UI compatibility)
        # Move selects INSIDE queryOptions instead of at expand level
        top = expand_dict.get("top")
        skip = expand_dict.get("skip")
        count = expand_dict.get("count")
        # Return DSExpandConfig model instance to ensure all fields are preserved
        return DSExpandConfig(
            property=expand_dict["property"],
            isCollection=None,  # UI infers from metadata
            queryOptions=DSQueryOptionsConfig(
                selects=expand_dict["select"],
                filters=filters,
                orderBys=orderby_configs,
                expands=expand_configs,
                hasTop=True if top is not None else None,
                top=top,
                hasSkip=True if skip is not None else None,
                skip=skip,
                count=count or None,
                apply=None,
                applyKeyDef=None,
            ),
        )

    def _build_type_definition(
        self,
        connection_id: int,
        entity_type_id: str,
        selects: list[str] | None,
        expands: list[dict] | None,
    ) -> list[TypeConfig]:
        """Build recursive type definition from query structure.

        Queries OData metadata to discover property types and builds a recursive
        type definition tree representing the shape of query results.

        Args:
            connection_id: API connection ID for metadata lookup
            entity_type_id: Entity type ID (e.g., 'Demo.Order')
            selects: List of selected scalar properties
            expands: List of expanded navigation properties with nested structure

        Returns:
            List of TypeConfig representing the shape of query results
        """
        type_def = []

        # 1. Fetch scalar properties for this entity type
        path, params = FootPrintMetadataEndpoints.properties(
            connection_id, filter=f"EntityTypeId eq '{entity_type_id}'"
        )
        response = self.client.get(path, params=params)
        props_response = ODataListResponse[PropertyDto](**response)

        # 2. Add selected scalar properties
        if selects:
            props_to_include = [p for p in props_response.value if p.name in selects]
            # Warn about $select fields not found in scalar properties.
            # Navigation property names resolved via $expand are handled separately,
            # so only flag names that are truly absent from scalar metadata.
            expand_names = {e["property"] for e in expands} if expands else set()
            resolved_names = {p.name for p in props_to_include}
            unresolved = [s for s in selects if s not in resolved_names and s not in expand_names]
            if unresolved:
                self.warnings.append(
                    f"Warning: $select field(s) not found in metadata: "
                    f"{', '.join(sorted(unresolved))}. "
                    "They will be included in the query but omitted from the type definition."
                )
        else:
            # If no selects specified, include all properties (should not happen with validation)
            props_to_include = props_response.value

        for prop in props_to_include:
            type_def.append(
                TypeConfig(
                    id=prop.name,
                    type=self._map_odata_type_to_jstype(prop.type_id),
                    isCollection=prop.is_collection,
                )
            )

        # 3. Handle expanded navigation properties (recursive)
        if expands:
            path, params = FootPrintMetadataEndpoints.navigation_properties(
                connection_id, filter=f"EntityTypeId eq '{entity_type_id}'"
            )
            response = self.client.get(path, params=params)
            nav_response = ODataListResponse[NavigationPropertyDto](**response)

            for expand in expands:
                prop_name = expand["property"]
                nav_prop = next((n for n in nav_response.value if n.name == prop_name), None)

                if not nav_prop:
                    # Navigation property not found in metadata - skip
                    continue

                # The Footprint Metadata API uses a dedicated IsCollection boolean field.
                # type_id is always the bare type name (never wrapped in Collection(...)).
                target_type = nav_prop.type_id
                is_collection = nav_prop.is_collection

                # Get nested selects/expands - handle both raw parsed and built formats
                nested_selects = None
                nested_expands = None
                if "queryOptions" in expand and expand["queryOptions"]:
                    # Built format (from _build_expand_config)
                    nested_selects = expand["queryOptions"].get("selects")
                    nested_expands = expand["queryOptions"].get("expands")
                else:
                    # Raw parsed format (from parser.get_expand())
                    nested_selects = expand.get("select")
                    nested_expands = expand.get("expands")

                # Recursively build type definition for nested entity
                nested_type_def = self._build_type_definition(
                    connection_id, target_type, nested_selects, nested_expands
                )

                type_def.append(
                    TypeConfig(
                        id=prop_name,
                        type="object",
                        isCollection=is_collection,
                        objectTypeDef=nested_type_def,
                    )
                )

        return type_def

    def _generate_key_param_name(self, entity_set_name: str, key_property: str) -> str:
        """Generate parameter name for key.

        Args:
            entity_set_name: Entity set name (e.g., "Shipments")
            key_property: Key property name (e.g., "Id")

        Returns:
            Generated parameter name (e.g., "shipmentId")
        """
        # Convert entity set name to singular camelCase.
        # Strip a single trailing 's' only for regular plurals (e.g. "Shipments" → "Shipment").
        # Do NOT strip when the word ends in 'ss' (e.g. "Status", "Address", "Process").
        if entity_set_name.endswith("s") and not entity_set_name.endswith("ss"):
            entity_singular = entity_set_name[:-1]
        else:
            entity_singular = entity_set_name
        entity_camel = (
            entity_singular[0].lower() + entity_singular[1:] if entity_singular else "entity"
        )

        # Combine with key property
        # If key is just "Id", use entityId pattern
        if key_property == "Id":
            return f"{entity_camel}Id"
        else:
            # Use entityKeyName pattern
            key_camel = key_property[0].upper() + key_property[1:] if key_property else "Key"
            return f"{entity_camel}{key_camel}"

    def _build_key_params(
        self,
        parser: ODataQueryParser,
        key_def: list[DSKeyConfig],
        key_param_name: str | None,
        entity_set_name: str,
    ) -> list[TypeConfig]:
        """Build input parameters for key segments.

        Args:
            parser: Parsed OData query
            key_def: Entity key definition
            key_param_name: Custom parameter name (or None for auto-generation)
            entity_set_name: Entity set name

        Returns:
            List of input parameter configurations
        """
        params: list[TypeConfig] = []

        # For now, only handle single key
        if len(key_def) == 1:
            key_config = key_def[0]
            param_name = key_param_name or self._generate_key_param_name(
                entity_set_name, key_config.id
            )

            params.append(
                TypeConfig(
                    id=param_name,
                    type=key_config.type,
                    required=True,
                    description=f"Key parameter for {entity_set_name}",
                )
            )

        return params

    @staticmethod
    def _infer_param_type(expr: str, param_name: str) -> str:
        """Infer a parameter's JSType from its usage context in an OData filter.

        Heuristics (checked in order):
        - format...Number/Int/Decimal → number
        - format...DateTime/Date      → date
        - format...Boolean             → boolean
        - param name ends with Id/Code/Number and used with 'eq' → number
        - otherwise                    → string
        """
        # Check $utils.odata.format* hints inserted by the codegen/UI
        format_pattern = rf"format\w*\(.*?{re.escape(param_name)}"
        format_match = re.search(format_pattern, expr, re.IGNORECASE)
        if format_match:
            fmt = format_match.group(0).lower()
            if any(kw in fmt for kw in ("number", "int", "decimal")):
                return "number"
            if any(kw in fmt for kw in ("datetime", "date")):
                return "date"
            if "boolean" in fmt:
                return "boolean"

        # Heuristic: param names ending with "Id" used with `eq` are typically numeric
        if re.search(r"\b\w+Id\b\s+eq\b", expr) and param_name.endswith("Id"):
            return "number"

        return "string"

    @staticmethod
    def _extract_filter_property_name(expr: str, param_name: str) -> str | None:
        """Extract the OData property name being compared to an inParams reference.

        Args:
            expr: Filter expression string
            param_name: The parameter name to look for

        Returns:
            The property name if found, otherwise None.
        """
        pattern = rf"(\w+)\s+(?:eq|ne|gt|lt|ge|le)\s+\$\{{[^}}]*\.{re.escape(param_name)}\}}"
        match = re.search(pattern, expr)
        return match.group(1) if match else None

    def _detect_input_params(
        self,
        filters: list[DSFilterConfig],
        connection_id: int | None = None,
        entity_type_id: str | None = None,
    ) -> list[TypeConfig] | None:
        """Auto-detect input parameters from filter expressions.

        Scans filter expressions for ``${...inParams.paramName}`` patterns and
        creates TypeConfig entries with types inferred from schema metadata
        (if available) or heuristics.

        Args:
            filters: List of filter configurations
            connection_id: Optional connection ID for metadata lookup
            entity_type_id: Optional entity type ID for metadata lookup

        Returns:
            List of detected input parameters, or None if none are found.
        """
        params: list[TypeConfig] = []
        seen: set[str] = set()

        # Build property type map from metadata if available
        prop_type_map: dict[str, str] = {}
        if connection_id is not None and entity_type_id is not None:
            try:
                path, qparams = FootPrintMetadataEndpoints.properties(
                    connection_id, filter=f"EntityTypeId eq '{entity_type_id}'"
                )
                response = self.client.get(path, params=qparams)
                props = ODataListResponse[PropertyDto](**response)
                prop_type_map = {
                    p.name: self._map_odata_type_to_jstype(p.type_id) for p in props.value
                }
            except Exception as e:
                self.warnings.append(
                    f"Warning: Could not fetch property metadata for type inference: {e}"
                )

        for filter_config in filters:
            expr = filter_config.expression.value

            # Look for template literal patterns like ${$datasource.inParams.paramName}
            param_pattern = r"\$\{.*?\.inParams\.(\w+)\}"
            matches = re.findall(param_pattern, expr)

            for param_name in matches:
                if param_name in seen:
                    continue
                seen.add(param_name)

                # Try metadata first, then fall back to heuristics
                prop_name = self._extract_filter_property_name(expr, param_name)
                if prop_name and prop_name in prop_type_map:
                    inferred_type = prop_type_map[prop_name]
                else:
                    inferred_type = self._infer_param_type(expr, param_name)

                params.append(
                    TypeConfig(
                        id=param_name,
                        type=inferred_type,  # type: ignore[arg-type]
                        required=False,
                        description=(
                            f"Auto-detected from filter: {expr[:50]}"
                            f"{'...' if len(expr) > 50 else ''}"
                        ),
                    )
                )

        return params if params else None
