"""Datasource configuration generation and validation.

This module provides tools for creating Datex datasource JSON configurations
from OData queries, enabling programmatic datasource creation for AI agents.
"""

from dxs.core.datasource.generator import DatasourceGenerator
from dxs.core.datasource.validator import DatasourceValidator

__all__ = ["DatasourceGenerator", "DatasourceValidator", "FlowDatasourceGenerator"]


def __getattr__(name: str) -> object:
    """Lazy import to avoid circular imports (flow_models ↔ models)."""
    if name == "FlowDatasourceGenerator":
        from dxs.core.datasource.flow_generator import FlowDatasourceGenerator

        return FlowDatasourceGenerator
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
