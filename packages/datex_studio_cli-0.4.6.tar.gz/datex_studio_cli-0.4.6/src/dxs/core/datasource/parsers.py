"""Shared parsers for datasource CLI flags.

Used by `dxs datasource generate`, `dxs datasource generate-flow`, and
`dxs report upload --owned FILE:ALIAS`.
"""

import re
from collections.abc import Sequence

import click

from dxs.core.datasource.models import (
    DatasourceConfig,
    DSDynamicOrderByConfig,
    DSExpressionConfig,
    DSFilterConfig,
    DSLinkedDatasourceConfig,
    DSLinkedDatasourceConfigRef,
    DSQueryOptionsConfig,
    DSValueConfig,
)
from dxs.core.designer.models import TypeConfig
from dxs.core.designer.parsers import (  # noqa: F401
    JS_RESERVED_WORDS,
    is_valid_js_identifier,
    parse_param,
)

DYNAMIC_FILTER_TYPES = {"boolean", "date", "number", "string"}

PARAM_FILTER_OPERATORS = {
    "eq",
    "ne",
    "gt",
    "ge",
    "lt",
    "le",
    "in",
    "contains",
    "startswith",
    "endswith",
}
STRING_ONLY_OPERATORS = {"contains", "startswith", "endswith"}

_ODATA_PROP_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_./]*$")


def parse_param_filter(value: str) -> tuple[str, str, str, str]:
    """Parse 'property:operator:param_name:type' -> (property, operator, param_name, type)."""
    parts = value.split(":", 3)
    if len(parts) != 4 or not all(parts):
        raise click.UsageError(
            f"--param-filter must be 'property:operator:param_name:type', got: {value!r}"
        )
    prop, op, param_name, typ = parts

    if not _ODATA_PROP_RE.match(prop):
        raise click.UsageError(
            f"--param-filter property must be a valid OData property name, got: {prop!r}"
        )
    if op not in PARAM_FILTER_OPERATORS:
        raise click.UsageError(
            f"--param-filter operator must be one of {sorted(PARAM_FILTER_OPERATORS)}, got: {op!r}"
        )
    if op in STRING_ONLY_OPERATORS and typ != "string":
        raise click.UsageError(
            f"--param-filter operator '{op}' requires type 'string', got: {typ!r}"
        )
    valid_types = {"string", "number", "date", "boolean"}
    if typ not in valid_types:
        raise click.UsageError(
            f"--param-filter type must be one of {sorted(valid_types)}, got: {typ!r}"
        )
    if not is_valid_js_identifier(param_name):
        raise click.UsageError(
            f"--param-filter param_name must be a valid JS identifier, got: {param_name!r}"
        )
    return prop, op, param_name, typ


def build_param_filter(
    prop: str, op: str, param_name: str, typ: str
) -> tuple[DSFilterConfig, TypeConfig]:
    """Build a conditional filter and inParam from a param-filter specification."""
    param_ref = f"$datasource.inParams.{param_name}"
    is_collection = op == "in"

    if op in ("eq", "ne", "gt", "ge", "lt", "le"):
        if typ == "string":
            expr_value = f"`{prop} {op} ${{{f'$utils.odata.formatString({param_ref})'}}}`"
        elif typ == "date":
            expr_value = f"`{prop} {op} ${{{f'$utils.odata.formatValue({param_ref})'}}}`"
        else:
            expr_value = f"`{prop} {op} ${{{param_ref}}}`"
    elif op == "in":
        expr_value = f"`{prop} in ${{{f'$utils.odata.formatValue({param_ref})'}}}`"
    elif op in ("contains", "startswith", "endswith"):
        expr_value = f"`{op}({prop}, ${{{f'$utils.odata.formatString({param_ref})'}}})`"
    else:
        # Unreachable: parse_param_filter validates op is in PARAM_FILTER_OPERATORS
        raise AssertionError(f"Unhandled operator: {op}")

    expr_value = expr_value.strip()

    filter_config = DSFilterConfig(
        hasCondition=True,
        condition=f"$utils.isDefined({param_ref})",
        expression=DSExpressionConfig(type="statement", value=expr_value),
    )
    in_param = TypeConfig(
        id=param_name,
        type=typ,  # type: ignore[arg-type]
        required=False,
        isCollection=is_collection or None,
    )
    return filter_config, in_param


def parse_dynamic_filter(value: str) -> TypeConfig:
    """Parse 'property:type' → TypeConfig. Raises UsageError if malformed."""
    parts = value.split(":", 1)
    if len(parts) != 2:
        raise click.UsageError(f"--dynamic-filter must be 'property:type', got: {value!r}")
    prop, typ = parts
    valid_types = {"string", "number", "date", "boolean"}
    if typ not in valid_types:
        raise click.UsageError(f"--dynamic-filter type must be one of {valid_types}, got: {typ!r}")
    return TypeConfig(id=prop, type=typ)  # type: ignore[arg-type]


def parse_dynamic_orderby(value: str) -> DSDynamicOrderByConfig:
    """Parse 'Property' or 'Owner.Name' → DSDynamicOrderByConfig."""
    return DSDynamicOrderByConfig(property=value.split("."))


def parse_linked(value: str) -> DSLinkedDatasourceConfig:
    """Parse linked datasource spec → DSLinkedDatasourceConfig.

    Format:
      oneToOne/oneToMany:    'name:type:target'            (3 parts only, no mergeByValue)
      oneToOneWithMerge:     'name:type:target:mergeBy'    (4 parts, mergeByValue required)
    """
    parts = value.split(":", 3)
    if len(parts) < 3:
        raise click.UsageError(f"--linked must be 'name:type:target[:mergeBy]', got: {value!r}")
    name, typ = parts[0], parts[1]
    valid_types = {"oneToOne", "oneToMany", "oneToOneWithMerge"}
    if typ not in valid_types:
        raise click.UsageError(f"--linked type must be one of {valid_types}, got: {typ!r}")
    raw_target = parts[2]
    if "/" in raw_target:
        module_id, target = raw_target.split("/", 1)
    else:
        module_id = None
        target = raw_target
    if typ == "oneToOneWithMerge":
        if len(parts) < 4 or not parts[3]:
            raise click.UsageError(
                "--linked oneToOneWithMerge requires a mergeBy expression: 'name:type:target:mergeBy'"
            )
        merge_by: str | None = parts[3]
    else:
        # oneToOne / oneToMany: mergeByValue must be null — reject 4-part format
        if len(parts) >= 4 and parts[3]:
            raise click.UsageError(
                f"--linked {typ} requires 3-part format: 'name:type:target'. "
                f"Got 4 parts with merge-by value '{parts[3]}'. "
                "For merge-by support, use oneToOneWithMerge."
            )
        merge_by = None
    return DSLinkedDatasourceConfig(
        name=name,
        type=typ,  # type: ignore[arg-type]
        datasourceConfig=DSLinkedDatasourceConfigRef(configId=target, moduleId=module_id),
        mergeByValue=merge_by,
    )


def parse_linked_param(value: str) -> tuple[str, str, str]:
    """Parse 'linked_name:param_id:expression' -> (linked_name, param_id, expression).

    Splits on first 2 colons only so expressions with colons are preserved.
    """
    parts = value.split(":", 2)
    if len(parts) != 3 or not parts[0] or not parts[1] or not parts[2]:
        raise click.UsageError(
            f"--linked-param must be 'linked_name:param_id:expression', got: {value!r}"
        )
    return parts[0], parts[1], parts[2]


def parse_custom_column(value: str) -> DSValueConfig:
    """Parse 'name:type:expression' → DSValueConfig (splits on first 2 colons)."""
    parts = value.split(":", 2)
    if len(parts) != 3:
        raise click.UsageError(f"--custom-column must be 'name:type:expression', got: {value!r}")
    name, typ, expression = parts
    valid_types = {"string", "number", "boolean", "date", "object"}
    if typ not in valid_types:
        raise click.UsageError(f"--custom-column type must be one of {valid_types}, got: {typ!r}")
    return DSValueConfig(name=name, type=typ, value=expression)  # type: ignore[arg-type]


def parse_linked_top(value: str) -> tuple[str, str]:
    """Parse 'name:value' → (linked_name, top_value) for --linked-top."""
    parts = value.split(":", 1)
    if len(parts) != 2 or not parts[0] or not parts[1]:
        raise click.UsageError(f"--linked-top must be 'name:value', got: {value!r}")
    return parts[0], parts[1]


def parse_linked_skip(value: str) -> tuple[str, str]:
    """Parse 'name:value' → (linked_name, skip_value) for --linked-skip."""
    parts = value.split(":", 1)
    if len(parts) != 2 or not parts[0] or not parts[1]:
        raise click.UsageError(f"--linked-skip must be 'name:value', got: {value!r}")
    return parts[0], parts[1]


def auto_populate_dynamic_filters(
    type_def: list[TypeConfig] | None,
) -> list[TypeConfig]:
    """Auto-populate dynamic filters from queryOptionsObjectTypeDef.

    Mirrors the UI's getQueryOptionsSelectedAsDynamicFilter: includes primitive
    non-collection properties and recurses into non-collection object properties.
    """
    if not type_def:
        return []
    result: list[TypeConfig] = []
    for prop in type_def:
        if prop.type in DYNAMIC_FILTER_TYPES and not prop.isCollection:
            result.append(TypeConfig(id=prop.id, type=prop.type))
        elif prop.type == "object" and prop.objectTypeDef and not prop.isCollection:
            nested = auto_populate_dynamic_filters(prop.objectTypeDef)
            if nested:
                result.append(TypeConfig(id=prop.id, type="object", objectTypeDef=nested))
    return result


def auto_populate_dynamic_orderbys(
    type_def: list[TypeConfig] | None,
    parent_property: list[str] | None = None,
) -> list[DSDynamicOrderByConfig]:
    """Auto-populate dynamic orderbys from queryOptionsObjectTypeDef.

    Mirrors the UI's getQueryOptionsSelectedAsDynamicOrderBy: includes primitive
    non-collection properties and recurses into non-collection object properties.
    """
    if not type_def:
        return []
    prefix = parent_property or []
    result: list[DSDynamicOrderByConfig] = []
    for prop in type_def:
        if prop.type in DYNAMIC_FILTER_TYPES and not prop.isCollection:
            result.append(DSDynamicOrderByConfig(property=[*prefix, prop.id]))
        elif prop.type == "object" and prop.objectTypeDef and not prop.isCollection:
            result.extend(auto_populate_dynamic_orderbys(prop.objectTypeDef, [*prefix, prop.id]))
    return result


def apply_param_filters(
    config: DatasourceConfig,
    param_filters: Sequence[tuple[str, str, str, str]],
) -> None:
    """Apply pre-parsed --param-filter specifications to a datasource config.

    Each element is a (property, operator, param_name, type) tuple as returned
    by ``parse_param_filter`` (or the ``cb_param_filter`` Click callback).

    Deduplicates inParams by name (--param-filter takes precedence over --detect-params).
    """
    for prop, op, param_name, typ in param_filters:
        filter_cfg, in_param = build_param_filter(prop, op, param_name, typ)
        if config.queryOptions is None:
            config.queryOptions = DSQueryOptionsConfig()
        if config.queryOptions.filters is None:
            config.queryOptions.filters = []
        config.queryOptions.filters.append(filter_cfg)
        if config.inParams is None:
            config.inParams = []
        config.inParams = [p for p in config.inParams if p.id != param_name]
        config.inParams.append(in_param)


def apply_enhancements(
    config: DatasourceConfig,
    *,
    dynamic_filters: Sequence[TypeConfig] = (),
    dynamic_orderbys: Sequence[DSDynamicOrderByConfig] = (),
    all_dynamic_filters: bool = False,
    all_dynamic_orderbys: bool = False,
    linked_datasources: Sequence[DSLinkedDatasourceConfig] = (),
    linked_tops: Sequence[tuple[str, str]] = (),
    linked_skips: Sequence[tuple[str, str]] = (),
    custom_columns: Sequence[DSValueConfig] = (),
    linked_flag_name: str = "--linked",
) -> None:
    """Apply pre-parsed enhancement flags to a datasource config.

    All sequence parameters accept pre-parsed objects (parsed at Click
    option-resolution time via callbacks).  Shared by
    ``dxs datasource generate``, ``generate-flow``, and the
    ``dxs report upload --owned`` pipeline.  The *linked_flag_name*
    parameter customises error-message flag references.
    """
    if dynamic_filters:
        config.dynamicFilters = list(dynamic_filters)

    if all_dynamic_filters:
        config.allSelectedIsDynamicFilters = True
        if not dynamic_filters:
            config.dynamicFilters = (
                auto_populate_dynamic_filters(config.queryOptionsObjectTypeDef) or None
            )
    elif dynamic_filters:
        config.allSelectedIsDynamicFilters = False

    if dynamic_orderbys:
        config.dynamicOrderBys = list(dynamic_orderbys)

    if all_dynamic_orderbys:
        config.allSelectedIsDynamicOrderBys = True
        if not dynamic_orderbys:
            config.dynamicOrderBys = (
                auto_populate_dynamic_orderbys(config.queryOptionsObjectTypeDef) or None
            )
    elif dynamic_orderbys:
        config.allSelectedIsDynamicOrderBys = False

    if linked_datasources:
        config.linkedDatasources = list(linked_datasources)

    if linked_tops:
        if not config.linkedDatasources:
            raise click.UsageError(
                f"{linked_flag_name}-top requires at least one {linked_flag_name} datasource"
            )
        linked_by_name = {ld.name: ld for ld in config.linkedDatasources}
        for name, top_value in linked_tops:
            if name not in linked_by_name:
                raise click.UsageError(
                    f"{linked_flag_name}-top: no linked datasource named '{name}'. "
                    f"Available: {list(linked_by_name)}"
                )
            linked_by_name[name].hasTop = True
            linked_by_name[name].top = top_value

    if linked_skips:
        if not config.linkedDatasources:
            raise click.UsageError(
                f"{linked_flag_name}-skip requires at least one {linked_flag_name} datasource"
            )
        linked_by_name = {ld.name: ld for ld in config.linkedDatasources}
        for name, skip_value in linked_skips:
            if name not in linked_by_name:
                raise click.UsageError(
                    f"{linked_flag_name}-skip: no linked datasource named '{name}'. "
                    f"Available: {list(linked_by_name)}"
                )
            linked_by_name[name].hasSkip = True
            linked_by_name[name].skip = skip_value

    if custom_columns:
        config.customColumns = list(custom_columns)


# ---------------------------------------------------------------------------
# Click option callbacks — parse format-based flags at option-resolution time
# ---------------------------------------------------------------------------


def cb_dynamic_filter(
    ctx: click.Context, param: click.Parameter, value: tuple[str, ...]
) -> tuple[TypeConfig, ...]:
    """Click callback: parse each ``--dynamic-filter`` value eagerly."""
    return tuple(parse_dynamic_filter(v) for v in value)


def cb_dynamic_orderby(
    ctx: click.Context, param: click.Parameter, value: tuple[str, ...]
) -> tuple[DSDynamicOrderByConfig, ...]:
    """Click callback: parse each ``--dynamic-orderby`` value eagerly."""
    return tuple(parse_dynamic_orderby(v) for v in value)


def cb_linked(
    ctx: click.Context, param: click.Parameter, value: tuple[str, ...]
) -> tuple[DSLinkedDatasourceConfig, ...]:
    """Click callback: parse each ``--linked`` value eagerly."""
    return tuple(parse_linked(v) for v in value)


def cb_custom_column(
    ctx: click.Context, param: click.Parameter, value: tuple[str, ...]
) -> tuple[DSValueConfig, ...]:
    """Click callback: parse each ``--custom-column`` value eagerly."""
    return tuple(parse_custom_column(v) for v in value)


def cb_param_filter(
    ctx: click.Context, param: click.Parameter, value: tuple[str, ...]
) -> tuple[tuple[str, str, str, str], ...]:
    """Click callback: parse each ``--param-filter`` value eagerly."""
    return tuple(parse_param_filter(v) for v in value)


def cb_linked_param(
    ctx: click.Context, param: click.Parameter, value: tuple[str, ...]
) -> tuple[tuple[str, str, str], ...]:
    """Click callback: parse each ``--linked-param`` value eagerly."""
    return tuple(parse_linked_param(v) for v in value)


def cb_linked_top(
    ctx: click.Context, param: click.Parameter, value: tuple[str, ...]
) -> tuple[tuple[str, str], ...]:
    """Click callback: parse each ``--linked-top`` value eagerly."""
    return tuple(parse_linked_top(v) for v in value)


def cb_linked_skip(
    ctx: click.Context, param: click.Parameter, value: tuple[str, ...]
) -> tuple[tuple[str, str], ...]:
    """Click callback: parse each ``--linked-skip`` value eagerly."""
    return tuple(parse_linked_skip(v) for v in value)
