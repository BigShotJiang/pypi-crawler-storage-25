"""Linked datasource parameter resolution.

Fetches target datasource configs from the API and populates
configParameters, configOutParameters, etc. on linked datasource refs.
"""

import json as _json
from collections.abc import Sequence

import click
from pydantic import ValidationError as PydanticValidationError

from dxs.core.api.client import ApiClient
from dxs.core.api.endpoints import ConfigurationEndpoints
from dxs.core.datasource.models import (
    DatasourceConfig,
    DSDynamicOrderByConfig,
    DSKeyConfig,
    DSLinkedDatasourceConfig,
    DSLinkedDatasourceConfigRef,
    DSReferenceParameterConfig,
    TypeConfig,
)
from dxs.utils.errors import ApiError, ValidationError


def _fetch_target_json(
    api_client: ApiClient,
    branch_id: int,
    ref: DSLinkedDatasourceConfigRef,
) -> dict:
    """Fetch and parse the target datasource's JSON config from the API."""
    if ref.moduleId:
        endpoint = ConfigurationEndpoints.get_by_module_reference(
            branch_id, "datasource", ref.moduleId, ref.configId
        )
    else:
        endpoint = ConfigurationEndpoints.get_by_reference(branch_id, "datasource", ref.configId)

    try:
        target_ds = api_client.get(endpoint)
    except ApiError as e:
        raise ValidationError(
            message=f"Cannot fetch linked target '{ref.configId}': {e}",
            suggestions=["Ensure the target datasource exists on the branch"],
        ) from e

    if not target_ds or not isinstance(target_ds, dict):
        raise ValidationError(
            message=f"Cannot fetch linked target '{ref.configId}': API returned empty response",
            suggestions=["Ensure the target datasource exists on the branch"],
        )

    target_json = target_ds.get("json")
    if isinstance(target_json, str):
        try:
            target_json = _json.loads(target_json)
        except _json.JSONDecodeError as e:
            raise ValidationError(
                message=f"Malformed JSON in target datasource '{ref.configId}': {e}",
                suggestions=["Check that the target datasource has a valid configuration"],
            ) from e
    if target_json is None:
        target_json = target_ds  # fallback: response IS the config

    return target_json


def resolve_linked_ds_metadata(
    api_client: ApiClient,
    branch_id: int,
    ref: DSLinkedDatasourceConfigRef,
) -> dict:
    """Fetch target DS and populate configOutParameters, datasourceKeyDef, etc.

    This resolves the target's metadata (outParams, keyDef, dynamicOrderBys,
    dynamicFilters) without requiring any parameter mappings.  It is safe to
    call multiple times — fields that are already populated are skipped.

    Returns:
        The parsed target datasource JSON dict (for reuse by callers that
        need additional fields like inParams).
    """
    target_json = _fetch_target_json(api_client, branch_id, ref)

    # Copy outParams -> configOutParameters
    if ref.configOutParameters is None:
        target_out = target_json.get("outParams")
        if target_out:
            try:
                ref.configOutParameters = [TypeConfig.model_validate(p) for p in target_out]
            except PydanticValidationError as e:
                raise ValidationError(
                    message=f"Malformed outParams on target '{ref.configId}': {e}",
                    suggestions=["Check the target datasource config for schema issues"],
                ) from e

    # Copy keyDef -> datasourceKeyDef (if not already set)
    if ref.datasourceKeyDef is None:
        # Try top-level keyDef first; single-entity datasources (--param-keys
        # --output-single) don't set a top-level keyDef, so fall back to the
        # entity set path's keyDef.
        key_def_raw = target_json.get("keyDef")
        if not key_def_raw:
            for path in target_json.get("paths") or []:
                if (
                    isinstance(path, dict)
                    and path.get("type") == "entitySet"
                    and path.get("keyDef")
                ):
                    key_def_raw = path["keyDef"]
                    break
        if key_def_raw:
            try:
                ref.datasourceKeyDef = [DSKeyConfig.model_validate(k) for k in key_def_raw]
            except PydanticValidationError as e:
                raise ValidationError(
                    message=f"Malformed keyDef on target '{ref.configId}': {e}",
                    suggestions=["Check the target datasource config for schema issues"],
                ) from e

    # Copy dynamicOrderBys/dynamicFilters if not set
    if ref.dynamicOrderBys is None and target_json.get("dynamicOrderBys"):
        ref.dynamicOrderBys = [
            DSDynamicOrderByConfig.model_validate(d) for d in target_json["dynamicOrderBys"]
        ]
    if ref.dynamicFilters is None and target_json.get("dynamicFilters"):
        ref.dynamicFilters = [TypeConfig.model_validate(d) for d in target_json["dynamicFilters"]]

    # These are always null for CLI-generated linked DS refs (no events/flow config)
    ref.configEvents = None
    ref.outParamsChangeFlowConfig = None

    return target_json


def resolve_linked_ds_params(
    api_client: ApiClient,
    branch_id: int,
    ref: DSLinkedDatasourceConfigRef,
    param_mappings: list[tuple[str, str]],
    linked_type: str = "oneToOne",
) -> None:
    """Fetch target DS and populate configParameters/configOutParameters on ref."""
    # Resolve metadata first (outParams, keyDef, dynamicOrderBys, dynamicFilters)
    # and reuse the fetched JSON to avoid a second HTTP request
    target_json = resolve_linked_ds_metadata(api_client, branch_id, ref)

    # Build configParameters from mappings + target inParams
    target_in = target_json.get("inParams") or []
    in_param_by_id: dict[str, dict] = {
        p["id"]: p for p in target_in if isinstance(p, dict) and "id" in p
    }

    config_params: list[DSReferenceParameterConfig] = []
    for param_id, expr in param_mappings:
        if param_id not in in_param_by_id:
            raise ValidationError(
                message=(
                    f"Param '{param_id}' not found on target '{ref.configId}'. "
                    f"Available: {list(in_param_by_id)}"
                ),
                suggestions=["Check param names with: dxs report datasource-fields <ref>"],
            )
        # For oneToOneWithMerge, configParameters values must be null.
        # The codegen renders configParameters inside $flowParams OUTSIDE the
        # per-entity loop, so $entity.* expressions are out of scope.  The UI
        # designer behaves identically — it always sets value to null and
        # relies on mergeByValue + $keys for the matching logic.
        param_value = None if linked_type == "oneToOneWithMerge" else expr
        config_params.append(
            DSReferenceParameterConfig(
                parameter=TypeConfig.model_validate(in_param_by_id[param_id]),
                value=param_value,
            )
        )

    # Validate required params have mappings (skip for oneToOneWithMerge —
    # its configParameters are intentionally null-valued; the getByKeys flow
    # receives $keys collected from mergeByValue, not per-entity params).
    if linked_type != "oneToOneWithMerge":
        mapped_ids = {pm[0] for pm in param_mappings}
        for p in target_in:
            if isinstance(p, dict) and p.get("required") and p.get("id") not in mapped_ids:
                raise ValidationError(
                    message=(
                        f"Required param '{p.get('id')}' on target '{ref.configId}' has no mapping"
                    ),
                    suggestions=[
                        f"Add --linked-param with param '{p.get('id')}'",
                    ],
                )

    ref.configParameters = config_params


def apply_linked_params(
    config: DatasourceConfig,
    linked_params: Sequence[tuple[str, str, str]],
    api_client: ApiClient,
    branch_id: int,
    flag_name: str = "--linked-param",
) -> None:
    """Group and resolve pre-parsed --linked-param mappings.

    Each element is a (linked_name, param_id, expression) tuple as
    returned by ``parse_linked_param`` (or the ``cb_linked_param``
    Click callback).

    Shared helper used by both `dxs datasource upsert` and
    `dxs report upload --owned-linked-param`.

    Raises click.UsageError for user-facing flag validation (missing linked DS,
    unknown name). ValidationError from resolve_linked_ds_params (API/data
    issues) is re-raised as click.UsageError at this CLI boundary.
    """
    if not linked_params:
        return

    if not config.linkedDatasources:
        raise click.UsageError(f"{flag_name} requires at least one linked datasource")

    linked_by_name: dict[str, DSLinkedDatasourceConfig] = {
        ld.name: ld for ld in config.linkedDatasources
    }

    # Group params by linked name
    lp_by_name: dict[str, list[tuple[str, str]]] = {}
    for ln_name, param_id, expr in linked_params:
        if ln_name not in linked_by_name:
            raise click.UsageError(
                f"{flag_name}: no linked datasource named '{ln_name}'. "
                f"Available: {list(linked_by_name)}"
            )
        lp_by_name.setdefault(ln_name, []).append((param_id, expr))

    # For each linked DS with params, fetch the target and resolve
    for ln_name, param_mappings in lp_by_name.items():
        ld = linked_by_name[ln_name]
        try:
            resolve_linked_ds_params(
                api_client, branch_id, ld.datasourceConfig, param_mappings, ld.type
            )
        except ValidationError as e:
            raise click.UsageError(str(e)) from e
