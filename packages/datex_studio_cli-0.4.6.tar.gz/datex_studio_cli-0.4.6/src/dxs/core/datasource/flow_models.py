"""Pydantic models for flow-based datasource configuration.

The embedded flow structure within datasource configs (getFlow, getListFlow, etc.).
Flow node primitives live in core/designer/flow_models.py.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field, field_validator

from dxs.core.designer.flow_models import (  # noqa: F401
    FlowExecuteCodeConfig,
    FlowNodeDesignerConfig,
    FlowStepDesignerConfig,
)
from dxs.core.designer.models import TypeConfig


class FlowDesignerConfig(BaseModel):
    """Complete flow method configuration.

    Represents one of: getFlow, getListFlow, getByKeysFlow, onInitFlow.
    The CLI always produces single-node flows (multi-node is legacy).
    """

    referenceName: str | None = None
    inParams: list[TypeConfig] | None = None
    outParams: list[TypeConfig] | None = None
    nodes: list[FlowNodeDesignerConfig] = Field(min_length=1)
    start: str
    enableProgressAndCancelation: bool = False

    @field_validator("start")
    @classmethod
    def start_must_reference_node(cls, v: str, info: Any) -> str:
        """Ensure start references a valid node ID."""
        nodes = (info.data or {}).get("nodes", [])
        node_ids = {n.id for n in nodes}
        if node_ids and v not in node_ids:
            raise ValueError(f"start '{v}' does not reference any node id in nodes")
        return v
