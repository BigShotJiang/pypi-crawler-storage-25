"""Generator for flow-based datasource configurations.

Accepts code strings and parsed type definitions, builds a complete
DatasourceConfig with type="flows". No file I/O — the command layer
handles reading files.
"""

from __future__ import annotations

from typing import cast

from dxs.core.datasource.flow_models import FlowDesignerConfig
from dxs.core.datasource.models import DatasourceConfig, DSKeyConfig
from dxs.core.designer.flow_models import (
    FlowExecuteCodeConfig,
    FlowNodeDesignerConfig,
    FlowStepDesignerConfig,
)
from dxs.core.designer.models import JSType, TypeConfig
from dxs.core.designer.parsers import VALID_TYPES


def _build_flow_config(code: str, reference_name: str) -> FlowDesignerConfig:
    """Build a single-node FlowDesignerConfig from code string."""
    return FlowDesignerConfig(
        referenceName=reference_name,
        start="step1",
        nodes=[
            FlowNodeDesignerConfig(
                id="step1",
                type="step",
                stepConfig=FlowStepDesignerConfig(
                    type="ExecuteCodeActivity",
                    executeCodeConfig=FlowExecuteCodeConfig(code=code),
                ),
            )
        ],
    )


class FlowDatasourceGenerator:
    """Generate DatasourceConfig for flow-based datasources."""

    def generate(
        self,
        *,
        reference_name: str,
        title: str,
        type_def: list[TypeConfig],
        get_flow_code: str | None = None,
        get_list_flow_code: str | None = None,
        get_by_keys_flow_code: str | None = None,
        on_init_flow_code: str | None = None,
        in_params: list[tuple[str, str, bool, bool]] | None = None,
        key_defs: list[tuple[str, str]] | None = None,
        result_is_collection: bool | None = None,
        description: str | None = None,
        access_modifier: str = "public",
    ) -> DatasourceConfig:
        """Generate a DatasourceConfig with type="flows".

        Args:
            reference_name: Datasource reference name (valid JS identifier).
            title: Display title.
            type_def: Output type definition (list of TypeConfig).
            get_flow_code: JavaScript code for the getFlow method.
            get_list_flow_code: JavaScript code for the getListFlow method.
            get_by_keys_flow_code: JavaScript code for the getByKeysFlow method.
            on_init_flow_code: JavaScript code for the onInitFlow method.
            in_params: Input parameters as (name, type, required, is_collection) tuples.
            key_defs: Key definitions as (name, type) tuples.
            result_is_collection: Explicit collection override. None = auto-detect.
            description: Datasource description.
            access_modifier: Access modifier (public/private).

        Returns:
            Complete DatasourceConfig ready for serialization.

        Raises:
            ValueError: If validation fails (no flows, missing keys, incompatible flags).
        """
        # Validate: at least one data flow method
        if not any((get_flow_code, get_list_flow_code, get_by_keys_flow_code)):
            raise ValueError(
                "At least one flow method is required "
                "(--get-flow, --get-list-flow, or --get-by-keys-flow)"
            )

        # Validate: getByKeys requires key definition
        if get_by_keys_flow_code and not key_defs:
            raise ValueError("getByKeysFlow requires at least one --key definition")

        # Validate: --single is incompatible with getList/getByKeys
        if result_is_collection is False and (get_list_flow_code or get_by_keys_flow_code):
            raise ValueError(
                "--single is not compatible with --get-list-flow or --get-by-keys-flow"
            )

        # Build flow configs
        get_flow = _build_flow_config(get_flow_code, "get") if get_flow_code else None
        get_list_flow = (
            _build_flow_config(get_list_flow_code, "getList") if get_list_flow_code else None
        )
        get_by_keys_flow = (
            _build_flow_config(get_by_keys_flow_code, "getByKeys")
            if get_by_keys_flow_code
            else None
        )
        on_init_flow = (
            _build_flow_config(on_init_flow_code, "onInit") if on_init_flow_code else None
        )

        # Determine resultIsCollection
        if result_is_collection is not None:
            is_collection = result_is_collection
        elif get_list_flow_code or get_by_keys_flow_code:
            is_collection = True
        else:
            is_collection = False

        # Build inParams
        in_param_configs = None
        if in_params:
            in_param_configs = []
            for name, typ, req, is_coll in in_params:
                if typ not in VALID_TYPES:
                    raise ValueError(
                        f"Invalid in-param type '{typ}' for '{name}'. "
                        f"Must be one of: {sorted(VALID_TYPES)}"
                    )
                in_param_configs.append(
                    TypeConfig(
                        id=name,
                        type=cast(JSType, typ),
                        required=req,
                        isCollection=True if is_coll else None,
                    )
                )

        # Build keyDef
        key_def_configs = None
        has_key = None
        if key_defs:
            key_def_configs = []
            for name, typ in key_defs:
                if typ not in VALID_TYPES:
                    raise ValueError(
                        f"Invalid key type '{typ}' for '{name}'. "
                        f"Must be one of: {sorted(VALID_TYPES)}"
                    )
                key_def_configs.append(DSKeyConfig(id=name, type=cast(JSType, typ)))
            has_key = True

        # Build outParams (wraps type_def in standard envelope)
        out_params = [
            TypeConfig(
                id="result",
                type="object",
                isCollection=is_collection,
                objectTypeDef=type_def,
            )
        ]

        return DatasourceConfig(
            type="flows",
            referenceName=reference_name,
            title=title,
            apiSettingName=None,
            description=description,
            isCollection=is_collection,
            queryOptionsObjectTypeDef=type_def,
            outParams=out_params,
            inParams=in_param_configs,
            resultIsCollection=is_collection,
            keyDef=key_def_configs,
            hasKey=has_key,
            getFlow=get_flow,
            getListFlow=get_list_flow,
            getByKeysFlow=get_by_keys_flow,
            onInitFlow=on_init_flow,
            accessModifier=access_modifier,
        )
