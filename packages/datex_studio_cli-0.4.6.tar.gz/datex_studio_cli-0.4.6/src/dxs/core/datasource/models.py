"""Pydantic models for Datex datasource JSON configuration structure.

Based on the OData datasource schema defined in:
- TypeScript: datasource-designer-config.ts
- C#: DatasourceDesignerConfig.cs
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Literal

from pydantic import BaseModel, ConfigDict

from dxs.core.designer.models import JS_TYPES, JSType, TypeConfig  # noqa: F401

if TYPE_CHECKING:
    from dxs.core.datasource.flow_models import FlowDesignerConfig


class DSKeyConfig(BaseModel):
    """Key definition for entity or apply result."""

    id: str
    type: JSType
    isSecured: bool | None = None


class DSPathEntitySetConfig(BaseModel):
    """Entity set path segment."""

    type: Literal["entitySet"] = "entitySet"
    entitySet: str
    keyDef: list[DSKeyConfig]


class DSKeySegmentKey(BaseModel):
    """Key value in key segment."""

    name: str
    isCollection: bool | None = None
    type: JSType
    value: str  # Can be expression like "$datasource.inParams.orderId"


class DSPathKeyConfig(BaseModel):
    """Key path segment (single entity by key)."""

    type: Literal["key"] = "key"
    keys: list[DSKeySegmentKey]


class DSPathNavigationPropertyConfig(BaseModel):
    """Navigation property path segment."""

    type: Literal["navigationProperty"] = "navigationProperty"
    property: str
    keyDef: list[DSKeyConfig]


DSPathSegmentConfig = DSPathEntitySetConfig | DSPathKeyConfig | DSPathNavigationPropertyConfig


class DSExpressionConfig(BaseModel):
    """Expression configuration."""

    type: Literal["statement"] = "statement"
    isCollection: bool | None = None
    value: str  # OData filter expression or template literal


class DSFilterConfig(BaseModel):
    """Filter configuration."""

    hasCondition: bool | None = None
    condition: str | None = None  # Boolean expression like "$utils.isDefined(...)"
    expression: DSExpressionConfig


class DSOrderByConfig(BaseModel):
    """OrderBy configuration."""

    property: list[str]  # Property path, e.g., ["OrderDate"] or ["Owner", "Name"]
    order: Literal["asc", "desc"] = "asc"


class DSExpandConfig(BaseModel):
    """Expand configuration."""

    property: str
    isCollection: bool | None = None  # Collection indicator (UI infers from metadata)
    queryOptions: DSQueryOptionsConfig | None = None  # Always present for UI compatibility


class DSAggregateConfig(BaseModel):
    """Aggregate configuration within apply transformations."""

    # method is None for $count aggregates (no "with <method>" part in OData syntax)
    method: Literal["sum", "min", "max", "average", "countdistinct"] | None = None
    alias: str
    property: list[str]


class DSApplyGroupByConfig(BaseModel):
    """GroupBy configuration for apply transformations."""

    propertyPaths: list[list[str]]
    aggregate: list[DSAggregateConfig] | None = None


class DSApplyConfig(BaseModel):
    """Apply transformation configuration."""

    transformation: Literal["filter", "groupby", "aggregate"]
    filterConfig: list[DSFilterConfig] | None = None
    groupByConfig: DSApplyGroupByConfig | None = None
    aggregateConfig: list[DSAggregateConfig] | None = None


# ---------------------------------------------------------------------------
# Parsed $apply clause models (intermediate parser output, not serialized to JSON)
# ---------------------------------------------------------------------------


class ParsedAggregate(BaseModel):
    """A single parsed aggregate clause from OData $apply."""

    property: list[str]
    method: str | None = None
    alias: str


class ParsedFilterClause(BaseModel):
    """Parsed filter(...) transformation."""

    transformation: Literal["filter"] = "filter"
    filterExpression: str


class ParsedAggregateClause(BaseModel):
    """Parsed standalone aggregate(...) transformation."""

    transformation: Literal["aggregate"] = "aggregate"
    aggregates: list[ParsedAggregate]


class ParsedGroupByClause(BaseModel):
    """Parsed groupby(...) transformation."""

    transformation: Literal["groupby"] = "groupby"
    propertyPaths: list[list[str]]
    aggregates: list[ParsedAggregate]


ParsedApplyClause = ParsedFilterClause | ParsedAggregateClause | ParsedGroupByClause


class DSQueryOptionsConfig(BaseModel):
    """Query options configuration ($select, $filter, $orderby, etc.)."""

    selects: list[str] | None = None
    filters: list[DSFilterConfig] | None = None
    orderBys: list[DSOrderByConfig] | None = None
    expands: list[DSExpandConfig] | None = None
    apply: list[DSApplyConfig] | None = None
    applyKeyDef: list[DSKeyConfig] | None = None
    hasTop: bool | None = None
    top: str | None = None  # String expression like "10" or "$datasource.inParams.pageSize"
    hasSkip: bool | None = None
    skip: str | None = None
    count: bool | None = None


# Fix forward reference
DSExpandConfig.model_rebuild()


class DSReferenceParameterConfig(BaseModel):
    """Parameter mapping for linked datasource reference."""

    parameter: TypeConfig
    value: str | None = (
        None  # null for oneToOneWithMerge (codegen uses $keys, not per-entity params)
    )
    parsedValue: Any | None = None


class DSDynamicOrderByConfig(BaseModel):
    """Dynamic orderby configuration."""

    property: list[str]


class DSLinkedDatasourceConfigRef(BaseModel):
    """Reference to linked datasource.

    configId is the reference name string used by the codegen to build the
    datasource service path (e.g. 'ds_accounts' → this.$datasources.app.ds_accounts).
    moduleId is null for the default app module.
    """

    configId: str  # reference name of the target datasource (used by codegen as the path segment)
    moduleId: str | None = None
    isOwned: bool | None = None
    datasourceKeyDef: list[DSKeyConfig] | None = None
    dynamicOrderBys: list[DSDynamicOrderByConfig] | None = None
    dynamicFilters: list[TypeConfig] | None = None
    configParameters: list[DSReferenceParameterConfig] | None = None
    configOutParameters: list[TypeConfig] | None = None
    configEvents: list[Any] | None = None
    outParamsChangeFlowConfig: Any | None = None


class DSLinkedDatasourceConfig(BaseModel):
    """Linked datasource configuration."""

    name: str
    type: Literal["oneToOne", "oneToMany", "oneToOneWithMerge"]
    datasourceConfig: DSLinkedDatasourceConfigRef
    mergeByValue: str | None = (
        None  # Required only for oneToOneWithMerge; null for oneToOne/oneToMany
    )
    hasTop: bool | None = None
    top: str | None = None
    hasSkip: bool | None = None
    skip: str | None = None
    fromBaseConfiguration: bool | None = None


class DSValueConfig(BaseModel):
    """Custom column (computed value) configuration.

    Matches the backend's DSValueConfig model. The `type` field is nullable to
    align with the backend's JSType? (nullable) schema.
    """

    name: str
    type: JSType | None = None
    isCollection: bool | None = None
    value: str  # JavaScript expression


class DatasourceConfig(BaseModel):
    """Complete datasource configuration."""

    model_config = ConfigDict(populate_by_name=True)

    configurationTypeId: Literal[6] = 6
    type: Literal["oDataQuery", "flows"] = "oDataQuery"
    fromBaseConfiguration: bool | None = None  # Inherited from base config
    referenceName: str
    title: str
    apiSettingName: str | None = None
    description: str | None = None

    # Path configuration
    paths: list[DSPathSegmentConfig] | None = None
    isCollection: bool = True

    # Query options
    queryOptions: DSQueryOptionsConfig | None = None
    queryOptionsObjectTypeDef: list[TypeConfig] | None = None  # Type definition for query results

    # Input/output parameters
    inParams: list[TypeConfig] | None = None
    outParams: list[TypeConfig] | None = None  # Output parameter definitions

    # Dynamic runtime parameters
    allSelectedIsDynamicFilters: bool | None = None
    dynamicFilters: list[TypeConfig] | None = None
    allSelectedIsDynamicOrderBys: bool | None = None
    dynamicOrderBys: list[DSDynamicOrderByConfig] | None = None

    # Advanced features
    linkedDatasources: list[DSLinkedDatasourceConfig] | None = None
    customColumns: list[DSValueConfig] | None = None

    # Collection configuration
    outputResultAsSingleObject: bool | None = None
    resultIsCollection: bool | None = None  # Result collection indicator
    keyDef: list[DSKeyConfig] | None = None  # Entity key definition
    hasKey: bool | None = None  # Has key indicator
    # NOTE: hasResult is computed server-side from outParams — do NOT add it here.

    # Flow method configurations (type="flows" only)
    getFlow: FlowDesignerConfig | None = None
    getListFlow: FlowDesignerConfig | None = None
    getByKeysFlow: FlowDesignerConfig | None = None
    onInitFlow: FlowDesignerConfig | None = None

    # Method configurations and events (not commonly used in programmatic generation)
    vars: list[Any] | None = None
    events: list[Any] | None = None
    accessModifier: str = "public"  # Access modifier (public, private, protected)


# Runtime import to resolve forward reference for FlowDesignerConfig
from dxs.core.datasource.flow_models import (  # noqa: E402
    FlowDesignerConfig as FlowDesignerConfig,  # noqa: F811
)

DatasourceConfig.model_rebuild()
