"""Type definition parser — moved to core/designer/parsers.py.

This module re-exports for backward compatibility during migration.
"""

from dxs.core.designer.parsers import (  # noqa: F401
    VALID_TYPES,
    parse_type_def,
)
