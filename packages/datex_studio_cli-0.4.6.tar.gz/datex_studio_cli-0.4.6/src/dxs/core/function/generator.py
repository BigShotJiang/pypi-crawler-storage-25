"""Generator for standalone function configurations.

Accepts a code string and parsed parameters, builds a complete
FunctionConfig (configurationTypeId=9). No file I/O — the command
layer handles reading files.
"""

from __future__ import annotations

from typing import Literal, cast

from dxs.core.designer.flow_models import (
    FlowExecuteCodeConfig,
    FlowNodeDesignerConfig,
    FlowStepDesignerConfig,
)
from dxs.core.designer.models import JS_TYPES, JSType, TypeConfig
from dxs.core.function.models import FunctionConfig
from dxs.utils.errors import ValidationError


def generate(
    *,
    reference_name: str,
    title: str,
    code: str,
    description: str | None = None,
    in_params: list[tuple[str, str, bool, bool]] | None = None,
    out_params: list[tuple[str, str, bool]] | None = None,
    access_modifier: Literal["public", "private"] = "public",
    enable_progress: bool = False,
) -> FunctionConfig:
    """Generate a FunctionConfig from code and parameter specs.

    Args:
        reference_name: Function reference name (valid JS identifier).
        title: Display title.
        code: JavaScript function body code.
        description: Function description.
        in_params: Input parameters as (name, type, required, is_collection) tuples.
        out_params: Output parameters as (name, type, is_collection) tuples.
        access_modifier: Access modifier (public/private).
        enable_progress: Enable progress and cancellation support.

    Returns:
        Complete FunctionConfig ready for serialization.

    Raises:
        ValidationError: If code is empty or parameter types are invalid.
    """
    if not code or not code.strip():
        raise ValidationError(
            message="Function code body cannot be empty",
            code="DXS-FN-005",
            suggestions=["Write non-empty TypeScript code in the code file"],
        )

    # Build single-node flow
    node = FlowNodeDesignerConfig(
        id="step1",
        type="step",
        stepConfig=FlowStepDesignerConfig(
            type="ExecuteCodeActivity",
            executeCodeConfig=FlowExecuteCodeConfig(code=code),
        ),
    )

    # Build inParams
    in_param_configs = (
        _build_typed_params(in_params, "in-param", "DXS-FN-004") if in_params else None
    )

    # Build outParams
    out_param_configs = (
        _build_simple_params(out_params, "out-param", "DXS-FN-004") if out_params else None
    )

    return FunctionConfig(
        referenceName=reference_name,
        title=title,
        description=description,
        accessModifier=access_modifier,
        inParams=in_param_configs,
        outParams=out_param_configs,
        nodes=[node],
        start="step1",
        enableProgressAndCancelation=enable_progress,
    )


def _build_typed_params(
    params: list[tuple[str, str, bool, bool]],
    flag_name: str,
    error_code: str,
) -> list[TypeConfig]:
    """Build TypeConfig list from (name, type, required, is_collection) tuples."""
    result = []
    for name, typ, req, is_coll in params:
        if typ not in JS_TYPES:
            raise ValidationError(
                message=(
                    f"Invalid {flag_name} type '{typ}' for '{name}'. "
                    f"Must be one of: {sorted(JS_TYPES)}"
                ),
                code=error_code,
                suggestions=[f"Valid types are: {', '.join(sorted(JS_TYPES))}"],
            )
        result.append(
            TypeConfig(
                id=name,
                type=cast(JSType, typ),
                required=req,
                isCollection=True if is_coll else None,
            )
        )
    return result


def _build_simple_params(
    params: list[tuple[str, str, bool]],
    flag_name: str,
    error_code: str,
) -> list[TypeConfig]:
    """Build TypeConfig list from (name, type, is_collection) tuples."""
    result = []
    for name, typ, is_coll in params:
        if typ not in JS_TYPES:
            raise ValidationError(
                message=(
                    f"Invalid {flag_name} type '{typ}' for '{name}'. "
                    f"Must be one of: {sorted(JS_TYPES)}"
                ),
                code=error_code,
                suggestions=[f"Valid types are: {', '.join(sorted(JS_TYPES))}"],
            )
        result.append(
            TypeConfig(
                id=name,
                type=cast(JSType, typ),
                isCollection=True if is_coll else None,
            )
        )
    return result
