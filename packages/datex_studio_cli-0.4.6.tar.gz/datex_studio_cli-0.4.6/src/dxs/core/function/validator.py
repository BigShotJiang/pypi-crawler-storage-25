"""Function configuration validator.

Validates function JSON configurations against schema and business rules.
"""

from __future__ import annotations

from typing import Any, NamedTuple

from pydantic import ValidationError as PydanticValidationError

from dxs.core.designer.parsers import JS_RESERVED_WORDS, is_valid_js_identifier
from dxs.core.function.models import FunctionConfig
from dxs.utils.errors import ValidationError


class ValidationResult(NamedTuple):
    """Result of function configuration validation."""

    valid: bool
    errors: list[str]
    config: FunctionConfig | None


def validate(config_dict: dict[str, Any]) -> ValidationResult:
    """Validate function configuration.

    Args:
        config_dict: Function configuration as dictionary.

    Returns:
        ValidationResult with (valid, errors, parsed_config_or_None).
    """
    errors: list[str] = []

    # 1. Validate against Pydantic schema
    try:
        config = FunctionConfig(**config_dict)
    except PydanticValidationError as e:
        for error in e.errors():
            loc = ".".join(str(x) for x in error["loc"])
            errors.append(f"{loc}: {error['msg']}")
        return ValidationResult(False, errors, None)

    # 2. Business rule validations
    errors.extend(_validate_business_rules(config))

    return ValidationResult(len(errors) == 0, errors, config)


def _validate_business_rules(config: FunctionConfig) -> list[str]:
    """Validate business rules beyond schema validation."""
    errors: list[str] = []

    # Rule: referenceName must be a valid JavaScript identifier
    if config.referenceName:
        if not is_valid_js_identifier(config.referenceName):
            if config.referenceName.lower() in JS_RESERVED_WORDS:
                errors.append(
                    f"referenceName '{config.referenceName}' is a JavaScript reserved word"
                )
            else:
                errors.append(
                    f"referenceName '{config.referenceName}' is not a valid JavaScript identifier "
                    "(must start with letter, _, or $ and contain only letters, digits, _, or $)"
                )

    # Rule: code body must not be empty
    if config.nodes:
        code = config.nodes[0].stepConfig.executeCodeConfig.code
        if not code or not code.strip():
            errors.append("Function code body cannot be empty")

    return errors


def validate_and_raise(config_dict: dict[str, Any]) -> FunctionConfig:
    """Validate and return configuration, or raise ValidationError.

    Args:
        config_dict: Function configuration as dictionary.

    Returns:
        Validated FunctionConfig instance.

    Raises:
        ValidationError: If validation fails.
    """
    result = validate(config_dict)

    if not result.valid or result.config is None:
        raise ValidationError(
            message="Function configuration validation failed",
            code="DXS-FN-VALIDATE-001",
            suggestions=result.errors,
        )

    return result.config
