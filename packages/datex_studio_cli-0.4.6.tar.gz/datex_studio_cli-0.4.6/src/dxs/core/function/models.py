"""Pydantic model for standalone function configuration.

A function (configurationTypeId=9) is a single-step flow that executes
backend business logic. Accessible via $flows.pkg_name.fn_name() from
other components.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field, model_validator

from dxs.core.designer.flow_models import FlowNodeDesignerConfig
from dxs.core.designer.models import TypeConfig


class FunctionConfig(BaseModel):
    """Standalone function configuration (configurationTypeId=9)."""

    configurationTypeId: Literal[9] = 9
    referenceName: str
    title: str
    description: str | None = None
    accessModifier: Literal["public", "private"] = "public"

    # Parameters
    inParams: list[TypeConfig] | None = None
    outParams: list[TypeConfig] | None = None

    # Flow structure — platform constraint: functions are always single-node.
    # max_length=1 is intentional; multi-step flows use a different config type.
    nodes: list[FlowNodeDesignerConfig] = Field(min_length=1, max_length=1)
    start: str = "step1"

    # Options
    enableProgressAndCancelation: bool = False

    @model_validator(mode="after")
    def start_must_reference_node(self) -> FunctionConfig:
        """Ensure start references a valid node ID."""
        node_ids = {n.id for n in self.nodes}
        if self.start not in node_ids:
            raise ValueError(f"start '{self.start}' does not reference any node id in nodes")
        return self
