"""YAML output formatter."""

from typing import Any

import yaml


class LiteralString(str):
    """String that should be rendered as a literal block in YAML.

    Automatically strips trailing whitespace from each line, which is required
    for PyYAML to use literal block style (|) instead of falling back to quoted strings.
    """

    def __new__(cls, value: str) -> "LiteralString":
        # Strip trailing whitespace from each line - required for YAML literal blocks
        # PyYAML falls back to quoted strings if any line has trailing whitespace
        lines = [line.rstrip() for line in value.split("\n")]
        cleaned = "\n".join(lines).strip()
        return super().__new__(cls, cleaned)


def literal_str_representer(dumper: yaml.Dumper, data: LiteralString) -> yaml.Node:
    """Custom representer for literal strings."""
    return dumper.represent_scalar("tag:yaml.org,2002:str", data, style="|")


# Register the custom representer
yaml.add_representer(LiteralString, literal_str_representer)


def convert_multiline_to_literal(data: Any) -> Any:
    """Recursively convert multiline string values to LiteralString for YAML block style.

    Any string value containing newlines is rendered as a YAML literal block (|)
    for readability. Single-line strings are left as plain scalars.
    Also normalizes line endings from \\r\\n to \\n.

    Args:
        data: Data structure to process (dict, list, or scalar).

    Returns:
        Same structure with multiline strings converted to LiteralString.
    """
    if isinstance(data, dict):
        result: dict[str, Any] = {}
        for key, value in data.items():
            if isinstance(value, str):
                cleaned = value.replace("\r\n", "\n").replace("\r", "\n")
                if "\n" in cleaned:
                    result[key] = LiteralString(cleaned)
                else:
                    result[key] = cleaned
            else:
                result[key] = convert_multiline_to_literal(value)
        return result
    elif isinstance(data, list):
        return [convert_multiline_to_literal(item) for item in data]
    else:
        return data


def format_yaml(data: Any, default_flow_style: bool = False) -> str:
    """Format data as YAML.

    Args:
        data: Data to format.
        default_flow_style: Use flow style for collections (compact).

    Returns:
        YAML-formatted string.
    """
    # Convert multiline strings to literal blocks for readability
    data = convert_multiline_to_literal(data)

    return yaml.dump(
        data,
        default_flow_style=default_flow_style,
        sort_keys=False,
        allow_unicode=True,
        width=120,
    )
