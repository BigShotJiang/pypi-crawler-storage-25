"""Output redaction and concise-mode stripping.

Canonical home for data-transform functions that filter output.
These are pure functions with no CLI or Click dependencies.
"""

from typing import Any

# Fields to strip from author objects in concise mode
AUTHOR_VERBOSE_FIELDS = {"id", "organizationId", "externalId", "hasManagementAccess"}

# Keys to strip from ALL output: secrets and server internals.
# Matched case-insensitively.
_REDACT_KEYS_LOWER = {
    "applicationdefinition",
    "stacktrace",
    "innererror",
}

# Parent keys where "application" is an envelope field (not user data)
_APPLICATION_ENVELOPE_PARENTS: frozenset[str | None] = frozenset(
    {None, "data", "item", "datasource", "report", "branch", "commit"}
)


def _redact_secrets(data: Any) -> Any:
    """Strip secret-containing fields and server internals from data.

    Runs ALWAYS (concise and full) to prevent credential leaks and noise.
    Matching is case-insensitive for .NET API PascalCase compatibility.
    """
    if isinstance(data, dict):
        return {
            key: _redact_secrets(value)
            for key, value in data.items()
            if key.lower() not in _REDACT_KEYS_LOWER
        }
    elif isinstance(data, list):
        return [_redact_secrets(item) for item in data]
    else:
        return data


def _strip_concise(data: Any, parent_key: str | None = None) -> Any:
    """Strip null values and verbose metadata from data for concise output.

    Args:
        data: Data to strip (dict, list, or other).
        parent_key: The key of the parent that contains this data.

    Returns:
        Data with nulls and verbose fields removed.
    """
    if isinstance(data, dict):
        result = {}
        for key, value in data.items():
            if value is None:
                continue
            if parent_key == "author" and key in AUTHOR_VERBOSE_FIELDS:
                continue
            if key == "jsonString":
                continue
            if key == "application" and parent_key in _APPLICATION_ENVELOPE_PARENTS:
                continue
            result[key] = _strip_concise(value, parent_key=key)
        return result
    elif isinstance(data, list):
        return [_strip_concise(item, parent_key=parent_key) for item in data]
    else:
        return data


_FORMATTED_VALUE_ANNOTATION = "@OData.Community.Display.V1.FormattedValue"


def _flatten_formatted_values(data: Any) -> Any:
    """Collapse Dynamics @OData FormattedValue siblings into clean keys.

    A Dataverse record like::

        {
            "_primarycontactid_value": "abc-123",
            "_primarycontactid_value@OData.Community.Display.V1.FormattedValue": "Jane Doe",
            "_primarycontactid_value@Microsoft.Dynamics.CRM.lookuplogicalname": "contact",
        }

    becomes::

        {
            "primarycontactid": "Jane Doe",
            "primarycontactid_id": "abc-123",
        }

    Behavior:
    - Annotation siblings (anything with "@" in the key) are dropped.
    - Keys with FormattedValue annotations get replaced by the display value.
    - For lookup-style keys (``_foo_value``), the GUID is preserved as ``foo_id``.
    - If a clean key would collide with an existing non-annotation key, the
      original key is kept and the display value lands at ``{clean}_display``.
    """
    if isinstance(data, dict):
        fv_keys: dict[str, Any] = {}
        for key, value in data.items():
            if _FORMATTED_VALUE_ANNOTATION in key:
                base = key.split("@", 1)[0]
                fv_keys[base] = value

        existing_keys = {k for k in data if "@" not in k}
        result: dict[str, Any] = {}
        for key, value in data.items():
            if "@" in key:
                continue
            if key in fv_keys:
                if key.startswith("_") and key.endswith("_value"):
                    clean = key[1 : -len("_value")]
                else:
                    clean = key
                if clean != key and clean in existing_keys:
                    # Collision — preserve original; surface display separately.
                    result[key] = value
                    result[f"{clean}_display"] = fv_keys[key]
                else:
                    result[clean] = fv_keys[key]
                    if key != clean:
                        result[f"{clean}_id"] = value
            else:
                result[key] = _flatten_formatted_values(value)
        return result
    if isinstance(data, list):
        return [_flatten_formatted_values(item) for item in data]
    return data
