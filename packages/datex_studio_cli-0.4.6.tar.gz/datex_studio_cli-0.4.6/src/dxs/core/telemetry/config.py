"""Telemetry configuration and persistent local state.

The CLI POSTs events to a Datex-owned telemetry endpoint, which validates the
user's Entra token and forwards to DataDog server-side. The DD API key never
ships in the CLI.

Resolution order (highest to lowest):
    1. Environment variables (DXS_TELEMETRY, DXS_TELEMETRY_ENDPOINT)
    2. ~/.datex/telemetry.yaml (keys: endpoint, disabled)
    3. DEFAULT_ENDPOINT (None today; flipped to the production URL once the
       service is deployed and a new CLI release is cut)

The local state file holds the per-machine opt-out flag, the optional endpoint
override, and the first-run notice marker.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any

import yaml

from dxs.utils.paths import get_datex_home

# Set to the production telemetry endpoint URL when the service is deployed.
# Until then, telemetry is implicitly off — no DNS lookups, no failed POSTs.
DEFAULT_ENDPOINT: str | None = None


def telemetry_state_path():  # type: ignore[no-untyped-def]
    """Path to the per-machine telemetry state file."""
    return get_datex_home() / "telemetry.yaml"


def _read_state() -> dict[str, Any]:
    path = telemetry_state_path()
    if not path.exists():
        return {}
    try:
        data = yaml.safe_load(path.read_text())
        return data if isinstance(data, dict) else {}
    except (yaml.YAMLError, OSError):
        return {}


def _write_state(state: dict[str, Any]) -> None:
    path = telemetry_state_path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(yaml.safe_dump(state, default_flow_style=False))
    except OSError:
        pass  # Telemetry state must never break the CLI


def _env_truthy(name: str) -> bool:
    return os.environ.get(name, "").strip().lower() in ("1", "true", "yes", "on")


def _env_falsy(name: str) -> bool:
    return os.environ.get(name, "").strip().lower() in ("0", "false", "no", "off")


@dataclass
class TelemetryConfig:
    """Resolved telemetry configuration for the current process."""

    endpoint: str | None
    disabled_via_env: bool
    disabled_via_state: bool
    debug: bool

    @property
    def enabled(self) -> bool:
        """True when telemetry should actually emit events.

        Requires both an endpoint URL and the absence of any disable signal.
        """
        if self.disabled_via_env or self.disabled_via_state:
            return False
        return bool(self.endpoint)

    @property
    def anonymous_endpoint(self) -> str | None:
        """Anonymous fallback URL derived from the configured endpoint.

        Convention: append ``/anonymous`` to the configured path. The service
        exposes ``POST /v1/events`` (authenticated) and
        ``POST /v1/events/anonymous`` (unauthenticated).
        """
        if not self.endpoint:
            return None
        return self.endpoint.rstrip("/") + "/anonymous"


def load_config() -> TelemetryConfig:
    """Load the resolved telemetry configuration."""
    state = _read_state()
    endpoint_raw = (
        os.environ.get("DXS_TELEMETRY_ENDPOINT") or state.get("endpoint") or DEFAULT_ENDPOINT
    )
    endpoint = str(endpoint_raw).rstrip("/") if endpoint_raw else None
    return TelemetryConfig(
        endpoint=endpoint,
        disabled_via_env=_env_falsy("DXS_TELEMETRY"),
        disabled_via_state=bool(state.get("disabled", False)),
        debug=_env_truthy("DXS_TELEMETRY_DEBUG"),
    )


# ── Mutating helpers (used by `dxs telemetry` subcommands) ──────────────


def set_disabled(disabled: bool) -> None:
    """Persist the opt-out flag to ~/.datex/telemetry.yaml."""
    state = _read_state()
    state["disabled"] = bool(disabled)
    _write_state(state)


def set_endpoint(endpoint: str | None) -> None:
    """Persist the endpoint override to ~/.datex/telemetry.yaml."""
    state = _read_state()
    if endpoint:
        state["endpoint"] = endpoint
    else:
        state.pop("endpoint", None)
    _write_state(state)


def get_first_run_notice_shown_at() -> float | None:
    state = _read_state()
    val = state.get("notice_shown_at")
    return float(val) if isinstance(val, (int, float)) else None


def mark_first_run_notice_shown(when: float) -> None:
    state = _read_state()
    state["notice_shown_at"] = float(when)
    _write_state(state)
