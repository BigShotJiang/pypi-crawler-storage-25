"""Telemetry: structured CLI usage events sent to DataDog.

Public API (called from cli.py and main()):

    record_start(argv: list[str], command: str)
    record_end(exit_code: int = 0)
    record_error(exc: BaseException, exit_code: int = 1)
    maybe_show_first_run_notice()
    flush(timeout: float = 0.5)

The sender runs on a daemon thread; failures are swallowed silently. Set
``DXS_TELEMETRY_DEBUG=1`` to surface them.
"""

from dxs.core.telemetry.recorder import (
    flush,
    maybe_show_first_run_notice,
    record_end,
    record_error,
    record_start,
)

__all__ = [
    "flush",
    "maybe_show_first_run_notice",
    "record_end",
    "record_error",
    "record_start",
]
