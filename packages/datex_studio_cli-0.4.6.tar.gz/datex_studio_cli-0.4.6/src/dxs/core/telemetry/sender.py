"""Background sender that POSTs telemetry events to the Datex telemetry service.

A single daemon thread drains a bounded queue. ``submit()`` is non-blocking;
overflow is silently dropped. ``flush(timeout)`` is called from atexit to give
the queue a brief window to drain before the process exits.

The CLI does not talk to DataDog directly. It POSTs Datex-canonical events to
the telemetry endpoint, which validates the user's Entra token and forwards
to DD server-side. When no valid Entra token is cached locally, the request
falls back to the unauthenticated ``/anonymous`` variant of the same path.

This module never raises into caller code. Failures are logged via the
``DXS_TELEMETRY_DEBUG`` channel only.
"""

from __future__ import annotations

import atexit
import queue
import threading
import time
from typing import Any

import click

from dxs.core.telemetry.config import TelemetryConfig, load_config

QUEUE_CAPACITY = 100
SEND_TIMEOUT_SECONDS = 2.0
WORKER_POLL_SECONDS = 0.2
DEFAULT_FLUSH_TIMEOUT = 0.5
SCHEMA_VERSION = 1


def _debug(msg: str) -> None:
    cfg = load_config()
    if cfg.debug:
        click.echo(f"[telemetry] {msg}", err=True)


def _get_cached_access_token() -> str | None:
    """Return the cached MSAL access token if present and not expired.

    Never triggers a refresh — telemetry runs on the CLI hot path and must
    not block on auth I/O.
    """
    try:
        from dxs.core.auth.token_cache import MultiIdentityTokenCache

        return MultiIdentityTokenCache().get_valid_token()
    except Exception:  # noqa: BLE001 - identity is best-effort
        return None


def _build_envelope(events: list[dict[str, Any]], install_id: str | None) -> dict[str, Any]:
    return {"schema_version": SCHEMA_VERSION, "events": events}


def _build_headers(install_id: str | None, access_token: str | None) -> dict[str, str]:
    headers = {
        "Content-Type": "application/json",
        "X-Dxs-Schema-Version": str(SCHEMA_VERSION),
    }
    if install_id:
        headers["X-Dxs-Install-Id"] = install_id
    if access_token:
        headers["Authorization"] = f"Bearer {access_token}"
    return headers


def _post_once(
    url: str,
    body: dict[str, Any],
    headers: dict[str, str],
) -> int | None:
    """Synchronously POST. Returns status code, or None on network failure."""
    try:
        import httpx

        response = httpx.post(
            url,
            json=body,
            headers=headers,
            timeout=SEND_TIMEOUT_SECONDS,
        )
        return int(response.status_code)
    except Exception as e:  # noqa: BLE001
        _debug(f"network error posting to {url}: {type(e).__name__}: {e}")
        return None


def _send(events: list[dict[str, Any]], cfg: TelemetryConfig) -> None:
    """POST a batch of events. Picks authenticated vs anonymous endpoint and
    retries the anonymous variant once on 401.
    """
    if not events or not cfg.endpoint:
        return

    # The first event in a batch always carries the install_id (they're all
    # generated in the same process, so they all match).
    install_id = events[0].get("install_id") if events else None
    body = _build_envelope(events, install_id)

    access_token = _get_cached_access_token()
    auth_url = cfg.endpoint
    anon_url = cfg.anonymous_endpoint or auth_url

    if access_token:
        status = _post_once(auth_url, body, _build_headers(install_id, access_token))
        if status is None:
            return
        if status == 401:
            _debug("authenticated POST returned 401; retrying as anonymous")
            status = _post_once(anon_url, body, _build_headers(install_id, None))
        _debug(f"telemetry POST {auth_url} -> {status}")
    else:
        status = _post_once(anon_url, body, _build_headers(install_id, None))
        _debug(f"telemetry POST (anonymous) {anon_url} -> {status}")


class _Sender:
    """Singleton background sender."""

    _instance: _Sender | None = None
    _instance_lock = threading.Lock()

    def __init__(self) -> None:
        self._queue: queue.Queue[dict[str, Any] | None] = queue.Queue(maxsize=QUEUE_CAPACITY)
        self._stopping = threading.Event()
        self._thread = threading.Thread(
            target=self._worker,
            daemon=True,
            name="dxs-telemetry-sender",
        )
        self._thread.start()
        atexit.register(self._atexit_handler)

    @classmethod
    def get(cls) -> _Sender:
        with cls._instance_lock:
            if cls._instance is None:
                cls._instance = cls()
            return cls._instance

    def submit(self, event: dict[str, Any]) -> None:
        try:
            self._queue.put_nowait(event)
        except queue.Full:
            _debug("queue full; dropping event")

    def _worker(self) -> None:
        while not self._stopping.is_set():
            try:
                event = self._queue.get(timeout=WORKER_POLL_SECONDS)
            except queue.Empty:
                continue

            if event is None:  # poison pill from _atexit_handler
                self._queue.task_done()
                return

            cfg = load_config()
            if cfg.enabled:
                _send([event], cfg)
            self._queue.task_done()

    def flush(self, timeout: float = DEFAULT_FLUSH_TIMEOUT) -> None:
        """Wait up to ``timeout`` seconds for the queue to drain."""
        deadline = time.monotonic() + max(0.0, timeout)
        while time.monotonic() < deadline:
            if self._queue.unfinished_tasks == 0:
                return
            time.sleep(0.01)

    def _atexit_handler(self) -> None:
        try:
            self.flush(DEFAULT_FLUSH_TIMEOUT)
        except Exception:  # noqa: BLE001
            pass
        self._stopping.set()


def submit(event: dict[str, Any]) -> None:
    """Module-level convenience: enqueue an event for async send."""
    _Sender.get().submit(event)


def flush(timeout: float = DEFAULT_FLUSH_TIMEOUT) -> None:
    """Module-level convenience: flush the singleton sender."""
    _Sender.get().flush(timeout)


def send_sync(event: dict[str, Any]) -> bool:
    """Synchronously POST a single event and return whether it likely succeeded.

    Used by ``dxs telemetry test``. Bypasses the queue.
    """
    cfg = load_config()
    if not cfg.endpoint:
        return False

    install_id = event.get("install_id")
    body = _build_envelope([event], install_id)
    access_token = _get_cached_access_token()
    auth_url = cfg.endpoint
    anon_url = cfg.anonymous_endpoint or auth_url

    if access_token:
        status = _post_once(auth_url, body, _build_headers(install_id, access_token))
        if status == 401:
            status = _post_once(anon_url, body, _build_headers(install_id, None))
    else:
        status = _post_once(anon_url, body, _build_headers(install_id, None))

    return status is not None and 200 <= status < 300
