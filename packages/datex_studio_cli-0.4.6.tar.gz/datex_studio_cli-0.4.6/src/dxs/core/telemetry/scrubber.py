"""Scrub argv tokens that look like secrets before sending to telemetry.

Per the enterprise data agreement we send raw command arguments — branch IDs,
query strings, file paths and the like all flow through verbatim. This module
applies a narrow set of defensive rules to keep accidental secret-bearing
flags out of the wire.

Rules:
    1. ``--<flag>`` whose name contains token / password / secret / key /
       credential is treated as a secret-bearing flag. Both ``--flag value``
       and ``--flag=value`` forms have their value masked.
    2. Any token that looks like a JWT (three dot-separated base64-url chunks
       of >=20 chars each) is masked anywhere it appears.
"""

from __future__ import annotations

import re

REDACTED = "***REDACTED***"
REDACTED_JWT = "***REDACTED-JWT***"

SECRET_KEYWORDS = ("token", "password", "secret", "credential", "key")

# JWT-shaped strings: three '.'-separated base64url segments, each >=20 chars.
JWT_RE = re.compile(r"\b[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}\b")


def _is_secret_flag(arg: str) -> bool:
    """True if ``arg`` is a long-form flag whose name contains a secret keyword.

    Single-character short flags (``-t``, ``-k``) are intentionally excluded
    to avoid false positives — short flags rarely carry sensitive payloads
    and we don't have enough signal to mask them safely.
    """
    if not arg.startswith("-"):
        return False
    name = arg.lstrip("-").lower()
    if len(name) <= 1:
        return False
    return any(kw in name for kw in SECRET_KEYWORDS)


def _scrub_jwts(value: str) -> str:
    return JWT_RE.sub(REDACTED_JWT, value)


def scrub_argv(argv: list[str]) -> list[str]:
    """Return a new argv list with secret-bearing values masked.

    Always returns a fresh list; never mutates the input.
    """
    result: list[str] = []
    expect_value_for_secret_flag = False

    for arg in argv:
        if expect_value_for_secret_flag:
            result.append(REDACTED)
            expect_value_for_secret_flag = False
            continue

        # ``--flag=value`` form
        if arg.startswith("-") and "=" in arg:
            flag, _, _value = arg.partition("=")
            if _is_secret_flag(flag):
                result.append(f"{flag}={REDACTED}")
                continue

        # ``--flag value`` form: mask the next token, not this one
        if _is_secret_flag(arg):
            result.append(arg)
            expect_value_for_secret_flag = True
            continue

        # Mask any embedded JWT-shaped tokens regardless of position
        result.append(_scrub_jwts(arg))

    return result


def scrub_string(value: str) -> str:
    """Public helper: scrub embedded JWTs from an arbitrary string."""
    return _scrub_jwts(value)
