"""Recorder: the public API the CLI uses to emit telemetry events.

State is held at module level — there's exactly one CLI invocation per process.
Calls are silent on every error path; telemetry must never break the CLI.
"""

from __future__ import annotations

import os
import platform
import sys
import time
from datetime import datetime, timezone
from typing import Any

import click

from dxs import __version__
from dxs.core.telemetry import sender
from dxs.core.telemetry.config import (
    get_first_run_notice_shown_at,
    load_config,
    mark_first_run_notice_shown,
)
from dxs.core.telemetry.identity import (
    get_datex_identity,
    get_install_id,
    get_os_user,
    get_session_id,
)
from dxs.core.telemetry.scrubber import scrub_argv

SCHEMA_VERSION = 1

# Event lifecycle state (module-level — one CLI invocation per process)
_state: dict[str, Any] = {
    "started_at": None,  # monotonic clock for duration
    "started_at_wall": None,  # wall clock for ts
    "argv": None,  # scrubbed
    "command": None,  # human-friendly command path
    "recorded_end": False,  # idempotent guard
}


def record_start(argv: list[str], command: str) -> None:
    """Mark the start of a CLI invocation. Safe to call once per process."""
    if _state["started_at"] is not None:
        return
    _state["started_at"] = time.monotonic()
    _state["started_at_wall"] = datetime.now(timezone.utc).isoformat()
    _state["argv"] = scrub_argv(list(argv))
    _state["command"] = command


def record_end(exit_code: int = 0, ctx_extras: dict[str, Any] | None = None) -> None:
    """Mark a successful CLI invocation. Idempotent."""
    if _state["recorded_end"]:
        return
    _state["recorded_end"] = True

    cfg = load_config()
    if not cfg.enabled:
        return

    event = _build_event(
        event_type="command.success",
        exit_code=exit_code,
        ctx_extras=ctx_extras,
    )
    sender.submit(event)


def record_error(
    exc: BaseException,
    exit_code: int = 1,
    ctx_extras: dict[str, Any] | None = None,
) -> None:
    """Mark a failed CLI invocation. Idempotent (first call wins)."""
    if _state["recorded_end"]:
        return
    _state["recorded_end"] = True

    cfg = load_config()
    if not cfg.enabled:
        return

    event = _build_event(
        event_type="command.error",
        exit_code=exit_code,
        error=exc,
        ctx_extras=ctx_extras,
    )
    sender.submit(event)


def flush(timeout: float = 0.5) -> None:
    """Flush the sender's queue. Called from main() at process end."""
    try:
        sender.flush(timeout)
    except Exception:  # noqa: BLE001
        pass


def maybe_show_first_run_notice() -> None:
    """Print a one-time notice that telemetry is being collected.

    Only fires when:
        - telemetry is configured (api key present) and not disabled
        - the notice has never been shown on this machine
        - stderr is a TTY (no banner pollution into logs)
    """
    cfg = load_config()
    if not cfg.enabled:
        return
    if not sys.stderr.isatty():
        return
    if get_first_run_notice_shown_at() is not None:
        return

    click.echo("", err=True)
    click.echo("  Datex Studio CLI sends usage telemetry to Datex.", err=True)
    click.echo("  Disable with: dxs telemetry disable", err=True)
    click.echo("  Or set DXS_TELEMETRY=0 in your environment.", err=True)
    click.echo(
        "  Details: https://github.com/datex/datex-studio-cli/blob/main/docs/telemetry.md", err=True
    )
    click.echo("", err=True)

    mark_first_run_notice_shown(time.time())


# ── Event construction ──────────────────────────────────────────────────


def _duration_ms() -> float | None:
    started = _state.get("started_at")
    if started is None:
        return None
    return round((time.monotonic() - float(started)) * 1000.0, 2)


def _build_event(
    *,
    event_type: str,
    exit_code: int | None = None,
    error: BaseException | None = None,
    ctx_extras: dict[str, Any] | None = None,
) -> dict[str, Any]:
    identity = get_datex_identity()
    duration_ms = _duration_ms()

    event: dict[str, Any] = {
        "schema_version": SCHEMA_VERSION,
        "event_type": event_type,
        "ts": datetime.now(timezone.utc).isoformat(),
        "started_at": _state.get("started_at_wall"),
        "command": _state.get("command"),
        "argv": _state.get("argv"),
        "duration_ms": duration_ms,
        "version": __version__,
        "python_version": platform.python_version(),
        "os": platform.system(),
        "os_release": platform.release(),
        "os_user": get_os_user(),
        "session_id": get_session_id(),
        "install_id": get_install_id(),
        "api_target": _resolve_api_target(),
        "message": _build_message(event_type, error),
    }
    event.update(identity)

    if exit_code is not None:
        event["exit_code"] = exit_code

    if error is not None:
        event["error_class"] = type(error).__name__
        event["error_message"] = _truncate(str(error), 1000)
        # DxsError carries a stable code we want to filter on
        code = getattr(error, "code", None)
        if isinstance(code, str):
            event["error_code"] = code

    if ctx_extras:
        for key, value in ctx_extras.items():
            event[f"ctx_{key}"] = value

    return event


def _build_message(event_type: str, error: BaseException | None) -> str:
    """Human-readable summary. Server may use as-is or rebuild."""
    cmd = _state.get("command") or "<unknown>"
    if error is not None:
        return f"{event_type} {cmd}: {type(error).__name__}"
    return f"{event_type} {cmd}"


def _resolve_api_target() -> str:
    """Return a short label for which Datex environment was targeted."""
    base = os.environ.get("DXS_API_BASE_URL", "")
    if "dev.wavelength.host" in base:
        return "dev"
    if "qa.wavelength.host" in base:
        return "qa"
    if base:
        return "prod"
    return "default"


def _truncate(value: str, limit: int) -> str:
    if len(value) <= limit:
        return value
    return value[: limit - 1] + "…"


# ── Test hook ───────────────────────────────────────────────────────────


def reset_for_tests() -> None:
    """Reset module-level state. Tests only."""
    _state["started_at"] = None
    _state["started_at_wall"] = None
    _state["argv"] = None
    _state["command"] = None
    _state["recorded_end"] = False


def build_test_event() -> dict[str, Any]:
    """Build a synthetic event used by ``dxs telemetry test``."""
    if _state["started_at"] is None:
        record_start(argv=["telemetry", "test"], command="telemetry test")
    return _build_event(event_type="command.test", exit_code=0)
