"""Identity, session, and install-ID helpers for telemetry events."""

from __future__ import annotations

import getpass
import hashlib
import os
import uuid
from typing import Any

from dxs.utils.paths import get_datex_home

INSTALL_ID_FILE = "install_id"


def get_session_id() -> str:
    """Return a stable identifier for the current shell tab.

    Computed from ``(cwd, parent_pid)``. Two ``dxs`` invocations from the same
    terminal tab produce the same session ID; commands run from a different
    shell or a different working directory produce a different one.

    PID reuse can theoretically merge sessions but is vanishingly rare in
    practice — at this scale, not worth a dependency on psutil to harden.
    """
    raw = f"{os.getcwd()}|{os.getppid()}"
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]


def get_os_user() -> str:
    """Best-effort OS-level username."""
    try:
        return getpass.getuser()
    except Exception:  # noqa: BLE001 - never raise from telemetry helpers
        return "unknown"


def get_install_id() -> str:
    """Return a stable per-machine install ID, generating one on first call.

    Stored in ~/.datex/install_id as plain text. If the file can't be read or
    written, a transient ID is returned so events still group within the
    process — they just won't correlate across runs.
    """
    path = get_datex_home() / INSTALL_ID_FILE
    if path.exists():
        try:
            existing = path.read_text().strip()
            if existing:
                return existing
        except OSError:
            pass

    new_id = str(uuid.uuid4())
    try:
        path.write_text(new_id)
    except OSError:
        pass
    return new_id


def get_datex_identity() -> dict[str, Any]:
    """Extract Datex identity (UPN, OID, tenant, org) from the MSAL token cache.

    Returns a dict with all fields present (None when not logged in).
    """
    blank: dict[str, Any] = {
        "datex_upn": None,
        "datex_oid": None,
        "datex_tenant_id": None,
        "datex_org_id": None,
        "datex_org_name": None,
    }
    try:
        from dxs.core.auth.token_cache import MultiIdentityTokenCache

        cache = MultiIdentityTokenCache()
        identity = cache.get_active_identity()
        if identity is None:
            return blank
        return {
            "datex_upn": identity.account_username,
            "datex_oid": identity.account_id,
            "datex_tenant_id": identity.tenant_id,
            "datex_org_id": identity.organization_id,
            "datex_org_name": identity.organization_name,
        }
    except Exception:  # noqa: BLE001 - identity is best-effort, never raise
        return blank
