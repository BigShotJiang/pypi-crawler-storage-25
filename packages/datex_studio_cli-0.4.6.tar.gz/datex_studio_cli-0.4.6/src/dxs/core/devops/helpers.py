"""Pure helper functions for Azure DevOps commands."""

from dxs.utils.config import get_settings
from dxs.utils.errors import ValidationError


def resolve_devops_org(organization: str | None) -> str:
    """Resolve the Azure DevOps organization from CLI flag or config.

    Args:
        organization: Explicit org from --org flag, or None.

    Returns:
        Resolved organization name.

    Raises:
        ValidationError: If no organization can be determined.
    """
    if organization:
        return organization

    default = get_settings().default_devops_org
    if default:
        return default

    raise ValidationError(
        message="Azure DevOps organization is required.",
        code="DXS-DEVOPS-ORG-001",
        suggestions=[
            "Pass --org <organization> on the command line",
            "Set default_devops_org in ~/.datex/config.yaml",
            "Set DXS_DEFAULT_DEVOPS_ORG environment variable",
        ],
    )


def resolve_attachment(
    attachment_list: list[dict[str, object]],
    download: str,
) -> dict[str, object]:
    """Resolve an attachment by name or 1-based index.

    Args:
        attachment_list: List of attachment dicts with index, name, url.
        download: Attachment name or 1-based index string.

    Returns:
        Matching attachment dict.

    Raises:
        ValidationError: If no match is found.
    """
    # Try as 1-based index first
    try:
        idx = int(download)
        if 1 <= idx <= len(attachment_list):
            return attachment_list[idx - 1]
        raise ValidationError(
            message=f"Attachment index {idx} out of range (1-{len(attachment_list)}).",
            code="DXS-DEVOPS-ATTACH-001",
            suggestions=[f"Use an index between 1 and {len(attachment_list)}"],
        )
    except ValueError:
        pass

    # Try as name (case-insensitive)
    for att in attachment_list:
        if str(att.get("name", "")).lower() == download.lower():
            return att

    names = [str(a["name"]) for a in attachment_list]
    raise ValidationError(
        message=f"Attachment '{download}' not found.",
        code="DXS-DEVOPS-ATTACH-002",
        suggestions=[f"Available attachments: {', '.join(names)}"],
    )
