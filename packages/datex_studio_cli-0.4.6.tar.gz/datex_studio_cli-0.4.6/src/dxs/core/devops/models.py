"""Pydantic models for Azure DevOps API responses."""

import re
from typing import Any

from markdownify import markdownify as md
from pydantic import BaseModel, Field

# Default truncation limit for HTML fields (in characters of converted markdown)
_HTML_TRUNCATE_LIMIT = 2000

# HTML fields to extract and convert to markdown in to_detail()
_HTML_FIELDS: list[tuple[str, str]] = [
    ("System.Description", "description"),
    ("Microsoft.VSTS.TCM.ReproSteps", "repro_steps"),
    ("Microsoft.VSTS.Common.AcceptanceCriteria", "acceptance_criteria"),
    ("Custom.Design", "design"),
    ("Custom.GWT", "gwt"),
]

# Regex to extract work item ID from an API URL
_WORKITEM_ID_RE = re.compile(r"/_apis/wit/workItems/(\d+)")

# Regex to extract org from an API URL
_API_URL_RE = re.compile(r"https://dev\.azure\.com/([^/]+)/")

# Regex to match DevOps inline image markdown references
_DEVOPS_IMAGE_RE = re.compile(
    r"!\[(?:Image|image)\]\((https://dev\.azure\.com/[^)]+/_apis/wit/attachments/[^)]+)\)"
)


def _html_to_markdown(html: str, *, truncate: int | None = None) -> str:
    """Convert HTML to clean markdown.

    Args:
        html: HTML string from Azure DevOps
        truncate: If set, truncate output to this many characters and append a notice.

    Returns:
        Clean markdown string
    """
    if not html:
        return ""

    # Convert HTML to markdown
    markdown = md(html, heading_style="ATX", strip=["script", "style"])

    # Normalize non-breaking spaces and tabs for clean YAML output
    markdown = markdown.replace("\xa0", " ")  # NBSP → space
    markdown = markdown.replace(
        "\t", "    "
    )  # Tab → 4 spaces (YAML literal blocks can't contain tabs)

    # Clean up excessive whitespace
    markdown = re.sub(r"\n{3,}", "\n\n", markdown)  # Max 2 newlines
    markdown = re.sub(r"[ \t]+\n", "\n", markdown)  # Trailing spaces
    markdown = markdown.strip()

    if truncate and len(markdown) > truncate:
        markdown = (
            markdown[:truncate].rstrip() + "\n\n(truncated — use --full to see complete content)"
        )

    return markdown


def extract_inline_image_urls(markdown: str) -> list[str]:
    """Extract unique DevOps inline image URLs from markdown text."""
    seen: set[str] = set()
    result: list[str] = []
    for match in _DEVOPS_IMAGE_RE.finditer(markdown):
        url = match.group(1)
        if url not in seen:
            seen.add(url)
            result.append(url)
    return result


def _flatten_person(value: Any) -> str:
    """Extract display name from an Azure DevOps person object.

    Args:
        value: A person dict with displayName, or a plain string.

    Returns:
        Display name string, or empty string if not available.
    """
    if isinstance(value, dict):
        return str(value.get("displayName", ""))
    return str(value) if value else ""


class DevOpsWorkItemDto(BaseModel):
    """Azure DevOps work item information."""

    id: int
    rev: int = 1
    url: str | None = None
    fields: dict[str, Any] = Field(default_factory=dict)
    relations: list[dict[str, Any]] = Field(default_factory=list)
    discussions: list[dict[str, Any]] = Field(default_factory=list)

    model_config = {"populate_by_name": True}

    @property
    def title(self) -> str:
        """Get work item title."""
        return str(self.fields.get("System.Title", ""))

    @property
    def work_item_type(self) -> str:
        """Get work item type (Bug, Task, User Story, etc.)."""
        return str(self.fields.get("System.WorkItemType", ""))

    @property
    def state(self) -> str:
        """Get work item state (New, Active, Resolved, Closed, etc.)."""
        return str(self.fields.get("System.State", ""))

    @property
    def description(self) -> str:
        """Get work item description (HTML)."""
        return str(self.fields.get("System.Description", ""))

    @property
    def assigned_to(self) -> str:
        """Get assigned user display name."""
        return _flatten_person(self.fields.get("System.AssignedTo"))

    @property
    def created_date(self) -> str:
        """Get created date."""
        return str(self.fields.get("System.CreatedDate", ""))

    @property
    def changed_date(self) -> str:
        """Get last changed date."""
        return str(self.fields.get("System.ChangedDate", ""))

    @property
    def tags(self) -> list[str]:
        """Get work item tags."""
        tags_str = self.fields.get("System.Tags", "")
        if tags_str:
            return [t.strip() for t in tags_str.split(";") if t.strip()]
        return []

    @property
    def area_path(self) -> str:
        """Get area path."""
        return str(self.fields.get("System.AreaPath", ""))

    @property
    def iteration_path(self) -> str:
        """Get iteration path."""
        return str(self.fields.get("System.IterationPath", ""))

    @property
    def web_url(self) -> str | None:
        """Convert API URL to human-readable web URL.

        API:  https://dev.azure.com/Org/ProjectGuid/_apis/wit/workItems/1234
        Web:  https://dev.azure.com/Org/_workitems/edit/1234
        """
        if not self.url:
            return None
        m = _API_URL_RE.match(self.url)
        if m:
            org = m.group(1)
            return f"https://dev.azure.com/{org}/_workitems/edit/{self.id}"
        return None

    def _summarize_relations(self) -> dict[str, Any]:
        """Categorize relations into structured groups."""
        attachments: list[dict[str, str]] = []
        parent: int | None = None
        children: list[int] = []
        related: list[int] = []

        for rel in self.relations:
            rel_type = rel.get("rel", "")
            rel_url = rel.get("url", "")
            attrs = rel.get("attributes", {})

            if rel_type == "AttachedFile":
                attachments.append(
                    {
                        "name": attrs.get("name", ""),
                        "url": rel_url,
                    }
                )
            elif rel_type == "System.LinkTypes.Hierarchy-Reverse":
                # Parent
                m = _WORKITEM_ID_RE.search(rel_url)
                if m:
                    parent = int(m.group(1))
            elif rel_type == "System.LinkTypes.Hierarchy-Forward":
                # Child
                m = _WORKITEM_ID_RE.search(rel_url)
                if m:
                    children.append(int(m.group(1)))
            elif rel_type == "System.LinkTypes.Related":
                m = _WORKITEM_ID_RE.search(rel_url)
                if m:
                    related.append(int(m.group(1)))

        result: dict[str, Any] = {}
        if parent is not None:
            result["parent"] = parent
        if children:
            result["children"] = children
        if related:
            result["related"] = related
        if attachments:
            result["attachments"] = attachments
        return result

    def to_detail(self, full: bool = False, include_discussions: bool = False) -> dict[str, Any]:
        """Full curated output for single workitem command.

        Args:
            full: If True, do not truncate HTML fields.
            include_discussions: If True, include discussions array and count.

        Returns:
            Curated dict with flattened person fields, converted HTML, and
            summarized relations.
        """
        truncate = None if full else _HTML_TRUNCATE_LIMIT

        detail: dict[str, Any] = {
            "id": self.id,
            "title": self.title,
            "type": self.work_item_type,
            "state": self.state,
            "assigned_to": self.assigned_to,
            "created_by": _flatten_person(self.fields.get("System.CreatedBy")),
            "changed_by": _flatten_person(self.fields.get("System.ChangedBy")),
            "tags": self.tags,
            "area_path": self.area_path,
            "iteration_path": self.iteration_path,
            "priority": self.fields.get("Microsoft.VSTS.Common.Priority"),
            "created_date": self.created_date,
            "changed_date": self.changed_date,
            "url": self.web_url,
        }

        # Custom fields (only include if present)
        custom_mappings: list[tuple[str, str]] = [
            ("Custom.Project", "project"),
            ("Custom.EffortHours", "effort_hours"),
            ("Microsoft.VSTS.Common.Severity", "severity"),
            ("Microsoft.VSTS.Scheduling.StoryPoints", "story_points"),
            ("Microsoft.VSTS.Scheduling.RemainingWork", "remaining_work"),
        ]
        for field_key, output_key in custom_mappings:
            value = self.fields.get(field_key)
            if value is not None:
                detail[output_key] = value

        # HTML fields — converted from HTML to markdown
        for field_key, output_key in _HTML_FIELDS:
            raw = self.fields.get(field_key, "")
            if raw:
                detail[output_key] = _html_to_markdown(str(raw), truncate=truncate)

        # Relations summary
        if self.relations:
            relations_summary = self._summarize_relations()
            if relations_summary:
                detail["relations"] = relations_summary
            attachment_count = sum(1 for r in self.relations if r.get("rel") == "AttachedFile")
            if attachment_count:
                detail["attachment_count"] = attachment_count

        # Discussions (only when requested)
        if include_discussions:
            detail["discussions"] = self.discussions or []
            detail["discussion_count"] = len(self.discussions or [])

        return detail

    def to_summary(
        self, include_description: bool = False, include_discussions: bool = False
    ) -> dict[str, Any]:
        """Convert to a summary dict for CLI output.

        Used by the batch workitems command and release notes enrichment.

        Args:
            include_description: Include description field (converted to markdown)
            include_discussions: Include discussions array
        """
        summary: dict[str, Any] = {
            "id": self.id,
            "title": self.title,
            "type": self.work_item_type,
            "state": self.state,
            "assigned_to": self.assigned_to,
            "tags": self.tags,
            "area_path": self.area_path,
            "iteration_path": self.iteration_path,
            "created_date": self.created_date,
            "changed_date": self.changed_date,
            "url": self.web_url or self.url,
        }

        # Conditionally add description (converted from HTML to markdown)
        if include_description:
            summary["description"] = _html_to_markdown(self.description)

        # Conditionally add discussions (with HTML converted to markdown)
        if include_discussions:
            # Simplify discussion structure for CLI output
            summary["discussions"] = [
                {
                    "text": _html_to_markdown(d.get("text", "")),
                    "created_by": d.get("createdBy", {}).get("displayName", ""),
                    "created_date": d.get("createdDate", ""),
                }
                for d in self.discussions
            ]
            summary["discussion_count"] = len(self.discussions)

        return summary
