#!/usr/bin/env python3
"""Analyze a corpus of RDLX-JSON reports and produce statistics.

Usage:
    python scripts/analyze_corpus.py [DIRECTORY]

Reads all .rdlx-json files under the given directory (default: example-reports/)
and prints statistics about page sizes, margins, item types, barcode symbologies,
fonts, expressions, datasets, element counts, and more.
"""

from __future__ import annotations

import json
import re
import sys
from collections import Counter
from pathlib import Path
from statistics import mean, median


def collect_report_items(obj: dict | list, items: list[dict]) -> None:
    """Recursively collect all report items from a report definition."""
    if isinstance(obj, dict):
        if "Type" in obj and "Name" in obj:
            items.append(obj)
        for v in obj.values():
            if isinstance(v, (dict, list)):
                collect_report_items(v, items)
    elif isinstance(obj, list):
        for v in obj:
            if isinstance(v, (dict, list)):
                collect_report_items(v, items)


def collect_strings(obj: dict | list, strings: list[str]) -> None:
    """Recursively collect all string values from a JSON structure."""
    if isinstance(obj, dict):
        for v in obj.values():
            if isinstance(v, str):
                strings.append(v)
            elif isinstance(v, (dict, list)):
                collect_strings(v, strings)
    elif isinstance(obj, list):
        for v in obj:
            if isinstance(v, str):
                strings.append(v)
            elif isinstance(v, (dict, list)):
                collect_strings(v, strings)


def collect_fonts(obj: dict | list, fonts: list[str]) -> None:
    """Recursively collect FontFamily values from Style objects."""
    if isinstance(obj, dict):
        if "FontFamily" in obj:
            fonts.append(obj["FontFamily"])
        for v in obj.values():
            if isinstance(v, (dict, list)):
                collect_fonts(v, fonts)
    elif isinstance(obj, list):
        for v in obj:
            if isinstance(v, (dict, list)):
                collect_fonts(v, fonts)


def collect_field_names(obj: dict | list, fields: list[str]) -> None:
    """Recursively extract field names from expressions (Fields!X.Value)."""
    if isinstance(obj, dict):
        for v in obj.values():
            if isinstance(v, str):
                for m in re.finditer(r"Fields!(\w+)\.Value", v):
                    fields.append(m.group(1))
            elif isinstance(v, (dict, list)):
                collect_field_names(v, fields)
    elif isinstance(obj, list):
        for v in obj:
            if isinstance(v, str):
                for m in re.finditer(r"Fields!(\w+)\.Value", v):
                    fields.append(m.group(1))
            elif isinstance(v, (dict, list)):
                collect_field_names(v, fields)


def effective_page(report: dict) -> dict:
    """Get the effective page settings (section-level overrides top-level)."""
    sections = report.get("ReportSections", [])
    if sections and "Page" in sections[0]:
        return sections[0]["Page"]
    return report.get("Page", {})


def main() -> None:
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("example-reports")
    if not root.exists():
        print(f"Error: directory '{root}' not found", file=sys.stderr)
        sys.exit(1)

    files = sorted(root.rglob("*.rdlx-json"))
    if not files:
        print(f"No .rdlx-json files found under '{root}'", file=sys.stderr)
        sys.exit(1)

    # Categorize by top-level folder under root
    category_counts: Counter[str] = Counter()
    page_sizes: Counter[str] = Counter()
    margin_counter: Counter[str] = Counter()
    item_type_counter: Counter[str] = Counter()
    barcode_symbology_counter: Counter[str] = Counter()
    font_counter: Counter[str] = Counter()
    expression_pattern_counter: Counter[str] = Counter()
    dataset_counts: list[int] = []
    element_counts_by_category: dict[str, list[int]] = {}
    field_names_by_category: dict[str, Counter[str]] = {}
    page_header_count = 0
    page_footer_count = 0
    total = 0

    for f in files:
        try:
            report = json.loads(f.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError) as e:
            print(f"Warning: skipping {f}: {e}", file=sys.stderr)
            continue

        total += 1

        # Category = first path component relative to root
        rel = f.relative_to(root)
        category = rel.parts[0] if len(rel.parts) > 1 else "uncategorized"
        category_counts[category] += 1

        # Page size
        page = effective_page(report)
        pw = page.get("PageWidth", "8.5in")
        ph = page.get("PageHeight", "11in")
        page_sizes[f"{pw} x {ph}"] += 1

        # Margins
        margins = (
            page.get("TopMargin", "0.5in"),
            page.get("BottomMargin", "0.5in"),
            page.get("LeftMargin", "0.5in"),
            page.get("RightMargin", "0.5in"),
        )
        margin_key = f"T={margins[0]} B={margins[1]} L={margins[2]} R={margins[3]}"
        margin_counter[margin_key] += 1

        # All items (recursive)
        items: list[dict] = []
        collect_report_items(report, items)
        for item in items:
            t = item.get("Type", "unknown")
            item_type_counter[t.lower()] += 1
            # Barcode symbology
            if t.lower() == "barcode":
                sym = item.get("Symbology", "unknown")
                barcode_symbology_counter[sym] += 1

        # Element count per category (top-level body items only)
        body_items = []
        for sec in report.get("ReportSections", []):
            body_items.extend(sec.get("Body", {}).get("ReportItems", []))
        element_counts_by_category.setdefault(category, []).append(len(body_items))

        # Fonts
        fonts: list[str] = []
        collect_fonts(report, fonts)
        for fnt in fonts:
            font_counter[fnt] += 1

        # Expressions
        strings: list[str] = []
        collect_strings(report, strings)
        for s in strings:
            if not s.startswith("="):
                continue
            if "First(" in s:
                expression_pattern_counter["First()"] += 1
            if re.search(r"(?<!First\()Fields!\w+\.Value", s):
                expression_pattern_counter["bare Fields!"] += 1
            if "Format(" in s:
                expression_pattern_counter["Format()"] += 1
            if "IIf(" in s:
                expression_pattern_counter["IIf()"] += 1
            if "&" in s:
                expression_pattern_counter["concatenation (&)"] += 1
            if "Globals!PageNumber" in s:
                expression_pattern_counter["Globals!PageNumber"] += 1
            if "Globals!TotalPages" in s:
                expression_pattern_counter["Globals!TotalPages"] += 1
            if "Globals!ExecutionTime" in s:
                expression_pattern_counter["Globals!ExecutionTime"] += 1
            if "Sum(" in s:
                expression_pattern_counter["Sum()"] += 1
            if "Count(" in s:
                expression_pattern_counter["Count()"] += 1
            if "Parameters!" in s:
                expression_pattern_counter["Parameters!"] += 1

        # Datasets
        datasets = report.get("DataSets", [])
        dataset_counts.append(len(datasets))

        # Field names by category
        fields: list[str] = []
        collect_field_names(report, fields)
        field_names_by_category.setdefault(category, Counter()).update(fields)

        # PageHeader/PageFooter
        for sec in report.get("ReportSections", []):
            if sec.get("PageHeader"):
                page_header_count += 1
                break
        for sec in report.get("ReportSections", []):
            if sec.get("PageFooter"):
                page_footer_count += 1
                break

    # ── Output ──

    print(f"{'=' * 70}")
    print(f"RDLX-JSON Corpus Analysis — {total} reports from {root}")
    print(f"{'=' * 70}")

    print(f"\n## Report Counts by Category ({len(category_counts)} categories)")
    for cat, cnt in category_counts.most_common():
        print(f"  {cat:30s} {cnt:4d}")

    print("\n## Page Size Distribution")
    for size, cnt in page_sizes.most_common():
        pct = cnt / total * 100
        print(f"  {size:30s} {cnt:4d}  ({pct:.0f}%)")

    print("\n## Margin Distribution")
    for margin, cnt in margin_counter.most_common(15):
        pct = cnt / total * 100
        print(f"  {margin:55s} {cnt:4d}  ({pct:.0f}%)")

    print("\n## Item Type Frequency")
    for typ, cnt in item_type_counter.most_common():
        print(f"  {typ:25s} {cnt:5d}")

    print("\n## Barcode Symbology Frequency")
    for sym, cnt in barcode_symbology_counter.most_common():
        print(f"  {sym:25s} {cnt:4d}")

    print("\n## Font Usage Frequency (top 20)")
    for fnt, cnt in font_counter.most_common(20):
        print(f"  {fnt:30s} {cnt:5d}")

    print("\n## Expression Pattern Frequency")
    for pat, cnt in expression_pattern_counter.most_common():
        print(f"  {pat:30s} {cnt:5d}")

    print("\n## Dataset Count per Report")
    if dataset_counts:
        print(f"  Mean:   {mean(dataset_counts):.1f}")
        print(f"  Median: {median(dataset_counts):.1f}")
        print(f"  Range:  {min(dataset_counts)} - {max(dataset_counts)}")

    print("\n## Element Count per Report by Category (body-level items)")
    for cat in sorted(element_counts_by_category):
        counts = element_counts_by_category[cat]
        if counts:
            print(
                f"  {cat:30s}  mean={mean(counts):5.1f}  "
                f"median={median(counts):5.1f}  "
                f"range={min(counts)}-{max(counts)}  "
                f"n={len(counts)}"
            )

    print("\n## Common Field Names by Category (top 10)")
    for cat in sorted(field_names_by_category):
        top = field_names_by_category[cat].most_common(10)
        if top:
            print(f"  {cat}:")
            for name, cnt in top:
                print(f"    {name:30s} {cnt:4d}")

    print("\n## PageHeader / PageFooter Usage")
    print(f"  PageHeader: {page_header_count}/{total} ({page_header_count / total * 100:.0f}%)")
    print(f"  PageFooter: {page_footer_count}/{total} ({page_footer_count / total * 100:.0f}%)")


if __name__ == "__main__":
    main()
