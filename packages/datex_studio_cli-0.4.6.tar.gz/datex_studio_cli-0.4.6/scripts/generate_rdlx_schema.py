#!/usr/bin/env python3
"""Generate a data-driven RDLX-JSON schema from a corpus of example reports.

Analyzes all .rdlx-json files under a directory and produces a comprehensive
property-level schema showing every property observed per item type, with
type inference, frequency counts, and value distributions.

Usage:
    python scripts/generate_rdlx_schema.py                              # defaults
    python scripts/generate_rdlx_schema.py example-reports/ -o out.json # explicit paths
    python scripts/generate_rdlx_schema.py --summary-only               # no JSON output
"""

from __future__ import annotations

import argparse
import json
import sys
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

# Threshold: string fields with <= this many distinct values are treated as enums
ENUM_THRESHOLD = 30
# Max example values to store for free-text fields
MAX_EXAMPLES = 10


# ── Item collection (same pattern as analyze_corpus.py) ──────────────────


def collect_report_items(obj: dict | list, items: list[dict]) -> None:
    """Recursively collect all report items (dicts with Type + Name)."""
    if isinstance(obj, dict):
        if "Type" in obj and "Name" in obj:
            items.append(obj)
        for v in obj.values():
            if isinstance(v, (dict, list)):
                collect_report_items(v, items)
    elif isinstance(obj, list):
        for v in obj:
            if isinstance(v, (dict, list)):
                collect_report_items(v, items)


# ── Value analysis ───────────────────────────────────────────────────────


def json_type(value: object) -> str:
    """Return a simple JSON type name for a value."""
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "boolean"
    if isinstance(value, int):
        return "integer"
    if isinstance(value, float):
        return "number"
    if isinstance(value, str):
        return "string"
    if isinstance(value, list):
        return "array"
    if isinstance(value, dict):
        return "object"
    return "unknown"


def analyze_values(values: list[object]) -> dict:
    """Analyze a list of observed values for a single property.

    Returns a dict with type info, count, and either a value distribution
    (for enum-like fields) or sample examples (for free-text).
    Recurses into nested objects.
    """
    type_counts: Counter[str] = Counter()
    for v in values:
        type_counts[json_type(v)] += 1

    types = sorted(type_counts, key=lambda t: -type_counts[t])
    result: dict = {
        "types": types if len(types) > 1 else types[0],
        "count": len(values),
    }

    # If all values are objects, recurse into sub-properties
    dict_values = [v for v in values if isinstance(v, dict)]
    if dict_values and len(dict_values) == len(values):
        result["children"] = analyze_object_properties(dict_values)
        return result

    # For non-object values, analyze distribution
    non_null = [v for v in values if v is not None]
    if not non_null:
        return result

    # String enum detection
    str_values = [v for v in non_null if isinstance(v, str)]
    if str_values:
        distinct = Counter(str_values)
        if len(distinct) <= ENUM_THRESHOLD:
            result["values"] = dict(distinct.most_common())
        else:
            result["distinct_count"] = len(distinct)
            result["examples"] = [v for v, _ in distinct.most_common(MAX_EXAMPLES)]

    # Boolean distribution
    bool_values = [v for v in non_null if isinstance(v, bool)]
    if bool_values:
        result["values"] = dict(Counter(str(v) for v in bool_values).most_common())

    # Numeric summary
    num_values = [v for v in non_null if isinstance(v, (int, float)) and not isinstance(v, bool)]
    if num_values:
        result["min"] = min(num_values)
        result["max"] = max(num_values)
        distinct_nums = set(num_values)
        if len(distinct_nums) <= ENUM_THRESHOLD:
            result["values"] = dict(Counter(num_values).most_common())

    # Array: show length distribution
    arr_values = [v for v in non_null if isinstance(v, list)]
    if arr_values:
        lengths = [len(a) for a in arr_values]
        result["array_length_min"] = min(lengths)
        result["array_length_max"] = max(lengths)

    return result


def analyze_object_properties(dicts: list[dict]) -> dict:
    """Analyze sub-properties across a list of dicts (e.g., Style objects)."""
    prop_values: dict[str, list[object]] = {}
    for d in dicts:
        for k, v in d.items():
            prop_values.setdefault(k, []).append(v)

    return {k: analyze_values(vs) for k, vs in sorted(prop_values.items())}


# ── Document-level analysis ──────────────────────────────────────────────


def analyze_documents(reports: list[dict]) -> dict:
    """Analyze top-level document properties across all reports."""
    prop_values: dict[str, list[object]] = {}
    # Keys to skip (analyzed separately or too large)
    skip = {"ReportSections", "DataSources", "DataSets", "ReportParameters", "EmbeddedImages"}
    for report in reports:
        for k, v in report.items():
            if k not in skip:
                prop_values.setdefault(k, []).append(v)

    return {k: analyze_values(vs) for k, vs in sorted(prop_values.items())}


# ── Item-type analysis ───────────────────────────────────────────────────


def analyze_items(items: list[dict]) -> dict:
    """Group items by Type and analyze properties per type."""
    by_type: dict[str, list[dict]] = {}
    for item in items:
        t = item.get("Type", "unknown").lower()
        by_type.setdefault(t, []).append(item)

    result = {}
    for item_type in sorted(by_type):
        type_items = by_type[item_type]
        prop_values: dict[str, list[object]] = {}
        for item in type_items:
            for k, v in item.items():
                prop_values.setdefault(k, []).append(v)

        result[item_type] = {
            "count": len(type_items),
            "properties": {k: analyze_values(vs) for k, vs in sorted(prop_values.items())},
        }

    return result


# ── Common properties ────────────────────────────────────────────────────


def find_common_properties(item_types: dict, threshold: float = 0.8) -> dict:
    """Identify properties that appear in >= threshold fraction of item types."""
    all_types = set(item_types.keys())
    if not all_types:
        return {}

    prop_type_sets: dict[str, set[str]] = {}
    for type_name, type_info in item_types.items():
        for prop in type_info["properties"]:
            prop_type_sets.setdefault(prop, set()).add(type_name)

    common = {}
    for prop, types_with_prop in sorted(prop_type_sets.items()):
        fraction = len(types_with_prop) / len(all_types)
        if fraction >= threshold:
            common[prop] = {
                "present_in": f"{len(types_with_prop)}/{len(all_types)} types",
                "fraction": round(fraction, 2),
                "types": sorted(types_with_prop),
            }

    return common


# ── Schema comparison ────────────────────────────────────────────────────


def load_schema_constants() -> tuple[dict, dict]:
    """Import ITEM_TYPES and BARCODE_SYMBOLOGIES from schema.py."""
    schema_path = Path(__file__).resolve().parent.parent / "src" / "dxs" / "report" / "schema.py"
    if not schema_path.exists():
        return {}, {}

    # Execute the schema module to extract constants
    ns: dict = {}
    exec(compile(schema_path.read_text(encoding="utf-8"), schema_path, "exec"), ns)
    return ns.get("ITEM_TYPES", {}), ns.get("BARCODE_SYMBOLOGIES", {})


def compare_schema(item_types: dict, items: list[dict]) -> dict:
    """Compare discovered schema against schema.py constants."""
    schema_item_types, schema_symbologies = load_schema_constants()
    if not schema_item_types and not schema_symbologies:
        return {"error": "Could not load schema.py constants"}

    discovered_types = set(item_types.keys())
    schema_types = set(schema_item_types.keys())

    # Item types in corpus but not in schema
    types_not_in_schema = sorted(discovered_types - schema_types)

    # Per-type property gaps
    props_not_in_schema: dict[str, list[str]] = {}
    for type_name in sorted(discovered_types & schema_types):
        schema_props = set(schema_item_types[type_name].get("properties", {}).keys())
        schema_style_props = set(schema_item_types[type_name].get("style_properties", {}).keys())
        all_schema_props = schema_props | schema_style_props
        corpus_props = set(item_types[type_name]["properties"].keys())
        # Exclude common layout props that aren't type-specific
        common_layout = {
            "Type",
            "Name",
            "Left",
            "Top",
            "Width",
            "Height",
            "ZIndex",
            "Visibility",
            "Style",
            "LayerName",
            "OverflowName",
            "Bookmark",
            "Label",
            "CustomProperties",
        }
        missing = sorted((corpus_props - all_schema_props) - common_layout)
        if missing:
            props_not_in_schema[type_name] = missing

    # Barcode symbologies in corpus but not in schema
    corpus_symbologies: set[str] = set()
    for item in items:
        if item.get("Type", "").lower() == "barcode":
            sym = item.get("Symbology")
            if sym:
                corpus_symbologies.add(sym)
    schema_sym_set = set(schema_symbologies.keys())
    sym_not_in_schema = sorted(corpus_symbologies - schema_sym_set)

    return {
        "item_types_in_corpus_not_in_schema": types_not_in_schema,
        "item_types_in_schema_not_in_corpus": sorted(schema_types - discovered_types),
        "properties_in_corpus_not_in_schema": props_not_in_schema,
        "symbologies_in_corpus_not_in_schema": sym_not_in_schema,
        "symbologies_in_schema_not_in_corpus": sorted(schema_sym_set - corpus_symbologies),
    }


# ── Summary printing ─────────────────────────────────────────────────────


def print_summary(schema: dict) -> None:
    """Print a human-readable summary of the generated schema."""
    meta = schema["metadata"]
    print(f"{'=' * 70}")
    print(f"RDLX-JSON Corpus Schema — {meta['total_files']} reports")
    print(f"Generated: {meta['generated_at']}")
    print(f"{'=' * 70}")

    # Document properties
    doc = schema.get("document", {})
    print(f"\n## Document-Level Properties ({len(doc)})")
    for prop, info in sorted(doc.items()):
        t = info.get("types", "?")
        c = info.get("count", 0)
        print(f"  {prop:30s}  type={str(t):15s}  count={c}")

    # Item types
    item_types = schema.get("item_types", {})
    print(f"\n## Item Types ({len(item_types)})")
    for type_name, type_info in sorted(item_types.items(), key=lambda x: -x[1]["count"]):
        prop_count = len(type_info["properties"])
        print(f"  {type_name:25s}  instances={type_info['count']:6d}  properties={prop_count}")

    # Common properties
    common = schema.get("common_properties", {})
    if common:
        print("\n## Common Properties (shared across >=80% of item types)")
        for prop, info in sorted(common.items()):
            print(f"  {prop:25s}  {info['present_in']}")

    # Top properties per type (top 5 by count, excluding common)
    common_names = set(common.keys()) if common else set()
    print("\n## Type-Specific Properties (top 10, excluding common)")
    for type_name, type_info in sorted(item_types.items(), key=lambda x: -x[1]["count"]):
        props = type_info["properties"]
        specific = [(k, v) for k, v in props.items() if k not in common_names]
        specific.sort(key=lambda x: -x[1]["count"])
        top = specific[:10]
        if top:
            print(f"  {type_name}:")
            for prop, info in top:
                t = info.get("types", "?")
                vals = info.get("values", {})
                val_preview = ""
                if vals and isinstance(vals, dict):
                    top_vals = list(vals.keys())[:5]
                    val_preview = f"  values=[{', '.join(str(v) for v in top_vals)}{'...' if len(vals) > 5 else ''}]"
                print(f"    {prop:28s}  type={str(t):10s}  n={info['count']}{val_preview}")

    # Comparison
    comp = schema.get("comparison", {})
    if comp and "error" not in comp:
        print("\n## Schema Comparison (corpus vs schema.py)")

        types_missing = comp.get("item_types_in_corpus_not_in_schema", [])
        if types_missing:
            print("  Item types in corpus but NOT in schema.py:")
            for t in types_missing:
                count = item_types.get(t, {}).get("count", "?")
                print(f"    - {t} ({count} instances)")

        types_extra = comp.get("item_types_in_schema_not_in_corpus", [])
        if types_extra:
            print("  Item types in schema.py but NOT in corpus:")
            for t in types_extra:
                print(f"    - {t}")

        props_missing = comp.get("properties_in_corpus_not_in_schema", {})
        if props_missing:
            print("  Properties in corpus but NOT in schema.py:")
            for type_name, props in sorted(props_missing.items()):
                print(f"    {type_name}: {', '.join(props)}")

        sym_missing = comp.get("symbologies_in_corpus_not_in_schema", [])
        if sym_missing:
            print("  Barcode symbologies in corpus but NOT in schema.py:")
            for s in sym_missing:
                print(f"    - {s}")

        sym_extra = comp.get("symbologies_in_schema_not_in_corpus", [])
        if sym_extra:
            print("  Barcode symbologies in schema.py but NOT in corpus:")
            for s in sym_extra:
                print(f"    - {s}")

    if not comp or all(not v for v in comp.values() if isinstance(v, (list, dict))):
        print("\n  Schema comparison: no gaps found!")


# ── Main ─────────────────────────────────────────────────────────────────


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate RDLX-JSON schema from report corpus")
    parser.add_argument(
        "directory",
        nargs="?",
        default="example-reports",
        help="Directory containing .rdlx-json files (default: example-reports/)",
    )
    parser.add_argument(
        "-o",
        "--output",
        default="corpus-schema.json",
        help="Output JSON file path (default: corpus-schema.json)",
    )
    parser.add_argument(
        "--summary-only",
        action="store_true",
        help="Print human-readable summary only, skip JSON output",
    )
    args = parser.parse_args()

    root = Path(args.directory)
    if not root.exists():
        print(f"Error: directory '{root}' not found", file=sys.stderr)
        sys.exit(1)

    files = sorted(root.rglob("*.rdlx-json"))
    if not files:
        print(f"No .rdlx-json files found under '{root}'", file=sys.stderr)
        sys.exit(1)

    # Load all reports
    reports: list[dict] = []
    skipped = 0
    for f in files:
        try:
            report = json.loads(f.read_text(encoding="utf-8"))
            reports.append(report)
        except (json.JSONDecodeError, UnicodeDecodeError) as e:
            print(f"Warning: skipping {f}: {e}", file=sys.stderr)
            skipped += 1

    print(f"Loaded {len(reports)} reports ({skipped} skipped)", file=sys.stderr)

    # Collect all items
    all_items: list[dict] = []
    for report in reports:
        collect_report_items(report, all_items)
    print(f"Collected {len(all_items)} report items", file=sys.stderr)

    # Analyze
    doc_props = analyze_documents(reports)
    item_types = analyze_items(all_items)
    common_props = find_common_properties(item_types)
    comparison = compare_schema(item_types, all_items)

    schema = {
        "metadata": {
            "total_files": len(reports),
            "total_items": len(all_items),
            "skipped_files": skipped,
            "generated_at": datetime.now(timezone.utc).isoformat(),
        },
        "document": doc_props,
        "item_types": item_types,
        "common_properties": common_props,
        "comparison": comparison,
    }

    # Output
    print_summary(schema)

    if not args.summary_only:
        out_path = Path(args.output)
        out_path.write_text(json.dumps(schema, indent=2, default=str), encoding="utf-8")
        print(f"\nSchema written to {out_path}", file=sys.stderr)


if __name__ == "__main__":
    main()
