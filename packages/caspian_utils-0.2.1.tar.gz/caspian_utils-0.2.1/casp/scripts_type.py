import re


_TYPE_ATTR_RE = re.compile(r'\btype\s*=', re.IGNORECASE)
_OPEN_TAG_BOUNDARY = set(' \t\r\n>/')
_CLOSE_TAG_BOUNDARY = set(' \t\r\n>')


def _find_tag_end(source: str, start: int) -> int:
    in_double_quote = False
    in_single_quote = False
    index = start

    while index < len(source):
        char = source[index]
        if in_double_quote:
            if char == '"':
                in_double_quote = False
        elif in_single_quote:
            if char == "'":
                in_single_quote = False
        else:
            if char == '"':
                in_double_quote = True
            elif char == "'":
                in_single_quote = True
            elif char == '>':
                return index
        index += 1

    return -1


def _inject_type_attr(tag_text: str) -> str:
    if tag_text.endswith('/>'):
        return f'{tag_text[:-2]} type="text/pp"/>'
    return f'{tag_text[:-1]} type="text/pp">'


def transform_scripts(html_content: str) -> str:
    """Add type='text/pp' to body script tags without reparsing the full document."""
    lower_html = html_content.lower()
    if '<script' not in lower_html:
        return html_content

    search_from = 0
    body_start = -1
    while True:
        body_start = lower_html.find('<body', search_from)
        if body_start == -1:
            return html_content
        boundary = body_start + len('<body')
        if boundary >= len(lower_html) or lower_html[boundary] in _OPEN_TAG_BOUNDARY:
            break
        search_from = body_start + 1

    body_tag_end = _find_tag_end(html_content, body_start)
    if body_tag_end == -1:
        return html_content

    body_end = lower_html.find('</body', body_tag_end + 1)
    if body_end == -1:
        body_end = len(html_content)

    if lower_html.find('<script', body_tag_end + 1, body_end) == -1:
        return html_content

    body_html = html_content[body_tag_end + 1:body_end]
    body_lower = lower_html[body_tag_end + 1:body_end]

    result: list[str] = []
    cursor = 0
    length = len(body_html)

    while cursor < length:
        tag_start = body_lower.find('<', cursor)
        if tag_start == -1:
            result.append(body_html[cursor:])
            break

        if body_lower.startswith('<!--', tag_start):
            comment_end = body_lower.find('-->', tag_start + 4)
            if comment_end == -1:
                result.append(body_html[cursor:])
                break
            result.append(body_html[cursor:comment_end + 3])
            cursor = comment_end + 3
            continue

        if not body_lower.startswith('<script', tag_start):
            result.append(body_html[cursor:tag_start + 1])
            cursor = tag_start + 1
            continue

        script_boundary = tag_start + len('<script')
        if script_boundary < length and body_lower[script_boundary] not in _OPEN_TAG_BOUNDARY:
            result.append(body_html[cursor:tag_start + 1])
            cursor = tag_start + 1
            continue

        tag_end = _find_tag_end(body_html, tag_start)
        if tag_end == -1:
            result.append(body_html[cursor:])
            break

        result.append(body_html[cursor:tag_start])

        tag_text = body_html[tag_start:tag_end + 1]
        if _TYPE_ATTR_RE.search(tag_text):
            result.append(tag_text)
        else:
            result.append(_inject_type_attr(tag_text))

        cursor = tag_end + 1

        search_from = cursor
        closing_start = -1
        while True:
            closing_start = body_lower.find('</script', search_from)
            if closing_start == -1:
                break
            closing_boundary = closing_start + len('</script')
            if closing_boundary >= length or body_lower[closing_boundary] in _CLOSE_TAG_BOUNDARY:
                break
            search_from = closing_start + 1

        if closing_start == -1:
            result.append(body_html[cursor:])
            cursor = length
            break

        closing_end = body_lower.find('>', closing_start + len('</script'))
        if closing_end == -1:
            result.append(body_html[cursor:])
            cursor = length
            break

        result.append(body_html[cursor:closing_end + 1])
        cursor = closing_end + 1

    transformed_body = ''.join(result)
    return html_content[:body_tag_end + 1] + transformed_body + html_content[body_end:]
