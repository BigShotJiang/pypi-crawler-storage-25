from .string_helpers import camel_to_kebab
from .string_helpers import kebab_to_camel
from .string_helpers import has_mustache
import hashlib
import re
import uuid
import inspect
from collections import OrderedDict
from typing import Dict, List, Optional, Tuple, Iterator, NamedTuple
from .component_decorator import Component, load_component_from_path
import os


_GROUPED_IMPORT_RE = re.compile(
    r'<!--\s*@import\s*\{([^}]+)\}\s*from\s*["\']?([^"\'>\s]+)["\']?\s*-->'
)
_SINGLE_IMPORT_RE = re.compile(
    r'<!--\s*@import\s+(?!\{)(\w+)(?:\s+as\s+(\w+))?\s+from\s*["\']?([^"\'>\s]+)["\']?\s*-->'
)
_GROUPED_IMPORT_STRIP_RE = re.compile(
    r'<!--\s*@import\s*\{[^}]+\}\s*from\s*["\']?[^"\'>\s]+["\']?\s*-->\n?'
)
_SINGLE_IMPORT_STRIP_RE = re.compile(
    r'<!--\s*@import\s+\w+(?:\s+as\s+\w+)?\s+from\s*["\']?[^"\'>\s]+["\']?\s*-->\n?'
)
_TEMPLATE_BLOCK_RE = re.compile(r'<(/?)template\b[^>]*>')
_TEMPLATE_OWNER_ATTR_RE = re.compile(r'pp-owner="([^"]+)"')
_COMPONENT_CANDIDATE_RE = re.compile(r'<([A-Z][a-zA-Z0-9\.\_\-\:]*)')
_ROOT_COMPONENT_TAG_RE = re.compile(r'^(\s*<([a-zA-Z][\w:-]*))')
_PP_COMPONENT_ATTR_RE = re.compile(
    r'\s+pp-component\s*=\s*(?:"[^"]*"|\'[^\']*\'|[^\s>]+)',
    re.IGNORECASE,
)
_DYNAMIC_ATTR_VALUE_RE = re.compile(
    r'\s[\w:-]+\s*=\s*(?:"[^"]*\{[^}]+\}[^"]*"|\'[^\']*\{[^}]+\}[^\']*\'|\{[^}]+\})'
)
_POTENTIAL_COMPONENT_TAG_RE = re.compile(r'<[A-Z]')
_MAX_IMPORT_PARSE_CACHE = 256
_import_parse_cache: OrderedDict[str, Tuple[str,
                                            Tuple[Tuple[str, str, str], ...]]] = OrderedDict()


def _remember_import_parse(html: str, cleaned_html: str, imports: Tuple[Tuple[str, str, str], ...]) -> None:
    _import_parse_cache[html] = (cleaned_html, imports)
    _import_parse_cache.move_to_end(html)
    while len(_import_parse_cache) > _MAX_IMPORT_PARSE_CACHE:
        _import_parse_cache.popitem(last=False)


class UnknownComponentError(RuntimeError):
    """Raised when a template references a component tag that cannot be resolved."""


class TemplateRootError(RuntimeError):
    """Raised when a page or layout template does not have a single HTML root."""


def build_pp_component_key(scope: str, source_id: str) -> str:
    safe_scope = re.sub(r'[^a-z0-9]+', '_', scope.lower()
                        ).strip('_') or 'component'
    digest = hashlib.md5(str(source_id).encode('utf-8')).hexdigest()[:8]
    return f"{safe_scope}_{digest}"


def _format_template_label(template_kind: str, source_name: Optional[str]) -> str:
    label = (template_kind or 'template').strip() or 'template'
    if source_name:
        return f"{label} template '{source_name}'"
    return f"{label} template"


def _raise_template_root_error(
    template_kind: str,
    source_name: Optional[str],
    detail: str,
) -> None:
    label = _format_template_label(template_kind, source_name)
    raise TemplateRootError(
        f"{label} must have exactly one top-level HTML element so Caspian can inject pp-component. {detail}"
    )


def _skip_ignorable_top_level_nodes(html: str, start: int = 0) -> int:
    i = start
    n = len(html)

    while i < n:
        ch = html[i]

        if ch.isspace() or ch == '\ufeff':
            i += 1
            continue

        if html.startswith('<!--', i):
            end = html.find('-->', i)
            return n if end == -1 else _skip_ignorable_top_level_nodes(html, end + 3)

        if html.startswith('<!', i) or html.startswith('<?', i):
            end = html.find('>', i)
            return n if end == -1 else _skip_ignorable_top_level_nodes(html, end + 1)

        break

    return i


def _find_single_top_level_root(
    html: str,
    *,
    template_kind: str,
    source_name: Optional[str],
    control_mode: bool,
    allow_component_root: bool = False,
) -> Optional[TagToken]:
    def fail(detail: str) -> Optional[TagToken]:
        if control_mode:
            _raise_template_root_error(template_kind, source_name, detail)
        return None

    start = _skip_ignorable_top_level_nodes(html)
    if start >= len(html):
        return fail('Found no root element.')

    root_token: Optional[TagToken] = None
    for token in _iter_tag_tokens(html):
        if token.end <= start:
            continue

        if token.start > start and html[start:token.start].strip():
            return fail('Found non-element content before the root element.')

        if token.is_close:
            return fail('Found a closing tag before any root element.')

        root_token = token
        break

    if root_token is None:
        return fail('Found no root element.')

    if (
        not allow_component_root
        and (
            not root_token.name
            or not root_token.name[0].islower()
        )
    ):
        return fail(
            f"Found <{root_token.name}> as the root. The root must be a lowercase HTML element, not a component tag."
        )

    scan_html, _ = _mask_raw_blocks(html)

    if root_token.is_self:
        root_end = root_token.end
    else:
        close_start = _scan_closing_tag(
            scan_html, root_token.name, root_token.end)
        if close_start == -1:
            return fail(f"The root element <{root_token.name}> is not closed.")

        close_end = scan_html.find('>', close_start)
        if close_end == -1:
            return fail(f"The root element <{root_token.name}> is not closed.")

        root_end = close_end + 1

    trailing_start = _skip_ignorable_top_level_nodes(scan_html, root_end)
    if trailing_start < len(scan_html):
        return fail('Found sibling content after the root element.')

    return root_token


def inject_pp_component_root(
    html: str,
    unique_key: str,
    *,
    template_kind: str = 'template',
    source_name: Optional[str] = None,
    control_mode: bool = True,
) -> str:
    root_token = _find_single_top_level_root(
        html,
        template_kind=template_kind,
        source_name=source_name,
        control_mode=control_mode,
    )
    if root_token is None:
        return html

    open_tag = html[root_token.start:root_token.end]
    if 'pp-component' in open_tag:
        clean_open_tag = _PP_COMPONENT_ATTR_RE.sub('', open_tag, count=1)
    else:
        clean_open_tag = open_tag

    insert_at = 1 + len(root_token.name)
    injected_open_tag = (
        clean_open_tag[:insert_at]
        + f' pp-component="{unique_key}"'
        + clean_open_tag[insert_at:]
    )
    return html[:root_token.start] + injected_open_tag + html[root_token.end:]


def _has_single_top_level_component_root(
    html: str,
    *,
    template_kind: str,
    source_name: Optional[str],
) -> bool:
    root_token = _find_single_top_level_root(
        html,
        template_kind=template_kind,
        source_name=source_name,
        control_mode=False,
        allow_component_root=True,
    )
    return bool(root_token and root_token.name and root_token.name[0].isupper())


# ====
# TOKENIZER-FIRST PREPASS (Robust component + attribute handling)
# ====

class AttrToken(NamedTuple):
    name: str
    value: Optional[str]
    quote: Optional[str]


class TagToken(NamedTuple):
    name: str
    is_close: bool
    is_self: bool
    start: int
    end: int
    attrs: Tuple[AttrToken, ...]


# Allow dot in tag names so <item.icon> stays a single tag token.
# This prevents ".icon" being mis-parsed as an attribute.
_TAGNAME_CHARS = set("._-:")  # plus alnum


def _is_tagname_char(c: str) -> bool:
    return c.isalnum() or c in _TAGNAME_CHARS


def _escape_quotes_in_braced_attr_values(html: str) -> str:
    """Make JSX-like braced expressions inside quoted attributes HTML-safe.

    Example (invalid HTML):
        class="{isOpen ? "a" : "b"}"

    Becomes (valid HTML):
        class="{isOpen ? &quot;a&quot; : &quot;b&quot;}"
    """
    out: list[str] = []
    i = 0
    n = len(html)

    while i < n:
        # Detect: ="{...}" or ='{...}'
        if (
            html[i] == "="
            and i + 2 < n
            and html[i + 1] in ('"', "'")
            and html[i + 2] == "{"
        ):
            quote = html[i + 1]
            out.append("=")
            out.append(quote)

            k = i + 2
            brace_depth = 0
            in_str: Optional[str] = None
            esc = False
            expr_out: list[str] = []

            while k < n:
                c = html[k]

                # Escape the delimiter quote inside the braced expression
                if c == quote:
                    expr_out.append("&quot;" if quote == '"' else "&#39;")
                else:
                    expr_out.append(c)

                # Track JS-like strings; braces inside strings do not change brace_depth
                if esc:
                    esc = False
                else:
                    if in_str is not None:
                        if c == "\\":
                            esc = True
                        elif c == in_str:
                            in_str = None
                    else:
                        if c in ("'", '"'):
                            in_str = c
                        elif c == "{":
                            brace_depth += 1
                        elif c == "}":
                            brace_depth -= 1
                            if brace_depth == 0:
                                k += 1
                                break

                k += 1

            # Malformed input: fall back to raw remainder
            if brace_depth != 0:
                out.append(html[i + 2:])
                break

            out.append("".join(expr_out))

            # Keep closing quote if present
            if k < n and html[k] == quote:
                out.append(quote)
                k += 1

            i = k
            continue

        out.append(html[i])
        i += 1

    return "".join(out)


def _iter_tag_tokens(html: str) -> Iterator[TagToken]:
    """Tokenize tags in an HTML-like string without lowercasing.

    - Preserves tag name case (critical for JSX-style components).
    - Skips comments and doctypes.
    - Respects quotes inside tags so '>' in attributes won't terminate early.

    NOTE: Supports dots in tag names so patterns like <item.icon /> remain intact.
    """
    n = len(html)
    i = 0

    while i < n:
        lt = html.find('<', i)
        if lt == -1:
            return

        # Comment
        if html.startswith('<!--', lt):
            end = html.find('-->', lt)
            i = (end + 3) if end != -1 else n
            continue

        # Doctype / processing instruction / other declarations
        if html.startswith('<!', lt) or html.startswith('<?', lt):
            end = html.find('>', lt)
            i = (end + 1) if end != -1 else n
            continue

        # Closing tag
        if html.startswith('</', lt):
            j = lt + 2
            while j < n and _is_tagname_char(html[j]):
                j += 1
            name = html[lt + 2: j]
            end = html.find('>', j)
            if not name or end == -1:
                i = lt + 1
                continue
            yield TagToken(name=name, is_close=True, is_self=False, start=lt, end=end + 1, attrs=())
            i = end + 1
            continue

        # Opening / self-closing tag
        j = lt + 1
        if j >= n or not (html[j].isalpha() or html[j] in '_'):
            i = lt + 1
            continue

        while j < n and _is_tagname_char(html[j]):
            j += 1
        name = html[lt + 1: j]
        if not name:
            i = lt + 1
            continue

        # Parse until matching '>' respecting quotes
        in_dq = False
        in_sq = False
        k = j
        while k < n:
            c = html[k]
            if in_dq:
                if c == '"':
                    in_dq = False
            elif in_sq:
                if c == "'":
                    in_sq = False
            else:
                if c == '"':
                    in_dq = True
                elif c == "'":
                    in_sq = True
                elif c == '>':
                    raw_inside = html[j:k]
                    is_self = raw_inside.rstrip().endswith('/')
                    attrs_str = raw_inside[:-1] if is_self else raw_inside
                    attrs = tuple(_parse_attributes(attrs_str))
                    yield TagToken(name=name, is_close=False, is_self=is_self, start=lt, end=k + 1, attrs=attrs)
                    i = k + 1
                    break
            k += 1
        else:
            i = lt + 1


def _parse_attributes(attrs_str: str) -> List[AttrToken]:
    """Parse attributes from a tag's inside text (between tag name and '>').

    Supports:
      - key="value" / key='value'
      - key=value (unquoted)
      - boolean attrs: key
    """
    s = attrs_str
    n = len(s)
    i = 0
    out: List[AttrToken] = []

    while i < n:
        # Skip whitespace
        while i < n and s[i].isspace():
            i += 1
        if i >= n:
            break

        # Read attribute name
        start = i
        while i < n and not s[i].isspace() and s[i] not in ('=', '/', '>'):
            i += 1
        name = s[start:i]
        if not name:
            i += 1
            continue

        # Skip whitespace
        while i < n and s[i].isspace():
            i += 1

        # Boolean attribute
        if i >= n or s[i] != '=':
            out.append(AttrToken(name=name, value=None, quote=None))
            continue

        # '=' then value
        i += 1
        while i < n and s[i].isspace():
            i += 1
        if i >= n:
            out.append(AttrToken(name=name, value='', quote=None))
            break

        q = None
        if s[i] in ('"', "'"):
            q = s[i]
            i += 1
            v_start = i
            while i < n and s[i] != q:
                i += 1
            value = s[v_start:i]
            if i < n and s[i] == q:
                i += 1
            out.append(AttrToken(name=name, value=value, quote=q))
        else:
            v_start = i
            while i < n and not s[i].isspace() and s[i] not in ('>',):
                i += 1
            value = s[v_start:i]
            out.append(AttrToken(name=name, value=value, quote=None))

    return out


def _rebuild_open_tag(name: str, attrs: Tuple[AttrToken, ...], is_self: bool) -> str:
    parts = [f"<{name}"]

    for a in attrs:
        out_name = camel_to_kebab(a.name) if (
            a.value is not None and has_mustache(a.value)) else a.name

        if a.value is None:
            parts.append(out_name)
            continue

        if a.quote == '"':
            parts.append(f'{out_name}="{a.value}"')
        elif a.quote == "'":
            parts.append(f"{out_name}='{a.value}'")
        else:
            parts.append(f"{out_name}={a.value}")

    if is_self:
        return (parts[0] + (" " + " ".join(parts[1:]) if len(parts) > 1 else "") + " />")

    return (parts[0] + (" " + " ".join(parts[1:]) if len(parts) > 1 else "") + ">")


def _rewrite_dynamic_attr_names(html: str) -> str:
    tokens = list(_iter_tag_tokens(html))
    if not tokens:
        return html

    out = html
    for t in sorted(tokens, key=lambda x: x.start, reverse=True):
        if t.is_close:
            continue
        rebuilt = _rebuild_open_tag(t.name, t.attrs, t.is_self)
        out = out[: t.start] + rebuilt + out[t.end:]

    return out


# ====
# HELPER: Mustache & Attributes
# ====

def convert_mustache_attrs_to_kebab_raw(html: str) -> str:
    html = str(html)
    if '{' not in html or '=' not in html or _DYNAMIC_ATTR_VALUE_RE.search(html) is None:
        return html

    html = _escape_quotes_in_braced_attr_values(html)
    return _rewrite_dynamic_attr_names(html)


# ====
# IMPORT PARSING
# ====

def extract_imports(html: str) -> List[Dict]:
    imports = []

    for match in _GROUPED_IMPORT_RE.finditer(html):
        try:
            members = match.group(1)
            path = match.group(2)
        except IndexError:
            continue

        for member in members.split(','):
            member = member.strip()
            if not member:
                continue
            if ' as ' in member:
                parts = member.split(' as ')
                original = parts[0].strip()
                alias = parts[1].strip()
            else:
                original = member
                alias = member
            imports.append(
                {'original': original, 'alias': alias, 'path': path})

    for match in _SINGLE_IMPORT_RE.finditer(html):
        try:
            original = match.group(1)
            alias = match.group(2) or original
            path = match.group(3)
        except IndexError:
            continue
        imports.append({'original': original, 'alias': alias, 'path': path})

    return imports


def strip_imports(html: str) -> str:
    html = _GROUPED_IMPORT_STRIP_RE.sub('', html)
    html = _SINGLE_IMPORT_STRIP_RE.sub('', html)
    return html


def build_alias_map(imports: List[Dict], base_dir: str = "") -> Dict[str, Component]:
    alias_map: Dict[str, Component] = {}
    for imp in imports:
        if isinstance(imp, dict):
            original = imp['original']
            alias = imp['alias']
            path = imp['path']
        else:
            original, alias, path = imp

        comp = load_component_from_path(path, original, base_dir)
        if comp:
            alias_map[alias] = comp
    return alias_map


def _prepare_imports(html: str) -> Tuple[str, Tuple[Tuple[str, str, str], ...]]:
    cached = _import_parse_cache.get(html)
    if cached is not None:
        _import_parse_cache.move_to_end(html)
        return cached

    imports = tuple(
        (imp['original'], imp['alias'], imp['path'])
        for imp in extract_imports(html)
    )
    cleaned_html = strip_imports(html)
    _remember_import_parse(html, cleaned_html, imports)
    return cleaned_html, imports


def process_imports(html: str, base_dir: str = "") -> tuple[str, Dict[str, Component]]:
    if '@import' not in html:
        return html, {}

    cleaned_html, imports = _prepare_imports(html)
    alias_map = build_alias_map(imports, base_dir)
    return cleaned_html, alias_map


# ====
# COMPONENT HELPERS
# ====

def accepts_children(fn):
    if isinstance(fn, Component):
        return fn.accepts_children

    sig = inspect.signature(fn)
    params = sig.parameters
    return 'children' in params or any(p.kind == inspect.Parameter.VAR_KEYWORD for p in params.values())


def _get_root_tag_name(fragment: str) -> str:
    tag, _, _, _ = _scan_opening_tag(str(fragment).strip(), 0)
    return tag.lower() if tag else ""


def _find_owner_context(html: str, position: int) -> Optional[str]:
    """
    Check if position is inside a <template pp-owner="X"> block.
    Returns the owner ID if found, None otherwise.
    """
    owner_stack = []

    for match in _TEMPLATE_BLOCK_RE.finditer(html[:position]):
        tag = match.group(0)
        is_closing = match.group(1) == '/'

        if is_closing:
            if owner_stack:
                owner_stack.pop()
        else:
            owner_match = _TEMPLATE_OWNER_ATTR_RE.search(tag)
            if owner_match:
                owner_stack.append(owner_match.group(1))

    return owner_stack[-1] if owner_stack else None


def wrap_children_template(children_html: str, owner_scope: str) -> str:
    """
    Wrap projected children in a template that marks ownership explicitly.
    Runtime resolves scope/event ownership using pp-owner.
    """
    if not children_html:
        return ""

    stripped = str(children_html).strip()

    if not stripped:
        return ""

    # Don't re-wrap if children are already wrapped with pp-owner
    if stripped.startswith('<template pp-owner='):
        return children_html

    owner = owner_scope or "app"
    return f'<template pp-owner="{owner}">\n{children_html}\n</template>'


def _offset_to_line_col(source: str, offset: int) -> Tuple[int, int]:
    line = source.count("\n", 0, offset) + 1
    last_newline = source.rfind("\n", 0, offset)
    column = offset + 1 if last_newline == -1 else offset - last_newline
    return line, column


def _find_unknown_component_tag(html: str, alias_map: Dict[str, Component]) -> Optional[Tuple[str, int]]:
    if _POTENTIAL_COMPONENT_TAG_RE.search(html) is None:
        return None

    for token in _iter_tag_tokens(html):
        if token.is_close or not token.name:
            continue
        if not token.name[0].isupper():
            continue
        if token.name in alias_map:
            continue
        return token.name, token.start
    return None


def _build_unknown_component_message(name: str, html: str, offset: int, alias_map: Dict[str, Component]) -> str:
    line, column = _offset_to_line_col(html, offset)
    message = (
        f'Component "{name}" is not imported or does not exist '
        f'(line {line}, column {column}).'
    )
    if alias_map:
        available = ", ".join(sorted(alias_map))
        message += f" Imported components in this template: {available}."
    else:
        message += " No component imports were found in this template."
    message += " Add an @import comment for the component, or remove the tag if it is not a real component."
    return message


# ====
# ROBUST PARSING
# ====

def _scan_opening_tag(html: str, start_pos: int) -> Tuple[Optional[str], str, bool, int]:
    length = len(html)
    if start_pos >= length or html[start_pos] != '<':
        return None, "", False, start_pos

    i = start_pos + 1
    while i < length and _is_tagname_char(html[i]):
        i += 1

    tag_name = html[start_pos+1:i]
    if not tag_name:
        return None, "", False, start_pos

    in_dquote = False
    in_squote = False
    attrs_start = i

    while i < length:
        char = html[i]

        if in_dquote:
            if char == '"':
                in_dquote = False
        elif in_squote:
            if char == "'":
                in_squote = False
        else:
            if char == '"':
                in_dquote = True
            elif char == "'":
                in_squote = True
            elif char == '>':
                is_self_closing = (html[i-1] == '/')
                attrs_end = i - 1 if is_self_closing else i
                attrs_str = html[attrs_start:attrs_end]
                return tag_name, attrs_str, is_self_closing, i + 1
        i += 1

    return None, "", False, start_pos


def _scan_closing_tag(html: str, tag_name: str, start_pos: int) -> int:
    depth = 1
    length = len(html)
    i = start_pos

    target_close = f"</{tag_name}"
    target_open = f"<{tag_name}"

    while i < length:
        lt = html.find('<', i)
        if lt == -1:
            break

        if html.startswith(target_close, lt):
            after = lt + len(target_close)
            if after < length and html[after] in '> \t\n\r':
                depth -= 1
                if depth == 0:
                    return lt
                i = html.find('>', after) + 1
                continue

        if html.startswith(target_open, lt):
            after = lt + len(target_open)
            if after < length and html[after] in '> \t\n\r/':
                _, _, is_self, end_nested = _scan_opening_tag(html, lt)
                if not is_self:
                    depth += 1
                i = end_nested
                continue

        if html.startswith("<​!--", lt):
            end_comment = html.find("-->", lt)
            if end_comment != -1:
                i = end_comment + 3
                continue

        if lt + 1 < length and (html[lt+1].isalnum() or html[lt+1] == '/'):
            _, _, _, end_other = _scan_opening_tag(html, lt)
            i = end_other if end_other > lt else lt + 1
        else:
            i = lt + 1

    return -1


# ====
# RAW BLOCK PROTECTION
# ====

_RAW_TAGS_DEFAULT = ("script", "style")
_RAW_TAG_PATTERNS = {
    tag: re.compile(rf'<{tag}\b[^>]*>[\s\S]*?</{tag}\s*>', re.IGNORECASE)
    for tag in _RAW_TAGS_DEFAULT
}


def _mask_raw_blocks(html: str, tags: Tuple[str, ...] = _RAW_TAGS_DEFAULT) -> Tuple[str, List[Tuple[str, str]]]:
    lower_html = html.lower()
    if not any(f"<{tag}" in lower_html for tag in tags):
        return html, []

    blocks: List[Tuple[str, str]] = []
    for tag in tags:
        pattern = _RAW_TAG_PATTERNS.get(tag)
        if pattern is None:
            pattern = re.compile(
                rf'<{tag}\b[^>]*>[\s\S]*?</{tag}\s*>', re.IGNORECASE)

        def repl(m):
            token = f"__PP_RAW_{tag.upper()}_{uuid.uuid4().hex}__"
            blocks.append((token, m.group(0)))
            return token

        html = pattern.sub(repl, html)
    return html, blocks


def _unmask_raw_blocks(html: str, blocks: List[Tuple[str, str]]) -> str:
    for token, original in blocks:
        html = html.replace(token, original)
    return html


# ====
# MAIN TRANSFORM (now async to support async components)
# ====

async def transform_components(
    html: str,
    parent_scope: str = "app",
    base_dir: str = "",
    alias_map: Optional[Dict[str, Component]] = None,
    _depth: int = 0
) -> str:
    if _depth > 50:
        return html

    html = str(html)
    needs_attr_rewrite = (
        '{' in html
        and '=' in html
        and _DYNAMIC_ATTR_VALUE_RE.search(html) is not None
    )
    has_imports = '@import' in html
    has_component_candidates = _POTENTIAL_COMPONENT_TAG_RE.search(
        html) is not None

    if not alias_map and not has_imports and not has_component_candidates and not needs_attr_rewrite:
        return html

    html, raw_blocks = _mask_raw_blocks(html)

    html, local_alias_map = process_imports(html, base_dir)
    merged_map = {**(alias_map or {}), **local_alias_map}

    html = convert_mustache_attrs_to_kebab_raw(html)

    max_iterations = 100
    iteration = 0

    while merged_map and iteration < max_iterations:
        iteration += 1

        best_match = None
        for m in _COMPONENT_CANDIDATE_RE.finditer(html):
            name = m.group(1)
            if name in merged_map:
                best_match = m
                break

        if not best_match:
            break

        found_start = best_match.start()
        found_tag_name = best_match.group(1)
        component_fn = merged_map[found_tag_name]

        tag_name, attrs_str, is_self_closing, open_end = _scan_opening_tag(
            html, found_start)

        if not tag_name or tag_name != found_tag_name:
            html = html[:found_start] + "__SKIP__" + html[found_start+1:]
            continue

        children_html = ""
        full_end = open_end

        if not is_self_closing:
            close_start = _scan_closing_tag(html, tag_name, open_end)
            if close_start != -1:
                children_html = html[open_end:close_start]
                close_tag_end = html.find('>', close_start) + 1
                full_end = close_tag_end
            else:
                print(
                    f"[Caspian] Warning: Unclosed component <{tag_name}> found.")
                break

        attr_tokens = _parse_attributes(attrs_str)
        props: Dict[str, str] = {}

        for token in attr_tokens:
            camel = kebab_to_camel(token.name)
            if token.value is None:
                if camel not in props:
                    props[camel] = ""
            else:
                props[camel] = token.value

        unique_id = f"{tag_name.lower()}_{uuid.uuid4().hex[:8]}"

        # Handle children - React pattern with template ownership
        if children_html and accepts_children(component_fn):
            existing_owner = _find_owner_context(html, found_start)

            effective_owner = existing_owner if existing_owner else parent_scope

            props['children'] = wrap_children_template(
                children_html, effective_owner)

        try:
            # === ASYNC-AWARE COMPONENT CALL ===
            if isinstance(component_fn, Component) and component_fn.is_async:
                component_html = await component_fn.acall(**props)
            else:
                component_html = component_fn(**props)
        except Exception as e:
            print(f"[Caspian] Error rendering <{tag_name}>: {e}")
            break

        rendered_component_html = str(component_html).strip()
        wraps_component_root = _has_single_top_level_component_root(
            rendered_component_html,
            template_kind='component',
            source_name=getattr(component_fn, 'source_path', None) or tag_name,
        )

        if hasattr(component_fn, 'source_path') and component_fn.source_path:
            component_dir = os.path.dirname(component_fn.source_path)
            component_html = await transform_components(
                rendered_component_html,
                parent_scope=unique_id,
                base_dir=component_dir,
                alias_map=merged_map,
                _depth=_depth + 1
            )
        else:
            component_html = rendered_component_html

        if wraps_component_root:
            component_html = f"<div>{component_html}</div>"

        component_html = inject_pp_component_root(
            str(component_html).strip(),
            unique_id,
            template_kind='component',
            source_name=getattr(component_fn, 'source_path', None) or tag_name,
            control_mode=True,
        )

        html = html[:found_start] + str(component_html) + html[full_end:]

    unknown_component = _find_unknown_component_tag(html, merged_map)
    if unknown_component is not None:
        name, offset = unknown_component
        raise UnknownComponentError(
            _build_unknown_component_message(name, html, offset, merged_map)
        )

    html = html.replace("__SKIP__", "<")
    return _unmask_raw_blocks(html, raw_blocks)
