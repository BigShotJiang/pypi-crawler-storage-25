from orbitkit.util import UniversalExtractor
import os


def is_xbrl_structure(extract_path):
    """
    判断是否为 XBRL 结构（支持多层嵌套目录）。

    逻辑：
    1. 递归扫描目录，寻找同时包含 'META-INF' 和 'reports' 子文件夹的层级。
       如果找到 -> 返回 True 和该层级下的 reports 完整路径。
    2. 如果没找到结构，则兜底扫描所有文件内容，看是否有 XBRL 签名。
       如果找到 -> 返回 True 和 根路径。

    Args:
        extract_path (str): 解压后的根目录

    Returns:
        tuple: (bool, str)
               - is_xbrl: 是否判定为 XBRL
               - target_path: 如果是标准结构，返回 '.../reports'；
                              如果是普通结构，返回 extract_path；
                              如果不匹配，返回 None。
    """

    if not os.path.exists(extract_path):
        return False, None

    # --- 策略 1: 递归寻找标准 Report Package 结构 (META-INF + reports) ---
    for root, dirs, files in os.walk(extract_path):
        # dirs 是当前 root 下所有子文件夹的名字列表
        # 必须精确匹配文件夹名称（通常规范是 META-INF 和 reports）
        if 'META-INF' in dirs and 'reports' in dirs:
            reports_path = os.path.join(root, 'reports')
            return True, reports_path

    # --- 策略 2: 兜底内容检测 (防止是老式平铺结构) ---
    # 如果遍历完了都没发现那两个文件夹，说明不是标准包，或者是老版本
    # 这时候我们需要判断它到底是不是 XBRL，如果是，返回根目录

    XBRL_SIGNATURES = [
        # 传统 XBRL (Traditional XBRL)
        b'<xbrl',  # 根元素通常是 <xbrl>
        b'http://www.xbrl.org/2003/instance',  # 实例文档的核心 Namespace

        # 内嵌 XBRL (Inline XBRL / iXBRL - 通常是 HTML 格式)
        b'http://www.xbrl.org/2008/inlineXBRL',  # iXBRL 的核心 Namespace
        b'<ix:header',  # iXBRL 头部标签
        b'xmlns:ix=',  # 定义 ix 命名空间

        # 配套文件特征 (有些包可能只有 linkbase 或 xsd)
        b'http://www.xbrl.org/2003/linkbase',  # 链接库 Namespace
        b'http://xbrl.org/2006/xbrldi'  # 维度 Namespace
    ]

    target_extensions = ('.xml', '.xbrl', '.htm', '.html', '.xhtml')

    for root, dirs, files in os.walk(extract_path):
        for file in files:
            if file.lower().endswith(target_extensions):
                file_path = os.path.join(root, file)
                try:
                    with open(file_path, 'rb') as f:
                        # 只读头部 8KB
                        head = f.read(8192)
                        for sig in XBRL_SIGNATURES:
                            if sig in head:
                                # 发现了 XBRL 特征，但因为它没有 reports 文件夹结构
                                # 我们只能把整个解压目录交出去
                                return True, extract_path
                except:
                    continue

    return False, None


if __name__ == "__main__":

    souce_file_dir = "file_test"

    for file in os.listdir(souce_file_dir):
        print("\n***********************\n" + file)
        file_name = os.path.splitext(file)[0]
        full_path = os.path.join(souce_file_dir, file)

        """
        先尝试原始解压，因为很多报告的格式是 xbrl 格式
        ⚠️这里一定要保持目录结构解压
        """
        with UniversalExtractor() as extractor:
            result_path = extractor.extract(full_path, flatten=False,
                                            output_path=os.path.join("output_xbrl", file_name))  # 保持目录结构解压
            print(f"  -> 文件已解压到: {result_path}")

            # === 核心变化在这里 ===
            is_xbrl, reports_path = is_xbrl_structure(result_path)

            """
            ⚠️如果是 xbrl 格式的话，能得到重要报告的路径位置！
            """
            if is_xbrl:
                print('  -> ✅ 这是 XBRL 格式的附件')
                # 这里如果是 xbrl 格式，则提取出重要文件（XHTML / HTML 格式）

                # 如果是标准结构，reports_path 结尾是 'reports'，你可以只处理这里面的 HTML
                print(reports_path)
                if reports_path.endswith('reports'):
                    print("  -> 仅提取 reports 文件夹下的内容")
                    for report in os.listdir(reports_path):
                        file_path = os.path.join(reports_path, report)
                        print(f"     - 处理文件: {report}")
                        # 这里可以添加你的处理逻辑，比如解析 HTML 文件等
                else:
                    print("  -> 策略: 非标准结构，需扫描整个目录提取")
                    # 遍历 reports_path (即 result_path) 处理文件...

                # 成功识别，跳过后续的打平解压
                continue

        # 到这里说明不是 xbrl 格式，则继续打平解压
        print("  -> ❌ 这不是 XBRL 格式的附件，文件名：", file)
        # with UniversalExtractor() as extractor:
        #     result_path = extractor.extract(full_path, flatten=True, output_path=output_path)  # 打平目录结构
        #     print(f"  -> 文件已解压到: {result_path}")
