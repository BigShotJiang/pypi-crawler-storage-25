'''
    @author  : xiaoyu.ma
    @date    : 2025/8/6
    @explain : MinerU PDF 解析工具 - 完整版（API + 解析 + 任务处理）
    @version : 3.0

    功能:
    - MinerUApiBase: API 基础类（上传、查询、下载）
    - MinerUExtract: 解析 layout.json 文件
    - MinerUSingleTask: 单文件完整处理（支持大文件自动拆分）
    - MinerUBatchTask: 批量文件处理

    限制（超限自动拆分）:
    - 单文件 ≤ 200MB
    - 页数 ≤ 600 页
    - 批量上传 ≤ 200 个文件

    使用示例见: mineru_demo.py

    @changelog:
    - v3.2 (2026/2/2): image_detail 格式改为对象数组，上传 S3 时添加 ContentType
    - v3.1 (2026/2/2): 添加 version_checker 回调，支持 API 版本兼容性检查
    - v3.0 (2026/2/2): 合并 mineru_task_v1.py，单文件即可使用
    - v2.0 (2025/1/30): 重构 API 调用逻辑
    - v1.5 (2025/1/30): 支持 vlm 模型的多种 block 类型
    - v1.0 (2025/8/6): 初始版本
'''
import os
import json
import time
import zipfile
import tempfile
import shutil
import mimetypes
import requests
from typing import List, Tuple, Dict, Any, Optional
from urllib.parse import urlparse
from orbitkit import id_srv


# ==================== API 基础类 ====================

class MinerUApiBase:
    """
    MinerU API 基础类

    API 文档: https://mineru.net/doc/docs/

    限制:
    - 单个文件大小不能超过 200MB
    - 文件页数不超出 600 页
    - 单次批量上传不超过 200 个文件
    """

    BASE_URL = "https://mineru.net/api/v4"
    MAX_FILE_SIZE_MB = 200  # 最大文件大小 MB
    MAX_PAGES = 200  # 最大页数（MinerU 服务端硬限制）
    SPLIT_PAGES = 150  # 拆分时每个分片的页数（留 10% 余量避免边界踩限）
    MAX_BATCH_FILES = 200  # 单次批量上传最大文件数

    def __init__(self, api_token: str, temp_dir: str = None):
        """
        初始化 MinerU API 客户端

        :param api_token: MinerU API Token (从 https://mineru.net 获取)
        :param temp_dir: 临时文件目录，默认使用系统临时目录
        """
        self.api_token = api_token
        self.headers = {
            "Authorization": f"Bearer {api_token}",
            "Content-Type": "application/json"
        }
        self.temp_dir = temp_dir or tempfile.mkdtemp(prefix="mineru_")
        os.makedirs(self.temp_dir, exist_ok=True)

    def get_pdf_page_count(self, pdf_path: str) -> int:
        """获取 PDF 页数"""
        try:
            from pypdf import PdfReader
            reader = PdfReader(pdf_path)
            return len(reader.pages)
        except ImportError:
            try:
                from PyPDF2 import PdfReader
                reader = PdfReader(pdf_path)
                return len(reader.pages)
            except ImportError:
                raise Exception("请安装 pypdf 或 PyPDF2: pip install pypdf")

    def split_pdf(self, pdf_path: str, total_pages: int) -> List[Tuple[str, int, int]]:
        """
        拆分 PDF 文件

        :param pdf_path: PDF 文件路径
        :param total_pages: 总页数
        :return: [(split_file_path, start_page, end_page), ...]
        """
        try:
            from pypdf import PdfReader, PdfWriter
        except ImportError:
            from PyPDF2 import PdfReader, PdfWriter

        reader = PdfReader(pdf_path)
        split_files = []
        split_dir = os.path.join(self.temp_dir, "splits")
        os.makedirs(split_dir, exist_ok=True)

        base_name = os.path.splitext(os.path.basename(pdf_path))[0]

        for i in range(0, total_pages, self.SPLIT_PAGES):
            start_page = i + 1  # 1-based
            end_page = min(i + self.SPLIT_PAGES, total_pages)

            writer = PdfWriter()
            for page_idx in range(i, end_page):
                writer.add_page(reader.pages[page_idx])

            split_path = os.path.join(split_dir, f"{base_name}_part{len(split_files):03d}.pdf")
            with open(split_path, "wb") as f:
                writer.write(f)

            split_files.append((split_path, start_page, end_page))
            print(f"  生成分片: {os.path.basename(split_path)} (页码 {start_page}-{end_page})")

        return split_files

    def check_file_limits(self, pdf_path: str) -> Tuple[bool, int, float]:
        """
        检查文件是否超出限制

        :param pdf_path: PDF 文件路径
        :return: (need_split, page_count, file_size_mb)
        """
        file_size_mb = os.path.getsize(pdf_path) / (1024 * 1024)
        page_count = self.get_pdf_page_count(pdf_path)
        need_split = file_size_mb > self.MAX_FILE_SIZE_MB or page_count > self.MAX_PAGES
        return need_split, page_count, file_size_mb

    def request_upload_urls(self, file_names: List[str], enable_formula: bool = True,
                            enable_table: bool = True, is_ocr: bool = True,
                            model_version: str = "vlm") -> Tuple[str, List[str]]:
        """
        请求文件上传 URL

        :param file_names: 文件名列表
        :param enable_formula: 是否启用公式识别
        :param enable_table: 是否启用表格识别
        :param is_ocr: 是否启用 OCR
        :param model_version: 模型版本 (pipeline/vlm/MinerU-HTML)
        :return: (batch_id, upload_urls)
        """
        url = f"{self.BASE_URL}/file-urls/batch"
        payload = {
            "files": [{"name": name} for name in file_names],
            "enable_formula": enable_formula,
            "enable_table": enable_table,
            "is_ocr": is_ocr,
            "model_version": model_version
        }

        response = requests.post(url, headers=self.headers, json=payload)

        if response.status_code != 200:
            raise Exception(f"请求上传 URL 失败: HTTP {response.status_code}, {response.text}")

        result = response.json()
        if result.get("code") != 0:
            raise Exception(f"请求上传 URL 失败: {result.get('msg', 'Unknown error')}")

        data = result.get("data", {})
        batch_id = data.get("batch_id")
        file_urls = data.get("file_urls", [])

        if not batch_id or not file_urls:
            raise Exception(f"请求上传 URL 失败: {result}")

        return batch_id, file_urls

    def upload_file(self, pdf_path: str, presigned_url: str):
        """
        上传文件到预签名 URL

        :param pdf_path: 本地文件路径
        :param presigned_url: 预签名上传 URL
        """
        with open(pdf_path, 'rb') as f:
            response = requests.put(presigned_url, data=f)

        if response.status_code not in [200, 201]:
            raise Exception(f"上传文件失败: HTTP {response.status_code}, {response.text}")

    def query_batch_status(self, batch_id: str) -> Dict[str, Any]:
        """
        查询批量任务状态

        :param batch_id: 批量任务 ID
        :return: 批量任务状态数据
        """
        url = f"{self.BASE_URL}/extract-results/batch/{batch_id}"
        response = requests.get(url, headers=self.headers)

        if response.status_code != 200:
            raise Exception(f"查询批量任务状态失败: HTTP {response.status_code}, {response.text}")

        result = response.json()
        if result.get("code") != 0:
            raise Exception(f"查询批量任务状态失败: {result.get('msg', 'Unknown error')}")

        return result.get("data", {})

    def download_and_extract_zip(self, zip_url: str, extract_dir: str):
        """
        下载并解压 ZIP 文件

        :param zip_url: ZIP 下载 URL
        :param extract_dir: 解压目录
        """
        os.makedirs(extract_dir, exist_ok=True)
        zip_path = os.path.join(extract_dir, "result.zip")

        print(f"  下载: {zip_url[:60]}...")
        response = requests.get(zip_url, stream=True)
        response.raise_for_status()

        with open(zip_path, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)

        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(extract_dir)

    def find_layout_json(self, directory: str) -> Optional[str]:
        """在目录中查找 layout.json 文件"""
        for root, dirs, files in os.walk(directory):
            if "layout.json" in files:
                return os.path.join(root, "layout.json")
        return None

    @staticmethod
    def cleanup_unused_images(output_dir: str, all_blocks: list):
        """清理 output_dir/images 中未被 blocks 引用的图片，避免上传冗余文件到 S3"""
        images_dir = os.path.join(output_dir, "images")
        if not os.path.exists(images_dir):
            return

        # 从 blocks 中收集所有被引用的图片文件名
        used_images = set()
        for block in all_blocks:
            for img in block.get("image_detail", []):
                path = img.get("path", "")
                if path.startswith("images/"):
                    used_images.add(os.path.basename(path))

        # 删除未被引用的图片
        for img_file in os.listdir(images_dir):
            if img_file not in used_images:
                img_path = os.path.join(images_dir, img_file)
                if os.path.isfile(img_path):
                    os.remove(img_path)
                    print(f"  清理未引用图片: {img_file}")

    def upload_directory_to_s3(self, s3_client, bucket: str, prefix: str, local_dir: str):
        """将本地目录上传到 S3"""
        for root, dirs, files in os.walk(local_dir):
            for file in files:
                local_path = os.path.join(root, file)
                relative_path = os.path.relpath(local_path, local_dir)
                s3_key = f"{prefix}/{relative_path}"

                # 获取 ContentType
                content_type, _ = mimetypes.guess_type(file)
                if content_type is None:
                    content_type = 'application/octet-stream'
                # txt 文件使用 UTF-8 编码
                if content_type == 'text/plain':
                    content_type = 'text/plain; charset=utf-8'

                print(f"  上传: {relative_path} -> s3://{bucket}/{s3_key}")
                s3_client.upload_file(
                    local_path, bucket, s3_key,
                    ExtraArgs={'ContentType': content_type}
                )


# ==================== 解析器类 ====================

class MinerUExtract:
    """
    MinerU 解析结果提取器 - 解析 layout.json 文件
    """
    page_required = ['page_size', 'page_idx']
    page_extractable_values = ["para_blocks", 'discarded_blocks']
    page_chemical = ['layout_bboxes', '_layout_tree', 'images', 'tables', 'interline_equations', 'need_drop', 'drop_reason', 'preproc_blocks']
    page_default = []

    def __init__(self, output_folder, file_path):
        self.blocks = []
        self.pages = []
        self.page_default.extend(self.page_required)
        self.page_default.extend(self.page_extractable_values)
        self.page_default.extend(self.page_chemical)
        self.output_folder = output_folder
        with open(file_path, 'r', encoding='utf-8') as file:
            self.layout_data = json.load(file)

    def extract_process(self):
        pdf_info = self.layout_data['pdf_info']
        for pdf_pages in pdf_info:
            self.extract_pages(pdf_pages)

        minerU_reg_file = os.path.join(self.output_folder, 'minerU_reg.txt')
        with open(minerU_reg_file, "w+", encoding='utf-8') as u_pages:
            u_pages.write(json.dumps({
                "_backend": self.layout_data.get('_backend', ''),
                "_version_name": self.layout_data.get('_version_name', '')
            }, ensure_ascii=False) + "\n")

        blocks_file = os.path.join(self.output_folder, 'blocks.txt')
        pages_file = os.path.join(self.output_folder, 'pages.txt')
        with open(pages_file, "w+", encoding='utf-8') as f_pages:
            for page in self.pages:
                f_pages.write(json.dumps(page, ensure_ascii=False) + "\n")

        with open(blocks_file, "w+", encoding='utf-8') as f_blocks:
            for block in self.blocks:
                f_blocks.write(json.dumps(block, ensure_ascii=False) + "\n")

    def check_page_params(self, pdf_pages):
        for pk in pdf_pages.keys():
            if pk not in self.page_default:
                raise Exception(f'参数配置异常，意外参数:{pk}')

    def extract_pages(self, pdf_pages):
        self.check_page_params(pdf_pages)
        self.page_size = pdf_pages['page_size']
        self.page = pdf_pages['page_idx'] + 1
        pages_body = self.extract_blocks(pdf_pages)
        self.pages.append({
            'id': id_srv.get_random_short_id(),
            'page': self.page,
            'sentence': '\n\n'.join(pages_body) + '\n\n' if len(pages_body) > 0 else ''
        })

    def extract_blocks(self, pdf_pages):
        pages_body = []
        block_seq = 0
        for block_method in self.page_extractable_values:
            if block_method in self.page_chemical:
                continue
            handler = getattr(self, block_method, "default_blocks")
            pages_body = handler(pdf_pages, pages_body, block_seq)
        return pages_body

    def preproc_blocks(self, pdf_pages, pages_body, block_seq):
        return self.default_extractable(pdf_pages, 'preproc_blocks', pages_body, block_seq)

    def para_blocks(self, pdf_pages, pages_body, block_seq):
        return self.default_extractable(pdf_pages, 'para_blocks', pages_body, block_seq)

    def discarded_blocks(self, pdf_pages, pages_body, block_seq):
        return self.default_extractable(pdf_pages, 'discarded_blocks', pages_body, block_seq)

    def default_blocks(self, pdf_pages):
        raise Exception(f'提取block方法异常，未知参数: {list(pdf_pages.keys())}')

    def default_extractable(self, pdf_pages, block_key, pages_body, block_seq):
        for pages_block in pdf_pages.get(block_key, []):
            handler_type_func = getattr(self, f'level_two_{pages_block["type"]}', self.level_two_default_blocks)
            block_seq, pages_body = handler_type_func(block_seq, pages_block, pages_body)
        return pages_body

    def get_location(self, bbox):
        location = [bbox[0], self.page_size[1] - bbox[1], bbox[2], self.page_size[1] - bbox[3]]
        return {"location": [location]}

    def level_two_text(self, block_seq, pages_block, pages_body):
        return self.level_two_txt_com(block_seq, pages_block, pages_body, 'sentence')

    def level_two_discarded(self, block_seq, pages_block, pages_body):
        return self.level_two_txt_com(block_seq, pages_block, pages_body, 'sentence')

    def level_two_title(self, block_seq, pages_block, pages_body):
        return self.level_two_txt_com(block_seq, pages_block, pages_body, 'title')

    def level_two_list(self, block_seq, pages_block, pages_body):
        """处理 list 类型 block（支持 pipeline 和 vlm 两种格式）"""
        block_type = 'sentence'
        if 'blocks' in pages_block:
            list_blocks = pages_block['blocks']
            for sub_block in list_blocks:
                if 'lines' in sub_block:
                    block_seq = block_seq + 1
                    bbox = sub_block['bbox']
                    text_location = self.get_location(bbox)
                    pages_lines = sub_block["lines"]
                    _block_arr, _image_detail_arr = self.get_com_lines(pages_lines)
                    if len(_block_arr) > 0 or len(_image_detail_arr) > 0:
                        _block_str = '\n'.join(_block_arr)
                        self.blocks.append({
                            "id": id_srv.get_random_short_id(),
                            "page": self.page,
                            "seq_no": block_seq,
                            "sentence": _block_str,
                            "type": block_type,
                            "image_detail": _image_detail_arr,
                            "text_location": text_location
                        })
                        pages_body.append(_block_str)
                    else:
                        if block_seq > 0:
                            block_seq = block_seq - 1
            return block_seq, pages_body
        return self.level_two_txt_com(block_seq, pages_block, pages_body, block_type)

    def level_two_index(self, block_seq, pages_block, pages_body):
        return self.level_two_txt_com(block_seq, pages_block, pages_body, 'sentence')

    def level_two_header(self, block_seq, pages_block, pages_body):
        return self.level_two_txt_com(block_seq, pages_block, pages_body, 'title')

    def level_two_footer(self, block_seq, pages_block, pages_body):
        return self.level_two_txt_com(block_seq, pages_block, pages_body, 'sentence')

    def level_two_page_number(self, block_seq, pages_block, pages_body):
        return block_seq, pages_body

    def level_two_aside_text(self, block_seq, pages_block, pages_body):
        return self.level_two_txt_com(block_seq, pages_block, pages_body, 'sentence')

    def level_two_footnote(self, block_seq, pages_block, pages_body):
        return self.level_two_txt_com(block_seq, pages_block, pages_body, 'sentence')

    def level_two_reference(self, block_seq, pages_block, pages_body):
        return self.level_two_txt_com(block_seq, pages_block, pages_body, 'sentence')

    def level_two_ref_text(self, block_seq, pages_block, pages_body):
        return self.level_two_txt_com(block_seq, pages_block, pages_body, 'sentence')

    def level_two_equation(self, block_seq, pages_block, pages_body):
        return self.level_two_txt_com(block_seq, pages_block, pages_body, 'sentence')

    def level_two_page_footnote(self, block_seq, pages_block, pages_body):
        return self.level_two_txt_com(block_seq, pages_block, pages_body, 'sentence')

    def level_two_caption(self, block_seq, pages_block, pages_body):
        return self.level_two_txt_com(block_seq, pages_block, pages_body, 'sentence')

    def level_two_abstract(self, block_seq, pages_block, pages_body):
        return self.level_two_txt_com(block_seq, pages_block, pages_body, 'sentence')

    def level_two_code(self, block_seq, pages_block, pages_body):
        return self.level_two_txt_com(block_seq, pages_block, pages_body, 'sentence')

    def level_two_table(self, block_seq, pages_block, pages_body):
        """处理 table 类型 block，sentence 直接存储 HTML 格式，脚注等文本单独生成 block（各自保留 bbox）"""
        table_blocks = pages_block.get('blocks', [])
        table_html = ""
        table_bbox = pages_block.get('bbox', [0, 0, 0, 0])
        _image_detail_arr = []
        # 收集非 table 类型的子 block（如 table_footnote, table_caption 等），保留各自的 bbox
        text_blocks = []

        for sub_block in table_blocks:
            sub_bbox = sub_block.get('bbox', table_bbox)
            pages_lines = sub_block.get("lines", [])
            for _line in pages_lines:
                for _span in _line.get('spans', []):
                    span_type = _span.get('type', '')
                    if span_type == 'table' and 'html' in _span:
                        table_html = _span['html']
                    elif 'content' in _span:  # table_footnote, table_caption 等文本类型
                        text_blocks.append({
                            'content': _span['content'],
                            'bbox': sub_bbox
                        })
                    if _span.get('image_path'):
                        _image_detail_arr.append({"path": f'images/{_span["image_path"]}', "desc": ""})

        # 当表格已有 HTML 内容时，不再需要图片（HTML 已完整表达表格结构和数据），丢弃 image_detail 以避免冗余
        if table_html:
            _image_detail_arr = []

        # 表格 HTML 单独一个 block
        if table_html or _image_detail_arr:
            block_seq = block_seq + 1
            text_location = self.get_location(table_bbox)
            self.blocks.append({
                "id": id_srv.get_random_short_id(),
                "page": self.page,
                "seq_no": block_seq,
                "sentence": table_html,
                "type": 'table',
                "image_detail": _image_detail_arr,
                "text_location": text_location
            })
            pages_body.append(table_html)

        # 每个脚注/标题等文本单独一个 block，使用各自的 bbox
        for text_block in text_blocks:
            block_seq = block_seq + 1
            text_location = self.get_location(text_block['bbox'])
            self.blocks.append({
                "id": id_srv.get_random_short_id(),
                "page": self.page,
                "seq_no": block_seq,
                "sentence": text_block['content'],
                "type": 'sentence',
                "image_detail": [],
                "text_location": text_location
            })
            pages_body.append(text_block['content'])

        return block_seq, pages_body

    def level_two_image(self, block_seq, pages_block, pages_body):
        pages_image_blocks = pages_block["blocks"]
        for _pages_image_blocks in pages_image_blocks:
            block_seq = block_seq + 1
            _pages_image_blocks_type = _pages_image_blocks['type']
            pages_image_blocks_line = _pages_image_blocks["lines"]
            bbox = pages_block['bbox']
            if _pages_image_blocks_type == 'image_body':
                block_type = 'image'
            elif _pages_image_blocks_type in ['image_caption', 'image_footnote']:
                block_type = 'sentence'
            else:
                raise Exception(f'Image 异常目标值 {_pages_image_blocks_type}:')
            text_location = self.get_location(bbox)
            _block_arr, _image_detail_arr = self.get_com_lines(pages_image_blocks_line)
            if len(_block_arr) > 0 or len(_image_detail_arr) > 0:
                _block_arr_str = '\n'.join(_block_arr)
                self.blocks.append({
                    "id": id_srv.get_random_short_id(),
                    "page": self.page,
                    "seq_no": block_seq,
                    "sentence": _block_arr_str,
                    "type": block_type,
                    "image_detail": _image_detail_arr,
                    "text_location": text_location
                })
            else:
                if block_seq > 0:
                    block_seq = block_seq - 1
        return block_seq, pages_body

    def level_two_chart(self, block_seq, pages_block, pages_body):
        pages_chart_blocks = pages_block["blocks"]
        for _pages_chart_blocks in pages_chart_blocks:
            block_seq = block_seq + 1
            _pages_chart_blocks_type = _pages_chart_blocks['type']
            pages_chart_blocks_line = _pages_chart_blocks["lines"]
            bbox = pages_block['bbox']
            if _pages_chart_blocks_type == 'chart_body':
                block_type = 'chart'
            elif _pages_chart_blocks_type in ['chart_caption', 'chart_footnote']:
                block_type = 'sentence'
            else:
                raise Exception(f'Chart 异常目标值 {_pages_chart_blocks_type}:')
            text_location = self.get_location(bbox)
            _block_arr, _image_detail_arr = self.get_com_lines(pages_chart_blocks_line)
            if len(_block_arr) > 0 or len(_image_detail_arr) > 0:
                _block_arr_str = '\n'.join(_block_arr)
                self.blocks.append({
                    "id": id_srv.get_random_short_id(),
                    "page": self.page,
                    "seq_no": block_seq,
                    "sentence": _block_arr_str,
                    "type": block_type,
                    "image_detail": _image_detail_arr,
                    "text_location": text_location
                })
            else:
                if block_seq > 0:
                    block_seq = block_seq - 1
        return block_seq, pages_body

    def level_two_interline_equation(self, block_seq, pages_block, pages_body):
        block_seq = block_seq + 1
        bbox = pages_block['bbox']
        text_location = self.get_location(bbox)
        pages_lines = pages_block["lines"]
        _block_arr, _image_detail_arr = self.get_com_lines(pages_lines)
        if len(_block_arr) > 0 or len(_image_detail_arr) > 0:
            _block_str = '\n'.join(_block_arr)
            self.blocks.append({
                "id": id_srv.get_random_short_id(),
                "page": self.page,
                "seq_no": block_seq,
                "sentence": _block_str,
                "type": 'equation',
                "image_detail": _image_detail_arr,
                "text_location": text_location
            })
            pages_body.append(_block_str)
        else:
            if block_seq > 0:
                block_seq = block_seq - 1
        return block_seq, pages_body

    def level_two_txt_com(self, block_seq, pages_block, pages_body, block_type):
        block_seq = block_seq + 1
        bbox = pages_block['bbox']
        text_location = self.get_location(bbox)
        pages_lines = pages_block["lines"]
        _block_arr, _image_detail_arr = self.get_com_lines(pages_lines)
        if len(_block_arr) > 0 or len(_image_detail_arr) > 0:
            _block_str = '\n'.join(_block_arr)
            self.blocks.append({
                "id": id_srv.get_random_short_id(),
                "page": self.page,
                "seq_no": block_seq,
                "sentence": _block_str,
                "type": block_type,
                "image_detail": _image_detail_arr,
                "text_location": text_location
            })
            pages_body.append(_block_str)
        else:
            if block_seq > 0:
                block_seq = block_seq - 1
        return block_seq, pages_body

    def level_two_default_blocks(self, block_seq, pages_block, pages_body):
        raise Exception(f'提取block方法异常，未知类型: {pages_block.get("type")}，参数: {list(pages_block.keys())}')

    def get_com_lines(self, pages_lines):
        _block_arr = []
        _img = []
        for _line in pages_lines:
            _c_s = []
            for _l in _line['spans']:
                if _l['type'] in ['text', 'title', 'inline_equation', 'interline_equation']:
                    _c_s.append(_l['content'])
                elif _l['type'] in ['table']:
                    _c_s.append(_l['html'])
                elif _l['type'] in ['image', 'chart']:
                    pass
                else:
                    raise Exception(f'类型匹配异常 意外值: {_l["type"]}')
                if _l.get('image_path', None):
                    _img.append({"path": f'images/{_l["image_path"]}', "desc": ""})
            if len(_c_s) > 0:
                _block_arr.append(' '.join(_c_s))
        return _block_arr, _img


# ==================== 单文件处理类 ====================

class MinerUSingleTask(MinerUApiBase):
    """
    MinerU 单文件处理类（推荐使用）

    特性:
    - 自动检测文件大小和页数
    - 超限自动拆分（>200MB 或 >600页）
    - 完整的三步流程
    - 版本检查回调（可选）

    使用方式:
        def check_version(version_info):
            # version_info = {"_backend": "hybrid", "_version_name": "2.7.3"}
            if version_info.get("_version_name") != "2.7.3":
                raise Exception(f"不支持的版本: {version_info}")

        client = MinerUSingleTask(api_token, version_checker=check_version)
        tasks = client.submit_task("test.pdf")
        results = client.wait_for_complete(tasks)
        output = client.download_and_process(results, "s3://bucket/path.pdf", s3_client)
    """

    def __init__(self, api_token: str, temp_dir: str = None, version_checker: callable = None):
        """
        初始化 MinerU 单文件处理客户端

        :param api_token: MinerU API Token
        :param temp_dir: 临时文件目录
        :param version_checker: 版本检查回调函数，签名: (version_info: dict) -> None
                               version_info 格式: {"_backend": "hybrid", "_version_name": "2.7.3"}
                               如果版本不兼容，应抛出异常
        """
        super().__init__(api_token, temp_dir)
        self.version_checker = version_checker

    def submit_task(self, pdf_path: str, model_version: str = "vlm",
                    is_ocr: bool = True, enable_formula: bool = True,
                    enable_table: bool = True) -> List[Dict[str, Any]]:
        """
        第一步：上传文件（系统自动创建任务）

        :param pdf_path: PDF 文件本地路径
        :param model_version: 模型版本 "pipeline" | "vlm" | "MinerU-HTML"
        :return: 任务列表 [{"batch_id", "filename", "seq_no", "start_page", "end_page", "total_pages"}, ...]
        """
        if not os.path.exists(pdf_path):
            raise Exception(f"PDF 文件不存在: {pdf_path}")

        need_split, page_count, file_size_mb = self.check_file_limits(pdf_path)
        print(f"PDF 信息: 大小={file_size_mb:.2f}MB, 页数={page_count}")

        if not need_split:
            print("文件符合限制，无需拆分")
            batch_id, filename = self._upload_file(pdf_path, model_version, is_ocr, enable_formula, enable_table)
            return [{
                "batch_id": batch_id,
                "filename": filename,
                "seq_no": 0,
                "start_page": 1,
                "end_page": page_count,
                "total_pages": page_count
            }]

        print(f"文件超限，进行拆分（每片最多 {self.SPLIT_PAGES} 页）")
        split_files = self.split_pdf(pdf_path, page_count)

        tasks = []
        for seq_no, (split_path, start_page, end_page) in enumerate(split_files):
            print(f"上传分片 {seq_no}: 页码 {start_page}-{end_page}")
            batch_id, filename = self._upload_file(split_path, model_version, is_ocr, enable_formula, enable_table)
            tasks.append({
                "batch_id": batch_id,
                "filename": filename,
                "seq_no": seq_no,
                "start_page": start_page,
                "end_page": end_page,
                "total_pages": page_count
            })

        print(f"共上传 {len(tasks)} 个文件")
        return tasks

    def _upload_file(self, pdf_path: str, model_version: str, is_ocr: bool,
                     enable_formula: bool, enable_table: bool) -> tuple:
        """上传文件，返回 (batch_id, filename)"""
        filename = os.path.basename(pdf_path)
        print(f"  请求上传 URL: {filename}")
        batch_id, upload_urls = self.request_upload_urls(
            [filename], enable_formula, enable_table, is_ocr, model_version
        )
        presigned_url = upload_urls[0]

        print(f"  上传文件: {filename}")
        self.upload_file(pdf_path, presigned_url)
        print(f"  上传完成: batch_id={batch_id}")
        return batch_id, filename

    def wait_for_complete(self, tasks: List[Dict[str, Any]], timeout: int = 1800,
                          poll_interval: int = 5) -> List[Dict[str, Any]]:
        """第二步：等待所有任务完成"""
        results = []
        start_time = time.time()

        for task in tasks:
            batch_id = task["batch_id"]
            filename = task["filename"]
            seq_no = task["seq_no"]

            print(f"\n等待任务 {seq_no} (batch_id={batch_id})...")

            elapsed = time.time() - start_time
            remaining_timeout = max(timeout - elapsed, 60)

            result = self._wait_batch_task(batch_id, filename, remaining_timeout, poll_interval)
            results.append({**task, "result": result})
            print(f"任务 {seq_no} 完成: state={result.get('state')}")

        print(f"\n所有 {len(results)} 个任务已完成")
        return results

    def _wait_batch_task(self, batch_id: str, filename: str, timeout: int, poll_interval: int) -> Dict[str, Any]:
        """通过 batch API 等待单个任务完成"""
        start_time = time.time()

        while True:
            elapsed = time.time() - start_time
            if elapsed > timeout:
                raise Exception(f"任务超时: batch_id={batch_id}")

            data = self.query_batch_status(batch_id)
            extract_results = data.get("extract_result", [])

            for r in extract_results:
                if r.get("file_name") == filename or len(extract_results) == 1:
                    state = r.get("state", "")
                    if state == "done":
                        return r
                    elif state == "failed":
                        raise Exception(f"任务执行失败: batch_id={batch_id}, err_msg={r.get('err_msg')}")
                    else:
                        print(f"  任务进行中: state={state}, elapsed={elapsed:.1f}s")
                    break
            else:
                print(f"  等待中... elapsed={elapsed:.1f}s")

            time.sleep(poll_interval)

    def download_and_process(self, task_results: List[Dict[str, Any]], s3_input_path: str,
                              s3_client, keep_all_files: bool = True) -> str:
        """第三步：下载所有结果、合并并上传到 S3"""
        parsed = urlparse(s3_input_path)
        bucket, key = parsed.netloc, parsed.path.lstrip('/')
        target_prefix = f"txt-vector/{key}"

        work_dir = os.path.join(self.temp_dir, "work")
        output_dir = os.path.join(self.temp_dir, "output")
        os.makedirs(work_dir, exist_ok=True)
        os.makedirs(output_dir, exist_ok=True)
        os.makedirs(os.path.join(output_dir, "images"), exist_ok=True)

        task_results = sorted(task_results, key=lambda x: x["seq_no"])
        all_blocks, all_pages, mineru_reg = [], [], None
        version_checked = False

        for task_result in task_results:
            seq_no, start_page = task_result["seq_no"], task_result["start_page"]
            full_zip_url = task_result["result"].get("full_zip_url")
            if not full_zip_url:
                raise Exception(f"任务 {seq_no} 缺少 full_zip_url")

            print(f"\n处理分片 {seq_no} (页码 {start_page}-{task_result['end_page']})...")

            extract_dir = os.path.join(work_dir, f"part_{seq_no:03d}")
            self.download_and_extract_zip(full_zip_url, extract_dir)

            # 版本检查：在第一个分片下载后立即检查
            if not version_checked and self.version_checker:
                layout_json_path = self.find_layout_json(extract_dir)
                if layout_json_path:
                    version_info = self._extract_version_info(layout_json_path)
                    print(f"版本检查: {version_info}")
                    self.version_checker(version_info)  # 如果不兼容，应抛出异常
                    version_checked = True

            if keep_all_files:
                self._copy_zip_files(extract_dir, output_dir, seq_no)

            layout_json_path = self.find_layout_json(extract_dir)
            if not layout_json_path:
                raise Exception(f"分片 {seq_no} 中未找到 layout.json")

            part_output = os.path.join(work_dir, f"parsed_{seq_no:03d}")
            os.makedirs(part_output, exist_ok=True)
            MinerUExtract(output_folder=part_output, file_path=layout_json_path).extract_process()

            page_offset = start_page - 1
            self._merge_results(part_output, all_blocks, all_pages, page_offset)

            if mineru_reg is None:
                reg_file = os.path.join(part_output, "minerU_reg.txt")
                if os.path.exists(reg_file):
                    with open(reg_file, 'r', encoding='utf-8') as f:
                        mineru_reg = f.read()

            self._copy_images(os.path.dirname(layout_json_path), output_dir)

        self._write_output_files(output_dir, all_blocks, all_pages, mineru_reg)
        self.cleanup_unused_images(output_dir, all_blocks)

        print(f"\n上传到 S3: s3://{bucket}/{target_prefix}/")
        self.upload_directory_to_s3(s3_client, bucket, target_prefix, output_dir)
        return f"s3://{bucket}/{target_prefix}"

    def _merge_results(self, part_output: str, all_blocks: list, all_pages: list, page_offset: int):
        for filename, target in [("blocks.txt", all_blocks), ("pages.txt", all_pages)]:
            filepath = os.path.join(part_output, filename)
            if os.path.exists(filepath):
                with open(filepath, 'r', encoding='utf-8') as f:
                    for line in f:
                        if line.strip():
                            data = json.loads(line)
                            data["page"] = data["page"] + page_offset
                            target.append(data)

    def _copy_images(self, layout_dir: str, output_dir: str):
        images_src = os.path.join(layout_dir, "images")
        images_dst = os.path.join(output_dir, "images")
        if os.path.exists(images_src):
            for img_file in os.listdir(images_src):
                src, dst = os.path.join(images_src, img_file), os.path.join(images_dst, img_file)
                if os.path.isfile(src) and not os.path.exists(dst):
                    shutil.copy2(src, dst)

    def _write_output_files(self, output_dir: str, all_blocks: list, all_pages: list, mineru_reg: str):
        print("\n写入合并后的文件...")
        with open(os.path.join(output_dir, "blocks.txt"), 'w', encoding='utf-8') as f:
            for block in all_blocks:
                f.write(json.dumps(block, ensure_ascii=False) + "\n")
        with open(os.path.join(output_dir, "pages.txt"), 'w', encoding='utf-8') as f:
            for page in all_pages:
                f.write(json.dumps(page, ensure_ascii=False) + "\n")
        if mineru_reg:
            with open(os.path.join(output_dir, "minerU_reg.txt"), 'w', encoding='utf-8') as f:
                f.write(mineru_reg)

    def _extract_version_info(self, layout_json_path: str) -> Dict[str, Any]:
        """从 layout.json 中提取版本信息"""
        with open(layout_json_path, 'r', encoding='utf-8') as f:
            layout_data = json.load(f)
        return {
            "_backend": layout_data.get("_backend", ""),
            "_version_name": layout_data.get("_version_name", "")
        }

    def _copy_zip_files(self, extract_dir: str, output_dir: str, part_idx: int):
        """复制 ZIP 中的所有文件（除原始 PDF 和 result.zip）到输出目录"""
        for root, dirs, files in os.walk(extract_dir):
            for file in files:
                if file.lower().endswith('.pdf') or file.lower() == 'result.zip':
                    continue
                src_path = os.path.join(root, file)
                relative_path = os.path.relpath(src_path, extract_dir)

                if part_idx > 0 and file in ['layout.json', 'middle.json', 'model.json', 'content_list.json']:
                    base, ext = os.path.splitext(file)
                    relative_path = os.path.join(os.path.dirname(relative_path), f"{base}_part{part_idx:03d}{ext}")

                dst_path = os.path.join(output_dir, relative_path)
                os.makedirs(os.path.dirname(dst_path), exist_ok=True)
                if not os.path.exists(dst_path):
                    shutil.copy2(src_path, dst_path)


# ==================== 批量处理类 ====================

class MinerUBatchTask(MinerUApiBase):
    """
    MinerU 批量文件处理类

    适用场景: 一次处理多个 PDF 文件

    使用方式:
        def check_version(version_info):
            if version_info.get("_version_name") != "2.7.3":
                raise Exception(f"不支持的版本: {version_info}")

        client = MinerUBatchTask(api_token, version_checker=check_version)
        batch = client.submit_batch([
            {"local_path": "a.pdf", "s3_output_path": "s3://bucket/a.pdf"},
            {"local_path": "b.pdf", "s3_output_path": "s3://bucket/b.pdf"},
        ])
        batch = client.wait_for_batch_complete(batch)
        outputs = client.download_and_process_batch(batch, s3_client)
    """

    def __init__(self, api_token: str, temp_dir: str = None, version_checker: callable = None):
        """
        初始化 MinerU 批量处理客户端

        :param api_token: MinerU API Token
        :param temp_dir: 临时文件目录
        :param version_checker: 版本检查回调函数，签名: (version_info: dict) -> None
        """
        super().__init__(api_token, temp_dir)
        self.version_checker = version_checker
        self._version_checked = False

    def submit_batch(self, pdf_files: List[Dict[str, Any]], enable_formula: bool = True,
                     enable_table: bool = True, is_ocr: bool = True,
                     model_version: str = "vlm") -> Dict[str, Any]:
        """第一步：批量上传文件"""
        if len(pdf_files) > self.MAX_BATCH_FILES:
            raise Exception(f"文件数超过限制: {len(pdf_files)} > {self.MAX_BATCH_FILES}")

        file_infos = []
        for file_item in pdf_files:
            local_path, s3_output_path = file_item["local_path"], file_item["s3_output_path"]
            if not os.path.exists(local_path):
                raise Exception(f"PDF 文件不存在: {local_path}")

            need_split, page_count, file_size_mb = self.check_file_limits(local_path)
            print(f"检查文件: {os.path.basename(local_path)} - {file_size_mb:.2f}MB, {page_count}页")

            if need_split:
                print(f"  文件需要拆分（每片最多 {self.SPLIT_PAGES} 页）")
                split_files = self.split_pdf(local_path, page_count)
                parts = [{"split_path": sp, "start_page": start, "end_page": end}
                         for sp, start, end in split_files]
            else:
                parts = [{"split_path": local_path, "start_page": 1, "end_page": page_count}]

            file_infos.append({
                "local_path": local_path,
                "s3_output_path": s3_output_path,
                "need_split": need_split,
                "total_pages": page_count,
                "parts": parts
            })

        upload_files, file_names = [], []
        for idx, fi in enumerate(file_infos):
            for part_idx, part in enumerate(fi["parts"]):
                upload_files.append((part["split_path"], idx, part_idx))
                file_names.append(os.path.basename(part["split_path"]))

        if len(upload_files) > self.MAX_BATCH_FILES:
            raise Exception(f"拆分后文件数超过限制: {len(upload_files)} > {self.MAX_BATCH_FILES}")

        print(f"\n准备上传 {len(upload_files)} 个文件...")
        batch_id, upload_urls = self.request_upload_urls(
            file_names, enable_formula, enable_table, is_ocr, model_version
        )
        print(f"获得 batch_id: {batch_id}")

        for i, ((file_path, file_idx, part_idx), presigned_url) in enumerate(zip(upload_files, upload_urls)):
            print(f"上传 [{i+1}/{len(upload_files)}]: {os.path.basename(file_path)}")
            self.upload_file(file_path, presigned_url)
            file_infos[file_idx]["parts"][part_idx]["filename"] = os.path.basename(file_path)

        print(f"\n所有 {len(upload_files)} 个文件上传完成")
        return {"batch_id": batch_id, "file_infos": file_infos}

    def wait_for_batch_complete(self, batch_result: Dict[str, Any], timeout: int = 3600,
                                 poll_interval: int = 10) -> Dict[str, Any]:
        """第二步：等待批量任务完成"""
        batch_id = batch_result["batch_id"]
        start_time = time.time()
        print(f"\n等待批量任务完成 (batch_id={batch_id})...")

        expected_count = sum(len(fi["parts"]) for fi in batch_result["file_infos"])

        while True:
            elapsed = time.time() - start_time
            if elapsed > timeout:
                raise Exception(f"批量任务超时: batch_id={batch_id}")

            data = self.query_batch_status(batch_id)
            extract_results = data.get("extract_result", [])

            done = sum(1 for r in extract_results if r.get("state") == "done")
            failed = sum(1 for r in extract_results if r.get("state") == "failed")
            pending = expected_count - done - failed

            print(f"  进度: {done}/{expected_count} 完成, {failed} 失败, {pending} 进行中 (elapsed={elapsed:.1f}s)")

            if done + failed >= expected_count:
                if failed > 0:
                    failed_files = [r.get("file_name") for r in extract_results if r.get("state") == "failed"]
                    print(f"警告: {failed} 个文件处理失败: {failed_files}")

                for result in extract_results:
                    result_filename = result.get("file_name", "")
                    for fi in batch_result["file_infos"]:
                        for part in fi["parts"]:
                            if part.get("filename") == result_filename:
                                part["result"] = result
                                break

                print(f"\n批量任务完成: {done} 成功, {failed} 失败")
                return batch_result

            time.sleep(poll_interval)

    def download_and_process_batch(self, batch_result: Dict[str, Any], s3_client,
                                    keep_all_files: bool = True) -> List[str]:
        """第三步：下载所有结果、合并并上传到 S3"""
        output_paths = []
        for file_idx, file_info in enumerate(batch_result["file_infos"]):
            filename = os.path.basename(file_info["local_path"])
            print(f"\n处理文件 [{file_idx + 1}/{len(batch_result['file_infos'])}]: {filename}")
            try:
                output_path = self._process_single_file(file_info, s3_client, keep_all_files)
                output_paths.append(output_path)
                print(f"  输出: {output_path}/")
            except Exception as e:
                print(f"  处理失败: {e}")
                output_paths.append(None)
        return output_paths

    def _process_single_file(self, file_info: Dict[str, Any], s3_client, keep_all_files: bool) -> str:
        """处理单个文件（可能包含多个分片）"""
        parsed = urlparse(file_info["s3_output_path"])
        bucket, key = parsed.netloc, parsed.path.lstrip('/')
        target_prefix = f"txt-vector/{key}"

        work_dir = os.path.join(self.temp_dir, f"work_{id(file_info)}")
        output_dir = os.path.join(self.temp_dir, f"output_{id(file_info)}")
        os.makedirs(work_dir, exist_ok=True)
        os.makedirs(output_dir, exist_ok=True)
        os.makedirs(os.path.join(output_dir, "images"), exist_ok=True)

        parts = sorted(file_info["parts"], key=lambda x: x["start_page"])
        all_blocks, all_pages, mineru_reg = [], [], None

        for part_idx, part in enumerate(parts):
            result = part.get("result", {})
            if result.get("state") != "done":
                print(f"    跳过失败分片 {part_idx}: state={result.get('state')}")
                continue

            full_zip_url = result.get("full_zip_url")
            if not full_zip_url:
                print(f"    跳过分片 {part_idx}: 无 full_zip_url")
                continue

            start_page, end_page = part["start_page"], part["end_page"]
            print(f"    处理分片 {part_idx}: 页码 {start_page}-{end_page}")

            extract_dir = os.path.join(work_dir, f"part_{part_idx:03d}")
            self.download_and_extract_zip(full_zip_url, extract_dir)

            # 版本检查：在第一个分片下载后立即检查（整个批处理只检查一次）
            if not self._version_checked and self.version_checker:
                layout_json_path = self.find_layout_json(extract_dir)
                if layout_json_path:
                    version_info = self._extract_version_info(layout_json_path)
                    print(f"    版本检查: {version_info}")
                    self.version_checker(version_info)  # 如果不兼容，应抛出异常
                    self._version_checked = True

            if keep_all_files:
                self._copy_zip_files(extract_dir, output_dir, part_idx)

            layout_json_path = self.find_layout_json(extract_dir)
            if not layout_json_path:
                print(f"    警告: 分片 {part_idx} 未找到 layout.json")
                continue

            part_output = os.path.join(work_dir, f"parsed_{part_idx:03d}")
            os.makedirs(part_output, exist_ok=True)
            MinerUExtract(output_folder=part_output, file_path=layout_json_path).extract_process()

            page_offset = start_page - 1
            for filename, target in [("blocks.txt", all_blocks), ("pages.txt", all_pages)]:
                filepath = os.path.join(part_output, filename)
                if os.path.exists(filepath):
                    with open(filepath, 'r', encoding='utf-8') as f:
                        for line in f:
                            if line.strip():
                                data = json.loads(line)
                                data["page"] = data["page"] + page_offset
                                target.append(data)

            if mineru_reg is None:
                reg_file = os.path.join(part_output, "minerU_reg.txt")
                if os.path.exists(reg_file):
                    with open(reg_file, 'r', encoding='utf-8') as f:
                        mineru_reg = f.read()

            images_src = os.path.join(os.path.dirname(layout_json_path), "images")
            images_dst = os.path.join(output_dir, "images")
            if os.path.exists(images_src):
                for img in os.listdir(images_src):
                    src, dst = os.path.join(images_src, img), os.path.join(images_dst, img)
                    if os.path.isfile(src) and not os.path.exists(dst):
                        shutil.copy2(src, dst)

        with open(os.path.join(output_dir, "blocks.txt"), 'w', encoding='utf-8') as f:
            for block in all_blocks:
                f.write(json.dumps(block, ensure_ascii=False) + "\n")
        with open(os.path.join(output_dir, "pages.txt"), 'w', encoding='utf-8') as f:
            for page in all_pages:
                f.write(json.dumps(page, ensure_ascii=False) + "\n")
        if mineru_reg:
            with open(os.path.join(output_dir, "minerU_reg.txt"), 'w', encoding='utf-8') as f:
                f.write(mineru_reg)

        self.cleanup_unused_images(output_dir, all_blocks)

        print(f"    上传到 S3: s3://{bucket}/{target_prefix}/")
        self.upload_directory_to_s3(s3_client, bucket, target_prefix, output_dir)

        shutil.rmtree(work_dir, ignore_errors=True)
        shutil.rmtree(output_dir, ignore_errors=True)
        return f"s3://{bucket}/{target_prefix}"

    def _extract_version_info(self, layout_json_path: str) -> Dict[str, Any]:
        """从 layout.json 中提取版本信息"""
        with open(layout_json_path, 'r', encoding='utf-8') as f:
            layout_data = json.load(f)
        return {
            "_backend": layout_data.get("_backend", ""),
            "_version_name": layout_data.get("_version_name", "")
        }

    def _copy_zip_files(self, extract_dir: str, output_dir: str, part_idx: int):
        """复制 ZIP 中的所有文件（除原始 PDF 和 result.zip）到输出目录"""
        for root, dirs, files in os.walk(extract_dir):
            for file in files:
                if file.lower().endswith('.pdf') or file.lower() == 'result.zip':
                    continue
                src_path = os.path.join(root, file)
                relative_path = os.path.relpath(src_path, extract_dir)

                if part_idx > 0 and file in ['layout.json', 'middle.json', 'model.json', 'content_list.json']:
                    base, ext = os.path.splitext(file)
                    relative_path = os.path.join(os.path.dirname(relative_path), f"{base}_part{part_idx:03d}{ext}")

                dst_path = os.path.join(output_dir, relative_path)
                os.makedirs(os.path.dirname(dst_path), exist_ok=True)
                if not os.path.exists(dst_path):
                    shutil.copy2(src_path, dst_path)
