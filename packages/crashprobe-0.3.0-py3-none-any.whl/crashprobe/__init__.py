import sys
import traceback
from datetime import datetime
import platform
import linecache
import html
from pathlib import Path
import webbrowser as web
import os


class Crashprobe:
    def __init__(self):
        self.last_frame = None
        self.error_frame = None
        self.local_var_list = []
        self.code_lines = []
        self.code = None
        self.local_var_str = None
        self.file_text = None
        self.value_of_error = None
        self.error_line = None
        self.path = None
        self.auto_open = None
        self.file_format = None
        self.hide_secrets = []

    def _excepthook(self, auto_open, file_format, hide_secrets):
        sys.excepthook = self._error_catching
        self.hide_secrets = hide_secrets
        if auto_open == True or auto_open == False:
            self.auto_open = auto_open
        else:
            raise ValueError(
                f"Invalid value for 'auto_open': '{auto_open}', crashprobe.start() expected True or False."
            )
        if file_format.upper() == "HTML" or file_format.upper() == "TXT":
            self.file_format = file_format
        else:
            raise ValueError(
                f"Invalid value for 'file_format': '{file_format}', crashprobe.start() expected 'html' or 'txt' (case-insensitive)."
            )

    def _error_catching(self, name, value, tb):
        try:
            print(
                f"Crashprobe caught an error type: {str(name.__name__)}, value: {value}."
            )
            self.last_frame = tb
            self.value_of_error = value
            while self.last_frame.tb_next:
                self.last_frame = self.last_frame.tb_next
            self.error_frame = self.last_frame.tb_frame
            self.error_line = self.last_frame.tb_lineno
            self.path = self.error_frame.f_code.co_filename
            if self.file_format.upper() == "HTML":
                for num in range(-2, 3, 1):
                    if self.error_line + num != self.error_line - num:
                        self.code_lines.append(
                            html.escape(
                                f"{self.error_line + num}|{linecache.getline(self.path, self.error_line + num)}"
                            )
                        )
                    if num == 0:
                        self.code_lines.append(
                            '<div class="errorStr">'
                            + html.escape(
                                f"{self.error_line + num}|{linecache.getline(self.path, self.error_line + num)}"
                            )
                            + "</div>"
                        )
                for key, val in self.error_frame.f_locals.items():
                    if (
                        not key.startswith("__")
                        and not callable(val)
                        and str(type(val)) != "<class 'module'>"
                    ):
                        if key in self.hide_secrets:
                            self.local_var_list.append(
                                html.escape(
                                    f"{key} = <hidden> #type: {type(val).__name__}"
                                )
                            )
                        else:
                            self.local_var_list.append(
                                html.escape(
                                    f"{key} = {val} #type: {type(val).__name__}"
                                )
                            )
                self.local_var_str = ("<br>").join(self.local_var_list)
                self.code = ("<br>").join(self.code_lines)
            if self.file_format.upper() == "TXT":
                for num in range(-2, 3, 1):
                    if self.error_line + num != self.error_line - num:
                        self.code_lines.append(
                            f"{self.error_line + num}|{linecache.getline(self.path, self.error_line + num)}"
                        )
                    if num == 0:
                        self.code_lines.append(
                            f"{self.error_line + num}|{linecache.getline(self.path, self.error_line + num)}"
                        )
                for key, val in self.error_frame.f_locals.items():
                    if (
                        not key.startswith("__")
                        and not callable(val)
                        and str(type(val)) != "<class 'module'>"
                    ):
                        if key in self.hide_secrets:
                            self.local_var_list.append(
                                f"{key} = <hidden> #type: {type(val).__name__}"
                            )
                        else:
                            self.local_var_list.append(
                                f"{key} = {val} #type: {type(val).__name__}"
                            )
                self.local_var_str = ("\n").join(self.local_var_list)
                self.code = ("\n").join(self.code_lines)
            if self.file_format.upper() == "HTML":
                self.__generate_html(
                    str(name.__name__),
                    str(self.value_of_error),
                    self.local_var_str,
                    self.path,
                    self.code,
                )
            elif self.file_format.upper() == "TXT":
                self.__generate_txt(
                    str(name.__name__),
                    str(self.value_of_error),
                    self.local_var_str,
                    self.path,
                    self.code,
                )
        except Exception as e:
            print(f"Crashprobe internal error: {e}")
            sys.__excepthook__(name, value, tb)

    def __generate_html(self, name, value, local_var, path, code):
        basename = os.path.basename(path)
        crash_dir = Path(path).parent / f"{basename}_crash_dir"
        crash_dir.mkdir(exist_ok=True)
        crash_file = (
            crash_dir / f"crash_{datetime.now().strftime('%Y-%m-%d_%H-%M-%S')}.html"
        )
        with open(crash_file, "w", encoding="utf-8") as file:
            self.html_text = """<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<style>
		body{
			background-color: #0d0d0d;
			color: #e0e0e0;
			font-family: "Segoe UI";
		}
			.block {
           	 	background: #161b22;
              		margin-bottom: 20px;
			padding: 5px;
		        border-radius: 10px;
			margin-left: 20px 
             	}
			.error {
			font-size: 55px; 
			margin-bottom: 20px;
			
		}
			.standart {
			font-size: 25px; 
			margin-bottom: 20px;
		}
			.code {
			font-size: 14px; 
			margin-bottom: 20px;
		}
			.errorStr {
			font-size: 14px; 
			background: #ff5050;
		}
			.button {
			font-size: 19px;
           	 	background: #161b22;
			color: #e0e0e0;
              		margin-bottom: 20px;
			padding: 5px;
		        border-radius: 10px;
			margin-left: 20px 
		}

	</style>
	<title>CRASH</title>
</head>"""
            self.html_text += f"""<body>
	<div class="error">🐛Error: {name}: {value}</div>
	<div class="standart">🕒Date time: {datetime.now()}</div>
	<div class="standart">📂Path:</div>
	<div class="block"><pre class="code">{path}</pre></div>
	<div class="standart">📂Code:</div>
	<div class="block">
		<div class="code"><pre><code>{code}</code></pre></div>
	</div>"""
            if local_var != "":
                self.html_text += f"""       <div class="standart">📋Local variables:</div>
	<div class="block">
	        <div class="code"><pre class="code">{local_var}</pre></div>
	</div>"""
            self.html_text += f"""        <div class="standart">🖥System:</div>
	<div class="block"><pre class="code">Python: {sys.version}<br>OS: <br>    {platform.system()}<br>    release: {platform.release()}<br>    version: {platform.version()}<br>Hostname: {platform.node()}</pre></div>
	<div class="standart">🌐Links:</div>
	<div class="block">
		<a class="standart" href="https://www.google.com/search?q=python+error+{name}%20{value.replace(" ", "%20")}">🔍 Google: {name} {value}<br></a>
		<a class="standart" href="https://docs.python.org/3/library/exceptions.html#{name}">📖 Python docs: {name}</a>
	</div>
	<button class="button" onclick="copy()">📌Click to copy</button>"""

            self.html_text += """	<script>
		function copy(){
                        var text = document.body.innerText;
			text = text.replace("📌Click to copy", "");"""
            self.html_text += f"""			text = text.replace("🔍 Google: {name} {value}", "🔍 Google: https://www.google.com/search?q=python+error+{name}%20{value.replace(" ", "%20")}");
			text = text.replace("📖 Python docs: {name}", "📖 Python docs: https://docs.python.org/3/library/exceptions.html#{name}");
			navigator.clipboard.writeText(text);"""
            self.html_text += """                        }
	</script>
</body>
</html>"""
            file.write(self.html_text)
            print(f"Html saved at {crash_file}!")
            if self.auto_open:
                web.open(crash_file)

    def __generate_txt(self, name, value, local_var, path, code):
        basename = os.path.basename(path)
        crash_dir = Path(path).parent / f"{basename}_crash_dir"
        crash_dir.mkdir(exist_ok=True)
        crash_file = (
            crash_dir / f"crash_{datetime.now().strftime('%Y-%m-%d_%H-%M-%S')}.txt"
        )
        with open(crash_file, "w", encoding="utf-8") as file:
            self.txt_text = f"""Error: {name}: {value}
_____________________________________________________________________
Date time: {datetime.now()}
_____________________________________________________________________
Path:{path}
_____________________________________________________________________
Code:
{code}"""
            if local_var != "":
                self.txt_text += f"""\n_____________________________________________________________________
Local variables:
{local_var}"""
            self.txt_text += f"""\n_____________________________________________________________________
System:
    Python: {sys.version}
    OS:
        {platform.system()}
        release: {platform.release()}
        version: {platform.version()}
    Hostname: {platform.node()}
_____________________________________________________________________
Links:
    Google: https://www.google.com/search?q=python+error+{name}%20{value.replace(" ", "%20")}
    Python docs: https://docs.python.org/3/library/exceptions.html#{name}"""
            file.write(self.txt_text)
            print(f"TXT saved at {crash_file}!")
            if self.auto_open:
                print(
                    "\n======================================================================\n",
                    self.txt_text,
                )


def start(auto_open=True, file_format="HTML", hide_secrets=[]):
    Crashprobe()._excepthook(auto_open, file_format, hide_secrets)


def stop():
    sys.excepthook = sys.__excepthook__
