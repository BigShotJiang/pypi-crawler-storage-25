---
mode: agent
description: Show "where am I?" — current phase, last activity, and the next action.
---

The user wants to pick up where they left off.

## Steps

1. Run from the integrated terminal: `sdlc resume`
2. The CLI prints:
   - 📍 Project name + overall progress (% + items count)
   - ⏳ Currently pending item (with stage if it's a Phase 3 task)
   - 🕐 Last agent activity with relative timestamp
   - ✋ Open clarifications (if any)
   - 🔒 Pending gates (if any)
   - **Next steps** — the recommended action (resolve clarification first / approve gate / run `sdlc-next` prompt / etc.)
3. Echo the output to the user verbatim. Do not paraphrase — the formatting is meaningful.
4. Highlight any actionable items and offer to invoke the related prompt:
   - Open clarification → suggest opening the file
   - Pending gate → tell the user how to approve (write `automation/signoffs/<id>.yaml` with `approved: true`)
   - Clean state → suggest the `sdlc-next` prompt
