---
mode: agent
description: Scaffold an SDLC project (auto-detects stack from package.json / pyproject.toml / go.mod).
---

The user wants to initialize the SDLC framework in the current working directory.

## Steps

1. Run from the integrated terminal: `sdlc init`
   - If the user passed an argument like `--stack=node` or `--force`, append it.
2. Read the command output verbatim and report:
   - Auto-detected stack (or "no stack detected").
   - Number of files copied vs skipped.
   - Whether `.github/workflows/ci.yml` was wired.
3. If 0 files were copied AND `--force` was not used, suggest:
   - "Looks already initialized. Run the `sdlc-scan` prompt to check progress, or `sdlc init --force` from the terminal to overwrite."
4. Otherwise, suggest the next step:
   - "Run the `sdlc-start` prompt with your project idea to begin Phase 1."

## Notes

- The `sdlc` CLI is the engine; this prompt is a thin wrapper.
- The scaffold is non-destructive: existing files are skipped unless `--force`.
