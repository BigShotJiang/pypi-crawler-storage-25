---
mode: agent
description: Open the bundled SDLC dashboard on localhost.
---

The user wants to view the SDLC dashboard in their browser.

## Steps

1. Run from the integrated terminal, in background: `sdlc dashboard --port 8765 &`
   - This starts a long-running HTTP server. Do NOT block the chat on it.
2. Tell the user: "Dashboard is now serving at http://localhost:8765/dashboard/. Open it in your browser. Run `sdlc scan` periodically (or rely on the in-agent auto-refresh) to keep state fresh."
3. Do NOT auto-open the browser unless the user asks.
4. To stop the server later, the user runs: `pkill -f 'sdlc.*dashboard'`. Mention this only if asked.

## Pre-requisite

If `automation/state.json` does not exist yet, the dashboard will be empty. Suggest running `sdlc scan` first to populate it.
