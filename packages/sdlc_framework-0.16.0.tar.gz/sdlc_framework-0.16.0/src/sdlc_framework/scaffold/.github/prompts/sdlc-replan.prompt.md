---
mode: agent
description: Mark downstream DoD items dirty after a major change (requirements, UI/UX, tech stack, scale).
---

The user has made or is about to make a major change and wants downstream items re-evaluated.

## Steps

1. Run from the integrated terminal: `sdlc replan` (with whatever flags the user provided, or interactively).
2. The CLI is interactive when no `--scope` is given — it asks the user to pick one of:
   - `requirements` — functional requirements / user stories changed
   - `ui-ux` — UI/UX scope or screens changed
   - `tech-stack` — language / framework / runtime changed
   - `scale-nfr` — RPS / latency / SLO targets changed
   - `custom` — user lists item ids manually
   - `clear` — drop all dirty markers (after the work has been redone)
3. After the user picks a scope, the CLI:
   - Marks downstream items dirty in `automation/.replan.json`
   - Writes an audit clarification under `automation/clarifications/replan-<ts>.md`
   - Forces the engine to show those items as ✗ until `sdlc replan --clear`
4. Suggest next steps:
   - "Run the `sdlc-scan` prompt to see the new state."
   - "When the work has been redone, run `sdlc replan --clear` to drop the markers."

## Non-interactive

If the user provides `--scope` and `--reason` already, pass them through directly and skip the prompt.
