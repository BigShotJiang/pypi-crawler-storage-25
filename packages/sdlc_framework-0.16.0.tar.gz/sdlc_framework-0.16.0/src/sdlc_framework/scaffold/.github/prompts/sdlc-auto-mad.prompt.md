---
mode: agent
description: MAD MODE autopilot — auto-signs phase gates and auto-verifies artifacts. Stops only on clarifications, high-risk paths, PR review, or errors. NOT for production.
---

⚠️  **MAD MODE — opt-in YOLO autopilot.** Use for prototypes / hackathons. The AI auto-signs Phase 1/2/4/5 signoffs and auto-verifies drafted artifacts. Do NOT use this when you want a human in the loop.

## How it differs from `sdlc-auto`

| Stop reason       | `sdlc-auto`        | `sdlc-auto-mad`                  |
| ----------------- | ------------------ | -------------------------------- |
| `verify_needed`   | stop               | **auto-verify** (`ai-mad-mode`)  |
| `gate`            | stop               | **auto-sign** (`ai-mad-mode`)    |
| `clarification`   | stop               | stop                             |
| `high_risk`       | stop               | stop                             |
| `review_pending`  | stop               | stop                             |
| `tasks_empty`     | bootstrap-or-stop  | bootstrap-or-stop                |

## Loop logic

Run `sdlc auto-mad-step` from the integrated terminal. Parse the JSON output:

- `action: "invoke"` → adopt the role from `agents/<role>.md` matching the `agent` field, **prepend `brief_context`** to your prompt as pre-loaded orientation, follow `instruction`, write the deliverable, then re-run `sdlc auto-mad-step`. **Print `auto_actions_taken` to the user first** so they see which signoffs / verifications were auto-handled this iteration.
- `action: "stop"` → print `auto_actions_taken` if any, then report `stop_reason` + `user_action`, exit. Stop reasons: `clarification`, `high_risk`, `review_pending`, `tasks_empty`, `auto_mad_cap`, `no_project`.
- `action: "done"` → all phases complete. Print final `auto_actions_taken` summary. Celebrate.

Defensive cap: max 20 outer-loop iterations per session.

## Safety rules

- Re-run `sdlc auto-mad-step` between every deliverable. Don't trust your own state — re-scan after each step.
- Even in mad mode, never skip a `stop`. Clarifications and high-risk are real.
- Surface auto-actions to the user every iteration.

## Reverting

To revert ALL ai-mad-mode signoffs:

```
grep -l "approved_by: ai-mad-mode" automation/signoffs/*.yaml | xargs rm
```
