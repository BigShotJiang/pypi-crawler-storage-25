---
mode: agent
description: Inspect what the smart dispatcher recommends right now (without acting).
---

The user wants to know what the framework thinks should happen next, without invoking any agent.

## Steps

1. Run from the integrated terminal: `sdlc dispatch --json`
2. Parse the JSON. Important fields:
   - `action` — `invoke` / `stop_for_gate` / `stop_for_user` / `ask_user` / `done`
   - `agent` — the primary agent
   - `parallel_agents` — cross-cutting agents to invoke in parallel (may be empty)
   - `blocked_by` — `null` or `{phase, gate, clarification, high_risk_item}`
3. Translate to plain language:
   - `action == "invoke"`: "Run the `sdlc-next` prompt — the framework wants `<agent>` to work on `<item_id>`."
   - `parallel_agents` non-empty: "After the primary agent finishes, also invoke these in parallel: `<list>`."
   - `action == "stop_for_gate"`: "Phase <N> is blocked by gate `<id>`. Approvers needed: `<list>`. Write `automation/signoffs/<id>.yaml` with `approved: true`."
   - `blocked_by.clarification`: "Resolve the open clarification(s) first."
   - `action == "done"`: "All phases complete. 🎉"

## When to use this vs `sdlc-next`

- `sdlc-next` prompt is the **action** command — picks up the next item AND runs the subagent.
- `sdlc-dispatch` is the **inspection** command — shows what would happen, without doing it.
