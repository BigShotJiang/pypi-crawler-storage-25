"""Compatibility wrapper for the bootstrap inference implementation."""

from critband.bootstrap import *  # noqa: F401,F403

