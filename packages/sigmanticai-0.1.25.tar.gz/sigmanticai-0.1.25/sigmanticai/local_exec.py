"""
Local command execution — runs commands on the user's machine at the agent's request.

Security model:
  1. Blocked commands (sudo, mkfs, rm -rf /, etc.) are ALWAYS rejected.
  2. Safe commands (ls, cat, grep, EDA tools, compilers) are ALWAYS auto-approved.
  3. Mutating commands (rm, mv, chmod, git push, pip install, etc.) depend on
     the user's command_approval preference:
       - "autonomous": auto-approve everything (agent has full control)
       - "supervised": prompt the user for each mutating command
     The preference is set on first run and saved to ~/.sigmanticai/preferences.json.
  4. Unknown commands always prompt the user.
  5. Hard timeout of 5 minutes per command.
  6. stdout/stderr capped at 500KB/100KB.
"""

from __future__ import annotations

import asyncio
import json
import os
import re
import subprocess
import sys
from pathlib import Path
from typing import Optional

_IS_WINDOWS = sys.platform == "win32"

from rich.console import Console
from rich.panel import Panel

console = Console()

# ── Preferences ──────────────────────────────────────────────────────

_PREFS_DIR = Path.home() / ".sigmanticai"
_PREFS_FILE = _PREFS_DIR / "preferences.json"

# Module-level cache so we only prompt once per CLI session
_session_approval_mode: Optional[str] = None


def _load_preferences() -> dict:
    """Load user preferences from ~/.sigmanticai/preferences.json."""
    if _PREFS_FILE.exists():
        try:
            return json.loads(_PREFS_FILE.read_text())
        except (json.JSONDecodeError, OSError):
            pass
    return {}


def _save_preferences(prefs: dict) -> None:
    """Save user preferences to ~/.sigmanticai/preferences.json."""
    _PREFS_DIR.mkdir(parents=True, exist_ok=True)
    _PREFS_FILE.write_text(json.dumps(prefs, indent=2) + "\n")


def get_command_approval_mode() -> str:
    """Get the user's command approval preference, prompting on first run.

    Returns "autonomous" or "supervised".
    """
    global _session_approval_mode

    if _session_approval_mode is not None:
        return _session_approval_mode

    prefs = _load_preferences()
    mode = prefs.get("command_approval")

    if mode in ("autonomous", "supervised"):
        _session_approval_mode = mode
        return mode

    # First run — ask the user
    console.print()
    console.print(Panel(
        "[bold]Command Approval Mode[/bold]\n\n"
        "When the agent needs to run commands on your machine, how should it behave?\n\n"
        "  [bold cyan]1[/bold cyan]. [bold]Autonomous[/bold] — Agent runs all commands freely\n"
        "     [dim]Best for experienced users. The agent can compile, simulate,\n"
        "     delete build artifacts, and modify files without asking.[/dim]\n\n"
        "  [bold cyan]2[/bold cyan]. [bold]Supervised[/bold] — Agent asks before mutating commands\n"
        "     [dim]Read-only commands and compilations run automatically.\n"
        "     Commands that delete/move/modify files will ask for your approval.[/dim]\n\n"
        "[dim]You can change this later: sigmanticai config --command-approval <mode>[/dim]",
        title="First-Time Setup",
        border_style="cyan",
    ))

    try:
        choice = input("  Select [1/2]: ").strip()
    except (EOFError, KeyboardInterrupt):
        choice = "2"

    if choice == "1":
        mode = "autonomous"
        console.print("  [green]Autonomous mode — agent has full control.[/green]")
    else:
        mode = "supervised"
        console.print("  [yellow]Supervised mode — agent will ask before deleting/modifying files.[/yellow]")

    prefs["command_approval"] = mode
    _save_preferences(prefs)
    _session_approval_mode = mode
    console.print(f"  [dim]Saved to {_PREFS_FILE}[/dim]")
    console.print()
    return mode


def set_command_approval_mode(mode: str) -> None:
    """Programmatically set the command approval mode."""
    global _session_approval_mode
    if mode not in ("autonomous", "supervised"):
        raise ValueError(f"Invalid mode: {mode!r}. Use 'autonomous' or 'supervised'.")
    prefs = _load_preferences()
    prefs["command_approval"] = mode
    _save_preferences(prefs)
    _session_approval_mode = mode


# ── Command classification ──────────────────────────────────────────

# Safe commands: read-only operations + compilation/simulation.
# These NEVER need user approval regardless of mode.
_SAFE_COMMANDS = {
    # Read-only / inspection
    "ls", "cat", "head", "tail", "grep", "find", "wc", "diff",
    "which", "echo", "env", "pwd", "cd", "file", "stat", "tree",
    "source", ".",
    # EDA tools (compile, simulate, lint, coverage)
    "verilator", "iverilog", "vvp", "yosys",
    "vcs", "simv", "urg", "vcf", "verdi", "spyglass", "sg_shell",
    "xrun", "xmsim", "xmvlog", "xmvhdl", "xmelab", "imc", "jg",
    "irun", "ncsim", "ncvlog",
    "vlog", "vopt", "vsim", "vlib", "vmap", "vcover", "qverify", "visualizer",
    "xvlog", "xvhdl", "xelab", "xsim", "xcrg", "vivado",
    # Build tools
    "make", "cmake", "gcc", "g++",
    "python3", "python",
}

# Mutating commands: these modify the filesystem or system state.
# In supervised mode, these prompt the user.
_MUTATING_COMMANDS = {
    "rm", "mv", "chmod", "chown",
    "cp", "mkdir", "touch",
    "pip", "pip3",
    "git",
    "sed", "awk", "tee",
    "tar", "gzip", "gunzip", "unzip",
}

# Always blocked — catastrophic or security-sensitive
BLOCKED_PATTERNS = [
    "curl ", "wget ", "ssh ", "scp ", "rsync ",
    "nc ", "netcat ", "ncat ",
    "> /dev/", "| /dev/",
    "sudo ", "su ",
    "mkfs", "dd if=",
    ":(){ ", "fork",
]

# rm -rf targeting root or home — matched via regex to avoid
# false positives like "rm -rf /tmp/build"
_BLOCKED_RM_RE = re.compile(
    r"rm\s+(-[a-zA-Z]*r[a-zA-Z]*\s+)*(/\s*$|/\s+|~\s*$|~\s+|~/)(?!tmp|var/tmp)",
)

COMMAND_TIMEOUT = 300  # 5 minutes
MAX_STDOUT = 500_000   # 500 KB
MAX_STDERR = 100_000   # 100 KB


def _get_base_command(command: str) -> str:
    """Extract the primary command from a shell string."""
    cmd_stripped = command.strip()
    # For chained commands, check the last one (cd /tmp && rm foo → rm)
    if "&&" in cmd_stripped:
        cmd_stripped = cmd_stripped.split("&&")[-1].strip()
    elif ";" in cmd_stripped:
        cmd_stripped = cmd_stripped.split(";")[-1].strip()
    first_word = cmd_stripped.split()[0] if cmd_stripped else ""
    return os.path.basename(first_word).lower()


def _classify_command(command: str) -> str:
    """Classify a command as 'safe', 'mutating', or 'unknown'.

    Also checks intermediate commands in chains (e.g. 'rm foo && ls' → 'mutating').
    Handles quoted strings to avoid false splits on ';' inside quotes.
    """
    parts = _split_command_chain(command)

    worst = "safe"
    for part in parts:
        first_word = part.split()[0] if part else ""
        base = os.path.basename(first_word).lower()
        if base in _MUTATING_COMMANDS:
            worst = "mutating"
        elif base not in _SAFE_COMMANDS:
            return "unknown"
    return worst


def _split_command_chain(command: str) -> list:
    """Split a command on && and ; while respecting quotes."""
    parts = []
    current = []
    in_single = False
    in_double = False
    i = 0
    s = command.strip()

    while i < len(s):
        c = s[i]
        if c == "'" and not in_double:
            in_single = not in_single
            current.append(c)
        elif c == '"' and not in_single:
            in_double = not in_double
            current.append(c)
        elif not in_single and not in_double:
            if c == ';':
                parts.append("".join(current).strip())
                current = []
            elif c == '&' and i + 1 < len(s) and s[i + 1] == '&':
                parts.append("".join(current).strip())
                current = []
                i += 1  # skip second &
            else:
                current.append(c)
        else:
            current.append(c)
        i += 1

    remainder = "".join(current).strip()
    if remainder:
        parts.append(remainder)

    return [p for p in parts if p]


def _is_blocked(command: str) -> bool:
    """Check if a command matches blocked patterns."""
    cmd_lower = command.lower()
    if any(pattern in cmd_lower for pattern in BLOCKED_PATTERNS):
        return True
    if _BLOCKED_RM_RE.search(cmd_lower):
        return True
    return False


# ── Detached / fire-and-forget launches ───────────────────────────
# Some commands explicitly launch a long-running daemon (e.g. an EDA
# hardware server). On Windows, ``start "" "...hw_server.bat"`` and on
# POSIX, ``nohup ./server`` are meant to detach. If we route those
# through the normal ``proc.communicate()`` path, the daemon's child
# process inherits our stdout/stderr pipe handles and never closes
# them, so ``communicate()`` blocks until ``COMMAND_TIMEOUT`` fires
# (5 minutes). We avoid that by explicitly spawning these with proper
# detachment flags and DEVNULL for all three standard streams.

# Regex for `cmd[.exe] /c[/k] <rest>` — used to peel ONE layer of
# cmd wrapping so a nested `start ...` is still classified as detached.
# EDA agents commonly emit `cmd /c "start /B C:\Xilinx\...\hw_server.bat"`
# and without unwrapping we'd run that through proc.communicate() and
# block on the daemon's inherited pipe handles.
_CMD_C_WRAPPER_RE = re.compile(
    r'^cmd(?:\.exe)?\s+/[ck]\s+(.+?)\s*$',
    re.IGNORECASE,
)


def _unwrap_cmd_c(seg: str) -> str:
    """Strip one layer of `cmd /c "..."` (or `/k`) wrapping, if present.

    Returns the inner command without surrounding double quotes. If the
    segment is not a cmd /c wrapper, returns it unchanged.
    """
    m = _CMD_C_WRAPPER_RE.match(seg)
    if not m:
        return seg
    inner = m.group(1).strip()
    if len(inner) >= 2 and inner[0] == '"' and inner[-1] == '"':
        inner = inner[1:-1].strip()
    return inner


def _seg_is_detached_start(seg: str) -> bool:
    """True if `seg` is a Windows `start ...` invocation that detaches.

    Treats `start /wait ...` as synchronous (caller skips it).
    """
    if not seg:
        return False
    if re.match(r"start\s+/wait\b", seg, re.IGNORECASE):
        return False
    return bool(re.match(r"start(\s|$)", seg, re.IGNORECASE))


def _is_detached_launch(command: str) -> bool:
    """True only for unambiguous fire-and-forget launches.

    Conservative on purpose: anything not matching the patterns below
    falls through to the normal execution path with no behavior change.

    Recognised on Windows:
      * ``start ...``                              (direct)
      * ``start /B foo``                           (no-window)
      * ``cmd /c "start /B foo"``                  (one cmd wrapper)
      * ``cmd.exe /c start foo``                   (one cmd wrapper, unquoted)

    Explicitly NOT recognised (so they go through normal sync path):
      * ``start /wait foo``                        (caller wants to wait)
      * Any nesting deeper than one cmd /c level  (vanishingly rare)
    """
    s = command.strip()
    if not s:
        return False

    if _IS_WINDOWS:
        for seg in re.split(r"\s*(?:&&|\|\|?|;)\s*", s):
            seg_stripped = seg.strip()
            if not seg_stripped:
                continue
            if _seg_is_detached_start(seg_stripped):
                return True
            unwrapped = _unwrap_cmd_c(seg_stripped)
            if unwrapped is not seg_stripped and _seg_is_detached_start(unwrapped):
                return True
        return False

    # POSIX: only the unambiguous `nohup ` prefix. Trailing `&` is not
    # handled here to avoid false positives with shell operators.
    return s.startswith("nohup ")


def _execute_detached(command: str, cwd: str) -> dict:
    """Spawn a detached process whose I/O is fully disconnected from us.

    We use ``subprocess.Popen`` (not ``asyncio.create_subprocess_shell``)
    with DEVNULL on all three streams and platform-appropriate detach
    flags. This guarantees that no child or grandchild can keep one of
    our pipes open and block ``communicate()``.

    Returns immediately after spawning (no wait).
    """
    creationflags = 0
    start_new_session = False
    if _IS_WINDOWS:
        creationflags = (
            getattr(subprocess, "DETACHED_PROCESS", 0)
            | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
        )
    else:
        start_new_session = True

    try:
        subprocess.Popen(
            command,
            shell=True,
            cwd=cwd or None,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=creationflags,
            start_new_session=start_new_session,
            close_fds=True,
        )
    except Exception as e:
        return {
            "stdout": "",
            "stderr": f"Detached launch failed: {e}",
            "exit_code": -1,
        }

    return {
        "stdout": (
            "(launched in background; output not captured)\n"
            f"  command: {command}"
        ),
        "stderr": "",
        "exit_code": 0,
    }


# ── Main entry point ──────────────────────────────────────────────


async def execute_local_command(
    command: str,
    cwd: str = ".",
    auto_approve: bool = False,
) -> dict:
    """Execute a command locally with security controls.

    Args:
        command: Shell command to execute.
        cwd: Working directory (must be within the project).
        auto_approve: Skip user approval for all commands.

    Returns:
        {"stdout": str, "stderr": str, "exit_code": int}
    """
    # Always block catastrophic commands
    if _is_blocked(command):
        return {
            "stdout": "",
            "stderr": f"BLOCKED: Command rejected by security policy: {command[:100]}",
            "exit_code": -1,
        }

    # Determine if we need to prompt
    if auto_approve:
        approved = True
    else:
        classification = _classify_command(command)
        mode = get_command_approval_mode()

        if classification == "safe":
            approved = True
        elif classification == "mutating" and mode == "autonomous":
            approved = True
        else:
            # supervised + mutating, or unknown command → prompt
            approved = False

    if not approved:
        label = _classify_command(command)
        tag = "[yellow]mutating[/yellow]" if label == "mutating" else "[red]unknown[/red]"
        console.print()
        console.print(Panel(
            f"[bold yellow]The agent wants to run a command on your machine:[/bold yellow]\n\n"
            f"  [bold white]{command}[/bold white]\n\n"
            f"  Type: {tag}\n"
            f"[dim]Working directory: {cwd}[/dim]",
            title="Command Approval Required",
            border_style="yellow",
        ))
        try:
            response = input("  Allow? (y/n/always): ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            return {
                "stdout": "",
                "stderr": "Command rejected by user",
                "exit_code": -1,
            }

        if response in ("always", "a"):
            set_command_approval_mode("autonomous")
            console.print("  [green]Switched to autonomous mode for this and future sessions.[/green]")
            approved = True
        elif response in ("y", "yes"):
            approved = True
        else:
            console.print("  [red]Rejected.[/red]")
            return {
                "stdout": "",
                "stderr": "Command rejected by user",
                "exit_code": -1,
            }

    # Show what's running
    cmd_short = command[:120] + ("..." if len(command) > 120 else "")
    console.print(f"  [dim]Running locally:[/dim] [cyan]{cmd_short}[/cyan]")

    # Detached/daemon launches must NOT go through proc.communicate() —
    # the spawned daemon keeps the inherited stdout/stderr handles open
    # and we'd block until COMMAND_TIMEOUT (5 minutes) for no reason.
    if _is_detached_launch(command):
        console.print("  [dim]Detected detached launch; spawning without pipe capture.[/dim]")
        # Brief delay so the spawned process has a chance to bind ports
        # / write its initial banner before we hand control back.
        await asyncio.sleep(0.5)
        result = _execute_detached(command, cwd)
        console.print("  [green]Spawned[/green] [dim](detached, exit code unavailable)[/dim]")
        return result

    # Execute with timeout
    try:
        proc = await asyncio.create_subprocess_shell(
            command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=cwd,
        )
        try:
            stdout_bytes, stderr_bytes = await asyncio.wait_for(
                proc.communicate(), timeout=COMMAND_TIMEOUT
            )
        except asyncio.TimeoutError:
            proc.kill()
            await proc.communicate()
            console.print(f"  [red]Timed out after {COMMAND_TIMEOUT}s[/red]")
            return {
                "stdout": "",
                "stderr": f"Command timed out after {COMMAND_TIMEOUT} seconds",
                "exit_code": -1,
            }

        stdout = stdout_bytes.decode("utf-8", errors="replace")[:MAX_STDOUT]
        stderr = stderr_bytes.decode("utf-8", errors="replace")[:MAX_STDERR]
        exit_code = proc.returncode or 0

        if exit_code == 0:
            console.print(f"  [green]Done[/green] [dim](exit 0, {len(stdout)} chars)[/dim]")
        else:
            console.print(f"  [red]Failed[/red] [dim](exit {exit_code})[/dim]")

        return {"stdout": stdout, "stderr": stderr, "exit_code": exit_code}

    except Exception as e:
        console.print(f"  [red]Error: {e}[/red]")
        return {
            "stdout": "",
            "stderr": f"Execution error: {e}",
            "exit_code": -1,
        }
