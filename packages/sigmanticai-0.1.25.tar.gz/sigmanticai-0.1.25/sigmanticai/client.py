"""
WebSocket client — connects to the SigmanticAI backend.

Handles:
  - Connection with authentication
  - Auto-reconnect with event replay
  - Message sending (text, file uploads)
  - Async event iterator for the display layer
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import ssl
import sys
import time
from pathlib import Path
from typing import Any, AsyncIterator, Dict, Optional

import certifi
import websockets
from websockets.exceptions import (
    ConnectionClosed,
    ConnectionClosedError,
    ConnectionClosedOK,
    InvalidStatusCode,
)

from sigmanticai.config import API_URL

logger = logging.getLogger("sigmanticai.client")


def _status(msg: str) -> None:
    """Print a reconnect status line visible to the user."""
    print(f"\033[33m{msg}\033[0m", file=sys.stderr, flush=True)


# ── Targeted diagnostic logging ──────────────────────────────────────
# Brought back specifically to diagnose the resume-replay flow (commit
# that introduced this came after the user reported "iter-limit then
# instant timeout" — caused by gateway replaying old `done {reason:
# timeout}` events that the client was treating as live death signals).
#
# Each line carries:  HH:MM:SS  [client]  <one-line event description>
# Stderr in dim cyan so it's visible but not loud.  Same line append to
# ~/.sigmanticai/debug.log so the user can paste it back for review.
#
# Disable: SIGMANTICAI_DEBUG=0
_DEBUG_ENABLED = os.environ.get("SIGMANTICAI_DEBUG", "1") not in ("0", "false", "False", "")
_DEBUG_LOG_PATH = Path.home() / ".sigmanticai" / "debug.log"


def _debug(msg: str) -> None:
    """One-line diagnostic to stderr + ~/.sigmanticai/debug.log. No-op
    when SIGMANTICAI_DEBUG=0. Best-effort: silent on any I/O failure."""
    if not _DEBUG_ENABLED:
        return
    try:
        ts = time.strftime("%H:%M:%S", time.localtime())
        line = f"[{ts}] [client] {msg}"
        print(f"\033[2;36m{line}\033[0m", file=sys.stderr, flush=True)
        try:
            _DEBUG_LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
            with _DEBUG_LOG_PATH.open("a") as f:
                f.write(line + "\n")
        except Exception:
            pass
    except Exception:
        pass


# Reconnect settings
MAX_RECONNECT_ATTEMPTS = 10
RECONNECT_BASE_DELAY = 1.0  # seconds
RECONNECT_MAX_DELAY = 30.0
_SESSION_LOCK_RETRY_DELAY = 5.0  # wait for old gateway's session lock to expire


# ── Session state persistence ────────────────────────────────────────
# Stored so that a fresh `sigmanticai` invocation after Ctrl+Z/quit can
# offer to reconnect to the same server-side session (and replay events
# from the last seen id), instead of always starting from scratch.
_SESSION_STATE_DIR = Path.home() / ".sigmanticai"
_SESSION_STATE_FILE = _SESSION_STATE_DIR / "last_session.json"
# Sessions older than this are considered stale and ignored on startup.
# Generous on purpose — the user may walk away from a long EDA debug
# session for hours.  The server may have already reaped the session by
# the time the user comes back, but the resume path falls back cleanly
# to a fresh session if the gateway declines, so it costs nothing to
# offer.  Override with $SIGMANTICAI_RESUME_MAX_AGE_SECONDS.
try:
    SESSION_STATE_MAX_AGE_SECONDS = int(
        os.environ.get("SIGMANTICAI_RESUME_MAX_AGE_SECONDS", str(7 * 24 * 60 * 60))
    )
except (TypeError, ValueError):
    SESSION_STATE_MAX_AGE_SECONDS = 7 * 24 * 60 * 60  # 7 days


def save_session_state(
    session_id: Optional[str],
    last_event_id: Optional[str] = None,
    api_url: Optional[str] = None,
    cwd: Optional[str] = None,
) -> None:
    """Persist the current session id and last event id to disk.

    Best-effort: failures are swallowed so a flaky disk never breaks the CLI.
    """
    if not session_id:
        return
    try:
        _SESSION_STATE_DIR.mkdir(parents=True, exist_ok=True)
        payload = {
            "session_id": session_id,
            "last_event_id": last_event_id,
            "api_url": api_url,
            "cwd": cwd,
            "saved_at": time.time(),
        }
        tmp = _SESSION_STATE_FILE.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(payload, indent=2))
        os.replace(tmp, _SESSION_STATE_FILE)
    except Exception as e:
        logger.debug("save_session_state failed: %s", e)


def load_session_state() -> Optional[Dict[str, Any]]:
    """Return the last persisted session state, or None if missing/stale.

    A returned dict always carries 'session_id' and an 'age_seconds' field
    derived from the file's saved_at timestamp.
    """
    try:
        if not _SESSION_STATE_FILE.is_file():
            return None
        data = json.loads(_SESSION_STATE_FILE.read_text())
    except Exception as e:
        logger.debug("load_session_state failed: %s", e)
        return None

    sid = data.get("session_id")
    if not sid:
        return None

    saved_at = data.get("saved_at")
    try:
        age = time.time() - float(saved_at) if saved_at is not None else None
    except (TypeError, ValueError):
        age = None

    if age is None or age > SESSION_STATE_MAX_AGE_SECONDS or age < 0:
        # Stale or unreadable timestamp — surface nothing to the caller and
        # quietly clear the file so we don't keep prompting forever.
        clear_session_state()
        return None

    data["age_seconds"] = age
    return data


def clear_session_state() -> None:
    """Delete the persisted session-state file (best-effort)."""
    try:
        if _SESSION_STATE_FILE.is_file():
            _SESSION_STATE_FILE.unlink()
    except Exception as e:
        logger.debug("clear_session_state failed: %s", e)


class SessionMigrating(Exception):
    """Raised when the server returns 4009 (session lock held by old gateway)."""
    pass


class UpgradeRequired(Exception):
    """Raised when the gateway closes our WebSocket with code 4012.

    Signals that this CLI is older than the latest published on PyPI
    and the server has refused to serve us until we upgrade.  ``cli.py``
    catches this at every call site, renders a clean upgrade panel,
    and exits — we *never* retry an upgrade-required close, because no
    amount of retrying will make the installed version newer.
    """

    UPGRADE_CLOSE_CODE = 4012

    def __init__(self, message: str = "") -> None:
        super().__init__(message or "Please upgrade SigmanticAI: pip3 install --upgrade sigmanticai")
        self.message = message


class SigmanticClient:
    """
    WebSocket client for the SigmanticAI backend.

    Usage:
        client = SigmanticClient(access_token="...")
        await client.connect()

        # Send a message
        await client.send_message("Build verification for a FIFO")

        # Iterate over events
        async for event in client.events():
            if event["type"] == "text":
                print(event["content"])
            elif event["type"] == "done":
                break

        await client.close()
    """

    def __init__(
        self,
        access_token: str,
        api_url: str = API_URL,
        session_id: Optional[str] = None,
    ):
        self._access_token = access_token
        self._api_url = api_url
        self._session_id = session_id
        # Remember what the caller asked us to resume so connect() can detect
        # the case where the gateway silently created a brand-new session
        # (it does that when the requested session_id no longer exists).
        self._requested_session_id = session_id
        self._resume_was_declined = False
        self._ws: Optional[websockets.WebSocketClientProtocol] = None
        self._last_event_id: Optional[str] = None
        self._connected = False
        self._closing = False
        # Set when the server ends the session for a non-recoverable reason
        # (idle timeout, client disconnected, hard fail). After this flips
        # True any further send_* call raises so the caller can surface the
        # dead state to the user instead of silently sitting on "Thinking…".
        self._session_dead = False
        self._session_dead_reason: str = ""
        # Number of user messages successfully sent on this connection.
        # Used by events() to distinguish REAL terminal events (which
        # always come from a worker processing something we sent) from
        # REPLAYED terminal events (the gateway dumps every event after
        # our last_event_id when we resume — including stale `done`
        # events from the previous worker's death). If we get a `done`
        # or `failed` while this is still 0, it's necessarily a replay.
        self._user_messages_sent = 0
        # Throttle disk writes for save_session_state — high-volume text
        # streaming events would otherwise hammer ~/.sigmanticai/ every tick.
        self._last_state_save_at: float = 0.0
        self._state_save_min_interval: float = 5.0  # seconds

    @property
    def is_session_dead(self) -> bool:
        """True after the server ended the session for an unrecoverable reason."""
        return self._session_dead

    @property
    def session_dead_reason(self) -> str:
        """Reason string for the dead session (e.g. 'timeout', 'disconnected')."""
        return self._session_dead_reason

    @property
    def resume_was_declined(self) -> bool:
        """True if we asked to resume a specific session_id and the gateway
        silently created a fresh one instead (i.e. the prior session has
        been reaped). The caller should warn the user that chat history
        from the prior session is NOT recovered."""
        return self._resume_was_declined

    @property
    def session_id(self) -> Optional[str]:
        return self._session_id

    async def connect(self) -> Dict[str, Any]:
        """
        Connect and authenticate.

        Returns the session info dict from the server.
        Raises ConnectionError on failure.
        """
        try:
            # Build SSL context with certifi's CA bundle so connections
            # work on macOS even when system certs aren't configured
            # (e.g. python.org Python without "Install Certificates").
            ssl_ctx = ssl.create_default_context(cafile=certifi.where())

            connect_kwargs: dict = {
                "ssl": ssl_ctx,
                "ping_interval": 30,
                "ping_timeout": 1800,
                "close_timeout": 10,
                "max_size": 10 * 1024 * 1024,
            }
            # ── Alpha stage routing (internal only) ─────────────────
            # DO NOT copy this block to SigmanticAICLi (PyPI package).
            # The extra_headers/additional_headers kwarg is not supported
            # by all websockets versions and will break the published CLI.
            _stage = os.environ.get("SIGMANTICAI_STAGE", "")
            if _stage:
                _hdrs = {"X-Stage": _stage}
                connect_kwargs["additional_headers"] = _hdrs

            try:
                self._ws = await websockets.connect(
                    self._api_url, **connect_kwargs,
                )
            except TypeError:
                if "additional_headers" in connect_kwargs:
                    connect_kwargs["extra_headers"] = connect_kwargs.pop("additional_headers")
                self._ws = await websockets.connect(
                    self._api_url, **connect_kwargs,
                )
            # ── End alpha stage routing ────────────────────────────
        except Exception as e:
            raise ConnectionError(f"Failed to connect to {self._api_url}: {e}")

        auth_msg = {"api_key": self._access_token}
        if self._session_id:
            auth_msg["session_id"] = self._session_id
        if self._last_event_id:
            auth_msg["after"] = self._last_event_id

        await self._ws.send(json.dumps(auth_msg))

        # Wait for session response
        try:
            raw = await asyncio.wait_for(self._ws.recv(), timeout=30)
        except ConnectionClosedError as e:
            if e.rcvd and e.rcvd.code == 4009:
                raise SessionMigrating(
                    "Session is being migrated to a new server — retrying..."
                )
            # 4012 = gateway-side CLI version gate.  Never retry — no
            # amount of reconnects will make our installed version
            # newer.  cli.py catches this and renders an upgrade panel.
            if e.rcvd and e.rcvd.code == UpgradeRequired.UPGRADE_CLOSE_CODE:
                raise UpgradeRequired(e.reason or "")
            reason = e.reason or "Invalid or expired credentials"
            raise ConnectionError(reason)
        session_info = json.loads(raw)

        if session_info.get("type") == "error":
            msg = session_info.get("message", "Unknown error")
            raise ConnectionError(msg)

        _server_sid = session_info.get("session_id", self._session_id)
        # If we requested a resume of a specific session_id and the server
        # came back with a DIFFERENT one, the gateway silently reaped our
        # prior session and started fresh. Surface that so the caller can
        # tell the user "your old chat history isn't recoverable" instead
        # of pretending the resume worked.
        if self._requested_session_id and _server_sid != self._requested_session_id:
            self._resume_was_declined = True
            _debug(
                f"connect: resume DECLINED (requested={self._requested_session_id!r} "
                f"got={_server_sid!r}) — gateway started fresh"
            )
        self._session_id = _server_sid
        self._connected = True
        # Persist the new session id so a Ctrl+Z / quit + restart can offer to
        # resume it. We re-save again on each event id update inside events().
        save_session_state(
            self._session_id,
            self._last_event_id,
            api_url=self._api_url,
            cwd=os.getcwd(),
        )
        _debug(
            f"connect ok: session={self._session_id!r} "
            f"resume_requested={self._requested_session_id!r} "
            f"resume_declined={self._resume_was_declined}"
        )
        return session_info

    async def send_message(self, text: str) -> None:
        """Send a user message to the agent."""
        if self._session_dead:
            _debug(
                f"send_message REFUSED (session_dead, reason="
                f"{self._session_dead_reason!r})"
            )
            raise RuntimeError(
                f"Session ended (reason: {self._session_dead_reason or 'unknown'}). "
                f"Restart sigmanticai to start a new session."
            )
        if not self._ws or not self._connected:
            _debug("send_message REFUSED (not connected)")
            raise RuntimeError("Not connected")
        await self._ws.send(json.dumps({"type": "message", "text": text}))
        # Bump AFTER the successful send so a network failure doesn't
        # falsely promote a future replayed terminal to "real". This
        # counter gates the replay-suppression in events() — see notes
        # on self._user_messages_sent in __init__.
        self._user_messages_sent += 1
        _debug(
            f"send_message ok: {len(text)} chars (#{self._user_messages_sent} on this connection)"
        )

    async def send_cancel(self) -> None:
        """Send a cancel signal to abort the current response without disconnecting."""
        if not self._ws or not self._connected:
            return
        await self._ws.send(json.dumps({"type": "cancel"}))

    async def send_file(self, filename: str, content: str) -> None:
        """Upload a file (e.g., RTL for --rtl flag)."""
        if not self._ws or not self._connected:
            raise RuntimeError("Not connected")
        await self._ws.send(
            json.dumps({"type": "upload", "filename": filename, "content": content})
        )

    async def send_delete(self, filename: str) -> None:
        """Notify the server that a local file was deleted."""
        if not self._ws or not self._connected:
            raise RuntimeError("Not connected")
        await self._ws.send(
            json.dumps({"type": "delete", "filename": filename})
        )

    async def send_tool_response(self, request_id: str, result: str) -> None:
        """Send the result of a locally-executed tool call back to the server."""
        if not self._ws or not self._connected:
            raise RuntimeError("Not connected")
        await self._ws.send(json.dumps({
            "type": "tool_response",
            "request_id": request_id,
            "result": result[:500000],
        }))

    async def send_project_context(
        self, tree: str, tool_config: str = "", cache: str = "",
        os_info: str = "", checkpoints: str = "",
    ) -> None:
        """Send project directory tree, tool config, cache, and OS info to the server."""
        if not self._ws or not self._connected:
            raise RuntimeError("Not connected")
        msg: dict = {
            "type": "project_context",
            "tree": tree[:100000],
        }
        if tool_config:
            msg["tool_config"] = tool_config[:10000]
        if cache:
            msg["cache"] = cache[:500000]
        if os_info:
            msg["os_info"] = os_info[:200]
        if checkpoints:
            msg["checkpoints"] = checkpoints[:500000]
        await self._ws.send(json.dumps(msg))

    async def send_command_response(
        self, request_id: str, stdout: str, stderr: str, exit_code: int
    ) -> None:
        """Send the result of a locally-executed command back to the server."""
        if not self._ws or not self._connected:
            raise RuntimeError("Not connected")
        await self._ws.send(json.dumps({
            "type": "command_response",
            "request_id": request_id,
            "stdout": stdout[:500000],
            "stderr": stderr[:100000],
            "exit_code": exit_code,
        }))

    async def events(self) -> AsyncIterator[Dict[str, Any]]:
        """
        Async iterator over events from the server.

        Handles auto-reconnect transparently. Yields event dicts.
        """
        reconnect_attempts = 0

        while not self._closing:
            try:
                async for raw_msg in self._ws:
                    event = json.loads(raw_msg)
                    event_type = event.get("type", "")

                    # Track last event ID for replay on reconnect
                    if "id" in event:
                        self._last_event_id = event["id"]
                        # Throttled best-effort persist so a fresh CLI launch
                        # can pick up where this one left off without the
                        # disk write happening on every text chunk.
                        _now = time.time()
                        if _now - self._last_state_save_at >= self._state_save_min_interval:
                            self._last_state_save_at = _now
                            save_session_state(
                                self._session_id,
                                self._last_event_id,
                                api_url=self._api_url,
                                cwd=os.getcwd(),
                            )

                    # Handle pings
                    if event_type == "ping":
                        await self._ws.send(json.dumps({"type": "pong"}))
                        continue

                    # ── Replay-suppression for terminal events ──────────
                    # When the user resumes, the gateway's _replay_events
                    # dumps every event AFTER our saved last_event_id —
                    # which can include `done {reason: timeout}` from the
                    # PREVIOUS worker's death. A live worker can only
                    # emit `done`/`failed` as a result of processing
                    # something we sent, so if we haven't sent anything
                    # yet on this connection, any terminal event MUST be
                    # a replay. Suppress it entirely: don't yield (so
                    # display_event never renders the scary timeout
                    # panel), don't flip _session_dead, just keep
                    # listening for new events.
                    if event_type in ("done", "failed"):
                        _reason = (event.get("reason") or "").lower()
                        _is_terminal = event_type == "failed" or _reason in (
                            "timeout", "disconnected", "session_ended", "expired",
                        )
                        if _is_terminal and self._user_messages_sent == 0:
                            _debug(
                                f"recv {event_type!r} reason={_reason!r} id="
                                f"{event.get('id', '?')!r} -> SUPPRESSED (replay; "
                                f"no user msgs sent yet on this connection)"
                            )
                            continue

                    _debug(
                        f"recv {event_type!r} id={event.get('id', '?')!r}"
                    )

                    # Reset reconnect counter on data
                    reconnect_attempts = 0
                    yield event

                    # If server says done or failed, stop. Mark the session
                    # as dead for the unrecoverable reasons so subsequent
                    # send_* calls fail loudly instead of going into the
                    # void and leaving the CLI on a forever spinner.
                    if event_type in ("done", "failed"):
                        _reason = (event.get("reason") or "").lower()
                        if event_type == "failed" or _reason in (
                            "timeout", "disconnected", "session_ended", "expired",
                        ):
                            self._session_dead = True
                            self._session_dead_reason = _reason or event_type
                            self._connected = False
                            _debug(
                                f"DEAD via {event_type!r} reason={_reason!r} "
                                f"(after {self._user_messages_sent} user msg(s))"
                            )
                        return

            except ConnectionClosed as cc:
                if self._closing:
                    return

                # Gateway-side CLI version gate.  Don't even try to
                # reconnect — no amount of retrying will make the
                # installed sigmanticai version newer.  cli.py turns
                # this into a clean "Upgrade required" panel and exits.
                if cc.rcvd and cc.rcvd.code == UpgradeRequired.UPGRADE_CLOSE_CODE:
                    raise UpgradeRequired(cc.reason or "")

                reason = str(cc)
                is_timeout = "keepalive" in reason.lower() or "ping timeout" in reason.lower()

                if is_timeout:
                    logger.warning(
                        "Connection timed out (idle too long). "
                        "Run `sigmanticai` again — you'll be offered to resume."
                    )
                    raise ConnectionError(
                        "Connection timed out — the session was idle too long. "
                        "Run `sigmanticai` to reconnect; on startup you'll be "
                        "asked whether to resume this session "
                        "(any worker checkpoints in your project are preserved)."
                    )

                _status(
                    "Connection lost — reconnecting "
                    "(session id preserved for resume)..."
                )
                self._connected = False

                if reconnect_attempts >= MAX_RECONNECT_ATTEMPTS:
                    raise ConnectionError(
                        f"Lost connection after {MAX_RECONNECT_ATTEMPTS} reconnect attempts. "
                        f"Run `sigmanticai` again — you'll be offered to resume the session."
                    )

                # Exponential backoff
                delay = min(
                    RECONNECT_BASE_DELAY * (2**reconnect_attempts),
                    RECONNECT_MAX_DELAY,
                )
                reconnect_attempts += 1
                _status(f"Reconnect attempt {reconnect_attempts}/{MAX_RECONNECT_ATTEMPTS} in {delay:.0f}s...")
                await asyncio.sleep(delay)

                try:
                    await self.connect()
                    _status("Reconnected! Resuming session...")
                except SessionMigrating:
                    _status("Server update in progress — waiting for session migration...")
                    reconnect_attempts -= 1  # don't count migration retries
                    await asyncio.sleep(_SESSION_LOCK_RETRY_DELAY)
                    continue
                except UpgradeRequired:
                    # Re-raise — never retry an upgrade-required close.
                    raise
                except Exception as e:
                    _status(f"Reconnect failed: {e}")
                    continue

            except Exception as e:
                if self._closing:
                    return
                logger.error("Event stream error: %s", e)
                raise

    async def close(self) -> None:
        """Close the WebSocket connection."""
        self._closing = True
        self._connected = False
        if self._ws:
            try:
                await self._ws.close()
            except Exception:
                pass


