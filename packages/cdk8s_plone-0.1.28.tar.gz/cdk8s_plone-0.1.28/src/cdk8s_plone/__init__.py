r'''
# CDK8S Plone

> TypeScript and Python library for deploying Plone CMS to Kubernetes using CDK8S

[![npm version](https://badge.fury.io/js/%40bluedynamics%2Fcdk8s-plone.svg)](https://www.npmjs.com/package/@bluedynamics/cdk8s-plone)
[![PyPI version](https://badge.fury.io/py/cdk8s-plone.svg)](https://pypi.org/project/cdk8s-plone/)
[![License](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](LICENSE)

## Overview

cdk8s-plone provides CDK8S constructs for deploying [Plone CMS](https://plone.org/) on Kubernetes. Define your infrastructure using TypeScript or Python and generate Kubernetes manifests automatically.

**Key Features:**

* 🚀 Supports Volto (modern React frontend) and Classic UI
* 📦 High availability with configurable replicas
* ⚡ Optional Varnish HTTP caching via kube-httpcache (`PloneHttpcache`) or cloud-vinyl VinylCache operator (`PloneVinylCache`)
* 🔧 Fine-grained resource and probe configuration
* 🌍 Multi-language support (TypeScript/JavaScript and Python)
* ✅ Type-safe infrastructure as code

## Quick Start

### Installation

**TypeScript/JavaScript:**

```bash
npm install @bluedynamics/cdk8s-plone
```

**Python:**

```bash
pip install cdk8s-plone
```

### Basic Example

```python
import { App, Chart } from 'cdk8s';
import { Plone, PloneVariant } from '@bluedynamics/cdk8s-plone';

const app = new App();
const chart = new Chart(app, 'PloneDeployment');

new Plone(chart, 'my-plone', {
  variant: PloneVariant.VOLTO,
  backend: {
    image: 'plone/plone-backend:6.1.3',
    replicas: 3,
  },
  frontend: {
    image: 'plone/plone-frontend:16.0.0',
    replicas: 2,
  },
});

app.synth();
```

Generate Kubernetes manifests:

```bash
cdk8s synth
kubectl apply -f dist/
```

## Documentation

**📚 Full documentation:** https://bluedynamics.github.io/cdk8s-plone/

* [Quick Start Tutorial](https://bluedynamics.github.io/cdk8s-plone/tutorials/01-quick-start.html)
* [Configuration Reference](https://bluedynamics.github.io/cdk8s-plone/reference/configuration-options.html)
* [Architecture Overview](https://bluedynamics.github.io/cdk8s-plone/explanation/architecture.html)
* [Complete API Documentation](./API.md)

## Examples

Complete working examples are available in the [`examples/`](examples/) directory:

* **[Production Volto](examples/production-volto/)** - Production-ready Plone 6 deployment with modern UI:

  * Volto frontend (React) + REST API backend
  * PostgreSQL with RelStorage (CloudNativePG or Bitnami)
  * Varnish HTTP caching with kube-httpcache
  * Ingress support (Traefik/Kong) with TLS
* **[Classic UI](examples/classic-ui/)** - Traditional Plone deployment with server-side rendering:

  * Classic UI (traditional Plone interface)
  * PostgreSQL with RelStorage (CloudNativePG or Bitnami)
  * Varnish HTTP caching with kube-httpcache
  * Ingress support (Traefik/Kong) with TLS
  * Simpler architecture (no separate frontend)

### Prometheus Metrics

Enable Prometheus ServiceMonitor for metrics collection (requires Prometheus Operator):

```python
new Plone(chart, 'my-plone', {
  backend: {
    servicemonitor: true,
    metricsPath: '/metrics',  // optional, defaults to '/metrics'
  },
  frontend: {
    servicemonitor: true,
    metricsPort: 9090,  // optional, defaults to service port
  },
});
```

**Note:** You must instrument your Plone backend/frontend to expose metrics at the configured endpoint. For Volto/Node.js frontends, consider using [prom-client](https://www.npmjs.com/package/prom-client) or [express-prometheus-middleware](https://www.npmjs.com/package/express-prometheus-middleware).

## Requirements

* **kubectl** - [Install kubectl](https://kubernetes.io/docs/tasks/tools/#kubectl)
* **Node.js 16+** (for TypeScript/JavaScript) - [Install Node.js](https://nodejs.org/)
* **Python 3.8+** (for Python) - [Install Python](https://www.python.org/)
* **Kubernetes cluster** (local or cloud)

For detailed setup instructions, see [Setup Prerequisites](https://bluedynamics.github.io/cdk8s-plone/how-to/setup-prerequisites.html).

## Development

This project uses [Projen](https://projen.io/) for project management.

```bash
# Install dependencies
npm install

# Run tests
npm test

# Build
npm run build

# Update project configuration
# Edit .projenrc.ts, then run:
npx projen
```

For detailed development instructions, see [CONTRIBUTING.md](./CONTRIBUTING.md) (if available).

## Resources

* [CDK8S Documentation](https://cdk8s.io/)
* [Plone CMS](https://plone.org/)
* [kube-httpcache](https://github.com/mittwald/kube-httpcache) (for HTTP caching)
* [CloudNativePG](https://cloudnative-pg.io/) (for PostgreSQL management)

## License

[Apache 2.0](LICENSE)

## Maintainers

Maintained by [Blue Dynamics Alliance](https://github.com/bluedynamics)

**Author:** Jens W. Klein (jk@kleinundpartner.at)
'''
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ._jsii import *

import cdk8s_plus_30 as _cdk8s_plus_30_fa3b8a6f
import constructs as _constructs_77d1e7e8


@jsii.data_type(
    jsii_type="@bluedynamics/cdk8s-plone.HttpcacheEnvVar",
    jsii_struct_bases=[],
    name_mapping={"name": "name", "value": "value"},
)
class HttpcacheEnvVar:
    def __init__(self, *, name: builtins.str, value: builtins.str) -> None:
        '''An environment variable to pass to the kube-httpcache container.

        :param name: The name of the environment variable.
        :param value: The value of the environment variable.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1235804a7513a3b12840acadf55725cfdeac6e17ebfd9e188feab3a3091cfc85)
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "name": name,
            "value": value,
        }

    @builtins.property
    def name(self) -> builtins.str:
        '''The name of the environment variable.'''
        result = self._values.get("name")
        assert result is not None, "Required property 'name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def value(self) -> builtins.str:
        '''The value of the environment variable.'''
        result = self._values.get("value")
        assert result is not None, "Required property 'value' is missing"
        return typing.cast(builtins.str, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "HttpcacheEnvVar(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@bluedynamics/cdk8s-plone.HttpcacheToleration",
    jsii_struct_bases=[],
    name_mapping={
        "key": "key",
        "effect": "effect",
        "operator": "operator",
        "value": "value",
    },
)
class HttpcacheToleration:
    def __init__(
        self,
        *,
        key: builtins.str,
        effect: typing.Optional[builtins.str] = None,
        operator: typing.Optional[builtins.str] = None,
        value: typing.Optional[builtins.str] = None,
    ) -> None:
        '''A Kubernetes toleration for the Varnish pods.

        :param key: The taint key to tolerate.
        :param effect: The taint effect to tolerate (NoSchedule, PreferNoSchedule, NoExecute). Default: - tolerate all effects
        :param operator: The operator (Equal or Exists). Default: 'Equal'
        :param value: The taint value to match (when operator is Equal). Default: - no value
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2fbb2f6f32c28345f0e9ca5077426e713e3011a97fc0bb79ec4b17114ff6575c)
            check_type(argname="argument key", value=key, expected_type=type_hints["key"])
            check_type(argname="argument effect", value=effect, expected_type=type_hints["effect"])
            check_type(argname="argument operator", value=operator, expected_type=type_hints["operator"])
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "key": key,
        }
        if effect is not None:
            self._values["effect"] = effect
        if operator is not None:
            self._values["operator"] = operator
        if value is not None:
            self._values["value"] = value

    @builtins.property
    def key(self) -> builtins.str:
        '''The taint key to tolerate.'''
        result = self._values.get("key")
        assert result is not None, "Required property 'key' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def effect(self) -> typing.Optional[builtins.str]:
        '''The taint effect to tolerate (NoSchedule, PreferNoSchedule, NoExecute).

        :default: - tolerate all effects
        '''
        result = self._values.get("effect")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def operator(self) -> typing.Optional[builtins.str]:
        '''The operator (Equal or Exists).

        :default: 'Equal'
        '''
        result = self._values.get("operator")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def value(self) -> typing.Optional[builtins.str]:
        '''The taint value to match (when operator is Equal).

        :default: - no value
        '''
        result = self._values.get("value")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "HttpcacheToleration(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class Plone(
    _constructs_77d1e7e8.Construct,
    metaclass=jsii.JSIIMeta,
    jsii_type="@bluedynamics/cdk8s-plone.Plone",
):
    '''Plone construct for deploying Plone CMS to Kubernetes.

    This construct creates all necessary Kubernetes resources for running Plone:

    - Deployment(s) for backend (and optionally frontend)
    - Service(s) for network access
    - Optional PodDisruptionBudget for high availability

    Supports two deployment variants:

    - VOLTO: Modern React frontend with REST API backend (default)
    - CLASSICUI: Traditional server-side rendered Plone

    Example::

        new Plone(chart, 'my-plone', {
          variant: PloneVariant.VOLTO,
          backend: {
            image: 'plone/plone-backend:6.0.10',
            replicas: 3,
          },
          frontend: {
            image: 'plone/plone-frontend:16.0.0',
          },
        });
    '''

    def __init__(
        self,
        scope: "_constructs_77d1e7e8.Construct",
        id: builtins.str,
        *,
        backend: typing.Optional[typing.Union["PloneBaseOptions", typing.Dict[builtins.str, typing.Any]]] = None,
        frontend: typing.Optional[typing.Union["PloneBaseOptions", typing.Dict[builtins.str, typing.Any]]] = None,
        image_pull_secrets: typing.Optional[typing.Sequence[builtins.str]] = None,
        site_id: typing.Optional[builtins.str] = None,
        variant: typing.Optional["PloneVariant"] = None,
        version: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param scope: -
        :param id: -
        :param backend: Backend (Plone API) configuration. Default: {} (uses default values from PloneBaseOptions)
        :param frontend: Frontend (Volto) configuration. Only used when variant is PloneVariant.VOLTO. Default: {} (uses default values from PloneBaseOptions)
        :param image_pull_secrets: Names of Kubernetes secrets to use for pulling private container images. These secrets must exist in the same namespace as the deployment. Default: [] (no image pull secrets)
        :param site_id: Plone site ID in the ZODB. This is used to construct the internal API path for Volto frontend. Default: 'Plone'
        :param variant: Plone deployment variant to use. Default: PloneVariant.VOLTO
        :param version: Version string for labeling the deployment. This is used in Kubernetes labels and doesn't affect the actual image versions. Default: 'undefined'
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__543cbcb1139deb4ce75315c33bb5ebd6fd98851d9416a0f8e2c5cd960899e686)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        options = PloneOptions(
            backend=backend,
            frontend=frontend,
            image_pull_secrets=image_pull_secrets,
            site_id=site_id,
            variant=variant,
            version=version,
        )

        jsii.create(self.__class__, self, [scope, id, options])

    @builtins.property
    @jsii.member(jsii_name="backendServiceName")
    def backend_service_name(self) -> builtins.str:
        '''Name of the backend Kubernetes service.

        Use this to reference the backend service from other constructs.
        '''
        return typing.cast(builtins.str, jsii.get(self, "backendServiceName"))

    @builtins.property
    @jsii.member(jsii_name="siteId")
    def site_id(self) -> builtins.str:
        '''The Plone site ID in ZODB.'''
        return typing.cast(builtins.str, jsii.get(self, "siteId"))

    @builtins.property
    @jsii.member(jsii_name="variant")
    def variant(self) -> "PloneVariant":
        '''The deployment variant being used (VOLTO or CLASSICUI).'''
        return typing.cast("PloneVariant", jsii.get(self, "variant"))

    @builtins.property
    @jsii.member(jsii_name="frontendServiceName")
    def frontend_service_name(self) -> typing.Optional[builtins.str]:
        '''Name of the frontend Kubernetes service.

        Only set when variant is VOLTO, otherwise undefined.
        '''
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "frontendServiceName"))


@jsii.data_type(
    jsii_type="@bluedynamics/cdk8s-plone.PloneBaseOptions",
    jsii_struct_bases=[],
    name_mapping={
        "annotations": "annotations",
        "environment": "environment",
        "image": "image",
        "image_pull_policy": "imagePullPolicy",
        "limit_cpu": "limitCpu",
        "limit_memory": "limitMemory",
        "liveness_enabled": "livenessEnabled",
        "liveness_failure_threshold": "livenessFailureThreshold",
        "liveness_initial_delay_seconds": "livenessInitialDelaySeconds",
        "liveness_period_seconds": "livenessPeriodSeconds",
        "liveness_success_threshold": "livenessSuccessThreshold",
        "liveness_timeout_seconds": "livenessTimeoutSeconds",
        "max_unavailable": "maxUnavailable",
        "metrics_path": "metricsPath",
        "metrics_port": "metricsPort",
        "min_available": "minAvailable",
        "node_selector": "nodeSelector",
        "pod_annotations": "podAnnotations",
        "readiness_enabled": "readinessEnabled",
        "readiness_failure_threshold": "readinessFailureThreshold",
        "readiness_initial_delay_seconds": "readinessInitialDelaySeconds",
        "readiness_period_seconds": "readinessPeriodSeconds",
        "readiness_success_threshold": "readinessSuccessThreshold",
        "readiness_timeout_seconds": "readinessTimeoutSeconds",
        "replicas": "replicas",
        "request_cpu": "requestCpu",
        "request_memory": "requestMemory",
        "service_annotations": "serviceAnnotations",
        "servicemonitor": "servicemonitor",
    },
)
class PloneBaseOptions:
    def __init__(
        self,
        *,
        annotations: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        environment: typing.Optional["_cdk8s_plus_30_fa3b8a6f.Env"] = None,
        image: typing.Optional[builtins.str] = None,
        image_pull_policy: typing.Optional[builtins.str] = None,
        limit_cpu: typing.Optional[builtins.str] = None,
        limit_memory: typing.Optional[builtins.str] = None,
        liveness_enabled: typing.Optional[builtins.bool] = None,
        liveness_failure_threshold: typing.Optional[jsii.Number] = None,
        liveness_initial_delay_seconds: typing.Optional[jsii.Number] = None,
        liveness_period_seconds: typing.Optional[jsii.Number] = None,
        liveness_success_threshold: typing.Optional[jsii.Number] = None,
        liveness_timeout_seconds: typing.Optional[jsii.Number] = None,
        max_unavailable: typing.Optional[typing.Union[builtins.str, jsii.Number]] = None,
        metrics_path: typing.Optional[builtins.str] = None,
        metrics_port: typing.Optional[typing.Union[builtins.str, jsii.Number]] = None,
        min_available: typing.Optional[typing.Union[builtins.str, jsii.Number]] = None,
        node_selector: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        pod_annotations: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        readiness_enabled: typing.Optional[builtins.bool] = None,
        readiness_failure_threshold: typing.Optional[jsii.Number] = None,
        readiness_initial_delay_seconds: typing.Optional[jsii.Number] = None,
        readiness_period_seconds: typing.Optional[jsii.Number] = None,
        readiness_success_threshold: typing.Optional[jsii.Number] = None,
        readiness_timeout_seconds: typing.Optional[jsii.Number] = None,
        replicas: typing.Optional[jsii.Number] = None,
        request_cpu: typing.Optional[builtins.str] = None,
        request_memory: typing.Optional[builtins.str] = None,
        service_annotations: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        servicemonitor: typing.Optional[builtins.bool] = None,
    ) -> None:
        '''Base options for Plone backend or frontend configuration.

        These options control container image, replica count, resource limits,
        environment variables, and health probes.

        :param annotations: Annotations to add to the Deployment metadata. Default: - no additional annotations
        :param environment: Environment variables to set in the container. Use cdk8s-plus-30 Env class to define variables and sources. Default: - undefined (no additional environment variables)
        :param image: Container image to use for the deployment. Default: - 'plone/plone-backend:latest' for backend, 'plone/plone-frontend:latest' for frontend
        :param image_pull_policy: Image pull policy for the container. Default: 'IfNotPresent'
        :param limit_cpu: CPU limit for the container. Default: '500m' for both backend and frontend
        :param limit_memory: Memory limit for the container. Default: '512Mi' for backend, '1Gi' for frontend
        :param liveness_enabled: Enable liveness probe for the container. Liveness probes determine when to restart a container. Recommended: true for frontend, false for backend (Zope has its own recovery). Default: false
        :param liveness_failure_threshold: Minimum consecutive failures for the liveness probe to be considered failed. Default: 3
        :param liveness_initial_delay_seconds: Number of seconds after container start before liveness probe is initiated. Default: 30
        :param liveness_period_seconds: How often (in seconds) to perform the liveness probe. Default: 10
        :param liveness_success_threshold: Minimum consecutive successes for the liveness probe to be considered successful. Default: 1
        :param liveness_timeout_seconds: Number of seconds after which the liveness probe times out. Default: 5
        :param max_unavailable: Maximum number of pods that can be unavailable during updates. Can be an absolute number (e.g., 1) or a percentage (e.g., '50%'). Used in PodDisruptionBudget if specified. Default: - undefined (not set)
        :param metrics_path: Path to scrape metrics from. Only used when servicemonitor is enabled. Default: '/metrics'
        :param metrics_port: Port name or number to scrape metrics from. Only used when servicemonitor is enabled. Default: - uses the main service port
        :param min_available: Minimum number of pods that must be available during updates. Can be an absolute number (e.g., 1) or a percentage (e.g., '50%'). Used in PodDisruptionBudget if specified. Default: - undefined (not set)
        :param node_selector: Node selector labels for pod scheduling. Use to constrain pods to nodes with matching labels, e.g. for region affinity. Default: - no node selector
        :param pod_annotations: Annotations to add to the Pod template metadata. Common for Prometheus, Istio, backup policies, etc. Default: - no additional annotations
        :param readiness_enabled: Enable readiness probe for the container. Readiness probes determine when a container is ready to accept traffic. Default: true
        :param readiness_failure_threshold: Minimum consecutive failures for the readiness probe to be considered failed. Default: 3
        :param readiness_initial_delay_seconds: Number of seconds after container start before readiness probe is initiated. Default: 10
        :param readiness_period_seconds: How often (in seconds) to perform the readiness probe. Default: 10
        :param readiness_success_threshold: Minimum consecutive successes for the readiness probe to be considered successful. Default: 1
        :param readiness_timeout_seconds: Number of seconds after which the readiness probe times out. Default: 15
        :param replicas: Number of pod replicas to run. Default: 2
        :param request_cpu: CPU request for the container. Default: '200m'
        :param request_memory: Memory request for the container. Default: '256Mi'
        :param service_annotations: Annotations to add to the Service metadata. Common for external-dns, load balancers, service mesh, etc. Default: - no additional annotations
        :param servicemonitor: Enable Prometheus ServiceMonitor for metrics collection. Requires Prometheus Operator to be installed in the cluster. When enabled, a ServiceMonitor resource will be created to scrape metrics. Default: false
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cd9cf17a63ac3f69f433db3caa859d98a750929386f09ada26dd0fd212b3ec78)
            check_type(argname="argument annotations", value=annotations, expected_type=type_hints["annotations"])
            check_type(argname="argument environment", value=environment, expected_type=type_hints["environment"])
            check_type(argname="argument image", value=image, expected_type=type_hints["image"])
            check_type(argname="argument image_pull_policy", value=image_pull_policy, expected_type=type_hints["image_pull_policy"])
            check_type(argname="argument limit_cpu", value=limit_cpu, expected_type=type_hints["limit_cpu"])
            check_type(argname="argument limit_memory", value=limit_memory, expected_type=type_hints["limit_memory"])
            check_type(argname="argument liveness_enabled", value=liveness_enabled, expected_type=type_hints["liveness_enabled"])
            check_type(argname="argument liveness_failure_threshold", value=liveness_failure_threshold, expected_type=type_hints["liveness_failure_threshold"])
            check_type(argname="argument liveness_initial_delay_seconds", value=liveness_initial_delay_seconds, expected_type=type_hints["liveness_initial_delay_seconds"])
            check_type(argname="argument liveness_period_seconds", value=liveness_period_seconds, expected_type=type_hints["liveness_period_seconds"])
            check_type(argname="argument liveness_success_threshold", value=liveness_success_threshold, expected_type=type_hints["liveness_success_threshold"])
            check_type(argname="argument liveness_timeout_seconds", value=liveness_timeout_seconds, expected_type=type_hints["liveness_timeout_seconds"])
            check_type(argname="argument max_unavailable", value=max_unavailable, expected_type=type_hints["max_unavailable"])
            check_type(argname="argument metrics_path", value=metrics_path, expected_type=type_hints["metrics_path"])
            check_type(argname="argument metrics_port", value=metrics_port, expected_type=type_hints["metrics_port"])
            check_type(argname="argument min_available", value=min_available, expected_type=type_hints["min_available"])
            check_type(argname="argument node_selector", value=node_selector, expected_type=type_hints["node_selector"])
            check_type(argname="argument pod_annotations", value=pod_annotations, expected_type=type_hints["pod_annotations"])
            check_type(argname="argument readiness_enabled", value=readiness_enabled, expected_type=type_hints["readiness_enabled"])
            check_type(argname="argument readiness_failure_threshold", value=readiness_failure_threshold, expected_type=type_hints["readiness_failure_threshold"])
            check_type(argname="argument readiness_initial_delay_seconds", value=readiness_initial_delay_seconds, expected_type=type_hints["readiness_initial_delay_seconds"])
            check_type(argname="argument readiness_period_seconds", value=readiness_period_seconds, expected_type=type_hints["readiness_period_seconds"])
            check_type(argname="argument readiness_success_threshold", value=readiness_success_threshold, expected_type=type_hints["readiness_success_threshold"])
            check_type(argname="argument readiness_timeout_seconds", value=readiness_timeout_seconds, expected_type=type_hints["readiness_timeout_seconds"])
            check_type(argname="argument replicas", value=replicas, expected_type=type_hints["replicas"])
            check_type(argname="argument request_cpu", value=request_cpu, expected_type=type_hints["request_cpu"])
            check_type(argname="argument request_memory", value=request_memory, expected_type=type_hints["request_memory"])
            check_type(argname="argument service_annotations", value=service_annotations, expected_type=type_hints["service_annotations"])
            check_type(argname="argument servicemonitor", value=servicemonitor, expected_type=type_hints["servicemonitor"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if annotations is not None:
            self._values["annotations"] = annotations
        if environment is not None:
            self._values["environment"] = environment
        if image is not None:
            self._values["image"] = image
        if image_pull_policy is not None:
            self._values["image_pull_policy"] = image_pull_policy
        if limit_cpu is not None:
            self._values["limit_cpu"] = limit_cpu
        if limit_memory is not None:
            self._values["limit_memory"] = limit_memory
        if liveness_enabled is not None:
            self._values["liveness_enabled"] = liveness_enabled
        if liveness_failure_threshold is not None:
            self._values["liveness_failure_threshold"] = liveness_failure_threshold
        if liveness_initial_delay_seconds is not None:
            self._values["liveness_initial_delay_seconds"] = liveness_initial_delay_seconds
        if liveness_period_seconds is not None:
            self._values["liveness_period_seconds"] = liveness_period_seconds
        if liveness_success_threshold is not None:
            self._values["liveness_success_threshold"] = liveness_success_threshold
        if liveness_timeout_seconds is not None:
            self._values["liveness_timeout_seconds"] = liveness_timeout_seconds
        if max_unavailable is not None:
            self._values["max_unavailable"] = max_unavailable
        if metrics_path is not None:
            self._values["metrics_path"] = metrics_path
        if metrics_port is not None:
            self._values["metrics_port"] = metrics_port
        if min_available is not None:
            self._values["min_available"] = min_available
        if node_selector is not None:
            self._values["node_selector"] = node_selector
        if pod_annotations is not None:
            self._values["pod_annotations"] = pod_annotations
        if readiness_enabled is not None:
            self._values["readiness_enabled"] = readiness_enabled
        if readiness_failure_threshold is not None:
            self._values["readiness_failure_threshold"] = readiness_failure_threshold
        if readiness_initial_delay_seconds is not None:
            self._values["readiness_initial_delay_seconds"] = readiness_initial_delay_seconds
        if readiness_period_seconds is not None:
            self._values["readiness_period_seconds"] = readiness_period_seconds
        if readiness_success_threshold is not None:
            self._values["readiness_success_threshold"] = readiness_success_threshold
        if readiness_timeout_seconds is not None:
            self._values["readiness_timeout_seconds"] = readiness_timeout_seconds
        if replicas is not None:
            self._values["replicas"] = replicas
        if request_cpu is not None:
            self._values["request_cpu"] = request_cpu
        if request_memory is not None:
            self._values["request_memory"] = request_memory
        if service_annotations is not None:
            self._values["service_annotations"] = service_annotations
        if servicemonitor is not None:
            self._values["servicemonitor"] = servicemonitor

    @builtins.property
    def annotations(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        '''Annotations to add to the Deployment metadata.

        :default: - no additional annotations

        Example::

            { 'deployment.kubernetes.io/revision': '1' }
        '''
        result = self._values.get("annotations")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

    @builtins.property
    def environment(self) -> typing.Optional["_cdk8s_plus_30_fa3b8a6f.Env"]:
        '''Environment variables to set in the container.

        Use cdk8s-plus-30 Env class to define variables and sources.

        :default: - undefined (no additional environment variables)
        '''
        result = self._values.get("environment")
        return typing.cast(typing.Optional["_cdk8s_plus_30_fa3b8a6f.Env"], result)

    @builtins.property
    def image(self) -> typing.Optional[builtins.str]:
        '''Container image to use for the deployment.

        :default: - 'plone/plone-backend:latest' for backend, 'plone/plone-frontend:latest' for frontend

        Example::

            'plone/plone-backend:6.0.10' or 'plone/plone-frontend:16.0.0'
        '''
        result = self._values.get("image")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def image_pull_policy(self) -> typing.Optional[builtins.str]:
        '''Image pull policy for the container.

        :default: 'IfNotPresent'
        '''
        result = self._values.get("image_pull_policy")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def limit_cpu(self) -> typing.Optional[builtins.str]:
        '''CPU limit for the container.

        :default: '500m' for both backend and frontend

        Example::

            '500m' or '1' or '2000m'
        '''
        result = self._values.get("limit_cpu")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def limit_memory(self) -> typing.Optional[builtins.str]:
        '''Memory limit for the container.

        :default: '512Mi' for backend, '1Gi' for frontend

        Example::

            '512Mi' or '1Gi'
        '''
        result = self._values.get("limit_memory")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def liveness_enabled(self) -> typing.Optional[builtins.bool]:
        '''Enable liveness probe for the container.

        Liveness probes determine when to restart a container.
        Recommended: true for frontend, false for backend (Zope has its own recovery).

        :default: false
        '''
        result = self._values.get("liveness_enabled")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def liveness_failure_threshold(self) -> typing.Optional[jsii.Number]:
        '''Minimum consecutive failures for the liveness probe to be considered failed.

        :default: 3
        '''
        result = self._values.get("liveness_failure_threshold")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def liveness_initial_delay_seconds(self) -> typing.Optional[jsii.Number]:
        '''Number of seconds after container start before liveness probe is initiated.

        :default: 30
        '''
        result = self._values.get("liveness_initial_delay_seconds")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def liveness_period_seconds(self) -> typing.Optional[jsii.Number]:
        '''How often (in seconds) to perform the liveness probe.

        :default: 10
        '''
        result = self._values.get("liveness_period_seconds")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def liveness_success_threshold(self) -> typing.Optional[jsii.Number]:
        '''Minimum consecutive successes for the liveness probe to be considered successful.

        :default: 1
        '''
        result = self._values.get("liveness_success_threshold")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def liveness_timeout_seconds(self) -> typing.Optional[jsii.Number]:
        '''Number of seconds after which the liveness probe times out.

        :default: 5
        '''
        result = self._values.get("liveness_timeout_seconds")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def max_unavailable(
        self,
    ) -> typing.Optional[typing.Union[builtins.str, jsii.Number]]:
        '''Maximum number of pods that can be unavailable during updates.

        Can be an absolute number (e.g., 1) or a percentage (e.g., '50%').
        Used in PodDisruptionBudget if specified.

        :default: - undefined (not set)
        '''
        result = self._values.get("max_unavailable")
        return typing.cast(typing.Optional[typing.Union[builtins.str, jsii.Number]], result)

    @builtins.property
    def metrics_path(self) -> typing.Optional[builtins.str]:
        '''Path to scrape metrics from.

        Only used when servicemonitor is enabled.

        :default: '/metrics'
        '''
        result = self._values.get("metrics_path")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def metrics_port(self) -> typing.Optional[typing.Union[builtins.str, jsii.Number]]:
        '''Port name or number to scrape metrics from.

        Only used when servicemonitor is enabled.

        :default: - uses the main service port
        '''
        result = self._values.get("metrics_port")
        return typing.cast(typing.Optional[typing.Union[builtins.str, jsii.Number]], result)

    @builtins.property
    def min_available(self) -> typing.Optional[typing.Union[builtins.str, jsii.Number]]:
        '''Minimum number of pods that must be available during updates.

        Can be an absolute number (e.g., 1) or a percentage (e.g., '50%').
        Used in PodDisruptionBudget if specified.

        :default: - undefined (not set)
        '''
        result = self._values.get("min_available")
        return typing.cast(typing.Optional[typing.Union[builtins.str, jsii.Number]], result)

    @builtins.property
    def node_selector(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        '''Node selector labels for pod scheduling.

        Use to constrain pods to nodes with matching labels, e.g. for region affinity.

        :default: - no node selector

        Example::

            { 'topology.kubernetes.io/region': 'fsn1' }
        '''
        result = self._values.get("node_selector")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

    @builtins.property
    def pod_annotations(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        '''Annotations to add to the Pod template metadata.

        Common for Prometheus, Istio, backup policies, etc.

        :default: - no additional annotations

        Example::

            { 'prometheus.io/scrape': 'true', 'prometheus.io/port': '8080' }
        '''
        result = self._values.get("pod_annotations")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

    @builtins.property
    def readiness_enabled(self) -> typing.Optional[builtins.bool]:
        '''Enable readiness probe for the container.

        Readiness probes determine when a container is ready to accept traffic.

        :default: true
        '''
        result = self._values.get("readiness_enabled")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def readiness_failure_threshold(self) -> typing.Optional[jsii.Number]:
        '''Minimum consecutive failures for the readiness probe to be considered failed.

        :default: 3
        '''
        result = self._values.get("readiness_failure_threshold")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def readiness_initial_delay_seconds(self) -> typing.Optional[jsii.Number]:
        '''Number of seconds after container start before readiness probe is initiated.

        :default: 10
        '''
        result = self._values.get("readiness_initial_delay_seconds")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def readiness_period_seconds(self) -> typing.Optional[jsii.Number]:
        '''How often (in seconds) to perform the readiness probe.

        :default: 10
        '''
        result = self._values.get("readiness_period_seconds")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def readiness_success_threshold(self) -> typing.Optional[jsii.Number]:
        '''Minimum consecutive successes for the readiness probe to be considered successful.

        :default: 1
        '''
        result = self._values.get("readiness_success_threshold")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def readiness_timeout_seconds(self) -> typing.Optional[jsii.Number]:
        '''Number of seconds after which the readiness probe times out.

        :default: 15
        '''
        result = self._values.get("readiness_timeout_seconds")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def replicas(self) -> typing.Optional[jsii.Number]:
        '''Number of pod replicas to run.

        :default: 2
        '''
        result = self._values.get("replicas")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def request_cpu(self) -> typing.Optional[builtins.str]:
        '''CPU request for the container.

        :default: '200m'

        Example::

            '200m' or '0.5'
        '''
        result = self._values.get("request_cpu")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def request_memory(self) -> typing.Optional[builtins.str]:
        '''Memory request for the container.

        :default: '256Mi'

        Example::

            '256Mi' or '512Mi'
        '''
        result = self._values.get("request_memory")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def service_annotations(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        '''Annotations to add to the Service metadata.

        Common for external-dns, load balancers, service mesh, etc.

        :default: - no additional annotations

        Example::

            { 'external-dns.alpha.kubernetes.io/hostname': 'plone.example.com' }
        '''
        result = self._values.get("service_annotations")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

    @builtins.property
    def servicemonitor(self) -> typing.Optional[builtins.bool]:
        '''Enable Prometheus ServiceMonitor for metrics collection.

        Requires Prometheus Operator to be installed in the cluster.
        When enabled, a ServiceMonitor resource will be created to scrape metrics.

        :default: false
        '''
        result = self._values.get("servicemonitor")
        return typing.cast(typing.Optional[builtins.bool], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "PloneBaseOptions(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class PloneHttpcache(
    _constructs_77d1e7e8.Construct,
    metaclass=jsii.JSIIMeta,
    jsii_type="@bluedynamics/cdk8s-plone.PloneHttpcache",
):
    '''PloneHttpcache construct for deploying Varnish HTTP caching layer.

    Uses the mittwald/kube-httpcache Helm chart to deploy Varnish as a
    caching proxy in front of Plone backend and/or frontend services.

    The cache automatically connects to the Plone services and provides
    HTTP cache invalidation capabilities.

    Example::

        const plone = new Plone(chart, 'plone');
        const cache = new PloneHttpcache(chart, 'cache', {
          plone: plone,
          existingSecret: 'varnish-secret',
        });
    '''

    def __init__(
        self,
        scope: "_constructs_77d1e7e8.Construct",
        id: builtins.str,
        *,
        plone: "Plone",
        app_version: typing.Optional[builtins.str] = None,
        chart_version: typing.Optional[builtins.str] = None,
        existing_secret: typing.Optional[builtins.str] = None,
        exporter_enabled: typing.Optional[builtins.bool] = None,
        extra_env_vars: typing.Optional[typing.Sequence[typing.Union["HttpcacheEnvVar", typing.Dict[builtins.str, typing.Any]]]] = None,
        limit_cpu: typing.Optional[builtins.str] = None,
        limit_memory: typing.Optional[builtins.str] = None,
        replicas: typing.Optional[jsii.Number] = None,
        request_cpu: typing.Optional[builtins.str] = None,
        request_memory: typing.Optional[builtins.str] = None,
        servicemonitor: typing.Optional[builtins.bool] = None,
        tolerations: typing.Optional[typing.Sequence[typing.Union["HttpcacheToleration", typing.Dict[builtins.str, typing.Any]]]] = None,
        varnish_vcl: typing.Optional[builtins.str] = None,
        varnish_vcl_file: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param scope: -
        :param id: -
        :param plone: The Plone construct to attach the HTTP cache to. The cache will automatically connect to the backend and frontend services.
        :param app_version: Version of the kube-httpcache Container Image to use. If not specified, the latest version from the repository will be used. Default: undefined (chartVersion = with each chart release there is an image release too )
        :param chart_version: Version of the kube-httpcache Helm chart to use. If not specified, the latest version from the repository will be used. Default: undefined (latest)
        :param existing_secret: Name of an existing Kubernetes secret containing Varnish admin credentials. The secret should be created separately in the same namespace. Default: - undefined (no existing secret)
        :param exporter_enabled: Enable the Prometheus exporter for Varnish metrics. When enabled, the exporter sidecar container will be deployed alongside Varnish. Default: true
        :param extra_env_vars: Additional environment variables to pass to the kube-httpcache container. These are appended to the built-in env vars (BACKEND_SERVICE_NAME, etc.) and can be referenced in VCL templates using Go template syntax: {{ .Env.VAR_NAME }} Default: - no additional env vars
        :param limit_cpu: CPU limit for Varnish pods. Default: '500m'
        :param limit_memory: Memory limit for Varnish pods. Default: '500Mi'
        :param replicas: Number of Varnish pod replicas to run. Default: 2
        :param request_cpu: CPU request for Varnish pods. Default: '100m'
        :param request_memory: Memory request for Varnish pods. Default: '100Mi'
        :param servicemonitor: Enable Prometheus ServiceMonitor for metrics collection. Requires Prometheus Operator to be installed in the cluster. Default: false
        :param tolerations: Tolerations for the Varnish pods. Use this to allow scheduling on nodes with specific taints, e.g. nodes tainted with kubernetes.io/arch=amd64:NoSchedule. Default: - no tolerations
        :param varnish_vcl: Varnish VCL configuration as a string. If provided, this takes precedence over varnishVclFile. Default: - loaded from varnishVclFile or default config file
        :param varnish_vcl_file: Path to a Varnish VCL configuration file. If not provided, uses the default VCL file included in the library. Default: - uses default config/varnish.tpl.vcl
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f7f85fe682616b18a7851bccc28d7021f541060ebc9eba02965066fd28589e69)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        options = PloneHttpcacheOptions(
            plone=plone,
            app_version=app_version,
            chart_version=chart_version,
            existing_secret=existing_secret,
            exporter_enabled=exporter_enabled,
            extra_env_vars=extra_env_vars,
            limit_cpu=limit_cpu,
            limit_memory=limit_memory,
            replicas=replicas,
            request_cpu=request_cpu,
            request_memory=request_memory,
            servicemonitor=servicemonitor,
            tolerations=tolerations,
            varnish_vcl=varnish_vcl,
            varnish_vcl_file=varnish_vcl_file,
        )

        jsii.create(self.__class__, self, [scope, id, options])

    @builtins.property
    @jsii.member(jsii_name="httpcacheServiceName")
    def httpcache_service_name(self) -> builtins.str:
        '''Name of the Varnish service created by the Helm chart.

        Use this to reference the cache service from ingress or other constructs.
        '''
        return typing.cast(builtins.str, jsii.get(self, "httpcacheServiceName"))


@jsii.data_type(
    jsii_type="@bluedynamics/cdk8s-plone.PloneHttpcacheOptions",
    jsii_struct_bases=[],
    name_mapping={
        "plone": "plone",
        "app_version": "appVersion",
        "chart_version": "chartVersion",
        "existing_secret": "existingSecret",
        "exporter_enabled": "exporterEnabled",
        "extra_env_vars": "extraEnvVars",
        "limit_cpu": "limitCpu",
        "limit_memory": "limitMemory",
        "replicas": "replicas",
        "request_cpu": "requestCpu",
        "request_memory": "requestMemory",
        "servicemonitor": "servicemonitor",
        "tolerations": "tolerations",
        "varnish_vcl": "varnishVcl",
        "varnish_vcl_file": "varnishVclFile",
    },
)
class PloneHttpcacheOptions:
    def __init__(
        self,
        *,
        plone: "Plone",
        app_version: typing.Optional[builtins.str] = None,
        chart_version: typing.Optional[builtins.str] = None,
        existing_secret: typing.Optional[builtins.str] = None,
        exporter_enabled: typing.Optional[builtins.bool] = None,
        extra_env_vars: typing.Optional[typing.Sequence[typing.Union["HttpcacheEnvVar", typing.Dict[builtins.str, typing.Any]]]] = None,
        limit_cpu: typing.Optional[builtins.str] = None,
        limit_memory: typing.Optional[builtins.str] = None,
        replicas: typing.Optional[jsii.Number] = None,
        request_cpu: typing.Optional[builtins.str] = None,
        request_memory: typing.Optional[builtins.str] = None,
        servicemonitor: typing.Optional[builtins.bool] = None,
        tolerations: typing.Optional[typing.Sequence[typing.Union["HttpcacheToleration", typing.Dict[builtins.str, typing.Any]]]] = None,
        varnish_vcl: typing.Optional[builtins.str] = None,
        varnish_vcl_file: typing.Optional[builtins.str] = None,
    ) -> None:
        '''Configuration options for PloneHttpcache (Varnish caching layer).

        :param plone: The Plone construct to attach the HTTP cache to. The cache will automatically connect to the backend and frontend services.
        :param app_version: Version of the kube-httpcache Container Image to use. If not specified, the latest version from the repository will be used. Default: undefined (chartVersion = with each chart release there is an image release too )
        :param chart_version: Version of the kube-httpcache Helm chart to use. If not specified, the latest version from the repository will be used. Default: undefined (latest)
        :param existing_secret: Name of an existing Kubernetes secret containing Varnish admin credentials. The secret should be created separately in the same namespace. Default: - undefined (no existing secret)
        :param exporter_enabled: Enable the Prometheus exporter for Varnish metrics. When enabled, the exporter sidecar container will be deployed alongside Varnish. Default: true
        :param extra_env_vars: Additional environment variables to pass to the kube-httpcache container. These are appended to the built-in env vars (BACKEND_SERVICE_NAME, etc.) and can be referenced in VCL templates using Go template syntax: {{ .Env.VAR_NAME }} Default: - no additional env vars
        :param limit_cpu: CPU limit for Varnish pods. Default: '500m'
        :param limit_memory: Memory limit for Varnish pods. Default: '500Mi'
        :param replicas: Number of Varnish pod replicas to run. Default: 2
        :param request_cpu: CPU request for Varnish pods. Default: '100m'
        :param request_memory: Memory request for Varnish pods. Default: '100Mi'
        :param servicemonitor: Enable Prometheus ServiceMonitor for metrics collection. Requires Prometheus Operator to be installed in the cluster. Default: false
        :param tolerations: Tolerations for the Varnish pods. Use this to allow scheduling on nodes with specific taints, e.g. nodes tainted with kubernetes.io/arch=amd64:NoSchedule. Default: - no tolerations
        :param varnish_vcl: Varnish VCL configuration as a string. If provided, this takes precedence over varnishVclFile. Default: - loaded from varnishVclFile or default config file
        :param varnish_vcl_file: Path to a Varnish VCL configuration file. If not provided, uses the default VCL file included in the library. Default: - uses default config/varnish.tpl.vcl
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0f974bf721e34d8993ba90020605bc5e09424793236af8b8c5a9bb9a63f1974a)
            check_type(argname="argument plone", value=plone, expected_type=type_hints["plone"])
            check_type(argname="argument app_version", value=app_version, expected_type=type_hints["app_version"])
            check_type(argname="argument chart_version", value=chart_version, expected_type=type_hints["chart_version"])
            check_type(argname="argument existing_secret", value=existing_secret, expected_type=type_hints["existing_secret"])
            check_type(argname="argument exporter_enabled", value=exporter_enabled, expected_type=type_hints["exporter_enabled"])
            check_type(argname="argument extra_env_vars", value=extra_env_vars, expected_type=type_hints["extra_env_vars"])
            check_type(argname="argument limit_cpu", value=limit_cpu, expected_type=type_hints["limit_cpu"])
            check_type(argname="argument limit_memory", value=limit_memory, expected_type=type_hints["limit_memory"])
            check_type(argname="argument replicas", value=replicas, expected_type=type_hints["replicas"])
            check_type(argname="argument request_cpu", value=request_cpu, expected_type=type_hints["request_cpu"])
            check_type(argname="argument request_memory", value=request_memory, expected_type=type_hints["request_memory"])
            check_type(argname="argument servicemonitor", value=servicemonitor, expected_type=type_hints["servicemonitor"])
            check_type(argname="argument tolerations", value=tolerations, expected_type=type_hints["tolerations"])
            check_type(argname="argument varnish_vcl", value=varnish_vcl, expected_type=type_hints["varnish_vcl"])
            check_type(argname="argument varnish_vcl_file", value=varnish_vcl_file, expected_type=type_hints["varnish_vcl_file"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "plone": plone,
        }
        if app_version is not None:
            self._values["app_version"] = app_version
        if chart_version is not None:
            self._values["chart_version"] = chart_version
        if existing_secret is not None:
            self._values["existing_secret"] = existing_secret
        if exporter_enabled is not None:
            self._values["exporter_enabled"] = exporter_enabled
        if extra_env_vars is not None:
            self._values["extra_env_vars"] = extra_env_vars
        if limit_cpu is not None:
            self._values["limit_cpu"] = limit_cpu
        if limit_memory is not None:
            self._values["limit_memory"] = limit_memory
        if replicas is not None:
            self._values["replicas"] = replicas
        if request_cpu is not None:
            self._values["request_cpu"] = request_cpu
        if request_memory is not None:
            self._values["request_memory"] = request_memory
        if servicemonitor is not None:
            self._values["servicemonitor"] = servicemonitor
        if tolerations is not None:
            self._values["tolerations"] = tolerations
        if varnish_vcl is not None:
            self._values["varnish_vcl"] = varnish_vcl
        if varnish_vcl_file is not None:
            self._values["varnish_vcl_file"] = varnish_vcl_file

    @builtins.property
    def plone(self) -> "Plone":
        '''The Plone construct to attach the HTTP cache to.

        The cache will automatically connect to the backend and frontend services.
        '''
        result = self._values.get("plone")
        assert result is not None, "Required property 'plone' is missing"
        return typing.cast("Plone", result)

    @builtins.property
    def app_version(self) -> typing.Optional[builtins.str]:
        '''Version of the kube-httpcache Container Image to use.

        If not specified, the latest version from the repository will be used.

        :default: undefined (chartVersion = with each chart release there is an image release too )
        '''
        result = self._values.get("app_version")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def chart_version(self) -> typing.Optional[builtins.str]:
        '''Version of the kube-httpcache Helm chart to use.

        If not specified, the latest version from the repository will be used.

        :default: undefined (latest)
        '''
        result = self._values.get("chart_version")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def existing_secret(self) -> typing.Optional[builtins.str]:
        '''Name of an existing Kubernetes secret containing Varnish admin credentials.

        The secret should be created separately in the same namespace.

        :default: - undefined (no existing secret)
        '''
        result = self._values.get("existing_secret")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def exporter_enabled(self) -> typing.Optional[builtins.bool]:
        '''Enable the Prometheus exporter for Varnish metrics.

        When enabled, the exporter sidecar container will be deployed alongside Varnish.

        :default: true
        '''
        result = self._values.get("exporter_enabled")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def extra_env_vars(self) -> typing.Optional[typing.List["HttpcacheEnvVar"]]:
        '''Additional environment variables to pass to the kube-httpcache container.

        These are appended to the built-in env vars (BACKEND_SERVICE_NAME, etc.)
        and can be referenced in VCL templates using Go template syntax: {{ .Env.VAR_NAME }}

        :default: - no additional env vars
        '''
        result = self._values.get("extra_env_vars")
        return typing.cast(typing.Optional[typing.List["HttpcacheEnvVar"]], result)

    @builtins.property
    def limit_cpu(self) -> typing.Optional[builtins.str]:
        '''CPU limit for Varnish pods.

        :default: '500m'
        '''
        result = self._values.get("limit_cpu")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def limit_memory(self) -> typing.Optional[builtins.str]:
        '''Memory limit for Varnish pods.

        :default: '500Mi'
        '''
        result = self._values.get("limit_memory")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def replicas(self) -> typing.Optional[jsii.Number]:
        '''Number of Varnish pod replicas to run.

        :default: 2
        '''
        result = self._values.get("replicas")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def request_cpu(self) -> typing.Optional[builtins.str]:
        '''CPU request for Varnish pods.

        :default: '100m'
        '''
        result = self._values.get("request_cpu")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def request_memory(self) -> typing.Optional[builtins.str]:
        '''Memory request for Varnish pods.

        :default: '100Mi'
        '''
        result = self._values.get("request_memory")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def servicemonitor(self) -> typing.Optional[builtins.bool]:
        '''Enable Prometheus ServiceMonitor for metrics collection.

        Requires Prometheus Operator to be installed in the cluster.

        :default: false
        '''
        result = self._values.get("servicemonitor")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def tolerations(self) -> typing.Optional[typing.List["HttpcacheToleration"]]:
        '''Tolerations for the Varnish pods.

        Use this to allow scheduling on nodes with specific taints,
        e.g. nodes tainted with kubernetes.io/arch=amd64:NoSchedule.

        :default: - no tolerations
        '''
        result = self._values.get("tolerations")
        return typing.cast(typing.Optional[typing.List["HttpcacheToleration"]], result)

    @builtins.property
    def varnish_vcl(self) -> typing.Optional[builtins.str]:
        '''Varnish VCL configuration as a string.

        If provided, this takes precedence over varnishVclFile.

        :default: - loaded from varnishVclFile or default config file
        '''
        result = self._values.get("varnish_vcl")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def varnish_vcl_file(self) -> typing.Optional[builtins.str]:
        '''Path to a Varnish VCL configuration file.

        If not provided, uses the default VCL file included in the library.

        :default: - uses default config/varnish.tpl.vcl
        '''
        result = self._values.get("varnish_vcl_file")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "PloneHttpcacheOptions(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@bluedynamics/cdk8s-plone.PloneOptions",
    jsii_struct_bases=[],
    name_mapping={
        "backend": "backend",
        "frontend": "frontend",
        "image_pull_secrets": "imagePullSecrets",
        "site_id": "siteId",
        "variant": "variant",
        "version": "version",
    },
)
class PloneOptions:
    def __init__(
        self,
        *,
        backend: typing.Optional[typing.Union["PloneBaseOptions", typing.Dict[builtins.str, typing.Any]]] = None,
        frontend: typing.Optional[typing.Union["PloneBaseOptions", typing.Dict[builtins.str, typing.Any]]] = None,
        image_pull_secrets: typing.Optional[typing.Sequence[builtins.str]] = None,
        site_id: typing.Optional[builtins.str] = None,
        variant: typing.Optional["PloneVariant"] = None,
        version: typing.Optional[builtins.str] = None,
    ) -> None:
        '''Main configuration options for Plone deployment.

        :param backend: Backend (Plone API) configuration. Default: {} (uses default values from PloneBaseOptions)
        :param frontend: Frontend (Volto) configuration. Only used when variant is PloneVariant.VOLTO. Default: {} (uses default values from PloneBaseOptions)
        :param image_pull_secrets: Names of Kubernetes secrets to use for pulling private container images. These secrets must exist in the same namespace as the deployment. Default: [] (no image pull secrets)
        :param site_id: Plone site ID in the ZODB. This is used to construct the internal API path for Volto frontend. Default: 'Plone'
        :param variant: Plone deployment variant to use. Default: PloneVariant.VOLTO
        :param version: Version string for labeling the deployment. This is used in Kubernetes labels and doesn't affect the actual image versions. Default: 'undefined'
        '''
        if isinstance(backend, dict):
            backend = PloneBaseOptions(**backend)
        if isinstance(frontend, dict):
            frontend = PloneBaseOptions(**frontend)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d92a415ce6a72ab45cd3d3e169acc7fc8156c275bc6268fa1eed4110e990c22a)
            check_type(argname="argument backend", value=backend, expected_type=type_hints["backend"])
            check_type(argname="argument frontend", value=frontend, expected_type=type_hints["frontend"])
            check_type(argname="argument image_pull_secrets", value=image_pull_secrets, expected_type=type_hints["image_pull_secrets"])
            check_type(argname="argument site_id", value=site_id, expected_type=type_hints["site_id"])
            check_type(argname="argument variant", value=variant, expected_type=type_hints["variant"])
            check_type(argname="argument version", value=version, expected_type=type_hints["version"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if backend is not None:
            self._values["backend"] = backend
        if frontend is not None:
            self._values["frontend"] = frontend
        if image_pull_secrets is not None:
            self._values["image_pull_secrets"] = image_pull_secrets
        if site_id is not None:
            self._values["site_id"] = site_id
        if variant is not None:
            self._values["variant"] = variant
        if version is not None:
            self._values["version"] = version

    @builtins.property
    def backend(self) -> typing.Optional["PloneBaseOptions"]:
        '''Backend (Plone API) configuration.

        :default: {} (uses default values from PloneBaseOptions)
        '''
        result = self._values.get("backend")
        return typing.cast(typing.Optional["PloneBaseOptions"], result)

    @builtins.property
    def frontend(self) -> typing.Optional["PloneBaseOptions"]:
        '''Frontend (Volto) configuration.

        Only used when variant is PloneVariant.VOLTO.

        :default: {} (uses default values from PloneBaseOptions)
        '''
        result = self._values.get("frontend")
        return typing.cast(typing.Optional["PloneBaseOptions"], result)

    @builtins.property
    def image_pull_secrets(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Names of Kubernetes secrets to use for pulling private container images.

        These secrets must exist in the same namespace as the deployment.

        :default: [] (no image pull secrets)

        Example::

            ['my-registry-secret']
        '''
        result = self._values.get("image_pull_secrets")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def site_id(self) -> typing.Optional[builtins.str]:
        '''Plone site ID in the ZODB.

        This is used to construct the internal API path for Volto frontend.

        :default: 'Plone'
        '''
        result = self._values.get("site_id")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def variant(self) -> typing.Optional["PloneVariant"]:
        '''Plone deployment variant to use.

        :default: PloneVariant.VOLTO
        '''
        result = self._values.get("variant")
        return typing.cast(typing.Optional["PloneVariant"], result)

    @builtins.property
    def version(self) -> typing.Optional[builtins.str]:
        '''Version string for labeling the deployment.

        This is used in Kubernetes labels and doesn't affect the actual image versions.

        :default: 'undefined'
        '''
        result = self._values.get("version")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "PloneOptions(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.enum(jsii_type="@bluedynamics/cdk8s-plone.PloneVariant")
class PloneVariant(enum.Enum):
    '''Plone deployment variants.'''

    VOLTO = "VOLTO"
    '''Volto variant: ReactJS frontend (Volto) with REST API backend.

    Deploys both frontend and backend services.
    '''
    CLASSICUI = "CLASSICUI"
    '''Classic UI variant: Traditional Plone with server-side rendering.

    Deploys only the backend service.
    '''


class PloneVinylCache(
    _constructs_77d1e7e8.Construct,
    metaclass=jsii.JSIIMeta,
    jsii_type="@bluedynamics/cdk8s-plone.PloneVinylCache",
):
    '''PloneVinylCache construct for deploying Varnish Cache via cloud-vinyl operator.

    Creates a VinylCache custom resource with Plone backend/frontend services
    auto-configured as backends. The cloud-vinyl operator manages the full
    Varnish lifecycle including VCL generation, agent delivery, and monitoring.

    Requires the cloud-vinyl operator to be installed in the cluster.

    Example::

        const plone = new Plone(chart, 'plone');
        const cache = new PloneVinylCache(chart, 'cache', {
          plone: plone,
          replicas: 2,
        });
        // Use cache.vinylCacheServiceName for IngressRoute
    '''

    def __init__(
        self,
        scope: "_constructs_77d1e7e8.Construct",
        id: builtins.str,
        *,
        plone: "Plone",
        director: typing.Optional[builtins.str] = None,
        extra_backends: typing.Optional[typing.Sequence[typing.Union["VinylCacheBackend", typing.Dict[builtins.str, typing.Any]]]] = None,
        image: typing.Optional[builtins.str] = None,
        invalidation: typing.Optional[builtins.bool] = None,
        limit_cpu: typing.Optional[builtins.str] = None,
        limit_memory: typing.Optional[builtins.str] = None,
        monitoring: typing.Optional[builtins.bool] = None,
        node_selector: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        replicas: typing.Optional[jsii.Number] = None,
        request_cpu: typing.Optional[builtins.str] = None,
        request_memory: typing.Optional[builtins.str] = None,
        tolerations: typing.Optional[typing.Sequence[typing.Union["VinylCacheToleration", typing.Dict[builtins.str, typing.Any]]]] = None,
        vcl_backend_error_snippet: typing.Optional[builtins.str] = None,
        vcl_backend_fetch_snippet: typing.Optional[builtins.str] = None,
        vcl_backend_response_snippet: typing.Optional[builtins.str] = None,
        vcl_deliver_snippet: typing.Optional[builtins.str] = None,
        vcl_fini_snippet: typing.Optional[builtins.str] = None,
        vcl_hash_snippet: typing.Optional[builtins.str] = None,
        vcl_hit_snippet: typing.Optional[builtins.str] = None,
        vcl_init_snippet: typing.Optional[builtins.str] = None,
        vcl_miss_snippet: typing.Optional[builtins.str] = None,
        vcl_pass_snippet: typing.Optional[builtins.str] = None,
        vcl_pipe_snippet: typing.Optional[builtins.str] = None,
        vcl_purge_snippet: typing.Optional[builtins.str] = None,
        vcl_recv_snippet: typing.Optional[builtins.str] = None,
        vcl_synth_snippet: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param scope: -
        :param id: -
        :param plone: The Plone construct to attach the cache to. Backends are auto-configured from the Plone services.
        :param director: Director type for load distribution. Default: 'shard'
        :param extra_backends: Additional backends to add after the auto-generated Plone backends. Uses the same backend type structure as the VinylCache CRD. Default: - no extra backends
        :param image: Container image for the Varnish pods. Default: 'varnish:7.6'
        :param invalidation: Enable cache invalidation (PURGE, BAN, xkey). Default: true
        :param limit_cpu: CPU limit for Varnish pods. Default: '500m'
        :param limit_memory: Memory limit for Varnish pods. Default: '512Mi'
        :param monitoring: Enable Prometheus monitoring (metrics + ServiceMonitor). Default: false
        :param node_selector: Node selector labels for the Varnish pods. Constrains pods to nodes matching all specified labels. Default: - no node selector
        :param replicas: Number of Varnish pod replicas. Default: 2
        :param request_cpu: CPU request for Varnish pods. Default: '100m'
        :param request_memory: Memory request for Varnish pods. Default: '256Mi'
        :param tolerations: Tolerations for the Varnish pods. Default: - no tolerations
        :param vcl_backend_error_snippet: Custom VCL snippet for vcl_backend_error subroutine. Default: - no snippet
        :param vcl_backend_fetch_snippet: Custom VCL snippet for vcl_backend_fetch subroutine. Default: - no snippet
        :param vcl_backend_response_snippet: Custom VCL snippet for vcl_backend_response subroutine. Replaces the default Plone backend_response snippet. Default: - uses built-in plone-vinyl-backend-response.vcl
        :param vcl_deliver_snippet: Custom VCL snippet for vcl_deliver subroutine. Default: - no snippet
        :param vcl_fini_snippet: Custom VCL snippet for vcl_fini subroutine. Default: - no snippet
        :param vcl_hash_snippet: Custom VCL snippet for vcl_hash subroutine. Default: - no snippet
        :param vcl_hit_snippet: Custom VCL snippet for vcl_hit subroutine. Default: - no snippet
        :param vcl_init_snippet: Custom VCL snippet for vcl_init subroutine. Default: - no snippet
        :param vcl_miss_snippet: Custom VCL snippet for vcl_miss subroutine. Default: - no snippet
        :param vcl_pass_snippet: Custom VCL snippet for vcl_pass subroutine. Default: - no snippet
        :param vcl_pipe_snippet: Custom VCL snippet for vcl_pipe subroutine. Default: - no snippet
        :param vcl_purge_snippet: Custom VCL snippet for vcl_purge subroutine. Default: - no snippet
        :param vcl_recv_snippet: Custom VCL snippet for vcl_recv subroutine. Replaces the default Plone recv snippet. Default: - uses built-in plone-vinyl-recv.vcl
        :param vcl_synth_snippet: Custom VCL snippet for vcl_synth subroutine. Default: - no snippet
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__93447ae1ad213e9afd98e1d8f3560fa78ec1f1282da39e445b9a89debffe0ca1)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        options = PloneVinylCacheOptions(
            plone=plone,
            director=director,
            extra_backends=extra_backends,
            image=image,
            invalidation=invalidation,
            limit_cpu=limit_cpu,
            limit_memory=limit_memory,
            monitoring=monitoring,
            node_selector=node_selector,
            replicas=replicas,
            request_cpu=request_cpu,
            request_memory=request_memory,
            tolerations=tolerations,
            vcl_backend_error_snippet=vcl_backend_error_snippet,
            vcl_backend_fetch_snippet=vcl_backend_fetch_snippet,
            vcl_backend_response_snippet=vcl_backend_response_snippet,
            vcl_deliver_snippet=vcl_deliver_snippet,
            vcl_fini_snippet=vcl_fini_snippet,
            vcl_hash_snippet=vcl_hash_snippet,
            vcl_hit_snippet=vcl_hit_snippet,
            vcl_init_snippet=vcl_init_snippet,
            vcl_miss_snippet=vcl_miss_snippet,
            vcl_pass_snippet=vcl_pass_snippet,
            vcl_pipe_snippet=vcl_pipe_snippet,
            vcl_purge_snippet=vcl_purge_snippet,
            vcl_recv_snippet=vcl_recv_snippet,
            vcl_synth_snippet=vcl_synth_snippet,
        )

        jsii.create(self.__class__, self, [scope, id, options])

    @builtins.property
    @jsii.member(jsii_name="vinylCacheServiceName")
    def vinyl_cache_service_name(self) -> builtins.str:
        '''Name of the VinylCache service created by the operator.

        Use this to reference the cache service from ingress or other constructs.
        '''
        return typing.cast(builtins.str, jsii.get(self, "vinylCacheServiceName"))


@jsii.data_type(
    jsii_type="@bluedynamics/cdk8s-plone.PloneVinylCacheOptions",
    jsii_struct_bases=[],
    name_mapping={
        "plone": "plone",
        "director": "director",
        "extra_backends": "extraBackends",
        "image": "image",
        "invalidation": "invalidation",
        "limit_cpu": "limitCpu",
        "limit_memory": "limitMemory",
        "monitoring": "monitoring",
        "node_selector": "nodeSelector",
        "replicas": "replicas",
        "request_cpu": "requestCpu",
        "request_memory": "requestMemory",
        "tolerations": "tolerations",
        "vcl_backend_error_snippet": "vclBackendErrorSnippet",
        "vcl_backend_fetch_snippet": "vclBackendFetchSnippet",
        "vcl_backend_response_snippet": "vclBackendResponseSnippet",
        "vcl_deliver_snippet": "vclDeliverSnippet",
        "vcl_fini_snippet": "vclFiniSnippet",
        "vcl_hash_snippet": "vclHashSnippet",
        "vcl_hit_snippet": "vclHitSnippet",
        "vcl_init_snippet": "vclInitSnippet",
        "vcl_miss_snippet": "vclMissSnippet",
        "vcl_pass_snippet": "vclPassSnippet",
        "vcl_pipe_snippet": "vclPipeSnippet",
        "vcl_purge_snippet": "vclPurgeSnippet",
        "vcl_recv_snippet": "vclRecvSnippet",
        "vcl_synth_snippet": "vclSynthSnippet",
    },
)
class PloneVinylCacheOptions:
    def __init__(
        self,
        *,
        plone: "Plone",
        director: typing.Optional[builtins.str] = None,
        extra_backends: typing.Optional[typing.Sequence[typing.Union["VinylCacheBackend", typing.Dict[builtins.str, typing.Any]]]] = None,
        image: typing.Optional[builtins.str] = None,
        invalidation: typing.Optional[builtins.bool] = None,
        limit_cpu: typing.Optional[builtins.str] = None,
        limit_memory: typing.Optional[builtins.str] = None,
        monitoring: typing.Optional[builtins.bool] = None,
        node_selector: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        replicas: typing.Optional[jsii.Number] = None,
        request_cpu: typing.Optional[builtins.str] = None,
        request_memory: typing.Optional[builtins.str] = None,
        tolerations: typing.Optional[typing.Sequence[typing.Union["VinylCacheToleration", typing.Dict[builtins.str, typing.Any]]]] = None,
        vcl_backend_error_snippet: typing.Optional[builtins.str] = None,
        vcl_backend_fetch_snippet: typing.Optional[builtins.str] = None,
        vcl_backend_response_snippet: typing.Optional[builtins.str] = None,
        vcl_deliver_snippet: typing.Optional[builtins.str] = None,
        vcl_fini_snippet: typing.Optional[builtins.str] = None,
        vcl_hash_snippet: typing.Optional[builtins.str] = None,
        vcl_hit_snippet: typing.Optional[builtins.str] = None,
        vcl_init_snippet: typing.Optional[builtins.str] = None,
        vcl_miss_snippet: typing.Optional[builtins.str] = None,
        vcl_pass_snippet: typing.Optional[builtins.str] = None,
        vcl_pipe_snippet: typing.Optional[builtins.str] = None,
        vcl_purge_snippet: typing.Optional[builtins.str] = None,
        vcl_recv_snippet: typing.Optional[builtins.str] = None,
        vcl_synth_snippet: typing.Optional[builtins.str] = None,
    ) -> None:
        '''Configuration options for PloneVinylCache (cloud-vinyl operator).

        Creates a VinylCache custom resource that the cloud-vinyl operator
        reconciles into a Varnish Cache cluster with agent-based VCL delivery.

        Requires the cloud-vinyl operator to be installed in the cluster.

        :param plone: The Plone construct to attach the cache to. Backends are auto-configured from the Plone services.
        :param director: Director type for load distribution. Default: 'shard'
        :param extra_backends: Additional backends to add after the auto-generated Plone backends. Uses the same backend type structure as the VinylCache CRD. Default: - no extra backends
        :param image: Container image for the Varnish pods. Default: 'varnish:7.6'
        :param invalidation: Enable cache invalidation (PURGE, BAN, xkey). Default: true
        :param limit_cpu: CPU limit for Varnish pods. Default: '500m'
        :param limit_memory: Memory limit for Varnish pods. Default: '512Mi'
        :param monitoring: Enable Prometheus monitoring (metrics + ServiceMonitor). Default: false
        :param node_selector: Node selector labels for the Varnish pods. Constrains pods to nodes matching all specified labels. Default: - no node selector
        :param replicas: Number of Varnish pod replicas. Default: 2
        :param request_cpu: CPU request for Varnish pods. Default: '100m'
        :param request_memory: Memory request for Varnish pods. Default: '256Mi'
        :param tolerations: Tolerations for the Varnish pods. Default: - no tolerations
        :param vcl_backend_error_snippet: Custom VCL snippet for vcl_backend_error subroutine. Default: - no snippet
        :param vcl_backend_fetch_snippet: Custom VCL snippet for vcl_backend_fetch subroutine. Default: - no snippet
        :param vcl_backend_response_snippet: Custom VCL snippet for vcl_backend_response subroutine. Replaces the default Plone backend_response snippet. Default: - uses built-in plone-vinyl-backend-response.vcl
        :param vcl_deliver_snippet: Custom VCL snippet for vcl_deliver subroutine. Default: - no snippet
        :param vcl_fini_snippet: Custom VCL snippet for vcl_fini subroutine. Default: - no snippet
        :param vcl_hash_snippet: Custom VCL snippet for vcl_hash subroutine. Default: - no snippet
        :param vcl_hit_snippet: Custom VCL snippet for vcl_hit subroutine. Default: - no snippet
        :param vcl_init_snippet: Custom VCL snippet for vcl_init subroutine. Default: - no snippet
        :param vcl_miss_snippet: Custom VCL snippet for vcl_miss subroutine. Default: - no snippet
        :param vcl_pass_snippet: Custom VCL snippet for vcl_pass subroutine. Default: - no snippet
        :param vcl_pipe_snippet: Custom VCL snippet for vcl_pipe subroutine. Default: - no snippet
        :param vcl_purge_snippet: Custom VCL snippet for vcl_purge subroutine. Default: - no snippet
        :param vcl_recv_snippet: Custom VCL snippet for vcl_recv subroutine. Replaces the default Plone recv snippet. Default: - uses built-in plone-vinyl-recv.vcl
        :param vcl_synth_snippet: Custom VCL snippet for vcl_synth subroutine. Default: - no snippet
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a07a5185c68385a34a009fb9ed8ad052b517d97b7a5262adaaaf5580dcac27b5)
            check_type(argname="argument plone", value=plone, expected_type=type_hints["plone"])
            check_type(argname="argument director", value=director, expected_type=type_hints["director"])
            check_type(argname="argument extra_backends", value=extra_backends, expected_type=type_hints["extra_backends"])
            check_type(argname="argument image", value=image, expected_type=type_hints["image"])
            check_type(argname="argument invalidation", value=invalidation, expected_type=type_hints["invalidation"])
            check_type(argname="argument limit_cpu", value=limit_cpu, expected_type=type_hints["limit_cpu"])
            check_type(argname="argument limit_memory", value=limit_memory, expected_type=type_hints["limit_memory"])
            check_type(argname="argument monitoring", value=monitoring, expected_type=type_hints["monitoring"])
            check_type(argname="argument node_selector", value=node_selector, expected_type=type_hints["node_selector"])
            check_type(argname="argument replicas", value=replicas, expected_type=type_hints["replicas"])
            check_type(argname="argument request_cpu", value=request_cpu, expected_type=type_hints["request_cpu"])
            check_type(argname="argument request_memory", value=request_memory, expected_type=type_hints["request_memory"])
            check_type(argname="argument tolerations", value=tolerations, expected_type=type_hints["tolerations"])
            check_type(argname="argument vcl_backend_error_snippet", value=vcl_backend_error_snippet, expected_type=type_hints["vcl_backend_error_snippet"])
            check_type(argname="argument vcl_backend_fetch_snippet", value=vcl_backend_fetch_snippet, expected_type=type_hints["vcl_backend_fetch_snippet"])
            check_type(argname="argument vcl_backend_response_snippet", value=vcl_backend_response_snippet, expected_type=type_hints["vcl_backend_response_snippet"])
            check_type(argname="argument vcl_deliver_snippet", value=vcl_deliver_snippet, expected_type=type_hints["vcl_deliver_snippet"])
            check_type(argname="argument vcl_fini_snippet", value=vcl_fini_snippet, expected_type=type_hints["vcl_fini_snippet"])
            check_type(argname="argument vcl_hash_snippet", value=vcl_hash_snippet, expected_type=type_hints["vcl_hash_snippet"])
            check_type(argname="argument vcl_hit_snippet", value=vcl_hit_snippet, expected_type=type_hints["vcl_hit_snippet"])
            check_type(argname="argument vcl_init_snippet", value=vcl_init_snippet, expected_type=type_hints["vcl_init_snippet"])
            check_type(argname="argument vcl_miss_snippet", value=vcl_miss_snippet, expected_type=type_hints["vcl_miss_snippet"])
            check_type(argname="argument vcl_pass_snippet", value=vcl_pass_snippet, expected_type=type_hints["vcl_pass_snippet"])
            check_type(argname="argument vcl_pipe_snippet", value=vcl_pipe_snippet, expected_type=type_hints["vcl_pipe_snippet"])
            check_type(argname="argument vcl_purge_snippet", value=vcl_purge_snippet, expected_type=type_hints["vcl_purge_snippet"])
            check_type(argname="argument vcl_recv_snippet", value=vcl_recv_snippet, expected_type=type_hints["vcl_recv_snippet"])
            check_type(argname="argument vcl_synth_snippet", value=vcl_synth_snippet, expected_type=type_hints["vcl_synth_snippet"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "plone": plone,
        }
        if director is not None:
            self._values["director"] = director
        if extra_backends is not None:
            self._values["extra_backends"] = extra_backends
        if image is not None:
            self._values["image"] = image
        if invalidation is not None:
            self._values["invalidation"] = invalidation
        if limit_cpu is not None:
            self._values["limit_cpu"] = limit_cpu
        if limit_memory is not None:
            self._values["limit_memory"] = limit_memory
        if monitoring is not None:
            self._values["monitoring"] = monitoring
        if node_selector is not None:
            self._values["node_selector"] = node_selector
        if replicas is not None:
            self._values["replicas"] = replicas
        if request_cpu is not None:
            self._values["request_cpu"] = request_cpu
        if request_memory is not None:
            self._values["request_memory"] = request_memory
        if tolerations is not None:
            self._values["tolerations"] = tolerations
        if vcl_backend_error_snippet is not None:
            self._values["vcl_backend_error_snippet"] = vcl_backend_error_snippet
        if vcl_backend_fetch_snippet is not None:
            self._values["vcl_backend_fetch_snippet"] = vcl_backend_fetch_snippet
        if vcl_backend_response_snippet is not None:
            self._values["vcl_backend_response_snippet"] = vcl_backend_response_snippet
        if vcl_deliver_snippet is not None:
            self._values["vcl_deliver_snippet"] = vcl_deliver_snippet
        if vcl_fini_snippet is not None:
            self._values["vcl_fini_snippet"] = vcl_fini_snippet
        if vcl_hash_snippet is not None:
            self._values["vcl_hash_snippet"] = vcl_hash_snippet
        if vcl_hit_snippet is not None:
            self._values["vcl_hit_snippet"] = vcl_hit_snippet
        if vcl_init_snippet is not None:
            self._values["vcl_init_snippet"] = vcl_init_snippet
        if vcl_miss_snippet is not None:
            self._values["vcl_miss_snippet"] = vcl_miss_snippet
        if vcl_pass_snippet is not None:
            self._values["vcl_pass_snippet"] = vcl_pass_snippet
        if vcl_pipe_snippet is not None:
            self._values["vcl_pipe_snippet"] = vcl_pipe_snippet
        if vcl_purge_snippet is not None:
            self._values["vcl_purge_snippet"] = vcl_purge_snippet
        if vcl_recv_snippet is not None:
            self._values["vcl_recv_snippet"] = vcl_recv_snippet
        if vcl_synth_snippet is not None:
            self._values["vcl_synth_snippet"] = vcl_synth_snippet

    @builtins.property
    def plone(self) -> "Plone":
        '''The Plone construct to attach the cache to.

        Backends are auto-configured from the Plone services.
        '''
        result = self._values.get("plone")
        assert result is not None, "Required property 'plone' is missing"
        return typing.cast("Plone", result)

    @builtins.property
    def director(self) -> typing.Optional[builtins.str]:
        '''Director type for load distribution.

        :default: 'shard'
        '''
        result = self._values.get("director")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def extra_backends(self) -> typing.Optional[typing.List["VinylCacheBackend"]]:
        '''Additional backends to add after the auto-generated Plone backends.

        Uses the same backend type structure as the VinylCache CRD.

        :default: - no extra backends
        '''
        result = self._values.get("extra_backends")
        return typing.cast(typing.Optional[typing.List["VinylCacheBackend"]], result)

    @builtins.property
    def image(self) -> typing.Optional[builtins.str]:
        '''Container image for the Varnish pods.

        :default: 'varnish:7.6'
        '''
        result = self._values.get("image")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def invalidation(self) -> typing.Optional[builtins.bool]:
        '''Enable cache invalidation (PURGE, BAN, xkey).

        :default: true
        '''
        result = self._values.get("invalidation")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def limit_cpu(self) -> typing.Optional[builtins.str]:
        '''CPU limit for Varnish pods.

        :default: '500m'
        '''
        result = self._values.get("limit_cpu")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def limit_memory(self) -> typing.Optional[builtins.str]:
        '''Memory limit for Varnish pods.

        :default: '512Mi'
        '''
        result = self._values.get("limit_memory")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def monitoring(self) -> typing.Optional[builtins.bool]:
        '''Enable Prometheus monitoring (metrics + ServiceMonitor).

        :default: false
        '''
        result = self._values.get("monitoring")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def node_selector(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        '''Node selector labels for the Varnish pods.

        Constrains pods to nodes matching all specified labels.

        :default: - no node selector
        '''
        result = self._values.get("node_selector")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

    @builtins.property
    def replicas(self) -> typing.Optional[jsii.Number]:
        '''Number of Varnish pod replicas.

        :default: 2
        '''
        result = self._values.get("replicas")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def request_cpu(self) -> typing.Optional[builtins.str]:
        '''CPU request for Varnish pods.

        :default: '100m'
        '''
        result = self._values.get("request_cpu")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def request_memory(self) -> typing.Optional[builtins.str]:
        '''Memory request for Varnish pods.

        :default: '256Mi'
        '''
        result = self._values.get("request_memory")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def tolerations(self) -> typing.Optional[typing.List["VinylCacheToleration"]]:
        '''Tolerations for the Varnish pods.

        :default: - no tolerations
        '''
        result = self._values.get("tolerations")
        return typing.cast(typing.Optional[typing.List["VinylCacheToleration"]], result)

    @builtins.property
    def vcl_backend_error_snippet(self) -> typing.Optional[builtins.str]:
        '''Custom VCL snippet for vcl_backend_error subroutine.

        :default: - no snippet
        '''
        result = self._values.get("vcl_backend_error_snippet")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def vcl_backend_fetch_snippet(self) -> typing.Optional[builtins.str]:
        '''Custom VCL snippet for vcl_backend_fetch subroutine.

        :default: - no snippet
        '''
        result = self._values.get("vcl_backend_fetch_snippet")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def vcl_backend_response_snippet(self) -> typing.Optional[builtins.str]:
        '''Custom VCL snippet for vcl_backend_response subroutine.

        Replaces the default Plone backend_response snippet.

        :default: - uses built-in plone-vinyl-backend-response.vcl
        '''
        result = self._values.get("vcl_backend_response_snippet")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def vcl_deliver_snippet(self) -> typing.Optional[builtins.str]:
        '''Custom VCL snippet for vcl_deliver subroutine.

        :default: - no snippet
        '''
        result = self._values.get("vcl_deliver_snippet")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def vcl_fini_snippet(self) -> typing.Optional[builtins.str]:
        '''Custom VCL snippet for vcl_fini subroutine.

        :default: - no snippet
        '''
        result = self._values.get("vcl_fini_snippet")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def vcl_hash_snippet(self) -> typing.Optional[builtins.str]:
        '''Custom VCL snippet for vcl_hash subroutine.

        :default: - no snippet
        '''
        result = self._values.get("vcl_hash_snippet")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def vcl_hit_snippet(self) -> typing.Optional[builtins.str]:
        '''Custom VCL snippet for vcl_hit subroutine.

        :default: - no snippet
        '''
        result = self._values.get("vcl_hit_snippet")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def vcl_init_snippet(self) -> typing.Optional[builtins.str]:
        '''Custom VCL snippet for vcl_init subroutine.

        :default: - no snippet
        '''
        result = self._values.get("vcl_init_snippet")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def vcl_miss_snippet(self) -> typing.Optional[builtins.str]:
        '''Custom VCL snippet for vcl_miss subroutine.

        :default: - no snippet
        '''
        result = self._values.get("vcl_miss_snippet")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def vcl_pass_snippet(self) -> typing.Optional[builtins.str]:
        '''Custom VCL snippet for vcl_pass subroutine.

        :default: - no snippet
        '''
        result = self._values.get("vcl_pass_snippet")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def vcl_pipe_snippet(self) -> typing.Optional[builtins.str]:
        '''Custom VCL snippet for vcl_pipe subroutine.

        :default: - no snippet
        '''
        result = self._values.get("vcl_pipe_snippet")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def vcl_purge_snippet(self) -> typing.Optional[builtins.str]:
        '''Custom VCL snippet for vcl_purge subroutine.

        :default: - no snippet
        '''
        result = self._values.get("vcl_purge_snippet")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def vcl_recv_snippet(self) -> typing.Optional[builtins.str]:
        '''Custom VCL snippet for vcl_recv subroutine.

        Replaces the default Plone recv snippet.

        :default: - uses built-in plone-vinyl-recv.vcl
        '''
        result = self._values.get("vcl_recv_snippet")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def vcl_synth_snippet(self) -> typing.Optional[builtins.str]:
        '''Custom VCL snippet for vcl_synth subroutine.

        :default: - no snippet
        '''
        result = self._values.get("vcl_synth_snippet")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "PloneVinylCacheOptions(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@bluedynamics/cdk8s-plone.VinylCacheBackend",
    jsii_struct_bases=[],
    name_mapping={
        "name": "name",
        "port": "port",
        "service_name": "serviceName",
        "probe": "probe",
        "weight": "weight",
    },
)
class VinylCacheBackend:
    def __init__(
        self,
        *,
        name: builtins.str,
        port: jsii.Number,
        service_name: builtins.str,
        probe: typing.Optional[typing.Union["VinylCacheBackendProbe", typing.Dict[builtins.str, typing.Any]]] = None,
        weight: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''An additional backend for the VinylCache.

        :param name: VCL identifier for this backend. Must match ^[a-zA-Z][a-zA-Z0-9_]*$.
        :param port: Port to use for this backend.
        :param service_name: Kubernetes Service name to use as backend.
        :param probe: Health probe configuration. Default: - no probe
        :param weight: Relative weight for the director. 0 means standby. Default: - operator default
        '''
        if isinstance(probe, dict):
            probe = VinylCacheBackendProbe(**probe)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__23be0f4fef2dff99ddd74b8384443782e3fe5032cd0368cdb5406251dce86e9a)
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument port", value=port, expected_type=type_hints["port"])
            check_type(argname="argument service_name", value=service_name, expected_type=type_hints["service_name"])
            check_type(argname="argument probe", value=probe, expected_type=type_hints["probe"])
            check_type(argname="argument weight", value=weight, expected_type=type_hints["weight"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "name": name,
            "port": port,
            "service_name": service_name,
        }
        if probe is not None:
            self._values["probe"] = probe
        if weight is not None:
            self._values["weight"] = weight

    @builtins.property
    def name(self) -> builtins.str:
        '''VCL identifier for this backend.

        Must match ^[a-zA-Z][a-zA-Z0-9_]*$.
        '''
        result = self._values.get("name")
        assert result is not None, "Required property 'name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def port(self) -> jsii.Number:
        '''Port to use for this backend.'''
        result = self._values.get("port")
        assert result is not None, "Required property 'port' is missing"
        return typing.cast(jsii.Number, result)

    @builtins.property
    def service_name(self) -> builtins.str:
        '''Kubernetes Service name to use as backend.'''
        result = self._values.get("service_name")
        assert result is not None, "Required property 'service_name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def probe(self) -> typing.Optional["VinylCacheBackendProbe"]:
        '''Health probe configuration.

        :default: - no probe
        '''
        result = self._values.get("probe")
        return typing.cast(typing.Optional["VinylCacheBackendProbe"], result)

    @builtins.property
    def weight(self) -> typing.Optional[jsii.Number]:
        '''Relative weight for the director.

        0 means standby.

        :default: - operator default
        '''
        result = self._values.get("weight")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "VinylCacheBackend(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@bluedynamics/cdk8s-plone.VinylCacheBackendProbe",
    jsii_struct_bases=[],
    name_mapping={
        "expected_response": "expectedResponse",
        "interval": "interval",
        "threshold": "threshold",
        "timeout": "timeout",
        "url": "url",
        "window": "window",
    },
)
class VinylCacheBackendProbe:
    def __init__(
        self,
        *,
        expected_response: typing.Optional[jsii.Number] = None,
        interval: typing.Optional[builtins.str] = None,
        threshold: typing.Optional[jsii.Number] = None,
        timeout: typing.Optional[builtins.str] = None,
        url: typing.Optional[builtins.str] = None,
        window: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''Health probe configuration for a VinylCache backend.

        :param expected_response: Expected HTTP response status code. Default: 200
        :param interval: How often to probe the backend. Default: '5s'
        :param threshold: Minimum successful probes within window for healthy status. Default: 8
        :param timeout: Maximum time to wait for a probe response. Default: '2s'
        :param url: URL to probe. Default: '/'
        :param window: Number of most recent probes to consider. Default: 10
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0da184588c5837a5bc88ddd4d3a4db35aaa3c775ee92ea8ba1959fc3079445ed)
            check_type(argname="argument expected_response", value=expected_response, expected_type=type_hints["expected_response"])
            check_type(argname="argument interval", value=interval, expected_type=type_hints["interval"])
            check_type(argname="argument threshold", value=threshold, expected_type=type_hints["threshold"])
            check_type(argname="argument timeout", value=timeout, expected_type=type_hints["timeout"])
            check_type(argname="argument url", value=url, expected_type=type_hints["url"])
            check_type(argname="argument window", value=window, expected_type=type_hints["window"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if expected_response is not None:
            self._values["expected_response"] = expected_response
        if interval is not None:
            self._values["interval"] = interval
        if threshold is not None:
            self._values["threshold"] = threshold
        if timeout is not None:
            self._values["timeout"] = timeout
        if url is not None:
            self._values["url"] = url
        if window is not None:
            self._values["window"] = window

    @builtins.property
    def expected_response(self) -> typing.Optional[jsii.Number]:
        '''Expected HTTP response status code.

        :default: 200
        '''
        result = self._values.get("expected_response")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def interval(self) -> typing.Optional[builtins.str]:
        '''How often to probe the backend.

        :default: '5s'
        '''
        result = self._values.get("interval")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def threshold(self) -> typing.Optional[jsii.Number]:
        '''Minimum successful probes within window for healthy status.

        :default: 8
        '''
        result = self._values.get("threshold")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def timeout(self) -> typing.Optional[builtins.str]:
        '''Maximum time to wait for a probe response.

        :default: '2s'
        '''
        result = self._values.get("timeout")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def url(self) -> typing.Optional[builtins.str]:
        '''URL to probe.

        :default: '/'
        '''
        result = self._values.get("url")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def window(self) -> typing.Optional[jsii.Number]:
        '''Number of most recent probes to consider.

        :default: 10
        '''
        result = self._values.get("window")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "VinylCacheBackendProbe(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@bluedynamics/cdk8s-plone.VinylCacheToleration",
    jsii_struct_bases=[],
    name_mapping={
        "key": "key",
        "effect": "effect",
        "operator": "operator",
        "value": "value",
    },
)
class VinylCacheToleration:
    def __init__(
        self,
        *,
        key: builtins.str,
        effect: typing.Optional[builtins.str] = None,
        operator: typing.Optional[builtins.str] = None,
        value: typing.Optional[builtins.str] = None,
    ) -> None:
        '''A Kubernetes toleration for the Varnish pods.

        :param key: The taint key to tolerate.
        :param effect: The taint effect to tolerate (NoSchedule, PreferNoSchedule, NoExecute). Default: - tolerate all effects
        :param operator: The operator (Equal or Exists). Default: 'Equal'
        :param value: The taint value to match (when operator is Equal). Default: - no value
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a7a858d36189193116364dcdc9602dc9a585ddd4b4a9f129818bc7b4d5af9aea)
            check_type(argname="argument key", value=key, expected_type=type_hints["key"])
            check_type(argname="argument effect", value=effect, expected_type=type_hints["effect"])
            check_type(argname="argument operator", value=operator, expected_type=type_hints["operator"])
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "key": key,
        }
        if effect is not None:
            self._values["effect"] = effect
        if operator is not None:
            self._values["operator"] = operator
        if value is not None:
            self._values["value"] = value

    @builtins.property
    def key(self) -> builtins.str:
        '''The taint key to tolerate.'''
        result = self._values.get("key")
        assert result is not None, "Required property 'key' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def effect(self) -> typing.Optional[builtins.str]:
        '''The taint effect to tolerate (NoSchedule, PreferNoSchedule, NoExecute).

        :default: - tolerate all effects
        '''
        result = self._values.get("effect")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def operator(self) -> typing.Optional[builtins.str]:
        '''The operator (Equal or Exists).

        :default: 'Equal'
        '''
        result = self._values.get("operator")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def value(self) -> typing.Optional[builtins.str]:
        '''The taint value to match (when operator is Equal).

        :default: - no value
        '''
        result = self._values.get("value")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "VinylCacheToleration(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


__all__ = [
    "HttpcacheEnvVar",
    "HttpcacheToleration",
    "Plone",
    "PloneBaseOptions",
    "PloneHttpcache",
    "PloneHttpcacheOptions",
    "PloneOptions",
    "PloneVariant",
    "PloneVinylCache",
    "PloneVinylCacheOptions",
    "VinylCacheBackend",
    "VinylCacheBackendProbe",
    "VinylCacheToleration",
]

publication.publish()

def _typecheckingstub__1235804a7513a3b12840acadf55725cfdeac6e17ebfd9e188feab3a3091cfc85(
    *,
    name: builtins.str,
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2fbb2f6f32c28345f0e9ca5077426e713e3011a97fc0bb79ec4b17114ff6575c(
    *,
    key: builtins.str,
    effect: typing.Optional[builtins.str] = None,
    operator: typing.Optional[builtins.str] = None,
    value: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__543cbcb1139deb4ce75315c33bb5ebd6fd98851d9416a0f8e2c5cd960899e686(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    backend: typing.Optional[typing.Union[PloneBaseOptions, typing.Dict[builtins.str, typing.Any]]] = None,
    frontend: typing.Optional[typing.Union[PloneBaseOptions, typing.Dict[builtins.str, typing.Any]]] = None,
    image_pull_secrets: typing.Optional[typing.Sequence[builtins.str]] = None,
    site_id: typing.Optional[builtins.str] = None,
    variant: typing.Optional[PloneVariant] = None,
    version: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cd9cf17a63ac3f69f433db3caa859d98a750929386f09ada26dd0fd212b3ec78(
    *,
    annotations: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    environment: typing.Optional[_cdk8s_plus_30_fa3b8a6f.Env] = None,
    image: typing.Optional[builtins.str] = None,
    image_pull_policy: typing.Optional[builtins.str] = None,
    limit_cpu: typing.Optional[builtins.str] = None,
    limit_memory: typing.Optional[builtins.str] = None,
    liveness_enabled: typing.Optional[builtins.bool] = None,
    liveness_failure_threshold: typing.Optional[jsii.Number] = None,
    liveness_initial_delay_seconds: typing.Optional[jsii.Number] = None,
    liveness_period_seconds: typing.Optional[jsii.Number] = None,
    liveness_success_threshold: typing.Optional[jsii.Number] = None,
    liveness_timeout_seconds: typing.Optional[jsii.Number] = None,
    max_unavailable: typing.Optional[typing.Union[builtins.str, jsii.Number]] = None,
    metrics_path: typing.Optional[builtins.str] = None,
    metrics_port: typing.Optional[typing.Union[builtins.str, jsii.Number]] = None,
    min_available: typing.Optional[typing.Union[builtins.str, jsii.Number]] = None,
    node_selector: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    pod_annotations: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    readiness_enabled: typing.Optional[builtins.bool] = None,
    readiness_failure_threshold: typing.Optional[jsii.Number] = None,
    readiness_initial_delay_seconds: typing.Optional[jsii.Number] = None,
    readiness_period_seconds: typing.Optional[jsii.Number] = None,
    readiness_success_threshold: typing.Optional[jsii.Number] = None,
    readiness_timeout_seconds: typing.Optional[jsii.Number] = None,
    replicas: typing.Optional[jsii.Number] = None,
    request_cpu: typing.Optional[builtins.str] = None,
    request_memory: typing.Optional[builtins.str] = None,
    service_annotations: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    servicemonitor: typing.Optional[builtins.bool] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f7f85fe682616b18a7851bccc28d7021f541060ebc9eba02965066fd28589e69(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    plone: Plone,
    app_version: typing.Optional[builtins.str] = None,
    chart_version: typing.Optional[builtins.str] = None,
    existing_secret: typing.Optional[builtins.str] = None,
    exporter_enabled: typing.Optional[builtins.bool] = None,
    extra_env_vars: typing.Optional[typing.Sequence[typing.Union[HttpcacheEnvVar, typing.Dict[builtins.str, typing.Any]]]] = None,
    limit_cpu: typing.Optional[builtins.str] = None,
    limit_memory: typing.Optional[builtins.str] = None,
    replicas: typing.Optional[jsii.Number] = None,
    request_cpu: typing.Optional[builtins.str] = None,
    request_memory: typing.Optional[builtins.str] = None,
    servicemonitor: typing.Optional[builtins.bool] = None,
    tolerations: typing.Optional[typing.Sequence[typing.Union[HttpcacheToleration, typing.Dict[builtins.str, typing.Any]]]] = None,
    varnish_vcl: typing.Optional[builtins.str] = None,
    varnish_vcl_file: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0f974bf721e34d8993ba90020605bc5e09424793236af8b8c5a9bb9a63f1974a(
    *,
    plone: Plone,
    app_version: typing.Optional[builtins.str] = None,
    chart_version: typing.Optional[builtins.str] = None,
    existing_secret: typing.Optional[builtins.str] = None,
    exporter_enabled: typing.Optional[builtins.bool] = None,
    extra_env_vars: typing.Optional[typing.Sequence[typing.Union[HttpcacheEnvVar, typing.Dict[builtins.str, typing.Any]]]] = None,
    limit_cpu: typing.Optional[builtins.str] = None,
    limit_memory: typing.Optional[builtins.str] = None,
    replicas: typing.Optional[jsii.Number] = None,
    request_cpu: typing.Optional[builtins.str] = None,
    request_memory: typing.Optional[builtins.str] = None,
    servicemonitor: typing.Optional[builtins.bool] = None,
    tolerations: typing.Optional[typing.Sequence[typing.Union[HttpcacheToleration, typing.Dict[builtins.str, typing.Any]]]] = None,
    varnish_vcl: typing.Optional[builtins.str] = None,
    varnish_vcl_file: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d92a415ce6a72ab45cd3d3e169acc7fc8156c275bc6268fa1eed4110e990c22a(
    *,
    backend: typing.Optional[typing.Union[PloneBaseOptions, typing.Dict[builtins.str, typing.Any]]] = None,
    frontend: typing.Optional[typing.Union[PloneBaseOptions, typing.Dict[builtins.str, typing.Any]]] = None,
    image_pull_secrets: typing.Optional[typing.Sequence[builtins.str]] = None,
    site_id: typing.Optional[builtins.str] = None,
    variant: typing.Optional[PloneVariant] = None,
    version: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__93447ae1ad213e9afd98e1d8f3560fa78ec1f1282da39e445b9a89debffe0ca1(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    plone: Plone,
    director: typing.Optional[builtins.str] = None,
    extra_backends: typing.Optional[typing.Sequence[typing.Union[VinylCacheBackend, typing.Dict[builtins.str, typing.Any]]]] = None,
    image: typing.Optional[builtins.str] = None,
    invalidation: typing.Optional[builtins.bool] = None,
    limit_cpu: typing.Optional[builtins.str] = None,
    limit_memory: typing.Optional[builtins.str] = None,
    monitoring: typing.Optional[builtins.bool] = None,
    node_selector: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    replicas: typing.Optional[jsii.Number] = None,
    request_cpu: typing.Optional[builtins.str] = None,
    request_memory: typing.Optional[builtins.str] = None,
    tolerations: typing.Optional[typing.Sequence[typing.Union[VinylCacheToleration, typing.Dict[builtins.str, typing.Any]]]] = None,
    vcl_backend_error_snippet: typing.Optional[builtins.str] = None,
    vcl_backend_fetch_snippet: typing.Optional[builtins.str] = None,
    vcl_backend_response_snippet: typing.Optional[builtins.str] = None,
    vcl_deliver_snippet: typing.Optional[builtins.str] = None,
    vcl_fini_snippet: typing.Optional[builtins.str] = None,
    vcl_hash_snippet: typing.Optional[builtins.str] = None,
    vcl_hit_snippet: typing.Optional[builtins.str] = None,
    vcl_init_snippet: typing.Optional[builtins.str] = None,
    vcl_miss_snippet: typing.Optional[builtins.str] = None,
    vcl_pass_snippet: typing.Optional[builtins.str] = None,
    vcl_pipe_snippet: typing.Optional[builtins.str] = None,
    vcl_purge_snippet: typing.Optional[builtins.str] = None,
    vcl_recv_snippet: typing.Optional[builtins.str] = None,
    vcl_synth_snippet: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a07a5185c68385a34a009fb9ed8ad052b517d97b7a5262adaaaf5580dcac27b5(
    *,
    plone: Plone,
    director: typing.Optional[builtins.str] = None,
    extra_backends: typing.Optional[typing.Sequence[typing.Union[VinylCacheBackend, typing.Dict[builtins.str, typing.Any]]]] = None,
    image: typing.Optional[builtins.str] = None,
    invalidation: typing.Optional[builtins.bool] = None,
    limit_cpu: typing.Optional[builtins.str] = None,
    limit_memory: typing.Optional[builtins.str] = None,
    monitoring: typing.Optional[builtins.bool] = None,
    node_selector: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    replicas: typing.Optional[jsii.Number] = None,
    request_cpu: typing.Optional[builtins.str] = None,
    request_memory: typing.Optional[builtins.str] = None,
    tolerations: typing.Optional[typing.Sequence[typing.Union[VinylCacheToleration, typing.Dict[builtins.str, typing.Any]]]] = None,
    vcl_backend_error_snippet: typing.Optional[builtins.str] = None,
    vcl_backend_fetch_snippet: typing.Optional[builtins.str] = None,
    vcl_backend_response_snippet: typing.Optional[builtins.str] = None,
    vcl_deliver_snippet: typing.Optional[builtins.str] = None,
    vcl_fini_snippet: typing.Optional[builtins.str] = None,
    vcl_hash_snippet: typing.Optional[builtins.str] = None,
    vcl_hit_snippet: typing.Optional[builtins.str] = None,
    vcl_init_snippet: typing.Optional[builtins.str] = None,
    vcl_miss_snippet: typing.Optional[builtins.str] = None,
    vcl_pass_snippet: typing.Optional[builtins.str] = None,
    vcl_pipe_snippet: typing.Optional[builtins.str] = None,
    vcl_purge_snippet: typing.Optional[builtins.str] = None,
    vcl_recv_snippet: typing.Optional[builtins.str] = None,
    vcl_synth_snippet: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__23be0f4fef2dff99ddd74b8384443782e3fe5032cd0368cdb5406251dce86e9a(
    *,
    name: builtins.str,
    port: jsii.Number,
    service_name: builtins.str,
    probe: typing.Optional[typing.Union[VinylCacheBackendProbe, typing.Dict[builtins.str, typing.Any]]] = None,
    weight: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0da184588c5837a5bc88ddd4d3a4db35aaa3c775ee92ea8ba1959fc3079445ed(
    *,
    expected_response: typing.Optional[jsii.Number] = None,
    interval: typing.Optional[builtins.str] = None,
    threshold: typing.Optional[jsii.Number] = None,
    timeout: typing.Optional[builtins.str] = None,
    url: typing.Optional[builtins.str] = None,
    window: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a7a858d36189193116364dcdc9602dc9a585ddd4b4a9f129818bc7b4d5af9aea(
    *,
    key: builtins.str,
    effect: typing.Optional[builtins.str] = None,
    operator: typing.Optional[builtins.str] = None,
    value: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass
