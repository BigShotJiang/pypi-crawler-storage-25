from sqlalchemy.orm import Mapped, mapped_column

from mastr_models.enum.einheiten_strom_speicher import (
    EinheitStromSpeicherAcDcKoppelung,
    EinheitStromSpeicherBatterietechnologie,
    EinheitStromSpeicherEegAnlagentyp,
    EinheitStromSpeicherEinsatzort,
    EinheitStromSpeicherPumpspeichertechnologie,
    EinheitStromSpeicherReserveartNachDemEnWg,
    EinheitStromSpeicherTechnologie,
)
from mastr_models.mysql.column import DEFAULT_STRING
from mastr_models.mysql.stromerzeugung.strom_speicher import (
    StromerzeugungseinheitStromSpeicher,
)
from mastr_models.types.str_enum import StrEnumColumn


class EinheitStromSpeicherMixin(StromerzeugungseinheitStromSpeicher):
    reserveart_nach_dem_en_wg: Mapped[
        EinheitStromSpeicherReserveartNachDemEnWg | None
    ] = mapped_column(
        StrEnumColumn(EinheitStromSpeicherReserveartNachDemEnWg),
        nullable=True,
        comment="Reserve category (EnWG)",
    )
    datum_ueberfuehrung_in_reserve: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="Date of transfer into reserve (raw)"
    )
    eeg_anlagentyp: Mapped[EinheitStromSpeicherEegAnlagentyp | None] = mapped_column(
        StrEnumColumn(EinheitStromSpeicherEegAnlagentyp),
        nullable=True,
        comment="EEG plant type",
    )
    einsatzort: Mapped[EinheitStromSpeicherEinsatzort | None] = mapped_column(
        StrEnumColumn(EinheitStromSpeicherEinsatzort),
        nullable=True,
        comment="Deployment location",
    )
    ac_dc_koppelung: Mapped[EinheitStromSpeicherAcDcKoppelung | None] = mapped_column(
        StrEnumColumn(EinheitStromSpeicherAcDcKoppelung),
        nullable=True,
        comment="AC/DC coupling",
    )
    batterietechnologie: Mapped[EinheitStromSpeicherBatterietechnologie | None] = (
        mapped_column(
            StrEnumColumn(EinheitStromSpeicherBatterietechnologie),
            nullable=True,
            comment="Battery technology",
        )
    )
    notstromaggregat: Mapped[bool | None] = mapped_column(
        nullable=True, comment="Emergency power unit present"
    )
    pumpbetrieb_leistungsaufnahme: Mapped[float | None] = mapped_column(
        nullable=True, comment="Pumped operation power consumption (MW)"
    )
    pumpbetrieb_kontinuierlich_regelbar: Mapped[bool | None] = mapped_column(
        nullable=True, comment="Pumped operation continuously controllable"
    )
    pumpspeichertechnologie: Mapped[
        EinheitStromSpeicherPumpspeichertechnologie | None
    ] = mapped_column(
        StrEnumColumn(EinheitStromSpeicherPumpspeichertechnologie),
        nullable=True,
        comment="Pumped storage technology",
    )
    bestandteil_grenzkraftwerk: Mapped[bool | None] = mapped_column(
        nullable=True, comment="Part of a border power plant"
    )
    nettonennleistung_deutschland: Mapped[float | None] = mapped_column(
        nullable=True, comment="Net nominal capacity attributable to Germany (MW)"
    )
    zugeordnente_wirkleistung_wechselrichter: Mapped[float | None] = mapped_column(
        nullable=True, comment="Assigned active power of inverter (MW)"
    )
    spe_mastr_nummer: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="SPE MaStR number"
    )
    technologie: Mapped[EinheitStromSpeicherTechnologie | None] = mapped_column(
        StrEnumColumn(EinheitStromSpeicherTechnologie),
        nullable=True,
        comment="Storage technology",
    )
    gemeinsam_registrierte_solareinheit_mastr_nummer: Mapped[str | None] = (
        mapped_column(
            DEFAULT_STRING,
            nullable=True,
            comment="Jointly registered solar unit MaStR number",
        )
    )
