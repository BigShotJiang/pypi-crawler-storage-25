from abc import abstractmethod
from datetime import date, datetime
from typing import TYPE_CHECKING, Optional

from sqlalchemy.orm import Mapped, declared_attr, mapped_column, relationship

from mastr_models.enum.marktakteure import (
    MarktakteurBundesland,
    MarktakteurHauptwirtdschaftszweigAbschnitt,
    MarktakteurHauptwirtdschaftszweigAbteilung,
    MarktakteurHauptwirtdschaftszweigGruppe,
    MarktakteurLand,
    MarktakteurLandAnZustelladresse,
    MarktakteurMarktakteurAnrede,
    MarktakteurMarktakteurTitel,
    MarktakteurMarktfunktion,
    MarktakteurPersonenart,
    MarktakteurRegisternummerPraefix,
)
from mastr_models.mysql.base import NewArchiveDateMixin
from mastr_models.mysql.column import DEFAULT_STRING, MASTR_ID_TYPE
from mastr_models.types.str_enum import StrEnumColumn

if TYPE_CHECKING:
    from mastr_models.mysql.netze import Netz_Mixin


class MarktakteurMixin(NewArchiveDateMixin):
    mastr_nummer: Mapped[str] = mapped_column(
        MASTR_ID_TYPE, primary_key=True, nullable=False, comment="MaStR ID"
    )
    datum_letze_aktualisierung: Mapped[datetime | None] = mapped_column(
        nullable=True, comment="Last update date"
    )
    personenart: Mapped[MarktakteurPersonenart | None] = mapped_column(
        StrEnumColumn(MarktakteurPersonenart), nullable=True, comment="Person type"
    )
    marktakteur_anrede: Mapped[MarktakteurMarktakteurAnrede | None] = mapped_column(
        StrEnumColumn(MarktakteurMarktakteurAnrede),
        nullable=True,
        comment="Salutation",
    )
    marktakteur_titel: Mapped[MarktakteurMarktakteurTitel | None] = mapped_column(
        StrEnumColumn(MarktakteurMarktakteurTitel), nullable=True, comment="Title"
    )
    marktakteur_vorname: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="First name"
    )
    marktakteur_nachname: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="Last name"
    )
    firmenname: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="Company name"
    )
    marktfunktion: Mapped[MarktakteurMarktfunktion | None] = mapped_column(
        StrEnumColumn(MarktakteurMarktfunktion),
        nullable=True,
        comment="Market function",
    )
    rechtsform: Mapped[int | None] = mapped_column(nullable=True, comment="Legal form")
    sonstige_rechtsform: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="Other legal form"
    )
    marktrollen: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="Market roles"
    )
    land: Mapped[MarktakteurLand | None] = mapped_column(
        StrEnumColumn(MarktakteurLand), nullable=True, comment="Country"
    )
    region: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="Region"
    )
    strasse: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="Street"
    )
    hausnummer: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="House number"
    )
    hausnummer_nv: Mapped[bool | None] = mapped_column(
        nullable=True, comment="House number not provided"
    )
    adresszusatz: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="Address supplement"
    )
    postleitzahl: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="Postal code"
    )
    ort: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="City"
    )
    bundesland: Mapped[MarktakteurBundesland | None] = mapped_column(
        StrEnumColumn(MarktakteurBundesland), nullable=True, comment="Federal state"
    )

    netz: Mapped[str | None] = mapped_column(
        MASTR_ID_TYPE, nullable=True, comment="1:1 corresponding network"
    )

    @classmethod
    @abstractmethod
    def _MapperNetz(cls) -> type["Netz_Mixin"]:
        raise NotImplementedError

    @declared_attr
    def Netz(cls) -> Mapped[Optional["Netz_Mixin"]]:
        return relationship(
            "MaStR_Netz",
            primaryjoin=lambda: cls.netz == cls._MapperNetz().mastr_nummer,
            viewonly=True,
            foreign_keys=lambda: cls.netz,
            back_populates="Marktakteur",
        )

    nuts2: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="NUTS2 region"
    )
    email: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="Email"
    )
    telefon: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="Phone"
    )
    fax: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="Fax"
    )
    fax_nv: Mapped[bool | None] = mapped_column(
        nullable=True, comment="Fax not provided"
    )
    webseite: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="Website"
    )
    webseite_nv: Mapped[bool | None] = mapped_column(
        nullable=True, comment="Website not provided"
    )
    registergericht: Mapped[int | None] = mapped_column(
        nullable=True, comment="Register court"
    )
    registergericht_ausland: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="Register court abroad"
    )
    registernummer_praefix: Mapped[MarktakteurRegisternummerPraefix | None] = (
        mapped_column(
            StrEnumColumn(MarktakteurRegisternummerPraefix),
            nullable=True,
            comment="Register number prefix",
        )
    )
    registernummer: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="Register number"
    )
    registernummer_ausland: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="Register number abroad"
    )
    taetigkeitsbeginn: Mapped[date | None] = mapped_column(
        nullable=True, comment="Activity start date"
    )
    acer_code: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="ACER code"
    )
    acer_code_nv: Mapped[bool | None] = mapped_column(
        nullable=True, comment="ACER code not provided"
    )
    umsatzsteueridentifikationsnummer: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="VAT ID"
    )
    umsatzsteueridentifikationsnummer_nv: Mapped[bool | None] = mapped_column(
        nullable=True, comment="VAT ID not provided"
    )
    taetigkeitsende: Mapped[date | None] = mapped_column(
        nullable=True, comment="Activity end date"
    )
    bundesnetzagentur_betriebsnummer: Mapped[str | None] = mapped_column(
        DEFAULT_STRING,
        nullable=True,
        comment="Federal Network Agency operation number",
    )
    bundesnetzagentur_betriebsnummer_nv: Mapped[bool | None] = mapped_column(
        nullable=True,
        comment="Federal Network Agency operation number not provided",
    )
    land_an_zustelladresse: Mapped[MarktakteurLandAnZustelladresse | None] = (
        mapped_column(
            StrEnumColumn(MarktakteurLandAnZustelladresse),
            nullable=True,
            comment="Country at delivery address",
        )
    )
    postleitzahl_an_zustelladresse: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="Postal code at delivery address"
    )
    ort_an_zustelladresse: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="City at delivery address"
    )
    strasse_an_zustelladresse: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="Street at delivery address"
    )
    hausnummer_an_zustelladresse: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="House number at delivery address"
    )
    hausnummer_an_zustelladresse_nv: Mapped[bool | None] = mapped_column(
        nullable=True, comment="House number at delivery address not provided"
    )
    adresszusatz_an_zustelladresse: Mapped[str | None] = mapped_column(
        DEFAULT_STRING,
        nullable=True,
        comment="Address supplement at delivery address",
    )
    kmu: Mapped[bool | None] = mapped_column(
        nullable=True, comment="SME (small/medium enterprise)"
    )
    registrierungsdatum_marktakteur: Mapped[datetime | None] = mapped_column(
        nullable=True, comment="Market participant registration date"
    )

    hauptwirtdschaftszweig_abteilung: Mapped[
        MarktakteurHauptwirtdschaftszweigAbteilung | None
    ] = mapped_column(
        StrEnumColumn(MarktakteurHauptwirtdschaftszweigAbteilung),
        nullable=True,
        comment="Main economic sector division",
    )
    hauptwirtdschaftszweig_gruppe: Mapped[
        MarktakteurHauptwirtdschaftszweigGruppe | None
    ] = mapped_column(
        StrEnumColumn(MarktakteurHauptwirtdschaftszweigGruppe),
        nullable=True,
        comment="Main economic sector group",
    )
    hauptwirtdschaftszweig_abschnitt: Mapped[
        MarktakteurHauptwirtdschaftszweigAbschnitt | None
    ] = mapped_column(
        StrEnumColumn(MarktakteurHauptwirtdschaftszweigAbschnitt),
        nullable=True,
        comment="Main economic sector section",
    )

    direktvermarktungsunternehmen: Mapped[bool | None] = mapped_column(
        nullable=True, comment="Direct marketing company"
    )
    belieferung_von_letztverbrauchern_strom: Mapped[bool | None] = mapped_column(
        nullable=True, comment="Supply to final consumers electricity"
    )
    belieferung_haushaltskunden_strom: Mapped[bool | None] = mapped_column(
        nullable=True, comment="Supply to household customers electricity"
    )
    gasgrosshaendler: Mapped[bool | None] = mapped_column(
        nullable=True, comment="Gas wholesale trader"
    )
    stromgrosshaendler: Mapped[bool | None] = mapped_column(
        nullable=True, comment="Electricity wholesale trader"
    )
    belieferung_von_letztverbrauchern_gas: Mapped[bool | None] = mapped_column(
        nullable=True, comment="Supply to final consumers gas"
    )
    belieferung_haushaltskunden_gas: Mapped[bool | None] = mapped_column(
        nullable=True, comment="Supply to household customers gas"
    )
    webportal_des_netzbetreibers: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="Web portal of network operator"
    )
