from sqlalchemy.orm import Mapped, mapped_column

from mastr_models.enum.einheiten_solar import (
    EinheitSolarArtDerSolaranlage,
    EinheitSolarHauptausrichtung,
    EinheitSolarHauptausrichtungNeigungswinkel,
    EinheitSolarLeistungsbegrenzung,
    EinheitSolarNebenausrichtung,
    EinheitSolarNebenausrichtungNeigungswinkel,
    EinheitSolarNutzungsbereich,
)
from mastr_models.mysql.column import DEFAULT_STRING
from mastr_models.mysql.stromerzeugung.solar import StromerzeugungseinheitSolar
from mastr_models.types.str_enum import StrEnumColumn


class EinheitSolarMixin(StromerzeugungseinheitSolar):
    zugeordnete_wirkleistung_wechselrichter: Mapped[float | None] = mapped_column(
        nullable=True, comment="Assigned active power inverter"
    )
    anzahl_module: Mapped[int | None] = mapped_column(
        nullable=True, comment="Number of modules"
    )
    art_der_solaranlage: Mapped[EinheitSolarArtDerSolaranlage | None] = mapped_column(
        StrEnumColumn(EinheitSolarArtDerSolaranlage),
        nullable=True,
        comment="Type of solar system",
    )
    leistungsbegrenzung: Mapped[EinheitSolarLeistungsbegrenzung | None] = mapped_column(
        StrEnumColumn(EinheitSolarLeistungsbegrenzung),
        nullable=True,
        comment="Power limitation",
    )
    einheitliche_ausrichtung_und_neigungswinkel: Mapped[bool | None] = mapped_column(
        nullable=True,
        comment="Uniform orientation and tilt angle",
    )
    hauptausrichtung: Mapped[EinheitSolarHauptausrichtung | None] = mapped_column(
        StrEnumColumn(EinheitSolarHauptausrichtung),
        nullable=True,
        comment="Main orientation",
    )
    hauptausrichtung_neigungswinkel: Mapped[
        EinheitSolarHauptausrichtungNeigungswinkel | None
    ] = mapped_column(
        StrEnumColumn(EinheitSolarHauptausrichtungNeigungswinkel),
        nullable=True,
        comment="Main orientation tilt angle",
    )
    nebenausrichtung: Mapped[EinheitSolarNebenausrichtung | None] = mapped_column(
        StrEnumColumn(EinheitSolarNebenausrichtung),
        nullable=True,
        comment="Secondary orientation",
    )
    nebenausrichtung_neigungswinkel: Mapped[
        EinheitSolarNebenausrichtungNeigungswinkel | None
    ] = mapped_column(
        StrEnumColumn(EinheitSolarNebenausrichtungNeigungswinkel),
        nullable=True,
        comment="Secondary orientation tilt angle",
    )
    nutzungsbereich: Mapped[EinheitSolarNutzungsbereich | None] = mapped_column(
        StrEnumColumn(EinheitSolarNutzungsbereich), nullable=True, comment="Area of use"
    )
    buergerenergie: Mapped[bool | None] = mapped_column(
        nullable=True,
        comment="Citizen energy",
    )
    speicher_am_gleichen_ort: Mapped[bool | None] = mapped_column(
        nullable=True,
        comment="Storage at the same location",
    )
    in_anspruch_genommene_flaeche: Mapped[float | None] = mapped_column(
        nullable=True, comment="Area used"
    )
    art_der_flaeche_ids: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="Type of area IDs"
    )
    in_anspruch_genommene_ackerflaeche: Mapped[float | None] = mapped_column(
        nullable=True, comment="Arable land used"
    )
