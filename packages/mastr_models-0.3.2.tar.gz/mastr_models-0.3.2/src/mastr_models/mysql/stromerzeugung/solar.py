from abc import abstractmethod
from datetime import date
from typing import Optional

from geoalchemy2.types import Geometry
from sqlalchemy import Computed, func
from sqlalchemy.orm import Mapped, declared_attr, mapped_column, relationship

from mastr_models.enum.einheiten_solar import (
    EinheitSolarBundesland,
    EinheitSolarEinheitBetriebsstatus,
    EinheitSolarEinheitSystemstatus,
    EinheitSolarEinspeisungsart,
    EinheitSolarEnergietraeger,
    EinheitSolarLand,
    EinheitSolarNetzbetreiberpruefungStatus,
)
from mastr_models.mysql.base import NewArchiveDateMixin
from mastr_models.mysql.column import (
    DEFAULT_STRING,
    HAUS_NUMMER_COLUMN,
    MASTR_ID_TYPE,
    ORT_COLUMN,
)
from mastr_models.mysql.netzanschlusspunkte import Netzanschlusspunkt_Mixin
from mastr_models.types.str_enum import StrEnumColumn


class StromerzeugungseinheitSolar(NewArchiveDateMixin):
    __abstract__ = True

    einheit_mastr_nummer: Mapped[str] = mapped_column(
        MASTR_ID_TYPE, nullable=False, primary_key=True, comment="Unit MaStR number"
    )
    name_stromerzeugungseinheit: Mapped[str] = mapped_column(
        DEFAULT_STRING, nullable=False, comment="Display name of power generation unit"
    )

    lokation_id: Mapped[str | None] = mapped_column(
        MASTR_ID_TYPE, nullable=True, comment="Location MaStR number"
    )

    @classmethod
    @abstractmethod
    def _MapperNetzanschlusspunkt(cls) -> type["Netzanschlusspunkt_Mixin"]:
        raise NotImplementedError

    @declared_attr
    def Netzanschlusspunkt(cls) -> Mapped[Optional["Netzanschlusspunkt_Mixin"]]:
        return relationship(
            "MaStR_Netzanschlusspunkt",
            primaryjoin=lambda: (
                cls._MapperNetzanschlusspunkt().lokation_ma_st_rnummer
                == cls.lokation_id
            ),
            viewonly=True,
            foreign_keys=lambda: cls.lokation_id,
        )

    land: Mapped[EinheitSolarLand] = mapped_column(
        StrEnumColumn(EinheitSolarLand), nullable=False, comment="Country"
    )
    bundesland: Mapped[EinheitSolarBundesland | None] = mapped_column(
        StrEnumColumn(EinheitSolarBundesland), nullable=True, comment="Federal state"
    )
    landkreis: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="District"
    )
    gemeinde: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="Municipality"
    )
    gemeindeschluessel: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="Municipality key"
    )
    postleitzahl: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="Postal code"
    )
    strasse: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="Street"
    )
    gemarkung: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="Cadastral district"
    )
    flur_flurstuecknummern: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="Parcel numbers"
    )
    strasse_nicht_gefunden: Mapped[bool | None] = mapped_column(
        nullable=True, comment="Street not found"
    )
    hausnummer: Mapped[str | None] = HAUS_NUMMER_COLUMN()

    hausnummer_nv: Mapped[bool | None] = mapped_column(
        nullable=True, comment="House number not available"
    )
    hausnummer_nicht_gefunden: Mapped[bool | None] = mapped_column(
        nullable=True, comment="House number not found"
    )
    adresszusatz: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="Address addition"
    )
    ort: Mapped[str | None] = ORT_COLUMN()

    laengengrad: Mapped[float | None] = mapped_column(
        nullable=True, comment="Longitude"
    )
    breitengrad: Mapped[float | None] = mapped_column(nullable=True, comment="Latitude")

    @declared_attr
    def location(cls) -> Mapped[int]:
        return mapped_column(
            Geometry("POINT", srid=4326),
            Computed(func.POINT(cls.laengengrad, cls.breitengrad)),
            nullable=True,
            comment="geographical point based on longitude and latitude",
        )

    registrierungsdatum: Mapped[date | None] = mapped_column(
        nullable=True, comment="Registration date"
    )
    inbetriebnahmedatum: Mapped[date | None] = mapped_column(
        nullable=True, comment="Commissioning date"
    )
    datum_endgueltige_stilllegung: Mapped[date | None] = mapped_column(
        nullable=True, comment="Final decommissioning date"
    )
    datum_beginn_voruebergehende_stilllegung: Mapped[date | None] = mapped_column(
        nullable=True, comment="Start date of temporary shutdown"
    )
    datum_wiederaufnahme_betrieb: Mapped[date | None] = mapped_column(
        nullable=True, comment="Date of resumption of operation"
    )
    geplantes_inbetriebnahmedatum: Mapped[date | None] = mapped_column(
        nullable=True, comment="Planned commissioning date"
    )
    datum_letzte_aktualisierung: Mapped[date | None] = mapped_column(
        nullable=True, comment="Last update date/time"
    )
    datum_des_betreiberwechsels: Mapped[date | None] = mapped_column(
        nullable=True, comment="Date of operator change"
    )
    datum_registrierung_des_betreiberwechsels: Mapped[date | None] = mapped_column(
        nullable=True, comment="Date of registration of operator change"
    )
    netzbetreiberpruefung_datum: Mapped[date | None] = mapped_column(
        nullable=True, comment="Grid operator check date"
    )
    anlagenbetreiber: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="Plant operator MaStR number"
    )
    alt_anlagenbetreiber: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="Old plant operator MaStR number"
    )
    bestandsanlage_mastr_nummer: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="Existing plant MaStR number"
    )
    nicht_vorhanden_in_migrierten_einheiten: Mapped[bool | None] = mapped_column(
        nullable=True, comment="Not present in migrated units"
    )
    BNetzA_id: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="BNetzA ID"
    )
    w_eic: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="WEIC"
    )
    w_eic_display_name: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="WEIC display name"
    )
    kraftwerksnummer: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="Power plant number"
    )
    kraftwerksnummer_nv: Mapped[bool | None] = mapped_column(
        nullable=True, comment="Power plant number not available"
    )
    weic_nv: Mapped[bool | None] = mapped_column(
        nullable=True, comment="WEIC not available"
    )
    eeg_ma_st_rnummer: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="EEG MaStR number"
    )
    gen_mastr_nummer: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="GEN MaStR number"
    )
    energietraeger: Mapped[EinheitSolarEnergietraeger | None] = mapped_column(
        StrEnumColumn(EinheitSolarEnergietraeger),
        nullable=True,
        comment="Energy carrier",
    )
    bruttoleistung: Mapped[float | None] = mapped_column(
        nullable=True, comment="Gross output"
    )
    nettonennleistung: Mapped[float | None] = mapped_column(
        nullable=True, comment="Net nominal output"
    )
    anschluss_an_hoechst_oder_hoch_spannung: Mapped[bool | None] = mapped_column(
        nullable=True, comment="Connection to extra-high or high voltage"
    )
    fernsteuerbarkeit_nb: Mapped[bool | None] = mapped_column(
        nullable=True, comment="Remote controllability NB"
    )
    fernsteuerbarkeit_dv: Mapped[bool | None] = mapped_column(
        nullable=True, comment="Remote controllability DV"
    )
    einspeisungsart: Mapped[EinheitSolarEinspeisungsart | None] = mapped_column(
        StrEnumColumn(EinheitSolarEinspeisungsart),
        nullable=True,
        comment="Type of feed-in",
    )
    einsatzverantwortlicher: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="Responsible operator"
    )
    einheit_systemstatus: Mapped[EinheitSolarEinheitSystemstatus | None] = (
        mapped_column(
            StrEnumColumn(EinheitSolarEinheitSystemstatus),
            nullable=True,
            comment="Unit system status",
        )
    )
    einheit_betriebsstatus: Mapped[EinheitSolarEinheitBetriebsstatus | None] = (
        mapped_column(
            StrEnumColumn(EinheitSolarEinheitBetriebsstatus),
            nullable=True,
            comment="Unit operating status",
        )
    )
    netzbetreiberpruefung_status: Mapped[
        EinheitSolarNetzbetreiberpruefungStatus | None
    ] = mapped_column(
        StrEnumColumn(EinheitSolarNetzbetreiberpruefungStatus),
        nullable=True,
        comment="Grid operator check status",
    )
