"""Same base abstract SQLAlchemy model, but with different enum classes.

Since all the enum classes in `mastr_models.enum` are generated automatically, The enum
classes are defined with different names for different types of generation units.
"""
