from abc import abstractmethod
from datetime import date
from typing import TYPE_CHECKING, Optional

from sqlalchemy import Column, Computed, String, func
from sqlalchemy.orm import Mapped, declared_attr, mapped_column, relationship

from mastr_models.enum.einheiten_verbrennung import (
    FeedInType,
    Hauptbrennstoff,
    Technologie,
)
from mastr_models.mysql.base import ArchiveDateMixin
from mastr_models.mysql.column import (
    DEFAULT_STRING,
    HAUS_NUMMER_COLUMN,
    MASTR_ID_TYPE,
    ORT_COLUMN,
)
from mastr_models.types.json import ListAsJSON
from mastr_models.types.str_enum import StrEnumColumn

if TYPE_CHECKING:
    from mastr_models.mysql.netzanschlusspunkte import Netzanschlusspunkt_Mixin


class EinheitVerbrennungMixin(ArchiveDateMixin):
    id_: Mapped[str] = mapped_column(MASTR_ID_TYPE, nullable=False, primary_key=True)
    DisplayName: Mapped[str] = mapped_column(DEFAULT_STRING, nullable=False)

    hauptbrennstoff: Mapped[Hauptbrennstoff | None] = mapped_column(
        StrEnumColumn(Hauptbrennstoff), nullable=True
    )
    technologie: Mapped[Technologie] = mapped_column(
        StrEnumColumn(Technologie), nullable=False
    )

    bruttoleistung: Mapped[float] = mapped_column(nullable=False, comment="[kW]")
    """Angabe der Bruttoleistung der Stromerzeugungseinheit.

    Die Bruttoleistung ist die an den Klemmen des Generators abgegebene elektrische
    Leistung.
    """

    nettonennleistung: Mapped[float] = mapped_column(nullable=False, comment="[kW]")
    """Angabe der Nettonennleistung der Stromerzeugungseinheit.

    Die Nettonennleistung entspricht in der Regel der Nettoleistung der
    Stromerzeugungseinheit.

    Definition: Die Nettonennleistung ist die tatsächliche höchste elektrische
    Dauerleistung unter Nennbedingungen, die der Stromerzeugungseinheit zuzurechnen ist.
    In der Nettonennleistung ist der Kraftwerkseigenverbrauch (Verbrauchsleistung der
    Neben- und Hilfsanlagen) während des Betriebs der Anlage nicht enthalten.

    Hinweise für große Einheiten:

    - Verfügen mehrere Stromerzeugungseinheiten über gemeinsame Neben- und Hilfsanlagen
      und ist die Nettonennleistung insofern nicht genauer bestimmbar, ist die
      Nettonennleistung der Anlage im Verhältnis der jeweiligen Bruttoleistungen
      aufzuteilen und für die einzelnen Stromerzeugungseinheiten anzugeben.
    - Die Leistungsänderung, die sich ggf. durch einen Kombibetrieb mit einer oder
      mehreren anderen Stromerzeugungseinheiten ergibt, bleibt an dieser Stelle
      unberücksichtigt.
    """

    lokation_id: Mapped[str | None] = mapped_column(DEFAULT_STRING, nullable=True)

    @classmethod
    @abstractmethod
    def _MapperNetzanschlusspunkt(cls) -> type["Netzanschlusspunkt_Mixin"]:
        raise NotImplementedError

    @declared_attr
    def Netzanschlusspunkt(cls) -> Mapped[Optional["Netzanschlusspunkt_Mixin"]]:
        return relationship(
            "MaStR_Netzanschlusspunkt",
            primaryjoin=lambda: (
                cls._MapperNetzanschlusspunkt().lokation_ma_st_rnummer
                == cls.lokation_id
            ),
            viewonly=True,
            foreign_keys=lambda: cls.lokation_id,
        )

    name_kraftwerk: Mapped[str | None] = mapped_column(DEFAULT_STRING, nullable=True)
    name_kraftwerksblock: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True
    )

    # Dates.

    inbetriebnahmedatum: Mapped[date | None] = mapped_column(nullable=True)
    """First date when the unit was in operation.

    No future commissioning dates can be entered in the MaStR. Commissioning can only be
    registered after the unit has been commissioned. Before that, the unit can only be
    registered with the status "In Planning."
    """

    netzreserve_ab_datum: Mapped[date | None] = mapped_column(nullable=True)

    datum_endgueltige_stilllegung: Mapped[date | None] = mapped_column(nullable=True)
    """Date of decommissioning.

    Definition: Die endgültige Stilllegung ist die dauerhafte Außerbetriebnahme der
    Einheit nach Wegfall der technischen Betriebsbereitschaft.

    Hinweise:

    - Nach der Registrierung der endgültigen Stilllegung der Einheit wird eine
      Netzbetreiberprüfung durchgeführt.
    - Nach der Netzbetreiberprüfung wird die Einheit vom Anlagenbetreiber getrennt. Dann
      wird nicht mehr angezeigt, wer der Anlagenbetreiber der stillgelegten Einheit war.
    - Die stillgelegte Einheit wird dauerhaft im MaStR angezeigt.
    """

    # Operators
    anlagenbetreiber: Mapped[str | None] = mapped_column(
        MASTR_ID_TYPE, nullable=True, doc="MaStR ID of the operator"
    )
    alt_anlagenbetreiber: Mapped[list[str] | None] = mapped_column(
        ListAsJSON, nullable=True
    )

    # IDs in other systems

    BNetzA_id: Mapped[str | None] = mapped_column(DEFAULT_STRING, nullable=True)
    w_eic: Mapped[str | None] = mapped_column(DEFAULT_STRING, nullable=True)
    w_eic_display_name: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True
    )

    einsatzverantwortlicher: Mapped[str | None] = mapped_column(
        String(20), nullable=True
    )
    """Marktpartner-Identifikations-Nummer (MP-ID) des Einsatzverantwortlichen.

    Hinweis: Für diese Nummern ist der BDEW zuständig. Möglich ist der Eintrag einer der
    beiden folgenden Nummern:

    - BDEW-Codenummer (z.B. 9900012345678)
    - Global Location Number (z.B. 4000012345678)

    Definition: Der Einsatzverantwortliche ist die Person, die für den Einsatz der
    Stromerzeugungseinheit und für die Übermittlung von deren Fahrplänen verantwortlich
    ist.
    """

    ## Combined generation

    kombibetrieb_id: Mapped[list[str] | None] = mapped_column(ListAsJSON, nullable=True)

    steigerung_nettonennleistung_kombibetrieb: Mapped[float | None] = mapped_column(
        nullable=True, comment="total net capacity in combined operation [kW]"
    )
    """Gesamte Nettonennleistung im Kombibetrieb.

    In diesem Feld ist bei jeder der kombiniert betriebenen Stromerzeugungseinheiten die
    gesamte Nettonennleistung eingetragen, die sich im Kombibetrieb ergibt.

    Hinweise:

    - Die gesamte Nettonennleistung kann höher, gleich oder niedriger sein, als die
      Summe der Nettonennleistungen der einzelnen Stromerzeugungseinheiten.
    - Diese Angabe ist für eine statistische Auswertung der gesamten installierten
      Leistung nicht geeignet.
    """

    anlage_ist_im_kombibetrieb: Mapped[bool | None] = mapped_column(
        nullable=True, comment="if combined generation"
    )
    """Wird in Kombination mit weiteren Stromerzeugungseinheiten betrieben?

    Angabe, ob die Stromerzeugungseinheit in einer technischen Abhängigkeit mit anderen
    Stromerzeugungseinheiten betrieben wird („Kombibetrieb“).
    """

    ausschliessliche_verwendung_im_kombibetrieb: Mapped[bool | None] = mapped_column(
        nullable=True
    )

    # KWK
    kwk_id: Mapped[str | None] = mapped_column(MASTR_ID_TYPE, nullable=True)

    # Address
    strasse: Mapped[str | None] = mapped_column(String(50), nullable=True)
    hausnummer: Mapped[str | None] = HAUS_NUMMER_COLUMN()
    postleitzahl: Mapped[str | None] = mapped_column(String(10), nullable=True)
    ort: Mapped[str | None] = ORT_COLUMN()
    land: Mapped[int] = mapped_column(nullable=False)
    bundesland: Mapped[int | None] = mapped_column(nullable=True)

    # Coordinates
    laengengrad: Mapped[float | None] = mapped_column(
        "laengengrad", nullable=True, comment="Longitude"
    )
    breitengrad: Mapped[float | None] = mapped_column(
        "breitengrad", nullable=True, comment="Latitude"
    )

    einspeisungsart: Mapped[FeedInType | None] = mapped_column(
        nullable=True, comment="Feed-in mode"
    )

    location = Column(
        Computed(func.ST_SRID(func.POINT(laengengrad, breitengrad), 4326)),
        nullable=True,
        comment="Geographical location based on longitude and latitude.",
    )

    def __repr__(self):
        return f"EinheitVerbrennung(id_={self.id_}, ArchiveDate={self.DownloadDate})"
