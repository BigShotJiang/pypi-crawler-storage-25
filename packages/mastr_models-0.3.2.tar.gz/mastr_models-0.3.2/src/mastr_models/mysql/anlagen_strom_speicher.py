from datetime import date

from sqlalchemy.orm import Mapped, mapped_column

from mastr_models.enum.anlagen_strom_speicher import (
    AnlageStromSpeicherAnlageBetriebsstatus,
)
from mastr_models.mysql.base import NewArchiveDateMixin
from mastr_models.mysql.column import MASTR_ID_TYPE
from mastr_models.types.json import ListAsJSON
from mastr_models.types.str_enum import StrEnumColumn


class AnlageStromSpeicherMixin(NewArchiveDateMixin):
    ma_st_rnummer: Mapped[str] = mapped_column(
        MASTR_ID_TYPE, primary_key=True, nullable=False, comment="MaStR ID"
    )
    registrierungsdatum: Mapped[date] = mapped_column(
        nullable=False, comment="Registration date"
    )
    datum_letzte_aktualisierung: Mapped[date] = mapped_column(
        nullable=False, comment="Last update date"
    )
    nutzbare_speicherkapazitaet: Mapped[float | None] = mapped_column(
        nullable=True, comment="Usable storage capacity (kWh)"
    )
    verknuepfte_einheiten_ma_st_rnummern: Mapped[str] = mapped_column(
        ListAsJSON,
        nullable=False,
        comment="Related generation units",
    )
    anlage_betriebsstatus: Mapped[AnlageStromSpeicherAnlageBetriebsstatus] = (
        mapped_column(
            StrEnumColumn(AnlageStromSpeicherAnlageBetriebsstatus),
            nullable=False,
            comment="Status",
        )
    )
