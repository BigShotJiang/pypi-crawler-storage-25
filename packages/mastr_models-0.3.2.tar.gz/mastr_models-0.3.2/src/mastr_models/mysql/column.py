from sqlalchemy import (
    String,
)
from sqlalchemy.orm import mapped_column

MASTR_ID_TYPE = String(15)

DEFAULT_STRING = String(255)
HAUS_NUMMER_COLUMN = lambda: mapped_column(
    String(20), nullable=True, comment="House number"
)
ORT_COLUMN = lambda: mapped_column(String(50), nullable=True, comment="City")
