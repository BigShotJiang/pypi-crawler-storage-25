from datetime import date

from sqlalchemy.orm import Mapped, mapped_column

from mastr_models.mysql.base import ArchiveDateMixin
from mastr_models.mysql.column import DEFAULT_STRING, MASTR_ID_TYPE


class AnlageKWK_Mixin(ArchiveDateMixin):
    kwk_mastr_nummer: Mapped[str] = mapped_column(
        MASTR_ID_TYPE, nullable=False, doc="KwkMastrNummer", primary_key=True
    )

    thermische_nutzleistung: Mapped[float | None] = mapped_column(
        nullable=True, comment="[kW]"
    )

    elektrische_kwk_leistung: Mapped[float | None] = mapped_column(
        nullable=True, comment="[kW]"
    )
    """Part of power generation capacity directly related to heat generation capacity.

    Original text in German: Die elektrische KWK-Leistung ist der Teil der elektrischen
    Leistung, der unmittelbar mit der im KWK-Prozess höchstens auskoppelbaren Nutzwärme
    im Zusammenhang steht.

    Hinweise:

    - Wenn es vom Hersteller der Anlage nicht anders angegeben wurde, dann ist bei
      kleinen KWK-Anlagen (z.B. bei Gasmotorenkraftwerken) die elektrische KWK-Leistung
      gleich der Nettonennleistung der Einheit.
    - Angegeben ist die elektrische KWK-Leistung der gesamten KWK-Anlage, die in vielen
      Fällen aus mehreren Einheiten besteht.
    """

    ausschreibung_zuschlag: Mapped[bool | None] = mapped_column(
        nullable=True, comment="if subsidied by KWKG levy"
    )

    zuschlagnummer: Mapped[str | None] = mapped_column(DEFAULT_STRING, nullable=True)

    inbetriebnahmedatum: Mapped[date] = mapped_column(nullable=True)
    registrierungsdatum: Mapped[date] = mapped_column(nullable=True)
