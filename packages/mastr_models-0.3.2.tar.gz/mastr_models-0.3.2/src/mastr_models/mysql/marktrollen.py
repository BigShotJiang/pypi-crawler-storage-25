from datetime import date

from sqlalchemy import String, Text
from sqlalchemy.orm import Mapped, mapped_column

from mastr_models.mysql.base import NewArchiveDateMixin
from mastr_models.mysql.column import DEFAULT_STRING, MASTR_ID_TYPE


class Marktrolle_Mixin(NewArchiveDateMixin):
    marktakteur_mastr_nummer: Mapped[str] = mapped_column(
        MASTR_ID_TYPE,
        nullable=False,
        comment="MaStR ID of the associated market actor",
    )

    mastr_nummer: Mapped[str] = mapped_column(
        String(17),
        nullable=False,
        primary_key=True,
    )

    marktrolle: Mapped[str] = mapped_column(
        DEFAULT_STRING,
        nullable=False,
        comment="Market role",
    )

    bundesnetzagentur_betriebsnummer: Mapped[str | None] = mapped_column(
        DEFAULT_STRING,
        nullable=True,
        comment="Federal Network Agency operation number",
    )

    bundesnetzagentur_betriebsnummer_nv: Mapped[bool | None] = mapped_column(
        nullable=True,
        comment="Whether BNetzA operation number is not provided",
    )

    marktpartneridentifikationsnummer: Mapped[str | None] = mapped_column(
        DEFAULT_STRING,
        nullable=True,
        comment="Market partner identification number",
    )

    marktpartneridentifikationsnummer_nv: Mapped[bool | None] = mapped_column(
        nullable=True,
        comment="Whether market partner ID is not provided",
    )

    kontaktdaten_marktrolle: Mapped[str | None] = mapped_column(
        Text,
        nullable=True,
        comment="Contact details for the market role",
    )

    datum_letzte_aktualisierung: Mapped[date | None] = mapped_column(
        nullable=True,
        comment="Last update date",
    )
