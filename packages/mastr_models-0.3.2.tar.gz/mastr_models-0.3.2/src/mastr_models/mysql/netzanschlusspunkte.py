from datetime import date

from sqlalchemy.orm import Mapped, mapped_column

from mastr_models.enum.netzanschlusspunkte import (
    NetzanschlusspunktGasqualitaet,
    NetzanschlusspunktLokationtyp,
    NetzanschlusspunktMarktgebiet,
    NetzanschlusspunktRegelzoneNetzanschlusspunkt,
    NetzanschlusspunktSpannungsebene,
)
from mastr_models.mysql.base import NewArchiveDateMixin
from mastr_models.mysql.column import DEFAULT_STRING, MASTR_ID_TYPE
from mastr_models.types.str_enum import StrEnumColumn


class Netzanschlusspunkt_Mixin(NewArchiveDateMixin):
    netzanschlusspunkt_mastr_nummer: Mapped[str] = mapped_column(
        MASTR_ID_TYPE,
        nullable=False,
        primary_key=True,
        comment="MaStR ID of the grid connection point",
    )

    netzanschlusspunkt_bezeichnung: Mapped[str | None] = mapped_column(
        DEFAULT_STRING,
        nullable=True,
        comment="Name/label of the grid connection point",
    )

    letzte_aenderung: Mapped[date | None] = mapped_column(
        nullable=True,
        comment="Last modification date",
    )

    lokation_ma_st_rnummer: Mapped[str] = mapped_column(
        MASTR_ID_TYPE,
        nullable=False,
        comment="MaStR ID of the associated location",
    )

    name_der_technischen_lokation: Mapped[str | None] = mapped_column(
        DEFAULT_STRING,
        nullable=True,
        comment="Name of the technical location",
    )

    lokationtyp: Mapped[NetzanschlusspunktLokationtyp | None] = mapped_column(
        StrEnumColumn(NetzanschlusspunktLokationtyp),
        nullable=True,
        comment="Location type",
    )

    maximale_einspeiseleistung: Mapped[float | None] = mapped_column(
        nullable=True,
        comment="Maximum feed-in capacity [kW]",
    )

    maximale_ausspeiseleistung: Mapped[float | None] = mapped_column(
        nullable=True,
        comment="Maximum offtake capacity [kW]",
    )

    gasqualitaet: Mapped[NetzanschlusspunktGasqualitaet | None] = mapped_column(
        StrEnumColumn(NetzanschlusspunktGasqualitaet),
        nullable=True,
        comment="Gas quality",
    )

    messlokation: Mapped[str | None] = mapped_column(
        DEFAULT_STRING,
        nullable=True,
        comment="Metering location ID",
    )

    marktgebiet: Mapped[NetzanschlusspunktMarktgebiet | None] = mapped_column(
        StrEnumColumn(NetzanschlusspunktMarktgebiet),
        nullable=True,
        comment="Market area",
    )

    spannungsebene: Mapped[NetzanschlusspunktSpannungsebene | None] = mapped_column(
        StrEnumColumn(NetzanschlusspunktSpannungsebene),
        nullable=True,
        comment="Voltage level",
    )

    regelzone_netzanschlusspunkt: Mapped[
        NetzanschlusspunktRegelzoneNetzanschlusspunkt | None
    ] = mapped_column(
        StrEnumColumn(NetzanschlusspunktRegelzoneNetzanschlusspunkt),
        nullable=True,
        comment="Control area of the connection point",
    )

    nettoengpassleistung: Mapped[float | None] = mapped_column(
        nullable=True,
        comment="Net transfer capacity [kW]",
    )

    bilanzierungsgebiet_netzanschlusspunkt_id: Mapped[int | None] = mapped_column(
        nullable=True,
        comment="balancing area ID",
    )

    netzanschlusskapazitaet: Mapped[float | None] = mapped_column(
        nullable=True,
        comment="Connection capacity [kW]",
    )

    netz_ma_st_rnummer: Mapped[str] = mapped_column(
        MASTR_ID_TYPE,
        nullable=False,
        comment="MaStR ID of the associated grid",
    )

    noch_in_planung: Mapped[bool | None] = mapped_column(
        nullable=True,
        comment="Whether the connection point is still in planning",
    )
    netzbetreiber_ma_st_rnummer: Mapped[str] = mapped_column(
        MASTR_ID_TYPE,
        nullable=False,
        comment="MaStR ID of the grid operator",
    )
