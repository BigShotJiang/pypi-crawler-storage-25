from mastr_models.mysql.eeg.anlagen_eeg import AnlageEegMixin


class AnlageEegSpeicher(AnlageEegMixin):
    __tablename__ = "AnlageEegSpeicher"
    __table_args__ = {"schema": "nemo"}
