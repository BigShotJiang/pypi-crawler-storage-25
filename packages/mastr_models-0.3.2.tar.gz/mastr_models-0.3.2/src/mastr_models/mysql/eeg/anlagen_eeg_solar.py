from datetime import date

from sqlalchemy.orm import Mapped, mapped_column

from mastr_models.enum.anlagen_eeg_solar import AnlageEegSolarAnlageBetriebsstatus
from mastr_models.mysql.column import DEFAULT_STRING
from mastr_models.mysql.eeg.anlagen_eeg import AnlageEegMixin
from mastr_models.types.str_enum import StrEnumColumn


class AnlageEegSolar(AnlageEegMixin):
    anlage_betriebsstatus: Mapped[AnlageEegSolarAnlageBetriebsstatus | None] = (
        mapped_column(
            StrEnumColumn(AnlageEegSolarAnlageBetriebsstatus),
            nullable=True,
            comment="Plant operational status",
        )
    )
    inanspruchnahme_zahlung_nach_eeg: Mapped[bool | None] = mapped_column(
        nullable=True, comment="Taking advantage of payment under EEG"
    )
    anlagenkennziffer_anlagenregister: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="Plant register identifier"
    )
    anlagenkennziffer_anlagenregister_nv: Mapped[bool | None] = mapped_column(
        nullable=True, comment="Plant register identifier not available"
    )
    installierte_leistung: Mapped[float | None] = mapped_column(
        nullable=True, comment="Installed capacity"
    )
    registrierungsnummer_pv_meldeportal: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="PV reporting portal registration number"
    )
    registrierungsnummer_pv_meldeportal_nv: Mapped[bool | None] = mapped_column(
        nullable=True, comment="PV reporting portal registration number not available"
    )
    mieterstrom_zugeordnet: Mapped[bool | None] = mapped_column(
        nullable=True, comment="Assigned to tenant electricity"
    )
    mieterstrom_meldedatum: Mapped[date | None] = mapped_column(
        nullable=True, comment="Tenant electricity reporting date"
    )
    mieterstrom_erste_zuordnung_zuschlag: Mapped[date | None] = mapped_column(
        nullable=True, comment="Tenant electricity first assignment with surcharge"
    )
    zugeordnete_gebotsmenge: Mapped[float | None] = mapped_column(
        nullable=True, comment="Assigned bid quantity"
    )
