from datetime import date

from sqlalchemy.orm import Mapped, mapped_column

from mastr_models.mysql.base import NewArchiveDateMixin
from mastr_models.mysql.column import DEFAULT_STRING, MASTR_ID_TYPE


class AnlageEegMixin(NewArchiveDateMixin):
    eeg_ma_st_rnummer: Mapped[str | None] = mapped_column(
        MASTR_ID_TYPE, primary_key=True, nullable=False, comment="MaStR ID"
    )

    registrierungsdatum: Mapped[date | None] = mapped_column(
        nullable=True, comment="Registration date"
    )
    datum_letzte_aktualisierung: Mapped[date | None] = mapped_column(
        nullable=True, comment="Last update date"
    )
    eeg_inbetriebnahmedatum: Mapped[date | None] = mapped_column(
        nullable=True, comment="commissioning date"
    )
    anlagenschluessel_eeg: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="EEG plant key"
    )
    ausschreibung_zuschlag: Mapped[bool | None] = mapped_column(
        nullable=True, comment="Auction award"
    )
    zuschlagsnummer: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="Award number"
    )
    verknuepfte_einheiten_ma_st_rnummern: Mapped[str] = mapped_column(
        MASTR_ID_TYPE,
        nullable=False,
        comment="Related MaStR generation units",
    )
