from datetime import datetime

from sqlalchemy import DateTime, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from mastr_models.mysql.column import MASTR_ID_TYPE


class LokationMixin:
    mastr_nummer: Mapped[str] = mapped_column(
        MASTR_ID_TYPE, nullable=False, primary_key=True, comment="MaStR number"
    )
    datum_letzte_aktualisierung: Mapped[datetime] = mapped_column(
        DateTime, nullable=True, comment="Last update date/time"
    )
    name_der_technischen_lokation: Mapped[str] = mapped_column(
        String(128), nullable=True, comment="Name of the technical location"
    )
    lokationtyp: Mapped[int] = mapped_column(
        Integer, nullable=False, comment="Location type (enum)"
    )
    verknuepfte_einheiten_ma_st_rnummern: Mapped[str] = mapped_column(
        MASTR_ID_TYPE, nullable=False, comment="Linked unit MaStR numbers"
    )
    netzanschlusspunkte_ma_st_rnummern: Mapped[str] = mapped_column(
        MASTR_ID_TYPE, nullable=True, comment="Grid connection point MaStR numbers"
    )
