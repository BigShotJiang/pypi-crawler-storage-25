from datetime import date

from sqlalchemy.orm import Mapped, mapped_column


class ArchiveDateMixin:
    DownloadDate: Mapped[date] = mapped_column(nullable=False, primary_key=True)


class NewArchiveDateMixin:
    archive_date: Mapped[date] = mapped_column(
        nullable=False, primary_key=True, comment="when the dataset was archived"
    )
