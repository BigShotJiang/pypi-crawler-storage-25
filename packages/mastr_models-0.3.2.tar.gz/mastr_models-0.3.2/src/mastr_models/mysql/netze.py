from abc import abstractmethod
from datetime import date
from typing import TYPE_CHECKING, Optional

from sqlalchemy.orm import Mapped, declared_attr, mapped_column, relationship

from mastr_models.mysql.base import NewArchiveDateMixin
from mastr_models.mysql.column import DEFAULT_STRING, MASTR_ID_TYPE
from mastr_models.types.json import ListAsJSON
from mastr_models.validation.netze import GridType

if TYPE_CHECKING:
    from mastr_models.mysql.marktakteure import MarktakteurMixin


class Netz_Mixin(NewArchiveDateMixin):
    mastr_nummer: Mapped[str] = mapped_column(
        MASTR_ID_TYPE, nullable=False, primary_key=True, comment="MaStR ID"
    )

    sparte: Mapped[GridType] = mapped_column(nullable=False, comment="Sparte")

    kunden_angeschlossen: Mapped[bool | None] = mapped_column(
        nullable=True, comment="Whether customers are connected"
    )

    geschlossenes_verteilnetz: Mapped[bool | None] = mapped_column(
        nullable=True, comment="Whether closed distribution network"
    )

    bezeichnung: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="Name"
    )

    marktgebiet: Mapped[int | None] = mapped_column(
        nullable=True, comment="Market area"
    )

    bundesland: Mapped[str | None] = mapped_column(
        DEFAULT_STRING, nullable=True, comment="Federal state"
    )

    bilanzierungsgebiete: Mapped[list[str] | None] = mapped_column(
        ListAsJSON, nullable=True, comment="Balancing areas"
    )

    datum_letzte_aktualisierung: Mapped[date | None] = mapped_column(
        nullable=True, comment="Last update date"
    )

    @classmethod
    @abstractmethod
    def _MapperMarktakteur(cls) -> type["MarktakteurMixin"]:
        raise NotImplementedError

    @declared_attr
    def Marktakteur(cls) -> Mapped[Optional["Netz_Mixin"]]:
        return relationship(
            "MaStR_Marktakteur",
            primaryjoin=lambda: cls._MapperMarktakteur().netz == cls.mastr_nummer,
            viewonly=True,
            foreign_keys=lambda: cls._MapperMarktakteur().netz,
            back_populates="Netz",
        )
