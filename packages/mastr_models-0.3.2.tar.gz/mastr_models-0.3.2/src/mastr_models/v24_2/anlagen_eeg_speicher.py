from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from xsdata.models.datatype import XmlDate, XmlDateTime


class AnlageEegSpeicherAusschreibungZuschlag(Enum):
    VALUE_1 = 1
    VALUE_0 = 0


@dataclass
class AnlagenEegSpeicher:
    anlage_eeg_speicher: list["AnlagenEegSpeicher.AnlageEegSpeicher"] = field(
        default_factory=list,
        metadata={
            "name": "AnlageEegSpeicher",
            "type": "Element",
        },
    )

    @dataclass
    class AnlageEegSpeicher:
        registrierungsdatum: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "Registrierungsdatum",
                "type": "Element",
                "required": True,
            },
        )
        datum_letzte_aktualisierung: Optional[XmlDateTime] = field(
            default=None,
            metadata={
                "name": "DatumLetzteAktualisierung",
                "type": "Element",
                "required": True,
            },
        )
        eeg_inbetriebnahmedatum: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "EegInbetriebnahmedatum",
                "type": "Element",
                "required": True,
            },
        )
        eeg_ma_st_rnummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "EegMaStRNummer",
                "type": "Element",
                "required": True,
            },
        )
        anlagenschluessel_eeg: Optional[str] = field(
            default=None,
            metadata={
                "name": "AnlagenschluesselEeg",
                "type": "Element",
                "required": True,
            },
        )
        ausschreibung_zuschlag: Optional[
            AnlageEegSpeicherAusschreibungZuschlag
        ] = field(
            default=None,
            metadata={
                "name": "AusschreibungZuschlag",
                "type": "Element",
            },
        )
        zuschlagsnummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "Zuschlagsnummer",
                "type": "Element",
                "required": True,
            },
        )
        verknuepfte_einheiten_ma_st_rnummern: Optional[str] = field(
            default=None,
            metadata={
                "name": "VerknuepfteEinheitenMaStRNummern",
                "type": "Element",
                "required": True,
            },
        )
