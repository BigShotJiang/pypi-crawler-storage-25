from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class BilanzierungsgebietRegelzoneNetzanschlusspunkt(Enum):
    VALUE_1000001 = 1000001
    VALUE_1000010 = 1000010
    VALUE_1001572 = 1001572
    VALUE_1001564 = 1001564


@dataclass
class Bilanzierungsgebiete:
    bilanzierungsgebiet: list["Bilanzierungsgebiete.Bilanzierungsgebiet"] = (
        field(
            default_factory=list,
            metadata={
                "name": "Bilanzierungsgebiet",
                "type": "Element",
            },
        )
    )

    @dataclass
    class Bilanzierungsgebiet:
        id: Optional[int] = field(
            default=None,
            metadata={
                "name": "Id",
                "type": "Element",
                "required": True,
            },
        )
        yeic: Optional[str] = field(
            default=None,
            metadata={
                "name": "Yeic",
                "type": "Element",
            },
        )
        bilanzierungsgebiet_netzanschlusspunkt: Optional[str] = field(
            default=None,
            metadata={
                "name": "BilanzierungsgebietNetzanschlusspunkt",
                "type": "Element",
            },
        )
        regelzone_netzanschlusspunkt: Optional[
            BilanzierungsgebietRegelzoneNetzanschlusspunkt
        ] = field(
            default=None,
            metadata={
                "name": "RegelzoneNetzanschlusspunkt",
                "type": "Element",
                "required": True,
            },
        )
