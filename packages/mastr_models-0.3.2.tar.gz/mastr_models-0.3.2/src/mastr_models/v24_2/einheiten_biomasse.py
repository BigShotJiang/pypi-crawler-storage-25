from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from xsdata.models.datatype import XmlDate, XmlDateTime


class EinheitBiomasseAnschlussAnHoechstOderHochSpannung(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitBiomasseBiomasseart(Enum):
    VALUE_721 = 721
    VALUE_719 = 719
    VALUE_720 = 720


class EinheitBiomasseBundesland(Enum):
    VALUE_1416 = 1416
    VALUE_1402 = 1402
    VALUE_1403 = 1403
    VALUE_1401 = 1401
    VALUE_1400 = 1400
    VALUE_1404 = 1404
    VALUE_1406 = 1406
    VALUE_1405 = 1405
    VALUE_1407 = 1407
    VALUE_1408 = 1408
    VALUE_1409 = 1409
    VALUE_1410 = 1410
    VALUE_1412 = 1412
    VALUE_1413 = 1413
    VALUE_1414 = 1414
    VALUE_1411 = 1411
    VALUE_1415 = 1415


class EinheitBiomasseEinheitBetriebsstatus(Enum):
    VALUE_35 = 35
    VALUE_38 = 38
    VALUE_37 = 37
    VALUE_31 = 31


class EinheitBiomasseEinheitSystemstatus(Enum):
    VALUE_472 = 472
    VALUE_473 = 473
    VALUE_484 = 484
    VALUE_490 = 490
    VALUE_572 = 572


class EinheitBiomasseEinspeisungsart(Enum):
    VALUE_689 = 689
    VALUE_688 = 688


class EinheitBiomasseEnergietraeger(Enum):
    VALUE_2411 = 2411
    VALUE_2493 = 2493
    VALUE_2408 = 2408
    VALUE_2410 = 2410
    VALUE_2494 = 2494
    VALUE_2409 = 2409
    VALUE_2412 = 2412
    VALUE_2407 = 2407
    VALUE_2413 = 2413
    VALUE_2403 = 2403
    VALUE_2404 = 2404
    VALUE_2405 = 2405
    VALUE_2495 = 2495
    VALUE_2406 = 2406
    VALUE_2957 = 2957
    VALUE_2958 = 2958
    VALUE_2496 = 2496
    VALUE_2498 = 2498
    VALUE_2497 = 2497


class EinheitBiomasseFernsteuerbarkeitDv(Enum):
    VALUE_1 = 1
    VALUE_0 = 0


class EinheitBiomasseFernsteuerbarkeitNb(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitBiomasseHauptbrennstoff(Enum):
    VALUE_2414 = 2414
    VALUE_2415 = 2415
    VALUE_2416 = 2416
    VALUE_2417 = 2417
    VALUE_2418 = 2418
    VALUE_2419 = 2419
    VALUE_2420 = 2420
    VALUE_2421 = 2421
    VALUE_2422 = 2422
    VALUE_2423 = 2423
    VALUE_2424 = 2424
    VALUE_2425 = 2425
    VALUE_2426 = 2426
    VALUE_2427 = 2427
    VALUE_2428 = 2428
    VALUE_2429 = 2429
    VALUE_2430 = 2430
    VALUE_2431 = 2431
    VALUE_2432 = 2432
    VALUE_2433 = 2433
    VALUE_2434 = 2434
    VALUE_2435 = 2435
    VALUE_2436 = 2436
    VALUE_2437 = 2437
    VALUE_2438 = 2438
    VALUE_2439 = 2439
    VALUE_2440 = 2440
    VALUE_2441 = 2441
    VALUE_2442 = 2442
    VALUE_2443 = 2443
    VALUE_2444 = 2444
    VALUE_2445 = 2445
    VALUE_2446 = 2446
    VALUE_2447 = 2447
    VALUE_2448 = 2448


class EinheitBiomasseHausnummerNichtGefunden(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitBiomasseHausnummerNv(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitBiomasseKraftwerksnummerNv(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitBiomasseLand(Enum):
    VALUE_84 = 84
    VALUE_90 = 90
    VALUE_198 = 198
    VALUE_66 = 66
    VALUE_169 = 169
    VALUE_106 = 106
    VALUE_231 = 231
    VALUE_206 = 206
    VALUE_215 = 215
    VALUE_269 = 269


class EinheitBiomasseNetzbetreiberpruefungStatus(Enum):
    VALUE_2954 = 2954
    VALUE_2955 = 2955
    VALUE_3075 = 3075


class EinheitBiomasseNichtVorhandenInMigriertenEinheiten(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitBiomasseReserveartNachDemEnWg(Enum):
    VALUE_3078 = 3078
    VALUE_3079 = 3079
    VALUE_3080 = 3080


class EinheitBiomasseStrasseNichtGefunden(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitBiomasseTechnologie(Enum):
    VALUE_542 = 542
    VALUE_543 = 543
    VALUE_544 = 544
    VALUE_545 = 545
    VALUE_546 = 546
    VALUE_833 = 833
    VALUE_834 = 834
    VALUE_835 = 835
    VALUE_836 = 836
    VALUE_837 = 837
    VALUE_838 = 838
    VALUE_839 = 839
    VALUE_840 = 840
    VALUE_1538 = 1538


class EinheitBiomasseWeicNv(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


@dataclass
class EinheitenBiomasse:
    einheit_biomasse: list["EinheitenBiomasse.EinheitBiomasse"] = field(
        default_factory=list,
        metadata={
            "name": "EinheitBiomasse",
            "type": "Element",
        },
    )

    @dataclass
    class EinheitBiomasse:
        einheit_mastr_nummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "EinheitMastrNummer",
                "type": "Element",
                "required": True,
            },
        )
        datum_letzte_aktualisierung: Optional[XmlDateTime] = field(
            default=None,
            metadata={
                "name": "DatumLetzteAktualisierung",
                "type": "Element",
                "required": True,
            },
        )
        lokation_ma_st_rnummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "LokationMaStRNummer",
                "type": "Element",
            },
        )
        netzbetreiberpruefung_status: Optional[
            EinheitBiomasseNetzbetreiberpruefungStatus
        ] = field(
            default=None,
            metadata={
                "name": "NetzbetreiberpruefungStatus",
                "type": "Element",
                "required": True,
            },
        )
        netzbetreiberpruefung_datum: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "NetzbetreiberpruefungDatum",
                "type": "Element",
            },
        )
        anlagenbetreiber_mastr_nummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "AnlagenbetreiberMastrNummer",
                "type": "Element",
            },
        )
        land: Optional[EinheitBiomasseLand] = field(
            default=None,
            metadata={
                "name": "Land",
                "type": "Element",
                "required": True,
            },
        )
        bundesland: Optional[EinheitBiomasseBundesland] = field(
            default=None,
            metadata={
                "name": "Bundesland",
                "type": "Element",
            },
        )
        landkreis: Optional[str] = field(
            default=None,
            metadata={
                "name": "Landkreis",
                "type": "Element",
            },
        )
        gemeinde: Optional[str] = field(
            default=None,
            metadata={
                "name": "Gemeinde",
                "type": "Element",
            },
        )
        gemeindeschluessel: Optional[str] = field(
            default=None,
            metadata={
                "name": "Gemeindeschluessel",
                "type": "Element",
            },
        )
        postleitzahl: Optional[str] = field(
            default=None,
            metadata={
                "name": "Postleitzahl",
                "type": "Element",
            },
        )
        strasse: Optional[str] = field(
            default=None,
            metadata={
                "name": "Strasse",
                "type": "Element",
            },
        )
        gemarkung: Optional[str] = field(
            default=None,
            metadata={
                "name": "Gemarkung",
                "type": "Element",
            },
        )
        flur_flurstuecknummern: Optional[str] = field(
            default=None,
            metadata={
                "name": "FlurFlurstuecknummern",
                "type": "Element",
            },
        )
        strasse_nicht_gefunden: Optional[
            EinheitBiomasseStrasseNichtGefunden
        ] = field(
            default=None,
            metadata={
                "name": "StrasseNichtGefunden",
                "type": "Element",
            },
        )
        hausnummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "Hausnummer",
                "type": "Element",
            },
        )
        hausnummer_nv: Optional[EinheitBiomasseHausnummerNv] = field(
            default=None,
            metadata={
                "name": "Hausnummer_nv",
                "type": "Element",
            },
        )
        hausnummer_nicht_gefunden: Optional[
            EinheitBiomasseHausnummerNichtGefunden
        ] = field(
            default=None,
            metadata={
                "name": "HausnummerNichtGefunden",
                "type": "Element",
            },
        )
        adresszusatz: Optional[str] = field(
            default=None,
            metadata={
                "name": "Adresszusatz",
                "type": "Element",
            },
        )
        ort: Optional[str] = field(
            default=None,
            metadata={
                "name": "Ort",
                "type": "Element",
            },
        )
        laengengrad: Optional[float] = field(
            default=None,
            metadata={
                "name": "Laengengrad",
                "type": "Element",
            },
        )
        breitengrad: Optional[float] = field(
            default=None,
            metadata={
                "name": "Breitengrad",
                "type": "Element",
            },
        )
        registrierungsdatum: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "Registrierungsdatum",
                "type": "Element",
                "required": True,
            },
        )
        inbetriebnahmedatum: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "Inbetriebnahmedatum",
                "type": "Element",
            },
        )
        datum_endgueltige_stilllegung: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "DatumEndgueltigeStilllegung",
                "type": "Element",
            },
        )
        datum_beginn_voruebergehende_stilllegung: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "DatumBeginnVoruebergehendeStilllegung",
                "type": "Element",
            },
        )
        datum_wiederaufnahme_betrieb: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "DatumWiederaufnahmeBetrieb",
                "type": "Element",
            },
        )
        geplantes_inbetriebnahmedatum: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "GeplantesInbetriebnahmedatum",
                "type": "Element",
            },
        )
        einheit_systemstatus: Optional[EinheitBiomasseEinheitSystemstatus] = (
            field(
                default=None,
                metadata={
                    "name": "EinheitSystemstatus",
                    "type": "Element",
                    "required": True,
                },
            )
        )
        einheit_betriebsstatus: Optional[
            EinheitBiomasseEinheitBetriebsstatus
        ] = field(
            default=None,
            metadata={
                "name": "EinheitBetriebsstatus",
                "type": "Element",
                "required": True,
            },
        )
        bestandsanlage_mastr_nummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "BestandsanlageMastrNummer",
                "type": "Element",
            },
        )
        nicht_vorhanden_in_migrierten_einheiten: Optional[
            EinheitBiomasseNichtVorhandenInMigriertenEinheiten
        ] = field(
            default=None,
            metadata={
                "name": "NichtVorhandenInMigriertenEinheiten",
                "type": "Element",
                "required": True,
            },
        )
        alt_anlagenbetreiber_mastr_nummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "AltAnlagenbetreiberMastrNummer",
                "type": "Element",
            },
        )
        datum_des_betreiberwechsels: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "DatumDesBetreiberwechsels",
                "type": "Element",
            },
        )
        datum_registrierung_des_betreiberwechsels: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "DatumRegistrierungDesBetreiberwechsels",
                "type": "Element",
            },
        )
        name_stromerzeugungseinheit: Optional[str] = field(
            default=None,
            metadata={
                "name": "NameStromerzeugungseinheit",
                "type": "Element",
                "required": True,
            },
        )
        weic: Optional[str] = field(
            default=None,
            metadata={
                "name": "Weic",
                "type": "Element",
            },
        )
        weic_nv: Optional[EinheitBiomasseWeicNv] = field(
            default=None,
            metadata={
                "name": "Weic_nv",
                "type": "Element",
                "required": True,
            },
        )
        weic_display_name: Optional[str] = field(
            default=None,
            metadata={
                "name": "WeicDisplayName",
                "type": "Element",
            },
        )
        kraftwerksnummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "Kraftwerksnummer",
                "type": "Element",
            },
        )
        kraftwerksnummer_nv: Optional[EinheitBiomasseKraftwerksnummerNv] = (
            field(
                default=None,
                metadata={
                    "name": "Kraftwerksnummer_nv",
                    "type": "Element",
                    "required": True,
                },
            )
        )
        energietraeger: Optional[EinheitBiomasseEnergietraeger] = field(
            default=None,
            metadata={
                "name": "Energietraeger",
                "type": "Element",
                "required": True,
            },
        )
        bruttoleistung: Optional[float] = field(
            default=None,
            metadata={
                "name": "Bruttoleistung",
                "type": "Element",
                "required": True,
            },
        )
        nettonennleistung: Optional[float] = field(
            default=None,
            metadata={
                "name": "Nettonennleistung",
                "type": "Element",
            },
        )
        anschluss_an_hoechst_oder_hoch_spannung: Optional[
            EinheitBiomasseAnschlussAnHoechstOderHochSpannung
        ] = field(
            default=None,
            metadata={
                "name": "AnschlussAnHoechstOderHochSpannung",
                "type": "Element",
            },
        )
        einsatzverantwortlicher: Optional[str] = field(
            default=None,
            metadata={
                "name": "Einsatzverantwortlicher",
                "type": "Element",
            },
        )
        fernsteuerbarkeit_nb: Optional[EinheitBiomasseFernsteuerbarkeitNb] = (
            field(
                default=None,
                metadata={
                    "name": "FernsteuerbarkeitNb",
                    "type": "Element",
                },
            )
        )
        fernsteuerbarkeit_dv: Optional[EinheitBiomasseFernsteuerbarkeitDv] = (
            field(
                default=None,
                metadata={
                    "name": "FernsteuerbarkeitDv",
                    "type": "Element",
                },
            )
        )
        einspeisungsart: Optional[EinheitBiomasseEinspeisungsart] = field(
            default=None,
            metadata={
                "name": "Einspeisungsart",
                "type": "Element",
            },
        )
        gen_mastr_nummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "GenMastrNummer",
                "type": "Element",
            },
        )
        reserveart_nach_dem_en_wg: Optional[
            EinheitBiomasseReserveartNachDemEnWg
        ] = field(
            default=None,
            metadata={
                "name": "ReserveartNachDemEnWG",
                "type": "Element",
                "required": True,
            },
        )
        datum_ueberfuehrung_in_reserve: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "DatumUeberfuehrungInReserve",
                "type": "Element",
                "required": True,
            },
        )
        hauptbrennstoff: Optional[EinheitBiomasseHauptbrennstoff] = field(
            default=None,
            metadata={
                "name": "Hauptbrennstoff",
                "type": "Element",
            },
        )
        biomasseart: Optional[EinheitBiomasseBiomasseart] = field(
            default=None,
            metadata={
                "name": "Biomasseart",
                "type": "Element",
                "required": True,
            },
        )
        technologie: Optional[EinheitBiomasseTechnologie] = field(
            default=None,
            metadata={
                "name": "Technologie",
                "type": "Element",
            },
        )
        eeg_ma_st_rnummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "EegMaStRNummer",
                "type": "Element",
            },
        )
        kwk_ma_st_rnummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "KwkMaStRNummer",
                "type": "Element",
            },
        )
