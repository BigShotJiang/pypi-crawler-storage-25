from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from xsdata.models.datatype import XmlDateTime


class LokationLokationtyp(Enum):
    VALUE_3 = 3
    VALUE_2 = 2
    VALUE_4 = 4
    VALUE_1 = 1


@dataclass
class Lokationen:
    lokation: list["Lokationen.Lokation"] = field(
        default_factory=list,
        metadata={
            "name": "Lokation",
            "type": "Element",
        },
    )

    @dataclass
    class Lokation:
        datum_letzte_aktualisierung: Optional[XmlDateTime] = field(
            default=None,
            metadata={
                "name": "DatumLetzteAktualisierung",
                "type": "Element",
            },
        )
        mastr_nummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "MastrNummer",
                "type": "Element",
                "required": True,
            },
        )
        name_der_technischen_lokation: Optional[str] = field(
            default=None,
            metadata={
                "name": "NameDerTechnischenLokation",
                "type": "Element",
            },
        )
        lokationtyp: Optional[LokationLokationtyp] = field(
            default=None,
            metadata={
                "name": "Lokationtyp",
                "type": "Element",
                "required": True,
            },
        )
        verknuepfte_einheiten_ma_st_rnummern: Optional[str] = field(
            default=None,
            metadata={
                "name": "VerknuepfteEinheitenMaStRNummern",
                "type": "Element",
                "required": True,
            },
        )
        netzanschlusspunkte_ma_st_rnummern: Optional[str] = field(
            default=None,
            metadata={
                "name": "NetzanschlusspunkteMaStRNummern",
                "type": "Element",
            },
        )
