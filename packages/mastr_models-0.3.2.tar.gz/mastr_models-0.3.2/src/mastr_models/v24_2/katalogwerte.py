from dataclasses import dataclass, field
from typing import Optional


@dataclass
class Katalogwerte:
    katalogwert: list["Katalogwerte.Katalogwert"] = field(
        default_factory=list,
        metadata={
            "name": "Katalogwert",
            "type": "Element",
        },
    )

    @dataclass
    class Katalogwert:
        id: Optional[int] = field(
            default=None,
            metadata={
                "name": "Id",
                "type": "Element",
                "required": True,
            },
        )
        wert: Optional[str] = field(
            default=None,
            metadata={
                "name": "Wert",
                "type": "Element",
                "required": True,
            },
        )
        katalog_kategorie_id: Optional[int] = field(
            default=None,
            metadata={
                "name": "KatalogKategorieId",
                "type": "Element",
                "required": True,
            },
        )
