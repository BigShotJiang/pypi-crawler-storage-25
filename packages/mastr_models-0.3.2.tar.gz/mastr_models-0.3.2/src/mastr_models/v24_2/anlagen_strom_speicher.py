from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from xsdata.models.datatype import XmlDate, XmlDateTime


class AnlageStromSpeicherAnlageBetriebsstatus(Enum):
    VALUE_35 = 35
    VALUE_31 = 31
    VALUE_38 = 38
    VALUE_37 = 37


@dataclass
class AnlagenStromSpeicher:
    anlage_strom_speicher: list["AnlagenStromSpeicher.AnlageStromSpeicher"] = (
        field(
            default_factory=list,
            metadata={
                "name": "AnlageStromSpeicher",
                "type": "Element",
            },
        )
    )

    @dataclass
    class AnlageStromSpeicher:
        ma_st_rnummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "MaStRNummer",
                "type": "Element",
                "required": True,
            },
        )
        registrierungsdatum: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "Registrierungsdatum",
                "type": "Element",
                "required": True,
            },
        )
        datum_letzte_aktualisierung: Optional[XmlDateTime] = field(
            default=None,
            metadata={
                "name": "DatumLetzteAktualisierung",
                "type": "Element",
                "required": True,
            },
        )
        nutzbare_speicherkapazitaet: Optional[float] = field(
            default=None,
            metadata={
                "name": "NutzbareSpeicherkapazitaet",
                "type": "Element",
                "required": True,
            },
        )
        verknuepfte_einheiten_ma_st_rnummern: Optional[str] = field(
            default=None,
            metadata={
                "name": "VerknuepfteEinheitenMaStRNummern",
                "type": "Element",
                "required": True,
            },
        )
        anlage_betriebsstatus: Optional[
            AnlageStromSpeicherAnlageBetriebsstatus
        ] = field(
            default=None,
            metadata={
                "name": "AnlageBetriebsstatus",
                "type": "Element",
                "required": True,
            },
        )
