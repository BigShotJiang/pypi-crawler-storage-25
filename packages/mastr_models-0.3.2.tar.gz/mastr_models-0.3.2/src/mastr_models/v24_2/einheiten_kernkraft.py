from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from xsdata.models.datatype import XmlDate, XmlDateTime


class EinheitKernkraftAnschlussAnHoechstOderHochSpannung(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitKernkraftBundesland(Enum):
    VALUE_1416 = 1416
    VALUE_1402 = 1402
    VALUE_1403 = 1403
    VALUE_1401 = 1401
    VALUE_1400 = 1400
    VALUE_1404 = 1404
    VALUE_1406 = 1406
    VALUE_1405 = 1405
    VALUE_1407 = 1407
    VALUE_1408 = 1408
    VALUE_1409 = 1409
    VALUE_1410 = 1410
    VALUE_1412 = 1412
    VALUE_1413 = 1413
    VALUE_1414 = 1414
    VALUE_1411 = 1411
    VALUE_1415 = 1415


class EinheitKernkraftEinheitBetriebsstatus(Enum):
    VALUE_35 = 35
    VALUE_38 = 38
    VALUE_37 = 37
    VALUE_31 = 31


class EinheitKernkraftEinheitSystemstatus(Enum):
    VALUE_472 = 472
    VALUE_473 = 473
    VALUE_484 = 484
    VALUE_490 = 490
    VALUE_572 = 572


class EinheitKernkraftEinspeisungsart(Enum):
    VALUE_689 = 689
    VALUE_688 = 688


class EinheitKernkraftEnergietraeger(Enum):
    VALUE_2411 = 2411
    VALUE_2493 = 2493
    VALUE_2408 = 2408
    VALUE_2410 = 2410
    VALUE_2494 = 2494
    VALUE_2409 = 2409
    VALUE_2412 = 2412
    VALUE_2407 = 2407
    VALUE_2413 = 2413
    VALUE_2403 = 2403
    VALUE_2404 = 2404
    VALUE_2405 = 2405
    VALUE_2495 = 2495
    VALUE_2406 = 2406
    VALUE_2957 = 2957
    VALUE_2958 = 2958
    VALUE_2496 = 2496
    VALUE_2498 = 2498
    VALUE_2497 = 2497


class EinheitKernkraftFernsteuerbarkeitDv(Enum):
    VALUE_1 = 1
    VALUE_0 = 0


class EinheitKernkraftFernsteuerbarkeitNb(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitKernkraftHausnummer(Enum):
    VALUE_1 = 1
    VALUE_2 = 2


class EinheitKernkraftHausnummerNichtGefunden(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitKernkraftHausnummerNv(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitKernkraftKraftwerksnummerNv(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitKernkraftLand(Enum):
    VALUE_84 = 84
    VALUE_90 = 90
    VALUE_198 = 198
    VALUE_66 = 66
    VALUE_169 = 169
    VALUE_106 = 106
    VALUE_231 = 231
    VALUE_206 = 206
    VALUE_215 = 215
    VALUE_269 = 269


class EinheitKernkraftNetzbetreiberpruefungStatus(Enum):
    VALUE_2954 = 2954
    VALUE_2955 = 2955
    VALUE_3075 = 3075


class EinheitKernkraftNichtVorhandenInMigriertenEinheiten(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitKernkraftStrasseNichtGefunden(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitKernkraftTechnologie(Enum):
    VALUE_1444 = 1444
    VALUE_1445 = 1445


class EinheitKernkraftWeicNv(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


@dataclass
class EinheitenKernkraft:
    einheit_kernkraft: list["EinheitenKernkraft.EinheitKernkraft"] = field(
        default_factory=list,
        metadata={
            "name": "EinheitKernkraft",
            "type": "Element",
        },
    )

    @dataclass
    class EinheitKernkraft:
        einheit_mastr_nummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "EinheitMastrNummer",
                "type": "Element",
                "required": True,
            },
        )
        datum_letzte_aktualisierung: Optional[XmlDateTime] = field(
            default=None,
            metadata={
                "name": "DatumLetzteAktualisierung",
                "type": "Element",
                "required": True,
            },
        )
        lokation_ma_st_rnummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "LokationMaStRNummer",
                "type": "Element",
            },
        )
        netzbetreiberpruefung_status: Optional[
            EinheitKernkraftNetzbetreiberpruefungStatus
        ] = field(
            default=None,
            metadata={
                "name": "NetzbetreiberpruefungStatus",
                "type": "Element",
                "required": True,
            },
        )
        netzbetreiberpruefung_datum: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "NetzbetreiberpruefungDatum",
                "type": "Element",
                "required": True,
            },
        )
        anlagenbetreiber_mastr_nummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "AnlagenbetreiberMastrNummer",
                "type": "Element",
            },
        )
        land: Optional[EinheitKernkraftLand] = field(
            default=None,
            metadata={
                "name": "Land",
                "type": "Element",
                "required": True,
            },
        )
        bundesland: Optional[EinheitKernkraftBundesland] = field(
            default=None,
            metadata={
                "name": "Bundesland",
                "type": "Element",
            },
        )
        landkreis: Optional[str] = field(
            default=None,
            metadata={
                "name": "Landkreis",
                "type": "Element",
                "required": True,
            },
        )
        gemeinde: Optional[str] = field(
            default=None,
            metadata={
                "name": "Gemeinde",
                "type": "Element",
                "required": True,
            },
        )
        gemeindeschluessel: Optional[str] = field(
            default=None,
            metadata={
                "name": "Gemeindeschluessel",
                "type": "Element",
                "required": True,
            },
        )
        postleitzahl: Optional[str] = field(
            default=None,
            metadata={
                "name": "Postleitzahl",
                "type": "Element",
                "required": True,
            },
        )
        strasse: Optional[str] = field(
            default=None,
            metadata={
                "name": "Strasse",
                "type": "Element",
                "required": True,
            },
        )
        gemarkung: Optional[str] = field(
            default=None,
            metadata={
                "name": "Gemarkung",
                "type": "Element",
            },
        )
        flur_flurstuecknummern: Optional[str] = field(
            default=None,
            metadata={
                "name": "FlurFlurstuecknummern",
                "type": "Element",
            },
        )
        strasse_nicht_gefunden: Optional[
            EinheitKernkraftStrasseNichtGefunden
        ] = field(
            default=None,
            metadata={
                "name": "StrasseNichtGefunden",
                "type": "Element",
                "required": True,
            },
        )
        hausnummer: Optional[EinheitKernkraftHausnummer] = field(
            default=None,
            metadata={
                "name": "Hausnummer",
                "type": "Element",
            },
        )
        hausnummer_nv: Optional[EinheitKernkraftHausnummerNv] = field(
            default=None,
            metadata={
                "name": "Hausnummer_nv",
                "type": "Element",
                "required": True,
            },
        )
        hausnummer_nicht_gefunden: Optional[
            EinheitKernkraftHausnummerNichtGefunden
        ] = field(
            default=None,
            metadata={
                "name": "HausnummerNichtGefunden",
                "type": "Element",
                "required": True,
            },
        )
        ort: Optional[str] = field(
            default=None,
            metadata={
                "name": "Ort",
                "type": "Element",
                "required": True,
            },
        )
        laengengrad: Optional[float] = field(
            default=None,
            metadata={
                "name": "Laengengrad",
                "type": "Element",
                "required": True,
            },
        )
        breitengrad: Optional[float] = field(
            default=None,
            metadata={
                "name": "Breitengrad",
                "type": "Element",
                "required": True,
            },
        )
        registrierungsdatum: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "Registrierungsdatum",
                "type": "Element",
                "required": True,
            },
        )
        inbetriebnahmedatum: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "Inbetriebnahmedatum",
                "type": "Element",
                "required": True,
            },
        )
        datum_endgueltige_stilllegung: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "DatumEndgueltigeStilllegung",
                "type": "Element",
            },
        )
        datum_beginn_voruebergehende_stilllegung: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "DatumBeginnVoruebergehendeStilllegung",
                "type": "Element",
            },
        )
        datum_wiederaufnahme_betrieb: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "DatumWiederaufnahmeBetrieb",
                "type": "Element",
            },
        )
        geplantes_inbetriebnahmedatum: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "GeplantesInbetriebnahmedatum",
                "type": "Element",
            },
        )
        einheit_systemstatus: Optional[EinheitKernkraftEinheitSystemstatus] = (
            field(
                default=None,
                metadata={
                    "name": "EinheitSystemstatus",
                    "type": "Element",
                    "required": True,
                },
            )
        )
        einheit_betriebsstatus: Optional[
            EinheitKernkraftEinheitBetriebsstatus
        ] = field(
            default=None,
            metadata={
                "name": "EinheitBetriebsstatus",
                "type": "Element",
                "required": True,
            },
        )
        bestandsanlage_mastr_nummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "BestandsanlageMastrNummer",
                "type": "Element",
            },
        )
        nicht_vorhanden_in_migrierten_einheiten: Optional[
            EinheitKernkraftNichtVorhandenInMigriertenEinheiten
        ] = field(
            default=None,
            metadata={
                "name": "NichtVorhandenInMigriertenEinheiten",
                "type": "Element",
                "required": True,
            },
        )
        alt_anlagenbetreiber_mastr_nummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "AltAnlagenbetreiberMastrNummer",
                "type": "Element",
            },
        )
        datum_des_betreiberwechsels: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "DatumDesBetreiberwechsels",
                "type": "Element",
            },
        )
        datum_registrierung_des_betreiberwechsels: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "DatumRegistrierungDesBetreiberwechsels",
                "type": "Element",
            },
        )
        name_stromerzeugungseinheit: Optional[str] = field(
            default=None,
            metadata={
                "name": "NameStromerzeugungseinheit",
                "type": "Element",
                "required": True,
            },
        )
        weic: Optional[str] = field(
            default=None,
            metadata={
                "name": "Weic",
                "type": "Element",
            },
        )
        weic_nv: Optional[EinheitKernkraftWeicNv] = field(
            default=None,
            metadata={
                "name": "Weic_nv",
                "type": "Element",
                "required": True,
            },
        )
        weic_display_name: Optional[str] = field(
            default=None,
            metadata={
                "name": "WeicDisplayName",
                "type": "Element",
            },
        )
        kraftwerksnummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "Kraftwerksnummer",
                "type": "Element",
            },
        )
        kraftwerksnummer_nv: Optional[EinheitKernkraftKraftwerksnummerNv] = (
            field(
                default=None,
                metadata={
                    "name": "Kraftwerksnummer_nv",
                    "type": "Element",
                    "required": True,
                },
            )
        )
        energietraeger: Optional[EinheitKernkraftEnergietraeger] = field(
            default=None,
            metadata={
                "name": "Energietraeger",
                "type": "Element",
                "required": True,
            },
        )
        bruttoleistung: Optional[float] = field(
            default=None,
            metadata={
                "name": "Bruttoleistung",
                "type": "Element",
                "required": True,
            },
        )
        nettonennleistung: Optional[float] = field(
            default=None,
            metadata={
                "name": "Nettonennleistung",
                "type": "Element",
                "required": True,
            },
        )
        anschluss_an_hoechst_oder_hoch_spannung: Optional[
            EinheitKernkraftAnschlussAnHoechstOderHochSpannung
        ] = field(
            default=None,
            metadata={
                "name": "AnschlussAnHoechstOderHochSpannung",
                "type": "Element",
            },
        )
        einsatzverantwortlicher: Optional[str] = field(
            default=None,
            metadata={
                "name": "Einsatzverantwortlicher",
                "type": "Element",
            },
        )
        fernsteuerbarkeit_nb: Optional[EinheitKernkraftFernsteuerbarkeitNb] = (
            field(
                default=None,
                metadata={
                    "name": "FernsteuerbarkeitNb",
                    "type": "Element",
                },
            )
        )
        fernsteuerbarkeit_dv: Optional[EinheitKernkraftFernsteuerbarkeitDv] = (
            field(
                default=None,
                metadata={
                    "name": "FernsteuerbarkeitDv",
                    "type": "Element",
                },
            )
        )
        einspeisungsart: Optional[EinheitKernkraftEinspeisungsart] = field(
            default=None,
            metadata={
                "name": "Einspeisungsart",
                "type": "Element",
            },
        )
        gen_mastr_nummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "GenMastrNummer",
                "type": "Element",
            },
        )
        name_kraftwerk: Optional[str] = field(
            default=None,
            metadata={
                "name": "NameKraftwerk",
                "type": "Element",
                "required": True,
            },
        )
        name_kraftwerksblock: Optional[str] = field(
            default=None,
            metadata={
                "name": "NameKraftwerksblock",
                "type": "Element",
                "required": True,
            },
        )
        technologie: Optional[EinheitKernkraftTechnologie] = field(
            default=None,
            metadata={
                "name": "Technologie",
                "type": "Element",
            },
        )
