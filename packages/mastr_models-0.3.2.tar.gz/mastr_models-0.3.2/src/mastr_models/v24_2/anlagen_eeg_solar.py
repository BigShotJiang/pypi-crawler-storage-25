from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from xsdata.models.datatype import XmlDate, XmlDateTime


class AnlageEegSolarAnlageBetriebsstatus(Enum):
    VALUE_35 = 35
    VALUE_38 = 38
    VALUE_37 = 37
    VALUE_31 = 31


class AnlageEegSolarAnlagenkennzifferAnlagenregisterNv(Enum):
    VALUE_1 = 1
    VALUE_0 = 0


class AnlageEegSolarAusschreibungZuschlag(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class AnlageEegSolarInanspruchnahmeZahlungNachEeg(Enum):
    VALUE_1 = 1
    VALUE_0 = 0


class AnlageEegSolarMieterstromZugeordnet(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class AnlageEegSolarRegistrierungsnummerPvMeldeportalNv(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


@dataclass
class AnlagenEegSolar:
    anlage_eeg_solar: list["AnlagenEegSolar.AnlageEegSolar"] = field(
        default_factory=list,
        metadata={
            "name": "AnlageEegSolar",
            "type": "Element",
        },
    )

    @dataclass
    class AnlageEegSolar:
        registrierungsdatum: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "Registrierungsdatum",
                "type": "Element",
                "required": True,
            },
        )
        datum_letzte_aktualisierung: Optional[XmlDateTime] = field(
            default=None,
            metadata={
                "name": "DatumLetzteAktualisierung",
                "type": "Element",
                "required": True,
            },
        )
        eeg_inbetriebnahmedatum: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "EegInbetriebnahmedatum",
                "type": "Element",
            },
        )
        eeg_ma_st_rnummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "EegMaStRNummer",
                "type": "Element",
                "required": True,
            },
        )
        inanspruchnahme_zahlung_nach_eeg: Optional[
            AnlageEegSolarInanspruchnahmeZahlungNachEeg
        ] = field(
            default=None,
            metadata={
                "name": "InanspruchnahmeZahlungNachEeg",
                "type": "Element",
            },
        )
        anlagenschluessel_eeg: Optional[str] = field(
            default=None,
            metadata={
                "name": "AnlagenschluesselEeg",
                "type": "Element",
            },
        )
        anlagenkennziffer_anlagenregister: Optional[str] = field(
            default=None,
            metadata={
                "name": "AnlagenkennzifferAnlagenregister",
                "type": "Element",
            },
        )
        anlagenkennziffer_anlagenregister_nv: Optional[
            AnlageEegSolarAnlagenkennzifferAnlagenregisterNv
        ] = field(
            default=None,
            metadata={
                "name": "AnlagenkennzifferAnlagenregister_nv",
                "type": "Element",
                "required": True,
            },
        )
        installierte_leistung: Optional[float] = field(
            default=None,
            metadata={
                "name": "InstallierteLeistung",
                "type": "Element",
                "required": True,
            },
        )
        registrierungsnummer_pv_meldeportal: Optional[str] = field(
            default=None,
            metadata={
                "name": "RegistrierungsnummerPvMeldeportal",
                "type": "Element",
            },
        )
        registrierungsnummer_pv_meldeportal_nv: Optional[
            AnlageEegSolarRegistrierungsnummerPvMeldeportalNv
        ] = field(
            default=None,
            metadata={
                "name": "RegistrierungsnummerPvMeldeportal_nv",
                "type": "Element",
                "required": True,
            },
        )
        mieterstrom_zugeordnet: Optional[
            AnlageEegSolarMieterstromZugeordnet
        ] = field(
            default=None,
            metadata={
                "name": "MieterstromZugeordnet",
                "type": "Element",
            },
        )
        mieterstrom_meldedatum: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "MieterstromMeldedatum",
                "type": "Element",
            },
        )
        mieterstrom_erste_zuordnung_zuschlag: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "MieterstromErsteZuordnungZuschlag",
                "type": "Element",
            },
        )
        ausschreibung_zuschlag: Optional[
            AnlageEegSolarAusschreibungZuschlag
        ] = field(
            default=None,
            metadata={
                "name": "AusschreibungZuschlag",
                "type": "Element",
            },
        )
        zugeordnete_gebotsmenge: Optional[float] = field(
            default=None,
            metadata={
                "name": "ZugeordneteGebotsmenge",
                "type": "Element",
            },
        )
        zuschlagsnummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "Zuschlagsnummer",
                "type": "Element",
            },
        )
        anlage_betriebsstatus: Optional[AnlageEegSolarAnlageBetriebsstatus] = (
            field(
                default=None,
                metadata={
                    "name": "AnlageBetriebsstatus",
                    "type": "Element",
                    "required": True,
                },
            )
        )
        verknuepfte_einheiten_ma_st_rnummern: Optional[str] = field(
            default=None,
            metadata={
                "name": "VerknuepfteEinheitenMaStRNummern",
                "type": "Element",
                "required": True,
            },
        )
