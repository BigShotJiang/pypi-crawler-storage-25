from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from xsdata.models.datatype import XmlDate, XmlDateTime


class AnlageEegBiomasseAnlageBetriebsstatus(Enum):
    VALUE_35 = 35
    VALUE_38 = 38
    VALUE_37 = 37
    VALUE_31 = 31


class AnlageEegBiomasseAnlagenkennzifferAnlagenregisterNv(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class AnlageEegBiomasseAusschliesslicheVerwendungBiomasse(Enum):
    VALUE_1 = 1
    VALUE_0 = 0


class AnlageEegBiomasseAusschreibungZuschlag(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class AnlageEegBiomasseBiogasGaserzeugungskapazitaetNv(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class AnlageEegBiomasseBiogasInanspruchnahmeFlexiPraemie(Enum):
    VALUE_1 = 1
    VALUE_0 = 0


class AnlageEegBiomasseBiogasLeistungserhoehung(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class AnlageEegBiomasseBiomethanErstmaligerEinsatzNv(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


@dataclass
class AnlagenEegBiomasse:
    anlage_eeg_biomasse: list["AnlagenEegBiomasse.AnlageEegBiomasse"] = field(
        default_factory=list,
        metadata={
            "name": "AnlageEegBiomasse",
            "type": "Element",
        },
    )

    @dataclass
    class AnlageEegBiomasse:
        registrierungsdatum: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "Registrierungsdatum",
                "type": "Element",
            },
        )
        datum_letzte_aktualisierung: Optional[XmlDateTime] = field(
            default=None,
            metadata={
                "name": "DatumLetzteAktualisierung",
                "type": "Element",
                "required": True,
            },
        )
        eeg_inbetriebnahmedatum: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "EegInbetriebnahmedatum",
                "type": "Element",
                "required": True,
            },
        )
        eeg_ma_st_rnummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "EegMaStRNummer",
                "type": "Element",
                "required": True,
            },
        )
        anlagenschluessel_eeg: Optional[str] = field(
            default=None,
            metadata={
                "name": "AnlagenschluesselEeg",
                "type": "Element",
            },
        )
        anlagenkennziffer_anlagenregister: Optional[str] = field(
            default=None,
            metadata={
                "name": "AnlagenkennzifferAnlagenregister",
                "type": "Element",
            },
        )
        anlagenkennziffer_anlagenregister_nv: Optional[
            AnlageEegBiomasseAnlagenkennzifferAnlagenregisterNv
        ] = field(
            default=None,
            metadata={
                "name": "AnlagenkennzifferAnlagenregister_nv",
                "type": "Element",
                "required": True,
            },
        )
        installierte_leistung: Optional[float] = field(
            default=None,
            metadata={
                "name": "InstallierteLeistung",
                "type": "Element",
                "required": True,
            },
        )
        ausschliessliche_verwendung_biomasse: Optional[
            AnlageEegBiomasseAusschliesslicheVerwendungBiomasse
        ] = field(
            default=None,
            metadata={
                "name": "AusschliesslicheVerwendungBiomasse",
                "type": "Element",
            },
        )
        ausschreibung_zuschlag: Optional[
            AnlageEegBiomasseAusschreibungZuschlag
        ] = field(
            default=None,
            metadata={
                "name": "AusschreibungZuschlag",
                "type": "Element",
            },
        )
        zuschlagsnummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "Zuschlagsnummer",
                "type": "Element",
            },
        )
        biogas_inanspruchnahme_flexi_praemie: Optional[
            AnlageEegBiomasseBiogasInanspruchnahmeFlexiPraemie
        ] = field(
            default=None,
            metadata={
                "name": "BiogasInanspruchnahmeFlexiPraemie",
                "type": "Element",
            },
        )
        biogas_datum_inanspruchnahme_flexi_praemie: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "BiogasDatumInanspruchnahmeFlexiPraemie",
                "type": "Element",
            },
        )
        biogas_leistungserhoehung: Optional[
            AnlageEegBiomasseBiogasLeistungserhoehung
        ] = field(
            default=None,
            metadata={
                "name": "BiogasLeistungserhoehung",
                "type": "Element",
            },
        )
        biogas_datum_leistungserhoehung: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "BiogasDatumLeistungserhoehung",
                "type": "Element",
            },
        )
        biogas_umfang_leistungserhoehung: Optional[float] = field(
            default=None,
            metadata={
                "name": "BiogasUmfangLeistungserhoehung",
                "type": "Element",
            },
        )
        biogas_gaserzeugungskapazitaet: Optional[float] = field(
            default=None,
            metadata={
                "name": "BiogasGaserzeugungskapazitaet",
                "type": "Element",
            },
        )
        biogas_gaserzeugungskapazitaet_nv: Optional[
            AnlageEegBiomasseBiogasGaserzeugungskapazitaetNv
        ] = field(
            default=None,
            metadata={
                "name": "BiogasGaserzeugungskapazitaet_nv",
                "type": "Element",
                "required": True,
            },
        )
        biogas_hoechstbemessungsleistung: Optional[float] = field(
            default=None,
            metadata={
                "name": "BiogasHoechstbemessungsleistung",
                "type": "Element",
            },
        )
        biomethan_erstmaliger_einsatz: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "BiomethanErstmaligerEinsatz",
                "type": "Element",
            },
        )
        biomethan_erstmaliger_einsatz_nv: Optional[
            AnlageEegBiomasseBiomethanErstmaligerEinsatzNv
        ] = field(
            default=None,
            metadata={
                "name": "BiomethanErstmaligerEinsatz_nv",
                "type": "Element",
                "required": True,
            },
        )
        anlage_betriebsstatus: Optional[
            AnlageEegBiomasseAnlageBetriebsstatus
        ] = field(
            default=None,
            metadata={
                "name": "AnlageBetriebsstatus",
                "type": "Element",
                "required": True,
            },
        )
        verknuepfte_einheiten_ma_st_rnummern: Optional[str] = field(
            default=None,
            metadata={
                "name": "VerknuepfteEinheitenMaStRNummern",
                "type": "Element",
                "required": True,
            },
        )
