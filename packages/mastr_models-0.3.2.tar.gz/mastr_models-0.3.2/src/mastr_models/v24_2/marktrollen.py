from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from xsdata.models.datatype import XmlDateTime


class MarktrolleBundesnetzagenturBetriebsnummerNv(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class MarktrolleMarktpartneridentifikationsnummerNv(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


@dataclass
class Marktrollen:
    marktrolle: list["Marktrollen.Marktrolle"] = field(
        default_factory=list,
        metadata={
            "name": "Marktrolle",
            "type": "Element",
        },
    )

    @dataclass
    class Marktrolle:
        marktakteur_mastr_nummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "MarktakteurMastrNummer",
                "type": "Element",
                "required": True,
            },
        )
        datum_letzte_aktualisierung: Optional[XmlDateTime] = field(
            default=None,
            metadata={
                "name": "DatumLetzteAktualisierung",
                "type": "Element",
            },
        )
        mastr_nummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "MastrNummer",
                "type": "Element",
                "required": True,
            },
        )
        marktrolle: Optional[str] = field(
            default=None,
            metadata={
                "name": "Marktrolle",
                "type": "Element",
                "required": True,
            },
        )
        bundesnetzagentur_betriebsnummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "BundesnetzagenturBetriebsnummer",
                "type": "Element",
            },
        )
        bundesnetzagentur_betriebsnummer_nv: Optional[
            MarktrolleBundesnetzagenturBetriebsnummerNv
        ] = field(
            default=None,
            metadata={
                "name": "BundesnetzagenturBetriebsnummer_nv",
                "type": "Element",
            },
        )
        marktpartneridentifikationsnummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "Marktpartneridentifikationsnummer",
                "type": "Element",
            },
        )
        marktpartneridentifikationsnummer_nv: Optional[
            MarktrolleMarktpartneridentifikationsnummerNv
        ] = field(
            default=None,
            metadata={
                "name": "Marktpartneridentifikationsnummer_nv",
                "type": "Element",
                "required": True,
            },
        )
        kontaktdaten_marktrolle: Optional[str] = field(
            default=None,
            metadata={
                "name": "KontaktdatenMarktrolle",
                "type": "Element",
            },
        )
