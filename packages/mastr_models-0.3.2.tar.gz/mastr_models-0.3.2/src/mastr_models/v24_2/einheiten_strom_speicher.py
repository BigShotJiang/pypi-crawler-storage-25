from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from xsdata.models.datatype import XmlDate, XmlDateTime


class EinheitStromSpeicherAcDcKoppelung(Enum):
    VALUE_694 = 694
    VALUE_693 = 693


class EinheitStromSpeicherAnschlussAnHoechstOderHochSpannung(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitStromSpeicherBatterietechnologie(Enum):
    VALUE_727 = 727
    VALUE_728 = 728
    VALUE_732 = 732
    VALUE_731 = 731
    VALUE_730 = 730
    VALUE_729 = 729


class EinheitStromSpeicherBestandteilGrenzkraftwerk(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitStromSpeicherBundesland(Enum):
    VALUE_1416 = 1416
    VALUE_1402 = 1402
    VALUE_1403 = 1403
    VALUE_1401 = 1401
    VALUE_1400 = 1400
    VALUE_1404 = 1404
    VALUE_1406 = 1406
    VALUE_1405 = 1405
    VALUE_1407 = 1407
    VALUE_1408 = 1408
    VALUE_1409 = 1409
    VALUE_1410 = 1410
    VALUE_1412 = 1412
    VALUE_1413 = 1413
    VALUE_1414 = 1414
    VALUE_1411 = 1411
    VALUE_1415 = 1415


class EinheitStromSpeicherEegAnlagentyp(Enum):
    VALUE_1 = 1
    VALUE_2 = 2
    VALUE_3 = 3
    VALUE_4 = 4
    VALUE_5 = 5
    VALUE_6 = 6
    VALUE_7 = 7
    VALUE_8 = 8
    VALUE_9 = 9
    VALUE_10 = 10
    VALUE_11 = 11
    VALUE_12 = 12


class EinheitStromSpeicherEinheitBetriebsstatus(Enum):
    VALUE_35 = 35
    VALUE_31 = 31
    VALUE_38 = 38
    VALUE_37 = 37


class EinheitStromSpeicherEinheitSystemstatus(Enum):
    VALUE_472 = 472
    VALUE_473 = 473
    VALUE_484 = 484
    VALUE_490 = 490
    VALUE_572 = 572


class EinheitStromSpeicherEinsatzort(Enum):
    VALUE_2399 = 2399
    VALUE_1531 = 1531
    VALUE_738 = 738
    VALUE_739 = 739
    VALUE_1532 = 1532
    VALUE_733 = 733
    VALUE_741 = 741
    VALUE_740 = 740
    VALUE_737 = 737
    VALUE_742 = 742
    VALUE_743 = 743
    VALUE_734 = 734
    VALUE_744 = 744
    VALUE_1533 = 1533
    VALUE_745 = 745
    VALUE_746 = 746
    VALUE_736 = 736
    VALUE_747 = 747
    VALUE_755 = 755
    VALUE_754 = 754
    VALUE_753 = 753
    VALUE_752 = 752
    VALUE_735 = 735
    VALUE_751 = 751
    VALUE_750 = 750
    VALUE_748 = 748
    VALUE_749 = 749
    VALUE_2400 = 2400


class EinheitStromSpeicherEinspeisungsart(Enum):
    VALUE_689 = 689
    VALUE_688 = 688


class EinheitStromSpeicherEnergietraeger(Enum):
    VALUE_2411 = 2411
    VALUE_2493 = 2493
    VALUE_2408 = 2408
    VALUE_2410 = 2410
    VALUE_2494 = 2494
    VALUE_2409 = 2409
    VALUE_2412 = 2412
    VALUE_2407 = 2407
    VALUE_2413 = 2413
    VALUE_2403 = 2403
    VALUE_2404 = 2404
    VALUE_2405 = 2405
    VALUE_2495 = 2495
    VALUE_2406 = 2406
    VALUE_2957 = 2957
    VALUE_2958 = 2958
    VALUE_2496 = 2496
    VALUE_2498 = 2498
    VALUE_2497 = 2497


class EinheitStromSpeicherFernsteuerbarkeitDv(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitStromSpeicherFernsteuerbarkeitNb(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitStromSpeicherHausnummerNichtGefunden(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitStromSpeicherHausnummerNv(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitStromSpeicherKraftwerksnummerNv(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitStromSpeicherLand(Enum):
    VALUE_84 = 84
    VALUE_90 = 90
    VALUE_198 = 198
    VALUE_66 = 66
    VALUE_169 = 169
    VALUE_106 = 106
    VALUE_231 = 231
    VALUE_206 = 206
    VALUE_215 = 215
    VALUE_269 = 269


class EinheitStromSpeicherNetzbetreiberpruefungStatus(Enum):
    VALUE_2954 = 2954
    VALUE_2955 = 2955
    VALUE_3075 = 3075


class EinheitStromSpeicherNichtVorhandenInMigriertenEinheiten(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitStromSpeicherNotstromaggregat(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitStromSpeicherPumpbetriebKontinuierlichRegelbar(Enum):
    VALUE_1 = 1
    VALUE_0 = 0


class EinheitStromSpeicherPumpspeichertechnologie(Enum):
    VALUE_2920 = 2920
    VALUE_2921 = 2921


class EinheitStromSpeicherReserveartNachDemEnWg(Enum):
    VALUE_3078 = 3078
    VALUE_3079 = 3079
    VALUE_3080 = 3080


class EinheitStromSpeicherStrasseNichtGefunden(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitStromSpeicherTechnologie(Enum):
    VALUE_524 = 524
    VALUE_784 = 784
    VALUE_1537 = 1537
    VALUE_526 = 526
    VALUE_525 = 525


class EinheitStromSpeicherWeicNv(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


@dataclass
class EinheitenStromSpeicher:
    einheit_strom_speicher: list[
        "EinheitenStromSpeicher.EinheitStromSpeicher"
    ] = field(
        default_factory=list,
        metadata={
            "name": "EinheitStromSpeicher",
            "type": "Element",
        },
    )

    @dataclass
    class EinheitStromSpeicher:
        einheit_mastr_nummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "EinheitMastrNummer",
                "type": "Element",
                "required": True,
            },
        )
        datum_letzte_aktualisierung: Optional[XmlDateTime] = field(
            default=None,
            metadata={
                "name": "DatumLetzteAktualisierung",
                "type": "Element",
                "required": True,
            },
        )
        lokation_ma_st_rnummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "LokationMaStRNummer",
                "type": "Element",
            },
        )
        netzbetreiberpruefung_status: Optional[
            EinheitStromSpeicherNetzbetreiberpruefungStatus
        ] = field(
            default=None,
            metadata={
                "name": "NetzbetreiberpruefungStatus",
                "type": "Element",
                "required": True,
            },
        )
        netzbetreiberpruefung_datum: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "NetzbetreiberpruefungDatum",
                "type": "Element",
            },
        )
        anlagenbetreiber_mastr_nummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "AnlagenbetreiberMastrNummer",
                "type": "Element",
            },
        )
        land: Optional[EinheitStromSpeicherLand] = field(
            default=None,
            metadata={
                "name": "Land",
                "type": "Element",
                "required": True,
            },
        )
        bundesland: Optional[EinheitStromSpeicherBundesland] = field(
            default=None,
            metadata={
                "name": "Bundesland",
                "type": "Element",
            },
        )
        landkreis: Optional[str] = field(
            default=None,
            metadata={
                "name": "Landkreis",
                "type": "Element",
            },
        )
        gemeinde: Optional[str] = field(
            default=None,
            metadata={
                "name": "Gemeinde",
                "type": "Element",
            },
        )
        gemeindeschluessel: Optional[str] = field(
            default=None,
            metadata={
                "name": "Gemeindeschluessel",
                "type": "Element",
            },
        )
        postleitzahl: Optional[str] = field(
            default=None,
            metadata={
                "name": "Postleitzahl",
                "type": "Element",
                "required": True,
            },
        )
        gemarkung: Optional[str] = field(
            default=None,
            metadata={
                "name": "Gemarkung",
                "type": "Element",
            },
        )
        flur_flurstuecknummern: Optional[str] = field(
            default=None,
            metadata={
                "name": "FlurFlurstuecknummern",
                "type": "Element",
            },
        )
        strasse: Optional[str] = field(
            default=None,
            metadata={
                "name": "Strasse",
                "type": "Element",
            },
        )
        strasse_nicht_gefunden: Optional[
            EinheitStromSpeicherStrasseNichtGefunden
        ] = field(
            default=None,
            metadata={
                "name": "StrasseNichtGefunden",
                "type": "Element",
            },
        )
        hausnummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "Hausnummer",
                "type": "Element",
            },
        )
        hausnummer_nv: Optional[EinheitStromSpeicherHausnummerNv] = field(
            default=None,
            metadata={
                "name": "Hausnummer_nv",
                "type": "Element",
            },
        )
        hausnummer_nicht_gefunden: Optional[
            EinheitStromSpeicherHausnummerNichtGefunden
        ] = field(
            default=None,
            metadata={
                "name": "HausnummerNichtGefunden",
                "type": "Element",
            },
        )
        adresszusatz: Optional[str] = field(
            default=None,
            metadata={
                "name": "Adresszusatz",
                "type": "Element",
            },
        )
        ort: Optional[str] = field(
            default=None,
            metadata={
                "name": "Ort",
                "type": "Element",
                "required": True,
            },
        )
        laengengrad: Optional[float] = field(
            default=None,
            metadata={
                "name": "Laengengrad",
                "type": "Element",
            },
        )
        breitengrad: Optional[float] = field(
            default=None,
            metadata={
                "name": "Breitengrad",
                "type": "Element",
            },
        )
        registrierungsdatum: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "Registrierungsdatum",
                "type": "Element",
                "required": True,
            },
        )
        inbetriebnahmedatum: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "Inbetriebnahmedatum",
                "type": "Element",
            },
        )
        geplantes_inbetriebnahmedatum: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "GeplantesInbetriebnahmedatum",
                "type": "Element",
            },
        )
        datum_endgueltige_stilllegung: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "DatumEndgueltigeStilllegung",
                "type": "Element",
            },
        )
        datum_beginn_voruebergehende_stilllegung: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "DatumBeginnVoruebergehendeStilllegung",
                "type": "Element",
            },
        )
        datum_wiederaufnahme_betrieb: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "DatumWiederaufnahmeBetrieb",
                "type": "Element",
            },
        )
        einheit_systemstatus: Optional[
            EinheitStromSpeicherEinheitSystemstatus
        ] = field(
            default=None,
            metadata={
                "name": "EinheitSystemstatus",
                "type": "Element",
                "required": True,
            },
        )
        einheit_betriebsstatus: Optional[
            EinheitStromSpeicherEinheitBetriebsstatus
        ] = field(
            default=None,
            metadata={
                "name": "EinheitBetriebsstatus",
                "type": "Element",
                "required": True,
            },
        )
        bestandsanlage_mastr_nummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "BestandsanlageMastrNummer",
                "type": "Element",
            },
        )
        nicht_vorhanden_in_migrierten_einheiten: Optional[
            EinheitStromSpeicherNichtVorhandenInMigriertenEinheiten
        ] = field(
            default=None,
            metadata={
                "name": "NichtVorhandenInMigriertenEinheiten",
                "type": "Element",
                "required": True,
            },
        )
        alt_anlagenbetreiber_mastr_nummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "AltAnlagenbetreiberMastrNummer",
                "type": "Element",
            },
        )
        datum_des_betreiberwechsels: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "DatumDesBetreiberwechsels",
                "type": "Element",
            },
        )
        datum_registrierung_des_betreiberwechsels: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "DatumRegistrierungDesBetreiberwechsels",
                "type": "Element",
            },
        )
        name_stromerzeugungseinheit: Optional[str] = field(
            default=None,
            metadata={
                "name": "NameStromerzeugungseinheit",
                "type": "Element",
                "required": True,
            },
        )
        weic: Optional[str] = field(
            default=None,
            metadata={
                "name": "Weic",
                "type": "Element",
            },
        )
        weic_nv: Optional[EinheitStromSpeicherWeicNv] = field(
            default=None,
            metadata={
                "name": "Weic_nv",
                "type": "Element",
                "required": True,
            },
        )
        weic_display_name: Optional[str] = field(
            default=None,
            metadata={
                "name": "WeicDisplayName",
                "type": "Element",
            },
        )
        kraftwerksnummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "Kraftwerksnummer",
                "type": "Element",
            },
        )
        kraftwerksnummer_nv: Optional[
            EinheitStromSpeicherKraftwerksnummerNv
        ] = field(
            default=None,
            metadata={
                "name": "Kraftwerksnummer_nv",
                "type": "Element",
                "required": True,
            },
        )
        energietraeger: Optional[EinheitStromSpeicherEnergietraeger] = field(
            default=None,
            metadata={
                "name": "Energietraeger",
                "type": "Element",
                "required": True,
            },
        )
        bruttoleistung: Optional[float] = field(
            default=None,
            metadata={
                "name": "Bruttoleistung",
                "type": "Element",
                "required": True,
            },
        )
        nettonennleistung: Optional[float] = field(
            default=None,
            metadata={
                "name": "Nettonennleistung",
                "type": "Element",
            },
        )
        anschluss_an_hoechst_oder_hoch_spannung: Optional[
            EinheitStromSpeicherAnschlussAnHoechstOderHochSpannung
        ] = field(
            default=None,
            metadata={
                "name": "AnschlussAnHoechstOderHochSpannung",
                "type": "Element",
            },
        )
        einsatzverantwortlicher: Optional[str] = field(
            default=None,
            metadata={
                "name": "Einsatzverantwortlicher",
                "type": "Element",
            },
        )
        fernsteuerbarkeit_nb: Optional[
            EinheitStromSpeicherFernsteuerbarkeitNb
        ] = field(
            default=None,
            metadata={
                "name": "FernsteuerbarkeitNb",
                "type": "Element",
            },
        )
        fernsteuerbarkeit_dv: Optional[
            EinheitStromSpeicherFernsteuerbarkeitDv
        ] = field(
            default=None,
            metadata={
                "name": "FernsteuerbarkeitDv",
                "type": "Element",
            },
        )
        einspeisungsart: Optional[EinheitStromSpeicherEinspeisungsart] = field(
            default=None,
            metadata={
                "name": "Einspeisungsart",
                "type": "Element",
            },
        )
        einsatzort: Optional[EinheitStromSpeicherEinsatzort] = field(
            default=None,
            metadata={
                "name": "Einsatzort",
                "type": "Element",
            },
        )
        gen_mastr_nummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "GenMastrNummer",
                "type": "Element",
            },
        )
        reserveart_nach_dem_en_wg: Optional[
            EinheitStromSpeicherReserveartNachDemEnWg
        ] = field(
            default=None,
            metadata={
                "name": "ReserveartNachDemEnWG",
                "type": "Element",
                "required": True,
            },
        )
        datum_ueberfuehrung_in_reserve: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "DatumUeberfuehrungInReserve",
                "type": "Element",
                "required": True,
            },
        )
        ac_dc_koppelung: Optional[EinheitStromSpeicherAcDcKoppelung] = field(
            default=None,
            metadata={
                "name": "AcDcKoppelung",
                "type": "Element",
            },
        )
        batterietechnologie: Optional[
            EinheitStromSpeicherBatterietechnologie
        ] = field(
            default=None,
            metadata={
                "name": "Batterietechnologie",
                "type": "Element",
            },
        )
        notstromaggregat: Optional[EinheitStromSpeicherNotstromaggregat] = (
            field(
                default=None,
                metadata={
                    "name": "Notstromaggregat",
                    "type": "Element",
                },
            )
        )
        pumpbetrieb_leistungsaufnahme: Optional[float] = field(
            default=None,
            metadata={
                "name": "PumpbetriebLeistungsaufnahme",
                "type": "Element",
            },
        )
        pumpbetrieb_kontinuierlich_regelbar: Optional[
            EinheitStromSpeicherPumpbetriebKontinuierlichRegelbar
        ] = field(
            default=None,
            metadata={
                "name": "PumpbetriebKontinuierlichRegelbar",
                "type": "Element",
            },
        )
        pumpspeichertechnologie: Optional[
            EinheitStromSpeicherPumpspeichertechnologie
        ] = field(
            default=None,
            metadata={
                "name": "Pumpspeichertechnologie",
                "type": "Element",
            },
        )
        bestandteil_grenzkraftwerk: Optional[
            EinheitStromSpeicherBestandteilGrenzkraftwerk
        ] = field(
            default=None,
            metadata={
                "name": "BestandteilGrenzkraftwerk",
                "type": "Element",
            },
        )
        nettonennleistung_deutschland: Optional[float] = field(
            default=None,
            metadata={
                "name": "NettonennleistungDeutschland",
                "type": "Element",
            },
        )
        zugeordnente_wirkleistung_wechselrichter: Optional[float] = field(
            default=None,
            metadata={
                "name": "ZugeordnenteWirkleistungWechselrichter",
                "type": "Element",
            },
        )
        spe_mastr_nummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "SpeMastrNummer",
                "type": "Element",
            },
        )
        eeg_ma_st_rnummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "EegMaStRNummer",
                "type": "Element",
            },
        )
        eeg_anlagentyp: Optional[EinheitStromSpeicherEegAnlagentyp] = field(
            default=None,
            metadata={
                "name": "EegAnlagentyp",
                "type": "Element",
                "required": True,
            },
        )
        technologie: Optional[EinheitStromSpeicherTechnologie] = field(
            default=None,
            metadata={
                "name": "Technologie",
                "type": "Element",
            },
        )
