from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from xsdata.models.datatype import XmlDate, XmlDateTime


class AnlageEegWasserAnlageBetriebsstatus(Enum):
    VALUE_35 = 35
    VALUE_38 = 38
    VALUE_31 = 31
    VALUE_37 = 37


class AnlageEegWasserAnlagenkennzifferAnlagenregisterNv(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


@dataclass
class AnlagenEegWasser:
    anlage_eeg_wasser: list["AnlagenEegWasser.AnlageEegWasser"] = field(
        default_factory=list,
        metadata={
            "name": "AnlageEegWasser",
            "type": "Element",
        },
    )

    @dataclass
    class AnlageEegWasser:
        registrierungsdatum: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "Registrierungsdatum",
                "type": "Element",
            },
        )
        datum_letzte_aktualisierung: Optional[XmlDateTime] = field(
            default=None,
            metadata={
                "name": "DatumLetzteAktualisierung",
                "type": "Element",
                "required": True,
            },
        )
        eeg_inbetriebnahmedatum: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "EegInbetriebnahmedatum",
                "type": "Element",
                "required": True,
            },
        )
        eeg_ma_st_rnummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "EegMaStRNummer",
                "type": "Element",
                "required": True,
            },
        )
        anlagenschluessel_eeg: Optional[str] = field(
            default=None,
            metadata={
                "name": "AnlagenschluesselEeg",
                "type": "Element",
            },
        )
        anlagenkennziffer_anlagenregister: Optional[str] = field(
            default=None,
            metadata={
                "name": "AnlagenkennzifferAnlagenregister",
                "type": "Element",
            },
        )
        anlagenkennziffer_anlagenregister_nv: Optional[
            AnlageEegWasserAnlagenkennzifferAnlagenregisterNv
        ] = field(
            default=None,
            metadata={
                "name": "AnlagenkennzifferAnlagenregister_nv",
                "type": "Element",
                "required": True,
            },
        )
        installierte_leistung: Optional[float] = field(
            default=None,
            metadata={
                "name": "InstallierteLeistung",
                "type": "Element",
                "required": True,
            },
        )
        anlage_betriebsstatus: Optional[
            AnlageEegWasserAnlageBetriebsstatus
        ] = field(
            default=None,
            metadata={
                "name": "AnlageBetriebsstatus",
                "type": "Element",
                "required": True,
            },
        )
        ertuechtigung_ids: Optional[str] = field(
            default=None,
            metadata={
                "name": "ErtuechtigungIds",
                "type": "Element",
            },
        )
        verknuepfte_einheiten_ma_st_rnummern: Optional[str] = field(
            default=None,
            metadata={
                "name": "VerknuepfteEinheitenMaStRNummern",
                "type": "Element",
                "required": True,
            },
        )
