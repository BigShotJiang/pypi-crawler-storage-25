from dataclasses import dataclass, field
from enum import Enum

from xsdata.models.datatype import XmlDate, XmlDateTime


class EinheitWasserAnschlussAnHoechstOderHochSpannung(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitWasserArtDerWasserkraftanlage(Enum):
    VALUE_890 = 890
    VALUE_894 = 894
    VALUE_895 = 895
    VALUE_891 = 891
    VALUE_896 = 896
    VALUE_897 = 897


class EinheitWasserArtDesZuflusses(Enum):
    VALUE_724 = 724
    VALUE_726 = 726
    VALUE_725 = 725


class EinheitWasserBestandteilGrenzkraftwerk(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitWasserBundesland(Enum):
    VALUE_1416 = 1416
    VALUE_1402 = 1402
    VALUE_1403 = 1403
    VALUE_1401 = 1401
    VALUE_1400 = 1400
    VALUE_1404 = 1404
    VALUE_1406 = 1406
    VALUE_1405 = 1405
    VALUE_1407 = 1407
    VALUE_1408 = 1408
    VALUE_1409 = 1409
    VALUE_1410 = 1410
    VALUE_1412 = 1412
    VALUE_1413 = 1413
    VALUE_1414 = 1414
    VALUE_1411 = 1411
    VALUE_1415 = 1415


class EinheitWasserEinheitBetriebsstatus(Enum):
    VALUE_35 = 35
    VALUE_31 = 31
    VALUE_38 = 38
    VALUE_37 = 37


class EinheitWasserEinheitSystemstatus(Enum):
    VALUE_472 = 472
    VALUE_473 = 473
    VALUE_484 = 484
    VALUE_490 = 490
    VALUE_572 = 572


class EinheitWasserEinspeisungsart(Enum):
    VALUE_689 = 689
    VALUE_688 = 688


class EinheitWasserEnergietraeger(Enum):
    VALUE_2411 = 2411
    VALUE_2493 = 2493
    VALUE_2408 = 2408
    VALUE_2410 = 2410
    VALUE_2494 = 2494
    VALUE_2409 = 2409
    VALUE_2412 = 2412
    VALUE_2407 = 2407
    VALUE_2413 = 2413
    VALUE_2403 = 2403
    VALUE_2404 = 2404
    VALUE_2405 = 2405
    VALUE_2495 = 2495
    VALUE_2406 = 2406
    VALUE_2957 = 2957
    VALUE_2958 = 2958
    VALUE_2496 = 2496
    VALUE_2498 = 2498
    VALUE_2497 = 2497


class EinheitWasserFernsteuerbarkeitDv(Enum):
    VALUE_1 = 1
    VALUE_0 = 0


class EinheitWasserFernsteuerbarkeitNb(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitWasserHausnummerNichtGefunden(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitWasserHausnummerNv(Enum):
    VALUE_1 = 1
    VALUE_0 = 0


class EinheitWasserKraftwerksnummerNv(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitWasserLand(Enum):
    VALUE_84 = 84
    VALUE_90 = 90
    VALUE_198 = 198
    VALUE_66 = 66
    VALUE_169 = 169
    VALUE_106 = 106
    VALUE_231 = 231
    VALUE_206 = 206
    VALUE_215 = 215
    VALUE_269 = 269


class EinheitWasserMinderungStromerzeugung(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitWasserNetzbetreiberpruefungStatus(Enum):
    VALUE_2954 = 2954
    VALUE_2955 = 2955
    VALUE_3075 = 3075


class EinheitWasserNichtVorhandenInMigriertenEinheiten(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitWasserReserveartNachDemEnWg(Enum):
    VALUE_3078 = 3078
    VALUE_3079 = 3079
    VALUE_3080 = 3080


class EinheitWasserStrasseNichtGefunden(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitWasserWeicNv(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


@dataclass
class EinheitenWasser:
    einheit_wasser: list["EinheitenWasser.EinheitWasser"] = field(
        default_factory=list,
        metadata={
            "name": "EinheitWasser",
            "type": "Element",
        },
    )

    @dataclass
    class EinheitWasser:
        einheit_mastr_nummer: list[str] = field(
            default_factory=list,
            metadata={
                "name": "EinheitMastrNummer",
                "type": "Element",
            },
        )
        datum_letzte_aktualisierung: list[XmlDateTime] = field(
            default_factory=list,
            metadata={
                "name": "DatumLetzteAktualisierung",
                "type": "Element",
            },
        )
        lokation_ma_st_rnummer: list[str] = field(
            default_factory=list,
            metadata={
                "name": "LokationMaStRNummer",
                "type": "Element",
            },
        )
        netzbetreiberpruefung_status: list[
            EinheitWasserNetzbetreiberpruefungStatus
        ] = field(
            default_factory=list,
            metadata={
                "name": "NetzbetreiberpruefungStatus",
                "type": "Element",
            },
        )
        netzbetreiberpruefung_datum: list[XmlDate] = field(
            default_factory=list,
            metadata={
                "name": "NetzbetreiberpruefungDatum",
                "type": "Element",
            },
        )
        anlagenbetreiber_mastr_nummer: list[str] = field(
            default_factory=list,
            metadata={
                "name": "AnlagenbetreiberMastrNummer",
                "type": "Element",
            },
        )
        land: list[EinheitWasserLand] = field(
            default_factory=list,
            metadata={
                "name": "Land",
                "type": "Element",
            },
        )
        bundesland: list[EinheitWasserBundesland] = field(
            default_factory=list,
            metadata={
                "name": "Bundesland",
                "type": "Element",
            },
        )
        landkreis: list[str] = field(
            default_factory=list,
            metadata={
                "name": "Landkreis",
                "type": "Element",
            },
        )
        gemeinde: list[str] = field(
            default_factory=list,
            metadata={
                "name": "Gemeinde",
                "type": "Element",
            },
        )
        gemeindeschluessel: list[str] = field(
            default_factory=list,
            metadata={
                "name": "Gemeindeschluessel",
                "type": "Element",
            },
        )
        postleitzahl: list[str] = field(
            default_factory=list,
            metadata={
                "name": "Postleitzahl",
                "type": "Element",
            },
        )
        strasse: list[str] = field(
            default_factory=list,
            metadata={
                "name": "Strasse",
                "type": "Element",
            },
        )
        gemarkung: list[str] = field(
            default_factory=list,
            metadata={
                "name": "Gemarkung",
                "type": "Element",
            },
        )
        flur_flurstuecknummern: list[str] = field(
            default_factory=list,
            metadata={
                "name": "FlurFlurstuecknummern",
                "type": "Element",
            },
        )
        strasse_nicht_gefunden: list[EinheitWasserStrasseNichtGefunden] = (
            field(
                default_factory=list,
                metadata={
                    "name": "StrasseNichtGefunden",
                    "type": "Element",
                },
            )
        )
        hausnummer: list[str] = field(
            default_factory=list,
            metadata={
                "name": "Hausnummer",
                "type": "Element",
            },
        )
        hausnummer_nv: list[EinheitWasserHausnummerNv] = field(
            default_factory=list,
            metadata={
                "name": "Hausnummer_nv",
                "type": "Element",
            },
        )
        hausnummer_nicht_gefunden: list[
            EinheitWasserHausnummerNichtGefunden
        ] = field(
            default_factory=list,
            metadata={
                "name": "HausnummerNichtGefunden",
                "type": "Element",
            },
        )
        adresszusatz: list[str] = field(
            default_factory=list,
            metadata={
                "name": "Adresszusatz",
                "type": "Element",
            },
        )
        ort: list[str] = field(
            default_factory=list,
            metadata={
                "name": "Ort",
                "type": "Element",
            },
        )
        laengengrad: list[float] = field(
            default_factory=list,
            metadata={
                "name": "Laengengrad",
                "type": "Element",
            },
        )
        breitengrad: list[float] = field(
            default_factory=list,
            metadata={
                "name": "Breitengrad",
                "type": "Element",
            },
        )
        registrierungsdatum: list[XmlDate] = field(
            default_factory=list,
            metadata={
                "name": "Registrierungsdatum",
                "type": "Element",
            },
        )
        inbetriebnahmedatum: list[XmlDate] = field(
            default_factory=list,
            metadata={
                "name": "Inbetriebnahmedatum",
                "type": "Element",
            },
        )
        geplantes_inbetriebnahmedatum: list[XmlDate] = field(
            default_factory=list,
            metadata={
                "name": "GeplantesInbetriebnahmedatum",
                "type": "Element",
            },
        )
        datum_endgueltige_stilllegung: list[XmlDate] = field(
            default_factory=list,
            metadata={
                "name": "DatumEndgueltigeStilllegung",
                "type": "Element",
            },
        )
        datum_beginn_voruebergehende_stilllegung: list[XmlDate] = field(
            default_factory=list,
            metadata={
                "name": "DatumBeginnVoruebergehendeStilllegung",
                "type": "Element",
            },
        )
        datum_wiederaufnahme_betrieb: list[XmlDate] = field(
            default_factory=list,
            metadata={
                "name": "DatumWiederaufnahmeBetrieb",
                "type": "Element",
            },
        )
        einheit_systemstatus: list[EinheitWasserEinheitSystemstatus] = field(
            default_factory=list,
            metadata={
                "name": "EinheitSystemstatus",
                "type": "Element",
            },
        )
        einheit_betriebsstatus: list[EinheitWasserEinheitBetriebsstatus] = (
            field(
                default_factory=list,
                metadata={
                    "name": "EinheitBetriebsstatus",
                    "type": "Element",
                },
            )
        )
        bestandsanlage_mastr_nummer: list[str] = field(
            default_factory=list,
            metadata={
                "name": "BestandsanlageMastrNummer",
                "type": "Element",
            },
        )
        nicht_vorhanden_in_migrierten_einheiten: list[
            EinheitWasserNichtVorhandenInMigriertenEinheiten
        ] = field(
            default_factory=list,
            metadata={
                "name": "NichtVorhandenInMigriertenEinheiten",
                "type": "Element",
            },
        )
        alt_anlagenbetreiber_mastr_nummer: list[str] = field(
            default_factory=list,
            metadata={
                "name": "AltAnlagenbetreiberMastrNummer",
                "type": "Element",
            },
        )
        datum_des_betreiberwechsels: list[XmlDate] = field(
            default_factory=list,
            metadata={
                "name": "DatumDesBetreiberwechsels",
                "type": "Element",
            },
        )
        datum_registrierung_des_betreiberwechsels: list[XmlDate] = field(
            default_factory=list,
            metadata={
                "name": "DatumRegistrierungDesBetreiberwechsels",
                "type": "Element",
            },
        )
        name_stromerzeugungseinheit: list[str] = field(
            default_factory=list,
            metadata={
                "name": "NameStromerzeugungseinheit",
                "type": "Element",
            },
        )
        weic: list[str] = field(
            default_factory=list,
            metadata={
                "name": "Weic",
                "type": "Element",
            },
        )
        weic_nv: list[EinheitWasserWeicNv] = field(
            default_factory=list,
            metadata={
                "name": "Weic_nv",
                "type": "Element",
            },
        )
        weic_display_name: list[str] = field(
            default_factory=list,
            metadata={
                "name": "WeicDisplayName",
                "type": "Element",
            },
        )
        kraftwerksnummer: list[str] = field(
            default_factory=list,
            metadata={
                "name": "Kraftwerksnummer",
                "type": "Element",
            },
        )
        kraftwerksnummer_nv: list[EinheitWasserKraftwerksnummerNv] = field(
            default_factory=list,
            metadata={
                "name": "Kraftwerksnummer_nv",
                "type": "Element",
            },
        )
        energietraeger: list[EinheitWasserEnergietraeger] = field(
            default_factory=list,
            metadata={
                "name": "Energietraeger",
                "type": "Element",
            },
        )
        bruttoleistung: list[float] = field(
            default_factory=list,
            metadata={
                "name": "Bruttoleistung",
                "type": "Element",
            },
        )
        nettonennleistung: list[float] = field(
            default_factory=list,
            metadata={
                "name": "Nettonennleistung",
                "type": "Element",
            },
        )
        anschluss_an_hoechst_oder_hoch_spannung: list[
            EinheitWasserAnschlussAnHoechstOderHochSpannung
        ] = field(
            default_factory=list,
            metadata={
                "name": "AnschlussAnHoechstOderHochSpannung",
                "type": "Element",
            },
        )
        einsatzverantwortlicher: list[str] = field(
            default_factory=list,
            metadata={
                "name": "Einsatzverantwortlicher",
                "type": "Element",
            },
        )
        fernsteuerbarkeit_nb: list[EinheitWasserFernsteuerbarkeitNb] = field(
            default_factory=list,
            metadata={
                "name": "FernsteuerbarkeitNb",
                "type": "Element",
            },
        )
        fernsteuerbarkeit_dv: list[EinheitWasserFernsteuerbarkeitDv] = field(
            default_factory=list,
            metadata={
                "name": "FernsteuerbarkeitDv",
                "type": "Element",
            },
        )
        einspeisungsart: list[EinheitWasserEinspeisungsart] = field(
            default_factory=list,
            metadata={
                "name": "Einspeisungsart",
                "type": "Element",
            },
        )
        gen_mastr_nummer: list[str] = field(
            default_factory=list,
            metadata={
                "name": "GenMastrNummer",
                "type": "Element",
            },
        )
        reserveart_nach_dem_en_wg: list[EinheitWasserReserveartNachDemEnWg] = (
            field(
                default_factory=list,
                metadata={
                    "name": "ReserveartNachDemEnWG",
                    "type": "Element",
                },
            )
        )
        datum_ueberfuehrung_in_reserve: list[XmlDate] = field(
            default_factory=list,
            metadata={
                "name": "DatumUeberfuehrungInReserve",
                "type": "Element",
            },
        )
        name_kraftwerk: list[str] = field(
            default_factory=list,
            metadata={
                "name": "NameKraftwerk",
                "type": "Element",
            },
        )
        art_der_wasserkraftanlage: list[
            EinheitWasserArtDerWasserkraftanlage
        ] = field(
            default_factory=list,
            metadata={
                "name": "ArtDerWasserkraftanlage",
                "type": "Element",
            },
        )
        minderung_stromerzeugung: list[
            EinheitWasserMinderungStromerzeugung
        ] = field(
            default_factory=list,
            metadata={
                "name": "MinderungStromerzeugung",
                "type": "Element",
            },
        )
        bestandteil_grenzkraftwerk: list[
            EinheitWasserBestandteilGrenzkraftwerk
        ] = field(
            default_factory=list,
            metadata={
                "name": "BestandteilGrenzkraftwerk",
                "type": "Element",
            },
        )
        nettonennleistung_deutschland: list[float] = field(
            default_factory=list,
            metadata={
                "name": "NettonennleistungDeutschland",
                "type": "Element",
            },
        )
        art_des_zuflusses: list[EinheitWasserArtDesZuflusses] = field(
            default_factory=list,
            metadata={
                "name": "ArtDesZuflusses",
                "type": "Element",
            },
        )
        eeg_ma_st_rnummer: list[str] = field(
            default_factory=list,
            metadata={
                "name": "EegMaStRNummer",
                "type": "Element",
            },
        )
