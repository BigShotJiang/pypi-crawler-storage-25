from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from xsdata.models.datatype import XmlDateTime


class EinheitenAenderungNetzbetreiberzuordnungArtDerAenderung(Enum):
    VALUE_3085 = 3085
    VALUE_3086 = 3086


@dataclass
class EinheitenAenderungNetzbetreiberzuordnungen:
    einheiten_aenderung_netzbetreiberzuordnung: list[
        "EinheitenAenderungNetzbetreiberzuordnungen.EinheitenAenderungNetzbetreiberzuordnung"
    ] = field(
        default_factory=list,
        metadata={
            "name": "EinheitenAenderungNetzbetreiberzuordnung",
            "type": "Element",
        },
    )

    @dataclass
    class EinheitenAenderungNetzbetreiberzuordnung:
        einheit_mastr_nummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "EinheitMastrNummer",
                "type": "Element",
                "required": True,
            },
        )
        lokation_mastr_nummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "LokationMastrNummer",
                "type": "Element",
            },
        )
        netzanschlusspunkt_mastr_nummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "NetzanschlusspunktMastrNummer",
                "type": "Element",
            },
        )
        netzbetreiber_mastr_nummer_alt: Optional[str] = field(
            default=None,
            metadata={
                "name": "NetzbetreiberMastrNummerAlt",
                "type": "Element",
            },
        )
        netzbetreiber_mastr_nummer_neu: Optional[str] = field(
            default=None,
            metadata={
                "name": "NetzbetreiberMastrNummerNeu",
                "type": "Element",
                "required": True,
            },
        )
        art_der_aenderung: Optional[
            EinheitenAenderungNetzbetreiberzuordnungArtDerAenderung
        ] = field(
            default=None,
            metadata={
                "name": "ArtDerAenderung",
                "type": "Element",
            },
        )
        registrierungsdatum_netzbetreiberzuordnungsaenderung: Optional[
            XmlDateTime
        ] = field(
            default=None,
            metadata={
                "name": "RegistrierungsdatumNetzbetreiberzuordnungsaenderung",
                "type": "Element",
            },
        )
        netzbetreiberzuordnungsaenderungsdatum: Optional[XmlDateTime] = field(
            default=None,
            metadata={
                "name": "Netzbetreiberzuordnungsaenderungsdatum",
                "type": "Element",
            },
        )
