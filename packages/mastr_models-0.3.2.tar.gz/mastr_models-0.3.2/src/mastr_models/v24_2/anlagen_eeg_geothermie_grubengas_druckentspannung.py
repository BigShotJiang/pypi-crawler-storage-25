from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from xsdata.models.datatype import XmlDate, XmlDateTime


class AnlageEegGeothermieGrubengasDruckentspannungAnlageBetriebsstatus(Enum):
    VALUE_35 = 35
    VALUE_38 = 38
    VALUE_37 = 37
    VALUE_31 = 31


class AnlageEegGeothermieGrubengasDruckentspannungAnlagenkennzifferAnlagenregisterNv(
    Enum
):
    VALUE_0 = 0
    VALUE_1 = 1


@dataclass
class AnlagenEegGeothermieGrubengasDruckentspannung:
    anlage_eeg_geothermie_grubengas_druckentspannung: list[
        "AnlagenEegGeothermieGrubengasDruckentspannung.AnlageEegGeothermieGrubengasDruckentspannung"
    ] = field(
        default_factory=list,
        metadata={
            "name": "AnlageEegGeothermieGrubengasDruckentspannung",
            "type": "Element",
        },
    )

    @dataclass
    class AnlageEegGeothermieGrubengasDruckentspannung:
        registrierungsdatum: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "Registrierungsdatum",
                "type": "Element",
                "required": True,
            },
        )
        datum_letzte_aktualisierung: Optional[XmlDateTime] = field(
            default=None,
            metadata={
                "name": "DatumLetzteAktualisierung",
                "type": "Element",
                "required": True,
            },
        )
        eeg_inbetriebnahmedatum: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "EegInbetriebnahmedatum",
                "type": "Element",
                "required": True,
            },
        )
        eeg_ma_st_rnummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "EegMaStRNummer",
                "type": "Element",
                "required": True,
            },
        )
        anlagenschluessel_eeg: Optional[str] = field(
            default=None,
            metadata={
                "name": "AnlagenschluesselEeg",
                "type": "Element",
            },
        )
        anlagenkennziffer_anlagenregister: Optional[str] = field(
            default=None,
            metadata={
                "name": "AnlagenkennzifferAnlagenregister",
                "type": "Element",
            },
        )
        anlagenkennziffer_anlagenregister_nv: Optional[
            AnlageEegGeothermieGrubengasDruckentspannungAnlagenkennzifferAnlagenregisterNv
        ] = field(
            default=None,
            metadata={
                "name": "AnlagenkennzifferAnlagenregister_nv",
                "type": "Element",
                "required": True,
            },
        )
        installierte_leistung: Optional[float] = field(
            default=None,
            metadata={
                "name": "InstallierteLeistung",
                "type": "Element",
                "required": True,
            },
        )
        anlage_betriebsstatus: Optional[
            AnlageEegGeothermieGrubengasDruckentspannungAnlageBetriebsstatus
        ] = field(
            default=None,
            metadata={
                "name": "AnlageBetriebsstatus",
                "type": "Element",
                "required": True,
            },
        )
        verknuepfte_einheiten_ma_st_rnummern: Optional[str] = field(
            default=None,
            metadata={
                "name": "VerknuepfteEinheitenMaStRNummern",
                "type": "Element",
                "required": True,
            },
        )
