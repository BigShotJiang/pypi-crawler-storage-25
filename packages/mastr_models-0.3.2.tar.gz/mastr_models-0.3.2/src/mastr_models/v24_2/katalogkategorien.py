from dataclasses import dataclass, field
from typing import Optional


@dataclass
class Katalogkategorien:
    katalogkategorie: list["Katalogkategorien.Katalogkategorie"] = field(
        default_factory=list,
        metadata={
            "name": "Katalogkategorie",
            "type": "Element",
        },
    )

    @dataclass
    class Katalogkategorie:
        id: Optional[int] = field(
            default=None,
            metadata={
                "name": "Id",
                "type": "Element",
                "required": True,
            },
        )
        name: Optional[str] = field(
            default=None,
            metadata={
                "name": "Name",
                "type": "Element",
                "required": True,
            },
        )
