from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class GeloeschteUndDeaktivierteMarktakteureMarktakteurStatus(Enum):
    VALUE_488 = "488"
    VALUE_489 = "489"


@dataclass
class GeloeschteUndDeaktivierteMarktakteure:
    marktakteur_mastr_nummer: Optional[str] = field(
        default=None,
        metadata={
            "name": "MarktakteurMastrNummer",
            "type": "Element",
        },
    )
    marktakteur_status: Optional[
        GeloeschteUndDeaktivierteMarktakteureMarktakteurStatus
    ] = field(
        default=None,
        metadata={
            "name": "MarktakteurStatus",
            "type": "Element",
        },
    )
    datum_letzte_aktualisierung: Optional[str] = field(
        default=None,
        metadata={
            "name": "DatumLetzteAktualisierung",
            "type": "Element",
        },
    )
    geloeschte_und_deaktivierte_marktakteure: list[object] = field(
        default_factory=list,
        metadata={
            "name": "GeloeschteUndDeaktivierteMarktakteure",
            "type": "Element",
        },
    )
