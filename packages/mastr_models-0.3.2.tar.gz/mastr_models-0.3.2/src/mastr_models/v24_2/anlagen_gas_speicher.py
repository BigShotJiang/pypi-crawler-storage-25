from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from xsdata.models.datatype import XmlDate, XmlDateTime


class AnlageGasSpeicherAnlageBetriebsstatus(Enum):
    VALUE_35 = 35
    VALUE_38 = 38
    VALUE_37 = 37
    VALUE_31 = 31


@dataclass
class AnlagenGasSpeicher:
    anlage_gas_speicher: list["AnlagenGasSpeicher.AnlageGasSpeicher"] = field(
        default_factory=list,
        metadata={
            "name": "AnlageGasSpeicher",
            "type": "Element",
        },
    )

    @dataclass
    class AnlageGasSpeicher:
        ma_st_rnummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "MaStRNummer",
                "type": "Element",
                "required": True,
            },
        )
        datum_letzte_aktualisierung: Optional[XmlDateTime] = field(
            default=None,
            metadata={
                "name": "DatumLetzteAktualisierung",
                "type": "Element",
                "required": True,
            },
        )
        speichername: Optional[str] = field(
            default=None,
            metadata={
                "name": "Speichername",
                "type": "Element",
                "required": True,
            },
        )
        registrierungsdatum: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "Registrierungsdatum",
                "type": "Element",
                "required": True,
            },
        )
        anlage_betriebsstatus: Optional[
            AnlageGasSpeicherAnlageBetriebsstatus
        ] = field(
            default=None,
            metadata={
                "name": "AnlageBetriebsstatus",
                "type": "Element",
                "required": True,
            },
        )
        verknuepfte_einheiten_ma_st_rnummern: Optional[str] = field(
            default=None,
            metadata={
                "name": "VerknuepfteEinheitenMaStRNummern",
                "type": "Element",
                "required": True,
            },
        )
