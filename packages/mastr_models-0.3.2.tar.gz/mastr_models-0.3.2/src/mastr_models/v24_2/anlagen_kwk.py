from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from xsdata.models.datatype import XmlDate, XmlDateTime


class AnlageKwkAusschreibungZuschlag(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


@dataclass
class AnlagenKwk:
    anlage_kwk: list["AnlagenKwk.AnlageKwk"] = field(
        default_factory=list,
        metadata={
            "name": "AnlageKwk",
            "type": "Element",
        },
    )

    @dataclass
    class AnlageKwk:
        kwk_mastr_nummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "KwkMastrNummer",
                "type": "Element",
                "required": True,
            },
        )
        ausschreibung_zuschlag: Optional[AnlageKwkAusschreibungZuschlag] = (
            field(
                default=None,
                metadata={
                    "name": "AusschreibungZuschlag",
                    "type": "Element",
                },
            )
        )
        zuschlagnummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "Zuschlagnummer",
                "type": "Element",
            },
        )
        datum_letzte_aktualisierung: Optional[XmlDateTime] = field(
            default=None,
            metadata={
                "name": "DatumLetzteAktualisierung",
                "type": "Element",
            },
        )
        inbetriebnahmedatum: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "Inbetriebnahmedatum",
                "type": "Element",
            },
        )
        registrierungsdatum: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "Registrierungsdatum",
                "type": "Element",
            },
        )
        thermische_nutzleistung: Optional[float] = field(
            default=None,
            metadata={
                "name": "ThermischeNutzleistung",
                "type": "Element",
            },
        )
        elektrische_kwk_leistung: Optional[float] = field(
            default=None,
            metadata={
                "name": "ElektrischeKwkLeistung",
                "type": "Element",
            },
        )
