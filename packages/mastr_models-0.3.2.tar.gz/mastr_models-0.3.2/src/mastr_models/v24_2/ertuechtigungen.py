from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from xsdata.models.datatype import XmlDateTime


class ErtuechtigungErtuechtigungIstZulassungspflichtig(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


@dataclass
class Ertuechtigungen:
    ertuechtigung: list["Ertuechtigungen.Ertuechtigung"] = field(
        default_factory=list,
        metadata={
            "name": "Ertuechtigung",
            "type": "Element",
        },
    )

    @dataclass
    class Ertuechtigung:
        id: Optional[int] = field(
            default=None,
            metadata={
                "name": "Id",
                "type": "Element",
                "required": True,
            },
        )
        datum_letzte_aktualisierung: Optional[XmlDateTime] = field(
            default=None,
            metadata={
                "name": "DatumLetzteAktualisierung",
                "type": "Element",
                "required": True,
            },
        )
        eeg_mastr_nummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "EegMastrNummer",
                "type": "Element",
                "required": True,
            },
        )
        ertuechtigungsart: Optional[int] = field(
            default=None,
            metadata={
                "name": "Ertuechtigungsart",
                "type": "Element",
                "required": True,
            },
        )
        ertuechtigung_ist_zulassungspflichtig: Optional[
            ErtuechtigungErtuechtigungIstZulassungspflichtig
        ] = field(
            default=None,
            metadata={
                "name": "ErtuechtigungIstZulassungspflichtig",
                "type": "Element",
            },
        )
        leistungserhoehung: Optional[float] = field(
            default=None,
            metadata={
                "name": "Leistungserhoehung",
                "type": "Element",
            },
        )
        wiederinbetriebnahme_datum: Optional[XmlDateTime] = field(
            default=None,
            metadata={
                "name": "WiederinbetriebnahmeDatum",
                "type": "Element",
            },
        )
