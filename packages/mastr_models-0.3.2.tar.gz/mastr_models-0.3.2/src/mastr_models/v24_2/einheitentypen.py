from dataclasses import dataclass, field
from typing import Optional


@dataclass
class Einheitentypen:
    einheitentyp: list["Einheitentypen.Einheitentyp"] = field(
        default_factory=list,
        metadata={
            "name": "Einheitentyp",
            "type": "Element",
        },
    )

    @dataclass
    class Einheitentyp:
        id: Optional[int] = field(
            default=None,
            metadata={
                "name": "Id",
                "type": "Element",
                "required": True,
            },
        )
        wert: Optional[str] = field(
            default=None,
            metadata={
                "name": "Wert",
                "type": "Element",
                "required": True,
            },
        )
