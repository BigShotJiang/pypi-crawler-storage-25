from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from xsdata.models.datatype import XmlDateTime


class GeloeschteUndDeaktivierteEinheitEinheitBetriebsstatus(Enum):
    VALUE_35 = 35
    VALUE_31 = 31
    VALUE_38 = 38
    VALUE_37 = 37


class GeloeschteUndDeaktivierteEinheitEinheitSystemstatus(Enum):
    VALUE_473 = 473
    VALUE_572 = 572


class GeloeschteUndDeaktivierteEinheitEinheittyp(Enum):
    VALUE_1 = 1
    VALUE_6 = 6
    VALUE_8 = 8
    VALUE_9 = 9
    VALUE_3 = 3
    VALUE_2 = 2
    VALUE_5 = 5
    VALUE_11 = 11
    VALUE_10 = 10
    VALUE_4 = 4
    VALUE_12 = 12


@dataclass
class GeloeschteUndDeaktivierteEinheiten:
    geloeschte_und_deaktivierte_einheit: list[
        "GeloeschteUndDeaktivierteEinheiten.GeloeschteUndDeaktivierteEinheit"
    ] = field(
        default_factory=list,
        metadata={
            "name": "GeloeschteUndDeaktivierteEinheit",
            "type": "Element",
        },
    )

    @dataclass
    class GeloeschteUndDeaktivierteEinheit:
        datum_letzte_aktualisierung: Optional[XmlDateTime] = field(
            default=None,
            metadata={
                "name": "DatumLetzteAktualisierung",
                "type": "Element",
                "required": True,
            },
        )
        einheit_mastr_nummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "EinheitMastrNummer",
                "type": "Element",
                "required": True,
            },
        )
        einheittyp: Optional[GeloeschteUndDeaktivierteEinheitEinheittyp] = (
            field(
                default=None,
                metadata={
                    "name": "Einheittyp",
                    "type": "Element",
                    "required": True,
                },
            )
        )
        einheit_systemstatus: Optional[
            GeloeschteUndDeaktivierteEinheitEinheitSystemstatus
        ] = field(
            default=None,
            metadata={
                "name": "EinheitSystemstatus",
                "type": "Element",
                "required": True,
            },
        )
        einheit_betriebsstatus: Optional[
            GeloeschteUndDeaktivierteEinheitEinheitBetriebsstatus
        ] = field(
            default=None,
            metadata={
                "name": "EinheitBetriebsstatus",
                "type": "Element",
                "required": True,
            },
        )
