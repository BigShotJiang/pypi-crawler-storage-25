from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from xsdata.models.datatype import XmlDate, XmlDateTime


class EinheitWindAnschlussAnHoechstOderHochSpannung(Enum):
    VALUE_1 = 1
    VALUE_0 = 0


class EinheitWindAuflageAbschaltungLeistungsbegrenzung(Enum):
    VALUE_1 = 1
    VALUE_0 = 0


class EinheitWindAuflagenAbschaltungEiswurf(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitWindAuflagenAbschaltungSchallimmissionsschutzNachts(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitWindAuflagenAbschaltungSchallimmissionsschutzTagsueber(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitWindAuflagenAbschaltungSchattenwurf(Enum):
    VALUE_1 = 1
    VALUE_0 = 0


class EinheitWindAuflagenAbschaltungSonstige(Enum):
    VALUE_1 = 1
    VALUE_0 = 0


class EinheitWindAuflagenAbschaltungTierschutz(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitWindBuergerenergie(Enum):
    VALUE_1 = 1
    VALUE_0 = 0


class EinheitWindBundesland(Enum):
    VALUE_1416 = 1416
    VALUE_1402 = 1402
    VALUE_1403 = 1403
    VALUE_1401 = 1401
    VALUE_1400 = 1400
    VALUE_1404 = 1404
    VALUE_1406 = 1406
    VALUE_1405 = 1405
    VALUE_1407 = 1407
    VALUE_1408 = 1408
    VALUE_1409 = 1409
    VALUE_1410 = 1410
    VALUE_1412 = 1412
    VALUE_1413 = 1413
    VALUE_1414 = 1414
    VALUE_1411 = 1411
    VALUE_1415 = 1415


class EinheitWindClusterNordsee(Enum):
    VALUE_1546 = 1546
    VALUE_1547 = 1547
    VALUE_1548 = 1548
    VALUE_1549 = 1549
    VALUE_1550 = 1550
    VALUE_1551 = 1551
    VALUE_1552 = 1552
    VALUE_1553 = 1553
    VALUE_1554 = 1554
    VALUE_1555 = 1555
    VALUE_1556 = 1556
    VALUE_1557 = 1557
    VALUE_1558 = 1558
    VALUE_2963 = 2963


class EinheitWindClusterOstsee(Enum):
    VALUE_1540 = 1540
    VALUE_1541 = 1541
    VALUE_1542 = 1542
    VALUE_1543 = 1543
    VALUE_1544 = 1544
    VALUE_2970 = 2970
    VALUE_2962 = 2962


class EinheitWindEinheitBetriebsstatus(Enum):
    VALUE_35 = 35
    VALUE_37 = 37
    VALUE_31 = 31
    VALUE_38 = 38


class EinheitWindEinheitSystemstatus(Enum):
    VALUE_472 = 472
    VALUE_473 = 473
    VALUE_484 = 484
    VALUE_490 = 490
    VALUE_572 = 572


class EinheitWindEinspeisungsart(Enum):
    VALUE_688 = 688
    VALUE_689 = 689


class EinheitWindEnergietraeger(Enum):
    VALUE_2411 = 2411
    VALUE_2493 = 2493
    VALUE_2408 = 2408
    VALUE_2410 = 2410
    VALUE_2494 = 2494
    VALUE_2409 = 2409
    VALUE_2412 = 2412
    VALUE_2407 = 2407
    VALUE_2413 = 2413
    VALUE_2403 = 2403
    VALUE_2404 = 2404
    VALUE_2405 = 2405
    VALUE_2495 = 2495
    VALUE_2406 = 2406
    VALUE_2957 = 2957
    VALUE_2958 = 2958
    VALUE_2496 = 2496
    VALUE_2498 = 2498
    VALUE_2497 = 2497


class EinheitWindFernsteuerbarkeitDv(Enum):
    VALUE_1 = 1
    VALUE_0 = 0


class EinheitWindFernsteuerbarkeitNb(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitWindHausnummerNichtGefunden(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitWindHausnummerNv(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitWindKraftwerksnummerNv(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitWindLage(Enum):
    VALUE_888 = 888
    VALUE_889 = 889


class EinheitWindLand(Enum):
    VALUE_84 = 84
    VALUE_90 = 90
    VALUE_198 = 198
    VALUE_66 = 66
    VALUE_169 = 169
    VALUE_106 = 106
    VALUE_231 = 231
    VALUE_206 = 206
    VALUE_215 = 215
    VALUE_269 = 269


class EinheitWindNachtkennzeichnung(Enum):
    VALUE_1 = 1
    VALUE_0 = 0


class EinheitWindNetzbetreiberpruefungStatus(Enum):
    VALUE_2954 = 2954
    VALUE_2955 = 2955
    VALUE_3075 = 3075


class EinheitWindNichtVorhandenInMigriertenEinheiten(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitWindRotorblattenteisungssystem(Enum):
    VALUE_1 = 1
    VALUE_0 = 0


class EinheitWindSeelage(Enum):
    VALUE_640 = 640
    VALUE_639 = 639


class EinheitWindStrasseNichtGefunden(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitWindTechnologie(Enum):
    VALUE_691 = 691
    VALUE_692 = 692


class EinheitWindWeicNv(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


@dataclass
class EinheitenWind:
    einheit_wind: list["EinheitenWind.EinheitWind"] = field(
        default_factory=list,
        metadata={
            "name": "EinheitWind",
            "type": "Element",
        },
    )

    @dataclass
    class EinheitWind:
        einheit_mastr_nummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "EinheitMastrNummer",
                "type": "Element",
                "required": True,
            },
        )
        datum_letzte_aktualisierung: Optional[XmlDateTime] = field(
            default=None,
            metadata={
                "name": "DatumLetzteAktualisierung",
                "type": "Element",
                "required": True,
            },
        )
        lokation_ma_st_rnummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "LokationMaStRNummer",
                "type": "Element",
            },
        )
        netzbetreiberpruefung_status: Optional[
            EinheitWindNetzbetreiberpruefungStatus
        ] = field(
            default=None,
            metadata={
                "name": "NetzbetreiberpruefungStatus",
                "type": "Element",
                "required": True,
            },
        )
        netzbetreiberpruefung_datum: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "NetzbetreiberpruefungDatum",
                "type": "Element",
            },
        )
        anlagenbetreiber_mastr_nummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "AnlagenbetreiberMastrNummer",
                "type": "Element",
            },
        )
        land: Optional[EinheitWindLand] = field(
            default=None,
            metadata={
                "name": "Land",
                "type": "Element",
                "required": True,
            },
        )
        bundesland: Optional[EinheitWindBundesland] = field(
            default=None,
            metadata={
                "name": "Bundesland",
                "type": "Element",
            },
        )
        landkreis: Optional[str] = field(
            default=None,
            metadata={
                "name": "Landkreis",
                "type": "Element",
            },
        )
        gemeinde: Optional[str] = field(
            default=None,
            metadata={
                "name": "Gemeinde",
                "type": "Element",
            },
        )
        gemeindeschluessel: Optional[str] = field(
            default=None,
            metadata={
                "name": "Gemeindeschluessel",
                "type": "Element",
            },
        )
        postleitzahl: Optional[str] = field(
            default=None,
            metadata={
                "name": "Postleitzahl",
                "type": "Element",
            },
        )
        gemarkung: Optional[str] = field(
            default=None,
            metadata={
                "name": "Gemarkung",
                "type": "Element",
            },
        )
        flur_flurstuecknummern: Optional[str] = field(
            default=None,
            metadata={
                "name": "FlurFlurstuecknummern",
                "type": "Element",
            },
        )
        strasse: Optional[str] = field(
            default=None,
            metadata={
                "name": "Strasse",
                "type": "Element",
            },
        )
        strasse_nicht_gefunden: Optional[EinheitWindStrasseNichtGefunden] = (
            field(
                default=None,
                metadata={
                    "name": "StrasseNichtGefunden",
                    "type": "Element",
                },
            )
        )
        hausnummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "Hausnummer",
                "type": "Element",
            },
        )
        hausnummer_nv: Optional[EinheitWindHausnummerNv] = field(
            default=None,
            metadata={
                "name": "Hausnummer_nv",
                "type": "Element",
            },
        )
        hausnummer_nicht_gefunden: Optional[
            EinheitWindHausnummerNichtGefunden
        ] = field(
            default=None,
            metadata={
                "name": "HausnummerNichtGefunden",
                "type": "Element",
            },
        )
        adresszusatz: Optional[str] = field(
            default=None,
            metadata={
                "name": "Adresszusatz",
                "type": "Element",
            },
        )
        ort: Optional[str] = field(
            default=None,
            metadata={
                "name": "Ort",
                "type": "Element",
            },
        )
        laengengrad: Optional[float] = field(
            default=None,
            metadata={
                "name": "Laengengrad",
                "type": "Element",
            },
        )
        breitengrad: Optional[float] = field(
            default=None,
            metadata={
                "name": "Breitengrad",
                "type": "Element",
            },
        )
        registrierungsdatum: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "Registrierungsdatum",
                "type": "Element",
                "required": True,
            },
        )
        inbetriebnahmedatum: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "Inbetriebnahmedatum",
                "type": "Element",
            },
        )
        datum_endgueltige_stilllegung: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "DatumEndgueltigeStilllegung",
                "type": "Element",
            },
        )
        datum_beginn_voruebergehende_stilllegung: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "DatumBeginnVoruebergehendeStilllegung",
                "type": "Element",
            },
        )
        datum_wiederaufnahme_betrieb: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "DatumWiederaufnahmeBetrieb",
                "type": "Element",
            },
        )
        geplantes_inbetriebnahmedatum: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "GeplantesInbetriebnahmedatum",
                "type": "Element",
            },
        )
        einheit_systemstatus: Optional[EinheitWindEinheitSystemstatus] = field(
            default=None,
            metadata={
                "name": "EinheitSystemstatus",
                "type": "Element",
                "required": True,
            },
        )
        einheit_betriebsstatus: Optional[EinheitWindEinheitBetriebsstatus] = (
            field(
                default=None,
                metadata={
                    "name": "EinheitBetriebsstatus",
                    "type": "Element",
                    "required": True,
                },
            )
        )
        bestandsanlage_mastr_nummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "BestandsanlageMastrNummer",
                "type": "Element",
            },
        )
        nicht_vorhanden_in_migrierten_einheiten: Optional[
            EinheitWindNichtVorhandenInMigriertenEinheiten
        ] = field(
            default=None,
            metadata={
                "name": "NichtVorhandenInMigriertenEinheiten",
                "type": "Element",
                "required": True,
            },
        )
        alt_anlagenbetreiber_mastr_nummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "AltAnlagenbetreiberMastrNummer",
                "type": "Element",
            },
        )
        datum_des_betreiberwechsels: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "DatumDesBetreiberwechsels",
                "type": "Element",
            },
        )
        datum_registrierung_des_betreiberwechsels: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "DatumRegistrierungDesBetreiberwechsels",
                "type": "Element",
            },
        )
        name_stromerzeugungseinheit: Optional[str] = field(
            default=None,
            metadata={
                "name": "NameStromerzeugungseinheit",
                "type": "Element",
                "required": True,
            },
        )
        weic: Optional[str] = field(
            default=None,
            metadata={
                "name": "Weic",
                "type": "Element",
            },
        )
        weic_nv: Optional[EinheitWindWeicNv] = field(
            default=None,
            metadata={
                "name": "Weic_nv",
                "type": "Element",
                "required": True,
            },
        )
        weic_display_name: Optional[str] = field(
            default=None,
            metadata={
                "name": "WeicDisplayName",
                "type": "Element",
            },
        )
        kraftwerksnummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "Kraftwerksnummer",
                "type": "Element",
            },
        )
        kraftwerksnummer_nv: Optional[EinheitWindKraftwerksnummerNv] = field(
            default=None,
            metadata={
                "name": "Kraftwerksnummer_nv",
                "type": "Element",
                "required": True,
            },
        )
        energietraeger: Optional[EinheitWindEnergietraeger] = field(
            default=None,
            metadata={
                "name": "Energietraeger",
                "type": "Element",
                "required": True,
            },
        )
        bruttoleistung: Optional[float] = field(
            default=None,
            metadata={
                "name": "Bruttoleistung",
                "type": "Element",
                "required": True,
            },
        )
        nettonennleistung: Optional[float] = field(
            default=None,
            metadata={
                "name": "Nettonennleistung",
                "type": "Element",
                "required": True,
            },
        )
        anschluss_an_hoechst_oder_hoch_spannung: Optional[
            EinheitWindAnschlussAnHoechstOderHochSpannung
        ] = field(
            default=None,
            metadata={
                "name": "AnschlussAnHoechstOderHochSpannung",
                "type": "Element",
            },
        )
        einsatzverantwortlicher: Optional[str] = field(
            default=None,
            metadata={
                "name": "Einsatzverantwortlicher",
                "type": "Element",
            },
        )
        fernsteuerbarkeit_nb: Optional[EinheitWindFernsteuerbarkeitNb] = field(
            default=None,
            metadata={
                "name": "FernsteuerbarkeitNb",
                "type": "Element",
            },
        )
        fernsteuerbarkeit_dv: Optional[EinheitWindFernsteuerbarkeitDv] = field(
            default=None,
            metadata={
                "name": "FernsteuerbarkeitDv",
                "type": "Element",
            },
        )
        einspeisungsart: Optional[EinheitWindEinspeisungsart] = field(
            default=None,
            metadata={
                "name": "Einspeisungsart",
                "type": "Element",
            },
        )
        gen_mastr_nummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "GenMastrNummer",
                "type": "Element",
            },
        )
        name_windpark: Optional[str] = field(
            default=None,
            metadata={
                "name": "NameWindpark",
                "type": "Element",
            },
        )
        lage: Optional[EinheitWindLage] = field(
            default=None,
            metadata={
                "name": "Lage",
                "type": "Element",
                "required": True,
            },
        )
        seelage: Optional[EinheitWindSeelage] = field(
            default=None,
            metadata={
                "name": "Seelage",
                "type": "Element",
            },
        )
        cluster_nordsee: Optional[EinheitWindClusterNordsee] = field(
            default=None,
            metadata={
                "name": "ClusterNordsee",
                "type": "Element",
            },
        )
        cluster_ostsee: Optional[EinheitWindClusterOstsee] = field(
            default=None,
            metadata={
                "name": "ClusterOstsee",
                "type": "Element",
            },
        )
        hersteller: Optional[int] = field(
            default=None,
            metadata={
                "name": "Hersteller",
                "type": "Element",
            },
        )
        technologie: Optional[EinheitWindTechnologie] = field(
            default=None,
            metadata={
                "name": "Technologie",
                "type": "Element",
                "required": True,
            },
        )
        typenbezeichnung: Optional[str] = field(
            default=None,
            metadata={
                "name": "Typenbezeichnung",
                "type": "Element",
            },
        )
        nabenhoehe: Optional[float] = field(
            default=None,
            metadata={
                "name": "Nabenhoehe",
                "type": "Element",
            },
        )
        rotordurchmesser: Optional[float] = field(
            default=None,
            metadata={
                "name": "Rotordurchmesser",
                "type": "Element",
            },
        )
        rotorblattenteisungssystem: Optional[
            EinheitWindRotorblattenteisungssystem
        ] = field(
            default=None,
            metadata={
                "name": "Rotorblattenteisungssystem",
                "type": "Element",
            },
        )
        auflage_abschaltung_leistungsbegrenzung: Optional[
            EinheitWindAuflageAbschaltungLeistungsbegrenzung
        ] = field(
            default=None,
            metadata={
                "name": "AuflageAbschaltungLeistungsbegrenzung",
                "type": "Element",
            },
        )
        auflagen_abschaltung_schallimmissionsschutz_nachts: Optional[
            EinheitWindAuflagenAbschaltungSchallimmissionsschutzNachts
        ] = field(
            default=None,
            metadata={
                "name": "AuflagenAbschaltungSchallimmissionsschutzNachts",
                "type": "Element",
            },
        )
        auflagen_abschaltung_schallimmissionsschutz_tagsueber: Optional[
            EinheitWindAuflagenAbschaltungSchallimmissionsschutzTagsueber
        ] = field(
            default=None,
            metadata={
                "name": "AuflagenAbschaltungSchallimmissionsschutzTagsueber",
                "type": "Element",
            },
        )
        auflagen_abschaltung_schattenwurf: Optional[
            EinheitWindAuflagenAbschaltungSchattenwurf
        ] = field(
            default=None,
            metadata={
                "name": "AuflagenAbschaltungSchattenwurf",
                "type": "Element",
            },
        )
        auflagen_abschaltung_tierschutz: Optional[
            EinheitWindAuflagenAbschaltungTierschutz
        ] = field(
            default=None,
            metadata={
                "name": "AuflagenAbschaltungTierschutz",
                "type": "Element",
            },
        )
        auflagen_abschaltung_eiswurf: Optional[
            EinheitWindAuflagenAbschaltungEiswurf
        ] = field(
            default=None,
            metadata={
                "name": "AuflagenAbschaltungEiswurf",
                "type": "Element",
            },
        )
        auflagen_abschaltung_sonstige: Optional[
            EinheitWindAuflagenAbschaltungSonstige
        ] = field(
            default=None,
            metadata={
                "name": "AuflagenAbschaltungSonstige",
                "type": "Element",
            },
        )
        nachtkennzeichnung: Optional[EinheitWindNachtkennzeichnung] = field(
            default=None,
            metadata={
                "name": "Nachtkennzeichnung",
                "type": "Element",
            },
        )
        buergerenergie: Optional[EinheitWindBuergerenergie] = field(
            default=None,
            metadata={
                "name": "Buergerenergie",
                "type": "Element",
            },
        )
        wassertiefe: Optional[float] = field(
            default=None,
            metadata={
                "name": "Wassertiefe",
                "type": "Element",
            },
        )
        kuestenentfernung: Optional[float] = field(
            default=None,
            metadata={
                "name": "Kuestenentfernung",
                "type": "Element",
            },
        )
        eeg_ma_st_rnummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "EegMaStRNummer",
                "type": "Element",
            },
        )
