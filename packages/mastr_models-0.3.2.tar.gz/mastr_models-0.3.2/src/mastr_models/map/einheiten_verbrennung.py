from mastr_models.enum.einheiten_verbrennung import (
    Betriebsstatus as BetriebsstatusEnum,
)
from mastr_models.enum.einheiten_verbrennung import (
    FeedInType,
)
from mastr_models.enum.einheiten_verbrennung import (
    Hauptbrennstoff as HauptbrennstoffEnum,
)
from mastr_models.enum.einheiten_verbrennung import Technologie as TechnologieEnum
from mastr_models.v25_2.einheiten_verbrennung import (
    EinheitVerbrennungEinheitBetriebsstatus,
    EinheitVerbrennungEinspeisungsart,
    EinheitVerbrennungHauptbrennstoff,
    EinheitVerbrennungTechnologie,
)

TECHNOLOGIE_MAP = {
    EinheitVerbrennungTechnologie.VALUE_542: TechnologieEnum.Verbrennungsmotor,
    EinheitVerbrennungTechnologie.VALUE_543: TechnologieEnum.Brennstoffzelle,
    EinheitVerbrennungTechnologie.VALUE_544: TechnologieEnum.Stirlingmotor,
    EinheitVerbrennungTechnologie.VALUE_545: TechnologieEnum.Dampfmotor,
    EinheitVerbrennungTechnologie.VALUE_546: TechnologieEnum.ORC,
    EinheitVerbrennungTechnologie.VALUE_833: TechnologieEnum.Gegendruckmaschine_mit_Entnahme,
    EinheitVerbrennungTechnologie.VALUE_834: TechnologieEnum.Gegendruckmaschine_ohne_Entnahme,
    EinheitVerbrennungTechnologie.VALUE_835: TechnologieEnum.Gasturbinen_ohne_Abhitzekessel,
    EinheitVerbrennungTechnologie.VALUE_836: TechnologieEnum.Gasturbinen_mit_Abhitzekessel,
    EinheitVerbrennungTechnologie.VALUE_837: TechnologieEnum.Gasturbinen_mit_nachgeschalteter_Dampfturbine,
    EinheitVerbrennungTechnologie.VALUE_838: TechnologieEnum.Kondensationsmaschine_mit_Entnahme,
    EinheitVerbrennungTechnologie.VALUE_839: TechnologieEnum.Kondensationsmaschine_ohne_Entnahme,
    EinheitVerbrennungTechnologie.VALUE_840: TechnologieEnum.Sonstige,
    EinheitVerbrennungTechnologie.VALUE_1538: TechnologieEnum.Kalina,
}
HAUPTBRENNSTOFF_MAP = {
    EinheitVerbrennungHauptbrennstoff.VALUE_2456: HauptbrennstoffEnum.Kohlenwertstoffe_aus_Steinkohle,
    EinheitVerbrennungHauptbrennstoff.VALUE_2457: HauptbrennstoffEnum.Steinkohlen,
    EinheitVerbrennungHauptbrennstoff.VALUE_2458: HauptbrennstoffEnum.Steinkohlenbriketts,
    EinheitVerbrennungHauptbrennstoff.VALUE_2459: HauptbrennstoffEnum.Steinkohlenkoks,
    EinheitVerbrennungHauptbrennstoff.VALUE_2460: HauptbrennstoffEnum.Braunkohlenbriketts,
    EinheitVerbrennungHauptbrennstoff.VALUE_2461: HauptbrennstoffEnum.Braunkohlenkoks,
    EinheitVerbrennungHauptbrennstoff.VALUE_2462: HauptbrennstoffEnum.Hartbraunkohlen,
    EinheitVerbrennungHauptbrennstoff.VALUE_2463: HauptbrennstoffEnum.Rohbraunkohlen,
    EinheitVerbrennungHauptbrennstoff.VALUE_2464: HauptbrennstoffEnum.Staub_und_Trockenkohle,
    EinheitVerbrennungHauptbrennstoff.VALUE_2465: HauptbrennstoffEnum.Wirbelschichtkohle,
    EinheitVerbrennungHauptbrennstoff.VALUE_2466: HauptbrennstoffEnum.Dieselkraftstoff,
    EinheitVerbrennungHauptbrennstoff.VALUE_2467: HauptbrennstoffEnum.Heizöl_leicht,
    EinheitVerbrennungHauptbrennstoff.VALUE_2468: HauptbrennstoffEnum.Heizöl_schwer,
    EinheitVerbrennungHauptbrennstoff.VALUE_2469: HauptbrennstoffEnum.Flüssiggas,
    EinheitVerbrennungHauptbrennstoff.VALUE_2470: HauptbrennstoffEnum.Petrolkoks,
    EinheitVerbrennungHauptbrennstoff.VALUE_2471: HauptbrennstoffEnum.Raffineriegas,
    EinheitVerbrennungHauptbrennstoff.VALUE_2472: HauptbrennstoffEnum.Andere_Mineraloelprodukte,
    EinheitVerbrennungHauptbrennstoff.VALUE_2473: HauptbrennstoffEnum.Erdgas_Erdoelgas,
    EinheitVerbrennungHauptbrennstoff.VALUE_2474: HauptbrennstoffEnum.Grubengas,
    EinheitVerbrennungHauptbrennstoff.VALUE_2475: HauptbrennstoffEnum.Hochofengas_Konvertergas,
    EinheitVerbrennungHauptbrennstoff.VALUE_2476: HauptbrennstoffEnum.Kokereigas,
    EinheitVerbrennungHauptbrennstoff.VALUE_2477: HauptbrennstoffEnum.Andere_Gase,
    EinheitVerbrennungHauptbrennstoff.VALUE_2478: HauptbrennstoffEnum.Sonstige_hergestellte_Gase,
    EinheitVerbrennungHauptbrennstoff.VALUE_2479: HauptbrennstoffEnum.nicht_biogener_Industrieabfall,
    EinheitVerbrennungHauptbrennstoff.VALUE_2480: HauptbrennstoffEnum.nicht_biogener_Abfall,
    EinheitVerbrennungHauptbrennstoff.VALUE_2481: HauptbrennstoffEnum.Prozessdampf,
    EinheitVerbrennungHauptbrennstoff.VALUE_2482: HauptbrennstoffEnum.Dampf,
    EinheitVerbrennungHauptbrennstoff.VALUE_2483: HauptbrennstoffEnum.Sonstige_Waerme,
}
SYSTEMSTATUS_MAP = {
    EinheitVerbrennungEinheitBetriebsstatus.VALUE_37: BetriebsstatusEnum.In_Betrieb,
    EinheitVerbrennungEinheitBetriebsstatus.VALUE_35: BetriebsstatusEnum.In_Planung,
    EinheitVerbrennungEinheitBetriebsstatus.VALUE_38: BetriebsstatusEnum.Voruebergehend_stillgelegt,
    EinheitVerbrennungEinheitBetriebsstatus.VALUE_31: BetriebsstatusEnum.Endgueltig_stillgelegt,
}
FEED_IN_MAP = {
    EinheitVerbrennungEinspeisungsart.VALUE_688: FeedInType.Volleinspeisung,
    EinheitVerbrennungEinspeisungsart.VALUE_689: FeedInType.Teileinspeisung,
}
