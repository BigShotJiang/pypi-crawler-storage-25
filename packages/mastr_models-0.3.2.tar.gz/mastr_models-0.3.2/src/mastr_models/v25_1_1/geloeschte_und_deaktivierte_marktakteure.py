from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class GeloeschterUndDeaktivierterMarktakteurMarktakteurStatus(Enum):
    VALUE_488 = "488"
    VALUE_489 = "489"


@dataclass
class GeloeschteUndDeaktivierteMarktakteure:
    geloeschter_und_deaktivierter_marktakteur: list[
        "GeloeschteUndDeaktivierteMarktakteure.GeloeschterUndDeaktivierterMarktakteur"
    ] = field(
        default_factory=list,
        metadata={
            "name": "GeloeschterUndDeaktivierterMarktakteur",
            "type": "Element",
        },
    )

    @dataclass
    class GeloeschterUndDeaktivierterMarktakteur:
        marktakteur_mastr_nummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "MarktakteurMastrNummer",
                "type": "Element",
            },
        )
        marktakteur_status: Optional[
            GeloeschterUndDeaktivierterMarktakteurMarktakteurStatus
        ] = field(
            default=None,
            metadata={
                "name": "MarktakteurStatus",
                "type": "Element",
            },
        )
        datum_letzte_aktualisierung: Optional[str] = field(
            default=None,
            metadata={
                "name": "DatumLetzteAktualisierung",
                "type": "Element",
            },
        )
