from dataclasses import dataclass, field
from enum import Enum

from xsdata.models.datatype import XmlDate, XmlDateTime


class EinheitVerbrennungAnlageIstImKombibetrieb(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitVerbrennungAnschlussAnHoechstOderHochSpannung(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitVerbrennungAusschliesslicheVerwendungImKombibetrieb(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitVerbrennungBestandteilGrenzkraftwerk(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitVerbrennungBundesland(Enum):
    VALUE_1416 = 1416
    VALUE_1402 = 1402
    VALUE_1403 = 1403
    VALUE_1401 = 1401
    VALUE_1400 = 1400
    VALUE_1404 = 1404
    VALUE_1406 = 1406
    VALUE_1405 = 1405
    VALUE_1407 = 1407
    VALUE_1408 = 1408
    VALUE_1409 = 1409
    VALUE_1410 = 1410
    VALUE_1412 = 1412
    VALUE_1413 = 1413
    VALUE_1414 = 1414
    VALUE_1411 = 1411
    VALUE_1415 = 1415


class EinheitVerbrennungEinheitBetriebsstatus(Enum):
    VALUE_37 = 37
    VALUE_35 = 35
    VALUE_38 = 38
    VALUE_31 = 31


class EinheitVerbrennungEinheitSystemstatus(Enum):
    VALUE_472 = 472
    VALUE_473 = 473
    VALUE_484 = 484
    VALUE_490 = 490
    VALUE_572 = 572


class EinheitVerbrennungEinsatzort(Enum):
    VALUE_2399 = 2399
    VALUE_1531 = 1531
    VALUE_738 = 738
    VALUE_739 = 739
    VALUE_1532 = 1532
    VALUE_733 = 733
    VALUE_741 = 741
    VALUE_740 = 740
    VALUE_737 = 737
    VALUE_742 = 742
    VALUE_743 = 743
    VALUE_734 = 734
    VALUE_744 = 744
    VALUE_1533 = 1533
    VALUE_745 = 745
    VALUE_746 = 746
    VALUE_736 = 736
    VALUE_747 = 747
    VALUE_755 = 755
    VALUE_754 = 754
    VALUE_753 = 753
    VALUE_752 = 752
    VALUE_735 = 735
    VALUE_751 = 751
    VALUE_750 = 750
    VALUE_748 = 748
    VALUE_749 = 749
    VALUE_2400 = 2400


class EinheitVerbrennungEinspeisungsart(Enum):
    VALUE_688 = 688
    VALUE_689 = 689


class EinheitVerbrennungEnergietraeger(Enum):
    VALUE_2411 = 2411
    VALUE_2493 = 2493
    VALUE_2408 = 2408
    VALUE_2410 = 2410
    VALUE_2494 = 2494
    VALUE_2409 = 2409
    VALUE_2412 = 2412
    VALUE_2407 = 2407
    VALUE_2413 = 2413
    VALUE_2403 = 2403
    VALUE_2404 = 2404
    VALUE_2405 = 2405
    VALUE_2495 = 2495
    VALUE_2406 = 2406
    VALUE_2957 = 2957
    VALUE_2958 = 2958
    VALUE_2496 = 2496
    VALUE_2498 = 2498
    VALUE_2497 = 2497


class EinheitVerbrennungFernsteuerbarkeitDv(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitVerbrennungFernsteuerbarkeitNb(Enum):
    VALUE_1 = 1
    VALUE_0 = 0


class EinheitVerbrennungHauptbrennstoff(Enum):
    VALUE_2456 = 2456
    VALUE_2457 = 2457
    VALUE_2458 = 2458
    VALUE_2459 = 2459
    VALUE_2460 = 2460
    VALUE_2461 = 2461
    VALUE_2462 = 2462
    VALUE_2463 = 2463
    VALUE_2464 = 2464
    VALUE_2465 = 2465
    VALUE_2466 = 2466
    VALUE_2467 = 2467
    VALUE_2468 = 2468
    VALUE_2469 = 2469
    VALUE_2470 = 2470
    VALUE_2471 = 2471
    VALUE_2472 = 2472
    VALUE_2473 = 2473
    VALUE_2474 = 2474
    VALUE_2475 = 2475
    VALUE_2476 = 2476
    VALUE_2477 = 2477
    VALUE_2478 = 2478
    VALUE_2479 = 2479
    VALUE_2480 = 2480
    VALUE_2481 = 2481
    VALUE_2482 = 2482
    VALUE_2483 = 2483


class EinheitVerbrennungHausnummerNichtGefunden(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitVerbrennungHausnummerNv(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitVerbrennungKraftwerksnummerNv(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitVerbrennungLand(Enum):
    VALUE_84 = 84
    VALUE_90 = 90
    VALUE_198 = 198
    VALUE_66 = 66
    VALUE_169 = 169
    VALUE_106 = 106
    VALUE_231 = 231
    VALUE_206 = 206
    VALUE_215 = 215
    VALUE_269 = 269


class EinheitVerbrennungNetzbetreiberpruefungStatus(Enum):
    VALUE_2954 = 2954
    VALUE_2955 = 2955
    VALUE_3075 = 3075


class EinheitVerbrennungNichtVorhandenInMigriertenEinheiten(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitVerbrennungNotstromaggregat(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitVerbrennungReserveartNachDemEnWg(Enum):
    VALUE_3078 = 3078
    VALUE_3079 = 3079
    VALUE_3080 = 3080


class EinheitVerbrennungStrasseNichtGefunden(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitVerbrennungTechnologie(Enum):
    VALUE_542 = 542
    VALUE_543 = 543
    VALUE_544 = 544
    VALUE_545 = 545
    VALUE_546 = 546
    VALUE_833 = 833
    VALUE_834 = 834
    VALUE_835 = 835
    VALUE_836 = 836
    VALUE_837 = 837
    VALUE_838 = 838
    VALUE_839 = 839
    VALUE_840 = 840
    VALUE_1538 = 1538


class EinheitVerbrennungWeicNv(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitVerbrennungWeitererHauptbrennstoff(Enum):
    VALUE_2414 = 2414
    VALUE_2415 = 2415
    VALUE_2416 = 2416
    VALUE_2417 = 2417
    VALUE_2418 = 2418
    VALUE_2419 = 2419
    VALUE_2420 = 2420
    VALUE_2421 = 2421
    VALUE_2422 = 2422
    VALUE_2423 = 2423
    VALUE_2424 = 2424
    VALUE_2425 = 2425
    VALUE_2426 = 2426
    VALUE_2427 = 2427
    VALUE_2428 = 2428
    VALUE_2429 = 2429
    VALUE_2430 = 2430
    VALUE_2431 = 2431
    VALUE_2432 = 2432
    VALUE_2433 = 2433
    VALUE_2434 = 2434
    VALUE_2435 = 2435
    VALUE_2436 = 2436
    VALUE_2437 = 2437
    VALUE_2438 = 2438
    VALUE_2439 = 2439
    VALUE_2440 = 2440
    VALUE_2441 = 2441
    VALUE_2442 = 2442
    VALUE_2443 = 2443
    VALUE_2444 = 2444
    VALUE_2445 = 2445
    VALUE_2446 = 2446
    VALUE_2447 = 2447
    VALUE_2448 = 2448
    VALUE_2456 = 2456
    VALUE_2457 = 2457
    VALUE_2458 = 2458
    VALUE_2459 = 2459
    VALUE_2460 = 2460
    VALUE_2461 = 2461
    VALUE_2462 = 2462
    VALUE_2463 = 2463
    VALUE_2464 = 2464
    VALUE_2465 = 2465
    VALUE_2466 = 2466
    VALUE_2467 = 2467
    VALUE_2468 = 2468
    VALUE_2469 = 2469
    VALUE_2470 = 2470
    VALUE_2471 = 2471
    VALUE_2472 = 2472
    VALUE_2473 = 2473
    VALUE_2474 = 2474
    VALUE_2475 = 2475
    VALUE_2476 = 2476
    VALUE_2477 = 2477
    VALUE_2478 = 2478
    VALUE_2479 = 2479
    VALUE_2480 = 2480
    VALUE_2481 = 2481
    VALUE_2482 = 2482
    VALUE_2483 = 2483


@dataclass
class EinheitenVerbrennung:
    einheit_verbrennung: list["EinheitenVerbrennung.EinheitVerbrennung"] = (
        field(
            default_factory=list,
            metadata={
                "name": "EinheitVerbrennung",
                "type": "Element",
            },
        )
    )

    @dataclass
    class EinheitVerbrennung:
        einheit_mastr_nummer: list[str] = field(
            default_factory=list,
            metadata={
                "name": "EinheitMastrNummer",
                "type": "Element",
            },
        )
        datum_letzte_aktualisierung: list[XmlDateTime] = field(
            default_factory=list,
            metadata={
                "name": "DatumLetzteAktualisierung",
                "type": "Element",
            },
        )
        lokation_ma_st_rnummer: list[str] = field(
            default_factory=list,
            metadata={
                "name": "LokationMaStRNummer",
                "type": "Element",
            },
        )
        netzbetreiberpruefung_status: list[
            EinheitVerbrennungNetzbetreiberpruefungStatus
        ] = field(
            default_factory=list,
            metadata={
                "name": "NetzbetreiberpruefungStatus",
                "type": "Element",
            },
        )
        netzbetreiberpruefung_datum: list[XmlDate] = field(
            default_factory=list,
            metadata={
                "name": "NetzbetreiberpruefungDatum",
                "type": "Element",
            },
        )
        anlagenbetreiber_mastr_nummer: list[str] = field(
            default_factory=list,
            metadata={
                "name": "AnlagenbetreiberMastrNummer",
                "type": "Element",
            },
        )
        land: list[EinheitVerbrennungLand] = field(
            default_factory=list,
            metadata={
                "name": "Land",
                "type": "Element",
            },
        )
        bundesland: list[EinheitVerbrennungBundesland] = field(
            default_factory=list,
            metadata={
                "name": "Bundesland",
                "type": "Element",
            },
        )
        landkreis: list[str] = field(
            default_factory=list,
            metadata={
                "name": "Landkreis",
                "type": "Element",
            },
        )
        gemeinde: list[str] = field(
            default_factory=list,
            metadata={
                "name": "Gemeinde",
                "type": "Element",
            },
        )
        gemeindeschluessel: list[str] = field(
            default_factory=list,
            metadata={
                "name": "Gemeindeschluessel",
                "type": "Element",
            },
        )
        postleitzahl: list[str] = field(
            default_factory=list,
            metadata={
                "name": "Postleitzahl",
                "type": "Element",
            },
        )
        strasse: list[str] = field(
            default_factory=list,
            metadata={
                "name": "Strasse",
                "type": "Element",
            },
        )
        gemarkung: list[str] = field(
            default_factory=list,
            metadata={
                "name": "Gemarkung",
                "type": "Element",
            },
        )
        flur_flurstuecknummern: list[str] = field(
            default_factory=list,
            metadata={
                "name": "FlurFlurstuecknummern",
                "type": "Element",
            },
        )
        strasse_nicht_gefunden: list[
            EinheitVerbrennungStrasseNichtGefunden
        ] = field(
            default_factory=list,
            metadata={
                "name": "StrasseNichtGefunden",
                "type": "Element",
            },
        )
        hausnummer: list[str] = field(
            default_factory=list,
            metadata={
                "name": "Hausnummer",
                "type": "Element",
            },
        )
        hausnummer_nv: list[EinheitVerbrennungHausnummerNv] = field(
            default_factory=list,
            metadata={
                "name": "Hausnummer_nv",
                "type": "Element",
            },
        )
        hausnummer_nicht_gefunden: list[
            EinheitVerbrennungHausnummerNichtGefunden
        ] = field(
            default_factory=list,
            metadata={
                "name": "HausnummerNichtGefunden",
                "type": "Element",
            },
        )
        ort: list[str] = field(
            default_factory=list,
            metadata={
                "name": "Ort",
                "type": "Element",
            },
        )
        laengengrad: list[float] = field(
            default_factory=list,
            metadata={
                "name": "Laengengrad",
                "type": "Element",
            },
        )
        breitengrad: list[float] = field(
            default_factory=list,
            metadata={
                "name": "Breitengrad",
                "type": "Element",
            },
        )
        registrierungsdatum: list[XmlDate] = field(
            default_factory=list,
            metadata={
                "name": "Registrierungsdatum",
                "type": "Element",
            },
        )
        inbetriebnahmedatum: list[XmlDate] = field(
            default_factory=list,
            metadata={
                "name": "Inbetriebnahmedatum",
                "type": "Element",
            },
        )
        datum_endgueltige_stilllegung: list[XmlDate] = field(
            default_factory=list,
            metadata={
                "name": "DatumEndgueltigeStilllegung",
                "type": "Element",
            },
        )
        datum_beginn_voruebergehende_stilllegung: list[XmlDate] = field(
            default_factory=list,
            metadata={
                "name": "DatumBeginnVoruebergehendeStilllegung",
                "type": "Element",
            },
        )
        datum_wiederaufnahme_betrieb: list[XmlDate] = field(
            default_factory=list,
            metadata={
                "name": "DatumWiederaufnahmeBetrieb",
                "type": "Element",
            },
        )
        geplantes_inbetriebnahmedatum: list[XmlDate] = field(
            default_factory=list,
            metadata={
                "name": "GeplantesInbetriebnahmedatum",
                "type": "Element",
            },
        )
        einheit_systemstatus: list[EinheitVerbrennungEinheitSystemstatus] = (
            field(
                default_factory=list,
                metadata={
                    "name": "EinheitSystemstatus",
                    "type": "Element",
                },
            )
        )
        einheit_betriebsstatus: list[
            EinheitVerbrennungEinheitBetriebsstatus
        ] = field(
            default_factory=list,
            metadata={
                "name": "EinheitBetriebsstatus",
                "type": "Element",
            },
        )
        bestandsanlage_mastr_nummer: list[str] = field(
            default_factory=list,
            metadata={
                "name": "BestandsanlageMastrNummer",
                "type": "Element",
            },
        )
        nicht_vorhanden_in_migrierten_einheiten: list[
            EinheitVerbrennungNichtVorhandenInMigriertenEinheiten
        ] = field(
            default_factory=list,
            metadata={
                "name": "NichtVorhandenInMigriertenEinheiten",
                "type": "Element",
            },
        )
        alt_anlagenbetreiber_mastr_nummer: list[str] = field(
            default_factory=list,
            metadata={
                "name": "AltAnlagenbetreiberMastrNummer",
                "type": "Element",
            },
        )
        datum_des_betreiberwechsels: list[XmlDate] = field(
            default_factory=list,
            metadata={
                "name": "DatumDesBetreiberwechsels",
                "type": "Element",
            },
        )
        datum_registrierung_des_betreiberwechsels: list[XmlDate] = field(
            default_factory=list,
            metadata={
                "name": "DatumRegistrierungDesBetreiberwechsels",
                "type": "Element",
            },
        )
        name_stromerzeugungseinheit: list[str] = field(
            default_factory=list,
            metadata={
                "name": "NameStromerzeugungseinheit",
                "type": "Element",
            },
        )
        weic: list[str] = field(
            default_factory=list,
            metadata={
                "name": "Weic",
                "type": "Element",
            },
        )
        weic_nv: list[EinheitVerbrennungWeicNv] = field(
            default_factory=list,
            metadata={
                "name": "Weic_nv",
                "type": "Element",
            },
        )
        weic_display_name: list[str] = field(
            default_factory=list,
            metadata={
                "name": "WeicDisplayName",
                "type": "Element",
            },
        )
        kraftwerksnummer: list[str] = field(
            default_factory=list,
            metadata={
                "name": "Kraftwerksnummer",
                "type": "Element",
            },
        )
        kraftwerksnummer_nv: list[EinheitVerbrennungKraftwerksnummerNv] = (
            field(
                default_factory=list,
                metadata={
                    "name": "Kraftwerksnummer_nv",
                    "type": "Element",
                },
            )
        )
        energietraeger: list[EinheitVerbrennungEnergietraeger] = field(
            default_factory=list,
            metadata={
                "name": "Energietraeger",
                "type": "Element",
            },
        )
        bruttoleistung: list[float] = field(
            default_factory=list,
            metadata={
                "name": "Bruttoleistung",
                "type": "Element",
            },
        )
        nettonennleistung: list[float] = field(
            default_factory=list,
            metadata={
                "name": "Nettonennleistung",
                "type": "Element",
            },
        )
        anschluss_an_hoechst_oder_hoch_spannung: list[
            EinheitVerbrennungAnschlussAnHoechstOderHochSpannung
        ] = field(
            default_factory=list,
            metadata={
                "name": "AnschlussAnHoechstOderHochSpannung",
                "type": "Element",
            },
        )
        einsatzverantwortlicher: list[str] = field(
            default_factory=list,
            metadata={
                "name": "Einsatzverantwortlicher",
                "type": "Element",
            },
        )
        fernsteuerbarkeit_nb: list[EinheitVerbrennungFernsteuerbarkeitNb] = (
            field(
                default_factory=list,
                metadata={
                    "name": "FernsteuerbarkeitNb",
                    "type": "Element",
                },
            )
        )
        fernsteuerbarkeit_dv: list[EinheitVerbrennungFernsteuerbarkeitDv] = (
            field(
                default_factory=list,
                metadata={
                    "name": "FernsteuerbarkeitDv",
                    "type": "Element",
                },
            )
        )
        einspeisungsart: list[EinheitVerbrennungEinspeisungsart] = field(
            default_factory=list,
            metadata={
                "name": "Einspeisungsart",
                "type": "Element",
            },
        )
        gen_mastr_nummer: list[str] = field(
            default_factory=list,
            metadata={
                "name": "GenMastrNummer",
                "type": "Element",
            },
        )
        reserveart_nach_dem_en_wg: list[
            EinheitVerbrennungReserveartNachDemEnWg
        ] = field(
            default_factory=list,
            metadata={
                "name": "ReserveartNachDemEnWG",
                "type": "Element",
            },
        )
        datum_ueberfuehrung_in_reserve: list[XmlDate] = field(
            default_factory=list,
            metadata={
                "name": "DatumUeberfuehrungInReserve",
                "type": "Element",
            },
        )
        name_kraftwerk: list[str] = field(
            default_factory=list,
            metadata={
                "name": "NameKraftwerk",
                "type": "Element",
            },
        )
        name_kraftwerksblock: list[str] = field(
            default_factory=list,
            metadata={
                "name": "NameKraftwerksblock",
                "type": "Element",
            },
        )
        anlage_ist_im_kombibetrieb: list[
            EinheitVerbrennungAnlageIstImKombibetrieb
        ] = field(
            default_factory=list,
            metadata={
                "name": "AnlageIstImKombibetrieb",
                "type": "Element",
            },
        )
        hauptbrennstoff: list[EinheitVerbrennungHauptbrennstoff] = field(
            default_factory=list,
            metadata={
                "name": "Hauptbrennstoff",
                "type": "Element",
            },
        )
        bestandteil_grenzkraftwerk: list[
            EinheitVerbrennungBestandteilGrenzkraftwerk
        ] = field(
            default_factory=list,
            metadata={
                "name": "BestandteilGrenzkraftwerk",
                "type": "Element",
            },
        )
        weiterer_hauptbrennstoff: list[
            EinheitVerbrennungWeitererHauptbrennstoff
        ] = field(
            default_factory=list,
            metadata={
                "name": "WeitererHauptbrennstoff",
                "type": "Element",
            },
        )
        weitere_brennstoffe: list[str] = field(
            default_factory=list,
            metadata={
                "name": "WeitereBrennstoffe",
                "type": "Element",
            },
        )
        notstromaggregat: list[EinheitVerbrennungNotstromaggregat] = field(
            default_factory=list,
            metadata={
                "name": "Notstromaggregat",
                "type": "Element",
            },
        )
        kwk_ma_st_rnummer: list[str] = field(
            default_factory=list,
            metadata={
                "name": "KwkMaStRNummer",
                "type": "Element",
            },
        )
        einsatzort: list[EinheitVerbrennungEinsatzort] = field(
            default_factory=list,
            metadata={
                "name": "Einsatzort",
                "type": "Element",
            },
        )
        technologie: list[EinheitVerbrennungTechnologie] = field(
            default_factory=list,
            metadata={
                "name": "Technologie",
                "type": "Element",
            },
        )
        steigerung_nettonennleistung_kombibetrieb: list[float] = field(
            default_factory=list,
            metadata={
                "name": "SteigerungNettonennleistungKombibetrieb",
                "type": "Element",
            },
        )
        adresszusatz: list[str] = field(
            default_factory=list,
            metadata={
                "name": "Adresszusatz",
                "type": "Element",
            },
        )
        mastr_nummern_kombibetrieb: list[str] = field(
            default_factory=list,
            metadata={
                "name": "MastrNummernKombibetrieb",
                "type": "Element",
            },
        )
        datum_baubeginn: list[XmlDate] = field(
            default_factory=list,
            metadata={
                "name": "DatumBaubeginn",
                "type": "Element",
            },
        )
        netzreserve_ab_datum: list[XmlDate] = field(
            default_factory=list,
            metadata={
                "name": "NetzreserveAbDatum",
                "type": "Element",
            },
        )
        sicherheitsbereitschaft_ab_datum: list[XmlDate] = field(
            default_factory=list,
            metadata={
                "name": "SicherheitsbereitschaftAbDatum",
                "type": "Element",
            },
        )
        nettonennleistung_deutschland: list[float] = field(
            default_factory=list,
            metadata={
                "name": "NettonennleistungDeutschland",
                "type": "Element",
            },
        )
        ausschliessliche_verwendung_im_kombibetrieb: list[
            EinheitVerbrennungAusschliesslicheVerwendungImKombibetrieb
        ] = field(
            default_factory=list,
            metadata={
                "name": "AusschliesslicheVerwendungImKombibetrieb",
                "type": "Element",
            },
        )
