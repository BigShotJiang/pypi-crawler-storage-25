from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from xsdata.models.datatype import XmlDate, XmlDateTime


class EinheitStromVerbraucherBundesland(Enum):
    VALUE_1416 = 1416
    VALUE_1402 = 1402
    VALUE_1403 = 1403
    VALUE_1401 = 1401
    VALUE_1400 = 1400
    VALUE_1404 = 1404
    VALUE_1406 = 1406
    VALUE_1405 = 1405
    VALUE_1407 = 1407
    VALUE_1408 = 1408
    VALUE_1409 = 1409
    VALUE_1410 = 1410
    VALUE_1412 = 1412
    VALUE_1413 = 1413
    VALUE_1414 = 1414
    VALUE_1411 = 1411
    VALUE_1415 = 1415


class EinheitStromVerbraucherEinheitBetriebsstatus(Enum):
    VALUE_35 = 35
    VALUE_38 = 38
    VALUE_37 = 37
    VALUE_31 = 31


class EinheitStromVerbraucherEinheitSystemstatus(Enum):
    VALUE_472 = 472
    VALUE_473 = 473
    VALUE_484 = 484
    VALUE_490 = 490
    VALUE_572 = 572


class EinheitStromVerbraucherHausnummerNichtGefunden(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitStromVerbraucherHausnummerNv(Enum):
    VALUE_1 = 1
    VALUE_0 = 0


class EinheitStromVerbraucherLand(Enum):
    VALUE_84 = 84
    VALUE_90 = 90
    VALUE_198 = 198
    VALUE_66 = 66
    VALUE_169 = 169
    VALUE_106 = 106
    VALUE_231 = 231
    VALUE_206 = 206
    VALUE_215 = 215
    VALUE_269 = 269


class EinheitStromVerbraucherNetzbetreiberpruefungStatus(Enum):
    VALUE_2954 = 2954
    VALUE_2955 = 2955
    VALUE_3075 = 3075


class EinheitStromVerbraucherNichtVorhandenInMigriertenEinheiten(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitStromVerbraucherPraequalifiziertGemaessAblav(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitStromVerbraucherStrasseNichtGefunden(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


@dataclass
class EinheitenStromVerbraucher:
    einheit_strom_verbraucher: list[
        "EinheitenStromVerbraucher.EinheitStromVerbraucher"
    ] = field(
        default_factory=list,
        metadata={
            "name": "EinheitStromVerbraucher",
            "type": "Element",
        },
    )

    @dataclass
    class EinheitStromVerbraucher:
        einheit_mastr_nummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "EinheitMastrNummer",
                "type": "Element",
                "required": True,
            },
        )
        datum_letzte_aktualisierung: Optional[XmlDateTime] = field(
            default=None,
            metadata={
                "name": "DatumLetzteAktualisierung",
                "type": "Element",
                "required": True,
            },
        )
        lokation_ma_st_rnummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "LokationMaStRNummer",
                "type": "Element",
            },
        )
        netzbetreiberpruefung_status: Optional[
            EinheitStromVerbraucherNetzbetreiberpruefungStatus
        ] = field(
            default=None,
            metadata={
                "name": "NetzbetreiberpruefungStatus",
                "type": "Element",
                "required": True,
            },
        )
        netzbetreiberpruefung_datum: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "NetzbetreiberpruefungDatum",
                "type": "Element",
            },
        )
        anlagenbetreiber_mastr_nummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "AnlagenbetreiberMastrNummer",
                "type": "Element",
                "required": True,
            },
        )
        land: Optional[EinheitStromVerbraucherLand] = field(
            default=None,
            metadata={
                "name": "Land",
                "type": "Element",
                "required": True,
            },
        )
        bundesland: Optional[EinheitStromVerbraucherBundesland] = field(
            default=None,
            metadata={
                "name": "Bundesland",
                "type": "Element",
            },
        )
        landkreis: Optional[str] = field(
            default=None,
            metadata={
                "name": "Landkreis",
                "type": "Element",
            },
        )
        gemeinde: Optional[str] = field(
            default=None,
            metadata={
                "name": "Gemeinde",
                "type": "Element",
            },
        )
        gemeindeschluessel: Optional[str] = field(
            default=None,
            metadata={
                "name": "Gemeindeschluessel",
                "type": "Element",
            },
        )
        postleitzahl: Optional[str] = field(
            default=None,
            metadata={
                "name": "Postleitzahl",
                "type": "Element",
                "required": True,
            },
        )
        strasse: Optional[str] = field(
            default=None,
            metadata={
                "name": "Strasse",
                "type": "Element",
            },
        )
        gemarkung: Optional[str] = field(
            default=None,
            metadata={
                "name": "Gemarkung",
                "type": "Element",
            },
        )
        flur_flurstuecknummern: Optional[str] = field(
            default=None,
            metadata={
                "name": "FlurFlurstuecknummern",
                "type": "Element",
            },
        )
        strasse_nicht_gefunden: Optional[
            EinheitStromVerbraucherStrasseNichtGefunden
        ] = field(
            default=None,
            metadata={
                "name": "StrasseNichtGefunden",
                "type": "Element",
                "required": True,
            },
        )
        hausnummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "Hausnummer",
                "type": "Element",
            },
        )
        hausnummer_nv: Optional[EinheitStromVerbraucherHausnummerNv] = field(
            default=None,
            metadata={
                "name": "Hausnummer_nv",
                "type": "Element",
                "required": True,
            },
        )
        hausnummer_nicht_gefunden: Optional[
            EinheitStromVerbraucherHausnummerNichtGefunden
        ] = field(
            default=None,
            metadata={
                "name": "HausnummerNichtGefunden",
                "type": "Element",
                "required": True,
            },
        )
        adresszusatz: Optional[str] = field(
            default=None,
            metadata={
                "name": "Adresszusatz",
                "type": "Element",
            },
        )
        ort: Optional[str] = field(
            default=None,
            metadata={
                "name": "Ort",
                "type": "Element",
                "required": True,
            },
        )
        laengengrad: Optional[float] = field(
            default=None,
            metadata={
                "name": "Laengengrad",
                "type": "Element",
                "required": True,
            },
        )
        breitengrad: Optional[float] = field(
            default=None,
            metadata={
                "name": "Breitengrad",
                "type": "Element",
                "required": True,
            },
        )
        registrierungsdatum: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "Registrierungsdatum",
                "type": "Element",
                "required": True,
            },
        )
        inbetriebnahmedatum: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "Inbetriebnahmedatum",
                "type": "Element",
            },
        )
        datum_endgueltige_stilllegung: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "DatumEndgueltigeStilllegung",
                "type": "Element",
            },
        )
        datum_beginn_voruebergehende_stilllegung: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "DatumBeginnVoruebergehendeStilllegung",
                "type": "Element",
            },
        )
        datum_wiederaufnahme_betrieb: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "DatumWiederaufnahmeBetrieb",
                "type": "Element",
            },
        )
        geplantes_inbetriebnahmedatum: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "GeplantesInbetriebnahmedatum",
                "type": "Element",
            },
        )
        einheit_systemstatus: Optional[
            EinheitStromVerbraucherEinheitSystemstatus
        ] = field(
            default=None,
            metadata={
                "name": "EinheitSystemstatus",
                "type": "Element",
                "required": True,
            },
        )
        einheit_betriebsstatus: Optional[
            EinheitStromVerbraucherEinheitBetriebsstatus
        ] = field(
            default=None,
            metadata={
                "name": "EinheitBetriebsstatus",
                "type": "Element",
                "required": True,
            },
        )
        bestandsanlage_mastr_nummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "BestandsanlageMastrNummer",
                "type": "Element",
            },
        )
        nicht_vorhanden_in_migrierten_einheiten: Optional[
            EinheitStromVerbraucherNichtVorhandenInMigriertenEinheiten
        ] = field(
            default=None,
            metadata={
                "name": "NichtVorhandenInMigriertenEinheiten",
                "type": "Element",
                "required": True,
            },
        )
        alt_anlagenbetreiber_mastr_nummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "AltAnlagenbetreiberMastrNummer",
                "type": "Element",
            },
        )
        datum_des_betreiberwechsels: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "DatumDesBetreiberwechsels",
                "type": "Element",
            },
        )
        datum_registrierung_des_betreiberwechsels: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "DatumRegistrierungDesBetreiberwechsels",
                "type": "Element",
            },
        )
        einsatzverantwortlicher: Optional[str] = field(
            default=None,
            metadata={
                "name": "Einsatzverantwortlicher",
                "type": "Element",
            },
        )
        name_stromverbrauchseinheit: Optional[str] = field(
            default=None,
            metadata={
                "name": "NameStromverbrauchseinheit",
                "type": "Element",
                "required": True,
            },
        )
        anzahl_stromverbrauchseinheiten_groesser50_mw: Optional[int] = field(
            default=None,
            metadata={
                "name": "AnzahlStromverbrauchseinheitenGroesser50Mw",
                "type": "Element",
            },
        )
        praequalifiziert_gemaess_ablav: Optional[
            EinheitStromVerbraucherPraequalifiziertGemaessAblav
        ] = field(
            default=None,
            metadata={
                "name": "PraequalifiziertGemaessAblav",
                "type": "Element",
            },
        )
        gemeinsam_registrierte_solareinheit_mastr_nummer: Optional[str] = (
            field(
                default=None,
                metadata={
                    "name": "GemeinsamRegistrierteSolareinheitMastrNummer",
                    "type": "Element",
                },
            )
        )
