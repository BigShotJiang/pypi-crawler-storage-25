from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from xsdata.models.datatype import XmlDate, XmlDateTime


class AnlageEegWindAnlageBetriebsstatus(Enum):
    VALUE_35 = 35
    VALUE_38 = 38
    VALUE_37 = 37
    VALUE_31 = 31


class AnlageEegWindAnlagenkennzifferAnlagenregisterNv(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class AnlageEegWindAusschreibungZuschlag(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class AnlageEegWindPilotAnlage(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class AnlageEegWindPrototypAnlage(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class AnlageEegWindVerhaeltnisErtragsschaetzungReferenzertragNv(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class AnlageEegWindVerhaeltnisReferenzertragErtrag10JahreNv(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class AnlageEegWindVerhaeltnisReferenzertragErtrag15JahreNv(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class AnlageEegWindVerhaeltnisReferenzertragErtrag5JahreNv(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


@dataclass
class AnlagenEegWind:
    anlage_eeg_wind: list["AnlagenEegWind.AnlageEegWind"] = field(
        default_factory=list,
        metadata={
            "name": "AnlageEegWind",
            "type": "Element",
        },
    )

    @dataclass
    class AnlageEegWind:
        registrierungsdatum: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "Registrierungsdatum",
                "type": "Element",
                "required": True,
            },
        )
        datum_letzte_aktualisierung: Optional[XmlDateTime] = field(
            default=None,
            metadata={
                "name": "DatumLetzteAktualisierung",
                "type": "Element",
                "required": True,
            },
        )
        eeg_inbetriebnahmedatum: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "EegInbetriebnahmedatum",
                "type": "Element",
                "required": True,
            },
        )
        eeg_ma_st_rnummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "EegMaStRNummer",
                "type": "Element",
                "required": True,
            },
        )
        anlagenkennziffer_anlagenregister: Optional[str] = field(
            default=None,
            metadata={
                "name": "AnlagenkennzifferAnlagenregister",
                "type": "Element",
            },
        )
        anlagenkennziffer_anlagenregister_nv: Optional[
            AnlageEegWindAnlagenkennzifferAnlagenregisterNv
        ] = field(
            default=None,
            metadata={
                "name": "AnlagenkennzifferAnlagenregister_nv",
                "type": "Element",
                "required": True,
            },
        )
        anlagenschluessel_eeg: Optional[str] = field(
            default=None,
            metadata={
                "name": "AnlagenschluesselEeg",
                "type": "Element",
            },
        )
        prototyp_anlage: Optional[AnlageEegWindPrototypAnlage] = field(
            default=None,
            metadata={
                "name": "PrototypAnlage",
                "type": "Element",
            },
        )
        pilot_anlage: Optional[AnlageEegWindPilotAnlage] = field(
            default=None,
            metadata={
                "name": "PilotAnlage",
                "type": "Element",
            },
        )
        installierte_leistung: Optional[float] = field(
            default=None,
            metadata={
                "name": "InstallierteLeistung",
                "type": "Element",
                "required": True,
            },
        )
        verhaeltnis_ertragsschaetzung_referenzertrag: Optional[float] = field(
            default=None,
            metadata={
                "name": "VerhaeltnisErtragsschaetzungReferenzertrag",
                "type": "Element",
            },
        )
        verhaeltnis_ertragsschaetzung_referenzertrag_nv: Optional[
            AnlageEegWindVerhaeltnisErtragsschaetzungReferenzertragNv
        ] = field(
            default=None,
            metadata={
                "name": "VerhaeltnisErtragsschaetzungReferenzertrag_nv",
                "type": "Element",
                "required": True,
            },
        )
        verhaeltnis_referenzertrag_ertrag5_jahre: Optional[float] = field(
            default=None,
            metadata={
                "name": "VerhaeltnisReferenzertragErtrag5Jahre",
                "type": "Element",
            },
        )
        verhaeltnis_referenzertrag_ertrag5_jahre_nv: Optional[
            AnlageEegWindVerhaeltnisReferenzertragErtrag5JahreNv
        ] = field(
            default=None,
            metadata={
                "name": "VerhaeltnisReferenzertragErtrag5Jahre_nv",
                "type": "Element",
                "required": True,
            },
        )
        verhaeltnis_referenzertrag_ertrag10_jahre: Optional[float] = field(
            default=None,
            metadata={
                "name": "VerhaeltnisReferenzertragErtrag10Jahre",
                "type": "Element",
            },
        )
        verhaeltnis_referenzertrag_ertrag10_jahre_nv: Optional[
            AnlageEegWindVerhaeltnisReferenzertragErtrag10JahreNv
        ] = field(
            default=None,
            metadata={
                "name": "VerhaeltnisReferenzertragErtrag10Jahre_nv",
                "type": "Element",
                "required": True,
            },
        )
        verhaeltnis_referenzertrag_ertrag15_jahre: Optional[float] = field(
            default=None,
            metadata={
                "name": "VerhaeltnisReferenzertragErtrag15Jahre",
                "type": "Element",
            },
        )
        verhaeltnis_referenzertrag_ertrag15_jahre_nv: Optional[
            AnlageEegWindVerhaeltnisReferenzertragErtrag15JahreNv
        ] = field(
            default=None,
            metadata={
                "name": "VerhaeltnisReferenzertragErtrag15Jahre_nv",
                "type": "Element",
                "required": True,
            },
        )
        ausschreibung_zuschlag: Optional[AnlageEegWindAusschreibungZuschlag] = field(
            default=None,
            metadata={
                "name": "AusschreibungZuschlag",
                "type": "Element",
            },
        )
        zuschlagsnummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "Zuschlagsnummer",
                "type": "Element",
            },
        )
        anlage_betriebsstatus: Optional[AnlageEegWindAnlageBetriebsstatus] = field(
            default=None,
            metadata={
                "name": "AnlageBetriebsstatus",
                "type": "Element",
                "required": True,
            },
        )
        verknuepfte_einheiten_ma_st_rnummern: Optional[str] = field(
            default=None,
            metadata={
                "name": "VerknuepfteEinheitenMaStRNummern",
                "type": "Element",
                "required": True,
            },
        )
