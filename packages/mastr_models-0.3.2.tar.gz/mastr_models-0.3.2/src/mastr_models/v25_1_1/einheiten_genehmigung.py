from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from xsdata.models.datatype import XmlDate, XmlDateTime


class EinheitGenehmigungArt(Enum):
    VALUE_846 = 846
    VALUE_847 = 847
    VALUE_41 = 41
    VALUE_845 = 845
    VALUE_2555 = 2555
    VALUE_40 = 40
    VALUE_848 = 848
    VALUE_39 = 39
    VALUE_2556 = 2556


class EinheitGenehmigungFristNv(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitGenehmigungWasserrechtAblaufdatumNv(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


@dataclass
class EinheitenGenehmigung:
    einheit_genehmigung: list["EinheitenGenehmigung.EinheitGenehmigung"] = (
        field(
            default_factory=list,
            metadata={
                "name": "EinheitGenehmigung",
                "type": "Element",
            },
        )
    )

    @dataclass
    class EinheitGenehmigung:
        gen_mastr_nummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "GenMastrNummer",
                "type": "Element",
                "required": True,
            },
        )
        datum_letzte_aktualisierung: Optional[XmlDateTime] = field(
            default=None,
            metadata={
                "name": "DatumLetzteAktualisierung",
                "type": "Element",
                "required": True,
            },
        )
        art: Optional[EinheitGenehmigungArt] = field(
            default=None,
            metadata={
                "name": "Art",
                "type": "Element",
                "required": True,
            },
        )
        datum: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "Datum",
                "type": "Element",
                "required": True,
            },
        )
        behoerde: Optional[str] = field(
            default=None,
            metadata={
                "name": "Behoerde",
                "type": "Element",
                "required": True,
            },
        )
        aktenzeichen: Optional[str] = field(
            default=None,
            metadata={
                "name": "Aktenzeichen",
                "type": "Element",
            },
        )
        frist: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "Frist",
                "type": "Element",
            },
        )
        frist_nv: Optional[EinheitGenehmigungFristNv] = field(
            default=None,
            metadata={
                "name": "Frist_nv",
                "type": "Element",
                "required": True,
            },
        )
        wasserrechts_nummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "WasserrechtsNummer",
                "type": "Element",
            },
        )
        wasserrecht_ablaufdatum: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "WasserrechtAblaufdatum",
                "type": "Element",
            },
        )
        wasserrecht_ablaufdatum_nv: Optional[
            EinheitGenehmigungWasserrechtAblaufdatumNv
        ] = field(
            default=None,
            metadata={
                "name": "WasserrechtAblaufdatum_nv",
                "type": "Element",
                "required": True,
            },
        )
        registrierungsdatum: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "Registrierungsdatum",
                "type": "Element",
                "required": True,
            },
        )
        verknuepfte_einheiten_ma_st_rnummern: Optional[str] = field(
            default=None,
            metadata={
                "name": "VerknuepfteEinheitenMaStRNummern",
                "type": "Element",
                "required": True,
            },
        )
        datum_der_antragstellung: Optional[XmlDate] = field(
            default=None,
            metadata={
                "name": "DatumDerAntragstellung",
                "type": "Element",
            },
        )
