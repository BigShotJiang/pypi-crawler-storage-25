import importlib
import inspect
import pkgutil
from datetime import date, datetime
from enum import Enum
from pprint import pprint
from re import fullmatch
from types import ModuleType
from typing import Literal, Protocol, Type, TypeVar

from strenum import StrEnum
from xsdata.formats.dataclass.parsers.config import ParserConfig
from xsdata.models.datatype import XmlDate, XmlDateTime

_T = TypeVar("T")
ID_TYPE = Literal[
    "SEE", "ABR", "KWK", "ADM", "SUP", "SNB", "GNB", "SOM", "SEM", "GEM", "BVI", "OMP"
]


def ensure_one(value: list[_T]) -> _T:
    """Check if one item exists in a list and return it."""
    if len(value) != 1:
        pprint(value)
        raise ValueError(f"Expected exactly one item in {value}.")
    else:
        return value[0]


def validate_mastr_id(value: str, *beginnings: ID_TYPE) -> str:
    if any(fullmatch(beginning + r"\d{12}", value) for beginning in beginnings):
        return value
    else:
        raise ValueError(
            f"`{value}` must start with `{beginnings}` followed by 12 digits."
        )


def validate_marktrolle_id(value: str, *beginnings: ID_TYPE) -> str:
    if any(
        fullmatch(beginning + r"\d{12}" + end, value)
        for beginning in beginnings
        for end in {
            "TK",
            "GK",
            "MB",
            "SR",
            "DL",
            "EI",
            "EV",
            "BE",
            "GS",
            "BO",
            "BV",
            "LT",
            "AN",
            "MV",
            "FN",
            "BK",
            "UN",
        }
    ):
        return value
    else:
        raise ValueError(
            f"`{value}` must start with `{beginnings}` followed by 14 digits."
        )


def unpack_list(value: str) -> list[str]:
    return [y for x in value.split("; ") for y in x.split(", ")]


def xml_date_to_date(value: XmlDate | None) -> date | None:
    return (
        date(
            value.year,
            value.month,
            value.day,
        )
        if value
        else None
    )


def map_xml_datetime(value: XmlDateTime | None) -> date | None:
    return (
        datetime(
            value.year,
            value.month,
            value.day,
            value.hour,
            value.minute,
            value.second,
        )
        if value
        else None
    )


def ensure_one_or_none(value: list[_T] | None) -> _T | None:
    """Check if one item exists in an existing list and return it."""
    return ensure_one(value) if (value and (len(value) >= 1)) else None


def find_subclasses_in_module(
    base_class: Type[_T], parent_module: str | ModuleType
) -> set[Type[_T]]:
    """Find all classes in a module that inherit from (or implement) a base class."""
    subclasses: set[Type[_T]] = set()

    # Convert the parent module to a module object if it's a string
    if isinstance(parent_module, str):
        parent_module = importlib.import_module(parent_module)

    # Iterate over all submodules
    for _, name, _ in pkgutil.walk_packages(
        parent_module.__path__, parent_module.__name__ + "."
    ):
        try:
            # Dynamically import the submodule
            submodule = importlib.import_module(name)
        except ImportError as e:
            print(f"Error importing {name}: {e}")
            continue

        # Inspect module members
        for _, obj in inspect.getmembers(submodule, inspect.isclass):
            if issubclass(base_class, Protocol):
                if isinstance(obj, base_class) and obj is not base_class:
                    subclasses.add(obj)
            else:
                if issubclass(obj, base_class) and obj is not base_class:
                    subclasses.add(obj)

    return subclasses


_STR_ENUM = TypeVar("T", bound=StrEnum)


def map_str_enum(value: Enum | None, enum_class: Type[_STR_ENUM]) -> _STR_ENUM | None:
    """Map an original enum-typed variable to a string-based value."""
    mapping = {x.name: x for x in enum_class}
    if value is None:
        return None
    elif not isinstance(value, Enum):
        raise ValueError(f"Value `{value}` not found in {enum_class.__name__}.")
    elif value.name not in mapping:
        raise ValueError(f"Value `{value}` not found in {enum_class.__name__}.")
    else:
        return mapping[value.name]


def map_bool_enum(value: Enum | None) -> bool | None:
    """Map an original enum-typed variable (with 1 or 0 as value) to a boolean."""
    if value is None:
        return None
    elif not isinstance(value, Enum):
        raise ValueError(f"Value `{value}` not recognized as boolean.")
    else:
        if value.value == 1:
            return True
        elif value.value == 0:
            return False
        else:
            raise ValueError(f"Value `{value}` not recognized as boolean.")


def map_bool_int(value: int | None) -> bool | None:
    """Map an integer (1 or 0) to a boolean."""
    if value is None:
        return None
    elif value == 1:
        return True
    elif value == 0:
        return False
    else:
        raise ValueError(f"Value `{value}` not recognized as boolean.")


ROBUST_CONFIG = ParserConfig(
    fail_on_unknown_properties=False,
    fail_on_unknown_attributes=False,
    process_xinclude=True,
)
