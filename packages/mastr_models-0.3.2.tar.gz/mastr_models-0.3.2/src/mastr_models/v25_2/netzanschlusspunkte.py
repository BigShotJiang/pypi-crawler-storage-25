from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from xsdata.models.datatype import XmlDateTime


class NetzanschlusspunktGasqualitaet(Enum):
    VALUE_767 = 767
    VALUE_766 = 766


class NetzanschlusspunktLokationtyp(Enum):
    VALUE_3 = 3
    VALUE_4 = 4
    VALUE_1 = 1
    VALUE_2 = 2


class NetzanschlusspunktMarktgebiet(Enum):
    VALUE_1001666 = 1001666
    VALUE_1001667 = 1001667
    VALUE_1536 = 1536


class NetzanschlusspunktNochInPlanung(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class NetzanschlusspunktRegelzoneNetzanschlusspunkt(Enum):
    VALUE_1000001 = 1000001
    VALUE_1000010 = 1000010
    VALUE_1001564 = 1001564
    VALUE_1001572 = 1001572


class NetzanschlusspunktSpannungsebene(Enum):
    VALUE_354 = 354
    VALUE_352 = 352
    VALUE_350 = 350
    VALUE_351 = 351
    VALUE_353 = 353
    VALUE_349 = 349
    VALUE_348 = 348


@dataclass
class Netzanschlusspunkte:
    netzanschlusspunkt: list["Netzanschlusspunkte.Netzanschlusspunkt"] = field(
        default_factory=list,
        metadata={
            "name": "Netzanschlusspunkt",
            "type": "Element",
        },
    )

    @dataclass
    class Netzanschlusspunkt:
        netzanschlusspunkt_mastr_nummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "NetzanschlusspunktMastrNummer",
                "type": "Element",
                "required": True,
            },
        )
        netzanschlusspunkt_bezeichnung: Optional[str] = field(
            default=None,
            metadata={
                "name": "NetzanschlusspunktBezeichnung",
                "type": "Element",
            },
        )
        letzte_aenderung: Optional[XmlDateTime] = field(
            default=None,
            metadata={
                "name": "LetzteAenderung",
                "type": "Element",
                "required": True,
            },
        )
        lokation_ma_st_rnummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "LokationMaStRNummer",
                "type": "Element",
                "required": True,
            },
        )
        name_der_technischen_lokation: Optional[str] = field(
            default=None,
            metadata={
                "name": "NameDerTechnischenLokation",
                "type": "Element",
            },
        )
        lokationtyp: Optional[NetzanschlusspunktLokationtyp] = field(
            default=None,
            metadata={
                "name": "Lokationtyp",
                "type": "Element",
                "required": True,
            },
        )
        maximale_einspeiseleistung: Optional[float] = field(
            default=None,
            metadata={
                "name": "MaximaleEinspeiseleistung",
                "type": "Element",
            },
        )
        maximale_ausspeiseleistung: Optional[float] = field(
            default=None,
            metadata={
                "name": "MaximaleAusspeiseleistung",
                "type": "Element",
            },
        )
        gasqualitaet: Optional[NetzanschlusspunktGasqualitaet] = field(
            default=None,
            metadata={
                "name": "Gasqualitaet",
                "type": "Element",
            },
        )
        messlokation: Optional[str] = field(
            default=None,
            metadata={
                "name": "Messlokation",
                "type": "Element",
            },
        )
        marktgebiet: Optional[NetzanschlusspunktMarktgebiet] = field(
            default=None,
            metadata={
                "name": "Marktgebiet",
                "type": "Element",
            },
        )
        spannungsebene: Optional[NetzanschlusspunktSpannungsebene] = field(
            default=None,
            metadata={
                "name": "Spannungsebene",
                "type": "Element",
            },
        )
        regelzone_netzanschlusspunkt: Optional[
            NetzanschlusspunktRegelzoneNetzanschlusspunkt
        ] = field(
            default=None,
            metadata={
                "name": "RegelzoneNetzanschlusspunkt",
                "type": "Element",
            },
        )
        nettoengpassleistung: Optional[float] = field(
            default=None,
            metadata={
                "name": "Nettoengpassleistung",
                "type": "Element",
            },
        )
        bilanzierungsgebiet_netzanschlusspunkt_id: Optional[int] = field(
            default=None,
            metadata={
                "name": "BilanzierungsgebietNetzanschlusspunktId",
                "type": "Element",
            },
        )
        netzanschlusskapazitaet: Optional[float] = field(
            default=None,
            metadata={
                "name": "Netzanschlusskapazitaet",
                "type": "Element",
            },
        )
        netz_ma_st_rnummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "NetzMaStRNummer",
                "type": "Element",
                "required": True,
            },
        )
        noch_in_planung: Optional[NetzanschlusspunktNochInPlanung] = field(
            default=None,
            metadata={
                "name": "NochInPlanung",
                "type": "Element",
                "required": True,
            },
        )
        netzbetreiber_ma_st_rnummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "NetzbetreiberMaStRNummer",
                "type": "Element",
                "required": True,
            },
        )
