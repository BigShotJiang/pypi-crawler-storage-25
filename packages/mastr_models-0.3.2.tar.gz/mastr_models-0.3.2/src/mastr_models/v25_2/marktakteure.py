from dataclasses import dataclass, field
from enum import Enum

from xsdata.models.datatype import XmlDate, XmlDateTime


class MarktakteurAcerCodeNv(Enum):
    VALUE_1 = 1
    VALUE_0 = 0


class MarktakteurBelieferungHaushaltskundenGas(Enum):
    VALUE_1 = 1
    VALUE_0 = 0


class MarktakteurBelieferungHaushaltskundenStrom(Enum):
    VALUE_1 = 1
    VALUE_0 = 0


class MarktakteurBelieferungVonLetztverbrauchernGas(Enum):
    VALUE_1 = 1
    VALUE_0 = 0


class MarktakteurBelieferungVonLetztverbrauchernStrom(Enum):
    VALUE_1 = 1
    VALUE_0 = 0


class MarktakteurBundesland(Enum):
    VALUE_334 = 334
    VALUE_335 = 335
    VALUE_333 = 333
    VALUE_332 = 332
    VALUE_336 = 336
    VALUE_338 = 338
    VALUE_337 = 337
    VALUE_339 = 339
    VALUE_340 = 340
    VALUE_341 = 341
    VALUE_342 = 342
    VALUE_344 = 344
    VALUE_345 = 345
    VALUE_346 = 346
    VALUE_343 = 343
    VALUE_347 = 347


class MarktakteurDirektvermarktungsunternehmen(Enum):
    VALUE_1 = 1
    VALUE_0 = 0


class MarktakteurFaxNv(Enum):
    VALUE_1 = 1
    VALUE_0 = 0


class MarktakteurGasgrosshaendler(Enum):
    VALUE_1 = 1
    VALUE_0 = 0


class MarktakteurHauptwirtdschaftszweigAbschnitt(Enum):
    VALUE_1162 = 1162
    VALUE_1163 = 1163
    VALUE_1164 = 1164
    VALUE_1165 = 1165
    VALUE_1166 = 1166
    VALUE_1167 = 1167
    VALUE_1168 = 1168
    VALUE_1169 = 1169
    VALUE_1170 = 1170
    VALUE_1171 = 1171
    VALUE_1172 = 1172
    VALUE_1173 = 1173
    VALUE_1174 = 1174
    VALUE_1175 = 1175
    VALUE_1176 = 1176
    VALUE_1177 = 1177
    VALUE_1178 = 1178
    VALUE_1179 = 1179
    VALUE_1180 = 1180
    VALUE_1181 = 1181
    VALUE_1182 = 1182
    VALUE_3125 = 3125


class MarktakteurHauptwirtdschaftszweigAbteilung(Enum):
    VALUE_1183 = 1183
    VALUE_1184 = 1184
    VALUE_1185 = 1185
    VALUE_1186 = 1186
    VALUE_1187 = 1187
    VALUE_1188 = 1188
    VALUE_1189 = 1189
    VALUE_1190 = 1190
    VALUE_1191 = 1191
    VALUE_1192 = 1192
    VALUE_1193 = 1193
    VALUE_1194 = 1194
    VALUE_1195 = 1195
    VALUE_1196 = 1196
    VALUE_1197 = 1197
    VALUE_1198 = 1198
    VALUE_1199 = 1199
    VALUE_1200 = 1200
    VALUE_1201 = 1201
    VALUE_1202 = 1202
    VALUE_1203 = 1203
    VALUE_1204 = 1204
    VALUE_1205 = 1205
    VALUE_1206 = 1206
    VALUE_1207 = 1207
    VALUE_1208 = 1208
    VALUE_1209 = 1209
    VALUE_1210 = 1210
    VALUE_1211 = 1211
    VALUE_1212 = 1212
    VALUE_1213 = 1213
    VALUE_1214 = 1214
    VALUE_1215 = 1215
    VALUE_1216 = 1216
    VALUE_1217 = 1217
    VALUE_1218 = 1218
    VALUE_1219 = 1219
    VALUE_1220 = 1220
    VALUE_1221 = 1221
    VALUE_1222 = 1222
    VALUE_1223 = 1223
    VALUE_1224 = 1224
    VALUE_1225 = 1225
    VALUE_1226 = 1226
    VALUE_1227 = 1227
    VALUE_1228 = 1228
    VALUE_1229 = 1229
    VALUE_1230 = 1230
    VALUE_1231 = 1231
    VALUE_1232 = 1232
    VALUE_1233 = 1233
    VALUE_1234 = 1234
    VALUE_1235 = 1235
    VALUE_1236 = 1236
    VALUE_1237 = 1237
    VALUE_1238 = 1238
    VALUE_1239 = 1239
    VALUE_1240 = 1240
    VALUE_1241 = 1241
    VALUE_1242 = 1242
    VALUE_1243 = 1243
    VALUE_1244 = 1244
    VALUE_1245 = 1245
    VALUE_1246 = 1246
    VALUE_1247 = 1247
    VALUE_1248 = 1248
    VALUE_1249 = 1249
    VALUE_1250 = 1250
    VALUE_1251 = 1251
    VALUE_1252 = 1252
    VALUE_1253 = 1253
    VALUE_1254 = 1254
    VALUE_1255 = 1255
    VALUE_1256 = 1256
    VALUE_1257 = 1257
    VALUE_1258 = 1258
    VALUE_1259 = 1259
    VALUE_1260 = 1260
    VALUE_1261 = 1261
    VALUE_1262 = 1262
    VALUE_1263 = 1263
    VALUE_1264 = 1264
    VALUE_1265 = 1265
    VALUE_1266 = 1266
    VALUE_1267 = 1267
    VALUE_1268 = 1268
    VALUE_1269 = 1269
    VALUE_1270 = 1270


class MarktakteurHauptwirtdschaftszweigGruppe(Enum):
    VALUE_2568 = 2568
    VALUE_2569 = 2569
    VALUE_2570 = 2570
    VALUE_2571 = 2571
    VALUE_2572 = 2572
    VALUE_2573 = 2573
    VALUE_2574 = 2574
    VALUE_2575 = 2575
    VALUE_2576 = 2576
    VALUE_2577 = 2577
    VALUE_2578 = 2578
    VALUE_2579 = 2579
    VALUE_2580 = 2580
    VALUE_2581 = 2581
    VALUE_2582 = 2582
    VALUE_2583 = 2583
    VALUE_2584 = 2584
    VALUE_2585 = 2585
    VALUE_2586 = 2586
    VALUE_2587 = 2587
    VALUE_2588 = 2588
    VALUE_2589 = 2589
    VALUE_2590 = 2590
    VALUE_2591 = 2591
    VALUE_2592 = 2592
    VALUE_2593 = 2593
    VALUE_2594 = 2594
    VALUE_2595 = 2595
    VALUE_2596 = 2596
    VALUE_2597 = 2597
    VALUE_2598 = 2598
    VALUE_2599 = 2599
    VALUE_2600 = 2600
    VALUE_2601 = 2601
    VALUE_2602 = 2602
    VALUE_2603 = 2603
    VALUE_2604 = 2604
    VALUE_2605 = 2605
    VALUE_2606 = 2606
    VALUE_2607 = 2607
    VALUE_2608 = 2608
    VALUE_2609 = 2609
    VALUE_2610 = 2610
    VALUE_2611 = 2611
    VALUE_2612 = 2612
    VALUE_2613 = 2613
    VALUE_2614 = 2614
    VALUE_2615 = 2615
    VALUE_2616 = 2616
    VALUE_2617 = 2617
    VALUE_2618 = 2618
    VALUE_2619 = 2619
    VALUE_2620 = 2620
    VALUE_2621 = 2621
    VALUE_2622 = 2622
    VALUE_2623 = 2623
    VALUE_2624 = 2624
    VALUE_2625 = 2625
    VALUE_2626 = 2626
    VALUE_2627 = 2627
    VALUE_2628 = 2628
    VALUE_2629 = 2629
    VALUE_2630 = 2630
    VALUE_2631 = 2631
    VALUE_2632 = 2632
    VALUE_2633 = 2633
    VALUE_2634 = 2634
    VALUE_2635 = 2635
    VALUE_2636 = 2636
    VALUE_2637 = 2637
    VALUE_2638 = 2638
    VALUE_2639 = 2639
    VALUE_2640 = 2640
    VALUE_2641 = 2641
    VALUE_2642 = 2642
    VALUE_2643 = 2643
    VALUE_2644 = 2644
    VALUE_2645 = 2645
    VALUE_2646 = 2646
    VALUE_2647 = 2647
    VALUE_2648 = 2648
    VALUE_2649 = 2649
    VALUE_2650 = 2650
    VALUE_2651 = 2651
    VALUE_2652 = 2652
    VALUE_2653 = 2653
    VALUE_2654 = 2654
    VALUE_2655 = 2655
    VALUE_2656 = 2656
    VALUE_2657 = 2657
    VALUE_2658 = 2658
    VALUE_2659 = 2659
    VALUE_2660 = 2660
    VALUE_2661 = 2661
    VALUE_2662 = 2662
    VALUE_2663 = 2663
    VALUE_2664 = 2664
    VALUE_2665 = 2665
    VALUE_2666 = 2666
    VALUE_2667 = 2667
    VALUE_2668 = 2668
    VALUE_2669 = 2669
    VALUE_2670 = 2670
    VALUE_2671 = 2671
    VALUE_2672 = 2672
    VALUE_2673 = 2673
    VALUE_2674 = 2674
    VALUE_2675 = 2675
    VALUE_2676 = 2676
    VALUE_2677 = 2677
    VALUE_2678 = 2678
    VALUE_2679 = 2679
    VALUE_2680 = 2680
    VALUE_2681 = 2681
    VALUE_2682 = 2682
    VALUE_2683 = 2683
    VALUE_2684 = 2684
    VALUE_2685 = 2685
    VALUE_2686 = 2686
    VALUE_2687 = 2687
    VALUE_2688 = 2688
    VALUE_2689 = 2689
    VALUE_2690 = 2690
    VALUE_2691 = 2691
    VALUE_2692 = 2692
    VALUE_2693 = 2693
    VALUE_2694 = 2694
    VALUE_2695 = 2695
    VALUE_2696 = 2696
    VALUE_2697 = 2697
    VALUE_2698 = 2698
    VALUE_2699 = 2699
    VALUE_2700 = 2700
    VALUE_2701 = 2701
    VALUE_2702 = 2702
    VALUE_2703 = 2703
    VALUE_2704 = 2704
    VALUE_2705 = 2705
    VALUE_2706 = 2706
    VALUE_2707 = 2707
    VALUE_2708 = 2708
    VALUE_2709 = 2709
    VALUE_2710 = 2710
    VALUE_2711 = 2711
    VALUE_2712 = 2712
    VALUE_2713 = 2713
    VALUE_2714 = 2714
    VALUE_2715 = 2715
    VALUE_2716 = 2716
    VALUE_2717 = 2717
    VALUE_2718 = 2718
    VALUE_2719 = 2719
    VALUE_2720 = 2720
    VALUE_2721 = 2721
    VALUE_2722 = 2722
    VALUE_2723 = 2723
    VALUE_2724 = 2724
    VALUE_2725 = 2725
    VALUE_2726 = 2726
    VALUE_2727 = 2727
    VALUE_2728 = 2728
    VALUE_2729 = 2729
    VALUE_2730 = 2730
    VALUE_2731 = 2731
    VALUE_2732 = 2732
    VALUE_2733 = 2733
    VALUE_2734 = 2734
    VALUE_2735 = 2735
    VALUE_2736 = 2736
    VALUE_2737 = 2737
    VALUE_2738 = 2738
    VALUE_2739 = 2739
    VALUE_2740 = 2740
    VALUE_2741 = 2741
    VALUE_2742 = 2742
    VALUE_2743 = 2743
    VALUE_2744 = 2744
    VALUE_2745 = 2745
    VALUE_2746 = 2746
    VALUE_2747 = 2747
    VALUE_2748 = 2748
    VALUE_2749 = 2749
    VALUE_2750 = 2750
    VALUE_2751 = 2751
    VALUE_2752 = 2752
    VALUE_2753 = 2753
    VALUE_2754 = 2754
    VALUE_2755 = 2755
    VALUE_2756 = 2756
    VALUE_2757 = 2757
    VALUE_2758 = 2758
    VALUE_2759 = 2759
    VALUE_2760 = 2760
    VALUE_2761 = 2761
    VALUE_2762 = 2762
    VALUE_2763 = 2763
    VALUE_2764 = 2764
    VALUE_2765 = 2765
    VALUE_2766 = 2766
    VALUE_2767 = 2767
    VALUE_2768 = 2768
    VALUE_2769 = 2769
    VALUE_2770 = 2770
    VALUE_2771 = 2771
    VALUE_2772 = 2772
    VALUE_2773 = 2773
    VALUE_2774 = 2774
    VALUE_2775 = 2775
    VALUE_2776 = 2776
    VALUE_2777 = 2777
    VALUE_2778 = 2778
    VALUE_2779 = 2779
    VALUE_2780 = 2780
    VALUE_2781 = 2781
    VALUE_2782 = 2782
    VALUE_2783 = 2783
    VALUE_2784 = 2784
    VALUE_2785 = 2785
    VALUE_2786 = 2786
    VALUE_2787 = 2787
    VALUE_2788 = 2788
    VALUE_2789 = 2789
    VALUE_2790 = 2790
    VALUE_2791 = 2791
    VALUE_2792 = 2792
    VALUE_2793 = 2793
    VALUE_2794 = 2794
    VALUE_2795 = 2795
    VALUE_2796 = 2796
    VALUE_2797 = 2797
    VALUE_2798 = 2798
    VALUE_2799 = 2799
    VALUE_2800 = 2800
    VALUE_2801 = 2801
    VALUE_2802 = 2802
    VALUE_2803 = 2803
    VALUE_2804 = 2804
    VALUE_2805 = 2805
    VALUE_2806 = 2806
    VALUE_2807 = 2807
    VALUE_2808 = 2808
    VALUE_2809 = 2809
    VALUE_2810 = 2810
    VALUE_2811 = 2811
    VALUE_2812 = 2812
    VALUE_2813 = 2813
    VALUE_2814 = 2814
    VALUE_2815 = 2815
    VALUE_2816 = 2816
    VALUE_2817 = 2817
    VALUE_2818 = 2818
    VALUE_2819 = 2819
    VALUE_2820 = 2820
    VALUE_2821 = 2821
    VALUE_2822 = 2822
    VALUE_2823 = 2823
    VALUE_2824 = 2824
    VALUE_2825 = 2825
    VALUE_2826 = 2826
    VALUE_2827 = 2827
    VALUE_2828 = 2828
    VALUE_2829 = 2829
    VALUE_2830 = 2830
    VALUE_2831 = 2831
    VALUE_2832 = 2832
    VALUE_2833 = 2833
    VALUE_2834 = 2834
    VALUE_2836 = 2836
    VALUE_2837 = 2837
    VALUE_2838 = 2838
    VALUE_2839 = 2839
    VALUE_3126 = 3126
    VALUE_3127 = 3127
    VALUE_3128 = 3128
    VALUE_3129 = 3129
    VALUE_3130 = 3130
    VALUE_3131 = 3131
    VALUE_3132 = 3132
    VALUE_3133 = 3133
    VALUE_3134 = 3134
    VALUE_3135 = 3135
    VALUE_3136 = 3136
    VALUE_3137 = 3137
    VALUE_3138 = 3138
    VALUE_3139 = 3139
    VALUE_3140 = 3140
    VALUE_3141 = 3141
    VALUE_3142 = 3142
    VALUE_3143 = 3143
    VALUE_3144 = 3144
    VALUE_3145 = 3145
    VALUE_3146 = 3146
    VALUE_3147 = 3147
    VALUE_3148 = 3148
    VALUE_3149 = 3149
    VALUE_3150 = 3150
    VALUE_3151 = 3151
    VALUE_3152 = 3152
    VALUE_3153 = 3153
    VALUE_3154 = 3154
    VALUE_3155 = 3155
    VALUE_3156 = 3156
    VALUE_3157 = 3157
    VALUE_3158 = 3158
    VALUE_3159 = 3159
    VALUE_3160 = 3160


class MarktakteurHausnummerAnZustelladresseNv(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class MarktakteurHausnummerNv(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class MarktakteurKmu(Enum):
    VALUE_1 = 1
    VALUE_0 = 0


class MarktakteurLand(Enum):
    VALUE_42 = 42
    VALUE_43 = 43
    VALUE_44 = 44
    VALUE_45 = 45
    VALUE_46 = 46
    VALUE_47 = 47
    VALUE_48 = 48
    VALUE_49 = 49
    VALUE_50 = 50
    VALUE_51 = 51
    VALUE_52 = 52
    VALUE_53 = 53
    VALUE_54 = 54
    VALUE_55 = 55
    VALUE_56 = 56
    VALUE_57 = 57
    VALUE_58 = 58
    VALUE_59 = 59
    VALUE_60 = 60
    VALUE_61 = 61
    VALUE_62 = 62
    VALUE_63 = 63
    VALUE_64 = 64
    VALUE_65 = 65
    VALUE_66 = 66
    VALUE_67 = 67
    VALUE_68 = 68
    VALUE_69 = 69
    VALUE_70 = 70
    VALUE_71 = 71
    VALUE_72 = 72
    VALUE_73 = 73
    VALUE_74 = 74
    VALUE_75 = 75
    VALUE_76 = 76
    VALUE_77 = 77
    VALUE_78 = 78
    VALUE_79 = 79
    VALUE_80 = 80
    VALUE_81 = 81
    VALUE_82 = 82
    VALUE_83 = 83
    VALUE_84 = 84
    VALUE_85 = 85
    VALUE_86 = 86
    VALUE_87 = 87
    VALUE_88 = 88
    VALUE_89 = 89
    VALUE_90 = 90
    VALUE_91 = 91
    VALUE_92 = 92
    VALUE_93 = 93
    VALUE_94 = 94
    VALUE_95 = 95
    VALUE_96 = 96
    VALUE_97 = 97
    VALUE_98 = 98
    VALUE_99 = 99
    VALUE_100 = 100
    VALUE_101 = 101
    VALUE_102 = 102
    VALUE_103 = 103
    VALUE_104 = 104
    VALUE_105 = 105
    VALUE_106 = 106
    VALUE_107 = 107
    VALUE_108 = 108
    VALUE_109 = 109
    VALUE_110 = 110
    VALUE_111 = 111
    VALUE_112 = 112
    VALUE_113 = 113
    VALUE_114 = 114
    VALUE_115 = 115
    VALUE_116 = 116
    VALUE_117 = 117
    VALUE_118 = 118
    VALUE_119 = 119
    VALUE_120 = 120
    VALUE_121 = 121
    VALUE_122 = 122
    VALUE_123 = 123
    VALUE_124 = 124
    VALUE_125 = 125
    VALUE_126 = 126
    VALUE_127 = 127
    VALUE_128 = 128
    VALUE_129 = 129
    VALUE_130 = 130
    VALUE_131 = 131
    VALUE_132 = 132
    VALUE_133 = 133
    VALUE_134 = 134
    VALUE_135 = 135
    VALUE_136 = 136
    VALUE_137 = 137
    VALUE_138 = 138
    VALUE_139 = 139
    VALUE_140 = 140
    VALUE_141 = 141
    VALUE_142 = 142
    VALUE_143 = 143
    VALUE_144 = 144
    VALUE_145 = 145
    VALUE_146 = 146
    VALUE_147 = 147
    VALUE_148 = 148
    VALUE_149 = 149
    VALUE_150 = 150
    VALUE_151 = 151
    VALUE_152 = 152
    VALUE_153 = 153
    VALUE_154 = 154
    VALUE_155 = 155
    VALUE_156 = 156
    VALUE_157 = 157
    VALUE_158 = 158
    VALUE_159 = 159
    VALUE_160 = 160
    VALUE_161 = 161
    VALUE_162 = 162
    VALUE_163 = 163
    VALUE_164 = 164
    VALUE_165 = 165
    VALUE_166 = 166
    VALUE_167 = 167
    VALUE_168 = 168
    VALUE_169 = 169
    VALUE_170 = 170
    VALUE_171 = 171
    VALUE_172 = 172
    VALUE_173 = 173
    VALUE_174 = 174
    VALUE_175 = 175
    VALUE_176 = 176
    VALUE_177 = 177
    VALUE_178 = 178
    VALUE_179 = 179
    VALUE_180 = 180
    VALUE_181 = 181
    VALUE_182 = 182
    VALUE_183 = 183
    VALUE_184 = 184
    VALUE_185 = 185
    VALUE_186 = 186
    VALUE_187 = 187
    VALUE_188 = 188
    VALUE_189 = 189
    VALUE_190 = 190
    VALUE_191 = 191
    VALUE_192 = 192
    VALUE_193 = 193
    VALUE_194 = 194
    VALUE_195 = 195
    VALUE_196 = 196
    VALUE_197 = 197
    VALUE_198 = 198
    VALUE_199 = 199
    VALUE_200 = 200
    VALUE_201 = 201
    VALUE_202 = 202
    VALUE_203 = 203
    VALUE_204 = 204
    VALUE_205 = 205
    VALUE_206 = 206
    VALUE_207 = 207
    VALUE_208 = 208
    VALUE_209 = 209
    VALUE_210 = 210
    VALUE_211 = 211
    VALUE_212 = 212
    VALUE_213 = 213
    VALUE_214 = 214
    VALUE_215 = 215
    VALUE_216 = 216
    VALUE_217 = 217
    VALUE_218 = 218
    VALUE_219 = 219
    VALUE_220 = 220
    VALUE_221 = 221
    VALUE_222 = 222
    VALUE_223 = 223
    VALUE_224 = 224
    VALUE_225 = 225
    VALUE_226 = 226
    VALUE_227 = 227
    VALUE_228 = 228
    VALUE_229 = 229
    VALUE_230 = 230
    VALUE_231 = 231
    VALUE_232 = 232
    VALUE_233 = 233
    VALUE_234 = 234
    VALUE_235 = 235
    VALUE_236 = 236
    VALUE_237 = 237
    VALUE_238 = 238
    VALUE_239 = 239
    VALUE_240 = 240
    VALUE_241 = 241
    VALUE_242 = 242
    VALUE_243 = 243
    VALUE_244 = 244
    VALUE_245 = 245
    VALUE_246 = 246
    VALUE_247 = 247
    VALUE_248 = 248
    VALUE_249 = 249
    VALUE_250 = 250
    VALUE_251 = 251
    VALUE_252 = 252
    VALUE_253 = 253
    VALUE_254 = 254
    VALUE_255 = 255
    VALUE_256 = 256
    VALUE_257 = 257
    VALUE_258 = 258
    VALUE_259 = 259
    VALUE_260 = 260
    VALUE_261 = 261
    VALUE_262 = 262
    VALUE_263 = 263
    VALUE_264 = 264
    VALUE_265 = 265
    VALUE_266 = 266
    VALUE_267 = 267
    VALUE_268 = 268
    VALUE_269 = 269
    VALUE_270 = 270
    VALUE_271 = 271
    VALUE_272 = 272
    VALUE_273 = 273
    VALUE_274 = 274
    VALUE_275 = 275
    VALUE_276 = 276
    VALUE_277 = 277
    VALUE_278 = 278
    VALUE_279 = 279
    VALUE_1273 = 1273
    VALUE_1274 = 1274
    VALUE_1275 = 1275
    VALUE_1276 = 1276
    VALUE_1277 = 1277
    VALUE_1278 = 1278
    VALUE_1279 = 1279
    VALUE_1280 = 1280
    VALUE_1281 = 1281
    VALUE_1282 = 1282
    VALUE_1283 = 1283
    VALUE_1284 = 1284


class MarktakteurLandAnZustelladresse(Enum):
    VALUE_42 = 42
    VALUE_43 = 43
    VALUE_44 = 44
    VALUE_45 = 45
    VALUE_46 = 46
    VALUE_47 = 47
    VALUE_48 = 48
    VALUE_49 = 49
    VALUE_50 = 50
    VALUE_51 = 51
    VALUE_52 = 52
    VALUE_53 = 53
    VALUE_54 = 54
    VALUE_55 = 55
    VALUE_56 = 56
    VALUE_57 = 57
    VALUE_58 = 58
    VALUE_59 = 59
    VALUE_60 = 60
    VALUE_61 = 61
    VALUE_62 = 62
    VALUE_63 = 63
    VALUE_64 = 64
    VALUE_65 = 65
    VALUE_66 = 66
    VALUE_67 = 67
    VALUE_68 = 68
    VALUE_69 = 69
    VALUE_70 = 70
    VALUE_71 = 71
    VALUE_72 = 72
    VALUE_73 = 73
    VALUE_74 = 74
    VALUE_75 = 75
    VALUE_76 = 76
    VALUE_77 = 77
    VALUE_78 = 78
    VALUE_79 = 79
    VALUE_80 = 80
    VALUE_81 = 81
    VALUE_82 = 82
    VALUE_83 = 83
    VALUE_84 = 84
    VALUE_85 = 85
    VALUE_86 = 86
    VALUE_87 = 87
    VALUE_88 = 88
    VALUE_89 = 89
    VALUE_90 = 90
    VALUE_91 = 91
    VALUE_92 = 92
    VALUE_93 = 93
    VALUE_94 = 94
    VALUE_95 = 95
    VALUE_96 = 96
    VALUE_97 = 97
    VALUE_98 = 98
    VALUE_99 = 99
    VALUE_100 = 100
    VALUE_101 = 101
    VALUE_102 = 102
    VALUE_103 = 103
    VALUE_104 = 104
    VALUE_105 = 105
    VALUE_106 = 106
    VALUE_107 = 107
    VALUE_108 = 108
    VALUE_109 = 109
    VALUE_110 = 110
    VALUE_111 = 111
    VALUE_112 = 112
    VALUE_113 = 113
    VALUE_114 = 114
    VALUE_115 = 115
    VALUE_116 = 116
    VALUE_117 = 117
    VALUE_118 = 118
    VALUE_119 = 119
    VALUE_120 = 120
    VALUE_121 = 121
    VALUE_122 = 122
    VALUE_123 = 123
    VALUE_124 = 124
    VALUE_125 = 125
    VALUE_126 = 126
    VALUE_127 = 127
    VALUE_128 = 128
    VALUE_129 = 129
    VALUE_130 = 130
    VALUE_131 = 131
    VALUE_132 = 132
    VALUE_133 = 133
    VALUE_134 = 134
    VALUE_135 = 135
    VALUE_136 = 136
    VALUE_137 = 137
    VALUE_138 = 138
    VALUE_139 = 139
    VALUE_140 = 140
    VALUE_141 = 141
    VALUE_142 = 142
    VALUE_143 = 143
    VALUE_144 = 144
    VALUE_145 = 145
    VALUE_146 = 146
    VALUE_147 = 147
    VALUE_148 = 148
    VALUE_149 = 149
    VALUE_150 = 150
    VALUE_151 = 151
    VALUE_152 = 152
    VALUE_153 = 153
    VALUE_154 = 154
    VALUE_155 = 155
    VALUE_156 = 156
    VALUE_157 = 157
    VALUE_158 = 158
    VALUE_159 = 159
    VALUE_160 = 160
    VALUE_161 = 161
    VALUE_162 = 162
    VALUE_163 = 163
    VALUE_164 = 164
    VALUE_165 = 165
    VALUE_166 = 166
    VALUE_167 = 167
    VALUE_168 = 168
    VALUE_169 = 169
    VALUE_170 = 170
    VALUE_171 = 171
    VALUE_172 = 172
    VALUE_173 = 173
    VALUE_174 = 174
    VALUE_175 = 175
    VALUE_176 = 176
    VALUE_177 = 177
    VALUE_178 = 178
    VALUE_179 = 179
    VALUE_180 = 180
    VALUE_181 = 181
    VALUE_182 = 182
    VALUE_183 = 183
    VALUE_184 = 184
    VALUE_185 = 185
    VALUE_186 = 186
    VALUE_187 = 187
    VALUE_188 = 188
    VALUE_189 = 189
    VALUE_190 = 190
    VALUE_191 = 191
    VALUE_192 = 192
    VALUE_193 = 193
    VALUE_194 = 194
    VALUE_195 = 195
    VALUE_196 = 196
    VALUE_197 = 197
    VALUE_198 = 198
    VALUE_199 = 199
    VALUE_200 = 200
    VALUE_201 = 201
    VALUE_202 = 202
    VALUE_203 = 203
    VALUE_204 = 204
    VALUE_205 = 205
    VALUE_206 = 206
    VALUE_207 = 207
    VALUE_208 = 208
    VALUE_209 = 209
    VALUE_210 = 210
    VALUE_211 = 211
    VALUE_212 = 212
    VALUE_213 = 213
    VALUE_214 = 214
    VALUE_215 = 215
    VALUE_216 = 216
    VALUE_217 = 217
    VALUE_218 = 218
    VALUE_219 = 219
    VALUE_220 = 220
    VALUE_221 = 221
    VALUE_222 = 222
    VALUE_223 = 223
    VALUE_224 = 224
    VALUE_225 = 225
    VALUE_226 = 226
    VALUE_227 = 227
    VALUE_228 = 228
    VALUE_229 = 229
    VALUE_230 = 230
    VALUE_231 = 231
    VALUE_232 = 232
    VALUE_233 = 233
    VALUE_234 = 234
    VALUE_235 = 235
    VALUE_236 = 236
    VALUE_237 = 237
    VALUE_238 = 238
    VALUE_239 = 239
    VALUE_240 = 240
    VALUE_241 = 241
    VALUE_242 = 242
    VALUE_243 = 243
    VALUE_244 = 244
    VALUE_245 = 245
    VALUE_246 = 246
    VALUE_247 = 247
    VALUE_248 = 248
    VALUE_249 = 249
    VALUE_250 = 250
    VALUE_251 = 251
    VALUE_252 = 252
    VALUE_253 = 253
    VALUE_254 = 254
    VALUE_255 = 255
    VALUE_256 = 256
    VALUE_257 = 257
    VALUE_258 = 258
    VALUE_259 = 259
    VALUE_260 = 260
    VALUE_261 = 261
    VALUE_262 = 262
    VALUE_263 = 263
    VALUE_264 = 264
    VALUE_265 = 265
    VALUE_266 = 266
    VALUE_267 = 267
    VALUE_268 = 268
    VALUE_269 = 269
    VALUE_270 = 270
    VALUE_271 = 271
    VALUE_272 = 272
    VALUE_273 = 273
    VALUE_274 = 274
    VALUE_275 = 275
    VALUE_276 = 276
    VALUE_277 = 277
    VALUE_278 = 278
    VALUE_279 = 279
    VALUE_1273 = 1273
    VALUE_1274 = 1274
    VALUE_1275 = 1275
    VALUE_1276 = 1276
    VALUE_1277 = 1277
    VALUE_1278 = 1278
    VALUE_1279 = 1279
    VALUE_1280 = 1280
    VALUE_1281 = 1281
    VALUE_1282 = 1282
    VALUE_1283 = 1283
    VALUE_1284 = 1284


class MarktakteurMarktakteurAnrede(Enum):
    VALUE_280 = 280
    VALUE_281 = 281
    VALUE_282 = 282
    VALUE_2966 = 2966
    VALUE_2982 = 2982
    VALUE_2983 = 2983
    VALUE_2984 = 2984


class MarktakteurMarktakteurTitel(Enum):
    VALUE_1000 = 1000
    VALUE_1001 = 1001
    VALUE_1002 = 1002


class MarktakteurMarktfunktion(Enum):
    VALUE_1 = 1
    VALUE_2 = 2
    VALUE_3 = 3
    VALUE_4 = 4
    VALUE_5 = 5
    VALUE_6 = 6
    VALUE_7 = 7
    VALUE_8 = 8
    VALUE_9 = 9
    VALUE_10 = 10


class MarktakteurPersonenart(Enum):
    VALUE_518 = 518
    VALUE_517 = 517


class MarktakteurRegisternummerPraefix(Enum):
    VALUE_1003 = 1003
    VALUE_1004 = 1004
    VALUE_1005 = 1005
    VALUE_1006 = 1006
    VALUE_1007 = 1007
    VALUE_3101 = 3101


class MarktakteurStromgrosshaendler(Enum):
    VALUE_1 = 1
    VALUE_0 = 0


class MarktakteurUmsatzsteueridentifikationsnummerNv(Enum):
    VALUE_1 = 1
    VALUE_0 = 0


class MarktakteurWebseiteNv(Enum):
    VALUE_1 = 1
    VALUE_0 = 0


@dataclass
class Marktakteure:
    marktakteur: list["Marktakteure.Marktakteur"] = field(
        default_factory=list,
        metadata={
            "name": "Marktakteur",
            "type": "Element",
        },
    )

    @dataclass
    class Marktakteur:
        mastr_nummer: list[str] = field(
            default_factory=list,
            metadata={
                "name": "MastrNummer",
                "type": "Element",
            },
        )
        datum_letze_aktualisierung: list[XmlDateTime] = field(
            default_factory=list,
            metadata={
                "name": "DatumLetzeAktualisierung",
                "type": "Element",
            },
        )
        personenart: list[MarktakteurPersonenart] = field(
            default_factory=list,
            metadata={
                "name": "Personenart",
                "type": "Element",
            },
        )
        marktakteur_anrede: list[MarktakteurMarktakteurAnrede] = field(
            default_factory=list,
            metadata={
                "name": "MarktakteurAnrede",
                "type": "Element",
            },
        )
        marktakteur_titel: list[MarktakteurMarktakteurTitel] = field(
            default_factory=list,
            metadata={
                "name": "MarktakteurTitel",
                "type": "Element",
            },
        )
        marktakteur_vorname: list[str] = field(
            default_factory=list,
            metadata={
                "name": "MarktakteurVorname",
                "type": "Element",
            },
        )
        marktakteur_nachname: list[str] = field(
            default_factory=list,
            metadata={
                "name": "MarktakteurNachname",
                "type": "Element",
            },
        )
        firmenname: list[str] = field(
            default_factory=list,
            metadata={
                "name": "Firmenname",
                "type": "Element",
            },
        )
        marktfunktion: list[MarktakteurMarktfunktion] = field(
            default_factory=list,
            metadata={
                "name": "Marktfunktion",
                "type": "Element",
            },
        )
        rechtsform: list[int] = field(
            default_factory=list,
            metadata={
                "name": "Rechtsform",
                "type": "Element",
            },
        )
        sonstige_rechtsform: list[str] = field(
            default_factory=list,
            metadata={
                "name": "SonstigeRechtsform",
                "type": "Element",
            },
        )
        marktrollen: list[str] = field(
            default_factory=list,
            metadata={
                "name": "Marktrollen",
                "type": "Element",
            },
        )
        land: list[MarktakteurLand] = field(
            default_factory=list,
            metadata={
                "name": "Land",
                "type": "Element",
            },
        )
        region: list[str] = field(
            default_factory=list,
            metadata={
                "name": "Region",
                "type": "Element",
            },
        )
        strasse: list[str] = field(
            default_factory=list,
            metadata={
                "name": "Strasse",
                "type": "Element",
            },
        )
        hausnummer: list[str] = field(
            default_factory=list,
            metadata={
                "name": "Hausnummer",
                "type": "Element",
            },
        )
        hausnummer_nv: list[MarktakteurHausnummerNv] = field(
            default_factory=list,
            metadata={
                "name": "Hausnummer_nv",
                "type": "Element",
            },
        )
        adresszusatz: list[str] = field(
            default_factory=list,
            metadata={
                "name": "Adresszusatz",
                "type": "Element",
            },
        )
        postleitzahl: list[str] = field(
            default_factory=list,
            metadata={
                "name": "Postleitzahl",
                "type": "Element",
            },
        )
        ort: list[str] = field(
            default_factory=list,
            metadata={
                "name": "Ort",
                "type": "Element",
            },
        )
        bundesland: list[MarktakteurBundesland] = field(
            default_factory=list,
            metadata={
                "name": "Bundesland",
                "type": "Element",
            },
        )
        netz: list[str] = field(
            default_factory=list,
            metadata={
                "name": "Netz",
                "type": "Element",
            },
        )
        nuts2: list[str] = field(
            default_factory=list,
            metadata={
                "name": "Nuts2",
                "type": "Element",
            },
        )
        email: list[str] = field(
            default_factory=list,
            metadata={
                "name": "Email",
                "type": "Element",
            },
        )
        telefon: list[str] = field(
            default_factory=list,
            metadata={
                "name": "Telefon",
                "type": "Element",
            },
        )
        fax: list[str] = field(
            default_factory=list,
            metadata={
                "name": "Fax",
                "type": "Element",
            },
        )
        fax_nv: list[MarktakteurFaxNv] = field(
            default_factory=list,
            metadata={
                "name": "Fax_nv",
                "type": "Element",
            },
        )
        webseite: list[str] = field(
            default_factory=list,
            metadata={
                "name": "Webseite",
                "type": "Element",
            },
        )
        webseite_nv: list[MarktakteurWebseiteNv] = field(
            default_factory=list,
            metadata={
                "name": "Webseite_nv",
                "type": "Element",
            },
        )
        registergericht: list[int] = field(
            default_factory=list,
            metadata={
                "name": "Registergericht",
                "type": "Element",
            },
        )
        registergericht_ausland: list[str] = field(
            default_factory=list,
            metadata={
                "name": "RegistergerichtAusland",
                "type": "Element",
            },
        )
        registernummer_praefix: list[MarktakteurRegisternummerPraefix] = field(
            default_factory=list,
            metadata={
                "name": "RegisternummerPraefix",
                "type": "Element",
            },
        )
        registernummer: list[str] = field(
            default_factory=list,
            metadata={
                "name": "Registernummer",
                "type": "Element",
            },
        )
        registernummer_ausland: list[str] = field(
            default_factory=list,
            metadata={
                "name": "RegisternummerAusland",
                "type": "Element",
            },
        )
        taetigkeitsbeginn: list[XmlDate] = field(
            default_factory=list,
            metadata={
                "name": "Taetigkeitsbeginn",
                "type": "Element",
            },
        )
        acer_code: list[str] = field(
            default_factory=list,
            metadata={
                "name": "AcerCode",
                "type": "Element",
            },
        )
        acer_code_nv: list[MarktakteurAcerCodeNv] = field(
            default_factory=list,
            metadata={
                "name": "AcerCode_nv",
                "type": "Element",
            },
        )
        umsatzsteueridentifikationsnummer: list[str] = field(
            default_factory=list,
            metadata={
                "name": "Umsatzsteueridentifikationsnummer",
                "type": "Element",
            },
        )
        umsatzsteueridentifikationsnummer_nv: list[
            MarktakteurUmsatzsteueridentifikationsnummerNv
        ] = field(
            default_factory=list,
            metadata={
                "name": "Umsatzsteueridentifikationsnummer_nv",
                "type": "Element",
            },
        )
        taetigkeitsende: list[XmlDate] = field(
            default_factory=list,
            metadata={
                "name": "Taetigkeitsende",
                "type": "Element",
            },
        )
        bundesnetzagentur_betriebsnummer: list[str] = field(
            default_factory=list,
            metadata={
                "name": "BundesnetzagenturBetriebsnummer",
                "type": "Element",
            },
        )
        bundesnetzagentur_betriebsnummer_nv: list[int] = field(
            default_factory=list,
            metadata={
                "name": "BundesnetzagenturBetriebsnummer_nv",
                "type": "Element",
            },
        )
        land_an_zustelladresse: list[MarktakteurLandAnZustelladresse] = field(
            default_factory=list,
            metadata={
                "name": "LandAnZustelladresse",
                "type": "Element",
            },
        )
        postleitzahl_an_zustelladresse: list[str] = field(
            default_factory=list,
            metadata={
                "name": "PostleitzahlAnZustelladresse",
                "type": "Element",
            },
        )
        ort_an_zustelladresse: list[str] = field(
            default_factory=list,
            metadata={
                "name": "OrtAnZustelladresse",
                "type": "Element",
            },
        )
        strasse_an_zustelladresse: list[str] = field(
            default_factory=list,
            metadata={
                "name": "StrasseAnZustelladresse",
                "type": "Element",
            },
        )
        hausnummer_an_zustelladresse: list[str] = field(
            default_factory=list,
            metadata={
                "name": "HausnummerAnZustelladresse",
                "type": "Element",
            },
        )
        hausnummer_an_zustelladresse_nv: list[
            MarktakteurHausnummerAnZustelladresseNv
        ] = field(
            default_factory=list,
            metadata={
                "name": "HausnummerAnZustelladresse_nv",
                "type": "Element",
            },
        )
        adresszusatz_an_zustelladresse: list[str] = field(
            default_factory=list,
            metadata={
                "name": "AdresszusatzAnZustelladresse",
                "type": "Element",
            },
        )
        kmu: list[MarktakteurKmu] = field(
            default_factory=list,
            metadata={
                "name": "Kmu",
                "type": "Element",
            },
        )
        registrierungsdatum_marktakteur: list[XmlDateTime] = field(
            default_factory=list,
            metadata={
                "name": "RegistrierungsdatumMarktakteur",
                "type": "Element",
            },
        )
        hauptwirtdschaftszweig_abteilung: list[
            MarktakteurHauptwirtdschaftszweigAbteilung
        ] = field(
            default_factory=list,
            metadata={
                "name": "HauptwirtdschaftszweigAbteilung",
                "type": "Element",
            },
        )
        hauptwirtdschaftszweig_gruppe: list[MarktakteurHauptwirtdschaftszweigGruppe] = (
            field(
                default_factory=list,
                metadata={
                    "name": "HauptwirtdschaftszweigGruppe",
                    "type": "Element",
                },
            )
        )
        hauptwirtdschaftszweig_abschnitt: list[
            MarktakteurHauptwirtdschaftszweigAbschnitt
        ] = field(
            default_factory=list,
            metadata={
                "name": "HauptwirtdschaftszweigAbschnitt",
                "type": "Element",
            },
        )
        direktvermarktungsunternehmen: list[
            MarktakteurDirektvermarktungsunternehmen
        ] = field(
            default_factory=list,
            metadata={
                "name": "Direktvermarktungsunternehmen",
                "type": "Element",
            },
        )
        belieferung_von_letztverbrauchern_strom: list[
            MarktakteurBelieferungVonLetztverbrauchernStrom
        ] = field(
            default_factory=list,
            metadata={
                "name": "BelieferungVonLetztverbrauchernStrom",
                "type": "Element",
            },
        )
        belieferung_haushaltskunden_strom: list[
            MarktakteurBelieferungHaushaltskundenStrom
        ] = field(
            default_factory=list,
            metadata={
                "name": "BelieferungHaushaltskundenStrom",
                "type": "Element",
            },
        )
        gasgrosshaendler: list[MarktakteurGasgrosshaendler] = field(
            default_factory=list,
            metadata={
                "name": "Gasgrosshaendler",
                "type": "Element",
            },
        )
        stromgrosshaendler: list[MarktakteurStromgrosshaendler] = field(
            default_factory=list,
            metadata={
                "name": "Stromgrosshaendler",
                "type": "Element",
            },
        )
        belieferung_von_letztverbrauchern_gas: list[
            MarktakteurBelieferungVonLetztverbrauchernGas
        ] = field(
            default_factory=list,
            metadata={
                "name": "BelieferungVonLetztverbrauchernGas",
                "type": "Element",
            },
        )
        belieferung_haushaltskunden_gas: list[
            MarktakteurBelieferungHaushaltskundenGas
        ] = field(
            default_factory=list,
            metadata={
                "name": "BelieferungHaushaltskundenGas",
                "type": "Element",
            },
        )
        webportal_des_netzbetreibers: list[str] = field(
            default_factory=list,
            metadata={
                "name": "WebportalDesNetzbetreibers",
                "type": "Element",
            },
        )
