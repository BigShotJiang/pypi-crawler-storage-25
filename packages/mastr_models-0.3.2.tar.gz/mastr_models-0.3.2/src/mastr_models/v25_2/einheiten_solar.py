from dataclasses import dataclass, field
from enum import Enum

from xsdata.models.datatype import XmlDate, XmlDateTime


class EinheitSolarAnschlussAnHoechstOderHochSpannung(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitSolarArtDerSolaranlage(Enum):
    VALUE_853 = 853
    VALUE_2961 = 2961
    VALUE_2484 = 2484
    VALUE_852 = 852
    VALUE_3002 = 3002


class EinheitSolarBuergerenergie(Enum):
    VALUE_1 = 1
    VALUE_0 = 0


class EinheitSolarBundesland(Enum):
    VALUE_1416 = 1416
    VALUE_1402 = 1402
    VALUE_1403 = 1403
    VALUE_1401 = 1401
    VALUE_1400 = 1400
    VALUE_1404 = 1404
    VALUE_1406 = 1406
    VALUE_1405 = 1405
    VALUE_1407 = 1407
    VALUE_1408 = 1408
    VALUE_1409 = 1409
    VALUE_1410 = 1410
    VALUE_1412 = 1412
    VALUE_1413 = 1413
    VALUE_1414 = 1414
    VALUE_1411 = 1411
    VALUE_1415 = 1415


class EinheitSolarEinheitBetriebsstatus(Enum):
    VALUE_35 = 35
    VALUE_31 = 31
    VALUE_38 = 38
    VALUE_37 = 37


class EinheitSolarEinheitSystemstatus(Enum):
    VALUE_472 = 472
    VALUE_473 = 473
    VALUE_484 = 484
    VALUE_490 = 490
    VALUE_572 = 572


class EinheitSolarEinheitlicheAusrichtungUndNeigungswinkel(Enum):
    VALUE_1 = 1
    VALUE_0 = 0


class EinheitSolarEinspeisungsart(Enum):
    VALUE_689 = 689
    VALUE_688 = 688


class EinheitSolarEnergietraeger(Enum):
    VALUE_2411 = 2411
    VALUE_2493 = 2493
    VALUE_2408 = 2408
    VALUE_2410 = 2410
    VALUE_2494 = 2494
    VALUE_2409 = 2409
    VALUE_2412 = 2412
    VALUE_2407 = 2407
    VALUE_2413 = 2413
    VALUE_2403 = 2403
    VALUE_2404 = 2404
    VALUE_2405 = 2405
    VALUE_2495 = 2495
    VALUE_2406 = 2406
    VALUE_2957 = 2957
    VALUE_2958 = 2958
    VALUE_2496 = 2496
    VALUE_2498 = 2498
    VALUE_2497 = 2497


class EinheitSolarFernsteuerbarkeitDv(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitSolarFernsteuerbarkeitNb(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitSolarHauptausrichtung(Enum):
    VALUE_702 = 702
    VALUE_699 = 699
    VALUE_698 = 698
    VALUE_700 = 700
    VALUE_704 = 704
    VALUE_695 = 695
    VALUE_696 = 696
    VALUE_703 = 703
    VALUE_701 = 701
    VALUE_697 = 697


class EinheitSolarHauptausrichtungNeigungswinkel(Enum):
    VALUE_810 = 810
    VALUE_808 = 808
    VALUE_809 = 809
    VALUE_806 = 806
    VALUE_811 = 811
    VALUE_807 = 807


class EinheitSolarHausnummerNichtGefunden(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitSolarHausnummerNv(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitSolarKraftwerksnummerNv(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitSolarLand(Enum):
    VALUE_84 = 84
    VALUE_90 = 90
    VALUE_198 = 198
    VALUE_66 = 66
    VALUE_169 = 169
    VALUE_106 = 106
    VALUE_231 = 231
    VALUE_206 = 206
    VALUE_215 = 215
    VALUE_269 = 269


class EinheitSolarLeistungsbegrenzung(Enum):
    VALUE_803 = 803
    VALUE_802 = 802
    VALUE_1535 = 1535
    VALUE_804 = 804
    VALUE_805 = 805


class EinheitSolarNebenausrichtung(Enum):
    VALUE_700 = 700
    VALUE_701 = 701
    VALUE_696 = 696
    VALUE_704 = 704
    VALUE_703 = 703
    VALUE_697 = 697
    VALUE_702 = 702
    VALUE_699 = 699
    VALUE_698 = 698
    VALUE_695 = 695


class EinheitSolarNebenausrichtungNeigungswinkel(Enum):
    VALUE_809 = 809
    VALUE_808 = 808
    VALUE_811 = 811
    VALUE_810 = 810
    VALUE_806 = 806
    VALUE_807 = 807


class EinheitSolarNetzbetreiberpruefungStatus(Enum):
    VALUE_2954 = 2954
    VALUE_2955 = 2955
    VALUE_3075 = 3075


class EinheitSolarNichtVorhandenInMigriertenEinheiten(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitSolarNutzungsbereich(Enum):
    VALUE_713 = 713
    VALUE_716 = 716
    VALUE_718 = 718
    VALUE_714 = 714
    VALUE_715 = 715
    VALUE_717 = 717


class EinheitSolarSpeicherAmGleichenOrt(Enum):
    VALUE_1 = 1
    VALUE_0 = 0


class EinheitSolarStrasseNichtGefunden(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class EinheitSolarWeicNv(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


@dataclass
class EinheitenSolar:
    einheit_solar: list["EinheitenSolar.EinheitSolar"] = field(
        default_factory=list,
        metadata={
            "name": "EinheitSolar",
            "type": "Element",
        },
    )

    @dataclass
    class EinheitSolar:
        einheit_mastr_nummer: list[str] = field(
            default_factory=list,
            metadata={
                "name": "EinheitMastrNummer",
                "type": "Element",
            },
        )
        datum_letzte_aktualisierung: list[XmlDateTime] = field(
            default_factory=list,
            metadata={
                "name": "DatumLetzteAktualisierung",
                "type": "Element",
            },
        )
        lokation_ma_st_rnummer: list[str] = field(
            default_factory=list,
            metadata={
                "name": "LokationMaStRNummer",
                "type": "Element",
            },
        )
        netzbetreiberpruefung_status: list[
            EinheitSolarNetzbetreiberpruefungStatus
        ] = field(
            default_factory=list,
            metadata={
                "name": "NetzbetreiberpruefungStatus",
                "type": "Element",
            },
        )
        netzbetreiberpruefung_datum: list[XmlDate] = field(
            default_factory=list,
            metadata={
                "name": "NetzbetreiberpruefungDatum",
                "type": "Element",
            },
        )
        anlagenbetreiber_mastr_nummer: list[str] = field(
            default_factory=list,
            metadata={
                "name": "AnlagenbetreiberMastrNummer",
                "type": "Element",
            },
        )
        land: list[EinheitSolarLand] = field(
            default_factory=list,
            metadata={
                "name": "Land",
                "type": "Element",
            },
        )
        bundesland: list[EinheitSolarBundesland] = field(
            default_factory=list,
            metadata={
                "name": "Bundesland",
                "type": "Element",
            },
        )
        landkreis: list[str] = field(
            default_factory=list,
            metadata={
                "name": "Landkreis",
                "type": "Element",
            },
        )
        gemeinde: list[str] = field(
            default_factory=list,
            metadata={
                "name": "Gemeinde",
                "type": "Element",
            },
        )
        gemeindeschluessel: list[str] = field(
            default_factory=list,
            metadata={
                "name": "Gemeindeschluessel",
                "type": "Element",
            },
        )
        postleitzahl: list[str] = field(
            default_factory=list,
            metadata={
                "name": "Postleitzahl",
                "type": "Element",
            },
        )
        strasse: list[str] = field(
            default_factory=list,
            metadata={
                "name": "Strasse",
                "type": "Element",
            },
        )
        gemarkung: list[str] = field(
            default_factory=list,
            metadata={
                "name": "Gemarkung",
                "type": "Element",
            },
        )
        flur_flurstuecknummern: list[str] = field(
            default_factory=list,
            metadata={
                "name": "FlurFlurstuecknummern",
                "type": "Element",
            },
        )
        strasse_nicht_gefunden: list[EinheitSolarStrasseNichtGefunden] = field(
            default_factory=list,
            metadata={
                "name": "StrasseNichtGefunden",
                "type": "Element",
            },
        )
        hausnummer: list[str] = field(
            default_factory=list,
            metadata={
                "name": "Hausnummer",
                "type": "Element",
            },
        )
        hausnummer_nv: list[EinheitSolarHausnummerNv] = field(
            default_factory=list,
            metadata={
                "name": "Hausnummer_nv",
                "type": "Element",
            },
        )
        hausnummer_nicht_gefunden: list[
            EinheitSolarHausnummerNichtGefunden
        ] = field(
            default_factory=list,
            metadata={
                "name": "HausnummerNichtGefunden",
                "type": "Element",
            },
        )
        adresszusatz: list[str] = field(
            default_factory=list,
            metadata={
                "name": "Adresszusatz",
                "type": "Element",
            },
        )
        ort: list[str] = field(
            default_factory=list,
            metadata={
                "name": "Ort",
                "type": "Element",
            },
        )
        laengengrad: list[float] = field(
            default_factory=list,
            metadata={
                "name": "Laengengrad",
                "type": "Element",
            },
        )
        breitengrad: list[float] = field(
            default_factory=list,
            metadata={
                "name": "Breitengrad",
                "type": "Element",
            },
        )
        registrierungsdatum: list[XmlDate] = field(
            default_factory=list,
            metadata={
                "name": "Registrierungsdatum",
                "type": "Element",
            },
        )
        inbetriebnahmedatum: list[XmlDate] = field(
            default_factory=list,
            metadata={
                "name": "Inbetriebnahmedatum",
                "type": "Element",
            },
        )
        datum_endgueltige_stilllegung: list[XmlDate] = field(
            default_factory=list,
            metadata={
                "name": "DatumEndgueltigeStilllegung",
                "type": "Element",
            },
        )
        datum_beginn_voruebergehende_stilllegung: list[XmlDate] = field(
            default_factory=list,
            metadata={
                "name": "DatumBeginnVoruebergehendeStilllegung",
                "type": "Element",
            },
        )
        datum_wiederaufnahme_betrieb: list[XmlDate] = field(
            default_factory=list,
            metadata={
                "name": "DatumWiederaufnahmeBetrieb",
                "type": "Element",
            },
        )
        geplantes_inbetriebnahmedatum: list[XmlDate] = field(
            default_factory=list,
            metadata={
                "name": "GeplantesInbetriebnahmedatum",
                "type": "Element",
            },
        )
        einheit_systemstatus: list[EinheitSolarEinheitSystemstatus] = field(
            default_factory=list,
            metadata={
                "name": "EinheitSystemstatus",
                "type": "Element",
            },
        )
        einheit_betriebsstatus: list[EinheitSolarEinheitBetriebsstatus] = (
            field(
                default_factory=list,
                metadata={
                    "name": "EinheitBetriebsstatus",
                    "type": "Element",
                },
            )
        )
        bestandsanlage_mastr_nummer: list[str] = field(
            default_factory=list,
            metadata={
                "name": "BestandsanlageMastrNummer",
                "type": "Element",
            },
        )
        nicht_vorhanden_in_migrierten_einheiten: list[
            EinheitSolarNichtVorhandenInMigriertenEinheiten
        ] = field(
            default_factory=list,
            metadata={
                "name": "NichtVorhandenInMigriertenEinheiten",
                "type": "Element",
            },
        )
        alt_anlagenbetreiber_mastr_nummer: list[str] = field(
            default_factory=list,
            metadata={
                "name": "AltAnlagenbetreiberMastrNummer",
                "type": "Element",
            },
        )
        datum_des_betreiberwechsels: list[XmlDate] = field(
            default_factory=list,
            metadata={
                "name": "DatumDesBetreiberwechsels",
                "type": "Element",
            },
        )
        datum_registrierung_des_betreiberwechsels: list[XmlDate] = field(
            default_factory=list,
            metadata={
                "name": "DatumRegistrierungDesBetreiberwechsels",
                "type": "Element",
            },
        )
        name_stromerzeugungseinheit: list[str] = field(
            default_factory=list,
            metadata={
                "name": "NameStromerzeugungseinheit",
                "type": "Element",
            },
        )
        weic: list[str] = field(
            default_factory=list,
            metadata={
                "name": "Weic",
                "type": "Element",
            },
        )
        weic_nv: list[EinheitSolarWeicNv] = field(
            default_factory=list,
            metadata={
                "name": "Weic_nv",
                "type": "Element",
            },
        )
        weic_display_name: list[str] = field(
            default_factory=list,
            metadata={
                "name": "WeicDisplayName",
                "type": "Element",
            },
        )
        kraftwerksnummer: list[str] = field(
            default_factory=list,
            metadata={
                "name": "Kraftwerksnummer",
                "type": "Element",
            },
        )
        kraftwerksnummer_nv: list[EinheitSolarKraftwerksnummerNv] = field(
            default_factory=list,
            metadata={
                "name": "Kraftwerksnummer_nv",
                "type": "Element",
            },
        )
        energietraeger: list[EinheitSolarEnergietraeger] = field(
            default_factory=list,
            metadata={
                "name": "Energietraeger",
                "type": "Element",
            },
        )
        bruttoleistung: list[float] = field(
            default_factory=list,
            metadata={
                "name": "Bruttoleistung",
                "type": "Element",
            },
        )
        nettonennleistung: list[float] = field(
            default_factory=list,
            metadata={
                "name": "Nettonennleistung",
                "type": "Element",
            },
        )
        anschluss_an_hoechst_oder_hoch_spannung: list[
            EinheitSolarAnschlussAnHoechstOderHochSpannung
        ] = field(
            default_factory=list,
            metadata={
                "name": "AnschlussAnHoechstOderHochSpannung",
                "type": "Element",
            },
        )
        fernsteuerbarkeit_nb: list[EinheitSolarFernsteuerbarkeitNb] = field(
            default_factory=list,
            metadata={
                "name": "FernsteuerbarkeitNb",
                "type": "Element",
            },
        )
        fernsteuerbarkeit_dv: list[EinheitSolarFernsteuerbarkeitDv] = field(
            default_factory=list,
            metadata={
                "name": "FernsteuerbarkeitDv",
                "type": "Element",
            },
        )
        einspeisungsart: list[EinheitSolarEinspeisungsart] = field(
            default_factory=list,
            metadata={
                "name": "Einspeisungsart",
                "type": "Element",
            },
        )
        zugeordnete_wirkleistung_wechselrichter: list[float] = field(
            default_factory=list,
            metadata={
                "name": "ZugeordneteWirkleistungWechselrichter",
                "type": "Element",
            },
        )
        anzahl_module: list[int] = field(
            default_factory=list,
            metadata={
                "name": "AnzahlModule",
                "type": "Element",
            },
        )
        art_der_solaranlage: list[EinheitSolarArtDerSolaranlage] = field(
            default_factory=list,
            metadata={
                "name": "ArtDerSolaranlage",
                "type": "Element",
            },
        )
        leistungsbegrenzung: list[EinheitSolarLeistungsbegrenzung] = field(
            default_factory=list,
            metadata={
                "name": "Leistungsbegrenzung",
                "type": "Element",
            },
        )
        einheitliche_ausrichtung_und_neigungswinkel: list[
            EinheitSolarEinheitlicheAusrichtungUndNeigungswinkel
        ] = field(
            default_factory=list,
            metadata={
                "name": "EinheitlicheAusrichtungUndNeigungswinkel",
                "type": "Element",
            },
        )
        hauptausrichtung: list[EinheitSolarHauptausrichtung] = field(
            default_factory=list,
            metadata={
                "name": "Hauptausrichtung",
                "type": "Element",
            },
        )
        hauptausrichtung_neigungswinkel: list[
            EinheitSolarHauptausrichtungNeigungswinkel
        ] = field(
            default_factory=list,
            metadata={
                "name": "HauptausrichtungNeigungswinkel",
                "type": "Element",
            },
        )
        nebenausrichtung: list[EinheitSolarNebenausrichtung] = field(
            default_factory=list,
            metadata={
                "name": "Nebenausrichtung",
                "type": "Element",
            },
        )
        nebenausrichtung_neigungswinkel: list[
            EinheitSolarNebenausrichtungNeigungswinkel
        ] = field(
            default_factory=list,
            metadata={
                "name": "NebenausrichtungNeigungswinkel",
                "type": "Element",
            },
        )
        nutzungsbereich: list[EinheitSolarNutzungsbereich] = field(
            default_factory=list,
            metadata={
                "name": "Nutzungsbereich",
                "type": "Element",
            },
        )
        buergerenergie: list[EinheitSolarBuergerenergie] = field(
            default_factory=list,
            metadata={
                "name": "Buergerenergie",
                "type": "Element",
            },
        )
        eeg_ma_st_rnummer: list[str] = field(
            default_factory=list,
            metadata={
                "name": "EegMaStRNummer",
                "type": "Element",
            },
        )
        in_anspruch_genommene_flaeche: list[float] = field(
            default_factory=list,
            metadata={
                "name": "InAnspruchGenommeneFlaeche",
                "type": "Element",
            },
        )
        art_der_flaeche_ids: list[str] = field(
            default_factory=list,
            metadata={
                "name": "ArtDerFlaecheIds",
                "type": "Element",
            },
        )
        in_anspruch_genommene_ackerflaeche: list[float] = field(
            default_factory=list,
            metadata={
                "name": "InAnspruchGenommeneAckerflaeche",
                "type": "Element",
            },
        )
        einsatzverantwortlicher: list[str] = field(
            default_factory=list,
            metadata={
                "name": "Einsatzverantwortlicher",
                "type": "Element",
            },
        )
        gen_mastr_nummer: list[str] = field(
            default_factory=list,
            metadata={
                "name": "GenMastrNummer",
                "type": "Element",
            },
        )
        speicher_am_gleichen_ort: list[EinheitSolarSpeicherAmGleichenOrt] = (
            field(
                default_factory=list,
                metadata={
                    "name": "SpeicherAmGleichenOrt",
                    "type": "Element",
                },
            )
        )
