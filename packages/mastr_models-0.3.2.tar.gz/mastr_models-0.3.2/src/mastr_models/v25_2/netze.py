from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from xsdata.models.datatype import XmlDateTime


class NetzGeschlossenesVerteilnetz(Enum):
    VALUE_0 = 0
    VALUE_1 = 1


class NetzKundenAngeschlossen(Enum):
    VALUE_1 = 1
    VALUE_0 = 0


@dataclass
class Netze:
    netz: list["Netze.Netz"] = field(
        default_factory=list,
        metadata={
            "name": "Netz",
            "type": "Element",
        },
    )

    @dataclass
    class Netz:
        datum_letzte_aktualisierung: Optional[XmlDateTime] = field(
            default=None,
            metadata={
                "name": "DatumLetzteAktualisierung",
                "type": "Element",
            },
        )
        mastr_nummer: Optional[str] = field(
            default=None,
            metadata={
                "name": "MastrNummer",
                "type": "Element",
                "required": True,
            },
        )
        sparte: Optional[int] = field(
            default=None,
            metadata={
                "name": "Sparte",
                "type": "Element",
                "required": True,
            },
        )
        kunden_angeschlossen: Optional[NetzKundenAngeschlossen] = field(
            default=None,
            metadata={
                "name": "KundenAngeschlossen",
                "type": "Element",
            },
        )
        geschlossenes_verteilnetz: Optional[NetzGeschlossenesVerteilnetz] = (
            field(
                default=None,
                metadata={
                    "name": "GeschlossenesVerteilnetz",
                    "type": "Element",
                },
            )
        )
        bezeichnung: Optional[str] = field(
            default=None,
            metadata={
                "name": "Bezeichnung",
                "type": "Element",
            },
        )
        marktgebiet: Optional[int] = field(
            default=None,
            metadata={
                "name": "Marktgebiet",
                "type": "Element",
            },
        )
        bundesland: Optional[str] = field(
            default=None,
            metadata={
                "name": "Bundesland",
                "type": "Element",
            },
        )

        bilanzierungsgebiete: Optional[str] = field(
            default=None,
            metadata={
                "name": "Bilanzierungsgebiete",
                "type": "Element",
            },
        )