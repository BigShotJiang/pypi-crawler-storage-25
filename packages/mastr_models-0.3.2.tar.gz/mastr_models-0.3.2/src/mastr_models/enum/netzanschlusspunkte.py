from strenum import StrEnum


class NetzanschlusspunktGasqualitaet(StrEnum):
    VALUE_766 = "L-Gas"
    VALUE_767 = "H-Gas"


class NetzanschlusspunktLokationtyp(StrEnum):
    VALUE_1 = "andere Gase"
    VALUE_2 = "Biomasse"
    VALUE_3 = "Braunkohle"
    VALUE_4 = ""


class NetzanschlusspunktMarktgebiet(StrEnum):
    VALUE_1001666 = "NetConnect Germany"
    VALUE_1001667 = "Trading Hub Europe"
    VALUE_1536 = "Beide"


class NetzanschlusspunktRegelzoneNetzanschlusspunkt(StrEnum):
    VALUE_1000001 = "50Hertz"
    VALUE_1000010 = "Amprion"
    VALUE_1001564 = "TenneT"
    VALUE_1001572 = "TransnetBW"


class NetzanschlusspunktSpannungsebene(StrEnum):
    VALUE_348 = "Höchstspannung"
    VALUE_349 = "Umspannebene Höchstspannung/Hochspannung"
    VALUE_350 = "Hochspannung"
    VALUE_351 = "Umspannebene Hochspannung/Mittelspannung"
    VALUE_352 = "Mittelspannung"
    VALUE_353 = "Umspannebene Mittelspannung/Niederspannung"
    VALUE_354 = "Niederspannung (= Hausanschluss/Haushaltsstrom)"
