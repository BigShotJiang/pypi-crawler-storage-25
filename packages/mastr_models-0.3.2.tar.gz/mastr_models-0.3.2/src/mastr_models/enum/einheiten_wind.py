from strenum import StrEnum


class EinheitWindBundesland(StrEnum):
    VALUE_1400 = "Brandenburg"
    VALUE_1401 = "Berlin"
    VALUE_1402 = "Baden-Württemberg"
    VALUE_1403 = "Bayern"
    VALUE_1404 = "Bremen"
    VALUE_1405 = "Hessen"
    VALUE_1406 = "Hamburg"
    VALUE_1407 = "Mecklenburg-Vorpommern"
    VALUE_1408 = "Niedersachsen"
    VALUE_1409 = "Nordrhein-Westfalen"
    VALUE_1410 = "Rheinland-Pfalz"
    VALUE_1411 = "Schleswig-Holstein"
    VALUE_1412 = "Saarland"
    VALUE_1413 = "Sachsen"
    VALUE_1414 = "Sachsen-Anhalt"
    VALUE_1415 = "Thüringen"
    VALUE_1416 = "Ausschließliche Wirtschaftszone"


class EinheitWindClusterNordsee(StrEnum):
    VALUE_1546 = "1"
    VALUE_1547 = "2"
    VALUE_1548 = "3"
    VALUE_1549 = "4"
    VALUE_1550 = "5"
    VALUE_1551 = "6"
    VALUE_1552 = "7"
    VALUE_1553 = "8"
    VALUE_1554 = "9"
    VALUE_1555 = "10"
    VALUE_1556 = "11"
    VALUE_1557 = "12"
    VALUE_1558 = "13"
    VALUE_2963 = "kein Cluster"


class EinheitWindClusterOstsee(StrEnum):
    VALUE_1540 = "1"
    VALUE_1541 = "2"
    VALUE_1542 = "3"
    VALUE_1543 = "4"
    VALUE_1544 = "5"
    VALUE_2962 = "kein Cluster"
    VALUE_2970 = "6"


class EinheitWindEinheitBetriebsstatus(StrEnum):
    VALUE_31 = "In Planung"
    VALUE_35 = "In Betrieb"
    VALUE_37 = "Vorübergehend stillgelegt"
    VALUE_38 = "Endgültig stillgelegt"


class EinheitWindEinheitSystemstatus(StrEnum):
    VALUE_472 = "Aktiviert"
    VALUE_473 = "Deaktiviert"
    VALUE_484 = "Ungeprüft"
    VALUE_490 = "Unvollständig"
    VALUE_572 = "Gelöscht"


class EinheitWindEinspeisungsart(StrEnum):
    VALUE_688 = "Volleinspeisung"
    VALUE_689 = "Teileinspeisung (einschließlich Eigenverbrauch)"


class EinheitWindEnergietraeger(StrEnum):
    VALUE_2403 = "Geothermie"
    VALUE_2404 = "Solarthermie"
    VALUE_2405 = "Klärschlamm"
    VALUE_2406 = "Grubengas"
    VALUE_2407 = "Steinkohle"
    VALUE_2408 = "Braunkohle"
    VALUE_2409 = "Mineralölprodukte"
    VALUE_2410 = "Erdgas"
    VALUE_2411 = "andere Gase"
    VALUE_2412 = "nicht biogener Abfall"
    VALUE_2413 = "Wärme"
    VALUE_2493 = "Biomasse"
    VALUE_2494 = "Kernenergie"
    VALUE_2495 = "Solare Strahlungsenergie"
    VALUE_2496 = "Speicher"
    VALUE_2497 = "Wind"
    VALUE_2498 = "Wasser"
    VALUE_2957 = "Druck aus Gasleitungen"
    VALUE_2958 = "Druck aus Wasserleitungen"


class EinheitWindLand(StrEnum):
    VALUE_106 = "Frankreich"
    VALUE_169 = "Luxemburg"
    VALUE_198 = "Niederlande"
    VALUE_206 = "Österreich"
    VALUE_215 = "Polen"
    VALUE_231 = "Schweiz"
    VALUE_269 = "Tschechische Republik"
    VALUE_66 = "Belgien"
    VALUE_84 = "Deutschland"
    VALUE_90 = "Dänemark"


class EinheitWindNetzbetreiberpruefungStatus(StrEnum):
    VALUE_2954 = "Geprüft"
    VALUE_2955 = "In Prüfung"
    VALUE_3075 = "Nicht vorgesehen"


class EinheitWindSeelage(StrEnum):
    VALUE_639 = "Ostsee"
    VALUE_640 = "Nordsee"


class EinheitWindTechnologie(StrEnum):
    VALUE_691 = "Horizontalläufer"
    VALUE_692 = "Vertikalläufer"


class EinheitWindTechnologieFlugwindenergieanlage(StrEnum):
    VALUE_3163 = "Flexibler Drachen (Softkite)"
    VALUE_3164 = "Starrflügler (Fixed Wing)"
    VALUE_3165 = "Hybrid"
    VALUE_3166 = "Sonstige"


class EinheitWindWindAnLandOderAufSee(StrEnum):
    VALUE_888 = "Windkraft an Land"
    VALUE_889 = "Windkraft auf See"
