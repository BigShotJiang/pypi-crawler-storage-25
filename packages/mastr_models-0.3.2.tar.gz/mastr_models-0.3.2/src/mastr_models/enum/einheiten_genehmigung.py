from strenum import StrEnum


class EinheitGenehmigungArt(StrEnum):
    VALUE_2555 = "nach Wasserhaushaltsgesetz"
    VALUE_2556 = "nach Windenergie-auf-See-Gesetz"
    VALUE_39 = "nach BImSchG i.V.m 17. BImSchV"
    VALUE_40 = "Sonstige"
    VALUE_41 = "nach Baurecht"
    VALUE_845 = "nach BImSchG andere"
    VALUE_846 = "nach BImSchG i.V.m 4. BImSchV"
    VALUE_847 = "nach BImSchG i.V.m 1. BImSchV"
    VALUE_848 = "nach BImSchG i.V.m 13. BImSchV"
