from strenum import StrEnum


class EinheitWasserArtDerWasserkraftanlage(StrEnum):
    VALUE_890 = "Laufwasseranlage"
    VALUE_891 = "Speicherwasseranlage"
    VALUE_894 = "Wasserkraftanlage in Trinkwassersystem"
    VALUE_895 = "Wasserkraftanlage in Brauchwassersystem"
    VALUE_896 = "Abwasserkraftanlage"
    VALUE_897 = "Meeresenergie"


class EinheitWasserArtDesZuflusses(StrEnum):
    VALUE_724 = "Flusskraftwerk"
    VALUE_725 = "Restwasserkraftwerk"
    VALUE_726 = "Ausleitungskraftwerk"


class EinheitWasserBundesland(StrEnum):
    VALUE_1400 = "Brandenburg"
    VALUE_1401 = "Berlin"
    VALUE_1402 = "Baden-Württemberg"
    VALUE_1403 = "Bayern"
    VALUE_1404 = "Bremen"
    VALUE_1405 = "Hessen"
    VALUE_1406 = "Hamburg"
    VALUE_1407 = "Mecklenburg-Vorpommern"
    VALUE_1408 = "Niedersachsen"
    VALUE_1409 = "Nordrhein-Westfalen"
    VALUE_1410 = "Rheinland-Pfalz"
    VALUE_1411 = "Schleswig-Holstein"
    VALUE_1412 = "Saarland"
    VALUE_1413 = "Sachsen"
    VALUE_1414 = "Sachsen-Anhalt"
    VALUE_1415 = "Thüringen"
    VALUE_1416 = "Ausschließliche Wirtschaftszone"


class EinheitWasserEinheitBetriebsstatus(StrEnum):
    VALUE_31 = "In Planung"
    VALUE_35 = "In Betrieb"
    VALUE_37 = "Vorübergehend stillgelegt"
    VALUE_38 = "Endgültig stillgelegt"


class EinheitWasserEinheitSystemstatus(StrEnum):
    VALUE_472 = "Aktiviert"
    VALUE_473 = "Deaktiviert"
    VALUE_484 = "Ungeprüft"
    VALUE_490 = "Unvollständig"
    VALUE_572 = "Gelöscht"


class EinheitWasserEinspeisungsart(StrEnum):
    VALUE_688 = "Volleinspeisung"
    VALUE_689 = "Teileinspeisung (einschließlich Eigenverbrauch)"


class EinheitWasserEnergietraeger(StrEnum):
    VALUE_2403 = "Geothermie"
    VALUE_2404 = "Solarthermie"
    VALUE_2405 = "Klärschlamm"
    VALUE_2406 = "Grubengas"
    VALUE_2407 = "Steinkohle"
    VALUE_2408 = "Braunkohle"
    VALUE_2409 = "Mineralölprodukte"
    VALUE_2410 = "Erdgas"
    VALUE_2411 = "andere Gase"
    VALUE_2412 = "nicht biogener Abfall"
    VALUE_2413 = "Wärme"
    VALUE_2493 = "Biomasse"
    VALUE_2494 = "Kernenergie"
    VALUE_2495 = "Solare Strahlungsenergie"
    VALUE_2496 = "Speicher"
    VALUE_2497 = "Wind"
    VALUE_2498 = "Wasser"
    VALUE_2957 = "Druck aus Gasleitungen"
    VALUE_2958 = "Druck aus Wasserleitungen"


class EinheitWasserLand(StrEnum):
    VALUE_106 = "Frankreich"
    VALUE_169 = "Luxemburg"
    VALUE_198 = "Niederlande"
    VALUE_206 = "Österreich"
    VALUE_215 = "Polen"
    VALUE_231 = "Schweiz"
    VALUE_269 = "Tschechische Republik"
    VALUE_66 = "Belgien"
    VALUE_84 = "Deutschland"
    VALUE_90 = "Dänemark"


class EinheitWasserNetzbetreiberpruefungStatus(StrEnum):
    VALUE_2954 = "Geprüft"
    VALUE_2955 = "In Prüfung"
    VALUE_3075 = "Nicht vorgesehen"


class EinheitWasserReserveartNachDemEnWg(StrEnum):
    VALUE_3078 = "Nein"
    VALUE_3079 = "Ja, Kapazitätsreserve"
    VALUE_3080 = "Ja, Netzreserve"
