from strenum import StrEnum


class EinheitStromSpeicherAcDcKoppelung(StrEnum):
    VALUE_693 = "AC gekoppeltes System"
    VALUE_694 = "DC gekoppeltes System"


class EinheitStromSpeicherBatterietechnologie(StrEnum):
    VALUE_727 = "Lithium-Batterie"
    VALUE_728 = "Blei-Batterie"
    VALUE_729 = "Redox-Flow-Batterie"
    VALUE_730 = "Hochtemperaturbatterie"
    VALUE_731 = "Nickel-Cadmium- / Nickel-Metallhydridbatterie"
    VALUE_732 = "Sonstige Batterie"


class EinheitStromSpeicherBundesland(StrEnum):
    VALUE_1400 = "Brandenburg"
    VALUE_1401 = "Berlin"
    VALUE_1402 = "Baden-Württemberg"
    VALUE_1403 = "Bayern"
    VALUE_1404 = "Bremen"
    VALUE_1405 = "Hessen"
    VALUE_1406 = "Hamburg"
    VALUE_1407 = "Mecklenburg-Vorpommern"
    VALUE_1408 = "Niedersachsen"
    VALUE_1409 = "Nordrhein-Westfalen"
    VALUE_1410 = "Rheinland-Pfalz"
    VALUE_1411 = "Schleswig-Holstein"
    VALUE_1412 = "Saarland"
    VALUE_1413 = "Sachsen"
    VALUE_1414 = "Sachsen-Anhalt"
    VALUE_1415 = "Thüringen"
    VALUE_1416 = "Ausschließliche Wirtschaftszone"


class EinheitStromSpeicherEegAnlagentyp(StrEnum):
    VALUE_1 = "andere Gase"
    VALUE_12 = "Mineralölprodukte"
    VALUE_2 = "Biomasse"
    VALUE_3 = "Braunkohle"
    VALUE_5 = "Erdgas"
    VALUE_6 = "Geothermie"
    VALUE_7 = "Grubengas"
    VALUE_8 = "Kernenergie"
    VALUE_9 = "Klärschlamm"


class EinheitStromSpeicherEinheitBetriebsstatus(StrEnum):
    VALUE_31 = "In Planung"
    VALUE_35 = "In Betrieb"
    VALUE_37 = "Vorübergehend stillgelegt"
    VALUE_38 = "Endgültig stillgelegt"


class EinheitStromSpeicherEinheitSystemstatus(StrEnum):
    VALUE_472 = "Aktiviert"
    VALUE_473 = "Deaktiviert"
    VALUE_484 = "Ungeprüft"
    VALUE_490 = "Unvollständig"
    VALUE_572 = "Gelöscht"


class EinheitStromSpeicherEinsatzort(StrEnum):
    VALUE_1531 = "Alten-/Pflegeheim"
    VALUE_1532 = "Bergbau"
    VALUE_1533 = "Logistikzentrum (z.B. Kühlhaus)"
    VALUE_2399 = "Haushalt"
    VALUE_2400 = "Sonstige"
    VALUE_733 = "Flughafen"
    VALUE_734 = "Krankenhaus"
    VALUE_735 = "Veranstaltungsgebäude"
    VALUE_736 = "Rechenzentrum"
    VALUE_737 = "Industrie"
    VALUE_738 = "Bahn"
    VALUE_739 = "Bank"
    VALUE_740 = "Hotel"
    VALUE_741 = "Hochhaus"
    VALUE_742 = "Kaufhaus"
    VALUE_743 = "Kraftwerk"
    VALUE_744 = "Kultur und Messe"
    VALUE_745 = "Mastbetrieb"
    VALUE_746 = "Militär, Polizei und Justiz"
    VALUE_747 = "Regierungsgebäude"
    VALUE_748 = "Wasser- und Klärwerk"
    VALUE_749 = "Wohngebäude"
    VALUE_750 = "Versicherung"
    VALUE_751 = "Verlagshaus"
    VALUE_752 = "Tunnel und Straßen"
    VALUE_753 = "Telekommunikationsbranche"
    VALUE_754 = "Sportstätte"
    VALUE_755 = "Sendeanstalt"


class EinheitStromSpeicherEinspeisungsart(StrEnum):
    VALUE_688 = "Volleinspeisung"
    VALUE_689 = "Teileinspeisung (einschließlich Eigenverbrauch)"


class EinheitStromSpeicherEnergietraeger(StrEnum):
    VALUE_2403 = "Geothermie"
    VALUE_2404 = "Solarthermie"
    VALUE_2405 = "Klärschlamm"
    VALUE_2406 = "Grubengas"
    VALUE_2407 = "Steinkohle"
    VALUE_2408 = "Braunkohle"
    VALUE_2409 = "Mineralölprodukte"
    VALUE_2410 = "Erdgas"
    VALUE_2411 = "andere Gase"
    VALUE_2412 = "nicht biogener Abfall"
    VALUE_2413 = "Wärme"
    VALUE_2493 = "Biomasse"
    VALUE_2494 = "Kernenergie"
    VALUE_2495 = "Solare Strahlungsenergie"
    VALUE_2496 = "Speicher"
    VALUE_2497 = "Wind"
    VALUE_2498 = "Wasser"
    VALUE_2957 = "Druck aus Gasleitungen"
    VALUE_2958 = "Druck aus Wasserleitungen"


class EinheitStromSpeicherLand(StrEnum):
    VALUE_106 = "Frankreich"
    VALUE_169 = "Luxemburg"
    VALUE_198 = "Niederlande"
    VALUE_206 = "Österreich"
    VALUE_215 = "Polen"
    VALUE_231 = "Schweiz"
    VALUE_269 = "Tschechische Republik"
    VALUE_66 = "Belgien"
    VALUE_84 = "Deutschland"
    VALUE_90 = "Dänemark"


class EinheitStromSpeicherNetzbetreiberpruefungStatus(StrEnum):
    VALUE_2954 = "Geprüft"
    VALUE_2955 = "In Prüfung"
    VALUE_3075 = "Nicht vorgesehen"


class EinheitStromSpeicherPumpspeichertechnologie(StrEnum):
    VALUE_2920 = "Pumpspeicheranlage ohne natürlichen Zufluss"
    VALUE_2921 = "Pumpspeicheranlage mit natürlichem Zufluss"


class EinheitStromSpeicherReserveartNachDemEnWg(StrEnum):
    VALUE_3078 = "Nein"
    VALUE_3079 = "Ja, Kapazitätsreserve"
    VALUE_3080 = "Ja, Netzreserve"


class EinheitStromSpeicherTechnologie(StrEnum):
    VALUE_1537 = "Pumpspeicher"
    VALUE_524 = "Batterie"
    VALUE_525 = "Druckluft"
    VALUE_526 = "Schwungrad"

    # Manually specified, based on
    # `data\Gesamtdatenexport_20250701_25.1\Katalogwerte.xml`. Not sure why it was not
    # generated. `data\Gesamtdatenexport_20250701_25.1\EinheitenStromSpeicher_*.xml`
    # files do contain this value.
    VALUE_3067 = "Wasserstoffspeicher"
