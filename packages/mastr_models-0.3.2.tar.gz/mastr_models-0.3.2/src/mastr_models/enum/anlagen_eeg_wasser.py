from strenum import StrEnum


class AnlageEegWasserAnlageBetriebsstatus(StrEnum):
    VALUE_31 = "In Planung"
    VALUE_35 = "In Betrieb"
    VALUE_37 = "Vorübergehend stillgelegt"
    VALUE_38 = "Endgültig stillgelegt"
