from strenum import StrEnum


class EinheitSolarArtDerSolaranlage(StrEnum):
    VALUE_2484 = "Bauliche Anlagen (Sonstige)"
    VALUE_2961 = "Steckerfertige Solaranlage (sog. Balkonkraftwerk)"
    VALUE_3002 = "Gewässer"
    VALUE_3058 = "Großparkplatz"
    VALUE_852 = "Freifläche"
    VALUE_853 = "Bauliche Anlagen (Hausdach, Gebäude und Fassade)"


class EinheitSolarBundesland(StrEnum):
    VALUE_1400 = "Brandenburg"
    VALUE_1401 = "Berlin"
    VALUE_1402 = "Baden-Württemberg"
    VALUE_1403 = "Bayern"
    VALUE_1404 = "Bremen"
    VALUE_1405 = "Hessen"
    VALUE_1406 = "Hamburg"
    VALUE_1407 = "Mecklenburg-Vorpommern"
    VALUE_1408 = "Niedersachsen"
    VALUE_1409 = "Nordrhein-Westfalen"
    VALUE_1410 = "Rheinland-Pfalz"
    VALUE_1411 = "Schleswig-Holstein"
    VALUE_1412 = "Saarland"
    VALUE_1413 = "Sachsen"
    VALUE_1414 = "Sachsen-Anhalt"
    VALUE_1415 = "Thüringen"
    VALUE_1416 = "Ausschließliche Wirtschaftszone"


class EinheitSolarEinheitBetriebsstatus(StrEnum):
    VALUE_31 = "In Planung"
    VALUE_35 = "In Betrieb"
    VALUE_37 = "Vorübergehend stillgelegt"
    VALUE_38 = "Endgültig stillgelegt"


class EinheitSolarEinheitSystemstatus(StrEnum):
    VALUE_472 = "Aktiviert"
    VALUE_473 = "Deaktiviert"
    VALUE_484 = "Ungeprüft"
    VALUE_490 = "Unvollständig"
    VALUE_572 = "Gelöscht"


class EinheitSolarEinspeisungsart(StrEnum):
    VALUE_688 = "Volleinspeisung"
    VALUE_689 = "Teileinspeisung (einschließlich Eigenverbrauch)"


class EinheitSolarEnergietraeger(StrEnum):
    VALUE_2403 = "Geothermie"
    VALUE_2404 = "Solarthermie"
    VALUE_2405 = "Klärschlamm"
    VALUE_2406 = "Grubengas"
    VALUE_2407 = "Steinkohle"
    VALUE_2408 = "Braunkohle"
    VALUE_2409 = "Mineralölprodukte"
    VALUE_2410 = "Erdgas"
    VALUE_2411 = "andere Gase"
    VALUE_2412 = "nicht biogener Abfall"
    VALUE_2413 = "Wärme"
    VALUE_2493 = "Biomasse"
    VALUE_2494 = "Kernenergie"
    VALUE_2495 = "Solare Strahlungsenergie"
    VALUE_2496 = "Speicher"
    VALUE_2497 = "Wind"
    VALUE_2498 = "Wasser"
    VALUE_2957 = "Druck aus Gasleitungen"
    VALUE_2958 = "Druck aus Wasserleitungen"


class EinheitSolarHauptausrichtung(StrEnum):
    VALUE_695 = "Nord"
    VALUE_696 = "Nord-Ost"
    VALUE_697 = "Ost"
    VALUE_698 = "Süd-Ost"
    VALUE_699 = "Süd"
    VALUE_700 = "Süd-West"
    VALUE_701 = "West"
    VALUE_702 = "Nord-West"
    VALUE_703 = "nachgeführt"
    VALUE_704 = "Ost-West"


class EinheitSolarHauptausrichtungNeigungswinkel(StrEnum):
    VALUE_806 = "Fassadenintegriert"
    VALUE_807 = "> 60 Grad"
    VALUE_808 = "40 - 60 Grad"
    VALUE_809 = "20 - 40 Grad"
    VALUE_810 = "< 20 Grad"
    VALUE_811 = "Nachgeführt"


class EinheitSolarLand(StrEnum):
    VALUE_106 = "Frankreich"
    VALUE_169 = "Luxemburg"
    VALUE_198 = "Niederlande"
    VALUE_206 = "Österreich"
    VALUE_215 = "Polen"
    VALUE_231 = "Schweiz"
    VALUE_269 = "Tschechische Republik"
    VALUE_66 = "Belgien"
    VALUE_84 = "Deutschland"
    VALUE_90 = "Dänemark"


class EinheitSolarLeistungsbegrenzung(StrEnum):
    VALUE_1535 = "Ja, sonstige"
    VALUE_802 = "Nein"
    VALUE_803 = "Ja, auf 70%"
    VALUE_804 = "Ja, auf 60%"
    VALUE_805 = "Ja, auf 50%"


class EinheitSolarNebenausrichtung(StrEnum):
    VALUE_695 = "Nord"
    VALUE_696 = "Nord-Ost"
    VALUE_697 = "Ost"
    VALUE_698 = "Süd-Ost"
    VALUE_699 = "Süd"
    VALUE_700 = "Süd-West"
    VALUE_701 = "West"
    VALUE_702 = "Nord-West"
    VALUE_703 = "nachgeführt"
    VALUE_704 = "Ost-West"


class EinheitSolarNebenausrichtungNeigungswinkel(StrEnum):
    VALUE_806 = "Fassadenintegriert"
    VALUE_807 = "> 60 Grad"
    VALUE_808 = "40 - 60 Grad"
    VALUE_809 = "20 - 40 Grad"
    VALUE_810 = "< 20 Grad"
    VALUE_811 = "Nachgeführt"


class EinheitSolarNetzbetreiberpruefungStatus(StrEnum):
    VALUE_2954 = "Geprüft"
    VALUE_2955 = "In Prüfung"
    VALUE_3075 = "Nicht vorgesehen"


class EinheitSolarNutzungsbereich(StrEnum):
    VALUE_713 = "Haushalt"
    VALUE_714 = "Gewerbe, Handel und Dienstleistungen"
    VALUE_715 = "Industrie"
    VALUE_716 = "Landwirtschaft"
    VALUE_717 = "Öffentliches Gebäude"
    VALUE_718 = "Sonstige"
