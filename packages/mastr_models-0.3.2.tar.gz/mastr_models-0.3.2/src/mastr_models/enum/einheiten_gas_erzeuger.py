from strenum import StrEnum


class EinheitGasErzeugerBundesland(StrEnum):
    VALUE_1400 = "Brandenburg"
    VALUE_1401 = "Berlin"
    VALUE_1402 = "Baden-Württemberg"
    VALUE_1403 = "Bayern"
    VALUE_1404 = "Bremen"
    VALUE_1405 = "Hessen"
    VALUE_1406 = "Hamburg"
    VALUE_1407 = "Mecklenburg-Vorpommern"
    VALUE_1408 = "Niedersachsen"
    VALUE_1409 = "Nordrhein-Westfalen"
    VALUE_1410 = "Rheinland-Pfalz"
    VALUE_1411 = "Schleswig-Holstein"
    VALUE_1412 = "Saarland"
    VALUE_1413 = "Sachsen"
    VALUE_1414 = "Sachsen-Anhalt"
    VALUE_1415 = "Thüringen"
    VALUE_1416 = "Ausschließliche Wirtschaftszone"


class EinheitGasErzeugerEinheitBetriebsstatus(StrEnum):
    VALUE_31 = "In Planung"
    VALUE_35 = "In Betrieb"
    VALUE_37 = "Vorübergehend stillgelegt"


class EinheitGasErzeugerEinheitSystemstatus(StrEnum):
    VALUE_472 = "Aktiviert"
    VALUE_473 = "Deaktiviert"
    VALUE_484 = "Ungeprüft"
    VALUE_490 = "Unvollständig"
    VALUE_572 = "Gelöscht"


class EinheitGasErzeugerLand(StrEnum):
    VALUE_106 = "Frankreich"
    VALUE_169 = "Luxemburg"
    VALUE_198 = "Niederlande"
    VALUE_206 = "Österreich"
    VALUE_215 = "Polen"
    VALUE_231 = "Schweiz"
    VALUE_269 = "Tschechische Republik"
    VALUE_66 = "Belgien"
    VALUE_84 = "Deutschland"
    VALUE_90 = "Dänemark"


class EinheitGasErzeugerNetzbetreiberpruefungStatus(StrEnum):
    VALUE_2954 = "Geprüft"
    VALUE_2955 = "In Prüfung"
    VALUE_3075 = "Nicht vorgesehen"


class EinheitGasErzeugerTechnologie(StrEnum):
    VALUE_824 = "Förderung fossilen Erdgases"
    VALUE_825 = "Biomethan-Erzeugung"
    VALUE_826 = "Power-to-Gas (Wasserstoff)"
    VALUE_827 = "Power-to-Gas (Methan)"
    VALUE_828 = None
    VALUE_829 = "Liquefied Natural Gas"
