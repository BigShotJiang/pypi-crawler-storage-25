from strenum import StrEnum


class GeloeschterUndDeaktivierterMarktakteurMarktakteurStatus(StrEnum):
    VALUE_488 = None
    VALUE_489 = None
