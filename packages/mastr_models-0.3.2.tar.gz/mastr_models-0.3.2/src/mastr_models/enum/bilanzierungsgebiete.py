from strenum import StrEnum


class BilanzierungsgebietRegelzoneNetzanschlusspunkt(StrEnum):
    VALUE_1000001 = "50Hertz"
    VALUE_1000010 = "Amprion"
    VALUE_1001564 = "TenneT"
    VALUE_1001572 = "TransnetBW"
