from strenum import StrEnum


class GeloeschteUndDeaktivierteEinheitEinheitBetriebsstatus(StrEnum):
    VALUE_31 = "In Planung"
    VALUE_35 = "In Betrieb"
    VALUE_37 = "Vorübergehend stillgelegt"
    VALUE_38 = "Endgültig stillgelegt"


class GeloeschteUndDeaktivierteEinheitEinheitSystemstatus(StrEnum):
    VALUE_473 = "Deaktiviert"
    VALUE_572 = "Gelöscht"


class GeloeschteUndDeaktivierteEinheitEinheittyp(StrEnum):
    VALUE_1 = "andere Gase"
    VALUE_10 = None
    VALUE_11 = None
    VALUE_12 = "Mineralölprodukte"
    VALUE_2 = "Biomasse"
    VALUE_3 = "Braunkohle"
    VALUE_4 = None
    VALUE_5 = "Erdgas"
    VALUE_6 = "Geothermie"
    VALUE_8 = "Kernenergie"
    VALUE_9 = "Klärschlamm"
