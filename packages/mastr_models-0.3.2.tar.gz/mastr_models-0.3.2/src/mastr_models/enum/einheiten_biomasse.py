from strenum import StrEnum


class EinheitBiomasseBiomasseart(StrEnum):
    VALUE_719 = "Flüssige Biomasse"
    VALUE_720 = "Feste Biomasse"
    VALUE_721 = "Gasförmige Biomasse"


class EinheitBiomasseBundesland(StrEnum):
    VALUE_1400 = "Brandenburg"
    VALUE_1401 = "Berlin"
    VALUE_1402 = "Baden-Württemberg"
    VALUE_1403 = "Bayern"
    VALUE_1404 = "Bremen"
    VALUE_1405 = "Hessen"
    VALUE_1406 = "Hamburg"
    VALUE_1407 = "Mecklenburg-Vorpommern"
    VALUE_1408 = "Niedersachsen"
    VALUE_1409 = "Nordrhein-Westfalen"
    VALUE_1410 = "Rheinland-Pfalz"
    VALUE_1411 = "Schleswig-Holstein"
    VALUE_1412 = "Saarland"
    VALUE_1413 = "Sachsen"
    VALUE_1414 = "Sachsen-Anhalt"
    VALUE_1415 = "Thüringen"
    VALUE_1416 = "Ausschließliche Wirtschaftszone"


class EinheitBiomasseEinheitBetriebsstatus(StrEnum):
    VALUE_31 = "In Planung"
    VALUE_35 = "In Betrieb"
    VALUE_37 = "Vorübergehend stillgelegt"
    VALUE_38 = "Endgültig stillgelegt"


class EinheitBiomasseEinheitSystemstatus(StrEnum):
    VALUE_472 = "Aktiviert"
    VALUE_473 = "Deaktiviert"
    VALUE_484 = "Ungeprüft"
    VALUE_490 = "Unvollständig"
    VALUE_572 = "Gelöscht"


class EinheitBiomasseEinspeisungsart(StrEnum):
    VALUE_688 = "Volleinspeisung"
    VALUE_689 = "Teileinspeisung (einschließlich Eigenverbrauch)"


class EinheitBiomasseEnergietraeger(StrEnum):
    VALUE_2403 = "Geothermie"
    VALUE_2404 = "Solarthermie"
    VALUE_2405 = "Klärschlamm"
    VALUE_2406 = "Grubengas"
    VALUE_2407 = "Steinkohle"
    VALUE_2408 = "Braunkohle"
    VALUE_2409 = "Mineralölprodukte"
    VALUE_2410 = "Erdgas"
    VALUE_2411 = "andere Gase"
    VALUE_2412 = "nicht biogener Abfall"
    VALUE_2413 = "Wärme"
    VALUE_2493 = "Biomasse"
    VALUE_2494 = "Kernenergie"
    VALUE_2495 = "Solare Strahlungsenergie"
    VALUE_2496 = "Speicher"
    VALUE_2497 = "Wind"
    VALUE_2498 = "Wasser"
    VALUE_2957 = "Druck aus Gasleitungen"
    VALUE_2958 = "Druck aus Wasserleitungen"


class EinheitBiomasseHauptbrennstoff(StrEnum):
    VALUE_2414 = "Feste biogene Stoffe und Abfälle (ohne Holz)"
    VALUE_2415 = "Altholz, Gebrauchtholz, Holz(sperr)müll"
    VALUE_2416 = "Tier- und Blutmehl"
    VALUE_2417 = "Brennholz"
    VALUE_2418 = "Brennlauge, Schwarzlauge, Sulfitablauge"
    VALUE_2419 = "Feste biogene Stoffe"
    VALUE_2420 = "Holz"
    VALUE_2421 = "Wald-Holzhackschnitzel, Wald-Scheitholz, -Kronenholz"
    VALUE_2422 = "Holzreste (z.B. aus Schreinereien, auch Spanholz)"
    VALUE_2423 = "Holzspäne, Sägemehl"
    VALUE_2424 = "Rinde und Landschaftspflegeholz"
    VALUE_2425 = "Holz-Pellets, Holz-Briketts"
    VALUE_2426 = "Rauchspan"
    VALUE_2427 = "Restholz"
    VALUE_2428 = "Rinde"
    VALUE_2429 = "Schleifstaub, biogen"
    VALUE_2430 = "Schwarzlauge"
    VALUE_2431 = "Stroh, Strohpellets"
    VALUE_2432 = "Sulfitablauge"
    VALUE_2433 = "Tierfett"
    VALUE_2434 = "Tiermehl"
    VALUE_2435 = "Warmbrennstoffe (biogener Gewerbeabfall)"
    VALUE_2436 = "Flüssige biogene Stoffe und Abfälle"
    VALUE_2437 = "Biodiesel"
    VALUE_2438 = "Biomethanol"
    VALUE_2439 = "Flüssige biogene Stoffe"
    VALUE_2440 = "Harzöl"
    VALUE_2441 = "Iso-Hexan"
    VALUE_2442 = "Palmöl u.a. Pflanzenöle"
    VALUE_2443 = "Pflanzenöl"
    VALUE_2444 = "Terpentin"
    VALUE_2445 = "Biogas"
    VALUE_2446 = "Biomethan (Bioerdgas)"
    VALUE_2447 = "Deponiegas"
    VALUE_2448 = "Klärgas"


class EinheitBiomasseLand(StrEnum):
    VALUE_106 = "Frankreich"
    VALUE_169 = "Luxemburg"
    VALUE_198 = "Niederlande"
    VALUE_206 = "Österreich"
    VALUE_215 = "Polen"
    VALUE_231 = "Schweiz"
    VALUE_269 = "Tschechische Republik"
    VALUE_66 = "Belgien"
    VALUE_84 = "Deutschland"
    VALUE_90 = "Dänemark"


class EinheitBiomasseNetzbetreiberpruefungStatus(StrEnum):
    VALUE_2954 = "Geprüft"
    VALUE_2955 = "In Prüfung"
    VALUE_3075 = "Nicht vorgesehen"


class EinheitBiomasseReserveartNachDemEnWg(StrEnum):
    VALUE_3078 = "Nein"
    VALUE_3079 = "Ja, Kapazitätsreserve"
    VALUE_3080 = "Ja, Netzreserve"


class EinheitBiomasseTechnologie(StrEnum):
    VALUE_1538 = "Kalina-Cycle"
    VALUE_542 = "Verbrennungsmotor"
    VALUE_543 = "Brennstoffzelle"
    VALUE_544 = "Stirlingmotor"
    VALUE_545 = "Dampfmotor"
    VALUE_546 = "ORC (Organic Rankine Cycle)-Anlage"
    VALUE_833 = "Gegendruckmaschine mit Entnahme"
    VALUE_834 = "Gegendruckmaschine ohne Entnahme"
    VALUE_835 = "Gasturbinen ohne Abhitzekessel"
    VALUE_836 = "Gasturbinen mit Abhitzekessel"
    VALUE_837 = "Gasturbinen mit nachgeschalteter Dampfturbine"
    VALUE_838 = "Kondensationsmaschine mit Entnahme"
    VALUE_839 = "Kondensationsmaschine ohne Entnahme"
    VALUE_840 = "Sonstige"
