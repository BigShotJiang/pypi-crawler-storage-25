from strenum import StrEnum


class EinheitenAenderungNetzbetreiberzuordnungArtDerAenderung(StrEnum):
    VALUE_3085 = "Standortänderung"
    VALUE_3086 = "Netzübertragung"
