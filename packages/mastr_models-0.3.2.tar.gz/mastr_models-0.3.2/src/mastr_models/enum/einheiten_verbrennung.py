"""Manually maintained enum classes for thermal generation unit."""

from enum import Enum

from strenum import StrEnum


class Technologie(StrEnum):
    """Technology of MaStR thermal generation unit."""

    Verbrennungsmotor = "Verbrennungsmotor"
    """Internal combustion engine."""

    Brennstoffzelle = "Brennstoffzelle"
    """Fuel cell."""

    Dampfmotor = "Dampfmotor"
    """Steam motor."""

    Gasturbinen_mit_Abhitzekessel = "Gasturbinen mit Abhitzekessel"
    """Gas turbines with waste heat boiler."""

    Gasturbinen_mit_nachgeschalteter_Dampfturbine = (
        "Gasturbinen mit nachgeschalteter Dampfturbine"
    )
    """Gas turbines with downstream steam turbine."""

    Gasturbinen_ohne_Abhitzekessel = "Gasturbinen ohne Abhitzekessel"
    """Gas turbines without waste heat boiler."""

    Gegendruckmaschine_mit_Entnahme = "Gegendruckmaschine mit Entnahme"
    """Backpressure steam turbine with extraction."""

    Gegendruckmaschine_ohne_Entnahme = "Gegendruckmaschine ohne Entnahme"
    """Backpressure steam turbine without extraction."""

    Kalina = "Kalina-Cycle"

    Kondensationsmaschine_mit_Entnahme = "Kondensationsmaschine mit Entnahme"
    """Extraction-condensing steam turbine."""

    Kondensationsmaschine_ohne_Entnahme = "Kondensationsmaschine ohne Entnahme"
    """Condensing steam turbine (without extraction)."""

    ORC = "ORC (Organic Rankine Cycle)-Anlage"
    Stirlingmotor = "Stirlingmotor"
    Sonstige = "Sonstige"


class Hauptbrennstoff(StrEnum):
    # Steinkohle
    Kohlenwertstoffe_aus_Steinkohle = "Kohlenwertstoffe aus Steinkohle"
    Steinkohlen = "Steinkohlen"
    Steinkohlenbriketts = "Steinkohlenbriketts"
    Steinkohlenkoks = "Steinkohlenkoks"

    # Braunkohle
    Braunkohlenbriketts = "Braunkohlenbriketts"
    Braunkohlenkoks = "Braunkohlenkoks"
    Hartbraunkohlen = "Hartbraunkohlen"
    Rohbraunkohlen = "Rohbraunkohlen"
    Staub_und_Trockenkohle = "Staub- und Trockenkohle"
    Wirbelschichtkohle = "Wirbelschichtkohle"

    # Mineralölprodukte
    Dieselkraftstoff = "Dieselkraftstoff"
    Heizöl_leicht = "Heizöl, leicht"
    Heizöl_schwer = "Heizöl, schwer"

    Flüssiggas = "Flüssiggas"
    """Liquefied petroleum gas (LPG), a mixture of propane and butane."""

    Petrolkoks = "Petrolkoks"

    Raffineriegas = "Raffineriegas"
    """Refinery gas, a by-product of oil refining."""

    Andere_Mineraloelprodukte = "Andere Mineralölprodukte"

    ## Erdgas

    Erdgas_Erdoelgas = "Erdgas, Erdölgas"

    ## Andere Gase

    Grubengas = "Grubengas"
    """Mine gas, a by-product of coal mining."""

    Hochofengas_Konvertergas = "Hochofengas, Konvertergas"
    """Blast furnace gas, converter gas, a by-product of steel production."""

    Kokereigas = "Kokereigas"
    """Coke oven gas, a by-product of coke production."""

    Andere_Gase = "Andere Gase"

    Sonstige_hergestellte_Gase = "Sonstige hergestellte Gase"
    """Other manufactured gases, such as synthesis gas or biogas."""

    ## Nicht biogener Abfall

    nicht_biogener_Industrieabfall = "nicht biogener Industrieabfall"
    nicht_biogener_Abfall = "nicht biogener Abfall (Hausmüll, Siedlungsabfälle)"

    ## Wärme

    Prozessdampf = "Prozessdampf"
    """Process steam, used in industrial processes."""

    Dampf = "Dampf (fremdbezogen)"
    """Steam (from external sources), used in industrial processes."""

    Sonstige_Waerme = "Sonstige Wärme"


class FeedInType(Enum):
    """Full feed-in or partial feed-in to the grid.

    Angabe, ob der gesamte Strom aus der Stromerzeugungseinheit ins Netz eingespeist
    wird (Volleinspeisung) oder ob der Strom ganz oder teilweise in der Kundenanlage
    verbraucht wird (Teileinspeisung).
    """

    Volleinspeisung = "Volleinspeisung"
    """
    Volleinspeisung ist die vollständige Einspeisung des erzeugten Stroms ins Stromnetz.
    Als Volleinspeisung gilt auch die sogenannte "kaufmännisch-bilanzielle Weitergabe"
    des erzeugten Stroms an den Netzbetreiber.
    """

    Teileinspeisung = "Teileinspeisung"
    """
    Teileinspeisung (einschließlich Eigenverbrauch) ist auszuwählen, wenn der erzeugte
    Strom teilweise oder vollständig in der Kundenanlage vom Betreiber selbst verbraucht
    wird oder ohne Nutzung des Netzes einem Dritten überlassen wird (direkte
    Stromlieferung).
    """


class Betriebsstatus(Enum):
    In_Betrieb = "In Betrieb"

    In_Planung = "In Planung"
    """dieser Status ist bei der Vorab-Registrierung einer Einheit zu wählen, die noch nicht in Betrieb gegangen ist."""  # noqa: E501

    Voruebergehend_stillgelegt = "Vorübergehend stillgelegt"

    Endgueltig_stillgelegt = "Endgültig stillgelegt"
