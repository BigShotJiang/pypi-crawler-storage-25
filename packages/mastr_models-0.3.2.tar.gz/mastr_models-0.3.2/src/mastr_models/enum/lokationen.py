from strenum import StrEnum


class LokationLokationtyp(StrEnum):
    VALUE_1 = "andere Gase"
    VALUE_2 = "Biomasse"
    VALUE_3 = "Braunkohle"
    VALUE_4 = None
