"""Custom JSON-based column types in SQLAlchemy and MySQL."""

from json import dumps
from typing import Any, Type, TypeVar

from pydantic import BaseModel, TypeAdapter
from sqlalchemy import JSON, func, literal
from sqlalchemy.types import TypeDecorator
from strenum import StrEnum

_T = TypeVar("T")


class ListAsJSON(TypeDecorator):
    """Column type to store a list as JSON and make it easy to write queries."""

    impl = JSON
    cache_ok = True

    class Comparator(JSON.Comparator):
        def contains(self, other: str | StrEnum | int | float, **kwargs):
            """Whether the list contains a value.

            Notes:
                Based on https://dev.mysql.com/doc/refman/8.4/en/json-search-functions.html#function_json-contains
                and https://stackoverflow.com/a/59460379/10181743.

            Args:
                other: a value that could exists in the list.
            """
            if issubclass(other.__class__, StrEnum):
                value = f'"{other.value}"'
            elif isinstance(other, str):
                value = f'"{other}"'
            else:
                value = other

            return func.JSON_CONTAINS(self.__clause_element__(), literal(value), "$")

    comparator_factory = Comparator

    def process_bind_param(self, value, dialect):
        if value is None:
            return None
        elif isinstance(value, tuple):
            return list(value)
        elif isinstance(value, list):
            return value
        else:
            return value


class PydanticModelAsJSON(TypeDecorator):
    """Column type to map Pydantic modeled object(s) as JSON."""

    impl = JSON

    def __init__(self, model: Type[_T], *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.need_adapter: bool = not isinstance(model, BaseModel)
        self.model: BaseModel | TypeAdapter = (
            TypeAdapter(model) if self.need_adapter else model
        )

    def process_bind_param(self, value: BaseModel | Any | None, dialect) -> str | None:
        if value is not None:
            if self.need_adapter:
                return self.model.dump_json(value).decode("utf-8")
            else:
                return value.model_dump_json()
        else:
            return None

    def process_result_value(self, value: str | Any | None, dialect) -> Any | None:
        if value is not None:
            if isinstance(value, list) and len(value) == 0:
                return value
            elif isinstance(value, dict) and len(value) == 0:
                return value
            elif self.need_adapter:
                return self.model.validate_json(value)
            else:
                return self.model.model_validate_json(value)
        else:
            return None


def not_dump_str(value: str | Any) -> str:
    """Dump object to JSON string, but not dump a string, as it has been dumped.

    Notes:
        https://stackoverflow.com/a/73388977/10181743
    """
    if isinstance(value, str):
        return value
    else:
        return dumps(value)
