from typing import Type, TypeVar

from sqlalchemy import Enum as SQLAlchemyEnum
from sqlalchemy.types import TypeDecorator
from strenum import StrEnum

_T = TypeVar("T", bound=StrEnum)


class StrEnumColumn(TypeDecorator):
    """SQLAlchemy column type to use values (not names) of a Python enum."""

    impl = None
    cache_ok = True

    def __init__(self, enum_type: Type[_T], *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.enum_type = enum_type
        self.impl = SQLAlchemyEnum(*(x.value for x in enum_type.__members__.values()))

    def process_bind_param(self, value: StrEnum | str | None, dialect):
        if (value is not None) and not isinstance(value, str):
            return value.value
        else:
            return value

    def process_result_value(self, value: str | None, dialect):
        if value is not None:
            return self.enum_type(value)
        else:
            return value

    def literal_processor(self, dialect):
        def process(value: StrEnum | None):
            if value is not None:
                return f"'{value.value}'"
            else:
                return "NULL"

        return process
