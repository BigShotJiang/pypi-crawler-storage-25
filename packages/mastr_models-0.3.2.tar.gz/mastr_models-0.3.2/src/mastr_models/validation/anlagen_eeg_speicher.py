from mastr_models.v25_1_1.anlagen_eeg_speicher import AnlagenEegSpeicher
from mastr_models.validation.anlagen_eeg import AnlageEegIO


class AnlageEegSpeicherIO(AnlageEegIO):
    @classmethod
    def from_xml(
        cls, value: AnlagenEegSpeicher.AnlageEegSpeicher
    ) -> "AnlageEegSpeicherIO":
        """Convert an XML object to a Pydantic object."""
        return cls(
            registrierungsdatum=value.registrierungsdatum,
            datum_letzte_aktualisierung=value.datum_letzte_aktualisierung,
            eeg_inbetriebnahmedatum=value.eeg_inbetriebnahmedatum,
            eeg_ma_st_rnummer=value.eeg_ma_st_rnummer,
            anlagenschluessel_eeg=value.anlagenschluessel_eeg,
            ausschreibung_zuschlag=value.ausschreibung_zuschlag,
            zuschlagsnummer=value.zuschlagsnummer,
            verknuepfte_einheiten_ma_st_rnummern_list=value.verknuepfte_einheiten_ma_st_rnummern,
        )
