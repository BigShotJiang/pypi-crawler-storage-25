from datetime import date
from typing import Annotated

from mastr_models.enum.einheiten_strom_speicher import (
    EinheitStromSpeicherBundesland,
    EinheitStromSpeicherEinheitBetriebsstatus,
    EinheitStromSpeicherEinheitSystemstatus,
    EinheitStromSpeicherEinspeisungsart,
    EinheitStromSpeicherEnergietraeger,
    EinheitStromSpeicherLand,
    EinheitStromSpeicherNetzbetreiberpruefungStatus,
)
from mastr_models.utils import (
    map_bool_enum,
    map_str_enum,
    unpack_list,
    validate_mastr_id,
    xml_date_to_date,
)
from pydantic import AfterValidator, BaseModel, BeforeValidator, PlainValidator


class StromerzeugungseinheitIO(BaseModel):
    einheit_mastr_nummer: Annotated[
        str, AfterValidator(lambda x: validate_mastr_id(x, "SEE"))
    ]
    name_stromerzeugungseinheit: str
    lokation_id: str | None
    land: Annotated[
        EinheitStromSpeicherLand,
        BeforeValidator(lambda x: map_str_enum(x, EinheitStromSpeicherLand)),
    ]
    bundesland: Annotated[
        EinheitStromSpeicherBundesland | None,
        BeforeValidator(lambda x: map_str_enum(x, EinheitStromSpeicherBundesland)),
    ]
    landkreis: str | None
    gemeinde: str | None
    gemeindeschluessel: str | None
    postleitzahl: str | None
    strasse: str | None
    gemarkung: str | None
    flur_flurstuecknummern: str | None
    strasse_nicht_gefunden: Annotated[bool | None, BeforeValidator(map_bool_enum)]
    hausnummer: str | None
    hausnummer_nv: Annotated[bool | None, BeforeValidator(map_bool_enum)]
    hausnummer_nicht_gefunden: Annotated[bool | None, BeforeValidator(map_bool_enum)]
    adresszusatz: str | None
    ort: str | None
    laengengrad: float | None
    breitengrad: float | None
    registrierungsdatum: Annotated[date | None, PlainValidator(xml_date_to_date)]
    inbetriebnahmedatum: Annotated[date | None, PlainValidator(xml_date_to_date)]
    datum_endgueltige_stilllegung: Annotated[
        date | None, PlainValidator(xml_date_to_date)
    ]
    datum_beginn_voruebergehende_stilllegung: Annotated[
        date | None, PlainValidator(xml_date_to_date)
    ]
    datum_wiederaufnahme_betrieb: Annotated[
        date | None, PlainValidator(xml_date_to_date)
    ]
    geplantes_inbetriebnahmedatum: Annotated[
        date | None, PlainValidator(xml_date_to_date)
    ]
    datum_letzte_aktualisierung: Annotated[
        date | None, PlainValidator(xml_date_to_date)
    ]
    datum_des_betreiberwechsels: Annotated[
        date | None, PlainValidator(xml_date_to_date)
    ]
    datum_registrierung_des_betreiberwechsels: Annotated[
        date | None, PlainValidator(xml_date_to_date)
    ]
    netzbetreiberpruefung_datum: Annotated[
        date | None, PlainValidator(xml_date_to_date)
    ]
    anlagenbetreiber: Annotated[
        str | None,
        AfterValidator(
            lambda x: validate_mastr_id(x, "ABR") if x is not None else None
        ),
    ]
    alt_anlagenbetreiber: Annotated[
        list[str] | None,
        PlainValidator(lambda x: unpack_list(x) if x else None),
        AfterValidator(
            lambda x: [validate_mastr_id(y, "ABR") for y in x] if x else None
        ),
    ]
    bestandsanlage_mastr_nummer: str | None
    nicht_vorhanden_in_migrierten_einheiten: Annotated[
        bool | None, BeforeValidator(map_bool_enum)
    ]
    BNetzA_id: str | None
    w_eic: str | None
    w_eic_display_name: str | None
    kraftwerksnummer: str | None
    kraftwerksnummer_nv: Annotated[bool | None, BeforeValidator(map_bool_enum)]
    weic_nv: Annotated[bool | None, BeforeValidator(map_bool_enum)]
    eeg_ma_st_rnummer: str | None
    gen_mastr_nummer: str | None
    energietraeger: Annotated[
        EinheitStromSpeicherEnergietraeger | None,
        BeforeValidator(lambda x: map_str_enum(x, EinheitStromSpeicherEnergietraeger)),
    ]
    bruttoleistung: float | None
    nettonennleistung: float | None
    anschluss_an_hoechst_oder_hoch_spannung: Annotated[
        bool | None, BeforeValidator(map_bool_enum)
    ]
    fernsteuerbarkeit_nb: Annotated[bool | None, BeforeValidator(map_bool_enum)]
    fernsteuerbarkeit_dv: Annotated[bool | None, BeforeValidator(map_bool_enum)]
    einspeisungsart: Annotated[
        EinheitStromSpeicherEinspeisungsart | None,
        BeforeValidator(lambda x: map_str_enum(x, EinheitStromSpeicherEinspeisungsart)),
    ]
    einsatzverantwortlicher: str | None
    einheit_systemstatus: Annotated[
        EinheitStromSpeicherEinheitSystemstatus | None,
        BeforeValidator(
            lambda x: map_str_enum(x, EinheitStromSpeicherEinheitSystemstatus)
        ),
    ]
    einheit_betriebsstatus: Annotated[
        EinheitStromSpeicherEinheitBetriebsstatus | None,
        BeforeValidator(
            lambda x: map_str_enum(x, EinheitStromSpeicherEinheitBetriebsstatus)
        ),
    ]
    netzbetreiberpruefung_status: Annotated[
        EinheitStromSpeicherNetzbetreiberpruefungStatus | None,
        BeforeValidator(
            lambda x: map_str_enum(x, EinheitStromSpeicherNetzbetreiberpruefungStatus)
        ),
    ]
