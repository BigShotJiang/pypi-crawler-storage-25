"""Same definitions of `StromerzeugungseinheitIO`, but with different enum classes.

Since all the enum classes in `mastr_models.enum` are generated automatically, the enum
classes for `StromerzeugungseinheitIO` are defined with different names for different
types of generation units.
"""
