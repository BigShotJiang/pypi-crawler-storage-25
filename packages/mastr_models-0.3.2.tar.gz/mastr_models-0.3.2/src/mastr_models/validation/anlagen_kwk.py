from datetime import date
from typing import Annotated

from pydantic import AfterValidator, BaseModel, BeforeValidator, PlainValidator

from mastr_models.utils import map_bool_enum, validate_mastr_id, xml_date_to_date


class AnlageKwkIO(BaseModel):
    kwk_mastr_nummer: Annotated[
        str, AfterValidator(lambda x: validate_mastr_id(x, "KWK"))
    ]

    thermische_nutzleistung: float | None
    elektrische_kwk_leistung: float | None

    inbetriebnahmedatum: Annotated[date, PlainValidator(xml_date_to_date)]
    registrierungsdatum: Annotated[date, PlainValidator(xml_date_to_date)]

    ausschreibung_zuschlag: Annotated[
        bool | None,
        BeforeValidator(map_bool_enum),
    ]
    zuschlagnummer: str | None
