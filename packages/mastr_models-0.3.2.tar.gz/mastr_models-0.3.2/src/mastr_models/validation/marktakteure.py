from datetime import date, datetime
from typing import Annotated, Optional

from pydantic import AfterValidator, BaseModel, BeforeValidator, PlainValidator

from mastr_models.enum.marktakteure import (
    MarktakteurBundesland,
    MarktakteurHauptwirtdschaftszweigAbschnitt,
    MarktakteurHauptwirtdschaftszweigAbteilung,
    MarktakteurHauptwirtdschaftszweigGruppe,
    MarktakteurLand,
    MarktakteurLandAnZustelladresse,
    MarktakteurMarktakteurAnrede,
    MarktakteurMarktakteurTitel,
    MarktakteurMarktfunktion,
    MarktakteurPersonenart,
    MarktakteurRegisternummerPraefix,
)
from mastr_models.utils import (
    ensure_one,
    ensure_one_or_none,
    map_bool_enum,
    map_bool_int,
    map_str_enum,
    map_xml_datetime,
    validate_mastr_id,
    xml_date_to_date,
)
from mastr_models.v24_2.marktakteure import Marktakteure as Marktakteure_v24_2
from mastr_models.v25_1_1.marktakteure import Marktakteure as Marktakteure_v25_1_1
from mastr_models.v25_2.marktakteure import Marktakteure as Marktakteure_v25_2


class MarktakteurIO(BaseModel):
    mastr_nummer: Annotated[
        str,
        AfterValidator(
            lambda x: validate_mastr_id(
                x, "ABR", "ADM", "SUP", "SNB", "GNB", "SOM", "SEM", "GEM", "BVI", "OMP"
            )
        ),
    ]

    datum_letze_aktualisierung: Annotated[
        datetime | None, PlainValidator(map_xml_datetime)
    ]
    personenart: Annotated[
        MarktakteurPersonenart | None,
        BeforeValidator(lambda x: map_str_enum(x, MarktakteurPersonenart)),
    ]

    marktakteur_anrede: Annotated[
        MarktakteurMarktakteurAnrede | None,
        BeforeValidator(lambda x: map_str_enum(x, MarktakteurMarktakteurAnrede)),
    ] = None
    marktakteur_titel: Annotated[
        MarktakteurMarktakteurTitel | None,
        BeforeValidator(lambda x: map_str_enum(x, MarktakteurMarktakteurTitel)),
    ] = None
    marktakteur_vorname: Optional[str] = None
    marktakteur_nachname: Optional[str] = None
    firmenname: Optional[str] = None
    marktfunktion: Annotated[
        MarktakteurMarktfunktion | None,
        BeforeValidator(lambda x: map_str_enum(x, MarktakteurMarktfunktion)),
    ] = None
    rechtsform: Optional[int] = None
    sonstige_rechtsform: Optional[str] = None
    marktrollen: Optional[str] = None
    land: Annotated[
        MarktakteurLand | None,
        BeforeValidator(lambda x: map_str_enum(x, MarktakteurLand)),
    ] = None
    region: Optional[str] = None
    strasse: Optional[str] = None
    hausnummer: Optional[str] = None
    hausnummer_nv: Annotated[
        bool | None,
        BeforeValidator(map_bool_enum),
    ] = None
    adresszusatz: Optional[str] = None
    postleitzahl: Optional[str] = None
    ort: Optional[str] = None
    bundesland: Annotated[
        MarktakteurBundesland | None,
        BeforeValidator(lambda x: map_str_enum(x, MarktakteurBundesland)),
    ] = None
    netz: Optional[str] = None
    nuts2: Optional[str] = None
    email: Optional[str] = None
    telefon: Optional[str] = None
    fax: Optional[str] = None
    fax_nv: Annotated[
        bool | None,
        BeforeValidator(map_bool_enum),
    ] = None
    webseite: Optional[str] = None
    webseite_nv: Annotated[
        bool | None,
        BeforeValidator(map_bool_enum),
    ] = None
    registergericht: Optional[int] = None
    registergericht_ausland: Optional[str] = None
    registernummer_praefix: Annotated[
        MarktakteurRegisternummerPraefix | None,
        BeforeValidator(lambda x: map_str_enum(x, MarktakteurRegisternummerPraefix)),
    ] = None
    registernummer: Optional[str] = None
    registernummer_ausland: Optional[str] = None
    taetigkeitsbeginn: Annotated[date | None, PlainValidator(xml_date_to_date)]
    acer_code: Optional[str] = None
    acer_code_nv: Annotated[
        bool | None,
        BeforeValidator(map_bool_enum),
    ] = None
    umsatzsteueridentifikationsnummer: Optional[str] = None
    umsatzsteueridentifikationsnummer_nv: Annotated[
        bool | None,
        BeforeValidator(map_bool_enum),
    ] = None
    taetigkeitsende: Annotated[date | None, PlainValidator(xml_date_to_date)]
    bundesnetzagentur_betriebsnummer: Optional[str] = None
    bundesnetzagentur_betriebsnummer_nv: Annotated[
        bool | None,
        BeforeValidator(map_bool_int),
    ] = None
    land_an_zustelladresse: Annotated[
        MarktakteurLandAnZustelladresse | None,
        BeforeValidator(lambda x: map_str_enum(x, MarktakteurLandAnZustelladresse)),
    ] = None
    postleitzahl_an_zustelladresse: Optional[str] = None
    ort_an_zustelladresse: Optional[str] = None
    strasse_an_zustelladresse: Optional[str] = None
    hausnummer_an_zustelladresse: Optional[str] = None
    hausnummer_an_zustelladresse_nv: Annotated[
        bool | None,
        BeforeValidator(map_bool_enum),
    ] = None
    adresszusatz_an_zustelladresse: Optional[str] = None
    kmu: Annotated[
        bool | None,
        BeforeValidator(map_bool_enum),
    ] = None
    registrierungsdatum_marktakteur: Annotated[
        datetime | None, PlainValidator(map_xml_datetime)
    ]
    hauptwirtdschaftszweig_abteilung: Annotated[
        MarktakteurHauptwirtdschaftszweigAbteilung | None,
        BeforeValidator(
            lambda x: map_str_enum(x, MarktakteurHauptwirtdschaftszweigAbteilung)
        ),
    ] = None
    hauptwirtdschaftszweig_gruppe: Annotated[
        MarktakteurHauptwirtdschaftszweigGruppe | None,
        BeforeValidator(
            lambda x: map_str_enum(x, MarktakteurHauptwirtdschaftszweigGruppe)
        ),
    ] = None
    hauptwirtdschaftszweig_abschnitt: Annotated[
        MarktakteurHauptwirtdschaftszweigAbschnitt | None,
        BeforeValidator(
            lambda x: map_str_enum(x, MarktakteurHauptwirtdschaftszweigAbschnitt)
        ),
    ] = None
    direktvermarktungsunternehmen: Annotated[
        bool | None,
        BeforeValidator(map_bool_enum),
    ] = None
    belieferung_von_letztverbrauchern_strom: Annotated[
        bool | None,
        BeforeValidator(map_bool_enum),
    ] = None
    belieferung_haushaltskunden_strom: Annotated[
        bool | None,
        BeforeValidator(map_bool_enum),
    ] = None
    gasgrosshaendler: Annotated[
        bool | None,
        BeforeValidator(map_bool_enum),
    ] = None
    stromgrosshaendler: Annotated[
        bool | None,
        BeforeValidator(map_bool_enum),
    ] = None
    belieferung_von_letztverbrauchern_gas: Annotated[
        bool | None,
        BeforeValidator(map_bool_enum),
    ] = None
    belieferung_haushaltskunden_gas: Annotated[
        bool | None,
        BeforeValidator(map_bool_enum),
    ] = None
    webportal_des_netzbetreibers: Optional[str] = None


def xml_to_pydantic(
    value: Marktakteure_v25_1_1.Marktakteur
    | Marktakteure_v24_2.Marktakteur
    | Marktakteure_v25_2.Marktakteur,
) -> MarktakteurIO:
    return MarktakteurIO(
        mastr_nummer=ensure_one(value.mastr_nummer),
        datum_letze_aktualisierung=ensure_one_or_none(value.datum_letze_aktualisierung),
        personenart=ensure_one_or_none(value.personenart),
        marktakteur_anrede=ensure_one_or_none(value.marktakteur_anrede),
        marktakteur_titel=ensure_one_or_none(value.marktakteur_titel),
        marktakteur_vorname=ensure_one_or_none(value.marktakteur_vorname),
        marktakteur_nachname=ensure_one_or_none(value.marktakteur_nachname),
        firmenname=ensure_one_or_none(value.firmenname),
        marktfunktion=ensure_one_or_none(value.marktfunktion),
        rechtsform=ensure_one_or_none(value.rechtsform),
        sonstige_rechtsform=ensure_one_or_none(value.sonstige_rechtsform),
        marktrollen=ensure_one_or_none(value.marktrollen),
        land=ensure_one_or_none(value.land),
        region=ensure_one_or_none(value.region),
        strasse=ensure_one_or_none(value.strasse),
        hausnummer=ensure_one_or_none(value.hausnummer),
        hausnummer_nv=ensure_one_or_none(value.hausnummer_nv),
        adresszusatz=ensure_one_or_none(value.adresszusatz),
        postleitzahl=ensure_one_or_none(value.postleitzahl),
        ort=ensure_one_or_none(value.ort),
        bundesland=ensure_one_or_none(value.bundesland),
        netz=ensure_one_or_none(value.netz),
        nuts2=ensure_one_or_none(value.nuts2),
        email=ensure_one_or_none(value.email),
        telefon=ensure_one_or_none(value.telefon),
        fax=ensure_one_or_none(value.fax),
        fax_nv=ensure_one_or_none(value.fax_nv),
        webseite=ensure_one_or_none(value.webseite),
        webseite_nv=ensure_one_or_none(value.webseite_nv),
        registergericht=ensure_one_or_none(value.registergericht),
        registergericht_ausland=ensure_one_or_none(value.registergericht_ausland),
        registernummer_praefix=ensure_one_or_none(value.registernummer_praefix),
        registernummer=ensure_one_or_none(value.registernummer),
        registernummer_ausland=ensure_one_or_none(value.registernummer_ausland),
        taetigkeitsbeginn=ensure_one_or_none(value.taetigkeitsbeginn),
        acer_code=ensure_one_or_none(value.acer_code),
        acer_code_nv=ensure_one_or_none(value.acer_code_nv),
        umsatzsteueridentifikationsnummer=ensure_one_or_none(
            value.umsatzsteueridentifikationsnummer
        ),
        umsatzsteueridentifikationsnummer_nv=ensure_one_or_none(
            value.umsatzsteueridentifikationsnummer_nv
        ),
        taetigkeitsende=ensure_one_or_none(value.taetigkeitsende),
        bundesnetzagentur_betriebsnummer=ensure_one_or_none(
            value.bundesnetzagentur_betriebsnummer
        ),
        bundesnetzagentur_betriebsnummer_nv=ensure_one_or_none(
            value.bundesnetzagentur_betriebsnummer_nv
        ),
        land_an_zustelladresse=ensure_one_or_none(value.land_an_zustelladresse),
        postleitzahl_an_zustelladresse=ensure_one_or_none(
            value.postleitzahl_an_zustelladresse
        ),
        ort_an_zustelladresse=ensure_one_or_none(value.ort_an_zustelladresse),
        strasse_an_zustelladresse=ensure_one_or_none(value.strasse_an_zustelladresse),
        hausnummer_an_zustelladresse=ensure_one_or_none(
            value.hausnummer_an_zustelladresse
        ),
        hausnummer_an_zustelladresse_nv=ensure_one_or_none(
            value.hausnummer_an_zustelladresse_nv
        ),
        adresszusatz_an_zustelladresse=ensure_one_or_none(
            value.adresszusatz_an_zustelladresse
        ),
        kmu=ensure_one_or_none(value.kmu),
        registrierungsdatum_marktakteur=ensure_one_or_none(
            value.registrierungsdatum_marktakteur
        ),
        hauptwirtdschaftszweig_abteilung=ensure_one_or_none(
            value.hauptwirtdschaftszweig_abteilung
        ),
        hauptwirtdschaftszweig_gruppe=ensure_one_or_none(
            value.hauptwirtdschaftszweig_gruppe
        ),
        hauptwirtdschaftszweig_abschnitt=ensure_one_or_none(
            value.hauptwirtdschaftszweig_abschnitt
        ),
        direktvermarktungsunternehmen=ensure_one_or_none(
            value.direktvermarktungsunternehmen
        ),
        belieferung_von_letztverbrauchern_strom=ensure_one_or_none(
            value.belieferung_von_letztverbrauchern_strom
        ),
        belieferung_haushaltskunden_strom=ensure_one_or_none(
            value.belieferung_haushaltskunden_strom
        ),
        gasgrosshaendler=ensure_one_or_none(value.gasgrosshaendler),
        stromgrosshaendler=ensure_one_or_none(value.stromgrosshaendler),
        belieferung_von_letztverbrauchern_gas=ensure_one_or_none(
            value.belieferung_von_letztverbrauchern_gas
        ),
        belieferung_haushaltskunden_gas=ensure_one_or_none(
            value.belieferung_haushaltskunden_gas
        ),
        webportal_des_netzbetreibers=ensure_one_or_none(
            value.webportal_des_netzbetreibers
        ),
    )
