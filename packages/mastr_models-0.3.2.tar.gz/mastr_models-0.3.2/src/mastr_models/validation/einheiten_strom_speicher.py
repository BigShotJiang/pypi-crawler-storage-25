from datetime import date
from typing import Annotated

from pydantic import BeforeValidator, PlainValidator, StringConstraints

from mastr_models.enum.einheiten_strom_speicher import (
    EinheitStromSpeicherAcDcKoppelung,
    EinheitStromSpeicherBatterietechnologie,
    EinheitStromSpeicherEegAnlagentyp,
    EinheitStromSpeicherEinsatzort,
    EinheitStromSpeicherPumpspeichertechnologie,
    EinheitStromSpeicherReserveartNachDemEnWg,
    EinheitStromSpeicherTechnologie,
)
from mastr_models.utils import map_bool_enum, map_str_enum, xml_date_to_date
from mastr_models.v25_1_1.einheiten_strom_speicher import EinheitenStromSpeicher
from mastr_models.validation.stromerzeugung.strom_speicher import StromerzeugungseinheitIO


class EinheitStromSpeicherIO(StromerzeugungseinheitIO):
    reserveart_nach_dem_en_wg: Annotated[
        EinheitStromSpeicherReserveartNachDemEnWg | None,
        BeforeValidator(
            lambda x: map_str_enum(x, EinheitStromSpeicherReserveartNachDemEnWg)
        ),
    ]
    datum_ueberfuehrung_in_reserve: Annotated[
        date | None, PlainValidator(xml_date_to_date)
    ]
    eeg_anlagentyp: Annotated[
        EinheitStromSpeicherEegAnlagentyp | None,
        BeforeValidator(lambda x: map_str_enum(x, EinheitStromSpeicherEegAnlagentyp)),
    ]
    einsatzort: Annotated[
        EinheitStromSpeicherEinsatzort | None,
        BeforeValidator(lambda x: map_str_enum(x, EinheitStromSpeicherEinsatzort)),
    ]
    ac_dc_koppelung: Annotated[
        EinheitStromSpeicherAcDcKoppelung | None,
        BeforeValidator(lambda x: map_str_enum(x, EinheitStromSpeicherAcDcKoppelung)),
    ]
    batterietechnologie: Annotated[
        EinheitStromSpeicherBatterietechnologie | None,
        BeforeValidator(
            lambda x: map_str_enum(x, EinheitStromSpeicherBatterietechnologie)
        ),
    ]
    notstromaggregat: Annotated[bool | None, BeforeValidator(map_bool_enum)]
    pumpbetrieb_leistungsaufnahme: float | None
    pumpbetrieb_kontinuierlich_regelbar: Annotated[
        bool | None, BeforeValidator(map_bool_enum)
    ]
    pumpspeichertechnologie: Annotated[
        EinheitStromSpeicherPumpspeichertechnologie | None,
        BeforeValidator(
            lambda x: map_str_enum(x, EinheitStromSpeicherPumpspeichertechnologie)
        ),
    ]
    bestandteil_grenzkraftwerk: Annotated[bool | None, BeforeValidator(map_bool_enum)]
    nettonennleistung_deutschland: float | None
    zugeordnente_wirkleistung_wechselrichter: float | None
    spe_mastr_nummer: Annotated[str | None, StringConstraints(max_length=255)]
    technologie: Annotated[
        EinheitStromSpeicherTechnologie | None,
        BeforeValidator(lambda x: map_str_enum(x, EinheitStromSpeicherTechnologie)),
    ]
    gemeinsam_registrierte_solareinheit_mastr_nummer: Annotated[
        str | None, StringConstraints(max_length=255)
    ]

    @classmethod
    def from_xml(cls, value: EinheitenStromSpeicher.EinheitStromSpeicher):
        """Convert an XML object to a Pydantic object."""
        return cls(
            # Base class fields.
            einheit_mastr_nummer=value.einheit_mastr_nummer,
            datum_letzte_aktualisierung=value.datum_letzte_aktualisierung,
            netzbetreiberpruefung_status=value.netzbetreiberpruefung_status,
            land=value.land,
            postleitzahl=value.postleitzahl,
            registrierungsdatum=value.registrierungsdatum,
            einheit_systemstatus=value.einheit_systemstatus,
            einheit_betriebsstatus=value.einheit_betriebsstatus,
            nicht_vorhanden_in_migrierten_einheiten=value.nicht_vorhanden_in_migrierten_einheiten,
            name_stromerzeugungseinheit=value.name_stromerzeugungseinheit,
            weic_nv=value.weic_nv,
            kraftwerksnummer_nv=value.kraftwerksnummer_nv,
            energietraeger=value.energietraeger,
            bruttoleistung=value.bruttoleistung,
            BNetzA_id=value.kraftwerksnummer,
            w_eic=value.weic,
            w_eic_display_name=value.weic_display_name,
            lokation_id=value.lokation_ma_st_rnummer,
            netzbetreiberpruefung_datum=value.netzbetreiberpruefung_datum,
            anlagenbetreiber=value.anlagenbetreiber_mastr_nummer,
            bundesland=value.bundesland,
            landkreis=value.landkreis,
            gemeinde=value.gemeinde,
            gemeindeschluessel=value.gemeindeschluessel,
            gemarkung=value.gemarkung,
            flur_flurstuecknummern=value.flur_flurstuecknummern,
            strasse=value.strasse,
            strasse_nicht_gefunden=value.strasse_nicht_gefunden,
            hausnummer=value.hausnummer,
            hausnummer_nv=value.hausnummer_nv,
            hausnummer_nicht_gefunden=value.hausnummer_nicht_gefunden,
            adresszusatz=value.adresszusatz,
            ort=value.ort,
            laengengrad=value.laengengrad,
            breitengrad=value.breitengrad,
            inbetriebnahmedatum=value.inbetriebnahmedatum,
            geplantes_inbetriebnahmedatum=value.geplantes_inbetriebnahmedatum,
            datum_endgueltige_stilllegung=value.datum_endgueltige_stilllegung,
            datum_beginn_voruebergehende_stilllegung=value.datum_beginn_voruebergehende_stilllegung,
            datum_wiederaufnahme_betrieb=value.datum_wiederaufnahme_betrieb,
            bestandsanlage_mastr_nummer=value.bestandsanlage_mastr_nummer,
            alt_anlagenbetreiber=value.alt_anlagenbetreiber_mastr_nummer,
            datum_des_betreiberwechsels=value.datum_des_betreiberwechsels,
            datum_registrierung_des_betreiberwechsels=value.datum_registrierung_des_betreiberwechsels,
            kraftwerksnummer=value.kraftwerksnummer,
            nettonennleistung=value.nettonennleistung,
            anschluss_an_hoechst_oder_hoch_spannung=value.anschluss_an_hoechst_oder_hoch_spannung,
            einsatzverantwortlicher=value.einsatzverantwortlicher,
            fernsteuerbarkeit_nb=value.fernsteuerbarkeit_nb,
            fernsteuerbarkeit_dv=value.fernsteuerbarkeit_dv,
            einspeisungsart=value.einspeisungsart,
            gen_mastr_nummer=value.gen_mastr_nummer,
            eeg_ma_st_rnummer=value.eeg_ma_st_rnummer,
            # Storage-specific fields.
            reserveart_nach_dem_en_wg=value.reserveart_nach_dem_en_wg,
            datum_ueberfuehrung_in_reserve=value.datum_ueberfuehrung_in_reserve,
            eeg_anlagentyp=value.eeg_anlagentyp,
            einsatzort=value.einsatzort,
            ac_dc_koppelung=value.ac_dc_koppelung,
            batterietechnologie=value.batterietechnologie,
            notstromaggregat=value.notstromaggregat,
            pumpbetrieb_leistungsaufnahme=value.pumpbetrieb_leistungsaufnahme,
            pumpbetrieb_kontinuierlich_regelbar=value.pumpbetrieb_kontinuierlich_regelbar,
            pumpspeichertechnologie=value.pumpspeichertechnologie,
            bestandteil_grenzkraftwerk=value.bestandteil_grenzkraftwerk,
            nettonennleistung_deutschland=value.nettonennleistung_deutschland,
            zugeordnente_wirkleistung_wechselrichter=value.zugeordnente_wirkleistung_wechselrichter,
            spe_mastr_nummer=value.spe_mastr_nummer,
            technologie=value.technologie,
            gemeinsam_registrierte_solareinheit_mastr_nummer=value.gemeinsam_registrierte_solareinheit_mastr_nummer,
        )
