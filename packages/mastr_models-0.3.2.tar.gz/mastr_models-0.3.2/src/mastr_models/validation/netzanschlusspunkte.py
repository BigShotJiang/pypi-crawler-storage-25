from datetime import date
from typing import Annotated

from pydantic import AfterValidator, BaseModel, BeforeValidator, PlainValidator

from mastr_models.enum.netzanschlusspunkte import (
    NetzanschlusspunktGasqualitaet,
    NetzanschlusspunktLokationtyp,
    NetzanschlusspunktMarktgebiet,
    NetzanschlusspunktRegelzoneNetzanschlusspunkt,
    NetzanschlusspunktSpannungsebene,
)
from mastr_models.utils import (
    map_bool_enum,
    map_str_enum,
    unpack_list,
    validate_mastr_id,
    xml_date_to_date,
)


class NetzanschlusspunktIO(BaseModel):
    netzanschlusspunkt_mastr_nummer: Annotated[
        str,
        AfterValidator(lambda x: validate_mastr_id(x, "SAN", "GAN")),
    ]
    netzanschlusspunkt_bezeichnung: str | None = None
    letzte_aenderung: Annotated[
        date | None,
        PlainValidator(xml_date_to_date),
    ]
    lokation_ma_st_rnummer: Annotated[
        str,
        AfterValidator(lambda x: validate_mastr_id(x, "SEL", "GVL", "GEL", "SVL")),
    ]
    name_der_technischen_lokation: str | None = None
    lokationtyp: Annotated[
        NetzanschlusspunktLokationtyp | None,
        BeforeValidator(lambda x: map_str_enum(x, NetzanschlusspunktLokationtyp)),
    ]
    maximale_einspeiseleistung: float | None = None
    maximale_ausspeiseleistung: float | None = None
    gasqualitaet: Annotated[
        NetzanschlusspunktGasqualitaet | None,
        BeforeValidator(lambda x: map_str_enum(x, NetzanschlusspunktGasqualitaet)),
    ]
    messlokation: Annotated[
        list[str] | None,
        PlainValidator(lambda x: unpack_list(x) if x else None),
    ]
    marktgebiet: Annotated[
        NetzanschlusspunktMarktgebiet | None,
        BeforeValidator(lambda x: map_str_enum(x, NetzanschlusspunktMarktgebiet)),
    ] = None
    spannungsebene: Annotated[
        NetzanschlusspunktSpannungsebene | None,
        BeforeValidator(lambda x: map_str_enum(x, NetzanschlusspunktSpannungsebene)),
    ] = None
    regelzone_netzanschlusspunkt: Annotated[
        NetzanschlusspunktRegelzoneNetzanschlusspunkt | None,
        BeforeValidator(
            lambda x: map_str_enum(x, NetzanschlusspunktRegelzoneNetzanschlusspunkt)
        ),
    ] = None
    nettoengpassleistung: float | None = None
    bilanzierungsgebiet_netzanschlusspunkt_id: int | None = None
    netzanschlusskapazitaet: float | None = None
    netz_ma_st_rnummer: Annotated[
        str,
        AfterValidator(lambda x: validate_mastr_id(x, "SNE", "GNE")),
    ]
    noch_in_planung: Annotated[
        bool | None,
        BeforeValidator(map_bool_enum),
    ]
    netzbetreiber_ma_st_rnummer: Annotated[
        str,
        AfterValidator(lambda x: validate_mastr_id(x, "SNB", "GNB")),
    ]
