from datetime import date
from typing import Annotated

from annotated_types import Len
from pydantic import (
    AfterValidator,
    BaseModel,
    BeforeValidator,
    Field,
    PlainValidator,
    StringConstraints,
    computed_field,
)

from mastr_models.utils import (
    map_bool_enum,
    unpack_list,
    validate_mastr_id,
    xml_date_to_date,
)


class AnlageEegIO(BaseModel):
    eeg_ma_st_rnummer: Annotated[
        str,
        AfterValidator(lambda x: validate_mastr_id(x, "EEG")),
    ]
    registrierungsdatum: Annotated[date | None, PlainValidator(xml_date_to_date)]
    datum_letzte_aktualisierung: Annotated[
        date | None, PlainValidator(xml_date_to_date)
    ]
    eeg_inbetriebnahmedatum: Annotated[date | None, PlainValidator(xml_date_to_date)]
    anlagenschluessel_eeg: Annotated[str | None, StringConstraints(max_length=255)]
    ausschreibung_zuschlag: Annotated[bool | None, BeforeValidator(map_bool_enum)]
    zuschlagsnummer: Annotated[str | None, StringConstraints(max_length=255)]
    verknuepfte_einheiten_ma_st_rnummern_list: Annotated[
        list[str],
        PlainValidator(lambda x: unpack_list(x)),
        AfterValidator(lambda x: [validate_mastr_id(y, "SEE") for y in x]),
        Len(min_length=1, max_length=1),
    ] = Field(exclude=True)

    @computed_field
    @property
    def verknuepfte_einheiten_ma_st_rnummern(self) -> str:
        return self.verknuepfte_einheiten_ma_st_rnummern_list[0]
