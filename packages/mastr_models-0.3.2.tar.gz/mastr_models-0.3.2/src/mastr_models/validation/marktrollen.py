from datetime import date
from typing import Annotated

from pydantic import AfterValidator, BaseModel, BeforeValidator, PlainValidator

from mastr_models.utils import (
    map_bool_enum,
    validate_marktrolle_id,
    validate_mastr_id,
    xml_date_to_date,
)


class MarktrolleIO(BaseModel):
    marktakteur_mastr_nummer: Annotated[
        str,
        AfterValidator(
            lambda x: validate_mastr_id(
                x,
                "ABR",
                "ADM",
                "SUP",
                "SNB",
                "GNB",
                "SOM",
                "SEM",
                "GEM",
                "BVI",
                "OMP",
            )
        ),
    ]
    datum_letzte_aktualisierung: Annotated[
        date | None,
        PlainValidator(xml_date_to_date),
    ]
    mastr_nummer: Annotated[
        str,
        AfterValidator(
            lambda x: validate_marktrolle_id(
                x, "SNB", "GEM", "OMP", "GNB", "SOM", "BVI", "SEM", "GNB"
            )
        ),
    ]
    marktrolle: str
    bundesnetzagentur_betriebsnummer: str | None = None
    bundesnetzagentur_betriebsnummer_nv: Annotated[
        bool | None,
        BeforeValidator(map_bool_enum),
    ] = None
    marktpartneridentifikationsnummer: str | None = None
    marktpartneridentifikationsnummer_nv: Annotated[
        bool | None,
        BeforeValidator(map_bool_enum),
    ]
    kontaktdaten_marktrolle: str | None = None
