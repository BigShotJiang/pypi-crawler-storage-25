from datetime import date
from enum import Enum
from typing import Annotated

from pydantic import AfterValidator, BaseModel, BeforeValidator, PlainValidator

from mastr_models.utils import (
    map_bool_enum,
    unpack_list,
    validate_mastr_id,
    xml_date_to_date,
)


class GridType(Enum):
    SNE = 20
    GNE = 21


class NetzIO(BaseModel):
    datum_letzte_aktualisierung: Annotated[
        date | None,
        PlainValidator(xml_date_to_date),
    ]
    mastr_nummer: Annotated[
        str, AfterValidator(lambda x: validate_mastr_id(x, "SNE", "GNE"))
    ]
    sparte: Annotated[
        GridType,
        BeforeValidator(lambda x: GridType(int(x))),
    ]
    kunden_angeschlossen: Annotated[
        bool | None,
        BeforeValidator(map_bool_enum),
    ]
    geschlossenes_verteilnetz: Annotated[
        bool | None,
        BeforeValidator(map_bool_enum),
    ]
    bezeichnung: str | None = None
    marktgebiet: int | None = None
    bundesland: str | None = None
    bilanzierungsgebiete: Annotated[
        list[str] | None,
        PlainValidator(lambda x: unpack_list(x) if x else None),
    ]
