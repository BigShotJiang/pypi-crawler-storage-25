from datetime import date
from typing import Annotated

from pydantic import (
    AfterValidator,
    BaseModel,
    BeforeValidator,
    PlainValidator,
    StringConstraints,
    ValidationError,
)

from mastr_models.enum.einheiten_verbrennung import (
    FeedInType,
    Hauptbrennstoff,
    Technologie,
)
from mastr_models.log import LOG
from mastr_models.map.einheiten_verbrennung import (
    FEED_IN_MAP,
    HAUPTBRENNSTOFF_MAP,
    TECHNOLOGIE_MAP,
)
from mastr_models.utils import (
    ensure_one,
    ensure_one_or_none,
    map_bool_enum,
    unpack_list,
    validate_mastr_id,
    xml_date_to_date,
)
from mastr_models.v25_2.einheiten_verbrennung import EinheitenVerbrennung


class EinheitVerbrennungIO(BaseModel):
    id_: Annotated[str, AfterValidator(lambda x: validate_mastr_id(x, "SEE"))]
    DisplayName: str

    hauptbrennstoff: Annotated[
        Hauptbrennstoff | None,
        BeforeValidator(
            lambda x: HAUPTBRENNSTOFF_MAP[x] if x in HAUPTBRENNSTOFF_MAP else None
        ),
    ]
    technologie: Annotated[Technologie, BeforeValidator(lambda x: TECHNOLOGIE_MAP[x])]
    bruttoleistung: float
    nettonennleistung: float

    lokation_id: str | None
    name_kraftwerk: str | None
    name_kraftwerksblock: str | None

    # Dates.
    inbetriebnahmedatum: Annotated[date | None, PlainValidator(xml_date_to_date)]
    netzreserve_ab_datum: Annotated[date | None, PlainValidator(xml_date_to_date)]
    datum_endgueltige_stilllegung: Annotated[
        date | None, PlainValidator(xml_date_to_date)
    ]

    # Operators
    anlagenbetreiber: Annotated[
        str | None,
        AfterValidator(
            lambda x: validate_mastr_id(x, "ABR") if x is not None else True
        ),
    ]
    alt_anlagenbetreiber: Annotated[
        list[str] | None,
        PlainValidator(lambda x: unpack_list(x) if x else None),
        AfterValidator(
            lambda x: [validate_mastr_id(y, "ABR") for y in x] if x else None
        ),
    ]

    # IDs in other systems
    BNetzA_id: str | None
    w_eic: str | None
    w_eic_display_name: str | None
    einsatzverantwortlicher: Annotated[str | None, StringConstraints(max_length=20)]

    # Combined generation
    kombibetrieb_id: Annotated[
        list[str] | None,
        PlainValidator(lambda x: unpack_list(x) if x else None),
        AfterValidator(
            lambda x: [validate_mastr_id(y, "SEE") for y in x] if x else None
        ),
    ]
    steigerung_nettonennleistung_kombibetrieb: float | None
    anlage_ist_im_kombibetrieb: Annotated[
        bool | None,
        BeforeValidator(map_bool_enum),
    ]
    ausschliessliche_verwendung_im_kombibetrieb: Annotated[
        bool | None,
        BeforeValidator(map_bool_enum),
    ]

    # KWK
    kwk_id: str | None

    # Address
    strasse: Annotated[str | None, StringConstraints(max_length=50)]
    hausnummer: Annotated[str | None, StringConstraints(max_length=20)]
    postleitzahl: Annotated[str | None, StringConstraints(max_length=10)]
    ort: Annotated[str | None, StringConstraints(max_length=50)]
    land: int
    bundesland: int | None

    # Coordinates
    laengengrad: float | None
    breitengrad: float | None

    # Feed-in
    einspeisungsart: Annotated[
        FeedInType | None,
        BeforeValidator(lambda x: FEED_IN_MAP[x] if x in FEED_IN_MAP else None),
    ]


def xml_to_pydantic(
    value: EinheitenVerbrennung.EinheitVerbrennung,
) -> EinheitVerbrennungIO | None:
    """Convert an XML object to a Pydantic object, if it satisfies requirement."""
    if value.technologie and value.bruttoleistung and value.nettonennleistung:
        try:
            kombibetrieb_id_raw = ensure_one_or_none(value.mastr_nummern_kombibetrieb)

            return EinheitVerbrennungIO(
                id_=ensure_one(value.einheit_mastr_nummer),
                DisplayName=ensure_one(value.name_stromerzeugungseinheit),
                lokation_id=ensure_one_or_none(value.lokation_ma_st_rnummer),
                name_kraftwerk=ensure_one_or_none(value.name_kraftwerk),
                name_kraftwerksblock=ensure_one_or_none(value.name_kraftwerksblock),
                hauptbrennstoff=ensure_one_or_none(value.hauptbrennstoff),
                technologie=ensure_one(value.technologie),
                bruttoleistung=ensure_one(value.bruttoleistung),
                nettonennleistung=ensure_one(value.nettonennleistung),
                # Dates.
                inbetriebnahmedatum=ensure_one_or_none(value.inbetriebnahmedatum),
                netzreserve_ab_datum=ensure_one_or_none(value.netzreserve_ab_datum),
                datum_endgueltige_stilllegung=ensure_one_or_none(
                    value.datum_endgueltige_stilllegung
                ),
                # Operators.
                anlagenbetreiber=ensure_one_or_none(
                    value.anlagenbetreiber_mastr_nummer
                ),
                alt_anlagenbetreiber=ensure_one_or_none(
                    value.alt_anlagenbetreiber_mastr_nummer
                ),
                # IDs in other systems.
                BNetzA_id=ensure_one_or_none(value.kraftwerksnummer),
                w_eic=ensure_one_or_none(value.weic),
                w_eic_display_name=ensure_one_or_none(value.weic_display_name),
                einsatzverantwortlicher=ensure_one_or_none(
                    value.einsatzverantwortlicher
                ),
                # KWK
                kwk_id=ensure_one_or_none(value.kwk_ma_st_rnummer),
                # Combined generation info.
                kombibetrieb_id=kombibetrieb_id_raw if kombibetrieb_id_raw else None,
                steigerung_nettonennleistung_kombibetrieb=ensure_one_or_none(
                    value.steigerung_nettonennleistung_kombibetrieb
                ),
                anlage_ist_im_kombibetrieb=ensure_one_or_none(
                    value.anlage_ist_im_kombibetrieb
                ),
                ausschliessliche_verwendung_im_kombibetrieb=ensure_one_or_none(
                    value.ausschliessliche_verwendung_im_kombibetrieb
                ),
                # Address.
                strasse=ensure_one_or_none(value.strasse),
                hausnummer=ensure_one_or_none(value.hausnummer),
                postleitzahl=ensure_one_or_none(value.postleitzahl),
                ort=ensure_one_or_none(value.ort),
                land=ensure_one(value.land),
                bundesland=ensure_one_or_none(value.bundesland),
                laengengrad=ensure_one_or_none(value.laengengrad),
                breitengrad=ensure_one_or_none(value.breitengrad),
                # Feed-in.
                einspeisungsart=ensure_one_or_none(value.einspeisungsart),
            )
        except ValidationError as e:
            LOG.error(f"Validation error: {e}")
            return None
    else:
        LOG.error(f"Missing information: {value}")
        return None
