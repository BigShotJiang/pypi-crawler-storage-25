from datetime import date
from typing import Annotated

from annotated_types import Len
from pydantic import AfterValidator, BaseModel, BeforeValidator, PlainValidator

from mastr_models.enum.anlagen_strom_speicher import (
    AnlageStromSpeicherAnlageBetriebsstatus,
)
from mastr_models.utils import (
    map_str_enum,
    unpack_list,
    validate_mastr_id,
    xml_date_to_date,
)
from mastr_models.v25_1_1.anlagen_strom_speicher import AnlagenStromSpeicher


class AnlageStromSpeicherIO(BaseModel):
    ma_st_rnummer: Annotated[str, AfterValidator(lambda x: validate_mastr_id(x, "SSE"))]
    registrierungsdatum: Annotated[date, PlainValidator(xml_date_to_date)]
    datum_letzte_aktualisierung: Annotated[date, PlainValidator(xml_date_to_date)]
    nutzbare_speicherkapazitaet: float | None
    verknuepfte_einheiten_ma_st_rnummern: Annotated[
        list[str],
        PlainValidator(lambda x: unpack_list(x)),
        AfterValidator(lambda x: [validate_mastr_id(y, "SEE") for y in x]),
        Len(min_length=1),
    ]
    anlage_betriebsstatus: Annotated[
        AnlageStromSpeicherAnlageBetriebsstatus,
        BeforeValidator(
            lambda x: map_str_enum(x, AnlageStromSpeicherAnlageBetriebsstatus)
        ),
    ]

    @classmethod
    def from_xml(cls, value: AnlagenStromSpeicher.AnlageStromSpeicher):
        """Convert an XML AnlageStromSpeicher dataclass to a Pydantic object."""
        return cls(
            ma_st_rnummer=value.ma_st_rnummer,
            registrierungsdatum=value.registrierungsdatum,
            datum_letzte_aktualisierung=value.datum_letzte_aktualisierung,
            nutzbare_speicherkapazitaet=value.nutzbare_speicherkapazitaet,
            verknuepfte_einheiten_ma_st_rnummern=value.verknuepfte_einheiten_ma_st_rnummern,
            anlage_betriebsstatus=value.anlage_betriebsstatus,
        )
