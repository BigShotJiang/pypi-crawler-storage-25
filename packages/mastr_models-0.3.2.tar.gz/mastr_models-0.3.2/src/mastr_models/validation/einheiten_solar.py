from typing import Annotated

from pydantic import BeforeValidator

from mastr_models.enum.einheiten_solar import (
    EinheitSolarArtDerSolaranlage,
    EinheitSolarHauptausrichtung,
    EinheitSolarHauptausrichtungNeigungswinkel,
    EinheitSolarLeistungsbegrenzung,
    EinheitSolarNebenausrichtung,
    EinheitSolarNebenausrichtungNeigungswinkel,
    EinheitSolarNutzungsbereich,
)
from mastr_models.utils import (
    ensure_one,
    ensure_one_or_none,
    map_bool_enum,
    map_str_enum,
)
from mastr_models.v25_1_1.einheiten_solar import EinheitenSolar
from mastr_models.validation.stromerzeugung.solar import (
    StromerzeugungseinheitIO,
)


class EinheitSolarIO(StromerzeugungseinheitIO):
    zugeordnete_wirkleistung_wechselrichter: float | None
    anzahl_module: int | None
    art_der_solaranlage: Annotated[
        EinheitSolarArtDerSolaranlage | None,
        BeforeValidator(lambda x: map_str_enum(x, EinheitSolarArtDerSolaranlage)),
    ]
    leistungsbegrenzung: Annotated[
        EinheitSolarLeistungsbegrenzung | None,
        BeforeValidator(lambda x: map_str_enum(x, EinheitSolarLeistungsbegrenzung)),
    ]
    einheitliche_ausrichtung_und_neigungswinkel: Annotated[
        bool | None, BeforeValidator(map_bool_enum)
    ]
    hauptausrichtung: Annotated[
        EinheitSolarHauptausrichtung | None,
        BeforeValidator(lambda x: map_str_enum(x, EinheitSolarHauptausrichtung)),
    ]
    hauptausrichtung_neigungswinkel: Annotated[
        EinheitSolarHauptausrichtungNeigungswinkel | None,
        BeforeValidator(
            lambda x: map_str_enum(x, EinheitSolarHauptausrichtungNeigungswinkel)
        ),
    ]
    nebenausrichtung: Annotated[
        EinheitSolarNebenausrichtung | None,
        BeforeValidator(lambda x: map_str_enum(x, EinheitSolarNebenausrichtung)),
    ]
    nebenausrichtung_neigungswinkel: Annotated[
        EinheitSolarNebenausrichtungNeigungswinkel | None,
        BeforeValidator(
            lambda x: map_str_enum(x, EinheitSolarNebenausrichtungNeigungswinkel)
        ),
    ]
    nutzungsbereich: Annotated[
        EinheitSolarNutzungsbereich | None,
        BeforeValidator(lambda x: map_str_enum(x, EinheitSolarNutzungsbereich)),
    ]
    buergerenergie: Annotated[bool | None, BeforeValidator(map_bool_enum)]
    speicher_am_gleichen_ort: Annotated[bool | None, BeforeValidator(map_bool_enum)]
    in_anspruch_genommene_flaeche: float | None
    art_der_flaeche_ids: str | None
    in_anspruch_genommene_ackerflaeche: float | None

    @classmethod
    def from_xml(cls, value: EinheitenSolar.EinheitSolar):
        """Convert an XML object to a Pydantic object."""
        return cls(
            einheit_mastr_nummer=ensure_one(value.einheit_mastr_nummer),
            name_stromerzeugungseinheit=ensure_one(value.name_stromerzeugungseinheit),
            lokation_id=ensure_one_or_none(value.lokation_ma_st_rnummer),
            land=ensure_one(value.land),
            bundesland=ensure_one_or_none(value.bundesland),
            landkreis=ensure_one_or_none(value.landkreis),
            gemeinde=ensure_one_or_none(value.gemeinde),
            gemeindeschluessel=ensure_one_or_none(value.gemeindeschluessel),
            postleitzahl=ensure_one_or_none(value.postleitzahl),
            strasse=ensure_one_or_none(value.strasse),
            gemarkung=ensure_one_or_none(value.gemarkung),
            flur_flurstuecknummern=ensure_one_or_none(value.flur_flurstuecknummern),
            strasse_nicht_gefunden=ensure_one_or_none(value.strasse_nicht_gefunden),
            hausnummer=ensure_one_or_none(value.hausnummer),
            hausnummer_nv=ensure_one_or_none(value.hausnummer_nv),
            hausnummer_nicht_gefunden=ensure_one_or_none(
                value.hausnummer_nicht_gefunden
            ),
            adresszusatz=ensure_one_or_none(value.adresszusatz),
            ort=ensure_one_or_none(value.ort),
            laengengrad=ensure_one_or_none(value.laengengrad),
            breitengrad=ensure_one_or_none(value.breitengrad),
            registrierungsdatum=ensure_one_or_none(value.registrierungsdatum),
            inbetriebnahmedatum=ensure_one_or_none(value.inbetriebnahmedatum),
            datum_endgueltige_stilllegung=ensure_one_or_none(
                value.datum_endgueltige_stilllegung
            ),
            datum_beginn_voruebergehende_stilllegung=ensure_one_or_none(
                value.datum_beginn_voruebergehende_stilllegung
            ),
            datum_wiederaufnahme_betrieb=ensure_one_or_none(
                value.datum_wiederaufnahme_betrieb
            ),
            geplantes_inbetriebnahmedatum=ensure_one_or_none(
                value.geplantes_inbetriebnahmedatum
            ),
            datum_letzte_aktualisierung=ensure_one_or_none(
                value.datum_letzte_aktualisierung
            ),
            datum_des_betreiberwechsels=ensure_one_or_none(
                value.datum_des_betreiberwechsels
            ),
            datum_registrierung_des_betreiberwechsels=ensure_one_or_none(
                value.datum_registrierung_des_betreiberwechsels
            ),
            netzbetreiberpruefung_datum=ensure_one_or_none(
                value.netzbetreiberpruefung_datum
            ),
            anlagenbetreiber=ensure_one_or_none(value.anlagenbetreiber_mastr_nummer),
            alt_anlagenbetreiber=ensure_one_or_none(
                value.alt_anlagenbetreiber_mastr_nummer
            ),
            bestandsanlage_mastr_nummer=ensure_one_or_none(
                value.bestandsanlage_mastr_nummer
            ),
            nicht_vorhanden_in_migrierten_einheiten=ensure_one_or_none(
                value.nicht_vorhanden_in_migrierten_einheiten
            ),
            BNetzA_id=ensure_one_or_none(value.kraftwerksnummer),
            w_eic=ensure_one_or_none(value.weic),
            w_eic_display_name=ensure_one_or_none(value.weic_display_name),
            kraftwerksnummer=ensure_one_or_none(value.kraftwerksnummer),
            kraftwerksnummer_nv=ensure_one_or_none(value.kraftwerksnummer_nv),
            weic_nv=ensure_one_or_none(value.weic_nv),
            eeg_ma_st_rnummer=ensure_one_or_none(value.eeg_ma_st_rnummer),
            gen_mastr_nummer=ensure_one_or_none(value.gen_mastr_nummer),
            energietraeger=ensure_one_or_none(value.energietraeger),
            bruttoleistung=ensure_one_or_none(value.bruttoleistung),
            nettonennleistung=ensure_one_or_none(value.nettonennleistung),
            anschluss_an_hoechst_oder_hoch_spannung=ensure_one_or_none(
                value.anschluss_an_hoechst_oder_hoch_spannung
            ),
            fernsteuerbarkeit_nb=ensure_one_or_none(value.fernsteuerbarkeit_nb),
            fernsteuerbarkeit_dv=ensure_one_or_none(value.fernsteuerbarkeit_dv),
            einspeisungsart=ensure_one_or_none(value.einspeisungsart),
            einsatzverantwortlicher=ensure_one_or_none(value.einsatzverantwortlicher),
            einheit_systemstatus=ensure_one_or_none(value.einheit_systemstatus),
            einheit_betriebsstatus=ensure_one_or_none(value.einheit_betriebsstatus),
            netzbetreiberpruefung_status=ensure_one_or_none(
                value.netzbetreiberpruefung_status
            ),
            zugeordnete_wirkleistung_wechselrichter=ensure_one_or_none(
                value.zugeordnete_wirkleistung_wechselrichter
            ),
            anzahl_module=ensure_one_or_none(value.anzahl_module),
            art_der_solaranlage=ensure_one_or_none(value.art_der_solaranlage),
            leistungsbegrenzung=ensure_one_or_none(value.leistungsbegrenzung),
            einheitliche_ausrichtung_und_neigungswinkel=ensure_one_or_none(
                value.einheitliche_ausrichtung_und_neigungswinkel
            ),
            hauptausrichtung=ensure_one_or_none(value.hauptausrichtung),
            hauptausrichtung_neigungswinkel=ensure_one_or_none(
                value.hauptausrichtung_neigungswinkel
            ),
            nebenausrichtung=ensure_one_or_none(value.nebenausrichtung),
            nebenausrichtung_neigungswinkel=ensure_one_or_none(
                value.nebenausrichtung_neigungswinkel
            ),
            nutzungsbereich=ensure_one_or_none(value.nutzungsbereich),
            buergerenergie=ensure_one_or_none(value.buergerenergie),
            speicher_am_gleichen_ort=ensure_one_or_none(value.speicher_am_gleichen_ort),
            in_anspruch_genommene_flaeche=ensure_one_or_none(
                value.in_anspruch_genommene_flaeche
            ),
            art_der_flaeche_ids=ensure_one_or_none(value.art_der_flaeche_ids),
            in_anspruch_genommene_ackerflaeche=ensure_one_or_none(
                value.in_anspruch_genommene_ackerflaeche
            ),
        )
