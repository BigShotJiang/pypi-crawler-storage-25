from datetime import date
from typing import Annotated

from pydantic import (
    BeforeValidator,
    PlainValidator,
    StringConstraints,
)

from mastr_models.enum.anlagen_eeg_solar import (
    AnlageEegSolarAnlageBetriebsstatus,
)
from mastr_models.utils import (
    map_bool_enum,
    map_str_enum,
    xml_date_to_date,
)
from mastr_models.v24_2.anlagen_eeg_solar import AnlagenEegSolar as AnlagenEegSolar_v24_2
from mastr_models.v25_1_1.anlagen_eeg_solar import (
    AnlagenEegSolar as AnlagenEegSolar_v25_1_1,
)
from mastr_models.validation.anlagen_eeg import AnlageEegIO


class AnlageEegSolarIO(AnlageEegIO):
    inanspruchnahme_zahlung_nach_eeg: Annotated[
        bool | None, BeforeValidator(map_bool_enum)
    ]
    anlagenkennziffer_anlagenregister: Annotated[
        str | None, StringConstraints(max_length=255)
    ]
    anlagenkennziffer_anlagenregister_nv: Annotated[
        bool | None, BeforeValidator(map_bool_enum)
    ]
    installierte_leistung: float | None
    registrierungsnummer_pv_meldeportal: Annotated[
        str | None, StringConstraints(max_length=255)
    ]
    registrierungsnummer_pv_meldeportal_nv: Annotated[
        bool | None, BeforeValidator(map_bool_enum)
    ]
    mieterstrom_zugeordnet: Annotated[bool | None, BeforeValidator(map_bool_enum)]
    mieterstrom_meldedatum: Annotated[date | None, PlainValidator(xml_date_to_date)]
    mieterstrom_erste_zuordnung_zuschlag: Annotated[
        date | None, PlainValidator(xml_date_to_date)
    ]
    zugeordnete_gebotsmenge: float | None
    anlage_betriebsstatus: Annotated[
        AnlageEegSolarAnlageBetriebsstatus | None,
        BeforeValidator(lambda x: map_str_enum(x, AnlageEegSolarAnlageBetriebsstatus)),
    ]

    @classmethod
    def from_xml(
        cls,
        value: AnlagenEegSolar_v24_2.AnlageEegSolar
        | AnlagenEegSolar_v25_1_1.AnlageEegSolar,
    ):
        """Convert an XML object to a Pydantic object."""
        return cls(
            registrierungsdatum=value.registrierungsdatum,
            datum_letzte_aktualisierung=value.datum_letzte_aktualisierung,
            eeg_inbetriebnahmedatum=value.eeg_inbetriebnahmedatum,
            eeg_ma_st_rnummer=value.eeg_ma_st_rnummer,
            anlagenschluessel_eeg=value.anlagenschluessel_eeg,
            ausschreibung_zuschlag=value.ausschreibung_zuschlag,
            zuschlagsnummer=value.zuschlagsnummer,
            verknuepfte_einheiten_ma_st_rnummern_list=value.verknuepfte_einheiten_ma_st_rnummern,
            # Attributes specific to this class.
            inanspruchnahme_zahlung_nach_eeg=value.inanspruchnahme_zahlung_nach_eeg,
            anlagenkennziffer_anlagenregister=value.anlagenkennziffer_anlagenregister,
            anlagenkennziffer_anlagenregister_nv=value.anlagenkennziffer_anlagenregister_nv,
            installierte_leistung=value.installierte_leistung,
            registrierungsnummer_pv_meldeportal=value.registrierungsnummer_pv_meldeportal,
            registrierungsnummer_pv_meldeportal_nv=value.registrierungsnummer_pv_meldeportal_nv,
            mieterstrom_zugeordnet=value.mieterstrom_zugeordnet,
            mieterstrom_meldedatum=value.mieterstrom_meldedatum,
            mieterstrom_erste_zuordnung_zuschlag=value.mieterstrom_erste_zuordnung_zuschlag,
            zugeordnete_gebotsmenge=value.zugeordnete_gebotsmenge,
            anlage_betriebsstatus=value.anlage_betriebsstatus,
        )
