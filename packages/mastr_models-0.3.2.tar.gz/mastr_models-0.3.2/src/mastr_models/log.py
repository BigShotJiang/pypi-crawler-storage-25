from pathlib import Path

from loguru import logger as LOG  # noqa: F401

THIS = Path(__file__).parent.parent.parent

ROOT = THIS.parent.parent
