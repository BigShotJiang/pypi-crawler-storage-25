from mastr_models.enum.einheiten_solar import EinheitSolarArtDerSolaranlage as Target
from mastr_models.utils import map_str_enum
from mastr_models.v25_1_1.einheiten_solar import EinheitSolarArtDerSolaranlage as Source


def test_map_str_enum():
    assert map_str_enum(Source.VALUE_2484, Target) == Target.VALUE_2484
    assert map_str_enum(None, Target) is None
