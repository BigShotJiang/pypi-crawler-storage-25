from pathlib import Path

from pydantic import ValidationError
from pytest import mark
from xsdata.formats.dataclass.parsers import XmlParser

from mastr_models.log import ROOT
from mastr_models.v24_2.anlagen_kwk import AnlagenKwk
from mastr_models.validation.anlagen_kwk import AnlageKwkIO

_KWK_2401 = (
    ROOT
    / "modifications"
    / "data"
    / "Gesamtdatenexport_20240101_23.1"
    / "AnlagenKwk.xml"
)
_KWK_2504 = (
    ROOT
    / "modifications"
    / "data"
    / "Gesamtdatenexport_20250401_24.2"
    / "AnlagenKwk.xml"
)


@mark.parametrize("path_", [_KWK_2401, _KWK_2504], ids=["01.2024", "04.2025"])
def test_kwk(path_: Path):
    """Read and parse MaStR KWK XML."""

    with open(path_, "r", encoding="utf-16le") as xml_file:
        result = XmlParser().from_string(xml_file.read(), AnlagenKwk)

    for x in result.anlage_kwk:
        try:
            AnlageKwkIO.model_validate(x.__dict__)
        except ValidationError as e:
            print(f"Validation error for {x.kwk_mastr_nummer}: {e}")
