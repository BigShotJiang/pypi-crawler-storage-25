from pathlib import Path

from pytest import mark
from xsdata.formats.dataclass.parsers import XmlParser

from mastr_models.log import THIS
from mastr_models.v24_2.anlagen_eeg_solar import AnlagenEegSolar
from mastr_models.v25_1_1.anlagen_eeg_speicher import AnlagenEegSpeicher
from mastr_models.v25_1_1.anlagen_strom_speicher import AnlagenStromSpeicher
from mastr_models.v25_1_1.einheiten_solar import EinheitenSolar
from mastr_models.v25_1_1.einheiten_strom_speicher import EinheitenStromSpeicher
from mastr_models.validation.anlagen_eeg_solar import AnlageEegSolarIO
from mastr_models.validation.anlagen_eeg_speicher import AnlageEegSpeicherIO
from mastr_models.validation.anlagen_strom_speicher import AnlageStromSpeicherIO
from mastr_models.validation.einheiten_solar import EinheitSolarIO
from mastr_models.validation.einheiten_strom_speicher import EinheitStromSpeicherIO

EINHEITEN_SOLAR = [
    x
    for x in (THIS / "data" / "Gesamtdatenexport_20250701_25.1").iterdir()
    if x.name.startswith("EinheitenSolar_")
]


@mark.parametrize("path_", EINHEITEN_SOLAR, ids=[x.name for x in EINHEITEN_SOLAR])
def test_einheiten_solar(path_: Path) -> None:
    with open(path_, "r", encoding="utf-16le") as xml_file:
        raw = XmlParser().from_string(xml_file.read(), EinheitenSolar)

        [EinheitSolarIO.from_xml(e) for e in raw.einheit_solar]


EINHEITEN_STROM_SPEICHER = [
    x
    for x in (THIS / "data" / "Gesamtdatenexport_20250701_25.1").iterdir()
    if x.name.startswith("EinheitenStromSpeicher_")
]


@mark.parametrize(
    "path_", EINHEITEN_STROM_SPEICHER, ids=[x.name for x in EINHEITEN_STROM_SPEICHER]
)
def test_einheiten_strom_speicher(path_: Path) -> None:
    with open(path_, "r", encoding="utf-16le") as xml_file:
        raw = XmlParser().from_string(xml_file.read(), EinheitenStromSpeicher)

        [EinheitStromSpeicherIO.from_xml(e) for e in raw.einheit_strom_speicher]


ANLAGEN_EEG_SOLAR = [
    x
    for x in (THIS / "data" / "Gesamtdatenexport_20250401_24.2").iterdir()
    if x.name.startswith("AnlagenEegSolar_")
]


@mark.parametrize("path_", ANLAGEN_EEG_SOLAR, ids=[x.name for x in ANLAGEN_EEG_SOLAR])
def test_anlagen_eeg_solar(path_: Path) -> None:
    with open(path_, "r", encoding="utf-16le") as xml_file:
        raw = XmlParser().from_string(xml_file.read(), AnlagenEegSolar)

        [AnlageEegSolarIO.from_xml(e) for e in raw.anlage_eeg_solar]


ANLAGEN_STROM_SPEICHER = [
    x
    for x in (THIS / "data" / "Gesamtdatenexport_20250701_25.1").iterdir()
    if x.name.startswith("AnlagenStromSpeicher_")
]


@mark.parametrize(
    "path_", ANLAGEN_STROM_SPEICHER, ids=[x.name for x in ANLAGEN_STROM_SPEICHER]
)
def test_anlagen_strom_speicher(path_: Path) -> None:
    with open(path_, "r", encoding="utf-16le") as xml_file:
        raw = XmlParser().from_string(xml_file.read(), AnlagenStromSpeicher)

        [AnlageStromSpeicherIO.from_xml(e) for e in raw.anlage_strom_speicher]


ANLAGEN_EEG_SPEICHER = [
    x
    for x in (THIS / "data" / "Gesamtdatenexport_20250701_25.1").iterdir()
    if x.name.startswith("AnlagenEegSpeicher_")
]


@mark.parametrize(
    "path_", ANLAGEN_EEG_SPEICHER, ids=[x.name for x in ANLAGEN_EEG_SPEICHER]
)
def test_anlagen_eeg_speicher(path_: Path) -> None:
    with open(path_, "r", encoding="utf-16le") as xml_file:
        raw = XmlParser().from_string(xml_file.read(), AnlagenEegSpeicher)

        [AnlageEegSpeicherIO.from_xml(e) for e in raw.anlage_eeg_speicher]
