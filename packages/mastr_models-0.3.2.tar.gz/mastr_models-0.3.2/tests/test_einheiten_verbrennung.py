"""Work with MaStR XML files for thermal units."""

from dataclasses import asdict
from enum import Enum
from json import dump

from xsdata.formats.dataclass.parsers import XmlParser

from mastr_models.log import THIS
from mastr_models.utils import ROBUST_CONFIG
from mastr_models.v25_2.einheiten_verbrennung import EinheitenVerbrennung
from mastr_models.validation.einheiten_verbrennung import xml_to_pydantic


def custom_serializer(obj):
    if hasattr(obj, "__dataclass_fields__"):  # Check if it's a dataclass
        return asdict(obj)
    elif isinstance(obj, Enum):  # Check if it's an Enum
        return obj.value  # Serialize the Enum as its value
    raise TypeError(f"Object of type {type(obj).__name__} is not JSON serializable")


PATH_ = THIS / "data" / "Gesamtdatenexport_20251001_25.2" / "EinheitenVerbrennung.xml"


def test():
    """Read and parse MaStR XML."""
    result = XmlParser(ROBUST_CONFIG).from_path(PATH_, EinheitenVerbrennung)

    [xml_to_pydantic(x) for x in result.einheit_verbrennung]


def test_xml2json():
    """Export some units to a JSON file."""
    result = XmlParser(ROBUST_CONFIG).from_path(PATH_, EinheitenVerbrennung)

    with open("SomeThermalUnits.json", "w") as json_file:
        dump(
            list(
                asdict(x)
                for x in result.einheit_verbrennung
                if x.einheit_mastr_nummer[0]
                in {
                    "SEE953784241926",
                    "SEE987913244618",
                    "SEE996431301710",
                    "SEE923244371197",
                    "SEE936196276359",
                    "SEE900403199748",
                    "SEE952340290002",
                    "SEE994281911899",
                    "SEE998028907619",
                    "SEE991220769276",
                    "SEE908658611688",
                    "SEE942956157011",
                    "SEE926356200836",
                    "SEE913862454280",  # storage
                    "SEE969616938483",  #
                    "SEE978267393503",  #
                    "SEE950518521354",  #
                    "SEE938035990372",  #
                    "SEE983807255883",  #
                }
            ),
            json_file,
            default=custom_serializer,
        )
