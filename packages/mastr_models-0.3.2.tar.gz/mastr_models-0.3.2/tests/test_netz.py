from pathlib import Path

from pydantic import ValidationError
from pytest import mark
from xsdata.formats.dataclass.parsers import XmlParser

from mastr_models.log import THIS
from mastr_models.v25_2.netze import Netze
from mastr_models.validation.netze import NetzIO

_KWK_2504 = THIS / "data" / "Gesamtdatenexport_20260101_25.2" / "Netze.xml"


@mark.parametrize("path_", [_KWK_2504], ids=["01.2026"])
def test(path_: Path):
    """Read and parse MaStR KWK XML."""

    with open(path_, "r", encoding="utf-16le") as xml_file:
        result = XmlParser().from_string(xml_file.read(), Netze)

    for x in result.netz:
        try:
            NetzIO.model_validate(x.__dict__)
        except ValidationError as e:
            print(f"Validation error for {x.mastr_nummer}: {e}")
