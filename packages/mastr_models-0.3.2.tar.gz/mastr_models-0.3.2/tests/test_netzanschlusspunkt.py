from pathlib import Path

from pydantic import ValidationError
from pytest import mark
from xsdata.formats.dataclass.parsers import XmlParser

from mastr_models.log import THIS
from mastr_models.v25_2.netzanschlusspunkte import Netzanschlusspunkte
from mastr_models.validation.netzanschlusspunkte import NetzanschlusspunktIO

FILES = [
    x
    for x in (THIS / "data" / "Gesamtdatenexport_20260101_25.2").iterdir()
    if x.name.startswith("Netzanschlusspunkte_")
]


@mark.parametrize("path_", FILES, ids=[x.name for x in FILES])
def test(path_: Path):
    """Read and parse MaStR KWK XML."""

    with open(path_, "r", encoding="utf-16le") as xml_file:
        result = XmlParser().from_string(xml_file.read(), Netzanschlusspunkte)

    for x in result.netzanschlusspunkt:
        try:
            NetzanschlusspunktIO.model_validate(x.__dict__)
        except ValidationError as e:
            print(f"Validation error for {x.netzanschlusspunkt_mastr_nummer}: {e}")
