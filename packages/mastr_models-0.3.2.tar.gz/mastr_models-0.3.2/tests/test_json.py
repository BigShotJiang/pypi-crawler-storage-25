from mastr_models.types.json import ListAsJSON


def test_list():
    assert ListAsJSON(list[int]).process_bind_param([1, 2, 3], None) == [1, 2, 3]
    assert ListAsJSON(list[int]).process_bind_param((1, 2, 3), None) == [1, 2, 3]
    assert ListAsJSON(list[str]).process_bind_param(["1", "2"], None) == ["1", "2"]
    assert ListAsJSON(list[str]).process_bind_param(("1", "2"), None) == ["1", "2"]
