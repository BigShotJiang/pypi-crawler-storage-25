from pathlib import Path

from pytest import mark
from xsdata.formats.dataclass.parsers import XmlParser

from mastr_models.log import THIS
from mastr_models.v25_2.marktakteure import Marktakteure
from mastr_models.validation.marktakteure import xml_to_pydantic

_FILES = [
    x
    for x in (THIS / "data" / "Gesamtdatenexport_20251001_25.2").iterdir()
    if x.name.startswith("Marktakteure_")
]


@mark.parametrize("path_", _FILES, ids=[x.name for x in _FILES])
def test(path_: Path) -> None:
    result = XmlParser().from_path(path_, Marktakteure)

    [xml_to_pydantic(x) for x in result.marktakteur]
