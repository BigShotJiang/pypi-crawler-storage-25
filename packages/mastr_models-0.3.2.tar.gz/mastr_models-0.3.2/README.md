
# `mastr-models`: Pydantic and SQLAlchemy models for Marktstammdatenregister (MaStR) data

Read MaStR XML files and map them to Pydantic models.

![MaStR official models](./img/models.png)

![How MaStR units connects to grids](./img/connection.png)

## Set up Python development environment

```console
uv sync  --all-groups --extra orm
```

## Generate Python dataclass from MaStR XML Schema

```console
xsdata generate --package mastr_models.v25_2 --union-type 'data/MaStR_xsd_25.2/'
```
