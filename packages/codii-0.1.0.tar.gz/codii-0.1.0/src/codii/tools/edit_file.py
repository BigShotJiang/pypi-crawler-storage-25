"""edit_file tool — old_str/new_str replacement only."""
from __future__ import annotations

from pathlib import Path
from typing import Any

from codii.connection.base import ToolDefinition
from codii.tools.base import ToolResult, timed_result


def _unescape(s: str) -> str:
    """Convert literal \\n \\t \\r to real characters when no real newlines are present."""
    if '\n' not in s and '\\n' in s:
        return s.replace('\\n', '\n').replace('\\t', '\t').replace('\\r', '\r')
    return s


class EditFileTool:
    name = "edit_file"
    description = (
        "Edit an existing file. "
        "Supply old_str (exact text to replace) and new_str (replacement)."
    )

    def definition(self) -> ToolDefinition:
        return ToolDefinition(
            name=self.name,
            description=self.description,
            parameters={
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "File path relative to workspace root.",
                    },
                    "old_str": {
                        "type": "string",
                        "description": (
                            "Exact text to find and replace (copy-paste from read_file output)."
                        ),
                    },
                    "new_str": {
                        "type": "string",
                        "description": "Replacement text. Omit or empty-string to delete old_str.",
                    },
                },
                "required": ["path"],
            },
        )

    @timed_result
    async def execute(self, arguments: dict[str, Any], workspace: Path) -> ToolResult:
        raw_path = arguments.get("path", "")
        target = (workspace / raw_path).resolve()

        try:
            target.relative_to(workspace.resolve())
        except ValueError:
            return ToolResult(
                success=False, output="", error=f"Path '{raw_path}' is outside the workspace."
            )

        if not target.exists():
            return ToolResult(success=False, output="", error=f"File not found: {raw_path}")

        try:
            original = target.read_text(encoding="utf-8", errors="replace")
        except OSError as e:
            return ToolResult(success=False, output="", error=str(e))

        # ── old_str / new_str path ────────────────────────────────────────────
        raw_old = arguments.get("old_str")
        if raw_old is not None:
            old_str = _unescape(raw_old)
            new_str = _unescape(arguments.get("new_str") or "")

            # Pass 1: exact match
            if old_str in original:
                new_content = original.replace(old_str, new_str, 1)
                try:
                    tmp = target.with_suffix(target.suffix + ".tmp")
                    tmp.write_text(new_content, encoding="utf-8")
                    tmp.replace(target)
                    return ToolResult(success=True, output=f"Edited: {raw_path}")
                except OSError as e:
                    return ToolResult(success=False, output="", error=str(e))

            # Pass 2: whitespace-normalised match (trailing spaces / CRLF tolerance)
            norm_orig = "\n".join(ln.rstrip() for ln in original.splitlines())
            norm_old  = "\n".join(ln.rstrip() for ln in old_str.splitlines())
            if norm_old and norm_old in norm_orig:
                orig_lines = original.splitlines(keepends=True)
                old_lines  = old_str.splitlines()
                n = len(old_lines)
                for i in range(len(orig_lines) - n + 1):
                    segment = "".join(orig_lines[i : i + n])
                    if "\n".join(ln.rstrip() for ln in segment.splitlines()) == norm_old:
                        new_content = (
                            "".join(orig_lines[:i])
                            + new_str
                            + ("" if new_str.endswith("\n") else "\n")
                            + "".join(orig_lines[i + n :])
                        )
                        try:
                            tmp = target.with_suffix(target.suffix + ".tmp")
                            tmp.write_text(new_content, encoding="utf-8")
                            tmp.replace(target)
                            return ToolResult(success=True, output=f"Edited: {raw_path}")
                        except OSError as e:
                            return ToolResult(success=False, output="", error=str(e))

            # Not found in either pass
            snippet = "\n".join(
                f"{i+1}: {ln}" for i, ln in enumerate(original.splitlines()[:30])
            )
            return ToolResult(
                success=False, output="",
                error=(
                    f"old_str not found in '{raw_path}'.\n"
                    f"First 30 lines of the file:\n```\n{snippet}\n```\n"
                    "Re-read the file, copy the EXACT text you want to change, and resubmit."
                ),
            )

        # ── diff fallback removed ─────────────────────────────────────────────
        if arguments.get("diff") is not None:
            return ToolResult(
                success=False, output="",
                error=(
                    "diff format removed — use old_str/new_str instead:\n"
                    f'edit_file("{raw_path}", old_str="[exact text to replace]", new_str="[replacement]")'
                ),
            )
        return ToolResult(
            success=False, output="",
            error="old_str is required. Supply the exact text to replace.",
        )
