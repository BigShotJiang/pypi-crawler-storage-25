"""todo tool — manage .codii/todos.jsonl."""
from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from codii.connection.base import ToolDefinition
from codii.tools.base import ToolResult, timed_result

_VALID_STATUSES = {"pending", "active", "completed", "blocked"}


def _todos_path(workspace: Path) -> Path:
    return workspace / ".codii" / "todos.jsonl"


def _load_todos(workspace: Path) -> list[dict[str, Any]]:
    p = _todos_path(workspace)
    if not p.exists():
        return []
    todos = []
    for line in p.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line:
            try:
                todos.append(json.loads(line))
            except json.JSONDecodeError:
                pass
    return todos


def _save_todos(workspace: Path, todos: list[dict[str, Any]]) -> None:
    p = _todos_path(workspace)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(".tmp")
    tmp.write_text(
        "\n".join(json.dumps(t) for t in todos) + "\n",
        encoding="utf-8",
    )
    tmp.replace(p)


class TodoTool:
    name = "todo"
    description = "Manage the task todo list. Operations: list, add, update, complete."

    def definition(self) -> ToolDefinition:
        return ToolDefinition(
            name=self.name,
            description=self.description,
            parameters={
                "type": "object",
                "properties": {
                    "operation": {
                        "type": "string",
                        "enum": ["list", "add", "update", "complete"],
                        "description": "Operation to perform.",
                    },
                    "description": {
                        "type": "string",
                        "description": "Todo description (required for 'add').",
                    },
                    "id": {
                        "type": "string",
                        "description": "Todo ID (required for 'update' and 'complete').",
                    },
                    "status": {
                        "type": "string",
                        "enum": ["pending", "active", "completed", "blocked"],
                        "description": "New status (required for 'update').",
                    },
                },
                "required": ["operation"],
            },
        )

    @timed_result
    async def execute(self, arguments: dict[str, Any], workspace: Path) -> ToolResult:
        op = arguments.get("operation", "list")

        match op:
            case "list":
                todos = _load_todos(workspace)
                if not todos:
                    return ToolResult(success=True, output="No todos.")
                lines = [
                    f"[{t['status']}] {t['id'][:8]} — {t['description']}"
                    for t in todos
                ]
                return ToolResult(success=True, output="\n".join(lines))

            case "add":
                desc = arguments.get("description", "").strip()
                if not desc:
                    return ToolResult(success=False, output="", error="'description' is required.")
                todo = {
                    "id": str(uuid.uuid4()),
                    "status": "pending",
                    "description": desc,
                    "created_at": datetime.now(timezone.utc).isoformat(),
                }
                todos = _load_todos(workspace)
                todos.append(todo)
                _save_todos(workspace, todos)
                return ToolResult(success=True, output=f"Added: {todo['id'][:8]} — {desc}")

            case "update":
                todo_id = arguments.get("id", "")
                status = arguments.get("status", "")
                if status not in _VALID_STATUSES:
                    return ToolResult(
                        success=False, output="", error=f"Invalid status: {status!r}"
                    )
                todos = _load_todos(workspace)
                for t in todos:
                    if t["id"].startswith(todo_id):
                        t["status"] = status
                        _save_todos(workspace, todos)
                        return ToolResult(success=True, output=f"Updated {t['id'][:8]} → {status}")
                return ToolResult(success=False, output="", error=f"Todo not found: {todo_id}")

            case "complete":
                todo_id = arguments.get("id", "")
                todos = _load_todos(workspace)
                for t in todos:
                    if t["id"].startswith(todo_id):
                        t["status"] = "completed"
                        _save_todos(workspace, todos)
                        return ToolResult(
                            success=True, output=f"Completed: {t['id'][:8]} — {t['description']}"
                        )
                return ToolResult(success=False, output="", error=f"Todo not found: {todo_id}")

            case _:
                return ToolResult(success=False, output="", error=f"Unknown operation: {op!r}")
