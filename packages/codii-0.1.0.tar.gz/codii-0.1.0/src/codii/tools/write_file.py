"""write_file tool — atomic write via Path.replace()."""
from __future__ import annotations

from pathlib import Path
from typing import Any

from codii.connection.base import ToolDefinition
from codii.tools.base import ToolResult, timed_result


def _unescape(s: str) -> str:
    """Convert literal \\n \\t \\r to real characters when no real newlines are present."""
    if '\n' not in s and '\\n' in s:
        return s.replace('\\n', '\n').replace('\\t', '\t').replace('\\r', '\r')
    return s


class WriteFileTool:
    name = "write_file"
    description = "Write content to a file, creating it if it doesn't exist. Overwrites existing content."

    def definition(self) -> ToolDefinition:
        return ToolDefinition(
            name=self.name,
            description=self.description,
            parameters={
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "File path relative to workspace root.",
                    },
                    "content": {
                        "type": "string",
                        "description": "Content to write to the file.",
                    },
                },
                "required": ["path", "content"],
            },
        )

    @timed_result
    async def execute(self, arguments: dict[str, Any], workspace: Path) -> ToolResult:
        raw_path = arguments.get("path", "")
        content = _unescape(arguments.get("content", ""))
        if not content.strip():
            return ToolResult(
                success=False, output="",
                error="write_file received empty content. Provide the complete file content.",
            )
        target = (workspace / raw_path).resolve()

        try:
            target.relative_to(workspace.resolve())
        except ValueError:
            return ToolResult(
                success=False, output="", error=f"Path '{raw_path}' is outside the workspace."
            )

        try:
            target.parent.mkdir(parents=True, exist_ok=True)
            tmp = target.with_suffix(target.suffix + ".tmp")
            tmp.write_text(content, encoding="utf-8")
            tmp.replace(target)
            byte_count = len(content.encode("utf-8"))
            return ToolResult(success=True, output=f"Written: {raw_path} ({byte_count} bytes)")
        except OSError as e:
            return ToolResult(success=False, output="", error=str(e))
