"""bash tool — run shell commands with timeout."""
from __future__ import annotations

import asyncio
import re
import sys
from pathlib import Path
from typing import Any

from codii.connection.base import ToolDefinition
from codii.tools.base import ToolResult, timed_result

_DEFAULT_TIMEOUT = 60
_MAX_TIMEOUT = 300

# Interactive CLI programs that block waiting for user input.
_INTERACTIVE_COMMANDS_RE = re.compile(
    r"^(?:npm\s+(?:init|create)|git\s+commit(?!\s+-m)\b|python3?\s*$|node\s*$)",
    re.IGNORECASE,
)
_PYTHON_SCRIPT_RE = re.compile(r"python(?:3)?\s+([\w./\\-]+\.py)", re.IGNORECASE)


def _looks_interactive(command: str, workspace: Path) -> bool:
    """Return True if the command would block waiting for user input."""
    stripped = command.strip()
    if _INTERACTIVE_COMMANDS_RE.match(stripped):
        return True
    # Detect Python scripts that contain input() calls.
    m = _PYTHON_SCRIPT_RE.match(stripped)
    if m:
        try:
            return "input(" in (workspace / m.group(1)).read_text(encoding="utf-8", errors="replace")
        except OSError:
            pass
    return False


_MAX_OUTPUT = 32_000


class BashTool:
    name = "bash"
    description = "Run a shell command in the workspace directory. Returns stdout and stderr."

    def definition(self) -> ToolDefinition:
        return ToolDefinition(
            name=self.name,
            description=self.description,
            parameters={
                "type": "object",
                "properties": {
                    "command": {
                        "type": "string",
                        "description": "Shell command to run.",
                    },
                    "timeout": {
                        "type": "integer",
                        "description": f"Timeout in seconds (default {_DEFAULT_TIMEOUT}, max {_MAX_TIMEOUT}).",
                    },
                },
                "required": ["command"],
            },
        )

    @timed_result
    async def execute(self, arguments: dict[str, Any], workspace: Path) -> ToolResult:
        command = arguments.get("command", "")
        try:
            timeout = min(int(float(str(arguments.get("timeout") or _DEFAULT_TIMEOUT))), _MAX_TIMEOUT)
        except (ValueError, TypeError):
            timeout = _DEFAULT_TIMEOUT

        if not command.strip():
            return ToolResult(success=False, output="", error="No command provided.")

        if _looks_interactive(command, workspace):
            return ToolResult(
                success=False, output="",
                error=(
                    "Warning: this command appears to be an interactive program that requires "
                    "user input. It will hang if run non-interactively. "
                    "To verify a file was created correctly, use read_file instead of running it. "
                    "To test interactively, open a separate terminal."
                ),
            )

        # On Windows, use PowerShell so that pip, npm, python, and other tools
        # installed via user-profile package managers (Conda, nvm, pyenv) are on PATH.
        # On Unix, sh -c correctly inherits the calling process's PATH — no change needed.
        if sys.platform == "win32":
            proc = await asyncio.create_subprocess_exec(
                "powershell.exe",
                "-NoProfile", "-NonInteractive",
                "-ExecutionPolicy", "Bypass",
                "-Command", command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,
                stdin=asyncio.subprocess.DEVNULL,
                cwd=str(workspace),
            )
        else:
            proc = await asyncio.create_subprocess_exec(
                "sh", "-c", command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,
                stdin=asyncio.subprocess.DEVNULL,
                cwd=str(workspace),
            )

        try:
            stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        except asyncio.TimeoutError:
            proc.kill()
            return ToolResult(
                success=False,
                output="",
                error=f"Command timed out after {timeout}s.",
            )

        output = stdout.decode("utf-8", errors="replace")
        if len(output) > _MAX_OUTPUT:
            output = output[:_MAX_OUTPUT] + f"\n... (truncated at {_MAX_OUTPUT} chars)"

        success = proc.returncode == 0
        return ToolResult(
            success=success,
            output=output,
            error=None if success else f"Exit code: {proc.returncode}",
        )
