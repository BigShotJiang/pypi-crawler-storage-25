"""read_file tool."""
from __future__ import annotations

from pathlib import Path
from typing import Any

from codii.connection.base import ToolDefinition
from codii.tools.base import ToolResult, timed_result


class ReadFileTool:
    name = "read_file"
    description = "Read the contents of a file. Returns the file content as text."

    def definition(self) -> ToolDefinition:
        return ToolDefinition(
            name=self.name,
            description=self.description,
            parameters={
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Path to the file to read, relative to the workspace root.",
                    }
                },
                "required": ["path"],
            },
        )

    @timed_result
    async def execute(self, arguments: dict[str, Any], workspace: Path) -> ToolResult:
        raw_path = arguments.get("path", "")
        target = (workspace / raw_path).resolve()

        try:
            target.relative_to(workspace.resolve())
        except ValueError:
            return ToolResult(
                success=False,
                output="",
                error=f"Path '{raw_path}' is outside the workspace.",
            )

        if not target.exists():
            return ToolResult(success=False, output="", error=f"File not found: {raw_path}")
        if not target.is_file():
            return ToolResult(success=False, output="", error=f"Not a file: {raw_path}")

        try:
            content = target.read_text(encoding="utf-8", errors="replace")
            return ToolResult(success=True, output=content)
        except OSError as e:
            return ToolResult(success=False, output="", error=str(e))
