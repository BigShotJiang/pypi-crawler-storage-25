"""Tool protocol, ToolResult, PermissionBand."""
from __future__ import annotations

import functools
import time
from collections.abc import Awaitable, Callable
from enum import Enum
from pathlib import Path
from typing import Any, ParamSpec, Protocol, TypeVar

from pydantic import BaseModel

_P = ParamSpec("_P")
_R = TypeVar("_R", bound="ToolResult")

from codii.connection.base import ToolDefinition


class PermissionBand(Enum):
    FREE = "free"
    CONFIRMATION = "confirmation"
    FORBIDDEN = "forbidden"


class ToolResult(BaseModel):
    success: bool
    output: str
    error: str | None = None
    duration_ms: int = 0


class Tool(Protocol):
    name: str
    description: str

    def definition(self) -> ToolDefinition: ...

    def execute(self, arguments: dict[str, Any], workspace: Path) -> Awaitable[ToolResult]: ...


def classify_operation(
    operation: str,
    path: Path | None,
    workspace: Path,
) -> PermissionBand:
    """Classify a file/command operation into a permission band."""
    if path is not None:
        try:
            resolved = path.resolve()
            ws_resolved = workspace.resolve()
            # Block anything that escapes the workspace (symlink traversal, ../ etc.)
            resolved.relative_to(ws_resolved)
        except ValueError:
            return PermissionBand.FORBIDDEN

        # Block credentials/secrets paths
        sensitive = {".env", ".ssh", ".aws", ".gnupg", "secrets", "credentials"}
        if any(part in sensitive for part in resolved.parts):
            return PermissionBand.FORBIDDEN

    match operation:
        case "read" | "list":
            return PermissionBand.FREE
        case "write" | "edit":
            return PermissionBand.FREE
        case "delete":
            return PermissionBand.CONFIRMATION
        case "bash":
            return PermissionBand.CONFIRMATION
        case _:
            return PermissionBand.CONFIRMATION


def timed_result(
    fn: Callable[_P, Awaitable[_R]],
) -> Callable[_P, Awaitable[_R]]:
    """Decorator that populates duration_ms on ToolResult."""
    @functools.wraps(fn)
    async def wrapper(*args: _P.args, **kwargs: _P.kwargs) -> _R:
        start = time.monotonic()
        result = await fn(*args, **kwargs)
        elapsed = int((time.monotonic() - start) * 1000)
        return result.model_copy(update={"duration_ms": elapsed})

    return wrapper
