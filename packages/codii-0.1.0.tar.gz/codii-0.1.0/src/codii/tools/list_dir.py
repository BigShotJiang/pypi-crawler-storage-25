"""list_dir tool."""
from __future__ import annotations

from pathlib import Path
from typing import Any

from codii.connection.base import ToolDefinition
from codii.tools.base import ToolResult, timed_result

_SKIP = {".git", "__pycache__", "node_modules", ".venv", "venv", ".mypy_cache", ".ruff_cache"}


class ListDirTool:
    name = "list_dir"
    description = "List the contents of a directory."

    def definition(self) -> ToolDefinition:
        return ToolDefinition(
            name=self.name,
            description=self.description,
            parameters={
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Directory path relative to workspace root. Defaults to '.'.",
                    }
                },
                "required": [],
            },
        )

    @timed_result
    async def execute(self, arguments: dict[str, Any], workspace: Path) -> ToolResult:
        raw_path = arguments.get("path", ".")
        target = (workspace / raw_path).resolve()

        try:
            target.relative_to(workspace.resolve())
        except ValueError:
            return ToolResult(
                success=False, output="", error=f"Path '{raw_path}' is outside the workspace."
            )

        if not target.exists():
            return ToolResult(success=False, output="", error=f"Directory not found: {raw_path}")
        if not target.is_dir():
            return ToolResult(success=False, output="", error=f"Not a directory: {raw_path}")

        lines: list[str] = []
        try:
            for item in sorted(target.iterdir()):
                if item.name in _SKIP:
                    continue
                suffix = "/" if item.is_dir() else ""
                lines.append(f"{item.name}{suffix}")
        except OSError as e:
            return ToolResult(success=False, output="", error=str(e))

        return ToolResult(success=True, output="\n".join(lines) if lines else "(empty directory)")
