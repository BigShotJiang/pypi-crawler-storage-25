"""spawn_subagent tool — delegates subtasks to built-in specialized subagents."""
from __future__ import annotations

from pathlib import Path
from typing import Any

from codii.connection.base import ToolDefinition
from codii.tools.base import ToolResult, timed_result

# Built-in subagent configurations
BUILTIN_AGENTS: dict[str, dict[str, Any]] = {
    "researcher": {
        "tools": ["read_file", "list_dir"],
        "system": (
            "You are a research agent. Explore the codebase to answer the given task. "
            "Return a structured summary of what you found. Do not modify any files."
        ),
        "max_turns": 10,
    },
    "reviewer": {
        "tools": ["read_file"],
        "system": (
            "You are a code reviewer. Read the relevant files and review the proposed changes. "
            "List your concerns, suggestions, and approvals clearly."
        ),
        "max_turns": 5,
    },
    "planner": {
        "tools": [],
        "system": (
            "You are a planning agent. Given a goal, produce a numbered step-by-step plan. "
            "Think carefully before responding. Return the plan only — no tool calls."
        ),
        "max_turns": 3,
    },
}


class SpawnSubagentTool:
    name = "spawn_subagent"
    description = (
        "Delegate a subtask to a specialized subagent. "
        "Available agents: 'researcher' (reads files, returns summary), "
        "'reviewer' (reviews code, returns concerns), "
        "'planner' (produces a numbered plan)."
    )

    def definition(self) -> ToolDefinition:
        agents = ", ".join(f"'{a}'" for a in BUILTIN_AGENTS)
        return ToolDefinition(
            name=self.name,
            description=self.description,
            parameters={
                "type": "object",
                "properties": {
                    "agent": {
                        "type": "string",
                        "description": f"Agent name: {agents}.",
                    },
                    "task": {
                        "type": "string",
                        "description": "Task description for the subagent.",
                    },
                },
                "required": ["agent", "task"],
            },
        )

    @timed_result
    async def execute(self, arguments: dict[str, Any], workspace: Path) -> ToolResult:
        # Actual execution is handled by _execute_tool in runner.py which has
        # access to the adapter and session. This path is a safety fallback.
        return ToolResult(
            success=False,
            output="",
            error="spawn_subagent must be called from within an active session.",
        )
