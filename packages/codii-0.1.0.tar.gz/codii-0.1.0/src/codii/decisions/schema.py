"""DecisionRecord schema — closed 12-type enum."""
from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel

DecisionType = Literal[
    "tier_select",
    "tool_surface",
    "parser_dispatch",
    "repair",
    "compact",
    "intervention",
    "subagent",
    "permission",
    "promote",
    "demote",
    "timeout",
    "circuit_break",
]


class DecisionRecord(BaseModel):
    ts: datetime
    type: DecisionType
    payload: dict[str, Any]
