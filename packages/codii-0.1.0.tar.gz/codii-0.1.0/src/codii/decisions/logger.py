"""Decision logger — writes simultaneously to .jsonl and human-readable .log."""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from codii.decisions.schema import DecisionRecord, DecisionType


class DecisionLogger:
    def __init__(self, session_dir: Path) -> None:
        self._jsonl = session_dir / "decisions.jsonl"
        self._log = session_dir / "decisions.log"
        session_dir.mkdir(parents=True, exist_ok=True)

    def log(self, type: DecisionType, payload: dict[str, Any]) -> None:
        try:
            record = DecisionRecord(
                ts=datetime.now(timezone.utc),
                type=type,
                payload=payload,
            )
            line = record.model_dump_json() + "\n"
            with self._jsonl.open("a", encoding="utf-8") as f:
                f.write(line)

            human = _format_human(record)
            with self._log.open("a", encoding="utf-8") as f:
                f.write(human + "\n\n")
        except Exception:
            # Logging must never crash the agent loop.
            pass

    def read_records(
        self,
        *,
        type_filter: str | None = None,
        limit: int = 50,
    ) -> list[DecisionRecord]:
        if not self._jsonl.exists():
            return []
        records: list[DecisionRecord] = []
        for line in self._jsonl.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                r = DecisionRecord.model_validate_json(line)
                if type_filter is None or r.type == type_filter:
                    records.append(r)
            except Exception:
                pass
        return records[-limit:]


def _format_human(record: DecisionRecord) -> str:
    ts = record.ts.strftime("%H:%M:%S")
    payload_str = json.dumps(record.payload, indent=2)
    return f"[{ts}] {record.type.upper()}\n{payload_str}"


def show_decisions(
    session_dir: Path,
    *,
    type_filter: str | None = None,
    limit: int = 50,
) -> str:
    logger = DecisionLogger(session_dir)
    records = logger.read_records(type_filter=type_filter, limit=limit)
    if not records:
        return "No decisions recorded."
    parts = [_format_human(r) for r in records]
    return "\n\n".join(parts)
