"""Ollama backend adapter. NDJSON streaming. Auto-detects at :11434."""
from __future__ import annotations

import json
import uuid
from typing import Any, AsyncIterator

import httpx

from codii.connection.base import (
    BackendAdapter,
    Done,
    RequestMessage,
    ResponseEvent,
    TextChunk,
    ToolCall,
    ToolDefinition,
)
from codii.errors import (
    ConnectionError as CodiiConnectionError,
    ollama_unreachable,
)

DEFAULT_ENDPOINT = "http://localhost:11434"


def _messages_to_ollama(messages: list[RequestMessage]) -> list[dict[str, Any]]:
    return [{"role": m.role, "content": m.content} for m in messages]


def _tool_defs_to_ollama(tools: list[ToolDefinition]) -> list[dict[str, Any]]:
    return [
        {
            "type": "function",
            "function": {
                "name": t.name,
                "description": t.description,
                "parameters": t.parameters,
            },
        }
        for t in tools
    ]


class OllamaAdapter(BackendAdapter):
    """Adapter for Ollama's /api/chat endpoint."""

    def __init__(
        self,
        endpoint: str = DEFAULT_ENDPOINT,
        model: str = "",
        api_key: str = "",
    ) -> None:
        super().__init__(endpoint, model, api_key)

    async def health_check(self) -> bool:
        try:
            async with self._make_client(timeout=5.0) as client:
                r = await client.get(f"{self.endpoint}/api/tags")
                return r.status_code == 200
        except httpx.TransportError:
            return False

    async def list_models(self) -> list[str]:
        async with self._make_client() as client:
            r = await client.get(f"{self.endpoint}/api/tags")
            r.raise_for_status()
            data = r.json()
            return [m["name"] for m in data.get("models", [])]

    async def get_model_info(self) -> dict[str, Any]:
        """Return Ollama model metadata including digest and num_ctx."""
        async with self._make_client() as client:
            r = await client.post(
                f"{self.endpoint}/api/show",
                json={"name": self.model},
            )
            r.raise_for_status()
            result: dict[str, Any] = r.json()
            return result

    async def send_request(
        self,
        messages: list[RequestMessage],
        tools: list[ToolDefinition] | None = None,
        stream: bool = True,
    ) -> AsyncIterator[ResponseEvent]:
        body: dict[str, Any] = {
            "model": self.model,
            "messages": _messages_to_ollama(messages),
            "stream": stream,
        }
        if tools:
            body["tools"] = _tool_defs_to_ollama(tools)

        try:
            if stream:
                async for event in self._stream_request(body):
                    yield event
            else:
                async for event in self._single_request(body):
                    yield event
        except httpx.ConnectError:
            raise ollama_unreachable(self.endpoint)
        except httpx.TimeoutException:
            raise CodiiConnectionError(
                f"Ollama at {self.endpoint} did not respond in time",
                hint="The model may be loading. Try again or run: ollama ps",
            )

    async def _single_request(self, body: dict[str, Any]) -> AsyncIterator[ResponseEvent]:
        async with self._make_client() as client:
            r = await client.post(f"{self.endpoint}/api/chat", json=body)
            r.raise_for_status()
            data = r.json()
            async for event in _parse_ollama_message(data):
                yield event

    async def _stream_request(self, body: dict[str, Any]) -> AsyncIterator[ResponseEvent]:
        async with self._make_client() as client:
            async with client.stream(
                "POST", f"{self.endpoint}/api/chat", json=body
            ) as response:
                response.raise_for_status()
                async for line in response.aiter_lines():
                    if not line.strip():
                        continue
                    try:
                        chunk = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    async for event in _parse_ollama_chunk(chunk):
                        yield event
                    if chunk.get("done"):
                        break


async def _parse_ollama_message(data: dict[str, Any]) -> AsyncIterator[ResponseEvent]:
    """Parse a single non-streaming Ollama response."""
    message = data.get("message", {})

    tool_calls = message.get("tool_calls", [])
    if tool_calls:
        for tc in tool_calls:
            fn = tc.get("function", {})
            yield ToolCall(
                id=str(uuid.uuid4()),
                name=fn.get("name", ""),
                arguments=BackendAdapter._parse_arguments(fn.get("arguments", {})),
            )
    elif content := message.get("content", ""):
        yield TextChunk(text=content)

    yield Done(stop_reason=data.get("done_reason", "stop"))


async def _parse_ollama_chunk(chunk: dict[str, Any]) -> AsyncIterator[ResponseEvent]:
    """Parse one NDJSON line from a streaming Ollama response."""
    message = chunk.get("message", {})

    tool_calls = message.get("tool_calls", [])
    if tool_calls:
        for tc in tool_calls:
            fn = tc.get("function", {})
            yield ToolCall(
                id=str(uuid.uuid4()),
                name=fn.get("name", ""),
                arguments=BackendAdapter._parse_arguments(fn.get("arguments", {})),
            )
    elif content := message.get("content", ""):
        yield TextChunk(text=content)

    if chunk.get("done"):
        yield Done(stop_reason=chunk.get("done_reason", "stop"))
