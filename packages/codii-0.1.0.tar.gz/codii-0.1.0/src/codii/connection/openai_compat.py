"""Generic OpenAI-compatible adapter and shared SSE streaming parser."""
from __future__ import annotations

import json
import re
import uuid
from typing import Any, AsyncIterator

import httpx

from codii.connection.base import (
    BackendAdapter,
    Done,
    RequestMessage,
    ResponseEvent,
    TextChunk,
    ToolCall,
    ToolDefinition,
)
from codii.errors import ConnectionError as CodiiConnectionError, endpoint_unreachable


# Matches pipe-delimited special tokens emitted by some models (e.g. Qwen3's
# <|channel>thought, <|im_start|>, <|endoftext|>). These must be stripped
# before the text reaches the agent loop or context history.
_SPECIAL_TOKEN_RE = re.compile(r"<\|[a-zA-Z0-9_:/]*\|?>")


def _tool_defs_to_openai(tools: list[ToolDefinition]) -> list[dict[str, Any]]:
    return [
        {
            "type": "function",
            "function": {
                "name": t.name,
                "description": t.description,
                "parameters": t.parameters,
            },
        }
        for t in tools
    ]


def _messages_to_openai(messages: list[RequestMessage]) -> list[dict[str, Any]]:
    return [{"role": m.role, "content": m.content} for m in messages]


async def parse_openai_sse_stream(
    response: httpx.Response,
) -> AsyncIterator[ResponseEvent]:
    """Parse an SSE stream from any OpenAI-compatible endpoint."""
    # Accumulate tool call fragments indexed by tool_call index
    pending_calls: dict[int, dict[str, Any]] = {}

    async for line in response.aiter_lines():
        if not line.startswith("data:"):
            continue
        payload = line[len("data:"):].strip()
        if payload == "[DONE]":
            break
        try:
            chunk = json.loads(payload)
        except json.JSONDecodeError:
            continue

        choices = chunk.get("choices", [])
        if not choices:
            continue
        choice = choices[0]
        delta = choice.get("delta", {})
        finish_reason = choice.get("finish_reason")

        # Accumulate text — strip pipe-delimited special tokens before yielding
        if content := delta.get("content"):
            content = _SPECIAL_TOKEN_RE.sub("", content)
            if content:
                yield TextChunk(text=content)

        # Accumulate tool call fragments
        for tc_fragment in delta.get("tool_calls", []):
            idx = tc_fragment.get("index", 0)
            if idx not in pending_calls:
                pending_calls[idx] = {
                    "id": tc_fragment.get("id", str(uuid.uuid4())),
                    "name": "",
                    "arguments": "",
                }
            fn = tc_fragment.get("function", {})
            if fn.get("name"):
                pending_calls[idx]["name"] += fn["name"]
            if fn.get("arguments"):
                pending_calls[idx]["arguments"] += fn["arguments"]

        if finish_reason in ("tool_calls", "stop", "length", "eos"):
            break

    # Emit accumulated tool calls
    for idx in sorted(pending_calls):
        tc = pending_calls[idx]
        if tc["name"]:
            yield ToolCall(
                id=tc["id"],
                name=tc["name"],
                arguments=BackendAdapter._parse_arguments(tc["arguments"]),
            )

    # Extract token usage if present in the last chunk
    usage: dict[str, Any] = locals().get("chunk", {}).get("usage", {}) if "chunk" in locals() else {}
    yield Done(
        stop_reason=finish_reason or "stop",
        input_tokens=usage.get("prompt_tokens"),
        output_tokens=usage.get("completion_tokens"),
    )


class GenericOpenAIAdapter(BackendAdapter):
    """OpenAI-compatible adapter for any endpoint (Colab tunnels, custom servers)."""

    async def health_check(self) -> bool:
        try:
            async with self._make_client(timeout=5.0) as client:
                r = await client.get(f"{self.endpoint}/v1/models")
                return r.status_code == 200
        except httpx.TransportError:
            return False

    async def list_models(self) -> list[str]:
        async with self._make_client() as client:
            r = await client.get(f"{self.endpoint}/v1/models")
            r.raise_for_status()
            data = r.json()
            return [m["id"] for m in data.get("data", [])]

    async def send_request(
        self,
        messages: list[RequestMessage],
        tools: list[ToolDefinition] | None = None,
        stream: bool = True,
    ) -> AsyncIterator[ResponseEvent]:
        body: dict[str, Any] = {
            "model": self.model,
            "messages": _messages_to_openai(messages),
            "stream": stream,
        }
        if tools:
            body["tools"] = _tool_defs_to_openai(tools)

        try:
            async with self._make_client(timeout=120.0) as client:
                if stream:
                    async with client.stream(
                        "POST", f"{self.endpoint}/v1/chat/completions", json=body
                    ) as response:
                        response.raise_for_status()
                        async for event in parse_openai_sse_stream(response):
                            yield event
                else:
                    r = await client.post(
                        f"{self.endpoint}/v1/chat/completions", json=body
                    )
                    r.raise_for_status()
                    data = r.json()
                    async for event in _parse_openai_completion(data):
                        yield event
        except httpx.ConnectError:
            raise endpoint_unreachable(self.endpoint)
        except httpx.TimeoutException:
            raise CodiiConnectionError(
                f"Request to {self.endpoint} timed out",
                hint="The model may be loading. Try again in a moment.",
            )
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 400:
                # Model does not support the tools array (e.g. Ollama OpenAI-compat
                # endpoint rejects tool-bearing requests for non-native models).
                yield Done(stop_reason="tools_not_supported")
            else:
                raise


async def _parse_openai_completion(data: dict[str, Any]) -> AsyncIterator[ResponseEvent]:
    """Parse a non-streaming OpenAI completion response."""
    choices = data.get("choices", [])
    if not choices:
        yield Done(stop_reason="stop")
        return

    choice = choices[0]
    message = choice.get("message", {})
    finish_reason = choice.get("finish_reason", "stop")

    if content := message.get("content"):
        yield TextChunk(text=content)

    for tc in message.get("tool_calls", []):
        fn = tc.get("function", {})
        yield ToolCall(
            id=tc.get("id", str(uuid.uuid4())),
            name=fn.get("name", ""),
            arguments=BackendAdapter._parse_arguments(fn.get("arguments", {})),
        )

    usage = data.get("usage", {})
    yield Done(
        stop_reason=finish_reason,
        input_tokens=usage.get("prompt_tokens"),
        output_tokens=usage.get("completion_tokens"),
    )
