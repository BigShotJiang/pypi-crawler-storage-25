"""BackendAdapter contract, shared types, and retry helper."""
from __future__ import annotations

import asyncio
import json
from typing import Any, AsyncIterator, Callable, Coroutine, Literal

import httpx
from pydantic import BaseModel

from codii.errors import ConnectionError as CodiiConnectionError


# ── Request / Response types ───────────────────────────────────────────────────

class RequestMessage(BaseModel):
    role: Literal["system", "user", "assistant", "tool"]
    content: str


class ToolDefinition(BaseModel):
    name: str
    description: str
    parameters: dict[str, Any]  # JSON Schema object


class TextChunk(BaseModel):
    text: str


class ToolCall(BaseModel):
    id: str
    name: str
    arguments: dict[str, Any]  # always a dict; adapters normalise from stringified JSON


class Done(BaseModel):
    stop_reason: str
    input_tokens: int | None = None
    output_tokens: int | None = None


ResponseEvent = TextChunk | ToolCall | Done


# ── BackendAdapter base class ──────────────────────────────────────────────────

class BackendAdapter:
    """Base class for all backend adapters. Subclasses must override all methods."""

    def __init__(self, endpoint: str, model: str, api_key: str = "") -> None:
        self.endpoint = endpoint.rstrip("/")
        self.model = model
        self.api_key = api_key

    async def health_check(self) -> bool:
        raise NotImplementedError

    async def list_models(self) -> list[str]:
        raise NotImplementedError

    async def send_request(
        self,
        messages: list[RequestMessage],
        tools: list[ToolDefinition] | None = None,
        stream: bool = True,
    ) -> AsyncIterator[ResponseEvent]:
        raise NotImplementedError
        yield  # makes this an async generator; subclasses override

    def _auth_headers(self) -> dict[str, str]:
        if self.api_key:
            return {"Authorization": f"Bearer {self.api_key}"}
        return {}

    def _make_client(self, timeout: float = 120.0) -> httpx.AsyncClient:
        return httpx.AsyncClient(
            timeout=httpx.Timeout(timeout),
            headers=self._auth_headers(),
        )

    @staticmethod
    def _parse_arguments(raw: str | dict[str, Any]) -> dict[str, Any]:
        """Normalise tool arguments: always return a dict."""
        if isinstance(raw, dict):
            return raw
        try:
            parsed = json.loads(raw)
            return parsed if isinstance(parsed, dict) else {}
        except (json.JSONDecodeError, TypeError):
            return {}


# ── Helpers ────────────────────────────────────────────────────────────────────

async def collect_response(
    adapter: BackendAdapter,
    messages: list[RequestMessage],
    tools: list[ToolDefinition] | None = None,
    *,
    timeout: float = 60.0,
) -> tuple[str, list[ToolCall], Done]:
    """Collect all events from a request into (text, tool_calls, done)."""
    text = ""
    tool_calls: list[ToolCall] = []
    done = Done(stop_reason="stop")
    async for event in adapter.send_request(messages, tools, stream=False):
        match event:
            case TextChunk():
                text += event.text
            case ToolCall():
                tool_calls.append(event)
            case Done():
                done = event
    return text, tool_calls, done


async def retry_health_check(
    check_fn: Callable[[], Coroutine[Any, Any, bool]],
    *,
    attempts: int = 3,
    base_delay: float = 0.5,
) -> bool:
    """Retry a health check coroutine. Returns False on final failure."""
    for attempt in range(attempts):
        try:
            result = await check_fn()
            if result:
                return True
        except Exception:
            pass
        if attempt < attempts - 1:
            await asyncio.sleep(base_delay * (2**attempt))
    return False
