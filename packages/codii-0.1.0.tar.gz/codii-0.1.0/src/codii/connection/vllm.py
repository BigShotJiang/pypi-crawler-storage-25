"""vLLM backend adapter. OpenAI-compatible SSE. Health check at /health."""
from __future__ import annotations

from typing import Any, AsyncIterator

import httpx

from codii.connection.base import (
    BackendAdapter,
    RequestMessage,
    ResponseEvent,
    ToolDefinition,
)
from codii.connection.openai_compat import (
    GenericOpenAIAdapter,
    _messages_to_openai,
    _parse_openai_completion,
    _tool_defs_to_openai,
    parse_openai_sse_stream,
)
from codii.errors import ConnectionError as CodiiConnectionError, vllm_unreachable


class VllmAdapter(BackendAdapter):
    """Adapter for vLLM's OpenAI-compatible server."""

    async def health_check(self) -> bool:
        try:
            async with self._make_client(timeout=5.0) as client:
                r = await client.get(f"{self.endpoint}/health")
                return r.status_code == 200
        except httpx.TransportError:
            return False

    async def list_models(self) -> list[str]:
        async with self._make_client() as client:
            r = await client.get(f"{self.endpoint}/v1/models")
            r.raise_for_status()
            data = r.json()
            return [m["id"] for m in data.get("data", [])]

    async def send_request(
        self,
        messages: list[RequestMessage],
        tools: list[ToolDefinition] | None = None,
        stream: bool = True,
    ) -> AsyncIterator[ResponseEvent]:
        body: dict[str, Any] = {
            "model": self.model,
            "messages": _messages_to_openai(messages),
            "stream": stream,
        }
        if tools:
            body["tools"] = _tool_defs_to_openai(tools)

        try:
            async with self._make_client() as client:
                if stream:
                    async with client.stream(
                        "POST", f"{self.endpoint}/v1/chat/completions", json=body
                    ) as response:
                        response.raise_for_status()
                        async for event in parse_openai_sse_stream(response):
                            yield event
                else:
                    r = await client.post(
                        f"{self.endpoint}/v1/chat/completions", json=body
                    )
                    r.raise_for_status()
                    async for event in _parse_openai_completion(r.json()):
                        yield event
        except httpx.ConnectError:
            raise vllm_unreachable(self.endpoint)
        except httpx.TimeoutException:
            raise CodiiConnectionError(
                f"vLLM at {self.endpoint} did not respond in time",
                hint="Check that the server is running and the model is loaded.",
            )
