"""OpenRouter cloud API adapter."""
from __future__ import annotations

import httpx

from codii.connection.openai_compat import GenericOpenAIAdapter

_ENDPOINT = "https://openrouter.ai/api"


class OpenRouterAdapter(GenericOpenAIAdapter):
    """Adapter for the OpenRouter cloud API (https://openrouter.ai).

    Endpoint is fixed; the caller supplies model name and API key.
    send_request() is fully inherited from GenericOpenAIAdapter.
    """

    def __init__(self, model: str = "", api_key: str = "") -> None:
        super().__init__(endpoint=_ENDPOINT, model=model, api_key=api_key)

    def _auth_headers(self) -> dict[str, str]:
        headers = super()._auth_headers()  # Authorization: Bearer <key>
        headers.update({
            "HTTP-Referer": "https://github.com/codii",
            "X-Title": "Codii",
        })
        return headers

    async def health_check(self) -> bool:
        """Verify OpenRouter is reachable. 401 counts as reachable (key validated on first request)."""
        try:
            async with self._make_client(timeout=5.0) as client:
                r = await client.get(f"{self.endpoint}/v1/models")
                return r.status_code in (200, 401)
        except httpx.TransportError:
            return False

    async def list_models(self) -> list[str]:
        """Return OpenRouter model IDs. Best-effort — returns [] on any error."""
        try:
            async with self._make_client(timeout=10.0) as client:
                r = await client.get(f"{self.endpoint}/v1/models")
                if r.status_code != 200:
                    return []
                data = r.json()
                return [m["id"] for m in data.get("data", []) if m.get("id")]
        except Exception:
            return []
