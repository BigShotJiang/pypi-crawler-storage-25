"""Probe 1: detect tool-call format and native tool calling support."""
from __future__ import annotations

import re
import uuid
from dataclasses import dataclass

from codii.connection.base import (
    BackendAdapter,
    Done,
    RequestMessage,
    TextChunk,
    ToolCall,
    ToolDefinition,
    collect_response,
)

_GET_TIME_TOOL = ToolDefinition(
    name="get_time",
    description="Get the current time",
    parameters={"type": "object", "properties": {}, "required": []},
)

_TOOL_CALL_PROMPT = (
    "Use the get_time tool to find the current time. "
    "Call it now and only call it — do not add any explanation."
)

_FORMAT_DETECTION_PROMPT = (
    "If you wanted to call a function named get_time with no arguments, "
    "write only the function call in your native format and nothing else."
)


@dataclass
class ToolCallResult:
    native_tool_calling: bool
    tool_call_format: str  # ToolFormatEnum value
    raw_response_a: str  # first 500 chars of request-A response
    raw_response_b: str  # first 500 chars of request-B response


async def probe_tool_call(adapter: BackendAdapter) -> ToolCallResult:
    """
    Two-request probe:
      A — send with get_time tool definition; check if backend surfaces ToolCall
      B — send without tools; detect format from raw text
    """
    # Request A: with tool definition.
    # Some backends (e.g. Ollama /v1/chat/completions) return HTTP 400 when
    # tools are included for models that don't support native tool calling.
    # Catch that so the probe can continue to Request B.
    try:
        text_a, tool_calls_a, done_a = await collect_response(
            adapter,
            messages=[RequestMessage(role="user", content=_TOOL_CALL_PROMPT)],
            tools=[_GET_TIME_TOOL],
        )
        if done_a.stop_reason == "tools_not_supported":
            text_a = ""
            tool_calls_a = []
        native = len(tool_calls_a) > 0
    except Exception:
        text_a = ""
        tool_calls_a = []
        native = False

    # Request B: free text, detect raw format
    text_b, _, _ = await collect_response(
        adapter,
        messages=[RequestMessage(role="user", content=_FORMAT_DETECTION_PROMPT)],
        tools=None,
    )

    detected_format = _detect_format(text_b)

    # If native tool calling worked and we also see gemma4 tokens in free text,
    # the format is gemma4_tokens even though the backend surfaced it natively.
    if native and detected_format == "none":
        # Backend surfaced it natively — use openai_json as the native format
        # unless a family-specific format was detected.
        detected_format = "openai_json"

    return ToolCallResult(
        native_tool_calling=native,
        tool_call_format=detected_format,
        raw_response_a=(text_a + _stringify_tool_calls(tool_calls_a))[:500],
        raw_response_b=text_b[:500],
    )


def _stringify_tool_calls(tool_calls: list[ToolCall]) -> str:
    if not tool_calls:
        return ""
    return " ".join(f"[tool_call:{tc.name}]" for tc in tool_calls)


def _detect_format(raw_text: str) -> str:
    """Detect tool-call format from raw model output. Conservative: returns 'none' if ambiguous."""
    match True:
        # Gemma 4: <|tool_call|> or <|tool_call> (both variants per Flag 6)
        case _ if re.search(r"<\|tool_call\|?>", raw_text):
            return "gemma4_tokens"

        # Hermes XML: <tool_call>...</tool_call>
        case _ if re.search(r"<tool_call\s*>", raw_text, re.IGNORECASE):
            return "hermes_xml"

        # Gemma 3 / tool_code markdown blocks (→ none: no native format)
        case _ if re.search(r"```tool_code|tool_output\b", raw_text):
            return "none"

        # Mistral: [TOOL_CALLS] marker
        case _ if re.search(r"\[TOOL_CALLS\]", raw_text):
            return "mistral_json"

        # Qwen: "type": "function" wrapper in JSON
        case _ if re.search(r'"type"\s*:\s*"function"', raw_text):
            return "qwen_json"

        # OpenAI JSON: {"name": ..., "arguments": ...} in code fence or inline
        case _ if re.search(
            r'```(?:json)?\s*\{[^`]*"(?:name|function)"\s*:', raw_text, re.DOTALL
        ):
            return "openai_json"

        # Inline JSON with name+arguments keys (no fence)
        case _ if re.search(r'\{"(?:name|function)"\s*:.*?"arguments"\s*:', raw_text, re.DOTALL):
            return "openai_json"

        case _:
            return "none"
