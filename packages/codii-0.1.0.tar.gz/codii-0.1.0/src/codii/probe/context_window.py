"""Probe 2: effective context window via needle-in-haystack at 25/50/90% depth."""
from __future__ import annotations

import random
import re
import string
from dataclasses import dataclass

from codii.connection.base import BackendAdapter, RequestMessage, collect_response

# Filler text: repeated to fill the context. ~500 chars per repeat ≈ 125 tokens.
_FILLER_PARAGRAPH = (
    "The study of distributed systems has produced many insights into the nature of "
    "consistency, availability, and partition tolerance. Engineers must carefully "
    "weigh the trade-offs between strong consistency and system availability when "
    "designing large-scale services. The CAP theorem provides a theoretical "
    "foundation for understanding these limits, while practical implementations "
    "often require nuanced approaches that balance competing requirements. Modern "
    "databases employ a variety of techniques including quorum reads, vector clocks, "
    "and conflict-free replicated data types to achieve desired consistency "
    "properties without sacrificing availability. "
)


@dataclass
class ContextWindowResult:
    effective_context_tokens: int
    claimed_context_tokens: int
    depth_results: dict[float, bool]  # depth → passed
    needle_word: str


def _generate_needle() -> str:
    """Generate a random needle string unlikely to appear in training data."""
    word = "".join(random.choices(string.ascii_uppercase, k=6))
    number = random.randint(1000, 9999)
    return f"CODII_{word}_{number}"


def _build_context_with_needle(
    needle: str,
    target_chars: int,
    depth: float,
) -> str:
    """Build a long context string with the needle inserted at `depth` fraction."""
    # Generate filler to fill target_chars
    repeats = (target_chars // len(_FILLER_PARAGRAPH)) + 2
    filler = (_FILLER_PARAGRAPH * repeats)[:target_chars]

    needle_sentence = f" The secret identifier for this test is: {needle}. "
    insert_pos = int(len(filler) * depth)
    return filler[:insert_pos] + needle_sentence + filler[insert_pos:]


async def probe_context_window(
    adapter: BackendAdapter,
    claimed_context_tokens: int,
    *,
    max_probe_tokens: int = 32000,
) -> ContextWindowResult:
    """
    Test effective context at 25%, 50%, and 90% of min(claimed, max_probe_tokens).
    Uses conservative consecutive-from-bottom logic: if 50% fails, report 25% even
    if 90% somehow passes.
    """
    target_tokens = min(claimed_context_tokens, max_probe_tokens)
    # 4 chars ≈ 1 token (approximation logged by runner)
    target_chars = target_tokens * 4

    needle = _generate_needle()
    depths = [0.25, 0.50, 0.90]
    depth_results: dict[float, bool] = {}

    for depth in depths:
        context_text = _build_context_with_needle(needle, target_chars, depth)
        prompt = (
            f"{context_text}\n\n"
            f"What is the secret identifier in the text above? "
            f"Reply with only the identifier and nothing else."
        )
        text, _, _ = await collect_response(
            adapter,
            messages=[RequestMessage(role="user", content=prompt)],
        )
        passed = needle in text
        depth_results[depth] = passed

    # Consecutive-from-bottom: find the highest depth where all lower depths also passed
    effective_depth = 0.0
    for depth in depths:
        if depth_results.get(depth, False):
            effective_depth = depth
        else:
            break  # Stop at first failure; don't credit higher depths

    effective_tokens = int(effective_depth * target_tokens)

    # Fallback: never store 0 — a zero effective context breaks auto-compact.
    # If all depths failed, use 75% of the claimed context as a conservative estimate.
    if effective_tokens == 0:
        effective_tokens = max(1, int(claimed_context_tokens * 0.75))

    return ContextWindowResult(
        effective_context_tokens=effective_tokens,
        claimed_context_tokens=claimed_context_tokens,
        depth_results=depth_results,
        needle_word=needle,
    )
