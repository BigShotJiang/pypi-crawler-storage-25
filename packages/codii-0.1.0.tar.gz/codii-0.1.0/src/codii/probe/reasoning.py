"""Probe 3: detect reasoning token support (<think>, <thinking>, etc.)."""
from __future__ import annotations

import re
from dataclasses import dataclass

from codii.connection.base import BackendAdapter, RequestMessage, collect_response

_REASONING_PROMPT = (
    "Alice has 3 baskets. Each basket contains 4 apples. "
    "She gives half of all her apples to Bob. "
    "Bob then gives 3 apples back to Alice. "
    "How many apples does Alice have now? "
    "Show your work step by step."
)

# Order matters: check longer/more-specific patterns first
_REASONING_PATTERNS: list[tuple[str, str]] = [
    (r"<\|begin_of_thought\|>", "<|begin_of_thought|>"),
    (r"<thinking>", "<thinking>"),
    (r"<think>", "<think>"),
    (r"<\|thinking\|>", "<|thinking|>"),
    (r"\[THINK\]", "[THINK]"),
]


@dataclass
class ReasoningResult:
    supported: bool
    delimiter: str | None
    raw_response_excerpt: str  # first 500 chars


async def probe_reasoning(adapter: BackendAdapter) -> ReasoningResult:
    """Send a multi-step arithmetic problem and check for reasoning token delimiters."""
    text, _, _ = await collect_response(
        adapter,
        messages=[RequestMessage(role="user", content=_REASONING_PROMPT)],
    )

    delimiter: str | None = None
    for pattern, label in _REASONING_PATTERNS:
        if re.search(pattern, text, re.IGNORECASE):
            delimiter = label
            break

    return ReasoningResult(
        supported=delimiter is not None,
        delimiter=delimiter,
        raw_response_excerpt=text[:500],
    )
