"""Probe 4: structured output reliability — 5 requests for a specific JSON object."""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field

from codii.connection.base import BackendAdapter, RequestMessage, collect_response

_STRUCTURED_PROMPT = (
    'Respond with ONLY a JSON object — no markdown fences, no explanation, '
    'no text before or after. The object must have exactly these three fields:\n'
    '  "name": a string with the value "codii"\n'
    '  "score": an integer between 1 and 10\n'
    '  "tags": a list of exactly 2 strings describing a coding tool\n'
    'Output the JSON object and nothing else.'
)

_FENCE_RE = re.compile(r"```(?:json)?\s*(.*?)\s*```", re.DOTALL)


def _strip_fences(text: str) -> str:
    """Remove markdown code fences if present."""
    m = _FENCE_RE.search(text)
    return m.group(1) if m else text.strip()


def _score_response(text: str) -> bool:
    """Return True if text parses as valid JSON with the required fields and types."""
    cleaned = _strip_fences(text)
    try:
        obj = json.loads(cleaned)
    except json.JSONDecodeError:
        return False
    if not isinstance(obj, dict):
        return False
    if not isinstance(obj.get("name"), str):
        return False
    if not isinstance(obj.get("score"), int):
        return False
    if not isinstance(obj.get("tags"), list):
        return False
    return True


@dataclass
class StructuredOutputResult:
    reliability: float  # 0.0 – 1.0; fraction of 5 attempts that passed
    scores: list[bool] = field(default_factory=list)
    raw_responses: list[str] = field(default_factory=list)


async def probe_structured_output(adapter: BackendAdapter, *, n: int = 5) -> StructuredOutputResult:
    """Send n requests for a specific JSON object. Score = fraction that parse correctly."""
    scores: list[bool] = []
    raw_responses: list[str] = []

    for _ in range(n):
        text, _, _ = await collect_response(
            adapter,
            messages=[RequestMessage(role="user", content=_STRUCTURED_PROMPT)],
        )
        scores.append(_score_response(text))
        raw_responses.append(text[:500])

    reliability = sum(scores) / len(scores) if scores else 0.0
    return StructuredOutputResult(
        reliability=reliability,
        scores=scores,
        raw_responses=raw_responses,
    )
