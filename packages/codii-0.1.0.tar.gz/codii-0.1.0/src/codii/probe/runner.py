"""Orchestrates all four probes and builds the CapabilityFingerprint."""
from __future__ import annotations

import asyncio
import hashlib
import re
from collections.abc import Awaitable, Callable
from datetime import datetime, timezone
from typing import Any, TypeVar

from codii.connection.base import BackendAdapter
from codii.connection.ollama import OllamaAdapter
from codii.errors import ConnectionError as CodiiConnectionError
from codii.fingerprint.schema import (
    Capabilities,
    CapabilityFingerprint,
    ReasoningSupport,
)
from codii.probe.context_window import probe_context_window
from codii.probe.reasoning import probe_reasoning
from codii.probe.structured import probe_structured_output
from codii.probe.tool_call import probe_tool_call

_T = TypeVar("_T")
_RETRY_ATTEMPTS = 3
_RETRY_DELAY = 10.0


async def _probe_step(
    coro_fn: Callable[[], Awaitable[_T]],
    on_status: Callable[[str], None] | None,
) -> _T:
    """Run a probe coroutine with up to 3 retries on timeout."""
    for attempt in range(1, _RETRY_ATTEMPTS + 1):
        try:
            return await coro_fn()
        except CodiiConnectionError as e:
            if "timed out" not in e.message.lower() or attempt == _RETRY_ATTEMPTS:
                raise
            msg = f"Model is loading, retrying... (attempt {attempt}/{_RETRY_ATTEMPTS})"
            if on_status:
                on_status(msg)
            await asyncio.sleep(_RETRY_DELAY)
    raise AssertionError("unreachable")


async def run_probe(
    adapter: BackendAdapter,
    *,
    max_context_tokens: int = 32000,
    trace_truncation_chars: int = 500,
    on_status: Callable[[str], None] | None = None,
) -> CapabilityFingerprint:
    """Run all four probes and return a complete CapabilityFingerprint."""

    def status(msg: str) -> None:
        if on_status:
            on_status(msg)

    # Determine claimed context and quant hash from backend
    claimed_context, quant_hash = await _get_backend_meta(adapter)

    status("probe 1/4: tool calling format")
    tc_result = await _probe_step(lambda: probe_tool_call(adapter), on_status)

    status("probe 2/4: effective context window")
    cw_result = await _probe_step(
        lambda: probe_context_window(
            adapter,
            claimed_context_tokens=claimed_context,
            max_probe_tokens=max_context_tokens,
        ),
        on_status,
    )

    status("probe 3/4: reasoning token support")
    r_result = await _probe_step(lambda: probe_reasoning(adapter), on_status)

    status("probe 4/4: structured output reliability")
    so_result = await _probe_step(lambda: probe_structured_output(adapter), on_status)

    family = detect_family(adapter.model)
    tier = compute_tier(
        native_tool_calling=tc_result.native_tool_calling,
        structured_reliability=so_result.reliability,
        effective_context_tokens=cw_result.effective_context_tokens,
    )
    tier_rationale = _build_rationale(tc_result, cw_result, so_result, tier)

    now = datetime.now(timezone.utc)

    caps = Capabilities(
        family=family,  # type: ignore[arg-type]
        tool_call_format=tc_result.tool_call_format,  # type: ignore[arg-type]
        native_tool_calling=tc_result.native_tool_calling,
        effective_context_tokens=cw_result.effective_context_tokens,
        claimed_context_tokens=cw_result.claimed_context_tokens,
        reasoning_support=ReasoningSupport(
            supported=r_result.supported,
            delimiter=r_result.delimiter,
        ),
        structured_output_reliability=so_result.reliability,
        instruction_following_reliability=so_result.reliability,
        tier=tier,
        tier_rationale=tier_rationale,
    )

    probe_trace = {
        "tool_call": {
            "native_tool_calling": tc_result.native_tool_calling,
            "format": tc_result.tool_call_format,
            "response_a": tc_result.raw_response_a[:trace_truncation_chars],
            "response_b": tc_result.raw_response_b[:trace_truncation_chars],
        },
        "context_window": {
            "claimed_tokens": cw_result.claimed_context_tokens,
            "effective_tokens": cw_result.effective_context_tokens,
            "depth_results": {str(k): v for k, v in cw_result.depth_results.items()},
            "token_count_method": "4-char-approximation",
        },
        "reasoning": {
            "supported": r_result.supported,
            "delimiter": r_result.delimiter,
            "response_excerpt": r_result.raw_response_excerpt[:trace_truncation_chars],
        },
        "structured_output": {
            "reliability": so_result.reliability,
            "scores": so_result.scores,
            "responses": [r[:trace_truncation_chars] for r in so_result.raw_responses],
        },
    }

    backend_type = _detect_backend_type(adapter)

    return CapabilityFingerprint(
        schema_version=1,
        created_at=now,
        updated_at=now,
        backend=backend_type,
        endpoint=adapter.endpoint,
        model=adapter.model,
        quant_hash=quant_hash,
        capabilities=caps,
        probe_trace=probe_trace,
        user_overrides={},
    )


async def _get_backend_meta(adapter: BackendAdapter) -> tuple[int, str]:
    """Return (claimed_context_tokens, quant_hash) from the backend."""
    claimed_context = 32000
    quant_hash = _hash_string(f"{adapter.endpoint}_{adapter.model}")

    if isinstance(adapter, OllamaAdapter):
        try:
            info = await adapter.get_model_info()
            # Try to parse num_ctx from modelfile parameters
            modelfile = info.get("modelfile", "")
            m = re.search(r"PARAMETER\s+num_ctx\s+(\d+)", modelfile)
            if m:
                claimed_context = int(m.group(1))
            # Use Ollama's model digest as quant hash
            digest = info.get("digest", "")
            if digest:
                quant_hash = digest[:8]
        except Exception:
            pass  # Fall through to defaults

    return claimed_context, quant_hash


def _detect_backend_type(adapter: BackendAdapter) -> str:
    from codii.connection.ollama import OllamaAdapter
    from codii.connection.vllm import VllmAdapter
    from codii.connection.lmstudio import LMStudioAdapter
    from codii.connection.openrouter import OpenRouterAdapter

    match adapter:
        case OllamaAdapter():
            return "ollama"
        case VllmAdapter():
            return "vllm"
        case LMStudioAdapter():
            return "lmstudio"
        case OpenRouterAdapter():
            return "openrouter"
        case _:
            return "openai_compat"


def detect_family(model_name: str) -> str:
    """
    Detect model family from model name string.
    'gemma4' family only for explicit gemma4/gemma-4 identifiers.
    Gemma 3 → 'other' (correct per schema: gemma3 is not in the enum).
    """
    name = model_name.lower()
    match True:
        case _ if re.search(r"gemma[-_]?4\b|gemma4", name):
            return "gemma4"
        case _ if "qwen" in name:
            return "qwen"
        case _ if "mistral" in name or "devstral" in name or "mixtral" in name:
            return "mistral"
        case _ if "llama" in name:
            return "llama"
        case _ if "deepseek" in name:
            return "deepseek"
        case _ if "phi" in name:
            return "phi"
        case _ if "gemma" in name:
            # Gemma 3 and older: correct family is 'other' (not in enum)
            return "other"
        case _:
            return "unknown"


def compute_tier(
    *,
    native_tool_calling: bool,
    structured_reliability: float,
    effective_context_tokens: int,
) -> int:
    """
    Tier selection — conservative at boundaries:
      Tier 1: native + reliability >= 0.9 + context >= 16000
      Tier 2: reliability >= 0.5
      Tier 3: else
    """
    if (
        native_tool_calling
        and structured_reliability >= 0.9
        and effective_context_tokens >= 16000
    ):
        return 1
    if structured_reliability >= 0.5:
        return 2
    return 3


def _build_rationale(tc_result: Any, cw_result: Any, so_result: Any, tier: int) -> str:
    ctx_k = cw_result.effective_context_tokens // 1000
    ctx_str = f"{ctx_k}k" if ctx_k > 0 else str(cw_result.effective_context_tokens)
    native_str = "Native tool calling" if tc_result.native_tool_calling else "No native tool calling"
    fmt = tc_result.tool_call_format
    reliability = f"{so_result.reliability:.2f}"
    return (
        f"{native_str} in {fmt} format, effective context {ctx_str} tokens, "
        f"scored {reliability} on structured output — Tier {tier}"
    )


def _hash_string(s: str) -> str:
    return hashlib.sha256(s.encode()).hexdigest()[:8]
