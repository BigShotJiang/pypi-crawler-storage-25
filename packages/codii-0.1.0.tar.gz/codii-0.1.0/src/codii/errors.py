"""All user-facing error messages. Never raise bare strings elsewhere."""
from __future__ import annotations


class CodiiError(Exception):
    def __init__(self, message: str, hint: str | None = None) -> None:
        super().__init__(message)
        self.message = message
        self.hint = hint


class ConnectionError(CodiiError):
    pass


class ModelNotFoundError(CodiiError):
    pass


class ProbeError(CodiiError):
    pass


class ConfigError(CodiiError):
    pass


class ToolExecutionError(CodiiError):
    pass


class PermissionDeniedError(CodiiError):
    pass


class ParseError(CodiiError):
    pass


# ── Message factories ──────────────────────────────────────────────────────────

def ollama_unreachable(endpoint: str) -> ConnectionError:
    return ConnectionError(
        f"Cannot reach Ollama at {endpoint}",
        hint="Is Ollama running? Start it with: ollama serve",
    )


def lmstudio_unreachable(endpoint: str) -> ConnectionError:
    return ConnectionError(
        f"Cannot reach LM Studio at {endpoint}",
        hint="Is LM Studio running and the local server enabled?",
    )


def vllm_unreachable(endpoint: str) -> ConnectionError:
    return ConnectionError(
        f"Cannot reach vLLM at {endpoint}",
        hint="Check that the server is running and the URL is correct.",
    )


def endpoint_unreachable(endpoint: str) -> ConnectionError:
    return ConnectionError(
        f"Cannot reach endpoint at {endpoint}",
        hint="Check that the server is running and the URL is correct.",
    )


def stream_dropped(endpoint: str) -> ConnectionError:
    return ConnectionError(
        f"Connection to {endpoint} dropped mid-response",
        hint="This sometimes happens with Colab tunnels. Try again.",
    )


def model_not_found(model: str, endpoint: str, available: list[str]) -> ModelNotFoundError:
    names = ", ".join(available[:10]) if available else "(none found)"
    return ModelNotFoundError(
        f"Model '{model}' not found at {endpoint}",
        hint=f"Available models: {names}",
    )


def probe_failed(probe_name: str, reason: str) -> ProbeError:
    return ProbeError(
        f"Probe '{probe_name}' failed: {reason}",
        hint="Use 'codii fingerprint edit' to set capabilities manually.",
    )


def no_backend_configured() -> ConfigError:
    return ConfigError(
        "No model configured",
        hint="Run 'codii' to set up a backend, or 'codii probe --backend ollama --model <name>'.",
    )
