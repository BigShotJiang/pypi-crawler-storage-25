"""Select scaffolding configuration from capability fingerprint."""
from __future__ import annotations

from pathlib import Path

from codii.fingerprint.schema import CapabilityFingerprint
from codii.scaffolding.schema import ScaffoldingConfig

_TEMPLATE_DIR = Path(__file__).parent / "templates"


def _load_template(name: str) -> str:
    return (_TEMPLATE_DIR / name).read_text(encoding="utf-8")


def select_scaffolding(
    fp: CapabilityFingerprint,
    *,
    backend: str,
) -> ScaffoldingConfig:
    caps = fp.effective_capabilities()

    # Flag 5: Ollama + Gemma 4 bug — force prompt_engineered regardless of native detection.
    ollama_gemma4 = backend == "ollama" and caps.family == "gemma4"

    tier = caps.tier

    if tier == 1 and not ollama_gemma4:
        return ScaffoldingConfig(
            tier=1,
            system_prompt_template=_load_template("tier1.txt"),
            tool_format="native_json",
            schema_density="full",
            max_tools_exposed=None,
            few_shot_examples=False,
            parser_key=caps.tool_call_format,
            intervention_thresholds={
                "circuit_breaker_count": 3,
                "premature_action": True,
            },
        )

    if tier == 2 or ollama_gemma4:
        return ScaffoldingConfig(
            tier=tier,
            system_prompt_template=_load_template("tier2.txt"),
            tool_format="prompt_engineered" if ollama_gemma4 else "xml_fenced",
            schema_density="compressed",
            max_tools_exposed=7,
            few_shot_examples=True,
            parser_key="generic" if ollama_gemma4 else caps.tool_call_format,
            intervention_thresholds={
                "circuit_breaker_count": 3,
                "premature_action": True,
            },
        )

    # Tier 3
    return ScaffoldingConfig(
        tier=3,
        system_prompt_template=_load_template("tier3.txt"),
        tool_format="prompt_engineered",
        schema_density="natural_language",
        max_tools_exposed=3,
        few_shot_examples=True,
        parser_key="generic",
        intervention_thresholds={
            "circuit_breaker_count": 3,
            "premature_action": True,
        },
    )
