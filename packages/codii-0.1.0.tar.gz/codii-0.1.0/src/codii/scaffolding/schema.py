"""ScaffoldingConfig — configuration produced by the selector for a session."""
from __future__ import annotations

from typing import Literal

from pydantic import BaseModel


class ScaffoldingConfig(BaseModel):
    tier: int
    system_prompt_template: str
    tool_format: Literal["native_json", "xml_fenced", "prompt_engineered"]
    schema_density: Literal["full", "compressed", "natural_language"]
    max_tools_exposed: int | None  # None = unlimited (Tier 1)
    few_shot_examples: bool
    parser_key: str
    intervention_thresholds: dict[str, int | float]
