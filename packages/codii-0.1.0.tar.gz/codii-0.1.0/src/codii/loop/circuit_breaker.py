"""Per-tool-call failure counter. Fires circuit at count == 3."""
from __future__ import annotations

import hashlib
import json
from collections import defaultdict


def _args_structure_hash(arguments: dict[str, object]) -> str:
    """Hash the key structure of arguments (not values) to group similar calls."""
    keys = sorted(arguments.keys())
    return hashlib.md5(json.dumps(keys).encode()).hexdigest()[:8]


class CircuitBreaker:
    def __init__(self, threshold: int = 3) -> None:
        self.threshold = threshold
        self._counts: dict[tuple[str, str], int] = defaultdict(int)

    def _key(self, tool_name: str, arguments: dict[str, object]) -> tuple[str, str]:
        return (tool_name, _args_structure_hash(arguments))

    def record_failure(self, tool_name: str, arguments: dict[str, object]) -> int:
        """Record a failure. Returns the new failure count."""
        key = self._key(tool_name, arguments)
        self._counts[key] += 1
        return self._counts[key]

    def record_success(self, tool_name: str, arguments: dict[str, object]) -> None:
        key = self._key(tool_name, arguments)
        self._counts.pop(key, None)

    def is_open(self, tool_name: str, arguments: dict[str, object]) -> bool:
        """True if this tool+arg-shape has hit the failure threshold."""
        key = self._key(tool_name, arguments)
        return self._counts[key] >= self.threshold

    def failure_count(self, tool_name: str, arguments: dict[str, object]) -> int:
        return self._counts[self._key(tool_name, arguments)]
