"""TAOR loop — Think-Act-Observe-Repeat."""
from __future__ import annotations

import asyncio
import re
import sys
from pathlib import Path
from typing import Any

from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.table import Table

from codii.connection.base import (
    BackendAdapter,
    Done,
    RequestMessage,
    TextChunk,
    ToolCall,
    ToolDefinition,
)
from codii.context.ledger import initialize_ledger
from codii.decisions.logger import DecisionLogger
from codii.fingerprint.schema import CapabilityFingerprint
from codii.loop.circuit_breaker import CircuitBreaker
from codii.loop.core import AgentCore
from codii.loop.session import Session
from codii.parser.base import ParsedToolCall
from codii.parser.dispatch import get_parser
from codii.permissions.model import check_permission
from codii.scaffolding.schema import ScaffoldingConfig
from codii.scaffolding.selector import select_scaffolding
from codii.tools.base import PermissionBand, Tool, ToolResult
from codii.replay.transcript import TranscriptWriter
from codii.tools.bash import BashTool
from codii.tools.edit_file import EditFileTool
from codii.tools.list_dir import ListDirTool
from codii.tools.read_file import ReadFileTool
from codii.tools.spawn_subagent import BUILTIN_AGENTS, SpawnSubagentTool
from codii.tools.write_file import WriteFileTool

console = Console()


def _safe(s: str) -> str:
    """Strip surrogate code points so Rich never raises UnicodeEncodeError."""
    return s.encode("utf-8", errors="replace").decode("utf-8")

_TOOL_INTENT_RE = re.compile(
    r"\b(i will|i'll|i can|i would|let me|i'm going to|going to)\b.{0,80}"
    r"\b(write|create|edit|run|call|use|execute|read)\b",
    re.IGNORECASE | re.DOTALL,
)

# Detects when the model asks the user to provide file content instead of reading it.
_ASKS_FOR_FILE_RE = re.compile(
    r"(please|can you|could you|would you).{0,80}(provide|share|give|send|show|paste).{0,80}"
    r"(content|file|code|source|the .{0,20}file)"
    r"|i.{0,20}need.{0,60}(content|the file|source|code)"
    r"|provide.{0,40}(content|file|code)",
    re.IGNORECASE | re.DOTALL,
)


def _looks_like_tool_description(text: str) -> bool:
    return bool(_TOOL_INTENT_RE.search(text))


_FENCE_WRAP_RE = re.compile(r"^```\w*\n(.*?)\n?```\s*$", re.DOTALL)
_LITERAL_NEWLINE_RE = re.compile(r"(?<!\\)\\n")


def _normalize_response_text(text: str) -> str:
    """Strip formatting artifacts before terminal display.

    Unwraps a single code fence if it wraps the entire response, and converts
    literal backslash-n escape sequences to real newlines. Applied to display
    only — the raw text is preserved in history for the parser.
    """
    text = text.strip()
    m = _FENCE_WRAP_RE.match(text)
    if m:
        text = m.group(1).strip()
    text = _LITERAL_NEWLINE_RE.sub("\n", text)
    return text


_DONE_PHRASES = (
    "done.",
    "task complete",
    "task is complete",
    "i'm done",
    "i have completed",
    "finished.",
    "completed.",
    "all done",
)

_ALL_TOOLS: list[Tool] = [
    ReadFileTool(),
    WriteFileTool(),
    EditFileTool(),
    BashTool(),
    ListDirTool(),
    SpawnSubagentTool(),
]


def _tool_map() -> dict[str, Tool]:
    return {t.name: t for t in _ALL_TOOLS}


def _select_tools(scaffolding: ScaffoldingConfig, *, native_override: bool = False) -> list[Tool]:
    tools: list[Tool] = list(_ALL_TOOLS)
    # native_tool_calling models always get the full tool set regardless of tier.
    # max_tools_exposed only limits prompt-engineered tiers (XML/JSON in system prompt).
    if not native_override and scaffolding.max_tools_exposed is not None:
        tools = tools[: scaffolding.max_tools_exposed]
    return tools


def _build_tool_defs(tools: list[Tool]) -> list[ToolDefinition]:
    return [t.definition() for t in tools]


def _tool_defs_as_text(tools: list[Tool]) -> str:
    """For prompt-engineered format, describe tools in text."""
    lines: list[str] = ["Available tools:"]
    for t in tools:
        d = t.definition()
        lines.append(f"\n  {d.name}: {d.description}")
        props = d.parameters.get("properties", {})
        if props:
            for pname, pinfo in props.items():
                desc = pinfo.get("description", "")
                lines.append(f"    - {pname}: {desc}")
    return "\n".join(lines)


def _build_system_prompt(
    scaffolding: ScaffoldingConfig,
    tools: list[Any],
    ledger: str,
) -> str:
    base = scaffolding.system_prompt_template

    # prompt_engineered templates (tier2/tier3) already embed tool docs in their
    # own format; appending _tool_defs_as_text creates contradictory duplicates.
    ledger_section = f"\n\n## Project context\n{ledger}" if ledger else ""

    return base + ledger_section


def _is_done(text: str, tool_calls: list[ParsedToolCall]) -> bool:
    """Heuristic: no tool calls AND text contains a done signal."""
    if tool_calls:
        return False
    lower = text.lower().strip()
    return any(phrase in lower for phrase in _DONE_PHRASES)


def _render_plan_panel(steps: list[str], statuses: list[str], title: str = "Plan") -> None:
    """Print a Rich panel showing plan steps with status indicators."""
    table = Table.grid(padding=(0, 1))
    table.add_column(width=2)
    table.add_column()
    icons = {
        "completed": "[green]✓[/green]",
        "active": "[bold cyan]▶[/bold cyan]",
        "pending": "[dim]□[/dim]",
    }
    for i, (step, status) in enumerate(zip(steps, statuses), 1):
        icon = icons.get(status, "[dim]□[/dim]")
        if status == "active":
            label = f"[bold]{i}. {step}[/bold]"
        elif status == "completed":
            label = f"[dim]{i}. {step}[/dim]"
        else:
            label = f"{i}. {step}"
        table.add_row(icon, label)
    completed = statuses.count("completed")
    total = len(steps)
    footer = f"[dim]Step {completed + 1} of {total}[/dim]" if total > 0 else None
    console.print(Panel(
        table,
        title=f"[bold]{title}[/bold]",
        subtitle=footer,
        border_style="cyan",
        padding=(0, 1),
    ))


def _write_plan_to_disk(steps: list[str], path: "Path") -> None:
    path.write_text("# Plan\n\n" + "".join(f"{i}. {s}\n" for i, s in enumerate(steps, 1)))


_DOC_FILE_STEMS = frozenset({
    "readme", "changelog", "contributing", "license", "authors",
    "notice", "history", "todo", "changes", "copying",
})


def _extract_edit_scope(user_input: str, workspace: "Path") -> "set[Path]":
    """Extract file paths mentioned in user input that exist in workspace.

    Prefers code/config files over documentation files when both are mentioned,
    to avoid README.md becoming the scope when the user is editing source files.
    """
    candidates = re.findall(
        r'[\w./\\-]+\.(?:py|js|ts|json|toml|yaml|yml|md|txt|sh|rs|go|c|cpp|h|java|rb)',
        user_input,
    )
    code_files: list[Path] = []
    doc_files: list[Path] = []
    for c in candidates:
        p = (workspace / c).resolve()
        try:
            p.relative_to(workspace.resolve())
        except ValueError:
            continue
        if not p.exists():
            continue
        if p.stem.lower() in _DOC_FILE_STEMS:
            doc_files.append(p)
        else:
            code_files.append(p)
    return set(code_files if code_files else doc_files)


async def _edit_steps_inline(steps: list[str], prompt_session: Any) -> list[str]:
    """Interactive inline step editor. Enter=keep, 'd'=delete, text=replace."""
    console.print("[dim]Edit each step (Enter=keep, 'd'=delete, new text=replace):[/dim]")
    result = []
    for i, step in enumerate(steps, 1):
        console.print(f"  [dim]{i}.[/dim] {step}")
        try:
            edited = (await prompt_session.prompt_async(f"  {i} › ")).strip()
        except (KeyboardInterrupt, EOFError):
            result.append(step)
            continue
        if edited == "d":
            continue
        result.append(edited if edited else step)
    return result


async def _ask_plan_approval() -> str:
    """Keyboard-driven approve / edit / reject selector. Returns one of those strings."""
    from prompt_toolkit import Application
    from prompt_toolkit.key_binding import KeyBindings as _KB
    from prompt_toolkit.layout import Layout
    from prompt_toolkit.layout.containers import Window
    from prompt_toolkit.layout.controls import FormattedTextControl
    from prompt_toolkit.formatted_text import HTML

    options = ["approve", "edit", "reject"]

    class _State:
        selected = 0
        result = "reject"

    state = _State()

    def _display():
        parts = []
        for i, opt in enumerate(options):
            if i == state.selected:
                parts.append(f"<b><ansicyan>❯ {opt.capitalize()}</ansicyan></b>")
            else:
                parts.append(f"<ansiwhite>  {opt.capitalize()}</ansiwhite>")
        return HTML("    ".join(parts))

    kb = _KB()

    @kb.add("right")
    @kb.add("tab")
    def _right(event):
        state.selected = (state.selected + 1) % len(options)
        event.app.invalidate()

    @kb.add("left")
    @kb.add("s-tab")
    def _left(event):
        state.selected = (state.selected - 1) % len(options)
        event.app.invalidate()

    @kb.add("enter")
    def _confirm(event):
        state.result = options[state.selected]
        event.app.exit()

    @kb.add("a")
    def _approve(event):
        state.result = "approve"
        event.app.exit()

    @kb.add("e")
    def _edit(event):
        state.result = "edit"
        event.app.exit()

    @kb.add("n")
    def _reject(event):
        state.result = "reject"
        event.app.exit()

    @kb.add("escape")
    @kb.add("c-c")
    def _cancel(event):
        state.result = "reject"
        event.app.exit()

    control = FormattedTextControl(_display, focusable=True)
    layout = Layout(Window(content=control), focused_element=control)
    app = Application(layout=layout, key_bindings=kb, full_screen=False)
    await app.run_async()
    return state.result


async def _ask_tool_confirm(tool_name: str, arg: str) -> bool:
    """Keyboard-driven Allow / Deny prompt for tool permission. Returns True if allowed."""
    import sys as _sys
    from prompt_toolkit import Application
    from prompt_toolkit.key_binding import KeyBindings as _KB
    from prompt_toolkit.layout import Layout
    from prompt_toolkit.layout.containers import Window
    from prompt_toolkit.layout.controls import FormattedTextControl
    from prompt_toolkit.formatted_text import HTML

    console.print(f"\n  [bold]{tool_name}[/bold]({arg})")

    if not _sys.stdout.isatty():
        return True  # non-TTY: auto-allow (tests, CI)

    class _State:
        selected = 0  # 0=Allow, 1=Deny

    state = _State()

    def _display():
        parts = []
        for i, (label, color) in enumerate([("Allow", "ansigreen"), ("Deny", "ansired")]):
            if i == state.selected:
                parts.append(f"<b><{color}>❯ {label}</{color}></b>")
            else:
                parts.append(f"  {label}")
        return HTML("    ".join(parts))

    kb = _KB()

    @kb.add("right")
    @kb.add("tab")
    def _right(event):
        state.selected = (state.selected + 1) % 2
        event.app.invalidate()

    @kb.add("left")
    @kb.add("s-tab")
    def _left(event):
        state.selected = (state.selected - 1) % 2
        event.app.invalidate()

    @kb.add("enter")
    def _confirm(event):
        event.app.exit()

    @kb.add("y")
    @kb.add("Y")
    def _yes(event):
        state.selected = 0
        event.app.exit()

    @kb.add("n")
    @kb.add("N")
    @kb.add("escape")
    @kb.add("c-c")
    def _no(event):
        state.selected = 1
        event.app.exit()

    control = FormattedTextControl(_display, focusable=True)
    layout = Layout(Window(content=control), focused_element=control)
    app = Application(layout=layout, key_bindings=kb, full_screen=False)
    await app.run_async()
    console.print()
    return state.selected == 0


async def _collect_response(
    adapter: BackendAdapter,
    messages: list[RequestMessage],
    tool_defs: list[ToolDefinition] | None,
    status_text: list[str],
    streamed_text: list[str] | None = None,
    live: Any = None,
    think_delimiter: str | None = None,
) -> tuple[str, list[ToolCall]]:
    """Stream a response, updating the live display token-by-token."""
    from rich.text import Text as _Text

    text_parts: list[str] = []
    tool_calls: list[ToolCall] = []
    in_think = False
    think_open = think_delimiter or ""
    think_close = think_open.replace("<", "</") if think_open else ""

    async for event in adapter.send_request(messages, tool_defs or []):
        match event:
            case TextChunk(text=chunk):
                text_parts.append(chunk)
                if streamed_text is not None:
                    streamed_text.append(chunk)
                    # Update thinking-block state
                    combined = "".join(streamed_text)
                    if think_open and think_open in combined:
                        in_think = think_close not in combined
                    if live is not None:
                        visible = combined[-2000:] if len(combined) > 2000 else combined
                        style = "dim italic" if in_think else ""
                        try:
                            live.update(_Text(_safe(visible), style=style, no_wrap=False))
                        except Exception:
                            pass
            case ToolCall() as tc:
                tool_calls.append(tc)
                status_text[0] = f"calling {tc.name}..."
            case Done():
                break

    # Final frame: render as Markdown when there are no tool calls
    if live is not None and text_parts and not tool_calls:
        from rich.markdown import Markdown as _MD
        try:
            live.update(_MD("".join(text_parts)))
        except Exception:
            pass  # preserve plain-text fallback already shown

    return "".join(text_parts), tool_calls


async def _execute_tool(
    call: ParsedToolCall,
    tool_map: dict[str, Tool],
    session: Session,
    decision_logger: DecisionLogger,
    circuit_breaker: CircuitBreaker,
    display_text: list[str],
    prompt_session: Any,
    adapter: BackendAdapter | None = None,
    scaffolding: ScaffoldingConfig | None = None,
) -> ToolResult:
    # Recursion guard: subagents cannot spawn other subagents
    if call.name == "spawn_subagent" and session.is_subagent:
        decision_logger.log("intervention", {"reason": "subagent_recursion_blocked", "tool": call.name})
        return ToolResult(success=False, output="", error="Subagents cannot spawn other subagents.")

    tool = tool_map.get(call.name)
    if tool is None:
        available = ", ".join(sorted(tool_map.keys()))
        session.add_injection(
            f"Tool '{call.name}' does not exist. "
            f"The available tools are: {available}. "
            "Please retry using one of these exact tool names."
        )
        return ToolResult(
            success=False, output="",
            error=(
                f"Unknown tool: {call.name!r}. "
                f"Available tools: {available}. "
                "Use one of these exact tool names."
            ),
        )

    # Archetype 4: circuit breaker check
    if check_fragile_execution(circuit_breaker, call):
        injection = build_circuit_break_injection(call)
        session.add_injection(injection)
        decision_logger.log("circuit_break", {"tool": call.name, "count": circuit_breaker.failure_count(call.name, call.arguments)})
        return ToolResult(success=False, output="", error=injection)

    # Determine path for permission check
    path_arg = call.arguments.get("path")
    path = (session.workspace / path_arg).resolve() if path_arg else None
    band, auto_approved = check_permission(call.name, path, session.workspace)

    if band == PermissionBand.FORBIDDEN:
        decision_logger.log("permission", {"tool": call.name, "band": "forbidden", "path": str(path)})
        if path is not None:
            try:
                path.relative_to(session.workspace.resolve())
                err = f"Access to '{path_arg}' is forbidden (sensitive path)."
            except ValueError:
                err = (
                    f"Path '{path_arg}' is outside the workspace ({session.workspace}). "
                    "Codii can only access files within the directory where it was launched. "
                    "To work with files elsewhere, launch codii from that directory."
                )
        else:
            err = f"Operation forbidden: {call.name}"
        return ToolResult(success=False, output="", error=err)

    if band == PermissionBand.CONFIRMATION and not auto_approved:
        decision_logger.log("permission", {"tool": call.name, "band": "confirmation", "path": str(path)})
        if session.auto_mode:
            console.print(f"  [dim][auto] {call.name}({path_arg or ''}) → allowed[/dim]")
        else:
            try:
                allowed = await _ask_tool_confirm(call.name, path_arg or "")
                if not allowed:
                    return ToolResult(success=False, output="", error="User denied permission.")
            except (KeyboardInterrupt, EOFError):
                return ToolResult(success=False, output="", error="User denied permission.")

    display_text[0] = f"{call.name} {path_arg or ''}"

    # Edit mode scope discipline: prompt before out-of-scope writes
    if (
        session.mode == "edit"
        and session.edit_scope
        and call.name in ("write_file", "edit_file")
        and path is not None
        and path.resolve() not in {p.resolve() for p in session.edit_scope}
    ):
        names = ", ".join(p.name for p in session.edit_scope)
        console.print(f"\n  [yellow]⚠[/yellow] {path_arg} is outside edit scope ({names})")
        try:
            allowed = await _ask_tool_confirm("out-of-scope write", path_arg or "")
            if not allowed:
                return ToolResult(success=False, output="", error="Out-of-scope write rejected.")
        except (KeyboardInterrupt, EOFError):
            return ToolResult(success=False, output="", error="Out-of-scope write rejected.")

    # Track reads for archetype 1
    if call.name == "read_file" and path_arg:
        session.record_read((session.workspace / path_arg).resolve())

    # Archetype 1: premature action check
    premature_err = check_premature_action(call, session)
    if premature_err:
        decision_logger.log("intervention", {"archetype": 1, "tool": call.name, "path": path_arg})
        return ToolResult(success=False, output="", error=premature_err)

    # Special execution for spawn_subagent — needs adapter and scaffolding context
    if call.name == "spawn_subagent" and adapter is not None and scaffolding is not None:
        result = await _run_subagent(
            agent_name=call.arguments.get("agent", ""),
            task=call.arguments.get("task", ""),
            adapter=adapter,
            scaffolding=scaffolding,
            workspace=session.workspace,
            parent_session=session,
            decision_logger=decision_logger,
        )
    else:
        result = await tool.execute(call.arguments, session.workspace)

    if result.success:
        circuit_breaker.record_success(call.name, call.arguments)
    else:
        count = circuit_breaker.record_failure(call.name, call.arguments)
        decision_logger.log("timeout" if "timed out" in (result.error or "") else "tool_surface",
                            {"tool": call.name, "error": result.error, "fail_count": count})

    return result


_PLAN_TRIGGERS_RE = re.compile(
    r"\b(refactor|migrate|implement|set up|create a new|redesign|restructure|"
    r"add.{0,30}endpoint|move all|port|convert|extract|split into|break (up|out))\b",
    re.IGNORECASE,
)

_PLAN_STEP_RE = re.compile(r"^\s*(\d+)[.)]\s+(.+)", re.MULTILINE)

_PLANNER_SYSTEM = (
    "You are a planning agent. Given a coding task, write a clear implementation strategy "
    "as 2–4 natural-language paragraphs — describe the approach, key design decisions, and "
    "tradeoffs. Do NOT list individual file edits.\n\n"
    "After your strategy, add a section titled '## Steps' containing 3–7 numbered "
    "implementation steps for sequential agent execution. Each step must describe one "
    "meaningful, self-contained chunk of work (not a single line or trivial edit).\n\n"
    "Do not write code. Do not execute anything. Return strategy and steps only."
)

_CHAT_SYSTEM = (
    "You are an expert pair programmer and software engineering assistant embedded in a "
    "terminal coding tool called Codii. Your role is to provide thoughtful, thorough "
    "answers to programming questions, explain code and concepts clearly, suggest "
    "architecture improvements, review logic, and help debug issues — all without "
    "modifying any files yourself.\n\n"
    "Guidelines:\n"
    "- Always respond in Markdown. Use headers, code blocks (with language tags), and "
    "  bullet lists to structure your answers clearly.\n"
    "- Be thorough: cover edge cases, tradeoffs, and alternatives when they matter. "
    "  Short answers are fine for simple questions; complex questions deserve depth.\n"
    "- Act as a senior engineer: push back gently when you see a better approach, "
    "  but respect the developer's intent.\n"
    "- Do NOT edit, write, or create files. Confine yourself to analysis, explanation, "
    "  and advice.\n"
    "- SOURCE GROUNDING: You have two read-only tools: read_file and list_dir. "
    "  Read the relevant file(s) before answering questions about specific code — never guess. "
    "  Read each file exactly once per question; do NOT re-read a file you already read. "
    "  Once you have enough context, write your complete answer in text immediately. "
    "  Do not call any more tools after you start writing your answer.\n"
    "- A file index is shown below (filenames and line counts). Use it to locate what to read.\n"
    "- Do NOT use LaTeX math notation ($ or $$). Write any mathematical content in "
    "  plain English or as a code comment.\n"
    "- Keep your tone conversational but precise.\n"
    "- If a question is ambiguous, ask one focused clarifying question."
)

# Used after _build_chat_summary() succeeds — no tool instructions, answer from context only
_CHAT_SYSTEM_INDEXED = (
    "You are an expert pair programmer embedded in a terminal coding tool called Codii.\n"
    "A full codebase summary is provided below. Answer all questions directly from it.\n"
    "Do NOT call any tools. Respond in Markdown with headers and code blocks.\n"
    "Be specific and precise. If the summary lacks the information needed, say so explicitly.\n"
)

_MODE_CYCLE: dict[str, str] = {"edit": "plan", "plan": "chat", "chat": "edit", "auto": "edit"}

_SLASH_COMMANDS: list[tuple[str, str]] = [
    ("/help",      "Show available commands"),
    ("/clear",     "Clear conversation history"),
    ("/compact",   "Summarize context to free tokens"),
    ("/context",   "Show detailed context usage breakdown"),
    ("/init",      "Generate CODII.md project documentation"),
    ("/index",     "Re-index workspace files for Chat mode"),
    ("/chat",      "Switch to chat mode"),
    ("/edit",      "Switch to edit mode"),
    ("/plan",      "Switch to plan mode"),
    ("/plan edit", "Open plan editor"),
    ("/scope",     "Show current edit scope"),
    ("/auto",      "Toggle auto-approval"),
    ("/exit",      "Exit session"),
]


class SlashCompleter:
    """Returns completions only when the input line starts with '/'.

    Inherits get_completions_async from prompt_toolkit.completion.Completer,
    which wraps get_completions so the async buffer path doesn't AttributeError.
    """

    def get_completions(self, document: Any, complete_event: Any) -> Any:
        from prompt_toolkit.completion import Completion
        text = document.text_before_cursor.lstrip()
        if not text.startswith("/"):
            return
        for cmd, desc in _SLASH_COMMANDS:
            if cmd.startswith(text):
                yield Completion(
                    cmd,
                    start_position=-len(text),
                    display=cmd,
                    display_meta=desc,
                )

    async def get_completions_async(self, document: Any, complete_event: Any) -> Any:
        for completion in self.get_completions(document, complete_event):
            yield completion




async def _generate_plan(
    adapter: BackendAdapter,
    task: str,
    system_prompt: str,
) -> list[str]:
    """Ask the model for a numbered plan. Returns list of step strings."""
    from codii.connection.base import collect_response, RequestMessage as _RM

    text, _, _ = await collect_response(
        adapter,
        messages=[
            _RM(role="system", content=_PLANNER_SYSTEM),
            _RM(role="user", content=task),
        ],
    )
    steps = [m.group(2).strip() for m in _PLAN_STEP_RE.finditer(text)]
    return steps if steps else [text.strip()]


async def _generate_revised_plan(
    adapter: BackendAdapter,
    current_steps: list[str],
    modification: str,
) -> list[str]:
    """Ask the model to revise an existing plan given a modification request."""
    from codii.connection.base import collect_response, RequestMessage as _RM

    plan_text = "\n".join(f"{i}. {s}" for i, s in enumerate(current_steps, 1))
    msg = (
        f"Current plan:\n{plan_text}\n\n"
        f"Modification request: {modification}\n\n"
        "Produce a revised numbered plan. Return only the plan."
    )
    text, _, _ = await collect_response(
        adapter,
        messages=[
            _RM(role="system", content=_PLANNER_SYSTEM),
            _RM(role="user", content=msg),
        ],
    )
    steps = [m.group(2).strip() for m in _PLAN_STEP_RE.finditer(text)]
    return steps if steps else []


def _plans_identical(a: list[str], b: list[str]) -> bool:
    """Normalized plan comparison: strip numbering, whitespace, and case."""
    _lead_num = re.compile(r"^\d+[.)]\s*")
    def _norm(steps: list[str]) -> list[str]:
        return [_lead_num.sub("", s).strip().lower() for s in steps]
    return _norm(a) == _norm(b)


async def _present_plan(
    steps: list[str],
    prompt_session: Any,
) -> bool:
    """Display plan and return True if approved, False if rejected."""
    from rich.console import Console as _Con
    _con = _Con()
    _con.print("\n[bold cyan]Plan:[/bold cyan]")
    for i, step in enumerate(steps, 1):
        _con.print(f"  [cyan]{i}.[/cyan] {step}")
    _con.print()
    try:
        answer = await prompt_session.prompt_async(
            f"[{len(steps)} steps] Press Enter to approve, 'n' to reject: "
        )
        return answer.strip().lower() not in ("n", "no", "reject")
    except (KeyboardInterrupt, EOFError):
        return False


async def _auto_verify(
    session: "Session",
    tool_map: dict[str, Tool],
    decision_logger: DecisionLogger,
) -> None:
    """Auto mode: verify written files exist and Python files are syntax-clean."""
    bash = tool_map.get("bash")
    if not bash:
        return

    from codii.parser.base import ParsedToolCall as _PTC
    for p in session.recent_writes[-5:]:  # check last 5 writes
        if not p.exists():
            msg = f"Verification failed: {p} was not created."
            console.print(f"  [yellow]⚠[/yellow] {msg}")
            session.add_injection(f"Task declared complete but {msg} Please fix.")
            decision_logger.log("intervention", {"archetype": "auto_verify", "path": str(p), "error": "file_missing"})
            return
        if p.suffix == ".py":
            dummy_call = _PTC(id="verify", name="bash", arguments={"command": f"python -m py_compile {p}"})
            result = await bash.execute(dummy_call.arguments, session.workspace)
            if not result.success:
                msg = f"Syntax error in {p.name}: {result.error}"
                console.print(f"  [yellow]⚠[/yellow] {msg}")
                session.add_injection(f"Task declared complete but verification failed: {msg}. Please fix.")
                decision_logger.log("intervention", {"archetype": "auto_verify", "path": str(p), "error": result.error})
                return


async def _run_subagent(
    agent_name: str,
    task: str,
    adapter: BackendAdapter,
    scaffolding: ScaffoldingConfig,
    workspace: Path,
    parent_session: "Session",
    decision_logger: DecisionLogger,
) -> ToolResult:
    """Execute a built-in subagent with its restricted tool set and isolated context."""
    agent_cfg = BUILTIN_AGENTS.get(agent_name)
    if not agent_cfg:
        return ToolResult(
            success=False, output="",
            error=f"Unknown subagent '{agent_name}'. Available: {', '.join(BUILTIN_AGENTS)}.",
        )

    allowed_tools: list[Tool] = [t for t in _ALL_TOOLS if t.name in agent_cfg["tools"]]
    agent_tool_defs = [t.definition() for t in allowed_tools] if scaffolding.tool_format == "native_json" else None
    agent_tool_map = {t.name: t for t in allowed_tools}

    sub_session = Session(workspace, is_subagent=True)
    parser = get_parser(scaffolding.parser_key)
    system_prompt = agent_cfg["system"]
    max_turns = agent_cfg["max_turns"]

    sub_session.add_message(RequestMessage(role="user", content=task))
    final_text = ""

    for _ in range(max_turns):
        messages = [RequestMessage(role="system", content=system_prompt)] + list(sub_session.history)
        try:
            text, raw_tc = await _collect_response(adapter, messages, agent_tool_defs, [""])
        except Exception as e:
            return ToolResult(success=False, output="", error=f"Subagent error: {e}")

        sub_session.add_message(RequestMessage(role="assistant", content=text))
        final_text = text

        parsed: list[ParsedToolCall] = []
        if raw_tc:
            import uuid as _uuid
            for tc in raw_tc:
                parsed.append(ParsedToolCall(id=tc.id or str(_uuid.uuid4()), name=tc.name, arguments=tc.arguments))
        else:
            raw_parsed = parser.parse(text, agent_tool_defs or [])
            parsed = [c for c in raw_parsed if c.name != "__repair_failed__"]

        if not parsed:
            break

        tool_results: list[str] = []
        for call in parsed:
            tool = agent_tool_map.get(call.name)
            if not tool:
                tool_results.append(f"Tool: {call.name}\nResult: ERROR\nNot available to this subagent.")
                continue
            result = await tool.execute(call.arguments, workspace)
            tool_results.append(
                f"Tool: {call.name}\nResult: {'OK' if result.success else 'ERROR'}\n"
                f"{result.output or result.error or ''}"
            )

        sub_session.add_message(RequestMessage(role="tool", content="\n\n---\n\n".join(tool_results)))

    decision_logger.log("subagent", {"agent": agent_name, "task": task[:100], "turns": sub_session.turn_count})
    return ToolResult(success=True, output=final_text, error=None)


def _estimate_tokens(text: str) -> int:
    return max(1, len(text) // 4)


def _history_tokens(history: list[RequestMessage]) -> int:
    return sum(_estimate_tokens(m.content) for m in history)


_SUMMARIZE_PROMPT = (
    "You are a context summarizer. The following is a conversation history. "
    "Produce a compact factual summary of: what task was being worked on, "
    "which files were read or modified, key findings, and the current state. "
    "Be concise — 3 to 8 sentences maximum. Do not include tool call details.\n\n"
    "Conversation:\n{history}"
)


async def _compact_context(
    session: Session,
    adapter: BackendAdapter,
    decision_logger: DecisionLogger,
    system_prompt: str,
) -> None:
    """Compact session history to fit within effective context."""
    from codii.connection.base import collect_response, RequestMessage as _RM

    before_tokens = _history_tokens(session.history)

    # Always preserve the last 6 messages (3 turns) verbatim
    keep_tail = session.history[-6:]
    to_summarize = session.history[:-6]

    if not to_summarize:
        return  # nothing to compact

    history_text = "\n".join(
        f"{m.role.upper()}: {m.content[:500]}" for m in to_summarize
    )
    summary_prompt = _SUMMARIZE_PROMPT.format(history=history_text[:8000])

    try:
        summary_text, _, _ = await collect_response(
            adapter,
            messages=[
                _RM(role="system", content=system_prompt),
                _RM(role="user", content=summary_prompt),
            ],
        )
    except Exception:
        summary_text = f"[Context compacted: {len(to_summarize)} earlier messages summarized]"

    summary_msg = _RM(role="user", content=f"[Context summary]\n{summary_text.strip()}")
    session.history = [summary_msg] + list(keep_tail)

    after_tokens = _history_tokens(session.history)
    reduction = 1.0 - (after_tokens / max(before_tokens, 1))

    decision_logger.log("compact", {
        "before_tokens": before_tokens,
        "after_tokens": after_tokens,
        "summarized_messages": len(to_summarize),
        "preserved_messages": len(keep_tail),
        "reduction_pct": round(reduction * 100, 1),
    })

    if reduction < 0.20:
        # Compaction barely helped — back off for 5 turns to avoid infinite loop
        session.compaction_cooldown = 5
        decision_logger.log("compact", {"warning": "low_reduction", "cooldown_turns": 5})


async def run_session(
    adapter: BackendAdapter,
    fp: CapabilityFingerprint,
    scaffolding: ScaffoldingConfig,
    workspace: Path,
    *,
    auto_mode: bool = False,
) -> None:
    """Run an interactive TAOR session."""
    session = Session(workspace, auto_mode=auto_mode)
    _chat_snapshot: str | None = None
    session_dir = session.session_dir
    session_dir.mkdir(parents=True, exist_ok=True)

    decision_logger = DecisionLogger(session_dir)
    circuit_breaker = CircuitBreaker()
    tool_map = _tool_map()

    # Transcript writer — records every session event for replay
    fp_summary = {
        "family": fp.capabilities.family,
        "tier": fp.capabilities.tier,
        "tool_call_format": fp.capabilities.tool_call_format,
        "effective_context_tokens": fp.capabilities.effective_context_tokens,
    }
    transcript = TranscriptWriter(session_dir, fp_summary, fp.capabilities.tier)

    decision_logger.log("tier_select", {
        "tier": scaffolding.tier,
        "tool_format": scaffolding.tool_format,
        "parser_key": scaffolding.parser_key,
        "token_count_method": "4-char-approximation",
    })

    # Initialize ledger
    ledger = initialize_ledger(workspace)
    session.ledger = ledger

    _native = fp.capabilities.native_tool_calling
    tools = _select_tools(scaffolding, native_override=_native)
    # Always build native tool defs for models that support native tool calling.
    # The old guard (only for native_json tier) meant demotion silently dropped all
    # tool definitions — leaving edit_file, write_file, bash unreachable.
    tool_defs = (
        _build_tool_defs(tools)
        if _native or scaffolding.tool_format == "native_json"
        else None
    )
    system_prompt = _build_system_prompt(scaffolding, tools, ledger)
    parser = get_parser(scaffolding.parser_key)

    try:
        from prompt_toolkit.application import Application
        from prompt_toolkit.buffer import Buffer
        from prompt_toolkit.formatted_text import FormattedText as _FT
        from prompt_toolkit.history import InMemoryHistory
        from prompt_toolkit.key_binding import KeyBindings, merge_key_bindings
        from prompt_toolkit.key_binding.defaults import load_key_bindings
        from prompt_toolkit.layout import Layout
        from prompt_toolkit.layout.containers import (
            HSplit, ScrollOffsets, VSplit, Window, FloatContainer, Float,
        )
        from prompt_toolkit.layout.controls import BufferControl, FormattedTextControl
        from prompt_toolkit.layout.menus import CompletionsMenu
        from prompt_toolkit.layout.processors import BeforeInput
        from prompt_toolkit.shortcuts import PromptSession

        kb = KeyBindings()

        @kb.add("c-c")
        def _ctrl_c(event: Any) -> None:
            raise KeyboardInterrupt

        @kb.add("s-tab")
        def _toggle_mode(event: Any) -> None:
            session.mode = _MODE_CYCLE.get(session.mode, "edit")
            event.app.invalidate()

        @kb.add("c-l")
        def _clear_screen(event: Any) -> None:
            event.app.renderer.clear()

        def _mode_color() -> str:
            if session.mode == "edit":
                return "fg:#e07a30"
            if session.mode == "plan":
                return "fg:#4a9eff"
            if session.mode == "chat":
                return "fg:#5fb45a"
            return "fg:#666666"

        def _top_label() -> str:
            if session.mode == "edit":
                return " ✎ edit (shift+tab to cycle modes) "
            if session.mode == "plan":
                return " ⏸ plan (shift+tab to cycle modes) "
            if session.mode == "chat":
                return " 💬 chat (shift+tab to cycle modes) "
            return " codii (shift+tab to cycle modes) "

        # Single-keypress confirmation session
        _confirm_kb = KeyBindings()

        @_confirm_kb.add("y")
        @_confirm_kb.add("Y")
        @_confirm_kb.add("enter")
        def _ck_yes(event: Any) -> None:
            event.app.exit(result="y")

        @_confirm_kb.add("n")
        @_confirm_kb.add("N")
        @_confirm_kb.add("escape")
        @_confirm_kb.add("c-c")
        def _ck_no(event: Any) -> None:
            event.app.exit(result="n")

        confirm_session_obj: PromptSession[str] = PromptSession(key_bindings=_confirm_kb)

        _prompt_history = InMemoryHistory()
        _simple_ps: PromptSession[str] = PromptSession()

        async def _main_prompt() -> str:
            """Custom HSplit: top bar | auto-height scrollable input | bottom bar."""
            # multiline=True: up/down navigate visual lines; paste lands fully in buffer.
            buf = Buffer(
                history=_prompt_history,
                multiline=True,
                completer=SlashCompleter(),
                complete_while_typing=True,
            )

            buf_control = BufferControl(
                buffer=buf,
                input_processors=[BeforeInput("❯ ")],
                focusable=True,
            )

            def _input_height() -> int:
                """Natural content height capped at terminal rows-2."""
                try:
                    from prompt_toolkit import get_app
                    _a = get_app()
                    rows, cols = _a.output.get_size().rows, _a.output.get_size().columns
                except Exception:
                    import shutil
                    _s = shutil.get_terminal_size()
                    rows, cols = _s.lines, _s.columns
                max_h = max(1, rows - 3)
                try:
                    ph = buf_control.preferred_height(
                        cols, max_h, wrap_lines=True, get_line_prefix=None
                    )
                except TypeError:
                    try:
                        ph = buf_control.preferred_height(cols, max_h)
                    except Exception:
                        ph = None
                return min(max(1, ph if ph is not None else 1), max_h)

            _submit_kb = KeyBindings()

            # eager=True fires before load_key_bindings()'s "insert newline" handler,
            # so Enter submits even though the buffer is in multiline mode.
            # When a completion is highlighted, accept it instead of submitting.
            @_submit_kb.add("enter", eager=True)
            def _submit(event: Any) -> None:
                cs = buf.complete_state
                if cs is not None and cs.current_completion is not None:
                    buf.apply_completion(cs.current_completion)
                    return
                if buf.text.strip():
                    _prompt_history.append_string(buf.text)
                event.app.exit()

            # Ctrl-D: exit when buffer empty (standard shell behaviour), else delete char.
            @_submit_kb.add("c-d", eager=True)
            def _eof(event: Any) -> None:
                if not buf.text:
                    raise EOFError
                event.current_buffer.delete(count=1)

            input_win = Window(
                content=buf_control,
                wrap_lines=True,
                height=_input_height,
                scroll_offsets=ScrollOffsets(top=2, bottom=2),
            )
            # Separators use Window(char="─") so prompt_toolkit fills them to
            # the exact allocated width automatically — no manual shutil/cols
            # arithmetic, no Unicode-width miscounting, no resize artifacts.
            # The top bar is a VSplit: 4 fixed dashes | mode label | fill dashes.
            top_bar = VSplit([
                Window(width=4, char="─", style=_mode_color),
                Window(
                    content=FormattedTextControl(_top_label, focusable=False),
                    dont_extend_width=True,
                    style=_mode_color,
                ),
                Window(char="─", style=_mode_color),
            ], height=1)
            bottom_bar = Window(char="─", height=1, style=_mode_color)

            def _ctx_bar_text() -> list[tuple[str, str]]:
                caps = fp.effective_capabilities()
                cap = caps.effective_context_tokens or fp.capabilities.claimed_context_tokens
                # Include snapshot tokens so chat-mode indexing shows up immediately.
                # _chat_snapshot is captured from run_session scope via closure.
                snap_tokens = _estimate_tokens(_chat_snapshot) if _chat_snapshot else 0
                used = _history_tokens(session.history) + snap_tokens
                if cap > 0:
                    pct = int(used * 100 / cap)
                    used_k = f"{used / 1000:.1f}k" if used >= 100 else ("<0.1k" if used > 0 else "0k")
                    cap_k  = f"{cap  / 1000:.0f}k"
                    ctx_str = f"Context: {used_k} / {cap_k} ({pct}%) | {fp.model}"
                else:
                    ctx_str = f"Context: calculating… | {fp.model}"
                return [("fg:#555555", ctx_str), ("", " ")]

            context_bar = VSplit([
                Window(char=" "),
                Window(
                    content=FormattedTextControl(_ctx_bar_text, focusable=False),
                    dont_extend_width=True,
                ),
            ], height=1)

            layout = Layout(
                FloatContainer(
                    content=HSplit([top_bar, input_win, bottom_bar, context_bar]),
                    floats=[
                        Float(
                            xcursor=True,
                            ycursor=True,
                            transparent=True,
                            content=CompletionsMenu(max_height=8, scroll_offset=1),
                        ),
                    ],
                ),
                focused_element=input_win,
            )
            all_kb = merge_key_bindings([load_key_bindings(), kb, _submit_kb])
            app: Application[None] = Application(
                layout=layout,
                key_bindings=all_kb,
                erase_when_done=True,
                full_screen=False,
            )
            await app.run_async()
            return buf.text

        # ── Nested session functions (closures over outer scope) ───────────────

        core: AgentCore | None = None  # forward reference for _adapt_scaffolding

        def _adapt_scaffolding(new_tier: int) -> None:
            """Rebuild scaffolding/tools/prompt/parser for new_tier in-place."""
            nonlocal scaffolding, tools, tool_defs, system_prompt, parser
            fp_copy = fp.model_copy(deep=True)
            fp_copy.user_overrides["tier"] = new_tier
            scaffolding = select_scaffolding(fp_copy, backend=fp.backend)
            tools = _select_tools(scaffolding, native_override=fp.capabilities.native_tool_calling)
            # Preserve native tool defs through demotion — tier changes the prompt/parser
            # strategy but must never drop tools from the API call for native-capable models.
            tool_defs = (
                _build_tool_defs(tools)
                if fp.capabilities.native_tool_calling or scaffolding.tool_format == "native_json"
                else None
            )
            system_prompt = _build_system_prompt(scaffolding, tools, ledger)
            parser = get_parser(scaffolding.parser_key)
            if core is not None:
                core.update_scaffolding(
                    scaffolding, {t.name: t for t in tools}, tool_defs, parser
                )

        async def _subagent_fn(agent_name: str, task: str) -> Any:
            return await _run_subagent(
                agent_name=agent_name,
                task=task,
                adapter=adapter,
                scaffolding=scaffolding,
                workspace=workspace,
                parent_session=session,
                decision_logger=decision_logger,
            )

        core = AgentCore(
            adapter=adapter,
            session=session,
            scaffolding=scaffolding,
            tool_map={t.name: t for t in tools},
            tool_defs=tool_defs,
            parser=parser,
            decision_logger=decision_logger,
            transcript=transcript,
            console=console,
            confirm_fn=_ask_tool_confirm,
            collect_response_fn=_collect_response,
            adapt_scaffolding_fn=_adapt_scaffolding,
            run_subagent_fn=_subagent_fn,
            fp=fp,
        )

        async def _run_taor_turn(task: str) -> None:
            """Thin wrapper — delegates to AgentCore."""
            await core.run_turn(task)
        async def _rank_workspace_files(max_ranked: int = 40) -> list[Path]:
            """Return workspace files ordered by LLM-assessed importance, falling back to heuristics."""
            from codii.connection.base import collect_response as _cr, RequestMessage as _RM
            import json as _json, re as _re2

            _skip = {".git", "__pycache__", "node_modules", ".venv", "venv",
                     ".mypy_cache", ".ruff_cache", "dist", "build", ".codii",
                     ".pytest_cache", ".eggs"}
            all_files = sorted(
                (p for p in workspace.rglob("*")
                 if p.is_file() and not any(s in p.parts for s in _skip)),
                key=lambda p: str(p),
            )
            if not all_files:
                return []

            # Always use forward slashes so the LLM returns consistent paths on
            # all platforms (Windows Path.relative_to() produces backslashes).
            def _rel_fwd(p: Path) -> str:
                return p.relative_to(workspace).as_posix()

            rel_paths = [_rel_fwd(p) for p in all_files]
            paths_for_llm = rel_paths[:300]

            ranking_prompt = (
                "Given a list of file paths in a directory, return a JSON array of the most "
                "important file paths to read first for understanding the folder's purpose. "
                "Use your knowledge of naming conventions: README*, manifest files "
                "(package.json, Cargo.toml, pyproject.toml, Makefile, Dockerfile, etc.), "
                "entry points (main.*, index.*, app.*), and overview-level files rank highest. "
                "Do NOT assume a specific project type — let the actual filenames guide you. "
                f"Return ONLY a JSON array of up to {max_ranked} exact path strings from the "
                "input list. No explanation."
            )
            try:
                raw, _, _ = await asyncio.wait_for(
                    _cr(adapter, messages=[
                        _RM(role="system", content=ranking_prompt),
                        _RM(role="user", content="\n".join(paths_for_llm)),
                    ]),
                    timeout=15.0,
                )
                m = _re2.search(r"\[.*?\]", raw, _re2.DOTALL)
                ranked_rel: list[str] = _json.loads(m.group(0) if m else raw.strip())
                # Use forward-slash keys so Windows backslash paths also match.
                rel_to_path = {_rel_fwd(p): p for p in all_files}
                ranked_rel_fwd = [r.replace("\\", "/") for r in ranked_rel]
                ranked = [rel_to_path[r] for r in ranked_rel_fwd if r in rel_to_path]
                ranked_set = {p.resolve() for p in ranked}
                remaining = [p for p in all_files if p.resolve() not in ranked_set]
                return ranked + remaining
            except Exception:
                def _rank_key(p: Path) -> tuple:
                    n = p.name.lower()
                    high = any(n.startswith(k) for k in (
                        "readme", "index", "main", "app", "package", "cargo",
                        "pyproject", "setup", "makefile", "dockerfile",
                    ))
                    return (0 if high else 1, p.stat().st_size)
                return sorted(all_files, key=_rank_key)

        async def _build_chat_summary() -> str:
            """Read the most important project files and return their content as a summary.

            The summary is cached once and reused for all chat answers — no further
            tool calls are needed after this runs.
            """
            ranked_files = await _rank_workspace_files(max_ranked=20)
            parts: list[str] = ["## Codebase Summary\n"]
            char_budget = 24_000  # ~6k tokens
            used = 0
            seen: set[Path] = set()

            for path in ranked_files:
                resolved = path.resolve()
                if resolved in seen or used >= char_budget:
                    break
                seen.add(resolved)
                try:
                    rel = str(path.relative_to(workspace.resolve()))
                except ValueError:
                    rel = str(path)
                try:
                    content = path.read_text(encoding="utf-8", errors="replace")
                except OSError:
                    continue
                # Store FULL content in session cache before any truncation
                session.file_cache[rel] = content
                session.record_read(path)

                file_lines = content.splitlines()
                total = len(file_lines)
                snippet = "\n".join(file_lines[:150])
                suffix = path.suffix.lstrip(".") or "txt"
                entry = f"\n### {rel} ({total} lines)\n```{suffix}\n{snippet}\n```\n"

                if used + len(entry) > char_budget:
                    remaining = char_budget - used
                    parts.append(entry[:remaining])
                    break

                parts.append(entry)
                used += len(entry)

            return "".join(parts)

        async def _run_chat_turn(task: str) -> None:
            """Chat mode — two phases:
            1. First call: read project files once, cache a comprehensive summary.
            2. Subsequent calls: answer directly from the cached summary, no tools.
            """
            nonlocal _chat_snapshot
            if _chat_snapshot is None:
                console.print(
                    f"[dim]Chat mode will read your project files to build a codebase summary "
                    f"({fp.model}). This happens once.[/dim]"
                )
                try:
                    _consent = (await _simple_ps.prompt_async("Proceed? (y/n): ")).strip().lower()
                except (KeyboardInterrupt, EOFError):
                    _consent = "n"
                if _consent in ("y", "yes", ""):
                    console.print("[dim]Reading project files…[/dim]")
                    _chat_snapshot = await _build_chat_summary()
                    session.chat_summary = _chat_snapshot
                    session.chat_indexed = True
                    import re as _re_fc
                    file_count = len(_re_fc.findall(r'^### .+ \(\d+ lines\)$', _chat_snapshot, _re_fc.MULTILINE))
                    snap_tokens = _estimate_tokens(_chat_snapshot)
                    console.print(
                        f"[dim]Summarized {file_count} file(s) "
                        f"(~{max(snap_tokens // 1000, 1)}k tokens cached).[/dim]"
                    )
                else:
                    console.print("[dim]Skipped. Chat will read files on demand.[/dim]")
                    _chat_snapshot = ""

            if session.chat_indexed and _chat_snapshot:
                # Phase 2: no tools — answer from cached summary
                chat_system = _CHAT_SYSTEM_INDEXED + "\n\n" + _chat_snapshot
            else:
                # Fallback: use tools to read files on demand
                ledger_section = f"\n\n## Project context\n{ledger}" if ledger else ""
                chat_system = _CHAT_SYSTEM + ledger_section

            await core.run_turn(task, mode="chat", system_override=chat_system)

        async def _run_plan_mode(user_input: str) -> None:
            """Generate plan, show approval UI, then execute via AgentCore (auto-approved)."""
            raw = user_input.lstrip("/plan").strip() or user_input
            console.print("[dim]Generating plan…[/dim]")
            steps = await _generate_plan(adapter, raw, system_prompt)
            if not steps:
                console.print("[red]Could not generate a plan. Describe the task differently.[/red]")
                session.mode = "auto"
                return

            if len(steps) == 1:
                console.print("[dim]Single-step task — executing directly.[/dim]")
                await core.run_turn(raw)
                session.mode = "auto"
                return

            plan_path = session.session_dir / "plan.md"
            plan_path.parent.mkdir(parents=True, exist_ok=True)
            _write_plan_to_disk(steps, plan_path)

            while True:
                _render_plan_panel(steps, ["pending"] * len(steps), title="Generated Plan")
                action = await _ask_plan_approval()

                if action == "approve":
                    console.print("[dim]Approved.[/dim]")
                    break
                elif action == "reject":
                    console.print("[dim]Plan rejected.[/dim]")
                    session.mode = "auto"
                    return
                elif action == "edit":
                    console.print("[dim]Entering edit mode — describe your changes:[/dim]")
                    mod_request = ""
                    while not mod_request:
                        try:
                            mod_request = (
                                await _simple_ps.prompt_async("  modification › ")
                            ).strip()
                        except (KeyboardInterrupt, EOFError):
                            break
                        if not mod_request:
                            console.print("[dim]Describe your changes (cannot be empty):[/dim]")
                    if not mod_request:
                        continue
                    console.print("[dim]Revising plan…[/dim]")
                    revised = await _generate_revised_plan(adapter, steps, mod_request)
                    if not revised:
                        console.print("[red]Could not revise the plan.[/red]")
                        continue
                    if _plans_identical(revised, steps):
                        console.print("[dim]Plan unchanged. Approve, edit again, or reject?[/dim]")
                        continue
                    steps = revised
                    _write_plan_to_disk(steps, plan_path)

            decision_logger.log("tool_surface", {"event": "plan_approved", "steps": len(steps)})
            _render_plan_panel(steps, ["pending"] * len(steps), "Approved Plan")
            console.print("[dim]Executing plan…[/dim]")

            # Attach plan state to session so the DCB can track and display progress.
            from codii.loop.plan_state import PlanState
            session.plan_state = PlanState(steps)

            # Build the plan into the prompt so it lives in conversation history.
            # The DCB also renders the plan on every inner turn as a persistent state block.
            # auto_approve=True because the user already gave consent above.
            plan_text = "\n".join(f"{i}. {s}" for i, s in enumerate(steps, 1))
            prefixed = (
                f"Execute the following plan step by step. Complete ALL steps.\n\n"
                f"<plan>\n{plan_text}\n</plan>\n\n"
                f"Original task: {raw}"
            )
            await core.run_turn(prefixed, auto_approve=True)
            session.plan_state = None
            session.mode = "auto"

        async def _plan_edit_flow() -> None:
            """Apply a modification to the current task via a new agent turn."""
            console.print("[dim]Describe the modification you want:[/dim]")
            try:
                mod = (await _simple_ps.prompt_async("  modification › ")).strip()
            except (KeyboardInterrupt, EOFError):
                return
            if mod:
                await core.run_turn(f"Modification request: {mod}")

        # ── Slash-command helpers ───────────────────────────────────────────────

        def _record_cmd(cmd: str, response: str) -> None:
            """Persist a slash-command exchange in history and transcript."""
            transcript.write_event("user_message", {"content": cmd})
            session.add_message(RequestMessage(role="user", content=cmd))
            transcript.write_event("assistant_message", {"content": response})
            session.add_message(RequestMessage(role="assistant", content=response))

        def _echo_user_cmd(text: str) -> None:
            """Print a mode-colored user bubble for a slash command."""
            import rich.box as _rbox2
            _colors = {
                "edit": ("#e07a30", "✎ edit"),
                "plan": ("#4a9eff", "⏸ plan"),
                "chat": ("#5fb45a", "💬 chat"),
            }
            _col, _pfx = _colors.get(session.mode, ("#888888", "❯"))
            _t = text[:200] + ("…" if len(text) > 200 else "")
            console.print(Panel(
                f"[white]{_t}[/white]",
                border_style=_col,
                title=f"[bold {_col}]{_pfx}[/bold {_col}]",
                title_align="left",
                padding=(0, 1),
                box=_rbox2.ROUNDED,
            ))
            console.print()

        # ── Outer session loop ──────────────────────────────────────────────────

        while True:
            try:
                console.print()
                user_input = await _main_prompt()
            except (KeyboardInterrupt, EOFError):
                console.print("\n[dim]Exiting session.[/dim]")
                break

            stripped = user_input.strip()
            if not stripped:
                continue

            # Slash commands (mode-agnostic)
            if stripped.lower() in ("/exit", "/quit", "exit", "quit"):
                console.print("[dim]Goodbye.[/dim]")
                break
            if stripped == "/auto":
                _echo_user_cmd(stripped)
                session.auto_mode = not session.auto_mode
                _auto_resp = f"Auto-approval {'enabled' if session.auto_mode else 'disabled'}."
                console.print(f"[dim]{_auto_resp}[/dim]")
                _record_cmd(stripped, _auto_resp)
                continue
            if stripped == "/plan":
                _echo_user_cmd(stripped)
                session.mode = "plan"
                console.print("[dim]Plan mode active. Type your task.[/dim]")
                _record_cmd(stripped, "Switched to Plan mode.")
                continue
            if stripped == "/plan edit":
                _echo_user_cmd(stripped)
                await _plan_edit_flow()
                _record_cmd(stripped, "Opened plan editor.")
                continue
            if stripped == "/edit":
                _echo_user_cmd(stripped)
                _prev_mode = session.mode
                session.mode = "edit"
                console.print("[dim]Edit mode. Mention a file in your next message to set scope.[/dim]")
                if _prev_mode == "chat":
                    session.add_message(RequestMessage(role="user", content="[Mode switch: Chat → Edit]"))
                    session.add_message(RequestMessage(role="assistant", content=(
                        "Switching to Edit mode. Previous responses were in read-only Chat mode "
                        "where file tools are not used. I'll use the available tools going forward."
                    )))
                _record_cmd(stripped, "Switched to Edit mode.")
                continue
            if stripped == "/scope":
                _echo_user_cmd(stripped)
                if session.edit_scope:
                    console.print("[dim]Edit scope:[/dim]")
                    _scope_lines: list[str] = []
                    for _sp in session.edit_scope:
                        try:
                            _sl = str(_sp.relative_to(workspace))
                        except ValueError:
                            _sl = str(_sp)
                        console.print(f"  [cyan]{_sl}[/cyan]")
                        _scope_lines.append(_sl)
                    _scope_resp = "Edit scope:\n" + "\n".join(f"- {l}" for l in _scope_lines)
                else:
                    console.print("[dim]No edit scope set.[/dim]")
                    _scope_resp = "No edit scope set."
                _record_cmd(stripped, _scope_resp)
                continue

            if stripped == "/help":
                _echo_user_cmd(stripped)
                _help_cmds = [
                    ("/help",      "Show this help"),
                    ("/clear",     "Clear conversation history"),
                    ("/compact",   "Summarize context to free tokens"),
                    ("/context",   "Show detailed context usage"),
                    ("/init",      "Generate CODII.md documentation"),
                    ("/index",     "Re-index workspace files for Chat mode"),
                    ("/chat",      "Switch to chat mode"),
                    ("/edit",      "Switch to edit mode"),
                    ("/plan",      "Switch to plan mode"),
                    ("/scope",     "Show current edit scope"),
                    ("/auto",      "Toggle auto-approval"),
                    ("/exit",      "Exit session"),
                ]
                console.print("[bold]Commands:[/bold]")
                for _cmd, _desc in _help_cmds:
                    console.print(f"  [cyan]{_cmd:<14}[/cyan] [dim]{_desc}[/dim]")
                _help_text = "Available commands:\n\n" + "\n".join(
                    f"- `{c}` — {d}" for c, d in _help_cmds
                )
                _record_cmd(stripped, _help_text)
                continue

            if stripped == "/clear":
                _echo_user_cmd(stripped)
                session.history.clear()
                session.turn_count = 0
                console.print("[dim]Conversation cleared.[/dim]")
                continue

            if stripped == "/compact":
                _echo_user_cmd(stripped)
                if len(session.history) < 4:
                    console.print("[dim]Nothing to compact yet.[/dim]")
                else:
                    console.print("[dim]Compacting context…[/dim]")
                    await _compact_context(session, adapter, decision_logger, system_prompt)
                continue

            if stripped == "/context":
                _echo_user_cmd(stripped)
                _caps = fp.effective_capabilities()
                _cap  = _caps.effective_context_tokens or fp.capabilities.claimed_context_tokens
                _used = _history_tokens(session.history)
                _sys  = _estimate_tokens(system_prompt)
                console.print("[bold]Context breakdown:[/bold]")
                console.print(f"  System prompt : [cyan]{_sys:,}[/cyan] tokens (est.)")
                console.print(f"  History       : [cyan]{_used:,}[/cyan] tokens (est.)")
                console.print(f"  Total in use  : [cyan]{_used + _sys:,}[/cyan] tokens")
                _ctx_lines = [
                    f"System prompt: {_sys:,} tokens",
                    f"History: {_used:,} tokens",
                    f"Total: {_used + _sys:,} tokens",
                ]
                if _cap:
                    _pct = int((_used + _sys) * 100 / _cap)
                    console.print(f"  Window        : [cyan]{_cap:,}[/cyan] tokens ({_pct}% used)")
                    _ctx_lines.append(f"Window: {_cap:,} tokens ({_pct}% used)")
                console.print(f"  Model         : [cyan]{fp.model}[/cyan]")
                _ctx_lines.append(f"Model: {fp.model}")
                _record_cmd(stripped, "\n".join(_ctx_lines))
                continue

            if stripped == "/init":
                _echo_user_cmd(stripped)
                from codii.connection.base import collect_response as _cr, RequestMessage as _RM
                from datetime import datetime as _dt
                _init_path = workspace / "CODII.md"
                console.print("[dim]Generating CODII.md…[/dim]")

                # ── Discover facts from the project ──────────────────────────
                _name_str = "Codii"
                _deps_str = ""
                _entry_str = ""
                _pyproject_path = workspace / "pyproject.toml"
                if _pyproject_path.exists():
                    try:
                        try:
                            import tomllib as _toml
                        except ImportError:
                            import tomli as _toml  # type: ignore[no-redef]
                        with _pyproject_path.open("rb") as _f:
                            _pdata = _toml.load(_f)
                        _proj = _pdata.get("project", {})
                        _name_str = _proj.get("name", _name_str).capitalize()
                        _deps_str = "\n".join(
                            f"- {d}" for d in _proj.get("dependencies", [])[:20]
                        )
                        _scripts = _proj.get("scripts", {})
                        if _scripts:
                            _entry_str = next(iter(_scripts.keys()))
                    except Exception:
                        pass

                # Extract tree section from ledger (up to 60 lines)
                _tree_lines: list[str] = []
                _in_tree = False
                for _ln in ledger.splitlines():
                    if _ln.startswith("## Project structure"):
                        _in_tree = True
                        continue
                    if _in_tree:
                        if _ln.startswith("##"):
                            break
                        _tree_lines.append(_ln)
                _tree_str = "\n".join(_tree_lines[:60])

                # Read top-ranked files for richer LLM context (LLM-driven, not hardcoded)
                _extra_ctx = ""
                try:
                    _top_files = await asyncio.wait_for(
                        _rank_workspace_files(max_ranked=8), timeout=15.0
                    )
                    for _cf in _top_files[:8]:
                        try:
                            _txt = _cf.read_text(encoding="utf-8", errors="replace")[:2000]
                            _extra_ctx += (
                                f"\n\n### {_cf.relative_to(workspace)}\n"
                                f"```{_cf.suffix.lstrip('.')}\n{_txt}\n```"
                            )
                        except OSError:
                            pass
                except Exception:
                    pass

                # ── Try LLM generation ────────────────────────────────────────
                _init_prompt = (
                    "Generate a CODII.md documentation file for this folder. "
                    "Your primary task is the **Overview** section: examine the provided file "
                    "tree and file contents to determine the *actual* purpose of this folder — "
                    "do not assume it is a coding project. It might be a novel, research notes, "
                    "a config repo, a web app, or anything else. Write a specific, "
                    "information-dense Overview that: (1) states the apparent domain and "
                    "purpose, (2) describes the high-level organizational structure, (3) lists "
                    "the most important files or directories and their roles. Then include "
                    "(where applicable): Architecture summary, Tech stack, Common dev commands. "
                    "Always include a 'For AI' section with guidance for Edit/Plan/Chat modes. "
                    "Use ## Markdown headers. Be concrete — avoid generic filler text. "
                    "Base everything strictly on the files shown."
                )
                _init_text: str | None = None
                try:
                    _init_text, _, _ = await asyncio.wait_for(
                        _cr(
                            adapter,
                            messages=[
                                _RM(role="system", content=_init_prompt),
                                _RM(role="user", content=f"Project context:\n{ledger}{_extra_ctx}"),
                            ],
                        ),
                        timeout=60.0,
                    )
                except asyncio.TimeoutError:
                    console.print("[yellow]LLM timed out — writing structured template.[/yellow]")
                except Exception as _e:
                    console.print(f"[yellow]LLM unavailable ({_e}) — writing structured template.[/yellow]")

                if _init_text:
                    _init_path.write_text(_init_text.strip(), encoding="utf-8")
                else:
                    # ── Structured fallback — dynamic analysis of actual files ──
                    _stamp = _dt.now().strftime("%Y-%m-%d")
                    _run_cmd = _entry_str if _entry_str else f"python -m {_name_str.lower()}"
                    _skip_set = {".git", "__pycache__", "node_modules", ".venv", "venv",
                                 ".mypy_cache", ".ruff_cache", "dist", "build", ".codii",
                                 ".pytest_cache", ".eggs"}
                    _file_types: dict[str, int] = {}
                    for _fp2 in workspace.rglob("*"):
                        if _fp2.is_file() and not any(s in _fp2.parts for s in _skip_set):
                            _e = _fp2.suffix.lower() or "(no ext)"
                            _file_types[_e] = _file_types.get(_e, 0) + 1
                    _total_files = sum(_file_types.values())
                    _top_types = sorted(_file_types.items(), key=lambda x: -x[1])[:4]
                    _type_summary = ", ".join(f"{c} `{e}`" for e, c in _top_types)
                    _has_py = ".py" in _file_types
                    _has_js = ".js" in _file_types or ".ts" in _file_types
                    _has_rs = ".rs" in _file_types
                    _lang = ("Python" if _has_py
                             else "JavaScript/TypeScript" if _has_js
                             else "Rust" if _has_rs
                             else "mixed or unknown type")
                    _overview = (
                        f"{_name_str} is a workspace with {_total_files} file(s) "
                        f"(primarily {_lang}). Dominant file types: {_type_summary}. "
                        "Review the file tree below for structure details."
                    )
                    _init_path.write_text(
                        f"# {_name_str}\n\n"
                        f"> Generated {_stamp} by `/init`. Edit to keep current.\n\n"
                        f"## Overview\n\n{_overview}\n\n"
                        f"## Structure\n\n```\n{_tree_str}\n```\n\n"
                        f"## Tech Stack\n\n"
                        f"{_deps_str if _deps_str else 'See project files for dependencies.'}\n\n"
                        f"## Development Commands\n\n"
                        f"- `{_run_cmd}` — launch\n"
                        f"- `pytest` — run tests (if applicable)\n\n"
                        f"## For Codii (AI Instructions)\n\n"
                        f"- **Chat**: base answers only on indexed source files; say so if unsure.\n"
                        f"- **Edit**: read a file before writing it.\n"
                        f"- **Plan**: produce a numbered step-list before executing.\n",
                        encoding="utf-8",
                    )
                console.print(f"[green]Written: {_init_path.name}[/green]")
                _record_cmd(stripped, f"Generated {_init_path.name}.")
                continue

            if stripped == "/chat":
                _echo_user_cmd(stripped)
                _prev_mode = session.mode
                session.mode = "chat"
                console.print("[dim]Chat mode. Ask anything about the project.[/dim]")
                if _prev_mode in ("edit", "auto"):
                    session.add_message(RequestMessage(role="user", content="[Mode switch: Edit → Chat]"))
                    session.add_message(RequestMessage(role="assistant", content=(
                        "Switching to Chat mode. I'll answer questions without editing files."
                    )))
                _record_cmd(stripped, "Switched to Chat mode.")
                continue

            if stripped == "/index":
                _echo_user_cmd(stripped)
                console.print("[dim]Reading project files…[/dim]")
                _chat_snapshot = await _build_chat_summary()
                session.chat_summary = _chat_snapshot
                session.chat_indexed = True
                _file_count = _chat_snapshot.count("###")
                _snap_tokens = _estimate_tokens(_chat_snapshot)
                console.print(
                    f"[dim]Summarized {_file_count} file(s) "
                    f"(~{max(_snap_tokens // 1000, 1)}k tokens cached).[/dim]"
                )
                if session.mode != "chat":
                    session.mode = "chat"
                    console.print("[dim]Switched to Chat mode.[/dim]")
                _record_cmd(stripped, f"Re-indexed {_file_count} file(s).")
                continue

            transcript.write_event("user_message", {"content": stripped})
            # Submit echo: print mode-colored styled block (Application erases its own area)
            if session.mode == "edit":
                _echo_color = "#e07a30"
                _echo_prefix = "✎ edit"
            elif session.mode == "plan":
                _echo_color = "#4a9eff"
                _echo_prefix = "⏸ plan"
            elif session.mode == "chat":
                _echo_color = "#5fb45a"
                _echo_prefix = "💬 chat"
            else:
                _echo_color = "#888888"
                _echo_prefix = "❯"
            import rich.box as _rich_box
            _echo_text = stripped[:200] + ("…" if len(stripped) > 200 else "")
            console.print(
                Panel(
                    f"[white]{_echo_text}[/white]",
                    border_style=_echo_color,
                    title=f"[bold {_echo_color}]{_echo_prefix}[/bold {_echo_color}]",
                    title_align="left",
                    padding=(0, 1),
                    box=_rich_box.ROUNDED,
                )
            )
            console.print()

            # Mode dispatch
            if session.mode == "plan":
                await _run_plan_mode(stripped)

            elif session.mode == "chat":
                await _run_chat_turn(stripped)

            else:
                # auto or edit
                if session.mode == "edit":
                    scope = _extract_edit_scope(stripped, workspace)
                    if scope:
                        session.edit_scope = scope
                        names = ", ".join(p.name for p in scope)
                        console.print(f"[dim]Edit scope: {names}[/dim]")
                await core.run_turn(stripped)

            # Auto-compact check after each turn
            effective_ctx = fp.capabilities.effective_context_tokens
            if effective_ctx >= 1000 and session.compaction_cooldown <= 0:
                current_tokens = _history_tokens(session.history)
                if current_tokens >= int(effective_ctx * 0.75):
                    console.print("[dim]compacting context...[/dim]")
                    await _compact_context(session, adapter, decision_logger, system_prompt)
            if session.compaction_cooldown > 0:
                session.compaction_cooldown -= 1

    except KeyboardInterrupt:
        console.print("\n[dim]Session ended.[/dim]")
    finally:
        transcript.write_event("session_end", {"reason": "user_quit"})
        transcript.close()
