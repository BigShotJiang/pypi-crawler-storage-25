"""PlanState — simple state machine for plan step tracking."""
from __future__ import annotations

from dataclasses import dataclass


@dataclass
class PlanState:
    steps: list[str]
    current: int = 0

    @property
    def is_complete(self) -> bool:
        return self.current >= len(self.steps)

    def advance(self) -> None:
        if not self.is_complete:
            self.current += 1

    def render(self) -> str:
        total = len(self.steps)
        step_num = min(self.current + 1, total)
        lines = [f"PLAN: Step {step_num} of {total}"]
        for i, step in enumerate(self.steps):
            if i < self.current:
                lines.append(f"  ✓ {i + 1}. {step}")
            elif i == self.current:
                lines.append(f"  ► {i + 1}. {step}  ← DO THIS NOW")
            else:
                lines.append(f"  □ {i + 1}. {step}")
        return "\n".join(lines)
