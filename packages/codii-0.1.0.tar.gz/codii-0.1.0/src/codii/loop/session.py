"""Session state for a single TAOR loop session."""
from __future__ import annotations

import uuid
from pathlib import Path
from typing import TYPE_CHECKING

from codii.connection.base import RequestMessage

if TYPE_CHECKING:
    from codii.loop.plan_state import PlanState

_ACTION_LOG_MAX = 20


class Session:
    def __init__(
        self,
        workspace: Path,
        session_id: str | None = None,
        auto_mode: bool = False,
        is_subagent: bool = False,
    ) -> None:
        self.session_id = session_id or str(uuid.uuid4())
        self.workspace = workspace
        self.turn_count = 0
        self.history: list[RequestMessage] = []
        self.reads_this_session: set[Path] = set()
        self.ledger: str = ""
        self.pending_injections: list[str] = []
        self.auto_mode: bool = auto_mode
        self.is_subagent: bool = is_subagent
        self.compaction_cooldown: int = 0
        self.recent_writes: list[Path] = []
        self.mode: str = "auto"  # "auto" | "plan" | "edit" | "chat"
        self.edit_scope: set[Path] = set()
        self.action_log: list[str] = []
        self.plan_state: "PlanState | None" = None
        # Set to True once chat mode has built a full codebase summary
        self.chat_indexed: bool = False
        # The cached codebase summary built by chat mode — reused by edit/plan modes
        self.chat_summary: str = ""
        # Session-wide file cache: populated by Chat Mode indexing, consumed by Edit/Plan modes
        self.file_cache: dict[str, str] = {}    # rel_path_str -> full file content
        self.cache_preloaded: set[str] = set()  # rel paths already injected into history

    @property
    def session_dir(self) -> Path:
        from codii.config import config_dir
        return config_dir() / "sessions" / self.session_id

    def record_read(self, path: Path) -> None:
        self.reads_this_session.add(path.resolve())

    def add_message(self, msg: RequestMessage) -> None:
        self.history.append(msg)

    def add_injection(self, text: str) -> None:
        """Enqueue an injection message; silently deduplicates identical entries."""
        if text not in self.pending_injections:
            self.pending_injections.append(text)

    def consume_injections(self) -> str | None:
        """Return pending injection text and clear it, or None if empty."""
        if not self.pending_injections:
            return None
        combined = "\n\n".join(self.pending_injections)
        self.pending_injections.clear()
        return combined

    def record_action(self, tool_name: str, arguments: dict, output: str | None = None) -> None:
        """Append a successful tool call to the action log (max 20 entries)."""
        if tool_name == "read_file":
            path = arguments.get("path", "?")
            line_count = (output or "").count("\n") + 1 if output else "?"
            entry = f"[READ] {path} ({line_count} lines)"
        elif tool_name == "write_file":
            entry = f"[CREATED] {arguments.get('path', '?')}"
        elif tool_name == "edit_file":
            entry = f"[EDITED] {arguments.get('path', '?')}"
        elif tool_name == "bash":
            cmd_short = (arguments.get("command") or "")[:60]
            entry = f"[RAN] {cmd_short}"
        elif tool_name == "list_dir":
            entry = f"[LISTED] {arguments.get('path', '.')}"
        else:
            return
        self.action_log.append(entry)
        if len(self.action_log) > _ACTION_LOG_MAX:
            self.action_log = self.action_log[-_ACTION_LOG_MAX:]
