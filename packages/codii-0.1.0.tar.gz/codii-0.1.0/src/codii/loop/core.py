"""AgentCore — the Surgeon execution engine.

Think → Execute → Verify loop. A single class replaces the old
_run_taor_turn / run_all_steps / run_chat_turn trifecta.
"""
from __future__ import annotations

import asyncio
import re
import uuid
from typing import Any, Callable

from codii.connection.base import RequestMessage, ToolCall, ToolDefinition
from codii.decisions.logger import DecisionLogger
from codii.loop.circuit_breaker import CircuitBreaker
from codii.loop.context_injector import ContextInjector
from codii.loop.session import Session
from codii.parser.base import ParsedToolCall
from codii.permissions.model import check_permission
from codii.replay.transcript import TranscriptWriter
from codii.scaffolding.schema import ScaffoldingConfig
from codii.tools.base import PermissionBand, Tool, ToolResult


_MAX_INNER_TURNS = 25
_MAX_CHAT_INNER_TURNS = 5   # Chat: read file(s) once, answer, stop
_REPROMPT_MAX = 2
_CHAT_ALLOWED_TOOLS = frozenset({"read_file", "list_dir"})

_SUBSTANTIVE_TOOLS = frozenset({"write_file", "edit_file", "bash"})

_DONE_PHRASES = (
    "done.",
    "task complete",
    "task is complete",
    "i'm done",
    "i have completed",
    "finished.",
    "completed.",
    "all done",
)

_ASKS_FOR_FILE_RE = re.compile(
    r"(please|can you|could you|would you).{0,80}(provide|share|give|send|show|paste).{0,80}"
    r"(content|file|code|source|the .{0,20}file)"
    r"|i.{0,20}need.{0,60}(content|the file|source|code)"
    r"|provide.{0,40}(content|file|code)",
    re.IGNORECASE | re.DOTALL,
)

# Detects substantial code blocks (>100 chars of content) — model wrote code as text
_CODE_AS_TEXT_RE = re.compile(r"```[a-zA-Z]*\n.{100,}", re.DOTALL)


def _safe(s: str) -> str:
    """Strip surrogate code points so Rich never raises UnicodeEncodeError."""
    return s.encode("utf-8", errors="replace").decode("utf-8")


def _session_rel(path: Path, workspace: Path) -> str | None:
    """Return path as a string relative to workspace (resolved), or None if outside."""
    try:
        return str(path.relative_to(workspace.resolve()))
    except ValueError:
        return None


class AgentCore:
    """Surgical Think → Execute → Verify execution engine."""

    def __init__(
        self,
        adapter: Any,
        session: Session,
        scaffolding: ScaffoldingConfig,
        tool_map: dict[str, Tool],
        tool_defs: list[ToolDefinition] | None,
        parser: Any,
        decision_logger: DecisionLogger,
        transcript: TranscriptWriter,
        console: Any,
        confirm_fn: Callable,
        collect_response_fn: Callable,
        adapt_scaffolding_fn: Callable,
        run_subagent_fn: Callable | None = None,
        fp: Any = None,
    ) -> None:
        self._adapter = adapter
        self._session = session
        self._scaffolding = scaffolding
        self._tool_map = tool_map
        self._tool_defs = tool_defs
        self._parser = parser
        self._decision_logger = decision_logger
        self._transcript = transcript
        self._console = console
        self._confirm_fn = confirm_fn
        self._collect_response_fn = collect_response_fn
        self._adapt_scaffolding_fn = adapt_scaffolding_fn
        self._run_subagent_fn = run_subagent_fn
        self._fp = fp
        self._circuit_breaker = CircuitBreaker()
        self._context_injector = ContextInjector(
            tier=scaffolding.tier,
            tool_map=tool_map,
            session=session,
        )
        # Build full tool defs directly from tool_map — always, regardless of scaffolding tier.
        # This guarantees non-chat turns always have native tool definitions even if runner.py
        # passes tool_defs=None (which it does for Tier 2/3 prompt-engineered scaffolding).
        # If the backend ignores native defs, no harm done; if it uses them, the agent can edit.
        self._full_tool_defs: list[ToolDefinition] = [t.definition() for t in tool_map.values()]
        # Tier adaptation — local to core, not stored in session
        self._consecutive_clean = 0
        self._consecutive_malformed = 0
        self._tier_promoted = False
        # Tracks whether a write/edit/bash succeeded in the current inner turn
        self._had_substantive_success: bool = False
        # WorkflowLock: set to path after a successful read; cleared after successful edit/write
        self._workflow_lock_path: str | None = None

    def update_scaffolding(
        self,
        scaffolding: ScaffoldingConfig,
        tool_map: dict[str, Tool],
        tool_defs: list[ToolDefinition] | None,
        parser: Any,
    ) -> None:
        """Hot-swap scaffolding after tier adaptation."""
        self._scaffolding = scaffolding
        self._tool_map = tool_map
        self._tool_defs = tool_defs
        self._parser = parser
        # Rebuild full_tool_defs from the new tool_map — demotion may add/remove tools.
        self._full_tool_defs = [t.definition() for t in tool_map.values()]
        self._context_injector.update_tier(scaffolding.tier)
        self._context_injector.update_tools(tool_map)

    async def run_turn(
        self,
        prompt: str,
        mode: str | None = None,
        auto_approve: bool = False,
        system_override: str | None = None,
    ) -> None:
        """Execute one full agent turn.

        Args:
            prompt: The user's task for this turn.
            mode: Override the session's current mode ("chat", "edit", "auto").
            auto_approve: When True, skip per-call confirmation prompts.
                          _run_plan_mode sets this because the user already approved
                          the plan.
            system_override: Use this string as the system prompt instead of the
                             built-in one. Chat mode passes its own system here.
        """
        effective_mode = mode or self._session.mode
        effective_auto = auto_approve or self._session.auto_mode
        self._workflow_lock_path = None  # reset WorkflowLock for each new outer turn

        if effective_mode == "chat":
            if self._session.chat_indexed:
                # Summary already built — answer from context, no tools needed
                active_tools = {}
                active_defs = None
            else:
                active_tools = {k: v for k, v in self._tool_map.items() if k in _CHAT_ALLOWED_TOOLS}
                active_defs = [d for d in self._full_tool_defs if d.name in _CHAT_ALLOWED_TOOLS] or None
        else:
            active_tools = self._tool_map
            # _full_tool_defs is built from tool_map in __init__/__update_scaffolding and is
            # NEVER None — this is the canonical source of truth for non-chat tool availability.
            active_defs = self._full_tool_defs or self._tool_defs
            if active_defs and len(active_defs) < 3:
                self._decision_logger.log("tool_warning", {
                    "mode": effective_mode,
                    "active_defs_count": len(active_defs),
                    "note": "Suspiciously few tool defs for a non-chat mode",
                })

        self._session.add_message(RequestMessage(role="user", content=prompt))
        self._session.turn_count += 1

        # Cache pre-load: for each cached file in edit_scope, inject its content into history
        # once so the model can call edit_file directly without a redundant read.
        if effective_mode != "chat" and self._session.edit_scope and self._session.file_cache:
            _newly_preloaded: list[str] = []
            for _scope_path in self._session.edit_scope:
                _rel = _session_rel(_scope_path, self._session.workspace)
                if not _rel or _rel not in self._session.file_cache:
                    continue
                if _rel in self._session.cache_preloaded:
                    continue
                _cached_content = self._session.file_cache[_rel]
                self._session.add_message(RequestMessage(
                    role="user",
                    content=(
                        f"[WORKSPACE INDEX] '{_rel}' was previously indexed and is pre-loaded.\n"
                        f"Full content:\n{_cached_content}\n"
                        "Do NOT call read_file. Call edit_file directly."
                    ),
                ))
                self._session.reads_this_session.add(_scope_path.resolve())
                self._session.record_action("read_file", {"path": _rel}, _cached_content)
                self._session.cache_preloaded.add(_rel)
                _newly_preloaded.append(_rel)
            # Pre-arm WorkflowLock when exactly one target was freshly pre-loaded
            if len(_newly_preloaded) == 1:
                self._workflow_lock_path = _newly_preloaded[0]

        reprompt_count = 0
        _code_as_text_count = 0
        _text_only_count = 0
        turn_had_malformed = False
        max_turns = _MAX_CHAT_INNER_TURNS if effective_mode == "chat" else _MAX_INNER_TURNS
        # Loop-break guard: detect same read-only tool on same file N times in a row
        _prev_call_sig: tuple[str, str] | None = None
        _repeat_count: int = 0
        # Per-turn read counter: detect non-consecutive re-reads of the same file
        _turn_read_counts: dict[str, int] = {}

        for _inner_turn in range(max_turns):
            self._had_substantive_success = False
            system = system_override or self._build_system_prompt()
            messages = [RequestMessage(role="system", content=system)]
            injection = self._session.consume_injections()
            messages.extend(self._session.history)
            if injection:
                messages.append(RequestMessage(role="user", content=injection))
            # Ground the model before every non-chat call with the Dynamic Context Block
            if effective_mode != "chat":
                messages.append(RequestMessage(
                    role="user", content=self._context_injector.build()
                ))

            try:
                text, raw_tool_calls = await self._stream_response(messages, active_defs)
            except asyncio.CancelledError:
                self._console.print("[red]Stream interrupted — connection lost. You can retry.[/red]")
                break
            except Exception as e:
                self._console.print(f"[red]Connection error: {e}[/red]")
                break

            self._transcript.write_event("response_complete", {
                "text": text[:2000],
                "tool_call_count": len(raw_tool_calls),
            })

            # Indexed chat: model answers from cached summary — no tools exist.
            # Skip ALL parsing to prevent the "unknown tool" injection loop.
            if effective_mode == "chat" and self._session.chat_indexed:
                self._session.add_message(RequestMessage(role="assistant", content=text))
                break

            parsed_calls, repair_failed = self._parse_calls(text, raw_tool_calls, active_defs)

            if repair_failed:
                turn_had_malformed = True

            if not parsed_calls:
                # Edit/auto mode + no repair failure: discard text, inject directive, re-loop.
                # DO NOT add text to history — next iteration re-sends same context + injection.
                if effective_mode != "chat" and not repair_failed:
                    _text_only_count += 1
                    if _text_only_count >= 3:
                        self._console.print(
                            "[red]Model produced text instead of a tool call "
                            f"after {_text_only_count} attempts — aborting turn.[/red]"
                        )
                        break

                    if _CODE_AS_TEXT_RE.search(text):
                        _code_as_text_count += 1
                        if _code_as_text_count >= 2:
                            self._build_bridge_injection(text)
                            if not self._session.pending_injections:
                                self._session.add_injection(
                                    "[SYSTEM: You are in EDIT MODE. "
                                    "You MUST respond with a tool call. Text answers are forbidden. "
                                    "Call a tool immediately.]"
                                )
                        else:
                            self._session.add_injection(
                                "[SYSTEM: Do not write code as plain text. "
                                "Use edit_file(path, old_str='[exact lines to replace]', "
                                "new_str='[replacement]') to apply your changes directly. "
                                "No text output allowed.]"
                            )
                    else:
                        self._session.add_injection(
                            "[SYSTEM: You are in EDIT MODE. "
                            "You MUST respond with a tool call. Text answers are forbidden. "
                            "Call a tool immediately.]"
                        )
                    continue  # Re-loop. No history pollution.

                # Chat mode or repair_failed: existing logic unchanged.
                outcome = self._handle_no_calls(
                    text, repair_failed, reprompt_count, effective_mode, active_tools
                )
                if outcome == "continue":
                    reprompt_count += 1
                    continue
                # "done"
                self._session.add_message(RequestMessage(role="assistant", content=text))
                break

            self._session.add_message(RequestMessage(role="assistant", content=text))
            tool_results = await self._execute_all_calls(
                parsed_calls, active_tools, effective_auto, effective_mode
            )
            self._session.add_message(RequestMessage(
                role="tool",
                content="\n\n---\n\n".join(tool_results),
            ))

            # Auto-complete: edit followed by successful bash with no pending work → done.
            if self._had_substantive_success and (
                self._session.plan_state is None or self._session.plan_state.is_complete
            ) and not self._session.pending_injections:
                _log = self._session.action_log
                _last_ran = _log and _log[-1].startswith("[RAN]")
                _had_edit = any(
                    e.startswith("[EDITED]") or e.startswith("[CREATED]")
                    for e in _log[-6:]
                )
                if _last_ran and _had_edit:
                    self._console.print("[dim]✓ Edit verified — task complete.[/dim]")
                    break

            # Per-turn read counter: inject a hard warning when the same file is read
            # more than once in a single turn (catches non-consecutive re-read loops).
            for _call in parsed_calls:
                if _call.name == "read_file" and (_rpath := _call.arguments.get("path")):
                    _turn_read_counts[_rpath] = _turn_read_counts.get(_rpath, 0) + 1
                    if _turn_read_counts[_rpath] >= 2:
                        self._session.add_injection(
                            f"STOP: '{_rpath}' has been read {_turn_read_counts[_rpath]}× "
                            "this turn. Do NOT read it again. Proceed to your next action now."
                        )

            # Consecutive-call guard: if the model calls the same read-only tool on
            # the same file twice in a row it is stuck — stop immediately.
            if len(parsed_calls) == 1 and parsed_calls[0].name in _CHAT_ALLOWED_TOOLS:
                sig = (parsed_calls[0].name, parsed_calls[0].arguments.get("path", ""))
                if sig == _prev_call_sig and sig[1]:
                    _repeat_count += 1
                    if _repeat_count >= 1:
                        self._console.print(
                            f"[yellow]Loop detected: {sig[0]}('{sig[1]}') called "
                            "twice in a row — stopping.[/yellow]"
                        )
                        break
                else:
                    _repeat_count = 0
                    _prev_call_sig = sig
            else:
                _repeat_count = 0
                _prev_call_sig = None

            if self._is_done(text):
                # Advance plan step only when the model declares done AND substantive
                # work happened this turn (write/edit/bash). Pure narration does not
                # count — the model must have actually done something.
                if self._had_substantive_success and self._session.plan_state:
                    self._session.plan_state.advance()
                if self._session.auto_mode:
                    await self._auto_verify(active_tools)
                break

        else:
            self._console.print("[yellow]Max inner turns reached — stopping this turn.[/yellow]")

        self._adapt_tier(turn_had_malformed)

    # ── Internal helpers ──────────────────────────────────────────────────────

    def _build_system_prompt(self) -> str:
        parts = []
        if self._session.mode != "chat":
            parts.append("[EXECUTE MODE ACTIVE — TEXT OUTPUT FORBIDDEN. USE TOOLS NOW]\n\n")
        parts.append(self._scaffolding.system_prompt_template)
        # Prefer chat summary (richer codebase context) over basic ledger
        context = self._session.chat_summary or self._session.ledger
        if context:
            parts.append(f"\n\n## Project context\n{context}")
        if self._session.action_log:
            log = "\n".join(f"- {e}" for e in self._session.action_log)
            parts.append(f"\n\n## Already done this session\n{log}")
        if self._session.chat_indexed and self._session.mode != "chat":
            parts.append(
                "\n\n## Context Inheritance — ACTIVE\n"
                "Chat mode already indexed this project. The summary above shows each file's purpose.\n\n"
                "EDITING WORKFLOW — follow this exactly:\n"
                "1. call read_file(target_file) — get the EXACT current content\n"
                "2. call edit_file(target_file, old_str='[exact lines]', new_str='[new lines]')\n\n"
                "Do NOT read files for exploration — the summary covers that. "
                "Only read the specific file you are about to edit."
            )
        return "".join(parts)

    def _is_done(self, text: str) -> bool:
        lower = text.lower().strip()
        return any(phrase in lower for phrase in _DONE_PHRASES)

    async def _stream_response(
        self,
        messages: list[RequestMessage],
        active_defs: list[ToolDefinition] | None,
    ) -> tuple[str, list[ToolCall]]:
        """Stream response with live display. Returns (text, raw_tool_calls)."""
        from rich.live import Live
        from rich.spinner import Spinner

        think_delim = None
        if self._fp is not None:
            rs = getattr(self._fp.capabilities, "reasoning_support", None)
            if rs is not None:
                think_delim = getattr(rs, "delimiter", None)

        streamed_text: list[str] = []
        status_text = ["thinking..."]

        with Live(
            Spinner("dots", text="thinking…", style="dim"),
            console=self._console,
            refresh_per_second=16,
        ) as live:
            text, raw_calls = await self._collect_response_fn(
                self._adapter,
                messages,
                active_defs,
                status_text,
                streamed_text=streamed_text,
                live=live,
                think_delimiter=think_delim,
            )

        return text, raw_calls

    def _parse_calls(
        self,
        text: str,
        raw_tool_calls: list[ToolCall],
        active_defs: list[ToolDefinition] | None,
    ) -> tuple[list[ParsedToolCall], bool]:
        """Parse model output into tool calls. Returns (calls, repair_failed)."""
        repair_failed = False
        parsed_calls: list[ParsedToolCall] = []

        if raw_tool_calls:
            for tc in raw_tool_calls:
                parsed_calls.append(ParsedToolCall(
                    id=tc.id or str(uuid.uuid4()),
                    name=tc.name,
                    arguments=tc.arguments,
                ))
            self._decision_logger.log("parser_dispatch", {"method": "native", "count": len(parsed_calls)})
        else:
            raw_parsed = self._parser.parse(text, active_defs or [])
            repair_failed = any(c.name == "__repair_failed__" for c in raw_parsed)
            parsed_calls = [c for c in raw_parsed if c.name != "__repair_failed__"]

            # Deduplicate identical calls
            seen: set[tuple[str, frozenset]] = set()
            deduped: list[ParsedToolCall] = []
            for c in parsed_calls:
                key = (c.name, frozenset(
                    (k, v) for k, v in c.arguments.items()
                    if isinstance(v, (str, int, float, bool))
                ))
                if key not in seen:
                    seen.add(key)
                    deduped.append(c)
            parsed_calls = deduped

            if parsed_calls:
                self._decision_logger.log("parser_dispatch", {
                    "method": "text_parse",
                    "parser": self._scaffolding.parser_key,
                    "count": len(parsed_calls),
                })
            elif repair_failed:
                self._decision_logger.log("repair", {
                    "type": "all_strategies_failed",
                    "parser": self._scaffolding.parser_key,
                    "snippet": text[:120],
                })

        return parsed_calls, repair_failed

    def _handle_no_calls(
        self,
        text: str,
        repair_failed: bool,
        reprompt_count: int,
        mode: str,
        active_tools: dict[str, Tool],
    ) -> str:  # "continue" | "done"
        # Chat mode: a text-only response IS the final answer.
        # Check this first — chat never needs tool calls.
        if mode == "chat" and text.strip() and not repair_failed:
            return "done"

        # Code-as-text: NEVER accept as done, regardless of reprompt_count.
        # The caller (run_turn) tracks _code_as_text_count with its own hard cap.
        if _CODE_AS_TEXT_RE.search(text) and mode != "chat":
            last_read_path: str | None = None
            for entry in reversed(self._session.action_log):
                if entry.startswith("[READ] "):
                    last_read_path = entry.split("[READ] ")[1].split(" (")[0]
                    break

            available = ", ".join(sorted(active_tools.keys()))
            if last_read_path:
                correction = (
                    f"ERROR: Code block detected — FORBIDDEN.\n"
                    f"You just read '{last_read_path}'. "
                    f"Call edit_file('{last_read_path}', "
                    f"old_str='[exact text to change]', new_str='[new text]') NOW.\n"
                    "Do NOT output any text. Call the tool immediately."
                )
            else:
                correction = (
                    "ERROR: Code block detected — FORBIDDEN.\n"
                    "Call read_file(target_file) then "
                    "edit_file(target_file, old_str='[text to replace]', new_str='[new text]') "
                    "or write_file(path, content='...') for new files.\n"
                    f"Available tools: {available}"
                )
            self._session.add_message(RequestMessage(role="assistant", content=text))
            self._session.add_message(RequestMessage(role="user", content=correction))
            return "continue"

        if self._is_done(text) and not repair_failed:
            return "done"
        if reprompt_count >= _REPROMPT_MAX:
            return "done"

        self._session.add_message(RequestMessage(role="assistant", content=text))

        if _ASKS_FOR_FILE_RE.search(text):
            available = ", ".join(sorted(active_tools.keys()))
            self._session.add_message(RequestMessage(role="user", content=(
                "You have a read_file tool. NEVER ask the user to provide file contents. "
                f"Call read_file now. Available tools: {available}"
            )))
            return "continue"

        if repair_failed:
            hint = self._format_tool_hint()
            self._decision_logger.log("repair", {
                "type": "reprompt",
                "reprompt": reprompt_count + 1,
            })
            self._session.add_message(RequestMessage(role="user", content=hint))
            return "continue"

        available = ", ".join(sorted(active_tools.keys()))
        self._session.add_message(RequestMessage(role="user", content=(
            "AGENT ERROR: You produced text without calling a tool. "
            "Do not narrate or explain. Call a tool immediately. "
            f"Available tools: {available}"
        )))
        return "continue"

    def _build_bridge_injection(self, text: str) -> None:
        """Weak Model Bridge: extract code-as-text and inject a precision edit_file directive."""
        code_pattern = re.compile(r"```[a-zA-Z]*\n(.*?)(?:```|$)", re.DOTALL)
        matches = list(code_pattern.finditer(text))
        if not matches:
            return
        extracted_code = max(matches, key=lambda m: len(m.group(1))).group(1).rstrip()
        if len(extracted_code) < 20:
            return

        target_file: str | None = self._workflow_lock_path
        if not target_file:
            for entry in reversed(self._session.action_log):
                if entry.startswith("[READ] "):
                    target_file = entry.split("[READ] ")[1].split(" (")[0]
                    break
        if not target_file and self._session.edit_scope:
            first = next(iter(self._session.edit_scope))
            try:
                target_file = str(first.relative_to(self._session.workspace))
            except ValueError:
                target_file = str(first)
        if not target_file:
            return

        file_hint = ""
        try:
            target_path = (self._session.workspace / target_file).resolve()
            cache_key = str(target_path.relative_to(self._session.workspace.resolve()))
            raw = (
                self._session.file_cache.get(cache_key)
                or target_path.read_text(encoding="utf-8", errors="replace")
            )
            snippet = "\n".join(raw.splitlines()[:40])
            file_hint = (
                f"\n\nCurrent file content (first 40 lines of {target_file} for old_str reference):\n"
                f"```\n{snippet}\n```"
            )
        except Exception:
            pass

        self._console.print(
            "  [cyan]⟳ Bridge:[/cyan] [dim]extracted code from text, constructing edit_file call[/dim]"
        )
        self._session.add_injection(
            f"[BRIDGE] Your code is correct. Apply it now with edit_file.\n\n"
            f"Target file: {target_file}\n\n"
            f"Your new_str (copy this exactly):\n"
            f"```\n{extracted_code}\n```"
            f"{file_hint}\n\n"
            f"Call EXACTLY:\n"
            f'edit_file("{target_file}", '
            f'old_str="[copy the exact lines you are replacing from the file above]", '
            f'new_str="[the code above]")\n\n'
            "Do NOT output any text. Call edit_file NOW with old_str and new_str."
        )

    def _format_tool_hint(self) -> str:
        available = ", ".join(sorted(self._tool_map.keys()))
        if self._scaffolding.tier == 3:
            return (
                "Your tool call could not be parsed. Use this EXACT JSON format:\n"
                '{"name": "read_file", "arguments": {"path": "src/main.py"}}\n'
                f"Available tools: {available}"
            )
        return (
            "Your tool call could not be parsed. Use this EXACT XML format:\n"
            '<tool name="read_file">\n'
            '<parameter name="path">src/main.py</parameter>\n'
            '</tool>\n'
            f"Available tools: {available}"
        )

    def _check_premature_action(self, call: ParsedToolCall) -> str | None:
        """Guard: writing/editing a file that hasn't been read this session."""
        if call.name not in ("write_file", "edit_file"):
            return None
        path_arg = call.arguments.get("path")
        if not path_arg:
            return None
        target = (self._session.workspace / path_arg).resolve()
        if target in self._session.reads_this_session:
            return None
        # Allow write_file for new files (they don't exist yet)
        if call.name == "write_file" and not target.exists():
            return None
        return (
            f"You must read '{path_arg}' before editing it. "
            f"Call read_file('{path_arg}') first, then resubmit."
        )

    def _check_workflow_lock(self, call: ParsedToolCall) -> str | None:
        """After a read, force the very next call to edit/write that same file."""
        if self._workflow_lock_path is None:
            return None
        locked = self._workflow_lock_path
        if call.name in ("edit_file", "write_file") and call.arguments.get("path") == locked:
            return None  # Correct sequence.
        return (
            f"WORKFLOW LOCK: You must call edit_file('{locked}') next — you just read it. "
            f"Do not call {call.name} before editing '{locked}'."
        )

    def _check_write_over_existing(self, call: ParsedToolCall) -> str | None:
        """Guard: write_file on an existing file must use edit_file instead."""
        if call.name != "write_file":
            return None
        path_arg = call.arguments.get("path")
        if not path_arg:
            return None
        target = (self._session.workspace / path_arg).resolve()
        if not target.exists():
            return None  # New file — write_file is correct
        return (
            f"WRONG TOOL: '{path_arg}' already exists. "
            "write_file would erase all existing content. "
            "Use edit_file with old_str/new_str to make surgical changes. "
            f"Re-read '{path_arg}' to confirm the current content, then call edit_file."
        )

    async def _execute_all_calls(
        self,
        calls: list[ParsedToolCall],
        active_tools: dict[str, Tool],
        auto_approve: bool,
        mode: str,
    ) -> list[str]:
        results: list[str] = []

        for call in calls:
            # Guard: unknown tool
            if call.name not in active_tools:
                available = ", ".join(sorted(active_tools.keys()))
                self._session.add_injection(
                    f"Tool '{call.name}' does not exist. "
                    f"Available tools: {available}. Use one of these exact names."
                )
                results.append(f"Tool: {call.name}\nResult: ERROR\nUnknown tool: {call.name!r}")
                continue

            # Guard: subagent recursion
            if call.name == "spawn_subagent" and self._session.is_subagent:
                results.append(f"Tool: {call.name}\nResult: ERROR\nSubagents cannot spawn other subagents.")
                continue

            # Guard: circuit breaker
            if self._circuit_breaker.is_open(call.name, call.arguments):
                # Deadlock prevention: if the CB fires on the locked path's edit, clear the lock.
                if (
                    self._workflow_lock_path is not None
                    and call.name in ("edit_file", "write_file")
                    and call.arguments.get("path") == self._workflow_lock_path
                ):
                    self._workflow_lock_path = None
                injection = (
                    f"The approach of calling {call.name} with similar arguments has "
                    "failed three times. Please try a completely different approach."
                )
                self._session.add_injection(injection)
                self._decision_logger.log("circuit_break", {
                    "tool": call.name,
                    "count": self._circuit_breaker.failure_count(call.name, call.arguments),
                })
                results.append(f"Tool: {call.name}\nResult: ERROR\n{injection}")
                continue

            # Guard: WorkflowLock — after a read, next call must edit that file
            lock_err = self._check_workflow_lock(call)
            if lock_err:
                self._session.add_injection(lock_err)
                self._decision_logger.log("intervention", {"archetype": "workflow_lock", "tool": call.name})
                results.append(f"Tool: {call.name}\nResult: ERROR\n{lock_err}")
                continue

            # Guard: read-before-write
            premature_err = self._check_premature_action(call)
            if premature_err:
                self._session.add_injection(premature_err)
                self._decision_logger.log("intervention", {"archetype": 1, "tool": call.name})
                results.append(f"Tool: {call.name}\nResult: ERROR\n{premature_err}")
                continue

            # Guard: edit-first (write_file on existing file → must use edit_file)
            write_over_err = self._check_write_over_existing(call)
            if write_over_err:
                self._session.add_injection(write_over_err)
                self._decision_logger.log("intervention", {"archetype": "edit_first", "tool": call.name})
                results.append(f"Tool: {call.name}\nResult: ERROR\n{write_over_err}")
                continue

            # Permission check
            path_arg = call.arguments.get("path")
            path = (self._session.workspace / path_arg).resolve() if path_arg else None
            band, auto_approved = check_permission(call.name, path, self._session.workspace)

            if band == PermissionBand.FORBIDDEN:
                self._decision_logger.log("permission", {"tool": call.name, "band": "forbidden", "path": str(path)})
                if path is not None:
                    try:
                        path.relative_to(self._session.workspace.resolve())
                        err = f"Access to '{path_arg}' is forbidden (sensitive path)."
                    except ValueError:
                        err = (
                            f"Path '{path_arg}' is outside the workspace ({self._session.workspace}). "
                            "Codii can only access files within the directory where it was launched."
                        )
                else:
                    err = f"Operation forbidden: {call.name}"
                results.append(f"Tool: {call.name}\nResult: ERROR\n{err}")
                continue

            if band == PermissionBand.CONFIRMATION and not auto_approved and not auto_approve:
                self._decision_logger.log("permission", {
                    "tool": call.name, "band": "confirmation", "path": str(path),
                })
                if self._session.auto_mode:
                    self._console.print(f"  [dim][auto] {call.name}({path_arg or ''}) → allowed[/dim]")
                else:
                    try:
                        allowed = await self._confirm_fn(call.name, path_arg or "")
                        if not allowed:
                            results.append(f"Tool: {call.name}\nResult: ERROR\nUser denied permission.")
                            continue
                    except (KeyboardInterrupt, EOFError):
                        results.append(f"Tool: {call.name}\nResult: ERROR\nUser denied permission.")
                        continue

            # Edit scope discipline (edit mode only, skipped when auto_approve)
            if (
                mode == "edit"
                and self._session.edit_scope
                and call.name in ("write_file", "edit_file")
                and path is not None
                and path.resolve() not in {p.resolve() for p in self._session.edit_scope}
                and not auto_approve
            ):
                names = ", ".join(p.name for p in self._session.edit_scope)
                self._console.print(f"\n  [yellow]⚠[/yellow] {path_arg} is outside edit scope ({names})")
                try:
                    allowed = await self._confirm_fn("out-of-scope write", path_arg or "")
                    if not allowed:
                        results.append(f"Tool: {call.name}\nResult: ERROR\nOut-of-scope write rejected.")
                        continue
                except (KeyboardInterrupt, EOFError):
                    results.append(f"Tool: {call.name}\nResult: ERROR\nOut-of-scope write rejected.")
                    continue

            # Cache intercept: serve read_file from session.file_cache (no disk I/O)
            if call.name == "read_file" and path_arg and self._session.file_cache:
                try:
                    _res = (self._session.workspace / path_arg).resolve()
                    _ckey = str(_res.relative_to(self._session.workspace.resolve()))
                except ValueError:
                    _ckey = None
                if _ckey and _ckey in self._session.file_cache:
                    _cached = self._session.file_cache[_ckey]
                    self._session.record_read(_res)
                    self._session.record_action("read_file", call.arguments, _cached)
                    self._workflow_lock_path = path_arg
                    self._circuit_breaker.record_success(call.name, call.arguments)
                    self._console.print(f"  [green]✓[/green] [dim][cache] {path_arg}[/dim]")
                    results.append(f"Tool: {call.name}\nResult: OK\n{_cached}")
                    continue

            # Track reads (for read-before-write guard on future calls)
            if call.name == "read_file" and path_arg:
                self._session.record_read((self._session.workspace / path_arg).resolve())

            # Display
            _short = path_arg or (
                call.arguments.get("command", "")[:40] if "command" in call.arguments else ""
            )
            _display = f"{call.name}({_short})" if _short else call.name
            self._console.print(f"  [dim]→ {_display}[/dim]")

            self._transcript.write_event("tool_call", {
                "name": call.name,
                "arguments": call.arguments,
                "call_id": call.id,
            })

            # Execute
            if call.name == "spawn_subagent" and self._run_subagent_fn is not None:
                result = await self._run_subagent_fn(
                    agent_name=call.arguments.get("agent", ""),
                    task=call.arguments.get("task", ""),
                )
            else:
                result = await active_tools[call.name].execute(
                    call.arguments, self._session.workspace
                )

            self._transcript.write_event("tool_result", {
                "call_id": call.id,
                "success": result.success,
                "output": (result.output or "")[:500],
                "error": result.error,
            })

            if result.success:
                self._circuit_breaker.record_success(call.name, call.arguments)
                # WorkflowLock transitions: arm on read, disarm on successful edit/write
                if call.name == "read_file" and path_arg:
                    self._workflow_lock_path = path_arg
                elif call.name in ("edit_file", "write_file") and path_arg == self._workflow_lock_path:
                    self._workflow_lock_path = None
                _res = {
                    "write_file": f"Written: {path_arg}",
                    "read_file": f"Read: {path_arg} ({(result.output or '').count(chr(10)) + 1} lines)",
                    "list_dir": f"Listed: {path_arg} ({len((result.output or '').splitlines())} entries)",
                    "bash": "Exit 0",
                }.get(call.name, (result.output or "").strip()[:50].replace("\n", " "))
                self._console.print(f"  [green]✓[/green] [dim]{_res}[/dim]")
                if call.name == "write_file" and path_arg:
                    resolved_p = (self._session.workspace / path_arg).resolve()
                    self._session.record_read(resolved_p)
                    self._session.recent_writes.append(resolved_p)
                self._session.record_action(call.name, call.arguments, result.output)
                if call.name in _SUBSTANTIVE_TOOLS:
                    self._had_substantive_success = True
            else:
                count = self._circuit_breaker.record_failure(call.name, call.arguments)
                self._decision_logger.log(
                    "timeout" if "timed out" in (result.error or "") else "tool_surface",
                    {"tool": call.name, "error": result.error, "fail_count": count},
                )
                err_preview = (result.error or "")[:60]
                self._console.print(f"  [red]✗[/red] [dim]{err_preview}[/dim]")
                self._inject_failure_guidance(call, result)

            results.append(
                f"Tool: {call.name}\nResult: {'OK' if result.success else 'ERROR'}\n"
                f"{result.output or result.error or ''}"
            )

        return results

    def _inject_failure_guidance(self, call: ParsedToolCall, result: ToolResult) -> None:
        if call.name == "edit_file":
            failed_path = call.arguments.get("path", "?")
            target = (self._session.workspace / failed_path).resolve()
            try:
                current_content = target.read_text(encoding="utf-8", errors="replace")
                # Mark as freshly read so the retry edit_file passes _check_premature_action
                self._session.record_read(target)
                lines = current_content.splitlines()
                line_count = len(lines)
                shown = _safe(
                    current_content if line_count <= 100
                    else "\n".join(lines[:100]) + f"\n... ({line_count - 100} more lines) ..."
                )
                self._session.add_injection(
                    f"EDIT FAILED for '{failed_path}'.\n"
                    f"Error: {result.error}\n\n"
                    f"The file has {line_count} line(s). EXACT current content:\n"
                    f"```\n{shown}\n```\n\n"
                    "On your NEXT call, use old_str/new_str instead of a diff:\n"
                    f'edit_file("{failed_path}", '
                    'old_str="[exact text from the file above]", '
                    'new_str="[what to replace it with]")'
                )
            except OSError:
                self._session.add_injection(
                    f"EDIT FAILED for '{failed_path}': {result.error or 'unknown error'}. "
                    f"Call read_file('{failed_path}') then resubmit edit_file with a corrected diff."
                )
        elif call.name == "bash" and "appears to be an interactive program" in (result.error or ""):
            self._session.add_injection(
                "The program is interactive and cannot be run automatically. "
                "Verify it was created correctly by reading the file instead."
            )
        elif call.name not in ("bash",):
            self._session.add_injection(
                f"The {call.name} call failed: {result.error or 'unknown error'}. "
                "Use a different tool or different arguments immediately."
            )

    async def _auto_verify(self, active_tools: dict[str, Tool]) -> None:
        """Auto mode: verify written files exist and Python files are syntax-clean."""
        bash = active_tools.get("bash")
        if not bash:
            return
        for p in self._session.recent_writes[-5:]:
            if not p.exists():
                msg = f"Verification failed: {p} was not created."
                self._console.print(f"  [yellow]⚠[/yellow] {msg}")
                self._session.add_injection(f"Task declared complete but {msg} Please fix.")
                self._decision_logger.log("intervention", {
                    "archetype": "auto_verify", "path": str(p), "error": "file_missing",
                })
                return
            if p.suffix == ".py":
                from codii.parser.base import ParsedToolCall as _PTC
                dummy = _PTC(id="verify", name="bash", arguments={"command": f"python -m py_compile {p}"})
                vresult = await bash.execute(dummy.arguments, self._session.workspace)
                if not vresult.success:
                    msg = f"Syntax error in {p.name}: {vresult.error}"
                    self._console.print(f"  [yellow]⚠[/yellow] {msg}")
                    self._session.add_injection(
                        f"Task declared complete but verification failed: {msg}. Please fix."
                    )
                    self._decision_logger.log("intervention", {
                        "archetype": "auto_verify", "path": str(p), "error": vresult.error,
                    })
                    return

    def _adapt_tier(self, turn_had_malformed: bool) -> None:
        if turn_had_malformed:
            self._consecutive_clean = 0
            self._consecutive_malformed += 1
            if self._consecutive_malformed >= 3 and self._scaffolding.tier < 3:
                old_tier = self._scaffolding.tier
                self._adapt_scaffolding_fn(self._scaffolding.tier + 1)
                self._consecutive_malformed = 0
                self._decision_logger.log("demote", {"from": old_tier, "to": self._scaffolding.tier})
                self._console.print(
                    f"[dim]Scaffolding demoted to tier {self._scaffolding.tier} "
                    "after repeated parse failures.[/dim]"
                )
        else:
            self._consecutive_malformed = 0
            self._consecutive_clean += 1
            if (
                self._consecutive_clean >= 20
                and not self._tier_promoted
                and self._scaffolding.tier > 1
            ):
                old_tier = self._scaffolding.tier
                self._adapt_scaffolding_fn(self._scaffolding.tier - 1)
                self._consecutive_clean = 0
                self._tier_promoted = True
                self._decision_logger.log("promote", {"from": old_tier, "to": self._scaffolding.tier})
                self._console.print(
                    f"[dim]Scaffolding promoted to tier {self._scaffolding.tier} "
                    "after sustained clean calls.[/dim]"
                )
