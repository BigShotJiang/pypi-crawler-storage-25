"""ContextInjector — builds the Dynamic Context Block (DCB) for every inner LLM call.

The DCB is injected as a user-role message (NOT system prompt, NOT stored in history)
before each LLM call in non-chat mode. It grounds the model with identity, available
tools, session log, and current plan state — impossible to ignore, impossible to forget.
"""
from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from codii.loop.session import Session
    from codii.tools.base import Tool

_DIV = "━" * 42


_TIER_FORMAT: dict[int, str] = {
    1: "",  # native tool calling — no format reminder needed
    2: '<tool name="read_file"><parameter name="path">file.py</parameter></tool>',
    3: '{"name": "read_file", "arguments": {"path": "file.py"}}',
}


class ContextInjector:
    """Builds a fresh Dynamic Context Block (DCB) before each inner LLM call."""

    def __init__(
        self,
        tier: int,
        tool_map: dict[str, "Tool"],
        session: "Session",
    ) -> None:
        self._tier = tier
        self._tool_map = tool_map
        self._session = session

    def update_tier(self, tier: int) -> None:
        self._tier = tier

    def update_tools(self, tool_map: dict[str, "Tool"]) -> None:
        self._tool_map = tool_map

    def build(self) -> str:
        lines: list[str] = [_DIV, "CODII AGENT RUNTIME"]
        lines.append("You are Codii — an AI coding agent in a terminal.")
        lines.append("You are NOT a generic chatbot. You have tools. Use them.")

        # Tool list
        tool_names = ", ".join(self._tool_map.keys())
        lines.append(f"Tools: {tool_names}")

        # Format hint for non-native tiers
        fmt = _TIER_FORMAT.get(self._tier, "")
        if fmt:
            lines.append(f"Call format: {fmt}")

        # Session log (last 10 entries)
        log = self._session.action_log[-10:]
        if log:
            lines.append("\nSession log:")
            for entry in log:
                lines.append(f"  {entry}")

        # Plan state
        ps = self._session.plan_state
        if ps is not None and not ps.is_complete:
            lines.append("")
            lines.append(ps.render())

        lines.append(_DIV)
        lines.append("⛔ FORBIDDEN: Writing code in text (``` blocks). Use write_file / edit_file instead.")
        lines.append("→ Call your next tool now. Do NOT output code blocks.")
        return "\n".join(lines)
