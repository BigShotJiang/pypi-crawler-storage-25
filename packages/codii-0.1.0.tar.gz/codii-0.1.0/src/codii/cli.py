"""
Entry point for the `codii` command.
All heavy imports are inside command handlers to keep startup under 1 second.
"""
from __future__ import annotations

import argparse
import asyncio
import sys
from typing import Any


# ── Adapter factory ────────────────────────────────────────────────────────────

def _build_adapter(backend_cfg: dict[str, Any]) -> Any:
    """Construct the right BackendAdapter from a backend config dict."""
    from codii.connection.ollama import OllamaAdapter
    from codii.connection.vllm import VllmAdapter
    from codii.connection.lmstudio import LMStudioAdapter
    from codii.connection.openai_compat import GenericOpenAIAdapter

    btype = backend_cfg.get("type", "openai_compat")
    endpoint = backend_cfg.get("endpoint", "")
    model = backend_cfg.get("model", "")
    api_key = backend_cfg.get("api_key", "")

    match btype:
        case "ollama":
            return OllamaAdapter(endpoint=endpoint, model=model, api_key=api_key)
        case "vllm":
            return VllmAdapter(endpoint=endpoint, model=model, api_key=api_key)
        case "lmstudio":
            return LMStudioAdapter(endpoint=endpoint, model=model, api_key=api_key)
        case "openrouter":
            from codii.connection.openrouter import OpenRouterAdapter
            return OpenRouterAdapter(model=model, api_key=api_key)
        case _:
            return GenericOpenAIAdapter(endpoint=endpoint, model=model, api_key=api_key)


# ── Commands ───────────────────────────────────────────────────────────────────

async def _run_probe_async(
    adapter: Any,
    *,
    verbose: bool = False,
    max_context_tokens: int = 32000,
) -> Any:
    """Run probe, save fingerprint, print report. Returns the fingerprint."""
    from codii.probe.runner import run_probe
    from codii.fingerprint.store import save_fingerprint
    from codii.fingerprint.report import print_probe_report
    from codii.display.terminal import ProbeSpinner
    from rich.console import Console

    console = Console()

    with ProbeSpinner(adapter.model):
        fp = await run_probe(
            adapter,
            max_context_tokens=max_context_tokens,
        )

    path = save_fingerprint(fp)
    console.print()
    print_probe_report(fp, verbose=verbose)
    console.print(f"\n[dim]Fingerprint saved to: {path}[/dim]")
    return fp


def _cmd_probe(args: argparse.Namespace) -> None:
    from codii.config import load_config, get_active_backend
    from codii.display.terminal import print_error
    from codii.errors import CodiiError, no_backend_configured

    config = load_config()
    backend_cfg = get_active_backend(config)

    # Allow CLI overrides
    if args.backend or args.endpoint or args.model:
        btype = args.backend or (backend_cfg or {}).get("type", "openai_compat")
        # Build default endpoint per backend type if not provided
        default_endpoints = {
            "ollama": "http://localhost:11434",
            "lmstudio": "http://localhost:1234",
        }
        endpoint = args.endpoint or (backend_cfg or {}).get("endpoint") or default_endpoints.get(btype, "")
        model = args.model or (backend_cfg or {}).get("model", "")
        backend_cfg = {"type": btype, "endpoint": endpoint, "model": model}

    if not backend_cfg:
        print_error(no_backend_configured().message, no_backend_configured().hint)
        sys.exit(1)

    if not backend_cfg.get("model"):
        print_error("No model specified.", hint="Add --model <name> or configure one with 'codii'.")
        sys.exit(1)

    adapter = _build_adapter(backend_cfg)

    try:
        asyncio.run(_run_probe_async(adapter, verbose=args.verbose))
    except CodiiError as e:
        print_error(e.message, e.hint)
        sys.exit(1)


def _cmd_fingerprint_edit(args: argparse.Namespace) -> None:
    import os
    from codii.config import load_config, get_active_backend
    from codii.fingerprint.store import find_fingerprint_for_backend, fingerprint_path
    from codii.display.terminal import print_error, print_info
    from rich.console import Console

    console = Console()
    config = load_config()
    backend_cfg = get_active_backend(config)

    if not backend_cfg:
        print_error("No backend configured.", hint="Run 'codii' to set one up.")
        sys.exit(1)

    fp = find_fingerprint_for_backend(backend_cfg)
    if not fp:
        print_error(
            "No fingerprint found for the current model.",
            hint="Run 'codii probe' first.",
        )
        sys.exit(1)

    path = fingerprint_path(fp.backend, fp.model, fp.quant_hash)
    editor = os.environ.get("EDITOR") or os.environ.get("VISUAL")

    if editor:
        import subprocess
        subprocess.run([editor, str(path)])
    else:
        console.print(f"[yellow]$EDITOR is not set.[/yellow]")
        console.print(f"Edit the fingerprint manually at:")
        console.print(f"  [cyan]{path}[/cyan]")
        console.print(
            "\nSet overrides in the [bold]user_overrides[/bold] key, e.g.:\n"
            '  "user_overrides": {"tier": 1, "tool_call_format": "gemma4_tokens"}'
        )


async def _cmd_connect_async(url: str) -> None:
    from codii.connection.openai_compat import GenericOpenAIAdapter
    from codii.config import save_config, load_config
    from codii.display.terminal import print_error, print_success
    from codii.errors import CodiiError, endpoint_unreachable
    from rich.console import Console

    console = Console()

    if not url.startswith(("http://", "https://")):
        print_error(f"Invalid URL: {url}", hint="URL must start with http:// or https://")
        sys.exit(1)

    console.print(f"[dim]Checking endpoint {url}...[/dim]")

    adapter = GenericOpenAIAdapter(endpoint=url, model="")
    if not await adapter.health_check():
        print_error(
            f"Cannot reach endpoint at {url}",
            hint="Check that the server is running and accessible.",
        )
        sys.exit(1)

    models = await adapter.list_models()
    if not models:
        print_error(
            f"Endpoint {url} is reachable but returned no models.",
            hint="Check that a model is loaded on the server.",
        )
        sys.exit(1)

    from codii.display.terminal import ask_choice
    if len(models) == 1:
        chosen_model = models[0]
        print_success(f"Using model: {chosen_model}")
    else:
        idx = await ask_choice("Choose a model:", models)
        chosen_model = models[idx]

    config = load_config()
    config["backend"] = {
        "type": "openai_compat",
        "endpoint": url,
        "model": chosen_model,
    }
    save_config(config)
    print_success(f"Connected to {url} with model {chosen_model}")

    adapter.model = chosen_model
    try:
        await _run_probe_async(adapter)
    except CodiiError as e:
        print_error(e.message, e.hint)
        sys.exit(1)


def _cmd_connect(args: argparse.Namespace) -> None:
    asyncio.run(_cmd_connect_async(args.url))


async def _openrouter_setup_async() -> dict[str, Any]:
    """Two-step setup UI: model name → masked API key → connectivity check → save."""
    from codii.display.terminal import ask_text, ask_password, print_success
    from codii.config import save_config, load_config
    from rich.console import Console

    console = Console()
    console.print("\n[bold cyan]❯ OpenRouter Setup[/bold cyan]")
    console.print("[dim]Connect Codii to a cloud model hosted on openrouter.ai[/dim]\n")

    # Step 1: model name
    console.print("[bold]Step 1 of 2[/bold]  Model name")
    console.print("[dim]Example: google/gemma-3-27b-it  |  Browse models: openrouter.ai/models[/dim]")
    model = ""
    while not model:
        model = await ask_text("Model name")
        if not model:
            console.print("[yellow]  Model name cannot be empty.[/yellow]")
    console.print()

    # Step 2: API key (masked)
    console.print("[bold]Step 2 of 2[/bold]  API key")
    console.print("[dim]Stored in ~/.codii/config.toml — never displayed after this step.[/dim]")
    api_key = ""
    while not api_key:
        api_key = await ask_password("OpenRouter API key")
        if not api_key:
            console.print("[yellow]  API key cannot be empty.[/yellow]")
    console.print()

    # Connectivity check
    console.print("[dim]Verifying connection to openrouter.ai...[/dim]")
    from codii.connection.openrouter import OpenRouterAdapter
    adapter = OpenRouterAdapter(model=model, api_key=api_key)
    ok = await adapter.health_check()
    if ok:
        print_success("Successfully connected to OpenRouter.")
    else:
        console.print(
            "[yellow]⚠  Could not reach openrouter.ai — check your network. Proceeding anyway.[/yellow]"
        )

    backend_cfg: dict[str, Any] = {
        "type": "openrouter",
        "endpoint": "https://openrouter.ai/api",
        "model": model,
        "api_key": api_key,
    }
    config = load_config()
    config["backend"] = backend_cfg
    save_config(config)
    return backend_cfg


async def _first_run_setup_async() -> dict[str, Any] | None:
    """Detect local backends, ask user to configure one. Returns backend_cfg or None."""
    from codii.connection.ollama import OllamaAdapter, DEFAULT_ENDPOINT as OLLAMA_DEFAULT
    from codii.connection.lmstudio import LMStudioAdapter, DEFAULT_ENDPOINT as LMS_DEFAULT
    from codii.config import save_config, load_config
    from codii.display.terminal import ask_choice, ask_text, print_info, print_success
    from rich.console import Console

    console = Console()
    console.print("[bold]No model configured. Let's set one up.[/bold]\n")

    # Auto-detect local backends
    detected: list[tuple[str, str, str]] = []  # (label, type, endpoint)

    ollama_ok = await OllamaAdapter(endpoint=OLLAMA_DEFAULT).health_check()
    if ollama_ok:
        detected.append(("Ollama (detected at localhost:11434)", "ollama", OLLAMA_DEFAULT))

    lms_ok = await LMStudioAdapter(endpoint=LMS_DEFAULT).health_check()
    if lms_ok:
        detected.append(("LM Studio (detected at localhost:1234)", "lmstudio", LMS_DEFAULT))

    options = [label for label, _, _ in detected] + [
        "vLLM (enter endpoint URL)",
        "Custom OpenAI-compatible endpoint",
        "OpenRouter (cloud models — enter API key)",
        "Colab tunnel URL (use 'codii connect <url>')",
    ]

    idx = await ask_choice("Choose a backend:", options)

    if idx < len(detected):
        _, btype, endpoint = detected[idx]
    elif options[idx].startswith("vLLM"):
        btype = "vllm"
        endpoint = await ask_text("vLLM endpoint URL", default="http://localhost:8000")
    elif options[idx].startswith("OpenRouter"):
        return await _openrouter_setup_async()
    elif options[idx].startswith("Colab"):
        console.print(
            "\n[dim]For Colab tunnels, use:[/dim] [cyan]codii connect <url>[/cyan]\n"
        )
        return None
    else:
        btype = "openai_compat"
        endpoint = await ask_text("Endpoint URL", default="http://localhost:8080")

    # List models
    adapter = _build_adapter({"type": btype, "endpoint": endpoint, "model": ""})
    console.print(f"[dim]Fetching models from {endpoint}...[/dim]")

    try:
        models = await adapter.list_models()
    except Exception as e:
        from codii.display.terminal import print_error
        print_error(f"Could not list models: {e}")
        models = []

    if not models:
        model_name = await ask_text("Enter model name manually")
    elif len(models) == 1:
        model_name = models[0]
        print_success(f"Using model: {model_name}")
    else:
        midx = await ask_choice("Choose a model:", models)
        model_name = models[midx]

    backend_cfg = {"type": btype, "endpoint": endpoint, "model": model_name}
    config = load_config()
    config["backend"] = backend_cfg
    save_config(config)

    return backend_cfg


def _cmd_default(args: argparse.Namespace) -> None:
    """
    codii with no subcommand:
      - First run → setup → probe
      - Configured → start agentic session (Phase 2) or show probe result
    """
    # Re-configuration shortcut: codii --backend openrouter
    if getattr(args, "backend", None) == "openrouter":
        asyncio.run(_openrouter_setup_async())
        # Config is now saved; fall through so probe + session start normally

    from codii.config import load_config, get_active_backend
    from codii.fingerprint.store import find_fingerprint_for_backend
    from codii.display.terminal import print_codii_mark, print_error
    from codii.errors import CodiiError
    from rich.console import Console

    console = Console()
    config = load_config()
    backend_cfg = get_active_backend(config)

    # First-run setup
    if not backend_cfg:
        backend_cfg = asyncio.run(_first_run_setup_async())
        if not backend_cfg:
            return

    adapter = _build_adapter(backend_cfg)
    fp = find_fingerprint_for_backend(backend_cfg)

    # Run probe if no fingerprint exists
    if fp is None:
        try:
            fp = asyncio.run(_run_probe_async(adapter))
        except CodiiError as e:
            print_error(e.message, e.hint)
            sys.exit(1)

    caps = fp.effective_capabilities()

    # Determine workspace (CWD by default)
    from pathlib import Path
    workspace = Path.cwd()

    print_codii_mark(model=fp.model, tier=caps.tier, workspace=workspace)

    # Build scaffolding config
    from codii.scaffolding.selector import select_scaffolding
    scaffolding = select_scaffolding(fp, backend=backend_cfg.get("type", "openai_compat"))

    # Start agentic loop
    from codii.loop.runner import run_session
    asyncio.run(run_session(adapter, fp, scaffolding, workspace, auto_mode=getattr(args, "auto", False)))


def _cmd_decisions(args: argparse.Namespace) -> None:
    """Show the decision log for the most recent session."""
    from codii.config import config_dir
    from codii.decisions.logger import show_decisions
    from codii.display.terminal import print_error
    from rich.console import Console

    sessions_dir = config_dir() / "sessions"
    if not sessions_dir.exists() or not any(sessions_dir.iterdir()):
        Console().print("[dim]No sessions found yet.[/dim]")
        return

    # Find the most recent session
    session_dirs = sorted(sessions_dir.iterdir(), key=lambda p: p.stat().st_mtime, reverse=True)
    if not session_dirs:
        Console().print("[dim]No sessions found.[/dim]")
        return

    session_dir = session_dirs[0]
    if not (session_dir / "decisions.jsonl").exists():
        Console().print(f"[dim]No decision log found in {session_dir.name}[/dim]")
        return

    output = show_decisions(
        session_dir,
        type_filter=getattr(args, "type", None),
    )
    Console().print(output)


# ── Main entry point ───────────────────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser(
        prog="codii",
        description="Terminal-native agentic coding runtime for local open-weight models",
    )
    sub = parser.add_subparsers(dest="command")

    # codii probe
    probe_p = sub.add_parser("probe", help="Run capability probe against a model")
    probe_p.add_argument("--verbose", "-v", action="store_true", help="Show full probe trace")
    probe_p.add_argument("--backend", help="Backend type: ollama, vllm, lmstudio, openai_compat")
    probe_p.add_argument("--endpoint", help="Endpoint URL")
    probe_p.add_argument("--model", help="Model name")

    # codii fingerprint
    fp_p = sub.add_parser("fingerprint", help="Manage capability fingerprints")
    fp_sub = fp_p.add_subparsers(dest="fp_command")
    fp_sub.add_parser("edit", help="Edit the current model's fingerprint")
    fp_sub.add_parser("show", help="Show the current model's fingerprint")
    fp_sub.add_parser("list", help="List all stored fingerprints")

    # codii connect
    connect_p = sub.add_parser("connect", help="Connect to a remote endpoint (e.g. Colab tunnel)")
    connect_p.add_argument("url", help="Endpoint URL")

    # codii decisions
    dec_p = sub.add_parser("decisions", help="Show decision log for the most recent session")
    dec_p.add_argument("--type", help="Filter by decision type (e.g. repair, tier_select)")
    dec_p.add_argument("--since", type=int, metavar="MINUTES", help="Show decisions from last N minutes")

    # codii serve
    serve_p = sub.add_parser("serve", help="Start Anthropic Messages API shim backed by local model")
    serve_p.add_argument("--port", type=int, default=8080, help="Port to listen on (default: 8080)")
    serve_p.add_argument("--host", default="127.0.0.1", help="Host to bind (default: 127.0.0.1)")
    serve_p.add_argument("--require-auth", metavar="TOKEN", help="Require x-api-key header to match TOKEN")

    # codii replay
    replay_p = sub.add_parser("replay", help="Replay a past session transcript")
    replay_p.add_argument("session_id", nargs="?", help="Session ID to replay (default: most recent)")
    replay_p.add_argument("--list", action="store_true", help="List available sessions")

    # Global --auto flag for autonomous mode (no confirmation prompts)
    parser.add_argument("--auto", action="store_true", help="Run in autonomous mode (skip confirmation prompts)")
    # Global --backend flag for reconfiguration (e.g., codii --backend openrouter)
    parser.add_argument(
        "--backend",
        metavar="TYPE",
        help="Force backend reconfiguration (e.g., openrouter)",
    )

    args = parser.parse_args()

    match args.command:
        case None:
            _cmd_default(args)
        case "probe":
            _cmd_probe(args)
        case "fingerprint":
            match getattr(args, "fp_command", None):
                case "edit":
                    _cmd_fingerprint_edit(args)
                case "show":
                    _cmd_fingerprint_show(args)
                case "list":
                    _cmd_fingerprint_list(args)
                case _:
                    _cmd_fingerprint_edit(args)
        case "connect":
            _cmd_connect(args)
        case "decisions":
            _cmd_decisions(args)
        case "serve":
            _cmd_serve(args)
        case "replay":
            _cmd_replay(args)
        case _:
            parser.print_help()


def _cmd_fingerprint_show(args: argparse.Namespace) -> None:
    from codii.config import load_config, get_active_backend
    from codii.fingerprint.store import find_fingerprint_for_backend
    from codii.fingerprint.report import print_probe_report
    from codii.display.terminal import print_error

    config = load_config()
    backend_cfg = get_active_backend(config)
    if not backend_cfg:
        print_error("No backend configured.")
        sys.exit(1)

    fp = find_fingerprint_for_backend(backend_cfg)
    if not fp:
        print_error("No fingerprint found.", hint="Run 'codii probe' first.")
        sys.exit(1)

    print_probe_report(fp, verbose=True)


def _cmd_fingerprint_list(args: argparse.Namespace) -> None:
    from codii.fingerprint.store import list_fingerprints
    from rich.console import Console
    from rich.table import Table

    fps = list_fingerprints()
    console = Console()

    if not fps:
        console.print("[dim]No fingerprints stored yet.[/dim]")
        return

    table = Table(title="Stored Fingerprints")
    table.add_column("Backend", style="cyan")
    table.add_column("Model", style="white")
    table.add_column("Family", style="dim")
    table.add_column("Format", style="dim")
    table.add_column("Tier", style="bold")
    table.add_column("Created", style="dim")

    for fp in fps:
        caps = fp.effective_capabilities()
        table.add_row(
            fp.backend,
            fp.model,
            caps.family,
            caps.tool_call_format,
            str(caps.tier),
            fp.created_at.strftime("%Y-%m-%d %H:%M"),
        )

    console.print(table)


def _cmd_serve(args: argparse.Namespace) -> None:
    """Start the Anthropic Messages API shim."""
    try:
        import uvicorn
    except ImportError:
        from codii.display.terminal import print_error
        print_error("uvicorn is required for 'codii serve'.", hint="pip install uvicorn fastapi")
        sys.exit(1)

    from codii.config import load_config, get_active_backend
    from codii.display.terminal import print_error
    from rich.console import Console

    console = Console()
    config = load_config()
    backend_cfg = get_active_backend(config)
    if not backend_cfg:
        print_error("No backend configured.", hint="Run 'codii' to set one up.")
        sys.exit(1)

    adapter = _build_adapter(backend_cfg)

    from codii.serve.app import create_app
    app = create_app(adapter, require_auth=args.require_auth)

    console.print(
        f"[bold]codii serve[/bold] listening on "
        f"[cyan]http://{args.host}:{args.port}/v1/messages[/cyan]"
    )
    if args.require_auth:
        console.print("[dim]Auth required via x-api-key header.[/dim]")

    uvicorn.run(app, host=args.host, port=args.port, log_level="warning")


def _cmd_replay(args: argparse.Namespace) -> None:
    """Replay or list session transcripts."""
    from codii.config import config_dir
    from codii.replay.transcript import load_transcript
    from rich.console import Console
    from rich.table import Table

    console = Console()
    sessions_dir = config_dir() / "sessions"

    if not sessions_dir.exists() or not any(sessions_dir.iterdir()):
        console.print("[dim]No sessions found.[/dim]")
        return

    session_dirs = sorted(sessions_dir.iterdir(), key=lambda p: p.stat().st_mtime, reverse=True)

    if getattr(args, "list", False):
        table = Table(title="Recorded Sessions")
        table.add_column("ID", style="cyan")
        table.add_column("Events", style="dim")
        table.add_column("Modified", style="dim")
        for d in session_dirs:
            events = load_transcript(d)
            table.add_row(
                d.name,
                str(len(events)),
                __import__("datetime").datetime.fromtimestamp(d.stat().st_mtime).strftime("%Y-%m-%d %H:%M"),
            )
        console.print(table)
        return

    # Resolve session directory
    session_id = getattr(args, "session_id", None)
    if session_id:
        target = sessions_dir / session_id
        if not target.exists():
            from codii.display.terminal import print_error
            print_error(f"Session '{session_id}' not found.", hint="Run 'codii replay --list' to see available sessions.")
            sys.exit(1)
    else:
        target = session_dirs[0]

    events = load_transcript(target)
    if not events:
        console.print(f"[dim]No transcript found in session {target.name}[/dim]")
        return

    console.print(f"[bold]Replaying session:[/bold] [cyan]{target.name}[/cyan]  ({len(events)} events)\n")

    for ev in events:
        etype = ev.get("type", "")
        payload = ev.get("payload", {})
        seq = ev.get("seq", "?")
        ts = ev.get("ts", "")[:19].replace("T", " ")

        if etype == "session_header":
            console.print(f"[dim]{ts}[/dim]  [bold]session start[/bold]  tier={payload.get('tier')}  model={payload.get('fingerprint', {}).get('model', '?')}")
        elif etype == "user_message":
            console.print(f"[dim]{ts}[/dim]  [green]user[/green]  {payload.get('content', '')[:120]}")
        elif etype == "response_complete":
            text = payload.get("text", "")
            preview = text[:100].replace("\n", " ")
            tool_count = len(payload.get("tool_calls", []))
            suffix = f"  +{tool_count} tool call(s)" if tool_count else ""
            console.print(f"[dim]{ts}[/dim]  [blue]assistant[/blue]  {preview}{suffix}")
        elif etype == "tool_call":
            console.print(f"[dim]{ts}[/dim]  [yellow]tool[/yellow]  {payload.get('name')}({str(payload.get('arguments', {}))[:80]})")
        elif etype == "tool_result":
            status = "[green]ok[/green]" if payload.get("success") else "[red]err[/red]"
            console.print(f"[dim]{ts}[/dim]  {status}  {str(payload.get('output', ''))[:80]}")
        elif etype == "session_end":
            console.print(f"\n[dim]{ts}[/dim]  [bold]session end[/bold]  turns={payload.get('turns', '?')}")
        elif etype == "intervention":
            console.print(f"[dim]{ts}[/dim]  [red]intervention[/red]  {payload.get('reason', '')}")
