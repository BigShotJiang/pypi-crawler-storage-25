"""~/.codii/config.toml management. Uses Path.home() everywhere."""
from __future__ import annotations

import tomllib
from pathlib import Path
from typing import Any

import tomli_w


def config_dir() -> Path:
    """Returns ~/.codii, creating it and required subdirectories on first call."""
    d = Path.home() / ".codii"
    for sub in ("fingerprints", "sessions", "agents"):
        (d / sub).mkdir(parents=True, exist_ok=True)
    return d


def load_config() -> dict[str, Any]:
    """Read config.toml; return {} if absent (first run)."""
    p = config_dir() / "config.toml"
    if not p.exists():
        return {}
    with open(p, "rb") as f:
        return tomllib.load(f)


def save_config(data: dict[str, Any]) -> None:
    """Write config.toml atomically using Path.replace() (Windows-safe)."""
    p = config_dir() / "config.toml"
    tmp = p.with_name("config.toml.tmp")
    with open(tmp, "wb") as f:
        tomli_w.dump(data, f)
    tmp.replace(p)


def get_active_backend(config: dict[str, Any] | None = None) -> dict[str, Any] | None:
    """Return the [backend] section or None if unconfigured."""
    if config is None:
        config = load_config()
    val = config.get("backend")
    if isinstance(val, dict):
        return val
    return None
