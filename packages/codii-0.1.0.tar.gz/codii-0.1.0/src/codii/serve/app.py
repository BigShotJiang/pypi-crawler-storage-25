"""Anthropic Messages API compatibility shim.

Start with: codii serve [--port 8080] [--require-auth TOKEN]
Exposes /v1/messages matching the Anthropic wire format, backed by the
configured local model through codii's full adaptive runtime.
"""
from __future__ import annotations

import json
import uuid
from typing import Any, AsyncIterator

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import Response, StreamingResponse
from pydantic import BaseModel, Field

from codii.connection.base import BackendAdapter, RequestMessage, TextChunk, ToolCall, Done


# ── Anthropic request/response models ─────────────────────────────────────────

class AnthropicContentBlock(BaseModel):
    type: str
    text: str | None = None
    id: str | None = None
    name: str | None = None
    input: dict[str, Any] | None = None


class AnthropicMessage(BaseModel):
    role: str
    content: str | list[AnthropicContentBlock]


class AnthropicTool(BaseModel):
    name: str
    description: str | None = None
    input_schema: dict[str, Any] = Field(default_factory=dict)


class AnthropicRequest(BaseModel):
    model: str
    messages: list[AnthropicMessage]
    system: str | None = None
    max_tokens: int = 4096
    tools: list[AnthropicTool] = Field(default_factory=list)
    stream: bool = False
    # Accept-and-ignore Anthropic-specific fields
    temperature: float | None = None
    top_p: float | None = None
    top_k: int | None = None
    metadata: dict[str, Any] | None = None


# ── Translation helpers ────────────────────────────────────────────────────────

def _to_internal_messages(req: AnthropicRequest) -> list[RequestMessage]:
    msgs: list[RequestMessage] = []
    if req.system:
        msgs.append(RequestMessage(role="system", content=req.system))
    for m in req.messages:
        if isinstance(m.content, str):
            content = m.content
        else:
            # Extract text parts from content blocks
            parts = [b.text for b in m.content if b.type == "text" and b.text]
            content = "\n".join(parts)
        msgs.append(RequestMessage(role=m.role, content=content))
    return msgs


def _to_internal_tool_defs(tools: list[AnthropicTool]) -> list[Any]:
    from codii.connection.base import ToolDefinition
    return [
        ToolDefinition(
            name=t.name,
            description=t.description or "",
            parameters=t.input_schema,
        )
        for t in tools
    ]


def _build_full_response(text: str, tool_calls: list[ToolCall], model: str) -> dict[str, Any]:
    content: list[dict[str, Any]] = []
    if text:
        content.append({"type": "text", "text": text})
    for tc in tool_calls:
        content.append({
            "type": "tool_use",
            "id": tc.id or str(uuid.uuid4()),
            "name": tc.name,
            "input": tc.arguments,
        })
    return {
        "id": f"msg_{uuid.uuid4().hex[:24]}",
        "type": "message",
        "role": "assistant",
        "content": content,
        "model": model,
        "stop_reason": "tool_use" if tool_calls else "end_turn",
        "stop_sequence": None,
        "usage": {
            "input_tokens": 0,
            "output_tokens": len(text) // 4,
        },
    }


async def _stream_response(
    adapter: BackendAdapter,
    messages: list[RequestMessage],
    tool_defs: list[Any],
    model: str,
) -> AsyncIterator[str]:
    """Yield SSE lines in Anthropic streaming format."""
    msg_id = f"msg_{uuid.uuid4().hex[:24]}"
    yield f"data: {json.dumps({'type': 'message_start', 'message': {'id': msg_id, 'type': 'message', 'role': 'assistant', 'content': [], 'model': model, 'stop_reason': None, 'usage': {'input_tokens': 0, 'output_tokens': 0}}})}\n\n"
    yield f"data: {json.dumps({'type': 'content_block_start', 'index': 0, 'content_block': {'type': 'text', 'text': ''}})}\n\n"
    yield "data: {\"type\": \"ping\"}\n\n"

    text_parts: list[str] = []
    tool_calls: list[ToolCall] = []

    async for event in adapter.send_request(messages, tool_defs):
        match event:
            case TextChunk(text=chunk):
                text_parts.append(chunk)
                delta = {"type": "content_block_delta", "index": 0, "delta": {"type": "text_delta", "text": chunk}}
                yield f"data: {json.dumps(delta)}\n\n"
            case ToolCall() as tc:
                tool_calls.append(tc)
            case Done():
                break

    yield f"data: {json.dumps({'type': 'content_block_stop', 'index': 0})}\n\n"

    stop_reason = "tool_use" if tool_calls else "end_turn"
    output_tokens = sum(len(p) for p in text_parts) // 4
    yield f"data: {json.dumps({'type': 'message_delta', 'delta': {'stop_reason': stop_reason, 'stop_sequence': None}, 'usage': {'output_tokens': output_tokens}})}\n\n"
    yield f"data: {json.dumps({'type': 'message_stop'})}\n\n"


# ── App factory ────────────────────────────────────────────────────────────────

def create_app(adapter: BackendAdapter, require_auth: str | None = None) -> FastAPI:
    app = FastAPI(title="codii Anthropic Shim", version="0.1.0")

    @app.post("/v1/messages")
    async def messages(request: Request, body: AnthropicRequest) -> Response:
        # Optional auth check
        if require_auth:
            auth = request.headers.get("x-api-key") or request.headers.get("authorization", "").removeprefix("Bearer ")
            if auth != require_auth:
                raise HTTPException(status_code=401, detail="Invalid API key")

        internal_messages = _to_internal_messages(body)
        internal_tools = _to_internal_tool_defs(body.tools) if body.tools else []

        if body.stream:
            return StreamingResponse(
                _stream_response(adapter, internal_messages, internal_tools, body.model),
                media_type="text/event-stream",
                headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
            )

        # Non-streaming: collect full response
        text_parts: list[str] = []
        tool_calls: list[ToolCall] = []
        async for event in adapter.send_request(internal_messages, internal_tools):
            match event:
                case TextChunk(text=chunk):
                    text_parts.append(chunk)
                case ToolCall() as tc:
                    tool_calls.append(tc)
                case Done():
                    break

        response_body = _build_full_response("".join(text_parts), tool_calls, body.model)
        return Response(
            content=json.dumps(response_body),
            media_type="application/json",
        )

    return app
