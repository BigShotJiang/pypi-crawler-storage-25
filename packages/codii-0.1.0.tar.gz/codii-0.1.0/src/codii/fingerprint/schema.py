"""CapabilityFingerprint — exact Appendix A schema. Do not add or rename fields."""
from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, Field

FamilyEnum = Literal["gemma4", "qwen", "mistral", "llama", "deepseek", "phi", "other", "unknown"]
ToolFormatEnum = Literal[
    "gemma4_tokens",
    "hermes_xml",
    "qwen_json",
    "mistral_json",
    "openai_json",
    "anthropic_xml",
    "none",
]


class ReasoningSupport(BaseModel):
    supported: bool
    delimiter: str | None = None


class Capabilities(BaseModel):
    family: FamilyEnum
    tool_call_format: ToolFormatEnum
    native_tool_calling: bool
    effective_context_tokens: int
    claimed_context_tokens: int
    reasoning_support: ReasoningSupport
    structured_output_reliability: float
    instruction_following_reliability: float
    tier: int  # 1, 2, or 3
    tier_rationale: str


class CapabilityFingerprint(BaseModel):
    schema_version: int = 1
    created_at: datetime
    updated_at: datetime
    backend: str
    endpoint: str
    model: str
    quant_hash: str
    capabilities: Capabilities
    probe_trace: dict[str, Any] = Field(default_factory=dict)
    user_overrides: dict[str, Any] = Field(default_factory=dict)

    def effective_capabilities(self) -> Capabilities:
        """
        Return capabilities with user_overrides applied.
        User overrides take precedence over probe-derived values.
        """
        if not self.user_overrides:
            return self.capabilities

        caps_dict = self.capabilities.model_dump()
        for key, value in self.user_overrides.items():
            if key in caps_dict:
                caps_dict[key] = value
            # Nested: reasoning_support.delimiter etc.
            elif "." in key:
                parts = key.split(".", 1)
                if parts[0] in caps_dict and isinstance(caps_dict[parts[0]], dict):
                    caps_dict[parts[0]][parts[1]] = value

        return Capabilities.model_validate(caps_dict)
