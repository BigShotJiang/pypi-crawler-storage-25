"""Rich-rendered probe report. Three-line summary + verbose trace."""
from __future__ import annotations

import json

from codii.fingerprint.schema import CapabilityFingerprint


def print_probe_report(fp: CapabilityFingerprint, *, verbose: bool = False) -> None:
    """Print the three-line probe summary using Rich. Verbose shows full trace."""
    from rich.console import Console
    from rich.syntax import Syntax
    from rich.text import Text

    console = Console()
    caps = fp.effective_capabilities()

    # Line 1: family, format, context
    ctx_k = caps.effective_context_tokens // 1000
    ctx_str = f"{ctx_k}k" if ctx_k > 0 else str(caps.effective_context_tokens)
    line1 = Text()
    line1.append("Family: ", style="dim")
    line1.append(caps.family, style="cyan bold")
    line1.append("  Format: ", style="dim")
    line1.append(caps.tool_call_format, style="cyan")
    line1.append("  Context: ", style="dim")
    line1.append(f"{ctx_str} tokens", style="cyan")

    # Line 2: structured output, reasoning
    reasoning_str = (
        f"supported ({caps.reasoning_support.delimiter})"
        if caps.reasoning_support.supported and caps.reasoning_support.delimiter
        else ("supported" if caps.reasoning_support.supported else "not detected")
    )
    line2 = Text()
    line2.append("Structured output: ", style="dim")
    line2.append(f"{caps.structured_output_reliability:.2f}", style="cyan")
    line2.append("  Reasoning: ", style="dim")
    line2.append(reasoning_str, style="cyan")

    # Line 3: tier with rationale
    tier_color = {1: "green", 2: "yellow", 3: "red"}.get(caps.tier, "white")
    line3 = Text()
    line3.append("Scaffolding tier: ", style="dim")
    line3.append(str(caps.tier), style=f"{tier_color} bold")
    line3.append(f" — {caps.tier_rationale}", style="dim")

    console.print(line1)
    console.print(line2)
    console.print(line3)

    if verbose:
        console.print()
        console.print("[dim]── Probe trace ─────────────────────────────────────[/dim]")
        trace_json = json.dumps(fp.probe_trace, indent=2, default=str)
        console.print(Syntax(trace_json, "json", theme="monokai", word_wrap=True))
        console.print()
        console.print("[dim]── Full fingerprint ──────────────────────────────────[/dim]")
        full_json = json.dumps(fp.model_dump(mode="json"), indent=2, default=str)
        console.print(Syntax(full_json, "json", theme="monokai", word_wrap=True))
