"""Persist and load CapabilityFingerprint to/from ~/.codii/fingerprints/."""
from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from codii.config import config_dir
from codii.fingerprint.schema import CapabilityFingerprint


def _fingerprints_dir() -> Path:
    return config_dir() / "fingerprints"


def slugify(backend: str, model: str, quant_hash: str) -> str:
    """
    Build a safe filename slug.
    Example: ollama + gemma4:27b + abc12345 → ollama_gemma4_27b_abc12345
    """
    raw = f"{backend}_{model}"
    slug = re.sub(r"[^a-z0-9]", "_", raw.lower())
    slug = re.sub(r"_+", "_", slug).strip("_")
    return f"{slug}_{quant_hash[:8].lower()}"


def fingerprint_path(backend: str, model: str, quant_hash: str) -> Path:
    return _fingerprints_dir() / f"{slugify(backend, model, quant_hash)}.json"


def save_fingerprint(fp: CapabilityFingerprint) -> Path:
    """Write fingerprint JSON atomically. Returns the path written."""
    path = fingerprint_path(fp.backend, fp.model, fp.quant_hash)
    tmp = path.with_suffix(".json.tmp")
    data = fp.model_dump(mode="json")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, default=str)
    tmp.replace(path)  # Windows-safe atomic replace
    return path


def load_fingerprint(backend: str, model: str, quant_hash: str) -> CapabilityFingerprint | None:
    """Load fingerprint; return None if not found."""
    path = fingerprint_path(backend, model, quant_hash)
    if not path.exists():
        return None
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    return CapabilityFingerprint.model_validate(data)


def list_fingerprints() -> list[CapabilityFingerprint]:
    """Return all stored fingerprints."""
    fps: list[CapabilityFingerprint] = []
    d = _fingerprints_dir()
    for p in d.glob("*.json"):
        if p.suffix == ".json" and not p.stem.endswith(".tmp"):
            try:
                with open(p, encoding="utf-8") as f:
                    data = json.load(f)
                fps.append(CapabilityFingerprint.model_validate(data))
            except Exception:
                pass  # Skip corrupted fingerprints
    return fps


def find_fingerprint_for_backend(backend_cfg: dict[str, Any]) -> CapabilityFingerprint | None:
    """
    Look up any fingerprint matching backend type + endpoint + model.
    Used to skip re-probing on resume.
    """
    backend = backend_cfg.get("type", "")
    endpoint = str(backend_cfg.get("endpoint", "")).rstrip("/")
    model = backend_cfg.get("model", "")

    for fp in list_fingerprints():
        if (
            fp.backend == backend
            and fp.endpoint.rstrip("/") == endpoint
            and fp.model == model
        ):
            return fp
    return None
