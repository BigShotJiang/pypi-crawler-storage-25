"""
Feature ledger — pre-loop project summary injected at the top of every request.
Reads dir structure + git state, produces a 2-3 paragraph string.
"""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

_SKIP_DIRS = {".git", "__pycache__", "node_modules", ".venv", "venv", ".mypy_cache", ".ruff_cache"}
_CONFIG_FILES = {
    "pyproject.toml", "package.json", "Cargo.toml", "go.mod",
    "setup.py", "setup.cfg", "Makefile", "requirements.txt",
}
_MAX_DIR_DEPTH = 3


def _tree(root: Path, depth: int = 0) -> list[str]:
    if depth >= _MAX_DIR_DEPTH:
        return []
    lines: list[str] = []
    try:
        for item in sorted(root.iterdir()):
            if item.name in _SKIP_DIRS:
                continue
            prefix = "  " * depth
            if item.is_dir():
                lines.append(f"{prefix}{item.name}/")
                lines.extend(_tree(item, depth + 1))
            else:
                lines.append(f"{prefix}{item.name}")
    except PermissionError:
        pass
    return lines


def _run_git(*args: str, cwd: Path) -> str:
    try:
        result = subprocess.run(
            ["git", *args],
            cwd=str(cwd),
            capture_output=True,
            text=True,
            timeout=5,
        )
        return result.stdout.strip()
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        return ""


def _read_config(workspace: Path) -> str:
    parts: list[str] = []
    for name in _CONFIG_FILES:
        p = workspace / name
        if p.exists():
            try:
                content = p.read_text(encoding="utf-8", errors="replace")
                parts.append(f"=== {name} ===\n{content[:2000]}")
            except OSError:
                pass
    return "\n\n".join(parts)


def build_ledger(workspace: Path) -> str:
    """Build the feature ledger string for the given workspace."""
    # Directory structure
    tree_lines = _tree(workspace)
    tree_str = "\n".join(tree_lines[:100])  # cap at 100 lines

    # Config files
    config_str = _read_config(workspace)

    # Git state
    branch = _run_git("branch", "--show-current", cwd=workspace)
    uncommitted = _run_git("status", "--short", cwd=workspace)
    recent_commits = _run_git("log", "--oneline", "-5", cwd=workspace)

    git_section = ""
    if branch or uncommitted or recent_commits:
        parts = []
        if branch:
            parts.append(f"Branch: {branch}")
        if uncommitted:
            parts.append(f"Uncommitted changes:\n{uncommitted}")
        if recent_commits:
            parts.append(f"Recent commits:\n{recent_commits}")
        git_section = "\n".join(parts)

    sections: list[str] = []
    if tree_str:
        sections.append(f"## Project structure\n{tree_str}")
    if config_str:
        sections.append(f"## Configuration\n{config_str[:3000]}")
    if git_section:
        sections.append(f"## Git state\n{git_section}")

    ledger = "\n\n".join(sections)
    return ledger


def initialize_ledger(workspace: Path) -> str:
    """Build ledger, write to .codii/ledger.md, and return the string."""
    ledger = build_ledger(workspace)

    ledger_path = workspace / ".codii" / "ledger.md"
    ledger_path.parent.mkdir(parents=True, exist_ok=True)
    tmp = ledger_path.with_suffix(".tmp")
    tmp.write_text(ledger, encoding="utf-8")
    tmp.replace(ledger_path)

    return ledger
