"""Explicit lookup table: tool_call_format string → parser instance."""
from __future__ import annotations

from codii.parser.base import Parser
from codii.parser.gemma4 import Gemma4Parser
from codii.parser.generic import GenericParser
from codii.parser.hermes import HermesParser
from codii.parser.mistral import MistralParser
from codii.parser.qwen import QwenParser

_PARSERS: dict[str, Parser] = {
    "gemma4_tokens": Gemma4Parser(),
    "hermes_xml": HermesParser(),
    "qwen_json": QwenParser(),
    "mistral_json": MistralParser(),
    "openai_json": GenericParser(),
    "anthropic_xml": GenericParser(),
    "none": GenericParser(),
    "unknown": GenericParser(),
}

_GENERIC = GenericParser()


def get_parser(tool_call_format: str) -> Parser:
    return _PARSERS.get(tool_call_format, _GENERIC)
