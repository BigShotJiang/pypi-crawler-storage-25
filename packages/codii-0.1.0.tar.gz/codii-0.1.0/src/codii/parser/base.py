"""Parser base types, repair framework, and shared utilities."""
from __future__ import annotations

import json
import re
import uuid
from dataclasses import dataclass, field
from typing import Any, Protocol

from codii.connection.base import ToolDefinition


@dataclass
class RepairTrace:
    """Records which repair heuristics were attempted and what they found."""
    steps_attempted: list[str] = field(default_factory=list)
    succeeded_at: str | None = None  # which step produced a parse
    repair_failed: bool = False  # True when all repair steps exhausted

    def attempt(self, step: str) -> None:
        self.steps_attempted.append(step)

    def success(self, step: str) -> None:
        self.succeeded_at = step

    def fail(self) -> None:
        self.repair_failed = True


@dataclass
class ParsedToolCall:
    id: str
    name: str
    arguments: dict[str, Any]
    repair_trace: RepairTrace = field(default_factory=RepairTrace)


class Parser(Protocol):
    def parse(self, raw_text: str, tools: list[ToolDefinition]) -> list[ParsedToolCall]:
        ...


# ── Shared repair utilities ────────────────────────────────────────────────────

_FENCE_RE = re.compile(r"```(?:json|python)?\s*(.*?)\s*```", re.DOTALL)
_THINK_RE = re.compile(
    r"<(?:think|thinking|\|begin_of_thought\|)>.*?<(?:/think|/thinking|\|end_of_thought\|)>",
    re.DOTALL | re.IGNORECASE,
)


def strip_reasoning(text: str) -> str:
    """Remove <think>...</think> and similar reasoning blocks."""
    return _THINK_RE.sub("", text).strip()


def extract_json_from_fence(text: str) -> str | None:
    """Extract JSON from a markdown code fence."""
    m = _FENCE_RE.search(text)
    return m.group(1).strip() if m else None


def try_parse_json(text: str, trace: RepairTrace) -> dict[str, Any] | None:
    """
    Apply repair heuristics in order. Returns a dict on success or None.
    Steps:
      1. strict parse
      2. lenient parse (single→double quotes, trailing commas)
      3. structural completion (close open braces)
    """
    trace.attempt("strict_parse")
    try:
        result = json.loads(text)
        if isinstance(result, dict):
            trace.success("strict_parse")
            return result
    except json.JSONDecodeError:
        pass

    trace.attempt("lenient_parse")
    lenient = _lenient_fix(text)
    try:
        result = json.loads(lenient)
        if isinstance(result, dict):
            trace.success("lenient_parse")
            return result
    except json.JSONDecodeError:
        pass

    trace.attempt("structural_completion")
    completed = _complete_json(text)
    try:
        result = json.loads(completed)
        if isinstance(result, dict):
            trace.success("structural_completion")
            return result
    except json.JSONDecodeError:
        pass

    return None


def _lenient_fix(text: str) -> str:
    """Fix common JSON issues: single quotes, trailing commas."""
    # Replace single quotes wrapping strings (simplified — won't catch all cases)
    fixed = re.sub(r"'([^']*)'", lambda m: json.dumps(m.group(1)), text)
    # Remove trailing commas before } or ]
    fixed = re.sub(r",\s*([}\]])", r"\1", fixed)
    return fixed


def _complete_json(text: str) -> str:
    """Attempt to close unclosed JSON braces and brackets."""
    text = text.strip()
    opens = {"(": ")", "{": "}", "[": "]"}
    closes = set(opens.values())
    stack: list[str] = []
    in_string = False
    escape_next = False

    for ch in text:
        if escape_next:
            escape_next = False
            continue
        if ch == "\\" and in_string:
            escape_next = True
            continue
        if ch == '"':
            in_string = not in_string
            continue
        if in_string:
            continue
        if ch in opens:
            stack.append(opens[ch])
        elif ch in closes:
            if stack and stack[-1] == ch:
                stack.pop()

    # Close open string if needed
    if in_string:
        text += '"'
    # Close open structures
    text += "".join(reversed(stack))
    return text


_JSON_BLOB_RE = re.compile(r"\{[^{}]*(?:\{[^{}]*\}[^{}]*)?\}", re.DOTALL)
_NAME_FIELD_RE = re.compile(r'"(?:name|function|tool_name)"\s*:\s*"([^"]+)"')


def try_extract_named_object(text: str, trace: RepairTrace) -> dict[str, Any] | None:
    """Step 4: scan for any JSON object whose 'name' key matches a plausible tool name."""
    trace.attempt("extract_named_object")
    for m in _JSON_BLOB_RE.finditer(text):
        blob = m.group()
        if not _NAME_FIELD_RE.search(blob):
            continue
        parsed = try_parse_json(blob, RepairTrace())
        if parsed and isinstance(parsed.get("name") or parsed.get("function"), str):
            trace.success("extract_named_object")
            return parsed
    return None


def try_semantic_repair(
    text: str,
    tools: "list[Any]",
    trace: RepairTrace,
) -> dict[str, Any] | None:
    """Step 5: fuzzy-match a JSON blob's keys against a known tool schema.

    Only returns a result when ≥50% of the matched tool's required parameters are
    found — prevents false positives from prose that contains JSON-like structures.
    """
    trace.attempt("semantic_repair")
    if not tools:
        return None

    for m in _JSON_BLOB_RE.finditer(text):
        blob = m.group()
        raw: dict[str, Any] | None = None
        try:
            raw = json.loads(blob)
        except json.JSONDecodeError:
            raw = None
        if not isinstance(raw, dict):
            continue

        blob_keys_lower = {k.lower() for k in raw}

        # Try each known tool
        for tool in tools:
            tool_name: str = getattr(tool, "name", "") or tool.get("name", "")
            if not tool_name:
                continue

            params_schema: dict[str, Any] = {}
            if hasattr(tool, "parameters"):
                params_schema = tool.parameters or {}
            elif isinstance(tool, dict):
                params_schema = tool.get("parameters", {})

            required: list[str] = params_schema.get("required", [])
            props: dict[str, Any] = params_schema.get("properties", {})

            if not props:
                continue

            prop_names_lower = {p.lower() for p in props}
            matched_required = sum(
                1 for r in required if r.lower() in blob_keys_lower
            )
            threshold = max(1, len(required) // 2)  # at least 50% of required params

            if matched_required >= threshold or (not required and blob_keys_lower & prop_names_lower):
                # Build arguments from blob, mapping lowercased keys back
                args: dict[str, Any] = {}
                for prop in props:
                    if prop.lower() in blob_keys_lower:
                        # find the original key
                        orig = next((k for k in raw if k.lower() == prop.lower()), prop)
                        args[prop] = raw[orig]

                if args:
                    trace.success("semantic_repair")
                    return {"name": tool_name, "arguments": args}
    return None


def normalize_arguments(raw: str | dict[str, Any]) -> dict[str, Any]:
    """Always return a dict. Handles stringified JSON."""
    if isinstance(raw, dict):
        return raw
    try:
        parsed = json.loads(raw)
        return parsed if isinstance(parsed, dict) else {}
    except (json.JSONDecodeError, TypeError):
        return {}


def make_tool_call(name: str, arguments: dict[str, Any], trace: RepairTrace) -> ParsedToolCall:
    return ParsedToolCall(
        id=str(uuid.uuid4()),
        name=name,
        arguments=arguments,
        repair_trace=trace,
    )
