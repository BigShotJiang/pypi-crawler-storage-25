"""Qwen JSON variant parser: normalizes name/function field and arguments."""
from __future__ import annotations

import re
from typing import Any

from codii.connection.base import ToolDefinition
from codii.parser.base import (
    ParsedToolCall,
    RepairTrace,
    make_tool_call,
    normalize_arguments,
    strip_reasoning,
    try_parse_json,
)

# Qwen often wraps calls in: {"type": "function", "function": {"name": ..., "arguments": ...}}
_TYPE_FUNCTION_RE = re.compile(r'"type"\s*:\s*"function"', re.IGNORECASE)


class QwenParser:
    """Parser for Qwen's JSON tool call variant."""

    def parse(self, raw_text: str, tools: list[ToolDefinition]) -> list[ParsedToolCall]:
        text = strip_reasoning(raw_text)
        results: list[ParsedToolCall] = []
        trace = RepairTrace()

        parsed = try_parse_json(text, trace)
        if parsed:
            tc = _normalize_qwen(parsed, trace)
            if tc:
                results.append(tc)
                return results

        # Try extracting from list
        trace.attempt("qwen_list_extract")
        list_match = re.search(r"\[.*?\]", text, re.DOTALL)
        if list_match:
            try:
                import json
                items = json.loads(list_match.group())
                if isinstance(items, list):
                    for item in items:
                        if isinstance(item, dict):
                            tc = _normalize_qwen(item, RepairTrace())
                            if tc:
                                results.append(tc)
            except Exception:
                pass

        return results


def _normalize_qwen(data: dict[str, Any], trace: RepairTrace) -> ParsedToolCall | None:
    """Handle Qwen's function wrapper and name/arguments variations."""
    trace.attempt("qwen_normalize")

    # Unwrap {"type": "function", "function": {...}}
    if data.get("type") == "function" and "function" in data:
        data = data["function"]

    name = data.get("name") or data.get("function")
    args = data.get("arguments") or data.get("parameters", {})

    if not name:
        return None

    trace.success("qwen_normalize")
    return make_tool_call(str(name), normalize_arguments(args), trace)
