"""Mistral/Devstral parser: [TOOL_CALLS] marker with JSON array."""
from __future__ import annotations

import json
import re

from codii.connection.base import ToolDefinition
from codii.parser.base import (
    ParsedToolCall,
    RepairTrace,
    make_tool_call,
    normalize_arguments,
    strip_reasoning,
    try_parse_json,
)

_TOOL_CALLS_MARKER = re.compile(r"\[TOOL_CALLS\]\s*", re.IGNORECASE)


class MistralParser:
    """Parser for Mistral function calling format."""

    def parse(self, raw_text: str, tools: list[ToolDefinition]) -> list[ParsedToolCall]:
        text = strip_reasoning(raw_text)
        results: list[ParsedToolCall] = []

        # Remove [TOOL_CALLS] marker and find the JSON array
        marker_m = _TOOL_CALLS_MARKER.search(text)
        if marker_m:
            json_part = text[marker_m.end():]
        else:
            json_part = text

        # Try to parse as JSON array
        array_match = re.search(r"\[.*?\]", json_part, re.DOTALL)
        if array_match:
            try:
                items = json.loads(array_match.group())
                if isinstance(items, list):
                    for item in items:
                        trace = RepairTrace()
                        trace.attempt("mistral_array_item")
                        if isinstance(item, dict):
                            name = item.get("name") or item.get("function")
                            args = item.get("arguments") or item.get("parameters", {})
                            if name:
                                trace.success("mistral_array_item")
                                results.append(
                                    make_tool_call(str(name), normalize_arguments(args), trace)
                                )
            except json.JSONDecodeError:
                pass

        if not results:
            # Fallback: single JSON object
            trace = RepairTrace()
            parsed = try_parse_json(json_part, trace)
            if parsed:
                name = parsed.get("name") or parsed.get("function")
                args = parsed.get("arguments") or parsed.get("parameters", {})
                if name:
                    results.append(make_tool_call(str(name), normalize_arguments(args), trace))

        return results
