"""Hermes XML parser: <tool_call>...</tool_call> with JSON payload."""
from __future__ import annotations

import re

from codii.connection.base import ToolDefinition
from codii.parser.base import (
    ParsedToolCall,
    RepairTrace,
    make_tool_call,
    normalize_arguments,
    strip_reasoning,
    try_parse_json,
)

_OPEN_TAG = re.compile(r"<tool_call\s*>", re.IGNORECASE)
_CLOSE_TAG = re.compile(r"</tool_call\s*>", re.IGNORECASE)


class HermesParser:
    """Parser for Hermes-style XML tool calls."""

    def parse(self, raw_text: str, tools: list[ToolDefinition]) -> list[ParsedToolCall]:
        text = strip_reasoning(raw_text)
        results: list[ParsedToolCall] = []

        # Find all <tool_call>...</tool_call> blocks
        pos = 0
        while True:
            start_m = _OPEN_TAG.search(text, pos)
            if not start_m:
                break

            payload_start = start_m.end()
            end_m = _CLOSE_TAG.search(text, payload_start)

            if end_m:
                payload = text[payload_start : end_m.start()].strip()
                pos = end_m.end()
            else:
                # Missing closing tag — auto-close at next double newline or end
                next_para = text.find("\n\n", payload_start)
                end_pos = next_para if next_para != -1 else len(text)
                payload = text[payload_start:end_pos].strip()
                pos = end_pos

            tc = _parse_hermes_payload(payload)
            if tc:
                results.append(tc)

        return results


def _parse_hermes_payload(payload: str) -> ParsedToolCall | None:
    trace = RepairTrace()
    trace.attempt("hermes_payload_parse")

    # Strip to first/last brace if there's extra text
    brace_start = payload.find("{")
    brace_end = payload.rfind("}")
    if brace_start != -1 and brace_end != -1:
        payload = payload[brace_start : brace_end + 1]

    parsed = try_parse_json(payload, trace)
    if not parsed:
        return None

    name = parsed.get("name") or parsed.get("tool_name")
    args = parsed.get("arguments") or parsed.get("parameters", {})

    if not name:
        return None

    trace.success("hermes_payload_parse")
    return make_tool_call(str(name), normalize_arguments(args), trace)
