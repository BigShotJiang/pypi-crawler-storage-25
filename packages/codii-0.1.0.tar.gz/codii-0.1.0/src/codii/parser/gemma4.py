"""
Gemma 4 parser: six-token delimiter state machine for <|tool_call|> / <|tool_call>.

Handles both token variants (Flag 6) and common malformations:
  - Truncated closing delimiter
  - Doubly-encoded JSON
  - Arguments in wrong order
"""
from __future__ import annotations

import json
import re
from typing import Any

from codii.connection.base import ToolDefinition
from codii.parser.base import (
    ParsedToolCall,
    RepairTrace,
    make_tool_call,
    normalize_arguments,
    strip_reasoning,
    try_parse_json,
)

# Match <|tool_call|> or <|tool_call> (both Ollama variants)
_TOOL_CALL_START = re.compile(r"<\|tool_call\|?>")
_TOOL_CALL_END = re.compile(r"<\|tool_call_end\|?>|<\|/tool_call\|?>")


class Gemma4Parser:
    """Parser for Gemma 4's six-token delimiter tool call format."""

    def parse(self, raw_text: str, tools: list[ToolDefinition]) -> list[ParsedToolCall]:
        text = strip_reasoning(raw_text)
        results: list[ParsedToolCall] = []

        # Split on tool call start markers
        segments = _TOOL_CALL_START.split(text)

        for segment in segments[1:]:  # skip text before first marker
            trace = RepairTrace()
            trace.attempt("locate_gemma4_marker")

            # Find end marker (optional — truncated output may lack it)
            end_match = _TOOL_CALL_END.search(segment)
            payload = segment[: end_match.start()].strip() if end_match else segment.strip()

            parsed = _parse_gemma4_payload(payload, trace)
            if parsed:
                name, arguments = parsed
                trace.success("gemma4_parse")
                results.append(make_tool_call(name, arguments, trace))

        return results


def _parse_gemma4_payload(
    payload: str, trace: RepairTrace
) -> tuple[str, dict[str, Any]] | None:
    """Extract name and arguments from a Gemma 4 tool call payload."""
    trace.attempt("strict_parse")

    # Standard format: {"name": "...", "arguments": {...}}
    parsed = try_parse_json(payload, trace)
    if parsed:
        name = parsed.get("name") or parsed.get("function") or parsed.get("tool")
        args = parsed.get("arguments") or parsed.get("parameters") or parsed.get("args", {})
        if name:
            return str(name), normalize_arguments(args)

    # Double-encoded: {"name": "...", "arguments": "{\"key\": \"val\"}"}
    trace.attempt("double_encoded_repair")
    try:
        outer = json.loads(payload)
        if isinstance(outer, dict):
            name = outer.get("name") or outer.get("function")
            raw_args = outer.get("arguments") or outer.get("parameters", {})
            if name:
                return str(name), normalize_arguments(raw_args)
    except (json.JSONDecodeError, TypeError):
        pass

    # Bare function name on first line, JSON on next lines
    trace.attempt("line_split_repair")
    lines = [ln.strip() for ln in payload.splitlines() if ln.strip()]
    if lines:
        name = lines[0].strip('"\'')
        remaining = "\n".join(lines[1:])
        if remaining:
            args = try_parse_json(remaining, trace)
            if args is not None:
                return name, args
        else:
            return name, {}

    return None
