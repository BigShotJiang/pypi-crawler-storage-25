"""
Generic JSON parser with heavy repair.
Catchall for 'none', 'unknown', and prompt-engineered (anthropic_xml) tool calls.
Also handles <tool> / <invoke> XML from tier-2/3 prompt engineering.
"""
from __future__ import annotations

import json
import re
from typing import Any

from codii.connection.base import ToolDefinition
from codii.parser.base import (
    ParsedToolCall,
    RepairTrace,
    extract_json_from_fence,
    make_tool_call,
    normalize_arguments,
    strip_reasoning,
    try_extract_named_object,
    try_parse_json,
    try_semantic_repair,
)

# Anthropic-style XML — split into open/close pairs so truncated responses
# (missing </parameter> or </tool>) still parse correctly.
_TOOL_OPEN_RE = re.compile(r"<(?:tool|invoke)\s+name=['\"]([^'\"]+)['\"]>", re.DOTALL)
_TOOL_CLOSE_RE = re.compile(r"</(?:tool|invoke)>", re.DOTALL)
_PARAM_OPEN_RE = re.compile(r"<parameter\s+name=['\"]([^'\"]+)['\"]>", re.DOTALL)
_PARAM_CLOSE_RE = re.compile(r"</parameter>", re.DOTALL)
_TRAILING_TAG_RE = re.compile(r"\s*</[a-zA-Z_][a-zA-Z0-9_]*>\s*$")

# JSON object extraction
_JSON_OBJECT_RE = re.compile(r"\{[^{}]*(?:\{[^{}]*\}[^{}]*)?\}", re.DOTALL)

# Detects structural markers of a tool-call ATTEMPT (not just keywords).
# Prevents pure code blocks from being flagged as repair_failed.
_TOOL_ATTEMPT_RE = re.compile(
    r'<(?:tool|invoke)\s+name='          # XML: <tool name= or <invoke name=
    r'|"name"\s*:\s*"[a-z][a-z0-9_]+'   # JSON: "name": "snake_case_name"
    r'|```tool_code'                      # Gemma 3 tool_code block
)


class GenericParser:
    """
    Heavy-repair fallback parser.
    Tries multiple extraction strategies in order.
    """

    def parse(self, raw_text: str, tools: list[ToolDefinition]) -> list[ParsedToolCall]:
        text = strip_reasoning(raw_text)
        # Model sometimes writes ```tool name="..."> with backtick replacing the <
        text = re.sub(r"```((?:tool|invoke)\s+name=)", r"<\1", text)
        text = re.sub(r"(</(?:tool|invoke)>)\s*\n?```", r"\1", text)
        results: list[ParsedToolCall] = []

        # Strategy 1: Anthropic XML <tool name="...">
        xml_calls = _parse_anthropic_xml(text)
        if xml_calls:
            return xml_calls

        # Strategy 2: JSON from code fence
        trace = RepairTrace()
        fence_content = extract_json_from_fence(text)
        if fence_content:
            trace.attempt("json_fence_extract")
            parsed = try_parse_json(fence_content, trace)
            if parsed:
                tc = _dict_to_tool_call(parsed, trace)
                if tc:
                    return [tc]

        # Strategy 3: First JSON object in text
        for m in _JSON_OBJECT_RE.finditer(text):
            trace = RepairTrace()
            trace.attempt("json_object_scan")
            parsed = try_parse_json(m.group(), trace)
            if parsed:
                tc = _dict_to_tool_call(parsed, trace)
                if tc:
                    return [tc]

        # Strategy 4: tool_code markdown (Gemma 3)
        tc = _parse_tool_code(text)
        if tc:
            return [tc]

        # Strategy 5: extract any JSON object with a 'name' field matching a tool
        trace = RepairTrace()
        named = try_extract_named_object(text, trace)
        if named:
            tc2 = _dict_to_tool_call(named, trace)
            if tc2:
                return [tc2]

        # Strategy 6: semantic repair — fuzzy-match against known tool schemas
        # (50% confidence threshold prevents false positives from plain prose)
        trace = RepairTrace()
        semantic = try_semantic_repair(text, tools, trace)
        if semantic:
            tc3 = make_tool_call(
                semantic["name"],
                normalize_arguments(semantic.get("arguments", {})),
                trace,
            )
            return [tc3]

        # Only signal repair failure if text contained structural markers of a tool-call
        # ATTEMPT: XML <tool> tags, JSON "name": "snake_case", or tool_code fences.
        # Plain code blocks, prose, and Python output must NOT trigger this — they are
        # text responses, not failed tool attempts, and must not drive tier demotion.
        has_tool_signal = bool(_TOOL_ATTEMPT_RE.search(text))
        if has_tool_signal:
            failed_trace = RepairTrace()
            failed_trace.fail()
            return [ParsedToolCall(id="__repair_failed__", name="__repair_failed__", arguments={}, repair_trace=failed_trace)]

        return results


def _deduplicate_calls(calls: list[ParsedToolCall]) -> list[ParsedToolCall]:
    """Keep only the first call per (name, path) — drops repeated writes to the same file."""
    seen: set[tuple[str, str]] = set()
    out: list[ParsedToolCall] = []
    for call in calls:
        key = (call.name, call.arguments.get("path", ""))
        if key not in seen:
            seen.add(key)
            out.append(call)
    return out


def _parse_anthropic_xml(text: str) -> list[ParsedToolCall]:
    results: list[ParsedToolCall] = []
    for tool_m in _TOOL_OPEN_RE.finditer(text):
        name = tool_m.group(1)
        body_start = tool_m.end()

        # Find closing </tool>; fall back to next <tool> opening or end-of-text
        # so truncated responses (model cut off mid-content) still parse.
        close_m = _TOOL_CLOSE_RE.search(text, body_start)
        if close_m:
            body_end = close_m.start()
        else:
            next_tool = _TOOL_OPEN_RE.search(text, body_start)
            body_end = next_tool.start() if next_tool else len(text)
        body = text[body_start:body_end]

        arguments: dict[str, Any] = {}
        param_opens = list(_PARAM_OPEN_RE.finditer(body))
        for i, pm in enumerate(param_opens):
            pname = pm.group(1)
            val_start = pm.end()
            # Layer 1: standard </parameter> close tag
            close_pm = _PARAM_CLOSE_RE.search(body, val_start)
            # Layer 1b: model used </pname> instead of </parameter>
            if not close_pm:
                alt_re = re.compile(rf"</{re.escape(pname)}>", re.IGNORECASE)
                close_pm = alt_re.search(body, val_start)
            if close_pm:
                val_end = close_pm.start()
            elif i + 1 < len(param_opens):
                val_end = param_opens[i + 1].start()
            else:
                val_end = len(body)
            # Layer 2: strip any stray trailing close tag the model appended
            val = _TRAILING_TAG_RE.sub("", body[val_start:val_end].strip()).rstrip()
            arguments[pname] = val

        trace = RepairTrace()
        trace.success("anthropic_xml")
        results.append(make_tool_call(name, arguments, trace))
    return _deduplicate_calls(results)


def _dict_to_tool_call(data: dict[str, Any], trace: RepairTrace) -> ParsedToolCall | None:
    """Convert a parsed dict to a tool call, handling multiple field naming conventions."""
    # Standard
    name = data.get("name") or data.get("function") or data.get("tool_name")
    args = data.get("arguments") or data.get("parameters") or data.get("args", {})

    # Unwrap {"type":"function","function":{"name":...}}
    if not name and data.get("type") == "function" and "function" in data:
        fn = data["function"]
        name = fn.get("name")
        args = fn.get("arguments") or fn.get("parameters", {})

    if not name:
        return None

    trace.success("generic_dict_extract")
    return make_tool_call(str(name), normalize_arguments(args), trace)


def _parse_tool_code(text: str) -> ParsedToolCall | None:
    """Extract function calls from ```tool_code blocks (Gemma 3 style)."""
    m = re.search(r"```tool_code\s+(.*?)\s*```", text, re.DOTALL)
    if not m:
        return None

    code = m.group(1).strip()
    # Simple function call: name(args)
    call_m = re.match(r"(\w+)\s*\((.*?)\)\s*$", code, re.DOTALL)
    if not call_m:
        return None

    name = call_m.group(1)
    args_str = call_m.group(2).strip()

    # Try to parse args as JSON
    arguments: dict[str, Any] = {}
    if args_str:
        try:
            parsed = json.loads(f"{{{args_str}}}")
            arguments = parsed
        except json.JSONDecodeError:
            # Named args: key=value
            for kv in re.finditer(r'(\w+)\s*=\s*([^,]+)', args_str):
                k = kv.group(1)
                v = kv.group(2).strip().strip('"\'')
                arguments[k] = v

    trace = RepairTrace()
    trace.success("tool_code_extract")
    return make_tool_call(name, arguments, trace)
