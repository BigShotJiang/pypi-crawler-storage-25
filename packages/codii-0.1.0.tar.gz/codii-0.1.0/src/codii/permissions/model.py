"""Permission check combining band classification + auto-approvals."""
from __future__ import annotations

from pathlib import Path

from codii.permissions.approvals import is_auto_approved, load_approvals
from codii.tools.base import PermissionBand, classify_operation


def check_permission(
    operation: str,
    path: Path | None,
    workspace: Path,
) -> tuple[PermissionBand, bool]:
    """
    Returns (band, auto_approved).
    FORBIDDEN is never auto-approved.
    """
    band = classify_operation(operation, path, workspace)

    if band == PermissionBand.FORBIDDEN:
        return band, False

    if band == PermissionBand.FREE:
        return band, True

    # CONFIRMATION — check auto-approval rules
    rules = load_approvals(workspace)
    target = str(path) if path else operation
    if is_auto_approved(operation, target, rules):
        return band, True

    return band, False
