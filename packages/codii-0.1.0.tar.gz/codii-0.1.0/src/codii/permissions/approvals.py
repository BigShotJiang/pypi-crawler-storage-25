"""Load auto-approval rules from .codii/approvals.toml."""
from __future__ import annotations

import fnmatch
from pathlib import Path
from typing import Any

try:
    import tomllib
except ImportError:
    import tomli as tomllib  # type: ignore[no-redef]


def load_approvals(workspace: Path) -> list[dict[str, Any]]:
    """Load approval rules from .codii/approvals.toml. Returns [] if absent."""
    p = workspace / ".codii" / "approvals.toml"
    if not p.exists():
        return []
    try:
        data = tomllib.loads(p.read_text(encoding="utf-8"))
        rules: list[dict[str, Any]] = data.get("auto_approve", [])
        return rules
    except Exception:
        return []


def is_auto_approved(
    operation: str,
    target: str,
    rules: list[dict[str, Any]],
) -> bool:
    """Check whether an operation matches any auto-approval rule."""
    for rule in rules:
        rule_op = rule.get("operation", "*")
        rule_pattern = rule.get("pattern", "*")
        # Wildcard-operation rules apply to file path operations only.
        # Bash commands are not file paths; require explicit operation="bash".
        if operation == "bash" and rule_op == "*":
            continue
        if rule_op not in ("*", operation):
            continue
        if fnmatch.fnmatch(target, rule_pattern):
            return True
    return False
