"""Rich + prompt_toolkit integration. Called in alternation, never concurrently."""
from __future__ import annotations

import sys
from contextlib import contextmanager
from typing import TYPE_CHECKING, Generator

if TYPE_CHECKING:
    from pathlib import Path

# Lazy imports keep startup fast — these are only imported when the function is called.


@contextmanager
def ProbeSpinner(model_name: str) -> Generator[None, None, None]:
    from rich.console import Console
    from rich.live import Live
    from rich.spinner import Spinner
    from rich.text import Text

    console = Console()
    spinner = Spinner("dots", text=Text(f"Probing {model_name}... (this takes about 10 seconds)"))
    with Live(spinner, console=console, refresh_per_second=10):
        yield


async def ask_choice(prompt: str, options: list[str]) -> int:
    """
    Keyboard-navigable selection menu. Up/Down navigate, Enter confirms.
    Number keys 1-9 jump and confirm directly.
    Returns the 0-based index chosen. Returns 0 if options is empty.
    """
    if not options:
        return 0

    from prompt_toolkit import Application
    from prompt_toolkit.key_binding import KeyBindings as _KB
    from prompt_toolkit.layout import Layout
    from prompt_toolkit.layout.containers import Window
    from prompt_toolkit.layout.controls import FormattedTextControl
    from prompt_toolkit.formatted_text import HTML
    from rich.console import Console

    console = Console()
    console.print(f"\n[bold]{prompt}[/bold]\n")

    if not sys.stdout.isatty():
        # Non-TTY fallback (CI / pipe) — plain numbered prompt
        from prompt_toolkit.shortcuts import PromptSession
        for i, opt in enumerate(options, 1):
            console.print(f"  [cyan]{i}[/cyan]  {opt}")
        console.print()
        ps: PromptSession[str] = PromptSession()
        while True:
            try:
                raw = (await ps.prompt_async("Enter number: ")).strip()
                idx = int(raw) - 1
                if 0 <= idx < len(options):
                    return idx
            except (ValueError, KeyboardInterrupt, EOFError):
                return 0

    class _State:
        selected = 0

    state = _State()

    def _display():
        import html as _html
        lines = []
        for i, opt in enumerate(options):
            safe = _html.escape(opt)
            if i == state.selected:
                lines.append(f"<b><ansicyan>  ❯ {safe}</ansicyan></b>")
            else:
                lines.append(f"    <ansiwhite>{safe}</ansiwhite>")
        return HTML("\n".join(lines))

    kb = _KB()

    @kb.add("up")
    def _up(event):
        state.selected = (state.selected - 1) % len(options)
        event.app.invalidate()

    @kb.add("down")
    def _down(event):
        state.selected = (state.selected + 1) % len(options)
        event.app.invalidate()

    @kb.add("enter")
    def _confirm(event):
        event.app.exit()

    @kb.add("c-c")
    @kb.add("escape")
    def _cancel(event):
        state.selected = 0
        event.app.exit()

    def _make_jump(n: int) -> None:
        @kb.add(str(n))
        def _jump(event):
            if n - 1 < len(options):
                state.selected = n - 1
            event.app.exit()

    for _n in range(1, min(10, len(options) + 1)):
        _make_jump(_n)

    control = FormattedTextControl(_display, focusable=True)
    layout = Layout(Window(content=control), focused_element=control)
    app = Application(layout=layout, key_bindings=kb, full_screen=False)
    await app.run_async()
    console.print()
    return state.selected


async def ask_text(prompt: str, *, default: str = "") -> str:
    """Single-line prompt_toolkit input."""
    from prompt_toolkit.shortcuts import PromptSession
    from prompt_toolkit.formatted_text import HTML

    placeholder = f" [{default}]" if default else ""
    _ps: PromptSession[str] = PromptSession()
    result = (await _ps.prompt_async(HTML(f"<ansicyan>{prompt}{placeholder}: </ansicyan>"))).strip()
    return result if result else default


async def ask_password(prompt: str) -> str:
    """Masked single-line input — characters are replaced with bullets."""
    from prompt_toolkit.shortcuts import PromptSession
    from prompt_toolkit.formatted_text import HTML

    _ps: PromptSession[str] = PromptSession(is_password=True)
    return (await _ps.prompt_async(HTML(f"<ansicyan>{prompt}: </ansicyan>"))).strip()


async def confirm(prompt: str, *, default: bool = False) -> bool:
    """y/n confirmation prompt."""
    from prompt_toolkit.shortcuts import PromptSession
    from prompt_toolkit.formatted_text import HTML

    suffix = " [Y/n]" if default else " [y/N]"
    _ps: PromptSession[str] = PromptSession()
    while True:
        try:
            raw = (await _ps.prompt_async(HTML(f"<ansicyan>{prompt}{suffix}: </ansicyan>"))).strip().lower()
            if raw in ("y", "yes"):
                return True
            if raw in ("n", "no"):
                return False
            if raw == "":
                return default
        except (KeyboardInterrupt, EOFError):
            return False


def print_error(message: str, hint: str | None = None) -> None:
    """Print an error with optional hint using Rich."""
    from rich.console import Console
    console = Console(stderr=True)
    console.print(f"[red bold]Error:[/red bold] {message}")
    if hint:
        console.print(f"[yellow]Hint:[/yellow] {hint}")


def print_info(message: str) -> None:
    from rich.console import Console
    Console().print(f"[dim]{message}[/dim]")


def print_success(message: str) -> None:
    from rich.console import Console
    Console().print(f"[green]✓[/green] {message}")


def print_codii_mark(
    model: str | None = None,
    tier: int | None = None,
    workspace: "Path | None" = None,
) -> None:
    import rich.box
    from pathlib import Path

    from rich.console import Console
    from rich.panel import Panel
    from rich.text import Text
    from codii import __version__

    console = Console()
    console.print()

    meta_parts = [f"[bright_white]Version:[/bright_white] [bright_cyan]{__version__}[/bright_cyan]"]
    if model:
        meta_parts.append(f"[bright_white]Model:[/bright_white] [bright_yellow]{model}[/bright_yellow]")
    if tier is not None:
        meta_parts.append(f"[bright_white]Tier:[/bright_white] [bright_green]{tier}[/bright_green]")
    if workspace is not None:
        try:
            folder = "~/" + str(workspace.relative_to(Path.home()))
        except Exception:
            folder = str(workspace)
        meta_parts.append(f"[bright_white]Folder:[/bright_white] [bright_blue]{folder}[/bright_blue]")
    metadata = "  |  ".join(meta_parts)

    panel = Panel(
        Text("C  O  D  I  I", style="bold bright_cyan", justify="center"),
        subtitle=Text.from_markup(metadata, justify="center"),
        subtitle_align="center",
        border_style="bold bright_cyan",
        box=rich.box.ROUNDED,
        padding=(2, 50),
        expand=False,
    )
    console.print(panel, justify="center")
    console.print()