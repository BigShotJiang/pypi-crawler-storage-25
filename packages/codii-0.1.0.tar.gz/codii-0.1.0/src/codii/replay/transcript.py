"""Session transcript writer — records every event to JSONL for replay."""
from __future__ import annotations

import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


class TranscriptWriter:
    """Writes session events to transcript.jsonl.

    Every write is wrapped in try/except so a disk or IO error never crashes
    the session — transcripts are important but sessions are more important.
    """

    def __init__(self, session_dir: Path, fingerprint_summary: dict[str, Any], tier: int) -> None:
        self._seq = 1
        self._path = session_dir / "transcript.jsonl"
        try:
            self._file = self._path.open("a", encoding="utf-8", buffering=1)
        except (OSError, IOError) as e:
            print(f"[codii] could not open transcript file: {e}", file=sys.stderr)
            self._file = None  # type: ignore[assignment]

        # Write session header as first line
        self.write_event("session_header", {
            "fingerprint": fingerprint_summary,
            "tier": tier,
            "started_at": datetime.now(timezone.utc).isoformat(),
        })

    def write_event(self, event_type: str, payload: dict[str, Any]) -> None:
        if self._file is None:
            return
        try:
            record = {
                "seq": self._seq,
                "ts": datetime.now(timezone.utc).isoformat(),
                "type": event_type,
                "payload": payload,
            }
            self._seq += 1
            self._file.write(json.dumps(record) + "\n")
            self._file.flush()
        except (OSError, IOError) as e:
            print(f"[codii] transcript write failed: {e}", file=sys.stderr)

    def close(self) -> None:
        if self._file is not None:
            try:
                self._file.close()
            except (OSError, IOError):
                pass


def load_transcript(session_dir: Path) -> list[dict[str, Any]]:
    """Load all events from a session transcript. Handles partial files gracefully."""
    path = session_dir / "transcript.jsonl"
    if not path.exists():
        return []
    events: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                events.append(json.loads(line))
            except json.JSONDecodeError:
                break  # stop at first corrupt line (partial write)
    return events
