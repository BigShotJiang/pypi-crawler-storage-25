"""Tests for the 7 core tools."""
from __future__ import annotations

import pytest
from pathlib import Path

from codii.tools.read_file import ReadFileTool
from codii.tools.write_file import WriteFileTool
from codii.tools.edit_file import EditFileTool, apply_diff
from codii.tools.list_dir import ListDirTool
from codii.tools.bash import BashTool
from codii.tools.todo import TodoTool
from codii.tools.base import PermissionBand, classify_operation


# ── Fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture
def workspace(tmp_path: Path) -> Path:
    return tmp_path


# ── ReadFileTool ──────────────────────────────────────────────────────────────

class TestReadFileTool:
    @pytest.mark.asyncio
    async def test_reads_existing_file(self, workspace: Path):
        (workspace / "hello.txt").write_text("Hello World", encoding="utf-8")
        result = await ReadFileTool().execute({"path": "hello.txt"}, workspace)
        assert result.success
        assert "Hello World" in result.output

    @pytest.mark.asyncio
    async def test_missing_file(self, workspace: Path):
        result = await ReadFileTool().execute({"path": "nonexistent.txt"}, workspace)
        assert not result.success
        assert result.error is not None

    @pytest.mark.asyncio
    async def test_path_escape_blocked(self, workspace: Path):
        result = await ReadFileTool().execute({"path": "../../etc/passwd"}, workspace)
        assert not result.success


# ── WriteFileTool ─────────────────────────────────────────────────────────────

class TestWriteFileTool:
    @pytest.mark.asyncio
    async def test_creates_file(self, workspace: Path):
        result = await WriteFileTool().execute(
            {"path": "hello.py", "content": 'print("Hello World")\n'},
            workspace,
        )
        assert result.success
        assert (workspace / "hello.py").read_text() == 'print("Hello World")\n'

    @pytest.mark.asyncio
    async def test_overwrites_existing(self, workspace: Path):
        (workspace / "x.txt").write_text("old", encoding="utf-8")
        result = await WriteFileTool().execute({"path": "x.txt", "content": "new"}, workspace)
        assert result.success
        assert (workspace / "x.txt").read_text() == "new"

    @pytest.mark.asyncio
    async def test_creates_parent_dirs(self, workspace: Path):
        result = await WriteFileTool().execute(
            {"path": "a/b/c.txt", "content": "nested"},
            workspace,
        )
        assert result.success
        assert (workspace / "a" / "b" / "c.txt").exists()

    @pytest.mark.asyncio
    async def test_atomic_write(self, workspace: Path):
        """Verify no .tmp file remains after write."""
        await WriteFileTool().execute({"path": "out.txt", "content": "data"}, workspace)
        tmp_files = list(workspace.glob("*.tmp"))
        assert tmp_files == []

    @pytest.mark.asyncio
    async def test_path_escape_blocked(self, workspace: Path):
        result = await WriteFileTool().execute(
            {"path": "../outside.txt", "content": "x"},
            workspace,
        )
        assert not result.success

    @pytest.mark.asyncio
    async def test_literal_newlines_unescaped(self, workspace: Path):
        result = await WriteFileTool().execute(
            {"path": "poem.txt", "content": "line1\\nline2\\nline3"},
            workspace,
        )
        assert result.success
        assert (workspace / "poem.txt").read_text().splitlines() == ["line1", "line2", "line3"]


# ── apply_diff (unified diff applier) ────────────────────────────────────────

class TestApplyDiff:
    def test_simple_replacement(self):
        original = "line1\nline2\nline3\n"
        diff = "--- a/file\n+++ b/file\n@@ -2,1 +2,1 @@\n-line2\n+LINE2\n"
        result, err = apply_diff(original, diff)
        assert err is None
        assert "LINE2" in result
        assert "line2" not in result

    def test_addition(self):
        original = "line1\nline2\n"
        diff = "--- a/file\n+++ b/file\n@@ -2,1 +2,2 @@\n line2\n+line3\n"
        result, err = apply_diff(original, diff)
        assert err is None
        assert "line3" in result

    def test_deletion(self):
        original = "line1\nline2\nline3\n"
        diff = "--- a/file\n+++ b/file\n@@ -2,1 +2,0 @@\n-line2\n"
        result, err = apply_diff(original, diff)
        assert err is None
        assert "line2" not in result

    def test_mismatch_returns_error(self):
        original = "line1\nline2\nline3\n"
        diff = "--- a/file\n+++ b/file\n@@ -1,1 +1,1 @@\n-WRONG_LINE\n+newline\n"
        _, err = apply_diff(original, diff)
        assert err is not None
        assert "mismatch" in err.lower() or "Hunk" in err

    def test_no_hunks_returns_error(self):
        _, err = apply_diff("content\n", "--- a/file\n+++ b/file\n")
        assert err is not None


class TestEditFileTool:
    @pytest.mark.asyncio
    async def test_applies_valid_diff(self, workspace: Path):
        (workspace / "test.py").write_text("x = 1\n", encoding="utf-8")
        diff = "--- test.py\n+++ test.py\n@@ -1,1 +1,1 @@\n-x = 1\n+x = 2\n"
        result = await EditFileTool().execute({"path": "test.py", "diff": diff}, workspace)
        assert result.success
        assert (workspace / "test.py").read_text() == "x = 2\n"

    @pytest.mark.asyncio
    async def test_rejects_invalid_diff(self, workspace: Path):
        (workspace / "test.py").write_text("x = 1\n", encoding="utf-8")
        diff = "--- test.py\n+++ test.py\n@@ -1,1 +1,1 @@\n-WRONG\n+x = 2\n"
        result = await EditFileTool().execute({"path": "test.py", "diff": diff}, workspace)
        assert not result.success
        assert result.error is not None

    @pytest.mark.asyncio
    async def test_missing_file(self, workspace: Path):
        diff = "--- a\n+++ b\n@@ -1,1 +1,1 @@\n-x\n+y\n"
        result = await EditFileTool().execute({"path": "missing.py", "diff": diff}, workspace)
        assert not result.success

    @pytest.mark.asyncio
    async def test_fake_diff_single_plus_auto_appends(self, workspace: Path):
        """Single + line with no context and no - → auto-append."""
        (workspace / "poem.txt").write_text("line1\nline2\n", encoding="utf-8")
        diff = "@@ -1,2 +1,3 @@\n+line3\n"
        result = await EditFileTool().execute({"path": "poem.txt", "diff": diff}, workspace)
        assert result.success
        assert (workspace / "poem.txt").read_text() == "line1\nline2\nline3\n"

    @pytest.mark.asyncio
    async def test_fake_diff_multi_plus_returns_correction(self, workspace: Path):
        """Multiple + lines with no context and no - → corrective error message."""
        (workspace / "poem.txt").write_text("line1\nline2\n", encoding="utf-8")
        diff = "@@ -1,2 +1,4 @@\n+line3\n+line4\n"
        result = await EditFileTool().execute({"path": "poem.txt", "diff": diff}, workspace)
        assert not result.success
        assert result.error is not None
        assert "context lines" in (result.error or "").lower() or "incorrect" in (result.error or "").lower()

    @pytest.mark.asyncio
    async def test_escaped_diff_unescaped(self, workspace: Path):
        (workspace / "f.txt").write_text("hello\nworld\n", encoding="utf-8")
        diff = "--- f.txt\\n+++ f.txt\\n@@ -1,2 +1,2 @@\\n hello\\n-world\\n+earth\\n"
        result = await EditFileTool().execute({"path": "f.txt", "diff": diff}, workspace)
        assert result.success
        assert (workspace / "f.txt").read_text() == "hello\nearth\n"


# ── ListDirTool ───────────────────────────────────────────────────────────────

class TestListDirTool:
    @pytest.mark.asyncio
    async def test_lists_files(self, workspace: Path):
        (workspace / "a.py").touch()
        (workspace / "b.py").touch()
        result = await ListDirTool().execute({"path": "."}, workspace)
        assert result.success
        assert "a.py" in result.output
        assert "b.py" in result.output

    @pytest.mark.asyncio
    async def test_skips_hidden_dirs(self, workspace: Path):
        (workspace / "__pycache__").mkdir()
        (workspace / "__pycache__" / "x.pyc").touch()
        result = await ListDirTool().execute({"path": "."}, workspace)
        assert "__pycache__" not in result.output

    @pytest.mark.asyncio
    async def test_empty_directory(self, workspace: Path):
        result = await ListDirTool().execute({"path": "."}, workspace)
        assert result.success
        assert "empty" in result.output.lower()


# ── BashTool ──────────────────────────────────────────────────────────────────

class TestBashTool:
    @pytest.mark.asyncio
    async def test_echo_command(self, workspace: Path):
        result = await BashTool().execute({"command": "echo hello"}, workspace)
        assert result.success
        assert "hello" in result.output

    @pytest.mark.asyncio
    async def test_exit_code_nonzero(self, workspace: Path):
        result = await BashTool().execute({"command": "exit 1"}, workspace)
        assert not result.success
        assert result.error is not None

    @pytest.mark.asyncio
    async def test_timeout(self, workspace: Path):
        import sys
        # ping -n 6 sends 6 ICMP packets (~5s); sleep 5 on POSIX
        sleep_cmd = "ping -n 6 127.0.0.1" if sys.platform == "win32" else "sleep 5"
        result = await BashTool().execute({"command": sleep_cmd, "timeout": 1}, workspace)
        assert not result.success
        assert "timed out" in (result.error or "").lower()


# ── TodoTool ──────────────────────────────────────────────────────────────────

class TestTodoTool:
    @pytest.mark.asyncio
    async def test_add_and_list(self, workspace: Path):
        tool = TodoTool()
        add_result = await tool.execute({"operation": "add", "description": "write tests"}, workspace)
        assert add_result.success

        list_result = await tool.execute({"operation": "list"}, workspace)
        assert list_result.success
        assert "write tests" in list_result.output

    @pytest.mark.asyncio
    async def test_complete_todo(self, workspace: Path):
        tool = TodoTool()
        await tool.execute({"operation": "add", "description": "task A"}, workspace)
        list_result = await tool.execute({"operation": "list"}, workspace)
        # extract id from output
        todo_id = list_result.output.split("—")[0].split()[-1].strip()

        complete_result = await tool.execute({"operation": "complete", "id": todo_id}, workspace)
        assert complete_result.success

    @pytest.mark.asyncio
    async def test_empty_list(self, workspace: Path):
        result = await TodoTool().execute({"operation": "list"}, workspace)
        assert result.success
        assert "No todos" in result.output


# ── classify_operation ────────────────────────────────────────────────────────

class TestClassifyOperation:
    def test_read_is_free(self, workspace: Path):
        band = classify_operation("read", workspace / "file.py", workspace)
        assert band == PermissionBand.FREE

    def test_write_is_free(self, workspace: Path):
        band = classify_operation("write", workspace / "file.py", workspace)
        assert band == PermissionBand.FREE

    def test_delete_is_confirmation(self, workspace: Path):
        band = classify_operation("delete", workspace / "file.py", workspace)
        assert band == PermissionBand.CONFIRMATION

    def test_bash_is_confirmation(self, workspace: Path):
        band = classify_operation("bash", None, workspace)
        assert band == PermissionBand.CONFIRMATION

    def test_escape_is_forbidden(self, workspace: Path):
        outside = workspace.parent / "outside.txt"
        band = classify_operation("read", outside, workspace)
        assert band == PermissionBand.FORBIDDEN
