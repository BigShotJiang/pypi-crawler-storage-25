"""Tests for scaffolding selector and schema."""
from __future__ import annotations

import pytest

from codii.scaffolding.selector import select_scaffolding
from codii.scaffolding.schema import ScaffoldingConfig


def _make_fp(tier: int, family: str = "gemma4", tool_format: str = "gemma4_tokens", native: bool = True):
    """Create a minimal CapabilityFingerprint for testing."""
    from datetime import datetime, timezone
    from codii.fingerprint.schema import (
        CapabilityFingerprint, Capabilities, ReasoningSupport
    )
    caps = Capabilities(
        family=family,
        tool_call_format=tool_format,
        native_tool_calling=native,
        effective_context_tokens=32000,
        claimed_context_tokens=32000,
        reasoning_support=ReasoningSupport(supported=False),
        structured_output_reliability=0.95,
        instruction_following_reliability=0.95,
        tier=tier,
        tier_rationale="test",
    )
    now = datetime.now(timezone.utc)
    return CapabilityFingerprint(
        created_at=now,
        updated_at=now,
        backend="ollama",
        endpoint="http://localhost:11434",
        model="gemma4:27b",
        quant_hash="abcd1234",
        capabilities=caps,
    )


class TestScaffoldingSelector:
    def test_tier1_config(self):
        fp = _make_fp(tier=1, family="llama", tool_format="openai_json")
        cfg = select_scaffolding(fp, backend="vllm")
        assert cfg.tier == 1
        assert cfg.tool_format == "native_json"
        assert cfg.max_tools_exposed is None
        assert cfg.few_shot_examples is False
        assert cfg.parser_key == "openai_json"

    def test_tier2_config(self):
        fp = _make_fp(tier=2, family="llama", tool_format="hermes_xml")
        cfg = select_scaffolding(fp, backend="vllm")
        assert cfg.tier == 2
        assert cfg.tool_format == "xml_fenced"
        assert cfg.max_tools_exposed == 7
        assert cfg.few_shot_examples is True

    def test_tier3_config(self):
        fp = _make_fp(tier=3, family="other", tool_format="none")
        cfg = select_scaffolding(fp, backend="ollama")
        assert cfg.tier == 3
        assert cfg.tool_format == "prompt_engineered"
        assert cfg.max_tools_exposed == 3
        assert cfg.parser_key == "generic"

    def test_flag5_ollama_gemma4_override(self):
        """Flag 5: Ollama + Gemma4 must force prompt_engineered regardless of tier."""
        fp = _make_fp(tier=1, family="gemma4", tool_format="gemma4_tokens", native=True)
        cfg = select_scaffolding(fp, backend="ollama")
        # Even though tier=1 and native=True, Ollama+Gemma4 forces prompt_engineered
        assert cfg.tool_format == "prompt_engineered"
        assert cfg.parser_key == "generic"

    def test_flag5_not_applied_for_non_ollama(self):
        """Flag 5 does not apply when backend is not ollama."""
        fp = _make_fp(tier=1, family="gemma4", tool_format="gemma4_tokens", native=True)
        cfg = select_scaffolding(fp, backend="vllm")
        assert cfg.tool_format == "native_json"
        assert cfg.parser_key == "gemma4_tokens"

    def test_flag5_not_applied_for_non_gemma4(self):
        """Flag 5 does not apply for non-gemma4 families on Ollama."""
        fp = _make_fp(tier=1, family="llama", tool_format="openai_json", native=True)
        cfg = select_scaffolding(fp, backend="ollama")
        assert cfg.tool_format == "native_json"

    def test_templates_loaded(self):
        """System prompt templates must be non-empty strings."""
        for tier in (1, 2, 3):
            family = "llama" if tier < 3 else "other"
            tool_format = "openai_json" if tier < 3 else "none"
            fp = _make_fp(tier=tier, family=family, tool_format=tool_format)
            cfg = select_scaffolding(fp, backend="vllm")
            assert isinstance(cfg.system_prompt_template, str)
            assert len(cfg.system_prompt_template) > 50

    def test_scaffolding_config_is_pydantic(self):
        fp = _make_fp(tier=1, family="llama", tool_format="openai_json")
        cfg = select_scaffolding(fp, backend="vllm")
        assert isinstance(cfg, ScaffoldingConfig)
        # Verify pydantic validation
        d = cfg.model_dump()
        assert "tier" in d
        assert "tool_format" in d
