"""Tests for the Anthropic Messages API shim (src/codii/serve/app.py)."""
from __future__ import annotations

import json

import pytest
from fastapi.testclient import TestClient

from codii.connection.base import Done, TextChunk, ToolCall
from codii.serve.app import create_app
from tests.conftest import MockAdapter


@pytest.fixture
def adapter() -> MockAdapter:
    return MockAdapter()


@pytest.fixture
def client(adapter: MockAdapter) -> TestClient:
    app = create_app(adapter)
    return TestClient(app)


def test_minimal_request(client: TestClient, adapter: MockAdapter) -> None:
    """Non-streaming request returns valid Anthropic-format response."""
    adapter.queue_text("Hello from local model!")

    resp = client.post(
        "/v1/messages",
        json={
            "model": "mock-model",
            "messages": [{"role": "user", "content": "Hi"}],
            "max_tokens": 256,
        },
    )
    assert resp.status_code == 200
    body = resp.json()
    assert body["type"] == "message"
    assert body["role"] == "assistant"
    assert body["stop_reason"] == "end_turn"
    assert isinstance(body["content"], list)
    assert body["content"][0]["type"] == "text"
    assert body["content"][0]["text"] == "Hello from local model!"
    assert "input_tokens" in body["usage"]
    assert "output_tokens" in body["usage"]


def test_streaming_sse(client: TestClient, adapter: MockAdapter) -> None:
    """Streaming request returns SSE lines with correct event types."""
    adapter.queue_text("Streamed response here.")

    resp = client.post(
        "/v1/messages",
        json={
            "model": "mock-model",
            "messages": [{"role": "user", "content": "Stream test"}],
            "stream": True,
        },
    )
    assert resp.status_code == 200
    assert "text/event-stream" in resp.headers["content-type"]

    lines = resp.text.splitlines()
    data_lines = [l for l in lines if l.startswith("data: ")]
    event_types = [json.loads(l[len("data: "):])["type"] for l in data_lines]

    assert "message_start" in event_types
    assert "content_block_start" in event_types
    assert "content_block_delta" in event_types
    assert "content_block_stop" in event_types
    assert "message_stop" in event_types

    # Verify the delta contains the streamed text
    deltas = [
        json.loads(l[len("data: "):])
        for l in data_lines
        if json.loads(l[len("data: "):])["type"] == "content_block_delta"
    ]
    text_content = "".join(d["delta"]["text"] for d in deltas)
    assert text_content == "Streamed response here."


def test_tool_use_response(client: TestClient, adapter: MockAdapter) -> None:
    """Response with tool call is formatted as tool_use block per Anthropic spec."""
    adapter.queue_tool_call(
        name="read_file",
        arguments={"path": "src/main.py"},
    )

    resp = client.post(
        "/v1/messages",
        json={
            "model": "mock-model",
            "messages": [{"role": "user", "content": "Read main.py"}],
            "tools": [
                {
                    "name": "read_file",
                    "description": "Read a file",
                    "input_schema": {
                        "type": "object",
                        "properties": {"path": {"type": "string"}},
                        "required": ["path"],
                    },
                }
            ],
        },
    )
    assert resp.status_code == 200
    body = resp.json()
    assert body["stop_reason"] == "tool_use"
    tool_blocks = [b for b in body["content"] if b["type"] == "tool_use"]
    assert len(tool_blocks) == 1
    block = tool_blocks[0]
    assert block["name"] == "read_file"
    assert block["input"] == {"path": "src/main.py"}
    assert "id" in block


def test_auth_required(adapter: MockAdapter) -> None:
    """Request without API key is rejected when auth is configured."""
    app = create_app(adapter, require_auth="secret-token")
    authed_client = TestClient(app, raise_server_exceptions=False)

    resp = authed_client.post(
        "/v1/messages",
        json={"model": "x", "messages": [{"role": "user", "content": "hi"}]},
    )
    assert resp.status_code == 401

    adapter.queue_text("ok")
    resp = authed_client.post(
        "/v1/messages",
        json={"model": "x", "messages": [{"role": "user", "content": "hi"}]},
        headers={"x-api-key": "secret-token"},
    )
    assert resp.status_code == 200
