"""Shared test fixtures."""
from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pytest

from codii.connection.base import (
    BackendAdapter,
    Done,
    RequestMessage,
    ResponseEvent,
    TextChunk,
    ToolCall,
    ToolDefinition,
)
from codii.fingerprint.schema import (
    Capabilities,
    CapabilityFingerprint,
    ReasoningSupport,
)


class MockAdapter(BackendAdapter):
    """
    BackendAdapter that yields pre-configured response sequences.
    Call queue_response([events]) before each expected request.
    """

    def __init__(self, endpoint: str = "http://mock", model: str = "mock-model") -> None:
        super().__init__(endpoint=endpoint, model=model)
        self._responses: list[list[ResponseEvent]] = []
        self._call_count = 0

    def queue_response(self, events: list[ResponseEvent]) -> None:
        self._responses.append(events)

    def queue_text(self, text: str, stop_reason: str = "stop") -> None:
        self.queue_response([TextChunk(text=text), Done(stop_reason=stop_reason)])

    def queue_tool_call(
        self, name: str, arguments: dict, stop_reason: str = "tool_calls"
    ) -> None:
        import uuid
        self.queue_response([
            ToolCall(id=str(uuid.uuid4()), name=name, arguments=arguments),
            Done(stop_reason=stop_reason),
        ])

    async def health_check(self) -> bool:
        return True

    async def list_models(self) -> list[str]:
        return [self.model]

    async def send_request(
        self,
        messages: list[RequestMessage],
        tools: list[ToolDefinition] | None = None,
        stream: bool = True,
    ) -> AsyncIterator[ResponseEvent]:
        self._call_count += 1
        if not self._responses:
            raise RuntimeError(
                f"MockAdapter has no queued responses (call #{self._call_count})"
            )
        events = self._responses.pop(0)
        for event in events:
            yield event


@pytest.fixture
def mock_adapter() -> MockAdapter:
    return MockAdapter()


@pytest.fixture
def tmp_codii_dir(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Redirect ~/.codii to a tmp dir for tests."""
    codii_dir = tmp_path / ".codii"
    for sub in ("fingerprints", "sessions", "agents"):
        (codii_dir / sub).mkdir(parents=True)

    monkeypatch.setattr("codii.config.config_dir", lambda: codii_dir)
    monkeypatch.setattr("codii.fingerprint.store.config_dir", lambda: codii_dir)
    return codii_dir


@pytest.fixture
def sample_fingerprint() -> CapabilityFingerprint:
    """A valid Gemma 4 tier-1 fingerprint for testing."""
    now = datetime.now(timezone.utc)
    return CapabilityFingerprint(
        schema_version=1,
        created_at=now,
        updated_at=now,
        backend="ollama",
        endpoint="http://localhost:11434",
        model="gemma4:27b",
        quant_hash="abc12345",
        capabilities=Capabilities(
            family="gemma4",
            tool_call_format="gemma4_tokens",
            native_tool_calling=True,
            effective_context_tokens=28800,
            claimed_context_tokens=131072,
            reasoning_support=ReasoningSupport(supported=True, delimiter="<think>"),
            structured_output_reliability=0.98,
            instruction_following_reliability=0.98,
            tier=1,
            tier_rationale=(
                "Native tool calling in gemma4_tokens format, effective context 28k, "
                "scored 0.98 on structured output — Tier 1"
            ),
        ),
        probe_trace={},
        user_overrides={},
    )
