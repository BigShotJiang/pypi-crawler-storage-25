"""Tests for the connection layer adapters."""
from __future__ import annotations

import json
import uuid
from unittest.mock import AsyncMock, MagicMock

import httpx
import pytest
import respx

from codii.connection.base import Done, TextChunk, ToolCall, collect_response, RequestMessage
from codii.connection.ollama import OllamaAdapter
from codii.connection.lmstudio import LMStudioAdapter
from codii.connection.vllm import VllmAdapter
from codii.connection.openai_compat import GenericOpenAIAdapter
from codii.errors import ConnectionError as CodiiConnectionError


# ── Ollama ─────────────────────────────────────────────────────────────────────

@respx.mock
async def test_ollama_health_check_ok():
    respx.get("http://localhost:11434/api/tags").mock(
        return_value=httpx.Response(200, json={"models": []})
    )
    adapter = OllamaAdapter()
    assert await adapter.health_check() is True


@respx.mock
async def test_ollama_health_check_connection_refused():
    respx.get("http://localhost:11434/api/tags").mock(
        side_effect=httpx.ConnectError("refused")
    )
    adapter = OllamaAdapter()
    assert await adapter.health_check() is False


@respx.mock
async def test_ollama_list_models():
    respx.get("http://localhost:11434/api/tags").mock(
        return_value=httpx.Response(200, json={
            "models": [{"name": "gemma4:27b"}, {"name": "llama3:8b"}]
        })
    )
    adapter = OllamaAdapter()
    models = await adapter.list_models()
    assert models == ["gemma4:27b", "llama3:8b"]


@respx.mock
async def test_ollama_text_response():
    respx.post("http://localhost:11434/api/chat").mock(
        return_value=httpx.Response(200, json={
            "model": "gemma4:27b",
            "message": {"role": "assistant", "content": "Hello, world!"},
            "done": True,
            "done_reason": "stop",
        })
    )
    adapter = OllamaAdapter(model="gemma4:27b")
    text, tool_calls, done = await collect_response(
        adapter, [RequestMessage(role="user", content="Hi")]
    )
    assert text == "Hello, world!"
    assert tool_calls == []
    assert done.stop_reason == "stop"


@respx.mock
async def test_ollama_tool_call_response():
    respx.post("http://localhost:11434/api/chat").mock(
        return_value=httpx.Response(200, json={
            "model": "gemma4:27b",
            "message": {
                "role": "assistant",
                "content": "",
                "tool_calls": [
                    {"function": {"name": "get_time", "arguments": {}}}
                ],
            },
            "done": True,
            "done_reason": "tool_calls",
        })
    )
    adapter = OllamaAdapter(model="gemma4:27b")
    text, tool_calls, done = await collect_response(
        adapter, [RequestMessage(role="user", content="What time is it?")]
    )
    assert len(tool_calls) == 1
    assert tool_calls[0].name == "get_time"
    assert done.stop_reason == "tool_calls"


@respx.mock
async def test_ollama_connect_error_raises():
    respx.post("http://localhost:11434/api/chat").mock(
        side_effect=httpx.ConnectError("refused")
    )
    adapter = OllamaAdapter(model="gemma4:27b")
    with pytest.raises(CodiiConnectionError):
        async for _ in adapter.send_request([RequestMessage(role="user", content="Hi")]):
            pass


# ── LM Studio ──────────────────────────────────────────────────────────────────

@respx.mock
async def test_lmstudio_health_check_ok():
    respx.get("http://localhost:1234/v1/models").mock(
        return_value=httpx.Response(200, json={"data": []})
    )
    adapter = LMStudioAdapter()
    assert await adapter.health_check() is True


@respx.mock
async def test_lmstudio_list_models():
    respx.get("http://localhost:1234/v1/models").mock(
        return_value=httpx.Response(200, json={
            "data": [{"id": "gemma3-12b"}, {"id": "qwen2.5-14b"}]
        })
    )
    adapter = LMStudioAdapter()
    models = await adapter.list_models()
    assert models == ["gemma3-12b", "qwen2.5-14b"]


@respx.mock
async def test_lmstudio_non_streaming_text():
    respx.post("http://localhost:1234/v1/chat/completions").mock(
        return_value=httpx.Response(200, json={
            "choices": [{"message": {"content": "Hello!"}, "finish_reason": "stop"}],
            "usage": {"prompt_tokens": 10, "completion_tokens": 5},
        })
    )
    adapter = LMStudioAdapter(model="gemma3-12b")
    text, tool_calls, done = await collect_response(
        adapter, [RequestMessage(role="user", content="Hi")]
    )
    assert text == "Hello!"
    assert done.stop_reason == "stop"


# ── vLLM ───────────────────────────────────────────────────────────────────────

@respx.mock
async def test_vllm_health_check_ok():
    respx.get("http://localhost:8000/health").mock(
        return_value=httpx.Response(200)
    )
    adapter = VllmAdapter(endpoint="http://localhost:8000", model="gemma4")
    assert await adapter.health_check() is True


@respx.mock
async def test_vllm_health_check_down():
    respx.get("http://localhost:8000/health").mock(
        side_effect=httpx.ConnectError("refused")
    )
    adapter = VllmAdapter(endpoint="http://localhost:8000", model="gemma4")
    assert await adapter.health_check() is False


# ── GenericOpenAIAdapter ───────────────────────────────────────────────────────

@respx.mock
async def test_generic_health_check_ok():
    respx.get("http://example.com/v1/models").mock(
        return_value=httpx.Response(200, json={"data": []})
    )
    adapter = GenericOpenAIAdapter(endpoint="http://example.com", model="test")
    assert await adapter.health_check() is True


@respx.mock
async def test_generic_non_streaming_with_tool_call():
    call_id = str(uuid.uuid4())
    respx.post("http://example.com/v1/chat/completions").mock(
        return_value=httpx.Response(200, json={
            "choices": [{
                "message": {
                    "content": None,
                    "tool_calls": [{
                        "id": call_id,
                        "type": "function",
                        "function": {"name": "get_time", "arguments": "{}"},
                    }],
                },
                "finish_reason": "tool_calls",
            }],
        })
    )
    adapter = GenericOpenAIAdapter(endpoint="http://example.com", model="test")
    text, tool_calls, done = await collect_response(
        adapter, [RequestMessage(role="user", content="time?")]
    )
    assert len(tool_calls) == 1
    assert tool_calls[0].name == "get_time"
    assert tool_calls[0].arguments == {}


# ── Argument normalisation ─────────────────────────────────────────────────────

def test_parse_arguments_dict():
    result = OllamaAdapter._parse_arguments({"key": "val"})
    assert result == {"key": "val"}


def test_parse_arguments_string():
    result = OllamaAdapter._parse_arguments('{"key": "val"}')
    assert result == {"key": "val"}


def test_parse_arguments_invalid_returns_empty():
    result = OllamaAdapter._parse_arguments("not json")
    assert result == {}
