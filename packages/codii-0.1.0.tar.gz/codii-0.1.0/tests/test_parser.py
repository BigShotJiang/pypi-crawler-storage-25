"""Tests for the wire-level parser layer."""
from __future__ import annotations

import pytest

from codii.parser.dispatch import get_parser
from codii.parser.gemma4 import Gemma4Parser
from codii.parser.generic import GenericParser
from codii.parser.hermes import HermesParser
from codii.parser.mistral import MistralParser
from codii.parser.qwen import QwenParser
from codii.parser.base import strip_reasoning, try_parse_json, RepairTrace


# ── dispatch ──────────────────────────────────────────────────────────────────

class TestDispatch:
    def test_gemma4_tokens(self):
        assert isinstance(get_parser("gemma4_tokens"), Gemma4Parser)

    def test_hermes_xml(self):
        assert isinstance(get_parser("hermes_xml"), HermesParser)

    def test_qwen_json(self):
        assert isinstance(get_parser("qwen_json"), QwenParser)

    def test_mistral_json(self):
        assert isinstance(get_parser("mistral_json"), MistralParser)

    def test_openai_json(self):
        assert isinstance(get_parser("openai_json"), GenericParser)

    def test_none_format(self):
        assert isinstance(get_parser("none"), GenericParser)

    def test_unknown_format(self):
        assert isinstance(get_parser("anything_else"), GenericParser)


# ── strip_reasoning ──────────────────────────────────────────────────────────

class TestStripReasoning:
    def test_strips_think_block(self):
        text = "<think>internal stuff</think>\nActual output"
        assert "internal" not in strip_reasoning(text)
        assert "Actual output" in strip_reasoning(text)

    def test_strips_thinking_block(self):
        text = "<thinking>private</thinking>Response"
        result = strip_reasoning(text)
        assert "private" not in result
        assert "Response" in result

    def test_no_reasoning_unchanged(self):
        text = '{"name": "foo", "arguments": {}}'
        assert strip_reasoning(text) == text


# ── try_parse_json ────────────────────────────────────────────────────────────

class TestTryParseJson:
    def test_strict_parse(self):
        trace = RepairTrace()
        result = try_parse_json('{"name": "foo"}', trace)
        assert result == {"name": "foo"}

    def test_trailing_comma_repair(self):
        trace = RepairTrace()
        result = try_parse_json('{"name": "foo",}', trace)
        assert result == {"name": "foo"}

    def test_single_quotes_repair(self):
        trace = RepairTrace()
        result = try_parse_json("{'name': 'foo'}", trace)
        assert result is not None
        assert result["name"] == "foo"

    def test_empty_string(self):
        trace = RepairTrace()
        assert try_parse_json("", trace) is None


# ── Gemma4Parser ──────────────────────────────────────────────────────────────

class TestGemma4Parser:
    def _parse(self, text: str):
        return Gemma4Parser().parse(text, [])

    def test_standard_pipe_variant(self):
        text = '<|tool_call|>{"name": "read_file", "arguments": {"path": "src/main.py"}}<|tool_call_end|>'
        calls = self._parse(text)
        assert len(calls) == 1
        assert calls[0].name == "read_file"
        assert calls[0].arguments["path"] == "src/main.py"

    def test_no_pipe_variant(self):
        text = '<|tool_call>{"name": "bash", "arguments": {"command": "ls"}}<|tool_call_end>'
        calls = self._parse(text)
        assert len(calls) == 1
        assert calls[0].name == "bash"

    def test_truncated_closing_delimiter(self):
        text = '<|tool_call|>{"name": "list_dir", "arguments": {"path": "."}}'
        calls = self._parse(text)
        assert len(calls) == 1
        assert calls[0].name == "list_dir"

    def test_double_encoded_json(self):
        import json
        inner = json.dumps({"path": "foo.py"})
        payload = json.dumps({"name": "read_file", "arguments": inner})
        text = f"<|tool_call|>{payload}<|tool_call_end|>"
        calls = self._parse(text)
        assert len(calls) == 1
        assert calls[0].name == "read_file"

    def test_no_marker_returns_empty(self):
        assert self._parse("Hello world") == []


# ── HermesParser ─────────────────────────────────────────────────────────────

class TestHermesParser:
    def _parse(self, text: str):
        return HermesParser().parse(text, [])

    def test_standard_tool_call(self):
        text = '<tool_call>{"name": "write_file", "arguments": {"path": "a.py", "content": "x"}}</tool_call>'
        calls = self._parse(text)
        assert len(calls) == 1
        assert calls[0].name == "write_file"
        assert calls[0].arguments["path"] == "a.py"

    def test_missing_closing_tag(self):
        text = '<tool_call>{"name": "bash", "arguments": {"command": "pwd"}}\n\nsome other text'
        calls = self._parse(text)
        assert len(calls) == 1
        assert calls[0].name == "bash"

    def test_extra_text_inside_tag(self):
        text = '<tool_call>\n\nHere is the call: {"name": "list_dir", "arguments": {"path": "."}}</tool_call>'
        calls = self._parse(text)
        assert len(calls) == 1
        assert calls[0].name == "list_dir"

    def test_multiple_tool_calls(self):
        text = (
            '<tool_call>{"name": "read_file", "arguments": {"path": "a.py"}}</tool_call>'
            '<tool_call>{"name": "read_file", "arguments": {"path": "b.py"}}</tool_call>'
        )
        calls = self._parse(text)
        assert len(calls) == 2


# ── QwenParser ────────────────────────────────────────────────────────────────

class TestQwenParser:
    def _parse(self, text: str):
        return QwenParser().parse(text, [])

    def test_type_function_wrapper(self):
        text = '{"type": "function", "function": {"name": "bash", "arguments": {"command": "ls"}}}'
        calls = self._parse(text)
        assert len(calls) == 1
        assert calls[0].name == "bash"

    def test_plain_name_arguments(self):
        text = '{"name": "read_file", "arguments": {"path": "x.py"}}'
        calls = self._parse(text)
        assert len(calls) == 1
        assert calls[0].name == "read_file"

    def test_list_of_calls(self):
        text = '[{"name": "read_file", "arguments": {"path": "a.py"}}, {"name": "bash", "arguments": {"command": "pwd"}}]'
        calls = self._parse(text)
        assert len(calls) == 2


# ── MistralParser ─────────────────────────────────────────────────────────────

class TestMistralParser:
    def _parse(self, text: str):
        return MistralParser().parse(text, [])

    def test_tool_calls_marker(self):
        text = '[TOOL_CALLS] [{"name": "bash", "arguments": {"command": "echo hi"}}]'
        calls = self._parse(text)
        assert len(calls) == 1
        assert calls[0].name == "bash"

    def test_without_marker(self):
        text = '[{"name": "read_file", "arguments": {"path": "x.py"}}]'
        calls = self._parse(text)
        assert len(calls) == 1

    def test_single_object_fallback(self):
        text = '{"name": "list_dir", "arguments": {"path": "."}}'
        calls = self._parse(text)
        assert len(calls) == 1


# ── GenericParser ─────────────────────────────────────────────────────────────

class TestGenericParser:
    def _parse(self, text: str):
        return GenericParser().parse(text, [])

    def test_anthropic_xml_tool(self):
        text = '<tool name="read_file"><parameter name="path">src/main.py</parameter></tool>'
        calls = self._parse(text)
        assert len(calls) == 1
        assert calls[0].name == "read_file"
        assert calls[0].arguments["path"] == "src/main.py"

    def test_json_from_fence(self):
        text = '```json\n{"name": "bash", "arguments": {"command": "ls"}}\n```'
        calls = self._parse(text)
        assert len(calls) == 1
        assert calls[0].name == "bash"

    def test_json_object_in_text(self):
        text = 'Let me call this: {"name": "list_dir", "arguments": {"path": "."}} now.'
        calls = self._parse(text)
        assert len(calls) == 1
        assert calls[0].name == "list_dir"

    def test_tool_code_block(self):
        text = '```tool_code\nread_file(path="src/main.py")\n```'
        calls = self._parse(text)
        assert len(calls) == 1
        assert calls[0].name == "read_file"

    def test_no_match_returns_empty(self):
        calls = self._parse("Just a plain text response.")
        assert calls == []

    def test_backtick_fence_around_tool_tag(self):
        """Model wrapping tool call in a markdown code fence must still parse."""
        text = '```tool name="bash">\n<parameter name="command">python contacts.py</parameter>\n</tool>\n```'
        calls = self._parse(text)
        assert len(calls) == 1
        assert calls[0].name == "bash"
        assert calls[0].arguments["command"] == "python contacts.py"

    def test_wrong_closing_tag_stripped(self):
        """</content> instead of </parameter> must not bleed into extracted value."""
        text = (
            '<tool name="write_file">'
            '<parameter name="path">foo.py</parameter>'
            '<parameter name="content">\ndef foo():\n    pass\n</content>'
            '</tool>'
        )
        calls = self._parse(text)
        assert len(calls) == 1
        assert calls[0].arguments["path"] == "foo.py"
        content = calls[0].arguments["content"]
        assert "</content>" not in content
        assert "def foo():" in content

    def test_multiline_content_truncated(self):
        """Missing </parameter> and </tool> (truncated response) must still yield content."""
        body_lines = "\n".join(f"    x_{i} = {i}" for i in range(30))
        code = f"def foo():\n{body_lines}\n    return x_0"
        text = (
            '<tool name="write_file">'
            '<parameter name="path">out.py</parameter>'
            f'<parameter name="content">\n{code}'
            # no closing </parameter> or </tool>
        )
        calls = self._parse(text)
        assert len(calls) == 1
        assert calls[0].name == "write_file"
        assert calls[0].arguments["path"] == "out.py"
        assert "def foo():" in calls[0].arguments["content"]
        assert "x_29" in calls[0].arguments["content"]

    def test_function_wrapper(self):
        text = '{"type": "function", "function": {"name": "bash", "arguments": {"command": "pwd"}}}'
        calls = self._parse(text)
        assert len(calls) == 1
        assert calls[0].name == "bash"
