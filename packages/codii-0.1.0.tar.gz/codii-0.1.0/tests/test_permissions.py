"""Tests for the permissions model."""
from __future__ import annotations

import pytest
from pathlib import Path

from codii.tools.base import PermissionBand, classify_operation
from codii.permissions.approvals import load_approvals, is_auto_approved
from codii.permissions.model import check_permission


@pytest.fixture
def workspace(tmp_path: Path) -> Path:
    return tmp_path


class TestClassifyOperation:
    def test_read_free(self, workspace):
        assert classify_operation("read", workspace / "x.py", workspace) == PermissionBand.FREE

    def test_list_free(self, workspace):
        assert classify_operation("list", None, workspace) == PermissionBand.FREE

    def test_write_free_inside_workspace(self, workspace):
        assert classify_operation("write", workspace / "new.py", workspace) == PermissionBand.FREE

    def test_edit_free_inside_workspace(self, workspace):
        assert classify_operation("edit", workspace / "src" / "main.py", workspace) == PermissionBand.FREE

    def test_delete_is_confirmation(self, workspace):
        assert classify_operation("delete", workspace / "x.py", workspace) == PermissionBand.CONFIRMATION

    def test_bash_is_confirmation(self, workspace):
        assert classify_operation("bash", None, workspace) == PermissionBand.CONFIRMATION

    def test_escape_via_dotdot_is_forbidden(self, workspace):
        outside = (workspace / ".." / "evil.txt").resolve()
        assert classify_operation("read", outside, workspace) == PermissionBand.FORBIDDEN

    def test_parent_dir_is_forbidden(self, workspace):
        parent = workspace.parent
        assert classify_operation("write", parent / "x.txt", workspace) == PermissionBand.FORBIDDEN

    def test_dotenv_path_is_forbidden(self, workspace):
        dotenv = workspace / ".env"
        assert classify_operation("read", dotenv, workspace) == PermissionBand.FORBIDDEN


class TestAutoApprovals:
    def test_empty_approvals(self, workspace):
        rules = load_approvals(workspace)
        assert rules == []

    def test_approvals_toml_loaded(self, workspace):
        (workspace / ".codii").mkdir()
        (workspace / ".codii" / "approvals.toml").write_text(
            '[[auto_approve]]\noperation = "bash"\npattern = "echo *"\n',
            encoding="utf-8",
        )
        rules = load_approvals(workspace)
        assert len(rules) == 1
        assert rules[0]["operation"] == "bash"

    def test_pattern_match(self):
        rules = [{"operation": "bash", "pattern": "echo *"}]
        assert is_auto_approved("bash", "echo hello", rules)
        assert not is_auto_approved("bash", "rm -rf /", rules)

    def test_wildcard_operation(self):
        rules = [{"operation": "*", "pattern": "*.py"}]
        assert is_auto_approved("read", "src/main.py", rules)
        assert is_auto_approved("write", "tests/test_foo.py", rules)
        assert not is_auto_approved("bash", "rm *.py", rules)


class TestCheckPermission:
    def test_free_operation_auto_approved(self, workspace):
        band, auto = check_permission("read", workspace / "x.py", workspace)
        assert band == PermissionBand.FREE
        assert auto is True

    def test_forbidden_never_auto_approved(self, workspace):
        outside = workspace.parent / "x.py"
        band, auto = check_permission("read", outside, workspace)
        assert band == PermissionBand.FORBIDDEN
        assert auto is False

    def test_confirmation_not_auto_approved_by_default(self, workspace):
        band, auto = check_permission("bash", None, workspace)
        assert band == PermissionBand.CONFIRMATION
        assert auto is False

    def test_confirmation_auto_approved_by_rule(self, workspace):
        (workspace / ".codii").mkdir()
        (workspace / ".codii" / "approvals.toml").write_text(
            '[[auto_approve]]\noperation = "bash"\npattern = "*"\n',
            encoding="utf-8",
        )
        band, auto = check_permission("bash", None, workspace)
        assert band == PermissionBand.CONFIRMATION
        assert auto is True
