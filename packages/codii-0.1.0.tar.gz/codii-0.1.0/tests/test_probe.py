"""Tests for the four capability probes and the runner."""
from __future__ import annotations

import json
from datetime import datetime, timezone

import pytest

from codii.connection.base import Done, TextChunk, ToolCall
from codii.probe.tool_call import _detect_format, probe_tool_call
from codii.probe.context_window import probe_context_window
from codii.probe.reasoning import probe_reasoning
from codii.probe.structured import probe_structured_output, _score_response
from codii.probe.runner import compute_tier, detect_family
from tests.conftest import MockAdapter


# ── Probe 1: tool call format detection ───────────────────────────────────────

class TestFormatDetection:
    def test_gemma4_token_variant_with_pipe(self):
        assert _detect_format("<|tool_call|>\n{\"name\": \"get_time\"}") == "gemma4_tokens"

    def test_gemma4_token_variant_without_pipe(self):
        assert _detect_format("<|tool_call>\n{\"name\": \"get_time\"}") == "gemma4_tokens"

    def test_hermes_xml(self):
        assert _detect_format("<tool_call>get_time()</tool_call>") == "hermes_xml"

    def test_gemma3_tool_code(self):
        assert _detect_format("```tool_code\nget_time()\n```") == "none"

    def test_mistral_tool_calls_marker(self):
        assert _detect_format("[TOOL_CALLS] [{\"name\": \"get_time\"}]") == "mistral_json"

    def test_qwen_function_type(self):
        assert _detect_format('{"type": "function", "function": {"name": "get_time"}}') == "qwen_json"

    def test_openai_json_in_fence(self):
        text = '```json\n{"name": "get_time", "arguments": {}}\n```'
        assert _detect_format(text) == "openai_json"

    def test_no_match_returns_none(self):
        assert _detect_format("I would call get_time() here.") == "none"

    def test_empty_returns_none(self):
        assert _detect_format("") == "none"


async def test_probe_tool_call_gemma4(mock_adapter: MockAdapter):
    """Gemma 4: native ToolCall from Request A, gemma4_tokens in Request B."""
    # Request A: native tool call surfaced
    mock_adapter.queue_tool_call("get_time", {}, stop_reason="tool_calls")
    # Request B: raw text with gemma4 tokens
    mock_adapter.queue_text("<|tool_call|>\n{\"name\": \"get_time\", \"arguments\": {}}")

    result = await probe_tool_call(mock_adapter)
    assert result.native_tool_calling is True
    assert result.tool_call_format == "gemma4_tokens"


async def test_probe_tool_call_gemma3(mock_adapter: MockAdapter):
    """Gemma 3: no native tool call, tool_code markdown → none format."""
    # Request A: plain text response (no tool call)
    mock_adapter.queue_text("I would look at the time using the get_time function.")
    # Request B: tool_code markdown
    mock_adapter.queue_text("```tool_code\nget_time()\n```")

    result = await probe_tool_call(mock_adapter)
    assert result.native_tool_calling is False
    assert result.tool_call_format == "none"


async def test_probe_tool_call_openai_json(mock_adapter: MockAdapter):
    """OpenAI JSON format detection."""
    mock_adapter.queue_text("Just checking the time.")  # Request A: no tool call
    mock_adapter.queue_text('```json\n{"name": "get_time", "arguments": {}}\n```')

    result = await probe_tool_call(mock_adapter)
    assert result.native_tool_calling is False
    assert result.tool_call_format == "openai_json"


async def test_probe_tool_call_ambiguous(mock_adapter: MockAdapter):
    """Ambiguous response → 'none' (conservative)."""
    mock_adapter.queue_text("I would call get_time() here.")  # No tool call
    mock_adapter.queue_text("get_time()")  # Ambiguous

    result = await probe_tool_call(mock_adapter)
    assert result.native_tool_calling is False
    assert result.tool_call_format == "none"


# ── Probe 2: context window ────────────────────────────────────────────────────

async def test_probe_context_window_25_50_pass_90_fail(mock_adapter: MockAdapter):
    """25% and 50% pass, 90% fails → effective = 50% of target."""
    # We need to know the needle before probing. We'll monkeypatch the random generation.
    import codii.probe.context_window as cw_module
    original_needle = cw_module._generate_needle

    fixed_needle = "CODII_ABCDEF_1234"
    cw_module._generate_needle = lambda: fixed_needle  # type: ignore

    try:
        # Three requests: 25%, 50%, 90%
        mock_adapter.queue_text(f"The secret identifier is {fixed_needle}.")  # 25% passes
        mock_adapter.queue_text(f"The identifier is {fixed_needle}")          # 50% passes
        mock_adapter.queue_text("I don't see any identifier in the text.")    # 90% fails

        result = await probe_context_window(mock_adapter, claimed_context_tokens=10000)
        assert result.depth_results[0.25] is True
        assert result.depth_results[0.50] is True
        assert result.depth_results[0.90] is False
        # effective = 50% of min(10000, 32000) = 5000
        assert result.effective_context_tokens == 5000
    finally:
        cw_module._generate_needle = original_needle


async def test_probe_context_window_all_fail(mock_adapter: MockAdapter):
    """All depths fail → effective context falls back to 75% of claimed."""
    import codii.probe.context_window as cw_module
    fixed_needle = "CODII_XXXXXX_9999"
    cw_module._generate_needle = lambda: fixed_needle  # type: ignore
    try:
        for _ in range(3):
            mock_adapter.queue_text("I don't see any identifier.")
        result = await probe_context_window(mock_adapter, claimed_context_tokens=8000)
        assert result.effective_context_tokens == int(8000 * 0.75)
    finally:
        cw_module._generate_needle = lambda: "CODII_RESTORE_0000"


# ── Probe 3: reasoning ────────────────────────────────────────────────────────

async def test_probe_reasoning_think_tag(mock_adapter: MockAdapter):
    mock_adapter.queue_text("<think>\n7 apples\n</think>\nAlice has 7 apples.")
    result = await probe_reasoning(mock_adapter)
    assert result.supported is True
    assert result.delimiter == "<think>"


async def test_probe_reasoning_thinking_tag(mock_adapter: MockAdapter):
    mock_adapter.queue_text("<thinking>Let me work this out...</thinking>\n12 apples.")
    result = await probe_reasoning(mock_adapter)
    assert result.supported is True
    assert result.delimiter == "<thinking>"


async def test_probe_reasoning_begin_of_thought(mock_adapter: MockAdapter):
    mock_adapter.queue_text("<|begin_of_thought|>Step 1...<|end_of_thought|>\n7.")
    result = await probe_reasoning(mock_adapter)
    assert result.supported is True
    assert result.delimiter == "<|begin_of_thought|>"


async def test_probe_reasoning_not_supported(mock_adapter: MockAdapter):
    mock_adapter.queue_text("Alice has 7 apples. Step 1: 3*4=12, divide by 2 is 6, plus 1 is 7.")
    result = await probe_reasoning(mock_adapter)
    assert result.supported is False
    assert result.delimiter is None


# ── Probe 4: structured output ────────────────────────────────────────────────

def test_score_response_valid():
    text = '{"name": "codii", "score": 8, "tags": ["fast", "local"]}'
    assert _score_response(text) is True


def test_score_response_with_fences():
    text = '```json\n{"name": "codii", "score": 8, "tags": ["fast", "local"]}\n```'
    assert _score_response(text) is True


def test_score_response_missing_field():
    text = '{"name": "codii", "score": 8}'
    assert _score_response(text) is False


def test_score_response_wrong_type():
    text = '{"name": "codii", "score": "eight", "tags": ["a", "b"]}'
    assert _score_response(text) is False


def test_score_response_invalid_json():
    assert _score_response("not json") is False


async def test_probe_structured_output_4_of_5(mock_adapter: MockAdapter):
    good = '{"name": "codii", "score": 7, "tags": ["agentic", "local"]}'
    bad = "Sorry, here is the JSON: it's complex."
    for i in range(5):
        mock_adapter.queue_text(good if i < 4 else bad)
    result = await probe_structured_output(mock_adapter, n=5)
    assert result.reliability == pytest.approx(0.8)
    assert sum(result.scores) == 4


async def test_probe_structured_output_perfect(mock_adapter: MockAdapter):
    good = '{"name": "codii", "score": 9, "tags": ["open", "source"]}'
    for _ in range(5):
        mock_adapter.queue_text(good)
    result = await probe_structured_output(mock_adapter, n=5)
    assert result.reliability == pytest.approx(1.0)


async def test_probe_structured_output_zero(mock_adapter: MockAdapter):
    for _ in range(5):
        mock_adapter.queue_text("I cannot produce JSON right now.")
    result = await probe_structured_output(mock_adapter, n=5)
    assert result.reliability == pytest.approx(0.0)


# ── Runner: tier computation ───────────────────────────────────────────────────

class TestComputeTier:
    def test_tier1_all_criteria_met(self):
        assert compute_tier(native_tool_calling=True, structured_reliability=0.9, effective_context_tokens=16000) == 1

    def test_tier1_boundary_0_9(self):
        assert compute_tier(native_tool_calling=True, structured_reliability=0.9, effective_context_tokens=32000) == 1

    def test_tier2_reliability_just_below_tier1(self):
        assert compute_tier(native_tool_calling=True, structured_reliability=0.89, effective_context_tokens=32000) == 2

    def test_tier2_no_native_tool_calling(self):
        assert compute_tier(native_tool_calling=False, structured_reliability=0.95, effective_context_tokens=32000) == 2

    def test_tier2_context_below_16k(self):
        assert compute_tier(native_tool_calling=True, structured_reliability=0.95, effective_context_tokens=8000) == 2

    def test_tier2_boundary_0_5(self):
        assert compute_tier(native_tool_calling=False, structured_reliability=0.5, effective_context_tokens=0) == 2

    def test_tier3_reliability_0_49(self):
        assert compute_tier(native_tool_calling=False, structured_reliability=0.49, effective_context_tokens=0) == 3

    def test_tier3_zero_reliability(self):
        assert compute_tier(native_tool_calling=False, structured_reliability=0.0, effective_context_tokens=0) == 3


class TestDetectFamily:
    def test_gemma4(self):
        assert detect_family("gemma4:27b") == "gemma4"

    def test_gemma4_with_dash(self):
        assert detect_family("gemma-4-27b") == "gemma4"

    def test_gemma3_is_other(self):
        # Gemma 3 is not in the enum → 'other'
        assert detect_family("gemma3:12b") == "other"

    def test_gemma_generic_is_other(self):
        assert detect_family("gemma:7b") == "other"

    def test_qwen(self):
        assert detect_family("qwen2.5-coder:32b") == "qwen"

    def test_mistral(self):
        assert detect_family("mistral:7b") == "mistral"

    def test_devstral(self):
        assert detect_family("devstral:22b") == "mistral"

    def test_llama(self):
        assert detect_family("llama3.1:8b") == "llama"

    def test_deepseek(self):
        assert detect_family("deepseek-coder-v2:16b") == "deepseek"

    def test_phi(self):
        assert detect_family("phi3.5:3.8b") == "phi"

    def test_unknown(self):
        assert detect_family("some-random-model:7b") == "unknown"
