"""Tests for the decision logger."""
from __future__ import annotations

import json
import pytest
from datetime import datetime, timezone
from pathlib import Path

from codii.decisions.logger import DecisionLogger, show_decisions
from codii.decisions.schema import DecisionRecord


@pytest.fixture
def session_dir(tmp_path: Path) -> Path:
    return tmp_path / "sessions" / "test-session"


class TestDecisionLogger:
    def test_writes_jsonl_and_log(self, session_dir: Path):
        logger = DecisionLogger(session_dir)
        logger.log("tier_select", {"tier": 2, "reason": "reliability < 0.9"})

        assert (session_dir / "decisions.jsonl").exists()
        assert (session_dir / "decisions.log").exists()

    def test_jsonl_is_valid_json(self, session_dir: Path):
        logger = DecisionLogger(session_dir)
        logger.log("parser_dispatch", {"parser": "generic", "count": 1})

        lines = (session_dir / "decisions.jsonl").read_text().splitlines()
        assert len(lines) == 1
        record = json.loads(lines[0])
        assert record["type"] == "parser_dispatch"

    def test_multiple_records_appended(self, session_dir: Path):
        logger = DecisionLogger(session_dir)
        logger.log("tier_select", {"tier": 1})
        logger.log("tool_surface", {"tool": "read_file"})
        logger.log("circuit_break", {"tool": "bash", "count": 3})

        lines = (session_dir / "decisions.jsonl").read_text().strip().splitlines()
        assert len(lines) == 3

    def test_read_records_returns_all(self, session_dir: Path):
        logger = DecisionLogger(session_dir)
        for t in ("tier_select", "repair", "compact"):
            logger.log(t, {"dummy": True})

        records = logger.read_records()
        assert len(records) == 3

    def test_read_records_type_filter(self, session_dir: Path):
        logger = DecisionLogger(session_dir)
        logger.log("tier_select", {})
        logger.log("repair", {})
        logger.log("tier_select", {})

        records = logger.read_records(type_filter="tier_select")
        assert len(records) == 2
        assert all(r.type == "tier_select" for r in records)

    def test_read_records_limit(self, session_dir: Path):
        logger = DecisionLogger(session_dir)
        for i in range(10):
            logger.log("tool_surface", {"i": i})

        records = logger.read_records(limit=5)
        assert len(records) == 5

    def test_show_decisions_returns_string(self, session_dir: Path):
        logger = DecisionLogger(session_dir)
        logger.log("tier_select", {"tier": 2})
        output = show_decisions(session_dir)
        assert "TIER_SELECT" in output

    def test_empty_session_returns_message(self, session_dir: Path):
        output = show_decisions(session_dir)
        assert "No decisions" in output

    def test_all_twelve_decision_types_valid(self, session_dir: Path):
        logger = DecisionLogger(session_dir)
        all_types = [
            "tier_select", "tool_surface", "parser_dispatch", "repair",
            "compact", "intervention", "subagent", "permission",
            "promote", "demote", "timeout", "circuit_break",
        ]
        for dt in all_types:
            logger.log(dt, {"test": True})

        records = logger.read_records()
        assert len(records) == 12

    def test_decision_record_schema(self, session_dir: Path):
        logger = DecisionLogger(session_dir)
        logger.log("permission", {"tool": "bash", "band": "confirmation"})
        records = logger.read_records()
        r = records[0]
        assert isinstance(r, DecisionRecord)
        assert isinstance(r.ts, datetime)
        assert r.type == "permission"
        assert r.payload["tool"] == "bash"
