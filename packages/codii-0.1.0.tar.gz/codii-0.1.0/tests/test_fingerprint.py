"""Tests for fingerprint schema, store, and overrides."""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

import pytest
from pydantic import ValidationError

from codii.fingerprint.schema import (
    Capabilities,
    CapabilityFingerprint,
    ReasoningSupport,
)
from codii.fingerprint.store import (
    fingerprint_path,
    list_fingerprints,
    load_fingerprint,
    save_fingerprint,
    slugify,
)
from tests.conftest import MockAdapter


# ── Schema validation ──────────────────────────────────────────────────────────

def test_valid_fingerprint_validates(sample_fingerprint: CapabilityFingerprint):
    data = sample_fingerprint.model_dump(mode="json")
    fp = CapabilityFingerprint.model_validate(data)
    assert fp.model == "gemma4:27b"


def test_missing_required_field_raises():
    data = {
        "schema_version": 1,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "updated_at": datetime.now(timezone.utc).isoformat(),
        # missing backend, endpoint, model, quant_hash, capabilities
    }
    with pytest.raises(ValidationError):
        CapabilityFingerprint.model_validate(data)


def test_invalid_family_raises(sample_fingerprint: CapabilityFingerprint):
    data = sample_fingerprint.model_dump(mode="json")
    data["capabilities"]["family"] = "turbocharger"  # not in enum
    with pytest.raises(ValidationError):
        CapabilityFingerprint.model_validate(data)


def test_invalid_tool_format_raises(sample_fingerprint: CapabilityFingerprint):
    data = sample_fingerprint.model_dump(mode="json")
    data["capabilities"]["tool_call_format"] = "magic_format"
    with pytest.raises(ValidationError):
        CapabilityFingerprint.model_validate(data)


def test_round_trip_serialization(sample_fingerprint: CapabilityFingerprint):
    data = sample_fingerprint.model_dump(mode="json")
    fp2 = CapabilityFingerprint.model_validate(data)
    assert fp2.capabilities.tier == sample_fingerprint.capabilities.tier
    assert fp2.capabilities.tier_rationale == sample_fingerprint.capabilities.tier_rationale


# ── Slugify ────────────────────────────────────────────────────────────────────

def test_slugify_basic():
    slug = slugify("ollama", "gemma4:27b", "abc12345")
    assert slug == "ollama_gemma4_27b_abc12345"


def test_slugify_with_slashes():
    slug = slugify("ollama", "my-model/variant", "deadbeef")
    assert "my_model_variant" in slug
    assert slug.endswith("deadbeef")


def test_slugify_uppercase_lowercased():
    slug = slugify("OLLAMA", "GEMMA4", "ABCD1234")
    assert slug == slug.lower()


def test_slugify_no_consecutive_underscores():
    slug = slugify("ollama", "model::variant", "12345678")
    assert "__" not in slug


# ── Persistence ────────────────────────────────────────────────────────────────

def test_save_and_load_fingerprint(
    sample_fingerprint: CapabilityFingerprint,
    tmp_codii_dir: Path,
):
    path = save_fingerprint(sample_fingerprint)
    assert path.exists()
    assert path.suffix == ".json"

    loaded = load_fingerprint(
        sample_fingerprint.backend,
        sample_fingerprint.model,
        sample_fingerprint.quant_hash,
    )
    assert loaded is not None
    assert loaded.model == sample_fingerprint.model
    assert loaded.capabilities.tier == sample_fingerprint.capabilities.tier


def test_load_missing_returns_none(tmp_codii_dir: Path):
    result = load_fingerprint("ollama", "nonexistent-model", "00000000")
    assert result is None


def test_list_fingerprints_empty(tmp_codii_dir: Path):
    assert list_fingerprints() == []


def test_list_fingerprints_returns_all(
    sample_fingerprint: CapabilityFingerprint,
    tmp_codii_dir: Path,
):
    # Save two fingerprints with different models
    fp1 = sample_fingerprint
    fp2 = sample_fingerprint.model_copy(update={"model": "gemma3:12b", "quant_hash": "zzz99999"})
    save_fingerprint(fp1)
    save_fingerprint(fp2)

    fps = list_fingerprints()
    models = {fp.model for fp in fps}
    assert "gemma4:27b" in models
    assert "gemma3:12b" in models


def test_atomic_replace_overwrites_existing(
    sample_fingerprint: CapabilityFingerprint,
    tmp_codii_dir: Path,
):
    """Second save must overwrite without error (tests Windows Path.replace() behaviour)."""
    save_fingerprint(sample_fingerprint)
    # Modify and save again
    updated = sample_fingerprint.model_copy(
        update={"capabilities": sample_fingerprint.capabilities.model_copy(update={"tier": 2})}
    )
    save_fingerprint(updated)

    loaded = load_fingerprint(
        sample_fingerprint.backend,
        sample_fingerprint.model,
        sample_fingerprint.quant_hash,
    )
    assert loaded is not None
    assert loaded.capabilities.tier == 2


def test_fingerprint_json_is_utf8(
    sample_fingerprint: CapabilityFingerprint,
    tmp_codii_dir: Path,
):
    path = save_fingerprint(sample_fingerprint)
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    assert data["model"] == "gemma4:27b"


# ── User overrides ─────────────────────────────────────────────────────────────

def test_apply_overrides_tier(sample_fingerprint: CapabilityFingerprint):
    """user_overrides.tier should take precedence over probe-derived tier."""
    fp = sample_fingerprint.model_copy(update={"user_overrides": {"tier": 2}})
    effective = fp.effective_capabilities()
    assert effective.tier == 2


def test_apply_overrides_tool_format(sample_fingerprint: CapabilityFingerprint):
    fp = sample_fingerprint.model_copy(
        update={"user_overrides": {"tool_call_format": "hermes_xml"}}
    )
    effective = fp.effective_capabilities()
    assert effective.tool_call_format == "hermes_xml"


def test_no_overrides_returns_original(sample_fingerprint: CapabilityFingerprint):
    effective = sample_fingerprint.effective_capabilities()
    assert effective.tier == sample_fingerprint.capabilities.tier
    assert effective.tool_call_format == sample_fingerprint.capabilities.tool_call_format
