import json

import pytest


@pytest.fixture
def apsi_params() -> str:
    return json.dumps(
        {
            "table_params": {
                "hash_func_count": 3,
                "table_size": 512,
                "max_items_per_bin": 92,
            },
            "item_params": {"felts_per_item": 8},
            "query_params": {
                "ps_low_degree": 0,
                "query_powers": [1, 3, 4, 5, 8, 14, 20, 26, 32, 38, 41, 42, 43, 45, 46],
            },
            "seal_params": {
                "plain_modulus": 40961,
                "poly_modulus_degree": 4096,
                "coeff_modulus_bits": [40, 32, 32],
            },
        }
    )
