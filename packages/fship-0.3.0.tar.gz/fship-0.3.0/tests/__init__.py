"""Tests for fship."""
