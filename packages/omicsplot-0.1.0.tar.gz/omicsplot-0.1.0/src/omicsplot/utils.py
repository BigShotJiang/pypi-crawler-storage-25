"""General utilities for omicsplot.

Genome-coordinate helpers used by track-based plotting.
"""

from pathlib import Path

import pandas as pd

_DATA_DIR = Path(__file__).resolve().parent / "data"


def genome_range(range_list=None, genome='hg38', chrXY=True):
    """Return a chrom-sizes DataFrame, optionally restricted to specific regions.

    Parameters
    ----------
    range_list : list of str, optional
        Genomic range strings (e.g. ``["chr1:1000000-2000000", "chr2"]``).
        If ``None`` or empty, all main chromosomes are returned.
    genome : {'hg38', 'GRCh38'}, default 'hg38'
        Reference genome. Only hg38/GRCh38 is supported.
    chrXY : bool, default True
        Whether to include sex chromosomes (chrX, chrY).

    Returns
    -------
    pd.DataFrame
        Columns ``chrom``, ``length``, ``start``, ``end``.

    Examples
    --------
    >>> genome_range()                              # all main chromosomes
    >>> genome_range(["chr1:1000000-2000000"])      # specific region
    >>> genome_range(chrXY=False)                   # autosomes only
    """
    if genome.lower() not in ('hg38', 'grch38'):
        raise ValueError(f"Genome '{genome}' not supported. Use 'hg38' or 'GRCh38'.")

    gs = pd.read_csv(_DATA_DIR / "GRCh38.genome.size.tsv",
                     sep='\t', names=['chrom', 'length'])
    gs = gs[gs['chrom'].str.startswith('chr') & (gs['chrom'] != 'chrM')]
    if not chrXY:
        gs = gs[~gs['chrom'].isin(['chrX', 'chrY'])]
    gs = gs.reset_index(drop=True)
    gs['start'] = 1
    gs['end'] = gs['length']

    if range_list:
        rows = []
        for s in range_list:
            parts = s.split(':')
            chrom = parts[0]
            if len(parts) > 1:
                start, end = parts[1].split('-')
                start, end = int(start), int(end)
            else:
                start = 1
                end = int(gs.loc[gs['chrom'] == chrom, 'end'].iloc[0])
            rows.append({'chrom': chrom, 'start': start, 'end': end,
                         'length': end - start + 1})
        gs = pd.DataFrame(rows)
    return gs
