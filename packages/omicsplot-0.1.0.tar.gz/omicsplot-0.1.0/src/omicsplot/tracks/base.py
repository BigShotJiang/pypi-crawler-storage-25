"""
Base track class for genome-wide plots.

Provides the shared rendering template: per-chromosome iteration,
highlight regions, facecolor/spine styling, axis labels. Subclasses
only need to implement _plot_chrom().
"""

from .axes import filter_genome_size


class _BaseTrack:
    """
    Base class for all genomic tracks.

    Subclasses implement _plot_chrom(ax, data, chrom_name, **kwargs) to
    draw into a single chromosome's axes. Everything else — iteration,
    styling, highlights, labels — is handled here.

    Parameters
    ----------
    df : pd.DataFrame
        Data to plot.
    ylabel : str, optional
        Y-axis label (shown on the leftmost chromosome only).
    ylim : tuple, optional
        Y-axis limits (ymin, ymax).
    highlight_df : pd.DataFrame, optional
        Regions to shade. Columns: 'chrom', 'start', 'end'.
    chrom_column : str
        Column name for chromosome in df.
    style : {'facecolor', 'spine'}
        How to visually separate chromosomes.
        - 'facecolor': alternating white/grey backgrounds.
        - 'spine': dashed grey lines between chromosomes.
    yscale : str
        Matplotlib yscale value: 'linear' (default) or 'log'.
    **kwargs
        Stored and merged into render() calls.
    """

    def __init__(self, df, ylabel=None, ylim=None, highlight_df=None,
                 chrom_column='chrom', style='facecolor', yscale='linear',
                 **kwargs):
        self.df = df
        self.ylabel = ylabel
        self.ylim = ylim
        self.highlight_df = highlight_df
        self.chrom_column = chrom_column
        self.style = style
        self.yscale = yscale
        self.kwargs = kwargs

    def render(self, axes, genome_size, chrom=[], showX=True,
               show_chrom_labels=True, **kwargs):
        """
        Render this track into a row of per-chromosome axes.

        Parameters
        ----------
        axes : array-like of Axes
            One axis per chromosome. Typically axes[i] from make_genome_axes().
        genome_size : pd.DataFrame
            Columns: 'chrom', 'length'. Used to determine chromosome order.
        chrom : list
            Chromosomes to include.
        showX : bool
            Include chrX when chrom is empty.
        show_chrom_labels : bool
            Show chromosome number as xlabel.
        **kwargs
            Override stored kwargs (e.g. style, colors).
        """
        merged = {**self.kwargs, **kwargs}
        style = merged.get('style', self.style)
        facecolor_even = merged.get('facecolor_even', 'white')
        facecolor_odd  = merged.get('facecolor_odd',  '#f0f0f0')
        spine_linestyle = merged.get('spine_linestyle', (0, (1, 4)))
        spine_color     = merged.get('spine_color',     'grey')
        highlight_color = merged.get('highlight_color', 'grey')
        highlight_alpha = merged.get('highlight_alpha', 0.3)

        gs = filter_genome_size(genome_size, chrom, showX)

        for col_idx, (_, row) in enumerate(gs.iterrows()):
            chrom_name = row['chrom']
            ax = axes[col_idx]
            data = self.df[self.df[self.chrom_column] == chrom_name]

            self._plot_chrom(ax, data, chrom_name, **merged)

            # Highlight regions
            if self.highlight_df is not None:
                h_data = self.highlight_df[self.highlight_df['chrom'] == chrom_name]
                for _, h in h_data.iterrows():
                    ax.axvspan(h['start'], h['end'],
                               facecolor=highlight_color, alpha=highlight_alpha)

            # Common spine cleanup
            ax.spines['right'].set_visible(False)
            ax.spines['top'].set_visible(False)

            # Chromosome separation style
            if style == 'facecolor':
                ax.set_facecolor(facecolor_even if col_idx % 2 == 0 else facecolor_odd)

            if col_idx > 0:
                ax.set(ylabel=None)
                ax.tick_params(left=False, labelleft=False)
                if style == 'spine':
                    ax.spines['left'].set_linestyle(spine_linestyle)
                    ax.spines['left'].set_edgecolor(spine_color)
                else:
                    ax.spines['left'].set_visible(False)
            else:
                ax.set(ylabel=self.ylabel)

            # Y-axis
            if self.yscale != 'linear':
                ax.set_yscale(self.yscale)
            if self.ylim is not None:
                ax.set_ylim(self.ylim)

            # X-axis / chrom label
            ax.tick_params(bottom=False, labelbottom=False)
            if show_chrom_labels:
                ax.set_xlabel(chrom_name.replace('chr', ''))
            else:
                ax.set_xlabel('')

            ax.legend([], [], frameon=False)

    def _plot_chrom(self, ax, data, chrom_name, **kwargs):
        """
        Draw data for a single chromosome into ax.

        Parameters
        ----------
        ax : matplotlib.axes.Axes
        data : pd.DataFrame
            Subset of self.df for this chromosome.
        chrom_name : str
        **kwargs
            Merged kwargs from render().
        """
        raise NotImplementedError
