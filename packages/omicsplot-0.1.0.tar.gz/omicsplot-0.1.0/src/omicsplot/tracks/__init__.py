"""
omicsplot.tracks — general-purpose genome-wide track plotting.

Stacks heterogeneous genomic signal tracks (scatter, line segments, bar
counts, step coverage, SV triangles) on per-chromosome subplot axes sized
proportionally to chromosome lengths.

Basic usage
-----------
>>> from omicsplot.tracks import ScatterTrack, plot_tracks
>>>
>>> track = ScatterTrack(df, x_column='start', y_column='logR',
...                      ylabel='logR', ylim=(-2, 2))
>>> plot_tracks(track, genome_size)
"""

from .axes import filter_genome_size, make_genome_axes
from .base import _BaseTrack
from .tracks import ScatterTrack, LineSegmentTrack, BarTrack, StepTrack, plot_tracks
from .sv_track import SVTriangleTrack

__all__ = [
    # Axes factory
    "filter_genome_size",
    "make_genome_axes",
    # Base (for subclassing)
    "_BaseTrack",
    # Track types
    "ScatterTrack",
    "LineSegmentTrack",
    "BarTrack",
    "StepTrack",
    "SVTriangleTrack",
    # Layout
    "plot_tracks",
]
