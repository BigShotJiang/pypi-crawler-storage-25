"""
Genome-wide axes factory.

Creates per-chromosome subplot grids with width ratios proportional to
chromosome lengths — the shared coordinate system for all genomic tracks.
"""

import matplotlib.pyplot as plt


def filter_genome_size(genome_size, chrom=[], showX=True):
    """
    Filter a genome_size DataFrame by chromosome selection.

    Parameters
    ----------
    genome_size : pd.DataFrame
        Columns: 'chrom', 'length'.
    chrom : list
        Chromosomes to include. Empty list = all.
    showX : bool
        Include chrX when chrom is empty. chrY is always excluded.

    Returns
    -------
    pd.DataFrame
        Filtered copy.
    """
    gs = genome_size.copy()
    if not chrom:
        if not showX:
            gs = gs[~gs['chrom'].isin(['chrX', 'chrY'])]
        else:
            gs = gs[gs['chrom'] != 'chrY']
    else:
        gs = gs[gs['chrom'].isin(chrom)]
    return gs


def make_genome_axes(genome_size, n_rows=1, chrom=[], showX=True,
                     figsize=(6, 0.8), hspace=0.3):
    """
    Create a per-chromosome subplot grid.

    Columns are sized proportionally to chromosome lengths, so that the
    x-axis physical spacing is consistent across chromosomes.

    Parameters
    ----------
    genome_size : pd.DataFrame
        Columns: 'chrom', 'length'.
    n_rows : int
        Number of track rows.
    chrom : list
        Chromosomes to include. Empty = all autosomes + chrX (if showX).
    showX : bool
        Include chrX when chrom is empty.
    figsize : tuple
        (width, height_per_row). Total height = height_per_row * n_rows.
    hspace : float
        Vertical space between rows.

    Returns
    -------
    fig : matplotlib.figure.Figure
    axes : np.ndarray, shape (n_rows, n_chroms)
    gs : pd.DataFrame
        Filtered genome_size used for the layout.
    """
    gs = filter_genome_size(genome_size, chrom, showX)
    widths = list(gs['length'])
    n_chroms = len(gs)

    fig, axes = plt.subplots(
        n_rows, n_chroms,
        figsize=(figsize[0], figsize[1] * n_rows),
        gridspec_kw={'width_ratios': widths},
        squeeze=False,
    )
    plt.subplots_adjust(wspace=0, hspace=hspace)

    return fig, axes, gs
