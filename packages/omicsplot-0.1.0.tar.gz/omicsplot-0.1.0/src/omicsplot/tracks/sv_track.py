"""
Triangle plot track for structural variants (BEDPE format).

Each SV is defined by two genomic breakpoints. Both are converted to
linear genome coordinates, then the triangle transform is applied:

    display_x = (pos1 + pos2) / 2   # genomic midpoint — still a genome coord
    display_y = |pos1 - pos2| / 2   # half the SV span — encodes size

Intra- and inter-chromosomal SVs are treated identically. Small/local SVs
cluster near the bottom edge; inter-chromosomal SVs float near the apex.
The triangle border is the natural boundary of the transform given the
total genome length in view.
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon as MplPolygon
from matplotlib.path import Path as MplPath
from matplotlib.transforms import ScaledTranslation

from .axes import filter_genome_size


class SVTriangleTrack:
    """
    Triangle plot for structural variants from a BEDPE-like DataFrame.

    Parameters
    ----------
    df : pd.DataFrame
        BEDPE-like table with two breakpoints per row.
    genome_size : pd.DataFrame
        Columns: 'chrom', 'length'. Used to compute linear offsets.
    chrom1_col, start1_col, end1_col : str
        Columns for the first breakpoint (default: 'chrom1', 'start1', 'end1').
    chrom2_col, start2_col, end2_col : str
        Columns for the second breakpoint (default: 'chrom2', 'start2', 'end2').
    chrom : list
        Chromosomes to include. Empty = all autosomes + chrX (if showX).
    showX : bool
        Include chrX when chrom is empty.
    s : float
        Point size (default 8).
    alpha : float
        Point transparency (default 0.6).
    color : str
        Point color (default 'steelblue').
    ylabel : str
        Y-axis label (default 'SV span').
    """

    def __init__(self, df, genome_size,
                 chrom1_col='chrom1', start1_col='start1', end1_col='end1',
                 chrom2_col='chrom2', start2_col='start2', end2_col='end2',
                 chrom=[], showX=True,
                 s=8, alpha=0.6, color='steelblue', ylabel='SV span',
                 style='spine', chrom_label_side='bottom',
                 highlight_df=None, highlight_color='grey', highlight_alpha=0.3):
        self.df               = df
        self.genome_size      = genome_size
        self.chrom1_col       = chrom1_col
        self.start1_col       = start1_col
        self.end1_col         = end1_col
        self.chrom2_col       = chrom2_col
        self.start2_col       = start2_col
        self.end2_col         = end2_col
        self.chrom            = chrom
        self.showX            = showX
        self.s                = s
        self.alpha            = alpha
        self.color            = color
        self.ylabel           = ylabel
        self.style            = style
        self.chrom_label_side = chrom_label_side
        self.highlight_df     = highlight_df
        self.highlight_color  = highlight_color
        self.highlight_alpha  = highlight_alpha

    def _draw_highlights(self, ax, offsets, total_len,
                         highlight_color, highlight_alpha):
        """
        Shade highlight regions as two diagonal parallelogram strips.

        For a region [a, b] in linear genome coords, two diagonal strips mark
        SVs where at least one breakpoint falls in the region:
          - 45° strip  (x - y ∈ [a, b]): min(pos1, pos2) in region
          - 135° strip (x + y ∈ [a, b]): max(pos1, pos2) in region
        """
        if self.highlight_df is None:
            return
        L = total_len
        # Clip path: the triangle boundary in data coordinates
        tri_clip = MplPath(
            [(0, 0), (L, 0), (L / 2, L / 2), (0, 0)],
            [MplPath.MOVETO, MplPath.LINETO, MplPath.LINETO, MplPath.CLOSEPOLY],
        )
        kw = dict(facecolor=highlight_color, alpha=highlight_alpha,
                  edgecolor='none', clip_on=True, zorder=2)
        for _, h in self.highlight_df.iterrows():
            if h['chrom'] not in offsets:
                continue
            a = offsets[h['chrom']] + h['start']
            b = offsets[h['chrom']] + h['end']
            for verts in [
                [(a, 0), (b, 0), (b + L / 2, L / 2), (a + L / 2, L / 2)],  # 45°
                [(a, 0), (b, 0), (b - L / 2, L / 2), (a - L / 2, L / 2)],  # 135°
            ]:
                patch = MplPolygon(verts, **kw)
                ax.add_patch(patch)
                patch.set_clip_path(tri_clip, ax.transData)

    def _build_offsets(self):
        """Compute cumulative linear offsets for each chromosome."""
        gs = filter_genome_size(self.genome_size, self.chrom, self.showX)
        offsets = {}
        cumsum = 0
        for _, row in gs.iterrows():
            offsets[row['chrom']] = cumsum
            cumsum += row['length']
        return offsets, cumsum, gs

    def _to_linear(self, chrom_vals, start_vals, end_vals, offsets):
        """Convert breakpoints to linear genome coords using interval midpoints."""
        result = []
        for chrom, start, end in zip(chrom_vals, start_vals, end_vals):
            if chrom in offsets:
                result.append(offsets[chrom] + (start + end) / 2)
            else:
                result.append(None)
        return result

    def preferred_height(self, fig_width):
        """
        Return the ideal row height (inches) for this track given fig_width.

        Uses the default subplot margins from rcParams to estimate the actual
        axes width, then returns half of that (the triangle's 2:1 data aspect).
        The exact height is recomputed and applied in render() once the figure
        exists and actual positions are known.
        """
        left  = plt.rcParams.get('figure.subplot.left',  0.125)
        right = plt.rcParams.get('figure.subplot.right', 0.9)
        return (right - left) * fig_width / 2

    def render(self, axes, genome_size, chrom=[], showX=True,
               show_chrom_labels=True, font_size=7, **kwargs):
        """
        Render into a row of per-chromosome axes produced by plot_tracks.

        Merges the per-chrom axes into one spanning axis and delegates to
        plot(). This makes SVTriangleTrack usable anywhere a normal track is
        expected::

            fig, axes = cn.plot_tracks([cn_track, sv_track], gs)

        Parameters
        ----------
        axes : array-like of Axes
            One axis per chromosome (the row produced by plot_tracks).
        genome_size : pd.DataFrame
        chrom : list
        showX : bool
        show_chrom_labels : bool
            Ignored — the triangle track draws its own chromosome labels.
        font_size : int
        """
        self.chrom = chrom
        self.showX = showX

        fig = axes[0].get_figure()

        x0 = axes[0].get_position().x0
        x1 = axes[-1].get_position().x1
        y0 = axes[0].get_position().y0
        y1 = axes[0].get_position().y1

        # Compute the exact axes height needed for true 45° angles.
        # The triangle data is [0, L] wide and [0, L/2] tall, so in display
        # space we need axes_height_in = axes_width_in / 2.
        # Convert to figure fractions using actual figure dimensions.
        fig_w = fig.get_figwidth()
        fig_h = fig.get_figheight()
        axes_w_in     = (x1 - x0) * fig_w
        needed_h_frac = axes_w_in / 2 / fig_h

        # Bottom-align: place the triangle's bottom at y0 (the gridspec row
        # boundary), so the gap to the track below equals hspace — same as the
        # gap between any two normal tracks.
        ax = fig.add_axes([x0, y0, x1 - x0, needed_h_frac])

        for a in axes:
            a.set_visible(False)

        style           = kwargs.get('style',           self.style)
        facecolor_even  = kwargs.get('facecolor_even',  'white')
        facecolor_odd   = kwargs.get('facecolor_odd',   '#f0f0f0')
        spine_color     = kwargs.get('spine_color',     '#cccccc')
        spine_linestyle = kwargs.get('spine_linestyle', '-')
        highlight_color = kwargs.get('highlight_color', self.highlight_color)
        highlight_alpha = kwargs.get('highlight_alpha', self.highlight_alpha)

        self.plot(ax=ax, font_size=font_size, show_chrom_labels=show_chrom_labels,
                  highlight_color=highlight_color, highlight_alpha=highlight_alpha)
        ax.set_aspect('auto')

        offsets, total_len, gs_filtered = self._build_offsets()

        # Pre-compute cumulative boundaries
        boundaries = [0]
        for _, row in gs_filtered.iterrows():
            boundaries.append(boundaries[-1] + row['length'])
        n = len(gs_filtered)

        if style == 'facecolor':
            # Diamond checkerboard: each (i, j) chromosome pair gets its own cell,
            # bounded by BOTH diagonal directions (45° and 135°).
            # Diagonal cells (i=j) are triangles sitting on the bottom edge.
            # Off-diagonal cells (i<j) are parallelograms floating above.
            # Together they tile the entire triangle. Color by (i+j) % 2.
            for i in range(n):
                for j in range(i, n):
                    Bi0, Bi1 = boundaries[i], boundaries[i + 1]
                    Bj0, Bj1 = boundaries[j], boundaries[j + 1]
                    fc = facecolor_even if (i + j) % 2 == 0 else facecolor_odd
                    if i == j:
                        verts = [
                            (Bi0, 0),
                            ((Bi0 + Bi1) / 2, (Bi1 - Bi0) / 2),
                            (Bi1, 0),
                        ]
                    else:
                        verts = [
                            ((Bi0 + Bj0) / 2, (Bj0 - Bi0) / 2),
                            ((Bi1 + Bj0) / 2, (Bj0 - Bi1) / 2),
                            ((Bi1 + Bj1) / 2, (Bj1 - Bi1) / 2),
                            ((Bi0 + Bj1) / 2, (Bj1 - Bi0) / 2),
                        ]
                    ax.add_patch(MplPolygon(verts, facecolor=fc, edgecolor='none', zorder=0))

        elif style == 'spine':
            # V-shape at each chromosome boundary: left arm (135°) and right arm (45°)
            # meet at (B, 0), reaching the triangle's left and right edges respectively.
            for col_idx in range(1, n):
                B = boundaries[col_idx]
                ax.plot([B / 2, B, (total_len + B) / 2],
                        [B / 2, 0, (total_len - B) / 2],
                        color=spine_color, linestyle=spine_linestyle,
                        linewidth=0.3, zorder=1)

    def plot(self, ax=None, figsize=(10, 5), font_size=7, show_chrom_labels=True,
             highlight_color=None, highlight_alpha=None):
        """
        Draw the SV triangle plot.

        Parameters
        ----------
        ax : matplotlib.axes.Axes, optional
            Axes to draw into. Created if None.
        figsize : tuple
            Used only if ax is None.
        font_size : int

        Returns
        -------
        ax : matplotlib.axes.Axes
        """
        offsets, total_len, gs = self._build_offsets()

        pos1 = self._to_linear(
            self.df[self.chrom1_col], self.df[self.start1_col], self.df[self.end1_col],
            offsets,
        )
        pos2 = self._to_linear(
            self.df[self.chrom2_col], self.df[self.start2_col], self.df[self.end2_col],
            offsets,
        )

        # Drop SVs where either breakpoint is on an excluded chromosome
        valid = [(p1, p2) for p1, p2 in zip(pos1, pos2)
                 if p1 is not None and p2 is not None]
        if not valid:
            raise ValueError("No SVs remain after chromosome filtering.")
        pos1_arr = np.array([v[0] for v in valid])
        pos2_arr = np.array([v[1] for v in valid])

        dx = (pos1_arr + pos2_arr) / 2
        dy = np.abs(pos1_arr - pos2_arr) / 2

        lo, hi = 0, total_len

        if ax is None:
            _, ax = plt.subplots(figsize=figsize)

        # Highlight regions
        hc = highlight_color if highlight_color is not None else self.highlight_color
        ha = highlight_alpha if highlight_alpha is not None else self.highlight_alpha
        self._draw_highlights(ax, offsets, total_len, hc, ha)

        # Scatter points
        ax.scatter(dx, dy, s=self.s, alpha=self.alpha, color=self.color, linewidths=0)

        # Triangle border
        t = np.array([lo, hi])
        bkw = dict(color='black', linewidth=1.0)
        ax.plot((t + t) / 2,  (t - t) / 2,  **bkw)  # bottom edge (pos1 = pos2)
        ax.plot((t + lo) / 2, (t - lo) / 2, **bkw)   # left edge
        ax.plot((hi + t) / 2, (hi - t) / 2, **bkw)   # right edge

        # Chromosome labels and boundary tick marks.
        cumsum = 0
        chrom_mids, chrom_names, boundaries = [], [], [0]
        for _, row in gs.iterrows():
            chrom_len = row['length']
            chrom_mids.append(cumsum + chrom_len / 2)
            chrom_names.append(row['chrom'].replace('chr', ''))
            cumsum += chrom_len
            boundaries.append(cumsum)

        # Small tick marks at chromosome boundaries along the bottom edge.
        # Drawn as data-coordinate segments so they scale with the triangle at
        # any figure size (tick_h is 1% of the triangle height).
        tick_h = (hi / 2) * 0.01
        ax.vlines(boundaries[1:-1], 0, -tick_h, color='black', linewidth=0.6, clip_on=False)

        side = self.chrom_label_side

        # Bottom labels — stagger chr16/18/20/22 downward to match other tracks.
        # Uses ScaledTranslation for a fixed point offset (independent of figure size).
        # Normal: 4 pt below axis (matches default labelpad). Staggered: 10 pt (matches
        # the labelpad=10 used for the same chromosomes in cn_plot.py).
        ax.set_xticks(chrom_mids)
        ax.tick_params(axis='x', which='major', bottom=False, labelbottom=False)
        show_bottom = show_chrom_labels and side in ('bottom', 'both')
        if show_bottom:
            stagger_set = {'16', '18', '20', '22'}
            do_stagger = len(chrom_names) >= 20
            dpi_trans = ax.get_figure().dpi_scale_trans
            for mid, name in zip(chrom_mids, chrom_names):
                pad_pts = 10 if (do_stagger and name in stagger_set) else 4
                offset = ScaledTranslation(0, -pad_pts / 72, dpi_trans)
                ax.text(mid, 0, name, fontsize=font_size,
                        ha='center', va='top', clip_on=False,
                        transform=ax.transData + offset)

        # Left-edge labels: each chromosome's midpoint on the left edge is at
        # (t_mid/2, t_mid/2). Text is offset outward by a fixed number of points
        # perpendicular to the edge (direction (-1,+1)/√2), so the gap is the same
        # regardless of figure size.
        # Chr16/18/20/22 are short and crowd together; stagger them further out
        # (larger offset) to match how bottom labels handle the same chromosomes.
        if side in ('left', 'both'):
            sq2 = np.sqrt(2)
            stagger_set = {'16', '18', '20', '22'}
            do_stagger = len(chrom_names) >= 20
            dpi_trans = ax.get_figure().dpi_scale_trans
            cumsum = 0
            for name, row in zip(chrom_names, gs.itertuples()):
                pad_pts = 14 if (do_stagger and name in stagger_set) else 7
                offset = ScaledTranslation(
                    -pad_pts / (sq2 * 72), pad_pts / (sq2 * 72), dpi_trans,
                )
                chrom_len = row.length
                t_mid = cumsum + chrom_len / 2
                ax.text(t_mid / 2, t_mid / 2, name,
                        fontsize=font_size, ha='center', va='center',
                        rotation=45, clip_on=False,
                        transform=ax.transData + offset)
                cumsum += chrom_len

        ax.yaxis.set_visible(False)

        ax.set_xlim(lo, hi)
        ax.set_ylim(0, hi / 2)
        ax.set_aspect('equal')
        for spine in ax.spines.values():
            spine.set_visible(False)

        return ax
