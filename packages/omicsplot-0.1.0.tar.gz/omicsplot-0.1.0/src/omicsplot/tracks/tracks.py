"""
General-purpose genomic track types.

Each track renders a specific plot style across per-chromosome axes.
All tracks are independent of CN biology — they work for any genomic
signal (logR, coverage, SNV counts, GC content, etc.).
"""

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from .axes import filter_genome_size
from .base import _BaseTrack


# =============================================================================
# Concrete track types
# =============================================================================

class ScatterTrack(_BaseTrack):
    """
    Scatter plot across chromosomes.

    Suitable for: logR values, read depth points, SNV positions,
    allele frequency, any per-bin point data.

    Parameters
    ----------
    df : pd.DataFrame
    x_column : str
        Column for genomic position (default 'start').
    y_column : str
        Column for the value to plot (default 'value').
    ylabel : str, optional
    chrom_column : str
        Column for chromosome (default 'chrom').
    hue_column : str, optional
        Column for color grouping.
    palette : dict, optional
        Mapping of hue values to colors. Auto-generated if None and
        hue_column is given.
    s_column : str, optional
        Column for per-point sizes.
    s : float
        Fixed point size (default 1).
    hue_order : list, optional
        Order for hue categories.
    alpha : float
        Point transparency (default 0.7).
    ylim : tuple, optional
    highlight_df : pd.DataFrame, optional
        Columns: 'chrom', 'start', 'end'.
    style : {'facecolor', 'spine'}
    yscale : str
        'linear' or 'log' (default 'linear').
    **kwargs
        Forwarded to render / seaborn scatterplot.
        Notable: sizes=(min, max), edgecolor.
    """

    def __init__(self, df, x_column='start', y_column='value', ylabel=None,
                 chrom_column='chrom', hue_column=None, palette=None,
                 s_column=None, s=1, hue_order=None, alpha=0.7,
                 ylim=None, highlight_df=None, style='facecolor',
                 yscale='linear', **kwargs):
        super().__init__(df, ylabel=ylabel, ylim=ylim, highlight_df=highlight_df,
                         chrom_column=chrom_column, style=style, yscale=yscale,
                         **kwargs)
        self.x_column = x_column
        self.y_column = y_column
        self.hue_column = hue_column
        self.s_column = s_column
        self.s = s
        self.hue_order = hue_order
        self.alpha = alpha

        if palette is None and hue_column is not None:
            unique_hues = df[hue_column].dropna().unique()
            palette = dict(zip(unique_hues,
                               sns.color_palette('tab10', len(unique_hues))))
        self.palette = palette

    def _plot_chrom(self, ax, data, chrom_name, **kwargs):
        sizes    = kwargs.get('sizes',     (1, 4))
        edgecolor = kwargs.get('edgecolor', 'none')

        scatter_kw = dict(
            data=data, x=self.x_column, y=self.y_column,
            s=self.s, size=self.s_column, sizes=sizes,
            hue_order=self.hue_order,
            edgecolor=edgecolor, alpha=self.alpha, ax=ax,
        )
        if self.hue_column is not None:
            scatter_kw.update(hue=self.hue_column, palette=self.palette)
        sns.scatterplot(**scatter_kw)


class LineSegmentTrack(_BaseTrack):
    """
    Horizontal line segment track across chromosomes.

    Suitable for: copy number segments, any interval-valued data
    (peaks, domains, any [start, end] → value mapping).

    Parameters
    ----------
    df : pd.DataFrame
    x1_column : str
        Segment start column (default 'start').
    x2_column : str
        Segment end column (default 'end').
    y_column : str
        Value column (default 'value').
    ylabel : str, optional
    chrom_column : str
    hue_column : str, optional
        Column for color grouping.
    palette : dict, optional
        Mapping of hue values to colors.
    alpha : float
    linewidth : float
    ylim : tuple, optional
    highlight_df : pd.DataFrame, optional
    style : {'facecolor', 'spine'}
    yscale : str
    **kwargs
    """

    def __init__(self, df, x1_column='start', x2_column='end', y_column='value',
                 ylabel=None, chrom_column='chrom', hue_column=None, palette=None,
                 alpha=0.7, linewidth=1, ylim=None, highlight_df=None,
                 style='facecolor', yscale='linear', **kwargs):
        super().__init__(df, ylabel=ylabel, ylim=ylim, highlight_df=highlight_df,
                         chrom_column=chrom_column, style=style, yscale=yscale,
                         **kwargs)
        self.x1_column = x1_column
        self.x2_column = x2_column
        self.y_column = y_column
        self.hue_column = hue_column
        self.palette = palette
        self.alpha = alpha
        self.linewidth = linewidth

    def _plot_chrom(self, ax, data, chrom_name, **kwargs):
        for _, row in data.iterrows():
            color = 'black'
            if self.hue_column is not None and self.palette is not None:
                color = self.palette.get(row[self.hue_column], 'black')
            ax.hlines(
                y=row[self.y_column],
                xmin=row[self.x1_column], xmax=row[self.x2_column],
                color=color, linewidth=self.linewidth, alpha=self.alpha,
            )


class BarTrack(_BaseTrack):
    """
    Bar plot track across chromosomes.

    Suitable for: SNV/SV counts per bin, mutation burden, any count
    or density signal measured in discrete genomic windows.

    Parameters
    ----------
    df : pd.DataFrame
    x_column : str
        Bar position column (default 'start').
    y_column : str
        Bar height column (default 'value').
    ylabel : str, optional
    chrom_column : str
    width : float, optional
        Fixed bar width in bp. Inferred from median bin spacing if None.
    width_column : str, optional
        Per-row bar width column. Takes precedence over width.
    color : str
        Bar color (default 'steelblue').
    alpha : float
    ylim : tuple, optional
    highlight_df : pd.DataFrame, optional
    style : {'facecolor', 'spine'}
    yscale : str
    **kwargs
    """

    def __init__(self, df, x_column='start', y_column='value', ylabel=None,
                 chrom_column='chrom', width=None, width_column=None,
                 color='steelblue', alpha=0.8, ylim=None, highlight_df=None,
                 style='facecolor', yscale='linear', **kwargs):
        super().__init__(df, ylabel=ylabel, ylim=ylim, highlight_df=highlight_df,
                         chrom_column=chrom_column, style=style, yscale=yscale,
                         **kwargs)
        self.x_column = x_column
        self.y_column = y_column
        self.width = width
        self.width_column = width_column
        self.color = color
        self.alpha = alpha

    def _plot_chrom(self, ax, data, chrom_name, **kwargs):
        if data.empty:
            return
        if self.width_column is not None:
            widths = data[self.width_column].values
        elif self.width is not None:
            widths = self.width
        else:
            x_vals = data[self.x_column].values
            widths = float(np.median(np.diff(x_vals))) if len(x_vals) > 1 else 1.0
        ax.bar(
            data[self.x_column], data[self.y_column],
            width=widths, color=self.color, alpha=self.alpha,
            align='edge',
        )


class StepTrack(_BaseTrack):
    """
    Step-function track across chromosomes.

    Suitable for: GC content, read depth as a continuous coverage
    profile, any signal that is constant within genomic bins.

    Parameters
    ----------
    df : pd.DataFrame
    start_column : str
        Bin start column (default 'start').
    end_column : str
        Bin end column (default 'end').
    y_column : str
        Value column (default 'value').
    ylabel : str, optional
    chrom_column : str
    color : str
        Line color (default 'steelblue').
    alpha : float
    linewidth : float
    fill : bool
        Fill area under the curve (default False).
    fill_alpha : float
        Fill transparency (default 0.2).
    ylim : tuple, optional
    highlight_df : pd.DataFrame, optional
    style : {'facecolor', 'spine'}
    yscale : str
    **kwargs
    """

    def __init__(self, df, start_column='start', end_column='end',
                 y_column='value', ylabel=None, chrom_column='chrom',
                 color='steelblue', alpha=0.8, linewidth=1,
                 fill=False, fill_alpha=0.2,
                 ylim=None, highlight_df=None,
                 style='facecolor', yscale='linear', **kwargs):
        super().__init__(df, ylabel=ylabel, ylim=ylim, highlight_df=highlight_df,
                         chrom_column=chrom_column, style=style, yscale=yscale,
                         **kwargs)
        self.start_column = start_column
        self.end_column = end_column
        self.y_column = y_column
        self.color = color
        self.alpha = alpha
        self.linewidth = linewidth
        self.fill = fill
        self.fill_alpha = fill_alpha

    def _plot_chrom(self, ax, data, chrom_name, **kwargs):
        if data.empty:
            return
        starts = data[self.start_column].values
        ends   = data[self.end_column].values
        ys     = data[self.y_column].values

        # Build step arrays: each bin contributes [start, end] at its y value
        xs = np.empty(len(starts) * 2)
        xs[0::2] = starts
        xs[1::2] = ends
        ys_step = np.repeat(ys, 2)

        ax.plot(xs, ys_step, color=self.color, alpha=self.alpha,
                linewidth=self.linewidth)
        if self.fill:
            ax.fill_between(xs, ys_step, alpha=self.fill_alpha, color=self.color)


# =============================================================================
# Layout function
# =============================================================================

def plot_tracks(tracks, genome_size, chrom=[], showX=True,
                width=6, height_per_track=0.8,
                figsize=None,
                font_family='Helvetica', font_size=7,
                hspace=0.1, **kwargs):
    """
    Plot one or more tracks stacked vertically.

    Works with any track that implements the .render() interface.

    Parameters
    ----------
    tracks : _BaseTrack or list of _BaseTrack
        Track objects to plot.
    genome_size : pd.DataFrame
        Columns: 'chrom', 'length'.
    chrom : list
        Chromosomes to include. Empty = all autosomes + chrX (if showX).
    showX : bool
        Include chrX when chrom is empty.
    width : float
        Figure width in inches (default 6).
    height_per_track : float
        Height in inches for each track (default 0.8). Total figure height =
        roughly height_per_track * n_tracks. Tracks that implement
        preferred_height(width) override this value for themselves
        (e.g. SVTriangleTrack sizes itself to fill the width).
    figsize : tuple, optional
        Deprecated. Pass (width, height_per_track) as a tuple. If given,
        overrides the width and height_per_track arguments.
    font_family : str
    font_size : int
    hspace : float
        Vertical space between tracks, as a fraction of average track height
        (default 0.1). Pass a smaller value to tighten spacing.
    **kwargs
        Forwarded to each track's render().

    Returns
    -------
    fig : matplotlib.figure.Figure
    axes : np.ndarray, shape (n_tracks, n_chroms)
    """
    if figsize is not None:
        width, height_per_track = figsize

    if not isinstance(tracks, list):
        tracks = [tracks]

    gs = filter_genome_size(genome_size, chrom, showX)
    n_tracks = len(tracks)
    n_chroms = len(gs)
    widths = list(gs['length'])

    track_heights = [
        t.preferred_height(width) if hasattr(t, 'preferred_height')
        else height_per_track
        for t in tracks
    ]

    with plt.rc_context({'font.family': font_family, 'font.size': font_size}):
        fig, axes = plt.subplots(
            n_tracks, n_chroms,
            figsize=(width, sum(track_heights)),
            gridspec_kw={'width_ratios': widths, 'height_ratios': track_heights},
            squeeze=False,
        )
        plt.subplots_adjust(wspace=0, hspace=hspace)

        for i, track in enumerate(tracks):
            is_last = (i == n_tracks - 1)
            track.render(
                axes[i], genome_size,
                chrom=chrom,
                showX=showX,
                show_chrom_labels=is_last,
                font_family=font_family,
                font_size=font_size,
                **kwargs,
            )

    return fig, axes
