"""
Unit system for layout, similar to R's grid::unit().

Provides absolute units (mm, cm, inch, pt), relative units (npc),
and flexible units (null) for size-driven layout.
"""

import numpy as np


class Unit:
    """
    A measurement unit for layout, similar to R's grid::unit().

    Supports:
    - Absolute units: 'mm', 'cm', 'inch', 'pt'
    - Relative units: 'npc' (normalized parent coordinates, 0-1)
    - Flexible units: 'null' (takes remaining space proportionally)

    Examples:
    ---------
    >>> unit(5, 'mm')           # 5 millimeters
    >>> unit(1, 'cm')           # 1 centimeter
    >>> unit(0.5, 'inch')       # 0.5 inches
    >>> unit(0.1, 'npc')        # 10% of parent size
    >>> unit(1, 'null')         # 1 share of remaining space
    >>> unit(5, 'mm') + unit(0.1, 'npc')  # Combined unit
    """

    # Conversion factors to inches
    _TO_INCH = {
        'inch': 1.0,
        'in': 1.0,
        'mm': 1.0 / 25.4,
        'cm': 1.0 / 2.54,
        'pt': 1.0 / 72.0,
    }

    def __init__(self, value, unit_type='mm'):
        self.value = value
        self.type = unit_type.lower()

        if self.type not in self._TO_INCH and self.type not in ('npc', 'null'):
            raise ValueError(f"Unknown unit type: {unit_type}. "
                           f"Supported: {list(self._TO_INCH.keys()) + ['npc', 'null']}")

    def is_absolute(self):
        """Check if this is an absolute unit (mm, cm, inch, pt)."""
        return self.type in self._TO_INCH

    def is_relative(self):
        """Check if this is a relative unit (npc)."""
        return self.type == 'npc'

    def is_null(self):
        """Check if this is a null unit (flexible space)."""
        return self.type == 'null'

    def to_inches(self, parent_size=None):
        """
        Convert to inches.

        Parameters:
        -----------
        parent_size : float, optional
            Parent size in inches (required for 'npc' units).

        Returns:
        --------
        float or None
            Size in inches, or None for 'null' units.
        """
        if self.is_absolute():
            return self.value * self._TO_INCH[self.type]
        elif self.is_relative():
            if parent_size is None:
                raise ValueError("parent_size required for 'npc' units")
            return self.value * parent_size
        else:  # null
            return None

    def __add__(self, other):
        if isinstance(other, (int, float)):
            other = Unit(other, self.type)
        return CompositeUnit([self, other], ['+'])

    def __radd__(self, other):
        if other == 0:  # For sum()
            return self
        return self.__add__(other)

    def __mul__(self, scalar):
        return Unit(self.value * scalar, self.type)

    def __rmul__(self, scalar):
        return self.__mul__(scalar)

    def __repr__(self):
        return f"unit({self.value}, '{self.type}')"


class CompositeUnit:
    """A combination of multiple units (e.g., 5mm + 0.1npc)."""

    def __init__(self, units, operators):
        self.units = list(units)
        self.operators = list(operators)

    def to_inches(self, parent_size=None):
        """Resolve composite unit to inches."""
        result = self.units[0].to_inches(parent_size)
        if result is None:
            raise ValueError("Cannot resolve composite unit containing 'null'")

        for i, op in enumerate(self.operators):
            val = self.units[i + 1].to_inches(parent_size)
            if val is None:
                raise ValueError("Cannot resolve composite unit containing 'null'")
            if op == '+':
                result += val
            elif op == '-':
                result -= val

        return result

    def __add__(self, other):
        if isinstance(other, Unit):
            return CompositeUnit(self.units + [other], self.operators + ['+'])
        elif isinstance(other, CompositeUnit):
            return CompositeUnit(self.units + other.units,
                               self.operators + ['+'] + other.operators)
        else:
            raise TypeError(f"Cannot add CompositeUnit and {type(other)}")

    def __repr__(self):
        parts = [repr(self.units[0])]
        for i, op in enumerate(self.operators):
            parts.append(op)
            parts.append(repr(self.units[i + 1]))
        return ' '.join(parts)


def unit(value, unit_type='mm'):
    """
    Create a Unit object.

    Convenience function similar to R's unit().

    Parameters:
    -----------
    value : float
        The numeric value.
    unit_type : str
        Unit type: 'mm', 'cm', 'inch', 'pt', 'npc', or 'null'.

    Returns:
    --------
    Unit
        A Unit object.

    Examples:
    ---------
    >>> unit(5, 'mm')      # 5 millimeters
    >>> unit(1, 'null')    # 1 share of flexible space
    """
    return Unit(value, unit_type)


class LayoutEngine:
    """
    Resolves a list of Units into absolute positions.

    Handles mixed absolute, relative, and null units.
    """

    @staticmethod
    def resolve(sizes, total_size):
        """
        Resolve a list of sizes to absolute values in inches.

        Parameters:
        -----------
        sizes : list of Unit
            List of size specifications.
        total_size : float
            Total available size in inches.

        Returns:
        --------
        list of float
            Resolved sizes in inches.
        """
        n = len(sizes)
        resolved = [None] * n

        # First pass: resolve absolute and relative units
        null_indices = []
        null_total = 0
        used_space = 0

        for i, s in enumerate(sizes):
            if isinstance(s, (int, float)):
                # Treat raw numbers as mm
                resolved[i] = s / 25.4
                used_space += resolved[i]
            elif isinstance(s, (Unit, CompositeUnit)):
                if isinstance(s, Unit) and s.is_null():
                    null_indices.append(i)
                    null_total += s.value
                else:
                    resolved[i] = s.to_inches(total_size)
                    used_space += resolved[i]
            else:
                raise TypeError(f"Expected Unit, got {type(s)}")

        # Second pass: distribute remaining space to null units
        remaining = total_size - used_space
        if null_indices:
            if remaining < 0:
                remaining = 0  # Clamp to avoid negative sizes
            for i in null_indices:
                share = sizes[i].value / null_total if null_total > 0 else 1
                resolved[i] = remaining * share

        return resolved

    @staticmethod
    def compute_positions(sizes):
        """
        Compute cumulative positions from sizes.

        Parameters:
        -----------
        sizes : list of float
            List of sizes in inches.

        Returns:
        --------
        list of float
            Starting positions for each element.
        """
        positions = [0]
        for s in sizes[:-1]:
            positions.append(positions[-1] + s)
        return positions
