"""
Absolute-coordinate layout engine for heatmap composition.

Three-phase pipeline
--------------------
1. measure(hm)            → PanelLayout   (sizes for one leaf heatmap)
2. layout_info(item)      → LayoutSummary (sizes for any item, recursive)
3. compute_placements(item, x0, y0)
                          → list[(hm, body_x, body_y)]
                            absolute body positions for every leaf heatmap,
                            where (0, 0) is the top-left of the figure.

These functions contain no matplotlib calls.  The caller creates the figure
with the returned dimensions and calls hm.draw_placed(fig, body_x, body_y)
for each (hm, body_x, body_y) tuple.
"""

from dataclasses import dataclass


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

@dataclass
class PanelLayout:
    """All component sizes (inches) for one leaf Heatmap."""
    body_w: float
    body_h: float
    # Left-of-body components (left to right)
    row_cluster_dend_w: float
    row_dend_w: float
    left_annot_w: float
    # Right-of-body components (left to right)
    right_annot_w: float
    row_names_w: float
    colorbar_gap: float
    colorbar_w: float
    colorbar_h: float          # height of colorbar bar itself
    annot_legend_gap: float
    annot_legend_w: float
    # Above-body components (top to bottom)
    title_h: float
    col_dend_h: float
    top_annot_h: float
    # Below-body components (top to bottom)
    bottom_annot_h: float
    col_names_h: float

    # ----- derived aggregates ------------------------------------------------

    @property
    def left_side(self):
        return self.row_cluster_dend_w + self.row_dend_w + self.left_annot_w

    @property
    def top_side(self):
        return self.title_h + self.col_dend_h + self.top_annot_h

    @property
    def right_side(self):
        return (self.right_annot_w + self.row_names_w
                + self.colorbar_gap + self.colorbar_w
                + self.annot_legend_gap + self.annot_legend_w)

    @property
    def bottom_side(self):
        return self.bottom_annot_h + self.col_names_h

    @property
    def total_w(self):
        return self.left_side + self.body_w + self.right_side

    @property
    def total_h(self):
        return self.top_side + self.body_h + self.bottom_side


@dataclass
class LayoutSummary:
    """Minimal layout description for a node in the composition tree."""
    left_side: float   # decoration width to the left of the leftmost body
    top_side: float    # decoration height above the topmost body
    total_w: float
    total_h: float


# ---------------------------------------------------------------------------
# Phase 1 — measure
# ---------------------------------------------------------------------------

def measure(hm):
    """
    Return a PanelLayout for *hm* based on its current state.

    Call this *after* clustering has been computed and after any
    show_colorbar / show_legend suppression so that the sizes reflect
    what will actually be drawn.
    """
    L = hm._compute_layout()

    colorbar_gap = 0.05 if (L['colorbar_width'] > 0 and L['row_names_width'] == 0) else 0
    legend_gap   = 0.3  if L['annotation_legend_width'] > 0 else 0

    return PanelLayout(
        body_w=L['heatmap_width'],
        body_h=L['heatmap_height'],
        row_cluster_dend_w=L['row_cluster_dend_width'],
        row_dend_w=L['row_dend_width'],
        left_annot_w=L['left_annot_width'],
        right_annot_w=L['right_annot_width'],
        row_names_w=L['row_names_width'],
        colorbar_gap=colorbar_gap,
        colorbar_w=L['colorbar_width'],
        colorbar_h=hm.colorbar_height.to_inches() if L['colorbar_width'] > 0 else 0,
        annot_legend_gap=legend_gap,
        annot_legend_w=L['annotation_legend_width'],
        title_h=L['title_height'],
        col_dend_h=L['col_dend_height'],
        top_annot_h=L['top_annot_height'],
        bottom_annot_h=L['bottom_annot_height'],
        col_names_h=L['col_names_height'],
    )


# ---------------------------------------------------------------------------
# Phase 2 — layout_info  (recursive, works on hm / concat / stack)
# ---------------------------------------------------------------------------

def layout_info(item):
    """
    Return a LayoutSummary for *item*, which can be a Heatmap,
    HeatmapConcat, or HeatmapStack.

    For a Heatmap the summary is derived from its PanelLayout.
    For groups the summary is derived recursively from child summaries.
    """
    from .heatmap import Heatmap
    from .concat import HeatmapConcat, HeatmapStack

    if isinstance(item, Heatmap):
        pl = measure(item)
        return LayoutSummary(
            left_side=pl.left_side,
            top_side=pl.top_side,
            total_w=pl.total_w,
            total_h=pl.total_h,
        )

    elif isinstance(item, HeatmapConcat):
        infos = [layout_info(child) for child in item.heatmaps]
        max_top = max(i.top_side for i in infos)
        # Each child is shifted down by (max_top - child.top_side); its
        # effective total height is that shift plus its own total_h.
        eff_h = max(max_top - i.top_side + i.total_h for i in infos)
        return LayoutSummary(
            left_side=infos[0].left_side,
            top_side=max_top,
            total_w=sum(i.total_w for i in infos),
            total_h=eff_h,
        )

    elif isinstance(item, HeatmapStack):
        infos = [layout_info(row) for row in item.rows]
        max_left = max(i.left_side for i in infos)
        eff_w = max(max_left - i.left_side + i.total_w for i in infos)
        return LayoutSummary(
            left_side=max_left,
            top_side=infos[0].top_side,
            total_w=eff_w,
            total_h=sum(i.total_h for i in infos),
        )

    else:
        raise TypeError(f"Unknown item type: {type(item)}")


# ---------------------------------------------------------------------------
# Phase 3 — compute_placements  (recursive)
# ---------------------------------------------------------------------------

def compute_placements(item, x_origin, y_origin):
    """
    Return a flat list of ``(hm, body_x, body_y)`` tuples for every leaf
    Heatmap reachable from *item*.

    *x_origin* and *y_origin* are the top-left corner of the region
    allocated to *item*, in inches from the figure's top-left corner.

    The function adjusts y_origin / x_origin per child so that bodies
    align across siblings before recursing.
    """
    from .heatmap import Heatmap
    from .concat import HeatmapConcat, HeatmapStack

    if isinstance(item, Heatmap):
        pl = measure(item)
        return [(item, x_origin + pl.left_side, y_origin + pl.top_side)]

    elif isinstance(item, HeatmapConcat):
        infos = [layout_info(child) for child in item.heatmaps]
        max_top = max(i.top_side for i in infos)

        result = []
        x_cursor = x_origin
        for child, info in zip(item.heatmaps, infos):
            # Shift each child down so its body lands at (x_cursor + info.left_side,
            # y_origin + max_top).
            child_y = y_origin + max_top - info.top_side
            result.extend(compute_placements(child, x_cursor, child_y))
            x_cursor += info.total_w
        return result

    elif isinstance(item, HeatmapStack):
        infos = [layout_info(row) for row in item.rows]
        max_left = max(i.left_side for i in infos)

        result = []
        y_cursor = y_origin
        for row, info in zip(item.rows, infos):
            # Shift each row right so its body lands at (x_origin + max_left,
            # y_cursor + info.top_side).
            child_x = x_origin + max_left - info.left_side
            result.extend(compute_placements(row, child_x, y_cursor))
            y_cursor += info.total_h
        return result

    else:
        raise TypeError(f"Unknown item type: {type(item)}")


# ---------------------------------------------------------------------------
# Figure-size helpers
# ---------------------------------------------------------------------------

FIGURE_MARGIN = 0.1   # inches of breathing room on right and bottom edges


def figure_size_for_concat(item, unified_panel_w=0.0):
    """
    Return (fig_w, fig_h) in inches for a top-level HeatmapConcat.
    *item* is the HeatmapConcat itself.
    """
    from .concat import HeatmapConcat
    infos = [layout_info(child) for child in item.heatmaps]
    max_top = max(i.top_side for i in infos)
    fig_h = max(max_top - i.top_side + i.total_h for i in infos) + FIGURE_MARGIN
    fig_w = sum(i.total_w for i in infos) + unified_panel_w + FIGURE_MARGIN
    return fig_w, fig_h


def figure_size_for_stack(item, unified_panel_w=0.0):
    """
    Return (fig_w, fig_h) in inches for a top-level HeatmapStack.
    *item* is the HeatmapStack itself.
    """
    infos = [layout_info(row) for row in item.rows]
    max_left = max(i.left_side for i in infos)
    fig_w = max(max_left - i.left_side + i.total_w for i in infos) + unified_panel_w + FIGURE_MARGIN
    fig_h = sum(i.total_h for i in infos) + FIGURE_MARGIN
    return fig_w, fig_h
