# `omicsheatmap` — Structure and Logic Reference

## Overview

`omicsheatmap` is a ComplexHeatmap-inspired layout system for publication-quality heatmaps.
The user specifies the **physical size** of the heatmap body (in mm or inches), and all
surrounding panels (dendrograms, annotations, labels, colorbar, legend) are added around it
without shrinking the body.

The module is split across three files:

| File | Responsibility |
|---|---|
| `heatmap.py` | Single-heatmap rendering engine |
| `layout.py` | Pure-geometry layout engine: measure component sizes, compute absolute body positions |
| `concat.py` | Multi-heatmap composition (`\|` and `/` operators) |

Public-facing names from `heatmap.py`:
- `HeatmapAnnotation` — annotation track container
- `Heatmap` — the main heatmap builder
- `clustermap()` — simplified convenience wrapper around `Heatmap`

Public-facing names from `concat.py`:
- `HeatmapConcat` — side-by-side layout (`A | B`)
- `HeatmapStack` — vertically stacked layout (`A / B`)
- `HeatmapConcatResult` — result container returned by both

---

## Class: `HeatmapAnnotation`

A container for one or more annotation tracks placed adjacent to the heatmap body (top, bottom,
left, or right). Tracks are passed as keyword arguments (e.g. `HeatmapAnnotation(Cluster=series)`).

### Key attributes

| Attribute | Purpose |
|---|---|
| `annotations` | Raw dict of `{name: data}` passed by caller |
| `_processed` | Normalized form after `_process_annotation()` — all converted to `{'type': ..., 'data': ...}` dicts |
| `segment_gap` | If set, inserts a physical gap between consecutive groups (where the annotation value changes). This is what drives cluster-group visual separation in the heatmap. |
| `show_labels` | `False`, `True`, or `'right'`. `True` draws labels on the natural outside edge of the annotation. `'right'` defers to `Heatmap._draw_annotation_labels_right()`. |
| `_segments` | Computed during `draw()` — list of `(start, end)` index ranges, one per contiguous group. |
| `_segment_position_offset` | Computed during `draw()` — array of length `n_items`; each entry is the cumulative y-offset (in data coordinates) added to item `i` due to gaps before it. |

### Key methods

**`_process_annotation(ann)`**
Normalizes input to `{'type': 'simple', 'data': Series}`. Arrays are wrapped in a Series.

**`_find_segment_boundaries(data)`**
Scans for value-change boundaries in ordered data. Returns `[(start, end), ...]` — one tuple
per contiguous run of the same value.

**`draw(ax, order, orientation, ...)`**
The main drawing method. Steps:
1. Applies `order` to reindex data.
2. Computes `_segments` and `_segment_position_offset` from the (reindexed) first track.
3. Sets `ax` limits: x = annotation track space, y = data space with gaps.
4. For each track, draws colored rectangles using `imshow` per segment (or one call if no gaps).
5. Calls `_draw_labels()` if `show_labels` is truthy and not `'right'`.

**`_get_colors(data, name, palette)`**
Maps annotation values to colors. Priority: `self.colors[name]` → `palette[name]` → auto tab10 palette.

**`_draw_labels(ax, order, orientation, position)`**
Draws text labels at segment centers, using `ax.get_xaxis_transform()` or `get_yaxis_transform()`
so labels sit just outside the annotation axes boundary, unclipped.

---

## Class: `Heatmap`

The main class. Users construct it with data + styling params, optionally call `add_*_annotation()`,
then call `draw()` to get a `HeatmapResult`.

### Initialization

`__init__` stores all parameters as instance attributes. No drawing occurs here.
Notable parameters:

| Parameter | Purpose |
|---|---|
| `width`, `height` | Physical size of the heatmap body (default 50mm each) |
| `figsize` | Alternative: specify total figure size; body fills the remainder |
| `row_cluster`, `col_cluster` | `False` / `True` / pre-computed linkage `np.ndarray` |
| `row_cluster_dendrogram` | A separate linkage matrix where each leaf = one cluster group (not one row) |
| `row_cluster_dendrogram_size` | Width of the cluster-dendrogram panel |
| `segment_linewidth/color` | Borders drawn around each cluster block when `segment_gap` is active |

### Annotation slots

Four annotation slots, each holding at most one `HeatmapAnnotation`:

```
top_annotation     → above heatmap body
bottom_annotation  → below heatmap body
left_annotation    → left of heatmap body   (drives row grouping / segment_gap)
right_annotation   → right of heatmap body
```

Added via `add_top_annotation()`, `add_left_annotation()`, etc.

### Rendering pipeline (`draw()`)

`draw()` orchestrates everything in this order:

```
_validate_segment_gap_clustering()   check segment_gap not combined with clustering
_compute_clustering()                compute row/col order and linkage matrices
_compute_layout()                    calculate all panel sizes in inches
create figure + GridSpec             allocate matplotlib axes
draw panels (in order):
  title
  column dendrogram
  cluster dendrogram (row_cluster_dendrogram)
  row dendrogram
  top annotation
  left annotation
  heatmap body  (_draw_heatmap)
  right-side annotation labels  (_draw_annotation_labels_right, if show_labels='right')
  right annotation
  bottom annotation
  row names
  column names
  colorbar
  annotation legend
return HeatmapResult
```

### GridSpec column layout (standalone `draw()`)

Columns from left to right (only present if their width > 0):

```
[cluster_dend] [row_dend] [left_annot] [heatmap] [right_annot] [row_names/gap] [colorbar] [gap] [legend]
      0              1          2           3           4             5              6         7      8
```

The heatmap column index (`heatmap_col`) is computed by counting how many optional left-side
columns are present. Downstream panels (colorbar, legend) are positioned relative to `heatmap_col`.

Note: this GridSpec-based layout is used **only** for standalone `draw()`. When called as part
of a concat/stack, `draw_placed()` is used instead (see below).

### Key private methods

**`_compute_clustering()`**
Fills `_row_order`, `_col_order`, `_row_linkage`, `_col_linkage`. Handles three input modes
for `row_cluster`/`col_cluster`: `False` (identity order), `True` (compute from data),
`np.ndarray` (use as pre-computed linkage). Custom `row_order` / `col_order` override clustering entirely.

**`_compute_layout()`**
Returns a dict of all panel sizes in inches (e.g. `layout['row_dend_width']`, `layout['heatmap_height']`).
Also handles:
- `figsize` mode: derives body size from figure size minus peripherals.
- `show_labels='right'` on left annotation: allocates a `row_names_width` slot to push
  colorbar/legend right, making room for clip-on-False annotation labels.

**`draw_placed(fig, body_x, body_y_from_top)`**
Used by `HeatmapConcat` / `HeatmapStack` to render a panel at exact absolute figure coordinates.
Both `body_x` and `body_y_from_top` are in inches from the figure's top-left corner.

Internally calls `layout.measure(self)` to get component sizes, then places every axis
(dendrograms, annotations, body, names, colorbar) with `fig.add_axes([x/fw, y/fh, w/fw, h/fh])`.
Because positions are absolute rather than fractional subdivisions, body alignment is exact
regardless of how many decorations surround each panel.

**`_get_row_segment_gap_info()` / `_get_col_segment_gap_info()`**
Inspect the left/right (or top/bottom) annotation for `segment_gap`. Returns a dict with:
- `segments`: `[(start, end), ...]` in reordered space
- `position_offset`: per-item cumulative y-offset (in data coordinates = cell heights)
- `gap_size`: gap in data coordinates

This dict is the single source of truth for where cluster group boundaries are, consumed
by `_draw_heatmap`, `_draw_cluster_dendrogram`, `_draw_annotation_labels_right`, and `_draw_row_names`.

**`_draw_heatmap(ax)`**
Draws the main body. Two code paths:
- **No gaps**: single `imshow` call on the full matrix.
- **With gaps** (when `segment_gap` is active): iterates over `(row_segment, col_segment)` pairs
  and issues one `imshow` per block. Cell borders and cell annotations are also drawn per-block.

Sets `ax.xlim` / `ax.ylim` to match the total data extent including gap space. Stores
`self._heatmap_mappable` for the colorbar.

**`_draw_dendrogram(ax, linkage_matrix, orientation)`**
Standard row/column dendrogram. Scipy leaf positions (5, 15, 25...) are rescaled to data
coordinates (0, 1, 2...) by `(icoord - 5) / 10`.

**`_draw_cluster_dendrogram(ax, cluster_linkage)`**
Cluster-level dendrogram where each leaf is a cluster group (not an individual row).

Steps:
1. Reads `_get_row_segment_gap_info()` to find cluster centers in data coordinates.
2. Calls `scipy.dendrogram(no_plot=True)` to get raw icoord/dcoord.
3. Remaps icoord from scipy's default leaf positions (5, 15, 25...) to actual cluster
   y-centers using `np.interp`.
4. Replaces `dcoord == 0` (leaf baseline) with `x_min = min_merge - 5% * internal_span`
   so every leaf gets a short, uniform stub regardless of when it merges.
5. Draws with `ax.plot(dcoord, icoord_remapped)` and sets xlim/ylim to match the heatmap.

**`_draw_annotation_labels_right(ax_heatmap)`**
Draws left-annotation group labels on the **right side** of the heatmap body. Called after
`_draw_heatmap` so the axes position is finalized. Uses `ax.get_yaxis_transform()` + `clip_on=False`
so text renders past the right edge of the heatmap axes.

**`_measure_text_size(labels, fontsize, rotation)`**
Renders text in a temporary off-screen figure to get actual pixel extents, then converts to
inches. Used to auto-size the row names column and the right-label space.

---

## Class: `HeatmapResult`

Simple data container returned by `draw()`:

| Attribute | Content |
|---|---|
| `fig` | The matplotlib Figure |
| `axes` | Dict of named axes: `'heatmap'`, `'row_dendrogram'`, `'left_annotation'`, `'colorbar'`, etc. |
| `row_order`, `col_order` | Integer index arrays (reordered positions in original data) |
| `row_linkage`, `col_linkage` | Linkage matrices (or None if no clustering) |
| `data` | The reordered, normalized data matrix |

---

## Function: `clustermap()`

A thin convenience wrapper around `Heatmap`. Converts `row_colors` / `col_colors` into
`HeatmapAnnotation` objects and calls `hm.draw()`. Exposes a subset of `Heatmap` parameters.

---

## Module: `layout.py` — Absolute-coordinate layout engine

`layout.py` is a pure-geometry module with no matplotlib calls. It implements the three-phase
pipeline used by `concat.py` to compute exact body positions before any drawing occurs.

### Phase 1 — `measure(hm)` → `PanelLayout`

Calls `hm._compute_layout()` and extracts all component sizes into a `PanelLayout` dataclass.
Must be called after clustering is computed and after `show_colorbar` / `show_legend` suppression,
so the sizes reflect what will actually be drawn.

`PanelLayout` exposes derived aggregates:

| Property | Value |
|---|---|
| `left_side` | `row_cluster_dend_w + row_dend_w + left_annot_w` |
| `top_side` | `title_h + col_dend_h + top_annot_h` |
| `right_side` | `right_annot_w + row_names_w + colorbar_gap + colorbar_w + legend_gap + legend_w` |
| `bottom_side` | `bottom_annot_h + col_names_h` |
| `total_w` | `left_side + body_w + right_side` |
| `total_h` | `top_side + body_h + bottom_side` |

### Phase 2 — `layout_info(item)` → `LayoutSummary`

Works recursively on any item (leaf `Heatmap`, `HeatmapConcat`, or `HeatmapStack`).
Returns `LayoutSummary(left_side, top_side, total_w, total_h)`.

For a `HeatmapConcat`:
```
left_side  = first child's left_side        (leftmost body's left decorations)
top_side   = max(child.top_side)            (shared body-top alignment target)
total_w    = sum(child.total_w)
total_h    = max(top_max − child.top_side + child.total_h)   (tallest effective extent)
```

For a `HeatmapStack`:
```
left_side  = max(child.left_side)           (shared body-left alignment target)
top_side   = first child's top_side         (topmost body's top decorations)
total_w    = max(left_max − child.left_side + child.total_w)
total_h    = sum(child.total_h)
```

### Phase 3 — `compute_placements(item, x0, y0)` → `[(hm, body_x, body_y), ...]`

Returns a flat list of `(hm, body_x, body_y)` tuples for every leaf `Heatmap` in the tree.
Coordinates are in inches from the figure's top-left corner.

The key operation at each level is adjusting the child's `y_origin` (concat) or `x_origin`
(stack) so all siblings' bodies land at the same absolute coordinate:

```python
# HeatmapConcat: align on y
max_top = max(info.top_side for info in child_infos)
for child, info in zip(children, child_infos):
    child_y = y_origin + max_top - info.top_side   # shift so body lands at y_origin + max_top
    placements += compute_placements(child, x_cursor, child_y)
    x_cursor += info.total_w

# HeatmapStack: align on x
max_left = max(info.left_side for info in child_infos)
for row, info in zip(rows, child_infos):
    child_x = x_origin + max_left - info.left_side  # shift so body lands at x_origin + max_left
    placements += compute_placements(row, child_x, y_cursor)
    y_cursor += info.total_h
```

---

## Module: `concat.py` — Multi-heatmap composition

### Design goals

Three properties distinguish a composed heatmap from "just a grid":

1. **Size consistency** — `A | B` forces matching body height; `A / B` forces matching body
   width, so individual cells are the same physical size across all panels.
2. **Body alignment** — even when panels carry different amounts of decoration (dendrograms,
   annotations, titles), the heatmap bodies always land at the same absolute pixel position.
   Achieved via `layout.compute_placements()` + `hm.draw_placed()` — no GridSpec subdivision.
3. **Unified colorbar + legend** — individual colorbars and annotation legends are suppressed
   on each leaf; a single shared panel on the right of the figure collects them all.

### Expression syntax

```python
A | B          # HeatmapConcat — side by side, body heights synced
A / B          # HeatmapStack  — stacked, body widths synced
(A | B) / C    # compound: HeatmapStack([HeatmapConcat([A, B]), C])
A | B | C      # flattened: HeatmapConcat([A, B, C]) — not nested
```

### State mutation and restoration

`draw()` temporarily mutates leaf `Heatmap` objects (syncing `height` or `width`, suppressing
`show_colorbar`, suppressing annotation `show_legend`). All mutations are wrapped in
`try/finally` blocks that restore original state even if drawing raises an exception.

Crucially, `layout.measure()` is called **after** suppression, so the panel sizes used for
placement reflect what is actually drawn (no colorbar/legend space in leaf panels).

### Class: `HeatmapConcat`

Created by `A | B`. Holds a flat list `self.heatmaps` of panels (each may be a `Heatmap`
or another `HeatmapConcat` / `HeatmapStack`).

`__or__` flattens: `(A | B) | C` produces `HeatmapConcat([A, B, C])`, not nested concats.

`draw(share_row_order=True)` flow:
1. Cluster all leaves; optionally sync row order from first leaf to the rest.
2. Sync all body heights to first leaf.
3. Suppress colorbars and annotation legends; record originals.
4. Call `layout.figure_size_for_concat()` → `(fig_w, fig_h)`.
5. Call `layout.compute_placements(self, 0, 0)` → `[(hm, body_x, body_y), ...]`.
6. Create figure; call `hm.draw_placed(fig, body_x, body_y)` for each placement.
7. Draw unified colorbar + legend panel on the right.
8. `finally`: restore all state.

### Class: `HeatmapStack`

Created by `A / B`. Holds a flat list `self.rows`.

`__truediv__` flattens: `(A / B) / C` produces `HeatmapStack([A, B, C])`.

`draw(share_col_order=True)` flow is symmetric to `HeatmapConcat.draw()`, with roles swapped:
- Syncs body **widths** instead of heights.
- Aligns on `left_side` instead of `top_side`.

### Unified colorbar + legend panel

The right-side panel collects all leaf colorbars and all annotation legends:

- **Width** is calculated by `_unified_panel_width()`: colorbar width + 0.2 gap + legend width.
  Returns 0 if neither colorbars nor legends are needed.
- **Colorbars** are stacked top-to-bottom, one per leaf that originally had `show_colorbar=True`.
  Uses `hm._heatmap_mappable` (stored by `Heatmap._draw_heatmap()` after drawing the body).
- **Annotation legends** are drawn by `_draw_combined_legend()`, which deduplicates tracks
  by name (so the same annotation used in multiple panels appears only once).

### Class: `HeatmapConcatResult`

Simple container:

| Attribute | Content |
|---|---|
| `fig` | The matplotlib Figure |
| `results` | List of `HeatmapResult` objects (one per leaf, in placement order) |

---

## Coordinate system conventions

| Axis | Convention |
|---|---|
| Heatmap body x | 0 = left column center, n_cols-1 = right column center; xlim = (-0.5, total_width-0.5) |
| Heatmap body y | 0 = top row center (y=0 at top), n_rows-1 = bottom row center; ylim = (total_height-0.5, -0.5) — inverted |
| Annotation (vertical) | Same y-axis as heatmap; x = annotation track space |
| Cluster dendrogram x | Linkage distance; xlim reversed (max_d → x_min) so tree root is leftmost |
| Gap offsets | In data coordinates: position of item i = i + position_offset[i] |
| Layout coordinates | `layout.py` uses top-left = (0, 0) with y increasing downward (inches). Converted to matplotlib's bottom-left origin inside `draw_placed()`. |

---

## Data flow summary

### Single heatmap

```
user data (DataFrame)
        │
        ▼
_compute_clustering()
  → _row_order, _col_order   (index arrays)
  → _row_linkage, _col_linkage
        │
        ▼
_compute_layout()
  → dict of panel sizes in inches
        │
        ▼
draw(fig=None, subplot_spec=None)
  → GridSpec allocation (from figure or from subplot_spec)
  → _draw_heatmap()  ← reads _get_row/col_segment_gap_info()
  → _draw_cluster_dendrogram()  ← reads same gap info for cluster centers
  → _draw_annotation_labels_right()  ← reads same gap info for label positions
  → colorbar, legend, names
        │
        ▼
HeatmapResult (fig, axes, row_order, ...)
```

### Composed heatmaps (concat.py + layout.py)

```
HeatmapConcat([A, B]) or HeatmapStack([A, B])
        │
        ▼
_get_leaves()  → [A, B, ...]   flat list of Heatmap objects
Cluster all leaves; sync body height (concat) or width (stack)
Suppress colorbar / legend on all leaves
        │
        ▼
layout.figure_size_for_concat/stack()
  → calls layout_info() recursively
  → returns (fig_w, fig_h) in inches
        │
        ▼
layout.compute_placements(self, x0=0, y0=0)
  → recurses through concat/stack tree
  → returns [(hm, body_x, body_y), ...]  — absolute inch coordinates
        │
        ▼
plt.figure(figsize=(fig_w, fig_h))
for hm, body_x, body_y in placements:
    hm.draw_placed(fig, body_x, body_y)
      → layout.measure(hm)  → PanelLayout
      → fig.add_axes() for every component at exact absolute positions
        │
        ▼
_draw_unified_panel()  → colorbars + combined legend on right
        │
        ▼
Restore suppressed state
        │
        ▼
HeatmapConcatResult (fig, results)
```

---

## Comparison with R's ComplexHeatmap

ComplexHeatmap (Gu et al., 2016) is the reference implementation this library is inspired by.
The two share the same core design philosophy but differ significantly in rendering engine,
layout model, and feature scope.

### Shared design principles

Both libraries:
- Specify the heatmap body in **absolute physical units** (mm). All surrounding panels
  (dendrograms, annotations, labels, colorbar) grow outward without shrinking the body.
- Use a `unit()` function identical in concept — `unit(10, 'mm')`, `unit(0.5, 'inch')`.
- Separate **data ordering** (clustering or manual) from **rendering**, so the same
  `Heatmap` object can be reused with different layouts.
- Support categorical row/column annotations with automatic color palettes and optional legends.
- Allow pre-computed linkage matrices to be passed in place of re-computing clustering.

---

### Rendering engine

| Aspect | R ComplexHeatmap | This implementation |
|---|---|---|
| Backend | R `grid` package (viewport tree) | matplotlib (`GridSpec` for standalone; `fig.add_axes()` for composed) |
| Layout unit | R `grid::unit()` — native to the rendering system | Custom `Unit` class that converts to inches |
| Layout composition | Nested viewports; each panel is a `viewport` inside a parent | `layout.py` computes absolute inch positions; `fig.add_axes()` places each axis exactly |
| Figure creation | `draw()` calls `grid.newpage()` and renders directly | `draw()` creates a `plt.figure()` and populates it with axes |

The R grid system is inherently more flexible: viewports can be nested arbitrarily, and every
object (text, line, rectangle) is a first-class "grob" with measurable dimensions. This is why
ComplexHeatmap's auto-sizing of row labels (`grobwidth`) is exact. The Python version approximates
this with `_measure_text_size()`, which renders text in a temporary figure and reads pixel extents.

---

### Multi-heatmap concatenation

ComplexHeatmap supports placing multiple heatmaps side by side:

```r
ht1 + ht2 + ht3   # concatenated horizontally
ht1 %v% ht2       # stacked vertically
```

This Python implementation uses `|` for horizontal concat and `/` for vertical stacking:

```python
A | B          # side by side
A / B          # stacked
(A | B) / C    # compound
```

Both systems unify the colorbar and legend panel and sync body sizes across panels.
The main difference: R's `+` shares a common column dendrogram across all panels in a
horizontal concat (the whole row gets one dendrogram). The Python version syncs row *order*
across panels but does not merge or share dendrograms — each panel renders its own
(or none, if `row_cluster=False`).

---

### Row/column splitting (slices)

ComplexHeatmap has a first-class `row_split` / `column_split` concept: the heatmap body is
divided into independent blocks separated by gaps, each with its own optional sub-dendrogram:

```r
Heatmap(mat, row_split = 3)                  # split into 3 slices by k-means
Heatmap(mat, row_split = annotation_vector)  # split by category
```

This Python version has no `row_split`. The equivalent is achieved indirectly: a `segment_gap`
on the left `HeatmapAnnotation` creates the visual gaps, and `row_cluster_dendrogram` draws a
tree over the resulting groups. This works but requires the caller to pre-sort rows so groups
are contiguous — ComplexHeatmap handles that automatically.

---

### Cluster-level dendrogram

ComplexHeatmap draws a sub-dendrogram *inside* each row slice (when `row_split` is used with
clustering). The Python `row_cluster_dendrogram` parameter serves the opposite use case: it draws
a single tree whose **leaves are the groups**, not the individual rows. This is a custom feature
not directly present in ComplexHeatmap; the closest analog is the slice-level tree you get when
passing a linkage matrix to `Heatmap()` with `row_split`.

---

### Annotation system

| Aspect | R ComplexHeatmap | This implementation |
|---|---|---|
| Annotation types | `anno_simple`, `anno_barplot`, `anno_boxplot`, `anno_density`, `anno_text`, `anno_mark`, `anno_lines`, `anno_points`, `anno_image` | `anno_simple`, `anno_barplot` |
| Annotation sizing | Each track specifies its own height/width via `anno_*()` | Uniform track height/width set on the `HeatmapAnnotation` object |
| Multiple tracks | `HeatmapAnnotation(a=anno_barplot(...), b=anno_simple(...))` — same API | Same API |
| Label placement | Controlled per-annotation via `labels_gp`, `show_annotation_name` | Single `show_labels` flag per `HeatmapAnnotation` |
| Legends | Auto-generated `Legend` objects, composable with `packLegend()` | Custom rendering in `_draw_annotation_legend()`; less composable |

---

### Dendrogram

| Aspect | R ComplexHeatmap | This implementation |
|---|---|---|
| Dendrogram style | Full control via `cluster_rows = as.dendrogram(hclust(...))` | Pre-computed linkage as `np.ndarray` |
| Leaf spacing | Uses actual dendrogram leaf positions; handles slice gaps | Rescales scipy's 5/15/25 positions to 0/1/2 by `(icoord-5)/10` |
| Dendrogram sides | Row dendrogram can be left or right | Row dendrogram always on left; no right option |
| Dendrogram per slice | Yes (when `row_split` is used) | Not supported |

---

### Color mapping

ComplexHeatmap uses `circlize::colorRamp2()` to define piecewise-linear color mappings:

```r
col_fun = colorRamp2(c(0, 2, 4), c("blue", "white", "red"))
Heatmap(mat, col = col_fun)
```

This Python version uses standard matplotlib colormaps with `vmin`, `vmax`, and `center`.
The `center` parameter symmetrizes the colormap range (max deviation from center), which
handles most CN/logR use cases, but non-symmetric or multi-breakpoint mappings require
passing a custom matplotlib `Colormap` object.

---

### Summary table

| Feature | R ComplexHeatmap | This implementation |
|---|---|---|
| Rendering engine | R grid / viewports | matplotlib (`GridSpec` standalone; `add_axes` composed) |
| Physical sizing (mm) | Yes | Yes |
| Multi-heatmap concat | Yes (`+`, `%v%`) | Yes (`\|`, `/`) |
| Shared dendrogram across panels | Yes (merged col dend) | Order synced; dendrograms independent |
| Row/column splitting | Yes (first-class) | Indirect via `segment_gap` |
| Cluster-level tree over groups | Partial (per-slice dend) | Yes (`row_cluster_dendrogram`) |
| Annotation types | 9+ | 2 |
| Per-annotation legends | Yes | Yes |
| Unified legend across panels | Yes | Yes |
| Body alignment across panels | Yes | Yes (absolute coordinates via `layout.py`) |
| Dendrogram per slice | Yes | No |
| Right-side row dendrogram | Yes | No |
| Color mapping | `colorRamp2` (piecewise) | matplotlib cmaps + `center` |
| Interactive mode | Yes (InteractiveComplexHeatmap) | No |

---

## Quality concerns

These are existing issues worth knowing before modifying the file.

### 1. Manual column index tracking in `draw()` (high fragility)

Every panel to the left of the heatmap body increments `heatmap_col` by 1:

```python
heatmap_col = 0
if layout['row_cluster_dend_width'] > 0: heatmap_col += 1
if layout['row_dend_width'] > 0:         heatmap_col += 1
if layout['left_annot_width'] > 0:       heatmap_col += 1
```

Downstream panels (colorbar, row names, legend) then compute their column by
`colorbar_col = heatmap_col + 1 + (1 if right_annot) + 1`. Adding or removing any
left-side panel requires auditing all downstream `+1` offsets. This affects the standalone
`draw()` path only; `draw_placed()` is immune since it uses absolute inch coordinates.

### 2. Duplicated segment-center logic (`_draw_annotation_labels_right` vs `_draw_labels`)

Both methods independently compute:
```python
start_pos = start + position_offset[start]
end_pos   = (end - 1) + position_offset[end - 1]
center    = (start_pos + end_pos) / 2
```

If the coordinate math ever changes, it must be changed in both places.

### 3. `show_labels='right'` is a string value on a boolean parameter

`show_labels` is documented as `bool`, but the `'right'` string value is now valid and
special-cased in two places: `HeatmapAnnotation.draw()` and `Heatmap._compute_layout()`.
The check in `_compute_layout()` repurposes `row_names_width` to push the colorbar over —
this is a workaround, not a first-class layout concept.

### 4. Two parallel code paths in `_draw_heatmap()`

The method has a `if has_col_gaps or has_row_gaps:` branch that duplicates cell-border
drawing and cell-annotation drawing from the simpler `else` branch. If a new cell rendering
feature is added, it must be implemented twice.

### 5. `draw()` is ~270 lines with mixed layout and rendering

The method handles GridSpec construction, all panel rendering, and result assembly in one
block. Extracting layout construction (`_build_gridspec()`) and panel dispatch
(`_draw_panels(gs, layout)`) would make each piece easier to test and reason about.
This only applies to the standalone `draw()` path; `draw_placed()` already separates
measurement (via `layout.measure()`) from rendering.
