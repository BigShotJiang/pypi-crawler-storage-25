"""
Publication-quality heatmap with size-driven layout.

Inspired by R's ComplexHeatmap, using a unit system similar to R's grid package.
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.colors import to_rgba, TwoSlopeNorm
from scipy.cluster.hierarchy import linkage, dendrogram, leaves_list
from scipy.spatial.distance import pdist
import seaborn as sns

from ..units import Unit, CompositeUnit, unit, LayoutEngine


# =============================================================================
# Heatmap Annotation
# =============================================================================

class HeatmapAnnotation:
    """
    Container for heatmap annotation tracks.

    Parameters:
    -----------
    **annotations : dict
        Keyword arguments where keys are annotation names and values are:
        - pandas.Series: Simple color annotation
        - dict with 'values' and 'colors': Mapped colors
        - anno_* function result: Complex annotation (barplot, etc.)

    height : Unit, default=5mm
        Height per track (for column annotations).
    width : Unit, default=5mm
        Width per track (for row annotations).
    gap : Unit, default=0mm
        Gap between tracks.
    segment_gap : Unit, optional
        Gap between different category segments (e.g., between chromosomes).
        Default: None (no gaps).
    show_labels : bool, default=False
        Whether to show category labels (e.g., chromosome numbers).
    label_offset : Unit, default=0.5mm
        Gap between annotation and labels.
    label_fontsize : int, default=5
        Font size for labels.
    label_formatter : callable, default=str
        Function to format label text. Receives the category value,
        returns the display string.
    colors : dict, optional
        Color mapping for categorical annotations. Format:
        {'annotation_name': {'category': 'color', ...}, ...}
    show_legend : bool, default=True
        Whether to show this annotation's legend in the legend panel.
        Set to False to hide the legend for this specific annotation.

    Examples:
    ---------
    >>> ann = HeatmapAnnotation(
    ...     group=pd.Series(['A', 'A', 'B', 'B']),
    ...     score=anno_barplot(values),
    ...     height=unit(5, 'mm')
    ... )

    >>> # With chromosome labels
    >>> ann = HeatmapAnnotation(
    ...     chrom=chrom_series,
    ...     height=unit(3, 'mm'),
    ...     show_labels=True,
    ...     label_offset=unit(1, 'mm'),
    ...     label_formatter=lambda x: str(x).replace('chr', '')
    ... )

    >>> # With gaps between chromosomes
    >>> ann = HeatmapAnnotation(
    ...     chrom=chrom_series,
    ...     height=unit(3, 'mm'),
    ...     segment_gap=unit(1, 'mm'),  # Gap between different chromosomes
    ...     show_labels=True
    ... )

    >>> # With custom colors
    >>> ann = HeatmapAnnotation(
    ...     chrom=chrom_series,
    ...     colors={'chrom': {'chr1': '#FFFFFF', 'chr2': '#CCCCCC', ...}}
    ... )
    """

    def __init__(self, height=unit(5, 'mm'), width=unit(5, 'mm'), gap=unit(0, 'mm'), segment_gap=None,
                 show_labels=False, label_offset=unit(0.5, 'mm'), label_fontsize=5,
                 label_formatter=str, colors=None, show_legend=True, **annotations):
        self.annotations = annotations
        self.height = height
        self.width = width
        self.gap = gap
        self.segment_gap = segment_gap  # Gap between different category values

        # Label settings
        self.show_labels = show_labels
        self.label_offset = label_offset
        self.label_fontsize = label_fontsize
        self.label_formatter = label_formatter

        # Legend visibility for this annotation
        self.show_legend = show_legend

        # Color palette for categorical annotations
        # Format: {'annotation_name': {'category': 'color', ...}, ...}
        self.colors = colors or {}

        # Process annotations
        self._processed = {}
        for name, ann in annotations.items():
            self._processed[name] = self._process_annotation(ann)

    def _process_annotation(self, ann):
        """Convert annotation to standard format."""
        if isinstance(ann, pd.Series):
            # Simple categorical or color annotation
            return {'type': 'simple', 'data': ann}
        elif isinstance(ann, dict):
            return ann
        elif isinstance(ann, np.ndarray):
            return {'type': 'simple', 'data': pd.Series(ann)}
        else:
            return ann

    def get_total_size(self, orientation='horizontal'):
        """Get total size of all annotation tracks."""
        n_tracks = len(self.annotations)
        if n_tracks == 0:
            return unit(0, 'mm')

        size_per_track = self.height if orientation == 'horizontal' else self.width
        gap_size = self.gap

        # Total = n * track_size + (n-1) * gap
        total_value = (n_tracks * size_per_track.value +
                      (n_tracks - 1) * gap_size.value)
        return unit(total_value, size_per_track.type)

    def _find_segment_boundaries(self, data):
        """
        Find boundaries where category values change.

        Returns list of (start, end) tuples for each segment.
        """
        n_items = len(data)
        data_values = data.values if isinstance(data, pd.Series) else data

        boundaries = []
        start = 0
        for i in range(1, n_items):
            if data_values[i] != data_values[i - 1]:
                boundaries.append((start, i))
                start = i
        boundaries.append((start, n_items))
        return boundaries

    def draw(self, ax, order, orientation='horizontal', palette=None, position=None, cell_size_inch=None):
        """
        Draw annotations on the given axes.

        Parameters:
        -----------
        ax : matplotlib.axes.Axes
            Axes to draw on.
        order : array-like
            Indices for reordering annotations.
        orientation : str
            'horizontal' (for column annotations) or 'vertical' (for row annotations).
        palette : dict, optional
            Color palette for categorical annotations.
        position : str, optional
            Position of annotation: 'top', 'bottom', 'left', or 'right'.
            Used for placing labels on the correct side.
        cell_size_inch : float, optional
            Size of one cell in inches (width for horizontal, height for vertical).
            Used to convert segment_gap from absolute units to coordinate units.
        """
        if not self.annotations:
            ax.axis('off')
            return

        n_tracks = len(self.annotations)
        n_items = len(order)

        # Get sizes in consistent units (use the unit type from height/width)
        track_size = self.height if orientation == 'horizontal' else self.width
        gap_size = self.gap

        # Calculate total size for coordinate system
        total_size = n_tracks * track_size.value + (n_tracks - 1) * gap_size.value

        # Get segment gap size in coordinate units (where 1 unit = 1 data item)
        # Convert from absolute units to "number of cells" equivalent
        if self.segment_gap and cell_size_inch and cell_size_inch > 0:
            segment_gap_size = self.segment_gap.to_inches() / cell_size_inch
        else:
            segment_gap_size = 0

        # Find segment boundaries from first annotation track for gap positions
        first_name = list(self._processed.keys())[0]
        first_processed = self._processed[first_name]
        first_data = first_processed.get('data', first_processed)
        if isinstance(first_data, pd.Series):
            first_data_ordered = first_data.iloc[order]
        else:
            first_data_ordered = np.array(first_data)[order]

        segments = self._find_segment_boundaries(first_data_ordered)
        n_gaps = len(segments) - 1

        # Calculate total width including segment gaps
        total_data_width = n_items + n_gaps * segment_gap_size if segment_gap_size > 0 else n_items

        # Build mapping from original index to position with gaps
        # This maps each item index to its x-position accounting for gaps
        if segment_gap_size > 0:
            position_offset = np.zeros(n_items)
            cumulative_gap = 0
            for seg_idx, (start, end) in enumerate(segments):
                for i in range(start, end):
                    position_offset[i] = cumulative_gap
                if seg_idx < len(segments) - 1:  # Don't add gap after last segment
                    cumulative_gap += segment_gap_size
            self._segment_position_offset = position_offset
            self._segments = segments
        else:
            self._segment_position_offset = np.zeros(n_items)
            self._segments = segments

        # Set up axes limits
        if orientation == 'horizontal':
            ax.set_xlim(-0.5, total_data_width - 0.5)
            ax.set_ylim(total_size, 0)  # y=0 at top, increasing downward
        else:
            ax.set_xlim(0, total_size)
            ax.set_ylim(-0.5, total_data_width - 0.5)
            ax.invert_yaxis()  # y=0 at top for row annotations

        # Draw each track separately with gaps
        current_pos = 0  # Track position in unit coordinates

        for name, processed in self._processed.items():
            data = processed.get('data', processed)
            if isinstance(data, pd.Series):
                data = data.iloc[order]
            else:
                data = np.array(data)[order]

            # Get colors for this track
            colors = self._get_colors(data, name, palette)

            if segment_gap_size > 0:
                # Draw each segment separately with gaps
                for seg_idx, (start, end) in enumerate(segments):
                    seg_len = end - start
                    # Build color array for this segment
                    seg_colors = np.ones((1, seg_len, 4))
                    for i in range(seg_len):
                        try:
                            seg_colors[0, i] = to_rgba(colors[start + i])
                        except:
                            seg_colors[0, i] = [0.9, 0.9, 0.9, 1]

                    # Calculate position with gap offset
                    x_start = start + self._segment_position_offset[start] - 0.5
                    x_end = end + self._segment_position_offset[end - 1] - 0.5

                    if orientation == 'horizontal':
                        extent = [x_start, x_end,
                                  current_pos + track_size.value, current_pos]
                        ax.imshow(seg_colors, aspect='auto', interpolation='nearest',
                                  extent=extent)
                    else:
                        seg_colors_t = np.transpose(seg_colors, (1, 0, 2))
                        extent = [current_pos, current_pos + track_size.value,
                                  x_end, x_start]
                        ax.imshow(seg_colors_t, aspect='auto', interpolation='nearest',
                                  extent=extent)
            else:
                # Original behavior: draw as single image
                track_colors = np.ones((1, n_items, 4))
                for i, c in enumerate(colors):
                    try:
                        track_colors[0, i] = to_rgba(c)
                    except:
                        track_colors[0, i] = [0.9, 0.9, 0.9, 1]

                if orientation == 'horizontal':
                    extent = [-0.5, n_items - 0.5,
                              current_pos + track_size.value, current_pos]
                    ax.imshow(track_colors, aspect='auto', interpolation='nearest',
                              extent=extent)
                else:
                    track_colors_t = np.transpose(track_colors, (1, 0, 2))
                    extent = [current_pos, current_pos + track_size.value,
                              n_items - 0.5, -0.5]
                    ax.imshow(track_colors_t, aspect='auto', interpolation='nearest',
                              extent=extent)

            # Move to next track position (track_size + gap)
            current_pos += track_size.value + gap_size.value

        ax.set_xticks([])
        ax.set_yticks([])
        for spine in ax.spines.values():
            spine.set_visible(False)

        # Draw labels if requested ('right' defers to Heatmap._draw_annotation_labels_right)
        if self.show_labels and self.show_labels != 'right':
            self._draw_labels(ax, order, orientation, position)

    def _get_colors(self, data, name, palette=None):
        """Convert data values to colors."""
        colors = []

        # Check if data is already colors
        if len(data) > 0:
            first = data.iloc[0] if isinstance(data, pd.Series) else data[0]
            if isinstance(first, str) and (first.startswith('#') or first in plt.colormaps()):
                return list(data)

        # Map categorical to colors
        unique_vals = pd.unique(data)
        if self.colors and name in self.colors:
            # Use colors passed to HeatmapAnnotation
            cmap = self.colors[name]
        elif palette and name in palette:
            cmap = palette[name]
        else:
            # Auto-generate palette
            n_colors = len(unique_vals)
            cmap = dict(zip(unique_vals, sns.color_palette("tab10", n_colors)))

        for val in data:
            colors.append(cmap.get(val, '#cccccc'))

        return colors

    def _draw_labels(self, ax, order, orientation, position):
        """
        Draw category labels for the first annotation track.

        Parameters:
        -----------
        ax : matplotlib.axes.Axes
            Axes to draw on.
        order : array-like
            Indices for reordering annotations.
        orientation : str
            'horizontal' or 'vertical'.
        position : str
            'top', 'bottom', 'left', or 'right'.
        """
        if not self._processed:
            return

        # Get data from the first annotation track
        first_name = list(self._processed.keys())[0]
        processed = self._processed[first_name]
        data = processed.get('data', processed)
        if isinstance(data, pd.Series):
            data = data.iloc[order]
        else:
            data = np.array(data)[order]

        n_items = len(data)
        data_values = data.values if isinstance(data, pd.Series) else data

        # Use pre-computed segments if available (from draw method)
        segments = getattr(self, '_segments', None)
        position_offset = getattr(self, '_segment_position_offset', None)

        if segments is None:
            # Fallback: compute boundaries
            boundaries = [0]
            for i in range(1, n_items):
                if data_values[i] != data_values[i - 1]:
                    boundaries.append(i)
            boundaries.append(n_items)
            segments = [(boundaries[i], boundaries[i + 1]) for i in range(len(boundaries) - 1)]
            position_offset = np.zeros(n_items)

        # Calculate offset in axes coordinates
        fig = ax.get_figure()
        bbox = ax.get_position()

        if orientation == 'horizontal':
            ax_size_inch = bbox.height * fig.get_figheight()
        else:
            ax_size_inch = bbox.width * fig.get_figwidth()

        offset_axes = self.label_offset.to_inches() / ax_size_inch

        # Determine label position and alignment based on annotation position
        if orientation == 'horizontal':
            # Column annotations (top or bottom)
            if position == 'top':
                # Labels above the annotation
                y_pos = 1 + offset_axes
                va = 'bottom'
            else:  # bottom or default
                # Labels below the annotation
                y_pos = -offset_axes
                va = 'top'

            # Draw labels at center of each category region (accounting for gaps)
            for start, end in segments:
                # Calculate center position with gap offset
                start_pos = start + position_offset[start]
                end_pos = end - 1 + position_offset[end - 1] + 1  # end-1 is last item in segment
                center = (start_pos + end_pos) / 2 - 0.5
                category = data_values[start]
                label = self.label_formatter(category)
                ax.text(center, y_pos, label, ha='center', va=va,
                        fontsize=self.label_fontsize,
                        transform=ax.get_xaxis_transform())
        else:
            # Row annotations (left or right)
            if position == 'right':
                # Labels to the right of the annotation
                x_pos = 1 + offset_axes
                ha = 'left'
            else:  # left or default
                # Labels to the left of the annotation
                x_pos = -offset_axes
                ha = 'right'

            # Draw labels at center of each category region (accounting for gaps)
            for start, end in segments:
                # Calculate center position with gap offset
                start_pos = start + position_offset[start]
                end_pos = end - 1 + position_offset[end - 1] + 1
                center = (start_pos + end_pos) / 2 - 0.5
                category = data_values[start]
                label = self.label_formatter(category)
                ax.text(x_pos, center, label, ha=ha, va='center',
                        fontsize=self.label_fontsize,
                        transform=ax.get_yaxis_transform())


def anno_simple(values, colors=None):
    """Create a simple color annotation track."""
    return {'type': 'simple', 'data': values, 'colors': colors}


def anno_barplot(values, height=unit(10, 'mm'), color='steelblue'):
    """Create a barplot annotation track."""
    return {
        'type': 'barplot',
        'data': values,
        'height': height,
        'color': color
    }


# =============================================================================
# Main Heatmap Class
# =============================================================================

class Heatmap:
    """
    Publication-quality heatmap with region-based layout.

    Inspired by R's ComplexHeatmap: the user specifies the total size of the
    heatmap body region (width × height), and cells fill that space. This
    decouples the figure size from the data dimensions.

    Parameters:
    -----------
    data : pandas.DataFrame or numpy.ndarray
        The data matrix to visualize.

    width : Unit, default=50mm
        Total width of the heatmap body region.

    height : Unit, default=50mm
        Total height of the heatmap body region.

    figsize : tuple of (float, float), optional
        Overall figure size in inches (width, height). When set, the heatmap
        body fills the remaining space after allocating dendrograms,
        annotations, labels, colorbar, legend, and margins. Overrides
        width/height.

    row_cluster : bool or np.ndarray, default=True
        Row clustering behavior:
        - True: compute hierarchical clustering from input data
        - False: no clustering, preserve input order
        - np.ndarray: use this pre-computed linkage matrix

    col_cluster : bool or np.ndarray, default=True
        Column clustering behavior:
        - True: compute hierarchical clustering from input data
        - False: no clustering, preserve input order
        - np.ndarray: use this pre-computed linkage matrix

    method : str, default='average'
        Clustering linkage method ('single', 'complete', 'average', 'ward', etc.).

    metric : str, default='euclidean'
        Distance metric for clustering.

    row_dendrogram_size : Unit, default=10mm
        Width of row dendrogram.

    col_dendrogram_size : Unit, default=10mm
        Height of column dendrogram.

    show_row_dendrogram : bool, default=True
        Whether to show row dendrogram (can hide while keeping clustering).

    show_col_dendrogram : bool, default=True
        Whether to show column dendrogram (can hide while keeping clustering).

    z_score : int or None, default=None
        Apply z-score normalization. 0=rows, 1=columns.

    cmap : str or Colormap, default='RdBu_r'
        Colormap for heatmap.

    center : float, optional
        Value to center colormap at.

    vmin, vmax : float, optional
        Colormap range.

    na_color : str, default='#808080'
        Color for NA/missing values.

    name : str, optional
        Name for this heatmap (used in legends).

    show_row_names : bool, default=True
        Whether to show row labels.

    show_col_names : bool, default=True
        Whether to show column labels.

    row_names_size : Unit or None, default=None
        Width reserved for row labels. If None (default), automatically
        measured from actual text width (like R's grobwidth).

    col_names_size : Unit or None, default=None
        Height reserved for column labels. If None (default), automatically
        measured from actual text size with rotation (like R's grobheight).

    labels_row : list, optional
        Custom labels for rows (overrides index).

    labels_col : list, optional
        Custom labels for columns (overrides columns).

    fontsize_row : int, default=6
        Font size for row labels.

    fontsize_col : int, default=6
        Font size for column labels.

    col_names_rotation : int, default=90
        Rotation angle for column labels (0, 45, or 90).

    row_order : array-like, optional
        Custom row ordering (overrides clustering).

    col_order : array-like, optional
        Custom column ordering (overrides clustering).

    annot : bool, default=False
        Whether to show values in cells.

    annot_fmt : str, default='.2g'
        Format string for cell annotations.

    annot_fontsize : int, default=6
        Font size for cell annotations.

    annot_color : str, default='auto'
        Color for annotations. 'auto' picks black/white based on cell color.

    linewidth : float, default=0
        Width of cell borders (0 = no borders).

    linecolor : str, default='white'
        Color of cell borders.

    segment_linewidth : float, default=0.8
        Width of borders around segment blocks when using segment_gap in annotations.

    segment_linecolor : str, default='grey'
        Color of segment block borders.

    title : str, optional
        Title for the heatmap.

    show_colorbar : bool, default=True
        Whether to show the colorbar.

    colorbar_label : str, optional
        Label for the colorbar.

    legend_breaks : list, optional
        Custom tick positions for colorbar.

    legend_labels : list, optional
        Custom tick labels for colorbar.

    legend_box_size : Unit, default=4mm
        Size of the color boxes in annotation legend.

    legend_item_gap : Unit, default=0.2mm
        Gap between items in the annotation legend.

    annotation_gap : Unit, default=1mm
        Gap between annotations and the heatmap.

    Examples:
    ---------
    >>> hm = Heatmap(data, width=unit(80, 'mm'), height=unit(60, 'mm'))
    >>> hm.draw()

    >>> # With annotations and cell values
    >>> hm = Heatmap(data, width=unit(50, 'mm'), height=unit(50, 'mm'),
    ...              annot=True, linewidth=0.5)
    >>> hm.add_top_annotation(HeatmapAnnotation(group=groups))
    >>> hm.draw()

    >>> # Custom ordering without clustering
    >>> hm = Heatmap(data, row_cluster=False, row_order=[2, 0, 1, 3])
    >>> hm.draw()
    """

    def __init__(
        self,
        data,
        width=unit(50, 'mm'),
        height=unit(50, 'mm'),
        figsize=None,
        row_cluster=True,
        col_cluster=True,
        method='average',
        metric='euclidean',
        row_dendrogram_size=unit(10, 'mm'),
        col_dendrogram_size=unit(10, 'mm'),
        show_row_dendrogram=True,
        show_col_dendrogram=True,
        dendrogram_linewidth=0.5,
        row_cluster_dendrogram=None,
        show_row_cluster_dendrogram=True,
        row_cluster_dendrogram_size=unit(10, 'mm'),
        z_score=None,
        cmap='RdBu_r',
        center=None,
        vmin=None,
        vmax=None,
        na_color='#808080',
        name=None,
        show_row_names=True,
        show_col_names=True,
        row_names_side='right',
        col_names_side='bottom',
        row_names_size=None,
        col_names_size=None,
        labels_row=None,
        labels_col=None,
        fontsize_row=6,
        fontsize_col=6,
        col_names_rotation=90,
        row_order=None,
        col_order=None,
        # Cell annotations
        annot=False,
        annot_fmt='.2g',
        annot_fontsize=6,
        annot_color='auto',
        # Cell borders
        linewidth=0,
        linecolor='white',
        # Segment borders (for blocks when using segment_gap)
        segment_linewidth=0.8,
        segment_linecolor='grey',
        # Title and colorbar
        title=None,
        title_size=unit(8, 'mm'),
        show_colorbar=True,
        colorbar_position='right',
        colorbar_size=unit(5, 'mm'),
        colorbar_height=unit(50, 'mm'),
        colorbar_label=None,
        legend_breaks=None,
        legend_labels=None,
        # Annotation legend
        annotation_legend_size=unit(25, 'mm'),
        legend_box_size=unit(4, 'mm'),
        legend_item_gap=unit(0.2, 'mm'),
        # Annotation gap
        annotation_gap=unit(1, 'mm'),
    ):
        # Convert to DataFrame
        if isinstance(data, np.ndarray):
            data = pd.DataFrame(data)
        self.data = data.copy()
        self.name = name

        # Sizing
        self.width = width
        self.height = height
        self.figsize = figsize
        self.row_dendrogram_size = row_dendrogram_size
        self.col_dendrogram_size = col_dendrogram_size
        self.show_row_dendrogram = show_row_dendrogram
        self.show_col_dendrogram = show_col_dendrogram
        self.dendrogram_linewidth = dendrogram_linewidth
        self.row_cluster_dendrogram = row_cluster_dendrogram
        self.show_row_cluster_dendrogram = show_row_cluster_dendrogram
        self.row_cluster_dendrogram_size = row_cluster_dendrogram_size

        # Clustering
        self.row_cluster = row_cluster
        self.col_cluster = col_cluster
        self.method = method
        self.metric = metric

        # Custom ordering (overrides clustering)
        self.row_order_input = row_order
        self.col_order_input = col_order

        # Appearance
        self.z_score = z_score
        self.cmap = cmap
        self.center = center
        self.vmin = vmin
        self.vmax = vmax
        self.na_color = na_color

        # Cell annotations
        self.annot = annot
        self.annot_fmt = annot_fmt
        self.annot_fontsize = annot_fontsize
        self.annot_color = annot_color

        # Cell borders
        self.linewidth = linewidth
        self.linecolor = linecolor

        # Segment borders (for blocks when using segment_gap)
        self.segment_linewidth = segment_linewidth
        self.segment_linecolor = segment_linecolor

        # Labels
        self.show_row_names = show_row_names
        self.show_col_names = show_col_names
        self.row_names_side = row_names_side
        self.col_names_side = col_names_side
        self.row_names_size = row_names_size  # None = auto-measure
        self.col_names_size = col_names_size  # None = auto-measure
        self.labels_row = labels_row
        self.labels_col = labels_col
        self.fontsize_row = fontsize_row
        self.fontsize_col = fontsize_col
        self.col_names_rotation = col_names_rotation

        # Title and colorbar
        self.title = title
        self.title_size = title_size
        self.show_colorbar = show_colorbar
        self.colorbar_position = colorbar_position
        self.colorbar_size = colorbar_size
        self.colorbar_height = colorbar_height
        self.colorbar_label = colorbar_label
        self.legend_breaks = legend_breaks
        self.legend_labels = legend_labels

        # Annotation legend
        self.annotation_legend_size = annotation_legend_size
        self.legend_box_size = legend_box_size
        self.legend_item_gap = legend_item_gap

        # Annotation gap (between annotations and heatmap)
        self.annotation_gap = annotation_gap

        # Annotations (added via methods)
        self.top_annotation = None
        self.bottom_annotation = None
        self.left_annotation = None
        self.right_annotation = None

        # Computed during draw
        self._row_order = None
        self._col_order = None
        self._row_linkage = None
        self._col_linkage = None

    def add_top_annotation(self, annotation):
        """Add annotation tracks above the heatmap."""
        self.top_annotation = annotation
        return self

    def add_bottom_annotation(self, annotation):
        """Add annotation tracks below the heatmap."""
        self.bottom_annotation = annotation
        return self

    def add_left_annotation(self, annotation):
        """Add annotation tracks to the left of the heatmap."""
        self.left_annotation = annotation
        return self

    def add_right_annotation(self, annotation):
        """Add annotation tracks to the right of the heatmap."""
        self.right_annotation = annotation
        return self

    def _compute_clustering(self):
        """Compute hierarchical clustering."""
        data = self.data.copy()

        # Apply z-score if requested
        if self.z_score is not None:
            if self.z_score == 0:  # rows
                data = data.sub(data.mean(axis=1), axis=0).div(data.std(axis=1), axis=0)
            elif self.z_score == 1:  # columns
                data = data.sub(data.mean(axis=0), axis=1).div(data.std(axis=0), axis=1)

        self._data_normalized = data

        # Row ordering
        if self.row_order_input is not None:
            self._row_order = np.array(self.row_order_input)
            self._row_linkage = None
        elif isinstance(self.row_cluster, np.ndarray):
            self._row_linkage = self.row_cluster
            self._row_order = leaves_list(self._row_linkage)
        elif self.row_cluster:
            data_for_cluster = data.fillna(0)
            row_dist = pdist(data_for_cluster.values, metric=self.metric)
            self._row_linkage = linkage(row_dist, method=self.method)
            self._row_order = leaves_list(self._row_linkage)
        else:
            self._row_order = np.arange(data.shape[0])
            self._row_linkage = None

        # Column ordering
        if self.col_order_input is not None:
            self._col_order = np.array(self.col_order_input)
            self._col_linkage = None
        elif isinstance(self.col_cluster, np.ndarray):
            self._col_linkage = self.col_cluster
            self._col_order = leaves_list(self._col_linkage)
        elif self.col_cluster:
            data_for_cluster = data.fillna(0)
            col_dist = pdist(data_for_cluster.values.T, metric=self.metric)
            self._col_linkage = linkage(col_dist, method=self.method)
            self._col_order = leaves_list(self._col_linkage)
        else:
            self._col_order = np.arange(data.shape[1])
            self._col_linkage = None

    def _measure_text_size(self, labels, fontsize, rotation=0):
        """
        Measure the maximum width and height of text labels.

        Similar to R's grobwidth/grobheight - measures actual rendered text.

        Parameters:
        -----------
        labels : list
            Text labels to measure.
        fontsize : int
            Font size in points.
        rotation : int
            Rotation angle in degrees.

        Returns:
        --------
        tuple of float
            (width, height) in inches.
        """
        if not labels:
            return (0, 0)

        # Create temporary figure for measurement
        temp_fig = plt.figure(figsize=(1, 1))
        temp_ax = temp_fig.add_subplot(111)

        max_width = 0
        max_height = 0

        try:
            renderer = temp_fig.canvas.get_renderer()
        except AttributeError:
            # Some backends don't support get_renderer without drawing
            temp_fig.canvas.draw()
            renderer = temp_fig.canvas.get_renderer()

        for label in labels:
            text = temp_ax.text(0, 0, str(label), fontsize=fontsize,
                               rotation=rotation)
            bbox = text.get_window_extent(renderer)
            # Convert pixels to inches
            width_inch = bbox.width / temp_fig.dpi
            height_inch = bbox.height / temp_fig.dpi
            max_width = max(max_width, width_inch)
            max_height = max(max_height, height_inch)

        plt.close(temp_fig)

        return (max_width, max_height)

    def _get_row_labels(self):
        """Get row labels (custom or from index)."""
        if self.labels_row is not None:
            return [str(self.labels_row[i]) for i in range(len(self.labels_row))]
        return [str(x) for x in self.data.index.tolist()]

    def _get_col_labels(self):
        """Get column labels (custom or from columns)."""
        if self.labels_col is not None:
            return [str(self.labels_col[i]) for i in range(len(self.labels_col))]
        return [str(x) for x in self.data.columns.tolist()]

    def _get_col_segment_gap_info(self):
        """
        Get segment gap info from top/bottom annotations for column gaps.

        Returns dict with 'gap_size', 'n_gaps', 'segments', 'position_offset' or None.
        Gap size and position_offset are in coordinate units (1 unit = 1 cell width).
        """
        for annot in [self.top_annotation, self.bottom_annotation]:
            if annot is not None and annot.segment_gap is not None:
                first_name = list(annot._processed.keys())[0]
                first_processed = annot._processed[first_name]
                first_data = first_processed.get('data', first_processed)
                if isinstance(first_data, pd.Series):
                    first_data_ordered = first_data.iloc[self._col_order]
                else:
                    first_data_ordered = np.array(first_data)[self._col_order]

                segments = annot._find_segment_boundaries(first_data_ordered)
                n_gaps = len(segments) - 1
                n_items = len(first_data_ordered)

                # Effective cell size: (body_width - total_gap) / n_cells
                gap_abs_inch = annot.segment_gap.to_inches()
                body_w_inch = self.width.to_inches()
                effective_cell_w = (body_w_inch - n_gaps * gap_abs_inch) / n_items if n_items > 0 else 1
                gap_size = gap_abs_inch / effective_cell_w if effective_cell_w > 0 else 0

                # Build position offset array
                position_offset = np.zeros(n_items)
                cumulative_gap = 0
                for seg_idx, (start, end) in enumerate(segments):
                    for i in range(start, end):
                        position_offset[i] = cumulative_gap
                    if seg_idx < len(segments) - 1:
                        cumulative_gap += gap_size

                return {
                    'gap_size': gap_size,
                    'n_gaps': n_gaps,
                    'segments': segments,
                    'position_offset': position_offset
                }
        return None

    def _get_row_segment_gap_info(self):
        """
        Get segment gap info from left/right annotations for row gaps.

        Returns dict with 'gap_size', 'n_gaps', 'segments', 'position_offset' or None.
        Gap size and position_offset are in coordinate units (1 unit = 1 cell height).
        """
        for annot in [self.left_annotation, self.right_annotation]:
            if annot is not None and annot.segment_gap is not None:
                first_name = list(annot._processed.keys())[0]
                first_processed = annot._processed[first_name]
                first_data = first_processed.get('data', first_processed)
                if isinstance(first_data, pd.Series):
                    first_data_ordered = first_data.iloc[self._row_order]
                else:
                    first_data_ordered = np.array(first_data)[self._row_order]

                segments = annot._find_segment_boundaries(first_data_ordered)
                n_gaps = len(segments) - 1
                n_items = len(first_data_ordered)

                # Effective cell size: (body_height - total_gap) / n_cells
                gap_abs_inch = annot.segment_gap.to_inches()
                body_h_inch = self.height.to_inches()
                effective_cell_h = (body_h_inch - n_gaps * gap_abs_inch) / n_items if n_items > 0 else 1
                gap_size = gap_abs_inch / effective_cell_h if effective_cell_h > 0 else 0

                # Build position offset array
                position_offset = np.zeros(n_items)
                cumulative_gap = 0
                for seg_idx, (start, end) in enumerate(segments):
                    for i in range(start, end):
                        position_offset[i] = cumulative_gap
                    if seg_idx < len(segments) - 1:
                        cumulative_gap += gap_size

                return {
                    'gap_size': gap_size,
                    'n_gaps': n_gaps,
                    'segments': segments,
                    'position_offset': position_offset
                }
        return None

    def _compute_layout(self):
        """Compute the layout sizes and positions."""
        # Heatmap body size is directly specified by the user
        heatmap_w = self.width.to_inches()
        heatmap_h = self.height.to_inches()

        # Determine if we should show dendrograms
        # row_cluster/col_cluster can be bool or np.ndarray (pre-computed linkage)
        row_cluster_active = isinstance(self.row_cluster, np.ndarray) or self.row_cluster
        col_cluster_active = isinstance(self.col_cluster, np.ndarray) or self.col_cluster
        show_row_dend = (row_cluster_active or self._row_linkage is not None) and self.show_row_dendrogram
        show_col_dend = (col_cluster_active or self._col_linkage is not None) and self.show_col_dendrogram

        # Check if we have any annotations with legends (show_legend=True)
        has_annotation_legend = any([
            annot for annot in [self.top_annotation, self.bottom_annotation,
                               self.left_annotation, self.right_annotation]
            if annot is not None and annot.show_legend
        ])

        # Auto-measure row names width if not specified
        if self.show_row_names:
            if self.row_names_size is not None:
                row_names_width = self.row_names_size.to_inches()
            else:
                # Measure actual text width (like R's grobwidth)
                row_labels = self._get_row_labels()
                measured_w, _ = self._measure_text_size(row_labels, self.fontsize_row, rotation=0)
                # Add padding: ~0.05 base + 30% of text width for the left margin offset
                padding = 0.05 + measured_w * 0.3
                row_names_width = measured_w + padding
        else:
            row_names_width = 0

        # When annotation labels are shown on the right, allocate space so they
        # don't overlap with the colorbar/legend (same mechanism as row_names_width).
        if (row_names_width == 0
                and self.left_annotation is not None
                and getattr(self.left_annotation, 'show_labels', False) == 'right'):
            ann = self.left_annotation
            first_name = list(ann._processed.keys())[0]
            ann_data = ann._processed[first_name].get('data', ann._processed[first_name])
            unique_vals = (ann_data.dropna().unique().tolist()
                           if isinstance(ann_data, pd.Series)
                           else list(pd.unique(ann_data)))
            labels = [ann.label_formatter(v) for v in unique_vals]
            measured_w, _ = self._measure_text_size(labels, ann.label_fontsize)
            row_names_width = measured_w + ann.label_offset.to_inches() + 0.05

        # Auto-measure column names height if not specified
        if self.show_col_names:
            if self.col_names_size is not None:
                col_names_height = self.col_names_size.to_inches()
            else:
                # Measure actual text size with rotation
                col_labels = self._get_col_labels()
                measured_w, measured_h = self._measure_text_size(
                    col_labels, self.fontsize_col, rotation=self.col_names_rotation
                )
                # Add padding: ~0.05 base + 30% of text height for margin offset
                padding = 0.05 + measured_h * 0.3
                col_names_height = measured_h + padding
        else:
            col_names_height = 0

        # Calculate extra space needed for top annotation labels (labels appear above annotation)
        top_annot_label_space = 0
        if self.top_annotation and self.top_annotation.show_labels:
            # Add label_offset + estimated text height based on fontsize
            label_space = self.top_annotation.label_offset.to_inches()
            text_height = self.top_annotation.label_fontsize / 72.0 * 1.2
            top_annot_label_space = label_space + text_height

        # Component sizes
        layout = {
            'heatmap_width': heatmap_w,
            'heatmap_height': heatmap_h,
            'row_dend_width': self.row_dendrogram_size.to_inches() if show_row_dend and self._row_linkage is not None else 0,
            'row_cluster_dend_width': (
                self.row_cluster_dendrogram_size.to_inches()
                if (self.row_cluster_dendrogram is not None and self.show_row_cluster_dendrogram)
                else 0
            ),
            # Add label space to dendrogram if no title (labels extend above annotation)
            'col_dend_height': (self.col_dendrogram_size.to_inches() + (top_annot_label_space if not self.title else 0)) if show_col_dend and self._col_linkage is not None else 0,
            'top_annot_height': (self.top_annotation.get_total_size('horizontal').to_inches()
                                if self.top_annotation else 0),
            'bottom_annot_height': (self.bottom_annotation.get_total_size('horizontal').to_inches()
                                   if self.bottom_annotation else 0),
            'left_annot_width': (self.left_annotation.get_total_size('vertical').to_inches()
                                if self.left_annotation else 0),
            'right_annot_width': (self.right_annotation.get_total_size('vertical').to_inches()
                                 if self.right_annotation else 0),
            'row_names_width': row_names_width,
            'col_names_height': col_names_height,
            # Title and colorbar (add space for top annotation labels if needed)
            'title_height': (self.title_size.to_inches() + top_annot_label_space) if self.title else 0,
            'colorbar_width': self.colorbar_size.to_inches() if self.show_colorbar and self.colorbar_position == 'right' else 0,
            'colorbar_height': self.colorbar_size.to_inches() if self.show_colorbar and self.colorbar_position == 'top' else 0,
            # Annotation legend
            'annotation_legend_width': self.annotation_legend_size.to_inches() if has_annotation_legend else 0,
        }

        # Total figure size
        legend_gap = 0.3 if has_annotation_legend else 0  # Gap before annotation legend
        colorbar_gap = 0.05 if (layout['colorbar_width'] > 0 and layout['row_names_width'] == 0) else 0
        margin = 0.5
        layout['margin'] = margin

        if self.figsize is not None:
            # Figure-in mode: derive body size from figure size minus peripherals
            fig_w, fig_h = self.figsize

            peripherals_w = (layout['row_cluster_dend_width'] +
                             layout['row_dend_width'] +
                             layout['left_annot_width'] +
                             layout['right_annot_width'] +
                             layout['row_names_width'] +
                             colorbar_gap +
                             layout['colorbar_width'] +
                             legend_gap +
                             layout['annotation_legend_width'] + margin)

            peripherals_h = (layout['title_height'] +
                             layout['col_dend_height'] +
                             layout['top_annot_height'] +
                             layout['bottom_annot_height'] +
                             layout['col_names_height'] + margin)

            body_w = max(fig_w - peripherals_w, 0.5)
            body_h = max(fig_h - peripherals_h, 0.5)

            layout['heatmap_width'] = body_w
            layout['heatmap_height'] = body_h

            # Update self.width/height so downstream code (segment gap
            # calculations, cell size, etc.) uses the correct body size
            self.width = unit(body_w, 'inch')
            self.height = unit(body_h, 'inch')

            layout['total_width'] = fig_w
            layout['total_height'] = fig_h
        else:
            # Body-out mode: derive figure size from body + peripherals
            layout['total_width'] = (layout['row_cluster_dend_width'] +
                                    layout['row_dend_width'] +
                                    layout['left_annot_width'] +
                                    layout['heatmap_width'] +
                                    layout['right_annot_width'] +
                                    layout['row_names_width'] +
                                    colorbar_gap +
                                    layout['colorbar_width'] +
                                    legend_gap +
                                    layout['annotation_legend_width'] + margin)

            layout['total_height'] = (layout['title_height'] +
                                     layout['col_dend_height'] +
                                     layout['top_annot_height'] +
                                     layout['heatmap_height'] +
                                     layout['bottom_annot_height'] +
                                     layout['col_names_height'] + margin)

        # Space above / to the left of the heatmap body — used by concat/stack
        # to add padding so that bodies always land at the same position.
        layout['left_side_width'] = (layout['row_cluster_dend_width'] +
                                     layout['row_dend_width'] +
                                     layout['left_annot_width'])
        layout['top_side_height'] = (layout['title_height'] +
                                     layout['col_dend_height'] +
                                     layout['top_annot_height'])

        return layout

    def _validate_segment_gap_clustering(self):
        """
        Validate that segment_gap and clustering are not used together.

        When segment_gap is non-zero, the gaps are inserted where annotation
        values change. Clustering would reorder the data and scatter the
        segments, making the gaps meaningless.
        """
        # Check if clustering is active (bool True or pre-computed linkage array)
        col_cluster_active = isinstance(self.col_cluster, np.ndarray) or self.col_cluster is True
        row_cluster_active = isinstance(self.row_cluster, np.ndarray) or self.row_cluster is True

        # Check column annotations vs col_cluster
        for annot, name in [(self.top_annotation, 'top_annotation'),
                            (self.bottom_annotation, 'bottom_annotation')]:
            if annot is not None and annot.segment_gap is not None:
                if col_cluster_active and self.col_order_input is None:
                    raise ValueError(
                        f"{name} has segment_gap set, but col_cluster is enabled. "
                        "Clustering would reorder columns and scatter the segments, "
                        "making gaps appear at meaningless positions. "
                        "Either set col_cluster=False or remove segment_gap."
                    )

        # Check row annotations vs row_cluster
        for annot, name in [(self.left_annotation, 'left_annotation'),
                            (self.right_annotation, 'right_annotation')]:
            if annot is not None and annot.segment_gap is not None:
                if row_cluster_active and self.row_order_input is None:
                    raise ValueError(
                        f"{name} has segment_gap set, but row_cluster is enabled. "
                        "Clustering would reorder rows and scatter the segments, "
                        "making gaps appear at meaningless positions. "
                        "Either set row_cluster=False or remove segment_gap."
                    )

    def draw(self, fig=None, subplot_spec=None):
        """
        Draw the heatmap.

        Parameters:
        -----------
        fig : matplotlib.figure.Figure, optional
            Figure to draw on.  If None (and subplot_spec is also None), a new
            figure is created.
        subplot_spec : matplotlib.gridspec.SubplotSpec, optional
            When provided, the heatmap is rendered into this sub-region of an
            existing figure instead of occupying the whole figure.  ``fig``
            must also be provided in this case (used by HeatmapConcat /
            HeatmapStack).

        Returns:
        --------
        HeatmapResult
            Object containing figure, axes, and clustering results.
        """
        # Validate segment_gap and clustering compatibility
        self._validate_segment_gap_clustering()

        # Compute clustering (may be a no-op if already called by a concat)
        if self._row_order is None or self._col_order is None:
            self._compute_clustering()

        # Compute layout
        layout = self._compute_layout()

        # Create figure (only when drawing standalone)
        if fig is None:
            fig = plt.figure(figsize=(layout['total_width'], layout['total_height']))

        # Build GridSpec
        # Rows: [title, col_dend, top_annot, heatmap, bottom_annot, col_names]
        # Cols: [row_dend, left_annot, heatmap, right_annot, row_names, colorbar]

        height_ratios = []
        width_ratios = []

        # Height ratios
        if layout['title_height'] > 0:
            height_ratios.append(layout['title_height'])
        if layout['col_dend_height'] > 0:
            height_ratios.append(layout['col_dend_height'])
        if layout['top_annot_height'] > 0:
            height_ratios.append(layout['top_annot_height'])
        height_ratios.append(layout['heatmap_height'])
        if layout['bottom_annot_height'] > 0:
            height_ratios.append(layout['bottom_annot_height'])
        if layout['col_names_height'] > 0:
            height_ratios.append(layout['col_names_height'])

        # Width ratios
        if layout['row_cluster_dend_width'] > 0:
            width_ratios.append(layout['row_cluster_dend_width'])
        if layout['row_dend_width'] > 0:
            width_ratios.append(layout['row_dend_width'])
        if layout['left_annot_width'] > 0:
            width_ratios.append(layout['left_annot_width'])
        width_ratios.append(layout['heatmap_width'])
        if layout['right_annot_width'] > 0:
            width_ratios.append(layout['right_annot_width'])
        if layout['row_names_width'] > 0:
            width_ratios.append(layout['row_names_width'])
        if layout['colorbar_width'] > 0:
            if layout['row_names_width'] == 0:
                width_ratios.append(0.05)  # gap when no row labels
            width_ratios.append(layout['colorbar_width'])
        # Add a gap column before annotation legend
        if layout['annotation_legend_width'] > 0:
            width_ratios.append(0.3)  # Gap column (in inches)
            width_ratios.append(layout['annotation_legend_width'])

        n_rows = len(height_ratios)
        n_cols = len(width_ratios)

        # Convert annotation_gap from absolute units to figure fraction
        gap_inches = self.annotation_gap.to_inches()
        # hspace/wspace are fractions of the average subplot size
        avg_height = layout['total_height'] / n_rows if n_rows > 0 else 1
        avg_width = layout['total_width'] / n_cols if n_cols > 0 else 1
        hspace = gap_inches / avg_height if avg_height > 0 else 0.02
        wspace = gap_inches / avg_width if avg_width > 0 else 0.02

        if subplot_spec is not None:
            from matplotlib.gridspec import GridSpecFromSubplotSpec
            gs = GridSpecFromSubplotSpec(n_rows, n_cols,
                                        subplot_spec=subplot_spec,
                                        width_ratios=width_ratios,
                                        height_ratios=height_ratios,
                                        wspace=wspace, hspace=hspace)
        else:
            gs = fig.add_gridspec(n_rows, n_cols,
                                  width_ratios=width_ratios,
                                  height_ratios=height_ratios,
                                  wspace=wspace, hspace=hspace)

        # Track current grid position
        row_idx = 0
        col_idx = 0

        # Determine heatmap position
        heatmap_row = 0
        if layout['title_height'] > 0:
            heatmap_row += 1
        if layout['col_dend_height'] > 0:
            heatmap_row += 1
        if layout['top_annot_height'] > 0:
            heatmap_row += 1

        heatmap_col = 0
        if layout['row_cluster_dend_width'] > 0:
            heatmap_col += 1
        if layout['row_dend_width'] > 0:
            heatmap_col += 1
        if layout['left_annot_width'] > 0:
            heatmap_col += 1

        # Store axes
        axes = {}

        def _sub(spec):
            return fig.add_subplot(spec)

        # Draw title (centered over heatmap column)
        if self.title and layout['title_height'] > 0:
            ax_title = _sub(gs[0, heatmap_col])
            ax_title.text(0.5, 0.5, self.title, ha='center', va='center',
                         fontsize=12, transform=ax_title.transAxes)
            ax_title.axis('off')
            axes['title'] = ax_title

        # Draw column dendrogram
        if layout['col_dend_height'] > 0 and self._col_linkage is not None:
            col_dend_row = 1 if layout['title_height'] > 0 else 0
            ax_col_dend = _sub(gs[col_dend_row, heatmap_col])
            self._draw_dendrogram(ax_col_dend, self._col_linkage,
                                 orientation='top')
            axes['col_dendrogram'] = ax_col_dend

        # Draw cluster dendrogram (one leaf per cluster group, aligned to group centers)
        if layout['row_cluster_dend_width'] > 0 and self.row_cluster_dendrogram is not None:
            ax_cluster_dend = _sub(gs[heatmap_row, 0])
            self._draw_cluster_dendrogram(ax_cluster_dend, self.row_cluster_dendrogram)
            axes['row_cluster_dendrogram'] = ax_cluster_dend

        # Draw row dendrogram
        if layout['row_dend_width'] > 0 and self._row_linkage is not None:
            row_dend_col = 1 if layout['row_cluster_dend_width'] > 0 else 0
            ax_row_dend = _sub(gs[heatmap_row, row_dend_col])
            self._draw_dendrogram(ax_row_dend, self._row_linkage,
                                 orientation='left')
            axes['row_dendrogram'] = ax_row_dend

        # Compute effective cell sizes for annotation gap conversion
        n_data_rows, n_data_cols = self.data.shape
        cell_width_inch = self.width.to_inches() / n_data_cols if n_data_cols > 0 else 1
        cell_height_inch = self.height.to_inches() / n_data_rows if n_data_rows > 0 else 1

        # Draw top annotation
        if self.top_annotation and layout['top_annot_height'] > 0:
            top_row = 0
            if layout['title_height'] > 0:
                top_row += 1
            if layout['col_dend_height'] > 0:
                top_row += 1
            ax_top = _sub(gs[top_row, heatmap_col])
            self.top_annotation.draw(ax_top, self._col_order, 'horizontal', position='top', cell_size_inch=cell_width_inch)
            axes['top_annotation'] = ax_top

        # Draw left annotation
        if self.left_annotation and layout['left_annot_width'] > 0:
            left_col = 0
            if layout['row_cluster_dend_width'] > 0:
                left_col += 1
            if layout['row_dend_width'] > 0:
                left_col += 1
            ax_left = _sub(gs[heatmap_row, left_col])
            self.left_annotation.draw(ax_left, self._row_order, 'vertical', position='left', cell_size_inch=cell_height_inch)
            axes['left_annotation'] = ax_left

        # Draw heatmap
        ax_heatmap = _sub(gs[heatmap_row, heatmap_col])
        self._draw_heatmap(ax_heatmap)
        axes['heatmap'] = ax_heatmap

        # Draw left-annotation labels on the right side if requested
        if (self.left_annotation is not None and
                getattr(self.left_annotation, 'show_labels', False) == 'right'):
            self._draw_annotation_labels_right(ax_heatmap)

        # Draw right annotation
        if self.right_annotation and layout['right_annot_width'] > 0:
            right_col = heatmap_col + 1
            ax_right = _sub(gs[heatmap_row, right_col])
            self.right_annotation.draw(ax_right, self._row_order, 'vertical', position='right', cell_size_inch=cell_height_inch)
            axes['right_annotation'] = ax_right

        # Draw bottom annotation
        if self.bottom_annotation and layout['bottom_annot_height'] > 0:
            bottom_row = heatmap_row + 1
            ax_bottom = _sub(gs[bottom_row, heatmap_col])
            self.bottom_annotation.draw(ax_bottom, self._col_order, 'horizontal', position='bottom', cell_size_inch=cell_width_inch)
            axes['bottom_annotation'] = ax_bottom

        # Draw row names
        if self.show_row_names and layout['row_names_width'] > 0:
            # Row names column is after right_annot but before colorbar
            names_col = heatmap_col + 1
            if layout['right_annot_width'] > 0:
                names_col += 1
            ax_names = _sub(gs[heatmap_row, names_col])
            self._draw_row_names(ax_names)
            axes['row_names'] = ax_names

        # Draw column names
        if self.show_col_names and layout['col_names_height'] > 0:
            names_row = n_rows - 1
            ax_names = _sub(gs[names_row, heatmap_col])
            self._draw_col_names(ax_names)
            axes['col_names'] = ax_names

        # Draw colorbar
        if self.show_colorbar and layout['colorbar_width'] > 0:
            colorbar_col = heatmap_col + 1
            if layout['right_annot_width'] > 0:
                colorbar_col += 1
            colorbar_col += 1  # row_names column (if shown) or gap column (if not)

            # Get the position of the grid cell
            ax_temp = _sub(gs[heatmap_row, colorbar_col])
            pos = ax_temp.get_position()
            ax_temp.remove()

            # Calculate colorbar height in figure coordinates
            cbar_height_inch = self.colorbar_height.to_inches()
            fig_height = fig.get_figheight()

            # Cap colorbar height to not exceed heatmap height
            heatmap_height_fig = pos.height
            cbar_height_fig = min(cbar_height_inch / fig_height, heatmap_height_fig)

            # Align the colorbar to the top of the heatmap
            y_start = pos.y0 + pos.height - cbar_height_fig

            # Create colorbar axes with custom height
            ax_cbar = fig.add_axes([pos.x0, y_start, pos.width, cbar_height_fig])

            cbar = fig.colorbar(self._heatmap_mappable, cax=ax_cbar)
            cbar.ax.tick_params(labelsize=6, length=0)  # length=0 removes tick marks

            # Custom legend breaks and labels
            if self.legend_breaks is not None:
                cbar.set_ticks(self.legend_breaks)
                if self.legend_labels is not None:
                    cbar.set_ticklabels(self.legend_labels)
            else:
                auto_ticks = self._auto_colorbar_ticks()
                if auto_ticks is not None:
                    cbar.set_ticks(auto_ticks)
                if self.legend_labels is not None:
                    cbar.set_ticklabels(self.legend_labels)

            # Set colorbar label only if explicitly provided
            if self.colorbar_label:
                cbar.set_label(self.colorbar_label, fontsize=8)
            axes['colorbar'] = ax_cbar

        # Draw annotation legend
        if layout['annotation_legend_width'] > 0:
            legend_col = n_cols - 1
            # Span from top of figure (below title) to bottom to give enough vertical space
            legend_row_start = 1 if layout['title_height'] > 0 else 0
            legend_row_end = n_rows  # Span to the bottom
            ax_legend = _sub(gs[legend_row_start:legend_row_end, legend_col])
            self._draw_annotation_legend(ax_legend, ax_heatmap)
            axes['annotation_legend'] = ax_legend

        # Create result
        result = HeatmapResult(
            fig=fig,
            axes=axes,
            row_order=self._row_order,
            col_order=self._col_order,
            row_linkage=self._row_linkage,
            col_linkage=self._col_linkage,
            data=self._data_normalized.iloc[self._row_order, self._col_order]
        )

        return result

    # ------------------------------------------------------------------
    # Composition operators  (A | B  and  A / B)
    # ------------------------------------------------------------------

    def __or__(self, other):
        """Horizontal concat: A | B → HeatmapConcat([A, B])."""
        from .concat import HeatmapConcat
        return HeatmapConcat([self, other])

    def __truediv__(self, other):
        """Vertical stack: A / B → HeatmapStack([A, B])."""
        from .concat import HeatmapStack
        return HeatmapStack([self, other])

    # ------------------------------------------------------------------
    # Helpers used by HeatmapConcat / HeatmapStack
    # ------------------------------------------------------------------

    def _get_leaves(self):
        """Return [self] — satisfies the recursive leaf-gathering protocol."""
        return [self]

    def draw_placed(self, fig, body_x, body_y_from_top):
        """
        Render the heatmap into *fig* with the body at absolute figure
        coordinates (*body_x*, *body_y_from_top*), both in inches from the
        figure's top-left corner.

        All axes are placed with fig.add_axes() so that bodies across panels
        land at pixel-exact positions regardless of decorations.

        Called by HeatmapConcat / HeatmapStack after clustering has been
        computed and colorbars / annotation legends have been suppressed.
        """
        from .layout import measure

        pl = measure(self)
        fw = fig.get_figwidth()
        fh = fig.get_figheight()

        # body bottom edge in matplotlib coordinates (origin = fig bottom-left)
        body_y_bot = fh - body_y_from_top - pl.body_h

        def _add(x_inch, y_bot_inch, w_inch, h_inch, label=''):
            """Add an axes at absolute inch coordinates."""
            return fig.add_axes(
                [x_inch / fw, y_bot_inch / fh, w_inch / fw, h_inch / fh],
                label=label or f'_hm{id(self)}_{x_inch:.3f}',
            )

        axes = {}

        # ---- above body -------------------------------------------------------

        if pl.title_h > 0 and self.title:
            y = body_y_bot + pl.body_h + pl.top_annot_h + pl.col_dend_h
            ax = _add(body_x, y, pl.body_w, pl.title_h, 'title')
            ax.text(0.5, 0.5, self.title, ha='center', va='center',
                    fontsize=12, transform=ax.transAxes)
            ax.axis('off')
            axes['title'] = ax

        if pl.col_dend_h > 0 and self._col_linkage is not None:
            y = body_y_bot + pl.body_h + pl.top_annot_h
            ax = _add(body_x, y, pl.body_w, pl.col_dend_h, 'col_dend')
            self._draw_dendrogram(ax, self._col_linkage, orientation='top')
            axes['col_dendrogram'] = ax

        if pl.top_annot_h > 0 and self.top_annotation:
            y = body_y_bot + pl.body_h
            ax = _add(body_x, y, pl.body_w, pl.top_annot_h, 'top_annot')
            n_cols = self.data.shape[1]
            cell_w = pl.body_w / n_cols if n_cols > 0 else 1
            self.top_annotation.draw(ax, self._col_order, 'horizontal',
                                     position='top', cell_size_inch=cell_w)
            axes['top_annotation'] = ax

        # ---- left of body -----------------------------------------------------

        if pl.row_cluster_dend_w > 0 and self.row_cluster_dendrogram is not None:
            x = body_x - pl.left_side
            ax = _add(x, body_y_bot, pl.row_cluster_dend_w, pl.body_h, 'rcluster_dend')
            self._draw_cluster_dendrogram(ax, self.row_cluster_dendrogram)
            axes['row_cluster_dendrogram'] = ax

        if pl.row_dend_w > 0 and self._row_linkage is not None:
            x = body_x - pl.row_dend_w - pl.left_annot_w
            ax = _add(x, body_y_bot, pl.row_dend_w, pl.body_h, 'row_dend')
            self._draw_dendrogram(ax, self._row_linkage, orientation='left')
            axes['row_dendrogram'] = ax

        if pl.left_annot_w > 0 and self.left_annotation:
            x = body_x - pl.left_annot_w
            ax = _add(x, body_y_bot, pl.left_annot_w, pl.body_h, 'left_annot')
            n_rows = self.data.shape[0]
            cell_h = pl.body_h / n_rows if n_rows > 0 else 1
            self.left_annotation.draw(ax, self._row_order, 'vertical',
                                      position='left', cell_size_inch=cell_h)
            axes['left_annotation'] = ax

        # ---- body -------------------------------------------------------------

        ax_body = _add(body_x, body_y_bot, pl.body_w, pl.body_h, 'body')
        self._draw_heatmap(ax_body)
        axes['heatmap'] = ax_body

        if (self.left_annotation is not None and
                getattr(self.left_annotation, 'show_labels', False) == 'right'):
            self._draw_annotation_labels_right(ax_body)

        # ---- right of body ----------------------------------------------------

        if pl.right_annot_w > 0 and self.right_annotation:
            x = body_x + pl.body_w
            ax = _add(x, body_y_bot, pl.right_annot_w, pl.body_h, 'right_annot')
            n_rows = self.data.shape[0]
            cell_h = pl.body_h / n_rows if n_rows > 0 else 1
            self.right_annotation.draw(ax, self._row_order, 'vertical',
                                       position='right', cell_size_inch=cell_h)
            axes['right_annotation'] = ax

        if pl.row_names_w > 0 and self.show_row_names:
            x = body_x + pl.body_w + pl.right_annot_w
            ax = _add(x, body_y_bot, pl.row_names_w, pl.body_h, 'row_names')
            self._draw_row_names(ax)
            axes['row_names'] = ax

        if pl.colorbar_w > 0 and self.show_colorbar:
            x = body_x + pl.body_w + pl.right_annot_w + pl.row_names_w + pl.colorbar_gap
            cbar_h = min(pl.colorbar_h, pl.body_h)
            y = body_y_bot + pl.body_h - cbar_h   # align to top of body
            ax = _add(x, y, pl.colorbar_w, cbar_h, 'colorbar')
            cbar = fig.colorbar(self._heatmap_mappable, cax=ax)
            cbar.ax.tick_params(labelsize=6, length=0)
            if self.legend_breaks is not None:
                cbar.set_ticks(self.legend_breaks)
                if self.legend_labels is not None:
                    cbar.set_ticklabels(self.legend_labels)
            else:
                auto_ticks = self._auto_colorbar_ticks()
                if auto_ticks is not None:
                    cbar.set_ticks(auto_ticks)
            if self.colorbar_label:
                cbar.set_label(self.colorbar_label, fontsize=8)
            axes['colorbar'] = ax

        # ---- below body -------------------------------------------------------

        if pl.bottom_annot_h > 0 and self.bottom_annotation:
            y = body_y_bot - pl.bottom_annot_h
            ax = _add(body_x, y, pl.body_w, pl.bottom_annot_h, 'bot_annot')
            n_cols = self.data.shape[1]
            cell_w = pl.body_w / n_cols if n_cols > 0 else 1
            self.bottom_annotation.draw(ax, self._col_order, 'horizontal',
                                        position='bottom', cell_size_inch=cell_w)
            axes['bottom_annotation'] = ax

        if pl.col_names_h > 0 and self.show_col_names:
            y = body_y_bot - pl.bottom_annot_h - pl.col_names_h
            ax = _add(body_x, y, pl.body_w, pl.col_names_h, 'col_names')
            self._draw_col_names(ax)
            axes['col_names'] = ax

        return HeatmapResult(
            fig=fig,
            axes=axes,
            row_order=self._row_order,
            col_order=self._col_order,
            row_linkage=self._row_linkage,
            col_linkage=self._col_linkage,
            data=self._data_normalized.iloc[self._row_order, self._col_order],
        )

    def _draw_heatmap(self, ax):
        """Draw the main heatmap."""
        data = self._data_normalized.iloc[self._row_order, self._col_order]
        values = data.values.copy()
        n_rows, n_cols = values.shape

        # Determine color range (ignoring NaN)
        vmin = self.vmin
        vmax = self.vmax
        if vmin is None:
            vmin = np.nanmin(values)
        if vmax is None:
            vmax = np.nanmax(values)

        if self.center is not None:
            if vmin < self.center < vmax:
                norm = TwoSlopeNorm(vcenter=self.center, vmin=vmin, vmax=vmax)
            else:
                raise ValueError(
                    f"center={self.center} must be strictly between vmin={vmin:.4g} and vmax={vmax:.4g}."
                )
        else:
            norm = None

        # Create colormap with NA color
        cmap = plt.get_cmap(self.cmap).copy()
        cmap.set_bad(color=self.na_color)

        # Get segment gap info from annotations
        col_seg_info = self._get_col_segment_gap_info()
        row_seg_info = self._get_row_segment_gap_info()

        # Calculate total extent with gaps
        col_offset = col_seg_info['position_offset'] if col_seg_info else np.zeros(n_cols)
        row_offset = row_seg_info['position_offset'] if row_seg_info else np.zeros(n_rows)

        total_width = n_cols + (col_offset[-1] if len(col_offset) > 0 else 0)
        total_height = n_rows + (row_offset[-1] if len(row_offset) > 0 else 0)

        # Set axes limits to match annotation
        ax.set_xlim(-0.5, total_width - 0.5)
        ax.set_ylim(total_height - 0.5, -0.5)

        # Check if we need segmented drawing
        has_col_gaps = col_seg_info is not None and col_seg_info['n_gaps'] > 0
        has_row_gaps = row_seg_info is not None and row_seg_info['n_gaps'] > 0

        if has_col_gaps or has_row_gaps:
            # Draw heatmap in segments
            col_segments = col_seg_info['segments'] if has_col_gaps else [(0, n_cols)]
            row_segments = row_seg_info['segments'] if has_row_gaps else [(0, n_rows)]

            im = None  # Will store last imshow for colorbar
            for row_start, row_end in row_segments:
                for col_start, col_end in col_segments:
                    # Extract segment data
                    seg_values = values[row_start:row_end, col_start:col_end]

                    # Calculate extent with gaps
                    x_start = col_start + col_offset[col_start] - 0.5
                    x_end = col_end + col_offset[col_end - 1] - 0.5
                    y_start = row_start + row_offset[row_start] - 0.5
                    y_end = row_end + row_offset[row_end - 1] - 0.5

                    # extent = [left, right, bottom, top]
                    im = ax.imshow(seg_values, aspect='auto', cmap=cmap,
                                  norm=norm, vmin=None if norm else vmin, vmax=None if norm else vmax,
                                  interpolation='nearest',
                                  extent=[x_start, x_end, y_end, y_start])

            # Draw cell borders if requested (accounting for gaps)
            if self.linewidth > 0:
                for row_start, row_end in row_segments:
                    for i in range(row_start, row_end + 1):
                        y = i + (row_offset[min(i, n_rows - 1)] if i < n_rows else row_offset[-1]) - 0.5
                        # Find x extent for this row segment
                        for col_start, col_end in col_segments:
                            x1 = col_start + col_offset[col_start] - 0.5
                            x2 = col_end + col_offset[col_end - 1] - 0.5
                            ax.plot([x1, x2], [y, y], color=self.linecolor, linewidth=self.linewidth)

                for col_start, col_end in col_segments:
                    for j in range(col_start, col_end + 1):
                        x = j + (col_offset[min(j, n_cols - 1)] if j < n_cols else col_offset[-1]) - 0.5
                        # Find y extent for this column segment
                        for row_start, row_end in row_segments:
                            y1 = row_start + row_offset[row_start] - 0.5
                            y2 = row_end + row_offset[row_end - 1] - 0.5
                            ax.plot([x, x], [y1, y2], color=self.linecolor, linewidth=self.linewidth)

            # Draw segment borders (borders around each block when using segment_gap)
            if self.segment_linewidth > 0:
                for row_start, row_end in row_segments:
                    for col_start, col_end in col_segments:
                        # Calculate block boundaries
                        x1 = col_start + col_offset[col_start] - 0.5
                        x2 = col_end + col_offset[col_end - 1] - 0.5
                        y1 = row_start + row_offset[row_start] - 0.5
                        y2 = row_end + row_offset[row_end - 1] - 0.5
                        # Draw rectangle around the block
                        rect = plt.Rectangle((x1, y1), x2 - x1, y2 - y1,
                                            fill=False, edgecolor=self.segment_linecolor,
                                            linewidth=self.segment_linewidth, clip_on=False)
                        ax.add_patch(rect)

            # Draw cell annotations if requested (accounting for gaps)
            if self.annot:
                for i in range(n_rows):
                    for j in range(n_cols):
                        val = values[i, j]
                        if np.isnan(val):
                            continue

                        text = format(val, self.annot_fmt)

                        if self.annot_color == 'auto':
                            norm_val = norm(val) if norm else ((val - vmin) / (vmax - vmin) if vmax != vmin else 0.5)
                            text_color = 'white' if norm_val > 0.5 else 'black'
                        else:
                            text_color = self.annot_color

                        x = j + col_offset[j]
                        y = i + row_offset[i]
                        ax.text(x, y, text, ha='center', va='center',
                               fontsize=self.annot_fontsize, color=text_color)
        else:
            # Original behavior: draw as single image
            im = ax.imshow(values, aspect='auto', cmap=cmap,
                          norm=norm, vmin=None if norm else vmin, vmax=None if norm else vmax,
                          interpolation='nearest')

            # Draw cell borders if requested
            if self.linewidth > 0:
                for i in range(n_rows + 1):
                    ax.axhline(i - 0.5, color=self.linecolor, linewidth=self.linewidth)
                for j in range(n_cols + 1):
                    ax.axvline(j - 0.5, color=self.linecolor, linewidth=self.linewidth)

            # Draw cell annotations if requested
            if self.annot:
                for i in range(n_rows):
                    for j in range(n_cols):
                        val = values[i, j]
                        if np.isnan(val):
                            continue

                        text = format(val, self.annot_fmt)

                        if self.annot_color == 'auto':
                            norm_val = norm(val) if norm else ((val - vmin) / (vmax - vmin) if vmax != vmin else 0.5)
                            text_color = 'white' if norm_val > 0.5 else 'black'
                        else:
                            text_color = self.annot_color

                        ax.text(j, i, text, ha='center', va='center',
                               fontsize=self.annot_fontsize, color=text_color)

        ax.set_xticks([])
        ax.set_yticks([])

        # Hide outer border when there are segment gaps
        if has_col_gaps or has_row_gaps:
            for spine in ax.spines.values():
                spine.set_visible(False)

        # Store for colorbar
        self._heatmap_mappable = im
        self._vmin = vmin
        self._vmax = vmax
        self._norm = norm

    def _auto_colorbar_ticks(self):
        """Return 9 evenly-spaced ticks for TwoSlopeNorm colorbars (4 below center, center, 4 above)."""
        if not isinstance(self._norm, TwoSlopeNorm):
            return None
        center = self._norm.vcenter
        ticks_below = np.linspace(self._vmin, center, 5)[:-1]   # 4 ticks, endpoint=center excluded
        ticks_above = np.linspace(center, self._vmax, 5)[1:]     # 4 ticks, startpoint=center excluded
        return np.concatenate([ticks_below, [center], ticks_above])

    def _draw_annotation_labels_right(self, ax_heatmap):
        """
        Draw left-annotation labels on the right side of the heatmap body.

        Used when show_labels='right' on the left annotation. Labels are placed
        just outside the right edge of the heatmap axes, aligned to segment centers.
        """
        ann = self.left_annotation
        if ann is None:
            return

        row_seg_info = self._get_row_segment_gap_info()
        if row_seg_info is None:
            return

        segments = row_seg_info['segments']
        position_offset = row_seg_info['position_offset']

        first_name = list(ann._processed.keys())[0]
        data = ann._processed[first_name].get('data', ann._processed[first_name])
        if isinstance(data, pd.Series):
            data_ordered = data.iloc[self._row_order]
        else:
            data_ordered = np.array(data)[self._row_order]
        data_values = data_ordered.values if isinstance(data_ordered, pd.Series) else data_ordered

        # Offset in axes-fraction units: convert label_offset from inches
        fig = ax_heatmap.get_figure()
        bbox = ax_heatmap.get_position()
        ax_w_inch = bbox.width * fig.get_figwidth()
        offset_axes = ann.label_offset.to_inches() / ax_w_inch if ax_w_inch > 0 else 0.01

        for start, end in segments:
            start_pos = start + position_offset[start]
            end_pos = (end - 1) + position_offset[end - 1]
            center = (start_pos + end_pos) / 2
            label = ann.label_formatter(data_values[start])
            ax_heatmap.text(
                1 + offset_axes, center, label,
                ha='left', va='center',
                fontsize=ann.label_fontsize,
                transform=ax_heatmap.get_yaxis_transform(),
                clip_on=False,
            )

    def _draw_cluster_dendrogram(self, ax, cluster_linkage):
        """
        Draw a dendrogram where each leaf is a cluster group, not an individual row.

        Leaves are positioned at the y-center of each cluster group as it appears in
        the heatmap (accounting for row_gap between groups). Requires a left/right
        annotation with segment_gap to be set so cluster boundaries are known.
        """
        row_seg_info = self._get_row_segment_gap_info()
        if row_seg_info is None:
            ax.axis('off')
            return

        segments = row_seg_info['segments']
        position_offset = row_seg_info['position_offset']
        n_clusters = len(segments)
        n_rows = len(self._row_order)
        total_height = n_rows + (position_offset[-1] if len(position_offset) > 0 else 0)

        # y-center of each cluster group in heatmap data coordinates (y=0 at top)
        cluster_centers = []
        for start, end in segments:
            start_pos = start + position_offset[start]
            end_pos = (end - 1) + position_offset[end - 1]
            cluster_centers.append((start_pos + end_pos) / 2)

        dendro = dendrogram(cluster_linkage, no_plot=True)
        icoord = np.array(dendro['icoord'], dtype=float)
        dcoord = np.array(dendro['dcoord'], dtype=float)

        # Scipy places leaf i at position 5 + 10*i; remap to actual cluster centers
        scipy_leaf_pos = np.array([5 + 10 * i for i in range(n_clusters)], dtype=float)
        icoord_remapped = np.interp(icoord.ravel(), scipy_leaf_pos, cluster_centers).reshape(icoord.shape)

        # Crop leaf stubs so they don't dominate.
        # Strategy: replace dcoord=0 (leaf baseline) with x_min so every leaf
        # gets a short uniform stub regardless of when it joins the tree.
        # x_min is set just below the shallowest merge, making stubs ~5% of the
        # tree's internal span. This mirrors R's ComplexHeatmap style.
        max_d = float(dcoord.max())
        nonzero_d = dcoord[dcoord > 0]
        min_d = float(nonzero_d.min()) if len(nonzero_d) > 0 else max_d * 0.85
        d_range = max_d - min_d
        stub = d_range * 0.05 if d_range > 0 else max_d * 0.05
        x_min = min_d - stub

        dcoord_plot = dcoord.copy()
        dcoord_plot[dcoord_plot == 0] = x_min

        # Left-side dendrogram: x=linkage distance (reversed), y=position
        for xs, ys in zip(icoord_remapped, dcoord_plot):
            ax.plot(ys, xs, color='black', linewidth=self.dendrogram_linewidth)

        # Match heatmap y-axis exactly (y=0 at top, same inverted orientation)
        ax.set_ylim(total_height - 0.5, -0.5)
        ax.set_xlim(max_d, x_min)
        ax.axis('off')

    def _draw_dendrogram(self, ax, linkage_matrix, orientation='top'):
        """Draw dendrogram."""
        n = len(linkage_matrix) + 1  # number of leaves
        dendro = dendrogram(linkage_matrix, no_plot=True)

        icoord = np.array(dendro['icoord'])
        dcoord = np.array(dendro['dcoord'])

        # Scale icoord to match heatmap pixel positions
        # scipy dendrogram default: leaves at 5, 15, 25, ..., 10*n-5
        # We want: leaves at 0, 1, 2, ..., n-1 (matching imshow pixel centers)
        icoord_scaled = (icoord - 5) / 10

        if orientation in ['top', 'bottom']:
            for xs, ys in zip(icoord_scaled, dcoord):
                ax.plot(xs, ys, color='black', linewidth=self.dendrogram_linewidth)
            ax.set_xlim(-0.5, n - 0.5)  # Match imshow extent
            ax.set_ylim(0, max(map(max, dcoord)))
            if orientation == 'bottom':
                ax.invert_yaxis()
        else:  # left or right
            for xs, ys in zip(icoord_scaled, dcoord):
                ax.plot(ys, xs, color='black', linewidth=self.dendrogram_linewidth)
            ax.set_ylim(n - 0.5, -0.5)  # Inverted to match heatmap body orientation
            ax.set_xlim(max(map(max, dcoord)), 0)  # Reversed for left

        ax.axis('off')

    def _draw_row_names(self, ax):
        """Draw row labels."""
        data = self._data_normalized.iloc[self._row_order]

        # Use custom labels if provided, otherwise use index
        if self.labels_row is not None:
            labels = [self.labels_row[i] for i in self._row_order]
        else:
            labels = data.index.tolist()

        n = len(labels)

        # Get segment gap info for row positioning
        row_seg_info = self._get_row_segment_gap_info()
        row_offset = row_seg_info['position_offset'] if row_seg_info else np.zeros(n)
        total_height = n + (row_offset[-1] if len(row_offset) > 0 else 0)

        ax.set_xlim(0, 1)
        ax.set_ylim(-0.5, total_height - 0.5)  # Match heatmap extent with gaps
        ax.invert_yaxis()  # Match imshow orientation (y=0 at top)

        for i, label in enumerate(labels):
            y = i + row_offset[i]  # Adjust position for gaps
            ax.text(0.05, y, str(label),
                   va='center', ha='left', fontsize=self.fontsize_row)

        ax.axis('off')

    def _draw_col_names(self, ax):
        """Draw column labels."""
        data = self._data_normalized.iloc[:, self._col_order]

        # Use custom labels if provided, otherwise use columns
        if self.labels_col is not None:
            labels = [self.labels_col[i] for i in self._col_order]
        else:
            labels = data.columns.tolist()

        n = len(labels)

        # Get segment gap info for column positioning
        col_seg_info = self._get_col_segment_gap_info()
        col_offset = col_seg_info['position_offset'] if col_seg_info else np.zeros(n)
        total_width = n + (col_offset[-1] if len(col_offset) > 0 else 0)

        ax.set_xlim(-0.5, total_width - 0.5)  # Match heatmap extent with gaps
        ax.set_ylim(0, 1)

        # Determine alignment based on rotation
        if self.col_names_rotation == 0:
            ha = 'center'
        elif self.col_names_rotation == 90:
            ha = 'center'
        elif self.col_names_rotation == 45:
            ha = 'right'
        else:
            ha = 'right'

        for i, label in enumerate(labels):
            x = i + col_offset[i]  # Adjust position for gaps
            ax.text(x, 0.95, str(label),
                   va='top', ha=ha, fontsize=self.fontsize_col,
                   rotation=self.col_names_rotation)

        ax.axis('off')

    def _draw_annotation_legend(self, ax, ax_heatmap=None):
        """Draw legend for annotation colors."""
        ax.axis('off')

        # Collect all annotation color mappings
        all_legends = {}
        for annot_obj in [self.top_annotation, self.bottom_annotation,
                          self.left_annotation, self.right_annotation]:
            if annot_obj is None or not annot_obj.show_legend:
                continue
            for name, processed in annot_obj._processed.items():
                data = processed.get('data', processed)
                if isinstance(data, pd.Series):
                    unique_vals = data.dropna().unique()
                elif isinstance(data, np.ndarray):
                    unique_vals = pd.unique(data[~pd.isna(data)])
                else:
                    continue

                # Skip if this looks like direct color values
                if len(unique_vals) > 0:
                    first = unique_vals[0]
                    if isinstance(first, str) and (first.startswith('#') or first in plt.colormaps()):
                        continue

                # Get colors for unique values
                colors = annot_obj._get_colors(pd.Series(unique_vals), name)
                all_legends[name] = list(zip(unique_vals, colors))

        if not all_legends:
            return

        # Get axes dimensions in inches for unit conversion
        fig = ax.get_figure()
        bbox = ax.get_position()
        ax_width_inch = bbox.width * fig.get_figwidth()
        ax_height_inch = bbox.height * fig.get_figheight()

        # Use absolute units for consistent sizing
        box_size_inch = self.legend_box_size.to_inches()
        item_gap_inch = self.legend_item_gap.to_inches()

        # Convert to axes coordinates (different for width and height to get perfect square)
        box_width_axes = box_size_inch / ax_width_inch
        box_height_axes = box_size_inch / ax_height_inch
        item_gap_axes = item_gap_inch / ax_height_inch

        fontsize = 6

        # Align legend top with heatmap top
        if ax_heatmap is not None:
            heatmap_bbox = ax_heatmap.get_position()
            legend_bbox = ax.get_position()
            # Convert heatmap top (in figure coords) to legend axes coords
            heatmap_top_fig = heatmap_bbox.y1
            y_pos = (heatmap_top_fig - legend_bbox.y0) / legend_bbox.height
        else:
            y_pos = 0.95

        # Gap between bottom of title and top of first box (1mm)
        title_gap_inch = unit(1, 'mm').to_inches()
        title_gap_axes = title_gap_inch / ax_height_inch

        for name, items in all_legends.items():
            # Draw title and measure its height
            title_text = ax.text(0.02, y_pos, name, fontsize=fontsize + 1,
                                 transform=ax.transAxes, va='top', ha='left')
            # Get title height in axes coordinates
            renderer = fig.canvas.get_renderer()
            title_bbox = title_text.get_window_extent(renderer)
            title_height_axes = (title_bbox.height / fig.dpi) / ax_height_inch
            # Move down by title height + 1mm gap
            y_pos -= (title_height_axes + title_gap_axes)

            for val, color in items:
                if y_pos < 0.02:  # Stop if we're running out of space
                    break

                # Color box (perfect square using absolute units, no gap between items)
                rect = plt.Rectangle((0.02, y_pos - box_height_axes), box_width_axes, box_height_axes,
                                     facecolor=color, edgecolor='none',
                                     linewidth=0, transform=ax.transAxes,
                                     clip_on=False)
                ax.add_patch(rect)

                # Label
                ax.text(0.02 + box_width_axes + 0.02, y_pos - box_height_axes / 2, str(val), fontsize=fontsize,
                       transform=ax.transAxes, va='center', ha='left')
                y_pos -= (box_height_axes + item_gap_axes)

            y_pos -= box_height_axes  # Gap between annotation groups


class HeatmapResult:
    """Container for heatmap results."""

    def __init__(self, fig, axes, row_order, col_order, row_linkage, col_linkage, data):
        self.fig = fig
        self.axes = axes
        self.row_order = row_order
        self.col_order = col_order
        self.row_linkage = row_linkage
        self.col_linkage = col_linkage
        self.data = data

    def savefig(self, path, dpi=300, **kwargs):
        """Save the figure."""
        self.fig.savefig(path, dpi=dpi, bbox_inches='tight', **kwargs)


# =============================================================================
# Convenience Functions
# =============================================================================

def clustermap(
    data,
    width=None,
    height=None,
    row_cluster=True,
    col_cluster=True,
    method='average',
    metric='euclidean',
    z_score=None,
    cmap='RdBu_r',
    center=None,
    vmin=None,
    vmax=None,
    na_color='#808080',
    row_colors=None,
    col_colors=None,
    row_order=None,
    col_order=None,
    annot=False,
    annot_fmt='.2g',
    linewidth=0,
    linecolor='white',
    fontsize_row=6,
    fontsize_col=6,
    col_names_rotation=90,
    figsize=None,
    **kwargs
):
    """
    Create a clustered heatmap (convenience function).

    This is a simpler interface to Heatmap for common use cases.

    Parameters:
    -----------
    data : DataFrame or ndarray
        Data matrix.
    width : Unit, optional
        Total heatmap body width. Default: 50mm.
    height : Unit, optional
        Total heatmap body height. Default: 50mm.
    row_cluster, col_cluster : bool
        Whether to cluster rows/columns.
    method : str
        Clustering method.
    metric : str
        Distance metric.
    z_score : int or None
        Z-score normalization (0=rows, 1=columns).
    cmap : str
        Colormap.
    center : float, optional
        Center value for colormap.
    vmin, vmax : float, optional
        Colormap range.
    na_color : str, default='#808080'
        Color for NA/missing values.
    row_colors, col_colors : Series, DataFrame, or dict
        Annotation colors.
    row_order, col_order : array-like, optional
        Custom ordering (overrides clustering).
    annot : bool, default=False
        Show values in cells.
    annot_fmt : str, default='.2g'
        Format string for annotations.
    linewidth : float, default=0
        Width of cell borders.
    linecolor : str, default='white'
        Color of cell borders.
    fontsize_row, fontsize_col : int, default=6
        Font size for row/column labels.
    col_names_rotation : int, default=90
        Rotation angle for column labels.
    figsize : tuple of (float, float), optional
        Overall figure size in inches. When set, the heatmap body fills
        the remaining space after peripherals. Overrides width/height.

    Returns:
    --------
    HeatmapResult
    """
    hm_kwargs = {}
    if width is not None:
        hm_kwargs['width'] = width
    if height is not None:
        hm_kwargs['height'] = height
    if figsize is not None:
        hm_kwargs['figsize'] = figsize

    hm = Heatmap(
        data,
        row_cluster=row_cluster,
        col_cluster=col_cluster,
        method=method,
        metric=metric,
        z_score=z_score,
        cmap=cmap,
        center=center,
        vmin=vmin,
        vmax=vmax,
        na_color=na_color,
        row_order=row_order,
        col_order=col_order,
        annot=annot,
        annot_fmt=annot_fmt,
        linewidth=linewidth,
        linecolor=linecolor,
        fontsize_row=fontsize_row,
        fontsize_col=fontsize_col,
        col_names_rotation=col_names_rotation,
        **hm_kwargs,
        **kwargs
    )

    # Add annotations if provided
    if col_colors is not None:
        if isinstance(col_colors, pd.Series):
            col_colors = pd.DataFrame({col_colors.name or 'group': col_colors})
        elif isinstance(col_colors, dict):
            col_colors = pd.DataFrame(col_colors)
        hm.add_top_annotation(HeatmapAnnotation(**{
            c: col_colors[c] for c in col_colors.columns
        }))

    if row_colors is not None:
        if isinstance(row_colors, pd.Series):
            row_colors = pd.DataFrame({row_colors.name or 'group': row_colors})
        elif isinstance(row_colors, dict):
            row_colors = pd.DataFrame(row_colors)
        hm.add_left_annotation(HeatmapAnnotation(**{
            c: row_colors[c] for c in row_colors.columns
        }))

    return hm.draw()
