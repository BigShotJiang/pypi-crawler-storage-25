"""
omicsplot.heatmap — publication-quality heatmaps with absolute physical sizing.

Inspired by R's ComplexHeatmap. The heatmap body is specified in physical
units (mm, cm, inch, pt) and surrounding panels (dendrograms, annotations,
labels, colorbar, legend) grow outward without shrinking the body.

Composition operators ``|`` (side-by-side) and ``/`` (stacked) align body
positions exactly across panels.
"""

from ..units import Unit, CompositeUnit, unit, LayoutEngine

from .heatmap import (
    Heatmap,
    HeatmapAnnotation,
    HeatmapResult,
    anno_simple,
    anno_barplot,
    clustermap,
)

from .genomic_heatmap import make_chrom_annotation, genomic_heatmap

from .concat import HeatmapConcat, HeatmapStack, HeatmapConcatResult

__all__ = [
    # Units (re-exported for convenience)
    "Unit",
    "CompositeUnit",
    "unit",
    "LayoutEngine",
    # Heatmap
    "Heatmap",
    "HeatmapAnnotation",
    "HeatmapResult",
    "anno_simple",
    "anno_barplot",
    "clustermap",
    # Genomic heatmap
    "make_chrom_annotation",
    "genomic_heatmap",
    # Composition
    "HeatmapConcat",
    "HeatmapStack",
    "HeatmapConcatResult",
]
