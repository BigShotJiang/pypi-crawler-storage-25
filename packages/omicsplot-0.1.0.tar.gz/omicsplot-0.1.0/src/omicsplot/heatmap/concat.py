"""
Heatmap composition: horizontal (|) and vertical (/) concatenation.

Three design goals:

1. **Size consistency** — `A | B` forces matching body height; `A / B` forces
   matching body width, so cells are the same physical size across panels.

2. **Body alignment** — even when panels differ in how many decorations they
   carry (dendrograms, annotations, titles), the heatmap bodies always start
   at the same absolute position in the figure.  This is achieved by computing
   absolute inch coordinates for every body via layout.compute_placements()
   and placing each axis with fig.add_axes() — no GridSpec subdivision.

3. **Unified colorbar + legend** — individual colorbars and annotation legends
   are suppressed on each leaf; a single shared panel on the right side of the
   figure collects them all.

Usage
-----
A | B          → HeatmapConcat  (side by side, shared row order)
A / B          → HeatmapStack   (stacked, shared col order)
(A | B) / C   → HeatmapStack of [HeatmapConcat([A, B]), C]
A | B | C      → HeatmapConcat([A, B, C])  (flattened)
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from . import layout as _layout


# ---------------------------------------------------------------------------
# Result container
# ---------------------------------------------------------------------------

class HeatmapConcatResult:
    """Returned by HeatmapConcat.draw() and HeatmapStack.draw()."""

    def __init__(self, fig, results):
        self.fig = fig
        self.results = results  # list of HeatmapResult (or nested lists)


# ---------------------------------------------------------------------------
# Colorbar / legend helpers
# ---------------------------------------------------------------------------

def _get_annot_objects(leaves):
    """Return list of (hm, annot) for all annotations with show_legend=True."""
    result = []
    for hm in leaves:
        for annot in [hm.top_annotation, hm.bottom_annotation,
                      hm.left_annotation, hm.right_annotation]:
            if annot is not None and annot.show_legend:
                result.append((hm, annot))
    return result


def _suppress_colorbar_legend(leaves, annot_objs):
    orig_cbar = {id(hm): hm.show_colorbar for hm in leaves}
    for hm in leaves:
        hm.show_colorbar = False

    orig_legend = {id(a): a.show_legend for _, a in annot_objs}
    for _, a in annot_objs:
        a.show_legend = False

    return orig_cbar, orig_legend


def _restore_colorbar_legend(leaves, annot_objs, orig_cbar, orig_legend):
    for hm in leaves:
        hm.show_colorbar = orig_cbar[id(hm)]
    for _, a in annot_objs:
        a.show_legend = orig_legend[id(a)]


def _unified_panel_width(leaves, orig_cbar, annot_objs):
    """Required width (inches) for the unified right-side panel."""
    w = 0
    cbar_leaves = [hm for hm in leaves if orig_cbar.get(id(hm), False)]
    if cbar_leaves:
        w += 0.08 + max(hm.colorbar_size.to_inches() for hm in cbar_leaves) + 0.2
    if annot_objs:
        w += max(hm.annotation_legend_size.to_inches() for hm, _ in annot_objs) + 0.15
    return w


def _draw_unified_panel(fig, x0_inch, fig_h_inch, panel_h_inch,
                        leaves, orig_cbar, annot_objs):
    """Draw colorbars and annotation legends in the unified right-side panel.

    Returns
    -------
    cbar_axes : list of Axes
        The colorbar axes, used by _fix_colorbar_overflow.
    leg_ax : Axes or None
        The annotation legend axes, or None if there are no annotation legends.
    """
    fw = fig.get_figwidth()
    fh = fig.get_figheight()

    x_cursor = x0_inch + 0.08
    y0 = fh - panel_h_inch   # bottom of panel in fig coords (inches)
    ph = panel_h_inch

    cbar_axes = []
    leg_ax = None

    # ---- Colorbars ----
    cbar_leaves = [hm for hm in leaves if orig_cbar.get(id(hm), False)]
    if cbar_leaves:
        cbar_w = max(hm.colorbar_size.to_inches() for hm in cbar_leaves)
        cbar_gap = 0.15
        max_cbar_h = max(hm.colorbar_height.to_inches() for hm in cbar_leaves)
        n = len(cbar_leaves)
        total_needed = n * max_cbar_h + (n - 1) * cbar_gap
        if total_needed > ph * 0.9:
            scale = (ph * 0.9) / total_needed
            max_cbar_h *= scale
            cbar_gap *= scale

        y_cur = y0 + ph
        for hm in cbar_leaves:
            if not hasattr(hm, '_heatmap_mappable') or hm._heatmap_mappable is None:
                continue
            cbar_h = min(hm.colorbar_height.to_inches(), max_cbar_h)
            y_cur -= cbar_h
            ax_cb = fig.add_axes([x_cursor / fw, y_cur / fh,
                                   cbar_w / fw, cbar_h / fh])
            cbar = fig.colorbar(hm._heatmap_mappable, cax=ax_cb)
            cbar.ax.tick_params(labelsize=6, length=0)
            if hm.legend_breaks is not None:
                cbar.set_ticks(hm.legend_breaks)
                if hm.legend_labels is not None:
                    cbar.set_ticklabels(hm.legend_labels)
            label = hm.colorbar_label or hm.name or ''
            if label:
                cbar.set_label(label, fontsize=7)
            y_cur -= cbar_gap
            cbar_axes.append(ax_cb)

        x_cursor += cbar_w + 0.2

    # ---- Annotation legend ----
    if annot_objs:
        leg_w = max(hm.annotation_legend_size.to_inches() for hm, _ in annot_objs)
        ax_leg = fig.add_axes([x_cursor / fw, y0 / fh, leg_w / fw, ph / fh])
        ax_leg.axis('off')
        _draw_combined_legend(ax_leg, annot_objs, leaves)
        leg_ax = ax_leg

    return cbar_axes, leg_ax


def _fix_colorbar_overflow(fig, cbar_axes, leg_ax):
    """Two-pass correction: expand figure and shift legend if colorbar labels overflow.

    Colorbar tick labels extend beyond the colorbar axes frame, but their
    actual width isn't known until after rendering.  This function draws the
    figure onto the Agg backend, measures the tight bounding boxes, and fixes
    any overlap between colorbar labels and the legend (or the figure edge).
    """
    if not cbar_axes:
        return

    fig.canvas.draw()
    try:
        renderer = fig.canvas.get_renderer()
    except AttributeError:
        return

    dpi = fig.dpi
    fig_w = fig.get_figwidth()

    # Measure how far colorbar labels spill past the right edge of the figure
    # or into the legend axes.
    if leg_ax is not None:
        boundary_inch = leg_ax.get_window_extent().x0 / dpi
    else:
        boundary_inch = fig_w  # right edge of figure

    overflow_inch = 0.0
    for ax in cbar_axes:
        tight = ax.get_tightbbox(renderer)
        if tight is None:
            continue
        overflow_inch = max(overflow_inch, tight.x1 / dpi - boundary_inch)

    if overflow_inch <= 1e-3:
        return

    extra = overflow_inch + 0.05   # measured overflow + small breathing room
    new_fig_w = fig_w + extra

    # Rescale ALL axes fractions so their absolute positions stay the same.
    # (fig.set_size_inches keeps fractions fixed, which would move everything
    # rightward — we want to add whitespace on the right only.)
    for ax in fig.axes:
        pos = ax.get_position()
        ax.set_position([
            pos.x0 * fig_w / new_fig_w,
            pos.y0,
            pos.width * fig_w / new_fig_w,
            pos.height,
        ])

    # Shift the legend right by `extra` on top of the rescaling above.
    if leg_ax is not None:
        pos = leg_ax.get_position()
        leg_ax.set_position([
            pos.x0 + extra / new_fig_w,
            pos.y0,
            pos.width,
            pos.height,
        ])

    fig.set_size_inches(new_fig_w, fig.get_figheight())


def _draw_combined_legend(ax, annot_objs, leaves):
    """Draw categorical annotation legends, deduplicating by track name."""
    first_hm = leaves[0]
    box_size_inch = first_hm.legend_box_size.to_inches()
    item_gap_inch = first_hm.legend_item_gap.to_inches()
    fontsize = 6

    fig = ax.get_figure()
    try:
        renderer = fig.canvas.get_renderer()
    except AttributeError:
        fig.canvas.draw()
        renderer = fig.canvas.get_renderer()

    bbox = ax.get_position()
    ax_w_inch = bbox.width * fig.get_figwidth()
    ax_h_inch = bbox.height * fig.get_figheight()

    box_w = box_size_inch / ax_w_inch
    box_h = box_size_inch / ax_h_inch
    item_gap = item_gap_inch / ax_h_inch
    from ..units import unit
    title_gap = unit(1, 'mm').to_inches() / ax_h_inch

    seen = set()
    all_legends = {}
    for hm, annot in annot_objs:
        for name, processed in annot._processed.items():
            if name in seen:
                continue
            data = processed.get('data', processed)
            if isinstance(data, pd.Series):
                unique_vals = data.dropna().unique()
            elif isinstance(data, np.ndarray):
                unique_vals = pd.unique(data[~pd.isna(data)])
            else:
                continue
            if len(unique_vals) == 0:
                continue
            first = unique_vals[0]
            if isinstance(first, str) and (first.startswith('#') or first in plt.colormaps()):
                continue
            colors = annot._get_colors(pd.Series(unique_vals), name)
            all_legends[name] = list(zip(unique_vals, colors))
            seen.add(name)

    if not all_legends:
        return

    y_pos = 0.97
    for name, items in all_legends.items():
        t = ax.text(0.02, y_pos, name, fontsize=fontsize + 1,
                    transform=ax.transAxes, va='top', ha='left', fontweight='bold')
        t_bbox = t.get_window_extent(renderer)
        t_h = (t_bbox.height / fig.dpi) / ax_h_inch
        y_pos -= t_h + title_gap
        for val, color in items:
            if y_pos < 0.02:
                break
            rect = plt.Rectangle(
                (0.02, y_pos - box_h), box_w, box_h,
                facecolor=color, edgecolor='none',
                transform=ax.transAxes, clip_on=False,
            )
            ax.add_patch(rect)
            ax.text(0.02 + box_w + 0.02, y_pos - box_h / 2, str(val),
                    fontsize=fontsize, transform=ax.transAxes, va='center', ha='left')
            y_pos -= box_h + item_gap
        y_pos -= box_h


# ---------------------------------------------------------------------------
# Horizontal concatenation  (A | B)
# ---------------------------------------------------------------------------

class HeatmapConcat:
    """
    Side-by-side heatmaps, created by ``A | B``.

    - Row order is shared from the first panel (optional).
    - Body heights are synced to the first panel's height.
    - Bodies are aligned to the same absolute y coordinate regardless of
      how many decorations sit above each panel.
    """

    def __init__(self, heatmaps):
        self.heatmaps = list(heatmaps)

    def __or__(self, other):
        right = other.heatmaps if isinstance(other, HeatmapConcat) else [other]
        return HeatmapConcat(self.heatmaps + right)

    def __truediv__(self, other):
        return HeatmapStack([self, other])

    def draw(self, share_row_order=True):
        """
        Render all heatmaps into a shared figure.

        Parameters
        ----------
        share_row_order : bool, default True
            Apply the first panel's row clustering order to all others.

        Returns
        -------
        HeatmapConcatResult
        """
        leaves = self._get_leaves()

        for hm in leaves:
            hm._compute_clustering()

        n_rows = [hm.data.shape[0] for hm in leaves]
        if len(set(n_rows)) > 1:
            raise ValueError(
                f"All heatmaps in | must have the same number of rows, got {n_rows}"
            )

        if share_row_order and len(leaves) > 1:
            primary = leaves[0]
            for hm in leaves[1:]:
                hm._row_order = primary._row_order.copy()
                hm._row_linkage = None

        # Sync body heights (all match the first leaf)
        target_h = leaves[0].height
        orig_heights = {id(hm): hm.height for hm in leaves}
        for hm in leaves:
            hm.height = target_h

        annot_objs = _get_annot_objects(leaves)
        orig_cbar, orig_legend = _suppress_colorbar_legend(leaves, annot_objs)

        try:
            upw = _unified_panel_width(leaves, orig_cbar, annot_objs)
            fig_w, fig_h = _layout.figure_size_for_concat(self, unified_panel_w=upw)

            fig = plt.figure(figsize=(fig_w, fig_h))

            placements = _layout.compute_placements(self, x_origin=0.0, y_origin=0.0)

            results = []
            for hm, body_x, body_y in placements:
                results.append(hm.draw_placed(fig, body_x, body_y))

            if upw > 0:
                # unified panel spans the full figure height
                content_w = fig_w - upw - _layout.FIGURE_MARGIN
                cbar_axes, leg_ax = _draw_unified_panel(fig, content_w, fig_h, fig_h,
                                                        leaves, orig_cbar, annot_objs)
                _fix_colorbar_overflow(fig, cbar_axes, leg_ax)

        finally:
            _restore_colorbar_legend(leaves, annot_objs, orig_cbar, orig_legend)
            for hm in leaves:
                hm.height = orig_heights[id(hm)]

        return HeatmapConcatResult(fig=fig, results=results)

    def _get_leaves(self):
        from .heatmap import Heatmap
        out = []
        for item in self.heatmaps:
            if isinstance(item, Heatmap):
                out.append(item)
            else:
                out.extend(item._get_leaves())
        return out


# ---------------------------------------------------------------------------
# Column-order helpers for HeatmapStack
# ---------------------------------------------------------------------------

def _row_ncols(row):
    """Total column count for a row (Heatmap or HeatmapConcat)."""
    from .heatmap import Heatmap
    if isinstance(row, Heatmap):
        return row.data.shape[1]
    return sum(hm.data.shape[1] for hm in row._get_leaves())


def _set_row_body_widths(row, primary_row):
    """Set row's leaf widths to match primary_row's leaf widths.

    For a single-Heatmap compound row: width is set to the span from the
    leftmost primary body's left edge to the rightmost primary body's right
    edge — i.e. sum of all primary leaf body widths plus the inter-leaf gaps
    (each inner leaf's left_side decoration width).  This ensures the figure
    size calculation allocates enough horizontal space.
    For a HeatmapConcat row: each leaf gets the corresponding primary leaf width.
    """
    from .heatmap import Heatmap
    from ..units import unit as _unit
    from . import layout as _layout
    primary_leaves = (primary_row._get_leaves()
                      if not isinstance(primary_row, Heatmap)
                      else [primary_row])
    if isinstance(row, Heatmap):
        # body span = sum of each primary leaf's body width plus the gaps
        # introduced by inner leaves' left_side decorations.
        primary_pls = [_layout.measure(hm) for hm in primary_leaves]
        body_span = sum(pl.body_w for pl in primary_pls)
        # Each leaf after the first adds its left_side as a visual gap between
        # the segments of C.
        body_span += sum(pl.left_side for pl in primary_pls[1:])
        row.width = _unit(body_span, 'inch')
    else:
        for hm, ref in zip(row._get_leaves(), primary_leaves):
            hm.width = _unit(ref.width.to_inches(), 'inch')


def _extract_combined_col_order(row):
    """Return a flat combined col_order for a row, with per-segment offsets applied.

    For a single Heatmap with col_order [2, 0, 1] → [2, 0, 1].
    For HeatmapConcat([A, B]) with A.col_order=[2,0,1], B.col_order=[1,0]
    → [2, 0, 1, 4, 3]  (B's indices shifted by n_a=3).
    """
    from .heatmap import Heatmap
    if isinstance(row, Heatmap):
        return row._col_order.copy()
    parts = []
    offset = 0
    for hm in row._get_leaves():
        parts.append(hm._col_order + offset)
        offset += hm.data.shape[1]
    return np.concatenate(parts)


def _apply_combined_col_order(row, order, primary_row):
    """Apply a combined col_order to a row's leaves.

    For a single Heatmap: set col_order directly.
    For a HeatmapConcat: split the order by each leaf's column count and
    subtract the running offset so indices stay 0-based within each leaf.
    The constituent column counts must match those of primary_row.
    """
    from .heatmap import Heatmap
    if isinstance(row, Heatmap):
        row._col_order = order.copy()
        row._col_linkage = None
        return

    # HeatmapConcat: validate matching structure then split
    my_leaves = row._get_leaves()
    primary_leaves = primary_row._get_leaves() if not isinstance(primary_row, Heatmap) else [primary_row]
    my_ncols = [hm.data.shape[1] for hm in my_leaves]
    primary_ncols = [hm.data.shape[1] for hm in primary_leaves]
    if my_ncols != primary_ncols:
        raise ValueError(
            f"Cannot share column order: row has constituent column counts "
            f"{my_ncols} but primary row has {primary_ncols}. "
            f"Constituent counts must match for HeatmapConcat rows."
        )
    offset = 0
    for hm, n in zip(my_leaves, my_ncols):
        hm._col_order = order[offset:offset + n] - offset
        hm._col_linkage = None
        offset += n


# ---------------------------------------------------------------------------
# Vertical stack  (A / B)
# ---------------------------------------------------------------------------

class HeatmapStack:
    """
    Vertically stacked heatmaps, created by ``A / B``.

    - Column order is shared from the first panel (optional).
    - Body widths are synced to the first panel's width.
    - Bodies are aligned to the same absolute x coordinate regardless of
      how many decorations sit to the left of each panel.
    """

    def __init__(self, rows):
        self.rows = list(rows)

    def __truediv__(self, other):
        bottom = other.rows if isinstance(other, HeatmapStack) else [other]
        return HeatmapStack(self.rows + bottom)

    def __or__(self, other):
        return HeatmapConcat([self, other])

    def draw(self, share_col_order=True):
        """
        Render all heatmaps into a shared figure.

        Parameters
        ----------
        share_col_order : bool, default True
            Apply the first panel's column clustering order to all others.

        Returns
        -------
        HeatmapConcatResult
        """
        leaves = self._get_leaves()

        for hm in leaves:
            hm._compute_clustering()

        row_ncols = [_row_ncols(row) for row in self.rows]
        if len(set(row_ncols)) > 1:
            raise ValueError(
                f"All rows in / must have the same total number of columns, got {row_ncols}"
            )

        if share_col_order and len(self.rows) > 1:
            primary_row = self.rows[0]
            combined_order = _extract_combined_col_order(primary_row)
            for row in self.rows[1:]:
                _apply_combined_col_order(row, combined_order, primary_row)

        # Sync body widths: each row's leaves are matched to the primary row's
        # leaf widths.  For a single-Heatmap row, its width becomes the sum of
        # all primary-row leaf widths.  For a HeatmapConcat row, each leaf gets
        # the width of the corresponding primary leaf.
        orig_widths = {id(hm): hm.width for hm in leaves}
        primary_row = self.rows[0]
        for row in self.rows[1:]:
            _set_row_body_widths(row, primary_row)

        # Identify compound non-primary rows: a single Heatmap row when the
        # primary row is a HeatmapConcat.  These must be drawn as one segment
        # per primary leaf so that each segment aligns to the correct column
        # group above it (e.g. C_left below A, C_right below B).
        from .heatmap import Heatmap as _Heatmap
        primary_leaves = (primary_row._get_leaves()
                          if not isinstance(primary_row, _Heatmap)
                          else [primary_row])
        compound_leaves = set()
        if not isinstance(primary_row, _Heatmap):
            for row in self.rows[1:]:
                if isinstance(row, _Heatmap):
                    compound_leaves.add(id(row))

        annot_objs = _get_annot_objects(leaves)
        orig_cbar, orig_legend = _suppress_colorbar_legend(leaves, annot_objs)

        try:
            upw = _unified_panel_width(leaves, orig_cbar, annot_objs)
            fig_w, fig_h = _layout.figure_size_for_stack(self, unified_panel_w=upw)

            fig = plt.figure(figsize=(fig_w, fig_h))

            placements = _layout.compute_placements(self, x_origin=0.0, y_origin=0.0)

            # body_pos maps each leaf to its absolute (body_x, body_y) so that
            # compound rows can look up the primary leaves' x positions.
            body_pos = {id(hm): (bx, by) for hm, bx, by in placements}

            results = []
            for hm, body_x, body_y in placements:
                if id(hm) not in compound_leaves:
                    results.append(hm.draw_placed(fig, body_x, body_y))
                else:
                    # Compound row: draw one segment per primary leaf.
                    # Each segment uses the primary leaf's body_x and width,
                    # and the corresponding slice of hm._col_order.
                    # Only the first segment draws the left-side decoration.
                    full_col_order = hm._col_order.copy()
                    orig_width = hm.width
                    orig_left_annot = hm.left_annotation
                    orig_row_linkage = hm._row_linkage
                    orig_row_cluster_dend = hm.row_cluster_dendrogram
                    try:
                        col_offset = 0
                        for seg_i, primary_leaf in enumerate(primary_leaves):
                            n = primary_leaf.data.shape[1]
                            hm._col_order = full_col_order[col_offset:col_offset + n]
                            hm.width = primary_leaf.width
                            if seg_i > 0:
                                # Left-side decorations (annotation, row dendrograms)
                                # only belong on the first segment.
                                hm.left_annotation = None
                                hm._row_linkage = None
                                hm.row_cluster_dendrogram = None
                            seg_body_x = body_pos[id(primary_leaf)][0]
                            results.append(hm.draw_placed(fig, seg_body_x, body_y))
                            col_offset += n
                    finally:
                        hm._col_order = full_col_order
                        hm.width = orig_width
                        hm.left_annotation = orig_left_annot
                        hm._row_linkage = orig_row_linkage
                        hm.row_cluster_dendrogram = orig_row_cluster_dend

            if upw > 0:
                content_w = fig_w - upw - _layout.FIGURE_MARGIN
                cbar_axes, leg_ax = _draw_unified_panel(fig, content_w, fig_h, fig_h,
                                                        leaves, orig_cbar, annot_objs)
                _fix_colorbar_overflow(fig, cbar_axes, leg_ax)

        finally:
            _restore_colorbar_legend(leaves, annot_objs, orig_cbar, orig_legend)
            for hm in leaves:
                hm.width = orig_widths[id(hm)]

        return HeatmapConcatResult(fig=fig, results=results)

    def _get_leaves(self):
        from .heatmap import Heatmap
        out = []
        for row in self.rows:
            if isinstance(row, Heatmap):
                out.append(row)
            else:
                out.extend(row._get_leaves())
        return out
