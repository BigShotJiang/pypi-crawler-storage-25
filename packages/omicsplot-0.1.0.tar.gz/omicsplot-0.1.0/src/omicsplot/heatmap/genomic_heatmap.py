"""
Genomic heatmap visualization.

Chromosome-aware heatmap for binned genomic data: methylation, expression,
copy number, accessibility, or any signal measured in genomic bins.
"""

import numpy as np
import pandas as pd

from .heatmap import Heatmap, HeatmapAnnotation
from ..units import unit


# Standard chromosome order
_CHR_ORDER = [f'chr{i}' for i in range(1, 23)] + ['chrX', 'chrY']


def make_chrom_annotation(
    chrom_series,
    chr_order=None,
    show_labels=True,
    label_fontsize=5,
    segment_gap=None,
    height=unit(3, 'mm'),
    width=unit(3, 'mm'),
    even_color='#CCCCCC',
    odd_color='#888888',
):
    """
    Create a chromosome annotation track for genomic heatmaps.

    Parameters:
    -----------
    chrom_series : pd.Series
        Chromosome label for each column (or row) of the heatmap.
    chr_order : list, optional
        Chromosome display order. Default: chr1-22, chrX, chrY.
    show_labels : bool, default=True
        Whether to show chromosome number labels.
    label_fontsize : int, default=5
        Font size for chromosome labels.
    segment_gap : Unit, optional
        Gap between chromosomes. Default: None (no gaps).
    height : Unit, default=3mm
        Height for horizontal (column) annotations.
    width : Unit, default=3mm
        Width for vertical (row) annotations.
    even_color : str, default='#CCCCCC'
        Color for even-indexed chromosomes.
    odd_color : str, default='#888888'
        Color for odd-indexed chromosomes.

    Returns:
    --------
    HeatmapAnnotation
    """
    if chr_order is None:
        chr_order = _CHR_ORDER

    chrom_cat = pd.Categorical(chrom_series, categories=chr_order, ordered=True)

    return HeatmapAnnotation(
        chrom=pd.Series(chrom_cat),
        height=height,
        width=width,
        segment_gap=segment_gap,
        show_labels=show_labels,
        label_fontsize=label_fontsize,
        label_formatter=lambda x: str(x).replace('chr', ''),
        colors={'chrom': {
            chr_name: even_color if i % 2 == 0 else odd_color
            for i, chr_name in enumerate(chr_order)
        }},
        show_legend=False,
    )


def genomic_heatmap(
    data,
    chrom_col='chrom',
    chrom_annotation=None,
    # Body sizing
    width=None,
    height=None,
    # Clustering
    row_cluster=False,
    col_cluster=False,
    method='ward',
    # Colormap
    cmap='RdBu_r',
    vmin=None,
    vmax=None,
    center=None,
    # Chromosome annotation
    show_chrom_annotation=True,
    chrom_position='bottom',
    chrom_labels=True,
    chrom_gap=None,
    chr_order=None,
    # Row annotation
    row_annotation=None,
    row_annotation_colors=None,
    row_annotation_show_legend=True,
    row_annotation_show_labels=False,
    row_gap=None,
    # Labels
    show_row_names=True,
    show_col_names=False,
    fontsize_row=6,
    # Dendrogram
    show_row_dendrogram=True,
    row_dendrogram_size=unit(10, 'mm'),
    dendrogram_linewidth=0.3,
    # Cluster dendrogram
    row_cluster_dendrogram=None,
    show_row_cluster_dendrogram=True,
    row_cluster_dendrogram_size=unit(10, 'mm'),
    # Title
    title=None,
    **kwargs,
):
    """
    Chromosome-aware heatmap for binned genomic data.

    Suitable for any signal measured in genomic bins: methylation, accessibility,
    expression (averaged over bins), copy number, etc. Columns represent genomic
    bins ordered along the genome; rows represent samples or features.

    Parameters:
    -----------
    data : pd.DataFrame
        Data matrix. Two accepted formats:

        - **Track format** (rows=bins, columns=samples): must have a column named
          by ``chrom_col``. The function transposes this to samples-as-rows.
        - **Matrix format** (rows=samples, columns=bins): set ``chrom_col=None``
          and optionally pass ``chrom_annotation`` for the chromosome track.

    chrom_col : str or None, default='chrom'
        Column containing chromosome labels when ``data`` is in track format.
        Set to ``None`` if data is already samples-as-rows.

    chrom_annotation : pd.Series, optional
        Chromosome labels for each column when data is already transposed.
        Takes precedence over extracting from ``chrom_col``.

    width : Unit, optional
        Total heatmap body width. Auto-sized from column count if not given.

    height : Unit, optional
        Total heatmap body height. Auto-sized from row count if not given.

    row_cluster : bool or np.ndarray, default=False
        Row clustering:
        - ``True``: hierarchical clustering computed from ``data``.
        - ``False``: preserve input row order.
        - ``np.ndarray``: pre-computed linkage matrix.

    col_cluster : bool or np.ndarray, default=False
        Column clustering. Usually ``False`` to preserve genome order.

    method : str, default='ward'
        Linkage method for hierarchical clustering.

    cmap : str, default='RdBu_r'
        Colormap.

    vmin, vmax : float, optional
        Colormap range. Auto-determined from data if not given.

    center : float, optional
        Value to center the colormap at (useful for diverging colormaps).

    show_chrom_annotation : bool, default=True
        Whether to add a chromosome annotation track.

    chrom_position : str, default='bottom'
        Position for chromosome annotation: ``'top'`` or ``'bottom'``.

    chrom_labels : bool, default=True
        Whether to show chromosome labels on the annotation track.

    chrom_gap : Unit, optional
        Gap between chromosomes in the annotation (and heatmap body).

    chr_order : list, optional
        Chromosome display order. Default: chr1-22, chrX, chrY.

    row_annotation : pd.DataFrame or dict, optional
        Row-level annotations (e.g. sample metadata).
        Keys are annotation names; values are ``pd.Series``.

    row_annotation_colors : dict, optional
        Color mapping for row annotations.
        Format: ``{'annotation_name': {'category': 'color', ...}}``.

    row_annotation_show_legend : bool, default=True
        Whether to include the row annotation in the legend panel.

    row_annotation_show_labels : bool, default=False
        Whether to show category labels on the row annotation track.

    row_gap : Unit, optional
        Gap between row annotation categories.

    show_row_names : bool, default=True
        Whether to show row labels.

    show_col_names : bool, default=False
        Whether to show column labels. Usually ``False`` for genomic bins.

    fontsize_row : int, default=6
        Font size for row labels.

    show_row_dendrogram : bool, default=True
        Whether to draw the row dendrogram when clustering is active.

    row_dendrogram_size : Unit, default=10mm
        Width of the row dendrogram.

    dendrogram_linewidth : float, default=0.3
        Line width for dendrogram branches.

    row_cluster_dendrogram : np.ndarray, optional
        Pre-computed linkage matrix on cluster groups (one leaf per cluster).
        When provided, draws a cluster-level dendrogram on the far left, with each
        leaf aligned to the center of its cluster's row group. Requires the left
        annotation to have ``segment_gap`` set so cluster boundaries are known.

    show_row_cluster_dendrogram : bool, default=True
        Whether to draw the cluster dendrogram when ``row_cluster_dendrogram`` is set.

    row_cluster_dendrogram_size : Unit, default=10mm
        Width of the cluster dendrogram panel.

    title : str, optional
        Figure title.

    **kwargs
        Additional arguments forwarded to :class:`Heatmap`.

    Returns:
    --------
    HeatmapResult

    Examples:
    ---------
    >>> from omicsplot import unit
    >>> from omicsplot.heatmap import genomic_heatmap

    >>> # Methylation matrix (track format: bins as rows, samples as columns)
    >>> result = genomic_heatmap(meth_df, chrom_col='chrom', cmap='Blues', center=0.5)

    >>> # Matrix format with explicit chromosome annotation
    >>> result = genomic_heatmap(
    ...     matrix,
    ...     chrom_col=None,
    ...     chrom_annotation=chrom_series,
    ...     row_cluster=True,
    ... )

    >>> # With sample metadata annotation
    >>> result = genomic_heatmap(
    ...     matrix,
    ...     row_annotation={'tissue': metadata['tissue']},
    ...     row_annotation_colors={'tissue': {'brain': '#4477AA', 'liver': '#EE6677'}},
    ... )
    """
    if chr_order is None:
        chr_order = _CHR_ORDER

    # --- Data format handling ---
    if chrom_col is not None and chrom_col in data.columns:
        # Track format: extract chrom series and transpose to samples-as-rows
        chrom_series = data[chrom_col].copy()

        meta_cols = {'chrom', 'start', 'end', 'name', chrom_col}
        sample_cols = [c for c in data.columns if c not in meta_cols]

        matrix = data[sample_cols].T.copy()

        if 'start' in data.columns:
            matrix.columns = [
                f"{row[chrom_col]}:{row['start']}"
                for _, row in data[[chrom_col, 'start']].iterrows()
            ]
    else:
        # Matrix format: already samples-as-rows
        matrix = data.copy()
        chrom_series = None

    # Explicit chrom_annotation overrides extracted series
    if chrom_annotation is not None:
        chrom_series = chrom_annotation

    # --- Filter to known chromosomes and sort by chr_order ---
    if chrom_series is not None:
        chrom_series = chrom_series.reset_index(drop=True)
        # Keep only bins whose chromosome appears in chr_order
        known_mask = chrom_series.isin(chr_order)
        chrom_series = chrom_series[known_mask].reset_index(drop=True)
        matrix = matrix.iloc[:, known_mask.values]
        # Sort columns into genomic order (stable so bins within a chrom stay in place)
        chrom_rank = [chr_order.index(c) for c in chrom_series]
        sort_idx = np.argsort(chrom_rank, kind='stable')
        matrix = matrix.iloc[:, sort_idx]
        chrom_series = chrom_series.iloc[sort_idx].reset_index(drop=True)

    # --- Auto-size body ---
    n_rows, n_cols = matrix.shape
    if width is None:
        width = unit(max(20, min(150, n_cols * 0.5)), 'mm')
    if height is None:
        height = unit(max(10, min(200, n_rows * 5)), 'mm')

    # --- Build heatmap ---
    hm = Heatmap(
        matrix,
        width=width,
        height=height,
        row_cluster=row_cluster,
        col_cluster=col_cluster,
        method=method,
        cmap=cmap,
        vmin=vmin,
        vmax=vmax,
        center=center,
        show_row_names=show_row_names,
        show_col_names=show_col_names,
        fontsize_row=fontsize_row,
        show_row_dendrogram=show_row_dendrogram,
        row_dendrogram_size=row_dendrogram_size,
        dendrogram_linewidth=dendrogram_linewidth,
        row_cluster_dendrogram=row_cluster_dendrogram,
        show_row_cluster_dendrogram=show_row_cluster_dendrogram,
        row_cluster_dendrogram_size=row_cluster_dendrogram_size,
        title=title,
        **kwargs,
    )

    # --- Chromosome annotation ---
    if show_chrom_annotation and chrom_series is not None:
        chrom_ann = make_chrom_annotation(
            chrom_series,
            chr_order=chr_order,
            show_labels=chrom_labels,
            segment_gap=chrom_gap,
        )
        if chrom_position == 'top':
            hm.add_top_annotation(chrom_ann)
        else:
            hm.add_bottom_annotation(chrom_ann)

    # --- Row annotation ---
    if row_annotation is not None:
        if isinstance(row_annotation, pd.DataFrame):
            ann_dict = {col: row_annotation[col] for col in row_annotation.columns}
        else:
            ann_dict = row_annotation

        row_ann = HeatmapAnnotation(
            **ann_dict,
            width=unit(3, 'mm'),
            segment_gap=row_gap,
            colors=row_annotation_colors or {},
            show_legend=row_annotation_show_legend,
            show_labels=row_annotation_show_labels,
        )
        hm.add_left_annotation(row_ann)

    return hm.draw()
