"""
omicsplot — publication-quality matplotlib figures for omics data.

Two submodules:

- ``omicsplot.heatmap`` — ComplexHeatmap-style heatmaps with absolute physical
  body sizing, multi-panel composition (``A | B``, ``A / B``), cluster-of-clusters
  dendrograms, and chromosome-aware genomic heatmaps.
- ``omicsplot.tracks`` — chromosome-proportional genome-wide track plots
  (scatter, line, bar, step, SV triangles) sized by chromosome length.

Both share a unit system (mm/cm/inch/pt/npc/null) inspired by R's grid::unit().

Basic usage
-----------
>>> from omicsplot import unit
>>> from omicsplot.heatmap import Heatmap, HeatmapAnnotation
>>> from omicsplot.tracks import ScatterTrack, plot_tracks
"""

from .units import Unit, CompositeUnit, unit, LayoutEngine
from .utils import genome_range

__version__ = "0.1.0"

__all__ = [
    "Unit",
    "CompositeUnit",
    "unit",
    "LayoutEngine",
    "genome_range",
    "__version__",
]
