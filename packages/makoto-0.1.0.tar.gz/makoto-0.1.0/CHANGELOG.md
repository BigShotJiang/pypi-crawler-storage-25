# Changelog

## 0.1.0

Initial OSS developer release.

- Signed mission campaign permits
- Signed work orders
- Proof-carrying tool calls
- Local protected tool decorator
- Local SQLite development ledger
- Protocol verifier
- JSON Schema export
- CLI commands: `demo`, `init`, `sign`, `verify`, `export-schemas`, `doctor`, `version`
- Neutral examples for CI, research, finance, customer support, and deploy-denied safety

