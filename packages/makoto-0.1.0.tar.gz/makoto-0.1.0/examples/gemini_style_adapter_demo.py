from makoto import MakotoClient, protected_tool
from makoto.adapters import MakotoToolAdapter, execute_gemini_function_call


client = MakotoClient()
client.register_attestation(
    agent_id="gemini-style-agent-01",
    code_hash="sha256:gemini-style-demo",
    config_hash="sha256:config-demo",
    policy_version_hash="sha256:policy-demo",
)

campaign = client.launch_campaign(
    tenant_id="demo-org",
    commander_agent_id="maintainer-01",
    objective="Run tests for a pull request",
    allowed_agent_roles=["ci"],
    max_parallel_agents=1,
    max_work_orders=3,
    max_total_risk=20.0,
    approver_id="repo-owner",
    policy_hash="sha256:policy-demo",
)

work_order = client.submit_work_order(
    campaign_id=campaign.campaign_id,
    assigned_agent_id="gemini-style-agent-01",
    assigned_role="ci",
    objective="Run unit tests only",
    allowed_tools=["run_tests"],
    forbidden_tools=["deploy_production"],
    resource_locks=["repo:main:test-runner"],
    risk_budget_allocation=4.0,
)


@protected_tool("run_tests", client)
def run_tests(*, tool_input):
    return {"passed": True, "pull_request": tool_input["pull_request"]}


adapter = MakotoToolAdapter(
    client=client,
    work_order_id=work_order.work_order_id,
    agent_id="gemini-style-agent-01",
    tools={"run_tests": run_tests},
)

gemini_function_call = {
    "functionCall": {
        "name": "run_tests",
        "args": {"pull_request": 42, "suite": "unit"},
    }
}

print(execute_gemini_function_call(gemini_function_call, adapter))

