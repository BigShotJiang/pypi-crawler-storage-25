from makoto import MakotoClient, protected_tool
from makoto.control.errors import AssuranceViolation


client = MakotoClient()
client.register_attestation(
    agent_id="research-agent-01",
    code_hash="sha256:research-agent-demo",
    config_hash="sha256:config-demo",
    policy_version_hash="sha256:policy-demo",
)

campaign = client.launch_campaign(
    tenant_id="demo-org",
    commander_agent_id="research-lead-01",
    objective="Summarize public research notes without external communication",
    allowed_agent_roles=["researcher"],
    max_parallel_agents=1,
    max_work_orders=3,
    max_total_risk=20.0,
    approver_id="research-lead",
    policy_hash="sha256:policy-demo",
)

work_order = client.submit_work_order(
    campaign_id=campaign.campaign_id,
    assigned_agent_id="research-agent-01",
    assigned_role="researcher",
    objective="Read notes and produce a local summary",
    allowed_tools=["read_notes", "write_summary"],
    forbidden_tools=["send_email", "post_to_slack", "delete_files"],
    resource_locks=["workspace:research-notes"],
    risk_budget_allocation=4.0,
)

proof = client.authorize_tool_call(
    work_order_id=work_order.work_order_id,
    agent_id="research-agent-01",
    tool_name="write_summary",
    tool_input={"document": "notes.md", "output": "summary.md"},
)


@protected_tool("write_summary", client)
def write_summary(*, tool_input):
    return {"output": tool_input["output"], "status": "written"}


print(write_summary(tool_input={"document": "notes.md", "output": "summary.md"}, makoto_proof=proof))

try:
    client.authorize_tool_call(
        work_order_id=work_order.work_order_id,
        agent_id="research-agent-01",
        tool_name="send_email",
        tool_input={"to": "external@example.com"},
    )
except AssuranceViolation as exc:
    print({"blocked": "send_email", "reason": str(exc)})

