from makoto import MakotoClient, protected_tool
from makoto.control.errors import AssuranceViolation


def fake_local_agent(prompt: str) -> tuple[str, dict]:
    """A tiny stand-in for any local/cloud LLM tool call."""
    if "deploy" in prompt.lower():
        return "deploy_production", {"environment": "production"}
    return "run_tests", {"pull_request": 42, "suite": "unit"}


client = MakotoClient()
client.register_attestation(
    agent_id="local-agent-01",
    code_hash="sha256:local-agent-demo",
    config_hash="sha256:config-demo",
    policy_version_hash="sha256:policy-demo",
)

campaign = client.launch_campaign(
    tenant_id="demo-org",
    commander_agent_id="maintainer-01",
    objective="Validate pull request safely",
    allowed_agent_roles=["ci"],
    max_parallel_agents=1,
    max_work_orders=3,
    max_total_risk=20.0,
    approver_id="repo-owner",
    policy_hash="sha256:policy-demo",
)

work_order = client.submit_work_order(
    campaign_id=campaign.campaign_id,
    assigned_agent_id="local-agent-01",
    assigned_role="ci",
    objective="Run tests, but do not deploy",
    allowed_tools=["run_tests"],
    forbidden_tools=["deploy_production"],
    resource_locks=["repo:main:test-runner"],
    risk_budget_allocation=4.0,
)


@protected_tool("run_tests", client)
def run_tests(*, tool_input):
    return {"passed": True, "input": tool_input}


TOOLS = {
    "run_tests": run_tests,
}


def execute_agent_request(prompt: str):
    tool_name, tool_input = fake_local_agent(prompt)
    print({"agent_requested": tool_name, "tool_input": tool_input})

    try:
        proof = client.authorize_tool_call(
            work_order_id=work_order.work_order_id,
            agent_id="local-agent-01",
            tool_name=tool_name,
            tool_input=tool_input,
        )
    except AssuranceViolation as exc:
        return {"blocked_before_tool": str(exc)}

    tool = TOOLS.get(tool_name)
    if tool is None:
        return {"blocked": f"Tool is not registered: {tool_name}"}
    return tool(tool_input=tool_input, makoto_proof=proof)


print(execute_agent_request("please run the tests"))
print(execute_agent_request("please deploy production"))

