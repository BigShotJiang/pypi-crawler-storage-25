from makoto import MakotoClient, protected_tool
from makoto.control.errors import AssuranceViolation


client = MakotoClient()
client.register_attestation(
    agent_id="deploy-agent-01",
    code_hash="sha256:deploy-agent-demo",
    config_hash="sha256:config-demo",
    policy_version_hash="sha256:policy-demo",
)

campaign = client.launch_campaign(
    tenant_id="demo-org",
    commander_agent_id="maintainer-01",
    objective="Investigate whether a release is safe",
    allowed_agent_roles=["release-checker"],
    max_parallel_agents=1,
    max_work_orders=2,
    max_total_risk=10.0,
    approver_id="repo-owner",
    policy_hash="sha256:policy-demo",
)

work_order = client.submit_work_order(
    campaign_id=campaign.campaign_id,
    assigned_agent_id="deploy-agent-01",
    assigned_role="release-checker",
    objective="Read release status and run smoke checks",
    allowed_tools=["read_release_status", "run_smoke_checks"],
    forbidden_tools=["deploy_production"],
    resource_locks=["release:2026.05"],
    risk_budget_allocation=3.0,
)


@protected_tool("deploy_production", client)
def deploy_production(*, tool_input):
    return {"deployed": True, "environment": tool_input["environment"]}


try:
    client.authorize_tool_call(
        work_order_id=work_order.work_order_id,
        agent_id="deploy-agent-01",
        tool_name="deploy_production",
        tool_input={"environment": "production"},
    )
except AssuranceViolation as exc:
    print("DENIED:", exc)

try:
    deploy_production(tool_input={"environment": "production"}, makoto_proof=None)
except AssuranceViolation as exc:
    print("BLOCKED BY TOOL:", exc)

