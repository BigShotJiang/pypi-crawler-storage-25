from makoto import MakotoClient, protected_tool


client = MakotoClient()

client.register_attestation(
    agent_id="ci-agent-01",
    code_hash="sha256:ci-agent-demo",
    config_hash="sha256:config-demo",
    policy_version_hash="sha256:policy-demo",
)

campaign = client.launch_campaign(
    tenant_id="demo-org",
    commander_agent_id="maintainer-01",
    objective="Validate a pull request before merge",
    allowed_agent_roles=["ci"],
    max_parallel_agents=1,
    max_work_orders=3,
    max_total_risk=20.0,
    approver_id="repo-owner",
    policy_hash="sha256:policy-demo",
)

work_order = client.submit_work_order(
    campaign_id=campaign.campaign_id,
    assigned_agent_id="ci-agent-01",
    assigned_role="ci",
    objective="Run unit tests for pull request #42",
    allowed_tools=["run_tests"],
    forbidden_tools=["merge_pr", "deploy_production", "rotate_secrets"],
    resource_locks=["repo:main:test-runner"],
    risk_budget_allocation=5.0,
)

proof = client.authorize_tool_call(
    work_order_id=work_order.work_order_id,
    agent_id="ci-agent-01",
    tool_name="run_tests",
    tool_input={"pull_request": 42, "suite": "unit"},
)


@protected_tool("run_tests", client)
def run_tests(*, tool_input):
    return {"pull_request": tool_input["pull_request"], "passed": True}


print(run_tests(tool_input={"pull_request": 42, "suite": "unit"}, makoto_proof=proof))

