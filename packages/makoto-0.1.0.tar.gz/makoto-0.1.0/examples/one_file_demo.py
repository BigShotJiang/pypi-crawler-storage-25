"""MAKOTO in one file.

Run:
    python examples/one_file_demo.py

The point: an agent may ask for a dangerous tool, but the tool itself refuses
unless the call carries a valid MAKOTO proof.
"""

from makoto import MakotoClient, protected_tool
from makoto.control.errors import AssuranceViolation


client = MakotoClient()

client.register_attestation(
    agent_id="demo-agent",
    code_hash="sha256:demo-agent-code",
    config_hash="sha256:demo-agent-config",
    policy_version_hash="sha256:demo-policy",
)

campaign = client.launch_campaign(
    tenant_id="local-demo",
    commander_agent_id="developer",
    objective="Validate PR #42 without deploying production",
    allowed_agent_roles=["ci"],
    max_parallel_agents=1,
    max_work_orders=2,
    max_total_risk=25.0,
    approver_id="developer",
    policy_hash="sha256:demo-policy",
)

work_order = client.submit_work_order(
    campaign_id=campaign.campaign_id,
    assigned_agent_id="demo-agent",
    assigned_role="ci",
    objective="Run tests only",
    allowed_tools=["run_tests"],
    forbidden_tools=["deploy_production"],
    resource_locks=["repo:test-runner"],
    risk_budget_allocation=5.0,
)


@protected_tool("run_tests", client)
def run_tests(*, tool_input):
    return {"passed": True, "suite": tool_input["suite"]}


@protected_tool("deploy_production", client)
def deploy_production(*, tool_input):
    return {"deployed": True, "environment": tool_input["environment"]}


print("Agent asks: run_tests")
test_input = {"suite": "unit"}
test_proof = client.authorize_tool_call(
    work_order_id=work_order.work_order_id,
    agent_id="demo-agent",
    tool_name="run_tests",
    tool_input=test_input,
)
print("Tool says:", run_tests(tool_input=test_input, makoto_proof=test_proof))

print("\nAgent asks: deploy_production")
deploy_input = {"environment": "production"}
try:
    deploy_proof = client.authorize_tool_call(
        work_order_id=work_order.work_order_id,
        agent_id="demo-agent",
        tool_name="deploy_production",
        tool_input=deploy_input,
    )
    print(deploy_production(tool_input=deploy_input, makoto_proof=deploy_proof))
except AssuranceViolation as exc:
    print("Tool says: DENIED")
    print("Reason:", exc)

print("\nMAKOTO rule: no signed mission, no tool.")
