# MAKOTO Examples

These examples are intentionally neutral. They show the same control primitive
without exposing regulated or critical-infrastructure scenarios.

## One-File Demo

Copy-paste version of the core idea: `run_tests` is allowed, but
`deploy_production` is denied by the MAKOTO-protected tool boundary.

```bash
python3 examples/one_file_demo.py
```

## Deploy Denied

```bash
python3 examples/deploy_denied_demo.py
```

## Local Agent Loop

Shows where MAKOTO sits when a local/cloud model asks to call a tool.

```bash
python3 examples/local_agent_loop.py
```

## OpenAI-Style Tool Call

Parses an OpenAI-style function tool call and executes it through MAKOTO.

```bash
python3 examples/openai_style_adapter_demo.py
```

## Claude-Style Tool Use

Parses a Claude-style `tool_use` block and executes it through MAKOTO.

```bash
python3 examples/claude_style_adapter_demo.py
```

## Gemini-Style Function Call

Parses a Gemini-style `functionCall` object and executes it through MAKOTO.

```bash
python3 examples/gemini_style_adapter_demo.py
```

## Framework Adapters

Demonstrates dependency-free LangGraph-style, CrewAI-style, and AutoGen-style
adapter boundaries.

```bash
python3 examples/framework_adapter_demo.py
```

Shows the viral core:

```text
DENIED: Tool is explicitly forbidden: deploy_production
BLOCKED BY TOOL: Tool deploy_production requires a MAKOTO proof
```

## CI Safety

Agent may run tests. It may not merge, deploy, or rotate secrets.

```bash
python3 examples/ci_safety_demo.py
```

## Research Safety

Agent may write a local summary. It may not send email.

```bash
python3 examples/research_safety_demo.py
```

## Finance Safety

Agent may draft an approval note. It may not send payment.

```bash
python3 examples/finance_safety_demo.py
```

## Customer Support Safety

Agent may draft a reply. It may not issue refunds.

```bash
python3 examples/customer_support_safety_demo.py
```
