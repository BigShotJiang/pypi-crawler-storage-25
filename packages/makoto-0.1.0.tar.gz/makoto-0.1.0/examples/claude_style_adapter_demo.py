from makoto import MakotoClient, protected_tool
from makoto.adapters import MakotoToolAdapter, execute_claude_tool_use


client = MakotoClient()
client.register_attestation(
    agent_id="claude-style-agent-01",
    code_hash="sha256:claude-style-demo",
    config_hash="sha256:config-demo",
    policy_version_hash="sha256:policy-demo",
)

campaign = client.launch_campaign(
    tenant_id="demo-org",
    commander_agent_id="research-lead-01",
    objective="Write a local research summary",
    allowed_agent_roles=["researcher"],
    max_parallel_agents=1,
    max_work_orders=3,
    max_total_risk=20.0,
    approver_id="research-lead",
    policy_hash="sha256:policy-demo",
)

work_order = client.submit_work_order(
    campaign_id=campaign.campaign_id,
    assigned_agent_id="claude-style-agent-01",
    assigned_role="researcher",
    objective="Write summary only",
    allowed_tools=["write_summary"],
    forbidden_tools=["send_email"],
    resource_locks=["workspace:research-notes"],
    risk_budget_allocation=4.0,
)


@protected_tool("write_summary", client)
def write_summary(*, tool_input):
    return {"written": tool_input["output"]}


adapter = MakotoToolAdapter(
    client=client,
    work_order_id=work_order.work_order_id,
    agent_id="claude-style-agent-01",
    tools={"write_summary": write_summary},
)

claude_tool_use = {
    "type": "tool_use",
    "id": "toolu_123",
    "name": "write_summary",
    "input": {"document": "notes.md", "output": "summary.md"},
}

print(execute_claude_tool_use(claude_tool_use, adapter))

