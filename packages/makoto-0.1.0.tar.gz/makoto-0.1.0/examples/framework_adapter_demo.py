from makoto import MakotoClient, protected_tool
from makoto.adapters import MakotoToolAdapter
from makoto.adapters.autogen import execute_autogen_tool_call
from makoto.adapters.crewai import make_crewai_tool
from makoto.adapters.langgraph import make_langgraph_tool_node


client = MakotoClient()
client.register_attestation(
    agent_id="framework-agent-01",
    code_hash="sha256:framework-demo",
    config_hash="sha256:config-demo",
    policy_version_hash="sha256:policy-demo",
)

campaign = client.launch_campaign(
    tenant_id="demo-org",
    commander_agent_id="maintainer-01",
    objective="Run framework adapter demo",
    allowed_agent_roles=["ci"],
    max_parallel_agents=1,
    max_work_orders=3,
    max_total_risk=20.0,
    approver_id="repo-owner",
    policy_hash="sha256:policy-demo",
)

work_order = client.submit_work_order(
    campaign_id=campaign.campaign_id,
    assigned_agent_id="framework-agent-01",
    assigned_role="ci",
    objective="Run tests only",
    allowed_tools=["run_tests"],
    forbidden_tools=["deploy_production"],
    resource_locks=[],
    risk_budget_allocation=4.0,
)


@protected_tool("run_tests", client)
def run_tests(*, tool_input):
    return {"passed": True, "source": tool_input.get("source", "unknown")}


adapter = MakotoToolAdapter(
    client=client,
    work_order_id=work_order.work_order_id,
    agent_id="framework-agent-01",
    tools={"run_tests": run_tests},
)

langgraph_node = make_langgraph_tool_node(adapter)
print(langgraph_node({"tool_call": {"id": "lg_1", "name": "run_tests", "arguments": {"source": "langgraph"}}}))

crewai_tool = make_crewai_tool(adapter, "run_tests")
print(crewai_tool(source="crewai"))

print(
    execute_autogen_tool_call(
        {"id": "ag_1", "name": "run_tests", "arguments": {"source": "autogen"}},
        adapter,
    )
)

