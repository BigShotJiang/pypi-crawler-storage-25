from makoto import MakotoClient, protected_tool
from makoto.control.errors import AssuranceViolation


client = MakotoClient()
client.register_attestation(
    agent_id="finance-agent-01",
    code_hash="sha256:finance-agent-demo",
    config_hash="sha256:config-demo",
    policy_version_hash="sha256:policy-demo",
)

campaign = client.launch_campaign(
    tenant_id="demo-org",
    commander_agent_id="finance-lead-01",
    objective="Review invoices without moving money",
    allowed_agent_roles=["finance-reviewer"],
    max_parallel_agents=1,
    max_work_orders=5,
    max_total_risk=30.0,
    approver_id="finance-controller",
    policy_hash="sha256:policy-demo",
)

work_order = client.submit_work_order(
    campaign_id=campaign.campaign_id,
    assigned_agent_id="finance-agent-01",
    assigned_role="finance-reviewer",
    objective="Analyze invoice #INV-42 and draft approval notes",
    allowed_tools=["read_invoice", "draft_approval_note"],
    forbidden_tools=["send_payment", "change_bank_account", "approve_invoice"],
    resource_locks=["invoice:INV-42"],
    risk_budget_allocation=6.0,
)

proof = client.authorize_tool_call(
    work_order_id=work_order.work_order_id,
    agent_id="finance-agent-01",
    tool_name="draft_approval_note",
    tool_input={"invoice_id": "INV-42"},
)


@protected_tool("draft_approval_note", client)
def draft_approval_note(*, tool_input):
    return {"invoice_id": tool_input["invoice_id"], "drafted": True}


print(draft_approval_note(tool_input={"invoice_id": "INV-42"}, makoto_proof=proof))

try:
    client.authorize_tool_call(
        work_order_id=work_order.work_order_id,
        agent_id="finance-agent-01",
        tool_name="send_payment",
        tool_input={"invoice_id": "INV-42", "amount": 1200},
    )
except AssuranceViolation as exc:
    print({"blocked": "send_payment", "reason": str(exc)})

