from makoto import MakotoClient, protected_tool
from makoto.control.errors import AssuranceViolation


client = MakotoClient()
client.register_attestation(
    agent_id="support-agent-01",
    code_hash="sha256:support-agent-demo",
    config_hash="sha256:config-demo",
    policy_version_hash="sha256:policy-demo",
)

campaign = client.launch_campaign(
    tenant_id="demo-org",
    commander_agent_id="support-lead-01",
    objective="Draft a support response without sending it",
    allowed_agent_roles=["support"],
    max_parallel_agents=1,
    max_work_orders=4,
    max_total_risk=20.0,
    approver_id="support-lead",
    policy_hash="sha256:policy-demo",
)

work_order = client.submit_work_order(
    campaign_id=campaign.campaign_id,
    assigned_agent_id="support-agent-01",
    assigned_role="support",
    objective="Read ticket #123 and draft a reply",
    allowed_tools=["read_ticket", "draft_reply"],
    forbidden_tools=["send_reply", "issue_refund", "close_account"],
    resource_locks=["ticket:123"],
    risk_budget_allocation=3.0,
)

proof = client.authorize_tool_call(
    work_order_id=work_order.work_order_id,
    agent_id="support-agent-01",
    tool_name="draft_reply",
    tool_input={"ticket_id": "123"},
)


@protected_tool("draft_reply", client)
def draft_reply(*, tool_input):
    return {"ticket_id": tool_input["ticket_id"], "drafted": True}


print(draft_reply(tool_input={"ticket_id": "123"}, makoto_proof=proof))

try:
    client.authorize_tool_call(
        work_order_id=work_order.work_order_id,
        agent_id="support-agent-01",
        tool_name="issue_refund",
        tool_input={"ticket_id": "123", "amount": 50},
    )
except AssuranceViolation as exc:
    print({"blocked": "issue_refund", "reason": str(exc)})

