from __future__ import annotations

import json
from dataclasses import fields, replace
from pathlib import Path
from typing import Any

from makoto.ledger.sqlite_ledger import _from_dict
from makoto.protocol.canonical_json import to_plain
from makoto.protocol.schemas import (
    AgentAttestation,
    MissionCampaignPermit,
    OutcomeRecord,
    ProofCarryingToolCall,
    SignedWorkOrder,
)
from makoto.protocol.signing import HmacSha256Signer, SignatureEnvelope


KIND_TO_SCHEMA = {
    "attestation": AgentAttestation,
    "campaign": MissionCampaignPermit,
    "work-order": SignedWorkOrder,
    "tool-call": ProofCarryingToolCall,
    "outcome": OutcomeRecord,
}


def load_json(path: str | Path) -> dict[str, Any]:
    with open(path, "r", encoding="utf-8") as handle:
        payload = json.load(handle)
    if not isinstance(payload, dict):
        raise ValueError("Expected a JSON object")
    return payload


def validate_shape(kind: str, payload: dict[str, Any]) -> list[str]:
    cls = KIND_TO_SCHEMA[kind]
    required = [field.name for field in fields(cls) if field.name != "signature"]
    return [name for name in required if name not in payload]


def verify_object(
    kind: str,
    payload: dict[str, Any],
    hmac_secret: str | None = None,
    key_id: str = "dev-local-key",
) -> dict[str, Any]:
    if kind not in KIND_TO_SCHEMA:
        raise ValueError(f"Unknown MAKOTO object kind: {kind}")

    missing = validate_shape(kind, payload)
    result: dict[str, Any] = {
        "kind": kind,
        "shape_valid": not missing,
        "missing_fields": missing,
        "signature_present": payload.get("signature") is not None,
        "signature_verified": False,
    }
    if missing:
        return result

    obj = _from_dict(KIND_TO_SCHEMA[kind], payload)
    if obj.signature is None or hmac_secret is None:
        return result

    signer = HmacSha256Signer(secret=hmac_secret.encode("utf-8"), key_id=key_id)
    result["signature_verified"] = signer.verify(obj.signing_payload(), obj.signature)
    return result


def sign_object(
    kind: str,
    payload: dict[str, Any],
    hmac_secret: str,
    key_id: str = "dev-local-key",
) -> dict[str, Any]:
    if kind not in KIND_TO_SCHEMA:
        raise ValueError(f"Unknown MAKOTO object kind: {kind}")
    missing = validate_shape(kind, payload)
    if missing:
        raise ValueError(f"Missing required fields: {', '.join(missing)}")

    obj = _from_dict(KIND_TO_SCHEMA[kind], payload)
    unsigned = replace(obj, signature=None)
    signer = HmacSha256Signer(secret=hmac_secret.encode("utf-8"), key_id=key_id)
    signed = replace(unsigned, signature=signer.sign(unsigned.signing_payload()))
    return to_plain(signed)
