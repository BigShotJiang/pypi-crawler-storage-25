from __future__ import annotations

import dataclasses
import json
import types
from pathlib import Path
from typing import Any, Union, get_args, get_origin, get_type_hints

from makoto.protocol.schemas import (
    AgentAttestation,
    MissionCampaignPermit,
    OutcomeRecord,
    ProofCarryingToolCall,
    SignedWorkOrder,
    WitnessReport,
)
from makoto.protocol.signing import SignatureEnvelope


SCHEMA_TYPES = {
    "attestation": AgentAttestation,
    "campaign": MissionCampaignPermit,
    "work-order": SignedWorkOrder,
    "tool-call": ProofCarryingToolCall,
    "outcome": OutcomeRecord,
    "witness-report": WitnessReport,
}


def _type_schema(annotation: Any) -> dict[str, Any]:
    origin = get_origin(annotation)
    args = get_args(annotation)

    if origin in (Union, types.UnionType):
        non_none = [arg for arg in args if arg is not type(None)]
        if len(non_none) == 1:
            return {"anyOf": [_type_schema(non_none[0]), {"type": "null"}]}

    if origin is list:
        return {"type": "array", "items": _type_schema(args[0] if args else Any)}

    if origin is dict:
        return {"type": "object", "additionalProperties": True}

    if annotation is str:
        return {"type": "string"}
    if annotation is int:
        return {"type": "integer"}
    if annotation is float:
        return {"type": "number"}
    if annotation is bool:
        return {"type": "boolean"}
    if annotation is Any:
        return {}
    if annotation is SignatureEnvelope:
        return {
            "type": "object",
            "properties": {
                "alg": {"type": "string"},
                "key_id": {"type": "string"},
                "value": {"type": "string"},
                "created_at": {"type": "string"},
            },
            "required": ["alg", "key_id", "value", "created_at"],
            "additionalProperties": False,
        }
    return {"type": "object"}


def schema_for(cls: type) -> dict[str, Any]:
    properties = {}
    required = []
    hints = get_type_hints(cls)
    for field in dataclasses.fields(cls):
        properties[field.name] = _type_schema(hints[field.name])
        if field.name != "signature":
            required.append(field.name)
    return {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "$id": f"https://makoto.dev/schemas/{cls.__name__}.json",
        "title": cls.__name__,
        "type": "object",
        "properties": properties,
        "required": required,
        "additionalProperties": False,
    }


def export_schemas(output_dir: str | Path) -> list[Path]:
    path = Path(output_dir)
    path.mkdir(parents=True, exist_ok=True)
    written = []
    for name, cls in SCHEMA_TYPES.items():
        target = path / f"{name}.schema.json"
        target.write_text(json.dumps(schema_for(cls), indent=2, sort_keys=True), encoding="utf-8")
        written.append(target)
    return written
