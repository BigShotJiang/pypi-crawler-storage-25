from __future__ import annotations

import base64
import hmac
import secrets
from dataclasses import dataclass
from datetime import datetime, timezone
from hashlib import sha256
from typing import Protocol


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass(frozen=True)
class SignatureEnvelope:
    alg: str
    key_id: str
    value: str
    created_at: str


class Signer(Protocol):
    alg: str
    key_id: str

    def sign(self, payload: str) -> SignatureEnvelope: ...

    def verify(self, payload: str, signature: SignatureEnvelope) -> bool: ...


class HmacSha256Signer:
    """Dependency-free development signer.

    Production deployments should replace this with Ed25519 backed by KMS/HSM.
    """

    alg = "HMAC-SHA256"

    def __init__(self, secret: bytes | None = None, key_id: str = "dev-local-key"):
        self.secret = secret or secrets.token_bytes(32)
        self.key_id = key_id

    def sign(self, payload: str) -> SignatureEnvelope:
        digest = hmac.new(self.secret, payload.encode("utf-8"), sha256).digest()
        return SignatureEnvelope(
            alg=self.alg,
            key_id=self.key_id,
            value=base64.b64encode(digest).decode("ascii"),
            created_at=utc_now(),
        )

    def verify(self, payload: str, signature: SignatureEnvelope) -> bool:
        if signature.alg != self.alg or signature.key_id != self.key_id:
            return False
        expected = self.sign(payload).value
        return hmac.compare_digest(expected, signature.value)


class Ed25519Signer:
    """Optional Ed25519 signer using `cryptography` when available."""

    alg = "Ed25519"

    def __init__(self, private_key=None, public_key=None, key_id: str = "ed25519-local"):
        try:
            from cryptography.hazmat.primitives.asymmetric import ed25519
            from cryptography.hazmat.primitives import serialization
        except ImportError as exc:
            raise RuntimeError("Install cryptography to use Ed25519Signer") from exc

        self._serialization = serialization
        self.key_id = key_id
        if private_key is None:
            private_key = ed25519.Ed25519PrivateKey.generate()
        self.private_key = private_key
        self.public_key = public_key or private_key.public_key()

    def sign(self, payload: str) -> SignatureEnvelope:
        raw = self.private_key.sign(payload.encode("utf-8"))
        return SignatureEnvelope(
            alg=self.alg,
            key_id=self.key_id,
            value=base64.b64encode(raw).decode("ascii"),
            created_at=utc_now(),
        )

    def verify(self, payload: str, signature: SignatureEnvelope) -> bool:
        if signature.alg != self.alg or signature.key_id != self.key_id:
            return False
        try:
            raw = base64.b64decode(signature.value.encode("ascii"))
            self.public_key.verify(raw, payload.encode("utf-8"))
            return True
        except Exception:
            return False

