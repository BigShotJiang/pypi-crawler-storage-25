"""Open protocol data structures for MAKOTO."""

