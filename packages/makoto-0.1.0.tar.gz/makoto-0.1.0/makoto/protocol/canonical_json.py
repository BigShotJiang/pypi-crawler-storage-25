from __future__ import annotations

import dataclasses
import hashlib
import json
from typing import Any


def to_plain(value: Any) -> Any:
    if dataclasses.is_dataclass(value):
        return {k: to_plain(v) for k, v in dataclasses.asdict(value).items()}
    if isinstance(value, dict):
        return {str(k): to_plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [to_plain(v) for v in value]
    return value


def canonical_json(value: Any) -> str:
    return json.dumps(
        to_plain(value),
        sort_keys=True,
        ensure_ascii=True,
        separators=(",", ":"),
    )


def sha256_hex(value: Any) -> str:
    payload = value if isinstance(value, str) else canonical_json(value)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()

