from __future__ import annotations

from dataclasses import dataclass, field, replace
from typing import Any, Optional

from makoto.protocol.canonical_json import canonical_json, sha256_hex
from makoto.protocol.signing import SignatureEnvelope


PROTOCOL_VERSION = "makoto.protocol.v0.1"


def _unsigned(obj):
    return replace(obj, signature=None)


@dataclass(frozen=True)
class AgentAttestation:
    protocol_version: str
    attestation_id: str
    agent_id: str
    code_hash: str
    config_hash: str
    policy_version_hash: str
    environment: str
    deployment_id: str
    secrets_sealed: bool
    timestamp: str
    signature: Optional[SignatureEnvelope] = None

    def signing_payload(self) -> str:
        return canonical_json(_unsigned(self))

    @property
    def attestation_hash(self) -> str:
        return sha256_hex(self.signing_payload())


@dataclass(frozen=True)
class MissionCampaignPermit:
    protocol_version: str
    campaign_id: str
    tenant_id: str
    commander_agent_id: str
    objective: str
    allowed_agent_roles: list[str]
    max_parallel_agents: int
    max_work_orders: int
    global_risk_budget_id: str
    max_total_risk: float
    escalation_rules: dict[str, Any]
    human_approved: bool
    approver_id: str
    policy_hash: str
    created_at: str
    expires_at: str
    signature: Optional[SignatureEnvelope] = None

    def signing_payload(self) -> str:
        return canonical_json(_unsigned(self))

    @property
    def permit_hash(self) -> str:
        return sha256_hex(self.signing_payload())


@dataclass(frozen=True)
class SignedWorkOrder:
    protocol_version: str
    work_order_id: str
    parent_campaign_id: str
    assigned_agent_id: str
    assigned_role: str
    objective: str
    allowed_tools: list[str]
    forbidden_tools: list[str]
    resource_locks: list[str]
    depends_on: list[str]
    risk_budget_allocation: float
    created_at: str
    expiry: str
    signature: Optional[SignatureEnvelope] = None

    def signing_payload(self) -> str:
        return canonical_json(_unsigned(self))

    @property
    def work_order_hash(self) -> str:
        return sha256_hex(self.signing_payload())


@dataclass(frozen=True)
class ProofCarryingToolCall:
    protocol_version: str
    proof_id: str
    tool_name: str
    tool_input_hash: str
    mission_campaign_id: str
    work_order_id: str
    agent_id: str
    policy_approved: bool
    human_approved: Optional[bool]
    runtime_attested: bool
    risk_budget_remaining: float
    created_at: str
    signature: Optional[SignatureEnvelope] = None

    def signing_payload(self) -> str:
        return canonical_json(_unsigned(self))

    @property
    def proof_hash(self) -> str:
        return sha256_hex(self.signing_payload())


@dataclass(frozen=True)
class OutcomeRecord:
    protocol_version: str
    outcome_id: str
    campaign_id: str
    work_order_id: str
    proof_id: str
    expected_outcome: str
    actual_outcome: str
    outcome_match: float
    human_rating: Optional[str]
    human_override: bool
    incident_after_action: bool
    value_estimate: float
    created_at: str
    signature: Optional[SignatureEnvelope] = None

    def signing_payload(self) -> str:
        return canonical_json(_unsigned(self))


@dataclass(frozen=True)
class WitnessReport:
    protocol_version: str
    report_id: str
    campaign_id: str
    work_order_id: str
    observer_agent_id: str
    verdict: str
    violations: list[str]
    created_at: str
    signature: Optional[SignatureEnvelope] = None

    def signing_payload(self) -> str:
        return canonical_json(_unsigned(self))


@dataclass(frozen=True)
class AuditEvent:
    protocol_version: str
    event_id: str
    event_type: str
    subject_id: str
    payload_hash: str
    payload: dict[str, Any]
    created_at: str
    signature: Optional[SignatureEnvelope] = None

    def signing_payload(self) -> str:
        return canonical_json(_unsigned(self))


@dataclass(frozen=True)
class SwarmSnapshot:
    campaign_id: str
    at_time: str
    campaign: Optional[MissionCampaignPermit]
    work_orders: list[SignedWorkOrder] = field(default_factory=list)
    tool_calls: list[ProofCarryingToolCall] = field(default_factory=list)
    outcomes: list[OutcomeRecord] = field(default_factory=list)
    events: list[AuditEvent] = field(default_factory=list)
