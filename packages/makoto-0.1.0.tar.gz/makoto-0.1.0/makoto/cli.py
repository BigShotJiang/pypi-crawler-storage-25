from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

from makoto import PROTOCOL_VERSION, __version__
from makoto.control.errors import AssuranceViolation
from makoto.protocol.json_schema import export_schemas
from makoto.protocol.canonical_json import to_plain
from makoto.protocol.signing import HmacSha256Signer
from makoto.protocol.verifier import KIND_TO_SCHEMA, load_json, sign_object, verify_object
from makoto.sdk.client import MakotoClient
from makoto.sdk.catalog import DANGEROUS_TOOLS, describe_tool_risk, get_risk, is_dangerous
from makoto.ux.mascot import mascot_line


LOCAL_LEDGER = ".makoto/ledger.db"
LOCAL_SECRET = ".makoto/hmac.key"


def run_demo(short: bool = False) -> dict:
    client = MakotoClient()
    client.register_attestation(
        agent_id="ci-agent-01",
        code_hash="sha256:ci-agent-demo",
        config_hash="sha256:config-demo",
        policy_version_hash="sha256:policy-demo",
    )
    campaign = client.launch_campaign(
        tenant_id="demo-org",
        commander_agent_id="maintainer-01",
        objective="Validate a pull request before merge",
        allowed_agent_roles=["ci", "reviewer"],
        max_parallel_agents=3,
        max_work_orders=10,
        max_total_risk=50.0,
        approver_id="repo-owner",
        policy_hash="sha256:policy-demo",
    )
    work_order = client.submit_work_order(
        campaign_id=campaign.campaign_id,
        assigned_agent_id="ci-agent-01",
        assigned_role="ci",
        objective="Read CI logs and run tests for pull request #42",
        allowed_tools=["read_ci_logs", "run_tests"],
        forbidden_tools=["merge_pr", "deploy_production", "rotate_secrets"],
        resource_locks=["repo:main:test-runner"],
        risk_budget_allocation=8.0,
    )
    proof = client.authorize_tool_call(
        work_order_id=work_order.work_order_id,
        agent_id="ci-agent-01",
        tool_name="run_tests",
        tool_input={"pull_request": 42, "suite": "unit"},
    )
    verified = client.verify_tool_call(proof, {"pull_request": 42, "suite": "unit"})
    outcome = client.record_outcome(
        proof_id=proof.proof_id,
        expected_outcome="unit tests completed",
        actual_outcome="unit tests completed; 128 passed, 0 failed",
        outcome_match=1.0,
        human_rating="correct",
        value_estimate=250.0,
    )
    witness = client.witness_work_order(
        work_order.work_order_id,
        observer_agent_id="witness-ci-01",
        attempted_tools=["run_tests"],
    )
    result = {
        "campaign_id": campaign.campaign_id,
        "work_order_id": work_order.work_order_id,
        "proof_id": proof.proof_id,
        "proof_verified": verified,
        "outcome_id": outcome.outcome_id,
        "witness_verdict": witness.verdict,
        "snapshot": client.export_campaign_json(campaign.campaign_id),
    }
    if short:
        return {
            "campaign_id": result["campaign_id"],
            "work_order_id": result["work_order_id"],
            "proof_id": result["proof_id"],
            "proof_verified": result["proof_verified"],
            "blocked_tools": ["merge_pr", "deploy_production", "rotate_secrets"],
            "message": "CI agent ran tests under a signed work order.",
        }
    return result


QUICKSTART_APP = '''from makoto import MakotoClient, protected_tool

client = MakotoClient()

client.register_attestation(
    agent_id="ci-agent-01",
    code_hash="sha256:demo-code",
    config_hash="sha256:demo-config",
    policy_version_hash="sha256:demo-policy",
)

campaign = client.launch_campaign(
    tenant_id="demo-org",
    commander_agent_id="maintainer-01",
    objective="Validate a pull request before merge",
    allowed_agent_roles=["ci"],
    max_parallel_agents=1,
    max_work_orders=3,
    max_total_risk=20.0,
    approver_id="repo-owner",
    policy_hash="sha256:demo-policy",
)

work_order = client.submit_work_order(
    campaign_id=campaign.campaign_id,
    assigned_agent_id="ci-agent-01",
    assigned_role="ci",
    objective="Run tests for pull request #42",
    allowed_tools=["run_tests"],
    forbidden_tools=["merge_pr", "deploy_production", "rotate_secrets"],
    resource_locks=["repo:main:test-runner"],
    risk_budget_allocation=5.0,
)

proof = client.authorize_tool_call(
    work_order_id=work_order.work_order_id,
    agent_id="ci-agent-01",
    tool_name="run_tests",
    tool_input={"pull_request": 42, "suite": "unit"},
)


@protected_tool("run_tests", client)
def run_tests(*, tool_input):
    return {"passed": True, "tool_input": tool_input}


print(run_tests(tool_input={"pull_request": 42, "suite": "unit"}, makoto_proof=proof))
'''


QUICKSTART_README = """# MAKOTO Quickstart

This example shows the core MAKOTO rule:

> A tool runs only with a valid proof-carrying tool call.

Run:

```bash
python app.py
```
"""


def _local_secret(path: str | Path = LOCAL_SECRET) -> bytes:
    key_path = Path(path)
    key_path.parent.mkdir(parents=True, exist_ok=True)
    if not key_path.exists():
        key_path.write_text(os.urandom(32).hex() + "\n", encoding="utf-8")
    return bytes.fromhex(key_path.read_text(encoding="utf-8").strip())


def local_client(ledger_path: str | Path = LOCAL_LEDGER) -> MakotoClient:
    Path(ledger_path).parent.mkdir(parents=True, exist_ok=True)
    secret_path = Path(ledger_path).parent / "hmac.key"
    return MakotoClient(
        ledger_path=str(ledger_path),
        signer=HmacSha256Signer(secret=_local_secret(secret_path), key_id="dev-local-key"),
    )


def init_project(path: str, force: bool = False) -> list[str]:
    root = Path(path)
    root.mkdir(parents=True, exist_ok=True)
    files = {
        "app.py": QUICKSTART_APP,
        "README.md": QUICKSTART_README,
    }
    written = []
    for name, content in files.items():
        target = root / name
        if target.exists() and not force:
            raise FileExistsError(f"{target} already exists; use --force to overwrite")
        target.write_text(content, encoding="utf-8")
        written.append(str(target))
    return written


def write_denial_file(payload: dict) -> str:
    target = Path(tempfile.gettempdir()) / f"makoto_denied_{payload['tool_name']}.json"
    target.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return str(target)


def denial_payload(
    tool_name: str,
    reason: str,
    work_order_id: str | None = None,
    allowed_tools: list[str] | None = None,
    risk_remaining: float | None = None,
) -> dict:
    return {
        "decision": "denied",
        "tool_name": tool_name,
        "reason": reason,
        "work_order_id": work_order_id,
        "allowed_tools": allowed_tools or [],
        "risk_score": get_risk(tool_name),
        "risk_level": describe_tool_risk(tool_name),
        "risk_remaining": risk_remaining,
    }


def explain_denial(path: str | Path) -> str:
    data = load_json(str(path))
    lines = [
        mascot_line("explain"),
        f"DENIED: {data.get('tool_name', 'unknown')}",
        f"Reason: {data.get('reason', 'No reason recorded')}",
        f"Risk: {data.get('risk_score', 'unknown')} ({data.get('risk_level', 'unknown')})",
    ]
    allowed = data.get("allowed_tools") or []
    if allowed:
        lines.append(f"Allowed tools: {', '.join(allowed)}")
    if data.get("work_order_id"):
        lines.append(f"Work order: {data['work_order_id']}")
    if data.get("risk_remaining") is not None:
        lines.append(f"Risk remaining: {data['risk_remaining']}")
    return "\n".join(lines)


def create_dev_work_order(client: MakotoClient, tool_name: str, agent_id: str, risk_budget: float):
    client.register_attestation(
        agent_id=agent_id,
        code_hash="sha256:makoto-cli-dev-agent",
        config_hash="sha256:makoto-cli-dev-config",
        policy_version_hash="sha256:makoto-cli-dev-policy",
    )
    campaign = client.launch_campaign(
        tenant_id="local-dev",
        commander_agent_id="local-user",
        objective=f"Run local command through MAKOTO wrap for {tool_name}",
        allowed_agent_roles=["local"],
        max_parallel_agents=1,
        max_work_orders=1,
        max_total_risk=max(risk_budget, float(get_risk(tool_name))),
        approver_id="local-user",
        policy_hash="sha256:makoto-cli-dev-policy",
        ttl_seconds=3_600,
    )
    return client.submit_work_order(
        campaign_id=campaign.campaign_id,
        assigned_agent_id=agent_id,
        assigned_role="local",
        objective=f"Execute {tool_name} locally",
        allowed_tools=[tool_name],
        forbidden_tools=[],
        resource_locks=[],
        risk_budget_allocation=min(risk_budget, campaign.max_total_risk),
        ttl_seconds=3_600,
    )


def wrap_command(
    tool_name: str,
    command: list[str],
    work_order_id: str | None = None,
    agent_id: str = "local-agent",
    ledger_path: str | Path = LOCAL_LEDGER,
    allow_dev: bool = False,
    risk_budget: float = 10.0,
    mode: str = "gate",
) -> int:
    if command and command[0] == "--":
        command = command[1:]
    if not command:
        raise ValueError("No command was provided after --")

    client = local_client(ledger_path)
    if allow_dev and work_order_id is None:
        work_order = create_dev_work_order(client, tool_name, agent_id, risk_budget)
        work_order_id = work_order.work_order_id

    if not work_order_id:
        payload = denial_payload(tool_name, "No valid work order was provided")
        path = write_denial_file(payload)
        print(mascot_line("denied"), flush=True)
        print(f"DENIED: {tool_name} - no valid work order", flush=True)
        print(f"Explanation file: {path}", flush=True)
        return 1

    try:
        proof = client.authorize_tool_call(
            work_order_id=work_order_id,
            agent_id=agent_id,
            tool_name=tool_name,
            tool_input={"command": command},
        )
    except AssuranceViolation as exc:
        work_order = client.ledger.get("work_orders", work_order_id)
        payload = denial_payload(
            tool_name,
            str(exc),
            work_order_id=work_order_id,
            allowed_tools=list(work_order.allowed_tools) if work_order else [],
        )
        path = write_denial_file(payload)
        print(mascot_line("denied"), flush=True)
        print(f"DENIED: {tool_name} - {exc}", flush=True)
        print(f"Explanation file: {path}", flush=True)
        return 1

    print(mascot_line("allowed"), flush=True)
    print(f"ALLOWED: {tool_name} - proof {proof.proof_id}", flush=True)
    env = os.environ.copy()
    if mode == "env":
        env["MAKOTO_PROOF"] = json.dumps(to_plain(proof), sort_keys=True)
        env["MAKOTO_PROOF_ID"] = proof.proof_id
    return subprocess.run(command, env=env, check=False).returncode


def score_project(path: str | Path = ".", ledger_path: str | Path = LOCAL_LEDGER) -> dict:
    root = Path(path)
    py_files = [
        item
        for item in root.rglob("*.py")
        if ".venv" not in item.parts and "__pycache__" not in item.parts
    ]
    contents = "\n".join(item.read_text(encoding="utf-8", errors="ignore") for item in py_files)
    discovered = sorted(tool for tool in DANGEROUS_TOOLS if tool in contents)
    protected = sorted(
        tool
        for tool in discovered
        if f'protected_tool("{tool}"' in contents or f"protected_tool('{tool}'" in contents
    )
    client = local_client(ledger_path)
    campaigns = client.ledger.list("campaigns")
    work_orders = client.ledger.list("work_orders")
    tool_calls = client.ledger.list("tool_calls")
    outcomes = client.ledger.list("outcomes")
    categories = {
        "dangerous_tool_awareness": 100 if discovered else 75,
        "protected_tool_usage": 100 if protected else (65 if "protected_tool" in contents else 25),
        "campaign_coverage": 100 if campaigns else 35,
        "work_order_coverage": 100 if work_orders else 35,
        "proof_coverage": 100 if tool_calls else 25,
        "outcome_feedback": 100 if outcomes else 40,
    }
    total = round(sum(categories.values()) / len(categories))
    if total >= 97:
        grade = "A+"
    elif total >= 90:
        grade = "A"
    elif total >= 82:
        grade = "B+"
    elif total >= 74:
        grade = "B"
    elif total >= 65:
        grade = "C"
    elif total >= 50:
        grade = "D"
    else:
        grade = "F"
    hints = []
    if not campaigns:
        hints.append("Launch at least one campaign with MakotoClient.launch_campaign().")
    if not work_orders:
        hints.append("Create signed work orders for every agent task.")
    if not tool_calls:
        hints.append("Authorize tool calls and pass the proof into @protected_tool.")
    if not outcomes:
        hints.append("Record outcomes so future reviews can see what happened.")
    if discovered and not protected:
        hints.append("Wrap dangerous tools with @protected_tool or MAKOTO adapters.")
    return {
        "grade": grade,
        "score": total,
        "categories": categories,
        "dangerous_tools_detected": discovered,
        "protected_tools_detected": protected,
        "hints": hints,
    }


def check_project(path: str | Path = ".") -> dict:
    root = Path(path)
    checks = {
        "readme": (root / "README.md").exists(),
        "pyproject": (root / "pyproject.toml").exists(),
        "examples": (root / "examples").exists(),
        "makoto_importable": True,
        "schemas": (root / "schemas").exists(),
    }
    return {"ok": all(checks.values()), "checks": checks}


def main() -> None:
    parser = argparse.ArgumentParser(prog="makoto")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("version", help="Print MAKOTO version information")
    sub.add_parser("doctor", help="Check local MAKOTO environment")
    demo = sub.add_parser("demo", help="Run a generic pull-request safety demo")
    demo.add_argument("--short", action="store_true", help="Print a compact demo result")
    explain = sub.add_parser("explain", help="Explain a MAKOTO denial JSON file")
    explain.add_argument("denial_file")
    score = sub.add_parser("score", help="Score local agent tool safety")
    score.add_argument("--path", default=".")
    score.add_argument("--ledger", default=LOCAL_LEDGER)
    check = sub.add_parser("check", help="Check a MAKOTO project")
    check.add_argument("--path", default=".")
    wrap = sub.add_parser("wrap", help="Run a command only after MAKOTO authorizes the tool")
    wrap.add_argument("--tool", required=True)
    wrap.add_argument("--work-order", default=None)
    wrap.add_argument("--agent-id", default="local-agent")
    wrap.add_argument("--ledger", default=LOCAL_LEDGER)
    wrap.add_argument("--allow-dev", action="store_true", help="Create a one-off local dev mission")
    wrap.add_argument("--risk-budget", type=float, default=10.0)
    wrap.add_argument("--mode", choices=["gate", "env"], default="gate")
    wrap.add_argument("command_args", nargs=argparse.REMAINDER)
    init = sub.add_parser("init", help="Create a minimal MAKOTO quickstart project")
    init.add_argument("path", nargs="?", default="makoto-quickstart")
    init.add_argument("--force", action="store_true")
    export = sub.add_parser("export-schemas", help="Export MAKOTO JSON Schemas")
    export.add_argument("output_dir")
    sign = sub.add_parser("sign", help="Sign a MAKOTO protocol object with a development HMAC key")
    sign.add_argument("kind", choices=sorted(KIND_TO_SCHEMA))
    sign.add_argument("path")
    sign.add_argument("--out", default=None)
    sign.add_argument("--hmac-secret", default=None)
    sign.add_argument("--key-id", default="dev-local-key")
    verify = sub.add_parser("verify", help="Validate a MAKOTO protocol object")
    verify.add_argument("kind", choices=sorted(KIND_TO_SCHEMA))
    verify.add_argument("path")
    verify.add_argument("--hmac-secret", default=None)
    verify.add_argument("--key-id", default="dev-local-key")
    args = parser.parse_args()

    if args.command == "version":
        print(json.dumps({"makoto": __version__, "protocol": PROTOCOL_VERSION}, indent=2))
    elif args.command == "doctor":
        checks = {
            "python": sys.version.split()[0],
            "makoto": __version__,
            "protocol": PROTOCOL_VERSION,
            "cwd": str(Path.cwd()),
            "sqlite_available": True,
        }
        print(json.dumps({"ok": True, "checks": checks}, indent=2, sort_keys=True))
    elif args.command == "demo":
        print(json.dumps(run_demo(args.short), indent=2, sort_keys=True))
    elif args.command == "explain":
        print(explain_denial(args.denial_file))
    elif args.command == "score":
        print(mascot_line("score"))
        print(json.dumps(score_project(args.path, args.ledger), indent=2, sort_keys=True))
    elif args.command == "check":
        print(json.dumps(check_project(args.path), indent=2, sort_keys=True))
    elif args.command == "wrap":
        raise SystemExit(
            wrap_command(
                tool_name=args.tool,
                command=args.command_args,
                work_order_id=args.work_order,
                agent_id=args.agent_id,
                ledger_path=args.ledger,
                allow_dev=args.allow_dev,
                risk_budget=args.risk_budget,
                mode=args.mode,
            )
        )
    elif args.command == "init":
        written = init_project(args.path, args.force)
        print(json.dumps({"written": written}, indent=2))
    elif args.command == "export-schemas":
        written = export_schemas(args.output_dir)
        print(json.dumps({"written": [str(path) for path in written]}, indent=2))
    elif args.command == "sign":
        secret = args.hmac_secret or os.environ.get("MAKOTO_HMAC_SECRET")
        if not secret:
            parser.error("makoto sign requires --hmac-secret or MAKOTO_HMAC_SECRET")
        payload = sign_object(args.kind, load_json(args.path), secret, args.key_id)
        output = json.dumps(payload, indent=2, sort_keys=True)
        if args.out:
            Path(args.out).write_text(output + "\n", encoding="utf-8")
            print(json.dumps({"written": args.out}, indent=2))
        else:
            print(output)
    elif args.command == "verify":
        secret = args.hmac_secret or os.environ.get("MAKOTO_HMAC_SECRET")
        result = verify_object(args.kind, load_json(args.path), secret, args.key_id)
        print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
