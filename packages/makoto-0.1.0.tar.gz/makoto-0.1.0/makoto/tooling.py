from __future__ import annotations

from functools import wraps
from typing import Any, Callable

from makoto.control.errors import AssuranceViolation
from makoto.protocol.schemas import ProofCarryingToolCall
from makoto.sdk.client import MakotoClient


def protected_tool(name: str, client: MakotoClient):
    """Decorate a tool so it only runs with a valid MAKOTO proof chain.

    The wrapped function must be called with `makoto_proof=<ProofCarryingToolCall>`.
    If the wrapped call includes `tool_input=...`, that input hash is checked
    against the proof before the tool body runs.
    """

    def decorator(fn: Callable[..., Any]):
        @wraps(fn)
        def wrapper(*args, makoto_proof: ProofCarryingToolCall | None = None, **kwargs):
            if makoto_proof is None:
                raise AssuranceViolation(f"Tool {name} requires a MAKOTO proof")
            if makoto_proof.tool_name != name:
                raise AssuranceViolation(
                    f"Proof is for {makoto_proof.tool_name}, not protected tool {name}"
                )
            tool_input = kwargs.get("tool_input")
            if not client.verify_tool_call(makoto_proof, tool_input):
                raise AssuranceViolation(f"Invalid MAKOTO proof for tool {name}")
            return fn(*args, **kwargs)

        return wrapper

    return decorator

