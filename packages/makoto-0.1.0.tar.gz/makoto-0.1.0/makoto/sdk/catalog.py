from __future__ import annotations


DANGEROUS_TOOLS: dict[str, int] = {
    "deploy_production": 95,
    "delete_files": 99,
    "rm_rf": 99,
    "transfer_money": 98,
    "send_email": 70,
    "merge_pr": 65,
    "rotate_secrets": 90,
    "push_to_main": 75,
    "close_account": 95,
    "modify_dns": 92,
    "issue_refund": 80,
    "drop_database": 99,
    "execute_sql": 85,
    "modify_firewall": 93,
    "create_user": 60,
}


ALIASES: dict[str, str] = {
    "deploy": "deploy_production",
    "production_deploy": "deploy_production",
    "rm -rf": "rm_rf",
    "remove_all": "rm_rf",
    "payment": "transfer_money",
    "wire_transfer": "transfer_money",
    "email": "send_email",
    "merge": "merge_pr",
    "main_push": "push_to_main",
    "refund": "issue_refund",
    "sql": "execute_sql",
}


def canonical_tool_name(tool_name: str) -> str:
    normalized = tool_name.strip().lower().replace("-", "_")
    return ALIASES.get(normalized, normalized)


def get_risk(tool_name: str, default: int = 25) -> int:
    """Return the risk score for a known tool name on a 0-100 scale."""
    return DANGEROUS_TOOLS.get(canonical_tool_name(tool_name), default)


def is_dangerous(tool_name: str, threshold: int = 60) -> bool:
    return get_risk(tool_name) >= threshold


def describe_tool_risk(tool_name: str) -> str:
    risk = get_risk(tool_name)
    if risk >= 90:
        return "critical"
    if risk >= 75:
        return "high"
    if risk >= 60:
        return "elevated"
    if risk >= 30:
        return "medium"
    return "low"
