from __future__ import annotations

import secrets
from dataclasses import replace
from datetime import datetime, timedelta, timezone
from typing import Any, Optional

from makoto.control.errors import AssuranceViolation, ConflictViolation
from makoto.control.policy import SimplePolicyEngine
from makoto.ledger.sqlite_ledger import SQLiteLedger
from makoto.protocol.canonical_json import canonical_json, sha256_hex, to_plain
from makoto.protocol.schemas import (
    AgentAttestation,
    AuditEvent,
    MissionCampaignPermit,
    OutcomeRecord,
    PROTOCOL_VERSION,
    ProofCarryingToolCall,
    SignedWorkOrder,
    SwarmSnapshot,
    WitnessReport,
)
from makoto.protocol.signing import HmacSha256Signer, Signer, utc_now


def _id(prefix: str) -> str:
    return f"{prefix}_{secrets.token_hex(8)}"


def _future(seconds: int) -> str:
    return (datetime.now(timezone.utc) + timedelta(seconds=seconds)).isoformat()


class MakotoClient:
    """High-level SDK for MAKOTO campaign, work-order and tool-proof flows."""

    def __init__(
        self,
        ledger_path: str = ":memory:",
        signer: Signer | None = None,
        policy: SimplePolicyEngine | None = None,
    ):
        self.ledger = SQLiteLedger(ledger_path)
        self.signer = signer or HmacSha256Signer()
        self.policy = policy or SimplePolicyEngine()

    def _sign(self, obj: Any):
        return replace(obj, signature=self.signer.sign(obj.signing_payload()))

    def _verify_signed(self, obj: Any) -> bool:
        return obj.signature is not None and self.signer.verify(obj.signing_payload(), obj.signature)

    def _event(self, event_type: str, subject_id: str, payload: dict[str, Any]) -> AuditEvent:
        event = AuditEvent(
            protocol_version=PROTOCOL_VERSION,
            event_id=_id("evt"),
            event_type=event_type,
            subject_id=subject_id,
            payload_hash=sha256_hex(payload),
            payload=payload,
            created_at=utc_now(),
        )
        return self._sign(event)

    def register_attestation(
        self,
        agent_id: str,
        code_hash: str,
        config_hash: str,
        policy_version_hash: str,
        environment: str = "development",
        deployment_id: str = "local",
        secrets_sealed: bool = False,
    ) -> AgentAttestation:
        attestation = AgentAttestation(
            protocol_version=PROTOCOL_VERSION,
            attestation_id=_id("att"),
            agent_id=agent_id,
            code_hash=code_hash,
            config_hash=config_hash,
            policy_version_hash=policy_version_hash,
            environment=environment,
            deployment_id=deployment_id,
            secrets_sealed=secrets_sealed,
            timestamp=utc_now(),
        )
        signed = self._sign(attestation)
        self.ledger.put("attestations", signed, signed.timestamp)
        self.ledger.append_event(
            self._event("agent_attested", signed.attestation_id, {"agent_id": agent_id})
        )
        return signed

    def launch_campaign(
        self,
        tenant_id: str,
        commander_agent_id: str,
        objective: str,
        allowed_agent_roles: list[str],
        max_parallel_agents: int,
        max_work_orders: int,
        max_total_risk: float,
        approver_id: str,
        policy_hash: str,
        ttl_seconds: int = 14_400,
        escalation_rules: Optional[dict[str, Any]] = None,
    ) -> MissionCampaignPermit:
        campaign = MissionCampaignPermit(
            protocol_version=PROTOCOL_VERSION,
            campaign_id=_id("camp"),
            tenant_id=tenant_id,
            commander_agent_id=commander_agent_id,
            objective=objective,
            allowed_agent_roles=allowed_agent_roles,
            max_parallel_agents=max_parallel_agents,
            max_work_orders=max_work_orders,
            global_risk_budget_id=_id("risk"),
            max_total_risk=max_total_risk,
            escalation_rules=escalation_rules or {},
            human_approved=True,
            approver_id=approver_id,
            policy_hash=policy_hash,
            created_at=utc_now(),
            expires_at=_future(ttl_seconds),
        )
        signed = self._sign(campaign)
        self.ledger.put("campaigns", signed, signed.created_at)
        self.ledger.append_event(
            self._event(
                "campaign_launched",
                signed.campaign_id,
                {"campaign_id": signed.campaign_id, "tenant_id": tenant_id},
            )
        )
        return signed

    def submit_work_order(
        self,
        campaign_id: str,
        assigned_agent_id: str,
        assigned_role: str,
        objective: str,
        allowed_tools: list[str],
        forbidden_tools: list[str],
        resource_locks: list[str],
        risk_budget_allocation: float,
        depends_on: Optional[list[str]] = None,
        ttl_seconds: int = 7_200,
    ) -> SignedWorkOrder:
        now = utc_now()
        campaign = self.ledger.get("campaigns", campaign_id)
        if campaign is None or not self._verify_signed(campaign):
            raise AssuranceViolation("Missing or invalid campaign permit")

        work_order = SignedWorkOrder(
            protocol_version=PROTOCOL_VERSION,
            work_order_id=_id("wo"),
            parent_campaign_id=campaign_id,
            assigned_agent_id=assigned_agent_id,
            assigned_role=assigned_role,
            objective=objective,
            allowed_tools=allowed_tools,
            forbidden_tools=forbidden_tools,
            resource_locks=resource_locks,
            depends_on=depends_on or [],
            risk_budget_allocation=risk_budget_allocation,
            created_at=now,
            expiry=_future(ttl_seconds),
        )
        existing = self.ledger.list_work_orders_for_campaign(campaign_id)
        self.policy.validate_work_order(campaign, existing, work_order, now)

        for resource in resource_locks:
            if not self.ledger.acquire_lock(resource, campaign_id, work_order.work_order_id, assigned_agent_id, now):
                lock = self.ledger.get_lock(resource)
                raise ConflictViolation(
                    f"Resource lock conflict for {resource}; held by {lock['work_order_id'] if lock else 'unknown'}"
                )

        signed = self._sign(work_order)
        self.ledger.put("work_orders", signed, signed.created_at)
        self.ledger.append_event(
            self._event(
                "work_order_signed",
                signed.work_order_id,
                {
                    "campaign_id": campaign_id,
                    "work_order_id": signed.work_order_id,
                    "assigned_agent_id": assigned_agent_id,
                },
            )
        )
        return signed

    def authorize_tool_call(
        self,
        work_order_id: str,
        agent_id: str,
        tool_name: str,
        tool_input: dict[str, Any],
        human_approved: Optional[bool] = None,
    ) -> ProofCarryingToolCall:
        now = utc_now()
        work_order = self.ledger.get("work_orders", work_order_id)
        if work_order is None or not self._verify_signed(work_order):
            raise AssuranceViolation("Missing or invalid work order")
        if work_order.assigned_agent_id != agent_id:
            raise AssuranceViolation("Work order is assigned to another agent")

        campaign = self.ledger.get("campaigns", work_order.parent_campaign_id)
        if campaign is None or not self._verify_signed(campaign):
            raise AssuranceViolation("Missing or invalid campaign permit")

        self.policy.validate_tool_call(campaign, work_order, tool_name, now)
        runtime_attested = any(
            att.agent_id == agent_id and self._verify_signed(att)
            for att in self.ledger.list("attestations")
        )
        if not runtime_attested:
            raise AssuranceViolation("No Attestation, No Mission")

        used = sum(w.risk_budget_allocation for w in self.ledger.list_work_orders_for_campaign(campaign.campaign_id))
        remaining = max(campaign.max_total_risk - used, 0.0)
        proof = ProofCarryingToolCall(
            protocol_version=PROTOCOL_VERSION,
            proof_id=_id("proof"),
            tool_name=tool_name,
            tool_input_hash=sha256_hex(canonical_json(tool_input)),
            mission_campaign_id=campaign.campaign_id,
            work_order_id=work_order.work_order_id,
            agent_id=agent_id,
            policy_approved=True,
            human_approved=human_approved,
            runtime_attested=runtime_attested,
            risk_budget_remaining=remaining,
            created_at=now,
        )
        signed = self._sign(proof)
        self.ledger.put("tool_calls", signed, signed.created_at)
        self.ledger.append_event(
            self._event(
                "tool_call_authorized",
                signed.proof_id,
                {
                    "campaign_id": campaign.campaign_id,
                    "work_order_id": work_order.work_order_id,
                    "proof_id": signed.proof_id,
                    "tool_name": tool_name,
                },
            )
        )
        return signed

    def verify_tool_call(
        self,
        proof: ProofCarryingToolCall,
        tool_input: Optional[dict[str, Any]] = None,
    ) -> bool:
        if not self._verify_signed(proof):
            return False
        if tool_input is not None and proof.tool_input_hash != sha256_hex(canonical_json(tool_input)):
            return False

        work_order = self.ledger.get("work_orders", proof.work_order_id)
        campaign = self.ledger.get("campaigns", proof.mission_campaign_id)
        if work_order is None or campaign is None:
            return False
        if not self._verify_signed(work_order) or not self._verify_signed(campaign):
            return False
        try:
            self.policy.validate_tool_call(campaign, work_order, proof.tool_name, utc_now())
        except AssuranceViolation:
            return False
        return proof.agent_id == work_order.assigned_agent_id and proof.policy_approved and proof.runtime_attested

    def record_outcome(
        self,
        proof_id: str,
        expected_outcome: str,
        actual_outcome: str,
        outcome_match: float,
        human_rating: Optional[str] = None,
        human_override: bool = False,
        incident_after_action: bool = False,
        value_estimate: float = 0.0,
    ) -> OutcomeRecord:
        proof = self.ledger.get("tool_calls", proof_id)
        if proof is None or not self._verify_signed(proof):
            raise AssuranceViolation("Missing or invalid proof")
        outcome = OutcomeRecord(
            protocol_version=PROTOCOL_VERSION,
            outcome_id=_id("out"),
            campaign_id=proof.mission_campaign_id,
            work_order_id=proof.work_order_id,
            proof_id=proof.proof_id,
            expected_outcome=expected_outcome,
            actual_outcome=actual_outcome,
            outcome_match=outcome_match,
            human_rating=human_rating,
            human_override=human_override,
            incident_after_action=incident_after_action,
            value_estimate=value_estimate,
            created_at=utc_now(),
        )
        signed = self._sign(outcome)
        self.ledger.put("outcomes", signed, signed.created_at)
        self.ledger.release_locks_for_work_order(proof.work_order_id)
        self.ledger.append_event(
            self._event(
                "outcome_recorded",
                signed.outcome_id,
                {
                    "campaign_id": signed.campaign_id,
                    "work_order_id": signed.work_order_id,
                    "proof_id": proof.proof_id,
                    "outcome_match": outcome_match,
                },
            )
        )
        return signed

    def witness_work_order(
        self,
        work_order_id: str,
        observer_agent_id: str,
        attempted_tools: list[str],
    ) -> WitnessReport:
        work_order = self.ledger.get("work_orders", work_order_id)
        if work_order is None:
            raise AssuranceViolation("Missing work order")
        violations = [
            tool
            for tool in attempted_tools
            if tool in work_order.forbidden_tools or tool not in work_order.allowed_tools
        ]
        report = WitnessReport(
            protocol_version=PROTOCOL_VERSION,
            report_id=_id("wit"),
            campaign_id=work_order.parent_campaign_id,
            work_order_id=work_order_id,
            observer_agent_id=observer_agent_id,
            verdict="PASS" if not violations else "FAIL",
            violations=violations,
            created_at=utc_now(),
        )
        signed = self._sign(report)
        self.ledger.put("witness_reports", signed, signed.created_at)
        self.ledger.append_event(
            self._event(
                "witness_reported",
                signed.report_id,
                {
                    "campaign_id": signed.campaign_id,
                    "work_order_id": work_order_id,
                    "verdict": signed.verdict,
                },
            )
        )
        return signed

    def replay_campaign(self, campaign_id: str, at_time: Optional[str] = None) -> SwarmSnapshot:
        return self.ledger.replay_campaign(campaign_id, at_time or utc_now())

    def export_campaign_json(self, campaign_id: str) -> dict[str, Any]:
        snapshot = self.replay_campaign(campaign_id)
        return to_plain(snapshot)
