"""MAKOTO: Mission Integrity for Autonomous Agent Swarms."""

__version__ = "0.1.0"
PROTOCOL_VERSION = "makoto.protocol.v0.1"

from makoto.sdk.client import MakotoClient
from makoto.tooling import protected_tool
from makoto.protocol.schemas import (
    AgentAttestation,
    MissionCampaignPermit,
    OutcomeRecord,
    ProofCarryingToolCall,
    SignedWorkOrder,
    SwarmSnapshot,
)

__all__ = [
    "AgentAttestation",
    "MakotoClient",
    "MissionCampaignPermit",
    "PROTOCOL_VERSION",
    "OutcomeRecord",
    "ProofCarryingToolCall",
    "SignedWorkOrder",
    "SwarmSnapshot",
    "__version__",
    "protected_tool",
]
