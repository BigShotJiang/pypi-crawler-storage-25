"""Persistence layer for MAKOTO."""

