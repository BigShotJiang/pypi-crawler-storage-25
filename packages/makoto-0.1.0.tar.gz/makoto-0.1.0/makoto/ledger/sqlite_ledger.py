from __future__ import annotations

import json
import sqlite3
from dataclasses import fields
from pathlib import Path
from typing import Any, TypeVar

from makoto.protocol.canonical_json import canonical_json, to_plain
from makoto.protocol.schemas import (
    AgentAttestation,
    AuditEvent,
    MissionCampaignPermit,
    OutcomeRecord,
    ProofCarryingToolCall,
    SignedWorkOrder,
    SwarmSnapshot,
    WitnessReport,
)
from makoto.protocol.signing import SignatureEnvelope

T = TypeVar("T")


TABLES = {
    "attestations": AgentAttestation,
    "campaigns": MissionCampaignPermit,
    "work_orders": SignedWorkOrder,
    "tool_calls": ProofCarryingToolCall,
    "outcomes": OutcomeRecord,
    "witness_reports": WitnessReport,
    "audit_events": AuditEvent,
}


PRIMARY_KEYS = {
    "attestations": "attestation_id",
    "campaigns": "campaign_id",
    "work_orders": "work_order_id",
    "tool_calls": "proof_id",
    "outcomes": "outcome_id",
    "witness_reports": "report_id",
    "audit_events": "event_id",
}


def _decode_signature(value: Any) -> Any:
    if isinstance(value, dict) and {"alg", "key_id", "value", "created_at"} <= set(value):
        return SignatureEnvelope(**value)
    return value


def _from_dict(cls: type[T], data: dict[str, Any]) -> T:
    kwargs = {}
    for field in fields(cls):
        value = data.get(field.name)
        if field.name == "signature" and value is not None:
            value = _decode_signature(value)
        kwargs[field.name] = value
    return cls(**kwargs)


class SQLiteLedger:
    def __init__(self, path: str | Path = ":memory:"):
        self.path = str(path)
        self.conn = sqlite3.connect(self.path)
        self.conn.row_factory = sqlite3.Row
        self._init_schema()

    def _init_schema(self) -> None:
        cur = self.conn.cursor()
        for table in TABLES:
            cur.execute(
                f"""
                CREATE TABLE IF NOT EXISTS {table} (
                    id TEXT PRIMARY KEY,
                    json TEXT NOT NULL,
                    created_at TEXT NOT NULL
                )
                """
            )
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS resource_locks (
                resource TEXT PRIMARY KEY,
                campaign_id TEXT NOT NULL,
                work_order_id TEXT NOT NULL,
                agent_id TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
            """
        )
        self.conn.commit()

    def put(self, table: str, obj: Any, created_at: str, object_id: str | None = None) -> None:
        if table not in TABLES:
            raise ValueError(f"Unknown table: {table}")
        key = object_id or getattr(obj, PRIMARY_KEYS[table])
        self.conn.execute(
            f"INSERT OR REPLACE INTO {table} (id, json, created_at) VALUES (?, ?, ?)",
            (key, canonical_json(to_plain(obj)), created_at),
        )
        self.conn.commit()

    def get(self, table: str, object_id: str) -> Any | None:
        row = self.conn.execute(f"SELECT json FROM {table} WHERE id = ?", (object_id,)).fetchone()
        if row is None:
            return None
        data = json.loads(row["json"])
        return _from_dict(TABLES[table], data)

    def list(self, table: str) -> list[Any]:
        rows = self.conn.execute(f"SELECT json FROM {table} ORDER BY created_at ASC").fetchall()
        return [_from_dict(TABLES[table], json.loads(row["json"])) for row in rows]

    def list_work_orders_for_campaign(self, campaign_id: str) -> list[SignedWorkOrder]:
        return [
            item
            for item in self.list("work_orders")
            if item.parent_campaign_id == campaign_id
        ]

    def list_tool_calls_for_campaign(self, campaign_id: str) -> list[ProofCarryingToolCall]:
        return [
            item
            for item in self.list("tool_calls")
            if item.mission_campaign_id == campaign_id
        ]

    def list_outcomes_for_campaign(self, campaign_id: str) -> list[OutcomeRecord]:
        return [item for item in self.list("outcomes") if item.campaign_id == campaign_id]

    def append_event(self, event: AuditEvent) -> None:
        self.put("audit_events", event, event.created_at)

    def acquire_lock(
        self,
        resource: str,
        campaign_id: str,
        work_order_id: str,
        agent_id: str,
        created_at: str,
    ) -> bool:
        try:
            self.conn.execute(
                """
                INSERT INTO resource_locks (resource, campaign_id, work_order_id, agent_id, created_at)
                VALUES (?, ?, ?, ?, ?)
                """,
                (resource, campaign_id, work_order_id, agent_id, created_at),
            )
            self.conn.commit()
            return True
        except sqlite3.IntegrityError:
            return False

    def release_locks_for_work_order(self, work_order_id: str) -> None:
        self.conn.execute("DELETE FROM resource_locks WHERE work_order_id = ?", (work_order_id,))
        self.conn.commit()

    def get_lock(self, resource: str) -> dict[str, str] | None:
        row = self.conn.execute(
            "SELECT * FROM resource_locks WHERE resource = ?",
            (resource,),
        ).fetchone()
        return dict(row) if row else None

    def replay_campaign(self, campaign_id: str, at_time: str) -> SwarmSnapshot:
        campaign = self.get("campaigns", campaign_id)
        work_orders = [
            w for w in self.list_work_orders_for_campaign(campaign_id) if w.created_at <= at_time
        ]
        tool_calls = [
            t for t in self.list_tool_calls_for_campaign(campaign_id) if t.created_at <= at_time
        ]
        outcomes = [
            o for o in self.list_outcomes_for_campaign(campaign_id) if o.created_at <= at_time
        ]
        events = [
            e
            for e in self.list("audit_events")
            if e.payload.get("campaign_id") == campaign_id and e.created_at <= at_time
        ]
        return SwarmSnapshot(campaign_id, at_time, campaign, work_orders, tool_calls, outcomes, events)

