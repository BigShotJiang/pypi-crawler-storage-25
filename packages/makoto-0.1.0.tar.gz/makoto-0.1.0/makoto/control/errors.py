class MakotoError(Exception):
    """Base MAKOTO exception."""


class AssuranceViolation(MakotoError):
    """Raised when a request violates the mission control plane."""


class ConflictViolation(MakotoError):
    """Raised when a resource lock conflicts with a proposed work order."""

