from __future__ import annotations

from datetime import datetime

from makoto.control.errors import AssuranceViolation
from makoto.protocol.schemas import MissionCampaignPermit, SignedWorkOrder


def parse_time(value: str) -> datetime:
    return datetime.fromisoformat(value)


class SimplePolicyEngine:
    """Minimal deterministic policy engine.

    Production can swap this boundary for Cedar while preserving the protocol.
    """

    def require_active_campaign(self, campaign: MissionCampaignPermit, now: str) -> None:
        if not campaign.human_approved:
            raise AssuranceViolation("Campaign is not human approved")
        if parse_time(campaign.expires_at) <= parse_time(now):
            raise AssuranceViolation("Campaign has expired")

    def validate_work_order(
        self,
        campaign: MissionCampaignPermit,
        existing_work_orders: list[SignedWorkOrder],
        work_order: SignedWorkOrder,
        now: str,
    ) -> None:
        self.require_active_campaign(campaign, now)
        if work_order.assigned_role not in campaign.allowed_agent_roles:
            raise AssuranceViolation(f"Role not allowed in campaign: {work_order.assigned_role}")
        if len(existing_work_orders) >= campaign.max_work_orders:
            raise AssuranceViolation("Campaign work order limit exceeded")
        if work_order.risk_budget_allocation < 0:
            raise AssuranceViolation("Risk budget allocation must be non-negative")
        used = sum(w.risk_budget_allocation for w in existing_work_orders)
        if used + work_order.risk_budget_allocation > campaign.max_total_risk:
            raise AssuranceViolation("Swarm risk budget exceeded")

    def validate_tool_call(
        self,
        campaign: MissionCampaignPermit,
        work_order: SignedWorkOrder,
        tool_name: str,
        now: str,
    ) -> None:
        self.require_active_campaign(campaign, now)
        if parse_time(work_order.expiry) <= parse_time(now):
            raise AssuranceViolation("Work order has expired")
        if tool_name in work_order.forbidden_tools:
            raise AssuranceViolation(f"Tool is explicitly forbidden: {tool_name}")
        if tool_name not in work_order.allowed_tools:
            raise AssuranceViolation(f"Tool is not in work order scope: {tool_name}")

