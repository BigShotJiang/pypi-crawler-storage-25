from __future__ import annotations

from typing import Any

from makoto.adapters.base import MakotoToolAdapter, ToolExecutionResult, ToolRequest


def _get(value: Any, key: str, default: Any = None) -> Any:
    if isinstance(value, dict):
        return value.get(key, default)
    return getattr(value, key, default)


def parse_claude_tool_use(tool_use: Any) -> ToolRequest:
    """Parse a Claude-style tool_use block into a MAKOTO ToolRequest.

    Supports dicts and SDK-like objects shaped like:

    {
      "type": "tool_use",
      "id": "toolu_...",
      "name": "run_tests",
      "input": {"pull_request": 42}
    }
    """

    arguments = _get(tool_use, "input", {})
    if not isinstance(arguments, dict):
        raise ValueError("Claude tool_use input must be an object")
    return ToolRequest(
        name=_get(tool_use, "name"),
        arguments=arguments,
        call_id=_get(tool_use, "id"),
    )


def execute_claude_tool_use(
    tool_use: Any,
    adapter: MakotoToolAdapter,
) -> dict[str, Any]:
    """Execute a Claude-style tool_use block and return a tool_result block."""

    result: ToolExecutionResult = adapter.execute(parse_claude_tool_use(tool_use))
    return {
        "type": "tool_result",
        "tool_use_id": result.call_id,
        "content": [
            {
                "type": "text",
                "text": str(
                    {
                        "output": result.output,
                        "makoto_proof_id": result.proof_id,
                    }
                ),
            }
        ],
    }

