from __future__ import annotations

from typing import Any

from makoto.adapters.base import MakotoToolAdapter, ToolRequest


def make_langgraph_tool_node(adapter: MakotoToolAdapter):
    """Create a dependency-free LangGraph-style node.

    The returned callable expects a state dict with `tool_call`:

    {"tool_call": {"name": "run_tests", "arguments": {...}, "id": "call_1"}}

    It returns a partial state dict containing `tool_result`.
    """

    def node(state: dict[str, Any]) -> dict[str, Any]:
        call = state["tool_call"]
        result = adapter.execute(
            ToolRequest(
                name=call["name"],
                arguments=call.get("arguments", {}),
                call_id=call.get("id"),
            )
        )
        return {
            "tool_result": {
                "name": result.tool_name,
                "output": result.output,
                "makoto_proof_id": result.proof_id,
                "call_id": result.call_id,
            }
        }

    return node

