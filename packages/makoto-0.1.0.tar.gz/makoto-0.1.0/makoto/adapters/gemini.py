from __future__ import annotations

from typing import Any

from makoto.adapters.base import MakotoToolAdapter, ToolExecutionResult, ToolRequest


def _get(value: Any, key: str, default: Any = None) -> Any:
    if isinstance(value, dict):
        return value.get(key, default)
    return getattr(value, key, default)


def parse_gemini_function_call(function_call: Any) -> ToolRequest:
    """Parse a Gemini-style functionCall/function_call object.

    Supports dicts and SDK-like objects shaped like:

    {
      "name": "run_tests",
      "args": {"pull_request": 42}
    }

    Also accepts wrappers such as:

    {
      "functionCall": {"name": "run_tests", "args": {...}}
    }
    """

    wrapped = _get(function_call, "functionCall") or _get(function_call, "function_call")
    if wrapped is not None:
        function_call = wrapped
    arguments = _get(function_call, "args", {})
    if not isinstance(arguments, dict):
        raise ValueError("Gemini function call args must be an object")
    return ToolRequest(
        name=_get(function_call, "name"),
        arguments=arguments,
        call_id=_get(function_call, "id"),
    )


def execute_gemini_function_call(
    function_call: Any,
    adapter: MakotoToolAdapter,
) -> dict[str, Any]:
    """Execute a Gemini-style function call and return a functionResponse part."""

    result: ToolExecutionResult = adapter.execute(parse_gemini_function_call(function_call))
    return {
        "functionResponse": {
            "name": result.tool_name,
            "response": {
                "output": result.output,
                "makoto_proof_id": result.proof_id,
            },
        }
    }

