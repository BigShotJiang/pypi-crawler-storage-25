from __future__ import annotations

import json
from typing import Any

from makoto.adapters.base import MakotoToolAdapter, ToolExecutionResult, ToolRequest


def _get(value: Any, key: str, default: Any = None) -> Any:
    if isinstance(value, dict):
        return value.get(key, default)
    return getattr(value, key, default)


def parse_openai_tool_call(tool_call: Any) -> ToolRequest:
    """Parse an OpenAI-style tool call into a MAKOTO ToolRequest.

    Supports dicts and SDK-like objects shaped like:

    {
      "id": "call_...",
      "function": {"name": "run_tests", "arguments": "{\"pull_request\": 42}"}
    }
    """

    function = _get(tool_call, "function", {})
    name = _get(function, "name")
    arguments = _get(function, "arguments", {})
    if isinstance(arguments, str):
        arguments = json.loads(arguments or "{}")
    if not isinstance(arguments, dict):
        raise ValueError("OpenAI tool call arguments must decode to an object")
    return ToolRequest(name=name, arguments=arguments, call_id=_get(tool_call, "id"))


def execute_openai_tool_call(
    tool_call: Any,
    adapter: MakotoToolAdapter,
) -> dict[str, Any]:
    """Execute an OpenAI-style tool call and return a tool-message dict."""

    result: ToolExecutionResult = adapter.execute(parse_openai_tool_call(tool_call))
    return {
        "role": "tool",
        "tool_call_id": result.call_id,
        "name": result.tool_name,
        "content": json.dumps(
            {
                "output": result.output,
                "makoto_proof_id": result.proof_id,
            },
            sort_keys=True,
        ),
    }

