from __future__ import annotations

from typing import Any

from makoto.adapters.base import MakotoToolAdapter, ToolRequest


def execute_autogen_tool_call(
    call: dict[str, Any],
    adapter: MakotoToolAdapter,
) -> dict[str, Any]:
    """Execute a simple AutoGen-style tool call dict through MAKOTO."""

    result = adapter.execute(
        ToolRequest(
            name=call["name"],
            arguments=call.get("arguments", {}),
            call_id=call.get("id"),
        )
    )
    return {
        "id": result.call_id,
        "name": result.tool_name,
        "result": result.output,
        "makoto_proof_id": result.proof_id,
    }

