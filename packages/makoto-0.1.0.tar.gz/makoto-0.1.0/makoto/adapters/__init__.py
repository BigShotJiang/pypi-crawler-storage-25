"""Dependency-free MAKOTO adapters for common agent tool-call shapes."""

from makoto.adapters.base import MakotoToolAdapter, ToolExecutionResult, ToolRequest
from makoto.adapters.claude import execute_claude_tool_use, parse_claude_tool_use
from makoto.adapters.gemini import execute_gemini_function_call, parse_gemini_function_call
from makoto.adapters.openai import execute_openai_tool_call, parse_openai_tool_call

__all__ = [
    "MakotoToolAdapter",
    "ToolExecutionResult",
    "ToolRequest",
    "execute_claude_tool_use",
    "execute_gemini_function_call",
    "execute_openai_tool_call",
    "parse_claude_tool_use",
    "parse_gemini_function_call",
    "parse_openai_tool_call",
]
