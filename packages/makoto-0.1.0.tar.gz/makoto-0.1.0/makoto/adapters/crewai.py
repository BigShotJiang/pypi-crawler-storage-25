from __future__ import annotations

from typing import Any

from makoto.adapters.base import MakotoToolAdapter, ToolRequest


def make_crewai_tool(adapter: MakotoToolAdapter, tool_name: str):
    """Create a dependency-free CrewAI-style callable tool wrapper."""

    def tool(**kwargs: Any) -> Any:
        return adapter.execute(ToolRequest(name=tool_name, arguments=dict(kwargs))).output

    tool.__name__ = tool_name
    tool.__doc__ = f"MAKOTO-protected CrewAI-style tool: {tool_name}"
    return tool

