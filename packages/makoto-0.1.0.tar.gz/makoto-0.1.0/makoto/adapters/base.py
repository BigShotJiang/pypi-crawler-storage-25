from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable

from makoto.control.errors import AssuranceViolation
from makoto.sdk.client import MakotoClient


@dataclass(frozen=True)
class ToolRequest:
    name: str
    arguments: dict[str, Any]
    call_id: str | None = None


@dataclass(frozen=True)
class ToolExecutionResult:
    tool_name: str
    tool_input: dict[str, Any]
    output: Any
    proof_id: str
    call_id: str | None = None


class MakotoToolAdapter:
    """Authorize and execute model-emitted tool calls through MAKOTO.

    Tool functions should accept `tool_input=...` and `makoto_proof=...`.
    This keeps the adapter compatible with local agents and hosted model
    providers without importing those provider SDKs.
    """

    def __init__(
        self,
        client: MakotoClient,
        work_order_id: str,
        agent_id: str,
        tools: dict[str, Callable[..., Any]],
    ):
        self.client = client
        self.work_order_id = work_order_id
        self.agent_id = agent_id
        self.tools = tools

    def execute(self, request: ToolRequest) -> ToolExecutionResult:
        tool = self.tools.get(request.name)
        if tool is None:
            raise AssuranceViolation(f"Tool is not registered: {request.name}")

        proof = self.client.authorize_tool_call(
            work_order_id=self.work_order_id,
            agent_id=self.agent_id,
            tool_name=request.name,
            tool_input=request.arguments,
        )
        output = tool(tool_input=request.arguments, makoto_proof=proof)
        return ToolExecutionResult(
            tool_name=request.name,
            tool_input=request.arguments,
            output=output,
            proof_id=proof.proof_id,
            call_id=request.call_id,
        )

