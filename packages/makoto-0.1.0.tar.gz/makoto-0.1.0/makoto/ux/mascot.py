from __future__ import annotations


LINES = {
    "allowed": "MAKOTO: mission verified. Tool may run.",
    "denied": "MAKOTO: no valid mission, no tool.",
    "explain": "MAKOTO: denial explained.",
    "score": "MAKOTO: safety score computed.",
    "warning": "MAKOTO: tighten the mission boundary.",
}


def mascot_line(event: str) -> str:
    return LINES.get(event, "MAKOTO: signed missions for AI agents.")
