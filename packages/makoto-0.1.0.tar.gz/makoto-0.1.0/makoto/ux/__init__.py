from makoto.ux.mascot import mascot_line

__all__ = ["mascot_line"]
