# Security Policy

MAKOTO OSS is a developer protocol and local enforcement reference. It is not a
complete production gateway.

## Supported Versions

| Version | Supported |
| --- | --- |
| 0.1.x | Yes |

## Reporting A Vulnerability

Do not open public issues for exploitable security vulnerabilities. Send a
private report to the maintainers with:

- affected version
- reproduction steps
- expected impact
- suggested fix, if known

## Important Boundaries

- The default HMAC signer is for local development.
- Production deployments should use Ed25519/KMS/HSM-backed signing.
- The OSS package demonstrates local tool protection. Non-bypassable gateway and
  MCP proxy enforcement belong in the commercial control plane.

