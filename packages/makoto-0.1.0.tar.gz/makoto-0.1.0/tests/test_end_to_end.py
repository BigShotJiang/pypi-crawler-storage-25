import unittest
import json
import sys
from tempfile import TemporaryDirectory

from makoto import MakotoClient, protected_tool
from makoto.adapters import (
    MakotoToolAdapter,
    execute_claude_tool_use,
    execute_gemini_function_call,
    execute_openai_tool_call,
)
from makoto.adapters.autogen import execute_autogen_tool_call
from makoto.adapters.crewai import make_crewai_tool
from makoto.adapters.langgraph import make_langgraph_tool_node
from makoto.cli import (
    denial_payload,
    explain_denial,
    init_project,
    score_project,
    wrap_command,
)
from makoto.control.errors import AssuranceViolation, ConflictViolation
from makoto.protocol.canonical_json import to_plain
from makoto.protocol.signing import HmacSha256Signer
from makoto.protocol.verifier import sign_object, verify_object
from makoto.sdk.catalog import describe_tool_risk, get_risk, is_dangerous


class MakotoEndToEndTests(unittest.TestCase):
    def setUp(self):
        self.client = MakotoClient()
        self.client.register_attestation(
            agent_id="ci-agent-01",
            code_hash="sha256:code",
            config_hash="sha256:config",
            policy_version_hash="sha256:policy",
        )
        self.campaign = self.client.launch_campaign(
            tenant_id="demo-org",
            commander_agent_id="commander",
            objective="Validate a pull request",
            allowed_agent_roles=["ci", "reviewer"],
            max_parallel_agents=3,
            max_work_orders=5,
            max_total_risk=100.0,
            approver_id="repo-owner",
            policy_hash="sha256:policy",
        )

    def test_campaign_work_order_tool_outcome_replay(self):
        work = self.client.submit_work_order(
            campaign_id=self.campaign.campaign_id,
            assigned_agent_id="ci-agent-01",
            assigned_role="ci",
            objective="Run pull request tests",
            allowed_tools=["run_tests"],
            forbidden_tools=["deploy_production"],
            resource_locks=["repo:main:test-runner"],
            risk_budget_allocation=10.0,
        )
        proof = self.client.authorize_tool_call(
            work_order_id=work.work_order_id,
            agent_id="ci-agent-01",
            tool_name="run_tests",
            tool_input={"pull_request": 42},
        )
        self.assertTrue(self.client.verify_tool_call(proof, {"pull_request": 42}))
        self.assertFalse(self.client.verify_tool_call(proof, {"pull_request": 43}))

        outcome = self.client.record_outcome(
            proof_id=proof.proof_id,
            expected_outcome="tests completed",
            actual_outcome="tests completed",
            outcome_match=0.9,
        )
        snapshot = self.client.replay_campaign(self.campaign.campaign_id)
        self.assertEqual(len(snapshot.work_orders), 1)
        self.assertEqual(len(snapshot.tool_calls), 1)
        self.assertEqual(snapshot.outcomes[0].outcome_id, outcome.outcome_id)

    def test_forbidden_tool_is_denied(self):
        work = self.client.submit_work_order(
            campaign_id=self.campaign.campaign_id,
            assigned_agent_id="ci-agent-01",
            assigned_role="ci",
            objective="Run tests",
            allowed_tools=["run_tests"],
            forbidden_tools=["deploy_production"],
            resource_locks=[],
            risk_budget_allocation=5.0,
        )
        with self.assertRaises(AssuranceViolation):
            self.client.authorize_tool_call(
                work_order_id=work.work_order_id,
                agent_id="ci-agent-01",
                tool_name="deploy_production",
                tool_input={},
            )

    def test_conflicting_resource_lock_is_blocked(self):
        self.client.submit_work_order(
            campaign_id=self.campaign.campaign_id,
            assigned_agent_id="ci-agent-01",
            assigned_role="ci",
            objective="Run tests",
            allowed_tools=["run_tests"],
            forbidden_tools=[],
            resource_locks=["repo:main:test-runner"],
            risk_budget_allocation=5.0,
        )
        with self.assertRaises(ConflictViolation):
            self.client.submit_work_order(
                campaign_id=self.campaign.campaign_id,
                assigned_agent_id="reviewer-agent-01",
                assigned_role="reviewer",
                objective="Run tests on same runner",
                allowed_tools=["run_tests"],
                forbidden_tools=[],
                resource_locks=["repo:main:test-runner"],
                risk_budget_allocation=5.0,
            )

    def test_agent_without_attestation_cannot_execute(self):
        work = self.client.submit_work_order(
            campaign_id=self.campaign.campaign_id,
            assigned_agent_id="reviewer-agent-01",
            assigned_role="reviewer",
            objective="Review test findings",
            allowed_tools=["summarize_results"],
            forbidden_tools=[],
            resource_locks=[],
            risk_budget_allocation=5.0,
        )
        with self.assertRaises(AssuranceViolation):
            self.client.authorize_tool_call(
                work_order_id=work.work_order_id,
                agent_id="reviewer-agent-01",
                tool_name="summarize_results",
                tool_input={},
            )

    def test_protected_tool_requires_valid_proof(self):
        work = self.client.submit_work_order(
            campaign_id=self.campaign.campaign_id,
            assigned_agent_id="ci-agent-01",
            assigned_role="ci",
            objective="Run tests",
            allowed_tools=["run_tests"],
            forbidden_tools=[],
            resource_locks=[],
            risk_budget_allocation=5.0,
        )
        proof = self.client.authorize_tool_call(
            work_order_id=work.work_order_id,
            agent_id="ci-agent-01",
            tool_name="run_tests",
            tool_input={"pull_request": 42},
        )

        @protected_tool("run_tests", self.client)
        def run_tests(*, tool_input):
            return {"pull_request": tool_input["pull_request"], "status": "ok"}

        self.assertEqual(
            run_tests(tool_input={"pull_request": 42}, makoto_proof=proof)["status"],
            "ok",
        )
        with self.assertRaises(AssuranceViolation):
            run_tests(tool_input={"pull_request": 43}, makoto_proof=proof)

    def test_protocol_verifier_checks_shape_and_signature(self):
        signer = HmacSha256Signer(secret=b"test-secret", key_id="test-key")
        client = MakotoClient(signer=signer)
        campaign = client.launch_campaign(
            tenant_id="demo-org",
            commander_agent_id="commander",
            objective="Validate pull request",
            allowed_agent_roles=["ci"],
            max_parallel_agents=1,
            max_work_orders=1,
            max_total_risk=10.0,
            approver_id="repo-owner",
            policy_hash="sha256:policy",
        )

        result = verify_object(
            "campaign",
            to_plain(campaign),
            hmac_secret="test-secret",
            key_id="test-key",
        )
        self.assertTrue(result["shape_valid"])
        self.assertTrue(result["signature_verified"])

    def test_sign_object_round_trip(self):
        payload = {
            "protocol_version": "makoto.protocol.v0.1",
            "allowed_agent_roles": ["ci"],
            "approver_id": "repo-owner",
            "campaign_id": "camp_test",
            "commander_agent_id": "maintainer",
            "created_at": "2026-05-19T00:00:00+00:00",
            "escalation_rules": {},
            "expires_at": "2026-05-19T01:00:00+00:00",
            "global_risk_budget_id": "risk_test",
            "human_approved": True,
            "max_parallel_agents": 1,
            "max_total_risk": 10.0,
            "max_work_orders": 2,
            "objective": "Validate pull request",
            "policy_hash": "sha256:policy",
            "signature": None,
            "tenant_id": "demo-org",
        }
        signed = sign_object("campaign", payload, "test-secret", "test-key")
        result = verify_object("campaign", signed, "test-secret", "test-key")
        self.assertTrue(result["signature_present"])
        self.assertTrue(result["signature_verified"])

        tampered = dict(signed)
        tampered["objective"] = "Tampered objective"
        tampered_result = verify_object("campaign", tampered, "test-secret", "test-key")
        self.assertFalse(tampered_result["signature_verified"])

    def test_init_project_writes_quickstart(self):
        with TemporaryDirectory() as tmp:
            written = init_project(tmp)
            self.assertEqual(len(written), 2)
            self.assertTrue(any(path.endswith("app.py") for path in written))
            self.assertTrue(any(path.endswith("README.md") for path in written))

    def test_dependency_free_adapters_execute_allowed_tool(self):
        client = MakotoClient()
        client.register_attestation(
            agent_id="adapter-agent",
            code_hash="sha256:code",
            config_hash="sha256:config",
            policy_version_hash="sha256:policy",
        )
        campaign = client.launch_campaign(
            tenant_id="demo-org",
            commander_agent_id="commander",
            objective="Run tests",
            allowed_agent_roles=["ci"],
            max_parallel_agents=1,
            max_work_orders=3,
            max_total_risk=10.0,
            approver_id="repo-owner",
            policy_hash="sha256:policy",
        )
        work = client.submit_work_order(
            campaign_id=campaign.campaign_id,
            assigned_agent_id="adapter-agent",
            assigned_role="ci",
            objective="Run tests only",
            allowed_tools=["run_tests"],
            forbidden_tools=["deploy_production"],
            resource_locks=[],
            risk_budget_allocation=2.0,
        )

        @protected_tool("run_tests", client)
        def run_tests(*, tool_input):
            return {"passed": True, "input": tool_input}

        adapter = MakotoToolAdapter(
            client=client,
            work_order_id=work.work_order_id,
            agent_id="adapter-agent",
            tools={"run_tests": run_tests},
        )

        openai_result = execute_openai_tool_call(
            {
                "id": "call_1",
                "function": {
                    "name": "run_tests",
                    "arguments": '{"pull_request": 42}',
                },
            },
            adapter,
        )
        self.assertEqual(openai_result["role"], "tool")

        claude_result = execute_claude_tool_use(
            {
                "type": "tool_use",
                "id": "toolu_1",
                "name": "run_tests",
                "input": {"pull_request": 42},
            },
            adapter,
        )
        self.assertEqual(claude_result["type"], "tool_result")

        gemini_result = execute_gemini_function_call(
            {
                "functionCall": {
                    "name": "run_tests",
                    "args": {"pull_request": 42},
                }
            },
            adapter,
        )
        self.assertEqual(gemini_result["functionResponse"]["name"], "run_tests")

        langgraph_node = make_langgraph_tool_node(adapter)
        self.assertTrue(
            langgraph_node(
                {"tool_call": {"id": "lg_1", "name": "run_tests", "arguments": {}}}
            )["tool_result"]["output"]["passed"]
        )

        crewai_tool = make_crewai_tool(adapter, "run_tests")
        self.assertTrue(crewai_tool()["passed"])

        autogen_result = execute_autogen_tool_call(
            {"id": "ag_1", "name": "run_tests", "arguments": {}},
            adapter,
        )
        self.assertTrue(autogen_result["result"]["passed"])

    def test_dangerous_tool_catalog(self):
        self.assertTrue(is_dangerous("deploy_production"))
        self.assertTrue(is_dangerous("deploy"))
        self.assertEqual(get_risk("rm_rf"), 99)
        self.assertEqual(describe_tool_risk("send_email"), "elevated")

    def test_explain_denial_file(self):
        with TemporaryDirectory() as tmp:
            denial = denial_payload(
                "deploy_production",
                "Tool is explicitly forbidden: deploy_production",
                work_order_id="wo_test",
                allowed_tools=["run_tests"],
            )
            path = f"{tmp}/denied.json"
            with open(path, "w", encoding="utf-8") as handle:
                json.dump(denial, handle)
            explanation = explain_denial(path)
            self.assertIn("DENIED: deploy_production", explanation)
            self.assertIn("run_tests", explanation)

    def test_score_project_detects_makoto_usage(self):
        with TemporaryDirectory() as tmp:
            with open(f"{tmp}/agent.py", "w", encoding="utf-8") as handle:
                handle.write(
                    "from makoto import protected_tool\n"
                    "@protected_tool('deploy_production', client)\n"
                    "def deploy_production(): pass\n"
                )
            score = score_project(tmp, f"{tmp}/ledger.db")
            self.assertIn("deploy_production", score["dangerous_tools_detected"])
            self.assertIn("deploy_production", score["protected_tools_detected"])

    def test_wrap_command_denies_without_work_order(self):
        with TemporaryDirectory() as tmp:
            rc = wrap_command(
                tool_name="deploy_production",
                command=[sys.executable, "-c", "raise SystemExit(99)"],
                ledger_path=f"{tmp}/ledger.db",
            )
            self.assertEqual(rc, 1)

    def test_wrap_command_allow_dev_runs_command(self):
        with TemporaryDirectory() as tmp:
            rc = wrap_command(
                tool_name="run_tests",
                command=[sys.executable, "-c", "print('wrapped ok')"],
                ledger_path=f"{tmp}/ledger.db",
                allow_dev=True,
                risk_budget=5.0,
            )
            self.assertEqual(rc, 0)


if __name__ == "__main__":
    unittest.main()
