# RFC 002: Signed Work Order

Status: Accepted for `makoto-protocol` v0.1

`SignedWorkOrder` is the bounded task object assigned to one agent inside a
campaign. It declares:

- assigned agent and role
- objective
- allowed tools
- forbidden tools
- resource locks
- dependencies
- risk allocation
- expiry
- signature

A tool call is invalid unless it is derived from an active signed work order.

