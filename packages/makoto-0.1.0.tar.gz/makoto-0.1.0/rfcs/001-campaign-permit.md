# RFC 001: Mission Campaign Permit

Status: Accepted for `makoto-protocol` v0.1

`MissionCampaignPermit` is the swarm-level authorization object. It bounds:

- tenant and commander identity
- campaign objective
- allowed agent roles
- maximum parallel agents
- maximum work orders
- global risk budget
- escalation rules
- human approval state
- policy hash
- expiry
- signature

The permit does not execute work. It authorizes issuance of signed work orders
inside a bounded campaign.

