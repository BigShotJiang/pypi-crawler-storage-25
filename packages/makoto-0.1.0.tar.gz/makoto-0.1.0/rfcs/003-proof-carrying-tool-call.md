# RFC 003: Proof-Carrying Tool Call

Status: Accepted for `makoto-protocol` v0.1

`ProofCarryingToolCall` is the authorization packet a tool verifies before it
executes. It binds:

- tool name
- hash of tool input
- campaign permit
- work order
- agent identity
- policy decision
- runtime attestation flag
- remaining risk budget
- signature

The OSS decorator `@protected_tool(...)` demonstrates this pattern locally.
Production enforcement belongs in the commercial gateway and MCP tool proxy.

