# Contributing

MAKOTO keeps the open-source surface small and stable:

- protocol schemas
- canonical JSON and hashing
- local verifier
- basic SDK
- local SQLite development ledger
- examples and tests

Enterprise enforcement, policy engines, swarm routing, MCP proxying, dashboards,
causal learning, and regulated deployment templates are not part of this OSS
package.

## Compatibility

Before a `1.0.0` release, fields may change. After `1.0.0`:

- optional fields can be added in minor versions
- breaking schema changes require a major version
- public schema changes should go through an RFC

## Testing

```bash
python3 -m unittest discover -s tests -v
```

