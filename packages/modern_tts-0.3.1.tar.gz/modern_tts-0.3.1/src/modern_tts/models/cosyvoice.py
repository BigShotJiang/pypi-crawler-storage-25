"""CosyVoice adapter (Alibaba / FunAudioLLM).

Models:
    - cosyvoice-300m: base model (zero-shot voice cloning)
    - cosyvoice-300m-sft: supervised fine-tuned (built-in speaker voices)
    - cosyvoice-300m-instruct: instruction-based control

References:
    - https://github.com/FunAudioLLM/CosyVoice
    - https://huggingface.co/FunAudioLLM/CosyVoice-300M

Note:
    CosyVoice-300M (base) is a zero-shot voice-cloning model requiring
    reference audio. CosyVoice-300M-SFT has built-in speaker voices.

Requirements (all auto-installed on first use):
    - Official CosyVoice repository (auto-cloned)
    - Model weights from HuggingFace (auto-downloaded)
    - Python dependencies: torch, torchaudio, etc. (auto-installed)
"""

from __future__ import annotations

import os
import subprocess
from pathlib import Path
from typing import Any

import numpy as np

from modern_tts.core.base import TTSModel
from modern_tts.core.config import BackendConfig, ModelConfig
from modern_tts.core.hf_hub import get_hf_model_path
from modern_tts.core.registry import register_model
from modern_tts.core.types import AudioOutput, TTSResult, TextInput


class _CosyVoiceBase(TTSModel):
    """Shared base for all CosyVoice variants."""

    MODEL_CARD = "https://huggingface.co/FunAudioLLM/CosyVoice-300M"
    SUPPORTED_LANGUAGES = {"zh", "en", "yue", "ja", "ko", "auto", "multi"}
    SUPPORTED_MODES = {"speak", "clone"}
    REQUIREMENTS = ["torch", "torchaudio"]
    DEFAULT_SAMPLE_RATE = 22050

    HF_PATH = "FunAudioLLM/CosyVoice-300M"

    def __init__(
        self,
        config: ModelConfig,
        backend: BackendConfig | None = None,
    ) -> None:
        super().__init__(config, backend)
        self._repo_path: Path | None = None
        self._model_path: Path | None = None

    def _check_deps(self) -> None:
        """Verify that upstream CosyVoice modules are importable."""
        import sys

        try:
            from cosyvoice.cli.cosyvoice import AutoModel  # noqa: F401
            return
        except (ImportError, ValueError):
            pass

        repo_path = (
            self.config.extra.get("cosyvoice_repo_path")
            or os.environ.get("COSYVOICE_REPO_PATH")
        )
        if repo_path:
            p = str(Path(repo_path).resolve())
            if p not in sys.path:
                sys.path.insert(0, p)
            matcha = Path(repo_path) / "third_party" / "Matcha-TTS"
            if matcha.exists() and str(matcha) not in sys.path:
                sys.path.insert(0, str(matcha))
            try:
                from cosyvoice.cli.cosyvoice import AutoModel  # noqa: F401
                return
            except (ImportError, ValueError):
                pass

        from modern_tts.core.repo_manager import ensure_repo, inject_repo_path

        repo_root = ensure_repo(
            "https://github.com/FunAudioLLM/CosyVoice.git",
            repo_name="CosyVoice",
        )
        self._init_submodules(repo_root)
        inject_repo_path(repo_root)

        matcha = repo_root / "third_party" / "Matcha-TTS"
        if matcha.exists():
            inject_repo_path(matcha)

        from modern_tts.utils.auto_install import ensure_packages

        ensure_packages(["torch", "torchaudio"])
        ensure_packages([
            "conformer", "diffusers", "grpcio", "grpcio-tools",
            "hydra-core", "hyperpyyaml", "lightning",
            "onnxruntime", "openai-whisper", "protobuf",
            "pydantic", "rich", "soundfile", "tensorboard",
            "wget",
        ], skip_on_failure=True)
        ensure_packages(["WeTextProcessing"], skip_on_failure=True)

        from cosyvoice.cli.cosyvoice import AutoModel  # noqa: F401

    @staticmethod
    def _init_submodules(repo_root: Path) -> None:
        """Initialize git submodules (third_party/Matcha-TTS)."""
        matcha = repo_root / "third_party" / "Matcha-TTS"
        if matcha.exists() and any(matcha.iterdir()):
            return
        try:
            subprocess.run(
                ["git", "submodule", "update", "--init", "--recursive"],
                cwd=str(repo_root),
                check=True, capture_output=True, text=True, timeout=120,
            )
        except (subprocess.CalledProcessError, FileNotFoundError, subprocess.TimeoutExpired):
            pass

    def load(self) -> None:
        self._check_deps()

        from cosyvoice.cli.cosyvoice import AutoModel

        self._model_path = get_hf_model_path(
            self.HF_PATH,
            model_path=self.config.model_path,
        )

        self._model = AutoModel(model_dir=str(self._model_path))
        self._is_loaded = True

    def synthesize(self, text: TextInput, **kwargs: Any) -> TTSResult:
        default_ref = self.config.extra.get("default_reference_audio")
        ref = kwargs.pop("reference_audio", default_ref)
        if ref is None:
            raise RuntimeError(
                "CosyVoice-300M is a zero-shot voice-cloning model and requires "
                "a reference audio. Use task='clone' with reference_audio=..., "
                "or set 'default_reference_audio' in ModelConfig.extra."
            )
        return self.clone(text, reference_audio=ref, **kwargs)

    def clone(
        self,
        text: TextInput,
        reference_audio: "AudioOutput | str | Path",
        **kwargs: Any,
    ) -> TTSResult:
        self._ensure_loaded()

        if isinstance(reference_audio, (str, Path)):
            ref_path = str(reference_audio)
        else:
            ref_path = self._save_temp_audio(reference_audio)

        if not os.path.exists(ref_path):
            raise FileNotFoundError(f"Reference audio not found: {ref_path}")

        import torchaudio

        prompt_text = kwargs.pop("prompt_text", "")
        gen_text = text.get_text()

        prompt_speech, sr = torchaudio.load(ref_path)
        if sr != 16000:
            prompt_speech = torchaudio.functional.resample(prompt_speech, sr, 16000)

        chunks = []
        for result in self._model.inference_zero_shot(
            gen_text, prompt_text, ref_path, stream=False,
        ):
            chunks.append(result["tts_speech"].squeeze().cpu().numpy())

        if not chunks:
            raise RuntimeError("CosyVoice synthesis returned no audio chunks.")

        audio_data = np.concatenate(chunks)
        audio_data = np.clip(audio_data, -1.0, 1.0).astype(np.float32)

        return TTSResult(
            audio=AudioOutput(
                waveform=audio_data,
                sample_rate=self._model.sample_rate,
            ),
            text=gen_text,
            language=text.language,
            model_id=self.model_id,
        )

    def unload(self) -> None:
        self._repo_path = None
        self._model_path = None
        super().unload()


@register_model("cosyvoice-300m")
class CosyVoice300M(_CosyVoiceBase):
    """CosyVoice 300M: zero-shot neural TTS with voice cloning."""

    HF_PATH = "FunAudioLLM/CosyVoice-300M"

    @property
    def model_id(self) -> str:
        return "cosyvoice-300m"


@register_model("cosyvoice-300m-sft")
class CosyVoice300MSFT(_CosyVoiceBase):
    """CosyVoice 300M SFT: supervised fine-tuned with built-in speaker voices."""

    HF_PATH = "FunAudioLLM/CosyVoice-300M-SFT"
    SUPPORTED_MODES = {"speak", "clone", "emotion", "style"}

    @property
    def model_id(self) -> str:
        return "cosyvoice-300m-sft"

    def synthesize(self, text: TextInput, **kwargs: Any) -> TTSResult:
        self._ensure_loaded()

        spk_id = kwargs.pop("spk_id", kwargs.pop("speaker", "中文女"))
        gen_text = text.get_text()

        chunks = []
        for result in self._model.inference_sft(gen_text, spk_id, stream=False):
            chunks.append(result["tts_speech"].squeeze().cpu().numpy())

        if not chunks:
            raise RuntimeError("CosyVoice SFT synthesis returned no audio chunks.")

        audio_data = np.concatenate(chunks)
        audio_data = np.clip(audio_data, -1.0, 1.0).astype(np.float32)

        return TTSResult(
            audio=AudioOutput(
                waveform=audio_data,
                sample_rate=self._model.sample_rate,
            ),
            text=gen_text,
            language=text.language,
            model_id=self.model_id,
        )


@register_model("cosyvoice-300m-instruct")
class CosyVoice300MInstruct(_CosyVoiceBase):
    """CosyVoice 300M Instruct: instruction-based control variant."""

    HF_PATH = "FunAudioLLM/CosyVoice-300M-Instruct"
    SUPPORTED_MODES = {"speak", "clone", "emotion", "style"}

    @property
    def model_id(self) -> str:
        return "cosyvoice-300m-instruct"

    def synthesize(self, text: TextInput, **kwargs: Any) -> TTSResult:
        self._ensure_loaded()

        spk_id = kwargs.pop("spk_id", kwargs.pop("speaker", "中文女"))
        instruct_text = kwargs.pop("instruct_text", "")
        gen_text = text.get_text()

        if instruct_text:
            chunks = []
            for result in self._model.inference_instruct(
                gen_text, spk_id, instruct_text, stream=False,
            ):
                chunks.append(result["tts_speech"].squeeze().cpu().numpy())
        else:
            chunks = []
            for result in self._model.inference_sft(gen_text, spk_id, stream=False):
                chunks.append(result["tts_speech"].squeeze().cpu().numpy())

        if not chunks:
            raise RuntimeError("CosyVoice Instruct synthesis returned no audio chunks.")

        audio_data = np.concatenate(chunks)
        audio_data = np.clip(audio_data, -1.0, 1.0).astype(np.float32)

        return TTSResult(
            audio=AudioOutput(
                waveform=audio_data,
                sample_rate=self._model.sample_rate,
            ),
            text=gen_text,
            language=text.language,
            model_id=self.model_id,
        )
