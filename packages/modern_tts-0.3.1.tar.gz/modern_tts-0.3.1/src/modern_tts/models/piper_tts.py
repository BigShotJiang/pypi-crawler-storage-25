"""Piper-TTS adapter (Rhasspy).

Models:
    - piper-tts: lightweight, fast ONNX-based TTS
    - Supports 30+ languages via voice models

References:
    - https://github.com/rhasspy/piper
    - https://huggingface.co/rhasspy/piper-voices

Requirements (auto-installed on first use):
    - piper-tts package (auto-installed)
    - Voice model files (auto-downloaded from HuggingFace)
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

from modern_tts.core.base import TTSModel
from modern_tts.core.config import BackendConfig, ModelConfig
from modern_tts.core.registry import register_model
from modern_tts.core.types import AudioOutput, TTSResult, TextInput

_DEFAULT_VOICE = "zh_CN-huayan-medium"

_VOICE_URL_MAP: dict[str, str] = {
    "zh_CN-huayan-medium": "zh/zh_CN/huayan/medium",
    "zh_CN-huayan-x_low": "zh/zh_CN/huayan/x_low",
    "en_US-lessac-medium": "en/en_US/lessac/medium",
    "en_US-amy-medium": "en/en_US/amy/medium",
    "en_GB-alba-medium": "en/en_GB/alba/medium",
    "ja_JP-takumi-medium": "ja/ja_JP/takumi/medium",
    "de_DE-thorsten-medium": "de/de_DE/thorsten/medium",
    "fr_FR-siwis-medium": "fr/fr_FR/siwis/medium",
    "es_ES-sharvard-medium": "es/es_ES/sharvard/medium",
    "ko_KR-kss-medium": "ko/ko_KR/kss/medium",
    "ru_RU-irina-medium": "ru/ru_RU/irina/medium",
}


def _check_deps() -> None:
    try:
        import piper  # noqa: F401
    except ImportError:
        from modern_tts.utils.auto_install import ensure_packages

        ensure_packages(["piper-tts", "onnxruntime"])
        import piper  # noqa: F401


def _ensure_voice_downloaded(voice_name: str) -> tuple[str, str]:
    """Download a Piper voice model if not already cached."""
    from modern_tts.utils.auto_install import ensure_packages

    ensure_packages(["huggingface_hub"])
    from huggingface_hub import hf_hub_download

    url_path = _VOICE_URL_MAP.get(voice_name)
    if not url_path:
        raise ValueError(
            f"Unknown Piper voice: {voice_name}. "
            f"Available voices: {', '.join(sorted(_VOICE_URL_MAP.keys()))}. "
            f"Or provide a local model_path."
        )

    print(f"[piper-tts] Downloading voice model: {voice_name} ...")
    onnx_path = hf_hub_download(
        repo_id="rhasspy/piper-voices",
        filename=f"{url_path}/{voice_name}.onnx",
    )
    json_path = hf_hub_download(
        repo_id="rhasspy/piper-voices",
        filename=f"{url_path}/{voice_name}.onnx.json",
    )

    return onnx_path, json_path


@register_model("piper-tts")
class PiperTTS(TTSModel):
    """Piper-TTS: lightweight ONNX-based TTS optimized for edge devices.

    Supports 30+ languages via downloadable voice models.
    Auto-downloads voice model on first use.
    """

    MODEL_CARD = "https://github.com/rhasspy/piper"
    SUPPORTED_LANGUAGES = {
        "zh", "en", "de", "es", "fr", "it", "nl", "pl", "pt",
        "ru", "ja", "ko", "ar", "hi", "auto", "multi"
    }
    SUPPORTED_MODES = {"speak"}
    REQUIREMENTS = ["onnxruntime", "piper-tts"]
    DEFAULT_SAMPLE_RATE = 22050

    def __init__(
        self,
        config: ModelConfig,
        backend: BackendConfig | None = None,
    ) -> None:
        super().__init__(config, backend)

    @property
    def model_id(self) -> str:
        return "piper-tts"

    def load(self) -> None:
        _check_deps()
        from piper import PiperVoice

        model_path = self.config.model_path
        if model_path and os.path.exists(str(model_path)):
            onnx_path = str(model_path)
            json_path = onnx_path + ".json"
        else:
            voice_name = self.config.extra.get("voice", _DEFAULT_VOICE)
            onnx_path, json_path = _ensure_voice_downloaded(voice_name)

        self._model = PiperVoice.load(onnx_path, json_path)
        self._is_loaded = True

    def synthesize(self, text: TextInput, **kwargs: Any) -> TTSResult:
        self._ensure_loaded()
        import numpy as np

        chunks = list(self._model.synthesize(text.get_text()))
        if not chunks:
            waveform = np.array([], dtype=np.float32)
            sr = self._model.config.sample_rate
        else:
            audio_parts = [c.audio_float_array for c in chunks]
            waveform = np.concatenate(audio_parts).astype(np.float32)
            sr = chunks[0].sample_rate

        return TTSResult(
            audio=AudioOutput(
                waveform=waveform,
                sample_rate=sr,
            ),
            text=text.get_text(),
            language=text.language or "zh",
            model_id=self.model_id,
        )
