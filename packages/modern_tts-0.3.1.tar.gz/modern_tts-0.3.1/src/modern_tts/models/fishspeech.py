"""Fish Speech adapter (Fish Audio).

Models:
    - fishspeech-1.5: multilingual TTS with voice cloning

References:
    - https://github.com/fishaudio/fish-speech
    - https://huggingface.co/fishaudio/fish-speech-1.5

Note:
    Fish Speech uses a Dual-AR architecture for high-quality TTS.
    The official repository is auto-cloned and dependencies auto-installed.

Requirements (auto-installed on first use):
    - Official fish-speech repository (auto-cloned)
    - Model weights from HuggingFace (auto-downloaded)
    - Python dependencies: torch, torchaudio, etc. (auto-installed)
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import numpy as np

from modern_tts.core.base import TTSModel
from modern_tts.core.config import BackendConfig, ModelConfig
from modern_tts.core.registry import register_model
from modern_tts.core.types import AudioOutput, TTSResult, TextInput


@register_model("fishspeech-1.5")
class FishSpeech15(TTSModel):
    """Fish Speech 1.5: multilingual TTS with high-quality voice cloning."""

    MODEL_CARD = "https://huggingface.co/fishaudio/fish-speech-1.5"
    SUPPORTED_LANGUAGES = {"zh", "en", "ja", "ko", "auto", "multi"}
    SUPPORTED_MODES = {"speak", "clone", "emotion"}
    REQUIREMENTS = ["torch", "torchaudio"]
    DEFAULT_SAMPLE_RATE = 44100

    HF_PATH = "fishaudio/fish-speech-1.5"

    def __init__(
        self,
        config: ModelConfig,
        backend: BackendConfig | None = None,
    ) -> None:
        super().__init__(config, backend)
        self._repo_path: Path | None = None

    @property
    def model_id(self) -> str:
        return "fishspeech-1.5"

    def _check_deps(self) -> None:
        """Auto-clone fish-speech repo and install dependencies."""
        import sys

        try:
            import fish_speech  # noqa: F401
            return
        except ImportError:
            pass

        repo_path = (
            self.config.extra.get("fishspeech_repo_path")
            or os.environ.get("FISHSPEECH_REPO_PATH")
        )
        if repo_path:
            p = str(Path(repo_path).resolve())
            if p not in sys.path:
                sys.path.insert(0, p)
            self._repo_path = Path(repo_path).resolve()
            try:
                import fish_speech  # noqa: F401
                return
            except ImportError:
                pass

        from modern_tts.core.repo_manager import ensure_repo, inject_repo_path

        repo_root = ensure_repo(
            "https://github.com/fishaudio/fish-speech.git",
            repo_name="fish-speech",
        )
        inject_repo_path(repo_root)
        self._repo_path = repo_root

        from modern_tts.utils.auto_install import ensure_packages

        ensure_packages(["torch", "torchaudio"])
        ensure_packages([
            "transformers", "soundfile", "librosa",
            "loguru", "natsort", "numpy",
        ], skip_on_failure=True)

        import fish_speech  # noqa: F401

    def load(self) -> None:
        self._check_deps()

        from modern_tts.core.hf_hub import get_hf_model_path

        model_path = get_hf_model_path(
            self.HF_PATH,
            model_path=self.config.model_path,
        )

        device = self._resolve_device()

        try:
            from fish_speech.inference_engine import TTSInferenceEngine

            self._model = TTSInferenceEngine(
                model_dir=str(model_path),
                device=device,
            )
        except (ImportError, AttributeError):
            from fish_speech.inference_engine.vq_manager import VQManager

            self._model = VQManager(
                model_dir=str(model_path),
                device=device,
            )

        self._is_loaded = True

    def synthesize(self, text: TextInput, **kwargs: Any) -> TTSResult:
        default_ref = self.config.extra.get("default_reference_audio")
        ref = kwargs.pop("reference_audio", default_ref)
        if ref is None:
            raise RuntimeError(
                "Fish Speech requires a reference audio for synthesis. "
                "Use task='clone' with reference_audio=..., or set "
                "'default_reference_audio' in ModelConfig.extra."
            )
        return self.clone(text, reference_audio=ref, **kwargs)

    def clone(
        self,
        text: TextInput,
        reference_audio: "AudioOutput | str | Path",
        **kwargs: Any,
    ) -> TTSResult:
        self._ensure_loaded()

        if isinstance(reference_audio, (str, Path)):
            ref_path = str(reference_audio)
        else:
            ref_path = self._save_temp_audio(reference_audio)

        if not os.path.exists(ref_path):
            raise FileNotFoundError(f"Reference audio not found: {ref_path}")

        gen_text = text.get_text()

        result = self._model.infer(
            text=gen_text,
            reference_audio=ref_path,
            **{k: v for k, v in kwargs.items() if k not in ("language", "task")},
        )

        if isinstance(result, tuple):
            sr, audio_data = result
        else:
            audio_data = result.squeeze()
            sr = self.DEFAULT_SAMPLE_RATE

        if not isinstance(audio_data, np.ndarray):
            audio_data = np.array(audio_data)
        waveform = audio_data.astype(np.float32)
        if waveform.max() > 1.0:
            waveform = waveform / 32767.0

        return TTSResult(
            audio=AudioOutput(
                waveform=waveform,
                sample_rate=sr,
            ),
            text=gen_text,
            language=text.language,
            model_id=self.model_id,
        )

    def unload(self) -> None:
        self._repo_path = None
        super().unload()
