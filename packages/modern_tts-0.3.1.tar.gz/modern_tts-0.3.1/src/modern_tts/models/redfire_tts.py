"""RedFire-TTS adapter (Xiaohongshu / FireRedTeam).

Models:
    - redfire-tts: high-quality Chinese/English neural TTS with voice cloning

References:
    - https://github.com/FireRedTeam/FireRedTTS
    - https://huggingface.co/FireRedTeam/FireRedTTS-1S

Note:
    FireRedTTS-1S is a zero-shot voice-cloning model. It always requires a
    reference audio prompt. Use ``task="clone"`` (or ``clone()``) and
    provide ``reference_audio``.

Requirements (all auto-installed on first use):
    - Official FireRedTTS repository (auto-cloned)
    - Model weights from HuggingFace (auto-downloaded)
    - Python dependencies: torch, fairseq, transformers, etc. (auto-installed)
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import numpy as np

from modern_tts.core.base import TTSModel
from modern_tts.core.config import BackendConfig, ModelConfig
from modern_tts.core.hf_hub import get_hf_model_path
from modern_tts.core.registry import register_model
from modern_tts.core.types import AudioOutput, TTSResult, TextInput


@register_model("redfire-tts")
class RedFireTTS(TTSModel):
    """RedFire-TTS: high-quality Chinese/English neural TTS from FireRedTeam."""

    MODEL_CARD = "https://huggingface.co/FireRedTeam/FireRedTTS-1S"
    SUPPORTED_LANGUAGES = {"zh", "en", "auto"}
    SUPPORTED_MODES = {"speak", "clone"}
    REQUIREMENTS = [
        "torch", "torchaudio", "fairseq", "transformers",
        "diffusers", "librosa", "soundfile", "einops",
        "tiktoken", "inflect", "sentencex",
    ]
    DEFAULT_SAMPLE_RATE = 24000

    HF_PATH = "FireRedTeam/FireRedTTS-1S"

    def __init__(
        self,
        config: ModelConfig,
        backend: BackendConfig | None = None,
    ) -> None:
        super().__init__(config, backend)
        self._repo_path: Path | None = None
        self._model_path: Path | None = None

    @property
    def model_id(self) -> str:
        return "redfire-tts"

    def _check_deps(self) -> None:
        """Verify that the upstream ``fireredtts`` package is importable.

        Automatically clones the official repository, installs all pip
        dependencies, and injects the repo into ``sys.path``.
        """
        import sys

        self._patch_dataclass_mutable_check()
        try:
            self._check_deps_inner()
        finally:
            self._unpatch_dataclass_mutable_check()

    def _check_deps_inner(self) -> None:
        import sys

        try:
            import fireredtts.models.fireredtts  # noqa: F401
            return
        except (ImportError, ValueError):
            pass

        # 1. Try manual override
        repo_path = (
            self.config.extra.get("redfire_tts_repo_path")
            or os.environ.get("REDFIRE_TTS_REPO_PATH")
        )
        if repo_path:
            p = str(Path(repo_path).resolve())
            if p not in sys.path:
                sys.path.insert(0, p)
            try:
                import fireredtts.models.fireredtts  # noqa: F401
                return
            except (ImportError, ValueError):
                pass

        # 2. Auto-clone the repository
        from modern_tts.core.repo_manager import ensure_repo, inject_repo_path

        repo_root = ensure_repo(
            "https://github.com/FireRedTeam/FireRedTTS.git",
            repo_name="FireRedTTS",
            branch="fireredtts-1s",
        )
        inject_repo_path(repo_root)

        # 3. Auto-install pip dependencies
        from modern_tts.utils.auto_install import ensure_packages

        ensure_packages(["torch", "torchaudio"])
        ensure_packages([
            "diffusers", "librosa", "soundfile", "einops",
            "transformers>=4.40", "tiktoken", "inflect",
            "lingua-language-detector", "sentencex", "regex",
        ])
        failed = ensure_packages(["WeTextProcessing"], skip_on_failure=True)
        # fairseq==0.12.2 pins hydra-core<1.1 which is broken on Python 3.12.
        # Install fairseq without deps, then install compatible versions.
        from modern_tts.utils.auto_install import _is_installed, _pip_install
        if not _is_installed("fairseq"):
            print("[auto-install] Installing fairseq (with compatible deps) ...")
            _pip_install("fairseq", "--no-deps")
            _pip_install("hydra-core>=1.3", "omegaconf>=2.3")
            ensure_packages([
                "bitarray", "portalocker", "sacrebleu", "cython",
            ], skip_on_failure=True)

        # 4. If WeTextProcessing failed, patch normalize.py to make tn optional
        if failed:
            self._patch_normalize(repo_root)

        # 5. Patch LogitsWarper → LogitsProcessor (removed in newer transformers)
        self._patch_logits_warper(repo_root)

        # 6. Verify import
        import fireredtts.models.fireredtts  # noqa: F401

    _orig_get_field = None

    @classmethod
    def _patch_dataclass_mutable_check(cls) -> None:
        """Bypass Python 3.12 mutable-default check for fairseq dataclasses.

        fairseq uses ``SomeConfig()`` as default values in @dataclass fields.
        Python 3.12 rejects these because unfrozen dataclass instances have
        ``__hash__ = None``. We temporarily make them hashable so the check
        passes, preserving the original mutable defaults that fairseq's
        ``initialize.py`` reads via ``__dataclass_fields__[k].default``.
        """
        import dataclasses as _dc

        cls._orig_get_field = _dc._get_field
        orig = _dc._get_field

        def _permissive_get_field(klass, a_name, a_type, default_kw_only):
            default = getattr(klass, a_name, _dc.MISSING)
            restore_cls = None
            val = None
            if isinstance(default, _dc.Field):
                val = default.default
            elif default is not _dc.MISSING and not isinstance(default, type):
                val = default
            if (
                val is not None
                and val is not _dc.MISSING
                and getattr(val.__class__, "__hash__", None) is None
            ):
                try:
                    val.__class__.__hash__ = object.__hash__
                    restore_cls = val.__class__
                except TypeError:
                    pass
            try:
                return orig(klass, a_name, a_type, default_kw_only)
            finally:
                if restore_cls is not None:
                    restore_cls.__hash__ = None

        _dc._get_field = _permissive_get_field

    @classmethod
    def _unpatch_dataclass_mutable_check(cls) -> None:
        if cls._orig_get_field is not None:
            import dataclasses as _dc
            _dc._get_field = cls._orig_get_field
            cls._orig_get_field = None

    @staticmethod
    def _patch_normalize(repo_root: Path) -> None:
        """Patch normalize.py to make WeTextProcessing (tn) import optional."""
        norm_file = repo_root / "fireredtts" / "modules" / "text_normalizer" / "normalize.py"
        if not norm_file.exists():
            return

        content = norm_file.read_text(encoding="utf-8")
        if "# patched by modern-tts" in content:
            return

        patched = content.replace(
            "from tn.chinese.normalizer import Normalizer as ZhNormalizer\n"
            "from tn.english.normalizer import Normalizer as EnNormalizer",
            "# patched by modern-tts: make tn optional\n"
            "try:\n"
            "    from tn.chinese.normalizer import Normalizer as ZhNormalizer\n"
            "    from tn.english.normalizer import Normalizer as EnNormalizer\n"
            "except ImportError:\n"
            "    ZhNormalizer = None\n"
            "    EnNormalizer = None",
        )

        # Also patch TextNormalizer.__init__ to handle missing tn
        patched = patched.replace(
            "        self.zh_normalizer = ZhNormalizer()\n"
            "        self.en_normalizer = EnNormalizer()",
            "        self.zh_normalizer = ZhNormalizer() if ZhNormalizer else None\n"
            "        self.en_normalizer = EnNormalizer() if EnNormalizer else None",
        )

        norm_file.write_text(patched, encoding="utf-8")

    @staticmethod
    def _patch_logits_warper(repo_root: Path) -> None:
        """Patch acoustic_llm.py for newer transformers compatibility."""
        target = repo_root / "fireredtts" / "modules" / "acoustic_llm" / "acoustic_llm.py"
        if not target.exists():
            return

        content = target.read_text(encoding="utf-8")
        if "# patched by modern-tts" in content:
            return

        patched = content
        patched = patched.replace("LogitsWarper", "LogitsProcessor")
        patched = patched.replace(
            "from transformers.utils.model_parallel_utils import get_device_map, assert_device_map",
            "# patched by modern-tts: removed in newer transformers\n"
            "try:\n"
            "    from transformers.utils.model_parallel_utils import get_device_map, assert_device_map\n"
            "except (ImportError, ModuleNotFoundError):\n"
            "    get_device_map = None\n"
            "    assert_device_map = None",
        )
        target.write_text(patched, encoding="utf-8")

    def _resolve_repo_path(self) -> Path:
        """Resolve the path to the official FireRedTTS repository."""
        repo_path = (
            self.config.extra.get("redfire_tts_repo_path")
            or os.environ.get("REDFIRE_TTS_REPO_PATH")
        )
        if repo_path:
            p = Path(repo_path)
            if p.exists():
                return p.resolve()

        import importlib.util
        spec = importlib.util.find_spec("fireredtts.models.fireredtts")
        if spec and spec.origin:
            return Path(spec.origin).parent.parent.parent.resolve()

        from modern_tts.core.repo_manager import ensure_repo
        return ensure_repo(
            "https://github.com/FireRedTeam/FireRedTTS.git",
            repo_name="FireRedTTS",
            branch="fireredtts-1s",
        )

    def load(self) -> None:
        self._check_deps()

        from fireredtts.models.fireredtts import FireRedTTS as _FireRedTTS

        self._repo_path = self._resolve_repo_path()
        self._model_path = get_hf_model_path(
            self.HF_PATH,
            model_path=self.config.model_path,
        )

        # The HF repo ships a zip; extract if needed
        zip_path = self._model_path / "pretrained_models.zip"
        extracted = self._model_path / "pretrained_models"
        if zip_path.exists() and not extracted.exists():
            import zipfile

            print("[redfire-tts] Extracting pretrained_models.zip ...")
            with zipfile.ZipFile(zip_path, "r") as zf:
                zf.extractall(self._model_path)
        if extracted.exists():
            self._model_path = extracted

        config_path = self._repo_path / "configs" / "config_24k.json"
        if not config_path.exists():
            raise RuntimeError(
                f"config_24k.json not found in {self._repo_path / 'configs'}. "
                f"The repository may be incomplete."
            )

        device = self._resolve_device()

        self._model = _FireRedTTS(
            config_path=str(config_path),
            pretrained_path=str(self._model_path),
            device=device,
        )
        self._is_loaded = True

    def synthesize(self, text: TextInput, **kwargs: Any) -> TTSResult:
        """Synthesize speech.

        FireRedTTS-1S is a zero-shot cloning model; for ``task="speak"`` we
        fall back to cloning if a default reference audio is configured,
        otherwise raise an error directing the user to ``clone()``.
        """
        default_ref = self.config.extra.get("default_reference_audio")
        ref = kwargs.pop("reference_audio", default_ref)
        if ref is None:
            raise RuntimeError(
                "RedFire-TTS is a zero-shot voice-cloning model and requires "
                "a reference audio. Use TTSPipeline with task='clone' and "
                "reference_audio=..., or set 'default_reference_audio' in "
                "ModelConfig.extra."
            )
        return self.clone(text, reference_audio=ref, **kwargs)

    def clone(
        self,
        text: TextInput,
        reference_audio: "AudioOutput | str | Path",
        **kwargs: Any,
    ) -> TTSResult:
        """Clone a voice from reference audio and synthesize text."""
        self._ensure_loaded()

        if isinstance(reference_audio, (str, Path)):
            ref_path = str(reference_audio)
        else:
            ref_path = self._save_temp_audio(reference_audio)

        if not os.path.exists(ref_path):
            raise FileNotFoundError(f"Reference audio not found: {ref_path}")

        prompt_text = kwargs.pop("prompt_text", "")
        lang = text.language or kwargs.pop("lang", "auto")
        use_tn = kwargs.pop("use_tn", False)

        result = self._model.synthesize(
            prompt_wav=ref_path,
            prompt_text=prompt_text,
            text=text.get_text(),
            lang=lang,
            use_tn=use_tn,
        )

        if result is None:
            raise RuntimeError(
                "FireRedTTS synthesis returned None. "
                "This may happen with very long text or incompatible input."
            )

        audio_data = result.squeeze().cpu().numpy()
        audio_data = np.clip(audio_data, -1.0, 1.0).astype(np.float32)

        return TTSResult(
            audio=AudioOutput(
                waveform=audio_data,
                sample_rate=self.DEFAULT_SAMPLE_RATE,
            ),
            text=text.get_text(),
            language=text.language,
            model_id=self.model_id,
        )

    def unload(self) -> None:
        """Release model weights and clear caches."""
        self._repo_path = None
        self._model_path = None
        super().unload()
