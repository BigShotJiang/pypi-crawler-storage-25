"""BuildShield MCP Server — AI cost intelligence for agents."""

__version__ = "0.1.0"
