"""Command line wrappers for BuildShield MCP tools.

The MCP server exposes tools to MCP clients over stdio. These wrappers make the
same offline helpers usable directly from a terminal, which is helpful for
smoke tests and for agent runtimes that cannot call MCP tools yet.
"""

from __future__ import annotations

import argparse
import asyncio
import sys
from collections.abc import Callable, Sequence

from .tools import (
    handle_check_budget,
    handle_check_cost,
    handle_get_pricing,
    handle_log_usage,
    handle_optimize_prompt,
    handle_recommend_model,
)


def _print(result: str) -> None:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    print(result)


def check_cost_main(argv: Sequence[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description="Calculate LLM cost for a model and token counts.")
    parser.add_argument("model", help="Model name, e.g. gpt-4.1 or claude-sonnet-4.6")
    parser.add_argument("input_tokens", type=int, help="Input token count")
    parser.add_argument("output_tokens", type=int, nargs="?", default=0, help="Output token count")
    args = parser.parse_args(argv)
    _print(handle_check_cost(args.model, args.input_tokens, args.output_tokens))


def recommend_model_main(argv: Sequence[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description="Recommend cost-efficient models for a task.")
    parser.add_argument("task", help="Task description, e.g. code review or long document analysis")
    parser.add_argument("--max-cost-per-1m-input", type=float, default=None)
    parser.add_argument("--min-context-tokens", type=int, default=None)
    parser.add_argument("--provider", default=None)
    args = parser.parse_args(argv)
    _print(
        handle_recommend_model(
            task=args.task,
            max_cost_per_1m_input=args.max_cost_per_1m_input,
            min_context_tokens=args.min_context_tokens,
            provider=args.provider,
        )
    )


def get_pricing_main(argv: Sequence[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description="Show BuildShield model pricing.")
    parser.add_argument("model", nargs="?", default=None, help="Optional model to inspect")
    parser.add_argument("--provider", default=None)
    args = parser.parse_args(argv)
    _print(handle_get_pricing(model=args.model, provider=args.provider))


def optimize_prompt_main(argv: Sequence[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description="Compress a prompt with offline rules.")
    parser.add_argument("text", help="Prompt text to optimize")
    parser.add_argument("--aggressiveness", choices=["light", "medium", "heavy"], default="medium")
    args = parser.parse_args(argv)
    _print(handle_optimize_prompt(text=args.text, aggressiveness=args.aggressiveness))


def check_budget_main(argv: Sequence[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description="Check BuildShield budget for an API key.")
    parser.add_argument("--api-key", default=None)
    parser.add_argument("--period", choices=["today", "week", "month"], default="today")
    args = parser.parse_args(argv)
    _print(asyncio.run(handle_check_budget(api_key=args.api_key, period=args.period)))


def log_usage_main(argv: Sequence[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description="Log LLM usage locally and optionally sync it.")
    parser.add_argument("model")
    parser.add_argument("input_tokens", type=int)
    parser.add_argument("output_tokens", type=int)
    parser.add_argument("--api-key", default=None)
    parser.add_argument("--task-description", default=None)
    args = parser.parse_args(argv)
    _print(
        asyncio.run(
            handle_log_usage(
                model=args.model,
                input_tokens=args.input_tokens,
                output_tokens=args.output_tokens,
                api_key=args.api_key,
                task_description=args.task_description,
            )
        )
    )


COMMANDS: dict[str, Callable[[Sequence[str] | None], None]] = {
    "check-cost": check_cost_main,
    "recommend-model": recommend_model_main,
    "get-pricing": get_pricing_main,
    "optimize-prompt": optimize_prompt_main,
    "check-budget": check_budget_main,
    "log-usage": log_usage_main,
}


def main(argv: Sequence[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description="BuildShield MCP utility commands.")
    subparsers = parser.add_subparsers(dest="command", required=True)
    subparsers.add_parser("check-cost", help="Run buildshield_check_cost")
    subparsers.add_parser("recommend-model", help="Run buildshield_recommend_model")
    subparsers.add_parser("get-pricing", help="Run buildshield_get_pricing")
    subparsers.add_parser("optimize-prompt", help="Run buildshield_optimize_prompt")
    subparsers.add_parser("check-budget", help="Run buildshield_check_budget")
    subparsers.add_parser("log-usage", help="Run buildshield_log_usage")

    parsed, rest = parser.parse_known_args(argv)
    COMMANDS[parsed.command](rest)


if __name__ == "__main__":
    main()
