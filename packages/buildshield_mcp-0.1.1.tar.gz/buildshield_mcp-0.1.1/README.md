# buildshield-mcp

MCP server for BuildShield — AI cost intelligence for agents.

## Install

```bash
pip install buildshield-mcp
```

## Configure (Claude Desktop / Cursor)

Add to your MCP config (`~/.config/claude/claude_desktop_config.json`):

```json
{
  "mcpServers": {
    "buildshield": {
      "command": "buildshield-mcp",
      "env": {
        "BUILDSHIELD_API_KEY": "bsk_..."
      }
    }
  }
}
```

Get your API key at [thebuildshield.com/settings](https://thebuildshield.com/settings).

`buildshield-mcp` is the MCP server command. Keep it inside your MCP client
configuration; it waits on stdio and is not meant to print a normal help screen.

## Terminal smoke tests

The package also installs CLI wrappers for the same tool handlers:

```bash
buildshield_check_cost gpt-4.1 50000 10000
buildshield_get_pricing claude-sonnet-4.6
buildshield_recommend_model "code review" --min-context-tokens 200000
```

You can also use the grouped command form:

```bash
buildshield check-cost gpt-4.1 50000 10000
```

## Tools

| Tool | Description | Requires key? |
|------|-------------|---------------|
| `buildshield_check_cost` | Exact cost for model + token count | No — offline |
| `buildshield_recommend_model` | Best models for a task with filters | No — offline |
| `buildshield_get_pricing` | Browse all model pricing | No — offline |
| `buildshield_optimize_prompt` | Rule-based prompt compression (20-40% savings) | No — offline |
| `buildshield_check_budget` | Check remaining budget for your API key | Yes |
| `buildshield_log_usage` | Log usage to your dashboard | Optional |

## Examples

```
"What does claude-sonnet-4.6 cost for 50K input + 10K output tokens?"
→ buildshield_check_cost(model="claude-sonnet-4.6", input_tokens=50000, output_tokens=10000)

"What's the cheapest model with at least 200K context?"
→ buildshield_recommend_model(task="long document analysis", min_context_tokens=200000)

"Compress this system prompt"
→ buildshield_optimize_prompt(text="...", aggressiveness="medium")
```
