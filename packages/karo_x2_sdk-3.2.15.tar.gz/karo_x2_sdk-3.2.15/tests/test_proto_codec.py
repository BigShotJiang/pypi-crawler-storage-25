"""Unit tests for proto_codec — 编解码 round-trip + 错码映射."""
import pytest

from karo_x2_sdk import ErrorCode
from karo_x2_sdk._internal import proto_codec as pc
from karo_x2_sdk._internal.proto_codec import SubscribeRejectReason


def test_encode_handshake_token_roundtrip():
    data = pc.encode_handshake_token(
        request_id=42, sdk_version="2.0.0", client_id="test",
        token=b"\x01\x02\x03",
    )
    assert len(data) > 0


def test_encode_subscribe_with_since_seq():
    data = pc.encode_subscribe(
        request_id=1, topic="robot.state", desired_hz=5.0,
        since_seq=100, history_limit=500,
    )
    assert len(data) > 0


def test_encode_cmd_vel():
    data = pc.encode_cmd_vel(
        request_id=2, linear_x=0.5, linear_y=0.0, angular_z=0.1,
        sequence=10, client_ts_ms=1234567890,
    )
    assert len(data) > 0


def test_encode_emergency_stop_with_reason():
    data = pc.encode_emergency_stop(
        request_id=3, engage=True, reason="test reason",
    )
    assert len(data) > 0


# SdkErrorCode → public ErrorCode mapping
@pytest.mark.parametrize("wire,expected", [
    (0, ErrorCode.OK),                                  # SDK_ERROR_NONE
    (1, ErrorCode.AUTH_FAILED),
    (10, ErrorCode.SESSION_TOKEN_INVALID),
    (20, ErrorCode.CAPABILITY_DENIED),
    (22, ErrorCode.UNSUPPORTED_VERSION),
    (40, ErrorCode.DISCONNECTED),                       # v2 SDK_DISCONNECTED
    (41, ErrorCode.WOULD_DEADLOCK),                     # v2 SDK_WOULD_DEADLOCK
    (901, ErrorCode.CONTROL_E_STOP_ACTIVE),             # CONTROL_REJECTED_ESTOP
    (902, ErrorCode.CONTROL_PUBLISHER_UNAVAILABLE),     # CONTROL_REJECTED_MOTOR_FAULT
    (999, ErrorCode.INTERNAL_ERROR),                    # 未知码
])
def test_map_sdk_error_code(wire, expected):
    assert pc.map_sdk_error_code(wire) == expected


# karo.v1.ErrorCode → public ErrorCode mapping
@pytest.mark.parametrize("wire,expected", [
    (0, ErrorCode.OK),
    (201, ErrorCode.CAPABILITY_DENIED),                 # PERMISSION_DENIED
    (205, ErrorCode.TIMEOUT),                           # DEADLINE_EXCEEDED
    (9300, ErrorCode.CONTROL_E_STOP_ACTIVE),
    (9301, ErrorCode.CONTROL_PUBLISHER_UNAVAILABLE),
    (9302, ErrorCode.CONTROL_INVALID_TWIST),
    (12345, ErrorCode.INTERNAL_ERROR),                  # 未知码
])
def test_map_v1_error_code(wire, expected):
    assert pc.map_v1_error_code(wire) == expected


# SubscribeAck.reject_reason → public ErrorCode
@pytest.mark.parametrize("reason,expected", [
    (SubscribeRejectReason.NONE, ErrorCode.OK),
    (SubscribeRejectReason.TOPIC_NOT_FOUND, ErrorCode.TOPIC_NOT_FOUND),
    (SubscribeRejectReason.CAPABILITY_DENIED, ErrorCode.CAPABILITY_DENIED),
    (SubscribeRejectReason.ALREADY_SUBSCRIBED, ErrorCode.TOPIC_ALREADY_SUBSCRIBED),
    (SubscribeRejectReason.HISTORY_TOO_OLD, ErrorCode.INTERNAL_ERROR),
    (SubscribeRejectReason.REPLAY_NOT_SUPPORTED, ErrorCode.INTERNAL_ERROR),
])
def test_reject_reason_to_error(reason, expected):
    assert pc.reject_reason_to_error(reason) == expected


def test_pem_to_der_empty():
    assert pc.pem_to_der("") == b""


def test_pem_to_der_invalid_raises():
    from karo_x2_sdk import SdkException
    with pytest.raises(SdkException) as exc_info:
        pc.pem_to_der("not a pem")
    assert exc_info.value.code == ErrorCode.AUTH_FAILED


def test_decode_topic_push_extracts_seq():
    # 构造一个最简 SdkTopicPush (用 _pb2 直接)
    from karo_x2_sdk._internal.proto_gen.sdk import session_pb2
    push = session_pb2.SdkTopicPush(
        topic="robot.state", timestamp_ms=12345, seq=42, payload=b"\xff\xfe",
    )
    data = push.SerializeToString()
    decoded = pc.decode_topic_push(data)
    assert decoded is not None
    assert decoded.topic == "robot.state"
    assert decoded.timestamp_ms == 12345
    assert decoded.seq == 42
    assert decoded.payload == b"\xff\xfe"
