# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Internal helper functions for the public API.

This module contains private utility functions that support the public API
but are not intended to be used directly by external consumers.

WARNING: Functions in this module are internal implementation details and
may change without notice. Do not import from this module directly.
"""

from __future__ import annotations

import os

from collections.abc import Callable
from pathlib import Path

import pandas as pd

from snowflake.snowflake_data_validation.configuration.model.table_configuration import (
    TableConfiguration,
)
from snowflake.snowflake_data_validation.connector.connector_base import ConnectorBase
from snowflake.snowflake_data_validation.public.model import (
    DataValidationExceptionError,
    GeneratedQuery,
    QueryExecutionResult,
)
from snowflake.snowflake_data_validation.snowflake.connector.connector_snowflake import (
    ConnectorSnowflake,
)
from snowflake.snowflake_data_validation.utils.constants import (
    Platform,
    ValidationLevel,
)
from snowflake.snowflake_data_validation.utils.helpers.helper_database import (
    HelperDatabase,
)
from snowflake.snowflake_data_validation.utils.helpers.helper_dataframe import (
    HelperDataFrame,
)
from snowflake.snowflake_data_validation.utils.snapshot_validation_statements import (
    CREATE_SNOWFLAKE_FILE_FORMAT_STATEMENT,
    SNAPSHOT_PARQUET_DATA_STATEMENT_FORMAT_SELECT,
)


def execute_query_internal(
    connector: ConnectorBase,
    generated_query: GeneratedQuery,
    platform: Platform,
    is_case_sensitive: bool,
    object_name: str,
    object_id: int,
    result_processor: Callable[[list, bool], pd.DataFrame] | None = None,
) -> QueryExecutionResult:
    """Execute a query with common logic.

    This function contains the shared execution logic used by both
    execute_query and execute_query_from_table_configuration.

    Args:
        connector: The database connector to use for execution.
        generated_query: The query to execute.
        platform: The database platform.
        is_case_sensitive: Whether column names are case-sensitive.
        object_name: The object name for error context.
        object_id: The object ID for error context.
        result_processor: Optional function to convert raw results to DataFrame.

    Returns:
        QueryExecutionResult: The execution result containing the DataFrame.

    Raises:
        DataValidationExceptionError: If query execution fails.

    """
    try:
        raw_result = connector.execute_query(generated_query.query_string)
        if not raw_result:
            dataframe = pd.DataFrame()
        else:
            processor = result_processor or get_default_result_processor(platform)
            dataframe = processor(raw_result, not is_case_sensitive)

        return QueryExecutionResult(dataframe=dataframe)

    except Exception as e:
        raise DataValidationExceptionError(
            message=str(e),
            platform=platform.value,
            object_name=object_name,
            object_id=object_id,
        ) from e


def get_default_result_processor(
    platform: Platform,
) -> Callable[[list, bool], pd.DataFrame]:
    """Return a platform-appropriate result processor.

    Args:
        platform: The database platform.

    Returns:
        A callable that converts raw query results to a DataFrame.

    """
    if platform == Platform.SNOWFLAKE:
        return lambda result, _: pd.DataFrame(result)
    else:

        def _process_generic(result: list, _: bool) -> pd.DataFrame:
            columns = [col.upper() for col in list(result[0])] if result else []
            rows = [list(row) for row in result[1]] if len(result) > 1 else []
            return pd.DataFrame(rows, columns=columns)

        return _process_generic


def write_query_to_script(
    generated_query: GeneratedQuery,
    file_path: str,
    append: bool = True,
) -> None:
    """Write a generated query to a script file.

    This function writes a generated SQL query to a file for later execution.
    Used in async execution mode where queries are generated first and executed
    separately (e.g., by a DBA or automated pipeline).

    Args:
        generated_query: The generated query to write.
        file_path: The full path to the output script file.
        append: If True, appends to existing file. If False, overwrites.
            Defaults to True.

    Raises:
        DataValidationExceptionError: If writing fails.

    """
    try:
        directory = os.path.dirname(file_path)
        if directory:
            os.makedirs(directory, exist_ok=True)

        mode = "a" if append else "w"
        with open(file_path, mode, encoding="utf-8") as f:
            f.write(generated_query.query_string)
            f.write("\n")

    except Exception as e:
        raise DataValidationExceptionError(
            message=f"Failed to write query to script: {str(e)}",
            platform="",
            object_name=file_path,
            object_id="",
        ) from e


def build_script_file_path(
    base_directory: str,
    filename_template: str,
    origin: str,
    platform: str,
    timestamp: str,
) -> str:
    """Build a script file path from components.

    This function constructs a full file path for script output files,
    following the naming convention used in async mode.

    Args:
        base_directory: The base output directory for scripts.
        filename_template: Template string with {timestamp}, {origin}, {platform}
            placeholders (e.g., "{origin}_{platform}_schema_{timestamp}.sql").
        origin: The origin identifier (e.g., "source", "target").
        platform: The platform name (e.g., "snowflake", "sqlserver").
        timestamp: The timestamp string for the run.

    Returns:
        str: The full file path.

    """
    filename = filename_template.format(
        timestamp=timestamp,
        origin=origin,
        platform=platform,
    )
    return os.path.join(base_directory, filename)


def get_target_cols(
    table_configuration: TableConfiguration,
    case_sensitive_dict: dict[str, str],
    cols: list[str],
) -> list[str]:
    """
    Resolve the target column names based on column mappings, case sensitivity, and fallback rules.

    The resolution order for each column is as follows:
        1. If the column name exists in table_configuration.column_mappings, use the mapped value.
        2. If not case sensitive and column.upper() exists in column_mappings, use the mapped value.
        3. If the uppercase column name exists in case_sensitive_dict, use the value from case_sensitive_dict.
        4. Use the original column name if case_sensitive_dict is provided, else use the uppercase column name.

    Args:
        table_configuration (TableConfiguration): Contains column mappings and case sensitivity flag.
        case_sensitive_dict (dict[str, str]): Dictionary mapping uppercase column names to their case-sensitive counterparts.
        cols (list[str]): List of source column names to resolve.

    Returns:
        list[str]: List of resolved target column names, in the same order as `cols`.

    """
    res = []
    for col in cols:
        n_col = (
            col if case_sensitive_dict else col.upper()
        )  # default if nothing else found
        if col in table_configuration.column_mappings:
            n_col = table_configuration.column_mappings.get(col)
        elif (
            not table_configuration.is_case_sensitive
            and col.upper() in table_configuration.column_mappings
        ):
            n_col = table_configuration.column_mappings.get(col.upper())
        elif col.upper() in case_sensitive_dict:
            n_col = case_sensitive_dict.get(col.upper())
        res.append(n_col)
    return res


def is_snowflake_stage(path: str) -> bool:
    """Check if the path is a Snowflake stage reference."""
    return path.strip().startswith("@")


def upload_to_stage(connector: ConnectorBase, local_file: str, stage: str) -> str:
    """Upload a local file to a Snowflake stage using PUT command.

    Args:
        connector: The Snowflake connector instance
        local_file: Path to the local file to upload
        stage: The Snowflake stage path (e.g., @my_stage/output/)

    """
    put_command = (
        f"PUT 'file://{local_file}' '{stage}' AUTO_COMPRESS=FALSE OVERWRITE=TRUE"
    )
    connector.execute_statement(put_command)
    file_output = f"{stage}{os.path.basename(local_file)}"
    return file_output


def load_snapshot_dataframe(
    directory: str,
    file_name: str,
    validation_level: ValidationLevel,
    snowflake_stage_connector: ConnectorSnowflake,
) -> pd.DataFrame:
    is_stage = is_snowflake_stage(directory)
    if is_stage:
        dataframe = load_snapshot_dataframe_from_stage(
            stage=directory,
            file_name=file_name,
            validation_level=validation_level,
            snowflake_stage_connector=snowflake_stage_connector,
        )
        return dataframe
    else:
        dataframe = load_snapshot_dataframe_from_local_file(
            directory=directory,
            file_name=file_name,
        )
        return dataframe


def load_snapshot_dataframe_from_local_file(
    directory: str,
    file_name: str,
) -> pd.DataFrame:
    directory_path = Path(directory)
    if not directory_path.is_dir():
        raise ValueError(f"Directory does not exist: {directory}")

    file_path = directory_path / file_name

    if not file_path.is_file():
        raise ValueError(f"Snapshot file does not exist: {file_path}")

    dataframe = pd.read_parquet(file_path)
    return dataframe


def load_snapshot_dataframe_from_stage(
    stage: str,
    file_name: str,
    validation_level: ValidationLevel,
    snowflake_stage_connector: ConnectorSnowflake,
) -> pd.DataFrame:
    normalized_stage = HelperDatabase.normalize_snowflake_stage(stage)
    stage_file = normalized_stage + file_name

    if not file_exists_in_stage(stage_file, snowflake_stage_connector):
        raise ValueError(f"Snapshot file does not exist in stage: {stage_file}")

    select_parquet_data_format = SNAPSHOT_PARQUET_DATA_STATEMENT_FORMAT_SELECT[
        validation_level
    ]
    select_parquet_data_statement = select_parquet_data_format.format(
        stage_file=stage_file
    )
    snowflake_stage_connector.execute_statement(CREATE_SNOWFLAKE_FILE_FORMAT_STATEMENT)
    result = snowflake_stage_connector.execute_query(select_parquet_data_statement)
    dataframe = HelperDataFrame().process_snowflake_query_result_to_dataframe(result)
    return dataframe


def file_exists_in_stage(
    stage_file: str, snowflake_stage_connector: ConnectorSnowflake
) -> bool:
    list_statement = f"LIST {stage_file}"
    result = snowflake_stage_connector.execute_query(list_statement)
    dataframe = HelperDataFrame().process_snowflake_query_result_to_dataframe(result)
    return not dataframe.empty
