import logging

import pandas as pd
import polars as pl

from snowflake.snowflake_data_validation.utils.constants import (
    DIFF_COL_COLUMN_KEY,
    DIFF_COL_ROW_KEY,
    DIFF_COL_SOURCE_VALUE_KEY,
    DIFF_COL_TARGET_VALUE_KEY,
)
from snowflake.snowflake_data_validation.validation.data_validator_base import (
    DataValidatorBase,
)


ROW_INDEX_CONST = "__row_idx__"

LOGGER = logging.getLogger(__name__)


class CellDataValidator(DataValidatorBase):
    """Validator for performing cell-level comparisons between source and target DataFrames."""

    def validate_cell_comparison(
        self,
        object_name: str,
        source_df: pl.DataFrame,
        target_df: pl.DataFrame,
        positional: bool = True,
    ) -> pd.DataFrame:
        """
        Compare source and target DataFrames at the cell level and return differences.

        Uses Polars' unpivot (melt) operation for fully vectorized comparison,
        avoiding Python loops for better performance on large DataFrames.

        Args:
            object_name (str): The name of the object being validated.
            source_df (pl.DataFrame): The source DataFrame.
            target_df (pl.DataFrame): The target DataFrame.
            positional (bool): If True, compare columns by position instead of by name.
                When False, columns are matched by name.
                When True (default), the i-th column in source is compared to the i-th column in target.

        Returns:
            pd.DataFrame: A DataFrame with differences, including column name, row
            index, source value, and target value.

        """
        if source_df.shape != target_df.shape:
            LOGGER.error(
                "Dataframe dimensions mismatch. Skipping cell-level comparison for: %s",
                object_name,
            )
            raise Exception("Dataframe dimensions mismatch.")

        source_df = self._strip_string_columns(source_df)
        target_df = self._strip_string_columns(target_df)

        result_columns = [
            DIFF_COL_ROW_KEY,
            DIFF_COL_COLUMN_KEY,
            DIFF_COL_SOURCE_VALUE_KEY,
            DIFF_COL_TARGET_VALUE_KEY,
        ]

        # For positional comparison, rename target columns to match source columns
        if positional:
            target_df = target_df.rename(
                dict(zip(target_df.columns, source_df.columns, strict=True))
            )

        source_with_idx = source_df.with_row_index(ROW_INDEX_CONST)
        target_with_idx = target_df.with_row_index(ROW_INDEX_CONST)

        source_melted = source_with_idx.unpivot(
            index=ROW_INDEX_CONST,
            variable_name=DIFF_COL_COLUMN_KEY,
            value_name=DIFF_COL_SOURCE_VALUE_KEY,
        )
        target_melted = target_with_idx.unpivot(
            index=ROW_INDEX_CONST,
            variable_name=DIFF_COL_COLUMN_KEY,
            value_name=DIFF_COL_TARGET_VALUE_KEY,
        )

        diff_df = (
            source_melted.join(
                target_melted,
                on=[ROW_INDEX_CONST, DIFF_COL_COLUMN_KEY],
            )
            .filter(
                pl.col(DIFF_COL_SOURCE_VALUE_KEY).ne_missing(
                    pl.col(DIFF_COL_TARGET_VALUE_KEY)
                )
            )
            .rename({ROW_INDEX_CONST: DIFF_COL_ROW_KEY})
            .select(result_columns)
        )

        if diff_df.is_empty():
            LOGGER.info("No cell-level differences found for: %s", object_name)
            return pd.DataFrame(columns=result_columns)

        return diff_df.to_pandas()

    @staticmethod
    def _strip_string_columns(df: pl.DataFrame) -> pl.DataFrame:
        """Strip leading/trailing whitespace from all string columns.

        Fixed-width CHAR types from sources like Teradata are right-padded
        with spaces, while Snowflake trims them.  Stripping before comparison
        avoids false positives caused solely by trailing whitespace.

        Also normalizes ``Object``-typed columns (common when pandas ingests
        VARCHAR from ODBC/native drivers) by casting to Utf8 then stripping.
        """
        str_like = (
            pl.Utf8,
            pl.String,
        )
        exprs = []
        for c in df.columns:
            dt = df[c].dtype
            if dt in str_like:
                exprs.append(pl.col(c).str.strip_chars().alias(c))
            elif dt == pl.Object:
                exprs.append(
                    pl.col(c)
                    .map_elements(
                        lambda v: (
                            str(v).strip()
                            if v is not None and not (isinstance(v, float) and v != v)
                            else v
                        ),
                        return_dtype=pl.Utf8,
                    )
                    .alias(c)
                )
        if not exprs:
            return df
        return df.with_columns(exprs)
