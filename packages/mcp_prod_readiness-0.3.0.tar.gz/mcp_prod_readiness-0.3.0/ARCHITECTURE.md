# Architecture: mcp-prod-readiness

Comprehensive system design, tool specifications, and data flow documentation.

---

## System Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────────────┐
│                           User / CI-CD Pipeline                         │
│                      (HTTP, CLI, or MCP Protocol)                      │
└──────────────────────────────┬──────────────────────────────────────────┘
                               │
                    ┌──────────▼──────────┐
                    │  FastMCP Server     │
                    │  (Python 3.10)      │
                    │  Port 8000          │
                    └──────────┬──────────┘
                               │
              ┌────────────────┼────────────────┐
              │                │                │
              ▼                ▼                ▼
    ┌──────────────────┐ ┌──────────────┐ ┌──────────────────┐
    │  Tool Router &   │ │  Checklist   │ │   AI Handler     │
    │  Classifier      │ │  Loader &    │ │  (when direct    │
    │  (Go binary)     │ │  Validator   │ │   path is NO)    │
    │                  │ │              │ │                  │
    │  - Query type    │ │  - YAML      │ │  - Claude API    │
    │  - Complexity    │ │    parsing   │ │  - Orchestrate   │
    │  - Route decision│ │  - Schema    │ │    multi-check   │
    │                  │ │    validate  │ │    audits        │
    └────────┬─────────┘ └──────────────┘ └──────────────────┘
             │
             │ ┌──────────────────────────────────────────────────┐
             │ │  DIRECT PATH (No AI - 80% of queries)           │
             │ │                                                  │
             ├─┼──────────────────────────────────────────────────┤
             │ │  Go Backend Service                              │
             │ │  (stateless, scales horizontally)                │
             │ │                                                  │
             │ │  ┌────────────────────────────────────────────┐  │
             │ │  │ 1. Kubernetes Audit Tools (8 tools)      │  │
             │ │  │    - audit_resource_limits                │  │
             │ │  │    - audit_probes                         │  │
             │ │  │    - audit_pdb                            │  │
             │ │  │    - audit_rbac_scope                     │  │
             │ │  │    - audit_network_policies               │  │
             │ │  │    - audit_security_context               │  │
             │ │  │    - audit_image_tags                     │  │
             │ │  │    - audit_replicas                       │  │
             │ │  └────────────────────────────────────────────┘  │
             │ │  ┌────────────────────────────────────────────┐  │
             │ │  │ 2. Observability Audit Tools (4 tools)   │  │
             │ │  │    - audit_metrics_instrumentation        │  │
             │ │  │    - audit_alert_rules                    │  │
             │ │  │    - audit_log_pipeline                   │  │
             │ │  │    - audit_dashboards                     │  │
             │ │  └────────────────────────────────────────────┘  │
             │ │  ┌────────────────────────────────────────────┐  │
             │ │  │ 3. Configuration Audit Tools (3 tools)   │  │
             │ │  │    - audit_hpa_config                     │  │
             │ │  │    - audit_ingress_config                 │  │
             │ │  │    - audit_secrets_management             │  │
             │ │  └────────────────────────────────────────────┘  │
             │ │  ┌────────────────────────────────────────────┐  │
             │ │  │ 4. Smart Check Tools (4 tools)           │  │
             │ │  │    - smart_hpa_check                      │  │
             │ │  │    - smart_probe_check                    │  │
             │ │  │    - smart_alert_check                    │  │
             │ │  │    - smart_resource_check                 │  │
             │ │  └────────────────────────────────────────────┘  │
             │ └──────────────────────────────────────────────────┘
             │                    │
             └────────┬───────────┴───────────┬──────────────────┐
                      │                       │                  │
                      ▼                       ▼                  ▼
            ┌──────────────────┐  ┌──────────────────┐ ┌──────────────────┐
            │  Kubernetes API  │  │  Prometheus      │ │  Grafana / Open- │
            │  (K8s cluster)   │  │  (metrics, time  │ │  Search API      │
            │                  │  │   series data)   │ │  (dashboards,    │
            │  - Pod specs     │  │                  │ │   logs, alerts)  │
            │  - Network Poly. │  │  PromQL:         │ │                  │
            │  - RBAC roles    │  │  - up{}          │ │  - Dashboard     │
            │  - PDB           │  │  - rate()        │ │    existence      │
            │  - HPA config    │  │  - histogram()   │ │  - Alert rules   │
            │  - Deployment    │  │  - predict_cpu() │ │  - Log streams   │
            │                  │  │                  │ │                  │
            └──────────────────┘  └──────────────────┘ └──────────────────┘
```

---

## Hybrid Engine: Classification Rules & Query Routing

### Decision Algorithm

Every incoming query is classified as either **DIRECT** or **AI** before execution:

```
Query → Classifier → Is this a multi-check audit or complex reasoning? 
                     YES: Route to AI
                     NO:  Route to Go backend (DIRECT)
```

### Classification Rules (Decision Tree)

| Query Type | Examples | Classification | Reasoning |
|---|---|---|---|
| Single check existence | "Does X have resource limits?" | DIRECT | One K8s API call, binary result |
| Configuration retrieval | "Get the HPA config for X" | DIRECT | One API call, return struct |
| Metrics existence | "Is X emitting metrics?" | DIRECT | PromQL exists check, ~50ms |
| List by criterion | "List services without network policies" | DIRECT | K8s API filter, array result |
| Restart history | "Get restart count for pod X" | DIRECT | K8s metrics query |
| Alert rule inspection | "List alert rules for service X" | DIRECT | Grafana API query |
| Dashboard existence | "Does X have a dashboard?" | DIRECT | Grafana API search |
| Log stream check | "Is X sending logs to OpenSearch?" | DIRECT | OpenSearch query |
| **Full audit (34 items)** | **"Audit service X"** | **AI** | **Orchestrates 34 checks, synthesizes findings** |
| **Smart HPA check** | **"Is HPA config realistic?"** | **AI** | **Fetches config + 30d traffic, reasons** |
| **Smart probe check** | **"Do probes cause false restarts?"** | **AI** | **Analyzes history + config, assesses** |
| **Smart alert check** | **"Are alert thresholds realistic?"** | **AI** | **Checks history + pattern, judges** |
| **Smart resource check** | **"Are limits tight or loose?"** | **AI** | **Compares limits to P99, reasons** |
| **Comparison audit** | **"Compare readiness A vs B"** | **AI** | **Two audits, comparative reasoning** |
| **Batch audit (N services)** | **"Audit all services"** | **AI** | **Orchestrates N audits, ranks by severity** |

### 12+ Classification Examples

1. **"Does checkout-service have resource limits?"** 
   - Path: DIRECT
   - Tool: `audit_resource_limits`
   - Latency: ~80ms (K8s API call)

2. **"List all services without network policies in production"**
   - Path: DIRECT
   - Tool: `audit_network_policies` (with filter mode)
   - Latency: ~200ms (K8s API + filtering)

3. **"Is checkout-service emitting metrics?"**
   - Path: DIRECT
   - Tool: `audit_metrics_instrumentation`
   - PromQL: `up{job="checkout-service"}`
   - Latency: ~100ms

4. **"Does checkout-service have liveness and readiness probes?"**
   - Path: DIRECT
   - Tool: `audit_probes`
   - Latency: ~80ms

5. **"Get the HPA config for payment-service"**
   - Path: DIRECT
   - Tool: `audit_hpa_config` (retrieval mode)
   - Latency: ~90ms

6. **"Do any pods have :latest image tags?"**
   - Path: DIRECT
   - Tool: `audit_image_tags`
   - Latency: ~150ms

7. **"Are there root containers in production?"**
   - Path: DIRECT
   - Tool: `audit_security_context`
   - Latency: ~100ms

8. **"Run a full production readiness audit on checkout-service"**
   - Path: AI
   - Invokes: All 34 checks via orchestration
   - Latency: 5-15 seconds
   - Output: Prioritized findings report

9. **"Is checkout-service's HPA configuration appropriate for its traffic?"**
   - Path: AI
   - Fetches: HPA config + 30 days Prometheus traffic data
   - Reasons: Peak QPS vs max replicas, average traffic vs target CPU
   - Latency: 3-5 seconds
   - Output: Assessment + recommendations

10. **"Which services have the most aggressive liveness probes?"**
    - Path: AI
    - Fetches: Probe configs + restart history for all services
    - Reasons: Correlates probes with restarts, ranks by false positive rate
    - Latency: 8-12 seconds
    - Output: Ranked list with restart analysis

11. **"Compare production readiness of checkout-service vs payment-service"**
    - Path: AI
    - Runs: Separate audit on each service
    - Reasons: Gap analysis, relative strengths/weaknesses
    - Latency: 10-20 seconds
    - Output: Comparative report

12. **"Audit all services in production namespace; show only critical findings"**
    - Path: AI
    - Runs: Batch audit across all services
    - Filters: Critical severity only
    - Latency: 20-40 seconds (depends on service count)
    - Output: Critical findings across all services

---

## Go Backend: Classifier Pseudocode

```go
package classifier

import (
    "context"
    "strings"
)

type QueryType string

const (
    TypeDirect QueryType = "direct"
    TypeAI     QueryType = "ai"
)

type ClassificationResult struct {
    QueryType    QueryType
    ToolName     string
    Confidence   float64
    Reasoning    string
    EstimatedMs  int
}

// ClassifyQuery routes a user query to either direct or AI path
func ClassifyQuery(ctx context.Context, userQuery string) *ClassificationResult {
    // Tokenize query for keyword matching
    tokens := strings.Fields(strings.ToLower(userQuery))
    
    // Check for AI-triggering keywords and patterns
    aiKeywords := []string{"audit", "compare", "analyze", "assess", "smart", "batch", "all", "which"}
    complexPatterns := []string{
        "full.*audit",
        "is.*appropriate",
        "is.*realistic",
        "compare.*vs",
        "which.*most",
        "all.*services",
    }
    
    // If query is a direct single-check, route to Go backend
    if isDirectQuery(tokens, userQuery) {
        return &ClassificationResult{
            QueryType:   TypeDirect,
            ToolName:    selectDirectTool(tokens),
            Confidence:  0.98,
            EstimatedMs: 50,
        }
    }
    
    // If query requires multi-check orchestration or reasoning, route to AI
    if isAIQuery(tokens, userQuery, complexPatterns) {
        return &ClassificationResult{
            QueryType:   TypeAI,
            Confidence:  0.95,
            EstimatedMs: 3000, // rough estimate
            Reasoning:   "Requires orchestration of multiple checks or comparative reasoning",
        }
    }
    
    // Default to direct (safe fallback)
    return &ClassificationResult{
        QueryType:   TypeDirect,
        ToolName:    "unknown",
        Confidence:  0.70,
        EstimatedMs: 100,
    }
}

func isDirectQuery(tokens []string, query string) bool {
    // Patterns for direct queries:
    // "does X have Y?" → direct
    // "list X without Y" → direct
    // "does X have a/an Y?" → direct
    // "get the Y of X" → direct
    
    for _, pattern := range []string{
        "does .* have",
        "list .* (without|with)",
        "get .* of",
        "show .* for",
        "do.*have",
    } {
        if matchPattern(pattern, query) {
            return true
        }
    }
    
    // Check for audit-related keywords (AI indicators)
    for _, aiKeyword := range []string{"audit", "compare", "analyze", "batch"} {
        for _, token := range tokens {
            if strings.Contains(token, aiKeyword) {
                return false // This is AI, not direct
            }
        }
    }
    
    return false
}

func isAIQuery(tokens []string, query string, patterns []string) bool {
    // If query mentions full audit, multi-service, or reasoning
    aiTriggers := []string{
        "full audit",
        "full.*audit",
        "compare",
        "all services",
        "all.*services",
        "batch",
        "which.*most",
        "is.*realistic",
        "is.*appropriate",
        "is.*correct",
    }
    
    for _, trigger := range aiTriggers {
        if matchPattern(trigger, query) {
            return true
        }
    }
    
    return false
}

func selectDirectTool(tokens []string) string {
    // Based on tokens, select which tool to invoke
    // Examples:
    // "resource limits" → audit_resource_limits
    // "network policies" → audit_network_policies
    // "probes" → audit_probes
    // "image tags" → audit_image_tags
    // "alerts" → audit_alert_rules
    
    if contains(tokens, "resource") {
        return "audit_resource_limits"
    }
    if contains(tokens, "network") {
        return "audit_network_policies"
    }
    if contains(tokens, "probe") || contains(tokens, "liveness") || contains(tokens, "readiness") {
        return "audit_probes"
    }
    if contains(tokens, "image") || contains(tokens, "tag") || contains(tokens, "latest") {
        return "audit_image_tags"
    }
    if contains(tokens, "alert") {
        return "audit_alert_rules"
    }
    if contains(tokens, "rbac") || contains(tokens, "role") {
        return "audit_rbac_scope"
    }
    if contains(tokens, "metric") || contains(tokens, "prometheus") {
        return "audit_metrics_instrumentation"
    }
    if contains(tokens, "dashboard") {
        return "audit_dashboards"
    }
    if contains(tokens, "hpa") || contains(tokens, "scaling") {
        return "audit_hpa_config"
    }
    if contains(tokens, "log") {
        return "audit_log_pipeline"
    }
    if contains(tokens, "pdb") || contains(tokens, "disruption") {
        return "audit_pdb"
    }
    if contains(tokens, "replicas") {
        return "audit_replicas"
    }
    if contains(tokens, "security") || contains(tokens, "root") || contains(tokens, "privilege") {
        return "audit_security_context"
    }
    
    return "unknown"
}

func contains(tokens []string, keyword string) bool {
    for _, t := range tokens {
        if strings.Contains(t, keyword) {
            return true
        }
    }
    return false
}

func matchPattern(pattern string, text string) bool {
    // Simple regex-like matching
    // In production, use regexp package
    return strings.Contains(strings.ToLower(text), strings.ToLower(pattern))
}
```

---

## Tool Groups & Specifications

### Group 1: Kubernetes Audit Tools (8 tools)

#### 1. audit_resource_limits

**Function Signature:**
```go
func (c *K8sClient) AuditResourceLimits(
    ctx context.Context,
    namespace string,
    serviceName string,
) *CheckResult
```

**Parameters:**
- `namespace` (string): Kubernetes namespace
- `serviceName` (string): Service/deployment name

**Returns:**
```go
type CheckResult struct {
    Status                    string  // "pass", "warning", "fail"
    Limits                    map[string]string // {"cpu": "500m", "memory": "512Mi"}
    Requests                  map[string]string
    CurrentP99CPU             string  // from Prometheus
    CurrentP99Memory          string  // from Prometheus
    NamespaceQuotaExceeded    bool
    Message                   string
    RemediationCommand        string
}
```

**Pass Criteria:**
- CPU limits defined and >= 100m
- Memory limits defined and >= 128Mi
- Requests defined and <= limits
- Current P99 usage < 80% of limits

**Warning Criteria:**
- Limits defined but P99 usage > 80% of limits
- Requests not defined
- Limits very high relative to typical usage

**Fail Criteria:**
- No limits defined
- Limits < 50m CPU or < 64Mi memory

**Implementation Notes:**
- Query K8s API: `kubectl get deployment <serviceName> -n <namespace> -o json | jq '.spec.template.spec.containers[].resources'`
- Query Prometheus: `histogram_quantile(0.99, rate(container_cpu_usage_seconds_total{pod=~"<serviceName>.*"}[7d]))`
- Cross-reference with namespace LimitRange

**Remediation Template:**
```yaml
spec:
  template:
    spec:
      containers:
      - name: <container>
        resources:
          limits:
            cpu: <recommended>
            memory: <recommended>
          requests:
            cpu: <80% of limits>
            memory: <80% of limits>
```

---

#### 2. audit_probes

**Function Signature:**
```go
func (c *K8sClient) AuditProbes(
    ctx context.Context,
    namespace string,
    serviceName string,
) *CheckResult
```

**Returns:**
```go
type ProbeCheckResult struct {
    Status               string // "pass", "warning", "fail"
    HasLivenessProbe     bool
    HasReadinessProbe    bool
    HasStartupProbe      bool
    LivenessConfig       ProbeConfig
    ReadinessConfig      ProbeConfig
    StartupConfig        ProbeConfig
    EndpointValidation   bool
    EndpointStatus       int // HTTP response code
    RestartCount         int
    Message              string
    RemediationCommand   string
}

type ProbeConfig struct {
    InitialDelaySeconds int
    TimeoutSeconds      int
    PeriodSeconds       int
    SuccessThreshold    int
    FailureThreshold    int
    HTTPPath            string
    Port                int
}
```

**Pass Criteria:**
- Liveness probe configured with initialDelaySeconds >= 10
- Readiness probe configured with initialDelaySeconds >= 5
- Startup probe configured (optional, but recommended for long startup)
- Probe endpoint returns 200-299 status
- No unexplained restarts in last 7 days

**Warning Criteria:**
- Probes configured but endpoint not responding
- InitialDelaySeconds very low (< 5)
- FailureThreshold very low (< 3)
- Restart count > 2 per day (may indicate aggressive probes)

**Fail Criteria:**
- No liveness probe
- No readiness probe
- Probe endpoint returns error
- Excessive restarts due to probe failures

**Implementation Notes:**
- Query pod spec for probe definitions
- Validate probe endpoint: `curl http://<pod>:<port><path>`
- Query restart history from K8s events and Prometheus: `increase(kube_pod_container_status_restarts_total{pod=~"<serviceName>.*"}[7d])`

**Remediation Template:**
```yaml
spec:
  template:
    spec:
      containers:
      - name: <container>
        livenessProbe:
          httpGet:
            path: /healthz
            port: 8080
          initialDelaySeconds: 15
          periodSeconds: 10
          failureThreshold: 3
        readinessProbe:
          httpGet:
            path: /ready
            port: 8080
          initialDelaySeconds: 5
          periodSeconds: 5
          failureThreshold: 1
```

---

#### 3. audit_pdb

**Function Signature:**
```go
func (c *K8sClient) AuditPDB(
    ctx context.Context,
    namespace string,
    serviceName string,
) *CheckResult
```

**Returns:**
```go
type PDBCheckResult struct {
    Status              string // "pass", "warning", "fail"
    HasPDB              bool
    MinAvailable        int
    MaxUnavailable      int
    ApplicableReplicas  int
    DisruptionsAllowed  int
    IsAppropriate       bool
    Message             string
    RemediationCommand  string
}
```

**Pass Criteria:**
- PDB exists for service
- minAvailable or maxUnavailable is appropriate for replica count
- At least 1 replica remains available during disruptions

**Warning Criteria:**
- PDB exists but minAvailable too low
- PDB too permissive (allows too many disruptions)

**Fail Criteria:**
- No PDB defined
- PDB configuration would allow total downtime

**Remediation Template:**
```yaml
apiVersion: policy/v1
kind: PodDisruptionBudget
metadata:
  name: <serviceName>
spec:
  minAvailable: <N>
  selector:
    matchLabels:
      app: <serviceName>
```

---

#### 4. audit_rbac_scope

**Function Signature:**
```go
func (c *K8sClient) AuditRBACScope(
    ctx context.Context,
    namespace string,
    serviceName string,
) *CheckResult
```

**Returns:**
```go
type RBACCheckResult struct {
    Status               string // "pass", "warning", "fail"
    ServiceAccountExists bool
    ServiceAccountName   string
    IsClusterAdmin       bool
    PermissionScope      string // "cluster", "namespace", "minimal"
    Permissions          []string
    HasExcessPerms       bool
    Message              string
    RemediationCommand   string
}
```

**Pass Criteria:**
- ServiceAccount exists and is used by pod
- RBAC is namespace-scoped (not cluster-wide)
- Permissions are minimal (only what's needed)
- No admin or privileged roles

**Warning Criteria:**
- ServiceAccount has multiple roles (consolidate)
- Wildcard permissions on any resources
- Read on secrets without need

**Fail Criteria:**
- Pod runs as default ServiceAccount
- Cluster-admin role assigned
- No RBAC defined

**Remediation Template:**
```yaml
apiVersion: v1
kind: ServiceAccount
metadata:
  name: <serviceName>
---
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  name: <serviceName>
rules:
- apiGroups: [""]
  resources: ["configmaps"]
  verbs: ["get", "list"]
---
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: <serviceName>
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: Role
  name: <serviceName>
subjects:
- kind: ServiceAccount
  name: <serviceName>
```

---

#### 5. audit_network_policies

**Function Signature:**
```go
func (c *K8sClient) AuditNetworkPolicies(
    ctx context.Context,
    namespace string,
    serviceName string,
    filterMode bool, // if true, return list of services without policies
) *CheckResult
```

**Returns:**
```go
type NetworkPolicyCheckResult struct {
    Status                   string // "pass", "warning", "fail"
    HasNetworkPolicy         bool
    IngressRules             int
    EgressRules              int
    DefaultDeny              bool
    PoliciesApplicable       []string
    PoliciesNotApplicable    []string
    ServicesWithoutPolicies  []string // when filterMode=true
    Message                  string
    RemediationCommand       string
}
```

**Pass Criteria:**
- NetworkPolicy exists
- Default deny ingress and egress rules configured
- Explicit allow rules defined for known dependencies
- Policy is scoped to namespace

**Warning Criteria:**
- NetworkPolicy exists but not comprehensive
- Allows too many sources or destinations
- Default allow (overly permissive)

**Fail Criteria:**
- No NetworkPolicy
- Namespace allows all traffic

**Remediation Template:**
```yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: <serviceName>
spec:
  podSelector:
    matchLabels:
      app: <serviceName>
  policyTypes:
  - Ingress
  - Egress
  ingress:
  - from:
    - podSelector:
        matchLabels:
          app: api-gateway
    ports:
    - protocol: TCP
      port: 8080
  egress:
  - to:
    - podSelector:
        matchLabels:
          app: database
    ports:
    - protocol: TCP
      port: 5432
  - to:
    - namespaceSelector:
        matchLabels:
          name: kube-system
    ports:
    - protocol: UDP
      port: 53
```

---

#### 6. audit_security_context

**Function Signature:**
```go
func (c *K8sClient) AuditSecurityContext(
    ctx context.Context,
    namespace string,
    serviceName string,
) *CheckResult
```

**Returns:**
```go
type SecurityContextCheckResult struct {
    Status                    string // "pass", "warning", "fail"
    RunsAsRoot                bool
    HasReadOnlyRootFilesystem bool
    AllowPrivilegeEscalation  bool
    HasPrivilegedContainer    bool
    HasCapabilities           []string
    ContainersChecked         int
    ViolatingContainers       []string
    Message                   string
    RemediationCommand        string
}
```

**Pass Criteria:**
- All containers run as non-root (runAsNonRoot: true)
- ReadOnlyRootFilesystem: true
- AllowPrivilegeEscalation: false
- No privileged containers
- Minimal capabilities (no NET_ADMIN, SYS_ADMIN, etc.)

**Warning Criteria:**
- Runs as non-root but root fallback allowed
- ReadOnlyRootFilesystem not set
- Some unnecessary capabilities

**Fail Criteria:**
- Any container runs as root
- Privileged containers
- Dangerous capabilities enabled

**Remediation Template:**
```yaml
spec:
  securityContext:
    runAsNonRoot: true
    runAsUser: 1000
    fsGroup: 1000
  containers:
  - name: <container>
    securityContext:
      allowPrivilegeEscalation: false
      readOnlyRootFilesystem: true
      capabilities:
        drop:
        - ALL
    volumeMounts:
    - name: tmp
      mountPath: /tmp
  volumes:
  - name: tmp
    emptyDir: {}
```

---

#### 7. audit_image_tags

**Function Signature:**
```go
func (c *K8sClient) AuditImageTags(
    ctx context.Context,
    namespace string,
    serviceName string,
) *CheckResult
```

**Returns:**
```go
type ImageTagCheckResult struct {
    Status            string // "pass", "warning", "fail"
    ImageCount        int
    UntaggedImages    int
    LatestTagImages   int
    ViolatingImages   []string
    Message           string
    RemediationCommand string
}
```

**Pass Criteria:**
- All images explicitly versioned (no :latest)
- Image SHA256 referenced (optional, but best practice)
- Consistent versioning across replicas

**Warning Criteria:**
- One or two :latest tags (minor issue)

**Fail Criteria:**
- Multiple or critical services using :latest
- No tag at all

**Implementation Notes:**
- Query pod specs for image field
- Parse image string: `repository:tag` or `repository@sha256:...`

**Remediation Template:**
```yaml
spec:
  template:
    spec:
      containers:
      - name: <container>
        image: <repository>:v1.2.3  # instead of :latest
```

---

#### 8. audit_replicas

**Function Signature:**
```go
func (c *K8sClient) AuditReplicas(
    ctx context.Context,
    namespace string,
    serviceName string,
) *CheckResult
```

**Returns:**
```go
type ReplicasCheckResult struct {
    Status           string // "pass", "warning", "fail"
    DesiredReplicas  int
    ReadyReplicas    int
    UpdatedReplicas  int
    AvailableReplicas int
    IsReady          bool
    Message          string
}
```

**Pass Criteria:**
- DesiredReplicas >= 2 (high availability)
- All replicas ready and updated
- No pending or failed pods

**Warning Criteria:**
- Only 1 replica
- Some replicas not ready

**Fail Criteria:**
- 0 replicas
- Severe mismatch between desired and actual

---

### Group 2: Observability Audit Tools (4 tools)

#### 1. audit_metrics_instrumentation

**Function Signature:**
```go
func (c *PrometheusClient) AuditMetricsInstrumentation(
    ctx context.Context,
    namespace string,
    serviceName string,
) *CheckResult
```

**Returns:**
```go
type MetricsCheckResult struct {
    Status           string // "pass", "warning", "fail"
    HasMetrics       bool
    JobName          string
    ActiveSeries     int
    LastScrapedTime  time.Time
    ScrapeInterval   int // seconds
    MetricsFound     []string
    CriticalMetrics  []string // e.g., http_request_duration, errors
    MissingMetrics   []string
    Message          string
}
```

**Pass Criteria:**
- Prometheus scrape job exists for service
- Active series > 10 (indicates real instrumentation)
- Recent scrapes (within last 5 min)
- Key metrics present: http_request_duration, errors, latency, throughput

**Warning Criteria:**
- Few metrics (< 5 active series)
- Stale scrapes (> 5 min old)
- Missing some key metrics

**Fail Criteria:**
- No metrics found
- Scrape job not configured

**Implementation Notes:**
- Query Prometheus: `up{job="<serviceName>"}`
- Query metric families: `HELP` and `TYPE` lines from `/metrics` endpoint
- Count series: `count(up{job="<serviceName>"})`

**Remediation Template:**
```yaml
# In Prometheus config
scrape_configs:
- job_name: '<serviceName>'
  kubernetes_sd_configs:
  - role: pod
    namespaces:
      names: ['<namespace>']
  relabel_configs:
  - source_labels: [__meta_kubernetes_pod_label_app]
    action: keep
    regex: '<serviceName>'
```

---

#### 2. audit_alert_rules

**Function Signature:**
```go
func (c *GrafanaClient) AuditAlertRules(
    ctx context.Context,
    namespace string,
    serviceName string,
) *CheckResult
```

**Returns:**
```go
type AlertRuleCheckResult struct {
    Status           string // "pass", "warning", "fail"
    AlertRuleCount   int
    CriticalAlerts   int
    WarningAlerts    int
    StaleAlerts      int // not fired in 90 days
    RecentFires      int // fired in last 30 days
    Rules            []AlertRule
    Message          string
}

type AlertRule struct {
    Name      string
    Severity  string // "critical", "warning"
    Condition string
    LastFire  time.Time
    IsFresh   bool // fired in last 90 days
}
```

**Pass Criteria:**
- >= 3 alert rules for service
- Mix of critical and warning rules
- Rules have been triggered at least once in 90 days
- Thresholds are realistic

**Warning Criteria:**
- Alert rules never fired (threshold may be too tight)
- Too many alerts (alert fatigue)
- Missing critical scenarios

**Fail Criteria:**
- No alert rules
- All rules are critical with no graduated severity

**Implementation Notes:**
- Query Grafana API: `GET /api/ruler/grafana/rules`
- Check firing history: Query Prometheus `ALERTS_FOR_STATE` or alert history

---

#### 3. audit_log_pipeline

**Function Signature:**
```go
func (c *OpenSearchClient) AuditLogPipeline(
    ctx context.Context,
    namespace string,
    serviceName string,
) *CheckResult
```

**Returns:**
```go
type LogPipelineCheckResult struct {
    Status           string // "pass", "warning", "fail"
    LogsReceived     bool
    IndexExists      bool
    IndexName        string
    DocCount         int
    LatestLog        time.Time
    LogFormat        string // "json", "text", etc.
    IsStructured     bool
    Message          string
}
```

**Pass Criteria:**
- OpenSearch index exists for service
- Recent logs (within last 30 min)
- Logs are structured (JSON) with required fields
- Document count > 0

**Warning Criteria:**
- Logs present but not recent (> 30 min)
- Logs are unstructured

**Fail Criteria:**
- No logs received
- Index doesn't exist

**Implementation Notes:**
- Query OpenSearch: `GET /<index>/_search?size=1&sort=@timestamp:desc`
- Check structured fields: presence of standard fields (timestamp, level, message, service)

---

#### 4. audit_dashboards

**Function Signature:**
```go
func (c *GrafanaClient) AuditDashboards(
    ctx context.Context,
    namespace string,
    serviceName string,
) *CheckResult
```

**Returns:**
```go
type DashboardCheckResult struct {
    Status          string // "pass", "warning", "fail"
    DashboardExists bool
    DashboardID     int
    DashboardURL    string
    PanelCount      int
    EssentialPanels []string // latency, error rate, throughput, etc.
    Message         string
}
```

**Pass Criteria:**
- Dashboard exists for service
- Contains >= 4 essential panels (latency, error rate, throughput, resource usage)

**Warning Criteria:**
- Dashboard exists but incomplete

**Fail Criteria:**
- No dashboard

**Implementation Notes:**
- Query Grafana API: `GET /api/search?query=<serviceName>`
- Get dashboard details: `GET /api/dashboards/uid/<uid>`

---

### Group 3: Configuration Audit Tools (3 tools)

#### 1. audit_hpa_config

**Function Signature:**
```go
func (c *K8sClient) AuditHPAConfig(
    ctx context.Context,
    namespace string,
    serviceName string,
) *CheckResult
```

**Returns:**
```go
type HPACheckResult struct {
    Status             string // "pass", "warning", "fail"
    HasHPA             bool
    MinReplicas        int
    MaxReplicas        int
    TargetCPU          int // percent
    TargetMemory       int // percent
    CurrentReplicas    int
    DesiredReplicas    int
    Message            string
    RemediationCommand string
}
```

**Pass Criteria:**
- HPA configured
- MinReplicas >= 2
- MaxReplicas appropriate for service type
- TargetCPU and TargetMemory are realistic

**Warning Criteria:**
- MinReplicas = 1
- Bounds seem arbitrary

**Fail Criteria:**
- No HPA configured

**Implementation Notes:**
- Query K8s API: `kubectl get hpa <serviceName> -n <namespace> -o json`

---

#### 2. audit_ingress_config

**Function Signature:**
```go
func (c *K8sClient) AuditIngressConfig(
    ctx context.Context,
    namespace string,
    serviceName string,
) *CheckResult
```

**Returns:**
```go
type IngressCheckResult struct {
    Status           string // "pass", "warning", "fail"
    HasIngress       bool
    IngressNames     []string
    TLSConfigured    bool
    HostsConfigured  []string
    Message          string
    RemediationCommand string
}
```

**Pass Criteria:**
- Ingress exists (if service is externally accessible)
- TLS configured with valid cert
- Proper host routing rules

**Warning Criteria:**
- Ingress exists but TLS missing
- Overly permissive routing

**Fail Criteria:**
- Service should be exposed but no Ingress

---

#### 3. audit_secrets_management

**Function Signature:**
```go
func (c *K8sClient) AuditSecretsManagement(
    ctx context.Context,
    namespace string,
    serviceName string,
) *CheckResult
```

**Returns:**
```go
type SecretsCheckResult struct {
    Status              string // "pass", "warning", "fail"
    SecretsUsed         int
    MountedAsFile       int
    MountedAsEnv        int
    PlaintextInEnv      int // secrets mounted as env vars (flag)
    Message             string
    RemediationCommand  string
}
```

**Pass Criteria:**
- Secrets mounted as files (not env vars)
- No plaintext secrets in deployment
- Secrets are actually used by pod

**Warning Criteria:**
- Some secrets mounted as env vars

**Fail Criteria:**
- Plaintext secrets in deployment
- Unused secret mounts

---

### Group 4: Smart Check Tools (4 tools)

These tools go beyond pass/fail by reasoning about configuration appropriateness.

#### 1. smart_hpa_check

**Function Signature:**
```go
func (c *SmartChecker) SmartHPACheck(
    ctx context.Context,
    namespace string,
    serviceName string,
) *SmartCheckResult
```

**Returns:**
```go
type SmartHPACheckResult struct {
    Status                string // "pass", "warning", "critical"
    HPAConfig             HPAConfig
    TrafficAnalysis       TrafficAnalysis
    RecommendedMinReplicas int
    RecommendedMaxReplicas int
    RecommendedTargetCPU   int
    Verdict               string // e.g., "Max replicas too low for observed peak traffic"
    Evidence              []string // e.g., ["Peak QPS 10k observed, max replicas only 5", ...]
    Message               string
}

type TrafficAnalysis struct {
    PeakQPS             int
    AverageQPS          int
    P95Latency          float64
    P99Latency          float64
    ErrorRate           float64
    TrafficTrend        string // "increasing", "stable", "decreasing"
    PeakDay             string // day of week
    PeakHour            string // hour of day
}
```

**Logic:**
1. Fetch HPA config: min, max, targetCPU, targetMemory
2. Query Prometheus for 30 days of traffic: QPS, error rate, latency, CPU usage
3. Find peak traffic day/hour
4. Reason: "If peak traffic is 10k QPS and each replica handles ~2k QPS, we need at least 5 replicas"
5. Compare recommendations to actual config
6. Verdict: "Max replicas (3) insufficient. Recommend 8 to handle peak with 20% headroom"

**Pass Criteria:**
- Config matches recommendations
- MaxReplicas can handle observed peak with 20%+ headroom
- TargetCPU appropriate (typically 60-70%)

**Warning Criteria:**
- MaxReplicas can handle peak but < 20% headroom
- Config is overly conservative (wastes resources)

**Critical Criteria:**
- MaxReplicas insufficient for observed peak
- Will experience throttling under normal peak load

---

#### 2. smart_probe_check

**Function Signature:**
```go
func (c *SmartChecker) SmartProbeCheck(
    ctx context.Context,
    namespace string,
    serviceName string,
) *SmartCheckResult
```

**Returns:**
```go
type SmartProbeCheckResult struct {
    Status              string // "pass", "warning", "critical"
    ProbeConfig         ProbeConfig
    RestartHistory      RestartHistory
    CorrelationScore    float64 // 0.0-1.0: likelihood probes cause restarts
    Verdict             string
    Evidence            []string
    Recommendations     []string
    Message             string
}

type RestartHistory struct {
    Last7DayRestarts    int
    RestartsPerDay      float64
    PeakRestartDay      string
    RestartTiming       []time.Time
    CorrelatesWithProbe bool
}
```

**Logic:**
1. Fetch liveness/readiness probe config: initialDelaySeconds, failureThreshold, periodSeconds
2. Query pod restart history from K8s metrics: `kube_pod_container_status_restarts_total`
3. Analyze timing: Do restarts cluster around times when probes would fail?
4. Calculate correlation: If restart happens N seconds after probe timeout, flag it
5. Verdict: "Liveness probe timeout (15s) with failureThreshold=3 = 45s before kill. Observed 2 restarts/day at 45s intervals. Likely false positives. Recommend: increase initialDelaySeconds to 30"

**Pass Criteria:**
- No unexplained restarts
- Probe configuration is conservative (unlikely to false-trigger)
- InitialDelaySeconds >= 2x worst-case startup time

**Warning Criteria:**
- Occasional restarts (< 1/day) but probe-correlated

**Critical Criteria:**
- Frequent restarts correlated with probe failures
- Probes likely causing false restarts

---

#### 3. smart_alert_check

**Function Signature:**
```go
func (c *SmartChecker) SmartAlertCheck(
    ctx context.Context,
    namespace string,
    serviceName string,
) *SmartCheckResult
```

**Returns:**
```go
type SmartAlertCheckResult struct {
    Status             string // "pass", "warning", "critical"
    AlertRules         []AlertRule
    FiringHistory      []AlertFiring
    StaleRules         []AlertRule // not fired in 90 days
    UnrealisticRules   []AlertRule // threshold disconnected from reality
    Verdict            string
    Evidence           []string
    Recommendations    []string
    Message            string
}

type AlertFiring struct {
    RuleName      string
    FiredAt       time.Time
    ResolvedAt    time.Time
    Duration      time.Duration
}
```

**Logic:**
1. Fetch all alert rules for service
2. Query alert firing history: `ALERTS_FOR_STATE` for last 90 days
3. For each rule: check if fired at least once
4. If not fired: flag as potentially unrealistic threshold
5. For stale rules: query current metrics vs threshold. E.g., rule triggers at "error_rate > 5%" but observed error rate is never > 1%. Threshold is too tight.
6. Verdict: "ErrorRate alert hasn't fired in 90 days but threshold is 5%. Current error rate is 0.1-0.5%. Either threshold is wrong or alert is not useful. Recommend: lower to 2% or reevaluate"

**Pass Criteria:**
- All rules fired at least once in 90 days
- Thresholds are realistic (don't need to be breached to be valid, but make sense)
- Mix of alert severities

**Warning Criteria:**
- Some rules not fired, but thresholds seem reasonable
- Alert fatigue: too many rules, too many fires

**Critical Criteria:**
- Rules with no firings but suspiciously low thresholds
- Threshold clearly disconnected from actual metrics

---

#### 4. smart_resource_check

**Function Signature:**
```go
func (c *SmartChecker) SmartResourceCheck(
    ctx context.Context,
    namespace string,
    serviceName string,
) *SmartCheckResult
```

**Returns:**
```go
type SmartResourceCheckResult struct {
    Status                string // "pass", "warning", "critical"
    LimitsConfig          map[string]string
    UsageAnalysis         UsageAnalysis
    RecommendedLimits     map[string]string
    RecommendedRequests   map[string]string
    Verdict               string
    Evidence              []string
    Recommendations       []string
    Message               string
}

type UsageAnalysis struct {
    P50CPU                string
    P95CPU                string
    P99CPU                string
    P50Memory             string
    P95Memory             string
    P99Memory             string
    PeakCPU               string
    PeakMemory            string
    AnalysisPeriod        string // "7d", "30d", etc.
    TrendCPU              string // "increasing", "stable", "decreasing"
    TrendMemory           string
}
```

**Logic:**
1. Fetch resource limits and requests from deployment
2. Query Prometheus for 7 days of CPU/memory usage: P50, P95, P99, peak
3. Calculate headroom: limit vs P99
4. Verdict: "Limit CPU 500m, P99 usage 450m = 10% headroom. Too tight. Recommend 600m limit. Request 80% of limit = 480m"
5. Or: "Limit CPU 5 cores, P99 usage 200m = 4.8 cores wasted. Recommend 300m limit, 240m request. Save costs"

**Pass Criteria:**
- Limits exist
- P99 usage < 80% of limits (20%+ headroom)
- Requests are 80% of limits
- No resource contention (kernel throttling)

**Warning Criteria:**
- P99 usage 80-90% of limits (tight but acceptable)
- Requests not aligned with limits

**Critical Criteria:**
- P99 usage > 90% of limits (risk of throttling)
- No limits defined
- Limits significantly mismatched with actual usage

---

## Checklist YAML Schema

Each of the 34 items is defined in `config/checklist.yaml`:

```yaml
version: "1.0"
checklist_name: "Production Readiness Audit"
categories:
  - name: "Resource Management"
    description: "Verify resource limits, requests, quotas"
    items:
      - id: "RM-001"
        title: "Resource Limits Defined"
        description: "All containers must have CPU and memory limits"
        category: "Resource Management"
        tool: "audit_resource_limits"
        severity: "critical"
        pass_criteria: "Limits defined and P99 usage < 80%"
        warning_criteria: "Limits defined but P99 usage 80-90%"
        fail_criteria: "No limits or usage > 90%"
        remediation_template: |
          spec:
            containers:
            - name: <container>
              resources:
                limits:
                  cpu: <value>m
                  memory: <value>Mi
        
      - id: "RM-002"
        title: "Resource Requests Defined"
        description: "All containers must have CPU and memory requests"
        category: "Resource Management"
        tool: "audit_resource_limits"
        severity: "warning"
        pass_criteria: "Requests defined and <= limits"
        fail_criteria: "No requests"
        remediation_template: |
          spec:
            containers:
            - name: <container>
              resources:
                requests:
                  cpu: <value>m
                  memory: <value>Mi
      
      # ... RM-003, RM-004, RM-005
  
  - name: "Health & Probes"
    description: "Verify health check probes"
    items:
      - id: "HP-001"
        title: "Liveness Probe Configured"
        category: "Health & Probes"
        tool: "audit_probes"
        severity: "critical"
        # ...
      
      # ... HP-002, HP-003, HP-004
  
  - name: "Scaling"
    items:
      - id: "SC-001"
        title: "HPA Configured"
        tool: "audit_hpa_config"
        severity: "warning"
      
      - id: "SC-002"
        title: "HPA Bounds Appropriate"
        tool: "smart_hpa_check"
        severity: "warning"
      
      # ... SC-003
  
  - name: "Observability"
    items:
      - id: "OB-001"
        title: "Metrics Instrumented"
        tool: "audit_metrics_instrumentation"
        severity: "critical"
      
      # ... OB-002 through OB-006
  
  - name: "Security"
    items:
      - id: "SEC-001"
        title: "No Root Containers"
        tool: "audit_security_context"
        severity: "critical"
      
      # ... SEC-002 through SEC-005
  
  - name: "Deployment"
    items:
      - id: "DEP-001"
        title: "No :latest Tags"
        tool: "audit_image_tags"
        severity: "critical"
      
      # ... DEP-002 through DEP-004
  
  - name: "Resilience"
    items:
      - id: "RES-001"
        title: "PDB Configured"
        tool: "audit_pdb"
        severity: "warning"
      
      # ... RES-002 through RES-004
  
  - name: "Documentation"
    items:
      - id: "DOC-001"
        title: "Runbook Exists"
        tool: "check_runbook_annotation"
        severity: "warning"
      
      # ... DOC-002, DOC-003
```

---

## Report Output Schema

Audit reports are returned as JSON following this schema:

```json
{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "type": "object",
  "properties": {
    "audit_id": {
      "type": "string",
      "description": "Unique audit run ID"
    },
    "timestamp": {
      "type": "string",
      "format": "date-time",
      "description": "When audit was run"
    },
    "service": {
      "type": "object",
      "properties": {
        "name": { "type": "string" },
        "namespace": { "type": "string" },
        "image": { "type": "string" },
        "replicas": { "type": "integer" }
      }
    },
    "cluster_info": {
      "type": "object",
      "properties": {
        "version": { "type": "string" },
        "region": { "type": "string" }
      }
    },
    "overall_status": {
      "type": "string",
      "enum": ["pass", "warning", "critical"]
    },
    "summary": {
      "type": "object",
      "properties": {
        "total_checks": { "type": "integer" },
        "passed": { "type": "integer" },
        "warning": { "type": "integer" },
        "critical": { "type": "integer" }
      }
    },
    "findings": {
      "type": "object",
      "properties": {
        "critical": {
          "type": "array",
          "items": { "$ref": "#/definitions/finding" }
        },
        "warning": {
          "type": "array",
          "items": { "$ref": "#/definitions/finding" }
        },
        "advisory": {
          "type": "array",
          "items": { "$ref": "#/definitions/finding" }
        }
      }
    },
    "by_category": {
      "type": "object",
      "additionalProperties": {
        "type": "object",
        "properties": {
          "category_name": { "type": "string" },
          "passed": { "type": "integer" },
          "warning": { "type": "integer" },
          "critical": { "type": "integer" },
          "items": { "type": "array" }
        }
      }
    }
  },
  "definitions": {
    "finding": {
      "type": "object",
      "properties": {
        "id": { "type": "string", "example": "RM-001" },
        "title": { "type": "string" },
        "category": { "type": "string" },
        "severity": { "type": "string", "enum": ["critical", "warning", "advisory"] },
        "status": { "type": "string", "enum": ["pass", "warning", "fail"] },
        "details": { "type": "string" },
        "evidence": { "type": "array", "items": { "type": "string" } },
        "remediation": { "type": "string" },
        "kubectl_command": { "type": "string" },
        "estimated_fix_time": { "type": "integer", "description": "minutes" }
      }
    }
  }
}
```

---

## Directory Structure

```
mcp-prod-readiness/
│
├── README.md
├── PROPOSAL.md
├── ARCHITECTURE.md
├── IMPLEMENTATION.md
├── Makefile
├── docker-compose.yml
│
├── go/
│   ├── go.mod
│   ├── go.sum
│   ├── backend/
│   │   ├── main.go                    # Entry point: HTTP server
│   │   ├── server.go                  # HTTP handlers
│   │   ├── classifier/
│   │   │   ├── router.go              # Query classification logic
│   │   │   └── models.go              # ClassificationResult, etc.
│   │   ├── checks/
│   │   │   ├── kubernetes.go          # 8 K8s audit functions
│   │   │   ├── observability.go       # 4 observability audit functions
│   │   │   ├── configuration.go       # 3 config audit functions
│   │   │   └── smart_checks.go        # 4 smart check functions
│   │   ├── clients/
│   │   │   ├── k8s.go                 # Kubernetes API client
│   │   │   ├── prometheus.go          # Prometheus PromQL client
│   │   │   ├── grafana.go             # Grafana API client
│   │   │   └── opensearch.go          # OpenSearch HTTP client
│   │   └── models/
│   │       ├── check_result.go        # CheckResult, various result types
│   │       ├── audit_report.go        # Full audit report struct
│   │       └── probe_config.go        # Domain models
│   └── cmd/
│       └── prod-readiness/
│           └── main.go                # CLI entry point
│
├── python/
│   ├── requirements.txt
│   ├── mcp_server.py                  # FastMCP entry point
│   ├── tools/
│   │   ├── __init__.py
│   │   ├── kubernetes_tools.py        # MCP tool definitions for K8s
│   │   ├── observability_tools.py     # MCP tool definitions for observability
│   │   ├── configuration_tools.py     # MCP tool definitions for config
│   │   └── smart_tools.py             # MCP tool definitions for smart checks
│   ├── models/
│   │   ├── __init__.py
│   │   ├── check_request.py
│   │   ├── audit_request.py
│   │   └── audit_report.py
│   ├── checklist/
│   │   ├── __init__.py
│   │   ├── loader.py                  # YAML checklist loader
│   │   ├── validator.py               # Schema validation
│   │   └── schemas/
│   │       └── checklist_schema.json
│   └── reporting/
│       ├── __init__.py
│       ├── generator.py               # Report generation
│       └── formatters.py              # JSON, YAML, HTML formatters
│
├── config/
│   ├── checklist.yaml                 # 34-item checklist definition
│   ├── prometheus-rules.yaml          # Alert rules (for demo)
│   ├── demo-config.yaml               # Demo environment config
│   └── helm-values.yaml               # Default Helm values
│
├── helm/
│   └── mcp-prod-readiness/
│       ├── Chart.yaml
│       ├── values.yaml
│       ├── templates/
│       │   ├── deployment.yaml
│       │   ├── service.yaml
│       │   ├── configmap.yaml
│       │   ├── rbac.yaml
│       │   └── serviceaccount.yaml
│       └── README.md
│
├── demo/
│   ├── kind-config.yaml               # Kind cluster setup
│   ├── setup.sh                       # Demo environment bootstrap
│   └── services/
│       ├── fully-compliant/
│       │   ├── deployment.yaml
│       │   ├── service.yaml
│       │   ├── hpa.yaml
│       │   ├── network-policy.yaml
│       │   └── README.md
│       ├── critical-issues/
│       │   └── ...
│       ├── warnings-only/
│       │   └── ...
│       └── mixed-findings/
│           └── ...
│
├── docs/
│   ├── checklist-items.md             # All 34 items with explanations
│   ├── smart-checks-guide.md          # Deep dive into smart checks
│   ├── hybrid-engine.md               # Hybrid routing explained
│   ├── api.md                         # HTTP and MCP API reference
│   ├── deployment.md                  # Production deployment guide
│   └── troubleshooting.md
│
└── .github/
    └── workflows/
        └── ci.yml                     # Build, test, lint
```

---

## Data Flow

### Full Audit Flow

```
User Request (HTTP POST /api/audit)
  ↓
FastMCP Router
  ↓
Checks "is this multi-check?" → YES
  ↓
AI Handler (Claude) receives audit request
  ↓
Claude orchestrates:
  For each of 34 checklist items:
    - Determine tool to invoke
    - Call Go backend with HTTP request
    - Go backend queries K8s/Prometheus/Grafana/OpenSearch
    - Returns CheckResult
    - Claude collects result
  ↓
Claude synthesizes findings:
  - Groups by severity (critical, warning, advisory)
  - Groups by category
  - Ranks by impact
  - Generates remediation for each
  ↓
Report generated (JSON)
  ↓
Return to user
```

### Single Check Flow

```
User Request (HTTP POST /api/check)
  ↓
FastMCP Router
  ↓
Checks "is this a single direct check?" → YES
  ↓
Go Backend (direct path):
  - Parse request (namespace, service, check_type)
  - Route to appropriate tool function
  - Execute check (K8s API call, PromQL query, etc.)
  - Return CheckResult (50-100ms)
  ↓
Return JSON to user immediately
```

### Smart Check Flow

```
User Request (AI path routing)
  ↓
Claude receives request for smart check
  ↓
Claude calls Go backend multiple times:
  1. Fetch config (e.g., HPA spec)
  2. Query historical data (e.g., 30d traffic from Prometheus)
  3. Fetch additional context (e.g., pod restart history)
  ↓
Claude reasons about collected data:
  - Compare config to real-world data
  - Identify mismatches
  - Generate verdict and evidence
  ↓
Return SmartCheckResult with reasoning
```

---

## Demo Environment

### Kind Cluster Setup

```yaml
kind: Cluster
apiVersion: kind.x-k8s.io/v1alpha4
name: mcp-demo
nodes:
- role: control-plane
  extraPortMappings:
  - containerPort: 8000
    hostPort: 8000
    protocol: TCP
  - containerPort: 9090
    hostPort: 9090
    protocol: TCP
  - containerPort: 3000
    hostPort: 3000
    protocol: TCP
```

### 4 Demo Services

**1. fully-compliant** (passes all 34 checks)
- 2+ replicas
- Resource limits and requests
- Liveness + readiness probes
- HPA configured
- NetworkPolicy
- SecurityContext (non-root, read-only FS)
- No :latest tags
- Metrics instrumented
- Alerts defined
- Dashboards exist
- RBAC configured

**2. critical-issues** (7 critical findings)
- No resource limits (RM-001)
- No liveness probe (HP-001)
- Using :latest tag (DEP-001)
- Root container (SEC-001)
- No network policy (SEC-003)
- No metrics (OB-001)
- No RBAC (SEC-005)

**3. warnings-only** (6 warnings, 0 critical)
- Limits exist but P99 > 85% (warning)
- Only 1 replica (warning)
- HPA with aggressive scaling (warning)
- Probes exist but stale endpoint (warning)
- Minimal alerts (warning)
- No dashboard (warning)

**4. mixed-findings**
- Realistic mix: some critical, some warnings, mostly pass
- Mirrors typical production service

---

## Deployment Model

### Local Development
```bash
make kind-up          # Start Kind cluster
make build-all        # Build Go + Python
make run-demo         # Run demo services
make run-server       # Start FastMCP server
```

### Helm Chart Deployment
```bash
helm install mcp-prod-readiness ./helm/mcp-prod-readiness \
  --namespace mcp-tools \
  --values config/helm-values.yaml
```

### Docker Compose
```bash
docker-compose up     # Start all services (for testing)
```

---

## Dependency Versions (Pinned)

```
Go: 1.21.0
Python: 3.10.12
Kubernetes client-go: v0.27.0
Prometheus client: v1.17.0
FastMCP: 0.1.0-rc1
Kind: v0.20.0
Helm: 3.12.0
OpenSearch: 2.9.0
Grafana: 10.0.0
```

---

## Performance Targets

- Single check: 50-100ms
- Full audit (34 checks): 5-15 seconds
- Batch audit (10 services): 30-40 seconds
- Smart check: 2-5 seconds additional
- Report generation: <1 second

---

This architecture enables scalable, cost-effective production readiness audits by intelligently routing queries between direct backend calls and AI-powered reasoning.
