# Changelog

All notable changes to this project will be documented here.
Format: [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).

## [0.3.0] — 2026-04-20

### Added
- Check: `resilience.replicas-ge-2` (blocker). Deployments need ≥2 replicas; StatefulSets additionally need anti-affinity or topology spread.
- Check: `resilience.pdb-exists` (warning). A matching PodDisruptionBudget must exist that preserves availability.
- `K8sAdapter.list_pdbs(namespace)` and `pdb_matches_workload(pdb, workload)` helper.

## [0.2.0] — 2026-04-20

### Added
- Check: `security.runs-as-non-root` (blocker). Enforces `runAsNonRoot`, non-zero `runAsUser`, and `allowPrivilegeEscalation=false`.
- Check: `observability.prometheus-scrape-configured` (warning). Verifies pod-template scrape annotation and — when Prometheus is configured — that samples arrived in the last 15m.
- Per-run read-through cache on `K8sAdapter.read_workload` (one API call per target per audit).
- Golden-test matrix runner: scenarios auto-discovered from `tests/golden/<check_id>/<scenario>/`.

### Changed
- Golden-test layout: formally the matrix-discovered layout. Existing Plan-1 scenarios migrated without change.

## [0.1.0] — 2026-04-20

### Added
- MCP server and CLI surfaces with 1:1 parity.
- Core engine: capability-routed orchestrator, plugin-registered checks, async K8s+Prom+LLM adapters.
- LLM-agnostic via litellm + instructor; offline fallback; Ollama auto-discovery.
- First check: `resources.requests-and-limits-set`.
- Golden-test harness on ephemeral kind; 3 scenarios.
- OTel spans per check run.
- Multi-stage Dockerfile.
