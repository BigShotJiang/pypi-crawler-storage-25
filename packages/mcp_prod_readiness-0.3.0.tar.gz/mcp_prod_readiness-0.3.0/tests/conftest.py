from __future__ import annotations

import pytest

from tests.golden._runner import KindCluster, create_kind


@pytest.fixture(scope="session")
def kind_cluster() -> KindCluster:  # type: ignore[return]
    cluster = create_kind()
    yield cluster  # type: ignore[misc]
    cluster.delete()
