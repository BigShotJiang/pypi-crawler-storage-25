from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock

import pytest

from prod_readiness.checks.resilience_replicas_ge_2 import ResilienceReplicasGe2
from prod_readiness.core.context import AuditContext
from prod_readiness.core.models import Status, Target


def _deploy(replicas: int) -> object:
    return SimpleNamespace(
        spec=SimpleNamespace(
            replicas=replicas,
            template=SimpleNamespace(
                spec=SimpleNamespace(
                    affinity=None, topology_spread_constraints=None, containers=[]
                )
            ),
        )
    )


def _sts(replicas: int, *, anti_affinity: bool = False, topology: bool = False) -> object:
    pod_spec = SimpleNamespace(
        affinity=(
            SimpleNamespace(pod_anti_affinity=SimpleNamespace()) if anti_affinity else None
        ),
        topology_spread_constraints=(
            [SimpleNamespace(topology_key="kubernetes.io/hostname")] if topology else None
        ),
        containers=[],
    )
    return SimpleNamespace(
        spec=SimpleNamespace(replicas=replicas, template=SimpleNamespace(spec=pod_spec))
    )


def _ctx(workload) -> AuditContext:
    k8s = MagicMock()
    k8s.read_workload = AsyncMock(return_value=workload)
    return AuditContext(k8s=k8s, prom=MagicMock(), llm=MagicMock())


def _dep_target() -> Target:
    return Target(kind="Deployment", namespace="d", name="a", uid="u-d")


def _sts_target() -> Target:
    return Target(kind="StatefulSet", namespace="d", name="s", uid="u-s")


@pytest.mark.asyncio
async def test_deployment_pass_when_replicas_is_3():
    ctx = _ctx(_deploy(3)).guard(needs=ResilienceReplicasGe2.needs)
    f = await ResilienceReplicasGe2().run(ctx, _dep_target())
    assert f.status == Status.PASS


@pytest.mark.asyncio
async def test_deployment_fail_when_replicas_is_1():
    ctx = _ctx(_deploy(1)).guard(needs=ResilienceReplicasGe2.needs)
    f = await ResilienceReplicasGe2().run(ctx, _dep_target())
    assert f.status == Status.FAIL
    assert "replicas" in f.message.lower()
    assert f.evidence["replicas"] == 1


@pytest.mark.asyncio
async def test_statefulset_pass_with_replicas_3_and_topology_spread():
    ctx = _ctx(_sts(3, topology=True)).guard(needs=ResilienceReplicasGe2.needs)
    f = await ResilienceReplicasGe2().run(ctx, _sts_target())
    assert f.status == Status.PASS


@pytest.mark.asyncio
async def test_statefulset_pass_with_replicas_3_and_anti_affinity():
    ctx = _ctx(_sts(3, anti_affinity=True)).guard(needs=ResilienceReplicasGe2.needs)
    f = await ResilienceReplicasGe2().run(ctx, _sts_target())
    assert f.status == Status.PASS


@pytest.mark.asyncio
async def test_statefulset_fail_with_replicas_3_but_no_spread_hints():
    ctx = _ctx(_sts(3)).guard(needs=ResilienceReplicasGe2.needs)
    f = await ResilienceReplicasGe2().run(ctx, _sts_target())
    assert f.status == Status.FAIL
    assert "spread" in f.message.lower() or "anti-affinity" in f.message.lower()


@pytest.mark.asyncio
async def test_statefulset_fail_with_replicas_1():
    ctx = _ctx(_sts(1, topology=True)).guard(needs=ResilienceReplicasGe2.needs)
    f = await ResilienceReplicasGe2().run(ctx, _sts_target())
    assert f.status == Status.FAIL
    assert f.evidence["replicas"] == 1
