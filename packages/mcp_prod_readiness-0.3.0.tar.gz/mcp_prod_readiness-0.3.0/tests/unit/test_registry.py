from __future__ import annotations

import pytest

from prod_readiness.core.check import Check
from prod_readiness.core.models import Capability, Finding, Severity, Status
from prod_readiness.core.registry import (
    get_check,
    list_checks,
    register_check,
    registry_snapshot,
)


@pytest.fixture(autouse=True)
def _clear_registry():
    snap = registry_snapshot()
    yield
    snap.restore()


def test_register_and_lookup():
    @register_check
    class DummyCheck(Check):
        id = "dummy.ok"
        category = "documentation"
        severity = Severity.INFO
        needs = frozenset({Capability.K8S})
        description = "dummy"

        async def run(self, ctx, target):  # type: ignore[override]
            return Finding(
                check_id=self.id,
                target=target,
                severity=self.severity,
                status=Status.PASS,
                message="ok",
            )

    assert get_check("dummy.ok") is DummyCheck
    assert any(c.id == "dummy.ok" for c in list_checks())


def test_duplicate_id_raises():
    @register_check
    class A(Check):
        id = "dup.id"
        category = "x"
        severity = Severity.INFO
        needs = frozenset()
        description = "a"

        async def run(self, ctx, target): ...

    with pytest.raises(ValueError, match="already registered"):

        @register_check
        class B(Check):
            id = "dup.id"
            category = "x"
            severity = Severity.INFO
            needs = frozenset()
            description = "b"

            async def run(self, ctx, target): ...
