from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock

import pytest

from prod_readiness.checks.resources_requests_and_limits_set import (
    ResourcesRequestsAndLimitsSet,
)
from prod_readiness.core.context import AuditContext
from prod_readiness.core.models import Status, Target


def _wl(containers: list[dict]) -> object:
    pod_spec = SimpleNamespace(
        containers=[
            SimpleNamespace(
                name=c["name"],
                resources=SimpleNamespace(
                    requests=c.get("requests"),
                    limits=c.get("limits"),
                ),
            )
            for c in containers
        ]
    )
    return SimpleNamespace(spec=SimpleNamespace(template=SimpleNamespace(spec=pod_spec)))


def _ctx(workload) -> AuditContext:
    k8s = MagicMock()
    k8s.read_workload = AsyncMock(return_value=workload)
    return AuditContext(k8s=k8s, prom=MagicMock(), llm=MagicMock())


def _target() -> Target:
    return Target(kind="Deployment", namespace="d", name="a", uid="u")


@pytest.mark.asyncio
async def test_pass_when_all_containers_have_requests_and_memory_limits():
    wl = _wl(
        [
            {
                "name": "api",
                "requests": {"cpu": "100m", "memory": "128Mi"},
                "limits": {"memory": "256Mi"},
            }
        ]
    )
    ctx = _ctx(wl).guard(needs=ResourcesRequestsAndLimitsSet.needs)
    f = await ResourcesRequestsAndLimitsSet().run(ctx, _target())
    assert f.status == Status.PASS


@pytest.mark.asyncio
async def test_fail_when_cpu_request_missing():
    wl = _wl(
        [{"name": "api", "requests": {"memory": "128Mi"}, "limits": {"memory": "256Mi"}}]
    )
    ctx = _ctx(wl).guard(needs=ResourcesRequestsAndLimitsSet.needs)
    f = await ResourcesRequestsAndLimitsSet().run(ctx, _target())
    assert f.status == Status.FAIL
    assert "cpu" in f.message.lower()
    assert f.evidence["containers"][0]["missing"] == ["requests.cpu"]


@pytest.mark.asyncio
async def test_fail_when_memory_limit_missing():
    wl = _wl(
        [{"name": "api", "requests": {"cpu": "100m", "memory": "128Mi"}, "limits": None}]
    )
    ctx = _ctx(wl).guard(needs=ResourcesRequestsAndLimitsSet.needs)
    f = await ResourcesRequestsAndLimitsSet().run(ctx, _target())
    assert f.status == Status.FAIL
    assert "memory limit" in f.message.lower()


@pytest.mark.asyncio
async def test_remediation_yaml_snippet_included_on_fail():
    wl = _wl([{"name": "api", "requests": None, "limits": None}])
    ctx = _ctx(wl).guard(needs=ResourcesRequestsAndLimitsSet.needs)
    f = await ResourcesRequestsAndLimitsSet().run(ctx, _target())
    assert f.status == Status.FAIL
    assert f.remediation is not None
    assert "resources:" in f.remediation
    assert "requests:" in f.remediation
