from __future__ import annotations

import pytest
from pydantic import BaseModel

from prod_readiness.adapters.llm import LLMAdapter, LLMConfig, OfflineError


class _Out(BaseModel):
    verdict: str


@pytest.mark.asyncio
async def test_offline_mode_raises_offline_error():
    adapter = LLMAdapter(LLMConfig(offline=True))
    with pytest.raises(OfflineError):
        await adapter.structured("why?", response_model=_Out)


@pytest.mark.asyncio
async def test_offline_detected_when_no_provider_and_ollama_unreachable(monkeypatch):
    async def _unreachable(*a, **kw):
        raise ConnectionError("nope")

    monkeypatch.setattr(
        "prod_readiness.adapters.llm._probe_ollama", _unreachable
    )
    adapter = LLMAdapter(LLMConfig(provider=None, base_url=None, api_key=None))
    await adapter.ensure_ready()  # should not raise
    assert adapter.effectively_offline is True
    with pytest.raises(OfflineError):
        await adapter.structured("q", response_model=_Out)


def test_config_precedence_flag_beats_env(monkeypatch):
    monkeypatch.setenv("PROD_READINESS_LLM_PROVIDER", "openai/gpt-4o")
    cfg = LLMConfig.from_sources(cli_provider="anthropic/claude-sonnet-4-6")
    assert cfg.provider == "anthropic/claude-sonnet-4-6"
