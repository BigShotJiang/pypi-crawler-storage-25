from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock

import pytest

from prod_readiness.checks.security_runs_as_non_root import SecurityRunsAsNonRoot
from prod_readiness.core.context import AuditContext
from prod_readiness.core.models import Status, Target


def _wl(
    *,
    pod_sc: dict | None = None,
    containers: list[dict],
) -> object:
    pod_spec = SimpleNamespace(
        security_context=(SimpleNamespace(**pod_sc) if pod_sc else None),
        containers=[
            SimpleNamespace(
                name=c["name"],
                security_context=(
                    SimpleNamespace(**c["security_context"])
                    if c.get("security_context")
                    else None
                ),
            )
            for c in containers
        ],
    )
    return SimpleNamespace(spec=SimpleNamespace(template=SimpleNamespace(spec=pod_spec)))


def _ctx(workload) -> AuditContext:
    k8s = MagicMock()
    k8s.read_workload = AsyncMock(return_value=workload)
    return AuditContext(k8s=k8s, prom=MagicMock(), llm=MagicMock())


def _target() -> Target:
    return Target(kind="Deployment", namespace="d", name="a", uid="u")


@pytest.mark.asyncio
async def test_pass_when_container_sets_runs_as_non_root_and_forbids_priv_escalation():
    wl = _wl(
        containers=[
            {
                "name": "api",
                "security_context": {
                    "run_as_non_root": True,
                    "run_as_user": 1000,
                    "allow_privilege_escalation": False,
                },
            }
        ]
    )
    ctx = _ctx(wl).guard(needs=SecurityRunsAsNonRoot.needs)
    f = await SecurityRunsAsNonRoot().run(ctx, _target())
    assert f.status == Status.PASS


@pytest.mark.asyncio
async def test_pass_when_pod_level_sets_runs_as_non_root_and_container_does_not_override():
    wl = _wl(
        pod_sc={"run_as_non_root": True, "run_as_user": 1000},
        containers=[
            {
                "name": "api",
                "security_context": {"allow_privilege_escalation": False},
            }
        ],
    )
    ctx = _ctx(wl).guard(needs=SecurityRunsAsNonRoot.needs)
    f = await SecurityRunsAsNonRoot().run(ctx, _target())
    assert f.status == Status.PASS


@pytest.mark.asyncio
async def test_fail_when_neither_pod_nor_container_set_run_as_non_root():
    wl = _wl(
        containers=[
            {"name": "api", "security_context": {"allow_privilege_escalation": False}}
        ]
    )
    ctx = _ctx(wl).guard(needs=SecurityRunsAsNonRoot.needs)
    f = await SecurityRunsAsNonRoot().run(ctx, _target())
    assert f.status == Status.FAIL
    assert "runAsNonRoot" in f.message or "non-root" in f.message.lower()
    assert f.evidence["containers"][0]["problems"]


@pytest.mark.asyncio
async def test_fail_when_run_as_user_is_zero():
    wl = _wl(
        containers=[
            {
                "name": "api",
                "security_context": {
                    "run_as_non_root": True,
                    "run_as_user": 0,
                    "allow_privilege_escalation": False,
                },
            }
        ]
    )
    ctx = _ctx(wl).guard(needs=SecurityRunsAsNonRoot.needs)
    f = await SecurityRunsAsNonRoot().run(ctx, _target())
    assert f.status == Status.FAIL
    assert "runAsUser=0" in f.message


@pytest.mark.asyncio
async def test_fail_when_allow_privilege_escalation_is_true_or_missing():
    wl = _wl(
        containers=[
            {
                "name": "api",
                "security_context": {"run_as_non_root": True, "run_as_user": 1000},
            }
        ]
    )
    ctx = _ctx(wl).guard(needs=SecurityRunsAsNonRoot.needs)
    f = await SecurityRunsAsNonRoot().run(ctx, _target())
    assert f.status == Status.FAIL
    assert "allowPrivilegeEscalation" in f.message


@pytest.mark.asyncio
async def test_container_override_of_pod_level_to_false_fails():
    wl = _wl(
        pod_sc={"run_as_non_root": True, "run_as_user": 1000},
        containers=[
            {
                "name": "api",
                "security_context": {
                    "run_as_non_root": False,
                    "allow_privilege_escalation": False,
                },
            }
        ],
    )
    ctx = _ctx(wl).guard(needs=SecurityRunsAsNonRoot.needs)
    f = await SecurityRunsAsNonRoot().run(ctx, _target())
    assert f.status == Status.FAIL
