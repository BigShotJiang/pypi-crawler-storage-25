from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock

import pytest

from prod_readiness.adapters.k8s import K8sAdapter, pdb_matches_workload


def _wl(pod_labels: dict[str, str]) -> object:
    return SimpleNamespace(
        spec=SimpleNamespace(
            template=SimpleNamespace(
                metadata=SimpleNamespace(labels=pod_labels),
                spec=SimpleNamespace(containers=[]),
            )
        )
    )


def _pdb(match_labels: dict[str, str] | None, match_expressions: list[dict] | None = None) -> object:
    selector = SimpleNamespace(
        match_labels=match_labels,
        match_expressions=[
            SimpleNamespace(**e) for e in (match_expressions or [])
        ],
    )
    return SimpleNamespace(spec=SimpleNamespace(selector=selector))


def test_matches_when_pdb_match_labels_is_subset_of_pod_labels():
    assert pdb_matches_workload(
        _pdb(match_labels={"app": "api"}),
        _wl({"app": "api", "env": "prod"}),
    )


def test_does_not_match_when_pdb_has_extra_label():
    assert not pdb_matches_workload(
        _pdb(match_labels={"app": "api", "role": "worker"}),
        _wl({"app": "api"}),
    )


def test_does_not_match_when_value_differs():
    assert not pdb_matches_workload(
        _pdb(match_labels={"app": "web"}),
        _wl({"app": "api"}),
    )


def test_matches_when_both_empty():
    assert pdb_matches_workload(
        _pdb(match_labels={}),
        _wl({}),
    )


def test_ignores_match_expressions_in_v1_and_matches_on_labels_only():
    # v1 only matches against match_labels; match_expressions are treated as "unknown"
    # and cause the PDB NOT to match, so the check errs on the side of "no PDB found".
    assert not pdb_matches_workload(
        _pdb(
            match_labels={"app": "api"},
            match_expressions=[{"key": "tier", "operator": "In", "values": ["web"]}],
        ),
        _wl({"app": "api"}),
    )


@pytest.mark.asyncio
async def test_list_pdbs_returns_items_from_policy_api():
    adapter = K8sAdapter.__new__(K8sAdapter)
    adapter._read_cache = {}  # type: ignore[attr-defined]
    fake_policy = MagicMock()
    fake_policy.list_namespaced_pod_disruption_budget = AsyncMock(
        return_value=MagicMock(items=[MagicMock(), MagicMock()])
    )
    adapter._policy = fake_policy  # type: ignore[attr-defined]
    pdbs = await adapter.list_pdbs("default")
    assert len(pdbs) == 2
    fake_policy.list_namespaced_pod_disruption_budget.assert_awaited_once_with(
        namespace="default"
    )
