from __future__ import annotations

import json

from typer.testing import CliRunner

from prod_readiness.cli import app

runner = CliRunner()


def test_list_checks_includes_resources_check():
    result = runner.invoke(app, ["list-checks"])
    assert result.exit_code == 0
    assert "resources.requests-and-limits-set" in result.stdout


def test_list_checks_json_output():
    result = runner.invoke(app, ["list-checks", "--format", "json"])
    assert result.exit_code == 0
    data = json.loads(result.stdout)
    ids = [m["id"] for m in data]
    assert "resources.requests-and-limits-set" in ids


def test_help_mentions_commands():
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    for cmd in ("audit", "audit-workload", "list-checks", "explain", "diff", "serve-mcp"):
        assert cmd in result.stdout
