from __future__ import annotations

import subprocess
import sys


def test_module_invocation_prints_help_with_exit_0_when_help_passed():
    result = subprocess.run(
        [sys.executable, "-m", "prod_readiness.cli", "--help"],
        capture_output=True,
        text=True,
        check=False,
    )
    assert result.returncode == 0
    assert "audit" in result.stdout
