from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock

import pytest

from prod_readiness.checks.observability_prometheus_scrape_configured import (
    ObservabilityPrometheusScrapeConfigured,
)
from prod_readiness.core.context import AuditContext
from prod_readiness.core.models import Status, Target


def _wl(annotations: dict[str, str] | None) -> object:
    pod_tmpl_meta = SimpleNamespace(annotations=annotations or {})
    pod_spec = SimpleNamespace(containers=[SimpleNamespace(name="api")])
    return SimpleNamespace(
        spec=SimpleNamespace(
            template=SimpleNamespace(metadata=pod_tmpl_meta, spec=pod_spec)
        )
    )


def _ctx(workload, *, prom_available: bool, prom_query_result: dict | Exception | None = None) -> AuditContext:
    k8s = MagicMock()
    k8s.read_workload = AsyncMock(return_value=workload)
    prom = MagicMock()
    prom.available = prom_available
    if isinstance(prom_query_result, Exception):
        prom.query = AsyncMock(side_effect=prom_query_result)
    else:
        prom.query = AsyncMock(return_value=prom_query_result or {"result": []})
    return AuditContext(k8s=k8s, prom=prom, llm=MagicMock())


def _target() -> Target:
    return Target(kind="Deployment", namespace="d", name="a", uid="u")


@pytest.mark.asyncio
async def test_skip_when_annotation_present_but_prom_unavailable():
    wl = _wl({"prometheus.io/scrape": "true"})
    ctx = _ctx(wl, prom_available=False).guard(
        needs=ObservabilityPrometheusScrapeConfigured.needs
    )
    f = await ObservabilityPrometheusScrapeConfigured().run(ctx, _target())
    assert f.status == Status.SKIP
    assert "no Prometheus" in f.message.lower() or "cannot verify" in f.message.lower()


@pytest.mark.asyncio
async def test_fail_when_no_annotation_and_prom_unavailable():
    wl = _wl(None)
    ctx = _ctx(wl, prom_available=False).guard(
        needs=ObservabilityPrometheusScrapeConfigured.needs
    )
    f = await ObservabilityPrometheusScrapeConfigured().run(ctx, _target())
    assert f.status == Status.FAIL
    assert "scrape" in f.message.lower()


@pytest.mark.asyncio
async def test_fail_when_annotation_present_but_prom_has_no_samples():
    wl = _wl({"prometheus.io/scrape": "true"})
    ctx = _ctx(
        wl,
        prom_available=True,
        prom_query_result={"result": []},
    ).guard(needs=ObservabilityPrometheusScrapeConfigured.needs)
    f = await ObservabilityPrometheusScrapeConfigured().run(ctx, _target())
    assert f.status == Status.FAIL
    assert "no samples" in f.message.lower()


@pytest.mark.asyncio
async def test_pass_when_annotation_present_and_prom_has_samples():
    wl = _wl({"prometheus.io/scrape": "true"})
    ctx = _ctx(
        wl,
        prom_available=True,
        prom_query_result={
            "result": [
                {"metric": {"namespace": "d", "pod": "a-abc"}, "value": [1234, "1"]}
            ]
        },
    ).guard(needs=ObservabilityPrometheusScrapeConfigured.needs)
    f = await ObservabilityPrometheusScrapeConfigured().run(ctx, _target())
    assert f.status == Status.PASS


@pytest.mark.asyncio
async def test_error_swallowed_when_prom_query_raises():
    wl = _wl({"prometheus.io/scrape": "true"})
    ctx = _ctx(
        wl,
        prom_available=True,
        prom_query_result=RuntimeError("prom down"),
    ).guard(needs=ObservabilityPrometheusScrapeConfigured.needs)
    f = await ObservabilityPrometheusScrapeConfigured().run(ctx, _target())
    assert f.status == Status.SKIP
    assert "prom down" in f.message.lower() or "query failed" in f.message.lower()
