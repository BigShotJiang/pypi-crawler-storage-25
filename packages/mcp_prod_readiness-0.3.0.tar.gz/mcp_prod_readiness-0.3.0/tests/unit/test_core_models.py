from __future__ import annotations

from datetime import UTC, datetime

import pytest
from pydantic import ValidationError

from prod_readiness.core.models import (
    Capability,
    CheckMeta,
    Finding,
    Report,
    Scope,
    Severity,
    Status,
    Target,
)


def test_target_roundtrip():
    t = Target(kind="Deployment", namespace="default", name="api", uid="u-1")
    assert t.model_dump()["uid"] == "u-1"


def test_target_rejects_invalid_kind():
    with pytest.raises(ValidationError):
        Target(kind="Pod", namespace="default", name="x", uid="u")  # type: ignore[arg-type]


def test_finding_requires_enum_values():
    f = Finding(
        check_id="x.y",
        target=Target(kind="Deployment", namespace="default", name="a", uid="u"),
        severity=Severity.BLOCKER,
        status=Status.FAIL,
        message="m",
        evidence={},
        remediation=None,
        ai_reasoning=None,
        duration_ms=1,
    )
    assert f.severity == Severity.BLOCKER


def test_report_summary_is_arbitrary_dict():
    r = Report(
        cluster_context="kind-dev",
        scope=Scope(),
        started_at=datetime.now(UTC),
        finished_at=datetime.now(UTC),
        findings=[],
        summary={"pass": 0, "fail": 0},
        version="0.1.0",
    )
    assert r.summary["pass"] == 0


def test_check_meta_serialises_needs():
    m = CheckMeta(
        id="x.y",
        category="resources",
        severity=Severity.WARNING,
        needs=frozenset({Capability.K8S}),
        description="test",
    )
    dumped = m.model_dump()
    assert dumped["needs"] == ["k8s"]
