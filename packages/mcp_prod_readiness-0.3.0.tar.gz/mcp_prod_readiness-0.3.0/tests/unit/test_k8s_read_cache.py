from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from prod_readiness.adapters.k8s import K8sAdapter
from prod_readiness.core.models import Target


@pytest.mark.asyncio
async def test_read_workload_is_memoised_per_run():
    adapter = K8sAdapter.__new__(K8sAdapter)
    adapter._read_cache = {}  # type: ignore[attr-defined]
    fake_apps = MagicMock()
    wl = MagicMock()
    fake_apps.read_namespaced_deployment = AsyncMock(return_value=wl)
    fake_apps.read_namespaced_stateful_set = AsyncMock()
    adapter._apps = fake_apps  # type: ignore[attr-defined]

    t = Target(kind="Deployment", namespace="d", name="a", uid="uid-1")

    first = await adapter.read_workload(t)
    second = await adapter.read_workload(t)

    assert first is wl
    assert second is wl
    assert fake_apps.read_namespaced_deployment.call_count == 1


@pytest.mark.asyncio
async def test_close_clears_cache():
    adapter = K8sAdapter.__new__(K8sAdapter)
    adapter._read_cache = {"u1": object()}  # type: ignore[attr-defined]
    adapter._api_client = None  # type: ignore[attr-defined]
    await adapter.close()
    assert adapter._read_cache == {}  # type: ignore[attr-defined]
