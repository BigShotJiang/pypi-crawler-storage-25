from __future__ import annotations

from datetime import UTC, datetime

from prod_readiness.core.models import Finding, Report, Scope, Severity, Status, Target
from prod_readiness.reports.html import render_html
from prod_readiness.reports.json import render_json
from prod_readiness.reports.junit import render_junit
from prod_readiness.reports.markdown import render_markdown


def _sample() -> Report:
    t = Target(kind="Deployment", namespace="d", name="a", uid="u-1")
    return Report(
        cluster_context="kind",
        scope=Scope(),
        started_at=datetime(2026, 4, 20, tzinfo=UTC),
        finished_at=datetime(2026, 4, 20, 0, 0, 1, tzinfo=UTC),
        findings=[
            Finding(
                check_id="x.y",
                target=t,
                severity=Severity.BLOCKER,
                status=Status.FAIL,
                message="missing requests",
                evidence={"container": "api"},
                remediation="set cpu+memory requests",
                duration_ms=3,
            )
        ],
        summary={"fail": 1, "fail_or_error": 1, "total": 1},
        version="0.1.0",
    )


def test_json_is_deterministic():
    r = _sample()
    a = render_json(r)
    b = render_json(r)
    assert a == b
    assert "missing requests" in a


def test_markdown_has_headers_and_severity():
    md = render_markdown(_sample())
    assert "# Production Readiness Report" in md
    assert "BLOCKER" in md
    assert "missing requests" in md


def test_junit_has_testsuite():
    x = render_junit(_sample())
    assert "<testsuite" in x
    assert 'failures="1"' in x


def test_html_has_doctype():
    h = render_html(_sample())
    assert h.lstrip().startswith("<!doctype html")
