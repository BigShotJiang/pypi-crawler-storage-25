from __future__ import annotations

import pytest
from pytest_httpx import HTTPXMock

from prod_readiness.adapters.prom import PromAdapter, PromConfig


@pytest.mark.asyncio
async def test_instant_query(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url="http://prom:9090/api/v1/query?query=up",
        json={
            "status": "success",
            "data": {"resultType": "vector", "result": [{"value": [123, "1"]}]},
        },
    )
    p = PromAdapter(PromConfig(base_url="http://prom:9090"))
    result = await p.query("up")
    assert result["result"][0]["value"][1] == "1"


@pytest.mark.asyncio
async def test_missing_base_url_returns_unavailable(monkeypatch):
    p = PromAdapter(PromConfig(base_url=None))
    assert p.available is False
    with pytest.raises(RuntimeError, match="Prometheus base URL not configured"):
        await p.query("up")
