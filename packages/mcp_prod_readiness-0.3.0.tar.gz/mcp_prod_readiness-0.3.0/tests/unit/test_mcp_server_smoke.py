from __future__ import annotations

import asyncio

from prod_readiness.mcp_server import build_server


def test_server_exposes_expected_tools() -> None:
    server = build_server()
    # fastmcp 3.x: list_tools() is a coroutine; run it synchronously here
    tools = asyncio.run(server.list_tools())
    tool_names = {t.name for t in tools}
    assert {"audit_cluster", "audit_workload", "list_checks"}.issubset(tool_names)
