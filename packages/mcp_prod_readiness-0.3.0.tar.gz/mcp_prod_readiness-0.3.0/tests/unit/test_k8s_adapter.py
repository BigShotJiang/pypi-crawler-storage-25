from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from prod_readiness.adapters.k8s import K8sAdapter
from prod_readiness.core.models import Target


@pytest.mark.asyncio
async def test_list_targets_merges_deployments_and_statefulsets(monkeypatch):
    # Note: MagicMock treats `name` as its own display-name kwarg, so set
    # metadata.name as an attribute after construction to get a real string.
    dep_meta = MagicMock(namespace="default", uid="u-1", labels={})
    dep_meta.name = "api"
    sts_meta = MagicMock(namespace="default", uid="u-2", labels={})
    sts_meta.name = "db"

    fake_apps = MagicMock()
    fake_apps.list_namespaced_deployment = AsyncMock(
        return_value=MagicMock(items=[MagicMock(metadata=dep_meta)])
    )
    fake_apps.list_namespaced_stateful_set = AsyncMock(
        return_value=MagicMock(items=[MagicMock(metadata=sts_meta)])
    )

    adapter = K8sAdapter.__new__(K8sAdapter)
    adapter._apps = fake_apps  # type: ignore[attr-defined]
    adapter._core = MagicMock()  # type: ignore[attr-defined]
    adapter.context_name = "kind-test"  # type: ignore[attr-defined]

    targets = await adapter.list_targets(
        namespaces=["default"], label_selector=None
    )
    kinds = {t.kind for t in targets}
    assert kinds == {"Deployment", "StatefulSet"}
    assert all(isinstance(t, Target) for t in targets)
