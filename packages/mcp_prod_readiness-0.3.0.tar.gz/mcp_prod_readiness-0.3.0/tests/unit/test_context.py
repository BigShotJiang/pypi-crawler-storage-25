from __future__ import annotations

import pytest

from prod_readiness.adapters.k8s import K8sAdapter, K8sConfig
from prod_readiness.adapters.llm import LLMAdapter, LLMConfig
from prod_readiness.adapters.prom import PromAdapter, PromConfig
from prod_readiness.core.context import AuditContext
from prod_readiness.core.models import Capability


@pytest.mark.asyncio
async def test_guard_blocks_undeclared_capabilities():
    ctx = AuditContext(
        k8s=K8sAdapter(K8sConfig()),
        prom=PromAdapter(PromConfig()),
        llm=LLMAdapter(LLMConfig(offline=True)),
    )
    guarded = ctx.guard(needs=frozenset({Capability.K8S}))
    assert guarded.k8s is ctx.k8s
    with pytest.raises(PermissionError, match="capability not declared: prom"):
        _ = guarded.prom
    with pytest.raises(PermissionError, match="capability not declared: llm"):
        _ = guarded.llm
