from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock

import pytest

from prod_readiness.checks.resilience_pdb_exists import ResiliencePdbExists
from prod_readiness.core.context import AuditContext
from prod_readiness.core.models import Status, Target


def _wl(labels: dict[str, str]) -> object:
    return SimpleNamespace(
        spec=SimpleNamespace(
            template=SimpleNamespace(
                metadata=SimpleNamespace(labels=labels),
                spec=SimpleNamespace(containers=[]),
            )
        )
    )


def _pdb(
    *,
    match_labels: dict[str, str] | None = None,
    min_available: int | str | None = None,
    max_unavailable: int | str | None = None,
    match_expressions: list[dict] | None = None,
) -> object:
    selector = SimpleNamespace(
        match_labels=match_labels,
        match_expressions=[
            SimpleNamespace(**e) for e in (match_expressions or [])
        ],
    )
    return SimpleNamespace(
        spec=SimpleNamespace(
            selector=selector,
            min_available=min_available,
            max_unavailable=max_unavailable,
        )
    )


def _ctx(workload, pdbs: list[object]) -> AuditContext:
    k8s = MagicMock()
    k8s.read_workload = AsyncMock(return_value=workload)
    k8s.list_pdbs = AsyncMock(return_value=pdbs)
    return AuditContext(k8s=k8s, prom=MagicMock(), llm=MagicMock())


def _target() -> Target:
    return Target(kind="Deployment", namespace="d", name="a", uid="u")


@pytest.mark.asyncio
async def test_pass_when_pdb_matches_and_min_available_is_1():
    ctx = _ctx(
        _wl({"app": "api"}),
        pdbs=[_pdb(match_labels={"app": "api"}, min_available=1)],
    ).guard(needs=ResiliencePdbExists.needs)
    f = await ResiliencePdbExists().run(ctx, _target())
    assert f.status == Status.PASS


@pytest.mark.asyncio
async def test_pass_when_pdb_matches_and_max_unavailable_is_percent():
    ctx = _ctx(
        _wl({"app": "api"}),
        pdbs=[_pdb(match_labels={"app": "api"}, max_unavailable="50%")],
    ).guard(needs=ResiliencePdbExists.needs)
    f = await ResiliencePdbExists().run(ctx, _target())
    assert f.status == Status.PASS


@pytest.mark.asyncio
async def test_fail_when_no_pdbs_in_namespace():
    ctx = _ctx(_wl({"app": "api"}), pdbs=[]).guard(needs=ResiliencePdbExists.needs)
    f = await ResiliencePdbExists().run(ctx, _target())
    assert f.status == Status.FAIL
    assert "no PodDisruptionBudget" in f.message


@pytest.mark.asyncio
async def test_fail_when_pdbs_exist_but_none_matches():
    ctx = _ctx(
        _wl({"app": "api"}),
        pdbs=[_pdb(match_labels={"app": "web"}, min_available=1)],
    ).guard(needs=ResiliencePdbExists.needs)
    f = await ResiliencePdbExists().run(ctx, _target())
    assert f.status == Status.FAIL
    assert "no matching" in f.message.lower()


@pytest.mark.asyncio
async def test_fail_when_matching_pdb_has_max_unavailable_100_percent():
    ctx = _ctx(
        _wl({"app": "api"}),
        pdbs=[_pdb(match_labels={"app": "api"}, max_unavailable="100%")],
    ).guard(needs=ResiliencePdbExists.needs)
    f = await ResiliencePdbExists().run(ctx, _target())
    assert f.status == Status.FAIL
    assert "leaves no pods" in f.message.lower() or "100%" in f.message
