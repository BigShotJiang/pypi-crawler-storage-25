from __future__ import annotations

from datetime import UTC
from unittest.mock import AsyncMock, MagicMock

import pytest

from prod_readiness.core.check import Check
from prod_readiness.core.context import AuditContext
from prod_readiness.core.models import Capability, Finding, Scope, Severity, Status, Target
from prod_readiness.core.orchestrator import Orchestrator
from prod_readiness.core.registry import register_check, registry_snapshot


@pytest.fixture(autouse=True)
def _isolate_registry():
    from prod_readiness.core.registry import _REGISTRY

    snap = registry_snapshot()
    _REGISTRY.clear()  # start each test with an empty registry
    yield
    snap.restore()


@pytest.mark.asyncio
async def test_full_run_produces_report_with_summary():
    @register_check
    class OkCheck(Check):
        id = "x.ok"
        category = "resources"
        severity = Severity.INFO
        needs = frozenset({Capability.K8S})
        description = "ok"

        async def run(self, ctx, target):
            return Finding(
                check_id=self.id,
                target=target,
                severity=self.severity,
                status=Status.PASS,
                message="ok",
            )

    @register_check
    class ErrCheck(Check):
        id = "x.boom"
        category = "resources"
        severity = Severity.WARNING
        needs = frozenset({Capability.K8S})
        description = "boom"

        async def run(self, ctx, target):
            raise RuntimeError("nope")

    k8s = MagicMock()
    k8s.context_name = "kind-unit"
    k8s.list_targets = AsyncMock(
        return_value=[Target(kind="Deployment", namespace="d", name="a", uid="u")]
    )
    ctx = AuditContext(k8s=k8s, prom=MagicMock(), llm=MagicMock())
    orch = Orchestrator(ctx=ctx, version="0.1.0", concurrency=4, per_check_timeout_s=2.0)

    report = await orch.audit(Scope(namespaces=["d"]))

    assert report.cluster_context == "kind-unit"
    assert len(report.findings) == 2
    statuses = {f.status for f in report.findings}
    assert Status.PASS in statuses
    assert Status.ERROR in statuses
    assert report.summary["fail_or_error"] == 1
    assert report.started_at.tzinfo is UTC


@pytest.mark.asyncio
async def test_timeout_marks_error():
    @register_check
    class Slow(Check):
        id = "x.slow"
        category = "resources"
        severity = Severity.INFO
        needs = frozenset({Capability.K8S})
        description = "slow"

        async def run(self, ctx, target):
            import asyncio

            await asyncio.sleep(5)
            raise AssertionError("should have timed out")

    k8s = MagicMock()
    k8s.context_name = "kind"
    k8s.list_targets = AsyncMock(
        return_value=[Target(kind="Deployment", namespace="d", name="a", uid="u")]
    )
    ctx = AuditContext(k8s=k8s, prom=MagicMock(), llm=MagicMock())
    orch = Orchestrator(ctx=ctx, version="0.1.0", concurrency=2, per_check_timeout_s=0.05)

    report = await orch.audit(Scope(namespaces=["d"]))
    assert report.findings[0].status == Status.ERROR
    assert "timeout" in report.findings[0].message.lower()
