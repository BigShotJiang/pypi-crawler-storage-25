from __future__ import annotations

import subprocess
import time
import uuid
from dataclasses import dataclass
from pathlib import Path

from prod_readiness.adapters.k8s import K8sAdapter, K8sConfig
from prod_readiness.adapters.llm import LLMAdapter, LLMConfig
from prod_readiness.adapters.prom import PromAdapter, PromConfig
from prod_readiness.core.context import AuditContext
from prod_readiness.core.models import Scope
from prod_readiness.core.orchestrator import Orchestrator


@dataclass
class KindCluster:
    name: str
    kubeconfig: Path

    def delete(self) -> None:
        subprocess.run(["kind", "delete", "cluster", "--name", self.name], check=False)


def create_kind() -> KindCluster:
    name = f"pr-golden-{uuid.uuid4().hex[:6]}"
    kubeconfig = Path(f"/tmp/kubeconfig-{name}")
    subprocess.run(
        ["kind", "create", "cluster", "--name", name, "--kubeconfig", str(kubeconfig)],
        check=True,
    )
    return KindCluster(name=name, kubeconfig=kubeconfig)


def apply_manifests(cluster: KindCluster, manifest: Path) -> None:
    subprocess.run(
        ["kubectl", "--kubeconfig", str(cluster.kubeconfig), "apply", "-f", str(manifest)],
        check=True,
    )
    for _ in range(20):
        r = subprocess.run(
            ["kubectl", "--kubeconfig", str(cluster.kubeconfig), "get", "deploy", "-A"],
            capture_output=True,
            text=True,
            check=True,
        )
        if "golden" in r.stdout or "pr-" in r.stdout:
            return
        time.sleep(0.25)


async def run_check_against_cluster(
    cluster: KindCluster, check_id: str
) -> list[dict]:  # type: ignore[type-arg]
    k8s = K8sAdapter(K8sConfig(kubeconfig=str(cluster.kubeconfig)))
    await k8s.connect()
    ctx = AuditContext(
        k8s=k8s,
        prom=PromAdapter(PromConfig()),
        llm=LLMAdapter(LLMConfig(offline=True)),
    )
    try:
        report = await Orchestrator(ctx=ctx, version="golden").audit(
            Scope(checks=[check_id])
        )
        return [f.model_dump(mode="json") for f in report.findings]
    finally:
        await k8s.close()
        await ctx.prom.close()


def normalise(findings: list[dict]) -> list[dict]:  # type: ignore[type-arg]
    for f in findings:
        f["duration_ms"] = 0
        f["target"]["uid"] = "<uid>"
    return sorted(findings, key=lambda f: (f["target"]["namespace"], f["target"]["name"]))
