from __future__ import annotations

# kind_cluster fixture is defined in tests/conftest.py and auto-discovered by pytest.
# This file is kept for potential future golden-specific fixtures.
