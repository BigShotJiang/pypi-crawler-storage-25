from __future__ import annotations

import json
from pathlib import Path

import pytest

from tests.golden._runner import (
    KindCluster,
    apply_manifests,
    normalise,
    run_check_against_cluster,
)

GOLDEN_ROOT = Path("tests/golden")


def _discover() -> list[tuple[str, str]]:
    """Return (check_id, scenario) for every scenario dir with input.yaml + expected.json."""
    out: list[tuple[str, str]] = []
    for check_dir in sorted(GOLDEN_ROOT.iterdir()):
        if not check_dir.is_dir():
            continue
        if check_dir.name.startswith("_") or check_dir.name == "__pycache__":
            continue
        for scenario_dir in sorted(check_dir.iterdir()):
            if not scenario_dir.is_dir():
                continue
            if not (scenario_dir / "input.yaml").exists():
                continue
            if not (scenario_dir / "expected.json").exists():
                continue
            out.append((check_dir.name, scenario_dir.name))
    return out


def _scenario_namespace(scenario_dir: Path) -> str:
    """Parse the Namespace metadata.name from the scenario's input.yaml."""
    text = (scenario_dir / "input.yaml").read_text()
    for doc in text.split("---"):
        lines = [ln.strip() for ln in doc.splitlines() if ln.strip()]
        if any(ln == "kind: Namespace" for ln in lines):
            for ln in lines:
                if ln.startswith("name:"):
                    return ln.split(":", 1)[1].strip()
    raise AssertionError(f"No Namespace found in {scenario_dir}")


SCENARIOS = _discover()


@pytest.mark.golden
@pytest.mark.asyncio
@pytest.mark.parametrize(
    "check_id,scenario",
    SCENARIOS,
    ids=[f"{c}/{s}" for c, s in SCENARIOS],
)
async def test_golden_scenario(
    kind_cluster: KindCluster, check_id: str, scenario: str
) -> None:
    scenario_dir = GOLDEN_ROOT / check_id / scenario
    apply_manifests(kind_cluster, scenario_dir / "input.yaml")

    ns = _scenario_namespace(scenario_dir)
    actual = await run_check_against_cluster(kind_cluster, check_id)
    actual = normalise([f for f in actual if f["target"]["namespace"] == ns])
    expected = json.loads((scenario_dir / "expected.json").read_text())

    assert actual == expected
