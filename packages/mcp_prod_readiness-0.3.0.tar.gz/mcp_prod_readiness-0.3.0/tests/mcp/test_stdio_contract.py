from __future__ import annotations

import asyncio
import json
import os
import sys
from pathlib import Path

import pytest

from tests.golden._runner import KindCluster, apply_manifests


async def _readline_timeout(reader: asyncio.StreamReader, deadline_s: float = 10.0) -> bytes:
    """Read a line with a deadline, raising asyncio.TimeoutError on expiry."""
    async with asyncio.timeout(deadline_s):
        return await reader.readline()


@pytest.mark.mcp_contract
@pytest.mark.asyncio
async def test_mcp_list_checks_over_stdio(kind_cluster: KindCluster) -> None:
    apply_manifests(
        kind_cluster,
        Path("tests/golden/resources.requests-and-limits-set/pass/input.yaml"),
    )

    proc = await asyncio.create_subprocess_exec(
        sys.executable,
        "-m",
        "prod_readiness.cli",
        "serve-mcp",
        stdin=asyncio.subprocess.PIPE,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        env={**os.environ, "KUBECONFIG": str(kind_cluster.kubeconfig)},
    )
    assert proc.stdin is not None
    assert proc.stdout is not None

    try:
        # 1. Send initialize
        init = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "initialize",
            "params": {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "clientInfo": {"name": "t", "version": "0"},
            },
        }
        proc.stdin.write((json.dumps(init) + "\n").encode())
        await proc.stdin.drain()

        # 2. Read initialize response
        init_line = await _readline_timeout(proc.stdout, deadline_s=15.0)
        init_resp = json.loads(init_line)
        assert init_resp.get("id") == 1, f"Unexpected init response: {init_resp}"

        # 3. Send notifications/initialized (good practice; harmless if not required)
        initialized_notif = {
            "jsonrpc": "2.0",
            "method": "notifications/initialized",
            "params": {},
        }
        proc.stdin.write((json.dumps(initialized_notif) + "\n").encode())
        await proc.stdin.drain()

        # 4. Send tools/list
        list_req = {"jsonrpc": "2.0", "id": 2, "method": "tools/list"}
        proc.stdin.write((json.dumps(list_req) + "\n").encode())
        await proc.stdin.drain()

        # 5. Read tools/list response (skip any non-matching lines)
        tools_resp: dict | None = None  # type: ignore[type-arg]
        for _ in range(10):
            raw = await _readline_timeout(proc.stdout, deadline_s=10.0)
            if not raw:
                break
            try:
                msg = json.loads(raw)
            except json.JSONDecodeError:
                continue
            if msg.get("id") == 2:
                tools_resp = msg
                break

        assert tools_resp is not None, "Did not receive tools/list response"
        assert "result" in tools_resp, f"tools/list error: {tools_resp}"
        tool_names = {t["name"] for t in tools_resp["result"]["tools"]}
        assert {"audit_cluster", "audit_workload", "list_checks"}.issubset(tool_names), (
            f"Missing tools; got: {tool_names}"
        )
    finally:
        proc.terminate()
        await proc.wait()
