from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

import pytest

from tests.golden._runner import KindCluster, apply_manifests


@pytest.mark.integration
def test_cli_audit_against_kind(kind_cluster: KindCluster, tmp_path: Path) -> None:
    manifest = Path("tests/golden/resources.requests-and-limits-set/pass/input.yaml")
    apply_manifests(kind_cluster, manifest)

    env = {
        **os.environ,
        "KUBECONFIG": str(kind_cluster.kubeconfig),
    }
    out = tmp_path / "report.json"
    result = subprocess.run(
        [
            sys.executable,
            "-m",
            "prod_readiness.cli",
            "audit",
            "--namespace",
            "golden-pass",
            "--check",
            "resources.requests-and-limits-set",
            "--format",
            "json",
            "--output",
            str(out),
        ],
        env=env,
        check=False,
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, f"stdout={result.stdout}\nstderr={result.stderr}"
    data = json.loads(out.read_text())
    assert any(f["check_id"] == "resources.requests-and-limits-set" for f in data["findings"])
