from __future__ import annotations

from prod_readiness.core.models import Report


def render_markdown(r: Report) -> str:
    lines: list[str] = ["# Production Readiness Report", ""]
    lines.append(f"- **Cluster:** `{r.cluster_context}`")
    lines.append(f"- **Started:** {r.started_at.isoformat()}")
    lines.append(f"- **Finished:** {r.finished_at.isoformat()}")
    lines.append(f"- **Tool:** mcp-prod-readiness {r.version}")
    lines.append("")
    lines.append("## Summary")
    for k, v in sorted(r.summary.items()):
        lines.append(f"- `{k}`: {v}")
    lines.append("")
    lines.append("## Findings")
    for f in r.findings:
        icon = {"pass": "✅", "fail": "❌", "skip": "⚪", "error": "⚠️"}[f.status.value]
        lines.append(
            f"### {icon} `{f.check_id}` — {f.severity.value.upper()} — "
            f"{f.target.kind}/{f.target.namespace}/{f.target.name}"
        )
        lines.append("")
        lines.append(f"- **Status:** {f.status.value}")
        lines.append(f"- **Message:** {f.message}")
        if f.evidence:
            lines.append(f"- **Evidence:** `{f.evidence}`")
        if f.remediation:
            lines.append("")
            lines.append("**Remediation:**")
            lines.append("")
            lines.append("```yaml")
            lines.append(f.remediation)
            lines.append("```")
        if f.ai_reasoning:
            lines.append("")
            lines.append("**AI reasoning:**")
            lines.append("")
            lines.append(f.ai_reasoning)
        lines.append("")
    while lines and lines[-1] == "":
        lines.pop()
    return "\n".join(lines) + "\n"
