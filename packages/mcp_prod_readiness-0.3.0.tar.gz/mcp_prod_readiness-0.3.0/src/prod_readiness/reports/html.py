from __future__ import annotations

from html import escape

from prod_readiness.core.models import Report


def render_html(r: Report) -> str:
    rows: list[str] = []
    for f in r.findings:
        rows.append(
            "<tr>"
            f"<td>{escape(f.status.value)}</td>"
            f"<td>{escape(f.severity.value)}</td>"
            f"<td>{escape(f.check_id)}</td>"
            f"<td>{escape(f.target.kind)}/{escape(f.target.namespace)}/"
            f"{escape(f.target.name)}</td>"
            f"<td>{escape(f.message)}</td>"
            "</tr>"
        )
    return (
        "<!doctype html>\n<html><head><meta charset='utf-8'>"
        "<title>Prod-Readiness Report</title></head><body>"
        f"<h1>Prod-Readiness Report — {escape(r.cluster_context)}</h1>"
        "<table border='1'><tr><th>Status</th><th>Severity</th>"
        "<th>Check</th><th>Target</th><th>Message</th></tr>"
        + "".join(rows)
        + "</table></body></html>\n"
    )
