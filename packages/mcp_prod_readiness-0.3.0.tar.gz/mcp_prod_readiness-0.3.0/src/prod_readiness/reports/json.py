from __future__ import annotations

from prod_readiness.core.models import Report


def render_json(r: Report) -> str:
    return r.model_dump_json(indent=2)
