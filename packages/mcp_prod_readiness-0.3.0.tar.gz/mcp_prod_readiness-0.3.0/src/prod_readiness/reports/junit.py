from __future__ import annotations

from xml.sax.saxutils import escape

from prod_readiness.core.models import Report, Status


def render_junit(r: Report) -> str:
    failures = sum(1 for f in r.findings if f.status == Status.FAIL)
    errors = sum(1 for f in r.findings if f.status == Status.ERROR)
    skipped = sum(1 for f in r.findings if f.status == Status.SKIP)
    out: list[str] = []
    out.append('<?xml version="1.0" encoding="UTF-8"?>')
    out.append(
        f'<testsuite name="prod-readiness" tests="{len(r.findings)}" '
        f'failures="{failures}" errors="{errors}" skipped="{skipped}">'
    )
    for f in r.findings:
        classname = f"{f.target.kind}.{f.target.namespace}.{f.target.name}"
        name = escape(f.check_id)
        out.append(f'<testcase classname="{escape(classname)}" name="{name}">')
        if f.status == Status.FAIL:
            out.append(
                f'<failure message="{escape(f.message)}" '
                f'type="{f.severity.value}"></failure>'
            )
        elif f.status == Status.ERROR:
            out.append(f'<error message="{escape(f.message)}"></error>')
        elif f.status == Status.SKIP:
            out.append("<skipped/>")
        out.append("</testcase>")
    out.append("</testsuite>")
    return "\n".join(out) + "\n"
