from __future__ import annotations

from typing import Any

from prod_readiness.core.check import Check
from prod_readiness.core.context import GuardedContext
from prod_readiness.core.models import Capability, Finding, Severity, Status, Target
from prod_readiness.core.registry import register_check

_REMEDIATION_TEMPLATE = (
    "spec:\n"
    "  template:\n"
    "    spec:\n"
    "      containers:\n"
    "        - name: <container>\n"
    "          resources:\n"
    "            requests:\n"
    "              cpu: 100m\n"
    "              memory: 128Mi\n"
    "            limits:\n"
    "              memory: 256Mi\n"
)


@register_check
class ResourcesRequestsAndLimitsSet(Check):
    id = "resources.requests-and-limits-set"
    category = "resources"
    severity = Severity.BLOCKER
    needs = frozenset({Capability.K8S})
    description = (
        "Every container has CPU and memory requests; memory limit is set."
    )

    async def run(self, ctx: GuardedContext, target: Target) -> Finding:  # type: ignore[override]
        wl = await ctx.k8s.read_workload(target)
        containers = wl.spec.template.spec.containers or []
        per_container: list[dict[str, Any]] = []
        all_ok = True
        for c in containers:
            missing: list[str] = []
            requests = getattr(c.resources, "requests", None) or {}
            limits = getattr(c.resources, "limits", None) or {}
            if "cpu" not in requests:
                missing.append("requests.cpu")
            if "memory" not in requests:
                missing.append("requests.memory")
            if "memory" not in limits:
                missing.append("limits.memory")
            if missing:
                all_ok = False
            per_container.append({"name": c.name, "missing": missing})
        if all_ok:
            return Finding(
                check_id=self.id,
                target=target,
                severity=self.severity,
                status=Status.PASS,
                message="All containers declare CPU+memory requests and memory limit.",
                evidence={"containers": per_container},
            )
        reasons: list[str] = []
        if any("requests.cpu" in c["missing"] for c in per_container):
            reasons.append("missing CPU request")
        if any("requests.memory" in c["missing"] for c in per_container):
            reasons.append("missing memory request")
        if any("limits.memory" in c["missing"] for c in per_container):
            reasons.append("missing memory limit")
        return Finding(
            check_id=self.id,
            target=target,
            severity=self.severity,
            status=Status.FAIL,
            message="Resource gaps: " + ", ".join(reasons) + ".",
            evidence={"containers": per_container},
            remediation=_REMEDIATION_TEMPLATE,
        )
