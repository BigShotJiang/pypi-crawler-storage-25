from __future__ import annotations

from typing import Any

from prod_readiness.core.check import Check
from prod_readiness.core.context import GuardedContext
from prod_readiness.core.models import Capability, Finding, Severity, Status, Target
from prod_readiness.core.registry import register_check

_REMEDIATION_DEPLOYMENT = (
    "spec:\n"
    "  replicas: 3\n"
)

_REMEDIATION_STATEFULSET = (
    "spec:\n"
    "  replicas: 3\n"
    "  template:\n"
    "    spec:\n"
    "      topologySpreadConstraints:\n"
    "        - maxSkew: 1\n"
    "          topologyKey: kubernetes.io/hostname\n"
    "          whenUnsatisfiable: DoNotSchedule\n"
    "          labelSelector:\n"
    "            matchLabels:\n"
    "              app: <label-value>\n"
)


def _has_pod_anti_affinity(pod_spec: Any) -> bool:
    affinity = getattr(pod_spec, "affinity", None)
    if affinity is None:
        return False
    return getattr(affinity, "pod_anti_affinity", None) is not None


def _has_topology_spread(pod_spec: Any) -> bool:
    tsc = getattr(pod_spec, "topology_spread_constraints", None)
    return bool(tsc)


@register_check
class ResilienceReplicasGe2(Check):
    id = "resilience.replicas-ge-2"
    category = "resilience"
    severity = Severity.BLOCKER
    needs = frozenset({Capability.K8S})
    description = (
        "Workload runs \u22652 replicas; StatefulSets additionally require "
        "anti-affinity or topology spread constraints."
    )

    async def run(self, ctx: GuardedContext, target: Target) -> Finding:  # type: ignore[override]
        wl = await ctx.k8s.read_workload(target)
        replicas = getattr(wl.spec, "replicas", None) or 0
        pod_spec = wl.spec.template.spec
        anti_affinity = _has_pod_anti_affinity(pod_spec)
        topology = _has_topology_spread(pod_spec)

        evidence: dict[str, Any] = {
            "replicas": replicas,
            "pod_anti_affinity": anti_affinity,
            "topology_spread_constraints": topology,
        }

        if replicas < 2:
            remediation = (
                _REMEDIATION_DEPLOYMENT
                if target.kind == "Deployment"
                else _REMEDIATION_STATEFULSET
            )
            return Finding(
                check_id=self.id,
                target=target,
                severity=self.severity,
                status=Status.FAIL,
                message=f"replicas={replicas}; require \u22652 for availability.",
                evidence=evidence,
                remediation=remediation,
            )

        if target.kind == "StatefulSet" and not (anti_affinity or topology):
            return Finding(
                check_id=self.id,
                target=target,
                severity=self.severity,
                status=Status.FAIL,
                message=(
                    "StatefulSet has \u22652 replicas but no pod anti-affinity or "
                    "topology spread constraints \u2014 replicas may co-locate."
                ),
                evidence=evidence,
                remediation=_REMEDIATION_STATEFULSET,
            )

        return Finding(
            check_id=self.id,
            target=target,
            severity=self.severity,
            status=Status.PASS,
            message=f"replicas={replicas}; spread hints present where required.",
            evidence=evidence,
        )
