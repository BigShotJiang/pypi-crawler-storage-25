from __future__ import annotations

from typing import Any

from prod_readiness.adapters.k8s import pdb_matches_workload
from prod_readiness.core.check import Check
from prod_readiness.core.context import GuardedContext
from prod_readiness.core.models import Capability, Finding, Severity, Status, Target
from prod_readiness.core.registry import register_check

_REMEDIATION = (
    "apiVersion: policy/v1\n"
    "kind: PodDisruptionBudget\n"
    "metadata:\n"
    "  name: <workload>-pdb\n"
    "  namespace: <workload-namespace>\n"
    "spec:\n"
    "  minAvailable: 1\n"
    "  selector:\n"
    "    matchLabels:\n"
    "      app: <workload-label>\n"
)


def _preserves_availability(pdb: Any) -> bool:
    min_available = getattr(pdb.spec, "min_available", None)
    max_unavailable = getattr(pdb.spec, "max_unavailable", None)

    if min_available is not None:
        if isinstance(min_available, int):
            return min_available >= 1
        if isinstance(min_available, str) and min_available.endswith("%"):
            return int(min_available.rstrip("%")) > 0
        return False

    if max_unavailable is not None:
        if isinstance(max_unavailable, int):
            return max_unavailable == 0
        if isinstance(max_unavailable, str) and max_unavailable.endswith("%"):
            return int(max_unavailable.rstrip("%")) < 100
        return False

    return False


@register_check
class ResiliencePdbExists(Check):
    id = "resilience.pdb-exists"
    category = "resilience"
    severity = Severity.WARNING
    needs = frozenset({Capability.K8S})
    description = (
        "A matching PodDisruptionBudget exists that keeps at least one pod available."
    )

    async def run(self, ctx: GuardedContext, target: Target) -> Finding:  # type: ignore[override]
        wl = await ctx.k8s.read_workload(target)
        pdbs = await ctx.k8s.list_pdbs(target.namespace)

        evidence: dict[str, Any] = {"pdbs_in_namespace": len(pdbs)}
        if not pdbs:
            return Finding(
                check_id=self.id,
                target=target,
                severity=self.severity,
                status=Status.FAIL,
                message="no PodDisruptionBudget found in namespace.",
                evidence=evidence,
                remediation=_REMEDIATION,
            )

        matching = [p for p in pdbs if pdb_matches_workload(p, wl)]
        evidence["matching_pdbs"] = len(matching)
        if not matching:
            return Finding(
                check_id=self.id,
                target=target,
                severity=self.severity,
                status=Status.FAIL,
                message=(
                    f"{len(pdbs)} PDB(s) in namespace but no matching selector "
                    "for this workload."
                ),
                evidence=evidence,
                remediation=_REMEDIATION,
            )

        for pdb in matching:
            if _preserves_availability(pdb):
                return Finding(
                    check_id=self.id,
                    target=target,
                    severity=self.severity,
                    status=Status.PASS,
                    message=f"{len(matching)} matching PDB(s) preserve availability.",
                    evidence=evidence,
                )

        return Finding(
            check_id=self.id,
            target=target,
            severity=self.severity,
            status=Status.FAIL,
            message=(
                "Matching PDB exists but leaves no pods available "
                "(e.g. maxUnavailable=100%)."
            ),
            evidence=evidence,
            remediation=_REMEDIATION,
        )
