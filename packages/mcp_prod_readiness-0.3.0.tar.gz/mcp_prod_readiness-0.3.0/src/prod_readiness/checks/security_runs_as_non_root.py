from __future__ import annotations

from typing import Any

from prod_readiness.core.check import Check
from prod_readiness.core.context import GuardedContext
from prod_readiness.core.models import Capability, Finding, Severity, Status, Target
from prod_readiness.core.registry import register_check

_REMEDIATION = (
    "spec:\n"
    "  template:\n"
    "    spec:\n"
    "      securityContext:\n"
    "        runAsNonRoot: true\n"
    "        runAsUser: 1000\n"
    "      containers:\n"
    "        - name: <container>\n"
    "          securityContext:\n"
    "            allowPrivilegeEscalation: false\n"
    "            readOnlyRootFilesystem: true\n"
    "            capabilities:\n"
    '              drop: ["ALL"]\n'
)


def _attr(obj: Any, name: str) -> Any:
    if obj is None:
        return None
    return getattr(obj, name, None)


@register_check
class SecurityRunsAsNonRoot(Check):
    id = "security.runs-as-non-root"
    category = "security"
    severity = Severity.BLOCKER
    needs = frozenset({Capability.K8S})
    description = (
        "Every container runs as non-root with privilege-escalation disabled."
    )

    async def run(self, ctx: GuardedContext, target: Target) -> Finding:  # type: ignore[override]
        wl = await ctx.k8s.read_workload(target)
        pod_spec = wl.spec.template.spec
        pod_sc = _attr(pod_spec, "security_context")
        pod_runs_as_non_root = _attr(pod_sc, "run_as_non_root") is True
        pod_run_as_user = _attr(pod_sc, "run_as_user")

        per_container: list[dict[str, Any]] = []
        any_fail = False
        for c in pod_spec.containers or []:
            sc = _attr(c, "security_context")
            c_runs_as_non_root = _attr(sc, "run_as_non_root")
            c_run_as_user = _attr(sc, "run_as_user")
            c_allow_priv = _attr(sc, "allow_privilege_escalation")

            effective_non_root = (
                c_runs_as_non_root
                if c_runs_as_non_root is not None
                else pod_runs_as_non_root
            )
            effective_uid = (
                c_run_as_user if c_run_as_user is not None else pod_run_as_user
            )

            problems: list[str] = []
            if effective_non_root is not True:
                problems.append("runAsNonRoot")
            if effective_uid == 0:
                problems.append("runAsUser=0")
            if c_allow_priv is not False:
                problems.append("allowPrivilegeEscalation")

            if problems:
                any_fail = True
            per_container.append({"name": c.name, "problems": problems})

        if not any_fail:
            return Finding(
                check_id=self.id,
                target=target,
                severity=self.severity,
                status=Status.PASS,
                message="All containers run as non-root with privilege escalation disabled.",
                evidence={"containers": per_container},
            )

        reason_bits = sorted(
            {p for c in per_container for p in c["problems"]}
        )
        return Finding(
            check_id=self.id,
            target=target,
            severity=self.severity,
            status=Status.FAIL,
            message="Security gaps: " + ", ".join(reason_bits) + ".",
            evidence={"containers": per_container},
            remediation=_REMEDIATION,
        )
