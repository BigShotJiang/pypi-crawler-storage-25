from __future__ import annotations

from typing import Any

from prod_readiness.core.check import Check
from prod_readiness.core.context import GuardedContext
from prod_readiness.core.models import Capability, Finding, Severity, Status, Target
from prod_readiness.core.registry import register_check

_REMEDIATION = (
    "spec:\n"
    "  template:\n"
    "    metadata:\n"
    "      annotations:\n"
    '        prometheus.io/scrape: "true"\n'
    '        prometheus.io/port: "<metrics-port>"\n'
    '        prometheus.io/path: "/metrics"\n'
)


@register_check
class ObservabilityPrometheusScrapeConfigured(Check):
    id = "observability.prometheus-scrape-configured"
    category = "observability"
    severity = Severity.WARNING
    needs = frozenset({Capability.K8S, Capability.PROM})
    description = (
        "Pod template has Prometheus scrape annotations and (when available) "
        "Prometheus reports samples within the last 15 minutes."
    )

    async def run(self, ctx: GuardedContext, target: Target) -> Finding:  # type: ignore[override]
        wl = await ctx.k8s.read_workload(target)
        tmpl_meta = getattr(wl.spec.template, "metadata", None)
        raw = getattr(tmpl_meta, "annotations", None)
        annotations: dict[str, str] = raw if isinstance(raw, dict) else {}
        has_annotation = annotations.get("prometheus.io/scrape") == "true"
        evidence: dict[str, Any] = {
            "scrape_annotation": has_annotation,
            "prom_available": ctx.prom.available,
        }

        if not has_annotation and not ctx.prom.available:
            return Finding(
                check_id=self.id,
                target=target,
                severity=self.severity,
                status=Status.FAIL,
                message=(
                    "No scrape annotation on pod template; "
                    "ServiceMonitor/PodMonitor lookup not implemented yet."
                ),
                evidence=evidence,
                remediation=_REMEDIATION,
            )

        if has_annotation and not ctx.prom.available:
            return Finding(
                check_id=self.id,
                target=target,
                severity=self.severity,
                status=Status.SKIP,
                message=(
                    "Scrape annotation present but no Prometheus configured — "
                    "cannot verify live samples."
                ),
                evidence=evidence,
            )

        promql = f'last_over_time(up{{namespace="{target.namespace}"}}[15m])'
        try:
            data = await ctx.prom.query(promql)
        except Exception as exc:
            return Finding(
                check_id=self.id,
                target=target,
                severity=self.severity,
                status=Status.SKIP,
                message=f"Prometheus query failed: {exc}",
                evidence=evidence,
            )

        samples = data.get("result") or []
        evidence["sample_count"] = len(samples)
        if not has_annotation and not samples:
            return Finding(
                check_id=self.id,
                target=target,
                severity=self.severity,
                status=Status.FAIL,
                message="No scrape annotation and Prometheus has no samples in last 15m.",
                evidence=evidence,
                remediation=_REMEDIATION,
            )
        if not samples:
            return Finding(
                check_id=self.id,
                target=target,
                severity=self.severity,
                status=Status.FAIL,
                message="Target is configured for scrape but Prometheus has no samples in last 15m.",
                evidence=evidence,
                remediation=_REMEDIATION,
            )
        return Finding(
            check_id=self.id,
            target=target,
            severity=self.severity,
            status=Status.PASS,
            message=f"Scrape annotation present; Prometheus returned {len(samples)} samples.",
            evidence=evidence,
        )
