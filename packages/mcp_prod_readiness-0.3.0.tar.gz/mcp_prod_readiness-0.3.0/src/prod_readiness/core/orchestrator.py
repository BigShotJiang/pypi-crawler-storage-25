from __future__ import annotations

import asyncio
import time
from collections import Counter
from dataclasses import dataclass
from datetime import UTC, datetime

from prod_readiness.core.check import Check
from prod_readiness.core.context import AuditContext
from prod_readiness.core.models import (
    Finding,
    Report,
    Scope,
    Severity,
    Status,
    Target,
)
from prod_readiness.core.registry import get_check, list_checks
from prod_readiness.core.tracing import tracer


@dataclass
class Orchestrator:
    ctx: AuditContext
    version: str
    concurrency: int = 16
    per_check_timeout_s: float = 10.0

    async def audit(self, scope: Scope) -> Report:
        started = datetime.now(UTC)
        targets = await self.ctx.k8s.list_targets(
            namespaces=scope.namespaces, label_selector=scope.label_selector
        )
        check_classes = self._select_checks(scope)
        sem = asyncio.Semaphore(self.concurrency)

        async def _run_one(cls: type[Check], target: Target) -> Finding:
            async with sem:
                instance = cls()
                start = time.perf_counter()
                guarded = self.ctx.guard(needs=instance.needs)
                with tracer().start_as_current_span("check.run") as span:
                    span.set_attribute("check.id", cls.id)
                    span.set_attribute("target.kind", target.kind)
                    span.set_attribute("target.namespace", target.namespace)
                    span.set_attribute("target.name", target.name)
                    try:
                        coro = instance.run(guarded, target)  # type: ignore[arg-type]
                        f = await asyncio.wait_for(
                            coro, timeout=self.per_check_timeout_s
                        )
                        duration_ms = int((time.perf_counter() - start) * 1000)
                        span.set_attribute("duration_ms", duration_ms)
                        span.set_attribute("status", f.status.value)
                        return f.model_copy(update={"duration_ms": duration_ms})
                    except TimeoutError:
                        span.set_attribute("status", "error")
                        return Finding(
                            check_id=cls.id,
                            target=target,
                            severity=cls.severity,
                            status=Status.ERROR,
                            message=f"timeout after {self.per_check_timeout_s}s",
                            duration_ms=int((time.perf_counter() - start) * 1000),
                        )
                    except Exception as exc:
                        span.set_attribute("status", "error")
                        span.record_exception(exc)
                        return Finding(
                            check_id=cls.id,
                            target=target,
                            severity=cls.severity,
                            status=Status.ERROR,
                            message=f"{type(exc).__name__}: {exc}",
                            duration_ms=int((time.perf_counter() - start) * 1000),
                        )

        tasks = [
            asyncio.create_task(_run_one(cls, t))
            for cls in check_classes
            for t in targets
        ]
        findings = list(await asyncio.gather(*tasks)) if tasks else []
        finished = datetime.now(UTC)
        return Report(
            cluster_context=self.ctx.k8s.context_name,
            scope=scope,
            started_at=started,
            finished_at=finished,
            findings=findings,
            summary=_summarise(findings),
            version=self.version,
        )

    def _select_checks(self, scope: Scope) -> list[type[Check]]:
        if scope.checks:
            return [get_check(cid) for cid in scope.checks]
        return list_checks()


def _summarise(findings: list[Finding]) -> dict[str, int]:
    by_status = Counter(f.status.value for f in findings)
    by_severity = Counter(
        f.severity.value for f in findings if f.status in {Status.FAIL, Status.ERROR}
    )
    return {
        **by_status,
        **{f"severity.{k}": v for k, v in by_severity.items()},
        "fail_or_error": by_status.get("fail", 0) + by_status.get("error", 0),
        "total": len(findings),
    }


def worst_severity(findings: list[Finding]) -> Severity | None:
    order = {Severity.INFO: 0, Severity.WARNING: 1, Severity.BLOCKER: 2}
    worst: Severity | None = None
    for f in findings:
        if f.status not in {Status.FAIL, Status.ERROR}:
            continue
        if worst is None or order[f.severity] > order[worst]:
            worst = f.severity
    return worst
