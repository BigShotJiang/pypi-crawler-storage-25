from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_serializer


class Severity(StrEnum):
    BLOCKER = "blocker"
    WARNING = "warning"
    INFO = "info"


class Status(StrEnum):
    PASS = "pass"
    FAIL = "fail"
    SKIP = "skip"
    ERROR = "error"


class Capability(StrEnum):
    K8S = "k8s"
    PROM = "prom"
    LLM = "llm"


class Target(BaseModel):
    model_config = ConfigDict(frozen=True)
    kind: Literal["Deployment", "StatefulSet"]
    namespace: str
    name: str
    uid: str


class Finding(BaseModel):
    check_id: str
    target: Target
    severity: Severity
    status: Status
    message: str
    evidence: dict[str, Any] = Field(default_factory=dict)
    remediation: str | None = None
    ai_reasoning: str | None = None
    duration_ms: int = 0


class Scope(BaseModel):
    contexts: list[str] | None = None
    namespaces: list[str] | None = None
    label_selector: str | None = None
    checks: list[str] | None = None


class CheckMeta(BaseModel):
    id: str
    category: str
    severity: Severity
    needs: frozenset[Capability]
    description: str

    @field_serializer("needs")
    def _sort_needs(self, v: frozenset[Capability]) -> list[str]:
        return sorted(c.value for c in v)


class Report(BaseModel):
    cluster_context: str
    scope: Scope
    started_at: datetime
    finished_at: datetime
    findings: list[Finding]
    summary: dict[str, Any]
    version: str


class Explanation(BaseModel):
    finding: Finding
    extra_reasoning: str
    remediation_patch_yaml: str | None = None


class ReportDiff(BaseModel):
    new_failures: list[Finding]
    fixed: list[Finding]
    unchanged: list[Finding]
