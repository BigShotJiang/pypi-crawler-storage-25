from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, ClassVar

from prod_readiness.core.models import Capability, Finding, Severity, Target

if TYPE_CHECKING:
    from prod_readiness.core.context import AuditContext


class Check(ABC):
    id: ClassVar[str]
    category: ClassVar[str]
    severity: ClassVar[Severity]
    needs: ClassVar[frozenset[Capability]]
    description: ClassVar[str]

    @abstractmethod
    async def run(self, ctx: AuditContext, target: Target) -> Finding: ...
