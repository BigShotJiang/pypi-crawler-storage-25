from __future__ import annotations

from dataclasses import dataclass

from prod_readiness.core.check import Check

_REGISTRY: dict[str, type[Check]] = {}


def register_check(cls: type[Check]) -> type[Check]:
    if cls.id in _REGISTRY:
        raise ValueError(f"check id {cls.id!r} already registered")
    _REGISTRY[cls.id] = cls
    return cls


def get_check(check_id: str) -> type[Check]:
    return _REGISTRY[check_id]


def list_checks() -> list[type[Check]]:
    return sorted(_REGISTRY.values(), key=lambda c: c.id)


@dataclass
class _Snapshot:
    saved: dict[str, type[Check]]

    def restore(self) -> None:
        _REGISTRY.clear()
        _REGISTRY.update(self.saved)


def registry_snapshot() -> _Snapshot:
    return _Snapshot(saved=dict(_REGISTRY))
