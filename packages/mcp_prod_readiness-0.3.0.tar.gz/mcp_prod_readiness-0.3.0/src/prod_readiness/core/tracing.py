from __future__ import annotations

from opentelemetry import trace
from opentelemetry.trace import Tracer

_NAME = "prod-readiness"


def tracer() -> Tracer:
    return trace.get_tracer(_NAME)
