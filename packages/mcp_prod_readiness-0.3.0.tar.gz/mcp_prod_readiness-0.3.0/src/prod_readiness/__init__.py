# src/prod_readiness/__init__.py
__version__ = "0.3.0"
