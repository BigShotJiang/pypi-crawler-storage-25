from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from kubernetes_asyncio import client as k8s_client
from kubernetes_asyncio import config as k8s_config

from prod_readiness.core.models import Target


def pdb_matches_workload(pdb: Any, workload: Any) -> bool:
    """True iff the PDB's selector matches the workload's pod-template labels.

    Only `matchLabels` is supported in v1. A PDB that uses `matchExpressions`
    is treated as non-matching so the check errs on the side of "no PDB found".
    """
    selector = getattr(pdb.spec, "selector", None)
    if selector is None:
        return False
    if getattr(selector, "match_expressions", None):
        return False
    match_labels = getattr(selector, "match_labels", None) or {}
    pod_labels = getattr(workload.spec.template.metadata, "labels", None) or {}
    return all(pod_labels.get(k) == v for k, v in match_labels.items())


@dataclass
class K8sConfig:
    context: str | None = None
    in_cluster: bool = False
    kubeconfig: str | None = None


class K8sAdapter:
    def __init__(self, cfg: K8sConfig) -> None:
        self.cfg = cfg
        self.context_name: str = cfg.context or "current-context"
        self._apps: k8s_client.AppsV1Api | None = None
        self._core: k8s_client.CoreV1Api | None = None
        self._policy: k8s_client.PolicyV1Api | None = None
        self._api_client: k8s_client.ApiClient | None = None
        self._read_cache: dict[str, Any] = {}

    async def connect(self) -> None:
        if self.cfg.in_cluster:
            k8s_config.load_incluster_config()  # type: ignore[no-untyped-call]
        else:
            await k8s_config.load_kube_config(
                config_file=self.cfg.kubeconfig, context=self.cfg.context
            )
        self._api_client = k8s_client.ApiClient()
        self._apps = k8s_client.AppsV1Api(self._api_client)
        self._core = k8s_client.CoreV1Api(self._api_client)
        self._policy = k8s_client.PolicyV1Api(self._api_client)

    async def close(self) -> None:
        self._read_cache.clear()
        if self._api_client is not None:
            await self._api_client.close()

    async def list_namespaces(self) -> list[str]:
        assert self._core is not None
        resp = await self._core.list_namespace()
        return [ns.metadata.name for ns in resp.items]

    async def list_targets(
        self,
        *,
        namespaces: list[str] | None,
        label_selector: str | None,
    ) -> list[Target]:
        assert self._apps is not None
        if namespaces is None:
            namespaces = await self.list_namespaces()
        out: list[Target] = []
        for ns in namespaces:
            deps = await self._apps.list_namespaced_deployment(
                namespace=ns, label_selector=label_selector or ""
            )
            for d in deps.items:
                out.append(
                    Target(
                        kind="Deployment",
                        namespace=d.metadata.namespace,
                        name=d.metadata.name,
                        uid=d.metadata.uid,
                    )
                )
            sts = await self._apps.list_namespaced_stateful_set(
                namespace=ns, label_selector=label_selector or ""
            )
            for s in sts.items:
                out.append(
                    Target(
                        kind="StatefulSet",
                        namespace=s.metadata.namespace,
                        name=s.metadata.name,
                        uid=s.metadata.uid,
                    )
                )
        return out

    async def read_workload(self, target: Target) -> Any:
        cached = self._read_cache.get(target.uid)
        if cached is not None:
            return cached
        assert self._apps is not None
        result: Any
        if target.kind == "Deployment":
            result = await self._apps.read_namespaced_deployment(
                name=target.name, namespace=target.namespace
            )
        else:
            result = await self._apps.read_namespaced_stateful_set(
                name=target.name, namespace=target.namespace
            )
        self._read_cache[target.uid] = result
        return result

    async def list_pdbs(self, namespace: str) -> list[Any]:
        assert self._policy is not None
        resp = await self._policy.list_namespaced_pod_disruption_budget(
            namespace=namespace
        )
        return list(resp.items)
