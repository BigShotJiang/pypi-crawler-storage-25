from __future__ import annotations

import asyncio
import json as json_lib
import os
import sys
from pathlib import Path

import typer

import prod_readiness.checks  # noqa: F401 — registers checks
from prod_readiness import __version__
from prod_readiness.adapters.k8s import K8sAdapter, K8sConfig
from prod_readiness.adapters.llm import LLMAdapter, LLMConfig
from prod_readiness.adapters.prom import PromAdapter, PromConfig
from prod_readiness.core.context import AuditContext
from prod_readiness.core.models import CheckMeta, Report, Scope, Severity
from prod_readiness.core.orchestrator import Orchestrator, worst_severity
from prod_readiness.core.registry import list_checks
from prod_readiness.reports.html import render_html
from prod_readiness.reports.json import render_json
from prod_readiness.reports.junit import render_junit
from prod_readiness.reports.markdown import render_markdown

app = typer.Typer(add_completion=False, no_args_is_help=True, help="Kubernetes prod-readiness auditor.")


def _render(report: Report, fmt: str) -> str:
    return {
        "json": render_json,
        "md": render_markdown,
        "markdown": render_markdown,
        "junit": render_junit,
        "html": render_html,
    }[fmt](report)


def _exit_code(report: Report, fail_on: str) -> int:
    worst = worst_severity(report.findings)
    if worst is None:
        return 0
    thresholds = {"blocker": {Severity.BLOCKER}, "warning": {Severity.BLOCKER, Severity.WARNING}}
    if worst in thresholds.get(fail_on, {Severity.BLOCKER}):
        return 2 if worst == Severity.BLOCKER else 1
    return 0


async def _build_ctx(
    context: str | None,
    prom_url: str | None,
    llm_provider: str | None,
    llm_base_url: str | None,
    llm_api_key: str | None,
    offline: bool,
    kubeconfig: str | None = None,
) -> AuditContext:
    effective_kubeconfig = kubeconfig or os.environ.get("KUBECONFIG")
    k8s = K8sAdapter(K8sConfig(context=context, kubeconfig=effective_kubeconfig))
    await k8s.connect()
    prom = PromAdapter(PromConfig(base_url=prom_url))
    llm = LLMAdapter(
        LLMConfig.from_sources(
            cli_provider=llm_provider,
            cli_base_url=llm_base_url,
            cli_api_key=llm_api_key,
            cli_offline=offline or None,
        )
    )
    return AuditContext(k8s=k8s, prom=prom, llm=llm)


@app.command()
def audit(
    context: str | None = typer.Option(None, "--context"),
    kubeconfig: str | None = typer.Option(None, "--kubeconfig", help="Path to kubeconfig file; defaults to KUBECONFIG env var."),
    namespace: list[str] = typer.Option([], "--namespace", "-n"),
    check: list[str] = typer.Option([], "--check"),
    label_selector: str | None = typer.Option(None, "--label-selector", "-l"),
    prom_url: str | None = typer.Option(None, "--prom-url"),
    llm_provider: str | None = typer.Option(None, "--llm-provider"),
    llm_base_url: str | None = typer.Option(None, "--llm-base-url"),
    llm_api_key: str | None = typer.Option(None, "--llm-api-key"),
    offline: bool = typer.Option(False, "--no-llm", help="Disable LLM calls."),
    fmt: str = typer.Option("md", "--format", "-f"),
    fail_on: str = typer.Option("blocker", "--fail-on"),
    output: Path | None = typer.Option(None, "--output", "-o"),
) -> None:
    """Run a full audit on the current (or --context) cluster."""

    async def _go() -> tuple[str, Report]:
        ctx = await _build_ctx(
            context, prom_url, llm_provider, llm_base_url, llm_api_key, offline, kubeconfig
        )
        try:
            orch = Orchestrator(ctx=ctx, version=__version__)
            scope = Scope(
                namespaces=namespace or None,
                label_selector=label_selector,
                checks=check or None,
            )
            report = await orch.audit(scope)
            return _render(report, fmt), report
        finally:
            await ctx.k8s.close()
            await ctx.prom.close()

    rendered, report = asyncio.run(_go())
    if output:
        output.write_text(rendered)
    else:
        sys.stdout.write(rendered)
    raise typer.Exit(_exit_code(report, fail_on))


@app.command("audit-workload")
def audit_workload(
    target: str = typer.Argument(..., help="namespace/kind/name"),
    context: str | None = typer.Option(None, "--context"),
    kubeconfig: str | None = typer.Option(None, "--kubeconfig", help="Path to kubeconfig file; defaults to KUBECONFIG env var."),
    fmt: str = typer.Option("md", "--format", "-f"),
) -> None:
    """Audit a single workload by namespace/kind/name."""
    ns, kind, name = target.split("/")

    async def _go() -> tuple[str, Report]:
        ctx = await _build_ctx(context, None, None, None, None, False, kubeconfig)
        try:
            orch = Orchestrator(ctx=ctx, version=__version__)
            report = await orch.audit(Scope(namespaces=[ns]))
            report.findings = [
                f for f in report.findings
                if f.target.namespace == ns and f.target.kind == kind and f.target.name == name
            ]
            return _render(report, fmt), report
        finally:
            await ctx.k8s.close()
            await ctx.prom.close()

    rendered, report = asyncio.run(_go())
    sys.stdout.write(rendered)
    raise typer.Exit(_exit_code(report, "blocker"))


@app.command("list-checks")
def list_checks_cmd(
    category: str | None = typer.Option(None, "--category"),
    fmt: str = typer.Option("text", "--format"),
) -> None:
    """List all registered checks."""
    metas = [
        CheckMeta(
            id=c.id,
            category=c.category,
            severity=c.severity,
            needs=c.needs,
            description=c.description,
        )
        for c in list_checks()
        if category is None or c.category == category
    ]
    if fmt == "json":
        typer.echo(json_lib.dumps([m.model_dump() for m in metas], indent=2))
        return
    for m in metas:
        typer.echo(f"{m.id}\t[{m.category}]\t{m.severity.value}\t{m.description}")


@app.command()
def explain(finding_id: str) -> None:
    """Explain a finding (Plan 2 stub)."""
    typer.echo(f"TODO: explain {finding_id} — implemented in Plan 2.", err=True)
    raise typer.Exit(3)


@app.command()
def diff(a: Path, b: Path) -> None:
    """Diff two reports (Plan 2 stub)."""
    typer.echo("TODO: diff — implemented in Plan 2.", err=True)
    raise typer.Exit(3)


@app.command("serve-mcp")
def serve_mcp() -> None:
    """Run the MCP stdio server."""
    from prod_readiness.mcp_server import run_stdio

    run_stdio()


if __name__ == "__main__":
    app()
