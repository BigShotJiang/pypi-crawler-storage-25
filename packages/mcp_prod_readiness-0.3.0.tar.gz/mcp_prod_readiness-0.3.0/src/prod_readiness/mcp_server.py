from __future__ import annotations

from fastmcp import FastMCP

import prod_readiness.checks  # noqa: F401 — registers all checks
from prod_readiness import __version__
from prod_readiness.adapters.k8s import K8sAdapter, K8sConfig
from prod_readiness.adapters.llm import LLMAdapter, LLMConfig
from prod_readiness.adapters.prom import PromAdapter, PromConfig
from prod_readiness.core.context import AuditContext
from prod_readiness.core.models import CheckMeta, Report, Scope
from prod_readiness.core.orchestrator import Orchestrator
from prod_readiness.core.registry import list_checks as _list_checks


def build_server() -> FastMCP:
    server = FastMCP("mcp-prod-readiness")

    @server.tool()
    async def audit_cluster(scope: Scope | None = None) -> Report:
        """Audit the current cluster against all registered checks."""
        s = scope or Scope()
        k8s = K8sAdapter(K8sConfig(context=s.contexts[0] if s.contexts else None))
        await k8s.connect()
        ctx = AuditContext(
            k8s=k8s,
            prom=PromAdapter(PromConfig()),
            llm=LLMAdapter(LLMConfig.from_sources()),
        )
        try:
            return await Orchestrator(ctx=ctx, version=__version__).audit(s)
        finally:
            await k8s.close()
            await ctx.prom.close()

    @server.tool()
    async def audit_workload(namespace: str, kind: str, name: str) -> Report:
        """Audit a single workload identified by namespace, kind, and name."""
        k8s = K8sAdapter(K8sConfig())
        await k8s.connect()
        ctx = AuditContext(
            k8s=k8s,
            prom=PromAdapter(PromConfig()),
            llm=LLMAdapter(LLMConfig.from_sources()),
        )
        try:
            report = await Orchestrator(ctx=ctx, version=__version__).audit(
                Scope(namespaces=[namespace])
            )
            report.findings = [
                f
                for f in report.findings
                if f.target.namespace == namespace
                and f.target.kind == kind
                and f.target.name == name
            ]
            return report
        finally:
            await k8s.close()
            await ctx.prom.close()

    @server.tool(name="list_checks")
    async def list_checks_tool() -> list[CheckMeta]:
        """List all registered checks and their metadata."""
        return [
            CheckMeta(
                id=c.id,
                category=c.category,
                severity=c.severity,
                needs=c.needs,
                description=c.description,
            )
            for c in _list_checks()
        ]

    return server


def run_stdio() -> None:
    """Synchronous entry point for cli.py::serve_mcp."""
    build_server().run()
