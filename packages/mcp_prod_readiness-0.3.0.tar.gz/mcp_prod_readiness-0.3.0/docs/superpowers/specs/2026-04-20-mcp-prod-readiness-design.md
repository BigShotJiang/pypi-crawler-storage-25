# mcp-prod-readiness — Design Spec

- **Date:** 2026-04-20
- **Project:** 04-mcp-prod-readiness (first of four conference/workshop MCP projects)
- **Status:** Approved for implementation planning
- **Prior art reused:** patterns from `github.com/vellankikoti/kotg.ai` (FastMCP skeleton, hybrid routing, structured outputs, K8s informer patterns)

## 1. Purpose & Vision

Ship a **production-grade Kubernetes prod-readiness auditor** exposed as both an MCP
server (for Claude Desktop / Claude Code / any MCP client) and a standalone CLI (for
CI pipelines, cron jobs, humans). It audits Deployments and StatefulSets against a
curated checklist covering resources, health probes, scaling, observability, security,
deployment strategy, resilience, and documentation. It produces structured, actionable
reports — with remediation snippets — and a machine-readable Report object that is
byte-identical across MCP and CLI.

The tool is also the headline artifact for a conference talk + 1–3 hr workshop. The
talk/workshop is the *surface*; the underlying software is built to stand alone as
a utility teams adopt in production.

**Non-goals for v1:**
- Auto-remediation (report only; never mutate cluster state).
- Pods / DaemonSets / CronJobs / Jobs as audit targets.
- Multi-cluster federation in one report (run per-context; aggregate externally).
- Profile/overlay YAML for threshold tuning (Phase 2).

## 2. Delivery Goals

- **Dual audience:** a real utility teams deploy, *and* a workshop artifact attendees build on.
- **Phased scope:** ship with **10 checks** (one per category + engine-path coverage),
  prove 100% accuracy on a golden-test suite, then expand in waves of 10–15.
- **Cluster-agnostic from day one:** kind, EKS, GKE, AKS — tested in CI.
- **LLM-agnostic:** any provider, any base URL (Ollama, vLLM, OpenAI-compatible),
  or fully offline.

## 3. Technical Stack

- **Language:** Python 3.11+, async-first (`asyncio`, `kubernetes_asyncio`, `httpx`).
- **MCP framework:** FastMCP (stdio transport).
- **CLI framework:** Typer.
- **Data models:** pydantic v2.
- **K8s client:** `kubernetes_asyncio`. Auth via standard kubeconfig exec-plugins
  (works unchanged on EKS/GKE/AKS/kind).
- **Prometheus client:** async wrapper over `httpx` (no heavy SDK); in-cluster
  auto-discovery via Service `kubernetes.io/name=prometheus` + fallback to
  `--prom-url` / `PROMETHEUS_URL`.
- **LLM access:** `litellm` for provider abstraction; `instructor` for typed
  structured outputs. Supports Anthropic, OpenAI, Azure, Bedrock, Gemini, Ollama,
  vLLM, any OpenAI-compatible endpoint.
- **Observability:** OpenTelemetry (OTLP exporter, no-op if unconfigured).
- **Packaging:** PyPI (`mcp-prod-readiness`), multi-arch OCI image
  (`ghcr.io/<you>/mcp-prod-readiness`), Helm chart (Phase 1.5), GitHub Action
  (Phase 1.5).

## 4. Architecture

### 4.1 Repository layout

```
prod-readiness/
├─ core/
│  ├─ context.py        # AuditContext: k8s + prom clients, cache, tracer, llm
│  ├─ registry.py       # @register_check decorator + discovery
│  ├─ check.py          # Check ABC
│  ├─ orchestrator.py   # fans checks across targets; aggregates Report
│  ├─ models.py         # pydantic: Target, Finding, Report, Scope
│  └─ router.py         # capability-based routing (K8S / PROM / LLM)
├─ checks/              # one module per check — MVP-10 ships here
├─ adapters/
│  ├─ k8s.py            # kubernetes_asyncio wrapper
│  ├─ prom.py           # async PromQL helper
│  └─ llm.py            # litellm + instructor wrapper
├─ mcp_server.py        # FastMCP entry point
├─ cli.py               # Typer CLI
├─ reports/             # renderers: json, md, junit-xml, html
└─ tests/               # unit / golden / integration / cluster-matrix / mcp
```

### 4.2 Request flow (one audit)

1. CLI or MCP tool invocation → `orchestrator.audit(scope)`.
2. `AuditContext` built once per run: K8s client, Prom client (discovered or
   configured), LLM client (constructed lazily; only if any selected check needs it).
3. Orchestrator lists **targets** = Deployments + StatefulSets matching scope
   (scope filters: contexts, namespaces, label selector, explicit check IDs).
4. For every (target × check), the orchestrator spawns a bounded-concurrency task
   that runs `check.run(ctx, target)`. The router enforces that only capabilities
   declared in `Check.needs` are reachable.
5. Results aggregate into a `Report`. Renderer writes JSON / Markdown / JUnit-XML
   / HTML.
6. Exit code: `0` clean, `1` warning, `2` blocker, `3` tool error.

### 4.3 Hybrid engine

The "hybrid direct / AI" split is a property of each check's declared
`needs: frozenset[Capability]`, not a runtime gate:

- `{K8S}` — pure API call. ~20 ms.
- `{K8S, PROM}` — API + PromQL correlation. ~80 ms.
- `{K8S, LLM}` — API gathers evidence; LLM invoked only for judgment. ~1–3 s.
- `{K8S, PROM, LLM}` — all three.

Each check *always runs*. The router gates which adapters the check may touch.
This makes "no-LLM for simple checks" verifiable in tests and teachable in the
workshop.

### 4.4 Caching

`AuditContext` memoizes:
- K8s list ops (one `list_namespaced_deployments` per namespace per run).
- PromQL queries (keyed by query + range + step).

No cross-run persistence in v1.

## 5. Data Model

```python
class Target(BaseModel):
    kind: Literal["Deployment", "StatefulSet"]
    namespace: str
    name: str
    uid: str

class Finding(BaseModel):
    check_id: str
    target: Target
    severity: Literal["blocker", "warning", "info"]
    status:   Literal["pass", "fail", "skip", "error"]
    message: str
    evidence: dict
    remediation: str | None
    ai_reasoning: str | None   # always persisted when an LLM call occurred
    duration_ms: int

class Report(BaseModel):
    cluster_context: str
    scope: Scope
    started_at: datetime
    finished_at: datetime
    findings: list[Finding]
    summary: dict              # counts by severity, status, category
    version: str               # tool semver, for reproducibility

class Scope(BaseModel):
    contexts: list[str] | None = None
    namespaces: list[str] | None = None
    label_selector: str | None = None
    checks: list[str] | None = None
```

**Severity ladder:** `blocker` = "do not ship to prod"; `warning` = "fix soon";
`info` = "aware / nice-to-have". Exit code is driven by the highest severity
observed with `status="fail"`.

**Error policy:**
- Check raises → `status="error"`, `message=str(exc)`; run continues.
- Check exceeds per-check timeout (default 10 s) → `status="error"`.
- Report always completes.

## 6. The MVP-10 Checks

| # | ID | Category | Needs | Severity | Assertion |
|---|---|---|---|---|---|
| 1 | `resources.requests-and-limits-set` | Resources | K8S | blocker | Every container has CPU+memory requests; memory limits set. |
| 2 | `health.liveness-readiness-configured` | Probes | K8S | blocker | Both probes present, not identical, sane timing. |
| 3 | `scaling.hpa-exists-and-realistic` | Scaling | K8S+PROM+LLM | warning | HPA exists; `maxReplicas` ≥ p99 traffic ÷ per-pod capacity (LLM judges "realistic given trend"). |
| 4 | `observability.prometheus-scrape-configured` | Observability | K8S+PROM | warning | Scrape annotations or ServiceMonitor/PodMonitor matching; Prom has received samples within 15 m. |
| 5 | `security.runs-as-non-root` | Security | K8S | blocker | `runAsNonRoot=true`, `runAsUser != 0`, `allowPrivilegeEscalation=false`. |
| 6 | `deployment.rolling-strategy-safe` | Deployment | K8S | warning | `RollingUpdate`, `maxUnavailable ≤ 25%`, `maxSurge ≥ 1`, `minReadySeconds ≥ 10`. |
| 7 | `resilience.pdb-exists` | Resilience | K8S | warning | Matching PDB leaves ≥1 pod available. |
| 8 | `resilience.replicas-ge-2` | Resilience | K8S | blocker | Deployments: `replicas ≥ 2`; StatefulSets: anti-affinity or topology spread. |
| 9 | `observability.logs-to-stdout` | Observability | K8S+LLM | info | No volumes mounted at log paths. LLM used only if ambiguous volume is present. |
| 10 | `documentation.runbook-link-annotation` | Documentation | K8S | info | `app.kubernetes.io/runbook` annotation is present and a well-formed URL. |

**Category coverage:** 8/8. **Engine-path coverage:** pure-API (×7), API+PromQL (×1),
API+PromQL+LLM (×1), API + conditional LLM (×1). Every code path exercised.

## 7. Surfaces

### 7.1 MCP tools (FastMCP)

- `audit_cluster(scope: Scope) -> Report`
- `audit_workload(namespace: str, kind: str, name: str) -> Report`
- `list_checks() -> list[CheckMeta]`
- `explain_finding(finding_id: str) -> Explanation`
- `diff_reports(a: Report, b: Report) -> ReportDiff`

### 7.2 CLI (Typer)

```
prod-readiness audit [--context X] [--namespace N...] [--check ID...]
                     [--format json|md|junit|html] [--fail-on blocker|warning]
prod-readiness audit-workload <ns>/<kind>/<name>
prod-readiness list-checks [--category C]
prod-readiness explain <finding-id>
prod-readiness diff <report-a.json> <report-b.json>
prod-readiness serve-mcp
```

Exit codes: `0` clean, `1` warning, `2` blocker, `3` tool error.

### 7.3 CLI ↔ MCP parity

Both surfaces invoke the same `orchestrator.audit(...)` function. A contract test
asserts that for identical scopes, `CLI --format json` output equals the MCP
`audit_cluster` response byte-for-byte (after normalising timestamps).

## 8. LLM Configuration

**Provider-agnostic via litellm.** Config precedence: CLI flag → env → config file.

| Flag | Env | Purpose |
|---|---|---|
| `--llm-provider` | `PROD_READINESS_LLM_PROVIDER` | e.g. `anthropic/claude-sonnet-4-6`, `openai/gpt-4o`, `ollama/qwen2.5:7b`. |
| `--llm-base-url` | `PROD_READINESS_LLM_BASE_URL` | For self-hosted / OpenAI-compatible endpoints. |
| `--llm-api-key` | `PROD_READINESS_LLM_API_KEY` or provider-native var | Auth. |
| `--no-llm` | `PROD_READINESS_OFFLINE=1` | Skip LLM-requiring checks with `status="skip"`. |

**Sane default when unconfigured:** attempt `ollama/qwen2.5:7b` at `http://localhost:11434`;
if unreachable, fall back to offline mode with a single warning line. The tool
*always* runs; LLM is a capability, not a requirement.

All structured LLM outputs go through `instructor` so schemas are explicit and
model-agnostic.

## 9. Packaging & Distribution

- **PyPI:** `pip install mcp-prod-readiness` installs both entry points:
  `prod-readiness` (CLI) and `mcp-prod-readiness` (MCP stdio server).
- **Workshop install:** `uvx mcp-prod-readiness serve-mcp` — zero build step.
  Claude Code/Desktop config:
  ```json
  { "mcpServers": { "prod-readiness": { "command": "uvx", "args": ["mcp-prod-readiness", "serve-mcp"] } } }
  ```
- **Container:** `ghcr.io/<you>/mcp-prod-readiness:<semver>`, multi-arch
  (amd64/arm64), runs as non-root, bundles `kubectl`, `aws-cli`, `gcloud`,
  `kubelogin`.
- **Helm chart (Phase 1.5):** optional in-cluster CronJob that publishes the
  latest report to a ConfigMap and emits Prom metrics
  (`readiness_findings_total{severity,category}`) — teams can track prod-readiness
  over time.
- **GitHub Action (Phase 1.5):** `vellankikoti/prod-readiness-action@v1`
  producing JUnit for PR checks.

## 10. Testing & Accuracy Bar

Five-layer pyramid:

1. **Unit** (`tests/unit/`). Pass-case and fail-case per check using a fake
   `AuditContext`. Runs on every commit.
2. **Golden** (`tests/golden/<check_id>/<scenario>/{input.yaml, expected.json}`).
   Authoritative accuracy harness — ephemeral kind cluster, apply manifests,
   run the check, diff against `expected.json`. **Phase 1 acceptance = 100%
   golden pass rate across 20 consecutive CI runs with zero flakes.**
   Every bug fix adds a new scenario before the code change.
3. **Integration** (`tests/integration/`). Full audits on kind with realistic
   happy-path and deliberately-broken apps. Asserts Report structure, severity
   counts, exit codes, CLI ↔ MCP parity.
4. **Cluster matrix** (`tests/cluster-matrix/`, weekly/manual). kind + EKS + GKE
   + AKS via Pulumi; integration suite runs on all four.
5. **MCP contract** (`tests/mcp/`). Official MCP client SDK exercises every tool
   over stdio; schemas validated against pydantic.

**LLM determinism:** checks with `LLM` in needs use `instructor`-recorded cassettes
in golden/integration tests. A separate nightly job runs against the live
configured provider and fails loudly on drift — so CI is not entangled with an
LLM vendor while we still detect regressions.

**Per-check acceptance gate.** No check merges until:
1. ≥3 golden scenarios (pass, fail, edge).
2. Golden suite passes 20× in CI without flake.
3. CLI and MCP produce byte-identical reports for the same scope (ignoring
   timestamps).

## 11. Observability of the Tool Itself

OpenTelemetry spans per check run: attributes `check.id`, `target.uid`,
`duration_ms`, `status`, `llm_tokens` (when applicable). OTLP export enabled when
`OTEL_EXPORTER_OTLP_ENDPOINT` is set; no-op otherwise. The Helm chart can wire
this to an in-cluster OTel collector.

## 12. Release & Versioning

- SemVer. `0.x.y` until MVP-10 hits the accuracy bar on kind + EKS + GKE + AKS;
  then `1.0.0`.
- Keep-a-Changelog format `CHANGELOG.md`.
- GitHub Release on tag: PyPI publish → multi-arch container push → Helm chart
  push to `ghcr.io/<you>/charts` → GitHub Action tag update → SBOM + cosign
  signatures.
- Phase milestones:
  - `v1.0.0` — MVP-10 proven across all four clusters.
  - `v1.1.0` — +10 checks (wave 2).
  - `v1.2.0` — +10–14 checks (wave 3, completes the 34).
  - `v2.0.0` — shared foundation extracted into its own package for reuse by
    01-secure-ops / 02-observatory / 03-deploy-intel.

## 13. Workshop Path (1–3 hr)

1. **(30 min)** Run the tool against a broken demo app on kind → read the
   Markdown report → fix the manifests → re-run → clean report.
2. **(45 min)** Swap LLM backends (Claude ↔ local Ollama) on the HPA check;
   discuss AI-as-judgment vs. AI-as-fact.
3. **(60 min)** Write your own check: pick a category, implement one class, add
   a golden scenario, open a PR.
4. **(15 min optional)** Install via Helm; watch `readiness_findings_total`
   appear in Grafana.

## 14. Open Decisions (all taken)

| Decision | Choice |
|---|---|
| Delivery goal | Production-grade utility first; talk/workshop second. |
| Scope decomposition | One deep project first (this one); extract shared foundation in `v2.0.0`. |
| Language | Python-only. |
| Stack | FastMCP + Typer + pydantic + kubernetes_asyncio + httpx + litellm + instructor. |
| Engine approach | Python check classes, plugin-registered (Approach 1). |
| MVP scope | 10 checks, one per category + full engine-path coverage; 100% accuracy before expansion. |
| Targets in v1 | Deployments + StatefulSets. |
| Cluster matrix | kind + EKS + GKE + AKS from day one. |
| Surfaces | MCP server + CLI, 1:1 parity. |
| Severity ladder | `blocker` / `warning` / `info`. |
| AI reasoning | Always persisted in `Finding.ai_reasoning`. |
| LLM agnosticism | litellm + instructor; any provider / URL; offline supported. |
| Workshop install | `uvx` default. |
| Helm chart / GH Action | Phase 1.5. |

## 15. Dependencies on External Work

- `kotg.ai` repo (cloned at `.reference/kotg.ai/`) — pattern reference only, not
  a runtime dependency. Specifically reused: FastMCP server skeleton shape,
  hybrid routing idea, `instructor`-typed outputs.

## 16. Success Criteria (Phase 1 exit)

1. All 10 MVP checks green on their golden suites, 20 consecutive CI runs, zero
   flakes.
2. Full audit of a 50-workload kind cluster completes in ≤ 10 s wall-clock with
   default concurrency.
3. Cluster-matrix job passes on kind + EKS + GKE + AKS.
4. `uvx mcp-prod-readiness serve-mcp` works from a fresh machine; Claude Desktop
   connects; `audit_cluster` returns a valid Report.
5. CLI ↔ MCP byte-parity test green.
6. PyPI release `v1.0.0` published; container image signed; release notes
   published.
