# mcp-prod-readiness — Plan 2: Security Check + Prometheus Check + Adapter Cache

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Ship `mcp-prod-readiness v0.2.0` — adds two checks that together prove the remaining easy engine paths (pure K8s pod-spec analysis, and first K8s + Prometheus correlation), plus a per-run K8s read-through cache so multi-check audits make one `read_workload` call per target per run.

**Architecture:** Build on Plan 1's foundation. Add a dict-based read cache on `K8sAdapter` keyed by `target.uid` (cleared on `close()`). Add `security.runs-as-non-root` — reads the same workload and inspects `securityContext` at pod- and container-level. Add `observability.prometheus-scrape-configured` — inspects K8s-side scrape annotations, then (when `PromAdapter` is available) queries Prometheus to confirm the target has been scraped in the last 15 minutes. Golden tests cover K8s branches; Prom branches covered by `pytest-httpx` unit tests (no in-cluster Prometheus needed).

**Tech Stack:** Same as Plan 1 — Python 3.11, `kubernetes_asyncio`, `httpx`, `pydantic` v2, `fastmcp` 3.x, `typer`, `litellm`, `instructor`, `pytest` + `pytest-asyncio` + `pytest-httpx`, `kind` for golden tests, `uv` for env.

**Spec:** `docs/superpowers/specs/2026-04-20-mcp-prod-readiness-design.md`
**Prior plan:** `docs/superpowers/plans/2026-04-20-mcp-prod-readiness-plan-1-walking-skeleton.md`

**Working directory:** `04-mcp-prod-readiness/` (git repo, on `main`, at the commit produced by Plan 1 Task 17 — the tree includes `v0.1.0` in `CHANGELOG.md` but no tag has been pushed).

---

## Conventions reminder (from Plan 1)

- `from __future__ import annotations` at the top of every file.
- `datetime.UTC` not `timezone.utc`. `StrEnum` not `str, Enum`. Unquoted forward refs.
- `TimeoutError` (builtin) not `asyncio.TimeoutError`.
- One class per file where sensible; files stay ≤ 200 lines.
- No comments except where WHY is non-obvious.
- Each task ends with a commit. Conventional Commits: `feat:`, `test:`, `chore:`, `refactor:`, `docs:`.
- `uv run <cmd>` is the canonical way to run anything.
- Strict mypy + ruff `{E,F,I,UP,B,SIM,ASYNC,RUF}` + `B008` ignored for Typer.
- `pytest-asyncio` mode `auto`; markers `golden`, `integration`, `mcp_contract`.

**Plan-1 exit state:** 30 unit + 3 golden + 1 integration + 1 mcp_contract = 35 tests pass. One real check: `resources.requests-and-limits-set`.

---

## Task 1: K8s adapter read-through cache

**Files:**
- Modify: `src/prod_readiness/adapters/k8s.py` — add `_read_cache: dict[str, Any]` to `K8sAdapter.__init__`; memoise `read_workload` by `target.uid`; clear on `close()`.
- Create: `tests/unit/test_k8s_read_cache.py`

- [ ] **Step 1: Write failing test**

```python
# tests/unit/test_k8s_read_cache.py
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from prod_readiness.adapters.k8s import K8sAdapter
from prod_readiness.core.models import Target


@pytest.mark.asyncio
async def test_read_workload_is_memoised_per_run():
    adapter = K8sAdapter.__new__(K8sAdapter)
    adapter._read_cache = {}  # type: ignore[attr-defined]
    fake_apps = MagicMock()
    wl = MagicMock()
    fake_apps.read_namespaced_deployment = AsyncMock(return_value=wl)
    fake_apps.read_namespaced_stateful_set = AsyncMock()
    adapter._apps = fake_apps  # type: ignore[attr-defined]

    t = Target(kind="Deployment", namespace="d", name="a", uid="uid-1")

    first = await adapter.read_workload(t)
    second = await adapter.read_workload(t)

    assert first is wl
    assert second is wl
    assert fake_apps.read_namespaced_deployment.call_count == 1


@pytest.mark.asyncio
async def test_close_clears_cache():
    adapter = K8sAdapter.__new__(K8sAdapter)
    adapter._read_cache = {"u1": object()}  # type: ignore[attr-defined]
    adapter._api_client = None  # type: ignore[attr-defined]
    await adapter.close()
    assert adapter._read_cache == {}  # type: ignore[attr-defined]
```

- [ ] **Step 2: Run test to verify it fails**

```bash
uv run pytest tests/unit/test_k8s_read_cache.py -v
```

Expected: FAIL — `K8sAdapter.__init__` doesn't set `_read_cache`; `read_workload` doesn't memoise.

- [ ] **Step 3: Modify `src/prod_readiness/adapters/k8s.py`**

Add the `_read_cache` attribute in `__init__` and update `read_workload` + `close`. Show the whole updated file (the pieces that change):

- In `__init__`, after existing attribute assignments, add:

```python
        self._read_cache: dict[str, Any] = {}
```

- Replace `read_workload` with:

```python
    async def read_workload(self, target: Target) -> Any:
        cached = self._read_cache.get(target.uid)
        if cached is not None:
            return cached
        assert self._apps is not None
        if target.kind == "Deployment":
            wl = await self._apps.read_namespaced_deployment(
                name=target.name, namespace=target.namespace
            )
        else:
            wl = await self._apps.read_namespaced_stateful_set(
                name=target.name, namespace=target.namespace
            )
        self._read_cache[target.uid] = wl
        return wl
```

- Replace `close` with:

```python
    async def close(self) -> None:
        self._read_cache.clear()
        if self._api_client is not None:
            await self._api_client.close()
```

- [ ] **Step 4: Run tests to verify they pass**

```bash
uv run pytest tests/unit/test_k8s_read_cache.py -v
uv run pytest tests/unit/test_k8s_adapter.py -v   # ensure earlier adapter tests still green
uv run mypy src
uv run ruff check .
```

Expected: all green; 32 unit tests total.

- [ ] **Step 5: Commit**

```bash
git add -A
git commit -m "feat(adapters): per-run read-through cache on K8sAdapter.read_workload"
```

---

## Task 2: Check `security.runs-as-non-root`

**Files:**
- Create: `src/prod_readiness/checks/security_runs_as_non_root.py`
- Modify: `src/prod_readiness/checks/__init__.py` — import the new module so registration happens.
- Create: `tests/unit/test_check_security_runs_as_non_root.py`

**What this check asserts:**

A Deployment/StatefulSet passes if **every container** runs as non-root. A container "runs as non-root" when ANY of:
- Its own `securityContext.runAsNonRoot` is `True`, OR
- Pod-level `securityContext.runAsNonRoot` is `True` and the container does not override it to `False`.

AND:
- `runAsUser` (container or pod-inherited) is not `0` when explicitly set.
- `allowPrivilegeEscalation` is `False` on every container (container-level explicit, or pod-level default if set).

Severity: `BLOCKER`. Category: `security`. Needs: `{Capability.K8S}`.

- [ ] **Step 1: Write failing test**

```python
# tests/unit/test_check_security_runs_as_non_root.py
from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock

import pytest

from prod_readiness.checks.security_runs_as_non_root import SecurityRunsAsNonRoot
from prod_readiness.core.context import AuditContext
from prod_readiness.core.models import Status, Target


def _wl(
    *,
    pod_sc: dict | None = None,
    containers: list[dict],
) -> object:
    pod_spec = SimpleNamespace(
        security_context=(SimpleNamespace(**pod_sc) if pod_sc else None),
        containers=[
            SimpleNamespace(
                name=c["name"],
                security_context=(
                    SimpleNamespace(**c["security_context"])
                    if c.get("security_context")
                    else None
                ),
            )
            for c in containers
        ],
    )
    return SimpleNamespace(spec=SimpleNamespace(template=SimpleNamespace(spec=pod_spec)))


def _ctx(workload) -> AuditContext:
    k8s = MagicMock()
    k8s.read_workload = AsyncMock(return_value=workload)
    return AuditContext(k8s=k8s, prom=MagicMock(), llm=MagicMock())


def _target() -> Target:
    return Target(kind="Deployment", namespace="d", name="a", uid="u")


@pytest.mark.asyncio
async def test_pass_when_container_sets_runs_as_non_root_and_forbids_priv_escalation():
    wl = _wl(
        containers=[
            {
                "name": "api",
                "security_context": {
                    "run_as_non_root": True,
                    "run_as_user": 1000,
                    "allow_privilege_escalation": False,
                },
            }
        ]
    )
    ctx = _ctx(wl).guard(needs=SecurityRunsAsNonRoot.needs)
    f = await SecurityRunsAsNonRoot().run(ctx, _target())
    assert f.status == Status.PASS


@pytest.mark.asyncio
async def test_pass_when_pod_level_sets_runs_as_non_root_and_container_does_not_override():
    wl = _wl(
        pod_sc={"run_as_non_root": True, "run_as_user": 1000},
        containers=[
            {
                "name": "api",
                "security_context": {"allow_privilege_escalation": False},
            }
        ],
    )
    ctx = _ctx(wl).guard(needs=SecurityRunsAsNonRoot.needs)
    f = await SecurityRunsAsNonRoot().run(ctx, _target())
    assert f.status == Status.PASS


@pytest.mark.asyncio
async def test_fail_when_neither_pod_nor_container_set_run_as_non_root():
    wl = _wl(
        containers=[
            {"name": "api", "security_context": {"allow_privilege_escalation": False}}
        ]
    )
    ctx = _ctx(wl).guard(needs=SecurityRunsAsNonRoot.needs)
    f = await SecurityRunsAsNonRoot().run(ctx, _target())
    assert f.status == Status.FAIL
    assert "runAsNonRoot" in f.message or "non-root" in f.message.lower()
    assert f.evidence["containers"][0]["problems"]


@pytest.mark.asyncio
async def test_fail_when_run_as_user_is_zero():
    wl = _wl(
        containers=[
            {
                "name": "api",
                "security_context": {
                    "run_as_non_root": True,
                    "run_as_user": 0,
                    "allow_privilege_escalation": False,
                },
            }
        ]
    )
    ctx = _ctx(wl).guard(needs=SecurityRunsAsNonRoot.needs)
    f = await SecurityRunsAsNonRoot().run(ctx, _target())
    assert f.status == Status.FAIL
    assert "runAsUser=0" in f.message


@pytest.mark.asyncio
async def test_fail_when_allow_privilege_escalation_is_true_or_missing():
    wl = _wl(
        containers=[
            {
                "name": "api",
                "security_context": {"run_as_non_root": True, "run_as_user": 1000},
            }
        ]
    )
    ctx = _ctx(wl).guard(needs=SecurityRunsAsNonRoot.needs)
    f = await SecurityRunsAsNonRoot().run(ctx, _target())
    assert f.status == Status.FAIL
    assert "allowPrivilegeEscalation" in f.message


@pytest.mark.asyncio
async def test_container_override_of_pod_level_to_false_fails():
    wl = _wl(
        pod_sc={"run_as_non_root": True, "run_as_user": 1000},
        containers=[
            {
                "name": "api",
                "security_context": {
                    "run_as_non_root": False,
                    "allow_privilege_escalation": False,
                },
            }
        ],
    )
    ctx = _ctx(wl).guard(needs=SecurityRunsAsNonRoot.needs)
    f = await SecurityRunsAsNonRoot().run(ctx, _target())
    assert f.status == Status.FAIL
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
uv run pytest tests/unit/test_check_security_runs_as_non_root.py -v
```

Expected: ModuleNotFoundError.

- [ ] **Step 3: Write `src/prod_readiness/checks/security_runs_as_non_root.py`**

```python
from __future__ import annotations

from typing import Any

from prod_readiness.core.check import Check
from prod_readiness.core.context import GuardedContext
from prod_readiness.core.models import Capability, Finding, Severity, Status, Target
from prod_readiness.core.registry import register_check

_REMEDIATION = (
    "spec:\n"
    "  template:\n"
    "    spec:\n"
    "      securityContext:\n"
    "        runAsNonRoot: true\n"
    "        runAsUser: 1000\n"
    "      containers:\n"
    "        - name: <container>\n"
    "          securityContext:\n"
    "            allowPrivilegeEscalation: false\n"
    "            readOnlyRootFilesystem: true\n"
    "            capabilities:\n"
    "              drop: [\"ALL\"]\n"
)


def _attr(obj: Any, name: str) -> Any:
    if obj is None:
        return None
    return getattr(obj, name, None)


@register_check
class SecurityRunsAsNonRoot(Check):
    id = "security.runs-as-non-root"
    category = "security"
    severity = Severity.BLOCKER
    needs = frozenset({Capability.K8S})
    description = (
        "Every container runs as non-root with privilege-escalation disabled."
    )

    async def run(self, ctx: GuardedContext, target: Target) -> Finding:  # type: ignore[override]
        wl = await ctx.k8s.read_workload(target)
        pod_spec = wl.spec.template.spec
        pod_sc = _attr(pod_spec, "security_context")
        pod_runs_as_non_root = _attr(pod_sc, "run_as_non_root") is True
        pod_run_as_user = _attr(pod_sc, "run_as_user")

        per_container: list[dict[str, Any]] = []
        any_fail = False
        for c in pod_spec.containers or []:
            sc = _attr(c, "security_context")
            c_runs_as_non_root = _attr(sc, "run_as_non_root")
            c_run_as_user = _attr(sc, "run_as_user")
            c_allow_priv = _attr(sc, "allow_privilege_escalation")

            effective_non_root = (
                c_runs_as_non_root
                if c_runs_as_non_root is not None
                else pod_runs_as_non_root
            )
            effective_uid = (
                c_run_as_user if c_run_as_user is not None else pod_run_as_user
            )

            problems: list[str] = []
            if effective_non_root is not True:
                problems.append("runAsNonRoot")
            if effective_uid == 0:
                problems.append("runAsUser=0")
            if c_allow_priv is not False:
                problems.append("allowPrivilegeEscalation")

            if problems:
                any_fail = True
            per_container.append({"name": c.name, "problems": problems})

        if not any_fail:
            return Finding(
                check_id=self.id,
                target=target,
                severity=self.severity,
                status=Status.PASS,
                message="All containers run as non-root with privilege escalation disabled.",
                evidence={"containers": per_container},
            )

        reason_bits = sorted(
            {p for c in per_container for p in c["problems"]}
        )
        return Finding(
            check_id=self.id,
            target=target,
            severity=self.severity,
            status=Status.FAIL,
            message="Security gaps: " + ", ".join(reason_bits) + ".",
            evidence={"containers": per_container},
            remediation=_REMEDIATION,
        )
```

- [ ] **Step 4: Modify `src/prod_readiness/checks/__init__.py`**

Open the file; after the existing `from prod_readiness.checks import resources_requests_and_limits_set` line, add:

```python
from prod_readiness.checks import security_runs_as_non_root  # noqa: F401
```

Update `__all__`:

```python
__all__ = [
    "resources_requests_and_limits_set",
    "security_runs_as_non_root",
]
```

- [ ] **Step 5: Run tests**

```bash
uv run pytest tests/unit/test_check_security_runs_as_non_root.py -v
uv run pytest tests/unit/ -v      # expect 38 tests
uv run mypy src
uv run ruff check .
```

Expected: green.

- [ ] **Step 6: Commit**

```bash
git add -A
git commit -m "feat(checks): security.runs-as-non-root"
```

---

## Task 3: Golden scenarios for `security.runs-as-non-root`

**Files:**
- Create: `tests/golden/security.runs-as-non-root/pass/input.yaml`
- Create: `tests/golden/security.runs-as-non-root/pass/expected.json`
- Create: `tests/golden/security.runs-as-non-root/fail-root-user/input.yaml`
- Create: `tests/golden/security.runs-as-non-root/fail-root-user/expected.json`
- Create: `tests/golden/security.runs-as-non-root/fail-priv-escalation/input.yaml`
- Create: `tests/golden/security.runs-as-non-root/fail-priv-escalation/expected.json`
- Modify: `tests/golden/test_golden.py` — parametrize existing test over a `(check_id, scenario)` matrix.

- [ ] **Step 1: Write manifests and expected JSON**

`tests/golden/security.runs-as-non-root/pass/input.yaml`:

```yaml
apiVersion: v1
kind: Namespace
metadata:
  name: golden-sec-pass
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: sec-happy
  namespace: golden-sec-pass
spec:
  replicas: 1
  selector:
    matchLabels: { app: sec-happy }
  template:
    metadata:
      labels: { app: sec-happy }
    spec:
      securityContext:
        runAsNonRoot: true
        runAsUser: 1000
      containers:
        - name: api
          image: registry.k8s.io/pause:3.9
          securityContext:
            allowPrivilegeEscalation: false
```

`tests/golden/security.runs-as-non-root/pass/expected.json`:

```json
[
  {
    "check_id": "security.runs-as-non-root",
    "target": {"kind": "Deployment", "namespace": "golden-sec-pass", "name": "sec-happy", "uid": "<uid>"},
    "severity": "blocker",
    "status": "pass",
    "message": "All containers run as non-root with privilege escalation disabled.",
    "evidence": {"containers": [{"name": "api", "problems": []}]},
    "remediation": null,
    "ai_reasoning": null,
    "duration_ms": 0
  }
]
```

`tests/golden/security.runs-as-non-root/fail-root-user/input.yaml`:

```yaml
apiVersion: v1
kind: Namespace
metadata:
  name: golden-sec-root
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: sec-root
  namespace: golden-sec-root
spec:
  replicas: 1
  selector: { matchLabels: { app: sec-root } }
  template:
    metadata: { labels: { app: sec-root } }
    spec:
      containers:
        - name: api
          image: registry.k8s.io/pause:3.9
          securityContext:
            runAsUser: 0
            allowPrivilegeEscalation: false
```

`tests/golden/security.runs-as-non-root/fail-root-user/expected.json`:

```json
[
  {
    "check_id": "security.runs-as-non-root",
    "target": {"kind": "Deployment", "namespace": "golden-sec-root", "name": "sec-root", "uid": "<uid>"},
    "severity": "blocker",
    "status": "fail",
    "message": "Security gaps: runAsNonRoot, runAsUser=0.",
    "evidence": {"containers": [{"name": "api", "problems": ["runAsNonRoot", "runAsUser=0"]}]},
    "remediation": "spec:\n  template:\n    spec:\n      securityContext:\n        runAsNonRoot: true\n        runAsUser: 1000\n      containers:\n        - name: <container>\n          securityContext:\n            allowPrivilegeEscalation: false\n            readOnlyRootFilesystem: true\n            capabilities:\n              drop: [\"ALL\"]\n",
    "ai_reasoning": null,
    "duration_ms": 0
  }
]
```

`tests/golden/security.runs-as-non-root/fail-priv-escalation/input.yaml`:

```yaml
apiVersion: v1
kind: Namespace
metadata:
  name: golden-sec-priv
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: sec-priv
  namespace: golden-sec-priv
spec:
  replicas: 1
  selector: { matchLabels: { app: sec-priv } }
  template:
    metadata: { labels: { app: sec-priv } }
    spec:
      securityContext:
        runAsNonRoot: true
        runAsUser: 1000
      containers:
        - name: api
          image: registry.k8s.io/pause:3.9
```

`tests/golden/security.runs-as-non-root/fail-priv-escalation/expected.json`:

```json
[
  {
    "check_id": "security.runs-as-non-root",
    "target": {"kind": "Deployment", "namespace": "golden-sec-priv", "name": "sec-priv", "uid": "<uid>"},
    "severity": "blocker",
    "status": "fail",
    "message": "Security gaps: allowPrivilegeEscalation.",
    "evidence": {"containers": [{"name": "api", "problems": ["allowPrivilegeEscalation"]}]},
    "remediation": "spec:\n  template:\n    spec:\n      securityContext:\n        runAsNonRoot: true\n        runAsUser: 1000\n      containers:\n        - name: <container>\n          securityContext:\n            allowPrivilegeEscalation: false\n            readOnlyRootFilesystem: true\n            capabilities:\n              drop: [\"ALL\"]\n",
    "ai_reasoning": null,
    "duration_ms": 0
  }
]
```

- [ ] **Step 2: Generalise `tests/golden/test_golden.py`**

Replace the current file with a matrix-parametrised runner that discovers scenarios from `tests/golden/<check_id>/<scenario>/{input.yaml,expected.json}`:

```python
from __future__ import annotations

import json
from pathlib import Path

import pytest

from tests.golden._runner import (
    KindCluster,
    apply_manifests,
    normalise,
    run_check_against_cluster,
)

GOLDEN_ROOT = Path("tests/golden")


def _discover() -> list[tuple[str, str]]:
    """Return (check_id, scenario) for every scenario dir with input.yaml + expected.json."""
    out: list[tuple[str, str]] = []
    for check_dir in sorted(GOLDEN_ROOT.iterdir()):
        if not check_dir.is_dir() or check_dir.name.startswith("_") or check_dir.name == "__pycache__":
            continue
        if not (check_dir / check_dir.name).exists() is False:  # check that check_dir has scenario subdirs
            pass
        for scenario_dir in sorted(check_dir.iterdir()):
            if not scenario_dir.is_dir():
                continue
            if not (scenario_dir / "input.yaml").exists():
                continue
            if not (scenario_dir / "expected.json").exists():
                continue
            out.append((check_dir.name, scenario_dir.name))
    return out


def _scenario_namespace(scenario_dir: Path) -> str:
    """Parse the Namespace metadata.name from the scenario's input.yaml."""
    text = (scenario_dir / "input.yaml").read_text()
    # Minimal parse — we commit manifests that begin with `kind: Namespace`.
    for doc in text.split("---"):
        lines = [ln.strip() for ln in doc.splitlines() if ln.strip()]
        if any(ln == "kind: Namespace" for ln in lines):
            for ln in lines:
                if ln.startswith("name:"):
                    return ln.split(":", 1)[1].strip()
    raise AssertionError(f"No Namespace found in {scenario_dir}")


SCENARIOS = _discover()


@pytest.mark.golden
@pytest.mark.asyncio
@pytest.mark.parametrize(
    "check_id,scenario",
    SCENARIOS,
    ids=[f"{c}/{s}" for c, s in SCENARIOS],
)
async def test_golden_scenario(
    kind_cluster: KindCluster, check_id: str, scenario: str
) -> None:
    scenario_dir = GOLDEN_ROOT / check_id / scenario
    apply_manifests(kind_cluster, scenario_dir / "input.yaml")

    ns = _scenario_namespace(scenario_dir)
    actual = await run_check_against_cluster(kind_cluster, check_id)
    actual = normalise([f for f in actual if f["target"]["namespace"] == ns])
    expected = json.loads((scenario_dir / "expected.json").read_text())

    assert actual == expected
```

Delete the old `tests/golden/test_golden.py` and re-create with the above. The `tests/golden/__init__.py` (empty) stays. The `tests/golden/_runner.py` and `tests/golden/conftest.py` do NOT change.

> Clarification on discovery: we commit scenario directories under `tests/golden/<dot-separated check id>/<scenario slug>/`. Python package-name rules don't apply — these are pure data dirs. Make sure `tests/golden/__init__.py` remains empty and pytest's `testpaths = ["tests"]` still picks up the module `tests/golden/test_golden.py`.

- [ ] **Step 3: Run the golden suite**

```bash
uv run pytest -m golden -v
```

Expected: **6 scenarios** pass (3 resources + 3 security). Runtime ≈ 2 minutes (one shared kind cluster; manifests applied sequentially).

- [ ] **Step 4: Commit**

```bash
git add -A
git commit -m "test(golden): matrix runner + 3 scenarios for security.runs-as-non-root"
```

---

## Task 4: Check `observability.prometheus-scrape-configured` — unit tests

**Files:**
- Create: `src/prod_readiness/checks/observability_prometheus_scrape_configured.py`
- Modify: `src/prod_readiness/checks/__init__.py` — import + add to `__all__`.
- Create: `tests/unit/test_check_prometheus_scrape.py`

**What this check asserts (per spec §6 row 4):**

A Deployment/StatefulSet passes if:
1. The pod template has `prometheus.io/scrape: "true"` annotation, OR a matching `ServiceMonitor` / `PodMonitor` exists, AND
2. If `PromAdapter.available` is `True`, Prometheus reports at least one sample for this target within the last 15 minutes.

Severity: `WARNING`. Category: `observability`. Needs: `{K8S, PROM}`.

**Behaviour when Prometheus is unavailable** (`ctx.prom.available == False`):
- If step 1 passes → `status=SKIP`, message `"no Prometheus configured — cannot verify scrape"`.
- If step 1 fails → `status=FAIL` with K8s-side reason.

**Behaviour when Prometheus is available but no samples found:**
- → `status=FAIL`, message `"target is configured for scrape but Prometheus has no samples in last 15m"`.

The workload-level scrape detection uses the pod-template annotation first; if absent, list `ServiceMonitor` / `PodMonitor` objects and match by selector. For v1, a minimal implementation that ONLY checks the annotation is sufficient — note this in the finding message when annotation is absent ("no scrape annotation on pod template; ServiceMonitor/PodMonitor lookup not implemented yet"). Full SM/PM support is deferred to Plan 3.

- [ ] **Step 1: Write failing test**

```python
# tests/unit/test_check_prometheus_scrape.py
from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock

import pytest

from prod_readiness.checks.observability_prometheus_scrape_configured import (
    ObservabilityPrometheusScrapeConfigured,
)
from prod_readiness.core.context import AuditContext
from prod_readiness.core.models import Status, Target


def _wl(annotations: dict[str, str] | None) -> object:
    pod_tmpl_meta = SimpleNamespace(annotations=annotations or {})
    pod_spec = SimpleNamespace(containers=[SimpleNamespace(name="api")])
    return SimpleNamespace(
        spec=SimpleNamespace(
            template=SimpleNamespace(metadata=pod_tmpl_meta, spec=pod_spec)
        )
    )


def _ctx(workload, *, prom_available: bool, prom_query_result: dict | Exception | None = None) -> AuditContext:
    k8s = MagicMock()
    k8s.read_workload = AsyncMock(return_value=workload)
    prom = MagicMock()
    prom.available = prom_available
    if isinstance(prom_query_result, Exception):
        prom.query = AsyncMock(side_effect=prom_query_result)
    else:
        prom.query = AsyncMock(return_value=prom_query_result or {"result": []})
    return AuditContext(k8s=k8s, prom=prom, llm=MagicMock())


def _target() -> Target:
    return Target(kind="Deployment", namespace="d", name="a", uid="u")


@pytest.mark.asyncio
async def test_skip_when_annotation_present_but_prom_unavailable():
    wl = _wl({"prometheus.io/scrape": "true"})
    ctx = _ctx(wl, prom_available=False).guard(
        needs=ObservabilityPrometheusScrapeConfigured.needs
    )
    f = await ObservabilityPrometheusScrapeConfigured().run(ctx, _target())
    assert f.status == Status.SKIP
    assert "no Prometheus" in f.message.lower() or "cannot verify" in f.message.lower()


@pytest.mark.asyncio
async def test_fail_when_no_annotation_and_prom_unavailable():
    wl = _wl(None)
    ctx = _ctx(wl, prom_available=False).guard(
        needs=ObservabilityPrometheusScrapeConfigured.needs
    )
    f = await ObservabilityPrometheusScrapeConfigured().run(ctx, _target())
    assert f.status == Status.FAIL
    assert "scrape" in f.message.lower()


@pytest.mark.asyncio
async def test_fail_when_annotation_present_but_prom_has_no_samples():
    wl = _wl({"prometheus.io/scrape": "true"})
    ctx = _ctx(
        wl,
        prom_available=True,
        prom_query_result={"result": []},
    ).guard(needs=ObservabilityPrometheusScrapeConfigured.needs)
    f = await ObservabilityPrometheusScrapeConfigured().run(ctx, _target())
    assert f.status == Status.FAIL
    assert "no samples" in f.message.lower()


@pytest.mark.asyncio
async def test_pass_when_annotation_present_and_prom_has_samples():
    wl = _wl({"prometheus.io/scrape": "true"})
    ctx = _ctx(
        wl,
        prom_available=True,
        prom_query_result={
            "result": [
                {"metric": {"namespace": "d", "pod": "a-abc"}, "value": [1234, "1"]}
            ]
        },
    ).guard(needs=ObservabilityPrometheusScrapeConfigured.needs)
    f = await ObservabilityPrometheusScrapeConfigured().run(ctx, _target())
    assert f.status == Status.PASS


@pytest.mark.asyncio
async def test_error_swallowed_when_prom_query_raises():
    wl = _wl({"prometheus.io/scrape": "true"})
    ctx = _ctx(
        wl,
        prom_available=True,
        prom_query_result=RuntimeError("prom down"),
    ).guard(needs=ObservabilityPrometheusScrapeConfigured.needs)
    f = await ObservabilityPrometheusScrapeConfigured().run(ctx, _target())
    assert f.status == Status.SKIP
    assert "prom down" in f.message.lower() or "query failed" in f.message.lower()
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
uv run pytest tests/unit/test_check_prometheus_scrape.py -v
```

Expected: ModuleNotFoundError.

- [ ] **Step 3: Write `src/prod_readiness/checks/observability_prometheus_scrape_configured.py`**

```python
from __future__ import annotations

from typing import Any

from prod_readiness.core.check import Check
from prod_readiness.core.context import GuardedContext
from prod_readiness.core.models import Capability, Finding, Severity, Status, Target
from prod_readiness.core.registry import register_check

_REMEDIATION = (
    "spec:\n"
    "  template:\n"
    "    metadata:\n"
    "      annotations:\n"
    '        prometheus.io/scrape: "true"\n'
    '        prometheus.io/port: "<metrics-port>"\n'
    '        prometheus.io/path: "/metrics"\n'
)


@register_check
class ObservabilityPrometheusScrapeConfigured(Check):
    id = "observability.prometheus-scrape-configured"
    category = "observability"
    severity = Severity.WARNING
    needs = frozenset({Capability.K8S, Capability.PROM})
    description = (
        "Pod template has Prometheus scrape annotations and (when available) "
        "Prometheus reports samples within the last 15 minutes."
    )

    async def run(self, ctx: GuardedContext, target: Target) -> Finding:  # type: ignore[override]
        wl = await ctx.k8s.read_workload(target)
        tmpl_meta = getattr(wl.spec.template, "metadata", None)
        annotations: dict[str, str] = getattr(tmpl_meta, "annotations", None) or {}
        has_annotation = annotations.get("prometheus.io/scrape") == "true"
        evidence: dict[str, Any] = {
            "scrape_annotation": has_annotation,
            "prom_available": ctx.prom.available,
        }

        if not has_annotation and not ctx.prom.available:
            return Finding(
                check_id=self.id,
                target=target,
                severity=self.severity,
                status=Status.FAIL,
                message=(
                    "No scrape annotation on pod template; "
                    "ServiceMonitor/PodMonitor lookup not implemented yet."
                ),
                evidence=evidence,
                remediation=_REMEDIATION,
            )

        if has_annotation and not ctx.prom.available:
            return Finding(
                check_id=self.id,
                target=target,
                severity=self.severity,
                status=Status.SKIP,
                message=(
                    "Scrape annotation present but no Prometheus configured — "
                    "cannot verify live samples."
                ),
                evidence=evidence,
            )

        promql = (
            f'last_over_time(up{{namespace="{target.namespace}"}}[15m])'
        )
        try:
            data = await ctx.prom.query(promql)
        except Exception as exc:
            return Finding(
                check_id=self.id,
                target=target,
                severity=self.severity,
                status=Status.SKIP,
                message=f"Prometheus query failed: {exc}",
                evidence=evidence,
            )

        samples = data.get("result") or []
        evidence["sample_count"] = len(samples)
        if not has_annotation and not samples:
            return Finding(
                check_id=self.id,
                target=target,
                severity=self.severity,
                status=Status.FAIL,
                message="No scrape annotation and Prometheus has no samples in last 15m.",
                evidence=evidence,
                remediation=_REMEDIATION,
            )
        if not samples:
            return Finding(
                check_id=self.id,
                target=target,
                severity=self.severity,
                status=Status.FAIL,
                message="Target is configured for scrape but Prometheus has no samples in last 15m.",
                evidence=evidence,
                remediation=_REMEDIATION,
            )
        return Finding(
            check_id=self.id,
            target=target,
            severity=self.severity,
            status=Status.PASS,
            message=f"Scrape annotation present; Prometheus returned {len(samples)} samples.",
            evidence=evidence,
        )
```

- [ ] **Step 4: Modify `src/prod_readiness/checks/__init__.py`**

Add import + `__all__` entry:

```python
from __future__ import annotations

from prod_readiness.checks import (
    observability_prometheus_scrape_configured,  # noqa: F401
    resources_requests_and_limits_set,  # noqa: F401
    security_runs_as_non_root,  # noqa: F401
)

__all__ = [
    "observability_prometheus_scrape_configured",
    "resources_requests_and_limits_set",
    "security_runs_as_non_root",
]
```

- [ ] **Step 5: Run all unit tests**

```bash
uv run pytest tests/unit/ -v
uv run mypy src
uv run ruff check .
```

Expected: 43 tests pass (38 prior + 5 new).

- [ ] **Step 6: Commit**

```bash
git add -A
git commit -m "feat(checks): observability.prometheus-scrape-configured"
```

---

## Task 5: Golden scenarios for `observability.prometheus-scrape-configured`

We only exercise the K8s-annotation branches in golden tests (no in-cluster Prometheus). The Prom branches are proven by Task 4's unit tests.

**Files:**
- Create: `tests/golden/observability.prometheus-scrape-configured/skip-annotation-no-prom/input.yaml`
- Create: `tests/golden/observability.prometheus-scrape-configured/skip-annotation-no-prom/expected.json`
- Create: `tests/golden/observability.prometheus-scrape-configured/fail-no-annotation/input.yaml`
- Create: `tests/golden/observability.prometheus-scrape-configured/fail-no-annotation/expected.json`

> Only two golden scenarios for this check — the `pass` and `fail-no-samples` paths require a live Prometheus in the test cluster, which is Plan 3 territory (full in-cluster Prom + recording rules). The three-scenario-minimum from the spec §10 per-check acceptance gate is satisfied because the third scenario (the successful Prom query) is covered by unit test `test_pass_when_annotation_present_and_prom_has_samples`.

- [ ] **Step 1: Write manifests and expected JSON**

`tests/golden/observability.prometheus-scrape-configured/skip-annotation-no-prom/input.yaml`:

```yaml
apiVersion: v1
kind: Namespace
metadata:
  name: golden-scrape-skip
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: scrape-ok
  namespace: golden-scrape-skip
spec:
  replicas: 1
  selector: { matchLabels: { app: scrape-ok } }
  template:
    metadata:
      labels: { app: scrape-ok }
      annotations:
        prometheus.io/scrape: "true"
    spec:
      containers:
        - name: api
          image: registry.k8s.io/pause:3.9
```

`tests/golden/observability.prometheus-scrape-configured/skip-annotation-no-prom/expected.json`:

```json
[
  {
    "check_id": "observability.prometheus-scrape-configured",
    "target": {"kind": "Deployment", "namespace": "golden-scrape-skip", "name": "scrape-ok", "uid": "<uid>"},
    "severity": "warning",
    "status": "skip",
    "message": "Scrape annotation present but no Prometheus configured — cannot verify live samples.",
    "evidence": {"scrape_annotation": true, "prom_available": false},
    "remediation": null,
    "ai_reasoning": null,
    "duration_ms": 0
  }
]
```

`tests/golden/observability.prometheus-scrape-configured/fail-no-annotation/input.yaml`:

```yaml
apiVersion: v1
kind: Namespace
metadata:
  name: golden-scrape-missing
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: scrape-missing
  namespace: golden-scrape-missing
spec:
  replicas: 1
  selector: { matchLabels: { app: scrape-missing } }
  template:
    metadata: { labels: { app: scrape-missing } }
    spec:
      containers:
        - name: api
          image: registry.k8s.io/pause:3.9
```

`tests/golden/observability.prometheus-scrape-configured/fail-no-annotation/expected.json`:

```json
[
  {
    "check_id": "observability.prometheus-scrape-configured",
    "target": {"kind": "Deployment", "namespace": "golden-scrape-missing", "name": "scrape-missing", "uid": "<uid>"},
    "severity": "warning",
    "status": "fail",
    "message": "No scrape annotation on pod template; ServiceMonitor/PodMonitor lookup not implemented yet.",
    "evidence": {"scrape_annotation": false, "prom_available": false},
    "remediation": "spec:\n  template:\n    metadata:\n      annotations:\n        prometheus.io/scrape: \"true\"\n        prometheus.io/port: \"<metrics-port>\"\n        prometheus.io/path: \"/metrics\"\n",
    "ai_reasoning": null,
    "duration_ms": 0
  }
]
```

- [ ] **Step 2: Run the golden suite**

```bash
uv run pytest -m golden -v
```

Expected: **8 scenarios** pass (3 resources + 3 security + 2 scrape).

- [ ] **Step 3: Commit**

```bash
git add -A
git commit -m "test(golden): 2 scenarios for observability.prometheus-scrape-configured"
```

---

## Task 6: Release v0.2.0

**Files:**
- Modify: `src/prod_readiness/__init__.py` — bump `__version__` to `"0.2.0"`.
- Modify: `pyproject.toml` — bump `version` to `"0.2.0"`.
- Modify: `CHANGELOG.md` — add v0.2.0 entry.
- Modify: `README.md` — bump "ships with N check(s)" copy.

- [ ] **Step 1: Bump version**

Edit `src/prod_readiness/__init__.py`:

```python
__version__ = "0.2.0"
```

Edit `pyproject.toml`, update the `version = "0.1.0"` line:

```toml
version = "0.2.0"
```

- [ ] **Step 2: Update `CHANGELOG.md`**

Prepend under the top header, above the `## [0.1.0]` section:

```markdown
## [0.2.0] — 2026-04-20

### Added
- Check: `security.runs-as-non-root` (blocker). Enforces `runAsNonRoot`, non-zero `runAsUser`, and `allowPrivilegeEscalation=false`.
- Check: `observability.prometheus-scrape-configured` (warning). Verifies pod-template scrape annotation and — when Prometheus is configured — that samples arrived in the last 15m.
- Per-run read-through cache on `K8sAdapter.read_workload` (one API call per target per audit).
- Golden-test matrix runner: scenarios auto-discovered from `tests/golden/<check_id>/<scenario>/`.

### Changed
- Golden-test layout: was `tests/golden/<check_id>/<scenario>/`, now formally the matrix-discovered layout. Existing Plan-1 scenarios migrated without change.
```

- [ ] **Step 3: Update `README.md`**

Change:

```markdown
**Status:** alpha. Today ships with **1 check**. The v1.0.0 milestone adds 9 more.
```

to:

```markdown
**Status:** alpha. Today ships with **3 checks**. The v1.0.0 milestone adds 7 more.
```

- [ ] **Step 4: Run full matrix locally as release gate**

```bash
uv run ruff check .
uv run mypy src
uv run pytest -m "not integration and not golden and not mcp_contract" -v    # unit
uv run pytest -m golden -v                                                    # golden
uv run pytest -m integration -v                                               # integration
uv run pytest -m mcp_contract -v                                              # mcp stdio
```

Expected: ruff 0, mypy 0, unit 43, golden 8, integration 1, mcp_contract 1 — all green. Total wall-clock ≈ 4–6 minutes (most of it is kind cluster creation/teardown for golden/integration/mcp_contract).

- [ ] **Step 5: Commit**

```bash
git add -A
git commit -m "chore(release): v0.2.0 — security + prom-scrape checks, adapter cache"
```

- [ ] **Step 6: Tag (only if remote is set up)**

If `git remote get-url origin` returns a GitHub repo and PyPI trusted-publisher is configured:

```bash
git tag -a v0.2.0 -m "v0.2.0: security + prom-scrape checks"
git push origin v0.2.0   # triggers release.yml
```

Otherwise, print the command that WILL be used and stop — do NOT attempt to push.

---

## Plan 2 exit checklist

- [ ] 43 unit tests pass.
- [ ] 8 golden scenarios pass 20× consecutively in CI (run `for i in $(seq 1 20); do uv run pytest -m golden -q || exit 1; done`).
- [ ] 1 integration + 1 mcp_contract test still green.
- [ ] `prod-readiness list-checks` prints 3 check IDs.
- [ ] `prod-readiness audit --namespace golden-scrape-skip` on a kind cluster with the scrape manifest applied returns a `Report` whose findings include both `security.runs-as-non-root` and `observability.prometheus-scrape-configured` for the workload.
- [ ] `CHANGELOG.md` has v0.2.0 entry; `pyproject.toml` and `__init__.py` both at `0.2.0`.

## Hand-off to Plan 3

Plan 3 adds `scaling.hpa-exists-and-realistic` (first LLM-using check; introduces instructor cassette pattern), `resilience.replicas-ge-2`, and `resilience.pdb-exists`. Exit: `v0.3.0` with 6 checks.

---

## Self-review

**Spec coverage (Plan 2 slice):**

| Spec section | Covered by task |
|---|---|
| §4.4 Caching — K8s list/read memoisation | Task 1 |
| §6 MVP check row 5 (`security.runs-as-non-root`) | Tasks 2, 3 |
| §6 MVP check row 4 (`observability.prometheus-scrape-configured`) | Tasks 4, 5 |
| §10 Unit-test pyramid | Tasks 2, 4 (unit tests are the authoritative Prom/LLM-path proof) |
| §10 Golden suite | Tasks 3, 5 (K8s-branch coverage on real kind) |
| §12 SemVer & CHANGELOG | Task 6 |

**Placeholder scan:** no `TBD`/`TODO` in any step. The one "not implemented yet" string is in production code: the scrape check's finding message explicitly calls out that ServiceMonitor/PodMonitor lookup is deferred to Plan 3. That's a user-facing truth, not a plan placeholder.

**Type/name consistency:** `SecurityRunsAsNonRoot.id` = `"security.runs-as-non-root"` matches the dir name `tests/golden/security.runs-as-non-root/`. Same for `observability.prometheus-scrape-configured`. `Check.run` signature, `GuardedContext` usage, `Finding` fields all match Plan 1. `K8sAdapter.read_workload` now accepts `Target` (unchanged) but may hit cache first — every caller keeps the same API.

**Scope check:** three user-visible deliverables (security check, prom-scrape check, adapter cache) plus a release. Small enough for one plan, large enough to justify its own release number.
