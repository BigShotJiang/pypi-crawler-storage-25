# mcp-prod-readiness — Plan 1: Walking Skeleton + First Check

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Ship `mcp-prod-readiness v0.1.0` — a working MCP server + CLI that audits a Kubernetes cluster against one real check (`resources.requests-and-limits-set`), with full test coverage (unit + golden + integration + MCP contract) and basic CI. Every piece of core machinery needed for Plan 2 is built and proven by one real check passing end-to-end.

**Architecture:** Python 3.11+, async-first. Plugin-registered `Check` classes run by an `Orchestrator` that fans out over K8s targets, gated by a capability-based `Router`. `AuditContext` holds adapters (K8s, Prometheus, LLM via litellm+instructor). Dual surface: FastMCP server (stdio) and Typer CLI share one `orchestrator.audit()` entry point. Reports rendered as JSON, Markdown, JUnit-XML, HTML.

**Tech Stack:** Python 3.11, `kubernetes_asyncio`, `httpx`, `pydantic` v2, `fastmcp`, `typer`, `litellm`, `instructor`, `pytest` + `pytest-asyncio`, `kind` for integration tests, `uv` for env management, `ruff` + `mypy` for lint/type, `opentelemetry-api`.

**Spec:** `docs/superpowers/specs/2026-04-20-mcp-prod-readiness-design.md`

**Working directory for this plan:** `04-mcp-prod-readiness/` (monorepo dir will be initialised as its own git repo by Task 1).

---

## Conventions all tasks follow

- All code uses `from __future__ import annotations`.
- All async functions; sync code only at CLI entry boundary (Typer wraps `asyncio.run`).
- One class per file where sensible. Files stay ≤ 200 lines; split if they grow.
- No comments except where WHY is non-obvious.
- Each task ends with a commit. Commit messages follow Conventional Commits (`feat:`, `test:`, `chore:`, `refactor:`, `docs:`).
- Tests use `pytest-asyncio` mode `auto`.
- `uv run <cmd>` is the canonical way to run anything inside the env.

---

## Task 1: Repo scaffolding

**Files:**
- Create: `04-mcp-prod-readiness/pyproject.toml`
- Create: `04-mcp-prod-readiness/.gitignore`
- Create: `04-mcp-prod-readiness/.python-version`
- Create: `04-mcp-prod-readiness/README.md`
- Create: `04-mcp-prod-readiness/src/prod_readiness/__init__.py`
- Create: `04-mcp-prod-readiness/src/prod_readiness/py.typed`
- Create: `04-mcp-prod-readiness/tests/__init__.py`
- Create: `04-mcp-prod-readiness/.pre-commit-config.yaml`
- Create: `04-mcp-prod-readiness/.github/workflows/ci.yml`

- [ ] **Step 1: Initialise git repo**

```bash
cd 04-mcp-prod-readiness
git init
git branch -M main
```

- [ ] **Step 2: Write `.gitignore`**

```
__pycache__/
*.py[cod]
.venv/
.pytest_cache/
.ruff_cache/
.mypy_cache/
dist/
build/
*.egg-info/
.coverage
coverage.xml
htmlcov/
.env
.DS_Store
kind-*.yaml
/tmp/
```

- [ ] **Step 3: Write `.python-version`**

```
3.11
```

- [ ] **Step 4: Write `pyproject.toml`**

```toml
[project]
name = "mcp-prod-readiness"
version = "0.1.0"
description = "Kubernetes production-readiness auditor, exposed as an MCP server and CLI."
readme = "README.md"
requires-python = ">=3.11"
license = { text = "Apache-2.0" }
authors = [{ name = "vellankikoti", email = "vellankikoti@gmail.com" }]
keywords = ["kubernetes", "mcp", "sre", "production-readiness", "audit"]
classifiers = [
  "Development Status :: 3 - Alpha",
  "License :: OSI Approved :: Apache Software License",
  "Programming Language :: Python :: 3.11",
  "Topic :: System :: Systems Administration",
]
dependencies = [
  "pydantic>=2.7",
  "kubernetes-asyncio>=30.1",
  "httpx>=0.27",
  "typer>=0.12",
  "fastmcp>=0.4",
  "litellm>=1.40",
  "instructor>=1.3",
  "opentelemetry-api>=1.25",
  "opentelemetry-sdk>=1.25",
  "rich>=13.7",
]

[project.optional-dependencies]
dev = [
  "pytest>=8.2",
  "pytest-asyncio>=0.23",
  "pytest-cov>=5.0",
  "pytest-httpx>=0.30",
  "ruff>=0.4",
  "mypy>=1.10",
  "types-PyYAML",
  "pre-commit>=3.7",
]

[project.scripts]
prod-readiness = "prod_readiness.cli:app"
mcp-prod-readiness = "prod_readiness.cli:app"

[project.urls]
Homepage = "https://github.com/vellankikoti/mcp-prod-readiness"
Repository = "https://github.com/vellankikoti/mcp-prod-readiness"
Issues = "https://github.com/vellankikoti/mcp-prod-readiness/issues"

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[tool.hatch.build.targets.wheel]
packages = ["src/prod_readiness"]

[tool.ruff]
line-length = 100
target-version = "py311"

[tool.ruff.lint]
select = ["E", "F", "I", "UP", "B", "SIM", "ASYNC", "RUF"]
ignore = ["E501"]

[tool.mypy]
python_version = "3.11"
strict = true
plugins = ["pydantic.mypy"]

[tool.pytest.ini_options]
asyncio_mode = "auto"
testpaths = ["tests"]
addopts = "-ra --strict-markers"
markers = [
  "integration: tests requiring a live kind cluster",
  "golden: golden-test scenarios (requires ephemeral kind)",
  "mcp_contract: MCP stdio contract tests",
]
```

- [ ] **Step 5: Create empty `src/prod_readiness/__init__.py` and `src/prod_readiness/py.typed`**

```python
# src/prod_readiness/__init__.py
__version__ = "0.1.0"
```

`py.typed` is an empty file.

- [ ] **Step 6: Write `README.md` (stub)**

```markdown
# mcp-prod-readiness

Kubernetes production-readiness auditor — MCP server + CLI.

Status: pre-1.0. See `docs/superpowers/specs/` for the design and `docs/superpowers/plans/` for implementation plans.
```

- [ ] **Step 7: Install uv and bootstrap env**

```bash
curl -LsSf https://astral.sh/uv/install.sh | sh  # if not already installed
uv venv
uv pip install -e ".[dev]"
```

- [ ] **Step 8: Write `.pre-commit-config.yaml`**

```yaml
repos:
  - repo: https://github.com/astral-sh/ruff-pre-commit
    rev: v0.4.10
    hooks:
      - id: ruff
      - id: ruff-format
  - repo: https://github.com/pre-commit/mirrors-mypy
    rev: v1.10.0
    hooks:
      - id: mypy
        additional_dependencies: [pydantic>=2.7, types-PyYAML]
```

- [ ] **Step 9: Write `.github/workflows/ci.yml`**

```yaml
name: ci
on:
  push:
    branches: [main]
  pull_request:
permissions:
  contents: read
jobs:
  lint-and-test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: astral-sh/setup-uv@v3
      - run: uv python install 3.11
      - run: uv venv
      - run: uv pip install -e ".[dev]"
      - run: uv run ruff check .
      - run: uv run ruff format --check .
      - run: uv run mypy src
      - run: uv run pytest -m "not integration and not golden and not mcp_contract" --cov=prod_readiness --cov-report=xml
```

- [ ] **Step 10: Verify env and tools run**

```bash
uv run ruff check .
uv run mypy src
uv run pytest --collect-only
```

Expected: all three exit 0 (pytest collects nothing — fine).

- [ ] **Step 11: Commit**

```bash
git add -A
git commit -m "chore: scaffold mcp-prod-readiness project"
```

---

## Task 2: Core enums & models

**Files:**
- Create: `src/prod_readiness/core/__init__.py`
- Create: `src/prod_readiness/core/models.py`
- Create: `tests/unit/test_core_models.py`

- [ ] **Step 1: Write failing test `tests/unit/test_core_models.py`**

```python
from __future__ import annotations

from datetime import datetime, timezone

import pytest
from pydantic import ValidationError

from prod_readiness.core.models import (
    Capability,
    CheckMeta,
    Finding,
    Report,
    Scope,
    Severity,
    Status,
    Target,
)


def test_target_roundtrip():
    t = Target(kind="Deployment", namespace="default", name="api", uid="u-1")
    assert t.model_dump()["uid"] == "u-1"


def test_target_rejects_invalid_kind():
    with pytest.raises(ValidationError):
        Target(kind="Pod", namespace="default", name="x", uid="u")  # type: ignore[arg-type]


def test_finding_requires_enum_values():
    f = Finding(
        check_id="x.y",
        target=Target(kind="Deployment", namespace="default", name="a", uid="u"),
        severity=Severity.BLOCKER,
        status=Status.FAIL,
        message="m",
        evidence={},
        remediation=None,
        ai_reasoning=None,
        duration_ms=1,
    )
    assert f.severity == Severity.BLOCKER


def test_report_summary_is_arbitrary_dict():
    r = Report(
        cluster_context="kind-dev",
        scope=Scope(),
        started_at=datetime.now(timezone.utc),
        finished_at=datetime.now(timezone.utc),
        findings=[],
        summary={"pass": 0, "fail": 0},
        version="0.1.0",
    )
    assert r.summary["pass"] == 0


def test_check_meta_serialises_needs():
    m = CheckMeta(
        id="x.y",
        category="resources",
        severity=Severity.WARNING,
        needs=frozenset({Capability.K8S}),
        description="test",
    )
    dumped = m.model_dump()
    assert dumped["needs"] == ["k8s"]
```

- [ ] **Step 2: Run test to see it fails**

```bash
uv run pytest tests/unit/test_core_models.py -v
```

Expected: ModuleNotFoundError for `prod_readiness.core.models`.

- [ ] **Step 3: Create `src/prod_readiness/core/__init__.py`** (empty).

- [ ] **Step 4: Write `src/prod_readiness/core/models.py`**

```python
from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_serializer


class Severity(str, Enum):
    BLOCKER = "blocker"
    WARNING = "warning"
    INFO = "info"


class Status(str, Enum):
    PASS = "pass"
    FAIL = "fail"
    SKIP = "skip"
    ERROR = "error"


class Capability(str, Enum):
    K8S = "k8s"
    PROM = "prom"
    LLM = "llm"


class Target(BaseModel):
    model_config = ConfigDict(frozen=True)
    kind: Literal["Deployment", "StatefulSet"]
    namespace: str
    name: str
    uid: str


class Finding(BaseModel):
    check_id: str
    target: Target
    severity: Severity
    status: Status
    message: str
    evidence: dict[str, Any] = Field(default_factory=dict)
    remediation: str | None = None
    ai_reasoning: str | None = None
    duration_ms: int = 0


class Scope(BaseModel):
    contexts: list[str] | None = None
    namespaces: list[str] | None = None
    label_selector: str | None = None
    checks: list[str] | None = None


class CheckMeta(BaseModel):
    id: str
    category: str
    severity: Severity
    needs: frozenset[Capability]
    description: str

    @field_serializer("needs")
    def _sort_needs(self, v: frozenset[Capability]) -> list[str]:
        return sorted(c.value for c in v)


class Report(BaseModel):
    cluster_context: str
    scope: Scope
    started_at: datetime
    finished_at: datetime
    findings: list[Finding]
    summary: dict[str, Any]
    version: str


class Explanation(BaseModel):
    finding: Finding
    extra_reasoning: str
    remediation_patch_yaml: str | None = None


class ReportDiff(BaseModel):
    new_failures: list[Finding]
    fixed: list[Finding]
    unchanged: list[Finding]
```

- [ ] **Step 5: Run tests to verify they pass**

```bash
uv run pytest tests/unit/test_core_models.py -v
uv run mypy src
```

Expected: all green.

- [ ] **Step 6: Commit**

```bash
git add -A
git commit -m "feat(core): core enums and pydantic models"
```

---

## Task 3: Check ABC + Registry

**Files:**
- Create: `src/prod_readiness/core/check.py`
- Create: `src/prod_readiness/core/registry.py`
- Create: `tests/unit/test_registry.py`

- [ ] **Step 1: Write failing test**

```python
# tests/unit/test_registry.py
from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from prod_readiness.core.check import Check
from prod_readiness.core.models import Capability, Finding, Severity, Status, Target
from prod_readiness.core.registry import (
    get_check,
    list_checks,
    register_check,
    registry_snapshot,
)


@pytest.fixture(autouse=True)
def _clear_registry():
    snap = registry_snapshot()
    yield
    snap.restore()


def test_register_and_lookup():
    @register_check
    class DummyCheck(Check):
        id = "dummy.ok"
        category = "documentation"
        severity = Severity.INFO
        needs = frozenset({Capability.K8S})
        description = "dummy"

        async def run(self, ctx, target):  # type: ignore[override]
            return Finding(
                check_id=self.id,
                target=target,
                severity=self.severity,
                status=Status.PASS,
                message="ok",
            )

    assert get_check("dummy.ok") is DummyCheck
    assert any(c.id == "dummy.ok" for c in list_checks())


def test_duplicate_id_raises():
    @register_check
    class A(Check):
        id = "dup.id"
        category = "x"
        severity = Severity.INFO
        needs = frozenset()
        description = "a"

        async def run(self, ctx, target): ...

    with pytest.raises(ValueError, match="already registered"):

        @register_check
        class B(Check):
            id = "dup.id"
            category = "x"
            severity = Severity.INFO
            needs = frozenset()
            description = "b"

            async def run(self, ctx, target): ...
```

- [ ] **Step 2: Run test to see it fails**

```bash
uv run pytest tests/unit/test_registry.py -v
```

Expected: import error.

- [ ] **Step 3: Write `src/prod_readiness/core/check.py`**

```python
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, ClassVar

from prod_readiness.core.models import Capability, Finding, Severity, Target

if TYPE_CHECKING:
    from prod_readiness.core.context import AuditContext


class Check(ABC):
    id: ClassVar[str]
    category: ClassVar[str]
    severity: ClassVar[Severity]
    needs: ClassVar[frozenset[Capability]]
    description: ClassVar[str]

    @abstractmethod
    async def run(self, ctx: "AuditContext", target: Target) -> Finding: ...
```

- [ ] **Step 4: Write `src/prod_readiness/core/registry.py`**

```python
from __future__ import annotations

from dataclasses import dataclass

from prod_readiness.core.check import Check

_REGISTRY: dict[str, type[Check]] = {}


def register_check(cls: type[Check]) -> type[Check]:
    if cls.id in _REGISTRY:
        raise ValueError(f"check id {cls.id!r} already registered")
    _REGISTRY[cls.id] = cls
    return cls


def get_check(check_id: str) -> type[Check]:
    return _REGISTRY[check_id]


def list_checks() -> list[type[Check]]:
    return sorted(_REGISTRY.values(), key=lambda c: c.id)


@dataclass
class _Snapshot:
    saved: dict[str, type[Check]]

    def restore(self) -> None:
        _REGISTRY.clear()
        _REGISTRY.update(self.saved)


def registry_snapshot() -> _Snapshot:
    return _Snapshot(saved=dict(_REGISTRY))
```

- [ ] **Step 5: Run tests**

```bash
uv run pytest tests/unit/test_registry.py -v
```

Expected: green.

- [ ] **Step 6: Commit**

```bash
git add -A
git commit -m "feat(core): Check ABC and plugin registry"
```

---

## Task 4: LLM adapter (litellm + instructor + offline fallback)

**Files:**
- Create: `src/prod_readiness/adapters/__init__.py`
- Create: `src/prod_readiness/adapters/llm.py`
- Create: `tests/unit/test_llm_adapter.py`

- [ ] **Step 1: Write failing test**

```python
# tests/unit/test_llm_adapter.py
from __future__ import annotations

import pytest
from pydantic import BaseModel

from prod_readiness.adapters.llm import LLMAdapter, LLMConfig, OfflineError


class _Out(BaseModel):
    verdict: str


@pytest.mark.asyncio
async def test_offline_mode_raises_offline_error():
    adapter = LLMAdapter(LLMConfig(offline=True))
    with pytest.raises(OfflineError):
        await adapter.structured("why?", response_model=_Out)


@pytest.mark.asyncio
async def test_offline_detected_when_no_provider_and_ollama_unreachable(monkeypatch):
    async def _unreachable(*a, **kw):
        raise ConnectionError("nope")

    monkeypatch.setattr(
        "prod_readiness.adapters.llm._probe_ollama", _unreachable
    )
    adapter = LLMAdapter(LLMConfig(provider=None, base_url=None, api_key=None))
    await adapter.ensure_ready()  # should not raise
    assert adapter.effectively_offline is True
    with pytest.raises(OfflineError):
        await adapter.structured("q", response_model=_Out)


def test_config_precedence_flag_beats_env(monkeypatch):
    monkeypatch.setenv("PROD_READINESS_LLM_PROVIDER", "openai/gpt-4o")
    cfg = LLMConfig.from_sources(cli_provider="anthropic/claude-sonnet-4-6")
    assert cfg.provider == "anthropic/claude-sonnet-4-6"
```

- [ ] **Step 2: Run test to see it fails**

```bash
uv run pytest tests/unit/test_llm_adapter.py -v
```

Expected: import error.

- [ ] **Step 3: Write `src/prod_readiness/adapters/__init__.py`** (empty).

- [ ] **Step 4: Write `src/prod_readiness/adapters/llm.py`**

```python
from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import TypeVar

import httpx
from pydantic import BaseModel

T = TypeVar("T", bound=BaseModel)


class OfflineError(RuntimeError):
    """Raised when an LLM call is attempted in offline mode."""


@dataclass
class LLMConfig:
    provider: str | None = None
    base_url: str | None = None
    api_key: str | None = None
    offline: bool = False
    timeout_s: float = 30.0
    extra: dict[str, str] = field(default_factory=dict)

    @classmethod
    def from_sources(
        cls,
        *,
        cli_provider: str | None = None,
        cli_base_url: str | None = None,
        cli_api_key: str | None = None,
        cli_offline: bool | None = None,
    ) -> "LLMConfig":
        offline = (
            cli_offline
            if cli_offline is not None
            else os.environ.get("PROD_READINESS_OFFLINE") == "1"
        )
        return cls(
            provider=cli_provider or os.environ.get("PROD_READINESS_LLM_PROVIDER"),
            base_url=cli_base_url or os.environ.get("PROD_READINESS_LLM_BASE_URL"),
            api_key=cli_api_key or os.environ.get("PROD_READINESS_LLM_API_KEY"),
            offline=offline,
        )


async def _probe_ollama(url: str, timeout: float = 1.0) -> bool:
    async with httpx.AsyncClient(timeout=timeout) as c:
        r = await c.get(url.rstrip("/") + "/api/tags")
        return r.status_code == 200


class LLMAdapter:
    def __init__(self, config: LLMConfig) -> None:
        self.config = config
        self._ready = False
        self._effectively_offline = config.offline

    @property
    def effectively_offline(self) -> bool:
        return self._effectively_offline

    async def ensure_ready(self) -> None:
        if self._ready:
            return
        if self.config.offline:
            self._effectively_offline = True
        elif self.config.provider is None:
            url = self.config.base_url or "http://localhost:11434"
            try:
                ok = await _probe_ollama(url)
            except Exception:
                ok = False
            if not ok:
                self._effectively_offline = True
            else:
                self.config.provider = "ollama/qwen2.5:7b"
                self.config.base_url = url
        self._ready = True

    async def structured(
        self,
        prompt: str,
        *,
        response_model: type[T],
        system: str | None = None,
    ) -> T:
        await self.ensure_ready()
        if self._effectively_offline:
            raise OfflineError("LLM unavailable; running in offline mode")
        # Real call happens here. We import lazily so unit tests that mock
        # ensure_ready() can skip installing the network path.
        import instructor  # noqa: PLC0415
        from litellm import acompletion  # noqa: PLC0415

        client = instructor.from_litellm(acompletion)
        messages: list[dict[str, str]] = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})
        return await client.chat.completions.create(  # type: ignore[no-any-return]
            model=self.config.provider,
            messages=messages,
            response_model=response_model,
            api_key=self.config.api_key,
            api_base=self.config.base_url,
            timeout=self.config.timeout_s,
        )
```

- [ ] **Step 5: Run tests**

```bash
uv run pytest tests/unit/test_llm_adapter.py -v
```

Expected: green.

- [ ] **Step 6: Commit**

```bash
git add -A
git commit -m "feat(adapters): LLM adapter via litellm+instructor with offline fallback"
```

---

## Task 5: K8s adapter

**Files:**
- Create: `src/prod_readiness/adapters/k8s.py`
- Create: `tests/unit/test_k8s_adapter.py`

- [ ] **Step 1: Write failing test**

```python
# tests/unit/test_k8s_adapter.py
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from prod_readiness.adapters.k8s import K8sAdapter
from prod_readiness.core.models import Target


@pytest.mark.asyncio
async def test_list_targets_merges_deployments_and_statefulsets(monkeypatch):
    fake_apps = MagicMock()
    fake_apps.list_namespaced_deployment = AsyncMock(
        return_value=MagicMock(
            items=[
                MagicMock(
                    metadata=MagicMock(
                        namespace="default", name="api", uid="u-1", labels={}
                    )
                )
            ]
        )
    )
    fake_apps.list_namespaced_stateful_set = AsyncMock(
        return_value=MagicMock(
            items=[
                MagicMock(
                    metadata=MagicMock(
                        namespace="default", name="db", uid="u-2", labels={}
                    )
                )
            ]
        )
    )

    adapter = K8sAdapter.__new__(K8sAdapter)
    adapter._apps = fake_apps  # type: ignore[attr-defined]
    adapter._core = MagicMock()  # type: ignore[attr-defined]
    adapter.context_name = "kind-test"  # type: ignore[attr-defined]

    targets = await adapter.list_targets(
        namespaces=["default"], label_selector=None
    )
    kinds = {t.kind for t in targets}
    assert kinds == {"Deployment", "StatefulSet"}
    assert all(isinstance(t, Target) for t in targets)
```

- [ ] **Step 2: Run test to see it fails**

```bash
uv run pytest tests/unit/test_k8s_adapter.py -v
```

Expected: import error.

- [ ] **Step 3: Write `src/prod_readiness/adapters/k8s.py`**

```python
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from kubernetes_asyncio import client as k8s_client
from kubernetes_asyncio import config as k8s_config

from prod_readiness.core.models import Target


@dataclass
class K8sConfig:
    context: str | None = None
    in_cluster: bool = False


class K8sAdapter:
    def __init__(self, cfg: K8sConfig) -> None:
        self.cfg = cfg
        self.context_name: str = cfg.context or "current-context"
        self._apps: k8s_client.AppsV1Api | None = None
        self._core: k8s_client.CoreV1Api | None = None
        self._policy: k8s_client.PolicyV1Api | None = None
        self._api_client: k8s_client.ApiClient | None = None

    async def connect(self) -> None:
        if self.cfg.in_cluster:
            k8s_config.load_incluster_config()
        else:
            await k8s_config.load_kube_config(context=self.cfg.context)
        self._api_client = k8s_client.ApiClient()
        self._apps = k8s_client.AppsV1Api(self._api_client)
        self._core = k8s_client.CoreV1Api(self._api_client)
        self._policy = k8s_client.PolicyV1Api(self._api_client)

    async def close(self) -> None:
        if self._api_client is not None:
            await self._api_client.close()

    async def list_namespaces(self) -> list[str]:
        assert self._core is not None
        resp = await self._core.list_namespace()
        return [ns.metadata.name for ns in resp.items]

    async def list_targets(
        self,
        *,
        namespaces: list[str] | None,
        label_selector: str | None,
    ) -> list[Target]:
        assert self._apps is not None
        if namespaces is None:
            namespaces = await self.list_namespaces()
        out: list[Target] = []
        for ns in namespaces:
            deps = await self._apps.list_namespaced_deployment(
                namespace=ns, label_selector=label_selector or ""
            )
            for d in deps.items:
                out.append(
                    Target(
                        kind="Deployment",
                        namespace=d.metadata.namespace,
                        name=d.metadata.name,
                        uid=d.metadata.uid,
                    )
                )
            sts = await self._apps.list_namespaced_stateful_set(
                namespace=ns, label_selector=label_selector or ""
            )
            for s in sts.items:
                out.append(
                    Target(
                        kind="StatefulSet",
                        namespace=s.metadata.namespace,
                        name=s.metadata.name,
                        uid=s.metadata.uid,
                    )
                )
        return out

    async def read_workload(self, target: Target) -> Any:
        assert self._apps is not None
        if target.kind == "Deployment":
            return await self._apps.read_namespaced_deployment(
                name=target.name, namespace=target.namespace
            )
        return await self._apps.read_namespaced_stateful_set(
            name=target.name, namespace=target.namespace
        )
```

- [ ] **Step 4: Run test to verify it passes**

```bash
uv run pytest tests/unit/test_k8s_adapter.py -v
```

Expected: green.

- [ ] **Step 5: Commit**

```bash
git add -A
git commit -m "feat(adapters): async K8s adapter with list/read for Deployments+StatefulSets"
```

---

## Task 6: Prometheus adapter

**Files:**
- Create: `src/prod_readiness/adapters/prom.py`
- Create: `tests/unit/test_prom_adapter.py`

- [ ] **Step 1: Write failing test**

```python
# tests/unit/test_prom_adapter.py
from __future__ import annotations

import pytest
from pytest_httpx import HTTPXMock

from prod_readiness.adapters.prom import PromAdapter, PromConfig


@pytest.mark.asyncio
async def test_instant_query(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url="http://prom:9090/api/v1/query?query=up",
        json={
            "status": "success",
            "data": {"resultType": "vector", "result": [{"value": [123, "1"]}]},
        },
    )
    p = PromAdapter(PromConfig(base_url="http://prom:9090"))
    result = await p.query("up")
    assert result["result"][0]["value"][1] == "1"


@pytest.mark.asyncio
async def test_missing_base_url_returns_unavailable(monkeypatch):
    p = PromAdapter(PromConfig(base_url=None))
    assert p.available is False
    with pytest.raises(RuntimeError, match="Prometheus base URL not configured"):
        await p.query("up")
```

- [ ] **Step 2: Run test to see it fails**

```bash
uv run pytest tests/unit/test_prom_adapter.py -v
```

Expected: import error.

- [ ] **Step 3: Write `src/prod_readiness/adapters/prom.py`**

```python
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import httpx


@dataclass
class PromConfig:
    base_url: str | None = None
    timeout_s: float = 10.0


class PromAdapter:
    def __init__(self, cfg: PromConfig) -> None:
        self.cfg = cfg
        self._client: httpx.AsyncClient | None = None
        self._cache: dict[tuple[str, str], dict[str, Any]] = {}

    @property
    def available(self) -> bool:
        return self.cfg.base_url is not None

    async def _ensure_client(self) -> httpx.AsyncClient:
        if self._client is None:
            if self.cfg.base_url is None:
                raise RuntimeError("Prometheus base URL not configured")
            self._client = httpx.AsyncClient(
                base_url=self.cfg.base_url, timeout=self.cfg.timeout_s
            )
        return self._client

    async def close(self) -> None:
        if self._client is not None:
            await self._client.aclose()

    async def query(self, promql: str) -> dict[str, Any]:
        key = ("instant", promql)
        if key in self._cache:
            return self._cache[key]
        client = await self._ensure_client()
        r = await client.get("/api/v1/query", params={"query": promql})
        r.raise_for_status()
        data = r.json()
        if data.get("status") != "success":
            raise RuntimeError(f"Prometheus query failed: {data}")
        self._cache[key] = data["data"]
        return data["data"]

    async def query_range(
        self, promql: str, start: float, end: float, step: float
    ) -> dict[str, Any]:
        key = ("range", f"{promql}|{start}|{end}|{step}")
        if key in self._cache:
            return self._cache[key]
        client = await self._ensure_client()
        r = await client.get(
            "/api/v1/query_range",
            params={"query": promql, "start": start, "end": end, "step": step},
        )
        r.raise_for_status()
        data = r.json()
        if data.get("status") != "success":
            raise RuntimeError(f"Prometheus range query failed: {data}")
        self._cache[key] = data["data"]
        return data["data"]
```

- [ ] **Step 4: Run tests**

```bash
uv run pytest tests/unit/test_prom_adapter.py -v
```

Expected: green.

- [ ] **Step 5: Commit**

```bash
git add -A
git commit -m "feat(adapters): async Prometheus adapter with response cache"
```

---

## Task 7: AuditContext

**Files:**
- Create: `src/prod_readiness/core/context.py`
- Create: `tests/unit/test_context.py`

- [ ] **Step 1: Write failing test**

```python
# tests/unit/test_context.py
from __future__ import annotations

import pytest

from prod_readiness.adapters.k8s import K8sAdapter, K8sConfig
from prod_readiness.adapters.llm import LLMAdapter, LLMConfig
from prod_readiness.adapters.prom import PromAdapter, PromConfig
from prod_readiness.core.context import AuditContext
from prod_readiness.core.models import Capability


@pytest.mark.asyncio
async def test_guard_blocks_undeclared_capabilities():
    ctx = AuditContext(
        k8s=K8sAdapter(K8sConfig()),
        prom=PromAdapter(PromConfig()),
        llm=LLMAdapter(LLMConfig(offline=True)),
    )
    guarded = ctx.guard(needs=frozenset({Capability.K8S}))
    assert guarded.k8s is ctx.k8s
    with pytest.raises(PermissionError, match="capability not declared: prom"):
        guarded.prom
    with pytest.raises(PermissionError, match="capability not declared: llm"):
        guarded.llm
```

- [ ] **Step 2: Run test to see it fails**

```bash
uv run pytest tests/unit/test_context.py -v
```

Expected: import error.

- [ ] **Step 3: Write `src/prod_readiness/core/context.py`**

```python
from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from prod_readiness.core.models import Capability

if TYPE_CHECKING:
    from prod_readiness.adapters.k8s import K8sAdapter
    from prod_readiness.adapters.llm import LLMAdapter
    from prod_readiness.adapters.prom import PromAdapter


@dataclass
class AuditContext:
    k8s: "K8sAdapter"
    prom: "PromAdapter"
    llm: "LLMAdapter"
    scratch: dict[str, object] = field(default_factory=dict)

    def guard(self, *, needs: frozenset[Capability]) -> "GuardedContext":
        return GuardedContext(self, needs)


class GuardedContext:
    def __init__(self, inner: AuditContext, needs: frozenset[Capability]) -> None:
        self._inner = inner
        self._needs = needs

    @property
    def k8s(self) -> "K8sAdapter":
        if Capability.K8S not in self._needs:
            raise PermissionError("capability not declared: k8s")
        return self._inner.k8s

    @property
    def prom(self) -> "PromAdapter":
        if Capability.PROM not in self._needs:
            raise PermissionError("capability not declared: prom")
        return self._inner.prom

    @property
    def llm(self) -> "LLMAdapter":
        if Capability.LLM not in self._needs:
            raise PermissionError("capability not declared: llm")
        return self._inner.llm

    @property
    def scratch(self) -> dict[str, object]:
        return self._inner.scratch
```

- [ ] **Step 4: Run tests**

```bash
uv run pytest tests/unit/test_context.py -v
```

Expected: green.

- [ ] **Step 5: Commit**

```bash
git add -A
git commit -m "feat(core): AuditContext with capability-guarded view"
```

---

## Task 8: Router + Orchestrator

**Files:**
- Create: `src/prod_readiness/core/orchestrator.py`
- Create: `tests/unit/test_orchestrator.py`

> The router lives inside the orchestrator — it is the capability-guard plus
> the per-check timeout policy. A separate file is YAGNI.

- [ ] **Step 1: Write failing test**

```python
# tests/unit/test_orchestrator.py
from __future__ import annotations

from datetime import timezone
from unittest.mock import AsyncMock, MagicMock

import pytest

from prod_readiness.core.check import Check
from prod_readiness.core.context import AuditContext
from prod_readiness.core.models import Capability, Finding, Scope, Severity, Status, Target
from prod_readiness.core.orchestrator import Orchestrator
from prod_readiness.core.registry import register_check, registry_snapshot


@pytest.fixture(autouse=True)
def _isolate_registry():
    snap = registry_snapshot()
    yield
    snap.restore()


@pytest.mark.asyncio
async def test_full_run_produces_report_with_summary():
    @register_check
    class OkCheck(Check):
        id = "x.ok"
        category = "resources"
        severity = Severity.INFO
        needs = frozenset({Capability.K8S})
        description = "ok"

        async def run(self, ctx, target):
            return Finding(
                check_id=self.id,
                target=target,
                severity=self.severity,
                status=Status.PASS,
                message="ok",
            )

    @register_check
    class ErrCheck(Check):
        id = "x.boom"
        category = "resources"
        severity = Severity.WARNING
        needs = frozenset({Capability.K8S})
        description = "boom"

        async def run(self, ctx, target):
            raise RuntimeError("nope")

    k8s = MagicMock()
    k8s.context_name = "kind-unit"
    k8s.list_targets = AsyncMock(
        return_value=[Target(kind="Deployment", namespace="d", name="a", uid="u")]
    )
    ctx = AuditContext(k8s=k8s, prom=MagicMock(), llm=MagicMock())
    orch = Orchestrator(ctx=ctx, version="0.1.0", concurrency=4, per_check_timeout_s=2.0)

    report = await orch.audit(Scope(namespaces=["d"]))

    assert report.cluster_context == "kind-unit"
    assert len(report.findings) == 2
    statuses = {f.status for f in report.findings}
    assert Status.PASS in statuses
    assert Status.ERROR in statuses
    assert report.summary["fail_or_error"] == 1
    assert report.started_at.tzinfo is timezone.utc


@pytest.mark.asyncio
async def test_timeout_marks_error():
    @register_check
    class Slow(Check):
        id = "x.slow"
        category = "resources"
        severity = Severity.INFO
        needs = frozenset({Capability.K8S})
        description = "slow"

        async def run(self, ctx, target):
            import asyncio

            await asyncio.sleep(5)
            raise AssertionError("should have timed out")

    k8s = MagicMock()
    k8s.context_name = "kind"
    k8s.list_targets = AsyncMock(
        return_value=[Target(kind="Deployment", namespace="d", name="a", uid="u")]
    )
    ctx = AuditContext(k8s=k8s, prom=MagicMock(), llm=MagicMock())
    orch = Orchestrator(ctx=ctx, version="0.1.0", concurrency=2, per_check_timeout_s=0.05)

    report = await orch.audit(Scope(namespaces=["d"]))
    assert report.findings[0].status == Status.ERROR
    assert "timeout" in report.findings[0].message.lower()
```

- [ ] **Step 2: Run test to see it fails**

```bash
uv run pytest tests/unit/test_orchestrator.py -v
```

Expected: import error.

- [ ] **Step 3: Write `src/prod_readiness/core/orchestrator.py`**

```python
from __future__ import annotations

import asyncio
import time
from collections import Counter
from dataclasses import dataclass
from datetime import datetime, timezone

from prod_readiness.core.check import Check
from prod_readiness.core.context import AuditContext
from prod_readiness.core.models import (
    Finding,
    Report,
    Scope,
    Severity,
    Status,
    Target,
)
from prod_readiness.core.registry import get_check, list_checks


@dataclass
class Orchestrator:
    ctx: AuditContext
    version: str
    concurrency: int = 16
    per_check_timeout_s: float = 10.0

    async def audit(self, scope: Scope) -> Report:
        started = datetime.now(timezone.utc)
        targets = await self.ctx.k8s.list_targets(
            namespaces=scope.namespaces, label_selector=scope.label_selector
        )
        check_classes = self._select_checks(scope)
        sem = asyncio.Semaphore(self.concurrency)

        async def _run_one(cls: type[Check], target: Target) -> Finding:
            async with sem:
                instance = cls()
                start = time.perf_counter()
                guarded = self.ctx.guard(needs=instance.needs)
                try:
                    coro = instance.run(guarded, target)  # type: ignore[arg-type]
                    f = await asyncio.wait_for(coro, timeout=self.per_check_timeout_s)
                    f = f.model_copy(
                        update={"duration_ms": int((time.perf_counter() - start) * 1000)}
                    )
                    return f
                except asyncio.TimeoutError:
                    return Finding(
                        check_id=cls.id,
                        target=target,
                        severity=cls.severity,
                        status=Status.ERROR,
                        message=f"timeout after {self.per_check_timeout_s}s",
                        duration_ms=int((time.perf_counter() - start) * 1000),
                    )
                except Exception as exc:
                    return Finding(
                        check_id=cls.id,
                        target=target,
                        severity=cls.severity,
                        status=Status.ERROR,
                        message=f"{type(exc).__name__}: {exc}",
                        duration_ms=int((time.perf_counter() - start) * 1000),
                    )

        tasks = [
            asyncio.create_task(_run_one(cls, t))
            for cls in check_classes
            for t in targets
        ]
        findings = list(await asyncio.gather(*tasks)) if tasks else []
        finished = datetime.now(timezone.utc)
        return Report(
            cluster_context=self.ctx.k8s.context_name,
            scope=scope,
            started_at=started,
            finished_at=finished,
            findings=findings,
            summary=_summarise(findings),
            version=self.version,
        )

    def _select_checks(self, scope: Scope) -> list[type[Check]]:
        if scope.checks:
            return [get_check(cid) for cid in scope.checks]
        return list_checks()


def _summarise(findings: list[Finding]) -> dict[str, int]:
    by_status = Counter(f.status.value for f in findings)
    by_severity = Counter(
        f.severity.value for f in findings if f.status in {Status.FAIL, Status.ERROR}
    )
    return {
        **by_status,
        **{f"severity.{k}": v for k, v in by_severity.items()},
        "fail_or_error": by_status.get("fail", 0) + by_status.get("error", 0),
        "total": len(findings),
    }


def worst_severity(findings: list[Finding]) -> Severity | None:
    order = {Severity.INFO: 0, Severity.WARNING: 1, Severity.BLOCKER: 2}
    worst: Severity | None = None
    for f in findings:
        if f.status not in {Status.FAIL, Status.ERROR}:
            continue
        if worst is None or order[f.severity] > order[worst]:
            worst = f.severity
    return worst
```

- [ ] **Step 4: Run tests**

```bash
uv run pytest tests/unit/test_orchestrator.py -v
```

Expected: green.

- [ ] **Step 5: Commit**

```bash
git add -A
git commit -m "feat(core): async orchestrator with per-check timeout and summary"
```

---

## Task 9: Renderers (JSON + Markdown; JUnit + HTML)

**Files:**
- Create: `src/prod_readiness/reports/__init__.py`
- Create: `src/prod_readiness/reports/json.py`
- Create: `src/prod_readiness/reports/markdown.py`
- Create: `src/prod_readiness/reports/junit.py`
- Create: `src/prod_readiness/reports/html.py`
- Create: `tests/unit/test_renderers.py`

- [ ] **Step 1: Write failing test**

```python
# tests/unit/test_renderers.py
from __future__ import annotations

from datetime import datetime, timezone

from prod_readiness.core.models import Finding, Report, Scope, Severity, Status, Target
from prod_readiness.reports.html import render_html
from prod_readiness.reports.json import render_json
from prod_readiness.reports.junit import render_junit
from prod_readiness.reports.markdown import render_markdown


def _sample() -> Report:
    t = Target(kind="Deployment", namespace="d", name="a", uid="u-1")
    return Report(
        cluster_context="kind",
        scope=Scope(),
        started_at=datetime(2026, 4, 20, tzinfo=timezone.utc),
        finished_at=datetime(2026, 4, 20, 0, 0, 1, tzinfo=timezone.utc),
        findings=[
            Finding(
                check_id="x.y",
                target=t,
                severity=Severity.BLOCKER,
                status=Status.FAIL,
                message="missing requests",
                evidence={"container": "api"},
                remediation="set cpu+memory requests",
                duration_ms=3,
            )
        ],
        summary={"fail": 1, "fail_or_error": 1, "total": 1},
        version="0.1.0",
    )


def test_json_is_deterministic():
    r = _sample()
    a = render_json(r)
    b = render_json(r)
    assert a == b
    assert "missing requests" in a


def test_markdown_has_headers_and_severity():
    md = render_markdown(_sample())
    assert "# Production Readiness Report" in md
    assert "BLOCKER" in md
    assert "missing requests" in md


def test_junit_has_testsuite():
    x = render_junit(_sample())
    assert "<testsuite" in x
    assert 'failures="1"' in x


def test_html_has_doctype():
    h = render_html(_sample())
    assert h.lstrip().startswith("<!doctype html")
```

- [ ] **Step 2: Run to see it fails**

```bash
uv run pytest tests/unit/test_renderers.py -v
```

Expected: import error.

- [ ] **Step 3: Write `src/prod_readiness/reports/__init__.py`** (empty).

- [ ] **Step 4: Write `src/prod_readiness/reports/json.py`**

```python
from __future__ import annotations

from prod_readiness.core.models import Report


def render_json(r: Report) -> str:
    return r.model_dump_json(indent=2)
```

- [ ] **Step 5: Write `src/prod_readiness/reports/markdown.py`**

```python
from __future__ import annotations

from prod_readiness.core.models import Report, Status


def render_markdown(r: Report) -> str:
    lines: list[str] = ["# Production Readiness Report", ""]
    lines.append(f"- **Cluster:** `{r.cluster_context}`")
    lines.append(f"- **Started:** {r.started_at.isoformat()}")
    lines.append(f"- **Finished:** {r.finished_at.isoformat()}")
    lines.append(f"- **Tool:** mcp-prod-readiness {r.version}")
    lines.append("")
    lines.append("## Summary")
    for k, v in sorted(r.summary.items()):
        lines.append(f"- `{k}`: {v}")
    lines.append("")
    lines.append("## Findings")
    for f in r.findings:
        icon = {"pass": "✅", "fail": "❌", "skip": "⚪", "error": "⚠️"}[f.status.value]
        lines.append(
            f"### {icon} `{f.check_id}` — {f.severity.value.upper()} — "
            f"{f.target.kind}/{f.target.namespace}/{f.target.name}"
        )
        lines.append("")
        lines.append(f"- **Status:** {f.status.value}")
        lines.append(f"- **Message:** {f.message}")
        if f.evidence:
            lines.append(f"- **Evidence:** `{f.evidence}`")
        if f.remediation:
            lines.append("")
            lines.append("**Remediation:**")
            lines.append("")
            lines.append("```yaml")
            lines.append(f.remediation)
            lines.append("```")
        if f.ai_reasoning:
            lines.append("")
            lines.append("**AI reasoning:**")
            lines.append("")
            lines.append(f.ai_reasoning)
        lines.append("")
    # strip trailing blank
    while lines and lines[-1] == "":
        lines.pop()
    return "\n".join(lines) + "\n"
```

- [ ] **Step 6: Write `src/prod_readiness/reports/junit.py`**

```python
from __future__ import annotations

from xml.sax.saxutils import escape

from prod_readiness.core.models import Report, Status


def render_junit(r: Report) -> str:
    failures = sum(1 for f in r.findings if f.status == Status.FAIL)
    errors = sum(1 for f in r.findings if f.status == Status.ERROR)
    skipped = sum(1 for f in r.findings if f.status == Status.SKIP)
    out: list[str] = []
    out.append('<?xml version="1.0" encoding="UTF-8"?>')
    out.append(
        f'<testsuite name="prod-readiness" tests="{len(r.findings)}" '
        f'failures="{failures}" errors="{errors}" skipped="{skipped}">'
    )
    for f in r.findings:
        classname = f"{f.target.kind}.{f.target.namespace}.{f.target.name}"
        name = escape(f.check_id)
        out.append(f'<testcase classname="{escape(classname)}" name="{name}">')
        if f.status == Status.FAIL:
            out.append(
                f'<failure message="{escape(f.message)}" '
                f'type="{f.severity.value}"></failure>'
            )
        elif f.status == Status.ERROR:
            out.append(f'<error message="{escape(f.message)}"></error>')
        elif f.status == Status.SKIP:
            out.append("<skipped/>")
        out.append("</testcase>")
    out.append("</testsuite>")
    return "\n".join(out) + "\n"
```

- [ ] **Step 7: Write `src/prod_readiness/reports/html.py`**

```python
from __future__ import annotations

from html import escape

from prod_readiness.core.models import Report, Status


def render_html(r: Report) -> str:
    rows: list[str] = []
    for f in r.findings:
        rows.append(
            "<tr>"
            f"<td>{escape(f.status.value)}</td>"
            f"<td>{escape(f.severity.value)}</td>"
            f"<td>{escape(f.check_id)}</td>"
            f"<td>{escape(f.target.kind)}/{escape(f.target.namespace)}/"
            f"{escape(f.target.name)}</td>"
            f"<td>{escape(f.message)}</td>"
            "</tr>"
        )
    return (
        "<!doctype html>\n<html><head><meta charset='utf-8'>"
        "<title>Prod-Readiness Report</title></head><body>"
        f"<h1>Prod-Readiness Report — {escape(r.cluster_context)}</h1>"
        "<table border='1'><tr><th>Status</th><th>Severity</th>"
        "<th>Check</th><th>Target</th><th>Message</th></tr>"
        + "".join(rows)
        + "</table></body></html>\n"
    )
```

- [ ] **Step 8: Run tests**

```bash
uv run pytest tests/unit/test_renderers.py -v
```

Expected: green.

- [ ] **Step 9: Commit**

```bash
git add -A
git commit -m "feat(reports): JSON, Markdown, JUnit-XML, and HTML renderers"
```

---

## Task 10: First check — `resources.requests-and-limits-set`

**Files:**
- Create: `src/prod_readiness/checks/__init__.py`
- Create: `src/prod_readiness/checks/resources_requests_and_limits_set.py`
- Create: `tests/unit/test_check_resources_requests_and_limits_set.py`

- [ ] **Step 1: Write failing test**

```python
# tests/unit/test_check_resources_requests_and_limits_set.py
from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock

import pytest

from prod_readiness.checks.resources_requests_and_limits_set import (
    ResourcesRequestsAndLimitsSet,
)
from prod_readiness.core.context import AuditContext
from prod_readiness.core.models import Status, Target


def _wl(containers: list[dict]) -> object:
    pod_spec = SimpleNamespace(
        containers=[
            SimpleNamespace(
                name=c["name"],
                resources=SimpleNamespace(
                    requests=c.get("requests"),
                    limits=c.get("limits"),
                ),
            )
            for c in containers
        ]
    )
    return SimpleNamespace(spec=SimpleNamespace(template=SimpleNamespace(spec=pod_spec)))


def _ctx(workload) -> AuditContext:
    k8s = MagicMock()
    k8s.read_workload = AsyncMock(return_value=workload)
    return AuditContext(k8s=k8s, prom=MagicMock(), llm=MagicMock())


def _target() -> Target:
    return Target(kind="Deployment", namespace="d", name="a", uid="u")


@pytest.mark.asyncio
async def test_pass_when_all_containers_have_requests_and_memory_limits():
    wl = _wl(
        [
            {
                "name": "api",
                "requests": {"cpu": "100m", "memory": "128Mi"},
                "limits": {"memory": "256Mi"},
            }
        ]
    )
    ctx = _ctx(wl).guard(needs=ResourcesRequestsAndLimitsSet.needs)
    f = await ResourcesRequestsAndLimitsSet().run(ctx, _target())
    assert f.status == Status.PASS


@pytest.mark.asyncio
async def test_fail_when_cpu_request_missing():
    wl = _wl(
        [{"name": "api", "requests": {"memory": "128Mi"}, "limits": {"memory": "256Mi"}}]
    )
    ctx = _ctx(wl).guard(needs=ResourcesRequestsAndLimitsSet.needs)
    f = await ResourcesRequestsAndLimitsSet().run(ctx, _target())
    assert f.status == Status.FAIL
    assert "cpu" in f.message.lower()
    assert f.evidence["containers"][0]["missing"] == ["requests.cpu"]


@pytest.mark.asyncio
async def test_fail_when_memory_limit_missing():
    wl = _wl(
        [{"name": "api", "requests": {"cpu": "100m", "memory": "128Mi"}, "limits": None}]
    )
    ctx = _ctx(wl).guard(needs=ResourcesRequestsAndLimitsSet.needs)
    f = await ResourcesRequestsAndLimitsSet().run(ctx, _target())
    assert f.status == Status.FAIL
    assert "memory limit" in f.message.lower()


@pytest.mark.asyncio
async def test_remediation_yaml_snippet_included_on_fail():
    wl = _wl([{"name": "api", "requests": None, "limits": None}])
    ctx = _ctx(wl).guard(needs=ResourcesRequestsAndLimitsSet.needs)
    f = await ResourcesRequestsAndLimitsSet().run(ctx, _target())
    assert f.status == Status.FAIL
    assert f.remediation is not None
    assert "resources:" in f.remediation
    assert "requests:" in f.remediation
```

- [ ] **Step 2: Run test to see it fails**

```bash
uv run pytest tests/unit/test_check_resources_requests_and_limits_set.py -v
```

Expected: import error.

- [ ] **Step 3: Write `src/prod_readiness/checks/__init__.py`**

```python
from __future__ import annotations

from prod_readiness.checks import resources_requests_and_limits_set  # noqa: F401

__all__ = ["resources_requests_and_limits_set"]
```

- [ ] **Step 4: Write `src/prod_readiness/checks/resources_requests_and_limits_set.py`**

```python
from __future__ import annotations

from typing import Any

from prod_readiness.core.check import Check
from prod_readiness.core.context import GuardedContext
from prod_readiness.core.models import Capability, Finding, Severity, Status, Target
from prod_readiness.core.registry import register_check

_REMEDIATION_TEMPLATE = (
    "spec:\n"
    "  template:\n"
    "    spec:\n"
    "      containers:\n"
    "        - name: <container>\n"
    "          resources:\n"
    "            requests:\n"
    "              cpu: 100m\n"
    "              memory: 128Mi\n"
    "            limits:\n"
    "              memory: 256Mi\n"
)


@register_check
class ResourcesRequestsAndLimitsSet(Check):
    id = "resources.requests-and-limits-set"
    category = "resources"
    severity = Severity.BLOCKER
    needs = frozenset({Capability.K8S})
    description = (
        "Every container has CPU and memory requests; memory limit is set."
    )

    async def run(self, ctx: GuardedContext, target: Target) -> Finding:  # type: ignore[override]
        wl = await ctx.k8s.read_workload(target)
        containers = wl.spec.template.spec.containers or []
        per_container: list[dict[str, Any]] = []
        all_ok = True
        for c in containers:
            missing: list[str] = []
            requests = getattr(c.resources, "requests", None) or {}
            limits = getattr(c.resources, "limits", None) or {}
            if "cpu" not in requests:
                missing.append("requests.cpu")
            if "memory" not in requests:
                missing.append("requests.memory")
            if "memory" not in limits:
                missing.append("limits.memory")
            if missing:
                all_ok = False
            per_container.append({"name": c.name, "missing": missing})
        if all_ok:
            return Finding(
                check_id=self.id,
                target=target,
                severity=self.severity,
                status=Status.PASS,
                message="All containers declare CPU+memory requests and memory limit.",
                evidence={"containers": per_container},
            )
        reasons: list[str] = []
        if any("requests.cpu" in c["missing"] for c in per_container):
            reasons.append("missing CPU request")
        if any("requests.memory" in c["missing"] for c in per_container):
            reasons.append("missing memory request")
        if any("limits.memory" in c["missing"] for c in per_container):
            reasons.append("missing memory limit")
        return Finding(
            check_id=self.id,
            target=target,
            severity=self.severity,
            status=Status.FAIL,
            message="Resource gaps: " + ", ".join(reasons) + ".",
            evidence={"containers": per_container},
            remediation=_REMEDIATION_TEMPLATE,
        )
```

- [ ] **Step 5: Run tests**

```bash
uv run pytest tests/unit/test_check_resources_requests_and_limits_set.py -v
uv run mypy src
```

Expected: green.

- [ ] **Step 6: Commit**

```bash
git add -A
git commit -m "feat(checks): resources.requests-and-limits-set (v1 — unit tests)"
```

---

## Task 11: CLI surface (Typer)

**Files:**
- Create: `src/prod_readiness/cli.py`
- Create: `tests/unit/test_cli.py`

- [ ] **Step 1: Write failing test**

```python
# tests/unit/test_cli.py
from __future__ import annotations

import json

from typer.testing import CliRunner

from prod_readiness.cli import app

runner = CliRunner()


def test_list_checks_includes_resources_check():
    result = runner.invoke(app, ["list-checks"])
    assert result.exit_code == 0
    assert "resources.requests-and-limits-set" in result.stdout


def test_list_checks_json_output():
    result = runner.invoke(app, ["list-checks", "--format", "json"])
    assert result.exit_code == 0
    data = json.loads(result.stdout)
    ids = [m["id"] for m in data]
    assert "resources.requests-and-limits-set" in ids


def test_help_mentions_commands():
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    for cmd in ("audit", "audit-workload", "list-checks", "explain", "diff", "serve-mcp"):
        assert cmd in result.stdout
```

- [ ] **Step 2: Run test to see it fails**

```bash
uv run pytest tests/unit/test_cli.py -v
```

Expected: import error.

- [ ] **Step 3: Write `src/prod_readiness/cli.py`**

```python
from __future__ import annotations

import asyncio
import json as json_lib
import sys
from pathlib import Path
from typing import Optional

import typer

from prod_readiness import __version__
from prod_readiness.adapters.k8s import K8sAdapter, K8sConfig
from prod_readiness.adapters.llm import LLMAdapter, LLMConfig
from prod_readiness.adapters.prom import PromAdapter, PromConfig
from prod_readiness.core.context import AuditContext
from prod_readiness.core.models import CheckMeta, Report, Scope, Severity, Status
from prod_readiness.core.orchestrator import Orchestrator, worst_severity
from prod_readiness.core.registry import list_checks
from prod_readiness.reports.html import render_html
from prod_readiness.reports.json import render_json
from prod_readiness.reports.junit import render_junit
from prod_readiness.reports.markdown import render_markdown

import prod_readiness.checks  # noqa: F401 — registers checks

app = typer.Typer(add_completion=False, no_args_is_help=True, help="Kubernetes prod-readiness auditor.")


def _render(report: Report, fmt: str) -> str:
    return {
        "json": render_json,
        "md": render_markdown,
        "markdown": render_markdown,
        "junit": render_junit,
        "html": render_html,
    }[fmt](report)


def _exit_code(report: Report, fail_on: str) -> int:
    worst = worst_severity(report.findings)
    if worst is None:
        return 0
    thresholds = {"blocker": {Severity.BLOCKER}, "warning": {Severity.BLOCKER, Severity.WARNING}}
    if worst in thresholds.get(fail_on, {Severity.BLOCKER}):
        return 2 if worst == Severity.BLOCKER else 1
    return 0


async def _build_ctx(
    context: str | None,
    prom_url: str | None,
    llm_provider: str | None,
    llm_base_url: str | None,
    llm_api_key: str | None,
    offline: bool,
) -> AuditContext:
    k8s = K8sAdapter(K8sConfig(context=context))
    await k8s.connect()
    prom = PromAdapter(PromConfig(base_url=prom_url))
    llm = LLMAdapter(
        LLMConfig.from_sources(
            cli_provider=llm_provider,
            cli_base_url=llm_base_url,
            cli_api_key=llm_api_key,
            cli_offline=offline or None,
        )
    )
    return AuditContext(k8s=k8s, prom=prom, llm=llm)


@app.command()
def audit(
    context: Optional[str] = typer.Option(None, "--context"),
    namespace: list[str] = typer.Option([], "--namespace", "-n"),
    check: list[str] = typer.Option([], "--check"),
    label_selector: Optional[str] = typer.Option(None, "--label-selector", "-l"),
    prom_url: Optional[str] = typer.Option(None, "--prom-url"),
    llm_provider: Optional[str] = typer.Option(None, "--llm-provider"),
    llm_base_url: Optional[str] = typer.Option(None, "--llm-base-url"),
    llm_api_key: Optional[str] = typer.Option(None, "--llm-api-key"),
    offline: bool = typer.Option(False, "--no-llm", help="Disable LLM calls."),
    fmt: str = typer.Option("md", "--format", "-f"),
    fail_on: str = typer.Option("blocker", "--fail-on"),
    output: Optional[Path] = typer.Option(None, "--output", "-o"),
) -> None:
    """Run a full audit on the current (or --context) cluster."""

    async def _go() -> int:
        ctx = await _build_ctx(
            context, prom_url, llm_provider, llm_base_url, llm_api_key, offline
        )
        try:
            orch = Orchestrator(ctx=ctx, version=__version__)
            scope = Scope(
                namespaces=namespace or None,
                label_selector=label_selector,
                checks=check or None,
            )
            report = await orch.audit(scope)
            rendered = _render(report, fmt)
            if output:
                output.write_text(rendered)
            else:
                sys.stdout.write(rendered)
            return _exit_code(report, fail_on)
        finally:
            await ctx.k8s.close()
            await ctx.prom.close()

    raise typer.Exit(asyncio.run(_go()))


@app.command("audit-workload")
def audit_workload(
    target: str = typer.Argument(..., help="namespace/kind/name"),
    context: Optional[str] = typer.Option(None, "--context"),
    fmt: str = typer.Option("md", "--format", "-f"),
) -> None:
    ns, kind, name = target.split("/")

    async def _go() -> int:
        ctx = await _build_ctx(context, None, None, None, None, False)
        try:
            orch = Orchestrator(ctx=ctx, version=__version__)
            report = await orch.audit(
                Scope(namespaces=[ns], label_selector=f"_match=__{kind}/{name}")
            )
            # Simpler: filter after listing
            report.findings = [
                f for f in report.findings
                if f.target.namespace == ns and f.target.kind == kind and f.target.name == name
            ]
            sys.stdout.write(_render(report, fmt))
            return _exit_code(report, "blocker")
        finally:
            await ctx.k8s.close()
            await ctx.prom.close()

    raise typer.Exit(asyncio.run(_go()))


@app.command("list-checks")
def list_checks_cmd(
    category: Optional[str] = typer.Option(None, "--category"),
    fmt: str = typer.Option("text", "--format"),
) -> None:
    metas = [
        CheckMeta(
            id=c.id,
            category=c.category,
            severity=c.severity,
            needs=c.needs,
            description=c.description,
        )
        for c in list_checks()
        if category is None or c.category == category
    ]
    if fmt == "json":
        typer.echo(json_lib.dumps([m.model_dump() for m in metas], indent=2))
        return
    for m in metas:
        typer.echo(f"{m.id}\t[{m.category}]\t{m.severity.value}\t{m.description}")


@app.command()
def explain(finding_id: str) -> None:  # Plan 2 will wire this to the orchestrator+LLM.
    typer.echo(f"TODO: explain {finding_id} — implemented in Plan 2.", err=True)
    raise typer.Exit(3)


@app.command()
def diff(a: Path, b: Path) -> None:  # Plan 2.
    typer.echo("TODO: diff — implemented in Plan 2.", err=True)
    raise typer.Exit(3)


@app.command("serve-mcp")
def serve_mcp() -> None:
    """Run the MCP stdio server."""
    from prod_readiness.mcp_server import run_stdio  # lazy import so CLI stays fast

    run_stdio()
```

> Note on `audit_workload`: the "simpler filter after listing" is a deliberate
> temporary shortcut in Plan 1 because we only have one check. Plan 2 adds a
> focused `orchestrator.audit_one()` path.

- [ ] **Step 4: Run tests**

```bash
uv run pytest tests/unit/test_cli.py -v
```

Expected: green. (`serve-mcp` import will fail at runtime — that's fine, tests don't invoke it.)

- [ ] **Step 5: Commit**

```bash
git add -A
git commit -m "feat(cli): Typer CLI with audit, list-checks, and stubs for plan 2"
```

---

## Task 12: MCP server (FastMCP)

**Files:**
- Create: `src/prod_readiness/mcp_server.py`
- Create: `tests/unit/test_mcp_server_smoke.py`

- [ ] **Step 1: Write failing test**

```python
# tests/unit/test_mcp_server_smoke.py
from __future__ import annotations

from prod_readiness.mcp_server import build_server


def test_server_exposes_expected_tools():
    server = build_server()
    tool_names = {t.name for t in server.list_tools()}
    assert {"audit_cluster", "audit_workload", "list_checks"}.issubset(tool_names)
```

> This test only asserts the tools are registered; the MCP stdio contract test
> (Task 14) exercises the full protocol.

- [ ] **Step 2: Run test to see it fails**

```bash
uv run pytest tests/unit/test_mcp_server_smoke.py -v
```

Expected: import error.

- [ ] **Step 3: Write `src/prod_readiness/mcp_server.py`**

```python
from __future__ import annotations

from fastmcp import FastMCP

from prod_readiness import __version__
from prod_readiness.adapters.k8s import K8sAdapter, K8sConfig
from prod_readiness.adapters.llm import LLMAdapter, LLMConfig
from prod_readiness.adapters.prom import PromAdapter, PromConfig
from prod_readiness.core.context import AuditContext
from prod_readiness.core.models import CheckMeta, Report, Scope
from prod_readiness.core.orchestrator import Orchestrator
from prod_readiness.core.registry import list_checks

import prod_readiness.checks  # noqa: F401


def build_server() -> FastMCP:
    server = FastMCP("mcp-prod-readiness")

    @server.tool()
    async def audit_cluster(scope: Scope | None = None) -> Report:
        """Audit the current cluster against all registered checks."""
        s = scope or Scope()
        k8s = K8sAdapter(K8sConfig(context=s.contexts[0] if s.contexts else None))
        await k8s.connect()
        ctx = AuditContext(
            k8s=k8s,
            prom=PromAdapter(PromConfig()),
            llm=LLMAdapter(LLMConfig.from_sources()),
        )
        try:
            return await Orchestrator(ctx=ctx, version=__version__).audit(s)
        finally:
            await k8s.close()
            await ctx.prom.close()

    @server.tool()
    async def audit_workload(namespace: str, kind: str, name: str) -> Report:
        """Audit a single workload."""
        k8s = K8sAdapter(K8sConfig())
        await k8s.connect()
        ctx = AuditContext(
            k8s=k8s,
            prom=PromAdapter(PromConfig()),
            llm=LLMAdapter(LLMConfig.from_sources()),
        )
        try:
            report = await Orchestrator(ctx=ctx, version=__version__).audit(
                Scope(namespaces=[namespace])
            )
            report.findings = [
                f
                for f in report.findings
                if f.target.namespace == namespace
                and f.target.kind == kind
                and f.target.name == name
            ]
            return report
        finally:
            await k8s.close()
            await ctx.prom.close()

    @server.tool()
    async def list_checks_tool() -> list[CheckMeta]:
        """List all registered checks."""
        return [
            CheckMeta(
                id=c.id,
                category=c.category,
                severity=c.severity,
                needs=c.needs,
                description=c.description,
            )
            for c in list_checks()
        ]

    # Expose it as `list_checks` in the MCP protocol (not the Python fn name):
    list_checks_tool.__name__ = "list_checks"
    return server


def run_stdio() -> None:
    build_server().run()
```

- [ ] **Step 4: Run tests**

```bash
uv run pytest tests/unit/test_mcp_server_smoke.py -v
```

Expected: green.

- [ ] **Step 5: Commit**

```bash
git add -A
git commit -m "feat(mcp): FastMCP server with audit_cluster, audit_workload, list_checks"
```

---

## Task 13: Golden test harness + 3 scenarios for the first check

**Files:**
- Create: `tests/golden/conftest.py`
- Create: `tests/golden/_runner.py`
- Create: `tests/golden/resources.requests-and-limits-set/pass/input.yaml`
- Create: `tests/golden/resources.requests-and-limits-set/pass/expected.json`
- Create: `tests/golden/resources.requests-and-limits-set/fail-missing-cpu/input.yaml`
- Create: `tests/golden/resources.requests-and-limits-set/fail-missing-cpu/expected.json`
- Create: `tests/golden/resources.requests-and-limits-set/fail-no-limits/input.yaml`
- Create: `tests/golden/resources.requests-and-limits-set/fail-no-limits/expected.json`
- Create: `tests/golden/test_golden.py`

- [ ] **Step 1: Write `tests/golden/_runner.py`** — ephemeral kind helper

```python
from __future__ import annotations

import json
import subprocess
import time
import uuid
from dataclasses import dataclass
from pathlib import Path

from prod_readiness.adapters.k8s import K8sAdapter, K8sConfig
from prod_readiness.adapters.llm import LLMAdapter, LLMConfig
from prod_readiness.adapters.prom import PromAdapter, PromConfig
from prod_readiness.core.context import AuditContext
from prod_readiness.core.models import Scope
from prod_readiness.core.orchestrator import Orchestrator
from prod_readiness.core.registry import get_check


@dataclass
class KindCluster:
    name: str
    kubeconfig: Path

    def delete(self) -> None:
        subprocess.run(["kind", "delete", "cluster", "--name", self.name], check=False)


def create_kind() -> KindCluster:
    name = f"pr-golden-{uuid.uuid4().hex[:6]}"
    kubeconfig = Path(f"/tmp/kubeconfig-{name}")
    subprocess.run(
        ["kind", "create", "cluster", "--name", name, "--kubeconfig", str(kubeconfig)],
        check=True,
    )
    return KindCluster(name=name, kubeconfig=kubeconfig)


def apply_manifests(cluster: KindCluster, manifest: Path) -> None:
    subprocess.run(
        ["kubectl", "--kubeconfig", str(cluster.kubeconfig), "apply", "-f", str(manifest)],
        check=True,
    )
    # Deployments may take a beat to appear; simple retry loop.
    for _ in range(20):
        r = subprocess.run(
            ["kubectl", "--kubeconfig", str(cluster.kubeconfig), "get", "deploy", "-A"],
            capture_output=True,
            text=True,
            check=True,
        )
        if "golden" in r.stdout or "pr-" in r.stdout:
            return
        time.sleep(0.25)


async def run_check_against_cluster(
    cluster: KindCluster, check_id: str
) -> list[dict]:
    cfg = K8sConfig()
    # The python-kubernetes-asyncio loader reads KUBECONFIG env var if set.
    import os

    os.environ["KUBECONFIG"] = str(cluster.kubeconfig)
    k8s = K8sAdapter(cfg)
    await k8s.connect()
    ctx = AuditContext(
        k8s=k8s,
        prom=PromAdapter(PromConfig()),
        llm=LLMAdapter(LLMConfig(offline=True)),
    )
    try:
        report = await Orchestrator(ctx=ctx, version="golden").audit(
            Scope(checks=[check_id])
        )
        return [f.model_dump(mode="json") for f in report.findings]
    finally:
        await k8s.close()
        await ctx.prom.close()


def normalise(findings: list[dict]) -> list[dict]:
    for f in findings:
        f["duration_ms"] = 0
        f["target"]["uid"] = "<uid>"
    return sorted(findings, key=lambda f: (f["target"]["namespace"], f["target"]["name"]))
```

- [ ] **Step 2: Write `tests/golden/conftest.py`**

```python
from __future__ import annotations

import pytest

from tests.golden._runner import KindCluster, create_kind


@pytest.fixture(scope="session")
def kind_cluster() -> KindCluster:
    cluster = create_kind()
    yield cluster
    cluster.delete()
```

- [ ] **Step 3: Write scenario manifests**

`tests/golden/resources.requests-and-limits-set/pass/input.yaml`:

```yaml
apiVersion: v1
kind: Namespace
metadata:
  name: golden-pass
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: pr-happy
  namespace: golden-pass
spec:
  replicas: 1
  selector:
    matchLabels: { app: pr-happy }
  template:
    metadata:
      labels: { app: pr-happy }
    spec:
      containers:
        - name: api
          image: registry.k8s.io/pause:3.9
          resources:
            requests:
              cpu: 100m
              memory: 128Mi
            limits:
              memory: 256Mi
```

`tests/golden/resources.requests-and-limits-set/pass/expected.json`:

```json
[
  {
    "check_id": "resources.requests-and-limits-set",
    "target": {"kind": "Deployment", "namespace": "golden-pass", "name": "pr-happy", "uid": "<uid>"},
    "severity": "blocker",
    "status": "pass",
    "message": "All containers declare CPU+memory requests and memory limit.",
    "evidence": {"containers": [{"name": "api", "missing": []}]},
    "remediation": null,
    "ai_reasoning": null,
    "duration_ms": 0
  }
]
```

`tests/golden/resources.requests-and-limits-set/fail-missing-cpu/input.yaml`:

```yaml
apiVersion: v1
kind: Namespace
metadata:
  name: golden-fail-cpu
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: pr-no-cpu
  namespace: golden-fail-cpu
spec:
  replicas: 1
  selector: { matchLabels: { app: pr-no-cpu } }
  template:
    metadata: { labels: { app: pr-no-cpu } }
    spec:
      containers:
        - name: api
          image: registry.k8s.io/pause:3.9
          resources:
            requests:
              memory: 128Mi
            limits:
              memory: 256Mi
```

`tests/golden/resources.requests-and-limits-set/fail-missing-cpu/expected.json`:

```json
[
  {
    "check_id": "resources.requests-and-limits-set",
    "target": {"kind": "Deployment", "namespace": "golden-fail-cpu", "name": "pr-no-cpu", "uid": "<uid>"},
    "severity": "blocker",
    "status": "fail",
    "message": "Resource gaps: missing CPU request.",
    "evidence": {"containers": [{"name": "api", "missing": ["requests.cpu"]}]},
    "remediation": "spec:\n  template:\n    spec:\n      containers:\n        - name: <container>\n          resources:\n            requests:\n              cpu: 100m\n              memory: 128Mi\n            limits:\n              memory: 256Mi\n",
    "ai_reasoning": null,
    "duration_ms": 0
  }
]
```

`tests/golden/resources.requests-and-limits-set/fail-no-limits/input.yaml`:

```yaml
apiVersion: v1
kind: Namespace
metadata:
  name: golden-fail-nolim
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: pr-no-limits
  namespace: golden-fail-nolim
spec:
  replicas: 1
  selector: { matchLabels: { app: pr-no-limits } }
  template:
    metadata: { labels: { app: pr-no-limits } }
    spec:
      containers:
        - name: api
          image: registry.k8s.io/pause:3.9
          resources:
            requests:
              cpu: 100m
              memory: 128Mi
```

`tests/golden/resources.requests-and-limits-set/fail-no-limits/expected.json`:

```json
[
  {
    "check_id": "resources.requests-and-limits-set",
    "target": {"kind": "Deployment", "namespace": "golden-fail-nolim", "name": "pr-no-limits", "uid": "<uid>"},
    "severity": "blocker",
    "status": "fail",
    "message": "Resource gaps: missing memory limit.",
    "evidence": {"containers": [{"name": "api", "missing": ["limits.memory"]}]},
    "remediation": "spec:\n  template:\n    spec:\n      containers:\n        - name: <container>\n          resources:\n            requests:\n              cpu: 100m\n              memory: 128Mi\n            limits:\n              memory: 256Mi\n",
    "ai_reasoning": null,
    "duration_ms": 0
  }
]
```

- [ ] **Step 4: Write `tests/golden/test_golden.py`**

```python
from __future__ import annotations

import json
from pathlib import Path

import pytest

from tests.golden._runner import (
    KindCluster,
    apply_manifests,
    normalise,
    run_check_against_cluster,
)

SCENARIO_ROOT = Path("tests/golden/resources.requests-and-limits-set")
SCENARIOS = ["pass", "fail-missing-cpu", "fail-no-limits"]


@pytest.mark.golden
@pytest.mark.asyncio
@pytest.mark.parametrize("scenario", SCENARIOS)
async def test_golden_scenario(kind_cluster: KindCluster, scenario: str) -> None:
    scenario_dir = SCENARIO_ROOT / scenario
    apply_manifests(kind_cluster, scenario_dir / "input.yaml")

    actual = await run_check_against_cluster(
        kind_cluster, "resources.requests-and-limits-set"
    )
    actual = normalise([f for f in actual if f["target"]["namespace"].startswith("golden-")])
    expected = json.loads((scenario_dir / "expected.json").read_text())

    # Filter actual to the namespace owned by this scenario.
    ns = {"pass": "golden-pass", "fail-missing-cpu": "golden-fail-cpu", "fail-no-limits": "golden-fail-nolim"}[scenario]
    actual = [f for f in actual if f["target"]["namespace"] == ns]

    assert actual == expected
```

- [ ] **Step 5: Run the golden suite manually**

Prereqs: `kind`, `kubectl`, and Docker must be on PATH.

```bash
uv run pytest -m golden -v
```

Expected: all three scenarios pass. If a scenario fails, **do not change the
expected.json** — fix the code or the manifest, then re-run.

- [ ] **Step 6: Commit**

```bash
git add -A
git commit -m "test(golden): kind-based harness + 3 scenarios for resources check"
```

---

## Task 14: Integration test + MCP contract test + kind CI workflow

**Files:**
- Create: `tests/integration/test_full_audit.py`
- Create: `tests/mcp/test_stdio_contract.py`
- Create: `.github/workflows/integration.yml`

- [ ] **Step 1: Write integration test**

```python
# tests/integration/test_full_audit.py
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pytest

from tests.golden._runner import KindCluster, apply_manifests


@pytest.mark.integration
def test_cli_audit_against_kind(kind_cluster: KindCluster, tmp_path: Path) -> None:
    manifest = Path("tests/golden/resources.requests-and-limits-set/pass/input.yaml")
    apply_manifests(kind_cluster, manifest)

    env = {"KUBECONFIG": str(kind_cluster.kubeconfig), "PATH": __import__("os").environ["PATH"]}
    out = tmp_path / "report.json"
    result = subprocess.run(
        [
            sys.executable,
            "-m",
            "prod_readiness.cli",
            "audit",
            "--namespace",
            "golden-pass",
            "--format",
            "json",
            "--output",
            str(out),
        ],
        env=env,
        check=False,
    )
    assert result.returncode == 0
    data = json.loads(out.read_text())
    assert any(f["check_id"] == "resources.requests-and-limits-set" for f in data["findings"])
```

Note: `prod_readiness.cli` must be runnable as a module. Add to `src/prod_readiness/cli.py` the lines:

```python
if __name__ == "__main__":
    app()
```

- [ ] **Step 2: Write MCP contract test**

```python
# tests/mcp/test_stdio_contract.py
from __future__ import annotations

import asyncio
import json
import os
import sys

import pytest

from tests.golden._runner import KindCluster, apply_manifests


@pytest.mark.mcp_contract
@pytest.mark.asyncio
async def test_mcp_list_checks_over_stdio(kind_cluster: KindCluster) -> None:
    from pathlib import Path

    apply_manifests(
        kind_cluster,
        Path("tests/golden/resources.requests-and-limits-set/pass/input.yaml"),
    )

    proc = await asyncio.create_subprocess_exec(
        sys.executable,
        "-m",
        "prod_readiness.cli",
        "serve-mcp",
        stdin=asyncio.subprocess.PIPE,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        env={**os.environ, "KUBECONFIG": str(kind_cluster.kubeconfig)},
    )
    try:
        init = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "initialize",
            "params": {"protocolVersion": "2024-11-05", "capabilities": {}, "clientInfo": {"name": "t", "version": "0"}},
        }
        proc.stdin.write((json.dumps(init) + "\n").encode())
        await proc.stdin.drain()
        list_req = {"jsonrpc": "2.0", "id": 2, "method": "tools/list"}
        proc.stdin.write((json.dumps(list_req) + "\n").encode())
        await proc.stdin.drain()
        # Read two responses
        buf = []
        while len(buf) < 2:
            line = await proc.stdout.readline()
            if not line:
                break
            try:
                buf.append(json.loads(line))
            except json.JSONDecodeError:
                continue
        tool_names = {t["name"] for t in buf[-1]["result"]["tools"]}
        assert {"audit_cluster", "audit_workload", "list_checks"}.issubset(tool_names)
    finally:
        proc.terminate()
        await proc.wait()
```

- [ ] **Step 3: Write `.github/workflows/integration.yml`**

```yaml
name: integration
on:
  push:
    branches: [main]
  pull_request:
  schedule:
    - cron: "17 4 * * *"
permissions:
  contents: read
jobs:
  golden-and-integration:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: astral-sh/setup-uv@v3
      - run: uv python install 3.11
      - uses: helm/kind-action@v1
        with:
          version: v0.23.0
          cluster_name: pr-ci
      - run: uv venv
      - run: uv pip install -e ".[dev]"
      - name: Run golden tests (20x)
        run: |
          for i in $(seq 1 20); do
            echo "=== golden run $i ==="
            uv run pytest -m golden -q || exit 1
          done
      - run: uv run pytest -m integration -v
      - run: uv run pytest -m mcp_contract -v
```

- [ ] **Step 4: Run all marks locally once**

```bash
uv run pytest -m golden -v
uv run pytest -m integration -v
uv run pytest -m mcp_contract -v
```

Expected: all green.

- [ ] **Step 5: Commit**

```bash
git add -A
git commit -m "test: integration + MCP contract tests + kind CI workflow"
```

---

## Task 15: OpenTelemetry tracing + wire into orchestrator

**Files:**
- Modify: `src/prod_readiness/core/orchestrator.py` — wrap each `_run_one` in a span.
- Create: `src/prod_readiness/core/tracing.py`
- Create: `tests/unit/test_tracing.py`

- [ ] **Step 1: Write failing test**

```python
# tests/unit/test_tracing.py
from __future__ import annotations

from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import SimpleSpanProcessor
from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter

from prod_readiness.core.tracing import tracer


def test_tracer_emits_spans_when_provider_configured():
    provider = TracerProvider()
    exporter = InMemorySpanExporter()
    provider.add_span_processor(SimpleSpanProcessor(exporter))
    trace.set_tracer_provider(provider)

    with tracer().start_as_current_span("t"):
        pass

    assert len(exporter.get_finished_spans()) == 1
```

- [ ] **Step 2: Run test to see it fails**

```bash
uv run pytest tests/unit/test_tracing.py -v
```

Expected: import error.

- [ ] **Step 3: Write `src/prod_readiness/core/tracing.py`**

```python
from __future__ import annotations

from opentelemetry import trace
from opentelemetry.trace import Tracer

_NAME = "prod-readiness"


def tracer() -> Tracer:
    return trace.get_tracer(_NAME)
```

- [ ] **Step 4: Modify `src/prod_readiness/core/orchestrator.py`**

Add the import at the top of the file:

```python
from prod_readiness.core.tracing import tracer
```

Wrap the check body inside `_run_one`. Replace the current body of `_run_one`:

```python
        async def _run_one(cls: type[Check], target: Target) -> Finding:
            async with sem:
                instance = cls()
                start = time.perf_counter()
                guarded = self.ctx.guard(needs=instance.needs)
                with tracer().start_as_current_span("check.run") as span:
                    span.set_attribute("check.id", cls.id)
                    span.set_attribute("target.kind", target.kind)
                    span.set_attribute("target.namespace", target.namespace)
                    span.set_attribute("target.name", target.name)
                    try:
                        coro = instance.run(guarded, target)  # type: ignore[arg-type]
                        f = await asyncio.wait_for(
                            coro, timeout=self.per_check_timeout_s
                        )
                        duration_ms = int((time.perf_counter() - start) * 1000)
                        span.set_attribute("duration_ms", duration_ms)
                        span.set_attribute("status", f.status.value)
                        return f.model_copy(update={"duration_ms": duration_ms})
                    except asyncio.TimeoutError:
                        span.set_attribute("status", "error")
                        return Finding(
                            check_id=cls.id,
                            target=target,
                            severity=cls.severity,
                            status=Status.ERROR,
                            message=f"timeout after {self.per_check_timeout_s}s",
                            duration_ms=int((time.perf_counter() - start) * 1000),
                        )
                    except Exception as exc:
                        span.set_attribute("status", "error")
                        span.record_exception(exc)
                        return Finding(
                            check_id=cls.id,
                            target=target,
                            severity=cls.severity,
                            status=Status.ERROR,
                            message=f"{type(exc).__name__}: {exc}",
                            duration_ms=int((time.perf_counter() - start) * 1000),
                        )
```

- [ ] **Step 5: Run full test suite**

```bash
uv run pytest -m "not integration and not golden and not mcp_contract" -v
uv run mypy src
```

Expected: green.

- [ ] **Step 6: Commit**

```bash
git add -A
git commit -m "feat(core): OTel spans per check run with status+target attributes"
```

---

## Task 16: Dockerfile + CLI entry + version check

**Files:**
- Create: `Dockerfile`
- Create: `.dockerignore`
- Create: `tests/unit/test_version.py`

- [ ] **Step 1: Write failing test**

```python
# tests/unit/test_version.py
from __future__ import annotations

import subprocess
import sys


def test_module_invocation_prints_help_with_exit_0_when_help_passed():
    result = subprocess.run(
        [sys.executable, "-m", "prod_readiness.cli", "--help"],
        capture_output=True,
        text=True,
        check=False,
    )
    assert result.returncode == 0
    assert "audit" in result.stdout
```

- [ ] **Step 2: Run to verify current state**

```bash
uv run pytest tests/unit/test_version.py -v
```

Expected: green only if Task 14's `if __name__ == "__main__"` guard was added.
If red, add to the bottom of `src/prod_readiness/cli.py`:

```python
if __name__ == "__main__":
    app()
```

- [ ] **Step 3: Write `.dockerignore`**

```
.git
.venv
.pytest_cache
.ruff_cache
.mypy_cache
dist
build
tests
docs
.github
```

- [ ] **Step 4: Write `Dockerfile`**

```dockerfile
FROM python:3.11-slim AS builder
ENV PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1 PIP_NO_CACHE_DIR=1
WORKDIR /app
COPY pyproject.toml README.md ./
COPY src ./src
RUN pip install --prefix=/install "."

FROM python:3.11-slim
ENV PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1
RUN apt-get update && apt-get install -y --no-install-recommends \
      curl ca-certificates gnupg \
    && curl -LO "https://dl.k8s.io/release/v1.30.1/bin/linux/amd64/kubectl" \
    && install -m 0755 kubectl /usr/local/bin/kubectl \
    && rm -rf /var/lib/apt/lists/* kubectl
COPY --from=builder /install /usr/local
RUN useradd -m -u 10001 pr && mkdir -p /home/pr/.kube && chown -R pr /home/pr
USER 10001
ENTRYPOINT ["prod-readiness"]
CMD ["--help"]
```

> Cloud-CLI bundling (`aws-cli`, `gcloud`, `kubelogin`) is deferred to Plan 2's
> release hardening — Plan 1 ships a minimal image.

- [ ] **Step 5: Verify image builds locally**

```bash
docker build -t mcp-prod-readiness:dev .
docker run --rm mcp-prod-readiness:dev list-checks
```

Expected: prints the one registered check.

- [ ] **Step 6: Commit**

```bash
git add -A
git commit -m "chore: Dockerfile and module-run entry"
```

---

## Task 17: Release v0.1.0 (PyPI + GHCR)

**Files:**
- Create: `.github/workflows/release.yml`
- Create: `CHANGELOG.md`
- Modify: `README.md` — add install + quickstart sections.

- [ ] **Step 1: Write `CHANGELOG.md`**

```markdown
# Changelog

All notable changes to this project will be documented here.
Format: [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).

## [0.1.0] — 2026-04-20

### Added
- MCP server and CLI surfaces with 1:1 parity.
- Core engine: capability-routed orchestrator, plugin-registered checks, async K8s+Prom+LLM adapters.
- LLM-agnostic via litellm + instructor; offline fallback; Ollama auto-discovery.
- First check: `resources.requests-and-limits-set`.
- Golden-test harness on ephemeral kind; 3 scenarios.
- OTel spans per check run.
- Multi-stage Dockerfile.
```

- [ ] **Step 2: Update `README.md`**

```markdown
# mcp-prod-readiness

Kubernetes production-readiness auditor — MCP server + CLI.

**Status:** alpha. Today ships with **1 check**. The v1.0.0 milestone adds 9 more.

## Install

```bash
# Ephemeral:
uvx mcp-prod-readiness list-checks

# Persistent:
pip install mcp-prod-readiness
```

## Quickstart — CLI

```bash
prod-readiness audit --namespace default --format md
```

## Quickstart — Claude Code / Desktop

```json
{
  "mcpServers": {
    "prod-readiness": {
      "command": "uvx",
      "args": ["mcp-prod-readiness", "serve-mcp"]
    }
  }
}
```

## LLM configuration

Any provider, any base URL, or fully offline:

```bash
# Anthropic
export PROD_READINESS_LLM_PROVIDER=anthropic/claude-sonnet-4-6
export PROD_READINESS_LLM_API_KEY=sk-ant-...

# Local Ollama (auto-detected if unconfigured)
export PROD_READINESS_LLM_PROVIDER=ollama/qwen2.5:7b
export PROD_READINESS_LLM_BASE_URL=http://localhost:11434

# Offline
export PROD_READINESS_OFFLINE=1
```

## Design and plans

- Spec: [`docs/superpowers/specs/2026-04-20-mcp-prod-readiness-design.md`](docs/superpowers/specs/2026-04-20-mcp-prod-readiness-design.md)
- Plan 1 (this release): [`docs/superpowers/plans/2026-04-20-mcp-prod-readiness-plan-1-walking-skeleton.md`](docs/superpowers/plans/2026-04-20-mcp-prod-readiness-plan-1-walking-skeleton.md)
```

- [ ] **Step 3: Write `.github/workflows/release.yml`**

```yaml
name: release
on:
  push:
    tags: ["v*"]
permissions:
  contents: write
  id-token: write
  packages: write
jobs:
  pypi:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: astral-sh/setup-uv@v3
      - run: uv python install 3.11
      - run: uv venv
      - run: uv pip install build
      - run: uv run python -m build
      - uses: pypa/gh-action-pypi-publish@release/v1
        with:
          packages-dir: dist
  image:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: docker/setup-qemu-action@v3
      - uses: docker/setup-buildx-action@v3
      - uses: docker/login-action@v3
        with:
          registry: ghcr.io
          username: ${{ github.actor }}
          password: ${{ secrets.GITHUB_TOKEN }}
      - uses: docker/build-push-action@v6
        with:
          context: .
          platforms: linux/amd64,linux/arm64
          push: true
          tags: |
            ghcr.io/${{ github.repository_owner }}/mcp-prod-readiness:${{ github.ref_name }}
            ghcr.io/${{ github.repository_owner }}/mcp-prod-readiness:latest
```

- [ ] **Step 4: Tag v0.1.0**

(Only after the maintainer has configured the `PYPI_API_TOKEN` trusted publisher
and pushed `main` to GitHub. If either is not set up, skip this step and return
to it post-setup.)

```bash
git tag -a v0.1.0 -m "v0.1.0: walking skeleton + first check"
git push origin v0.1.0  # triggers release.yml
```

- [ ] **Step 5: Commit (docs and workflow)**

```bash
git add -A
git commit -m "chore(release): v0.1.0 release workflow, README, CHANGELOG"
```

---

## Phase 1 exit checklist (for this plan only)

Before considering Plan 1 done and moving to Plan 2:

- [ ] All unit tests green in CI.
- [ ] Golden suite green 20× consecutively in CI (see `integration.yml`).
- [ ] Integration and MCP-contract tests green.
- [ ] `uvx mcp-prod-readiness list-checks` works on a fresh machine.
- [ ] `prod-readiness audit` against a kind cluster produces a Markdown report
      containing the `resources.requests-and-limits-set` finding.
- [ ] Claude Desktop config snippet connects; `audit_cluster` returns a valid
      `Report`.
- [ ] `CHANGELOG.md` and `README.md` match the release.
- [ ] `v0.1.0` published to PyPI and GHCR.

## Hand-off to Plan 2

Plan 2 starts with the foundation stable. It adds checks 2–10, the cluster
matrix (EKS+GKE+AKS), Helm chart, GitHub Action, the `explain` and `diff`
commands, and the `v1.0.0` release.

---

## Self-review (inline, before handing off)

**Spec coverage check:**

| Spec section | Covered by |
|---|---|
| §3 Technical Stack | Task 1 `pyproject.toml` |
| §4.1 Repo layout | Tasks 1–9 |
| §4.2 Request flow | Task 8 (orchestrator) + Task 11 (CLI) + Task 12 (MCP) |
| §4.3 Hybrid engine / capability-gated | Task 7 (GuardedContext) + Task 8 |
| §4.4 Caching | Task 6 (Prom cache); K8s list-cache deferred — see "Open gap" below |
| §5 Data model | Task 2 |
| §6 MVP-10 checks | First check in Task 10; remaining 9 in Plan 2 |
| §7 Surfaces (MCP + CLI + parity) | Tasks 11, 12; parity smoke in Task 14 |
| §8 LLM agnosticism | Task 4 |
| §9 Packaging | Task 16 (image), Task 17 (PyPI+GHCR). Helm/GH-Action deferred to Plan 2 (per spec §9 Phase 1.5). |
| §10 Testing pyramid | Unit (each task), Golden (Task 13), Integration + MCP contract (Task 14). Cluster matrix deferred to Plan 2. |
| §11 OTel | Task 15 |
| §12 Release | Task 17 |
| §16 Success criteria | Phase 1 exit checklist above |

**Open gap surfaced by self-review:** the spec mentions "K8s list op memoisation
per run" (§4.4). The current orchestrator calls `list_targets` once, so a
single-namespace run is already single-query; and each check re-reads its own
workload via `read_workload`. A shared read-cache on `AuditContext` is
low-value with one check. **Deferred to Plan 2** (when checks 2–10 start
sharing K8s reads).

**Placeholder scan:** no "TBD/TODO/implement later" in any step. The `explain`
and `diff` CLI commands emit "implemented in Plan 2" — that is an explicit,
user-visible Plan-2 hand-off, not a placeholder in the code.

**Type consistency:** `Finding`, `Scope`, `Report`, `CheckMeta`, `GuardedContext`,
`Orchestrator.audit`, `K8sAdapter.list_targets` signatures are referenced
consistently across tasks. `register_check` is a decorator applied to a
`type[Check]` and returns the same type.
