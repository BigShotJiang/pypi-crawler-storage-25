# mcp-prod-readiness — Plan 3: Two Resilience Checks

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Ship `mcp-prod-readiness v0.3.0` — adds two resilience checks (`resilience.replicas-ge-2`, `resilience.pdb-exists`) bringing the total to 5 out of the MVP-10. Also teaches `K8sAdapter` how to list PodDisruptionBudgets and match them to workloads by label selector.

**Architecture:** Same engine as Plans 1 and 2. Both new checks are K8s-pure — they read the workload, inspect replica counts / anti-affinity / matching PDBs, and emit Findings. `resilience.pdb-exists` requires a new adapter capability: `K8sAdapter.list_pdbs(namespace)` returns `V1PodDisruptionBudget` objects and the check compares each PDB's `spec.selector` against the workload's pod-template labels.

**Tech Stack:** Same as Plan 2 — Python 3.11 async-first, `kubernetes_asyncio`, `httpx`, `pydantic` v2, `fastmcp` 3.x, `typer`, `litellm`, `instructor`, `pytest` + `pytest-asyncio` + `pytest-httpx`, `kind` for golden tests, `uv` for env.

**Spec:** `docs/superpowers/specs/2026-04-20-mcp-prod-readiness-design.md`
**Prior plans:** Plan 1 (v0.1.0), Plan 2 (v0.2.0) — both under `docs/superpowers/plans/`.

**Working directory:** `04-mcp-prod-readiness/` (git repo, on `main`, at the commit produced by Plan 2 Task 6 — `bb3e1c4` or later).

---

## Conventions reminder (unchanged from Plan 2)

- `from __future__ import annotations` at the top of every file.
- `datetime.UTC` not `timezone.utc`. `StrEnum` not `str, Enum`. Unquoted forward refs.
- `TimeoutError` (builtin) not `asyncio.TimeoutError`.
- One class per file where sensible; files stay ≤ 200 lines.
- No comments except where WHY is non-obvious.
- Each task ends with a commit (Conventional Commits).
- `uv run <cmd>` for everything.
- Strict mypy + ruff `{E,F,I,UP,B,SIM,ASYNC,RUF}` + `B008` ignored (Typer).
- Golden tests discovered from `tests/golden/<check_id>/<scenario>/{input.yaml, expected.json}` via `tests/golden/test_golden.py`.

**Plan-2 exit state:** 43 unit + 8 golden + 1 integration + 1 mcp_contract = 53 tests. 3 registered checks.

---

## Task 1: `K8sAdapter.list_pdbs` + label-selector matcher

The PDB check needs two things the adapter doesn't yet do: (a) list PDBs in a namespace, (b) decide whether a PDB's label selector matches a given workload's pod-template labels. Both live in `K8sAdapter` so the check can stay thin.

**Files:**
- Modify: `src/prod_readiness/adapters/k8s.py` — add `list_pdbs(namespace)` method and `pdb_matches_workload(pdb, workload) -> bool` helper.
- Create: `tests/unit/test_k8s_pdb.py`

- [ ] **Step 1: Write failing test**

```python
# tests/unit/test_k8s_pdb.py
from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock

import pytest

from prod_readiness.adapters.k8s import K8sAdapter, pdb_matches_workload


def _wl(pod_labels: dict[str, str]) -> object:
    return SimpleNamespace(
        spec=SimpleNamespace(
            template=SimpleNamespace(
                metadata=SimpleNamespace(labels=pod_labels),
                spec=SimpleNamespace(containers=[]),
            )
        )
    )


def _pdb(match_labels: dict[str, str] | None, match_expressions: list[dict] | None = None) -> object:
    selector = SimpleNamespace(
        match_labels=match_labels,
        match_expressions=[
            SimpleNamespace(**e) for e in (match_expressions or [])
        ],
    )
    return SimpleNamespace(spec=SimpleNamespace(selector=selector))


def test_matches_when_pdb_match_labels_is_subset_of_pod_labels():
    assert pdb_matches_workload(
        _pdb(match_labels={"app": "api"}),
        _wl({"app": "api", "env": "prod"}),
    )


def test_does_not_match_when_pdb_has_extra_label():
    assert not pdb_matches_workload(
        _pdb(match_labels={"app": "api", "role": "worker"}),
        _wl({"app": "api"}),
    )


def test_does_not_match_when_value_differs():
    assert not pdb_matches_workload(
        _pdb(match_labels={"app": "web"}),
        _wl({"app": "api"}),
    )


def test_matches_when_both_empty():
    assert pdb_matches_workload(
        _pdb(match_labels={}),
        _wl({}),
    )


def test_ignores_match_expressions_in_v1_and_matches_on_labels_only():
    # v1 only matches against match_labels; match_expressions are treated as "unknown"
    # and cause the PDB NOT to match, so the check errs on the side of "no PDB found".
    assert not pdb_matches_workload(
        _pdb(
            match_labels={"app": "api"},
            match_expressions=[{"key": "tier", "operator": "In", "values": ["web"]}],
        ),
        _wl({"app": "api"}),
    )


@pytest.mark.asyncio
async def test_list_pdbs_returns_items_from_policy_api():
    adapter = K8sAdapter.__new__(K8sAdapter)
    adapter._read_cache = {}  # type: ignore[attr-defined]
    fake_policy = MagicMock()
    fake_policy.list_namespaced_pod_disruption_budget = AsyncMock(
        return_value=MagicMock(items=[MagicMock(), MagicMock()])
    )
    adapter._policy = fake_policy  # type: ignore[attr-defined]
    pdbs = await adapter.list_pdbs("default")
    assert len(pdbs) == 2
    fake_policy.list_namespaced_pod_disruption_budget.assert_awaited_once_with(
        namespace="default"
    )
```

- [ ] **Step 2: Run test to see it fails**

```bash
uv run pytest tests/unit/test_k8s_pdb.py -v
```

Expected: ImportError for `pdb_matches_workload`; AttributeError for `list_pdbs`.

- [ ] **Step 3: Modify `src/prod_readiness/adapters/k8s.py`**

Add the `pdb_matches_workload` module-level function near the bottom of the file (after `K8sAdapter`):

```python
def pdb_matches_workload(pdb: Any, workload: Any) -> bool:
    """True iff the PDB's selector matches the workload's pod-template labels.

    Only `matchLabels` is supported in v1. A PDB that uses `matchExpressions`
    is treated as non-matching so the check errs on the side of "no PDB found".
    """
    selector = getattr(pdb.spec, "selector", None)
    if selector is None:
        return False
    if getattr(selector, "match_expressions", None):
        return False
    match_labels = getattr(selector, "match_labels", None) or {}
    pod_labels = (
        getattr(workload.spec.template.metadata, "labels", None) or {}
    )
    return all(pod_labels.get(k) == v for k, v in match_labels.items())
```

Inside `K8sAdapter`, add a `list_pdbs` method (after `list_targets`, before `read_workload`):

```python
    async def list_pdbs(self, namespace: str) -> list[Any]:
        assert self._policy is not None
        resp = await self._policy.list_namespaced_pod_disruption_budget(
            namespace=namespace
        )
        return list(resp.items)
```

- [ ] **Step 4: Run tests**

```bash
uv run pytest tests/unit/test_k8s_pdb.py -v
uv run pytest tests/unit/ -q
uv run mypy src
uv run ruff check .
```

Expected: all green; 49 tests total (43 prior + 6 new).

- [ ] **Step 5: Commit**

```bash
git add -A
git commit -m "feat(adapters): K8sAdapter.list_pdbs + pdb_matches_workload helper"
```

---

## Task 2: Check `resilience.replicas-ge-2`

**What this check asserts:**

- For **Deployments**: `spec.replicas >= 2`.
- For **StatefulSets**: `spec.replicas >= 2` AND **either** the pod template has anti-affinity (`podAntiAffinity`) **or** `topologySpreadConstraints`.

Severity: `BLOCKER`. Category: `resilience`. Needs: `{K8S}`.

Rationale: a single replica means a single point of failure. A StatefulSet with ≥2 replicas can still be co-located on one node and take a correlated outage, so we additionally require spread hints.

**Files:**
- Create: `src/prod_readiness/checks/resilience_replicas_ge_2.py`
- Modify: `src/prod_readiness/checks/__init__.py` — add import + `__all__` entry alphabetically.
- Create: `tests/unit/test_check_replicas_ge_2.py`

- [ ] **Step 1: Write failing test**

```python
# tests/unit/test_check_replicas_ge_2.py
from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock

import pytest

from prod_readiness.checks.resilience_replicas_ge_2 import ResilienceReplicasGe2
from prod_readiness.core.context import AuditContext
from prod_readiness.core.models import Status, Target


def _deploy(replicas: int) -> object:
    return SimpleNamespace(
        spec=SimpleNamespace(
            replicas=replicas,
            template=SimpleNamespace(
                spec=SimpleNamespace(
                    affinity=None, topology_spread_constraints=None, containers=[]
                )
            ),
        )
    )


def _sts(replicas: int, *, anti_affinity: bool = False, topology: bool = False) -> object:
    pod_spec = SimpleNamespace(
        affinity=(
            SimpleNamespace(pod_anti_affinity=SimpleNamespace()) if anti_affinity else None
        ),
        topology_spread_constraints=(
            [SimpleNamespace(topology_key="kubernetes.io/hostname")] if topology else None
        ),
        containers=[],
    )
    return SimpleNamespace(
        spec=SimpleNamespace(replicas=replicas, template=SimpleNamespace(spec=pod_spec))
    )


def _ctx(workload) -> AuditContext:
    k8s = MagicMock()
    k8s.read_workload = AsyncMock(return_value=workload)
    return AuditContext(k8s=k8s, prom=MagicMock(), llm=MagicMock())


def _dep_target() -> Target:
    return Target(kind="Deployment", namespace="d", name="a", uid="u-d")


def _sts_target() -> Target:
    return Target(kind="StatefulSet", namespace="d", name="s", uid="u-s")


@pytest.mark.asyncio
async def test_deployment_pass_when_replicas_is_3():
    ctx = _ctx(_deploy(3)).guard(needs=ResilienceReplicasGe2.needs)
    f = await ResilienceReplicasGe2().run(ctx, _dep_target())
    assert f.status == Status.PASS


@pytest.mark.asyncio
async def test_deployment_fail_when_replicas_is_1():
    ctx = _ctx(_deploy(1)).guard(needs=ResilienceReplicasGe2.needs)
    f = await ResilienceReplicasGe2().run(ctx, _dep_target())
    assert f.status == Status.FAIL
    assert "replicas" in f.message.lower()
    assert f.evidence["replicas"] == 1


@pytest.mark.asyncio
async def test_statefulset_pass_with_replicas_3_and_topology_spread():
    ctx = _ctx(_sts(3, topology=True)).guard(needs=ResilienceReplicasGe2.needs)
    f = await ResilienceReplicasGe2().run(ctx, _sts_target())
    assert f.status == Status.PASS


@pytest.mark.asyncio
async def test_statefulset_pass_with_replicas_3_and_anti_affinity():
    ctx = _ctx(_sts(3, anti_affinity=True)).guard(needs=ResilienceReplicasGe2.needs)
    f = await ResilienceReplicasGe2().run(ctx, _sts_target())
    assert f.status == Status.PASS


@pytest.mark.asyncio
async def test_statefulset_fail_with_replicas_3_but_no_spread_hints():
    ctx = _ctx(_sts(3)).guard(needs=ResilienceReplicasGe2.needs)
    f = await ResilienceReplicasGe2().run(ctx, _sts_target())
    assert f.status == Status.FAIL
    assert "spread" in f.message.lower() or "anti-affinity" in f.message.lower()


@pytest.mark.asyncio
async def test_statefulset_fail_with_replicas_1():
    ctx = _ctx(_sts(1, topology=True)).guard(needs=ResilienceReplicasGe2.needs)
    f = await ResilienceReplicasGe2().run(ctx, _sts_target())
    assert f.status == Status.FAIL
    assert f.evidence["replicas"] == 1
```

- [ ] **Step 2: Run tests to see they fail**

```bash
uv run pytest tests/unit/test_check_replicas_ge_2.py -v
```

Expected: ModuleNotFoundError.

- [ ] **Step 3: Write `src/prod_readiness/checks/resilience_replicas_ge_2.py`**

```python
from __future__ import annotations

from typing import Any

from prod_readiness.core.check import Check
from prod_readiness.core.context import GuardedContext
from prod_readiness.core.models import Capability, Finding, Severity, Status, Target
from prod_readiness.core.registry import register_check

_REMEDIATION_DEPLOYMENT = (
    "spec:\n"
    "  replicas: 3\n"
)

_REMEDIATION_STATEFULSET = (
    "spec:\n"
    "  replicas: 3\n"
    "  template:\n"
    "    spec:\n"
    "      topologySpreadConstraints:\n"
    "        - maxSkew: 1\n"
    "          topologyKey: kubernetes.io/hostname\n"
    "          whenUnsatisfiable: DoNotSchedule\n"
    "          labelSelector:\n"
    "            matchLabels:\n"
    "              app: <label-value>\n"
)


def _has_pod_anti_affinity(pod_spec: Any) -> bool:
    affinity = getattr(pod_spec, "affinity", None)
    if affinity is None:
        return False
    return getattr(affinity, "pod_anti_affinity", None) is not None


def _has_topology_spread(pod_spec: Any) -> bool:
    tsc = getattr(pod_spec, "topology_spread_constraints", None)
    return bool(tsc)


@register_check
class ResilienceReplicasGe2(Check):
    id = "resilience.replicas-ge-2"
    category = "resilience"
    severity = Severity.BLOCKER
    needs = frozenset({Capability.K8S})
    description = (
        "Workload runs ≥2 replicas; StatefulSets additionally require "
        "anti-affinity or topology spread constraints."
    )

    async def run(self, ctx: GuardedContext, target: Target) -> Finding:  # type: ignore[override]
        wl = await ctx.k8s.read_workload(target)
        replicas = getattr(wl.spec, "replicas", None) or 0
        pod_spec = wl.spec.template.spec
        anti_affinity = _has_pod_anti_affinity(pod_spec)
        topology = _has_topology_spread(pod_spec)

        evidence: dict[str, Any] = {
            "replicas": replicas,
            "pod_anti_affinity": anti_affinity,
            "topology_spread_constraints": topology,
        }

        if replicas < 2:
            remediation = (
                _REMEDIATION_DEPLOYMENT
                if target.kind == "Deployment"
                else _REMEDIATION_STATEFULSET
            )
            return Finding(
                check_id=self.id,
                target=target,
                severity=self.severity,
                status=Status.FAIL,
                message=f"replicas={replicas}; require ≥2 for availability.",
                evidence=evidence,
                remediation=remediation,
            )

        if target.kind == "StatefulSet" and not (anti_affinity or topology):
            return Finding(
                check_id=self.id,
                target=target,
                severity=self.severity,
                status=Status.FAIL,
                message=(
                    "StatefulSet has ≥2 replicas but no pod anti-affinity or "
                    "topology spread constraints — replicas may co-locate."
                ),
                evidence=evidence,
                remediation=_REMEDIATION_STATEFULSET,
            )

        return Finding(
            check_id=self.id,
            target=target,
            severity=self.severity,
            status=Status.PASS,
            message=f"replicas={replicas}; spread hints present where required.",
            evidence=evidence,
        )
```

- [ ] **Step 4: Modify `src/prod_readiness/checks/__init__.py`**

After Plan 2 Task 4 the file looks like:

```python
from __future__ import annotations

from prod_readiness.checks import (
    observability_prometheus_scrape_configured,  # noqa: F401
    resources_requests_and_limits_set,  # noqa: F401
    security_runs_as_non_root,  # noqa: F401
)

__all__ = [
    "observability_prometheus_scrape_configured",
    "resources_requests_and_limits_set",
    "security_runs_as_non_root",
]
```

Add the new module alphabetically. Target:

```python
from __future__ import annotations

from prod_readiness.checks import (
    observability_prometheus_scrape_configured,  # noqa: F401
    resilience_replicas_ge_2,  # noqa: F401
    resources_requests_and_limits_set,  # noqa: F401
    security_runs_as_non_root,  # noqa: F401
)

__all__ = [
    "observability_prometheus_scrape_configured",
    "resilience_replicas_ge_2",
    "resources_requests_and_limits_set",
    "security_runs_as_non_root",
]
```

If Plan 2's implementer kept `noqa` absent (relying on `__all__` for ruff), preserve that shape — the decision here is "match what's already there, add new entry alphabetically".

- [ ] **Step 5: Run tests**

```bash
uv run pytest tests/unit/test_check_replicas_ge_2.py -v
uv run pytest tests/unit/ -q
uv run mypy src
uv run ruff check .
```

Expected: all green; 55 tests total (49 after Task 1 + 6 new).

- [ ] **Step 6: Commit**

```bash
git add -A
git commit -m "feat(checks): resilience.replicas-ge-2"
```

---

## Task 3: Golden scenarios for `resilience.replicas-ge-2`

**Files:**
- Create: `tests/golden/resilience.replicas-ge-2/pass-deployment-3-replicas/input.yaml`
- Create: `tests/golden/resilience.replicas-ge-2/pass-deployment-3-replicas/expected.json`
- Create: `tests/golden/resilience.replicas-ge-2/fail-deployment-1-replica/input.yaml`
- Create: `tests/golden/resilience.replicas-ge-2/fail-deployment-1-replica/expected.json`
- Create: `tests/golden/resilience.replicas-ge-2/fail-statefulset-no-spread/input.yaml`
- Create: `tests/golden/resilience.replicas-ge-2/fail-statefulset-no-spread/expected.json`

The golden runner (`tests/golden/test_golden.py`) auto-discovers these — no changes needed there.

- [ ] **Step 1: Write scenario manifests and expected JSON**

`tests/golden/resilience.replicas-ge-2/pass-deployment-3-replicas/input.yaml`:

```yaml
apiVersion: v1
kind: Namespace
metadata:
  name: golden-rep-pass
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: rep-happy
  namespace: golden-rep-pass
spec:
  replicas: 3
  selector:
    matchLabels: { app: rep-happy }
  template:
    metadata:
      labels: { app: rep-happy }
    spec:
      containers:
        - name: api
          image: registry.k8s.io/pause:3.9
```

`tests/golden/resilience.replicas-ge-2/pass-deployment-3-replicas/expected.json`:

```json
[
  {
    "check_id": "resilience.replicas-ge-2",
    "target": {"kind": "Deployment", "namespace": "golden-rep-pass", "name": "rep-happy", "uid": "<uid>"},
    "severity": "blocker",
    "status": "pass",
    "message": "replicas=3; spread hints present where required.",
    "evidence": {"replicas": 3, "pod_anti_affinity": false, "topology_spread_constraints": false},
    "remediation": null,
    "ai_reasoning": null,
    "duration_ms": 0
  }
]
```

`tests/golden/resilience.replicas-ge-2/fail-deployment-1-replica/input.yaml`:

```yaml
apiVersion: v1
kind: Namespace
metadata:
  name: golden-rep-single
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: rep-single
  namespace: golden-rep-single
spec:
  replicas: 1
  selector: { matchLabels: { app: rep-single } }
  template:
    metadata: { labels: { app: rep-single } }
    spec:
      containers:
        - name: api
          image: registry.k8s.io/pause:3.9
```

`tests/golden/resilience.replicas-ge-2/fail-deployment-1-replica/expected.json`:

```json
[
  {
    "check_id": "resilience.replicas-ge-2",
    "target": {"kind": "Deployment", "namespace": "golden-rep-single", "name": "rep-single", "uid": "<uid>"},
    "severity": "blocker",
    "status": "fail",
    "message": "replicas=1; require ≥2 for availability.",
    "evidence": {"replicas": 1, "pod_anti_affinity": false, "topology_spread_constraints": false},
    "remediation": "spec:\n  replicas: 3\n",
    "ai_reasoning": null,
    "duration_ms": 0
  }
]
```

`tests/golden/resilience.replicas-ge-2/fail-statefulset-no-spread/input.yaml`:

```yaml
apiVersion: v1
kind: Namespace
metadata:
  name: golden-rep-sts
---
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: rep-sts-bare
  namespace: golden-rep-sts
spec:
  serviceName: rep-sts-bare
  replicas: 3
  selector: { matchLabels: { app: rep-sts-bare } }
  template:
    metadata: { labels: { app: rep-sts-bare } }
    spec:
      containers:
        - name: api
          image: registry.k8s.io/pause:3.9
```

`tests/golden/resilience.replicas-ge-2/fail-statefulset-no-spread/expected.json`:

```json
[
  {
    "check_id": "resilience.replicas-ge-2",
    "target": {"kind": "StatefulSet", "namespace": "golden-rep-sts", "name": "rep-sts-bare", "uid": "<uid>"},
    "severity": "blocker",
    "status": "fail",
    "message": "StatefulSet has ≥2 replicas but no pod anti-affinity or topology spread constraints — replicas may co-locate.",
    "evidence": {"replicas": 3, "pod_anti_affinity": false, "topology_spread_constraints": false},
    "remediation": "spec:\n  replicas: 3\n  template:\n    spec:\n      topologySpreadConstraints:\n        - maxSkew: 1\n          topologyKey: kubernetes.io/hostname\n          whenUnsatisfiable: DoNotSchedule\n          labelSelector:\n            matchLabels:\n              app: <label-value>\n",
    "ai_reasoning": null,
    "duration_ms": 0
  }
]
```

- [ ] **Step 2: Run the golden suite**

```bash
uv run pytest -m golden -v
```

Expected: 11 scenarios pass (8 prior + 3 new). Runtime ≈ 2–3 min on one shared kind cluster.

If a scenario fails, do NOT modify `expected.json` — investigate: is K8s populating `topology_spread_constraints=[]` vs `None`? (The check treats both as falsy, so either works.) Is `replicas` coming back as `None` when unset? (We fall back to `0`.)

- [ ] **Step 3: Commit**

```bash
git add -A
git commit -m "test(golden): 3 scenarios for resilience.replicas-ge-2"
```

---

## Task 4: Check `resilience.pdb-exists`

**What this check asserts:**

- At least one PodDisruptionBudget in the workload's namespace has `spec.selector` matching the workload's pod-template labels (via `pdb_matches_workload` from Task 1).
- AND the matched PDB leaves at least one pod available: either `minAvailable >= 1` or `maxUnavailable` is a number that leaves ≥1 pod up (we keep v1 simple: `minAvailable >= 1` OR `maxUnavailable` is `0` OR `maxUnavailable` is a percentage string that is `< 100%`).

Severity: `WARNING`. Category: `resilience`. Needs: `{K8S}`.

**Files:**
- Create: `src/prod_readiness/checks/resilience_pdb_exists.py`
- Modify: `src/prod_readiness/checks/__init__.py` — add import + `__all__` entry alphabetically.
- Create: `tests/unit/test_check_pdb_exists.py`

- [ ] **Step 1: Write failing test**

```python
# tests/unit/test_check_pdb_exists.py
from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock

import pytest

from prod_readiness.checks.resilience_pdb_exists import ResiliencePdbExists
from prod_readiness.core.context import AuditContext
from prod_readiness.core.models import Status, Target


def _wl(labels: dict[str, str]) -> object:
    return SimpleNamespace(
        spec=SimpleNamespace(
            template=SimpleNamespace(
                metadata=SimpleNamespace(labels=labels),
                spec=SimpleNamespace(containers=[]),
            )
        )
    )


def _pdb(
    *,
    match_labels: dict[str, str] | None = None,
    min_available: int | str | None = None,
    max_unavailable: int | str | None = None,
    match_expressions: list[dict] | None = None,
) -> object:
    selector = SimpleNamespace(
        match_labels=match_labels,
        match_expressions=[
            SimpleNamespace(**e) for e in (match_expressions or [])
        ],
    )
    return SimpleNamespace(
        spec=SimpleNamespace(
            selector=selector,
            min_available=min_available,
            max_unavailable=max_unavailable,
        )
    )


def _ctx(workload, pdbs: list[object]) -> AuditContext:
    k8s = MagicMock()
    k8s.read_workload = AsyncMock(return_value=workload)
    k8s.list_pdbs = AsyncMock(return_value=pdbs)
    return AuditContext(k8s=k8s, prom=MagicMock(), llm=MagicMock())


def _target() -> Target:
    return Target(kind="Deployment", namespace="d", name="a", uid="u")


@pytest.mark.asyncio
async def test_pass_when_pdb_matches_and_min_available_is_1():
    ctx = _ctx(
        _wl({"app": "api"}),
        pdbs=[_pdb(match_labels={"app": "api"}, min_available=1)],
    ).guard(needs=ResiliencePdbExists.needs)
    f = await ResiliencePdbExists().run(ctx, _target())
    assert f.status == Status.PASS


@pytest.mark.asyncio
async def test_pass_when_pdb_matches_and_max_unavailable_is_percent():
    ctx = _ctx(
        _wl({"app": "api"}),
        pdbs=[_pdb(match_labels={"app": "api"}, max_unavailable="50%")],
    ).guard(needs=ResiliencePdbExists.needs)
    f = await ResiliencePdbExists().run(ctx, _target())
    assert f.status == Status.PASS


@pytest.mark.asyncio
async def test_fail_when_no_pdbs_in_namespace():
    ctx = _ctx(_wl({"app": "api"}), pdbs=[]).guard(needs=ResiliencePdbExists.needs)
    f = await ResiliencePdbExists().run(ctx, _target())
    assert f.status == Status.FAIL
    assert "no PodDisruptionBudget" in f.message


@pytest.mark.asyncio
async def test_fail_when_pdbs_exist_but_none_matches():
    ctx = _ctx(
        _wl({"app": "api"}),
        pdbs=[_pdb(match_labels={"app": "web"}, min_available=1)],
    ).guard(needs=ResiliencePdbExists.needs)
    f = await ResiliencePdbExists().run(ctx, _target())
    assert f.status == Status.FAIL
    assert "no matching" in f.message.lower()


@pytest.mark.asyncio
async def test_fail_when_matching_pdb_has_max_unavailable_100_percent():
    ctx = _ctx(
        _wl({"app": "api"}),
        pdbs=[_pdb(match_labels={"app": "api"}, max_unavailable="100%")],
    ).guard(needs=ResiliencePdbExists.needs)
    f = await ResiliencePdbExists().run(ctx, _target())
    assert f.status == Status.FAIL
    assert "leaves no pods" in f.message.lower() or "100%" in f.message
```

- [ ] **Step 2: Run tests to see they fail**

```bash
uv run pytest tests/unit/test_check_pdb_exists.py -v
```

Expected: ModuleNotFoundError.

- [ ] **Step 3: Write `src/prod_readiness/checks/resilience_pdb_exists.py`**

```python
from __future__ import annotations

from typing import Any

from prod_readiness.adapters.k8s import pdb_matches_workload
from prod_readiness.core.check import Check
from prod_readiness.core.context import GuardedContext
from prod_readiness.core.models import Capability, Finding, Severity, Status, Target
from prod_readiness.core.registry import register_check

_REMEDIATION = (
    "apiVersion: policy/v1\n"
    "kind: PodDisruptionBudget\n"
    "metadata:\n"
    "  name: <workload>-pdb\n"
    "  namespace: <workload-namespace>\n"
    "spec:\n"
    "  minAvailable: 1\n"
    "  selector:\n"
    "    matchLabels:\n"
    "      app: <workload-label>\n"
)


def _preserves_availability(pdb: Any) -> bool:
    min_available = getattr(pdb.spec, "min_available", None)
    max_unavailable = getattr(pdb.spec, "max_unavailable", None)

    if min_available is not None:
        if isinstance(min_available, int):
            return min_available >= 1
        if isinstance(min_available, str) and min_available.endswith("%"):
            return int(min_available.rstrip("%")) > 0
        return False

    if max_unavailable is not None:
        if isinstance(max_unavailable, int):
            return max_unavailable == 0
        if isinstance(max_unavailable, str) and max_unavailable.endswith("%"):
            return int(max_unavailable.rstrip("%")) < 100
        return False

    return False


@register_check
class ResiliencePdbExists(Check):
    id = "resilience.pdb-exists"
    category = "resilience"
    severity = Severity.WARNING
    needs = frozenset({Capability.K8S})
    description = (
        "A matching PodDisruptionBudget exists that keeps at least one pod available."
    )

    async def run(self, ctx: GuardedContext, target: Target) -> Finding:  # type: ignore[override]
        wl = await ctx.k8s.read_workload(target)
        pdbs = await ctx.k8s.list_pdbs(target.namespace)

        evidence: dict[str, Any] = {"pdbs_in_namespace": len(pdbs)}
        if not pdbs:
            return Finding(
                check_id=self.id,
                target=target,
                severity=self.severity,
                status=Status.FAIL,
                message="no PodDisruptionBudget found in namespace.",
                evidence=evidence,
                remediation=_REMEDIATION,
            )

        matching = [p for p in pdbs if pdb_matches_workload(p, wl)]
        evidence["matching_pdbs"] = len(matching)
        if not matching:
            return Finding(
                check_id=self.id,
                target=target,
                severity=self.severity,
                status=Status.FAIL,
                message=(
                    f"{len(pdbs)} PDB(s) in namespace but no matching selector "
                    "for this workload."
                ),
                evidence=evidence,
                remediation=_REMEDIATION,
            )

        for pdb in matching:
            if _preserves_availability(pdb):
                return Finding(
                    check_id=self.id,
                    target=target,
                    severity=self.severity,
                    status=Status.PASS,
                    message=f"{len(matching)} matching PDB(s) preserve availability.",
                    evidence=evidence,
                )

        return Finding(
            check_id=self.id,
            target=target,
            severity=self.severity,
            status=Status.FAIL,
            message=(
                "Matching PDB exists but leaves no pods available "
                "(e.g. maxUnavailable=100%)."
            ),
            evidence=evidence,
            remediation=_REMEDIATION,
        )
```

- [ ] **Step 4: Modify `src/prod_readiness/checks/__init__.py`**

Target (after Task 2's additions):

```python
from __future__ import annotations

from prod_readiness.checks import (
    observability_prometheus_scrape_configured,  # noqa: F401
    resilience_pdb_exists,  # noqa: F401
    resilience_replicas_ge_2,  # noqa: F401
    resources_requests_and_limits_set,  # noqa: F401
    security_runs_as_non_root,  # noqa: F401
)

__all__ = [
    "observability_prometheus_scrape_configured",
    "resilience_pdb_exists",
    "resilience_replicas_ge_2",
    "resources_requests_and_limits_set",
    "security_runs_as_non_root",
]
```

- [ ] **Step 5: Run tests**

```bash
uv run pytest tests/unit/test_check_pdb_exists.py -v
uv run pytest tests/unit/ -q
uv run mypy src
uv run ruff check .
```

Expected: all green; 60 tests total (55 after Task 2 + 5 new).

- [ ] **Step 6: Commit**

```bash
git add -A
git commit -m "feat(checks): resilience.pdb-exists"
```

---

## Task 5: Golden scenarios for `resilience.pdb-exists`

**Files:**
- Create: `tests/golden/resilience.pdb-exists/pass-min-available/input.yaml`
- Create: `tests/golden/resilience.pdb-exists/pass-min-available/expected.json`
- Create: `tests/golden/resilience.pdb-exists/fail-no-pdb/input.yaml`
- Create: `tests/golden/resilience.pdb-exists/fail-no-pdb/expected.json`
- Create: `tests/golden/resilience.pdb-exists/fail-pdb-leaves-none/input.yaml`
- Create: `tests/golden/resilience.pdb-exists/fail-pdb-leaves-none/expected.json`

- [ ] **Step 1: Write manifests and expected JSON**

`tests/golden/resilience.pdb-exists/pass-min-available/input.yaml`:

```yaml
apiVersion: v1
kind: Namespace
metadata:
  name: golden-pdb-pass
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: pdb-happy
  namespace: golden-pdb-pass
spec:
  replicas: 3
  selector:
    matchLabels: { app: pdb-happy }
  template:
    metadata:
      labels: { app: pdb-happy }
    spec:
      containers:
        - name: api
          image: registry.k8s.io/pause:3.9
---
apiVersion: policy/v1
kind: PodDisruptionBudget
metadata:
  name: pdb-happy
  namespace: golden-pdb-pass
spec:
  minAvailable: 1
  selector:
    matchLabels: { app: pdb-happy }
```

`tests/golden/resilience.pdb-exists/pass-min-available/expected.json`:

```json
[
  {
    "check_id": "resilience.pdb-exists",
    "target": {"kind": "Deployment", "namespace": "golden-pdb-pass", "name": "pdb-happy", "uid": "<uid>"},
    "severity": "warning",
    "status": "pass",
    "message": "1 matching PDB(s) preserve availability.",
    "evidence": {"pdbs_in_namespace": 1, "matching_pdbs": 1},
    "remediation": null,
    "ai_reasoning": null,
    "duration_ms": 0
  }
]
```

`tests/golden/resilience.pdb-exists/fail-no-pdb/input.yaml`:

```yaml
apiVersion: v1
kind: Namespace
metadata:
  name: golden-pdb-missing
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: pdb-missing
  namespace: golden-pdb-missing
spec:
  replicas: 3
  selector: { matchLabels: { app: pdb-missing } }
  template:
    metadata: { labels: { app: pdb-missing } }
    spec:
      containers:
        - name: api
          image: registry.k8s.io/pause:3.9
```

`tests/golden/resilience.pdb-exists/fail-no-pdb/expected.json`:

```json
[
  {
    "check_id": "resilience.pdb-exists",
    "target": {"kind": "Deployment", "namespace": "golden-pdb-missing", "name": "pdb-missing", "uid": "<uid>"},
    "severity": "warning",
    "status": "fail",
    "message": "no PodDisruptionBudget found in namespace.",
    "evidence": {"pdbs_in_namespace": 0},
    "remediation": "apiVersion: policy/v1\nkind: PodDisruptionBudget\nmetadata:\n  name: <workload>-pdb\n  namespace: <workload-namespace>\nspec:\n  minAvailable: 1\n  selector:\n    matchLabels:\n      app: <workload-label>\n",
    "ai_reasoning": null,
    "duration_ms": 0
  }
]
```

`tests/golden/resilience.pdb-exists/fail-pdb-leaves-none/input.yaml`:

```yaml
apiVersion: v1
kind: Namespace
metadata:
  name: golden-pdb-zero
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: pdb-zero
  namespace: golden-pdb-zero
spec:
  replicas: 3
  selector: { matchLabels: { app: pdb-zero } }
  template:
    metadata: { labels: { app: pdb-zero } }
    spec:
      containers:
        - name: api
          image: registry.k8s.io/pause:3.9
---
apiVersion: policy/v1
kind: PodDisruptionBudget
metadata:
  name: pdb-zero
  namespace: golden-pdb-zero
spec:
  maxUnavailable: 100%
  selector:
    matchLabels: { app: pdb-zero }
```

`tests/golden/resilience.pdb-exists/fail-pdb-leaves-none/expected.json`:

```json
[
  {
    "check_id": "resilience.pdb-exists",
    "target": {"kind": "Deployment", "namespace": "golden-pdb-zero", "name": "pdb-zero", "uid": "<uid>"},
    "severity": "warning",
    "status": "fail",
    "message": "Matching PDB exists but leaves no pods available (e.g. maxUnavailable=100%).",
    "evidence": {"pdbs_in_namespace": 1, "matching_pdbs": 1},
    "remediation": "apiVersion: policy/v1\nkind: PodDisruptionBudget\nmetadata:\n  name: <workload>-pdb\n  namespace: <workload-namespace>\nspec:\n  minAvailable: 1\n  selector:\n    matchLabels:\n      app: <workload-label>\n",
    "ai_reasoning": null,
    "duration_ms": 0
  }
]
```

- [ ] **Step 2: Run the golden suite**

```bash
uv run pytest -m golden -v
```

Expected: 14 scenarios pass (11 after Task 3 + 3 new). Runtime ≈ 2–3 min.

- [ ] **Step 3: Commit**

```bash
git add -A
git commit -m "test(golden): 3 scenarios for resilience.pdb-exists"
```

---

## Task 6: Release v0.3.0

**Files:**
- Modify: `src/prod_readiness/__init__.py` — bump `__version__` to `"0.3.0"`.
- Modify: `pyproject.toml` — bump `version` to `"0.3.0"`.
- Modify: `CHANGELOG.md` — add v0.3.0 entry above v0.2.0.
- Modify: `README.md` — bump "ships with N checks" copy to 5.

- [ ] **Step 1: Bump version**

Edit `src/prod_readiness/__init__.py`:

```python
__version__ = "0.3.0"
```

Edit `pyproject.toml`, change the `version = "0.2.0"` line to:

```toml
version = "0.3.0"
```

- [ ] **Step 2: Update `CHANGELOG.md`**

Insert ABOVE the `## [0.2.0]` heading:

```markdown
## [0.3.0] — 2026-04-20

### Added
- Check: `resilience.replicas-ge-2` (blocker). Deployments need ≥2 replicas; StatefulSets additionally need anti-affinity or topology spread.
- Check: `resilience.pdb-exists` (warning). A matching PodDisruptionBudget must exist that preserves availability.
- `K8sAdapter.list_pdbs(namespace)` and `pdb_matches_workload(pdb, workload)` helper.
```

- [ ] **Step 3: Update `README.md`**

Change:

```markdown
**Status:** alpha. Today ships with **3 checks**. The v1.0.0 milestone adds 7 more.
```

to:

```markdown
**Status:** alpha. Today ships with **5 checks**. The v1.0.0 milestone adds 5 more.
```

If the README after Plan 2 differs slightly, adapt to reflect **5 checks** / **5 more**.

- [ ] **Step 4: Run the full release gate**

```bash
uv run ruff check .
uv run mypy src
uv run pytest -m "not integration and not golden and not mcp_contract" -v
uv run pytest -m "golden or integration or mcp_contract" -v
```

Expected: ruff 0, mypy 0, unit 60, `golden or integration or mcp_contract` = 16 (14 golden + 1 integration + 1 mcp_contract).

- [ ] **Step 5: Commit**

```bash
git add -A
git commit -m "chore(release): v0.3.0 — two resilience checks"
```

- [ ] **Step 6: Do NOT push a tag**

Print the deferred command:

```
git tag -a v0.3.0 -m "v0.3.0: resilience.replicas-ge-2 + resilience.pdb-exists"
git push origin v0.3.0
```

---

## Plan 3 exit checklist

- [ ] 60 unit tests pass.
- [ ] 14 golden scenarios pass.
- [ ] 1 integration + 1 mcp_contract test still pass.
- [ ] `prod-readiness list-checks` prints 5 check IDs.
- [ ] Audit on a kind cluster with the pass manifests returns `blocker=0 warning=0`.
- [ ] `CHANGELOG.md` has v0.3.0; `pyproject.toml` and `__init__.py` both at `0.3.0`.

## Hand-off to Plan 4

Plan 4 adds `scaling.hpa-exists-and-realistic` — the first LLM-using check. It introduces the litellm/instructor cassette harness (record real calls once, replay deterministically in CI), the K8s `AutoscalingV2Api` wrapper for listing HPAs, and a Prom traffic-model query for "p99 traffic over 30d". Exit: `v0.4.0` with 6 checks.

---

## Self-review

**Spec coverage (Plan 3 slice):**

| Spec section | Covered by task |
|---|---|
| §6 MVP check row 7 (`resilience.pdb-exists`) | Tasks 1, 4, 5 |
| §6 MVP check row 8 (`resilience.replicas-ge-2`) | Tasks 2, 3 |
| §4 Adapter: K8s PDB listing | Task 1 |
| §10 Unit + golden coverage | Tasks 2, 4 (unit); Tasks 3, 5 (golden; 3 scenarios each, spec §10 gate) |
| §12 SemVer + CHANGELOG | Task 6 |

**Placeholder scan:** no `TBD`/`TODO`/`implement later` in any code step. One acknowledged v1 simplification is called out in `pdb_matches_workload` — PDBs that use `matchExpressions` are treated as non-matching rather than fully evaluated. The docstring explicitly explains this is v1 behaviour and that the check errs on the side of "no PDB found" — user-visible truth, not a plan placeholder.

**Type/name consistency:** `K8sAdapter.list_pdbs` and the module-level `pdb_matches_workload` are both defined in Task 1 and consumed in Task 4. The fixture helpers in `test_check_pdb_exists.py` use the same `SimpleNamespace` shape (`spec.selector.match_labels`, `spec.min_available`, `spec.max_unavailable`, `spec.selector.match_expressions`) the real `kubernetes_asyncio` client emits. The `Check` and `GuardedContext` surfaces are identical to Plans 1 and 2.

**Scope:** two small K8s-pure checks + one adapter extension. Bite-sized; produces a releasable v0.3.0.
