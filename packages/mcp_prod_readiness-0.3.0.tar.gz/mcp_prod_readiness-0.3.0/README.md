# mcp-prod-readiness

Kubernetes production-readiness auditor — MCP server + CLI.

**Status:** alpha. Today ships with **5 checks**. The v1.0.0 milestone adds 5 more.

## Install

```bash
# Ephemeral:
uvx mcp-prod-readiness list-checks

# Persistent:
pip install mcp-prod-readiness
```

## Quickstart — CLI

```bash
prod-readiness audit --namespace default --format md
```

## Quickstart — Claude Code / Desktop

```json
{
  "mcpServers": {
    "prod-readiness": {
      "command": "uvx",
      "args": ["mcp-prod-readiness", "serve-mcp"]
    }
  }
}
```

## LLM configuration

Any provider, any base URL, or fully offline:

```bash
# Anthropic
export PROD_READINESS_LLM_PROVIDER=anthropic/claude-sonnet-4-6
export PROD_READINESS_LLM_API_KEY=sk-ant-...

# Local Ollama (auto-detected if unconfigured)
export PROD_READINESS_LLM_PROVIDER=ollama/qwen2.5:7b
export PROD_READINESS_LLM_BASE_URL=http://localhost:11434

# Offline
export PROD_READINESS_OFFLINE=1
```

## Design and plans

- Spec: [`docs/superpowers/specs/2026-04-20-mcp-prod-readiness-design.md`](docs/superpowers/specs/2026-04-20-mcp-prod-readiness-design.md)
- Plan 1 (this release): [`docs/superpowers/plans/2026-04-20-mcp-prod-readiness-plan-1-walking-skeleton.md`](docs/superpowers/plans/2026-04-20-mcp-prod-readiness-plan-1-walking-skeleton.md)
