from unittest import TestCase
from rest_framework.test import APIClient
from django.utils.translation import ugettext as _
from django.utils import translation
from .middleware import (
    request_response_formatter, get_all_locales,
    get_translations, reset_db, BOOL,
    set_auth_header, reset_auth_header, set_custom_headers,
    set_lang_header, set_reset_seq_query, set_all_models,
    unit_test_formatter, generate_test_report,
    parse_snapshot, generate_analytics, get_test_endpoints,
    Constants, mark_test_as_failed, form_endpoint, replace_context_var,
    set_default_data_to_context, CustomDict, Context,  purge_not_applicables, set_context_vars,
    log_method_call
)
from unittest import TextTestRunner, TextTestResult
from django.test.runner import DiscoverRunner
import inspect
from rest_framework.test import RequestsClient
from django.conf import settings
import requests
import re
import json
import os
import csv
from django.template.loader import render_to_string
from .object_manager import ObjectManager
import time
import copy
import yaml
import random
from case_insensitive_dict import CaseInsensitiveDict


class CustomTextTestResult(TextTestResult):
    def startTestRun(self):
        set_reset_seq_query()
        set_all_models()

    def stopTestRun(self):
        super().stopTestRun()

        TestRunner.runtime_info['test_session_status'] = 'completed'
        with open(settings.TEST_PAYLOAD_PATH + '/data/yml/runtime_info.yml', 'w') as f:
            yaml.dump(dict(runtimeInfo=TestRunner.runtime_info), f)
        self.testsRun = TestRunner.total_test_cases
        analytics = generate_analytics(Constants.FAIL_LOG)
        if TestRunner.query_executor:
            TestRunner.query_executor.quit()

        if (self.testsRun + len(Constants.EXCEPTIONS)):

            report = render_to_string('report.html', {
                'priority_fail_count': analytics,
                'passed_tests': Constants.PASSED_TESTS,
                'failed_tests': Constants.FAILED_TESTS,
                'success_count': self.testsRun - len(Constants.FAIL_LOG),
                'success_percentage': float("%0.2f" % ((self.testsRun - len(Constants.FAIL_LOG))/(self.testsRun + len(Constants.EXCEPTIONS)) * 100)),
                'fail_count': len(Constants.FAIL_LOG),
                'fail_percentage': float("%0.2f" % (len(Constants.FAIL_LOG)/(self.testsRun + len(Constants.EXCEPTIONS)) * 100)),
                'exception_count': len(Constants.EXCEPTIONS),
                'exception_percentage': float("%0.2f" % (len(Constants.EXCEPTIONS)/(self.testsRun + len(Constants.EXCEPTIONS)) * 100)),
                'exception_details': Constants.EXCEPTIONS
            })

            if not os.path.exists(settings.TEST_PAYLOAD_PATH + '/reports'):
                os.makedirs(settings.TEST_PAYLOAD_PATH + '/reports')

            print('Generating Report for Session: {}'.format(
                TestRunner.test_session_id))
            f = open(settings.TEST_PAYLOAD_PATH +
                     '/reports/report-{}.html'.format(TestRunner.test_session_id), 'w')
            f.write(report)

    def startTest(self, test):
        super(TextTestResult, self).startTest(test)
        with open(settings.TEST_PAYLOAD_PATH + '/data/yml/runtime_info.yml', 'w') as f:
            TestRunner.runtime_info['session_id'] = TestRunner.test_session_id
            yaml.dump(dict(runtimeInfo=TestRunner.runtime_info), f)


class CustomTextTestRunner(TextTestRunner):
    resultclass = CustomTextTestResult


class CMTestRunner(DiscoverRunner):
    test_runner = CustomTextTestRunner


class TestRunner(TestCase):
    client = requests.Session()
    total_test_cases = 0
    def create_default_user(): return None
    def create_default_superuser(): return None
    def create_default_superuser_token(): return None
    def create_default_user_token(): return None
    def reset_db(): return None
    total_exceptions = 0
    package = None
    ENDPOINTS = None
    query_executor = None
    test_pool = {}
    Context = Context
    test_session_id = str(random.choice(range(1, 10000)))
    runtime_info = dict(test_session_status='running', tests=[])
    case_insensitive_check = False

    @log_method_call
    def set_test_vars(self, test_data):
        # TestRunner.total_test_cases += 1
        self.response = None
        reset_auth_header(TestRunner.client)
        self.request_body = test_data.get('req')
        if self.request_body.get('user_type'):
            user_type = self.request_body.pop('user_type')
            if user_type == 'user':
                self.set_user_auth()
            elif user_type == 'admin':
                self.set_superuser_auth()
            elif user_type == 'invalid':
                set_auth_header(TestRunner.client, 'XXXinvalid_tokenXXX')

        # self.set_endpoints()
        self.wait = self.request_body.get('wait', 0)
        self.exp_response = test_data.get('resp')
        self.priority = int(self.request_body.pop('priority'))
        self.test_id = self.request_body.pop('test_id')
        self.test_purpose = self.request_body.pop('comment')
        self.context_params = self.request_body.pop('context', {})
        self.error_info = '\nTest ID: ' + str(
            self.test_id) + ' =====>>>>> ' + self.test_data_set + \
            ' failed for language: %s.\n' % self.accept_lang
        self.custom_headers = test_data.get('headers')
        self.endpoint = getattr(
            TestRunner.ENDPOINTS,
            self.endpoint_alias
        )
        # self.request_body = replace_context_var(self.request_body)
        # self.endpoint = form_endpoint(self.endpoint, self.request_body)
        # setattr(TestRunner.ENDPOINTS, self.endpoint_alias, self.endpoint)

    @log_method_call
    def get_error(self, error_info, exp_response):
        errors = 'Validation failed for: ' + error_info + '\n\n'
        errors += 'Test Purpose: ' + self.test_purpose + '\n\n'
        errors += 'Requset Header: ' + str(
            TestRunner.client.headers) + '\n\n'
        errors += 'Request Body: \n\t' + str(self.request_body)[:100] + (
            ['', '....}'][len(str(self.request_body)) > 100]) + '\n\n'
        return errors

    @log_method_call
    def format_expected_response(self, exp_resp, accept_lang):
        translations = self.load_translations(accept_lang)
        if type(exp_resp) is list:
            for idx, x in enumerate(exp_resp):
                if type(x) is not dict:
                    if translations.get(x):
                        exp_resp[idx] = translations.get(x)
                    elif type(x) is not int:
                        exp_resp[idx] = _(x)
        elif type(exp_resp) is not dict:
            if translations.get(exp_resp):
                exp_resp = translations.get(exp_resp)
            elif type(exp_resp) is not int and type(exp_resp) is not float:
                exp_resp = _(exp_resp)
        return exp_resp

    def load_translations(self, accept_lang):
        return get_translations(accept_lang)

    @log_method_call
    def set_endpoints(self):
        TestRunner.ENDPOINTS = get_test_endpoints('endpoints.yml')

    @log_method_call
    def refresh_environment(self):
        try:
            for refresh_env in self.refresh_envs:
                refresh_env()
        except Exception as e:
            Constants.EXCEPTIONS.append({
                'test_method': self.test_name,
                'details': e
            })
            raise Exception(refresh_env.__doc__ + ':: ' + str(e))

    @log_method_call
    def set_environment(self, envs):
        # print('self.package: ', self.package)
        settings.TEST_SERVER = getattr(
            settings, self.package.upper() + '_BASE_URL')
        self.set_endpoints()
        # need to find out why this is here again
        TestRunner.client = self.get_client()
        if settings.TEST_SERVER == 'http://testserver':
            TestRunner.reset_db = reset_db
        if TestRunner.query_executor:
            TestRunner.reset_db(TestRunner.query_executor)
        translation.activate('en')
        self.reproduce_steps = []
        try:
            for env in envs:
                self.reproduce_steps.append(env.__doc__)
                if not hasattr(inspect, 'getargspec'):
                    inspect.getargspec = inspect.getfullargspec
                args = inspect.getargspec(env).args
                if args and args[0] == 'client':
                    env(TestRunner.client)
                else:
                    env()
        except Exception as e:
            Constants.EXCEPTIONS.append({
                'test_method': self.test_name,
                'details': e
            })
            raise Exception(env.__doc__ + ':: ' + str(e))

    @log_method_call
    def set_headers(self, **kwargs):
        accept_lang = kwargs.get('accept_lang')
        set_lang_header(TestRunner.client, accept_lang)
        return True

    def set_user_auth(self):
        TestRunner.create_default_user()
        token = TestRunner.create_default_user_token()
        set_auth_header(TestRunner.client, token)

    def set_superuser_auth(self):
        TestRunner.create_default_superuser()
        token = TestRunner.create_default_superuser_token()
        set_auth_header(TestRunner.client, token)

    @log_method_call
    def get_response(self):
        return self.response

    @log_method_call
    def get_client(self):
        if settings.TEST_SERVER == 'http://testserver':
            return RequestsClient()
        return TestRunner.client

    # see CONTRIBUTING.md for test data formats.

    @log_method_call
    def verify_test_result(self, exp_response, test_id, accept_lang):
        response_time = None
        response_status_code = None

        if self.response.get('request_errors'):
            exp_response['request_errors'] = None

        response_ = {}
        if self.response:
            response_time = self.response.get('response_time')
            response_status_code = self.response.get('status_code')

        exp_response_ = copy.deepcopy(exp_response)
        if exp_response_.get('response'):
            exp_response.pop('response')
            # snapshot parsing for response key
            snap = parse_snapshot(exp_response_.pop('response'), self.response)
            if type(snap) is dict:
                snap.update(exp_response)
                exp_response = exp_response_ = snap
            # exp_response_.update(snap)
            # exp_response.update(snap)

        for key, value in exp_response_.items():

            if accept_lang != 'en':
                exp_response[key] = self.format_expected_response(
                    exp_response[key], accept_lang)

            val = parse_snapshot(value, self.response.get(key))
            if val == 'N/A':
                continue
            # if key == 'response':
            #     exp_response.pop('response')
            #     exp_response.update(parse_snapshot(value, self.response))   # there is a bug in this line, response may not be a dictionary always
            #     response_.update(self.response)
            #     continue
            exp_response[key] = val  # snapshot parsing for individual keys
            res = self.response
            if TestRunner.case_insensitive_check:
                res = CaseInsensitiveDict(data=self.response)
            response_[key] = res.get(key)
        exp_response = replace_context_var(exp_response)

        purge_not_applicables(exp_response)

        # leftOverResponseAttributes = self.response.keys() - response_.keys()
        # leftOverResponse = {}
        # for item in leftOverResponseAttributes:
        #     leftOverResponse[item] = self.response.get(item)

        # self.response = response_

        object_manager = ObjectManager(
            response_, exp_response, case_insensitive_check=TestRunner.case_insensitive_check)
        object_manager.match_obj()
        response_, exp_response = object_manager.get_converted()
        self.is_matched = object_manager.is_matched()
        error_info = ', '.join(object_manager.mismatched_keys())
        errors = self.get_error(error_info, exp_response)
        self.response.update(response_)

        # if self.is_matched:
        set_context_vars(self.context_params, response_)

        generate_test_report(
            test_name=self.test_data_set, priority=self.priority, test_id=self.test_id,
            purpose=self.test_purpose, reproduce_steps=self.reproduce_steps,
            request_body=self.request_body, response=self.response,
            request_header=dict(TestRunner.client.headers),
            expected_response=exp_response,
            error_info=error_info,
            response_time=response_time,
            status_code=response_status_code,
            endpoint=getattr(TestRunner.ENDPOINTS, self.endpoint_alias)
        )

        try:
            self.assertEqual(self.is_matched, True, msg=errors)
        except AssertionError:
            mark_test_as_failed(self.test_data_set)
            raise

    @log_method_call
    def set_test_attributes(self, **kwargs):
        set_default_data_to_context(settings.TEST_ENV, self.package)
        self.test_method = kwargs.get('test_method')
        self.environment = kwargs.get('env', [])
        self.refresh_envs = kwargs.get('refresh_envs', [])
        self.sub_test = kwargs.get('sub_test')
        self.accept_lang = kwargs.get('accept_lang')
        self.set_headers(accept_lang=self.accept_lang)
        self.test_data_set = kwargs.get('test_data_set')
        self.test_name = self.test_data_set.split('.')[0].replace('_', ' ')
        self.set_environment(self.environment)
        self.test_data = request_response_formatter(
            'tests/' + self.test_data_set)
        self.endpoint_alias = kwargs.get('endpoint_alias', [])
        # self.endpoint = getattr(
        #     TestRunner.ENDPOINTS,
        #     self.endpoint_alias
        #     )
        TestRunner.test_pool[self.test_data_set] = self.test_data

    @log_method_call
    def process_tests(self, **kwargs):
        self.set_test_attributes(**kwargs)
        TestRunner.runtime_info['tests'].append(
            dict(name=self.test_name, status='running', total_tests=len(self.test_data), tests_executed=0, completion=0))

        with open(settings.TEST_PAYLOAD_PATH + '/data/yml/runtime_info.yml', 'w') as f:
            yaml.dump(dict(runtimeInfo=TestRunner.runtime_info), f)
        for each_test_data in self.test_data:
            TestRunner.runtime_info['tests'][-1]['completion'] = round(
                TestRunner.runtime_info['tests'][-1]['tests_executed']/TestRunner.runtime_info['tests'][-1]['total_tests'] * 100, 2)

            with open(settings.TEST_PAYLOAD_PATH + '/data/yml/runtime_info.yml', 'w') as f:
                yaml.dump(dict(runtimeInfo=TestRunner.runtime_info), f)

            TestRunner.runtime_info['tests'][-1]['tests_executed'] += 1

            self.set_test_vars(each_test_data)

            if self.request_body.get(
                    'accept_lang'
            ) and self.request_body.get('accept_lang') != self.accept_lang:
                TestRunner.total_test_cases -= 1
                continue
            time.sleep(float(self.wait)/1000)

            files = self.request_body.pop('files')

            purge_not_applicables(self.request_body)
            purge_not_applicables(self.custom_headers)

            if self.request_body.get('reset_env'):
                self.refresh_environment()
                self.set_environment(self.environment)
                self.request_body.pop('reset_env')

            self.request_body = replace_context_var(self.request_body)
            self.endpoint = form_endpoint(self.endpoint, self.request_body)

            self.request_body['files'] = files
            set_custom_headers(TestRunner.client,
                               replace_context_var(self.custom_headers))
            try:
                self.response = kwargs.get('test_method')(
                    client=TestRunner.client,
                    request_body=self.request_body,
                    accept_lang=self.accept_lang,
                    headers=self.custom_headers,
                    url=self.endpoint
                )

            except requests.exceptions.RequestException as e:
                self.response = dict(request_errors=e)
            except Exception as e:
                Constants.EXCEPTIONS.append({
                    'test_method': self.test_method.__name__,
                    'details': e
                })
                TestRunner.runtime_info['tests'][-1]['completion'] = 100.00
                TestRunner.runtime_info['tests'][-1]['status'] = 'completed'
                raise Exception('Exception Occured: ' + str(e))

            with self.subTest():
                TestRunner.total_test_cases += 1
                self.verify_test_result(self.exp_response, self.test_id,
                                        self.accept_lang)
        self.refresh_environment()
        TestRunner.runtime_info['tests'][-1]['status'] = 'completed'
        TestRunner.runtime_info['tests'][-1]['completion'] = 100
        with open(settings.TEST_PAYLOAD_PATH + '/data/yml/runtime_info.yml', 'w') as f:
            yaml.dump(dict(runtimeInfo=TestRunner.runtime_info), f)

    @log_method_call
    def execute_tests(self, **kwargs):
        try:
            locales = get_all_locales()
            locales.append('en')
            for each_lang in locales:
                kwargs['accept_lang'] = each_lang
                self.process_tests(**kwargs)
        except Exception as e:
            print(e)
            raise

    @log_method_call
    def execute_unit_tests(self, **kwargs):

        test_data_set = kwargs.get('test_data_set')
        test_data = unit_test_formatter(test_data_set)
        self.set_environment(kwargs.get('env'))

        for each_test_data in test_data:
            args = each_test_data.get('args')
            inits = each_test_data.get('inits')
            kwargs_ = each_test_data.get('kwargs')
            returns = each_test_data.get('returns')
            test_obj = kwargs.get('test_object')
            if kwargs.get('test_class'):
                test_class = getattr(test_obj, kwargs.get('test_class'))
                test_method = kwargs.get('test_method')
                if kwargs.get('static'):
                    test_obj = getattr(test_class, test_method)
                else:
                    test_obj = test_class(*inits)
                    test_obj = getattr(test_obj, test_method)
            else:
                test_obj = getattr(test_obj, kwargs.get('test_method'))
            response = test_obj(*args, **kwargs_)
            TestRunner.total_test_cases += 1

            self.assertEqual(str(response), str(returns))
