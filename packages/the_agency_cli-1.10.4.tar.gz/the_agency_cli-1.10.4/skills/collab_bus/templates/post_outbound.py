#!/usr/bin/env python3
"""
Collab Bus Transport — GitHub & GitLab Issues backend

Reads tmp/outbound.md, executes the requested action via the configured
backend (GitHub `gh` CLI or GitLab REST API), prints the current issue
state, and clears the file for the next message.

Supported actions:
  view     — fetch full issue thread
  latest   — fetch last N comments (default 1) + issue header
  list     — list open issues
  comment  — post a comment to an issue
  create   — create a new issue
  close    — close an issue

Backend selection (in outbound.md frontmatter or comms/collab_bus.conf):
  backend: github   (default — uses `gh` CLI)
  backend: gitlab   (uses GitLab REST API via curl/requests)

GitLab configuration (comms/collab_bus.conf):
  gitlab_url:        https://gitlab.example.com
  gitlab_project_id: 1
  gitlab_token_env:  GITLAB_HELPER_CLAUDE_TOKEN
  gitlab_token_file: functions/.env.local
  cf_app_url:        https://gitlab.example.com  (if behind Cloudflare Access)

Usage:
  python tmp/post_outbound.py
  python tmp/post_outbound.py --dry-run
  python tmp/post_outbound.py --file path/to/outbound.md
  python tmp/post_outbound.py --backend gitlab
"""

import argparse
import json
import os
import re
import subprocess
import sys
from pathlib import Path
from urllib.parse import quote as urlquote

DEFAULT_OUTBOUND = Path("tmp/outbound.md")
DEFAULT_CONF = Path("comms/collab_bus.conf")

TEMPLATE = """\
---
# action:  view | latest | list | comment | create | close
# issue:   (issue number)
# count:   (for 'latest', default 1)
# title:   (for 'create')
# labels:  (for 'create', comma-separated)
# backend: github | gitlab  (override default from collab_bus.conf)
action: comment
issue:
---

"""


# ---------------------------------------------------------------------------
# Frontmatter / config parsing
# ---------------------------------------------------------------------------

def parse_outbound(path: Path) -> tuple[dict, str]:
    """Parse YAML-like frontmatter and body from outbound.md."""
    text = path.read_text(encoding="utf-8")
    match = re.match(r"^---\s*\n(.*?)\n---\s*\n?(.*)", text, re.DOTALL)
    if not match:
        print("ERROR: outbound.md has no valid frontmatter (---)")
        sys.exit(1)

    meta: dict[str, str] = {}
    for line in match.group(1).splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if ":" in line:
            key, _, val = line.partition(":")
            meta[key.strip()] = val.strip()

    body = match.group(2).strip()
    return meta, body


def load_conf(path: Path) -> dict[str, str]:
    """Load key: value config from collab_bus.conf (same format as frontmatter)."""
    if not path.exists():
        return {}
    conf: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if ":" in line:
            key, _, val = line.partition(":")
            conf[key.strip()] = val.strip()
    return conf


# ---------------------------------------------------------------------------
# GitHub backend (via `gh` CLI)
# ---------------------------------------------------------------------------

def gh(*args: str, input_text: str | None = None) -> str:
    """Run a gh CLI command and return stdout."""
    cmd = ["gh"] + list(args)
    result = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        input=input_text,
    )
    if result.returncode != 0:
        print(f"ERROR: gh {' '.join(args)}")
        print(result.stderr)
        sys.exit(1)
    return result.stdout


def parse_comment_pages(raw: str) -> list[dict]:
    """Parse one or more JSON pages returned by `gh api --paginate`."""
    if not raw.strip():
        return []

    comments: list[dict] = []
    decoder = json.JSONDecoder()
    index = 0

    while index < len(raw):
        while index < len(raw) and raw[index].isspace():
            index += 1
        if index >= len(raw):
            break

        page, index = decoder.raw_decode(raw, index)
        if isinstance(page, list):
            comments.extend(item for item in page if isinstance(item, dict))
        elif isinstance(page, dict):
            comments.append(page)

    return comments


class GitHubBackend:
    """Issue operations via the `gh` CLI (GitHub)."""

    name = "github"

    def view(self, meta: dict, _body: str) -> None:
        issue = meta.get("issue")
        if not issue:
            print("ERROR: 'issue' field is required for action: view")
            sys.exit(1)
        print(gh("issue", "view", issue, "--comments"))

    def latest(self, meta: dict, _body: str) -> None:
        issue = meta.get("issue")
        if not issue:
            print("ERROR: 'issue' field is required for action: latest")
            sys.exit(1)
        count = int(meta.get("count", "1"))
        header = gh("issue", "view", issue)
        comments_json = gh("api", f"repos/{{owner}}/{{repo}}/issues/{issue}/comments",
                           "--paginate", "--jq", ".")
        try:
            comments = parse_comment_pages(comments_json)
        except json.JSONDecodeError:
            comments = []

        print(header)
        print(f"\n--- Last {count} comment(s) ---\n")
        if not comments:
            print("(no comments yet)")
            return

        for c in comments[-count:]:
            print(f"[{c.get('created_at', '')}] {c.get('user', {}).get('login', 'unknown')}:")
            print(c.get("body", ""))
            print("---")

    def list_issues(self, meta: dict, _body: str) -> None:
        label_filter = meta.get("labels", "")
        args = ["issue", "list", "--state", "open"]
        if label_filter:
            args.extend(["--label", label_filter])
        print(gh(*args))

    def comment(self, meta: dict, body: str) -> None:
        issue = meta.get("issue")
        if not issue:
            print("ERROR: 'issue' field is required for action: comment")
            sys.exit(1)
        if not body:
            print("ERROR: comment body is empty — write your message below the frontmatter")
            sys.exit(1)
        gh("issue", "comment", issue, "--body", body)
        print(f"Comment posted to issue #{issue}")
        print("\n--- Current issue state ---\n")
        print(gh("issue", "view", issue, "--comments"))

    def create(self, meta: dict, body: str) -> None:
        title = meta.get("title")
        if not title:
            print("ERROR: 'title' field is required for action: create")
            sys.exit(1)
        args = ["issue", "create", "--title", title]
        if body:
            args.extend(["--body", body])
        labels = meta.get("labels", "")
        if labels:
            args.extend(["--label", labels])
        print(gh(*args))

    def close(self, meta: dict, body: str) -> None:
        issue = meta.get("issue")
        if not issue:
            print("ERROR: 'issue' field is required for action: close")
            sys.exit(1)
        if body:
            gh("issue", "comment", issue, "--body", body)
        gh("issue", "close", issue)
        print(f"Issue #{issue} closed.")


# ---------------------------------------------------------------------------
# GitLab backend (REST API, with optional Cloudflare Access)
# ---------------------------------------------------------------------------

class GitLabBackend:
    """Issue operations via the GitLab REST API."""

    name = "gitlab"

    def __init__(self, conf: dict[str, str]):
        self.base_url = conf.get("gitlab_url", "").rstrip("/")
        if not self.base_url:
            print("ERROR: gitlab_url not set in comms/collab_bus.conf")
            sys.exit(1)

        self.project_id = conf.get("gitlab_project_id", "")
        if not self.project_id:
            print("ERROR: gitlab_project_id not set in comms/collab_bus.conf")
            sys.exit(1)

        self.cf_app_url = conf.get("cf_app_url", "")
        self.token = self._load_token(conf)
        self.api = f"{self.base_url}/api/v4/projects/{self.project_id}"

    def _load_token(self, conf: dict[str, str]) -> str:
        """Load GitLab token from env var, optionally reading from a dotenv file first."""
        env_var = conf.get("gitlab_token_env", "GITLAB_HELPER_CLAUDE_TOKEN")

        # Check environment first
        token = os.environ.get(env_var, "")
        if token:
            return token

        # Fall back to reading from a dotenv file
        token_file = conf.get("gitlab_token_file", "")
        if token_file:
            p = Path(token_file)
            if p.exists():
                for line in p.read_text(encoding="utf-8").splitlines():
                    line = line.strip()
                    if line.startswith(f"{env_var}="):
                        token = line.split("=", 1)[1].strip()
                        if token:
                            return token

        print(f"ERROR: GitLab token not found. Set {env_var} in env or configure gitlab_token_file in collab_bus.conf")
        sys.exit(1)

    def _cf_cookie(self) -> str | None:
        """Get Cloudflare Access token if cf_app_url is configured."""
        if not self.cf_app_url:
            return None
        try:
            result = subprocess.run(
                ["cloudflared", "access", "token", f"--app={self.cf_app_url}"],
                capture_output=True, text=True,
            )
            if result.returncode == 0 and result.stdout.strip():
                return result.stdout.strip()
            # Token expired — try login
            print("Cloudflare Access token expired — opening browser to re-authenticate...", file=sys.stderr)
            subprocess.run(["cloudflared", "access", "login", self.cf_app_url], check=True)
            result = subprocess.run(
                ["cloudflared", "access", "token", f"--app={self.cf_app_url}"],
                capture_output=True, text=True, check=True,
            )
            return result.stdout.strip()
        except FileNotFoundError:
            print("WARNING: cloudflared not found — skipping Cloudflare Access auth", file=sys.stderr)
            return None

    @staticmethod
    def _ssl_context():
        """Build an SSL context that trusts the system/certifi CA bundle."""
        import ssl
        try:
            import certifi
            return ssl.create_default_context(cafile=certifi.where())
        except ImportError:
            pass
        ctx = ssl.create_default_context()
        if not ctx.get_ca_certs():
            ctx = ssl._create_unverified_context()
            print("WARNING: SSL certificate verification disabled (install certifi to fix)", file=sys.stderr)
        return ctx

    def _request(self, method: str, endpoint: str, data: dict | None = None) -> dict | list:
        """Make an authenticated GitLab API request."""
        import urllib.request
        import urllib.error

        url = f"{self.api}/{endpoint}"
        headers = {
            "PRIVATE-TOKEN": self.token,
            "Content-Type": "application/json",
            "User-Agent": "collab-bus/1.0",
        }

        cf_token = self._cf_cookie()
        if cf_token:
            headers["Cookie"] = f"CF_Authorization={cf_token}"

        body_bytes = json.dumps(data).encode() if data else None

        req = urllib.request.Request(url, data=body_bytes, headers=headers, method=method)
        try:
            with urllib.request.urlopen(req, timeout=30, context=self._ssl_context()) as resp:
                return json.loads(resp.read().decode())
        except urllib.error.HTTPError as e:
            error_body = e.read().decode() if e.fp else ""
            print(f"ERROR: GitLab API {method} {endpoint} → HTTP {e.code}")
            print(error_body)
            sys.exit(1)

    def _format_issue(self, issue: dict, comments: list[dict] | None = None) -> str:
        """Format a GitLab issue for human-readable display."""
        lines = [
            f"#{issue['iid']}  {issue['title']}",
            f"State: {issue['state']}  Labels: {', '.join(issue.get('labels', []))}",
            f"Author: {issue.get('author', {}).get('username', '?')}  "
            f"Created: {issue.get('created_at', '?')}",
            "",
            issue.get("description", "") or "(no description)",
        ]
        if comments is not None:
            lines.append(f"\n--- {len(comments)} comment(s) ---\n")
            for c in comments:
                author = c.get("author", {}).get("username", "unknown")
                lines.append(f"[{c.get('created_at', '')}] {author}:")
                lines.append(c.get("body", ""))
                lines.append("---")
        return "\n".join(lines)

    def view(self, meta: dict, _body: str) -> None:
        issue_iid = meta.get("issue")
        if not issue_iid:
            print("ERROR: 'issue' field is required for action: view")
            sys.exit(1)
        issue = self._request("GET", f"issues/{issue_iid}")
        comments = self._request("GET", f"issues/{issue_iid}/notes?per_page=100&sort=asc")
        # Filter out system notes
        comments = [c for c in comments if not c.get("system", False)]
        print(self._format_issue(issue, comments))

    def latest(self, meta: dict, _body: str) -> None:
        issue_iid = meta.get("issue")
        if not issue_iid:
            print("ERROR: 'issue' field is required for action: latest")
            sys.exit(1)
        count = int(meta.get("count", "1"))
        issue = self._request("GET", f"issues/{issue_iid}")
        comments = self._request("GET", f"issues/{issue_iid}/notes?per_page=100&sort=asc")
        comments = [c for c in comments if not c.get("system", False)]

        print(self._format_issue(issue))
        print(f"\n--- Last {count} comment(s) ---\n")
        if not comments:
            print("(no comments yet)")
            return

        for c in comments[-count:]:
            author = c.get("author", {}).get("username", "unknown")
            print(f"[{c.get('created_at', '')}] {author}:")
            print(c.get("body", ""))
            print("---")

    def list_issues(self, meta: dict, _body: str) -> None:
        label_filter = meta.get("labels", "")
        endpoint = "issues?state=opened&per_page=50&order_by=created_at&sort=asc"
        if label_filter:
            endpoint += f"&labels={urlquote(label_filter)}"
        issues = self._request("GET", endpoint)
        if not issues:
            print("No open issues found.")
            return
        for iss in issues:
            labels = ", ".join(iss.get("labels", []))
            print(f"#{iss['iid']}  {iss['title']}  [{labels}]")

    def comment(self, meta: dict, body: str) -> None:
        issue_iid = meta.get("issue")
        if not issue_iid:
            print("ERROR: 'issue' field is required for action: comment")
            sys.exit(1)
        if not body:
            print("ERROR: comment body is empty — write your message below the frontmatter")
            sys.exit(1)
        self._request("POST", f"issues/{issue_iid}/notes", {"body": body})
        print(f"Comment posted to issue #{issue_iid}")
        # Print current state for race-condition visibility
        print("\n--- Current issue state ---\n")
        issue = self._request("GET", f"issues/{issue_iid}")
        comments = self._request("GET", f"issues/{issue_iid}/notes?per_page=100&sort=asc")
        comments = [c for c in comments if not c.get("system", False)]
        print(self._format_issue(issue, comments))

    def create(self, meta: dict, body: str) -> None:
        title = meta.get("title")
        if not title:
            print("ERROR: 'title' field is required for action: create")
            sys.exit(1)
        data: dict = {"title": title}
        if body:
            data["description"] = body
        labels = meta.get("labels", "")
        if labels:
            data["labels"] = labels
        result = self._request("POST", "issues", data)
        print(f"Created issue #{result['iid']}: {result['title']}")
        print(f"URL: {result.get('web_url', 'N/A')}")

    def close(self, meta: dict, body: str) -> None:
        issue_iid = meta.get("issue")
        if not issue_iid:
            print("ERROR: 'issue' field is required for action: close")
            sys.exit(1)
        if body:
            self._request("POST", f"issues/{issue_iid}/notes", {"body": body})
        self._request("PUT", f"issues/{issue_iid}", {"state_event": "close"})
        print(f"Issue #{issue_iid} closed.")


# ---------------------------------------------------------------------------
# Backend registry & dispatch
# ---------------------------------------------------------------------------

ACTIONS = ["view", "latest", "list", "comment", "create", "close"]


def get_backend(name: str, conf: dict[str, str]) -> GitHubBackend | GitLabBackend:
    """Instantiate the requested backend."""
    if name == "github":
        return GitHubBackend()
    elif name == "gitlab":
        return GitLabBackend(conf)
    else:
        print(f"ERROR: Unknown backend '{name}'. Valid: github, gitlab")
        sys.exit(1)


def dispatch(backend: GitHubBackend | GitLabBackend, action: str, meta: dict, body: str) -> None:
    """Route the action to the correct backend method."""
    method_map = {
        "view": backend.view,
        "latest": backend.latest,
        "list": backend.list_issues,
        "comment": backend.comment,
        "create": backend.create,
        "close": backend.close,
    }
    method_map[action](meta, body)


def main() -> None:
    parser = argparse.ArgumentParser(description="Collab Bus Transport (GitHub & GitLab Issues)")
    parser.add_argument("--file", type=Path, default=DEFAULT_OUTBOUND,
                        help="Path to outbound.md (default: tmp/outbound.md)")
    parser.add_argument("--dry-run", action="store_true",
                        help="Parse and display the action without executing")
    parser.add_argument("--backend", choices=["github", "gitlab"],
                        help="Override the backend (default: from conf or github)")
    parser.add_argument("--conf", type=Path, default=DEFAULT_CONF,
                        help="Path to collab_bus.conf (default: comms/collab_bus.conf)")
    args = parser.parse_args()

    if not args.file.exists():
        print(f"ERROR: {args.file} not found. Run 'agency collab-bus' to scaffold.")
        sys.exit(1)

    conf = load_conf(args.conf)
    meta, body = parse_outbound(args.file)
    action = meta.get("action", "").lower()

    if action not in ACTIONS:
        print(f"ERROR: Unknown action '{action}'. Valid: {', '.join(ACTIONS)}")
        sys.exit(1)

    # Backend priority: CLI flag > frontmatter > conf file > default (github)
    backend_name = args.backend or meta.get("backend") or conf.get("backend", "github")

    if args.dry_run:
        print(f"[DRY RUN] backend={backend_name} action={action} meta={meta}")
        print(f"[DRY RUN] body={body[:200]}{'...' if len(body) > 200 else ''}")
        return

    backend = get_backend(backend_name, conf)
    dispatch(backend, action, meta, body)

    # Reset outbound.md to template for next use
    args.file.write_text(TEMPLATE, encoding="utf-8")
    print(f"\n{args.file} reset for next message.")


if __name__ == "__main__":
    main()
