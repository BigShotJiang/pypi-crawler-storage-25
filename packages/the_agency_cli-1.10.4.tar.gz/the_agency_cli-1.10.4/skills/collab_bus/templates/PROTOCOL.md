# Multi-Agent Collaboration Protocol

This document defines the communication protocol for multi-agent collaboration
via Issues (GitHub or GitLab) as a shared persistent message bus. Any agent
joining this project should read this file before participating.

## How It Works

Issues serve as the shared bus. Agents do not communicate directly —
they read and write issue comments independently, on their own schedule.
A human operator can observe, redirect, or intervene at any point.

### Message Flow

```
Agent writes tmp/outbound.md
    |
    v
python tmp/post_outbound.py    (or `py tmp/post_outbound.py` on Windows)
    |
    v
Issue comment posted            (with signed authorship + status packet)
    |
    v
Next agent reads the thread     (via 'latest' or 'view' action)
```

### Backend Configuration

The transport supports two backends, configured in `comms/collab_bus.conf`:

| Backend | Platform | Requirement |
|---------|----------|-------------|
| `github` | GitHub Issues | `gh` CLI installed and authenticated |
| `gitlab` | GitLab Issues | GitLab API token + optional Cloudflare Access |

**GitHub** (default):
```
backend: github
```

**GitLab**:
```
backend: gitlab
gitlab_url: https://gitlab.example.com
gitlab_project_id: 1
gitlab_token_env: GITLAB_HELPER_CLAUDE_TOKEN
gitlab_token_file: functions/.env.local
cf_app_url: https://gitlab.example.com
```

You can override per-message with `backend: gitlab` in the outbound.md
frontmatter, or via `--backend gitlab` on the command line.

## Signed Authorship

Every comment MUST begin with an authorship line:

```
**Author:** <AgentName> (via @<human-username>)
```

This ensures the thread is auditable even though all writes go through
one account. Example:

```
**Author:** Claude (via @flegare)

Here is my analysis of the auth middleware...
```

## Issue Taxonomy

Use these prefixes in issue titles:

| Prefix | Meaning | Example |
|---|---|---|
| `[DEC]` | Decision or rule of engagement | `[DEC] Rules of engagement` |
| `[EXP-NNN]` | Experiment with ladder stages | `[EXP-001] Refactor auth middleware` |
| `[idea]` | Parked seed, not yet promoted | `[idea] Switch to WebSocket bus` |

### Experiment Ladder Stages

- **Stage A** — Hypothesis defined, not yet started
- **Stage B** — Implementation in progress
- **Stage C** — Testing / validation
- **Stage D** — Complete, results documented

## Status Packets

Every comment that represents a handoff MUST end with:

1. A **human-readable summary** under a `### Handoff` heading
2. A **JSON status packet** for machine parsing

### Format

```
### Handoff
<Plain-language summary of what was done and what comes next.>
<Any blockers or dependencies in plain English.>

{"speaker":"<AgentName>","next_owner":"<AgentName|human>","next_action":"<what the next agent should do>","blocking":false,"waiting_on":null}
```

### Fields

| Field | Type | Description |
|---|---|---|
| `speaker` | string | Name of the agent posting this comment |
| `next_owner` | string | Who should act next (agent name or "human") |
| `next_action` | string | Concrete description of the next task |
| `blocking` | boolean | True if this agent cannot proceed without input |
| `waiting_on` | string or null | What/who is blocking (null if not blocked) |

### Example

```
**Author:** GPT (via @flegare)

Refactored the session store to use encrypted tokens. See commit abc123.

### Handoff
Done with session store refactor. Claude should write integration tests
for the /v2/auth endpoints using the new token format.
No blockers.

{"speaker":"GPT","next_owner":"Claude","next_action":"Write integration tests for /v2/auth token changes","blocking":false,"waiting_on":null}
```

## Using outbound.md

To send a message, edit `tmp/outbound.md` with your action and body,
then run `python tmp/post_outbound.py` (or `py tmp/post_outbound.py` on Windows).

### Available Actions

| Action | Required Fields | Description |
|---|---|---|
| `view` | `issue` | Fetch full issue thread |
| `latest` | `issue`, `count` (optional, default 1) | Fetch last N comments + header |
| `list` | `labels` (optional) | List open issues |
| `comment` | `issue` | Post a comment (body below frontmatter) |
| `create` | `title`, `labels` (optional) | Create a new issue |
| `close` | `issue` | Close an issue (optional farewell comment in body) |

### Example: Posting a comment

```yaml
---
action: comment
issue: 12
---
**Author:** Claude (via @flegare)

Completed the database migration. All tests passing.

### Handoff
Migration complete. GPT should update the API documentation for the new schema.
No blockers.

{"speaker":"Claude","next_owner":"GPT","next_action":"Update API docs for new schema","blocking":false,"waiting_on":null}
```

Then run: `python tmp/post_outbound.py`

## Filesystem Watchers (Optional)

When all agents run on the same machine, you can use `tmp/watch_bus.sh`
to automatically detect when a new comment is posted and trigger the
next agent. This avoids polling and saves tokens.

See `tmp/watch_bus.sh` for setup instructions.

## Quick Onboarding for New Agents

If you are an AI agent joining this project for the first time:

1. Read this file (`comms/PROTOCOL.md`)
2. Use `action: list` to see open workstreams
3. Use `action: latest` on the issue assigned to you to get context
4. Always sign your comments with the authorship line
5. Always end handoff comments with a human-readable summary + JSON status packet
6. Run `python tmp/post_outbound.py` (or `py tmp/post_outbound.py` on Windows) to send your message
