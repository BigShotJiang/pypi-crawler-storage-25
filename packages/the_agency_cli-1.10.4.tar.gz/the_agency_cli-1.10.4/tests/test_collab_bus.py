"""Tests for collab-bus scaffolding helpers and transport edge cases."""

from __future__ import annotations

import importlib.util
import json
from pathlib import Path
from unittest.mock import patch, MagicMock

import agency


def _load_post_outbound_module():
    script_path = Path(__file__).resolve().parents[1] / "skills" / "collab_bus" / "templates" / "post_outbound.py"
    spec = importlib.util.spec_from_file_location("collab_bus_post_outbound", script_path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


post_outbound = _load_post_outbound_module()


class TestCollabBusPlatformHelpers:
    def test_windows_defaults_use_py_and_powershell(self, monkeypatch):
        monkeypatch.setattr(agency.sys, "platform", "win32")

        assert agency._collab_bus_python_command() == "py"
        assert agency._collab_bus_supports_shell_watcher() is False
        assert agency._collab_bus_permission_entries() == [
            "PowerShell(py tmp/post_outbound.py*)",
            "PowerShell(python tmp/post_outbound.py*)",
        ]

    def test_unix_defaults_use_python3_and_bash(self, monkeypatch):
        monkeypatch.setattr(agency.sys, "platform", "linux")

        assert agency._collab_bus_python_command() == "python3"
        assert agency._collab_bus_supports_shell_watcher() is True
        assert agency._collab_bus_permission_entries() == [
            "Bash(python3 tmp/post_outbound.py*)"
        ]


class TestParseCommentPages:
    def test_returns_empty_list_for_empty_issue(self):
        assert post_outbound.parse_comment_pages("[]\n") == []

    def test_flattens_paginated_comment_arrays(self):
        raw = '[{"id": 1, "body": "first"}]\n[{"id": 2, "body": "second"}]\n'

        comments = post_outbound.parse_comment_pages(raw)

        assert [comment["id"] for comment in comments] == [1, 2]


class TestActionLatest:
    def test_handles_threads_with_no_comments(self, capsys):
        github = post_outbound.GitHubBackend()
        with patch.object(post_outbound, "gh", side_effect=["issue header", "[]\n"]):
            github.latest({"issue": "12"}, "")

        out = capsys.readouterr().out
        assert "issue header" in out
        assert "(no comments yet)" in out


class TestLoadConf:
    def test_returns_empty_for_missing_file(self, tmp_path):
        assert post_outbound.load_conf(tmp_path / "nope.conf") == {}

    def test_parses_key_value_conf(self, tmp_path):
        conf_file = tmp_path / "test.conf"
        conf_file.write_text("backend: gitlab\ngitlab_url: https://gl.example.com\n# comment\n")
        result = post_outbound.load_conf(conf_file)
        assert result["backend"] == "gitlab"
        assert result["gitlab_url"] == "https://gl.example.com"

    def test_skips_comments_and_blanks(self, tmp_path):
        conf_file = tmp_path / "test.conf"
        conf_file.write_text("# this is a comment\n\nbackend: github\n")
        result = post_outbound.load_conf(conf_file)
        assert result == {"backend": "github"}


class TestGetBackend:
    def test_github_backend(self):
        backend = post_outbound.get_backend("github", {})
        assert isinstance(backend, post_outbound.GitHubBackend)

    def test_gitlab_backend(self, monkeypatch):
        monkeypatch.setenv("TEST_GL_TOKEN", "glpat-fake")
        conf = {
            "gitlab_url": "https://gl.example.com",
            "gitlab_project_id": "1",
            "gitlab_token_env": "TEST_GL_TOKEN",
        }
        backend = post_outbound.get_backend("gitlab", conf)
        assert isinstance(backend, post_outbound.GitLabBackend)
        assert backend.base_url == "https://gl.example.com"
        assert backend.project_id == "1"

    def test_unknown_backend_exits(self):
        import pytest
        with pytest.raises(SystemExit):
            post_outbound.get_backend("bitbucket", {})


class TestGitLabBackendTokenLoading:
    def test_loads_from_env(self, monkeypatch):
        monkeypatch.setenv("MY_TOKEN", "glpat-123")
        conf = {
            "gitlab_url": "https://gl.example.com",
            "gitlab_project_id": "1",
            "gitlab_token_env": "MY_TOKEN",
        }
        backend = post_outbound.GitLabBackend(conf)
        assert backend.token == "glpat-123"

    def test_loads_from_dotenv_file(self, tmp_path, monkeypatch):
        # Make sure the env var is NOT set
        monkeypatch.delenv("MY_GL_TOKEN", raising=False)
        dotenv = tmp_path / ".env.local"
        dotenv.write_text("OTHER=stuff\nMY_GL_TOKEN=glpat-from-file\n")
        conf = {
            "gitlab_url": "https://gl.example.com",
            "gitlab_project_id": "1",
            "gitlab_token_env": "MY_GL_TOKEN",
            "gitlab_token_file": str(dotenv),
        }
        backend = post_outbound.GitLabBackend(conf)
        assert backend.token == "glpat-from-file"

    def test_exits_if_no_token_found(self, monkeypatch):
        import pytest
        monkeypatch.delenv("MISSING_TOKEN", raising=False)
        conf = {
            "gitlab_url": "https://gl.example.com",
            "gitlab_project_id": "1",
            "gitlab_token_env": "MISSING_TOKEN",
        }
        with pytest.raises(SystemExit):
            post_outbound.GitLabBackend(conf)


class TestGitLabBackendFormat:
    def test_format_issue_basic(self, monkeypatch):
        monkeypatch.setenv("GL_TOK", "fake")
        conf = {
            "gitlab_url": "https://gl.example.com",
            "gitlab_project_id": "1",
            "gitlab_token_env": "GL_TOK",
        }
        backend = post_outbound.GitLabBackend(conf)
        issue = {
            "iid": 5,
            "title": "Test issue",
            "state": "opened",
            "labels": ["bug", "urgent"],
            "author": {"username": "bot"},
            "created_at": "2026-01-01T00:00:00Z",
            "description": "Some description",
        }
        output = backend._format_issue(issue)
        assert "#5" in output
        assert "Test issue" in output
        assert "bug, urgent" in output

    def test_format_issue_with_comments(self, monkeypatch):
        monkeypatch.setenv("GL_TOK", "fake")
        conf = {
            "gitlab_url": "https://gl.example.com",
            "gitlab_project_id": "1",
            "gitlab_token_env": "GL_TOK",
        }
        backend = post_outbound.GitLabBackend(conf)
        issue = {
            "iid": 1, "title": "T", "state": "opened", "labels": [],
            "author": {"username": "x"}, "created_at": "", "description": "",
        }
        comments = [
            {"author": {"username": "agent1"}, "created_at": "2026-01-01", "body": "hello"},
        ]
        output = backend._format_issue(issue, comments)
        assert "1 comment(s)" in output
        assert "agent1" in output
        assert "hello" in output


class TestParseOutbound:
    def test_parses_frontmatter_and_body(self, tmp_path):
        f = tmp_path / "out.md"
        f.write_text("---\naction: comment\nissue: 5\nbackend: gitlab\n---\n\nHello world\n")
        meta, body = post_outbound.parse_outbound(f)
        assert meta["action"] == "comment"
        assert meta["issue"] == "5"
        assert meta["backend"] == "gitlab"
        assert body == "Hello world"
