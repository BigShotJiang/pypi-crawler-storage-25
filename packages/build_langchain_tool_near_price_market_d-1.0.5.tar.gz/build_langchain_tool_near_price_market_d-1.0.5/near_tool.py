"""
LangChain tools for NEAR Protocol.
Generated for: Build LangChain Tool: NEAR Price & Market Data
"""
import requests
import json
import base64
from typing import Optional, Type, Any, List, Dict, Union, Tuple, Set, Callable
from pydantic import BaseModel, Field

try:
    from langchain.tools import BaseTool
except ImportError:
    from langchain_core.tools import BaseTool  # langchain v0.2+

NEAR_RPC_MAINNET = "https://rpc.mainnet.near.org"
NEAR_RPC_TESTNET = "https://rpc.testnet.near.org"


def _near_rpc(method: str, params: Any, network: str = "mainnet") -> dict:
    """Execute NEAR JSON-RPC call."""
    url = NEAR_RPC_MAINNET if network == "mainnet" else NEAR_RPC_TESTNET
    resp = requests.post(url, json={"jsonrpc":"2.0","id":"1","method":method,"params":params}, timeout=10)
    resp.raise_for_status()
    data = resp.json()
    if "error" in data:
        raise RuntimeError(f"NEAR RPC error: {data['error']}")
    return data.get("result", {})


class NEARAccountInput(BaseModel):
    account_id: str = Field(description="NEAR account ID (e.g. example.near)")
    network: str = Field(default="mainnet", description="mainnet or testnet")


class NEARAccountTool(BaseTool):
    """Query NEAR account balance and storage info."""
    name: str = "near_account_info"
    description: str = "Get NEAR account balance and info. Input: account_id, network (optional)"
    args_schema: Type[BaseModel] = NEARAccountInput

    def _run(self, account_id: str, network: str = "mainnet") -> str:
        result = _near_rpc("query", {
            "request_type": "view_account", "finality": "final", "account_id": account_id
        }, network)
        near = int(result.get("amount", 0)) / 10**24
        return json.dumps({"account_id": account_id, "balance_near": f"{near:.4f}",
            "storage_bytes": result.get("storage_usage", 0)})

    async def _arun(self, account_id: str, network: str = "mainnet") -> str:
        return self._run(account_id, network)


class NEARViewFunctionInput(BaseModel):
    contract_id: str = Field(description="NEAR contract ID")
    method_name: str = Field(description="View method name")
    args: dict = Field(default={}, description="Method arguments")
    network: str = Field(default="mainnet", description="mainnet or testnet")


class NEARViewFunctionTool(BaseTool):
    """Call a view function on a NEAR smart contract."""
    name: str = "near_view_function"
    description: str = "Call a NEAR contract view function. Input: contract_id, method_name, args"
    args_schema: Type[BaseModel] = NEARViewFunctionInput

    def _run(self, contract_id: str, method_name: str, args: dict = {}, network: str = "mainnet") -> str:
        args_b64 = base64.b64encode(json.dumps(args).encode()).decode()
        result = _near_rpc("query", {
            "request_type": "call_function", "finality": "final",
            "account_id": contract_id, "method_name": method_name, "args_base64": args_b64
        }, network)
        decoded = json.loads(bytes(result["result"]).decode())
        return json.dumps(decoded, indent=2)

    async def _arun(self, contract_id: str, method_name: str, args: dict = {}, network: str = "mainnet") -> str:
        return self._run(contract_id, method_name, args, network)


class NEARPriceInput(BaseModel):
    tokens: Optional[List[str]] = Field(
        default=["near"],
        description="List of token ids to fetch price data for (e.g. ['near', 'ref-finance'])"
    )
    include_history: Optional[bool] = Field(
        default=False,
        description="Whether to include 7-day historical price data"
    )
    currency: Optional[str] = Field(
        default="usd",
        description="Target currency for price data (e.g. 'usd', 'eur')"
    )

class NEARPriceMarketTool(BaseTool):
    name: str = "near_price_market_data"
    description: str = (
        "Fetches real-time NEAR and NEAR ecosystem token price, market cap, volume, "
        "and optionally 7-day historical price data from CoinGecko. "
        "Use this to get current market data for NEAR or ecosystem tokens."
    )
    args_schema: Type[BaseModel] = NEARPriceInput
    _cache: Dict[str, Any] = {}
    _cache_ts: Dict[str, float] = {}
    _cache_ttl: float = 60.0

    def _fetch_prices(self, tokens: List[str], currency: str, include_history: bool) -> Dict[str, Any]:
        import time
        cache_key = f"{','.join(sorted(tokens))}:{currency}:{include_history}"
        now = time.time()
        if cache_key in self._cache and (now - self._cache_ts.get(cache_key, 0)) < self._cache_ttl:
            return self._cache[cache_key]

        ids = ",".join(tokens)
        url = (
            f"https://api.coingecko.com/api/v3/coins/markets"
            f"?vs_currency={currency}&ids={ids}&price_change_percentage=24h,7d"
        )
        resp = requests.get(url, timeout=10)
        resp.raise_for_status()
        data = resp.json()

        result: Dict[str, Any] = {}
        for coin in data:
            entry: Dict[str, Any] = {
                "symbol": coin.get("symbol", "").upper(),
                "name": coin.get("name"),
                "price": coin.get("current_price"),
                "market_cap": coin.get("market_cap"),
                "volume_24h": coin.get("total_volume"),
                "change_24h_pct": coin.get("price_change_percentage_24h"),
                "change_7d_pct": coin.get("price_change_percentage_7d_in_currency"),
                "ath": coin.get("ath"),
                "atl": coin.get("atl"),
                "circulating_supply": coin.get("circulating_supply"),
                "currency": currency.upper(),
            }
            if include_history:
                hist_url = (
                    f"https://api.coingecko.com/api/v3/coins/{coin['id']}/market_chart"
                    f"?vs_currency={currency}&days=7&interval=daily"
                )
                hr = requests.get(hist_url, timeout=10)
                if hr.ok:
                    prices = hr.json().get("prices", [])
                    entry["history_7d"] = [
                        {"timestamp": p[0], "price": p[1]} for p in prices
                    ]
            result[coin["id"]] = entry

        self._cache[cache_key] = result
        self._cache_ts[cache_key] = now
        return result

    def _run(self, tokens: Optional[List[str]] = None, include_history: bool = False, currency: str = "usd") -> str:
        if not tokens:
            tokens = ["near"]
        try:
            data = self._fetch_prices(tokens, currency, include_history)
            if not data:
                return f"No price data found for tokens: {tokens}"
            lines = []
            for tid, info in data.items():
                lines.append(
                    f"{info['name']} ({info['symbol']}): "
                    f"{info['price']} {info['currency']} | "
                    f"MCap: {info['market_cap']} | Vol 24h: {info['volume_24h']} | "
                    f"Δ24h: {info['change_24h_pct']:.2f}% | Δ7d: {info.get('change_7d_pct', 'N/A')}%"
                )
                if include_history and "history_7d" in info:
                    hist = info["history_7d"]
                    lines.append(f"  7d history ({len(hist)} pts): start={hist[0]['price']:.4f}, end={hist[-1]['price']:.4f}")
            return "\n".join(lines)
        except Exception as e:
            return f"Error fetching price data: {e}"

    async def _arun(self, tokens: Optional[List[str]] = None, include_history: bool = False, currency: str = "usd") -> str:
        return self._run(tokens=tokens, include_history=include_history, currency=currency)


class NEARPriceAlertInput(BaseModel):
    token: Optional[str] = Field(default="near", description="Token id to check (e.g. 'near')")
    threshold_high: Optional[float] = Field(default=None, description="Alert if price exceeds this value (USD)")
    threshold_low: Optional[float] = Field(default=None, description="Alert if price drops below this value (USD)")
    currency: Optional[str] = Field(default="usd", description="Currency for threshold comparison")

class NEARPriceAlertTool(BaseTool):
    name: str = "near_price_alert"
    description: str = (
        "Checks if the current NEAR or ecosystem token price crosses specified high/low thresholds. "
        "Returns an alert message if the price is above threshold_high or below threshold_low."
    )
    args_schema: Type[BaseModel] = NEARPriceAlertInput

    def _get_current_price(self, token: str, currency: str) -> float:
        url = (
            f"https://api.coingecko.com/api/v3/simple/price"
            f"?ids={token}&vs_currencies={currency}"
        )
        resp = requests.get(url, timeout=10)
        resp.raise_for_status()
        data = resp.json()
        return data.get(token, {}).get(currency, 0.0)

    def _run(self, token: str = "near", threshold_high: Optional[float] = None,
             threshold_low: Optional[float] = None, currency: str = "usd") -> str:
        try:
            price = self._get_current_price(token, currency)
            alerts = []
            if threshold_high is not None and price >= threshold_high:
                alerts.append(f"🚨 ALERT: {token.upper()} price {price} {currency.upper()} is ABOVE high threshold {threshold_high}")
            if threshold_low is not None and price <= threshold_low:
                alerts.append(f"🚨 ALERT: {token.upper()} price {price} {currency.upper()} is BELOW low threshold {threshold_low}")
            if not alerts:
                parts = []
                if threshold_high is not None:
                    parts.append(f"below high {threshold_high}")
                if threshold_low is not None:
                    parts.append(f"above low {threshold_low}")
                status = " and ".join(parts) if parts else "no thresholds set"
                return f"✅ {token.upper()} at {price} {currency.upper()} — within range ({status})"
            return "\n".join(alerts)
        except Exception as e:
            return f"Error checking price alert: {e}"

    async def _arun(self, token: str = "near", threshold_high: Optional[float] = None,
                    threshold_low: Optional[float] = None, currency: str = "usd") -> str:
        return self._run(token=token, threshold_high=threshold_high, threshold_low=threshold_low, currency=currency)