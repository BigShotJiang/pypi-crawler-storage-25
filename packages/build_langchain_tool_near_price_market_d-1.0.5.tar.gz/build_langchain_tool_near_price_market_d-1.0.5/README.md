# Build LangChain Tool: NEAR Price & Market Data

## Overview
Create a LangChain tool that provides real-time NEAR price data, market metrics, and historical trends for agent applications.

## Why This Matters
Agents need market data to make informed

## Install

```bash
pip install -r requirements.txt
```

## Tools

- `NEARAccountTool` — see near_tool.py
- `NEARViewFunctionTool` — see near_tool.py
- `NEARPriceMarketTool` — see near_tool.py
- `NEARPriceAlertTool` — see near_tool.py

## Usage

```python
from near_tool import NEARAccountTool, NEARViewFunctionTool, NEARPriceMarketTool, NEARPriceAlertTool

tool = NEARAccountTool()
result = tool._run(account_id='example.near')
print(result)
```
