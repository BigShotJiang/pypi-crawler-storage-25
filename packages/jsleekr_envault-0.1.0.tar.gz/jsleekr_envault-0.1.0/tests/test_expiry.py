"""Tests for envault.expiry module."""

import time

import pytest

from envault.expiry import ExpiryManager, ExpiryPolicy


class TestExpiryPolicy:
    def test_not_expired(self):
        p = ExpiryPolicy("KEY", "dev", time.time() + 30 * 86400)
        assert p.is_expired is False
        assert p.status == "ok"

    def test_expired(self):
        p = ExpiryPolicy("KEY", "dev", time.time() - 100)
        assert p.is_expired is True
        assert p.status == "expired"

    def test_warning(self):
        # Expires in 3 days, warn_days=7
        p = ExpiryPolicy("KEY", "dev", time.time() + 3 * 86400, warn_days=7)
        assert p.is_warning is True
        assert p.status == "warning"

    def test_not_warning(self):
        # Expires in 30 days, warn_days=7
        p = ExpiryPolicy("KEY", "dev", time.time() + 30 * 86400, warn_days=7)
        assert p.is_warning is False

    def test_days_until_expiry(self):
        p = ExpiryPolicy("KEY", "dev", time.time() + 10 * 86400)
        assert 9.9 < p.days_until_expiry < 10.1

    def test_to_dict_from_dict(self):
        p = ExpiryPolicy("KEY", "dev", 1000.0, warn_days=14, auto_rotate=True, notes="rotate monthly")
        d = p.to_dict()
        r = ExpiryPolicy.from_dict(d)
        assert r.variable == "KEY"
        assert r.environment == "dev"
        assert r.warn_days == 14
        assert r.auto_rotate is True
        assert r.notes == "rotate monthly"


class TestExpiryManager:
    @pytest.fixture
    def mgr(self):
        return ExpiryManager()

    def test_set_expiry(self, mgr):
        p = mgr.set_expiry("KEY", "dev", time.time() + 86400)
        assert p.variable == "KEY"
        assert len(mgr) == 1

    def test_set_ttl(self, mgr):
        p = mgr.set_ttl("KEY", "dev", 30)
        assert p.days_until_expiry > 29

    def test_get_policy(self, mgr):
        mgr.set_expiry("KEY", "dev", time.time() + 86400)
        p = mgr.get_policy("KEY", "dev")
        assert p is not None
        assert p.variable == "KEY"

    def test_get_policy_none(self, mgr):
        assert mgr.get_policy("NOPE", "dev") is None

    def test_remove_policy(self, mgr):
        mgr.set_expiry("KEY", "dev", time.time())
        assert mgr.remove_policy("KEY", "dev") is True
        assert len(mgr) == 0

    def test_remove_nonexistent(self, mgr):
        assert mgr.remove_policy("NOPE", "dev") is False

    def test_get_expired(self, mgr):
        mgr.set_expiry("OLD", "dev", time.time() - 100)
        mgr.set_expiry("NEW", "dev", time.time() + 86400 * 30)
        expired = mgr.get_expired()
        assert len(expired) == 1
        assert expired[0].variable == "OLD"

    def test_get_warning(self, mgr):
        mgr.set_expiry("SOON", "dev", time.time() + 3 * 86400, warn_days=7)
        mgr.set_expiry("FAR", "dev", time.time() + 30 * 86400, warn_days=7)
        mgr.set_expiry("PAST", "dev", time.time() - 100)
        warnings = mgr.get_warning()
        assert len(warnings) == 1
        assert warnings[0].variable == "SOON"

    def test_get_ok(self, mgr):
        mgr.set_expiry("OK", "dev", time.time() + 30 * 86400)
        mgr.set_expiry("EXPIRED", "dev", time.time() - 100)
        ok = mgr.get_ok()
        assert len(ok) == 1

    def test_get_by_environment(self, mgr):
        mgr.set_expiry("A", "dev", time.time() + 86400)
        mgr.set_expiry("B", "prod", time.time() + 86400)
        dev = mgr.get_by_environment("dev")
        assert len(dev) == 1
        assert dev[0].variable == "A"

    def test_get_auto_rotate(self, mgr):
        mgr.set_expiry("AUTO", "dev", time.time(), auto_rotate=True)
        mgr.set_expiry("MANUAL", "dev", time.time(), auto_rotate=False)
        auto = mgr.get_auto_rotate()
        assert len(auto) == 1
        assert auto[0].variable == "AUTO"

    def test_summary(self, mgr):
        mgr.set_expiry("EXPIRED", "dev", time.time() - 100)
        mgr.set_expiry("WARNING", "dev", time.time() + 3 * 86400, warn_days=7)
        mgr.set_expiry("OK", "dev", time.time() + 30 * 86400)
        s = mgr.summary()
        assert s["total"] == 3
        assert s["expired"] == 1
        assert s["warning"] == 1
        assert s["ok"] == 1

    def test_to_list_from_list(self, mgr):
        mgr.set_expiry("A", "dev", 1000.0)
        mgr.set_expiry("B", "prod", 2000.0, auto_rotate=True)
        data = mgr.to_list()
        restored = ExpiryManager.from_list(data)
        assert len(restored) == 2
        assert restored.get_policy("B", "prod").auto_rotate is True

    def test_update_existing(self, mgr):
        mgr.set_expiry("KEY", "dev", 1000.0)
        mgr.set_expiry("KEY", "dev", 2000.0)
        assert len(mgr) == 1
        assert mgr.get_policy("KEY", "dev").expires_at == 2000.0
