"""Tests for envault.access module."""

import pytest

from envault.access import (
    AccessControl,
    AccessDeniedError,
    AccessEntry,
    Permission,
    Role,
    ROLE_PERMISSIONS,
)


class TestRole:
    def test_admin_has_all_permissions(self):
        admin_perms = ROLE_PERMISSIONS[Role.ADMIN]
        for p in Permission:
            assert p in admin_perms

    def test_editor_has_no_admin(self):
        editor_perms = ROLE_PERMISSIONS[Role.EDITOR]
        assert Permission.ADMIN not in editor_perms

    def test_viewer_only_read_export(self):
        viewer_perms = ROLE_PERMISSIONS[Role.VIEWER]
        assert Permission.READ in viewer_perms
        assert Permission.EXPORT in viewer_perms
        assert Permission.WRITE not in viewer_perms
        assert Permission.DELETE not in viewer_perms


class TestAccessEntry:
    def test_create(self):
        entry = AccessEntry(identity="alice", role=Role.ADMIN)
        assert entry.identity == "alice"
        assert entry.role == Role.ADMIN
        assert entry.environments is None
        assert entry.variables is None

    def test_with_restrictions(self):
        entry = AccessEntry(
            identity="bob",
            role=Role.EDITOR,
            environments=["dev", "staging"],
            variables=["API_KEY"],
        )
        assert entry.environments == ["dev", "staging"]
        assert entry.variables == ["API_KEY"]

    def test_to_dict(self):
        entry = AccessEntry("alice", Role.ADMIN)
        d = entry.to_dict()
        assert d["identity"] == "alice"
        assert d["role"] == "admin"

    def test_from_dict(self):
        d = {"identity": "bob", "role": "editor", "environments": ["dev"]}
        entry = AccessEntry.from_dict(d)
        assert entry.identity == "bob"
        assert entry.role == Role.EDITOR
        assert entry.environments == ["dev"]

    def test_roundtrip(self):
        original = AccessEntry("alice", Role.VIEWER, ["prod"], ["SECRET"])
        restored = AccessEntry.from_dict(original.to_dict())
        assert restored.identity == original.identity
        assert restored.role == original.role
        assert restored.environments == original.environments
        assert restored.variables == original.variables


class TestAccessControl:
    @pytest.fixture
    def ac(self):
        return AccessControl()

    def test_add_entry(self, ac):
        ac.add_entry(AccessEntry("alice", Role.ADMIN))
        assert len(ac) == 1

    def test_remove_entry(self, ac):
        ac.add_entry(AccessEntry("alice", Role.ADMIN))
        assert ac.remove_entry("alice") is True
        assert len(ac) == 0

    def test_remove_nonexistent(self, ac):
        assert ac.remove_entry("nobody") is False

    def test_get_entry(self, ac):
        ac.add_entry(AccessEntry("alice", Role.ADMIN))
        entry = ac.get_entry("alice")
        assert entry is not None
        assert entry.role == Role.ADMIN

    def test_get_entry_nonexistent(self, ac):
        assert ac.get_entry("nobody") is None

    def test_list_entries(self, ac):
        ac.add_entry(AccessEntry("bob", Role.EDITOR))
        ac.add_entry(AccessEntry("alice", Role.ADMIN))
        entries = ac.list_entries()
        assert len(entries) == 2
        assert entries[0].identity == "alice"  # sorted

    def test_has_permission_admin(self, ac):
        ac.add_entry(AccessEntry("alice", Role.ADMIN))
        assert ac.has_permission("alice", Permission.READ) is True
        assert ac.has_permission("alice", Permission.ADMIN) is True

    def test_has_permission_viewer(self, ac):
        ac.add_entry(AccessEntry("bob", Role.VIEWER))
        assert ac.has_permission("bob", Permission.READ) is True
        assert ac.has_permission("bob", Permission.WRITE) is False

    def test_has_permission_unknown_identity(self, ac):
        assert ac.has_permission("nobody", Permission.READ) is False

    def test_environment_restriction(self, ac):
        ac.add_entry(AccessEntry("bob", Role.EDITOR, environments=["dev"]))
        assert ac.has_permission("bob", Permission.READ, environment="dev") is True
        assert ac.has_permission("bob", Permission.READ, environment="prod") is False

    def test_variable_restriction(self, ac):
        ac.add_entry(AccessEntry("bob", Role.EDITOR, variables=["API_KEY"]))
        assert ac.has_permission("bob", Permission.READ, variable="API_KEY") is True
        assert ac.has_permission("bob", Permission.READ, variable="SECRET") is False

    def test_no_restriction_allows_all(self, ac):
        ac.add_entry(AccessEntry("alice", Role.EDITOR))
        assert ac.has_permission("alice", Permission.READ, environment="any") is True
        assert ac.has_permission("alice", Permission.READ, variable="any") is True

    def test_check_permission_passes(self, ac):
        ac.add_entry(AccessEntry("alice", Role.ADMIN))
        ac.check_permission("alice", Permission.READ)  # Should not raise

    def test_check_permission_denied(self, ac):
        ac.add_entry(AccessEntry("bob", Role.VIEWER))
        with pytest.raises(AccessDeniedError):
            ac.check_permission("bob", Permission.WRITE)

    def test_check_permission_unknown(self, ac):
        with pytest.raises(AccessDeniedError):
            ac.check_permission("nobody", Permission.READ)

    def test_get_allowed_environments(self, ac):
        ac.add_entry(AccessEntry("bob", Role.EDITOR, environments=["dev", "staging"]))
        assert ac.get_allowed_environments("bob") == ["dev", "staging"]

    def test_get_allowed_environments_all(self, ac):
        ac.add_entry(AccessEntry("alice", Role.ADMIN))
        assert ac.get_allowed_environments("alice") is None

    def test_get_allowed_environments_unknown(self, ac):
        assert ac.get_allowed_environments("nobody") == []

    def test_get_role(self, ac):
        ac.add_entry(AccessEntry("alice", Role.ADMIN))
        assert ac.get_role("alice") == Role.ADMIN

    def test_get_role_unknown(self, ac):
        assert ac.get_role("nobody") is None

    def test_update_entry(self, ac):
        ac.add_entry(AccessEntry("alice", Role.VIEWER))
        ac.add_entry(AccessEntry("alice", Role.ADMIN))
        assert ac.get_role("alice") == Role.ADMIN
        assert len(ac) == 1

    def test_to_list_from_list(self, ac):
        ac.add_entry(AccessEntry("alice", Role.ADMIN))
        ac.add_entry(AccessEntry("bob", Role.VIEWER, environments=["dev"]))
        data = ac.to_list()
        restored = AccessControl.from_list(data)
        assert len(restored) == 2
        assert restored.get_role("alice") == Role.ADMIN


class TestAccessDeniedError:
    def test_message(self):
        err = AccessDeniedError("bob", Permission.WRITE)
        assert "bob" in str(err)
        assert "write" in str(err)

    def test_attributes(self):
        err = AccessDeniedError("bob", Permission.DELETE)
        assert err.identity == "bob"
        assert err.permission == Permission.DELETE

    def test_custom_message(self):
        err = AccessDeniedError("bob", Permission.ADMIN, "Custom denial")
        assert str(err) == "Custom denial"
