"""Edge case tests across multiple envault modules."""

import json
import time

import pytest

from envault.crypto import (
    EncryptedPayload,
    decrypt,
    decrypt_with_key,
    encrypt,
    encrypt_with_key,
    generate_key,
)
from envault.diff import ChangeType, DiffResult, VarChange, diff_environments, _mask_value
from envault.exporter import (
    ExportFormat,
    export_dotenv,
    export_json,
    export_k8s_secret,
    export_shell,
    export_to_format,
    export_yaml,
)
from envault.importer import parse_dotenv, parse_json_env, validate_var_name, sanitize_var_name
from envault.template import interpolate, interpolate_all, find_references
from envault.vault import Vault, DEFAULT_ENVIRONMENT
from envault.merge import merge_dicts, ConflictStrategy
from envault.validator import VariableSchema, RuleType


class TestCryptoEdgeCases:
    def test_encrypt_multiline_value(self):
        value = "line1\nline2\nline3"
        payload = encrypt(value, "pw")
        assert decrypt(payload, "pw") == value

    def test_encrypt_very_long_password(self):
        long_pw = "x" * 10000
        payload = encrypt("data", long_pw)
        assert decrypt(payload, long_pw) == "data"

    def test_encrypt_binary_like_string(self):
        value = "\x00\x01\x02\x03"
        payload = encrypt(value, "pw")
        assert decrypt(payload, "pw") == value

    def test_payload_json_roundtrip(self):
        payload = encrypt("test", "pw")
        json_str = json.dumps(payload.to_dict())
        restored = EncryptedPayload.from_dict(json.loads(json_str))
        assert decrypt(restored, "pw") == "test"

    def test_key_encryption_unicode(self):
        key = generate_key()
        value = "Emoji: 🔐🗝️"
        payload = encrypt_with_key(value, key)
        assert decrypt_with_key(payload, key) == value


class TestVaultEdgeCases:
    def test_many_environments(self, tmp_path):
        v = Vault(path=tmp_path / ".envault.json", password="pw")
        for i in range(50):
            v.set("KEY", f"val-{i}", f"env-{i}")
        assert len(v.list_environments()) == 50
        assert v.get("KEY", "env-25") == "val-25"

    def test_many_variables(self, tmp_path):
        v = Vault(path=tmp_path / ".envault.json", password="pw")
        for i in range(100):
            v.set(f"VAR_{i}", f"value_{i}")
        assert len(v) == 100
        assert v.get("VAR_50") == "value_50"

    def test_special_chars_in_value(self, tmp_path):
        v = Vault(path=tmp_path / ".envault.json", password="pw")
        special = 'value with "quotes" and \'apostrophes\' and \ttabs\n'
        v.set("SPECIAL", special)
        assert v.get("SPECIAL") == special

    def test_save_load_roundtrip_large(self, tmp_path):
        v1 = Vault(path=tmp_path / ".envault.json", password="pw")
        for i in range(50):
            v1.set(f"KEY_{i}", f"value_{i}", f"env_{i % 5}")
        v1.save()

        v2 = Vault(path=tmp_path / ".envault.json", password="pw")
        v2.load()
        assert len(v2) == 50
        assert v2.get("KEY_25", "env_0") == "value_25"

    def test_search_empty_pattern(self, tmp_path):
        v = Vault(path=tmp_path / ".envault.json", password="pw")
        v.set("A", "1")
        result = v.search("")
        assert DEFAULT_ENVIRONMENT in result

    def test_copy_environment_empty(self, tmp_path):
        v = Vault(path=tmp_path / ".envault.json", password="pw")
        count = v.copy_environment("empty", "other")
        assert count == 0


class TestExporterEdgeCases:
    def test_export_dotenv_multiline_value(self):
        result = export_dotenv({"MSG": "line1\nline2"})
        assert "\\n" in result

    def test_export_shell_with_dollar(self):
        result = export_shell({"CMD": "$HOME/bin"})
        assert "'" in result  # should be single-quoted

    def test_export_json_empty(self):
        result = export_json({})
        assert json.loads(result) == {}

    def test_export_yaml_with_special(self):
        result = export_yaml({"KEY": "value: with colon"})
        assert '"' in result  # should be quoted

    def test_export_k8s_unicode(self):
        result = export_k8s_secret({"KEY": "한글"})
        assert "kind: Secret" in result

    def test_all_formats_handle_empty(self):
        for fmt in ExportFormat:
            result = export_to_format({}, fmt)
            assert isinstance(result, str)


class TestImporterEdgeCases:
    def test_parse_dotenv_consecutive_equals(self):
        result = parse_dotenv("KEY==value")
        assert result["KEY"] == "=value"

    def test_parse_dotenv_hash_in_value(self):
        result = parse_dotenv('KEY="has#hash"')
        assert result["KEY"] == "has#hash"

    def test_parse_json_float_value(self):
        result = parse_json_env('{"RATE": 0.95}')
        assert result["RATE"] == "0.95"

    def test_validate_var_name_underscore_start(self):
        assert validate_var_name("_PRIVATE") is True

    def test_sanitize_special(self):
        result = sanitize_var_name("my.weird-name@here")
        assert result == "MY_WEIRD_NAME_HERE"


class TestTemplateEdgeCases:
    def test_nested_braces(self):
        # ${VAR} inside a value that looks like JSON
        result = interpolate('{"key": "${VAL}"}', {"VAL": "x"})
        assert result == '{"key": "x"}'

    def test_dollar_without_brace(self):
        result = interpolate("price is $5", {})
        assert result == "price is $5"

    def test_empty_variable_name(self):
        refs = find_references("${}")
        assert refs == []

    def test_interpolate_all_large(self):
        variables = {f"VAR_{i}": f"value_{i}" for i in range(100)}
        variables["COMBO"] = "${VAR_1}-${VAR_2}-${VAR_3}"
        result = interpolate_all(variables)
        assert result["COMBO"] == "value_1-value_2-value_3"


class TestMergeEdgeCases:
    def test_merge_large(self):
        source = {f"K{i}": f"v{i}" for i in range(100)}
        target = {}
        merged, result = merge_dicts(source, target)
        assert result.merged == 100

    def test_merge_all_conflicts_skip(self):
        source = {"A": "new1", "B": "new2"}
        target = {"A": "old1", "B": "old2"}
        merged, result = merge_dicts(source, target, ConflictStrategy.SKIP)
        assert result.skipped == 2
        assert merged["A"] == "old1"


class TestValidatorEdgeCases:
    def test_multiple_failures(self):
        schema = VariableSchema()
        schema.require("A").require("B").require("C")
        result = schema.validate({})
        assert result.error_count == 3

    def test_all_pass(self):
        schema = VariableSchema()
        schema.require("A").url("B").port("C")
        result = schema.validate({
            "A": "present",
            "B": "https://example.com",
            "C": "8080",
        })
        assert result.is_valid

    def test_schema_roundtrip(self):
        schema = VariableSchema()
        schema.require("A").url("A").min_length("A", 10)
        d = schema.to_dict()
        restored = VariableSchema.from_dict(d)
        result = restored.validate({"A": "http://x"})
        # Should fail url (too short) but technically url validation is separate
        assert len(restored.get_rules("A")) == 3


class TestDiffEdgeCases:
    def test_mask_empty(self):
        assert _mask_value("") == ""

    def test_mask_single_char(self):
        result = _mask_value("x")
        assert result == "*"

    def test_diff_result_text_unchanged(self):
        result = DiffResult("a", "b", [
            VarChange("KEY", ChangeType.UNCHANGED, "val", "val"),
        ])
        text = result.to_text()
        assert "  KEY" in text  # space prefix for unchanged
