"""Tests for envault.backup module."""

import json
import time

import pytest

from envault.backup import (
    BACKUP_SUFFIX,
    BackupInfo,
    cleanup_old_backups,
    create_backup,
    delete_backup,
    list_backups,
    restore_backup,
    verify_backup,
)
from envault.vault import Vault


@pytest.fixture
def vault(tmp_path):
    v = Vault(path=tmp_path / ".envault.json", password="pw")
    v.set("KEY", "value")
    v.save()
    return v


class TestBackupInfo:
    def test_created_at(self):
        info = BackupInfo(path=None, timestamp=0.0, size=100)
        assert "1970" in info.created_at

    def test_to_dict(self, tmp_path):
        info = BackupInfo(path=tmp_path / "test.backup", timestamp=1000.0, size=50)
        d = info.to_dict()
        assert d["size"] == 50
        assert "path" in d
        assert "created_at" in d

    def test_filename(self, tmp_path):
        info = BackupInfo(path=tmp_path / "myfile.backup", timestamp=0, size=0)
        assert info.filename == "myfile.backup"


class TestCreateBackup:
    def test_creates_backup(self, vault):
        info = create_backup(vault.path)
        assert info.path.exists()
        assert info.size > 0
        assert BACKUP_SUFFIX in info.path.name

    def test_backup_content_matches(self, vault):
        info = create_backup(vault.path)
        original = vault.path.read_text()
        backup = info.path.read_text()
        assert original == backup

    def test_custom_backup_dir(self, vault, tmp_path):
        backup_dir = tmp_path / "backups"
        info = create_backup(vault.path, backup_dir=backup_dir)
        assert info.path.parent == backup_dir

    def test_with_label(self, vault):
        info = create_backup(vault.path, label="before_deploy")
        assert "before_deploy" in info.path.name

    def test_nonexistent_vault_raises(self, tmp_path):
        with pytest.raises(FileNotFoundError):
            create_backup(tmp_path / "nope.json")

    def test_multiple_backups(self, vault):
        b1 = create_backup(vault.path)
        b2 = create_backup(vault.path)
        assert b1.path != b2.path


class TestListBackups:
    def test_list_empty(self, tmp_path):
        result = list_backups(tmp_path / ".envault.json")
        assert result == []

    def test_list_backups(self, vault):
        create_backup(vault.path)
        create_backup(vault.path)
        backups = list_backups(vault.path)
        assert len(backups) == 2
        # Newest first
        assert backups[0].timestamp >= backups[1].timestamp

    def test_custom_dir(self, vault, tmp_path):
        backup_dir = tmp_path / "backups"
        create_backup(vault.path, backup_dir=backup_dir)
        backups = list_backups(vault.path, backup_dir=backup_dir)
        assert len(backups) == 1

    def test_nonexistent_dir(self, tmp_path):
        result = list_backups(tmp_path / ".envault.json", backup_dir=tmp_path / "nope")
        assert result == []


class TestRestoreBackup:
    def test_restore(self, vault, tmp_path):
        # Create backup
        backup = create_backup(vault.path)

        # Modify vault
        vault.set("NEW_KEY", "new_value")
        vault.save()

        # Restore
        restore_backup(backup.path, vault.path, create_pre_restore_backup=False)

        # Verify restored
        v2 = Vault(path=vault.path, password="pw")
        v2.load()
        assert v2.has("KEY")
        assert not v2.has("NEW_KEY")

    def test_restore_creates_pre_backup(self, vault):
        backup = create_backup(vault.path)
        pre = restore_backup(backup.path, vault.path, create_pre_restore_backup=True)
        assert pre is not None
        assert pre.path.exists()

    def test_restore_no_pre_backup(self, vault):
        backup = create_backup(vault.path)
        pre = restore_backup(backup.path, vault.path, create_pre_restore_backup=False)
        assert pre is None

    def test_restore_nonexistent_raises(self, tmp_path):
        with pytest.raises(FileNotFoundError):
            restore_backup(tmp_path / "nope.backup", tmp_path / ".envault.json")

    def test_restore_when_vault_missing(self, vault, tmp_path):
        backup = create_backup(vault.path)
        new_path = tmp_path / "new" / ".envault.json"
        new_path.parent.mkdir(parents=True)
        restore_backup(backup.path, new_path, create_pre_restore_backup=True)
        assert new_path.exists()


class TestDeleteBackup:
    def test_delete(self, vault):
        backup = create_backup(vault.path)
        assert delete_backup(backup.path) is True
        assert not backup.path.exists()

    def test_delete_nonexistent(self, tmp_path):
        assert delete_backup(tmp_path / "nope.backup") is False


class TestCleanupOldBackups:
    def test_cleanup(self, vault):
        for _ in range(7):
            create_backup(vault.path)

        removed = cleanup_old_backups(vault.path, keep=3)
        assert removed == 4
        remaining = list_backups(vault.path)
        assert len(remaining) == 3

    def test_cleanup_fewer_than_keep(self, vault):
        create_backup(vault.path)
        create_backup(vault.path)
        removed = cleanup_old_backups(vault.path, keep=5)
        assert removed == 0

    def test_cleanup_none(self, tmp_path):
        removed = cleanup_old_backups(tmp_path / ".envault.json", keep=5)
        assert removed == 0


class TestVerifyBackup:
    def test_valid(self, vault):
        backup = create_backup(vault.path)
        assert verify_backup(backup.path) is True

    def test_invalid_json(self, tmp_path):
        bad = tmp_path / "bad.envault.backup"
        bad.write_text("not json")
        assert verify_backup(bad) is False

    def test_missing_fields(self, tmp_path):
        bad = tmp_path / "bad.envault.backup"
        bad.write_text(json.dumps({"other": "data"}))
        assert verify_backup(bad) is False

    def test_nonexistent(self, tmp_path):
        assert verify_backup(tmp_path / "nope.backup") is False
