"""Tests for envault.template module."""

import pytest

from envault.template import (
    InterpolationError,
    build_dependency_graph,
    find_circular_references,
    find_references,
    has_references,
    interpolate,
    interpolate_all,
    resolve_order,
)


class TestFindReferences:
    def test_no_references(self):
        assert find_references("hello world") == []

    def test_single_reference(self):
        assert find_references("${VAR}") == ["VAR"]

    def test_multiple_references(self):
        refs = find_references("${A} and ${B}")
        assert refs == ["A", "B"]

    def test_reference_with_default(self):
        refs = find_references("${VAR:-default}")
        assert refs == ["VAR"]

    def test_embedded_in_text(self):
        refs = find_references("postgres://${USER}:${PASS}@${HOST}/db")
        assert refs == ["USER", "PASS", "HOST"]

    def test_hyphens_in_name(self):
        refs = find_references("${my-var}")
        assert refs == ["my-var"]


class TestHasReferences:
    def test_no_references(self):
        assert has_references("plain") is False

    def test_has_reference(self):
        assert has_references("${VAR}") is True

    def test_dollar_without_braces(self):
        assert has_references("$VAR") is False


class TestInterpolate:
    def test_simple(self):
        result = interpolate("${NAME}", {"NAME": "Alice"})
        assert result == "Alice"

    def test_embedded(self):
        result = interpolate("Hello, ${NAME}!", {"NAME": "World"})
        assert result == "Hello, World!"

    def test_multiple(self):
        result = interpolate(
            "${PROTO}://${HOST}:${PORT}",
            {"PROTO": "https", "HOST": "example.com", "PORT": "443"},
        )
        assert result == "https://example.com:443"

    def test_default_value(self):
        result = interpolate("${MISSING:-fallback}", {})
        assert result == "fallback"

    def test_default_not_used_when_present(self):
        result = interpolate("${KEY:-default}", {"KEY": "actual"})
        assert result == "actual"

    def test_empty_default(self):
        result = interpolate("${KEY:-}", {})
        assert result == ""

    def test_strict_raises_on_missing(self):
        with pytest.raises(InterpolationError):
            interpolate("${MISSING}", {}, strict=True)

    def test_non_strict_leaves_as_is(self):
        result = interpolate("${MISSING}", {}, strict=False)
        assert result == "${MISSING}"

    def test_no_references_unchanged(self):
        result = interpolate("plain text", {})
        assert result == "plain text"

    def test_interpolation_error_has_reference(self):
        with pytest.raises(InterpolationError) as exc_info:
            interpolate("${BAD_REF}", {}, strict=True)
        assert exc_info.value.reference == "BAD_REF"


class TestInterpolateAll:
    def test_simple_resolution(self):
        variables = {
            "HOST": "localhost",
            "PORT": "5432",
            "URL": "postgres://${HOST}:${PORT}/db",
        }
        result = interpolate_all(variables)
        assert result["URL"] == "postgres://localhost:5432/db"

    def test_transitive_resolution(self):
        variables = {
            "A": "hello",
            "B": "${A}-world",
            "C": "${B}-foo",
        }
        result = interpolate_all(variables)
        assert result["C"] == "hello-world-foo"

    def test_no_references(self):
        variables = {"A": "1", "B": "2"}
        result = interpolate_all(variables)
        assert result == variables

    def test_circular_raises(self):
        variables = {
            "A": "${B}",
            "B": "${A}",
        }
        with pytest.raises(RecursionError):
            interpolate_all(variables, max_depth=5)

    def test_strict_missing_raises(self):
        variables = {"A": "${EXTERNAL}"}
        with pytest.raises(InterpolationError):
            interpolate_all(variables, strict=True)

    def test_non_strict_missing(self):
        variables = {"A": "${EXTERNAL}"}
        result = interpolate_all(variables, strict=False)
        assert result["A"] == "${EXTERNAL}"

    def test_with_defaults(self):
        variables = {
            "HOST": "localhost",
            "URL": "http://${HOST}:${PORT:-8080}/api",
        }
        result = interpolate_all(variables)
        assert result["URL"] == "http://localhost:8080/api"


class TestBuildDependencyGraph:
    def test_no_deps(self):
        graph = build_dependency_graph({"A": "1", "B": "2"})
        assert graph["A"] == set()
        assert graph["B"] == set()

    def test_simple_deps(self):
        graph = build_dependency_graph({
            "A": "1",
            "B": "${A}",
        })
        assert graph["A"] == set()
        assert graph["B"] == {"A"}

    def test_multiple_deps(self):
        graph = build_dependency_graph({
            "URL": "${PROTO}://${HOST}:${PORT}",
        })
        assert graph["URL"] == {"PROTO", "HOST", "PORT"}


class TestFindCircularReferences:
    def test_no_circles(self):
        variables = {"A": "1", "B": "${A}"}
        cycles = find_circular_references(variables)
        assert cycles == []

    def test_direct_circle(self):
        variables = {"A": "${B}", "B": "${A}"}
        cycles = find_circular_references(variables)
        assert len(cycles) > 0

    def test_indirect_circle(self):
        variables = {"A": "${B}", "B": "${C}", "C": "${A}"}
        cycles = find_circular_references(variables)
        assert len(cycles) > 0

    def test_no_variables(self):
        assert find_circular_references({}) == []


class TestResolveOrder:
    def test_no_deps(self):
        order = resolve_order({"A": "1", "B": "2"})
        assert set(order) == {"A", "B"}

    def test_linear_deps(self):
        order = resolve_order({
            "C": "${B}",
            "B": "${A}",
            "A": "1",
        })
        assert order.index("A") < order.index("B")
        assert order.index("B") < order.index("C")

    def test_circular_raises(self):
        with pytest.raises(ValueError, match="Circular"):
            resolve_order({"A": "${B}", "B": "${A}"})

    def test_external_refs_ok(self):
        # References to vars not in dict should be fine
        order = resolve_order({"A": "${EXTERNAL}"})
        assert order == ["A"]
