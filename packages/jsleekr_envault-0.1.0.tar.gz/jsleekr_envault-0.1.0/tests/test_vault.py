"""Tests for envault.vault module."""

import json

import pytest

from envault.crypto import generate_key
from envault.vault import DEFAULT_ENVIRONMENT, Environment, Vault, VaultEntry


@pytest.fixture
def password():
    return "test-password-123"


@pytest.fixture
def vault(tmp_path, password):
    return Vault(path=tmp_path / ".envault.json", password=password)


@pytest.fixture
def key():
    return generate_key()


@pytest.fixture
def key_vault(tmp_path, key):
    return Vault(path=tmp_path / ".envault.json", key=key)


class TestVaultInit:
    def test_requires_password_or_key(self, tmp_path):
        with pytest.raises(ValueError, match="Either password or key"):
            Vault(path=tmp_path / ".envault.json")

    def test_accepts_password(self, tmp_path):
        v = Vault(path=tmp_path / ".envault.json", password="pw")
        assert v is not None

    def test_accepts_key(self, tmp_path):
        v = Vault(path=tmp_path / ".envault.json", key=generate_key())
        assert v is not None

    def test_default_path(self):
        v = Vault(password="pw")
        assert v.path.name == ".envault.json"


class TestVaultSetGet:
    def test_set_and_get(self, vault):
        vault.set("DB_URL", "postgres://localhost/db")
        assert vault.get("DB_URL") == "postgres://localhost/db"

    def test_set_overwrites(self, vault):
        vault.set("KEY", "old")
        vault.set("KEY", "new")
        assert vault.get("KEY") == "new"

    def test_get_nonexistent_raises(self, vault):
        with pytest.raises(KeyError):
            vault.get("NOPE")

    def test_set_with_environment(self, vault):
        vault.set("KEY", "dev-val", "dev")
        vault.set("KEY", "prod-val", "prod")
        assert vault.get("KEY", "dev") == "dev-val"
        assert vault.get("KEY", "prod") == "prod-val"

    def test_set_with_description(self, vault):
        vault.set("KEY", "val", description="The main key")
        entry = vault.get_entry("KEY")
        assert entry.description == "The main key"

    def test_set_with_tags(self, vault):
        vault.set("KEY", "val", tags=["db", "critical"])
        entry = vault.get_entry("KEY")
        assert entry.tags == ["db", "critical"]

    def test_set_preserves_description_on_update(self, vault):
        vault.set("KEY", "v1", description="my desc")
        vault.set("KEY", "v2")
        entry = vault.get_entry("KEY")
        assert entry.description == "my desc"

    def test_set_preserves_tags_on_update(self, vault):
        vault.set("KEY", "v1", tags=["important"])
        vault.set("KEY", "v2")
        assert vault.get_entry("KEY").tags == ["important"]

    def test_set_empty_name_raises(self, vault):
        with pytest.raises(ValueError, match="cannot be empty"):
            vault.set("", "value")

    def test_set_invalid_name_raises(self, vault):
        with pytest.raises(ValueError, match="Invalid variable name"):
            vault.set("bad name!", "value")

    def test_set_valid_name_with_hyphens(self, vault):
        vault.set("my-key", "val")
        assert vault.get("my-key") == "val"

    def test_set_valid_name_with_underscores(self, vault):
        vault.set("MY_KEY", "val")
        assert vault.get("MY_KEY") == "val"

    def test_get_entry_nonexistent_raises(self, vault):
        with pytest.raises(KeyError):
            vault.get_entry("NOPE")

    def test_timestamps_set_correctly(self, vault):
        vault.set("KEY", "val")
        entry = vault.get_entry("KEY")
        assert entry.created_at > 0
        assert entry.updated_at >= entry.created_at


class TestVaultDelete:
    def test_delete_existing(self, vault):
        vault.set("KEY", "val")
        assert vault.delete("KEY") is True
        assert not vault.has("KEY")

    def test_delete_nonexistent(self, vault):
        assert vault.delete("NOPE") is False

    def test_delete_removes_empty_environment(self, vault):
        vault.set("KEY", "val", "staging")
        vault.delete("KEY", "staging")
        assert "staging" not in vault.list_environments()

    def test_delete_from_specific_env(self, vault):
        vault.set("KEY", "v1", "dev")
        vault.set("KEY", "v2", "prod")
        vault.delete("KEY", "dev")
        assert not vault.has("KEY", "dev")
        assert vault.has("KEY", "prod")


class TestVaultList:
    def test_list_vars_empty(self, vault):
        assert vault.list_vars() == []

    def test_list_vars_sorted(self, vault):
        vault.set("ZEBRA", "z")
        vault.set("ALPHA", "a")
        vault.set("MIDDLE", "m")
        assert vault.list_vars() == ["ALPHA", "MIDDLE", "ZEBRA"]

    def test_list_environments(self, vault):
        vault.set("A", "1", "dev")
        vault.set("B", "2", "prod")
        vault.set("C", "3", "staging")
        assert vault.list_environments() == ["dev", "prod", "staging"]

    def test_list_environments_empty(self, vault):
        assert vault.list_environments() == []


class TestVaultHas:
    def test_has_existing(self, vault):
        vault.set("KEY", "val")
        assert vault.has("KEY") is True

    def test_has_nonexistent(self, vault):
        assert vault.has("NOPE") is False

    def test_has_wrong_env(self, vault):
        vault.set("KEY", "val", "dev")
        assert vault.has("KEY", "prod") is False


class TestVaultGetAll:
    def test_get_all(self, vault):
        vault.set("A", "1")
        vault.set("B", "2")
        result = vault.get_all()
        assert result == {"A": "1", "B": "2"}

    def test_get_all_empty(self, vault):
        assert vault.get_all() == {}

    def test_get_all_specific_env(self, vault):
        vault.set("A", "1", "dev")
        vault.set("B", "2", "prod")
        assert vault.get_all("dev") == {"A": "1"}


class TestVaultCopy:
    def test_copy_var(self, vault):
        vault.set("KEY", "val", "dev")
        vault.copy_var("KEY", "dev", "prod")
        assert vault.get("KEY", "prod") == "val"

    def test_copy_environment(self, vault):
        vault.set("A", "1", "dev")
        vault.set("B", "2", "dev")
        count = vault.copy_environment("dev", "staging")
        assert count == 2
        assert vault.get("A", "staging") == "1"
        assert vault.get("B", "staging") == "2"

    def test_copy_var_preserves_metadata(self, vault):
        vault.set("KEY", "val", "dev", description="desc", tags=["t1"])
        vault.copy_var("KEY", "dev", "prod")
        entry = vault.get_entry("KEY", "prod")
        assert entry.description == "desc"
        assert entry.tags == ["t1"]


class TestVaultSearch:
    def test_search_finds_matching(self, vault):
        vault.set("DATABASE_URL", "x")
        vault.set("DATABASE_HOST", "y")
        vault.set("API_KEY", "z")
        result = vault.search("database")
        assert DEFAULT_ENVIRONMENT in result
        assert set(result[DEFAULT_ENVIRONMENT]) == {"DATABASE_HOST", "DATABASE_URL"}

    def test_search_case_insensitive(self, vault):
        vault.set("MyVar", "x")
        result = vault.search("myvar")
        assert DEFAULT_ENVIRONMENT in result

    def test_search_no_match(self, vault):
        vault.set("KEY", "val")
        assert vault.search("xyz") == {}

    def test_search_specific_env(self, vault):
        vault.set("KEY", "v1", "dev")
        vault.set("KEY", "v2", "prod")
        result = vault.search("KEY", "dev")
        assert "dev" in result
        assert "prod" not in result

    def test_search_across_envs(self, vault):
        vault.set("DB_URL", "x", "dev")
        vault.set("DB_URL", "y", "prod")
        result = vault.search("DB")
        assert "dev" in result
        assert "prod" in result


class TestVaultFilterByTag:
    def test_filter_by_tag(self, vault):
        vault.set("A", "1", tags=["db"])
        vault.set("B", "2", tags=["api"])
        vault.set("C", "3", tags=["db", "api"])
        assert vault.filter_by_tag("db") == ["A", "C"]

    def test_filter_no_match(self, vault):
        vault.set("A", "1", tags=["db"])
        assert vault.filter_by_tag("api") == []

    def test_filter_empty_env(self, vault):
        assert vault.filter_by_tag("db") == []


class TestVaultStats:
    def test_stats(self, vault):
        vault.set("A", "1", "dev")
        vault.set("B", "2", "dev")
        vault.set("C", "3", "prod")
        stats = vault.stats()
        assert stats["environments"] == 2
        assert stats["total_variables"] == 3
        assert stats["environment_details"]["dev"] == 2
        assert stats["environment_details"]["prod"] == 1

    def test_stats_empty(self, vault):
        stats = vault.stats()
        assert stats["total_variables"] == 0


class TestVaultPersistence:
    def test_save_and_load(self, tmp_path, password):
        v1 = Vault(path=tmp_path / ".envault.json", password=password)
        v1.set("KEY", "secret")
        v1.save()

        v2 = Vault(path=tmp_path / ".envault.json", password=password)
        v2.load()
        assert v2.get("KEY") == "secret"

    def test_load_nonexistent_raises(self, tmp_path, password):
        v = Vault(path=tmp_path / "nope.json", password=password)
        with pytest.raises(FileNotFoundError):
            v.load()

    def test_exists_false(self, tmp_path, password):
        v = Vault(path=tmp_path / "nope.json", password=password)
        assert v.exists() is False

    def test_exists_true(self, tmp_path, password):
        v = Vault(path=tmp_path / ".envault.json", password=password)
        v.save()
        assert v.exists() is True

    def test_save_creates_parent_dirs(self, tmp_path, password):
        v = Vault(path=tmp_path / "sub" / "dir" / ".envault.json", password=password)
        v.set("KEY", "val")
        v.save()
        assert v.exists()

    def test_roundtrip_with_key(self, tmp_path, key):
        v1 = Vault(path=tmp_path / ".envault.json", key=key)
        v1.set("A", "1", "dev")
        v1.set("B", "2", "prod", description="desc", tags=["tag"])
        v1.save()

        v2 = Vault(path=tmp_path / ".envault.json", key=key)
        v2.load()
        assert v2.get("A", "dev") == "1"
        assert v2.get("B", "prod") == "2"
        assert v2.get_entry("B", "prod").description == "desc"

    def test_save_atomic_on_success(self, tmp_path, password):
        v = Vault(path=tmp_path / ".envault.json", password=password)
        v.set("KEY", "val")
        path = v.save()
        assert path.exists()
        assert not path.with_suffix(".tmp").exists()


class TestVaultRotatePassword:
    def test_rotate_password(self, tmp_path):
        v = Vault(path=tmp_path / ".envault.json", password="old-pw")
        v.set("A", "secret1")
        v.set("B", "secret2", "prod")
        count = v.rotate_password("new-pw")
        assert count == 2
        assert v.get("A") == "secret1"
        assert v.get("B", "prod") == "secret2"

    def test_rotate_password_persists(self, tmp_path):
        v1 = Vault(path=tmp_path / ".envault.json", password="old")
        v1.set("KEY", "value")
        v1.rotate_password("new")
        v1.save()

        v2 = Vault(path=tmp_path / ".envault.json", password="new")
        v2.load()
        assert v2.get("KEY") == "value"

    def test_rotate_password_old_fails(self, tmp_path):
        v1 = Vault(path=tmp_path / ".envault.json", password="old")
        v1.set("KEY", "value")
        v1.rotate_password("new")
        v1.save()

        v2 = Vault(path=tmp_path / ".envault.json", password="old")
        v2.load()
        with pytest.raises(ValueError):
            v2.get("KEY")

    def test_rotate_password_on_key_vault_raises(self, tmp_path, key):
        v = Vault(path=tmp_path / ".envault.json", key=key)
        v.set("KEY", "val")
        with pytest.raises(ValueError, match="Cannot rotate password"):
            v.rotate_password("new")


class TestVaultRotateKey:
    def test_rotate_key(self, tmp_path, key):
        v = Vault(path=tmp_path / ".envault.json", key=key)
        v.set("A", "secret")
        new_key = generate_key()
        count = v.rotate_key(new_key)
        assert count == 1
        assert v.get("A") == "secret"

    def test_rotate_key_persists(self, tmp_path, key):
        v1 = Vault(path=tmp_path / ".envault.json", key=key)
        v1.set("KEY", "val")
        new_key = generate_key()
        v1.rotate_key(new_key)
        v1.save()

        v2 = Vault(path=tmp_path / ".envault.json", key=new_key)
        v2.load()
        assert v2.get("KEY") == "val"

    def test_rotate_key_on_password_vault_raises(self, tmp_path):
        v = Vault(path=tmp_path / ".envault.json", password="pw")
        v.set("KEY", "val")
        with pytest.raises(ValueError, match="Cannot rotate key"):
            v.rotate_key(generate_key())


class TestVaultRename:
    def test_rename_var(self, vault):
        vault.set("OLD_NAME", "val")
        vault.rename_var("OLD_NAME", "NEW_NAME")
        assert vault.get("NEW_NAME") == "val"
        assert not vault.has("OLD_NAME")

    def test_rename_nonexistent_raises(self, vault):
        with pytest.raises(KeyError):
            vault.rename_var("NOPE", "NEW")

    def test_rename_to_existing_raises(self, vault):
        vault.set("A", "1")
        vault.set("B", "2")
        with pytest.raises(ValueError, match="already exists"):
            vault.rename_var("A", "B")

    def test_rename_preserves_entry(self, vault):
        vault.set("OLD", "val", description="desc", tags=["t1"])
        vault.rename_var("OLD", "NEW")
        entry = vault.get_entry("NEW")
        assert entry.description == "desc"
        assert entry.tags == ["t1"]


class TestVaultBulkSet:
    def test_bulk_set(self, vault):
        count = vault.bulk_set({"A": "1", "B": "2", "C": "3"})
        assert count == 3
        assert vault.get("A") == "1"
        assert vault.get("B") == "2"
        assert vault.get("C") == "3"

    def test_bulk_set_specific_env(self, vault):
        vault.bulk_set({"X": "10"}, "staging")
        assert vault.get("X", "staging") == "10"

    def test_bulk_set_empty(self, vault):
        count = vault.bulk_set({})
        assert count == 0


class TestVaultDunder:
    def test_len(self, vault):
        vault.set("A", "1")
        vault.set("B", "2", "other")
        assert len(vault) == 2

    def test_contains(self, vault):
        vault.set("KEY", "val")
        assert "KEY" in vault
        assert "NOPE" not in vault

    def test_iter(self, vault):
        vault.set("B", "2")
        vault.set("A", "1")
        assert list(vault) == ["A", "B"]


class TestVaultEntry:
    def test_to_dict_from_dict_roundtrip(self, vault):
        vault.set("KEY", "val", description="desc", tags=["t1", "t2"])
        entry = vault.get_entry("KEY")
        d = entry.to_dict()
        restored = VaultEntry.from_dict(d)
        assert restored.description == "desc"
        assert restored.tags == ["t1", "t2"]
        assert restored.created_at == entry.created_at


class TestEnvironment:
    def test_to_dict_from_dict(self, vault):
        vault.set("A", "1", "test")
        env = vault.environments["test"]
        d = env.to_dict()
        restored = Environment.from_dict(d)
        assert restored.name == "test"
        assert "A" in restored.entries
