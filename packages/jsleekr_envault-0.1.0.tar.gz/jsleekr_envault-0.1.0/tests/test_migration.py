"""Tests for envault.migration module."""

import json

import pytest

from envault.migration import (
    CURRENT_VERSION,
    MigrationResult,
    MigrationStep,
    get_migration_path,
    get_vault_version,
    migrate,
    migrate_file,
    needs_migration,
)
from envault.vault import Vault


class TestGetVaultVersion:
    def test_version_1_default(self):
        assert get_vault_version({}) == 1

    def test_explicit_version(self):
        assert get_vault_version({"metadata": {"version": 2}}) == 2

    def test_no_metadata(self):
        assert get_vault_version({"environments": {}}) == 1


class TestNeedsMigration:
    def test_old_version(self):
        assert needs_migration({}) is True

    def test_current_version(self):
        assert needs_migration({"metadata": {"version": CURRENT_VERSION}}) is False


class TestGetMigrationPath:
    def test_v1_to_v2(self):
        path = get_migration_path(1, 2)
        assert len(path) == 1
        assert path[0].from_version == 1
        assert path[0].to_version == 2

    def test_already_current(self):
        path = get_migration_path(2, 2)
        assert path == []

    def test_no_path(self):
        path = get_migration_path(99, 100)
        assert path == []


class TestMigrate:
    def test_v1_to_v2(self):
        data = {"metadata": {"version": 1}, "environments": {}}
        migrated, result = migrate(data)
        assert result.success is True
        assert result.steps_applied == 1
        assert get_vault_version(migrated) == 2

    def test_already_current(self):
        data = {"metadata": {"version": CURRENT_VERSION}}
        migrated, result = migrate(data)
        assert result.success is True
        assert result.steps_applied == 0

    def test_adds_migration_history(self):
        data = {"metadata": {"version": 1}, "environments": {}}
        migrated, result = migrate(data)
        history = migrated["metadata"]["migration_history"]
        assert len(history) == 1
        assert history[0]["from"] == 1
        assert history[0]["to"] == 2

    def test_adds_migrated_at(self):
        data = {"metadata": {"version": 1}, "environments": {}}
        migrated, result = migrate(data)
        assert "migrated_at" in migrated["metadata"]


class TestMigrationResult:
    def test_summary_success(self):
        r = MigrationResult(1, 2, 1, True)
        assert "Migrated" in r.summary

    def test_summary_failure(self):
        r = MigrationResult(1, 1, 0, False, ["Error here"])
        assert "failed" in r.summary
        assert "Error here" in r.summary


class TestMigrateFile:
    def test_migrate_v1_file(self, tmp_path):
        path = tmp_path / ".envault.json"
        data = {
            "metadata": {"version": 1, "created_at": 1000.0},
            "environments": {},
        }
        path.write_text(json.dumps(data))

        result = migrate_file(path, backup=False)
        assert result.success is True
        assert result.steps_applied == 1

        # Verify file was updated
        updated = json.loads(path.read_text())
        assert updated["metadata"]["version"] == 2

    def test_migrate_already_current(self, tmp_path):
        path = tmp_path / ".envault.json"
        data = {"metadata": {"version": CURRENT_VERSION}, "environments": {}}
        path.write_text(json.dumps(data))

        result = migrate_file(path, backup=False)
        assert result.success is True
        assert result.steps_applied == 0

    def test_migrate_nonexistent(self, tmp_path):
        result = migrate_file(tmp_path / "nope.json")
        assert result.success is False

    def test_migrate_with_backup(self, tmp_path):
        path = tmp_path / ".envault.json"
        data = {"metadata": {"version": 1}, "environments": {}}
        path.write_text(json.dumps(data))

        result = migrate_file(path, backup=True)
        assert result.success is True
        # Backup should exist
        backups = list(tmp_path.glob("*.envault.backup"))
        assert len(backups) == 1

    def test_preserves_existing_data(self, tmp_path):
        # Create a real vault with data
        v = Vault(path=tmp_path / ".envault.json", password="pw")
        v.set("KEY", "value")
        v.save()

        result = migrate_file(v.path, backup=False)
        assert result.success is True

        # Verify data is preserved
        v2 = Vault(path=tmp_path / ".envault.json", password="pw")
        v2.load()
        assert v2.get("KEY") == "value"
