"""Tests for envault.merge module."""

import pytest

from envault.crypto import generate_key
from envault.merge import (
    ConflictStrategy,
    MergeConflict,
    MergeResult,
    diff_and_merge,
    merge_dicts,
    merge_environments,
    merge_vaults,
)
from envault.vault import Vault


class TestMergeDicts:
    def test_no_overlap(self):
        merged, result = merge_dicts({"A": "1"}, {"B": "2"})
        assert merged == {"A": "1", "B": "2"}
        assert result.merged == 1
        assert result.new_vars == ["A"]

    def test_same_values_no_conflict(self):
        merged, result = merge_dicts({"A": "1"}, {"A": "1"})
        assert merged == {"A": "1"}
        assert not result.has_conflicts

    def test_source_wins(self):
        merged, result = merge_dicts(
            {"A": "new"}, {"A": "old"}, ConflictStrategy.SOURCE_WINS
        )
        assert merged["A"] == "new"
        assert result.has_conflicts
        assert result.conflicts[0].resolution == "source"

    def test_target_wins(self):
        merged, result = merge_dicts(
            {"A": "new"}, {"A": "old"}, ConflictStrategy.TARGET_WINS
        )
        assert merged["A"] == "old"
        assert result.conflicts[0].resolution == "target"

    def test_skip(self):
        merged, result = merge_dicts(
            {"A": "new"}, {"A": "old"}, ConflictStrategy.SKIP
        )
        assert merged["A"] == "old"
        assert result.skipped == 1

    def test_error_raises(self):
        with pytest.raises(ValueError, match="Merge conflict"):
            merge_dicts({"A": "new"}, {"A": "old"}, ConflictStrategy.ERROR)

    def test_empty_source(self):
        merged, result = merge_dicts({}, {"A": "1"})
        assert merged == {"A": "1"}
        assert result.merged == 0

    def test_empty_target(self):
        merged, result = merge_dicts({"A": "1"}, {})
        assert merged == {"A": "1"}
        assert result.merged == 1

    def test_mixed(self):
        source = {"A": "1", "B": "new", "C": "3"}
        target = {"B": "old", "D": "4"}
        merged, result = merge_dicts(source, target)
        assert merged == {"A": "1", "B": "new", "C": "3", "D": "4"}
        assert len(result.new_vars) == 2  # A and C
        assert len(result.updated_vars) == 1  # B


class TestMergeResult:
    def test_total(self):
        r = MergeResult(merged=3, skipped=2)
        assert r.total == 5

    def test_has_conflicts(self):
        r = MergeResult()
        assert not r.has_conflicts
        r.conflicts.append(MergeConflict("K", "e", "a", "b"))
        assert r.has_conflicts

    def test_summary(self):
        r = MergeResult(merged=3, skipped=1)
        r.new_vars = ["A"]
        r.updated_vars = ["B"]
        r.conflicts = [MergeConflict("B", "e", "old", "new")]
        s = r.summary()
        assert s["merged"] == 3
        assert s["skipped"] == 1
        assert s["conflicts"] == 1
        assert s["new"] == 1
        assert s["updated"] == 1


class TestMergeEnvironments:
    def test_merge(self, tmp_path):
        v = Vault(path=tmp_path / ".envault.json", password="pw")
        v.set("A", "1", "dev")
        v.set("B", "2", "dev")
        v.set("C", "3", "staging")
        result = merge_environments(v, "dev", "staging")
        assert result.merged == 2
        assert v.get("A", "staging") == "1"
        assert v.get("C", "staging") == "3"

    def test_merge_with_conflict(self, tmp_path):
        v = Vault(path=tmp_path / ".envault.json", password="pw")
        v.set("A", "dev-val", "dev")
        v.set("A", "staging-val", "staging")
        result = merge_environments(v, "dev", "staging", ConflictStrategy.SOURCE_WINS)
        assert v.get("A", "staging") == "dev-val"
        assert result.has_conflicts


class TestMergeVaults:
    def test_merge(self, tmp_path):
        src = Vault(path=tmp_path / "src.json", password="pw")
        src.set("A", "1")
        src.set("B", "2")

        tgt = Vault(path=tmp_path / "tgt.json", password="pw")
        tgt.set("C", "3")

        result = merge_vaults(src, tgt)
        assert tgt.get("A") == "1"
        assert tgt.get("B") == "2"
        assert tgt.get("C") == "3"
        assert result.merged == 2

    def test_merge_with_conflict(self, tmp_path):
        src = Vault(path=tmp_path / "src.json", password="pw")
        src.set("KEY", "src-val")

        tgt = Vault(path=tmp_path / "tgt.json", password="pw")
        tgt.set("KEY", "tgt-val")

        result = merge_vaults(src, tgt, strategy=ConflictStrategy.TARGET_WINS)
        assert tgt.get("KEY") == "tgt-val"


class TestDiffAndMerge:
    def test_include_filter(self):
        merged, result = diff_and_merge(
            {"A": "1", "B": "2", "C": "3"},
            {"D": "4"},
            include={"A", "C"},
        )
        assert "A" in merged
        assert "C" in merged
        assert "B" not in merged
        assert "D" in merged

    def test_exclude_filter(self):
        merged, result = diff_and_merge(
            {"A": "1", "B": "2", "C": "3"},
            {},
            exclude={"B"},
        )
        assert "A" in merged
        assert "B" not in merged
        assert "C" in merged

    def test_both_filters(self):
        merged, result = diff_and_merge(
            {"A": "1", "B": "2", "C": "3"},
            {},
            include={"A", "B"},
            exclude={"B"},
        )
        assert "A" in merged
        assert "B" not in merged
        assert "C" not in merged

    def test_no_filters(self):
        merged, result = diff_and_merge(
            {"A": "1"},
            {"B": "2"},
        )
        assert merged == {"A": "1", "B": "2"}


class TestConflictStrategy:
    def test_values(self):
        assert ConflictStrategy.SOURCE_WINS.value == "source_wins"
        assert ConflictStrategy.TARGET_WINS.value == "target_wins"
        assert ConflictStrategy.ERROR.value == "error"
        assert ConflictStrategy.SKIP.value == "skip"
