"""Tests for envault.groups module."""

import pytest

from envault.groups import (
    GroupManager,
    VariableGroup,
    create_default_groups,
)


class TestVariableGroup:
    def test_create(self):
        g = VariableGroup("database", prefix="DB_")
        assert g.name == "database"
        assert g.prefix == "DB_"

    def test_count(self):
        g = VariableGroup("test", variables=["A", "B", "C"])
        assert g.count == 3

    def test_matches_by_prefix(self):
        g = VariableGroup("db", prefix="DB_")
        assert g.matches("DB_HOST") is True
        assert g.matches("API_KEY") is False

    def test_matches_by_variable(self):
        g = VariableGroup("custom", variables=["SPECIAL_VAR"])
        assert g.matches("SPECIAL_VAR") is True
        assert g.matches("OTHER") is False

    def test_matches_empty_prefix(self):
        g = VariableGroup("custom", variables=["A"])
        assert g.matches("B") is False

    def test_to_dict_from_dict(self):
        g = VariableGroup("db", "DB_", "Database vars", ["DB_HOST"])
        d = g.to_dict()
        r = VariableGroup.from_dict(d)
        assert r.name == "db"
        assert r.prefix == "DB_"
        assert r.variables == ["DB_HOST"]


class TestGroupManager:
    @pytest.fixture
    def mgr(self):
        return GroupManager()

    def test_create_group(self, mgr):
        g = mgr.create_group("db", prefix="DB_")
        assert g.name == "db"
        assert len(mgr) == 1

    def test_add_group(self, mgr):
        mgr.add_group(VariableGroup("test"))
        assert len(mgr) == 1

    def test_remove_group(self, mgr):
        mgr.create_group("test")
        assert mgr.remove_group("test") is True
        assert len(mgr) == 0

    def test_remove_nonexistent(self, mgr):
        assert mgr.remove_group("nope") is False

    def test_get_group(self, mgr):
        mgr.create_group("db", prefix="DB_")
        g = mgr.get_group("db")
        assert g is not None
        assert g.prefix == "DB_"

    def test_get_nonexistent(self, mgr):
        assert mgr.get_group("nope") is None

    def test_list_groups(self, mgr):
        mgr.create_group("b")
        mgr.create_group("a")
        groups = mgr.list_groups()
        assert [g.name for g in groups] == ["a", "b"]

    def test_find_group(self, mgr):
        mgr.create_group("db", prefix="DB_")
        mgr.create_group("api", prefix="API_")
        assert mgr.find_group("DB_HOST").name == "db"
        assert mgr.find_group("API_KEY").name == "api"
        assert mgr.find_group("OTHER") is None

    def test_find_all_groups(self, mgr):
        mgr.create_group("db", prefix="DB_")
        mgr.create_group("critical", variables=["DB_PASSWORD"])
        groups = mgr.find_all_groups("DB_PASSWORD")
        assert len(groups) == 2

    def test_categorize(self, mgr):
        mgr.create_group("db", prefix="DB_")
        mgr.create_group("api", prefix="API_")
        result = mgr.categorize(["DB_HOST", "DB_PORT", "API_KEY", "OTHER"])
        assert result["db"] == ["DB_HOST", "DB_PORT"]
        assert result["api"] == ["API_KEY"]
        assert result["ungrouped"] == ["OTHER"]

    def test_categorize_empty(self, mgr):
        result = mgr.categorize([])
        assert result == {}

    def test_add_variable_to_group(self, mgr):
        mgr.create_group("custom")
        assert mgr.add_variable_to_group("MY_VAR", "custom") is True
        assert mgr.get_group("custom").matches("MY_VAR") is True

    def test_add_variable_to_nonexistent(self, mgr):
        assert mgr.add_variable_to_group("VAR", "nope") is False

    def test_add_variable_duplicate(self, mgr):
        mgr.create_group("custom", variables=["A"])
        mgr.add_variable_to_group("A", "custom")
        assert mgr.get_group("custom").variables.count("A") == 1

    def test_remove_variable_from_group(self, mgr):
        mgr.create_group("custom", variables=["A", "B"])
        assert mgr.remove_variable_from_group("A", "custom") is True
        assert "A" not in mgr.get_group("custom").variables

    def test_remove_variable_nonexistent(self, mgr):
        mgr.create_group("custom")
        assert mgr.remove_variable_from_group("NOPE", "custom") is False

    def test_to_list_from_list(self, mgr):
        mgr.create_group("a", prefix="A_")
        mgr.create_group("b", variables=["X"])
        data = mgr.to_list()
        restored = GroupManager.from_list(data)
        assert len(restored) == 2
        assert restored.get_group("a").prefix == "A_"

    def test_contains(self, mgr):
        mgr.create_group("db")
        assert "db" in mgr
        assert "nope" not in mgr


class TestCreateDefaultGroups:
    def test_has_common_groups(self):
        mgr = create_default_groups()
        assert len(mgr) >= 5
        assert mgr.get_group("database") is not None
        assert mgr.get_group("api") is not None
        assert mgr.get_group("auth") is not None

    def test_default_groups_match(self):
        mgr = create_default_groups()
        assert mgr.find_group("DB_HOST").name == "database"
        assert mgr.find_group("API_KEY").name == "api"
        assert mgr.find_group("AWS_REGION").name == "aws"
