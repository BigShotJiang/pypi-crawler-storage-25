"""Tests for envault.inheritance module."""

import pytest

from envault.inheritance import (
    InheritanceConfig,
    find_inherited,
    find_overrides,
    resolve_variables,
)
from envault.vault import Vault


@pytest.fixture
def vault(tmp_path):
    return Vault(path=tmp_path / ".envault.json", password="pw")


class TestInheritanceConfig:
    def test_set_parent(self):
        config = InheritanceConfig()
        config.set_parent("staging", "default")
        assert config.get_parent("staging") == "default"

    def test_self_inheritance_raises(self):
        config = InheritanceConfig()
        with pytest.raises(ValueError, match="cannot inherit from itself"):
            config.set_parent("dev", "dev")

    def test_circular_raises(self):
        config = InheritanceConfig()
        config.set_parent("staging", "dev")
        config.set_parent("dev", "base")
        with pytest.raises(ValueError, match="Circular"):
            config.set_parent("base", "staging")

    def test_get_parent_none(self):
        config = InheritanceConfig()
        assert config.get_parent("dev") is None

    def test_get_chain_no_parent(self):
        config = InheritanceConfig()
        assert config.get_chain("dev") == ["dev"]

    def test_get_chain_single_parent(self):
        config = InheritanceConfig()
        config.set_parent("staging", "default")
        assert config.get_chain("staging") == ["staging", "default"]

    def test_get_chain_multi_level(self):
        config = InheritanceConfig()
        config.set_parent("prod-us", "prod")
        config.set_parent("prod", "default")
        chain = config.get_chain("prod-us")
        assert chain == ["prod-us", "prod", "default"]

    def test_remove_parent(self):
        config = InheritanceConfig()
        config.set_parent("staging", "dev")
        assert config.remove_parent("staging") is True
        assert config.get_parent("staging") is None

    def test_remove_nonexistent(self):
        config = InheritanceConfig()
        assert config.remove_parent("nope") is False

    def test_to_dict_from_dict(self):
        config = InheritanceConfig()
        config.set_parent("staging", "dev")
        config.set_parent("prod", "dev")
        d = config.to_dict()
        restored = InheritanceConfig.from_dict(d)
        assert restored.get_parent("staging") == "dev"
        assert restored.get_parent("prod") == "dev"


class TestResolveVariables:
    def test_no_inheritance(self, vault):
        config = InheritanceConfig()
        vault.set("A", "1", "dev")
        result = resolve_variables(vault, "dev", config)
        assert result == {"A": "1"}

    def test_inherits_from_parent(self, vault):
        config = InheritanceConfig()
        config.set_parent("staging", "default")
        vault.set("DB_HOST", "localhost", "default")
        vault.set("DB_PORT", "5432", "default")
        result = resolve_variables(vault, "staging", config)
        assert result["DB_HOST"] == "localhost"
        assert result["DB_PORT"] == "5432"

    def test_child_overrides_parent(self, vault):
        config = InheritanceConfig()
        config.set_parent("prod", "default")
        vault.set("DB_HOST", "localhost", "default")
        vault.set("DB_HOST", "prod-db.example.com", "prod")
        result = resolve_variables(vault, "prod", config)
        assert result["DB_HOST"] == "prod-db.example.com"

    def test_multi_level_inheritance(self, vault):
        config = InheritanceConfig()
        config.set_parent("prod-us", "prod")
        config.set_parent("prod", "default")
        vault.set("APP", "myapp", "default")
        vault.set("REGION", "global", "prod")
        vault.set("REGION", "us-east-1", "prod-us")
        result = resolve_variables(vault, "prod-us", config)
        assert result["APP"] == "myapp"  # from default
        assert result["REGION"] == "us-east-1"  # overridden

    def test_child_specific_vars(self, vault):
        config = InheritanceConfig()
        config.set_parent("staging", "default")
        vault.set("SHARED", "val", "default")
        vault.set("STAGING_ONLY", "x", "staging")
        result = resolve_variables(vault, "staging", config)
        assert "SHARED" in result
        assert "STAGING_ONLY" in result


class TestFindOverrides:
    def test_no_parent(self, vault):
        config = InheritanceConfig()
        vault.set("A", "1", "dev")
        assert find_overrides(vault, "dev", config) == {}

    def test_finds_overrides(self, vault):
        config = InheritanceConfig()
        config.set_parent("prod", "default")
        vault.set("A", "1", "default")
        vault.set("B", "2", "default")
        vault.set("A", "prod-1", "prod")
        overrides = find_overrides(vault, "prod", config)
        assert "A" in overrides
        assert overrides["A"] == "default"
        assert "B" not in overrides

    def test_no_overrides(self, vault):
        config = InheritanceConfig()
        config.set_parent("staging", "default")
        vault.set("A", "1", "default")
        vault.set("B", "2", "staging")
        overrides = find_overrides(vault, "staging", config)
        assert overrides == {}


class TestFindInherited:
    def test_no_parent(self, vault):
        config = InheritanceConfig()
        assert find_inherited(vault, "dev", config) == {}

    def test_finds_inherited(self, vault):
        config = InheritanceConfig()
        config.set_parent("staging", "default")
        vault.set("A", "1", "default")
        vault.set("B", "2", "default")
        vault.set("A", "override", "staging")
        inherited = find_inherited(vault, "staging", config)
        assert "B" in inherited
        assert inherited["B"] == "default"
        assert "A" not in inherited  # overridden

    def test_multi_level(self, vault):
        config = InheritanceConfig()
        config.set_parent("prod", "default")
        config.set_parent("prod-us", "prod")
        vault.set("BASE", "val", "default")
        vault.set("MID", "val", "prod")
        inherited = find_inherited(vault, "prod-us", config)
        assert "BASE" in inherited
        assert inherited["BASE"] == "default"
        assert "MID" in inherited
        assert inherited["MID"] == "prod"
