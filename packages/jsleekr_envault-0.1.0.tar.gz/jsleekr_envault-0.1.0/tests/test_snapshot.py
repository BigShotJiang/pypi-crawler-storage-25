"""Tests for envault.snapshot module."""

import pytest

from envault.snapshot import (
    Snapshot,
    SnapshotDiff,
    VarSnapshot,
    compare_snapshots,
    create_snapshot,
    hash_value,
)


class TestHashValue:
    def test_deterministic(self):
        assert hash_value("test") == hash_value("test")

    def test_different_values(self):
        assert hash_value("a") != hash_value("b")

    def test_length(self):
        assert len(hash_value("test")) == 16


class TestVarSnapshot:
    def test_create(self):
        vs = VarSnapshot("KEY", "abc123", "dev")
        assert vs.name == "KEY"
        assert vs.value_hash == "abc123"
        assert vs.environment == "dev"

    def test_to_dict_from_dict(self):
        vs = VarSnapshot("KEY", "hash", "prod", tags=["db"])
        d = vs.to_dict()
        restored = VarSnapshot.from_dict(d)
        assert restored.name == "KEY"
        assert restored.tags == ["db"]


class TestSnapshot:
    def test_var_count(self):
        snap = Snapshot("id", 0, "label", [
            VarSnapshot("A", "h1", "dev"),
            VarSnapshot("B", "h2", "dev"),
        ])
        assert snap.var_count == 2

    def test_environments(self):
        snap = Snapshot("id", 0, "", [
            VarSnapshot("A", "h1", "dev"),
            VarSnapshot("B", "h2", "prod"),
        ])
        assert snap.environments == ["dev", "prod"]

    def test_get_vars_all(self):
        snap = Snapshot("id", 0, "", [
            VarSnapshot("A", "h1", "dev"),
            VarSnapshot("B", "h2", "prod"),
        ])
        assert len(snap.get_vars()) == 2

    def test_get_vars_filtered(self):
        snap = Snapshot("id", 0, "", [
            VarSnapshot("A", "h1", "dev"),
            VarSnapshot("B", "h2", "prod"),
        ])
        assert len(snap.get_vars("dev")) == 1

    def test_to_dict_from_dict(self):
        snap = Snapshot("id1", 100.0, "v1", [
            VarSnapshot("A", "h1", "dev"),
        ], {"author": "test"})
        d = snap.to_dict()
        restored = Snapshot.from_dict(d)
        assert restored.id == "id1"
        assert restored.label == "v1"
        assert restored.var_count == 1
        assert restored.metadata["author"] == "test"


class TestCreateSnapshot:
    def test_creates_snapshot(self):
        variables = {"dev": {"A": "1", "B": "2"}}
        snap = create_snapshot(variables, label="test")
        assert snap.var_count == 2
        assert snap.label == "test"
        assert len(snap.id) == 12

    def test_multiple_environments(self):
        variables = {
            "dev": {"A": "1"},
            "prod": {"B": "2"},
        }
        snap = create_snapshot(variables)
        assert snap.environments == ["dev", "prod"]

    def test_hashes_values(self):
        variables = {"dev": {"KEY": "secret"}}
        snap = create_snapshot(variables)
        assert snap.variables[0].value_hash == hash_value("secret")

    def test_with_metadata(self):
        snap = create_snapshot({"dev": {"A": "1"}}, metadata={"version": 2})
        assert snap.metadata["version"] == 2

    def test_empty(self):
        snap = create_snapshot({})
        assert snap.var_count == 0


class TestCompareSnapshots:
    def test_identical(self):
        vars = {"dev": {"A": "1", "B": "2"}}
        s1 = create_snapshot(vars, label="s1")
        s2 = create_snapshot(vars, label="s2")
        diff = compare_snapshots(s1, s2)
        assert not diff.has_changes
        assert len(diff.unchanged) == 2

    def test_added(self):
        s1 = create_snapshot({"dev": {"A": "1"}})
        s2 = create_snapshot({"dev": {"A": "1", "B": "2"}})
        diff = compare_snapshots(s1, s2)
        assert diff.has_changes
        assert "dev:B" in diff.added

    def test_removed(self):
        s1 = create_snapshot({"dev": {"A": "1", "B": "2"}})
        s2 = create_snapshot({"dev": {"A": "1"}})
        diff = compare_snapshots(s1, s2)
        assert "dev:B" in diff.removed

    def test_changed(self):
        s1 = create_snapshot({"dev": {"A": "old"}})
        s2 = create_snapshot({"dev": {"A": "new"}})
        diff = compare_snapshots(s1, s2)
        assert "dev:A" in diff.changed

    def test_filter_environment(self):
        s1 = create_snapshot({"dev": {"A": "1"}, "prod": {"B": "2"}})
        s2 = create_snapshot({"dev": {"A": "1"}, "prod": {"B": "changed"}})
        diff = compare_snapshots(s1, s2, environment="dev")
        assert not diff.has_changes

    def test_summary(self):
        s1 = create_snapshot({"dev": {"A": "1", "B": "2", "C": "3"}})
        s2 = create_snapshot({"dev": {"A": "1", "B": "changed", "D": "4"}})
        diff = compare_snapshots(s1, s2)
        s = diff.summary
        assert s["unchanged"] == 1
        assert s["changed"] == 1
        assert s["added"] == 1
        assert s["removed"] == 1


class TestSnapshotDiff:
    def test_has_changes_false(self):
        diff = SnapshotDiff("a", "b", unchanged=["x"])
        assert not diff.has_changes

    def test_has_changes_added(self):
        diff = SnapshotDiff("a", "b", added=["x"])
        assert diff.has_changes

    def test_has_changes_removed(self):
        diff = SnapshotDiff("a", "b", removed=["x"])
        assert diff.has_changes

    def test_has_changes_changed(self):
        diff = SnapshotDiff("a", "b", changed=["x"])
        assert diff.has_changes
