"""Tests for envault.lock module."""

import json
import os
import time

import pytest

from envault.lock import (
    DEFAULT_TIMEOUT,
    LockError,
    LockInfo,
    VaultLock,
)


class TestLockInfo:
    def test_create(self):
        info = LockInfo("alice", 1234, time.time())
        assert info.holder == "alice"
        assert info.pid == 1234

    def test_to_dict_from_dict(self):
        info = LockInfo("alice", 42, 1000.0, "myhost")
        d = info.to_dict()
        restored = LockInfo.from_dict(d)
        assert restored.holder == "alice"
        assert restored.pid == 42
        assert restored.hostname == "myhost"

    def test_age(self):
        info = LockInfo("a", 1, time.time() - 10)
        assert 9 < info.age < 12

    def test_is_stale(self):
        info = LockInfo("a", 1, time.time() - 600)
        assert info.is_stale is True

    def test_not_stale(self):
        info = LockInfo("a", 1, time.time())
        assert info.is_stale is False

    def test_from_dict_defaults(self):
        d = {}
        info = LockInfo.from_dict(d)
        assert info.holder == "unknown"
        assert info.pid == 0


class TestVaultLock:
    @pytest.fixture
    def vault_path(self, tmp_path):
        p = tmp_path / ".envault.json"
        p.write_text("{}")
        return p

    def test_acquire_release(self, vault_path):
        lock = VaultLock(vault_path, holder="test")
        assert lock.acquire() is True
        assert lock.lock_path.exists()
        assert lock.release() is True
        assert not lock.lock_path.exists()

    def test_is_locked(self, vault_path):
        lock = VaultLock(vault_path, holder="test")
        assert lock.is_locked() is False
        lock.acquire()
        assert lock.is_locked() is True
        lock.release()
        assert lock.is_locked() is False

    def test_get_lock_info(self, vault_path):
        lock = VaultLock(vault_path, holder="alice")
        lock.acquire()
        info = lock.get_lock_info()
        assert info is not None
        assert info.holder == "alice"
        assert info.pid == os.getpid()
        lock.release()

    def test_get_lock_info_none(self, vault_path):
        lock = VaultLock(vault_path)
        assert lock.get_lock_info() is None

    def test_context_manager(self, vault_path):
        with VaultLock(vault_path, holder="test") as lock:
            assert lock.is_locked()
        lock2 = VaultLock(vault_path)
        assert not lock2.is_locked()

    def test_force_release(self, vault_path):
        lock1 = VaultLock(vault_path, holder="alice")
        lock1.acquire()

        lock2 = VaultLock(vault_path, holder="bob")
        assert lock2.force_release() is True
        assert not lock2.is_locked()

    def test_force_release_no_lock(self, vault_path):
        lock = VaultLock(vault_path)
        assert lock.force_release() is False

    def test_release_without_acquire(self, vault_path):
        lock = VaultLock(vault_path)
        assert lock.release() is False

    def test_stale_lock_auto_released(self, vault_path):
        # Create a stale lock manually
        lock_path = vault_path.with_suffix(vault_path.suffix + ".lock")
        stale_info = {
            "holder": "old-process",
            "pid": 99999,
            "timestamp": time.time() - 600,
        }
        lock_path.write_text(json.dumps(stale_info))

        lock = VaultLock(vault_path, holder="new", timeout=1)
        assert lock.acquire() is True
        lock.release()

    def test_stale_lock_detected(self, vault_path):
        lock_path = vault_path.with_suffix(vault_path.suffix + ".lock")
        stale_info = {
            "holder": "old",
            "pid": 99999,
            "timestamp": time.time() - 600,
        }
        lock_path.write_text(json.dumps(stale_info))

        lock = VaultLock(vault_path)
        assert lock.is_locked() is False

    def test_lock_path(self, vault_path):
        lock = VaultLock(vault_path)
        assert lock.lock_path.name == ".envault.json.lock"

    def test_default_holder(self, vault_path):
        lock = VaultLock(vault_path)
        assert str(os.getpid()) in lock.holder

    def test_corrupted_lock_file(self, vault_path):
        lock_path = vault_path.with_suffix(vault_path.suffix + ".lock")
        lock_path.write_text("not json")
        lock = VaultLock(vault_path)
        # Should handle gracefully
        assert lock.get_lock_info() is None


class TestLockError:
    def test_basic(self):
        err = LockError(message="test error")
        assert "test error" in str(err)

    def test_with_lock_info(self):
        info = LockInfo("alice", 42, time.time())
        err = LockError(info)
        assert "alice" in str(err)
        assert "42" in str(err)

    def test_attributes(self):
        info = LockInfo("bob", 1, 0)
        err = LockError(info)
        assert err.lock_info is info
