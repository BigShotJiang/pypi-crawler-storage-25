"""Tests for envault.history module."""

import time

import pytest

from envault.history import ActionType, HistoryEntry, HistoryLog


class TestHistoryEntry:
    def test_create(self):
        entry = HistoryEntry(
            timestamp=time.time(),
            action=ActionType.SET,
            variable="KEY",
            environment="dev",
        )
        assert entry.variable == "KEY"
        assert entry.action == ActionType.SET

    def test_to_dict(self):
        entry = HistoryEntry(
            timestamp=1000.0,
            action=ActionType.DELETE,
            variable="KEY",
            environment="prod",
            details={"reason": "deprecated"},
        )
        d = entry.to_dict()
        assert d["action"] == "delete"
        assert d["variable"] == "KEY"
        assert d["details"]["reason"] == "deprecated"

    def test_from_dict(self):
        d = {
            "timestamp": 1000.0,
            "action": "set",
            "variable": "KEY",
            "environment": "dev",
            "details": {},
        }
        entry = HistoryEntry.from_dict(d)
        assert entry.action == ActionType.SET
        assert entry.variable == "KEY"

    def test_roundtrip(self):
        original = HistoryEntry(
            timestamp=1234.5,
            action=ActionType.RENAME,
            variable="OLD",
            environment="dev",
            details={"new_name": "NEW"},
        )
        restored = HistoryEntry.from_dict(original.to_dict())
        assert restored.timestamp == original.timestamp
        assert restored.action == original.action
        assert restored.details == original.details

    def test_from_dict_missing_details(self):
        d = {
            "timestamp": 1.0,
            "action": "set",
            "variable": "K",
            "environment": "dev",
        }
        entry = HistoryEntry.from_dict(d)
        assert entry.details == {}


class TestHistoryLog:
    def test_record(self):
        log = HistoryLog()
        entry = log.record(ActionType.SET, "KEY", "dev")
        assert entry.variable == "KEY"
        assert len(log) == 1

    def test_record_with_details(self):
        log = HistoryLog()
        entry = log.record(ActionType.SET, "KEY", "dev", details={"old": "v1"})
        assert entry.details["old"] == "v1"

    def test_entries_property(self):
        log = HistoryLog()
        log.record(ActionType.SET, "A", "dev")
        log.record(ActionType.SET, "B", "dev")
        assert len(log.entries) == 2
        # Verify it's a copy
        log.entries.clear()
        assert len(log) == 2

    def test_max_entries(self):
        log = HistoryLog(max_entries=5)
        for i in range(10):
            log.record(ActionType.SET, f"K{i}", "dev")
        assert len(log) == 5

    def test_get_variable_history(self):
        log = HistoryLog()
        log.record(ActionType.SET, "A", "dev")
        log.record(ActionType.SET, "B", "dev")
        log.record(ActionType.SET, "A", "dev")
        history = log.get_variable_history("A")
        assert len(history) == 2
        # Newest first
        assert history[0].timestamp >= history[1].timestamp

    def test_get_variable_history_with_env(self):
        log = HistoryLog()
        log.record(ActionType.SET, "A", "dev")
        log.record(ActionType.SET, "A", "prod")
        history = log.get_variable_history("A", "dev")
        assert len(history) == 1

    def test_get_environment_history(self):
        log = HistoryLog()
        log.record(ActionType.SET, "A", "dev")
        log.record(ActionType.SET, "B", "prod")
        log.record(ActionType.DELETE, "C", "dev")
        history = log.get_environment_history("dev")
        assert len(history) == 2

    def test_get_recent(self):
        log = HistoryLog()
        for i in range(20):
            log.record(ActionType.SET, f"K{i}", "dev")
        recent = log.get_recent(5)
        assert len(recent) == 5
        assert recent[0].variable == "K19"

    def test_get_recent_fewer_than_count(self):
        log = HistoryLog()
        log.record(ActionType.SET, "A", "dev")
        recent = log.get_recent(10)
        assert len(recent) == 1

    def test_filter_by_action(self):
        log = HistoryLog()
        log.record(ActionType.SET, "A", "dev")
        log.record(ActionType.DELETE, "B", "dev")
        log.record(ActionType.SET, "C", "dev")
        sets = log.filter_by_action(ActionType.SET)
        assert len(sets) == 2
        deletes = log.filter_by_action(ActionType.DELETE)
        assert len(deletes) == 1

    def test_clear(self):
        log = HistoryLog()
        log.record(ActionType.SET, "A", "dev")
        log.record(ActionType.SET, "B", "dev")
        count = log.clear()
        assert count == 2
        assert len(log) == 0

    def test_to_list_from_list(self):
        log = HistoryLog()
        log.record(ActionType.SET, "A", "dev")
        log.record(ActionType.DELETE, "B", "prod")
        data = log.to_list()
        restored = HistoryLog.from_list(data)
        assert len(restored) == 2
        assert restored.entries[0].variable == "A"

    def test_bool_empty(self):
        log = HistoryLog()
        assert not log

    def test_bool_nonempty(self):
        log = HistoryLog()
        log.record(ActionType.SET, "A", "dev")
        assert log


class TestActionType:
    def test_values(self):
        assert ActionType.SET.value == "set"
        assert ActionType.DELETE.value == "delete"
        assert ActionType.RENAME.value == "rename"
        assert ActionType.IMPORT.value == "import"
        assert ActionType.ROTATE.value == "rotate"
