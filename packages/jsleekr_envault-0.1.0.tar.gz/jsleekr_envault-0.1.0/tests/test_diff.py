"""Tests for envault.diff module."""

import pytest

from envault.crypto import generate_key
from envault.diff import (
    ChangeType,
    DiffResult,
    VarChange,
    _mask_value,
    diff_environments,
    find_extra_vars,
    find_missing_vars,
)
from envault.vault import Vault


@pytest.fixture
def vault(tmp_path):
    return Vault(path=tmp_path / ".envault.json", password="test")


class TestMaskValue:
    def test_short_value_fully_masked(self):
        assert _mask_value("ab") == "**"

    def test_long_value_partially_masked(self):
        result = _mask_value("secret-password")
        assert result.startswith("se")
        assert result.endswith("rd")
        assert "*" in result

    def test_medium_value(self):
        result = _mask_value("abcdef")
        assert result == "******"

    def test_custom_visible(self):
        result = _mask_value("abcdefghij", visible=3)
        assert result.startswith("abc")
        assert result.endswith("hij")


class TestVarChange:
    def test_is_changed_added(self):
        c = VarChange("KEY", ChangeType.ADDED, new_value="v")
        assert c.is_changed is True

    def test_is_changed_unchanged(self):
        c = VarChange("KEY", ChangeType.UNCHANGED)
        assert c.is_changed is False

    def test_is_changed_modified(self):
        c = VarChange("KEY", ChangeType.MODIFIED, old_value="a", new_value="b")
        assert c.is_changed is True

    def test_is_changed_removed(self):
        c = VarChange("KEY", ChangeType.REMOVED, old_value="v")
        assert c.is_changed is True


class TestDiffResult:
    def test_categorization(self):
        result = DiffResult(
            source_env="dev",
            target_env="prod",
            changes=[
                VarChange("A", ChangeType.ADDED, new_value="1"),
                VarChange("B", ChangeType.REMOVED, old_value="2"),
                VarChange("C", ChangeType.MODIFIED, old_value="3", new_value="4"),
                VarChange("D", ChangeType.UNCHANGED, old_value="5", new_value="5"),
            ],
        )
        assert len(result.added) == 1
        assert len(result.removed) == 1
        assert len(result.modified) == 1
        assert len(result.unchanged) == 1

    def test_has_changes_true(self):
        result = DiffResult("a", "b", [VarChange("K", ChangeType.ADDED, new_value="v")])
        assert result.has_changes is True

    def test_has_changes_false(self):
        result = DiffResult("a", "b", [VarChange("K", ChangeType.UNCHANGED)])
        assert result.has_changes is False

    def test_has_changes_empty(self):
        result = DiffResult("a", "b", [])
        assert result.has_changes is False

    def test_summary(self):
        result = DiffResult(
            "a", "b",
            [
                VarChange("A", ChangeType.ADDED, new_value="1"),
                VarChange("B", ChangeType.REMOVED, old_value="2"),
            ],
        )
        summary = result.summary
        assert summary["added"] == 1
        assert summary["removed"] == 1
        assert summary["total"] == 2

    def test_to_text_basic(self):
        result = DiffResult(
            "dev", "prod",
            [VarChange("KEY", ChangeType.ADDED, new_value="val")],
        )
        text = result.to_text()
        assert "dev" in text
        assert "prod" in text
        assert "+ KEY" in text

    def test_to_text_with_values(self):
        result = DiffResult(
            "dev", "prod",
            [VarChange("KEY", ChangeType.MODIFIED, old_value="old", new_value="new")],
        )
        text = result.to_text(show_values=True, mask=False)
        assert "old" in text
        assert "new" in text

    def test_to_text_with_masked_values(self):
        result = DiffResult(
            "dev", "prod",
            [VarChange("KEY", ChangeType.MODIFIED, old_value="secret-old", new_value="secret-new")],
        )
        text = result.to_text(show_values=True, mask=True)
        assert "secret-old" not in text
        assert "*" in text

    def test_to_text_removed_with_values(self):
        result = DiffResult(
            "dev", "prod",
            [VarChange("KEY", ChangeType.REMOVED, old_value="gone")],
        )
        text = result.to_text(show_values=True, mask=False)
        assert "gone" in text

    def test_to_text_added_with_values(self):
        result = DiffResult(
            "dev", "prod",
            [VarChange("KEY", ChangeType.ADDED, new_value="new")],
        )
        text = result.to_text(show_values=True, mask=False)
        assert "new" in text


class TestDiffEnvironments:
    def test_identical_envs(self, vault):
        vault.set("KEY", "val", "dev")
        vault.set("KEY", "val", "prod")
        result = diff_environments(vault, "dev", "prod")
        assert not result.has_changes
        assert len(result.unchanged) == 1

    def test_added(self, vault):
        vault.set("A", "1", "dev")
        vault.set("A", "1", "prod")
        vault.set("B", "2", "prod")
        result = diff_environments(vault, "dev", "prod")
        assert len(result.added) == 1
        assert result.added[0].name == "B"

    def test_removed(self, vault):
        vault.set("A", "1", "dev")
        vault.set("B", "2", "dev")
        vault.set("A", "1", "prod")
        result = diff_environments(vault, "dev", "prod")
        assert len(result.removed) == 1
        assert result.removed[0].name == "B"

    def test_modified(self, vault):
        vault.set("KEY", "old", "dev")
        vault.set("KEY", "new", "prod")
        result = diff_environments(vault, "dev", "prod")
        assert len(result.modified) == 1
        assert result.modified[0].old_value == "old"
        assert result.modified[0].new_value == "new"

    def test_complex_diff(self, vault):
        vault.set("SHARED", "same", "dev")
        vault.set("SHARED", "same", "prod")
        vault.set("DEV_ONLY", "x", "dev")
        vault.set("PROD_ONLY", "y", "prod")
        vault.set("CHANGED", "a", "dev")
        vault.set("CHANGED", "b", "prod")
        result = diff_environments(vault, "dev", "prod")
        assert len(result.unchanged) == 1
        assert len(result.removed) == 1
        assert len(result.added) == 1
        assert len(result.modified) == 1

    def test_empty_envs(self, vault):
        result = diff_environments(vault, "dev", "prod")
        assert not result.has_changes
        assert len(result.changes) == 0


class TestFindMissingVars:
    def test_finds_missing(self, vault):
        vault.set("A", "1", "dev")
        vault.set("B", "2", "dev")
        vault.set("A", "1", "prod")
        missing = find_missing_vars(vault, "dev", "prod")
        assert missing == ["B"]

    def test_none_missing(self, vault):
        vault.set("A", "1", "dev")
        vault.set("A", "1", "prod")
        assert find_missing_vars(vault, "dev", "prod") == []

    def test_empty_reference(self, vault):
        vault.set("A", "1", "prod")
        assert find_missing_vars(vault, "dev", "prod") == []


class TestFindExtraVars:
    def test_finds_extra(self, vault):
        vault.set("A", "1", "dev")
        vault.set("A", "1", "prod")
        vault.set("B", "2", "prod")
        extra = find_extra_vars(vault, "dev", "prod")
        assert extra == ["B"]

    def test_none_extra(self, vault):
        vault.set("A", "1", "dev")
        vault.set("A", "1", "prod")
        assert find_extra_vars(vault, "dev", "prod") == []
