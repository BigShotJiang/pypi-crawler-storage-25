"""Tests for envault.security module."""

import pytest
from pathlib import Path

from envault.security import (
    SecurityIssue,
    SecurityReport,
    audit_variables,
    check_gitignore,
    check_password_strength,
    generate_gitignore_entries,
    is_sensitive_name,
    looks_like_secret,
)


class TestIsSensitiveName:
    def test_password(self):
        assert is_sensitive_name("DB_PASSWORD") is True
        assert is_sensitive_name("password") is True

    def test_secret(self):
        assert is_sensitive_name("JWT_SECRET") is True

    def test_token(self):
        assert is_sensitive_name("AUTH_TOKEN") is True

    def test_api_key(self):
        assert is_sensitive_name("API_KEY") is True
        assert is_sensitive_name("APIKEY") is True

    def test_private_key(self):
        assert is_sensitive_name("PRIVATE_KEY") is True

    def test_non_sensitive(self):
        assert is_sensitive_name("HOST") is False
        assert is_sensitive_name("PORT") is False
        assert is_sensitive_name("DEBUG") is False

    def test_credentials(self):
        assert is_sensitive_name("AWS_CREDENTIALS") is True

    def test_access_key(self):
        assert is_sensitive_name("AWS_ACCESS_KEY") is True


class TestLooksLikeSecret:
    def test_openai_key(self):
        assert looks_like_secret("sk-abc123def456") is True

    def test_github_pat(self):
        assert looks_like_secret("ghp_abcdef123456") is True

    def test_aws_access_key(self):
        assert looks_like_secret("AKIAIOSFODNN7EXAMPLE") is True

    def test_regular_value(self):
        assert looks_like_secret("hello") is False
        assert looks_like_secret("localhost") is False

    def test_slack_token(self):
        assert looks_like_secret("xoxb-123-456-abc") is True

    def test_jwt(self):
        jwt = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.abcdefghijk"
        assert looks_like_secret(jwt) is True


class TestCheckPasswordStrength:
    def test_strong_password(self):
        weaknesses = check_password_strength("MyStr0ng!Pass#2024")
        assert len(weaknesses) == 0

    def test_too_short(self):
        weaknesses = check_password_strength("Ab1!")
        assert any("short" in w for w in weaknesses)

    def test_no_uppercase(self):
        weaknesses = check_password_strength("abcdefgh123!")
        assert any("uppercase" in w for w in weaknesses)

    def test_no_lowercase(self):
        weaknesses = check_password_strength("ABCDEFGH123!")
        assert any("lowercase" in w for w in weaknesses)

    def test_no_numbers(self):
        weaknesses = check_password_strength("Abcdefghijkl!")
        assert any("numbers" in w for w in weaknesses)

    def test_no_special(self):
        weaknesses = check_password_strength("Abcdefgh1234")
        assert any("special" in w for w in weaknesses)

    def test_common_password(self):
        weaknesses = check_password_strength("password")
        assert any("common" in w for w in weaknesses)

    def test_medium_length(self):
        weaknesses = check_password_strength("Ab1!efgh")
        assert any("12 characters" in w for w in weaknesses)


class TestAuditVariables:
    def test_clean(self):
        report = audit_variables({"HOST": "localhost", "PORT": "8080"})
        assert report.is_clean

    def test_empty_secret(self):
        report = audit_variables({"API_KEY": ""})
        assert not report.is_clean
        assert report.medium_count == 1

    def test_short_secret(self):
        report = audit_variables({"PASSWORD": "abc"})
        assert report.high_count == 1

    def test_default_value(self):
        report = audit_variables({"DB_PASSWORD": "changeme"})
        assert report.high_count >= 1

    def test_with_environment(self):
        report = audit_variables({"TOKEN": ""}, environment="prod")
        assert report.issues[0].environment == "prod"


class TestSecurityReport:
    def test_empty(self):
        r = SecurityReport()
        assert r.is_clean
        assert r.high_count == 0

    def test_counts(self):
        r = SecurityReport(issues=[
            SecurityIssue("high", "test", "msg1"),
            SecurityIssue("high", "test", "msg2"),
            SecurityIssue("medium", "test", "msg3"),
            SecurityIssue("low", "test", "msg4"),
        ])
        assert r.high_count == 2
        assert r.medium_count == 1
        assert r.low_count == 1

    def test_to_text(self):
        r = SecurityReport(issues=[
            SecurityIssue("high", "test", "Critical issue", variable="KEY"),
        ])
        text = r.to_text()
        assert "HIGH" in text
        assert "Critical issue" in text
        assert "KEY" in text


class TestGenerateGitignore:
    def test_contains_entries(self):
        content = generate_gitignore_entries()
        assert ".envault.json" in content
        assert "*.envault.backup" in content
        assert ".env" in content
        assert "!.env.example" in content


class TestCheckGitignore:
    def test_missing_gitignore(self, tmp_path):
        warnings = check_gitignore(tmp_path)
        assert len(warnings) == 1
        assert ".gitignore" in warnings[0]

    def test_complete_gitignore(self, tmp_path):
        gi = tmp_path / ".gitignore"
        gi.write_text(".envault.json\n*.envault.backup\n.env\n")
        warnings = check_gitignore(tmp_path)
        assert len(warnings) == 0

    def test_missing_entries(self, tmp_path):
        gi = tmp_path / ".gitignore"
        gi.write_text(".env\n")
        warnings = check_gitignore(tmp_path)
        assert len(warnings) == 2  # missing .envault.json and *.envault.backup
