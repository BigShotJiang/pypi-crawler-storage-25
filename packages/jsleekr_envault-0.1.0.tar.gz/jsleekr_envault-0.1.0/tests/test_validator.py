"""Tests for envault.validator module."""

import pytest

from envault.validator import (
    RuleType,
    ValidationResult,
    ValidationRule,
    VariableSchema,
    _validate_email,
    _validate_max_length,
    _validate_min_length,
    _validate_not_empty,
    _validate_one_of,
    _validate_pattern,
    _validate_port,
    _validate_required,
    _validate_url,
)


class TestValidateRequired:
    def test_none_fails(self):
        assert _validate_required(None, {}) is not None

    def test_value_passes(self):
        assert _validate_required("val", {}) is None

    def test_empty_string_passes(self):
        assert _validate_required("", {}) is None


class TestValidateNotEmpty:
    def test_empty_fails(self):
        assert _validate_not_empty("", {}) is not None

    def test_whitespace_fails(self):
        assert _validate_not_empty("   ", {}) is not None

    def test_value_passes(self):
        assert _validate_not_empty("val", {}) is None

    def test_none_passes(self):
        assert _validate_not_empty(None, {}) is None


class TestValidatePattern:
    def test_matching(self):
        assert _validate_pattern("abc123", {"pattern": r"^[a-z0-9]+$"}) is None

    def test_not_matching(self):
        assert _validate_pattern("ABC", {"pattern": r"^[a-z]+$"}) is not None

    def test_none_passes(self):
        assert _validate_pattern(None, {"pattern": r".*"}) is None


class TestValidateMinLength:
    def test_too_short(self):
        assert _validate_min_length("ab", {"min": 5}) is not None

    def test_exact(self):
        assert _validate_min_length("abcde", {"min": 5}) is None

    def test_longer(self):
        assert _validate_min_length("abcdef", {"min": 5}) is None

    def test_none_passes(self):
        assert _validate_min_length(None, {"min": 5}) is None


class TestValidateMaxLength:
    def test_too_long(self):
        assert _validate_max_length("abcdef", {"max": 5}) is not None

    def test_exact(self):
        assert _validate_max_length("abcde", {"max": 5}) is None

    def test_shorter(self):
        assert _validate_max_length("abc", {"max": 5}) is None

    def test_none_passes(self):
        assert _validate_max_length(None, {"max": 5}) is None


class TestValidateOneOf:
    def test_valid(self):
        assert _validate_one_of("a", {"values": ["a", "b", "c"]}) is None

    def test_invalid(self):
        assert _validate_one_of("d", {"values": ["a", "b", "c"]}) is not None

    def test_none_passes(self):
        assert _validate_one_of(None, {"values": ["a"]}) is None


class TestValidateUrl:
    def test_valid_http(self):
        assert _validate_url("http://example.com", {}) is None

    def test_valid_https(self):
        assert _validate_url("https://example.com/path?q=1", {}) is None

    def test_invalid(self):
        assert _validate_url("not-a-url", {}) is not None

    def test_none_passes(self):
        assert _validate_url(None, {}) is None

    def test_ftp_fails(self):
        assert _validate_url("ftp://example.com", {}) is not None


class TestValidateEmail:
    def test_valid(self):
        assert _validate_email("user@example.com", {}) is None

    def test_invalid(self):
        assert _validate_email("not-email", {}) is not None

    def test_none_passes(self):
        assert _validate_email(None, {}) is None

    def test_missing_domain(self):
        assert _validate_email("user@", {}) is not None


class TestValidatePort:
    def test_valid(self):
        assert _validate_port("8080", {}) is None

    def test_min(self):
        assert _validate_port("1", {}) is None

    def test_max(self):
        assert _validate_port("65535", {}) is None

    def test_zero_fails(self):
        assert _validate_port("0", {}) is not None

    def test_too_high(self):
        assert _validate_port("65536", {}) is not None

    def test_not_a_number(self):
        assert _validate_port("abc", {}) is not None

    def test_none_passes(self):
        assert _validate_port(None, {}) is None


class TestValidationRule:
    def test_to_dict(self):
        rule = ValidationRule(RuleType.MIN_LENGTH, {"min": 5}, "Too short")
        d = rule.to_dict()
        assert d["rule_type"] == "min_length"
        assert d["params"]["min"] == 5
        assert d["message"] == "Too short"

    def test_from_dict(self):
        d = {"rule_type": "pattern", "params": {"pattern": "^[a-z]+$"}, "message": ""}
        rule = ValidationRule.from_dict(d)
        assert rule.rule_type == RuleType.PATTERN

    def test_roundtrip(self):
        original = ValidationRule(RuleType.ONE_OF, {"values": ["a", "b"]}, "Invalid")
        restored = ValidationRule.from_dict(original.to_dict())
        assert restored.rule_type == original.rule_type
        assert restored.params == original.params


class TestValidationResult:
    def test_is_valid_empty(self):
        r = ValidationResult()
        assert r.is_valid is True

    def test_error_count(self):
        from envault.validator import ValidationError
        r = ValidationResult(errors=[
            ValidationError("A", ValidationRule(RuleType.REQUIRED), "missing"),
        ])
        assert r.error_count == 1
        assert r.is_valid is False

    def test_messages(self):
        from envault.validator import ValidationError
        r = ValidationResult(errors=[
            ValidationError("KEY", ValidationRule(RuleType.REQUIRED), "is required"),
        ])
        msgs = r.messages()
        assert "KEY: is required" in msgs


class TestVariableSchema:
    def test_require(self):
        schema = VariableSchema()
        schema.require("DB_URL")
        result = schema.validate({})
        assert not result.is_valid

    def test_require_present(self):
        schema = VariableSchema()
        schema.require("DB_URL")
        result = schema.validate({"DB_URL": "postgres://..."})
        assert result.is_valid

    def test_not_empty(self):
        schema = VariableSchema()
        schema.not_empty("KEY")
        assert not schema.validate({"KEY": ""}).is_valid
        assert schema.validate({"KEY": "val"}).is_valid

    def test_pattern(self):
        schema = VariableSchema()
        schema.pattern("API_KEY", r"^sk-[a-z0-9]+$")
        assert schema.validate({"API_KEY": "sk-abc123"}).is_valid
        assert not schema.validate({"API_KEY": "bad"}).is_valid

    def test_min_length(self):
        schema = VariableSchema()
        schema.min_length("PASSWORD", 8)
        assert not schema.validate({"PASSWORD": "short"}).is_valid
        assert schema.validate({"PASSWORD": "long-enough"}).is_valid

    def test_max_length(self):
        schema = VariableSchema()
        schema.max_length("KEY", 10)
        assert not schema.validate({"KEY": "a" * 11}).is_valid
        assert schema.validate({"KEY": "short"}).is_valid

    def test_one_of(self):
        schema = VariableSchema()
        schema.one_of("ENV", ["dev", "staging", "prod"])
        assert schema.validate({"ENV": "dev"}).is_valid
        assert not schema.validate({"ENV": "local"}).is_valid

    def test_url(self):
        schema = VariableSchema()
        schema.url("ENDPOINT")
        assert schema.validate({"ENDPOINT": "https://api.example.com"}).is_valid
        assert not schema.validate({"ENDPOINT": "not-url"}).is_valid

    def test_email(self):
        schema = VariableSchema()
        schema.email("ADMIN_EMAIL")
        assert schema.validate({"ADMIN_EMAIL": "a@b.com"}).is_valid
        assert not schema.validate({"ADMIN_EMAIL": "bad"}).is_valid

    def test_port(self):
        schema = VariableSchema()
        schema.port("APP_PORT")
        assert schema.validate({"APP_PORT": "3000"}).is_valid
        assert not schema.validate({"APP_PORT": "abc"}).is_valid

    def test_multiple_rules(self):
        schema = VariableSchema()
        schema.require("KEY").not_empty("KEY").min_length("KEY", 5)
        result = schema.validate({"KEY": "ab"})
        assert not result.is_valid
        assert result.error_count == 1  # only min_length fails

    def test_multiple_variables(self):
        schema = VariableSchema()
        schema.require("A").require("B")
        result = schema.validate({"A": "1"})
        assert not result.is_valid  # B missing

    def test_custom_message(self):
        schema = VariableSchema()
        schema.require("KEY", message="KEY is mandatory!")
        result = schema.validate({})
        assert "KEY is mandatory!" in result.messages()[0]

    def test_chaining(self):
        schema = VariableSchema()
        s = schema.require("A").url("B").port("C")
        assert s is schema

    def test_get_rules(self):
        schema = VariableSchema()
        schema.require("KEY").min_length("KEY", 5)
        rules = schema.get_rules("KEY")
        assert len(rules) == 2

    def test_get_rules_empty(self):
        schema = VariableSchema()
        assert schema.get_rules("NOPE") == []

    def test_variables(self):
        schema = VariableSchema()
        schema.require("B").require("A")
        assert schema.variables() == ["A", "B"]

    def test_to_dict_from_dict(self):
        schema = VariableSchema()
        schema.require("A").url("B").min_length("A", 5)
        d = schema.to_dict()
        restored = VariableSchema.from_dict(d)
        assert sorted(restored.variables()) == ["A", "B"]
        assert len(restored.get_rules("A")) == 2
