"""Tests for envault.config module."""

import json

import pytest

from envault.config import (
    CONFIG_FILENAME,
    EnvaultConfig,
    find_project_root,
    load_config,
    save_config,
)


class TestEnvaultConfig:
    def test_defaults(self):
        config = EnvaultConfig()
        assert config.vault_path == ".envault.json"
        assert config.default_environment == "default"
        assert config.auto_backup is True
        assert config.max_backups == 5

    def test_to_dict(self):
        config = EnvaultConfig(vault_path="custom.json", max_backups=10)
        d = config.to_dict()
        assert d["vault_path"] == "custom.json"
        assert d["max_backups"] == 10

    def test_from_dict(self):
        d = {"vault_path": "test.json", "encryption_method": "key"}
        config = EnvaultConfig.from_dict(d)
        assert config.vault_path == "test.json"
        assert config.encryption_method == "key"

    def test_from_dict_defaults(self):
        config = EnvaultConfig.from_dict({})
        assert config.vault_path == ".envault.json"

    def test_roundtrip(self):
        original = EnvaultConfig(
            vault_path="custom.json",
            default_environment="dev",
            encryption_method="key",
            max_backups=3,
            inheritance={"staging": "dev"},
        )
        restored = EnvaultConfig.from_dict(original.to_dict())
        assert restored.vault_path == original.vault_path
        assert restored.inheritance == original.inheritance

    def test_merge(self):
        config = EnvaultConfig(vault_path="a.json", max_backups=5)
        merged = config.merge({"max_backups": 10, "warn_days": 14})
        assert merged.vault_path == "a.json"  # preserved
        assert merged.max_backups == 10  # overridden
        assert merged.warn_days == 14  # overridden


class TestLoadConfig:
    def test_no_config(self, tmp_path):
        config = load_config(tmp_path)
        assert config.vault_path == ".envault.json"  # defaults

    def test_from_envaultrc(self, tmp_path):
        rc = tmp_path / CONFIG_FILENAME
        rc.write_text(json.dumps({
            "vault_path": "secrets.json",
            "max_backups": 3,
        }))
        config = load_config(tmp_path)
        assert config.vault_path == "secrets.json"
        assert config.max_backups == 3

    def test_from_pyproject_toml(self, tmp_path):
        toml_content = """
[tool.envault]
vault_path = "my-vault.json"
max_backups = 7
"""
        (tmp_path / "pyproject.toml").write_text(toml_content)
        config = load_config(tmp_path)
        # Only works if tomllib available (Python 3.11+)
        try:
            import tomllib
            assert config.vault_path == "my-vault.json"
        except ImportError:
            pass  # Skip on older Python

    def test_envaultrc_takes_priority(self, tmp_path):
        rc = tmp_path / CONFIG_FILENAME
        rc.write_text(json.dumps({"vault_path": "from-rc.json"}))
        (tmp_path / "pyproject.toml").write_text("[tool.envault]\nvault_path = 'from-toml.json'\n")
        config = load_config(tmp_path)
        assert config.vault_path == "from-rc.json"

    def test_pyproject_without_envault_section(self, tmp_path):
        (tmp_path / "pyproject.toml").write_text("[project]\nname = 'test'\n")
        config = load_config(tmp_path)
        assert config.vault_path == ".envault.json"  # defaults


class TestSaveConfig:
    def test_saves_file(self, tmp_path):
        config = EnvaultConfig(vault_path="test.json", max_backups=3)
        path = save_config(config, tmp_path)
        assert path.exists()
        data = json.loads(path.read_text())
        assert data["vault_path"] == "test.json"

    def test_roundtrip(self, tmp_path):
        original = EnvaultConfig(
            vault_path="custom.json",
            encryption_method="key",
            inheritance={"prod": "base"},
        )
        save_config(original, tmp_path)
        loaded = load_config(tmp_path)
        assert loaded.vault_path == original.vault_path
        assert loaded.inheritance == original.inheritance


class TestFindProjectRoot:
    def test_finds_envaultrc(self, tmp_path):
        (tmp_path / CONFIG_FILENAME).write_text("{}")
        sub = tmp_path / "sub" / "dir"
        sub.mkdir(parents=True)
        root = find_project_root(sub)
        assert root == tmp_path

    def test_finds_envault_json(self, tmp_path):
        (tmp_path / ".envault.json").write_text("{}")
        sub = tmp_path / "deep" / "nested"
        sub.mkdir(parents=True)
        root = find_project_root(sub)
        assert root == tmp_path

    def test_finds_git(self, tmp_path):
        (tmp_path / ".git").mkdir()
        sub = tmp_path / "src"
        sub.mkdir()
        root = find_project_root(sub)
        assert root == tmp_path

    def test_returns_start_if_not_found(self, tmp_path):
        sub = tmp_path / "isolated"
        sub.mkdir()
        root = find_project_root(sub)
        assert root == sub
