"""Tests for envault.importer module."""

import json
from pathlib import Path

import pytest

from envault.importer import (
    import_from_env,
    import_from_file,
    parse_dotenv,
    parse_json_env,
    sanitize_var_name,
    validate_var_name,
)


class TestParseDotenv:
    def test_basic(self):
        result = parse_dotenv("KEY=value")
        assert result == {"KEY": "value"}

    def test_multiple_lines(self):
        content = "A=1\nB=2\nC=3"
        result = parse_dotenv(content)
        assert result == {"A": "1", "B": "2", "C": "3"}

    def test_comments_ignored(self):
        content = "# comment\nKEY=val\n# another"
        result = parse_dotenv(content)
        assert result == {"KEY": "val"}

    def test_blank_lines_ignored(self):
        content = "A=1\n\n\nB=2"
        result = parse_dotenv(content)
        assert result == {"A": "1", "B": "2"}

    def test_double_quoted_value(self):
        result = parse_dotenv('KEY="hello world"')
        assert result == {"KEY": "hello world"}

    def test_single_quoted_value(self):
        result = parse_dotenv("KEY='hello world'")
        assert result == {"KEY": "hello world"}

    def test_escape_newline(self):
        result = parse_dotenv('KEY="line1\\nline2"')
        assert result == {"KEY": "line1\nline2"}

    def test_escape_tab(self):
        result = parse_dotenv('KEY="col1\\tcol2"')
        assert result == {"KEY": "col1\tcol2"}

    def test_escape_double_quote(self):
        result = parse_dotenv('KEY="say \\"hi\\""')
        assert result == {"KEY": 'say "hi"'}

    def test_escape_backslash(self):
        result = parse_dotenv('KEY="path\\\\to"')
        assert result == {"KEY": "path\\to"}

    def test_export_prefix(self):
        result = parse_dotenv("export KEY=value")
        assert result == {"KEY": "value"}

    def test_inline_comment_unquoted(self):
        result = parse_dotenv("KEY=value # comment")
        assert result == {"KEY": "value"}

    def test_value_with_equals(self):
        result = parse_dotenv("URL=postgres://user:pw@host/db?opt=val")
        assert result["URL"] == "postgres://user:pw@host/db?opt=val"

    def test_empty_value(self):
        result = parse_dotenv("KEY=")
        assert result == {"KEY": ""}

    def test_no_equals_skipped(self):
        result = parse_dotenv("NOEQUALS")
        assert result == {}

    def test_whitespace_trimmed(self):
        result = parse_dotenv("  KEY = value  ")
        assert result == {"KEY": "value"}

    def test_empty_name_skipped(self):
        result = parse_dotenv("=value")
        assert result == {}


class TestParseJsonEnv:
    def test_basic(self):
        result = parse_json_env('{"KEY": "value"}')
        assert result == {"KEY": "value"}

    def test_number_values(self):
        result = parse_json_env('{"PORT": 8080}')
        assert result == {"PORT": "8080"}

    def test_bool_values(self):
        result = parse_json_env('{"DEBUG": true}')
        assert result == {"DEBUG": "True"}

    def test_null_values(self):
        result = parse_json_env('{"KEY": null}')
        assert result == {"KEY": ""}

    def test_non_dict_raises(self):
        with pytest.raises(ValueError, match="flat object"):
            parse_json_env("[1, 2, 3]")

    def test_nested_object_raises(self):
        with pytest.raises(ValueError, match="Unsupported value type"):
            parse_json_env('{"KEY": {"nested": "obj"}}')

    def test_array_value_raises(self):
        with pytest.raises(ValueError, match="Unsupported value type"):
            parse_json_env('{"KEY": [1, 2]}')


class TestImportFromFile:
    def test_dotenv_file(self, tmp_path):
        f = tmp_path / ".env"
        f.write_text("KEY=value\n")
        result = import_from_file(f)
        assert result == {"KEY": "value"}

    def test_json_file(self, tmp_path):
        f = tmp_path / "vars.json"
        f.write_text(json.dumps({"KEY": "value"}))
        result = import_from_file(f)
        assert result == {"KEY": "value"}

    def test_nonexistent_raises(self, tmp_path):
        with pytest.raises(FileNotFoundError):
            import_from_file(tmp_path / "nope")

    def test_default_to_dotenv(self, tmp_path):
        f = tmp_path / "custom.txt"
        f.write_text("A=1\nB=2\n")
        result = import_from_file(f)
        assert result == {"A": "1", "B": "2"}


class TestImportFromEnv:
    def test_imports_all(self, monkeypatch):
        monkeypatch.setenv("TEST_A", "1")
        monkeypatch.setenv("TEST_B", "2")
        result = import_from_env(prefix="TEST_")
        assert result["TEST_A"] == "1"
        assert result["TEST_B"] == "2"

    def test_strip_prefix(self, monkeypatch):
        monkeypatch.setenv("MYAPP_KEY", "val")
        result = import_from_env(prefix="MYAPP_", strip_prefix=True)
        assert "KEY" in result
        assert result["KEY"] == "val"

    def test_no_prefix(self, monkeypatch):
        monkeypatch.setenv("ENVAULT_TEST_X", "1")
        result = import_from_env()
        assert "ENVAULT_TEST_X" in result


class TestValidateVarName:
    def test_valid_names(self):
        assert validate_var_name("KEY") is True
        assert validate_var_name("_KEY") is True
        assert validate_var_name("my_var") is True
        assert validate_var_name("A1") is True
        assert validate_var_name("key-name") is True

    def test_invalid_names(self):
        assert validate_var_name("") is False
        assert validate_var_name("1KEY") is False
        assert validate_var_name("bad name") is False
        assert validate_var_name("bad!name") is False


class TestSanitizeVarName:
    def test_basic(self):
        assert sanitize_var_name("hello") == "HELLO"

    def test_spaces_to_underscores(self):
        assert sanitize_var_name("my var") == "MY_VAR"

    def test_special_chars(self):
        assert sanitize_var_name("my.var!name") == "MY_VAR_NAME"

    def test_starts_with_digit(self):
        assert sanitize_var_name("1var") == "_1VAR"
