"""Tests for envault.display module."""

import pytest

from envault.display import (
    MaskStyle,
    format_env_comparison,
    format_stats,
    format_variable_table,
    mask_value,
    truncate_value,
)


class TestMaskValue:
    def test_stars(self):
        result = mask_value("secret", MaskStyle.STARS)
        assert result == "******"

    def test_stars_long_capped(self):
        result = mask_value("a" * 100, MaskStyle.STARS)
        assert len(result) == 16

    def test_partial_short(self):
        result = mask_value("ab", MaskStyle.PARTIAL)
        assert result == "**"

    def test_partial_long(self):
        result = mask_value("secret-password", MaskStyle.PARTIAL)
        assert result.startswith("se")
        assert result.endswith("rd")
        assert "*" in result

    def test_dots(self):
        result = mask_value("secret", MaskStyle.DOTS)
        assert result == "......"

    def test_dots_long_capped(self):
        result = mask_value("a" * 100, MaskStyle.DOTS)
        assert len(result) == 16

    def test_redacted(self):
        result = mask_value("anything", MaskStyle.REDACTED)
        assert result == "[REDACTED]"

    def test_length(self):
        result = mask_value("hello", MaskStyle.LENGTH)
        assert result == "[5 chars]"

    def test_empty(self):
        result = mask_value("")
        assert result == "(empty)"

    def test_custom_visible(self):
        result = mask_value("abcdefghij", MaskStyle.PARTIAL, visible=3)
        assert result.startswith("abc")
        assert result.endswith("hij")

    def test_unknown_style(self):
        result = mask_value("test", "unknown_style")
        assert result == "****"


class TestFormatVariableTable:
    def test_basic(self):
        rows = format_variable_table({"KEY": "secret"})
        assert len(rows) == 1
        assert rows[0]["name"] == "KEY"
        assert "secret" not in rows[0]["value"]

    def test_show_values(self):
        rows = format_variable_table({"KEY": "secret"}, show_values=True)
        assert rows[0]["value"] == "secret"

    def test_sorted(self):
        rows = format_variable_table({"B": "2", "A": "1"})
        assert rows[0]["name"] == "A"

    def test_custom_mask(self):
        rows = format_variable_table({"K": "val"}, mask_style=MaskStyle.REDACTED)
        assert rows[0]["value"] == "[REDACTED]"


class TestFormatStats:
    def test_basic(self):
        stats = {
            "environments": 2,
            "total_variables": 5,
            "environment_details": {"dev": 3, "prod": 2},
        }
        result = format_stats(stats)
        assert "Environments: 2" in result
        assert "Total variables: 5" in result
        assert "dev: 3" in result
        assert "prod: 2" in result

    def test_empty(self):
        result = format_stats({})
        assert "Environments: 0" in result

    def test_no_details(self):
        result = format_stats({"environments": 1, "total_variables": 3})
        assert "Environments: 1" in result


class TestTruncateValue:
    def test_short_unchanged(self):
        assert truncate_value("hello", 50) == "hello"

    def test_long_truncated(self):
        result = truncate_value("a" * 100, 10)
        assert len(result) == 10
        assert result.endswith("...")

    def test_exact_length(self):
        result = truncate_value("abcde", 5)
        assert result == "abcde"


class TestFormatEnvComparison:
    def test_basic(self):
        result = format_env_comparison(
            "dev", {"A": "1", "B": "2"},
            "prod", {"A": "1", "C": "3"},
        )
        assert "dev" in result
        assert "prod" in result
        assert "A" in result
        assert "B" in result
        assert "C" in result

    def test_shows_markers(self):
        result = format_env_comparison(
            "dev", {"COMMON": "same", "DEV_ONLY": "x", "DIFF": "old"},
            "prod", {"COMMON": "same", "PROD_ONLY": "y", "DIFF": "new"},
        )
        lines = result.split("\n")
        # Find lines with markers
        marker_lines = [l for l in lines[2:] if l]  # skip header
        markers = [l[0] for l in marker_lines]
        assert " " in markers  # COMMON - same
        assert "-" in markers  # DEV_ONLY - removed
        assert "+" in markers  # PROD_ONLY - added
        assert "~" in markers  # DIFF - modified

    def test_show_values(self):
        result = format_env_comparison(
            "dev", {"KEY": "secret"},
            "prod", {"KEY": "other"},
            show_values=True,
        )
        assert "secret" in result
        assert "other" in result

    def test_hide_values(self):
        result = format_env_comparison(
            "dev", {"KEY": "secret"},
            "prod", {"KEY": "other"},
            show_values=False,
        )
        assert "secret" not in result
        assert "*" in result
