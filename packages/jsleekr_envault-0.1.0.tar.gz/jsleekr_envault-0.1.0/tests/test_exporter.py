"""Tests for envault.exporter module."""

import json
import base64
from pathlib import Path

import pytest

from envault.exporter import (
    ExportFormat,
    _quote_value,
    _shell_escape,
    export_docker,
    export_dotenv,
    export_json,
    export_k8s_secret,
    export_shell,
    export_to_format,
    export_yaml,
    write_export,
)


class TestQuoteValue:
    def test_simple_value(self):
        assert _quote_value("hello") == "hello"

    def test_value_with_spaces(self):
        assert _quote_value("hello world") == '"hello world"'

    def test_value_with_newlines(self):
        assert _quote_value("line1\nline2") == '"line1\\nline2"'

    def test_value_with_equals(self):
        assert _quote_value("a=b") == '"a=b"'

    def test_value_with_double_quotes(self):
        result = _quote_value('say "hi"')
        assert '\\"' in result

    def test_value_with_backslash(self):
        result = _quote_value("path\\to")
        assert "\\\\" in result


class TestShellEscape:
    def test_simple(self):
        assert _shell_escape("hello") == "'hello'"

    def test_with_single_quote(self):
        result = _shell_escape("it's")
        assert result == "'it'\\''s'"


class TestExportDotenv:
    def test_basic(self):
        result = export_dotenv({"KEY": "value"})
        assert result == "KEY=value\n"

    def test_sorted_keys(self):
        result = export_dotenv({"B": "2", "A": "1"})
        lines = result.strip().split("\n")
        assert lines[0] == "A=1"
        assert lines[1] == "B=2"

    def test_empty(self):
        assert export_dotenv({}) == ""

    def test_value_with_spaces_quoted(self):
        result = export_dotenv({"KEY": "hello world"})
        assert result == 'KEY="hello world"\n'


class TestExportShell:
    def test_basic(self):
        result = export_shell({"KEY": "value"})
        assert result == "export KEY='value'\n"

    def test_sorted(self):
        result = export_shell({"B": "2", "A": "1"})
        lines = result.strip().split("\n")
        assert lines[0].startswith("export A=")

    def test_empty(self):
        assert export_shell({}) == ""


class TestExportDocker:
    def test_basic(self):
        result = export_docker({"KEY": "value"})
        assert result == "KEY=value\n"

    def test_sorted(self):
        result = export_docker({"B": "2", "A": "1"})
        lines = result.strip().split("\n")
        assert lines[0] == "A=1"

    def test_empty(self):
        assert export_docker({}) == ""


class TestExportJson:
    def test_basic(self):
        result = export_json({"KEY": "value"})
        data = json.loads(result)
        assert data == {"KEY": "value"}

    def test_sorted(self):
        result = export_json({"B": "2", "A": "1"})
        keys = list(json.loads(result).keys())
        assert keys == ["A", "B"]

    def test_empty(self):
        data = json.loads(export_json({}))
        assert data == {}


class TestExportYaml:
    def test_basic(self):
        result = export_yaml({"KEY": "value"})
        assert result == "KEY: value\n"

    def test_value_with_colon_quoted(self):
        result = export_yaml({"URL": "http://host:8080"})
        assert '"' in result

    def test_empty(self):
        assert export_yaml({}) == ""

    def test_value_with_hash_quoted(self):
        result = export_yaml({"COMMENT": "has # in it"})
        assert '"' in result


class TestExportK8sSecret:
    def test_basic(self):
        result = export_k8s_secret({"KEY": "value"})
        assert "apiVersion: v1" in result
        assert "kind: Secret" in result
        assert "type: Opaque" in result
        encoded = base64.b64encode(b"value").decode()
        assert f"  KEY: {encoded}" in result

    def test_custom_name_namespace(self):
        result = export_k8s_secret({"K": "v"}, name="my-secret", namespace="prod")
        assert "name: my-secret" in result
        assert "namespace: prod" in result

    def test_sorted_keys(self):
        result = export_k8s_secret({"B": "2", "A": "1"})
        lines = result.strip().split("\n")
        data_lines = [l for l in lines if l.startswith("  ") and ":" in l and l.strip().split(":")[0] in ("A", "B")]
        assert len(data_lines) == 2


class TestExportToFormat:
    def test_dotenv(self):
        result = export_to_format({"K": "v"}, ExportFormat.DOTENV)
        assert "K=v" in result

    def test_shell(self):
        result = export_to_format({"K": "v"}, ExportFormat.SHELL)
        assert "export K=" in result

    def test_docker(self):
        result = export_to_format({"K": "v"}, ExportFormat.DOCKER)
        assert "K=v" in result

    def test_json(self):
        result = export_to_format({"K": "v"}, ExportFormat.JSON)
        assert json.loads(result) == {"K": "v"}

    def test_yaml(self):
        result = export_to_format({"K": "v"}, ExportFormat.YAML)
        assert "K: v" in result

    def test_k8s(self):
        result = export_to_format({"K": "v"}, ExportFormat.K8S_SECRET)
        assert "kind: Secret" in result


class TestWriteExport:
    def test_writes_file(self, tmp_path):
        path = tmp_path / "output.env"
        write_export({"KEY": "val"}, ExportFormat.DOTENV, path)
        assert path.exists()
        assert "KEY=val" in path.read_text()

    def test_creates_parent_dirs(self, tmp_path):
        path = tmp_path / "sub" / "dir" / "output.env"
        write_export({"KEY": "val"}, ExportFormat.DOTENV, path)
        assert path.exists()

    def test_returns_path(self, tmp_path):
        path = tmp_path / "out.json"
        result = write_export({"K": "v"}, ExportFormat.JSON, path)
        assert result == path
