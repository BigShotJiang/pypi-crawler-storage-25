"""Tests for envault.cli module."""

import json
from pathlib import Path

import pytest
from click.testing import CliRunner

from envault.cli import main
from envault.crypto import generate_key


@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def key():
    return generate_key()


@pytest.fixture
def vault_dir(tmp_path):
    return tmp_path


class TestCLIInit:
    def test_init_with_password(self, runner, vault_dir):
        result = runner.invoke(
            main, ["init", "--path", str(vault_dir / ".envault.json")],
            input="password\npassword\n",
        )
        assert result.exit_code == 0
        assert "Vault created" in result.output
        assert (vault_dir / ".envault.json").exists()

    def test_init_with_key(self, runner, vault_dir):
        result = runner.invoke(
            main, ["init", "--key", "--path", str(vault_dir / ".envault.json")],
        )
        assert result.exit_code == 0
        assert "Your key" in result.output

    def test_init_already_exists(self, runner, vault_dir):
        path = str(vault_dir / ".envault.json")
        runner.invoke(main, ["init", "--key", "--path", path])
        result = runner.invoke(main, ["init", "--key", "--path", path])
        assert "already exists" in result.output


class TestCLISetGet:
    def test_set_and_get(self, runner, vault_dir, key):
        path = str(vault_dir / ".envault.json")
        # Init
        runner.invoke(main, ["init", "--key", "--path", path])
        # Set
        result = runner.invoke(
            main, ["set", "DB_URL", "postgres://localhost/db", "--key", key, "--path", path],
        )
        assert result.exit_code == 0
        assert "Set DB_URL" in result.output

        # Get
        result = runner.invoke(
            main, ["get", "DB_URL", "--key", key, "--path", path],
        )
        assert result.exit_code == 0
        assert "postgres://localhost/db" in result.output

    def test_get_nonexistent(self, runner, vault_dir, key):
        path = str(vault_dir / ".envault.json")
        runner.invoke(main, ["init", "--key", "--path", path])
        runner.invoke(main, ["set", "A", "1", "--key", key, "--path", path])
        result = runner.invoke(
            main, ["get", "NOPE", "--key", key, "--path", path],
        )
        assert result.exit_code == 1

    def test_set_with_env(self, runner, vault_dir, key):
        path = str(vault_dir / ".envault.json")
        runner.invoke(main, ["init", "--key", "--path", path])
        result = runner.invoke(
            main, ["set", "KEY", "val", "-e", "prod", "--key", key, "--path", path],
        )
        assert result.exit_code == 0
        assert "[prod]" in result.output

    def test_set_with_tags(self, runner, vault_dir, key):
        path = str(vault_dir / ".envault.json")
        runner.invoke(main, ["init", "--key", "--path", path])
        result = runner.invoke(
            main, ["set", "KEY", "val", "-t", "db", "-t", "critical", "--key", key, "--path", path],
        )
        assert result.exit_code == 0


class TestCLIDelete:
    def test_delete(self, runner, vault_dir, key):
        path = str(vault_dir / ".envault.json")
        runner.invoke(main, ["init", "--key", "--path", path])
        runner.invoke(main, ["set", "KEY", "val", "--key", key, "--path", path])
        result = runner.invoke(
            main, ["delete", "KEY", "--key", key, "--path", path],
        )
        assert result.exit_code == 0
        assert "Deleted" in result.output

    def test_delete_nonexistent(self, runner, vault_dir, key):
        path = str(vault_dir / ".envault.json")
        runner.invoke(main, ["init", "--key", "--path", path])
        runner.invoke(main, ["set", "A", "1", "--key", key, "--path", path])
        result = runner.invoke(
            main, ["delete", "NOPE", "--key", key, "--path", path],
        )
        assert result.exit_code == 1


class TestCLIList:
    def test_list(self, runner, vault_dir, key):
        path = str(vault_dir / ".envault.json")
        runner.invoke(main, ["init", "--key", "--path", path])
        runner.invoke(main, ["set", "A", "1", "--key", key, "--path", path])
        runner.invoke(main, ["set", "B", "2", "--key", key, "--path", path])
        result = runner.invoke(
            main, ["list", "--key", key, "--path", path],
        )
        assert result.exit_code == 0
        assert "A" in result.output
        assert "B" in result.output


class TestCLIExport:
    def test_export_dotenv(self, runner, vault_dir, key):
        path = str(vault_dir / ".envault.json")
        runner.invoke(main, ["init", "--key", "--path", path])
        runner.invoke(main, ["set", "KEY", "val", "--key", key, "--path", path])
        result = runner.invoke(
            main, ["export", "-f", "dotenv", "--key", key, "--path", path],
        )
        assert result.exit_code == 0
        assert "KEY=val" in result.output

    def test_export_json(self, runner, vault_dir, key):
        path = str(vault_dir / ".envault.json")
        runner.invoke(main, ["init", "--key", "--path", path])
        runner.invoke(main, ["set", "KEY", "val", "--key", key, "--path", path])
        result = runner.invoke(
            main, ["export", "-f", "json", "--key", key, "--path", path],
        )
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["KEY"] == "val"

    def test_export_to_file(self, runner, vault_dir, key):
        path = str(vault_dir / ".envault.json")
        out_path = str(vault_dir / "output.env")
        runner.invoke(main, ["init", "--key", "--path", path])
        runner.invoke(main, ["set", "KEY", "val", "--key", key, "--path", path])
        result = runner.invoke(
            main, ["export", "-f", "dotenv", "-o", out_path, "--key", key, "--path", path],
        )
        assert result.exit_code == 0
        assert Path(out_path).exists()


class TestCLIImport:
    def test_import_dotenv(self, runner, vault_dir, key):
        path = str(vault_dir / ".envault.json")
        env_file = vault_dir / ".env"
        env_file.write_text("A=1\nB=2\n")
        runner.invoke(main, ["init", "--key", "--path", path])
        result = runner.invoke(
            main, ["import", str(env_file), "--key", key, "--path", path],
        )
        assert result.exit_code == 0
        assert "Imported 2" in result.output


class TestCLIDiff:
    def test_diff(self, runner, vault_dir, key):
        path = str(vault_dir / ".envault.json")
        runner.invoke(main, ["init", "--key", "--path", path])
        runner.invoke(main, ["set", "A", "1", "-e", "dev", "--key", key, "--path", path])
        runner.invoke(main, ["set", "A", "2", "-e", "prod", "--key", key, "--path", path])
        result = runner.invoke(
            main, ["diff", "dev", "prod", "--key", key, "--path", path],
        )
        assert result.exit_code == 0
        assert "modified" in result.output


class TestCLIKeygen:
    def test_keygen(self, runner):
        result = runner.invoke(main, ["keygen"])
        assert result.exit_code == 0
        assert len(result.output.strip().split("\n")[0]) > 20


class TestCLIVersion:
    def test_version(self, runner):
        result = runner.invoke(main, ["--version"])
        assert result.exit_code == 0
        assert "0.1.0" in result.output
