"""Tests for envault.crypto module."""

import base64

import pytest

from envault.crypto import (
    KEY_SIZE,
    EncryptedPayload,
    decrypt,
    decrypt_with_key,
    derive_key,
    encrypt,
    encrypt_with_key,
    generate_key,
)


class TestDeriveKey:
    def test_derives_key_of_correct_length(self):
        key, salt = derive_key("password")
        assert len(key) == KEY_SIZE

    def test_generates_salt_when_not_provided(self):
        key, salt = derive_key("password")
        assert len(salt) == 32

    def test_same_password_and_salt_give_same_key(self):
        key1, salt = derive_key("password")
        key2, _ = derive_key("password", salt)
        assert key1 == key2

    def test_different_passwords_give_different_keys(self):
        _, salt = derive_key("password1")
        key1, _ = derive_key("password1", salt)
        key2, _ = derive_key("password2", salt)
        assert key1 != key2

    def test_different_salts_give_different_keys(self):
        key1, salt1 = derive_key("password")
        key2, salt2 = derive_key("password")
        assert salt1 != salt2  # random salts should differ
        assert key1 != key2


class TestEncryptDecrypt:
    def test_encrypt_decrypt_roundtrip(self):
        payload = encrypt("hello world", "password")
        result = decrypt(payload, "password")
        assert result == "hello world"

    def test_encrypt_produces_encrypted_payload(self):
        payload = encrypt("secret", "password")
        assert isinstance(payload, EncryptedPayload)
        assert payload.ciphertext != b"secret"
        assert len(payload.nonce) == 12
        assert len(payload.salt) == 32

    def test_decrypt_wrong_password_raises(self):
        payload = encrypt("hello", "correct")
        with pytest.raises(ValueError, match="Decryption failed"):
            decrypt(payload, "wrong")

    def test_encrypt_empty_string(self):
        payload = encrypt("", "password")
        result = decrypt(payload, "password")
        assert result == ""

    def test_encrypt_unicode(self):
        payload = encrypt("Hello, 세계! 🌍", "password")
        result = decrypt(payload, "password")
        assert result == "Hello, 세계! 🌍"

    def test_encrypt_long_value(self):
        long_value = "x" * 10000
        payload = encrypt(long_value, "password")
        result = decrypt(payload, "password")
        assert result == long_value

    def test_encrypt_special_characters(self):
        value = 'key="value"\nnewline\ttab\\backslash'
        payload = encrypt(value, "pw")
        assert decrypt(payload, "pw") == value

    def test_different_encryptions_produce_different_ciphertext(self):
        p1 = encrypt("same", "password")
        p2 = encrypt("same", "password")
        assert p1.ciphertext != p2.ciphertext  # different nonce/salt

    def test_encrypt_with_empty_password(self):
        payload = encrypt("data", "")
        result = decrypt(payload, "")
        assert result == "data"


class TestEncryptedPayload:
    def test_to_dict_and_from_dict(self):
        payload = encrypt("test", "pw")
        d = payload.to_dict()
        restored = EncryptedPayload.from_dict(d)
        assert restored.ciphertext == payload.ciphertext
        assert restored.nonce == payload.nonce
        assert restored.salt == payload.salt

    def test_to_string_and_from_string(self):
        payload = encrypt("test", "pw")
        s = payload.to_string()
        restored = EncryptedPayload.from_string(s)
        result = decrypt(restored, "pw")
        assert result == "test"

    def test_version_defaults_to_1(self):
        payload = encrypt("test", "pw")
        assert payload.version == 1

    def test_from_dict_handles_missing_version(self):
        d = {"ct": base64.b64encode(b"x").decode(), "nonce": base64.b64encode(b"y").decode(), "salt": base64.b64encode(b"z").decode()}
        p = EncryptedPayload.from_dict(d)
        assert p.version == 1


class TestGenerateKey:
    def test_generates_base64_key(self):
        key = generate_key()
        decoded = base64.b64decode(key)
        assert len(decoded) == KEY_SIZE

    def test_generates_unique_keys(self):
        keys = {generate_key() for _ in range(10)}
        assert len(keys) == 10


class TestKeyBasedEncryption:
    def test_encrypt_decrypt_with_key(self):
        key = generate_key()
        payload = encrypt_with_key("secret", key)
        result = decrypt_with_key(payload, key)
        assert result == "secret"

    def test_wrong_key_fails(self):
        key1 = generate_key()
        key2 = generate_key()
        payload = encrypt_with_key("secret", key1)
        with pytest.raises(ValueError):
            decrypt_with_key(payload, key2)

    def test_key_encryption_has_empty_salt(self):
        key = generate_key()
        payload = encrypt_with_key("test", key)
        assert payload.salt == b""

    def test_invalid_key_length_raises(self):
        short_key = base64.b64encode(b"short").decode()
        with pytest.raises(ValueError, match="Key must be"):
            encrypt_with_key("test", short_key)

    def test_invalid_key_length_decrypt_raises(self):
        short_key = base64.b64encode(b"short").decode()
        key = generate_key()
        payload = encrypt_with_key("test", key)
        with pytest.raises(ValueError, match="Key must be"):
            decrypt_with_key(payload, short_key)

    def test_encrypt_unicode_with_key(self):
        key = generate_key()
        payload = encrypt_with_key("안녕하세요", key)
        result = decrypt_with_key(payload, key)
        assert result == "안녕하세요"
