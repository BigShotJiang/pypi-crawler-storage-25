"""Integration tests combining multiple envault modules."""

import json

import pytest

from envault.backup import create_backup, restore_backup
from envault.config import EnvaultConfig, save_config, load_config
from envault.crypto import generate_key
from envault.diff import diff_environments
from envault.display import format_variable_table, mask_value
from envault.example import generate_example_env, diff_example_env
from envault.exporter import export_dotenv, export_json, ExportFormat, export_to_format
from envault.expiry import ExpiryManager
from envault.groups import GroupManager, create_default_groups
from envault.history import HistoryLog, ActionType
from envault.importer import parse_dotenv, import_from_file
from envault.inheritance import InheritanceConfig, resolve_variables
from envault.merge import merge_vaults, ConflictStrategy
from envault.migration import migrate_file
from envault.security import audit_variables, check_password_strength
from envault.snapshot import create_snapshot, compare_snapshots
from envault.template import interpolate_all
from envault.validator import VariableSchema
from envault.vault import Vault


class TestFullWorkflow:
    """Test a complete workflow: init, set, export, backup, restore."""

    def test_complete_lifecycle(self, tmp_path):
        key = generate_key()
        vault = Vault(path=tmp_path / ".envault.json", key=key)

        # Set variables across environments
        vault.set("DB_HOST", "localhost", "dev")
        vault.set("DB_PORT", "5432", "dev")
        vault.set("DB_HOST", "prod-db.internal", "prod")
        vault.set("DB_PORT", "5432", "prod")
        vault.set("API_KEY", "dev-key-123", "dev", tags=["api"])
        vault.set("API_KEY", "prod-key-456", "prod", tags=["api"])
        vault.save()

        # Export dev environment
        dev_vars = vault.get_all("dev")
        dotenv = export_dotenv(dev_vars)
        assert "DB_HOST=localhost" in dotenv
        assert "API_KEY=dev-key-123" in dotenv

        # Diff environments
        diff = diff_environments(vault, "dev", "prod")
        assert diff.has_changes
        assert len(diff.modified) == 2  # DB_HOST and API_KEY changed

        # Create backup
        backup = create_backup(vault.path)
        assert backup.path.exists()

        # Modify and restore
        vault.set("NEW_VAR", "new", "dev")
        vault.save()

        restore_backup(backup.path, vault.path, create_pre_restore_backup=False)
        vault2 = Vault(path=tmp_path / ".envault.json", key=key)
        vault2.load()
        assert not vault2.has("NEW_VAR", "dev")
        assert vault2.get("DB_HOST", "dev") == "localhost"

    def test_import_export_roundtrip(self, tmp_path):
        """Import from .env, encrypt in vault, export back."""
        # Create source .env
        env_content = "DB_HOST=localhost\nDB_PORT=5432\nSECRET=s3cr3t\n"
        env_file = tmp_path / ".env"
        env_file.write_text(env_content)

        # Import into vault
        vault = Vault(path=tmp_path / ".envault.json", password="pw")
        imported = import_from_file(env_file)
        for name, value in imported.items():
            vault.set(name, value)
        vault.save()

        # Reload and export
        vault2 = Vault(path=tmp_path / ".envault.json", password="pw")
        vault2.load()
        exported = export_dotenv(vault2.get_all())

        # Parse exported and compare
        re_imported = parse_dotenv(exported)
        assert re_imported["DB_HOST"] == "localhost"
        assert re_imported["SECRET"] == "s3cr3t"


class TestTemplateWithVault:
    def test_interpolate_vault_vars(self, tmp_path):
        vault = Vault(path=tmp_path / ".envault.json", password="pw")
        vault.set("DB_USER", "admin")
        vault.set("DB_PASS", "secret")
        vault.set("DB_HOST", "localhost")
        vault.set("DB_NAME", "mydb")
        vault.set("DATABASE_URL", "postgres://${DB_USER}:${DB_PASS}@${DB_HOST}/${DB_NAME}")
        vault.save()

        vault2 = Vault(path=tmp_path / ".envault.json", password="pw")
        vault2.load()
        variables = vault2.get_all()
        resolved = interpolate_all(variables)
        assert resolved["DATABASE_URL"] == "postgres://admin:secret@localhost/mydb"


class TestValidationWithVault:
    def test_validate_vault_vars(self, tmp_path):
        vault = Vault(path=tmp_path / ".envault.json", password="pw")
        vault.set("DB_URL", "https://db.example.com/mydb")
        vault.set("APP_PORT", "8080")
        vault.set("ADMIN_EMAIL", "admin@example.com")

        schema = VariableSchema()
        schema.require("DB_URL").url("DB_URL")
        schema.port("APP_PORT")
        schema.email("ADMIN_EMAIL")

        result = schema.validate(vault.get_all())
        assert result.is_valid


class TestInheritanceWithVault:
    def test_layered_environments(self, tmp_path):
        vault = Vault(path=tmp_path / ".envault.json", password="pw")
        vault.set("APP_NAME", "myapp", "base")
        vault.set("DEBUG", "true", "base")
        vault.set("DB_HOST", "localhost", "base")

        vault.set("DB_HOST", "staging-db.internal", "staging")
        vault.set("DEBUG", "false", "prod")
        vault.set("DB_HOST", "prod-db.internal", "prod")

        config = InheritanceConfig()
        config.set_parent("staging", "base")
        config.set_parent("prod", "base")

        staging_vars = resolve_variables(vault, "staging", config)
        assert staging_vars["APP_NAME"] == "myapp"  # inherited
        assert staging_vars["DB_HOST"] == "staging-db.internal"  # overridden
        assert staging_vars["DEBUG"] == "true"  # inherited

        prod_vars = resolve_variables(vault, "prod", config)
        assert prod_vars["DEBUG"] == "false"  # overridden
        assert prod_vars["DB_HOST"] == "prod-db.internal"  # overridden


class TestSecurityWithVault:
    def test_audit_vault_vars(self, tmp_path):
        vault = Vault(path=tmp_path / ".envault.json", password="pw")
        vault.set("API_KEY", "changeme")
        vault.set("DB_PASSWORD", "")
        vault.set("HOST", "localhost")

        report = audit_variables(vault.get_all())
        assert not report.is_clean
        assert report.high_count >= 1  # changeme


class TestMergeVaults:
    def test_merge_two_vaults(self, tmp_path):
        v1 = Vault(path=tmp_path / "v1.json", password="pw")
        v1.set("A", "1")
        v1.set("B", "2")

        v2 = Vault(path=tmp_path / "v2.json", password="pw")
        v2.set("B", "3")
        v2.set("C", "4")

        result = merge_vaults(v1, v2, strategy=ConflictStrategy.SOURCE_WINS)
        assert v2.get("A") == "1"  # new
        assert v2.get("B") == "2"  # source wins
        assert v2.get("C") == "4"  # kept


class TestSnapshotWithVault:
    def test_snapshot_and_compare(self, tmp_path):
        vault = Vault(path=tmp_path / ".envault.json", password="pw")
        vault.set("A", "1", "dev")
        vault.set("B", "2", "dev")

        snap1 = create_snapshot({"dev": vault.get_all("dev")}, label="before")

        vault.set("A", "changed", "dev")
        vault.set("C", "3", "dev")

        snap2 = create_snapshot({"dev": vault.get_all("dev")}, label="after")

        diff = compare_snapshots(snap1, snap2)
        assert diff.has_changes
        assert "dev:A" in diff.changed
        assert "dev:C" in diff.added


class TestGroupsWithVault:
    def test_categorize_vault_vars(self, tmp_path):
        vault = Vault(path=tmp_path / ".envault.json", password="pw")
        vault.set("DB_HOST", "localhost")
        vault.set("DB_PORT", "5432")
        vault.set("API_KEY", "key")
        vault.set("CUSTOM", "val")

        mgr = create_default_groups()
        categories = mgr.categorize(vault.list_vars())
        assert "DB_HOST" in categories["database"]
        assert "API_KEY" in categories["api"]
        assert "CUSTOM" in categories["ungrouped"]


class TestExampleWithVault:
    def test_generate_and_diff(self, tmp_path):
        vault = Vault(path=tmp_path / ".envault.json", password="pw")
        vault.set("DB_HOST", "localhost")
        vault.set("API_SECRET", "supersecret", description="Main API secret")

        content = generate_example_env(vault)
        assert "DB_HOST=" in content
        assert "supersecret" not in content
        assert "(sensitive)" in content

        # Write example and diff
        example_path = tmp_path / ".env.example"
        example_path.write_text(content)
        diff = diff_example_env(vault, example_path)
        assert diff["missing"] == []


class TestMigrationIntegration:
    def test_migrate_and_load(self, tmp_path):
        vault = Vault(path=tmp_path / ".envault.json", password="pw")
        vault.set("KEY", "value")
        vault.save()

        result = migrate_file(vault.path, backup=False)
        assert result.success

        vault2 = Vault(path=tmp_path / ".envault.json", password="pw")
        vault2.load()
        assert vault2.get("KEY") == "value"
