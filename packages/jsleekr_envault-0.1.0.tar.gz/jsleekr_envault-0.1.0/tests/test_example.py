"""Tests for envault.example module."""

import pytest

from envault.example import (
    diff_example_env,
    generate_example_env,
    generate_placeholder,
    write_example_env,
)
from envault.vault import Vault


@pytest.fixture
def vault(tmp_path):
    v = Vault(path=tmp_path / ".envault.json", password="pw")
    return v


class TestGeneratePlaceholder:
    def test_password(self):
        assert generate_placeholder("DB_PASSWORD") == "your-secret-here"

    def test_api_key(self):
        assert generate_placeholder("API_KEY") == "your-secret-here"

    def test_port(self):
        assert generate_placeholder("APP_PORT") == "3000"

    def test_host(self):
        assert generate_placeholder("DB_HOST") == "localhost"

    def test_url(self):
        assert generate_placeholder("BASE_URL") == "https://example.com"

    def test_email(self):
        assert generate_placeholder("ADMIN_EMAIL") == "user@example.com"

    def test_debug(self):
        assert generate_placeholder("DEBUG") == "false"

    def test_env(self):
        assert generate_placeholder("NODE_ENV") == "development"

    def test_log_level(self):
        assert generate_placeholder("LOG_LEVEL") == "info"

    def test_timeout(self):
        assert generate_placeholder("REQUEST_TIMEOUT") == "30"

    def test_path(self):
        assert generate_placeholder("DATA_PATH") == "/path/to/dir"

    def test_name(self):
        assert generate_placeholder("APP_NAME") == "my-app"

    def test_version(self):
        assert generate_placeholder("APP_VERSION") == "1.0.0"

    def test_generic(self):
        assert generate_placeholder("SOMETHING") == "your-value-here"

    def test_short_non_sensitive_shows_value(self):
        assert generate_placeholder("COLOR", "blue") == "blue"

    def test_max_limit(self):
        assert generate_placeholder("MAX_RETRIES") == "100"


class TestGenerateExampleEnv:
    def test_empty_vault(self, vault):
        content = generate_example_env(vault)
        assert "Environment Variables" in content
        assert "envault" in content

    def test_with_variables(self, vault):
        vault.set("DB_HOST", "localhost")
        vault.set("DB_PORT", "5432")
        content = generate_example_env(vault)
        assert "DB_HOST=" in content
        assert "DB_PORT=" in content

    def test_with_description(self, vault):
        vault.set("KEY", "val", description="The main key")
        content = generate_example_env(vault, include_descriptions=True)
        assert "The main key" in content

    def test_sensitive_marked(self, vault):
        vault.set("API_SECRET", "shhh")
        content = generate_example_env(vault)
        assert "(sensitive)" in content

    def test_group_by_tag(self, vault):
        vault.set("DB_HOST", "localhost", tags=["database"])
        vault.set("DB_PORT", "5432", tags=["database"])
        vault.set("API_KEY", "key", tags=["api"])
        content = generate_example_env(vault, group_by_tag=True)
        assert "--- database ---" in content
        assert "--- api ---" in content

    def test_untagged_in_group_mode(self, vault):
        vault.set("TAGGED", "val", tags=["group"])
        vault.set("UNTAGGED", "val")
        content = generate_example_env(vault, group_by_tag=True)
        assert "--- other ---" in content


class TestWriteExampleEnv:
    def test_writes_file(self, vault, tmp_path):
        vault.set("KEY", "val")
        path = write_example_env(vault, tmp_path / ".env.example")
        assert path.exists()
        content = path.read_text()
        assert "KEY=" in content

    def test_creates_dirs(self, vault, tmp_path):
        vault.set("KEY", "val")
        path = write_example_env(vault, tmp_path / "sub" / ".env.example")
        assert path.exists()


class TestDiffExampleEnv:
    def test_missing_file(self, vault, tmp_path):
        vault.set("A", "1")
        vault.set("B", "2")
        result = diff_example_env(vault, tmp_path / "nope")
        assert set(result["missing"]) == {"A", "B"}
        assert result["extra"] == []

    def test_no_diff(self, vault, tmp_path):
        vault.set("A", "1")
        vault.set("B", "2")
        example = tmp_path / ".env.example"
        example.write_text("A=placeholder\nB=placeholder\n")
        result = diff_example_env(vault, example)
        assert result["missing"] == []
        assert result["extra"] == []

    def test_missing_in_example(self, vault, tmp_path):
        vault.set("A", "1")
        vault.set("B", "2")
        vault.set("C", "3")
        example = tmp_path / ".env.example"
        example.write_text("A=x\n")
        result = diff_example_env(vault, example)
        assert set(result["missing"]) == {"B", "C"}

    def test_extra_in_example(self, vault, tmp_path):
        vault.set("A", "1")
        example = tmp_path / ".env.example"
        example.write_text("A=x\nOLD_VAR=y\n")
        result = diff_example_env(vault, example)
        assert result["extra"] == ["OLD_VAR"]
