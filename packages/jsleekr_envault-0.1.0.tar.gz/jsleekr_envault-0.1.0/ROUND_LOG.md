# Round Log

## Project: envault
- **Category**: Security / Secrets Management
- **Language**: Python 3.10+
- **Tests**: 698 passing

## Commit History

### Commit 1: `a7290f7` - feat: initial envault implementation with 186 passing tests
- Core vault engine with AES-256-GCM encryption
- Password and key-based encryption modes
- CLI with init, set, get, list, delete, export, import, diff, run, keygen
- 6 export formats: dotenv, shell, Docker, JSON, YAML, K8s Secret
- Multi-environment support
- 186 tests

### Commit 2: `1f48c84` - feat: add password/key rotation, variable rename, and bulk set
- Password rotation re-encrypts all secrets
- Key rotation for key-based vaults
- Variable rename without re-encryption
- Bulk set for multiple variables

### Commit 3: `c5f1e00` - feat: add variable change history tracking with audit log
- HistoryLog with configurable max entries
- ActionType tracking (set, delete, rename, import, rotate)
- Filter by variable, environment, action, or recency

### Commit 4: `9be75c7` - feat: add variable validation schema with built-in rule types
- ValidationSchema with per-variable rules
- Built-in types: required, pattern, min/max length, URL, email, port, one_of, not_empty
- Custom validation function support

### Commit 5: `b91b849` - feat: add variable interpolation and template expansion
- `${VAR}` and `${VAR:-default}` syntax support
- Circular reference detection
- Reference finder for dependency analysis

### Commit 6: `ee2672c` - feat: add vault merge with configurable conflict resolution strategies
- Merge strategies: keep_source, keep_target, keep_newest
- Conflict detection and reporting
- Cross-vault merging

### Commit 7: `5aa37e5` - feat: add role-based access control with environment/variable restrictions
- Three roles: admin, editor, viewer
- Six permissions: read, write, delete, export, import, admin
- Environment and variable level restrictions

### Commit 8: `eccf89c` - feat: add comprehensive CLI tests and fix Rich markup escaping
- Full CLI test coverage
- Rich markup escaping fixes

### Commit 9: `66056c1` - feat: add backup and restore with cleanup and verification
- Timestamped backup creation
- One-command restore
- Backup cleanup and integrity verification

### Commit 10: `281c407` - feat: add secure display utilities with multiple masking styles
- Multiple masking styles for terminal output
- Secure value display

### Commit 11: `4e11879` - feat: add security auditing, secret detection, and gitignore generation
- Weak secret detection
- Default value detection
- Auto-generate gitignore entries

### Commit 12: `25bb2f6` - feat: add vault snapshots for point-in-time state comparison
- Snapshot creation and comparison
- Change detection between snapshots

### Commit 13: `41c87ae` - feat: add file-based vault locking with stale lock detection
- File-based locks for concurrent access
- Stale lock detection and cleanup

### Commit 14: `16c8353` - feat: add environment inheritance with layered variable resolution
- Parent-child environment relationships
- Layered variable resolution (child overrides parent)
- Circular inheritance detection

### Commit 15: `a5ba3a7` - feat: add .env.example generation with smart placeholders
- Smart placeholder generation
- No secret values exposed in example files

### Commit 16: `80424c6` - feat: add variable expiry and TTL management
- TTL-based variable expiration
- Warning threshold support

### Commit 17: `112250b` - test: add edge case tests across all modules
- Edge case coverage for all modules

### Commit 18: `9b39acd` - feat: add vault file migration with version upgrade support
- Vault file version migration
- Backward compatibility

### Commit 19: `65d2560` - feat: add project configuration with .envaultrc and pyproject.toml support
- .envaultrc configuration file
- pyproject.toml [tool.envault] section

### Commit 20: `dfa4a3a` - feat: add variable groups with prefix-based and explicit categorization
- Variable groups by prefix (DB_, API_, AWS_)
- Explicit group assignment

### Commit 21: `2d1269e` - feat: add integration tests and update README with all features
- Integration tests
- README update with feature list

## Architecture Decisions

1. **AES-256-GCM**: Authenticated encryption ensures both confidentiality and integrity
2. **scrypt for KDF**: Memory-hard function resistant to GPU-based brute force attacks
3. **Per-variable encryption**: Each value encrypted independently with unique nonce
4. **JSON storage**: Human-inspectable structure (encrypted values, readable metadata)
5. **Click + Rich**: Click for declarative CLI, Rich for styled terminal output
6. **Atomic saves**: Temp file + rename prevents vault corruption on crash
