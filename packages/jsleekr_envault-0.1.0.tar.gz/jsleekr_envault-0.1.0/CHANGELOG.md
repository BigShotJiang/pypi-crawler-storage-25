# Changelog

All notable changes to envault will be documented in this file.

## [0.1.0] - 2026-03-26

### Added

- **Core vault engine** with AES-256-GCM encryption and scrypt key derivation
- **Password-based and key-based encryption** modes
- **Multi-environment support** (dev, staging, prod in one vault file)
- **Click CLI** with commands: init, set, get, list, delete, export, import, diff, run, keygen
- **Rich terminal output** with styled tables and colored messages
- **6 export formats**: dotenv, shell, Docker, JSON, YAML, Kubernetes Secret manifests
- **Import support** from .env files and JSON
- **Process injection** via `envault run` command
- **Environment diffing** to compare variables across environments
- **Variable tags** for categorization with search and filter
- **Variable interpolation** with `${VAR}` and `${VAR:-default}` syntax
- **Environment inheritance** with layered resolution and circular dependency detection
- **Validation rules** with built-in types: required, pattern, min/max length, URL, email, port, one_of
- **Role-based access control** with admin/editor/viewer roles and environment/variable restrictions
- **Variable change history** with audit trail (set, delete, rename, rotate actions)
- **Password/key rotation** to re-encrypt all secrets with new credentials
- **Variable rename** and **bulk set** operations
- **Backup and restore** with timestamped backups, cleanup, and verification
- **Vault snapshots** for point-in-time state comparison
- **File-based locking** with stale lock detection to prevent concurrent modifications
- **Vault migration** for version upgrade support
- **Security auditing** with weak secret detection and gitignore generation
- **Secure display** with multiple masking styles for terminal output
- **.env.example generation** with smart placeholders (no secrets exposed)
- **Variable groups** organized by prefix (DB_, API_, AWS_)
- **Variable expiry/TTL** management with warning thresholds
- **Project configuration** via `.envaultrc` or `pyproject.toml [tool.envault]`
- **Atomic file saves** using temp file + rename pattern
- **698 passing tests** covering all modules including edge cases and integration
