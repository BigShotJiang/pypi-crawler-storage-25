"""Variable interpolation and template expansion for envault.

Supports ${VAR} references within variable values, enabling
composition (e.g., DATABASE_URL = postgres://${DB_USER}:${DB_PASS}@${DB_HOST}/mydb).
"""

from __future__ import annotations

import re
from typing import Optional


# Matches ${VAR_NAME} or ${VAR_NAME:-default}
INTERPOLATION_PATTERN = re.compile(
    r"\$\{([A-Za-z_][A-Za-z0-9_-]*)(?::-(.*?))?\}"
)


class InterpolationError(Exception):
    """Raised when variable interpolation fails."""

    def __init__(self, variable: str, reference: str, message: str = ""):
        self.variable = variable
        self.reference = reference
        super().__init__(message or f"Unresolved reference '${{{reference}}}' in '{variable}'")


def find_references(value: str) -> list[str]:
    """Find all variable references in a value.

    Args:
        value: The string to search.

    Returns:
        List of referenced variable names.
    """
    return [m.group(1) for m in INTERPOLATION_PATTERN.finditer(value)]


def has_references(value: str) -> bool:
    """Check if a value contains variable references.

    Args:
        value: The string to check.

    Returns:
        True if references are found.
    """
    return bool(INTERPOLATION_PATTERN.search(value))


def interpolate(
    value: str,
    variables: dict[str, str],
    strict: bool = True,
) -> str:
    """Interpolate variable references in a value.

    Supports ${VAR} and ${VAR:-default} syntax.

    Args:
        value: The string with potential references.
        variables: Available variables for resolution.
        strict: If True, raise on unresolved references.

    Returns:
        The interpolated string.

    Raises:
        InterpolationError: If strict and a reference can't be resolved.
    """
    def replacer(match: re.Match) -> str:
        ref_name = match.group(1)
        default = match.group(2)

        if ref_name in variables:
            return variables[ref_name]
        elif default is not None:
            return default
        elif strict:
            raise InterpolationError("", ref_name)
        else:
            return match.group(0)  # Leave as-is

    return INTERPOLATION_PATTERN.sub(replacer, value)


def interpolate_all(
    variables: dict[str, str],
    strict: bool = True,
    max_depth: int = 10,
) -> dict[str, str]:
    """Interpolate all variables, resolving cross-references.

    Handles transitive references up to max_depth levels.

    Args:
        variables: Dictionary of name -> value (may contain ${refs}).
        strict: If True, raise on unresolved references.
        max_depth: Maximum interpolation depth to prevent infinite loops.

    Returns:
        Dictionary with all references resolved.

    Raises:
        InterpolationError: If strict and references can't be resolved.
        RecursionError: If max_depth is exceeded (circular references).
    """
    # Check for circular references first
    cycles = find_circular_references(variables)
    if cycles:
        cycle_vars = set()
        for cycle in cycles:
            cycle_vars.update(cycle)
        raise RecursionError(
            f"Circular references detected in: {', '.join(sorted(cycle_vars))}"
        )

    result = dict(variables)

    for depth in range(max_depth):
        changed = False
        for name, value in list(result.items()):
            if has_references(value):
                try:
                    new_value = interpolate(value, result, strict=strict)
                except InterpolationError as e:
                    e.variable = name
                    raise
                if new_value != value:
                    result[name] = new_value
                    changed = True

        if not changed:
            break
    else:
        unresolved = {name for name, val in result.items() if has_references(val)}
        if unresolved:
            raise RecursionError(
                f"Maximum interpolation depth ({max_depth}) exceeded. "
                f"Possible circular references in: {', '.join(sorted(unresolved))}"
            )

    return result


def build_dependency_graph(variables: dict[str, str]) -> dict[str, set[str]]:
    """Build a dependency graph from variable references.

    Args:
        variables: Dictionary of name -> value.

    Returns:
        Dictionary mapping variable names to their dependencies.
    """
    graph: dict[str, set[str]] = {}
    for name, value in variables.items():
        refs = find_references(value)
        graph[name] = set(refs)
    return graph


def find_circular_references(variables: dict[str, str]) -> list[list[str]]:
    """Find circular reference chains in variables.

    Args:
        variables: Dictionary of name -> value.

    Returns:
        List of circular reference chains.
    """
    graph = build_dependency_graph(variables)
    cycles: list[list[str]] = []
    visited: set[str] = set()
    rec_stack: set[str] = set()

    def _dfs(node: str, path: list[str]) -> None:
        visited.add(node)
        rec_stack.add(node)
        path.append(node)

        for neighbor in graph.get(node, set()):
            if neighbor not in visited:
                if neighbor in graph:
                    _dfs(neighbor, path)
            elif neighbor in rec_stack:
                # Found a cycle
                cycle_start = path.index(neighbor)
                cycle = path[cycle_start:] + [neighbor]
                cycles.append(cycle)

        path.pop()
        rec_stack.discard(node)

    for node in graph:
        if node not in visited:
            _dfs(node, [])

    return cycles


def resolve_order(variables: dict[str, str]) -> list[str]:
    """Determine the resolution order for variables (topological sort).

    Variables without dependencies come first.

    Args:
        variables: Dictionary of name -> value.

    Returns:
        List of variable names in resolution order.

    Raises:
        ValueError: If circular dependencies exist.
    """
    graph = build_dependency_graph(variables)

    # Kahn's algorithm
    in_degree: dict[str, int] = {name: 0 for name in variables}
    for deps in graph.values():
        for dep in deps:
            if dep in in_degree:
                in_degree[dep] = in_degree.get(dep, 0)  # ignore external refs

    # Recalculate based on reverse graph
    in_degree = {name: 0 for name in variables}
    for name, deps in graph.items():
        for dep in deps:
            if dep in in_degree:
                pass  # dep is depended upon by name
    # Actually: in_degree[name] = number of vars that name depends on (that exist)
    for name, deps in graph.items():
        in_degree[name] = len(deps & set(variables.keys()))

    queue = sorted(name for name, deg in in_degree.items() if deg == 0)
    result = []

    while queue:
        node = queue.pop(0)
        result.append(node)

        # For each var that depends on node, decrement in-degree
        for name, deps in graph.items():
            if node in deps:
                in_degree[name] -= 1
                if in_degree[name] == 0:
                    queue.append(name)
                    queue.sort()

    if len(result) != len(variables):
        raise ValueError("Circular dependencies detected")

    return result
