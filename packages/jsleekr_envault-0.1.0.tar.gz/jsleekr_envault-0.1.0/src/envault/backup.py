"""Backup and restore functionality for envault.

Create timestamped backups, list available backups,
and restore from backup files.
"""

from __future__ import annotations

import json
import shutil
import time
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Optional


BACKUP_SUFFIX = ".envault.backup"


@dataclass
class BackupInfo:
    """Metadata about a backup file."""

    path: Path
    timestamp: float
    size: int

    @property
    def created_at(self) -> str:
        return datetime.fromtimestamp(self.timestamp).isoformat()

    @property
    def filename(self) -> str:
        return self.path.name

    def to_dict(self) -> dict:
        return {
            "path": str(self.path),
            "timestamp": self.timestamp,
            "size": self.size,
            "created_at": self.created_at,
        }


def create_backup(
    vault_path: Path,
    backup_dir: Optional[Path] = None,
    label: str = "",
) -> BackupInfo:
    """Create a backup of the vault file.

    Args:
        vault_path: Path to the vault file.
        backup_dir: Directory for backups. Defaults to vault's parent dir.
        label: Optional label for the backup.

    Returns:
        BackupInfo with backup details.

    Raises:
        FileNotFoundError: If vault file doesn't exist.
    """
    if not vault_path.exists():
        raise FileNotFoundError(f"Vault not found: {vault_path}")

    ts = time.time()
    ts_str = datetime.fromtimestamp(ts).strftime("%Y%m%d_%H%M%S_%f")

    if backup_dir is None:
        backup_dir = vault_path.parent

    backup_dir.mkdir(parents=True, exist_ok=True)

    label_part = f"_{label}" if label else ""
    backup_name = f"{vault_path.stem}{label_part}_{ts_str}{BACKUP_SUFFIX}"
    backup_path = backup_dir / backup_name

    shutil.copy2(vault_path, backup_path)

    return BackupInfo(
        path=backup_path,
        timestamp=ts,
        size=backup_path.stat().st_size,
    )


def list_backups(
    vault_path: Path,
    backup_dir: Optional[Path] = None,
) -> list[BackupInfo]:
    """List available backups.

    Args:
        vault_path: Path to the vault file.
        backup_dir: Directory containing backups. Defaults to vault's parent dir.

    Returns:
        List of BackupInfo, newest first.
    """
    if backup_dir is None:
        backup_dir = vault_path.parent

    if not backup_dir.exists():
        return []

    backups = []
    for f in backup_dir.glob(f"*{BACKUP_SUFFIX}"):
        backups.append(BackupInfo(
            path=f,
            timestamp=f.stat().st_mtime,
            size=f.stat().st_size,
        ))

    return sorted(backups, key=lambda b: b.timestamp, reverse=True)


def restore_backup(
    backup_path: Path,
    vault_path: Path,
    create_pre_restore_backup: bool = True,
) -> Optional[BackupInfo]:
    """Restore a vault from a backup.

    Args:
        backup_path: Path to the backup file.
        vault_path: Path to the vault file to restore to.
        create_pre_restore_backup: Whether to backup current vault first.

    Returns:
        BackupInfo of the pre-restore backup (if created), or None.

    Raises:
        FileNotFoundError: If backup file doesn't exist.
    """
    if not backup_path.exists():
        raise FileNotFoundError(f"Backup not found: {backup_path}")

    pre_restore = None
    if create_pre_restore_backup and vault_path.exists():
        pre_restore = create_backup(vault_path, label="pre_restore")

    shutil.copy2(backup_path, vault_path)
    return pre_restore


def delete_backup(backup_path: Path) -> bool:
    """Delete a backup file.

    Args:
        backup_path: Path to the backup.

    Returns:
        True if deleted.
    """
    if backup_path.exists():
        backup_path.unlink()
        return True
    return False


def cleanup_old_backups(
    vault_path: Path,
    keep: int = 5,
    backup_dir: Optional[Path] = None,
) -> int:
    """Remove old backups, keeping only the most recent.

    Args:
        vault_path: Path to the vault file.
        keep: Number of backups to keep.
        backup_dir: Directory containing backups.

    Returns:
        Number of backups removed.
    """
    backups = list_backups(vault_path, backup_dir)
    removed = 0

    for backup in backups[keep:]:
        if backup.path.exists():
            backup.path.unlink()
            removed += 1

    return removed


def verify_backup(backup_path: Path) -> bool:
    """Verify a backup file is valid JSON.

    Args:
        backup_path: Path to the backup.

    Returns:
        True if the backup is valid.
    """
    if not backup_path.exists():
        return False

    try:
        content = backup_path.read_text(encoding="utf-8")
        data = json.loads(content)
        return "metadata" in data and "environments" in data
    except (json.JSONDecodeError, UnicodeDecodeError):
        return False
