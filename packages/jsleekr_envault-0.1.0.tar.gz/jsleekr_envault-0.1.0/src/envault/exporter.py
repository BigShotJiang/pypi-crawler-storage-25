"""Export functionality for envault.

Supports exporting vault variables to various formats:
- .env files
- Shell export statements
- Docker --env-file format
- JSON
- YAML-like
- Kubernetes Secret manifests
"""

from __future__ import annotations

import base64
import json
import os
import subprocess
import sys
from enum import Enum
from pathlib import Path
from typing import Optional

from envault.vault import Vault


class ExportFormat(str, Enum):
    """Supported export formats."""

    DOTENV = "dotenv"
    SHELL = "shell"
    DOCKER = "docker"
    JSON = "json"
    YAML = "yaml"
    K8S_SECRET = "k8s-secret"


def _quote_value(value: str) -> str:
    """Quote a value for .env file format."""
    if "\n" in value or '"' in value or "'" in value or " " in value or "=" in value or "\\" in value:
        escaped = value.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n")
        return f'"{escaped}"'
    return value


def _shell_escape(value: str) -> str:
    """Escape a value for shell export."""
    escaped = value.replace("'", "'\\''")
    return f"'{escaped}'"


def export_dotenv(variables: dict[str, str]) -> str:
    """Export variables as .env file format.

    Args:
        variables: Dictionary of name -> value.

    Returns:
        String in .env format.
    """
    lines = []
    for name in sorted(variables):
        value = _quote_value(variables[name])
        lines.append(f"{name}={value}")
    return "\n".join(lines) + "\n" if lines else ""


def export_shell(variables: dict[str, str]) -> str:
    """Export variables as shell export statements.

    Args:
        variables: Dictionary of name -> value.

    Returns:
        String with export statements.
    """
    lines = []
    for name in sorted(variables):
        value = _shell_escape(variables[name])
        lines.append(f"export {name}={value}")
    return "\n".join(lines) + "\n" if lines else ""


def export_docker(variables: dict[str, str]) -> str:
    """Export variables in Docker --env-file format.

    Args:
        variables: Dictionary of name -> value.

    Returns:
        String in Docker env-file format.
    """
    lines = []
    for name in sorted(variables):
        lines.append(f"{name}={variables[name]}")
    return "\n".join(lines) + "\n" if lines else ""


def export_json(variables: dict[str, str]) -> str:
    """Export variables as JSON.

    Args:
        variables: Dictionary of name -> value.

    Returns:
        JSON string.
    """
    return json.dumps(dict(sorted(variables.items())), indent=2) + "\n"


def export_yaml(variables: dict[str, str]) -> str:
    """Export variables in YAML-like format.

    Args:
        variables: Dictionary of name -> value.

    Returns:
        YAML-formatted string.
    """
    lines = []
    for name in sorted(variables):
        value = variables[name]
        if "\n" in value or ":" in value or "#" in value:
            value = f'"{value}"'
        lines.append(f"{name}: {value}")
    return "\n".join(lines) + "\n" if lines else ""


def export_k8s_secret(
    variables: dict[str, str],
    name: str = "app-secrets",
    namespace: str = "default",
) -> str:
    """Export variables as a Kubernetes Secret manifest.

    Args:
        variables: Dictionary of name -> value.
        name: Secret resource name.
        namespace: Kubernetes namespace.

    Returns:
        YAML-formatted Kubernetes Secret manifest.
    """
    lines = [
        "apiVersion: v1",
        "kind: Secret",
        "metadata:",
        f"  name: {name}",
        f"  namespace: {namespace}",
        "type: Opaque",
        "data:",
    ]
    for var_name in sorted(variables):
        encoded = base64.b64encode(variables[var_name].encode()).decode()
        lines.append(f"  {var_name}: {encoded}")
    return "\n".join(lines) + "\n"


def export_to_format(
    variables: dict[str, str],
    fmt: ExportFormat,
    **kwargs,
) -> str:
    """Export variables in the specified format.

    Args:
        variables: Dictionary of name -> value.
        fmt: Target format.
        **kwargs: Additional format-specific options.

    Returns:
        Formatted string.
    """
    exporters = {
        ExportFormat.DOTENV: export_dotenv,
        ExportFormat.SHELL: export_shell,
        ExportFormat.DOCKER: export_docker,
        ExportFormat.JSON: export_json,
        ExportFormat.YAML: export_yaml,
        ExportFormat.K8S_SECRET: export_k8s_secret,
    }
    exporter = exporters[fmt]
    if fmt == ExportFormat.K8S_SECRET:
        return exporter(variables, **kwargs)
    return exporter(variables)


def write_export(
    variables: dict[str, str],
    fmt: ExportFormat,
    output_path: Path,
    **kwargs,
) -> Path:
    """Export variables to a file.

    Args:
        variables: Dictionary of name -> value.
        fmt: Target format.
        output_path: Path to write the output file.
        **kwargs: Additional format-specific options.

    Returns:
        Path to the written file.
    """
    content = export_to_format(variables, fmt, **kwargs)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(content, encoding="utf-8")
    return output_path


def inject_to_process(
    variables: dict[str, str],
    command: list[str],
    inherit_env: bool = True,
) -> int:
    """Run a subprocess with injected environment variables.

    Args:
        variables: Variables to inject.
        command: Command and arguments to run.
        inherit_env: Whether to inherit current environment.

    Returns:
        Exit code of the subprocess.
    """
    env = dict(os.environ) if inherit_env else {}
    env.update(variables)

    result = subprocess.run(command, env=env)
    return result.returncode
