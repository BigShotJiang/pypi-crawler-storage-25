"""CLI interface for envault."""

from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Optional

import click
from rich.console import Console
from rich.table import Table

from envault import __version__
from envault.crypto import generate_key
from envault.diff import diff_environments
from envault.exporter import ExportFormat, export_to_format, write_export
from envault.importer import import_from_file, parse_dotenv
from envault.vault import DEFAULT_ENVIRONMENT, VAULT_FILENAME, Vault


console = Console()


def _get_vault(password: Optional[str] = None, key: Optional[str] = None, path: Optional[str] = None) -> Vault:
    """Create a vault instance from options."""
    vault_path = Path(path) if path else Path.cwd() / VAULT_FILENAME

    # Try key from env var
    if not key and not password:
        key = os.environ.get("ENVAULT_KEY")
    if not key and not password:
        password = os.environ.get("ENVAULT_PASSWORD")

    if not key and not password:
        password = click.prompt("Password", hide_input=True)

    return Vault(path=vault_path, password=password, key=key)


@click.group()
@click.version_option(version=__version__)
def main():
    """envault - Encrypted environment variable management."""
    pass


@main.command()
@click.option("--key", is_flag=True, help="Use key-based encryption instead of password")
@click.option("--path", default=None, help="Path to vault file")
def init(key: bool, path: Optional[str]):
    """Initialize a new vault."""
    vault_path = Path(path) if path else Path.cwd() / VAULT_FILENAME
    if vault_path.exists():
        console.print(f"[yellow]Vault already exists: {vault_path}[/yellow]")
        return

    if key:
        generated = generate_key()
        vault = Vault(path=vault_path, key=generated)
        vault.save()
        console.print(f"[green]Vault created: {vault_path}[/green]")
        console.print(f"[bold]Your key (save this securely):[/bold] {generated}")
    else:
        password = click.prompt("Password", hide_input=True, confirmation_prompt=True)
        vault = Vault(path=vault_path, password=password)
        vault.save()
        console.print(f"[green]Vault created: {vault_path}[/green]")


@main.command()
@click.argument("name")
@click.argument("value")
@click.option("-e", "--env", default=DEFAULT_ENVIRONMENT, help="Environment name")
@click.option("-d", "--description", default="", help="Variable description")
@click.option("-t", "--tag", multiple=True, help="Tags")
@click.option("--password", default=None, help="Password")
@click.option("--key", default=None, help="Encryption key")
@click.option("--path", default=None, help="Vault path")
def set(name: str, value: str, env: str, description: str, tag: tuple, password: Optional[str], key: Optional[str], path: Optional[str]):
    """Set a variable."""
    vault = _get_vault(password, key, path)
    if vault.exists():
        vault.load()
    vault.set(name, value, env, description=description, tags=list(tag))
    vault.save()
    console.print(f"[green]Set {name} in \\[{env}][/green]")


@main.command()
@click.argument("name")
@click.option("-e", "--env", default=DEFAULT_ENVIRONMENT, help="Environment name")
@click.option("--password", default=None, help="Password")
@click.option("--key", default=None, help="Encryption key")
@click.option("--path", default=None, help="Vault path")
def get(name: str, env: str, password: Optional[str], key: Optional[str], path: Optional[str]):
    """Get a variable value."""
    vault = _get_vault(password, key, path)
    vault.load()
    try:
        value = vault.get(name, env)
        click.echo(value)
    except KeyError as e:
        console.print(f"[red]{e}[/red]")
        sys.exit(1)


@main.command(name="list")
@click.option("-e", "--env", default=None, help="Environment name (all if not specified)")
@click.option("--password", default=None, help="Password")
@click.option("--key", default=None, help="Encryption key")
@click.option("--path", default=None, help="Vault path")
def list_cmd(env: Optional[str], password: Optional[str], key: Optional[str], path: Optional[str]):
    """List variables."""
    vault = _get_vault(password, key, path)
    vault.load()

    if env:
        envs = [env]
    else:
        envs = vault.list_environments()

    table = Table(title="Vault Variables")
    table.add_column("Environment", style="cyan")
    table.add_column("Variable", style="green")
    table.add_column("Description")
    table.add_column("Tags")

    for e in envs:
        for name in vault.list_vars(e):
            entry = vault.get_entry(name, e)
            table.add_row(e, name, entry.description, ", ".join(entry.tags))

    console.print(table)


@main.command()
@click.argument("name")
@click.option("-e", "--env", default=DEFAULT_ENVIRONMENT, help="Environment name")
@click.option("--password", default=None, help="Password")
@click.option("--key", default=None, help="Encryption key")
@click.option("--path", default=None, help="Vault path")
def delete(name: str, env: str, password: Optional[str], key: Optional[str], path: Optional[str]):
    """Delete a variable."""
    vault = _get_vault(password, key, path)
    vault.load()
    if vault.delete(name, env):
        vault.save()
        console.print(f"[green]Deleted {name} from \\[{env}][/green]")
    else:
        console.print(f"[red]Variable '{name}' not found in \\[{env}][/red]")
        sys.exit(1)


@main.command()
@click.option("-e", "--env", default=DEFAULT_ENVIRONMENT, help="Environment")
@click.option("-f", "--format", "fmt", type=click.Choice([f.value for f in ExportFormat]), default="dotenv")
@click.option("-o", "--output", default=None, help="Output file path")
@click.option("--password", default=None, help="Password")
@click.option("--key", default=None, help="Encryption key")
@click.option("--path", default=None, help="Vault path")
def export(env: str, fmt: str, output: Optional[str], password: Optional[str], key: Optional[str], path: Optional[str]):
    """Export variables."""
    vault = _get_vault(password, key, path)
    vault.load()
    variables = vault.get_all(env)
    export_fmt = ExportFormat(fmt)

    if output:
        write_export(variables, export_fmt, Path(output))
        console.print(f"[green]Exported to {output}[/green]")
    else:
        click.echo(export_to_format(variables, export_fmt), nl=False)


@main.command(name="import")
@click.argument("file_path", type=click.Path(exists=True))
@click.option("-e", "--env", default=DEFAULT_ENVIRONMENT, help="Target environment")
@click.option("--password", default=None, help="Password")
@click.option("--key", default=None, help="Encryption key")
@click.option("--path", default=None, help="Vault path")
def import_cmd(file_path: str, env: str, password: Optional[str], key: Optional[str], path: Optional[str]):
    """Import variables from a file."""
    vault = _get_vault(password, key, path)
    if vault.exists():
        vault.load()

    variables = import_from_file(Path(file_path))
    for name, value in variables.items():
        vault.set(name, value, env)

    vault.save()
    console.print(f"[green]Imported {len(variables)} variables into \\[{env}][/green]")


@main.command()
@click.argument("source_env")
@click.argument("target_env")
@click.option("--values", is_flag=True, help="Show masked values")
@click.option("--password", default=None, help="Password")
@click.option("--key", default=None, help="Encryption key")
@click.option("--path", default=None, help="Vault path")
def diff(source_env: str, target_env: str, values: bool, password: Optional[str], key: Optional[str], path: Optional[str]):
    """Compare two environments."""
    vault = _get_vault(password, key, path)
    vault.load()
    result = diff_environments(vault, source_env, target_env)
    console.print(result.to_text(show_values=values))


@main.command()
@click.option("-e", "--env", default=DEFAULT_ENVIRONMENT, help="Environment")
@click.argument("command", nargs=-1, required=True)
@click.option("--password", default=None, help="Password")
@click.option("--key", default=None, help="Encryption key")
@click.option("--path", default=None, help="Vault path")
def run(env: str, command: tuple, password: Optional[str], key: Optional[str], path: Optional[str]):
    """Run a command with injected variables."""
    from envault.exporter import inject_to_process

    vault = _get_vault(password, key, path)
    vault.load()
    variables = vault.get_all(env)
    exit_code = inject_to_process(variables, list(command))
    sys.exit(exit_code)


@main.command()
def keygen():
    """Generate a new encryption key."""
    key = generate_key()
    console.print(f"[bold]{key}[/bold]")
    console.print("[dim]Save this key securely. You'll need it to access the vault.[/dim]")


if __name__ == "__main__":
    main()
