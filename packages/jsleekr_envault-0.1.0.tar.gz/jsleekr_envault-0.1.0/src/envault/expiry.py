"""Variable expiry and TTL management for envault.

Track variable expiration dates, find expired or soon-expiring
variables, and manage rotation schedules.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class ExpiryPolicy:
    """Expiry policy for a variable."""

    variable: str
    environment: str
    expires_at: float  # Unix timestamp
    warn_days: int = 7  # Days before expiry to start warning
    auto_rotate: bool = False
    notes: str = ""

    @property
    def is_expired(self) -> bool:
        return time.time() > self.expires_at

    @property
    def days_until_expiry(self) -> float:
        return (self.expires_at - time.time()) / 86400

    @property
    def is_warning(self) -> bool:
        return not self.is_expired and self.days_until_expiry <= self.warn_days

    @property
    def status(self) -> str:
        if self.is_expired:
            return "expired"
        if self.is_warning:
            return "warning"
        return "ok"

    def to_dict(self) -> dict:
        return {
            "variable": self.variable,
            "environment": self.environment,
            "expires_at": self.expires_at,
            "warn_days": self.warn_days,
            "auto_rotate": self.auto_rotate,
            "notes": self.notes,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "ExpiryPolicy":
        return cls(
            variable=data["variable"],
            environment=data["environment"],
            expires_at=data["expires_at"],
            warn_days=data.get("warn_days", 7),
            auto_rotate=data.get("auto_rotate", False),
            notes=data.get("notes", ""),
        )


class ExpiryManager:
    """Manage variable expiry policies."""

    def __init__(self):
        self._policies: dict[tuple[str, str], ExpiryPolicy] = {}

    def set_expiry(
        self,
        variable: str,
        environment: str,
        expires_at: float,
        warn_days: int = 7,
        auto_rotate: bool = False,
        notes: str = "",
    ) -> ExpiryPolicy:
        """Set an expiry policy for a variable."""
        policy = ExpiryPolicy(
            variable=variable,
            environment=environment,
            expires_at=expires_at,
            warn_days=warn_days,
            auto_rotate=auto_rotate,
            notes=notes,
        )
        self._policies[(variable, environment)] = policy
        return policy

    def set_ttl(
        self,
        variable: str,
        environment: str,
        ttl_days: int,
        **kwargs,
    ) -> ExpiryPolicy:
        """Set expiry as a TTL from now."""
        expires_at = time.time() + (ttl_days * 86400)
        return self.set_expiry(variable, environment, expires_at, **kwargs)

    def get_policy(self, variable: str, environment: str) -> Optional[ExpiryPolicy]:
        """Get the expiry policy for a variable."""
        return self._policies.get((variable, environment))

    def remove_policy(self, variable: str, environment: str) -> bool:
        """Remove an expiry policy."""
        key = (variable, environment)
        if key in self._policies:
            del self._policies[key]
            return True
        return False

    def get_expired(self) -> list[ExpiryPolicy]:
        """Get all expired variables."""
        return sorted(
            [p for p in self._policies.values() if p.is_expired],
            key=lambda p: p.expires_at,
        )

    def get_warning(self) -> list[ExpiryPolicy]:
        """Get all variables in warning state."""
        return sorted(
            [p for p in self._policies.values() if p.is_warning],
            key=lambda p: p.expires_at,
        )

    def get_ok(self) -> list[ExpiryPolicy]:
        """Get all variables with OK status."""
        return sorted(
            [p for p in self._policies.values() if p.status == "ok"],
            key=lambda p: p.expires_at,
        )

    def get_by_environment(self, environment: str) -> list[ExpiryPolicy]:
        """Get all policies for an environment."""
        return sorted(
            [p for p in self._policies.values() if p.environment == environment],
            key=lambda p: p.variable,
        )

    def get_auto_rotate(self) -> list[ExpiryPolicy]:
        """Get all policies with auto-rotate enabled."""
        return [p for p in self._policies.values() if p.auto_rotate]

    def summary(self) -> dict[str, int]:
        """Get a summary of all policies by status."""
        return {
            "total": len(self._policies),
            "expired": len(self.get_expired()),
            "warning": len(self.get_warning()),
            "ok": len(self.get_ok()),
        }

    def to_list(self) -> list[dict]:
        """Serialize all policies."""
        return [p.to_dict() for p in self._policies.values()]

    @classmethod
    def from_list(cls, data: list[dict]) -> "ExpiryManager":
        """Deserialize from list of dicts."""
        mgr = cls()
        for d in data:
            p = ExpiryPolicy.from_dict(d)
            mgr._policies[(p.variable, p.environment)] = p
        return mgr

    def __len__(self) -> int:
        return len(self._policies)
