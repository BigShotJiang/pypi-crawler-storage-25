"""Import functionality for envault.

Supports importing environment variables from various sources:
- .env files
- Shell environment
- JSON files
- Key=value files
"""

from __future__ import annotations

import json
import os
import re
from pathlib import Path
from typing import Optional


def parse_dotenv(content: str) -> dict[str, str]:
    """Parse a .env file content into a dictionary.

    Handles:
    - Quoted and unquoted values
    - Single and double quotes
    - Comments and blank lines
    - Escape sequences in double-quoted values
    - Multiline values (not supported, newlines are escaped)

    Args:
        content: The .env file content.

    Returns:
        Dictionary of name -> value.
    """
    result: dict[str, str] = {}
    for line in content.splitlines():
        line = line.strip()

        # Skip empty lines and comments
        if not line or line.startswith("#"):
            continue

        # Handle export prefix
        if line.startswith("export "):
            line = line[7:].strip()

        # Split on first =
        if "=" not in line:
            continue

        name, value = line.split("=", 1)
        name = name.strip()
        value = value.strip()

        if not name:
            continue

        # Handle quoted values
        was_quoted = False
        if len(value) >= 2:
            if (value.startswith('"') and value.endswith('"')) or (
                value.startswith("'") and value.endswith("'")
            ):
                was_quoted = True
                quote_char = value[0]
                value = value[1:-1]
                if quote_char == '"':
                    # Process escape sequences in double-quoted values
                    # Use a placeholder for literal backslash to avoid double processing
                    _placeholder = "\x00BACKSLASH\x00"
                    value = value.replace("\\\\", _placeholder)
                    value = value.replace("\\n", "\n")
                    value = value.replace("\\t", "\t")
                    value = value.replace('\\"', '"')
                    value = value.replace(_placeholder, "\\")

        # Remove inline comments (only for unquoted values)
        if not was_quoted:
            comment_idx = value.find(" #")
            if comment_idx >= 0:
                value = value[:comment_idx].rstrip()

        result[name] = value

    return result


def parse_json_env(content: str) -> dict[str, str]:
    """Parse a JSON file into environment variables.

    Expects a flat object with string values.

    Args:
        content: JSON file content.

    Returns:
        Dictionary of name -> value.
    """
    data = json.loads(content)
    if not isinstance(data, dict):
        raise ValueError("JSON must be a flat object")

    result: dict[str, str] = {}
    for key, value in data.items():
        if isinstance(value, str):
            result[key] = value
        elif isinstance(value, (int, float, bool)):
            result[key] = str(value)
        elif value is None:
            result[key] = ""
        else:
            raise ValueError(f"Unsupported value type for key '{key}': {type(value).__name__}")

    return result


def import_from_file(path: Path) -> dict[str, str]:
    """Import variables from a file, auto-detecting format.

    Supports .env, .json files.

    Args:
        path: Path to the file.

    Returns:
        Dictionary of name -> value.

    Raises:
        FileNotFoundError: If the file doesn't exist.
        ValueError: If the format is unsupported.
    """
    if not path.exists():
        raise FileNotFoundError(f"File not found: {path}")

    content = path.read_text(encoding="utf-8")

    if path.suffix == ".json":
        return parse_json_env(content)

    # Default to .env format
    return parse_dotenv(content)


def import_from_env(
    prefix: Optional[str] = None,
    strip_prefix: bool = False,
) -> dict[str, str]:
    """Import variables from the current shell environment.

    Args:
        prefix: Only import variables starting with this prefix.
        strip_prefix: Remove the prefix from imported variable names.

    Returns:
        Dictionary of name -> value.
    """
    result: dict[str, str] = {}

    for name, value in os.environ.items():
        if prefix:
            if not name.startswith(prefix):
                continue
            key = name[len(prefix):] if strip_prefix else name
        else:
            key = name
        result[key] = value

    return result


def validate_var_name(name: str) -> bool:
    """Validate an environment variable name.

    Args:
        name: Variable name to validate.

    Returns:
        True if the name is valid.
    """
    if not name:
        return False
    return bool(re.match(r"^[A-Za-z_][A-Za-z0-9_-]*$", name))


def sanitize_var_name(name: str) -> str:
    """Sanitize a string into a valid variable name.

    Args:
        name: Raw string.

    Returns:
        Sanitized variable name.
    """
    # Replace non-alnum with underscore
    sanitized = re.sub(r"[^A-Za-z0-9_]", "_", name)
    # Ensure it starts with a letter or underscore
    if sanitized and sanitized[0].isdigit():
        sanitized = "_" + sanitized
    return sanitized.upper()
