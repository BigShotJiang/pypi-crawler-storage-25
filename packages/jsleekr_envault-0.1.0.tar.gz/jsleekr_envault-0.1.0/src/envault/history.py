"""Variable change history tracking for envault.

Records changes to variables over time, supporting
audit trails and rollback capabilities.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional


class ActionType(str, Enum):
    """Type of action performed on a variable."""

    SET = "set"
    DELETE = "delete"
    RENAME = "rename"
    IMPORT = "import"
    ROTATE = "rotate"


@dataclass
class HistoryEntry:
    """A single history record."""

    timestamp: float
    action: ActionType
    variable: str
    environment: str
    details: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "timestamp": self.timestamp,
            "action": self.action.value,
            "variable": self.variable,
            "environment": self.environment,
            "details": self.details,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "HistoryEntry":
        return cls(
            timestamp=data["timestamp"],
            action=ActionType(data["action"]),
            variable=data["variable"],
            environment=data["environment"],
            details=data.get("details", {}),
        )


class HistoryLog:
    """Tracks variable change history."""

    def __init__(self, max_entries: int = 1000):
        """Initialize history log.

        Args:
            max_entries: Maximum entries to retain.
        """
        self._entries: list[HistoryEntry] = []
        self._max_entries = max_entries

    @property
    def entries(self) -> list[HistoryEntry]:
        return list(self._entries)

    def record(
        self,
        action: ActionType,
        variable: str,
        environment: str,
        details: Optional[dict[str, Any]] = None,
    ) -> HistoryEntry:
        """Record a new history entry.

        Args:
            action: Type of action.
            variable: Variable name.
            environment: Environment name.
            details: Additional details.

        Returns:
            The created history entry.
        """
        entry = HistoryEntry(
            timestamp=time.time(),
            action=action,
            variable=variable,
            environment=environment,
            details=details or {},
        )
        self._entries.append(entry)

        # Trim if exceeding max
        if len(self._entries) > self._max_entries:
            self._entries = self._entries[-self._max_entries:]

        return entry

    def get_variable_history(
        self,
        variable: str,
        environment: Optional[str] = None,
    ) -> list[HistoryEntry]:
        """Get history for a specific variable.

        Args:
            variable: Variable name.
            environment: Optional environment filter.

        Returns:
            List of history entries, newest first.
        """
        entries = [e for e in self._entries if e.variable == variable]
        if environment:
            entries = [e for e in entries if e.environment == environment]
        return list(reversed(entries))

    def get_environment_history(self, environment: str) -> list[HistoryEntry]:
        """Get all history for an environment.

        Args:
            environment: Environment name.

        Returns:
            List of history entries, newest first.
        """
        entries = [e for e in self._entries if e.environment == environment]
        return list(reversed(entries))

    def get_recent(self, count: int = 10) -> list[HistoryEntry]:
        """Get the most recent history entries.

        Args:
            count: Number of entries to return.

        Returns:
            List of recent entries, newest first.
        """
        return list(reversed(self._entries[-count:]))

    def filter_by_action(self, action: ActionType) -> list[HistoryEntry]:
        """Filter history by action type.

        Args:
            action: Action type to filter by.

        Returns:
            Matching entries, newest first.
        """
        entries = [e for e in self._entries if e.action == action]
        return list(reversed(entries))

    def clear(self) -> int:
        """Clear all history entries.

        Returns:
            Number of entries cleared.
        """
        count = len(self._entries)
        self._entries.clear()
        return count

    def to_list(self) -> list[dict]:
        """Serialize to list of dicts."""
        return [e.to_dict() for e in self._entries]

    @classmethod
    def from_list(cls, data: list[dict], max_entries: int = 1000) -> "HistoryLog":
        """Deserialize from list of dicts."""
        log = cls(max_entries=max_entries)
        log._entries = [HistoryEntry.from_dict(d) for d in data]
        return log

    def __len__(self) -> int:
        return len(self._entries)

    def __bool__(self) -> bool:
        return bool(self._entries)
