"""Vault merge strategies for envault.

Merge variables from multiple vaults or environments with
configurable conflict resolution strategies.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional

from envault.vault import Vault, DEFAULT_ENVIRONMENT


class ConflictStrategy(str, Enum):
    """How to handle merge conflicts."""

    SOURCE_WINS = "source_wins"
    TARGET_WINS = "target_wins"
    ERROR = "error"
    SKIP = "skip"


@dataclass
class MergeConflict:
    """A merge conflict record."""

    variable: str
    environment: str
    source_value: str
    target_value: str
    resolution: str = ""


@dataclass
class MergeResult:
    """Result of a merge operation."""

    merged: int = 0
    skipped: int = 0
    conflicts: list[MergeConflict] = field(default_factory=list)
    new_vars: list[str] = field(default_factory=list)
    updated_vars: list[str] = field(default_factory=list)

    @property
    def total(self) -> int:
        return self.merged + self.skipped

    @property
    def has_conflicts(self) -> bool:
        return len(self.conflicts) > 0

    def summary(self) -> dict[str, Any]:
        return {
            "merged": self.merged,
            "skipped": self.skipped,
            "conflicts": len(self.conflicts),
            "new": len(self.new_vars),
            "updated": len(self.updated_vars),
        }


def merge_dicts(
    source: dict[str, str],
    target: dict[str, str],
    strategy: ConflictStrategy = ConflictStrategy.SOURCE_WINS,
) -> tuple[dict[str, str], MergeResult]:
    """Merge two variable dictionaries.

    Args:
        source: Source variables.
        target: Target variables (destination).
        strategy: How to resolve conflicts.

    Returns:
        Tuple of (merged dict, merge result).

    Raises:
        ValueError: If strategy is ERROR and conflicts exist.
    """
    result_dict = dict(target)
    merge_result = MergeResult()

    for name, source_value in source.items():
        if name in target:
            if source_value == target[name]:
                # No conflict
                merge_result.merged += 1
                continue

            conflict = MergeConflict(
                variable=name,
                environment="",
                source_value=source_value,
                target_value=target[name],
            )

            if strategy == ConflictStrategy.SOURCE_WINS:
                result_dict[name] = source_value
                conflict.resolution = "source"
                merge_result.updated_vars.append(name)
                merge_result.merged += 1
            elif strategy == ConflictStrategy.TARGET_WINS:
                conflict.resolution = "target"
                merge_result.merged += 1
            elif strategy == ConflictStrategy.SKIP:
                conflict.resolution = "skipped"
                merge_result.skipped += 1
            elif strategy == ConflictStrategy.ERROR:
                raise ValueError(
                    f"Merge conflict for '{name}': "
                    f"source='{source_value}', target='{target[name]}'"
                )

            merge_result.conflicts.append(conflict)
        else:
            result_dict[name] = source_value
            merge_result.new_vars.append(name)
            merge_result.merged += 1

    return result_dict, merge_result


def merge_environments(
    vault: Vault,
    source_env: str,
    target_env: str,
    strategy: ConflictStrategy = ConflictStrategy.SOURCE_WINS,
) -> MergeResult:
    """Merge variables from one environment into another within a vault.

    Args:
        vault: The vault.
        source_env: Source environment.
        target_env: Target environment.
        strategy: Conflict resolution strategy.

    Returns:
        MergeResult with details.
    """
    source_vars = vault.get_all(source_env)
    target_vars = vault.get_all(target_env)

    merged_dict, result = merge_dicts(source_vars, target_vars, strategy)

    # Apply merged result to vault
    for name, value in merged_dict.items():
        vault.set(name, value, target_env)

    return result


def merge_vaults(
    source: Vault,
    target: Vault,
    environment: str = DEFAULT_ENVIRONMENT,
    strategy: ConflictStrategy = ConflictStrategy.SOURCE_WINS,
) -> MergeResult:
    """Merge variables from source vault into target vault.

    Args:
        source: Source vault.
        target: Target vault.
        environment: Environment to merge.
        strategy: Conflict resolution strategy.

    Returns:
        MergeResult with details.
    """
    source_vars = source.get_all(environment)
    target_vars = target.get_all(environment)

    merged_dict, result = merge_dicts(source_vars, target_vars, strategy)

    for name, value in merged_dict.items():
        target.set(name, value, environment)

    return result


def diff_and_merge(
    source: dict[str, str],
    target: dict[str, str],
    include: Optional[set[str]] = None,
    exclude: Optional[set[str]] = None,
) -> tuple[dict[str, str], MergeResult]:
    """Selective merge with include/exclude filters.

    Args:
        source: Source variables.
        target: Target variables.
        include: Only merge these variable names (if set).
        exclude: Skip these variable names.

    Returns:
        Tuple of (merged dict, merge result).
    """
    filtered_source = {}
    for name, value in source.items():
        if include and name not in include:
            continue
        if exclude and name in exclude:
            continue
        filtered_source[name] = value

    return merge_dicts(filtered_source, target)
