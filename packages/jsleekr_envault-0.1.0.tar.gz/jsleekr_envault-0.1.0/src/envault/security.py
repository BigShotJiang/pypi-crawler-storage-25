"""Security utilities for envault.

Check for common security issues, generate .gitignore entries,
and validate vault configuration.
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


# Patterns that suggest sensitive variable names
SENSITIVE_PATTERNS = [
    re.compile(r".*(?:PASSWORD|PASSWD|PASS).*", re.IGNORECASE),
    re.compile(r".*(?:SECRET|TOKEN).*", re.IGNORECASE),
    re.compile(r".*(?:API_?KEY|AUTH).*", re.IGNORECASE),
    re.compile(r".*(?:PRIVATE_?KEY|PRIV_?KEY).*", re.IGNORECASE),
    re.compile(r".*(?:CREDENTIALS?|CRED).*", re.IGNORECASE),
    re.compile(r".*(?:ACCESS_?KEY).*", re.IGNORECASE),
    re.compile(r".*(?:SIGNING_?KEY|ENCRYPT).*", re.IGNORECASE),
]

# Patterns that suggest a value might be a secret
SECRET_VALUE_PATTERNS = [
    re.compile(r"^sk-[a-zA-Z0-9]+$"),  # OpenAI-style keys
    re.compile(r"^ghp_[a-zA-Z0-9]+$"),  # GitHub PAT
    re.compile(r"^glpat-[a-zA-Z0-9-]+$"),  # GitLab PAT
    re.compile(r"^xox[bpras]-[a-zA-Z0-9-]+$"),  # Slack token
    re.compile(r"^AKIA[0-9A-Z]{16}$"),  # AWS access key
    re.compile(r"^eyJ[a-zA-Z0-9_-]+\.eyJ[a-zA-Z0-9_-]+\.[a-zA-Z0-9_-]+$"),  # JWT
]


@dataclass
class SecurityIssue:
    """A detected security issue."""

    severity: str  # "high", "medium", "low"
    category: str
    message: str
    variable: str = ""
    environment: str = ""


@dataclass
class SecurityReport:
    """Result of a security audit."""

    issues: list[SecurityIssue] = field(default_factory=list)

    @property
    def high_count(self) -> int:
        return sum(1 for i in self.issues if i.severity == "high")

    @property
    def medium_count(self) -> int:
        return sum(1 for i in self.issues if i.severity == "medium")

    @property
    def low_count(self) -> int:
        return sum(1 for i in self.issues if i.severity == "low")

    @property
    def is_clean(self) -> bool:
        return len(self.issues) == 0

    def to_text(self) -> str:
        lines = [
            f"Security Report: {len(self.issues)} issue(s)",
            f"  High: {self.high_count}, Medium: {self.medium_count}, Low: {self.low_count}",
            "",
        ]
        for issue in sorted(self.issues, key=lambda i: {"high": 0, "medium": 1, "low": 2}[i.severity]):
            prefix = {"high": "!!!", "medium": "!!", "low": "!"}[issue.severity]
            line = f"  {prefix} [{issue.severity.upper()}] {issue.message}"
            if issue.variable:
                line += f" (var: {issue.variable})"
            lines.append(line)
        return "\n".join(lines)


def is_sensitive_name(name: str) -> bool:
    """Check if a variable name suggests it holds sensitive data.

    Args:
        name: Variable name.

    Returns:
        True if the name matches sensitive patterns.
    """
    return any(p.match(name) for p in SENSITIVE_PATTERNS)


def looks_like_secret(value: str) -> bool:
    """Check if a value looks like a known secret format.

    Args:
        value: Variable value.

    Returns:
        True if the value matches known secret patterns.
    """
    return any(p.match(value) for p in SECRET_VALUE_PATTERNS)


def check_password_strength(password: str) -> list[str]:
    """Check password strength for vault encryption.

    Args:
        password: The password to check.

    Returns:
        List of weakness descriptions. Empty if strong.
    """
    weaknesses = []

    if len(password) < 8:
        weaknesses.append("Password is too short (minimum 8 characters)")
    if len(password) < 12:
        weaknesses.append("Password should be at least 12 characters for strong security")
    if not re.search(r"[A-Z]", password):
        weaknesses.append("Password should contain uppercase letters")
    if not re.search(r"[a-z]", password):
        weaknesses.append("Password should contain lowercase letters")
    if not re.search(r"[0-9]", password):
        weaknesses.append("Password should contain numbers")
    if not re.search(r"[^A-Za-z0-9]", password):
        weaknesses.append("Password should contain special characters")

    common = {"password", "123456", "admin", "secret", "envault", "changeme"}
    if password.lower() in common:
        weaknesses.append("Password is too common")

    return weaknesses


def audit_variables(
    variables: dict[str, str],
    environment: str = "",
) -> SecurityReport:
    """Audit variables for security issues.

    Args:
        variables: Dictionary of name -> value to audit.
        environment: Environment name for reporting.

    Returns:
        SecurityReport with findings.
    """
    report = SecurityReport()

    for name, value in variables.items():
        # Check for empty sensitive vars
        if is_sensitive_name(name) and not value:
            report.issues.append(SecurityIssue(
                severity="medium",
                category="empty_secret",
                message=f"Sensitive variable '{name}' is empty",
                variable=name,
                environment=environment,
            ))

        # Check for short secrets
        if is_sensitive_name(name) and 0 < len(value) < 8:
            report.issues.append(SecurityIssue(
                severity="high",
                category="weak_secret",
                message=f"Sensitive variable '{name}' is suspiciously short ({len(value)} chars)",
                variable=name,
                environment=environment,
            ))

        # Check for duplicate values across sensitive vars
        if is_sensitive_name(name) and value == "changeme":
            report.issues.append(SecurityIssue(
                severity="high",
                category="default_secret",
                message=f"Sensitive variable '{name}' appears to be a default/placeholder value",
                variable=name,
                environment=environment,
            ))

    return report


def generate_gitignore_entries() -> str:
    """Generate .gitignore entries for envault files.

    Returns:
        Gitignore content string.
    """
    return "\n".join([
        "# envault - encrypted environment variables",
        ".envault.json",
        "*.envault.backup",
        ".envault.key",
        ".env",
        ".env.*",
        "!.env.example",
    ]) + "\n"


def check_gitignore(project_dir: Path) -> list[str]:
    """Check if .gitignore properly excludes vault files.

    Args:
        project_dir: Project root directory.

    Returns:
        List of warnings about missing gitignore entries.
    """
    gitignore_path = project_dir / ".gitignore"
    warnings = []

    if not gitignore_path.exists():
        warnings.append(".gitignore file not found")
        return warnings

    content = gitignore_path.read_text(encoding="utf-8")
    lines = {line.strip() for line in content.splitlines()}

    required = [".envault.json", "*.envault.backup", ".env"]
    for entry in required:
        if entry not in lines:
            warnings.append(f"Missing gitignore entry: {entry}")

    return warnings
