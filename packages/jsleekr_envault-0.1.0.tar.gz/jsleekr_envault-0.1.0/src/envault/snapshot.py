"""Vault snapshot functionality for envault.

Create point-in-time snapshots of vault state for comparison,
auditing, and change tracking between states.
"""

from __future__ import annotations

import hashlib
import json
import time
from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class VarSnapshot:
    """Snapshot of a single variable (name + hash of value)."""

    name: str
    value_hash: str
    environment: str
    tags: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "value_hash": self.value_hash,
            "environment": self.environment,
            "tags": self.tags,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "VarSnapshot":
        return cls(
            name=data["name"],
            value_hash=data["value_hash"],
            environment=data["environment"],
            tags=data.get("tags", []),
        )


@dataclass
class Snapshot:
    """A point-in-time snapshot of vault state."""

    id: str
    timestamp: float
    label: str
    variables: list[VarSnapshot] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def var_count(self) -> int:
        return len(self.variables)

    @property
    def environments(self) -> list[str]:
        return sorted(set(v.environment for v in self.variables))

    def get_vars(self, environment: Optional[str] = None) -> list[VarSnapshot]:
        if environment:
            return [v for v in self.variables if v.environment == environment]
        return list(self.variables)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "timestamp": self.timestamp,
            "label": self.label,
            "variables": [v.to_dict() for v in self.variables],
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Snapshot":
        return cls(
            id=data["id"],
            timestamp=data["timestamp"],
            label=data.get("label", ""),
            variables=[VarSnapshot.from_dict(v) for v in data.get("variables", [])],
            metadata=data.get("metadata", {}),
        )


@dataclass
class SnapshotDiff:
    """Differences between two snapshots."""

    snapshot_a: str
    snapshot_b: str
    added: list[str] = field(default_factory=list)
    removed: list[str] = field(default_factory=list)
    changed: list[str] = field(default_factory=list)
    unchanged: list[str] = field(default_factory=list)

    @property
    def has_changes(self) -> bool:
        return bool(self.added or self.removed or self.changed)

    @property
    def summary(self) -> dict[str, int]:
        return {
            "added": len(self.added),
            "removed": len(self.removed),
            "changed": len(self.changed),
            "unchanged": len(self.unchanged),
        }


def hash_value(value: str) -> str:
    """Create a hash of a value for comparison without storing plaintext."""
    return hashlib.sha256(value.encode("utf-8")).hexdigest()[:16]


def create_snapshot(
    variables: dict[str, dict[str, str]],
    label: str = "",
    metadata: Optional[dict] = None,
) -> Snapshot:
    """Create a snapshot from vault variables.

    Args:
        variables: Dict of environment -> {name: value}.
        label: Optional label.
        metadata: Optional metadata.

    Returns:
        New Snapshot instance.
    """
    ts = time.time()
    snap_id = hashlib.sha256(f"{ts}{label}".encode()).hexdigest()[:12]

    var_snapshots = []
    for env_name, env_vars in sorted(variables.items()):
        for var_name, value in sorted(env_vars.items()):
            var_snapshots.append(VarSnapshot(
                name=var_name,
                value_hash=hash_value(value),
                environment=env_name,
            ))

    return Snapshot(
        id=snap_id,
        timestamp=ts,
        label=label,
        variables=var_snapshots,
        metadata=metadata or {},
    )


def compare_snapshots(
    snap_a: Snapshot,
    snap_b: Snapshot,
    environment: Optional[str] = None,
) -> SnapshotDiff:
    """Compare two snapshots.

    Args:
        snap_a: First snapshot (older).
        snap_b: Second snapshot (newer).
        environment: Optional environment filter.

    Returns:
        SnapshotDiff with changes.
    """
    vars_a = {
        (v.environment, v.name): v.value_hash
        for v in snap_a.get_vars(environment)
    }
    vars_b = {
        (v.environment, v.name): v.value_hash
        for v in snap_b.get_vars(environment)
    }

    keys_a = set(vars_a.keys())
    keys_b = set(vars_b.keys())

    added = sorted(f"{env}:{name}" for env, name in (keys_b - keys_a))
    removed = sorted(f"{env}:{name}" for env, name in (keys_a - keys_b))
    changed = sorted(
        f"{env}:{name}"
        for env, name in (keys_a & keys_b)
        if vars_a[(env, name)] != vars_b[(env, name)]
    )
    unchanged = sorted(
        f"{env}:{name}"
        for env, name in (keys_a & keys_b)
        if vars_a[(env, name)] == vars_b[(env, name)]
    )

    return SnapshotDiff(
        snapshot_a=snap_a.id,
        snapshot_b=snap_b.id,
        added=added,
        removed=removed,
        changed=changed,
        unchanged=unchanged,
    )
