"""Variable groups and namespacing for envault.

Organize variables into logical groups (database, api, cache, etc.)
with prefix-based or explicit grouping.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class VariableGroup:
    """A logical group of variables."""

    name: str
    prefix: str = ""
    description: str = ""
    variables: list[str] = field(default_factory=list)

    @property
    def count(self) -> int:
        return len(self.variables)

    def matches(self, var_name: str) -> bool:
        """Check if a variable belongs to this group.

        Matches by explicit membership or prefix.
        """
        if var_name in self.variables:
            return True
        if self.prefix and var_name.startswith(self.prefix):
            return True
        return False

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "prefix": self.prefix,
            "description": self.description,
            "variables": self.variables,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "VariableGroup":
        return cls(
            name=data["name"],
            prefix=data.get("prefix", ""),
            description=data.get("description", ""),
            variables=data.get("variables", []),
        )


class GroupManager:
    """Manage variable groups."""

    def __init__(self):
        self._groups: dict[str, VariableGroup] = {}

    def add_group(self, group: VariableGroup) -> None:
        """Add or update a group."""
        self._groups[group.name] = group

    def create_group(
        self,
        name: str,
        prefix: str = "",
        description: str = "",
        variables: Optional[list[str]] = None,
    ) -> VariableGroup:
        """Create and add a new group."""
        group = VariableGroup(
            name=name,
            prefix=prefix,
            description=description,
            variables=variables or [],
        )
        self._groups[name] = group
        return group

    def remove_group(self, name: str) -> bool:
        """Remove a group."""
        if name in self._groups:
            del self._groups[name]
            return True
        return False

    def get_group(self, name: str) -> Optional[VariableGroup]:
        """Get a group by name."""
        return self._groups.get(name)

    def list_groups(self) -> list[VariableGroup]:
        """List all groups sorted by name."""
        return sorted(self._groups.values(), key=lambda g: g.name)

    def find_group(self, var_name: str) -> Optional[VariableGroup]:
        """Find which group a variable belongs to.

        Returns the first matching group.
        """
        for group in self._groups.values():
            if group.matches(var_name):
                return group
        return None

    def find_all_groups(self, var_name: str) -> list[VariableGroup]:
        """Find all groups a variable belongs to."""
        return [g for g in self._groups.values() if g.matches(var_name)]

    def categorize(self, var_names: list[str]) -> dict[str, list[str]]:
        """Categorize variables into groups.

        Args:
            var_names: List of variable names.

        Returns:
            Dict of group_name -> [variable_names].
            Ungrouped variables go under "ungrouped".
        """
        result: dict[str, list[str]] = {}

        for name in sorted(var_names):
            group = self.find_group(name)
            group_name = group.name if group else "ungrouped"
            result.setdefault(group_name, []).append(name)

        return result

    def add_variable_to_group(self, var_name: str, group_name: str) -> bool:
        """Add a variable to a group explicitly."""
        group = self._groups.get(group_name)
        if not group:
            return False
        if var_name not in group.variables:
            group.variables.append(var_name)
        return True

    def remove_variable_from_group(self, var_name: str, group_name: str) -> bool:
        """Remove a variable from a group."""
        group = self._groups.get(group_name)
        if not group or var_name not in group.variables:
            return False
        group.variables.remove(var_name)
        return True

    def to_list(self) -> list[dict]:
        """Serialize all groups."""
        return [g.to_dict() for g in self._groups.values()]

    @classmethod
    def from_list(cls, data: list[dict]) -> "GroupManager":
        """Deserialize from list."""
        mgr = cls()
        for d in data:
            mgr.add_group(VariableGroup.from_dict(d))
        return mgr

    def __len__(self) -> int:
        return len(self._groups)

    def __contains__(self, name: str) -> bool:
        return name in self._groups


# Common group presets
def create_default_groups() -> GroupManager:
    """Create a GroupManager with common group presets."""
    mgr = GroupManager()
    mgr.create_group("database", prefix="DB_", description="Database configuration")
    mgr.create_group("api", prefix="API_", description="API keys and endpoints")
    mgr.create_group("auth", prefix="AUTH_", description="Authentication settings")
    mgr.create_group("cache", prefix="CACHE_", description="Cache configuration")
    mgr.create_group("mail", prefix="MAIL_", description="Email settings")
    mgr.create_group("aws", prefix="AWS_", description="AWS services")
    mgr.create_group("app", prefix="APP_", description="Application settings")
    return mgr
