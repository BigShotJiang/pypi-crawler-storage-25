"""Vault - the core storage engine for envault.

A Vault is a JSON file that stores encrypted environment variables
organized by environment (dev, staging, prod, etc.).
"""

from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterator, Optional

from envault.crypto import (
    EncryptedPayload,
    decrypt,
    decrypt_with_key,
    encrypt,
    encrypt_with_key,
    generate_key,
)


VAULT_FILENAME = ".envault.json"
DEFAULT_ENVIRONMENT = "default"


@dataclass
class VaultEntry:
    """A single variable entry in the vault."""

    encrypted: EncryptedPayload
    description: str = ""
    created_at: float = 0.0
    updated_at: float = 0.0
    tags: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "encrypted": self.encrypted.to_dict(),
            "description": self.description,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "tags": self.tags,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "VaultEntry":
        return cls(
            encrypted=EncryptedPayload.from_dict(data["encrypted"]),
            description=data.get("description", ""),
            created_at=data.get("created_at", 0.0),
            updated_at=data.get("updated_at", 0.0),
            tags=data.get("tags", []),
        )


@dataclass
class Environment:
    """A named environment containing variable entries."""

    name: str
    entries: dict[str, VaultEntry] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "entries": {k: v.to_dict() for k, v in self.entries.items()},
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Environment":
        return cls(
            name=data["name"],
            entries={k: VaultEntry.from_dict(v) for k, v in data.get("entries", {}).items()},
        )


class Vault:
    """Encrypted environment variable vault.

    Stores variables organized by environment, encrypted with either
    a password or a shared key.
    """

    def __init__(
        self,
        path: Optional[Path] = None,
        password: Optional[str] = None,
        key: Optional[str] = None,
    ):
        """Initialize a vault.

        Args:
            path: Path to the vault file. Defaults to .envault.json in cwd.
            password: Password for encryption. Either password or key is required.
            key: Base64-encoded encryption key. Either password or key is required.
        """
        self.path = path or Path.cwd() / VAULT_FILENAME
        self._password = password
        self._key = key
        self._environments: dict[str, Environment] = {}
        self._metadata: dict[str, Any] = {
            "version": 1,
            "created_at": time.time(),
        }

        if not password and not key:
            raise ValueError("Either password or key must be provided")

    @property
    def environments(self) -> dict[str, Environment]:
        """Access the environments dictionary."""
        return self._environments

    def _encrypt_value(self, plaintext: str) -> EncryptedPayload:
        if self._key:
            return encrypt_with_key(plaintext, self._key)
        return encrypt(plaintext, self._password)

    def _decrypt_value(self, payload: EncryptedPayload) -> str:
        if self._key:
            return decrypt_with_key(payload, self._key)
        return decrypt(payload, self._password)

    def set(
        self,
        name: str,
        value: str,
        environment: str = DEFAULT_ENVIRONMENT,
        description: str = "",
        tags: Optional[list[str]] = None,
    ) -> None:
        """Set a variable in the vault.

        Args:
            name: Variable name (e.g., DATABASE_URL).
            value: Variable value.
            environment: Target environment name.
            description: Optional description.
            tags: Optional tags for categorization.
        """
        if not name:
            raise ValueError("Variable name cannot be empty")
        if not name.replace("_", "").replace("-", "").isalnum():
            raise ValueError(
                f"Invalid variable name: {name}. "
                "Use only alphanumeric characters, underscores, and hyphens."
            )

        now = time.time()
        env = self._environments.setdefault(environment, Environment(name=environment))
        existing = env.entries.get(name)

        entry = VaultEntry(
            encrypted=self._encrypt_value(value),
            description=description or (existing.description if existing else ""),
            created_at=existing.created_at if existing else now,
            updated_at=now,
            tags=tags if tags is not None else (existing.tags if existing else []),
        )
        env.entries[name] = entry

    def get(self, name: str, environment: str = DEFAULT_ENVIRONMENT) -> str:
        """Get a decrypted variable value.

        Args:
            name: Variable name.
            environment: Environment to look up.

        Returns:
            The decrypted value.

        Raises:
            KeyError: If the variable doesn't exist.
        """
        env = self._environments.get(environment)
        if not env or name not in env.entries:
            raise KeyError(f"Variable '{name}' not found in environment '{environment}'")

        return self._decrypt_value(env.entries[name].encrypted)

    def get_entry(self, name: str, environment: str = DEFAULT_ENVIRONMENT) -> VaultEntry:
        """Get the full entry metadata (without decryption).

        Args:
            name: Variable name.
            environment: Environment to look up.

        Returns:
            VaultEntry with encrypted data and metadata.

        Raises:
            KeyError: If the variable doesn't exist.
        """
        env = self._environments.get(environment)
        if not env or name not in env.entries:
            raise KeyError(f"Variable '{name}' not found in environment '{environment}'")
        return env.entries[name]

    def delete(self, name: str, environment: str = DEFAULT_ENVIRONMENT) -> bool:
        """Delete a variable from the vault.

        Args:
            name: Variable name to delete.
            environment: Environment to delete from.

        Returns:
            True if the variable was deleted, False if not found.
        """
        env = self._environments.get(environment)
        if not env or name not in env.entries:
            return False
        del env.entries[name]
        if not env.entries:
            del self._environments[environment]
        return True

    def list_vars(self, environment: str = DEFAULT_ENVIRONMENT) -> list[str]:
        """List variable names in an environment.

        Args:
            environment: Environment to list.

        Returns:
            Sorted list of variable names.
        """
        env = self._environments.get(environment)
        if not env:
            return []
        return sorted(env.entries.keys())

    def list_environments(self) -> list[str]:
        """List all environment names.

        Returns:
            Sorted list of environment names.
        """
        return sorted(self._environments.keys())

    def has(self, name: str, environment: str = DEFAULT_ENVIRONMENT) -> bool:
        """Check if a variable exists.

        Args:
            name: Variable name.
            environment: Environment to check.

        Returns:
            True if the variable exists.
        """
        env = self._environments.get(environment)
        return env is not None and name in env.entries

    def get_all(self, environment: str = DEFAULT_ENVIRONMENT) -> dict[str, str]:
        """Get all decrypted variables in an environment.

        Args:
            environment: Environment to export.

        Returns:
            Dictionary of name -> decrypted value.
        """
        env = self._environments.get(environment)
        if not env:
            return {}
        return {name: self._decrypt_value(entry.encrypted) for name, entry in env.entries.items()}

    def copy_var(
        self,
        name: str,
        from_env: str,
        to_env: str,
    ) -> None:
        """Copy a variable from one environment to another.

        Args:
            name: Variable name.
            from_env: Source environment.
            to_env: Destination environment.
        """
        value = self.get(name, from_env)
        entry = self.get_entry(name, from_env)
        self.set(name, value, to_env, description=entry.description, tags=entry.tags)

    def copy_environment(self, from_env: str, to_env: str) -> int:
        """Copy all variables from one environment to another.

        Args:
            from_env: Source environment.
            to_env: Destination environment.

        Returns:
            Number of variables copied.
        """
        names = self.list_vars(from_env)
        for name in names:
            self.copy_var(name, from_env, to_env)
        return len(names)

    def search(
        self,
        pattern: str,
        environment: Optional[str] = None,
    ) -> dict[str, list[str]]:
        """Search for variables by name pattern.

        Args:
            pattern: Substring to search for (case-insensitive).
            environment: Limit search to specific environment, or all if None.

        Returns:
            Dictionary mapping environment names to lists of matching variable names.
        """
        results: dict[str, list[str]] = {}
        pattern_lower = pattern.lower()

        envs = (
            [self._environments[environment]]
            if environment and environment in self._environments
            else self._environments.values()
        )

        for env in envs:
            matches = [name for name in env.entries if pattern_lower in name.lower()]
            if matches:
                results[env.name] = sorted(matches)

        return results

    def filter_by_tag(
        self,
        tag: str,
        environment: str = DEFAULT_ENVIRONMENT,
    ) -> list[str]:
        """Filter variables by tag.

        Args:
            tag: Tag to filter by.
            environment: Environment to search.

        Returns:
            List of variable names with the given tag.
        """
        env = self._environments.get(environment)
        if not env:
            return []
        return sorted(name for name, entry in env.entries.items() if tag in entry.tags)

    def rotate_password(self, new_password: str) -> int:
        """Re-encrypt all variables with a new password.

        Args:
            new_password: The new password to encrypt with.

        Returns:
            Number of variables re-encrypted.
        """
        if self._key:
            raise ValueError("Cannot rotate password on a key-based vault")

        count = 0
        old_password = self._password
        for env in self._environments.values():
            for name, entry in env.entries.items():
                plaintext = self._decrypt_value(entry.encrypted)
                self._password = new_password
                entry.encrypted = self._encrypt_value(plaintext)
                self._password = old_password
                count += 1

        self._password = new_password
        return count

    def rotate_key(self, new_key: str) -> int:
        """Re-encrypt all variables with a new key.

        Args:
            new_key: The new base64-encoded key.

        Returns:
            Number of variables re-encrypted.
        """
        if self._password and not self._key:
            raise ValueError("Cannot rotate key on a password-based vault")

        count = 0
        old_key = self._key
        for env in self._environments.values():
            for name, entry in env.entries.items():
                plaintext = self._decrypt_value(entry.encrypted)
                self._key = new_key
                entry.encrypted = self._encrypt_value(plaintext)
                self._key = old_key
                count += 1

        self._key = new_key
        return count

    def rename_var(
        self,
        old_name: str,
        new_name: str,
        environment: str = DEFAULT_ENVIRONMENT,
    ) -> None:
        """Rename a variable.

        Args:
            old_name: Current variable name.
            new_name: New variable name.
            environment: Environment containing the variable.

        Raises:
            KeyError: If old_name doesn't exist.
            ValueError: If new_name already exists.
        """
        env = self._environments.get(environment)
        if not env or old_name not in env.entries:
            raise KeyError(f"Variable '{old_name}' not found in environment '{environment}'")
        if new_name in env.entries:
            raise ValueError(f"Variable '{new_name}' already exists in environment '{environment}'")

        entry = env.entries.pop(old_name)
        env.entries[new_name] = entry

    def bulk_set(
        self,
        variables: dict[str, str],
        environment: str = DEFAULT_ENVIRONMENT,
    ) -> int:
        """Set multiple variables at once.

        Args:
            variables: Dictionary of name -> value.
            environment: Target environment.

        Returns:
            Number of variables set.
        """
        for name, value in variables.items():
            self.set(name, value, environment)
        return len(variables)

    def stats(self) -> dict[str, Any]:
        """Get vault statistics.

        Returns:
            Dictionary with counts and metadata.
        """
        total_vars = sum(len(env.entries) for env in self._environments.values())
        return {
            "environments": len(self._environments),
            "total_variables": total_vars,
            "environment_details": {
                env.name: len(env.entries) for env in self._environments.values()
            },
            "version": self._metadata.get("version", 1),
        }

    def save(self) -> Path:
        """Save the vault to disk.

        Returns:
            Path to the saved file.
        """
        data = {
            "metadata": self._metadata,
            "environments": {k: v.to_dict() for k, v in self._environments.items()},
        }

        self.path.parent.mkdir(parents=True, exist_ok=True)

        # Write atomically via temp file
        tmp_path = self.path.with_suffix(".tmp")
        try:
            tmp_path.write_text(json.dumps(data, indent=2), encoding="utf-8")
            tmp_path.replace(self.path)
        except Exception:
            if tmp_path.exists():
                tmp_path.unlink()
            raise

        return self.path

    def load(self) -> "Vault":
        """Load the vault from disk.

        Returns:
            Self for chaining.

        Raises:
            FileNotFoundError: If the vault file doesn't exist.
        """
        if not self.path.exists():
            raise FileNotFoundError(f"Vault not found: {self.path}")

        data = json.loads(self.path.read_text(encoding="utf-8"))
        self._metadata = data.get("metadata", self._metadata)
        self._environments = {
            k: Environment.from_dict(v) for k, v in data.get("environments", {}).items()
        }
        return self

    def exists(self) -> bool:
        """Check if the vault file exists on disk."""
        return self.path.exists()

    def __len__(self) -> int:
        """Total number of variables across all environments."""
        return sum(len(env.entries) for env in self._environments.values())

    def __contains__(self, item: str) -> bool:
        """Check if a variable exists in the default environment."""
        return self.has(item)

    def __iter__(self) -> Iterator[str]:
        """Iterate over variable names in the default environment."""
        env = self._environments.get(DEFAULT_ENVIRONMENT)
        if env:
            yield from sorted(env.entries.keys())
