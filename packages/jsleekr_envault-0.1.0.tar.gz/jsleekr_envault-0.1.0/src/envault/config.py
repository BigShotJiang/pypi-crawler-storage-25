"""Configuration file management for envault.

Load and save envault configuration from .envaultrc files
or pyproject.toml [tool.envault] sections.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional


@dataclass
class EnvaultConfig:
    """Envault project configuration."""

    vault_path: str = ".envault.json"
    default_environment: str = "default"
    encryption_method: str = "password"  # "password" or "key"
    export_format: str = "dotenv"
    auto_backup: bool = True
    max_backups: int = 5
    warn_days: int = 7
    inheritance: dict[str, str] = field(default_factory=dict)
    validation_rules: dict[str, list[dict]] = field(default_factory=dict)
    excluded_envs: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "vault_path": self.vault_path,
            "default_environment": self.default_environment,
            "encryption_method": self.encryption_method,
            "export_format": self.export_format,
            "auto_backup": self.auto_backup,
            "max_backups": self.max_backups,
            "warn_days": self.warn_days,
            "inheritance": self.inheritance,
            "validation_rules": self.validation_rules,
            "excluded_envs": self.excluded_envs,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "EnvaultConfig":
        return cls(
            vault_path=data.get("vault_path", ".envault.json"),
            default_environment=data.get("default_environment", "default"),
            encryption_method=data.get("encryption_method", "password"),
            export_format=data.get("export_format", "dotenv"),
            auto_backup=data.get("auto_backup", True),
            max_backups=data.get("max_backups", 5),
            warn_days=data.get("warn_days", 7),
            inheritance=data.get("inheritance", {}),
            validation_rules=data.get("validation_rules", {}),
            excluded_envs=data.get("excluded_envs", []),
        )

    def merge(self, overrides: dict) -> "EnvaultConfig":
        """Create a new config with overrides applied."""
        base = self.to_dict()
        base.update(overrides)
        return EnvaultConfig.from_dict(base)


CONFIG_FILENAME = ".envaultrc"


def load_config(project_dir: Path) -> EnvaultConfig:
    """Load envault configuration from project directory.

    Searches for .envaultrc (JSON) or pyproject.toml [tool.envault].

    Args:
        project_dir: Project root directory.

    Returns:
        EnvaultConfig (defaults if no config found).
    """
    # Try .envaultrc
    rc_path = project_dir / CONFIG_FILENAME
    if rc_path.exists():
        return _load_rc(rc_path)

    # Try pyproject.toml
    pyproject_path = project_dir / "pyproject.toml"
    if pyproject_path.exists():
        return _load_pyproject(pyproject_path)

    return EnvaultConfig()


def _load_rc(path: Path) -> EnvaultConfig:
    """Load from .envaultrc JSON file."""
    content = path.read_text(encoding="utf-8")
    data = json.loads(content)
    return EnvaultConfig.from_dict(data)


def _load_pyproject(path: Path) -> EnvaultConfig:
    """Load from pyproject.toml [tool.envault] section."""
    try:
        import tomllib
    except ImportError:
        try:
            import tomli as tomllib  # type: ignore
        except ImportError:
            return EnvaultConfig()

    content = path.read_bytes()
    data = tomllib.loads(content.decode("utf-8"))

    envault_config = data.get("tool", {}).get("envault", {})
    if not envault_config:
        return EnvaultConfig()

    return EnvaultConfig.from_dict(envault_config)


def save_config(config: EnvaultConfig, project_dir: Path) -> Path:
    """Save envault configuration to .envaultrc.

    Args:
        config: Configuration to save.
        project_dir: Project root directory.

    Returns:
        Path to saved config file.
    """
    rc_path = project_dir / CONFIG_FILENAME
    rc_path.write_text(
        json.dumps(config.to_dict(), indent=2) + "\n",
        encoding="utf-8",
    )
    return rc_path


def find_project_root(start: Path = Path.cwd()) -> Path:
    """Find the project root by looking for config files.

    Searches upward for .envaultrc, .envault.json, pyproject.toml, or .git.

    Args:
        start: Starting directory.

    Returns:
        Project root directory (or start if not found).
    """
    markers = [CONFIG_FILENAME, ".envault.json", "pyproject.toml", ".git"]
    current = start.resolve()

    while True:
        for marker in markers:
            if (current / marker).exists():
                return current
        parent = current.parent
        if parent == current:
            break
        current = parent

    return start
