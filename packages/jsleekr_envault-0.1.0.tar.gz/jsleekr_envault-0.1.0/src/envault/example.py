"""Generate .env.example files from vault contents.

Create template files with variable names, descriptions,
and placeholder values without exposing actual secrets.
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

from envault.security import is_sensitive_name
from envault.vault import Vault, DEFAULT_ENVIRONMENT


def generate_placeholder(name: str, value: str = "") -> str:
    """Generate a placeholder value for a variable.

    Args:
        name: Variable name.
        value: Actual value (used for non-sensitive hints).

    Returns:
        Placeholder string.
    """
    name_upper = name.upper()

    if is_sensitive_name(name):
        return "your-secret-here"

    # Type-based placeholders
    if "PORT" in name_upper:
        return "3000"
    if "HOST" in name_upper or "HOSTNAME" in name_upper:
        return "localhost"
    if "URL" in name_upper or "URI" in name_upper:
        return "https://example.com"
    if "EMAIL" in name_upper or "MAIL" in name_upper:
        return "user@example.com"
    if "DEBUG" in name_upper:
        return "false"
    if "ENV" in name_upper or "ENVIRONMENT" in name_upper:
        return "development"
    if "LOG" in name_upper and "LEVEL" in name_upper:
        return "info"
    if "TIMEOUT" in name_upper:
        return "30"
    if "MAX" in name_upper or "LIMIT" in name_upper:
        return "100"
    if "PATH" in name_upper or "DIR" in name_upper:
        return "/path/to/dir"
    if "NAME" in name_upper:
        return "my-app"
    if "VERSION" in name_upper:
        return "1.0.0"

    # For non-sensitive, show actual short values
    if value and len(value) <= 20 and not is_sensitive_name(name):
        return value

    return "your-value-here"


def generate_example_env(
    vault: Vault,
    environment: str = DEFAULT_ENVIRONMENT,
    include_descriptions: bool = True,
    include_types: bool = True,
    group_by_tag: bool = False,
) -> str:
    """Generate a .env.example file content from vault.

    Args:
        vault: The vault.
        environment: Environment to generate for.
        include_descriptions: Add description comments.
        include_types: Add type hint comments.
        group_by_tag: Group variables by tag.

    Returns:
        .env.example file content.
    """
    lines: list[str] = [
        "# Environment Variables",
        "# Copy this file to .env and fill in the values",
        "#",
        f"# Generated from envault (environment: {environment})",
        "",
    ]

    var_names = vault.list_vars(environment)
    if not var_names:
        return "\n".join(lines)

    if group_by_tag:
        # Group by first tag
        tagged: dict[str, list[str]] = {}
        untagged: list[str] = []

        for name in var_names:
            entry = vault.get_entry(name, environment)
            if entry.tags:
                tag = entry.tags[0]
                tagged.setdefault(tag, []).append(name)
            else:
                untagged.append(name)

        for tag in sorted(tagged):
            lines.append(f"# --- {tag} ---")
            for name in tagged[tag]:
                lines.extend(_format_var_lines(vault, name, environment, include_descriptions))
            lines.append("")

        if untagged:
            lines.append("# --- other ---")
            for name in untagged:
                lines.extend(_format_var_lines(vault, name, environment, include_descriptions))
    else:
        for name in var_names:
            lines.extend(_format_var_lines(vault, name, environment, include_descriptions))

    return "\n".join(lines) + "\n"


def _format_var_lines(
    vault: Vault,
    name: str,
    environment: str,
    include_descriptions: bool,
) -> list[str]:
    """Format a single variable for the example file."""
    lines = []
    entry = vault.get_entry(name, environment)
    value = vault.get(name, environment)
    placeholder = generate_placeholder(name, value)

    if include_descriptions and entry.description:
        lines.append(f"# {entry.description}")

    if is_sensitive_name(name):
        lines.append(f"# (sensitive)")

    lines.append(f"{name}={placeholder}")
    return lines


def write_example_env(
    vault: Vault,
    output_path: Path,
    environment: str = DEFAULT_ENVIRONMENT,
    **kwargs,
) -> Path:
    """Write .env.example file.

    Args:
        vault: The vault.
        output_path: Path to write.
        environment: Environment to generate for.
        **kwargs: Additional options for generate_example_env.

    Returns:
        Path to written file.
    """
    content = generate_example_env(vault, environment, **kwargs)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(content, encoding="utf-8")
    return output_path


def diff_example_env(
    vault: Vault,
    example_path: Path,
    environment: str = DEFAULT_ENVIRONMENT,
) -> dict[str, list[str]]:
    """Compare vault variables with an existing .env.example file.

    Args:
        vault: The vault.
        example_path: Path to existing .env.example.
        environment: Environment to compare.

    Returns:
        Dict with 'missing' and 'extra' variable lists.
    """
    from envault.importer import parse_dotenv

    if not example_path.exists():
        return {
            "missing": vault.list_vars(environment),
            "extra": [],
        }

    content = example_path.read_text(encoding="utf-8")
    example_vars = set(parse_dotenv(content).keys())
    vault_vars = set(vault.list_vars(environment))

    return {
        "missing": sorted(vault_vars - example_vars),
        "extra": sorted(example_vars - vault_vars),
    }
