"""Secure display utilities for envault.

Mask sensitive values when displaying, format vault contents
for terminal output.
"""

from __future__ import annotations

from typing import Any, Optional


class MaskStyle:
    """Masking styles for secret values."""

    STARS = "stars"         # ****
    PARTIAL = "partial"     # se****rd
    DOTS = "dots"           # ........
    REDACTED = "redacted"   # [REDACTED]
    LENGTH = "length"       # [12 chars]


def mask_value(
    value: str,
    style: str = MaskStyle.PARTIAL,
    visible: int = 2,
) -> str:
    """Mask a sensitive value for display.

    Args:
        value: The value to mask.
        style: Masking style (see MaskStyle).
        visible: Number of visible characters for partial style.

    Returns:
        Masked string.
    """
    if not value:
        return "(empty)"

    if style == MaskStyle.STARS:
        return "*" * min(len(value), 16)

    if style == MaskStyle.PARTIAL:
        if len(value) <= visible * 2 + 2:
            return "*" * len(value)
        return value[:visible] + "*" * (len(value) - visible * 2) + value[-visible:]

    if style == MaskStyle.DOTS:
        return "." * min(len(value), 16)

    if style == MaskStyle.REDACTED:
        return "[REDACTED]"

    if style == MaskStyle.LENGTH:
        return f"[{len(value)} chars]"

    return "*" * len(value)


def format_variable_table(
    variables: dict[str, str],
    show_values: bool = False,
    mask_style: str = MaskStyle.PARTIAL,
) -> list[dict[str, str]]:
    """Format variables as a table-ready list.

    Args:
        variables: Dictionary of name -> value.
        show_values: Whether to show actual values.
        mask_style: How to mask values when not showing.

    Returns:
        List of row dicts with 'name' and 'value' keys.
    """
    rows = []
    for name in sorted(variables):
        value = variables[name]
        display = value if show_values else mask_value(value, mask_style)
        rows.append({"name": name, "value": display})
    return rows


def format_stats(stats: dict[str, Any]) -> str:
    """Format vault statistics for display.

    Args:
        stats: Stats dictionary from Vault.stats().

    Returns:
        Formatted string.
    """
    lines = [
        f"Environments: {stats.get('environments', 0)}",
        f"Total variables: {stats.get('total_variables', 0)}",
    ]

    env_details = stats.get("environment_details", {})
    if env_details:
        lines.append("Breakdown:")
        for env_name in sorted(env_details):
            count = env_details[env_name]
            lines.append(f"  {env_name}: {count} variable(s)")

    return "\n".join(lines)


def truncate_value(value: str, max_length: int = 50) -> str:
    """Truncate a value for display.

    Args:
        value: The value to truncate.
        max_length: Maximum display length.

    Returns:
        Truncated string.
    """
    if len(value) <= max_length:
        return value
    return value[:max_length - 3] + "..."


def format_env_comparison(
    env_a_name: str,
    env_a_vars: dict[str, str],
    env_b_name: str,
    env_b_vars: dict[str, str],
    show_values: bool = False,
) -> str:
    """Format a side-by-side environment comparison.

    Args:
        env_a_name: First environment name.
        env_a_vars: First environment variables.
        env_b_name: Second environment name.
        env_b_vars: Second environment variables.
        show_values: Whether to show actual values.

    Returns:
        Formatted comparison string.
    """
    all_names = sorted(set(env_a_vars) | set(env_b_vars))
    lines = [f"{'Variable':<30} {env_a_name:<20} {env_b_name:<20}"]
    lines.append("-" * 70)

    for name in all_names:
        in_a = name in env_a_vars
        in_b = name in env_b_vars

        if in_a and in_b:
            val_a = env_a_vars[name] if show_values else mask_value(env_a_vars[name])
            val_b = env_b_vars[name] if show_values else mask_value(env_b_vars[name])
            marker = " " if env_a_vars[name] == env_b_vars[name] else "~"
        elif in_a:
            val_a = env_a_vars[name] if show_values else mask_value(env_a_vars[name])
            val_b = "(missing)"
            marker = "-"
        else:
            val_a = "(missing)"
            val_b = env_b_vars[name] if show_values else mask_value(env_b_vars[name])
            marker = "+"

        lines.append(f"{marker} {name:<28} {truncate_value(val_a, 20):<20} {truncate_value(val_b, 20):<20}")

    return "\n".join(lines)
