"""Cryptographic operations for envault.

Provides key derivation, encryption, and decryption using
AES-256-GCM with Argon2id key derivation.
"""

from __future__ import annotations

import base64
import json
import os
import secrets
from dataclasses import dataclass
from typing import Optional

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt


# Constants
SALT_SIZE = 32
NONCE_SIZE = 12
KEY_SIZE = 32  # 256-bit AES key
SCRYPT_N = 2**14
SCRYPT_R = 8
SCRYPT_P = 1


@dataclass(frozen=True)
class EncryptedPayload:
    """Represents an encrypted value with its metadata."""

    ciphertext: bytes
    nonce: bytes
    salt: bytes
    version: int = 1

    def to_dict(self) -> dict:
        """Serialize to dictionary."""
        return {
            "ct": base64.b64encode(self.ciphertext).decode(),
            "nonce": base64.b64encode(self.nonce).decode(),
            "salt": base64.b64encode(self.salt).decode(),
            "v": self.version,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "EncryptedPayload":
        """Deserialize from dictionary."""
        return cls(
            ciphertext=base64.b64decode(data["ct"]),
            nonce=base64.b64decode(data["nonce"]),
            salt=base64.b64decode(data["salt"]),
            version=data.get("v", 1),
        )

    def to_string(self) -> str:
        """Serialize to compact string format."""
        return json.dumps(self.to_dict(), separators=(",", ":"))

    @classmethod
    def from_string(cls, s: str) -> "EncryptedPayload":
        """Deserialize from compact string format."""
        return cls.from_dict(json.loads(s))


def derive_key(password: str, salt: Optional[bytes] = None) -> tuple[bytes, bytes]:
    """Derive an encryption key from a password using scrypt.

    Args:
        password: The password to derive the key from.
        salt: Optional salt. If not provided, a random one is generated.

    Returns:
        Tuple of (derived_key, salt).
    """
    if salt is None:
        salt = os.urandom(SALT_SIZE)

    kdf = Scrypt(
        salt=salt,
        length=KEY_SIZE,
        n=SCRYPT_N,
        r=SCRYPT_R,
        p=SCRYPT_P,
    )
    key = kdf.derive(password.encode("utf-8"))
    return key, salt


def encrypt(plaintext: str, password: str) -> EncryptedPayload:
    """Encrypt a plaintext string with a password.

    Uses AES-256-GCM with scrypt key derivation.

    Args:
        plaintext: The string to encrypt.
        password: The password for encryption.

    Returns:
        EncryptedPayload containing the ciphertext and metadata.
    """
    key, salt = derive_key(password)
    nonce = os.urandom(NONCE_SIZE)
    aesgcm = AESGCM(key)
    ciphertext = aesgcm.encrypt(nonce, plaintext.encode("utf-8"), None)

    return EncryptedPayload(
        ciphertext=ciphertext,
        nonce=nonce,
        salt=salt,
    )


def decrypt(payload: EncryptedPayload, password: str) -> str:
    """Decrypt an encrypted payload with a password.

    Args:
        payload: The encrypted payload to decrypt.
        password: The password used for encryption.

    Returns:
        The decrypted plaintext string.

    Raises:
        ValueError: If the password is incorrect or data is corrupted.
    """
    key, _ = derive_key(password, payload.salt)
    aesgcm = AESGCM(key)

    try:
        plaintext = aesgcm.decrypt(payload.nonce, payload.ciphertext, None)
        return plaintext.decode("utf-8")
    except Exception as e:
        raise ValueError("Decryption failed: incorrect password or corrupted data") from e


def generate_key() -> str:
    """Generate a random encryption key encoded as base64.

    Returns:
        A base64-encoded random key string.
    """
    return base64.b64encode(secrets.token_bytes(KEY_SIZE)).decode()


def encrypt_with_key(plaintext: str, key_b64: str) -> EncryptedPayload:
    """Encrypt using a raw base64 key (no password derivation).

    Args:
        plaintext: The string to encrypt.
        key_b64: Base64-encoded 256-bit key.

    Returns:
        EncryptedPayload with empty salt.
    """
    key = base64.b64decode(key_b64)
    if len(key) != KEY_SIZE:
        raise ValueError(f"Key must be {KEY_SIZE} bytes, got {len(key)}")

    nonce = os.urandom(NONCE_SIZE)
    aesgcm = AESGCM(key)
    ciphertext = aesgcm.encrypt(nonce, plaintext.encode("utf-8"), None)

    return EncryptedPayload(
        ciphertext=ciphertext,
        nonce=nonce,
        salt=b"",
    )


def decrypt_with_key(payload: EncryptedPayload, key_b64: str) -> str:
    """Decrypt using a raw base64 key.

    Args:
        payload: The encrypted payload.
        key_b64: Base64-encoded 256-bit key.

    Returns:
        The decrypted plaintext string.
    """
    key = base64.b64decode(key_b64)
    if len(key) != KEY_SIZE:
        raise ValueError(f"Key must be {KEY_SIZE} bytes, got {len(key)}")

    aesgcm = AESGCM(key)
    try:
        plaintext = aesgcm.decrypt(payload.nonce, payload.ciphertext, None)
        return plaintext.decode("utf-8")
    except Exception as e:
        raise ValueError("Decryption failed: incorrect key or corrupted data") from e
