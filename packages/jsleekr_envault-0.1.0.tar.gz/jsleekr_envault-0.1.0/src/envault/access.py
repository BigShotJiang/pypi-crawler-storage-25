"""Access control for envault.

Simple role-based access control for vault operations.
Defines roles (admin, editor, viewer) and checks permissions.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional


class Permission(str, Enum):
    """Available permissions."""

    READ = "read"
    WRITE = "write"
    DELETE = "delete"
    EXPORT = "export"
    IMPORT = "import"
    ADMIN = "admin"


class Role(str, Enum):
    """Predefined roles."""

    ADMIN = "admin"
    EDITOR = "editor"
    VIEWER = "viewer"


# Role -> permissions mapping
ROLE_PERMISSIONS: dict[Role, set[Permission]] = {
    Role.ADMIN: {p for p in Permission},
    Role.EDITOR: {Permission.READ, Permission.WRITE, Permission.DELETE, Permission.EXPORT, Permission.IMPORT},
    Role.VIEWER: {Permission.READ, Permission.EXPORT},
}


@dataclass
class AccessEntry:
    """An access control entry for a user/identity."""

    identity: str
    role: Role
    environments: Optional[list[str]] = None  # None means all
    variables: Optional[list[str]] = None  # None means all

    def to_dict(self) -> dict:
        return {
            "identity": self.identity,
            "role": self.role.value,
            "environments": self.environments,
            "variables": self.variables,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "AccessEntry":
        return cls(
            identity=data["identity"],
            role=Role(data["role"]),
            environments=data.get("environments"),
            variables=data.get("variables"),
        )


class AccessDeniedError(Exception):
    """Raised when access is denied."""

    def __init__(self, identity: str, permission: Permission, detail: str = ""):
        self.identity = identity
        self.permission = permission
        super().__init__(
            detail or f"Access denied for '{identity}': missing '{permission.value}' permission"
        )


class AccessControl:
    """Access control manager for vault operations."""

    def __init__(self):
        self._entries: dict[str, AccessEntry] = {}

    def add_entry(self, entry: AccessEntry) -> None:
        """Add or update an access entry."""
        self._entries[entry.identity] = entry

    def remove_entry(self, identity: str) -> bool:
        """Remove an access entry."""
        if identity in self._entries:
            del self._entries[identity]
            return True
        return False

    def get_entry(self, identity: str) -> Optional[AccessEntry]:
        """Get an access entry."""
        return self._entries.get(identity)

    def list_entries(self) -> list[AccessEntry]:
        """List all access entries."""
        return sorted(self._entries.values(), key=lambda e: e.identity)

    def has_permission(
        self,
        identity: str,
        permission: Permission,
        environment: Optional[str] = None,
        variable: Optional[str] = None,
    ) -> bool:
        """Check if an identity has a specific permission.

        Args:
            identity: User/identity name.
            permission: Required permission.
            environment: Optional environment context.
            variable: Optional variable context.

        Returns:
            True if permitted.
        """
        entry = self._entries.get(identity)
        if not entry:
            return False

        # Check role permissions
        role_perms = ROLE_PERMISSIONS.get(entry.role, set())
        if permission not in role_perms:
            return False

        # Check environment restriction
        if environment and entry.environments is not None:
            if environment not in entry.environments:
                return False

        # Check variable restriction
        if variable and entry.variables is not None:
            if variable not in entry.variables:
                return False

        return True

    def check_permission(
        self,
        identity: str,
        permission: Permission,
        environment: Optional[str] = None,
        variable: Optional[str] = None,
    ) -> None:
        """Check permission, raising AccessDeniedError if denied.

        Args:
            identity: User/identity name.
            permission: Required permission.
            environment: Optional environment context.
            variable: Optional variable context.

        Raises:
            AccessDeniedError: If permission is denied.
        """
        if not self.has_permission(identity, permission, environment, variable):
            raise AccessDeniedError(identity, permission)

    def get_allowed_environments(self, identity: str) -> Optional[list[str]]:
        """Get environments an identity can access.

        Returns None if all environments are allowed.
        """
        entry = self._entries.get(identity)
        if not entry:
            return []
        return entry.environments

    def get_role(self, identity: str) -> Optional[Role]:
        """Get the role for an identity."""
        entry = self._entries.get(identity)
        return entry.role if entry else None

    def to_list(self) -> list[dict]:
        """Serialize to list of dicts."""
        return [e.to_dict() for e in self._entries.values()]

    @classmethod
    def from_list(cls, data: list[dict]) -> "AccessControl":
        """Deserialize from list of dicts."""
        ac = cls()
        for d in data:
            ac.add_entry(AccessEntry.from_dict(d))
        return ac

    def __len__(self) -> int:
        return len(self._entries)
