"""envault - Encrypted environment variable management for teams and projects."""

__version__ = "0.1.0"
