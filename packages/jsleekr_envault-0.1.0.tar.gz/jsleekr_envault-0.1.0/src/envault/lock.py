"""File locking mechanism for envault.

Prevent concurrent vault modifications using file-based locks.
"""

from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional


LOCK_SUFFIX = ".lock"
DEFAULT_TIMEOUT = 30.0  # seconds
STALE_TIMEOUT = 300.0  # 5 minutes


@dataclass
class LockInfo:
    """Information about a vault lock."""

    holder: str
    pid: int
    timestamp: float
    hostname: str = ""

    def to_dict(self) -> dict:
        return {
            "holder": self.holder,
            "pid": self.pid,
            "timestamp": self.timestamp,
            "hostname": self.hostname,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "LockInfo":
        return cls(
            holder=data.get("holder", "unknown"),
            pid=data.get("pid", 0),
            timestamp=data.get("timestamp", 0),
            hostname=data.get("hostname", ""),
        )

    @property
    def age(self) -> float:
        """Age of the lock in seconds."""
        return time.time() - self.timestamp

    @property
    def is_stale(self) -> bool:
        """Check if the lock is stale (older than stale timeout)."""
        return self.age > STALE_TIMEOUT


class LockError(Exception):
    """Raised when a lock cannot be acquired."""

    def __init__(self, lock_info: Optional[LockInfo] = None, message: str = ""):
        self.lock_info = lock_info
        msg = message or "Vault is locked"
        if lock_info:
            msg += f" by {lock_info.holder} (pid {lock_info.pid})"
        super().__init__(msg)


class VaultLock:
    """File-based lock for vault operations."""

    def __init__(
        self,
        vault_path: Path,
        holder: str = "",
        timeout: float = DEFAULT_TIMEOUT,
    ):
        """Initialize vault lock.

        Args:
            vault_path: Path to the vault file.
            holder: Identity of the lock holder.
            timeout: Max seconds to wait for lock.
        """
        self.vault_path = vault_path
        self.lock_path = vault_path.with_suffix(vault_path.suffix + LOCK_SUFFIX)
        self.holder = holder or f"user-{os.getpid()}"
        self.timeout = timeout
        self._locked = False

    def acquire(self) -> bool:
        """Acquire the lock.

        Returns:
            True if the lock was acquired.

        Raises:
            LockError: If the lock cannot be acquired within timeout.
        """
        start = time.time()

        while True:
            try:
                # Check for existing lock
                if self.lock_path.exists():
                    existing = self._read_lock()
                    if existing and existing.is_stale:
                        # Remove stale lock
                        self._remove_lock()
                    elif existing:
                        if time.time() - start > self.timeout:
                            raise LockError(existing, "Timeout waiting for lock")
                        time.sleep(0.1)
                        continue

                # Create lock file
                self._write_lock()
                self._locked = True
                return True

            except LockError:
                raise
            except OSError:
                if time.time() - start > self.timeout:
                    raise LockError(message="Timeout: could not create lock file")
                time.sleep(0.1)

    def release(self) -> bool:
        """Release the lock.

        Returns:
            True if the lock was released.
        """
        if self._locked:
            self._remove_lock()
            self._locked = False
            return True
        return False

    def is_locked(self) -> bool:
        """Check if the vault is currently locked."""
        if not self.lock_path.exists():
            return False
        info = self._read_lock()
        if info and info.is_stale:
            return False
        return info is not None

    def get_lock_info(self) -> Optional[LockInfo]:
        """Get info about the current lock."""
        if not self.lock_path.exists():
            return None
        return self._read_lock()

    def force_release(self) -> bool:
        """Force release a lock (even if not the holder).

        Returns:
            True if a lock was removed.
        """
        if self.lock_path.exists():
            self._remove_lock()
            self._locked = False
            return True
        return False

    def _write_lock(self) -> None:
        """Write the lock file atomically using exclusive create."""
        import socket
        info = LockInfo(
            holder=self.holder,
            pid=os.getpid(),
            timestamp=time.time(),
            hostname=socket.gethostname(),
        )
        try:
            # O_CREAT | O_EXCL ensures atomic create-if-not-exists
            fd = os.open(str(self.lock_path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            try:
                os.write(fd, json.dumps(info.to_dict()).encode("utf-8"))
            finally:
                os.close(fd)
        except FileExistsError:
            raise OSError("Lock file already exists")

    def _read_lock(self) -> Optional[LockInfo]:
        """Read the lock file."""
        try:
            content = self.lock_path.read_text(encoding="utf-8")
            return LockInfo.from_dict(json.loads(content))
        except (json.JSONDecodeError, OSError):
            return None

    def _remove_lock(self) -> None:
        """Remove the lock file."""
        try:
            self.lock_path.unlink(missing_ok=True)
        except OSError:
            pass

    def __enter__(self) -> "VaultLock":
        self.acquire()
        return self

    def __exit__(self, *args) -> None:
        self.release()

    def __del__(self) -> None:
        if self._locked:
            self.release()
