"""Variable validation rules for envault.

Define and enforce rules on variable values -- required format,
min/max length, patterns, allowed values, etc.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Optional


class RuleType(str, Enum):
    """Types of validation rules."""

    REQUIRED = "required"
    PATTERN = "pattern"
    MIN_LENGTH = "min_length"
    MAX_LENGTH = "max_length"
    ONE_OF = "one_of"
    NOT_EMPTY = "not_empty"
    URL = "url"
    EMAIL = "email"
    PORT = "port"
    CUSTOM = "custom"


@dataclass
class ValidationRule:
    """A single validation rule for a variable."""

    rule_type: RuleType
    params: dict[str, Any] = field(default_factory=dict)
    message: str = ""

    def to_dict(self) -> dict:
        return {
            "rule_type": self.rule_type.value,
            "params": self.params,
            "message": self.message,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "ValidationRule":
        return cls(
            rule_type=RuleType(data["rule_type"]),
            params=data.get("params", {}),
            message=data.get("message", ""),
        )


@dataclass
class ValidationError:
    """A validation failure."""

    variable: str
    rule: ValidationRule
    message: str


@dataclass
class ValidationResult:
    """Result of validating variables."""

    errors: list[ValidationError] = field(default_factory=list)

    @property
    def is_valid(self) -> bool:
        return len(self.errors) == 0

    @property
    def error_count(self) -> int:
        return len(self.errors)

    def messages(self) -> list[str]:
        return [f"{e.variable}: {e.message}" for e in self.errors]


# Built-in validators
URL_PATTERN = re.compile(
    r"^https?://[^\s/$.?#].[^\s]*$", re.IGNORECASE
)
EMAIL_PATTERN = re.compile(
    r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
)


def _validate_required(value: Optional[str], params: dict) -> Optional[str]:
    if value is None:
        return "Variable is required but not set"
    return None


def _validate_not_empty(value: Optional[str], params: dict) -> Optional[str]:
    if value is not None and not value.strip():
        return "Variable must not be empty"
    return None


def _validate_pattern(value: Optional[str], params: dict) -> Optional[str]:
    if value is None:
        return None
    pattern = params.get("pattern", "")
    if not re.match(pattern, value):
        return f"Value does not match pattern: {pattern}"
    return None


def _validate_min_length(value: Optional[str], params: dict) -> Optional[str]:
    if value is None:
        return None
    min_len = params.get("min", 0)
    if len(value) < min_len:
        return f"Value must be at least {min_len} characters (got {len(value)})"
    return None


def _validate_max_length(value: Optional[str], params: dict) -> Optional[str]:
    if value is None:
        return None
    max_len = params.get("max", float("inf"))
    if len(value) > max_len:
        return f"Value must be at most {max_len} characters (got {len(value)})"
    return None


def _validate_one_of(value: Optional[str], params: dict) -> Optional[str]:
    if value is None:
        return None
    allowed = params.get("values", [])
    if value not in allowed:
        return f"Value must be one of: {', '.join(allowed)}"
    return None


def _validate_url(value: Optional[str], params: dict) -> Optional[str]:
    if value is None:
        return None
    if not URL_PATTERN.match(value):
        return "Value must be a valid URL"
    return None


def _validate_email(value: Optional[str], params: dict) -> Optional[str]:
    if value is None:
        return None
    if not EMAIL_PATTERN.match(value):
        return "Value must be a valid email address"
    return None


def _validate_port(value: Optional[str], params: dict) -> Optional[str]:
    if value is None:
        return None
    try:
        port = int(value)
        if not (1 <= port <= 65535):
            return "Port must be between 1 and 65535"
    except ValueError:
        return "Port must be a valid integer"
    return None


VALIDATORS: dict[RuleType, Callable] = {
    RuleType.REQUIRED: _validate_required,
    RuleType.NOT_EMPTY: _validate_not_empty,
    RuleType.PATTERN: _validate_pattern,
    RuleType.MIN_LENGTH: _validate_min_length,
    RuleType.MAX_LENGTH: _validate_max_length,
    RuleType.ONE_OF: _validate_one_of,
    RuleType.URL: _validate_url,
    RuleType.EMAIL: _validate_email,
    RuleType.PORT: _validate_port,
}


class VariableSchema:
    """Schema defining validation rules for variables."""

    def __init__(self):
        self._rules: dict[str, list[ValidationRule]] = {}

    def add_rule(self, variable: str, rule: ValidationRule) -> None:
        """Add a validation rule for a variable."""
        self._rules.setdefault(variable, []).append(rule)

    def require(self, variable: str, message: str = "") -> "VariableSchema":
        """Mark a variable as required."""
        self.add_rule(variable, ValidationRule(RuleType.REQUIRED, message=message))
        return self

    def not_empty(self, variable: str, message: str = "") -> "VariableSchema":
        """Require a variable to be non-empty."""
        self.add_rule(variable, ValidationRule(RuleType.NOT_EMPTY, message=message))
        return self

    def pattern(self, variable: str, regex: str, message: str = "") -> "VariableSchema":
        """Require a variable to match a regex pattern."""
        self.add_rule(variable, ValidationRule(RuleType.PATTERN, {"pattern": regex}, message))
        return self

    def min_length(self, variable: str, length: int, message: str = "") -> "VariableSchema":
        """Set minimum length for a variable."""
        self.add_rule(variable, ValidationRule(RuleType.MIN_LENGTH, {"min": length}, message))
        return self

    def max_length(self, variable: str, length: int, message: str = "") -> "VariableSchema":
        """Set maximum length for a variable."""
        self.add_rule(variable, ValidationRule(RuleType.MAX_LENGTH, {"max": length}, message))
        return self

    def one_of(self, variable: str, values: list[str], message: str = "") -> "VariableSchema":
        """Restrict a variable to a set of allowed values."""
        self.add_rule(variable, ValidationRule(RuleType.ONE_OF, {"values": values}, message))
        return self

    def url(self, variable: str, message: str = "") -> "VariableSchema":
        """Require a variable to be a valid URL."""
        self.add_rule(variable, ValidationRule(RuleType.URL, message=message))
        return self

    def email(self, variable: str, message: str = "") -> "VariableSchema":
        """Require a variable to be a valid email."""
        self.add_rule(variable, ValidationRule(RuleType.EMAIL, message=message))
        return self

    def port(self, variable: str, message: str = "") -> "VariableSchema":
        """Require a variable to be a valid port number."""
        self.add_rule(variable, ValidationRule(RuleType.PORT, message=message))
        return self

    def get_rules(self, variable: str) -> list[ValidationRule]:
        """Get all rules for a variable."""
        return self._rules.get(variable, [])

    def variables(self) -> list[str]:
        """List all variables with rules."""
        return sorted(self._rules.keys())

    def validate(self, variables: dict[str, str]) -> ValidationResult:
        """Validate variables against the schema.

        Args:
            variables: Dictionary of name -> value.

        Returns:
            ValidationResult with any errors.
        """
        result = ValidationResult()

        for var_name, rules in self._rules.items():
            value = variables.get(var_name)

            for rule in rules:
                validator = VALIDATORS.get(rule.rule_type)
                if validator is None:
                    continue

                error_msg = validator(value, rule.params)
                if error_msg:
                    msg = rule.message or error_msg
                    result.errors.append(ValidationError(var_name, rule, msg))

        return result

    def to_dict(self) -> dict:
        """Serialize schema to dictionary."""
        return {
            var: [r.to_dict() for r in rules]
            for var, rules in self._rules.items()
        }

    @classmethod
    def from_dict(cls, data: dict) -> "VariableSchema":
        """Deserialize schema from dictionary."""
        schema = cls()
        for var, rules in data.items():
            for rule_data in rules:
                schema.add_rule(var, ValidationRule.from_dict(rule_data))
        return schema
