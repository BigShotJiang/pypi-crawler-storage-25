"""Diff and comparison utilities for envault.

Compare variables between environments, detect changes,
and generate diff reports.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from envault.vault import Vault


class ChangeType(str, Enum):
    """Type of change between environments."""

    ADDED = "added"
    REMOVED = "removed"
    MODIFIED = "modified"
    UNCHANGED = "unchanged"


@dataclass
class VarChange:
    """Represents a single variable change."""

    name: str
    change_type: ChangeType
    old_value: Optional[str] = None
    new_value: Optional[str] = None

    @property
    def is_changed(self) -> bool:
        return self.change_type != ChangeType.UNCHANGED


@dataclass
class DiffResult:
    """Result of a diff between two environments."""

    source_env: str
    target_env: str
    changes: list[VarChange] = field(default_factory=list)

    @property
    def added(self) -> list[VarChange]:
        return [c for c in self.changes if c.change_type == ChangeType.ADDED]

    @property
    def removed(self) -> list[VarChange]:
        return [c for c in self.changes if c.change_type == ChangeType.REMOVED]

    @property
    def modified(self) -> list[VarChange]:
        return [c for c in self.changes if c.change_type == ChangeType.MODIFIED]

    @property
    def unchanged(self) -> list[VarChange]:
        return [c for c in self.changes if c.change_type == ChangeType.UNCHANGED]

    @property
    def has_changes(self) -> bool:
        return any(c.is_changed for c in self.changes)

    @property
    def summary(self) -> dict[str, int]:
        return {
            "added": len(self.added),
            "removed": len(self.removed),
            "modified": len(self.modified),
            "unchanged": len(self.unchanged),
            "total": len(self.changes),
        }

    def to_text(self, show_values: bool = False, mask: bool = True) -> str:
        """Generate a text diff report.

        Args:
            show_values: Whether to show actual values.
            mask: Mask values (show only first/last 2 chars).

        Returns:
            Formatted diff text.
        """
        lines = [
            f"Diff: {self.source_env} → {self.target_env}",
            f"  {len(self.added)} added, {len(self.removed)} removed, "
            f"{len(self.modified)} modified, {len(self.unchanged)} unchanged",
            "",
        ]

        for change in sorted(self.changes, key=lambda c: c.name):
            prefix = {
                ChangeType.ADDED: "+",
                ChangeType.REMOVED: "-",
                ChangeType.MODIFIED: "~",
                ChangeType.UNCHANGED: " ",
            }[change.change_type]

            line = f"  {prefix} {change.name}"

            if show_values and change.is_changed:
                if mask:
                    old_display = _mask_value(change.old_value) if change.old_value else "(none)"
                    new_display = _mask_value(change.new_value) if change.new_value else "(none)"
                else:
                    old_display = change.old_value or "(none)"
                    new_display = change.new_value or "(none)"

                if change.change_type == ChangeType.MODIFIED:
                    line += f": {old_display} → {new_display}"
                elif change.change_type == ChangeType.ADDED:
                    line += f": {new_display}"
                elif change.change_type == ChangeType.REMOVED:
                    line += f": {old_display}"

            lines.append(line)

        return "\n".join(lines)


def _mask_value(value: str, visible: int = 2) -> str:
    """Mask a value, showing only first and last N characters.

    Args:
        value: Value to mask.
        visible: Number of visible chars at each end.

    Returns:
        Masked value string.
    """
    if len(value) <= visible * 2 + 2:
        return "*" * len(value)
    return value[:visible] + "*" * (len(value) - visible * 2) + value[-visible:]


def diff_environments(
    vault: Vault,
    source_env: str,
    target_env: str,
) -> DiffResult:
    """Compare variables between two environments.

    Args:
        vault: The vault containing both environments.
        source_env: Source environment name.
        target_env: Target environment name.

    Returns:
        DiffResult with all changes.
    """
    source_vars = vault.get_all(source_env)
    target_vars = vault.get_all(target_env)

    all_names = sorted(set(source_vars.keys()) | set(target_vars.keys()))
    changes = []

    for name in all_names:
        in_source = name in source_vars
        in_target = name in target_vars

        if in_source and in_target:
            if source_vars[name] == target_vars[name]:
                changes.append(VarChange(
                    name=name,
                    change_type=ChangeType.UNCHANGED,
                    old_value=source_vars[name],
                    new_value=target_vars[name],
                ))
            else:
                changes.append(VarChange(
                    name=name,
                    change_type=ChangeType.MODIFIED,
                    old_value=source_vars[name],
                    new_value=target_vars[name],
                ))
        elif in_source:
            changes.append(VarChange(
                name=name,
                change_type=ChangeType.REMOVED,
                old_value=source_vars[name],
            ))
        else:
            changes.append(VarChange(
                name=name,
                change_type=ChangeType.ADDED,
                new_value=target_vars[name],
            ))

    return DiffResult(
        source_env=source_env,
        target_env=target_env,
        changes=changes,
    )


def find_missing_vars(
    vault: Vault,
    reference_env: str,
    target_env: str,
) -> list[str]:
    """Find variables in reference but missing from target.

    Args:
        vault: The vault.
        reference_env: Reference environment.
        target_env: Target environment to check.

    Returns:
        List of missing variable names.
    """
    ref_vars = set(vault.list_vars(reference_env))
    target_vars = set(vault.list_vars(target_env))
    return sorted(ref_vars - target_vars)


def find_extra_vars(
    vault: Vault,
    reference_env: str,
    target_env: str,
) -> list[str]:
    """Find variables in target but not in reference.

    Args:
        vault: The vault.
        reference_env: Reference environment.
        target_env: Target environment.

    Returns:
        List of extra variable names.
    """
    ref_vars = set(vault.list_vars(reference_env))
    target_vars = set(vault.list_vars(target_env))
    return sorted(target_vars - ref_vars)
