"""Environment inheritance for envault.

Support layered environments where child environments
inherit variables from parent environments with overrides.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional

from envault.vault import Vault


@dataclass
class InheritanceConfig:
    """Configuration for environment inheritance."""

    # Map of child -> parent environment
    parents: dict[str, str] = field(default_factory=dict)

    def set_parent(self, child: str, parent: str) -> None:
        """Set the parent of an environment."""
        if child == parent:
            raise ValueError(f"Environment cannot inherit from itself: {child}")
        # Check for circular inheritance
        # Follow the chain from parent; if we reach child, it's circular
        current = parent
        visited = set()
        while current is not None:
            if current == child:
                raise ValueError(
                    f"Circular inheritance detected: {child} -> ... -> {current}"
                )
            if current in visited:
                break
            visited.add(current)
            current = self.parents.get(current)
        self.parents[child] = parent

    def get_parent(self, env: str) -> Optional[str]:
        """Get the parent of an environment."""
        return self.parents.get(env)

    def get_chain(self, env: str) -> list[str]:
        """Get the full inheritance chain for an environment.

        Returns environments from most specific to most general.
        Detects cycles to prevent infinite loops from corrupted configs.
        """
        chain = [env]
        visited: set[str] = {env}
        current = env
        while current in self.parents:
            parent = self.parents[current]
            if parent in visited:
                break
            chain.append(parent)
            visited.add(parent)
            current = parent
        return chain

    def remove_parent(self, child: str) -> bool:
        """Remove inheritance for an environment."""
        if child in self.parents:
            del self.parents[child]
            return True
        return False

    def to_dict(self) -> dict:
        return {"parents": dict(self.parents)}

    @classmethod
    def from_dict(cls, data: dict) -> "InheritanceConfig":
        return cls(parents=data.get("parents", {}))


def resolve_variables(
    vault: Vault,
    environment: str,
    config: InheritanceConfig,
) -> dict[str, str]:
    """Resolve variables for an environment including inherited values.

    Variables in child environments override parent values.

    Args:
        vault: The vault.
        environment: Target environment.
        config: Inheritance configuration.

    Returns:
        Merged dictionary with all resolved variables.
    """
    chain = config.get_chain(environment)

    # Start from the most general (last in chain), override with more specific
    result: dict[str, str] = {}
    for env in reversed(chain):
        env_vars = vault.get_all(env)
        result.update(env_vars)

    return result


def find_overrides(
    vault: Vault,
    environment: str,
    config: InheritanceConfig,
) -> dict[str, str]:
    """Find which variables in the environment override parent values.

    Args:
        vault: The vault.
        environment: Child environment.
        config: Inheritance configuration.

    Returns:
        Dictionary of overridden variable names -> parent environment.
    """
    parent = config.get_parent(environment)
    if not parent:
        return {}

    child_vars = set(vault.list_vars(environment))
    overrides: dict[str, str] = {}

    chain = config.get_chain(environment)[1:]  # Skip self
    for ancestor in chain:
        ancestor_vars = set(vault.list_vars(ancestor))
        for var in child_vars & ancestor_vars:
            if var not in overrides:
                overrides[var] = ancestor

    return overrides


def find_inherited(
    vault: Vault,
    environment: str,
    config: InheritanceConfig,
) -> dict[str, str]:
    """Find variables inherited (not overridden) from parents.

    Args:
        vault: The vault.
        environment: Child environment.
        config: Inheritance configuration.

    Returns:
        Dictionary of inherited variable names -> source environment.
    """
    child_vars = set(vault.list_vars(environment))
    inherited: dict[str, str] = {}

    chain = config.get_chain(environment)[1:]  # Skip self
    for ancestor in chain:
        ancestor_vars = set(vault.list_vars(ancestor))
        for var in ancestor_vars:
            if var not in child_vars and var not in inherited:
                inherited[var] = ancestor

    return inherited
