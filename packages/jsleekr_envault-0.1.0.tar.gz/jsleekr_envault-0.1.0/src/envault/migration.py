"""Vault file migration and version upgrade support.

Handle schema upgrades between vault file versions.
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Optional


CURRENT_VERSION = 2


@dataclass
class MigrationStep:
    """A single migration step between versions."""

    from_version: int
    to_version: int
    description: str
    migrator: Callable[[dict], dict]


@dataclass
class MigrationResult:
    """Result of a migration operation."""

    from_version: int
    to_version: int
    steps_applied: int
    success: bool
    errors: list[str] = field(default_factory=list)

    @property
    def summary(self) -> str:
        if self.success:
            return f"Migrated from v{self.from_version} to v{self.to_version} ({self.steps_applied} steps)"
        return f"Migration failed: {'; '.join(self.errors)}"


def _migrate_v1_to_v2(data: dict) -> dict:
    """Migrate from v1 to v2 format.

    v2 adds:
    - metadata.migrated_at timestamp
    - metadata.migration_history list
    """
    metadata = data.get("metadata", {})
    metadata["version"] = 2
    metadata["migrated_at"] = time.time()
    metadata.setdefault("migration_history", []).append({
        "from": 1,
        "to": 2,
        "timestamp": time.time(),
    })
    data["metadata"] = metadata
    return data


# Registry of migration steps
MIGRATIONS: list[MigrationStep] = [
    MigrationStep(
        from_version=1,
        to_version=2,
        description="Add migration tracking metadata",
        migrator=_migrate_v1_to_v2,
    ),
]


def get_vault_version(data: dict) -> int:
    """Get the version of a vault data dict.

    Args:
        data: Parsed vault JSON.

    Returns:
        Version number (defaults to 1).
    """
    return data.get("metadata", {}).get("version", 1)


def needs_migration(data: dict) -> bool:
    """Check if a vault needs migration.

    Args:
        data: Parsed vault JSON.

    Returns:
        True if the vault version is below current.
    """
    return get_vault_version(data) < CURRENT_VERSION


def get_migration_path(from_version: int, to_version: int) -> list[MigrationStep]:
    """Get the sequence of migration steps needed.

    Args:
        from_version: Current version.
        to_version: Target version.

    Returns:
        Ordered list of migration steps.
    """
    steps = []
    current = from_version
    while current < to_version:
        step = next(
            (m for m in MIGRATIONS if m.from_version == current),
            None,
        )
        if step is None:
            break
        steps.append(step)
        current = step.to_version
    return steps


def migrate(data: dict, target_version: Optional[int] = None) -> tuple[dict, MigrationResult]:
    """Migrate vault data to the target version.

    Args:
        data: Parsed vault JSON.
        target_version: Target version (defaults to CURRENT_VERSION).

    Returns:
        Tuple of (migrated data, migration result).
    """
    target = target_version or CURRENT_VERSION
    current = get_vault_version(data)

    if current >= target:
        return data, MigrationResult(
            from_version=current,
            to_version=current,
            steps_applied=0,
            success=True,
        )

    steps = get_migration_path(current, target)
    if not steps:
        return data, MigrationResult(
            from_version=current,
            to_version=current,
            steps_applied=0,
            success=False,
            errors=[f"No migration path from v{current} to v{target}"],
        )

    result_data = dict(data)
    errors = []
    applied = 0

    for step in steps:
        try:
            result_data = step.migrator(result_data)
            applied += 1
        except Exception as e:
            errors.append(f"Step v{step.from_version}->v{step.to_version}: {e}")
            return result_data, MigrationResult(
                from_version=current,
                to_version=get_vault_version(result_data),
                steps_applied=applied,
                success=False,
                errors=errors,
            )

    return result_data, MigrationResult(
        from_version=current,
        to_version=get_vault_version(result_data),
        steps_applied=applied,
        success=True,
    )


def migrate_file(
    vault_path: Path,
    target_version: Optional[int] = None,
    backup: bool = True,
) -> MigrationResult:
    """Migrate a vault file in place.

    Args:
        vault_path: Path to vault file.
        target_version: Target version.
        backup: Whether to create backup before migration.

    Returns:
        MigrationResult.
    """
    if not vault_path.exists():
        return MigrationResult(0, 0, 0, False, ["Vault file not found"])

    data = json.loads(vault_path.read_text(encoding="utf-8"))

    if backup:
        from envault.backup import create_backup
        create_backup(vault_path, label="pre_migration")

    migrated, result = migrate(data, target_version)

    if result.success and result.steps_applied > 0:
        vault_path.write_text(json.dumps(migrated, indent=2), encoding="utf-8")

    return result
