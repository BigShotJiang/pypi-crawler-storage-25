"""CLI output formatting modules."""
