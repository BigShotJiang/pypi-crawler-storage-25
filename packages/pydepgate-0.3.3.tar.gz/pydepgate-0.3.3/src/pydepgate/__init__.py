"""
pydepgate.__init__
"""