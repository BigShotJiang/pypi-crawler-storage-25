# CHANGELOG

<!-- version list -->

## v1.0.0 (2026-05-07)

- Initial Release
