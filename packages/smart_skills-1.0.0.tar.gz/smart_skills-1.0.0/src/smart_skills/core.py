import os
import re
from collections import Counter
from pathlib import Path

# Automatically locate the internal "data" folder packaged with the library
PACKAGE_DIR = Path(__file__).parent
DATA_DIR = PACKAGE_DIR / "data"

class Skill:
    def __init__(self, filepath, name, description, content):
        self.filepath = filepath
        self.name = name
        self.description = description
        self.content = content
        self.keywords = set(re.findall(r'\b\w+\b', (name + " " + description).lower()))

class SkillManager:
    def __init__(self):
        self.skills = []
        if not DATA_DIR.exists():
            print(f"Warning: Internal skills data directory not found at {DATA_DIR}")
        else:
            self.load_all_skills()

    def load_all_skills(self):
        """Recursively loads all markdown skills packaged inside the library."""
        for root, _, files in os.walk(DATA_DIR):
            for file in files:
                if file.endswith((".md", ".txt")):
                    filepath = os.path.join(root, file)
                    self._parse_skill_file(filepath)

    def _parse_skill_file(self, filepath):
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read()

            name = os.path.basename(filepath).replace('.md', '')
            description = ""

            # Try to parse YAML frontmatter
            frontmatter_match = re.match(r'^---\s*(.*?)\s*---', content, re.DOTALL)
            if frontmatter_match:
                fm_text = frontmatter_match.group(1)
                name_match = re.search(r'name:\s*(.+)', fm_text)
                if name_match: name = name_match.group(1).strip().strip('"\'')
                
                desc_match = re.search(r'description:\s*(.+)', fm_text)
                if desc_match: description = desc_match.group(1).strip().strip('"\'')

            self.skills.append(Skill(filepath, name, description, content))
        except Exception as e:
            pass # Silently skip unreadable files

    def useSkills(self, user_prompt, top_k=2):
        """Selects the best skills and returns the formatted system prompt payload."""
        if not self.skills:
            return ""

        prompt_words = re.findall(r'\b\w+\b', user_prompt.lower())
        prompt_counter = Counter(prompt_words)

        scored_skills = []
        for skill in self.skills:
            score = sum(prompt_counter[word] for word in skill.keywords if word in prompt_counter)
            if skill.name.lower() in user_prompt.lower():
                score += 5 
                
            if score > 0:
                scored_skills.append((score, skill))

        scored_skills.sort(key=lambda x: x[0], reverse=True)
        selected_skills = [skill for score, skill in scored_skills[:top_k]]

        if not selected_skills:
            return "" 

        payload = "\n\n### RELEVANT AI SKILLS ###\n"
        payload += "The user's query triggered the following specific skills/guidelines. Follow them strictly:\n\n"
        
        for skill in selected_skills:
            payload += f"==== SKILL: {skill.name} ====\n"
            payload += skill.content + "\n\n"
            
        return payload

# Global helper function 
_default_manager = None

def useSkills(prompt, max_skills=2):
    global _default_manager
    if _default_manager is None:
        _default_manager = SkillManager()
    return _default_manager.useSkills(prompt, top_k=max_skills)