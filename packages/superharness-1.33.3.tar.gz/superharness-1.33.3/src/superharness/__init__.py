"""superharness — multi-agent session handoff framework."""

__version__ = "1.33.3"
