# gogkeep

`gogkeep` is a Google Keep CLI matching the [gogcli](https://github.com/steipete/gogcli) interface. It enables access for personal Gmail accounts, bypassing the "Workspace-only" restriction of the official Keep API.

## Installation

### From PyPI
```bash
pip install gogkeep
```

### Via pipx
```bash
pipx install gogkeep
```

## Authentication

`gogkeep` automates Master Token extraction using the Chrome DevTools Protocol (CDP), removing the need for manual cookie surfing.

### Login

```bash
gogkeep login
```
This automatically launches an isolated browser. Log in, and `gogkeep` will capture the token. Press `Ctrl+C` at any time to skip to manual cookie extraction.

> [!NOTE]
> This approach is based on the [alternative flow for gpsoauth](https://gist.github.com/julianpitt/94774e74d36a46f9ec10ddce13cfd423) by julianpitt.

## Usage

### Root Flags
- `-a, --account EMAIL`: Set the account email (also can be set via `GOG_ACCOUNT` env var).
- `-j, --json`: Output as JSON.
- `-p, --plain`: Output as tab-separated values.
- `-n, --dry-run`: Do not make changes.

### Commands

#### List Notes
```bash
gogkeep list
```

#### Get Note
```bash
gogkeep get <note_id>
```

#### Search Notes
```bash
gogkeep search "query text"
```

#### Create Note
```bash
gogkeep create --title "My Title" --text "My body text"
```

#### Delete Note
```bash
gogkeep delete <note_id>
```

#### Download Attachment
```bash
gogkeep attachment <attachment_name> --out local_filename.jpg
```
Attachment names follow the format `notes/<note_id>/attachments/<attachment_id>`.

## Keyring Storage

`gogkeep` securely stores your Master Token using the system keyring:
- **macOS**: Keychain
- **Linux**: Secret Service (D-Bus)
- **Fallback**: Encrypted file in `~/.config/gogkeep/`

You can force specific behavior using environment variables:
- `GOGKEEP_ACCOUNT`: Default account email.
- `GOGKEEP_KEYRING_BACKEND`: `auto`, `keychain`, `file`, or `secret-service`.
- `GOGKEEP_KEYRING_PATH`: Custom path for the encrypted file backend.
- `GOGKEEP_KEYRING_PASSWORD`: Password for the encrypted file (if not in a TTY).
