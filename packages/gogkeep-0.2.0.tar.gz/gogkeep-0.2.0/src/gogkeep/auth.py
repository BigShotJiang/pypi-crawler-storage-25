import click
import gpsoauth

from .store import get_token, set_default_account, set_token


def get_master_token(email: str):
    try:
        return get_token("default", email)
    except KeyError:
        return None


def save_master_token(email: str, token: str):
    set_token("default", email, token)
    set_default_account(email, "default")


def login_flow(email: str | None = None):
    from .cdp_auth import find_chrome, get_auth_info_via_browser

    click.echo("--- Google Keep Authentication (Master Token Auth workflow) ---")

    oauth_token = None
    discovered_email = None
    chrome_path = find_chrome()

    if chrome_path:
        click.echo(f"Launching browser: {chrome_path}")
        click.echo("Please log in. Press Ctrl+C to skip to manual fallback.")
        try:
            discovered_email, oauth_token = get_auth_info_via_browser()
            if oauth_token:
                click.echo("Successfully extracted token from browser.")
                if discovered_email:
                    click.echo(f"Detected account: {discovered_email}")
                    email = discovered_email
            else:
                click.echo("Failed to extract token automatically.")
        except KeyboardInterrupt:
            click.echo("\n[!] User skipped to manual fallback.")
    else:
        click.echo("[!] No compatible browser found for automated login.")

    if not oauth_token:
        click.echo("Manual fallback initialization...")
        if not email:
            email = click.prompt("Enter your Google account email")
        click.echo(f"Account: {email}")
        click.echo("1. Visit https://accounts.google.com/EmbeddedSetup in your browser.")
        click.echo("2. Log in and click 'I agree' if prompted.")
        click.echo("   (Note: If it shows a spinning loader indefinitely, ignore it and proceed.)")
        click.echo("3. Open Developer Tools (F12) -> Application/Storage -> Cookies.")
        click.echo("4. Find the 'oauth_token' cookie (starts with 'oauth2_4/').")
        click.echo("5. Copy its value.")
        oauth_token = click.prompt("Enter the 'oauth_token' (oauth2_4/...)")

    # Final check for email if discovery + manual both missed it
    if not email:
        email = click.prompt("Enter the email address associated with this token")

    # Use the specific android_id from the gist, some token exchanges require this exact string format or it throws BadAuthentication.
    android_id = "0123456789abcdef"

    click.echo(f"Exchanging token for Master Token (using android_id: {android_id})...")

    try:
        response = gpsoauth.exchange_token(email, oauth_token, android_id)
        if "Token" in response:
            master_token = response["Token"]
            save_master_token(email, master_token)
            click.echo(f"Successfully saved Master Token in keyring for {email}")
            return master_token
        else:
            click.echo("Failed to exchange token. Response from Google:")
            click.echo(response)
            return None
    except Exception as e:
        click.echo(f"An error occurred: {e}")
        return None
