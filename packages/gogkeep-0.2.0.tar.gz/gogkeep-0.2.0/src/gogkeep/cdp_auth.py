import asyncio
import http.client
import json
import os
import shutil
import subprocess
import tempfile
import time

import websockets
from websockets.exceptions import ConnectionClosed


def find_chrome() -> str | None:
    """Find a compatible Chrome or Chromium binary."""
    for bin_name in ["google-chrome", "chromium-browser", "chromium", "chrome"]:
        path = shutil.which(bin_name)
        if path:
            return path
    return None


def is_port_open(port: int) -> bool:
    import socket

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.1)
        return s.connect_ex(("localhost", port)) == 0


def get_websocket_url(port: int) -> str | None:
    try:
        conn = http.client.HTTPConnection("localhost", port)
        conn.request("GET", "/json")
        resp = conn.getresponse()
        if resp.status == 200:
            data = json.loads(resp.read().decode())
            best_target = None
            for item in data:
                if item.get("type") == "page" and "webSocketDebuggerUrl" in item:
                    url = item.get("url", "")
                    title = item.get("title", "")
                    if "accounts.google.com" in url or "google" in title.lower():
                        return item["webSocketDebuggerUrl"]
                    best_target = item["webSocketDebuggerUrl"]
            return best_target
    except Exception:
        pass
    return None


async def watch_auth_info(ws_url: str) -> tuple[str | None, str | None]:
    print(f"[*] Attaching to CDP: {ws_url}")
    try:
        async with websockets.connect(ws_url, ping_interval=None) as ws:
            next_id = 1

            async def call_cdp(method: str, params: dict | None = None) -> dict:
                nonlocal next_id
                req_id = next_id
                next_id += 1
                msg = {"id": req_id, "method": method}
                if params:
                    msg["params"] = params
                await ws.send(json.dumps(msg))

                # Consume messages until we find our response
                while True:
                    resp_str = await ws.recv()
                    resp = json.loads(resp_str)
                    if resp.get("id") == req_id:
                        return resp

            await call_cdp("Runtime.enable")
            await call_cdp("Storage.enable")
            print("[*] CDP domains enabled (Runtime, Storage)")

            email = None
            token = None
            start_time = time.time()

            while (time.time() - start_time) < 600:  # 10 minute timeout
                try:
                    # 0. Get current URL
                    await call_cdp("Runtime.evaluate", {"expression": "window.location.href"})

                    # 1. Get cookies (Storage)
                    storage_resp = await call_cdp("Storage.getCookies")

                    all_cookies = []
                    all_cookies.extend(storage_resp.get("result", {}).get("cookies", []))

                    found_names = set()
                    for c in all_cookies:
                        found_names.add(c["name"])
                        if c["name"] == "oauth_token":
                            token = c["value"]
                        if c["name"] == "Email" and not email:
                            email = c["value"]

                    # 2. Extract email from AF_initDataCallback (High reliability)
                    if not email:
                        js = """
                        (function() {
                            const scripts = Array.from(document.querySelectorAll('script'));
                            for (const s of scripts) {
                                if (s.innerText.includes('AF_initDataCallback')) {
                                    try {
                                        let match = s.innerText.match(/AF_initDataCallback\\(([\\s\\S]*?)\\);?/);
                                        if (match) {
                                            let cbData = null;
                                            const AF_initDataCallback = (obj) => { cbData = obj; };
                                            eval('AF_initDataCallback(' + match[1] + ')');
                                            if (cbData && cbData.data && cbData.data[0] && typeof cbData.data[0][0] === 'string' && cbData.data[0][0].includes('@')) {
                                                return cbData.data[0][0];
                                            }
                                        }
                                    } catch(e) {}
                                    
                                    // Fallback to regex
                                    const emailMatch = s.innerText.match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}/);
                                    if (emailMatch) return emailMatch[0];
                                }
                            }
                            return null;
                        })()
                        """
                        email_resp = await call_cdp("Runtime.evaluate", {"expression": js})
                        res = email_resp.get("result", {}).get("result", {})
                        if res.get("type") == "string" and res.get("value"):
                            email = res.get("value")
                            print(f"[*] Account detected via page data: {email}")

                    if token:
                        print(f"[!] Success: oauth_token found! (Email: {email or 'Unknown'})")
                        return email, token

                except ConnectionClosed:
                    print("[!] Browser connection closed.")
                    break

                await asyncio.sleep(2)

    except Exception as e:
        print(f"[!] CDP Error: {e}")

    return None, None


def find_free_port() -> int:
    import socket

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("", 0))
        return s.getsockname()[1]


def get_auth_info_via_browser() -> tuple[str | None, str | None]:
    chrome_path = find_chrome()
    if not chrome_path:
        return None, None

    port = find_free_port()
    temp_profile_dir = tempfile.mkdtemp(prefix="gogkeep-auth-")
    url = "https://accounts.google.com/EmbeddedSetup"

    cmd = [
        chrome_path,
        f"--remote-debugging-port={port}",
        f"--user-data-dir={temp_profile_dir}",
        "--no-first-run",
        "--no-default-browser-check",
        url,
    ]

    proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    try:
        ws_url = None
        for _ in range(20):
            if is_port_open(port):
                ws_url = get_websocket_url(port)
                if ws_url:
                    break
            time.sleep(0.5)

        if not ws_url:
            return None, None

        return asyncio.run(watch_auth_info(ws_url))

    finally:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except Exception:
            proc.kill()
        if os.path.exists(temp_profile_dir):
            shutil.rmtree(temp_profile_dir)
