import concurrent.futures
import contextlib
import getpass
import json
import os
import platform
import sys

SERVICE_NAME = "gogkeep"

_backend_cache = None


def get_keyring_backend():
    """Resolve and return the appropriate keyring backend based on platform and env vars."""
    global _backend_cache
    if _backend_cache is not None:
        return _backend_cache

    backend_env = os.environ.get("GOGKEEP_KEYRING_BACKEND", "auto")

    selected_backend = None

    # gogcli logic: Force file backend on linux if no DBus session (common on headless/wsl/docker)
    dbus_addr = os.environ.get("DBUS_SESSION_BUS_ADDRESS")
    if platform.system() == "Linux" and backend_env == "auto" and not dbus_addr:
        backend_env = "file"

    if backend_env == "auto":
        from keyring.backend import get_all_keyring

        all_backends = sorted(get_all_keyring(), key=lambda x: x.priority, reverse=True)

        candidate = None
        for be in all_backends:
            if be.priority >= 1 and "keyrings.alt" not in str(be.__class__):
                candidate = be
                break

        if candidate:
            if platform.system() == "Linux" and "SecretService" in str(candidate.__class__):

                def check_native():
                    with contextlib.suppress(Exception):
                        candidate.get_credential("test", "test")

                with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
                    future = executor.submit(check_native)
                    try:
                        future.result(timeout=5)
                        selected_backend = candidate
                    except concurrent.futures.TimeoutError:
                        backend_env = "file"
            else:
                selected_backend = candidate
        else:
            backend_env = "file"

    if backend_env == "keychain" and platform.system() == "Darwin":
        from keyring.backends.macOS import Keyring

        selected_backend = Keyring()

    # Isolated Encrypted File Backend Fallback
    if backend_env == "file" or selected_backend is None:
        try:
            from keyrings.alt.file import EncryptedKeyring

            class IsolatedEncryptedKeyring(EncryptedKeyring):
                @property
                def file_path(self):
                    custom_dir = os.environ.get("GOGKEEP_KEYRING_PATH", os.path.expanduser("~/.config/gogkeep"))
                    os.makedirs(custom_dir, exist_ok=True)
                    return os.path.join(custom_dir, "crypted_pass.cfg")

                def _get_keyring_key(self):
                    env_pwd = os.environ.get("GOGKEEP_KEYRING_PASSWORD")
                    if env_pwd is not None:
                        return env_pwd

                    if not sys.stdin.isatty():
                        raise RuntimeError("Not a TTY and GOGKEEP_KEYRING_PASSWORD not set for file backend.")

                    val = getpass.getpass("Password for encrypted keyring: ")
                    os.environ["GOGKEEP_KEYRING_PASSWORD"] = val
                    return val

                @property
                def keyring_key(self):
                    return self._get_keyring_key()

            selected_backend = IsolatedEncryptedKeyring()
        except ImportError:
            from keyring.backends.null import Keyring as NullKeyring

            selected_backend = NullKeyring()

    _backend_cache = selected_backend
    return selected_backend


def set_token(client: str, email: str, token: str, backend_override=None):
    kr = backend_override or get_keyring_backend()
    key = f"token:{client}:{email}"
    kr.set_password(SERVICE_NAME, key, token)

    if platform.system() == "Darwin" and "macOS" in str(kr.__class__):
        validated = kr.get_password(SERVICE_NAME, key)
        if not validated:
            kr.set_password(SERVICE_NAME, key, token)


def get_token(client: str, email: str, backend_override=None) -> str | None:
    kr = backend_override or get_keyring_backend()
    primary_key = f"token:{client}:{email}"
    legacy_key = f"token:{email}"

    with contextlib.redirect_stderr(open(os.devnull, "w")):
        try:
            data = kr.get_password(SERVICE_NAME, primary_key)
        except Exception:
            data = None

        if data is None and client == "default":
            try:
                data = kr.get_password(SERVICE_NAME, legacy_key)
                if data is not None:
                    kr.set_password(SERVICE_NAME, primary_key, data)
            except Exception:
                data = None

    if data is None:
        raise KeyError("Token not found")

    if isinstance(data, str) and data.startswith("{"):
        try:
            return json.loads(data).get("master_token", data)
        except json.JSONDecodeError:
            pass

    return data


def get_default_account(client: str = "default", backend_override=None) -> str | None:
    kr = backend_override or get_keyring_backend()
    with contextlib.redirect_stderr(open(os.devnull, "w")):
        try:
            account = kr.get_password(SERVICE_NAME, f"default_account:{client}")
            if not account:
                account = kr.get_password(SERVICE_NAME, "default_account")
            if not account:
                account = kr.get_password("gogkeep", "last_used")
        except Exception:
            return None
    return account


def set_default_account(email: str, client: str = "default", backend_override=None):
    kr = backend_override or get_keyring_backend()
    kr.set_password(SERVICE_NAME, f"default_account:{client}", email)
