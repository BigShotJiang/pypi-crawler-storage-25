import hashlib

import gkeepapi

from .auth import get_master_token


def get_keep(email):
    master_token = get_master_token(email)
    if not master_token:
        raise Exception("No master token found. Run 'gogkeep login' first.")

    # Ensure android_id is consistent with the one used during exchange.
    android_id = hashlib.md5(email.encode()).hexdigest()[:16]

    keep = gkeepapi.Keep()

    try:
        # device_id must match the one used to exchange the token.
        keep.authenticate(email, master_token, device_id=android_id)
        return keep
    except gkeepapi.exception.LoginException as e:
        raise Exception(f"Login failed: {e}. You may need to run 'gogkeep login' again.") from e


def list_notes(keep, max_results=100):
    notes = list(keep.find(trashed=False))[:max_results]
    return notes


def search_notes(keep, query):
    q = query.lower()

    def search_func(n):
        if q in n.title.lower():
            return True
        if hasattr(n, "text") and q in n.text.lower():
            return True
        if hasattr(n, "items"):
            for item in n.items:
                if q in item.text.lower():
                    return True
        return False

    notes = list(keep.find(func=search_func, trashed=False))
    return notes


def get_note(keep, note_id):
    # gkeepapi's get() takes an ID.
    note = keep.get(note_id)
    return note


def create_note(keep, title, text=None, items=None):
    if text:
        note = keep.createNote(title, text)
    elif items:
        note = keep.createList(title, items)
    else:
        note = keep.createNote(title, "")
    keep.sync()
    return note


def delete_note(keep, note_id):
    note = keep.get(note_id)
    if note:
        note.delete()
        keep.sync()
        return True
    return False


def download_attachment(keep, attachment_name, out_path):
    # attachment_name: notes/<noteId>/attachments/<attachmentId>
    parts = attachment_name.split("/")
    if len(parts) < 4:
        raise Exception("Invalid attachment name format. Expected: notes/<noteId>/attachments/<attachmentId>")
    note_id = parts[1]
    attachment_id = parts[3]

    note = keep.get(note_id)
    if not note:
        raise Exception(f"Note not found: {note_id}")

    # Search in images, drawings, audio
    # gkeepapi uses different attributes for different types of blobs
    blobs = []
    if hasattr(note, "images"):
        blobs.extend(note.images)
    if hasattr(note, "drawings"):
        blobs.extend(note.drawings)
    if hasattr(note, "audio"):
        blobs.extend(note.audio)

    for att in blobs:
        if att.id == attachment_id:
            blob = att.get_blob()
            data = blob.read()
            with open(out_path, "wb") as f:
                f.write(data)
            return len(data)
    return 0
