import unittest
from unittest.mock import MagicMock, patch

from click.testing import CliRunner

from gogkeep.cli import main


class TestCLI(unittest.TestCase):
    def setUp(self):
        self.runner = CliRunner()

    @patch("gogkeep.cli.get_keep")
    @patch("gogkeep.cli.list_notes")
    def test_list_command(self, mock_list_notes, mock_get_keep):
        # Mock note object
        mock_note = MagicMock()
        mock_note.id = "abc123"
        mock_note.title = "Test Note"
        mock_note.timestamps.updated.isoformat.return_value = "2024-01-01T00:00:00Z"
        mock_note.trashed = False

        mock_list_notes.return_value = [mock_note]

        result = self.runner.invoke(main, ["-a", "test@example.com", "list"])

        self.assertEqual(result.exit_code, 0)
        self.assertIn("NAME", result.output)
        self.assertIn("TITLE", result.output)
        self.assertIn("UPDATED", result.output)
        self.assertIn("notes/abc123", result.output)
        self.assertIn("Test Note", result.output)

    @patch("gogkeep.cli.get_keep")
    @patch("gogkeep.cli.get_note")
    def test_get_command(self, mock_get_note, mock_get_keep):
        # Mock note object
        mock_note = MagicMock()
        mock_note.id = "abc123"
        mock_note.title = "Test Note"
        mock_note.timestamps.created.isoformat.return_value = "2024-01-01T00:00:00Z"
        mock_note.timestamps.updated.isoformat.return_value = "2024-01-02T00:00:00Z"
        mock_note.text = "Hello World"
        mock_note.trashed = False
        mock_note.images = []
        mock_note.drawings = []
        mock_note.audio = []

        mock_get_note.return_value = mock_note

        result = self.runner.invoke(main, ["-a", "test@example.com", "get", "abc123"])

        self.assertEqual(result.exit_code, 0)
        self.assertIn("name\tnotes/abc123", result.output)
        self.assertIn("title\tTest Note", result.output)
        self.assertIn("Hello World", result.output)

    @patch("gogkeep.cli.get_keep")
    @patch("gogkeep.cli.create_note")
    def test_create_command(self, mock_create_note, mock_get_keep):
        # Mock note object
        mock_note = MagicMock()
        mock_note.id = "new123"
        mock_note.title = "New Note"
        mock_note.timestamps.created.isoformat.return_value = "2024-01-01T00:00:00Z"

        mock_create_note.return_value = mock_note

        result = self.runner.invoke(
            main, ["-a", "test@example.com", "create", "--title", "New Note", "--text", "content"]
        )

        self.assertEqual(result.exit_code, 0)
        self.assertIn("name\tnotes/new123", result.output)
        self.assertIn("title\tNew Note", result.output)
        self.assertIn("created\t2024-01-01T00:00:00Z", result.output)


if __name__ == "__main__":
    unittest.main()
