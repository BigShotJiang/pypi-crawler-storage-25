"""
Paquete loaddata
================

Clase principal:
- load_data: Clase para carga incremental a base de datos PostgreSQL.

Clase contrato
- LoadContract
"""

from .carga import LoadData, DataContractValidator

__all__ = ["LoadData", "DataContractValidator"]
