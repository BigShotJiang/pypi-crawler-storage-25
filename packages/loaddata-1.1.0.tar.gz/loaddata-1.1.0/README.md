# 📦 LoadData & DataContractValidator

Este módulo proporciona utilidades para:

- Carga de datos en PostgreSQL
- Generación de identificadores únicos
- Validación de contratos de datos
- Manejo de fechas

---

## 🧱 Clase: `LoadData`

Clase principal para gestionar la carga de datos en base de datos PostgreSQL.

### 🔌 `enginepsql()`
Crea y devuelve un engine de conexión a PostgreSQL usando variables de entorno:

- `USUARIO`
- `PASSWORD`
- `HOSTNAME`
- `PORT`
- `DATABASE`

---

### 🧹 `truncate_table(schema, table)`
Trunca una tabla sin eliminar su estructura:

- Desactiva triggers (FKs)
- Ejecuta `TRUNCATE`
- Reactiva triggers

---

### 🆔 `unique_id_()`
Genera un identificador único (`unique_id`) para cada fila del DataFrame:

- Usa columnas definidas en `uid_cols`
- Limpia strings (lowercase, sin acentos ni caracteres especiales)
- Genera hash SHA256 → entero int64

---

### 📥 `load_all_data(...)`

Carga datos en PostgreSQL.

#### Parámetros:

- `input_table`: DataFrame a cargar
- `output_table`: `schema.table`
- `uid_cols`: columnas para generar ID único
- `uid_need`: columna ya existente como ID
- `truncate`: si `True`, borra la tabla antes

#### Comportamiento:

- 🔁 **Carga incremental (default)**:
  - Genera `unique_id`
  - Convierte datos a `polars`
  - Realiza `anti-join` para evitar duplicados

- 🧨 **Carga completa (`truncate=True`)**:
  - Trunca tabla
  - Inserta todos los datos

- 🆕 **Si la tabla no existe**:
  - La crea automáticamente

---

### 📊 `reportar_datos_aniadidos()`
Imprime en consola el número de filas insertadas:

```json
{"datos_aniadidos": X}

