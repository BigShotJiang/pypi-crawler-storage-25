import requests
import uuid
import json
from typing import Any, Dict, List, Optional

class Response:
    def __init__(self, data: Dict[str, Any]):
        self.text = data.get("text", "")
        self.session_id = data.get("session_id", "")
        self.files = data.get("new_files", [])
        self.model = data.get("model_used", "")
        self.job_id = data.get("job_id")

class ChatSession:
    def __init__(self, client: 'Client', session_id: str):
        self.client = client
        self.session_id = session_id

    def send_message(self, prompt: str) -> Response:
        return self.client.generate_content(prompt, session_id=self.session_id)

class Client:
    def __init__(self, api_key: str, base_url: str = "http://localhost:8010"):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.headers = {
            "X-API-KEY": self.api_key,
            "Content-Type": "application/json"
        }

    def generate_content(self, prompt: str, session_id: Optional[str] = None) -> Response:
        url = f"{self.base_url}/api/v1/claw/chat"
        payload = {
            "prompt": prompt,
            "session_id": session_id,
        }
        
        response = requests.post(url, headers=self.headers, json=payload)
        if response.status_code != 200:
            try:
                error_msg = response.json().get("detail", response.text)
            except:
                error_msg = response.text
            raise Exception(f"API Error ({response.status_code}): {error_msg}")
            
        return Response(response.json())

    def get_job_status(self, job_id: str) -> Dict[str, Any]:
        url = f"{self.base_url}/api/v1/claw/status/{job_id}"
        response = requests.get(url, headers=self.headers)
        if response.status_code != 200:
             raise Exception(f"API Error ({response.status_code}): {response.text}")
        return response.json()

    def download_file(self, session_id: str, filename: str, output_path: str) -> str:
        url = f"{self.base_url}/api/v1/claw/download/{session_id}/{filename}"
        response = requests.get(url, headers=self.headers, stream=True)
        if response.status_code != 200:
             raise Exception(f"API Error ({response.status_code}): {response.text}")
        
        with open(output_path, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)
        return output_path

    def start_chat(self) -> ChatSession:
        session_id = f"sdk-session-{uuid.uuid4().hex[:8]}"
        return ChatSession(self, session_id)
