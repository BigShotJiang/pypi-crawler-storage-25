# Claude-Claw SDK

Thư viện Python để tích hợp hệ thống Agent Multi-Workflow "Claude-Claw" vào ứng dụng của bạn.

## Cài đặt

```bash
pip install .
```

## Cách sử dụng

### 1. Khởi tạo Client

```python
import claude_claw

# Sử dụng mã SDK được cấp (Định dạng: LcAIxnfu2h873h...)
client = claude_claw.Client(api_key="LcAIxnfu2h873h_PRO_SDK_9999", base_url="https://api.locaith.com")
```

### 2. Soạn thảo văn bản (Drafting)

```python
response = client.generate_content("Hãy soạn thảo một hợp đồng thuê nhà ngắn gọn.")
print("Nội dung:", response.text)
if response.files:
    print("Các tệp đã tạo:", response.files)
```

### 3. Lập trình Website (Web Coding)

Hệ thống Agent sẽ tự động nhận diện yêu cầu kỹ thuật và thực thi workflow code.

```python
chat = client.start_chat()
response = chat.send_message("Tạo một website landing page cho dịch vụ spa, dùng Next.js và Tailwind.")
print(response.text)

# Theo dõi tiến độ nếu là job chạy ngầm
if response.job_id:
    print(f"Workflow đang thực thi ngầm. Job ID: {response.job_id}")
```

### 4. Chat có ngữ cảnh (Session)

```python
chat = client.start_chat()
chat.send_message("Tôi muốn viết một cuốn sách về AI.")
response = chat.send_message("Hãy gợi ý cho tôi mục lục.") # Giữ nguyên ngữ cảnh session
print(response.text)
```

## Lưu ý bảo mật
- Đừng bao giờ chia sẻ API Key của bạn (bắt đầu bằng `LcAIxnfu2h87`).
- Đảm bảo backend server của bạn đã cấu hình đúng `BACKEND_API_KEY` trong file `.env`.
