from setuptools import setup, find_packages

setup(
    name="claude_claw_agent",
    version="0.1.1",
    packages=find_packages(),
    install_requires=[
        "requests",
        "pydantic",
    ],
    author="Claw Team",
    description="Python SDK for Claude-Claw Multi-Agent Workflow",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.7',
)
