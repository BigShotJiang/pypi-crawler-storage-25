"""Test helper: Qubit component that circularly references Resonator via TYPE_CHECKING."""
from __future__ import annotations

from typing import TYPE_CHECKING

from quam.core import QuamComponent, quam_dataclass

if TYPE_CHECKING:
    from tests.serialisation.forward_ref_helpers.resonator import Resonator


@quam_dataclass
class Qubit(QuamComponent):
    resonator: Resonator
