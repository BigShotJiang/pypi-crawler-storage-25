# FastClaw

A lightweight but powerful AI Agent framework in Python.

## PyPI Installation (Recommended)

```bash
# Install
pip install fastclaw-ai

# Run
fastclaw start

# Persistent running (recommended for server)
nohup fastclaw start > /tmp/fastclaw.log 2>&1 &
```

### Configure Agent

After starting, visit http://localhost:8765 , click Settings in the top right corner to configure main_agent, recommended: deepseek-chat.

Or edit the config file:
```bash
vim ~/.fastclaw/workspace/data/agents/main_agent/metadata.json
```

### CLI Usage

```bash
# Interactive chat
fastclaw chat

# New session
fastclaw chat --new

# Check status
fastclaw status
```

---

## Git Clone

```bash
git clone https://github.com/kandada/fastclaw.git
cd fastclaw
pip install -r requirements.txt
```

```bash
# Run
python main.py start

# Persistent running
nohup python main.py start > fastclaw.log 2>&1 &
```

### Configure Agent

After starting, visit http://localhost:8765 , click Settings in the top right corner to configure main_agent, recommended: deepseek-chat.

Or edit the config file:
```bash
vim workspace/data/agents/main_agent/metadata.json
```

### CLI Usage

```bash
# Interactive chat
python main.py chat

# New session
python main.py chat --new

# Check status
python main.py status
```

---

## Design Philosophy

FastClaw is built on the core concept of **event-driven agent orchestration**. Key design principles:

- **Graph-based Agent**: Uses a directed graph to orchestrate agent behavior, supporting conditional branching between nodes (e.g., tool execution, response generation)
- **Event Streaming**: Real-time streaming output of LLM responses for better user experience
- **Tool System**: Extensible tool framework supporting Shell commands, skills, and custom integrations
- **Session Management**: Persistent conversation history with multi-session support
- **Cron Scheduling**: Built-in cron-style task scheduling for automated workflows

## Features

- 🤖 **LLM-powered** - Built on [FastMind](https://github.com/kandada/fastmind) framework with streaming support
- 🔧 **Tool Calling** - Execute Shell commands, skills, and more
- ⏰ **Cron Jobs** - Schedule tasks with cron expressions
- 💬 **Multi-channel** - Feishu, iMessage integrations
- 🎨 **Extensible** - Easy to add custom skills and agents
- 🐍 **Python Ecosystem** - Seamlessly call professional libraries like numpy and pandas, enabling AI to use Python ecosystem tools as skillfully as humans

## License

GPL-3.0

Copyright (c) 2024-2026 xiefujin. All rights reserved.

## Official Website

[https://www.fastclaw.world/](https://www.fastclaw.world/) | [https://fastclaw-ai.com/](https://fastclaw-ai.com/)

## Acknowledgments

Inspired by [OpenClaw](https://github.com/openclaw/openclaw). Special thanks to the open source community.

---

FastClaw is powerful, but its use depends entirely on the user - all responsibility lies with the user yourself.

---

Author：[xiefujin](https://github.com/kandada) email: 490021684@qq.com，welcome to contact me.
