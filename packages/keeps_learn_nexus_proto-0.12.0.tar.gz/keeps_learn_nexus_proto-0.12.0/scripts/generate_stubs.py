#!/usr/bin/env python3
"""
Generate Python stubs from .proto files using grpcio-tools.

This script:
1. Finds all .proto files in the protos directory
2. Generates stubs using protoc (gRPC Python plugin)
3. Fixes imports to use relative imports for package compatibility

Usage:
    python3 scripts/generate_stubs.py
    or
    make build
"""

import glob
import os
import re
import subprocess
import sys


def main():
    """Main entry point."""
    script_dir = os.path.dirname(os.path.abspath(__file__))
    repo_root = os.path.dirname(script_dir)
    
    protos_dir = os.path.join(repo_root, 'protos')
    generated_dir = os.path.join(repo_root, 'nexus_proto', 'generated')
    
    print("Generating Python gRPC stubs...")
    print(f"  Protos directory: {protos_dir}")
    print(f"  Output directory: {generated_dir}")
    
    if not os.path.isdir(protos_dir):
        print(f"Error: Protos directory not found: {protos_dir}")
        return 1
    
    # Find all .proto files
    proto_files = sorted(glob.glob(os.path.join(protos_dir, '**', '*.proto'), recursive=True))
    
    if not proto_files:
        print(f"No .proto files found in {protos_dir}")
        return 1
    
    print(f"\nFound {len(proto_files)} .proto files:")
    for proto_file in proto_files:
        rel_path = os.path.relpath(proto_file, protos_dir)
        print(f"  - {rel_path}")
    
    # Generate stubs for each proto file
    print("\nGenerating stubs...")
    for proto_file in proto_files:
        rel_path = os.path.relpath(proto_file, protos_dir)
        print(f"  - {rel_path}")
        
        cmd = [
            sys.executable, '-m', 'grpc_tools.protoc',
            f'-I{protos_dir}',
            f'--python_out={generated_dir}',
            f'--grpc_python_out={generated_dir}',
            proto_file
        ]
        
        try:
            subprocess.run(cmd, capture_output=True, text=True, check=True)
        except subprocess.CalledProcessError as e:
            print(f"    Error: {e.stderr}")
            return 1
    
    # Fix imports to use relative imports
    print("\nFixing imports...")
    for pb2_file in glob.glob(os.path.join(generated_dir, '**', '*_pb2*.py'), recursive=True):
        with open(pb2_file, 'r') as f:
            content = f.read()
        
        # Replace: from <module> import X_pb2 as Y -> from . import X_pb2 as Y
        content = re.sub(
            r'^from [A-Za-z0-9_]+ import ([A-Za-z0-9_]*_pb2) as ([A-Za-z0-9_]*)',
            r'from . import \1 as \2',
            content,
            flags=re.MULTILINE
        )
        
        with open(pb2_file, 'w') as f:
            f.write(content)
    
    print(f"\n✓ Done. Output in {generated_dir}")  # noqa: F541
    return 0


if __name__ == '__main__':
    sys.exit(main())
