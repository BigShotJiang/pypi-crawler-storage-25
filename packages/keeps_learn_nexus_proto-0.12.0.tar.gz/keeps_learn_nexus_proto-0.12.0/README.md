# Nexus Proto

Shared Protocol Buffer definitions for Nexus microservices.

## Why "Nexus"?

The name **Nexus** was chosen to represent the **central connection** between microservices. In many languages, "nexus" refers to a point of intersection or link, which is exactly what this project provides: an efficient hub for communication between distributed services built in different technologies. The idea is to create a convergence point that makes it easier to integrate systems, ensuring consistent and scalable communication, no matter the language or framework used. **Nexus** is the solution that connects and unites services in a simple and effective way.

## Features

- **Centralized Protocol Definitions**: All communication contracts are defined in a shared repository of `.proto` files.
- **Pre-Generated Python Stubs**: Python stubs (`*_pb2.py` and `*_pb2_grpc.py`) are automatically generated and included in the package, eliminating the need for consumers to generate them.
- **Multi-Language Support**: Easily integrate microservices written in different programming languages (e.g., Python, Node.js, Java, etc.).
- **Scalable Communication**: Easily extend the system as new microservices are added to the architecture.
- **gRPC-powered**: Leveraging gRPC for high-performance communication with built-in support for multiple programming languages.
- **Industry Standard**: Follows best practices from projects like `googleapis-common-protos`, ensuring consistency and reliability.

## Installation

### Node.js / npm

```bash
npm install @keeps-learn/nexus-proto
```

📦 **npm Package**: https://www.npmjs.com/package/@keeps-learn/nexus-proto

### Python / pip

```bash
pip install keeps-learn-nexus-proto
```

📦 **PyPI Package**: https://pypi.org/project/keeps-learn-nexus-proto/

## Quick Start - Python

### Using Pre-Generated Stubs (Recommended)

```python
# Import stubs directly - no compilation needed!
from nexus_proto.generated.myaccount import users_pb2, users_pb2_grpc
from nexus_proto.generated.konquest import mission_pb2, mission_pb2_grpc

# Use message types
user = users_pb2.User(id="123", name="John Doe")

# Use service stubs with gRPC
import grpc
channel = grpc.aio.secure_channel('localhost:50051', grpc.ssl_channel_credentials())
stub = users_pb2_grpc.UserServiceStub(channel)
```

See [USAGE.md](./USAGE.md) for more detailed examples and options.

## Publishing

1. Update version in `package.json`, `setup.py`, and `pyproject.toml`
2. Commit: `git commit -m "Bump version to X.Y.Z"`
3. Tag: `git tag vX.Y.Z`
4. Push: `git push origin vX.Y.Z`

GitHub Actions publishes automatically to both **npmjs.com** and **pypi.org**

See [PUBLISH.md](./PUBLISH.md) for detailed publishing instructions.
