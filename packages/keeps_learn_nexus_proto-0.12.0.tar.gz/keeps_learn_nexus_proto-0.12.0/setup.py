import os
import shutil
import subprocess
import sys

from setuptools import setup
from setuptools.command.build_py import build_py


class CustomBuildPy(build_py):
    """Custom build command that generates stubs and copies proto files into the package."""

    def run(self):
        # Generate stubs before building
        self._generate_stubs()

        # Run the standard build
        super().run()

        # Copy proto files into the package
        protos_src = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'protos')
        protos_dst = os.path.join(self.build_lib, 'nexus_proto', 'protos')
        if os.path.exists(protos_src):
            if os.path.exists(protos_dst):
                shutil.rmtree(protos_dst)
            shutil.copytree(protos_src, protos_dst)

        # Copy generated stubs into the package
        generated_src = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'nexus_proto', 'generated')
        generated_dst = os.path.join(self.build_lib, 'nexus_proto', 'generated')
        if os.path.exists(generated_src):
            if os.path.exists(generated_dst):
                shutil.rmtree(generated_dst)
            shutil.copytree(generated_src, generated_dst)

    def _generate_stubs(self):
        """Generate Python stubs from .proto files."""
        repo_root = os.path.dirname(os.path.abspath(__file__))
        script_path = os.path.join(repo_root, 'scripts', 'generate_stubs.py')

        if not os.path.exists(script_path):
            print(f"Warning: generate_stubs.py not found at {script_path}")
            return

        print("Generating Protocol Buffer stubs...")
        try:
            result = subprocess.run(
                [sys.executable, script_path],
                cwd=repo_root,
                capture_output=True,
                text=True,
                check=True
            )
            print(result.stdout)
            if result.stderr:
                print(result.stderr)
        except subprocess.CalledProcessError as e:
            print(f"Error generating stubs: {e.stderr}")
            raise


setup(
    cmdclass={'build_py': CustomBuildPy},
)
