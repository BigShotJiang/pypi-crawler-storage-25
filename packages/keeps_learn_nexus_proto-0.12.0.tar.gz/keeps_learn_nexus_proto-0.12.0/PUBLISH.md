# Publishing Guide

## Quick Start (Recommended)

Simply run:

```bash
make publish
```

This will:
1. ✅ Verify no uncommitted changes
2. ✅ Regenerate stubs (ensures they're up-to-date)
3. ✅ Ask for new version
4. ✅ Update version in all files
5. ✅ Commit version bump + stubs
6. ✅ Create git tag
7. ✅ Push to remote
8. ✅ GitHub Actions publishes to npm and PyPI

### Example

```bash
$ make publish

╔════════════════════════════════════════════════════════════════╗
║                    PUBLISH WORKFLOW                           ║
╚════════════════════════════════════════════════════════════════╝

Step 1: Checking for uncommitted changes...
✓ No uncommitted changes

Step 2: Regenerating stubs to ensure they're up-to-date...
✓ Stubs regenerated

Current version: 0.10.1

Enter new version (e.g., 0.11.0):
0.11.0

Updating version to 0.11.0...
✓ Version updated

Committing and tagging...
✓ Committed and tagged

Pushing to remote...
✓ Pushed

╔════════════════════════════════════════════════════════════════╗
║                    ✅ PUBLISH COMPLETE!                       ║
╚════════════════════════════════════════════════════════════════╝

Version 0.11.0 published!
GitHub Actions will publish to npm and PyPI.
```

---

## Manual Publishing (Legacy)

If you prefer to do it manually, follow these steps:

### 1. Update Version

Update the version in **all** files:

#### package.json
```json
{
  "version": "0.7.0"
}
```

#### pyproject.toml
```toml
version = "0.7.0"
```

#### nexus_proto/__init__.py
```python
__version__ = "0.7.0"
```

### 2. Commit

```bash
git add .
git commit -m "Bump version to 0.7.0"
```

### 3. Tag

```bash
git tag v0.7.0
```

### 4. Push

```bash
git push origin main
git push origin v0.7.0
```

### 5. Done!

GitHub Actions automatically publishes to **both** registries:

- **npm**: https://www.npmjs.com/package/@keeps-learn/nexus-proto
- **PyPI**: https://pypi.org/project/keeps-learn-nexus-proto/

Check the pipeline at: https://github.com/Keeps-Learn/nexus-proto/actions

## Installation

### Node.js
```bash
npm install @keeps-learn/nexus-proto
```

### Python
```bash
pip install keeps-learn-nexus-proto
```

