"""
Nexus Proto - Shared Protocol Buffer definitions for Nexus microservices
"""

__version__ = "0.12.0"
__author__ = "Keeps"
__license__ = "MIT"

import os

# Installed mode: protos are copied inside the package during build
_installed_protos = os.path.join(os.path.dirname(__file__), 'protos')
# Development/editable mode: protos are at the repo root
_dev_protos = os.path.join(os.path.dirname(__file__), '..', 'protos')

if os.path.isdir(_installed_protos):
    PROTO_DIR = os.path.abspath(_installed_protos)
else:
    PROTO_DIR = os.path.abspath(_dev_protos)

# Generated stubs directory
_installed_generated = os.path.join(os.path.dirname(__file__), 'generated')
_dev_generated = os.path.join(os.path.dirname(__file__), '..', 'nexus_proto', 'generated')

if os.path.isdir(_installed_generated):
    GENERATED_DIR = os.path.abspath(_installed_generated)
else:
    GENERATED_DIR = os.path.abspath(_dev_generated)


def get_proto_path(proto_name: str) -> str:
    """
    Get the full path to a proto file.

    Args:
        proto_name: Name of the proto file (e.g., 'users', 'workspaces')

    Returns:
        Full path to the proto file
    """
    return os.path.join(PROTO_DIR, f'{proto_name}.proto')


def get_proto_dir() -> str:
    """
    Get the path to the protos directory.

    Returns:
        Path to the protos directory
    """
    return PROTO_DIR


def get_generated_dir() -> str:
    """
    Get the path to the generated stubs directory.

    Returns:
        Path to the generated stubs directory
    """
    return GENERATED_DIR


__all__ = ['get_proto_path', 'get_proto_dir', 'get_generated_dir', 'PROTO_DIR', 'GENERATED_DIR']

