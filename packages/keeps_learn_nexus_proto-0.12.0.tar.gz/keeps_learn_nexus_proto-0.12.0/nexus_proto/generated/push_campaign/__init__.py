"""Push Campaign service stubs."""

