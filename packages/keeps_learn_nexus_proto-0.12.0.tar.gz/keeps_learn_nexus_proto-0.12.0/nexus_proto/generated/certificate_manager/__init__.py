"""Certificate Manager service stubs."""

