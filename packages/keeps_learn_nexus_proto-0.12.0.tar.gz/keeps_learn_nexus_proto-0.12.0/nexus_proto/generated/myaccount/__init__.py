"""MyAccount service stubs."""

