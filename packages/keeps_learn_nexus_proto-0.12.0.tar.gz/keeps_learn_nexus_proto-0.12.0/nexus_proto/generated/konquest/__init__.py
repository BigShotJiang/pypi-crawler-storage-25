"""Konquest service stubs."""

