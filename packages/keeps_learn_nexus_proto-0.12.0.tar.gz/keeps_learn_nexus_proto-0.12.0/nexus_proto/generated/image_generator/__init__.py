"""Image Generator service stubs."""

