from forge_cloud.models import ChatCompletionRequest, ChatMessage
from forge_cloud.proxy import ProxyEngine


def _simple_request(content: str = "What is 2+2?", **kwargs) -> ChatCompletionRequest:
    return ChatCompletionRequest(
        model="test-model",
        messages=[ChatMessage(role="user", content=content)],
        **kwargs,
    )


class TestProxyEngine:
    def setup_method(self):
        self.engine = ProxyEngine()

    def test_route_simple_query(self):
        req = _simple_request("What is Python?")
        decision = self.engine.route_request(req, "vllm")
        assert decision.complexity.value == "simple"

    def test_route_complex_query(self):
        req = _simple_request(
            "Refactor the entire codebase to implement a new module "
            "that integrates the service layer. First analyze the "
            "dependencies, then design the architecture."
        )
        decision = self.engine.route_request(req, "vllm")
        assert decision.complexity.value == "complex"
        assert decision.mode.value == "think"
        assert decision.sampling_profile == "thinking"

    def test_route_auto_route_disabled(self):
        req = _simple_request("hello", forge_auto_route=False)
        decision = self.engine.route_request(req, "vllm")
        assert decision.mode.value == "think"

    def test_build_upstream_body_includes_model(self):
        req = _simple_request()
        decision = self.engine.route_request(req, "vllm")
        body = self.engine.build_upstream_body(req, decision)
        assert body["model"] == "test-model"
        assert len(body["messages"]) == 1
        assert body["messages"][0]["role"] == "user"

    def test_build_upstream_body_includes_extra_body(self):
        req = _simple_request()
        decision = self.engine.route_request(req, "vllm")
        body = self.engine.build_upstream_body(req, decision)
        extra = body.get("extra_body", {})
        assert "chat_template_kwargs" in extra

    def test_build_upstream_body_dashscope_format(self):
        req = _simple_request()
        decision = self.engine.route_request(req, "dashscope")
        body = self.engine.build_upstream_body(req, decision)
        extra = body.get("extra_body", {})
        assert "enable_thinking" in extra
        assert "chat_template_kwargs" not in extra

    def test_build_upstream_body_user_temperature_preserved(self):
        req = _simple_request(temperature=0.3)
        decision = self.engine.route_request(req, "vllm")
        body = self.engine.build_upstream_body(req, decision)
        assert body["temperature"] == 0.3

    def test_build_upstream_body_stream_passed(self):
        req = _simple_request(stream=True)
        decision = self.engine.route_request(req, "vllm")
        body = self.engine.build_upstream_body(req, decision)
        assert body["stream"] is True

    def test_build_upstream_body_max_tokens_passed(self):
        req = _simple_request(max_tokens=512)
        decision = self.engine.route_request(req, "vllm")
        body = self.engine.build_upstream_body(req, decision)
        assert body["max_tokens"] == 512

    def test_build_upstream_body_no_max_tokens_if_none(self):
        req = _simple_request()
        decision = self.engine.route_request(req, "vllm")
        body = self.engine.build_upstream_body(req, decision)
        assert "max_tokens" not in body

    def test_build_response_adds_forge_metadata(self):
        req = _simple_request()
        decision = self.engine.route_request(req, "vllm")
        upstream = {
            "id": "chatcmpl-test",
            "choices": [{"message": {"role": "assistant", "content": "4"}}],
            "usage": {"prompt_tokens": 10, "completion_tokens": 1},
        }
        result = self.engine.build_response(upstream, decision)
        assert "forge" in result
        assert result["forge"]["backend"] == "vllm"
        assert result["forge"]["thinking_mode"] in ("think", "no_think")
        assert result["forge"]["complexity"] in ("simple", "moderate", "complex")

    def test_build_response_preserves_upstream(self):
        req = _simple_request()
        decision = self.engine.route_request(req, "vllm")
        upstream = {
            "id": "chatcmpl-xyz",
            "choices": [{"message": {"role": "assistant", "content": "hello"}}],
            "usage": {"prompt_tokens": 5, "completion_tokens": 1},
        }
        result = self.engine.build_response(upstream, decision)
        assert result["id"] == "chatcmpl-xyz"
        assert result["choices"][0]["message"]["content"] == "hello"

    def test_resolve_backend_uses_key_type(self):
        from forge_cloud.models import APIKeyInfo

        key_info = APIKeyInfo(key="fk-test", name="test", backend_type="dashscope")
        assert self.engine.resolve_backend(key_info, "vllm") == "dashscope"

    def test_resolve_backend_falls_back(self):
        from forge_cloud.models import APIKeyInfo

        key_info = APIKeyInfo(key="fk-test", name="test", backend_type="")
        assert self.engine.resolve_backend(key_info, "sglang") == "sglang"

    def test_sampling_nonstandard_params_in_extra_body(self):
        req = _simple_request()
        decision = self.engine.route_request(req, "vllm")
        body = self.engine.build_upstream_body(req, decision)
        extra = body.get("extra_body", {})
        assert "top_k" in extra or "min_p" in extra

    def test_route_extracts_last_user_message(self):
        req = ChatCompletionRequest(
            model="test",
            messages=[
                ChatMessage(role="system", content="you are helpful"),
                ChatMessage(role="user", content="first"),
                ChatMessage(role="assistant", content="ok"),
                ChatMessage(
                    role="user",
                    content="refactor the module and implement step by step",
                ),
            ],
        )
        decision = self.engine.route_request(req, "vllm")
        assert decision.complexity.value == "complex"
