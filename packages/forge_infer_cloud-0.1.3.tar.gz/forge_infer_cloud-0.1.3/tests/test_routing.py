from forge_cloud.models import ChatCompletionRequest, ChatMessage
from forge_cloud.proxy import ProxyEngine


def _req(content: str) -> ChatCompletionRequest:
    return ChatCompletionRequest(
        model="test",
        messages=[ChatMessage(role="user", content=content)],
    )


class TestRoutingDecisions:
    def setup_method(self):
        self.engine = ProxyEngine()

    def test_simple_factual_query(self):
        decision = self.engine.route_request(_req("What is Python?"), "vllm")
        assert decision.complexity.value == "simple"

    def test_refactor_is_complex(self):
        decision = self.engine.route_request(
            _req("refactor this module to use dependency injection"), "vllm"
        )
        assert decision.complexity.value == "complex"
        assert decision.mode.value == "think"

    def test_debug_is_complex(self):
        decision = self.engine.route_request(
            _req("debug why the server crashes on startup after the refactor"),
            "vllm",
        )
        assert decision.complexity.value == "complex"

    def test_yes_is_simple(self):
        decision = self.engine.route_request(_req("yes"), "vllm")
        assert decision.complexity.value == "simple"
        assert decision.mode.value == "no_think"
        assert decision.sampling_profile == "instruct"

    def test_vllm_sets_nested_flag(self):
        decision = self.engine.route_request(_req("hello"), "vllm")
        assert "chat_template_kwargs" in decision.extra_body

    def test_sglang_sets_nested_flag(self):
        decision = self.engine.route_request(_req("hello"), "sglang")
        assert "chat_template_kwargs" in decision.extra_body

    def test_dashscope_sets_toplevel_flag(self):
        decision = self.engine.route_request(_req("hello"), "dashscope")
        assert "enable_thinking" in decision.extra_body
        assert "chat_template_kwargs" not in decision.extra_body

    def test_llamacpp_sets_chat_template_kwargs(self):
        decision = self.engine.route_request(_req("hello"), "llamacpp")
        assert "chat_template_kwargs" in decision.extra_body

    def test_thinking_profile_has_temp_06(self):
        decision = self.engine.route_request(
            _req("refactor the codebase and implement step by step"), "vllm"
        )
        assert decision.sampling_profile == "thinking"
        assert decision.sampling["temperature"] == 0.6

    def test_instruct_profile_has_temp_07(self):
        decision = self.engine.route_request(_req("yes"), "vllm")
        assert decision.sampling_profile == "instruct"
        assert decision.sampling["temperature"] == 0.7
