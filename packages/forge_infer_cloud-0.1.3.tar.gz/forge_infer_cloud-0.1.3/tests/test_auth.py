from unittest.mock import MagicMock

import pytest
from fastapi import HTTPException

from forge_cloud.auth import _extract_key, authenticate, require_admin


def _make_request(headers: dict) -> MagicMock:
    req = MagicMock()
    req.headers = headers
    return req


def test_extract_bearer_key():
    req = _make_request({"authorization": "Bearer fk-abc123"})
    assert _extract_key(req) == "fk-abc123"


def test_extract_x_api_key():
    req = _make_request({"x-api-key": "fk-xyz"})
    assert _extract_key(req) == "fk-xyz"


def test_extract_missing_key():
    req = _make_request({})
    with pytest.raises(HTTPException) as exc_info:
        _extract_key(req)
    assert exc_info.value.status_code == 401


def test_bearer_takes_precedence():
    req = _make_request(
        {
            "authorization": "Bearer fk-bearer",
            "x-api-key": "fk-header",
        }
    )
    assert _extract_key(req) == "fk-bearer"


@pytest.mark.asyncio
async def test_authenticate_valid(db):
    info = await db.create_api_key(name="auth-test")
    req = _make_request({"authorization": f"Bearer {info.key}"})
    result = await authenticate(req, db)
    assert result.key == info.key


@pytest.mark.asyncio
async def test_authenticate_invalid(db):
    req = _make_request({"authorization": "Bearer fk-invalid"})
    with pytest.raises(HTTPException) as exc_info:
        await authenticate(req, db)
    assert exc_info.value.status_code == 401


def test_require_admin_valid():
    require_admin("secret", "secret")


def test_require_admin_invalid():
    with pytest.raises(HTTPException) as exc_info:
        require_admin("secret", "wrong")
    assert exc_info.value.status_code == 403


def test_require_admin_not_configured():
    with pytest.raises(HTTPException) as exc_info:
        require_admin("", "anything")
    assert exc_info.value.status_code == 503
