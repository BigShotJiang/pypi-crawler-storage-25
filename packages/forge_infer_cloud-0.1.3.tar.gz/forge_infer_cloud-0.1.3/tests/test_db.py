import pytest


@pytest.mark.asyncio
async def test_create_and_get_key(db):
    info = await db.create_api_key(name="test-user", tier="free")
    assert info.key.startswith("fk-")
    assert info.name == "test-user"
    assert info.tier == "free"

    fetched = await db.get_api_key(info.key)
    assert fetched is not None
    assert fetched.key == info.key
    assert fetched.name == "test-user"


@pytest.mark.asyncio
async def test_get_missing_key(db):
    result = await db.get_api_key("fk-nonexistent")
    assert result is None


@pytest.mark.asyncio
async def test_daily_request_count(db):
    info = await db.create_api_key(name="counter-test")
    assert await db.get_daily_request_count(info.key) == 0

    await db.record_usage(info.key, tokens_used=100)
    assert await db.get_daily_request_count(info.key) == 1

    await db.record_usage(info.key, tokens_used=200)
    assert await db.get_daily_request_count(info.key) == 2


@pytest.mark.asyncio
async def test_usage_accumulates(db):
    info = await db.create_api_key(name="accum-test")
    await db.record_usage(
        info.key, tokens_used=50, thinking_tokens=30, response_tokens=20
    )
    await db.record_usage(
        info.key, tokens_used=50, thinking_tokens=10, response_tokens=40
    )
    assert await db.get_daily_request_count(info.key) == 2


@pytest.mark.asyncio
async def test_create_key_with_backend(db):
    info = await db.create_api_key(
        name="custom",
        tier="paid",
        backend_url="http://my-vllm:8000",
        backend_type="sglang",
    )
    assert info.tier == "paid"
    assert info.backend_url == "http://my-vllm:8000"
    assert info.backend_type == "sglang"
