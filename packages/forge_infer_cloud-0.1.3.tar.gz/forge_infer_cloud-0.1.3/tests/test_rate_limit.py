import pytest
from fastapi import HTTPException

from forge_cloud.models import APIKeyInfo
from forge_cloud.rate_limit import check_rate_limit


def _free_key() -> APIKeyInfo:
    return APIKeyInfo(key="fk-free", name="free-user", tier="free")


def _paid_key() -> APIKeyInfo:
    return APIKeyInfo(key="fk-paid", name="paid-user", tier="paid")


@pytest.mark.asyncio
async def test_free_tier_under_limit(db):
    key_info = _free_key()
    await db.create_api_key(name="free-user")
    await check_rate_limit(key_info, db, free_daily_limit=100)


@pytest.mark.asyncio
async def test_free_tier_at_limit(db):
    info = await db.create_api_key(name="limit-test")
    for _ in range(5):
        await db.record_usage(info.key)
    key_info = APIKeyInfo(key=info.key, name="limit-test", tier="free")
    with pytest.raises(HTTPException) as exc_info:
        await check_rate_limit(key_info, db, free_daily_limit=5)
    assert exc_info.value.status_code == 429


@pytest.mark.asyncio
async def test_paid_tier_skips_limit(db):
    key_info = _paid_key()
    await check_rate_limit(key_info, db, free_daily_limit=0)
