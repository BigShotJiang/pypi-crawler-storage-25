from forge_cloud.models import (
    APIKeyCreate,
    APIKeyInfo,
    ChatCompletionRequest,
    ChatMessage,
    ForgeMetadata,
)


def test_chat_message_minimal():
    msg = ChatMessage(role="user", content="hello")
    assert msg.role == "user"
    assert msg.content == "hello"
    assert msg.reasoning_content is None


def test_chat_completion_request_defaults():
    req = ChatCompletionRequest(
        model="test",
        messages=[ChatMessage(role="user", content="hi")],
    )
    assert req.stream is False
    assert req.n == 1
    assert req.forge_auto_route is True


def test_chat_completion_request_allows_extra_fields():
    req = ChatCompletionRequest(
        model="test",
        messages=[ChatMessage(role="user", content="hi")],
        extra_field="ignored_by_proxy",
    )
    assert req.model == "test"


def test_forge_metadata_fields():
    meta = ForgeMetadata(
        thinking_mode="think",
        complexity="complex",
        backend="vllm",
        sampling_profile="thinking",
        thinking_tokens=100,
        response_tokens=200,
    )
    assert meta.thinking_tokens == 100
    assert meta.response_tokens == 200


def test_api_key_info_defaults():
    info = APIKeyInfo(key="fk-abc", name="test")
    assert info.tier == "free"
    assert info.active is True
    assert info.backend_type is None


def test_api_key_create_defaults():
    body = APIKeyCreate(name="my-key")
    assert body.tier == "free"
    assert body.backend_url is None
