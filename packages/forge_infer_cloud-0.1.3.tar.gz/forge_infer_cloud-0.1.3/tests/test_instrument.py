from forge_cloud.instrument import instrument_response


def test_basic_instrumentation():
    data = {
        "choices": [{"message": {"role": "assistant", "content": "hello"}}],
        "usage": {"completion_tokens": 10},
    }
    meta = instrument_response(
        data,
        thinking_mode="no_think",
        complexity="simple",
        backend="vllm",
        sampling_profile="instruct",
    )
    assert meta.thinking_mode == "no_think"
    assert meta.complexity == "simple"
    assert meta.thinking_tokens == 0
    assert meta.response_tokens == 10


def test_thinking_tokens_estimated():
    # estimate_tokens uses max(1, int(len(text) * 0.5))
    # "x" * 200 -> int(200 * 0.5) = 100 estimated tokens
    data = {
        "choices": [
            {
                "message": {
                    "role": "assistant",
                    "content": "answer",
                    "reasoning_content": "x" * 200,
                }
            }
        ],
        "usage": {"completion_tokens": 150},
    }
    meta = instrument_response(
        data,
        thinking_mode="think",
        complexity="complex",
        backend="vllm",
        sampling_profile="thinking",
    )
    assert meta.thinking_tokens == 100
    assert meta.response_tokens == 50


def test_thinking_tokens_capped_to_completion():
    # When estimated thinking tokens exceed completion_tokens,
    # response_tokens floors at 0
    data = {
        "choices": [
            {
                "message": {
                    "role": "assistant",
                    "content": "short",
                    "reasoning_content": "x" * 400,
                }
            }
        ],
        "usage": {"completion_tokens": 50},
    }
    meta = instrument_response(
        data,
        thinking_mode="think",
        complexity="complex",
        backend="vllm",
        sampling_profile="thinking",
    )
    assert meta.thinking_tokens == 200
    assert meta.response_tokens == 0


def test_no_usage_field():
    data = {
        "choices": [{"message": {"role": "assistant", "content": "ok"}}],
    }
    meta = instrument_response(
        data,
        thinking_mode="think",
        complexity="moderate",
        backend="sglang",
        sampling_profile="thinking",
    )
    assert meta.response_tokens == 0


def test_empty_choices():
    meta = instrument_response(
        {"choices": []},
        thinking_mode="no_think",
        complexity="simple",
        backend="dashscope",
        sampling_profile="instruct",
    )
    assert meta.thinking_tokens == 0
    assert meta.response_tokens == 0
