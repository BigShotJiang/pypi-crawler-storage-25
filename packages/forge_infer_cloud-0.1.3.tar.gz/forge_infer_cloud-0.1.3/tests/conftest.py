from __future__ import annotations

import pytest
import pytest_asyncio

from forge_cloud.config import Settings
from forge_cloud.db import Database


@pytest.fixture
def tmp_db_path(tmp_path):
    return str(tmp_path / "test.db")


@pytest.fixture
def test_settings(tmp_db_path):
    return Settings(
        db_path=tmp_db_path,
        backend_url="http://localhost:9999",
        backend_type="vllm",
        admin_key="test-admin-key",
        free_daily_limit=5,
    )


@pytest_asyncio.fixture
async def db(tmp_db_path):
    database = Database(tmp_db_path)
    await database.connect()
    yield database
    await database.close()
