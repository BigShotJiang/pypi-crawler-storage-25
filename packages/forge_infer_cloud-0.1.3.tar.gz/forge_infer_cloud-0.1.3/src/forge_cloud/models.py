from __future__ import annotations

from pydantic import BaseModel


class ChatMessage(BaseModel):
    role: str
    content: str | None = None
    name: str | None = None
    reasoning_content: str | None = None


class ChatCompletionRequest(BaseModel):
    model: str
    messages: list[ChatMessage]
    temperature: float | None = None
    top_p: float | None = None
    n: int = 1
    stream: bool = False
    stop: str | list[str] | None = None
    max_tokens: int | None = None
    presence_penalty: float | None = None
    frequency_penalty: float | None = None
    logit_bias: dict[str, float] | None = None
    user: str | None = None

    forge_auto_route: bool = True

    model_config = {"extra": "allow"}


class ForgeMetadata(BaseModel):
    thinking_mode: str
    complexity: str
    backend: str
    sampling_profile: str
    thinking_tokens: int = 0
    response_tokens: int = 0


class APIKeyInfo(BaseModel):
    key: str
    name: str
    tier: str = "free"
    backend_url: str | None = None
    backend_type: str | None = None
    active: bool = True


class APIKeyCreate(BaseModel):
    name: str
    tier: str = "free"
    backend_url: str | None = None
    backend_type: str | None = None
