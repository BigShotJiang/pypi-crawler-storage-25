from __future__ import annotations

import uvicorn

from .app import create_app
from .config import Settings


def main() -> None:
    cfg = Settings()
    app = create_app(cfg)
    uvicorn.run(app, host=cfg.host, port=cfg.port, log_level="info")


if __name__ == "__main__":
    main()
