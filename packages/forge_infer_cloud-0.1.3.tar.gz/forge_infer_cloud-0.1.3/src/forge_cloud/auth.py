from __future__ import annotations

import hmac
from typing import Optional

from fastapi import HTTPException, Request

from .db import Database
from .models import APIKeyInfo


def _extract_key(request: Request) -> str:
    auth = request.headers.get("authorization", "")
    if auth.startswith("Bearer "):
        return auth[7:].strip()
    key = request.headers.get("x-api-key", "").strip()
    if key:
        return key
    raise HTTPException(status_code=401, detail="Missing API key")


async def authenticate(request: Request, db: Database) -> APIKeyInfo:
    key = _extract_key(request)
    info = await db.get_api_key(key)
    if info is None:
        raise HTTPException(status_code=401, detail="Invalid API key")
    if not info.active:
        raise HTTPException(status_code=403, detail="API key deactivated")
    return info


def require_admin(admin_key: str, provided: Optional[str]) -> None:
    if not admin_key:
        raise HTTPException(status_code=503, detail="Admin key not configured")
    if not hmac.compare_digest(provided or "", admin_key):
        raise HTTPException(status_code=403, detail="Invalid admin key")
