from __future__ import annotations

from fastapi import HTTPException

from .db import Database
from .models import APIKeyInfo


async def check_rate_limit(
    key_info: APIKeyInfo, db: Database, free_daily_limit: int
) -> None:
    if key_info.tier != "free":
        return
    count = await db.get_daily_request_count(key_info.key)
    if count >= free_daily_limit:
        raise HTTPException(
            status_code=429,
            detail=(
                f"Free tier limit reached ({free_daily_limit}/day). "
                "Upgrade for higher limits."
            ),
        )
