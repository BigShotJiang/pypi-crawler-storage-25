from __future__ import annotations

import secrets
from datetime import date

import aiosqlite

from .models import APIKeyInfo

_SCHEMA = """
CREATE TABLE IF NOT EXISTS api_keys (
    key TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    tier TEXT NOT NULL DEFAULT 'free',
    backend_url TEXT,
    backend_type TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    active INTEGER DEFAULT 1
);
CREATE TABLE IF NOT EXISTS usage (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    api_key TEXT NOT NULL,
    date TEXT NOT NULL,
    request_count INTEGER DEFAULT 0,
    tokens_used INTEGER DEFAULT 0,
    thinking_tokens INTEGER DEFAULT 0,
    response_tokens INTEGER DEFAULT 0,
    UNIQUE(api_key, date)
);
"""


class Database:
    def __init__(self, db_path: str) -> None:
        self.db_path = db_path
        self._db: aiosqlite.Connection | None = None

    def _conn(self) -> aiosqlite.Connection:
        if self._db is None:
            raise RuntimeError("Database not connected -- call connect() first")
        return self._db

    async def connect(self) -> None:
        self._db = await aiosqlite.connect(self.db_path)
        self._db.row_factory = aiosqlite.Row
        await self._db.executescript(_SCHEMA)
        await self._db.commit()

    async def close(self) -> None:
        if self._db:
            await self._db.close()
            self._db = None

    async def create_api_key(
        self,
        name: str,
        tier: str = "free",
        backend_url: str | None = None,
        backend_type: str | None = None,
    ) -> APIKeyInfo:
        key = f"fk-{secrets.token_urlsafe(32)}"
        db = self._conn()
        await db.execute(
            "INSERT INTO api_keys (key, name, tier, backend_url, backend_type) "
            "VALUES (?, ?, ?, ?, ?)",
            (key, name, tier, backend_url, backend_type),
        )
        await db.commit()
        return APIKeyInfo(
            key=key,
            name=name,
            tier=tier,
            backend_url=backend_url,
            backend_type=backend_type,
        )

    async def get_api_key(self, key: str) -> APIKeyInfo | None:
        db = self._conn()
        cursor = await db.execute(
            "SELECT key, name, tier, backend_url, backend_type, active "
            "FROM api_keys WHERE key = ?",
            (key,),
        )
        row = await cursor.fetchone()
        if row is None:
            return None
        return APIKeyInfo(
            key=row["key"],
            name=row["name"],
            tier=row["tier"],
            backend_url=row["backend_url"],
            backend_type=row["backend_type"],
            active=bool(row["active"]),
        )

    async def get_daily_request_count(self, key: str) -> int:
        db = self._conn()
        today = date.today().isoformat()
        cursor = await db.execute(
            "SELECT request_count FROM usage WHERE api_key = ? AND date = ?",
            (key, today),
        )
        row = await cursor.fetchone()
        if row is None:
            return 0
        return row["request_count"]

    async def record_usage(
        self,
        key: str,
        tokens_used: int = 0,
        thinking_tokens: int = 0,
        response_tokens: int = 0,
    ) -> None:
        db = self._conn()
        today = date.today().isoformat()
        await db.execute(
            "INSERT INTO usage (api_key, date, request_count, tokens_used, "
            "thinking_tokens, response_tokens) VALUES (?, ?, 1, ?, ?, ?) "
            "ON CONFLICT(api_key, date) DO UPDATE SET "
            "request_count = request_count + 1, "
            "tokens_used = tokens_used + excluded.tokens_used, "
            "thinking_tokens = thinking_tokens + excluded.thinking_tokens, "
            "response_tokens = response_tokens + excluded.response_tokens",
            (key, today, tokens_used, thinking_tokens, response_tokens),
        )
        await db.commit()
