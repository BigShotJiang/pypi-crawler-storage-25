from __future__ import annotations

import json
import logging
from typing import Any, AsyncIterator

import httpx
from qwen_think.backends import get_backend
from qwen_think.router import ComplexityRouter
from qwen_think.sampling import SamplingManager
from qwen_think.types import Backend, Complexity, ThinkingMode

from .instrument import instrument_response
from .models import (
    APIKeyInfo,
    ChatCompletionRequest,
)

logger = logging.getLogger("forge-cloud.proxy")

_OPENAI_TOP_LEVEL = {
    "temperature",
    "top_p",
    "presence_penalty",
    "frequency_penalty",
    "stop",
    "n",
    "seed",
    "logprobs",
    "top_logprobs",
    "logit_bias",
}


class ProxyEngine:
    def __init__(self) -> None:
        self.router = ComplexityRouter()
        self.sampling = SamplingManager()
        self._client: httpx.AsyncClient | None = None

    def _get_client(self, timeout: float) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(timeout=timeout)
        return self._client

    async def close(self) -> None:
        if self._client is not None and not self._client.is_closed:
            await self._client.close()
            self._client = None

    def resolve_backend(self, key_info: APIKeyInfo, fallback_type: str) -> str:
        return key_info.backend_type or fallback_type

    def route_request(
        self,
        request: ChatCompletionRequest,
        backend_type: str,
    ) -> ProxyDecision:
        last_user = ""
        for msg in reversed(request.messages):
            if msg.role == "user" and msg.content:
                last_user = msg.content
                break

        if request.forge_auto_route and last_user:
            context = [
                m.content
                for m in request.messages[-6:]
                if m.content and m.role != "system"
            ]
            decision = self.router.route(last_user, context=context)
            mode = decision.mode
            complexity = decision.complexity
        else:
            mode = ThinkingMode.THINK
            complexity = Complexity.MODERATE

        sampling_config = self.sampling.get_config(mode)
        try:
            backend_enum = Backend(backend_type)
        except ValueError:
            valid = [b.value for b in Backend]
            raise ValueError(
                f"Unsupported backend_type {backend_type!r}. "
                f"Valid options: {valid}"
            )
        backend_instance = get_backend(backend_enum)

        payload = backend_instance.build_payload(
            mode=mode,
            preserve_thinking=mode == ThinkingMode.THINK,
            sampling=sampling_config.to_dict(),
        )

        return ProxyDecision(
            mode=mode,
            complexity=complexity,
            backend_type=backend_type,
            extra_body=payload.extra_body,
            sampling=payload.sampling,
            sampling_profile="thinking" if mode == ThinkingMode.THINK else "instruct",
        )

    def build_upstream_body(
        self,
        request: ChatCompletionRequest,
        decision: ProxyDecision,
    ) -> dict[str, Any]:
        messages = [m.model_dump(exclude_none=True) for m in request.messages]

        top_level: dict[str, Any] = {}
        extra_sampling: dict[str, Any] = {}
        for k, v in decision.sampling.items():
            if k in _OPENAI_TOP_LEVEL:
                top_level[k] = v
            else:
                extra_sampling[k] = v

        if request.temperature is not None:
            top_level["temperature"] = request.temperature
        if request.top_p is not None:
            top_level["top_p"] = request.top_p
        if request.presence_penalty is not None:
            top_level["presence_penalty"] = request.presence_penalty
        if request.frequency_penalty is not None:
            top_level["frequency_penalty"] = request.frequency_penalty
        if request.stop is not None:
            top_level["stop"] = request.stop
        if request.logit_bias is not None:
            top_level["logit_bias"] = request.logit_bias

        extra_body = {**decision.extra_body, **extra_sampling}

        body: dict[str, Any] = {
            "model": request.model,
            "messages": messages,
            "stream": request.stream,
            **top_level,
        }
        if request.max_tokens is not None:
            body["max_tokens"] = request.max_tokens
        if request.n != 1:
            body["n"] = request.n
        if extra_body:
            body["extra_body"] = extra_body

        return body

    async def forward(
        self,
        body: dict[str, Any],
        backend_url: str,
        timeout: float,
    ) -> httpx.Response:
        url = backend_url.rstrip("/") + "/v1/chat/completions"
        client = self._get_client(timeout)
        resp = await client.post(url, json=body)
        resp.raise_for_status()
        return resp

    async def forward_stream(
        self,
        body: dict[str, Any],
        backend_url: str,
        timeout: float,
    ) -> AsyncIterator[bytes]:
        url = backend_url.rstrip("/") + "/v1/chat/completions"
        client = self._get_client(timeout)
        try:
            async with client.stream("POST", url, json=body) as resp:
                resp.raise_for_status()
                async for chunk in resp.aiter_bytes():
                    yield chunk
        except (
            httpx.HTTPStatusError,
            httpx.ConnectError,
            httpx.TimeoutException,
        ) as exc:
            logger.error("Streaming backend error: %s", exc)
            error_event = {
                "error": {
                    "message": "Backend error during streaming",
                    "type": "proxy_error",
                }
            }
            yield f"data: {json.dumps(error_event)}\n\n".encode()

    def build_response(
        self,
        upstream_data: dict[str, Any],
        decision: ProxyDecision,
    ) -> dict[str, Any]:
        metadata = instrument_response(
            upstream_data,
            thinking_mode=decision.mode.value,
            complexity=decision.complexity.value,
            backend=decision.backend_type,
            sampling_profile=decision.sampling_profile,
        )
        upstream_data["forge"] = metadata.model_dump()
        return upstream_data


class ProxyDecision:
    __slots__ = (
        "mode",
        "complexity",
        "backend_type",
        "extra_body",
        "sampling",
        "sampling_profile",
    )

    def __init__(
        self,
        mode: ThinkingMode,
        complexity: Complexity,
        backend_type: str,
        extra_body: dict[str, Any],
        sampling: dict[str, Any],
        sampling_profile: str,
    ) -> None:
        self.mode = mode
        self.complexity = complexity
        self.backend_type = backend_type
        self.extra_body = extra_body
        self.sampling = sampling
        self.sampling_profile = sampling_profile
