from __future__ import annotations

from typing import Any

from qwen_think.budget import estimate_tokens

from .models import ForgeMetadata


def instrument_response(
    response_data: dict[str, Any],
    *,
    thinking_mode: str,
    complexity: str,
    backend: str,
    sampling_profile: str,
) -> ForgeMetadata:
    thinking_tokens = 0
    response_tokens = 0

    usage = response_data.get("usage")
    if usage:
        response_tokens = usage.get("completion_tokens", 0)

    for choice in response_data.get("choices", []):
        msg = choice.get("message", {})
        reasoning = msg.get("reasoning_content")
        if reasoning:
            thinking_tokens += estimate_tokens(reasoning)

    if thinking_tokens > 0:
        response_tokens = max(0, response_tokens - thinking_tokens)

    return ForgeMetadata(
        thinking_mode=thinking_mode,
        complexity=complexity,
        backend=backend,
        sampling_profile=sampling_profile,
        thinking_tokens=thinking_tokens,
        response_tokens=response_tokens,
    )
