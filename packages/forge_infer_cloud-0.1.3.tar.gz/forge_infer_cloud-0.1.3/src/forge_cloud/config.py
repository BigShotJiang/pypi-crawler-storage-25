from __future__ import annotations

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    model_config = {"env_prefix": "FORGE_"}

    host: str = "127.0.0.1"
    port: int = 8741

    db_path: str = "forge.db"

    backend_url: str = "http://localhost:8000"
    backend_type: str = "vllm"

    free_daily_limit: int = 1000

    admin_key: str = ""

    request_timeout: float = 120.0
