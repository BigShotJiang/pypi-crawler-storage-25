"""Allow ``python -m pipeline_sdk <path>``.

Thin shim — the real CLI lives in ``pipeline_sdk.runner``.
"""
from pipeline_sdk.runner import _cli_main

if __name__ == '__main__':
    _cli_main()
