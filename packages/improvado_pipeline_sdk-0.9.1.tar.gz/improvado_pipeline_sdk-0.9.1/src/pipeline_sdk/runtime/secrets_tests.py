"""Tests for read_pipeline_secret — header assembly and JWT injection."""
from __future__ import annotations

import importlib
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from pipeline_sdk.runtime import secrets as secrets_module
from pipeline_sdk.types import PipelineCredentials


_CREDS = PipelineCredentials(
    secret_path='custom-pipelines/run-1',
    vault_token='hvs.test-vault-token',
    s3_bucket='bucket',
    s3_prefix='prefix',
)

_VAULT_RESPONSE = {
    'data': {
        'data': {
            'connections': {'pg': {'host': 'localhost'}},
            'storage': {
                'host': 'http://ch:8123',
                'database': 'db',
                'user': 'u',
                'password': 'p',
            },
            'dts_session_id': 'sess-1',
            's3': {
                'access_key': 'ak',
                'secret_key': 'sk',
                'session_token': 'st',
                'bucket': 'bkt',
                'prefix': 'pfx',
            },
        }
    }
}


def _make_mock_session(body: dict):
    resp = AsyncMock()
    resp.raise_for_status = MagicMock()
    resp.json = AsyncMock(return_value=body)

    get_ctx = MagicMock()
    get_ctx.__aenter__ = AsyncMock(return_value=resp)
    get_ctx.__aexit__ = AsyncMock(return_value=False)

    session = MagicMock()
    session.get = MagicMock(return_value=get_ctx)

    session_ctx = MagicMock()
    session_ctx.__aenter__ = AsyncMock(return_value=session)
    session_ctx.__aexit__ = AsyncMock(return_value=False)

    return session_ctx, session


@pytest.mark.asyncio
async def test_no_jwt_sends_only_vault_token() -> None:
    original = secrets_module.VAULT_AUTH_JWT
    secrets_module.VAULT_AUTH_JWT = ''
    try:
        session_ctx, session = _make_mock_session(_VAULT_RESPONSE)
        with patch('aiohttp.ClientSession', return_value=session_ctx):
            await secrets_module.read_pipeline_secret(_CREDS)
        call_headers = session.get.call_args.kwargs['headers']
        assert 'X-Vault-Token' in call_headers
        assert 'Authorization' not in call_headers
    finally:
        secrets_module.VAULT_AUTH_JWT = original


@pytest.mark.asyncio
async def test_with_jwt_sends_bearer_and_vault_token() -> None:
    original = secrets_module.VAULT_AUTH_JWT
    secrets_module.VAULT_AUTH_JWT = 'test.jwt.token'
    try:
        session_ctx, session = _make_mock_session(_VAULT_RESPONSE)
        with patch('aiohttp.ClientSession', return_value=session_ctx):
            await secrets_module.read_pipeline_secret(_CREDS)
        call_headers = session.get.call_args.kwargs['headers']
        assert call_headers['X-Vault-Token'] == _CREDS.vault_token
        assert call_headers['Authorization'] == 'Bearer test.jwt.token'
    finally:
        secrets_module.VAULT_AUTH_JWT = original


def test_vault_auth_jwt_env_override(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv('VAULT_AUTH_JWT', 'env.jwt.value')
    reloaded = importlib.reload(secrets_module)
    try:
        assert reloaded.VAULT_AUTH_JWT == 'env.jwt.value'
    finally:
        monkeypatch.delenv('VAULT_AUTH_JWT', raising=False)
        importlib.reload(secrets_module)


def test_vault_auth_jwt_falls_back_to_temporal_jwt(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.delenv('VAULT_AUTH_JWT', raising=False)
    monkeypatch.setenv('TEMPORAL_AUTH_JWT', 'temporal.jwt.value')
    reloaded = importlib.reload(secrets_module)
    try:
        assert reloaded.VAULT_AUTH_JWT == 'temporal.jwt.value'
    finally:
        importlib.reload(secrets_module)


def test_vault_auth_jwt_override_takes_precedence(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv('VAULT_AUTH_JWT', 'vault.specific.jwt')
    monkeypatch.setenv('TEMPORAL_AUTH_JWT', 'temporal.jwt.value')
    reloaded = importlib.reload(secrets_module)
    try:
        assert reloaded.VAULT_AUTH_JWT == 'vault.specific.jwt'
    finally:
        importlib.reload(secrets_module)


def test_vault_auth_jwt_empty_when_neither_set(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.delenv('VAULT_AUTH_JWT', raising=False)
    monkeypatch.delenv('TEMPORAL_AUTH_JWT', raising=False)
    reloaded = importlib.reload(secrets_module)
    try:
        assert reloaded.VAULT_AUTH_JWT == ''
    finally:
        importlib.reload(secrets_module)
