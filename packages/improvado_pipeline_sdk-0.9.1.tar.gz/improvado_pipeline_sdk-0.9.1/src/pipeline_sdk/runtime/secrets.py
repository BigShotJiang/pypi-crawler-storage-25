"""Vault secret reader — activity-side.

``read_pipeline_secret`` fetches the full pipeline secret from Vault
using the token from ``PipelineCredentials``. Call from
``@activity.defn`` code only — this performs I/O.

``VAULT_ADDR`` / ``VAULT_MOUNT_POINT`` / ``VAULT_AUTH_JWT`` are
module-level constants initialized from environment variables. They
can be overridden via env var before import, or reassigned directly
in tests.

When ``VAULT_AUTH_JWT`` is non-empty the request carries both the
scoped Vault token (``X-Vault-Token``) *and* ``Authorization: Bearer``
— required when Vault is proxied through an nginx gateway that
validates JWT on ingress.  Falls back to ``TEMPORAL_AUTH_JWT`` so
no extra config is needed in the common case.
"""

from __future__ import annotations

import os

import aiohttp

from pipeline_sdk.types import (
    PipelineSecret,
    S3Credentials,
    StorageCredentials,
    PipelineCredentials,
)

VAULT_ADDR = os.getenv('VAULT_ADDR', 'http://vault:8200')
VAULT_MOUNT_POINT = os.getenv(
    'VAULT_AI_AGENT_MOUNT_POINT',
    'ai_agent',
)
# JWT for the nginx gateway in front of Vault.  Falls back to
# TEMPORAL_AUTH_JWT so the runner only needs one token in the
# common case; set VAULT_AUTH_JWT explicitly to override.
VAULT_AUTH_JWT = os.getenv('VAULT_AUTH_JWT') or os.getenv('TEMPORAL_AUTH_JWT', '')


async def read_pipeline_secret(
    creds: PipelineCredentials,
) -> PipelineSecret:
    """Read the full pipeline secret from Vault.

    Call from activity code only (performs I/O).
    """
    url = f'{VAULT_ADDR}/v1/{VAULT_MOUNT_POINT}/data/{creds.secret_path}'
    headers: dict[str, str] = {'X-Vault-Token': creds.vault_token}
    if VAULT_AUTH_JWT:
        headers['Authorization'] = f'Bearer {VAULT_AUTH_JWT}'

    timeout = aiohttp.ClientTimeout(total=30)
    async with aiohttp.ClientSession(timeout=timeout) as session:
        async with session.get(url, headers=headers) as resp:
            resp.raise_for_status()
            body = await resp.json()

    data = body['data']['data']

    return PipelineSecret(
        connections=data['connections'],
        storage=StorageCredentials(**data['storage']),
        dts_session_id=data['dts_session_id'],
        s3=S3Credentials(**data['s3']),
    )


__all__ = ['read_pipeline_secret', 'VAULT_ADDR', 'VAULT_MOUNT_POINT', 'VAULT_AUTH_JWT']
