"""Local runner for custom pipelines against production Temporal.

Two modes:

1. **One-shot** (default) — discover workflows from a file or
   directory, spin up a worker on the tenant queue, start the
   workflow, wait for the result, print, exit::

       python -m pipeline_sdk hello_sdk.py
       python -m pipeline_sdk hello_sdk.py --params '{"label": "hi"}'
       python -m pipeline_sdk ./pipelines/ --name HelloSdkWorkflow

2. **Worker-only** (long-running) — same discovery + worker, but
   never starts the workflow itself; trigger via Workflow Manager
   API or Temporal CLI::

       python -m pipeline_sdk ./pipelines/ --worker-only

Both modes need the same env vars:

    TEMPORAL_API_URL=flow-api.tools.improvado.io:443
    TEMPORAL_AUTH_JWT=$(cat /tmp/token)
    TENANT_AGENCY_UUID=fc010783-...
    TENANT_WORKSPACE_ID=42
    # optional: TENANT_USER_ID, TEMPORAL_TLS=false (debug),
    #           VAULT_ADDR / VAULT_MOUNT_POINT / VAULT_AUTH_JWT

Cross-queue activities (``les_extract``, ``ch_load``,
``prepare_credentials``) are dispatched to Improvado shared queues
and execute on Improvado infra; activities defined in your file
host on the laptop. See ADR-004 §"Local Runner".

This module performs I/O on import — never import it from inside
``@workflow.defn`` code.
"""

from __future__ import annotations

import argparse
import asyncio
import dataclasses
import importlib.util
import inspect
import json
import logging
import os
import signal
import sys
import typing
import uuid
from pathlib import Path
from typing import Any, Callable

from temporalio.client import Client
from temporalio.worker import Worker

from pipeline_sdk.tenant import (
    TenantClientInterceptor,
    TenantInterceptor,
    make_task_queue,
)
from pipeline_sdk.types import TenantID

logger = logging.getLogger('pipeline_sdk.runner')

_REQUIRED_ENV = (
    'TEMPORAL_API_URL',
    'TEMPORAL_AUTH_JWT',
    'TENANT_AGENCY_UUID',
    'TENANT_WORKSPACE_ID',
)


# ── Configuration ──────────────────────────────────────────────────


@dataclasses.dataclass(frozen=True)
class LocalRunnerConfig:
    """Resolved configuration for a local pipeline runner."""

    temporal_api_url: str
    temporal_auth_jwt: str
    tenant: TenantID
    pipeline_path: Path
    tls: bool = True

    # Backward compat: old code/tests called the field
    # ``pipeline_dir``; keep it as an alias property.
    @property
    def pipeline_dir(self) -> Path:
        return self.pipeline_path

    @classmethod
    def from_env(
        cls,
        env: dict[str, str] | None = None,
        pipeline_path_override: Path | None = None,
    ) -> LocalRunnerConfig:
        """Build a config from environment variables.

        Raises ``ValueError`` listing every missing required variable
        in one message — the runner is a CLI, callers want to see all
        problems at once instead of fixing them one by one.

        ``pipeline_path_override`` (typically the CLI positional arg)
        wins over the ``PIPELINE_LOCAL_DIR`` env var. At least one of
        the two must be set.
        """
        env = dict(os.environ if env is None else env)

        missing = [k for k in _REQUIRED_ENV if not env.get(k)]
        pipeline_path_raw = (
            str(pipeline_path_override)
            if pipeline_path_override is not None
            else env.get('PIPELINE_LOCAL_DIR') or ''
        )
        if not pipeline_path_raw:
            missing.append('PIPELINE_LOCAL_DIR (or positional path)')
        if missing:
            raise ValueError(
                'Missing required env vars: '
                + ', '.join(missing)
                + '. See pipeline_sdk.runner module docstring.',
            )

        try:
            workspace_id = int(env['TENANT_WORKSPACE_ID'])
        except ValueError as exc:
            raise ValueError(
                f'TENANT_WORKSPACE_ID must be int, '
                f'got {env["TENANT_WORKSPACE_ID"]!r}',
            ) from exc

        user_id_raw = env.get('TENANT_USER_ID')
        user_id: int | None
        if user_id_raw is None or user_id_raw == '':
            user_id = None
        else:
            try:
                user_id = int(user_id_raw)
            except ValueError as exc:
                raise ValueError(
                    f'TENANT_USER_ID must be int or unset, '
                    f'got {user_id_raw!r}',
                ) from exc

        tls_raw = env.get('TEMPORAL_TLS', 'true').strip().lower()
        if tls_raw in ('1', 'true', 'yes', 'on'):
            tls = True
        elif tls_raw in ('0', 'false', 'no', 'off'):
            tls = False
        else:
            raise ValueError(
                f'TEMPORAL_TLS must be true/false, got {tls_raw!r}',
            )

        return cls(
            temporal_api_url=env['TEMPORAL_API_URL'],
            temporal_auth_jwt=env['TEMPORAL_AUTH_JWT'],
            tenant=TenantID(
                agency_uuid=env['TENANT_AGENCY_UUID'],
                workspace_id=workspace_id,
                user_id=user_id,
            ),
            pipeline_path=Path(pipeline_path_raw),
            tls=tls,
        )


# ── Discovery ──────────────────────────────────────────────────────


def _import_file(py_file: Path) -> Any | None:
    module_name = f'_pipeline_sdk_local_{py_file.stem}'
    spec = importlib.util.spec_from_file_location(module_name, py_file)
    if spec is None or spec.loader is None:
        logger.warning('Skipping %s: cannot build import spec', py_file)
        return None
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


def _discover(
    pipeline_path: Path,
) -> tuple[list[type], list[Callable]]:
    """Import workflow source and pull out workflow / activity defs.

    ``pipeline_path`` may be a single ``.py`` file or a directory
    containing ``*.py`` files. Other shapes raise ``ValueError``.
    """
    if not pipeline_path.exists():
        raise ValueError(f'Path does not exist: {pipeline_path}')

    if pipeline_path.is_file():
        if pipeline_path.suffix != '.py':
            raise ValueError(
                f'Not a Python file: {pipeline_path}',
            )
        py_files: list[Path] = [pipeline_path]
    elif pipeline_path.is_dir():
        py_files = sorted(pipeline_path.glob('*.py'))
        if not py_files:
            raise ValueError(
                f'No .py files found in {pipeline_path}',
            )
    else:
        raise ValueError(
            f'Path is neither a file nor a directory: {pipeline_path}',
        )

    workflows: list[type] = []
    activities: list[Callable] = []
    seen_workflow_names: set[str] = set()
    seen_activity_names: set[str] = set()

    for py_file in py_files:
        module = _import_file(py_file)
        if module is None:
            continue

        for _, obj in inspect.getmembers(module, inspect.isclass):
            defn = getattr(obj, '__temporal_workflow_definition', None)
            if defn is None:
                continue
            name = getattr(defn, 'name', obj.__name__)
            if name in seen_workflow_names:
                logger.warning(
                    'Duplicate workflow name %r — using first occurrence',
                    name,
                )
                continue
            seen_workflow_names.add(name)
            workflows.append(obj)

        for _, obj in inspect.getmembers(module, inspect.isfunction):
            defn = getattr(obj, '__temporal_activity_definition', None)
            if defn is None:
                continue
            name = getattr(defn, 'name', obj.__name__)
            if name in seen_activity_names:
                continue
            seen_activity_names.add(name)
            activities.append(obj)

    return workflows, activities


def _workflow_name(wf_class: type) -> str:
    defn = getattr(wf_class, '__temporal_workflow_definition')
    return getattr(defn, 'name', wf_class.__name__)


def _select_workflow(
    workflows: list[type],
    requested_name: str | None,
) -> type:
    if not workflows:
        raise ValueError(
            'No @workflow.defn classes discovered. Ensure your workflow '
            'is decorated with @workflow.defn(sandboxed=False, ...).',
        )
    if requested_name is None:
        if len(workflows) > 1:
            names = sorted(_workflow_name(w) for w in workflows)
            raise ValueError(
                f'Multiple workflows discovered ({names}); '
                f'pass --name to pick one.',
            )
        return workflows[0]
    for wf in workflows:
        if _workflow_name(wf) == requested_name:
            return wf
    raise ValueError(
        f'Workflow {requested_name!r} not found. Available: '
        f'{sorted(_workflow_name(w) for w in workflows)}',
    )


def _build_workflow_arg(wf_class: type, params_json: str) -> Any:
    """Parse JSON and coerce to the workflow's first run-arg type.

    If the workflow's ``run`` method takes a frozen dataclass param,
    we instantiate it from the JSON dict (keys map 1:1 to fields).
    Otherwise the parsed value is passed straight through. Empty JSON
    means "no positional arg".
    """
    if not params_json or params_json.strip() == '':
        params_json = '{}'
    try:
        parsed = json.loads(params_json)
    except json.JSONDecodeError as exc:
        raise ValueError(
            f'--params is not valid JSON: {exc}',
        ) from exc

    run_fn = getattr(wf_class, 'run', None)
    if run_fn is None:
        return parsed
    sig = inspect.signature(run_fn)
    args = [
        (n, p) for n, p in sig.parameters.items()
        if n != 'self' and p.kind in (
            inspect.Parameter.POSITIONAL_OR_KEYWORD,
            inspect.Parameter.POSITIONAL_ONLY,
        )
    ]
    if not args:
        return None
    arg_name, arg_param = args[0]
    if arg_param.annotation is inspect.Parameter.empty:
        return parsed
    # Resolve string-form annotations (``from __future__ import
    # annotations`` in the workflow file) to the live class object.
    try:
        resolved = typing.get_type_hints(run_fn)
        target_type = resolved.get(arg_name, arg_param.annotation)
    except Exception:
        target_type = arg_param.annotation
    if dataclasses.is_dataclass(target_type) and isinstance(parsed, dict):
        return target_type(**parsed)
    return parsed


# ── Connection / worker ────────────────────────────────────────────


async def _connect(
    cfg: LocalRunnerConfig,
    interceptors: list | None = None,
) -> Client:
    """Connect to Temporal in the tenant's namespace with JWT auth.

    ADR-009 §5: ``api_key`` is TLS-only; on plaintext we have to set
    ``client.rpc_metadata`` post-connect. Production endpoint is TLS;
    plaintext is debug-only against a local docker-compose Temporal.
    """
    namespace = cfg.tenant.to_namespace()
    if cfg.tls:
        return await Client.connect(
            cfg.temporal_api_url,
            namespace=namespace,
            tls=True,
            api_key=cfg.temporal_auth_jwt,
            interceptors=interceptors or [],
        )
    client = await Client.connect(
        cfg.temporal_api_url,
        namespace=namespace,
        interceptors=interceptors or [],
    )
    client.rpc_metadata = {
        'authorization': f'Bearer {cfg.temporal_auth_jwt}',
    }
    return client


def _make_worker(
    client: Client,
    task_queue: str,
    workflows: list[type],
    activities: list[Callable],
) -> Worker:
    return Worker(
        client,
        task_queue=task_queue,
        workflows=workflows,
        activities=activities,
        interceptors=[TenantInterceptor()],
        # Symmetric with src/custom_pipelines/tenant_workflow_worker.py:
        # any unhandled exception becomes an execution failure (capped
        # by DEFAULT_TENANT_RETRY_POLICY) instead of looping as a
        # Workflow Task Failure forever.
        workflow_failure_exception_types=[Exception],
    )


def _install_signal_handlers(stop_event: asyncio.Event) -> None:
    loop = asyncio.get_running_loop()

    def _request_stop() -> None:
        if not stop_event.is_set():
            logger.info('Shutdown signal received — draining worker')
            stop_event.set()

    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, _request_stop)
        except NotImplementedError:
            pass


async def run_local_worker(
    cfg: LocalRunnerConfig,
    start_timeout_seconds: float = 30.0,
) -> None:
    """Run a Temporal Worker on the tenant queue until interrupted.

    Same manual ``create_task`` + ``cancel`` lifecycle as
    ``run_local_oneshot`` so a bogus / expired JWT or unreachable
    server doesn't hang on Ctrl-C: ``async with worker`` /
    ``worker.shutdown()`` waits for in-flight RPCs to drain, which
    never completes when Rust Core is stuck retrying ``PermissionDenied``.
    ``start_timeout_seconds`` bounds the initial connect.
    """
    workflows, activities = _discover(cfg.pipeline_path)
    if not workflows and not activities:
        raise ValueError(
            f'No @workflow.defn / @activity.defn objects found in '
            f'{cfg.pipeline_path}.',
        )

    try:
        client = await asyncio.wait_for(
            _connect(cfg), timeout=start_timeout_seconds,
        )
    except asyncio.TimeoutError as exc:
        raise ValueError(
            f'Connect to Temporal at {cfg.temporal_api_url} timed out '
            f'after {start_timeout_seconds}s. Likely causes: server '
            f'unreachable, JWT rejected (server retries silently), '
            f'or namespace {cfg.tenant.to_namespace()!r} does not '
            f'exist for this tenant.',
        ) from exc

    task_queue = make_task_queue(cfg.tenant)

    logger.info(
        'Starting local worker: namespace=%s task_queue=%s '
        'workflows=%d activities=%d path=%s',
        cfg.tenant.to_namespace(), task_queue,
        len(workflows), len(activities), cfg.pipeline_path,
    )

    worker = _make_worker(client, task_queue, workflows, activities)
    stop_event = asyncio.Event()
    _install_signal_handlers(stop_event)

    worker_task = asyncio.create_task(worker.run())
    try:
        # Race the stop signal against the worker task itself so we
        # surface a connection / poll-time failure (e.g. JWT rejected
        # mid-flight) instead of waiting forever for a Ctrl-C that
        # would never let us recover.
        stop_wait = asyncio.create_task(stop_event.wait())
        done, _ = await asyncio.wait(
            {stop_wait, worker_task},
            return_when=asyncio.FIRST_COMPLETED,
        )
        stop_wait.cancel()
        if worker_task in done and not worker_task.cancelled():
            # Re-raise the worker's exception (or noop on clean exit).
            worker_task.result()
    finally:
        worker_task.cancel()
        try:
            await asyncio.wait_for(worker_task, timeout=5)
        except (asyncio.TimeoutError, asyncio.CancelledError, Exception):
            pass


async def run_local_oneshot(
    cfg: LocalRunnerConfig,
    workflow_name: str | None,
    params_json: str,
    timeout_seconds: float,
    workflow_id: str | None = None,
    start_timeout_seconds: float = 30.0,
) -> Any:
    """Spin up a worker, start a single workflow, return its result.

    The worker is torn down once the workflow completes (or either
    timeout fires). ``start_timeout_seconds`` covers connect +
    StartWorkflowExecution — keeps the CLI from hanging when the
    server rejects the JWT and the Rust Core silently retries.
    Used by the default CLI mode.
    """
    workflows, activities = _discover(cfg.pipeline_path)
    if not workflows:
        raise ValueError(
            f'No @workflow.defn classes discovered in {cfg.pipeline_path}.',
        )
    wf_class = _select_workflow(workflows, workflow_name)
    wf_name = _workflow_name(wf_class)
    arg = _build_workflow_arg(wf_class, params_json)

    # Two clients so we can both run the worker (no client-side
    # interceptor — ``TenantInterceptor`` is the worker side) AND
    # start the workflow with TenantClientInterceptor injecting the
    # ``x-tenant-id`` header into the StartWorkflowExecution request.
    try:
        worker_client = await asyncio.wait_for(
            _connect(cfg), timeout=start_timeout_seconds,
        )
        starter_client = await asyncio.wait_for(
            _connect(
                cfg,
                interceptors=[TenantClientInterceptor(cfg.tenant)],
            ),
            timeout=start_timeout_seconds,
        )
    except asyncio.TimeoutError as exc:
        raise ValueError(
            f'Connect to Temporal at {cfg.temporal_api_url} timed out '
            f'after {start_timeout_seconds}s. Likely causes: server '
            f'unreachable, JWT rejected (server retries silently), '
            f'or namespace {cfg.tenant.to_namespace()!r} does not '
            f'exist for this tenant.',
        ) from exc

    task_queue = make_task_queue(cfg.tenant)
    if workflow_id is None:
        workflow_id = (
            f'{task_queue}-{wf_name}-{uuid.uuid4().hex[:8]}'
        )

    logger.info(
        'One-shot: namespace=%s task_queue=%s workflow=%s id=%s',
        cfg.tenant.to_namespace(), task_queue, wf_name, workflow_id,
    )

    worker = _make_worker(
        worker_client, task_queue, workflows, activities,
    )

    async def _start() -> Any:
        if arg is None:
            return await starter_client.start_workflow(
                wf_name, id=workflow_id, task_queue=task_queue,
            )
        return await starter_client.start_workflow(
            wf_name, arg, id=workflow_id, task_queue=task_queue,
        )

    # Manual worker lifecycle — ``async with worker`` would call
    # ``worker.shutdown()`` on exit, which itself blocks until every
    # in-flight RPC drains. With a rejected JWT that drain never
    # completes (Rust Core retries on PermissionDenied), so the
    # process hangs even after our wait_for fires. Driving the worker
    # as a cancelable task lets us bound shutdown unconditionally.
    worker_task = asyncio.create_task(worker.run())
    try:
        try:
            handle = await asyncio.wait_for(
                _start(), timeout=start_timeout_seconds,
            )
        except asyncio.TimeoutError as exc:
            raise ValueError(
                f'StartWorkflowExecution timed out after '
                f'{start_timeout_seconds}s. Server is reachable but '
                f'is rejecting the call — most often: JWT lacks '
                f'permission for namespace '
                f'{cfg.tenant.to_namespace()!r}, or the namespace '
                f'does not exist. Run the same command with '
                f'LOG_LEVEL=DEBUG to see the underlying gRPC error.',
            ) from exc
        logger.info('Started run_id=%s', handle.first_execution_run_id)
        return await asyncio.wait_for(handle.result(), timeout_seconds)
    finally:
        worker_task.cancel()
        try:
            await asyncio.wait_for(worker_task, timeout=5)
        except (asyncio.TimeoutError, asyncio.CancelledError, Exception):
            pass


# ── CLI ────────────────────────────────────────────────────────────


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog='improvado-pipeline-run',
        description=(
            'Run a custom pipeline locally against a production '
            'Temporal under your tenant identity. Default mode: '
            'one-shot (start workflow, wait, print, exit). Use '
            '--worker-only for long-running worker.'
        ),
    )
    p.add_argument(
        'pipeline_path',
        nargs='?',
        type=Path,
        help=(
            'Path to a .py file or directory of .py files. Falls '
            'back to the PIPELINE_LOCAL_DIR env var.'
        ),
    )
    p.add_argument(
        '--name',
        dest='workflow_name',
        help='Workflow class name (omit if file has exactly one).',
    )
    p.add_argument(
        '--params',
        default='{}',
        help='JSON object passed as the workflow input (default: {}).',
    )
    p.add_argument(
        '--params-file',
        type=Path,
        help='Read JSON params from a file (overrides --params).',
    )
    p.add_argument(
        '--timeout',
        type=float,
        default=300.0,
        help='One-shot result wait timeout, seconds (default: 300).',
    )
    p.add_argument(
        '--start-timeout',
        type=float,
        default=30.0,
        help=(
            'Connect + StartWorkflowExecution timeout, seconds '
            '(default: 30). Bounds bogus-JWT silent-retry hangs.'
        ),
    )
    p.add_argument(
        '--workflow-id',
        help='Override generated workflow_id (useful for retries).',
    )
    p.add_argument(
        '--worker-only',
        action='store_true',
        help=(
            'Long-running mode — register worker on tenant queue and '
            'wait for SIGINT/SIGTERM. Trigger workflow via WM API or '
            'Temporal CLI.'
        ),
    )
    return p


async def main(argv: list[str] | None = None) -> int:
    logging.basicConfig(
        level=os.environ.get('LOG_LEVEL', 'INFO'),
        format='%(asctime)s %(levelname)s %(name)s %(message)s',
    )
    args = _build_parser().parse_args(argv)
    cfg = LocalRunnerConfig.from_env(
        pipeline_path_override=args.pipeline_path,
    )

    if args.worker_only:
        await run_local_worker(
            cfg, start_timeout_seconds=args.start_timeout,
        )
        return 0

    params_json = args.params
    if args.params_file is not None:
        params_json = args.params_file.read_text()

    result = await run_local_oneshot(
        cfg,
        workflow_name=args.workflow_name,
        params_json=params_json,
        timeout_seconds=args.timeout,
        workflow_id=args.workflow_id,
        start_timeout_seconds=args.start_timeout,
    )
    print(json.dumps(_jsonable(result), indent=2, default=str))
    return 0


def _jsonable(value: Any) -> Any:
    """Make ``value`` JSON-serializable for the CLI's stdout print.

    Workflow results may be plain dicts / lists / scalars (the common
    case from auto-converted dataclasses), but a custom DataConverter
    can hand back a dataclass directly.
    """
    if dataclasses.is_dataclass(value) and not isinstance(value, type):
        return dataclasses.asdict(value)
    if isinstance(value, dict):
        return {k: _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(v) for v in value]
    return value


def _cli_main() -> None:
    """Console-script entry (``improvado-pipeline-run``)."""
    try:
        rc = asyncio.run(main())
        sys.exit(rc or 0)
    except KeyboardInterrupt:
        sys.exit(130)
    except ValueError as exc:
        print(f'error: {exc}', file=sys.stderr)
        sys.exit(2)


if __name__ == '__main__':
    _cli_main()


__all__ = [
    'LocalRunnerConfig',
    'run_local_worker',
    'run_local_oneshot',
    'main',
]
