"""Unit tests for ``pipeline_sdk.runner`` config / discovery / CLI parser.

Networked paths (``Client.connect``, ``Worker.run``) are exercised
end-to-end manually against a real Temporal — see ADR-004 §"Local
Runner — Verification". This file covers env parsing, filesystem
discovery, workflow-arg coercion, and CLI flag parsing only.
"""
from __future__ import annotations

import dataclasses
from pathlib import Path

import pytest

from pipeline_sdk.runner import (
    LocalRunnerConfig,
    _REQUIRED_ENV,
    _build_parser,
    _build_workflow_arg,
    _discover,
    _select_workflow,
    _workflow_name,
)
from pipeline_sdk.types import TenantID


def _base_env(**overrides: str) -> dict[str, str]:
    env = {
        'TEMPORAL_API_URL': 'flow-api.tools.improvado.io:443',
        'TEMPORAL_AUTH_JWT': 'eyJ.fake.token',
        'TENANT_AGENCY_UUID': 'fc010783-7a09-449b-84ab-0c1660b15245',
        'TENANT_WORKSPACE_ID': '42',
        'PIPELINE_LOCAL_DIR': './pipelines',
    }
    env.update(overrides)
    return env


# ── Config ─────────────────────────────────────────────────────────


def test_from_env_happy_path() -> None:
    cfg = LocalRunnerConfig.from_env(_base_env())

    assert cfg.temporal_api_url == 'flow-api.tools.improvado.io:443'
    assert cfg.temporal_auth_jwt == 'eyJ.fake.token'
    assert cfg.tenant == TenantID(
        agency_uuid='fc010783-7a09-449b-84ab-0c1660b15245',
        workspace_id=42,
    )
    assert cfg.pipeline_path == Path('./pipelines')
    assert cfg.pipeline_dir == Path('./pipelines')  # back-compat alias
    assert cfg.tls is True


def test_from_env_pipeline_path_override_wins(tmp_path: Path) -> None:
    cfg = LocalRunnerConfig.from_env(
        _base_env(PIPELINE_LOCAL_DIR='./should-be-ignored'),
        pipeline_path_override=tmp_path / 'flow.py',
    )

    assert cfg.pipeline_path == tmp_path / 'flow.py'


def test_from_env_pipeline_path_override_replaces_missing_env() -> None:
    env = _base_env()
    env.pop('PIPELINE_LOCAL_DIR')

    cfg = LocalRunnerConfig.from_env(
        env, pipeline_path_override=Path('flow.py'),
    )

    assert cfg.pipeline_path == Path('flow.py')


@pytest.mark.parametrize('missing_var', _REQUIRED_ENV)
def test_from_env_lists_missing_required_var(missing_var: str) -> None:
    env = _base_env()
    env.pop(missing_var)

    with pytest.raises(ValueError, match=missing_var):
        LocalRunnerConfig.from_env(env)


def test_from_env_no_pipeline_path_or_dir() -> None:
    env = _base_env()
    env.pop('PIPELINE_LOCAL_DIR')

    with pytest.raises(ValueError, match='PIPELINE_LOCAL_DIR'):
        LocalRunnerConfig.from_env(env)


def test_from_env_lists_all_missing_at_once() -> None:
    """Surfaces every problem in one error so the dev fixes once."""
    with pytest.raises(ValueError) as excinfo:
        LocalRunnerConfig.from_env({})

    msg = str(excinfo.value)
    for var in _REQUIRED_ENV:
        assert var in msg


def test_from_env_workspace_id_must_be_int() -> None:
    with pytest.raises(ValueError, match='TENANT_WORKSPACE_ID'):
        LocalRunnerConfig.from_env(
            _base_env(TENANT_WORKSPACE_ID='not-an-int'),
        )


def test_from_env_user_id_optional_when_absent() -> None:
    cfg = LocalRunnerConfig.from_env(_base_env())

    assert cfg.tenant.user_id is None


def test_from_env_user_id_optional_when_blank() -> None:
    cfg = LocalRunnerConfig.from_env(_base_env(TENANT_USER_ID=''))

    assert cfg.tenant.user_id is None


def test_from_env_user_id_parsed_to_int() -> None:
    cfg = LocalRunnerConfig.from_env(_base_env(TENANT_USER_ID='99'))

    assert cfg.tenant.user_id == 99


def test_from_env_user_id_must_be_int() -> None:
    with pytest.raises(ValueError, match='TENANT_USER_ID'):
        LocalRunnerConfig.from_env(_base_env(TENANT_USER_ID='not-int'))


@pytest.mark.parametrize(
    'value,expected',
    [
        ('true', True), ('TRUE', True), ('1', True), ('yes', True),
        ('false', False), ('FALSE', False), ('0', False), ('no', False),
    ],
)
def test_from_env_tls_flag(value: str, expected: bool) -> None:
    cfg = LocalRunnerConfig.from_env(_base_env(TEMPORAL_TLS=value))

    assert cfg.tls is expected


def test_from_env_tls_default_true() -> None:
    cfg = LocalRunnerConfig.from_env(_base_env())

    assert cfg.tls is True


def test_from_env_tls_invalid_value() -> None:
    with pytest.raises(ValueError, match='TEMPORAL_TLS'):
        LocalRunnerConfig.from_env(_base_env(TEMPORAL_TLS='maybe'))


# ── Discovery ──────────────────────────────────────────────────────


_SAMPLE_WORKFLOW = (
    'from temporalio import workflow, activity\n'
    '\n'
    '@activity.defn\n'
    'async def my_activity() -> int:\n'
    '    return 1\n'
    '\n'
    '@workflow.defn(sandboxed=False, name="MyPipeline")\n'
    'class MyPipeline:\n'
    '    @workflow.run\n'
    '    async def run(self) -> int:\n'
    '        return 1\n'
)


def test_discover_missing_path(tmp_path: Path) -> None:
    with pytest.raises(ValueError, match='does not exist'):
        _discover(tmp_path / 'no-such')


def test_discover_empty_dir(tmp_path: Path) -> None:
    with pytest.raises(ValueError, match='No .py files'):
        _discover(tmp_path)


def test_discover_non_py_file(tmp_path: Path) -> None:
    f = tmp_path / 'something.txt'
    f.write_text('')

    with pytest.raises(ValueError, match='Not a Python file'):
        _discover(f)


def test_discover_directory(tmp_path: Path) -> None:
    (tmp_path / 'sample.py').write_text(_SAMPLE_WORKFLOW)

    workflows, activities = _discover(tmp_path)

    assert _workflow_name(workflows[0]) == 'MyPipeline'
    assert len(activities) == 1


def test_discover_single_file(tmp_path: Path) -> None:
    py = tmp_path / 'sample.py'
    py.write_text(_SAMPLE_WORKFLOW)

    workflows, activities = _discover(py)

    assert _workflow_name(workflows[0]) == 'MyPipeline'
    assert len(activities) == 1


def test_discover_dedupes_workflow_by_name(tmp_path: Path) -> None:
    body = (
        'from temporalio import workflow\n'
        '\n'
        '@workflow.defn(sandboxed=False, name="Dup")\n'
        'class Dup:\n'
        '    @workflow.run\n'
        '    async def run(self) -> int:\n'
        '        return 1\n'
    )
    (tmp_path / 'a.py').write_text(body)
    (tmp_path / 'b.py').write_text(body)

    workflows, _ = _discover(tmp_path)

    assert len(workflows) == 1


# ── Workflow selection ────────────────────────────────────────────


def _make_wf(name: str) -> type:
    """Build a stub object that looks like a @workflow.defn class.

    Avoids importing temporalio just to set up a marker — _discover
    reads the marker via getattr, not isinstance.
    """
    @dataclasses.dataclass
    class _Defn:
        name: str

    cls = type(name, (), {})
    cls.__temporal_workflow_definition = _Defn(name=name)  # type: ignore[attr-defined]
    return cls


def test_select_workflow_single_no_name() -> None:
    wf = _make_wf('Solo')

    assert _select_workflow([wf], None) is wf


def test_select_workflow_multiple_no_name_errors() -> None:
    a = _make_wf('A')
    b = _make_wf('B')

    with pytest.raises(ValueError, match='Multiple workflows'):
        _select_workflow([a, b], None)


def test_select_workflow_by_name() -> None:
    a = _make_wf('A')
    b = _make_wf('B')

    assert _select_workflow([a, b], 'B') is b


def test_select_workflow_unknown_name() -> None:
    a = _make_wf('A')

    with pytest.raises(ValueError, match='not found'):
        _select_workflow([a], 'B')


def test_select_workflow_empty_list() -> None:
    with pytest.raises(ValueError, match='No @workflow.defn'):
        _select_workflow([], None)


# ── Workflow arg coercion ──────────────────────────────────────────
#
# Workflow / param classes are declared at module level so
# ``typing.get_type_hints`` can resolve string-form annotations
# (which is exactly the shape user workflow files have).


@dataclasses.dataclass(frozen=True)
class _ArgParams:
    label: str


@dataclasses.dataclass(frozen=True)
class _ArgParamsDefault:
    label: str = 'default'


class _WfWithDataclassParam:
    async def run(self, params: _ArgParams) -> int:
        return 1


class _WfWithDataclassParamDefault:
    async def run(self, params: _ArgParamsDefault) -> int:
        return 1


class _WfNoArgs:
    async def run(self) -> int:
        return 1


class _WfUnannotated:
    async def run(self, params):  # noqa: ANN001
        return 1


class _StubNoRun:
    pass


def test_build_arg_no_run_method_returns_parsed() -> None:
    assert _build_workflow_arg(_StubNoRun, '{"x": 1}') == {'x': 1}


def test_build_arg_dataclass_param_constructed() -> None:
    arg = _build_workflow_arg(_WfWithDataclassParam, '{"label": "hi"}')

    assert arg == _ArgParams(label='hi')


def test_build_arg_no_args_returns_none() -> None:
    assert _build_workflow_arg(_WfNoArgs, '{}') is None


def test_build_arg_unannotated_passes_through() -> None:
    assert _build_workflow_arg(_WfUnannotated, '{"x": 1}') == {'x': 1}


def test_build_arg_invalid_json_errors() -> None:
    with pytest.raises(ValueError, match='not valid JSON'):
        _build_workflow_arg(_WfNoArgs, 'not-json')


def test_build_arg_empty_string_means_empty_object() -> None:
    arg = _build_workflow_arg(_WfWithDataclassParamDefault, '')

    assert arg == _ArgParamsDefault(label='default')


# ── CLI parser ─────────────────────────────────────────────────────


def test_parser_defaults() -> None:
    args = _build_parser().parse_args([])

    assert args.pipeline_path is None
    assert args.workflow_name is None
    assert args.params == '{}'
    assert args.params_file is None
    assert args.timeout == 300.0
    assert args.start_timeout == 30.0
    assert args.workflow_id is None
    assert args.worker_only is False


def test_parser_positional_path() -> None:
    args = _build_parser().parse_args(['hello.py'])

    assert args.pipeline_path == Path('hello.py')


def test_parser_all_flags() -> None:
    args = _build_parser().parse_args([
        'hello.py',
        '--name', 'My',
        '--params', '{"x":1}',
        '--timeout', '60',
        '--start-timeout', '5',
        '--workflow-id', 'wf-1',
        '--worker-only',
    ])

    assert args.pipeline_path == Path('hello.py')
    assert args.workflow_name == 'My'
    assert args.params == '{"x":1}'
    assert args.timeout == 60.0
    assert args.start_timeout == 5.0
    assert args.workflow_id == 'wf-1'
    assert args.worker_only is True


def test_parser_params_file_path() -> None:
    args = _build_parser().parse_args(['--params-file', 'p.json'])

    assert args.params_file == Path('p.json')
