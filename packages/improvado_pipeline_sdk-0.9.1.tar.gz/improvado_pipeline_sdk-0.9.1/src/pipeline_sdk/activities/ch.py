"""CH Loader — Nexus-backed call.

``ch_load`` dispatches the ``run_pipeline_load`` operation on the
``ClickhouseLoaderNexusService``. Wire format mirrors
``custom_pipelines/nexus_service.py`` in the clickhouse-loader repo:
ISO date strings, ``list[dict]`` fields, lowercase enum strings — the
server-side ``run_pipeline_load_activity._normalize_request`` already
expects this exact shape from any caller.

Mirrors the ``credentials.py`` / ``les.py`` pattern — module-private
mirror of the CH-Loader Nexus service (so the SDK does not import from
the clickhouse-loader package), default endpoint with env override,
fail-fast tenant check.

Usage::

    with workflow.unsafe.imports_passed_through():
        from pipeline_sdk.activities import les_extract, ch_load

    les_result = await les_extract(...)
    if les_result.result_stage_has_data:
        load_result = await ch_load(
            les_result,
            data_source=params.data_source,
            report_type=params.report_type,
            account_id=params.account_id,
        )
"""

from __future__ import annotations

import dataclasses
import datetime
import os
from datetime import timedelta

import nexusrpc
from temporalio import workflow

from pipeline_sdk.tenant import get_current_workflow_tenant
from pipeline_sdk.types import (
    LesActivityWithS3Result,
    PipelineLoadResult,
    SchemaField,
)


# ── Internal LES → CH wire-format mappings ─────────────────────────
# CH-Loader nexus_service expects lowercase enum strings (matches
# ``run_pipeline_load_activity._normalize_request`` on the server).

_LES_TO_CH_FIELD_TYPE: dict[str, str] = {
    'string': 'string',
    'number': 'number',
    'boolean': 'boolean',
    'date': 'date',
    'object': 'string',
}

_LES_TO_CH_FIELD_KIND: dict[str, str] = {
    'metric': 'metric',
    'dimension': 'dimension',
    'property': 'property',
    'date_key': 'date_key',
}


# ── Nexus service mirror (matches ClickhouseLoaderNexusService) ────
# Source of truth: ``clickhouse-loader/src/custom_pipelines/nexus_service.py``.
# Module-private — pipeline authors talk to CH-loader through
# ``ch_load`` only.


@dataclasses.dataclass(frozen=True)
class _RunPipelineLoadParams:
    data_source: str
    report_type: str
    account_id: str
    # ISO-8601 date strings (YYYY-MM-DD). The Temporal default payload
    # converter does not natively serialize datetime.date across Nexus
    # — keep parity with the CH-Loader nexus_service wire format.
    date_from: str
    date_to: str
    s3_path: str
    data_format: str
    # [{"name": ..., "field_type": ..., "kind": ..., "sql_name": ...,
    #   "title": ..., "is_dynamic": ...}, ...]
    fields: list[dict]
    report_type_class: str
    write_method: str
    write_scope: str
    duplicates_status: str


@dataclasses.dataclass(frozen=True)
class _RunPipelineLoadResult:
    error: str | None
    inserted_rows: int
    deleted_rows: int
    processed_rows: int
    updated_rows: int
    duplicate_rows: int
    actual_date_from: str
    actual_date_to: str


@nexusrpc.service(name='ClickhouseLoaderNexusService')
class _ClickhouseLoaderNexusService:
    run_pipeline_load: nexusrpc.Operation[
        _RunPipelineLoadParams, _RunPipelineLoadResult,
    ]


# ── Endpoint ───────────────────────────────────────────────────────
# Cluster-wide Nexus endpoint targeting CH-Loader's ``ch-activities-queue``
# served by the default ``clickhouse-loader-temporal-worker`` deployment.
# Provisioned by Workflow Manager on startup
# (see ``workflow_manager/config.py:REQUIRED_NEXUS_ENDPOINTS``).
# Env override is for staging / non-default clusters.

_CH_LOADER_ENDPOINT = os.getenv(
    'CH_LOADER_NEXUS_ENDPOINT', 'im-ch-loader-pipeline',
)


# ── Operation timeout ──────────────────────────────────────────────
# Outer envelope around the CH handler workflow + its retries. The
# per-attempt activity timeout and retry policy live on the CH-Loader
# side; this matches the previous activity-side
# ``schedule_to_close_timeout`` so behaviour at the SDK boundary is
# preserved.

_CH_OPERATION_TIMEOUT = timedelta(hours=2)


def _nexus_client() -> workflow.NexusClient[_ClickhouseLoaderNexusService]:
    # Fail-fast if the workflow starter forgot TenantClientInterceptor:
    # without the header the CH-Loader handler would reject the call
    # anyway, but raising here keeps the error close to the real cause.
    get_current_workflow_tenant()
    return workflow.create_nexus_client(
        service=_ClickhouseLoaderNexusService,
        endpoint=_CH_LOADER_ENDPOINT,
    )


# ── Internal converters ────────────────────────────────────────────


def _les_field_to_load_field(field: SchemaField) -> dict:
    # ``.value`` rather than ``str(...)``: (str, Enum) members render
    # as ``ClassName.MEMBER`` under ``str()`` in Python 3.11+, so the
    # lowercase mapping below would always miss without ``.value``.
    field_type_str = field.type.value if field.type else 'string'
    field_kind_str = field.kind.value if field.kind else 'dimension'
    return {
        'name': field.name,
        'field_type': _LES_TO_CH_FIELD_TYPE.get(
            field_type_str, 'string',
        ),
        'kind': _LES_TO_CH_FIELD_KIND.get(
            field_kind_str, 'dimension',
        ),
        'sql_name': field.sql_name,
        'title': field.title,
        'is_dynamic': field.dynamic,
    }


def _build_load_params(
    les_result: LesActivityWithS3Result,
    *,
    data_source: str,
    report_type: str,
    account_id: str,
) -> _RunPipelineLoadParams:
    result_stage = les_result.executor_result.result_stage
    date_from, date_to = result_stage.get_range()
    meta = les_result.executor_result.report_type_meta
    fields = result_stage.fields or []

    return _RunPipelineLoadParams(
        data_source=data_source,
        report_type=report_type,
        account_id=account_id,
        date_from=date_from.isoformat(),
        date_to=date_to.isoformat(),
        s3_path=f's3://{les_result.s3_bucket}/{les_result.s3_key}',
        data_format=les_result.data_format,
        fields=[_les_field_to_load_field(f) for f in fields],
        report_type_class=meta.report_type_class.value,
        write_method=meta.write_method.value,
        write_scope=meta.write_scope.value,
        duplicates_status=meta.duplicates_status.value,
    )


# ── Public wrapper ─────────────────────────────────────────────────


async def ch_load(
    les_result: LesActivityWithS3Result,
    *,
    data_source: str,
    report_type: str,
    account_id: str,
) -> PipelineLoadResult:
    """Load a LES extraction result into ClickHouse via Nexus.

    Must be called from workflow context. Pair with ``les_extract()``:
    feed its result here after checking ``result_stage_has_data``.
    Tenant identity is taken from the workflow's inbound x-tenant-id
    header — callers cannot pass another tenant.
    """
    params = _build_load_params(
        les_result,
        data_source=data_source,
        report_type=report_type,
        account_id=account_id,
    )
    client = _nexus_client()
    raw = await client.execute_operation(
        _ClickhouseLoaderNexusService.run_pipeline_load,
        params,
        schedule_to_close_timeout=_CH_OPERATION_TIMEOUT,
    )
    return PipelineLoadResult(
        error=raw.error,
        inserted_rows=raw.inserted_rows,
        deleted_rows=raw.deleted_rows,
        processed_rows=raw.processed_rows,
        updated_rows=raw.updated_rows,
        duplicate_rows=raw.duplicate_rows,
        actual_date_from=datetime.date.fromisoformat(
            raw.actual_date_from,
        ),
        actual_date_to=datetime.date.fromisoformat(raw.actual_date_to),
    )


__all__ = ['ch_load']
