"""LES extraction — Nexus-backed call.

``les_extract`` dispatches the ``run_les_activity_with_s3_upload``
operation on the LES ``LesNexusService``. The cluster-wide Nexus
endpoint targets the LES namespace + ``les-activities-queue``; tenant
isolation is enforced by the x-tenant-id header (set on the caller
side by ``TenantClientInterceptor`` and forwarded onto Nexus operations
by ``_TenantWorkflowOutbound.start_nexus_operation``) and validated on
the LES handler ingress, not by per-tenant endpoint names.

Mirrors the ``credentials.py`` pattern — module-private mirror of the
LES Nexus service (so the SDK never imports anything from the ``les.*``
package), default endpoint with env override, fail-fast tenant check.

Usage from workflow code::

    with workflow.unsafe.imports_passed_through():
        from pipeline_sdk.activities import les_extract

    result = await les_extract(
        connector_id=123,
        data_source='facebook',
        report_type='ad_insights',
        date_range=params.date_range,
    )
"""

from __future__ import annotations

import os
from datetime import timedelta
from typing import Any

import nexusrpc
from temporalio import workflow

from pipeline_sdk.tenant import get_current_workflow_tenant
from pipeline_sdk.types import (
    DateRangeRequest,
    LesActivityWithS3Result,
    _LesS3UploadActivityParams,
)


# ── Nexus service mirror (matches LesNexusService in les repo) ─────
# Source of truth: ``les/src/apps/app/temporal_activity/nexus_service.py``.
# The mirror here matches the JSON wire format only — the LES side uses
# Pydantic StrictModels with the same field names, the SDK side uses
# frozen dataclasses, both round-trip through Temporal's default
# payload converter as plain JSON objects.
#
# Module-private on purpose: pipeline authors talk to LES through
# ``les_extract`` only.


@nexusrpc.service(name='LesNexusService')
class _LesNexusService:
    run_les_activity_with_s3_upload: nexusrpc.Operation[
        _LesS3UploadActivityParams,
        LesActivityWithS3Result,
    ]


# ── Endpoint ───────────────────────────────────────────────────────
# Cluster-wide Nexus endpoint targeting the LES namespace + activity
# task queue where ``LesNexusServiceHandler`` is hosted. Provisioned
# by Workflow Manager on startup
# (see ``workflow_manager/config.py:REQUIRED_NEXUS_ENDPOINTS``).
# Env override is for staging / non-default clusters.

_LES_ENDPOINT = os.getenv(
    'LES_NEXUS_ENDPOINT', 'im-les-run-activity-with-s3-upload',
)


# ── Operation timeout ──────────────────────────────────────────────
# Outer envelope around the LES handler workflow + its retries. The
# per-attempt activity timeout and retry policy live on the LES side
# (``LesNexusServiceHandler`` handler workflow) — keep this generous
# enough that the handler's retry budget can fully play out.

_LES_OPERATION_TIMEOUT = timedelta(hours=48)


def _nexus_client() -> workflow.NexusClient[_LesNexusService]:
    # Fail-fast if the workflow starter forgot TenantClientInterceptor:
    # without the header the LES handler would reject the call anyway,
    # but raising here keeps the error close to the real cause.
    get_current_workflow_tenant()
    return workflow.create_nexus_client(
        service=_LesNexusService,
        endpoint=_LES_ENDPOINT,
    )


# ── Public wrapper ─────────────────────────────────────────────────


async def les_extract(
    connector_id: int,
    data_source: str,
    report_type: str,
    date_range: DateRangeRequest | None = None,
    fields: list[str] | None = None,
    args: dict[str, Any] | None = None,
    hashed_fields: list[str] | None = None,
    save_raw_data: bool = False,
    raw_responses_exclude_request: bool = False,
) -> LesActivityWithS3Result:
    """Extract data via LES over Nexus.

    Returns a result with ``.data_ref`` and ``.result_stage_has_data``.

    Must be called from workflow context. Tenant identity is taken
    from the workflow's inbound x-tenant-id header — callers cannot
    pass another tenant.
    """
    client = _nexus_client()
    return await client.execute_operation(
        _LesNexusService.run_les_activity_with_s3_upload,
        _LesS3UploadActivityParams(
            connector_id=connector_id,
            data_source=data_source,
            report_type=report_type,
            fields=fields or [],
            date_range_request=date_range,
            args=args or {},
            hashed_fields=hashed_fields or [],
            save_raw_data=save_raw_data,
            raw_responses_exclude_request=raw_responses_exclude_request,
        ),
        schedule_to_close_timeout=_LES_OPERATION_TIMEOUT,
    )


__all__ = ['les_extract']
