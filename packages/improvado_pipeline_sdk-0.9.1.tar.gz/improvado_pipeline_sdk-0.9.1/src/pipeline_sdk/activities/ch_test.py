"""Unit tests for the Nexus-backed CH-Loader helper."""
from __future__ import annotations

import dataclasses
import datetime
import importlib
import inspect

import pytest

from pipeline_sdk.activities import ch as ch_module
from pipeline_sdk.types import (
    CursorRange,
    LesActivityResult,
    LesActivityWithS3Result,
    ReportTypeMeta,
    SchemaField,
    StageResult,
    _DuplicatesStatus,
    _LesFieldKind,
    _LesFieldType,
    _ReportTypeClass,
    _WriteMethod,
    _WriteScope,
)


def test_default_ch_endpoint() -> None:
    # Dashes — Temporal Nexus endpoint names cannot contain dots.
    # Keep in sync with REQUIRED_NEXUS_ENDPOINTS in workflow_manager.
    assert ch_module._CH_LOADER_ENDPOINT == 'im-ch-loader-pipeline'


def test_ch_endpoint_env_override(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv(
        'CH_LOADER_NEXUS_ENDPOINT', 'im-ch-loader-pipeline-staging',
    )
    reloaded = importlib.reload(ch_module)
    try:
        assert (
            reloaded._CH_LOADER_ENDPOINT
            == 'im-ch-loader-pipeline-staging'
        )
    finally:
        monkeypatch.delenv('CH_LOADER_NEXUS_ENDPOINT', raising=False)
        importlib.reload(ch_module)


def test_public_api_accepts_no_tenant_or_endpoint_params() -> None:
    """Tenant/endpoint must not be passable from pipeline authors."""
    forbidden = {'tenant', 'nexus_endpoint', 'endpoint'}
    params = set(inspect.signature(ch_module.ch_load).parameters)
    leaked = params & forbidden
    assert not leaked, f'ch_load leaks {leaked}'


def test_ch_service_mirror_operation_name() -> None:
    """Operation name on the SDK mirror must match the CH-Loader service."""
    op = ch_module._ClickhouseLoaderNexusService.run_pipeline_load
    assert op is not None


def _build_les_result() -> LesActivityWithS3Result:
    """Minimal LES result with one date-range stage and one schema field."""
    field = SchemaField(
        type=_LesFieldType.STRING,
        name='campaign',
        sql_name='campaign',
        kind=_LesFieldKind.DIMENSION,
        title='Campaign',
        dynamic=False,
    )
    stage = StageResult(
        name='result',
        path='res.json',
        cursor_range=CursorRange(
            min_value=datetime.date(2026, 4, 1),
            max_value=datetime.date(2026, 4, 30),
        ),
        fields=[field],
    )
    meta = ReportTypeMeta(
        report_type_class=_ReportTypeClass.DAILY,
        write_method=_WriteMethod.OVERWRITE,
        write_scope=_WriteScope.BY_DATE_RANGE,
        duplicates_status=_DuplicatesStatus.NO_DUPLICATES,
    )
    return LesActivityWithS3Result(
        executor_result=LesActivityResult(
            stages=[stage],
            result_stage_name='result',
            report_type_meta=meta,
        ),
        s3_bucket='im-bucket',
        s3_key='runs/abc/data.json',
        data_format='json_each_row',
    )


def test_build_load_params_emits_nexus_wire_format() -> None:
    """Wire fields must match CH-Loader nexus_service.RunPipelineLoadParams.

    ISO date strings, lowercase enum values, list[dict] fields,
    s3://… path. Any drift here lands at the server-side
    ``_normalize_request`` and explodes at runtime.
    """
    params = ch_module._build_load_params(
        _build_les_result(),
        data_source='facebook',
        report_type='ad_insights',
        account_id='acc-1',
    )

    # All wire fields are primitives or list[dict] — no enums or dates
    # should leak into the Nexus payload.
    for f in dataclasses.fields(params):
        value = getattr(params, f.name)
        assert not isinstance(value, datetime.date), f.name
        assert not isinstance(
            value,
            (
                _ReportTypeClass, _WriteMethod, _WriteScope,
                _DuplicatesStatus,
            ),
        ), f.name

    assert params.date_from == '2026-04-01'
    assert params.date_to == '2026-04-30'
    assert params.s3_path == 's3://im-bucket/runs/abc/data.json'
    assert params.data_format == 'json_each_row'
    assert params.report_type_class == 'daily'
    assert params.write_method == 'overwrite'
    assert params.write_scope == 'by_date_range'
    assert params.duplicates_status == 'no_duplicates'

    assert params.fields == [
        {
            'name': 'campaign',
            'field_type': 'string',
            'kind': 'dimension',
            'sql_name': 'campaign',
            'title': 'Campaign',
            'is_dynamic': False,
        },
    ]
