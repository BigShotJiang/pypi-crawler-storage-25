"""Unit tests for the Nexus-backed LES helper."""
from __future__ import annotations

import importlib
import inspect

import pytest

from pipeline_sdk.activities import les as les_module


def test_default_les_endpoint() -> None:
    # Dashes — Temporal Nexus endpoint names cannot contain dots.
    # Keep in sync with REQUIRED_NEXUS_ENDPOINTS in workflow_manager
    # and the LES nexus handler registration.
    assert (
        les_module._LES_ENDPOINT == 'im-les-run-activity-with-s3-upload'
    )


def test_les_endpoint_env_override(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv(
        'LES_NEXUS_ENDPOINT', 'im-les-run-activity-staging',
    )
    reloaded = importlib.reload(les_module)
    try:
        assert reloaded._LES_ENDPOINT == 'im-les-run-activity-staging'
    finally:
        monkeypatch.delenv('LES_NEXUS_ENDPOINT', raising=False)
        importlib.reload(les_module)


def test_public_api_accepts_no_tenant_or_endpoint_params() -> None:
    """Tenant/endpoint must not be passable from pipeline authors.

    Guards against regressions that would reintroduce a ``tenant=`` or
    ``nexus_endpoint=`` kwarg on the public helper — the whole point
    of the Nexus migration is that tenant identity comes from the
    trusted inbound header only.
    """
    forbidden = {'tenant', 'nexus_endpoint', 'endpoint'}
    params = set(inspect.signature(les_module.les_extract).parameters)
    leaked = params & forbidden
    assert not leaked, f'les_extract leaks {leaked}'


def test_les_service_mirror_operation_name() -> None:
    """Operation name on the SDK mirror must match the LES service.

    LES side declares ``run_les_activity_with_s3_upload`` on
    ``LesNexusService``. A drift here would land the Nexus dispatch
    on a non-existent operation.
    """
    op = les_module._LesNexusService.run_les_activity_with_s3_upload
    assert op is not None
