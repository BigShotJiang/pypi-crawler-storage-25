#!/usr/bin/env python3
"""
grepme-x — regex-powered README generator for Python web projects.
Supports Flask, Django, FastAPI, SQLAlchemy, Pydantic, Django ORM, DRF.
"""

import argparse
import json
import os
import re
import sys
from pathlib import Path


# ─── Constants ────────────────────────────────────────────────────────────────

BINARY_EXTENSIONS = {
    ".png", ".jpg", ".jpeg", ".gif", ".bmp", ".ico", ".webp", ".svg",
    ".pdf", ".zip", ".tar", ".gz", ".rar", ".7z",
    ".exe", ".dll", ".so", ".dylib",
    ".ttf", ".otf", ".woff", ".woff2", ".eot",
    ".mp3", ".mp4", ".wav", ".ogg", ".avi", ".mov",
    ".db", ".sqlite", ".lock", ".pyc",
}

BASE_IGNORE = {
    ".git", "__pycache__", ".venv", "venv", "env",
    "dist", "build", ".cache", "coverage", "htmlcov",
    ".mypy_cache", ".pytest_cache", ".tox", ".ruff_cache",
    "eggs", ".eggs", "site-packages", "migrations",
    "staticfiles", "static", "media",
}

# ─── Auth packages ────────────────────────────────────────────────────────────

AUTH_PACKAGES = {
    "flask-login":                   "Flask-Login",
    "flask_login":                   "Flask-Login",
    "flask-jwt-extended":            "Flask-JWT-Extended",
    "flask_jwt_extended":            "Flask-JWT-Extended",
    "flask-security":                "Flask-Security",
    "flask_security":                "Flask-Security",
    "flask-security-too":            "Flask-Security-Too",
    "flask-httpauth":                "Flask-HTTPAuth",
    "flask_httpauth":                "Flask-HTTPAuth",
    "djangorestframework":           "DRF Token Auth",
    "djangorestframework-simplejwt": "Django SimpleJWT",
    "django-allauth":                "django-allauth",
    "django-oauth-toolkit":          "Django OAuth Toolkit",
    "python-jose":                   "python-jose (JWT)",
    "python_jose":                   "python-jose (JWT)",
    "pyjwt":                         "PyJWT",
    "PyJWT":                         "PyJWT",
    "authlib":                       "Authlib (OAuth2)",
    "passlib":                       "passlib (password hashing)",
    "bcrypt":                        "bcrypt (password hashing)",
    "argon2-cffi":                   "argon2 (password hashing)",
    "argon2_cffi":                   "argon2 (password hashing)",
    "python-keycloak":               "Keycloak",
    "firebase-admin":                "Firebase Auth",
    "supabase":                      "Supabase Auth",
    "fastapi-users":                 "FastAPI Users",
    "fastapi_users":                 "FastAPI Users",
    "fastapi-jwt-auth":              "FastAPI JWT Auth",
    "casbin":                        "Casbin (RBAC/ABAC)",
    "django-guardian":               "Django Guardian (object permissions)",
    "django-rules":                  "django-rules (RBAC)",
}

# ─── Route protection patterns ────────────────────────────────────────────────

PROTECTED_PATTERNS = [
    re.compile(r"@login_required"),
    re.compile(r"@jwt_required"),
    re.compile(r"@token_required"),
    re.compile(r"@permission_required"),
    re.compile(r"@roles_required"),
    re.compile(r"@auth\.login_required"),
    re.compile(r"Depends\(get_current_user\)"),
    re.compile(r"Depends\(verify_token\)"),
    re.compile(r"Depends\(get_current_active_user\)"),
    re.compile(r"OAuth2PasswordBearer"),
    re.compile(r"HTTPBearer|HTTPBasic"),
    re.compile(r"current_user\.is_authenticated"),
    re.compile(r"IsAuthenticated|IsAdminUser|DjangoModelPermissions"),
    re.compile(r"permission_classes\s*="),
    re.compile(r"authentication_classes\s*="),
]

PUBLIC_PATTERNS = [
    re.compile(r"/login|/signin|/signup|/register|/auth/|/oauth|/token", re.IGNORECASE),
    re.compile(r"/public/", re.IGNORECASE),
    re.compile(r"AllowAny"),
]

AUTH_ENV_PATTERNS = [
    re.compile(r"SECRET_KEY"),
    re.compile(r"JWT_SECRET|JWT_PRIVATE_KEY|JWT_PUBLIC_KEY|JWT_SECRET_KEY"),
    re.compile(r"SESSION_SECRET|COOKIE_SECRET"),
    re.compile(r"GOOGLE_CLIENT_ID|GOOGLE_CLIENT_SECRET"),
    re.compile(r"GITHUB_CLIENT_ID|GITHUB_CLIENT_SECRET"),
    re.compile(r"AUTH0_DOMAIN|AUTH0_CLIENT_ID|AUTH0_CLIENT_SECRET"),
    re.compile(r"SUPABASE_ANON_KEY|SUPABASE_SERVICE_ROLE_KEY|SUPABASE_URL"),
    re.compile(r"FIREBASE_API_KEY|FIREBASE_PROJECT_ID|FIREBASE_CREDENTIALS"),
    re.compile(r"OAUTH_CLIENT_ID|OAUTH_CLIENT_SECRET"),
]


# ─── File helpers ─────────────────────────────────────────────────────────────

def get_files(directory: Path, ignore: set) -> list:
    results = []
    try:
        entries = list(directory.iterdir())
    except PermissionError:
        return results
    for entry in entries:
        if entry.name in ignore or entry.name.startswith("."):
            continue
        if entry.is_dir():
            results.extend(get_files(entry, ignore))
        elif entry.suffix.lower() not in BINARY_EXTENSIONS:
            results.append(entry)
    return results


def safe_read(file_path: Path) -> str:
    try:
        return file_path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return ""


# ─── File tree ────────────────────────────────────────────────────────────────

def build_tree(directory: Path, ignore: set, prefix: str = "", depth: int = 0) -> str:
    if depth > 3:
        return ""
    try:
        entries = sorted(directory.iterdir(), key=lambda e: (e.is_file(), e.name))
    except PermissionError:
        return ""
    filtered = [e for e in entries if e.name not in ignore and not e.name.startswith(".")]
    lines = []
    for i, entry in enumerate(filtered):
        is_last = i == len(filtered) - 1
        connector = "└── " if is_last else "├── "
        child_prefix = prefix + ("    " if is_last else "│   ")
        if entry.is_dir():
            lines.append(f"{prefix}{connector}{entry.name}/")
            subtree = build_tree(entry, ignore, child_prefix, depth + 1)
            if subtree:
                lines.append(subtree)
        else:
            lines.append(f"{prefix}{connector}{entry.name}")
    return "\n".join(lines)


# ─── File classifier ──────────────────────────────────────────────────────────

def classify_file(file_path: Path) -> str:
    lower = str(file_path).lower().replace("\\", "/")
    if re.search(r"/(routes?|urls?|api|views?)/", lower): return "routes"
    if re.search(r"/controllers?/", lower):               return "controllers"
    if re.search(r"/models?/", lower):                    return "models"
    if re.search(r"/(middleware|decorators?)/", lower):   return "middleware"
    if re.search(r"/schemas?/", lower):                   return "models"
    if lower.endswith("urls.py"):                         return "routes"
    if lower.endswith("views.py"):                        return "routes"
    if lower.endswith("models.py"):                       return "models"
    if lower.endswith("serializers.py"):                  return "models"
    if lower.endswith("schemas.py"):                      return "models"
    if lower.endswith("middleware.py"):                   return "middleware"
    if lower.endswith("decorators.py"):                   return "middleware"
    return "other"


# ─── Route extraction ─────────────────────────────────────────────────────────

def extract_routes(content: str, file_path: Path) -> list:
    routes = []
    seen = set()

    def add(method: str, path_str: str):
        key = f"{method.upper()}:{path_str}"
        if key not in seen:
            seen.add(key)
            routes.append({"method": method.upper(), "path": path_str})

    # Flask: @app.route / @blueprint.route with optional methods=[]
    for m in re.finditer(
        r"@(?:[\w]+\.)*route\s*\(\s*['\"`](.*?)['\"`](?:.*?methods\s*=\s*\[(.*?)\])?",
        content, re.DOTALL
    ):
        path_str = m.group(1)
        methods_raw = m.group(2)
        if methods_raw:
            for method in re.findall(r"['\"`](\w+)['\"`]", methods_raw):
                add(method, path_str)
        else:
            add("GET", path_str)

    # Flask 2.0+ / FastAPI shorthand: @app.get / @router.post / etc.
    for m in re.finditer(
        r"@(?:[\w]+\.)(get|post|put|patch|delete)\s*\(\s*['\"`](.*?)['\"`]",
        content, re.IGNORECASE
    ):
        add(m.group(1), m.group(2))

    # Django: path() / re_path() / url()
    for m in re.finditer(
        r"(?:path|re_path|url)\s*\(\s*r?['\"`](.*?)['\"`]",
        content
    ):
        raw = m.group(1)
        # Convert Django path converters <int:pk> -> :pk
        clean = re.sub(r"<(?:\w+:)?(\w+)>", r":\1", raw)
        add("ANY", "/" + clean.lstrip("/"))

    # DRF ViewSet router.register -> auto-generates CRUD routes
    for m in re.finditer(
        r"router\.register\s*\(\s*r?['\"`](.*?)['\"`]",
        content
    ):
        prefix = m.group(1).strip("/")
        for method, suffix in [
            ("GET", "/"), ("POST", "/"),
            ("GET", "/:id/"), ("PUT", "/:id/"),
            ("PATCH", "/:id/"), ("DELETE", "/:id/"),
        ]:
            add(method, f"/{prefix}{suffix}")

    return routes


# ─── View / function extraction ───────────────────────────────────────────────

def extract_functions(content: str) -> list:
    found = set()
    # Top-level functions
    for m in re.finditer(r"^(?:async\s+)?def\s+(\w+)\s*\(", content, re.MULTILINE):
        name = m.group(1)
        if not name.startswith("__"):
            found.add(name)
    # Class methods (4-space indent)
    for m in re.finditer(r"^    (?:async\s+)?def\s+(\w+)\s*\(", content, re.MULTILINE):
        name = m.group(1)
        if not name.startswith("_"):
            found.add(name)
    return sorted(found)


# ─── Schema extraction ────────────────────────────────────────────────────────

def extract_schemas(content: str, file_path: Path) -> list:
    schemas = []

    # SQLAlchemy: class MyModel(Base) with Column / mapped_column
    for m in re.finditer(
        r"class\s+(\w+)\s*\([^)]*(?:Base|DeclarativeBase|db\.Model)[^)]*\):"
        r"([\s\S]*?)(?=\nclass\s|\Z)",
        content
    ):
        body = m.group(2)
        columns = re.findall(
            r"(\w+)\s*(?::\s*Mapped\[.*?\])?\s*=\s*(?:mapped_column|Column)\s*\(([^)]*)\)",
            body
        )
        if columns:
            defn = "\n".join(f"  {col} = Column({typ.strip()})" for col, typ in columns[:12])
            schemas.append({"type": "sqlalchemy", "name": m.group(1), "definition": defn[:400]})

    # Django ORM: class MyModel(models.Model)
    for m in re.finditer(
        r"class\s+(\w+)\s*\([^)]*models\.Model[^)]*\):([\s\S]*?)(?=\nclass\s|\Z)",
        content
    ):
        body = m.group(2)
        fields = re.findall(r"(\w+)\s*=\s*models\.(\w+)\s*\(([^)]*)\)", body)
        if fields:
            defn = "\n".join(
                f"  {name} = models.{ftype}({args.strip()[:60]})"
                for name, ftype, args in fields[:12]
            )
            schemas.append({"type": "django", "name": m.group(1), "definition": defn[:400]})

    # Pydantic: class MySchema(BaseModel)
    for m in re.finditer(
        r"class\s+(\w+)\s*\([^)]*(?:BaseModel|Schema)[^)]*\):([\s\S]*?)(?=\nclass\s|\Z)",
        content
    ):
        body = m.group(2)
        fields = re.findall(r"^\s{4}(\w+)\s*:\s*([\w\[\], |\"']+)", body, re.MULTILINE)
        if fields:
            defn = "\n".join(f"  {name}: {typ.strip()}" for name, typ in fields[:12])
            schemas.append({"type": "pydantic", "name": m.group(1), "definition": defn[:400]})

    # DRF Serializer: class MySerializer(ModelSerializer)
    for m in re.finditer(
        r"class\s+(\w+)\s*\([^)]*(?:Serializer|ModelSerializer)[^)]*\):([\s\S]*?)(?=\nclass\s|\Z)",
        content
    ):
        body = m.group(2)
        meta_model = re.search(r"model\s*=\s*(\w+)", body)
        meta_fields = re.search(r"fields\s*=\s*(.+)", body)
        if meta_model or meta_fields:
            defn = ""
            if meta_model:
                defn += f"  model = {meta_model.group(1)}\n"
            if meta_fields:
                defn += f"  fields = {meta_fields.group(1).strip()[:100]}"
            schemas.append({"type": "drf_serializer", "name": m.group(1), "definition": defn[:400]})

    return schemas


# ─── Environment variables ────────────────────────────────────────────────────

def extract_env_vars(content: str) -> list:
    found = set()

    # os.environ["VAR"] / os.environ.get("VAR") / os.getenv("VAR")
    for m in re.finditer(
        r"""os\.(?:environ(?:\.get)?\s*[\[(\s]\s*|getenv\s*\(\s*)['"`]([A-Z_][A-Z0-9_]*)['"`]""",
        content
    ):
        found.add(m.group(1))

    # python-decouple / environs: config("VAR") / env("VAR")
    for m in re.finditer(r"""(?:config|env)\s*\(\s*['"`]([A-Z_][A-Z0-9_]*)['"`]""", content):
        found.add(m.group(1))

    # Django settings.py top-level all-caps assignments that look like env-backed
    for m in re.finditer(r"^([A-Z_][A-Z0-9_]{3,})\s*=", content, re.MULTILINE):
        name = m.group(1)
        if any(kw in name for kw in ("KEY", "SECRET", "URL", "HOST", "PORT", "USER", "PASS", "TOKEN", "ID", "DSN")):
            found.add(name)

    return sorted(found)


# ─── Middleware extraction ────────────────────────────────────────────────────

def extract_middleware(content: str) -> list:
    found = []
    seen = set()

    def add(name: str):
        if name not in seen:
            seen.add(name)
            found.append({"name": name, "path": "*"})

    # Django MIDDLEWARE list entries
    for m in re.finditer(r"['\"`]([\w.]+Middleware)['\"`]", content):
        add(m.group(1).split(".")[-1])

    # FastAPI / Starlette: app.add_middleware(SomeMiddleware)
    for m in re.finditer(r"(?:app|router)\.add_middleware\s*\(\s*(\w+)", content):
        add(m.group(1))

    # Flask lifecycle hooks
    for m in re.finditer(r"@(?:\w+\.)(before_request|after_request|before_app_request|teardown_request)", content):
        add(m.group(1))

    # Starlette Middleware() wrapper
    for m in re.finditer(r"Middleware\s*\(\s*(\w+)", content):
        add(m.group(1))

    return found


# ─── Auth detection ───────────────────────────────────────────────────────────

def detect_auth(all_files: list, dependencies: list) -> dict:
    strategies = set()

    # From dependency list (requirements.txt / pyproject.toml)
    for dep in dependencies:
        key = dep.lower().replace("-", "_")
        if dep in AUTH_PACKAGES:
            strategies.add(AUTH_PACKAGES[dep])
        elif key in AUTH_PACKAGES:
            strategies.add(AUTH_PACKAGES[key])

    # From import statements
    for file_path in all_files:
        if file_path.suffix != ".py":
            continue
        content = safe_read(file_path)
        if not content:
            continue
        for m in re.finditer(r"^(?:from|import)\s+([\w._]+)", content, re.MULTILINE):
            pkg = m.group(1).split(".")[0]
            for variant in [pkg, pkg.replace("_", "-")]:
                if variant in AUTH_PACKAGES:
                    strategies.add(AUTH_PACKAGES[variant])

        # Decorator-based detection
        if re.search(r"@login_required", content):
            strategies.add("Flask-Login / Django login_required")
        if re.search(r"@jwt_required|@jwt_optional", content):
            strategies.add("JWT decorator auth")
        if re.search(r"OAuth2PasswordBearer|HTTPBearer", content):
            strategies.add("FastAPI OAuth2 / Bearer token")
        if re.search(r"permission_classes|authentication_classes", content):
            strategies.add("DRF permission classes")

    # Route-level auth annotation
    route_auth_info = []
    for file_path in all_files:
        if file_path.suffix != ".py":
            continue
        content = safe_read(file_path)
        if not content:
            continue
        # Match decorator block + function def
        for m in re.finditer(
            r"((?:@[\w.()\", '\n]+\n)+)(?:async\s+)?def\s+(\w+)\s*\(",
            content
        ):
            decorators = m.group(1)
            func_name = m.group(2)
            path_match = re.search(r"""['\"`](/[^'"`\s]*)['\"`]""", decorators)
            path_str = path_match.group(1) if path_match else f"/{func_name}"
            is_public = any(p.search(path_str) for p in PUBLIC_PATTERNS) or \
                        any(p.search(decorators) for p in PUBLIC_PATTERNS)
            is_protected = not is_public and any(p.search(decorators) for p in PROTECTED_PATTERNS)
            if is_public or is_protected:
                route_auth_info.append({
                    "method": "ANY",
                    "path": path_str,
                    "protected": is_protected,
                    "public": is_public,
                    "view": func_name,
                })

    # Auth env vars
    auth_env_vars = set()
    for file_path in all_files:
        content = safe_read(file_path)
        if not content:
            continue
        for pattern in AUTH_ENV_PATTERNS:
            for match in re.findall(pattern, content):
                auth_env_vars.add(match.split("=")[0].strip())

    return {
        "strategies": sorted(strategies),
        "routeAuthInfo": route_auth_info,
        "authEnvVars": sorted(auth_env_vars),
    }


# ─── Docker info ──────────────────────────────────────────────────────────────

def get_docker_info(root: Path) -> dict:
    info = {
        "hasDockerfile": False, "hasDockerCompose": False, "hasDockerIgnore": False,
        "services": [], "ports": [], "exposedPorts": [], "volumes": [],
        "envFiles": [], "buildArgs": [], "stages": [],
        "composeVersion": None, "dockerfileCommands": [],
    }

    dockerfile = root / "Dockerfile"
    if dockerfile.exists():
        info["hasDockerfile"] = True
        content = safe_read(dockerfile)
        for m in re.finditer(r"^FROM\s+\S+\s+AS\s+(\S+)", content, re.MULTILINE | re.IGNORECASE):
            info["stages"].append(m.group(1))
        for m in re.finditer(r"^EXPOSE\s+([\d\s]+)", content, re.MULTILINE | re.IGNORECASE):
            info["exposedPorts"].extend(m.group(1).strip().split())
        for m in re.finditer(r"^ARG\s+(\w+)", content, re.MULTILINE | re.IGNORECASE):
            info["buildArgs"].append(m.group(1))
        for m in re.finditer(r"^(CMD|ENTRYPOINT)\s+(.+)", content, re.MULTILINE | re.IGNORECASE):
            info["dockerfileCommands"].append({"instruction": m.group(1), "value": m.group(2).strip()})

    if (root / ".dockerignore").exists():
        info["hasDockerIgnore"] = True

    compose_names = [
        "docker-compose.yml", "docker-compose.yaml",
        "docker-compose.prod.yml", "docker-compose.production.yml",
        "docker-compose.dev.yml", "docker-compose.override.yml",
    ]
    compose_paths = [root / n for n in compose_names if (root / n).exists()]

    if compose_paths:
        info["hasDockerCompose"] = True
        ports_seen, services_seen, volumes_seen, env_files_seen = set(), set(), set(), set()
        for cp in compose_paths:
            raw = safe_read(cp)
            ver = re.search(r"^version:\s*['\"]?([\d.]+)['\"]?", raw, re.MULTILINE)
            if ver and not info["composeVersion"]:
                info["composeVersion"] = ver.group(1)
            svc_block = re.search(r"^services:\s*\n([\s\S]*?)(?=^\w|\Z)", raw, re.MULTILINE)
            if svc_block:
                for svc in re.finditer(r"^  (\w[\w-]*):", svc_block.group(1), re.MULTILINE):
                    services_seen.add(svc.group(1))
            for m in re.finditer(r"['\"]?(\d+):(\d+)['\"]?", raw):
                key = f"{m.group(1)}:{m.group(2)}"
                if key not in ports_seen:
                    ports_seen.add(key)
                    info["ports"].append({"host": m.group(1), "container": m.group(2)})
            vol_block = re.search(r"^volumes:\s*\n([\s\S]*?)(?=^\w|\Z)", raw, re.MULTILINE)
            if vol_block:
                for vol in re.finditer(r"^  (\w[\w-]*):", vol_block.group(1), re.MULTILINE):
                    volumes_seen.add(vol.group(1))
            for m in re.finditer(r"env_file:\s*\n\s+-\s+(.+)", raw):
                env_files_seen.add(m.group(1).strip())
        info["services"] = sorted(services_seen)
        info["volumes"] = sorted(volumes_seen)
        info["envFiles"] = sorted(env_files_seen)

    return info


# ─── Package info ─────────────────────────────────────────────────────────────

def get_package_info(root: Path) -> dict:
    base = {"name": None, "version": None, "description": None,
            "dependencies": [], "devDependencies": [], "scripts": {}}

    # pyproject.toml — Poetry or PEP 621
    pyproject = root / "pyproject.toml"
    if pyproject.exists():
        content = safe_read(pyproject)
        for key, pattern in [
            ("name",        r'^name\s*=\s*["\']([^"\']+)["\']'),
            ("version",     r'^version\s*=\s*["\']([^"\']+)["\']'),
            ("description", r'^description\s*=\s*["\']([^"\']+)["\']'),
        ]:
            m = re.search(pattern, content, re.MULTILINE)
            if m:
                base[key] = m.group(1)

        # Poetry deps
        deps_block = re.search(r"\[tool\.poetry\.dependencies\]([\s\S]*?)(?=\[|\Z)", content)
        if deps_block:
            base["dependencies"] = re.findall(r'^(\w[\w-]*)\s*=', deps_block.group(1), re.MULTILINE)

        dev_block = re.search(
            r"\[tool\.poetry\.(?:dev-dependencies|group\.dev\.dependencies)\]([\s\S]*?)(?=\[|\Z)",
            content
        )
        if dev_block:
            base["devDependencies"] = re.findall(r'^(\w[\w-]*)\s*=', dev_block.group(1), re.MULTILINE)

        # PEP 621 deps
        pep621 = re.search(r"\[project\][\s\S]*?dependencies\s*=\s*\[([\s\S]*?)\]", content)
        if pep621 and not base["dependencies"]:
            base["dependencies"] = re.findall(r'["\']([a-zA-Z0-9_-]+)', pep621.group(1))

        # Scripts
        scripts_block = re.search(r"\[tool\.poetry\.scripts\]([\s\S]*?)(?=\[|\Z)", content)
        if scripts_block:
            for sm in re.finditer(r'(\w[\w-]*)\s*=\s*["\']([^"\']+)["\']', scripts_block.group(1)):
                base["scripts"][sm.group(1)] = sm.group(2)
        return base

    # setup.py
    setup_py = root / "setup.py"
    if setup_py.exists():
        content = safe_read(setup_py)
        for key, pattern in [
            ("name",        r"""name\s*=\s*['"]([^'"]+)['"]"""),
            ("version",     r"""version\s*=\s*['"]([^'"]+)['"]"""),
            ("description", r"""description\s*=\s*['"]([^'"]+)['"]"""),
        ]:
            m = re.search(pattern, content)
            if m:
                base[key] = m.group(1)
        inst = re.search(r"install_requires\s*=\s*\[([\s\S]*?)\]", content)
        if inst:
            base["dependencies"] = re.findall(r'["\']([a-zA-Z0-9_-]+)', inst.group(1))
        return base

    # requirements.txt fallback
    req_txt = root / "requirements.txt"
    if req_txt.exists():
        deps = []
        for line in safe_read(req_txt).splitlines():
            line = line.strip()
            if line and not line.startswith("#"):
                pkg = re.split(r"[>=<!~\[]", line)[0].strip()
                if pkg:
                    deps.append(pkg)
        base["dependencies"] = deps

    req_dev = root / "requirements-dev.txt"
    if req_dev.exists():
        dev_deps = []
        for line in safe_read(req_dev).splitlines():
            line = line.strip()
            if line and not line.startswith("#"):
                pkg = re.split(r"[>=<!~\[]", line)[0].strip()
                if pkg:
                    dev_deps.append(pkg)
        base["devDependencies"] = dev_deps

    return base


# ─── README renderer ──────────────────────────────────────────────────────────

def generate_markdown(data: dict, controller_descriptions: dict = {}) -> str:
    name        = data.get("name") or "Project"
    version     = data.get("version") or "1.0.0"
    description = data.get("description")
    routes      = data.get("routes", [])
    controllers = data.get("controllers", [])
    models      = data.get("models", [])
    dependencies = data.get("dependencies", [])
    dev_deps    = data.get("devDependencies", [])
    scripts     = data.get("scripts", {})
    env_vars    = data.get("envVars", [])
    middleware  = data.get("middleware", [])
    tree        = data.get("tree", "")
    auth        = data.get("auth", {"strategies": [], "routeAuthInfo": [], "authEnvVars": []})
    docker      = data.get("docker", {"hasDockerfile": False, "hasDockerCompose": False})

    lines = []

    lines.append(f"# {name}")
    if description:
        lines.append(f"\n> {description}")
    lines.append(f"\n## Version\n\n{version}")

    # Scripts
    if scripts:
        lines.append("\n## Scripts\n")
        lines.append("| Command | Runs |")
        lines.append("|---------|------|")
        for cmd, val in scripts.items():
            lines.append(f"| `{cmd}` | `{val}` |")

    # Authentication
    if auth["strategies"] or auth["routeAuthInfo"]:
        lines.append("\n## Authentication\n")
        if auth["strategies"]:
            lines.append("**Detected:**\n")
            for s in auth["strategies"]:
                lines.append(f"- {s}")
        annotated = [r for r in auth["routeAuthInfo"] if r["protected"] or r["public"]]
        if annotated:
            lines.append("\n**Route protection:**\n")
            lines.append("| View | Path | Access |")
            lines.append("|------|------|--------|")
            for r in annotated:
                badge = "Public" if r["public"] else "Protected"
                view = r.get("view", r["method"])
                lines.append(f"| `{view}` | `{r['path']}` | {badge} |")
        if auth["authEnvVars"]:
            lines.append("\n**Required auth environment variables:**\n")
            lines.append("```env")
            for v in auth["authEnvVars"]:
                lines.append(f"{v}=")
            lines.append("```")

    # Docker
    if docker.get("hasDockerfile") or docker.get("hasDockerCompose"):
        lines.append("\n## Docker & Deployment\n")
        if docker.get("hasDockerfile"):
            lines.append("### Dockerfile\n")
            if docker.get("stages"):
                lines.append(f"**Multi-stage build** — stages: {', '.join(f'`{s}`' for s in docker['stages'])}\n")
            if docker.get("exposedPorts"):
                lines.append(f"**Exposed ports:** {', '.join(f'`{p}`' for p in docker['exposedPorts'])}\n")
            if docker.get("buildArgs"):
                lines.append(f"**Build args:** {', '.join(f'`{a}`' for a in docker['buildArgs'])}\n")
            if docker.get("dockerfileCommands"):
                lines.append("**Entry commands:**\n")
                for cmd in docker["dockerfileCommands"]:
                    lines.append(f"- `{cmd['instruction']}`: `{cmd['value']}`")
            lines.append("\n```bash")
            lines.append(f"docker build -t {name} .")
            if docker.get("exposedPorts"):
                port = docker["exposedPorts"][0]
                lines.append(f"docker run -p {port}:{port} {name}")
            lines.append("```")
        if docker.get("hasDockerCompose"):
            lines.append("\n### Docker Compose\n")
            if docker.get("composeVersion"):
                lines.append(f"**Compose version:** {docker['composeVersion']}\n")
            if docker.get("services"):
                lines.append(f"**Services:** {', '.join(f'`{s}`' for s in docker['services'])}\n")
            if docker.get("ports"):
                lines.append("**Port mappings:**\n")
                lines.append("| Host | Container |")
                lines.append("|------|-----------|")
                for p in docker["ports"]:
                    lines.append(f"| `{p['host']}` | `{p['container']}` |")
            if docker.get("volumes"):
                lines.append(f"\n**Named volumes:** {', '.join(f'`{v}`' for v in docker['volumes'])}\n")
            if docker.get("envFiles"):
                lines.append(f"**Env files:** {', '.join(f'`{f}`' for f in docker['envFiles'])}\n")
            lines.append("\n```bash")
            lines.append("docker compose up -d")
            lines.append("docker compose logs -f")
            lines.append("docker compose down")
            lines.append("```")

    # Routes
    lines.append("\n## Routes\n")
    if routes:
        lines.append("| Method | Path |")
        lines.append("|--------|------|")
        for r in routes:
            ann = next((a for a in auth["routeAuthInfo"] if a["path"] == r["path"]), None)
            badge = " (Protected)" if ann and ann["protected"] else \
                    " (Public)"    if ann and ann["public"]     else ""
            lines.append(f"| `{r['method']}` | `{r['path']}`{badge} |")
    else:
        lines.append("No routes found.")

    # Middleware
    if middleware:
        lines.append("\n## Middleware\n")
        for mw in middleware:
            lines.append(f"- `{mw['name']}`")

    # Views / Controllers
    lines.append("\n## Views / Controllers\n")
    if controllers:
        for c in controllers:
            desc = controller_descriptions.get(c, "")
            if desc:
                lines.append(f"- **`{c}`** — {desc}")
            else:
                lines.append(f"- `{c}`")
    else:
        lines.append("No views found.")

    # Models / Schemas
    lines.append("\n## Models & Schemas\n")
    if models:
        for i, m in enumerate(models):
            label = f"{m['type']} — {m['name']}" if m.get("name") else f"{m['type']} model {i + 1}"
            lines.append(f"### {label}\n```python\n{m['definition']}\n```")
    else:
        lines.append("No models found.")

    # Environment Variables
    lines.append("\n## Environment Variables\n")
    if env_vars:
        lines.append("Create a `.env` file:\n")
        lines.append("```env")
        for v in env_vars:
            lines.append(f"{v}=")
        lines.append("```")
    else:
        lines.append("No environment variables detected.")

    # Dependencies
    lines.append("\n## Dependencies\n")
    if dependencies:
        lines.append("\n".join(f"- `{d}`" for d in dependencies))
    else:
        lines.append("None.")
    if dev_deps:
        lines.append("\n### Dev Dependencies\n")
        lines.append("\n".join(f"- `{d}`" for d in dev_deps))

    # File tree
    if tree:
        lines.append(f"\n## Project Structure\n\n```\n{tree}\n```")

    lines.append("\n---\n_Generated by [grepme-x](https://github.com/yourusername/grepme-x)_")
    return "\n".join(lines)


# ─── AI generation ────────────────────────────────────────────────────────────


def generate_ai_readme(data: dict, api_key: str, model: str) -> str:
    routes      = data.get("routes", [])
    auth        = data.get("auth", {})
    docker      = data.get("docker", {})
    env_vars    = data.get("envVars", [])
    dependencies = data.get("dependencies", [])
    name        = data.get("name") or "project"
    version     = data.get("version") or "1.0.0"
    description = data.get("description") or ""

    facts = "\n".join(filter(None, [
        f"Project: {name} v{version}",
        f"Description: {description}" if description else None,
        ("Routes:\n" + "\n".join(f"  {r['method']} {r['path']}" for r in routes)) if routes else "No routes detected.",
        f"Auth strategies: {', '.join(auth.get('strategies', []))}" if auth.get("strategies") else None,
        f"Dockerfile present. Exposed ports: {', '.join(docker.get('exposedPorts', []))}." if docker.get("hasDockerfile") else None,
        f"Docker Compose services: {', '.join(docker.get('services', []))}." if docker.get("hasDockerCompose") else None,
        f"Environment variables: {', '.join(env_vars)}" if env_vars else None,
        f"Dependencies: {', '.join(dependencies[:15])}" if dependencies else None,
    ]))

    system_prompt = (
        "You are a senior Python engineer writing a README.md for an open source web project.\n"
        "Write clear, confident technical prose. Be concise but complete.\n"
        "Use ONLY the facts provided — do not invent anything.\n"
        "Structure: project name + tagline, what it is (2-4 sentences), features list, "
        "installation (pip install), usage, routes table, environment variables, "
        "Docker section only if present, contributing, license.\n"
        "Return only valid markdown."
    )

    print("Calling OpenRouter API...", file=sys.stderr)

    url = "https://openrouter.ai/api/v1/chat/completions"

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
        
    }

    payload = {
        "model": model,  # e.g. "openai/gpt-4o-mini" or "mistralai/mixtral-8x7b"
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": f"Confirmed facts:\n\n{facts}\n\nWrite the README.md."}
        ],
        "max_tokens": 2000,
        "temperature": 0.7
    }

    response = requests.post(url, headers=headers, json=payload)

    if response.status_code != 200:
        print(f"OpenRouter error: {response.text}", file=sys.stderr)
        sys.exit(1)

    result = response.json()
    readme = result["choices"][0]["message"]["content"]

    return readme

# ─── CLI ──────────────────────────────────────────────────────────────────────

def parse_args():
    parser = argparse.ArgumentParser(
        prog="grepme-x",
        description="Regex-powered README generator for Python web projects (Flask, Django, FastAPI)."
    )
    parser.add_argument("-o", "--output",  default="grepme-X.md",       help="Output file (default: README.md)")
    parser.add_argument("-i", "--ignore",  default="",                help="Comma-separated extra dirs to ignore")
    parser.add_argument("-f", "--format",  default="markdown",        choices=["markdown", "json"])
    parser.add_argument("-a", "--ai",      metavar="API_KEY",         help="Enable AI mode — Anthropic API key")
    parser.add_argument("-m", "--model",   default="minimax/minimax-m2.5:free", help=" (default: minimax/minimax-m2.5:free)")
    parser.add_argument("-d", "--dir",     default=".",               help="Project directory to scan (default: cwd)")
    return parser.parse_args()


def main():
    args = parse_args()

    extra_ignore = {s.strip() for s in args.ignore.split(",") if s.strip()}
    ignore = BASE_IGNORE | extra_ignore
    project_path = Path(args.dir).resolve()

    print(f"Scanning {project_path}...", file=sys.stderr)

    all_files = get_files(project_path, ignore)
    py_files  = [f for f in all_files if f.suffix == ".py"]

    routes:       list = []
    controllers:  list = []
    models:       list = []
    middleware:   list = []
    env_vars_set: set  = set()

    for file_path in py_files:
        content = safe_read(file_path)
        if not content:
            continue
        ftype = classify_file(file_path)
        if ftype in ("routes", "other"):
            routes.extend(extract_routes(content, file_path))
            middleware.extend(extract_middleware(content))
        if ftype in ("controllers", "routes", "other"):
            controllers.extend(extract_functions(content))
        if ftype == "models":
            models.extend(extract_schemas(content, file_path))
        for v in extract_env_vars(content):
            env_vars_set.add(v)

    # Deduplicate routes
    seen_routes, unique_routes = set(), []
    for r in routes:
        key = f"{r['method']}:{r['path']}"
        if key not in seen_routes:
            seen_routes.add(key)
            unique_routes.append(r)

    # Deduplicate middleware
    seen_mw, unique_mw = set(), []
    for mw in middleware:
        if mw["name"] not in seen_mw:
            seen_mw.add(mw["name"])
            unique_mw.append(mw)

    unique_controllers = sorted(set(controllers))
    pkg_info = get_package_info(project_path)
    tree     = build_tree(project_path, ignore)
    env_vars = sorted(env_vars_set)
    auth     = detect_auth(all_files, pkg_info.get("dependencies", []))
    docker   = get_docker_info(project_path)

    print(
        f"  Found {len(unique_routes)} routes, "
        f"{len(unique_controllers)} views, "
        f"{len(models)} models",
        file=sys.stderr
    )

    data = {
        **pkg_info,
        "routes":      unique_routes,
        "controllers": unique_controllers,
        "models":      models,
        "middleware":  unique_mw,
        "envVars":     env_vars,
        "tree":        tree,
        "auth":        auth,
        "docker":      docker,
    }

    output_path = project_path / args.output

    if args.format == "json":
        output_path.write_text(json.dumps(data, indent=2), encoding="utf-8")
        print(f"JSON written to {output_path}")
        return

    if args.ai:
        api_key = args.ai or os.environ.get("ANTHROPIC_API_KEY", "")
        if not api_key:
            print("No API key. Pass it with --ai YOUR_KEY or set ANTHROPIC_API_KEY.", file=sys.stderr)
            sys.exit(1)
        try:
            readme = generate_ai_readme(data, api_key, args.model)
            output_path.write_text(readme, encoding="utf-8")
            print(f"\nAI README written to {output_path}", file=sys.stderr)
        except Exception as e:
            print(f"AI generation failed: {e}\nFalling back to structured README...", file=sys.stderr)
            output_path.write_text(generate_markdown(data), encoding="utf-8")
            print(f"README written to {output_path}")
        return

    readme = generate_markdown(data)
    output_path.write_text(readme, encoding="utf-8")
    print(f"README generated -> {output_path}")


if __name__ == "__main__":
    main()