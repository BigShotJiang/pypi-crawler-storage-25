"""Test package for FasterAPI."""
