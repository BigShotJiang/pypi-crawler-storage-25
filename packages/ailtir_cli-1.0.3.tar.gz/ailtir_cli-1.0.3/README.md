# ailtir-cli

A CLI tool for interacting with Ailtir knowledge bases. Upload documents, trigger analysis, and query your knowledge bases from the terminal.

## What is ailtir-cli?

The Ailtir CLI provides commands for:
- **upload**: Upload a ZIP archive of documents to Ailtir storage
- **analyse**: Trigger knowledge base creation and analysis
- **list**: List all knowledge bases in your account
- **chat**: Ask questions answered using documents in a knowledge base (RAG)
- **version**: Print the CLI version

## Installation

```sh
uv tool install ailtir-cli
```

See [docs/index.html](./docs/index.html) for the full customer-facing installation guide.

## Documentation

- See [docs/index.html](./docs/index.html) for installation and usage guide (published at GitHub Pages)
- See [CLAUDE.md][] for architecture and implementation details
- See [CONTRIBUTING.md][] for development workflow and how to contribute

## License

MIT

[CLAUDE.md]: ./CLAUDE.md
[CONTRIBUTING.md]: ./CONTRIBUTING.md
