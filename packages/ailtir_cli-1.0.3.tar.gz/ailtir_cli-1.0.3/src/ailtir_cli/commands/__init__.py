import ailtir_cli.commands.analyse  # noqa: F401
import ailtir_cli.commands.chat  # noqa: F401
import ailtir_cli.commands.list_kbs  # noqa: F401
import ailtir_cli.commands.upload  # noqa: F401
import ailtir_cli.commands.version  # noqa: F401
