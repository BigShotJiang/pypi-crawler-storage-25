import httpx
import structlog
import typer
from rich.console import Console
from rich.table import Table

from ailtir_cli.app import app
from ailtir_cli.config import settings

_log = structlog.get_logger(__name__)
_console = Console()


@app.command(name="list")
def list_kbs() -> None:
    """List all knowledge bases in your Ailtir account."""
    token = settings.ailtir_cli_secret

    with httpx.Client(base_url=settings.cli_api_url, timeout=30.0) as http:
        try:
            resp = http.get("/kb", headers={"Authorization": f"Bearer {token}"})
            resp.raise_for_status()
        except httpx.HTTPStatusError as exc:
            _console.print(f"[red]Error: {exc.response.status_code}[/red]")
            raise typer.Exit(1) from exc

    kbs = resp.json()
    if not kbs:
        _console.print("No knowledge bases found.")
        return

    table = Table(title="Knowledge Bases")
    table.add_column("ID", style="dim")
    table.add_column("Name")
    table.add_column("Status")

    for kb in kbs:
        table.add_row(str(kb.get("id", "")), str(kb.get("name", "")), str(kb.get("status", "")))

    _log.info("list_kbs.returned", count=len(kbs))
    _console.print(table)
