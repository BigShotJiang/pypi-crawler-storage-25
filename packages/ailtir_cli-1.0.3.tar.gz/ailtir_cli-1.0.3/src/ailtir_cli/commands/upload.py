import pathlib

import httpx
import structlog
import typer
from rich.console import Console

from ailtir_cli.app import app
from ailtir_cli.config import settings

_log = structlog.get_logger(__name__)
_console = Console()


@app.command()
def upload(
    file_path: str = typer.Argument(..., help="Absolute path to the ZIP file to upload."),
) -> None:
    """Upload a ZIP archive of documents to Ailtir storage."""
    path = pathlib.Path(file_path)
    if not path.is_absolute():
        _console.print("[red]Error: file_path must be an absolute path.[/red]")
        raise typer.Exit(1)
    if not path.exists():
        _console.print(f"[red]Error: file not found: {file_path}[/red]")
        raise typer.Exit(1)
    if not path.is_file():
        _console.print(f"[red]Error: not a file: {file_path}[/red]")
        raise typer.Exit(1)

    _console.print(f"Uploading [bold]{path.name}[/bold]...")

    content = path.read_bytes()
    token = settings.ailtir_cli_secret

    with httpx.Client(base_url=settings.cli_api_url, timeout=30.0) as http:
        try:
            reg_resp = http.post(
                "/kb",
                json={"file_name": path.name},
                headers={"Authorization": f"Bearer {token}"},
            )
            reg_resp.raise_for_status()
        except httpx.HTTPStatusError as exc:
            _console.print(f"[red]Error registering KB: {exc.response.status_code}[/red]")
            raise typer.Exit(1) from exc

    reg = reg_resp.json()
    kb_id: str = reg["kb_id"]
    upload_url: str = reg["upload_url"]

    # PUT directly to S3 via the presigned URL — no auth header, S3 auth is in the URL.
    with httpx.Client(timeout=None) as s3_client:  # noqa: S113
        try:
            s3_resp = s3_client.put(
                upload_url,
                content=content,
                headers={"Content-Type": "application/zip"},
            )
            s3_resp.raise_for_status()
        except httpx.HTTPStatusError as exc:
            _console.print(f"[red]Error uploading to S3: {exc.response.status_code}[/red]")
            raise typer.Exit(1) from exc

    _log.info("upload.done", kb_id=kb_id)
    _console.print(f"[green]Upload complete.[/green] kb_id: [bold]{kb_id}[/bold]")
