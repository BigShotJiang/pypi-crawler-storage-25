import httpx
import structlog
import typer
from rich.console import Console

from ailtir_cli.app import app
from ailtir_cli.config import settings

_log = structlog.get_logger(__name__)
_console = Console()


@app.command()
def chat(
    kb_id: str = typer.Argument(..., help="The knowledge base ID to query."),
    question: str = typer.Argument(..., help="Your natural-language question."),
) -> None:
    """Ask a question answered using documents in a knowledge base (RAG)."""
    _console.print(f"Querying kb_id: [bold]{kb_id}[/bold]...")

    token = settings.ailtir_cli_secret

    with httpx.Client(base_url=settings.cli_api_url, timeout=60.0) as http:
        try:
            resp = http.post(
                f"/kb/{kb_id}/chat",
                json={"question": question},
                headers={"Authorization": f"Bearer {token}"},
            )
            resp.raise_for_status()
        except httpx.HTTPStatusError as exc:
            _console.print(f"[red]Error: {exc.response.status_code}[/red]")
            raise typer.Exit(1) from exc

    data = resp.json()
    _log.info("chat.answered", kb_id=kb_id)
    _console.print(data.get("answer", "No answer returned."))
