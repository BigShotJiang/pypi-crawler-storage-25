from importlib.metadata import version

from rich.console import Console

from ailtir_cli.app import app

_console = Console()


@app.command(name="version")
def get_version() -> None:
    """Print the version of the ailtir CLI."""
    _console.print(version("ailtir-cli"))
