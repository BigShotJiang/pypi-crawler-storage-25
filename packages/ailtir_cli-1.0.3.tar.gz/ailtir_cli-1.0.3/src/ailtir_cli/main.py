"""Entrypoint for the ailtir CLI."""

import ailtir_cli.commands  # noqa: F401 — registers all commands on app
from ailtir_cli.app import app

if __name__ == "__main__":
    app()
