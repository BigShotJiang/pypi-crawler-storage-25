from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    ailtir_cli_secret: str = Field(default="")
    cli_api_url: str = Field(default="https://app.ailtir.ai/cli-api")
    log_format: str = Field(default="console")
    log_level: str = Field(default="INFO")

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")


settings = Settings()
