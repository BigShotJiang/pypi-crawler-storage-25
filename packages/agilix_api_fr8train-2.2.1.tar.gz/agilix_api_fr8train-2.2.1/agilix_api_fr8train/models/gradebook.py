from typing import Optional as Opt


class GetEntityGradebookDefinition:
    entity_id: int
    all_status: bool
    enrollment_ids: Opt[list[int]]
    force_required_items: bool
    days_active_past_end: Opt[int]
    grading_scheme_id: Opt[str]
    grading_scheme: Opt[str]
    item_id: Opt[list[str]]
    scorm: bool
    select: Opt[list[str]]
    user_id: Opt[int]
    zero_unscored: bool
    version: int

    def __init__(self,
                 entity_id: int,
                 all_status: bool = False,
                 enrollment_ids: Opt[list[int]] = None,
                 force_required_items: bool = False,
                 days_active_past_end: Opt[int] = None,
                 grading_scheme_id: Opt[str] = None,
                 grading_scheme: Opt[str] = None,
                 item_id: Opt[list[str]] = ["*"],
                 scorm: bool = False,
                 select: list[str] = None,
                 user_id: Opt[int] = None,
                 zero_unscored: bool = False,
                 version: int = 2
                 ):
        self.entity_id = entity_id
        self.all_status = all_status
        self.enrollment_ids = enrollment_ids
        self.force_required_items = force_required_items
        self.days_active_past_end = days_active_past_end
        self.grading_scheme_id = grading_scheme_id
        self.grading_scheme = grading_scheme
        # ITEM ID POSSIBLE VALUES:
        # * = ALL GRADABLE ITEMS
        # ** = ALL ITEMS
        # itemid|itemid|... = SPECIFIC ITEMS
        # None = ONLY ROLLED UP ITEMS (period, category, course)
        self.item_id = item_id
        self.scorm = scorm
        self.select = select
        self.user_id = user_id
        self.zero_unscored = zero_unscored
        # CURRENT VERSIONS: (2, 3)
        self.version = version

    def __iter__(self):
        yield "entityid", self.entity_id
        yield "allstatus", self.all_status
        if self.enrollment_ids and self.version == 3:
            yield "enrollmentids", "|".join(map(str, self.enrollment_ids))
        yield "forcerequireditems", self.force_required_items
        if self.days_active_past_end and self.version == 2:
            yield "daysactivepastend", self.days_active_past_end
        if self.grading_scheme_id:
            yield "gradingschemeid", self.grading_scheme_id
        if self.grading_scheme:
            yield "gradingscheme", self.grading_scheme
        if self.item_id:
            yield "itemid", "|".join(self.item_id)
        yield "scorm", self.scorm
        if self.select:
            yield "select", ",".join(self.select)
        if self.user_id:
            yield "userid", self.user_id
        yield "zerounscored", self.zero_unscored