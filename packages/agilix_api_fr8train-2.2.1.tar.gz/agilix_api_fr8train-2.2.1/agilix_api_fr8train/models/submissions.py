from typing import Any, Optional as Opt


class GetStudentSubmissionInfoDefinition:
    enrollmentid: int
    itemid: str


class GetStudentSubmissionDefinition:
    enrollment_id: int
    filepath: Opt[str]
    inline: bool
    item_id: str
    package_type: str  # data|file|zip
    version: Opt[int]

    def __init__(
            self,
            enrollment_id: int,
            item_id: str,
            filepath: str = None,
            inline: bool = False,
            package_type: str = "data",
            version: int = None
    ):
        self.enrollment_id = enrollment_id
        self.filepath = filepath
        self.inline = inline
        self.item_id = item_id
        self.package_type = package_type
        self.version = version

    def __iter__(self):
        yield "enrollmentid", self.enrollment_id
        yield "itemid", self.item_id
        if self.package_type == "file":
            yield "filepath", self.filepath
        yield "inline", self.inline
        yield "packagetype", self.package_type
        if self.version is not None:
            yield "version", self.version


class PutTeacherResponsesDefinition:
    enrollment_id: int
    item_id: Any
    letter: Opt[str]
    response_type: Opt[str]
    submitted_date: Opt[str]
    mask: Opt[int]
    status: Opt[int]
    points_assigned: Opt[Any]
    points_possible: Opt[float]
    zero_unscored: bool
    scored_version: int

    def __init__(
            self,
            enrollment_id: int,
            item_id: Any,
            letter: str = None,
            type: str = None,
            submitted_date: str = None,
            mask: int = None,
            status: int = None,
            points_assigned: Any = None,
            points_possible: float = None,
            zero_unscored: bool = False,
            scored_version: int = 0,
    ):
        self.enrollment_id = enrollment_id
        self.item_id = item_id
        self.letter = letter
        self.response_type = type
        self.submitted_date = submitted_date
        self.mask = mask
        self.status = status
        self.points_assigned = points_assigned
        self.points_possible = points_possible
        self.zero_unscored = zero_unscored
        self.scored_version = scored_version

    def __iter__(self):
        yield "enrollmentid", self.enrollment_id
        yield "itemid", self.item_id
        if self.scored_version is not None:
            yield "scoredversion", self.scored_version
        if self.letter:
            yield "letter", self.letter
        if self.response_type:
            yield "type", self.response_type
        if self.submitted_date:
            yield "submitteddate", self.submitted_date
        if self.mask:
            yield "mask", self.mask
        if self.status:
            yield "status", self.status
        if self.points_assigned:
            yield "pointsassigned", self.points_assigned
        if self.points_possible:
            yield "pointspossible", self.points_possible
        if self.zero_unscored:
            yield "zerounscored", self.zero_unscored
