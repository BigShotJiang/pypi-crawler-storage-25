"""
Utilidades compartidas para conexión y operaciones con MySQL.
Usadas tanto por el servidor FastAPI como por el servidor MCP.
"""
import os
import re
import logging
from typing import Any, Dict, List, Optional
from urllib.parse import urlparse, unquote, parse_qs, quote

import mysql.connector
from mysql.connector import pooling, Error

logger = logging.getLogger("mysql-utils")


def parse_bool_env(value: Optional[str], default: bool = True) -> bool:
    """Parse boolean environment variables."""
    if value is None:
        return default
    return str(value).strip().lower() in ("1", "true", "yes", "y", "on")


def clean_env_string(value: Optional[str]) -> Optional[str]:
    """Limpia strings de variables de entorno removiendo comillas si existen."""
    if value is None:
        return None
    value = value.strip()
    # Remover comillas dobles o simples al inicio y final
    if (value.startswith('"') and value.endswith('"')) or (value.startswith("'") and value.endswith("'")):
        value = value[1:-1]
    return value


def parse_mysql_dsn(dsn: str) -> Dict[str, Any]:
    """
    Parsea un DSN como:
      mysql://user:password@host:3306/dbname?sslmode=require
    
    Escapa automáticamente caracteres especiales en usuario y contraseña para evitar
    problemas con urlparse (ej: corchetes que se interpretan como IPv6).
    
    sslmode:
      - disable -> no SSL
      - require -> SSL sin verificación de certificado (rejectUnauthorized=false)
      - cualquier otro valor (o vacío) -> SSL con verificación (si el driver lo soporta)
    """
    # Pre-procesar el DSN para escapar caracteres especiales en user:pass
    if "://" in dsn and "@" in dsn:
        scheme_part, rest = dsn.split("://", 1)
        if "@" in rest:
            credentials, host_part = rest.split("@", 1)
            if ":" in credentials:
                user, password = credentials.split(":", 1)
                # Escapar solo caracteres especiales que causan problemas
                user_escaped = quote(user, safe='')
                password_escaped = quote(password, safe='')
                dsn = f"{scheme_part}://{user_escaped}:{password_escaped}@{host_part}"
    
    parsed = urlparse(dsn)
    scheme = parsed.scheme.lower()
    if not scheme.startswith("mysql"):
        raise ValueError("DATABASE_URL debe usar esquema mysql://")

    user = unquote(parsed.username) if parsed.username else None
    password = unquote(parsed.password) if parsed.password else None
    host = parsed.hostname or "127.0.0.1"
    port = int(parsed.port or 3306)
    database = parsed.path.lstrip("/") if parsed.path else None
    if not database:
        raise ValueError("DATABASE_URL debe incluir el nombre de la base de datos en la path")

    # Debug: mostrar info de conexión (sin password completo)
    logger.info(f"Conectando a MySQL: user={user}, host={host}, port={port}, database={database}, password={'***' + password[-4:] if password and len(password) > 4 else '***'}")

    # Parsear query params (sslmode)
    query = parse_qs(parsed.query)
    sslmode = None
    if "sslmode" in query and len(query["sslmode"]) > 0:
        sslmode = query["sslmode"][0].lower()

    # Timeouts
    connection_timeout = int(os.getenv("DB_CONNECTION_TIMEOUT", "60"))

    # Preparar config para mysql.connector
    config: Dict[str, Any] = {
        "user": user,
        "password": password,
        "host": host,
        "port": port,
        "database": database,
        "autocommit": False,
        "connection_timeout": connection_timeout,
    }

    # Manejo de SSL
    if sslmode == "disable":
        config["ssl_disabled"] = True
    elif sslmode == "require":
        config["ssl_disabled"] = False
        config["ssl_verify_cert"] = False
    else:
        config["ssl_disabled"] = False
        config["ssl_verify_cert"] = True

    return config


class MySQLConnectionPool:
    """Singleton para pool de conexiones MySQL."""
    
    _instance = None
    _pool = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def initialize(self, database_url: str, pool_size: int = 5, pool_name: str = "mysql_pool"):
        """Inicializa el pool de conexiones."""
        if self._pool is not None:
            logger.warning("Pool ya inicializado, no se reinicializa")
            return
        
        db_config = parse_mysql_dsn(database_url)
        
        try:
            self._pool = pooling.MySQLConnectionPool(
                pool_name=pool_name,
                pool_size=pool_size,
                **{k: v for k, v in db_config.items() if k not in ("autocommit",)},
            )
            logger.info(f"Pool de conexiones creado: {pool_name} (size={pool_size})")
        except Error as e:
            logger.exception("No se pudo crear el pool de conexiones")
            raise
    
    def get_connection(self):
        """Obtiene una conexión del pool."""
        if self._pool is None:
            raise RuntimeError("Pool no inicializado. Llama a initialize() primero")
        
        try:
            conn = self._pool.get_connection()
            conn.autocommit = False
            return conn
        except Error as e:
            logger.exception("Error al obtener conexión del pool")
            raise


# Utilidades SQL
SEMICOLON_PATTERN = re.compile(r";")
LIMIT_PATTERN = re.compile(r"\blimit\b", re.IGNORECASE)
SELECT_START_PATTERN = re.compile(r"^\s*(select|show|describe|explain)\b", re.IGNORECASE)
CALL_START_PATTERN = re.compile(r"^\s*call\b", re.IGNORECASE)


def contains_semicolon(sql: str) -> bool:
    return bool(SEMICOLON_PATTERN.search(sql))


def is_read_query(sql: str) -> bool:
    return bool(SELECT_START_PATTERN.match(sql))


def is_call_statement(sql: str) -> bool:
    return bool(CALL_START_PATTERN.match(sql))


def apply_max_rows(sql: str, max_rows: int) -> str:
    """Aplica límite de filas a consultas SELECT."""
    if max_rows is None or max_rows <= 0:
        return sql
    
    if not is_read_query(sql):
        return sql
    
    if LIMIT_PATTERN.search(sql):
        return sql
    
    return f"{sql.rstrip()} LIMIT {int(max_rows)}"


def rows_to_dicts(cursor, rows):
    """Convierte filas de cursor a lista de diccionarios."""
    cols = cursor.column_names
    result = []
    for r in rows:
        result.append({col: val for col, val in zip(cols, r)})
    return result
