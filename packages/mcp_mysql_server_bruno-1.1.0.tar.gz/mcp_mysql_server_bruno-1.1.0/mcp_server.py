"""
MCP Server para MySQL - Expone operaciones MySQL via Model Context Protocol.
Uso: python mcp_server.py (se ejecuta en modo stdio para integración con clientes MCP)
"""
import asyncio
import os
import logging
from typing import Any, Dict, List, Optional
from dotenv import load_dotenv
from fastmcp import FastMCP, Context

from db_utils import (
    MySQLConnectionPool,
    clean_env_string,
    parse_bool_env,
    contains_semicolon,
    is_read_query,
    is_call_statement,
    apply_max_rows,
    rows_to_dicts,
)

# Cargar variables de entorno
load_dotenv()

# Logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("mcp-mysql-server")

# Configuración
DATABASE_URL = clean_env_string(os.getenv("DATABASE_URL"))
if not DATABASE_URL:
    raise RuntimeError("Se requiere la variable de entorno DATABASE_URL")

READ_ONLY = parse_bool_env(os.getenv("READ_ONLY"), default=True)
POOL_SIZE = int(os.getenv("DB_POOL_SIZE", "5"))
POOL_NAME = os.getenv("DB_POOL_NAME", "mcp_mysql_pool")

# Inicializar pool de conexiones
pool = MySQLConnectionPool()
pool.initialize(DATABASE_URL, POOL_SIZE, POOL_NAME)

# Crear servidor MCP
mcp = FastMCP("MySQL MCP Server")


@mcp.tool()
async def query_database(
    ctx: Context,
    sql: str,
    params: Optional[List[Any]] = None,
    limit: Optional[int] = None
) -> Dict[str, Any]:
    """
    Ejecuta una consulta de solo lectura (SELECT, SHOW, DESCRIBE, EXPLAIN) en MySQL.
    
    Args:
        sql: Consulta SQL a ejecutar
        params: Parámetros para la consulta (opcional)
        limit: Límite máximo de filas a retornar (opcional)
    
    Returns:
        Diccionario con 'rows' (lista de resultados) y 'count' (número de filas)
    """
    if contains_semicolon(sql):
        await ctx.error("No se permiten punto y coma ni múltiples sentencias")
        return {"error": "SQL inválido: múltiples sentencias no permitidas"}
    
    if not is_read_query(sql):
        await ctx.error("Solo se permiten consultas de lectura (SELECT/SHOW/DESCRIBE/EXPLAIN)")
        return {"error": "SQL no permitido: solo consultas de lectura"}
    
    try:
        conn = pool.get_connection()
        cursor = conn.cursor()
        params = params or []
        
        # Aplicar límite si se especifica
        sql_exec = sql
        if limit is not None and limit > 0:
            sql_exec = apply_max_rows(sql, limit)
        
        cursor.execute(sql_exec, tuple(params))
        rows = cursor.fetchall()
        result = rows_to_dicts(cursor, rows)
        
        cursor.close()
        conn.close()
        
        return {"rows": result, "count": len(result)}
    
    except Exception as e:
        await ctx.error(f"Error ejecutando consulta: {str(e)}")
        return {"error": str(e)}


@mcp.tool()
async def execute_statement(
    ctx: Context,
    sql: str,
    params: Optional[List[Any]] = None
) -> Dict[str, Any]:
    """
    Ejecuta una sentencia de escritura (INSERT, UPDATE, DELETE) en MySQL.
    Requiere que READ_ONLY=false en .env
    
    Args:
        sql: Sentencia SQL a ejecutar
        params: Parámetros para la sentencia (opcional)
    
    Returns:
        Diccionario con 'status' y 'affected_rows'
    """
    if READ_ONLY:
        await ctx.error("Servidor en modo READ_ONLY: no se permiten operaciones de escritura")
        return {"error": "Servidor en modo solo lectura"}
    
    if contains_semicolon(sql):
        await ctx.error("No se permiten punto y coma ni múltiples sentencias")
        return {"error": "SQL inválido: múltiples sentencias no permitidas"}
    
    if is_read_query(sql):
        await ctx.error("Use query_database para consultas de solo lectura")
        return {"error": "Use query_database para SELECT"}
    
    if is_call_statement(sql):
        await ctx.error("Use call_procedure para ejecutar procedimientos")
        return {"error": "Use call_procedure para CALL"}
    
    conn = None
    try:
        conn = pool.get_connection()
        cursor = conn.cursor()
        params = params or []
        
        cursor.execute(sql, tuple(params))
        affected = cursor.rowcount
        conn.commit()
        
        cursor.close()
        conn.close()
        
        return {"status": "ok", "affected_rows": affected}
    
    except Exception as e:
        if conn:
            try:
                conn.rollback()
            except:
                pass
        await ctx.error(f"Error ejecutando sentencia: {str(e)}")
        return {"error": str(e)}


@mcp.tool()
async def call_procedure(
    ctx: Context,
    procedure: str,
    params: Optional[List[Any]] = None
) -> Dict[str, Any]:
    """
    Ejecuta un procedimiento almacenado en MySQL.
    Requiere que READ_ONLY=false en .env
    
    Args:
        procedure: Nombre del procedimiento almacenado
        params: Parámetros del procedimiento (opcional)
    
    Returns:
        Diccionario con 'rows' (resultados del procedimiento)
    """
    if READ_ONLY:
        await ctx.error("Servidor en modo READ_ONLY: no se permiten llamadas a procedimientos")
        return {"error": "Servidor en modo solo lectura"}
    
    if not procedure or ";" in procedure:
        await ctx.error("Nombre de procedimiento inválido")
        return {"error": "Nombre de procedimiento inválido"}
    
    conn = None
    try:
        conn = pool.get_connection()
        cursor = conn.cursor()
        params = params or []
        
        cursor.callproc(procedure, tuple(params))
        
        # Recolectar resultados
        all_rows: List[Dict[str, Any]] = []
        for result in cursor.stored_results():
            rows = result.fetchall()
            cols = result.column_names
            for r in rows:
                all_rows.append({col: val for col, val in zip(cols, r)})
        
        conn.commit()
        cursor.close()
        conn.close()
        
        return {"rows": all_rows}
    
    except Exception as e:
        if conn:
            try:
                conn.rollback()
            except:
                pass
        await ctx.error(f"Error ejecutando procedimiento: {str(e)}")
        return {"error": str(e)}


@mcp.tool()
async def list_tables(ctx: Context, schema: Optional[str] = None) -> Dict[str, Any]:
    """
    Lista todas las tablas en la base de datos o esquema especificado.
    
    Args:
        schema: Nombre del esquema (opcional, usa el actual por defecto)
    
    Returns:
        Diccionario con 'tables' (lista de nombres de tablas)
    """
    try:
        conn = pool.get_connection()
        cursor = conn.cursor()
        
        if schema:
            cursor.execute(
                "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = %s ORDER BY TABLE_NAME",
                (schema,)
            )
        else:
            cursor.execute(
                "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() ORDER BY TABLE_NAME"
            )
        
        rows = cursor.fetchall()
        cursor.close()
        conn.close()
        
        return {"tables": [r[0] for r in rows]}
    
    except Exception as e:
        await ctx.error(f"Error listando tablas: {str(e)}")
        return {"error": str(e)}


@mcp.tool()
async def get_table_schema(ctx: Context, table: str, schema: Optional[str] = None) -> Dict[str, Any]:
    """
    Obtiene el esquema (columnas) de una tabla específica.
    
    Args:
        table: Nombre de la tabla
        schema: Nombre del esquema (opcional)
    
    Returns:
        Diccionario con 'columns' (lista de información de columnas)
    """
    if not table or ";" in table:
        await ctx.error("Nombre de tabla inválido")
        return {"error": "Nombre de tabla inválido"}
    
    try:
        conn = pool.get_connection()
        cursor = conn.cursor()
        
        if schema:
            cursor.execute("""
                SELECT COLUMN_NAME, DATA_TYPE, IS_NULLABLE, COLUMN_DEFAULT, COLUMN_KEY, EXTRA
                FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s
                ORDER BY ORDINAL_POSITION
            """, (schema, table))
        else:
            cursor.execute("""
                SELECT COLUMN_NAME, DATA_TYPE, IS_NULLABLE, COLUMN_DEFAULT, COLUMN_KEY, EXTRA
                FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s
                ORDER BY ORDINAL_POSITION
            """, (table,))
        
        rows = cursor.fetchall()
        cursor.close()
        conn.close()
        
        columns = []
        for r in rows:
            columns.append({
                "column_name": r[0],
                "data_type": r[1],
                "is_nullable": r[2],
                "column_default": r[3],
                "column_key": r[4],
                "extra": r[5],
            })
        
        return {"columns": columns}
    
    except Exception as e:
        await ctx.error(f"Error obteniendo esquema de tabla: {str(e)}")
        return {"error": str(e)}


@mcp.tool()
async def list_schemas(ctx: Context) -> Dict[str, Any]:
    """
    Lista todos los esquemas (bases de datos) disponibles.
    
    Returns:
        Diccionario con 'schemas' (lista de nombres de esquemas)
    """
    try:
        conn = pool.get_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA ORDER BY SCHEMA_NAME")
        rows = cursor.fetchall()
        
        cursor.close()
        conn.close()
        
        return {"schemas": [r[0] for r in rows]}
    
    except Exception as e:
        await ctx.error(f"Error listando esquemas: {str(e)}")
        return {"error": str(e)}


def main():
    """Punto de entrada principal para el servidor MCP."""
    logger.info(f"Iniciando MySQL MCP Server (READ_ONLY={READ_ONLY})")
    mcp.run()


if __name__ == "__main__":
    main()
