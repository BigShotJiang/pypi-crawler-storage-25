from typing import Literal, TypedDict

from langgraph.graph import MessagesState


class Query(TypedDict):
    content: str


class IsAnswerable(TypedDict):
    response: Literal["yes", "no"]


class AgentState(MessagesState):
    query: Query | None
    documents: list[dict[str, str]] | None
    is_answerable: IsAnswerable | None
