import logging
from abc import ABC, abstractmethod
from typing import Any

from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import AIMessage, BaseMessage, SystemMessage
from langchain_core.messages.utils import AnyMessage
from langchain_core.runnables import Runnable
from langgraph._internal._typing import StateLike
from langgraph.graph._node import _Node

from agents_builder import Agent
from agents_builder.mixins import FromConfigMixin
from agents_builder.settings import DeletionStrategySettings

logger = logging.getLogger(__name__)


class Prompt[TState: StateLike](ABC):
    @classmethod
    @abstractmethod
    def format_prompt(cls, state: TState) -> str: ...

    @classmethod
    def render(cls, state: TState) -> list[BaseMessage]:
        content = cls.format_prompt(state)
        return [
            *state["messages"],  # ty: ignore[not-subscriptable]
            SystemMessage(content=content),
        ]


class SchemaBasedPrompt[TState: StateLike](Prompt[TState], ABC):
    @classmethod
    @abstractmethod
    def get_schema(cls) -> Any: ...


class DeletionStrategy[TConfig: DeletionStrategySettings](FromConfigMixin[TConfig]):
    def __init__(self, config: TConfig) -> None:
        self.config = config

    @abstractmethod
    def _delete(self, messages: list[AnyMessage]) -> list[AnyMessage]: ...

    def delete(self, messages: list[AnyMessage]) -> list[AnyMessage]:
        before_count = len(messages)
        logger.debug(f"DeletionStrategy.start | strategy={self.__class__.__name__} | messages_before={before_count}")
        new_messages = self._delete(messages)
        after_count = len(new_messages)
        removed = before_count - after_count
        logger.info(
            f"DeletionStrategy.done | strategy={self.__class__.__name__} | removed={removed} | remaining={after_count}"
        )
        return new_messages


class Node[TState: StateLike](_Node[TState]):
    def __init__(self, name: str) -> None:
        self.name = name

    async def __call__(self, state: TState) -> Any: ...


class RouterNode[TState: StateLike](Node[TState]):
    def __init__(self, name: str) -> None:
        super().__init__(name)


class ToolBasedNode[TState: StateLike](Node[TState]):
    def __init__(self, name: str, agent: Agent[Any], mcp_name: str, tool_key: str):
        super().__init__(name)
        self.agent = agent
        self.mcp_name = mcp_name
        self.tool_key = tool_key


class LLMNode[TState: StateLike](Node[TState]):
    def __init__(
        self,
        name: str,
        model: BaseChatModel,
        prompt: type[Prompt[TState]],
        structured_output: dict | type | None,
    ):
        super().__init__(name)
        runnable: Runnable[list[BaseMessage], AIMessage] = model

        if structured_output:
            runnable = runnable.with_structured_output(structured_output)  # ty: ignore[invalid-assignment]
        self.runnable = runnable
        self.prompt = prompt

    async def _ainvoke(self, state: TState) -> AIMessage:
        messages = self.prompt.render(state)
        return await self.runnable.ainvoke(messages)
