import json
from typing import Any

from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.tools.base import BaseTool

from agents_builder import Agent
from agents_builder.exceptions import MissingStateKeyError
from agents_builder.langgraph import (
    LLMNode,
    Prompt,
    RouterNode,
    SchemaBasedPrompt,
    ToolBasedNode,
)
from agents_builder.langgraph.states import AgentState


class GenerateQueryLLMNode(LLMNode[AgentState]):  # ty: ignore[invalid-type-arguments]
    def __init__(self, name: str, model: BaseChatModel, prompt: type[SchemaBasedPrompt]):
        super().__init__(
            name=name,
            model=model,
            prompt=prompt,
            structured_output=prompt.get_schema(),
        )

    async def __call__(self, state: AgentState) -> Any:
        query = await self._ainvoke(state)
        return {"query": query}


class SearchDocumentsNode(ToolBasedNode[AgentState]):  # ty: ignore[invalid-type-arguments]
    def __init__(self, name: str, agent: Agent[Any], mcp_name: str, tool_key: str):
        super().__init__(name=name, agent=agent, mcp_name=mcp_name, tool_key=tool_key)
        self.retriever_tool: BaseTool | None = None

    async def __call__(self, state: AgentState) -> Any:
        if self.retriever_tool is None:
            self.retriever_tool = await self.agent.load_tool(self.mcp_name, self.tool_key)
        if state["query"] is None:
            raise MissingStateKeyError("query")
        # Call the retriever tool asynchronously
        tool_result = (await self.retriever_tool.arun({"query": state["query"]["content"]}))[0]
        # Parse tool output
        payload = json.loads(tool_result["text"])
        evidence = payload["retrieval"]["evidence"]
        # Return state update
        return {"documents": evidence}


class GraderLLMNode(LLMNode[AgentState]):  # ty: ignore[invalid-type-arguments]
    def __init__(self, name: str, model: BaseChatModel, prompt: type[SchemaBasedPrompt]):
        super().__init__(
            name=name,
            model=model,
            prompt=prompt,
            structured_output=prompt.get_schema(),
        )

    async def __call__(self, state: AgentState) -> Any:
        return {"is_answerable": (await self._ainvoke(state))}


class GenerateAnswerLLMNode(LLMNode[AgentState]):  # ty: ignore[invalid-type-arguments]
    def __init__(self, name: str, model: BaseChatModel, prompt: type[Prompt]):
        super().__init__(
            name=name,
            model=model,
            prompt=prompt,
            structured_output=None,
        )

    async def __call__(self, state: AgentState) -> Any:
        response = await self._ainvoke(state)
        return {"messages": [response]}


class AnswerFailureLLMNode(LLMNode[AgentState]):  # ty: ignore[invalid-type-arguments]
    def __init__(self, name: str, model: BaseChatModel, prompt: type[Prompt]):
        super().__init__(
            name=name,
            model=model,
            prompt=prompt,
            structured_output=None,
        )

    async def __call__(self, state: AgentState) -> Any:
        response = await self._ainvoke(state)
        return {"messages": [response]}


class IrrelevantQueryLLMNode(LLMNode[AgentState]):  # ty: ignore[invalid-type-arguments]
    def __init__(self, name: str, model: BaseChatModel, prompt: type[Prompt]):
        super().__init__(
            name=name,
            model=model,
            prompt=prompt,
            structured_output=None,
        )

    async def __call__(self, state: AgentState) -> Any:
        response = await self._ainvoke(state)
        return {"messages": [response]}


class IsQueryRelevantRouterNode(RouterNode[AgentState]):  # ty: ignore[invalid-type-arguments]
    def __init__(self, name: str) -> None:
        super().__init__(name=name)

    async def __call__(self, state: AgentState) -> Any:
        if state["query"] and state["query"]["content"] != "[NAN]":  # type: ignore[index]
            return "yes"
        return "no"


class IsDocumentRelevantRouterNode(RouterNode[AgentState]):  # ty: ignore[invalid-type-arguments]
    def __init__(self, name: str) -> None:
        super().__init__(name=name)

    async def __call__(self, state: AgentState) -> Any:
        if state["is_answerable"] is None:
            raise MissingStateKeyError("is_answerable")
        return state["is_answerable"]["response"]
