from typing import Annotated, Any, Literal

from pydantic import Field
from pydantic_settings import (
    BaseSettings,
    PydanticBaseSettingsSource,
    SettingsConfigDict,
    YamlConfigSettingsSource,
)

from agents_builder.constants import CONFIG_PATH


class FromConfigMixinSettings(BaseSettings):
    module_path: str
    model_config = SettingsConfigDict(
        yaml_file=CONFIG_PATH,
        extra="ignore",
    )

    @classmethod
    def settings_customise_sources(
        cls,
        settings_cls: type[BaseSettings],
        init_settings: PydanticBaseSettingsSource,
        env_settings: PydanticBaseSettingsSource,
        dotenv_settings: PydanticBaseSettingsSource,
        file_secret_settings: PydanticBaseSettingsSource,
    ) -> tuple[PydanticBaseSettingsSource, ...]:
        return (
            init_settings,
            YamlConfigSettingsSource(settings_cls),
            env_settings,
            dotenv_settings,
            file_secret_settings,
        )


class MCPServerSettings(BaseSettings):
    name: str
    url: str


class LLMSettings(FromConfigMixinSettings):
    model: str


class OllamaLLMSettings(LLMSettings):
    kind: Literal["ollama"]
    base_url: str


class OpenRouterLLMSettings(LLMSettings):
    kind: Literal["openrouter"]
    model_kwargs: dict[str, Any]
    provider: dict[str, Any] | None


AnyLLMSettings = Annotated[
    OllamaLLMSettings | OpenRouterLLMSettings,
    Field(discriminator="kind"),
]


class LLMFactorySettings(FromConfigMixinSettings):
    roles: dict[str, AnyLLMSettings]


class DeletionStrategySettings(FromConfigMixinSettings):
    pass


class AgentSettings(FromConfigMixinSettings):
    llm_factory: LLMFactorySettings
    mcps: list[MCPServerSettings]


class TrimDeletionStrategySettings(DeletionStrategySettings):
    strategy: Literal["first", "last"]
    max_tokens: int
    start_on: str
    end_on: tuple[str, str]


class BaseAgentSettings(AgentSettings):
    pass
