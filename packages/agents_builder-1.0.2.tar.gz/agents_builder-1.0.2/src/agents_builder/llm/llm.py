import logging
from typing import Self

from langchain_core.language_models.chat_models import BaseChatModel
from langchain_ollama import ChatOllama
from langchain_openrouter import ChatOpenRouter

from agents_builder.llm import LLM
from agents_builder.settings import OllamaLLMSettings, OpenRouterLLMSettings

_logger = logging.getLogger(__name__)


class OllamaLLM(LLM[OllamaLLMSettings]):
    def __init__(self, config: OllamaLLMSettings):
        super().__init__(config)

    def to_langchain(self) -> BaseChatModel:
        model = ChatOllama(model=self.config.model, base_url=self.config.base_url)
        _logger.info(f"Chat model ready: {self.config.model}")
        return model

    def with_streaming(self, streaming: bool = True) -> Self:
        # Ollama streams based on call method (astream), not config
        return self


class OpenRouterLLM(LLM[OpenRouterLLMSettings]):
    def __init__(self, config: OpenRouterLLMSettings):
        super().__init__(config)
        self.streaming = False

    def with_streaming(self, streaming: bool = True) -> Self:
        self.streaming = streaming
        return self

    def to_langchain(self) -> BaseChatModel:
        _logger.info(f"Initializing OpenRouter model: {self.config.model}")
        model = ChatOpenRouter(
            model=self.config.model,
            model_kwargs=self.config.model_kwargs,
            openrouter_provider=self.config.provider,  # raw dict
            streaming=self.streaming,
        )
        _logger.info(f"OpenRouter Chat model ready: {self.config.model}")
        return model
