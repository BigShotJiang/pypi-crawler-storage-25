from abc import ABC, abstractmethod
from typing import Self

from langchain_core.language_models.chat_models import BaseChatModel

from agents_builder.exceptions import StreamingNotSupportedError
from agents_builder.mixins import FromConfigMixin
from agents_builder.settings import LLMSettings


class LLM[TConfig: LLMSettings](FromConfigMixin[TConfig], ABC):
    def __init__(self, config: TConfig):
        super().__init__(config)

    @abstractmethod
    def to_langchain(self) -> BaseChatModel: ...

    def with_streaming(self, streaming: bool = True) -> Self:
        raise StreamingNotSupportedError("Streaming not supported for this LLM")
