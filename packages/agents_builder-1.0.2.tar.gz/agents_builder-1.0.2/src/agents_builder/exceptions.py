# agents_builder/exceptions.py


class AgenticBuilderError(Exception):
    """Base exception for the package"""


# -------------------------
# MESSAGE / STATE
# -------------------------
class MessageError(AgenticBuilderError):
    pass


class NoHumanMessageError(MessageError):
    pass


class InvalidStateError(AgenticBuilderError):
    pass


class MissingStateKeyError(InvalidStateError):
    def __init__(self, key: str):
        super().__init__(f"Missing or None key '{key}' in state dict")
        self.key = key


# -------------------------
# MCP / TOOLS
# -------------------------
class MCPError(AgenticBuilderError):
    pass


class MCPNotConfiguredError(MCPError):
    def __init__(self, tool_key: str):
        super().__init__(f"No MCP configured for tool '{tool_key}'")


class MCPToolNotFoundError(MCPError):
    def __init__(self, tool_key: str, mcp_name: str, available: list[str]):
        super().__init__(f"Tool '{tool_key}' not found in MCP '{mcp_name}'. Available: {available}")
        self.tool_key = tool_key
        self.mcp_name = mcp_name
        self.available = available


# -------------------------
# GRAPH / AGENT
# -------------------------
class GraphError(AgenticBuilderError):
    pass


# -------------------------
# PROMPTS
# -------------------------
class PromptError(AgenticBuilderError):
    pass


# -------------------------
# STRATEGIES
# -------------------------
class StrategyError(AgenticBuilderError):
    pass


# -------------------------
# LLM
# -------------------------
class LLMError(AgenticBuilderError):
    pass


class InvalidLLMRoleError(LLMError):
    def __init__(self, role: str, available: list[str]):
        super().__init__(f"LLM role '{role}' not defined. Available roles: {available}")


class InvalidLLMClassError(LLMError):
    pass


class StreamingNotSupportedError(LLMError):
    pass
