from pathlib import Path
from typing import Any, Self, get_args

import yaml

from agents_builder.settings import FromConfigMixinSettings


class FromConfigMixin[TConfig: FromConfigMixinSettings]:
    def __init__(self, config: TConfig) -> None:
        self.config = config

    @classmethod
    def get_config_class(cls) -> type[TConfig]:
        return get_args(cls.__orig_bases__[0])[0]  # type: ignore

    @classmethod
    def from_config(
        cls,
        config: TConfig,
    ) -> Self:
        return cls(config)

    @classmethod
    def from_yaml(
        cls,
        path: str,
        key: str | None = None,
    ) -> Self:
        """
        Load a runtime object from YAML.

        Args:
            yaml_path: Path to YAML config file
            settings_cls: Pydantic Settings model to validate config
            key: Optional top-level YAML key (e.g. "retriever")

        Returns:
            Instantiated runtime object
        """
        yaml_path = Path(path)
        with yaml_path.open("r") as f:
            raw: dict[str, Any] = yaml.safe_load(f)
        if key is not None:
            raw = raw[key]
        config = cls.get_config_class().model_validate(raw)
        return cls.from_config(config)

    @classmethod
    async def create(cls, config: TConfig) -> Self:
        return cls.from_config(config)

    @classmethod
    async def from_yaml_async(
        cls,
        path: str,
        key: str | None = None,
    ) -> Self:
        yaml_path = Path(path)
        with yaml_path.open("r") as f:
            raw: dict[str, Any] = yaml.safe_load(f)

        if key is not None:
            raw = raw[key]
        config_cls: type[TConfig] = cls.get_config_class()
        config = config_cls.model_validate(raw)
        return await cls.create(config)

    @classmethod
    def from_settings(cls) -> Self:
        """
        Load runtime object using Pydantic Settings resolution:
        init > yaml > env > dotenv > secrets
        """
        config = cls.get_config_class()()  # ty: ignore[missing-argument]
        return cls.from_config(config)
