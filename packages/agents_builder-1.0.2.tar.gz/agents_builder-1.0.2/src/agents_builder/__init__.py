import asyncio
import logging
from abc import ABC, abstractmethod
from datetime import datetime
from pathlib import Path

from langchain.tools import BaseTool
from langgraph.graph.state import CompiledStateGraph

from agents_builder.exceptions import (
    MCPNotConfiguredError,
    MCPToolNotFoundError,
)
from agents_builder.llm.factory import LLMFactory
from agents_builder.mixins import FromConfigMixin
from agents_builder.settings import AgentSettings
from agents_builder.utils import _cached_mcp_tools, load_class

_logger = logging.getLogger(__name__)


class Agent[TConfig: AgentSettings](FromConfigMixin[TConfig], ABC):
    """
    Initializes and runs a LangChain agent backed by VLLM and Qdrant embeddings.
    Minimal version: no exception catching, f-string logs only.
    """

    def __init__(self, config: TConfig) -> None:
        self.config = config
        self._graph: CompiledStateGraph | None = None
        self.init_components()
        _logger.info("Agent initialized")

    @property
    def graph(self) -> CompiledStateGraph:
        if self._graph is None:
            _logger.info("Graph not initialized → building graph")
            self._graph = self.build_graph()
        return self._graph

    async def load_tool(self, mcp_name: str, key: str) -> BaseTool:
        # ✅ cache hit
        if key in self._tools_by_name:
            return self._tools_by_name[key]
        async with self._tool_lock:
            # double-check (important)
            if key in self._tools_by_name:
                return self._tools_by_name[key]
            # 🔥 find the correct MCP
            mcp = next(
                (m for m in self.config.mcps if m.name == mcp_name),
                None,
            )
            if mcp is None:
                raise MCPNotConfiguredError(tool_key=key)
            # 🔥 load ONLY this MCP
            tools = await _cached_mcp_tools(
                mcps_fingerprint=f"{mcp.name}:{mcp.url}",
                mcps_config=[mcp],  # 👈 only ONE MCP
            )
            # cache all tools from this MCP (usually few)
            for tool in tools:
                self._tools_by_name[tool.name] = tool
        if key not in self._tools_by_name:
            raise MCPToolNotFoundError(
                tool_key=key,
                mcp_name=mcp.name,
                available=list(self._tools_by_name.keys()),
            )
        return self._tools_by_name[key]

    def init_components(self) -> None:
        self.llm_factory: LLMFactory = load_class(self.config.llm_factory.module_path).from_config(
            self.config.llm_factory
        )
        self._tools_by_name: dict[str, BaseTool] = {}
        self._tool_lock = asyncio.Lock()
        _logger.info("Agent created")

    def push(self, path: str | None = None) -> None:
        # Timestamp: YYYYMMDD_HHMMSS
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        # Optional: include agent name / class
        agent_name = self.__class__.__name__
        # Build filename
        filename = f"{agent_name}_graph_{timestamp}.png"
        # Full path
        full_path: Path = Path(path) / filename if path else Path(".") / filename
        # Draw + save
        png_bytes = self.graph.get_graph().draw_mermaid_png()
        full_path.write_bytes(png_bytes)
        _logger.info(f"Graph saved locally at {full_path}")

    @abstractmethod
    def build_graph(self) -> CompiledStateGraph: ...
