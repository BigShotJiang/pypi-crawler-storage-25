from collections.abc import Callable
from typing import TYPE_CHECKING, Any, TypeVar

from langchain_core.tools.base import BaseTool

if TYPE_CHECKING:
    from agents_builder.settings import (
        AgentSettings,
        DeletionStrategySettings,
        FromConfigMixinSettings,
        LLMSettings,
    )

TNode = TypeVar("TNode")
ToolLike = dict[str, Any] | type | Callable | BaseTool
StructuredOutput = dict[str, Any] | type[Any] | None
TCFromConfigMixin = TypeVar("TCFromConfigMixin", bound="FromConfigMixinSettings")
TCAgent = TypeVar("TCAgent", bound="AgentSettings")
TCDeletionStrategy = TypeVar("TCDeletionStrategy", bound="DeletionStrategySettings")

TCLLM = TypeVar("TCLLM", bound="LLMSettings")
TCAgentSettings = TypeVar("TCAgentSettings", bound="AgentSettings")

CONFIG_PATH = "/config/config.yaml"
