# Copyright 2026 Vijil, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# AUTO-GENERATED from specs/service_agent_environment.json — do not edit manually.
# Re-generate with: make generate-mcp

from __future__ import annotations

from typing import Any

from vijil_mcp.server import server
from vijil_mcp.tools._runner import run_vijil


@server.tool()
def inventory_scan(
    regions: str | None = None,
    permission_tier: str | None = None,
    scan_tier: str | None = None,
    all_regions: bool = False,
    provider: str | None = None,
) -> str:
    """
    Create Scan

    Args:
        regions: Regions (JSON array string)
        permission_tier: IAM permission level requested of the vijil-discover role.  Mirrors the ``permission_tier`` flag accepted by vijil-discover. Extend this enum when vijil...
        scan_tier: Network scan aggressiveness for vijil-discover.  Mirrors the ``network.scan_tier`` key accepted by vijil-discover. (one of: passive, active)
        all_regions: All Regions
        provider: Cloud provider (or mock) for vijil-discover.  ``mock`` uses vijil-discover's built-in mock provider — no real AWS calls, returns synthetic resources. Useful fo...
    """
    args: dict[str, Any] = {}
    args["regions"] = regions
    args["permission_tier"] = permission_tier
    args["scan_tier"] = scan_tier
    args["all_regions"] = all_regions
    args["provider"] = provider
    return run_vijil("inventory", "scan", args)

@server.tool()
def inventory_scan_list(limit: int | None = None, offset: int | None = None) -> str:
    """
    List Scans

    Args:
        limit: limit
        offset: offset
    """
    args: dict[str, Any] = {}
    args["limit"] = limit
    args["offset"] = offset
    return run_vijil("inventory", "scan-list", args)

@server.tool()
def inventory_scan_get(scan_id: str) -> str:
    """
    Get Scan

    Args:
        scan_id: The scan id
    """
    return run_vijil("inventory", "scan-get", {}, positional=[scan_id])

@server.tool()
def inventory_scan_cancel(scan_id: str) -> str:
    """
    Cancel Scan

    Args:
        scan_id: The scan id
    """
    return run_vijil("inventory", "scan-cancel", {}, positional=[scan_id])

@server.tool()
def inventory_scan_resources(scan_id: str, limit: int | None = None, offset: int | None = None) -> str:
    """
    List Scan Resources

    Args:
        scan_id: The scan id
        limit: limit
        offset: offset
    """
    args: dict[str, Any] = {}
    args["limit"] = limit
    args["offset"] = offset
    return run_vijil("inventory", "scan-resources", args, positional=[scan_id])

@server.tool()
def inventory_schedule(
    enabled: bool,
    regions: str | None = None,
    permission_tier: str | None = None,
    scan_tier: str | None = None,
    all_regions: bool = False,
    provider: str | None = None,
) -> str:
    """
    Upsert Schedule

    Args:
        enabled: Enabled
        regions: Regions (JSON array string)
        permission_tier: IAM permission level requested of the vijil-discover role.  Mirrors the ``permission_tier`` flag accepted by vijil-discover. Extend this enum when vijil...
        scan_tier: Network scan aggressiveness for vijil-discover.  Mirrors the ``network.scan_tier`` key accepted by vijil-discover. (one of: passive, active)
        all_regions: All Regions
        provider: Cloud provider (or mock) for vijil-discover.  ``mock`` uses vijil-discover's built-in mock provider — no real AWS calls, returns synthetic resources. Useful fo...
    """
    args: dict[str, Any] = {}
    args["enabled"] = enabled
    args["regions"] = regions
    args["permission_tier"] = permission_tier
    args["scan_tier"] = scan_tier
    args["all_regions"] = all_regions
    args["provider"] = provider
    return run_vijil("inventory", "schedule", args)

@server.tool()
def inventory_resources(
    status: list[str] | None = None,
    agent_id: str | None = None,
    resource_type: list[str] | None = None,
    limit: int | None = None,
    offset: int | None = None,
) -> str:
    """
    List Resources

    Args:
        status: Filter by resource status(es). Repeat for multiple (e.g. ?status=candidate&status=matched). When omitted, defaults to ['candidate'].
        agent_id: Filter by linked agent ID.
        resource_type: Filter by resource type(s). Repeat for multiple (e.g. ?resource_type=agent&resource_type=guardrail).
        limit: limit
        offset: offset
    """
    args: dict[str, Any] = {}
    args["status"] = status
    args["agent_id"] = agent_id
    args["resource_type"] = resource_type
    args["limit"] = limit
    args["offset"] = offset
    return run_vijil("inventory", "resources", args)

@server.tool()
def inventory_resource_get(resource_id: str) -> str:
    """
    Get Resource

    Args:
        resource_id: The resource id
    """
    return run_vijil("inventory", "resource-get", {}, positional=[resource_id])

@server.tool()
def inventory_resource_update(resource_id: str, agent_id: str) -> str:
    """
    Update Resource

    Args:
        resource_id: The resource id
        agent_id: Agent to associate. Set UUID to link (MATCHED), null to unlink (CANDIDATE).
    """
    args: dict[str, Any] = {}
    args["agent_id"] = agent_id
    return run_vijil("inventory", "resource-update", args, positional=[resource_id])

@server.tool()
def inventory_resource_delete(resource_id: str) -> str:
    """
    Delete Resource

    Args:
        resource_id: The resource id
    """
    return run_vijil("inventory", "resource-delete", {}, positional=[resource_id], skip_confirm=True)

@server.tool()
def inventory_save(resource_id: str, name: str | None = None, notes: str | None = None) -> str:
    """
    Save Resource

    Args:
        resource_id: The resource id
        name: Optional display name for the pending agent.
        notes: Freeform notes recorded on the agent metadata.
    """
    args: dict[str, Any] = {}
    args["name"] = name
    args["notes"] = notes
    return run_vijil("inventory", "save", args, positional=[resource_id])

@server.tool()
def inventory_dismiss(resource_id: str) -> str:
    """
    Dismiss Resource

    Args:
        resource_id: The resource id
    """
    return run_vijil("inventory", "dismiss", {}, positional=[resource_id])

@server.tool()
def inventory_bulk_save(resource_ids: str, notes: str | None = None) -> str:
    """
    Bulk Save

    Args:
        resource_ids: Resource Ids (JSON array string)
        notes: Notes
    """
    args: dict[str, Any] = {}
    args["resource_ids"] = resource_ids
    args["notes"] = notes
    return run_vijil("inventory", "bulk-save", args)

@server.tool()
def inventory_bulk_dismiss(resource_ids: str) -> str:
    """
    Bulk Dismiss

    Args:
        resource_ids: Resource Ids (JSON array string)
    """
    args: dict[str, Any] = {}
    args["resource_ids"] = resource_ids
    return run_vijil("inventory", "bulk-dismiss", args)
