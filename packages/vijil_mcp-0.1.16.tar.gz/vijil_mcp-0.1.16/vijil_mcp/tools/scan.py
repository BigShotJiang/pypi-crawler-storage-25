# Copyright 2026 Vijil, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# AUTO-GENERATED from specs/service_agent_environment.json — do not edit manually.
# Re-generate with: make generate-mcp

from __future__ import annotations

from typing import Any

from vijil_mcp.server import server
from vijil_mcp.tools._runner import run_vijil


@server.tool()
def scan_run(
    scm_installation_id: str,
    repo_owner: str,
    repo_name: str,
    ref: str,
    scan_target_type: str | None = None,
    scan_mode: str | None = None,
    external_repository_id: str | None = None,
    wait: bool = False,
) -> str:
    """
    Create Scan

    Args:
        scm_installation_id: Scm Installation Id
        repo_owner: Repo Owner
        repo_name: Repo Name
        ref: Branch, tag, or commit SHA to scan
        scan_target_type: What kind of ref is being scanned. (one of: branch, tag, commit)
        scan_mode: Scan analysis mode. (one of: full_repo, diff)
        external_repository_id: External Repository Id
        wait: Poll until the operation reaches a terminal state (completed/failed/cancelled)
    """
    args: dict[str, Any] = {}
    args["scm_installation_id"] = scm_installation_id
    args["repo_owner"] = repo_owner
    args["repo_name"] = repo_name
    args["ref"] = ref
    args["scan_target_type"] = scan_target_type
    args["scan_mode"] = scan_mode
    args["external_repository_id"] = external_repository_id
    return run_vijil("scan", "run", args, wait=wait)

@server.tool()
def scan_list(
    limit: int | None = None,
    offset: int | None = None,
    status_filter: list[str] | None = None,
    review_status: list[str] | None = None,
    agent_id: str | None = None,
    repo_owner: str | None = None,
    repo_name: str | None = None,
) -> str:
    """
    List Scans

    Args:
        limit: limit
        offset: offset
        status_filter: status_filter
        review_status: review_status
        agent_id: agent_id
        repo_owner: repo_owner
        repo_name: repo_name
    """
    args: dict[str, Any] = {}
    args["limit"] = limit
    args["offset"] = offset
    args["status_filter"] = status_filter
    args["review_status"] = review_status
    args["agent_id"] = agent_id
    args["repo_owner"] = repo_owner
    args["repo_name"] = repo_name
    return run_vijil("scan", "list", args)

@server.tool()
def scan_get(scan_id: str) -> str:
    """
    Get Scan

    Args:
        scan_id: The scan id
    """
    return run_vijil("scan", "get", {}, positional=[scan_id])

@server.tool()
def scan_cancel(scan_id: str) -> str:
    """
    Cancel Scan

    Args:
        scan_id: The scan id
    """
    return run_vijil("scan", "cancel", {}, positional=[scan_id], skip_confirm=True)

@server.tool()
def scan_list_repos(installation_id: str) -> str:
    """
    List Repos

    Args:
        installation_id: The installation id
    """
    return run_vijil("scan", "list-repos", {}, positional=[installation_id])

@server.tool()
def scan_list_installations(limit: int | None = None, offset: int | None = None) -> str:
    """
    List Installations

    Args:
        limit: limit
        offset: offset
    """
    args: dict[str, Any] = {}
    args["limit"] = limit
    args["offset"] = offset
    return run_vijil("scan", "list-installations", args)

@server.tool()
def scan_get_installation(installation_id: str) -> str:
    """
    Get Installation

    Args:
        installation_id: The installation id
    """
    return run_vijil("scan", "get-installation", {}, positional=[installation_id])

@server.tool()
def scan_create_installation(
    external_installation_id: str,
    external_account_login: str,
    provider: str | None = None,
    external_account_type: str | None = None,
) -> str:
    """
    Create Installation

    Args:
        external_installation_id: GitHub installation ID (numeric)
        external_account_login: GitHub org or user login
        provider: Source control management provider.  Phase 3: add GITLAB = "gitlab" and BITBUCKET = "bitbucket" when additional SCM providers are supported. (one of: github)
        external_account_type: External Account Type (one of: Organization, User)
    """
    args: dict[str, Any] = {}
    args["external_installation_id"] = external_installation_id
    args["external_account_login"] = external_account_login
    args["provider"] = provider
    args["external_account_type"] = external_account_type
    return run_vijil("scan", "create-installation", args)

@server.tool()
def scan_associate(scan_id: str, agent_id: str) -> str:
    """
    Associate Scan

    Args:
        scan_id: The scan id
        agent_id: Agent Id
    """
    args: dict[str, Any] = {}
    args["agent_id"] = agent_id
    return run_vijil("scan", "associate", args, positional=[scan_id])

@server.tool()
def scan_disassociate(scan_id: str) -> str:
    """
    Disassociate Scan

    Args:
        scan_id: The scan id
    """
    return run_vijil("scan", "disassociate", {}, positional=[scan_id], skip_confirm=True)

@server.tool()
def scan_review(scan_id: str, review_status: str) -> str:
    """
    Update Review Status

    Args:
        scan_id: The scan id
        review_status: User triage decision — independent of agent assignment. (one of: pending, flagged, waived)
    """
    args: dict[str, Any] = {}
    args["review_status"] = review_status
    return run_vijil("scan", "review", args, positional=[scan_id])

@server.tool()
def scan_delete(scan_id: str) -> str:
    """
    Delete Scan

    Args:
        scan_id: The scan id
    """
    return run_vijil("scan", "delete", {}, positional=[scan_id], skip_confirm=True)
