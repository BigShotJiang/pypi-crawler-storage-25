# Copyright 2026 Vijil, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# AUTO-GENERATED from specs/service_agent_environment.json — do not edit manually.
# Re-generate with: make generate-mcp

from __future__ import annotations

from typing import Any

from vijil_mcp.server import server
from vijil_mcp.tools._runner import run_vijil


@server.tool()
def genome_list(agent_id: str | None = None, limit: int | None = None, offset: int | None = None) -> str:
    """
    List Genomes

    Args:
        agent_id: Filter by agent
        limit: limit
        offset: offset
    """
    args: dict[str, Any] = {}
    args["agent_id"] = agent_id
    args["limit"] = limit
    args["offset"] = offset
    return run_vijil("genome", "list", args)

@server.tool()
def genome_get(genome_id: str, version: int | None = None) -> str:
    """
    Get Genome

    Args:
        genome_id: The genome id
        version: Specific version (None = latest)
    """
    args: dict[str, Any] = {}
    args["version"] = version
    return run_vijil("genome", "get", args, positional=[genome_id])

@server.tool()
def genome_create() -> str:
    """Create Genome"""
    return run_vijil("genome", "create", {})

@server.tool()
def genome_delete(genome_id: str) -> str:
    """
    Delete Genome

    Args:
        genome_id: The genome id
    """
    return run_vijil("genome", "delete", {}, positional=[genome_id], skip_confirm=True)

@server.tool()
def genome_by_agent(agent_id: str, version: int | None = None) -> str:
    """
    Get Genome By Agent

    Args:
        agent_id: The agent id
        version: Specific version (None = latest)
    """
    args: dict[str, Any] = {}
    args["version"] = version
    return run_vijil("genome", "by-agent", args, positional=[agent_id])

@server.tool()
def genome_mutation_history(agent_id: str, limit: int | None = None) -> str:
    """
    Get Mutation History

    Args:
        agent_id: The agent id
        limit: limit
    """
    args: dict[str, Any] = {}
    args["limit"] = limit
    return run_vijil("genome", "mutation-history", args, positional=[agent_id])

@server.tool()
def genome_versions(genome_id: str, limit: int | None = None, offset: int | None = None) -> str:
    """
    List Genome Versions

    Args:
        genome_id: The genome id
        limit: limit
        offset: offset
    """
    args: dict[str, Any] = {}
    args["limit"] = limit
    args["offset"] = offset
    return run_vijil("genome", "versions", args, positional=[genome_id])

@server.tool()
def genome_version_get(genome_id: str, version: str) -> str:
    """
    Get Genome Version

    Args:
        genome_id: The genome id
        version: The version
    """
    return run_vijil("genome", "version-get", {}, positional=[genome_id, version])

@server.tool()
def genome_ancestry(genome_id: str, max_depth: int | None = None) -> str:
    """
    Get Genome Ancestry

    Args:
        genome_id: The genome id
        max_depth: Maximum ancestor depth
    """
    args: dict[str, Any] = {}
    args["max_depth"] = max_depth
    return run_vijil("genome", "ancestry", args, positional=[genome_id])

@server.tool()
def genome_diff(genome_id: str, version_a: int, version_b: int) -> str:
    """
    Diff Genome Versions

    Args:
        genome_id: The genome id
        version_a: First version
        version_b: Second version
    """
    args: dict[str, Any] = {}
    args["version_a"] = version_a
    args["version_b"] = version_b
    return run_vijil("genome", "diff", args, positional=[genome_id])

@server.tool()
def genome_similar(genome_id: str, version: int | None = None, limit: int | None = None) -> str:
    """
    Find Similar Genomes

    Args:
        genome_id: The genome id
        version: Genome version
        limit: limit
    """
    args: dict[str, Any] = {}
    args["version"] = version
    args["limit"] = limit
    return run_vijil("genome", "similar", args, positional=[genome_id])

@server.tool()
def genome_extract(agent_id: str) -> str:
    """
    Extract Genome From Agent

    Args:
        agent_id: The agent id
    """
    return run_vijil("genome", "extract", {}, positional=[agent_id])

@server.tool()
def genome_to_agent_update(genome_id: str, version: int | None = None) -> str:
    """
    Genome To Agent Update

    Args:
        genome_id: The genome id
        version: Specific version
    """
    args: dict[str, Any] = {}
    args["version"] = version
    return run_vijil("genome", "to-agent-update", args, positional=[genome_id])
