# Copyright 2026 Vijil, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# AUTO-GENERATED from specs/service_agent_environment.json — do not edit manually.
# Re-generate with: make generate-mcp

from __future__ import annotations

from typing import Any

from vijil_mcp.server import server
from vijil_mcp.tools._runner import run_vijil


@server.tool()
def evolution_run(
    agent_id: str,
    harness_names: str | None = None,
    sample_size: int | None = None,
    min_improvement_threshold: float | None = None,
    target_dimensions: str | None = None,
    max_probes_per_evaluation: int | None = None,
    probe_concurrency: int | None = None,
    reflection_model: str | None = None,
    mutation_strategy: str | None = None,
    gepa_max_metric_calls: int | None = None,
    detection_volume_threshold: int | None = None,
    use_tier1: bool = False,
    wait: bool = False,
) -> str:
    """
    Trigger Evolution

    Args:
        agent_id: The agent id
        harness_names: Harness Names (JSON array string)
        sample_size: Sample Size
        min_improvement_threshold: Min Improvement Threshold
        target_dimensions: Target Dimensions (JSON array string)
        max_probes_per_evaluation: Max Probes Per Evaluation
        probe_concurrency: Probe Concurrency
        reflection_model: Reflection Model
        mutation_strategy: Mutation Strategy
        gepa_max_metric_calls: Gepa Max Metric Calls
        detection_volume_threshold: Detection Volume Threshold
        use_tier1: Use Tier1
        wait: Poll until the operation reaches a terminal state (completed/failed/cancelled)
    """
    args: dict[str, Any] = {}
    args["harness_names"] = harness_names
    args["sample_size"] = sample_size
    args["min_improvement_threshold"] = min_improvement_threshold
    args["target_dimensions"] = target_dimensions
    args["max_probes_per_evaluation"] = max_probes_per_evaluation
    args["probe_concurrency"] = probe_concurrency
    args["reflection_model"] = reflection_model
    args["mutation_strategy"] = mutation_strategy
    args["gepa_max_metric_calls"] = gepa_max_metric_calls
    args["detection_volume_threshold"] = detection_volume_threshold
    args["use_tier1"] = use_tier1
    return run_vijil("evolution", "run", args, positional=[agent_id], wait=wait)

@server.tool()
def evolution_status(agent_id: str, evolution_id: str) -> str:
    """
    Get Evolution Job Status

    Args:
        agent_id: The agent id
        evolution_id: The evolution id
    """
    return run_vijil("evolution", "status", {}, positional=[agent_id, evolution_id])
