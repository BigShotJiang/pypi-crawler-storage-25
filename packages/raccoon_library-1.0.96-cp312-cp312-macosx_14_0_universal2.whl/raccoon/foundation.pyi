"""
Python bindings for libstp-foundation
"""
from __future__ import annotations
import typing
__all__: list[str] = ['ChassisVelocity', 'Feedforward', 'FeedforwardController', 'Level', 'MotorCalibration', 'PidConfig', 'PidController', 'PidGains', 'Pose', 'clear_file_level', 'clear_filters', 'clear_package_level', 'debug', 'error', 'info', 'initialize_logging', 'initialize_timer', 'is_speed_mode_enabled', 'set_file_level', 'set_global_level', 'set_package_level', 'set_speed_mode_enabled', 'shutdown_logging', 'warn']
class ChassisVelocity:
    vx: float
    vy: float
    wz: float
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, vx: float, vy: float, wz: float) -> None:
        ...
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
class Feedforward:
    kA: float
    kS: float
    kV: float
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, kS: float, kV: float, kA: float) -> None:
        ...
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
class FeedforwardController:
    config: Feedforward
    def __init__(self, config: Feedforward = ...) -> None:
        ...
    def calculate(self, velocity: float, acceleration: float = 0.0) -> float:
        ...
class Level:
    """
    Members:
    
      trace
    
      debug
    
      info
    
      warn
    
      error
    
      critical
    
      off
    """
    __members__: typing.ClassVar[dict[str, Level]]  # value = {'trace': <Level.trace: 0>, 'debug': <Level.debug: 1>, 'info': <Level.info: 2>, 'warn': <Level.warn: 3>, 'error': <Level.error: 4>, 'critical': <Level.critical: 5>, 'off': <Level.off: 6>}
    critical: typing.ClassVar[Level]  # value = <Level.critical: 5>
    debug: typing.ClassVar[Level]  # value = <Level.debug: 1>
    error: typing.ClassVar[Level]  # value = <Level.error: 4>
    info: typing.ClassVar[Level]  # value = <Level.info: 2>
    off: typing.ClassVar[Level]  # value = <Level.off: 6>
    trace: typing.ClassVar[Level]  # value = <Level.trace: 0>
    warn: typing.ClassVar[Level]  # value = <Level.warn: 3>
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class MotorCalibration:
    pid: PidGains | None
    ticks_to_rad: float
    vel_lpf_alpha: float
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, ticks_to_rad: float, vel_lpf_alpha: float) -> None:
        ...
    @typing.overload
    def __init__(self, ticks_to_rad: float, vel_lpf_alpha: float, pid: PidGains | None = None) -> None:
        ...
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
class PidConfig:
    derivative_lpf_alpha: float
    integral_deadband: float
    integral_max: float
    kd: float
    ki: float
    kp: float
    output_max: float
    output_min: float
    def __init__(self, kp: float = 1.0, ki: float = 0.0, kd: float = 0.0, integral_max: float = 10.0, integral_deadband: float = 0.01, derivative_lpf_alpha: float = 0.1, output_min: float = -10.0, output_max: float = 10.0) -> None:
        ...
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
class PidController:
    def __init__(self, config: PidConfig = ...) -> None:
        ...
    def reset(self) -> None:
        ...
    def set_gains(self, kp: float, ki: float, kd: float) -> None:
        ...
    def update(self, error: float, dt: float) -> float:
        ...
    @property
    def derivative(self) -> float:
        ...
    @property
    def integral(self) -> float:
        ...
class PidGains:
    kd: float
    ki: float
    kp: float
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, kp: float, ki: float, kd: float) -> None:
        ...
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
class Pose:
    heading: float
    position: numpy.ndarray[numpy.float32[3, 1]]
    def __init__(self) -> None:
        ...
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
def _log_filtered(level: Level, filepath: str, message: str) -> None:
    """
            Log a message with file-based filtering (internal use).
    
            Checks is_enabled_for(level, filepath) before logging, supporting both
            per-file filtering (set_file_level) and package filtering (set_package_level).
    
            Args:
                level: The log level
                filepath: The full source file path (used for filtering and display)
                message: The log message
    """
def clear_file_level(filename: str) -> None:
    """
            Remove the log level filter for a specific source file.
    
            Args:
                filename: The source file basename to clear
    """
def clear_filters() -> None:
    """
            Clear all file-specific filters and reset global level to INFO.
    """
def clear_package_level(package: str) -> None:
    """
            Remove the log level filter for a package substring.
    
            Args:
                package: The package substring to clear
    """
def debug(message: str) -> None:
    """
            Log a message with severity level debug
    """
def error(message: str) -> None:
    """
            Log a message with severity level error
    """
def info(message: str) -> None:
    """
            Log a message with severity level info
    """
def initialize_logging() -> None:
    """
    Initialize and enable the logging system
    """
def initialize_timer() -> None:
    """
    Initialize the timer for elapsed time logging
    """
def is_speed_mode_enabled() -> bool:
    """
    Return True if SpeedMode is currently active (BEMF disabled).
    """
def set_file_level(filename: str, level: Level) -> None:
    """
            Set the log level for a specific source file (by basename).
    
            Args:
                filename: The source file basename (e.g., "fused_odometry.cpp")
                level: The minimum log level for this file
    """
def set_global_level(level: Level) -> None:
    """
            Set the global runtime log level. Messages below this level are filtered.
    
            Args:
                level: The minimum log level to display (e.g., Level.trace, Level.debug, Level.info)
    """
def set_package_level(package: str, level: Level) -> None:
    """
            Set the log level for all source files whose path contains the given substring.
    
            Package filters are checked after file-specific filters (set_file_level).
            Use path fragments like "libstp-motion" (C++ module) or "libstp/step/motion"
            (Python package) to match groups of files.
    
            Args:
                package: A substring to match against the full source file path
                level: The minimum log level for matching files
    """
def set_speed_mode_enabled(enabled: bool) -> None:
    """
    Set the process-wide SpeedMode flag. Should only be called by the `SetSpeedMode` step after the firmware has acknowledged the BEMF-disable command; calling it directly bypasses the firmware handshake and leaves the library/firmware state inconsistent.
    """
def shutdown_logging() -> None:
    """
    Flush and tear down the logger so that no further log calls touch spdlog
    """
def warn(message: str) -> None:
    """
            Log a message with severity level warn
    """
