"""
Python bindings for libstp-localization (Phase-2 pass-through upgraded with a Phase-6 particle-filter core).
"""
from __future__ import annotations
import raccoon.foundation
import raccoon.hal
import typing
__all__: list[str] = ['Localization', 'LocalizationConfig', 'Observation', 'SurfaceKind', 'SurfaceMeasurement']
class Localization:
    """
    Thread-safe particle-filter localization service.
    
    Owns a background thread that polls the supplied IOdometry at a fixed rate and propagates a particle cloud from the per-tick odometry delta. ``observe()`` injects sigma-weighted absolute pose observations for resync sites. The constructor calls ``start()``; the destructor calls ``stop()`` and joins the worker thread.
    """
    def __init__(self, odometry: raccoon.hal.IOdometry, config: LocalizationConfig = ..., table_map: typing.Any = None) -> None:
        ...
    def enable_recording(self, path: str, record_hz: float = 20.0, robot_json: str = 'null', sensors_json: str = '[]', table_map_json: str = 'null', notes: str = '', particle_count_hint: int = 128, tick_hz: float = 100.0) -> bool:
        """
        Enable post-run JSONL recording of localization state. Returns True if the file was opened successfully. On failure (e.g. unwritable path) returns False and localization continues without recording — never raises.
        """
    def get_pose(self) -> raccoon.foundation.Pose:
        """
        Snapshot of the current world pose. Thread-safe.
        """
    def observe(self, observation: Observation) -> None:
        """
        Apply a sigma-weighted pose observation. Infinite-sigma axes are left untouched.
        """
    def start(self) -> None:
        """
        Idempotent. The constructor already calls this; tests may re-call.
        """
    def stop(self) -> None:
        """
        Idempotent. Joins the worker thread. The destructor also calls this.
        """
class LocalizationConfig:
    """
    Configuration for the Localization background tick loop and particle filter.
    """
    observation_injection_ratio: float
    particle_count: int
    process_heading_noise_per_rad: float
    process_heading_noise_rad: float
    process_translation_noise_m: float
    process_translation_noise_per_m: float
    resample_effective_sample_ratio: float
    rng_seed: int
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, tick_period_ms: int = 10, particle_count: int = 128, process_translation_noise_m: float = 0.002, process_translation_noise_per_m: float = 0.02, process_heading_noise_rad: float = 0.01, process_heading_noise_per_rad: float = 0.05, observation_injection_ratio: float = 0.35, resample_effective_sample_ratio: float = 0.5, rng_seed: int = 1592594996) -> None:
        ...
    @property
    def tick_period_ms(self) -> int:
        """
        Background tick period in milliseconds (default 10 = 100 Hz).
        """
    @tick_period_ms.setter
    def tick_period_ms(self, arg0: int) -> None:
        ...
class Observation:
    """
    Soft-snap observation pushed by Resync-Steps.
    
    sigma is the per-axis (x, y, theta) measurement standard deviation. An axis with infinite sigma is left untouched.
    """
    pose: raccoon.foundation.Pose
    surface_measurements: list[SurfaceMeasurement]
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, pose: raccoon.foundation.Pose, sigma: typing.Any = (0.001, 0.001, 0.001)) -> None:
        """
        Construct an Observation. ``sigma`` accepts any 3-element sequence (list, tuple, numpy array). Use ``math.inf`` on an axis to leave it untouched.
        """
    @property
    def sigma(self) -> tuple:
        ...
    @sigma.setter
    def sigma(self, arg1: typing.Any) -> None:
        ...
class SurfaceKind:
    """
    Members:
    
      LINE
    
      WALL
    """
    LINE: typing.ClassVar[SurfaceKind]  # value = <SurfaceKind.LINE: 0>
    WALL: typing.ClassVar[SurfaceKind]  # value = <SurfaceKind.WALL: 1>
    __members__: typing.ClassVar[dict[str, SurfaceKind]]  # value = {'LINE': <SurfaceKind.LINE: 0>, 'WALL': <SurfaceKind.WALL: 1>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class SurfaceMeasurement:
    """
    Map-projected boolean sensor observation used as a soft particle likelihood.
    """
    detected: bool
    kind: SurfaceKind
    sigma_cm: float
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, kind: SurfaceKind, sensor: typing.Any, detected: bool = True, sigma_cm: float = 1.0) -> None:
        ...
    @property
    def forward_cm(self) -> float:
        ...
    @property
    def sensor(self) -> tuple:
        ...
    @sensor.setter
    def sensor(self, arg1: typing.Any) -> None:
        ...
    @property
    def strafe_cm(self) -> float:
        ...
def _auto_enable_recording(localization: Localization, robot_json: str = 'null', sensors_json: str = '[]', table_map_json: str = 'null', particle_count_hint: int = 128, tick_hz: float = 100.0) -> bool:
    """
    Internal: enable LocalizationRecorder iff LIBSTP_RECORD_LOCALIZATION is truthy. Returns True if recording started.
    """
