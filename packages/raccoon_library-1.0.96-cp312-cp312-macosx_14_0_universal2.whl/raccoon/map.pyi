"""
Canonical raccoon table-map module (libstp::map). Provides WorldMap, MapSegment, and sensor-projection queries used by the localization stack and Python TableMap consumers.
"""
from __future__ import annotations
import typing
__all__: list[str] = ['FtmapParseError', 'MapSegment', 'Point2D', 'SensorOffset', 'WheelOffset', 'WorldMap']
class FtmapParseError(Exception):
    pass
class MapSegment:
    class Kind:
        """
        Members:
        
          LINE
        
          WALL
        """
        LINE: typing.ClassVar[MapSegment.Kind]  # value = <Kind.LINE: 0>
        WALL: typing.ClassVar[MapSegment.Kind]  # value = <Kind.WALL: 1>
        __members__: typing.ClassVar[dict[str, MapSegment.Kind]]  # value = {'LINE': <Kind.LINE: 0>, 'WALL': <Kind.WALL: 1>}
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: int) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: int) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    end_x: float
    end_y: float
    kind: MapSegment.Kind
    start_x: float
    start_y: float
    width_cm: float
    def __init__(self) -> None:
        ...
    @property
    def length(self) -> float:
        ...
class Point2D:
    """
    Point in field coordinates (cm, origin = bottom-left, +X right, +Y up).
    """
    x_cm: float
    y_cm: float
    def __getitem__(self, arg0: int) -> float:
        ...
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, x_cm: float, y_cm: float) -> None:
        ...
    def __iter__(self) -> typing.Iterator:
        ...
    def __repr__(self) -> str:
        ...
class SensorOffset:
    """
    Sensor mount offset from the robot geometric center. forward_cm is along the robot heading, strafe_cm is 90° CCW (positive = robot's left).
    """
    forward_cm: float
    strafe_cm: float
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, forward_cm: float, strafe_cm: float) -> None:
        ...
    def __repr__(self) -> str:
        ...
class WheelOffset:
    """
    Wheel mount offset from the robot geometric center. Same axes as SensorOffset.
    """
    forward_cm: float
    strafe_cm: float
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, forward_cm: float, strafe_cm: float) -> None:
        ...
class WorldMap:
    """
    Canonical Botball table map. Bottom-left origin, +X right, +Y up, all dimensions in cm.
    """
    @staticmethod
    def from_ftmap(data: dict) -> WorldMap:
        """
        Build a WorldMap from a parsed ftmap dict (the same shape that raccoon.project.yml stores under robot.physical.table_map).
        """
    def __init__(self) -> None:
        ...
    def __repr__(self) -> str:
        ...
    def add_segment(self, segment: MapSegment) -> None:
        ...
    def clear(self) -> None:
        ...
    def distance_to_nearest_line(self, x_cm: float, y_cm: float) -> float:
        ...
    def distance_to_nearest_wall(self, x_cm: float, y_cm: float) -> float:
        ...
    def is_on_black_line(self, x_cm: float, y_cm: float) -> bool:
        """
        Legacy alias for is_on_line, kept for libstp-sim compatibility.
        """
    def is_on_line(self, x_cm: float, y_cm: float) -> bool:
        ...
    def is_on_wall(self, x_cm: float, y_cm: float) -> bool:
        ...
    def lines(self) -> list[MapSegment]:
        ...
    def load(self, path: str) -> None:
        """
        Load an .ftmap file from disk (TableMapFileV1 schema).
        """
    def load_ftmap(self, path: str) -> None:
        """
        Legacy alias for load(), kept for libstp-sim compatibility.
        """
    def parse_ftmap(self, content: str) -> None:
        """
        Parse an in-memory ftmap document.
        """
    def segments(self) -> list[MapSegment]:
        ...
    def sensor_field_position(self, robot_x_cm: float, robot_y_cm: float, robot_heading_rad: float, sensor: typing.Any) -> Point2D:
        """
        Project a robot-local sensor mount into field coordinates. `sensor` may be a SensorOffset or any object with `forward_cm`/`strafe_cm` attributes (e.g. SensorPosition).
        """
    def sensor_is_on_line(self, robot_x_cm: float, robot_y_cm: float, robot_heading_rad: float, sensor: typing.Any) -> bool:
        ...
    def sensor_is_on_wall(self, robot_x_cm: float, robot_y_cm: float, robot_heading_rad: float, sensor: typing.Any) -> bool:
        ...
    def set_table(self, width_cm: float, height_cm: float) -> None:
        ...
    def walls(self) -> list[MapSegment]:
        """
        Wall segments plus the four synthesized table-border edges.
        """
    @property
    def all_segments(self) -> list[MapSegment]:
        """
        Authored segments (lines + explicit walls), excluding the synthesized table-border walls.
        """
    @property
    def height_cm(self) -> float:
        ...
    @property
    def table_height_cm(self) -> float:
        ...
    @property
    def table_width_cm(self) -> float:
        ...
    @property
    def width_cm(self) -> float:
        ...
