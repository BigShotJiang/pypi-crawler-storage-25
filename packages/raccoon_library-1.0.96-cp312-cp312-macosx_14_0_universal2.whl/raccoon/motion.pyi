"""
Python bindings for libstp-motion
"""
from __future__ import annotations
import raccoon.foundation
import raccoon.hal
import typing
__all__: list[str] = ['ArcMotion', 'ArcMotionConfig', 'ArcMotionTelemetry', 'AxisConstraints', 'DiagonalMotion', 'DiagonalMotionConfig', 'DiagonalMotionTelemetry', 'LinearAxis', 'LinearMotion', 'LinearMotionConfig', 'LinearMotionTelemetry', 'Motion', 'SplineMotion', 'SplineMotionConfig', 'SplineMotionTelemetry', 'TurnConfig', 'TurnMotion', 'UnifiedMotionPidConfig']
class ArcMotion(Motion):
    def __init__(self, drive: ..., odometry: raccoon.hal.IOdometry, pid_config: UnifiedMotionPidConfig, config: ArcMotionConfig) -> None:
        ...
    def get_filtered_velocity(self) -> float:
        """
        Current filtered angular velocity (rad/s).
        """
    def get_telemetry(self) -> list[ArcMotionTelemetry]:
        ...
    def has_reached_angle(self) -> bool:
        """
        Check if target arc angle is reached (ignores velocity settling).
        """
    def is_finished(self) -> bool:
        ...
    def set_suppress_hard_stop(self, suppress: bool) -> None:
        """
        When true, complete() will not call hardStop().
        """
    def start(self) -> None:
        ...
    def start_warm(self, heading_offset_rad: float, initial_angular_velocity: float) -> None:
        """
        Begin arc from current state without resetting odometry.
        """
    def update(self, dt: float) -> None:
        ...
class ArcMotionConfig:
    arc_angle_rad: float
    lateral: bool
    radius_m: float
    speed_scale: float
    def __init__(self) -> None:
        ...
class ArcMotionTelemetry:
    @property
    def arc_position_m(self) -> float:
        ...
    @property
    def arc_target_m(self) -> float:
        ...
    @property
    def cmd_vx_mps(self) -> float:
        ...
    @property
    def cmd_vy_mps(self) -> float:
        ...
    @property
    def cmd_wz_radps(self) -> float:
        ...
    @property
    def dt(self) -> float:
        ...
    @property
    def filtered_velocity_radps(self) -> float:
        ...
    @property
    def heading_error_rad(self) -> float:
        ...
    @property
    def heading_rad(self) -> float:
        ...
    @property
    def pid_raw(self) -> float:
        ...
    @property
    def saturated(self) -> bool:
        ...
    @property
    def setpoint_position_rad(self) -> float:
        ...
    @property
    def setpoint_velocity_radps(self) -> float:
        ...
    @property
    def target_angle_rad(self) -> float:
        ...
    @property
    def time_s(self) -> float:
        ...
class AxisConstraints:
    acceleration: float
    deceleration: float
    max_velocity: float
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, max_velocity: float = 0.0, acceleration: float = 0.0, deceleration: float = 0.0) -> None:
        ...
class DiagonalMotion(Motion):
    def __init__(self, drive: ..., odometry: raccoon.hal.IOdometry, pid_config: UnifiedMotionPidConfig, config: DiagonalMotionConfig) -> None:
        ...
    def get_telemetry(self) -> list[DiagonalMotionTelemetry]:
        ...
    def is_finished(self) -> bool:
        ...
    def start(self) -> None:
        ...
    def update(self, dt: float) -> None:
        ...
class DiagonalMotionConfig:
    angle_rad: float
    distance_m: float
    speed_scale: float
    target_heading_rad: float
    def __init__(self) -> None:
        ...
    @property
    def has_distance_target(self) -> bool:
        """
        True when distance_m is a real positional goal. Set False when the motion is terminated by an external until-condition (required for SpeedMode, where BEMF-based distance is unavailable).
        """
    @has_distance_target.setter
    def has_distance_target(self, arg0: bool) -> None:
        ...
class DiagonalMotionTelemetry:
    @property
    def actual_error_m(self) -> float:
        ...
    @property
    def cmd_vx_mps(self) -> float:
        ...
    @property
    def cmd_vy_mps(self) -> float:
        ...
    @property
    def cmd_wz_radps(self) -> float:
        ...
    @property
    def cross_track_m(self) -> float:
        ...
    @property
    def distance_error_m(self) -> float:
        ...
    @property
    def dt(self) -> float:
        ...
    @property
    def filtered_velocity_mps(self) -> float:
        ...
    @property
    def heading_rad(self) -> float:
        ...
    @property
    def heading_scale(self) -> float:
        ...
    @property
    def pid_cross_raw(self) -> float:
        ...
    @property
    def pid_heading_raw(self) -> float:
        ...
    @property
    def pid_primary_raw(self) -> float:
        ...
    @property
    def position_m(self) -> float:
        ...
    @property
    def predicted_m(self) -> float:
        ...
    @property
    def saturated(self) -> bool:
        ...
    @property
    def setpoint_position_m(self) -> float:
        ...
    @property
    def setpoint_velocity_mps(self) -> float:
        ...
    @property
    def speed_scale(self) -> float:
        ...
    @property
    def target_m(self) -> float:
        ...
    @property
    def time_s(self) -> float:
        ...
    @property
    def yaw_error_rad(self) -> float:
        ...
class LinearAxis:
    """
    Members:
    
      Forward
    
      Lateral
    """
    Forward: typing.ClassVar[LinearAxis]  # value = <LinearAxis.Forward: 0>
    Lateral: typing.ClassVar[LinearAxis]  # value = <LinearAxis.Lateral: 1>
    __members__: typing.ClassVar[dict[str, LinearAxis]]  # value = {'Forward': <LinearAxis.Forward: 0>, 'Lateral': <LinearAxis.Lateral: 1>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class LinearMotion(Motion):
    def __init__(self, drive: ..., odometry: raccoon.hal.IOdometry, pid_config: UnifiedMotionPidConfig, config: LinearMotionConfig) -> None:
        ...
    def clear_omega_override(self) -> None:
        """
        Restore internal heading PID control.
        """
    def get_filtered_velocity(self) -> float:
        """
        Current filtered velocity along the primary axis (m/s).
        """
    def get_telemetry(self) -> list[LinearMotionTelemetry]:
        ...
    def has_reached_distance(self) -> bool:
        """
        Check if target distance is reached (ignores velocity settling).
        """
    def is_finished(self) -> bool:
        ...
    def set_omega_override(self, omega: float) -> None:
        """
        Override heading PID with external omega. Set each cycle before update().
        """
    def set_suppress_hard_stop(self, suppress: bool) -> None:
        """
        When true, complete() will not call hardStop().
        """
    def start(self) -> None:
        ...
    def start_warm(self, position_offset_m: float, initial_velocity_mps: float) -> None:
        """
        Begin motion from current state without resetting odometry.
        """
    def update(self, dt: float) -> None:
        ...
class LinearMotionConfig:
    axis: LinearAxis
    distance_m: float
    speed_scale: float
    target_heading_rad: float
    def __init__(self) -> None:
        ...
    @property
    def has_distance_target(self) -> bool:
        """
        True when distance_m is a real positional goal. Set False when the motion is terminated by an external until-condition (required for SpeedMode, where BEMF-based distance is unavailable).
        """
    @has_distance_target.setter
    def has_distance_target(self, arg0: bool) -> None:
        ...
class LinearMotionTelemetry:
    @property
    def actual_error_m(self) -> float:
        ...
    @property
    def cmd_vx_mps(self) -> float:
        ...
    @property
    def cmd_vy_mps(self) -> float:
        ...
    @property
    def cmd_wz_radps(self) -> float:
        ...
    @property
    def cross_track_m(self) -> float:
        ...
    @property
    def distance_error_m(self) -> float:
        ...
    @property
    def dt(self) -> float:
        ...
    @property
    def filtered_velocity_mps(self) -> float:
        ...
    @property
    def heading_rad(self) -> float:
        ...
    @property
    def heading_scale(self) -> float:
        ...
    @property
    def pid_cross_raw(self) -> float:
        ...
    @property
    def pid_heading_raw(self) -> float:
        ...
    @property
    def pid_primary_raw(self) -> float:
        ...
    @property
    def position_m(self) -> float:
        ...
    @property
    def predicted_m(self) -> float:
        ...
    @property
    def saturated(self) -> bool:
        ...
    @property
    def setpoint_position_m(self) -> float:
        ...
    @property
    def setpoint_velocity_mps(self) -> float:
        ...
    @property
    def speed_scale(self) -> float:
        ...
    @property
    def target_m(self) -> float:
        ...
    @property
    def time_s(self) -> float:
        ...
    @property
    def yaw_error_rad(self) -> float:
        ...
class Motion:
    def is_finished(self) -> bool:
        ...
    def start(self) -> None:
        ...
    def update(self, dt: float) -> None:
        ...
class SplineMotion(Motion):
    def __init__(self, drive: ..., odometry: raccoon.hal.IOdometry, pid_config: UnifiedMotionPidConfig, config: SplineMotionConfig) -> None:
        ...
    def get_telemetry(self) -> list[SplineMotionTelemetry]:
        ...
    def is_finished(self) -> bool:
        ...
    def start(self) -> None:
        ...
    def update(self, dt: float) -> None:
        ...
class SplineMotionConfig:
    final_heading_rad: float | None
    headings_rad: list[float]
    speed_scale: float
    waypoints_m: list[tuple[float, float]]
    def __init__(self) -> None:
        ...
class SplineMotionTelemetry:
    @property
    def arc_length_m(self) -> float:
        ...
    @property
    def arc_target_m(self) -> float:
        ...
    @property
    def cmd_vx_mps(self) -> float:
        ...
    @property
    def cmd_vy_mps(self) -> float:
        ...
    @property
    def cmd_wz_radps(self) -> float:
        ...
    @property
    def cross_track_m(self) -> float:
        ...
    @property
    def dt(self) -> float:
        ...
    @property
    def filtered_velocity_mps(self) -> float:
        ...
    @property
    def heading_error_rad(self) -> float:
        ...
    @property
    def heading_rad(self) -> float:
        ...
    @property
    def saturated(self) -> bool:
        ...
    @property
    def setpoint_position_m(self) -> float:
        ...
    @property
    def setpoint_velocity_mps(self) -> float:
        ...
    @property
    def target_heading_rad(self) -> float:
        ...
    @property
    def time_s(self) -> float:
        ...
class TurnConfig:
    kS: float
    speed_scale: float
    target_angle_rad: float
    def __init__(self) -> None:
        ...
    @property
    def has_angle_target(self) -> bool:
        """
        True when target_angle_rad is a real angular goal. Set False when the turn is terminated by an external until-condition (required for SpeedMode, where BEMF-based heading integration is unavailable).
        """
    @has_angle_target.setter
    def has_angle_target(self, arg0: bool) -> None:
        ...
class TurnMotion(Motion):
    def __init__(self, drive: ..., odometry: raccoon.hal.IOdometry, pid_config: UnifiedMotionPidConfig, config: TurnConfig) -> None:
        ...
    def get_filtered_velocity(self) -> float:
        """
        Current filtered angular velocity (rad/s).
        """
    def has_reached_angle(self) -> bool:
        """
        Check if target angle is reached (ignores velocity settling).
        """
    def is_finished(self) -> bool:
        ...
    def set_suppress_hard_stop(self, suppress: bool) -> None:
        """
        When true, complete() will not call hardStop().
        """
    def start(self) -> None:
        ...
    def start_warm(self, heading_offset_rad: float, initial_angular_velocity: float) -> None:
        """
        Begin turn from current state without resetting odometry.
        """
    def update(self, dt: float) -> None:
        ...
class UnifiedMotionPidConfig:
    angle_tolerance_rad: float
    angular: AxisConstraints
    distance: raccoon.foundation.PidConfig
    distance_tolerance_m: float
    heading: raccoon.foundation.PidConfig
    heading_min_scale: float
    heading_recovery_error_rad: float
    heading_recovery_rate: float
    heading_saturation_derating_factor: float
    heading_saturation_error_rad: float
    lateral: AxisConstraints
    linear: AxisConstraints
    saturation_derating_factor: float
    saturation_hold_cycles: int
    saturation_min_scale: float
    saturation_recovery_rate: float
    saturation_recovery_threshold: float
    velocity_ff: float
    def __init__(self, distance: raccoon.foundation.PidConfig = ..., heading: raccoon.foundation.PidConfig = ..., velocity_ff: float = 1.0, saturation_derating_factor: float = 0.9, saturation_min_scale: float = 0.2, saturation_recovery_rate: float = 0.03, heading_saturation_derating_factor: float = 0.85, heading_min_scale: float = 0.25, heading_recovery_rate: float = 0.05, saturation_hold_cycles: int = 5, saturation_recovery_threshold: float = 0.95, distance_tolerance_m: float = 0.01, angle_tolerance_rad: float = 0.035, heading_saturation_error_rad: float = 0.01, heading_recovery_error_rad: float = 0.005, linear: AxisConstraints = ..., lateral: AxisConstraints = ..., angular: AxisConstraints = ...) -> None:
        ...
