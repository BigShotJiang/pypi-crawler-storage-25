from __future__ import annotations
from raccoon.log import debug
from raccoon.log import error
from raccoon.log import info
from raccoon.log import trace
from raccoon.log import warn
__all__: list[str] = ['ClassNameLogger', 'debug', 'error', 'info', 'trace', 'warn']
class ClassNameLogger:
    def debug(self, msg: str) -> None:
        """
        
                Print a debug message.
        
                Args:
                    msg: The message to print
                
        """
    def error(self, msg: str) -> None:
        """
        
                Print an error message.
        
                Args:
                    msg: The message to print
                
        """
    def info(self, msg: str) -> None:
        """
        
                Print an info message.
        
                Args:
                    msg: The message to print
                
        """
    def trace(self, msg: str) -> None:
        """
        
                Print a trace message.
        
                Args:
                    msg: The message to print
                
        """
    def warn(self, msg: str) -> None:
        """
        
                Print a warn message.
        
                Args:
                    msg: The message to print
                
        """
