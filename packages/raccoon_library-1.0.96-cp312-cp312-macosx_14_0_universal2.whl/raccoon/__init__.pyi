from __future__ import annotations
import atexit as atexit
from builtins import frame as FrameType
import collections.abc
from raccoon.class_name_logger import ClassNameLogger
from raccoon.drive import AxisVelocityControlConfig
from raccoon.drive import ChassisVelocityControlConfig
from raccoon.drive import Drive
from raccoon.foundation import Feedforward
from raccoon.foundation import FeedforwardController
from raccoon.foundation import MotorCalibration
from raccoon.foundation import PidConfig
from raccoon.foundation import PidController
from raccoon.foundation import PidGains
from raccoon.foundation import initialize_logging
from raccoon.hal import AnalogSensor
from raccoon.hal import DigitalSensor
from raccoon.hal import IMU
from raccoon.hal import Motor
from raccoon.hal import Servo
from raccoon.kinematics_differential import DifferentialKinematics
from raccoon.kinematics_mecanum import MecanumKinematics
from raccoon.kmeans import KMeans
from raccoon.kmeans import KMeansResult
from raccoon.localization import Localization
from raccoon.localization import LocalizationConfig
from raccoon.localization import Observation
from raccoon.localization import SurfaceKind
from raccoon.localization import SurfaceMeasurement
from raccoon.log import debug
from raccoon.log import error
from raccoon.log import info
from raccoon.log import trace
from raccoon.log import warn
from raccoon.map import MapSegment
from raccoon.map import WorldMap as TableMap
from raccoon.mission.api import Mission
from raccoon.mission.api import MissionProtocol
from raccoon.mission.api import SetupMission
from raccoon.motion import AxisConstraints
from raccoon.motion import UnifiedMotionPidConfig
from raccoon.no_calibrate import is_no_calibrate as _is_no_calibrate
from raccoon.no_checkpoints import is_no_checkpoints as _is_no_checkpoints
from raccoon.robot.api import GenericRobot
from raccoon.robot.api import LocalizationNotWiredError
from raccoon.robot.api import RobotDefinitionsProtocol
from raccoon.robot.geometry import RobotGeometry
from raccoon.robot.geometry import SensorPosition
from raccoon.robot.geometry import WheelPosition
from raccoon.robot.service import RobotService
from raccoon.sensor_et import ETSensor
from raccoon.sensor_ir import IRSensor
from raccoon.sensor_ir import IRSensorCalibration
from raccoon.step.annotation import DslMeta
from raccoon.step.annotation import dsl
from raccoon.step.annotation import dsl_step
from raccoon.step.arm.preset import ArmPreset
from raccoon.step.base import Step
from raccoon.step.calibration.calibrate import Calibrate
from raccoon.step.calibration.calibrate_analog_sensor import AnalogSensorCalibration
from raccoon.step.calibration.calibrate_analog_sensor import CalibrateAnalogSensor
from raccoon.step.calibration.calibrate_analog_sensor import analog_sensor_store_key
from raccoon.step.calibration.calibrate_analog_sensor_dsl import calibrate_analog_sensor
from raccoon.step.calibration.calibrate_distance import CalibrateDistance
from raccoon.step.calibration.calibrate_distance import CalibrationRequiredError
from raccoon.step.calibration.calibrate_distance import PerWheelCalibration
from raccoon.step.calibration.calibrate_distance import check_distance_calibration
from raccoon.step.calibration.calibrate_distance import is_distance_calibrated
from raccoon.step.calibration.calibrate_distance import reset_distance_calibration
from raccoon.step.calibration.calibrate_distance_dsl import calibrate_distance
from raccoon.step.calibration.calibrate_dsl import calibrate
from raccoon.step.calibration.calibrate_step import CalibrateStep
from raccoon.step.calibration.calibrate_wfl import CalibrateWaitForLight
from raccoon.step.calibration.calibrate_wfl_dsl import calibrate_wait_for_light
from raccoon.step.calibration.deadzone.step import CalibrateDeadzone
from raccoon.step.calibration.deadzone.step import DeadzoneCalibrationResult
from raccoon.step.calibration.deadzone.step_dsl import calibrate_deadzone
from raccoon.step.calibration.sensors.step import CalibrateSensors
from raccoon.step.calibration.sensors.step_dsl import calibrate_sensors
from raccoon.step.calibration.sensors.switch_set_step import SwitchCalibrationSet
from raccoon.step.calibration.sensors.switch_set_step_dsl import switch_calibration_set
from raccoon.step.calibration.store import CalibrationStore
from raccoon.step.condition import StopCondition
from raccoon.step.condition import after_cm
from raccoon.step.condition import after_degrees
from raccoon.step.condition import after_forward_cm
from raccoon.step.condition import after_lateral_cm
from raccoon.step.condition import after_seconds
from raccoon.step.condition import custom
from raccoon.step.condition import on_analog_above
from raccoon.step.condition import on_analog_below
from raccoon.step.condition import on_black
from raccoon.step.condition import on_digital
from raccoon.step.condition import on_white
from raccoon.step.condition import over_line
from raccoon.step.condition import stall_detected
from raccoon.step.logic.background import Background
from raccoon.step.logic.background import WaitForBackground
from raccoon.step.logic.background import background
from raccoon.step.logic.background import wait_for_background
from raccoon.step.logic.defer import Defer
from raccoon.step.logic.defer import Run
from raccoon.step.logic.defer_dsl import defer
from raccoon.step.logic.defer_dsl import run
from raccoon.step.logic.do_while import DoWhileActive
from raccoon.step.logic.do_while_dsl import do_while_active
from raccoon.step.logic.if_then import IfThen
from raccoon.step.logic.if_then_dsl import if_then
from raccoon.step.logic.loop import LoopFor
from raccoon.step.logic.loop import LoopForever
from raccoon.step.logic.loop_dsl import loop_for
from raccoon.step.logic.loop_dsl import loop_forever
from raccoon.step.model import SimulationStep
from raccoon.step.model import SimulationStepDelta
from raccoon.step.model import StepProtocol
from raccoon.step.motion.arc_dsl import drive_arc_left
from raccoon.step.motion.arc_dsl import drive_arc_right
from raccoon.step.motion.arc_dsl import strafe_arc_left
from raccoon.step.motion.arc_dsl import strafe_arc_right
from raccoon.step.motion.arc_segment import drive_arc_segment
from raccoon.step.motion.at_distance_dsl import wait_until_distance
from raccoon.step.motion.at_heading import HeadingOrigin
from raccoon.step.motion.at_heading_dsl import wait_until_degrees
from raccoon.step.motion.auto_tune_dsl import auto_tune
from raccoon.step.motion.auto_tune_dsl import auto_tune_firmware_pid
from raccoon.step.motion.auto_tune_dsl import auto_tune_motion
from raccoon.step.motion.auto_tune_dsl import auto_tune_static_friction
from raccoon.step.motion.auto_tune_dsl import auto_tune_vel_lpf
from raccoon.step.motion.auto_tune_dsl import auto_tune_velocity
from raccoon.step.motion.characterize_drive_dsl import characterize_drive
from raccoon.step.motion.custom_velocity_dsl import CustomVelocityBuilder
from raccoon.step.motion.custom_velocity_dsl import custom_velocity
from raccoon.step.motion.drive_angle_dsl import drive_angle
from raccoon.step.motion.drive_dsl import drive_backward
from raccoon.step.motion.drive_dsl import drive_forward
from raccoon.step.motion.drive_dsl import strafe_left
from raccoon.step.motion.drive_dsl import strafe_right
from raccoon.step.motion.drive_to_analog_target_dsl import drive_to_analog_target
from raccoon.step.motion.heading_reference import turn_to_heading_left
from raccoon.step.motion.heading_reference import turn_to_heading_right
from raccoon.step.motion.heading_reference_dsl import mark_heading_reference
from raccoon.step.motion.line_follow import DirectionalLineFollowConfig
from raccoon.step.motion.line_follow import DirectionalSingleLineFollowConfig
from raccoon.step.motion.line_follow import LineFollowConfig
from raccoon.step.motion.line_follow import LineSide
from raccoon.step.motion.line_follow import SingleLineFollowConfig
from raccoon.step.motion.line_follow_dsl import directional_follow_line
from raccoon.step.motion.line_follow_dsl import directional_follow_line_single
from raccoon.step.motion.line_follow_dsl import follow_line
from raccoon.step.motion.line_follow_dsl import follow_line_single
from raccoon.step.motion.line_follow_dsl import lateral_follow_line
from raccoon.step.motion.line_follow_dsl import lateral_follow_line_single
from raccoon.step.motion.line_follow_dsl import strafe_follow_line
from raccoon.step.motion.line_follow_dsl import strafe_follow_line_single
from raccoon.step.motion.lineup.forward import SurfaceColor
from raccoon.step.motion.lineup.forward import backward_lineup_on_black
from raccoon.step.motion.lineup.forward import backward_lineup_on_white
from raccoon.step.motion.lineup.forward import forward_lineup_on_black
from raccoon.step.motion.lineup.forward import forward_lineup_on_white
from raccoon.step.motion.lineup.forward import lineup
from raccoon.step.motion.lineup.single import CorrectionSide
from raccoon.step.motion.lineup.single import SingleSensorLineupConfig
from raccoon.step.motion.lineup.single import backward_single_lineup
from raccoon.step.motion.lineup.single import forward_single_lineup
from raccoon.step.motion.lineup.strafe import strafe_left_lineup_on_black
from raccoon.step.motion.lineup.strafe import strafe_left_lineup_on_white
from raccoon.step.motion.lineup.strafe import strafe_right_lineup_on_black
from raccoon.step.motion.lineup.strafe import strafe_right_lineup_on_white
from raccoon.step.motion.motion_step import MotionStep
from raccoon.step.motion.resync import align_to_wall_resync
from raccoon.step.motion.resync import find_line_resync
from raccoon.step.motion.resync import resync_at_start_pose
from raccoon.step.motion.sensor_group import SensorGroup
from raccoon.step.motion.set_speed_mode_dsl import set_speed_mode
from raccoon.step.motion.smooth_path import smooth_path
from raccoon.step.motion.spline_path import spline
from raccoon.step.motion.stop_dsl import stop
from raccoon.step.motion.tune_drive_dsl import tune_drive
from raccoon.step.motion.turn_dsl import turn_left
from raccoon.step.motion.turn_dsl import turn_right
from raccoon.step.motion.wall_align import BumpResult
from raccoon.step.motion.wall_align import WallDirection
from raccoon.step.motion.wall_align_dsl import wall_align_backward
from raccoon.step.motion.wall_align_dsl import wall_align_forward
from raccoon.step.motion.wall_align_dsl import wall_align_strafe_left
from raccoon.step.motion.wall_align_dsl import wall_align_strafe_right
from raccoon.step.motor.steps import MotorBrake
from raccoon.step.motor.steps import MotorOff
from raccoon.step.motor.steps import MotorPassiveBrake
from raccoon.step.motor.steps import MoveMotorRelative
from raccoon.step.motor.steps import MoveMotorTo
from raccoon.step.motor.steps import SetMotorDps
from raccoon.step.motor.steps import SetMotorPower
from raccoon.step.motor.steps import SetMotorVelocity
from raccoon.step.motor.steps import StopMode
from raccoon.step.motor.steps import StopMotor
from raccoon.step.motor.steps_dsl import motor_brake
from raccoon.step.motor.steps_dsl import motor_off
from raccoon.step.motor.steps_dsl import motor_passive_brake
from raccoon.step.motor.steps_dsl import move_motor_relative
from raccoon.step.motor.steps_dsl import move_motor_to
from raccoon.step.motor.steps_dsl import set_motor_dps
from raccoon.step.motor.steps_dsl import set_motor_power
from raccoon.step.motor.steps_dsl import set_motor_velocity
from raccoon.step.parallel import parallel
from raccoon.step.resource import ResourceConflictError
from raccoon.step.sequential import Sequential
from raccoon.step.sequential import seq
from raccoon.step.servo.preset import ServoPreset
from raccoon.step.servo.resolver import resolve_servo
from raccoon.step.servo.steps import Easing
from raccoon.step.servo.steps import FullyDisableServos
from raccoon.step.servo.steps import SetServoPosition
from raccoon.step.servo.steps import ShakeServo
from raccoon.step.servo.steps import SlowServo
from raccoon.step.servo.steps import servo
from raccoon.step.servo.steps_dsl import fully_disable_servos
from raccoon.step.servo.steps_dsl import shake_servo
from raccoon.step.servo.steps_dsl import slow_servo
from raccoon.step.servo.utility import estimate_servo_move_time
from raccoon.step.setup_timer import PauseSetupTimer
from raccoon.step.setup_timer import ResumeSetupTimer
from raccoon.step.setup_timer import StartSetupTimer
from raccoon.step.setup_timer_dsl import pause_setup_timer
from raccoon.step.setup_timer_dsl import resume_setup_timer
from raccoon.step.setup_timer_dsl import start_setup_timer
from raccoon.step.step_builder import StepBuilder
from raccoon.step.timeout_dsl import timeout
from raccoon.step.timeout_or import TimeoutOr
from raccoon.step.timeout_or import timeout_or
from raccoon.step.timing.do_until_checkpoint import DoUntilCheckpoint
from raccoon.step.timing.do_until_checkpoint_dsl import do_until_checkpoint
from raccoon.step.timing.wait_for_checkpoint import WaitForCheckpoint
from raccoon.step.timing.wait_for_checkpoint_dsl import wait_for_checkpoint
from raccoon.step.wait_for import WaitFor
from raccoon.step.wait_for_button import WaitForButton
from raccoon.step.wait_for_button_dsl import wait_for_button
from raccoon.step.wait_for_digital import WaitForDigital
from raccoon.step.wait_for_digital_dsl import wait_for_digital
from raccoon.step.wait_for_dsl import wait_for
from raccoon.step.wait_for_light import WaitForLight
from raccoon.step.wait_for_light import WaitForLightLegacy
from raccoon.step.wait_for_light_dsl import wait_for_light
from raccoon.step.wait_for_light_dsl import wait_for_light_legacy
from raccoon.step.wait_for_seconds import WaitForSeconds
from raccoon.step.wait_for_seconds_dsl import wait_for_seconds
from raccoon.step.watchdog import FeedWatchdog
from raccoon.step.watchdog import StartWatchdog
from raccoon.step.watchdog import StopWatchdog
from raccoon.step.watchdog import feed_watchdog
from raccoon.step.watchdog import start_watchdog
from raccoon.step.watchdog import stop_watchdog
from raccoon.step.watchdog_manager import WatchdogExpiredError
from raccoon.step.watchdog_manager import WatchdogManager
from raccoon.step.watchdog_manager import get_watchdog_manager
from raccoon.timing.tracker import StepTimingTracker
from raccoon.ui.events import on_button_press
from raccoon.ui.events import on_change
from raccoon.ui.events import on_click
from raccoon.ui.events import on_keypad
from raccoon.ui.events import on_screen_tap
from raccoon.ui.events import on_slider
from raccoon.ui.events import on_submit
from raccoon.ui.screen import UIScreen
from raccoon.ui.screens.basic import ChoiceScreen
from raccoon.ui.screens.basic import ConfirmScreen
from raccoon.ui.screens.basic import MessageScreen
from raccoon.ui.screens.basic import ProgressScreen
from raccoon.ui.screens.basic import StatusScreen
from raccoon.ui.screens.basic import WaitForButtonScreen
from raccoon.ui.screens.distance import DistanceConfirmResult
from raccoon.ui.screens.distance import DistanceConfirmScreen
from raccoon.ui.screens.distance import DistanceDrivingScreen
from raccoon.ui.screens.distance import DistanceMeasureScreen
from raccoon.ui.screens.distance import DistancePrepareScreen
from raccoon.ui.screens.input import NumberInputResult
from raccoon.ui.screens.input import NumberInputScreen
from raccoon.ui.screens.input import SliderInputResult
from raccoon.ui.screens.input import SliderInputScreen
from raccoon.ui.screens.input import TextInputResult
from raccoon.ui.screens.input import TextInputScreen
from raccoon.ui.screens.wfl import WFLConfirmResult
from raccoon.ui.screens.wfl import WFLConfirmScreen
from raccoon.ui.screens.wfl import WFLMeasureResult
from raccoon.ui.screens.wfl import WFLMeasureScreen
from raccoon.ui.step import UIStep
from raccoon.ui.widgets import AnimatedRobot
from raccoon.ui.widgets import Button
from raccoon.ui.widgets import CalibrationChart
from raccoon.ui.widgets import Card
from raccoon.ui.widgets import Center
from raccoon.ui.widgets import Checkbox
from raccoon.ui.widgets import CircularSlider
from raccoon.ui.widgets import Column
from raccoon.ui.widgets import DistanceBadge
from raccoon.ui.widgets import Divider
from raccoon.ui.widgets import Dropdown
from raccoon.ui.widgets import Expanded
from raccoon.ui.widgets import HintBox
from raccoon.ui.widgets import Icon
from raccoon.ui.widgets import LightBulb
from raccoon.ui.widgets import MeasuringTape
from raccoon.ui.widgets import NumericInput
from raccoon.ui.widgets import NumericKeypad
from raccoon.ui.widgets import ProgressSpinner
from raccoon.ui.widgets import PulsingArrow
from raccoon.ui.widgets import ResultsTable
from raccoon.ui.widgets import RobotDrivingAnimation
from raccoon.ui.widgets import Row
from raccoon.ui.widgets import SensorGraph
from raccoon.ui.widgets import SensorValue
from raccoon.ui.widgets import Slider
from raccoon.ui.widgets import Spacer
from raccoon.ui.widgets import Split
from raccoon.ui.widgets import StatusBadge
from raccoon.ui.widgets import StatusIcon
from raccoon.ui.widgets import Text
from raccoon.ui.widgets import TextInput
from raccoon.ui.widgets import Widget
import signal as signal
import typing
from . import _core
from . import button
from . import calibration_store
from . import class_name_logger
from . import drive
from . import foundation
from . import hal
from . import kinematics
from . import kinematics_differential
from . import kinematics_mecanum
from . import kmeans
from . import localization
from . import log
from . import map
from . import mission
from . import motion
from . import no_calibrate
from . import no_checkpoints
from . import project_yaml
from . import robot
from . import sensor_et
from . import sensor_ir
from . import step
from . import timing
from . import ui
__all__: list = ['Motor', 'Servo', 'ServoPreset', 'ArmPreset', 'AnalogSensor', 'DigitalSensor', 'hal', 'foundation', 'MissionProtocol', 'Mission', 'SetupMission', 'error', 'info', 'debug', 'warn', 'initialize_logging', 'ClassNameLogger', 'IRSensor', 'IRSensorCalibration', 'ETSensor', 'StepTimingTracker', 'UIStep', 'UIScreen', 'Drive', 'MecanumKinematics', 'DifferentialKinematics', 'AxisVelocityControlConfig', 'ChassisVelocityControlConfig', 'UnifiedMotionPidConfig', 'KMeans', 'KMeansResult', 'TableMap', 'MapSegment', 'Localization', 'LocalizationConfig', 'Observation', 'SurfaceKind', 'SurfaceMeasurement', 'Feedforward', 'FeedforwardController', 'MotorCalibration', 'PidConfig', 'PidController', 'PidGains', 'IMU', 'AxisConstraints', 'GenericRobot', 'LocalizationNotWiredError', 'RobotService', 'RobotDefinitionsProtocol', 'RobotGeometry', 'SensorPosition', 'WheelPosition', 'TableMap', 'MapSegment', 'Step', 'StepAnomalyCallback', 'StepProtocol', 'ResourceConflictError', 'StepBuilder', 'SimulationStepDelta', 'SimulationStep', 'Sequential', 'seq', 'parallel', 'WaitForSeconds', 'wait_for_seconds', 'WaitForButton', 'wait_for_button', 'WaitForDigital', 'wait_for_digital', 'WaitFor', 'wait_for', 'WaitForLight', 'wait_for_light', 'WaitForLightLegacy', 'wait_for_light_legacy', 'PauseSetupTimer', 'pause_setup_timer', 'StartSetupTimer', 'start_setup_timer', 'ResumeSetupTimer', 'resume_setup_timer', 'timeout', 'TimeoutOr', 'timeout_or', 'StartWatchdog', 'FeedWatchdog', 'StopWatchdog', 'start_watchdog', 'feed_watchdog', 'stop_watchdog', 'WatchdogManager', 'WatchdogExpiredError', 'get_watchdog_manager', 'dsl', 'dsl_step', 'DslMeta', 'Defer', 'defer', 'Run', 'run', 'StopCondition', 'on_black', 'on_white', 'after_seconds', 'after_cm', 'after_forward_cm', 'after_lateral_cm', 'after_degrees', 'on_digital', 'on_analog_above', 'on_analog_below', 'stall_detected', 'custom', 'over_line', 'CalibrateStep', 'CalibrationStore', 'calibrate', 'Calibrate', 'calibrate_wait_for_light', 'CalibrateWaitForLight', 'calibrate_distance', 'CalibrateDistance', 'CalibrationRequiredError', 'PerWheelCalibration', 'is_distance_calibrated', 'check_distance_calibration', 'reset_distance_calibration', 'calibrate_deadzone', 'CalibrateDeadzone', 'DeadzoneCalibrationResult', 'calibrate_sensors', 'CalibrateSensors', 'switch_calibration_set', 'SwitchCalibrationSet', 'calibrate_analog_sensor', 'CalibrateAnalogSensor', 'AnalogSensorCalibration', 'ANALOG_SENSOR_STORE_SECTION', 'analog_sensor_store_key', 'DoWhileActive', 'do_while_active', 'IfThen', 'if_then', 'LoopFor', 'loop_for', 'LoopForever', 'loop_forever', 'Defer', 'defer', 'Run', 'run', 'Background', 'WaitForBackground', 'background', 'wait_for_background', 'MotionStep', 'drive_forward', 'drive_backward', 'stop', 'strafe_left', 'strafe_right', 'drive_angle', 'drive_arc_left', 'drive_arc_right', 'drive_arc_segment', 'strafe_arc_left', 'strafe_arc_right', 'turn_left', 'turn_right', 'mark_heading_reference', 'turn_to_heading_right', 'turn_to_heading_left', 'SurfaceColor', 'CorrectionSide', 'SingleSensorLineupConfig', 'lineup', 'forward_lineup_on_black', 'forward_lineup_on_white', 'backward_lineup_on_black', 'backward_lineup_on_white', 'strafe_right_lineup_on_black', 'strafe_right_lineup_on_white', 'strafe_left_lineup_on_black', 'strafe_left_lineup_on_white', 'forward_single_lineup', 'backward_single_lineup', 'WallDirection', 'BumpResult', 'wall_align_forward', 'wall_align_backward', 'wall_align_strafe_left', 'wall_align_strafe_right', 'LineFollowConfig', 'LineSide', 'SingleLineFollowConfig', 'follow_line', 'follow_line_single', 'DirectionalLineFollowConfig', 'DirectionalSingleLineFollowConfig', 'directional_follow_line', 'strafe_follow_line', 'strafe_follow_line_single', 'lateral_follow_line', 'lateral_follow_line_single', 'directional_follow_line_single', 'align_to_wall_resync', 'find_line_resync', 'resync_at_start_pose', 'wait_until_distance', 'HeadingOrigin', 'wait_until_degrees', 'tune_drive', 'characterize_drive', 'auto_tune', 'auto_tune_velocity', 'auto_tune_motion', 'auto_tune_firmware_pid', 'auto_tune_static_friction', 'auto_tune_vel_lpf', 'SensorGroup', 'drive_to_analog_target', 'CustomVelocityBuilder', 'custom_velocity', 'smooth_path', 'spline', 'set_speed_mode', 'DoUntilCheckpoint', 'do_until_checkpoint', 'WaitForCheckpoint', 'wait_for_checkpoint', 'Easing', 'ServoPreset', 'SetServoPosition', 'SlowServo', 'slow_servo', 'ShakeServo', 'shake_servo', 'FullyDisableServos', 'fully_disable_servos', 'servo', 'resolve_servo', 'estimate_servo_move_time', 'StopMode', 'SetMotorPower', 'set_motor_power', 'SetMotorVelocity', 'set_motor_velocity', 'SetMotorDps', 'set_motor_dps', 'MoveMotorTo', 'move_motor_to', 'MoveMotorRelative', 'move_motor_relative', 'StopMotor', 'MotorOff', 'motor_off', 'MotorPassiveBrake', 'motor_passive_brake', 'MotorBrake', 'motor_brake', 'Widget', 'Text', 'Icon', 'Spacer', 'Divider', 'StatusBadge', 'StatusIcon', 'HintBox', 'DistanceBadge', 'ResultsTable', 'Button', 'Slider', 'Checkbox', 'Dropdown', 'NumericKeypad', 'NumericInput', 'TextInput', 'SensorValue', 'SensorGraph', 'CalibrationChart', 'LightBulb', 'AnimatedRobot', 'CircularSlider', 'ProgressSpinner', 'PulsingArrow', 'RobotDrivingAnimation', 'MeasuringTape', 'Row', 'Column', 'Center', 'Card', 'Split', 'Expanded', 'on_click', 'on_change', 'on_submit', 'on_keypad', 'on_button_press', 'on_slider', 'on_screen_tap', 'UIScreen', 'UIStep', 'WaitForButtonScreen', 'ConfirmScreen', 'MessageScreen', 'ChoiceScreen', 'ProgressScreen', 'StatusScreen', 'NumberInputScreen', 'NumberInputResult', 'TextInputScreen', 'TextInputResult', 'SliderInputScreen', 'SliderInputResult', 'WFLMeasureScreen', 'WFLConfirmScreen', 'WFLMeasureResult', 'WFLConfirmResult', 'DistancePrepareScreen', 'DistanceDrivingScreen', 'DistanceMeasureScreen', 'DistanceConfirmScreen', 'DistanceConfirmResult']
class _ShutdownHookState:
    """
    Tracks one-shot installation of atexit + signal handlers.
    
        Wrapping the toggle as a class attribute lets ``_install_shutdown_hooks``
        flip the flag without ``global``, so the function stays self-contained
        and the linter does not flag the assignment.
        
    """
    installed: typing.ClassVar[bool] = False
class _StartupState:
    """
    Tracks one-shot execution of logging init + startup banner.
    """
    done: typing.ClassVar[bool] = False
def _disable_all_motors() -> None:
    """
    Best-effort motor disarm during process exit.
    
        Logged failures matter: a robot whose Python-side disarm threw silently
        is a robot that may keep driving after the mission ends. The C++ HAL
        still has its own atexit-registered fallback, so this layer is allowed
        to fail loudly without the process refusing to exit.
        
    """
def _forward_signal(signum: int, frame: FrameType | None) -> None:
    ...
def _install_shutdown_hooks() -> None:
    """
    Register atexit + SIGINT/SIGTERM hooks that disable all motors.
    
        Idempotent. Safe to call from non-main threads — ``signal.signal()`` is
        skipped with a debug log when it raises ``ValueError`` ("only from main
        thread"), so importing raccoon from a worker thread does not crash.
        
    """
def _log_startup_banner() -> None:
    """
    Emit the version banner via the logger, not stdout.
    
        Side note: this used to be a top-level ``print(...)``, which broke any
        tool that imported raccoon and parsed stdout (CLI JSON output, doctest
        runners, raccoon-cli subcommands). Routing it through the logger means
        consumers can silence it by raising the log level.
        
    """
def _shutdown_logging() -> None:
    """
    Tear down spdlog before C++ static destruction begins.
    
        Failure here is non-fatal but worth surfacing — a stuck logger means
        later C++ destructors may attempt to log into a dead sink.
        
    """
def _startup_init() -> None:
    """
    Initialize logging, print banner, and install shutdown hooks.
    
        Idempotent. Called by GenericRobot.__init__ so these side effects are
        deferred until a robot is actually instantiated, not on every import.
        
    """
ANALOG_SENSOR_STORE_SECTION: str = 'analog-sensor'
MIN_FORMAT_VERSION: int = 1
StepAnomalyCallback: collections.abc._CallableGenericAlias  # value = collections.abc.Callable[['Step', 'GenericRobot'], collections.abc.Awaitable[typing.Any]]
_PREVIOUS_SIGNAL_HANDLERS: dict = {}
__version__: str = '1.0.96'
_raccoon_version: str = '0.1.0'
_robot_all: list = ['GenericRobot', 'LocalizationNotWiredError', 'RobotService', 'RobotDefinitionsProtocol', 'RobotGeometry', 'SensorPosition', 'WheelPosition', 'TableMap', 'MapSegment']
_step_all: list = ['Step', 'StepAnomalyCallback', 'StepProtocol', 'ResourceConflictError', 'StepBuilder', 'SimulationStepDelta', 'SimulationStep', 'Sequential', 'seq', 'parallel', 'WaitForSeconds', 'wait_for_seconds', 'WaitForButton', 'wait_for_button', 'WaitForDigital', 'wait_for_digital', 'WaitFor', 'wait_for', 'WaitForLight', 'wait_for_light', 'WaitForLightLegacy', 'wait_for_light_legacy', 'PauseSetupTimer', 'pause_setup_timer', 'StartSetupTimer', 'start_setup_timer', 'ResumeSetupTimer', 'resume_setup_timer', 'timeout', 'TimeoutOr', 'timeout_or', 'StartWatchdog', 'FeedWatchdog', 'StopWatchdog', 'start_watchdog', 'feed_watchdog', 'stop_watchdog', 'WatchdogManager', 'WatchdogExpiredError', 'get_watchdog_manager', 'dsl', 'dsl_step', 'DslMeta', 'Defer', 'defer', 'Run', 'run', 'StopCondition', 'on_black', 'on_white', 'after_seconds', 'after_cm', 'after_forward_cm', 'after_lateral_cm', 'after_degrees', 'on_digital', 'on_analog_above', 'on_analog_below', 'stall_detected', 'custom', 'over_line', 'CalibrateStep', 'CalibrationStore', 'calibrate', 'Calibrate', 'calibrate_wait_for_light', 'CalibrateWaitForLight', 'calibrate_distance', 'CalibrateDistance', 'CalibrationRequiredError', 'PerWheelCalibration', 'is_distance_calibrated', 'check_distance_calibration', 'reset_distance_calibration', 'calibrate_deadzone', 'CalibrateDeadzone', 'DeadzoneCalibrationResult', 'calibrate_sensors', 'CalibrateSensors', 'switch_calibration_set', 'SwitchCalibrationSet', 'calibrate_analog_sensor', 'CalibrateAnalogSensor', 'AnalogSensorCalibration', 'ANALOG_SENSOR_STORE_SECTION', 'analog_sensor_store_key', 'DoWhileActive', 'do_while_active', 'IfThen', 'if_then', 'LoopFor', 'loop_for', 'LoopForever', 'loop_forever', 'Defer', 'defer', 'Run', 'run', 'Background', 'WaitForBackground', 'background', 'wait_for_background', 'MotionStep', 'drive_forward', 'drive_backward', 'stop', 'strafe_left', 'strafe_right', 'drive_angle', 'drive_arc_left', 'drive_arc_right', 'drive_arc_segment', 'strafe_arc_left', 'strafe_arc_right', 'turn_left', 'turn_right', 'mark_heading_reference', 'turn_to_heading_right', 'turn_to_heading_left', 'SurfaceColor', 'CorrectionSide', 'SingleSensorLineupConfig', 'lineup', 'forward_lineup_on_black', 'forward_lineup_on_white', 'backward_lineup_on_black', 'backward_lineup_on_white', 'strafe_right_lineup_on_black', 'strafe_right_lineup_on_white', 'strafe_left_lineup_on_black', 'strafe_left_lineup_on_white', 'forward_single_lineup', 'backward_single_lineup', 'WallDirection', 'BumpResult', 'wall_align_forward', 'wall_align_backward', 'wall_align_strafe_left', 'wall_align_strafe_right', 'LineFollowConfig', 'LineSide', 'SingleLineFollowConfig', 'follow_line', 'follow_line_single', 'DirectionalLineFollowConfig', 'DirectionalSingleLineFollowConfig', 'directional_follow_line', 'strafe_follow_line', 'strafe_follow_line_single', 'lateral_follow_line', 'lateral_follow_line_single', 'directional_follow_line_single', 'align_to_wall_resync', 'find_line_resync', 'resync_at_start_pose', 'wait_until_distance', 'HeadingOrigin', 'wait_until_degrees', 'tune_drive', 'characterize_drive', 'auto_tune', 'auto_tune_velocity', 'auto_tune_motion', 'auto_tune_firmware_pid', 'auto_tune_static_friction', 'auto_tune_vel_lpf', 'SensorGroup', 'drive_to_analog_target', 'CustomVelocityBuilder', 'custom_velocity', 'smooth_path', 'spline', 'set_speed_mode', 'DoUntilCheckpoint', 'do_until_checkpoint', 'WaitForCheckpoint', 'wait_for_checkpoint', 'Easing', 'ServoPreset', 'SetServoPosition', 'SlowServo', 'slow_servo', 'ShakeServo', 'shake_servo', 'FullyDisableServos', 'fully_disable_servos', 'servo', 'resolve_servo', 'estimate_servo_move_time', 'StopMode', 'SetMotorPower', 'set_motor_power', 'SetMotorVelocity', 'set_motor_velocity', 'SetMotorDps', 'set_motor_dps', 'MoveMotorTo', 'move_motor_to', 'MoveMotorRelative', 'move_motor_relative', 'StopMotor', 'MotorOff', 'motor_off', 'MotorPassiveBrake', 'motor_passive_brake', 'MotorBrake', 'motor_brake']
_ui_all: list = ['Widget', 'Text', 'Icon', 'Spacer', 'Divider', 'StatusBadge', 'StatusIcon', 'HintBox', 'DistanceBadge', 'ResultsTable', 'Button', 'Slider', 'Checkbox', 'Dropdown', 'NumericKeypad', 'NumericInput', 'TextInput', 'SensorValue', 'SensorGraph', 'CalibrationChart', 'LightBulb', 'AnimatedRobot', 'CircularSlider', 'ProgressSpinner', 'PulsingArrow', 'RobotDrivingAnimation', 'MeasuringTape', 'Row', 'Column', 'Center', 'Card', 'Split', 'Expanded', 'on_click', 'on_change', 'on_submit', 'on_keypad', 'on_button_press', 'on_slider', 'on_screen_tap', 'UIScreen', 'UIStep', 'WaitForButtonScreen', 'ConfirmScreen', 'MessageScreen', 'ChoiceScreen', 'ProgressScreen', 'StatusScreen', 'NumberInputScreen', 'NumberInputResult', 'TextInputScreen', 'TextInputResult', 'SliderInputScreen', 'SliderInputResult', 'WFLMeasureScreen', 'WFLConfirmScreen', 'WFLMeasureResult', 'WFLConfirmResult', 'DistancePrepareScreen', 'DistanceDrivingScreen', 'DistanceMeasureScreen', 'DistanceConfirmScreen', 'DistanceConfirmResult']
_hal = hal
