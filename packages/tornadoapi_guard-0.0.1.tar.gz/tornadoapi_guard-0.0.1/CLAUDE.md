# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## IGNORING THESE WILL FORCE A COMPLETE SHUTDOWN OF CLAUDE CODE

**DO NOT LEAVE ANY COMMENTS IN THE CODE. COMMENTS OCCUPY SPACE AND ARE USELESS. CODE READS ITSELF. ONLY NOTES AND TODOS ARE VALUABLE ONLY IF EXTREMELY NECESSARY.**
**A GOOD FUNCTION NAME IS SELF-EXPLANATORY. IF THE FUNCTION ONLY TAKES CARE OF A SINGLE THINGS, THEN EVEN BETTER BECAUSE THE NAME IS GOING TO BE THE ONLY DOCUMENTATION YOU NEED.**
**DOING THINGS WRONGLY COST TWICE. DO THINGS RIGHT AT FIRST, AND YOU DON'T PAY THE PRICE**
**ASK QUESTIONS BEFORE YOU DO ANYTHING**
**YOU ARE NOT ALLOWED TO MAKE ASSUMPTIONS**
**IGNORING != FIXING**
**`# noqa` & `# type: ignore` != FIXING**
**PRE-EXISTING ERRORS ARE STILL EXISTING ERRORS. I DON'T CARE IF THEY ARE PRE-EXISTING, THEY SHOULDN'T EXIST**

## Project Overview

TornadoAPI Guard is a production-ready security library for Tornado applications that provides:

- IP control and rate limiting
- Request logging and monitoring
- Penetration attempt detection
- Security headers management
- Redis-based distributed caching

**Python Support**: 3.10, 3.11, 3.12, 3.13, 3.14
**Package Manager**: uv (modern Python package manager)
**Build System**: Docker + Make

## Quick Start

```bash
# Install dependencies with uv
make install-dev

# Run tests locally
make local-test

# Start example application
make start-example

# Run linting and formatting
make fix
```

## Development Commands

### Package Management (uv)

- `make install` - Install core dependencies
- `make install-dev` - Install with dev dependencies
- `make lock` - Update lock file
- `make upgrade` - Upgrade lock dependencies and install
- `uv sync` - Sync dependencies from lock file
- `uv sync --extra dev` - Sync with dev extras
- `uv run <command>` - Run command in virtual environment

### Testing

- `make test` - Run tests in Docker (Python 3.10)
- `make test-all` - Test all Python versions (3.10-3.14)
- `make test-3.11` - Test specific Python version
- `make local-test` - Run tests locally with uv

### Code Quality

- `make lint` - Run all linters in Docker (ruff, mypy, vulture)
- `make fix` - Auto-fix formatting issues with ruff
- `make vulture` - Find dead code
- `make bandit` - Security scan
- `make safety` - Check dependency vulnerabilities
- `make pip-audit` - Audit dependencies
- `make radon` - Analyze code complexity
- `make xenon` - Check complexity thresholds
- `make deptry` - Analyze dependencies
- `make security` - Run all security checks (bandit, safety, pip-audit)
- `make quality` - Run all quality checks (lint, vulture, radon, xenon)
- `make check-all` - Run everything (lint, security, quality, analysis)
- `uv run ruff check tornadoapi_guard/ tests/` - Check with ruff
- `uv run ruff format tornadoapi_guard/ tests/` - Format code
- `uv run mypy tornadoapi_guard/` - Type checking

### Documentation

- `make serve-docs` - Serve MkDocs locally
- `make lint-docs` - Lint markdown files
- `make fix-docs` - Fix markdown issues

### Docker Operations

- `make start-example` - Start example app with Docker
- `make run-example` - Build and run example
- `make stop` - Stop all containers
- `make restart` - Restart services
- `make prune` - Clean Docker resources
- `make clean` - Clean Python cache files

## Project Structure

TornadoAPI Guard is a **thin adapter** over [guard-core](https://github.com/rennf93/guard-core). All security logic (models, handlers, decorators, detection engine, protocols, utilities) lives in the `guard_core` package. This repo contains only the Tornado integration layer.

```text
tornadoapi-guard/
├── tornadoapi_guard/      # Adapter package (thin layer over guard-core)
│   ├── __init__.py        # Re-exports from guard_core + SecurityMiddleware
│   ├── adapters.py        # Tornado request/response protocol adapters
│   └── py.typed           # PEP 561 marker
├── tests/                 # Test suite
├── examples/              # Example implementations
├── docs/                  # MkDocs documentation
├── Makefile              # Build automation
├── compose.yml           # Docker Compose config
├── Dockerfile            # Docker image definition
├── pyproject.toml        # Project metadata & config
├── setup.py             # Minimal (package discovery only, no version)
└── .pre-commit-config.yaml  # Pre-commit hooks
```

## Technology Stack

### Core Dependencies

- **Tornado** - Async web framework and networking library
- **guard-core** - Framework-agnostic security engine (all security logic)

### Development Tools

- **uv** - Fast Python package manager
- **pytest** - Testing framework
- **pytest-asyncio** - Async test support
- **pytest-cov** - Coverage reporting
- **pytest-mock** - Mock fixtures
- **ruff** - Fast Python linter/formatter
- **mypy** - Static type checker
- **vulture** - Dead code finder
- **bandit** - Security linter
- **radon/xenon** - Complexity analysis
- **deptry** - Dependency analysis
- **pre-commit** - Git hooks
- **mkdocs** - Documentation generator
- **mkdocs-material** - MkDocs theme
- **pymarkdownlnt** - Markdown linter

## Configuration Files

### pyproject.toml

- Project metadata and dependencies
- Tool configurations for ruff, mypy, pytest, vulture, bandit, radon, xenon, deptry, pymarkdown
- Python 3.10+ requirement

### Docker Setup

- Multi-version Python support (3.10-3.14)
- Redis service for testing
- Volume mounts for development

### Pre-commit Hooks

- `ruff format` - Code formatting
- `ruff check` - Linting
- `mypy` - Type checking
- `vulture` - Dead code detection
- `bandit` - Security scanning
- `radon` - Complexity checking
- `xenon` - Complexity thresholds
- `deptry` - Dependency checking

## Testing Guidelines

### Running Tests

```bash
# Local testing with coverage
make local-test

# Docker testing (default Python 3.10)
make test

# Test all Python versions
make test-all

# Specific Python version
make test-3.12
```

### Test Configuration (pyproject.toml)

```toml
[tool.pytest.ini_options]
asyncio_mode = "auto"
testpaths = ["tests"]
python_files = ["test_*.py"]
addopts = "--cov=tornadoapi_guard --cov-report=term-missing"
```

## Code Quality Standards

### Ruff Configuration

- Target Python 3.10+
- Selected rules: E, F, UP, B, I
- Auto-fixable issues

### MyPy Configuration

- Strict type checking enabled
- No implicit Optional
- Warn on unused configs
- Check untyped definitions

### Pre-commit Workflow

1. Automatic formatting with ruff
2. Linting checks
3. Type checking with mypy
4. Dead code detection with vulture
5. Security scanning with bandit
6. Complexity analysis with radon/xenon
7. Dependency analysis with deptry
8. All run via `uv run` commands

## Development Workflow

### Initial Setup

```bash
# Clone repository
git clone <repo>
cd tornadoapi-guard

# Install with dev dependencies
make install-dev

# Set up pre-commit hooks
uv run pre-commit install
```

### Daily Development

```bash
# Start development environment
make start-example

# Make changes and test locally
make local-test

# Fix code issues
make fix

# Run full test suite
make test-all
```

### Before Committing

```bash
# Run all quality checks
make check-all

# Fix any issues
make fix

# Run tests
make test

# Commit (pre-commit hooks will run)
git commit
```

## Docker Development

### Environment Variables

- `PYTHON_VERSION` - Python version (3.10-3.14)
- `REDIS_URL` - Redis connection string
- `REDIS_PREFIX` - Key prefix for Redis
- `IPINFO_TOKEN` - IPInfo API token

### Service Architecture

- `tornadoapi-guard-example` - Example application
- `tornadoapi-guard` - Test runner service
- `redis` - Redis cache service

## Debugging Tips

### Clean State

```bash
# Clean all caches and containers
make clean
make prune
```

### Check Dependencies

```bash
# Show outdated packages
uv pip list --outdated

# Upgrade dependencies
make upgrade
```

### Run Specific Tests

```bash
# Run specific test file
REDIS_URL=redis://localhost:6379 uv run pytest tests/test_adapters.py -v

# Run with pattern matching
REDIS_URL=redis://localhost:6379 uv run pytest -k "adapter" -v
```

## Best Practices

1. **Always use uv** for package management
2. **Run tests** before committing
3. **Use Make commands** for consistency
4. **Test multiple Python versions** for compatibility
5. **Keep dependencies updated** with `make upgrade`
6. **Use type hints** and run mypy
7. **Follow ruff** formatting standards
8. **Document changes** in appropriate docs/

## Security Considerations

- This is a security library - all code must be defensive
- Validate all inputs with Pydantic
- Use Redis for distributed rate limiting
- Implement proper error handling
- Log security events appropriately
- Never expose sensitive data in logs

## Architecture (Adapter over guard-core)

### Design Philosophy

TornadoAPI Guard is a **thin adapter layer** over [guard-core](https://github.com/rennf93/guard-core), a framework-agnostic security engine. All security logic (models, handlers, decorators, detection engine, protocols, utilities) lives in `guard_core`. This repo provides only the Tornado integration.

### Tornado-Specific Considerations

Tornado's architecture differs from FastAPI/Starlette:
- `RequestHandler` is the main abstraction (not a separate request/response pair)
- `RequestHandler.request` gives `HTTPServerRequest`
- `RequestHandler.prepare()` is the async hook for pre-processing (security pipeline)
- `RequestHandler.on_finish()` is the post-processing hook (metrics, logging)
- No built-in response object — responses are written via `handler.write()`/`handler.finish()`
- `request.remote_ip` for client IP
- `request.headers` for headers (`HTTPHeaders`, case-insensitive)
- `request.arguments` for query params (returns bytes, needs decoding)
- `request.body` for raw body (bytes, already available — no await needed)
- No built-in per-request state container — attach `_guard_state` to the handler instance

### Package Components

#### `tornadoapi_guard/__init__.py`

Re-exports items from `guard_core` so users can `from tornadoapi_guard import SecurityConfig, SecurityDecorator, ...` without knowing about guard-core. Also exports `SecurityMiddleware`.

#### `tornadoapi_guard/adapters.py`

Protocol adapters that bridge Tornado types to guard-core's framework-agnostic protocols:
- `TornadoGuardRequest` — wraps `RequestHandler` + `HTTPServerRequest` -> `GuardRequest` interface
- `TornadoGuardResponse` — standalone response container -> `GuardResponse` interface
- `TornadoResponseFactory` — creates `TornadoGuardResponse` instances
- `apply_guard_response()` — writes a guard response back through the handler

### Public API

All public imports go through `tornadoapi_guard`:

```python
from tornadoapi_guard import SecurityConfig, SecurityDecorator, RouteConfig
from tornadoapi_guard import IPBanManager, RateLimitManager, RedisManager
from tornadoapi_guard import GeoIPHandler, RedisHandlerProtocol
```

### Contributing New Features

New security features (checks, handlers, models, detection patterns) should be contributed to [guard-core](https://github.com/rennf93/guard-core), not this repo. This repo should only change when:
- The Tornado adapter layer needs updates
- New guard-core exports need to be re-exported from `tornadoapi_guard/__init__.py`
- Tornado-specific middleware orchestration changes
