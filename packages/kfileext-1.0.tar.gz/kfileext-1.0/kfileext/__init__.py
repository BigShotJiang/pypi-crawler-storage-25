# -*- coding: utf-8 -*-
__version__ = '1.0'
try:
    from .fileext import etx
except:
    print("from .pyfileext import etx 失败")