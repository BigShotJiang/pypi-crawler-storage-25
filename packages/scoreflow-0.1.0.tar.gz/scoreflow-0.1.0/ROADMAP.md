# ScoreFlow — Build Roadmap

A phased plan to build the production-ready automated ML scoring engine described in the README.

---

## Phase 1: Foundation & project setup

**Goal:** Reproducible environment, package layout, and basic config.

- [x] **1.1** Choose dependency manager (e.g. `uv`, `poetry`, or `pdm`) and add `pyproject.toml` with:
  - Project metadata and Python version
  - Core dependencies: `pandas`, `scikit-learn`, `numpy`, optional `lightgbm`/`xgboost`
  - Dev deps: `pytest`, `ruff`, `mypy` (or similar)
- [x] **1.2** Define package layout, e.g.:
  ```
  scoreflow/
    __init__.py
    config.py
    data/
    models/
    evaluation/
    api/
    pipeline/
  ```
- [x] **1.3** Add minimal config (env vars, paths, model defaults) in `config.py` or a small config module.
- [x] **1.4** Add a `Makefile` or `tasks.py` for: install, lint, test, run.

**Outcome:** `pip install -e .` works, tests run, lint passes.

---

## Phase 2: Data ingestion

**Goal:** Load and validate structured datasets in a consistent way.

- [x] **2.1** Define a **dataset schema** (column types, target name, optional ID/time columns).
- [x] **2.2** Implement **loaders** for CSV/Parquet (and optionally DB/S3) with basic validation.
- [x] **2.3** Add **train/validation/test** (or time-based) split logic with a stable seed.
- [x] **2.4** Optional: simple **feature validation** (missing rates, dtypes, cardinality) and logging.

**Outcome:** One entry point (e.g. `load_dataset(path, config)`) that returns validated splits.

---

## Phase 3: Model training & selection

**Goal:** Train multiple models and pick the best one in a reproducible way.

- [x] **3.1** Define a **model interface** (e.g. fit, predict_proba, get_params) so all models are pluggable.
- [x] **3.2** Implement 2–3 **baseline models** (e.g. LogisticRegression, RandomForest, GradientBoosting).
- [x] **3.3** Add a **trainer/orchestrator** that:
  - Trains each model on the same splits
  - Saves artifacts (model, metadata, version) under a consistent path/namespace
- [x] **3.4** Add **hyperparameter config** (e.g. YAML/JSON or `pyproject` extra) without full AutoML yet.
- [x] **3.5** Optional: simple **cross-validation** wrapper for robust selection.

**Outcome:** Single function/CLI that trains all models and writes artifacts to disk.

---

## Phase 4: Evaluation (AUC, KS, lift, stability)

**Goal:** Compute the metrics that drive model selection and reporting.

- [x] **4.1** Implement **metrics**:
  - AUC-ROC (and optionally AUC-PR)
  - Kolmogorov–Smirnov (KS)
  - Lift at chosen quantiles (e.g. top 10%, 20%)
  - **Stability:** e.g. PSI (Population Stability Index) or score distribution shift between train vs holdout/time.
- [x] **4.2** Add an **evaluator** that runs all metrics on validation/test and returns a structured report (dict or small dataclass).
- [x] **4.3** Implement **model selection logic** (e.g. primary metric = AUC, tie-break by KS or stability).
- [x] **4.4** Persist **evaluation reports** (JSON/Parquet) next to model artifacts for audit.

**Outcome:** Clear “best model” chosen by AUC + robustness, with full metrics logged.

---

## Phase 5: Scoring API

**Goal:** Expose the selected model via a simple, production-ready API.

- [x] **5.1** Choose API framework (e.g. **FastAPI**) and add a minimal app skeleton.
- [x] **5.2** Endpoints:
  - **Health:** e.g. `GET /health` (and optional `GET /ready` if loading model is async).
  - **Score:** e.g. `POST /score` — input: one or many records (JSON); output: scores (and optional model version).
- [x] **5.3** **Model loading:** load the chosen model at startup (or on first request) from the path produced in Phase 3.
- [x] **5.4** **Input validation:** same schema as training (reuse Phase 2 schema) and return 4xx on invalid payloads.
- [x] **5.5** Optional: **batch endpoint** or async job for large batches; **API key** or basic auth.

**Outcome:** Running server that scores requests using the selected model and validated schema.

---

## Phase 6: Exportable scoring pipeline

**Goal:** Allow exporting a runnable pipeline (e.g. for offline or another service).

- [x] **6.1** Define **pipeline artifact:** serialized model + preprocessing steps + schema + version.
- [x] **6.2** Implement **export** (e.g. to a folder or archive): model file + config + small runner script or `predict.py`.
- [x] **6.3** **Runner:** script or CLI that loads the exported pipeline and runs on CSV/Parquet (or stdin) and writes scores to file/stdout.
- [ ] **6.4** Optional: **container image** (Dockerfile) that runs the API or the batch runner.

**Outcome:** One command to export the current best model; another to run it on new data without the full app.

---

## Phase 7: Reproducibility & production hardening

**Goal:** Reproducible runs and safe production behavior.

- [x] **7.1** **Reproducibility:** fixed seeds in config, log Python + dependency versions (e.g. `pip freeze` or lockfile) in runs.
- [x] **7.2** **Logging:** structured logs (JSON) with request IDs, model version, and timing.
- [ ] **7.3** **Observability:** optional metrics (e.g. Prometheus) for request count, latency, errors.
- [x] **7.4** **Testing:** unit tests for loaders, metrics, selection logic; integration test for API and export/run.
- [ ] **7.5** **CI:** GitHub Actions (or similar) for lint, test, and optionally build Docker image.

**Outcome:** Every training run and deploy is traceable and repeatable; API is observable and tested.

---

## Suggested order of work

| Order | Phase              | Dependency        |
|-------|--------------------|-------------------|
| 1     | Foundation         | —                 |
| 2     | Data ingestion     | Foundation        |
| 3     | Model training     | Data ingestion    |
| 4     | Evaluation         | Model training    |
| 5     | Scoring API        | Evaluation        |
| 6     | Export pipeline    | Evaluation + API  |
| 7     | Reproducibility    | All above         |

You can parallelize within a phase (e.g. multiple models in Phase 3, or API + export in 5–6) but the phase order keeps dependencies clear.

---

## Quick wins to start

1. **Week 1:** Phase 1 (pyproject, package layout, config, lint, test).
2. **Week 2:** Phase 2 (CSV loader + schema + split) and Phase 3.1–3.3 (one model, trainer, save artifacts).
3. **Week 3:** Phase 4 (metrics + selection) and Phase 5.1–5.3 (FastAPI + load model + `/score`).

After that, expand models, add export (Phase 6), then harden with Phase 7.
