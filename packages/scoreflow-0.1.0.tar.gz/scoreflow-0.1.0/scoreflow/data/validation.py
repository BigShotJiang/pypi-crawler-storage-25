"""Feature validation — advisory checks on data quality."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

import pandas as pd

from scoreflow.data.schema import DatasetSchema

logger = logging.getLogger(__name__)

# ── Defaults ────────────────────────────────────────────────────────────
_MAX_MISSING_RATE = 0.50  # warn if more than 50 % missing
_MAX_CARDINALITY = 100  # warn if a categorical has > 100 unique values


@dataclass
class ValidationReport:
    """Result of ``validate_features``."""

    warnings: list[str] = field(default_factory=list)

    @property
    def is_valid(self) -> bool:
        """A dataset is considered valid when there are no warnings."""
        return len(self.warnings) == 0

    def log(self) -> None:
        """Emit each warning via the module logger."""
        for w in self.warnings:
            logger.warning(w)


def validate_features(
    df: pd.DataFrame,
    schema: DatasetSchema,
    *,
    max_missing_rate: float = _MAX_MISSING_RATE,
    max_cardinality: int = _MAX_CARDINALITY,
) -> ValidationReport:
    """Run advisory quality checks against *df* using *schema*.

    Checks performed
    ----------------
    1. **Missing rate** — per-column fraction of NaN / None.
    2. **Dtype match** — numeric columns should have numeric dtype and vice-versa.
    3. **Cardinality** — categorical columns with very many unique values.

    Returns a :class:`ValidationReport`.  Warnings are logged but no
    exceptions are raised.
    """
    report = ValidationReport()
    features = schema.features or list(df.columns)

    for col in features:
        if col not in df.columns:
            report.warnings.append(f"Column '{col}' listed in schema but missing from DataFrame")
            continue

        # 1. Missing rate
        missing = df[col].isna().mean()
        if missing > max_missing_rate:
            report.warnings.append(
                f"Column '{col}' has {missing:.1%} missing values "
                f"(threshold: {max_missing_rate:.0%})"
            )

        # 2. Dtype check
        is_num = pd.api.types.is_numeric_dtype(df[col])
        if col in schema.numeric and not is_num:
            report.warnings.append(
                f"Column '{col}' expected numeric but has dtype '{df[col].dtype}'"
            )
        if col in schema.categorical and is_num:
            report.warnings.append(
                f"Column '{col}' expected categorical but has numeric dtype '{df[col].dtype}'"
            )

        # 3. Cardinality
        if col in schema.categorical:
            nunique = df[col].nunique()
            if nunique > max_cardinality:
                report.warnings.append(
                    f"Column '{col}' has high cardinality ({nunique} unique values, "
                    f"threshold: {max_cardinality})"
                )

    report.log()
    return report
