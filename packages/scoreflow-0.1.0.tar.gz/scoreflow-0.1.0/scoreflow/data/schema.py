"""Dataset schema definition for ScoreFlow."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

import pandas as pd

logger = logging.getLogger(__name__)


@dataclass
class DatasetSchema:
    """Describes the expected shape of a dataset.

    Parameters
    ----------
    target : str
        Name of the target (label) column.
    features : list[str] | None
        Feature column names.  ``None`` = auto-infer from the DataFrame
        (all columns except target, id, and time columns).
    id_column : str | None
        Optional row-identifier column (excluded from features).
    time_column : str | None
        Optional timestamp column used for time-based splits.
    categorical : list[str]
        Columns to treat as categorical.
    numeric : list[str]
        Columns to treat as numeric.
    """

    target: str
    features: list[str] | None = None
    id_column: str | None = None
    time_column: str | None = None
    categorical: list[str] = field(default_factory=list)
    numeric: list[str] = field(default_factory=list)

    # ── helpers ──────────────────────────────────────────────────────────

    def _excluded_columns(self) -> set[str]:
        """Columns that should never appear in the feature list."""
        excluded = {self.target}
        if self.id_column:
            excluded.add(self.id_column)
        if self.time_column:
            excluded.add(self.time_column)
        return excluded

    def resolve(self, df: pd.DataFrame) -> DatasetSchema:
        """Fill in ``features``, ``categorical``, and ``numeric`` from *df*.

        Returns *self* (mutated) so callers can chain:
        ``schema.resolve(df)``.
        """
        excluded = self._excluded_columns()

        # -- features --
        if self.features is None:
            self.features = [c for c in df.columns if c not in excluded]
            logger.info("Auto-detected %d feature columns", len(self.features))

        # -- categorical / numeric --
        if not self.categorical and not self.numeric:
            for col in self.features:
                if col not in df.columns:
                    continue
                if pd.api.types.is_numeric_dtype(df[col]):
                    self.numeric.append(col)
                else:
                    self.categorical.append(col)
            logger.info(
                "Inferred %d numeric, %d categorical columns",
                len(self.numeric),
                len(self.categorical),
            )

        return self
