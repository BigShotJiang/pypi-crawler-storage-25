"""Train / validation / test splitting strategies."""

from __future__ import annotations

import logging
from typing import NamedTuple

import pandas as pd
from sklearn.model_selection import train_test_split

logger = logging.getLogger(__name__)


class DataSplits(NamedTuple):
    """Container for the three canonical data splits."""

    train: pd.DataFrame
    val: pd.DataFrame
    test: pd.DataFrame


def random_split(
    df: pd.DataFrame,
    target: str,
    *,
    test_size: float = 0.2,
    val_size: float = 0.1,
    random_state: int = 42,
) -> DataSplits:
    """Stratified random split into train / val / test.

    Parameters
    ----------
    df : DataFrame
        Full dataset.
    target : str
        Name of the target column (used for stratification).
    test_size : float
        Fraction of data reserved for the test set.
    val_size : float
        Fraction of data reserved for the validation set (taken from the
        remaining data after the test split).
    random_state : int
        Seed for reproducibility.
    """
    train_val, test = train_test_split(
        df,
        test_size=test_size,
        random_state=random_state,
        stratify=df[target],
    )

    # val_size is relative to the original dataset; rescale to the train_val subset
    relative_val = val_size / (1 - test_size)

    train, val = train_test_split(
        train_val,
        test_size=relative_val,
        random_state=random_state,
        stratify=train_val[target],
    )

    logger.info(
        "Random split → train=%d, val=%d, test=%d",
        len(train),
        len(val),
        len(test),
    )
    return DataSplits(
        train=train.reset_index(drop=True),
        val=val.reset_index(drop=True),
        test=test.reset_index(drop=True),
    )


def time_split(
    df: pd.DataFrame,
    time_column: str,
    *,
    test_size: float = 0.2,
    val_size: float = 0.1,
) -> DataSplits:
    """Chronological split into train / val / test.

    Rows are sorted by *time_column* and split at quantile boundaries, so
    the test set always contains the most recent observations.
    """
    df_sorted = df.sort_values(time_column).reset_index(drop=True)
    n = len(df_sorted)

    train_end = int(n * (1 - test_size - val_size))
    val_end = int(n * (1 - test_size))

    train = df_sorted.iloc[:train_end]
    val = df_sorted.iloc[train_end:val_end]
    test = df_sorted.iloc[val_end:]

    logger.info(
        "Time split → train=%d, val=%d, test=%d",
        len(train),
        len(val),
        len(test),
    )
    return DataSplits(
        train=train.reset_index(drop=True),
        val=val.reset_index(drop=True),
        test=test.reset_index(drop=True),
    )
