"""Data ingestion and validation — unified entry point."""

from __future__ import annotations

import logging
from pathlib import Path

from scoreflow.data.loaders import load_file
from scoreflow.data.schema import DatasetSchema
from scoreflow.data.splitters import DataSplits, random_split, time_split
from scoreflow.data.validation import ValidationReport, validate_features

logger = logging.getLogger(__name__)

__all__ = [
    "DataSplits",
    "DatasetSchema",
    "ValidationReport",
    "load_dataset",
    "load_file",
    "validate_features",
]


def load_dataset(
    path: str | Path,
    schema: DatasetSchema,
    *,
    split_method: str = "random",
    test_size: float = 0.2,
    val_size: float = 0.1,
    random_state: int = 42,
) -> DataSplits:
    """Load, validate, and split a dataset in one call.

    Parameters
    ----------
    path : str | Path
        Path to a CSV or Parquet file.
    schema : DatasetSchema
        Expected dataset schema (target, features, etc.).
    split_method : ``"random"`` | ``"time"``
        Splitting strategy.  ``"time"`` requires ``schema.time_column``.
    test_size : float
        Fraction reserved for the test set.
    val_size : float
        Fraction reserved for the validation set.
    random_state : int
        Seed for the random split (ignored for time splits).

    Returns
    -------
    DataSplits
        Named tuple with ``train``, ``val``, ``test`` DataFrames.
    """
    # 1. Load
    df = load_file(path)

    # 2. Resolve schema from actual data
    schema.resolve(df)

    # 3. Validate (advisory)
    validate_features(df, schema)

    # 4. Split
    if split_method == "time":
        if schema.time_column is None:
            raise ValueError("Time-based split requires schema.time_column to be set")
        return time_split(df, schema.time_column, test_size=test_size, val_size=val_size)

    return random_split(
        df,
        schema.target,
        test_size=test_size,
        val_size=val_size,
        random_state=random_state,
    )
