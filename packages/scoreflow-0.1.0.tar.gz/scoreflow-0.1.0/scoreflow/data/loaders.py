"""File loaders for CSV and Parquet datasets."""

from __future__ import annotations

import logging
from pathlib import Path

import pandas as pd

logger = logging.getLogger(__name__)

_SUPPORTED_EXTENSIONS = {".csv", ".parquet", ".pq"}


def load_file(path: str | Path) -> pd.DataFrame:
    """Load a structured dataset from *path* (CSV or Parquet).

    Raises
    ------
    FileNotFoundError
        If *path* does not exist.
    ValueError
        If the file extension is unsupported or the file is empty.
    """
    path = Path(path)

    if not path.exists():
        raise FileNotFoundError(f"Dataset file not found: {path}")

    ext = path.suffix.lower()
    if ext not in _SUPPORTED_EXTENSIONS:
        raise ValueError(
            f"Unsupported file extension '{ext}'. Supported: {sorted(_SUPPORTED_EXTENSIONS)}"
        )

    df = _load_csv(path) if ext == ".csv" else _load_parquet(path)

    if df.empty:
        raise ValueError(f"Dataset file is empty: {path}")

    logger.info("Loaded %d rows × %d columns from %s", len(df), len(df.columns), path.name)
    return df


def _load_csv(path: Path) -> pd.DataFrame:
    """Read a CSV file into a DataFrame."""
    return pd.read_csv(path)


def _load_parquet(path: Path) -> pd.DataFrame:
    """Read a Parquet file into a DataFrame."""
    return pd.read_parquet(path)
