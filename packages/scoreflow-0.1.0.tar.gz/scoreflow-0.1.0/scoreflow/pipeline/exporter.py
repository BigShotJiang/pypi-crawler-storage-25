"""Pipeline exporter — serialize a trained model artifact for offline scoring."""

from __future__ import annotations

import json
import logging
from pathlib import Path

import joblib

from scoreflow.data.schema import DatasetSchema
from scoreflow.models.base import ModelArtifact

logger = logging.getLogger(__name__)

_SCHEMA_FILE = "schema.json"
_MODEL_FILE = "model.joblib"
_META_FILE = "metadata.json"


def export_pipeline(
    artifact: ModelArtifact,
    schema: DatasetSchema,
    output_dir: str | Path,
) -> Path:
    """Export a trained model artifact + schema so it can run standalone.

    The exported directory contains:
    - ``model.joblib`` — the serialised model
    - ``metadata.json`` — training metadata (name, params, timestamp, …)
    - ``schema.json``   — DatasetSchema (target, features, categorical, numeric)

    Parameters
    ----------
    artifact:
        A trained ``ModelArtifact``.
    schema:
        The ``DatasetSchema`` describing feature columns used during training.
    output_dir:
        Directory where the exported pipeline will be written.
        A sub-directory named after the model will be created inside.

    Returns
    -------
    Path
        The path to the created pipeline directory.
    """
    out = Path(output_dir) / artifact.name
    out.mkdir(parents=True, exist_ok=True)

    # 1. Model
    joblib.dump(artifact.model, out / _MODEL_FILE)

    # 2. Metadata
    meta = {
        "name": artifact.name,
        "params": artifact.params,
        "train_time_ns": artifact.train_time_ns,
        "n_rows_trained": artifact.n_rows_trained,
        "timestamp": artifact.timestamp,
        "cv_score": artifact.cv_score,
        "model_file": _MODEL_FILE,
    }
    with open(out / _META_FILE, "w") as f:
        json.dump(meta, f, indent=2)

    # 3. Schema
    schema_data = {
        "target": schema.target,
        "features": schema.features,
        "id_column": schema.id_column,
        "time_column": schema.time_column,
        "categorical": schema.categorical,
        "numeric": schema.numeric,
    }
    with open(out / _SCHEMA_FILE, "w") as f:
        json.dump(schema_data, f, indent=2)

    logger.info("Exported pipeline '%s' to %s", artifact.name, out)
    return out
