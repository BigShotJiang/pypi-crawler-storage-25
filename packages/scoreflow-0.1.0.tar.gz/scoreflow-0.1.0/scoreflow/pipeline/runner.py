"""Pipeline runner — score new data using an exported pipeline directory."""

from __future__ import annotations

import json
import logging
from pathlib import Path

import joblib
import pandas as pd

from scoreflow.data.loaders import load_file
from scoreflow.data.schema import DatasetSchema

logger = logging.getLogger(__name__)

_SCHEMA_FILE = "schema.json"
_MODEL_FILE = "model.joblib"


def run_pipeline(
    pipeline_dir: str | Path,
    input_path: str | Path,
    output_path: str | Path,
) -> pd.DataFrame:
    """Load an exported pipeline and score records from *input_path*.

    Parameters
    ----------
    pipeline_dir:
        Directory produced by :func:`export_pipeline`.
    input_path:
        CSV or Parquet file containing records to score.
        Only the feature columns declared in the pipeline schema are used.
    output_path:
        Destination for the scored output (CSV).  The file will contain all
        original columns plus a ``score`` column.

    Returns
    -------
    pd.DataFrame
        The scored DataFrame (also written to *output_path*).
    """
    pipeline_dir = Path(pipeline_dir)

    # 1. Load schema
    with open(pipeline_dir / _SCHEMA_FILE) as f:
        schema_data = json.load(f)

    schema = DatasetSchema(
        target=schema_data["target"],
        features=schema_data.get("features"),
        id_column=schema_data.get("id_column"),
        time_column=schema_data.get("time_column"),
        categorical=schema_data.get("categorical", []),
        numeric=schema_data.get("numeric", []),
    )

    # 2. Load model
    model = joblib.load(pipeline_dir / _MODEL_FILE)

    # 3. Load input data
    df = load_file(input_path)

    # 4. Select features
    features = schema.features or []
    missing = [c for c in features if c not in df.columns]
    if missing:
        raise ValueError(
            f"Input data is missing required feature columns: {missing}"
        )

    X = df[features]

    # 5. Score
    probs = model.predict_proba(X)
    df = df.copy()
    df["score"] = probs

    # 6. Write output
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(output_path, index=False)
    logger.info(
        "Scored %d rows → %s", len(df), output_path
    )

    return df
