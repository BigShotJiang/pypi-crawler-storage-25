"""ScoreFlow CLI entry point.

Usage
-----
    python -m scoreflow serve   --model-dir <dir>
    python -m scoreflow run     --pipeline <dir> --input <file> --output <file>
"""

from __future__ import annotations

import argparse
import sys


def _cmd_serve(args: argparse.Namespace) -> None:
    """Start the FastAPI scoring server."""
    import os

    import uvicorn

    os.environ["SCOREFLOW_MODEL_DIR"] = args.model_dir
    if args.model_name:
        os.environ["SCOREFLOW_MODEL_NAME"] = args.model_name

    uvicorn.run(
        "scoreflow.api.app:app",
        host=args.host,
        port=args.port,
        log_level="info",
    )


def _cmd_run(args: argparse.Namespace) -> None:
    """Run the exported scoring pipeline on a file."""
    from scoreflow.pipeline.runner import run_pipeline

    df = run_pipeline(args.pipeline, args.input, args.output)
    print(f"Scored {len(df)} rows → {args.output}")


def main(argv: list[str] | None = None) -> None:
    """Parse CLI args and dispatch to the appropriate sub-command."""
    parser = argparse.ArgumentParser(
        prog="scoreflow",
        description="ScoreFlow ML scoring engine",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # ── serve ─────────────────────────────────────────────────────────────
    serve_p = sub.add_parser("serve", help="Start the scoring API server")
    serve_p.add_argument(
        "--model-dir",
        default="models",
        help="Directory containing model artifact sub-directories (default: models/)",
    )
    serve_p.add_argument("--model-name", default="", help="Specific model sub-dir to load")
    serve_p.add_argument("--host", default="0.0.0.0", help="Bind host (default: 0.0.0.0)")
    serve_p.add_argument("--port", type=int, default=8000, help="Bind port (default: 8000)")

    # ── run ───────────────────────────────────────────────────────────────
    run_p = sub.add_parser("run", help="Score a file using an exported pipeline")
    run_p.add_argument("--pipeline", required=True, help="Exported pipeline directory")
    run_p.add_argument("--input", required=True, help="Input CSV or Parquet file")
    run_p.add_argument("--output", required=True, help="Output CSV path for scores")

    args = parser.parse_args(argv)
    if args.command == "serve":
        _cmd_serve(args)
    elif args.command == "run":
        _cmd_run(args)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
