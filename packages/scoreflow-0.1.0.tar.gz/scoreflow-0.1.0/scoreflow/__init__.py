"""ScoreFlow — Production-ready automated ML scoring engine."""

__version__ = "0.1.0"
