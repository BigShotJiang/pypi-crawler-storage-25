"""Evaluation metrics for model scoring and stability."""

import numpy as np
import pandas as pd
from scipy.stats import ks_2samp
from sklearn.metrics import roc_auc_score


def calculate_auc(y_true: np.ndarray | pd.Series, y_prob: np.ndarray | pd.Series) -> float:
    """Calculate the Area Under the Receiver Operating Characteristic Curve (ROC AUC).

    Parameters
    ----------
    y_true : np.ndarray | pd.Series
        True binary labels.
    y_prob : np.ndarray | pd.Series
        Target scores, can either be probability estimates of the positive class.

    Returns
    -------
    float
        The AUC score.
    """
    return float(roc_auc_score(y_true, y_prob))


def calculate_ks(y_true: np.ndarray | pd.Series, y_prob: np.ndarray | pd.Series) -> float:
    """Calculate the Kolmogorov-Smirnov (KS) statistic.

    The KS statistic is the maximum difference between the cumulative distribution
    functions of the positive and negative classes.

    Parameters
    ----------
    y_true : np.ndarray | pd.Series
        True binary labels (0 or 1).
    y_prob : np.ndarray | pd.Series
        Predicted probabilities for the positive class.

    Returns
    -------
    float
        The KS statistic.
    """
    y_true_arr = np.asarray(y_true)
    y_prob_arr = np.asarray(y_prob)

    pos_probs = y_prob_arr[y_true_arr == 1]
    neg_probs = y_prob_arr[y_true_arr == 0]

    if len(pos_probs) == 0 or len(neg_probs) == 0:
        return 0.0

    stat, _ = ks_2samp(pos_probs, neg_probs)
    return float(stat)


def calculate_lift(
    y_true: np.ndarray | pd.Series, y_prob: np.ndarray | pd.Series, quantile: float = 0.1
) -> float:
    """Calculate Lift at a given quantile.

    Lift is the ratio of the positive class rate in the top `quantile` of predicted
    probabilities to the overall positive class rate.

    Parameters
    ----------
    y_true : np.ndarray | pd.Series
        True binary labels.
    y_prob : np.ndarray | pd.Series
        Predicted probabilities for the positive class.
    quantile : float, default=0.1
        The top fraction of predictions to consider (e.g., 0.1 for top 10%).

    Returns
    -------
    float
        The Lift at the specified quantile.
    """
    y_true_arr = np.asarray(y_true)
    y_prob_arr = np.asarray(y_prob)
    
    if len(y_true_arr) == 0:
        return 0.0

    overall_rate = np.mean(y_true_arr)
    if overall_rate == 0:
        return 0.0

    n_samples = len(y_true_arr)
    n_top = max(1, int(n_samples * quantile))

    # Sort indices descending by probability
    top_indices = np.argsort(y_prob_arr)[::-1][:n_top]
    top_responses = y_true_arr[top_indices]

    top_rate = np.mean(top_responses)
    return float(top_rate / overall_rate)


def calculate_psi(
    expected: np.ndarray | pd.Series, actual: np.ndarray | pd.Series, buckets: int = 10
) -> float:
    """Calculate the Population Stability Index (PSI).

    PSI measures the shift in the distribution of two samples (e.g., train vs test scores).

    Parameters
    ----------
    expected : np.ndarray | pd.Series
        Reference (e.g., training) distribution scores.
    actual : np.ndarray | pd.Series
        Current (e.g., test/production) distribution scores.
    buckets : int, default=10
        Number of quantiles to split the expected distribution into.

    Returns
    -------
    float
        The PSI value.
    """
    expected_arr = np.asarray(expected)
    actual_arr = np.asarray(actual)
    
    if len(expected_arr) == 0 or len(actual_arr) == 0:
        return 0.0

    # Define the bucket boundaries based on the expected distribution quantiles
    quantiles = np.linspace(0, 1, buckets + 1)
    bins = np.quantile(expected_arr, quantiles)
    
    # Ensure slightly wider bounds to include min/max
    bins[0] = -np.inf
    bins[-1] = np.inf
    
    # Ensure bins are unique (can happen with many identical values)
    bins = np.unique(bins)
    
    # Count samples in each bin
    expected_counts, _ = np.histogram(expected_arr, bins=bins)
    actual_counts, _ = np.histogram(actual_arr, bins=bins)
    
    # Convert counts to percentages, avoiding zero
    expected_pct = expected_counts / len(expected_arr)
    actual_pct = actual_counts / len(actual_arr)
    
    expected_pct = np.clip(expected_pct, a_min=1e-6, a_max=None)
    actual_pct = np.clip(actual_pct, a_min=1e-6, a_max=None)
    
    psi = np.sum((actual_pct - expected_pct) * np.log(actual_pct / expected_pct))
    return float(psi)
