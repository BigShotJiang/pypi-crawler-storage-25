"""Model evaluator to compute standard ML metrics."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

import pandas as pd

from scoreflow.data.schema import DatasetSchema
from scoreflow.data.splitters import DataSplits
from scoreflow.evaluation.metrics import (
    calculate_auc,
    calculate_ks,
    calculate_lift,
    calculate_psi,
)
from scoreflow.models.base import ModelArtifact

logger = logging.getLogger(__name__)


@dataclass
class EvaluationReport:
    """A container for evaluation metrics across different splits."""

    model_name: str
    metrics: dict[str, dict[str, float]] = field(default_factory=dict)
    
    def to_dict(self) -> dict[str, Any]:
        """Convert the report to a plain dictionary."""
        return {
            "model_name": self.model_name,
            "metrics": self.metrics,
        }


class Evaluator:
    """Computes relevant metrics for a trained model across data splits."""

    def __init__(self, schema: DatasetSchema) -> None:
        """Initialize the evaluator.

        Parameters
        ----------
        schema : DatasetSchema
            The schema identifying features and target columns.
        """
        self.schema = schema

    def _get_X_y(self, df: pd.DataFrame) -> tuple[pd.DataFrame, pd.Series]:
        """Extract features and target from a DataFrame."""
        if not self.schema.features:
            raise ValueError("Schema features not resolved. Call schema.resolve(df) first.")
        
        X = df[self.schema.features]
        y = df[self.schema.target]
        return X, y

    def evaluate(self, model_artifact: ModelArtifact, splits: DataSplits) -> EvaluationReport:
        """Evaluate a model artifact on validation and test splits.

        Also scores the training split to use as a baseline for PSI.

        Parameters
        ----------
        model_artifact : ModelArtifact
            The trained model to evaluate.
        splits : DataSplits
            The data splits (train, val, test).

        Returns
        -------
        EvaluationReport
            The evaluation results.
        """
        logger.info("Evaluating model: %s", model_artifact.name)
        model = model_artifact.model
        
        # 1. Score the training set (needed for PSI expected distribution)
        X_train, y_train = self._get_X_y(splits.train)
        train_probs = model.predict_proba(X_train)
        
        report = EvaluationReport(model_name=model_artifact.name)
        
        # 2. Evaluate on target splits
        for split_name, df in [("train", splits.train), ("val", splits.val), ("test", splits.test)]:
            if df is None or len(df) == 0:
                continue

            X, y = self._get_X_y(df)
            probs = model.predict_proba(X)
            
            auc = calculate_auc(y, probs)
            ks = calculate_ks(y, probs)
            lift_10 = calculate_lift(y, probs, quantile=0.1)
            lift_20 = calculate_lift(y, probs, quantile=0.2)
            
            psi = 0.0
            if split_name != "train":
                psi = calculate_psi(train_probs, probs)
                
            report.metrics[split_name] = {
                "auc": auc,
                "ks": ks,
                "lift_10": lift_10,
                "lift_20": lift_20,
                "psi": psi,
            }
            
            logger.info(
                "  [%s] AUC: %.3f, KS: %.3f, Lift@10%%: %.3f, PSI: %.3f",
                split_name, auc, ks, lift_10, psi
            )
            
        return report
