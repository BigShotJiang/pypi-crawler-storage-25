"""Model selection and evaluation reporting logic."""

from __future__ import annotations

import json
import logging
from pathlib import Path

from scoreflow.evaluation.evaluator import EvaluationReport

logger = logging.getLogger(__name__)


def select_best_model(
    reports: list[EvaluationReport],
    split: str = "val",
    primary_metric: str = "auc",
    tie_breaker: str = "ks",
) -> EvaluationReport:
    """Select the best model based on evaluation reports.

    Parameters
    ----------
    reports : list[EvaluationReport]
        The evaluation reports of the trained models.
    split : str, default="val"
        Which data split to use for selection.
    primary_metric : str, default="auc"
        The primary metric to maximize.
    tie_breaker : str, default="ks"
        The secondary metric to maximize in case of a tie (or close).

    Returns
    -------
    EvaluationReport
        The report corresponding to the best model.
    """
    if not reports:
        raise ValueError("No reports provided for model selection.")

    def sort_key(report: EvaluationReport) -> tuple[float, float]:
        metrics = report.metrics.get(split, {})
        primary_val = metrics.get(primary_metric, 0.0)
        tie_val = metrics.get(tie_breaker, 0.0)
        return (primary_val, tie_val)

    sorted_reports = sorted(reports, key=sort_key, reverse=True)
    best = sorted_reports[0]
    
    logger.info(
        "Selected best model: %s (split=%s, %s=%.3f, %s=%.3f)",
        best.model_name,
        split,
        primary_metric,
        best.metrics.get(split, {}).get(primary_metric, 0.0),
        tie_breaker,
        best.metrics.get(split, {}).get(tie_breaker, 0.0),
    )
    
    return best


def persist_evaluation_report(report: EvaluationReport, output_dir: str | Path) -> Path:
    """Save the evaluation report as JSON to the output directory.

    Usually, this output_dir is the model's artifact directory.

    Parameters
    ----------
    report : EvaluationReport
        The evaluation report to save.
    output_dir : str | Path
        The directory where to save the report.

    Returns
    -------
    Path
        The path to the saved JSON file.
    """
    out_path = Path(output_dir) / report.model_name / "evaluation.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    
    with open(out_path, "w") as f:
        json.dump(report.to_dict(), f, indent=2)
        
    logger.info("Saved evaluation report to %s", out_path)
    return out_path
