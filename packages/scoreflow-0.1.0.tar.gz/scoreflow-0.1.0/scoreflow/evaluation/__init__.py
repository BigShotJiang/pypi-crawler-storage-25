"""Evaluation metrics — AUC, KS, lift, stability (Phase 4)."""

from .evaluator import EvaluationReport, Evaluator
from .metrics import calculate_auc, calculate_ks, calculate_lift, calculate_psi
from .selection import persist_evaluation_report, select_best_model

__all__ = [
    "calculate_auc",
    "calculate_ks",
    "calculate_lift",
    "calculate_psi",
    "Evaluator",
    "EvaluationReport",
    "select_best_model",
    "persist_evaluation_report",
]
