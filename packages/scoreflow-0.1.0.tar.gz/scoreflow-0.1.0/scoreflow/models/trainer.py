"""Model training orchestrator."""

from __future__ import annotations

import logging
import time
from pathlib import Path

import pandas as pd
from sklearn.model_selection import StratifiedKFold, cross_val_score

from scoreflow.data.schema import DatasetSchema
from scoreflow.data.splitters import DataSplits
from scoreflow.models.base import ModelArtifact
from scoreflow.models.registry import get_model

logger = logging.getLogger(__name__)


class Trainer:
    """Orchestrates model training and cross-validation across multiple models."""

    def __init__(
        self,
        schema: DatasetSchema,
        model_names: list[str] | None = None,
        hyperparams: dict[str, dict[str, float | str | int]] | None = None,
        random_state: int = 42,
        cv_folds: int = 5,
    ) -> None:
        """Initialize the Trainer.

        Parameters
        ----------
        schema : DatasetSchema
            The dataset schema specifying target and feature columns.
        model_names : list[str] | None
            Names of models to train. If None, trains all registered models.
        hyperparams : dict[str, dict[str, Any]] | None
            Optional dictionary mapping model names to hyperparameter kwargs.
        random_state : int
            Random seed for cross-validation splits.
        cv_folds : int
            Number of folds for cross-validation.
        """
        self.schema = schema
        self.hyperparams = hyperparams or {}
        self.random_state = random_state
        self.cv_folds = cv_folds

        if model_names is None:
            from scoreflow.models.registry import list_models
            self.model_names = list_models()
        else:
            self.model_names = model_names

    def _get_X_y(self, df: pd.DataFrame) -> tuple[pd.DataFrame, pd.Series]:
        """Extract feature matrix and target series based on schema."""
        if not self.schema.features:
            raise ValueError("Schema features not resolved. Call schema.resolve(df) first.")

        X = df[self.schema.features]
        y = df[self.schema.target]
        return X, y

    def train(self, splits: DataSplits) -> list[ModelArtifact]:
        """Fit all configured models on the training split.

        Parameters
        ----------
        splits : DataSplits
            The data splits (must contain 'train').

        Returns
        -------
        list[ModelArtifact]
            A list of trained model artifacts.
        """
        X_train, y_train = self._get_X_y(splits.train)
        n_rows = len(splits.train)
        artifacts = []

        logger.info("Training %d models on %d rows...", len(self.model_names), n_rows)

        for name in self.model_names:
            kwargs = self.hyperparams.get(name, {})
            model = get_model(name, **kwargs)

            logger.info("  Fitting %s...", name)
            t0 = time.perf_counter_ns()
            model.fit(X_train, y_train)
            t1 = time.perf_counter_ns()

            artifact = ModelArtifact(
                model=model,
                name=name,
                params=model.get_params(),
                train_time_ns=t1 - t0,
                n_rows_trained=n_rows,
            )
            artifacts.append(artifact)

        return artifacts

    def cross_validate(self, splits: DataSplits, metric: str = "roc_auc") -> pd.DataFrame:
        """Run k-fold cross-validation on the training split for all models.

        Uses StratifiedKFold. Note that for models that don't output pure classes
        (like predict_proba), roc_auc might require special handling if passing wrapped models
        back to sklearn cross_val_score. Our BaseModel wrappers expose fit and predict_proba,
        but sklearn expects duck-typed estimators. To use cross_val_score directly,
        we expose `.model` inside BaseModel.

        Parameters
        ----------
        splits : DataSplits
            The data splits.
        metric : str
            Scoring metric compatible with sklearn (e.g. "roc_auc").

        Returns
        -------
        pd.DataFrame
            A summary DataFrame containing mean CV score and std for each model.
        """
        X_train, y_train = self._get_X_y(splits.train)

        cv = StratifiedKFold(
            n_splits=self.cv_folds,
            shuffle=True,
            random_state=self.random_state,
        )

        results = []
        logger.info("Running %d-fold CV using %s...", self.cv_folds, metric)

        for name in self.model_names:
            kwargs = self.hyperparams.get(name, {})
            # We get our wrapper
            wrapper = get_model(name, **kwargs)

            # NOTE: cross_val_score needs a standard scikit-learn estimator.
            # Our `wrapper.model` is an sklearn/lgbm estimator.
            logger.info("  CV for %s...", name)
            scores = cross_val_score(
                wrapper.model,  # type: ignore[attr-defined]
                X_train,
                y_train,
                cv=cv,
                scoring=metric,
                n_jobs=-1,
            )

            results.append({
                "model": name,
                f"mean_{metric}": scores.mean(),
                f"std_{metric}": scores.std(),
            })

        df_res = pd.DataFrame(results).sort_values(f"mean_{metric}", ascending=False)
        return df_res.reset_index(drop=True)

    def save_artifacts(self, artifacts: list[ModelArtifact], output_dir: str | Path) -> list[Path]:
        """Save a list of artifacts to disk.

        Parameters
        ----------
        artifacts : list[ModelArtifact]
            The trained model artifacts.
        output_dir : str | Path
            The directory to save them in. Subdirectories will be created.

        Returns
        -------
        list[Path]
            Paths to the saved artifact directories.
        """
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        paths = []
        for a in artifacts:
            p = a.save(output_dir)
            paths.append(p)
            logger.info("Saved %s to %s", a.name, p)
        return paths
