"""Base model interface and artifact definition."""

from __future__ import annotations

import json
from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import joblib
import numpy as np
import pandas as pd


class BaseModel(ABC):
    """Abstract interface for all ScoreFlow predictive models."""

    @abstractmethod
    def fit(self, X: pd.DataFrame, y: pd.Series) -> BaseModel:
        """Fit the model to the training data.

        Returns
        -------
        self
            The fitted model instance.
        """
        ...

    @abstractmethod
    def predict_proba(self, X: pd.DataFrame) -> np.ndarray:
        """Predict class probabilities for X.

        Returns
        -------
        np.ndarray
            1D array of shape (n_samples,) containing the probability of the
            positive class.
        """
        ...

    @abstractmethod
    def get_params(self) -> dict[str, Any]:
        """Return the hyperparameters used by this model."""
        ...

    @property
    @abstractmethod
    def name(self) -> str:
        """Human-readable name of the model (e.g., 'logistic_regression')."""
        ...


@dataclass
class ModelArtifact:
    """A trained model and its associated metadata."""

    model: BaseModel
    name: str
    params: dict[str, Any]
    train_time_ns: int
    n_rows_trained: int
    timestamp: str = ""
    cv_score: float | None = None

    def __post_init__(self) -> None:
        if not self.timestamp:
            self.timestamp = datetime.now(UTC).isoformat(timespec="seconds").replace("+00:00", "Z")

    def save(self, output_dir: str | Path) -> Path:
        """Persist this artifact to a directory.

        Creates a subdirectory named after the model, saving the pickled
        model and a JSON metadata file.

        Returns
        -------
        Path
            The path to the created artifact directory.
        """
        dir_path = Path(output_dir) / self.name
        dir_path.mkdir(parents=True, exist_ok=True)

        # 1. Save model
        model_path = dir_path / "model.joblib"
        joblib.dump(self.model, model_path)

        # 2. Save metadata
        meta = {
            "name": self.name,
            "params": self.params,
            "train_time_ns": self.train_time_ns,
            "n_rows_trained": self.n_rows_trained,
            "timestamp": self.timestamp,
            "cv_score": self.cv_score,
            "model_file": model_path.name,
        }
        with open(dir_path / "metadata.json", "w") as f:
            json.dump(meta, f, indent=2)

        return dir_path

    @classmethod
    def load(cls, artifact_dir: str | Path) -> ModelArtifact:
        """Load an artifact from a directory."""
        dir_path = Path(artifact_dir)

        with open(dir_path / "metadata.json") as f:
            meta = json.load(f)

        model_path = dir_path / meta["model_file"]
        model = joblib.load(model_path)

        return cls(
            model=model,
            name=meta["name"],
            params=meta["params"],
            train_time_ns=meta["train_time_ns"],
            n_rows_trained=meta["n_rows_trained"],
            timestamp=meta["timestamp"],
            cv_score=meta.get("cv_score"),
        )
