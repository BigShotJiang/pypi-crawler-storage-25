"""Baseline model implementations."""

from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd
from lightgbm import LGBMClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression

from scoreflow.models.base import BaseModel


class LogisticRegressionModel(BaseModel):
    """Wrapper for sklearn's LogisticRegression."""

    def __init__(self, **kwargs: Any) -> None:
        defaults = {"max_iter": 1000, "solver": "lbfgs"}
        # Overlay user kwargs on top of defaults
        params = {**defaults, **kwargs}
        self.model = LogisticRegression(**params)

    def fit(self, X: pd.DataFrame, y: pd.Series) -> BaseModel:
        self.model.fit(X, y)
        return self

    def predict_proba(self, X: pd.DataFrame) -> np.ndarray:
        # Return probability of positive class (index 1)
        return self.model.predict_proba(X)[:, 1]

    def get_params(self) -> dict[str, Any]:
        return self.model.get_params()

    @property
    def name(self) -> str:
        return "logistic_regression"


class RandomForestModel(BaseModel):
    """Wrapper for sklearn's RandomForestClassifier."""

    def __init__(self, **kwargs: Any) -> None:
        defaults = {"n_estimators": 200, "random_state": 42}
        params = {**defaults, **kwargs}
        self.model = RandomForestClassifier(**params)

    def fit(self, X: pd.DataFrame, y: pd.Series) -> BaseModel:
        self.model.fit(X, y)
        return self

    def predict_proba(self, X: pd.DataFrame) -> np.ndarray:
        return self.model.predict_proba(X)[:, 1]

    def get_params(self) -> dict[str, Any]:
        return self.model.get_params()

    @property
    def name(self) -> str:
        return "random_forest"


class LightGBMModel(BaseModel):
    """Wrapper for LightGBM Classifier."""

    def __init__(self, **kwargs: Any) -> None:
        defaults = {"n_estimators": 200, "verbosity": -1, "random_state": 42}
        params = {**defaults, **kwargs}
        self.model = LGBMClassifier(**params)

    def fit(self, X: pd.DataFrame, y: pd.Series) -> BaseModel:
        # LGBM warns if column names contain special characters, but we trust the user.
        self.model.fit(X, y)
        return self

    def predict_proba(self, X: pd.DataFrame) -> np.ndarray:
        return self.model.predict_proba(X)[:, 1]

    def get_params(self) -> dict[str, Any]:
        return self.model.get_params()

    @property
    def name(self) -> str:
        return "lightgbm"
