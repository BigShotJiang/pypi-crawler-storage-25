"""Model registry and instantiation."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from scoreflow.models.base import BaseModel
from scoreflow.models.classifiers import LightGBMModel, LogisticRegressionModel, RandomForestModel

_REGISTRY: dict[str, Callable[..., BaseModel]] = {
    "logistic_regression": LogisticRegressionModel,
    "random_forest": RandomForestModel,
    "lightgbm": LightGBMModel,
}


def list_models() -> list[str]:
    """Return a list of available model names."""
    return list(_REGISTRY.keys())


def get_model(name: str, **kwargs: Any) -> BaseModel:
    """Instantiate a model by name with optional hyperparameter overrides.

    Parameters
    ----------
    name : str
        The name of the model to instantiate.
    **kwargs
        Hyperparameters to pass to the model constructor.

    Raises
    ------
    KeyError
        If the model name is not found in the registry.

    Returns
    -------
    BaseModel
        The instantiated model.
    """
    if name not in _REGISTRY:
        raise KeyError(f"Unknown model '{name}'. Available: {list_models()}")

    return _REGISTRY[name](**kwargs)
