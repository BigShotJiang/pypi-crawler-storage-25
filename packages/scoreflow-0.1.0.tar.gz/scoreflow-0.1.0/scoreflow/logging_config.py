"""Structured logging configuration for ScoreFlow."""

from __future__ import annotations

import json
import logging
import sys
from typing import Any


class _JsonFormatter(logging.Formatter):
    """Emit log records as single-line JSON objects."""

    def format(self, record: logging.LogRecord) -> str:  # noqa: A003
        payload: dict[str, Any] = {
            "ts": self.formatTime(record, self.datefmt),
            "level": record.levelname,
            "logger": record.name,
            "msg": record.getMessage(),
        }
        if record.exc_info:
            payload["exc"] = self.formatException(record.exc_info)
        return json.dumps(payload)


def configure_logging(
    level: str = "INFO",
    json_format: bool = False,
) -> None:
    """Configure root logger for ScoreFlow.

    Parameters
    ----------
    level:
        Logging level (``"DEBUG"``, ``"INFO"``, ``"WARNING"``, …).
    json_format:
        If ``True``, emit JSON lines instead of human-readable text.
    """
    root = logging.getLogger()
    root.setLevel(level)

    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(level)

    if json_format:
        handler.setFormatter(_JsonFormatter())
    else:
        fmt = "%(asctime)s [%(levelname)s] %(name)s — %(message)s"
        handler.setFormatter(logging.Formatter(fmt, datefmt="%Y-%m-%dT%H:%M:%S"))

    # Remove pre-existing handlers to avoid duplicate messages
    root.handlers.clear()
    root.addHandler(handler)
