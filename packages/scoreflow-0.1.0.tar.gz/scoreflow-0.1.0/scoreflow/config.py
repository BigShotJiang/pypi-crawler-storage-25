"""Central configuration for ScoreFlow."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

# ── Path constants ───────────────────────────────────────────────────────
PROJECT_ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = Path(os.getenv("SCOREFLOW_DATA_DIR", str(PROJECT_ROOT / "data")))
MODELS_DIR = Path(os.getenv("SCOREFLOW_MODELS_DIR", str(PROJECT_ROOT / "models")))
REPORTS_DIR = Path(os.getenv("SCOREFLOW_REPORTS_DIR", str(PROJECT_ROOT / "reports")))


# ── Model defaults ──────────────────────────────────────────────────────
@dataclass(frozen=True)
class ModelDefaults:
    """Sensible defaults shared across all model training runs."""

    random_state: int = 42
    test_size: float = 0.2
    cv_folds: int = 5
    primary_metric: str = "roc_auc"


# Singleton instance — import this instead of instantiating directly.
defaults: ModelDefaults = field(default_factory=ModelDefaults) if False else ModelDefaults()
