"""scoreflow.api — FastAPI scoring endpoints."""

from .app import create_app

__all__ = ["create_app"]
