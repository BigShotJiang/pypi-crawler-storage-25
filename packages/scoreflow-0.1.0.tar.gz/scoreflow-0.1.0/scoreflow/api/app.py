"""FastAPI scoring application — Phase 5."""

from __future__ import annotations

import json
import logging
import os
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any

import numpy as np
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel as PydanticModel

from scoreflow.models.base import ModelArtifact

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Pydantic request / response schemas
# ---------------------------------------------------------------------------


class ScoreRequest(PydanticModel):
    """Payload for POST /score.

    Each item in *records* is a flat dict mapping feature name → value.
    """

    records: list[dict[str, Any]]


class ScoreResponse(PydanticModel):
    """Response for POST /score."""

    scores: list[float]
    model_name: str
    model_version: str


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _load_best_artifact(model_dir: Path) -> ModelArtifact | None:
    """Scan *model_dir* for sub-directories containing a model.

    Returns the artifact whose ``metadata.json`` has the newest timestamp.
    If ``SCOREFLOW_MODEL_NAME`` env var is set, loads that specific sub-dir.
    """
    if not model_dir.exists():
        logger.warning("Model directory does not exist: %s", model_dir)
        return None

    specific_name = os.getenv("SCOREFLOW_MODEL_NAME")
    if specific_name:
        candidate = model_dir / specific_name
        if candidate.is_dir() and (candidate / "metadata.json").exists():
            return ModelArtifact.load(candidate)
        logger.warning("Requested model '%s' not found in %s", specific_name, model_dir)
        return None

    # Auto-pick newest
    candidates = [
        d for d in model_dir.iterdir() if d.is_dir() and (d / "metadata.json").exists()
    ]
    if not candidates:
        logger.warning("No model artifacts found in %s", model_dir)
        return None

    def _ts(d: Path) -> str:
        with open(d / "metadata.json") as f:
            return json.load(f).get("timestamp", "")

    best = max(candidates, key=_ts)
    logger.info("Auto-selected model artifact: %s", best.name)
    return ModelArtifact.load(best)


# ---------------------------------------------------------------------------
# Application factory
# ---------------------------------------------------------------------------


def create_app(model_dir: str | Path | None = None) -> FastAPI:
    """Create and return a FastAPI application instance.

    Each call produces an isolated app with its own in-memory model state,
    making it safe to create multiple apps in tests.

    Parameters
    ----------
    model_dir:
        Directory containing model artifact sub-directories.
        Defaults to ``SCOREFLOW_MODEL_DIR`` env var, then ``./models``.
    """
    # Per-app state — stored in a mutable dict so the lifespan closure can mutate it.
    _state: dict[str, ModelArtifact | None] = {"artifact": None}

    @asynccontextmanager
    async def _lifespan(application: FastAPI) -> AsyncGenerator[None, None]:  # noqa: ARG001
        resolved_dir = Path(
            model_dir
            or os.getenv("SCOREFLOW_MODEL_DIR", "models")
        )
        _state["artifact"] = _load_best_artifact(resolved_dir)
        artifact = _state["artifact"]
        if artifact:
            logger.info("Loaded model '%s' (ts=%s)", artifact.name, artifact.timestamp)
        else:
            logger.warning("No model loaded — /score will return 503.")
        yield
        # Shutdown: nothing to clean up.

    app = FastAPI(
        title="ScoreFlow",
        description="Production-ready automated ML scoring API.",
        version="0.1.0",
        lifespan=_lifespan,
    )

    # ── Endpoints ─────────────────────────────────────────────────────────

    @app.get("/health", summary="Health check")
    def health() -> dict[str, str]:
        """Return service health and loaded model info."""
        artifact = _state["artifact"]
        if artifact is None:
            raise HTTPException(status_code=503, detail="No model loaded")
        return {
            "status": "ok",
            "model": artifact.name,
            "version": artifact.timestamp,
        }

    @app.post("/score", response_model=ScoreResponse, summary="Score records")
    def score(payload: ScoreRequest) -> ScoreResponse:
        """Score one or more records using the loaded model.

        Each record in ``records`` should be a flat dict of feature→value pairs.
        Returns a probability score (0–1) per record.
        """
        artifact = _state["artifact"]
        if artifact is None:
            raise HTTPException(status_code=503, detail="No model loaded")

        if not payload.records:
            raise HTTPException(status_code=422, detail="records list must not be empty")

        import pandas as pd

        try:
            df = pd.DataFrame(payload.records)
        except Exception as exc:
            raise HTTPException(status_code=422, detail=f"Invalid records: {exc}") from exc

        try:
            probs: np.ndarray = artifact.model.predict_proba(df)
        except Exception as exc:
            raise HTTPException(
                status_code=422, detail=f"Prediction failed: {exc}"
            ) from exc

        return ScoreResponse(
            scores=probs.tolist(),
            model_name=artifact.name,
            model_version=artifact.timestamp,
        )

    return app


# ── Default app instance (for `uvicorn scoreflow.api.app:app`) ──────────────
app = create_app()
