"""Tests for the FastAPI scoring API (Phase 5)."""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
from fastapi.testclient import TestClient

from scoreflow.api.app import create_app
from scoreflow.data.schema import DatasetSchema
from scoreflow.models.base import ModelArtifact
from scoreflow.models.registry import get_model

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_artifact(tmp_path: Path) -> tuple[Path, ModelArtifact]:
    """Train a tiny LR and save it; return (model_dir, artifact)."""
    rng = np.random.default_rng(0)
    df = pd.DataFrame(
        {
            "feat1": rng.normal(size=200),
            "feat2": rng.normal(size=200),
            "target": rng.integers(0, 2, size=200),
        }
    )
    schema = DatasetSchema(target="target")
    schema.resolve(df)

    model = get_model("logistic_regression")
    model.fit(df[schema.features], df["target"])

    artifact = ModelArtifact(
        model=model,
        name="logistic_regression",
        params=model.get_params(),
        train_time_ns=1000,
        n_rows_trained=200,
    )
    model_dir = tmp_path / "models"
    artifact.save(model_dir)
    return model_dir, artifact


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

def test_health_no_model(tmp_path: Path) -> None:
    """GET /health should return 503 when no model is loaded."""
    empty_dir = tmp_path / "empty_models"
    empty_dir.mkdir()
    app = create_app(model_dir=empty_dir)
    with TestClient(app, raise_server_exceptions=False) as client:
        resp = client.get("/health")
    assert resp.status_code == 503


def test_health_with_model(tmp_path: Path) -> None:
    """GET /health should return 200 and model info when model is loaded."""
    model_dir, _ = _make_artifact(tmp_path)
    app = create_app(model_dir=model_dir)
    with TestClient(app) as client:
        resp = client.get("/health")
    assert resp.status_code == 200
    data = resp.json()
    assert data["status"] == "ok"
    assert data["model"] == "logistic_regression"
    assert "version" in data


def test_score_single_record(tmp_path: Path) -> None:
    """POST /score with a valid single record should return one score."""
    model_dir, _ = _make_artifact(tmp_path)
    app = create_app(model_dir=model_dir)
    with TestClient(app) as client:
        payload = {"records": [{"feat1": 0.5, "feat2": -0.3}]}
        resp = client.post("/score", json=payload)
    assert resp.status_code == 200
    data = resp.json()
    assert len(data["scores"]) == 1
    assert 0.0 <= data["scores"][0] <= 1.0
    assert data["model_name"] == "logistic_regression"


def test_score_batch(tmp_path: Path) -> None:
    """POST /score with multiple records should return one score per record."""
    model_dir, _ = _make_artifact(tmp_path)
    app = create_app(model_dir=model_dir)
    with TestClient(app) as client:
        records = [{"feat1": float(i), "feat2": float(i)} for i in range(5)]
        resp = client.post("/score", json={"records": records})
    assert resp.status_code == 200
    data = resp.json()
    assert len(data["scores"]) == 5


def test_score_empty_records(tmp_path: Path) -> None:
    """POST /score with an empty records list should return 422."""
    model_dir, _ = _make_artifact(tmp_path)
    app = create_app(model_dir=model_dir)
    with TestClient(app, raise_server_exceptions=False) as client:
        resp = client.post("/score", json={"records": []})
    assert resp.status_code == 422


def test_score_no_model(tmp_path: Path) -> None:
    """POST /score should return 503 when no model is loaded."""
    empty_dir = tmp_path / "empty"
    empty_dir.mkdir()
    app = create_app(model_dir=empty_dir)
    with TestClient(app, raise_server_exceptions=False) as client:
        resp = client.post("/score", json={"records": [{"feat1": 1.0}]})
    assert resp.status_code == 503
