"""Tests for the evaluation metrics, evaluator, and selection logic."""

import numpy as np
import pandas as pd
import pytest

from scoreflow.data.schema import DatasetSchema
from scoreflow.data.splitters import DataSplits
from scoreflow.evaluation import (
    EvaluationReport,
    Evaluator,
    calculate_auc,
    calculate_ks,
    calculate_lift,
    calculate_psi,
    persist_evaluation_report,
    select_best_model,
)
from scoreflow.models.base import BaseModel, ModelArtifact


def test_calculate_auc():
    y_true = np.array([0, 0, 1, 1])
    y_prob = np.array([0.1, 0.4, 0.35, 0.8])
    auc = calculate_auc(y_true, y_prob)
    assert auc == 0.75


def test_calculate_ks():
    y_true = np.array([0, 0, 1, 1])
    # T: [0.35, 0.8], F: [0.1, 0.4]
    # CDF Pos: 0.1 -> 0, 0.35 -> 0.5, 0.4 -> 0.5, 0.8 -> 1.0
    # CDF Neg: 0.1 -> 0.5, 0.35 -> 0.5, 0.4 -> 1.0, 0.8 -> 1.0
    # Pos - Neg at 0.1 = 0 - 0.5 = 0.5 diff
    # at 0.35 = 0.5 - 0.5 = 0 diff
    # at 0.4 = 0.5 - 1.0 = 0.5 diff
    y_prob = np.array([0.1, 0.4, 0.35, 0.8])
    ks = calculate_ks(y_true, y_prob)
    # The max diff is 0.5.
    assert ks == pytest.approx(0.5)


def test_calculate_lift():
    # 10 samples, 2 positive
    y_true = np.array([1, 0, 0, 0, 0, 0, 0, 0, 1, 0])
    y_prob = np.array([0.9, 0.8, 0.7, 0.6, 0.5, 0.4, 0.3, 0.2, 0.1, 0.0])
    
    # overall rate = 2/10 = 0.2
    # top 10% -> 1 sample (top prob 0.9, true label 1) -> top rate = 1/1 = 1.0
    # lift = 1.0 / 0.2 = 5.0
    lift_10 = calculate_lift(y_true, y_prob, quantile=0.1)
    assert lift_10 == pytest.approx(5.0)

    # top 20% -> 2 samples (probs 0.9, 0.8, labels 1, 0)
    # top rate = 1/2 = 0.5
    # lift = 0.5 / 0.2 = 2.5
    lift_20 = calculate_lift(y_true, y_prob, quantile=0.2)
    assert lift_20 == pytest.approx(2.5)


def test_calculate_psi():
    # Identical distributions
    expected = np.random.normal(0, 1, 1000)
    actual = expected.copy()
    psi_identical = calculate_psi(expected, actual, buckets=10)
    assert psi_identical == pytest.approx(0.0, abs=1e-5)
    
    # Shifted actual distribution
    actual_shifted = np.random.normal(1, 1, 1000)
    psi_shifted = calculate_psi(expected, actual_shifted, buckets=10)
    assert psi_shifted > 0.1  # Substantial shift


class DummyModel(BaseModel):
    def fit(self, X: pd.DataFrame, y: pd.Series) -> BaseModel:
        return self

    def predict_proba(self, X: pd.DataFrame) -> np.ndarray:
        return np.array([0.8, 0.2, 0.9, 0.1][: len(X)])
        
    def get_params(self):
        return {}

    @property
    def name(self):
        return "dummy"

@pytest.fixture
def dummy_data():
    schema = DatasetSchema(target="target", features=["f1"])
    df_train = pd.DataFrame({"f1": [1, 2, 3, 4], "target": [1, 0, 1, 0]})
    df_val = pd.DataFrame({"f1": [1, 2], "target": [1, 0]})
    df_test = pd.DataFrame({"f1": [3, 4], "target": [1, 0]})
    return schema, DataSplits(train=df_train, val=df_val, test=df_test)


def test_evaluator(dummy_data):
    schema, splits = dummy_data
    model = DummyModel()
    artifact = ModelArtifact(
        model=model,
        name="dummy",
        params={},
        train_time_ns=100,
        n_rows_trained=4,
    )
    
    evaluator = Evaluator(schema)
    report = evaluator.evaluate(artifact, splits)
    
    assert report.model_name == "dummy"
    assert "train" in report.metrics
    assert "val" in report.metrics
    assert "test" in report.metrics
    
    # val target: [1, 0], val probs: [0.8, 0.2]
    # auc should be 1.0
    assert report.metrics["val"]["auc"] == 1.0


def test_select_best_model():
    r1 = EvaluationReport(
        model_name="model1",
        metrics={"val": {"auc": 0.8, "ks": 0.4}},
    )
    r2 = EvaluationReport(
        model_name="model2",
        metrics={"val": {"auc": 0.85, "ks": 0.5}},
    )
    r3 = EvaluationReport(
        model_name="model3",
        metrics={"val": {"auc": 0.85, "ks": 0.6}},
    )
    
    # model3 has same AUC as model2 but strictly higher KS
    best = select_best_model([r1, r2, r3], split="val", primary_metric="auc", tie_breaker="ks")
    assert best.model_name == "model3"


def test_persist_evaluation_report(tmp_path):
    r = EvaluationReport(
        model_name="test_model",
        metrics={"val": {"auc": 0.9}},
    )
    
    out_path = persist_evaluation_report(r, tmp_path)
    assert out_path.exists()
    assert out_path.parts[-2] == "test_model"
    assert out_path.name == "evaluation.json"
    
    import json
    with open(out_path) as f:
        data = json.load(f)
    assert data["model_name"] == "test_model"
    assert data["metrics"]["val"]["auc"] == 0.9
