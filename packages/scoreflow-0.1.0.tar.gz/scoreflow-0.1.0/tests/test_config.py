"""Smoke tests for scoreflow configuration."""

from __future__ import annotations

import scoreflow
from scoreflow.config import (
    DATA_DIR,
    MODELS_DIR,
    PROJECT_ROOT,
    REPORTS_DIR,
    ModelDefaults,
    defaults,
)


class TestProjectPaths:
    def test_project_root_exists(self) -> None:
        assert PROJECT_ROOT.exists(), f"PROJECT_ROOT does not exist: {PROJECT_ROOT}"

    def test_path_constants_are_paths(self) -> None:
        from pathlib import Path

        for p in (DATA_DIR, MODELS_DIR, REPORTS_DIR):
            assert isinstance(p, Path)


class TestModelDefaults:
    def test_default_values(self) -> None:
        d = ModelDefaults()
        assert d.random_state == 42
        assert d.test_size == 0.2
        assert d.cv_folds == 5
        assert d.primary_metric == "roc_auc"

    def test_singleton_matches(self) -> None:
        assert defaults == ModelDefaults()

    def test_frozen(self) -> None:
        import pytest

        with pytest.raises(AttributeError):
            defaults.random_state = 0  # type: ignore[misc]


class TestVersion:
    def test_version_is_string(self) -> None:
        assert isinstance(scoreflow.__version__, str)

    def test_version_not_empty(self) -> None:
        assert len(scoreflow.__version__) > 0
