"""Tests for the scoreflow.models package."""

from pathlib import Path

import numpy as np
import pandas as pd
import pytest

from scoreflow.data.schema import DatasetSchema
from scoreflow.data.splitters import DataSplits
from scoreflow.models.base import BaseModel, ModelArtifact
from scoreflow.models.registry import get_model
from scoreflow.models.trainer import Trainer


# -- Helpers --
def _sample_splits(n: int = 100) -> DataSplits:
    """Return a tiny synthetic dataset for testing training."""
    rng = np.random.default_rng(42)
    df = pd.DataFrame(
        {
            "feat1": rng.normal(size=n),
            "feat2": rng.normal(size=n),
            "target": rng.integers(0, 2, size=n),
        }
    )
    # Using 80/10/10 mock splits
    return DataSplits(
        train=df.iloc[:80].reset_index(drop=True),
        val=df.iloc[80:90].reset_index(drop=True),
        test=df.iloc[90:].reset_index(drop=True),
    )


# -- Tests --
class TestClassifiers:
    @pytest.mark.parametrize("name", ["logistic_regression", "random_forest", "lightgbm"])
    def test_classifier_fit_predict(self, name: str) -> None:
        """Check that all registered classifiers implement the BaseModel interface."""
        splits = _sample_splits()
        X_train = splits.train[["feat1", "feat2"]]
        y_train = splits.train["target"]

        model = get_model(name)
        assert isinstance(model, BaseModel)
        assert model.name == name

        # Fit
        ret = model.fit(X_train, y_train)
        assert ret is model

        # Predict
        probs = model.predict_proba(X_train)
        assert isinstance(probs, np.ndarray)
        assert probs.shape == (80,)
        assert (probs >= 0).all() and (probs <= 1).all()

        # Params
        params = model.get_params()
        assert isinstance(params, dict)

    def test_classifier_kwargs_override(self) -> None:
        model = get_model("random_forest", n_estimators=10)
        assert model.get_params()["n_estimators"] == 10


class TestTrainer:
    def test_trainer_trains_all_models(self) -> None:
        schema = DatasetSchema(target="target")
        schema.resolve(_sample_splits().train)
        
        trainer = Trainer(schema)
        # We only expect 3 models right now
        assert len(trainer.model_names) == 3

        splits = _sample_splits()
        artifacts = trainer.train(splits)

        assert len(artifacts) == 3
        for artifact in artifacts:
            assert isinstance(artifact, ModelArtifact)
            assert artifact.n_rows_trained == 80
            assert artifact.train_time_ns > 0

    def test_trainer_cv(self) -> None:
        schema = DatasetSchema(target="target")
        schema.resolve(_sample_splits().train)
        
        # Test only LR to make it fast
        trainer = Trainer(schema, model_names=["logistic_regression"], cv_folds=2)
        results = trainer.cross_validate(_sample_splits())
        
        assert isinstance(results, pd.DataFrame)
        assert len(results) == 1
        assert "mean_roc_auc" in results.columns
        assert results["model"].iloc[0] == "logistic_regression"

    def test_trainer_save_load_artifacts(self, tmp_path: Path) -> None:
        schema = DatasetSchema(target="target")
        schema.resolve(_sample_splits().train)

        trainer = Trainer(schema, model_names=["logistic_regression"])
        artifacts = trainer.train(_sample_splits())
        
        # Add a fake cv_score
        artifacts[0].cv_score = 0.85
        
        paths = trainer.save_artifacts(artifacts, output_dir=tmp_path)
        assert len(paths) == 1
        
        dir_path = paths[0]
        assert dir_path.is_dir()
        assert (dir_path / "model.joblib").exists()
        assert (dir_path / "metadata.json").exists()

        loaded = ModelArtifact.load(dir_path)
        assert loaded.name == artifacts[0].name
        assert loaded.cv_score == 0.85
        assert isinstance(loaded.model, BaseModel)
