"""Tests for the exportable scoring pipeline (Phase 6)."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

from scoreflow.data.schema import DatasetSchema
from scoreflow.models.base import ModelArtifact
from scoreflow.models.registry import get_model
from scoreflow.pipeline.exporter import export_pipeline
from scoreflow.pipeline.runner import run_pipeline

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_artifact_and_schema() -> tuple[ModelArtifact, DatasetSchema, pd.DataFrame]:
    """Create a tiny trained artifact, schema, and sample DataFrame."""
    rng = np.random.default_rng(7)
    df = pd.DataFrame(
        {
            "feat1": rng.normal(size=150),
            "feat2": rng.normal(size=150),
            "target": rng.integers(0, 2, size=150),
        }
    )
    schema = DatasetSchema(target="target")
    schema.resolve(df)

    model = get_model("logistic_regression")
    model.fit(df[schema.features], df["target"])

    artifact = ModelArtifact(
        model=model,
        name="logistic_regression",
        params=model.get_params(),
        train_time_ns=500,
        n_rows_trained=150,
    )
    return artifact, schema, df


# ---------------------------------------------------------------------------
# Tests — exporter
# ---------------------------------------------------------------------------

def test_export_creates_expected_files(tmp_path: Path) -> None:
    """export_pipeline should create model.joblib, metadata.json, schema.json."""
    artifact, schema, _ = _make_artifact_and_schema()
    out = export_pipeline(artifact, schema, output_dir=tmp_path)

    assert out.is_dir()
    assert (out / "model.joblib").exists()
    assert (out / "metadata.json").exists()
    assert (out / "schema.json").exists()


def test_export_schema_content(tmp_path: Path) -> None:
    """The exported schema.json should contain the correct feature list."""
    artifact, schema, _ = _make_artifact_and_schema()
    out = export_pipeline(artifact, schema, output_dir=tmp_path)

    with open(out / "schema.json") as f:
        data = json.load(f)

    assert data["target"] == "target"
    assert set(data["features"]) == {"feat1", "feat2"}


# ---------------------------------------------------------------------------
# Tests — runner
# ---------------------------------------------------------------------------

def test_run_pipeline_produces_score_column(tmp_path: Path) -> None:
    """run_pipeline should add a 'score' column and write a CSV."""
    artifact, schema, df = _make_artifact_and_schema()
    pipeline_dir = export_pipeline(artifact, schema, output_dir=tmp_path / "pipeline")

    # Write a small input CSV (without target)
    input_csv = tmp_path / "input.csv"
    df[schema.features].to_csv(input_csv, index=False)

    output_csv = tmp_path / "scores.csv"
    result = run_pipeline(pipeline_dir, input_csv, output_csv)

    assert "score" in result.columns
    assert len(result) == len(df)
    assert output_csv.exists()

    # Verify scores are probabilities
    assert (result["score"] >= 0).all() and (result["score"] <= 1).all()


def test_run_pipeline_missing_feature_raises(tmp_path: Path) -> None:
    """run_pipeline should raise ValueError when a required feature is missing."""
    artifact, schema, df = _make_artifact_and_schema()
    pipeline_dir = export_pipeline(artifact, schema, output_dir=tmp_path / "pipeline")

    # Write a CSV with only one feature
    bad_input = tmp_path / "bad.csv"
    df[["feat1"]].to_csv(bad_input, index=False)   # missing feat2

    with pytest.raises(ValueError, match="missing required feature"):
        run_pipeline(pipeline_dir, bad_input, tmp_path / "out.csv")
