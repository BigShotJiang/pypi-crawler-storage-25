"""Tests for the scoreflow.data ingestion layer."""

from __future__ import annotations

import tempfile
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

from scoreflow.data import DatasetSchema, DataSplits, load_dataset, load_file, validate_features
from scoreflow.data.splitters import random_split, time_split

# ── helpers ──────────────────────────────────────────────────────────────


def _sample_df(n: int = 200, seed: int = 42) -> pd.DataFrame:
    """Return a small synthetic DataFrame for testing."""
    rng = np.random.default_rng(seed)
    return pd.DataFrame(
        {
            "id": range(n),
            "age": rng.integers(18, 80, size=n),
            "income": rng.normal(50_000, 15_000, size=n).round(2),
            "city": rng.choice(["NYC", "LA", "CHI"], size=n),
            "target": rng.integers(0, 2, size=n),
        }
    )


def _write_csv(df: pd.DataFrame, dir_path: Path) -> Path:
    p = dir_path / "test.csv"
    df.to_csv(p, index=False)
    return p


def _write_parquet(df: pd.DataFrame, dir_path: Path) -> Path:
    p = dir_path / "test.parquet"
    df.to_parquet(p, index=False)
    return p


# ── Schema ───────────────────────────────────────────────────────────────


class TestDatasetSchema:
    def test_resolve_auto_features(self) -> None:
        df = _sample_df()
        schema = DatasetSchema(target="target", id_column="id")
        schema.resolve(df)
        assert schema.features is not None
        assert "target" not in schema.features
        assert "id" not in schema.features
        assert "age" in schema.features

    def test_resolve_infers_dtypes(self) -> None:
        df = _sample_df()
        schema = DatasetSchema(target="target")
        schema.resolve(df)
        assert "city" in schema.categorical
        assert "age" in schema.numeric

    def test_explicit_features_preserved(self) -> None:
        df = _sample_df()
        schema = DatasetSchema(target="target", features=["age", "income"])
        schema.resolve(df)
        assert schema.features == ["age", "income"]


# ── Loaders ──────────────────────────────────────────────────────────────


class TestLoaders:
    def test_load_csv(self) -> None:
        df = _sample_df(50)
        with tempfile.TemporaryDirectory() as tmp:
            path = _write_csv(df, Path(tmp))
            loaded = load_file(path)
            assert len(loaded) == 50

    def test_load_parquet(self) -> None:
        df = _sample_df(50)
        with tempfile.TemporaryDirectory() as tmp:
            path = _write_parquet(df, Path(tmp))
            loaded = load_file(path)
            assert len(loaded) == 50

    def test_missing_file_raises(self) -> None:
        with pytest.raises(FileNotFoundError):
            load_file("nonexistent.csv")

    def test_unsupported_extension_raises(self) -> None:
        with (
            tempfile.NamedTemporaryFile(suffix=".xlsx", delete=False) as f,
            pytest.raises(ValueError, match="Unsupported"),
        ):
            load_file(f.name)

    def test_empty_csv_raises(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp) / "empty.csv"
            p.write_text("a,b,c\n")
            with pytest.raises(ValueError, match="empty"):
                load_file(p)


# ── Splitters ────────────────────────────────────────────────────────────


class TestRandomSplit:
    def test_sizes(self) -> None:
        df = _sample_df(200)
        splits = random_split(df, "target", test_size=0.2, val_size=0.1)
        assert isinstance(splits, DataSplits)
        total = len(splits.train) + len(splits.val) + len(splits.test)
        assert total == 200

    def test_no_overlap(self) -> None:
        df = _sample_df(200)
        df["_idx"] = range(len(df))
        splits = random_split(df, "target")
        train_idx = set(splits.train["_idx"])
        val_idx = set(splits.val["_idx"])
        test_idx = set(splits.test["_idx"])
        assert train_idx.isdisjoint(val_idx)
        assert train_idx.isdisjoint(test_idx)
        assert val_idx.isdisjoint(test_idx)

    def test_reproducible(self) -> None:
        df = _sample_df(200)
        s1 = random_split(df, "target", random_state=99)
        s2 = random_split(df, "target", random_state=99)
        pd.testing.assert_frame_equal(s1.train, s2.train)


class TestTimeSplit:
    def test_chronological_order(self) -> None:
        rng = np.random.default_rng(0)
        df = pd.DataFrame(
            {
                "ts": pd.date_range("2020-01-01", periods=100, freq="D"),
                "x": rng.normal(size=100),
                "target": rng.integers(0, 2, size=100),
            }
        )
        splits = time_split(df, "ts", test_size=0.2, val_size=0.1)
        assert splits.train["ts"].max() <= splits.val["ts"].min()
        assert splits.val["ts"].max() <= splits.test["ts"].min()


# ── Validation ───────────────────────────────────────────────────────────


class TestValidation:
    def test_clean_data_is_valid(self) -> None:
        df = _sample_df()
        schema = DatasetSchema(target="target")
        schema.resolve(df)
        report = validate_features(df, schema)
        assert report.is_valid

    def test_high_missing_warns(self) -> None:
        df = _sample_df(100)
        df.loc[:79, "age"] = np.nan  # 80 % missing
        schema = DatasetSchema(target="target")
        schema.resolve(df)
        report = validate_features(df, schema, max_missing_rate=0.5)
        assert not report.is_valid
        assert any("missing" in w for w in report.warnings)

    def test_dtype_mismatch_warns(self) -> None:
        df = _sample_df()
        schema = DatasetSchema(target="target", features=["city"], numeric=["city"])
        report = validate_features(df, schema)
        assert any("expected numeric" in w for w in report.warnings)

    def test_high_cardinality_warns(self) -> None:
        rng = np.random.default_rng(0)
        df = pd.DataFrame(
            {
                "cat": [f"v{i}" for i in range(200)],
                "target": rng.integers(0, 2, size=200),
            }
        )
        schema = DatasetSchema(target="target", features=["cat"], categorical=["cat"])
        report = validate_features(df, schema, max_cardinality=50)
        assert any("cardinality" in w for w in report.warnings)


# ── End-to-end ───────────────────────────────────────────────────────────


class TestLoadDataset:
    def test_end_to_end_csv(self) -> None:
        df = _sample_df(200)
        with tempfile.TemporaryDirectory() as tmp:
            path = _write_csv(df, Path(tmp))
            schema = DatasetSchema(target="target", id_column="id")
            splits = load_dataset(path, schema)
            assert isinstance(splits, DataSplits)
            total = len(splits.train) + len(splits.val) + len(splits.test)
            assert total == 200

    def test_time_split_via_load_dataset(self) -> None:
        rng = np.random.default_rng(0)
        df = pd.DataFrame(
            {
                "ts": pd.date_range("2020-01-01", periods=100, freq="D"),
                "x": rng.normal(size=100),
                "target": rng.integers(0, 2, size=100),
            }
        )
        with tempfile.TemporaryDirectory() as tmp:
            path = _write_csv(df, Path(tmp))
            schema = DatasetSchema(target="target", time_column="ts")
            splits = load_dataset(path, schema, split_method="time")
            total = len(splits.train) + len(splits.val) + len(splits.test)
            assert total == 100
