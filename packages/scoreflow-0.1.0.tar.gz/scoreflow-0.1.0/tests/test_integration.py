"""End-to-end integration test: data → train → evaluate → select → export → run."""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
import pytest

from scoreflow.data.schema import DatasetSchema
from scoreflow.data.splitters import random_split
from scoreflow.evaluation import Evaluator, persist_evaluation_report, select_best_model
from scoreflow.models.trainer import Trainer
from scoreflow.pipeline.exporter import export_pipeline
from scoreflow.pipeline.runner import run_pipeline


@pytest.fixture
def synthetic_df() -> pd.DataFrame:
    """400-row synthetic binary classification dataset."""
    rng = np.random.default_rng(99)
    n = 400
    feat1 = rng.normal(size=n)
    feat2 = rng.normal(size=n)
    # Simple linear signal so all models should beat random
    log_odds = 0.8 * feat1 - 0.5 * feat2
    prob = 1 / (1 + np.exp(-log_odds))
    target = rng.binomial(1, prob, size=n)
    return pd.DataFrame({"feat1": feat1, "feat2": feat2, "target": target})


def test_full_pipeline(synthetic_df: pd.DataFrame, tmp_path: Path) -> None:
    """Train → evaluate → select → export → run should produce valid scores."""

    # 1. Schema + splits
    schema = DatasetSchema(target="target")
    schema.resolve(synthetic_df)
    splits = random_split(synthetic_df, target="target", test_size=0.2, val_size=0.1)

    # 2. Train (only LR + RF to keep the test fast)
    trainer = Trainer(schema, model_names=["logistic_regression", "random_forest"])
    artifacts = trainer.train(splits)
    assert len(artifacts) == 2

    # 3. Save artifacts
    artifact_dir = tmp_path / "artifacts"
    trainer.save_artifacts(artifacts, artifact_dir)

    # 4. Evaluate
    evaluator = Evaluator(schema)
    reports = [evaluator.evaluate(a, splits) for a in artifacts]
    assert all("val" in r.metrics for r in reports)
    assert all(r.metrics["val"]["auc"] > 0.5 for r in reports)

    # 5. Select best
    best_report = select_best_model(reports, split="val")
    assert best_report.model_name in ["logistic_regression", "random_forest"]

    # Persist report
    report_path = persist_evaluation_report(best_report, tmp_path / "reports")
    assert report_path.exists()

    # 6. Export best model's artifact
    best_artifact = next(a for a in artifacts if a.name == best_report.model_name)
    pipeline_dir = export_pipeline(best_artifact, schema, output_dir=tmp_path / "pipeline")
    assert (pipeline_dir / "model.joblib").exists()
    assert (pipeline_dir / "schema.json").exists()

    # 7. Run pipeline on the test split (no target column)
    test_features = splits.test[schema.features]
    input_csv = tmp_path / "test_input.csv"
    test_features.to_csv(input_csv, index=False)

    output_csv = tmp_path / "test_scores.csv"
    scored = run_pipeline(pipeline_dir, input_csv, output_csv)

    assert "score" in scored.columns
    assert len(scored) == len(splits.test)
    assert (scored["score"] >= 0).all() and (scored["score"] <= 1).all()
    assert output_csv.exists()
