"""byoe web — lightweight browser UI for the BYOE Agent.

Single-file implementation using only the Python standard library.
No new runtime dependencies beyond what byoe already requires.

Architecture
------------
- ThreadingHTTPServer handles concurrent requests (one thread per connection)
- Server-Sent Events (SSE) stream tokens + tool-call progress to the browser
- All state lives in a single WebSession object shared across HTTP handlers
- A one-time token printed to the terminal gates every request (CSRF-safe)
- The entire frontend is an inline HTML string — no static files needed

Endpoints
---------
  GET  /           → Main UI (requires ?token=... or Cookie)
  GET  /api/status → JSON: project + session summary
  GET  /api/sessions → JSON list of saved sessions
  POST /api/chat   → SSE stream: { "q": "..." }
  POST /api/reset  → Reset conversation
  POST /api/save   → Save session, returns { "id": "..." }
  GET  /api/diff   → JSON list of changed files
  GET  /api/tokens → JSON token usage
  GET  /api/crew   → JSON Crew workspace status
"""
from __future__ import annotations

import hashlib
import html
import io
import json
import os
import queue
import secrets
import sys
import threading
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import TYPE_CHECKING
from urllib.parse import parse_qs, urlparse

if TYPE_CHECKING:
    from .engine.agent import Agent
    from .engine.config import Config


# ─────────────────────────────────────────────────────────────────────────────
# Inline HTML / CSS / JS  (single-page app, no build step)
# ─────────────────────────────────────────────────────────────────────────────

_HTML = r"""<!DOCTYPE html>
<html lang="zh">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>卜一智航 · BYOE</title>
<style>
  :root {
    --bg: #0d1117; --surface: #161b22; --border: #30363d;
    --text: #e6edf3; --muted: #7d8590; --accent: #58a6ff;
    --green: #3fb950; --yellow: #d29922; --red: #f85149;
    --tool-bg: #1c2128; --user-bg: #1f2937; --bot-bg: #161b22;
    --font-mono: 'Cascadia Code', 'Fira Code', 'Consolas', monospace;
    --font-ui: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
  }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { background: var(--bg); color: var(--text); font-family: var(--font-ui);
         display: flex; height: 100vh; overflow: hidden; }

  /* ── sidebar ── */
  #sidebar {
    width: 260px; min-width: 260px; background: var(--surface);
    border-right: 1px solid var(--border); display: flex; flex-direction: column;
    transition: width .2s;
  }
  #sidebar-header { padding: 16px; border-bottom: 1px solid var(--border); }
  #sidebar-header h1 { font-size: 15px; font-weight: 700; color: var(--accent); }
  #sidebar-header .sub { font-size: 11px; color: var(--muted); margin-top: 2px; }
  .sidebar-section { padding: 10px 12px 4px; font-size: 11px; color: var(--muted);
                     text-transform: uppercase; letter-spacing: .06em; }
  .stat-row { display: flex; justify-content: space-between; padding: 4px 16px;
              font-size: 12px; }
  .stat-row .val { color: var(--accent); font-weight: 600; font-family: var(--font-mono); }
  #sessions-list { flex: 1; overflow-y: auto; padding: 4px 0; }
  .sess-item { padding: 8px 16px; cursor: pointer; border-left: 3px solid transparent;
               font-size: 12px; line-height: 1.5; }
  .sess-item:hover { background: rgba(88,166,255,.08); border-left-color: var(--accent); }
  .sess-item .sid { font-family: var(--font-mono); color: var(--accent); font-size: 11px; }
  .sess-item .spre { color: var(--muted); margin-top: 2px;
                     white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  #sidebar-footer { padding: 12px 16px; border-top: 1px solid var(--border); }
  .sb-btn { width: 100%; padding: 7px 12px; background: transparent;
            border: 1px solid var(--border); border-radius: 6px; color: var(--text);
            font-size: 12px; cursor: pointer; margin-bottom: 6px; text-align: left; }
  .sb-btn:hover { background: rgba(88,166,255,.1); border-color: var(--accent); }
  .sb-btn.danger:hover { background: rgba(248,81,73,.1); border-color: var(--red); }

  /* ── main ── */
  #main { flex: 1; display: flex; flex-direction: column; min-width: 0; }
  #toolbar { height: 44px; background: var(--surface); border-bottom: 1px solid var(--border);
             display: flex; align-items: center; padding: 0 16px; gap: 8px; }
  #toolbar .cwd { font-size: 12px; color: var(--muted); font-family: var(--font-mono);
                  flex: 1; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  #toolbar .model-badge { font-size: 11px; background: rgba(88,166,255,.15);
                          color: var(--accent); padding: 2px 8px; border-radius: 12px; }
  #toolbar .token-badge { font-size: 11px; color: var(--muted); }

  /* ── messages ── */
  #messages { flex: 1; overflow-y: auto; padding: 16px 0; }
  .msg { padding: 12px 20px; display: flex; gap: 12px; }
  .msg.user { background: var(--user-bg); }
  .msg.assistant { background: var(--bot-bg); }
  .msg.tool-call { background: var(--tool-bg); padding: 6px 20px; }
  .avatar { width: 28px; height: 28px; border-radius: 50%; flex-shrink: 0;
            display: flex; align-items: center; justify-content: center;
            font-size: 13px; font-weight: 700; }
  .avatar.u { background: #1f6feb; }
  .avatar.a { background: #238636; }
  .avatar.t { background: var(--tool-bg); border: 1px solid var(--border); font-size: 11px; }
  .msg-body { flex: 1; min-width: 0; font-size: 14px; line-height: 1.7; }
  .msg-body pre { background: #0d1117; border: 1px solid var(--border); border-radius: 6px;
                  padding: 12px; overflow-x: auto; font-family: var(--font-mono);
                  font-size: 12px; margin: 8px 0; }
  .msg-body code { font-family: var(--font-mono); font-size: 12px;
                   background: rgba(110,118,129,.2); padding: 1px 5px; border-radius: 3px; }
  .msg-body pre code { background: none; padding: 0; }
  .tool-line { font-size: 12px; font-family: var(--font-mono); color: var(--muted); }
  .tool-line .tool-name { color: var(--yellow); }
  .tool-line .tool-arg { color: var(--accent); }
  .tool-line .tool-err { color: var(--red); }
  .compress-notice { text-align: center; font-size: 11px; color: var(--yellow);
                     padding: 4px; }

  /* ── thinking spinner ── */
  .thinking-row { padding: 10px 20px; display: flex; gap: 12px; align-items: center;
                  background: var(--bot-bg); }
  .thinking-dots { display: flex; gap: 5px; align-items: center; }
  .thinking-dots span {
    width: 7px; height: 7px; border-radius: 50%;
    background: var(--accent);
    animation: td-bounce 1.2s infinite ease-in-out;
    opacity: 0.7;
  }
  .thinking-dots span:nth-child(1) { animation-delay: 0s; }
  .thinking-dots span:nth-child(2) { animation-delay: 0.2s; }
  .thinking-dots span:nth-child(3) { animation-delay: 0.4s; }
  @keyframes td-bounce {
    0%, 80%, 100% { transform: scale(0.6); opacity: 0.4; }
    40%           { transform: scale(1.1); opacity: 1; }
  }
  .thinking-label { font-size: 12px; color: var(--muted); margin-left: 4px; }

  /* ── tool spinner ── */
  .tool-spinner {
    display: inline-block;
    width: 10px; height: 10px;
    border: 2px solid rgba(88,166,255,0.25);
    border-top-color: var(--accent);
    border-radius: 50%;
    animation: spin 0.7s linear infinite;
    vertical-align: middle;
    margin-left: 6px;
  }
  @keyframes spin { to { transform: rotate(360deg); } }

  /* ── diff panel ── */
  #diff-panel { display: none; border-top: 1px solid var(--border); max-height: 200px;
                overflow-y: auto; background: var(--tool-bg); }
  #diff-panel.open { display: block; }
  .diff-item { font-size: 12px; font-family: var(--font-mono); padding: 4px 20px;
               color: var(--green); }

  /* ── input ── */
  #input-area { padding: 12px 16px; border-top: 1px solid var(--border);
                background: var(--surface); }
  #input-row { display: flex; gap: 8px; align-items: flex-end; }
  #input { flex: 1; background: var(--bg); border: 1px solid var(--border);
           border-radius: 8px; color: var(--text); font-size: 14px;
           font-family: var(--font-ui); padding: 10px 14px; resize: none;
           min-height: 44px; max-height: 200px; outline: none; line-height: 1.5; }
  #input:focus { border-color: var(--accent); }
  #send-btn { padding: 10px 18px; background: var(--accent); color: #000;
              border: none; border-radius: 8px; cursor: pointer; font-weight: 600;
              font-size: 13px; white-space: nowrap; }
  #send-btn:disabled { background: var(--border); color: var(--muted); cursor: default; }
  .hint { font-size: 11px; color: var(--muted); margin-top: 6px; }

  /* scrollbar */
  ::-webkit-scrollbar { width: 6px; } ::-webkit-scrollbar-track { background: transparent; }
  ::-webkit-scrollbar-thumb { background: var(--border); border-radius: 3px; }

  @media (max-width: 600px) {
    #sidebar { display: none; }
  }
</style>
</head>
<body>

<div id="sidebar">
  <div id="sidebar-header">
    <h1>卜一智航 · BYOE</h1>
    <div class="sub" id="version-line">携智而来，决策随行 · v__VERSION__</div>
  </div>

  <div class="sidebar-section">状态</div>
  <div class="stat-row"><span>模型</span><span class="val" id="stat-model">—</span></div>
  <div class="stat-row"><span>Prompt tokens</span><span class="val" id="stat-pt">0</span></div>
  <div class="stat-row"><span>Completion</span><span class="val" id="stat-ct">0</span></div>
  <div class="stat-row"><span>费用估算</span><span class="val" id="stat-cost">—</span></div>
  <div class="stat-row"><span>修改文件</span><span class="val" id="stat-files">0</span></div>

  <div class="sidebar-section">历史会话</div>
  <div id="sessions-list"></div>

  <div class="sidebar-section">Crew</div>
  <div id="crew-panel" style="padding:4px 16px 8px;font-size:12px;color:var(--muted)">
    <div id="dc-blockers"></div>
    <div id="dc-changes"></div>
    <div id="dc-next"></div>
  </div>

  <div id="sidebar-footer">
    <button class="sb-btn" onclick="saveSession()">💾 保存会话</button>
    <button class="sb-btn" onclick="showDiff()">📂 查看修改文件</button>
    <button class="sb-btn danger" onclick="resetSession()">🔄 重置对话</button>
  </div>
</div>

<div id="main">
  <div id="toolbar">
    <span class="cwd" id="tb-cwd">—</span>
    <span class="model-badge" id="tb-model">—</span>
    <span class="token-badge" id="tb-tokens">0 tokens</span>
  </div>

  <div id="messages"></div>

  <div id="diff-panel">
    <div style="padding:6px 20px;font-size:11px;color:var(--muted);border-bottom:1px solid var(--border)">
      本次会话修改的文件
      <span onclick="hideDiff()" style="float:right;cursor:pointer">✕</span>
    </div>
    <div id="diff-list"></div>
  </div>

  <div id="input-area">
    <div id="input-row">
      <textarea id="input" placeholder="发送消息… (Enter 提交，Shift+Enter 换行)" rows="1"></textarea>
      <button id="send-btn" onclick="send()">发送</button>
    </div>
    <div class="hint">Enter 提交 · Shift+Enter 换行 · /help /reset /save /diff /tokens</div>
  </div>
</div>

<script>
// ── token: persist in localStorage so page refresh keeps auth ───────────────
const _urlToken = new URLSearchParams(location.search).get('token') || '';
if (_urlToken) {
  localStorage.setItem('byoe_token', _urlToken);
  // clean token from URL bar without reload
  const clean = location.pathname + location.search.replace(/[?&]token=[^&]*/g, '').replace(/^&/, '?').replace(/^\?$/, '');
  history.replaceState(null, '', clean);
}
const TOKEN = _urlToken || localStorage.getItem('byoe_token') || '';
const headers = { 'Content-Type': 'application/json', 'X-BYOE-Token': TOKEN };
let streaming = false;

// ── auto-resize textarea ─────────────────────────────────────────────────────
const inp = document.getElementById('input');
inp.addEventListener('input', () => {
  inp.style.height = 'auto';
  inp.style.height = Math.min(inp.scrollHeight, 200) + 'px';
});
inp.addEventListener('keydown', e => {
  if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); }
});

// ── status polling ───────────────────────────────────────────────────────────
async function refreshStatus() {
  try {
    const r = await fetch('/api/status?token=' + TOKEN);
    if (!r.ok) return;
    const d = await r.json();
    document.getElementById('stat-model').textContent = d.model || '—';
    document.getElementById('stat-pt').textContent = fmtNum(d.prompt_tokens);
    document.getElementById('stat-ct').textContent = fmtNum(d.completion_tokens);
    document.getElementById('stat-cost').textContent = d.estimated_cost != null
      ? '$' + d.estimated_cost.toFixed(4) : '—';
    document.getElementById('stat-files').textContent = d.changed_files || 0;
    document.getElementById('tb-cwd').textContent = d.cwd || '—';
    document.getElementById('tb-model').textContent = d.model || '—';
    document.getElementById('tb-tokens').textContent =
      fmtNum((d.prompt_tokens||0) + (d.completion_tokens||0)) + ' tokens';
  } catch {}
}

async function loadSessions() {
  try {
    const r = await fetch('/api/sessions?token=' + TOKEN);
    if (!r.ok) return;
    const sessions = await r.json();
    const el = document.getElementById('sessions-list');
    el.innerHTML = sessions.map(s => `
      <div class="sess-item" style="display:flex;align-items:flex-start;gap:4px">
        <div style="flex:1;min-width:0" onclick="loadSession('${esc(s.id)}')">
          <div class="sid">${esc(s.id)}</div>
          <div class="spre">${esc(s.preview || '(empty)')}</div>
        </div>
        <span title="删除" style="cursor:pointer;color:var(--muted);font-size:12px;padding:2px 4px"
          onclick="deleteSession('${esc(s.id)}')">✕</span>
      </div>`).join('');
  } catch {}
}

async function deleteSession(id) {
  if (!confirm(`删除会话 ${id}？`)) return;
  const r = await fetch('/api/sessions/' + encodeURIComponent(id), {
    method: 'DELETE', headers
  });
  if (r.ok) loadSessions();
}

async function loadCrew() {
  try {
    const r = await fetch('/api/crew?token=' + TOKEN);
    if (!r.ok) return;
    const d = await r.json();
    if (!d.active) return;
    const bl = document.getElementById('dc-blockers');
    const ch = document.getElementById('dc-changes');
    const nx = document.getElementById('dc-next');
    bl.innerHTML = d.open_blockers.length
      ? `<span style="color:var(--red)">🚨 ${d.open_blockers.length} 个阻塞项</span>` : '';
    ch.innerHTML = d.active_changes.length
      ? d.active_changes.map(c => {
          const pct = c.tasks_total ? Math.round(c.tasks_done/c.tasks_total*100) : 0;
          return `<div style="margin-top:4px">📌 ${esc(c.name)}` +
            (c.tasks_total ? ` <span style="color:var(--accent)">${pct}%</span>` : '') + '</div>';
        }).join('') : '<div style="color:var(--muted)">无活跃变更</div>';
    nx.innerHTML = d.next_steps.length
      ? '<div style="margin-top:6px;color:var(--muted)">下一步:</div>' +
        d.next_steps.map(s => `<div style="padding-left:8px">• ${esc(s)}</div>`).join('') : '';
  } catch {}
}

refreshStatus();
loadSessions();
loadCrew();
setInterval(refreshStatus, 5000);
setInterval(loadCrew, 15000);

// ── send message ─────────────────────────────────────────────────────────────
async function send() {
  const text = inp.value.trim();
  if (!text || streaming) return;

  // built-in slash commands handled client-side for speed
  if (text === '/help') {
    inp.value = '';
    addMsg('assistant', `<strong>Commands</strong><br>
      /reset — clear conversation<br>
      /save — save session<br>
      /diff — show changed files<br>
      /tokens — show token usage<br>
      Send any message to chat with the Agent.`);
    return;
  }
  if (text === '/diff') { inp.value = ''; showDiff(); return; }
  if (text === '/tokens') { inp.value = ''; await showTokens(); return; }
  if (text === '/reset') { inp.value = ''; await resetSession(); return; }
  if (text === '/save') { inp.value = ''; await saveSession(); return; }

  addMsg('user', esc(text).replace(/\n/g, '<br>'));
  inp.value = '';
  inp.style.height = 'auto';
  setStreaming(true);

  // ── 显示"思考中" spinner ──────────────────────────────────────────────────
  const thinkingRow = addThinkingRow();

  const botDiv = addMsg('assistant', '');
  botDiv.style.display = 'none';           // 先隐藏，有内容后再显示
  const bodyEl = botDiv.querySelector('.msg-body');
  let firstToken = true;

  try {
    const resp = await fetch('/api/chat', {
      method: 'POST', headers,
      body: JSON.stringify({ q: text })
    });
    if (!resp.ok) {
      removeThinkingRow(thinkingRow);
      botDiv.style.display = '';
      bodyEl.innerHTML = `<span style="color:var(--red)">Error ${resp.status}</span>`;
      setStreaming(false); return;
    }

    const reader = resp.body.getReader();
    const dec = new TextDecoder();
    let buf = '';
    let contentBuf = '';
    let lastToolRow = null;   // 当前正在执行的工具行

    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      const lines = buf.split('\n');
      buf = lines.pop();
      for (const line of lines) {
        if (!line.startsWith('data: ')) continue;
        const raw = line.slice(6);
        if (raw === '[DONE]') continue;
        let ev;
        try { ev = JSON.parse(raw); } catch { continue; }

        if (ev.type === 'token') {
          // 移除思考 spinner，显示消息框
          if (firstToken) {
            firstToken = false;
            removeThinkingRow(thinkingRow);
            if (lastToolRow) { removeToolSpinner(lastToolRow); lastToolRow = null; }
            botDiv.style.display = '';
          }
          contentBuf += ev.text;
          bodyEl.innerHTML = renderMd(contentBuf);
          scrollBottom();
        } else if (ev.type === 'tool') {
          // 工具开始：移除思考 spinner，添加工具行（带执行 spinner）
          removeThinkingRow(thinkingRow);
          if (lastToolRow) removeToolSpinner(lastToolRow);
          lastToolRow = makeToolRow(ev.name, ev.arg);
          document.getElementById('messages').appendChild(lastToolRow);
          addToolSpinner(lastToolRow);
          scrollBottom();
        } else if (ev.type === 'tool_err') {
          if (lastToolRow) { removeToolSpinner(lastToolRow); lastToolRow = null; }
          const row = makeToolRow(ev.name, ev.arg, ev.snippet);
          document.getElementById('messages').appendChild(row);
          scrollBottom();
        } else if (ev.type === 'compress') {
          addCompressNotice(ev.label);
        } else if (ev.type === 'done') {
          removeThinkingRow(thinkingRow);
          if (lastToolRow) { removeToolSpinner(lastToolRow); lastToolRow = null; }
          if (ev.text && !contentBuf) {
            contentBuf = ev.text;
            botDiv.style.display = '';
            bodyEl.innerHTML = renderMd(contentBuf);
          }
          refreshStatus();
        }
      }
    }
  } catch (e) {
    removeThinkingRow(thinkingRow);
    botDiv.style.display = '';
    bodyEl.innerHTML = `<span style="color:var(--red)">${esc(String(e))}</span>`;
  }
  setStreaming(false);
  scrollBottom();
  refreshStatus();
}

// ── session actions ───────────────────────────────────────────────────────────
async function saveSession() {
  const r = await fetch('/api/save', { method: 'POST', headers, body: '{}' });
  const d = await r.json();
  if (d.id) {
    addMsg('assistant', `✅ 会话已保存：<code>${esc(d.id)}</code>`);
    loadSessions();
  }
}

async function resetSession() {
  await fetch('/api/reset', { method: 'POST', headers, body: '{}' });
  document.getElementById('messages').innerHTML = '';
  addMsg('assistant', '✅ 对话已重置，上下文已清除。');
  refreshStatus();
}

async function loadSession(id) {
  const r = await fetch('/api/load', {
    method: 'POST', headers,
    body: JSON.stringify({ id })
  });
  const d = await r.json();
  if (d.ok) {
    document.getElementById('messages').innerHTML = '';
    // replay messages from loaded session
    for (const m of (d.messages || [])) {
      if (m.role === 'user' && m.content)
        addMsg('user', esc(m.content).replace(/\n/g,'<br>'));
      else if (m.role === 'assistant' && m.content)
        addMsg('assistant', renderMd(m.content));
    }
    addMsg('assistant', `✅ 已恢复会话 <code>${esc(id)}</code>`);
    refreshStatus();
  }
}

async function showDiff() {
  const r = await fetch('/api/diff?token=' + TOKEN);
  const d = await r.json();
  const panel = document.getElementById('diff-panel');
  const list = document.getElementById('diff-list');
  list.innerHTML = d.files.length
    ? d.files.map(f => `<div class="diff-item">+ ${esc(f)}</div>`).join('')
    : '<div class="diff-item" style="color:var(--muted)">本次会话暂无文件修改</div>';
  panel.classList.add('open');
  document.getElementById('stat-files').textContent = d.files.length;
}

function hideDiff() {
  document.getElementById('diff-panel').classList.remove('open');
}

async function showTokens() {
  const r = await fetch('/api/tokens?token=' + TOKEN);
  const d = await r.json();
  const cost = d.estimated_cost != null ? `\n费用估算: $${d.estimated_cost.toFixed(4)}` : '';
  addMsg('assistant',
    `📊 Token 用量\nPrompt: ${fmtNum(d.prompt_tokens)}\nCompletion: ${fmtNum(d.completion_tokens)}\nTotal: ${fmtNum(d.total)}${cost}`
      .replace(/\n/g, '<br>'));
}

// ── DOM helpers ───────────────────────────────────────────────────────────────
function addThinkingRow() {
  const msgs = document.getElementById('messages');
  const div = document.createElement('div');
  div.className = 'thinking-row';
  div.innerHTML = `<div class="avatar a">AI</div>
    <div class="thinking-dots">
      <span></span><span></span><span></span>
    </div>
    <span class="thinking-label">思考中…</span>`;
  msgs.appendChild(div);
  scrollBottom();
  return div;
}

function removeThinkingRow(row) {
  if (row && row.parentNode) row.parentNode.removeChild(row);
}

function addToolSpinner(toolRow) {
  const line = toolRow.querySelector('.tool-line');
  if (!line) return;
  const s = document.createElement('span');
  s.className = 'tool-spinner';
  s.dataset.spinner = '1';
  line.appendChild(s);
}

function removeToolSpinner(toolRow) {
  if (!toolRow) return;
  const s = toolRow.querySelector('.tool-spinner[data-spinner]');
  if (s) s.remove();
}

function addMsg(role, html_content) {
  const msgs = document.getElementById('messages');
  const div = document.createElement('div');
  div.className = 'msg ' + role;
  const avatarText = role === 'user' ? 'U' : 'AI';
  const avatarClass = role === 'user' ? 'u' : 'a';
  div.innerHTML = `<div class="avatar ${avatarClass}">${avatarText}</div>
    <div class="msg-body">${html_content}</div>`;
  msgs.appendChild(div);
  scrollBottom();
  return div;
}

function makeToolRow(name, arg, errSnippet) {
  const msgs = document.getElementById('messages');
  const div = document.createElement('div');
  div.className = 'msg tool-call';
  const icons = {bash:'⚙️',read_file:'📖',edit_file:'✏️',write_file:'💾',glob:'🔍',grep:'🔎',agent:'🤖'};
  const icon = icons[name] || '🔧';
  const argHtml = arg ? ` <span class="tool-arg">${esc(arg.substring(0,100))}</span>` : '';
  const errHtml = errSnippet ? `<pre style="margin-top:4px;color:var(--red)">${esc(errSnippet)}</pre>` : '';
  div.innerHTML = `<div class="avatar t">${icon}</div>
    <div class="msg-body"><span class="tool-line">
      <span class="tool-name">[${esc(name)}]</span>${argHtml}
    </span>${errHtml}</div>`;
  return div;
}

function addCompressNotice(label) {
  const msgs = document.getElementById('messages');
  const div = document.createElement('div');
  div.className = 'compress-notice';
  div.textContent = '⚡ ' + label;
  msgs.appendChild(div);
}

function scrollBottom() {
  const m = document.getElementById('messages');
  m.scrollTop = m.scrollHeight;
}

function setStreaming(v) {
  streaming = v;
  document.getElementById('send-btn').disabled = v;
  document.getElementById('input').disabled = v;
}

function esc(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;');
}

function fmtNum(n) {
  return Number(n||0).toLocaleString();
}

// minimal markdown: code blocks, inline code, bold, italic, line breaks
function renderMd(text) {
  let s = esc(text);
  // fenced code blocks
  s = s.replace(/```(\w*)\n?([\s\S]*?)```/g, (_, lang, code) =>
    `<pre><code>${code}</code></pre>`);
  // inline code
  s = s.replace(/`([^`]+)`/g, '<code>$1</code>');
  // bold
  s = s.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  // italic
  s = s.replace(/\*(.+?)\*/g, '<em>$1</em>');
  // newlines outside pre blocks — split on pre to avoid mangling code
  const parts = s.split(/(<pre[\s\S]*?<\/pre>)/);
  return parts.map((p, i) => i % 2 === 0 ? p.replace(/\n/g, '<br>') : p).join('');
}
</script>
</body>
</html>
"""


# ─────────────────────────────────────────────────────────────────────────────
# Shared web session state
# ─────────────────────────────────────────────────────────────────────────────

class WebSession:
    """Holds the single Agent instance shared across all HTTP requests."""

    def __init__(self, agent: "Agent", config: "Config", token: str, cwd: str):
        self.agent = agent
        self.config = config
        self.token = token
        self.cwd = cwd
        self._lock = threading.Lock()   # serialise chat calls

    def verify(self, req_token: str) -> bool:
        return secrets.compare_digest(self.token, req_token)


# ─────────────────────────────────────────────────────────────────────────────
# HTTP handler
# ─────────────────────────────────────────────────────────────────────────────

class ByoeHandler(BaseHTTPRequestHandler):

    # injected by start_web() below
    session: WebSession

    def log_message(self, fmt, *args):  # noqa: A002
        pass  # suppress default access log; errors still go to stderr

    # ── auth ──────────────────────────────────────────────────────────────────

    def _token_from_request(self) -> str:
        qs = parse_qs(urlparse(self.path).query)
        t = qs.get("token", [""])[0]
        if t:
            return t
        # also accept header (used by fetch() with X-BYOE-Token)
        return self.headers.get("X-BYOE-Token", "")

    def _authorized(self) -> bool:
        return self.session.verify(self._token_from_request())

    # ── response helpers ──────────────────────────────────────────────────────

    def _json(self, code: int, data: object) -> None:
        body = json.dumps(data, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _html_response(self, code: int, body: str) -> None:
        b = body.encode()
        self.send_response(code)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def _read_body(self) -> dict:
        length = int(self.headers.get("Content-Length", 0))
        if length <= 0:
            return {}
        raw = self.rfile.read(length)
        try:
            return json.loads(raw)
        except Exception:
            return {}

    # ── routing ───────────────────────────────────────────────────────────────

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET,POST,DELETE,OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type,X-BYOE-Token")
        self.end_headers()

    def do_GET(self):
        path = urlparse(self.path).path

        if path == "/":
            if not self._authorized():
                # redirect to include token in URL
                self._html_response(200, _HTML.replace("__VERSION__", _byoe_version()))
                return
            self._html_response(200, _HTML.replace("__VERSION__", _byoe_version()))
            return

        if not self._authorized():
            self._json(401, {"error": "Unauthorized"})
            return

        if path == "/api/status":
            self._handle_status()
        elif path == "/api/sessions":
            self._handle_list_sessions()
        elif path == "/api/diff":
            self._handle_diff()
        elif path == "/api/tokens":
            self._handle_tokens()
        elif path == "/api/crew":
            self._handle_crew()
        else:
            self._json(404, {"error": "Not found"})

    def do_POST(self):
        path = urlparse(self.path).path

        if not self._authorized():
            self._json(401, {"error": "Unauthorized"})
            return

        if path == "/api/chat":
            self._handle_chat()
        elif path == "/api/reset":
            self._handle_reset()
        elif path == "/api/save":
            self._handle_save()
        elif path == "/api/load":
            self._handle_load()
        else:
            self._json(404, {"error": "Not found"})

    def do_DELETE(self):
        path = urlparse(self.path).path

        if not self._authorized():
            self._json(401, {"error": "Unauthorized"})
            return

        # DELETE /api/sessions/<id>
        if path.startswith("/api/sessions/"):
            sid = path[len("/api/sessions/"):]
            if not sid:
                self._json(400, {"error": "Missing session id"})
                return
            from byoe.engine.session import delete_session
            ok = delete_session(sid)
            if ok:
                self._json(200, {"ok": True, "id": sid})
            else:
                self._json(404, {"ok": False, "error": f"Session not found: {sid}"})
        else:
            self._json(404, {"error": "Not found"})

    # ── GET handlers ─────────────────────────────────────────────────────────

    def _handle_status(self):
        agent = self.session.agent
        llm = agent.llm
        cost = llm.estimated_cost
        self._json(200, {
            "model": llm.model,
            "cwd": self.session.cwd,
            "prompt_tokens": llm.total_prompt_tokens,
            "completion_tokens": llm.total_completion_tokens,
            "estimated_cost": round(cost, 6) if cost is not None else None,
            "changed_files": len(agent.changed_files),
            "message_count": len(agent.messages),
        })

    def _handle_list_sessions(self):
        from byoe.engine.session import list_sessions
        self._json(200, list_sessions())

    def _handle_diff(self):
        files = sorted(self.session.agent.changed_files)
        self._json(200, {"files": files})

    def _handle_tokens(self):
        llm = self.session.agent.llm
        cost = llm.estimated_cost
        self._json(200, {
            "prompt_tokens": llm.total_prompt_tokens,
            "completion_tokens": llm.total_completion_tokens,
            "total": llm.total_prompt_tokens + llm.total_completion_tokens,
            "estimated_cost": round(cost, 6) if cost is not None else None,
        })

    def _handle_crew(self):
        """Return Crew workspace status as JSON (equiv. to `byoe status`)."""
        cwd = Path(self.session.cwd)
        crew_dir = cwd / "crew"

        if not crew_dir.exists():
            self._json(200, {"active": False, "reason": "no crew/ directory"})
            return

        changes_dir = crew_dir / "changes"
        archive_dir = crew_dir / "archive"

        active_changes = []
        if changes_dir.exists():
            for d in sorted(changes_dir.iterdir()):
                if d.is_dir():
                    info: dict = {"name": d.name}
                    proposal = d / "proposal.md"
                    if proposal.exists():
                        txt = proposal.read_text(encoding="utf-8")
                        # extract title from first heading
                        for line in txt.splitlines():
                            if line.startswith("# "):
                                info["title"] = line[2:].strip()
                                break
                    tasks_total = tasks_done = 0
                    tasks_file = d / "tasks.md"
                    if tasks_file.exists():
                        for line in tasks_file.read_text(encoding="utf-8").splitlines():
                            if line.strip().startswith("- ["):
                                tasks_total += 1
                                if line.strip().startswith("- [x]") or line.strip().startswith("- [X]"):
                                    tasks_done += 1
                    info["tasks_total"] = tasks_total
                    info["tasks_done"] = tasks_done
                    active_changes.append(info)

        archived_count = (
            len([x for x in archive_dir.iterdir() if x.is_dir()])
            if archive_dir.exists() else 0
        )

        # blockers
        open_blockers: list[dict] = []
        blockers_file = crew_dir / "blockers.md"
        if blockers_file.exists():
            import re
            for line in blockers_file.read_text(encoding="utf-8").splitlines():
                m = re.match(r"\[([A-Z0-9-]+)\]\s+\[?(OPEN|CLOSED)\]?\s+(.*)", line.strip())
                if m and m.group(2) == "OPEN":
                    open_blockers.append({"id": m.group(1), "title": m.group(3).strip()})

        # next steps from resume.md
        next_steps: list[str] = []
        resume = crew_dir / "resume.md"
        if resume.exists():
            import re
            in_section = False
            for line in resume.read_text(encoding="utf-8").splitlines():
                if re.match(r"#+\s*(next|下一步)", line, re.I):
                    in_section = True
                    continue
                if in_section:
                    if line.startswith("#"):
                        break
                    stripped = line.strip()
                    if stripped.startswith("-") or stripped.startswith("*"):
                        next_steps.append(stripped.lstrip("-* ").strip())

        self._json(200, {
            "active": True,
            "active_changes": active_changes,
            "archived_count": archived_count,
            "open_blockers": open_blockers,
            "next_steps": next_steps[:5],
        })

    # ── POST handlers ─────────────────────────────────────────────────────────

    def _handle_reset(self):
        self.session.agent.reset()
        self._json(200, {"ok": True})

    def _handle_save(self):
        from byoe.engine.session import save_session
        agent = self.session.agent
        sid = save_session(
            agent.messages,
            agent.llm.model,
            changed_files=agent.changed_files,
        )
        self._json(200, {"id": sid})

    def _handle_load(self):
        from byoe.engine.session import load_session
        body = self._read_body()
        sid = body.get("id", "")
        loaded = load_session(sid)
        if not loaded:
            self._json(404, {"ok": False, "error": f"Session not found: {sid}"})
            return
        msgs, model, changed = loaded
        agent = self.session.agent
        agent.messages = msgs
        agent.changed_files.update(changed)
        agent.llm.model = model
        self._json(200, {"ok": True, "model": model, "messages": msgs})

    def _handle_chat(self):
        """SSE stream: each event is a JSON line prefixed with 'data: '."""
        body = self._read_body()
        q = body.get("q", "").strip()
        if not q:
            self._json(400, {"error": "Empty message"})
            return

        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("X-Accel-Buffering", "no")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()

        def emit(data: dict) -> bool:
            """Write one SSE event. Returns False if the client disconnected."""
            try:
                line = "data: " + json.dumps(data, ensure_ascii=False) + "\n\n"
                self.wfile.write(line.encode())
                self.wfile.flush()
                return True
            except (BrokenPipeError, ConnectionResetError, OSError):
                return False

        def on_token(tok: str):
            emit({"type": "token", "text": tok})

        def on_tool(name: str, kwargs: dict):
            detail = (
                kwargs.get("command") or kwargs.get("path") or
                kwargs.get("file_path") or kwargs.get("pattern") or ""
            )
            if len(detail) > 120:
                detail = detail[:117] + "..."
            emit({"type": "tool", "name": name, "arg": detail})

        def on_tool_result(name: str, kwargs: dict, result: str):
            if name != "bash":
                return
            if not result or result == "(no output)":
                return
            has_error = "[exit code:" in result or result.startswith("Error")
            if has_error or len(result) <= 200:
                emit({"type": "tool_err", "name": name,
                      "arg": kwargs.get("command", ""),
                      "snippet": result[:300]})

        def on_compress(layer: str, before: int, after: int):
            labels = {
                "snip":      "工具输出已裁剪",
                "summarize": "上下文已摘要压缩",
                "collapse":  "上下文已硬重置",
            }
            emit({"type": "compress", "label": labels.get(layer, layer),
                  "before": before, "after": after})

        with self.session._lock:
            old_cwd = os.getcwd()
            try:
                os.chdir(self.session.cwd)
                response = self.session.agent.chat(
                    q,
                    on_token=on_token,
                    on_tool=on_tool,
                    on_tool_result=on_tool_result,
                    on_compress=on_compress,
                )
            except Exception as e:
                emit({"type": "token", "text": f"\n\n**Error:** {e}"})
                response = ""
            finally:
                os.chdir(old_cwd)

        emit({"type": "done", "text": response})
        try:
            self.wfile.write(b"data: [DONE]\n\n")
            self.wfile.flush()
        except OSError:
            pass


# ─────────────────────────────────────────────────────────────────────────────
# Public entry point
# ─────────────────────────────────────────────────────────────────────────────

def start_web(
    host: str = "127.0.0.1",
    port: int = 7860,
    open_browser: bool = True,
    model: str | None = None,
    resume: str | None = None,
) -> None:
    """Build agent, start ThreadingHTTPServer, optionally open browser."""
    from byoe.engine.config import Config
    from byoe.engine.llm import LLM
    from byoe.engine.agent import Agent
    from byoe import __version__

    config = Config.from_env()
    if model:
        config.model = model
    if not config.api_key:
        print(
            "Error: API Key not found.\n"
            "Set BYOE_API_KEY / OPENAI_API_KEY / DEEPSEEK_API_KEY / ANTHROPIC_API_KEY"
        )
        sys.exit(1)

    llm = LLM(
        model=config.model,
        api_key=config.api_key,
        base_url=config.base_url,
        temperature=config.temperature,
        max_tokens=config.max_tokens,
    )
    agent = Agent(llm=llm, max_context_tokens=config.max_context_tokens)

    # Resume an existing session if requested
    if resume:
        from byoe.engine.session import load_session
        loaded = load_session(resume)
        if loaded:
            msgs, sess_model, changed = loaded
            agent.messages = msgs
            agent.changed_files.update(changed)
            if not model:          # don't override explicit --model flag
                agent.llm.model = sess_model
                config.model = sess_model
            print(f"  Resumed: {resume}  ({len(msgs)} messages)")
        else:
            print(f"  Warning: session '{resume}' not found, starting fresh.")

    token = secrets.token_urlsafe(16)
    cwd = os.getcwd()

    # Inject handler's session reference via class attribute
    # (avoids global state while keeping BaseHTTPRequestHandler compatible)
    session = WebSession(agent=agent, config=config, token=token, cwd=cwd)
    ByoeHandler.session = session  # type: ignore[attr-defined]

    server = ThreadingHTTPServer((host, port), ByoeHandler)

    url = f"http://{host}:{port}/?token={token}"

    print("=" * 60)
    print(f"  BYOE Web UI  —  v{_byoe_version()}")
    print(f"  Model : {config.model}")
    print(f"  CWD   : {cwd}")
    print("=" * 60)
    print(f"\n  URL:  {url}\n")
    print("  Ctrl+C to stop\n")

    if open_browser:
        # Delay slightly so the server is ready before the browser connects
        threading.Timer(0.8, webbrowser.open, args=(url,)).start()

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
        server.server_close()


def _byoe_version() -> str:
    try:
        from byoe import __version__
        return __version__
    except Exception:
        return "?"
