"""LLM provider layer - thin wrapper over OpenAI-compatible APIs.

Since most providers (DeepSeek, Qwen, Kimi, GLM, Ollama, etc.) expose an
OpenAI-compatible endpoint, we just use the openai SDK directly.
Switch provider by changing OPENAI_BASE_URL + OPENAI_API_KEY. That's it.
"""

import json
import time
from dataclasses import dataclass, field

from openai import OpenAI, APIError, RateLimitError, APITimeoutError, APIConnectionError


@dataclass
class ToolCall:
    id: str
    name: str
    arguments: dict


@dataclass
class LLMResponse:
    content: str = ""
    tool_calls: list[ToolCall] = field(default_factory=list)
    prompt_tokens: int = 0
    completion_tokens: int = 0

    @property
    def message(self) -> dict:
        msg: dict = {"role": "assistant", "content": self.content or None}
        if self.tool_calls:
            msg["tool_calls"] = [
                {
                    "id": tc.id,
                    "type": "function",
                    "function": {
                        "name": tc.name,
                        "arguments": json.dumps(tc.arguments),
                    },
                }
                for tc in self.tool_calls
            ]
        return msg


# pricing per million tokens: (input, output)
_BUILTIN_PRICING = {
    # OpenAI
    "gpt-5.4": (2.5, 15),
    "gpt-5.4-mini": (0.75, 4.5),
    "gpt-5.4-nano": (0.2, 1.25),
    "o4-mini": (1.1, 4.4),
    "o3": (10, 40),
    "o3-mini": (1.1, 4.4),
    "gpt-4.1": (2, 8),
    "gpt-4.1-mini": (0.4, 1.6),
    "gpt-4.1-nano": (0.1, 0.4),
    "gpt-4o": (2.5, 10),
    "gpt-4o-mini": (0.15, 0.6),
    # Anthropic Claude
    "claude-opus-4-6": (5, 25),
    "claude-sonnet-4-6": (3, 15),
    "claude-sonnet-4-5": (3, 15),
    "claude-haiku-4-5": (1, 5),
    "claude-opus-4": (15, 75),
    "claude-sonnet-4": (3, 15),
    "claude-haiku-4": (0.8, 4),
    # DeepSeek
    "deepseek-chat": (0.27, 1.10),
    "deepseek-reasoner": (0.55, 2.19),
    "deepseek-coder": (0.27, 1.10),
    # Qwen (Alibaba)
    "qwen3-max": (0.78, 3.9),
    "qwen3-plus": (0.26, 0.78),
    "qwen3-coder": (0.78, 3.9),
    "qwen3-235b-a22b": (0.26, 0.78),
    "qwen-max": (0.78, 3.9),
    "qwen-plus": (0.26, 0.78),
    "qwen-turbo": (0.06, 0.18),
    # Kimi (Moonshot)
    "kimi-k2.5": (0.6, 3),
    "moonshot-v1-128k": (0.8, 2.4),
    "moonshot-v1-32k": (0.4, 1.2),
    # Google Gemini
    "gemini-2.5-pro": (1.25, 10),
    "gemini-2.5-flash": (0.075, 0.3),
    "gemini-2.0-flash": (0.075, 0.3),
    "gemini-1.5-pro": (1.25, 5),
    "gemini-1.5-flash": (0.075, 0.3),
    # Mistral
    "mistral-large-2": (2, 6),
    "mistral-small-3": (0.1, 0.3),
    "codestral-2": (0.3, 0.9),
}


def _load_pricing() -> dict:
    """Merge built-in pricing with optional ~/.byoe/pricing.json overrides.

    Format of pricing.json::

        {
            "my-local-model": [0.0, 0.0],
            "gpt-4o": [2.0, 9.0]
        }
    """
    import json
    from pathlib import Path
    overrides_path = Path.home() / ".byoe" / "pricing.json"
    pricing = dict(_BUILTIN_PRICING)
    if overrides_path.exists():
        try:
            raw = json.loads(overrides_path.read_text(encoding="utf-8"))
            for model, rates in raw.items():
                if isinstance(rates, (list, tuple)) and len(rates) == 2:
                    pricing[model] = (float(rates[0]), float(rates[1]))
        except Exception:
            pass  # malformed override file — silently fall back to built-ins
    return pricing


_PRICING = _load_pricing()


class LLM:
    def __init__(
        self,
        model: str,
        api_key: str,
        base_url: str | None = None,
        **kwargs,
    ):
        self.model = model
        self.client = OpenAI(api_key=api_key, base_url=base_url)
        self.extra = kwargs
        self.total_prompt_tokens = 0
        self.total_completion_tokens = 0

    @property
    def estimated_cost(self) -> float | None:
        pricing = _PRICING.get(self.model)
        if not pricing:
            return None
        input_rate, output_rate = pricing
        return (
            self.total_prompt_tokens * input_rate / 1_000_000
            + self.total_completion_tokens * output_rate / 1_000_000
        )

    def chat(
        self,
        messages: list[dict],
        tools: list[dict] | None = None,
        on_token=None,
    ) -> LLMResponse:
        params: dict = {
            "model": self.model,
            "messages": messages,
            "stream": True,
            **self.extra,
        }
        if tools:
            params["tools"] = tools

        try:
            params["stream_options"] = {"include_usage": True}
            stream = self._call_with_retry(params)
        except Exception:
            params.pop("stream_options", None)
            stream = self._call_with_retry(params)

        content_parts: list[str] = []
        tc_map: dict[int, dict] = {}
        prompt_tok = 0
        completion_tok = 0

        for chunk in stream:
            if chunk.usage:
                prompt_tok = chunk.usage.prompt_tokens
                completion_tok = chunk.usage.completion_tokens

            if not chunk.choices:
                continue
            delta = chunk.choices[0].delta

            if delta.content:
                content_parts.append(delta.content)
                if on_token:
                    on_token(delta.content)

            if delta.tool_calls:
                for tc_delta in delta.tool_calls:
                    idx = tc_delta.index
                    if idx not in tc_map:
                        tc_map[idx] = {"id": "", "name": "", "args": ""}
                    if tc_delta.id:
                        tc_map[idx]["id"] = tc_delta.id
                    if tc_delta.function:
                        if tc_delta.function.name:
                            tc_map[idx]["name"] = tc_delta.function.name
                        if tc_delta.function.arguments:
                            tc_map[idx]["args"] += tc_delta.function.arguments

        parsed: list[ToolCall] = []
        for idx in sorted(tc_map):
            raw = tc_map[idx]
            try:
                args = json.loads(raw["args"])
            except (json.JSONDecodeError, KeyError):
                args = {}
            parsed.append(ToolCall(id=raw["id"], name=raw["name"], arguments=args))

        self.total_prompt_tokens += prompt_tok
        self.total_completion_tokens += completion_tok

        return LLMResponse(
            content="".join(content_parts),
            tool_calls=parsed,
            prompt_tokens=prompt_tok,
            completion_tokens=completion_tok,
        )

    def _call_with_retry(self, params: dict, max_retries: int = 3):
        for attempt in range(max_retries):
            try:
                return self.client.chat.completions.create(**params)
            except (RateLimitError, APITimeoutError, APIConnectionError) as e:
                if attempt == max_retries - 1:
                    raise
                time.sleep(2 ** attempt)
            except APIError as e:
                if e.status_code and e.status_code >= 500 and attempt < max_retries - 1:
                    time.sleep(2 ** attempt)
                else:
                    raise
