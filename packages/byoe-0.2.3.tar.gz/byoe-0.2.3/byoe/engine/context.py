"""Multi-layer context compression.

Three compression layers triggered by context window usage:
  Layer 1 (50%)  - snip verbose tool outputs
  Layer 2 (70%)  - LLM-powered summary of old turns
  Layer 3 (90%)  - hard collapse: drop everything except summary + recent
"""

from __future__ import annotations
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .llm import LLM


def _approx_tokens(text: str) -> int:
    """Approximate token count for mixed Chinese/English text.

    Chinese/Japanese/Korean characters are roughly 1 token each (BPE encodes
    them individually).  ASCII content averages ~4 chars/token.  We count CJK
    characters directly and divide the rest by 4.
    """
    cjk = sum(1 for ch in text if '\u4e00' <= ch <= '\u9fff'
              or '\u3040' <= ch <= '\u30ff'
              or '\uac00' <= ch <= '\ud7af')
    ascii_chars = len(text) - cjk
    return cjk + ascii_chars // 4


def estimate_tokens(messages: list[dict]) -> int:
    total = 0
    for m in messages:
        if m.get("content"):
            total += _approx_tokens(m["content"])
        if m.get("tool_calls"):
            total += _approx_tokens(str(m["tool_calls"]))
    return total


class ContextManager:
    def __init__(self, max_tokens: int = 128_000):
        self.max_tokens = max_tokens
        self._snip_at      = int(max_tokens * 0.50)
        self._summarize_at = int(max_tokens * 0.70)
        self._collapse_at  = int(max_tokens * 0.90)

    def maybe_compress(
        self,
        messages: list[dict],
        llm: LLM | None = None,
        on_compress=None,
    ) -> bool:
        """Compress messages if context window usage exceeds thresholds.

        Args:
            messages:    The live message list (mutated in place).
            llm:         Optional LLM used for summarisation.
            on_compress: Optional callable(layer: str, before: int, after: int)
                         called whenever compression occurs — use this to surface
                         a UI notice like "⚡ context compressed".
        """
        current = estimate_tokens(messages)
        compressed = False

        if current > self._snip_at:
            if self._snip_tool_outputs(messages):
                compressed = True
                after = estimate_tokens(messages)
                if on_compress:
                    on_compress("snip", current, after)
                current = after

        if current > self._summarize_at and len(messages) > 10:
            if self._summarize_old(messages, llm, keep_recent=8):
                compressed = True
                after = estimate_tokens(messages)
                if on_compress:
                    on_compress("summarize", current, after)
                current = after

        if current > self._collapse_at and len(messages) > 4:
            self._hard_collapse(messages, llm)
            compressed = True
            after = estimate_tokens(messages)
            if on_compress:
                on_compress("collapse", current, after)

        return compressed

    @staticmethod
    def _snip_tool_outputs(messages: list[dict]) -> bool:
        changed = False
        for m in messages:
            if m.get("role") != "tool":
                continue
            content = m.get("content", "")
            if len(content) <= 1500:
                continue
            lines = content.splitlines()
            if len(lines) <= 6:
                continue
            snipped = (
                "\n".join(lines[:3])
                + f"\n... ({len(lines)} lines, snipped to save context) ...\n"
                + "\n".join(lines[-3:])
            )
            m["content"] = snipped
            changed = True
        return changed

    def _summarize_old(self, messages: list[dict], llm: LLM | None,
                       keep_recent: int = 8) -> bool:
        if len(messages) <= keep_recent:
            return False

        old  = messages[:-keep_recent]
        tail = messages[-keep_recent:]
        summary = self._get_summary(old, llm)

        messages.clear()
        messages.append({
            "role": "user",
            "content": f"[Context compressed - conversation summary]\n{summary}",
        })
        messages.append({
            "role": "assistant",
            "content": "Got it, I have the context from our earlier conversation.",
        })
        messages.extend(tail)
        return True

    def _hard_collapse(self, messages: list[dict], llm: LLM | None):
        tail = messages[-4:] if len(messages) > 4 else messages[-2:]
        summary = self._get_summary(messages[:-len(tail)], llm)

        messages.clear()
        messages.append({
            "role": "user",
            "content": f"[Hard context reset]\n{summary}",
        })
        messages.append({
            "role": "assistant",
            "content": "Context restored. Continuing from where we left off.",
        })
        messages.extend(tail)

    def _get_summary(self, messages: list[dict], llm: LLM | None) -> str:
        flat = self._flatten(messages)

        if llm:
            try:
                resp = llm.chat(
                    messages=[
                        {
                            "role": "system",
                            "content": (
                                "Compress this conversation into a brief summary. "
                                "Preserve: file paths edited, key decisions made, "
                                "errors encountered, current task state. "
                                "Drop: verbose command output, code listings, "
                                "redundant back-and-forth."
                            ),
                        },
                        {"role": "user", "content": flat[:15000]},
                    ],
                )
                return resp.content
            except Exception:
                pass

        return self._extract_key_info(messages)

    @staticmethod
    def _flatten(messages: list[dict]) -> str:
        parts = []
        for m in messages:
            role = m.get("role", "?")
            text = m.get("content", "") or ""
            if text:
                parts.append(f"[{role}] {text[:400]}")
        return "\n".join(parts)

    @staticmethod
    def _extract_key_info(messages: list[dict]) -> str:
        import re
        files_seen: set[str] = set()
        errors: list[str] = []

        for m in messages:
            text = m.get("content", "") or ""
            for match in re.finditer(r'[\w./\-]+\.\w{1,5}', text):
                files_seen.add(match.group())
            for line in text.splitlines():
                if "error" in line.lower():
                    errors.append(line.strip()[:150])

        parts = []
        if files_seen:
            parts.append(f"Files touched: {', '.join(sorted(files_seen)[:20])}")
        if errors:
            parts.append(f"Errors seen: {'; '.join(errors[:5])}")
        return "\n".join(parts) or "(no extractable context)"
