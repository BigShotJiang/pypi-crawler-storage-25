"""Unit tests for orchestrator commands.

These tests are filesystem-centric: each test gets an isolated tmp_path
so commands that call Path.cwd() must have os.chdir patched.

Run:  pytest tests/test_orchestrator.py -v
"""
import os
from pathlib import Path

import pytest


# ── helpers ───────────────────────────────────────────────────────────────────

@pytest.fixture()
def project_dir(tmp_path, monkeypatch):
    """An empty temp dir acting as the project root (CWD)."""
    monkeypatch.chdir(tmp_path)
    return tmp_path


# ── init_command ──────────────────────────────────────────────────────────────

from byoe.orchestrator.commands.init import init_command


class TestInitCommand:
    def test_creates_crew_directory(self, project_dir):
        init_command(name="myproject")
        assert (project_dir / "crew").is_dir()

    def test_creates_instructions_md(self, project_dir):
        init_command(name="myproject")
        assert (project_dir / "crew").is_dir()

    def test_creates_crew_yaml(self, project_dir):
        init_command(name="myproject")
        assert (project_dir / "crew.yaml").is_file()

    def test_creates_resume_md(self, project_dir):
        init_command(name="myproject")
        assert (project_dir / "crew" / "resume.md").is_file()

    def test_creates_blockers_md(self, project_dir):
        init_command(name="myproject")
        assert (project_dir / "crew" / "blockers.md").is_file()

    def test_creates_specs_dir(self, project_dir):
        init_command(name="myproject")
        assert (project_dir / "crew" / "specs").is_dir()

    def test_idempotent_second_call(self, project_dir):
        """Running init twice must not raise or overwrite existing files."""
        init_command(name="myproject")
        (project_dir / "crew.yaml").write_text("sentinel: true", encoding="utf-8")
        init_command(name="myproject")
        assert "sentinel" in (project_dir / "crew.yaml").read_text()

    def test_crew_yaml_contains_project_name(self, project_dir):
        init_command(name="sentinelproject")
        content = (project_dir / "crew.yaml").read_text(encoding="utf-8")
        assert "sentinelproject" in content

    def test_gitignore_updated(self, project_dir):
        init_command(name="myproject", gitignore=True)
        pass  # absence of exception is the assertion


# ── plan_command ──────────────────────────────────────────────────────────────

from byoe.orchestrator.commands.plan import plan_command, _infer_mode


class TestPlanCommand:
    def test_creates_proposal_file(self, project_dir):
        init_command(name="proj")
        plan_command(name="add-auth")
        proposal = project_dir / "crew" / "changes" / "add-auth" / "proposal.md"
        assert proposal.is_file()

    def test_proposal_contains_change_name(self, project_dir):
        init_command(name="proj")
        plan_command(name="add-auth")
        content = (project_dir / "crew" / "changes" / "add-auth" / "proposal.md").read_text(encoding="utf-8")
        assert "add-auth" in content

    def test_express_mode_flag(self, project_dir):
        init_command(name="proj")
        plan_command(name="fix-bug", express=True)
        proposal = project_dir / "crew" / "changes" / "fix-bug" / "proposal.md"
        assert "express" in proposal.read_text(encoding="utf-8")

    def test_no_name_skips_creation(self, project_dir, capsys):
        init_command(name="proj")
        plan_command(name=None)
        captured = capsys.readouterr()
        assert "变更名称" in captured.out or "name" in captured.out.lower()

    def test_duplicate_plan_skips(self, project_dir, capsys):
        init_command(name="proj")
        plan_command(name="feat-x")
        plan_command(name="feat-x")
        captured = capsys.readouterr()
        assert "已存在" in captured.out


class TestInferMode:
    def test_express_keyword(self):
        assert _infer_mode("fix-login", False, False) == "express"

    def test_prototype_keyword(self):
        assert _infer_mode("spike-new-api", False, False) == "prototype"

    def test_explicit_express_flag(self):
        assert _infer_mode("add-feature", True, False) == "express"

    def test_explicit_prototype_flag(self):
        assert _infer_mode("add-feature", False, True) == "prototype"

    def test_standard_default(self):
        assert _infer_mode("add-oauth", False, False) == "standard"


# ── status_command ────────────────────────────────────────────────────────────

from byoe.orchestrator.commands.status import status_command


class TestStatusCommand:
    def test_no_crew_warns(self, project_dir, capsys):
        status_command()
        captured = capsys.readouterr()
        assert "crew" in captured.out

    def test_empty_workspace_shows_no_changes(self, project_dir, capsys):
        init_command(name="proj")
        status_command()
        captured = capsys.readouterr()
        assert "暂无活跃变更" in captured.out or "0" in captured.out or "活跃" in captured.out

    def test_shows_active_change(self, project_dir, capsys):
        init_command(name="proj")
        plan_command(name="my-feature")
        status_command()
        captured = capsys.readouterr()
        assert "my-feature" in captured.out


# ── release_command ───────────────────────────────────────────────────────────

from byoe.orchestrator.commands.release import release_command


class TestReleaseCommand:
    def test_no_crew_warns(self, project_dir, capsys):
        release_command()
        captured = capsys.readouterr()
        assert "crew" in captured.out

    def test_no_changes_warns(self, project_dir, capsys):
        init_command(name="proj")
        release_command()
        captured = capsys.readouterr()
        assert "没有" in captured.out

    def test_pending_change_not_archived(self, project_dir, capsys):
        init_command(name="proj")
        plan_command(name="my-feat")
        release_command()
        captured = capsys.readouterr()
        assert "没有已完成" in captured.out

    def test_confirmed_change_archived(self, project_dir, capsys):
        init_command(name="proj")
        plan_command(name="my-feat")
        proposal = project_dir / "crew" / "changes" / "my-feat" / "proposal.md"
        content = proposal.read_text(encoding="utf-8")
        proposal.write_text(content + "\nverify_confirmed: true\n", encoding="utf-8")
        release_command()
        archive = project_dir / "crew" / "archive"
        assert archive.is_dir()
        archived_names = [d.name for d in archive.iterdir()]
        assert any("my-feat" in n for n in archived_names)
