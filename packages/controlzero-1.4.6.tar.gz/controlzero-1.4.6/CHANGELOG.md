# Changelog

## 1.4.6 -- 2026-05-11

### Fixed

- **resources:["*"] no longer requires a caller resource** (T83).
  Hosted policy bundles emit `resources:["*"]` for any rule that does
  not scope by resource. The enforcer's resource gate previously
  required a caller-supplied `context.resource` even when the rule's
  resources list was the universal wildcard, causing every rule to be
  silently skipped on calls that didn't pass a resource. Result: every
  `cz.guard()` returned `deny` with `reason_code=NO_RULE_MATCH` regardless
  of what the policy said. Now rules with `*` in their resources match
  universally; non-wildcard resource patterns still require a caller
  resource (no silent broadening). Three regression tests added in
  `tests/test_glob_matching.py` including the exact bundle shape from
  the customer reproduction.

## 1.4.5 -- 2026-05-05

### Added

- **Cross-CLI canonical tool coverage** (#341). The shared
  `tool_extractors.json` is now spec_version 2 and adds three new
  canonical tools (`web_search`, `file_search`, `task`) plus extended
  aliases so PowerShell shell-command emission, Codex CLI's
  `apply_patch`, Gemini CLI's `read_many_files`, and the WebFetch
  family all resolve to the existing canonical tools. One rule
  `action: Bash:rm` now covers Claude Code, Gemini CLI, Codex CLI,
  and PowerShell on Windows.
- **SQL semantic-class layer** (#345/#350). New `sql_semantic_class()`
  helper emits a parallel `database:read|write|admin|exec` action
  alongside the existing per-keyword `database:SELECT|DROP|...`
  action. Write portable rules like `allow: database:read` that cover
  SELECT, EXPLAIN, SHOW, DESCRIBE, and CTE in one rule, without
  enumerating every keyword the dialect accepts. Multi-statement
  piggybacks like `SELECT 1; DROP TABLE x` correctly resolve to
  `database:admin` so deny rules catch them. 21 new parity-test
  fixtures (cross-SDK byte-identical with the Node sibling).

### Documentation

- New customer-facing reference at `docs/sdk/policies/canonical-tools.md`
  explaining canonical tool names, alias coverage per host CLI, and
  the contract for adding new clients.
- New SQL semantic class section in `canonical-tools.md` plus updated
  quickstart and read-only-database recipe.

## 1.4.4 -- 2026-04-19

### Fixed

- Hosted mode now refreshes the policy bundle periodically (default 60 seconds) so dashboard edits reach long-running clients without a process restart. New `Client(refresh_interval_seconds=...)` constructor arg controls cadence: pass `None` to disable, `0` to refresh on every `guard()` call (tests only). Added public `Client.refresh()` for on-demand reloads and `Client.last_refreshed_at` for ops visibility. Swap is protected by a lock so multi-threaded callers never observe torn state.
- Bundle translator now reads plural `actions: [...]` rules from the hosted bundle. Previously every such rule collapsed to a universal `*` match, turning narrow denies like `deny database:execute` into deny-all.
- Backend now stamps `api_keys.last_used_at` on the SDK pull endpoint on both fresh-bundle and 304 paths, so the dashboard can distinguish "SDK online with cached bundle" from "SDK has never connected". Best-effort write; stamp failures never block the response.

## 1.4.1 -- 2026-04-15

### Added

- `agent_name` arg + `CZ_AGENT_NAME` env var contract on the `Client` constructor (issue #71). Order: explicit arg > env > `default-agent`.
- `CZ_DEBUG=1` (or `true`/`yes`/`on`) flips the controlzero logger to DEBUG at construction. Cheap escape hatch for support.
- Optional install extras: `controlzero[google]`, `controlzero[openai]`, `controlzero[anthropic]` (issue #68). Pin the matching upstream SDK so users do not see import errors.
- Cross-SDK action canonicalization parity test (issue #69). Mirrors the same fixture in the Node and Go SDKs.
- Smoke + denial + error-propagation tests for the `wrap_google` integration (issue #68).

## 1.4.0 -- 2026-04-15

### Breaking changes

- Integration wrappers now emit simplified action names (`llm:generate`, `embedding:generate`, `tool:call`) instead of provider-prefixed ones (`llm:openai:chat.completions.create`). Policies targeting the old action names must be updated. Provider and model move into `context` tags. See docs/integrations for current patterns.
- Google integration rewritten against `google-genai` (deprecated `google.generativeai` removed). Install `google-genai`.
- `integrations.langchain.agent.GovernedAgent` wrapping `AgentExecutor` is deprecated in LangChain v1.x. Use `integrations.langchain.modern.create_governed_agent`.

### New integrations

- `integrations.autogen` - first-party helper for autogen-agentchat v0.7+
- `integrations.pydantic_ai` - first-party helper for pydantic-ai v1.x
- `integrations.langchain.modern` - LangGraph create_agent pattern

### New features

- Policy rule `conditions` field is now evaluated in the local enforcer. Conditions are matched against merged context + args with glob patterns. All keys must match.

### Enhancements

- `integrations.litellm` - async + success/failure hooks for streaming audit.
