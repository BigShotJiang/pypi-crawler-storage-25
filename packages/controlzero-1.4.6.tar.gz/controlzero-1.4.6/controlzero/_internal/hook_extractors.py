"""Hook-check tool-method extractor.

Consumes the canonical spec at
``controlzero/_internal/tool_extractors.json`` (byte-identical to
``tests/fixtures/enforcement-spec/extractors/tool-extractors.json``)
and turns a host-agent PreToolUse payload into a canonical
``(tool, method)`` action string.

Phase 3 of issue #228. The ``controlzero hook-check`` CLI previously
passed ``method="*"`` for every call because it could not reach into
``tool_input`` to pull a method out. That meant rules like
``deny database:DROP`` never matched via the hook path -- Gateway and
``Client.guard(...)`` saw the method, but the hook collapsed to
``database:*`` and either over- or under-enforced.

The functions defined in this module MUST produce byte-identical
output to the Node-SDK implementation in
``sdks/node/controlzero/src/internal/toolExtractors.ts``. Parity is
verified by the cases at
``tests/fixtures/enforcement-spec/extractors/parity-cases.json``.

Security model: this extractor is the FIRST layer of defence. When it
cannot confidently parse a value, it returns ``""`` and the resolver
substitutes the tool's ``fallback_method`` (``"*"`` for every danger
scanner). A rule that does not include ``*`` therefore misses, and
the bundle's ``default_action`` fires -- deny by default in any
governance-worthy policy.
"""

from __future__ import annotations

import json
import os
import re
from functools import lru_cache
from typing import Any, Dict, Optional, Tuple


# ---------------------------------------------------------------------------
# Spec loading
# ---------------------------------------------------------------------------


_SPEC_PATH = os.path.join(os.path.dirname(__file__), "tool_extractors.json")


@lru_cache(maxsize=1)
def _load_spec() -> Dict[str, Any]:
    """Load the extractor spec JSON from disk.

    Cached at import time via ``lru_cache`` so every ``hook-check``
    invocation reads the file exactly once. The spec is small (under
    2 KiB) so the cost of a re-read is trivial, but we still avoid it.
    """
    with open(_SPEC_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


# ---------------------------------------------------------------------------
# Danger orderings
# ---------------------------------------------------------------------------
#
# Lowest index = most dangerous. See the README under
# ``tests/fixtures/enforcement-spec/extractors/README.md``.
# Reordering these is a major version bump (``spec_version`` 1 -> 2).

_SQL_DANGER_ORDER = (
    "DROP", "TRUNCATE", "GRANT", "REVOKE", "ALTER", "DELETE", "UPDATE",
    "INSERT", "CREATE", "MERGE",
    "COPY", "LOAD", "EXECUTE", "CALL", "DO", "VACUUM", "REINDEX",
    "CLUSTER", "LOCK",
    "SELECT", "WITH", "SHOW", "EXPLAIN", "DESCRIBE", "DESC", "VALUES",
)
_SQL_DANGER_RANK = {kw: i for i, kw in enumerate(_SQL_DANGER_ORDER)}

# Mapping from raw SQL keyword -> canonical semantic class.
#
# Four semantic classes form a portable, dialect-independent layer
# above the per-keyword action. A rule written against `database:read`
# matches every read-shaped statement (SELECT, EXPLAIN, SHOW, CTE, ...)
# regardless of which dialect-specific spelling the agent emitted. See
# ``docs/sdk/policies/canonical-tools.md`` for the full contract.
#
# - ``read``: SELECT, EXPLAIN, SHOW, DESCRIBE, USE, WITH (CTE that
#   produces a SELECT), VALUES.
# - ``write``: INSERT, UPDATE, DELETE, MERGE, COPY (table target), LOAD.
# - ``admin``: CREATE, ALTER, DROP, TRUNCATE, GRANT, REVOKE, RENAME,
#   ATTACH, DETACH, REINDEX, VACUUM, ANALYZE, OPTIMIZE, CLUSTER, LOCK.
# - ``exec``: CALL, EXECUTE, DO, BEGIN/COMMIT/ROLLBACK transaction
#   control keywords.
#
# Multi-statement: most-dangerous-class wins per the danger ordering
# above. SQL-injection piggyback ``SELECT 1; DROP TABLE x`` resolves
# to ``database:admin`` so a deny-admin rule catches it.
_SQL_KEYWORD_TO_CLASS = {
    # read
    "SELECT": "read",
    "WITH": "read",
    "SHOW": "read",
    "EXPLAIN": "read",
    "DESCRIBE": "read",
    "DESC": "read",
    "USE": "read",
    "VALUES": "read",
    # write
    "INSERT": "write",
    "UPDATE": "write",
    "DELETE": "write",
    "MERGE": "write",
    "UPSERT": "write",
    "REPLACE": "write",
    "COPY": "write",
    "LOAD": "write",
    # admin
    "CREATE": "admin",
    "ALTER": "admin",
    "DROP": "admin",
    "TRUNCATE": "admin",
    "GRANT": "admin",
    "REVOKE": "admin",
    "RENAME": "admin",
    "ATTACH": "admin",
    "DETACH": "admin",
    "REINDEX": "admin",
    "VACUUM": "admin",
    "ANALYZE": "admin",
    "OPTIMIZE": "admin",
    "CLUSTER": "admin",
    "LOCK": "admin",
    # exec
    "CALL": "exec",
    "EXECUTE": "exec",
    "DO": "exec",
    "BEGIN": "exec",
    "COMMIT": "exec",
    "ROLLBACK": "exec",
    "START": "exec",
    "SAVEPOINT": "exec",
}

# Class danger ordering: lowest index wins when multiple statements
# resolve to different classes. ``admin`` outranks ``write`` outranks
# ``exec`` outranks ``read``. ``exec`` sits between write and read so
# a transaction-control wrapper around reads still surfaces as exec.
_SQL_CLASS_DANGER_ORDER = ("admin", "write", "exec", "read")
_SQL_CLASS_DANGER_RANK = {c: i for i, c in enumerate(_SQL_CLASS_DANGER_ORDER)}

_SHELL_DANGER_ORDER = (
    "rm", "dd", "mkfs", "fdisk", "shred", "shutdown", "reboot", "halt",
    "kill", "killall", "pkill",
    "curl", "wget", "nc", "ncat", "ssh", "scp", "rsync", "sftp", "ftp",
    "tar", "zip", "unzip",
    "chmod", "chown", "su", "sudo", "useradd", "usermod", "passwd",
    "crontab",
    "psql", "mysql", "mongosh", "redis-cli", "clickhouse-client",
    "docker", "kubectl", "terraform",
    "python", "python3", "node", "ruby", "perl", "php", "java",
    "bash", "sh", "zsh", "fish",
    "git", "gh", "aws", "gcloud", "azure",
    "echo", "cat", "ls", "pwd", "cd", "mkdir", "touch", "date",
)
_SHELL_DANGER_RANK = {cmd: i for i, cmd in enumerate(_SHELL_DANGER_ORDER)}


# ---------------------------------------------------------------------------
# SQL literal/comment stripping
# ---------------------------------------------------------------------------


def _strip_sql_noise(sql: str) -> str:
    """Replace SQL string literals and comments with whitespace.

    Preserves newlines so line anchors and statement splitting on ``;``
    continue to work. Handles:

    - ``'...'`` single-quoted literals with ``''`` doubled-quote escape.
    - ``"..."`` double-quoted literals with ``""`` doubled-quote escape
      (PostgreSQL quoted identifiers; treated as opaque strings for
      the purpose of keyword scanning).
    - ``-- ...\\n`` line comments.
    - ``/* ... */`` block comments (non-nesting).

    All replaced characters become a space except for newlines, which
    are preserved verbatim. This keeps statement offsets stable for
    later tokenization.
    """
    out = []
    i = 0
    n = len(sql)
    while i < n:
        ch = sql[i]
        nxt = sql[i + 1] if i + 1 < n else ""

        # Line comment: -- ... (newline)
        if ch == "-" and nxt == "-":
            i += 2
            while i < n and sql[i] != "\n":
                out.append(" ")
                i += 1
            continue

        # Block comment: /* ... */ (no nesting)
        if ch == "/" and nxt == "*":
            # Replace opening "/*"
            out.append(" ")
            out.append(" ")
            i += 2
            while i < n:
                if sql[i] == "*" and i + 1 < n and sql[i + 1] == "/":
                    out.append(" ")
                    out.append(" ")
                    i += 2
                    break
                if sql[i] == "\n":
                    out.append("\n")
                else:
                    out.append(" ")
                i += 1
            continue

        # Single-quoted literal with '' escape
        if ch == "'":
            out.append(" ")
            i += 1
            while i < n:
                if sql[i] == "'":
                    # Escaped quote? '' stays inside the literal.
                    if i + 1 < n and sql[i + 1] == "'":
                        out.append(" ")
                        out.append(" ")
                        i += 2
                        continue
                    out.append(" ")
                    i += 1
                    break
                if sql[i] == "\n":
                    out.append("\n")
                else:
                    out.append(" ")
                i += 1
            continue

        # Double-quoted identifier/literal with "" escape
        if ch == '"':
            out.append(" ")
            i += 1
            while i < n:
                if sql[i] == '"':
                    if i + 1 < n and sql[i + 1] == '"':
                        out.append(" ")
                        out.append(" ")
                        i += 2
                        continue
                    out.append(" ")
                    i += 1
                    break
                if sql[i] == "\n":
                    out.append("\n")
                else:
                    out.append(" ")
                i += 1
            continue

        out.append(ch)
        i += 1
    return "".join(out)


_SQL_FIRST_KEYWORD_RE = re.compile(r"^\s*([A-Za-z]+)")


# ---------------------------------------------------------------------------
# Public extractor functions
# ---------------------------------------------------------------------------


def most_dangerous_sql_keyword(sql: str) -> str:
    """Return the most dangerous SQL keyword across every statement.

    Algorithm:
        1. Strip string literals and comments, preserving newlines.
        2. Split on ``;`` to get per-statement pieces.
        3. For each piece, match ``/^\\s*([A-Za-z]+)/`` and uppercase
           the captured word.
        4. Rank every recognized keyword by the danger ordering and
           return the one with the lowest index.
        5. If no recognized keyword is found, return ``""``.

    Byte-identical to the Node implementation in
    ``sdks/node/controlzero/src/internal/toolExtractors.ts``.
    """
    if not isinstance(sql, str) or not sql:
        return ""

    stripped = _strip_sql_noise(sql)
    best_rank: Optional[int] = None
    best_kw: str = ""

    for piece in stripped.split(";"):
        m = _SQL_FIRST_KEYWORD_RE.match(piece)
        if not m:
            continue
        kw = m.group(1).upper()
        rank = _SQL_DANGER_RANK.get(kw)
        if rank is None:
            continue
        if best_rank is None or rank < best_rank:
            best_rank = rank
            best_kw = kw

    return best_kw


def sql_semantic_class(sql: str) -> str:
    """Return the most-dangerous semantic class across every statement.

    Returns one of ``read|write|admin|exec`` or ``""`` when no
    recognized keyword is found in the input. The class is derived by
    looking up every per-statement first keyword in
    ``_SQL_KEYWORD_TO_CLASS`` and picking the one with the lowest
    danger rank (``admin`` > ``write`` > ``exec`` > ``read``).

    Multi-statement piggyback (``SELECT 1; DROP TABLE x``) resolves to
    ``admin`` so a ``deny: database:admin`` rule catches it. Comments
    and string literals are stripped before tokenization, identical to
    :func:`most_dangerous_sql_keyword`.

    Byte-identical to the Node implementation in
    ``sdks/node/controlzero/src/internal/hookExtractors.ts``.
    """
    if not isinstance(sql, str) or not sql:
        return ""

    stripped = _strip_sql_noise(sql)
    best_rank: Optional[int] = None
    best_class: str = ""

    for piece in stripped.split(";"):
        m = _SQL_FIRST_KEYWORD_RE.match(piece)
        if not m:
            continue
        kw = m.group(1).upper()
        cls = _SQL_KEYWORD_TO_CLASS.get(kw)
        if cls is None:
            continue
        rank = _SQL_CLASS_DANGER_RANK.get(cls)
        if rank is None:
            continue
        if best_rank is None or rank < best_rank:
            best_rank = rank
            best_class = cls

    return best_class


_SHELL_SEPARATORS_RE = re.compile(r"(\|\||&&|;|\|)")


def _split_shell_segments(cmd: str) -> list:
    """Tokenize a shell command on separators and subshells.

    Separators: ``;``, ``&&``, ``||``, ``|``. Subshells: ``$(...)``
    and backtick command substitution are pulled out as their own
    segments containing the inner body.
    """
    segments: list = []

    # First pass: extract subshell bodies, replacing them with spaces
    # in the outer string so they are not double-counted.
    outer_chars = []
    i = 0
    n = len(cmd)
    while i < n:
        ch = cmd[i]
        nxt = cmd[i + 1] if i + 1 < n else ""
        if ch == "$" and nxt == "(":
            # Find the matching close paren, supporting nested $(...)
            # groups. Bare `(` in shell is a grouping construct that is
            # rare inside $(...) in practice; we treat only $(...) as
            # depth-increasing to keep the tokenizer deliberately dumb.
            depth = 1
            i += 2
            start = i
            while i < n and depth > 0:
                if cmd[i] == "$" and i + 1 < n and cmd[i + 1] == "(":
                    depth += 1
                    i += 2
                    continue
                if cmd[i] == ")":
                    depth -= 1
                    if depth == 0:
                        break
                    i += 1
                    continue
                i += 1
            inner = cmd[start:i]
            # Skip closing paren if present
            if i < n and cmd[i] == ")":
                i += 1
            # Recurse: the subshell body is its own set of segments.
            segments.extend(_split_shell_segments(inner))
            outer_chars.append(" ")
            continue
        if ch == "`":
            # Backtick subshell
            i += 1
            start = i
            while i < n and cmd[i] != "`":
                i += 1
            inner = cmd[start:i]
            if i < n and cmd[i] == "`":
                i += 1
            segments.extend(_split_shell_segments(inner))
            outer_chars.append(" ")
            continue
        outer_chars.append(ch)
        i += 1

    outer = "".join(outer_chars)

    # Second pass: split outer on ;, &&, ||, | separators.
    for piece in _SHELL_SEPARATORS_RE.split(outer):
        if piece in (";", "&&", "||", "|"):
            continue
        if piece.strip():
            segments.append(piece)

    return segments


def _first_token_basename(segment: str) -> str:
    """Take the first whitespace-delimited token and basename it."""
    token = segment.strip().split()[0] if segment.strip() else ""
    if not token:
        return ""
    # basename: drop everything up to and including the last "/"
    idx = token.rfind("/")
    if idx >= 0:
        return token[idx + 1:]
    return token


def most_dangerous_shell_command(cmd: str) -> str:
    """Return the most dangerous shell command across every segment.

    Algorithm:
        1. Tokenize on ``;``, ``&&``, ``||``, ``|``. Also pull out
           ``$(...)`` and backtick subshell bodies as their own
           segments.
        2. For each non-empty segment, take the first whitespace
           token and basename it.
        3. Rank every recognized command by the danger ordering.
           Return the one with the lowest index.
        4. If no recognized command is found, return the first
           segment's basenamed first token so unknown-but-simple
           commands still log something useful.
        5. Empty / whitespace-only -> ``""``.

    Byte-identical to the Node implementation in
    ``sdks/node/controlzero/src/internal/toolExtractors.ts``.
    """
    if not isinstance(cmd, str) or not cmd.strip():
        return ""

    segments = _split_shell_segments(cmd)
    if not segments:
        return ""

    best_rank: Optional[int] = None
    best_cmd: str = ""
    first_segment_token: str = ""

    for idx, seg in enumerate(segments):
        tok = _first_token_basename(seg)
        if idx == 0 and tok and not first_segment_token:
            first_segment_token = tok
        if not tok:
            continue
        rank = _SHELL_DANGER_RANK.get(tok)
        if rank is None:
            continue
        if best_rank is None or rank < best_rank:
            best_rank = rank
            best_cmd = tok

    if best_cmd:
        return best_cmd

    # No recognized command found -- fall back to the first segment's
    # first-token basename so unknown programs are still audit-visible.
    return first_segment_token


def identity(v: str) -> str:
    """Return ``v`` unchanged. Used for browser ``action``."""
    if not isinstance(v, str):
        return ""
    return v


def identity_upper(v: str) -> str:
    """Return ``v.upper()``. Used for HTTP method normalization."""
    if not isinstance(v, str):
        return ""
    return v.upper()


def tool_name_as_method(tool: str) -> str:  # noqa: ARG001
    """Return ``""`` so the resolver applies ``fallback_method``.

    Used for tools whose TYPE is their method -- ``file_read`` is
    always method ``"read"``. See the spec README for the rationale
    (keeps the extract-function a pure "cannot extract" signal).
    """
    return ""


# Registry used by ``extract_method``. Mirrors the function names in
# ``tool-extractors.json``. Any new function must be added here AND in
# the Node-SDK toolExtractors.ts.
_EXTRACTORS = {
    "most_dangerous_sql_keyword": most_dangerous_sql_keyword,
    "most_dangerous_shell_command": most_dangerous_shell_command,
    "identity": identity,
    "identity_upper": identity_upper,
    "tool_name_as_method": tool_name_as_method,
}


# ---------------------------------------------------------------------------
# Resolver
# ---------------------------------------------------------------------------


def resolve_canonical_tool(tool_name: str) -> str:
    """Resolve a host-agent tool name to its canonical name.

    Returns:
        - ``tool_name`` unchanged if it is a direct key in ``tools``.
        - The canonical key if the input matches an entry's aliases.
        - ``tool_name`` unchanged if no alias matches (unknown tool
          falls through; caller must apply ``fallback_method="*"``).
    """
    if not isinstance(tool_name, str) or not tool_name:
        return tool_name if isinstance(tool_name, str) else ""
    spec = _load_spec()
    tools = spec.get("tools", {}) or {}
    if tool_name in tools:
        return tool_name
    for canonical, entry in tools.items():
        aliases = entry.get("aliases") or []
        if tool_name in aliases:
            return canonical
    return tool_name


def extract_method(
    tool_name: str,
    args: Optional[dict],
) -> Tuple[str, str]:
    """Resolve ``(canonical_tool, method)`` from a PreToolUse payload.

    Applies the spec's resolution algorithm:

    1. Canonical tool lookup (via :func:`resolve_canonical_tool`).
    2. If the tool is unknown, method = ``"*"``.
    3. Read ``args_path`` from the entry. If non-null, ``raw =
       args[args_path]``; else ``raw = tool_name`` (used by
       ``file_read`` / ``file_write``).
    4. Apply the ``extract`` function. Non-empty result = method.
    5. Empty result -> ``fallback_method``.

    Any exception (missing field, wrong type, unknown extract
    function) falls back to ``fallback_method`` (``"*"`` for most
    tools) to preserve fail-closed semantics: the emitted action
    still reaches the policy engine, which enforces
    ``default_action`` on the no-match path.
    """
    canonical = resolve_canonical_tool(tool_name)
    spec = _load_spec()
    tools = spec.get("tools", {}) or {}
    entry = tools.get(canonical)
    if entry is None:
        return canonical, "*"

    fallback = entry.get("fallback_method", "*") or "*"
    args_path = entry.get("args_path")
    extract_name = entry.get("extract", "")

    try:
        if args_path is None:
            raw = tool_name
        else:
            if not isinstance(args, dict):
                return canonical, fallback
            raw = args.get(args_path)
            if raw is None:
                return canonical, fallback
            if not isinstance(raw, str):
                return canonical, fallback

        func = _EXTRACTORS.get(extract_name)
        if func is None:
            return canonical, fallback

        result = func(raw)
        if not isinstance(result, str) or result == "":
            return canonical, fallback
        return canonical, result
    except Exception:
        # Never let an extractor crash brick the hook. Fall back.
        return canonical, fallback


def build_action(tool_name: str, args: Optional[dict]) -> str:
    """Return ``"{canonical_tool}:{method}"`` for the given payload."""
    canonical, method = extract_method(tool_name, args)
    return f"{canonical}:{method}"


__all__ = [
    "build_action",
    "extract_method",
    "identity",
    "identity_upper",
    "most_dangerous_shell_command",
    "most_dangerous_sql_keyword",
    "resolve_canonical_tool",
    "sql_semantic_class",
    "tool_name_as_method",
]
