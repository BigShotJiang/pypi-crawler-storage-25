"""Internal type definitions. Public users should import from controlzero, not here."""

from typing import Any, Optional
from pydantic import BaseModel, Field


class PolicyRule(BaseModel):
    """Internal canonical representation of a single policy rule.

    The user-facing schema (see policy_loader) is friendlier; this is what the
    evaluator consumes after translation.
    """
    id: str = ""
    name: str = ""
    effect: str  # "allow" or "deny"
    actions: list[str] = Field(default_factory=list)
    resources: list[str] = Field(default_factory=list)
    conditions: dict[str, Any] = Field(default_factory=dict)
    reason: str = ""  # Human-readable explanation, surfaced in audit + denies
    # Machine-readable reason code from the REASON_CODE_* enum in
    # enforcer.py. Set for synthetic rules emitted by the bundle
    # translator (e.g. the empty-bundle deny carries
    # "NO_ACTIVE_POLICIES"). User-authored rules leave this empty and
    # the evaluator does not promote them to a code.
    reason_code: str = ""
