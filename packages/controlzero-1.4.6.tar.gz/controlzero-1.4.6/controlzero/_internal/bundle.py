"""Policy bundle parser (`.czpolicy`).

See `docs/designs/policy-bundle-format.md` for the authoritative spec.

This module is a *pure function* parser: given bundle bytes plus the
project encryption key and the project signing public key, it either
returns the decrypted policy payload as a dict, or raises a
:class:`BundleVerificationError` / :class:`BundleFormatError`.

The parser performs **no I/O**. It does not read from disk. It does not
make network calls. It does not mutate global state. This is
intentional: the integrity of the policy flow depends on the parser
being auditable in isolation. All I/O (fetching bundles, caching,
retries) lives in :mod:`controlzero.hosted_policy`.

Wire format (little-endian throughout):

    offset  size  field
    0       4     magic           ASCII "CZ01"
    4       2     schema_version  uint16
    6       8     created_at      uint64 UNIX seconds
    14      2     policy_count    uint16 (informational)
    16      4     sig_offset      uint32 (absolute byte offset of signature)
    20      4     sig_len         uint32 (must be 64)
    24      8     reserved        must be zero
    32      N     payload         authenticated-encryption over zstd(json)
    32+N    64    signature       signature over header[0:32] || payload
"""

from __future__ import annotations

import json
import struct
from dataclasses import dataclass
from typing import Optional  # noqa: F401  (used in type annotations below)

# --- Exceptions ------------------------------------------------------------


class BundleFormatError(ValueError):
    """Bundle bytes do not match the expected wire format.

    Raised for structural problems: wrong magic, impossible offsets,
    truncated data, unknown schema version. Never raised for cryptographic
    failures -- use :class:`BundleVerificationError` for those.
    """


class BundleVerificationError(ValueError):
    """Bundle signature or AES-GCM authentication tag failed to verify.

    This is the fail-closed signal. The SDK MUST NOT use any policy data
    extracted before this exception was raised.
    """


# --- Constants -------------------------------------------------------------

_MAGIC = b"CZ01"
_HEADER_SIZE = 32
_SIG_LEN = 64
_SCHEMA_VERSION_MAX = 1

# AES-GCM constants. Matches the backend's encryptAESGCM helper:
# nonce(12) || ciphertext || tag(16)
_GCM_NONCE_SIZE = 12
_GCM_TAG_SIZE = 16


# --- Parsed structures -----------------------------------------------------


@dataclass(frozen=True)
class BundleHeader:
    schema_version: int
    created_at: int
    policy_count: int
    sig_offset: int
    sig_len: int


@dataclass(frozen=True)
class ParsedBundle:
    """The decrypted and authenticated policy bundle."""

    header: BundleHeader
    payload: dict  # the JSON-decoded policy bundle


# --- Public API ------------------------------------------------------------


def parse_bundle(
    blob: bytes,
    encryption_key: bytes,
    signing_pubkey: bytes,
    *,
    max_bundle_bytes: int = 16 * 1024 * 1024,
) -> ParsedBundle:
    """Verify signature, decrypt, and decode a policy bundle.

    Args:
        blob: The raw bundle bytes as returned by ``/v1/sdk/policies/pull``.
        encryption_key: 32-byte symmetric key for the project.
        signing_pubkey: 32-byte signing public key for the project.
        max_bundle_bytes: Defensive cap on bundle size. Rejects huge blobs
            before doing any crypto work (default 16 MiB).

    Returns:
        A :class:`ParsedBundle` with the decoded header and payload dict.

    Raises:
        BundleFormatError: if the wire format is malformed.
        BundleVerificationError: if the signature does not verify, or if
            authenticated-encryption tag validation fails.
    """
    if not isinstance(blob, (bytes, bytearray)):
        raise BundleFormatError(
            f"bundle must be bytes, got {type(blob).__name__}"
        )
    blob = bytes(blob)

    if len(blob) > max_bundle_bytes:
        raise BundleFormatError(
            f"bundle size {len(blob)} exceeds max {max_bundle_bytes}"
        )

    header, encrypted_payload, signature = _split_bundle(blob)

    # Signature covers header[0:32] || encrypted_payload. Verify BEFORE
    # decrypt so we never touch ciphertext for an unauthenticated blob.
    if len(signing_pubkey) != 32:
        raise BundleVerificationError(
            f"signing public key must be 32 bytes, got {len(signing_pubkey)}"
        )
    _verify_ed25519(signing_pubkey, blob[:_HEADER_SIZE] + encrypted_payload, signature)

    # Decrypt the payload.
    if len(encryption_key) != 32:
        raise BundleVerificationError(
            f"encryption key must be 32 bytes, got {len(encryption_key)}"
        )
    plaintext_compressed = _decrypt_aes_gcm(encryption_key, encrypted_payload)

    # zstd decompress.
    plaintext_json = _zstd_decompress(plaintext_compressed)

    # Parse JSON.
    try:
        payload = json.loads(plaintext_json.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        # We already verified the signature, so this is either a server
        # bug or a successful decryption of corrupted content. Report as
        # format error so the caller surfaces a clear message.
        raise BundleFormatError(f"payload is not valid JSON: {exc}") from exc

    if not isinstance(payload, dict):
        raise BundleFormatError(
            f"payload root must be an object, got {type(payload).__name__}"
        )

    return ParsedBundle(header=header, payload=payload)


# --- Header / split --------------------------------------------------------


def _split_bundle(blob: bytes) -> tuple[BundleHeader, bytes, bytes]:
    """Validate the header and split the blob into (header, payload, signature)."""
    if len(blob) < _HEADER_SIZE + _SIG_LEN:
        raise BundleFormatError(
            f"bundle too short: {len(blob)} bytes, need at least "
            f"{_HEADER_SIZE + _SIG_LEN}"
        )

    if blob[:4] != _MAGIC:
        raise BundleFormatError(
            f"bad magic: expected CZ01, got {blob[:4]!r}"
        )

    # Parse the fixed-layout header.
    (
        schema_version,
        created_at,
        policy_count,
        sig_offset,
        sig_len,
    ) = struct.unpack_from("<HQHII", blob, 4)

    # The reserved 8 bytes at offset 24 must be zero. This gives us room
    # to extend the header in a backwards-compatible way later.
    reserved = blob[24:32]
    if reserved != b"\x00" * 8:
        raise BundleFormatError(f"reserved bytes must be zero, got {reserved!r}")

    if schema_version < 1 or schema_version > _SCHEMA_VERSION_MAX:
        raise BundleFormatError(
            f"unsupported schema version {schema_version}, this SDK "
            f"supports 1..{_SCHEMA_VERSION_MAX}. Upgrade the SDK."
        )

    if sig_len != _SIG_LEN:
        raise BundleFormatError(
            f"unexpected signature length {sig_len}, want {_SIG_LEN}"
        )

    if sig_offset < _HEADER_SIZE:
        raise BundleFormatError(
            f"sig_offset {sig_offset} must be >= header size {_HEADER_SIZE}"
        )

    if sig_offset + sig_len > len(blob):
        raise BundleFormatError(
            f"signature extends past end of bundle: sig_offset={sig_offset} "
            f"sig_len={sig_len} bundle_len={len(blob)}"
        )

    if sig_offset + sig_len != len(blob):
        # Trailing bytes after the signature are not allowed. This prevents
        # smuggling data past the authenticated region.
        raise BundleFormatError(
            f"trailing bytes after signature: "
            f"sig_offset+sig_len={sig_offset + sig_len} bundle_len={len(blob)}"
        )

    encrypted_payload = blob[_HEADER_SIZE:sig_offset]
    signature = blob[sig_offset : sig_offset + sig_len]

    return (
        BundleHeader(
            schema_version=schema_version,
            created_at=created_at,
            policy_count=policy_count,
            sig_offset=sig_offset,
            sig_len=sig_len,
        ),
        encrypted_payload,
        signature,
    )


# --- Crypto primitives -----------------------------------------------------


def _verify_ed25519(pubkey: bytes, message: bytes, signature: bytes) -> None:
    """Verify a detached signature. Raises BundleVerificationError on failure."""
    try:
        from cryptography.exceptions import InvalidSignature
        from cryptography.hazmat.primitives.asymmetric.ed25519 import (
            Ed25519PublicKey,
        )
    except ImportError as exc:
        # The cryptography package is a hard dependency of the SDK. If it
        # is missing, we cannot verify a bundle and MUST NOT accept it.
        raise BundleVerificationError(
            "cryptography library is not installed; cannot verify bundle"
        ) from exc

    try:
        pk = Ed25519PublicKey.from_public_bytes(pubkey)
        pk.verify(signature, message)
    except InvalidSignature as exc:
        raise BundleVerificationError(
            "signature verification failed: bundle is not authentic"
        ) from exc
    except Exception as exc:  # noqa: BLE001
        raise BundleVerificationError(
            f"signature verification error: {exc}"
        ) from exc


def _decrypt_aes_gcm(key: bytes, encrypted: bytes) -> bytes:
    """Authenticated-encryption decrypt. Expects nonce(12) || ciphertext || tag(16)."""
    try:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    except ImportError as exc:
        raise BundleVerificationError(
            "cryptography library is not installed; cannot decrypt bundle"
        ) from exc

    if len(encrypted) < _GCM_NONCE_SIZE + _GCM_TAG_SIZE:
        raise BundleFormatError(
            f"encrypted payload too short ({len(encrypted)} bytes) to contain "
            f"nonce and tag"
        )

    nonce = encrypted[:_GCM_NONCE_SIZE]
    ciphertext_with_tag = encrypted[_GCM_NONCE_SIZE:]

    try:
        aesgcm = AESGCM(key)
        return aesgcm.decrypt(nonce, ciphertext_with_tag, None)
    except Exception as exc:  # noqa: BLE001
        # Authenticated-encryption tag check failed or key mismatch.
        # Either way, the bundle is not trusted.
        raise BundleVerificationError(
            f"bundle decryption failed: {exc}"
        ) from exc


def _zstd_decompress(data: bytes) -> bytes:
    """Zstd decompress. Tries multiple Python bindings for portability.

    Some backend builds produce zstd frames without the frame content
    size in the header (klauspost/compress EncodeAll variants). In that
    case `zstd.ZstdDecompressor().decompress(data)` raises:

        zstandard.backend_c.ZstdError:
            could not determine content size in frame header

    To decompress regardless of whether the size is declared, we fall
    back to the streaming API with a hard upper bound of 16 MiB --
    matching MAX_BUNDLE_BYTES enforced one layer up. This is the
    standard robust-decompression pattern recommended by the zstandard
    maintainers for untrusted / variable-source input. #113.
    """
    # 16 MiB upper bound on decompressed size; matches
    # hosted_policy.MAX_BUNDLE_BYTES. Kept inline to avoid an import
    # cycle between _internal and hosted_policy.
    _MAX_DECOMPRESSED = 16 * 1024 * 1024

    # Preferred: `zstandard` is the de-facto PyPI package.
    try:
        import io
        import zstandard as zstd

        dctx = zstd.ZstdDecompressor()
        # Streaming read works for frames that lack the declared
        # content size. Cap the output to prevent a zip-bomb class
        # of attack on a tampered bundle.
        with dctx.stream_reader(io.BytesIO(data)) as reader:
            out = reader.read(_MAX_DECOMPRESSED + 1)
        if len(out) > _MAX_DECOMPRESSED:
            raise BundleVerificationError(
                f"zstd decompressed payload exceeds {_MAX_DECOMPRESSED} byte limit"
            )
        return out
    except ImportError:
        pass

    # Fallback: `pyzstd`. Its `decompress()` handles missing content
    # size natively without needing streaming mode.
    try:
        import pyzstd

        return pyzstd.decompress(data)
    except ImportError:
        pass

    raise BundleVerificationError(
        "zstd decompression library not installed; "
        "install with: pip install -U controlzero (or pip install zstandard)"
    )


# --- Schema translation ----------------------------------------------------


def translate_to_local_policy(payload: dict) -> dict:
    """Translate a decrypted bundle payload to the local policy dict shape.

    The bundle's `policies` list comes from the backend in the shape
    produced by :func:`BundleHandler.SDKPull` (Go: bundlePolicy). The
    local :class:`PolicyEvaluator` expects the input format from
    :func:`controlzero.policy_loader.load_policy`: a dict with
    ``version: "1"`` and a flat ``rules`` list where each entry is
    either ``{"deny": "<tool>"}``, ``{"allow": "<tool>"}`` or
    ``{"effect": "<deny|allow|warn|audit>", "action": "<tool>"}``.

    Policies are sorted by ``priority`` ascending so SDKs in every
    language produce identical decisions from identical input.

    Schema 1.1 (#228 Phase 2) adds three top-level enforcement-default
    knobs -- ``default_action``, ``default_on_missing``, and
    ``default_on_tamper`` -- that the translator surfaces into the
    local policy dict's ``settings`` block so downstream
    :func:`controlzero.policy_loader.load_policy` can pick them up
    unchanged. Missing or unknown values fall back to the canonical
    deny/deny/warn (matches pre-1.1 hard-coded behaviour, so old
    bundles keep working).
    """
    # Lazy import to avoid a cycle: enforcer imports from this file
    # via policy_loader via client. Importing at call time breaks the
    # cycle cleanly while still letting translate_to_local_policy own
    # the canonical-default fallback (one source of truth).
    from controlzero._internal.enforcer import (
        DEFAULT_BUNDLE_ACTION,
        DEFAULT_BUNDLE_ON_MISSING,
        DEFAULT_BUNDLE_ON_TAMPER,
        VALID_DEFAULT_ACTIONS,
        VALID_DEFAULT_ON_MISSING,
        VALID_DEFAULT_ON_TAMPER,
    )

    default_action = payload.get("default_action")
    if default_action not in VALID_DEFAULT_ACTIONS:
        default_action = DEFAULT_BUNDLE_ACTION

    default_on_missing = payload.get("default_on_missing")
    if default_on_missing not in VALID_DEFAULT_ON_MISSING:
        default_on_missing = DEFAULT_BUNDLE_ON_MISSING

    default_on_tamper = payload.get("default_on_tamper")
    if default_on_tamper not in VALID_DEFAULT_ON_TAMPER:
        default_on_tamper = DEFAULT_BUNDLE_ON_TAMPER

    policies = payload.get("policies") or []
    policies = sorted(
        [p for p in policies if isinstance(p, dict)],
        key=lambda p: int(p.get("priority", 100)),
    )

    flat: list[dict] = []
    for pol in policies:
        raw_rules = pol.get("rules")
        if isinstance(raw_rules, dict):
            rule_list = list(raw_rules.values())
        elif isinstance(raw_rules, list):
            rule_list = raw_rules
        else:
            continue

        for r in rule_list:
            if not isinstance(r, dict):
                continue
            translated = _translate_rule(r, pol.get("id", ""))
            if translated is not None:
                flat.append(translated)

    if not flat:
        # Empty policy set: synthetic catchall rule. The effect
        # mirrors the bundle-level default_action so "empty bundle"
        # continues to deliver the operator's chosen posture. Prior
        # to #228 Phase 2 this was hard-coded to deny; now an org
        # that ships an empty-bundle-with-default=allow gets the
        # expected allow (with the same NO_ACTIVE_POLICIES
        # reason_code so dashboards still bucket it as "nothing
        # attached").
        #
        # Copy-choice note (2026-04-19, Bryan's P0): the previous
        # message -- "No active policies. Define one in the Control Zero
        # dashboard." -- presumed the user had not defined any policies.
        # That presumption was wrong in the common case: the user had
        # defined several, but the library-attachments state on the
        # backend did not include any active attachment row, so the
        # bundle arrived with zero policies while the dashboard Library
        # tab still showed them. The new wording removes the
        # presumption and points at the actual recovery action.
        flat.append({
            "effect": default_action,
            "action": "*",
            "reason": (
                "No policies are active on this project. If the dashboard "
                "shows attached policies, regenerate the policy bundle."
            ),
            "reason_code": "NO_ACTIVE_POLICIES",
        })

    return {
        "version": "1",
        "rules": flat,
        "settings": {
            "default_action": default_action,
            "default_on_missing": default_on_missing,
            "default_on_tamper": default_on_tamper,
        },
    }


def make_bundle_missing_policy(
    default_on_missing: Optional[str] = None,
) -> dict:
    """Build the synthetic local-policy dict used when the bundle cannot load.

    Returned shape matches what :func:`translate_to_local_policy`
    produces, so downstream :func:`controlzero.policy_loader.load_policy`
    accepts it unchanged.

    Args:
        default_on_missing: Effect to apply -- ``"deny"`` or ``"allow"``.
            ``None`` or an unknown value coerces to the canonical deny
            default, matching the pre-#228 hard-coded behaviour.

    The single catchall rule carries ``reason_code=BUNDLE_MISSING`` so
    audit pipelines can distinguish "no bundle at all" (this path) from
    "bundle loaded but empty" (``NO_ACTIVE_POLICIES``) and from
    "rule set evaluated, nothing matched" (``NO_RULE_MATCH``).
    """
    from controlzero._internal.enforcer import (
        DEFAULT_BUNDLE_ACTION,
        DEFAULT_BUNDLE_ON_MISSING,
        DEFAULT_BUNDLE_ON_TAMPER,
        VALID_DEFAULT_ON_MISSING,
    )

    effect = default_on_missing if default_on_missing in VALID_DEFAULT_ON_MISSING else DEFAULT_BUNDLE_ON_MISSING
    reason = (
        "Policy bundle could not be loaded (never synced, backend "
        "unreachable, or decrypt failed). "
        f"Honoring default_on_missing={effect}."
    )
    return {
        "version": "1",
        "rules": [
            {
                "effect": effect,
                "action": "*",
                "reason": reason,
                "reason_code": "BUNDLE_MISSING",
            }
        ],
        "settings": {
            # Stamp the resolved default triple onto the synthetic
            # policy so downstream code that reads settings sees
            # consistent values. default_action mirrors the missing
            # effect so no-match behaviour is predictable.
            "default_action": effect if effect in {"deny", "allow"} else DEFAULT_BUNDLE_ACTION,
            "default_on_missing": effect,
            "default_on_tamper": DEFAULT_BUNDLE_ON_TAMPER,
        },
    }


def _translate_rule(rule: dict, policy_id: str) -> Optional[dict]:
    """Translate a single backend rule to the local rule shape.

    The backend (:file:`bundle_handler.go` ``PolicyRule``) emits rules
    whose tool pattern lives under plural ``actions: [...]``. This
    function used to ignore that key entirely and fell back to ``"*"``
    for every such rule, causing e.g. a ``deny database:execute`` rule
    to silently become ``deny *`` after round-tripping through the
    bundle. Both the plural (backend wire-format) and the legacy
    singular (``tool`` / ``pattern`` / ``action`` / ``match.tool``) forms
    are now supported; plural wins when both are present.
    """
    # Accept several spellings of "effect". Policy engine has four
    # canonical effects; anything else is treated as ``allow`` to stay
    # fail-safe on forward-compat.
    effect_raw = rule.get("effect")
    if not effect_raw:
        # Only fall back to rule["action"] for effect if it looks like
        # one of the canonical effects. Otherwise "action" is a tool
        # name and we should not use it here.
        fallback = rule.get("action")
        if fallback in ("allow", "deny", "warn", "audit"):
            effect_raw = fallback
    effect = effect_raw if effect_raw in ("allow", "deny", "warn", "audit") else "allow"

    # Tool pattern resolution order:
    #   1. plural ``actions`` (list, as emitted by the backend)
    #   2. legacy singular ``tool`` / ``pattern``
    #   3. legacy singular ``action`` (only if it is NOT an effect keyword)
    #   4. nested ``match.tool`` / ``match.action``
    #   5. default ``"*"`` (universal)
    patterns: list[str] = []
    raw_actions = rule.get("actions")
    if isinstance(raw_actions, list):
        patterns = [str(a) for a in raw_actions if isinstance(a, str) and a]

    if not patterns:
        candidate = rule.get("tool") or rule.get("pattern")
        if candidate:
            patterns = [str(candidate)]

    if not patterns:
        # Legacy singular "action" field -- only a tool pattern when
        # it is NOT a canonical effect name (effect already captured
        # above).
        candidate = rule.get("action")
        if candidate and candidate not in ("allow", "deny", "warn", "audit"):
            patterns = [str(candidate)]

    if not patterns:
        match = rule.get("match")
        if isinstance(match, dict):
            candidate = match.get("tool") or match.get("action")
            if candidate:
                patterns = [str(candidate)]

    if not patterns:
        # Final fallback: universal match. Combined with a non-allow
        # effect, this is still meaningful (e.g. deny-all).
        patterns = ["*"]

    translated: dict = {
        "effect": effect,
        # Emit plural ``actions`` so downstream
        # :func:`controlzero.policy_loader.load_policy` can pass the
        # full list through to :class:`PolicyRule.actions` unchanged.
        # The loader accepts either ``action`` or ``actions``.
        "actions": patterns if len(patterns) > 1 else patterns,
        "reason": rule.get("reason") or f"policy:{policy_id}",
    }
    # Keep the singular ``action`` alias for single-pattern rules so
    # older consumers that read the translated dict (tests, docs) still
    # see a scalar. The loader prefers ``action`` when scalar.
    if len(patterns) == 1:
        translated["action"] = patterns[0]

    resources = rule.get("resources") or rule.get("resource")
    if resources:
        translated["resources"] = resources

    # Propagate the machine-readable reason_code when the source rule
    # carries one. Today only the synthetic empty-bundle deny (above)
    # sets this; user-authored rules are unaffected.
    rc = rule.get("reason_code")
    if isinstance(rc, str) and rc:
        translated["reason_code"] = rc

    return translated
