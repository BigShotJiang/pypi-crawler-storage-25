"""Hosted-mode policy orchestration.

This module glues the pure bundle parser (:mod:`controlzero._internal.bundle`)
to the network (backend endpoints) and to the disk (on-prem cache). It is
the only place in the SDK that talks to the Control Zero API for policy
retrieval.

Flow on ``Client(api_key=...)`` construction:

1. :func:`load_hosted_policy` is invoked.
2. If no bootstrap cached, :func:`fetch_bootstrap` hits
   ``GET /v1/sdk/bootstrap`` to retrieve the project encryption key and
   signing public key. Cached to disk.
3. :func:`pull_bundle` hits ``GET /v1/sdk/policies/pull`` with the cached
   ETag if one exists.
4. On 200: the signed bundle is parsed + verified + decrypted via
   :func:`controlzero._internal.bundle.parse_bundle`. Success path caches
   the bundle bytes.
5. On 304: the cached bundle is parsed + verified using cached keys.
6. On 401: :class:`HostedAuthError` (permanent; user supplied bad key).
7. On any other failure: fall back to cached bundle if present (with a
   warning), otherwise raise :class:`HostedBootstrapError` (fail closed).

Cache layout under ``~/.controlzero/cache/``:

- ``bootstrap-<prefix>.json`` -- JSON dict with keys + metadata
- ``bundle-<prefix>.bin``     -- raw signed bundle bytes
- ``bundle-<prefix>.meta``    -- ETag + checksum for conditional fetches

The ``<prefix>`` is the first 12 characters of the API key. Safe to write
to disk because (a) the prefix is already used in audit logs server-side,
(b) the cache is scoped to the local user's home directory.
"""

from __future__ import annotations

import base64
import hashlib
import json
import logging
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from controlzero._internal.bundle import (
    ParsedBundle,
    parse_bundle,
    translate_to_local_policy,
)
from controlzero.errors import HostedAuthError, HostedBootstrapError

logger = logging.getLogger("controlzero.hosted_policy")

# Default: production SaaS. Override for self-hosted deployments via
# CONTROLZERO_API_URL (e.g. https://api.my-corp.com).
DEFAULT_API_URL = "https://api.controlzero.ai"

# Timeouts. Deliberately short -- the SDK should never block the caller
# for long. On timeout we fall back to the cache.
BOOTSTRAP_TIMEOUT_S = 5.0
PULL_TIMEOUT_S = 5.0

# Defensive cap. Spec says 16 MiB; we stay well under.
MAX_BUNDLE_BYTES = 16 * 1024 * 1024


def get_api_url() -> str:
    """Resolve the Control Zero API base URL."""
    return os.environ.get("CONTROLZERO_API_URL", DEFAULT_API_URL).rstrip("/")


def _cache_dir() -> Path:
    """Resolve the cache directory, creating it if missing."""
    p = Path.home() / ".controlzero" / "cache"
    p.mkdir(parents=True, exist_ok=True)
    return p


def _key_scope(api_key: str) -> str:
    """Return a filename-safe scope identifier for the given API key."""
    if not api_key:
        return "unknown"
    return (api_key[:12]).replace("/", "_").replace(".", "_")


# --- Bootstrap (keys) ------------------------------------------------------


@dataclass
class BootstrapKeys:
    """Project keys returned by ``GET /v1/sdk/bootstrap``."""

    project_id: str
    org_id: str
    encryption_key: bytes  # 32 bytes, decoded from base64
    signing_pubkey: bytes  # 32 bytes, raw
    key_version: int


def _bootstrap_cache_path(api_key: str) -> Path:
    return _cache_dir() / f"bootstrap-{_key_scope(api_key)}.json"


def load_cached_bootstrap(api_key: str) -> Optional[BootstrapKeys]:
    path = _bootstrap_cache_path(api_key)
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return BootstrapKeys(
            project_id=str(data["project_id"]),
            org_id=str(data.get("org_id", "")),
            encryption_key=base64.b64decode(data["project_encryption_key_b64"]),
            signing_pubkey=bytes.fromhex(data["signing_pubkey_hex"]),
            key_version=int(data.get("key_version", 1)),
        )
    except (KeyError, ValueError, OSError) as exc:
        logger.warning("controlzero: invalid cached bootstrap (%s); refetching", exc)
        return None


def save_cached_bootstrap(api_key: str, keys: BootstrapKeys) -> None:
    path = _bootstrap_cache_path(api_key)
    payload = {
        "project_id": keys.project_id,
        "org_id": keys.org_id,
        "project_encryption_key_b64": base64.b64encode(keys.encryption_key).decode("ascii"),
        "signing_pubkey_hex": keys.signing_pubkey.hex(),
        "key_version": keys.key_version,
    }
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def fetch_bootstrap(api_key: str, api_url: Optional[str] = None) -> BootstrapKeys:
    """Call ``GET /v1/sdk/bootstrap`` to retrieve project keys.

    Raises:
        HostedAuthError: 401 or 403 from the backend.
        HostedBootstrapError: any other network or protocol failure.
    """
    try:
        import httpx
    except ImportError as exc:
        raise HostedBootstrapError(
            "httpx is required for hosted mode. Install with: pip install httpx"
        ) from exc

    base = (api_url or get_api_url()).rstrip("/")
    try:
        resp = httpx.get(
            f"{base}/v1/sdk/bootstrap",
            headers={
                "Authorization": f"Bearer {api_key}",
                "Accept": "application/json",
            },
            timeout=BOOTSTRAP_TIMEOUT_S,
        )
    except Exception as exc:  # noqa: BLE001
        raise HostedBootstrapError(
            f"bootstrap request failed: {exc}"
        ) from exc

    if resp.status_code in (401, 403):
        raise HostedAuthError(
            "Control Zero API key rejected by backend. Check that "
            "CONTROLZERO_API_KEY is a valid cz_live_ or cz_test_ project key."
        )
    if resp.status_code >= 400:
        raise HostedBootstrapError(
            f"bootstrap returned HTTP {resp.status_code}: {resp.text[:500]}"
        )

    try:
        data = resp.json()
        return BootstrapKeys(
            project_id=str(data["project_id"]),
            org_id=str(data.get("org_id", "")),
            encryption_key=base64.b64decode(data["project_encryption_key_b64"]),
            signing_pubkey=bytes.fromhex(data["signing_pubkey_hex"]),
            key_version=int(data.get("key_version", 1)),
        )
    except (KeyError, ValueError) as exc:
        raise HostedBootstrapError(
            f"bootstrap response malformed: {exc}"
        ) from exc


def get_or_fetch_bootstrap(
    api_key: str, api_url: Optional[str] = None
) -> BootstrapKeys:
    """Return cached bootstrap keys, fetching from backend if not cached."""
    cached = load_cached_bootstrap(api_key)
    if cached is not None:
        return cached
    keys = fetch_bootstrap(api_key, api_url)
    try:
        save_cached_bootstrap(api_key, keys)
    except OSError as exc:
        logger.warning("controlzero: could not cache bootstrap keys (%s)", exc)
    return keys


# --- Bundle pull ----------------------------------------------------------


@dataclass
class CachedBundle:
    """On-disk cached bundle with metadata for conditional fetches."""

    bytes_: bytes
    etag: str
    checksum: str


def _bundle_cache_paths(api_key: str) -> tuple[Path, Path]:
    scope = _key_scope(api_key)
    bin_path = _cache_dir() / f"bundle-{scope}.bin"
    meta_path = _cache_dir() / f"bundle-{scope}.meta"
    return bin_path, meta_path


def load_cached_bundle(api_key: str) -> Optional[CachedBundle]:
    bin_path, meta_path = _bundle_cache_paths(api_key)
    if not bin_path.exists() or not meta_path.exists():
        return None
    try:
        blob = bin_path.read_bytes()
        meta = json.loads(meta_path.read_text(encoding="utf-8"))
        return CachedBundle(
            bytes_=blob,
            etag=str(meta.get("etag", "")),
            checksum=str(meta.get("checksum", "")),
        )
    except (OSError, ValueError) as exc:
        logger.warning("controlzero: invalid cached bundle (%s); refetching", exc)
        return None


def save_cached_bundle(api_key: str, blob: bytes, etag: str) -> None:
    bin_path, meta_path = _bundle_cache_paths(api_key)
    checksum = hashlib.sha256(blob).hexdigest()
    bin_path.write_bytes(blob)
    meta_path.write_text(
        json.dumps({"etag": etag, "checksum": checksum}, indent=2),
        encoding="utf-8",
    )


def pull_bundle(
    api_key: str,
    api_url: Optional[str] = None,
    cached_etag: Optional[str] = None,
) -> Optional[bytes]:
    """Call ``GET /v1/sdk/policies/pull``.

    Returns:
        The signed bundle bytes on 200.
        ``None`` on 304 (caller should use cached bundle).

    Raises:
        HostedAuthError: 401 / 403.
        HostedBootstrapError: any other network / protocol failure.
    """
    try:
        import httpx
    except ImportError as exc:
        raise HostedBootstrapError(
            "httpx is required for hosted mode. Install with: pip install httpx"
        ) from exc

    base = (api_url or get_api_url()).rstrip("/")
    headers = {"Authorization": f"Bearer {api_key}"}
    if cached_etag:
        headers["If-None-Match"] = cached_etag

    try:
        resp = httpx.get(
            f"{base}/v1/sdk/policies/pull",
            headers=headers,
            timeout=PULL_TIMEOUT_S,
        )
    except Exception as exc:  # noqa: BLE001
        raise HostedBootstrapError(f"bundle pull failed: {exc}") from exc

    if resp.status_code == 304:
        return None
    if resp.status_code in (401, 403):
        raise HostedAuthError(
            "Control Zero API key rejected during bundle pull."
        )
    if resp.status_code >= 400:
        raise HostedBootstrapError(
            f"bundle pull returned HTTP {resp.status_code}: {resp.text[:500]}"
        )

    return resp.content


# --- Orchestration --------------------------------------------------------


def load_hosted_policy(
    api_key: str,
    api_url: Optional[str] = None,
) -> tuple[dict, ParsedBundle]:
    """Fetch + verify + decrypt + translate the project's active policy.

    Returns a pair ``(local_policy_dict, parsed_bundle)``. The local
    policy dict is what :func:`controlzero.policy_loader.load_policy`
    consumes. The parsed bundle is kept so the caller can surface metadata
    (version, created_at) if desired.

    Raises:
        HostedAuthError: permanent auth failure. Do not retry.
        HostedBootstrapError: backend unreachable and no cache available.
        BundleFormatError / BundleVerificationError: signature or format
            problems -- same fail-closed meaning as a bad network state.
    """
    base = api_url or get_api_url()

    # Step 1: bootstrap keys. Cached indefinitely; refetched only on
    # verification failure (handled below).
    keys = get_or_fetch_bootstrap(api_key, base)

    # Step 2: attempt conditional bundle pull.
    cached = load_cached_bundle(api_key)
    cached_etag = cached.etag if cached else None

    try:
        blob = pull_bundle(api_key, base, cached_etag=cached_etag)
    except HostedAuthError:
        # Never fall back to cache on auth error. User must fix the key.
        raise
    except HostedBootstrapError as exc:
        # Transient: use cache if present.
        if cached is not None:
            logger.warning(
                "controlzero: policy pull failed (%s), using cached bundle; "
                "calls will be enforced against the last-known-good policy",
                exc,
            )
            return _parse_and_translate(cached.bytes_, keys, api_key, base)
        raise

    if blob is None:
        # 304 Not Modified. We must have a cached bundle -- if not, the
        # backend and our cache disagree and we fail closed.
        if cached is None:
            raise HostedBootstrapError(
                "backend returned 304 but no cached bundle is available; "
                "retry without cache"
            )
        return _parse_and_translate(cached.bytes_, keys, api_key, base)

    # Fresh bundle. Parse + verify with cached keys first. If that fails,
    # re-fetch keys once (possible rotation) and retry. On second failure,
    # fail closed.
    try:
        parsed = parse_bundle(blob, keys.encryption_key, keys.signing_pubkey,
                              max_bundle_bytes=MAX_BUNDLE_BYTES)
    except Exception:
        logger.warning(
            "controlzero: bundle verification failed with cached keys; "
            "re-fetching bootstrap in case of key rotation"
        )
        fresh_keys = fetch_bootstrap(api_key, base)
        # Persist the new keys even if the retry fails -- they are still
        # the latest known.
        try:
            save_cached_bootstrap(api_key, fresh_keys)
        except OSError:
            pass
        parsed = parse_bundle(blob, fresh_keys.encryption_key, fresh_keys.signing_pubkey,
                              max_bundle_bytes=MAX_BUNDLE_BYTES)
        keys = fresh_keys

    # Cache the bundle for next time. Use the response's ETag header if
    # available, else the content checksum.
    etag = _compute_etag(blob)
    try:
        save_cached_bundle(api_key, blob, etag)
    except OSError as exc:
        logger.warning("controlzero: could not cache bundle (%s)", exc)

    return translate_to_local_policy(parsed.payload), parsed


def _parse_and_translate(
    blob: bytes, keys: BootstrapKeys, api_key: str, api_url: str
) -> tuple[dict, ParsedBundle]:
    """Helper: parse a cached bundle, re-fetch keys once on failure."""
    try:
        parsed = parse_bundle(
            blob, keys.encryption_key, keys.signing_pubkey,
            max_bundle_bytes=MAX_BUNDLE_BYTES,
        )
    except Exception:
        fresh = fetch_bootstrap(api_key, api_url)
        try:
            save_cached_bootstrap(api_key, fresh)
        except OSError:
            pass
        parsed = parse_bundle(
            blob, fresh.encryption_key, fresh.signing_pubkey,
            max_bundle_bytes=MAX_BUNDLE_BYTES,
        )
    return translate_to_local_policy(parsed.payload), parsed


def _compute_etag(blob: bytes) -> str:
    """Fallback ETag when the server doesn't provide one.

    Returns the full 64-char hex sha256 of the bundle blob. The backend
    stores and serves the full hex string in its ETag header, so the
    SDK must hash to the same width for `If-None-Match` to ever match.
    Truncating to 32 chars (the prior shape) silently broke the 304
    short-circuit, surfacing as Bryan's investigation finding 1 in
    docs/investigations/bryan-db-read-only-fail-closed-2026-05-08.md.
    """
    return hashlib.sha256(blob).hexdigest()
