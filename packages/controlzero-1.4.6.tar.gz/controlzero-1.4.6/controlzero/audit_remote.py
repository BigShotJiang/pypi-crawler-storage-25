"""Remote audit sink -- batches local audit entries and POSTs them to the backend.

When an enrolled SDK evaluates a tool call, the decision is written to the local
audit log first (fire-and-forget). This module buffers those entries and
periodically flushes them to ``POST /api/audit`` on the backend so the
governance admin dashboard shows real data from CLI hooks (Claude Code,
Gemini CLI, Codex CLI, etc.).

Design constraints:
  - NEVER block or crash the hook-check critical path. Local audit is
    always written first; remote is best-effort.
  - Thread-safe: multiple guard() calls from different threads share
    one buffer protected by a lock.
  - Flush runs in a daemon thread so shutdown of the main process is
    not blocked by a slow network.
  - On 401 the sink disables itself (enrollment expired).
  - On transient errors the buffer is retained for the next flush cycle.
"""

from __future__ import annotations

import getpass
import json
import logging
import platform
import threading
import time
import uuid
from datetime import datetime, timezone
from typing import Optional

from controlzero.device import detect_client_name, detect_client_version

logger = logging.getLogger("controlzero.audit_remote")

# Buffer limits
MAX_BUFFER_SIZE = 50
FLUSH_INTERVAL_S = 30.0
FLUSH_TIMEOUT_S = 2.0


class RemoteAuditSink:
    """Buffers audit entries and flushes them to the backend in batches."""

    def __init__(
        self,
        api_url: str,
        machine_token: str,  # not used for auth header, kept for future
        org_id: str,
        machine_id: str,
        state_dir: Optional["Path"] = None,
    ):
        self._api_url = api_url.rstrip("/")
        self._machine_token = machine_token
        self._org_id = org_id
        self._machine_id = machine_id
        self._state_dir = state_dir

        self._buffer: list[dict] = []
        self._lock = threading.Lock()
        self._disabled = False
        self._closed = False

        # Start the periodic flush timer
        self._start_flush_timer()

    # ---- public API ----

    def log(self, entry: dict) -> None:
        """Append an audit entry to the buffer. Triggers flush if buffer is full."""
        if self._disabled or self._closed:
            return
        with self._lock:
            self._buffer.append(self._to_wire_format(entry))
            should_flush = len(self._buffer) >= MAX_BUFFER_SIZE
        if should_flush:
            self._flush_async()

    def close(self) -> None:
        """Final flush on shutdown. Blocks briefly to drain the buffer."""
        if self._closed:
            return
        self._closed = True
        self._cancel_flush_timer()
        # Synchronous flush -- we are shutting down
        self._flush_sync()

    # ---- wire format mapping ----

    def _to_wire_format(self, entry: dict) -> dict:
        """Map from the local audit entry shape to the backend wire format.

        Backend expects (from audit_ingest_handler.go AuditIngestEntry):
          id, user, tool_name, decision, policy_id, rule_id, reason,
          hostname, mode, ts, verbosity_level
        """
        hostname = platform.node() or "unknown"
        user = ""
        try:
            user = getpass.getuser()
        except Exception:
            pass

        # Resolve user_email from enrollment state if available
        user_email = ""
        try:
            from controlzero.enrollment import load_state
            state = load_state(self._state_dir) if self._state_dir else load_state()
            if state and hasattr(state, "hostname"):
                # enrollment state exists; user_email may be stored in the
                # state dir's enrollment.json but is not on EnrollmentState
                # dataclass yet -- fall back to empty.
                pass
        except Exception:
            pass

        return {
            "id": str(uuid.uuid4()),
            "tool_name": entry.get("tool", ""),
            "decision": entry.get("decision", "allow"),
            "policy_id": entry.get("policy_id", ""),
            "rule_id": entry.get("policy_id", ""),  # local entries use policy_id as rule_id
            "reason": entry.get("reason", ""),
            "hostname": hostname,
            "user": user,
            "mode": entry.get("mode", "local"),
            "ts": datetime.now(timezone.utc).isoformat(),
            "client_name": detect_client_name(),
            "client_version": detect_client_version(),
            "user_email": user_email,
            # Phase 3 of #228 (T4d column). Populated only on
            # coding-agent hook-check calls; SDK library integrations
            # pass an empty string until they adopt the same extractor.
            "extracted_method": entry.get("extracted_method", ""),
        }

    # ---- flush mechanics ----

    def _flush_async(self) -> None:
        """Run flush in a daemon thread so it never blocks the caller."""
        t = threading.Thread(target=self._flush_sync, daemon=True)
        t.start()

    def _flush_sync(self) -> None:
        """POST buffered entries to the backend. On success, clear buffer."""
        with self._lock:
            if not self._buffer or self._disabled:
                return
            batch = list(self._buffer)

        try:
            self._post_batch(batch)
            # Success: remove the flushed entries from the buffer
            with self._lock:
                # Only remove the entries we successfully sent; new entries
                # may have been appended while we were posting.
                self._buffer = self._buffer[len(batch):]
        except _AuthExpiredError:
            logger.warning(
                "controlzero: remote audit sink disabled -- enrollment expired (401)"
            )
            with self._lock:
                self._disabled = True
                self._buffer.clear()
        except Exception as exc:
            # Transient error: keep entries in buffer for next flush
            logger.warning(
                "controlzero: remote audit flush failed (%s); "
                "entries retained for retry",
                exc,
            )

    def _post_batch(self, batch: list[dict]) -> None:
        """Send a batch of entries to POST /api/audit with signed headers."""
        try:
            from controlzero.enrollment import load_state, sign_request
        except ImportError:
            # enrollment module not available -- cannot send
            raise _AuthExpiredError("enrollment module not available")

        state = load_state(self._state_dir) if self._state_dir else load_state()
        if state is None:
            raise _AuthExpiredError("no enrollment state")

        body = json.dumps({"entries": batch}).encode("utf-8")
        state_dir_kwarg = {"state_dir": self._state_dir} if self._state_dir else {}
        headers = sign_request(state, "POST", "/api/audit", body, **state_dir_kwarg)
        headers["Content-Type"] = "application/json"

        try:
            import httpx
        except ImportError:
            raise _AuthExpiredError("httpx not available")

        resp = httpx.post(
            f"{self._api_url}/api/audit",
            content=body,
            headers=headers,
            timeout=FLUSH_TIMEOUT_S,
        )
        if resp.status_code == 401:
            raise _AuthExpiredError("server returned 401")
        if resp.status_code >= 400:
            raise RuntimeError(
                f"audit ingest returned HTTP {resp.status_code}: {resp.text}"
            )

    # ---- periodic timer ----

    def _start_flush_timer(self) -> None:
        """Schedule the next periodic flush."""
        if self._closed or self._disabled:
            return
        self._timer = threading.Timer(FLUSH_INTERVAL_S, self._on_timer)
        self._timer.daemon = True
        self._timer.start()

    def _cancel_flush_timer(self) -> None:
        timer = getattr(self, "_timer", None)
        if timer is not None:
            timer.cancel()

    def _on_timer(self) -> None:
        """Called by the periodic timer. Flush and reschedule."""
        if self._closed or self._disabled:
            return
        self._flush_sync()
        self._start_flush_timer()

    # ---- properties for testing ----

    @property
    def disabled(self) -> bool:
        return self._disabled

    @property
    def buffer(self) -> list[dict]:
        with self._lock:
            return list(self._buffer)


class BearerAuditSink:
    """Hosted-mode audit sink using Bearer API key auth.

    Unlike :class:`RemoteAuditSink` (which requires enrollment state and
    per-request signed headers), this sink authenticates with the project
    API key and posts to ``POST /v1/sdk/audit``. It is the sink used by
    :class:`Client` when constructed with ``api_key=...`` and no local
    enrollment state.

    Thread-safe, daemon-thread flush, buffer retention on transient errors
    -- same envelope as :class:`RemoteAuditSink`. On 401 the sink disables
    itself (API key revoked or invalid) so a bad key does not produce a
    storm of failing requests.
    """

    def __init__(self, api_url: str, api_key: str):
        self._api_url = api_url.rstrip("/")
        self._api_key = api_key

        self._buffer: list[dict] = []
        self._lock = threading.Lock()
        self._disabled = False
        self._closed = False

        self._start_flush_timer()

    def log(self, entry: dict) -> None:
        if self._disabled or self._closed:
            return
        with self._lock:
            self._buffer.append(self._to_wire_format(entry))
            should_flush = len(self._buffer) >= MAX_BUFFER_SIZE
        if should_flush:
            self._flush_async()

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        self._cancel_flush_timer()
        self._flush_sync()

    def _to_wire_format(self, entry: dict) -> dict:
        hostname = platform.node() or "unknown"
        user = ""
        try:
            user = getpass.getuser()
        except Exception:  # noqa: BLE001
            pass
        return {
            "id": str(uuid.uuid4()),
            "tool_name": entry.get("tool", ""),
            "decision": entry.get("decision", "allow"),
            "policy_id": entry.get("policy_id", ""),
            "rule_id": entry.get("policy_id", ""),
            "reason": entry.get("reason", ""),
            "hostname": hostname,
            "user": user,
            "mode": entry.get("mode", "hosted"),
            "ts": datetime.now(timezone.utc).isoformat(),
            "client_name": detect_client_name(),
            "client_version": detect_client_version(),
            "user_email": "",
            # Phase 3 of #228 (T4d column). Populated only on
            # coding-agent hook-check calls; SDK library integrations
            # pass an empty string until they adopt the same extractor.
            "extracted_method": entry.get("extracted_method", ""),
        }

    def _flush_async(self) -> None:
        t = threading.Thread(target=self._flush_sync, daemon=True)
        t.start()

    def _flush_sync(self) -> None:
        with self._lock:
            if not self._buffer or self._disabled:
                return
            batch = list(self._buffer)
        try:
            self._post_batch(batch)
            with self._lock:
                self._buffer = self._buffer[len(batch):]
        except _AuthExpiredError:
            logger.warning(
                "controlzero: bearer audit sink disabled (API key rejected 401). "
                "Check that CONTROLZERO_API_KEY is a valid cz_live_ or cz_test_ key."
            )
            with self._lock:
                self._disabled = True
                self._buffer.clear()
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "controlzero: bearer audit flush failed (%s); "
                "entries retained for retry",
                exc,
            )

    def _post_batch(self, batch: list[dict]) -> None:
        try:
            import httpx
        except ImportError as exc:
            raise RuntimeError(
                "httpx required for hosted mode. Install with: pip install httpx"
            ) from exc

        body = json.dumps({"entries": batch}).encode("utf-8")
        headers = {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
        }
        resp = httpx.post(
            f"{self._api_url}/v1/sdk/audit",
            content=body,
            headers=headers,
            timeout=FLUSH_TIMEOUT_S,
        )
        if resp.status_code == 401:
            raise _AuthExpiredError("server returned 401")
        if resp.status_code >= 400:
            raise RuntimeError(
                f"audit ingest returned HTTP {resp.status_code}: {resp.text}"
            )

    def _start_flush_timer(self) -> None:
        if self._closed or self._disabled:
            return
        self._timer = threading.Timer(FLUSH_INTERVAL_S, self._on_timer)
        self._timer.daemon = True
        self._timer.start()

    def _cancel_flush_timer(self) -> None:
        timer = getattr(self, "_timer", None)
        if timer is not None:
            timer.cancel()

    def _on_timer(self) -> None:
        if self._closed or self._disabled:
            return
        self._flush_sync()
        self._start_flush_timer()

    @property
    def disabled(self) -> bool:
        return self._disabled

    @property
    def buffer(self) -> list[dict]:
        with self._lock:
            return list(self._buffer)


class _AuthExpiredError(Exception):
    """Internal: signals the remote sink should be permanently disabled."""
