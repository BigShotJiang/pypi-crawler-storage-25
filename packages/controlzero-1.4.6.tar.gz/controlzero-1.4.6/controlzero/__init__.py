"""ControlZero: AI agent governance, policies, and audit. Works locally with no signup.

Hello World:

    from controlzero import Client

    cz = Client(policy={
        "rules": [
            {"deny":  "delete_*", "reason": "Hello World: deletes are blocked"},
            {"allow": "*",        "reason": "Hello World: everything else is fine"},
        ]
    })

    print(cz.guard("delete_file", {"path": "/tmp/foo"}).decision)  # "deny"
    print(cz.guard("read_file",   {"path": "/tmp/foo"}).decision)  # "allow"

10 lines, no API key, no signup. See https://docs.controlzero.ai/sdk/integrations
for framework examples (LangChain, LangGraph, OpenAI Agents, Anthropic, CrewAI,
AutoGen, Pydantic AI, MCP servers, and more).
"""

from controlzero.client import Client
from controlzero.errors import (
    PolicyDecision,
    PolicyDeniedError,
    PolicyLoadError,
    PolicyValidationError,
)
from controlzero.policy_loader import load_policy

__version__ = "1.4.6"

__all__ = [
    "Client",
    "PolicyDecision",
    "PolicyDeniedError",
    "PolicyLoadError",
    "PolicyValidationError",
    "load_policy",
    "__version__",
]
