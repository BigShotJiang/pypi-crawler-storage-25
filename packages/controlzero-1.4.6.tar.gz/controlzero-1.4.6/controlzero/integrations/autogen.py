"""Control Zero integration for AutoGen v0.4+ (autogen-agentchat).

Compatible with autogen-agentchat >=0.7.0, tested against 0.7.5.

Provides a ``governed_tool`` decorator for standalone AutoGen tool
functions, and a ``GovernedAssistantAgent`` subclass that auto-wraps
every tool passed into it.

Usage::

    from autogen_agentchat.agents import AssistantAgent
    from controlzero import Client
    from controlzero.integrations.autogen import (
        governed_tool,
        GovernedAssistantAgent,
    )

    cz = Client(api_key="cz_live_...")

    @governed_tool(cz, "search_web", agent_id="researcher")
    async def search_web(query: str) -> str:
        return do_search(query)

    agent = GovernedAssistantAgent(
        name="researcher",
        model_client=model_client,
        tools=[search_web],
        client=cz,
        agent_id="researcher",
    )
"""

from __future__ import annotations

import functools
from typing import Any, Callable, Iterable, Optional

from controlzero.client import Client


def governed_tool(
    cz: Client,
    tool_name: str,
    method: str = "call",
    agent_id: str = "",
) -> Callable:
    """Decorate an async tool function with Control Zero policy enforcement.

    Args:
        cz: The ``controlzero.Client`` instance.
        tool_name: Logical tool name used for the guard action.
        method: Method name for the guard action. Defaults to ``"call"``.
        agent_id: Optional tag on the audit entry.

    Returns:
        A decorator that wraps an async function. On invocation the wrapped
        function calls ``cz.guard(...)`` with ``raise_on_deny=True`` and then
        awaits the original function.
    """
    def decorator(fn: Callable) -> Callable:
        @functools.wraps(fn)
        async def wrapped(*args: Any, **kwargs: Any) -> Any:
            cz.guard(
                tool_name,
                method=method,
                args={"args": list(args), "kwargs": kwargs},
                context={
                    "tags": {
                        "agent_id": agent_id,
                        "framework": "autogen",
                    },
                },
                raise_on_deny=True,
            )
            return await fn(*args, **kwargs)

        return wrapped

    return decorator


class GovernedAssistantAgent:
    """Subclass of ``autogen_agentchat.agents.AssistantAgent`` that auto-wraps tools.

    Every tool passed via ``tools=[...]`` is transparently wrapped in a
    ``governed_tool`` decorator so the policy is evaluated before the tool
    runs.

    The import of ``autogen_agentchat`` is deferred to instantiation time so
    that merely importing this module does not require the optional
    dependency.
    """

    def __new__(
        cls,
        name: str,
        model_client: Any,
        tools: Optional[Iterable[Callable]] = None,
        client: Optional[Client] = None,
        agent_id: str = "",
        **kwargs: Any,
    ) -> Any:
        try:
            from autogen_agentchat.agents import AssistantAgent
        except ImportError as exc:
            raise ImportError(
                "The 'autogen-agentchat' package is required for this integration. "
                "Install it with: pip install autogen-agentchat"
            ) from exc

        if client is None:
            raise ValueError("GovernedAssistantAgent requires a 'client' argument.")

        wrapped_tools: list[Callable] = []
        if tools:
            for tool in tools:
                tool_name = getattr(tool, "__name__", None) or getattr(
                    tool, "name", "tool"
                )
                # Only wrap async callables; if something is already wrapped
                # (a decorator already applied), it is idempotent because
                # guard() is cheap.
                wrapped = governed_tool(
                    client,
                    tool_name=tool_name,
                    method="call",
                    agent_id=agent_id,
                )(tool)
                # Preserve name/description attributes AutoGen might inspect.
                for attr in ("name", "description"):
                    if hasattr(tool, attr):
                        try:
                            setattr(wrapped, attr, getattr(tool, attr))
                        except Exception:
                            pass
                wrapped_tools.append(wrapped)

        # Instantiate the real AssistantAgent with the wrapped tools.
        return AssistantAgent(
            name=name,
            model_client=model_client,
            tools=wrapped_tools or None,
            **kwargs,
        )
