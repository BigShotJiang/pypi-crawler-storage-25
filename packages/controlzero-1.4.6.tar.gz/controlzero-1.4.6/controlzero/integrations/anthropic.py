"""Anthropic SDK integration for ControlZero.

Provides ``wrap_anthropic()`` which transparently intercepts
``client.messages.create()`` and ``client.messages.stream()``
to enforce governance policies before the request reaches Anthropic.

All other client methods pass through unchanged.

Usage::

    from controlzero import Client
    from controlzero.integrations.anthropic import wrap_anthropic
    import anthropic

    cz = Client(policy={"rules": [{"deny": "delete_*"}]})
    client = wrap_anthropic(anthropic.Anthropic(), cz)

    # Policy enforcement happens automatically
    response = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=1024,
        messages=[{"role": "user", "content": "Hello"}],
    )
"""

from __future__ import annotations

import time
from typing import Any

try:
    import anthropic as _anthropic  # noqa: F401
except ImportError:
    raise ImportError(
        "The 'anthropic' package is required for this integration. "
        "Install it with: pip install anthropic"
    )

from controlzero.client import Client


def _estimate_cost(model: str, input_tokens: int, output_tokens: int) -> float:
    """Rough cost estimate fallback (USD per token)."""
    return (input_tokens + output_tokens) / 1_000_000 * 1.0


class _WrappedMessages:
    """Proxy for ``client.messages`` that enforces policy on create() and stream()."""

    __slots__ = ("_inner", "_cz", "_agent_id")

    def __init__(
        self,
        inner: Any,
        cz: Client,
        agent_id: str,
    ) -> None:
        self._inner = inner
        self._cz = cz
        self._agent_id = agent_id

    def _enforce_model(self, kwargs: dict, method: str) -> None:
        """Enforce policy for a messages API call."""
        model = kwargs.get("model", "unknown")
        tags: dict[str, Any] = {
            "provider": "anthropic",
            "agent_id": self._agent_id,
            "action_detail": method,
        }
        tools = kwargs.get("tools")
        if tools:
            tags["tool_count"] = len(tools)
            tags["tool_names"] = [
                t.get("name", "") for t in tools if isinstance(t, dict)
            ]
        self._cz.guard(
            "llm",
            method="generate",
            raise_on_deny=True,
            context={
                "resource": f"model/{model}",
                "tags": tags,
            },
        )

    def create(self, **kwargs: Any) -> Any:
        """Enforce policy then delegate to the original create()."""
        model = kwargs.get("model", "unknown")
        self._enforce_model(kwargs, "messages.create")  # action_detail tag

        start = time.perf_counter()
        response = self._inner.create(**kwargs)
        latency_ms = int((time.perf_counter() - start) * 1000)

        # Capture token usage from the response
        input_tokens = 0
        output_tokens = 0
        if hasattr(response, "usage") and response.usage is not None:
            input_tokens = getattr(response.usage, "input_tokens", 0) or 0
            output_tokens = getattr(response.usage, "output_tokens", 0) or 0

        # Audit the successful call
        try:
            from controlzero._internal.enforcer import PolicyDecision
            decision = PolicyDecision(
                effect="allow",
                reason="guard passed",
            )
            self._cz._audit_decision(
                tool="llm",
                method="generate",
                args={
                    "model": model,
                    "input_tokens": input_tokens,
                    "output_tokens": output_tokens,
                    "latency_ms": latency_ms,
                },
                decision=decision,
                context={
                    "tags": {
                        "provider": "anthropic",
                        "agent_id": self._agent_id,
                        "action_detail": "messages.create",
                    },
                },
            )
        except Exception:
            pass

        return response

    def stream(self, **kwargs: Any) -> Any:
        """Enforce policy then delegate to the original stream()."""
        self._enforce_model(kwargs, "messages.stream")
        return self._inner.stream(**kwargs)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._inner, name)


class _WrappedAnthropic:
    """Proxy for ``anthropic.Anthropic`` that wraps the messages resource."""

    __slots__ = ("_inner", "_messages")

    def __init__(
        self,
        inner: Any,
        cz: Client,
        agent_id: str,
    ) -> None:
        self._inner = inner
        self._messages = _WrappedMessages(inner.messages, cz, agent_id)

    @property
    def messages(self) -> _WrappedMessages:
        return self._messages

    def __getattr__(self, name: str) -> Any:
        return getattr(self._inner, name)


def wrap_anthropic(
    client: Any,
    cz: Client,
    agent_id: str = "",
) -> Any:
    """Wrap an Anthropic client with ControlZero policy enforcement.

    Returns a proxy object that intercepts ``messages.create()`` and
    ``messages.stream()`` to enforce governance policies. All other
    client methods and properties pass through unchanged.

    Args:
        client: An ``anthropic.Anthropic()`` instance.
        cz: A ``controlzero.Client`` instance with a policy loaded.
        agent_id: Optional identifier for the agent making requests.
            Included in the enforcement context for audit logging.

    Returns:
        A wrapped client with transparent policy enforcement.

    Example::

        from controlzero import Client
        from controlzero.integrations.anthropic import wrap_anthropic
        import anthropic

        cz = Client(policy={"rules": [{"allow": "*"}]})
        client = wrap_anthropic(anthropic.Anthropic(), cz, agent_id="my-agent")

        response = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=1024,
            messages=[{"role": "user", "content": "Hello"}],
        )
    """
    return _WrappedAnthropic(client, cz, agent_id)
