"""OpenAI SDK integration for ControlZero.

Provides ``wrap_openai()`` which transparently intercepts
``client.chat.completions.create()`` and ``client.embeddings.create()``
to enforce governance policies before the request reaches OpenAI.

All other client methods pass through unchanged.

Usage::

    from controlzero import Client
    from controlzero.integrations.openai import wrap_openai
    import openai

    cz = Client(policy={"rules": [{"allow": "*"}]})
    client = wrap_openai(openai.OpenAI(), cz)

    # Policy enforcement happens automatically
    response = client.chat.completions.create(
        model="gpt-4",
        messages=[{"role": "user", "content": "Hello"}],
    )
"""

from __future__ import annotations

import time
from typing import Any

try:
    import openai as _openai  # noqa: F401
except ImportError:
    raise ImportError(
        "The 'openai' package is required for this integration. "
        "Install it with: pip install openai"
    )

from controlzero.client import Client
from controlzero._internal.enforcer import PolicyDecision


class _WrappedCompletions:
    """Proxy for ``client.chat.completions`` that enforces policy on create()."""

    __slots__ = ("_inner", "_cz", "_agent_id")

    def __init__(
        self,
        inner: Any,
        cz: Client,
        agent_id: str,
    ) -> None:
        self._inner = inner
        self._cz = cz
        self._agent_id = agent_id

    def create(self, **kwargs: Any) -> Any:
        """Enforce policy then delegate to the original create()."""
        model = kwargs.get("model", "unknown")
        self._cz.guard(
            "llm",
            method="generate",
            raise_on_deny=True,
            context={
                "resource": f"model/{model}",
                "tags": {
                    "provider": "openai",
                    "agent_id": self._agent_id,
                    "action_detail": "chat.completions.create",
                },
            },
        )
        start = time.perf_counter()
        response = self._inner.create(**kwargs)
        latency_ms = int((time.perf_counter() - start) * 1000)

        # Capture token usage
        input_tokens = 0
        output_tokens = 0
        if hasattr(response, "usage") and response.usage is not None:
            input_tokens = getattr(response.usage, "prompt_tokens", 0) or 0
            output_tokens = getattr(response.usage, "completion_tokens", 0) or 0

        try:
            decision = PolicyDecision(effect="allow", reason="guard passed")
            self._cz._audit_decision(
                tool="llm",
                method="generate",
                args={
                    "model": model,
                    "input_tokens": input_tokens,
                    "output_tokens": output_tokens,
                    "latency_ms": latency_ms,
                },
                decision=decision,
                context={
                    "tags": {
                        "provider": "openai",
                        "agent_id": self._agent_id,
                        "action_detail": "chat.completions.create",
                    },
                },
            )
        except Exception:
            pass

        return response

    def __getattr__(self, name: str) -> Any:
        return getattr(self._inner, name)


class _WrappedChat:
    """Proxy for ``client.chat`` that returns wrapped completions."""

    __slots__ = ("_inner", "_completions")

    def __init__(
        self,
        inner: Any,
        cz: Client,
        agent_id: str,
    ) -> None:
        self._inner = inner
        self._completions = _WrappedCompletions(
            inner.completions, cz, agent_id
        )

    @property
    def completions(self) -> _WrappedCompletions:
        return self._completions

    def __getattr__(self, name: str) -> Any:
        return getattr(self._inner, name)


class _WrappedEmbeddings:
    """Proxy for ``client.embeddings`` that enforces policy on create()."""

    __slots__ = ("_inner", "_cz", "_agent_id")

    def __init__(
        self,
        inner: Any,
        cz: Client,
        agent_id: str,
    ) -> None:
        self._inner = inner
        self._cz = cz
        self._agent_id = agent_id

    def create(self, **kwargs: Any) -> Any:
        """Enforce policy then delegate to the original create()."""
        model = kwargs.get("model", "unknown")
        self._cz.guard(
            "embedding",
            method="generate",
            raise_on_deny=True,
            context={
                "resource": f"model/{model}",
                "tags": {
                    "provider": "openai",
                    "agent_id": self._agent_id,
                    "action_detail": "embeddings.create",
                },
            },
        )
        return self._inner.create(**kwargs)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._inner, name)


class _WrappedOpenAI:
    """Proxy for ``openai.OpenAI`` that wraps chat and embeddings."""

    __slots__ = ("_inner", "_chat", "_embeddings")

    def __init__(
        self,
        inner: Any,
        cz: Client,
        agent_id: str,
    ) -> None:
        self._inner = inner
        self._chat = _WrappedChat(inner.chat, cz, agent_id)
        self._embeddings = _WrappedEmbeddings(
            inner.embeddings, cz, agent_id
        )

    @property
    def chat(self) -> _WrappedChat:
        return self._chat

    @property
    def embeddings(self) -> _WrappedEmbeddings:
        return self._embeddings

    def __getattr__(self, name: str) -> Any:
        return getattr(self._inner, name)


def wrap_openai(
    client: Any,
    cz: Client,
    agent_id: str = "",
) -> Any:
    """Wrap an OpenAI client with ControlZero policy enforcement.

    Returns a proxy object that intercepts ``chat.completions.create()``
    and ``embeddings.create()`` to enforce governance policies. All
    other client methods and properties pass through unchanged.

    Args:
        client: An ``openai.OpenAI()`` instance (or any OpenAI-compatible
            client such as one pointed at OpenRouter or Azure).
        cz: A ``controlzero.Client`` instance with a policy loaded.
        agent_id: Optional identifier for the agent making requests.
            Included in the enforcement context for audit logging.

    Returns:
        A wrapped client with transparent policy enforcement.

    Example::

        from controlzero import Client
        from controlzero.integrations.openai import wrap_openai
        import openai

        cz = Client(policy={"rules": [{"allow": "*"}]})
        client = wrap_openai(openai.OpenAI(), cz, agent_id="my-agent")

        response = client.chat.completions.create(
            model="gpt-4",
            messages=[{"role": "user", "content": "Hello"}],
        )
    """
    return _WrappedOpenAI(client, cz, agent_id)
