"""Control Zero integration for PydanticAI v1.x.

Compatible with pydantic-ai >=1.0.0, tested against 1.74.x.

NOTE: PydanticAI v1.x renamed ``result_type`` -> ``output_type`` and
``result.data`` -> ``result.output``. Examples below use the v1.x names.

Provides a ``governed_tool`` decorator for standalone tool functions and
a ``GovernedAgent`` proxy that wraps an entire ``pydantic_ai.Agent`` and
guards each ``.run()`` / ``.run_sync()`` call.

Usage::

    from pydantic_ai import Agent
    from controlzero import Client
    from controlzero.integrations.pydantic_ai import (
        governed_tool,
        GovernedAgent,
    )

    cz = Client(api_key="cz_live_...")
    base = Agent("openai:gpt-5.4", output_type=str)

    agent = GovernedAgent(base, client=cz, agent_id="my-agent")
    result = await agent.run("Tell me a joke")
    print(result.output)
"""

from __future__ import annotations

import functools
from typing import Any, Callable, Optional

from controlzero.client import Client
from controlzero._internal.enforcer import PolicyDecision


def governed_tool(
    cz: Client,
    tool_name: str,
    method: str = "call",
    agent_id: str = "",
) -> Callable:
    """Decorate an async tool function with Control Zero policy enforcement.

    Works for any async callable you would register with ``Agent.tool`` or
    ``@agent.tool``.
    """
    def decorator(fn: Callable) -> Callable:
        @functools.wraps(fn)
        async def wrapped(*args: Any, **kwargs: Any) -> Any:
            cz.guard(
                tool_name,
                method=method,
                args={"args": list(args), "kwargs": kwargs},
                context={
                    "tags": {
                        "agent_id": agent_id,
                        "framework": "pydantic_ai",
                    },
                },
                raise_on_deny=True,
            )
            return await fn(*args, **kwargs)

        return wrapped

    return decorator


class GovernedAgent:
    """Proxy around a ``pydantic_ai.Agent`` that guards ``run`` and ``run_sync``.

    Every attribute not explicitly intercepted is forwarded to the wrapped
    agent. ``pydantic_ai`` is imported lazily so importing this module does
    not require the optional dependency.
    """

    __slots__ = ("_agent", "_cz", "_agent_id")

    def __init__(
        self,
        agent: Any,
        client: Optional[Client] = None,
        agent_id: str = "",
    ) -> None:
        try:
            import pydantic_ai  # noqa: F401
        except ImportError as exc:
            raise ImportError(
                "The 'pydantic-ai' package is required for this integration. "
                "Install it with: pip install pydantic-ai"
            ) from exc

        if client is None:
            raise ValueError("GovernedAgent requires a 'client' argument.")

        self._agent = agent
        self._cz = client
        self._agent_id = agent_id

    def _guard(self, method: str, user_prompt: Any) -> None:
        model = getattr(self._agent, "model", None)
        model_name = getattr(model, "model_name", None) or str(model) or "unknown"
        self._cz.guard(
            "llm",
            method="generate",
            args={"user_prompt": str(user_prompt)[:4096]},
            context={
                "resource": f"model/{model_name}",
                "tags": {
                    "provider": "pydantic_ai",
                    "agent_id": self._agent_id,
                    "framework": "pydantic_ai",
                    "action_detail": method,
                },
            },
            raise_on_deny=True,
        )

    def _audit(self, method: str, latency_ms: int, result: Any) -> None:
        try:
            decision = PolicyDecision(effect="allow", reason="guard passed")
            self._cz._audit_decision(
                tool="llm",
                method="generate",
                args={"latency_ms": latency_ms, "action_detail": method},
                decision=decision,
            )
        except Exception:
            pass

    async def run(self, user_prompt: Any, *args: Any, **kwargs: Any) -> Any:
        """Guarded async ``Agent.run``. Returns ``RunResult`` (use ``.output``)."""
        import time

        self._guard("run", user_prompt)
        start = time.perf_counter()
        result = await self._agent.run(user_prompt, *args, **kwargs)
        latency_ms = int((time.perf_counter() - start) * 1000)
        self._audit("run", latency_ms, result)
        return result

    def run_sync(self, user_prompt: Any, *args: Any, **kwargs: Any) -> Any:
        """Guarded synchronous ``Agent.run_sync``."""
        import time

        self._guard("run_sync", user_prompt)
        start = time.perf_counter()
        result = self._agent.run_sync(user_prompt, *args, **kwargs)
        latency_ms = int((time.perf_counter() - start) * 1000)
        self._audit("run_sync", latency_ms, result)
        return result

    def tool(self, *args: Any, **kwargs: Any) -> Any:
        """Proxy ``Agent.tool`` decorator and auto-wrap with ``governed_tool``.

        Usage::

            @agent.tool
            async def search(ctx, query: str) -> str:
                ...

        Each tool is wrapped with a guard check before the function runs.
        """
        # Support both ``@agent.tool`` and ``@agent.tool(name=...)`` forms.
        if len(args) == 1 and callable(args[0]) and not kwargs:
            fn = args[0]
            wrapped = governed_tool(
                self._cz,
                tool_name=getattr(fn, "__name__", "tool"),
                method="call",
                agent_id=self._agent_id,
            )(fn)
            return self._agent.tool(wrapped)

        def _decorator(fn: Callable) -> Callable:
            wrapped = governed_tool(
                self._cz,
                tool_name=kwargs.get("name") or getattr(fn, "__name__", "tool"),
                method="call",
                agent_id=self._agent_id,
            )(fn)
            return self._agent.tool(*args, **kwargs)(wrapped)

        return _decorator

    @property
    def agent(self) -> Any:
        """Return the underlying ``pydantic_ai.Agent`` instance."""
        return self._agent

    def __getattr__(self, name: str) -> Any:
        return getattr(self._agent, name)
