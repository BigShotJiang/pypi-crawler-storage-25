"""
Governed Google ADK Agent wrapper.

Provides governance enforcement for Google ADK agents including:
- Agent-level policy enforcement
- Automatic tool wrapping with governance
- Action audit logging
- Execution tracking
"""

from __future__ import annotations

import time
from typing import Any, Dict, List, Optional

try:
    from google.adk.agents import BaseAgent
    GOOGLE_ADK_AVAILABLE = True
except ImportError:
    GOOGLE_ADK_AVAILABLE = False
    class BaseAgent:  # type: ignore[no-redef]
        pass

from controlzero.client import Client
from controlzero.errors import PolicyDeniedError, PolicyDecision
from controlzero.integrations.google_adk.tool import GovernedTool, wrap_adk_tools


class GovernedAgent:
    """
    Governance wrapper for a Google ADK Agent.

    Wraps a Google ADK BaseAgent to provide:
    - Agent-level policy enforcement before each run
    - Automatic tool wrapping with ControlZero governance
    - Execution audit logging and timing
    - Session-level usage tracking

    Usage::

        from google.adk.agents import LlmAgent
        from controlzero import Client
        from controlzero.integrations.google_adk import GovernedAgent

        client = Client(policy={"rules": [{"allow": "*"}]})

        agent = LlmAgent(
            name="research_agent",
            model="gemini-2.0-flash",
            tools=[search_tool, scrape_tool],
            instruction="You are a research assistant.",
        )

        governed = GovernedAgent(
            agent=agent,
            client=client,
            agent_name="research_agent",
            wrap_tools=True,
        )
    """

    def __init__(
        self,
        agent: Any,
        client: Client,
        agent_name: Optional[str] = None,
        wrap_tools: bool = True,
        allowed_tools: Optional[List[str]] = None,
        log_outputs: bool = False,
    ) -> None:
        """
        Initialize a governed agent.

        Args:
            agent: The Google ADK BaseAgent (or subclass) to wrap.
            client: ControlZero client.
            agent_name: Name used for policy lookups and logging.
                        Defaults to agent.name if present.
            wrap_tools: Whether to wrap the agent's tools with governance.
            allowed_tools: Optional allowlist of tool names. Tools not on
                           this list are removed from the agent before wrapping.
            log_outputs: Whether to include a preview of the run output in
                         the audit log entry.
        """
        if not GOOGLE_ADK_AVAILABLE:
            raise ImportError(
                "The 'google-adk' package is required for this integration. "
                "Install it with: pip install google-adk"
            )

        self._agent = agent
        self._client = client
        self._agent_name = agent_name or getattr(agent, "name", type(agent).__name__)
        self._log_outputs = log_outputs

        if allowed_tools is not None:
            self._filter_tools(allowed_tools)

        if wrap_tools:
            self._wrap_agent_tools()

        # Tracking
        self._run_count = 0
        self._session_start = time.time()

    def _filter_tools(self, allowed_tools: List[str]) -> None:
        """Remove tools not present in the allowlist."""
        tools = getattr(self._agent, "tools", None)
        if not tools:
            return
        filtered = [
            t for t in tools
            if getattr(t, "name", str(t)) in allowed_tools
        ]
        try:
            self._agent.tools = filtered
        except AttributeError:
            pass

    def _wrap_agent_tools(self) -> None:
        """Replace the agent's tools with GovernedTool wrappers."""
        tools = getattr(self._agent, "tools", None)
        if not tools:
            return

        governed = []
        for tool in tools:
            if isinstance(tool, GovernedTool):
                governed.append(tool)
            else:
                governed.append(
                    GovernedTool(base_tool=tool, client=self._client)
                )
        try:
            self._agent.tools = governed
        except AttributeError:
            pass

    async def run_async(
        self,
        *,
        invocation_context: Any,
    ) -> Any:
        """
        Run the agent asynchronously with governance.

        Args:
            invocation_context: Google ADK InvocationContext passed to the
                                 underlying agent's run_async method.

        Returns:
            Agent run result.

        Raises:
            PolicyDeniedError: If the governing policy denies execution.
        """
        tool_name = self._agent_name
        action = "call"
        decision = self._client.guard(
            tool_name,
            method=action,
            context={
                "tags": {
                    "framework": "google_adk",
                    "agent_id": self._agent_name,
                    "action_detail": "run_async",
                },
            },
        )

        if decision.denied:
            raise PolicyDeniedError(decision)

        start = time.perf_counter()
        self._run_count += 1

        try:
            result = await self._agent.run_async(
                invocation_context=invocation_context,
            )

            latency_ms = int((time.perf_counter() - start) * 1000)

            metadata: Dict[str, Any] = {
                "run_count": self._run_count,
                "status": "success",
                "latency_ms": latency_ms,
                "agent_name": self._agent_name,
            }
            if self._log_outputs and result is not None:
                metadata["result_preview"] = str(result)[:500]

            try:
                self._client._audit_decision(
                    tool=tool_name,
                    method=action,
                    args=metadata,
                    decision=decision,
                )
            except Exception:
                pass

            return result

        except PolicyDeniedError:
            raise
        except Exception as exc:
            latency_ms = int((time.perf_counter() - start) * 1000)
            try:
                err_decision = PolicyDecision(
                    effect="allow",
                    reason=f"error: {type(exc).__name__}: {exc}",
                )
                self._client._audit_decision(
                    tool=tool_name,
                    method=action,
                    args={
                        "status": "error",
                        "latency_ms": latency_ms,
                        "agent_name": self._agent_name,
                    },
                    decision=err_decision,
                )
            except Exception:
                pass
            raise

    @property
    def agent(self) -> Any:
        """Return the underlying Google ADK agent."""
        return self._agent

    @property
    def name(self) -> str:
        """Return the agent name."""
        return self._agent_name

    @property
    def tools(self) -> List[Any]:
        """Return the agent's current tool list."""
        return getattr(self._agent, "tools", [])

    @property
    def run_count(self) -> int:
        """Return the total number of run_async calls made this session."""
        return self._run_count

    @property
    def usage_metrics(self) -> Dict[str, Any]:
        """Return session-level usage metrics."""
        return {
            "agent_name": self._agent_name,
            "run_count": self._run_count,
            "session_duration_seconds": round(time.time() - self._session_start, 2),
            "num_tools": len(self.tools),
        }

    def __getattr__(self, name: str) -> Any:
        """Delegate any unknown attribute access to the underlying agent."""
        return getattr(self._agent, name)
