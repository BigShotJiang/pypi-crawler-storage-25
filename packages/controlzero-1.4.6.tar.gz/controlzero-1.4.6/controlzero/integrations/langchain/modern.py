"""Control Zero integration for LangChain v1.x / LangGraph create_agent.

Compatible with langchain >=1.0.0 and langgraph >=1.0.0, tested against
langchain 1.2.x and langgraph 1.1.x.

This module is the modern replacement for the legacy ``GovernedAgent``
wrapper around ``AgentExecutor`` (deprecated in LangChain v1.x).
"""

from __future__ import annotations

from typing import Any, Iterable

from controlzero.client import Client
from controlzero.integrations.langchain.tool import wrap_tools


def create_governed_agent(
    *,
    model: Any,
    tools: Iterable,
    client: Client,
    agent_id: str = "",
    **kwargs: Any,
) -> Any:
    """Create a LangGraph agent with all tools wrapped in Control Zero governance.

    This is the modern replacement for the deprecated AgentExecutor pattern.

    Args:
        model: A LangChain chat model (string like ``"openai:gpt-5.4"`` or a
            model instance).
        tools: Iterable of LangChain tools. Each is wrapped with
            ``GovernanceTool`` before being handed to LangGraph.
        client: Control Zero client.
        agent_id: Tag for audit.
        **kwargs: Forwarded to ``langgraph.prebuilt.create_agent``.

    Returns:
        The LangGraph agent runnable returned by ``create_agent``.
    """
    try:
        from langgraph.prebuilt import create_agent
    except ImportError as exc:
        raise ImportError(
            "langgraph >=1.0.0 is required for create_governed_agent. "
            "Install with: pip install langgraph"
        ) from exc

    governed = wrap_tools(list(tools), client)
    return create_agent(model=model, tools=list(governed), **kwargs)
