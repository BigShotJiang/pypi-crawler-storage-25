"""
ControlZero LangChain Integration.

This module provides governance wrappers for LangChain components including:
- Tools (GovernedTool, GovernanceTool)
- Agents (GovernedAgent)
- Chains (GovernedChain)
- LangGraph (GovernedNode, governed_graph)
- Callbacks (ControlZeroCallbackHandler)

Usage:
    from controlzero import Client
    from controlzero.integrations.langchain import (
        GovernedTool,
        GovernedAgent,
        ControlZeroCallbackHandler,
    )

    # Initialize ControlZero
    client = Client(policy={"rules": [{"allow": "*"}]})

    # Wrap tools with governance
    governed_tool = GovernedTool(
        tool=my_tool,
        client=client,
    )

    # Use callback handler for comprehensive logging
    callback = ControlZeroCallbackHandler(client)
    agent.run("query", callbacks=[callback])
"""

from controlzero.integrations.langchain.tool import GovernanceTool, GovernedTool
from controlzero.integrations.langchain.agent import GovernedAgent
from controlzero.integrations.langchain.chain import GovernedChain
from controlzero.integrations.langchain.callbacks import ControlZeroCallbackHandler
from controlzero.integrations.langchain.graph import (
    GovernedNode,
    governed_graph,
    GovernedStateGraph,
)
from controlzero.integrations.langchain.modern import create_governed_agent

__all__ = [
    # Tools
    "GovernanceTool",
    "GovernedTool",
    # Agents
    "GovernedAgent",
    "create_governed_agent",
    # Chains
    "GovernedChain",
    # Callbacks
    "ControlZeroCallbackHandler",
    # LangGraph
    "GovernedNode",
    "governed_graph",
    "GovernedStateGraph",
]
