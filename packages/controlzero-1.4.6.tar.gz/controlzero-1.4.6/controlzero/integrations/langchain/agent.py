"""
Governed LangChain Agent wrapper.

Provides governance enforcement at the agent level including:
- Per-action policy checks
- Cost and token tracking
- Conversation audit logging
- Tool filtering
"""

from __future__ import annotations

import time
import warnings
from typing import Any, Dict, List, Optional, Sequence, Union

warnings.warn(
    "GovernedAgent wrapping AgentExecutor is deprecated in LangChain v1.x. "
    "Use controlzero.integrations.langchain.modern.create_governed_agent instead.",
    DeprecationWarning,
    stacklevel=2,
)

try:
    from langchain.agents import AgentExecutor
    from langchain_core.agents import AgentAction, AgentFinish
    from langchain_core.tools import BaseTool
    from langchain_core.callbacks import BaseCallbackHandler
    LANGCHAIN_AVAILABLE = True
except ImportError:
    LANGCHAIN_AVAILABLE = False
    class AgentExecutor:
        pass
    class AgentAction:
        pass
    class AgentFinish:
        pass
    class BaseTool:
        pass
    class BaseCallbackHandler:
        pass

from controlzero.client import Client
from controlzero.errors import PolicyDeniedError, PolicyDecision
from controlzero.integrations.langchain.tool import GovernanceTool


class GovernedAgent:
    """
    Governance wrapper for LangChain agents.

    Wraps an AgentExecutor to provide:
    - Tool-level policy enforcement
    - Agent action logging
    - Cost tracking
    - Iteration limits

    Usage:
        from langchain.agents import initialize_agent

        agent = initialize_agent(tools, llm, agent=AgentType.OPENAI_FUNCTIONS)

        governed_agent = GovernedAgent(
            agent=agent,
            client=client,
            max_iterations=10,
        )

        result = governed_agent.run("What's the weather?")
    """

    def __init__(
        self,
        agent: AgentExecutor,
        client: Client,
        max_iterations: Optional[int] = None,
        max_execution_time: Optional[float] = None,
        wrap_tools: bool = True,
        agent_name: str = "langchain_agent",
    ):
        """
        Initialize governed agent.

        Args:
            agent: The LangChain AgentExecutor to wrap
            client: ControlZero client
            max_iterations: Maximum agent iterations (overrides agent setting)
            max_execution_time: Maximum execution time in seconds
            wrap_tools: Whether to wrap agent tools with governance
            agent_name: Name for logging purposes
        """
        if not LANGCHAIN_AVAILABLE:
            raise ImportError(
                "langchain is required. Install with: pip install langchain"
            )

        self._agent = agent
        self._client = client
        self._agent_name = agent_name
        self._max_iterations = max_iterations
        self._max_execution_time = max_execution_time

        if max_iterations:
            self._agent.max_iterations = max_iterations
        if max_execution_time:
            self._agent.max_execution_time = max_execution_time

        if wrap_tools:
            self._wrap_agent_tools()

        # Tracking
        self._total_iterations = 0
        self._total_tool_calls = 0
        self._session_start = time.time()

    def _wrap_agent_tools(self) -> None:
        """Wrap all agent tools with governance."""
        governed_tools = []
        for tool in self._agent.tools:
            if isinstance(tool, GovernanceTool):
                governed_tools.append(tool)
            else:
                governed_tools.append(
                    GovernanceTool(
                        base_tool=tool,
                        client=self._client,
                    )
                )
        self._agent.tools = governed_tools

    def run(
        self,
        input: Union[str, Dict[str, Any]],
        callbacks: Optional[List[BaseCallbackHandler]] = None,
        **kwargs,
    ) -> str:
        """
        Run the agent with governance.

        Args:
            input: Agent input (string or dict)
            callbacks: Additional callbacks
            **kwargs: Additional arguments passed to agent

        Returns:
            Agent response string

        Raises:
            PolicyDeniedError: If agent execution is denied
        """
        decision = self._client.guard(
            tool=self._agent_name,
            method="run",
        )
        if decision.denied:
            raise PolicyDeniedError(decision)

        start = time.perf_counter()

        try:
            result = self._agent.run(input, callbacks=callbacks, **kwargs)

            latency_ms = int((time.perf_counter() - start) * 1000)
            self._audit("run", latency_ms, "success", decision, result)

            return result

        except PolicyDeniedError:
            raise
        except Exception as e:
            latency_ms = int((time.perf_counter() - start) * 1000)
            self._audit("run", latency_ms, "error", decision, error=e)
            raise

    async def arun(
        self,
        input: Union[str, Dict[str, Any]],
        callbacks: Optional[List[BaseCallbackHandler]] = None,
        **kwargs,
    ) -> str:
        """Async run with governance."""
        decision = self._client.guard(
            tool=self._agent_name,
            method="run",
        )
        if decision.denied:
            raise PolicyDeniedError(decision)

        start = time.perf_counter()

        try:
            result = await self._agent.arun(input, callbacks=callbacks, **kwargs)
            latency_ms = int((time.perf_counter() - start) * 1000)
            self._audit("run", latency_ms, "success", decision, result)
            return result

        except PolicyDeniedError:
            raise
        except Exception as e:
            latency_ms = int((time.perf_counter() - start) * 1000)
            self._audit("run", latency_ms, "error", decision, error=e)
            raise

    def invoke(
        self,
        input: Union[str, Dict[str, Any]],
        config: Optional[Dict] = None,
        **kwargs,
    ) -> Dict[str, Any]:
        """
        Invoke the agent (LCEL interface) with governance.

        Args:
            input: Agent input
            config: Run configuration
            **kwargs: Additional arguments

        Returns:
            Agent output dict
        """
        decision = self._client.guard(
            tool=self._agent_name,
            method="invoke",
        )
        if decision.denied:
            raise PolicyDeniedError(decision)

        start = time.perf_counter()

        try:
            result = self._agent.invoke(input, config=config, **kwargs)
            latency_ms = int((time.perf_counter() - start) * 1000)
            self._audit("invoke", latency_ms, "success", decision, str(result))
            return result

        except PolicyDeniedError:
            raise
        except Exception as e:
            latency_ms = int((time.perf_counter() - start) * 1000)
            self._audit("invoke", latency_ms, "error", decision, error=e)
            raise

    async def ainvoke(
        self,
        input: Union[str, Dict[str, Any]],
        config: Optional[Dict] = None,
        **kwargs,
    ) -> Dict[str, Any]:
        """Async invoke with governance."""
        decision = self._client.guard(
            tool=self._agent_name,
            method="invoke",
        )
        if decision.denied:
            raise PolicyDeniedError(decision)

        start = time.perf_counter()

        try:
            result = await self._agent.ainvoke(input, config=config, **kwargs)
            latency_ms = int((time.perf_counter() - start) * 1000)
            self._audit("invoke", latency_ms, "success", decision, str(result))
            return result

        except PolicyDeniedError:
            raise
        except Exception as e:
            latency_ms = int((time.perf_counter() - start) * 1000)
            self._audit("invoke", latency_ms, "error", decision, error=e)
            raise

    def _audit(
        self,
        method: str,
        latency_ms: int,
        status: str,
        decision: PolicyDecision,
        result: Optional[str] = None,
        error: Optional[Exception] = None,
    ) -> None:
        """Write audit entry."""
        try:
            args: dict = {"status": status, "latency_ms": latency_ms}
            if result:
                args["result_length"] = len(result)
            if error:
                args["error_type"] = type(error).__name__
                args["error_message"] = str(error)
            self._client._audit_decision(
                tool=self._agent_name,
                method=method,
                args=args,
                decision=decision,
            )
        except Exception:
            pass

    @property
    def tools(self) -> List[BaseTool]:
        """Get agent tools."""
        return self._agent.tools

    @property
    def agent(self) -> AgentExecutor:
        """Get underlying agent executor."""
        return self._agent
