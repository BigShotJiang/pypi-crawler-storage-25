"""Control Zero integration for Google Gemini via google-genai.

Compatible with google-genai >=0.1.0, tested against 0.3.x.

Provides ``wrap_google()`` which intercepts the ``generate_content``
method on a ``google.genai.Client().models`` resource to enforce
governance policies before the request reaches Google. All other
attributes pass through unchanged.

Usage::

    from controlzero import Client
    from controlzero.integrations.google import wrap_google
    from google import genai

    cz = Client(api_key="cz_live_...")
    google_client = genai.Client(api_key="GEMINI_API_KEY")
    models = wrap_google(google_client.models, cz, agent_id="my-agent")

    response = models.generate_content(
        model="gemini-2.0-flash",
        contents="Hello",
    )
"""

from __future__ import annotations

import time
from typing import Any

from controlzero.client import Client
from controlzero._internal.enforcer import PolicyDecision


class _WrappedModels:
    """Proxy for ``genai.Client().models`` that enforces policy on generate_content()."""

    __slots__ = ("_inner", "_cz", "_agent_id")

    def __init__(self, inner: Any, cz: Client, agent_id: str) -> None:
        self._inner = inner
        self._cz = cz
        self._agent_id = agent_id

    def _extract_usage(self, response: Any) -> tuple[int, int]:
        """Return (input_tokens, output_tokens) from a google-genai response."""
        usage = getattr(response, "usage_metadata", None)
        if usage is None:
            return 0, 0
        input_tokens = getattr(usage, "prompt_token_count", 0) or 0
        output_tokens = getattr(usage, "candidates_token_count", 0) or 0
        return input_tokens, output_tokens

    def _guard(self, model_name: str) -> None:
        self._cz.guard(
            "llm",
            method="generate",
            context={
                "provider": "google",
                "resource": f"model/{model_name}",
                "tags": {
                    "agent_id": self._agent_id,
                    "provider": "google",
                    "action_detail": "generate_content",
                },
            },
            raise_on_deny=True,
        )

    def generate_content(self, *args: Any, **kwargs: Any) -> Any:
        """Enforce policy then delegate to the inner generate_content()."""
        model_name = kwargs.get("model") or (args[0] if args else "unknown")
        self._guard(model_name)

        start = time.perf_counter()
        response = self._inner.generate_content(*args, **kwargs)
        latency_ms = int((time.perf_counter() - start) * 1000)

        input_tokens, output_tokens = self._extract_usage(response)

        try:
            decision = PolicyDecision(effect="allow", reason="guard passed")
            self._cz._audit_decision(
                tool="llm",
                method="generate",
                args={
                    "model": model_name,
                    "input_tokens": input_tokens,
                    "output_tokens": output_tokens,
                    "latency_ms": latency_ms,
                },
                decision=decision,
                context={
                    "tags": {
                        "provider": "google",
                        "agent_id": self._agent_id,
                        "action_detail": "generate_content",
                    },
                },
            )
        except Exception:
            pass

        return response

    async def generate_content_async(self, *args: Any, **kwargs: Any) -> Any:
        """Async variant. google-genai exposes ``aio.models.generate_content``; we
        also support the older ``generate_content_async`` method name."""
        model_name = kwargs.get("model") or (args[0] if args else "unknown")
        self._guard(model_name)

        start = time.perf_counter()
        if hasattr(self._inner, "generate_content_async"):
            response = await self._inner.generate_content_async(*args, **kwargs)
        else:
            # google-genai 0.3.x uses Client().aio.models.generate_content
            response = await self._inner.generate_content(*args, **kwargs)
        latency_ms = int((time.perf_counter() - start) * 1000)

        input_tokens, output_tokens = self._extract_usage(response)

        try:
            decision = PolicyDecision(effect="allow", reason="guard passed")
            self._cz._audit_decision(
                tool="llm",
                method="generate",
                args={
                    "model": model_name,
                    "input_tokens": input_tokens,
                    "output_tokens": output_tokens,
                    "latency_ms": latency_ms,
                },
                decision=decision,
                context={
                    "tags": {
                        "provider": "google",
                        "agent_id": self._agent_id,
                        "action_detail": "generate_content_async",
                    },
                },
            )
        except Exception:
            pass

        return response

    def __getattr__(self, name: str) -> Any:
        return getattr(self._inner, name)


def wrap_google(
    models: Any,
    cz: Client,
    agent_id: str = "",
) -> Any:
    """Wrap a ``google.genai.Client().models`` resource with Control Zero governance.

    Args:
        models: A ``google.genai.Client().models`` instance (or ``.aio.models``).
        cz: A ``controlzero.Client`` instance with a policy loaded.
        agent_id: Optional identifier tagged on the audit entry.

    Returns:
        Proxy that intercepts ``generate_content()`` / ``generate_content_async()``
        and passes all other attributes through.

    Example::

        from google import genai
        from controlzero import Client
        from controlzero.integrations.google import wrap_google

        cz = Client(api_key="cz_live_...")
        google_client = genai.Client(api_key="GEMINI_API_KEY")
        models = wrap_google(google_client.models, cz, agent_id="my-agent")
        response = models.generate_content(model="gemini-2.0-flash", contents="Hi")
    """
    return _WrappedModels(models, cz, agent_id)
