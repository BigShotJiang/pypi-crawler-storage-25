"""Control Zero LiteLLM callback integration.

Compatible with litellm >=1.50.0, tested against 1.50+ including async streaming.

Provides ``ControlZeroLiteLLMCallback`` which extends LiteLLM's
``CustomLogger`` to enforce policies before every LLM API call and to
write audit entries on success or failure. Both sync and async hooks
are implemented.

Usage::

    from controlzero import Client
    from controlzero.integrations.litellm import ControlZeroLiteLLMCallback
    import litellm

    cz = Client(api_key="cz_live_...")
    litellm.callbacks = [ControlZeroLiteLLMCallback(cz)]

    response = litellm.completion(
        model="openai/gpt-5",
        messages=[{"role": "user", "content": "Hello"}],
    )
"""

from __future__ import annotations

from typing import Any

try:
    from litellm.integrations.custom_logger import CustomLogger
except ImportError:
    raise ImportError(
        "The 'litellm' package is required for this integration. "
        "Install it with: pip install litellm"
    )

from controlzero.client import Client
from controlzero._internal.enforcer import PolicyDecision


def _parse_provider_model(model: str) -> tuple[str, str]:
    """Split a LiteLLM model string into (provider, model).

    LiteLLM uses ``"provider/model"`` (e.g. ``"openai/gpt-5"``). If no
    provider is present, returns ("litellm", model).
    """
    if "/" in model:
        provider, actual = model.split("/", 1)
        return provider, actual
    return "litellm", model


def _compute_duration_ms(start_time: Any, end_time: Any) -> int:
    """Best-effort duration in milliseconds from LiteLLM start/end timestamps."""
    try:
        if hasattr(start_time, "timestamp") and hasattr(end_time, "timestamp"):
            return int((end_time.timestamp() - start_time.timestamp()) * 1000)
        return int((float(end_time) - float(start_time)) * 1000)
    except Exception:
        return 0


def _extract_tokens(response_obj: Any) -> tuple[int, int]:
    """Extract (input_tokens, output_tokens) from a LiteLLM response object."""
    usage = getattr(response_obj, "usage", None)
    if usage is None and isinstance(response_obj, dict):
        usage = response_obj.get("usage")
    if usage is None:
        return 0, 0
    if isinstance(usage, dict):
        return int(usage.get("prompt_tokens", 0) or 0), int(
            usage.get("completion_tokens", 0) or 0
        )
    return (
        int(getattr(usage, "prompt_tokens", 0) or 0),
        int(getattr(usage, "completion_tokens", 0) or 0),
    )


class ControlZeroLiteLLMCallback(CustomLogger):
    """LiteLLM callback that enforces Control Zero policies and audits calls.

    On ``log_pre_api_call`` (sync) and ``async_log_pre_api_call`` (async),
    the callback evaluates ``cz.guard(...)``. If the policy denies, a
    ``PolicyDeniedError`` is raised and the API call is aborted.

    On success, the callback writes an audit entry with latency and
    token counts. On failure, the callback writes an audit entry with
    the error type and message.
    """

    def __init__(self, cz: Client, agent_id: str = "") -> None:
        super().__init__()
        self._cz = cz
        self._agent_id = agent_id

    # ---------------- helpers ----------------

    def _guard(self, model: str, call_type: str) -> None:
        provider, model_name = _parse_provider_model(model)
        action_detail = f"{call_type}"
        if call_type == "embedding":
            tool = "embedding"
            method = "generate"
        else:
            tool = "llm"
            method = "generate"

        self._cz.guard(
            tool,
            method=method,
            context={
                "resource": f"model/{model_name}",
                "tags": {
                    "provider": provider,
                    "agent_id": self._agent_id,
                    "framework": "litellm",
                    "action_detail": action_detail,
                },
            },
            raise_on_deny=True,
        )

    def _audit_success(
        self,
        kwargs: dict,
        response_obj: Any,
        start_time: Any,
        end_time: Any,
    ) -> None:
        model = kwargs.get("model", "unknown")
        call_type = kwargs.get("call_type", "completion")
        provider, model_name = _parse_provider_model(model)
        duration_ms = _compute_duration_ms(start_time, end_time)
        input_tokens, output_tokens = _extract_tokens(response_obj)

        tool = "embedding" if call_type == "embedding" else "llm"

        try:
            decision = PolicyDecision(effect="allow", reason="guard passed")
            self._cz._audit_decision(
                tool=tool,
                method="generate",
                args={
                    "model": model_name,
                    "input_tokens": input_tokens,
                    "output_tokens": output_tokens,
                    "latency_ms": duration_ms,
                    "status": "success",
                    "action_detail": call_type,
                },
                decision=decision,
                context={
                    "tags": {
                        "provider": provider,
                        "agent_id": self._agent_id,
                        "framework": "litellm",
                    },
                },
            )
        except Exception:
            pass

    def _audit_failure(
        self,
        kwargs: dict,
        response_obj: Any,
        start_time: Any,
        end_time: Any,
    ) -> None:
        model = kwargs.get("model", "unknown")
        call_type = kwargs.get("call_type", "completion")
        provider, model_name = _parse_provider_model(model)
        duration_ms = _compute_duration_ms(start_time, end_time)
        error = kwargs.get("exception") or response_obj
        error_type = type(error).__name__ if error is not None else "unknown"
        error_msg = str(error) if error is not None else ""

        tool = "embedding" if call_type == "embedding" else "llm"

        try:
            decision = PolicyDecision(
                effect="allow",
                reason=f"error: {error_type}: {error_msg}",
            )
            self._cz._audit_decision(
                tool=tool,
                method="generate",
                args={
                    "model": model_name,
                    "latency_ms": duration_ms,
                    "status": "error",
                    "error_type": error_type,
                    "error_message": error_msg[:500],
                    "action_detail": call_type,
                },
                decision=decision,
                context={
                    "tags": {
                        "provider": provider,
                        "agent_id": self._agent_id,
                        "framework": "litellm",
                    },
                },
            )
        except Exception:
            pass

    # ---------------- sync hooks ----------------

    def log_pre_api_call(
        self,
        model: str,
        messages: Any,
        kwargs: dict,
    ) -> None:
        """Enforce policy before each sync LiteLLM call."""
        call_type = kwargs.get("call_type", "completion")
        self._guard(model, call_type)

    def log_success_event(
        self,
        kwargs: dict,
        response_obj: Any,
        start_time: Any,
        end_time: Any,
    ) -> None:
        """Audit a successful sync call with latency and tokens."""
        self._audit_success(kwargs, response_obj, start_time, end_time)

    def log_failure_event(
        self,
        kwargs: dict,
        response_obj: Any,
        start_time: Any,
        end_time: Any,
    ) -> None:
        """Audit a failed sync call with the error type and message."""
        self._audit_failure(kwargs, response_obj, start_time, end_time)

    # ---------------- async hooks ----------------

    async def async_log_pre_api_call(
        self,
        model: str,
        messages: Any,
        kwargs: dict,
    ) -> None:
        """Enforce policy before each async LiteLLM call."""
        call_type = kwargs.get("call_type", "completion")
        self._guard(model, call_type)

    async def async_log_success_event(
        self,
        kwargs: dict,
        response_obj: Any,
        start_time: Any,
        end_time: Any,
    ) -> None:
        """Audit a successful async call (including streaming)."""
        self._audit_success(kwargs, response_obj, start_time, end_time)

    async def async_log_failure_event(
        self,
        kwargs: dict,
        response_obj: Any,
        start_time: Any,
        end_time: Any,
    ) -> None:
        """Audit a failed async call."""
        self._audit_failure(kwargs, response_obj, start_time, end_time)
