"""Public exception types for the controlzero SDK."""

from controlzero._internal.enforcer import PolicyDeniedError, PolicyDecision


class HostedModeNotImplemented(NotImplementedError):
    """Raised when an API key is set but no local policy is provided.

    Hosted mode (dashboard-managed policies + remote audit) is not implemented
    in the slim `controlzero` package. To use hosted mode, install the legacy
    `control-zero<=0.3.0` package. To use this package, provide a local policy
    via `policy=` or `policy_file=`.
    """


class HybridModeError(RuntimeError):
    """Raised when an API key and a local policy are both provided AND
    `strict_hosted=True` is set. Indicates an accidental dashboard-policy
    override that the user opted to make a hard error.
    """


class PolicyValidationError(ValueError):
    """Raised when a policy file or dict fails schema validation.

    Attributes:
        errors: List of human-readable error strings, one per bad field.
        source: The file path or "<dict>" indicating where the policy came from.
    """

    def __init__(self, errors: list[str], source: str = "<unknown>"):
        self.errors = errors
        self.source = source
        msg = f"Policy validation failed for {source}:\n  - " + "\n  - ".join(errors)
        super().__init__(msg)


class PolicyLoadError(Exception):
    """Raised when a policy file cannot be loaded (file not found, parse error, etc).

    Wraps the underlying exception with extra context (file path, format hint).
    """

    def __init__(self, message: str, source: str = "<unknown>", cause: Exception = None):
        self.source = source
        self.cause = cause
        full = f"{message} (source: {source})"
        if cause:
            full += f"\n  caused by: {type(cause).__name__}: {cause}"
        super().__init__(full)


class BundleSignatureError(Exception):
    """Policy bundle signature verification failed."""


class HostedAuthError(RuntimeError):
    """Raised when the project API key is rejected by the backend (401/403).

    This is a permanent failure: the caller supplied an invalid or revoked
    API key. Retrying with the same key will not help. The SDK surfaces
    this so the user can correct their configuration.
    """


class HostedBootstrapError(RuntimeError):
    """Raised when hosted mode cannot initialize and no cached bundle exists.

    The SDK fails closed: without a valid policy it refuses to construct.
    This is preferable to silently allowing every tool call. If a cached
    bundle is present, the SDK uses it and emits a warning instead.
    """


__all__ = [
    "PolicyDecision",
    "PolicyDeniedError",
    "PolicyValidationError",
    "PolicyLoadError",
    "BundleSignatureError",
    "HostedAuthError",
    "HostedBootstrapError",
    "HostedModeNotImplemented",
    "HybridModeError",
]
