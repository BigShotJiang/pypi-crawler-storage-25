"""Tests for configurable tamper behavior in the Client and CLI."""

import json
import os
import tempfile
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

from controlzero import Client
from controlzero.tamper import TamperState


@pytest.fixture
def tmp_state_dir(tmp_path):
    """Provide a temporary directory for quarantine state."""
    return tmp_path


@pytest.fixture
def policy_deny():
    """Policy dict with tamper_behavior=deny."""
    return {
        "version": "1",
        "settings": {"tamper_behavior": "deny"},
        "rules": [{"allow": "*"}],
    }


@pytest.fixture
def policy_deny_all():
    """Policy dict with tamper_behavior=deny-all."""
    return {
        "version": "1",
        "settings": {"tamper_behavior": "deny-all"},
        "rules": [{"allow": "*"}],
    }


@pytest.fixture
def policy_quarantine():
    """Policy dict with tamper_behavior=quarantine."""
    return {
        "version": "1",
        "settings": {"tamper_behavior": "quarantine"},
        "rules": [{"allow": "*"}],
    }


@pytest.fixture
def policy_warn():
    """Policy dict with tamper_behavior=warn (default)."""
    return {
        "version": "1",
        "settings": {"tamper_behavior": "warn"},
        "rules": [{"allow": "*"}],
    }


class TestClientTamperBehavior:

    def test_client_warn_mode_allows_on_tamper(self, policy_warn):
        """When tamper_behavior=warn and tamper_detected=True, the call is still allowed."""
        cz = Client(policy=policy_warn)
        decision = cz.guard("some_tool", context={"tamper_detected": True})
        cz.close()
        assert decision.allowed

    def test_client_deny_mode_blocks_on_tamper(self, policy_deny):
        """When tamper_behavior=deny and tamper_detected=True, the call is blocked."""
        cz = Client(policy=policy_deny)
        decision = cz.guard("some_tool", context={"tamper_detected": True})
        cz.close()
        assert decision.denied
        assert "tamper" in decision.reason.lower()

    def test_client_deny_all_mode_quarantines(self, policy_deny_all, tmp_state_dir):
        """When tamper_behavior=deny-all and tamper_detected=True,
        quarantine is set and the call is blocked."""
        cz = Client(policy=policy_deny_all)
        cz._tamper_state_dir = tmp_state_dir
        decision = cz.guard("some_tool", context={"tamper_detected": True})
        cz.close()
        assert decision.denied
        assert TamperState.is_quarantined(tmp_state_dir)

    @patch("controlzero.tamper.report_tamper_alert")
    def test_client_quarantine_mode_alerts_dashboard(
        self, mock_report, policy_quarantine, tmp_state_dir
    ):
        """When tamper_behavior=quarantine and tamper_detected=True,
        report_tamper_alert is called and the call is blocked."""
        cz = Client(policy=policy_quarantine)
        cz._tamper_state_dir = tmp_state_dir
        decision = cz.guard("some_tool", context={"tamper_detected": True})
        cz.close()
        assert decision.denied
        assert TamperState.is_quarantined(tmp_state_dir)
        mock_report.assert_called_once()

    @patch("controlzero.enrollment.load_state")
    def test_priority_enrollment_over_policy(self, mock_load_state, tmp_path):
        """Enrollment state tamper_behavior overrides policy settings."""
        mock_state = MagicMock()
        mock_state.tamper_behavior = "deny"
        mock_state.api_url = "https://api.test"
        mock_state.machine_id = "test-id"
        mock_state.org_id = "test-org"
        mock_load_state.return_value = mock_state

        # Policy says warn, but enrollment says deny
        policy = {
            "version": "1",
            "settings": {"tamper_behavior": "warn"},
            "rules": [{"allow": "*"}],
        }
        cz = Client(policy=policy)
        assert cz._tamper_behavior == "deny"
        decision = cz.guard("some_tool", context={"tamper_detected": True})
        cz.close()
        assert decision.denied

    def test_no_tamper_context_allows(self, policy_deny):
        """When tamper_detected is not in context, calls proceed normally."""
        cz = Client(policy=policy_deny)
        decision = cz.guard("some_tool")
        cz.close()
        assert decision.allowed

    def test_tamper_detected_false_allows(self, policy_deny):
        """When tamper_detected=False, calls proceed normally even in deny mode."""
        cz = Client(policy=policy_deny)
        decision = cz.guard("some_tool", context={"tamper_detected": False})
        cz.close()
        assert decision.allowed


class TestTamperStatePersistence:

    def test_enter_and_check_quarantine(self, tmp_state_dir):
        """After enter_quarantine, is_quarantined returns True."""
        assert not TamperState.is_quarantined(tmp_state_dir)
        TamperState.enter_quarantine(tmp_state_dir, reason="test", source="policy_hmac")
        assert TamperState.is_quarantined(tmp_state_dir)

    def test_clear_quarantine(self, tmp_state_dir):
        """After clear, is_quarantined returns False."""
        TamperState.enter_quarantine(tmp_state_dir, reason="test", source="policy_hmac")
        assert TamperState.is_quarantined(tmp_state_dir)
        TamperState.clear(tmp_state_dir)
        assert not TamperState.is_quarantined(tmp_state_dir)

    def test_load_roundtrip(self, tmp_state_dir):
        """TamperState save/load preserves all fields."""
        TamperState.enter_quarantine(tmp_state_dir, reason="bad hmac", source="policy_hmac")
        loaded = TamperState.load(tmp_state_dir)
        assert loaded.quarantined is True
        assert loaded.reason == "bad hmac"
        assert loaded.source == "policy_hmac"
        assert loaded.detected_at != ""

    def test_no_file_returns_not_quarantined(self, tmp_state_dir):
        """When quarantine.json does not exist, is_quarantined returns False."""
        assert not TamperState.is_quarantined(tmp_state_dir)
        state = TamperState.load(tmp_state_dir)
        assert state.quarantined is False
