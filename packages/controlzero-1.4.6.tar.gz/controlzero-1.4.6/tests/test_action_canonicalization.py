"""Cross-SDK action canonicalization parity (issue #69).

Mirrors the fixture at tests/cross-sdk/policy-action-format.json. The
same cases run in the Node SDK (tests/actionCanonicalization.test.ts)
and Go SDK (action_canonicalization_test.go). Drift between any of
the three breaks this test in the SDK that drifted.
"""

from __future__ import annotations

import unittest

from controlzero.policy_loader import _canonicalize_action

# Keep this list in sync with the same fixture in the Node + Go tests.
CASES = [
    ("*", "*"),
    ("delete_*", "delete_*:*"),
    ("github", "github:*"),
    ("github:*", "github:*"),
    ("github:list_*", "github:list_*"),
    ("*:read", "*:read"),
    ("llm:openai.generate", "llm:openai.generate"),
    ("tool_with_dot.name", "tool_with_dot.name:*"),
]


class ActionCanonicalizationTests(unittest.TestCase):
    def test_all_cases(self) -> None:
        for pattern, expected in CASES:
            with self.subTest(pattern=pattern):
                self.assertEqual(_canonicalize_action(pattern), expected)


if __name__ == "__main__":
    unittest.main()
