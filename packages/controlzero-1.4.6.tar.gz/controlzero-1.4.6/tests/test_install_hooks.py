"""End-to-end test suite for the controlzero hook installers and hook-check evaluator.

This file is intentionally exhaustive. The audience is procurement / security
review teams (Samsung et al.) who need a clear story of what is covered,
what is intentionally skipped, and what is known broken.

Coverage matrix
---------------
Per installer (claude-code, gemini-cli, codex-cli):
  POSITIVE
    - fresh install writes policy.yaml + agent config from scratch
    - policy file content matches the bundled template byte-for-byte
    - resulting agent config file is valid JSON / valid TOML
    - second install is idempotent (no duplicate hook blocks)
    - --force overwrites an existing policy.yaml
    - --settings / --config flag honored (custom path)
    - return code 0 and stdout contains a success message
  NEGATIVE
    - bundled template missing -> error, exit 1, stderr explains
    - existing settings.json is malformed JSON -> error, exit 1, stderr asks user to fix
    - settings.json is read-only -> failure surfaces cleanly (PermissionError)
    - --force overwrites a policy file that has local edits
    - top-level `controlzero` with no args -> shows help, exit 0
    - top-level `controlzero install` with no args -> shows help, exit 0/2
  REGRESSION
    - 3rd-party hook is preserved when ours is added
    - replacing-only-our-block leaves siblings intact
    - upgrading from a v0.1-shaped block to a v0.2-shaped block does not duplicate
    - cross-installer: all three installers compose without clobbering each other

For hook-check:
    - allow rule, deny rule, glob match, catch-all, ordering, missing payload,
      invalid payload, empty stdin, missing policy, unreadable policy, audit log
      write failure, per-project override

Per the project mandate (fail-closed by default in production), the hook-check
command actually fails OPEN at the CLI layer to "never brick the agent". That
trade-off is documented in main.py:354 (`# Malformed payload: log to stderr
and pass through. Never brick the agent.`). Tests assert the SHIPPED behavior
and call out the gap explicitly so reviewers see the intent.

Implementation notes
--------------------
* `Path.home()` is monkey-patched to `tmp_path` for every test that touches
  the global `~/.controlzero` or per-agent config dirs.
* `controlzero.cli.main` is reloaded after monkey-patching `Path.home` so the
  module-level `GLOBAL_POLICY_DIR` / `GLOBAL_POLICY_PATH` constants pick up
  the fake home.
* `click.testing.CliRunner(mix_stderr=False)` is used so we can assert on
  stdout vs. stderr separately.
* TOML is parsed with stdlib `tomllib` (Python 3.11+).
"""

from __future__ import annotations

import importlib
import json
import os
import sys
from pathlib import Path

import pytest
import yaml
from click.testing import CliRunner

# tomllib is stdlib in 3.11+. Skip the strict TOML parse tests on older
# Pythons rather than pull in tomli (we still ship for 3.9+).
try:
    import tomllib  # type: ignore[import-not-found]
    HAS_TOMLLIB = True
except ImportError:
    HAS_TOMLLIB = False


# ---------------------------------------------------------------------------
# Fixtures and helpers
# ---------------------------------------------------------------------------


@pytest.fixture
def fake_home(tmp_path, monkeypatch):
    """Point Path.home() at a tmp dir and reload the CLI module so its
    module-level constants (GLOBAL_POLICY_DIR, GLOBAL_POLICY_PATH) repoint.

    Returns the fake home Path.
    """
    home = tmp_path / "home"
    home.mkdir()
    monkeypatch.setenv("HOME", str(home))
    monkeypatch.setattr("pathlib.Path.home", lambda: home)

    import controlzero.cli.main as cli_main
    importlib.reload(cli_main)
    return home


@pytest.fixture
def cli_main(fake_home):
    """The freshly reloaded CLI module bound to the fake home."""
    import controlzero.cli.main as m
    return m


@pytest.fixture
def runner():
    # Click >=8.2 removed mix_stderr; older Click had it default to True.
    # Use the default constructor and read result.output for combined stream.
    try:
        return CliRunner(mix_stderr=False)
    except TypeError:
        return CliRunner()


def _write_yaml_policy(path: Path, rules: list) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(yaml.safe_dump({"version": "1", "rules": rules}))


def _read_template(name: str) -> str:
    """Read a bundled template file straight off disk for byte-comparison."""
    pkg_root = Path(__file__).resolve().parent.parent / "controlzero" / "cli" / "templates"
    return (pkg_root / name).read_text(encoding="utf-8")


def _settings_pretool_commands(settings: dict) -> list:
    """Pull every Claude-Code-style PreToolUse command into a flat list."""
    return [
        h.get("command")
        for block in settings.get("hooks", {}).get("PreToolUse", [])
        for h in block.get("hooks", [])
    ]


def _settings_gemini_pretool_commands(settings: dict) -> list:
    # New nested format: BeforeTool -> [{matcher, hooks: [{type, command}]}]
    commands = []
    for block in settings.get("hooks", {}).get("BeforeTool", []):
        for h in block.get("hooks", []):
            if isinstance(h, dict) and h.get("command"):
                commands.append(h["command"])
        # Also handle old flat format for backwards compat in tests
        if isinstance(block, dict) and isinstance(block.get("command"), str):
            commands.append(block["command"])
    return commands


def _codex_hooks_json_commands(hooks_data: dict) -> list:
    """Pull every Codex hooks.json PreToolUse command into a flat list."""
    commands = []
    for block in hooks_data.get("hooks", {}).get("PreToolUse", []):
        for h in block.get("hooks", []):
            if isinstance(h, dict) and h.get("command"):
                commands.append(h["command"])
    return commands


# ===========================================================================
# TestClaudeCodeInstall
# ===========================================================================


class TestClaudeCodeInstall:
    """Coverage for `controlzero install claude-code`."""

    # ---------- POSITIVE ----------

    def test_fresh_install_writes_policy_and_settings(self, cli_main, runner, fake_home):
        result = runner.invoke(cli_main.cli, ["install", "claude-code"])
        assert result.exit_code == 0, result.output
        assert (fake_home / ".controlzero" / "policy.yaml").exists()
        assert (fake_home / ".claude" / "settings.json").exists()

    def test_policy_matches_bundled_template_byte_for_byte(self, cli_main, runner, fake_home):
        runner.invoke(cli_main.cli, ["install", "claude-code"])
        on_disk = (fake_home / ".controlzero" / "policy.yaml").read_text(encoding="utf-8")
        assert on_disk == _read_template("claude-code.yaml")

    def test_settings_json_is_valid_after_merge(self, cli_main, runner, fake_home):
        runner.invoke(cli_main.cli, ["install", "claude-code"])
        text = (fake_home / ".claude" / "settings.json").read_text(encoding="utf-8")
        json.loads(text)  # raises if invalid

    def test_idempotent_second_install_no_duplicate_block(self, cli_main, runner, fake_home):
        runner.invoke(cli_main.cli, ["install", "claude-code"])
        runner.invoke(cli_main.cli, ["install", "claude-code"])
        settings = json.loads((fake_home / ".claude" / "settings.json").read_text())
        cmds = _settings_pretool_commands(settings)
        assert cmds.count("controlzero hook-check") == 1

    def test_idempotent_state_is_byte_identical(self, cli_main, runner, fake_home):
        runner.invoke(cli_main.cli, ["install", "claude-code"])
        first = (fake_home / ".claude" / "settings.json").read_text()
        runner.invoke(cli_main.cli, ["install", "claude-code"])
        second = (fake_home / ".claude" / "settings.json").read_text()
        assert first == second

    def test_force_overwrites_existing_policy(self, cli_main, runner, fake_home):
        cz_dir = fake_home / ".controlzero"
        cz_dir.mkdir()
        (cz_dir / "policy.yaml").write_text("# stale\n")
        result = runner.invoke(cli_main.cli, ["install", "claude-code", "--force"])
        assert result.exit_code == 0
        assert "stale" not in (cz_dir / "policy.yaml").read_text()

    def test_settings_flag_honors_custom_path(self, cli_main, runner, tmp_path, fake_home):
        custom = tmp_path / "custom" / "settings.json"
        result = runner.invoke(
            cli_main.cli, ["install", "claude-code", "--settings", str(custom)]
        )
        assert result.exit_code == 0, result.output
        assert custom.exists()
        assert not (fake_home / ".claude" / "settings.json").exists()

    def test_success_message_on_stdout(self, cli_main, runner, fake_home):
        result = runner.invoke(cli_main.cli, ["install", "claude-code"])
        assert result.exit_code == 0
        assert "Done" in result.output or "Updated" in result.output

    def test_creates_parent_dirs_when_absent(self, cli_main, runner, fake_home):
        # Neither ~/.controlzero nor ~/.claude exist; install must create both.
        assert not (fake_home / ".controlzero").exists()
        assert not (fake_home / ".claude").exists()
        result = runner.invoke(cli_main.cli, ["install", "claude-code"])
        assert result.exit_code == 0
        assert (fake_home / ".controlzero").is_dir()
        assert (fake_home / ".claude").is_dir()

    # ---------- NEGATIVE ----------

    def test_missing_template_errors(self, cli_main, runner, fake_home, monkeypatch):
        bogus = fake_home / "no-such-templates"
        monkeypatch.setattr(cli_main, "TEMPLATE_DIR", bogus)
        result = runner.invoke(cli_main.cli, ["install", "claude-code"])
        assert result.exit_code == 1
        assert "template missing" in result.output

    def test_malformed_settings_json_errors(self, cli_main, runner, fake_home):
        claude_dir = fake_home / ".claude"
        claude_dir.mkdir()
        (claude_dir / "settings.json").write_text("{ this is not json")
        result = runner.invoke(cli_main.cli, ["install", "claude-code"])
        assert result.exit_code == 1
        assert "not valid JSON" in result.output

    def test_readonly_settings_file_surfaces_error(self, cli_main, runner, fake_home):
        if os.geteuid() == 0:
            pytest.skip("running as root; chmod cannot block writes")
        claude_dir = fake_home / ".claude"
        claude_dir.mkdir()
        sf = claude_dir / "settings.json"
        sf.write_text("{}")
        sf.chmod(0o400)
        # Make the parent dir non-writable too so the rewrite cannot succeed.
        claude_dir.chmod(0o500)
        try:
            result = runner.invoke(cli_main.cli, ["install", "claude-code"])
            # Either Click catches it (non-zero exit) or PermissionError leaks
            # through. Both are acceptable; what matters is we do not silently
            # claim success.
            assert result.exit_code != 0 or isinstance(result.exception, PermissionError)
        finally:
            claude_dir.chmod(0o700)
            sf.chmod(0o600)

    def test_force_overwrites_policy_with_local_edits(self, cli_main, runner, fake_home):
        cz_dir = fake_home / ".controlzero"
        cz_dir.mkdir()
        (cz_dir / "policy.yaml").write_text("# locally edited\nversion: '1'\nrules: []\n")
        result = runner.invoke(cli_main.cli, ["install", "claude-code", "--force"])
        assert result.exit_code == 0
        assert "locally edited" not in (cz_dir / "policy.yaml").read_text()

    def test_top_level_no_args_prints_help(self, cli_main, runner):
        result = runner.invoke(cli_main.cli, [])
        # Click 8 prints help on missing subcommand and returns exit_code 0 or 2
        assert result.exit_code in (0, 2)
        assert "init" in result.output or "init" in (result.output or "")

    def test_install_no_subcommand_prints_help(self, cli_main, runner):
        result = runner.invoke(cli_main.cli, ["install"])
        assert result.exit_code in (0, 2)
        assert "claude-code" in result.output or "claude-code" in (result.output or "")

    # ---------- REGRESSION ----------

    def test_existing_third_party_hook_survives(self, cli_main, runner, fake_home):
        claude_dir = fake_home / ".claude"
        claude_dir.mkdir()
        (claude_dir / "settings.json").write_text(json.dumps({
            "hooks": {
                "PreToolUse": [
                    {
                        "matcher": "*",
                        "hooks": [{
                            "type": "command",
                            "command": "third-party-tool",
                            "timeout": 1000,
                        }],
                    }
                ]
            }
        }))
        runner.invoke(cli_main.cli, ["install", "claude-code"])
        cmds = _settings_pretool_commands(
            json.loads((claude_dir / "settings.json").read_text())
        )
        assert "third-party-tool" in cmds
        assert "controlzero hook-check" in cmds

    def test_unrelated_settings_keys_preserved(self, cli_main, runner, fake_home):
        claude_dir = fake_home / ".claude"
        claude_dir.mkdir()
        (claude_dir / "settings.json").write_text(json.dumps({
            "model": "claude-opus-4",
            "theme": "dark",
            "permissions": {"allow": ["Bash"]},
        }))
        runner.invoke(cli_main.cli, ["install", "claude-code"])
        merged = json.loads((claude_dir / "settings.json").read_text())
        assert merged["model"] == "claude-opus-4"
        assert merged["theme"] == "dark"
        assert merged["permissions"] == {"allow": ["Bash"]}

    def test_upgrade_from_old_block_replaces_not_duplicates(self, cli_main, runner, fake_home):
        # Simulate an installed v0.1 block (different timeout, but same command)
        claude_dir = fake_home / ".claude"
        claude_dir.mkdir()
        (claude_dir / "settings.json").write_text(json.dumps({
            "hooks": {
                "PreToolUse": [
                    {
                        "matcher": "*",
                        "hooks": [{
                            "type": "command",
                            "command": "controlzero hook-check",
                            "timeout": 1234,
                        }],
                    }
                ]
            }
        }))
        runner.invoke(cli_main.cli, ["install", "claude-code"])
        settings = json.loads((claude_dir / "settings.json").read_text())
        cmds = _settings_pretool_commands(settings)
        assert cmds.count("controlzero hook-check") == 1
        # New block should have the canonical timeout
        for block in settings["hooks"]["PreToolUse"]:
            for h in block.get("hooks", []):
                if h.get("command") == "controlzero hook-check":
                    assert h.get("timeout") == 5000


# ===========================================================================
# TestGeminiCliInstall
# ===========================================================================


class TestGeminiCliInstall:
    """Coverage for `controlzero install gemini-cli`."""

    # ---------- POSITIVE ----------

    def test_fresh_install_writes_policy_and_settings(self, cli_main, runner, fake_home):
        result = runner.invoke(cli_main.cli, ["install", "gemini-cli"])
        assert result.exit_code == 0, result.output
        assert (fake_home / ".controlzero" / "policy.yaml").exists()
        assert (fake_home / ".gemini" / "settings.json").exists()

    def test_policy_matches_bundled_template_byte_for_byte(self, cli_main, runner, fake_home):
        runner.invoke(cli_main.cli, ["install", "gemini-cli"])
        on_disk = (fake_home / ".controlzero" / "policy.yaml").read_text(encoding="utf-8")
        assert on_disk == _read_template("gemini-cli.yaml")

    def test_settings_json_is_valid_after_merge(self, cli_main, runner, fake_home):
        runner.invoke(cli_main.cli, ["install", "gemini-cli"])
        text = (fake_home / ".gemini" / "settings.json").read_text(encoding="utf-8")
        json.loads(text)

    def test_idempotent_second_install_no_duplicate_block(self, cli_main, runner, fake_home):
        runner.invoke(cli_main.cli, ["install", "gemini-cli"])
        runner.invoke(cli_main.cli, ["install", "gemini-cli"])
        settings = json.loads((fake_home / ".gemini" / "settings.json").read_text())
        cmds = _settings_gemini_pretool_commands(settings)
        assert cmds.count("controlzero hook-check") == 1

    def test_idempotent_state_is_byte_identical(self, cli_main, runner, fake_home):
        runner.invoke(cli_main.cli, ["install", "gemini-cli"])
        first = (fake_home / ".gemini" / "settings.json").read_text()
        runner.invoke(cli_main.cli, ["install", "gemini-cli"])
        second = (fake_home / ".gemini" / "settings.json").read_text()
        assert first == second

    def test_force_overwrites_existing_policy(self, cli_main, runner, fake_home):
        cz_dir = fake_home / ".controlzero"
        cz_dir.mkdir()
        (cz_dir / "policy.yaml").write_text("# stale\n")
        result = runner.invoke(cli_main.cli, ["install", "gemini-cli", "--force"])
        assert result.exit_code == 0
        assert "stale" not in (cz_dir / "policy.yaml").read_text()

    def test_settings_flag_honors_custom_path(self, cli_main, runner, tmp_path, fake_home):
        custom = tmp_path / "gemini-custom" / "settings.json"
        result = runner.invoke(
            cli_main.cli, ["install", "gemini-cli", "--settings", str(custom)]
        )
        assert result.exit_code == 0, result.output
        assert custom.exists()
        assert not (fake_home / ".gemini" / "settings.json").exists()

    def test_success_message_on_stdout(self, cli_main, runner, fake_home):
        result = runner.invoke(cli_main.cli, ["install", "gemini-cli"])
        assert result.exit_code == 0
        assert "Done" in result.output or "Updated" in result.output

    def test_block_shape_uses_BeforeTool(self, cli_main, runner, fake_home):
        runner.invoke(cli_main.cli, ["install", "gemini-cli"])
        settings = json.loads((fake_home / ".gemini" / "settings.json").read_text())
        assert "BeforeTool" in settings["hooks"]
        block = settings["hooks"]["BeforeTool"][0]
        # Nested format: {matcher, hooks: [{type, command, timeout}]}
        assert block["matcher"] == ".*"
        inner = block["hooks"][0]
        assert inner["command"] == "controlzero hook-check"
        assert inner["timeout"] == 5000
        assert inner["type"] == "command"

    # ---------- NEGATIVE ----------

    def test_missing_template_errors(self, cli_main, runner, fake_home, monkeypatch):
        bogus = fake_home / "no-such-templates"
        monkeypatch.setattr(cli_main, "TEMPLATE_DIR", bogus)
        result = runner.invoke(cli_main.cli, ["install", "gemini-cli"])
        assert result.exit_code == 1
        assert "template missing" in result.output

    def test_malformed_settings_json_errors(self, cli_main, runner, fake_home):
        gem_dir = fake_home / ".gemini"
        gem_dir.mkdir()
        (gem_dir / "settings.json").write_text("not json {{{")
        result = runner.invoke(cli_main.cli, ["install", "gemini-cli"])
        assert result.exit_code == 1
        assert "not valid JSON" in result.output

    def test_readonly_settings_file_surfaces_error(self, cli_main, runner, fake_home):
        if os.geteuid() == 0:
            pytest.skip("running as root; chmod cannot block writes")
        gem_dir = fake_home / ".gemini"
        gem_dir.mkdir()
        sf = gem_dir / "settings.json"
        sf.write_text("{}")
        sf.chmod(0o400)
        gem_dir.chmod(0o500)
        try:
            result = runner.invoke(cli_main.cli, ["install", "gemini-cli"])
            assert result.exit_code != 0 or isinstance(result.exception, PermissionError)
        finally:
            gem_dir.chmod(0o700)
            sf.chmod(0o600)

    def test_force_overwrites_policy_with_local_edits(self, cli_main, runner, fake_home):
        cz_dir = fake_home / ".controlzero"
        cz_dir.mkdir()
        (cz_dir / "policy.yaml").write_text("# locally edited\nversion: '1'\nrules: []\n")
        result = runner.invoke(cli_main.cli, ["install", "gemini-cli", "--force"])
        assert result.exit_code == 0
        assert "locally edited" not in (cz_dir / "policy.yaml").read_text()

    # ---------- REGRESSION ----------

    def test_existing_third_party_hook_survives(self, cli_main, runner, fake_home):
        gem_dir = fake_home / ".gemini"
        gem_dir.mkdir()
        (gem_dir / "settings.json").write_text(json.dumps({
            "hooks": {
                "BeforeTool": [
                    {"matcher": "*", "command": "another-hook", "timeout_ms": 1000}
                ]
            }
        }))
        runner.invoke(cli_main.cli, ["install", "gemini-cli"])
        cmds = _settings_gemini_pretool_commands(
            json.loads((gem_dir / "settings.json").read_text())
        )
        assert "another-hook" in cmds
        assert "controlzero hook-check" in cmds

    def test_unrelated_settings_keys_preserved(self, cli_main, runner, fake_home):
        gem_dir = fake_home / ".gemini"
        gem_dir.mkdir()
        (gem_dir / "settings.json").write_text(json.dumps({
            "theme": "Default",
            "model": "gemini-2.5-pro",
            "selectedAuthType": "oauth-personal",
        }))
        runner.invoke(cli_main.cli, ["install", "gemini-cli"])
        merged = json.loads((gem_dir / "settings.json").read_text())
        assert merged["theme"] == "Default"
        assert merged["model"] == "gemini-2.5-pro"
        assert merged["selectedAuthType"] == "oauth-personal"

    def test_upgrade_from_old_block_replaces_not_duplicates(self, cli_main, runner, fake_home):
        gem_dir = fake_home / ".gemini"
        gem_dir.mkdir()
        # Start with old flat-format entry
        (gem_dir / "settings.json").write_text(json.dumps({
            "hooks": {
                "BeforeTool": [
                    {"matcher": "*", "command": "controlzero hook-check", "timeout_ms": 1234}
                ]
            }
        }))
        runner.invoke(cli_main.cli, ["install", "gemini-cli"])
        settings = json.loads((gem_dir / "settings.json").read_text())
        cmds = _settings_gemini_pretool_commands(settings)
        assert cmds.count("controlzero hook-check") == 1
        # After upgrade, block should use new nested format
        block = settings["hooks"]["BeforeTool"][0]
        assert "hooks" in block  # nested format
        assert block["hooks"][0]["timeout"] == 5000


# ===========================================================================
# TestCodexCliInstall
# ===========================================================================


class TestCodexCliInstall:
    """Coverage for `controlzero install codex-cli`."""

    # ---------- POSITIVE ----------

    def test_fresh_install_writes_policy_hooks_json_and_config(self, cli_main, runner, fake_home):
        result = runner.invoke(cli_main.cli, ["install", "codex-cli"])
        assert result.exit_code == 0, result.output
        assert (fake_home / ".controlzero" / "policy.yaml").exists()
        assert (fake_home / ".codex" / "hooks.json").exists()
        assert (fake_home / ".codex" / "config.toml").exists()
        # Legacy wrapper script must NOT be created
        assert not (fake_home / ".codex" / "hooks" / "controlzero.sh").exists()

    def test_policy_matches_bundled_template_byte_for_byte(self, cli_main, runner, fake_home):
        runner.invoke(cli_main.cli, ["install", "codex-cli"])
        on_disk = (fake_home / ".controlzero" / "policy.yaml").read_text(encoding="utf-8")
        assert on_disk == _read_template("codex-cli.yaml")

    def test_hooks_json_contains_hook_check(self, cli_main, runner, fake_home):
        runner.invoke(cli_main.cli, ["install", "codex-cli"])
        hooks_path = fake_home / ".codex" / "hooks.json"
        hooks_data = json.loads(hooks_path.read_text(encoding="utf-8"))
        cmds = _codex_hooks_json_commands(hooks_data)
        assert "controlzero hook-check" in cmds
        # Verify the nested structure: matcher + hooks with type/command/timeout
        block = hooks_data["hooks"]["PreToolUse"][0]
        assert block["matcher"] == ".*"
        inner = block["hooks"][0]
        assert inner["type"] == "command"
        assert inner["command"] == "controlzero hook-check"
        assert inner["timeout"] == 5000

    @pytest.mark.skipif(not HAS_TOMLLIB, reason="tomllib requires Python 3.11+")
    def test_config_toml_is_valid_toml_after_merge(self, cli_main, runner, fake_home):
        runner.invoke(cli_main.cli, ["install", "codex-cli"])
        text = (fake_home / ".codex" / "config.toml").read_bytes()
        parsed = tomllib.loads(text.decode("utf-8"))
        assert "features" in parsed
        assert parsed["features"]["codex_hooks"] is True
        # Legacy tool_approval_policy must NOT be present in a fresh install
        assert "tool_approval_policy" not in parsed

    def test_idempotent_second_install_no_duplicate_block(self, cli_main, runner, fake_home):
        runner.invoke(cli_main.cli, ["install", "codex-cli"])
        runner.invoke(cli_main.cli, ["install", "codex-cli"])
        hooks_data = json.loads(
            (fake_home / ".codex" / "hooks.json").read_text()
        )
        cmds = _codex_hooks_json_commands(hooks_data)
        assert cmds.count("controlzero hook-check") == 1

    def test_force_overwrites_existing_policy(self, cli_main, runner, fake_home):
        cz_dir = fake_home / ".controlzero"
        cz_dir.mkdir()
        (cz_dir / "policy.yaml").write_text("# stale\n")
        result = runner.invoke(cli_main.cli, ["install", "codex-cli", "--force"])
        assert result.exit_code == 0
        assert "stale" not in (cz_dir / "policy.yaml").read_text()

    def test_force_rewrites_existing_block_in_place(self, cli_main, runner, fake_home):
        # First install lays the hooks.json down.
        runner.invoke(cli_main.cli, ["install", "codex-cli"])
        # Tamper with the hooks.json command so we can prove --force replaces it.
        hooks_path = fake_home / ".codex" / "hooks.json"
        hooks_data = json.loads(hooks_path.read_text())
        hooks_data["hooks"]["PreToolUse"][0]["hooks"][0]["command"] = "controlzero hook-check --OLD"
        hooks_path.write_text(json.dumps(hooks_data))
        result = runner.invoke(cli_main.cli, ["install", "codex-cli", "--force"])
        assert result.exit_code == 0
        hooks_data2 = json.loads(hooks_path.read_text())
        cmds = _codex_hooks_json_commands(hooks_data2)
        assert cmds.count("controlzero hook-check") == 1
        assert "controlzero hook-check --OLD" not in cmds

    def test_config_flag_honors_custom_path(self, cli_main, runner, tmp_path, fake_home):
        custom = tmp_path / "codex-custom" / "config.toml"
        result = runner.invoke(
            cli_main.cli, ["install", "codex-cli", "--config", str(custom)]
        )
        assert result.exit_code == 0, result.output
        assert custom.exists()
        assert not (fake_home / ".codex" / "config.toml").exists()

    def test_success_message_on_stdout(self, cli_main, runner, fake_home):
        result = runner.invoke(cli_main.cli, ["install", "codex-cli"])
        assert result.exit_code == 0
        assert "Done" in result.output or "Updated" in result.output

    # ---------- NEGATIVE ----------

    def test_missing_template_errors(self, cli_main, runner, fake_home, monkeypatch):
        bogus = fake_home / "no-such-templates"
        monkeypatch.setattr(cli_main, "TEMPLATE_DIR", bogus)
        result = runner.invoke(cli_main.cli, ["install", "codex-cli"])
        assert result.exit_code == 1
        assert "template missing" in result.output

    def test_existing_block_without_force_is_a_noop(self, cli_main, runner, fake_home):
        runner.invoke(cli_main.cli, ["install", "codex-cli"])
        before_hooks = (fake_home / ".codex" / "hooks.json").read_text()
        before_toml = (fake_home / ".codex" / "config.toml").read_text()
        result = runner.invoke(cli_main.cli, ["install", "codex-cli"])
        after_hooks = (fake_home / ".codex" / "hooks.json").read_text()
        after_toml = (fake_home / ".codex" / "config.toml").read_text()
        assert result.exit_code == 0
        assert before_hooks == after_hooks
        assert before_toml == after_toml
        assert "Skipping" in result.output

    def test_force_overwrites_policy_with_local_edits(self, cli_main, runner, fake_home):
        cz_dir = fake_home / ".controlzero"
        cz_dir.mkdir()
        (cz_dir / "policy.yaml").write_text("# locally edited\nversion: '1'\nrules: []\n")
        result = runner.invoke(cli_main.cli, ["install", "codex-cli", "--force"])
        assert result.exit_code == 0
        assert "locally edited" not in (cz_dir / "policy.yaml").read_text()

    def test_malformed_existing_toml_documented(self, cli_main, runner, fake_home):
        """The codex installer does NOT parse config.toml -- it does a string
        append. A garbage config.toml is therefore preserved as-is and our
        block is appended after it. Document the actual behavior so reviewers
        know this is intentional (TOML writer would be a heavy dep) and what
        the failure mode is.
        """
        codex_dir = fake_home / ".codex"
        codex_dir.mkdir()
        (codex_dir / "config.toml").write_text("this is not [valid toml\n")
        result = runner.invoke(cli_main.cli, ["install", "codex-cli"])
        assert result.exit_code == 0
        text = (codex_dir / "config.toml").read_text()
        assert "this is not [valid toml" in text  # preserved
        assert "[features]" in text   # appended
        if HAS_TOMLLIB:
            with pytest.raises(tomllib.TOMLDecodeError):
                tomllib.loads(text)

    # ---------- REGRESSION ----------

    def test_existing_unrelated_toml_block_survives(self, cli_main, runner, fake_home):
        codex_dir = fake_home / ".codex"
        codex_dir.mkdir()
        (codex_dir / "config.toml").write_text(
            '[model]\nname = "gpt-5"\n\n[shell]\ndefault = "bash"\n'
        )
        runner.invoke(cli_main.cli, ["install", "codex-cli"])
        text = (codex_dir / "config.toml").read_text()
        assert '[model]' in text
        assert 'name = "gpt-5"' in text
        assert '[shell]' in text
        assert '[features]' in text
        if HAS_TOMLLIB:
            parsed = tomllib.loads(text)
            assert parsed["model"]["name"] == "gpt-5"
            assert parsed["shell"]["default"] == "bash"
            assert parsed["features"]["codex_hooks"] is True

    def test_marker_based_idempotency_with_other_blocks(self, cli_main, runner, fake_home):
        codex_dir = fake_home / ".codex"
        codex_dir.mkdir()
        (codex_dir / "config.toml").write_text(
            '[model]\nname = "gpt-5"\n'
        )
        runner.invoke(cli_main.cli, ["install", "codex-cli"])
        runner.invoke(cli_main.cli, ["install", "codex-cli"])
        text = (codex_dir / "config.toml").read_text()
        assert text.count("# controlzero:features") == 1
        assert text.count("[features]") == 1
        assert text.count("[model]") == 1


# ===========================================================================
# TestHookCheckEvaluator
# ===========================================================================


class TestHookCheckEvaluator:
    """Coverage for `controlzero hook-check`.

    Documented behavior (from main.py:330-400):
        * Allow / no match for deny -> exit 0, empty stdout
        * Deny matched              -> exit 2, JSON {"decision":"block",...} on stdout
        * Empty stdin               -> exit 0 (fail-open at CLI to never break agents)
        * Malformed JSON            -> exit 0, warning to stderr
        * No policy file at all     -> exit 0, warning to stderr
        * Invalid policy file       -> exit 0, warning to stderr
        * Missing tool_name         -> exit 0, warning to stderr

    Note that the hook-check command intentionally fails OPEN at the CLI
    layer (`# Never brick the agent`). The fail-CLOSED mandate from the
    project audit applies to the production gateway, not this developer-
    facing local hook. Tests assert the SHIPPED behavior.
    """

    # ---------- POSITIVE ----------

    def test_allow_rule_exit_zero(self, runner, tmp_path):
        from controlzero.cli.main import cli
        p = tmp_path / "p.yaml"
        _write_yaml_policy(p, [{"allow": "*"}])
        payload = json.dumps({"tool_name": "Bash", "tool_input": {"command": "ls"}})
        result = runner.invoke(cli, ["hook-check", "--policy", str(p)], input=payload)
        assert result.exit_code == 0
        # Must NOT emit a block-decision JSON on allow. Loguru audit lines
        # can bleed into the combined output stream so we filter for the
        # block keyword instead of asserting empty.
        assert '"decision": "block"' not in result.output

    def test_deny_rule_exit_two_with_json_stdout(self, runner, tmp_path):
        from controlzero.cli.main import cli
        p = tmp_path / "p.yaml"
        _write_yaml_policy(p, [{"deny": "Bash", "reason": "no shells"}, {"allow": "*"}])
        payload = json.dumps({"tool_name": "Bash", "tool_input": {}})
        result = runner.invoke(cli, ["hook-check", "--policy", str(p)], input=payload)
        assert result.exit_code == 2
        # CliRunner mixes stderr into output; extract the JSON line
        json_line = [l for l in result.output.strip().splitlines() if l.startswith("{")][0]
        decision = json.loads(json_line)
        assert decision["decision"] == "block"
        assert "[Control Zero]" in decision["reason"]

    def test_glob_match_blocks_drop_table(self, runner, tmp_path):
        from controlzero.cli.main import cli
        p = tmp_path / "p.yaml"
        _write_yaml_policy(
            p, [{"deny": "mcp__db__drop_*"}, {"allow": "*"}],
        )
        payload = json.dumps({"tool_name": "mcp__db__drop_table"})
        result = runner.invoke(cli, ["hook-check", "--policy", str(p)], input=payload)
        assert result.exit_code == 2

    def test_glob_does_not_overmatch(self, runner, tmp_path):
        from controlzero.cli.main import cli
        p = tmp_path / "p.yaml"
        _write_yaml_policy(
            p, [{"deny": "mcp__db__drop_*"}, {"allow": "*"}],
        )
        payload = json.dumps({"tool_name": "mcp__db__read_table"})
        result = runner.invoke(cli, ["hook-check", "--policy", str(p)], input=payload)
        assert result.exit_code == 0

    def test_catch_all_allow_at_end(self, runner, tmp_path):
        from controlzero.cli.main import cli
        p = tmp_path / "p.yaml"
        _write_yaml_policy(
            p, [{"deny": "Specific"}, {"allow": "*"}],
        )
        payload = json.dumps({"tool_name": "AnythingElse"})
        result = runner.invoke(cli, ["hook-check", "--policy", str(p)], input=payload)
        assert result.exit_code == 0

    def test_camel_case_keys_accepted(self, runner, tmp_path):
        from controlzero.cli.main import cli
        p = tmp_path / "p.yaml"
        _write_yaml_policy(p, [{"deny": "Danger"}, {"allow": "*"}])
        payload = json.dumps({"toolName": "Danger", "toolInput": {}})
        result = runner.invoke(cli, ["hook-check", "--policy", str(p)], input=payload)
        assert result.exit_code == 2

    def test_first_match_wins_deny_then_allow(self, runner, tmp_path):
        """Document rule ordering semantics: first matching rule wins."""
        from controlzero.cli.main import cli
        p = tmp_path / "p.yaml"
        _write_yaml_policy(p, [{"deny": "Bash"}, {"allow": "Bash"}])
        payload = json.dumps({"tool_name": "Bash"})
        result = runner.invoke(cli, ["hook-check", "--policy", str(p)], input=payload)
        assert result.exit_code == 2  # deny first -> deny

    def test_first_match_wins_allow_then_deny(self, runner, tmp_path):
        """Inverse of the above: allow listed first means allow wins."""
        from controlzero.cli.main import cli
        p = tmp_path / "p.yaml"
        _write_yaml_policy(p, [{"allow": "Bash"}, {"deny": "Bash"}])
        payload = json.dumps({"tool_name": "Bash"})
        result = runner.invoke(cli, ["hook-check", "--policy", str(p)], input=payload)
        assert result.exit_code == 0

    # ---------- NEGATIVE / fail-open ----------

    def test_invalid_json_stdin_fails_open(self, runner):
        from controlzero.cli.main import cli
        result = runner.invoke(cli, ["hook-check"], input="not json {{{")
        assert result.exit_code == 0
        assert "not JSON" in (result.output or "") or "allowing" in (result.output or "")

    def test_empty_stdin_fails_open(self, runner):
        from controlzero.cli.main import cli
        result = runner.invoke(cli, ["hook-check"], input="")
        assert result.exit_code == 0

    def test_missing_policy_file_fails_open(self, runner, tmp_path, monkeypatch):
        from controlzero.cli.main import cli
        import controlzero.cli.main as cm
        monkeypatch.chdir(tmp_path)
        monkeypatch.setattr(cm, "GLOBAL_POLICY_PATH", tmp_path / "no.yaml")
        payload = json.dumps({"tool_name": "Bash"})
        result = runner.invoke(cli, ["hook-check"], input=payload)
        # Fail-open contract: exit 0. Post-#228 Phase 2 the
        # carve-out (no api key + no enrollment + no policy file)
        # also goes fail-open but with a louder "Not enrolled"
        # banner; the contract is unchanged, the phrasing moved.
        assert result.exit_code == 0
        output = (result.output or "").lower()
        assert "no policy" in output or "not enrolled" in output

    def test_unreadable_policy_file_fails_open(self, runner, tmp_path):
        if os.geteuid() == 0:
            pytest.skip("running as root; chmod cannot block reads")
        from controlzero.cli.main import cli
        p = tmp_path / "p.yaml"
        _write_yaml_policy(p, [{"allow": "*"}])
        p.chmod(0o000)
        try:
            payload = json.dumps({"tool_name": "Bash"})
            result = runner.invoke(cli, ["hook-check", "--policy", str(p)], input=payload)
            # Documented: invalid/unreadable policy -> log + allow.
            assert result.exit_code == 0
        finally:
            p.chmod(0o600)

    def test_invalid_policy_yaml_fails_open(self, runner, tmp_path):
        from controlzero.cli.main import cli
        p = tmp_path / "p.yaml"
        p.write_text("rules: not-a-list")
        payload = json.dumps({"tool_name": "Bash"})
        result = runner.invoke(cli, ["hook-check", "--policy", str(p)], input=payload)
        assert result.exit_code == 0

    def test_missing_tool_name_fails_open(self, runner, tmp_path):
        from controlzero.cli.main import cli
        p = tmp_path / "p.yaml"
        _write_yaml_policy(p, [{"deny": "*"}])
        # Even with deny-all, missing tool_name should pass through (logged).
        result = runner.invoke(cli, ["hook-check", "--policy", str(p)], input="{}")
        assert result.exit_code == 0

    def test_audit_log_unwritable_does_not_block_decision(self, runner, tmp_path, monkeypatch):
        """If the audit log path is unwritable the SDK falls back to stderr
        logging but the decision MUST still be returned. This is the local-
        first promise: enforcement runs even if audit storage is broken.
        """
        if os.geteuid() == 0:
            pytest.skip("running as root; chmod cannot block writes")
        from controlzero.cli.main import cli
        import controlzero.cli.main as cm
        # Point audit log at a read-only directory.
        ro = tmp_path / "ro"
        ro.mkdir()
        ro.chmod(0o500)
        monkeypatch.setattr(cm, "GLOBAL_AUDIT_PATH", ro / "audit.log")
        try:
            p = tmp_path / "p.yaml"
            _write_yaml_policy(p, [{"deny": "Bash"}, {"allow": "*"}])
            payload = json.dumps({"tool_name": "Bash"})
            result = runner.invoke(cli, ["hook-check", "--policy", str(p)], input=payload)
            assert result.exit_code == 2  # decision still propagated
        finally:
            ro.chmod(0o700)

    def test_per_project_policy_overrides_global(self, runner, tmp_path, monkeypatch):
        from controlzero.cli.main import cli
        import controlzero.cli.main as cm
        project = tmp_path / "proj"
        project.mkdir()
        monkeypatch.chdir(project)
        # Permissive global, restrictive project
        global_policy = tmp_path / "global.yaml"
        _write_yaml_policy(global_policy, [{"allow": "*"}])
        monkeypatch.setattr(cm, "GLOBAL_POLICY_PATH", global_policy)
        _write_yaml_policy(project / "controlzero.yaml", [{"deny": "*"}])
        payload = json.dumps({"tool_name": "Bash"})
        result = runner.invoke(cli, ["hook-check"], input=payload)
        assert result.exit_code == 2

    def test_explicit_policy_flag_wins_over_both(self, runner, tmp_path, monkeypatch):
        from controlzero.cli.main import cli
        import controlzero.cli.main as cm
        project = tmp_path / "proj"
        project.mkdir()
        monkeypatch.chdir(project)
        _write_yaml_policy(project / "controlzero.yaml", [{"deny": "*"}])
        global_policy = tmp_path / "global.yaml"
        _write_yaml_policy(global_policy, [{"deny": "*"}])
        monkeypatch.setattr(cm, "GLOBAL_POLICY_PATH", global_policy)
        explicit = tmp_path / "explicit.yaml"
        _write_yaml_policy(explicit, [{"allow": "*"}])
        payload = json.dumps({"tool_name": "Bash"})
        result = runner.invoke(cli, ["hook-check", "--policy", str(explicit)], input=payload)
        assert result.exit_code == 0


# ===========================================================================
# TestCrossInstallerRegression
# ===========================================================================


class TestCrossInstallerRegression:
    """All three installers must coexist without clobbering each other."""

    def test_install_all_three_in_sequence(self, cli_main, runner, fake_home):
        for sub in ("claude-code", "gemini-cli", "codex-cli"):
            result = runner.invoke(cli_main.cli, ["install", sub])
            assert result.exit_code == 0, f"{sub} failed: {result.output}"
        assert (fake_home / ".claude" / "settings.json").exists()
        assert (fake_home / ".gemini" / "settings.json").exists()
        assert (fake_home / ".codex" / "config.toml").exists()
        assert (fake_home / ".codex" / "hooks.json").exists()
        assert (fake_home / ".controlzero" / "policy.yaml").exists()

    def test_global_policy_is_first_writers_template(self, cli_main, runner, fake_home):
        """Document the actual behavior: the FIRST installer writes the global
        policy and subsequent installers see it exists and skip (without
        --force). So the policy on disk matches whichever installer ran first.
        Reviewers: this is intentional. Global policy is shared across agents
        because the rule semantics are agent-agnostic.
        """
        runner.invoke(cli_main.cli, ["install", "claude-code"])
        first_policy = (fake_home / ".controlzero" / "policy.yaml").read_text()
        runner.invoke(cli_main.cli, ["install", "gemini-cli"])
        second_policy = (fake_home / ".controlzero" / "policy.yaml").read_text()
        runner.invoke(cli_main.cli, ["install", "codex-cli"])
        third_policy = (fake_home / ".controlzero" / "policy.yaml").read_text()
        assert first_policy == second_policy == third_policy
        assert first_policy == _read_template("claude-code.yaml")

    def test_force_on_last_installer_overwrites_global_policy(self, cli_main, runner, fake_home):
        runner.invoke(cli_main.cli, ["install", "claude-code"])
        runner.invoke(cli_main.cli, ["install", "codex-cli", "--force"])
        on_disk = (fake_home / ".controlzero" / "policy.yaml").read_text()
        assert on_disk == _read_template("codex-cli.yaml")

    def test_each_installer_owns_its_own_config_file(self, cli_main, runner, fake_home):
        runner.invoke(cli_main.cli, ["install", "claude-code"])
        runner.invoke(cli_main.cli, ["install", "gemini-cli"])
        runner.invoke(cli_main.cli, ["install", "codex-cli"])

        claude_settings = json.loads((fake_home / ".claude" / "settings.json").read_text())
        gemini_settings = json.loads((fake_home / ".gemini" / "settings.json").read_text())
        codex_hooks = json.loads((fake_home / ".codex" / "hooks.json").read_text())

        assert "controlzero hook-check" in _settings_pretool_commands(claude_settings)
        assert "controlzero hook-check" in _settings_gemini_pretool_commands(gemini_settings)
        assert "controlzero hook-check" in _codex_hooks_json_commands(codex_hooks)

    def test_manual_removal_of_one_does_not_affect_others(self, cli_main, runner, fake_home):
        # Install all three, manually strip claude-code's hook, verify the
        # other two still hold.
        for sub in ("claude-code", "gemini-cli", "codex-cli"):
            runner.invoke(cli_main.cli, ["install", sub])

        cs_path = fake_home / ".claude" / "settings.json"
        cs = json.loads(cs_path.read_text())
        cs["hooks"]["PreToolUse"] = []
        cs_path.write_text(json.dumps(cs))

        gemini_settings = json.loads((fake_home / ".gemini" / "settings.json").read_text())
        codex_hooks = json.loads((fake_home / ".codex" / "hooks.json").read_text())
        assert "controlzero hook-check" in _settings_gemini_pretool_commands(gemini_settings)
        assert "controlzero hook-check" in _codex_hooks_json_commands(codex_hooks)

    def test_reinstall_after_manual_removal_repairs_only_target(self, cli_main, runner, fake_home):
        for sub in ("claude-code", "gemini-cli", "codex-cli"):
            runner.invoke(cli_main.cli, ["install", sub])

        # Wipe gemini's hook
        gs_path = fake_home / ".gemini" / "settings.json"
        gs = json.loads(gs_path.read_text())
        gs["hooks"]["BeforeTool"] = []
        gs_path.write_text(json.dumps(gs))

        # Re-install gemini only -- claude/codex must be untouched
        before_claude = (fake_home / ".claude" / "settings.json").read_text()
        before_codex_toml = (fake_home / ".codex" / "config.toml").read_text()
        before_codex_hooks = (fake_home / ".codex" / "hooks.json").read_text()
        runner.invoke(cli_main.cli, ["install", "gemini-cli"])
        after_claude = (fake_home / ".claude" / "settings.json").read_text()
        after_codex_toml = (fake_home / ".codex" / "config.toml").read_text()
        after_codex_hooks = (fake_home / ".codex" / "hooks.json").read_text()

        assert before_claude == after_claude
        assert before_codex_toml == after_codex_toml
        assert before_codex_hooks == after_codex_hooks
        # And gemini is repaired
        gs2 = json.loads(gs_path.read_text())
        assert "controlzero hook-check" in _settings_gemini_pretool_commands(gs2)


# ===========================================================================
# TestUninstall
# ===========================================================================


class TestUninstall:
    """Coverage for `controlzero uninstall {claude-code,gemini-cli,codex-cli}`.

    Each subcommand is tested with the full install-verify-uninstall-verify
    lifecycle plus preservation of third-party hooks.
    """

    # ---------- Claude Code ----------

    def test_claude_code_install_then_uninstall(self, cli_main, runner, fake_home):
        runner.invoke(cli_main.cli, ["install", "claude-code"])
        settings = json.loads((fake_home / ".claude" / "settings.json").read_text())
        assert "controlzero hook-check" in _settings_pretool_commands(settings)

        result = runner.invoke(cli_main.cli, ["uninstall", "claude-code"])
        assert result.exit_code == 0
        assert "Removed controlzero hook from Claude Code" in result.output
        settings2 = json.loads((fake_home / ".claude" / "settings.json").read_text())
        assert "controlzero hook-check" not in _settings_pretool_commands(settings2)

    def test_claude_code_uninstall_preserves_third_party_hooks(self, cli_main, runner, fake_home):
        # Pre-populate a third-party hook before installing ours
        claude_dir = fake_home / ".claude"
        claude_dir.mkdir(parents=True, exist_ok=True)
        third_party = {
            "hooks": {
                "PreToolUse": [
                    {
                        "matcher": "Bash",
                        "hooks": [{"type": "command", "command": "my-other-tool check"}],
                    }
                ]
            }
        }
        (claude_dir / "settings.json").write_text(json.dumps(third_party))

        runner.invoke(cli_main.cli, ["install", "claude-code"])
        settings = json.loads((claude_dir / "settings.json").read_text())
        cmds = _settings_pretool_commands(settings)
        assert "controlzero hook-check" in cmds
        assert "my-other-tool check" in cmds

        runner.invoke(cli_main.cli, ["uninstall", "claude-code"])
        settings2 = json.loads((claude_dir / "settings.json").read_text())
        cmds2 = _settings_pretool_commands(settings2)
        assert "controlzero hook-check" not in cmds2
        assert "my-other-tool check" in cmds2

    def test_claude_code_uninstall_idempotent_no_hook(self, cli_main, runner, fake_home):
        result = runner.invoke(cli_main.cli, ["uninstall", "claude-code"])
        assert result.exit_code == 0
        assert "No controlzero hook found in Claude Code" in result.output

    def test_claude_code_uninstall_idempotent_after_uninstall(self, cli_main, runner, fake_home):
        runner.invoke(cli_main.cli, ["install", "claude-code"])
        runner.invoke(cli_main.cli, ["uninstall", "claude-code"])
        result = runner.invoke(cli_main.cli, ["uninstall", "claude-code"])
        assert result.exit_code == 0
        assert "No controlzero hook found in Claude Code" in result.output

    def test_claude_code_uninstall_preserves_policy_and_audit(self, cli_main, runner, fake_home):
        runner.invoke(cli_main.cli, ["install", "claude-code"])
        policy_path = fake_home / ".controlzero" / "policy.yaml"
        audit_path = fake_home / ".controlzero" / "audit.log"
        audit_path.write_text("some audit data\n")
        assert policy_path.exists()

        runner.invoke(cli_main.cli, ["uninstall", "claude-code"])
        assert policy_path.exists(), "policy.yaml must not be deleted"
        assert audit_path.exists(), "audit.log must not be deleted"

    def test_claude_code_uninstall_custom_settings_path(self, cli_main, runner, tmp_path, fake_home):
        custom = tmp_path / "custom" / "settings.json"
        runner.invoke(cli_main.cli, ["install", "claude-code", "--settings", str(custom)])
        result = runner.invoke(
            cli_main.cli, ["uninstall", "claude-code", "--settings", str(custom)]
        )
        assert result.exit_code == 0
        assert "Removed controlzero hook from Claude Code" in result.output
        settings = json.loads(custom.read_text())
        assert "controlzero hook-check" not in _settings_pretool_commands(settings)

    # ---------- Gemini CLI ----------

    def test_gemini_cli_install_then_uninstall(self, cli_main, runner, fake_home):
        runner.invoke(cli_main.cli, ["install", "gemini-cli"])
        settings = json.loads((fake_home / ".gemini" / "settings.json").read_text())
        assert "controlzero hook-check" in _settings_gemini_pretool_commands(settings)

        result = runner.invoke(cli_main.cli, ["uninstall", "gemini-cli"])
        assert result.exit_code == 0
        assert "Removed controlzero hook from Gemini CLI" in result.output
        settings2 = json.loads((fake_home / ".gemini" / "settings.json").read_text())
        assert "controlzero hook-check" not in _settings_gemini_pretool_commands(settings2)

    def test_gemini_cli_uninstall_preserves_third_party_hooks(self, cli_main, runner, fake_home):
        gemini_dir = fake_home / ".gemini"
        gemini_dir.mkdir(parents=True, exist_ok=True)
        third_party = {
            "hooks": {
                "BeforeTool": [
                    {"matcher": "*", "command": "some-other-linter check", "timeout_ms": 3000}
                ]
            }
        }
        (gemini_dir / "settings.json").write_text(json.dumps(third_party))

        runner.invoke(cli_main.cli, ["install", "gemini-cli"])
        settings = json.loads((gemini_dir / "settings.json").read_text())
        cmds = _settings_gemini_pretool_commands(settings)
        assert "controlzero hook-check" in cmds
        assert "some-other-linter check" in cmds

        runner.invoke(cli_main.cli, ["uninstall", "gemini-cli"])
        settings2 = json.loads((gemini_dir / "settings.json").read_text())
        cmds2 = _settings_gemini_pretool_commands(settings2)
        assert "controlzero hook-check" not in cmds2
        assert "some-other-linter check" in cmds2

    def test_gemini_cli_uninstall_idempotent_no_hook(self, cli_main, runner, fake_home):
        result = runner.invoke(cli_main.cli, ["uninstall", "gemini-cli"])
        assert result.exit_code == 0
        assert "No controlzero hook found in Gemini CLI" in result.output

    def test_gemini_cli_uninstall_preserves_policy_and_audit(self, cli_main, runner, fake_home):
        runner.invoke(cli_main.cli, ["install", "gemini-cli"])
        policy_path = fake_home / ".controlzero" / "policy.yaml"
        audit_path = fake_home / ".controlzero" / "audit.log"
        audit_path.write_text("gemini audit data\n")

        runner.invoke(cli_main.cli, ["uninstall", "gemini-cli"])
        assert policy_path.exists(), "policy.yaml must not be deleted"
        assert audit_path.exists(), "audit.log must not be deleted"

    def test_gemini_cli_uninstall_custom_settings_path(self, cli_main, runner, tmp_path, fake_home):
        custom = tmp_path / "custom_gemini" / "settings.json"
        runner.invoke(cli_main.cli, ["install", "gemini-cli", "--settings", str(custom)])
        result = runner.invoke(
            cli_main.cli, ["uninstall", "gemini-cli", "--settings", str(custom)]
        )
        assert result.exit_code == 0
        assert "Removed controlzero hook from Gemini CLI" in result.output

    # ---------- Codex CLI ----------

    def test_codex_cli_install_then_uninstall(self, cli_main, runner, fake_home):
        runner.invoke(cli_main.cli, ["install", "codex-cli"])
        cfg_path = fake_home / ".codex" / "config.toml"
        hooks_path = fake_home / ".codex" / "hooks.json"
        assert "features" in cfg_path.read_text()
        assert hooks_path.exists()
        hooks_data = json.loads(hooks_path.read_text())
        assert "controlzero hook-check" in _codex_hooks_json_commands(hooks_data)

        result = runner.invoke(cli_main.cli, ["uninstall", "codex-cli"])
        assert result.exit_code == 0
        assert "Removed controlzero hook from Codex CLI" in result.output
        assert "controlzero:features" not in cfg_path.read_text()
        # hooks.json should have controlzero entry removed
        hooks_data2 = json.loads(hooks_path.read_text())
        assert "controlzero hook-check" not in _codex_hooks_json_commands(hooks_data2)

    def test_codex_cli_uninstall_preserves_third_party_toml(self, cli_main, runner, fake_home):
        codex_dir = fake_home / ".codex"
        codex_dir.mkdir(parents=True, exist_ok=True)
        (codex_dir / "config.toml").write_text(
            '[model]\nname = "gpt-4"\ntemperature = 0.7\n'
        )

        runner.invoke(cli_main.cli, ["install", "codex-cli"])
        cfg_text = (codex_dir / "config.toml").read_text()
        assert "[model]" in cfg_text
        assert "controlzero:features" in cfg_text

        runner.invoke(cli_main.cli, ["uninstall", "codex-cli"])
        cfg_text2 = (codex_dir / "config.toml").read_text()
        assert "[model]" in cfg_text2
        assert 'name = "gpt-4"' in cfg_text2
        assert "controlzero:features" not in cfg_text2

    def test_codex_cli_uninstall_idempotent_no_hook(self, cli_main, runner, fake_home):
        result = runner.invoke(cli_main.cli, ["uninstall", "codex-cli"])
        assert result.exit_code == 0
        assert "No controlzero hook found in Codex CLI" in result.output

    def test_codex_cli_uninstall_preserves_policy_and_audit(self, cli_main, runner, fake_home):
        runner.invoke(cli_main.cli, ["install", "codex-cli"])
        policy_path = fake_home / ".controlzero" / "policy.yaml"
        audit_path = fake_home / ".controlzero" / "audit.log"
        audit_path.write_text("codex audit data\n")

        runner.invoke(cli_main.cli, ["uninstall", "codex-cli"])
        assert policy_path.exists(), "policy.yaml must not be deleted"
        assert audit_path.exists(), "audit.log must not be deleted"
        # hooks.json should still exist (file not deleted, just entry removed)
        assert (fake_home / ".codex" / "hooks.json").exists()

    def test_codex_cli_uninstall_custom_config_path(self, cli_main, runner, tmp_path, fake_home):
        custom = tmp_path / "custom_codex" / "config.toml"
        runner.invoke(cli_main.cli, ["install", "codex-cli", "--config", str(custom)])
        result = runner.invoke(
            cli_main.cli, ["uninstall", "codex-cli", "--config", str(custom)]
        )
        assert result.exit_code == 0
        assert "Removed controlzero hook from Codex CLI" in result.output
