"""Tests for the hook-check hosted-mode background policy refresh.

When a user runs `controlzero install claude-code --api-key cz_live_...`
and later hook-check runs, the cached policy.yaml can become stale. Phase
6 adds a hosted-mode refresh path that uses the Bearer API key (no
enrollment required) to re-pull the signed .czpolicy bundle and rewrite
the local policy file.
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

import pytest
import yaml


def _write_stale_policy(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        yaml.safe_dump({"version": "1", "rules": [{"allow": "*"}]}),
        encoding="utf-8",
    )
    # Force staleness by setting mtime in the past.
    import os
    past = os.path.getmtime(path) - 10 * 60  # 10 minutes ago
    os.utime(path, (past, past))


def test_hosted_refresh_rewrites_policy_file(tmp_path, monkeypatch):
    """Stale policy + CONTROLZERO_API_KEY + no enrollment => hosted pull."""
    from controlzero.cli.main import _maybe_refresh_policy

    policy_path = tmp_path / "policy.yaml"
    _write_stale_policy(policy_path)

    monkeypatch.setenv("CONTROLZERO_API_KEY", "cz_live_fakekey")

    fresh_policy = {
        "version": "1",
        "rules": [{"effect": "deny", "action": "send_email", "reason": "remote"}],
    }

    def fake_load_hosted_policy(api_key):
        assert api_key == "cz_live_fakekey"
        return fresh_policy, object()

    with patch("controlzero.hosted_policy.load_hosted_policy", side_effect=fake_load_hosted_policy), \
         patch("controlzero.cli.main._load_enrollment_state", return_value=None):
        _maybe_refresh_policy(policy_path, state_dir=tmp_path, threshold_s=60, timeout_s=5)

    # File should now contain the fresh policy.
    reloaded = yaml.safe_load(policy_path.read_text(encoding="utf-8"))
    assert reloaded["rules"][0]["action"] == "send_email"
    assert reloaded["rules"][0]["effect"] == "deny"


def test_hosted_refresh_noop_without_api_key(tmp_path, monkeypatch):
    """No enrollment and no CONTROLZERO_API_KEY => skip (pure-local mode)."""
    from controlzero.cli.main import _maybe_refresh_policy

    policy_path = tmp_path / "policy.yaml"
    _write_stale_policy(policy_path)
    monkeypatch.delenv("CONTROLZERO_API_KEY", raising=False)

    before = policy_path.read_text(encoding="utf-8")
    with patch("controlzero.cli.main._load_enrollment_state", return_value=None):
        _maybe_refresh_policy(policy_path, state_dir=tmp_path, threshold_s=60, timeout_s=1)
    after = policy_path.read_text(encoding="utf-8")

    assert before == after


def test_hosted_refresh_enrollment_takes_precedence(tmp_path, monkeypatch):
    """When both enrollment and API key are available, enrollment wins.

    Requires the 'hosted' extras (cryptography) to import the enrollment
    module. Skip in slim-install test environments.
    """
    try:
        import controlzero.enrollment as _enroll_mod  # noqa: F401
    except ImportError:
        pytest.skip("enrollment module requires 'hosted' extras")

    from controlzero.cli.main import _maybe_refresh_policy

    policy_path = tmp_path / "policy.yaml"
    _write_stale_policy(policy_path)
    monkeypatch.setenv("CONTROLZERO_API_KEY", "cz_live_fakekey")

    enrollment_called = {"value": False}

    def fake_enrollment_pull(*args, **kwargs):
        enrollment_called["value"] = True
        return None  # 304 Not Modified

    def fake_hosted(*args, **kwargs):
        pytest.fail("hosted path should not be used when enrolled")

    with patch("controlzero.cli.main._load_enrollment_state", return_value=object()), \
         patch.object(_enroll_mod, "pull_policy", side_effect=fake_enrollment_pull), \
         patch("controlzero.hosted_policy.load_hosted_policy", side_effect=fake_hosted):
        _maybe_refresh_policy(policy_path, state_dir=tmp_path, threshold_s=60, timeout_s=5)

    assert enrollment_called["value"] is True


def test_hosted_refresh_timeout_falls_back_to_cache(tmp_path, monkeypatch, capsys):
    """Slow backend => hook never stalls; falls back to cached policy + warns."""
    import time
    from controlzero.cli.main import _maybe_refresh_policy

    policy_path = tmp_path / "policy.yaml"
    _write_stale_policy(policy_path)
    monkeypatch.setenv("CONTROLZERO_API_KEY", "cz_live_fakekey")

    def slow_hosted(api_key):
        time.sleep(5)
        return {"version": "1", "rules": []}, object()

    with patch("controlzero.hosted_policy.load_hosted_policy", side_effect=slow_hosted), \
         patch("controlzero.cli.main._load_enrollment_state", return_value=None):
        t0 = time.time()
        _maybe_refresh_policy(policy_path, state_dir=tmp_path, threshold_s=60, timeout_s=0.3)
        elapsed = time.time() - t0

    assert elapsed < 1.5  # join timeout + small slack
    captured = capsys.readouterr()
    assert "timed out" in captured.err


def test_hosted_refresh_network_error_falls_back_to_cache(tmp_path, monkeypatch, capsys):
    """Network error => keep cached policy, log warning, never crash."""
    from controlzero.cli.main import _maybe_refresh_policy

    policy_path = tmp_path / "policy.yaml"
    _write_stale_policy(policy_path)
    before = policy_path.read_text(encoding="utf-8")
    monkeypatch.setenv("CONTROLZERO_API_KEY", "cz_live_fakekey")

    def raise_conn(api_key):
        raise RuntimeError("connection refused")

    with patch("controlzero.hosted_policy.load_hosted_policy", side_effect=raise_conn), \
         patch("controlzero.cli.main._load_enrollment_state", return_value=None):
        _maybe_refresh_policy(policy_path, state_dir=tmp_path, threshold_s=60, timeout_s=5)

    # Cached policy untouched, warning printed.
    assert policy_path.read_text(encoding="utf-8") == before
    assert "stale" in capsys.readouterr().err
