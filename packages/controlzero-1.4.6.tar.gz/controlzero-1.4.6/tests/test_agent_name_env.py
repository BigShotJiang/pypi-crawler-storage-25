"""Coverage for the agent_name / CZ_AGENT_NAME / CZ_DEBUG env-var contract.

Resolution order (per docs):
  explicit Client(agent_name=...) > CZ_AGENT_NAME env > "default-agent"

CZ_DEBUG=1 (or true/yes/on) flips controlzero's logger to DEBUG at construction.
"""

from __future__ import annotations

import logging
import os
import unittest
from unittest.mock import patch

from controlzero import Client


class AgentNameEnvTests(unittest.TestCase):
    def test_default_when_no_arg_no_env(self) -> None:
        with patch.dict(os.environ, {}, clear=False):
            os.environ.pop("CZ_AGENT_NAME", None)
            cz = Client(policy={"rules": [{"allow": "*", "reason": "test fixture"}]})
            self.assertEqual(cz.agent_name, "default-agent")

    def test_env_var_used_when_no_arg(self) -> None:
        with patch.dict(os.environ, {"CZ_AGENT_NAME": "agent-from-env"}):
            cz = Client(policy={"rules": [{"allow": "*", "reason": "test fixture"}]})
            self.assertEqual(cz.agent_name, "agent-from-env")

    def test_explicit_arg_wins_over_env(self) -> None:
        with patch.dict(os.environ, {"CZ_AGENT_NAME": "agent-from-env"}):
            cz = Client(policy={"rules": [{"allow": "*", "reason": "test fixture"}]}, agent_name="explicit-arg")
            self.assertEqual(cz.agent_name, "explicit-arg")

    def test_empty_string_arg_is_treated_as_unset(self) -> None:
        # "" is falsy in Python, so falls through to env or default.
        with patch.dict(os.environ, {"CZ_AGENT_NAME": "from-env"}):
            cz = Client(policy={"rules": [{"allow": "*", "reason": "test fixture"}]}, agent_name="")
            self.assertEqual(cz.agent_name, "from-env")


class DebugEnvTests(unittest.TestCase):
    def setUp(self) -> None:
        # Reset logger between tests so prior CZ_DEBUG runs do not bleed.
        logging.getLogger("controlzero").setLevel(logging.NOTSET)

    def test_cz_debug_unset_does_not_lower_level(self) -> None:
        with patch.dict(os.environ, {}, clear=False):
            os.environ.pop("CZ_DEBUG", None)
            Client(policy={"rules": [{"allow": "*", "reason": "test fixture"}]})
            self.assertNotEqual(
                logging.getLogger("controlzero").level, logging.DEBUG
            )

    def test_cz_debug_1_sets_debug_level(self) -> None:
        with patch.dict(os.environ, {"CZ_DEBUG": "1"}):
            Client(policy={"rules": [{"allow": "*", "reason": "test fixture"}]})
            self.assertEqual(
                logging.getLogger("controlzero").level, logging.DEBUG
            )

    def test_cz_debug_true_yes_on_all_recognized(self) -> None:
        for value in ("true", "yes", "on", "TRUE", "Yes", "ON"):
            logging.getLogger("controlzero").setLevel(logging.NOTSET)
            with patch.dict(os.environ, {"CZ_DEBUG": value}):
                Client(policy={"rules": [{"allow": "*", "reason": "test fixture"}]})
                self.assertEqual(
                    logging.getLogger("controlzero").level,
                    logging.DEBUG,
                    f"value={value!r} should enable DEBUG",
                )

    def test_cz_debug_garbage_does_not_enable(self) -> None:
        with patch.dict(os.environ, {"CZ_DEBUG": "no"}):
            Client(policy={"rules": [{"allow": "*", "reason": "test fixture"}]})
            self.assertNotEqual(
                logging.getLogger("controlzero").level, logging.DEBUG
            )


if __name__ == "__main__":
    unittest.main()
