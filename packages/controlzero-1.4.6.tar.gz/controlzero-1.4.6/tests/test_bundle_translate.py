"""Tests for bundle _translate_rule against the backend wire format.

Covers Bug #2 from the 2026-04-19 Bryan investigation: before this
change, :func:`controlzero._internal.bundle._translate_rule` ignored
the plural ``actions`` list emitted by the Go backend (see
``bundle_handler.go`` ``PolicyRule.Actions``). Any rule carrying
``actions: ["database:execute"]`` was silently converted to
``action: "*"``, i.e. a universal match, turning a narrow deny into
a deny-all.

These tests drive the translator directly (no network, no crypto) with
the exact shape the Go handler emits.
"""

from __future__ import annotations

import pytest

from controlzero._internal.bundle import (
    _translate_rule,
    translate_to_local_policy,
)
from controlzero.policy_loader import load_policy


# ---- direct _translate_rule unit tests -------------------------------------


def test_translate_rule_plural_actions_single():
    """A single-element ``actions`` list is respected, not replaced by '*'."""
    rule = {
        "id": "r1",
        "effect": "deny",
        "actions": ["database:execute"],
        "resources": [],
        "conditions": {},
    }
    out = _translate_rule(rule, "policy-id-1")
    assert out is not None
    assert out["effect"] == "deny"
    # Either scalar or list, both must represent database:execute.
    pattern = out.get("action")
    actions = out.get("actions")
    assert pattern == "database:execute" or actions == ["database:execute"]
    # And critically: NOT '*'.
    assert pattern != "*"


def test_translate_rule_plural_actions_multi():
    """A multi-element ``actions`` list is preserved in full."""
    rule = {
        "id": "r2",
        "effect": "deny",
        "actions": ["database:execute", "database:delete"],
        "resources": [],
        "conditions": {},
    }
    out = _translate_rule(rule, "policy-id-2")
    assert out is not None
    assert out["effect"] == "deny"
    assert out.get("actions") == ["database:execute", "database:delete"]
    # Scalar "action" must NOT silently drop the second pattern.
    # (We accept either: no scalar emitted, OR a scalar that matches
    # the whole list via some canonical form. The first list element is
    # NOT acceptable because it loses information.)
    if "action" in out:
        assert out["action"] != "database:execute" or out.get("actions") is not None


def test_translate_rule_legacy_singular_tool_still_works():
    """Legacy singular ``tool`` key (old form) is preserved."""
    rule = {"effect": "deny", "tool": "send_email", "reason": "blocked"}
    out = _translate_rule(rule, "p")
    assert out is not None
    assert out["effect"] == "deny"
    # Either scalar or list should contain send_email.
    assert (
        out.get("action") == "send_email"
        or out.get("actions") == ["send_email"]
    )


def test_translate_rule_legacy_singular_action_as_tool_name():
    """Legacy singular ``action`` key (tool name, not effect) is preserved."""
    # Historically some callers used "action" as the tool pattern key.
    # Only treat "action" as a tool name when it's NOT one of the four
    # effect keywords.
    rule = {"effect": "allow", "action": "github:list_*"}
    out = _translate_rule(rule, "p")
    assert out is not None
    assert out["effect"] == "allow"
    assert (
        out.get("action") == "github:list_*"
        or out.get("actions") == ["github:list_*"]
    )


def test_translate_rule_no_pattern_defaults_to_wildcard():
    """Absence of any tool pattern preserves the documented default: '*'."""
    rule = {"effect": "deny", "reason": "catch-all"}
    out = _translate_rule(rule, "p")
    assert out is not None
    assert out["effect"] == "deny"
    assert out.get("action") == "*" or out.get("actions") == ["*"]


def test_translate_rule_plural_takes_precedence_over_singular():
    """If both ``actions`` (plural) and ``tool`` (singular) are present, plural wins.

    This matches the backend wire format: the Go struct only populates
    the plural field. If a hand-written test or migration script supplies
    both, the plural (canonical) form is authoritative.
    """
    rule = {
        "effect": "deny",
        "actions": ["database:execute"],
        "tool": "legacy_tool",
    }
    out = _translate_rule(rule, "p")
    assert out is not None
    # The plural list must win.
    assert (
        out.get("actions") == ["database:execute"]
        or out.get("action") == "database:execute"
    )
    assert out.get("action") != "legacy_tool"
    assert out.get("actions") != ["legacy_tool"]


# ---- end-to-end: backend-shaped payload -> local-mode enforcer -------------


def _backend_shaped_payload(rules: list[dict]) -> dict:
    """Mimic the shape that ``bundle_handler.go`` puts in the bundle payload.

    ``PolicyRule.Actions`` (Go) marshals to ``actions: [...]`` (plural).
    """
    return {
        "policies": [
            {
                "id": "p1",
                "name": "Demo",
                "priority": 10,
                "rules": rules,
            }
        ]
    }


def test_translate_and_enforce_plural_actions_narrow_deny():
    """A rule with ``actions: ["database:execute"]`` must NOT deny everything."""
    payload = _backend_shaped_payload([
        {
            "id": "r1",
            "effect": "deny",
            "actions": ["database:execute"],
            "resources": [],
            "conditions": {},
            "reason": "writes blocked",
        },
        {
            "id": "r2",
            "effect": "allow",
            "actions": ["*"],
            "resources": [],
            "conditions": {},
        },
    ])

    local = translate_to_local_policy(payload)
    parsed = load_policy(local)
    from controlzero._internal.enforcer import PolicyEvaluator

    evaluator = PolicyEvaluator(parsed.rules)

    # The narrow deny must hit ONLY database:execute, not every call.
    assert evaluator.evaluate("database", method="execute").effect == "deny"
    # Unrelated calls must pass through to the allow-* rule.
    assert evaluator.evaluate("web_search", method="query").effect == "allow"
    # database:query (read) must NOT be hit by the execute deny.
    assert evaluator.evaluate("database", method="query").effect == "allow"


def test_translate_and_enforce_plural_actions_multi():
    """A rule with multiple actions denies all listed, none others."""
    payload = _backend_shaped_payload([
        {
            "id": "r1",
            "effect": "deny",
            "actions": ["database:execute", "database:delete"],
            "resources": [],
            "conditions": {},
        },
        {
            "id": "r2",
            "effect": "allow",
            "actions": ["*"],
            "resources": [],
            "conditions": {},
        },
    ])

    local = translate_to_local_policy(payload)
    parsed = load_policy(local)
    from controlzero._internal.enforcer import PolicyEvaluator

    evaluator = PolicyEvaluator(parsed.rules)

    assert evaluator.evaluate("database", method="execute").effect == "deny"
    assert evaluator.evaluate("database", method="delete").effect == "deny"
    # database:query is outside the deny list.
    assert evaluator.evaluate("database", method="query").effect == "allow"
    # Unrelated tools are allowed.
    assert evaluator.evaluate("send_email", method="send").effect == "allow"


def test_translate_and_enforce_empty_actions_falls_back_to_wildcard():
    """An empty ``actions: []`` falls back to the documented default.

    The backend guarantees non-nil slices but can legitimately emit an
    empty list for a catch-all rule. We preserve the pre-existing
    behavior: empty pattern -> universal match.
    """
    payload = _backend_shaped_payload([
        {
            "id": "r1",
            "effect": "deny",
            "actions": [],
            "resources": [],
            "conditions": {},
            "reason": "catch-all deny",
        },
    ])

    local = translate_to_local_policy(payload)
    parsed = load_policy(local)
    from controlzero._internal.enforcer import PolicyEvaluator

    evaluator = PolicyEvaluator(parsed.rules)
    # Universal deny applies.
    assert evaluator.evaluate("anything").effect == "deny"
    assert evaluator.evaluate("web_search").effect == "deny"


def test_translate_legacy_singular_tool_still_works_end_to_end():
    """Legacy rules using singular ``tool`` key still behave as before."""
    payload = _backend_shaped_payload([
        {
            "id": "r1",
            "effect": "deny",
            "tool": "send_email",
            "reason": "blocked",
        },
        {
            "id": "r2",
            "effect": "allow",
            "tool": "*",
        },
    ])
    local = translate_to_local_policy(payload)
    parsed = load_policy(local)
    from controlzero._internal.enforcer import PolicyEvaluator

    evaluator = PolicyEvaluator(parsed.rules)
    assert evaluator.evaluate("send_email").effect == "deny"
    assert evaluator.evaluate("web_search").effect == "allow"
