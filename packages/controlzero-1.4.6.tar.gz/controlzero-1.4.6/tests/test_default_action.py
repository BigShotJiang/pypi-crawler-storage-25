"""Tests for bundle-level default_action (#228 Phase 2).

The bundle's `default_action` field drives the evaluator's no-match
path. Prior to #228 Phase 2, this was hard-coded to deny. Now the
bundle can carry any of `deny`/`allow`/`warn`, resolved server-side
from the canonical/org/project hierarchy, and the SDK honors it.

These tests pin:

  1. The evaluator reads the default_action from its constructor
     and emits the configured effect on no-match.
  2. Invalid/unknown values coerce to the canonical deny default
     (fail-closed, never raise).
  3. The bundle translator threads the field from the signed
     payload through to the local policy settings block.
  4. YAML policy files can carry `settings.default_action` and it
     survives load_policy into a PolicyEvaluator with the right
     effect.
  5. `set_default_action` on an existing evaluator swaps the
     no-match effect live (used by the hosted refresh path).
  6. PolicySettings also gains default_on_missing and
     default_on_tamper with matching fallback + validation.
"""

from __future__ import annotations

import pytest

from controlzero._internal.bundle import (
    make_bundle_missing_policy,
    translate_to_local_policy,
)
from controlzero._internal.enforcer import (
    DEFAULT_BUNDLE_ACTION,
    DEFAULT_BUNDLE_ON_MISSING,
    DEFAULT_BUNDLE_ON_TAMPER,
    VALID_DEFAULT_ACTIONS,
    VALID_DEFAULT_ON_MISSING,
    VALID_DEFAULT_ON_TAMPER,
    PolicyEvaluator,
)
from controlzero.errors import PolicyValidationError
from controlzero.policy_loader import PolicySettings, load_policy


# ---- evaluator: no-match default ----------------------------------------


def test_evaluator_default_action_deny_is_canonical_fallback():
    """With no explicit default_action, no-match must deny. This is
    the pre-#228 behaviour pinned so a silent regression is caught.
    """
    parsed = load_policy({
        "version": "1",
        "rules": [{"effect": "allow", "action": "safe_tool", "reason": "ok"}],
    })
    ev = PolicyEvaluator(parsed.rules)
    d = ev.evaluate(tool="other_tool", method="*")
    assert d.effect == "deny"
    assert d.reason_code == "NO_RULE_MATCH"


def test_evaluator_default_action_allow_overrides_deny():
    """default_action=allow must convert the no-match deny into an
    allow. Reason_code stays NO_RULE_MATCH so dashboards can tell
    "no rule matched" apart from "user rule allowed".
    """
    parsed = load_policy({
        "version": "1",
        "rules": [{"effect": "deny", "action": "hot_tool", "reason": "no"}],
    })
    ev = PolicyEvaluator(parsed.rules, default_action="allow")
    d = ev.evaluate(tool="cold_tool", method="*")
    assert d.effect == "allow"
    assert d.reason_code == "NO_RULE_MATCH"


def test_evaluator_default_action_warn_is_distinct_from_allow():
    """default_action=warn must emit effect=warn on no-match. Warn
    and allow are different: warn lets the call through but flags
    it for operator review (shadow-mode style).
    """
    parsed = load_policy({
        "version": "1",
        "rules": [{"effect": "allow", "action": "safe_tool", "reason": "ok"}],
    })
    ev = PolicyEvaluator(parsed.rules, default_action="warn")
    d = ev.evaluate(tool="other_tool", method="*")
    assert d.effect == "warn"
    assert d.reason_code == "NO_RULE_MATCH"


def test_evaluator_default_action_unknown_coerces_to_deny():
    """Unknown default_action values must coerce to deny (fail-
    closed). A future bundle format could ship a value this SDK
    version does not understand; safer to deny than to raise or
    accidentally allow.
    """
    parsed = load_policy({"version": "1", "rules": [{"allow": "*"}]})
    ev = PolicyEvaluator(parsed.rules, default_action="nonsense")
    # Behavior: the evaluator ignores the bad value and uses deny.
    # We validate by evaluating a miss-case policy.
    parsed_miss = load_policy({
        "version": "1",
        "rules": [{"effect": "allow", "action": "only_this", "reason": "ok"}],
    })
    ev_miss = PolicyEvaluator(parsed_miss.rules, default_action="nonsense")
    d = ev_miss.evaluate(tool="other", method="*")
    assert d.effect == "deny"


def test_evaluator_set_default_action_live_swap():
    """set_default_action must take effect without rebuilding the
    evaluator. This is the hot path for hosted-mode refresh: a
    dashboard flip from deny to allow should propagate on the next
    scheduled refresh.
    """
    parsed = load_policy({
        "version": "1",
        "rules": [{"effect": "allow", "action": "safe", "reason": "ok"}],
    })
    ev = PolicyEvaluator(parsed.rules, default_action="deny")
    assert ev.evaluate(tool="x").effect == "deny"

    ev.set_default_action("allow")
    assert ev.evaluate(tool="x").effect == "allow"

    # Unknown value reverts to deny.
    ev.set_default_action("garbage")
    assert ev.evaluate(tool="x").effect == "deny"


def test_evaluator_default_action_does_not_affect_rule_match():
    """default_action ONLY fires on no-match. A user-authored deny
    rule must still deny regardless of default_action=allow.
    """
    parsed = load_policy({
        "version": "1",
        "rules": [{"effect": "deny", "action": "Bash", "reason": "no shell"}],
    })
    ev = PolicyEvaluator(parsed.rules, default_action="allow")
    d = ev.evaluate(tool="Bash", method="*")
    assert d.effect == "deny"
    assert d.reason_code == "RULE_MATCH"


def test_evaluator_default_action_property_exposes_effective_value():
    """default_action property exists so the client can surface it
    in debug output without reaching into private state.
    """
    parsed = load_policy({"version": "1", "rules": [{"allow": "*"}]})
    ev = PolicyEvaluator(parsed.rules, default_action="warn")
    assert ev.default_action == "warn"


# ---- bundle translator: field wiring -------------------------------------


def test_translate_passes_default_action_into_settings():
    """Bundle payload's default_action must surface in the
    translated local policy's settings block so load_policy can
    pick it up.
    """
    payload = {
        "default_action": "allow",
        "default_on_missing": "allow",
        "default_on_tamper": "deny-all",
        "policies": [
            {
                "id": "pol1",
                "priority": 1,
                "rules": [{"effect": "deny", "actions": ["Bash"]}],
            },
        ],
    }
    local = translate_to_local_policy(payload)
    assert local["settings"]["default_action"] == "allow"
    assert local["settings"]["default_on_missing"] == "allow"
    assert local["settings"]["default_on_tamper"] == "deny-all"


def test_translate_missing_fields_fall_back_to_canonical_defaults():
    """An old bundle (schema 1.0) without the default_* fields must
    still translate cleanly. Missing fields fall back to
    deny/deny/warn which matches pre-#228 hard-coded behaviour.
    """
    payload = {
        "policies": [
            {
                "id": "pol1",
                "priority": 1,
                "rules": [{"effect": "allow", "actions": ["*"]}],
            },
        ],
    }
    local = translate_to_local_policy(payload)
    assert local["settings"]["default_action"] == DEFAULT_BUNDLE_ACTION
    assert local["settings"]["default_on_missing"] == DEFAULT_BUNDLE_ON_MISSING
    assert local["settings"]["default_on_tamper"] == DEFAULT_BUNDLE_ON_TAMPER


def test_translate_invalid_field_values_coerce_to_canonical():
    """A backend bug (or hostile payload) that shipped a bad enum
    value must not raise. The translator coerces to the canonical
    default so the SDK fails closed rather than crashing.
    """
    payload = {
        "default_action": "destroy",
        "default_on_missing": "",
        "default_on_tamper": "not-a-valid-value",
        "policies": [
            {
                "id": "pol1",
                "priority": 1,
                "rules": [{"effect": "allow", "actions": ["*"]}],
            },
        ],
    }
    local = translate_to_local_policy(payload)
    assert local["settings"]["default_action"] == "deny"
    assert local["settings"]["default_on_missing"] == "deny"
    assert local["settings"]["default_on_tamper"] == "warn"


def test_translate_empty_bundle_uses_default_action_on_synthetic_rule():
    """Empty bundle with default_action=allow must produce a
    synthetic allow rule (not deny). Prior to #228 Phase 2 this
    was hard-coded to deny; now the operator's choice takes
    effect. reason_code stays NO_ACTIVE_POLICIES so dashboards
    can still bucket it as "no attachments".
    """
    payload = {"default_action": "allow", "policies": []}
    local = translate_to_local_policy(payload)
    assert len(local["rules"]) == 1
    rule = local["rules"][0]
    assert rule["effect"] == "allow"
    assert rule["reason_code"] == "NO_ACTIVE_POLICIES"


def test_translate_empty_bundle_default_deny_still_default():
    """Pre-#228 behaviour preserved for bundles without an explicit
    default_action: empty bundle still denies with the NO_ACTIVE_
    POLICIES synthetic rule.
    """
    payload = {"policies": []}
    local = translate_to_local_policy(payload)
    rule = local["rules"][0]
    assert rule["effect"] == "deny"
    assert rule["reason_code"] == "NO_ACTIVE_POLICIES"


# ---- YAML policy loader: settings fields --------------------------------


def test_load_policy_parses_default_action_from_yaml():
    """Local YAML policies can declare settings.default_action and
    the loader must plumb it into PolicySettings.
    """
    policy = {
        "version": "1",
        "settings": {
            "default_action": "allow",
            "default_on_missing": "allow",
            "default_on_tamper": "deny",
        },
        "rules": [{"allow": "*"}],
    }
    parsed = load_policy(policy)
    assert parsed.settings.default_action == "allow"
    assert parsed.settings.default_on_missing == "allow"
    assert parsed.settings.default_on_tamper == "deny"


def test_load_policy_missing_settings_uses_canonical_defaults():
    """Existing YAML policies without a settings block must keep
    working with canonical defaults (deny/deny/warn).
    """
    policy = {"version": "1", "rules": [{"allow": "*"}]}
    parsed = load_policy(policy)
    assert parsed.settings.default_action == DEFAULT_BUNDLE_ACTION
    assert parsed.settings.default_on_missing == DEFAULT_BUNDLE_ON_MISSING
    assert parsed.settings.default_on_tamper == DEFAULT_BUNDLE_ON_TAMPER


def test_load_policy_rejects_invalid_default_action():
    """YAML-level typos must surface as a validation error. Bundle
    translator sanitises its own input (different contract: fail-
    closed, never raise), but YAML is authored by humans and a
    raised error catches typos up front.
    """
    policy = {
        "version": "1",
        "settings": {"default_action": "burn-everything"},
        "rules": [{"allow": "*"}],
    }
    with pytest.raises(PolicyValidationError) as exc:
        load_policy(policy)
    assert "default_action" in str(exc.value)


def test_load_policy_rejects_invalid_default_on_missing():
    """Same validation contract for default_on_missing."""
    policy = {
        "version": "1",
        "settings": {"default_on_missing": "shrug"},
        "rules": [{"allow": "*"}],
    }
    with pytest.raises(PolicyValidationError) as exc:
        load_policy(policy)
    assert "default_on_missing" in str(exc.value)


def test_load_policy_rejects_invalid_default_on_tamper():
    """Same validation contract for default_on_tamper."""
    policy = {
        "version": "1",
        "settings": {"default_on_tamper": "whatever"},
        "rules": [{"allow": "*"}],
    }
    with pytest.raises(PolicyValidationError) as exc:
        load_policy(policy)
    assert "default_on_tamper" in str(exc.value)


def test_policy_settings_dataclass_defaults():
    """The PolicySettings dataclass must default to canonical values
    so code that constructs one without kwargs behaves the same as
    pre-#228.
    """
    s = PolicySettings()
    assert s.tamper_behavior == "warn"
    assert s.default_action == DEFAULT_BUNDLE_ACTION
    assert s.default_on_missing == DEFAULT_BUNDLE_ON_MISSING
    assert s.default_on_tamper == DEFAULT_BUNDLE_ON_TAMPER


# ---- canonical enum constants are frozen ---------------------------------


def test_valid_default_action_enum_is_three_values():
    """Contract with the backend: the enum stays exactly {deny,
    allow, warn}. Adding `last-known-good` is a Phase 3 item,
    not Phase 2.
    """
    assert VALID_DEFAULT_ACTIONS == frozenset({"deny", "allow", "warn"})


def test_valid_default_on_missing_enum_is_two_values():
    """Pinned to {deny, allow} for Phase 2. last-known-good is
    deliberately absent."""
    assert VALID_DEFAULT_ON_MISSING == frozenset({"deny", "allow"})


def test_valid_default_on_tamper_enum_matches_tamper_behavior():
    """default_on_tamper mirrors the existing tamper_behavior enum
    so the two are 1:1 convertible."""
    assert VALID_DEFAULT_ON_TAMPER == frozenset(
        {"warn", "deny", "deny-all", "quarantine"}
    )
