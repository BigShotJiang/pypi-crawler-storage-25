"""Tests for the .czpolicy bundle parser.

These tests are deterministic: the bundle is constructed inline with
the same format as the backend's buildBundle() so we don't need any
network or external test vectors. If these pass and the Go unit tests
for buildBundle pass, we have cross-language parity.
"""

from __future__ import annotations

import json
import os
import struct

import pytest

from controlzero._internal.bundle import (
    BundleFormatError,
    BundleVerificationError,
    parse_bundle,
    translate_to_local_policy,
)


# --- Test vector builder (mirrors backend buildBundle) --------------------


def _build_bundle(
    payload: bytes,
    enc_key: bytes,
    signing_priv,
    *,
    schema_version: int = 1,
    created_at: int = 1700000000,
    policy_count: int = 1,
    corrupt_magic: bool = False,
    corrupt_reserved: bool = False,
    corrupt_sig_len: bool = False,
    extra_trailing: bytes = b"",
) -> bytes:
    """Construct a bundle using the exact wire format from the spec."""
    import zstandard as zstd
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM

    compressed = zstd.ZstdCompressor().compress(payload)
    aesgcm = AESGCM(enc_key)
    nonce = os.urandom(12)
    ciphertext = aesgcm.encrypt(nonce, compressed, None)
    encrypted_payload = nonce + ciphertext

    magic = b"XX01" if corrupt_magic else b"CZ01"
    reserved = b"\xff" * 8 if corrupt_reserved else b"\x00" * 8
    sig_len = 65 if corrupt_sig_len else 64

    sig_offset = 32 + len(encrypted_payload)
    header = (
        magic
        + struct.pack("<HQHII", schema_version, created_at, policy_count, sig_offset, sig_len)
        + reserved
    )
    assert len(header) == 32

    data_to_sign = header + encrypted_payload
    signature = signing_priv.sign(data_to_sign)
    # Pad/truncate signature to match sig_len so we can test length mismatch.
    if len(signature) != sig_len:
        if corrupt_sig_len:
            signature = signature + b"\x00" * (sig_len - 64)
    return data_to_sign + signature + extra_trailing


@pytest.fixture
def keys():
    """Fresh Ed25519 keypair + AES-256 key for each test."""
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

    enc_key = os.urandom(32)
    priv = Ed25519PrivateKey.generate()
    pub_bytes = priv.public_key().public_bytes_raw()
    return enc_key, priv, pub_bytes


@pytest.fixture
def valid_payload():
    return json.dumps({
        "schema_version": "1.0",
        "bundle_id": "v1",
        "project_id": "test",
        "policies": [
            {
                "id": "p1",
                "name": "Demo",
                "priority": 10,
                "rules": [
                    {"effect": "deny", "tool": "send_email", "reason": "Email blocked"},
                    {"effect": "allow", "tool": "*"},
                ],
            }
        ],
    }).encode("utf-8")


# --- Happy path -----------------------------------------------------------


def test_parse_valid_bundle(keys, valid_payload):
    enc_key, priv, pub = keys
    bundle = _build_bundle(valid_payload, enc_key, priv)
    parsed = parse_bundle(bundle, enc_key, pub)
    assert parsed.header.schema_version == 1
    assert parsed.header.policy_count == 1
    assert isinstance(parsed.payload, dict)
    assert len(parsed.payload["policies"]) == 1


def test_translate_to_local_policy(keys, valid_payload):
    enc_key, priv, pub = keys
    bundle = _build_bundle(valid_payload, enc_key, priv)
    parsed = parse_bundle(bundle, enc_key, pub)
    local = translate_to_local_policy(parsed.payload)
    assert local["version"] == "1"
    actions = [r["action"] for r in local["rules"]]
    assert "send_email" in actions
    assert "*" in actions


def test_empty_policies_becomes_deny_all(keys):
    """An empty policy set translates to deny-all, not allow-all."""
    enc_key, priv, pub = keys
    payload = json.dumps({"policies": []}).encode("utf-8")
    bundle = _build_bundle(payload, enc_key, priv, policy_count=0)
    parsed = parse_bundle(bundle, enc_key, pub)
    local = translate_to_local_policy(parsed.payload)
    assert len(local["rules"]) == 1
    assert local["rules"][0]["effect"] == "deny"
    assert local["rules"][0]["action"] == "*"


# --- Tamper detection (security-critical) ---------------------------------


def test_tampered_signature_rejected(keys, valid_payload):
    enc_key, priv, pub = keys
    bundle = _build_bundle(valid_payload, enc_key, priv)
    tampered = bundle[:-1] + bytes([bundle[-1] ^ 1])
    with pytest.raises(BundleVerificationError, match="signature verification failed"):
        parse_bundle(tampered, enc_key, pub)


def test_tampered_ciphertext_rejected(keys, valid_payload):
    enc_key, priv, pub = keys
    bundle = _build_bundle(valid_payload, enc_key, priv)
    # Flip a byte well inside the ciphertext region.
    offset = 48
    tampered = bundle[:offset] + bytes([bundle[offset] ^ 1]) + bundle[offset + 1:]
    with pytest.raises(BundleVerificationError):
        parse_bundle(tampered, enc_key, pub)


def test_wrong_encryption_key_rejected(keys, valid_payload):
    _enc_key, priv, pub = keys
    bundle = _build_bundle(valid_payload, _enc_key, priv)
    wrong_key = os.urandom(32)
    with pytest.raises(BundleVerificationError, match="decryption failed"):
        parse_bundle(bundle, wrong_key, pub)


def test_wrong_signing_pubkey_rejected(keys, valid_payload):
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

    enc_key, priv, _pub = keys
    bundle = _build_bundle(valid_payload, enc_key, priv)
    wrong_priv = Ed25519PrivateKey.generate()
    wrong_pub = wrong_priv.public_key().public_bytes_raw()
    with pytest.raises(BundleVerificationError, match="signature verification failed"):
        parse_bundle(bundle, enc_key, wrong_pub)


# --- Format errors --------------------------------------------------------


def test_rejects_short_blob():
    with pytest.raises(BundleFormatError, match="too short"):
        parse_bundle(b"short", b"\x00" * 32, b"\x00" * 32)


def test_rejects_non_bytes_input():
    with pytest.raises(BundleFormatError, match="must be bytes"):
        parse_bundle("not bytes", b"\x00" * 32, b"\x00" * 32)  # type: ignore[arg-type]


def test_rejects_bad_magic(keys, valid_payload):
    enc_key, priv, pub = keys
    bundle = _build_bundle(valid_payload, enc_key, priv, corrupt_magic=True)
    with pytest.raises(BundleFormatError, match="bad magic"):
        parse_bundle(bundle, enc_key, pub)


def test_rejects_nonzero_reserved(keys, valid_payload):
    enc_key, priv, pub = keys
    bundle = _build_bundle(valid_payload, enc_key, priv, corrupt_reserved=True)
    with pytest.raises(BundleFormatError, match="reserved bytes"):
        parse_bundle(bundle, enc_key, pub)


def test_rejects_trailing_bytes(keys, valid_payload):
    enc_key, priv, pub = keys
    bundle = _build_bundle(valid_payload, enc_key, priv, extra_trailing=b"\x00\x00\x00")
    with pytest.raises(BundleFormatError, match="trailing bytes"):
        parse_bundle(bundle, enc_key, pub)


def test_rejects_wrong_enc_key_length(keys, valid_payload):
    enc_key, priv, pub = keys
    bundle = _build_bundle(valid_payload, enc_key, priv)
    with pytest.raises(BundleVerificationError, match="encryption key must be 32 bytes"):
        parse_bundle(bundle, b"short", pub)


def test_rejects_wrong_pubkey_length(keys, valid_payload):
    enc_key, priv, pub = keys
    bundle = _build_bundle(valid_payload, enc_key, priv)
    with pytest.raises(BundleVerificationError, match="signing public key must be 32 bytes"):
        parse_bundle(bundle, enc_key, b"short")


def test_rejects_oversized_bundle(keys, valid_payload):
    enc_key, priv, pub = keys
    bundle = _build_bundle(valid_payload, enc_key, priv)
    with pytest.raises(BundleFormatError, match="exceeds max"):
        parse_bundle(bundle, enc_key, pub, max_bundle_bytes=10)
