"""Smoke + negative tests for the google.genai integration wrapper.

Mocks the google-genai client surface so the test does not require
network access or a real GEMINI_API_KEY.
"""

from __future__ import annotations

import unittest
from types import SimpleNamespace
from unittest.mock import MagicMock

from controlzero import Client
from controlzero.integrations.google import wrap_google


def _make_cz_allow() -> Client:
    return Client(
        policy={"rules": [{"allow": "llm:generate", "reason": "test fixture"}]}
    )


def _make_cz_deny() -> Client:
    return Client(
        policy={
            "rules": [
                {"deny": "llm:generate", "reason": "denied for test"},
            ]
        }
    )


def _fake_models(response: SimpleNamespace) -> MagicMock:
    """Return a mock that mimics google.genai Client().models with a
    generate_content() returning the given response object."""
    inner = MagicMock()
    inner.generate_content.return_value = response
    return inner


class WrapGoogleHappyPathTests(unittest.TestCase):
    def test_allow_passes_through_response(self) -> None:
        cz = _make_cz_allow()
        response = SimpleNamespace(
            text="Hello",
            usage_metadata=SimpleNamespace(
                prompt_token_count=4, candidates_token_count=12
            ),
        )
        models = wrap_google(_fake_models(response), cz, agent_id="test-agent")
        out = models.generate_content(model="gemini-2.0-flash", contents="Hi")
        self.assertIs(out, response)

    def test_zero_usage_metadata(self) -> None:
        """Response without usage_metadata still passes through cleanly."""
        cz = _make_cz_allow()
        response = SimpleNamespace(text="x")
        models = wrap_google(_fake_models(response), cz, agent_id="a")
        out = models.generate_content(model="gemini-2.0-flash", contents="Hi")
        self.assertIs(out, response)

    def test_passthrough_for_other_attrs(self) -> None:
        """Non-generate_content attributes pass through to the inner."""
        cz = _make_cz_allow()
        inner = _fake_models(SimpleNamespace())
        inner.list_models = MagicMock(return_value=["gemini-2.0-flash"])
        wrapped = wrap_google(inner, cz, agent_id="a")
        self.assertEqual(wrapped.list_models(), ["gemini-2.0-flash"])
        inner.list_models.assert_called_once()


class WrapGoogleDenialTests(unittest.TestCase):
    def test_deny_raises_before_calling_inner(self) -> None:
        from controlzero._internal.enforcer import PolicyDeniedError

        cz = _make_cz_deny()
        inner = _fake_models(SimpleNamespace())
        models = wrap_google(inner, cz, agent_id="a")
        with self.assertRaises(PolicyDeniedError):
            models.generate_content(model="gemini-2.0-flash", contents="Hi")
        # Inner should not have been called
        inner.generate_content.assert_not_called()


class WrapGoogleErrorPropagationTests(unittest.TestCase):
    def test_inner_exception_propagates(self) -> None:
        cz = _make_cz_allow()
        inner = MagicMock()
        inner.generate_content.side_effect = RuntimeError("upstream 500")
        models = wrap_google(inner, cz, agent_id="a")
        with self.assertRaisesRegex(RuntimeError, "upstream 500"):
            models.generate_content(model="gemini-2.0-flash", contents="Hi")


if __name__ == "__main__":
    unittest.main()
