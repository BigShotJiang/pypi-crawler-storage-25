"""Glob matching via fnmatch. Verifies the patterns advertised in templates work."""

from controlzero import Client


def test_bare_tool_name_glob(tmp_log):
    cz = Client(
        policy={"rules": [{"deny": "delete_*"}, {"allow": "*"}]},
        log_path=str(tmp_log),
    )
    assert cz.guard("delete_file").decision == "deny"
    assert cz.guard("delete_repo").decision == "deny"
    assert cz.guard("read_file").decision == "allow"
    cz.close()


def test_tool_method_exact(tmp_log):
    cz = Client(
        policy={
            "rules": [
                {"deny": "github:delete_repo"},
                {"allow": "github:*"},
                {"deny": "*"},
            ]
        },
        log_path=str(tmp_log),
    )
    assert cz.guard("github", method="delete_repo").decision == "deny"
    assert cz.guard("github", method="list_repos").decision == "allow"
    assert cz.guard("github", method="get_pr").decision == "allow"
    cz.close()


def test_method_wildcard_across_any_tool(tmp_log):
    cz = Client(
        policy={
            "rules": [
                {"allow": "*:read"},
                {"allow": "*:list"},
                {"deny": "*"},
            ]
        },
        log_path=str(tmp_log),
    )
    assert cz.guard("fs", method="read").decision == "allow"
    assert cz.guard("db", method="read").decision == "allow"
    assert cz.guard("fs", method="write").decision == "deny"
    cz.close()


def test_resource_glob_in_suffix(tmp_log):
    """The bug that broke the cost-cap template: glob patterns inside the
    resource suffix (e.g. 'model:claude-haiku-*') must work, not just at the
    colon position."""
    cz = Client(
        policy={
            "rules": [
                {
                    "allow": "llm_call",
                    "resources": ["model:claude-haiku-*"],
                    "reason": "Haiku is cheap",
                },
                {
                    "deny": "llm_call",
                    "resources": ["model:claude-opus-*"],
                    "reason": "Opus is expensive",
                },
                {"deny": "*"},
            ]
        },
        log_path=str(tmp_log),
    )
    haiku = cz.guard("llm_call", context={"resource": "model:claude-haiku-3-5-20241022"})
    opus = cz.guard("llm_call", context={"resource": "model:claude-opus-4-20250101"})
    assert haiku.decision == "allow", f"expected allow, got {haiku.decision} ({haiku.reason})"
    assert opus.decision == "deny", f"expected deny, got {opus.decision} ({opus.reason})"
    cz.close()


def test_cost_cap_template_end_to_end(tmp_log):
    """The shipped cost-cap template must actually do what its comments claim."""
    from pathlib import Path
    template_path = Path(__file__).parent.parent / "controlzero" / "cli" / "templates" / "cost-cap.yaml"
    assert template_path.exists()

    cz = Client(policy_file=template_path, log_path=str(tmp_log))

    # Allowed: Haiku
    r = cz.guard("llm_call", context={"resource": "model:claude-haiku-3-5-20241022"})
    assert r.decision == "allow", f"Haiku should be allowed, got {r.decision} ({r.reason})"

    # Allowed: Sonnet
    r = cz.guard("llm_call", context={"resource": "model:claude-sonnet-4-5-20250929"})
    assert r.decision == "allow", f"Sonnet should be allowed, got {r.decision} ({r.reason})"

    # Allowed: gpt-4o-mini exact
    r = cz.guard("llm_call", context={"resource": "model:gpt-4o-mini"})
    assert r.decision == "allow"

    # Denied: Opus
    r = cz.guard("llm_call", context={"resource": "model:claude-opus-4-20250101"})
    assert r.decision == "deny"

    # Denied: gpt-4-32k exact
    r = cz.guard("llm_call", context={"resource": "model:gpt-4-32k"})
    assert r.decision == "deny"

    cz.close()


def test_universal_wildcard(tmp_log):
    cz = Client(
        policy={"rules": [{"allow": "*"}]},
        log_path=str(tmp_log),
    )
    assert cz.guard("anything").allowed
    assert cz.guard("anything", method="anything").allowed
    cz.close()


# ---------------------------------------------------------------------
# T83 regression: resources:["*"] must NOT require a caller resource.
# ---------------------------------------------------------------------
# Pre-T83 the dashboard's universal-resource shape (every rule emitted
# resources:["*"]) skipped every rule when callers passed no
# context.resource, falling through to default deny. Bryan deny-deny
# incident, 2026-05-10. The exact bundle Bryan ran against is the
# fixture below.

def test_resources_wildcard_matches_without_context_resource(tmp_log):
    cz = Client(
        policy={
            "rules": [
                {
                    "id": "rule-0",
                    "allow": "database:read",
                    "resources": ["*"],
                },
            ],
        },
        log_path=str(tmp_log),
    )
    # SELECT classifies as database:read via sql_semantic_class.
    r = cz.guard("database", method="read", args={"sql": "SELECT id FROM orders"})
    assert r.decision == "allow", f"resources:['*'] without context.resource should match; got {r.decision} ({r.reason})"
    cz.close()


def test_bryan_db_read_only_full_bundle_shape(tmp_log):
    """End-to-end against the EXACT rule shape from Bryan's published bundle.

    This is the smoking-gun reproduction:
      - rule-0 allow database:read    (should fire on SELECT)
      - rule-1 deny  database:exec    (should fire on DROP via canonical class)
      - rule-2 deny  database:delete  (separate guard rail)
    All rules carry resources:["*"]. Pre-T83 every call returned deny.
    """
    cz = Client(
        policy={
            "rules": [
                {"id": "rule-0", "allow": "database:read", "resources": ["*"]},
                {"id": "rule-1", "deny": "database:exec", "resources": ["*"]},
                {"id": "rule-2", "deny": "database:delete", "resources": ["*"]},
            ],
        },
        log_path=str(tmp_log),
    )
    # SELECT must allow.
    r = cz.guard("database", method="read", args={"sql": "SELECT id FROM orders"})
    assert r.decision == "allow", f"SELECT should allow, got {r.decision} ({r.reason})"

    # DROP TABLE: caller passes method="exec" so candidate_actions
    # contains database:exec which matches rule-1 deny.
    r2 = cz.guard("database", method="exec", args={"sql": "DROP TABLE orders"})
    assert r2.decision == "deny", f"DROP via method=exec should deny, got {r2.decision} ({r2.reason})"
    cz.close()


def test_specific_resource_pattern_still_requires_caller_resource(tmp_log):
    """T83 must NOT regress non-wildcard resource scoping. A rule that
    names a concrete resource pattern should still skip when the caller
    passes no resource."""
    cz = Client(
        policy={
            "rules": [
                {"id": "scoped", "allow": "fs:read", "resources": ["/home/*"]},
                {"deny": "*"},
            ],
        },
        log_path=str(tmp_log),
    )
    # No resource in context -- scoped rule must NOT match, fall through to deny.
    r = cz.guard("fs", method="read")
    assert r.decision == "deny", f"scoped rule must not match without context.resource, got {r.decision}"
    # With matching resource, allow.
    r2 = cz.guard("fs", method="read", context={"resource": "/home/alice/notes.txt"})
    assert r2.decision == "allow"
    # With non-matching resource, deny via fall-through.
    r3 = cz.guard("fs", method="read", context={"resource": "/etc/passwd"})
    assert r3.decision == "deny"
    cz.close()
