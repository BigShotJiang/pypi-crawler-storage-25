"""End-to-end hosted mode test against an in-process mock backend.

Spins up a tiny HTTP server that serves valid /v1/sdk/bootstrap and
/v1/sdk/policies/pull responses with a bundle produced using the same
exact wire format as the real backend's buildBundle(). Verifies:

  - Client(api_key=...) pulls, verifies, decrypts, enforces.
  - guard() returns correct allow/deny per the policy.
  - Audit entries posted to /v1/sdk/audit.
  - Second construction uses cached bundle (304 path).
"""

from __future__ import annotations

import base64
import json
import os
import shutil
import struct
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

import pytest


@pytest.fixture
def mock_backend(tmp_path, monkeypatch):
    """Spin up an in-process backend that signs + encrypts a real bundle."""
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    import zstandard as zstd

    # Keys for this test instance.
    priv = Ed25519PrivateKey.generate()
    pub_bytes = priv.public_key().public_bytes_raw()
    enc_key = os.urandom(32)

    # Test policy payload.
    payload_dict = {
        "schema_version": "1.0",
        "bundle_id": "v1",
        "project_id": "test-project",
        "policies": [
            {
                "id": "p1",
                "name": "Demo",
                "priority": 10,
                "rules": [
                    {"effect": "deny", "tool": "send_email", "reason": "blocked"},
                    {"effect": "allow", "tool": "*"},
                ],
            }
        ],
    }
    payload_json = json.dumps(payload_dict).encode("utf-8")
    compressed = zstd.ZstdCompressor().compress(payload_json)

    # AES-GCM encrypt: nonce(12) || ciphertext || tag
    nonce = os.urandom(12)
    encrypted = nonce + AESGCM(enc_key).encrypt(nonce, compressed, None)

    # Header (32 bytes).
    sig_offset = 32 + len(encrypted)
    header = (
        b"CZ01"
        + struct.pack("<HQHII", 1, 1700000000, 1, sig_offset, 64)
        + b"\x00" * 8
    )
    data_to_sign = header + encrypted
    signature = priv.sign(data_to_sign)
    bundle_bytes = data_to_sign + signature

    # Responses.
    bootstrap_resp = {
        "project_id": "test-project",
        "org_id": "test-org",
        "project_encryption_key_b64": base64.b64encode(enc_key).decode("ascii"),
        "signing_pubkey_hex": pub_bytes.hex(),
        "signing_pubkey_pem": "",  # SDK prefers hex
        "key_version": 1,
        "algorithm": "ed25519",
    }

    audits_received = []

    class Handler(BaseHTTPRequestHandler):
        def _require_bearer(self):
            auth = self.headers.get("Authorization", "")
            if not auth.startswith("Bearer cz_"):
                self.send_response(401)
                self.end_headers()
                return False
            return True

        def do_GET(self):
            if not self._require_bearer():
                return
            if self.path == "/v1/sdk/bootstrap":
                body = json.dumps(bootstrap_resp).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return
            if self.path == "/v1/sdk/policies/pull":
                etag = self.headers.get("If-None-Match", "")
                if etag:
                    # Caller already has this bundle.
                    self.send_response(304)
                    self.end_headers()
                    return
                self.send_response(200)
                self.send_header("Content-Type", "application/octet-stream")
                self.send_header("Content-Length", str(len(bundle_bytes)))
                self.end_headers()
                self.wfile.write(bundle_bytes)
                return
            self.send_response(404)
            self.end_headers()

        def do_POST(self):
            if not self._require_bearer():
                return
            if self.path == "/v1/sdk/audit":
                length = int(self.headers.get("Content-Length", "0"))
                raw = self.rfile.read(length) if length else b"{}"
                parsed = json.loads(raw)
                audits_received.extend(parsed.get("entries", []))
                resp = json.dumps({"accepted": len(parsed.get("entries", [])), "dropped": 0}).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(resp)))
                self.end_headers()
                self.wfile.write(resp)
                return
            self.send_response(404)
            self.end_headers()

        def log_message(self, *a, **kw):
            pass

    server = HTTPServer(("127.0.0.1", 0), Handler)
    port = server.server_address[1]
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()

    # Isolate cache to tmp_path so repeated test runs don't collide.
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("CONTROLZERO_API_URL", f"http://127.0.0.1:{port}")

    yield {
        "port": port,
        "audits": audits_received,
        "bundle_bytes": bundle_bytes,
        "payload": payload_dict,
    }

    server.shutdown()


def test_hosted_mode_e2e_allow(mock_backend):
    from controlzero import Client

    client = Client(api_key="cz_live_e2e_test")
    result = client.guard("web_search", args={"q": "test"})
    assert result.effect == "allow"
    client.close()


def test_hosted_mode_e2e_deny(mock_backend):
    from controlzero import Client

    client = Client(api_key="cz_live_e2e_test")
    result = client.guard("send_email", args={"body": "x"})
    assert result.effect == "deny"
    client.close()


def test_hosted_mode_audit_pushed(mock_backend):
    from controlzero import Client

    client = Client(api_key="cz_live_e2e_test")
    client.guard("web_search", args={})
    client.guard("send_email", args={})
    client.close()  # flushes synchronously

    # Both decisions should be in the audit batch.
    tools = [a.get("tool_name") for a in mock_backend["audits"]]
    assert "web_search" in tools
    assert "send_email" in tools
    # Hosted mode marker.
    assert all(a.get("mode") == "hosted" for a in mock_backend["audits"])


def test_hosted_mode_second_run_uses_cache(mock_backend):
    """Second Client with same key should succeed via the 304 cache path."""
    from controlzero import Client

    c1 = Client(api_key="cz_live_e2e_test")
    c1.close()

    c2 = Client(api_key="cz_live_e2e_test")
    # Still enforces policy correctly.
    assert c2.guard("send_email", args={}).effect == "deny"
    c2.close()


def test_hosted_mode_invalid_key_fails_fast(mock_backend):
    """An invalid Bearer token must surface HostedAuthError from bootstrap."""
    from controlzero import Client
    from controlzero.errors import HostedAuthError

    # Our mock rejects anything that doesn't start with cz_
    with pytest.raises(HostedAuthError):
        Client(api_key="not_a_real_key_prefix")
