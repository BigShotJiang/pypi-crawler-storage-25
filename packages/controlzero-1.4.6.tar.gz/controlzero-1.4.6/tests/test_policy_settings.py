"""Tests for the policy settings section (tamper_behavior parsing)."""

import pytest

from controlzero.errors import PolicyValidationError
from controlzero.policy_loader import (
    ParsedPolicy,
    PolicySettings,
    VALID_TAMPER_BEHAVIORS,
    load_policy,
)


def _base_policy(**overrides):
    """Return a valid policy dict, optionally overriding top-level keys."""
    d = {
        "version": "1",
        "rules": [{"deny": "*", "reason": "catch-all"}],
    }
    d.update(overrides)
    return d


class TestPolicySettingsParsing:

    def test_parse_settings_tamper_behavior_warn(self):
        """Default tamper_behavior is 'warn' when settings section is present
        but tamper_behavior is not set."""
        policy = _base_policy(settings={})
        parsed = load_policy(policy)
        assert isinstance(parsed, ParsedPolicy)
        assert parsed.settings.tamper_behavior == "warn"

    def test_parse_settings_tamper_behavior_deny(self):
        """Explicit 'deny' value is parsed correctly."""
        policy = _base_policy(settings={"tamper_behavior": "deny"})
        parsed = load_policy(policy)
        assert parsed.settings.tamper_behavior == "deny"

    def test_parse_settings_tamper_behavior_deny_all(self):
        """Explicit 'deny-all' value is parsed correctly."""
        policy = _base_policy(settings={"tamper_behavior": "deny-all"})
        parsed = load_policy(policy)
        assert parsed.settings.tamper_behavior == "deny-all"

    def test_parse_settings_tamper_behavior_quarantine(self):
        """Explicit 'quarantine' value is parsed correctly."""
        policy = _base_policy(settings={"tamper_behavior": "quarantine"})
        parsed = load_policy(policy)
        assert parsed.settings.tamper_behavior == "quarantine"

    def test_parse_settings_tamper_behavior_invalid(self):
        """Invalid tamper_behavior raises PolicyValidationError."""
        policy = _base_policy(settings={"tamper_behavior": "explode"})
        with pytest.raises(PolicyValidationError) as exc_info:
            load_policy(policy)
        assert "tamper_behavior" in str(exc_info.value)

    def test_parse_no_settings_section(self):
        """When no settings section is present, defaults apply."""
        policy = _base_policy()
        parsed = load_policy(policy)
        assert parsed.settings.tamper_behavior == "warn"
        assert len(parsed.rules) == 1

    def test_parse_settings_not_dict(self):
        """When settings is not a dict, raises PolicyValidationError."""
        policy = _base_policy(settings="not-a-dict")
        with pytest.raises(PolicyValidationError) as exc_info:
            load_policy(policy)
        assert "mapping" in str(exc_info.value).lower()

    def test_parsed_policy_has_rules(self):
        """ParsedPolicy.rules contains the expected PolicyRule objects."""
        policy = _base_policy(
            settings={"tamper_behavior": "deny"},
            rules=[
                {"deny": "delete_*", "reason": "no deletes"},
                {"allow": "read_*"},
            ],
        )
        parsed = load_policy(policy)
        assert len(parsed.rules) == 2
        assert parsed.rules[0].effect == "deny"
        assert parsed.rules[1].effect == "allow"
        assert parsed.settings.tamper_behavior == "deny"
