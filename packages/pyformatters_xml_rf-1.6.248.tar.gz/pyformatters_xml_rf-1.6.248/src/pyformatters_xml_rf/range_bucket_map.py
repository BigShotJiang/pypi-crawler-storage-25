"""Lightweight replacement for the Ranger library (incompatible with Python 3.12+).

Provides Range and RangeBucketMap with only the subset of functionality
used by this project: closed-open ranges, point containment, and
overlap-based lookups returning bucket values.
"""


class Range:
    """A half-open interval [start, end)."""

    __slots__ = ("start", "end")

    def __init__(self, start: int, end: int):
        self.start = start
        self.end = end

    @staticmethod
    def closedOpen(start: int, end: int) -> "Range":
        return Range(start, end)

    def overlaps(self, other: "Range") -> bool:
        return self.start < other.end and other.start < self.end

    def contains_point(self, point: int) -> bool:
        return self.start <= point < self.end


class RangeBucketMap:
    """Maps disjoint ranges to lists of values.

    Supports assigning values to ranges, checking point containment,
    and retrieving all values whose ranges overlap a query range.
    """

    def __init__(self):
        self._entries: list[tuple[Range, list]] = []

    def __setitem__(self, r: Range, value):
        self._entries.append((r, [value]))

    def contains(self, point: int) -> bool:
        return any(r.contains_point(point) for r, _ in self._entries)

    def __getitem__(self, r: Range) -> list:
        result = []
        for entry_range, values in self._entries:
            if entry_range.overlaps(r):
                result.extend(values)
        return result
