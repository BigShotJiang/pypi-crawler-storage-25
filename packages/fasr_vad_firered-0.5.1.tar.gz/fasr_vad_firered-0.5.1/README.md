# fasr-vad-firered

基于 [FireRedVAD](https://github.com/FireRedTeam/FireRedVAD) 的语音活动检测模型插件，为 fasr 提供非流式 VAD 能力。

## 安装

```bash
pip install fasr-vad-firered
```

## 注册模型

| 注册名 | 类 | 默认 checkpoint | 说明 |
|---|---|---|---|
| `firered` | `FireRedForVAD` | `xukaituo/FireRedVAD` | 非流式 VAD，基于神经网络的语音段检测 |

模型权重默认从 ModelScope 自动下载。权重目录需包含 `cmvn.ark` 和 `model.pth.tar`。

## 使用方式

### 在流水线中使用

```python
from fasr import AudioPipeline

pipeline = (
    AudioPipeline()
    .add_pipe("detector", model="firered")
    .add_pipe("recognizer", model="firered_aed", checkpoint_dir="/path/to/asr-ckpt")
    .add_pipe("sentencizer", model="ct_transformer")
)
```

### 单独使用模型

模型实例化时会自动执行 `download_checkpoint()` + `load_checkpoint()`：

```python
from fasr.config import registry
from fasr.data import AudioSpan, Waveform

model = registry.vad_models.get("firered")(use_gpu=True, speech_threshold=0.4)

audio = AudioSpan(waveform=Waveform.from_file("example.wav"), start_ms=0)
segments = model.detect(audio)
for seg in segments:
    print(f"{seg.start_ms}ms - {seg.end_ms}ms")

# 使用自定义权重目录（需含 cmvn.ark 与 model.pth.tar）
model.load_checkpoint("/path/to/custom/firered-vad")
```

## 运行期 / 会话参数

| 参数 | 类型 | 默认值 | 说明 |
|---|---|---|---|
| `checkpoint` | `str \| None` | `"FireRedTeam/FireRedVAD"` | 远程 repo_id；非空时实例化会自动下载 |
| `cache_dir` | `str \| Path \| None` | `None` | 缓存目录，`None` 使用 `fasr.utils.get_cache_dir()` |
| `endpoint` | `Literal["modelscope", "huggingface", "hf-mirror"]` | `"modelscope"` | 下载端点 |
| `use_gpu` | `bool` | `False` | 是否使用 GPU 推理 |
| `speech_threshold` | `float` | `0.4` | 语音判定阈值，越小越敏感 |

## 依赖

- `fasr`
- `torch >= 2.0.0`
- `soundfile >= 0.12.0`
- `kaldiio >= 2.18.0`、`kaldi-native-fbank >= 1.19.0`
- Python 3.10–3.12
