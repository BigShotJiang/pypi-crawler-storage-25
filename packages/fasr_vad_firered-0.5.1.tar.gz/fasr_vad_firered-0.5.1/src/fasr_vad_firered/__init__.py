from fasr_vad_firered.models.vad import FireRedForVAD

__all__ = ["FireRedForVAD"]
