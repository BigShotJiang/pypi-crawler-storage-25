"""Tests for scripts/profit_gates (sin Redis)."""

import json
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
FIXTURE = ROOT / "tests" / "fixtures" / "profit_gates_sample.json"


def test_trading_passes_with_fixture():
    from scripts.profit_gates.trading import evaluate_trading_gates

    data = json.loads(FIXTURE.read_text(encoding="utf-8"))
    v = evaluate_trading_gates(data["trading"])
    assert v.overall in ("PASS", "DEGRADED")
    assert len(v.gates) == 4
    assert all(g.gate_id.startswith("G") for g in v.gates)


def test_dropshipping_passes_with_fixture():
    from scripts.profit_gates.dropshipping import evaluate_dropshipping_gates

    data = json.loads(FIXTURE.read_text(encoding="utf-8"))
    v = evaluate_dropshipping_gates(data["dropshipping"])
    assert v.overall == "PASS"
    assert len(v.gates) == 7


def test_trading_fails_empty_snapshot():
    from scripts.profit_gates.trading import evaluate_trading_gates

    v = evaluate_trading_gates({})
    assert v.overall == "FAIL"


def test_merge_overall():
    from scripts.profit_gates.types import GateResult, merge_overall

    g = [
        GateResult("G2", "x", True, "", "ok"),
        GateResult("G3", "y", False, "", "warn"),
    ]
    assert merge_overall(g) == "DEGRADED"


def test_load_thresholds():
    from scripts.profit_gates.config import load_thresholds

    cfg = load_thresholds()
    assert "trading" in cfg and "dropshipping" in cfg
    assert cfg["trading"]["g2_research"]["min_trades"] >= 1
