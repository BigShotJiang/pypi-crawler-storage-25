import time
import json
import redis
import sys

def test_sentinel_router():
    r = redis.Redis(host='localhost', port=6379, db=0, decode_responses=True)
    
    print("🚀 Inyectando objetivos para Sentinel Dual Offensive Architecture (v2)...")

    # 1. Externo (Black Box -> RL)
    payload_blackbox = {
        "type": "ope_audit",
        "target": "http://testphp.vulnweb.com",
        "max_iterations": 3
    }
    r.lpush("kernell:tasks:sentinel", json.dumps(payload_blackbox))
    
    # 2. Interno (White Box -> AST)
    payload_whitebox = {
        "type": "ope_audit",
        "target": "/home/anny/kernell-os/agents/sentinel/rl_engine.py",
        "max_iterations": 1
    }
    r.lpush("kernell:tasks:sentinel", json.dumps(payload_whitebox))

    print("✅ Tareas inyectadas. Revisando logs para ver el enrutador táctico operar...")
    
if __name__ == "__main__":
    test_sentinel_router()
