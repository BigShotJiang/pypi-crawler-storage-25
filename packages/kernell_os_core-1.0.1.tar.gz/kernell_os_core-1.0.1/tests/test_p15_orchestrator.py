"""P15 Orchestrator end-to-end test — FakeRedis, no real services."""

import json
import os
import sys
import time

import pytest

sys.path.insert(0, "/home/anny/kernell-os")


class FakeRedis:
    """Minimal Redis mock supporting get/set/lpush/ltrim/rpush/hset/hgetall/delete/pipeline/ping."""

    def __init__(self, data=None):
        self._data: dict = dict(data or {})
        self._lists: dict = {}
        self._hashes: dict = {}

    def ping(self):
        return True

    def get(self, key):
        return self._data.get(key)

    def set(self, key, value, ex=None):
        self._data[key] = value
        return True

    def delete(self, *keys):
        for k in keys:
            self._data.pop(k, None)
            self._lists.pop(k, None)
            self._hashes.pop(k, None)

    def lpush(self, key, *values):
        lst = self._lists.setdefault(key, [])
        for v in reversed(values):
            lst.insert(0, v)
        return len(lst)

    def rpush(self, key, *values):
        lst = self._lists.setdefault(key, [])
        lst.extend(values)
        return len(lst)

    def lrange(self, key, start, end):
        lst = self._lists.get(key, [])
        return lst[start : end + 1] if end >= 0 else lst[start:]

    def ltrim(self, key, start, end):
        lst = self._lists.get(key, [])
        self._lists[key] = lst[start : end + 1] if end >= 0 else lst[start:]
        return True

    def hset(self, key, field=None, value=None, mapping=None):
        h = self._hashes.setdefault(key, {})
        if mapping:
            h.update(mapping)
        elif field is not None:
            h[field] = value

    def hgetall(self, key):
        return dict(self._hashes.get(key, {}))

    def expire(self, key, seconds):
        return True

    def pipeline(self):
        return FakePipeline(self)


class FakePipeline:
    def __init__(self, redis):
        self._redis = redis
        self._ops = []

    def __getattr__(self, name):
        def _queue(*args, **kwargs):
            getattr(self._redis, name)(*args, **kwargs)
            return self
        return _queue

    def execute(self):
        return []


# ── Fixtures ────────────────────────────────────────────────
@pytest.fixture
def r():
    """FakeRedis with realistic trading/dropshipping data."""
    return FakeRedis({
        # Nemesis trading data
        "kernell:nemesis:backtest_result": json.dumps({
            "total_trades": 50,
            "sharpe": 1.2,
            "max_drawdown_pct": 12.0,
            "win_rate": 0.55,
        }),
        "kernell:nemesis:daily_loss_pct": "1.5",
        "kernell:nemesis:open_correlated_positions": "2",
        "kernell:nemesis:reconciliation:latest": json.dumps({"match_pct": 99.5}),
        "kernell:nemesis:monthly_pnl_usd": "350.00",
        "kernell:trading:allowed": "1",
        "kernell:nemesis:graduated": "0",
        # Economy/Dropshipping data
        "ECON:cogs:aggregated": json.dumps({"avg_gross_margin_pct": 32.0, "avg_price_usd": 55.0}),
        "ECON:supplier:last_sync": str(time.time() - 300),  # 5 min ago
        "kernell:ads:metrics:daily": json.dumps({"spend_usd": 50, "roas": 2.5, "cpa_usd": 15}),
        "ECON:cx:metrics": json.dumps({
            "chargeback_rate_pct": 0.3,
            "late_shipment_rate_pct": 2.0,
            "store_rating": 4.6,
        }),
        "ECON:metrics:net_contribution_month_usd": "800.00",
        # System
        "kernell:system:defcon": "5",
        "ECON:pipeline:stats": None,
    })


@pytest.fixture(autouse=True)
def env_setup(monkeypatch):
    monkeypatch.setenv("KERNELL_PROFIT_GATES_ENFORCE_TRADING", "1")
    monkeypatch.setenv("KERNELL_PROFIT_GATES_ENFORCE_DROPSHIP", "1")
    monkeypatch.setenv("PROFIT_GATES_SNAPSHOT_TTL_S", "1200")
    monkeypatch.setenv("REDIS_HOST", "127.0.0.1")
    monkeypatch.setenv("REDIS_PORT", "6380")
    # Avoid needing CJ token for test
    monkeypatch.delenv("CJ_DROPSHIPPING_TOKEN", raising=False)


# ── Test: Snapshot Collector ────────────────────────────────
def test_collect_trading_snapshot(r):
    from scripts.profit_gates.snapshot_collector import collect_trading_snapshot

    snap = collect_trading_snapshot(r)
    assert snap["g2"]["trades_count"] == 50
    assert snap["g2"]["sharpe_ratio"] == 1.2
    assert snap["g2"]["win_rate_pct"] == pytest.approx(55.0, abs=0.01)
    assert snap["g3"]["daily_loss_pct_today"] == 1.5
    assert snap["g3"]["open_correlated_positions"] == 2
    assert snap["g4"]["reconcile_skipped"] is False
    assert snap["g4"]["order_reconcile_match_rate_pct"] == 99.5
    assert snap["g5"]["net_pnl_month_usd"] == 350.0
    assert "_meta" in snap
    assert "collected_at_ts" in snap["_meta"]


def test_collect_dropshipping_snapshot(r):
    from scripts.profit_gates.snapshot_collector import collect_dropshipping_snapshot

    snap = collect_dropshipping_snapshot(r)
    assert snap["b1"]["gross_margin_pct"] == 32.0
    assert snap["b2"]["cj_token_present"] is False
    assert snap["b2"]["supplier_sync_age_minutes"] < 10  # fresh
    assert snap["b3"]["roas"] == 2.5
    assert snap["b4"]["chargeback_rate_pct"] == 0.3
    assert snap["b6"]["store_rating"] == 4.6
    assert "_meta" in snap


def test_collect_all_persists_to_redis(r):
    from scripts.profit_gates.snapshot_collector import (
        KEY_TRADING_SNAPSHOT,
        KEY_DROPSHIP_SNAPSHOT,
        collect_all,
    )

    result = collect_all(r, ttl=600)
    assert result["ok"] is True
    assert result["trading"] is not None
    assert result["dropshipping"] is not None

    # Verify data was persisted
    raw_t = r.get(KEY_TRADING_SNAPSHOT)
    assert raw_t is not None
    snap_t = json.loads(raw_t)
    assert "g2" in snap_t

    raw_d = r.get(KEY_DROPSHIP_SNAPSHOT)
    assert raw_d is not None
    snap_d = json.loads(raw_d)
    assert "b1" in snap_d


def test_collect_trading_only(r):
    from scripts.profit_gates.snapshot_collector import (
        KEY_TRADING_SNAPSHOT,
        KEY_DROPSHIP_SNAPSHOT,
        collect_all,
    )

    result = collect_all(r, ttl=600, trading=True, dropshipping=False)
    assert result["trading"] is not None
    assert result["dropshipping"] is None
    assert r.get(KEY_TRADING_SNAPSHOT) is not None


def test_collect_empty_redis():
    """With empty Redis, collector should still produce valid (zeroed) snapshots."""
    from scripts.profit_gates.snapshot_collector import collect_all

    empty_r = FakeRedis()
    result = collect_all(empty_r, ttl=300)
    assert result["ok"] is True


# ── Test: Gate Evaluation ───────────────────────────────────
def test_gates_pass_with_good_data(r):
    from scripts.profit_gates.snapshot_collector import collect_all

    collect_all(r, ttl=600)

    from scripts.profit_gates.trading import evaluate_trading_gates
    from scripts.profit_gates.dropshipping import evaluate_dropshipping_gates
    from scripts.profit_gates.redis_io import load_snapshots

    t_snap, d_snap = load_snapshots(r)
    t_verdict = evaluate_trading_gates(t_snap)
    assert t_verdict.overall in ("PASS", "DEGRADED")

    # Dropshipping may FAIL on CJ token (not set in test), but shouldn't crash
    d_verdict = evaluate_dropshipping_gates(d_snap)
    assert d_verdict.overall in ("PASS", "FAIL", "DEGRADED")


# ── Test: Orchestrator Cycle ────────────────────────────────
def test_p15_cycle_dry_run(r):
    from scripts.profit_gates.orchestrator import run_p15_cycle

    result = run_p15_cycle(redis_client=r, dry_run=True)
    assert result["ok"] is True
    assert len(result["steps"]) == 3
    for step in result["steps"]:
        assert step.get("status") in ("dry_run", "skipped_by_flag")


def test_p15_cycle_skip_revenue_max(r):
    from scripts.profit_gates.orchestrator import run_p15_cycle

    result = run_p15_cycle(redis_client=r, skip_revenue_max=True)
    assert result["ok"] is True
    # S03 should be skipped
    s3 = [s for s in result["steps"] if s["step"] == "revenue_max"][0]
    assert s3["status"] == "skipped_by_flag"


def test_p15_cycle_full(r):
    from scripts.profit_gates.orchestrator import run_p15_cycle

    result = run_p15_cycle(redis_client=r, skip_revenue_max=True)
    assert "steps" in result
    assert result["duration_s"] >= 0

    # Verify cycle was persisted
    last = r.get("kernell:p15:last_cycle")
    assert last is not None
    cycle_data = json.loads(last)
    assert cycle_data["pipeline"] == "P15_autonomy_closed_loop"


# ── Test: Drift Detection ──────────────────────────────────
def test_drift_ads_over_cap(r, monkeypatch):
    monkeypatch.setenv("REVENUE_PIPELINE_ADS_CAP", "100")
    r.set("kernell:ads:daily_spent_usd", "150")

    from scripts.profit_gates.orchestrator import _check_drift

    eval_result = {"trading_overall": "PASS", "dropshipping_overall": "PASS"}
    alert = _check_drift(r, eval_result)
    assert alert is not None
    types = [a["type"] for a in alert["alerts"]]
    assert "ads_over_cap" in types


def test_no_drift_normal(r):
    from scripts.profit_gates.orchestrator import _check_drift

    eval_result = {"trading_overall": "PASS", "dropshipping_overall": "PASS"}
    alert = _check_drift(r, eval_result)
    assert alert is None


def test_drift_cross_pipeline(r):
    from scripts.profit_gates.orchestrator import _check_drift

    eval_result = {"trading_overall": "PASS", "dropshipping_overall": "FAIL"}
    alert = _check_drift(r, eval_result)
    assert alert is not None
    types = [a["type"] for a in alert["alerts"]]
    assert "cross_pipeline_divergence" in types


# ── Test: Guard Freshness ───────────────────────────────────
def test_guard_stale_verdict(monkeypatch):
    monkeypatch.setenv("KERNELL_PROFIT_GATES_ENFORCE_TRADING", "1")
    monkeypatch.setenv("KERNELL_PROFIT_GATES_MAX_VERDICT_AGE_S", "60")

    from agents.core import profit_gates_guard as g
    from datetime import datetime, timezone, timedelta

    old_ts = (datetime.now(timezone.utc) - timedelta(seconds=120)).isoformat()
    fr = FakeRedis({
        g.KEY_LAST_RUN: old_ts,
        g.KEY_TRADING_VERDICT: json.dumps({"overall": "PASS"}),
    })
    ok, msg = g.trading_real_execution_allowed(fr)
    assert ok is False
    assert "stale" in msg.lower()


def test_guard_fresh_verdict(monkeypatch):
    monkeypatch.setenv("KERNELL_PROFIT_GATES_ENFORCE_TRADING", "1")
    monkeypatch.setenv("KERNELL_PROFIT_GATES_MAX_VERDICT_AGE_S", "3600")

    from agents.core import profit_gates_guard as g
    from datetime import datetime, timezone

    fresh_ts = datetime.now(timezone.utc).isoformat()
    fr = FakeRedis({
        g.KEY_LAST_RUN: fresh_ts,
        g.KEY_TRADING_VERDICT: json.dumps({"overall": "PASS"}),
    })
    ok, msg = g.trading_real_execution_allowed(fr)
    assert ok is True


def test_guard_dropshipping_stale(monkeypatch):
    monkeypatch.setenv("KERNELL_PROFIT_GATES_ENFORCE_DROPSHIP", "1")
    monkeypatch.setenv("KERNELL_PROFIT_GATES_MAX_VERDICT_AGE_S", "10")

    from agents.core import profit_gates_guard as g
    from datetime import datetime, timezone, timedelta

    old_ts = (datetime.now(timezone.utc) - timedelta(seconds=120)).isoformat()
    fr = FakeRedis({
        g.KEY_LAST_RUN: old_ts,
        g.KEY_DROPSHIP_VERDICT: json.dumps({"overall": "PASS"}),
    })
    status = g.dropshipping_gate_status(fr)
    assert status == "STALE"
