#!/usr/bin/env python3
"""
S3-T01 — Trading Expansion E2E Test
=====================================
Validates the full pipeline end-to-end:
    Snapshot → Decision → Allocation → Execution(paper) → Telemetry

Exit code 0 = PASS, 1 = FAIL
"""

import os
import sys
import json
import time
import logging
from pathlib import Path

ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT))

logging.basicConfig(level=logging.INFO, format="%(message)s")
logger = logging.getLogger("e2e_test")


def get_redis():
    import redis
    pw = os.getenv("REDIS_PASSWORD", "").strip().strip("\"'")
    return redis.Redis(
        host="127.0.0.1", port=6380,
        password=pw or None,
        decode_responses=True,
        socket_connect_timeout=3,
    )


def test_redis_connectivity(r) -> bool:
    try:
        r.ping()
        logger.info("✅ Redis connectivity OK")
        return True
    except Exception as e:
        logger.error(f"❌ Redis: {e}")
        return False


def test_snapshot_exists(r) -> bool:
    """Atlas should publish reality snapshot."""
    raw = r.get("kernell:reality:snapshot")
    if raw:
        snap = json.loads(raw)
        drift = snap.get("drift_index", -1)
        mode = snap.get("mode", "?")
        logger.info(f"✅ Reality snapshot: mode={mode}, drift={drift:.1f}")
        return True
    logger.warning("⚠️ No reality snapshot — Atlas may not have run yet")
    return True  # Non-blocking for e2e


def test_risk_manager(r) -> bool:
    """RiskManager can read system state without crashing."""
    try:
        from agents.nemesis.risk_manager import RiskManager
        rm = RiskManager(r)
        state = rm.get_system_state()
        logger.info(
            f"✅ RiskManager state: DEFCON={state.defcon}, "
            f"budget=${state.nemesis_budget_usd:.2f}, "
            f"positions={state.open_positions_count}"
        )
        return True
    except Exception as e:
        logger.error(f"❌ RiskManager: {e}")
        return False


def test_graduation_gate(r) -> bool:
    """GraduationGate responds without error."""
    try:
        from agents.nemesis.graduation import GraduationGate
        from agents.nemesis.risk_manager import RiskManager
        rm = RiskManager(r)
        state = rm.get_system_state()
        gg = GraduationGate(r)
        graduated, reason = gg.check_graduation(state)
        logger.info(f"✅ Graduation gate: graduated={graduated}, reason={reason[:60]}")
        return True
    except Exception as e:
        logger.error(f"❌ GraduationGate: {e}")
        return False


def test_treasury_allocator(r) -> bool:
    """Treasury allocator keys exist in Redis."""
    keys_to_check = [
        "kernell:treasury:alloc:weights",
    ]
    found = 0
    for k in keys_to_check:
        if r.exists(k):
            found += 1
    if found > 0:
        logger.info(f"✅ Treasury allocator: {found}/{len(keys_to_check)} keys present")
        return True
    logger.warning("⚠️ Treasury allocator keys not yet published (Economy may not have run)")
    return True  # Non-blocking


def test_backtest_publisher(r) -> bool:
    """Auto-backtester can run and publish."""
    try:
        from agents.nemesis.auto_backtester import run_paper_trade_backtest
        result = run_paper_trade_backtest(r)
        if result:
            logger.info(
                f"✅ Auto-backtest: WR={result['win_rate']:.2%}, "
                f"trades={result['total_trades']}"
            )
        else:
            logger.info("✅ Auto-backtest: no paper trades yet (OK for fresh system)")
        return True
    except Exception as e:
        logger.error(f"❌ Auto-backtest: {e}")
        return False


def test_heartbeats(r) -> bool:
    """Critical agents have heartbeats."""
    critical = ["kernell", "atlas", "sentinel", "nemesis", "economy", "sierra"]
    alive = 0
    for agent in critical:
        hb = r.get(f"kernell:agent:{agent}:heartbeat")
        if hb:
            alive += 1
    if alive >= len(critical) - 1:  # Allow 1 missing
        logger.info(f"✅ Heartbeats: {alive}/{len(critical)} critical agents alive")
        return True
    logger.error(f"❌ Only {alive}/{len(critical)} critical agents have heartbeats")
    return False


def test_decision_ledger(r) -> bool:
    """Decision ledger exists (may be empty for new systems)."""
    length = r.llen("kernell:nemesis:decision_ledger:v2")
    logger.info(f"✅ Decision ledger v2: {length} entries")
    return True


def test_kill_switch(r) -> bool:
    """Kill switch should be OFF for trading."""
    ks = r.get("kernell:economy:kill_switch")
    if ks and ks.lower() == "true":
        logger.warning("⚠️ Kill switch is ON — trading blocked")
        return True  # Valid state, not a test failure
    logger.info("✅ Kill switch: OFF")
    return True


def main():
    r = get_redis()

    tests = [
        ("Redis Connectivity", test_redis_connectivity),
        ("Reality Snapshot", test_snapshot_exists),
        ("Risk Manager", test_risk_manager),
        ("Graduation Gate", test_graduation_gate),
        ("Treasury Allocator", test_treasury_allocator),
        ("Auto Backtest", test_backtest_publisher),
        ("Critical Heartbeats", test_heartbeats),
        ("Decision Ledger", test_decision_ledger),
        ("Kill Switch", test_kill_switch),
    ]

    print("\n" + "=" * 50)
    print("  S3-T01: Trading Expansion E2E Test")
    print("=" * 50 + "\n")

    passed = 0
    failed = 0
    for name, test_fn in tests:
        try:
            if test_fn(r):
                passed += 1
            else:
                failed += 1
        except Exception as e:
            logger.error(f"❌ {name}: EXCEPTION {e}")
            failed += 1

    print(f"\n{'=' * 50}")
    print(f"  Results: {passed} PASSED, {failed} FAILED")
    print(f"  Status: {'✅ PASS' if failed == 0 else '❌ FAIL'}")
    print(f"{'=' * 50}\n")

    sys.exit(0 if failed == 0 else 1)


if __name__ == "__main__":
    main()
