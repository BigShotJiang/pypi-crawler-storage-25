import os
import json
import time

from agents.core.degradation import DegradationProtocol

def test_degradation_protocol():
    print("🛡️ Starting Degradation Protocol Test...")
    
    # Initialize without Redis to simulate L1 cache failure
    proto = DegradationProtocol(redis_client=None)
    
    # 1. Force Qdrant failure by overriding environment
    os.environ['QDRANT_HOST'] = "1.2.3.4" # Unreachable IP
    level, report = proto.evaluate()
    
    print(f"Current Level: {proto.get_level_name()} ({level})")
    assert level >= 1, "Level should be at least DEGRADED (1) with Qdrant down"
    print("Report Issues:")
    for issue in report['issues']:
        print(f" - {issue}")
    
    # 2. Check if non-critical agents should pause
    pause_active = proto.should_pause()
    print(f"Is system-wide pause active in local cache? {pause_active}")
    
    # 3. Check agent allowances
    assert proto.is_agent_allowed("atlas") == True, "Atlas is critical, must be allowed"
    
    if level >= 2:
        assert proto.is_agent_allowed("telegram_bridge") == False, "Telegram Bridge is non-critical, should pause in EMERGENCY"
        print("✅ Correctly rejected non-critical agent during emergency.")
    else:
        print("🟡 (System not in Emergency, skipping reject test)")
    
    print("\n✅ Degradation Protocol Test Passed!")

if __name__ == "__main__":
    test_degradation_protocol()
