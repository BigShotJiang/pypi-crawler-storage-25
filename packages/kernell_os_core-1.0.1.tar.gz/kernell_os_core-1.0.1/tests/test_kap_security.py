"""
KAP Security Regression Tests
==============================
Validates the 4 patches from KAP-SEC-2026-04 audit.
Run:  cd /home/anny/kernell-os && python -m pytest tests/test_kap_security.py -v
"""
import json
import pytest

# ── KAP-02: Merkle Tree Regression ──────────────────────────────


def test_merkle_odd_leaf_no_collision():
    """
    KAP-02b: [A, B, C] must NOT produce the same root as [A, B, C, C].
    Before the fix, duplicating the last leaf on odd layers caused
    identical roots for different transaction sets.
    """
    from kap_escrow.merkle import MerkleTree

    tree1 = MerkleTree()
    root1 = tree1.build(["A", "B", "C"])

    tree2 = MerkleTree()
    root2 = tree2.build(["A", "B", "C", "C"])

    assert root1 != root2, (
        f"COLLISION: [A,B,C] root == [A,B,C,C] root ({root1}). "
        f"CVE-2012-2459 class vulnerability still present."
    )


def test_merkle_positional_ordering():
    """
    KAP-02a: Swapping children must produce a DIFFERENT root.
    Before the fix, sorting by lexicographic order made
    hash(L, R) == hash(R, L), destroying structural integrity.
    """
    from kap_escrow.merkle import _node_hash

    h1 = _node_hash("aaa", "zzz")
    h2 = _node_hash("zzz", "aaa")
    assert h1 != h2, (
        "Node hash is commutative — swapping L/R produces same result. "
        "Positional ordering fix not applied."
    )


def test_merkle_proof_roundtrip():
    """Verify that inclusion proofs still work after the fix."""
    from kap_escrow.merkle import MerkleTree

    items = ["tx1", "tx2", "tx3", "tx4", "tx5"]
    tree = MerkleTree()
    root = tree.build(items)

    for item in items:
        proof = tree.get_proof(item)
        assert MerkleTree.verify_proof(item, proof, root), (
            f"Proof verification failed for {item}"
        )


def test_merkle_proof_odd_count():
    """Proofs must work for odd leaf counts too."""
    from kap_escrow.merkle import MerkleTree

    items = ["alpha", "beta", "gamma"]
    tree = MerkleTree()
    root = tree.build(items)

    for item in items:
        proof = tree.get_proof(item)
        assert MerkleTree.verify_proof(item, proof, root), (
            f"Odd-count proof failed for {item}"
        )


def test_merkle_empty_tree():
    """Empty tree should produce a deterministic empty root."""
    from kap_escrow.merkle import MerkleTree

    tree = MerkleTree()
    root = tree.build([])
    assert root is not None
    assert len(root) == 64  # SHA-256 hex digest


def test_merkle_single_item():
    """Single-item tree root == leaf hash."""
    from kap_escrow.merkle import MerkleTree, _leaf_hash

    tree = MerkleTree()
    root = tree.build(["only_one"])
    assert root == _leaf_hash("only_one")


# ── KAP-01: Engine Escrow TTL ──────────────────────────────────


def test_engine_lock_no_ttl():
    """
    KAP-01: Verify that engine.lock() does NOT set a TTL on escrow keys.
    We inspect the source code since we can't run against live Redis.
    """
    import inspect
    from kap_escrow.engine import EscrowEngine

    source = inspect.getsource(EscrowEngine.lock)
    assert "ex=300" not in source, (
        "engine.lock() still contains ex=300 TTL on escrow keys. "
        "KAP-01 patch not applied — funds will black-hole."
    )
    assert "ex=" not in source or "pipe.execute" in source, (
        "Unexpected expire parameter found in lock()."
    )


# ── KAP-03: WAL PENDING/COMMITTED ─────────────────────────────


def test_engine_wal_has_pending_committed():
    """
    KAP-03: Verify the WAL now writes PENDING before Redis
    and COMMITTED after.
    """
    import inspect
    from kap_escrow.engine import EscrowEngine

    source = inspect.getsource(EscrowEngine._append_tx)
    assert "PENDING" in source, "WAL PENDING phase not found in _append_tx"
    assert "COMMITTED" in source, "WAL COMMITTED phase not found in _append_tx"


# ── KAP-04: Lua Nonce Script ──────────────────────────────────


def test_engine_uses_lua_nonce():
    """KAP-04: Verify nonce cleanup uses Lua scripting."""
    import inspect
    from kap_escrow.engine import EscrowEngine

    source = inspect.getsource(EscrowEngine._check_nonce)
    assert "evalsha" in source.lower(), (
        "Nonce check does not use EVALSHA for Lua scripting. "
        "KAP-04 atomic nonce patch not applied."
    )


def test_agent_wallet_uses_pessimistic_lua_for_critical_paths():
    """
    Regression guard: critical AgentWallet flows must use Lua pessimistic execution,
    not WATCH/MULTI optimistic transactions.
    """
    import inspect
    from agents.finance.economy.agent_wallet import AgentWallet

    critical_methods = [
        AgentWallet.transfer,
        AgentWallet.escrow_lock,
        AgentWallet.escrow_refund,
        AgentWallet.escrow_settle,
    ]

    for method in critical_methods:
        source = inspect.getsource(method).lower()
        assert "evalsha" in source, (
            f"{method.__name__} does not use evalsha-based execution."
        )
        assert ".watch(" not in source, (
            f"{method.__name__} still uses WATCH/MULTI optimistic locking."
        )


# ── Signing Module (Ed25519) ───────────────────────────────────

def test_sign_verify_roundtrip():
    """Basic asymmetric Ed25519 signing and verification."""
    from kap_escrow.signing import sign_tx, verify_tx
    import nacl.signing

    record = {"type": "credit", "to": "agent_a", "amount": 100.0}
    # Create an actual seed for Ed25519 (must be 32 bytes)
    private_seed = b"1" * 32
    signer = nacl.signing.SigningKey(private_seed)
    
    signed_record = sign_tx(record.copy(), private_key=private_seed)

    # Allow exactly this public key in the ring
    ring = {signer.verify_key.encode()}
    assert verify_tx(signed_record, public_keyring=ring)
    
    # Try without keyring (should just verify the signature math)
    assert verify_tx(signed_record)


def test_sign_tamper_detection():
    """Tampering with amount must invalidate signature."""
    from kap_escrow.signing import sign_tx, verify_tx

    record = {"type": "credit", "to": "agent_a", "amount": 100.0}
    private_seed = b"1" * 32
    
    signed_record = sign_tx(record, private_key=private_seed)
    signed_record["amount"] = 999.0  # Tamper
    
    assert not verify_tx(signed_record)


def test_sign_requires_key():
    """Signing without a private key must raise."""
    from kap_escrow.signing import sign_tx

    import pytest
    with pytest.raises(ValueError, match="private_key is required"):
        sign_tx({"type": "test"}, private_key=b"")


def test_sign_unauthorized_key():
    """Valid signature but from an unauthorized key should fail if keyring is strict."""
    from kap_escrow.signing import sign_tx, verify_tx
    import nacl.signing
    
    record = {"type": "credit", "to": "agent_a"}
    rogue_seed = b"r" * 32
    signed = sign_tx(record, private_key=rogue_seed)
    
    # Only allow a different key
    strict_ring = {b"a_totally_different_pubkey"}
    
    assert not verify_tx(signed, public_keyring=strict_ring)



# ── A2A Agent Card ─────────────────────────────────────────────


def test_agent_card_deterministic_id():
    """Same name+url → same agent_id."""
    from kap_escrow.a2a_compat import AgentCard

    c1 = AgentCard(name="Nemesis", url="https://nemesis.kernell.io")
    c2 = AgentCard(name="Nemesis", url="https://nemesis.kernell.io")
    assert c1.agent_id == c2.agent_id


def test_agent_card_validation():
    """Cards without URL must fail validation."""
    from kap_escrow.a2a_compat import AgentCard, validate_agent_card

    bad = AgentCard(name="Test", url="")
    ok, msg = validate_agent_card(bad)
    assert not ok


# ── AP2 Mandate ────────────────────────────────────────────────


def test_mandate_expiration():
    """Expired mandate must be rejected."""
    from kap_escrow.ap2_compat import Mandate, validate_mandate

    m = Mandate(
        mandate_id="m1", payer_id="user1", agent_id="bot1",
        service_type="search", max_amount=50.0,
        expires_at=1000.0  # long expired
    )
    ok, _ = validate_mandate(m)
    assert not ok


def test_mandate_budget_enforcement():
    """Lock amount must be capped by mandate.max_amount."""
    from kap_escrow.ap2_compat import Mandate

    m = Mandate(
        mandate_id="m2", payer_id="user2", agent_id="bot2",
        service_type="compute", max_amount=10.0,
    )
    lock = min(100.0, m.max_amount)
    assert lock == 10.0
