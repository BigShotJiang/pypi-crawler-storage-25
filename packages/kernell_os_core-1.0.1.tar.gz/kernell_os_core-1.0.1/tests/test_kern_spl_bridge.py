"""Tests for KERN → SPL mobile withdrawal bridge (no live Solana RPC)."""
import inspect
import json
from unittest.mock import MagicMock

import pytest


def test_validate_solana_pubkey_accepts_typical():
    from agents.finance.economy.kern_spl_bridge import validate_solana_pubkey

    ok, _ = validate_solana_pubkey("So11111111111111111111111111111111111111112")
    assert ok
    ok2, _ = validate_solana_pubkey("")
    assert not ok2


def test_mobile_ledger_key_sanitizes():
    from agents.finance.economy.kern_spl_bridge import mobile_ledger_key

    assert mobile_ledger_key("dev-1") == "kernell:economy:balance:dev-1"


def test_enqueue_uses_evalsha_not_watch():
    """Regression: withdrawal enqueue must stay Lua-based (no optimistic WATCH)."""
    from agents.finance.economy import kern_spl_bridge as k

    src = inspect.getsource(k.enqueue_mobile_withdrawal)
    assert "evalsha" in src.lower()
    assert ".watch(" not in src


def test_enqueue_mock_redis_happy_path():
    from agents.finance.economy import kern_spl_bridge as k

    k._SCRIPT_SHA_ENQUEUE = None
    r = MagicMock()
    r.script_load.return_value = "deadbeef"
    r.evalsha.return_value = 1

    ok, msg, jid = k.enqueue_mobile_withdrawal(
        r,
        device_id="device_a",
        amount_ku=10.5,
        destination_spl_address="So11111111111111111111111111111111111111112",
    )
    assert ok is True
    assert jid == msg
    r.hset.assert_called_once()
    call_kw = r.hset.call_args[1]["mapping"]
    assert "queued" in call_kw.get("status", "")


def test_enqueue_insufficient_balance():
    from agents.finance.economy import kern_spl_bridge as k

    k._SCRIPT_SHA_ENQUEUE = None
    r = MagicMock()
    r.script_load.return_value = "deadbeef"
    r.evalsha.return_value = -1

    ok, msg, jid = k.enqueue_mobile_withdrawal(
        r,
        device_id="device_a",
        amount_ku=999.0,
        destination_spl_address="So11111111111111111111111111111111111111112",
    )
    assert ok is False
    assert msg == "insufficient_balance"
    assert jid is None


def test_enqueue_with_real_redis_optional():
    """Opcional: `pytest -m integration` con Redis local y REDIS_URL."""
    import os

    url = os.getenv("REDIS_TEST_URL", os.getenv("REDIS_URL", ""))
    if not url:
        pytest.skip("REDIS_TEST_URL / REDIS_URL not set")

    import redis
    from agents.finance.economy import kern_spl_bridge as k

    k._SCRIPT_SHA_ENQUEUE = None
    r = redis.Redis.from_url(url, decode_responses=True)
    dev = "pytest_kern_bridge_device"
    lk = k.mobile_ledger_key(dev)
    r.set(lk, "100.0")
    ok, msg, jid = k.enqueue_mobile_withdrawal(
        r,
        device_id=dev,
        amount_ku=1.0,
        destination_spl_address="So11111111111111111111111111111111111111112",
    )
    assert ok, msg
    raw = r.lpop(k.WITHDRAW_QUEUE_KEY)
    assert raw
    job = json.loads(raw)
    assert job["job_id"] == jid
    assert float(r.get(lk)) == pytest.approx(99.0)
    r.delete(lk, k._job_key(jid))
