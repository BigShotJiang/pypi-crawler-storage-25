"""
KERNELL OS — Economy Agent Tests
===================================
Tests para kill switch, circuit breaker, financial consolidation,
causal warning system and risk evaluation pipeline.
"""
import sys
import json
import time
import pytest
from unittest.mock import MagicMock, patch
from pathlib import Path

ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT))


class FakeBytes(str):
    """String that supports .decode() for compatibility with code expecting bytes."""
    def decode(self, *args, **kwargs):
        return str(self)


class MockRedis:
    """Mock Redis for Economy tests."""
    def __init__(self): self.store, self._pubsub_channels = {}, {}
    def get(self, key):
        v = self.store.get(key)
        return FakeBytes(v) if v is not None else None
    def set(self, key, value, **kwargs): self.store[key] = str(value) if not isinstance(value, str) else value
    def hset(self, key, field=None, value=None, mapping=None, **kwargs):
        if key not in self.store: self.store[key] = {}
        if field is not None and value is not None:
            self.store[key][str(field)] = str(value)
        if mapping: self.store[key].update({str(k): str(v) for k, v in mapping.items()})
        for k, v in kwargs.items(): self.store[key][str(k)] = str(v)
    def hgetall(self, key): return self.store.get(key, {})
    def hget(self, key, field): return self.store.get(key, {}).get(field)
    def incr(self, key): self.store[key] = str(int(self.store.get(key, "0")) + 1)
    def incrby(self, key, n): self.store[key] = str(int(self.store.get(key, "0")) + n)
    def publish(self, channel, msg):
        self._pubsub_channels.setdefault(channel, []).append(msg)
    def rpush(self, key, *values):
        if key not in self.store: self.store[key] = []
        self.store[key].extend(values)
    def pubsub(self): return MagicMock()


# ── Risk Evaluation Tests ──────────────────────────────────────

class TestEconomyRiskEvaluation:
    """Tests for economy/risk.py — opportunity risk assessment."""

    def test_evaluate_risk_returns_dict(self):
        from agents.finance.economy.risk import evaluate_risk
        opp = {"uuid": "test1", "supplier": "TestCo", "price": 10.0}
        result = evaluate_risk(opp)
        assert isinstance(result, dict)
        assert "risk_profile" in result
        assert "score" in result["risk_profile"]

    def test_risk_score_range(self):
        from agents.finance.economy.risk import evaluate_risk
        opp = {"uuid": "test2", "supplier": "TestCo", "price": 10.0}
        result = evaluate_risk(opp)
        score = result["risk_profile"]["score"]
        assert 0.0 <= score <= 1.0

    def test_high_price_increases_risk(self):
        from agents.finance.economy.risk import evaluate_risk
        cheap = evaluate_risk({"uuid": "c", "supplier": "A", "price": 5.0})
        expensive = evaluate_risk({"uuid": "e", "supplier": "A", "price": 200.0})
        assert expensive["risk_profile"]["score"] >= 0.0


# ── Kill Switch / Emergency Tests ────────────────────────────

class TestKillSwitch:
    """Tests for the Economy emergency & kill-switch mechanism."""

    def test_nemesis_kill_switch_blocks_trading(self):
        """When kill_switch is set, Nemesis RiskManager should block all trades."""
        from agents.nemesis.risk_manager import RiskManager, RiskViolation
        r = MockRedis()
        r.set("kernell:system:defcon", "1")
        r.set("kernell:economy:kill_switch", "true")
        r.set("kernell:economy:nemesis_budget", "1000")
        r.set("kernell:nemesis:daily_loss_usd", "0")
        r.set("kernell:nemesis:open_positions_count", "0")
        r.set("kernell:reality:snapshot", json.dumps({"drift_index": 5.0, "mode": "STABLE"}))
        rm = RiskManager(r)
        with pytest.raises(RiskViolation, match="kill_switch"):
            rm.validate_all(100.0)

    def test_critical_mode_triggers_emergency(self):
        """EconomyManager.run() should freeze when Atlas mode is CRITICAL."""
        r = MockRedis()
        r.set("kernell:reality:snapshot", json.dumps({
            "drift_index": 90.0, "mode": "CRITICAL", "confidence_score": 10.0
        }))

        from agents.finance.economy.manager import EconomyManager
        with patch.object(EconomyManager, '__init__', lambda self: None):
            mgr = EconomyManager()
            mgr.redis = r
            mgr.logger = MagicMock()
            mgr._cycle_count = 1
            mgr.emergency_threshold = 0.8
            # Mock the emergency trigger to avoid AgentMessage import issues
            mgr._trigger_economic_emergency = MagicMock(
                side_effect=lambda reason: r.hset("economy.global", "status", "emergency")
            )
            mgr._consolidate_finances = MagicMock()

            mgr.run()
            
            # Verify emergency was triggered
            mgr._trigger_economic_emergency.assert_called_once()
            global_state = r.hgetall("economy.global")
            assert global_state.get("status") == "emergency"

    def test_causal_warning_high_confidence(self):
        """Economy should trigger preventive action on high-confidence causal signal."""
        r = MockRedis()
        from agents.finance.economy.manager import EconomyManager
        with patch.object(EconomyManager, '__init__', lambda self: None):
            mgr = EconomyManager()
            mgr.redis = r
            mgr.logger = MagicMock()
            mgr.emergency_threshold = 0.8

            mgr.handle_causal_warning({
                "confidence": 0.95,
                "hypothesized_causes": ["demand_drop"]
            })

            # Should have published pause
            assert "kernell:economy:control" in r._pubsub_channels
            msg = json.loads(r._pubsub_channels["kernell:economy:control"][0])
            assert msg["command"] == "PAUSE_EXPOSURE"

    def test_causal_warning_low_confidence_no_action(self):
        """Low confidence causal warnings should not trigger preventive action."""
        r = MockRedis()
        from agents.finance.economy.manager import EconomyManager
        with patch.object(EconomyManager, '__init__', lambda self: None):
            mgr = EconomyManager()
            mgr.redis = r
            mgr.logger = MagicMock()
            mgr.emergency_threshold = 0.8

            mgr.handle_causal_warning({
                "confidence": 0.3,
                "hypothesized_causes": ["noise"]
            })

            assert "kernell:economy:control" not in r._pubsub_channels


# ── Financial Consolidation Tests ────────────────────────────

class TestFinancialConsolidation:
    """Tests for economy consolidation and global metrics."""

    def test_consolidation_writes_global_state(self):
        r = MockRedis()
        from agents.finance.economy.manager import EconomyManager
        with patch.object(EconomyManager, '__init__', lambda self: None):
            mgr = EconomyManager()
            mgr.redis = r
            mgr.logger = MagicMock()
            mgr._cycle_count = 5

            mgr._consolidate_finances()

            global_state = r.hgetall("economy.global")
            assert "revenue_today" in global_state
            assert "profit_today" in global_state
            assert "status" in global_state

    def test_negative_roi_triggers_emergency(self):
        """Global ROI < -10% should trigger emergency."""
        r = MockRedis()
        # Setup data that yields negative ROI
        r.hset("economy.marketplace.shopify", mapping={
            "revenue": "100", "profit": "-50", "store_count": "1"
        })
        from agents.finance.economy.manager import EconomyManager
        with patch.object(EconomyManager, '__init__', lambda self: None):
            mgr = EconomyManager()
            mgr.redis = r
            mgr.logger = MagicMock()
            mgr._cycle_count = 1

            mgr._consolidate_finances()

            global_state = r.hgetall("economy.global")
            # If ROI is critically negative, emergency should trigger
            # (ROI formula: profit/cost * 100 where cost = revenue - profit)
            # With revenue=100, profit=-50 → cost=150, ROI = -50/150*100 = -33%
            assert global_state.get("status") == "emergency"

    def test_stress_mode_skips_heavy_tasks(self):
        """In STRESS mode, should skip fulfillment and promotion."""
        r = MockRedis()
        r.set("kernell:reality:snapshot", json.dumps({
            "drift_index": 50.0, "mode": "STRESS", "confidence_score": 60.0
        }))
        from agents.finance.economy.manager import EconomyManager
        with patch.object(EconomyManager, '__init__', lambda self: None):
            mgr = EconomyManager()
            mgr.redis = r
            mgr.logger = MagicMock()
            mgr._cycle_count = 1
            # Mock pipeline to return empty
            mgr._run_autonomous_pipeline = MagicMock(return_value=[])
            mgr._consolidate_finances = MagicMock()

            mgr.run()

            # Pipeline should run with penalty
            mgr._run_autonomous_pipeline.assert_called_once_with(confidence_penalty=True)
            # Consolidation should still run
            mgr._consolidate_finances.assert_called_once()
