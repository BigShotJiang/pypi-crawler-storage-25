import os
import time
from agents.core.cognitive_pressure import CognitivePressureManager, PRESSURE_WARNING, PRESSURE_COMPRESS

def test_cognitive_pressure():
    print("🧠 Starting Cognitive Pressure Test...")
    
    # Initialize with a tiny max_tokens so it's easy to hit pressure
    manager = CognitivePressureManager(model="test_model")
    manager.max_tokens = 1000  # Artificially low limit for testing
    
    print(f"Max tokens limit: {manager.max_tokens}")
    
    # 1. Add some priority blocks
    manager.add_block("This is the system prompt. Never compress this.", priority=3, source="system")
    manager.add_block("This is an old context block that we don't care about.", priority=1, source="user")
    manager.add_block("This is a strategic plan that we should summarize.", priority=2, source="agent")
    
    level, ratio = manager.get_pressure()
    print(f"Initial pressure: {level} ({ratio*100:.1f}%)")
    assert level == "nominal"
    
    # 2. Induce pressure by adding a massive block
    print("\n📦 Adding massive block to induce pressure...")
    massive_text = "word " * 2000  # Should be ~500 tokens
    manager.add_block(massive_text, priority=1, source="user_input")
    
    level, ratio = manager.get_pressure()
    print(f"Pressure after massive block: {level} ({ratio*100:.1f}%)")
    
    budget = manager.get_context_budget()
    print(f"Active blocks: {budget['active_blocks']} | Archived: {budget['archived_blocks']}")
    print(f"Compressions triggered: {budget['compressions_total']} | Pages out: {budget['pages_out']}")
    
    # 3. Verify compression worked
    assert manager.compressions_triggered > 0, "Wait, compression should have triggered!"
    assert manager.pages_out > 0, "Wait, page-out should have occurred!"
    
    active = [b for b in manager.blocks if not b.archived]
    print(f"\nRemaining active blocks: {len(active)}")
    for b in active:
        print(f" - [Pri {b.priority}] {b.source}: {b.token_estimate} tokens")
        
    print("\n✅ Cognitive Pressure Test Passed!")

if __name__ == "__main__":
    test_cognitive_pressure()
