"""PM-001 / PM-002 — venue policy + global kill-switch / DEFCON gates for Pythia."""

from __future__ import annotations

import pytest

from agents.trading.pythia.venue_policy import venue_allows_live_execution
from agents.trading.pythia.system_risk_gate import system_allows_pythia_live


class _FakeRedis:
    def __init__(self, mapping: dict):
        self._m = mapping

    def get(self, key: str):
        return self._m.get(key)


def test_venue_allows_only_polymarket_live():
    assert venue_allows_live_execution("polymarket") is True
    assert venue_allows_live_execution("POLYMARKET") is True
    assert venue_allows_live_execution("kalshi") is False
    assert venue_allows_live_execution("") is False
    assert venue_allows_live_execution(None) is False


def test_system_gate_kill_switch():
    r = _FakeRedis({"kernell:economy:kill_switch": "true"})
    ok, reason = system_allows_pythia_live(r)
    assert ok is False
    assert reason == "kill_switch_active"


def test_system_gate_defcon_crisis():
    r = _FakeRedis({"kernell:system:defcon": "1"})
    ok, reason = system_allows_pythia_live(r)
    assert ok is False
    assert "defcon_block_live" in reason


def test_system_gate_nominal():
    r = _FakeRedis({"kernell:system:defcon": "5", "kernell:economy:kill_switch": "false"})
    ok, reason = system_allows_pythia_live(r)
    assert ok is True
    assert reason == "ok"
