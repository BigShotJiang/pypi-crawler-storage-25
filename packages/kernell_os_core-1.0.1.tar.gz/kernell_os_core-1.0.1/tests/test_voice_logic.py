import sys
import time
import logging
from pathlib import Path
from unittest.mock import MagicMock

# Add root path
sys.path.append(str(Path(__file__).parent.parent))

# Mock PyQt6 before importing Bridge to avoid GUI requirement issues in headless envs
# Actually, Bridge imports QObject, so we need PyQt6 installed. It is.
# But we need a QApp to use signals.

from PyQt6.QtWidgets import QApplication
from agents.interface.bridge import Bridge

# Setup Logger
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("TEST_VOICE")

def test_logic():
    print("\n🎤 TESTING VOICE LOGIC (HEADLESS) 🎤\n")
    
    # 1. Setup App (Required for QThread/Signals)
    app = QApplication(sys.argv)
    
    # 2. Init Bridge
    bridge = Bridge()
    
    # 3. Mock Hardware (Ears/Mouth)
    bridge.ears = MagicMock()
    bridge.mouth = MagicMock()
    
    # 4. Mock Input
    test_phrase = "Report system status"
    bridge.ears.listen.return_value = test_phrase
    
    print(f"✅ Bridge Initialized. Testing input: '{test_phrase}'")
    
    # 5. Run Logic Step Manually (bypass loop threading for test)
    # We call the internal processor directly
    response = bridge._process_thought(test_phrase)
    
    print(f"\n🧠 BRAIN RESPONSE:\n{response}\n")
    
    if "my brain is offline" in response.lower():
        print("❌ LLM Connection Failed (Check API Key)")
    else:
        print("✅ LLM Connected & Responded")

    # 6. Test Stop
    bridge.stop()
    print("\n✅ Cleanup Successful")

if __name__ == "__main__":
    test_logic()
