#!/usr/bin/env python3
import pytest
import redis
import httpx
import subprocess
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).parent.parent))
from agents.core.config import get_redis_client


class TestRedis:
    """Test Redis connectivity and operations"""
    
    def test_redis_connection(self):
        """Test basic Redis connection with auth"""
        try:
            r = get_redis_client()
            r.ping()
            assert True
        except redis.exceptions.ConnectionError as e:
            pytest.fail(f"Redis connection failed: {e}")
    
    def test_redis_docker_container(self):
        """Test Redis Docker container is running"""
        result = subprocess.run(
            ["docker", "ps", "--filter", "name=kernell-redis", "--format", "{{.Status}}"],
            capture_output=True,
            text=True
        )
        
        assert "Up" in result.stdout, "Redis container is not running"
    
    def test_redis_port_accessible(self):
        """Test Redis port is accessible"""
        import socket
        
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        result = sock.connect_ex(('localhost', 6379))
        sock.close()
        
        assert result == 0, "Redis port 6379 is not accessible"


class TestQdrant:
    """Test Qdrant connectivity and collections"""
    
    def test_qdrant_connection(self):
        """Test basic Qdrant connection"""
        try:
            response = httpx.get("http://localhost:6333", timeout=5)
            assert response.status_code == 200, f"Qdrant returned status {response.status_code}"
        except httpx.ConnectError as e:
            pytest.fail(f"Qdrant connection failed: {e}")
    
    def test_qdrant_docker_container(self):
        """Test Qdrant Docker container is running"""
        result = subprocess.run(
            ["docker", "ps", "--filter", "name=kernell-qdrant", "--format", "{{.Status}}"],
            capture_output=True,
            text=True
        )
        
        assert "Up" in result.stdout, "Qdrant container is not running"
    
    def test_qdrant_collections(self):
        """Test Qdrant collections exist"""
        try:
            response = httpx.get("http://localhost:6333/collections", timeout=5)
            assert response.status_code == 200
            
            collections = response.json()
            # Check if expected collections exist
            # Note: Collections may not exist yet, so we just verify the API works
            assert "result" in collections or "collections" in collections
        except Exception as e:
            pytest.skip(f"Qdrant collections check skipped: {e}")


class TestDocker:
    """Test Docker infrastructure"""
    
    def test_docker_daemon_running(self):
        """Test Docker daemon is running"""
        result = subprocess.run(
            ["docker", "info"],
            capture_output=True,
            text=True
        )
        
        assert result.returncode == 0, "Docker daemon is not running"
    
    def test_kernell_containers(self):
        """Test ANTIGRAVITY containers are running"""
        result = subprocess.run(
            ["docker", "ps", "--filter", "name=kernell", "--format", "{{.Names}}"],
            capture_output=True,
            text=True
        )
        
        containers = result.stdout.strip().split("\n")
        containers = [c for c in containers if c]  # Remove empty strings
        
        assert len(containers) >= 2, f"Expected at least 2 containers, found {len(containers)}"
        assert any("redis" in c for c in containers), "Redis container not found"
        assert any("qdrant" in c for c in containers), "Qdrant container not found"


class TestFileSystem:
    """Test file system structure"""
    
    def test_base_structure(self):
        """Test base directory structure exists"""
        base_path = Path(__file__).parent.parent
        
        required_dirs = [
            "agents",
            "core",
            "scripts",
            "data",
            ".agent"
        ]
        
        for dir_name in required_dirs:
            dir_path = base_path / dir_name
            assert dir_path.exists(), f"Required directory {dir_name} not found"
            assert dir_path.is_dir(), f"{dir_name} is not a directory"
    
    def test_core_files(self):
        """Test core configuration files exist"""
        base_path = Path(__file__).parent.parent
        
        required_files = [
            "core/core.md",
            "core/context_rules.md",
            "core/hardware_map.md",
            "core/software_map.md",
            "core/memory_map.md",
            "core/security_map.md"
        ]
        
        for file_path in required_files:
            full_path = base_path / file_path
            assert full_path.exists(), f"Required file {file_path} not found"
    
    def test_ramdisk_mount(self):
        """Test RAMDisk is mounted (optional)"""
        ramdisk_path = Path("/mnt/kernell_ram")
        
        if ramdisk_path.exists():
            # RAMDisk exists, check if it's a mount point
            result = subprocess.run(
                ["mountpoint", "-q", str(ramdisk_path)],
                capture_output=True
            )
            
            if result.returncode == 0:
                assert True, "RAMDisk is properly mounted"
            else:
                pytest.skip("RAMDisk directory exists but is not mounted")
        else:
            pytest.skip("RAMDisk not configured")


class TestVault:
    """Test Vault encryption system"""
    
    def test_vault_files_exist(self):
        """Test vault files exist"""
        base_path = Path(__file__).parent.parent
        
        vault_encrypted = base_path / "core/config/credentials.vault.encrypted.json"
        vault_key = base_path / "core/config/.vault_key"
        
        assert vault_encrypted.exists(), "Encrypted vault file not found"
        assert vault_key.exists(), "Vault key file not found"
    
    def test_vault_key_permissions(self):
        """Test vault key has correct permissions"""
        base_path = Path(__file__).parent.parent
        vault_key = base_path / "core/config/.vault_key"
        
        if vault_key.exists():
            import stat
            st = vault_key.stat()
            mode = st.st_mode
            
            # Check that only owner has read/write permissions (600)
            assert stat.S_IMODE(mode) == 0o600, f"Vault key has incorrect permissions: {oct(stat.S_IMODE(mode))}"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
