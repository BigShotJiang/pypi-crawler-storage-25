import sys
from pathlib import Path
import json
import time

# Add scratch to path
SCRATCH_ROOT = Path("/home/anny/Documentos/kernell/scratch")
sys.path.append(str(SCRATCH_ROOT))

# Import the refactored CarouselManager
from agents.atlas.carousel_manager import CarouselManager

def test_carousel_loop():
    print("🚀 Starting Atlas-Nexus Integration Test...")
    
    cm = CarouselManager()
    
    # 1. Request Key
    print("⏳ Requesting key for Gemini...")
    key = cm.get_next_key('gemini')
    
    if key:
        print(f"✅ Key received: {key[:5]}...{key[-3:]}")
        
        # 2. Report Usage
        print("📊 Reporting usage of 500 tokens...")
        cm.increment_usage('gemini', key, 'atlas', tokens=500)
        
        print("✅ Usage reported. Check Redis for: usage:key:gemini:* and usage:agent:atlas:tokens")
    else:
        print("❌ Failed to get key. Is Nexus running and Vault populated?")

if __name__ == "__main__":
    test_carousel_loop()
