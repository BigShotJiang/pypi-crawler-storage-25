#!/usr/bin/env python3
"""
KERNELL OS — Pipeline Layer Integration Tests
===============================================
Tests for: Pipeline State Machine, Engine, Mixin, Scheduler, Registry
Run: cd /home/anny/kernell-os && .venv/bin/python3 -m pytest tests/test_pipeline_layer.py -v
"""

import os
import sys
import json
import time
import pytest

sys.path.insert(0, "/home/anny/kernell-os")
os.environ.setdefault("PYTHONPATH", "/home/anny/kernell-os")

from dotenv import load_dotenv
load_dotenv("/home/anny/kernell-os/.env")


# ═══════════════════════════════════════════════════
# TEST: PIPELINE STATE MACHINE
# ═══════════════════════════════════════════════════

class TestPipelineState:
    """Tests for the PipelineInstance state machine."""

    def test_import(self):
        from agents.core.pipeline.pipeline_state import (
            PipelineInstance, PipelineStatus, StepStatus, StepResult
        )
        assert PipelineInstance is not None
        assert len(PipelineStatus) == 7
        assert len(StepStatus) == 6

    def test_create_instance(self):
        from agents.core.pipeline.pipeline_state import PipelineInstance, PipelineStatus
        pdef = {
            "id": "TEST01",
            "name": "Test Pipeline",
            "owner": "test",
            "sla_minutes": 5,
            "on_failure": "alert",
            "steps": [
                {"id": "S01", "name": "Step 1", "agent": "test", "required": True},
                {"id": "S02", "name": "Step 2", "agent": "test", "required": False},
            ],
        }
        inst = PipelineInstance(pipeline_id="TEST01", pipeline_def=pdef)
        assert inst.status == PipelineStatus.PENDING
        assert inst.pipeline_id == "TEST01"
        assert inst.sla_minutes == 5
        assert len(inst.steps_def) == 2

    def test_state_transitions(self):
        from agents.core.pipeline.pipeline_state import PipelineInstance, PipelineStatus
        pdef = {"id": "T", "name": "T", "steps": [{"id": "S01"}]}
        inst = PipelineInstance(pipeline_id="T", pipeline_def=pdef)

        assert inst.status == PipelineStatus.PENDING
        inst.start()
        assert inst.status == PipelineStatus.RUNNING
        inst.pause("test")
        assert inst.status == PipelineStatus.PAUSED
        inst.resume()
        assert inst.status == PipelineStatus.RUNNING
        inst.complete()
        assert inst.status == PipelineStatus.COMPLETED

    def test_step_tracking(self):
        from agents.core.pipeline.pipeline_state import (
            PipelineInstance, StepStatus
        )
        pdef = {
            "steps": [
                {"id": "S01", "required": True},
                {"id": "S02", "required": False},
            ]
        }
        inst = PipelineInstance(pipeline_id="T", pipeline_def=pdef)
        inst.start()

        inst.mark_step_active("S01")
        assert inst.steps_status["S01"] == StepStatus.ACTIVE

        inst.mark_step_done("S01", output={"result": "ok"}, duration_ms=100)
        assert inst.steps_status["S01"] == StepStatus.DONE
        assert "S01" in inst.accumulated_context

        inst.mark_step_skipped("S02", "optional")
        assert inst.steps_status["S02"] == StepStatus.SKIPPED

    def test_serialization_roundtrip(self):
        from agents.core.pipeline.pipeline_state import PipelineInstance, PipelineStatus
        pdef = {
            "steps": [{"id": "S01", "required": True}],
            "on_failure": "alert",
        }
        inst = PipelineInstance(pipeline_id="RT", pipeline_def=pdef)
        inst.start()
        inst.mark_step_done("S01", output={"x": 1})
        inst.complete()

        d = inst.to_dict()
        assert d["status"] == "completed"
        assert "hash" in d

        restored = PipelineInstance.from_dict(d, pdef)
        assert restored.instance_id == inst.instance_id
        assert restored.status == PipelineStatus.COMPLETED

    def test_sla_tracking(self):
        from agents.core.pipeline.pipeline_state import PipelineInstance
        pdef = {"steps": [], "sla_minutes": 10}
        inst = PipelineInstance(pipeline_id="SLA", pipeline_def=pdef)
        inst.start()
        assert inst.sla_pct_used() < 0.01  # Just created
        assert not inst.is_sla_exceeded()

    def test_hash_integrity(self):
        from agents.core.pipeline.pipeline_state import PipelineInstance
        pdef = {"steps": [{"id": "S01"}]}
        inst = PipelineInstance(pipeline_id="HASH", pipeline_def=pdef)
        h1 = inst.compute_hash()
        assert len(h1) == 64  # SHA-256
        h2 = inst.compute_hash()
        assert h1 == h2  # Deterministic


# ═══════════════════════════════════════════════════
# TEST: PIPELINE REGISTRY
# ═══════════════════════════════════════════════════

class TestPipelineRegistry:
    """Validate pipeline_registry.yaml structure."""

    @pytest.fixture(scope="class")
    def registry(self):
        import yaml
        with open("/home/anny/kernell-os/core/pipelines/pipeline_registry.yaml") as f:
            return yaml.safe_load(f)

    def test_has_14_pipelines(self, registry):
        assert len(registry["pipelines"]) == 14

    def test_all_pipelines_have_required_fields(self, registry):
        required = ["id", "name", "steps", "owner", "sla_minutes"]
        for key, pdef in registry["pipelines"].items():
            for field in required:
                assert field in pdef, f"{key} missing '{field}'"

    def test_all_steps_have_id_and_agent(self, registry):
        for key, pdef in registry["pipelines"].items():
            for step in pdef.get("steps", []):
                assert "id" in step, f"{key}: step missing 'id'"
                assert "agent" in step, f"{key}:{step.get('id','?')} missing 'agent'"

    def test_pipeline_ids_are_unique(self, registry):
        ids = [pdef["id"] for pdef in registry["pipelines"].values()]
        assert len(ids) == len(set(ids)), f"Duplicate IDs: {ids}"

    def test_step_ids_unique_within_pipeline(self, registry):
        for key, pdef in registry["pipelines"].items():
            step_ids = [s["id"] for s in pdef.get("steps", [])]
            assert len(step_ids) == len(set(step_ids)), f"{key} has duplicate step IDs"

    def test_total_steps_count(self, registry):
        total = sum(len(p.get("steps", [])) for p in registry["pipelines"].values())
        assert total >= 85, f"Expected ≥85 total steps, got {total}"


# ═══════════════════════════════════════════════════
# TEST: PIPELINE ENGINE (import + config)
# ═══════════════════════════════════════════════════

class TestPipelineEngine:
    """Tests for PipelineEngine configuration."""

    def test_import(self):
        from agents.core.pipeline import PipelineEngine
        assert PipelineEngine is not None

    def test_engine_init(self):
        from agents.core.pipeline import PipelineEngine

        class FakeRedis:
            pass

        engine = PipelineEngine(FakeRedis())
        assert engine._loaded is False
        assert engine._registry == {}

    def test_engine_list_pipelines_empty(self):
        from agents.core.pipeline import PipelineEngine

        class FakeRedis:
            pass

        engine = PipelineEngine(FakeRedis())
        assert engine.list_pipelines() == []


# ═══════════════════════════════════════════════════
# TEST: PIPELINE MIXIN
# ═══════════════════════════════════════════════════

class TestPipelineMixin:
    """Tests for PipelineMixin."""

    def test_import(self):
        from agents.core.pipeline import PipelineMixin, pipeline_step
        assert PipelineMixin is not None
        assert callable(pipeline_step)

    def test_mixin_has_required_methods(self):
        from agents.core.pipeline import PipelineMixin
        mixin = PipelineMixin()
        assert hasattr(mixin, "pipeline_step_done")
        assert hasattr(mixin, "pipeline_step_failed")
        assert hasattr(mixin, "pipeline_step_pause")
        assert hasattr(mixin, "get_pipeline_task_handler")
        assert hasattr(mixin, "_handle_pipeline_step")

    def test_decorator_returns_callable(self):
        from agents.core.pipeline import pipeline_step
        @pipeline_step("S01")
        async def dummy(self, task):
            return {"ok": True}
        assert callable(dummy)


# ═══════════════════════════════════════════════════
# TEST: PIPELINE SCHEDULER
# ═══════════════════════════════════════════════════

class TestPipelineScheduler:
    """Tests for Chronos PipelineScheduler."""

    def test_import(self):
        from agents.chronos.pipeline_scheduler import PipelineScheduler, PIPELINE_SCHEDULES
        assert PipelineScheduler is not None
        assert len(PIPELINE_SCHEDULES) == 6

    def test_schedules_have_required_fields(self):
        from agents.chronos.pipeline_scheduler import PIPELINE_SCHEDULES
        for sched in PIPELINE_SCHEDULES:
            assert "pipeline_id" in sched
            assert "name" in sched
            assert "hour" in sched
            assert "minute" in sched
            assert 0 <= sched["hour"] <= 23
            assert 0 <= sched["minute"] <= 59


# ═══════════════════════════════════════════════════
# TEST: PIPELINE MONITOR
# ═══════════════════════════════════════════════════

class TestPipelineMonitor:
    """Tests for Sierra PipelineMonitor."""

    def test_import(self):
        from agents.sierra.pipeline_monitor import PipelineMonitor
        assert PipelineMonitor is not None

    def test_monitor_has_run_method(self):
        from agents.sierra.pipeline_monitor import PipelineMonitor
        assert hasattr(PipelineMonitor, "run")
        assert hasattr(PipelineMonitor, "stop")
        assert hasattr(PipelineMonitor, "get_dashboard_data")


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
