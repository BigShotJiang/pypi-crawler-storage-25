from agents.nemesis.prediction_adapter import PredictionPaperAdapter


def test_budget_trade_cap_blocks_oversized_stake():
    adapter = PredictionPaperAdapter()
    signal = {"stake_usd": 80.0}
    ok, reason = adapter.risk_check(
        signal,
        market_exposure=0.0,
        total_exposure=0.0,
        daily_pnl=0.0,
        nemesis_budget_usd=100.0,
    )
    assert ok is False
    assert reason == "budget_trade_cap"


def test_budget_total_cap_blocks_cumulative_exposure():
    adapter = PredictionPaperAdapter()
    signal = {"stake_usd": 20.0}
    ok, reason = adapter.risk_check(
        signal,
        market_exposure=0.0,
        total_exposure=160.0,
        daily_pnl=0.0,
        nemesis_budget_usd=200.0,
    )
    assert ok is False
    assert reason == "budget_total_cap"


def test_budget_guardrail_allows_small_trade():
    adapter = PredictionPaperAdapter()
    signal = {"stake_usd": 10.0}
    ok, reason = adapter.risk_check(
        signal,
        market_exposure=5.0,
        total_exposure=10.0,
        daily_pnl=0.0,
        nemesis_budget_usd=200.0,
    )
    assert ok is True
    assert reason == "ok"
