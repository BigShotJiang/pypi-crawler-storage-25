import unittest
from agents.finance.economy.cap_committee import CAPCommittee

class MockRedis:
    def __init__(self):
        self.data = {}
        self.lists = {}
        
    def get(self, key):
        return self.data.get(key)
        
    def set(self, key, val):
        self.data[key] = val
        
    def lpush(self, key, val):
        if key not in self.lists:
            self.lists[key] = []
        self.lists[key].insert(0, val)
        
    def ltrim(self, key, start, stop):
        if key in self.lists:
            self.lists[key] = self.lists[key][start:stop+1]

class TestCAPCommittee(unittest.TestCase):
    
    def setUp(self):
        self.cap = CAPCommittee(redis_client=MockRedis())
        
    def test_stable_environment(self):
        """Should not change prices when everything is perfectly stable."""
        metrics = {
             "demand": 0.5, "congestion": 0.3, "cost_pressure": 0.4,
             "stability": 0.95, "supply_ratio": 0.8, "anomalies": 0
        }
        self.cap._fetch_system_metrics = lambda: metrics
        result = self.cap.execute_committee_cycle()
        
        self.assertEqual(result["price_chamber"]["adjustment"], 0.0)
        self.assertEqual(result["burn_chamber"]["adjustment"], 0.0)
        self.assertEqual(result["mode"], "stable")
        
    def test_extreme_demand_expansion(self):
        """Should attempt to increase burn modestly and increase price safely."""
        metrics = {
             "demand": 0.9, "congestion": 0.4, "cost_pressure": 0.5,
             "stability": 0.90, "supply_ratio": 0.7, "anomalies": 0
        }
        self.cap._fetch_system_metrics = lambda: metrics
        result = self.cap.execute_committee_cycle()
        
        self.assertGreater(result["price_chamber"]["adjustment"], 0.0)
        self.assertLessEqual(result["price_chamber"]["adjustment"], self.cap.MAX_DAILY_PRICE_VARIATION)
        self.assertEqual(result["mode"], "expansion")
        
    def test_system_compromise_veto(self):
        """Should freeze and defend when anomalies are too high, regardless of other metrics."""
        metrics = {
             "demand": 0.9, "congestion": 0.9, "cost_pressure": 0.9,
             "stability": 0.4, "supply_ratio": 0.9, "anomalies": 5
        }
        self.cap._fetch_system_metrics = lambda: metrics
        result = self.cap.execute_committee_cycle()
        
        self.assertTrue(result["veto_active"])
        self.assertEqual(result["mode"], "protection")
        self.assertEqual(result["price_chamber"]["adjustment"], self.cap.MAX_DAILY_PRICE_VARIATION)
        self.assertLess(result["burn_chamber"]["adjustment"], 0.0) # Lower burn, conserve tokens

if __name__ == "__main__":
    unittest.main()
