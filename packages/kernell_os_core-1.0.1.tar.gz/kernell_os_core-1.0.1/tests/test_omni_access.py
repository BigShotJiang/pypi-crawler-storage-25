#!/usr/bin/env python3
"""
🧪 OMNI-ACCESS VERIFICATION TEST
=================================
Verifies that Atlas connects to ALL subsystems of Kernell OS.
Tests: Redis, Qdrant, Snapshot Compilation, Context Router, Security, Economy, Timeline.

Phase 1 Roadmap Item: "Prove Atlas connects everything."
"""

import sys
import os
import json
import time

# Setup path
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from agents.core.config import get_redis_client

# ─── Test Results ───
RESULTS = []

def test(name, check_fn):
    """Run a test and record result."""
    try:
        ok, detail = check_fn()
        status = "✅ PASS" if ok else "⚠️  WARN"
        RESULTS.append((name, ok, detail))
        print(f"  {status} │ {name}: {detail}")
        return ok
    except Exception as e:
        RESULTS.append((name, False, str(e)))
        print(f"  ❌ FAIL │ {name}: {e}")
        return False


def main():
    print("=" * 64)
    print("🧪 OMNI-ACCESS VERIFICATION — Atlas Connectivity Test")
    print("=" * 64)
    
    r = get_redis_client()
    
    # ─── 1. Redis Connectivity ───
    print("\n📡 1. REDIS CONNECTIVITY")
    test("Redis PING", lambda: (r.ping(), "Connected"))
    
    # ─── 2. Agent Heartbeats ───
    print("\n💓 2. AGENT HEARTBEATS")
    CANONICAL = [
        "kernell", "atlas", "chronos", "sentinel", "forge", "nexus",
        "interface", "sierra", "overseer", "hunter", "archivista",
        "scribe", "fixer", "economy", "telegram_bridge"
    ]
    alive = 0
    for agent in CANONICAL:
        hb = r.get(f"kernell:agent:{agent}:heartbeat")
        if hb:
            alive += 1
    test("Agent Heartbeats", lambda: (alive >= 10, f"{alive}/{len(CANONICAL)} agents alive"))
    
    # ─── 3. Snapshot Compilation ───
    print("\n📸 3. SNAPSHOT COMPILATION (Atlas Core)")
    from agents.atlas.snapshot_compiler import SnapshotCompiler
    compiler = SnapshotCompiler(redis_client=r)
    snapshot = compiler.compile()
    snap_dict = snapshot.model_dump()
    
    test("Snapshot compiles", lambda: (snapshot is not None, f"Cycle {snapshot.cycle_id}"))
    test("Checksum present", lambda: (len(snapshot.checksum) == 64, f"{snapshot.checksum[:16]}..."))
    test("Mode valid", lambda: (snapshot.mode in ["STABLE", "TENSION", "STRESS", "CRITICAL"], snapshot.mode))
    test("Drift in range", lambda: (0 <= snap_dict['drift_index'] <= 100, f"{snap_dict['drift_index']:.1f}"))
    test("Confidence in range", lambda: (0 <= snapshot.confidence_score <= 100, f"{snapshot.confidence_score:.1f}"))
    test("Agents populated", lambda: (len(snapshot.agents) > 0, f"{len(snapshot.agents)} agents in snapshot"))
    
    # ─── 4. Security State ───
    print("\n🛡️ 4. SECURITY STATE (Sentinel → Atlas)")
    test("DEFCON readable", lambda: (
        snap_dict['security']['defcon'] in range(1, 6),
        f"DEFCON {snap_dict['security']['defcon']}"
    ))
    test("Threat level readable", lambda: (
        0.0 <= snap_dict['security']['threat_level'] <= 1.0,
        f"Threat: {snap_dict['security']['threat_level']}"
    ))
    
    # ─── 5. Economy State ───
    print("\n💰 5. ECONOMY STATE (Economy → Atlas)")
    eco = snap_dict.get('economy', {})
    test("Economy data present", lambda: (
        eco is not None,
        f"ROI: {eco.get('roi_index', 'N/A')}, Budget: {eco.get('budget_status', 'N/A')}"
    ))
    
    # ─── 6. Timeline ───
    print("\n⏱️ 6. TIMELINE (Chronos → Atlas)")
    timeline = snap_dict.get('timeline', {})
    test("Timeline accessible", lambda: (timeline is not None, f"{len(timeline.get('scheduled_events', []))} scheduled, {len(timeline.get('critical_events', []))} critical"))
    
    # ─── 7. Memory Index ───
    print("\n🧠 7. MEMORY INDEX (Overseer/Qdrant → Atlas)")
    mem = snap_dict.get('memory_index', {})
    test("Memory index linked", lambda: (mem is not None, f"{mem.get('semantic_vectors', 0)} vectors, {mem.get('episodic_entries', 0)} episodes"))
    
    # ─── 8. System Metrics ───
    print("\n⚙️ 8. SYSTEM METRICS (Host → Atlas)")
    sys_m = snap_dict.get('system', {})
    test("CPU readable", lambda: (0 <= sys_m.get('cpu', -1) <= 100, f"{sys_m.get('cpu', 0):.1f}%"))
    test("Memory readable", lambda: (0 <= sys_m.get('memory', -1) <= 100, f"{sys_m.get('memory', 0):.1f}%"))
    test("Disk readable", lambda: (0 <= sys_m.get('disk', -1) <= 100, f"{sys_m.get('disk', 0):.1f}%"))
    test("Uptime readable", lambda: (sys_m.get('uptime', 0) > 0, f"{sys_m.get('uptime', 0)/3600:.1f}h"))
    
    # ─── 9. Qdrant Direct ───
    print("\n🔮 9. QDRANT VECTOR DATABASE")
    try:
        from qdrant_client import QdrantClient
        q = QdrantClient(host="localhost", port=6333, timeout=5)
        cols = q.get_collections()
        test("Qdrant reachable", lambda: (True, f"{len(cols.collections)} collections"))
        for c in cols.collections:
            info = q.get_collection(c.name)
            test(f"Collection: {c.name}", lambda n=c.name, i=info: (True, f"{i.points_count} vectors"))
    except Exception as e:
        test("Qdrant reachable", lambda: (False, str(e)))
    
    # ─── 10. Redis Published State ───
    print("\n📤 10. REDIS PUBLISHED STATE (Atlas → Ecosystem)")
    pub_keys = {
        "kernell:reality:hash": "Reality Checksum",
        "kernell:system:boot_status": "Boot Status",
        "kernell:system:health_score": "Health Score",
        "kernell:gshi:v2:current": "GSHI Payload",
    }
    for key, label in pub_keys.items():
        val = r.get(key)
        test(label, lambda v=val, l=label: (v is not None, f"{v[:40]}..." if v and len(v) > 40 else str(v)))
    
    # ─── 11. Cognitive Metrics ───
    print("\n🧮 11. COGNITIVE METRICS ENGINE")
    from agents.atlas.cognitive_metrics import CognitiveMetrics
    cm = CognitiveMetrics()
    test("CognitiveMetrics instantiates", lambda: (cm is not None, "OK"))
    
    # ─── 12. Context Router ───
    print("\n🔀 12. CONTEXT ROUTER")
    from agents.atlas.context_router import ContextRouter
    cr = ContextRouter(redis_client=r)
    test("ContextRouter instantiates", lambda: (cr is not None, "OK"))
    
    # ─── 13. Projection Engine ───
    print("\n🔭 13. PROJECTION ENGINE")
    from agents.atlas.projection_engine import ProjectionEngine
    pe = ProjectionEngine()
    projection = pe.project_state(snap_dict)
    test("Projection computes", lambda: (projection is not None, f"Keys: {list(projection.keys()) if isinstance(projection, dict) else type(projection).__name__}"))
    
    # ─── 14. Bias Monitor ───
    print("\n⚖️ 14. BIAS RISK INDEX (BRI)")
    from agents.atlas.bias_monitor import BiasMonitor
    bm = BiasMonitor()
    bri = bm.evaluate(snap_dict)
    test("BRI computes", lambda: (0 <= bri <= 100, f"BRI: {bri:.1f}"))
    
    # ─── FINAL REPORT ───
    print("\n" + "=" * 64)
    passed = sum(1 for _, ok, _ in RESULTS if ok)
    total = len(RESULTS)
    warns = sum(1 for _, ok, _ in RESULTS if not ok)
    
    if warns == 0:
        verdict = "✅ OMNI-ACCESS VERIFIED — Atlas connects everything"
    elif warns <= 3:
        verdict = "⚠️  PARTIAL — Atlas has minor connectivity gaps"
    else:
        verdict = "❌ FAILED — Atlas has significant connectivity issues"
    
    print(f"  {verdict}")
    print(f"  Results: {passed}/{total} passed, {warns} warnings")
    print("=" * 64)
    
    return warns == 0


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
