#!/usr/bin/env python3
"""
Agent Tests for ANTIGRAVITY
Tests agent functionality, heartbeats, and inter-agent communication
"""

import pytest
import redis
import subprocess
import json
import sys
from pathlib import Path
from datetime import datetime
sys.path.insert(0, str(Path(__file__).parent.parent))
from agents.core.config import get_redis_client


class TestAgentStructure:
    """Test agent directory structure and configuration"""
    
    @pytest.fixture
    def base_path(self):
        return Path(__file__).parent.parent
    
    @pytest.fixture
    def expected_agents(self):
        return [
            "kernel", "atlas", "chronos", "sentinel", "forge",
            "harlemm", "hunter", "telefonica", "kali", "archivista",
            "telegram_bridge", "present", "alterego", "spectre",
            "cash", "steward", "interface", "nexus"
        ]
    
    def test_agent_directories_exist(self, base_path, expected_agents):
        """Test all agent directories exist"""
        agents_dir = base_path / "agents"
        
        for agent_name in expected_agents:
            agent_path = agents_dir / agent_name
            assert agent_path.exists(), f"Agent directory {agent_name} not found"
            assert agent_path.is_dir(), f"{agent_name} is not a directory"
    
    def test_agent_readmes(self, base_path, expected_agents):
        """Test agents have README.md files"""
        agents_dir = base_path / "agents"
        missing_readmes = []
        
        for agent_name in expected_agents:
            readme_path = agents_dir / agent_name / "README.md"
            if not readme_path.exists():
                missing_readmes.append(agent_name)
        
        # Allow some agents to not have READMEs (legacy or in development)
        assert len(missing_readmes) < 5, f"Too many agents missing READMEs: {missing_readmes}"


class TestSystemdServices:
    """Test systemd service status"""
    
    def test_kernell_target_active(self):
        """Test kernell.target is active"""
        result = subprocess.run(
            ["systemctl", "--user", "is-active", "kernell.target"],
            capture_output=True,
            text=True
        )
        
        assert result.returncode == 0, "kernell.target is not active"
    
    def test_swarm_agents_running(self):
        """Test swarm agents are running"""
        result = subprocess.run(
            ["systemctl", "--user", "list-units", "kernell-swarm@*", "--no-pager"],
            capture_output=True,
            text=True
        )
        
        # Count active swarm agents
        active_count = result.stdout.count("active")
        assert active_count > 0, "No swarm agents are running"
    
    def test_dashboard_running(self):
        """Test dashboard service is running"""
        result = subprocess.run(
            ["systemctl", "--user", "is-active", "kernell-dashboard.service"],
            capture_output=True,
            text=True
        )
        
        # Dashboard should be running
        is_active = result.returncode == 0
        if not is_active:
            pytest.skip("Dashboard service is not active")


class TestNEXUS:
    """Test NEXUS (Keymaster) functionality"""
    
    def test_nexus_service_running(self):
        """Test NEXUS service is running"""
        result = subprocess.run(
            ["systemctl", "--user", "is-active", "kernell-swarm@nexus.service"],
            capture_output=True,
            text=True
        )
        
        assert result.returncode == 0, "NEXUS service is not running"
    
    def test_nexus_config_exists(self):
        """Test NEXUS configuration exists"""
        base_path = Path(__file__).parent.parent
        config_path = base_path / "agents/nexus/config.json"
        
        assert config_path.exists(), "NEXUS config.json not found"
        
        # Validate JSON
        with open(config_path) as f:
            config = json.load(f)
            assert "agent_name" in config or "name" in config


class TestATLAS:
    """Test ATLAS (Context Orchestrator) functionality"""
    
    def test_atlas_bootstrap_script_exists(self):
        """Test ATLAS bootstrap script exists"""
        base_path = Path(__file__).parent.parent
        bootstrap_path = base_path / "agents/atlas/bootstrap.py"
        
        assert bootstrap_path.exists(), "ATLAS bootstrap.py not found"
    
    def test_atlas_config_exists(self):
        """Test ATLAS configuration exists"""
        base_path = Path(__file__).parent.parent
        config_path = base_path / "agents/atlas/config.json"
        
        assert config_path.exists(), "ATLAS config.json not found"
        
        # Validate JSON
        with open(config_path) as f:
            config = json.load(f)
            assert "context_files" in config or "agent_name" in config
    
    def test_atlas_can_import(self):
        """Test ATLAS modules can be imported"""
        try:
            from agents.atlas.carousel_manager import CarouselManager
            from agents.atlas.context_builder import ContextBuilder
            assert True
        except ImportError as e:
            pytest.fail(f"Failed to import ATLAS modules: {e}")


class TestCHRONOS:
    """Test CHRONOS (Scheduler) functionality"""
    
    def test_chronos_service_running(self):
        """Test CHRONOS service is running"""
        result = subprocess.run(
            ["systemctl", "--user", "is-active", "kernell-swarm@chronos.service"],
            capture_output=True,
            text=True
        )
        
        # CHRONOS should be running
        is_active = result.returncode == 0
        if not is_active:
            pytest.skip("CHRONOS service is not active")


class TestRedisQueues:
    """Test Redis queue operations"""
    
    @pytest.fixture
    def redis_client(self):
        """Create authenticated Redis client"""
        try:
            r = get_redis_client()
            r.ping()
            return r
        except redis.exceptions.ConnectionError:
            pytest.skip("Redis is not accessible")
    
    def test_redis_key_pattern(self, redis_client):
        """Test Redis keys follow ANTIGRAVITY pattern"""
        keys = redis_client.keys("kernell:*")
        
        # We expect some kernell keys to exist
        # This is a soft check - system may be freshly initialized
        if len(keys) == 0:
            pytest.skip("No kernell keys found (system may be fresh)")
        
        # Verify key naming convention
        for key in keys[:10]:  # Check first 10 keys
            assert key.startswith("kernell:"), f"Key {key} doesn't follow naming convention"


class TestDashboard:
    """Test Dashboard accessibility"""
    
    def test_dashboard_port_accessible(self):
        """Test Dashboard port 8501 is accessible"""
        import socket
        
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        result = sock.connect_ex(('localhost', 8501))
        sock.close()
        
        if result != 0:
            pytest.skip("Dashboard port 8501 is not accessible")
    
    def test_dashboard_http_response(self):
        """Test Dashboard responds to HTTP requests"""
        try:
            import httpx
            response = httpx.get("http://localhost:8501", timeout=5, follow_redirects=True)
            assert response.status_code == 200, f"Dashboard returned status {response.status_code}"
        except Exception as e:
            pytest.skip(f"Dashboard HTTP check failed: {e}")


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
