import sys
from pathlib import Path
sys.path.append(str(Path(__file__).parent.parent))

from agents.common.task_memory import TaskMemory
from agents.atlas.agent_context_manager import AgentContextManager

def test_dtm():
    print("--- 🧪 DTM Integration Test ---")
    tm = TaskMemory("TEST_AGENT")
    tm.push_work_item("task_123", "Verificar Power Demo en Pop 7", {"ip": "100.88.123.18"})
    print("✅ Task pushed to Redis")
    
    mgr = AgentContextManager(Path(__file__).parent.parent)
    context = mgr.create_initial_context("test_verify", {"model": "gpt-4o"})
    summary = mgr._create_context_summary(context)
    
    print("\n--- 📝 Generated Context Summary ---")
    print(summary)
    
    if "Verificar Power Demo" in summary:
        print("\n🎉 SUCCESS: DTM Task found in context summary!")
    else:
        print("\n❌ FAILURE: DTM Task not found.")

if __name__ == "__main__":
    test_dtm()
