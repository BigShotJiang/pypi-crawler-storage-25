"""
KERNELL OS — SIERRA (Verifier) Agent Tests
=============================================
Tests for infrastructure checking, agent health monitoring,
pipeline SLA verification, and SAGE proposal review.
"""
import sys
import json
import time
import pytest
from unittest.mock import MagicMock, patch
from pathlib import Path

ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT))


class FakeBytes(str):
    def decode(self, *args, **kwargs): return str(self)


class MockRedis:
    def __init__(self): self.store, self._published = {}, []
    def get(self, key):
        v = self.store.get(key)
        return FakeBytes(v) if v is not None else None
    def set(self, key, value, **kwargs): self.store[key] = str(value)
    def hset(self, key, field=None, value=None, mapping=None, **kwargs):
        if key not in self.store: self.store[key] = {}
        if field is not None and value is not None: self.store[key][str(field)] = str(value)
        if mapping: self.store[key].update({str(k): str(v) for k, v in mapping.items()})
    def hgetall(self, key): return self.store.get(key, {})
    def hget(self, key, field): return self.store.get(key, {}).get(field)
    def keys(self, pattern="*"): return [k for k in self.store if pattern.replace("*","") in k]
    def rpush(self, key, *vals):
        if key not in self.store: self.store[key] = []
        self.store[key].extend(vals)
    def lpush(self, key, *vals):
        if key not in self.store: self.store[key] = []
        for v in vals: self.store[key].insert(0, v)
    def lrange(self, key, start, end): return self.store.get(key, [])[start:end+1] if end >= 0 else self.store.get(key, [])
    def publish(self, ch, msg): self._published.append((ch, msg))
    def incr(self, key): self.store[key] = str(int(self.store.get(key, "0")) + 1)
    def setex(self, key, ttl, val): self.store[key] = str(val)
    def exists(self, key): return 1 if key in self.store else 0
    def xadd(self, stream, fields, **kw): pass
    def ping(self): return True


def _sierra_agent():
    """Create a VerifierAgent with mocked internals."""
    from agents.sierra.agent import VerifierAgent
    with patch.object(VerifierAgent, '__init__', lambda self: None):
        agent = VerifierAgent()
        agent.redis = MockRedis()
        agent.logger = MagicMock()
        agent.agent_name = "sierra"
        agent.root_path = ROOT
        agent.system_config = {"agents": {
            "atlas": {}, "chronos": {}, "sentinel": {}, "economy": {}
        }}
        agent._async_redis = None
        agent._pipeline_engine = None
        return agent


class TestInfrastructureCheck:
    """Tests for SIERRA infrastructure monitoring."""

    def test_agent_heartbeat_detection(self):
        agent = _sierra_agent()
        agents_list = ["atlas", "chronos", "sentinel", "economy"]
        for a in agents_list:
            agent.redis.set(f"kernell:agent:{a}:heartbeat", json.dumps({
                "agent": a, "ts": time.time(), "status": "running"
            }))
        health = agent.get_agent_health()
        assert isinstance(health, dict)

    def test_defcon_escalation(self):
        agent = _sierra_agent()
        agent._request_defcon_escalation(3, "Critical vulnerability detected")
        # Should have pushed to defcon request queue
        assert "kernell:sierra:defcon_request" in agent.redis.store
        data = json.loads(agent.redis.store["kernell:sierra:defcon_request"][0])
        assert data["requested_level"] == 3

    def test_documentation_check_returns_tuple(self):
        """check_documentation returns (bool, str) tuple."""
        agent = _sierra_agent()
        result = agent.check_documentation("atlas")
        assert isinstance(result, tuple)
        assert len(result) == 2

    def test_infrastructure_check(self):
        agent = _sierra_agent()
        result = agent.check_infrastructure()
        assert isinstance(result, dict)
        assert "redis" in result


class TestPipelineMonitoring:
    """Tests for SIERRA pipeline SLA monitoring."""

    def test_pipeline_trigger_handling(self):
        agent = _sierra_agent()
        task = {
            "type": "pipeline_trigger",
            "pipeline_id": "P04",
            "reason": "scheduled_security_scan"
        }
        agent._handle_pipeline_trigger(task)
        assert agent.logger.info.called or agent.logger.warning.called

    def test_pipeline_rollback(self):
        agent = _sierra_agent()
        task = {
            "type": "pipeline_rollback",
            "pipeline_id": "P02",
            "reason": "SLA_breach"
        }
        agent._handle_pipeline_rollback(task)


class TestSageProposalReview:
    """Tests for SIERRA reviewing SAGE evolution proposals."""

    def test_handle_evolution_proposal_safe(self):
        agent = _sierra_agent()
        task = {
            "type": "evolution_proposal",
            "proposal_id": "test-001",
            "file_path": "/tmp/test_proposal.py",
            "change_type": "config_update",
            "risk_level": "low",
            "description": "Update logging format"
        }
        agent._handle_evolution_proposal(task)

    def test_handle_rollback(self):
        agent = _sierra_agent()
        task = {
            "type": "rollback",
            "proposal_id": "test-001",
            "reason": "Performance degradation"
        }
        agent._handle_rollback_request(task)


class TestHygieneEngine:
    """Tests for SIERRA's file integrity and garbage collection."""

    def test_hygiene_engine_init(self):
        from agents.sierra.hygiene_engine import HygieneEngine
        engine = HygieneEngine(redis_client=MockRedis())
        assert engine is not None

    def test_integrity_check(self):
        from agents.sierra.hygiene_engine import HygieneEngine
        engine = HygieneEngine(redis_client=MockRedis())
        result = engine.check_integrity()
        assert isinstance(result, dict)

    def test_garbage_collection(self):
        from agents.sierra.hygiene_engine import HygieneEngine
        engine = HygieneEngine(redis_client=MockRedis())
        result = engine.collect_garbage()
        assert isinstance(result, dict)
