"""
KERNELL OS — Sentinel ↔ Sierra Protocol Integration Tests
===========================================================
Tests the v13.0 coordination protocol:
  1. Sierra DEFCON requests go through Sentinel (not direct writes)
  2. Sentinel internal alerts are consumed by Sierra and dispatched to Fixer
  3. DefconRulesEngine uses the request channel, not direct DEFCON writes
"""

import json
import time
import sys
import os
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

# Add project root
PROJECT_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(PROJECT_ROOT))


# ── Fixtures ──────────────────────────────────────────────────

class FakeRedis:
    """Minimal Redis mock for protocol testing."""
    
    def __init__(self):
        self._store = {}
        self._lists = {}
        self._hashes = {}
    
    def get(self, key):
        return self._store.get(key)
    
    def set(self, key, value, ex=None):
        self._store[key] = value
    
    def setex(self, key, ttl, value):
        self._store[key] = value
    
    def lpush(self, key, value):
        self._lists.setdefault(key, []).insert(0, value)
        return len(self._lists[key])
    
    def rpush(self, key, value):
        self._lists.setdefault(key, []).append(value)
        return len(self._lists[key])
    
    def rpop(self, key):
        lst = self._lists.get(key, [])
        return lst.pop() if lst else None
    
    def lrange(self, key, start, end):
        lst = self._lists.get(key, [])
        return lst[start:end + 1] if end >= 0 else lst[start:]
    
    def ltrim(self, key, start, end):
        lst = self._lists.get(key, [])
        self._lists[key] = lst[start:end + 1] if end >= 0 else lst[start:]
    
    def hset(self, key, field, value):
        self._hashes.setdefault(key, {})[field] = value
    
    def hget(self, key, field):
        return self._hashes.get(key, {}).get(field)
    
    def hgetall(self, key):
        return self._hashes.get(key, {})
    
    def hdel(self, key, field):
        self._hashes.get(key, {}).pop(field, None)
    
    def delete(self, key):
        self._store.pop(key, None)
        self._lists.pop(key, None)
    
    def ping(self):
        return True
    
    def pubsub(self):
        return MagicMock()
    
    def publish(self, channel, message):
        pass
    
    def smembers(self, key):
        return set()


@pytest.fixture
def redis():
    return FakeRedis()


# ── Test 1: Sierra DEFCON Request Protocol ────────────────────

def test_sierra_requests_defcon_via_channel(redis):
    """Sierra must request DEFCON changes via kernell:sierra:defcon_request,
    never writing to kernell:system:defcon directly."""
    from agents.sierra.agent import VerifierAgent
    
    # Create a minimal Sierra instance with mocked internals
    with patch.object(VerifierAgent, '__init__', lambda self: None):
        sierra = VerifierAgent()
        sierra.redis = redis
        sierra.logger = MagicMock()
        sierra.agent_name = "sierra"
    
    # Set initial DEFCON
    redis.set("kernell:system:defcon", "4")
    
    # Sierra requests escalation
    sierra._request_defcon_escalation(2, "Test: Multiple agents dead")
    
    # Verify: Request was published to the channel
    req_raw = redis.rpop("kernell:sierra:defcon_request")
    assert req_raw is not None, "Sierra should publish to kernell:sierra:defcon_request"
    
    req = json.loads(req_raw)
    assert req["requested_level"] == 2
    assert "Multiple agents dead" in req["reason"]
    
    # Verify: Sierra did NOT write to DEFCON directly
    assert redis.get("kernell:system:defcon") == "4", \
        "Sierra must NOT write to kernell:system:defcon directly"


# ── Test 2: Sentinel Evaluates DEFCON Requests ────────────────

def test_sentinel_evaluates_defcon_request(redis):
    """Sentinel should consume DEFCON requests from Sierra and write decisions."""
    from agents.sentinel.sentinel_agent import SentinelAgent
    
    with patch.object(SentinelAgent, '__init__', lambda self: None):
        sentinel = SentinelAgent()
        sentinel.redis = redis
        sentinel.logger = MagicMock()
        sentinel.agent_name = "sentinel"
        sentinel.threat_analyzer = MagicMock()
    
    # Set current DEFCON high (peaceful)
    redis.set("kernell:system:defcon", "5")
    
    # Simulate Sierra request
    redis.lpush("kernell:sierra:defcon_request", json.dumps({
        "requested_level": 3,
        "reason": "Agent nemesis offline for 5 minutes",
        "timestamp": time.time()
    }))
    
    # Sentinel processes
    sentinel._process_sierra_coordination()
    
    # Verify: Sentinel logged a decision
    decision_raw = redis.rpop("kernell:sentinel:defcon_decisions")
    assert decision_raw is not None, "Sentinel should publish decision to kernell:sentinel:defcon_decisions"
    
    decision = json.loads(decision_raw)
    assert decision["decision"] in ("APPROVED", "REJECTED")
    assert "request" in decision


# ── Test 3: Sentinel Internal Alert → Sierra → Fixer ─────────

def test_sentinel_alert_to_sierra_to_fixer(redis):
    """Sentinel publishes internal alert, Sierra verifies and dispatches to Fixer."""
    from agents.sierra.agent import VerifierAgent
    
    with patch.object(VerifierAgent, '__init__', lambda self: None):
        sierra = VerifierAgent()
        sierra.redis = redis
        sierra.logger = MagicMock()
        sierra.agent_name = "sierra"
    
    # Simulate Sentinel alert
    redis.lpush("kernell:sentinel:internal_alert", json.dumps({
        "issue": "File agents/nexus/core.py modified without authorization",
        "severity": "HIGH",
        "action_recommended": "rollback",
        "timestamp": time.time()
    }))
    
    # Sierra processes
    sierra._process_sentinel_alerts()
    
    # Verify: Sierra dispatched to Fixer
    fixer_task_raw = redis.rpop("kernell:tasks:fixer")
    assert fixer_task_raw is not None, "Sierra should dispatch verified alerts to Fixer"
    
    fixer_task = json.loads(fixer_task_raw)
    assert fixer_task["source"] == "sierra_verified_sentinel_alert"
    assert "modified without authorization" in fixer_task["reason"]


# ── Test 4: Sentinel Does NOT Write to Fixer Directly ─────────

def test_sentinel_never_writes_to_fixer():
    """Verify that sentinel_agent.py does not contain any write to kernell:tasks:fixer."""
    sentinel_path = PROJECT_ROOT / "agents" / "sentinel" / "sentinel_agent.py"
    content = sentinel_path.read_text()
    
    assert "kernell:tasks:fixer" not in content, \
        "Sentinel must NEVER write to kernell:tasks:fixer — only Sierra dispatches to Fixer"


# ── Test 5: Sierra Does NOT Write DEFCON Directly ─────────────

def test_sierra_never_writes_defcon_directly():
    """Verify that sierra/agent.py does not directly set kernell:system:defcon."""
    sierra_path = PROJECT_ROOT / "agents" / "sierra" / "agent.py"
    content = sierra_path.read_text()
    
    # Sierra should not SET defcon directly. It reads it but only writes via request channel.
    lines = content.split('\n')
    for i, line in enumerate(lines):
        if 'kernell:system:defcon' in line:
            # Only reads are OK (e.g. redis.get("kernell:system:defcon"))
            assert '.get(' in line or 'GET' in line.upper() or '#' in line.split('kernell:system:defcon')[0], \
                f"Sierra agent.py line {i+1} may be writing to DEFCON directly: {line.strip()}"


# ── Test 6: DefconRulesEngine Uses Request Channel ────────────

def test_defcon_rules_engine_uses_request_channel():
    """Verify that defcon_rules.py does not write directly to kernell:system:defcon
    in the _set_defcon method (should use request channel instead)."""
    rules_path = PROJECT_ROOT / "agents" / "sierra" / "defcon_rules.py"
    content = rules_path.read_text()
    
    # Find the _set_defcon method body
    in_method = False
    method_lines = []
    for line in content.split('\n'):
        if 'async def _set_defcon' in line:
            in_method = True
        elif in_method and (line.strip().startswith('async def ') or line.strip().startswith('def ')):
            break
        elif in_method:
            method_lines.append(line)
    
    method_body = '\n'.join(method_lines)
    
    # Should use request channel
    assert 'kernell:sierra:defcon_request' in method_body, \
        "_set_defcon should use kernell:sierra:defcon_request channel"
    
    # Should NOT directly write to DEFCON key
    assert 'await r.set(DEFCON_KEY' not in method_body, \
        "_set_defcon should NOT write directly to kernell:system:defcon"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
