import unittest
import json
import time
from unittest.mock import patch, MagicMock
from agents.finance.economy.ads.organic_engine import OrganicTrafficManager

class TestOrganicEngine(unittest.TestCase):
    
    def setUp(self):
        self.mock_redis = MagicMock()
        self.engine = OrganicTrafficManager(redis_client=self.mock_redis)

    def test_node_discovery(self):
        """Test that the engine properly filters for active Android nodes"""
        base_time = time.time()
        
        # Mock Registry Data
        mock_registry = {
            "node_1": json.dumps({"os": "android", "ip_tailscale": "100.1.1.1", "hostname": "TestNode"}),
            "node_2": json.dumps({"os": "windows", "ip_tailscale": "100.2.2.2"}), # Windows, should be ignored
            "node_3": json.dumps({"os": "android"}) # Missing IP, should be ignored
        }
        self.mock_redis.hgetall.return_value = mock_registry
        
        # Mock Telemetry (node_1 is active, others irrelevant)
        def mock_hget(key, field):
            if key == "kernell:nodes:node_1:telemetry":
                return json.dumps({"timestamp": base_time - 10}) # 10 seconds ago
            return None
            
        self.mock_redis.hget.side_effect = mock_hget
        
        active_nodes = self.engine._get_active_nodes()
        
        self.assertEqual(len(active_nodes), 1)
        self.assertEqual(active_nodes[0]["id"], "node_1")
        self.assertEqual(active_nodes[0]["ip_tailscale"], "100.1.1.1")

    @patch('agents.economy.ads.organic_engine.subprocess.run')
    def test_campaign_dry_run(self, mock_subprocess):
        """Test the campaign launch without real ADB side-effects"""
        # Fake file existence
        with patch('os.path.exists', return_value=True):
            # Inject a fake node
            self.engine._get_active_nodes = MagicMock(return_value=[{
                "id": "node_pop7",
                "hostname": "Pop7 Test",
                "ip_tailscale": "100.88.123.18"
            }])
            
            # Make ADB commands return success
            mock_res = MagicMock()
            mock_res.stdout = "connected"
            mock_res.stderr = ""
            mock_subprocess.return_value = mock_res
            
            result = self.engine.launch_campaign("/tmp/test.jpg", "Hello #World", dry_run=True)
            
            self.assertEqual(result["status"], "success")
            self.assertEqual(result["node_ip"], "100.88.123.18")
            self.assertTrue(result["dry_run"])

if __name__ == '__main__':
    unittest.main()
