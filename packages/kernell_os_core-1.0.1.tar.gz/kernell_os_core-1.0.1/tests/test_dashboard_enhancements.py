#!/usr/bin/env python3
"""
Comprehensive test script for ANTIGRAVITY dashboard enhancements
Tests all agents and ATLAS context injection
"""

import sys
from pathlib import Path
sys.path.append(str(Path(__file__).parent.parent))

from agents.common.usage_tracker import UsageTracker, track_context_injection
import time
import json

# All 18 agents
AGENTS = [
    "kernel", "chronos", "atlas", "sentinel",
    "forge", "harlemm", "hunter", "telefonica",
    "kali", "present", "alterego", "steward",
    "cash", "archivista", "telegram_bridge", "nexus",
    "spectre", "interface"
]

def test_all_agents():
    """Execute all agents to test usage counter increments"""
    print("=" * 70)
    print("🧪 TESTING ALL AGENTS - Usage Counter Verification")
    print("=" * 70)
    
    results = []
    
    for agent in AGENTS:
        tracker = UsageTracker(agent)
        
        # Get initial count
        initial_stats = tracker.get_usage_stats()
        initial_count = initial_stats.get('usage_count', 0)
        
        # Execute agent (simulate)
        result = tracker.track_execution()
        
        # Get new count
        final_stats = tracker.get_usage_stats()
        final_count = final_stats.get('usage_count', 0)
        
        # Verify increment
        success = final_count == initial_count + 1
        status = "✅" if success else "❌"
        
        print(f"{status} {agent:15} - {initial_count:3} → {final_count:3} uses")
        
        results.append({
            "agent": agent,
            "initial": initial_count,
            "final": final_count,
            "success": success
        })
        
        time.sleep(0.05)  # Small delay
    
    print("=" * 70)
    
    # Summary
    total = len(results)
    passed = sum(1 for r in results if r['success'])
    
    print(f"\n📊 RESULTS: {passed}/{total} agents passed")
    
    if passed == total:
        print("✅ ALL AGENTS PASSED - Counters working correctly!")
    else:
        print("❌ SOME AGENTS FAILED - Check results above")
        failed = [r['agent'] for r in results if not r['success']]
        print(f"Failed agents: {', '.join(failed)}")
    
    return results

def test_atlas_context_injection():
    """Test ATLAS context injection tracking"""
    print("\n" + "=" * 70)
    print("🧬 TESTING ATLAS CONTEXT INJECTION")
    print("=" * 70)
    
    # Simulate context injection for a few agents
    test_agents = ["chronos", "atlas", "hunter", "nexus"]
    
    for agent in test_agents:
        result = track_context_injection(agent)
        
        if result.get('success'):
            print(f"✅ {agent:15} - Context injection tracked")
        else:
            print(f"❌ {agent:15} - Failed: {result.get('error')}")
        
        time.sleep(0.05)
    
    print("=" * 70)
    print("✅ Context injection tracking complete")

def generate_report(results):
    """Generate test report"""
    print("\n" + "=" * 70)
    print("📋 DETAILED REPORT")
    print("=" * 70)
    
    # Sort by usage count
    sorted_results = sorted(results, key=lambda x: x['final'], reverse=True)
    
    print("\nTop 10 Most Used Agents:")
    for i, r in enumerate(sorted_results[:10], 1):
        print(f"{i:2}. {r['agent']:15} - {r['final']:3} uses")
    
    print("\n" + "=" * 70)

if __name__ == "__main__":
    print("\n🚀 Starting Comprehensive Dashboard Test\n")
    
    # Test 1: All agents
    results = test_all_agents()
    
    # Test 2: ATLAS context injection
    test_atlas_context_injection()
    
    # Generate report
    generate_report(results)
    
    print("\n✅ All tests complete! Check dashboard for updated counters.")
    print("   Run: xdg-open http://localhost:8501\n")
