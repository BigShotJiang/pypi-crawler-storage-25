"""agents/core/profit_gates_guard.py — sin Redis real."""

import json
import os
import sys
from datetime import datetime, timezone

import pytest

sys.path.insert(0, "/home/anny/kernell-os")


class FakeRedis:
    def __init__(self, data=None):
        self._data = dict(data or {})

    def get(self, key):
        return self._data.get(key)


def _fresh_ts():
    """Return a fresh ISO timestamp for verdict_age_ok to pass."""
    return datetime.now(timezone.utc).isoformat()


def test_trading_pass(monkeypatch):
    monkeypatch.delenv("KERNELL_PROFIT_GATES_ENFORCE_TRADING", raising=False)
    monkeypatch.setenv("KERNELL_PROFIT_GATES_ENFORCE_TRADING", "1")
    monkeypatch.setenv("KERNELL_PROFIT_GATES_MAX_VERDICT_AGE_S", "3600")
    from agents.core import profit_gates_guard as g

    r = FakeRedis(
        {
            g.KEY_TRADING_VERDICT: json.dumps({"overall": "PASS"}),
            g.KEY_LAST_RUN: _fresh_ts(),
        }
    )
    ok, msg = g.trading_real_execution_allowed(r)
    assert ok is True


def test_trading_fail_closed(monkeypatch):
    monkeypatch.setenv("KERNELL_PROFIT_GATES_ENFORCE_TRADING", "1")
    monkeypatch.setenv("KERNELL_PROFIT_GATES_MAX_VERDICT_AGE_S", "3600")
    from agents.core import profit_gates_guard as g

    r = FakeRedis({
        g.KEY_TRADING_VERDICT: json.dumps({"overall": "FAIL"}),
        g.KEY_LAST_RUN: _fresh_ts(),
    })
    ok, msg = g.trading_real_execution_allowed(r)
    assert ok is False


def test_dropshipping_degraded_simulate_only(monkeypatch):
    monkeypatch.setenv("KERNELL_PROFIT_GATES_ENFORCE_DROPSHIP", "1")
    monkeypatch.setenv("KERNELL_PROFIT_GATES_MAX_VERDICT_AGE_S", "3600")
    from agents.core import profit_gates_guard as g

    r = FakeRedis({
        g.KEY_DROPSHIP_VERDICT: json.dumps({"overall": "DEGRADED"}),
        g.KEY_LAST_RUN: _fresh_ts(),
    })
    assert g.dropshipping_gate_status(r) == "DEGRADED"
    assert g.listing_verdict_allowed("SIMULATE", "DEGRADED") is True
    assert g.listing_verdict_allowed("EXECUTE", "DEGRADED") is False


def test_enforcement_off_allows(monkeypatch):
    monkeypatch.setenv("KERNELL_PROFIT_GATES_ENFORCE_TRADING", "0")
    from agents.core import profit_gates_guard as g

    r = FakeRedis({})
    ok, _ = g.trading_real_execution_allowed(r)
    assert ok is True


def test_no_verdict_fail_closed(monkeypatch):
    monkeypatch.setenv("KERNELL_PROFIT_GATES_ENFORCE_TRADING", "1")
    from agents.core import profit_gates_guard as g

    r = FakeRedis({})  # No verdict, no last_run
    ok, msg = g.trading_real_execution_allowed(r)
    assert ok is False
    assert "never ran" in msg or "no verdict" in msg
