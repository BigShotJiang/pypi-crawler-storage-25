"""
KERNELL OS — Nemesis Risk Manager Tests
=========================================
Tests para lógica de riesgo, circuit breaker y paper trading.
Usa mock Redis para no depender de infraestructura real.
"""
import sys
import os
import json
import pytest
from unittest.mock import MagicMock, patch
from pathlib import Path

ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT))

from agents.nemesis.risk_manager import (
    RiskManager, RiskParams, RiskViolation, OperationMode, SystemState
)


class FakeBytes(str):
    """String that supports .decode() for compatibility with code expecting bytes."""
    def decode(self, *args, **kwargs):
        return str(self)


class MockRedis:
    """Mock Redis that simulates key-value storage for tests."""

    def __init__(self):
        self.store = {}

    def get(self, key):
        v = self.store.get(key)
        return FakeBytes(v) if v is not None else None

    def set(self, key, value, **kwargs):
        self.store[key] = str(value) if not isinstance(value, str) else value

    def incr(self, key):
        val = int(self.store.get(key) or 0)
        self.store[key] = str(val + 1)
        return val + 1

    def decr(self, key):
        val = int(self.store.get(key) or 0)
        self.store[key] = str(max(0, val - 1))
        return max(0, val - 1)

    def setex(self, key, ttl, value):
        self.store[key] = value


def _setup_nominal_state(r: MockRedis, budget=1000.0):
    """Sets up a nominal system state in mock Redis."""
    r.set("kernell:system:defcon", "1")
    r.set("kernell:economy:kill_switch", "false")
    r.set("kernell:economy:nemesis_budget", str(budget))
    r.set("kernell:nemesis:daily_loss_usd", "0.0")
    r.set("kernell:nemesis:open_positions_count", "0")
    r.set("kernell:reality:snapshot", json.dumps({
        "drift_index": 5.0,
        "mode": "STABLE",
        "confidence_score": 95.0,
    }))


class TestRiskChecks:
    """Individual risk check validation."""

    def test_kill_switch_blocks(self):
        r = MockRedis()
        _setup_nominal_state(r)
        r.set("kernell:economy:kill_switch", "true")
        rm = RiskManager(r)
        with pytest.raises(RiskViolation, match="kill_switch"):
            rm.validate_all(100.0)

    def test_defcon_3_blocks(self):
        r = MockRedis()
        _setup_nominal_state(r)
        r.set("kernell:system:defcon", "3")
        rm = RiskManager(r)
        with pytest.raises(RiskViolation, match="DEFCON"):
            rm.validate_all(100.0)

    def test_defcon_1_allows(self):
        r = MockRedis()
        _setup_nominal_state(r)
        r.set("kernell:system:defcon", "1")
        rm = RiskManager(r)
        ok, mode, state = rm.validate_all(100.0)
        assert ok is True
        assert mode == OperationMode.NORMAL

    def test_defcon_2_conservative(self):
        r = MockRedis()
        _setup_nominal_state(r)
        r.set("kernell:system:defcon", "2")
        rm = RiskManager(r)
        ok, mode, state = rm.validate_all(100.0)
        assert ok is True
        assert mode == OperationMode.CONSERVATIVE

    def test_critical_mode_blocks(self):
        r = MockRedis()
        _setup_nominal_state(r)
        r.set("kernell:reality:snapshot", json.dumps({
            "drift_index": 10.0, "mode": "CRITICAL"
        }))
        rm = RiskManager(r)
        with pytest.raises(RiskViolation, match="CRITICAL"):
            rm.validate_all(100.0)

    def test_zero_budget_blocks(self):
        r = MockRedis()
        _setup_nominal_state(r, budget=0)
        rm = RiskManager(r)
        with pytest.raises(RiskViolation, match="Presupuesto"):
            rm.validate_all(100.0)

    def test_high_drift_conservative(self):
        r = MockRedis()
        _setup_nominal_state(r)
        r.set("kernell:reality:snapshot", json.dumps({
            "drift_index": 70.0, "mode": "STRESS"
        }))
        rm = RiskManager(r)
        ok, mode, state = rm.validate_all(100.0)
        assert mode == OperationMode.CONSERVATIVE


class TestCircuitBreaker:
    """Daily loss circuit breaker tests."""

    def test_circuit_breaker_triggers(self):
        r = MockRedis()
        _setup_nominal_state(r, budget=1000.0)
        r.set("kernell:nemesis:daily_loss_usd", "25.0")  # 2.5% > 2%
        rm = RiskManager(r)
        with pytest.raises(RiskViolation, match="CIRCUIT BREAKER"):
            rm.validate_all(100.0)

    def test_circuit_breaker_allows_under_limit(self):
        r = MockRedis()
        _setup_nominal_state(r, budget=1000.0)
        r.set("kernell:nemesis:daily_loss_usd", "15.0")  # 1.5% < 2%
        rm = RiskManager(r)
        ok, _, _ = rm.validate_all(100.0)
        assert ok is True

    def test_concurrent_positions_limit(self):
        r = MockRedis()
        _setup_nominal_state(r)
        r.set("kernell:nemesis:open_positions_count", "3")
        rm = RiskManager(r)
        with pytest.raises(RiskViolation, match="posiciones"):
            rm.validate_all(100.0)


class TestOperationSize:
    """Position sizing and limits."""

    def test_oversized_operation_blocks(self):
        r = MockRedis()
        _setup_nominal_state(r)
        rm = RiskManager(r)
        with pytest.raises(RiskViolation, match="supera límite"):
            rm.validate_all(600.0)  # > 500 max

    def test_conservative_reduces_max(self):
        r = MockRedis()
        _setup_nominal_state(r)
        r.set("kernell:system:defcon", "2")  # Forces conservative
        rm = RiskManager(r)
        # In conservative: max = 500 * 0.5 = 250
        with pytest.raises(RiskViolation, match="supera límite"):
            rm.validate_all(300.0)

    def test_conservative_allows_small(self):
        r = MockRedis()
        _setup_nominal_state(r)
        r.set("kernell:system:defcon", "2")
        rm = RiskManager(r)
        ok, mode, _ = rm.validate_all(200.0)
        assert ok is True
        assert mode == OperationMode.CONSERVATIVE


class TestRecording:
    """Post-trade recording functions."""

    def test_record_loss(self):
        r = MockRedis()
        _setup_nominal_state(r)
        rm = RiskManager(r)
        rm.record_loss(50.0)
        assert float(r.get("kernell:nemesis:daily_loss_usd")) == 50.0

    def test_record_profit(self):
        r = MockRedis()
        _setup_nominal_state(r)
        rm = RiskManager(r)
        rm.record_profit(75.0)
        assert float(r.get("kernell:nemesis:daily_profit_usd")) == 75.0

    def test_cumulative_loss(self):
        r = MockRedis()
        _setup_nominal_state(r)
        r.set("kernell:nemesis:daily_loss_usd", "10.0")
        rm = RiskManager(r)
        rm.record_loss(15.0)
        assert float(r.get("kernell:nemesis:daily_loss_usd")) == 25.0

    def test_increment_decrement_positions(self):
        r = MockRedis()
        _setup_nominal_state(r)
        rm = RiskManager(r)
        rm.increment_positions()
        assert int(r.get("kernell:nemesis:open_positions_count")) == 1
        rm.increment_positions()
        assert int(r.get("kernell:nemesis:open_positions_count")) == 2
        rm.decrement_positions()
        assert int(r.get("kernell:nemesis:open_positions_count")) == 1

    def test_reset_daily_counters(self):
        r = MockRedis()
        _setup_nominal_state(r)
        r.set("kernell:nemesis:daily_loss_usd", "50.0")
        r.set("kernell:nemesis:daily_profit_usd", "30.0")
        rm = RiskManager(r)
        rm.reset_daily_counters()
        assert float(r.get("kernell:nemesis:daily_loss_usd")) == 0.0
        assert float(r.get("kernell:nemesis:daily_profit_usd")) == 0.0


class TestActionGate:
    """ActionGate paper trading validation."""

    def test_paper_trading_always_allowed(self):
        with patch.dict(os.environ, {"PAPER_TRADING": "true"}):
            # Re-import to pick up env
            from agents.nemesis.core import _ActionGate
            r = MockRedis()
            result = _ActionGate.can_execute_trade(1000.0, "BTC/USDT", r)
            assert result["allowed"] is True
            assert result["dry_run"] is True

    def test_technical_analyzer_rsi(self):
        from agents.nemesis.core import TechnicalAnalyzer
        ta = TechnicalAnalyzer()
        # Generate simple ascending closes
        closes = [100.0 + i * 0.5 for i in range(30)]
        rsi = ta.calculate_rsi(closes)
        assert 0 <= rsi <= 100

    def test_technical_analyzer_bollinger(self):
        from agents.nemesis.core import TechnicalAnalyzer
        ta = TechnicalAnalyzer()
        closes = [100.0 + i * 0.1 for i in range(25)]
        upper, middle, lower = ta.calculate_bollinger(closes)
        assert upper > middle > lower
