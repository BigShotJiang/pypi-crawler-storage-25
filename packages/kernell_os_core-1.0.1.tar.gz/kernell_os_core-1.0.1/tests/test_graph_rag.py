import sys
import os
import json
import logging
from pathlib import Path

# Add root to python path
sys.path.append(str(Path(__file__).parent.parent))

from agents.atlas.graph_manager import GraphManager

# Setup basic logging
logging.basicConfig(level=logging.INFO, format='%(message)s')
logger = logging.getLogger("GRAPH_TEST")

def test_graph_rag():
    print("\n🕸️  TESTING GRAPHRAG CAPABILITIES 🕸️\n")

    # 1. Initialize Graph
    gm = GraphManager()
    print("✅ GraphManager Initialized")

    # 2. Ingest Sample Data (The "Documentation")
    print("\n📝 Ingesting Knowledge...")
    triples = [
        ("Kernell OS", "uses", "Redis"),
        ("Redis", "is_a", "Key-Value Store"),
        ("Redis", "located_at", "L1 Memory"),
        ("L1 Memory", "is", "Volatile"),
        ("Qdrant", "is_a", "Vector Database"),
        ("Qdrant", "stores", "Embeddings"),
        ("Atlas", "orchestrates", "Kernell OS"),
        ("Atlas", "manages", "Context"),
        ("Context", "stored_in", "RAMDisk"),
        ("RAMDisk", "is_a", "L1.5 Memory"),
        ("L1.5 Memory", "wiped_on", "Reboot")
    ]
    gm.add_knowledge_batch(triples)
    print(f"✅ Ingested {len(triples)} facts.")

    # 3. Query: The "Multi-Hop" Problem
    # Question: "What happens to the Context on Reboot?"
    # Logic: Context -> stored_in -> RAMDisk -> is_a -> L1.5 Memory -> wiped_on -> Reboot
    
    print("\n🔎 Querying Relations...")
    
    # Simple Neighbor Check
    print("   > Neighbors of 'Context':")
    neighbors = gm.get_neighbors("Context")
    for n in neighbors:
        print(f"     - {n['relation']} -> {n['concept']}")

    # Path Finding
    print("\n🚀 Path Finding (Inferential Reasoning):")
    start = "Context"
    end = "Reboot"
    print(f"   > Finding path from '{start}' to '{end}'...")
    
    path = gm.find_path(start, end)
    
    if path:
        print(f"   ✅ PATH FOUND: {' -> '.join(path)}")
        print("   🧠 CONCLUSION: The Context is wiped on Reboot (inferred via RAMDisk/L1.5).")
    else:
        print("   ❌ No path found.")

    # 4. Subgraph Extraction (Context Injection)
    print("\n📦 Context Injection (Subgraph):")
    context = gm.search_subgraph("Redis")
    print(f"---\n{context}\n---")

if __name__ == "__main__":
    test_graph_rag()
