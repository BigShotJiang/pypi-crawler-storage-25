import time
import json
import redis

def test_herald_generation():
    r = redis.Redis(host='localhost', port=6379, db=0, decode_responses=True)
    
    # 1. Clear previous drafts for clean test
    r.delete("kernell:social:drafts")
    
    # 2. Prepare payload
    payload = {
        "type": "generate_content",
        "payload": {
            "topic": "Kernell OS v12.5 release with advanced AI Pentesting capabilities.",
            "platforms": ["X", "YouTube", "TikTok"]
        }
    }
    
    print("🚀 Sending generation task to Herald...")
    r.lpush("kernell:tasks:herald", json.dumps(payload))
    
    # 3. Wait for draft to appear (Herald runs interval=15, we'll wait up to 45s)
    print("⏳ Waiting for Herald to process (max 45s)...")
    for i in range(45):
        drafts = r.hgetall("kernell:social:drafts")
        if drafts:
            print("\n✅ Success! Draft found in Redis:")
            for k, v in drafts.items():
                data = json.loads(v)
                print(f"\n--- Draft ID: {k} ---")
                print(f"Status: {data.get('status')}")
                print(f"Platforms: {data.get('platforms')}")
                print(f"Content:\n{data.get('content')}")
            return
        time.sleep(1)
        print(".", end="", flush=True)
        
    print("\n❌ Failed: No draft found after 45 seconds.")

if __name__ == "__main__":
    test_herald_generation()
