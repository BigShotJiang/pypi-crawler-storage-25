#!/usr/bin/env python3
"""
KERNELL OS — Integration Tests for New Components
===================================================
Tests for: Ontology Layer, Backup Engine, Agent Heartbeats, SAGE Daemon
Run: cd /home/anny/kernell-os && .venv/bin/python3 -m pytest tests/test_new_components.py -v
"""

import os
import sys
import json
import pytest

sys.path.insert(0, "/home/anny/kernell-os")
os.environ.setdefault("PYTHONPATH", "/home/anny/kernell-os")

from dotenv import load_dotenv
load_dotenv("/home/anny/kernell-os/.env")


# ═══════════════════════════════════════════════════
# FIXTURES
# ═══════════════════════════════════════════════════

@pytest.fixture(scope="session")
def redis_client():
    import redis
    pw = os.environ.get("REDIS_PASSWORD", "").strip().strip('"').strip("'") or None
    r = redis.Redis(host="localhost", port=6379, password=pw, decode_responses=True)
    try:
        r.ping()
    except Exception:
        pytest.skip("Redis not available")
    return r


@pytest.fixture(scope="session")
def qdrant_client():
    from qdrant_client import QdrantClient
    q = QdrantClient(host="localhost", port=6333)
    try:
        q.get_collections()
    except Exception:
        pytest.skip("Qdrant not available")
    return q


# ═══════════════════════════════════════════════════
# TEST: ONTOLOGY CLIENT
# ═══════════════════════════════════════════════════

class TestOntologyClient:
    """Tests for the semantic ontology client."""

    def test_import(self):
        """OntologyClient is importable."""
        from agents.core.ontology import OntologyClient, COLLECTION_MAP
        assert OntologyClient is not None
        assert isinstance(COLLECTION_MAP, dict)

    def test_collection_map_complete(self):
        """COLLECTION_MAP has all 13 object types."""
        from agents.core.ontology import COLLECTION_MAP
        expected_types = [
            "TradeSignal", "TradePosition", "AdCampaign", "AgentDecision",
            "EvolutionProposal", "Product", "Supplier", "B2BLead",
            "SystemEvent", "KnowledgeItem", "AgentSkill",
            "KernellOSNode", "AntigravityNode", "NodeEvent",
        ]
        for ot in expected_types:
            assert ot in COLLECTION_MAP, f"Missing object type: {ot}"

    def test_collection_map_values(self):
        """All collection names in COLLECTION_MAP are valid."""
        from agents.core.ontology import COLLECTION_MAP
        valid_collections = {
            "kernell_memory", "kernell_memory", "kernell_episodes",
            "kernell_memory", "kernell_memory",
            "kernell_memory", "kernell_episodes",
        }
        for ot, coll in COLLECTION_MAP.items():
            assert coll in valid_collections, f"{ot} → {coll} not in valid set"


# ═══════════════════════════════════════════════════
# TEST: QDRANT COLLECTIONS
# ═══════════════════════════════════════════════════

class TestQdrantCollections:
    """Verify all required Qdrant collections exist."""

    REQUIRED = [
        "kernell_memory", "kernell_episodes", "kernell_memory",
        "kernell_memory", "kernell_memory", "kernell_memory",
        "kernell_memory", "kernell_memory",
        "kernell_memory", "kernell_episodes",
        "kernell_memory", "kernell_memory",
    ]

    def test_all_collections_exist(self, qdrant_client):
        """All 12 required collections are present."""
        existing = [c.name for c in qdrant_client.get_collections().collections]
        for coll in self.REQUIRED:
            assert coll in existing, f"Collection missing: {coll}"

    def test_collections_have_correct_dimensions(self, qdrant_client):
        """Collections with data use 768-dim vectors (Gemini embedding size)."""
        for coll_name in ["kernell_memory", "kernell_episodes"]:
            info = qdrant_client.get_collection(coll_name)
            config = info.config
            vector_size = config.params.vectors.size
            assert vector_size == 768, f"{coll_name} has {vector_size} dims, expected 768"

    def test_ontology_seed_populated_decisions(self, qdrant_client):
        """kernell_memory has agent registry entries from seed."""
        points = qdrant_client.scroll(
            collection_name="kernell_memory",
            limit=100,
            with_payload=True,
        )[0]
        agent_entries = [
            p for p in points
            if p.payload.get("decision_type") == "agent_registration"
        ]
        assert len(agent_entries) >= 5, f"Expected ≥5 agent entries, got {len(agent_entries)}"


# ═══════════════════════════════════════════════════
# TEST: AGENT HEARTBEATS
# ═══════════════════════════════════════════════════

class TestAgentHeartbeats:
    """Verify critical agent heartbeats are active."""

    CRITICAL_AGENTS = [
        "kernell", "atlas", "chronos", "sentinel", "sierra",
        "observer", "operator", "scribe",
    ]

    def test_critical_heartbeats_exist(self, redis_client):
        """All critical agents have active heartbeats."""
        missing = []
        for agent in self.CRITICAL_AGENTS:
            hb = redis_client.get(f"kernell:agent:{agent}:heartbeat")
            if not hb:
                missing.append(agent)
        assert len(missing) == 0, f"Missing heartbeats: {missing}"

    def test_observer_heartbeat_ttl(self, redis_client):
        """Observer heartbeat TTL should be <= 120s (the fix we applied)."""
        ttl = redis_client.ttl("kernell:agent:observer:heartbeat")
        assert 0 < ttl <= 120, f"Observer TTL={ttl}s, expected 0-120"

    def test_sage_heartbeat_has_daemon_fields(self, redis_client):
        """SAGE heartbeat should include daemon-specific fields."""
        hb_raw = redis_client.get("kernell:agent:sage:heartbeat")
        if not hb_raw:
            pytest.skip("SAGE heartbeat not available")
        hb = json.loads(hb_raw)
        assert "next_fast_scan" in hb, "Missing next_fast_scan in SAGE heartbeat"
        assert "cycle_running" in hb, "Missing cycle_running in SAGE heartbeat"

    def test_total_agents_online(self, redis_client):
        """At least 20 of 24 agents should have heartbeats."""
        agents = [
            "kernell", "atlas", "chronos", "sentinel", "forge", "nexus",
            "interface", "sierra", "overseer", "hunter", "archivista",
            "scribe", "fixer", "economy", "telegram_bridge", "vector",
            "nemesis", "ads", "herald", "bounty", "operator", "prospector",
            "observer", "sage",
        ]
        alive = sum(1 for a in agents if redis_client.get(f"kernell:agent:{a}:heartbeat"))
        assert alive >= 20, f"Only {alive}/24 agents online, expected ≥20"


# ═══════════════════════════════════════════════════
# TEST: BACKUP ENGINE
# ═══════════════════════════════════════════════════

class TestBackupEngine:
    """Test backup engine components."""

    def test_import(self):
        """BackupEngine is importable."""
        from agents.archivista.backup_engine import BackupEngine
        assert BackupEngine is not None

    def test_integrity_verifier(self, tmp_path):
        """IntegrityVerifier produces correct SHA-256."""
        from agents.archivista.backup_engine import IntegrityVerifier
        test_file = tmp_path / "test.txt"
        test_file.write_text("hello kernell")
        h = IntegrityVerifier.hash_file(str(test_file))
        assert len(h) == 64  # SHA-256 hex digest length
        assert h == IntegrityVerifier.hash_file(str(test_file))  # Deterministic

    def test_rotation_policy_no_crash(self, tmp_path):
        """RotationPolicy.enforce doesn't crash on empty dir."""
        from agents.archivista.backup_engine import RotationPolicy
        result = RotationPolicy.enforce(tmp_path)
        assert result["removed"] == 0


# ═══════════════════════════════════════════════════
# TEST: SAGE DAEMON
# ═══════════════════════════════════════════════════

class TestSageDaemon:
    """Test SAGE daemon components."""

    def test_import_daemon(self):
        """SageDaemon is importable."""
        from agents.sage.daemon import SageDaemon, CooldownManager, CycleScheduler
        assert SageDaemon is not None
        assert CooldownManager is not None
        assert CycleScheduler is not None

    def test_scheduler_calculates_future(self):
        """CycleScheduler returns positive seconds."""
        from agents.sage.daemon import CycleScheduler
        fast = CycleScheduler.seconds_until_fast_scan()
        full = CycleScheduler.seconds_until_full_research()
        assert fast > 0, f"fast_scan seconds should be > 0, got {fast}"
        assert full > 0, f"full_research seconds should be > 0, got {full}"

    def test_chain_verifier_import(self):
        """Scribe chain_verifier is importable."""
        from agents.scribe.chain_verifier import ChainVerifier, LedgerSync
        assert ChainVerifier is not None
        assert LedgerSync is not None


# ═══════════════════════════════════════════════════
# TEST: ONTOLOGY YAML
# ═══════════════════════════════════════════════════

class TestOntologyYAML:
    """Validate ontology_semantic.yaml structure."""

    def test_yaml_loads(self):
        """ontology_semantic.yaml is valid YAML."""
        import yaml
        with open("/home/anny/kernell-os/core/ontology_semantic.yaml") as f:
            data = yaml.safe_load(f)
        assert data is not None

    def test_has_object_types(self):
        """YAML defines object_types section."""
        import yaml
        with open("/home/anny/kernell-os/core/ontology_semantic.yaml") as f:
            data = yaml.safe_load(f)
        assert "object_types" in data
        assert len(data["object_types"]) >= 10

    def test_has_link_types(self):
        """YAML defines link_types section."""
        import yaml
        with open("/home/anny/kernell-os/core/ontology_semantic.yaml") as f:
            data = yaml.safe_load(f)
        assert "link_types" in data
        assert len(data["link_types"]) >= 5


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
