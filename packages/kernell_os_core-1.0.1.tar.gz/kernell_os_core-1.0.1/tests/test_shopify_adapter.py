import os
import unittest
from unittest.mock import patch, MagicMock
from agents.finance.economy.marketplaces.shopify import ShopifyAdapter

class TestShopifyAdapter(unittest.TestCase):
    
    @patch.dict(os.environ, {"SHOPIFY_STORE_URL": "", "SHOPIFY_ACCESS_TOKEN": ""})
    def test_missing_credentials_fallback(self):
        """Test that without credentials, the adapter returns safe fallback zeroes."""
        adapter = ShopifyAdapter(interval=600)
        data = adapter.fetch_marketplace_data()
        
        self.assertEqual(data["revenue"], 0.0)
        self.assertEqual(data["profit"], 0.0)
        self.assertEqual(data["store_count"], 0)
        self.assertEqual(data["status"], "missing_credentials")
        self.assertFalse(adapter._has_auth)

    @patch.dict(os.environ, {"SHOPIFY_STORE_URL": "https://test.myshopify.com", "SHOPIFY_ACCESS_TOKEN": "token123"})
    @patch('requests.Session.get')
    def test_fetch_market_data_success(self, mock_get):
        """Test fetching orders and parsing correctly"""
        adapter = ShopifyAdapter(interval=600)
        
        # Mock Orders response
        orders_mock = MagicMock()
        orders_mock.status_code = 200
        orders_mock.json.return_value = {
            "orders": [
                {"total_price": "100.50"},
                {"total_price": "50.25"}
            ]
        }
        
        # Mock Products count response
        products_mock = MagicMock()
        products_mock.status_code = 200
        products_mock.json.return_value = {"count": 15}
        
        mock_get.side_effect = [orders_mock, products_mock]
        
        data = adapter.fetch_marketplace_data()
        
        self.assertEqual(data["revenue"], 150.75)   # 100.50 + 50.25
        # Sin line_items, order_cogs=0 → beneficio bruto = revenue (comportamiento actual del adapter)
        self.assertEqual(data["profit"], 150.75)
        self.assertEqual(data["store_count"], 1)
        self.assertEqual(data["active_listings"], 15)
        self.assertEqual(data["status"], "active")

    @patch.dict(os.environ, {"SHOPIFY_STORE_URL": "https://test.myshopify.com", "SHOPIFY_ACCESS_TOKEN": "token123"})
    @patch('requests.Session.get')
    def test_fetch_market_data_rate_limit(self, mock_get):
        """Test handling of 429 Too Many Requests"""
        adapter = ShopifyAdapter(interval=600)
        
        error_mock = MagicMock()
        error_mock.status_code = 429
        mock_get.return_value = error_mock
        
        with self.assertRaises(Exception) as context:
            adapter.fetch_marketplace_data()
            
        self.assertTrue("Rate Limit Exceeded" in str(context.exception))

if __name__ == '__main__':
    unittest.main()
