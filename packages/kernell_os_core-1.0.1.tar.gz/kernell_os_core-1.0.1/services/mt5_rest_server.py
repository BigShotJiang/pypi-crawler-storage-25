#!/usr/bin/env python3
"""
MT5 REST JSON Bridge — Kernell OS
===================================
Flask single-threaded server running inside Wine.
Proxies all MT5 Python API calls over HTTP JSON.

Features:
  - Auto-reconnect on IPC failure (-10001)
  - /api/ping  → liveness probe (Flask only)
  - /api/health → readiness probe (real MT5 check)
  - /api/mt5   → generic MT5 method proxy

Author: Kernell OS — IA-Metrópolis
"""

import logging
import json
import datetime
import traceback
import sys
import os
import time
import threading

import numpy as np
from flask import Flask, request, Response

# MetaTrader 5 module must be imported locally inside Wine!
# We set it to None and import lazily to prevent Wine hang!
mt5 = None

logger = logging.getLogger("mt5_rest")
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)

app = Flask(__name__)

# ── MT5 State ─────────────────────────────────────────────────────────
_mt5_ready = False
_mt5_lock = threading.Lock()  # Guard for single-threaded reinit
_last_reinit_ts = 0
_REINIT_COOLDOWN = 10  # seconds between reinit attempts


def _do_mt5_init() -> bool:
    """Initialize MT5 and login. Returns True on success."""
    global _mt5_ready

    if mt5 is None:
        return False

    if not mt5.initialize():
        logger.error(f"mt5.initialize() failed: {mt5.last_error()}")
        _mt5_ready = False
        return False

    login = os.getenv("MT5_LOGIN")
    password = os.getenv("MT5_PASSWORD")
    server = os.getenv("MT5_SERVER", "MetaQuotes-Demo")

    if login and password:
        try:
            login_int = int(login)
            if mt5.login(login_int, password=password, server=server):
                logger.info(f"MT5 logged in: account {login_int} on {server}")
            else:
                logger.error(f"MT5 login failed for {login_int} on {server}: {mt5.last_error()}")
                _mt5_ready = False
                return False
        except Exception as e:
            logger.error(f"Failed to parse MT5 login credentials: {e}")
            _mt5_ready = False
            return False

    for sym in ["EURUSDm", "GBPUSDm", "USDJPYm", "XAUUSDm", "BTCUSDm"]:
        if hasattr(mt5, "symbol_select"):
            try:
                mt5.symbol_select(sym, True)
            except Exception:
                pass

    _mt5_ready = True
    return True


def _reinit_mt5() -> bool:
    """Attempt to re-initialize MT5 (shutdown + init + login).
    Returns True if MT5 is now ready. Respects cooldown."""
    global _last_reinit_ts, _mt5_ready

    if mt5 is None:
        return False

    now = time.time()
    if now - _last_reinit_ts < _REINIT_COOLDOWN:
        return _mt5_ready

    with _mt5_lock:
        # Double-check after acquiring lock
        if time.time() - _last_reinit_ts < _REINIT_COOLDOWN:
            return _mt5_ready

        _last_reinit_ts = time.time()
        logger.warning("🔄 MT5 auto-reconnect: shutting down + reinitializing...")

        try:
            mt5.shutdown()
        except Exception:
            pass

        time.sleep(1)

        for attempt in range(3):
            if _do_mt5_init():
                logger.info(f"✅ MT5 auto-reconnect successful (attempt {attempt + 1})")
                return True
            logger.warning(f"Reinit attempt {attempt + 1}/3 failed, retrying in 2s...")
            time.sleep(2)

        logger.error("❌ MT5 auto-reconnect failed after 3 attempts")
        _mt5_ready = False
        return False


def _parse_iso_datetime(val):
    if isinstance(val, str) and len(val) >= 10:
        try:
            s = val.replace("Z", "+00:00")
            return datetime.datetime.fromisoformat(s)
        except ValueError:
            pass
    return val


# Arg indices (0-based) to coerce from ISO string → datetime for each MT5 method.
_MT5_DATETIME_ARG_INDICES = {
    "history_deals_get": (0, 1),
    "history_orders_get": (0, 1),
    "history_deals_get_by_ticket": (),
    "history_orders_get_by_ticket": (),
    "copy_rates_from": (2,),
    "copy_rates_range": (2, 3),
    "copy_ticks_from": (1,),
    "copy_ticks_range": (1, 2),
}


def _coerce_json_args_to_mt5(method_name: str, args: list, kwargs: dict):
    """
    El cliente envía fechas como ISO8601 (strings). Varios métodos MT5 esperan datetime.
    """
    if method_name in _MT5_DATETIME_ARG_INDICES:
        indices = _MT5_DATETIME_ARG_INDICES[method_name]
        args = list(args)
        for i in indices:
            if i < len(args):
                args[i] = _parse_iso_datetime(args[i])
        return args, {k: _parse_iso_datetime(v) for k, v in kwargs.items()}

    return args, kwargs


def _safe_mt5_call(method_name: str, args: list, kwargs: dict):
    """Execute an MT5 method with auto-reconnect on IPC failure."""
    if mt5 is None:
        return None, "MT5 module not loaded inside Wine"
    func = getattr(mt5, method_name, None)
    if func is None:
        return None, f"Method {method_name} not found"

    # First attempt
    try:
        result = func(*args, **kwargs)
    except Exception as e:
        return None, f"Exception: {e}"

    # Check if result indicates IPC death
    if result is None:
        err = mt5.last_error()
        err_code = err[0] if err and len(err) > 0 else 0

        if err_code in (-10001, -10003, -10004):
            # IPC send failed / timeout / no connection — attempt reconnect
            logger.warning(f"MT5 IPC failure (code {err_code}) on {method_name}, triggering reconnect...")
            if _reinit_mt5():
                # Retry once after reconnect
                try:
                    result = func(*args, **kwargs)
                    if result is not None:
                        return result, None
                except Exception as e2:
                    return None, f"Retry exception: {e2}"

            return None, f"IPC dead (code {err_code}), reconnect failed"

    return result, None


# ── Deferred MT5 init via background thread ───────────────────────────
# CRITICAL: Flask must bind the port BEFORE MT5 initializes.
# Under Wine, mt5.initialize() can hang indefinitely on COM/IPC.
# Running it in a daemon thread lets the health endpoint respond "degraded"
# immediately, instead of the entire process hanging and never starting.
def _deferred_mt5_init():
    """Initialize MT5 in background so Flask port binds immediately."""
    global mt5
    time.sleep(8)  # Give terminal time to register COM pipes
    
    try:
        import MetaTrader5 as _mt5
        mt5 = _mt5
        logger.info("MetaTrader5 module imported successfully in background.")
    except Exception as e:
        logger.error(f"Fatal error importing MetaTrader5: {e}")
        return

    for _attempt in range(15):
        if _do_mt5_init():
            ti = mt5.terminal_info()
            logger.info(f"MT5 Initialized (attempt {_attempt + 1}): {ti}")
            return
        logger.warning(f"initialize() attempt {_attempt + 1}/15 failed: {mt5.last_error()} — retrying in 5s...")
        time.sleep(5)
    logger.error("MT5 failed to initialize after 15 attempts. Running in degraded mode.")

_init_thread = threading.Thread(target=_deferred_mt5_init, daemon=True, name="mt5-deferred-init")
_init_thread.start()
logger.info("Flask starting immediately — MT5 init deferred to background thread.")


# ── Serialization ─────────────────────────────────────────────────────

def serialize_mt5(obj):
    """Recursively encodes MT5 namedtuples, objects, and numpy arrays to JSON primitives."""
    if obj is None:
        return None
    elif isinstance(obj, np.integer):
        return int(obj)
    elif isinstance(obj, np.floating):
        return float(obj)
    elif isinstance(obj, np.ndarray):
        return obj.tolist()
    elif hasattr(obj, "_asdict"):
        return {k: serialize_mt5(v) for k, v in obj._asdict().items()}
    elif hasattr(obj, "__dict__"):
        return {k: serialize_mt5(v) for k, v in obj.__dict__.items()}
    elif isinstance(obj, (datetime.datetime, datetime.date)):
        return obj.isoformat()
    elif isinstance(obj, dict):
        return {k: serialize_mt5(v) for k, v in obj.items()}
    elif isinstance(obj, (list, tuple)):
        return [serialize_mt5(v) for v in obj]
    return obj


# ── Routes ────────────────────────────────────────────────────────────

@app.route('/api/mt5', methods=['POST'])
def proxy():
    data = request.json or {}
    method_name = data.get("method")
    args = data.get("args", [])
    kwargs = data.get("kwargs", {})

    args, kwargs = _coerce_json_args_to_mt5(method_name, args, kwargs)

    if not method_name or not hasattr(mt5, method_name):
        return Response(
            json.dumps({"error": f"Method {method_name} not found"}),
            status=404, mimetype='application/json',
        )

    result, error = _safe_mt5_call(method_name, args, kwargs)

    if error:
        return Response(
            json.dumps({"error": error}),
            status=500, mimetype='application/json',
        )

    encoded = serialize_mt5(result)
    return Response(
        json.dumps({"result": encoded}),
        status=200, mimetype='application/json',
    )


@app.route('/api/ping', methods=['GET'])
def ping():
    """Liveness probe — Flask is alive."""
    return Response(
        json.dumps({"status": "ok"}),
        status=200, mimetype='application/json',
    )


@app.route('/api/health', methods=['GET'])
def health():
    """Readiness probe — checks real MT5 connection state."""
    global _mt5_ready

    if not _mt5_ready:
        # Try a reconnect if we know we're down
        _reinit_mt5()

    # Attempt a real MT5 call
    ti, err = _safe_mt5_call("terminal_info", [], {})

    if ti is None or err:
        return Response(
            json.dumps({
                "status": "degraded",
                "mt5_ready": False,
                "error": err or "terminal_info returned None",
                "last_error": serialize_mt5(mt5.last_error()) if mt5 else "MT5 module not loaded",
            }),
            status=503, mimetype='application/json',
        )

    connected = getattr(ti, "connected", False) if hasattr(ti, "connected") else ti.get("connected", False) if isinstance(ti, dict) else False
    
    # Also check account
    ai, ai_err = _safe_mt5_call("account_info", [], {})
    balance = 0.0
    login = 0
    trade_expert = False
    
    if ai and not ai_err:
        balance = getattr(ai, "balance", 0.0) if hasattr(ai, "balance") else ai.get("balance", 0.0) if isinstance(ai, dict) else 0.0
        login = getattr(ai, "login", 0) if hasattr(ai, "login") else ai.get("login", 0) if isinstance(ai, dict) else 0
        trade_expert = getattr(ai, "trade_expert", False) if hasattr(ai, "trade_expert") else ai.get("trade_expert", False) if isinstance(ai, dict) else False

    # Under Wine, terminal trade_allowed is often false, but if account trade_expert is True, we can trade.
    status = "ok" if (connected and trade_expert and balance >= 0.0) else "partial"
    http_code = 200 if status == "ok" else 207  # 207 = Multi-Status (partial)

    return Response(
        json.dumps({
            "status": status,
            "mt5_ready": True,
            "connected": connected,
            "trade_expert": trade_expert,
            "balance": balance,
            "login": login,
        }),
        status=http_code, mimetype='application/json',
    )


if __name__ == '__main__':
    # threaded=False is CRITICAL for Wine COM initialization! All API calls
    # execute strictly sequentially on the main thread, avoiding unhandled message bugs.
    port = int(os.getenv("MT5_REST_PORT", "18812"))
    app.run(host='0.0.0.0', port=port, threaded=False)
