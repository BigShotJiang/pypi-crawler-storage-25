"""
🛒 Shopify Webhook Receiver — Kernell OS Dropshipping Gateway
Receives Shopify `orders/create` webhooks and injects them into
the Redis fulfillment queue for CJ Dropshipping auto-fulfillment.

Run:
  uvicorn services.shopify_webhook.server:app --host 0.0.0.0 --port 8900

Redis Queue:
  - kernell:FULFILL:orders:pending (List — new orders for CJDropshippingFulfillment)

HTTP probes (v1.1+):
  - GET /live  — liveness
  - GET /ready — readiness (503 si Redis cae)
  - GET /health — métricas suaves (200 aunque Redis falle; status=degraded)

Security:
  - Validates Shopify HMAC signature on every request
  - Rejects requests without valid signature

CJ Dropshipping Queue:
  - kernell:FULFILL:cjdropshipping:tracking (List — order tracking updates)
"""

import os
import json
import hmac
import hashlib
import base64
import time
import logging
from typing import Optional

from fastapi import FastAPI, Request, HTTPException, Header
from fastapi.responses import JSONResponse
from dotenv import load_dotenv

load_dotenv()
logger = logging.getLogger("SHOPIFY_WEBHOOK")

app = FastAPI(
    title="Kernell OS — Shopify Webhook Gateway",
    version="1.1.0",
    docs_url=None,
    redoc_url=None
)

# Configuration
SHOPIFY_WEBHOOK_SECRET = os.getenv("SHOPIFY_WEBHOOK_SECRET", "")
REDIS_HOST = os.getenv("REDIS_HOST", "127.0.0.1")
REDIS_PORT = int(os.getenv("REDIS_PORT", "6380"))
REDIS_PASSWORD = os.getenv("REDIS_PASSWORD", "")

# Lazy Redis connection
_redis = None

def get_redis():
    global _redis
    if _redis is None:
        import redis
        pwd = REDIS_PASSWORD.strip().strip("\"'") or None
        _redis = redis.Redis(host=REDIS_HOST, port=REDIS_PORT, password=pwd, decode_responses=True)
    return _redis


def verify_shopify_hmac(body: bytes, hmac_header: str) -> bool:
    """Verify Shopify webhook HMAC-SHA256 signature."""
    if not SHOPIFY_WEBHOOK_SECRET:
        logger.warning("⚠️ SHOPIFY_WEBHOOK_SECRET not set. Skipping HMAC verification.")
        return True  # Allow in dev mode

    computed = base64.b64encode(
        hmac.new(
            SHOPIFY_WEBHOOK_SECRET.encode("utf-8"),
            body,
            hashlib.sha256
        ).digest()
    ).decode("utf-8")

    return hmac.compare_digest(computed, hmac_header)


@app.post("/webhooks/shopify/orders/create")
async def handle_order_created(
    request: Request,
    x_shopify_hmac_sha256: Optional[str] = Header(None),
    x_shopify_topic: Optional[str] = Header(None),
    x_shopify_shop_domain: Optional[str] = Header(None)
):
    """
    Receives Shopify orders/create webhook.
    Normalizes the order and pushes it to Redis fulfillment queue.
    """
    body = await request.body()

    # 1. Verify HMAC signature
    if x_shopify_hmac_sha256 and not verify_shopify_hmac(body, x_shopify_hmac_sha256):
        logger.warning(f"🚫 Invalid HMAC from {x_shopify_shop_domain}")
        raise HTTPException(status_code=401, detail="Invalid signature")

    # 2. Parse order
    try:
        order = json.loads(body)
    except json.JSONDecodeError:
        raise HTTPException(status_code=400, detail="Invalid JSON")

    order_id = str(order.get("id", ""))
    order_number = order.get("order_number", "")

    logger.info(f"📬 Webhook received: Order #{order_number} (ID: {order_id}) from {x_shopify_shop_domain}")

    # 3. Check financial status — only process paid orders
    financial_status = order.get("financial_status", "")
    if financial_status not in ("paid", "partially_paid"):
        logger.info(f"⏭️ Skipping order #{order_number}: financial_status={financial_status}")
        return {"status": "skipped", "reason": f"financial_status={financial_status}"}

    # 4. Normalize for fulfillment queue
    shipping = order.get("shipping_address") or {}
    normalized = {
        "order_id": order_id,
        "order_number": order_number,
        "customer_name": f"{shipping.get('first_name', '')} {shipping.get('last_name', '')}".strip(),
        "customer_email": order.get("email", ""),
        "shipping_address": {
            "name": f"{shipping.get('first_name', '')} {shipping.get('last_name', '')}".strip(),
            "address1": shipping.get("address1", ""),
            "address2": shipping.get("address2", ""),
            "city": shipping.get("city", ""),
            "province": shipping.get("province", ""),
            "zip": shipping.get("zip", ""),
            "country": shipping.get("country", ""),
            "country_code": shipping.get("country_code", ""),
            "phone": shipping.get("phone", ""),
        },
        "line_items": [
            {
                "shopify_product_id": str(item.get("product_id", "")),
                "shopify_variant_id": str(item.get("variant_id", "")),
                "title": item.get("title", ""),
                "quantity": item.get("quantity", 1),
                "price": float(item.get("price", 0)),
                "sku": item.get("sku", "")
            }
            for item in order.get("line_items", [])
        ],
        "total_price": float(order.get("total_price", 0)),
        "currency": order.get("currency", "USD"),
        "created_at": order.get("created_at", ""),
        "received_at": time.time(),
        "source": "shopify_webhook"
    }

    # 5. Push to Redis fulfillment queue
    r = get_redis()
    r.rpush("kernell:FULFILL:orders:pending", json.dumps(normalized))
    
    # 5.b. Tokenize physically-paid Shopify USD order into $KERN ESCROW automatically
    try:
        from services.control_room.kern_ledger import create_invoice, pay_invoice
        
        # 1 USD = 1 KERN for internal accounting
        amount_kern = normalized['total_price']
        
        # We simulate the external buyer created the invoice for the merchant
        # and it immediately got "ESCROWED" because Shopify guaranteed the FIAT USD.
        
        inv = create_invoice(
            redis_client=r,
            from_entity="dropship_merchant",  # The agent selling
            amount=amount_kern,
            description=f"Shopify Order {order_number}"
        )
        
        # Immediately push it into ESCROW via pay_invoice
        pay_invoice(
            redis_client=r,
            invoice_id=inv["invoice_id"],
            payer_entity="shopify_gateway" # System account representing fiat in processing
        )
        logger.info(f"🪙 Tokenized Order #{order_number} into KERN ESCROW Invoice: {inv['invoice_id']}")
    except ImportError:
        logger.warning("Kern ledger not found. Skipping KERN Tokenization.")
    except Exception as e:
        logger.error(f"Failed to tokenize into KERN: {e}")

    # 6. Publish event for real-time listeners
    r.publish("kernell:events:new_order", json.dumps({
        "order_id": order_id,
        "order_number": order_number,
        "total": normalized["total_price"],
        "currency": normalized["currency"],
        "items": len(normalized["line_items"]),
        "timestamp": time.time()
    }))

    logger.info(f"✅ Order #{order_number} queued for fulfillment ({len(normalized['line_items'])} items, ${normalized['total_price']})")

    return {"status": "queued", "order_id": order_id, "tokenized": True}


@app.post("/webhooks/cjdropshipping")
async def handle_cj_webhook(request: Request):
    """
    Receives CJ Dropshipping order status / tracking webhooks.
    """
    try:
        body_bytes = await request.body()
        if not body_bytes:
            return {"status": "ignored", "reason": "empty_body"}
            
        data = json.loads(body_bytes)
    except json.JSONDecodeError:
        logger.warning(f"🚫 Invalid JSON from CJ Webhook")
        raise HTTPException(status_code=400, detail="Invalid JSON")

    # CJ typically sends order tracking / status updates
    order_id = data.get("orderId", "") or data.get("cjOrderId", "")
    status = data.get("status", "")
    tracking = data.get("trackingNumber", "")
    
    if not order_id:
        logger.info(f"⏭️ Skipping CJ webhook, no order ID found in payload.")
        return {"status": "skipped", "reason": "no_order_id"}

    logger.info(f"🚚 CJ Webhook received: Order {order_id} | Status: {status} | Tracking: {tracking}")

    # Push to Redis for the fulfillment engine to process (e.g. notify Shopify)
    r = get_redis()
    
    payload = {
        "order_id": order_id,
        "status": status,
        "tracking_number": tracking,
        "raw_data": data,
        "received_at": time.time(),
        "source": "cjdropshipping_webhook"
    }
    
    r.rpush("kernell:FULFILL:cjdropshipping:tracking", json.dumps(payload))
    
    # Publish event
    r.publish("kernell:events:cjdropshipping_update", json.dumps({
        "order_id": order_id,
        "status": status,
        "tracking": tracking,
        "timestamp": time.time()
    }))

    return {"code": 200, "message": "success"}


@app.post("/webhooks/shopify/customer/inquiry")
async def handle_customer_inquiry(request: Request):
    """D-06: encola mensajes de soporte para CustomerServiceBot."""
    body = await request.body()
    try:
        data = json.loads(body) if body else {}
    except json.JSONDecodeError:
        raise HTTPException(status_code=400, detail="Invalid JSON")
    r = get_redis()
    ticket = {
        "customer_email": data.get("email", "") or data.get("customer_email", ""),
        "order_id": str(data.get("order_id", "") or ""),
        "subject": data.get("subject", "Customer inquiry"),
        "message": data.get("body", "") or data.get("message", ""),
        "source": "shopify_webhook_inquiry",
    }
    r.rpush("SUPPORT:tickets:incoming", json.dumps(ticket))
    return {"status": "queued"}


@app.get("/live")
async def live():
    """Liveness: proceso arriba (load balancers / orchestrators)."""
    return {"status": "alive", "service": "kernell-shopify-webhook"}


@app.get("/ready")
async def ready():
    """Readiness: Redis alcanzable; 503 si no (retira tráfico sin matar el proceso)."""
    try:
        r = get_redis()
        r.ping()
        pending = int(r.llen("kernell:FULFILL:orders:pending") or 0)
        return JSONResponse(
            {
                "status": "ready",
                "redis": "connected",
                "pending_orders": pending,
                "timestamp": time.time(),
            }
        )
    except Exception as e:
        return JSONResponse(
            status_code=503,
            content={
                "status": "not_ready",
                "redis": str(e),
                "timestamp": time.time(),
            },
        )


@app.get("/health")
async def health():
    """Health check for systemd/monitoring (siempre HTTP 200; ver campo status)."""
    try:
        r = get_redis()
        r.ping()
        pending = r.llen("kernell:FULFILL:orders:pending") or 0
        return {
            "status": "healthy",
            "redis": "connected",
            "pending_orders": pending,
            "timestamp": time.time()
        }
    except Exception as e:
        return {"status": "degraded", "redis": str(e)}
