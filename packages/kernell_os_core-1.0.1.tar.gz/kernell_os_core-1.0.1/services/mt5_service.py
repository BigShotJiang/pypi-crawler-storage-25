#!/usr/bin/env python3
"""
MT5 Service Manager — Kernell OS
==================================
Manages the Wine-based MT5 Terminal and REST JSON bridge lifecycle.

Architecture:
  Wine MT5 Terminal → mt5_rest_server.py (Flask, single-threaded)
  → HTTP JSON POST → MT5Engine (native Linux) → Nemesis/MCP

Responsibilities:
  1. Start MT5 Terminal under Wine (headless via Xvfb if no display)
  2. Start REST JSON server (wine python mt5_rest_server.py)
  3. Health monitoring with auto-restart (HTTP ping)
  4. Clean shutdown

Usage:
    python3 services/mt5_service.py start    # Start MT5 + REST bridge
    python3 services/mt5_service.py stop     # Stop everything
    python3 services/mt5_service.py status   # Check if running
    python3 services/mt5_service.py restart  # Restart everything

Environment Variables:
    WINEPREFIX          - Wine prefix (default: /home/anny/.wine_mt5)
    MT5_REST_HOST       - REST server host (default: localhost)
    MT5_REST_PORT       - REST server port (default: 18812)
    MT5_TERMINAL_PATH   - Path to terminal64.exe inside Wine prefix
    DISPLAY             - X display (auto-starts Xvfb if not set)
"""

import os
import sys
import time
import signal
import subprocess
import logging
import json
import urllib.request
import urllib.error
from pathlib import Path

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [MT5_SVC] %(levelname)s %(message)s",
)
logger = logging.getLogger("mt5_service")

# ── Configuration ─────────────────────────────────────────────────────
WINEPREFIX = os.getenv("WINEPREFIX", "/home/anny/.wine_mt5")
REST_HOST = os.getenv("MT5_REST_HOST", "localhost")
REST_PORT = os.getenv("MT5_REST_PORT", "18812")

# Auto-detect terminal path inside Wine prefix
TERMINAL_PATH = os.getenv("MT5_TERMINAL_PATH", "")
if not TERMINAL_PATH:
    # Common install locations
    _candidates = [
        f"{WINEPREFIX}/drive_c/Program Files/MetaTrader 5/terminal64.exe",
        f"{WINEPREFIX}/drive_c/Program Files (x86)/MetaTrader 5/terminal64.exe",
    ]
    # Also search for broker-named installs
    pf = Path(f"{WINEPREFIX}/drive_c/Program Files")
    if pf.exists():
        for d in pf.iterdir():
            if d.is_dir() and "metatrader" in d.name.lower():
                _candidates.append(str(d / "terminal64.exe"))
    for c in _candidates:
        if Path(c).exists():
            TERMINAL_PATH = c
            break

# Wine Python path (for REST bridge server)
WINE_PYTHON = os.getenv("MT5_WINE_PYTHON", "")
if not WINE_PYTHON:
    _py_candidates = [
        f"{WINEPREFIX}/drive_c/Python311/python.exe",
        f"{WINEPREFIX}/drive_c/Python310/python.exe",
        f"{WINEPREFIX}/drive_c/Python39/python.exe",
    ]
    # Also check AppData paths
    _appdata = f"{WINEPREFIX}/drive_c/users"
    if Path(_appdata).exists():
        for user_dir in Path(_appdata).iterdir():
            for ver in ["311", "310", "39", "312"]:
                p1 = user_dir / f"AppData/Local/Programs/Python/Python{ver}/python.exe"
                p2 = user_dir / f"Local Settings/Application Data/Programs/Python/Python{ver}/python.exe"
                if p1.exists(): _py_candidates.insert(0, str(p1))
                if p2.exists(): _py_candidates.insert(0, str(p2))
    for c in _py_candidates:
        if Path(c).exists():
            WINE_PYTHON = c
            break

PID_DIR = Path("/tmp/kernell_mt5")
PID_DIR.mkdir(exist_ok=True)

MT5_PID_FILE = PID_DIR / "mt5_terminal.pid"
REST_PID_FILE = PID_DIR / "rest_server.pid"
XVFB_PID_FILE = PID_DIR / "xvfb.pid"


class MT5ServiceManager:
    """Manages MT5 Terminal + REST JSON bridge lifecycle."""

    def __init__(self):
        self._mt5_proc = None
        self._rest_proc = None
        self._xvfb_proc = None

    def start(self):
        """Start MT5 Terminal and REST JSON bridge."""
        logger.info("=" * 60)
        logger.info("Starting MT5 Service Stack...")
        logger.info(f"  WINEPREFIX:    {WINEPREFIX}")
        logger.info(f"  TERMINAL:      {TERMINAL_PATH or 'NOT FOUND'}")
        logger.info(f"  Proxy Bridge:  {REST_HOST}:{REST_PORT} (Native)")
        logger.info("=" * 60)

        # Validate
        if not Path(WINEPREFIX).exists():
            logger.error(f"Wine prefix not found: {WINEPREFIX}")
            logger.info("Run setup first: WINEPREFIX=/home/anny/.wine_mt5 WINEARCH=win64 wineboot --init")
            return False

        if not TERMINAL_PATH or not Path(TERMINAL_PATH).exists():
            logger.error(f"MT5 terminal not found: {TERMINAL_PATH}")
            logger.info("Install MT5 in Wine: wine mt5setup.exe")
            return False



        # 1. Start Xvfb if no display
        if not os.getenv("DISPLAY"):
            self._start_xvfb()

        # 2. Start MT5 Terminal
        self._start_mt5_terminal()
        time.sleep(10)  # Give terminal time to initialize in Wine

        # 3. Start REST JSON bridge
        self._start_rest_server()

        # 4. Poll for bridge readiness (up to 120s)
        # With deferred MT5 init, Flask binds port immediately;
        # but full MT5 readiness may take 60-90s under Wine.
        bridge_up = False
        for _poll in range(24):  # 24 × 5s = 120s max
            time.sleep(5)
            if self._check_rest_alive():
                bridge_up = True
                break
            # Even a /api/ping response (Flask alive, MT5 degraded) counts
            try:
                url = f"http://{REST_HOST}:{REST_PORT}/api/ping"
                req = urllib.request.Request(url, method="GET")
                with urllib.request.urlopen(req, timeout=5) as resp:
                    if resp.status == 200:
                        logger.info(f"Flask alive (MT5 may still be initializing) — poll {_poll + 1}/24")
                        # Give MT5 more time if Flask is up but MT5 not ready
                        continue
            except Exception:
                logger.debug(f"Bridge not yet responding — poll {_poll + 1}/24")

        if bridge_up:
            logger.info("✅ MT5 Service Stack fully operational (REST JSON)")
            self._write_status("RUNNING")
            return True
        else:
            # Check if Flask is at least alive (degraded mode is acceptable)
            try:
                url = f"http://{REST_HOST}:{REST_PORT}/api/ping"
                req = urllib.request.Request(url, method="GET")
                with urllib.request.urlopen(req, timeout=5) as resp:
                    if resp.status == 200:
                        logger.warning("⚠️ MT5 Service Stack running in DEGRADED mode (Flask up, MT5 not ready)")
                        self._write_status("DEGRADED")
                        return True  # Don't crash — let health checks handle recovery
            except Exception:
                pass
            logger.error("❌ REST bridge not responding after 120s startup window")
            return False

    def _start_xvfb(self):
        """Start virtual X display for headless operation."""
        display = ":100"
        
        # Clear locks from previous runs to prevent Xvfb crash/zombie
        try:
            lock = Path(f"/tmp/.X{display.strip(':')}-lock")
            unix_sock = Path(f"/tmp/.X11-unix/X{display.strip(':')}")
            if lock.exists(): lock.unlink()
            if unix_sock.exists(): unix_sock.unlink()
        except Exception as e:
            logger.warning(f"Failed to clear Xvfb locks: {e}")

        try:
            self._xvfb_proc = subprocess.Popen(
                ["Xvfb", display, "-screen", "0", "1920x1080x24", "-ac"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            os.environ["DISPLAY"] = display
            XVFB_PID_FILE.write_text(str(self._xvfb_proc.pid))
            logger.info(f"Xvfb started on {display} (PID: {self._xvfb_proc.pid})")
            
            # Start x11vnc for the 24/7 reality show broadcast
            time.sleep(1) # wait for Xvfb to be ready
            self._x11vnc_proc = subprocess.Popen(
                ["x11vnc", "-display", display, "-rfbport", "5900", "-forever", "-shared", "-nopw", "-bg"],
                stdout=open(PID_DIR / "x11vnc.log", "w"),
                stderr=subprocess.STDOUT,
            )
            logger.info("x11vnc broadcast server started on port 5900 (NoVNC reality show)")
            
        except FileNotFoundError:
            logger.warning("Xvfb or x11vnc not installed — trying with existing DISPLAY")

    def _start_mt5_terminal(self):
        """Start MT5 Terminal under Wine with AutoTrading forced ON."""
        env = os.environ.copy()
        env["WINEPREFIX"] = WINEPREFIX

        # Ensure startup.ini exists with AutoTrading=1
        terminal_dir = Path(TERMINAL_PATH).parent
        startup_ini = terminal_dir / "startup.ini"
        mt5_login = os.environ.get("MT5_LOGIN", "198270315")
        mt5_password = os.environ.get("MT5_PASSWORD", "Andreitas.1744")
        mt5_server = os.environ.get("MT5_SERVER", "Exness-MT5Trial11")
        mt5_symbol = os.environ.get("MT5_CHART_SYMBOL", "EURUSDm")
        mt5_period = os.environ.get("MT5_CHART_PERIOD", "M15")
        startup_ini_content = f"""[Common]
Login={mt5_login}
Password={mt5_password}
Server={mt5_server}
AutoTrading=1

[Experts]
AllowDllImport=1
Enabled=1
WebRequest=1
WebRequestUrl=http://127.0.0.1:18812

[Charts]
Symbol={mt5_symbol}
Period={mt5_period}
Expert=NemesisBridge
"""
        try:
            startup_ini.write_text(startup_ini_content)
            logger.info(f"Wrote {startup_ini} with AutoTrading=1 and Chart Expert")
        except Exception as e:
            logger.warning(f"Could not write startup.ini: {e}")

        self._mt5_proc = subprocess.Popen(
            [
                "wine", TERMINAL_PATH,
                "/portable",
                "/algotrading",
                f"/config:{startup_ini}",
                "/profile:Default",
            ],
            env=env,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        MT5_PID_FILE.write_text(str(self._mt5_proc.pid))
        logger.info(f"MT5 Terminal started (PID: {self._mt5_proc.pid})")

    def _start_rest_server(self):
        """Start the FastAPI Proxy Bridge natively (no Wine)."""
        env = os.environ.copy()
        logger.info(f"Starting MT5 Proxy Server on port {REST_PORT} (Native Linux)...")
        proxy_script = os.path.abspath(os.path.join(os.path.dirname(__file__), "mt5_proxy_server.py"))
        
        rest_log = open(PID_DIR / "proxy_server.log", "w")
        self._rest_proc = subprocess.Popen(
            [
                sys.executable,
                proxy_script
            ],
            env=env,
            stdout=rest_log,
            stderr=subprocess.STDOUT,
        )
        REST_PID_FILE.write_text(str(self._rest_proc.pid))
        logger.info(f"Native Proxy started (PID: {self._rest_proc.pid})")

    def _check_rest_alive(self) -> bool:
        """Check if REST JSON bridge AND MT5 are responsive via /api/health."""
        try:
            url = f"http://{REST_HOST}:{REST_PORT}/api/health"
            req = urllib.request.Request(url, method="GET")
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read().decode())
                status = data.get("status", "unknown")
                if status == "degraded":
                    logger.warning(f"MT5 health: DEGRADED — {data.get('error', 'unknown')}")
                    return False
                return status in ("ok", "partial")
        except urllib.error.HTTPError as e:
            if e.code == 503:  # degraded
                logger.warning("MT5 health: 503 DEGRADED")
                return False
            return False
        except Exception:
            return False

    def stop(self):
        """Stop all services."""
        logger.info("Stopping MT5 Service Stack...")

        for pid_file, name in [
            (REST_PID_FILE, "REST Bridge"),
            (MT5_PID_FILE, "MT5 Terminal"),
            (XVFB_PID_FILE, "Xvfb"),
        ]:
            if pid_file.exists():
                try:
                    pid = int(pid_file.read_text().strip())
                    os.kill(pid, signal.SIGTERM)
                    logger.info(f"  Stopped {name} (PID: {pid})")
                except (ProcessLookupError, ValueError):
                    pass
                pid_file.unlink(missing_ok=True)
                
        # Also clean up any loose x11vnc instances
        try:
            subprocess.run(["pkill", "-f", "x11vnc -display"], check=False)
        except Exception:
            pass

        # Also kill any wine processes in our prefix
        try:
            subprocess.run(
                ["wineserver", "-k"],
                env={**os.environ, "WINEPREFIX": WINEPREFIX},
                timeout=10,
            )
        except Exception:
            pass

        self._write_status("STOPPED")
        logger.info("MT5 Service Stack stopped")

    def status(self) -> dict:
        """Check current status."""
        result = {
            "mt5_terminal": self._check_pid(MT5_PID_FILE),
            "rest_server": self._check_pid(REST_PID_FILE),
            "rest_alive": self._check_rest_alive(),
            "xvfb": self._check_pid(XVFB_PID_FILE),
            "wineprefix": WINEPREFIX,
            "terminal_path": TERMINAL_PATH,
        }
        return result

    def restart(self):
        """Restart all services."""
        self.stop()
        time.sleep(2)
        return self.start()

    @staticmethod
    def _check_pid(pid_file: Path) -> bool:
        if not pid_file.exists():
            return False
        try:
            pid = int(pid_file.read_text().strip())
            os.kill(pid, 0)  # Check if process exists
            return True
        except (ProcessLookupError, ValueError):
            return False

    @staticmethod
    def _write_status(status: str):
        try:
            (PID_DIR / "status.json").write_text(json.dumps({
                "status": status,
                "ts": time.time(),
                "rest_port": REST_PORT,
            }))
        except Exception:
            pass


def main():
    if len(sys.argv) < 2:
        print("Usage: mt5_service.py [start|stop|status|restart]")
        sys.exit(1)

    mgr = MT5ServiceManager()
    cmd = sys.argv[1].lower()

    if cmd == "start":
        success = mgr.start()
        if success:
            # Keep running for health monitoring
            try:
                _consecutive_fails = 0
                while True:
                    time.sleep(30)
                    if not mgr._check_rest_alive():
                        _consecutive_fails += 1
                        logger.warning(f"MT5 health check failed ({_consecutive_fails}/3)")
                        if _consecutive_fails >= 3:
                            logger.error("MT5 health failed 3x consecutively — full restart")
                            mgr.restart()
                            _consecutive_fails = 0
                    else:
                        _consecutive_fails = 0
            except KeyboardInterrupt:
                mgr.stop()
        else:
            sys.exit(1)

    elif cmd == "stop":
        mgr.stop()

    elif cmd == "status":
        s = mgr.status()
        print(json.dumps(s, indent=2))

    elif cmd == "restart":
        mgr.restart()

    else:
        print(f"Unknown command: {cmd}")
        sys.exit(1)


if __name__ == "__main__":
    main()
