#!/usr/bin/env python3
"""
Nemesis SSE / WebSocket Server — Kernell OS
===========================================
Servidor FastAPI para telemetría en tiempo real.
Lee del PubSub de Redis (generado por telemetry_stream.py)
y hace un broadcast vía Server-Sent Events (SSE) a cualquier Dashboard.

Author: Kernell OS — IA
"""

import asyncio
import json
import logging
import os
import sys
from typing import AsyncGenerator

from fastapi import FastAPI, Depends, Request
from fastapi.responses import StreamingResponse
from fastapi.middleware.cors import CORSMiddleware
import redis.asyncio as redis

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("nemesis_sse")

app = FastAPI(title="Nemesis Telemetry SSE")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

async def get_redis():
    redis_host = os.getenv("REDIS_HOST", "127.0.0.1").strip()
    redis_port = int(os.getenv("REDIS_PORT", 6380))
    redis_pass = os.getenv("REDIS_PASSWORD", "").strip() or None
    
    r = redis.Redis(
        host=redis_host,
        port=redis_port,
        password=redis_pass,
        decode_responses=True
    )
    try:
        yield r
    finally:
        await r.aclose()


async def event_generator(r: redis.Redis, request: Request, symbol: str) -> AsyncGenerator[str, None]:
    """Generador asincrónico para Server-Sent Events."""
    pubsub = r.pubsub()
    channel = f"kernell:nemesis:live_chart:{symbol}"
    await pubsub.subscribe(channel)
    
    logger.info(f"Client subscribed to {channel}")
    
    # 1. Empujar el último estado inmediato (si existe) para que no espere al primer tick
    try:
        last_state = await r.get(f"kernell:telemetry:latest:{symbol}")
        if last_state:
            yield f"data: {last_state}\n\n"
    except Exception as e:
        logger.warning(f"No last state for {symbol}: {e}")

    # 2. Escuchar en tiempo real
    try:
        async for message in pubsub.listen():
            if await request.is_disconnected():
                logger.info("Client disconnected")
                break
                
            if message["type"] == "message":
                data = message["data"]
                yield f"data: {data}\n\n"
    finally:
        await pubsub.unsubscribe(channel)
        await pubsub.close()

@app.get("/telemetry/stream/{symbol}")
async def stream_telemetry(symbol: str, request: Request, r: redis.Redis = Depends(get_redis)):
    """
    Endpoint SSE: Conéctate con `new EventSource('/telemetry/stream/EURUSDm')`
    """
    return StreamingResponse(
        event_generator(r, request, symbol),
        media_type="text/event-stream"
    )

@app.get("/telemetry/latest/{symbol}")
async def get_latest(symbol: str, r: redis.Redis = Depends(get_redis)):
    """
    Endpoint HTTP normal para obtener el snapshot.
    """
    data = await r.get(f"kernell:telemetry:latest:{symbol}")
    if data:
        return json.loads(data)
    return {"error": "No telemetry data yet"}


async def decision_tree_generator(
    r: redis.Redis, request: Request, symbol: str
) -> AsyncGenerator[str, None]:
    pubsub = r.pubsub()
    channel = f"kernell:nemesis:decision_tree:{symbol}"
    await pubsub.subscribe(channel)
    logger.info("Client subscribed to %s", channel)
    try:
        last_state = await r.get(f"kernell:nemesis:decision_tree:latest:{symbol}")
        if last_state:
            yield f"data: {last_state}\n\n"
        async for message in pubsub.listen():
            if await request.is_disconnected():
                break
            if message["type"] == "message":
                yield f"data: {message['data']}\n\n"
    finally:
        await pubsub.unsubscribe(channel)
        await pubsub.close()


@app.get("/telemetry/decision-tree/latest")
async def decision_tree_latest_global(r: redis.Redis = Depends(get_redis)):
    data = await r.get("kernell:nemesis:decision_tree:latest")
    if data:
        return json.loads(data)
    return {"error": "No decision tree yet"}


@app.get("/telemetry/decision-tree/latest/{symbol}")
async def decision_tree_latest_symbol(symbol: str, r: redis.Redis = Depends(get_redis)):
    data = await r.get(f"kernell:nemesis:decision_tree:latest:{symbol}")
    if data:
        return json.loads(data)
    return {"error": "No decision tree for symbol"}


@app.get("/telemetry/decision-tree/stream/{symbol}")
async def stream_decision_tree(
    symbol: str, request: Request, r: redis.Redis = Depends(get_redis)
):
    """SSE — árbol de decisión Nemesis (thinking aloud)."""
    return StreamingResponse(
        decision_tree_generator(r, request, symbol),
        media_type="text/event-stream",
    )


if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("TELEMETRY_PORT", 18813))
    logger.info(f"Starting SSE Server on port {port}")
    uvicorn.run(app, host="0.0.0.0", port=port)
