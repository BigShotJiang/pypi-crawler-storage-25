"""
MT5 Native Proxy Server — Kernell OS
======================================
Replaces the old Wine Flask bridge. 
Acts as a high-speed memory state holder between Nemesis and the MQL5 EA.

Endpoints for Nemesis (matches old bridge exactly):
 - GET  /api/ping
 - GET  /api/health
 - POST /api/mt5

Endpoints for MQL5 EA:
 - POST /api/ea/state     (Push AccountBalance, Equity, Positions)
 - POST /api/ea/ticks     (Push bid/ask prices)
 - GET  /api/ea/commands  (Pull pending trades)
 - POST /api/ea/execution (Push trade results)
"""

import logging
import asyncio
import time
import json
from typing import Dict, Any, List, Optional
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
import uvicorn

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("mt5_proxy")

app = FastAPI(title="MT5 Native Proxy")

# ── In-Memory State ───────────────────────────────────────────────────
class MT5State:
    def __init__(self):
        self.account: Dict[str, Any] = {}
        self.positions: List[Dict[str, Any]] = []
        self.orders: List[Dict[str, Any]] = []
        self.ticks: Dict[str, Dict[str, Any]] = {}  # symbol -> {bid, ask, last, time}
        self.last_ea_ping = 0.0
        
        # Command Queue for EA
        self.pending_commands = []
        # Futures for resolving order_send synchronously for Nemesis
        self.command_futures = {}  # id -> asyncio.Future

state = MT5State()

# ── EA ENDPOINTS (MQL5 -> Linux) ──────────────────────────────────────

@app.post("/api/ea/state")
async def ea_state(request: Request):
    """EA pushes account state and positions here at 1-2 Hz."""
    try:
        body = await request.body()
        data = json.loads(body.decode('utf-8').rstrip('\x00'))
        state.account = data.get("account", {})
        state.positions = data.get("positions", [])
        state.orders = data.get("orders", [])
    except Exception as e:
        logger.error(f"JSON ERROR: {e} | BODY: {body}")
    state.last_ea_ping = time.time()
    return {"status": "ok"}

@app.post("/api/ea/ticks")
async def ea_ticks(request: Request):
    """EA pushes tick data here at 5-10 Hz."""
    try:
        body = await request.body()
        data = json.loads(body.decode('utf-8').rstrip('\x00'))
        ticks = data.get("ticks", [])
        for t in ticks:
            sym = t.get("symbol")
            if sym:
                state.ticks[sym] = t
    except Exception as e:
        logger.error(f"Tick JSON ERROR: {e}")
    state.last_ea_ping = time.time()
    return {"status": "ok"}

@app.get("/api/ea/commands")
async def ea_commands():
    """EA polls this at 10 Hz to get orders to execute."""
    state.last_ea_ping = time.time()
    cmds = list(state.pending_commands)
    state.pending_commands.clear()
    return {"commands": cmds}

@app.post("/api/ea/execution")
async def ea_execution(request: Request):
    """EA posts result of a command here."""
    try:
        body = await request.body()
        data = json.loads(body.decode('utf-8').rstrip('\x00'))
        cmd_id = data.get("id")
        result = data.get("result", {})
        
        if cmd_id in state.command_futures:
            fut = state.command_futures[cmd_id]
            if not fut.done():
                fut.set_result(result)
    except Exception as e:
        logger.error(f"Exec JSON ERROR: {e}")
            
    return {"status": "ok"}

# ── NEMESIS ENDPOINTS (Linux -> Linux) ────────────────────────────────

@app.get("/api/ping")
def ping():
    return {"status": "ok"}

@app.get("/api/health")
def health():
    ea_connected = (time.time() - state.last_ea_ping) < 5.0
    return {
        "status": "ok" if ea_connected else "degraded",
        "connected": ea_connected,
        "trade_expert": True
    }

@app.post("/api/mt5")
async def proxy_mt5(request: Request):
    """Emulates the old MetaTrader5 python library REST bridge."""
    data = await request.json()
    method = data.get("method")
    args = data.get("args", [])
    kwargs = data.get("kwargs", {})
    
    ea_connected = (time.time() - state.last_ea_ping) < 5.0
    if not ea_connected:
        logger.warning("MQL5 EA is disconnected. Queueing command anyway...")

    try:
        res = await handle_mt5_call(method, args, kwargs)
        return {"result": res}
    except Exception as e:
        logger.error(f"MT5 Proxy Error on {method}: {e}")
        return JSONResponse({"error": str(e)}, status_code=500)

async def handle_mt5_call(method: str, args: list, kwargs: dict) -> Any:
    """Mock the MT5 Python module responses from memory or command queue."""
    if method == "account_info":
        return state.account

    elif method == "terminal_info":
        return {"connected": True, "trade_allowed": True, "name": "MT5 Proxy"}

    elif method == "symbol_info_tick":
        sym = args[0] if args else kwargs.get("symbol")
        return state.ticks.get(sym, None)

    elif method == "positions_get":
        sym = kwargs.get("symbol")
        if sym:
            return [p for p in state.positions if p.get("symbol") == sym]
        return state.positions

    elif method == "orders_get":
        sym = kwargs.get("symbol")
        if sym:
            return [o for o in state.orders if o.get("symbol") == sym]
        return state.orders

    elif method == "order_send":
        # Requires blocking execution via the EA
        request_obj = args[0] if args else kwargs.get("request", {})
        cmd_id = f"cmd_{int(time.time()*1000)}"
        return await dispatch_command_to_ea("order_send", {"request": request_obj}, cmd_id)
        
    elif method == "order_check":
        request_obj = args[0] if args else kwargs.get("request", {})
        cmd_id = f"chk_{int(time.time()*1000)}"
        return await dispatch_command_to_ea("order_check", {"request": request_obj}, cmd_id)

    elif method in ("copy_rates_from_pos", "copy_rates_from", "copy_rates_range"):
        # EA normally doesn't poll gigabytes of OHLCV to save RAM.
        # But we can request it via a command if needed, or point this to ForexFactory/etc.
        cmd_id = f"ohlcv_{int(time.time()*1000)}"
        # Pass the exact arguments over
        return await dispatch_command_to_ea(method, {"args": args, "kwargs": kwargs}, cmd_id)

    elif method == "draw_graphics":
        payload_str = kwargs.get("payload", "")
        cmd_id = f"draw_{int(time.time()*1000)}"
        return await dispatch_command_to_ea("draw", payload_str, cmd_id)

    else:
        # Generic fallback to bridge
        cmd_id = f"gen_{method}_{int(time.time()*1000)}"
        return await dispatch_command_to_ea(method, {"args": args, "kwargs": kwargs}, cmd_id)

async def dispatch_command_to_ea(action: str, payload: dict, cmd_id: str, timeout: float = 8.0) -> Any:
    """Places command in queue, waits for EA to execute and post result."""
    loop = asyncio.get_event_loop()
    fut = loop.create_future()
    state.command_futures[cmd_id] = fut
    
    state.pending_commands.append({
        "id": cmd_id,
        "action": action,
        "payload": payload
    })
    
    try:
        # Wait for EA to pick it up and return result to /api/ea/execution
        result = await asyncio.wait_for(fut, timeout=timeout)
        return result
    except asyncio.TimeoutError:
        logger.error(f"Command {cmd_id} ({action}) timed out waiting for EA.")
        raise Exception(f"EA Execution Timeout ({timeout}s)")
    finally:
        state.command_futures.pop(cmd_id, None)

if __name__ == "__main__":
    uvicorn.run("mt5_proxy_server:app", host="0.0.0.0", port=18812, log_level="warning")
