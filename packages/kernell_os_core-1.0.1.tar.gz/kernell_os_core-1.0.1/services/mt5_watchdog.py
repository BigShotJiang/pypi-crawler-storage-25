"""
🐺 MT5 Live Guard Watchdog v1.0 — Kernell OS
Monitors the MT5 REST bridge health and takes corrective action.

Runs as a separate systemd service. Every 30 seconds:
  1. Pings /api/ping (Flask alive?)
  2. Checks /api/health (MT5 connected + trade_expert?)
  3. If degraded 3x in a row → restart kernell-mt5.service
  4. If down → activate NEMESIS:risk:macro_lockdown to block all trading
  5. Publishes status to Redis for dashboard/alerts

Redis Keys:
  - NEMESIS:mt5:watchdog:status   (Hash — last check results)
  - NEMESIS:mt5:watchdog:history  (List — last 50 health checks)
"""

import os
import sys
import json
import time
import logging
import subprocess
import requests
from datetime import datetime, timezone

logging.basicConfig(level=logging.INFO, format="%(asctime)s [WATCHDOG] %(message)s")
logger = logging.getLogger("MT5_WATCHDOG")

# Config
MT5_BRIDGE_URL = os.getenv("MT5_BRIDGE_URL", "http://localhost:18812")
CHECK_INTERVAL = int(os.getenv("WATCHDOG_INTERVAL", "30"))
MAX_CONSECUTIVE_FAILURES = 3
MT5_SERVICE_NAME = "kernell-mt5.service"

# Redis
REDIS_HOST = os.getenv("REDIS_HOST", "localhost")
REDIS_PORT = int(os.getenv("REDIS_PORT", "6380"))

_redis = None
def get_redis():
    global _redis
    if _redis is None:
        try:
            import redis
            pwd = os.getenv("REDIS_PASSWORD", "")
            _redis = redis.Redis(host=REDIS_HOST, port=REDIS_PORT,
                                 password=pwd or None, decode_responses=True)
            _redis.ping()
        except Exception as e:
            logger.warning(f"Redis unavailable: {e}")
            _redis = None
    return _redis


def check_ping() -> bool:
    """Check if Flask process is alive."""
    try:
        r = requests.get(f"{MT5_BRIDGE_URL}/api/ping", timeout=5)
        return r.status_code == 200
    except Exception:
        return False


def check_health() -> dict:
    """Full MT5 readiness check."""
    try:
        r = requests.get(f"{MT5_BRIDGE_URL}/api/health", timeout=10)
        data = r.json()
        data["http_code"] = r.status_code
        return data
    except Exception as e:
        return {"status": "dead", "error": str(e), "http_code": 0}


def restart_mt5_service():
    """Attempt to restart the MT5 systemd service."""
    logger.warning(f"🔄 Restarting {MT5_SERVICE_NAME}...")
    try:
        result = subprocess.run(
            ["sudo", "systemctl", "restart", MT5_SERVICE_NAME],
            capture_output=True, text=True, timeout=30
        )
        if result.returncode == 0:
            logger.info(f"✅ {MT5_SERVICE_NAME} restart initiated")
            return True
        else:
            logger.error(f"❌ Restart failed: {result.stderr}")
            return False
    except Exception as e:
        logger.error(f"❌ Restart exception: {e}")
        return False


def set_trading_lockdown(active: bool, reason: str = ""):
    """Block or unblock all Nemesis trading via Redis flag."""
    r = get_redis()
    if not r:
        return
    if active:
        r.set("NEMESIS:risk:mt5_bridge_down", "ACTIVE")
        logger.critical(f"�� Trading LOCKED: {reason}")
        r.publish("kernell:alerts:critical", json.dumps({
            "source": "mt5_watchdog",
            "event": "MT5_BRIDGE_DOWN",
            "reason": reason,
            "timestamp": time.time()
        }))
    else:
        r.delete("NEMESIS:risk:mt5_bridge_down")
        logger.info("🔓 Trading UNLOCKED: MT5 bridge recovered")


def update_redis_status(health: dict, consecutive_fails: int):
    """Push status to Redis for dashboard."""
    r = get_redis()
    if not r:
        return
    status = {
        "last_check": datetime.now(timezone.utc).isoformat(),
        "bridge_status": health.get("status", "unknown"),
        "connected": str(health.get("connected", False)),
        "trade_expert": str(health.get("trade_expert", False)),
        "balance": str(health.get("balance", 0)),
        "consecutive_failures": str(consecutive_fails),
        "http_code": str(health.get("http_code", 0))
    }
    r.hset("NEMESIS:mt5:watchdog:status", mapping=status)
    # Keep last 50 entries
    r.lpush("NEMESIS:mt5:watchdog:history", json.dumps(status))
    r.ltrim("NEMESIS:mt5:watchdog:history", 0, 49)



def main():
    logger.info(f"🐺 MT5 Watchdog started. Monitoring {MT5_BRIDGE_URL} every {CHECK_INTERVAL}s")
    consecutive_fails = 0
    was_locked = False

    while True:
        # Step 1: Ping Wine bridge
        alive = check_ping()
        if not alive:
            consecutive_fails += 1
            health = {"status": "dead", "http_code": 0}
            logger.warning(f"💀 Bridge unreachable ({consecutive_fails}/{MAX_CONSECUTIVE_FAILURES})")
        else:
            # Step 2: Full health
            health = check_health()
            status = health.get("status", "unknown")

            if status == "ok":
                if consecutive_fails > 0:
                    logger.info(f"✅ Bridge recovered after {consecutive_fails} failures")
                consecutive_fails = 0
                if was_locked:
                    set_trading_lockdown(False)
                    was_locked = False
            elif status in ("degraded", "partial"):
                consecutive_fails += 1
                logger.warning(
                    f"⚠️ Bridge degraded: connected={health.get('connected')} "
                    f"trade_expert={health.get('trade_expert')} "
                    f"({consecutive_fails}/{MAX_CONSECUTIVE_FAILURES})"
                )
            else:
                consecutive_fails += 1

        # Step 3: Take action on sustained failure
        if consecutive_fails >= MAX_CONSECUTIVE_FAILURES:
            if not was_locked:
                set_trading_lockdown(True, f"Bridge failed {consecutive_fails}x consecutively")
                was_locked = True

            # Try restart every 3rd failure
            if consecutive_fails % 3 == 0:
                restart_mt5_service()
                time.sleep(15)  # Give it time to boot

        update_redis_status(health, consecutive_fails)
        time.sleep(CHECK_INTERVAL)


if __name__ == "__main__":
    main()

