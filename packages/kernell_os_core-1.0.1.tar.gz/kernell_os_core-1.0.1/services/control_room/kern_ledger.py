"""
💰 KernellNet Off-Chain KERN Ledger
====================================
Internal balance tracking system for $KERN transactions.

Philosophy:
  - ALL internal micro-transactions (tool calls, messages, signals) happen INSTANTLY off-chain
  - Blockchain settlement happens in BATCH every N minutes or when threshold is reached
  - This is the same model as Binance/Coinbase internal transfers: instant, free, auditable
  - On-chain settlement is for: withdrawals, cross-system transfers, and periodic anchoring

Security:
  - Double-entry bookkeeping: every debit has a matching credit
  - Merkle-root anchoring of batch to blockchain (when settlement runs)
  - Overdraft protection: agents cannot spend more than their balance
  - Burn guard: prevents burning tokens without explicit authorization
  - All entries are append-only with SHA-256 chain integrity

Redis Keys:
  kernell:kern:balance:{entity_id}        — Current off-chain balance (HASH)
  kernell:kern:ledger:{entity_id}         — Transaction history (LIST, ring buffer)
  kernell:kern:settlement:pending         — Pending settlements for batch (LIST)
  kernell:kern:settlement:last            — Last settlement metadata (HASH)
  kernell:kern:burn:authorized            — SET of authorized burn request IDs
"""

from __future__ import annotations

import hashlib
import json
import logging
import time
import uuid
from dataclasses import dataclass, asdict
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple
from datetime import datetime, timezone

logger = logging.getLogger("kernellnet.kern_ledger")


class TxType(str, Enum):
    CREDIT = "credit"           # Funds added (deposit, reward)
    DEBIT = "debit"             # Funds spent (tool call, service)
    TRANSFER = "transfer"       # Agent-to-agent transfer
    BURN = "burn"               # Permanent token destruction
    SETTLEMENT = "settlement"   # Batch on-chain settlement
    REFUND = "refund"           # Reversed transaction


class TxStatus(str, Enum):
    CONFIRMED = "confirmed"     # Instant off-chain confirmation
    PENDING_SETTLEMENT = "pending_settlement"  # Awaiting batch
    SETTLED = "settled"         # On-chain confirmed
    FAILED = "failed"           # Rejected (insufficient balance, etc.)
    REVERSED = "reversed"       # Refunded


# ── Redis Keys ──────────────────────────────────────────────────
BALANCE_KEY = "kernell:kern:balance:{entity_id}"
LEDGER_KEY = "kernell:kern:ledger:{entity_id}"
PENDING_SETTLEMENT = "kernell:kern:settlement:pending"
LAST_SETTLEMENT = "kernell:kern:settlement:last"
BURN_AUTH_SET = "kernell:kern:burn:authorized"
GLOBAL_STATS = "kernell:kern:stats"
MAX_LEDGER_ENTRIES = 2000


@dataclass
class KernTransaction:
    tx_id: str
    tx_type: str
    from_entity: str
    to_entity: str
    amount: float
    description: str
    tool_name: Optional[str] = None
    status: str = "confirmed"
    ts: float = 0.0
    prev_hash: str = ""
    tx_hash: str = ""

    def compute_hash(self) -> str:
        raw = json.dumps({
            "tx_id": self.tx_id,
            "tx_type": self.tx_type,
            "from": self.from_entity,
            "to": self.to_entity,
            "amount": self.amount,
            "ts": self.ts,
            "prev_hash": self.prev_hash,
        }, sort_keys=True)
        return hashlib.sha256(raw.encode()).hexdigest()


def _balance_key(entity_id: str) -> str:
    return BALANCE_KEY.replace("{entity_id}", entity_id)


def _ledger_key(entity_id: str) -> str:
    return LEDGER_KEY.replace("{entity_id}", entity_id)


# ── Balance Operations ──────────────────────────────────────────

def get_balance(redis_client: Any, entity_id: str) -> float:
    """Get current off-chain KERN balance for an entity."""
    bal = redis_client.hget(_balance_key(entity_id), "balance")
    if bal is None:
        return 0.0
    return float(bal)


def set_initial_balance(redis_client: Any, entity_id: str, amount: float) -> None:
    """Set initial balance for a new entity (admin only)."""
    redis_client.hset(_balance_key(entity_id), mapping={
        "balance": str(amount),
        "total_credited": str(amount),
        "total_debited": "0",
        "total_burned": "0",
        "tx_count": "0",
        "created_ts": str(time.time()),
        "last_tx_ts": str(time.time()),
    })


def _update_balance(redis_client: Any, entity_id: str, delta: float, field: str) -> float:
    """Atomically update balance. Returns new balance."""
    pipe = redis_client.pipeline()
    pipe.hincrbyfloat(_balance_key(entity_id), "balance", delta)
    pipe.hincrbyfloat(_balance_key(entity_id), field, abs(delta))
    pipe.hincrby(_balance_key(entity_id), "tx_count", 1)
    pipe.hset(_balance_key(entity_id), "last_tx_ts", str(time.time()))
    results = pipe.execute()
    return float(results[0])


def _get_last_hash(redis_client: Any, entity_id: str) -> str:
    """Get the hash of the last transaction for chain integrity."""
    last = redis_client.lindex(_ledger_key(entity_id), 0)
    if last:
        try:
            return json.loads(last).get("tx_hash", "genesis")
        except (json.JSONDecodeError, TypeError):
            pass
    return "genesis"


def _record_tx(redis_client: Any, tx: KernTransaction) -> None:
    """Append transaction to entity ledger (ring buffer)."""
    # Record for sender
    redis_client.lpush(_ledger_key(tx.from_entity), json.dumps(asdict(tx)))
    redis_client.ltrim(_ledger_key(tx.from_entity), 0, MAX_LEDGER_ENTRIES - 1)
    # Record for receiver (if different)
    if tx.to_entity and tx.to_entity != tx.from_entity:
        redis_client.lpush(_ledger_key(tx.to_entity), json.dumps(asdict(tx)))
        redis_client.ltrim(_ledger_key(tx.to_entity), 0, MAX_LEDGER_ENTRIES - 1)
    # Add to pending settlement
    redis_client.lpush(PENDING_SETTLEMENT, json.dumps(asdict(tx)))
    # Add to global public ledger list (limited to 500 for the explorer)
    redis_client.lpush("kernell:kern:ledger:GLOBAL", json.dumps(asdict(tx)))
    redis_client.ltrim("kernell:kern:ledger:GLOBAL", 0, 499)
    # Update global stats
    redis_client.hincrbyfloat(GLOBAL_STATS, "total_volume", tx.amount)
    redis_client.hincrby(GLOBAL_STATS, "total_transactions", 1)


# ── Core Transaction Functions ──────────────────────────────────

def charge_tool_call(
    redis_client: Any,
    agent_id: str,
    tool_name: str,
    cost: float,
    description: str = "",
) -> Tuple[bool, str, Optional[KernTransaction]]:
    """
    Charge an agent for a tool call. INSTANT off-chain.

    Returns: (success, message, transaction)
    """
    # Check balance
    balance = get_balance(redis_client, agent_id)
    if balance < cost:
        return False, f"insufficient_balance: {balance} < {cost}", None

    # Create transaction
    prev_hash = _get_last_hash(redis_client, agent_id)
    tx = KernTransaction(
        tx_id=f"tx_{uuid.uuid4().hex[:16]}",
        tx_type=TxType.DEBIT,
        from_entity=agent_id,
        to_entity="kernell:treasury",
        amount=cost,
        description=description or f"Tool call: {tool_name}",
        tool_name=tool_name,
        status=TxStatus.CONFIRMED,
        ts=time.time(),
        prev_hash=prev_hash,
    )
    tx.tx_hash = tx.compute_hash()

    # Execute atomically
    _update_balance(redis_client, agent_id, -cost, "total_debited")
    _update_balance(redis_client, "kernell:treasury", +cost, "total_credited")
    _record_tx(redis_client, tx)

    logger.info(f"[KERN] Charged {agent_id}: {cost} KERN for {tool_name}")
    return True, "charged", tx


def credit_entity(
    redis_client: Any,
    entity_id: str,
    amount: float,
    description: str = "deposit",
) -> Tuple[bool, str, Optional[KernTransaction]]:
    """Credit KERN to an entity (deposit, reward, etc.)."""
    prev_hash = _get_last_hash(redis_client, entity_id)
    tx = KernTransaction(
        tx_id=f"tx_{uuid.uuid4().hex[:16]}",
        tx_type=TxType.CREDIT,
        from_entity="kernell:mint",
        to_entity=entity_id,
        amount=amount,
        description=description,
        status=TxStatus.CONFIRMED,
        ts=time.time(),
        prev_hash=prev_hash,
    )
    tx.tx_hash = tx.compute_hash()

    _update_balance(redis_client, entity_id, +amount, "total_credited")
    _record_tx(redis_client, tx)

    logger.info(f"[KERN] Credited {entity_id}: +{amount} KERN ({description})")
    return True, "credited", tx


def transfer_kern(
    redis_client: Any,
    from_entity: str,
    to_entity: str,
    amount: float,
    description: str = "transfer",
) -> Tuple[bool, str, Optional[KernTransaction]]:
    """Transfer KERN between entities. Instant off-chain."""
    balance = get_balance(redis_client, from_entity)
    if balance < amount:
        return False, f"insufficient_balance: {balance} < {amount}", None

    prev_hash = _get_last_hash(redis_client, from_entity)
    tx = KernTransaction(
        tx_id=f"tx_{uuid.uuid4().hex[:16]}",
        tx_type=TxType.TRANSFER,
        from_entity=from_entity,
        to_entity=to_entity,
        amount=amount,
        description=description,
        status=TxStatus.CONFIRMED,
        ts=time.time(),
        prev_hash=prev_hash,
    )
    tx.tx_hash = tx.compute_hash()

    _update_balance(redis_client, from_entity, -amount, "total_debited")
    _update_balance(redis_client, to_entity, +amount, "total_credited")
    _record_tx(redis_client, tx)

    return True, "transferred", tx


def burn_kern(
    redis_client: Any,
    entity_id: str,
    amount: float,
    burn_request_id: str,
    reason: str = "protocol_burn",
) -> Tuple[bool, str, Optional[KernTransaction]]:
    """
    Burn KERN tokens. REQUIRES pre-authorization.

    Security: Burns must be pre-authorized by adding the burn_request_id
    to the kernell:kern:burn:authorized set. This prevents:
      - Prompt injection causing unauthorized burns
      - Accidental burns from buggy tool calls
      - Malicious agents draining funds via burn exploits
    """
    # BURN GUARD: Must be pre-authorized
    if not redis_client.sismember(BURN_AUTH_SET, burn_request_id):
        logger.warning(f"[KERN] UNAUTHORIZED BURN ATTEMPT: {entity_id} tried to burn {amount} (req={burn_request_id})")
        return False, "burn_not_authorized", None

    balance = get_balance(redis_client, entity_id)
    if balance < amount:
        return False, f"insufficient_balance: {balance} < {amount}", None

    prev_hash = _get_last_hash(redis_client, entity_id)
    tx = KernTransaction(
        tx_id=f"tx_{uuid.uuid4().hex[:16]}",
        tx_type=TxType.BURN,
        from_entity=entity_id,
        to_entity="kernell:burn_address",
        amount=amount,
        description=f"Burn: {reason} (req={burn_request_id})",
        status=TxStatus.CONFIRMED,
        ts=time.time(),
        prev_hash=prev_hash,
    )
    tx.tx_hash = tx.compute_hash()

    _update_balance(redis_client, entity_id, -amount, "total_burned")
    _record_tx(redis_client, tx)
    # Remove authorization (one-time use)
    redis_client.srem(BURN_AUTH_SET, burn_request_id)

    logger.info(f"[KERN] BURNED {amount} KERN from {entity_id}: {reason}")
    return True, "burned", tx


def authorize_burn(redis_client: Any, burn_request_id: str) -> None:
    """Pre-authorize a burn operation (operator-only action)."""
    redis_client.sadd(BURN_AUTH_SET, burn_request_id)


# ── Query Functions ─────────────────────────────────────────────

def get_transaction_history(
    redis_client: Any,
    entity_id: str,
    limit: int = 50,
    tx_type: Optional[str] = None,
) -> List[Dict]:
    """Get transaction history for an entity."""
    entries = redis_client.lrange(_ledger_key(entity_id), 0, limit * 2)
    result = []
    for raw in (entries or []):
        try:
            tx = json.loads(raw)
            if tx_type and tx.get("tx_type") != tx_type:
                continue
            result.append(tx)
            if len(result) >= limit:
                break
        except (json.JSONDecodeError, TypeError):
            continue
    return result


def get_balance_summary(redis_client: Any, entity_id: str) -> Dict:
    """Get full balance summary for an entity."""
    data = redis_client.hgetall(_balance_key(entity_id))
    if not data:
        return {"entity_id": entity_id, "balance": 0, "exists": False}
    return {
        "entity_id": entity_id,
        "balance": float(data.get("balance", 0)),
        "total_credited": float(data.get("total_credited", 0)),
        "total_debited": float(data.get("total_debited", 0)),
        "total_burned": float(data.get("total_burned", 0)),
        "tx_count": int(data.get("tx_count", 0)),
        "last_tx_ts": float(data.get("last_tx_ts", 0)),
        "exists": True,
    }


def get_global_stats(redis_client: Any) -> Dict:
    """Get global KERN economy stats."""
    data = redis_client.hgetall(GLOBAL_STATS) or {}
    pending = redis_client.llen(PENDING_SETTLEMENT)
    return {
        "total_volume": float(data.get("total_volume", 0)),
        "total_transactions": int(data.get("total_transactions", 0)),
        "pending_settlements": pending,
    }


def get_pending_settlements(redis_client: Any, limit: int = 100) -> List[Dict]:
    """Get pending transactions awaiting batch settlement."""
    entries = redis_client.lrange(PENDING_SETTLEMENT, 0, limit - 1)
    return [json.loads(e) for e in (entries or []) if e]


# ── Kernell Pay (Invoices & Agent Market) ───────────────────────

def create_invoice(redis_client: Any, from_entity: str, amount: float, description: str) -> Dict:
    """Create a pending invoice that another agent or human can pay."""
    invoice_id = f"inv_{uuid.uuid4().hex[:16]}"
    invoice_data = {
        "invoice_id": invoice_id,
        "from_entity": from_entity, 
        "amount": str(amount),
        "description": description,
        "status": "pending",
        "created_at": str(time.time())
    }
    inv_key = f"kernell:kern:invoice:{invoice_id}"
    redis_client.hset(inv_key, mapping=invoice_data)
    # Set expiration for 24 hours to avoid clutter
    redis_client.expire(inv_key, 86400)
    
    logger.info(f"[KERN PAY] Invoice created: {invoice_id} for {amount} KERN by {from_entity}")
    return invoice_data


def pay_invoice(
    redis_client: Any, invoice_id: str, payer_entity: str
) -> Tuple[bool, str, Optional[KernTransaction]]:
    """Pay an existing invoice. Instant L2 execution."""
    inv_key = f"kernell:kern:invoice:{invoice_id}"
    if not redis_client.exists(inv_key):
        return False, "invoice_not_found", None
    
    status = redis_client.hget(inv_key, "status")
    if status != "pending":
        return False, f"invoice_status_{status}", None
        
    amount = float(redis_client.hget(inv_key, "amount"))
    payee_entity = redis_client.hget(inv_key, "from_entity")
    description = redis_client.hget(inv_key, "description")
    
    if payee_entity == payer_entity:
        return False, "cannot_pay_own_invoice", None
    
    # Execute transfer to ESCROW
    ESCROW_ACCOUNT = "kernell:escrow"
    success, msg, tx = transfer_kern(
        redis_client, 
        from_entity=payer_entity, 
        to_entity=ESCROW_ACCOUNT, 
        amount=amount, 
        description=f"ESCROW deposit for invoice {invoice_id}: {description}"
    )
    
    if success:
        redis_client.hset(inv_key, mapping={
            "status": "escrowed",
            "paid_by": payer_entity,
            "escrowed_at": str(time.time()),
            "escrow_tx_hash": tx.tx_hash if tx else ""
        })
        logger.info(f"[KERN PAY] Invoice {invoice_id} paid by {payer_entity} (ESCROWED)")
        
    return success, msg, tx


def release_invoice_escrow(
    redis_client: Any, invoice_id: str
) -> Tuple[bool, str, Optional[KernTransaction]]:
    """Release funds from ESCROW to the payee entity."""
    inv_key = f"kernell:kern:invoice:{invoice_id}"
    if not redis_client.exists(inv_key):
        return False, "invoice_not_found", None
        
    status = redis_client.hget(inv_key, "status")
    if status != "escrowed":
        return False, f"invoice_not_in_escrow_status_is_{status}", None
        
    amount = float(redis_client.hget(inv_key, "amount"))
    payee_entity = redis_client.hget(inv_key, "from_entity")
    description = redis_client.hget(inv_key, "description")
    
    ESCROW_ACCOUNT = "kernell:escrow"
    success, msg, tx = transfer_kern(
        redis_client, 
        from_entity=ESCROW_ACCOUNT, 
        to_entity=payee_entity, 
        amount=amount, 
        description=f"ESCROW release for invoice {invoice_id}: {description}"
    )
    
    if success:
        redis_client.hset(inv_key, mapping={
            "status": "paid",
            "paid_at": str(time.time()),
            "tx_hash": tx.tx_hash if tx else ""
        })
        logger.info(f"[KERN PAY] Invoice {invoice_id} ESCROW RELEASED to {payee_entity}")
        
    return success, msg, tx


def batch_settle(redis_client: Any) -> Dict:
    """
    Execute batch settlement: anchor pending TXs to blockchain.
    Calls the Solana settlement agent to anchor the Merkle root natively.
    """
    pending = get_pending_settlements(redis_client, limit=1000)
    if not pending:
        return {"settled": 0, "merkle_root": None}

    # Compute Merkle root of all pending TX hashes
    hashes = [tx.get("tx_hash", "") for tx in pending]
    while len(hashes) > 1:
        if len(hashes) % 2 == 1:
            hashes.append(hashes[-1])
        new_hashes = []
        for i in range(0, len(hashes), 2):
            combined = hashes[i] + hashes[i + 1]
            new_hashes.append(hashlib.sha256(combined.encode()).hexdigest())
        hashes = new_hashes

    merkle_root = hashes[0] if hashes else "empty"

    # Record settlement properties
    settlement = {
        "merkle_root": merkle_root,
        "tx_count": len(pending),
        "total_volume": sum(float(tx.get("amount", 0)) for tx in pending),
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "burns_processed": 0, # Unused for L2 pay
        "settled_ts": time.time(),
    }
    
    # Anchor to Solana via Settlement Agent
    solana_signature = None
    try:
        from agents.finance.economy.settlement_agent import SettlementAgent
        agent = SettlementAgent()
        solana_signature = agent._anchor_merkle_onchain(merkle_root, settlement)
        settlement["solana_signature"] = solana_signature
        settlement["status"] = "anchored" if solana_signature else "local_only"
    except Exception as e:
        logger.error(f"[KERN PAY] Failed to anchor settlement to Solana: {e}")
        settlement["status"] = "anchor_failed"
        
    redis_client.hset(LAST_SETTLEMENT, mapping={k: str(v) for k, v in settlement.items()})
    redis_client.delete(PENDING_SETTLEMENT)

    logger.info(f"[KERN] Batch settled {len(pending)} TXs, merkle={merkle_root[:16]}..., status={settlement['status']}")
    return {"settled": len(pending), "merkle_root": merkle_root, **settlement}
