"""
📡 Nemesis Control Room — WebSocket Manager
=============================================
Manages live broadcast of trading data to connected investors.

Channels:
  - trades:    Real-time trade executions
  - positions: Open position updates (every 2s)
  - alerts:    System alerts and kill switch events
  - stats:     Periodic performance stats (every 5s)
"""

import json
import asyncio
import logging
from typing import Dict, List, Set
from dataclasses import dataclass, field

from fastapi import WebSocket

logger = logging.getLogger("control_room.ws")


@dataclass
class WSClient:
    """Represents a connected WebSocket client."""
    websocket: WebSocket
    pubkey: str
    tier: str
    channels: Set[str] = field(default_factory=lambda: {"stats"})


class WSManager:
    """
    Broadcast WebSocket manager for the Control Room.

    Supports channel-based subscriptions with tier gating.
    """

    # Channel → minimum tier required
    CHANNEL_TIERS: Dict[str, str] = {
        "stats": "public",
        "narration": "public",
        "trades": "analyst",
        "positions": "analyst",
        "alerts": "analyst",
        "signals": "strategist",
        "engine": "operator",
        "governance": "governor",
    }

    TIER_ORDER = ["public", "observer", "analyst", "strategist", "operator", "governor"]

    def __init__(self):
        self._clients: List[WSClient] = []
        self._lock = asyncio.Lock()

    async def connect(self, websocket: WebSocket, pubkey: str, tier: str) -> WSClient:
        """Accept a new WebSocket connection."""
        await websocket.accept()
        client = WSClient(websocket=websocket, pubkey=pubkey, tier=tier)

        # Auto-subscribe to all channels the tier allows
        tier_idx = self.TIER_ORDER.index(tier) if tier in self.TIER_ORDER else 0
        for channel, min_tier in self.CHANNEL_TIERS.items():
            min_idx = self.TIER_ORDER.index(min_tier) if min_tier in self.TIER_ORDER else 0
            if tier_idx >= min_idx:
                client.channels.add(channel)

        async with self._lock:
            self._clients.append(client)

        logger.info(
            f"🔌 WS connected: {pubkey[:12]}... | "
            f"tier={tier} | channels={client.channels}"
        )
        return client

    async def disconnect(self, client: WSClient):
        """Remove a disconnected client."""
        async with self._lock:
            if client in self._clients:
                self._clients.remove(client)
        logger.info(f"🔌 WS disconnected: {client.pubkey[:12]}...")

    async def broadcast(self, channel: str, data: dict):
        """Broadcast a message to all clients subscribed to a channel."""
        message = json.dumps({"channel": channel, "data": data, "ts": None})
        dead_clients = []

        async with self._lock:
            targets = [c for c in self._clients if channel in c.channels]

        for client in targets:
            try:
                await client.websocket.send_text(message)
            except Exception:
                dead_clients.append(client)

        # Clean dead connections
        for client in dead_clients:
            await self.disconnect(client)

    async def send_personal(self, client: WSClient, channel: str, data: dict):
        """Send a message to a single client."""
        try:
            message = json.dumps({"channel": channel, "data": data})
            await client.websocket.send_text(message)
        except Exception:
            await self.disconnect(client)

    @property
    def connected_count(self) -> int:
        return len(self._clients)

    def get_stats(self) -> dict:
        """Connection statistics for monitoring."""
        tier_counts: Dict[str, int] = {}
        for c in self._clients:
            tier_counts[c.tier] = tier_counts.get(c.tier, 0) + 1
        return {
            "total_connections": len(self._clients),
            "by_tier": tier_counts,
        }
