"""
🌐 KernellNet Gateway — External Agent Registry
==================================================
Handles registration, verification, and lifecycle of external agents
connecting to Kernell OS via the KAP Agent Card protocol.

Security model:
  1. Agent submits Agent Card + Ed25519 signature
  2. Gateway verifies signature against card's public key
  3. Agent receives a scoped JWT with tier based on $KERN staked
  4. All actions are audited in the economic ledger
  5. Human operator can revoke any agent from mobile app

Registry keys (Redis):
  kernell:registry:agents:{agent_id}  — HASH with card, tier, status, ts
  kernell:registry:agents:index       — SET of all registered agent_ids
  kernell:registry:revoked            — SET of revoked agent_ids
"""

from __future__ import annotations

import hashlib
import json
import logging
import time
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger("control_room.agent_registry")

# ── Redis Key Patterns ──────────────────────────────────────────
REGISTRY_PREFIX = "kernell:registry:agents"
REGISTRY_INDEX = f"{REGISTRY_PREFIX}:index"
REVOKED_SET = "kernell:registry:revoked"

# ── Sandbox Permission Tiers ────────────────────────────────────
# What each tier of external agent is allowed to do
EXTERNAL_AGENT_PERMISSIONS = {
    "public": {
        "mcp_tools": [],
        "max_requests_per_hour": 10,
        "can_transact": False,
        "can_read_positions": False,
        "can_read_trades": False,
    },
    "observer": {
        "mcp_tools": [
            "search_codebase", "get_architecture",
            "get_agent_status", "send_message",
        ],
        "max_requests_per_hour": 60,
        "can_transact": False,
        "can_read_positions": False,
        "can_read_trades": True,
    },
    "analyst": {
        "mcp_tools": [
            "search_codebase", "get_architecture",
            "get_agent_status", "send_message",
            "query_redis_readonly", "read_economic_ledger",
        ],
        "max_requests_per_hour": 200,
        "can_transact": False,
        "can_read_positions": True,
        "can_read_trades": True,
    },
    "strategist": {
        "mcp_tools": [
            "search_codebase", "get_architecture",
            "get_agent_status", "send_message",
            "query_redis_readonly", "read_economic_ledger",
            "submit_signal",
        ],
        "max_requests_per_hour": 500,
        "can_transact": True,
        "can_read_positions": True,
        "can_read_trades": True,
    },
}


@dataclass
class ExternalAgentCard:
    """
    KAP-compatible Agent Card for external agent identification.
    Follows the A2A Agent Card spec with Kernell extensions.
    """
    name: str
    url: str
    description: str = ""
    capabilities: List[str] = field(default_factory=list)
    version: str = "1.0"
    framework: str = "kernell"  # e.g. "kernell", "custom"
    owner_pubkey: str = ""      # Solana pubkey of the human owner

    @property
    def agent_id(self) -> str:
        """Deterministic agent ID: SHA256(name::url)[:16]."""
        raw = f"{self.name}::{self.url}".encode("utf-8")
        return hashlib.sha256(raw).hexdigest()[:16]

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["agent_id"] = self.agent_id
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ExternalAgentCard":
        known = {"name", "url", "description", "capabilities", "version", "framework", "owner_pubkey"}
        filtered = {k: v for k, v in data.items() if k in known}
        return cls(**filtered)


def _agent_key(agent_id: str) -> str:
    return f"{REGISTRY_PREFIX}:{agent_id}"


def register_agent(
    redis_client: Any,
    card: ExternalAgentCard,
    *,
    signature_b58: str = "",
    tier: str = "public",
) -> Tuple[bool, str, Optional[str]]:
    """
    Register an external agent in the KernellNet Gateway.

    Args:
        redis_client: Redis connection
        card: The agent's identity card
        signature_b58: Base58 Ed25519 signature of the card JSON (optional for phase 1)
        tier: Resolved tier based on $KERN staked by owner

    Returns:
        (ok, message, agent_id)
    """
    agent_id = card.agent_id

    # Check if revoked
    if redis_client.sismember(REVOKED_SET, agent_id):
        return False, "agent_revoked", None

    # Check if already registered
    if redis_client.exists(_agent_key(agent_id)):
        existing = redis_client.hgetall(_agent_key(agent_id))
        if existing.get("status") == "active":
            return False, "already_registered", agent_id

    # Validate card minimums
    if not card.name or not card.url:
        return False, "invalid_card_missing_name_or_url", None

    if len(card.name) > 128 or len(card.url) > 512:
        return False, "card_fields_too_long", None

    # Resolve permissions for this tier
    permissions = EXTERNAL_AGENT_PERMISSIONS.get(tier, EXTERNAL_AGENT_PERMISSIONS["public"])

    # Persist
    now = time.time()
    redis_client.hset(
        _agent_key(agent_id),
        mapping={
            "agent_id": agent_id,
            "name": card.name,
            "url": card.url,
            "description": card.description[:500],
            "framework": card.framework,
            "owner_pubkey": card.owner_pubkey,
            "capabilities": json.dumps(card.capabilities),
            "tier": tier,
            "status": "active",
            "permissions": json.dumps(permissions),
            "signature": signature_b58 or "",
            "registered_ts": str(now),
            "last_seen_ts": str(now),
        },
    )
    redis_client.sadd(REGISTRY_INDEX, agent_id)

    logger.info(
        f"[KernellNet] Registered external agent: {card.name} "
        f"(id={agent_id}, tier={tier}, framework={card.framework})"
    )
    return True, agent_id, agent_id


def get_agent(redis_client: Any, agent_id: str) -> Optional[Dict[str, Any]]:
    """Fetch a registered agent's full record."""
    data = redis_client.hgetall(_agent_key(agent_id))
    if not data:
        return None
    # Parse JSON fields
    for json_field in ("capabilities", "permissions"):
        if json_field in data and isinstance(data[json_field], str):
            try:
                data[json_field] = json.loads(data[json_field])
            except json.JSONDecodeError:
                pass
    return data


def list_agents(redis_client: Any, *, status_filter: str = "active") -> List[Dict[str, Any]]:
    """List all registered agents, optionally filtered by status."""
    agent_ids = redis_client.smembers(REGISTRY_INDEX) or set()
    result = []
    for aid in agent_ids:
        agent = get_agent(redis_client, aid)
        if agent and (not status_filter or agent.get("status") == status_filter):
            result.append(agent)
    return result


def revoke_agent(redis_client: Any, agent_id: str, *, reason: str = "manual") -> Tuple[bool, str]:
    """
    Revoke an agent's access (kill switch).
    Adds to revoked set and marks status as revoked.
    """
    key = _agent_key(agent_id)
    if not redis_client.exists(key):
        return False, "agent_not_found"

    redis_client.hset(key, mapping={
        "status": "revoked",
        "revoked_ts": str(time.time()),
        "revoke_reason": reason,
    })
    redis_client.sadd(REVOKED_SET, agent_id)

    logger.warning(f"[KernellNet] REVOKED agent {agent_id}: {reason}")
    return True, "revoked"


def is_agent_allowed(redis_client: Any, agent_id: str) -> Tuple[bool, str]:
    """Quick check if an agent is active and not revoked."""
    if redis_client.sismember(REVOKED_SET, agent_id):
        return False, "revoked"
    agent = get_agent(redis_client, agent_id)
    if not agent:
        return False, "not_registered"
    if agent.get("status") != "active":
        return False, f"status_{agent.get('status', 'unknown')}"
    return True, "ok"


def check_tool_permission(
    redis_client: Any, agent_id: str, tool_name: str
) -> Tuple[bool, str]:
    """Check if a registered agent has permission to use a specific MCP tool."""
    agent = get_agent(redis_client, agent_id)
    if not agent:
        return False, "not_registered"
    if agent.get("status") != "active":
        return False, "not_active"

    permissions = agent.get("permissions", {})
    if isinstance(permissions, str):
        try:
            permissions = json.loads(permissions)
        except json.JSONDecodeError:
            return False, "invalid_permissions"

    allowed_tools = permissions.get("mcp_tools", [])
    if tool_name not in allowed_tools:
        return False, f"tool_not_in_tier_{agent.get('tier', 'unknown')}"

    return True, "allowed"


def touch_agent(redis_client: Any, agent_id: str) -> None:
    """Update last_seen_ts for an active agent."""
    key = _agent_key(agent_id)
    if redis_client.exists(key):
        redis_client.hset(key, "last_seen_ts", str(time.time()))


# ── API Key Management ──────────────────────────────────────────

import secrets

API_KEY_PREFIX = "knet_sk"
API_KEY_INDEX = "kernell:registry:apikeys"  # HASH: sha256(key) → agent_id
API_KEY_EXPIRE_DAYS = 90


def generate_api_key(
    redis_client: Any,
    agent_id: str,
    tier: str = "observer",
) -> Optional[str]:
    """
    Generate a new API key for a registered agent.

    The plaintext key is returned ONCE. Only its SHA-256 hash
    is stored in Redis. If you lose it, rotate.

    Format: knet_sk_{tier}_{32 hex chars}

    Returns:
        The plaintext API key, or None if agent not found/revoked.
    """
    if not redis_client.exists(_agent_key(agent_id)):
        return None
    if redis_client.sismember(REVOKED_SET, agent_id):
        return None

    # Generate the key
    random_part = secrets.token_hex(32)
    api_key = f"{API_KEY_PREFIX}_{tier}_{random_part}"

    # Store ONLY the hash
    key_hash = hashlib.sha256(api_key.encode("utf-8")).hexdigest()
    now = time.time()
    expire_ts = now + (API_KEY_EXPIRE_DAYS * 86400)

    # Map hash → agent metadata
    redis_client.hset(API_KEY_INDEX, key_hash, json.dumps({
        "agent_id": agent_id,
        "tier": tier,
        "created_ts": now,
        "expire_ts": expire_ts,
    }))

    # Store hash reference on the agent record
    redis_client.hset(_agent_key(agent_id), mapping={
        "api_key_hash": key_hash,
        "api_key_created_ts": str(now),
        "api_key_expire_ts": str(expire_ts),
        "api_key_prefix": api_key[:20] + "...",
    })

    logger.info(
        f"[KernellNet] Generated API key for agent {agent_id} "
        f"(tier={tier}, expires={API_KEY_EXPIRE_DAYS}d)"
    )
    return api_key


def validate_api_key(redis_client: Any, api_key: str) -> Tuple[bool, str, Optional[str]]:
    """
    Validate an API key and return the associated agent.

    Returns:
        (valid, reason, agent_id)
    """
    if not api_key or not api_key.startswith(API_KEY_PREFIX):
        return False, "invalid_format", None

    key_hash = hashlib.sha256(api_key.encode("utf-8")).hexdigest()
    raw = redis_client.hget(API_KEY_INDEX, key_hash)
    if not raw:
        return False, "key_not_found", None

    try:
        meta = json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        return False, "corrupted_key_meta", None

    agent_id = meta.get("agent_id")
    expire_ts = meta.get("expire_ts", 0)

    # Check expiration
    if time.time() > expire_ts:
        # Auto-revoke expired key
        redis_client.hdel(API_KEY_INDEX, key_hash)
        if agent_id:
            redis_client.hset(_agent_key(agent_id), "status", "expired")
        return False, "key_expired", agent_id

    # Check agent still active
    if agent_id:
        allowed, reason = is_agent_allowed(redis_client, agent_id)
        if not allowed:
            return False, reason, agent_id
        # Touch the agent (heartbeat)
        touch_agent(redis_client, agent_id)

    return True, "valid", agent_id


def rotate_api_key(
    redis_client: Any,
    agent_id: str,
) -> Tuple[Optional[str], str]:
    """
    Rotate an agent's API key: invalidate the old one, issue a new one.

    Returns:
        (new_api_key_or_none, message)
    """
    agent = get_agent(redis_client, agent_id)
    if not agent:
        return None, "agent_not_found"
    if agent.get("status") != "active":
        return None, f"agent_not_active_{agent.get('status')}"

    # Revoke old key
    old_hash = agent.get("api_key_hash")
    if old_hash:
        redis_client.hdel(API_KEY_INDEX, old_hash)

    # Generate new key
    tier = agent.get("tier", "observer")
    new_key = generate_api_key(redis_client, agent_id, tier=tier)
    if not new_key:
        return None, "generation_failed"

    logger.info(f"[KernellNet] Rotated API key for agent {agent_id}")
    return new_key, "rotated"


def cleanup_expired_keys(redis_client: Any) -> int:
    """
    Scan and remove expired API keys. Run periodically (cron/heartbeat).

    Returns:
        Number of keys cleaned up.
    """
    all_keys = redis_client.hgetall(API_KEY_INDEX) or {}
    cleaned = 0
    now = time.time()

    for key_hash, raw in all_keys.items():
        try:
            meta = json.loads(raw)
        except (json.JSONDecodeError, TypeError):
            redis_client.hdel(API_KEY_INDEX, key_hash)
            cleaned += 1
            continue

        if now > meta.get("expire_ts", 0):
            redis_client.hdel(API_KEY_INDEX, key_hash)
            agent_id = meta.get("agent_id")
            if agent_id and redis_client.exists(_agent_key(agent_id)):
                redis_client.hset(_agent_key(agent_id), "status", "expired")
            cleaned += 1

    if cleaned:
        logger.info(f"[KernellNet] Cleaned up {cleaned} expired API keys")
    return cleaned

