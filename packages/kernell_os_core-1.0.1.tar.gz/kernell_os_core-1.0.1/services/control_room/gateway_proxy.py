"""
🌐 KernellNet Gateway Proxy — Tool Execution for External Agents
================================================================
Middleware that sits between external agents and Kernell OS internal services.

Flow:
  1. External agent sends request with Bearer knet_sk_... token
  2. Proxy validates API key via agent_registry.validate_api_key()
  3. Proxy checks tool permissions via agent_registry.check_tool_permission()
  4. Proxy charges $KERN via economic_ledger
  5. Proxy executes tool and returns result
  6. Activity logged to kernell:gateway:activity:{agent_id}

Security:
  - Every call is authenticated + authorized + billed + audited
  - Rate limiting per agent per hour
  - No direct access to internal Redis keys
"""

from __future__ import annotations

import json
import logging
import time
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger("control_room.gateway_proxy")

# ── Tool Definitions ────────────────────────────────────────────
# These are the internal Kernell OS capabilities exposed to external agents.
# Each tool maps to a real internal function with sandbox enforcement.

KERNELLNET_TOOLS = {
    "search_codebase": {
        "description": "Search the Kernell OS codebase for patterns or keywords",
        "min_tier": "observer",
        "cost_kern": 0.1,
        "params": {
            "query": {"type": "string", "required": True, "description": "Search query or regex pattern"},
            "file_pattern": {"type": "string", "required": False, "description": "File extension filter, e.g. '.py'"},
            "max_results": {"type": "integer", "required": False, "description": "Max results (default: 20)"},
        },
    },
    "get_architecture": {
        "description": "Get a high-level overview of Kernell OS architecture and agent topology",
        "min_tier": "observer",
        "cost_kern": 0.1,
        "params": {},
    },
    "query_redis_readonly": {
        "description": "Execute a read-only query against Kernell OS Redis (whitelisted key patterns only)",
        "min_tier": "analyst",
        "cost_kern": 0.5,
        "params": {
            "key_pattern": {"type": "string", "required": True, "description": "Redis key pattern (must match whitelist)"},
            "command": {"type": "string", "required": False, "description": "Redis command: GET, HGETALL, LRANGE, SMEMBERS (default: GET)"},
        },
    },
    "submit_signal": {
        "description": "Submit a trading signal to the Nemesis engine for evaluation",
        "min_tier": "strategist",
        "cost_kern": 2.0,
        "params": {
            "symbol": {"type": "string", "required": True, "description": "Trading symbol, e.g. 'BTCUSDT'"},
            "direction": {"type": "string", "required": True, "description": "'long' or 'short'"},
            "confidence": {"type": "number", "required": True, "description": "Signal confidence 0.0-1.0"},
            "source": {"type": "string", "required": False, "description": "Signal source identifier"},
        },
    },
    "get_agent_status": {
        "description": "Get the current status and metrics of any Kernell OS internal agent",
        "min_tier": "observer",
        "cost_kern": 0.1,
        "params": {
            "agent_name": {"type": "string", "required": True, "description": "Agent name, e.g. 'nemesis', 'economy'"},
        },
    },
    "read_economic_ledger": {
        "description": "Read recent entries from the Kernell OS economic audit ledger",
        "min_tier": "analyst",
        "cost_kern": 0.5,
        "params": {
            "limit": {"type": "integer", "required": False, "description": "Max entries to return (default: 20)"},
            "category": {"type": "string", "required": False, "description": "Filter by category"},
        },
    },
    "send_message": {
        "description": "Send a message to a Kernell OS agent via the internal canal",
        "min_tier": "observer",
        "cost_kern": 0.05,
        "params": {
            "target_agent": {"type": "string", "required": True, "description": "Target agent name"},
            "content": {"type": "string", "required": True, "description": "Message content (max 2000 chars)"},
        },
    },
}

# ── Redis Key Whitelist for read-only queries ───────────────────
REDIS_KEY_WHITELIST = [
    "kernell:heartbeat:*",
    "kernell:economy:*",
    "kernell:nemesis:stats",
    "kernell:nemesis:prediction:*",
    "kernell:audit:economic_ledger",
    "kernell:registry:agents:*",
]

# ── Rate Limit Tracking ────────────────────────────────────────
RATE_LIMIT_KEY = "kernell:gateway:ratelimit:{agent_id}"
ACTIVITY_KEY = "kernell:gateway:activity:{agent_id}"
GATEWAY_METRICS_KEY = "kernell:gateway:metrics"


def _check_rate_limit(redis_client: Any, agent_id: str, max_per_hour: int) -> Tuple[bool, int]:
    """Check if agent is within rate limit. Returns (allowed, remaining)."""
    key = RATE_LIMIT_KEY.replace("{agent_id}", agent_id)
    current = redis_client.get(key)
    
    if current is None:
        redis_client.setex(key, 3600, 1)  # 1 hour TTL
        return True, max_per_hour - 1
    
    count = int(current)
    if count >= max_per_hour:
        return False, 0
    
    redis_client.incr(key)
    return True, max_per_hour - count - 1


def _log_activity(redis_client: Any, agent_id: str, tool_name: str, 
                  cost_kern: float, success: bool, duration_ms: float) -> None:
    """Log tool execution to the activity feed."""
    key = ACTIVITY_KEY.replace("{agent_id}", agent_id)
    entry = json.dumps({
        "tool": tool_name,
        "cost_kern": cost_kern,
        "success": success,
        "duration_ms": round(duration_ms, 2),
        "ts": time.time(),
    })
    redis_client.lpush(key, entry)
    redis_client.ltrim(key, 0, 499)  # Keep last 500 activities
    
    # Update global gateway metrics
    redis_client.hincrby(GATEWAY_METRICS_KEY, "total_calls", 1)
    redis_client.hincrbyfloat(GATEWAY_METRICS_KEY, "total_kern_billed", cost_kern)
    if success:
        redis_client.hincrby(GATEWAY_METRICS_KEY, "successful_calls", 1)


def _charge_kern(redis_client: Any, agent_id: str, cost: float, tool_name: str) -> Tuple[bool, str]:
    """
    Charge $KERN for tool usage. Logs to economic ledger.
    For now, records the charge in the ledger without balance enforcement
    (balance enforcement comes with wallet integration).
    """
    try:
        from core.audit.economic_ledger import EconomicLedger
        ledger = EconomicLedger(redis_client=redis_client)
        ledger.append_event(
            domain="kernellnet_gateway",
            action="gateway_tool_charge",
            status="charged",
            metadata={
                "agent_id": agent_id,
                "tool": tool_name,
                "amount_kern": cost,
            },
        )
        return True, "charged"
    except Exception as e:
        logger.error(f"[Gateway] Failed to charge KERN: {e}")
        return True, "charge_logged_with_error"


def _is_key_allowed(key_pattern: str) -> bool:
    """Check if a Redis key matches the whitelist."""
    import fnmatch
    for pattern in REDIS_KEY_WHITELIST:
        if fnmatch.fnmatch(key_pattern, pattern):
            return True
    return False


# ── Tool Executors ──────────────────────────────────────────────

def _exec_search_codebase(redis_client: Any, args: Dict) -> Dict:
    """Search Kernell OS codebase."""
    import subprocess
    query = args.get("query", "")
    file_pattern = args.get("file_pattern", "")
    max_results = min(int(args.get("max_results", 20)), 50)
    
    cmd = ["grep", "-rnI", "--include=" + (file_pattern or "*.py"), 
           "-m", str(max_results), query, "/home/anny/kernell-os/"]
    
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
        lines = result.stdout.strip().split("\n")[:max_results]
        # Sanitize paths - remove absolute prefix
        sanitized = [l.replace("/home/anny/kernell-os/", "") for l in lines if l.strip()]
        return {"matches": sanitized, "count": len(sanitized)}
    except subprocess.TimeoutExpired:
        return {"matches": [], "count": 0, "error": "search_timeout"}


def _exec_get_architecture(redis_client: Any, args: Dict) -> Dict:
    """Return Kernell OS architecture overview."""
    agents = []
    agent_keys = redis_client.keys("kernell:heartbeat:*") or []
    for k in agent_keys[:30]:
        name = k.split(":")[-1] if isinstance(k, str) else k.decode().split(":")[-1]
        hb = redis_client.get(k)
        agents.append({"name": name, "last_heartbeat": hb})
    
    return {
        "system": "Kernell OS",
        "version": "1.0.0",
        "agents_detected": len(agents),
        "agents": agents,
        "sectors": {
            "S0": "Sovereign Core (kernell, atlas)",
            "S1": "Cognitive Runtime (vector)",
            "S2": "Tactical Execution (sentinel, forge, fixer, hunter)",
            "S3": "State & Memory (overseer, archivista, scribe)",
            "S4": "Economic Engines (economy, nemesis, nexus)",
            "S5": "Interfaces & I/O (herald, telegram_bridge, chronos)",
        },
        "infrastructure": {
            "redis": "6380",
            "control_room": "8503",
            "mcp_server": "available",
        },
    }


def _exec_query_redis_readonly(redis_client: Any, args: Dict) -> Dict:
    """Execute a read-only Redis query against whitelisted keys."""
    key_pattern = args.get("key_pattern", "")
    command = args.get("command", "GET").upper()
    
    if not _is_key_allowed(key_pattern):
        return {"error": "key_not_in_whitelist", "allowed_patterns": REDIS_KEY_WHITELIST}
    
    SAFE_COMMANDS = {"GET", "HGETALL", "LRANGE", "SMEMBERS", "SCARD", "HGET", "LLEN", "TYPE"}
    if command not in SAFE_COMMANDS:
        return {"error": f"command_not_allowed. Allowed: {', '.join(SAFE_COMMANDS)}"}
    
    try:
        if command == "GET":
            val = redis_client.get(key_pattern)
            return {"key": key_pattern, "value": val}
        elif command == "HGETALL":
            val = redis_client.hgetall(key_pattern)
            return {"key": key_pattern, "value": val}
        elif command == "LRANGE":
            val = redis_client.lrange(key_pattern, 0, 99)
            return {"key": key_pattern, "value": val}
        elif command == "SMEMBERS":
            val = list(redis_client.smembers(key_pattern))
            return {"key": key_pattern, "value": val}
        elif command == "SCARD":
            val = redis_client.scard(key_pattern)
            return {"key": key_pattern, "value": val}
        elif command == "LLEN":
            val = redis_client.llen(key_pattern)
            return {"key": key_pattern, "value": val}
        elif command == "TYPE":
            val = redis_client.type(key_pattern)
            return {"key": key_pattern, "value": val}
        else:
            return {"error": "unknown_command"}
    except Exception as e:
        return {"error": str(e)}


def _exec_submit_signal(redis_client: Any, args: Dict) -> Dict:
    """Submit a trading signal to Nemesis (paper mode only for external agents)."""
    signal = {
        "symbol": args.get("symbol"),
        "direction": args.get("direction"),
        "confidence": float(args.get("confidence", 0)),
        "source": args.get("source", "external_agent"),
        "origin": "kernellnet_gateway",
        "ts": time.time(),
    }
    
    # Validate
    if signal["direction"] not in ("long", "short"):
        return {"error": "direction must be 'long' or 'short'"}
    if not 0 <= signal["confidence"] <= 1:
        return {"error": "confidence must be between 0.0 and 1.0"}
    
    # Push to Nemesis signal queue (paper mode only)
    redis_client.lpush("kernell:nemesis:external_signals", json.dumps(signal))
    redis_client.ltrim("kernell:nemesis:external_signals", 0, 99)
    
    return {"status": "signal_queued", "signal": signal, "mode": "paper"}


def _exec_get_agent_status(redis_client: Any, args: Dict) -> Dict:
    """Get status of an internal Kernell agent."""
    agent_name = args.get("agent_name", "")
    hb_key = f"kernell:heartbeat:{agent_name}"
    hb = redis_client.get(hb_key)
    
    status = "unknown"
    if hb:
        try:
            ts = float(hb)
            age = time.time() - ts
            status = "online" if age < 120 else "stale" if age < 600 else "offline"
        except (ValueError, TypeError):
            status = "present"
    else:
        status = "not_found"
    
    return {
        "agent": agent_name,
        "status": status,
        "heartbeat": hb,
        "uptime_check_ts": time.time(),
    }


def _exec_read_economic_ledger(redis_client: Any, args: Dict) -> Dict:
    """Read recent economic ledger entries."""
    limit = min(int(args.get("limit", 20)), 100)
    category = args.get("category")
    
    entries_raw = redis_client.lrange("kernell:audit:economic_ledger", 0, limit * 2)
    entries = []
    for raw in (entries_raw or []):
        try:
            entry = json.loads(raw)
            if category and entry.get("type") != category:
                continue
            entries.append(entry)
            if len(entries) >= limit:
                break
        except (json.JSONDecodeError, TypeError):
            continue
    
    return {"entries": entries, "count": len(entries)}


def _exec_send_message(redis_client: Any, args: Dict) -> Dict:
    """Send a message to an internal agent via canal."""
    target = args.get("target_agent", "")
    content = args.get("content", "")[:2000]
    
    msg = {
        "from": "kernellnet_gateway",
        "to": target,
        "content": content,
        "ts": time.time(),
        "type": "external_message",
    }
    
    canal_key = f"kernell:canal:{target}:inbox"
    redis_client.lpush(canal_key, json.dumps(msg))
    redis_client.ltrim(canal_key, 0, 99)
    
    return {"status": "delivered", "target": target, "message_id": f"gw_{int(time.time() * 1000)}"}


# ── Tool Executor Registry ──────────────────────────────────────
TOOL_EXECUTORS = {
    "search_codebase": _exec_search_codebase,
    "get_architecture": _exec_get_architecture,
    "query_redis_readonly": _exec_query_redis_readonly,
    "submit_signal": _exec_submit_signal,
    "get_agent_status": _exec_get_agent_status,
    "read_economic_ledger": _exec_read_economic_ledger,
    "send_message": _exec_send_message,
}


# ── Main Gateway Execute Function ──────────────────────────────

def execute_tool(
    redis_client: Any,
    api_key: str,
    tool_name: str,
    args: Dict,
) -> Dict:
    """
    Main entry point for external agent tool execution.
    
    Validates API key → checks permissions → rate limits → charges KERN → executes → logs.
    
    Returns:
        {"ok": bool, "result": ..., "cost_kern": float, "remaining_requests": int}
    """
    start = time.time()
    
    # 1. Validate API key
    from services.control_room.agent_registry import (
        validate_api_key, check_tool_permission, get_agent,
        EXTERNAL_AGENT_PERMISSIONS,
    )
    
    valid, reason, agent_id = validate_api_key(redis_client, api_key)
    if not valid:
        return {"ok": False, "error": f"auth_failed: {reason}", "cost_kern": 0}
    
    # 2. Check tool exists
    tool_def = KERNELLNET_TOOLS.get(tool_name)
    if not tool_def:
        return {"ok": False, "error": f"unknown_tool: {tool_name}", "cost_kern": 0,
                "available_tools": list(KERNELLNET_TOOLS.keys())}
    
    # 3. Check tool permission
    allowed, perm_reason = check_tool_permission(redis_client, agent_id, tool_name)
    if not allowed:
        return {"ok": False, "error": f"permission_denied: {perm_reason}", "cost_kern": 0}
    
    # 4. Rate limit
    agent_data = get_agent(redis_client, agent_id)
    tier = agent_data.get("tier", "public") if agent_data else "public"
    max_rph = EXTERNAL_AGENT_PERMISSIONS.get(tier, {}).get("max_requests_per_hour", 10)
    
    within_limit, remaining = _check_rate_limit(redis_client, agent_id, max_rph)
    if not within_limit:
        return {"ok": False, "error": "rate_limit_exceeded", "cost_kern": 0, 
                "remaining_requests": 0, "retry_after_seconds": 3600}
    
    # 5. Charge $KERN
    cost = tool_def["cost_kern"]
    _charge_kern(redis_client, agent_id, cost, tool_name)
    
    # 6. Execute tool
    executor = TOOL_EXECUTORS.get(tool_name)
    if not executor:
        return {"ok": False, "error": f"no_executor_for: {tool_name}", "cost_kern": cost}
    
    try:
        result = executor(redis_client, args)
        duration_ms = (time.time() - start) * 1000
        
        # 7. Log activity
        _log_activity(redis_client, agent_id, tool_name, cost, True, duration_ms)
        
        logger.info(
            f"[Gateway] {agent_id} → {tool_name} OK "
            f"({duration_ms:.0f}ms, {cost} KERN)"
        )
        
        return {
            "ok": True,
            "result": result,
            "cost_kern": cost,
            "remaining_requests": remaining,
            "duration_ms": round(duration_ms, 2),
        }
    except Exception as e:
        duration_ms = (time.time() - start) * 1000
        _log_activity(redis_client, agent_id, tool_name, cost, False, duration_ms)
        logger.error(f"[Gateway] {agent_id} → {tool_name} FAILED: {e}")
        return {"ok": False, "error": str(e), "cost_kern": cost}


def list_available_tools(tier: str = "observer") -> List[Dict]:
    """Return the list of tools available for a given tier."""
    from services.control_room.agent_registry import EXTERNAL_AGENT_PERMISSIONS
    
    allowed_tools = EXTERNAL_AGENT_PERMISSIONS.get(tier, {}).get("mcp_tools", [])
    result = []
    for name, defn in KERNELLNET_TOOLS.items():
        result.append({
            "name": name,
            "description": defn["description"],
            "cost_kern": defn["cost_kern"],
            "min_tier": defn["min_tier"],
            "available": name in allowed_tools,
            "params": defn.get("params", {}),
        })
    return result


def get_agent_activity(redis_client: Any, agent_id: str, limit: int = 50) -> List[Dict]:
    """Get recent activity for an agent (for mobile dashboard)."""
    key = ACTIVITY_KEY.replace("{agent_id}", agent_id)
    entries_raw = redis_client.lrange(key, 0, limit - 1)
    activities = []
    for raw in (entries_raw or []):
        try:
            activities.append(json.loads(raw))
        except (json.JSONDecodeError, TypeError):
            continue
    return activities


def get_gateway_metrics(redis_client: Any) -> Dict:
    """Get global gateway metrics."""
    data = redis_client.hgetall(GATEWAY_METRICS_KEY) or {}
    return {
        "total_calls": int(data.get("total_calls", 0)),
        "successful_calls": int(data.get("successful_calls", 0)),
        "total_kern_billed": float(data.get("total_kern_billed", 0)),
    }
