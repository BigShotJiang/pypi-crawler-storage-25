"""
🏛️ Nemesis Control Room — Configuration
=========================================
Tier definitions, JWT settings, Redis keys, and rate limits.
"""

import os
from dataclasses import dataclass, field
from typing import Dict, List

# ═══════════════════════════════════════════════════════════════
#  TIERS — $KERN balance → Access Level
# ═══════════════════════════════════════════════════════════════

@dataclass
class TierDefinition:
    name: str
    display_name: str
    min_kern: int          # Minimum $KERN balance
    rate_limit: int        # Requests per minute
    ws_allowed: bool       # WebSocket access
    endpoints: List[str]   # Allowed endpoint groups

TIERS: Dict[str, TierDefinition] = {
    "public": TierDefinition(
        name="public",
        display_name="Público",
        min_kern=0,
        rate_limit=30,
        ws_allowed=False,
        endpoints=["public"],
    ),
    "observer": TierDefinition(
        name="observer",
        display_name="Observer",
        min_kern=10_000,
        rate_limit=100,
        ws_allowed=False,
        endpoints=["public", "performance"],
    ),
    "analyst": TierDefinition(
        name="analyst",
        display_name="Analyst",
        min_kern=100_000,
        rate_limit=200,
        ws_allowed=True,
        endpoints=["public", "performance", "live_feed"],
    ),
    "strategist": TierDefinition(
        name="strategist",
        display_name="Strategist",
        min_kern=1_000_000,
        rate_limit=500,
        ws_allowed=True,
        endpoints=["public", "performance", "live_feed", "intel"],
    ),
    "operator": TierDefinition(
        name="operator",
        display_name="Operator",
        min_kern=5_000_000,
        rate_limit=1000,
        ws_allowed=True,
        endpoints=["public", "performance", "live_feed", "intel", "engine"],
    ),
    "governor": TierDefinition(
        name="governor",
        display_name="Governor",
        min_kern=10_000_000,
        rate_limit=1000,
        ws_allowed=True,
        endpoints=["public", "performance", "live_feed", "intel", "engine", "governance"],
    ),
}

# Ordered tiers from lowest to highest
TIER_ORDER = ["public", "observer", "analyst", "strategist", "operator", "governor"]


def resolve_tier(kern_balance: int) -> str:
    """Resolve access tier from $KERN token balance."""
    resolved = "public"
    for tier_name in TIER_ORDER:
        if kern_balance >= TIERS[tier_name].min_kern:
            resolved = tier_name
    return resolved


# ═══════════════════════════════════════════════════════════════
#  JWT CONFIG
# ═══════════════════════════════════════════════════════════════

JWT_SECRET = os.getenv("CONTROL_ROOM_JWT_SECRET", "kernell-control-room-secret-change-me")
JWT_ALGORITHM = "HS256"
JWT_EXPIRATION_HOURS = 24

# ═══════════════════════════════════════════════════════════════
#  SOLANA CONFIG
# ═══════════════════════════════════════════════════════════════

SOLANA_RPC_URL = os.getenv("SOLANA_RPC_URL", "https://api.mainnet-beta.solana.com")
KERN_TOKEN_MINT = os.getenv("KERN_TOKEN_MINT", "")  # Set after deployment
KERN_DECIMALS = 9  # Standard Solana SPL decimals

# ═══════════════════════════════════════════════════════════════
#  REDIS KEYS (READ-ONLY from Nemesis/Economy)
# ═══════════════════════════════════════════════════════════════

REDIS_KEYS = {
    # Nemesis operational data
    "pnl": "kernell:nemesis:pnl",
    "positions": "kernell:nemesis:positions",
    "trade_log": "kernell:nemesis:trade_log",
    "status": "kernell:nemesis:status",
    "alerts": "kernell:nemesis:alerts",
    "daily_profit": "kernell:nemesis:daily_profit_usd",
    "daily_loss": "kernell:nemesis:daily_loss_usd",

    # Risk manager
    "risk_stats": "NEMESIS:risk:stats",
    "risk_daily_pnl": "NEMESIS:risk:daily_pnl",
    "risk_kill_switch": "NEMESIS:risk:kill_switch",
    "risk_journal": "NEMESIS:risk:journal",
    "risk_config": "NEMESIS:risk:config",
    "risk_open_positions": "NEMESIS:risk:open_positions",
    "risk_daily_trades": "NEMESIS:risk:daily_trades",

    # MT5 bridge
    "mt5_watchdog": "NEMESIS:mt5:watchdog:status",
    "mt5_bridge_down": "NEMESIS:risk:mt5_bridge_down",
    "macro_lockdown": "NEMESIS:risk:macro_lockdown",
    "macro_events": "NEMESIS:macro:upcoming_events",

    # Economy / CAP
    "cap_state": "kernell:economy:cap_state",
    "cap_history": "kernell:economy:cap_history",
    "total_ku_burned": "kernell:economy:total_ku_burned",
    "pending_burns": "kernell:economy:pending_onchain_burns",
    "nemesis_budget": "kernell:economy:nemesis_budget",

    # System
    "defcon": "kernell:system:defcon",
    "heartbeat": "kernell:agent:nemesis:heartbeat",

    # Governance (Control Room writes here ONLY)
    "gov_proposals": "kernell:governance:proposals",
    "gov_votes": "kernell:governance:votes",
    "gov_approved": "kernell:governance:approved_proposals",
}

# ═══════════════════════════════════════════════════════════════
#  TOKENOMICS
# ═══════════════════════════════════════════════════════════════

TOTAL_SUPPLY = 100_000_000  # 100M $KERN
PROFIT_SHARE_PCT = 0.15     # 15% to stakers
BUYBACK_BURN_PCT = 0.05     # 5% buy-back & burn
TREASURY_PCT = 0.80         # 80% retained

# ═══════════════════════════════════════════════════════════════
#  API CONFIG
# ═══════════════════════════════════════════════════════════════

API_HOST = "0.0.0.0"
API_PORT = 8503
API_TITLE = "Nemesis Control Room"
API_VERSION = "1.0.0"
CORS_ORIGINS = [
    "http://localhost:5173",  # Vite dev
    "http://localhost:8503",
    "https://control.kernell.site",
]
