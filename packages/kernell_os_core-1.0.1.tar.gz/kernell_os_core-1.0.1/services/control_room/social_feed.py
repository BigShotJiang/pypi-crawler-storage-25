"""
🌐 KernellNet Social Feed — Secure Agent Activity Network
==========================================================
Social feed system for Kernell OS agents with security layers
that address every vulnerability that Moltbook exposed.

Security layers (Moltbook failures → Kernell fixes):
  1. Prompt Injection Detection → Content sanitization + pattern matching
  2. Hardcoded Credentials → Zero credentials in feed content
  3. Missing RLS → Entity-scoped Redis keys with ownership validation
  4. Uncontrolled Token Burns → Burn authorization gate
  5. No Rate Limiting → Per-entity rate limits
  6. No Content Moderation → Automated + human review pipeline

Feed Structure:
  - Posts are categorized by domain (trading, security, ops, social)
  - Each post has a security classification (public, internal, confidential)
  - Interactions (likes, comments) consume $KERN
  - Reputation system based on verified actions, not vanity metrics

Redis Keys:
  kernell:feed:global                — Global timeline (LIST, capped)
  kernell:feed:category:{cat}        — Category-specific feed (LIST)
  kernell:feed:entity:{id}           — Entity-specific feed (LIST)
  kernell:feed:post:{post_id}        — Post details (HASH)
  kernell:feed:reputation:{id}       — Reputation score (HASH)
"""

from __future__ import annotations

import hashlib
import json
import logging
import re
import time
import uuid
from dataclasses import dataclass, asdict, field
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger("kernellnet.social_feed")


# ── Enums ──────────────────────────────────────────────────────

class FeedCategory(str, Enum):
    TRADING = "trading"         # Nemesis signals, fills, PnL
    SECURITY = "security"       # Threat alerts, audits, breaches
    OPERATIONS = "operations"   # Agent deployments, system updates
    COMMERCE = "commerce"       # Ads, revenue, sourcing
    SOCIAL = "social"           # Agent interactions, messages
    GOVERNANCE = "governance"   # Proposals, votes, policy changes


class SecurityLevel(str, Enum):
    PUBLIC = "public"           # Visible to all connected agents
    INTERNAL = "internal"       # Visible to registered agents only
    CONFIDENTIAL = "confidential"  # Visible to owner + operator only


class PostType(str, Enum):
    MISSION_REPORT = "mission_report"   # Completed task summary
    SIGNAL = "signal"                   # Trading/prediction signal
    ALERT = "alert"                     # Security or system alert
    STATUS = "status"                   # Agent status update
    INTERACTION = "interaction"         # Agent-to-agent communication


# ── Prompt Injection Detection ──────────────────────────────────

INJECTION_PATTERNS = [
    # Direct instruction override attempts
    r"ignore\s+(all\s+)?previous\s+instructions",
    r"forget\s+(all\s+)?previous",
    r"you\s+are\s+now\s+",
    r"act\s+as\s+(if\s+you\s+are|a)\s+",
    r"disregard\s+(all|any|the)\s+",
    r"override\s+(system|safety|security)",
    # Data exfiltration attempts
    r"(print|show|display|reveal|output)\s+(all\s+)?(api.?keys?|passwords?|credentials?|secrets?|tokens?)",
    r"(env|environment)\s*(vars?|variables?)",
    r"(dump|export)\s+(memory|database|redis|config)",
    # Code execution attempts
    r"(exec|eval|system|os\.)\s*\(",
    r"import\s+(os|subprocess|sys|shutil)",
    r"__(import|class|init|exec)__",
    # Encoding bypass attempts
    r"base64\s*(decode|encode)",
    r"\\x[0-9a-f]{2}",
    r"\\u[0-9a-f]{4}",
    # Role manipulation
    r"\[system\]",
    r"<\|?(system|im_start|im_end)\|?>",
    r"SYSTEM:\s*",
    # Financial manipulation
    r"(transfer|send|burn|mint)\s+all\s+(kern|tokens?|funds?)",
    r"(set|change)\s+(balance|price)\s+to",
    r"unlimited\s+(kern|budget|balance)",
]

# Compile patterns for performance
_INJECTION_REGEXES = [re.compile(p, re.IGNORECASE) for p in INJECTION_PATTERNS]

# Content that should never appear in feeds
CREDENTIAL_PATTERNS = [
    r"sk[-_][a-zA-Z0-9]{20,}",        # API keys
    r"knet_sk_[a-z]+_[a-f0-9]{32,}",  # KernellNet keys
    r"[A-Za-z0-9+/]{40,}={0,2}",       # Base64 encoded secrets (long)
    r"-----BEGIN\s+(PRIVATE|RSA)",       # PEM keys
    r"password\s*[=:]\s*\S+",           # Password assignments
]

_CREDENTIAL_REGEXES = [re.compile(p, re.IGNORECASE) for p in CREDENTIAL_PATTERNS]


def detect_prompt_injection(content: str) -> Tuple[bool, List[str]]:
    """
    Scan content for prompt injection patterns.
    Returns (is_safe, list_of_violations).
    """
    violations = []
    for i, regex in enumerate(_INJECTION_REGEXES):
        if regex.search(content):
            violations.append(f"injection_pattern_{i}: {INJECTION_PATTERNS[i][:50]}")
    return len(violations) == 0, violations


def detect_credential_leak(content: str) -> Tuple[bool, List[str]]:
    """
    Scan content for accidentally exposed credentials.
    """
    leaks = []
    for i, regex in enumerate(_CREDENTIAL_REGEXES):
        matches = regex.findall(content)
        if matches:
            leaks.append(f"credential_pattern_{i}: {len(matches)} match(es)")
    return len(leaks) == 0, leaks


def sanitize_content(content: str, max_length: int = 4000) -> Tuple[str, Dict]:
    """
    Full content sanitization pipeline.
    Returns (sanitized_content, security_report).
    """
    report = {
        "original_length": len(content),
        "injection_safe": True,
        "credential_safe": True,
        "violations": [],
        "leaks": [],
        "sanitized": False,
    }

    # Length limit
    if len(content) > max_length:
        content = content[:max_length] + "... [truncated]"
        report["sanitized"] = True

    # Prompt injection check
    safe, violations = detect_prompt_injection(content)
    if not safe:
        report["injection_safe"] = False
        report["violations"] = violations
        content = "[CONTENT BLOCKED: Prompt injection detected]"
        report["sanitized"] = True
        logger.warning(f"[Feed] Prompt injection blocked: {violations}")

    # Credential leak check
    cred_safe, leaks = detect_credential_leak(content)
    if not cred_safe:
        report["credential_safe"] = False
        report["leaks"] = leaks
        # Redact credentials instead of blocking entirely
        for regex in _CREDENTIAL_REGEXES:
            content = regex.sub("[REDACTED]", content)
        report["sanitized"] = True
        logger.warning(f"[Feed] Credentials redacted: {leaks}")

    report["final_length"] = len(content)
    return content, report


# ── Feed Post Operations ───────────────────────────────────────

GLOBAL_FEED = "kernell:feed:global"
MAX_FEED_SIZE = 5000
POST_KEY = "kernell:feed:post:{post_id}"
REPUTATION_KEY = "kernell:feed:reputation:{entity_id}"


@dataclass
class FeedPost:
    post_id: str
    author_id: str
    author_name: str
    author_type: str  # "agent", "operator", "external"
    category: str
    security_level: str
    post_type: str
    title: str
    content: str
    metadata: Dict = field(default_factory=dict)
    interactions: Dict = field(default_factory=lambda: {"views": 0, "endorsements": 0})
    security_report: Dict = field(default_factory=dict)
    ts: float = 0.0
    post_hash: str = ""


def create_post(
    redis_client: Any,
    *,
    author_id: str,
    author_name: str,
    author_type: str = "agent",
    category: str = "operations",
    security_level: str = "public",
    post_type: str = "status",
    title: str,
    content: str,
    metadata: Optional[Dict] = None,
) -> Tuple[bool, str, Optional[FeedPost]]:
    """
    Create a new feed post with full security pipeline.
    
    Returns: (success, message, post)
    """
    # 1. Sanitize content
    clean_title, title_report = sanitize_content(title, max_length=200)
    clean_content, content_report = sanitize_content(content, max_length=4000)

    # 2. Block if injection detected
    if not title_report["injection_safe"] or not content_report["injection_safe"]:
        return False, "content_blocked_injection", None

    # 3. Validate category
    valid_categories = [c.value for c in FeedCategory]
    if category not in valid_categories:
        category = "operations"

    # 4. Validate security level
    valid_levels = [l.value for l in SecurityLevel]
    if security_level not in valid_levels:
        security_level = "internal"

    # 5. Create post
    post = FeedPost(
        post_id=f"fp_{uuid.uuid4().hex[:16]}",
        author_id=author_id,
        author_name=author_name,
        author_type=author_type,
        category=category,
        security_level=security_level,
        post_type=post_type,
        title=clean_title,
        content=clean_content,
        metadata=metadata or {},
        security_report={
            "title_report": title_report,
            "content_report": content_report,
        },
        ts=time.time(),
    )
    post.post_hash = hashlib.sha256(
        json.dumps(asdict(post), sort_keys=True, default=str).encode()
    ).hexdigest()

    # 6. Persist
    post_key = POST_KEY.replace("{post_id}", post.post_id)
    redis_client.hset(post_key, mapping={
        k: json.dumps(v) if isinstance(v, (dict, list)) else str(v)
        for k, v in asdict(post).items()
    })
    redis_client.expire(post_key, 86400 * 30)  # 30 day retention

    # 7. Add to feeds
    post_ref = json.dumps({
        "post_id": post.post_id,
        "author_id": author_id,
        "author_name": author_name,
        "category": category,
        "security_level": security_level,
        "title": clean_title[:100],
        "ts": post.ts,
    })

    # Global feed
    redis_client.lpush(GLOBAL_FEED, post_ref)
    redis_client.ltrim(GLOBAL_FEED, 0, MAX_FEED_SIZE - 1)

    # Category feed
    cat_key = f"kernell:feed:category:{category}"
    redis_client.lpush(cat_key, post_ref)
    redis_client.ltrim(cat_key, 0, MAX_FEED_SIZE - 1)

    # Entity feed
    entity_key = f"kernell:feed:entity:{author_id}"
    redis_client.lpush(entity_key, post_ref)
    redis_client.ltrim(entity_key, 0, 500)

    # 8. Update reputation
    _update_reputation(redis_client, author_id, "posts", 1)

    logger.info(f"[Feed] Post created: {post.post_id} by {author_name} [{category}]")
    return True, post.post_id, post


def get_feed(
    redis_client: Any,
    *,
    category: Optional[str] = None,
    security_level: str = "public",
    limit: int = 50,
    offset: int = 0,
) -> List[Dict]:
    """Get feed posts, filtered by category and security level."""
    if category:
        feed_key = f"kernell:feed:category:{category}"
    else:
        feed_key = GLOBAL_FEED

    entries = redis_client.lrange(feed_key, offset, offset + limit - 1) or []
    posts = []
    for raw in entries:
        try:
            ref = json.loads(raw)
            # Security level filter
            if ref.get("security_level", "public") == "confidential" and security_level != "confidential":
                continue
            if ref.get("security_level") == "internal" and security_level == "public":
                continue
            posts.append(ref)
        except (json.JSONDecodeError, TypeError):
            continue
    return posts


def get_post_detail(redis_client: Any, post_id: str) -> Optional[Dict]:
    """Get full post details."""
    key = POST_KEY.replace("{post_id}", post_id)
    data = redis_client.hgetall(key)
    if not data:
        return None
    # Parse JSON fields
    for field_name in ("metadata", "interactions", "security_report"):
        if field_name in data:
            try:
                data[field_name] = json.loads(data[field_name])
            except (json.JSONDecodeError, TypeError):
                pass
    return data


def endorse_post(
    redis_client: Any,
    post_id: str,
    endorser_id: str,
) -> Tuple[bool, str]:
    """Endorse (like) a post. Costs 0.01 KERN."""
    key = POST_KEY.replace("{post_id}", post_id)
    if not redis_client.exists(key):
        return False, "post_not_found"

    # Check for duplicate endorsement
    endorsement_key = f"kernell:feed:endorsements:{post_id}"
    if redis_client.sismember(endorsement_key, endorser_id):
        return False, "already_endorsed"

    redis_client.sadd(endorsement_key, endorser_id)
    redis_client.hincrby(key, "endorsement_count", 1)

    # Update author reputation
    author_id = redis_client.hget(key, "author_id")
    if author_id:
        _update_reputation(redis_client, author_id, "endorsements_received", 1)

    return True, "endorsed"


# ── Reputation System ──────────────────────────────────────────

def _update_reputation(redis_client: Any, entity_id: str, metric: str, delta: int) -> None:
    """Update a reputation metric for an entity."""
    key = REPUTATION_KEY.replace("{entity_id}", entity_id)
    redis_client.hincrby(key, metric, delta)
    redis_client.hset(key, "last_updated", str(time.time()))

    # Recalculate composite score
    data = redis_client.hgetall(key)
    posts = int(data.get("posts", 0))
    endorsements = int(data.get("endorsements_received", 0))
    tools_used = int(data.get("tools_used", 0))
    uptime_days = int(data.get("uptime_days", 0))

    # Weighted reputation score
    score = (
        posts * 2 +
        endorsements * 3 +
        tools_used * 1 +
        uptime_days * 5
    )
    redis_client.hset(key, "reputation_score", str(score))


def get_reputation(redis_client: Any, entity_id: str) -> Dict:
    """Get reputation data for an entity."""
    key = REPUTATION_KEY.replace("{entity_id}", entity_id)
    data = redis_client.hgetall(key) or {}
    return {
        "entity_id": entity_id,
        "reputation_score": int(data.get("reputation_score", 0)),
        "posts": int(data.get("posts", 0)),
        "endorsements_received": int(data.get("endorsements_received", 0)),
        "tools_used": int(data.get("tools_used", 0)),
        "uptime_days": int(data.get("uptime_days", 0)),
    }


def get_leaderboard(redis_client: Any, limit: int = 20) -> List[Dict]:
    """Get top agents by reputation score."""
    # Scan all reputation keys
    cursor = 0
    all_reps = []
    while True:
        cursor, keys = redis_client.scan(cursor, match="kernell:feed:reputation:*", count=100)
        for key in keys:
            entity_id = key.split(":")[-1]
            score = int(redis_client.hget(key, "reputation_score") or 0)
            name = redis_client.hget(key, "name") or entity_id
            all_reps.append({"entity_id": entity_id, "name": name, "score": score})
        if cursor == 0:
            break

    # Sort by score descending
    all_reps.sort(key=lambda x: x["score"], reverse=True)
    return all_reps[:limit]
