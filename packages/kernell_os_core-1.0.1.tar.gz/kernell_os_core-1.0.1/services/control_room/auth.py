"""
🔐 Nemesis Control Room — Wallet Authentication
=================================================
Solana wallet signature verification + $KERN balance → Tier → JWT.

Flow:
  1. Frontend sends wallet pubkey + signed nonce
  2. Backend verifies Ed25519 signature
  3. Queries Solana RPC for $KERN token balance
  4. Resolves tier from balance
  5. Issues JWT with tier claim
"""

import time
import json
import logging
import secrets
from datetime import datetime, timezone, timedelta
from typing import Optional, Tuple

import jwt
import hmac
import hashlib
from nacl.signing import VerifyKey
from nacl.exceptions import BadSignatureError

from services.control_room.config import (
    JWT_SECRET,
    JWT_ALGORITHM,
    JWT_EXPIRATION_HOURS,
    SOLANA_RPC_URL,
    KERN_TOKEN_MINT,
    KERN_DECIMALS,
    TIERS,
    resolve_tier,
)

logger = logging.getLogger("control_room.auth")

# ═══════════════════════════════════════════════════════════════
#  NONCE MANAGER (in-memory, Redis-backed in production)
# ═══════════════════════════════════════════════════════════════

_nonce_store: dict[str, float] = {}  # pubkey → expiry timestamp
NONCE_TTL_SECONDS = 300  # 5 minutes


def generate_nonce(pubkey: str) -> str:
    """Generate a unique nonce for wallet signature verification."""
    nonce = f"kernell-control-room-{secrets.token_hex(16)}-{int(time.time())}"
    _nonce_store[pubkey] = time.time() + NONCE_TTL_SECONDS
    # Store nonce associated with pubkey for later verification
    _nonce_store[f"nonce:{pubkey}"] = nonce
    return nonce


def validate_nonce(pubkey: str, nonce: str) -> bool:
    """Validate that the nonce is still valid and matches."""
    stored_nonce = _nonce_store.get(f"nonce:{pubkey}")
    expiry = _nonce_store.get(pubkey, 0)

    if not stored_nonce or stored_nonce != nonce:
        return False
    if time.time() > expiry:
        # Expired
        _nonce_store.pop(pubkey, None)
        _nonce_store.pop(f"nonce:{pubkey}", None)
        return False

    # Consume nonce (single use)
    _nonce_store.pop(pubkey, None)
    _nonce_store.pop(f"nonce:{pubkey}", None)
    return True


# ═══════════════════════════════════════════════════════════════
#  SOLANA SIGNATURE VERIFICATION
# ═══════════════════════════════════════════════════════════════

def verify_solana_signature(pubkey_b58: str, message: str, signature_b58: str) -> bool:
    """
    Verify an Ed25519 signature from a Solana wallet.

    Args:
        pubkey_b58: Base58-encoded public key
        message: Original message that was signed
        signature_b58: Base58-encoded signature

    Returns:
        True if signature is valid
    """
    try:
        import base58
        pubkey_bytes = base58.b58decode(pubkey_b58)
        signature_bytes = base58.b58decode(signature_b58)

        verify_key = VerifyKey(pubkey_bytes)
        verify_key.verify(message.encode("utf-8"), signature_bytes)
        return True

    except (BadSignatureError, Exception) as e:
        logger.warning(f"Signature verification failed for {pubkey_b58[:12]}...: {e}")
        return False

# ═══════════════════════════════════════════════════════════════
#  AGENT HMAC VERIFICATION (Kernell Pay)
# ═══════════════════════════════════════════════════════════════

def verify_hmac_signature(secret: str, payload_str: str, signature: str) -> bool:
    """Verify an HMAC-SHA256 signature from an external agent API Key."""
    try:
        expected = hmac.new(secret.encode(), payload_str.encode(), hashlib.sha256).hexdigest()
        return hmac.compare_digest(expected, signature)
    except Exception as e:
        logger.warning(f"HMAC verification failed: {e}")
        return False


# ═══════════════════════════════════════════════════════════════
#  $KERN BALANCE QUERY
# ═══════════════════════════════════════════════════════════════

async def get_kern_balance(pubkey: str) -> int:
    """
    Query $KERN SPL token balance for a wallet via Solana RPC.

    Returns integer token amount (no decimals).
    """
    if not KERN_TOKEN_MINT:
        logger.warning("KERN_TOKEN_MINT not configured, returning 0")
        return 0

    try:
        import httpx

        payload = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "getTokenAccountsByOwner",
            "params": [
                pubkey,
                {"mint": KERN_TOKEN_MINT},
                {"encoding": "jsonParsed"},
            ],
        }

        async with httpx.AsyncClient() as client:
            resp = await client.post(SOLANA_RPC_URL, json=payload, timeout=10)
            data = resp.json()

        accounts = data.get("result", {}).get("value", [])
        if not accounts:
            return 0

        # Sum balance across all token accounts for this mint
        total = 0
        for acc in accounts:
            info = acc.get("account", {}).get("data", {}).get("parsed", {}).get("info", {})
            token_amount = info.get("tokenAmount", {})
            amount = int(token_amount.get("amount", "0"))
            total += amount

        # Convert from raw (with decimals) to integer tokens
        return total // (10 ** KERN_DECIMALS)

    except Exception as e:
        logger.error(f"Failed to query $KERN balance: {e}")
        return 0


# ═══════════════════════════════════════════════════════════════
#  JWT TOKEN MANAGEMENT
# ═══════════════════════════════════════════════════════════════

def create_jwt(pubkey: str, tier: str, kern_balance: int) -> str:
    """Issue a JWT with tier-bound claims."""
    now = datetime.now(timezone.utc)
    payload = {
        "sub": pubkey,
        "tier": tier,
        "kern_balance": kern_balance,
        "iat": now,
        "exp": now + timedelta(hours=JWT_EXPIRATION_HOURS),
        "iss": "kernell-control-room",
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)


def decode_jwt(token: str) -> Optional[dict]:
    """Decode and validate a JWT. Returns claims or None."""
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        return payload
    except jwt.ExpiredSignatureError:
        logger.debug("JWT expired")
        return None
    except jwt.InvalidTokenError as e:
        logger.debug(f"Invalid JWT: {e}")
        return None


# ═══════════════════════════════════════════════════════════════
#  FULL AUTH FLOW
# ═══════════════════════════════════════════════════════════════

async def authenticate_wallet(
    pubkey: str, nonce: str, signature: str
) -> Tuple[Optional[str], Optional[str], Optional[dict]]:
    """
    Full authentication pipeline: verify → balance → tier → JWT.

    Returns:
        (jwt_token, tier_name, error_dict)
        On success: (token, tier, None)
        On failure: (None, None, {"error": "...", "code": "..."})
    """
    # 1. Validate nonce
    if not validate_nonce(pubkey, nonce):
        return None, None, {"error": "Invalid or expired nonce", "code": "NONCE_INVALID"}

    # 2. Verify signature
    if not verify_solana_signature(pubkey, nonce, signature):
        return None, None, {"error": "Invalid wallet signature", "code": "SIG_INVALID"}

    # 3. Get $KERN balance
    balance = await get_kern_balance(pubkey)

    # 4. Resolve tier
    tier = resolve_tier(balance)

    # 5. Issue JWT
    token = create_jwt(pubkey, tier, balance)

    logger.info(
        f"✅ Authenticated: {pubkey[:12]}... | "
        f"Balance: {balance:,} $KERN | Tier: {tier}"
    )

    return token, tier, None
