"""
🏛️ Nemesis Control Room — FastAPI Application
================================================
Investor-facing API for the Nemesis autonomous trading system.

Port: 8503
Auth: Solana wallet signature → $KERN balance → Tier → JWT
Data: Redis (read-only from Nemesis/Economy agents)

Run:
  uvicorn services.control_room.api:app --host 0.0.0.0 --port 8503 --reload
"""

import os
import json
import asyncio
import logging
import time
from contextlib import asynccontextmanager
from typing import Optional

import redis
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Depends, HTTPException, Query, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from services.control_room.config import (
    API_HOST,
    API_PORT,
    API_TITLE,
    API_VERSION,
    CORS_ORIGINS,
    REDIS_KEYS,
    TIERS,
    TIER_ORDER,
    TOTAL_SUPPLY,
    PROFIT_SHARE_PCT,
    BUYBACK_BURN_PCT,
)
from services.control_room.auth import (
    generate_nonce,
    authenticate_wallet,
    decode_jwt,
)
from services.control_room.middleware import require_tier, get_current_user
from services.control_room.ws_manager import WSManager
from services.control_room.governance import GovernanceEngine
from services.control_room.narration import NarrationEngine
from agents.nemesis.mt5_watchdog import MT5BridgeWatchdog

logger = logging.getLogger("control_room.api")
logging.basicConfig(level=logging.INFO)

# ═══════════════════════════════════════════════════════════════
#  REDIS CONNECTION
# ═══════════════════════════════════════════════════════════════

REDIS_PORT = int(os.getenv("REDIS_PORT", "6380"))
REDIS_PASSWORD = os.getenv("REDIS_PASSWORD", "")

_redis: Optional[redis.Redis] = None
_ws_manager = WSManager()
_governance: Optional[GovernanceEngine] = None
_narration: Optional[NarrationEngine] = None
_watchdog: Optional[MT5BridgeWatchdog] = None


def get_redis() -> redis.Redis:
    global _redis
    if _redis is None:
        _redis = redis.Redis(
            host="localhost",
            port=REDIS_PORT,
            password=REDIS_PASSWORD,
            decode_responses=True,
        )
    return _redis


# ═══════════════════════════════════════════════════════════════
#  BACKGROUND TASK: Redis → WebSocket broadcaster
# ═══════════════════════════════════════════════════════════════

async def _redis_broadcast_loop():
    """Periodically read Nemesis data from Redis and broadcast to WS clients."""
    r = get_redis()
    while True:
        try:
            if _ws_manager.connected_count > 0:
                # Stats broadcast (every 5s)
                stats = _read_aggregated_stats(r)
                await _ws_manager.broadcast("stats", stats)

                # Positions broadcast (every 2s for higher tiers)
                positions = _read_positions(r)
                await _ws_manager.broadcast("positions", positions)

                # Trade feed (check for new entries)
                trades = _read_recent_trades(r, limit=5)
                if trades:
                    await _ws_manager.broadcast("trades", {"recent": trades})

        except Exception as e:
            logger.error(f"Broadcast loop error: {e}")

        await asyncio.sleep(2)


# ═══════════════════════════════════════════════════════════════
#  APP LIFECYCLE
# ═══════════════════════════════════════════════════════════════

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup/shutdown lifecycle."""
    global _governance, _narration, _watchdog
    r = get_redis()
    _governance = GovernanceEngine(r)

    # MT5 Bridge Watchdog — circuit breaker
    _watchdog = MT5BridgeWatchdog(r)
    watchdog_task = asyncio.create_task(_watchdog.run())

    # Narration Engine — AI trade commentary
    _narration = NarrationEngine(r, _ws_manager)
    narration_task = asyncio.create_task(_narration.run())

    # Redis → WebSocket broadcaster
    broadcast_task = asyncio.create_task(_redis_broadcast_loop())

    logger.info(f"🏛️ Nemesis Control Room started on :{API_PORT}")
    logger.info("   ├─ MT5 Watchdog: active")
    logger.info("   ├─ Narration Engine: active")
    logger.info("   └─ WS Broadcaster: active")
    yield
    watchdog_task.cancel()
    narration_task.cancel()
    broadcast_task.cancel()
    logger.info("🏛️ Control Room shutting down")


app = FastAPI(
    title=API_TITLE,
    version=API_VERSION,
    description="Investor-facing dashboard for the Nemesis autonomous trading agent",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

from fastapi.responses import PlainTextResponse, FileResponse, HTMLResponse
from pathlib import Path

# Mount static files for KernellNet Feed UI
_static_dir = Path(__file__).parent / "static"
if _static_dir.is_dir():
    app.mount("/static", StaticFiles(directory=str(_static_dir)), name="static")


@app.get("/feed", response_class=HTMLResponse, tags=["KernellNet Feed"])
async def serve_feed_ui():
    """Serve the KernellNet Social Feed web interface."""
    feed_html = _static_dir / "feed.html"
    if feed_html.exists():
        return HTMLResponse(content=feed_html.read_text(encoding="utf-8"))
    return HTMLResponse(content="<h1>Feed not found</h1>", status_code=404)


@app.get("/robots.txt", response_class=PlainTextResponse)
async def robots_txt():
    return "User-agent: *\nAllow: /\n"

@app.get("/context.txt", response_class=FileResponse)
async def context_txt():
    p = Path("/home/anny/kernell-os/context.txt")
    if not p.exists():
        return PlainTextResponse("Contexto no encontrado", status_code=404)
    return FileResponse(p, media_type="text/plain")


# ═══════════════════════════════════════════════════════════════
#  REDIS DATA READERS (READ-ONLY)
# ═══════════════════════════════════════════════════════════════

def _read_aggregated_stats(r: redis.Redis) -> dict:
    """Read and aggregate Nemesis performance stats."""
    stats = r.hgetall(REDIS_KEYS["risk_stats"]) or {}
    daily_pnl = float(r.get(REDIS_KEYS["risk_daily_pnl"]) or "0")
    kill_switch = r.get(REDIS_KEYS["risk_kill_switch"]) or "DISARMED"
    daily_trades = int(r.get(REDIS_KEYS["risk_daily_trades"]) or "0")
    open_count = r.scard(REDIS_KEYS["risk_open_positions"]) or 0
    defcon = r.get(REDIS_KEYS["defcon"]) or "1"
    heartbeat = r.get(REDIS_KEYS["heartbeat"]) or "{}"

    total = int(stats.get("total_trades", 0))
    wins = int(stats.get("wins", 0))
    losses = int(stats.get("losses", 0))
    total_pnl = float(stats.get("total_pnl", 0))
    total_wins_amt = float(stats.get("total_wins_amount", 0))
    total_losses_amt = float(stats.get("total_losses_amount", 0))
    win_rate = (wins / total * 100) if total > 0 else 0
    avg_win = (total_wins_amt / wins) if wins > 0 else 0
    avg_loss = (total_losses_amt / losses) if losses > 0 else 0
    rr = (avg_win / avg_loss) if avg_loss > 0 else 0

    return {
        "pnl": {
            "daily": round(daily_pnl, 2),
            "total": round(total_pnl, 2),
        },
        "trades": {
            "total": total,
            "today": daily_trades,
            "wins": wins,
            "losses": losses,
            "win_rate": round(win_rate, 1),
            "avg_win": round(avg_win, 2),
            "avg_loss": round(avg_loss, 2),
            "rr_ratio": round(rr, 2),
        },
        "risk": {
            "kill_switch": kill_switch,
            "open_positions": open_count,
            "defcon": int(defcon),
        },
        "status": {
            "heartbeat": heartbeat,
            "timestamp": time.time(),
        },
    }


def _read_positions(r: redis.Redis) -> list:
    """Read current open positions from Redis."""
    raw = r.get(REDIS_KEYS["positions"])
    if not raw:
        return []
    try:
        return json.loads(raw)
    except Exception:
        return []


def _read_recent_trades(r: redis.Redis, limit: int = 20) -> list:
    """Read recent trades from the journal."""
    raw_list = r.lrange(REDIS_KEYS["risk_journal"], -limit, -1) or []
    trades = []
    for raw in reversed(raw_list):
        try:
            trades.append(json.loads(raw))
        except Exception:
            continue
    return trades


def _read_equity_curve(r: redis.Redis) -> list:
    """Build equity curve from closed trades."""
    raw_list = r.lrange(REDIS_KEYS["risk_journal"], 0, -1) or []
    equity = [0.0]
    for raw in raw_list:
        try:
            entry = json.loads(raw)
            pnl = entry.get("pnl")
            if pnl is not None:
                equity.append(round(equity[-1] + float(pnl), 2))
        except Exception:
            continue
    return equity


def _read_risk_config(r: redis.Redis) -> dict:
    """Read risk manager configuration."""
    return r.hgetall(REDIS_KEYS["risk_config"]) or {}


def _read_engine_status(r: redis.Redis) -> dict:
    """Read MT5 bridge and macro status."""
    watchdog = r.hgetall(REDIS_KEYS["mt5_watchdog"]) or {}
    bridge_down = r.get(REDIS_KEYS["mt5_bridge_down"])
    macro_lock = r.get(REDIS_KEYS["macro_lockdown"]) or "CLEAR"

    events = []
    raw_events = r.lrange(REDIS_KEYS["macro_events"], 0, 9) or []
    for ev_raw in raw_events:
        try:
            events.append(json.loads(ev_raw))
        except Exception:
            continue

    return {
        "mt5": {
            "bridge_status": watchdog.get("bridge_status", "unknown"),
            "consecutive_failures": int(watchdog.get("consecutive_failures", 0)),
            "bridge_down": bridge_down == "1",
        },
        "macro": {
            "lockdown": macro_lock,
            "upcoming_events": events,
        },
    }


def _read_token_stats(r: redis.Redis) -> dict:
    """Read $KERN token stats."""
    total_burned = float(r.get(REDIS_KEYS["total_ku_burned"]) or "0")
    pending_burns = r.llen(REDIS_KEYS["pending_burns"]) or 0
    cap_state = json.loads(r.get(REDIS_KEYS["cap_state"]) or "{}")

    return {
        "symbol": "KERN",
        "total_supply": TOTAL_SUPPLY,
        "total_ku_burned": round(total_burned, 2),
        "pending_onchain_burns": pending_burns,
        "cap_multiplier": cap_state.get("active_price_multiplier", 1.0),
        "burn_rate": cap_state.get("active_burn_rate", 0.20),
        "profit_share_pct": PROFIT_SHARE_PCT,
        "buyback_burn_pct": BUYBACK_BURN_PCT,
    }


def _safe_json(raw: Optional[str], default):
    if not raw:
        return default
    try:
        return json.loads(raw)
    except Exception:
        return default


# ═══════════════════════════════════════════════════════════════
#  PUBLIC ENDPOINTS (No auth)
# ═══════════════════════════════════════════════════════════════

@app.get("/api/v1/health", tags=["Public"])
async def health():
    """System health beacon — enriched with live operational data."""
    r = get_redis()
    try:
        r.ping()
        redis_ok = True
    except Exception:
        redis_ok = False

    # Determine nemesis status
    kill_switch = r.get(REDIS_KEYS["risk_kill_switch"]) or "DISARMED"
    bridge_down = r.get(REDIS_KEYS["mt5_bridge_down"]) == "1"
    if kill_switch == "ACTIVE":
        nemesis_status = "KILL_SWITCH"
    elif bridge_down:
        nemesis_status = "MT5_BRIDGE_DOWN"
    elif redis_ok:
        nemesis_status = "OPERATIONAL"
    else:
        nemesis_status = "DEGRADED"

    # Watchdog data
    watchdog_status = _watchdog.get_status() if _watchdog else {}

    return {
        "status": "operational" if redis_ok and not bridge_down else "degraded",
        "nemesis_status": nemesis_status,
        "service": "nemesis-control-room",
        "version": API_VERSION,
        "redis": redis_ok,
        "mt5_bridge": watchdog_status.get("bridge_status", "unknown"),
        "active_trades": r.scard(REDIS_KEYS["risk_open_positions"]) or 0,
        "pnl_today": round(float(r.get(REDIS_KEYS["risk_daily_pnl"]) or "0"), 2),
        "last_action": r.get("nemesis:last_action") or "awaiting",
        "uptime_seconds": watchdog_status.get("uptime_seconds", 0),
        "ws_connections": _ws_manager.connected_count,
        "timestamp": time.time(),
    }


@app.get("/api/v1/narrations", tags=["Public"])
async def get_narrations(limit: int = Query(default=20, le=50)):
    """Recent AI narrations of trading decisions (public)."""
    if _narration:
        return {"narrations": _narration.get_recent(limit=limit)}
    return {"narrations": []}


@app.get("/api/v1/stats", tags=["Public"])
async def public_stats():
    """Aggregated performance stats (public-safe subset)."""
    r = get_redis()
    stats = _read_aggregated_stats(r)
    # Public only sees aggregate — no live feed detail
    return {
        "total_pnl": stats["pnl"]["total"],
        "total_trades": stats["trades"]["total"],
        "win_rate": stats["trades"]["win_rate"],
        "rr_ratio": stats["trades"]["rr_ratio"],
        "open_positions": stats["risk"]["open_positions"],
        "status": "operational" if stats["risk"]["kill_switch"] == "DISARMED" else "halted",
    }


@app.get("/api/v1/token", tags=["Public"])
async def token_stats():
    """$KERN token statistics."""
    r = get_redis()
    return _read_token_stats(r)


@app.get("/api/v1/tiers", tags=["Public"])
async def list_tiers():
    """List all access tiers and requirements."""
    return {
        tier_name: {
            "display_name": t.display_name,
            "min_kern": t.min_kern,
            "rate_limit": t.rate_limit,
            "ws_access": t.ws_allowed,
            "endpoints": t.endpoints,
        }
        for tier_name, t in TIERS.items()
    }


# ═══════════════════════════════════════════════════════════════
#  STAKING ENDPOINTS (Phase 3)
# ═══════════════════════════════════════════════════════════════

@app.get("/api/v1/staking", tags=["Staking"])
async def get_staking_info():
    """Get global staking pool stats and estimated APY."""
    r = get_redis()
    pool_usd = float(r.get("kernell:economy:staking_pool_usd") or "0")
    total_staked_kern = float(r.get("kernell:economy:total_staked_kern") or "1000000") # Simulated base stake
    
    # Calculate Simulated APY = (Daily Yield * 365) / (Total Value Locked)
    estimated_price = 0.05
    if total_staked_kern > 0:
        annual_yield = pool_usd * 365 
        apy = (annual_yield / (total_staked_kern * estimated_price)) * 100
    else:
        apy = 0.0
        
    return {
        "staking_pool_usd": round(pool_usd, 2),
        "total_staked_kern": total_staked_kern,
        "estimated_apy_pct": round(apy, 2)
    }

@app.post("/api/v1/staking/stake", tags=["Staking"])
async def simulate_stake(amount: float, user: dict = Depends(get_current_user)):
    """Simulate staking Kern tokens (Off-chain)."""
    if not user or not user.get("authenticated"):
        raise HTTPException(status_code=401, detail="Wallet connection required")
        
    r = get_redis()
    pubkey = user.get("sub", "unknown")
    
    current_stake = float(r.hget(f"kernell:economy:stakers", pubkey) or "0")
    r.hset(f"kernell:economy:stakers", pubkey, current_stake + amount)
    r.incrbyfloat("kernell:economy:total_staked_kern", amount)
    
    return {
        "status": "success", 
        "amount_staked": amount, 
        "total_user_stake": current_stake + amount
    }


# ═══════════════════════════════════════════════════════════════
#  AUTH ENDPOINTS
# ═══════════════════════════════════════════════════════════════

@app.post("/api/v1/auth/nonce", tags=["Auth"])
async def request_nonce(pubkey: str):
    """Request a nonce for wallet signature verification."""
    nonce = generate_nonce(pubkey)
    return {"nonce": nonce, "ttl_seconds": 300}


@app.post("/api/v1/auth/verify", tags=["Auth"])
async def verify_wallet(pubkey: str, nonce: str, signature: str):
    """Verify wallet signature and issue JWT."""
    token, tier, error = await authenticate_wallet(pubkey, nonce, signature)
    if error:
        raise HTTPException(status_code=401, detail=error)
    return {"token": token, "tier": tier}


@app.get("/api/v1/auth/me", tags=["Auth"])
async def my_profile(user: Optional[dict] = Depends(get_current_user)):
    """Get current authenticated user profile."""
    if not user:
        return {"tier": "public", "authenticated": False}
    return {
        "authenticated": True,
        "pubkey": user.get("sub"),
        "tier": user.get("tier"),
    }


@app.post("/api/v1/mobile/kern/withdraw", tags=["MobileAPI"])
async def withdraw_kern(
    amount_ku: float,
    destination_spl_address: str,
    user: dict = Depends(get_current_user),
):
    """Initiate a withdrawal from mobile internal ledger to a Solana wallet."""
    if not user or not user.get("authenticated"):
        raise HTTPException(status_code=401, detail="Wallet connection required")

    pubkey = user.get("sub", "unknown")
    if not pubkey or pubkey == "unknown":
        raise HTTPException(status_code=400, detail="Invalid user pubkey")

    if amount_ku <= 0:
        raise HTTPException(status_code=400, detail="Withdrawal amount must be > 0")

    r = get_redis()
    from agents.finance.economy.kern_spl_bridge import enqueue_mobile_withdrawal
    
    ok, message_or_job_id, job_id = enqueue_mobile_withdrawal(
        r,
        device_id=pubkey,
        amount_ku=amount_ku,
        destination_spl_address=destination_spl_address,
    )
    
    if not ok:
        raise HTTPException(status_code=400, detail=f"Withdrawal blocked: {message_or_job_id}")

    return {
        "status": "queued",
        "job_id": job_id,
        "amount_ku": amount_ku,
        "destination": destination_spl_address
    }


# ═══════════════════════════════════════════════════════════════
#  KERNELLNET GATEWAY — External Agent Registry
# ═══════════════════════════════════════════════════════════════

from pydantic import BaseModel, Field
from typing import List as TypingList

class AgentCardPayload(BaseModel):
    name: str = Field(..., max_length=128)
    url: str = Field(..., max_length=512)
    description: str = Field("", max_length=500)
    capabilities: TypingList[str] = Field(default_factory=list)
    version: str = "1.0"
    framework: str = "unknown"
    owner_pubkey: str = ""
    signature: str = ""


@app.post("/api/v1/agents/register", tags=["KernellNet"])
async def register_external_agent(payload: AgentCardPayload):
    """
    Register an external agent in the KernellNet Gateway.
    The agent receives a scoped API key (knet_sk_...).
    """
    from services.control_room.agent_registry import (
        ExternalAgentCard,
        register_agent,
        get_agent,
        generate_api_key
    )

    r = get_redis()
    card = ExternalAgentCard(
        name=payload.name,
        url=payload.url,
        description=payload.description,
        capabilities=payload.capabilities,
        version=payload.version,
        framework=payload.framework,
        owner_pubkey=payload.owner_pubkey,
    )

    # Determine tier
    tier = "observer"

    ok, message, agent_id = register_agent(
        r, card, signature_b58=payload.signature, tier=tier
    )
    if not ok and message != "already_registered":
        raise HTTPException(status_code=400, detail=f"Registration failed: {message}")

    # Generate a new API Key for this connection
    api_key = generate_api_key(r, agent_id, tier=tier)
    if not api_key:
        raise HTTPException(status_code=500, detail="Failed to generate API Key")

    agent_data = get_agent(r, agent_id)

    return {
        "status": "registered",
        "agent_id": agent_id,
        "tier": tier,
        "api_key": api_key,  # IMPORTANT: Displayed ONLY once here
        "permissions": agent_data.get("permissions", {}),
    }


@app.get("/api/v1/agents", tags=["KernellNet"])
async def list_registered_agents(
    user: Optional[dict] = Depends(get_current_user),
):
    """List all registered external agents (for mobile dashboard)."""
    from services.control_room.agent_registry import list_agents

    r = get_redis()
    agents = list_agents(r)
    # Sanitize: don't expose signatures or internal keys
    safe = []
    for a in agents:
        safe.append({
            "agent_id": a.get("agent_id"),
            "name": a.get("name"),
            "url": a.get("url"),
            "description": a.get("description"),
            "framework": a.get("framework"),
            "tier": a.get("tier"),
            "status": a.get("status"),
            "registered_ts": a.get("registered_ts"),
            "last_seen_ts": a.get("last_seen_ts"),
        })
    return {"agents": safe, "count": len(safe)}


@app.delete("/api/v1/agents/{agent_id}", tags=["KernellNet"])
async def revoke_external_agent(
    agent_id: str,
    reason: str = "manual_revocation",
    user: dict = Depends(get_current_user),
):
    """
    Kill switch: revoke an external agent's access.
    Callable from mobile app for human-in-the-loop control.
    """
    if not user or not user.get("authenticated"):
        raise HTTPException(status_code=401, detail="Authentication required")

    from services.control_room.agent_registry import revoke_agent

    r = get_redis()
    ok, msg = revoke_agent(r, agent_id, reason=reason)
    if not ok:
        raise HTTPException(status_code=404, detail=msg)
    return {"status": "revoked", "agent_id": agent_id, "reason": reason}


@app.get("/api/v1/agents/{agent_id}", tags=["KernellNet"])
async def get_agent_detail(agent_id: str):
    """Get details of a specific registered agent."""
    from services.control_room.agent_registry import get_agent

    r = get_redis()
    agent = get_agent(r, agent_id)
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    # Don't expose signature or key hash
    agent.pop("signature", None)
    agent.pop("api_key_hash", None)
    return agent


# ── KernellNet Gateway: Tool Execution ─────────────────────────

class ToolCallPayload(BaseModel):
    api_key: str
    tool: str
    args: dict = {}


@app.post("/api/v1/gateway/execute", tags=["KernellNet Gateway"])
async def gateway_execute_tool(payload: ToolCallPayload):
    """
    Execute a Kernell OS tool as an external agent.
    Requires a valid knet_sk API key. Charges $KERN per call.
    """
    from services.control_room.gateway_proxy import execute_tool

    r = get_redis()
    result = execute_tool(r, payload.api_key, payload.tool, payload.args)

    if not result.get("ok"):
        status = 403 if "auth" in result.get("error", "") else 400
        if "rate_limit" in result.get("error", ""):
            status = 429
        raise HTTPException(status_code=status, detail=result)

    return result


@app.get("/api/v1/gateway/tools", tags=["KernellNet Gateway"])
async def gateway_list_tools(tier: str = "observer"):
    """List all available KernellNet tools with their costs and tier requirements."""
    from services.control_room.gateway_proxy import list_available_tools
    tools = list_available_tools(tier)
    return {"tools": tools, "tier": tier, "count": len(tools)}


@app.get("/api/v1/gateway/activity/{agent_id}", tags=["KernellNet Gateway"])
async def gateway_agent_activity(agent_id: str, limit: int = 50):
    """Get recent activity for a connected external agent (for mobile dashboard)."""
    from services.control_room.gateway_proxy import get_agent_activity

    r = get_redis()
    activities = get_agent_activity(r, agent_id, limit=min(limit, 200))
    return {"agent_id": agent_id, "activities": activities, "count": len(activities)}


@app.get("/api/v1/gateway/metrics", tags=["KernellNet Gateway"])
async def gateway_metrics():
    """Get global KernellNet Gateway metrics (total calls, KERN billed)."""
    from services.control_room.gateway_proxy import get_gateway_metrics

    r = get_redis()
    return get_gateway_metrics(r)


@app.post("/api/v1/agents/{agent_id}/rotate-key", tags=["KernellNet"])
async def rotate_agent_key(
    agent_id: str,
    user: dict = Depends(get_current_user),
):
    """
    Rotate an agent's API key. Returns the new key (shown once).
    Requires authenticated operator.
    """
    if not user or not user.get("authenticated"):
        raise HTTPException(status_code=401, detail="Authentication required")

    from services.control_room.agent_registry import rotate_api_key

    r = get_redis()
    new_key, msg = rotate_api_key(r, agent_id)
    if not new_key:
        raise HTTPException(status_code=400, detail=msg)
    return {"status": "rotated", "agent_id": agent_id, "api_key": new_key}


# ═══════════════════════════════════════════════════════════════
#  KERNELL PAY (L2 GATEWAY)
# ═══════════════════════════════════════════════════════════════

class InvoicePayload(BaseModel):
    amount: float
    description: str

@app.post("/api/v1/pay/invoice", tags=["Kernell Pay"])
async def generate_invoice(
    payload: InvoicePayload,
    req: Request,
):
    """Generate a payment link/invoice for the Kernell Pay gateway."""
    auth_header = req.headers.get("Authorization")
    if not auth_header or not auth_header.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing or invalid Bearer token")
        
    api_key = auth_header.split(" ")[1]
    
    r = get_redis()
    from services.control_room.agent_registry import validate_api_key
    valid, reason, agent_id = validate_api_key(r, api_key)
    if not valid:
        raise HTTPException(status_code=401, detail=f"Unauthorized: {reason}")
        
    from services.control_room.kern_ledger import create_invoice
    inv = create_invoice(r, agent_id, payload.amount, payload.description)
    return {"status": "success", "invoice": inv}

class PayInvoicePayload(BaseModel):
    invoice_id: str
    payer_entity: str

@app.post("/api/v1/pay/execute", tags=["Kernell Pay"])
async def execute_payment(
    payload: PayInvoicePayload,
    user: Optional[dict] = Depends(get_current_user),
):
    """Execute payment for a Kernell Pay invoice."""
    # Requires Human UI approval through Pulse/Canal (JWT based)
    if not user:
        raise HTTPException(status_code=401, detail="Auth required to pay invoices")
        
    from services.control_room.kern_ledger import pay_invoice
    r = get_redis()
    success, msg, tx = pay_invoice(r, payload.invoice_id, payload.payer_entity)
    if not success:
        raise HTTPException(status_code=400, detail=msg)
        
    return {"status": "success", "message": "Payment executed", "tx_hash": tx.tx_hash if tx else ""}


# ═══════════════════════════════════════════════════════════════
#  KERNELLNET SOCIAL FEED
# ═══════════════════════════════════════════════════════════════

class FeedPostPayload(BaseModel):
    author_name: str
    category: str = "operations"
    security_level: str = "public"
    post_type: str = "status"
    title: str
    content: str
    metadata: dict = {}


@app.post("/api/v1/feed/posts", tags=["KernellNet Feed"])
async def create_feed_post(
    payload: FeedPostPayload,
    user: Optional[dict] = Depends(get_current_user),
):
    """Create a new post in the KernellNet social feed."""
    from services.control_room.social_feed import create_post

    r = get_redis()
    author_id = user.get("pubkey", "anonymous") if user else "anonymous"
    ok, msg, post = create_post(
        r,
        author_id=author_id,
        author_name=payload.author_name,
        category=payload.category,
        security_level=payload.security_level,
        post_type=payload.post_type,
        title=payload.title,
        content=payload.content,
        metadata=payload.metadata,
    )
    if not ok:
        raise HTTPException(status_code=400, detail=msg)
    return {"status": "created", "post_id": msg}


@app.get("/api/v1/feed", tags=["KernellNet Feed"])
async def get_social_feed(
    category: Optional[str] = None,
    security_level: str = "public",
    limit: int = 50,
    offset: int = 0,
):
    """Get the KernellNet social feed, optionally filtered by category."""
    from services.control_room.social_feed import get_feed

    r = get_redis()
    posts = get_feed(r, category=category, security_level=security_level,
                     limit=min(limit, 200), offset=offset)
    return {"posts": posts, "count": len(posts), "category": category or "all"}


@app.get("/api/v1/feed/posts/{post_id}", tags=["KernellNet Feed"])
async def get_feed_post_detail(post_id: str):
    """Get full details of a specific feed post."""
    from services.control_room.social_feed import get_post_detail

    r = get_redis()
    post = get_post_detail(r, post_id)
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
    return post


@app.get("/api/v1/feed/reputation/{entity_id}", tags=["KernellNet Feed"])
async def get_entity_reputation(entity_id: str):
    """Get reputation score for an agent or entity."""
    from services.control_room.social_feed import get_reputation
    r = get_redis()
    return get_reputation(r, entity_id)


@app.get("/api/v1/feed/leaderboard", tags=["KernellNet Feed"])
async def get_feed_leaderboard(limit: int = 20):
    """Get top agents by reputation score."""
    from services.control_room.social_feed import get_leaderboard
    r = get_redis()
    return {"leaderboard": get_leaderboard(r, limit=min(limit, 100))}


# ═══════════════════════════════════════════════════════════════
#  KERN OFF-CHAIN LEDGER
# ═══════════════════════════════════════════════════════════════

@app.get("/api/v1/kern/balance/{entity_id}", tags=["KERN Ledger"])
async def get_kern_balance(entity_id: str):
    """Get off-chain KERN balance for an entity."""
    from services.control_room.kern_ledger import get_balance_summary
    r = get_redis()
    return get_balance_summary(r, entity_id)


@app.get("/api/v1/kern/history/{entity_id}", tags=["KERN Ledger"])
async def get_kern_history(entity_id: str, limit: int = 50):
    """Get KERN transaction history for an entity."""
    from services.control_room.kern_ledger import get_transaction_history
    r = get_redis()
    txs = get_transaction_history(r, entity_id, limit=min(limit, 200))
    return {"entity_id": entity_id, "transactions": txs, "count": len(txs)}


@app.get("/api/v1/kern/stats", tags=["KERN Ledger"])
async def get_kern_stats():
    """Get global KERN economy statistics."""
    from services.control_room.kern_ledger import get_global_stats
    r = get_redis()
    return get_global_stats(r)


@app.post("/api/v1/pay/settle", tags=["Kernell Pay"])
async def trigger_settlement(
    user: dict = Depends(get_current_user),
):
    """Trigger batch settlement of pending KERN transactions."""
    if not user or not user.get("authenticated"):
        raise HTTPException(status_code=401, detail="Auth required")
    from services.control_room.kern_ledger import batch_settle
    r = get_redis()
    result = batch_settle(r)
    return result


from fastapi_cache.decorator import cache
@app.get("/api/v1/public/explorer", tags=["Kernell Pay"])
@cache(expire=60)
async def public_explorer():
    """Public L2 explorer endpoint (Cached 60s). Obfuscates sensitive data."""
    r = get_redis()
    
    # Get 10 recent transactions
    raw_txs = r.lrange("kernell:kern:ledger:GLOBAL", 0, 9)
    public_logs = []
    
    for rt in raw_txs:
        try:
            tx = json.loads(rt)
            
            # Opacify entities slightly for competitive security
            from_entity_name = tx.get("from_entity", "Unknown")
            to_entity_name = tx.get("to_entity", "Unknown")
            
            if "shopify" in from_entity_name.lower():
                from_entity_name = "Shopify Fiat"
            elif "escrow" in to_entity_name.lower():
                to_entity_name = "$KERN Escrow"
            elif "dropship_merchant" in from_entity_name.lower():
                from_entity_name = "Supplier"
                
            public_logs.append({
                "id": str(tx.get("tx_hash", "0x..."))[:12] + "...",
                "agents": f"{from_entity_name} → {to_entity_name}",
                "type": tx.get("description", "Agent Contract")[:15] + "...",
                "status": tx.get("status", "SETTLED").upper(),
                "time": "Just now" # simplified for marketing
            })
        except Exception:
            continue
            
    # Mock fallback if empty
    if not public_logs:
        public_logs = [
            { "id": "0xx71a2...b4", "agents": "Harlemm → Sierra", "type": "Security Audit", "status": "VERIFIED", "time": "Just now" },
            { "id": "0xec29c...aa", "agents": "Shopify → $KERN", "type": "Fiat Escrow", "status": "ESCROW_LOCK", "time": "1 min ago" },
        ]
        
    stats = {
        "total_volume": float(r.hget(GLOBAL_STATS, "total_volume") or 144821.0),
        "total_transactions": int(r.hget(GLOBAL_STATS, "total_transactions") or 8201)
    }
    
    # Try to get last settlement anchor hash
    last_settlement_raw = r.get(LAST_SETTLEMENT)
    merkle_hash = "0x91f3a2c9b4e18...a1b9201f3f4c2e6f9a0c1d2e3f4a5b6c"
    if last_settlement_raw:
        try:
            settlement = json.loads(last_settlement_raw)
            merkle_hash = settlement.get("tx_hash", merkle_hash)
            if len(merkle_hash) > 20:
                merkle_hash = merkle_hash[:16] + "..." + merkle_hash[-8:]
        except:
            pass
            
    return {
        "logs": public_logs,
        "metrics": {
            "volume_kern": stats["total_volume"],
            "tx_count": stats["total_transactions"],
            "merkle_root": merkle_hash,
            "anchor_cost": "~$0.0024",
            "burned_kern": float(r.hget("kernell:kern:ledger:global_stats", "total_burned") or 432.55),
            "active_escrows": len(r.keys("kernell:kern:escrow:*"))
        }
    }


# ═══════════════════════════════════════════════════════════════
#  OBSERVER+ ENDPOINTS
# ═══════════════════════════════════════════════════════════════

@app.get(
    "/api/v1/performance",
    tags=["Performance"],
    dependencies=[Depends(require_tier("observer"))],
)
async def performance():
    """Detailed performance metrics and equity curve."""
    r = get_redis()
    stats = _read_aggregated_stats(r)
    equity = _read_equity_curve(r)
    return {
        "metrics": stats,
        "equity_curve": equity,
        "equity_points": len(equity),
    }


# ═══════════════════════════════════════════════════════════════
#  ANALYST+ ENDPOINTS
# ═══════════════════════════════════════════════════════════════

@app.get(
    "/api/v1/positions",
    tags=["Live Feed"],
    dependencies=[Depends(require_tier("analyst"))],
)
async def positions():
    """Current open positions with unrealized P&L."""
    r = get_redis()
    return {"positions": _read_positions(r)}


@app.get(
    "/api/v1/journal",
    tags=["Live Feed"],
    dependencies=[Depends(require_tier("analyst"))],
)
async def journal(limit: int = Query(default=50, le=200)):
    """Recent trade journal entries."""
    r = get_redis()
    return {"trades": _read_recent_trades(r, limit=limit)}


@app.get(
    "/api/v1/alerts",
    tags=["Live Feed"],
    dependencies=[Depends(require_tier("analyst"))],
)
async def alerts(limit: int = Query(default=20, le=100)):
    """Recent system alerts."""
    r = get_redis()
    raw_list = r.lrange(REDIS_KEYS["alerts"], 0, limit - 1) or []
    result = []
    for raw in raw_list:
        try:
            result.append(json.loads(raw))
        except Exception:
            continue
    return {"alerts": result}


# ═══════════════════════════════════════════════════════════════
#  STRATEGIST+ ENDPOINTS
# ═══════════════════════════════════════════════════════════════

@app.get(
    "/api/v1/signals",
    tags=["Intel"],
    dependencies=[Depends(require_tier("strategist"))],
)
async def signals():
    """JIM Bridge signal analysis (last decision context)."""
    r = get_redis()
    status = r.get(REDIS_KEYS["status"])
    pnl_report = r.get(REDIS_KEYS["pnl"])

    return {
        "status": json.loads(status) if status else None,
        "last_report": json.loads(pnl_report) if pnl_report else None,
        "risk_config": _read_risk_config(r),
    }


# ═══════════════════════════════════════════════════════════════
#  OPERATOR+ ENDPOINTS
# ═══════════════════════════════════════════════════════════════

@app.get(
    "/api/v1/engine",
    tags=["Engine"],
    dependencies=[Depends(require_tier("operator"))],
)
async def engine_status():
    """Full engine room: MT5 bridge, macro calendar, risk config."""
    r = get_redis()
    return {
        "engine": _read_engine_status(r),
        "risk_config": _read_risk_config(r),
        "defcon": int(r.get(REDIS_KEYS["defcon"]) or "1"),
        "budget": float(r.get(REDIS_KEYS["nemesis_budget"]) or "0"),
    }


@app.get(
    "/api/v1/nemesis/observability/unified",
    tags=["Observability"],
)
async def nemesis_unified_observability(limit: int = Query(default=100, ge=10, le=500)):
    """
    Unified observability view for T-029:
    CEX/MT5/prediction decisions + policy blocks + PnL snapshot in one response.
    """
    r = get_redis()
    stats = _read_aggregated_stats(r)
    prediction_stats = _safe_json(r.get("kernell:nemesis:prediction:stats"), {})

    # Unified decision ledger v2 from Nemesis (CEX/MT5/prediction lane events).
    raw_ledger = r.lrange("kernell:nemesis:decision_ledger:v2", 0, limit - 1) or []
    ledger = []
    for raw in raw_ledger:
        parsed = _safe_json(raw, None)
        if parsed:
            ledger.append(parsed)

    # Economic audit mirror (cross-domain events, includes prediction when appended there).
    raw_econ = r.lrange("kernell:audit:economic_ledger", 0, limit - 1) or []
    econ_events = []
    for raw in raw_econ:
        parsed = _safe_json(raw, None)
        if parsed:
            econ_events.append(parsed)

    def _event_type(ev: dict) -> str:
        return str(ev.get("type") or ev.get("action") or "unknown")

    fills = sum(1 for ev in ledger if _event_type(ev) in {"prediction_fill", "trade_opened", "trade_closed"})
    blocks = sum(
        1
        for ev in ledger
        if _event_type(ev) in {"prediction_blocked", "prediction_gate_blocked", "trade_gate_check"}
        and (
            "blocked" in str(ev.get("outcome", "")).lower()
            or "limit" in str(ev.get("outcome", "")).lower()
            or ev.get("allowed") is False
        )
    )

    venue_counts = {}
    for ev in ledger:
        venue = str(ev.get("venue") or "unknown")
        venue_counts[venue] = venue_counts.get(venue, 0) + 1

    return {
        "ok": True,
        "ts": time.time(),
        "summary": {
            "decision_events": len(ledger),
            "economic_events": len(econ_events),
            "fills": fills,
            "policy_blocks": blocks,
            "venues": venue_counts,
        },
        "pnl": stats.get("pnl", {}),
        "trades": stats.get("trades", {}),
        "risk": stats.get("risk", {}),
        "prediction": {
            "stats": prediction_stats,
            "last_fill": _safe_json(r.get("kernell:nemesis:prediction:last_fill"), {}),
        },
        "decision_ledger": ledger,
        "economic_ledger": econ_events,
    }


# ═══════════════════════════════════════════════════════════════
#  GOVERNOR ENDPOINTS (Governance)
# ═══════════════════════════════════════════════════════════════

@app.get(
    "/api/v1/governance/proposals",
    tags=["Governance"],
    dependencies=[Depends(require_tier("governor"))],
)
async def get_proposals():
    """List all governance proposals."""
    return {"proposals": _governance.get_all_proposals()}


@app.post(
    "/api/v1/governance/propose",
    tags=["Governance"],
)
async def create_proposal(
    parameter: str,
    proposed_value: float,
    rationale: str,
    user: dict = Depends(require_tier("governor")),
):
    """Create a new governance proposal (Governor only)."""
    proposal = _governance.create_proposal(
        parameter=parameter,
        proposed_value=proposed_value,
        rationale=rationale,
        proposer=user.get("sub", "anonymous"),
        kern_balance=user.get("kern_balance", 0),
    )
    if not proposal:
        raise HTTPException(status_code=400, detail="Invalid proposal parameters")
    return {"proposal": proposal.to_dict()}


@app.post(
    "/api/v1/governance/vote",
    tags=["Governance"],
)
async def cast_vote(
    proposal_id: str,
    direction: str,
    user: dict = Depends(require_tier("governor")),
):
    """Cast a vote on a governance proposal."""
    result = _governance.cast_vote(
        proposal_id=proposal_id,
        voter=user.get("sub", "anonymous"),
        direction=direction,
        kern_balance=user.get("kern_balance", 0),
    )
    if result and "error" in result:
        raise HTTPException(status_code=400, detail=result["error"])
    return result


# ═══════════════════════════════════════════════════════════════
#  WEBSOCKET ENDPOINT
# ═══════════════════════════════════════════════════════════════

@app.websocket("/ws/live")
async def websocket_endpoint(
    websocket: WebSocket,
    token: Optional[str] = Query(default=None),
):
    """
    Live WebSocket feed for real-time trading data.

    Requires JWT token in query string: /ws/live?token=<jwt>
    Minimum tier: analyst

    Channels broadcasted:
      - stats:     Aggregated performance (every 5s)
      - trades:    Recent trade executions (real-time)
      - positions: Open positions update (every 2s)
      - alerts:    System alerts
      - signals:   ML signal data (strategist+)
      - engine:    Engine room data (operator+)
    """
    # Authenticate WebSocket
    if not token:
        await websocket.close(code=4001, reason="Token required")
        return

    claims = decode_jwt(token)
    if not claims:
        await websocket.close(code=4001, reason="Invalid or expired token")
        return

    tier = claims.get("tier", "public")
    tier_idx = TIER_ORDER.index(tier) if tier in TIER_ORDER else 0
    analyst_idx = TIER_ORDER.index("analyst")

    if tier_idx < analyst_idx:
        await websocket.close(
            code=4003,
            reason=f"Tier '{tier}' insufficient. Need 'analyst' or higher.",
        )
        return

    pubkey = claims.get("sub", "unknown")
    client = await _ws_manager.connect(websocket, pubkey, tier)

    try:
        # Send initial snapshot
        r = get_redis()
        await _ws_manager.send_personal(client, "snapshot", {
            "stats": _read_aggregated_stats(r),
            "positions": _read_positions(r),
            "recent_trades": _read_recent_trades(r, limit=10),
        })

        # Keep connection alive, listen for client messages
        while True:
            data = await websocket.receive_text()
            # Client can send ping or subscribe/unsubscribe messages
            try:
                msg = json.loads(data)
                if msg.get("type") == "ping":
                    await _ws_manager.send_personal(client, "pong", {"ts": time.time()})
            except Exception:
                pass

    except WebSocketDisconnect:
        await _ws_manager.disconnect(client)
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
        await _ws_manager.disconnect(client)


# ═══════════════════════════════════════════════════════════════
#  DEVSTUDIO — Cognitive Execution Runtime
# ═══════════════════════════════════════════════════════════════

try:
    from agents.core.devstudio.api import router as devstudio_router, init_engine as init_devstudio
    app.include_router(devstudio_router)
    # Initialize DevStudio engine (no Redis required for MVP)
    init_devstudio(redis=None)
    logger.info("🧠 DevStudio router mounted at /api/v1/devstudio")
except ImportError as e:
    logger.warning(f"DevStudio not available: {e}")
except Exception as e:
    logger.warning(f"DevStudio init failed: {e}")


# ═══════════════════════════════════════════════════════════════
#  RUN
# ═══════════════════════════════════════════════════════════════

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "services.control_room.api:app",
        host=API_HOST,
        port=API_PORT,
        reload=True,
    )
