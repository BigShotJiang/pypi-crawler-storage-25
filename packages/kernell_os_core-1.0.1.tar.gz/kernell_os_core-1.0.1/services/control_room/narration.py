"""
🎙️ Nemesis Narration Engine — AI Trade Commentary
====================================================
Translates raw trading decisions into dramatic, investor-facing
narrations using Claude API. Broadcasts via WebSocket for the
"show mediático" live feed.

Architecture:
  Redis PubSub (journal events) → Claude Haiku → Redis list → WS broadcast

Redis Keys:
  - nemesis:narrations       (List — last 50 narrations, newest last)
  - nemesis:last_action      (String — latest action description)

Usage:
    engine = NarrationEngine(redis_client, ws_manager)
    asyncio.create_task(engine.run())
"""

import asyncio
import json
import logging
import os
import time
from typing import Optional

import redis

logger = logging.getLogger("control_room.narration")

ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")
NARRATION_MODEL = os.getenv("NARRATION_MODEL", "claude-haiku-4-20250414")
MAX_NARRATIONS = 50
NARRATION_SYSTEM_PROMPT = """Eres el narrador oficial de Nemesis, un agente de trading autónomo de grado institucional operando en Forex/Metales vía MetaTrader 5.

Tu tarea: Traducir decisiones de trading crudas en narración dramática y confiada de 2-3 oraciones en español.

Reglas:
- Sé preciso con los datos (símbolo, dirección, P&L)
- Tono: confiado, institucional, cinematográfico — como un narrador de Bloomberg con personalidad
- No uses emojis excesivos — máximo uno al inicio
- Si es un trade ganador, celebra con confianza contenida
- Si es una pérdida, mantenga compostura y enfoca en la gestión del riesgo
- Nunca inventes datos que no estén en el input
- Responde SOLO con la narración, sin prefijos ni explicaciones"""


class NarrationEngine:
    """
    Generates AI narrations for trade events and broadcasts them.
    """

    def __init__(self, redis_client: redis.Redis, ws_manager=None):
        self.redis = redis_client
        self.ws_manager = ws_manager
        self._client = None
        self._enabled = bool(ANTHROPIC_API_KEY)

        if not self._enabled:
            logger.warning(
                "⚠️ Narration Engine disabled — ANTHROPIC_API_KEY not set. "
                "Narrations will use fallback templates."
            )

    def _get_client(self):
        """Lazy-init Anthropic client."""
        if self._client is None and self._enabled:
            try:
                import anthropic
                self._client = anthropic.AsyncAnthropic(api_key=ANTHROPIC_API_KEY)
            except ImportError:
                logger.error("anthropic package not installed. pip install anthropic")
                self._enabled = False
        return self._client

    async def run(self):
        """
        Main narration loop. Polls Redis journal for new entries
        and generates narrations for each.
        """
        logger.info("🎙️ Narration Engine started")
        last_journal_len = self.redis.llen("NEMESIS:risk:journal") or 0

        while True:
            try:
                current_len = self.redis.llen("NEMESIS:risk:journal") or 0

                if current_len > last_journal_len:
                    # Process new journal entries
                    new_entries = self.redis.lrange(
                        "NEMESIS:risk:journal",
                        last_journal_len,
                        current_len - 1
                    )
                    for raw in new_entries:
                        try:
                            entry = json.loads(raw)
                            await self._process_trade_event(entry)
                        except Exception as e:
                            logger.error(f"Narration error for entry: {e}")

                    last_journal_len = current_len

            except Exception as e:
                logger.error(f"Narration loop error: {e}")

            await asyncio.sleep(3)

    async def _process_trade_event(self, event: dict):
        """Generate and broadcast narration for a trade event."""
        narration_text = await self._generate_narration(event)
        if not narration_text:
            return

        narration = {
            "text": narration_text,
            "event_type": event.get("status", "UNKNOWN"),
            "symbol": event.get("symbol", ""),
            "pnl": event.get("pnl"),
            "timestamp": time.time(),
        }

        # Store in Redis (capped list)
        self.redis.rpush("nemesis:narrations", json.dumps(narration))
        self.redis.ltrim("nemesis:narrations", -MAX_NARRATIONS, -1)

        # Update last action
        action_desc = self._format_action(event)
        self.redis.set("nemesis:last_action", action_desc)

        # Broadcast via WebSocket
        if self.ws_manager:
            await self.ws_manager.broadcast("narration", narration)

        logger.info(f"🎙️ Narration: {narration_text[:80]}...")

    async def _generate_narration(self, event: dict) -> Optional[str]:
        """Generate narration via Claude API or fallback template."""
        # Build context
        status = event.get("status", "")
        symbol = event.get("symbol", "N/A")
        side = event.get("side", "")
        pnl = event.get("pnl")
        lot_size = event.get("lot_size", "")
        entry_price = event.get("entry_price", "")
        exit_price = event.get("exit_price", "")

        if status == "OPEN":
            prompt = (
                f"Trade ABIERTO: {side.upper()} {lot_size} lotes de {symbol} "
                f"a precio de entrada {entry_price}."
            )
        elif status == "CLOSED":
            result = "ganancia" if (pnl and pnl > 0) else "pérdida"
            prompt = (
                f"Trade CERRADO: {symbol} con {result} de ${pnl:.2f} USD. "
                f"Precio de salida: {exit_price}."
            )
        else:
            return None

        # Try Claude API
        if self._enabled:
            try:
                client = self._get_client()
                if client:
                    message = await client.messages.create(
                        model=NARRATION_MODEL,
                        max_tokens=200,
                        system=NARRATION_SYSTEM_PROMPT,
                        messages=[{"role": "user", "content": prompt}],
                    )
                    return message.content[0].text
            except Exception as e:
                logger.error(f"Claude API error: {e}")

        # Fallback templates
        return self._fallback_narration(event)

    def _fallback_narration(self, event: dict) -> str:
        """Generate narration without Claude API."""
        status = event.get("status", "")
        symbol = event.get("symbol", "N/A")
        side = event.get("side", "")
        pnl = event.get("pnl")
        lot_size = event.get("lot_size", "")

        if status == "OPEN":
            return (
                f"⚡ Nemesis abre posición {side.upper()} en {symbol} — "
                f"{lot_size} lotes desplegados. El algoritmo ha identificado "
                f"una ventana de oportunidad. Ejecución instantánea."
            )
        elif status == "CLOSED" and pnl is not None:
            if pnl > 0:
                return (
                    f"🟢 Operación en {symbol} cerrada con +${pnl:.2f} de ganancia. "
                    f"Nemesis extrae beneficio con precisión quirúrgica. "
                    f"El capital de los Governors crece."
                )
            else:
                return (
                    f"🔴 Nemesis cierra {symbol} con -${abs(pnl):.2f}. "
                    f"Pérdida controlada dentro de los parámetros de riesgo. "
                    f"El Risk Manager contiene el daño — la disciplina es el edge."
                )
        return f"📡 Nemesis procesa evento en {symbol}."

    def _format_action(self, event: dict) -> str:
        """Format a short action string for the health endpoint."""
        status = event.get("status", "")
        symbol = event.get("symbol", "N/A")
        side = event.get("side", "")
        pnl = event.get("pnl")

        if status == "OPEN":
            return f"{side.upper()} {symbol}"
        elif status == "CLOSED":
            result = f"+${pnl:.2f}" if pnl and pnl > 0 else f"-${abs(pnl or 0):.2f}"
            return f"CLOSED {symbol} ({result})"
        return f"EVENT {symbol}"

    def get_recent(self, limit: int = 20) -> list:
        """Get recent narrations from Redis."""
        raw_list = self.redis.lrange("nemesis:narrations", -limit, -1) or []
        result = []
        for raw in reversed(raw_list):
            try:
                result.append(json.loads(raw))
            except Exception:
                continue
        return result
