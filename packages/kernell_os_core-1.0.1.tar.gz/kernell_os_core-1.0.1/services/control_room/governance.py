"""
🏦 Nemesis Control Room — Governance Engine
=============================================
On-chain-inspired voting system for $KERN holders.

Governors can propose and vote on Nemesis risk parameters,
burn rates, and strategy allocations.

All proposals are stored in Redis and consumed by agents.
"""

import json
import time
import uuid
import logging
from datetime import datetime, timezone
from typing import Dict, List, Optional
from dataclasses import dataclass, asdict

logger = logging.getLogger("control_room.governance")


# ═══════════════════════════════════════════════════════════════
#  DATA MODELS
# ═══════════════════════════════════════════════════════════════

GOVERNABLE_PARAMS = {
    "max_daily_drawdown_pct": {"min": 1.0, "max": 10.0, "type": float, "target": "risk"},
    "max_per_trade_risk_pct": {"min": 0.5, "max": 3.0, "type": float, "target": "risk"},
    "kelly_fraction": {"min": 0.1, "max": 0.5, "type": float, "target": "risk"},
    "max_concurrent_positions": {"min": 1, "max": 10, "type": int, "target": "risk"},
    "max_daily_trades": {"min": 3, "max": 50, "type": int, "target": "risk"},
    "burn_rate": {"min": 0.05, "max": 0.70, "type": float, "target": "cap"},
    "revenue_share_pct": {"min": 0.10, "max": 0.25, "type": float, "target": "economy"},
    "strategy_forex_pct": {"min": 0.0, "max": 1.0, "type": float, "target": "strategy"},
}


@dataclass
class Proposal:
    id: str
    title: str
    parameter: str
    current_value: float
    proposed_value: float
    rationale: str
    proposer: str            # Wallet pubkey
    created_at: float        # Unix timestamp
    expires_at: float        # Voting deadline
    status: str              # "active" | "passed" | "rejected" | "executed" | "vetoed"
    votes_for: int           # Total $KERN weight FOR
    votes_against: int       # Total $KERN weight AGAINST
    votes_abstain: int       # Total $KERN weight ABSTAIN
    voter_count: int
    quorum_required: int     # 10% of staked supply
    execution_after: float   # Timelock: 48h after passing

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "Proposal":
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})


@dataclass
class Vote:
    proposal_id: str
    voter: str               # Wallet pubkey
    direction: str           # "for" | "against" | "abstain"
    weight: int              # $KERN balance at snapshot
    timestamp: float


class GovernanceEngine:
    """
    Manages governance proposals and voting for the Control Room.

    Architecture:
      - Proposals stored in Redis list: kernell:governance:proposals
      - Votes stored in Redis hash: kernell:governance:votes:{proposal_id}
      - Approved proposals queued: kernell:governance:approved_proposals
      - Architect veto channel: kernell:governance:veto
    """

    VOTING_PERIOD_HOURS = 72       # 3 days to vote
    TIMELOCK_HOURS = 48            # 48h after passing before execution
    QUORUM_PCT = 0.10              # 10% of staked supply must vote
    PASS_THRESHOLD = 0.60          # 60% weighted votes to pass

    def __init__(self, redis_client):
        self.redis = redis_client

    def create_proposal(
        self,
        parameter: str,
        proposed_value: float,
        rationale: str,
        proposer: str,
        kern_balance: int,
    ) -> Optional[Proposal]:
        """Create a new governance proposal."""

        # Validate parameter
        if parameter not in GOVERNABLE_PARAMS:
            logger.warning(f"Invalid parameter: {parameter}")
            return None

        param_def = GOVERNABLE_PARAMS[parameter]

        # Validate proposed value range
        if not (param_def["min"] <= proposed_value <= param_def["max"]):
            logger.warning(
                f"Value {proposed_value} out of range "
                f"[{param_def['min']}, {param_def['max']}] for {parameter}"
            )
            return None

        # Get current value from Redis
        current_value = self._get_current_value(parameter)

        now = time.time()
        proposal = Proposal(
            id=f"GOV-{uuid.uuid4().hex[:8].upper()}",
            title=f"Adjust {parameter} → {proposed_value}",
            parameter=parameter,
            current_value=current_value,
            proposed_value=proposed_value,
            rationale=rationale,
            proposer=proposer,
            created_at=now,
            expires_at=now + (self.VOTING_PERIOD_HOURS * 3600),
            status="active",
            votes_for=0,
            votes_against=0,
            votes_abstain=0,
            voter_count=0,
            quorum_required=self._get_quorum_threshold(),
            execution_after=0,
        )

        # Store in Redis
        self.redis.rpush(
            "kernell:governance:proposals",
            json.dumps(proposal.to_dict()),
        )

        logger.info(
            f"📜 Proposal created: {proposal.id} | "
            f"{parameter}: {current_value} → {proposed_value} | "
            f"by {proposer[:12]}..."
        )
        return proposal

    def cast_vote(
        self,
        proposal_id: str,
        voter: str,
        direction: str,
        kern_balance: int,
    ) -> Optional[dict]:
        """Cast a vote on an active proposal."""

        if direction not in ("for", "against", "abstain"):
            return {"error": "Invalid direction. Must be: for, against, abstain"}

        # Check if already voted
        vote_key = f"kernell:governance:votes:{proposal_id}"
        if self.redis.hexists(vote_key, voter):
            return {"error": "Already voted on this proposal"}

        # Find the proposal
        proposal = self._find_proposal(proposal_id)
        if not proposal:
            return {"error": "Proposal not found"}

        if proposal.status != "active":
            return {"error": f"Proposal is {proposal.status}, not active"}

        if time.time() > proposal.expires_at:
            return {"error": "Voting period has ended"}

        # Record vote
        vote = Vote(
            proposal_id=proposal_id,
            voter=voter,
            direction=direction,
            weight=kern_balance,
            timestamp=time.time(),
        )
        self.redis.hset(vote_key, voter, json.dumps(asdict(vote)))

        # Update tallies
        if direction == "for":
            proposal.votes_for += kern_balance
        elif direction == "against":
            proposal.votes_against += kern_balance
        else:
            proposal.votes_abstain += kern_balance
        proposal.voter_count += 1

        self._update_proposal(proposal)

        logger.info(
            f"🗳️ Vote: {voter[:12]}... voted {direction} on {proposal_id} "
            f"(weight: {kern_balance:,} $KERN)"
        )

        return {
            "status": "voted",
            "proposal_id": proposal_id,
            "direction": direction,
            "weight": kern_balance,
        }

    def check_and_finalize(self):
        """
        Check all active proposals for quorum/passing.
        Called periodically by the API.
        """
        proposals = self._get_all_proposals()

        for p in proposals:
            if p.status != "active":
                continue

            # Check if expired
            if time.time() > p.expires_at:
                total_votes = p.votes_for + p.votes_against + p.votes_abstain

                if total_votes < p.quorum_required:
                    p.status = "rejected"
                    logger.info(f"❌ Proposal {p.id} rejected: quorum not met")
                elif p.votes_for / max(p.votes_for + p.votes_against, 1) >= self.PASS_THRESHOLD:
                    p.status = "passed"
                    p.execution_after = time.time() + (self.TIMELOCK_HOURS * 3600)
                    # Queue for execution after timelock
                    self.redis.rpush(
                        "kernell:governance:approved_proposals",
                        json.dumps(p.to_dict()),
                    )
                    logger.info(f"✅ Proposal {p.id} PASSED. Timelock: {self.TIMELOCK_HOURS}h")
                else:
                    p.status = "rejected"
                    logger.info(f"❌ Proposal {p.id} rejected: insufficient votes")

                self._update_proposal(p)

    def architect_veto(self, proposal_id: str, reason: str) -> bool:
        """Architect (Anny) vetoes a passed proposal. Constitutional override."""
        proposal = self._find_proposal(proposal_id)
        if not proposal:
            return False

        proposal.status = "vetoed"
        self._update_proposal(proposal)

        # Remove from execution queue
        approved = self.redis.lrange("kernell:governance:approved_proposals", 0, -1)
        for i, raw in enumerate(approved):
            p = json.loads(raw)
            if p.get("id") == proposal_id:
                self.redis.lrem("kernell:governance:approved_proposals", 1, raw)
                break

        logger.warning(f"🔒 ARCHITECT VETO on {proposal_id}: {reason}")
        return True

    def get_active_proposals(self) -> List[dict]:
        """Get all active proposals for the governance UI."""
        proposals = self._get_all_proposals()
        return [p.to_dict() for p in proposals if p.status == "active"]

    def get_all_proposals(self) -> List[dict]:
        """Get all proposals (any status)."""
        return [p.to_dict() for p in self._get_all_proposals()]

    # ── Helpers ──────────────────────────────────────────────────

    def _find_proposal(self, proposal_id: str) -> Optional[Proposal]:
        for p in self._get_all_proposals():
            if p.id == proposal_id:
                return p
        return None

    def _get_all_proposals(self) -> List[Proposal]:
        raw_list = self.redis.lrange("kernell:governance:proposals", 0, -1)
        proposals = []
        for raw in raw_list:
            try:
                proposals.append(Proposal.from_dict(json.loads(raw)))
            except Exception:
                continue
        return proposals

    def _update_proposal(self, proposal: Proposal):
        """Update a proposal in the Redis list (replace by ID)."""
        all_raw = self.redis.lrange("kernell:governance:proposals", 0, -1)
        for i, raw in enumerate(all_raw):
            try:
                p = json.loads(raw)
                if p.get("id") == proposal.id:
                    self.redis.lset(
                        "kernell:governance:proposals",
                        i,
                        json.dumps(proposal.to_dict()),
                    )
                    return
            except Exception:
                continue

    def _get_current_value(self, parameter: str) -> float:
        """Read current value of a governable parameter."""
        try:
            target = GOVERNABLE_PARAMS[parameter]["target"]
            if target == "risk":
                config = self.redis.hgetall("NEMESIS:risk:config")
                return float(config.get(parameter, "0"))
            elif target == "cap":
                cap = json.loads(self.redis.get("kernell:economy:cap_state") or "{}")
                return float(cap.get("active_burn_rate", 0.20))
            elif target == "economy":
                return 0.15  # Default revenue share
            else:
                return 0.5
        except Exception:
            return 0.0

    def _get_quorum_threshold(self) -> int:
        """Get quorum as 10% of some reference supply."""
        # For now: 10% of 100M total supply = 10M $KERN in weighted votes
        return int(100_000_000 * self.QUORUM_PCT)
