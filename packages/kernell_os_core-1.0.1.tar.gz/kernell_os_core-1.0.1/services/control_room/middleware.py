"""
🛡️ Nemesis Control Room — Middleware
======================================
Tier-based access control, rate limiting, and JWT extraction.
"""

import time
import logging
from collections import defaultdict
from typing import Optional

from fastapi import Request, HTTPException, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials

from services.control_room.auth import decode_jwt
from services.control_room.config import TIERS, TIER_ORDER

logger = logging.getLogger("control_room.middleware")

security = HTTPBearer(auto_error=False)


# ═══════════════════════════════════════════════════════════════
#  RATE LIMITER (in-memory sliding window)
# ═══════════════════════════════════════════════════════════════

class RateLimiter:
    """Simple sliding-window rate limiter per IP/pubkey."""

    def __init__(self):
        self._requests: dict[str, list[float]] = defaultdict(list)

    def check(self, key: str, limit: int, window: int = 60) -> bool:
        """Returns True if request is allowed."""
        now = time.time()
        cutoff = now - window

        # Clean old entries
        self._requests[key] = [t for t in self._requests[key] if t > cutoff]

        if len(self._requests[key]) >= limit:
            return False

        self._requests[key].append(now)
        return True


_rate_limiter = RateLimiter()


# ═══════════════════════════════════════════════════════════════
#  JWT EXTRACTION + TIER CHECK
# ═══════════════════════════════════════════════════════════════

async def get_current_user(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(security),
) -> Optional[dict]:
    """
    Extract and decode JWT from Authorization header.
    Returns user claims or None for unauthenticated requests.
    """
    if credentials is None:
        return None

    claims = decode_jwt(credentials.credentials)
    return claims


def require_tier(min_tier: str):
    """
    Dependency factory: ensures the caller has at least `min_tier` access.

    Usage:
        @app.get("/api/v1/signals", dependencies=[Depends(require_tier("strategist"))])
    """
    min_index = TIER_ORDER.index(min_tier)

    async def _check(
        request: Request,
        user: Optional[dict] = Depends(get_current_user),
    ):
        # Determine user tier
        if user is None:
            user_tier = "public"
            rate_key = request.client.host if request.client else "unknown"
        else:
            user_tier = user.get("tier", "public")
            rate_key = user.get("sub", request.client.host if request.client else "unknown")

        user_index = TIER_ORDER.index(user_tier) if user_tier in TIER_ORDER else 0

        # Tier check
        if user_index < min_index:
            raise HTTPException(
                status_code=403,
                detail={
                    "error": "Insufficient access tier",
                    "code": "TIER_INSUFFICIENT",
                    "your_tier": user_tier,
                    "required_tier": min_tier,
                    "required_kern": TIERS[min_tier].min_kern,
                },
            )

        # Rate limit check
        tier_def = TIERS.get(user_tier, TIERS["public"])
        if not _rate_limiter.check(rate_key, tier_def.rate_limit):
            raise HTTPException(
                status_code=429,
                detail={
                    "error": "Rate limit exceeded",
                    "code": "RATE_LIMIT",
                    "limit": tier_def.rate_limit,
                    "tier": user_tier,
                },
            )

        return user

    return _check
