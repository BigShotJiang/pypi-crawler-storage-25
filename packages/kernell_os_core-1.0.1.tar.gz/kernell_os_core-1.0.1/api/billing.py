"""
Kernell OS — Stripe Billing Module
Handles checkout sessions, webhooks, and KERN credit top-ups.
"""
import stripe
import os
import json
from fastapi import APIRouter, Request, HTTPException, Header
from typing import Optional
from datetime import datetime

router = APIRouter(prefix="/api/v1/billing", tags=["billing"])

# ─── Config ─────────────────────────────────────────────────────────────
stripe.api_key = os.environ.get("STRIPE_SECRET_KEY", "")
WEBHOOK_SECRET = os.environ.get("STRIPE_WEBHOOK_SECRET", "")

# Plans: USD → KERN conversion
PLANS = {
    "starter": {"price_cents": 2900, "kern_credits": 5000, "label": "Starter"},
    "growth":  {"price_cents": 9900, "kern_credits": 25000, "label": "Growth"},
    "production": {"price_cents": 29900, "kern_credits": 100000, "label": "Production"},
}

# For ad-hoc top-ups: $1 = 100 KERN
USD_TO_KERN_RATE = 100


def _get_db():
    from api.app import get_db
    return get_db()


@router.get("/plans")
def list_plans():
    """Return available pricing plans."""
    return {
        "plans": [
            {
                "id": plan_id,
                "label": plan["label"],
                "price_usd": plan["price_cents"] / 100,
                "kern_credits": plan["kern_credits"],
                "price_per_kern": round(plan["price_cents"] / 100 / plan["kern_credits"], 5),
            }
            for plan_id, plan in PLANS.items()
        ]
    }


@router.post("/checkout")
def create_checkout_session(
    plan_id: str,
    x_api_key: Optional[str] = Header(None, alias="X-API-Key"),
):
    """Create a Stripe Checkout session for a specific plan."""
    if not stripe.api_key:
        raise HTTPException(status_code=503, detail="Billing not configured. Contact support.")

    if plan_id not in PLANS:
        raise HTTPException(status_code=400, detail=f"Invalid plan. Choose from: {list(PLANS.keys())}")

    plan = PLANS[plan_id]
    base_url = os.environ.get("APP_BASE_URL", "http://localhost:3000")

    try:
        session = stripe.checkout.Session.create(
            payment_method_types=["card"],
            line_items=[{
                "price_data": {
                    "currency": "usd",
                    "product_data": {
                        "name": f"Kernell OS — {plan['label']} Plan",
                        "description": f"{plan['kern_credits']:,} KERN credits for agent execution",
                    },
                    "unit_amount": plan["price_cents"],
                },
                "quantity": 1,
            }],
            mode="payment",
            success_url=f"{base_url}?payment=success&plan={plan_id}",
            cancel_url=f"{base_url}?payment=cancelled",
            metadata={
                "sandbox_key": x_api_key or "",
                "plan_id": plan_id,
                "kern_credits": str(plan["kern_credits"]),
            },
        )
        return {"checkout_url": session.url, "session_id": session.id}
    except stripe.error.StripeError as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/webhook")
async def stripe_webhook(request: Request):
    """
    Handle Stripe webhook events.
    On successful payment → top-up KERN credits.
    Idempotent: checks event ID to prevent double-crediting.
    """
    payload = await request.body()
    sig_header = request.headers.get("stripe-signature", "")

    try:
        event = stripe.Webhook.construct_event(payload, sig_header, WEBHOOK_SECRET)
    except (ValueError, stripe.error.SignatureVerificationError):
        raise HTTPException(status_code=400, detail="Invalid webhook signature")

    event_id = event["id"]
    conn = _get_db()
    c = conn.cursor()

    try:
        c.execute("BEGIN TRANSACTION")

        # ── Idempotency Check ───────────────────────────────────────────────
        c.execute("SELECT event_id FROM processed_events WHERE event_id = ?", (event_id,))
        if c.fetchone():
            conn.commit()
            conn.close()
            return {"status": "ignored", "reason": "already processed"}

        # ── Only handle completed checkouts ──────────────────────────────
        if event["type"] == "checkout.session.completed":
            session = event["data"]["object"]
            meta = session.get("metadata", {})
            sandbox_key = meta.get("sandbox_key", "")
            kern_to_add = int(meta.get("kern_credits", "0"))

            if sandbox_key:
                c.execute("SELECT credits_kern FROM users WHERE api_key = ?", (sandbox_key,))
                user = c.fetchone()
                if user:
                    new_expires_at = datetime(2099, 12, 31).isoformat()
                    
                    c.execute(
                        "UPDATE users SET credits_kern = credits_kern + ?, expires_at = ? WHERE api_key = ?",
                        (kern_to_add, new_expires_at, sandbox_key)
                    )

                    # Persist payment event separately for audit
                    os.makedirs("data", exist_ok=True)
                    with open("data/payments.jsonl", "a") as f:
                        f.write(json.dumps({
                            "event_id": event_id,
                            "sandbox_key_hash": hash(sandbox_key), # Ocultando API key de logs
                            "plan": meta.get("plan_id"),
                            "kern_added": kern_to_add,
                            "amount_usd": session.get("amount_total", 0) / 100,
                            "timestamp": datetime.utcnow().isoformat(),
                        }) + "\n")

        # Mark as processed
        c.execute("INSERT INTO processed_events (event_id, processed_at) VALUES (?, ?)", (event_id, datetime.utcnow().isoformat()))
        conn.commit()
    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=500, detail="Webhook processing failed")
    finally:
        conn.close()

    return {"received": True}
