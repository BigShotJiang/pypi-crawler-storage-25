#!/usr/bin/env python3
"""
🧬 KERNELL OS — DATA FUSION ENGINE v1.0
==========================================
Correlates data across ALL agent silos into a Unified Ontology.
This is the key architectural piece that bridges the gap to Palantir-grade.

ARCHITECTURE:
    Redis (23 agents, ~60 key namespaces)
        ↓ EntityExtractor
    Unified Entities (Product, Customer, Decision, Trend, Campaign)
        ↓ FusionPipeline
    Qdrant (kernell_memory collection, 768-dim embeddings)
        ↓ CorrelationEngine
    Cross-domain insights (trend → product → campaign → revenue)

ENTITY TYPES:
    Product   — from Sourcer, Fulfillment, Ads
    Customer  — from Fulfillment, Engagement
    Decision  — from Mentor, Distiller, Playmaker
    Trend     — from Trends, Hunter
    Campaign  — from Ads, Herald, Engagement
    Pattern   — from Distiller, Playmaker
    Order     — from Fulfillment
    Revenue   — from Economy, Fulfillment

USAGE:
    engine = DataFusionEngine(redis_client)
    engine.run_fusion_cycle()            # Periodic (Chronos: every 2h)
    engine.query("products trending now") # Natural language query
    engine.correlate("trend", "moda")     # Cross-domain correlation

Author: Kernell OS Autonomous Build
"""

import os
import sys
import json
import time
import hashlib
import logging
from pathlib import Path
from datetime import datetime, timezone, timedelta
from dataclasses import dataclass, field, asdict
from typing import Optional, Dict, List, Any, Tuple
from enum import Enum

logger = logging.getLogger("DATA_FUSION")

KERNELL_ROOT = Path(os.getenv("KERNELL_ROOT", "/home/anny/kernell-os"))

# ══════════════════════════════════════════════════════════════════════════════
# ENTITY MODEL — Unified Ontology Types
# ══════════════════════════════════════════════════════════════════════════════

class EntityType(str, Enum):
    PRODUCT   = "product"
    CUSTOMER  = "customer"
    DECISION  = "decision"
    TREND     = "trend"
    CAMPAIGN  = "campaign"
    PATTERN   = "pattern"
    ORDER     = "order"
    REVENUE   = "revenue"
    AGENT     = "agent"


@dataclass
class FusionEntity:
    """Universal entity that lives in the Unified Ontology."""
    entity_id:    str
    entity_type:  str                # EntityType value
    name:         str                # Human-readable label
    source_agent: str                # Which agent produced this
    source_key:   str                # Redis key origin
    data:         Dict[str, Any]     # Raw payload
    tags:         List[str] = field(default_factory=list)
    relations:    List[Dict] = field(default_factory=list)  # [{target_id, relation_type, weight}]
    created_at:   str = ""
    updated_at:   str = ""
    confidence:   float = 1.0        # 0.0 - 1.0
    embedding:    List[float] = field(default_factory=list)

    def __post_init__(self):
        now = datetime.now(timezone.utc).isoformat()
        if not self.created_at:
            self.created_at = now
        if not self.updated_at:
            self.updated_at = now

    def to_dict(self) -> Dict:
        d = asdict(self)
        d.pop("embedding", None)  # Don't serialize embedding in payload
        return d

    def content_hash(self) -> str:
        """Content-based dedup hash."""
        key_data = f"{self.entity_type}:{self.source_agent}:{self.source_key}:{json.dumps(self.data, sort_keys=True, default=str)}"
        return hashlib.md5(key_data.encode()).hexdigest()[:16]


# ══════════════════════════════════════════════════════════════════════════════
# ENTITY EXTRACTORS — Pull data from each agent's Redis namespace
# ══════════════════════════════════════════════════════════════════════════════

class EntityExtractor:
    """Extracts FusionEntities from Redis agent data."""

    def __init__(self, redis_client):
        self._r = redis_client

    def extract_all(self) -> List[FusionEntity]:
        """Extract entities from all known agent namespaces."""
        entities = []
        entities.extend(self._extract_trends())
        entities.extend(self._extract_products())
        entities.extend(self._extract_orders())
        entities.extend(self._extract_decisions())
        entities.extend(self._extract_patterns())
        entities.extend(self._extract_playbooks())
        entities.extend(self._extract_engagement())
        entities.extend(self._extract_agents())
        return entities

    def _extract_trends(self) -> List[FusionEntity]:
        """Extract trend entities from Trends Agent."""
        entities = []
        try:
            raw = self._r.get("kernell:trends:current")
            if raw:
                data = json.loads(raw)
                trends = data if isinstance(data, list) else data.get("trends", [])
                for t in trends:
                    e = FusionEntity(
                        entity_id=f"trend-{hashlib.md5(t.get('term','').encode()).hexdigest()[:10]}",
                        entity_type=EntityType.TREND,
                        name=t.get("term", "unknown"),
                        source_agent="trends",
                        source_key="kernell:trends:current",
                        data=t,
                        tags=[t.get("platform", ""), t.get("niche", "")],
                        confidence=min(t.get("velocity", 50) / 100, 1.0),
                    )
                    entities.append(e)
        except Exception as ex:
            logger.warning(f"Trends extraction: {ex}")
        return entities

    def _extract_products(self) -> List[FusionEntity]:
        """Extract product entities from Sourcer Agent."""
        entities = []
        try:
            candidates = self._r.hgetall("kernell:sourcer:candidates") or {}
            for pid, raw in candidates.items():
                p = json.loads(raw) if isinstance(raw, str) else raw
                e = FusionEntity(
                    entity_id=f"product-{pid}",
                    entity_type=EntityType.PRODUCT,
                    name=p.get("name", pid),
                    source_agent="sourcer",
                    source_key=f"kernell:sourcer:candidates:{pid}",
                    data=p,
                    tags=[p.get("niche", ""), p.get("supplier", "")],
                    confidence=p.get("score", 50) / 100,
                )
                entities.append(e)

            approved = self._r.hgetall("kernell:sourcer:approved") or {}
            for pid, raw in approved.items():
                p = json.loads(raw) if isinstance(raw, str) else raw
                e = FusionEntity(
                    entity_id=f"product-{pid}",
                    entity_type=EntityType.PRODUCT,
                    name=p.get("name", pid),
                    source_agent="sourcer",
                    source_key=f"kernell:sourcer:approved:{pid}",
                    data={**p, "approved": True},
                    tags=[p.get("niche", ""), "approved"],
                    confidence=1.0,
                )
                entities.append(e)
        except Exception as ex:
            logger.warning(f"Products extraction: {ex}")
        return entities

    def _extract_orders(self) -> List[FusionEntity]:
        """Extract order entities from Fulfillment Agent."""
        entities = []
        try:
            orders = self._r.hgetall("kernell:fulfillment:orders") or {}
            for oid, raw in orders.items():
                o = json.loads(raw) if isinstance(raw, str) else raw
                e = FusionEntity(
                    entity_id=f"order-{oid}",
                    entity_type=EntityType.ORDER,
                    name=f"Order {oid}",
                    source_agent="fulfillment",
                    source_key=f"kernell:fulfillment:orders:{oid}",
                    data=o,
                    tags=[o.get("status", ""), o.get("country", "")],
                )
                # Link to product
                if o.get("product_id"):
                    e.relations.append({
                        "target_id": f"product-{o['product_id']}",
                        "relation_type": "order_of",
                        "weight": 1.0,
                    })
                # Link to customer
                if o.get("customer_email"):
                    cust_id = hashlib.md5(o["customer_email"].encode()).hexdigest()[:10]
                    e.relations.append({
                        "target_id": f"customer-{cust_id}",
                        "relation_type": "ordered_by",
                        "weight": 1.0,
                    })
                    # Also create customer entity
                    ce = FusionEntity(
                        entity_id=f"customer-{cust_id}",
                        entity_type=EntityType.CUSTOMER,
                        name=o.get("customer_name", "Unknown"),
                        source_agent="fulfillment",
                        source_key=f"kernell:fulfillment:orders:{oid}",
                        data={
                            "email": o.get("customer_email"),
                            "phone": o.get("customer_phone"),
                            "city": o.get("city"),
                            "country": o.get("country"),
                        },
                        tags=[o.get("city", ""), o.get("country", "")],
                    )
                    entities.append(ce)
                # Revenue entity
                if o.get("price_paid"):
                    re = FusionEntity(
                        entity_id=f"revenue-{oid}",
                        entity_type=EntityType.REVENUE,
                        name=f"Revenue from {oid}",
                        source_agent="fulfillment",
                        source_key=f"kernell:fulfillment:orders:{oid}",
                        data={
                            "revenue": o.get("price_paid", 0),
                            "cost": o.get("supplier_cost", 0),
                            "profit": o.get("price_paid", 0) - o.get("supplier_cost", 0),
                            "status": o.get("status"),
                        },
                        relations=[{"target_id": f"order-{oid}", "relation_type": "revenue_from", "weight": 1.0}],
                    )
                    entities.append(re)
                entities.append(e)
        except Exception as ex:
            logger.warning(f"Orders extraction: {ex}")
        return entities

    def _extract_decisions(self) -> List[FusionEntity]:
        """Extract decision entities from Mentor Agent."""
        entities = []
        try:
            decisions = self._r.lrange("kernell:mentor:decisions", 0, 199)
            for raw in decisions:
                d = json.loads(raw)
                did = d.get("decision_id", hashlib.md5(raw.encode()).hexdigest()[:10])
                e = FusionEntity(
                    entity_id=f"decision-{did}",
                    entity_type=EntityType.DECISION,
                    name=d.get("description", "")[:100],
                    source_agent="mentor",
                    source_key="kernell:mentor:decisions",
                    data=d,
                    tags=[d.get("type", ""), d.get("business", ""), d.get("platform", "")],
                    confidence=1.0 if d.get("outcome_measured") else 0.5,
                )
                entities.append(e)
        except Exception as ex:
            logger.warning(f"Decisions extraction: {ex}")
        return entities

    def _extract_patterns(self) -> List[FusionEntity]:
        """Extract pattern entities from Distiller Agent."""
        entities = []
        try:
            patterns = self._r.hgetall("kernell:distiller:patterns") or {}
            for pid, raw in patterns.items():
                p = json.loads(raw) if isinstance(raw, str) else raw
                e = FusionEntity(
                    entity_id=f"pattern-{pid}",
                    entity_type=EntityType.PATTERN,
                    name=p.get("name", pid),
                    source_agent="distiller",
                    source_key=f"kernell:distiller:patterns:{pid}",
                    data=p,
                    tags=[p.get("business", ""), p.get("type", "")],
                    confidence=p.get("confidence", 0.5),
                )
                entities.append(e)
        except Exception as ex:
            logger.warning(f"Patterns extraction: {ex}")
        return entities

    def _extract_playbooks(self) -> List[FusionEntity]:
        """Extract playbook entities from Playmaker Agent."""
        entities = []
        try:
            playbooks = self._r.hgetall("kernell:playmaker:playbooks") or {}
            for pbid, raw in playbooks.items():
                pb = json.loads(raw) if isinstance(raw, str) else raw
                e = FusionEntity(
                    entity_id=f"pattern-playbook-{pbid}",
                    entity_type=EntityType.PATTERN,
                    name=pb.get("name", pbid),
                    source_agent="playmaker",
                    source_key=f"kernell:playmaker:playbooks:{pbid}",
                    data=pb,
                    tags=[pb.get("agent_target", ""), pb.get("business", ""), "playbook"],
                    confidence=1.0 if pb.get("approved") else 0.6,
                )
                # Link to source pattern
                if pb.get("pattern_id"):
                    e.relations.append({
                        "target_id": f"pattern-{pb['pattern_id']}",
                        "relation_type": "implements",
                        "weight": 1.0,
                    })
                entities.append(e)
        except Exception as ex:
            logger.warning(f"Playbooks extraction: {ex}")
        return entities

    def _extract_engagement(self) -> List[FusionEntity]:
        """Extract engagement interaction entities."""
        entities = []
        try:
            handled = self._r.lrange("kernell:engagement:handled", 0, 99)
            for raw in handled:
                h = json.loads(raw)
                eid = h.get("comment_id", hashlib.md5(raw.encode()).hexdigest()[:10])
                e = FusionEntity(
                    entity_id=f"engagement-{eid}",
                    entity_type=EntityType.CAMPAIGN,
                    name=f"Engagement: {h.get('username', 'unknown')}",
                    source_agent="engagement",
                    source_key="kernell:engagement:handled",
                    data=h,
                    tags=[h.get("platform", ""), h.get("intent", ""), h.get("priority", "")],
                )
                entities.append(e)
        except Exception as ex:
            logger.warning(f"Engagement extraction: {ex}")
        return entities

    def _extract_agents(self) -> List[FusionEntity]:
        """Extract agent state entities from heartbeats."""
        entities = []
        agent_names = [
            "kernell", "atlas", "chronos", "sentinel", "forge", "nexus",
            "interface", "sierra", "overseer", "hunter", "archivista",
            "scribe", "fixer", "economy", "telegram_bridge", "herald",
            "ads", "nemesis", "prospector", "operator", "vector",
            "mentor", "distiller", "playmaker", "trends", "engagement",
            "sourcer", "fulfillment", "syncer",
        ]
        for name in agent_names:
            try:
                hb = self._r.get(f"kernell:agent:{name}:heartbeat")
                if hb:
                    e = FusionEntity(
                        entity_id=f"agent-{name}",
                        entity_type=EntityType.AGENT,
                        name=name.upper(),
                        source_agent=name,
                        source_key=f"kernell:agent:{name}:heartbeat",
                        data={
                            "heartbeat": float(hb),
                            "alive": True,
                            "age_seconds": time.time() - float(hb),
                        },
                        tags=["active"],
                    )
                    entities.append(e)
            except Exception:
                pass
        return entities


# ══════════════════════════════════════════════════════════════════════════════
# CORRELATION ENGINE — Cross-domain relationship discovery
# ══════════════════════════════════════════════════════════════════════════════

class CorrelationEngine:
    """Discovers relationships between entities across domains."""

    def correlate(self, entities: List[FusionEntity]) -> List[FusionEntity]:
        """Add cross-domain relations to entities."""
        # Index by type
        by_type: Dict[str, List[FusionEntity]] = {}
        for e in entities:
            by_type.setdefault(e.entity_type, []).append(e)

        # Correlate trends → products (tag matching)
        trends = by_type.get(EntityType.TREND, [])
        products = by_type.get(EntityType.PRODUCT, [])
        for trend in trends:
            term = trend.name.lower()
            for product in products:
                p_name = product.name.lower()
                p_tags = [t.lower() for t in product.tags]
                if term in p_name or any(term in tag for tag in p_tags):
                    trend.relations.append({
                        "target_id": product.entity_id,
                        "relation_type": "trend_matches_product",
                        "weight": 0.8,
                    })
                    product.relations.append({
                        "target_id": trend.entity_id,
                        "relation_type": "product_in_trend",
                        "weight": 0.8,
                    })

        # Correlate decisions → patterns (business field matching)
        decisions = by_type.get(EntityType.DECISION, [])
        patterns = by_type.get(EntityType.PATTERN, [])
        for d in decisions:
            d_biz = d.data.get("business", "").lower()
            d_type = d.data.get("type", "").lower()
            for p in patterns:
                p_biz = p.data.get("business", "").lower()
                if d_biz and p_biz and d_biz == p_biz:
                    d.relations.append({
                        "target_id": p.entity_id,
                        "relation_type": "decision_informed_pattern",
                        "weight": 0.7,
                    })

        # Correlate patterns → playbooks (already linked by extract)
        # Correlate orders → products (already linked by extract)
        # Correlate engagement → trends (platform matching)
        campaigns = by_type.get(EntityType.CAMPAIGN, [])
        for c in campaigns:
            c_platform = c.data.get("platform", "").lower()
            for t in trends:
                t_platform = t.data.get("platform", "").lower()
                if c_platform and t_platform and c_platform == t_platform:
                    c.relations.append({
                        "target_id": t.entity_id,
                        "relation_type": "engagement_on_trending_platform",
                        "weight": 0.5,
                    })

        return entities


# ══════════════════════════════════════════════════════════════════════════════
# FUSION PIPELINE — Store correlated entities in Qdrant
# ══════════════════════════════════════════════════════════════════════════════

class FusionPipeline:
    """Stores correlated entities into the Qdrant kernell_memory collection."""

    COLLECTION = "kernell_memory"
    VECTOR_SIZE = 768

    def __init__(self, redis_client=None):
        self._r = redis_client
        self._qdrant = None
        self._embedder = None
        self._init_qdrant()

    def _init_qdrant(self):
        """Initialize Qdrant client and ensure collection exists."""
        try:
            from qdrant_client import QdrantClient
            from qdrant_client.http import models

            host = os.getenv("QDRANT_HOST", "127.0.0.1")
            port = int(os.getenv("QDRANT_PORT", "6333"))
            api_key = os.getenv("QDRANT_API_KEY", "")

            self._qdrant = QdrantClient(
                url=f"http://{host}:{port}",
                api_key=api_key if api_key else None,
                https=False,
                timeout=10,
            )

            # Ensure collection exists
            existing = [c.name for c in self._qdrant.get_collections().collections]
            if self.COLLECTION not in existing:
                self._qdrant.create_collection(
                    collection_name=self.COLLECTION,
                    vectors_config=models.VectorParams(
                        size=self.VECTOR_SIZE,
                        distance=models.Distance.COSINE,
                    ),
                    hnsw_config=models.HnswConfigDiff(m=16, ef_construct=100),
                    on_disk_payload=True,
                )
                print(f"  🧬 Created Qdrant collection: {self.COLLECTION}")

        except Exception as e:
            logger.warning(f"Qdrant init: {e}")
            self._qdrant = None

    def _get_embedding(self, text: str) -> List[float]:
        """Get embedding vector via Gemini API (production path), hash fallback."""
        # 1. Try production Gemini embedding (same as all other Qdrant collections)
        if self._embedder is None:
            try:
                from agents.core.embedding_config import get_embedding as _gemini_embed
                self._embedder = _gemini_embed
            except ImportError:
                self._embedder = "hash"

        if self._embedder == "hash":
            return self._hash_embedding(text)

        try:
            return self._embedder(text[:8000])
        except Exception as e:
            logger.warning(f"Gemini embedding failed: {e} — using hash fallback")
            return self._hash_embedding(text)

    def _hash_embedding(self, text: str) -> List[float]:
        """Deterministic hash-based embedding (fallback when no model available)."""
        import struct
        h = hashlib.sha256(text.encode()).digest()
        # Repeat hash to fill vector
        values = []
        for i in range(self.VECTOR_SIZE):
            byte_idx = i % 32
            val = (h[byte_idx] - 128) / 128.0  # Normalize to [-1, 1]
            values.append(val)
        return values

    def upsert_entities(self, entities: List[FusionEntity]) -> Dict:
        """Store entities in Qdrant with embeddings."""
        if not self._qdrant:
            return {"upserted": 0, "error": "Qdrant not available"}

        from qdrant_client.http import models
        from core.memory.qdrant_time_payload import attach_kernell_time_metadata

        points = []
        for e in entities:
            # Create searchable text from entity
            search_text = f"{e.entity_type} {e.name} {' '.join(e.tags)} {json.dumps(e.data, default=str)[:500]}"
            embedding = self._get_embedding(search_text)

            payload = e.to_dict()
            attach_kernell_time_metadata(
                payload,
                agent=e.source_agent or "data_fusion",
                source="data_fusion",
            )
            point = models.PointStruct(
                id=abs(hash(e.entity_id)) % (2**63),
                vector=embedding,
                payload=payload,
            )
            points.append(point)

        # Batch upsert
        batch_size = 100
        total = 0
        for i in range(0, len(points), batch_size):
            batch = points[i:i+batch_size]
            try:
                self._qdrant.upsert(
                    collection_name=self.COLLECTION,
                    points=batch,
                )
                total += len(batch)
            except Exception as ex:
                logger.error(f"Qdrant upsert batch error: {ex}")

        return {"upserted": total, "total_entities": len(entities)}

    def search(self, query: str, entity_type: str = None, limit: int = 10) -> List[Dict]:
        """Search the fusion ontology with natural language."""
        if not self._qdrant:
            return []

        embedding = self._get_embedding(query)
        filters = None

        if entity_type:
            from qdrant_client.http import models
            filters = models.Filter(
                must=[models.FieldCondition(
                    key="entity_type",
                    match=models.MatchValue(value=entity_type),
                )]
            )

        try:
            response = self._qdrant.query_points(
                collection_name=self.COLLECTION,
                query=embedding,
                query_filter=filters,
                limit=limit,
            )
            return [
                {
                    "score": r.score,
                    "entity_id": r.payload.get("entity_id"),
                    "entity_type": r.payload.get("entity_type"),
                    "name": r.payload.get("name"),
                    "data": r.payload.get("data"),
                    "relations": r.payload.get("relations", []),
                    "tags": r.payload.get("tags", []),
                }
                for r in response.points
            ]
        except Exception as ex:
            logger.error(f"Search error: {ex}")
            return []

    def get_graph(self, entity_id: str, depth: int = 2) -> Dict:
        """Traverse the entity graph from a starting point."""
        if not self._qdrant:
            return {}

        visited = set()
        graph = {"nodes": [], "edges": []}

        def _traverse(eid, current_depth):
            if eid in visited or current_depth > depth:
                return
            visited.add(eid)

            # Find entity by searching its ID
            results = self.search(eid, limit=5)
            for r in results:
                if r["entity_id"] == eid:
                    graph["nodes"].append({
                        "id": eid,
                        "type": r["entity_type"],
                        "name": r["name"],
                    })
                    for rel in r.get("relations", []):
                        graph["edges"].append({
                            "source": eid,
                            "target": rel["target_id"],
                            "type": rel["relation_type"],
                            "weight": rel.get("weight", 1.0),
                        })
                        _traverse(rel["target_id"], current_depth + 1)
                    break

        _traverse(entity_id, 0)
        return graph


# ══════════════════════════════════════════════════════════════════════════════
# MAIN ENGINE — Orchestrates the full fusion cycle
# ══════════════════════════════════════════════════════════════════════════════

class DataFusionEngine:
    """
    Master engine for the Unified Ontology.
    Combines extraction, correlation, and storage.
    """

    KEY_LAST_CYCLE  = "kernell:fusion:last_cycle"
    KEY_STATS       = "kernell:fusion:stats"
    KEY_HEARTBEAT   = "kernell:agent:fusion:heartbeat"

    def __init__(self, redis_client=None):
        self._r = redis_client
        self.extractor   = EntityExtractor(redis_client) if redis_client else None
        self.correlator  = CorrelationEngine()
        self.pipeline    = FusionPipeline(redis_client)

    def run_fusion_cycle(self) -> Dict:
        """
        Full fusion cycle:
        1. Extract entities from all agent Redis namespaces
        2. Correlate cross-domain relationships
        3. Store in Qdrant unified collection
        
        Designed to run every 2 hours via Chronos.
        """
        start = time.time()
        print("🧬 [DataFusion] Starting fusion cycle...")

        # 1. Extract
        entities = self.extractor.extract_all() if self.extractor else []
        print(f"  📥 Extracted: {len(entities)} entities")

        if not entities:
            return {"entities": 0, "upserted": 0, "duration_ms": 0}

        # Count by type
        type_counts = {}
        for e in entities:
            type_counts[e.entity_type] = type_counts.get(e.entity_type, 0) + 1
        for t, c in type_counts.items():
            print(f"    {t}: {c}")

        # 2. Correlate
        entities = self.correlator.correlate(entities)
        total_relations = sum(len(e.relations) for e in entities)
        print(f"  🔗 Correlated: {total_relations} relations")

        # 3. Store
        result = self.pipeline.upsert_entities(entities)
        print(f"  💾 Upserted: {result.get('upserted', 0)} to Qdrant")

        duration_ms = int((time.time() - start) * 1000)

        # Record stats
        stats = {
            "entities": len(entities),
            "type_counts": type_counts,
            "relations": total_relations,
            "upserted": result.get("upserted", 0),
            "duration_ms": duration_ms,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

        if self._r:
            try:
                self._r.set(self.KEY_LAST_CYCLE, json.dumps(stats))
                self._r.set(self.KEY_HEARTBEAT, str(time.time()), ex=7200)
                self._r.lpush(f"{self.KEY_STATS}:history", json.dumps(stats))
                self._r.ltrim(f"{self.KEY_STATS}:history", 0, 99)
            except Exception:
                pass

        print(f"  ✅ Fusion complete in {duration_ms}ms")
        return stats

    def query(self, query_text: str, entity_type: str = None, limit: int = 10, requester: str = "kernell") -> List[Dict]:
        """Natural language query against the unified ontology with ABAC security."""
        results = self.pipeline.search(query_text, entity_type, limit)

        # SVS v3 field-level security filter
        try:
            from agents.sierra.svs3_field_security import FieldLevelSecurity
            svs = FieldLevelSecurity(self._r)
            mode = "STABLE"
            if self._r:
                try:
                    snap = self._r.get("kernell:reality:snapshot")
                    if snap:
                        import json as _json
                        mode = _json.loads(snap).get("mode", "STABLE")
                except Exception:
                    pass
            results = svs.filter_results(results, requester, mode)
        except ImportError:
            pass  # SVS v3 not available, return unfiltered

        return results

    def correlate_entity(self, entity_type: str, name: str) -> Dict:
        """Get all correlations for a specific entity."""
        results = self.pipeline.search(f"{entity_type} {name}", entity_type, limit=5)
        if not results:
            return {"found": False}

        entity = results[0]
        related = []
        for rel in entity.get("relations", []):
            # Look up related entity
            rel_results = self.pipeline.search(rel["target_id"], limit=1)
            if rel_results:
                related.append({
                    "relation": rel["relation_type"],
                    "weight": rel.get("weight", 1.0),
                    "entity": rel_results[0],
                })

        return {
            "found":    True,
            "entity":   entity,
            "related":  related,
            "total_relations": len(entity.get("relations", [])),
        }

    def get_insights(self) -> Dict:
        """Generate cross-domain insights from the ontology."""
        if not self._r:
            return {}

        insights = []

        try:
            # Trending products: products that match current trends
            trending_products = self.query("trending popular product", EntityType.PRODUCT, limit=5)
            if trending_products:
                insights.append({
                    "type": "trending_products",
                    "title": "Productos en Tendencia",
                    "items": [{"name": p["name"], "score": p["score"]} for p in trending_products],
                })

            # Decision effectiveness
            effective_decisions = self.query("successful decision outcome", EntityType.DECISION, limit=5)
            if effective_decisions:
                insights.append({
                    "type": "effective_decisions",
                    "title": "Decisiones Efectivas Recientes",
                    "items": [{"name": d["name"][:80], "score": d["score"]} for d in effective_decisions],
                })

            # Active patterns
            patterns = self.query("high confidence pattern", EntityType.PATTERN, limit=5)
            if patterns:
                insights.append({
                    "type": "active_patterns",
                    "title": "Patrones Activos",
                    "items": [{"name": p["name"], "score": p["score"]} for p in patterns],
                })

        except Exception as ex:
            logger.warning(f"Insights error: {ex}")

        return {"insights": insights, "timestamp": datetime.now(timezone.utc).isoformat()}

    def get_stats(self) -> Dict:
        """Get latest fusion stats."""
        if not self._r:
            return {}
        try:
            raw = self._r.get(self.KEY_LAST_CYCLE)
            return json.loads(raw) if raw else {}
        except Exception:
            return {}

    def heartbeat(self):
        if self._r:
            try:
                self._r.set(self.KEY_HEARTBEAT, str(time.time()), ex=7200)
            except Exception:
                pass


# ══════════════════════════════════════════════════════════════════════════════
# CLI
# ══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="DataFusionEngine CLI — Unified Ontology")
    parser.add_argument("--fuse", action="store_true", help="Run full fusion cycle")
    parser.add_argument("--query", type=str, help="Query the ontology")
    parser.add_argument("--type", type=str, choices=[e.value for e in EntityType], help="Filter by type")
    parser.add_argument("--insights", action="store_true", help="Generate cross-domain insights")
    parser.add_argument("--stats", action="store_true", help="Show latest fusion stats")
    parser.add_argument("--extract-only", action="store_true", help="Extract entities without storing")
    args = parser.parse_args()

    redis_client = None
    try:
        import redis
        password = os.getenv("REDIS_PASSWORD", "").strip().strip("\"'") or None
        redis_client = redis.Redis(host="127.0.0.1", port=6379, password=password,
                                   decode_responses=True, socket_connect_timeout=2)
        redis_client.ping()
        print("✅ Redis connected")
    except Exception:
        print("⚠️  No Redis — limited mode")

    engine = DataFusionEngine(redis_client)

    if args.fuse:
        result = engine.run_fusion_cycle()
        print(f"\n📊 Result: {json.dumps(result, indent=2, default=str)}")

    elif args.query:
        results = engine.query(args.query, args.type)
        print(f"\n🔍 Query: '{args.query}' → {len(results)} results")
        for r in results:
            print(f"  [{r['entity_type']}] {r['name']} (score={r['score']:.3f})")
            if r.get("relations"):
                for rel in r["relations"][:3]:
                    print(f"    → {rel['relation_type']}: {rel['target_id']}")

    elif args.insights:
        insights = engine.get_insights()
        for insight in insights.get("insights", []):
            print(f"\n📌 {insight['title']}")
            for item in insight["items"]:
                print(f"  - {item['name']} (score={item['score']:.3f})")

    elif args.stats:
        stats = engine.get_stats()
        if stats:
            print(json.dumps(stats, indent=2, default=str))
        else:
            print("No fusion stats yet. Run --fuse first.")

    elif args.extract_only:
        extractor = EntityExtractor(redis_client)
        entities = extractor.extract_all()
        print(f"\n📥 Extracted {len(entities)} entities:")
        type_counts = {}
        for e in entities:
            type_counts[e.entity_type] = type_counts.get(e.entity_type, 0) + 1
        for t, c in sorted(type_counts.items()):
            print(f"  {t}: {c}")
        print(f"\nSample entities:")
        for e in entities[:5]:
            print(f"  [{e.entity_type}] {e.entity_id}: {e.name}")
    else:
        parser.print_help()
