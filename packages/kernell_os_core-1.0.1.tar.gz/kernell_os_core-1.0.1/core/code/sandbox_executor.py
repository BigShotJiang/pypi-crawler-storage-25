"""
SANDBOX EXECUTOR — Execution Feedback Loop
============================================
El componente que cierra el gap con Opus.

Opus ejecuta código, ve errores, y corrige antes de entregar.
Este módulo replica ese loop:

  1. Recibe código generado por el pipeline
  2. Lo ejecuta en un subprocess aislado con timeout
  3. Captura stdout + stderr
  4. Si falla → devuelve el error al pipeline para auto-corrección
  5. Máximo N iteraciones antes de escalar

SEGURIDAD:
  - Subprocess con timeout estricto (default 10s)
  - Directorio temporal aislado (se borra después)
  - Sin acceso a red por defecto
  - Sin permisos de escritura fuera del tmpdir
  - Solo ejecuta Python (extensible a otros lenguajes)
"""

import json
import logging
import os
import shutil
import subprocess
import tempfile
import time
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from typing import Optional

import redis

logger = logging.getLogger("kernell.code.sandbox")

DEFAULT_TIMEOUT_S      = 10
MAX_CORRECTION_LOOPS   = 3
MAX_STDERR_CHARS       = 2000
MAX_STDOUT_CHARS       = 5000


@dataclass
class ExecutionResult:
    """Resultado de una ejecución en sandbox."""
    success: bool
    stdout: str
    stderr: str
    exit_code: int
    execution_time_ms: float
    iteration: int
    timed_out: bool
    error_summary: str            # Resumen corto del error para el LLM
    timestamp: str = ""

    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = datetime.now(timezone.utc).isoformat()


@dataclass
class CorrectionAttempt:
    """Registro de un intento de auto-corrección."""
    iteration: int
    error_input: str
    code_before: str
    code_after: str
    fixed: bool
    timestamp: str = ""


@dataclass
class ForgeResult:
    """Resultado final del ciclo completo generate→execute→correct."""
    code: str
    language: str
    executed: bool
    execution_passed: bool
    iterations_used: int
    max_iterations: int
    execution_results: list
    correction_attempts: list
    final_stdout: str
    final_stderr: str
    total_time_ms: float
    architecture_trace: Optional[str] = None
    critic_findings: list = None
    is_production_ready: bool = False
    timestamp: str = ""

    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = datetime.now(timezone.utc).isoformat()
        if self.critic_findings is None:
            self.critic_findings = []


class SandboxExecutor:
    """
    Ejecuta código Python en un subprocess aislado.
    Captura stdout/stderr y devuelve un resumen de error
    listo para inyectar en el prompt de corrección del LLM.
    """

    def __init__(
        self,
        timeout_s: int = DEFAULT_TIMEOUT_S,
        python_binary: str = None,
    ):
        self.timeout = timeout_s
        self.python = python_binary or self._find_python()

    def execute(
        self,
        code: str,
        language: str = "python",
        test_code: str = "",
        env_vars: dict = None,
    ) -> ExecutionResult:
        """
        Ejecuta código en sandbox.
        
        Args:
            code: Código a ejecutar
            language: Lenguaje (actualmente solo python)
            test_code: Código de test adicional a ejecutar después
            env_vars: Variables de entorno adicionales
            
        Returns:
            ExecutionResult con stdout, stderr, exit_code
        """
        if language != "python":
            return ExecutionResult(
                success=False, stdout="", stderr=f"Language '{language}' not supported yet",
                exit_code=-1, execution_time_ms=0, iteration=0,
                timed_out=False, error_summary=f"Unsupported language: {language}",
            )

        tmpdir = tempfile.mkdtemp(prefix="kernell_sandbox_")
        try:
            # Escribir código principal
            main_file = os.path.join(tmpdir, "main.py")
            with open(main_file, "w") as f:
                f.write(code)
                if test_code:
                    f.write("\n\n# === AUTO-TEST ===\n")
                    f.write(test_code)

            # Preparar entorno aislado
            env = os.environ.copy()
            env["PYTHONDONTWRITEBYTECODE"] = "1"
            env["PYTHONUNBUFFERED"] = "1"
            if env_vars:
                env.update(env_vars)

            # Ejecutar
            t_start = time.time()
            try:
                proc = subprocess.run(
                    [self.python, main_file],
                    capture_output=True,
                    text=True,
                    timeout=self.timeout,
                    cwd=tmpdir,
                    env=env,
                )
                elapsed_ms = (time.time() - t_start) * 1000

                stdout = proc.stdout[:MAX_STDOUT_CHARS] if proc.stdout else ""
                stderr = proc.stderr[:MAX_STDERR_CHARS] if proc.stderr else ""

                return ExecutionResult(
                    success=(proc.returncode == 0),
                    stdout=stdout,
                    stderr=stderr,
                    exit_code=proc.returncode,
                    execution_time_ms=round(elapsed_ms, 1),
                    iteration=0,
                    timed_out=False,
                    error_summary=self._extract_error_summary(stderr) if proc.returncode != 0 else "",
                )

            except subprocess.TimeoutExpired:
                elapsed_ms = (time.time() - t_start) * 1000
                return ExecutionResult(
                    success=False, stdout="", stderr=f"Timeout after {self.timeout}s",
                    exit_code=-1, execution_time_ms=round(elapsed_ms, 1),
                    iteration=0, timed_out=True,
                    error_summary=f"Code execution timed out after {self.timeout} seconds",
                )

        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)

    def validate_syntax(self, code: str, language: str = "python") -> ExecutionResult:
        """
        Solo valida sintaxis sin ejecutar.
        Más rápido y seguro para validación inicial.
        """
        if language != "python":
            return ExecutionResult(
                success=True, stdout="", stderr="", exit_code=0,
                execution_time_ms=0, iteration=0, timed_out=False, error_summary="",
            )

        tmpdir = tempfile.mkdtemp(prefix="kernell_syntax_")
        try:
            check_file = os.path.join(tmpdir, "check.py")
            with open(check_file, "w") as f:
                f.write(code)

            t_start = time.time()
            proc = subprocess.run(
                [self.python, "-m", "py_compile", check_file],
                capture_output=True, text=True, timeout=5,
            )
            elapsed_ms = (time.time() - t_start) * 1000

            return ExecutionResult(
                success=(proc.returncode == 0),
                stdout="",
                stderr=proc.stderr[:MAX_STDERR_CHARS] if proc.stderr else "",
                exit_code=proc.returncode,
                execution_time_ms=round(elapsed_ms, 1),
                iteration=0,
                timed_out=False,
                error_summary=self._extract_error_summary(proc.stderr) if proc.returncode != 0 else "",
            )
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)

    def _extract_error_summary(self, stderr: str) -> str:
        """
        Extrae un resumen del error más útil para el LLM.
        Busca la línea de traceback más relevante.
        """
        if not stderr:
            return ""

        lines = stderr.strip().split("\n")

        # Buscar la última línea de error (usualmente la más informativa)
        error_line = ""
        traceback_line = ""
        for line in reversed(lines):
            stripped = line.strip()
            if not error_line and (
                stripped.startswith(("Error", "Exception", "TypeError", "ValueError",
                                    "NameError", "AttributeError", "ImportError",
                                    "KeyError", "IndexError", "SyntaxError",
                                    "IndentationError", "ZeroDivisionError",
                                    "FileNotFoundError", "ModuleNotFoundError"))
                or ": " in stripped and any(
                    e in stripped for e in ["Error", "Exception", "Warning"]
                )
            ):
                error_line = stripped
            if not traceback_line and stripped.startswith("File "):
                traceback_line = stripped

        if error_line and traceback_line:
            return f"{traceback_line}\n{error_line}"
        elif error_line:
            return error_line
        elif len(lines) <= 5:
            return stderr.strip()
        else:
            # Últimas 5 líneas del traceback
            return "\n".join(lines[-5:])

    def _find_python(self) -> str:
        """Encuentra el mejor Python disponible."""
        venv_python = "/home/anny/kernell-os/.venv/bin/python3"
        if os.path.exists(venv_python):
            return venv_python
        return "python3"


class ExecutionLoop:
    """
    El loop de ejecución completo: genera → ejecuta → corrige → repite.
    Integra SandboxExecutor con el CodePipeline para auto-corrección.
    """

    def __init__(
        self,
        redis_client: redis.Redis,
        max_iterations: int = MAX_CORRECTION_LOOPS,
        timeout_s: int = DEFAULT_TIMEOUT_S,
    ):
        self.redis = redis_client
        self.max_iterations = max_iterations
        self.executor = SandboxExecutor(timeout_s=timeout_s)
        self._corrections = []
        self._executions = []

    def run(
        self,
        code: str,
        language: str = "python",
        test_code: str = "",
        pipeline_ref=None,
        task_context: str = "",
    ) -> ForgeResult:
        """
        Ejecuta el loop de corrección:
        1. Ejecuta código
        2. Si falla → pide al pipeline que corrija basado en el error
        3. Repite hasta que funcione o se agoten iteraciones
        
        Args:
            code: Código inicial (output del pipeline)
            language: Lenguaje
            test_code: Tests opcionales
            pipeline_ref: Referencia al CodePipeline para auto-corrección
            task_context: Contexto de la tarea para el corrector
        """
        current_code = code
        t_total_start = time.time()

        for i in range(self.max_iterations + 1):
            # Paso 1: Ejecutar
            result = self.executor.execute(
                current_code, language, test_code=test_code
            )
            result.iteration = i
            self._executions.append(asdict(result))

            logger.info(
                f"[EXECUTION LOOP] iteration={i} success={result.success} "
                f"exit={result.exit_code} time={result.execution_time_ms}ms"
            )

            # Si funciona → done
            if result.success:
                return self._build_result(
                    code=current_code,
                    language=language,
                    executed=True,
                    passed=True,
                    iterations=i + 1,
                    stdout=result.stdout,
                    stderr=result.stderr,
                    t_start=t_total_start,
                )

            # Si es la última iteración → entregar con warning
            if i >= self.max_iterations:
                logger.warning(
                    f"[EXECUTION LOOP] Max iterations ({self.max_iterations}) reached. "
                    f"Delivering code with known issues."
                )
                return self._build_result(
                    code=current_code,
                    language=language,
                    executed=True,
                    passed=False,
                    iterations=i + 1,
                    stdout=result.stdout,
                    stderr=result.stderr,
                    t_start=t_total_start,
                )

            # Paso 2: Auto-corrección vía LLM
            if pipeline_ref is None:
                logger.warning("[EXECUTION LOOP] No pipeline ref for correction, stopping.")
                return self._build_result(
                    code=current_code,
                    language=language,
                    executed=True,
                    passed=False,
                    iterations=i + 1,
                    stdout=result.stdout,
                    stderr=result.stderr,
                    t_start=t_total_start,
                )

            corrected = self._auto_correct(
                pipeline_ref, current_code, language,
                result.error_summary, result.stderr, task_context, i
            )

            if corrected and corrected != current_code:
                self._corrections.append(CorrectionAttempt(
                    iteration=i,
                    error_input=result.error_summary,
                    code_before=current_code[:200] + "...",
                    code_after=corrected[:200] + "...",
                    fixed=False,  # Will be updated if next execution passes
                    timestamp=datetime.now(timezone.utc).isoformat(),
                ))
                current_code = corrected
            else:
                # LLM no pudo corregir → stop
                logger.warning("[EXECUTION LOOP] LLM could not produce different code.")
                return self._build_result(
                    code=current_code,
                    language=language,
                    executed=True,
                    passed=False,
                    iterations=i + 1,
                    stdout=result.stdout,
                    stderr=result.stderr,
                    t_start=t_total_start,
                )

        # Shouldn't reach here, but safety
        return self._build_result(
            code=current_code, language=language,
            executed=True, passed=False,
            iterations=self.max_iterations,
            stdout="", stderr="Max iterations exceeded",
            t_start=t_total_start,
        )

    def _auto_correct(
        self, pipeline, code, language, error_summary, full_stderr, task_context, iteration
    ) -> Optional[str]:
        """
        Pide al LLM que corrija el código basado en el error de ejecución.
        Usa el Refiner (R1) del pipeline existente.
        """
        error_findings = [
            f"RUNTIME ERROR (iteration {iteration + 1}):",
            f"  {error_summary}",
            "",
            "Full stderr:",
            full_stderr[:1500],
        ]

        try:
            from core.sea.llm_registry import LLMProviderRegistry

            registry = LLMProviderRegistry(self.redis)

            correction_prompt = (
                f"The following {language} code produced a runtime error. "
                f"Fix the error and return ONLY the corrected code.\n\n"
                f"TASK CONTEXT: {task_context}\n\n"
                f"RUNTIME ERROR:\n{error_summary}\n\n"
                f"FULL STDERR:\n{full_stderr[:1500]}\n\n"
                f"CODE WITH BUG:\n```{language}\n{code}\n```\n\n"
                f"Return ONLY the corrected code inside a ```{language} code block. "
                f"No explanations."
            )

            resp = registry.complete(
                messages=[{"role": "user", "content": correction_prompt}],
                system_prompt=(
                    f"You are a {language} debugging expert. "
                    f"Fix runtime errors precisely. Return only corrected code."
                ),
                preferred_provider="groq_r1",
                role="code_fix",
                max_tokens=3000,
                temperature=0.15,
            )

            if resp and resp.content:
                return self._extract_code(resp.content, language)

        except Exception as e:
            logger.error(f"[EXECUTION LOOP] Auto-correct failed: {e}")

        return None

    def _extract_code(self, text: str, language: str) -> Optional[str]:
        """Extrae código de un bloque markdown."""
        import re

        # Buscar bloque de código con language tag
        pattern = rf"```{language}\s*\n(.*?)```"
        match = re.search(pattern, text, re.DOTALL)
        if match:
            return match.group(1).strip()

        # Buscar cualquier bloque de código
        pattern = r"```\w*\s*\n(.*?)```"
        match = re.search(pattern, text, re.DOTALL)
        if match:
            return match.group(1).strip()

        # Si no hay bloques, asumir que todo es código
        clean = text.strip()
        if clean and not clean.startswith("#") and ("def " in clean or "class " in clean or "import " in clean):
            return clean

        return None

    def _build_result(
        self, code, language, executed, passed,
        iterations, stdout, stderr, t_start,
    ) -> ForgeResult:
        """Construye el resultado final del loop."""
        total_ms = (time.time() - t_start) * 1000

        # Marcar la última corrección como exitosa si el código pasó
        if passed and self._corrections:
            self._corrections[-1].fixed = True

        # Persistir métricas
        self._persist_metrics(passed, iterations, total_ms)

        return ForgeResult(
            code=code,
            language=language,
            executed=executed,
            execution_passed=passed,
            iterations_used=iterations,
            max_iterations=self.max_iterations,
            execution_results=list(self._executions),
            correction_attempts=[asdict(c) for c in self._corrections],
            final_stdout=stdout,
            final_stderr=stderr,
            total_time_ms=round(total_ms, 1),
            is_production_ready=passed,
        )

    def _persist_metrics(self, passed: bool, iterations: int, total_ms: float):
        """Registra métricas del loop en Redis."""
        try:
            self.redis.lpush("kernell:code:execution_loop:history", json.dumps({
                "passed": passed,
                "iterations": iterations,
                "total_ms": round(total_ms, 1),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }))
            self.redis.ltrim("kernell:code:execution_loop:history", 0, 499)

            # Counter de éxitos/fallos
            if passed:
                self.redis.incr("kernell:code:execution_loop:passes")
            else:
                self.redis.incr("kernell:code:execution_loop:failures")
        except Exception:
            pass
"""
SANDBOX EXECUTOR — Execution Feedback Loop
============================================
"""
