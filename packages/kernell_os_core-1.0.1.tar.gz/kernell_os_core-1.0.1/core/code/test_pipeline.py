"""
TESTS DEL CODE PIPELINE
========================
Valida que el pipeline produce código de calidad esperada.
Corre estos tests después de configurar las API keys.

python -m kernell.code.tests.run_tests
"""

import redis
import sys
from kernell.code.code_agent import CodeAgent
from kernell.code.pipeline.code_pipeline import PipelineMode

REDIS_URL = "redis://localhost:6379"


def test_circuit_breaker():
    """Test 1: Implementar un componente no trivial desde cero."""
    print("\n=== TEST 1: Circuit Breaker ===")
    r = redis.from_url(REDIS_URL, decode_responses=False)
    agent = CodeAgent(r)

    result = agent.code(
        task=(
            "Implementar un CircuitBreaker genérico en Python. "
            "Estados: CLOSED, OPEN, HALF_OPEN. "
            "Threshold configurable de fallos. "
            "Reset automático después de timeout. "
            "Thread-safe. "
            "Usable como decorador y como context manager."
        ),
        language="python",
        mode=PipelineMode.FULL,
    )

    print(f"Pasos: {result.steps_completed}/4")
    print(f"Latencia: {result.total_latency_ms:.0f}ms")
    print(f"Bugs críticos: {result.had_critical_bugs}")
    print(f"Production ready: {result.is_production_ready}")
    print(f"Critic findings ({len(result.critic_findings)}):")
    for f in result.critic_findings[:3]:
        print(f"  - {f[:80]}")
    print(f"\nArch trace disponible: {bool(result.architecture_trace)}")
    if result.architecture_trace:
        print(f"Arch trace preview: {result.architecture_trace[:200]}...")
    print(f"\nCódigo ({len(result.code)} chars):")
    print(result.code[:800])
    print("..." if len(result.code) > 800 else "")

    # Validaciones básicas
    assert "CLOSED" in result.code or "closed" in result.code.lower(), "Falta estado CLOSED"
    assert "OPEN" in result.code or "open" in result.code.lower(), "Falta estado OPEN"
    assert "threading" in result.code or "Lock" in result.code, "No es thread-safe"
    assert "def " in result.code, "No hay funciones"
    print("\n✅ TEST 1 PASSED")


def test_redis_helper():
    """Test 2: Código que usa Redis — valida que los patrones de memoria funcionan."""
    print("\n=== TEST 2: Redis Helper ===")
    r = redis.from_url(REDIS_URL, decode_responses=False)
    agent = CodeAgent(r)

    result = agent.code(
        task=(
            "Crear un helper RateLimiter usando Redis con el algoritmo sliding window. "
            "Método: is_allowed(key: str, limit: int, window_seconds: int) -> bool. "
            "Debe ser atómico (usar Lua script o pipeline). "
            "Limpiar automáticamente entradas expiradas."
        ),
        language="python",
        context="Redis cliente: redis.Redis(decode_responses=False). Usar pipeline() cuando sea posible.",
        mode=PipelineMode.FULL,
    )

    print(f"Production ready: {result.is_production_ready}")
    print(f"Critic findings: {result.critic_findings}")

    # Validar que usa correctamente Redis (los patrones de memoria deben haber ayudado)
    code = result.code.lower()
    assert "redis" in code, "No usa Redis"
    assert "pipeline" in code or "lua" in code or "script" in code, "No es atómico"
    print(f"\nCódigo ({len(result.code)} chars):")
    print(result.code[:600])
    print("\n✅ TEST 2 PASSED")


def test_review_existing():
    """Test 3: Review de código con bugs intencionales."""
    print("\n=== TEST 3: Code Review ===")
    r = redis.from_url(REDIS_URL, decode_responses=False)
    agent = CodeAgent(r)

    BAD_CODE = '''
def process_users(users=[], db=None):
    """Process a list of users."""
    results = []
    for i in range(len(users)):
        user = users[i]
        data = db.get("user:" + user["id"])
        if data:
            results.append(json.loads(data))
    return results

def calculate_stats(data):
    total = 0
    for item in data:
        total = total + item["value"]
    avg = total / len(data)
    return {"total": total, "average": avg}
'''

    result = agent.review(BAD_CODE, language="python")

    print(f"Findings ({len(result.critic_findings)}):")
    for f in result.critic_findings:
        print(f"  - {f[:100]}")

    # Debe detectar: mutable default, ZeroDivisionError, None dereference
    findings_text = " ".join(result.critic_findings).lower()
    detected_mutable = any(w in findings_text for w in ["mutable", "default", "[]", "shared"])
    detected_division = any(w in findings_text for w in ["zero", "division", "empty", "len(data)"])
    detected_none = any(w in findings_text for w in ["none", "null", "db", "attribute"])

    print(f"\nDetectó mutable default: {detected_mutable}")
    print(f"Detectó ZeroDivision: {detected_division}")
    print(f"Detectó None dereference: {detected_none}")

    assert len(result.critic_findings) >= 2, "Debería encontrar al menos 2 problemas"
    print(f"\nCódigo mejorado ({len(result.code)} chars):")
    print(result.code[:500])
    print("\n✅ TEST 3 PASSED")


def test_fast_mode():
    """Test 4: Modo rápido para tareas simples."""
    print("\n=== TEST 4: Fast Mode ===")
    r = redis.from_url(REDIS_URL, decode_responses=False)
    agent = CodeAgent(r)

    result = agent.code(
        task="función que convierte segundos a formato HH:MM:SS",
        language="python",
        mode=PipelineMode.FAST,
    )

    print(f"Latencia fast mode: {result.total_latency_ms:.0f}ms")
    assert "def " in result.code, "Debe ser una función"
    assert result.steps_completed == 1, "Fast mode debe ser 1 paso"
    print(result.code)
    print("\n✅ TEST 4 PASSED")


def test_design_only():
    """Test 5: Solo diseño sin implementación."""
    print("\n=== TEST 5: Design Only ===")
    r = redis.from_url(REDIS_URL, decode_responses=False)
    agent = CodeAgent(r)

    plan = agent.design(
        task=(
            "Diseñar un sistema de eventos asíncrono para Kernell OS "
            "donde los agentes pueden suscribirse y publicar eventos "
            "sin acoplamiento directo"
        ),
        language="python",
    )

    print(f"Plan ({len(plan)} chars):")
    print(plan[:600])
    assert len(plan) > 100, "El plan debe tener contenido"
    print("\n✅ TEST 5 PASSED")


def run_all():
    print("=" * 60)
    print("KERNELL CODE PIPELINE — Tests de Calidad")
    print("=" * 60)

    tests = [
        test_circuit_breaker,
        test_redis_helper,
        test_review_existing,
        test_fast_mode,
        test_design_only,
    ]

    passed = 0
    failed = 0

    for test in tests:
        try:
            test()
            passed += 1
        except AssertionError as e:
            print(f"\n❌ ASSERTION FAILED: {e}")
            failed += 1
        except Exception as e:
            print(f"\n❌ ERROR: {type(e).__name__}: {e}")
            failed += 1

    print("\n" + "=" * 60)
    print(f"Resultados: {passed}/{len(tests)} passed, {failed} failed")
    print("=" * 60)

    return failed == 0


if __name__ == "__main__":
    ok = run_all()
    sys.exit(0 if ok else 1)
