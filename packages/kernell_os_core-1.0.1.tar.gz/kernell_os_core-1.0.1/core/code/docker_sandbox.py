"""
DOCKER SANDBOX — OpenHands-Inspired Isolated Execution
========================================================
Ejecuta código en contenedores Docker efímeros para eliminar
riesgos de jailbreak y acceso no autorizado al host.

Design:
  - Levanta un contenedor por ejecución con timeout
  - Monta kernell-os como READ-ONLY en /workspace
  - Monta un tmpdir como READ-WRITE en /sandbox
  - Destruye el contenedor al terminar
  - Sin acceso a red por defecto (--network=none)

Fallback:
  Si Docker no está disponible (no instalado, no permisos),
  usa SandboxExecutor (subprocess) de forma transparente.
  Controlado por KERNELL_SANDBOX_DOCKER env var.

Integration:
  - sandbox_executor.py:  ExecutionLoop usa DockerSandbox si habilitado
  - Redis telemetry:      kernell:sandbox:mode, kernell:sandbox:executions:*
"""

from __future__ import annotations

import json
import logging
import os
import shutil
import subprocess
import tempfile
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Optional

logger = logging.getLogger("kernell.code.docker_sandbox")

# ── Config ────────────────────────────────────────────────────────────────────

DOCKER_ENABLED = os.getenv("KERNELL_SANDBOX_DOCKER", "0").strip() in ("1", "true", "yes")
DOCKER_IMAGE = os.getenv("KERNELL_SANDBOX_IMAGE", "kernell-sandbox:latest")
DOCKER_TIMEOUT_S = int(os.getenv("KERNELL_SANDBOX_TIMEOUT_S", "30"))
DOCKER_MOUNT_RO = os.getenv("KERNELL_SANDBOX_MOUNT_RO", "/home/anny/kernell-os")

MAX_STDOUT_CHARS = 5000
MAX_STDERR_CHARS = 2000


# Reuse ExecutionResult from sandbox_executor
try:
    from core.code.sandbox_executor import ExecutionResult, SandboxExecutor
except ImportError:
    # Standalone fallback dataclass
    @dataclass
    class ExecutionResult:
        success: bool
        stdout: str
        stderr: str
        exit_code: int
        execution_time_ms: float
        iteration: int
        timed_out: bool
        error_summary: str
        timestamp: str = ""

    SandboxExecutor = None


class DockerSandbox:
    """
    Ejecuta código en contenedores Docker efímeros.
    Fallback transparente a SandboxExecutor si Docker no está disponible.
    """

    def __init__(
        self,
        image: str = DOCKER_IMAGE,
        timeout_s: int = DOCKER_TIMEOUT_S,
        mount_ro: str = DOCKER_MOUNT_RO,
        redis_client=None,
    ):
        self.image = image
        self.timeout = timeout_s
        self.mount_ro = mount_ro
        self.redis = redis_client
        self._docker_available = self._check_docker() if DOCKER_ENABLED else False
        self._fallback = None

        if self._docker_available:
            logger.info(f"[SANDBOX] Docker mode active — image={image}")
            self._publish_mode("docker")
        else:
            logger.info("[SANDBOX] Docker not available — using subprocess fallback")
            self._publish_mode("subprocess")

    def execute(
        self,
        code: str,
        language: str = "python",
        test_code: str = "",
        env_vars: dict = None,
    ) -> ExecutionResult:
        """
        Ejecuta código en sandbox aislado.
        Docker si disponible, subprocess si no.
        """
        if language != "python":
            return ExecutionResult(
                success=False, stdout="", stderr=f"Language '{language}' not supported",
                exit_code=-1, execution_time_ms=0, iteration=0,
                timed_out=False, error_summary=f"Unsupported language: {language}",
            )

        if self._docker_available:
            return self._execute_docker(code, test_code, env_vars)
        else:
            return self._execute_fallback(code, language, test_code, env_vars)

    def _execute_docker(
        self,
        code: str,
        test_code: str = "",
        env_vars: dict = None,
    ) -> ExecutionResult:
        """Ejecución en contenedor Docker efímero."""
        tmpdir = tempfile.mkdtemp(prefix="kernell_docker_sandbox_")
        try:
            # Escribir código
            main_file = os.path.join(tmpdir, "main.py")
            with open(main_file, "w") as f:
                f.write(code)
                if test_code:
                    f.write("\n\n# === AUTO-TEST ===\n")
                    f.write(test_code)

            # Construir comando docker
            container_name = f"ksandbox-{int(time.time() * 1000)}"
            cmd = [
                "docker", "run",
                "--rm",
                "--name", container_name,
                "--network", "none",  # Sin red
                "--memory", "256m",   # Límite de RAM
                "--cpus", "1",        # Límite de CPU
                "--pids-limit", "64", # Límite de procesos
                "-v", f"{self.mount_ro}:/workspace:ro",  # Proyecto read-only
                "-v", f"{tmpdir}:/sandbox:rw",           # Sandbox read-write
                "-w", "/sandbox",
            ]

            # Env vars opcionales
            if env_vars:
                for k, v in env_vars.items():
                    cmd.extend(["-e", f"{k}={v}"])

            cmd.extend([self.image, "python3", "/sandbox/main.py"])

            # Ejecutar con timeout
            t_start = time.time()
            try:
                proc = subprocess.run(
                    cmd,
                    capture_output=True,
                    text=True,
                    timeout=self.timeout,
                )
                elapsed_ms = (time.time() - t_start) * 1000

                stdout = proc.stdout[:MAX_STDOUT_CHARS] if proc.stdout else ""
                stderr = proc.stderr[:MAX_STDERR_CHARS] if proc.stderr else ""

                self._record_execution("docker", proc.returncode == 0)

                return ExecutionResult(
                    success=(proc.returncode == 0),
                    stdout=stdout,
                    stderr=stderr,
                    exit_code=proc.returncode,
                    execution_time_ms=round(elapsed_ms, 1),
                    iteration=0,
                    timed_out=False,
                    error_summary=self._extract_error(stderr) if proc.returncode != 0 else "",
                )

            except subprocess.TimeoutExpired:
                elapsed_ms = (time.time() - t_start) * 1000
                # Kill container
                subprocess.run(
                    ["docker", "kill", container_name],
                    capture_output=True, timeout=5,
                )
                self._record_execution("docker", False)

                return ExecutionResult(
                    success=False, stdout="",
                    stderr=f"Docker container timed out after {self.timeout}s",
                    exit_code=-1, execution_time_ms=round(elapsed_ms, 1),
                    iteration=0, timed_out=True,
                    error_summary=f"Execution timed out after {self.timeout}s",
                )

        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)

    def _execute_fallback(
        self,
        code: str,
        language: str = "python",
        test_code: str = "",
        env_vars: dict = None,
    ) -> ExecutionResult:
        """Fallback al SandboxExecutor basado en subprocess."""
        if self._fallback is None:
            if SandboxExecutor is not None:
                self._fallback = SandboxExecutor(timeout_s=self.timeout)
            else:
                return ExecutionResult(
                    success=False, stdout="",
                    stderr="No sandbox backend available",
                    exit_code=-1, execution_time_ms=0, iteration=0,
                    timed_out=False, error_summary="Neither Docker nor SandboxExecutor available",
                )

        result = self._fallback.execute(code, language, test_code, env_vars)
        self._record_execution("fallback", result.success)
        return result

    # ── Helpers ────────────────────────────────────────────────────────────

    def _check_docker(self) -> bool:
        """Verifica si Docker está disponible y el usuario tiene permisos."""
        try:
            result = subprocess.run(
                ["docker", "info"],
                capture_output=True, text=True, timeout=5,
            )
            if result.returncode == 0:
                # Verificar que la imagen existe
                img_check = subprocess.run(
                    ["docker", "image", "inspect", self.image],
                    capture_output=True, text=True, timeout=5,
                )
                if img_check.returncode != 0:
                    logger.warning(
                        f"[SANDBOX] Docker available but image '{self.image}' not found. "
                        f"Build it: docker build -t {self.image} -f docker/Dockerfile.sandbox ."
                    )
                    return False
                return True
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass
        return False

    @staticmethod
    def _extract_error(stderr: str) -> str:
        """Extrae resumen de error del stderr."""
        if not stderr:
            return ""
        lines = stderr.strip().split("\n")
        for line in reversed(lines):
            s = line.strip()
            if any(e in s for e in ["Error", "Exception", "Warning"]):
                return s
        return "\n".join(lines[-3:]) if len(lines) > 3 else stderr.strip()

    def _record_execution(self, mode: str, success: bool):
        """Registra ejecución en Redis."""
        if not self.redis:
            return
        try:
            self.redis.incr("kernell:sandbox:executions:total")
            self.redis.incr(f"kernell:sandbox:executions:{mode}")
            if not success:
                self.redis.incr(f"kernell:sandbox:executions:{mode}:failures")
        except Exception:
            pass

    def _publish_mode(self, mode: str):
        """Publica modo de sandbox activo en Redis."""
        if not self.redis:
            return
        try:
            self.redis.set("kernell:sandbox:mode", mode, ex=86400)
        except Exception:
            pass

    @property
    def mode(self) -> str:
        """Retorna el modo actual de sandbox."""
        return "docker" if self._docker_available else "subprocess"

    @property
    def docker_available(self) -> bool:
        return self._docker_available
