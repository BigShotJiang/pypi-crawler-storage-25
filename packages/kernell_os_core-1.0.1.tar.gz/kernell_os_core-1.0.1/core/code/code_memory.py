"""
CODE MEMORY — Memoria de Patrones de Programación
===================================================
El segundo componente que separa Opus del resto:
Opus ha visto millones de patrones. Nosotros los memorizamos explícitamente.

Qué almacena:
  - Patrones exitosos: "cuando se hace X en Python, hacerlo así"
  - Anti-patrones: "esto parece bueno pero falla en edge case Y"
  - Soluciones probadas: código que pasó review sin cambios
  - Bugs recurrentes: problemas que R1/Gemini repiten consistentemente

Cómo se usa:
  El CodePipeline inyecta contexto relevante en el prompt del Architect.
  "Patrones relevantes de tu base de conocimiento:
   - En Redis pipelines, usar pipeline() context manager para atomicidad
   - En asyncio, evitar .run_until_complete dentro de otro loop"

Cómo crece:
  - Automático: cuando un CodeResult pasa el pipeline completo sin bugs críticos,
    el patrón se indexa
  - Manual: kernell.code.learn(pattern, context)
  - Del fine-tuning: patrones extraídos de episodios de código exitoso
"""

import json
import logging
import redis
import hashlib
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from typing import Optional
from enum import Enum

logger = logging.getLogger("kernell.code.memory")


class PatternType(Enum):
    SOLUTION    = "solution"    # Solución completa probada
    PATTERN     = "pattern"     # Patrón de diseño o idiom
    ANTIPATTERN = "antipattern" # Cosa que parece buena pero no lo es
    BUG         = "bug"         # Bug recurrente que los LLMs cometen
    LESSON      = "lesson"      # Lección aprendida de un review


@dataclass
class CodePattern:
    pattern_id: str
    pattern_type: PatternType
    language: str
    title: str
    description: str          # Cuándo aplica este patrón
    code_example: str         # El código (bueno o malo según el tipo)
    tags: list[str]           # Para búsqueda: ["async", "redis", "error_handling"]
    use_count: int            # Cuántas veces se inyectó en prompts
    positive_outcomes: int    # Cuántas veces resultó en código bueno
    source: str               # "auto" | "manual" | "fine_tune"
    created_at: str


class CodeMemory:
    """
    Base de conocimiento de patrones de programación específicos de Kernell.
    Se alimenta solo a medida que el sistema aprende.
    """

    # Patrones base cargados al inicio
    # Estos no son genéricos — son los problemas que R1 y Gemini
    # cometen consistentemente en las tareas típicas de Kernell OS

    BOOTSTRAP_PATTERNS = [
        {
            "type": PatternType.BUG,
            "language": "python",
            "title": "Redis decode_responses=False requiere decode manual",
            "description": "Cuando redis cliente tiene decode_responses=False, todos los valores son bytes",
            "code_example": (
                "# MAL — asume string\n"
                "val = redis.get('key')  # retorna b'value'\n"
                "if val == 'expected':   # nunca True\n\n"
                "# BIEN\n"
                "raw = redis.get('key')\n"
                "val = raw.decode() if isinstance(raw, bytes) else raw\n"
                "if val == 'expected':   # funciona"
            ),
            "tags": ["redis", "bytes", "decode", "python"],
        },
        {
            "type": PatternType.BUG,
            "language": "python",
            "title": "dataclass asdict() con Enum falla en json.dumps",
            "description": "dataclasses.asdict convierte Enum a su valor pero json.dumps puede fallar",
            "code_example": (
                "# MAL\n"
                "@dataclass\nclass Config:\n    mode: SomeEnum\n\n"
                "json.dumps(asdict(config))  # Error: SomeEnum is not JSON serializable\n\n"
                "# BIEN\n"
                "# Usar mode.value al crear el dataclass o custom encoder:\n"
                "json.dumps(asdict(config), default=lambda x: x.value if isinstance(x, Enum) else str(x))"
            ),
            "tags": ["dataclass", "enum", "json", "serialization"],
        },
        {
            "type": PatternType.PATTERN,
            "language": "python",
            "title": "Context manager para Redis pipeline",
            "description": "Siempre usar pipeline() con context manager para operaciones batch atómicas",
            "code_example": (
                "# BIEN — atómico, se ejecuta en un round-trip\n"
                "with redis.pipeline() as pipe:\n"
                "    pipe.set('key1', val1)\n"
                "    pipe.lpush('list', item)\n"
                "    pipe.expire('key1', 3600)\n"
                "    pipe.execute()"
            ),
            "tags": ["redis", "pipeline", "atomic", "performance"],
        },
        {
            "type": PatternType.BUG,
            "language": "python",
            "title": "threading.Lock.acquire() sin timeout puede deadlock",
            "description": "Lock.acquire(blocking=True) sin timeout cuelga si el thread muere con el lock",
            "code_example": (
                "# MAL — puede deadlock permanente\n"
                "lock.acquire()\n\n"
                "# BIEN\n"
                "if not lock.acquire(timeout=30):\n"
                "    logger.error('Lock timeout — posible deadlock')\n"
                "    return\n"
                "try:\n"
                "    ...\n"
                "finally:\n"
                "    lock.release()"
            ),
            "tags": ["threading", "lock", "deadlock", "timeout"],
        },
        {
            "type": PatternType.PATTERN,
            "language": "python",
            "title": "Optional[str] con None check explícito vs falsy",
            "description": "En Python, '' (string vacío) es falsy pero válido. Usar 'is not None' para Optional",
            "code_example": (
                "# MAL — rechaza string vacío válido\n"
                "def process(name: Optional[str]):\n"
                "    if not name:  # rechaza '' pero también None\n"
                "        return\n\n"
                "# BIEN\n"
                "def process(name: Optional[str]):\n"
                "    if name is None:\n"
                "        return\n"
                "    # name puede ser ''"
            ),
            "tags": ["optional", "none", "empty_string", "type_hints"],
        },
        {
            "type": PatternType.ANTIPATTERN,
            "language": "python",
            "title": "Mutable default arguments en funciones",
            "description": "Los mutable defaults se comparten entre todas las llamadas — bug clásico",
            "code_example": (
                "# MAL — la lista se comparte entre llamadas\n"
                "def add_item(item, items=[]):\n"
                "    items.append(item)\n"
                "    return items\n\n"
                "# BIEN\n"
                "def add_item(item, items=None):\n"
                "    if items is None:\n"
                "        items = []\n"
                "    items.append(item)\n"
                "    return items"
            ),
            "tags": ["default_args", "mutable", "bug", "gotcha"],
        },
        {
            "type": PatternType.PATTERN,
            "language": "python",
            "title": "Retry con backoff exponencial usando tenacity o manual",
            "description": "Para llamadas a APIs externas, siempre retry con backoff",
            "code_example": (
                "import time\n\n"
                "def retry_with_backoff(fn, max_retries=3, base_delay=1.0):\n"
                "    for attempt in range(max_retries + 1):\n"
                "        try:\n"
                "            return fn()\n"
                "        except Exception as e:\n"
                "            if attempt == max_retries:\n"
                "                raise\n"
                "            delay = base_delay * (2 ** attempt)\n"
                "            logger.warning(f'Retry {attempt+1}/{max_retries} after {delay}s: {e}')\n"
                "            time.sleep(delay)"
            ),
            "tags": ["retry", "backoff", "api", "resilience"],
        },
        {
            "type": PatternType.BUG,
            "language": "python",
            "title": "json.loads sobre bytes falla en Python < 3.6",
            "description": "json.loads acepta bytes desde 3.6+, pero mejor decodificar explícitamente",
            "code_example": (
                "# BIEN — funciona en todas las versiones\n"
                "raw = redis.get('key')  # puede ser bytes\n"
                "if raw:\n"
                "    data = json.loads(raw.decode() if isinstance(raw, bytes) else raw)"
            ),
            "tags": ["json", "bytes", "redis", "compatibility"],
        },
        {
            "type": PatternType.PATTERN,
            "language": "python",
            "title": "Logging con lazy evaluation para performance",
            "description": "logger.debug(f'...') evalúa el f-string incluso si el nivel no está activo",
            "code_example": (
                "# MAL — formatea el string aunque debug esté desactivado\n"
                "logger.debug(f'Procesando {len(items)} items: {items}')\n\n"
                "# BIEN — lazy evaluation\n"
                "logger.debug('Procesando %d items: %s', len(items), items)"
            ),
            "tags": ["logging", "performance", "debug"],
        },
        {
            "type": PatternType.PATTERN,
            "language": "python",
            "title": "Timezone-aware datetime siempre para timestamps",
            "description": "datetime.now() produce naive datetime. Usar timezone.utc explícitamente",
            "code_example": (
                "# MAL — naive datetime, problema en comparaciones con timezone-aware\n"
                "ts = datetime.now().isoformat()\n\n"
                "# BIEN\n"
                "from datetime import datetime, timezone\n"
                "ts = datetime.now(timezone.utc).isoformat()\n"
                "# Comparación con otro aware datetime:\n"
                "age = datetime.now(timezone.utc) - other_ts  # funciona"
            ),
            "tags": ["datetime", "timezone", "timestamp", "bug"],
        },
    ]

    def __init__(self, redis_client: redis.Redis):
        self.redis = redis_client
        self._ensure_bootstrapped()

    # ══════════════════════════════════════════════════════════════════════
    # API PÚBLICA
    # ══════════════════════════════════════════════════════════════════════

    def recall(
        self,
        task: str,
        language: str,
        top_k: int = 5,
    ) -> list[CodePattern]:
        """
        Recupera patrones relevantes para inyectar en el prompt del Architect.
        Búsqueda por tags + language matching.
        """
        # Extraer keywords de la tarea
        keywords = self._extract_keywords(task.lower())

        all_patterns = self._load_all(language)
        scored = []

        for p in all_patterns:
            score = 0.0
            p_tags = set(t.lower() for t in p.tags)
            p_words = set((p.title + " " + p.description).lower().split())

            # Tag match
            kw_set = set(keywords)
            score += len(kw_set & p_tags) * 2.0
            score += len(kw_set & p_words) * 0.5

            # Bugs y antipatterns tienen prioridad — mejor prevenir
            if p.pattern_type in (PatternType.BUG, PatternType.ANTIPATTERN):
                score *= 1.5

            # Boost por uso previo positivo
            if p.use_count > 0:
                success_rate = p.positive_outcomes / p.use_count
                score *= (0.8 + success_rate * 0.4)

            if score > 0:
                scored.append((p, score))

        scored.sort(key=lambda x: x[1], reverse=True)
        results = [p for p, _ in scored[:top_k]]

        # Registrar uso
        for p in results:
            self._increment_use(p.pattern_id)

        return results

    def learn(
        self,
        pattern_type: PatternType,
        language: str,
        title: str,
        description: str,
        code_example: str,
        tags: list[str],
        source: str = "manual",
    ) -> CodePattern:
        """Agrega un nuevo patrón manualmente o desde el pipeline."""
        import uuid
        p = CodePattern(
            pattern_id=str(uuid.uuid4())[:8],
            pattern_type=pattern_type,
            language=language,
            title=title,
            description=description,
            code_example=code_example,
            tags=tags,
            use_count=0,
            positive_outcomes=0,
            source=source,
            created_at=datetime.now(timezone.utc).isoformat(),
        )
        self._save(p)
        logger.info(f"[CODE MEM] Patrón aprendido: [{p.language}] {p.title}")
        return p

    def record_outcome(self, pattern_id: str, positive: bool):
        """Registra si un patrón resultó en buen código."""
        raw = self.redis.get(f"kernell:code:patterns:{pattern_id}")
        if not raw:
            return
        try:
            data = json.loads(raw)
            if positive:
                data["positive_outcomes"] = data.get("positive_outcomes", 0) + 1
            self.redis.set(f"kernell:code:patterns:{pattern_id}", json.dumps(data))
        except Exception:
            pass

    def format_for_prompt(self, patterns: list[CodePattern]) -> str:
        """
        Formatea patrones para inyectar en el prompt del Architect.
        Solo los relevantes, en formato conciso.
        """
        if not patterns:
            return ""

        lines = ["PATRONES RELEVANTES DE TU BASE DE CONOCIMIENTO:", ""]

        for p in patterns:
            emoji = {"bug": "🐛", "antipattern": "⚠️", "pattern": "✅", "solution": "💡", "lesson": "📚"}.get(p.pattern_type.value, "•")
            lines.append(f"{emoji} [{p.language}] {p.title}")
            lines.append(f"   Cuándo: {p.description}")
            if p.code_example and len(p.code_example) < 400:
                lines.append(f"   ```\n{p.code_example}\n   ```")
            lines.append("")

        return "\n".join(lines)

    def stats(self) -> dict:
        keys = list(self.redis.scan_iter("kernell:code:patterns:*"))
        by_type = {}
        by_lang = {}
        for k in keys:
            raw = self.redis.get(k)
            if raw:
                try:
                    d = json.loads(raw)
                    t = d.get("pattern_type", "?")
                    l = d.get("language", "?")
                    by_type[t] = by_type.get(t, 0) + 1
                    by_lang[l] = by_lang.get(l, 0) + 1
                except Exception:
                    pass
        return {
            "total": len(keys),
            "by_type": by_type,
            "by_language": by_lang,
        }

    # ══════════════════════════════════════════════════════════════════════
    # INTERNALS
    # ══════════════════════════════════════════════════════════════════════

    def _ensure_bootstrapped(self):
        if self.redis.get("kernell:code:patterns:bootstrapped"):
            return
        for bp in self.BOOTSTRAP_PATTERNS:
            self.learn(
                pattern_type=bp["type"],
                language=bp["language"],
                title=bp["title"],
                description=bp["description"],
                code_example=bp["code_example"],
                tags=bp["tags"],
                source="bootstrap",
            )
        self.redis.set("kernell:code:patterns:bootstrapped", "1")
        logger.info(f"[CODE MEM] Bootstrap: {len(self.BOOTSTRAP_PATTERNS)} patrones cargados")

    def _save(self, p: CodePattern):
        data = asdict(p)
        data["pattern_type"] = p.pattern_type.value
        self.redis.set(f"kernell:code:patterns:{p.pattern_id}", json.dumps(data))
        lang_key = f"kernell:code:patterns:lang:{p.language}"
        self.redis.sadd(lang_key, p.pattern_id)

    def _load_all(self, language: str) -> list[CodePattern]:
        # Cargar del lenguaje específico + "all" (agnósticos)
        ids = set()
        for lang in [language, "all"]:
            raw_ids = self.redis.smembers(f"kernell:code:patterns:lang:{lang}")
            ids.update(raw_ids)

        patterns = []
        for pid in ids:
            raw = self.redis.get(
                f"kernell:code:patterns:{pid if isinstance(pid,str) else pid.decode()}"
            )
            if raw:
                try:
                    d = json.loads(raw)
                    d["pattern_type"] = PatternType(d["pattern_type"])
                    patterns.append(CodePattern(**d))
                except Exception:
                    pass
        return patterns

    def _increment_use(self, pattern_id: str):
        raw = self.redis.get(f"kernell:code:patterns:{pattern_id}")
        if raw:
            try:
                d = json.loads(raw)
                d["use_count"] = d.get("use_count", 0) + 1
                self.redis.set(f"kernell:code:patterns:{pattern_id}", json.dumps(d))
            except Exception:
                pass

    def _extract_keywords(self, text: str) -> list[str]:
        """Extrae keywords relevantes del texto de la tarea."""
        # Stopwords básicas
        STOP = {
            "a", "an", "the", "and", "or", "for", "with", "in", "on",
            "to", "of", "that", "this", "is", "are", "was", "be", "do",
            "implement", "create", "build", "write", "make", "add",
            "el", "la", "los", "las", "un", "una", "y", "con", "para",
            "que", "de", "en", "una", "implementar", "crear", "hacer",
        }
        words = text.replace(",", " ").replace(".", " ").replace("(", " ").replace(")", " ").split()
        return [w for w in words if len(w) > 3 and w not in STOP]
