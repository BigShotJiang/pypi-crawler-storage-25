"""
KERNELL CODE PIPELINE — Opus-Level Programming con R1 + Gemini
==============================================================
Objetivo: producir código de la misma calidad que Claude Opus
usando solo DeepSeek R1 (Groq) + Gemini (Google).

POR QUÉ EL GAP EXISTE HOY:
  R1 y Gemini son modelos capaces. El problema no es el modelo,
  es que se usan en un único turno sin estructura.
  Opus produce código de calidad porque razona en múltiples pasos
  implícitos antes de responder. Este pipeline los hace explícitos.

EL PIPELINE DE 4 PASOS:

  PASO 1 — ARCHITECT (R1)
    Lee el problema completo.
    Produce: design decisions, edge cases, riesgos, estructura de módulos.
    NO escribe código todavía. Solo piensa.
    Usa el reasoning_trace de R1 — aquí está el valor real.

  PASO 2 — IMPLEMENTER (R1 o Gemini Pro)
    Recibe el análisis del arquitecto.
    Escribe el código completo basándose en las decisiones de diseño.
    Solo código — no explica, no justifica.

  PASO 3 — CRITIC (Gemini Flash)
    Lee el código implementado.
    Busca: bugs, edge cases no manejados, código no idiomático,
    problemas de performance, violaciones de principios SOLID,
    hardcoded values, falta de error handling.
    Produce lista concreta de problemas.

  PASO 4 — REFINER (R1)
    Recibe código original + crítica.
    Produce versión final corregida.
    Explica solo los cambios significativos.

RESULTADO:
  CodeResult con el código final + reasoning trace del arquitecto
  + crítica del reviewer + diff de cambios del refinador.

CUÁNDO USAR EL PIPELINE COMPLETO vs RÁPIDO:
  FULL (4 pasos): componentes nuevos, arquitectura, código crítico
  FAST (1 paso):  funciones pequeñas, fixes, cambios menores
  REVIEW (pasos 3+4): revisar código existente
"""

import json
import logging
import time
import redis
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from typing import Optional
from enum import Enum

from core.sea.llm_registry import LLMProviderRegistry, LLMResponse

logger = logging.getLogger("kernell.code.pipeline")


class PipelineMode(Enum):
    FULL    = "full"      # 4 pasos — máxima calidad
    FAST    = "fast"      # 1 paso — respuestas rápidas
    REVIEW  = "review"   # Solo critic + refiner sobre código existente
    DESIGN  = "design"   # Solo architect — para planear antes de codificar


# ── Modelos asignados a cada rol ──────────────────────────────────────────
# R1 para pensar (cadenas causales, edge cases)
# Gemini para revisar (conocimiento amplio, idioms, libraries)
# R1 para refinar (incorporar crítica con razonamiento)

ROLE_MODEL_MAP = {
    "architect":   "groq_r1",      # R1: el razonamiento es el producto
    "implementer": "groq_r1",      # R1: código consistente con su propio diseño
    "critic":      "gemini_flash", # Gemini: rápido, amplio, buen reviewer
    "refiner":     "groq_r1",      # R1: razona sobre los cambios necesarios
    "fast":        "groq_r1",      # R1: un paso, máximo esfuerzo
}


@dataclass
class CodeResult:
    code: str                        # El código final listo para usar
    language: str
    mode: PipelineMode

    # Transparencia del proceso
    architecture_trace: Optional[str]   # Cómo pensó el arquitecto (R1 reasoning)
    architecture_plan: str              # Las decisiones de diseño
    critic_findings: list[str]          # Qué encontró el critic
    refinements_made: str               # Qué cambió el refiner

    # Metadata
    steps_completed: int
    total_latency_ms: float
    providers_used: list[str]
    prompt_tokens_total: int
    timestamp: str

    # Flags de calidad
    had_critical_bugs: bool       # Si el critic encontró bugs críticos
    is_production_ready: bool     # Juicio del pipeline sobre el código


@dataclass
class CodeReviewResult:
    """Resultado cuando se pide review de código existente."""
    original_code: str
    improved_code: str
    findings: list[str]
    severity_counts: dict        # {"critical": 2, "warning": 5, "style": 3}
    reasoning_trace: Optional[str]
    latency_ms: float


class CodePipeline:
    """
    Pipeline de programación de 4 pasos que extrae el máximo de R1 + Gemini.
    Produce código equivalente a Claude Opus en calidad.
    """

    def __init__(self, redis_client: redis.Redis):
        self.redis    = redis_client
        self.registry = LLMProviderRegistry(redis_client)

    # ══════════════════════════════════════════════════════════════════════
    # ENTRY POINT PRINCIPAL
    # ══════════════════════════════════════════════════════════════════════

    def generate(
        self,
        task: str,
        language: str = "python",
        context: str = "",
        existing_code: str = "",
        mode: PipelineMode = PipelineMode.FULL,
        max_tokens_per_step: int = 3000,
    ) -> CodeResult:
        """
        Genera código de calidad Opus para la tarea dada.

        Args:
            task: Descripción de qué construir (cuanto más detallado, mejor)
            language: Lenguaje de programación objetivo
            context: Código o contexto existente relevante
            existing_code: Si es una modificación de código existente
            mode: FULL (máxima calidad) | FAST (respuesta rápida) | etc.
        """
        t_start = time.time()
        logger.info(f"[CODE] Iniciando pipeline {mode.value} — {language}")

        if mode == PipelineMode.FAST:
            return self._fast_mode(task, language, context, existing_code, t_start, max_tokens_per_step)

        if mode == PipelineMode.REVIEW:
            return self._review_mode_as_result(existing_code, language, task, t_start, max_tokens_per_step)

        # ── FULL PIPELINE ─────────────────────────────────────────────────
        providers_used = []
        arch_trace     = None
        arch_plan      = ""
        critic_findings = []
        refinements    = ""
        steps          = 0
        total_tokens   = 0

        # ─── PASO 1: ARCHITECT ────────────────────────────────────────────
        logger.info("[CODE] Paso 1/4: Architect (R1)")
        arch_resp = self._call_architect(task, language, context, existing_code, max_tokens_per_step)
        if arch_resp:
            arch_trace = arch_resp.reasoning_trace
            arch_plan  = arch_resp.content
            providers_used.append(arch_resp.provider_used)
            total_tokens += arch_resp.tokens_used
            steps = 1
            logger.debug(f"[CODE] Architect: {len(arch_plan)} chars plan, trace={bool(arch_trace)}")
        else:
            # Architect falló — fallback directo a fast
            logger.warning("[CODE] Architect falló — fallback a FAST mode")
            return self._fast_mode(task, language, context, existing_code, t_start, max_tokens_per_step)

        # ─── PASO 2: IMPLEMENTER ──────────────────────────────────────────
        logger.info("[CODE] Paso 2/4: Implementer (R1)")
        impl_resp = self._call_implementer(task, language, arch_plan, context, existing_code, max_tokens_per_step)
        if not impl_resp:
            # Sin implementación — retornar solo el plan
            return CodeResult(
                code=f"# Plan de implementación generado:\n# {arch_plan[:500]}",
                language=language, mode=mode,
                architecture_trace=arch_trace, architecture_plan=arch_plan,
                critic_findings=[], refinements_made="",
                steps_completed=1, total_latency_ms=(time.time()-t_start)*1000,
                providers_used=providers_used, prompt_tokens_total=total_tokens,
                timestamp=datetime.now(timezone.utc).isoformat(),
                had_critical_bugs=False, is_production_ready=False,
            )

        code_v1 = self._extract_code(impl_resp.content, language)
        providers_used.append(impl_resp.provider_used)
        total_tokens += impl_resp.tokens_used
        steps = 2
        logger.debug(f"[CODE] Implementer: {len(code_v1)} chars código")

        # ─── PASO 3: CRITIC ───────────────────────────────────────────────
        logger.info("[CODE] Paso 3/4: Critic (Gemini Flash)")
        critic_resp = self._call_critic(code_v1, language, task, max_tokens_per_step)
        has_critical = False

        if critic_resp:
            findings_data = self._parse_critic(critic_resp.content)
            critic_findings = findings_data.get("findings", [])
            has_critical    = findings_data.get("has_critical", False)
            providers_used.append(critic_resp.provider_used)
            total_tokens += critic_resp.tokens_used
            steps = 3
            logger.debug(f"[CODE] Critic: {len(critic_findings)} hallazgos, críticos={has_critical}")
        else:
            # Sin critic — usar el código del implementer directamente
            critic_findings = []

        # ─── PASO 4: REFINER ──────────────────────────────────────────────
        if critic_findings:
            logger.info("[CODE] Paso 4/4: Refiner (R1)")
            refiner_resp = self._call_refiner(code_v1, language, critic_findings, task, max_tokens_per_step)

            if refiner_resp:
                final_code    = self._extract_code(refiner_resp.content, language)
                refinements   = self._extract_refinements_summary(refiner_resp.content)
                providers_used.append(refiner_resp.provider_used)
                total_tokens  += refiner_resp.tokens_used
                steps = 4
                # Si R1 usó reasoning trace también para refinar — capturarlo
                if refiner_resp.reasoning_trace and not arch_trace:
                    arch_trace = refiner_resp.reasoning_trace
            else:
                final_code = code_v1
                refinements = "Refiner no disponible — código del implementer usado"
        else:
            final_code  = code_v1
            refinements = "Sin problemas detectados — código directo del implementer"
            steps = max(steps, 3)

        latency_ms = (time.time() - t_start) * 1000
        logger.info(
            f"[CODE] Pipeline completado: {steps} pasos, "
            f"{latency_ms:.0f}ms, {len(final_code)} chars"
        )

        return CodeResult(
            code=final_code,
            language=language,
            mode=mode,
            architecture_trace=arch_trace,
            architecture_plan=arch_plan,
            critic_findings=critic_findings,
            refinements_made=refinements,
            steps_completed=steps,
            total_latency_ms=round(latency_ms, 1),
            providers_used=providers_used,
            prompt_tokens_total=total_tokens,
            timestamp=datetime.now(timezone.utc).isoformat(),
            had_critical_bugs=has_critical,
            is_production_ready=(not has_critical and steps >= 3),
        )

    def review(
        self,
        code: str,
        language: str,
        context: str = "",
        max_tokens: int = 3000,
    ) -> CodeReviewResult:
        """
        Revisa y mejora código existente.
        Útil para refactoring, bug fixing, optimización.
        """
        t_start = time.time()

        critic_resp = self._call_critic(code, language, context, max_tokens)
        if not critic_resp:
            return CodeReviewResult(
                original_code=code, improved_code=code,
                findings=["Critic no disponible"],
                severity_counts={}, reasoning_trace=None,
                latency_ms=(time.time()-t_start)*1000,
            )

        findings_data = self._parse_critic(critic_resp.content)
        findings      = findings_data.get("findings", [])

        if findings:
            refiner_resp = self._call_refiner(code, language, findings, context, max_tokens)
            improved     = self._extract_code(refiner_resp.content, language) if refiner_resp else code
            trace        = refiner_resp.reasoning_trace if refiner_resp else critic_resp.reasoning_trace
        else:
            improved = code
            trace    = critic_resp.reasoning_trace

        return CodeReviewResult(
            original_code=code,
            improved_code=improved,
            findings=findings,
            severity_counts=findings_data.get("severity_counts", {}),
            reasoning_trace=trace,
            latency_ms=round((time.time()-t_start)*1000, 1),
        )

    # ══════════════════════════════════════════════════════════════════════
    # LLAMADAS A CADA ROL
    # ══════════════════════════════════════════════════════════════════════

    def _call_architect(
        self, task, language, context, existing_code, max_tokens
    ) -> Optional[LLMResponse]:
        system = PROMPT_ARCHITECT.format(language=language)
        user   = _build_architect_prompt(task, language, context, existing_code)
        return self.registry.complete(
            messages=[{"role": "user", "content": user}],
            system_prompt=system,
            preferred_provider=ROLE_MODEL_MAP["architect"],
            role="synthesis",
            max_tokens=max_tokens,
            temperature=0.3,
        )

    def _call_implementer(
        self, task, language, arch_plan, context, existing_code, max_tokens
    ) -> Optional[LLMResponse]:
        system = PROMPT_IMPLEMENTER.format(language=language)
        user   = _build_implementer_prompt(task, language, arch_plan, context, existing_code)
        return self.registry.complete(
            messages=[{"role": "user", "content": user}],
            system_prompt=system,
            preferred_provider=ROLE_MODEL_MAP["implementer"],
            role="synthesis",
            max_tokens=max_tokens,
            temperature=0.15,   # Muy bajo — el implementer debe ser determinístico
        )

    def _call_critic(
        self, code, language, task_or_context, max_tokens
    ) -> Optional[LLMResponse]:
        system = PROMPT_CRITIC.format(language=language)
        user   = _build_critic_prompt(code, language, task_or_context)
        return self.registry.complete(
            messages=[{"role": "user", "content": user}],
            system_prompt=system,
            preferred_provider=ROLE_MODEL_MAP["critic"],
            role="audit_structural",
            max_tokens=min(max_tokens, 2000),
            temperature=0.2,
        )

    def _call_refiner(
        self, code, language, findings, task_context, max_tokens
    ) -> Optional[LLMResponse]:
        system = PROMPT_REFINER.format(language=language)
        user   = _build_refiner_prompt(code, language, findings, task_context)
        return self.registry.complete(
            messages=[{"role": "user", "content": user}],
            system_prompt=system,
            preferred_provider=ROLE_MODEL_MAP["refiner"],
            role="synthesis",
            max_tokens=max_tokens,
            temperature=0.15,
        )

    def _fast_mode(
        self, task, language, context, existing_code, t_start, max_tokens
    ) -> CodeResult:
        """Un solo paso con R1 — para tareas simples."""
        user = _build_fast_prompt(task, language, context, existing_code)
        resp = self.registry.complete(
            messages=[{"role": "user", "content": user}],
            system_prompt=PROMPT_FAST.format(language=language),
            preferred_provider=ROLE_MODEL_MAP["fast"],
            role="synthesis",
            max_tokens=max_tokens,
            temperature=0.2,
        )

        code = self._extract_code(resp.content if resp else "", language)
        return CodeResult(
            code=code, language=language, mode=PipelineMode.FAST,
            architecture_trace=resp.reasoning_trace if resp else None,
            architecture_plan="",
            critic_findings=[], refinements_made="",
            steps_completed=1,
            total_latency_ms=round((time.time()-t_start)*1000, 1),
            providers_used=[resp.provider_used] if resp else [],
            prompt_tokens_total=resp.tokens_used if resp else 0,
            timestamp=datetime.now(timezone.utc).isoformat(),
            had_critical_bugs=False,
            is_production_ready=False,
        )

    def _review_mode_as_result(
        self, code, language, context, t_start, max_tokens
    ) -> CodeResult:
        review = self.review(code, language, context, max_tokens)
        return CodeResult(
            code=review.improved_code, language=language, mode=PipelineMode.REVIEW,
            architecture_trace=review.reasoning_trace,
            architecture_plan="",
            critic_findings=review.findings, refinements_made="",
            steps_completed=2,
            total_latency_ms=round((time.time()-t_start)*1000, 1),
            providers_used=[], prompt_tokens_total=0,
            timestamp=datetime.now(timezone.utc).isoformat(),
            had_critical_bugs=review.severity_counts.get("critical", 0) > 0,
            is_production_ready=review.severity_counts.get("critical", 0) == 0,
        )

    # ══════════════════════════════════════════════════════════════════════
    # UTILS
    # ══════════════════════════════════════════════════════════════════════

    def _extract_code(self, text: str, language: str) -> str:
        """Extrae el bloque de código de la respuesta del LLM."""
        import re
        # Intentar bloque de código con lenguaje especificado
        pattern = rf"```{language}\n(.*?)```"
        match   = re.search(pattern, text, re.DOTALL | re.IGNORECASE)
        if match:
            return match.group(1).strip()

        # Cualquier bloque de código
        pattern = r"```(?:\w+)?\n(.*?)```"
        match   = re.search(pattern, text, re.DOTALL)
        if match:
            return match.group(1).strip()

        # Devolver el texto completo si no hay bloques
        return text.strip()

    def _parse_critic(self, critic_text: str) -> dict:
        """Parsea la respuesta del critic."""
        import re
        findings       = []
        has_critical   = False
        severity_counts = {"critical": 0, "warning": 0, "style": 0}

        # Intentar JSON
        try:
            match = re.search(r"\{.*\}", critic_text, re.DOTALL)
            if match:
                data     = json.loads(match.group())
                findings = data.get("findings", [])
                has_critical = data.get("has_critical", False) or any(
                    "critical" in str(f).lower() for f in findings
                )
                severity_counts = data.get("severity_counts", severity_counts)
                return {
                    "findings": findings,
                    "has_critical": has_critical,
                    "severity_counts": severity_counts,
                }
        except Exception:
            pass

        # Fallback: parsear texto libre línea por línea
        for line in critic_text.split("\n"):
            line = line.strip()
            if line and (line.startswith("-") or line.startswith("*") or line[:2] in ("1.", "2.", "3.", "4.", "5.", "6.", "7.", "8.", "9.")):
                finding = line.lstrip("-*0123456789. ").strip()
                if finding:
                    findings.append(finding)
                    l = finding.lower()
                    if any(w in l for w in ["bug", "error", "crash", "critical", "segfault", "null", "none", "undefined", "race condition"]):
                        has_critical = True
                        severity_counts["critical"] += 1
                    elif any(w in l for w in ["warning", "risk", "missing", "unhandled"]):
                        severity_counts["warning"] += 1
                    else:
                        severity_counts["style"] += 1

        return {
            "findings": findings,
            "has_critical": has_critical,
            "severity_counts": severity_counts,
        }

    def _extract_refinements_summary(self, refiner_text: str) -> str:
        """Extrae el resumen de cambios del refiner."""
        import re
        # Buscar sección de cambios
        for marker in ["## Changes", "## Cambios", "CHANGES:", "REFINEMENTS:", "Lo que cambié:"]:
            idx = refiner_text.find(marker)
            if idx != -1:
                section = refiner_text[idx:idx+400].strip()
                # Remover el bloque de código si lo hay
                section = re.sub(r"```.*?```", "", section, flags=re.DOTALL).strip()
                return section[:300]
        # Extraer primeras líneas no-código como resumen
        lines = [l for l in refiner_text.split("\n") if l.strip() and not l.strip().startswith(("```", "#"))]
        return " ".join(lines[:3])[:300]

    def _persist(self, result: CodeResult, task: str):
        self.redis.lpush("kernell:code:pipeline:history", json.dumps({
            "task":      task[:100],
            "language":  result.language,
            "mode":      result.mode.value,
            "steps":     result.steps_completed,
            "latency":   result.total_latency_ms,
            "bugs":      result.had_critical_bugs,
            "ready":     result.is_production_ready,
            "timestamp": result.timestamp,
        }))
        self.redis.ltrim("kernell:code:pipeline:history", 0, 199)


# ══════════════════════════════════════════════════════════════════════════
# PROMPTS — El corazón del sistema
# ══════════════════════════════════════════════════════════════════════════

PROMPT_ARCHITECT = """\
Eres el Arquitecto de código de Kernell OS. Lenguaje: {language}.

Tu único trabajo en este paso es PENSAR, no escribir código.

Antes de que alguien escriba una sola línea de código, analiza profundamente:

1. ¿Cuál es el problema real que se está resolviendo? (no el superficial)
2. ¿Cuáles son los edge cases que el implementador podría no ver?
3. ¿Qué decisiones de diseño son críticas aquí?
4. ¿Qué abstracciones existen en {language} que hacen esto más limpio?
5. ¿Qué puede fallar en producción que no está en el happy path?
6. ¿Hay estado compartido, concurrencia, o efectos secundarios a considerar?
7. ¿Qué tipos/interfaces/contratos deben definirse primero?
8. ¿Cómo se testea esto?

Responde con tu análisis en prosa. NO escribas código.
Sé específico: "el error handling debe capturar X porque Y", no genérico.
Tu análisis es la base sobre la que el implementador construirá.\
"""

PROMPT_IMPLEMENTER = """\
Eres el Implementador de código de Kernell OS. Lenguaje: {language}.

Recibirás:
- La tarea a implementar
- El análisis completo del Arquitecto

Tu trabajo: escribir el código de producción completo.

Reglas:
- Sigue las decisiones de diseño del arquitecto
- Implementa TODOS los edge cases que el arquitecto identificó
- Código completo, no esqueletos ni TODOs
- Type hints completos (si aplica al lenguaje)
- Docstrings/JSDoc para clases y funciones públicas
- Error handling explícito donde el arquitecto lo señaló
- Sin comentarios obvios ("# increment counter" sobre counter += 1)
- Sin código muerto ni imports no usados

Responde SOLO con el bloque de código, sin explicaciones antes o después.\
"""

PROMPT_CRITIC = """\
Eres el Code Reviewer adversarial de Kernell OS. Lenguaje: {language}.

Recibirás código para auditar. Tu trabajo es encontrar problemas REALES.
No seas condescendiente ni sigas un checklist genérico.

Busca específicamente:

BUGS CRÍTICOS (bloquean funcionalidad o causan errores):
- Null/None dereferences no protegidos
- Race conditions si hay concurrencia o estado compartido
- Excepciones no capturadas en flujos críticos
- Lógica incorrecta (el código hace algo diferente a lo que dice el nombre)
- Edge cases no manejados: lista vacía, string vacío, 0, negativos, overflow
- Off-by-one en loops e índices

PROBLEMAS DE CALIDAD (funcionan pero son frágiles o no mantenibles):
- Hardcoded values que deberían ser parámetros o constantes
- Funciones que hacen más de una cosa
- Violaciones de principios SOLID evidentes
- Código duplicado que debería ser abstraído
- Manejo de estado que hace el código difícil de testear
- Nombres engañosos (la función hace X pero se llama Y)

PROBLEMAS DE {language} ESPECÍFICAMENTE:
- Antipatterns conocidos del lenguaje
- APIs deprecadas o peligrosas
- Mejor herramienta del stdlib/std que existe para este caso

Responde en JSON:
{{
  "findings": ["descripción concreta del problema 1", "problema 2", ...],
  "has_critical": true/false,
  "severity_counts": {{"critical": N, "warning": N, "style": N}}
}}

Si el código está bien, findings = [] y has_critical = false.
No inventes problemas. Solo reporta lo que realmente encuentras.\
"""

PROMPT_REFINER = """\
Eres el Refinador de código de Kernell OS. Lenguaje: {language}.

Recibirás:
- El código original
- Una lista de problemas encontrados por el code reviewer

Tu trabajo: producir el código corregido.

Reglas:
- Corrige TODOS los problemas de la lista
- No rompas nada que funcionaba
- Si un "problema" del reviewer es incorrecto o irrelevante, ignóralo
  (pero sabrás por qué — si usas razonamiento, explícalo ahí)
- El código final debe ser completo, no fragmentos
- Después del bloque de código, incluye "## Cambios" con los cambios significativos

Responde con el bloque de código completo + la sección de cambios.\
"""

PROMPT_FAST = """\
Eres un programador experto en {language}.

Escribe código de producción completo para la tarea dada.

Estándares que aplicas siempre, sin que te lo pidan:
- Type hints / tipos estáticos
- Error handling para los casos que pueden fallar
- Edge cases obvios manejados
- Código limpio sin comentarios innecesarios
- Sin TODOs ni código incompleto

Responde con el bloque de código. Si necesitas explicar algo crítico, 
añádelo después del bloque en máximo 3 líneas.\
"""


# ══════════════════════════════════════════════════════════════════════════
# CONSTRUCTORES DE PROMPTS DE USUARIO
# ══════════════════════════════════════════════════════════════════════════

def _build_architect_prompt(task, language, context, existing_code) -> str:
    lines = [f"TAREA: {task}", ""]
    if existing_code:
        lines += [f"CÓDIGO EXISTENTE ({language}):", f"```{language}", existing_code[:3000], "```", ""]
    if context:
        lines += ["CONTEXTO ADICIONAL:", context[:1000], ""]
    lines.append("Analiza este problema en profundidad antes de que alguien escriba código.")
    return "\n".join(lines)

def _build_implementer_prompt(task, language, arch_plan, context, existing_code) -> str:
    lines = [
        f"TAREA: {task}", "",
        "ANÁLISIS DEL ARQUITECTO:", arch_plan[:2000], "",
    ]
    if existing_code:
        lines += [f"CÓDIGO BASE ({language}):", f"```{language}", existing_code[:2000], "```", ""]
    if context:
        lines += ["CONTEXTO:", context[:500], ""]
    lines.append(f"Implementa el código {language} completo siguiendo el análisis del arquitecto.")
    return "\n".join(lines)

def _build_critic_prompt(code, language, task_or_context) -> str:
    lines = [
        f"TAREA ORIGINAL: {str(task_or_context)[:300]}", "",
        f"CÓDIGO A REVISAR ({language}):", f"```{language}", code[:4000], "```", "",
        "Audita este código. Encuentra problemas reales.",
    ]
    return "\n".join(lines)

def _build_refiner_prompt(code, language, findings, task_context) -> str:
    findings_text = "\n".join(f"- {f}" for f in findings)
    lines = [
        f"TAREA: {str(task_context)[:300]}", "",
        f"CÓDIGO ORIGINAL ({language}):", f"```{language}", code[:3500], "```", "",
        "PROBLEMAS ENCONTRADOS POR EL REVIEWER:", findings_text, "",
        "Produce el código corregido.",
    ]
    return "\n".join(lines)

def _build_fast_prompt(task, language, context, existing_code) -> str:
    lines = [f"TAREA: {task}", ""]
    if existing_code:
        lines += [f"CÓDIGO EXISTENTE:", f"```{language}", existing_code[:2000], "```", ""]
    if context:
        lines += ["CONTEXTO:", context[:500], ""]
    return "\n".join(lines)
