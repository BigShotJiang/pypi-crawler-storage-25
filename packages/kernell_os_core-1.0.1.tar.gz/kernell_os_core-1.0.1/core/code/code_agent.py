"""
CODE AGENT v2 — CodeForge: Opus-Level Programming
====================================================
Punto de entrada para todas las tareas de programación en Kernell OS.

v2 agrega dos capacidades que cierran el gap con Opus:
  1. CODEBASE CONTEXT: Recupera archivos relevantes antes de generar
  2. EXECUTION LOOP:   Ejecuta el código, ve errores, y auto-corrige

Pipeline completo:
  Tarea → [Context Retriever] → [Code Pipeline 4-step]
        → [Sandbox Executor] → ¿Funciona? → ✅ Entrega
                              → ¿Falla?   → [R1 Auto-Correct] → Re-ejecutar
                                             (máx 3 iteraciones)

Uso:
  agent = CodeAgent(redis_client)

  # Código con ejecución y auto-corrección
  result = agent.forge("implementar circuit breaker", language="python")
  assert result.execution_passed  # El código fue ejecutado y funciona

  # Solo generación sin ejecución (modo legacy)
  result = agent.code("implementar retry", language="python")

  # Review de código existente
  result = agent.review(code=existing_code, language="python")
"""

import json
import logging
import redis
from dataclasses import asdict
from datetime import datetime, timezone
from typing import Optional

from core.code.code_pipeline import CodePipeline, CodeResult, PipelineMode
from core.code.code_memory import CodeMemory, PatternType
from core.code.sandbox_executor import SandboxExecutor, ExecutionLoop, ForgeResult
from core.code.context_retriever import ContextRetriever

logger = logging.getLogger("kernell.code.agent")

FAST_MODE_THRESHOLD_CHARS = 200


class CodeAgent:
    """
    CodeForge v2: Agente de programación de Kernell OS.
    Produce código de calidad Opus usando R1 + Gemini + Execution Loop.
    """

    def __init__(
        self,
        redis_client: redis.Redis,
        default_mode: PipelineMode = PipelineMode.FULL,
        enable_execution: bool = True,
        enable_context: bool = True,
        execution_timeout_s: int = 10,
        max_correction_loops: int = 3,
    ):
        self.redis     = redis_client
        self.pipeline  = CodePipeline(redis_client)
        self.memory    = CodeMemory(redis_client)
        self.executor  = ExecutionLoop(
            redis_client,
            max_iterations=max_correction_loops,
            timeout_s=execution_timeout_s,
        )
        self.retriever = ContextRetriever(redis_client)
        self._mode     = default_mode
        self._exec_enabled = enable_execution
        self._ctx_enabled  = enable_context

    # ══════════════════════════════════════════════════════════════════════
    # API v2 — FORGE: Genera + Ejecuta + Auto-corrige
    # ══════════════════════════════════════════════════════════════════════

    def forge(
        self,
        task: str,
        language: str = "python",
        context: str = "",
        existing_code: str = "",
        target_files: list = None,
        test_code: str = "",
        mode: Optional[PipelineMode] = None,
        max_tokens: int = 3000,
    ) -> ForgeResult:
        """
        Pipeline completo Opus-level:
          1. Recupera contexto del codebase
          2. Genera código con el pipeline de 4 pasos
          3. Ejecuta en sandbox
          4. Si falla → R1 auto-corrige (máx 3 loops)
          5. Entrega resultado verificado
        """
        if mode is None:
            mode = (
                PipelineMode.FAST
                if len(task) < FAST_MODE_THRESHOLD_CHARS and not existing_code
                else self._mode
            )

        # Paso 1: Recuperar contexto del codebase
        codebase_context = ""
        if self._ctx_enabled:
            try:
                ctx_payload = self.retriever.retrieve(
                    task=task, language=language,
                    target_files=target_files, max_files=5,
                )
                codebase_context = self.retriever.format_for_prompt(ctx_payload)
                logger.info(
                    f"[FORGE] Context: {ctx_payload.total_chars} chars from "
                    f"{len(ctx_payload.files)} files"
                )
            except Exception as e:
                logger.warning(f"[FORGE] Context retrieval failed: {e}")

        # Recuperar patrones de memoria
        patterns = self.memory.recall(task, language, top_k=4)
        pattern_context = self.memory.format_for_prompt(patterns)

        # Enriquecer contexto: codebase + patrones + contexto del usuario
        enriched_context = "\n\n".join(filter(None, [
            codebase_context, pattern_context, context,
        ]))

        logger.info(
            f"[FORGE] task='{task[:60]}' lang={language} mode={mode.value} "
            f"patterns={len(patterns)} exec={self._exec_enabled}"
        )

        # Paso 2: Generar código con el pipeline
        pipeline_result = self.pipeline.generate(
            task=task,
            language=language,
            context=enriched_context,
            existing_code=existing_code,
            mode=mode,
            max_tokens_per_step=max_tokens,
        )

        if not pipeline_result or not pipeline_result.code:
            return ForgeResult(
                code="", language=language, executed=False,
                execution_passed=False, iterations_used=0,
                max_iterations=self.executor.max_iterations,
                execution_results=[], correction_attempts=[],
                final_stdout="", final_stderr="Pipeline produced no code",
                total_time_ms=pipeline_result.total_latency_ms if pipeline_result else 0,
                architecture_trace=pipeline_result.architecture_trace if pipeline_result else None,
                critic_findings=pipeline_result.critic_findings if pipeline_result else [],
                is_production_ready=False,
            )

        # Paso 3: Ejecutar en sandbox + auto-corrección
        if self._exec_enabled and language == "python":
            forge_result = self.executor.run(
                code=pipeline_result.code,
                language=language,
                test_code=test_code,
                pipeline_ref=self.pipeline,
                task_context=task,
            )

            # Enriquecer resultado con datos del pipeline
            forge_result.architecture_trace = pipeline_result.architecture_trace
            forge_result.critic_findings = pipeline_result.critic_findings

            # Aprendizaje
            if forge_result.execution_passed and patterns:
                for p in patterns:
                    self.memory.record_outcome(p.pattern_id, positive=True)

            self._persist(task, language, forge_result)
            return forge_result

        # Sin ejecución → wrap pipeline result en ForgeResult
        result = ForgeResult(
            code=pipeline_result.code,
            language=language,
            executed=False,
            execution_passed=False,
            iterations_used=0,
            max_iterations=self.executor.max_iterations,
            execution_results=[],
            correction_attempts=[],
            final_stdout="",
            final_stderr="",
            total_time_ms=pipeline_result.total_latency_ms,
            architecture_trace=pipeline_result.architecture_trace,
            critic_findings=pipeline_result.critic_findings,
            is_production_ready=pipeline_result.is_production_ready,
        )

        self._persist(task, language, result)
        return result

    # ══════════════════════════════════════════════════════════════════════
    # API LEGACY — Sin execution loop
    # ══════════════════════════════════════════════════════════════════════

    def code(
        self,
        task: str,
        language: str = "python",
        context: str = "",
        existing_code: str = "",
        mode: Optional[PipelineMode] = None,
        max_tokens: int = 3000,
    ) -> CodeResult:
        """
        Genera código SIN execution loop (modo legacy).
        Aún incluye context retrieval si está habilitado.
        """
        if mode is None:
            mode = (
                PipelineMode.FAST
                if len(task) < FAST_MODE_THRESHOLD_CHARS and not existing_code
                else self._mode
            )

        # Context retrieval (v2)
        codebase_context = ""
        if self._ctx_enabled:
            try:
                ctx = self.retriever.retrieve(task=task, language=language)
                codebase_context = self.retriever.format_for_prompt(ctx)
            except Exception:
                pass

        patterns = self.memory.recall(task, language, top_k=4)
        pattern_context = self.memory.format_for_prompt(patterns)
        enriched_context = "\n\n".join(filter(None, [
            codebase_context, pattern_context, context,
        ]))

        result = self.pipeline.generate(
            task=task, language=language,
            context=enriched_context, existing_code=existing_code,
            mode=mode, max_tokens_per_step=max_tokens,
        )

        if result and result.is_production_ready and patterns:
            for p in patterns:
                self.memory.record_outcome(p.pattern_id, positive=True)

        return result

    def review(
        self,
        code: str,
        language: str = "python",
        context: str = "",
        max_tokens: int = 3000,
    ) -> CodeResult:
        """Revisa y mejora código existente."""
        patterns = self.memory.recall(f"review {language} code", language, top_k=3)
        pattern_context = self.memory.format_for_prompt(patterns)
        enriched_context = "\n\n".join(filter(None, [context, pattern_context]))

        return self.pipeline.generate(
            task=f"Review y mejora del código {language}",
            language=language, context=enriched_context,
            existing_code=code, mode=PipelineMode.REVIEW,
            max_tokens_per_step=max_tokens,
        )

    def design(
        self,
        task: str,
        language: str = "python",
        context: str = "",
        max_tokens: int = 2000,
    ) -> str:
        """Solo análisis arquitectónico — sin implementar."""
        from core.code.code_pipeline import PROMPT_ARCHITECT, _build_architect_prompt
        from core.sea.llm_registry import LLMProviderRegistry

        patterns = self.memory.recall(task, language, top_k=3)
        pattern_context = self.memory.format_for_prompt(patterns)

        # v2: incluir contexto del codebase
        codebase_context = ""
        if self._ctx_enabled:
            try:
                ctx = self.retriever.retrieve(task=task, language=language)
                codebase_context = self.retriever.format_for_prompt(ctx)
            except Exception:
                pass

        enriched_context = "\n\n".join(filter(None, [
            codebase_context, pattern_context, context,
        ]))

        registry = LLMProviderRegistry(self.redis)
        user_msg = _build_architect_prompt(task, language, enriched_context, "")
        resp = registry.complete(
            messages=[{"role": "user", "content": user_msg}],
            system_prompt=PROMPT_ARCHITECT.format(language=language),
            preferred_provider="groq_r1",
            role="synthesis",
            max_tokens=max_tokens,
            temperature=0.3,
        )

        if resp:
            return (
                f"## Plan Arquitectónico: {task}\n\n"
                f"{resp.content}\n\n"
                + (f"---\n### Razonamiento interno de R1:\n{resp.reasoning_trace}"
                   if resp.reasoning_trace else "")
            )
        return f"Design agent no disponible para: {task}"

    # ══════════════════════════════════════════════════════════════════════
    # UTILIDADES
    # ══════════════════════════════════════════════════════════════════════

    def learn_from_code(
        self, title: str, description: str, code: str,
        language: str, tags: list, is_antipattern: bool = False,
    ):
        """Enseña un patrón al agente."""
        ptype = PatternType.ANTIPATTERN if is_antipattern else PatternType.SOLUTION
        self.memory.learn(
            pattern_type=ptype, language=language,
            title=title, description=description,
            code_example=code, tags=tags, source="manual",
        )

    def stats(self) -> dict:
        """Estado del agente de código."""
        mem_stats = self.memory.stats()
        history = self.redis.lrange("kernell:code:pipeline:history", 0, 19)
        recent = [json.loads(h) for h in history if h]

        # Execution loop stats
        exec_passes = int(self.redis.get("kernell:code:execution_loop:passes") or 0)
        exec_fails = int(self.redis.get("kernell:code:execution_loop:failures") or 0)
        exec_total = exec_passes + exec_fails

        return {
            "code_memory": mem_stats,
            "recent_runs": len(recent),
            "avg_latency_ms": round(
                sum(r.get("latency", 0) for r in recent) / max(len(recent), 1), 0
            ),
            "production_rate": round(
                sum(1 for r in recent if r.get("ready")) / max(len(recent), 1) * 100, 1
            ),
            "execution_loop": {
                "total_runs": exec_total,
                "pass_rate": round(exec_passes / max(exec_total, 1) * 100, 1),
                "passes": exec_passes,
                "failures": exec_fails,
            },
            "context_retrieval_enabled": self._ctx_enabled,
            "execution_enabled": self._exec_enabled,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def generate_for_pfe(
        self, proposal_description: str,
        target_files: list, context: str = "",
    ) -> ForgeResult:
        """Versión especializada para el PFE de Kernell OS."""
        kernell_context = (
            "CONTEXTO: Este código es para Kernell OS. "
            "Estándares del sistema:\n"
            "- Redis con decode_responses=False (siempre decode manual)\n"
            "- Logging con logger = logging.getLogger('kernell.módulo')\n"
            "- Dataclasses para structs de datos\n"
            "- Timestamps con datetime.now(timezone.utc).isoformat()\n"
            "- Archivos target: " + ", ".join(target_files) + "\n\n"
            + context
        )

        return self.forge(
            task=proposal_description,
            language="python",
            context=kernell_context,
            target_files=target_files,
            mode=PipelineMode.FULL,
        )

    def _persist(self, task: str, language: str, result):
        """Persiste en historial."""
        try:
            if isinstance(result, ForgeResult):
                entry = {
                    "task": task[:100],
                    "language": language,
                    "executed": result.executed,
                    "passed": result.execution_passed,
                    "iterations": result.iterations_used,
                    "latency": result.total_time_ms,
                    "ready": result.is_production_ready,
                    "timestamp": result.timestamp,
                }
            else:
                entry = {
                    "task": task[:100],
                    "language": language,
                    "mode": result.mode.value if hasattr(result, "mode") else "unknown",
                    "latency": result.total_latency_ms if hasattr(result, "total_latency_ms") else 0,
                    "bugs": result.had_critical_bugs if hasattr(result, "had_critical_bugs") else False,
                    "ready": result.is_production_ready if hasattr(result, "is_production_ready") else False,
                    "timestamp": result.timestamp if hasattr(result, "timestamp") else "",
                }
            self.redis.lpush("kernell:code:pipeline:history", json.dumps(entry))
            self.redis.ltrim("kernell:code:pipeline:history", 0, 499)
        except Exception:
            pass
