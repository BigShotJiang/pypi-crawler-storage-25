"""
CONTEXT RETRIEVER — Codebase-Aware Context Injection
=====================================================
El segundo componente que cierra el gap con Opus.

Opus tiene acceso al codebase completo en su contexto.
R1 en Groq tiene contexto limitado.
La solución: recuperar SOLO los archivos relevantes del codebase
antes de generar código, e inyectarlos como contexto.

PIPELINE:
  1. Tarea llega al CodeAgent
  2. ContextRetriever busca los 3-5 archivos más relevantes
  3. Extrae las funciones/clases que importan (no todo el archivo)
  4. Inyecta como contexto en el prompt del Architect
  5. R1 ahora VE el código real del sistema, no genera en el vacío

BÚSQUEDA:
  - Qdrant (búsqueda semántica si los archivos están indexados)
  - Fallback: búsqueda por keywords en el filesystem
  - Siempre incluye imports del archivo target si existe
"""

import json
import logging
import os
import re
import subprocess
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Optional

import redis

logger = logging.getLogger("kernell.code.context")

# Directorio raíz del proyecto
PROJECT_ROOT = "/home/anny/kernell-os"

# Extensiones a indexar
CODE_EXTENSIONS = {".py", ".js", ".ts", ".yaml", ".yml", ".json", ".md"}

# Archivos a ignorar
IGNORE_DIRS = {
    ".git", ".venv", "venv", "__pycache__", "node_modules",
    ".agent", "extracted_antigravity", "extracted_kernell", "system_backup", "logs",
    "snapshots", "qdrant_storage", "mnt_sync", "C:",
}

# Máximo de caracteres de contexto a inyectar
MAX_CONTEXT_CHARS = 8000
MAX_FILE_CHARS = 3000


@dataclass
class CodeFile:
    """Un archivo del codebase con su contenido relevante."""
    path: str                      # Ruta relativa al proyecto
    content: str                   # Contenido (truncado si necesario)
    relevance_score: float         # 0.0 - 1.0
    retrieval_method: str          # "keyword" | "qdrant" | "import" | "target"
    functions_found: list          # Funciones/clases encontradas
    total_lines: int


@dataclass
class ContextPayload:
    """El contexto completo a inyectar en el prompt del Architect."""
    files: list                    # Lista de CodeFile (como dicts)
    total_chars: int
    retrieval_methods_used: list
    summary: str                   # Resumen corto del contexto para logging
    timestamp: str = ""

    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = datetime.now(timezone.utc).isoformat()


class ContextRetriever:
    """
    Recupera archivos relevantes del codebase para inyección en prompts.
    Combina búsqueda por keywords + búsqueda semántica en Qdrant.
    """

    def __init__(
        self,
        redis_client: redis.Redis,
        project_root: str = PROJECT_ROOT,
        qdrant_url: str = "http://localhost:6333",
        use_qdrant: bool = True,
    ):
        self.redis = redis_client
        self.root = project_root
        self.qdrant_url = qdrant_url
        self.use_qdrant = use_qdrant

    def retrieve(
        self,
        task: str,
        language: str = "python",
        target_files: list = None,
        max_files: int = 5,
        max_chars: int = MAX_CONTEXT_CHARS,
    ) -> ContextPayload:
        """
        Recupera contexto relevante del codebase.
        
        Estrategia en capas:
          1. Si hay target_files explícitos → leerlos primero
          2. Buscar por keywords extraídos de la tarea
          3. Si Qdrant disponible → búsqueda semántica adicional
          4. Deduplicar y truncar al presupuesto de caracteres
        """
        found_files = []
        methods_used = set()

        # Capa 1: Archivos target explícitos
        if target_files:
            for tf in target_files:
                cf = self._read_file(tf, method="target", score=1.0)
                if cf:
                    found_files.append(cf)
                    methods_used.add("target")

        # Capa 2: Búsqueda por keywords en el filesystem
        keywords = self._extract_keywords(task, language)
        if keywords:
            keyword_files = self._search_by_keywords(
                keywords, language,
                max_results=max_files - len(found_files),
            )
            for kf in keyword_files:
                if not any(f.path == kf.path for f in found_files):
                    found_files.append(kf)
                    methods_used.add("keyword")

        # Capa 3: Búsqueda semántica en Qdrant (si disponible)
        if self.use_qdrant and len(found_files) < max_files:
            qdrant_files = self._search_qdrant(
                task, max_results=max_files - len(found_files)
            )
            for qf in qdrant_files:
                if not any(f.path == qf.path for f in found_files):
                    found_files.append(qf)
                    methods_used.add("qdrant")

        # Ordenar por relevancia
        found_files.sort(key=lambda f: f.relevance_score, reverse=True)

        # Truncar al presupuesto de caracteres
        context_files = self._fit_budget(found_files, max_chars)

        # Formatear para logging
        summary = self._build_summary(context_files)

        logger.info(
            f"[CONTEXT] Retrieved {len(context_files)} files for task "
            f"'{task[:50]}' via {methods_used}"
        )

        return ContextPayload(
            files=[self._file_to_dict(f) for f in context_files],
            total_chars=sum(len(f.content) for f in context_files),
            retrieval_methods_used=list(methods_used),
            summary=summary,
        )

    def format_for_prompt(self, payload: ContextPayload) -> str:
        """
        Formatea el contexto para inyectar en el prompt del Architect.
        Produce un bloque legible que R1 puede usar para entender el codebase.
        """
        if not payload.files:
            return ""

        parts = [
            "## EXISTING CODEBASE CONTEXT",
            f"The following {len(payload.files)} file(s) from the project are relevant to this task.",
            "Study them carefully before designing your solution.",
            "",
        ]

        for f in payload.files:
            path = f.get("path", "unknown")
            content = f.get("content", "")
            funcs = f.get("functions_found", [])

            parts.append(f"### {path}")
            if funcs:
                parts.append(f"Key symbols: {', '.join(funcs[:10])}")
            parts.append(f"```python\n{content}\n```")
            parts.append("")

        return "\n".join(parts)

    # ══════════════════════════════════════════════════════════════════════
    # ESTRATEGIAS DE BÚSQUEDA
    # ══════════════════════════════════════════════════════════════════════

    def _search_by_keywords(
        self, keywords: list, language: str, max_results: int = 5
    ) -> list:
        """
        Busca archivos que contengan las keywords usando grep.
        Rápido y siempre disponible.
        """
        ext_map = {"python": "py", "javascript": "js", "typescript": "ts"}
        ext = ext_map.get(language, "py")
        results = []

        for kw in keywords[:8]:  # Limitar búsqueda
            try:
                proc = subprocess.run(
                    [
                        "grep", "-rl", "--include", f"*.{ext}",
                        "-m", "3",  # max 3 matches por keyword
                        kw, self.root,
                    ],
                    capture_output=True, text=True, timeout=3,
                )
                if proc.returncode == 0 and proc.stdout:
                    for path in proc.stdout.strip().split("\n"):
                        path = path.strip()
                        if not path or self._should_ignore(path):
                            continue
                        rel = os.path.relpath(path, self.root)
                        if not any(r.path == rel for r in results):
                            cf = self._read_file(rel, method="keyword", score=0.6)
                            if cf:
                                results.append(cf)
                        if len(results) >= max_results:
                            return results
            except Exception:
                continue

        return results[:max_results]

    def _search_qdrant(self, query: str, max_results: int = 3) -> list:
        """
        Búsqueda semántica en Qdrant.
        Usa embeddings de Gemini para encontrar archivos similares.
        Solo funciona si el codebase fue previamente indexado.
        """
        try:
            import urllib.request

            # Generar embedding de la query
            embedding = self._get_embedding(query)
            if not embedding:
                return []

            # Buscar en Qdrant
            search_payload = {
                "vector": embedding,
                "limit": max_results,
                "with_payload": True,
            }

            req = urllib.request.Request(
                f"{self.qdrant_url}/collections/kernell_memory/points/search",
                data=json.dumps(search_payload).encode(),
                headers={"Content-Type": "application/json"},
                method="POST",
            )

            resp = urllib.request.urlopen(req, timeout=5)
            data = json.loads(resp.read())

            results = []
            for hit in data.get("result", []):
                payload = hit.get("payload", {})
                path = payload.get("file_path", "")
                if path:
                    cf = self._read_file(
                        path, method="qdrant",
                        score=hit.get("score", 0.5),
                    )
                    if cf:
                        results.append(cf)

            return results

        except Exception as e:
            logger.debug(f"[CONTEXT] Qdrant search unavailable: {e}")
            return []

    # ══════════════════════════════════════════════════════════════════════
    # UTILIDADES
    # ══════════════════════════════════════════════════════════════════════

    def _read_file(
        self, path: str, method: str = "direct", score: float = 0.5
    ) -> Optional[CodeFile]:
        """Lee un archivo y extrae las funciones/clases principales."""
        abs_path = os.path.join(self.root, path) if not os.path.isabs(path) else path
        rel_path = os.path.relpath(abs_path, self.root)

        if not os.path.isfile(abs_path):
            return None

        try:
            with open(abs_path, "r", errors="ignore") as f:
                content = f.read()
        except Exception:
            return None

        total_lines = content.count("\n") + 1

        # Extraer nombres de funciones y clases
        functions = []
        for line in content.split("\n"):
            stripped = line.strip()
            if stripped.startswith("def "):
                name = stripped[4:].split("(")[0].strip()
                if not name.startswith("_"):
                    functions.append(name)
            elif stripped.startswith("class "):
                name = stripped[6:].split("(")[0].split(":")[0].strip()
                functions.append(name)

        # Truncar contenido si es muy largo
        if len(content) > MAX_FILE_CHARS:
            content = self._smart_truncate(content, MAX_FILE_CHARS)

        return CodeFile(
            path=rel_path,
            content=content,
            relevance_score=score,
            retrieval_method=method,
            functions_found=functions[:20],
            total_lines=total_lines,
        )

    def _smart_truncate(self, content: str, max_chars: int) -> str:
        """
        Trunca inteligentemente: mantiene imports, signatures de clases/funciones,
        y trunca los cuerpos largos de funciones.
        """
        lines = content.split("\n")
        result = []
        char_count = 0
        in_long_function = False
        skip_count = 0

        for line in lines:
            stripped = line.strip()

            # Siempre incluir imports y definiciones
            is_important = (
                stripped.startswith(("import ", "from ", "class ", "def "))
                or stripped.startswith(("@", "#!"))
                or stripped == ""
                or line.startswith("# ")
            )

            if is_important:
                in_long_function = False
                skip_count = 0

            if in_long_function:
                skip_count += 1
                if skip_count == 1:
                    result.append("        # ... (truncated)")
                continue

            result.append(line)
            char_count += len(line) + 1

            # Detectar inicio de función larga
            if stripped.startswith("def ") and char_count > max_chars * 0.4:
                in_long_function = True

            if char_count >= max_chars:
                result.append("# ... (file truncated)")
                break

        return "\n".join(result)

    def _extract_keywords(self, task: str, language: str) -> list:
        """Extrae keywords relevantes del texto de la tarea."""
        # Filtrar palabras comunes
        stop_words = {
            "the", "a", "an", "is", "are", "was", "were", "be", "been", "being",
            "have", "has", "had", "do", "does", "did", "will", "would", "could",
            "should", "may", "might", "shall", "can", "need", "must",
            "and", "or", "but", "if", "then", "else", "when", "while",
            "for", "to", "from", "by", "on", "in", "at", "with", "of",
            "that", "this", "which", "who", "what", "where", "how", "why",
            "it", "its", "i", "we", "you", "they", "he", "she",
            "not", "no", "yes", "all", "each", "any", "some",
            "implementar", "crear", "agregar", "hacer", "usar", "un", "una",
            "el", "la", "los", "las", "de", "en", "con", "por", "para",
            "que", "del", "al", "se", "es", "como", "más", "muy",
            "code", "function", "class", "method", "file", "module",
            "nuevo", "nueva", "sistema", "add", "new", "create", "implement",
        }

        # Extraer palabras significativas
        words = re.findall(r'\b[a-zA-Z_][a-zA-Z0-9_]{2,}\b', task.lower())
        keywords = [w for w in words if w not in stop_words and len(w) > 2]

        # Detectar nombres compuestos (snake_case, camelCase)
        compound = re.findall(r'\b[a-zA-Z_][a-zA-Z0-9_]*(?:_[a-zA-Z0-9_]+)+\b', task)
        keywords.extend(compound)

        # Deduplicar manteniendo orden
        seen = set()
        unique = []
        for k in keywords:
            if k not in seen:
                seen.add(k)
                unique.append(k)

        return unique[:15]

    def _should_ignore(self, path: str) -> bool:
        """Verifica si un path debe ser ignorado."""
        for ignore in IGNORE_DIRS:
            if f"/{ignore}/" in path or path.startswith(ignore):
                return True
        return False

    def _fit_budget(self, files: list, max_chars: int) -> list:
        """Selecciona archivos que caben en el presupuesto de caracteres."""
        result = []
        chars_used = 0
        for f in files:
            file_chars = len(f.content)
            if chars_used + file_chars <= max_chars:
                result.append(f)
                chars_used += file_chars
            elif chars_used < max_chars:
                # Truncar el último archivo para que quepa
                remaining = max_chars - chars_used
                f.content = f.content[:remaining] + "\n# ... (truncated to fit budget)"
                result.append(f)
                break
        return result

    def _build_summary(self, files: list) -> str:
        """Resumen corto del contexto para logging."""
        if not files:
            return "No relevant files found"
        paths = [f.path for f in files]
        return f"{len(files)} files: {', '.join(paths)}"

    def _file_to_dict(self, cf: CodeFile) -> dict:
        """Convierte CodeFile a dict para serialización."""
        return {
            "path": cf.path,
            "content": cf.content,
            "relevance_score": cf.relevance_score,
            "retrieval_method": cf.retrieval_method,
            "functions_found": cf.functions_found,
            "total_lines": cf.total_lines,
        }

    def _get_embedding(self, text: str) -> Optional[list]:
        """Genera embedding 100% LOCAL via fastembed (Jina 768d)."""
        try:
            from agents.core.memory.embedding_engine import get_query_embedding
            return get_query_embedding(str(text)[:8192])
        except Exception as e:
            logger.debug(f"[CONTEXT] Embedding generation failed: {e}")
            return None
