#!/usr/bin/env python3
"""
Kernell OS — Closed Learning Loop Engine
══════════════════════════════════════════
Inspired by Hermes Agent (Nous Research, 2026).

After complex tasks (5+ tool calls), this engine:
1. Analyzes the execution trace (steps, tools, outcomes)
2. Extracts reusable patterns
3. Generates a Markdown skill file in .agent/skills/
4. Indexes the skill in Redis for fast matching on future tasks

The key insight: an AI system that LEARNS from its own executions
becomes exponentially more capable over time, unlike one that
starts fresh every session.

Redis keys:
  kernell:learning:skills_index    — HASH  skill_id → JSON metadata
  kernell:learning:task_traces     — LIST  recent task traces (capped)
  kernell:learning:stats           — HASH  counters
"""
import hashlib
import json
import logging
import os
import re
import time
import uuid
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

logger = logging.getLogger("kernell.learning_loop")

PROJECT_ROOT = Path(__file__).parent.parent.parent.resolve()
SKILLS_DIR = PROJECT_ROOT / ".agent" / "skills"
LEARNED_PREFIX = "learned_"
MAX_TRACES = 200
MIN_STEPS_FOR_LEARNING = 5


# ═══════════════════════════════════════════════════════════════════
# Data Structures
# ═══════════════════════════════════════════════════════════════════

class TaskTrace:
    """A recorded trace of a completed agentic task."""

    def __init__(
        self,
        task_id: str,
        description: str,
        steps: List[Dict],
        outcome: str = "success",
        total_time_ms: int = 0,
        model_used: str = "unknown",
        tags: Optional[List[str]] = None,
    ):
        self.task_id = task_id
        self.description = description
        self.steps = steps  # [{"tool": "...", "input": "...", "output_summary": "...", "success": True}]
        self.outcome = outcome
        self.total_time_ms = total_time_ms
        self.model_used = model_used
        self.tags = tags or []
        self.timestamp = time.time()

    @property
    def step_count(self) -> int:
        return len(self.steps)

    @property
    def tools_used(self) -> List[str]:
        return list(dict.fromkeys(s.get("tool", "unknown") for s in self.steps))

    @property
    def success_rate(self) -> float:
        if not self.steps:
            return 0.0
        ok = sum(1 for s in self.steps if s.get("success", True))
        return ok / len(self.steps)

    def to_dict(self) -> dict:
        return {
            "task_id": self.task_id,
            "description": self.description,
            "steps": self.steps,
            "outcome": self.outcome,
            "step_count": self.step_count,
            "tools_used": self.tools_used,
            "success_rate": self.success_rate,
            "total_time_ms": self.total_time_ms,
            "model_used": self.model_used,
            "tags": self.tags,
            "timestamp": self.timestamp,
        }


# ═══════════════════════════════════════════════════════════════════
# Pattern Extractor
# ═══════════════════════════════════════════════════════════════════

class PatternExtractor:
    """Analyzes task traces and extracts reusable workflow patterns."""

    # Categories of patterns we look for
    PATTERN_CATEGORIES = {
        "api_integration": ["fetch", "api", "endpoint", "request", "response", "REST", "POST", "GET"],
        "file_operations": ["create", "write", "read", "edit", "modify", "file", "directory"],
        "debugging": ["fix", "bug", "error", "debug", "trace", "exception", "crash"],
        "refactoring": ["refactor", "clean", "optimize", "improve", "restructure"],
        "testing": ["test", "spec", "assert", "coverage", "verify", "validate"],
        "deployment": ["deploy", "build", "compile", "bundle", "serve", "docker"],
        "security": ["auth", "token", "encrypt", "permission", "vault", "key"],
        "database": ["redis", "sql", "query", "migrate", "schema", "index"],
        "frontend": ["component", "render", "style", "css", "jsx", "react", "dom"],
        "infrastructure": ["config", "env", "setup", "install", "service", "systemd"],
    }

    @classmethod
    def categorize(cls, description: str, tools_used: List[str]) -> List[str]:
        """Determine which categories a task belongs to."""
        text = f"{description} {' '.join(tools_used)}".lower()
        matches = []
        for cat, keywords in cls.PATTERN_CATEGORIES.items():
            score = sum(1 for kw in keywords if kw in text)
            if score >= 2:
                matches.append(cat)
        return matches or ["general"]

    @classmethod
    def extract_workflow(cls, trace: TaskTrace) -> Dict:
        """Extract a reusable workflow pattern from a task trace."""
        categories = cls.categorize(trace.description, trace.tools_used)

        # Identify the critical path (successful steps in order)
        critical_path = []
        for i, step in enumerate(trace.steps):
            if step.get("success", True):
                critical_path.append({
                    "order": i + 1,
                    "tool": step.get("tool", "unknown"),
                    "purpose": step.get("input_summary", step.get("input", "")[:100]),
                    "key_output": step.get("output_summary", "")[:200],
                })

        # Detect retry patterns (same tool called multiple times)
        tool_counts = {}
        for s in trace.steps:
            t = s.get("tool", "unknown")
            tool_counts[t] = tool_counts.get(t, 0) + 1
        retried_tools = {t: c for t, c in tool_counts.items() if c > 1}

        # Extract error recovery patterns
        error_recoveries = []
        for i, step in enumerate(trace.steps):
            if not step.get("success", True) and i + 1 < len(trace.steps):
                next_step = trace.steps[i + 1]
                if next_step.get("success", True):
                    error_recoveries.append({
                        "failed_tool": step.get("tool"),
                        "recovery_tool": next_step.get("tool"),
                        "recovery_action": next_step.get("input_summary", "")[:100],
                    })

        return {
            "categories": categories,
            "critical_path": critical_path,
            "tools_sequence": trace.tools_used,
            "retried_tools": retried_tools,
            "error_recoveries": error_recoveries,
            "total_steps": trace.step_count,
            "success_rate": trace.success_rate,
        }

    @classmethod
    def generate_skill_name(cls, description: str, categories: List[str]) -> str:
        """Generate a descriptive skill ID from the task."""
        # Clean description to create a short identifier
        words = re.sub(r'[^a-z0-9\s]', '', description.lower()).split()
        # Take meaningful words (skip common ones)
        stop_words = {"the", "a", "an", "to", "for", "in", "on", "at", "is", "it", "of", "and", "or", "with"}
        meaningful = [w for w in words if w not in stop_words and len(w) > 2][:4]

        if meaningful:
            base = "_".join(meaningful)
        else:
            base = categories[0] if categories else "general"

        # Add hash suffix for uniqueness
        h = hashlib.sha256(description.encode()).hexdigest()[:6]
        return f"{LEARNED_PREFIX}{base}_{h}"


# ═══════════════════════════════════════════════════════════════════
# Skill Generator
# ═══════════════════════════════════════════════════════════════════

class SkillGenerator:
    """Generates reusable skill files from extracted patterns."""

    SKILL_TEMPLATE = """---
name: {name}
description: {description}
version: 1.0
created: {date}
source: closed_learning_loop
learned_from: {task_id}
categories: [{categories}]
confidence: {confidence}
uses: {uses}
---

# 🧠 {name}

> Auto-generated by the Kernell OS Closed Learning Loop.
> Learned from task `{task_id}` on {date}.

## When To Use
This skill applies when the task involves:
{when_to_use}

## Workflow Pattern

### Critical Path ({total_steps} steps, {success_rate}% success rate)
{critical_path_md}

### Tools Required
{tools_md}

{error_recovery_md}

## Key Observations
{observations}

## Refinement History
| Date | Trigger | Change |
|------|---------|--------|
| {date} | Initial learning | Created from task `{task_id}` |
"""

    @classmethod
    def generate(cls, trace: TaskTrace, workflow: Dict) -> str:
        """Generate a complete SKILL.md from a trace and workflow."""
        categories = workflow["categories"]
        name = " ".join(w.capitalize() for w in categories[:2]) + " Workflow"

        # When to use
        when_lines = []
        for cat in categories:
            when_lines.append(f"- Tasks involving **{cat.replace('_', ' ')}** operations")
        for tool in workflow["tools_sequence"][:5]:
            when_lines.append(f"- Workflows that use `{tool}`")
        when_to_use = "\n".join(when_lines)

        # Critical path
        cp_lines = []
        for step in workflow["critical_path"][:10]:
            cp_lines.append(f"{step['order']}. **`{step['tool']}`** — {step['purpose']}")
            if step.get("key_output"):
                cp_lines.append(f"   - Output: _{step['key_output'][:80]}_")
        critical_path_md = "\n".join(cp_lines) or "_(no critical path extracted)_"

        # Tools
        tools_md = "\n".join(f"- `{t}`" for t in workflow["tools_sequence"]) or "- _(none)_"

        # Error recovery
        error_recovery_md = ""
        if workflow["error_recoveries"]:
            error_recovery_md = "### Error Recovery Patterns\n"
            for er in workflow["error_recoveries"]:
                error_recovery_md += (
                    f"- If `{er['failed_tool']}` fails → use `{er['recovery_tool']}`: "
                    f"_{er['recovery_action']}_\n"
                )

        # Observations
        obs_lines = []
        obs_lines.append(f"- Task completed in {trace.total_time_ms}ms with {trace.step_count} steps")
        obs_lines.append(f"- Overall success rate: {workflow['success_rate']:.0%}")
        if workflow["retried_tools"]:
            for tool, count in workflow["retried_tools"].items():
                obs_lines.append(f"- `{tool}` was called {count} times (possible retry pattern)")
        obs_lines.append(f"- Model used: `{trace.model_used}`")
        observations = "\n".join(obs_lines)

        confidence = min(95, int(workflow["success_rate"] * 100))

        return cls.SKILL_TEMPLATE.format(
            name=name,
            description=f"Learned workflow for {', '.join(categories)} tasks",
            date=datetime.now().strftime("%Y-%m-%d"),
            task_id=trace.task_id,
            categories=", ".join(categories),
            confidence=confidence,
            uses=0,
            when_to_use=when_to_use,
            total_steps=len(workflow["critical_path"]),
            success_rate=f"{workflow['success_rate']:.0%}",
            critical_path_md=critical_path_md,
            tools_md=tools_md,
            error_recovery_md=error_recovery_md,
            observations=observations,
        )


# ═══════════════════════════════════════════════════════════════════
# Skill Matcher
# ═══════════════════════════════════════════════════════════════════

class SkillMatcher:
    """Matches incoming tasks to previously learned skills."""

    @classmethod
    def find_relevant_skills(cls, description: str, redis_client=None) -> List[Dict]:
        """Find learned skills relevant to a task description."""
        if not redis_client:
            return cls._find_from_filesystem(description)
        return cls._find_from_index(description, redis_client)

    @classmethod
    def _find_from_filesystem(cls, description: str) -> List[Dict]:
        """Fallback: scan .agent/skills/ for learned skills."""
        matches = []
        desc_lower = description.lower()
        desc_words = set(desc_lower.split())

        for skill_dir in SKILLS_DIR.iterdir():
            if not skill_dir.is_dir() or not skill_dir.name.startswith(LEARNED_PREFIX):
                continue
            skill_md = skill_dir / "SKILL.md"
            if not skill_md.exists():
                continue
            try:
                content = skill_md.read_text(encoding="utf-8")
                # Extract categories from frontmatter
                cat_match = re.search(r'categories:\s*\[([^\]]+)\]', content)
                categories = [c.strip() for c in cat_match.group(1).split(",")] if cat_match else []

                # Score relevance
                score = 0
                content_lower = content.lower()
                for word in desc_words:
                    if len(word) > 3 and word in content_lower:
                        score += 1
                for cat in categories:
                    cat_words = cat.replace("_", " ").split()
                    if any(w in desc_lower for w in cat_words):
                        score += 3

                if score > 2:
                    matches.append({
                        "skill_id": skill_dir.name,
                        "categories": categories,
                        "score": score,
                        "path": str(skill_md),
                    })
            except Exception:
                continue

        matches.sort(key=lambda m: -m["score"])
        return matches[:5]

    @classmethod
    def _find_from_index(cls, description: str, r) -> List[Dict]:
        """Use Redis index for fast skill matching."""
        desc_lower = description.lower()
        desc_words = set(desc_lower.split())

        raw_all = r.hgetall("kernell:learning:skills_index")
        if not raw_all:
            return cls._find_from_filesystem(description)

        matches = []
        for skill_id, raw in raw_all.items():
            try:
                meta = json.loads(raw)
                score = 0
                for word in desc_words:
                    if len(word) > 3:
                        if word in meta.get("description", "").lower():
                            score += 2
                        if any(word in cat for cat in meta.get("categories", [])):
                            score += 3
                        if any(word in t for t in meta.get("tools", [])):
                            score += 1
                if score > 2:
                    meta["score"] = score
                    matches.append(meta)
            except Exception:
                continue

        matches.sort(key=lambda m: -m.get("score", 0))
        return matches[:5]


# ═══════════════════════════════════════════════════════════════════
# Learning Loop Engine (Main Orchestrator)
# ═══════════════════════════════════════════════════════════════════

class LearningLoop:
    """
    The main Closed Learning Loop engine.

    Usage:
        loop = LearningLoop(redis_client)

        # After a complex task completes:
        trace = TaskTrace(
            task_id="task_123",
            description="Integrate DevLayer API endpoints",
            steps=[...],
            outcome="success",
        )
        result = loop.process_trace(trace)

        # Before starting a new task:
        skills = loop.find_skills("refactor authentication module")
    """

    def __init__(self, redis_client=None):
        self.redis = redis_client
        self.extractor = PatternExtractor()
        self.generator = SkillGenerator()
        self.matcher = SkillMatcher()

    def process_trace(self, trace: TaskTrace) -> Dict:
        """
        Process a completed task trace through the learning loop.

        Returns: {"learned": bool, "skill_id": str|None, "reason": str}
        """
        # Gate: only learn from complex, successful tasks
        if trace.step_count < MIN_STEPS_FOR_LEARNING:
            return {"learned": False, "skill_id": None, "reason": f"Too few steps ({trace.step_count} < {MIN_STEPS_FOR_LEARNING})"}

        if trace.outcome != "success":
            # Store trace for failure analysis but don't generate skill
            self._persist_trace(trace)
            return {"learned": False, "skill_id": None, "reason": f"Task outcome: {trace.outcome}"}

        if trace.success_rate < 0.6:
            self._persist_trace(trace)
            return {"learned": False, "skill_id": None, "reason": f"Low success rate: {trace.success_rate:.0%}"}

        # 1. Extract workflow pattern
        workflow = self.extractor.extract_workflow(trace)
        categories = workflow["categories"]

        # 2. Check if similar skill already exists
        skill_name = self.extractor.generate_skill_name(trace.description, categories)
        existing = self.matcher.find_relevant_skills(trace.description, self.redis)

        if existing and existing[0].get("score", 0) > 8:
            # Skill already exists with high confidence — refine instead of create
            self._refine_skill(existing[0], trace, workflow)
            self._persist_trace(trace)
            return {
                "learned": True,
                "skill_id": existing[0]["skill_id"],
                "reason": "Refined existing skill",
                "action": "refined",
            }

        # 3. Generate new skill
        skill_content = self.generator.generate(trace, workflow)

        # 4. Write to filesystem
        skill_dir = SKILLS_DIR / skill_name
        skill_dir.mkdir(parents=True, exist_ok=True)
        (skill_dir / "SKILL.md").write_text(skill_content, encoding="utf-8")

        # 5. Index in Redis
        self._index_skill(skill_name, trace, workflow)

        # 6. Persist trace
        self._persist_trace(trace)

        # 7. Update stats
        self._update_stats("skills_created")

        logger.info("🧠 LEARNING: Generated skill '%s' from task '%s' (%d steps)",
                     skill_name, trace.task_id, trace.step_count)

        return {
            "learned": True,
            "skill_id": skill_name,
            "reason": "New skill created",
            "action": "created",
            "categories": categories,
            "path": str(skill_dir / "SKILL.md"),
        }

    def find_skills(self, description: str) -> List[Dict]:
        """Find learned skills relevant to a new task."""
        return self.matcher.find_relevant_skills(description, self.redis)

    def get_stats(self) -> Dict:
        """Get learning loop statistics."""
        stats = {"skills_created": 0, "skills_refined": 0, "traces_processed": 0, "matches_found": 0}
        if self.redis:
            raw = self.redis.hgetall("kernell:learning:stats")
            for k, v in (raw or {}).items():
                key = k if isinstance(k, str) else k.decode()
                stats[key] = int(v if isinstance(v, str) else v.decode())

        # Count learned skills on filesystem
        learned_count = sum(1 for d in SKILLS_DIR.iterdir()
                           if d.is_dir() and d.name.startswith(LEARNED_PREFIX))
        stats["learned_skills_on_disk"] = learned_count
        return stats

    def list_learned_skills(self) -> List[Dict]:
        """List all auto-generated skills."""
        skills = []
        for skill_dir in sorted(SKILLS_DIR.iterdir()):
            if not skill_dir.is_dir() or not skill_dir.name.startswith(LEARNED_PREFIX):
                continue
            skill_md = skill_dir / "SKILL.md"
            if not skill_md.exists():
                continue
            try:
                content = skill_md.read_text(encoding="utf-8")
                meta = {}
                # Parse frontmatter
                fm_match = re.search(r'^---\n(.*?)\n---', content, re.DOTALL)
                if fm_match:
                    for line in fm_match.group(1).split("\n"):
                        if ": " in line:
                            k, v = line.split(": ", 1)
                            meta[k.strip()] = v.strip()
                meta["skill_id"] = skill_dir.name
                meta["path"] = str(skill_md)
                skills.append(meta)
            except Exception:
                continue
        return skills

    # ── Private ──────────────────────────────────────────────────

    def _refine_skill(self, existing_meta: Dict, trace: TaskTrace, workflow: Dict):
        """Refine an existing skill with new evidence."""
        skill_path = existing_meta.get("path")
        if not skill_path or not Path(skill_path).exists():
            return

        try:
            content = Path(skill_path).read_text(encoding="utf-8")

            # Increment uses
            content = re.sub(r'uses: (\d+)', lambda m: f'uses: {int(m.group(1)) + 1}', content)

            # Add refinement history entry
            date = datetime.now().strftime("%Y-%m-%d")
            new_row = f"| {date} | Refinement | Updated from task `{trace.task_id}` (success: {trace.success_rate:.0%}) |"
            content = content.rstrip() + "\n" + new_row + "\n"

            Path(skill_path).write_text(content, encoding="utf-8")
            self._update_stats("skills_refined")
            logger.info("🔄 LEARNING: Refined skill '%s'", existing_meta.get("skill_id"))
        except Exception as e:
            logger.warning("Failed to refine skill: %s", e)

    def _index_skill(self, skill_id: str, trace: TaskTrace, workflow: Dict):
        """Index a skill in Redis for fast matching."""
        if not self.redis:
            return
        meta = {
            "skill_id": skill_id,
            "description": trace.description,
            "categories": workflow["categories"],
            "tools": workflow["tools_sequence"],
            "success_rate": workflow["success_rate"],
            "created_at": time.time(),
            "path": str(SKILLS_DIR / skill_id / "SKILL.md"),
        }
        self.redis.hset("kernell:learning:skills_index", skill_id, json.dumps(meta))

    def _persist_trace(self, trace: TaskTrace):
        """Store trace for future analysis."""
        if not self.redis:
            return
        self.redis.lpush("kernell:learning:task_traces", json.dumps(trace.to_dict()))
        self.redis.ltrim("kernell:learning:task_traces", 0, MAX_TRACES - 1)
        self._update_stats("traces_processed")

    def _update_stats(self, key: str, delta: int = 1):
        """Increment a stats counter."""
        if self.redis:
            self.redis.hincrby("kernell:learning:stats", key, delta)


# ═══════════════════════════════════════════════════════════════════
# CLI Interface
# ═══════════════════════════════════════════════════════════════════

def main():
    """CLI for testing the learning loop."""
    import sys

    if len(sys.argv) < 2:
        print("Usage:")
        print("  python learning_loop.py stats       — Show learning stats")
        print("  python learning_loop.py list         — List learned skills")
        print("  python learning_loop.py match 'desc' — Find matching skills")
        print("  python learning_loop.py test         — Run test learning cycle")
        sys.exit(0)

    cmd = sys.argv[1]

    # Try to get Redis
    r = None
    try:
        from agents.core.config import get_redis_client
        r = get_redis_client()
        r.ping()
    except Exception:
        print("⚠️  Redis not available, using filesystem only")
        r = None

    loop = LearningLoop(r)

    if cmd == "stats":
        stats = loop.get_stats()
        print("📊 Learning Loop Stats:")
        for k, v in stats.items():
            print(f"   {k}: {v}")

    elif cmd == "list":
        skills = loop.list_learned_skills()
        print(f"🧠 Learned Skills ({len(skills)}):")
        for s in skills:
            print(f"   [{s.get('skill_id')}] {s.get('description', '—')}")

    elif cmd == "match" and len(sys.argv) > 2:
        desc = " ".join(sys.argv[2:])
        matches = loop.find_skills(desc)
        print(f"🔍 Matching skills for: '{desc}'")
        for m in matches:
            print(f"   [{m.get('skill_id')}] score={m.get('score', 0)} categories={m.get('categories', [])}")

    elif cmd == "test":
        print("🧪 Running test learning cycle...")
        trace = TaskTrace(
            task_id=f"test_{uuid.uuid4().hex[:8]}",
            description="Integrate DevLayer API endpoints with Redis backend and React frontend",
            steps=[
                {"tool": "view_file", "input": "Read api_server.py", "success": True, "output_summary": "Found router registration pattern"},
                {"tool": "view_file", "input": "Read marketplace_endpoint.py", "success": True, "output_summary": "Understood API contract"},
                {"tool": "write_to_file", "input": "Create devlayer_endpoint.py", "success": True, "output_summary": "New FastAPI router created"},
                {"tool": "multi_replace_file_content", "input": "Register router in api_server", "success": True, "output_summary": "Router wired"},
                {"tool": "write_to_file", "input": "Rewrite DevLayerPanel.jsx", "success": True, "output_summary": "Frontend consuming real API"},
                {"tool": "run_command", "input": "python -m py_compile", "success": True, "output_summary": "Backend compiles OK"},
                {"tool": "run_command", "input": "vite build", "success": True, "output_summary": "Frontend builds OK"},
            ],
            outcome="success",
            total_time_ms=45000,
            model_used="claude-opus-4",
            tags=["api", "frontend", "integration"],
        )
        result = loop.process_trace(trace)
        print(f"   Result: {json.dumps(result, indent=2)}")
    else:
        print(f"Unknown command: {cmd}")


if __name__ == "__main__":
    main()
