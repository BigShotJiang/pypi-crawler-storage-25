#!/usr/bin/env python3
"""
core/token_budget_guard.py
TokenBudgetGuard — controla el consumo de tokens por agente.
Previene loops sin throttling que disparan el gasto.

Uso:
    from core.token_budget_guard import TokenBudgetGuard

    guard = TokenBudgetGuard("overseer", hourly_limit=50_000, daily_limit=200_000)

    async def my_llm_call(prompt):
        if not guard.can_spend(estimated_tokens=2000):
            return "Budget exceeded — throttling"
        result = await actual_llm_call(prompt)
        guard.record(tokens_used=result.usage.total_tokens)
        return result
"""
import os, sys, json, time, logging
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
from dotenv import load_dotenv
load_dotenv()

import redis as redis_lib

logger = logging.getLogger("TokenBudgetGuard")

# Límites por defecto por agente (pueden sobreescribirse)
DEFAULT_LIMITS = {
    "overseer":       {"hourly": 80_000,  "daily": 400_000},
    "atlas":          {"hourly": 30_000,  "daily": 150_000},
    "sentinel":       {"hourly": 20_000,  "daily": 100_000},
    "sierra":         {"hourly": 15_000,  "daily": 80_000},
    "fixer":          {"hourly": 40_000,  "daily": 200_000},
    "forge":          {"hourly": 60_000,  "daily": 300_000},
    "nexus":          {"hourly": 10_000,  "daily": 50_000},
    "economy":        {"hourly": 20_000,  "daily": 100_000},
    "hunter":         {"hourly": 30_000,  "daily": 150_000},
    "nemesis":        {"hourly": 25_000,  "daily": 120_000},
    "chronos":        {"hourly": 5_000,   "daily": 25_000},
    "archivista":     {"hourly": 10_000,  "daily": 50_000},
    "herald":         {"hourly": 15_000,  "daily": 75_000},
    "telegram_bridge":{"hourly": 10_000,  "daily": 50_000},
    "observer":       {"hourly": 20_000,  "daily": 100_000},
    "vector":         {"hourly": 10_000,  "daily": 50_000},
    "scribe":         {"hourly": 8_000,   "daily": 40_000},
    "DEFAULT":        {"hourly": 20_000,  "daily": 100_000},
}


def _r():
    pw = os.getenv("REDIS_PASSWORD", "").strip().strip("\"'")
    return redis_lib.Redis(host="127.0.0.1", port=6379, password=pw or None,
                           decode_responses=True, socket_connect_timeout=3)


class TokenBudgetGuard:

    def __init__(self, agent_name: str,
                 hourly_limit: int = None,
                 daily_limit:  int = None):
        self.agent   = agent_name
        defaults     = DEFAULT_LIMITS.get(agent_name, DEFAULT_LIMITS["DEFAULT"])
        self.hourly  = hourly_limit or defaults["hourly"]
        self.daily   = daily_limit  or defaults["daily"]
        self._r      = None

        # Claves Redis
        self._k_hourly = f"kernell:token_budget:{agent_name}:hourly"
        self._k_daily  = f"kernell:token_budget:{agent_name}:daily"
        self._k_total  = f"kernell:agent:{agent_name}:tokens_used_total"
        self._k_alert  = f"kernell:token_budget:{agent_name}:last_alert"

    def _redis(self):
        if self._r is None:
            try:
                self._r = _r()
                self._r.ping()
            except Exception:
                self._r = None
        return self._r

    def _current_usage(self) -> dict:
        r = self._redis()
        if not r:
            return {"hourly": 0, "daily": 0}
        try:
            hourly = int(r.get(self._k_hourly) or 0)
            daily  = int(r.get(self._k_daily)  or 0)
            return {"hourly": hourly, "daily": daily}
        except Exception:
            return {"hourly": 0, "daily": 0}

    def can_spend(self, estimated_tokens: int = 1000) -> bool:
        """
        Retorna True si el agente puede gastar los tokens estimados.
        Si está cerca del límite, loggea una advertencia.
        """
        usage = self._current_usage()

        hourly_after = usage["hourly"] + estimated_tokens
        daily_after  = usage["daily"]  + estimated_tokens

        # Alerta si > 80%
        hourly_pct = hourly_after / self.hourly * 100
        daily_pct  = daily_after  / self.daily  * 100

        if hourly_pct > 80 or daily_pct > 80:
            self._send_alert(usage, hourly_pct, daily_pct)

        # Bloquear si excede límite
        if hourly_after > self.hourly:
            logger.warning(
                f"[{self.agent}] Budget HORARIO excedido: "
                f"{usage['hourly']:,}/{self.hourly:,} tokens"
            )
            return False

        if daily_after > self.daily:
            logger.warning(
                f"[{self.agent}] Budget DIARIO excedido: "
                f"{usage['daily']:,}/{self.daily:,} tokens"
            )
            return False

        return True

    def record(self, tokens_used: int, provider: str = "unknown", model: str = "unknown"):
        """Registra el consumo real después de una llamada."""
        r = self._redis()
        if not r:
            return

        try:
            pipe = r.pipeline()

            # Contadores con TTL automático
            pipe.incrby(self._k_hourly, tokens_used)
            pipe.expire(self._k_hourly, 3600)  # Reset cada hora

            pipe.incrby(self._k_daily, tokens_used)
            pipe.expire(self._k_daily, 86400)  # Reset cada día

            # Total acumulado (sin TTL)
            pipe.incrby(self._k_total, tokens_used)

            # Total por provider
            pipe.hincrby("kernell:token_totals:by_provider", provider, tokens_used)

            pipe.execute()

            # Ledger de eventos
            event = json.dumps({
                "agent":       self.agent,
                "provider":    provider,
                "model":       model,
                "tokens_used": tokens_used,
                "timestamp":   time.time(),
                "success":     True,
            })
            r.lpush("kernell:token_ledger", event)
            r.ltrim("kernell:token_ledger", 0, 499)

        except Exception as e:
            logger.error(f"Error registrando tokens: {e}")

    def record_error(self, provider: str = "unknown", error: str = ""):
        """Registra un fallo de llamada LLM."""
        r = self._redis()
        if not r:
            return
        try:
            event = json.dumps({
                "agent":    self.agent,
                "provider": provider,
                "success":  False,
                "error":    str(error)[:100],
                "timestamp": time.time(),
            })
            r.lpush("kernell:token_ledger", event)
            r.ltrim("kernell:token_ledger", 0, 499)
        except Exception:
            pass

    def get_status(self) -> dict:
        usage = self._current_usage()
        return {
            "agent":        self.agent,
            "hourly":       {"used": usage["hourly"], "limit": self.hourly,
                             "pct": round(usage["hourly"] / self.hourly * 100, 1)},
            "daily":        {"used": usage["daily"],  "limit": self.daily,
                             "pct": round(usage["daily"]  / self.daily  * 100, 1)},
            "total_ever":   int(self._redis().get(self._k_total) or 0)
                            if self._redis() else 0,
            "throttled":    usage["hourly"] >= self.hourly or
                            usage["daily"]  >= self.daily,
        }

    def reset_hourly(self):
        """Resetea el contador horario (para tests o admin manual)."""
        r = self._redis()
        if r:
            r.delete(self._k_hourly)

    def _send_alert(self, usage: dict, hourly_pct: float, daily_pct: float):
        """Envía alerta a Sierra si no se envió en las últimas 10 min."""
        r = self._redis()
        if not r:
            return
        last_alert = r.get(self._k_alert)
        if last_alert and (time.time() - float(last_alert)) < 600:
            return
        try:
            r.set(self._k_alert, str(time.time()), ex=600)
            alert = json.dumps({
                "type":       "token_budget_warning",
                "agent":      self.agent,
                "hourly_pct": round(hourly_pct, 1),
                "daily_pct":  round(daily_pct, 1),
                "usage":      usage,
                "limits":     {"hourly": self.hourly, "daily": self.daily},
                "ts":         time.time(),
            })
            r.lpush("kernell:tasks:sierra",  alert)
            r.publish("kernell:system:alerts", alert)
        except Exception:
            pass


# ─── CLI: mostrar status de todos los agentes ─────────────────────────────────
if __name__ == "__main__":
    r = _r()
    print(f"\n  {'AGENTE':<20} {'HOURLY':<20} {'DAILY':<20} {'THROTTLED'}")
    print(f"  {'─'*75}")
    all_keys = r.keys("kernell:token_budget:*:hourly") or []
    agents_found = set()
    for k in all_keys:
        agent = k.split(":")[2]
        agents_found.add(agent)
    for agent in sorted(agents_found | set(DEFAULT_LIMITS.keys()) - {"DEFAULT"}):
        guard  = TokenBudgetGuard(agent)
        status = guard.get_status()
        h = status["hourly"]
        d = status["daily"]
        icon = "🔴" if status["throttled"] else "🟡" if h["pct"] > 70 else "🟢"
        print(f"  {icon} {agent:<18} "
              f"{h['used']:>6,}/{h['limit']:<7,} ({h['pct']:>5.1f}%)  "
              f"{d['used']:>7,}/{d['limit']:<8,} ({d['pct']:>5.1f}%)  "
              f"{'🔴 SÍ' if status['throttled'] else 'no'}")
    print()
