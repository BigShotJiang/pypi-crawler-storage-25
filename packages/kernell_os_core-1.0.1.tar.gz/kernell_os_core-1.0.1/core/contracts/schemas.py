from typing import Any, Dict, List

try:
    from pydantic import BaseModel, Field, ValidationError
    HAS_PYDANTIC = True
except Exception:  # pragma: no cover - fallback when pydantic is unavailable
    HAS_PYDANTIC = False

    class ValidationError(Exception):
        pass

    class BaseModel:
        @classmethod
        def model_validate(cls, data):
            required = getattr(cls, "__required_fields__", [])
            missing = [f for f in required if f not in data]
            if missing:
                raise ValidationError(f"Missing fields: {missing}")
            return data


if HAS_PYDANTIC:
    class ProductListingPayload(BaseModel):
        optimized_title: str = Field(min_length=1)
        seo_description: str = ""
        retail_price_usd: str = "0.0"
        image_urls: List[str] = Field(default_factory=list)
        product_url: str | None = None


    class AdCreativePayload(BaseModel):
        campaign_id: str
        video_path: str
        caption: str
        link_url: str


    class BountyFindingPayload(BaseModel):
        matched_at: str
        severity: str
        name: str


    class TradingTelemetryPayload(BaseModel):
        symbol: str
        timeframe: str
        action_taken: str
        result_pips: float
else:
    class ProductListingPayload(BaseModel):
        __required_fields__ = ["optimized_title"]


    class AdCreativePayload(BaseModel):
        __required_fields__ = ["campaign_id", "video_path", "caption", "link_url"]


    class BountyFindingPayload(BaseModel):
        __required_fields__ = ["matched_at", "severity", "name"]


    class TradingTelemetryPayload(BaseModel):
        __required_fields__ = ["symbol", "timeframe", "action_taken", "result_pips"]


def validate_product_listing_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
    model = ProductListingPayload.model_validate(payload)
    if hasattr(model, "model_dump"):
        return model.model_dump()
    return dict(model)

