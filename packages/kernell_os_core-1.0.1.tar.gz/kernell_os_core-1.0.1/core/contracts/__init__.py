"""Contracts package for cross-agent payload validation."""

