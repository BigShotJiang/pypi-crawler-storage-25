#!/usr/bin/env python3
"""
OVV — Optimal Version Verifier: Data Models
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
from datetime import datetime, timezone


@dataclass
class HealthCheck:
    """Single health check definition."""
    type: str          # redis_key_exists | queue_draining | endpoint_reachable | process_running
    target: str        # key name, queue name, URL, or process name
    expected: Any = True
    max_depth: int = 5  # for queue_draining type


@dataclass
class ModuleBaseline:
    """Optimal baseline state for a module."""
    module_id: str
    version: str
    last_verified: str
    config_file: Optional[str] = None
    config_hash: Optional[str] = None
    health_checks: List[Dict] = field(default_factory=list)
    expected_state: Dict[str, Any] = field(default_factory=dict)
    description: str = ""


@dataclass
class VerificationResult:
    """Result of verifying a module against its baseline."""
    module_id: str
    baseline_version: str
    status: str              # OK | DEGRADED | BROKEN
    checks_passed: int = 0
    checks_failed: int = 0
    checks_total: int = 0
    failures: List[Dict] = field(default_factory=list)
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def to_dict(self) -> dict:
        return {
            "module_id": self.module_id,
            "baseline_version": self.baseline_version,
            "status": self.status,
            "checks_passed": self.checks_passed,
            "checks_failed": self.checks_failed,
            "checks_total": self.checks_total,
            "failures": self.failures,
            "timestamp": self.timestamp,
        }


@dataclass
class AnomalyReport:
    """Report for a detected module anomaly."""
    module_id: str
    anomaly_type: str        # config_drift | health_failure | broken_endpoint | stale_queue
    severity: str            # low | medium | high | critical
    details: str
    recommended_action: str
    escalation_level: int = 1  # 1=self, 2=fixer, 3=forge, 4=audit
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def to_dict(self) -> dict:
        return {
            "module_id": self.module_id,
            "anomaly_type": self.anomaly_type,
            "severity": self.severity,
            "details": self.details,
            "recommended_action": self.recommended_action,
            "escalation_level": self.escalation_level,
            "timestamp": self.timestamp,
        }
