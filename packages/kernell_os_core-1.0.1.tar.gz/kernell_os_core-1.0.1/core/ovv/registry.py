#!/usr/bin/env python3
"""
OVV — Optimal Version Verifier: Baseline Registry
==================================================
Manages optimal baseline YAML files per module.
Provides snapshot, compare, and persistence operations.
"""

import hashlib
import json
import logging
from pathlib import Path
from typing import Dict, List, Optional, Any

import yaml

from core.ovv.schema import ModuleBaseline, VerificationResult

logger = logging.getLogger("OVV_REGISTRY")

BASELINES_DIR = Path(__file__).parent / "baselines"
ROOT_PATH = Path(__file__).parent.parent.parent


class BaselineRegistry:
    """Manages optimal baselines for all modules."""

    def __init__(self):
        BASELINES_DIR.mkdir(parents=True, exist_ok=True)

    def list_modules(self) -> List[str]:
        """List all modules with registered baselines."""
        modules = []
        for f in sorted(BASELINES_DIR.glob("*.yaml")):
            modules.append(f.stem)
        return modules

    def load_baseline(self, module_id: str) -> Optional[ModuleBaseline]:
        """Load a module's baseline from YAML."""
        path = BASELINES_DIR / f"{module_id}.yaml"
        if not path.exists():
            return None
        try:
            data = yaml.safe_load(path.read_text())
            return ModuleBaseline(
                module_id=data.get("module_id", module_id),
                version=data.get("version", "1.0"),
                last_verified=data.get("last_verified", ""),
                config_file=data.get("config", {}).get("config_file"),
                config_hash=data.get("config", {}).get("config_hash"),
                health_checks=data.get("health_checks", []),
                expected_state=data.get("expected_state", {}),
                description=data.get("description", ""),
            )
        except Exception as e:
            logger.error(f"Failed to load baseline {module_id}: {e}")
            return None

    def save_baseline(self, module_id: str, baseline: ModuleBaseline) -> None:
        """Save a baseline to YAML."""
        path = BASELINES_DIR / f"{module_id}.yaml"
        data = {
            "module_id": baseline.module_id,
            "version": baseline.version,
            "last_verified": baseline.last_verified,
            "description": baseline.description,
            "config": {
                "config_file": baseline.config_file,
                "config_hash": baseline.config_hash,
            },
            "health_checks": baseline.health_checks,
            "expected_state": baseline.expected_state,
        }
        path.write_text(yaml.dump(data, default_flow_style=False, sort_keys=False))
        logger.info(f"✅ Baseline saved: {module_id} v{baseline.version}")

    def compute_config_hash(self, config_file: str) -> Optional[str]:
        """Compute SHA256 hash of a config file."""
        path = ROOT_PATH / config_file
        if not path.exists():
            return None
        content = path.read_bytes()
        return f"sha256:{hashlib.sha256(content).hexdigest()[:16]}"

    def snapshot_current(self, module_id: str, redis_client=None) -> Dict[str, Any]:
        """Capture live state for a module."""
        baseline = self.load_baseline(module_id)
        if not baseline:
            return {"module_id": module_id, "error": "no_baseline"}

        snapshot = {
            "module_id": module_id,
            "config_hash": None,
            "health_results": [],
        }

        # Config hash
        if baseline.config_file:
            snapshot["config_hash"] = self.compute_config_hash(baseline.config_file)

        # Health checks
        for check in baseline.health_checks:
            result = self._run_health_check(check, redis_client)
            snapshot["health_results"].append(result)

        return snapshot

    def compare(self, baseline: ModuleBaseline, snapshot: Dict) -> VerificationResult:
        """Compare baseline vs current snapshot."""
        failures = []
        passed = 0
        total = 0

        # Config hash check
        if baseline.config_hash and snapshot.get("config_hash"):
            total += 1
            if baseline.config_hash == snapshot["config_hash"]:
                passed += 1
            else:
                failures.append({
                    "check": "config_hash",
                    "expected": baseline.config_hash,
                    "actual": snapshot["config_hash"],
                    "type": "config_drift",
                })

        # Health checks
        for hr in snapshot.get("health_results", []):
            total += 1
            if hr.get("passed"):
                passed += 1
            else:
                failures.append({
                    "check": hr.get("type", "unknown"),
                    "target": hr.get("target", ""),
                    "expected": hr.get("expected"),
                    "actual": hr.get("actual"),
                    "type": hr.get("failure_type", "health_failure"),
                })

        failed = total - passed
        if failed == 0:
            status = "OK"
        elif failed <= total // 2:
            status = "DEGRADED"
        else:
            status = "BROKEN"

        return VerificationResult(
            module_id=baseline.module_id,
            baseline_version=baseline.version,
            status=status,
            checks_passed=passed,
            checks_failed=failed,
            checks_total=total,
            failures=failures,
        )

    def _run_health_check(self, check: Dict, redis_client=None) -> Dict:
        """Execute a single health check and return result."""
        check_type = check.get("type", "")
        target = check.get("target", check.get("key", check.get("queue", check.get("url", ""))))
        result = {"type": check_type, "target": target, "passed": False}

        try:
            if check_type == "redis_key_exists" and redis_client:
                val = redis_client.get(target)
                result["passed"] = val is not None
                result["actual"] = "exists" if val else "missing"
                result["expected"] = "exists"

            elif check_type == "queue_draining" and redis_client:
                depth = redis_client.llen(target)
                max_depth = check.get("max_depth", 5)
                result["passed"] = depth <= max_depth
                result["actual"] = depth
                result["expected"] = f"<= {max_depth}"
                if not result["passed"]:
                    result["failure_type"] = "stale_queue"

            elif check_type == "endpoint_reachable":
                import urllib.request
                expected_status = check.get("expected_status", 200)
                try:
                    resp = urllib.request.urlopen(target, timeout=5)
                    result["passed"] = resp.getcode() == expected_status
                    result["actual"] = resp.getcode()
                    result["expected"] = expected_status
                except Exception as e:
                    result["actual"] = str(e)[:80]
                    result["expected"] = expected_status
                    result["failure_type"] = "broken_endpoint"

            elif check_type == "process_running":
                import subprocess as sp
                r = sp.run(["pgrep", "-f", target], capture_output=True)
                result["passed"] = r.returncode == 0
                result["actual"] = "running" if r.returncode == 0 else "not_found"
                result["expected"] = "running"

            elif check_type == "file_exists":
                path = ROOT_PATH / target
                result["passed"] = path.exists()
                result["actual"] = "exists" if path.exists() else "missing"
                result["expected"] = "exists"

            else:
                result["actual"] = "unsupported_check_type"
                result["expected"] = check_type

        except Exception as e:
            result["actual"] = f"error: {str(e)[:60]}"

        return result
