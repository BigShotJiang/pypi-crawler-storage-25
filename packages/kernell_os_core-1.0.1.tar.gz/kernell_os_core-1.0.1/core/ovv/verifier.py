#!/usr/bin/env python3
"""
OVV — Optimal Version Verifier: Module Verifier
================================================
Per-module health verifier with escalation chain:
  Level 1: Self-correct (re-apply config, restart)
  Level 2: Fixer (auto-repair pipeline)
  Level 3: Forge (engineering request for code fix)
  Level 4: Audit (log for Architect review)
"""

import json
import logging
from datetime import datetime, timezone
from typing import Dict, List, Optional

from core.ovv.schema import VerificationResult, AnomalyReport
from core.ovv.registry import BaselineRegistry

logger = logging.getLogger("OVV_VERIFIER")


class ModuleVerifier:
    """
    Per-module health verifier with escalation chain.
    
    Compares current module state against its documented optimal baseline.
    Escalates anomalies through: Self → Fixer → Forge → Audit.
    """

    def __init__(self, redis_client=None):
        self.redis = redis_client
        self.registry = BaselineRegistry()

    def verify_module(self, module_id: str) -> VerificationResult:
        """
        Verify a single module against its baseline.
        
        1. Load baseline from registry
        2. Snapshot current state
        3. Compare and generate result
        4. Escalate if DEGRADED or BROKEN
        """
        baseline = self.registry.load_baseline(module_id)
        if not baseline:
            return VerificationResult(
                module_id=module_id,
                baseline_version="N/A",
                status="NO_BASELINE",
            )

        # Snapshot current state
        snapshot = self.registry.snapshot_current(module_id, self.redis)

        # Compare
        result = self.registry.compare(baseline, snapshot)

        # Escalate if needed
        if result.status in ("DEGRADED", "BROKEN"):
            self._escalate(result)

        # Publish to Redis
        self._publish_result(result)

        return result

    def verify_all(self) -> List[VerificationResult]:
        """Verify all registered modules."""
        modules = self.registry.list_modules()
        results = []
        for mid in modules:
            try:
                r = self.verify_module(mid)
                results.append(r)
            except Exception as e:
                logger.error(f"Verification failed for {mid}: {e}")
                results.append(VerificationResult(
                    module_id=mid,
                    baseline_version="N/A",
                    status="ERROR",
                    failures=[{"check": "verification", "actual": str(e)[:100]}],
                ))
        return results

    def on_config_change(self, module_id: str, change_description: str = "") -> VerificationResult:
        """
        Called after a config change. Re-verifies module and escalates if regression.
        """
        logger.info(f"🔄 Config change detected for {module_id}: {change_description[:60]}")
        result = self.verify_module(module_id)

        if result.status != "OK":
            anomaly = AnomalyReport(
                module_id=module_id,
                anomaly_type="config_drift",
                severity="high" if result.status == "BROKEN" else "medium",
                details=f"Config change caused regression: {change_description}. "
                        f"Failures: {json.dumps(result.failures[:3])}",
                recommended_action="Revert config change or fix affected checks",
                escalation_level=3 if result.status == "BROKEN" else 2,
            )
            self._publish_anomaly(anomaly)

        return result

    def get_all_results(self) -> Dict:
        """Get cached verification results from Redis (for Dashboard)."""
        try:
            raw = self.redis.get("kernell:ovv:verification:latest") if self.redis else None
            if raw:
                return json.loads(raw)
        except Exception:
            pass
        return {"modules": [], "timestamp": None}

    # ─── Escalation Chain ─────────────────────────────

    def _escalate(self, result: VerificationResult):
        """Escalate based on failure severity."""
        if not self.redis:
            return

        if result.status == "DEGRADED":
            # Level 2: Notify Fixer
            error_payload = {
                "type": "ovv_degraded",
                "source": "ovv_verifier",
                "module": result.module_id,
                "failures": result.failures[:5],
                "message": f"Module {result.module_id} DEGRADED: "
                          f"{result.checks_failed}/{result.checks_total} checks failed",
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
            self.redis.lpush("kernell:errors:system", json.dumps(error_payload))
            logger.warning(f"⚠️ Escalated {result.module_id} (DEGRADED) → Fixer")

        elif result.status == "BROKEN":
            # Level 2+3: Notify Fixer AND Forge
            error_payload = {
                "type": "ovv_broken",
                "source": "ovv_verifier",
                "module": result.module_id,
                "failures": result.failures[:5],
                "message": f"Module {result.module_id} BROKEN: "
                          f"{result.checks_failed}/{result.checks_total} checks failed",
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
            self.redis.lpush("kernell:errors:system", json.dumps(error_payload))

            # Forge engineering request
            forge_request = {
                "type": "engineering_request",
                "problem": f"OVV: Module {result.module_id} is BROKEN",
                "impact": f"{result.checks_failed} health checks failing",
                "affected_modules": [result.module_id],
                "logs": json.dumps(result.failures[:3]),
                "severity": "high",
                "source": "ovv_verifier",
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
            self.redis.lpush("kernell:tasks:forge:engineering_request",
                           json.dumps(forge_request))
            logger.critical(f"🚨 Escalated {result.module_id} (BROKEN) → Fixer + Forge")

            # Level 4: Audit log
            audit_entry = {
                "type": "ovv_audit",
                "module": result.module_id,
                "status": result.status,
                "failures": result.failures,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
            self.redis.lpush("kernell:ovv:audit", json.dumps(audit_entry))
            self.redis.ltrim("kernell:ovv:audit", 0, 199)

    # ─── Redis Publishing ─────────────────────────────

    def _publish_result(self, result: VerificationResult):
        """Publish verification result to Redis."""
        if not self.redis:
            return
        try:
            # Per-module result
            self.redis.hset(
                "kernell:ovv:modules",
                result.module_id,
                json.dumps(result.to_dict()),
            )

            # Aggregate latest
            all_modules = self.redis.hgetall("kernell:ovv:modules") or {}
            summary = {
                "modules": [],
                "total": len(all_modules),
                "ok": 0,
                "degraded": 0,
                "broken": 0,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
            for mid, raw in all_modules.items():
                try:
                    m = json.loads(raw)
                    summary["modules"].append(m)
                    s = m.get("status", "")
                    if s == "OK":
                        summary["ok"] += 1
                    elif s == "DEGRADED":
                        summary["degraded"] += 1
                    elif s == "BROKEN":
                        summary["broken"] += 1
                except Exception:
                    pass

            self.redis.set(
                "kernell:ovv:verification:latest",
                json.dumps(summary),
                ex=3600,
            )
        except Exception as e:
            logger.error(f"Failed to publish OVV result: {e}")

    def _publish_anomaly(self, anomaly: AnomalyReport):
        """Publish anomaly report to Redis."""
        if not self.redis:
            return
        try:
            self.redis.lpush("kernell:ovv:anomalies", json.dumps(anomaly.to_dict()))
            self.redis.ltrim("kernell:ovv:anomalies", 0, 199)
        except Exception as e:
            logger.error(f"Failed to publish anomaly: {e}")
