#!/usr/bin/env python3
"""
🔧 KERNELL OS — TOOL ROOM v1.0
==========================================
Centralized Tool Access Registry with ACL Enforcement.

All system tools (MCP servers, API keys, SSH tunnels, browsers,
databases, crypto exchanges, system commands) are registered here
with per-agent Access Control Lists.

Integration:
  - Agents call ToolRoom.check_access() before using ANY tool
  - Violations logged to disk + Telegram alert
  - Dashboard section shows who used what and when
  - Works with CircuitBreaker: repeated violations trip the circuit

Architecture:
  Levels: FULL > DEPLOY > TRADE > READ_WRITE > ROTATE > WRITE_OWN_KEYS
          > READ > SCAN > STATUS_ONLY > MONITOR > SCRAPE_READONLY > NONE

Blueprint XIV — Sovereign Architecture
"""

import os
import sys
import json
import time
import logging
import hashlib
from pathlib import Path
from datetime import datetime, timezone
from typing import Dict, List, Optional, Set
from dataclasses import dataclass, field, asdict

# Add root to path
ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT))

logger = logging.getLogger("TOOL_ROOM")

# ── Directories ──────────────────────────────────────────────────────────────
AUDIT_LOG_DIR = Path("/data/tool_room_audit")
AUDIT_LOG_DIR.mkdir(parents=True, exist_ok=True)


# ── Privilege Hierarchy ──────────────────────────────────────────────────────

PRIVILEGE_LEVELS = {
    "FULL": 100,
    "DEPLOY": 90,
    "DEPLOY_STAGING": 85,
    "TRADE": 80,
    "TRADE_ONLY": 75,
    "READ_WRITE": 70,
    "ROTATE": 65,
    "WRITE_OWN_KEYS": 60,
    "RESTART": 55,
    "SOCIAL_POST": 50,
    "READ": 40,
    "SCAN": 35,
    "SCRAPE_READONLY": 30,
    "STATUS_ONLY": 20,
    "MONITOR": 15,
    "NONE": 0,
}


# ── Tool Registry ───────────────────────────────────────────────────────────

DEFAULT_TOOL_REGISTRY = {
    "mcp_servers": {
        "description": "MCP protocol servers for external tool access",
        "tools": ["filesystem", "brave_search", "github", "slack"],
        "acl": {
            "kernell": "FULL",
            "forge": "READ_WRITE",
            "hunter": "READ",
            "herald": "READ",
            "atlas": "READ",
        },
        "require_multisign": False,
    },
    "api_keys": {
        "description": "LLM and service API keys managed by Nexus",
        "tools": ["gemini", "groq", "openai", "anthropic", "rapidapi", "binance"],
        "acl": {
            "nexus": "ROTATE",
            "atlas": "READ",
            "economy": "TRADE_ONLY",
            "forge": "READ",
            "hunter": "READ",
        },
        "require_multisign": True,  # Rotating API keys is sensitive
    },
    "ssh_tunnels": {
        "description": "Remote server access via SSH/Tailscale",
        "tools": ["oracle_staging", "nebula_nodes", "tailscale_mesh"],
        "acl": {
            "sentinel": "SCAN",
            "fixer": "RESTART",
            "forge": "DEPLOY_STAGING",
        },
        "require_multisign": True,  # SSH is high-risk
    },
    "browsers": {
        "description": "Browser automation for web interaction",
        "tools": ["playwright_chromium", "puppeteer"],
        "acl": {
            "herald": "SOCIAL_POST",
            "hunter": "SCRAPE_READONLY",
        },
        "require_multisign": False,
    },
    "databases": {
        "description": "Data storage systems",
        "tools": ["redis", "qdrant", "sqlite"],
        "acl": {
            "atlas": "FULL",
            "overseer": "READ",
            "economy": "WRITE_OWN_KEYS",
            "forge": "READ_WRITE",
            "fixer": "READ_WRITE",
            "chronos": "READ",
        },
        "require_multisign": False,
    },
    "crypto": {
        "description": "Cryptocurrency exchange access",
        "tools": ["binance_spot", "binance_futures", "ccxt"],
        "acl": {
            "economy": "TRADE",
            "sentinel": "MONITOR",
        },
        "require_multisign": True,  # Financial operations
    },
    "system": {
        "description": "OS-level commands and services",
        "tools": ["systemctl", "docker", "git", "sudo"],
        "acl": {
            "forge": "DEPLOY",
            "fixer": "RESTART",
            "sentinel": "STATUS_ONLY",
            "chronos": "STATUS_ONLY",
        },
        "require_multisign": True,  # System commands need governance
    },
}


# ── Data Models ──────────────────────────────────────────────────────────────

@dataclass
class AccessRequest:
    """A request from an agent to use a tool."""
    agent_id: str
    tool_category: str
    tool_name: str
    operation: str         # What the agent wants to do
    timestamp: str = ""

    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = datetime.now(timezone.utc).isoformat()


@dataclass
class AccessDecision:
    """Result of an access check."""
    allowed: bool
    agent_id: str
    tool_category: str
    tool_name: str
    granted_level: str
    required_level: str = ""
    requires_multisign: bool = False
    reason: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


# ── Tool Room ────────────────────────────────────────────────────────────────

class ToolRoom:
    """
    Centralized Tool Access Registry with ACL Enforcement.
    
    Usage:
        tool_room = ToolRoom(redis_client=redis)
        decision = tool_room.check_access("hunter", "browsers", "playwright_chromium")
        if decision.allowed:
            # proceed with tool usage
        else:
            logger.warning(f"Access denied: {decision.reason}")
    """

    REDIS_PREFIX = "kernell:tool_room:"

    def __init__(self, redis_client=None, custom_registry: Dict = None):
        self._redis = redis_client
        self._registry = custom_registry or self._load_registry()
        self._access_log: List[Dict] = []
        self._violation_count: Dict[str, int] = {}  # Per-agent violations
        
        logger.info(f"🔧 Tool Room v1.0 initialized ({len(self._registry)} categories)")

    def _load_registry(self) -> Dict:
        """Load registry from Redis (if overridden) or use defaults."""
        try:
            if self._redis:
                raw = self._redis.get(f"{self.REDIS_PREFIX}registry")
                if raw:
                    return json.loads(raw)
        except Exception:
            pass
        return DEFAULT_TOOL_REGISTRY

    # ── Core Access Control ──────────────────────────────────────────────────

    def check_access(
        self,
        agent_id: str,
        tool_category: str,
        tool_name: str = "",
        required_level: str = "",
    ) -> AccessDecision:
        """
        Check if an agent has permission to use a specific tool.
        
        Args:
            agent_id: The requesting agent (e.g., "forge", "hunter")
            tool_category: Category in the registry (e.g., "browsers", "system")
            tool_name: Specific tool (e.g., "playwright_chromium"). Optional.
            required_level: Minimum level needed. If empty, returns the agent's level.
        
        Returns:
            AccessDecision with allowed=True/False
        """
        # Category exists?
        category = self._registry.get(tool_category)
        if not category:
            decision = AccessDecision(
                allowed=False,
                agent_id=agent_id,
                tool_category=tool_category,
                tool_name=tool_name,
                granted_level="NONE",
                reason=f"Unknown tool category: {tool_category}",
            )
            self._log_access(decision)
            return decision

        # Tool exists in category?
        if tool_name and tool_name not in category.get("tools", []):
            decision = AccessDecision(
                allowed=False,
                agent_id=agent_id,
                tool_category=tool_category,
                tool_name=tool_name,
                granted_level="NONE",
                reason=f"Tool '{tool_name}' not in category '{tool_category}'",
            )
            self._log_access(decision)
            return decision

        # Agent has any access?
        acl = category.get("acl", {})
        agent_level = acl.get(agent_id, "NONE")
        agent_power = PRIVILEGE_LEVELS.get(agent_level, 0)

        # Check against required level
        if required_level:
            required_power = PRIVILEGE_LEVELS.get(required_level, 0)
            allowed = agent_power >= required_power
        else:
            allowed = agent_power > 0

        # Does this category require MultiSign?
        requires_multisign = category.get("require_multisign", False)

        decision = AccessDecision(
            allowed=allowed,
            agent_id=agent_id,
            tool_category=tool_category,
            tool_name=tool_name,
            granted_level=agent_level,
            required_level=required_level,
            requires_multisign=requires_multisign,
            reason="" if allowed else f"Insufficient privilege: {agent_level} (power={agent_power}) < {required_level} (power={PRIVILEGE_LEVELS.get(required_level, 0)})",
        )

        self._log_access(decision)

        if not allowed:
            self._record_violation(agent_id, tool_category, tool_name)

        return decision

    def get_agent_tools(self, agent_id: str) -> Dict[str, str]:
        """Return all tools available to an agent with their access levels."""
        tools = {}
        for cat_name, category in self._registry.items():
            acl = category.get("acl", {})
            level = acl.get(agent_id, "NONE")
            if level != "NONE":
                for tool in category.get("tools", []):
                    tools[f"{cat_name}:{tool}"] = level
        return tools

    def get_tool_users(self, tool_category: str) -> Dict[str, str]:
        """Return all agents that have access to a tool category."""
        category = self._registry.get(tool_category, {})
        return category.get("acl", {})

    # ── ACL Management ───────────────────────────────────────────────────────

    def grant_access(
        self,
        agent_id: str,
        tool_category: str,
        level: str,
        granted_by: str = "architect",
    ) -> bool:
        """Grant or update an agent's access level for a tool category."""
        if tool_category not in self._registry:
            return False
        if level not in PRIVILEGE_LEVELS:
            return False

        self._registry[tool_category]["acl"][agent_id] = level
        self._save_registry()

        self._log_event("access_granted", {
            "agent_id": agent_id,
            "category": tool_category,
            "level": level,
            "granted_by": granted_by,
        })

        logger.info(f"🔓 Granted {agent_id} → {tool_category}: {level} (by {granted_by})")
        return True

    def revoke_access(
        self,
        agent_id: str,
        tool_category: str,
        revoked_by: str = "architect",
    ) -> bool:
        """Revoke an agent's access to a tool category."""
        if tool_category not in self._registry:
            return False

        acl = self._registry[tool_category].get("acl", {})
        if agent_id in acl:
            del acl[agent_id]
            self._save_registry()

            self._log_event("access_revoked", {
                "agent_id": agent_id,
                "category": tool_category,
                "revoked_by": revoked_by,
            })

            logger.warning(f"🔒 Revoked {agent_id} → {tool_category} (by {revoked_by})")
            return True
        return False

    # ── Internal ─────────────────────────────────────────────────────────────

    def _save_registry(self):
        """Persist registry to Redis."""
        try:
            if self._redis:
                self._redis.set(
                    f"{self.REDIS_PREFIX}registry",
                    json.dumps(self._registry),
                )
        except Exception as e:
            logger.error(f"Failed to save registry: {e}")

    def _log_access(self, decision: AccessDecision):
        """Log access check to Redis and disk."""
        event = {
            "type": "access_check",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "decision": decision.to_dict(),
        }
        
        # Memory buffer
        self._access_log.append(event)
        if len(self._access_log) > 500:
            self._access_log = self._access_log[-200:]
        
        # Redis
        try:
            if self._redis:
                self._redis.lpush(f"{self.REDIS_PREFIX}access_log", json.dumps(event))
                self._redis.ltrim(f"{self.REDIS_PREFIX}access_log", 0, 999)
        except Exception:
            pass

    def _record_violation(self, agent_id: str, category: str, tool_name: str):
        """
        Track access violations. If an agent accumulates 5+ violations,
        trip the Circuit Breaker for that agent.
        """
        key = f"{agent_id}:{category}"
        self._violation_count[key] = self._violation_count.get(key, 0) + 1
        count = self._violation_count[key]

        self._log_event("access_violation", {
            "agent_id": agent_id,
            "category": category,
            "tool_name": tool_name,
            "violation_count": count,
        })

        logger.warning(
            f"🚨 VIOLATION: {agent_id} tried to access {category}:{tool_name} "
            f"({count} violations)"
        )

        # Escalate after 5 violations
        if count >= 5:
            try:
                if self._redis:
                    alert = {
                        "type": "tool_room_violation_escalation",
                        "agent_id": agent_id,
                        "category": category,
                        "violations": count,
                        "action": "circuit_breaker_triggered",
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                    }
                    self._redis.publish("kernell:alerts:security", json.dumps(alert))
                    logger.critical(
                        f"🔴 ESCALATION: {agent_id} has {count} violations → "
                        "Circuit Breaker + Telegram alert triggered"
                    )
            except Exception:
                pass

    def _log_event(self, event_type: str, data: Dict):
        """Append-only audit log to disk."""
        event = {
            "type": event_type,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "data": data,
        }
        try:
            log_file = AUDIT_LOG_DIR / f"tool_room_{datetime.now(timezone.utc).strftime('%Y%m')}.jsonl"
            with open(log_file, "a", encoding="utf-8") as f:
                f.write(json.dumps(event) + "\n")
        except Exception as e:
            logger.error(f"Audit log write failed: {e}")

    # ── Status & Reporting ───────────────────────────────────────────────────

    def get_status(self) -> Dict:
        """Return Tool Room status for Dashboard."""
        categories = {}
        for cat_name, category in self._registry.items():
            categories[cat_name] = {
                "tools": len(category.get("tools", [])),
                "agents_with_access": len(category.get("acl", {})),
                "requires_multisign": category.get("require_multisign", False),
            }

        return {
            "categories": len(self._registry),
            "total_tools": sum(len(c.get("tools", [])) for c in self._registry.values()),
            "total_acl_entries": sum(len(c.get("acl", {})) for c in self._registry.values()),
            "violations": dict(self._violation_count),
            "breakdown": categories,
        }

    def get_acl_matrix(self) -> Dict[str, Dict[str, str]]:
        """
        Return the full ACL matrix for dashboard visualization.
        Returns: {agent_id: {category: level}}
        """
        # Collect all agent IDs
        all_agents: Set[str] = set()
        for category in self._registry.values():
            all_agents.update(category.get("acl", {}).keys())
        
        matrix = {}
        for agent_id in sorted(all_agents):
            matrix[agent_id] = {}
            for cat_name, category in self._registry.items():
                level = category.get("acl", {}).get(agent_id, "NONE")
                matrix[agent_id][cat_name] = level
        
        return matrix


# ── CLI ──────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Tool Room CLI")
    parser.add_argument("--status", action="store_true", help="Show status")
    parser.add_argument("--matrix", action="store_true", help="Show ACL matrix")
    parser.add_argument("--check", nargs=3, metavar=("AGENT", "CATEGORY", "TOOL"),
                       help="Check access: --check hunter browsers playwright_chromium")
    parser.add_argument("--agent-tools", type=str, help="Show all tools for an agent")
    args = parser.parse_args()

    try:
        import redis
        r = redis.Redis(host="localhost", port=6379, decode_responses=True)
        r.ping()
    except Exception:
        r = None

    room = ToolRoom(redis_client=r)

    if args.status:
        print(json.dumps(room.get_status(), indent=2))
    elif args.matrix:
        matrix = room.get_acl_matrix()
        # Pretty print matrix
        cats = list(next(iter(matrix.values())).keys()) if matrix else []
        header = f"{'Agent':<12}" + "".join(f"{c:<16}" for c in cats)
        print(header)
        print("─" * len(header))
        for agent, levels in matrix.items():
            row = f"{agent:<12}" + "".join(f"{levels.get(c, 'NONE'):<16}" for c in cats)
            print(row)
    elif args.check:
        agent, category, tool = args.check
        d = room.check_access(agent, category, tool)
        print(f"{'✅ ALLOWED' if d.allowed else '❌ DENIED'} — {agent} → {category}:{tool}")
        print(f"  Level: {d.granted_level}")
        if d.requires_multisign:
            print(f"  ⚠️ Requires MultiSign quorum")
        if d.reason:
            print(f"  Reason: {d.reason}")
    elif args.agent_tools:
        tools = room.get_agent_tools(args.agent_tools)
        if tools:
            for tool, level in sorted(tools.items()):
                print(f"  {tool:<40} → {level}")
        else:
            print(f"No tools registered for '{args.agent_tools}'")
    else:
        parser.print_help()
