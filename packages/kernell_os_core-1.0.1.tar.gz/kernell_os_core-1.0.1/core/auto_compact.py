#!/usr/bin/env python3
"""
core/auto_compact.py
════════════════════
Auto-Compactación de contexto para agentes de Kernell OS.
Sistema de 4 niveles para prevenir overflow de la ventana de contexto.

Previene el overflow de la ventana de contexto detectando:
  1. Proximidad al límite de tokens (auto-compact threshold)
  2. Rendimientos decrecientes (diminishing returns)
  3. Gaps temporales (time-based cleanup)

Integra con CircuitBreaker existente para evitar retries infinitos.

Uso:
    from core.auto_compact import AutoCompactManager

    compact = AutoCompactManager("forge", model_context_window=200_000)

    # Antes de cada query al LLM:
    messages = compact.pre_query_check(messages)
    # Si compactó → messages ahora tiene un resumen + últimos N mensajes

    # Después de cada query:
    compact.post_query_update(response_tokens)

Compact levels:
  Level 1: AutoCompact (threshold-based)       — token budget monitoring
  Level 2: MicroCompact (tool result grouping)  — selective result clearing
  Level 3: SessionMemoryCompact (LLM summary)   — conversation summarization
  Level 4: APIMicroCompact (pre-send cleanup)    — non-destructive optimization
"""
import os
import sys
import json
import time
import logging
import re
from pathlib import Path
from typing import Optional, NamedTuple, Dict, Tuple
from dataclasses import dataclass, field

sys.path.insert(0, str(Path(__file__).parent.parent))

from core.token_estimator import (
    estimate_tokens,
    estimate_messages_tokens,
    format_token_count,
)

logger = logging.getLogger("AutoCompact")

# ── Constantes ───────────────────────────────────────────────────────────────

# Buffer de seguridad antes del límite de contexto
AUTOCOMPACT_BUFFER_TOKENS = 13_000

# Threshold de warning (se acerca al límite)
WARNING_BUFFER_TOKENS = 20_000

# Threshold de rendimientos decrecientes
DIMINISHING_THRESHOLD_TOKENS = 500

# Continuaciones mínimas antes de checkear diminishing returns
MIN_CONTINUATIONS_FOR_DIMINISHING = 3

# Porcentaje del budget para considerar "casi completo"
COMPLETION_THRESHOLD = 0.90

# Máximo de intentos de compactación consecutivos fallidos
MAX_CONSECUTIVE_FAILURES = 3

# Gap temporal para microcompact (minutos) — si el agente estuvo inactivo más de esto
TIME_BASED_GAP_MINUTES = 30

# Cuántos tool results recientes mantener en microcompact temporal
TIME_BASED_KEEP_RECENT = 5

# Ventanas de contexto por modelo (tokens)
# ── MicroCompact: Tool result groups and retention ───────────────────────────

TOOL_RESULT_GROUPS = {
    "bash_results":  ["bash", "shell", "exec"],
    "grep_results":  ["grep", "search", "ripgrep"],
    "file_results":  ["file_read", "file_write", "file_edit"],
    "query_results": ["mt5_query", "qdrant_query", "redis_query", "sql"],
    "web_results":   ["web_search", "web_fetch", "brave_search"],
}

# How many recent tool results to keep per group
MICRO_COMPACT_KEEP_PER_GROUP = 3

# Minimum age (seconds) before a tool result can be cleared
MICRO_COMPACT_MIN_AGE_S = 120

# ── APIMicroCompact: Pre-send cleanup thresholds ─────────────────────────────

# Max stack trace frames to keep
MAX_STACKTRACE_FRAMES = 5

# Max JSON nesting depth for compression (flatten beyond this)
MAX_JSON_DEPTH_DISPLAY = 2

# Whitespace regex pattern for collapsing
EXCESS_WHITESPACE_RE = re.compile(r"\n{3,}")
EXCESS_SPACES_RE = re.compile(r" {4,}")

MODEL_CONTEXT_WINDOWS = {
    "claude-sonnet-4-20250514":    200_000,
    "claude-opus-4-20250514":      200_000,
    "gemini-2.5-pro":              1_000_000,
    "gemini-2.5-flash":            1_000_000,
    "gpt-4o":                      128_000,
    "deepseek-r1":                 128_000,
    "groq-llama-3.3-70b":         128_000,
    "DEFAULT":                     128_000,
}

# Message indicando que el tool result fue limpiado
CLEARED_MSG = "[Old tool result content cleared]"


# ── Tipos ────────────────────────────────────────────────────────────────────

@dataclass
class CompactTracking:
    """Estado de tracking de auto-compactación por sesión."""
    compacted: bool = False
    turn_counter: int = 0
    consecutive_failures: int = 0
    last_delta_tokens: int = 0
    last_total_tokens: int = 0
    started_at: float = field(default_factory=time.time)
    last_compact_at: Optional[float] = None


class TokenWarningState(NamedTuple):
    """Estado de proximidad al límite de tokens."""
    percent_left: int
    above_warning: bool
    above_error: bool
    above_auto_compact: bool
    at_blocking_limit: bool


class BudgetDecision(NamedTuple):
    """Decisión del token budget: continuar o parar."""
    action: str  # "continue" | "stop"
    reason: str
    pct_used: int
    tokens_used: int
    budget: int


# ── Auto Compact Manager ────────────────────────────────────────────────────

class AutoCompactManager:
    """
    Gestor de auto-compactación para un agente específico.
    """

    def __init__(
        self,
        agent_name: str,
        model_context_window: int = 128_000,
        model_name: str = "DEFAULT",
        redis_client=None,
    ):
        self.agent_name = agent_name
        self.context_window = model_context_window or MODEL_CONTEXT_WINDOWS.get(
            model_name, MODEL_CONTEXT_WINDOWS["DEFAULT"]
        )
        self.model_name = model_name
        self._redis = redis_client
        self.tracking = CompactTracking()

        # Threshold efectivo
        self.auto_compact_threshold = self.context_window - AUTOCOMPACT_BUFFER_TOKENS

        logger.info(
            f"[{agent_name}] AutoCompact initialized: "
            f"window={format_token_count(self.context_window)}, "
            f"threshold={format_token_count(self.auto_compact_threshold)}"
        )

    # ── Token Warning State ──────────────────────────────────────────────

    def calculate_warning_state(self, token_usage: int) -> TokenWarningState:
        """
        Calcula el estado de proximidad al límite.
        Retorna si estamos en warning, error, o necesitamos compactar.
        """
        threshold = self.auto_compact_threshold
        percent_left = max(0, round(((threshold - token_usage) / threshold) * 100))

        warning_threshold = threshold - WARNING_BUFFER_TOKENS
        blocking_limit = self.context_window - 3_000  # 3K de margen final

        return TokenWarningState(
            percent_left=percent_left,
            above_warning=token_usage >= warning_threshold,
            above_error=token_usage >= warning_threshold,
            above_auto_compact=token_usage >= threshold,
            at_blocking_limit=token_usage >= blocking_limit,
        )

    # ── Should Auto-Compact ──────────────────────────────────────────────

    def should_auto_compact(self, messages: list[dict]) -> bool:
        """
        Determina si se debe auto-compactar la conversación.

        Returns:
            True si los tokens actuales exceden el threshold
        """
        # Circuit breaker: dejar de intentar después de N fallos
        if self.tracking.consecutive_failures >= MAX_CONSECUTIVE_FAILURES:
            logger.warning(
                f"[{self.agent_name}] Circuit breaker tripped: "
                f"{self.tracking.consecutive_failures} consecutive compact failures"
            )
            return False

        token_count = estimate_messages_tokens(messages)
        state = self.calculate_warning_state(token_count)

        if state.above_warning and not state.above_auto_compact:
            logger.info(
                f"[{self.agent_name}] Context approaching limit: "
                f"{format_token_count(token_count)} / {format_token_count(self.auto_compact_threshold)} "
                f"({state.percent_left}% left)"
            )

        return state.above_auto_compact

    # ── Token Budget / Diminishing Returns ───────────────────────────────

    def check_token_budget(
        self,
        budget: int,
        current_tokens: int,
    ) -> BudgetDecision:
        """
        Evalúa si el agente debería continuar o parar basado en:
          1. Porcentaje del budget consumido
          2. Rendimientos decrecientes (delta bajo en múltiples turnos)

        Evaluates based on token budget consumption and diminishing returns.
        """
        pct = round((current_tokens / budget) * 100) if budget > 0 else 100
        delta = current_tokens - self.tracking.last_total_tokens

        # Detectar rendimientos decrecientes
        is_diminishing = (
            self.tracking.turn_counter >= MIN_CONTINUATIONS_FOR_DIMINISHING
            and delta < DIMINISHING_THRESHOLD_TOKENS
            and self.tracking.last_delta_tokens < DIMINISHING_THRESHOLD_TOKENS
        )

        if is_diminishing:
            return BudgetDecision(
                action="stop",
                reason=f"Diminishing returns: delta={delta} tokens en últimos 2 turnos",
                pct_used=pct,
                tokens_used=current_tokens,
                budget=budget,
            )

        if current_tokens >= budget * COMPLETION_THRESHOLD:
            return BudgetDecision(
                action="stop",
                reason=f"Budget {pct}% consumed ({format_token_count(current_tokens)}/{format_token_count(budget)})",
                pct_used=pct,
                tokens_used=current_tokens,
                budget=budget,
            )

        # Actualizar tracking
        self.tracking.turn_counter += 1
        self.tracking.last_delta_tokens = delta
        self.tracking.last_total_tokens = current_tokens

        return BudgetDecision(
            action="continue",
            reason=f"Budget ok: {pct}% used",
            pct_used=pct,
            tokens_used=current_tokens,
            budget=budget,
        )

    # ── Time-Based Microcompact ──────────────────────────────────────────

    def time_based_cleanup(
        self,
        messages: list[dict],
        last_activity_ts: Optional[float] = None,
    ) -> tuple[list[dict], int]:
        """
        Si ha pasado más de TIME_BASED_GAP_MINUTES desde la última actividad,
        limpia los tool results viejos dejando solo los N más recientes.

        Args:
            messages:        Lista de mensajes
            last_activity_ts: Timestamp de la última actividad

        Returns:
            (messages_cleaned, tokens_freed)
        """
        if last_activity_ts is None:
            # Buscar el último mensaje del asistente
            for msg in reversed(messages):
                if msg.get("role") == "assistant":
                    ts = msg.get("timestamp")
                    if ts:
                        try:
                            last_activity_ts = float(ts)
                        except (ValueError, TypeError):
                            pass
                    break

        if last_activity_ts is None:
            return messages, 0

        gap_minutes = (time.time() - last_activity_ts) / 60

        if gap_minutes < TIME_BASED_GAP_MINUTES:
            return messages, 0

        # Encontrar todos los mensajes con tool_result
        tool_result_indices = []
        for i, msg in enumerate(messages):
            content = msg.get("content", "")
            if isinstance(content, str) and content.strip() and content != CLEARED_MSG:
                if msg.get("role") == "tool" or msg.get("tool_use_id"):
                    tool_result_indices.append(i)
            elif isinstance(content, list):
                for block in content:
                    if isinstance(block, dict) and block.get("type") == "tool_result":
                        if block.get("content") and block["content"] != CLEARED_MSG:
                            tool_result_indices.append(i)
                            break

        if len(tool_result_indices) <= TIME_BASED_KEEP_RECENT:
            return messages, 0

        # Mantener solo los recientes
        to_clear = set(tool_result_indices[:-TIME_BASED_KEEP_RECENT])
        tokens_freed = 0
        cleaned = []

        for i, msg in enumerate(messages):
            if i in to_clear:
                old_tokens = estimate_tokens(
                    msg.get("content", "") if isinstance(msg.get("content"), str) else json.dumps(msg.get("content", ""), default=str)
                )
                cleared_msg = {**msg, "content": CLEARED_MSG}
                cleaned.append(cleared_msg)
                tokens_freed += old_tokens
            else:
                cleaned.append(msg)

        if tokens_freed > 0:
            logger.info(
                f"[{self.agent_name}] Time-based cleanup: "
                f"gap={gap_minutes:.0f}min, cleared {len(to_clear)} results, "
                f"freed ~{format_token_count(tokens_freed)} tokens"
            )

            # Publicar evento en Redis
            self._publish_event("time_based_compact", {
                "gap_minutes": round(gap_minutes),
                "results_cleared": len(to_clear),
                "results_kept": TIME_BASED_KEEP_RECENT,
                "tokens_freed": tokens_freed,
            })

        return cleaned, tokens_freed

    # ── Main API: Pre-Query Check ────────────────────────────────────────

    def pre_query_check(
        self,
        messages: list[dict],
        last_activity_ts: Optional[float] = None,
    ) -> list[dict]:
        """
        Hook principal: llamar ANTES de cada query al LLM.

        1. Primero intenta time-based cleanup (no-destructivo)
        2. Si aún excede, señala que se necesita compactación completa

        Returns:
            Lista de mensajes (potencialmente limpiados)
        """
        # Paso 1: Time-based cleanup
        messages, tokens_freed = self.time_based_cleanup(messages, last_activity_ts)

        # Paso 2: Verificar si necesita auto-compact
        if self.should_auto_compact(messages):
            token_count = estimate_messages_tokens(messages)
            logger.warning(
                f"[{self.agent_name}] ⚠️  AUTO-COMPACT NEEDED: "
                f"{format_token_count(token_count)} tokens "
                f"(threshold: {format_token_count(self.auto_compact_threshold)})"
            )

            # Publicar alerta
            self._publish_event("auto_compact_needed", {
                "token_count": token_count,
                "threshold": self.auto_compact_threshold,
                "tokens_freed_by_cleanup": tokens_freed,
            })

        return messages

    # ── Lifecycle ────────────────────────────────────────────────────────

    def record_compact_success(self):
        """Registra una compactación exitosa."""
        self.tracking.compacted = True
        self.tracking.consecutive_failures = 0
        self.tracking.last_compact_at = time.time()

    def record_compact_failure(self, error: str = ""):
        """Registra una compactación fallida."""
        self.tracking.consecutive_failures += 1
        if self.tracking.consecutive_failures >= MAX_CONSECUTIVE_FAILURES:
            logger.error(
                f"[{self.agent_name}] Compact circuit breaker TRIPPED "
                f"after {self.tracking.consecutive_failures} failures"
            )

    def get_status(self) -> dict:
        """Retorna el estado actual del auto-compact manager."""
        return {
            "agent": self.agent_name,
            "model": self.model_name,
            "context_window": self.context_window,
            "threshold": self.auto_compact_threshold,
            "tracking": {
                "compacted": self.tracking.compacted,
                "turn_counter": self.tracking.turn_counter,
                "consecutive_failures": self.tracking.consecutive_failures,
                "circuit_breaker_tripped": self.tracking.consecutive_failures >= MAX_CONSECUTIVE_FAILURES,
            },
        }

    # ── Internal ─────────────────────────────────────────────────────────

    def _publish_event(self, event_type: str, data: dict):
        """Publica evento en Redis si disponible."""
        if not self._redis:
            return
        try:
            event = json.dumps({
                "type": f"auto_compact:{event_type}",
                "agent": self.agent_name,
                "timestamp": time.time(),
                **data,
            })
            self._redis.lpush("kernell:auto_compact:events", event)
            self._redis.ltrim("kernell:auto_compact:events", 0, 99)
            self._redis.publish("kernell:events", event)
        except Exception:
            pass


# ══════════════════════════════════════════════════════════════════════════════
# LEVEL 2: MICRO-COMPACT — Selective tool result clearing by group
# Groups tool results and drops old ones to free tokens.
# ══════════════════════════════════════════════════════════════════════════════

class MicroCompactManager:
    """
    Clears old tool results by group (bash, grep, query, etc.).
    Keeps the N most recent results per group, clears the rest.
    Preserves tool results that were referenced in assistant responses.
    """

    def __init__(self, agent_name: str):
        self.agent_name = agent_name

    def compact(self, messages: list[dict]) -> Tuple[list[dict], int]:
        """
        Apply micro-compaction: group tool results by type, keep recent, clear old.

        Returns:
            (messages_cleaned, tokens_freed)
        """
        # 1. Find assistant-referenced tool IDs (these are preserved)
        referenced_ids = self._find_referenced_tool_ids(messages)

        # 2. Group tool result indices by category
        groups: Dict[str, list] = {g: [] for g in TOOL_RESULT_GROUPS}
        groups["other"] = []

        for i, msg in enumerate(messages):
            tool_name = msg.get("tool_name", "") or msg.get("name", "")
            tool_id = msg.get("tool_use_id", "") or msg.get("id", "")
            content = msg.get("content", "")

            if not tool_name or not content or content == CLEARED_MSG:
                continue
            if msg.get("role") not in ("tool", None) and not msg.get("tool_use_id"):
                continue

            # Skip referenced results
            if tool_id in referenced_ids:
                continue

            # Classify into group
            group_found = False
            for group_name, prefixes in TOOL_RESULT_GROUPS.items():
                if any(tool_name.lower().startswith(p) for p in prefixes):
                    groups[group_name].append((i, tool_id, tool_name))
                    group_found = True
                    break
            if not group_found:
                groups["other"].append((i, tool_id, tool_name))

        # 3. For each group, keep only the N most recent
        to_clear = set()
        for group_name, entries in groups.items():
            if len(entries) <= MICRO_COMPACT_KEEP_PER_GROUP:
                continue
            # entries are in order of appearance — clear the oldest
            for idx, tool_id, tool_name in entries[:-MICRO_COMPACT_KEEP_PER_GROUP]:
                to_clear.add(idx)

        if not to_clear:
            return messages, 0

        # 4. Clear selected tool results
        tokens_freed = 0
        cleaned = []
        for i, msg in enumerate(messages):
            if i in to_clear:
                old_content = msg.get("content", "")
                if isinstance(old_content, str):
                    tokens_freed += estimate_tokens(old_content)
                cleaned.append({**msg, "content": CLEARED_MSG})
            else:
                cleaned.append(msg)

        if tokens_freed > 0:
            logger.info(
                f"[{self.agent_name}] MicroCompact: cleared {len(to_clear)} tool results, "
                f"freed ~{format_token_count(tokens_freed)} tokens"
            )

        return cleaned, tokens_freed

    def _find_referenced_tool_ids(self, messages: list[dict]) -> set:
        """Find tool IDs that were explicitly referenced in assistant messages."""
        referenced = set()
        for msg in messages:
            if msg.get("role") != "assistant":
                continue
            content = msg.get("content", "")
            if isinstance(content, str):
                # Look for tool_use_id patterns in assistant text
                for m in messages:
                    tid = m.get("tool_use_id", "") or m.get("id", "")
                    if tid and tid in content:
                        referenced.add(tid)
        return referenced


# ══════════════════════════════════════════════════════════════════════════════
# LEVEL 3: SESSION MEMORY COMPACT — LLM-summarized session persistence
# Generates compressed conversation summaries for cross-session continuity.
# ══════════════════════════════════════════════════════════════════════════════

class SessionMemoryCompact:
    """
    When auto-compact triggers, generates a session summary using a fast LLM.
    The summary replaces old conversation history, preserving:
      - Task context and goals
      - Decisions made and rationale
      - Files modified
      - Blockers and errors encountered
      - Pending work
    """

    SUMMARY_SYSTEM_PROMPT = """You are a conversation summarizer for Kernell OS.
Compress the conversation into a structured summary preserving:
1. **Task Context**: What the user/agent is trying to accomplish
2. **Decisions Made**: Key choices and their rationale
3. **Files Modified**: List of files that were changed
4. **Errors/Blockers**: Any issues encountered
5. **Pending Work**: What remains to be done

Output as concise markdown. Maximum 800 words. Focus on ACTIONABLE information."""

    def __init__(self, agent_name: str, redis_client=None):
        self.agent_name = agent_name
        self._redis = redis_client

    def compact(
        self,
        messages: list[dict],
        keep_recent: int = 4,
    ) -> Tuple[list[dict], str]:
        """
        Compact the session by summarizing old messages.

        Args:
            messages: Full message history
            keep_recent: Number of recent messages to preserve verbatim

        Returns:
            (compacted_messages, summary_text)
        """
        if len(messages) <= keep_recent + 2:
            return messages, ""

        # Split: old messages to summarize + recent to keep
        old_messages = messages[:-keep_recent]
        recent_messages = messages[-keep_recent:]

        # Build context string from old messages
        context_parts = []
        for msg in old_messages:
            role = msg.get("role", "unknown")
            content = msg.get("content", "")
            if isinstance(content, list):
                text_parts = []
                for block in content:
                    if isinstance(block, dict) and block.get("type") == "text":
                        text_parts.append(block.get("text", ""))
                content = "\n".join(text_parts)
            if isinstance(content, str) and content.strip() and content != CLEARED_MSG:
                # Truncate very long individual messages
                if len(content) > 1500:
                    content = content[:1500] + "... [TRUNCATED]"
                context_parts.append(f"[{role.upper()}]: {content}")

        context_str = "\n\n".join(context_parts)

        # Generate summary using LLM
        summary = self._generate_summary(context_str)

        if not summary:
            logger.warning(f"[{self.agent_name}] SessionMemoryCompact: summary generation failed")
            return messages, ""

        # Build compacted messages: summary + recent
        summary_message = {
            "role": "user",
            "content": (
                f"[SESSION SUMMARY — Previous conversation compacted]\n\n"
                f"{summary}\n\n"
                f"[END SESSION SUMMARY — Continue from here]"
            ),
        }

        compacted = [summary_message] + recent_messages

        old_tokens = estimate_messages_tokens(old_messages)
        new_tokens = estimate_tokens(summary)
        savings = max(0, old_tokens - new_tokens)

        logger.info(
            f"[{self.agent_name}] SessionMemoryCompact: "
            f"{len(old_messages)} messages → 1 summary, "
            f"saved ~{format_token_count(savings)} tokens"
        )

        return compacted, summary

    def _generate_summary(self, context: str) -> str:
        """Generate a summary using a fast LLM provider."""
        try:
            from core.sea.llm_registry import LLMProviderRegistry
            import redis as redis_lib

            r = self._redis
            if not r:
                pw = os.getenv("REDIS_PASSWORD", "").strip().strip("\"'")
                r = redis_lib.Redis(
                    host="127.0.0.1", port=6379,
                    password=pw or None, decode_responses=True,
                    socket_connect_timeout=2,
                )
                r.ping()

            registry = LLMProviderRegistry(r)
            resp = registry.complete(
                messages=[{"role": "user", "content": f"Summarize this conversation:\n\n{context[:15000]}"}],
                system_prompt=self.SUMMARY_SYSTEM_PROMPT,
                role="fallback_any",
                preferred_provider="gemini_flash",
                max_tokens=2000,
                temperature=0.2,
            )
            if resp and resp.content:
                return resp.content.strip()
        except Exception as e:
            logger.error(f"[{self.agent_name}] SessionMemoryCompact LLM error: {e}")

        return ""


# ══════════════════════════════════════════════════════════════════════════════
# LEVEL 4: API MICRO-COMPACT — Pre-send cleanup
# Lightweight transformations applied before LLM API calls.
# ══════════════════════════════════════════════════════════════════════════════

class APIMicroCompact:
    """
    Lightweight, non-destructive cleanup applied just before sending to the LLM.
    Does NOT modify the actual message history — returns a cleaned copy.

    Operations:
      1. Collapse excessive whitespace (3+ newlines → 2)
      2. Collapse excessive spaces (4+ → 2)
      3. Truncate stack traces to first N frames
      4. Trim JSON in tool results to top-level keys only
    """

    @staticmethod
    def clean(messages: list[dict]) -> list[dict]:
        """Return a cleaned copy of messages for API submission."""
        cleaned = []
        for msg in messages:
            content = msg.get("content", "")
            if isinstance(content, str) and len(content) > 200:
                content = APIMicroCompact._clean_content(content)
                cleaned.append({**msg, "content": content})
            else:
                cleaned.append(msg)
        return cleaned

    @staticmethod
    def _clean_content(text: str) -> str:
        """Apply all cleanup operations to a text string."""
        # 1. Collapse excessive whitespace
        text = EXCESS_WHITESPACE_RE.sub("\n\n", text)
        text = EXCESS_SPACES_RE.sub("  ", text)

        # 2. Truncate stack traces
        text = APIMicroCompact._truncate_stacktraces(text)

        # 3. Compress nested JSON
        text = APIMicroCompact._compress_json_blocks(text)

        return text

    @staticmethod
    def _truncate_stacktraces(text: str) -> str:
        """Truncate Python/JS stack traces to first N frames."""
        lines = text.split("\n")
        result = []
        in_traceback = False
        frame_count = 0

        for line in lines:
            if line.strip().startswith("Traceback (") or line.strip().startswith("Error:"):
                in_traceback = True
                frame_count = 0
                result.append(line)
            elif in_traceback:
                if line.strip().startswith("File ") or line.strip().startswith("at "):
                    frame_count += 1
                    if frame_count <= MAX_STACKTRACE_FRAMES:
                        result.append(line)
                    elif frame_count == MAX_STACKTRACE_FRAMES + 1:
                        result.append(f"    ... ({frame_count}+ frames truncated)")
                elif not line.strip().startswith(" ") and not line.strip().startswith("\t"):
                    # End of traceback
                    in_traceback = False
                    result.append(line)
                else:
                    if frame_count <= MAX_STACKTRACE_FRAMES:
                        result.append(line)
            else:
                result.append(line)

        return "\n".join(result)

    @staticmethod
    def _compress_json_blocks(text: str) -> str:
        """
        Find embedded JSON objects and compress nested ones to keys-only.
        Only touches JSON blocks > 500 chars.
        """
        import re

        def _compress_json(match):
            raw = match.group(0)
            if len(raw) < 500:
                return raw
            try:
                obj = json.loads(raw)
                if isinstance(obj, dict):
                    compressed = {}
                    for k, v in obj.items():
                        if isinstance(v, (dict, list)) and len(json.dumps(v)) > 200:
                            if isinstance(v, dict):
                                compressed[k] = f"{{...{len(v)} keys}}"
                            else:
                                compressed[k] = f"[...{len(v)} items]"
                        else:
                            compressed[k] = v
                    return json.dumps(compressed, indent=1, default=str)
            except (json.JSONDecodeError, TypeError):
                pass
            return raw

        # Match top-level JSON objects
        return re.sub(r'\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}', _compress_json, text)


# ══════════════════════════════════════════════════════════════════════════════
# LEVEL 3: SEMANTIC COMPACT — API Round-Aware Truncation
# Drops old conversation rounds while preserving tool-call integrity.
# ══════════════════════════════════════════════════════════════════════════════

class SemanticCompactor:
    """
    Semantic context compaction that safely drops old messages without
    breaking tool call chains (orphaning tool_results).
    """

    @staticmethod
    def compact(messages: list[dict], threshold_tokens: int) -> tuple[list[dict], int]:
        """
        Compacts the messages to fit inside threshold_tokens.
        Returns (compacted_messages, tokens_freed).
        """
        from core.token_estimator import estimate_messages_tokens
        
        current_tokens = estimate_messages_tokens(messages)
        if current_tokens <= threshold_tokens:
            return messages, 0

        # Strip images first to see if that's enough
        stripped_messages = SemanticCompactor._strip_images(messages)
        stripped_tokens = estimate_messages_tokens(stripped_messages)
        
        if stripped_tokens <= threshold_tokens:
            return stripped_messages, current_tokens - stripped_tokens

        # Group by rounds and truncate
        rounds = SemanticCompactor._group_by_api_round(stripped_messages)
        final_rounds = SemanticCompactor._truncate_rounds(rounds, threshold_tokens)
        
        compacted = [msg for r in final_rounds for msg in r]
        compacted_tokens = estimate_messages_tokens(compacted)

        # Make sure we don't return an empty array if we had messages
        if not compacted and messages:
            compacted = [messages[-1]]
            
        return compacted, current_tokens - compacted_tokens

    @staticmethod
    def _strip_images(messages: list[dict]) -> list[dict]:
        """Replace heavy image blocks with [image] placeholders."""
        stripped = []
        for msg in messages:
            content = msg.get("content", "")
            if isinstance(content, list):
                new_content = []
                for block in content:
                    if isinstance(block, dict) and block.get("type") == "image_url":
                        new_content.append({"type": "text", "text": "[image data removed for context compaction]"})
                    else:
                        new_content.append(block)
                stripped.append({**msg, "content": new_content})
            else:
                stripped.append(msg)
        return stripped

    @staticmethod
    def _group_by_api_round(messages: list[dict]) -> list[list[dict]]:
        """
        Group messages into API rounds to preserve tool call integrity.
        A round starts with a 'user' or 'system' message.
        """
        rounds = []
        current_round = []

        for msg in messages:
            role = msg.get("role")
            if role in ("user", "system") and current_round:
                rounds.append(current_round)
                current_round = []
            
            current_round.append(msg)
            
        if current_round:
            rounds.append(current_round)
            
        return rounds

    @staticmethod
    def _truncate_rounds(rounds: list[list[dict]], threshold: int) -> list[list[dict]]:
        """Drop older rounds progressively until we fit the threshold."""
        from core.token_estimator import estimate_messages_tokens
        
        # Identify non-removable indices: system prompt (0) and latest round (-1)
        removable_indices = []
        for i, r in enumerate(rounds):
            if i == len(rounds) - 1:
                continue # Never remove the last round (current query)
            if r[0].get("role") == "system":
                continue # Never remove system instructions
            removable_indices.append(i)
            
        # Try dropping from oldest removable to newest
        dropped = set()
        for idx in removable_indices:
            dropped.add(idx)
            kept = [r for i, r in enumerate(rounds) if i not in dropped]
            flat = [msg for r in kept for msg in r]
            if estimate_messages_tokens(flat) <= threshold:
                break
                
        return kept


# ── CLI ───────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Auto-Compact Manager — Kernell OS")
    parser.add_argument("--demo", action="store_true", help="Run demo")
    parser.add_argument("--models", action="store_true", help="Show model context windows")
    args = parser.parse_args()

    if args.models:
        print("\n📊 Model Context Windows\n")
        for model, window in sorted(MODEL_CONTEXT_WINDOWS.items(), key=lambda x: -x[1]):
            threshold = window - AUTOCOMPACT_BUFFER_TOKENS
            print(f"  {model:<35} {format_token_count(window):>6}  (compact at {format_token_count(threshold)})")

    elif args.demo:
        print("🔧 Auto-Compact V2 Demo (4 levels)\n")

        # Level 1: AutoCompact (threshold)
        print("── Level 1: AutoCompact (threshold) ──")
        mgr = AutoCompactManager("demo_agent", model_context_window=200_000)
        messages = [
            {"role": "user", "content": "Analyze this codebase"},
            {"role": "assistant", "content": "x" * 100_000},
            {"role": "user", "content": "y" * 200_000},
        ]
        token_count = estimate_messages_tokens(messages)
        print(f"  Total tokens: {format_token_count(token_count)}")
        print(f"  Should compact: {mgr.should_auto_compact(messages)}")

        # Level 2: MicroCompact (tool result groups)
        print("\n── Level 2: MicroCompact (tool result groups) ──")
        micro = MicroCompactManager("demo_agent")
        tool_messages = [
            {"role": "user", "content": "test"},
            {"role": "tool", "tool_name": "bash", "tool_use_id": "bash_1", "content": "output " * 500},
            {"role": "tool", "tool_name": "bash", "tool_use_id": "bash_2", "content": "output " * 500},
            {"role": "tool", "tool_name": "bash", "tool_use_id": "bash_3", "content": "output " * 500},
            {"role": "tool", "tool_name": "bash", "tool_use_id": "bash_4", "content": "output " * 500},
            {"role": "tool", "tool_name": "bash", "tool_use_id": "bash_5", "content": "output " * 500},
            {"role": "tool", "tool_name": "grep", "tool_use_id": "grep_1", "content": "match " * 300},
            {"role": "assistant", "content": "Found the results."},
        ]
        cleaned, freed = micro.compact(tool_messages)
        print(f"  Before: {len(tool_messages)} messages")
        print(f"  After:  {len(cleaned)} messages (cleared content in old results)")
        print(f"  Freed:  ~{format_token_count(freed)} tokens")

        # Level 4: APIMicroCompact (pre-send cleanup)
        print("\n── Level 4: APIMicroCompact (pre-send cleanup) ──")
        dirty = [
            {"role": "tool", "content": "Result:\n\n\n\n\n\nLine 1\n\n\n\nLine 2    lots   of    spaces"},
            {"role": "tool", "content": 'Traceback (most recent call last):\n' + ''.join(
                f'  File "test.py", line {i}, in func{i}\n    pass\n' for i in range(20)
            )},
        ]
        api_cleaned = APIMicroCompact.clean(dirty)
        for i, (d, c) in enumerate(zip(dirty, api_cleaned)):
            print(f"  [{i}] {len(d['content'])} → {len(c['content'])} chars")

        print(f"\n  Status: {json.dumps(mgr.get_status(), indent=2)}")
        print("\n✅ All 4 compact levels operational.")

    else:
        parser.print_help()
