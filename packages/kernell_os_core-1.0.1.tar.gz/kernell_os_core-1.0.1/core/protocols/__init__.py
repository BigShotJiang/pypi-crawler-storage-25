"""Internal inter-agent protocol package."""

