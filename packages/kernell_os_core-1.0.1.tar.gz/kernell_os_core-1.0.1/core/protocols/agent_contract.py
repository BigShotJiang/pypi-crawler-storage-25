import json
import time
import uuid
from typing import Any, Dict, Optional, List

from core.audit.economic_ledger import EconomicLedger

PROTOCOL_NAME = "internal_protocol_v1"
PROTOCOL_VERSION = "1.1.0"


_CAPABILITIES: Dict[str, Dict[str, Any]] = {
    "merchant": {"tasks": ["list_product", "ola1_run"], "queue": "kernell:merchant:prospects"},
    "ads": {"tasks": ["create_campaign", "roas_gate"], "queue": "kernell:tasks:ads"},
    "nemesis": {"tasks": ["backtest", "canary_guard", "unlock_live"], "queue": "kernell:tasks:nemesis"},
    "hunter": {"tasks": ["preflight", "bounty_scan", "bounty_submit"], "queue": "kernell:tasks:hunter"},
    "chronos": {"tasks": ["run_job", "schedule_tick"], "queue": "kernell:tasks:chronos"},
}


def discover_capabilities(agent: Optional[str] = None) -> Dict[str, Any]:
    if agent:
        cap = _CAPABILITIES.get(agent)
        return {
            "ok": True,
            "protocol": {"name": PROTOCOL_NAME, "version": PROTOCOL_VERSION},
            "agent": agent,
            "capabilities": cap or {},
            "exists": bool(cap),
        }
    return {
        "ok": True,
        "protocol": {"name": PROTOCOL_NAME, "version": PROTOCOL_VERSION},
        "agents": _CAPABILITIES,
        "total": len(_CAPABILITIES),
    }


def _err(
    code: str,
    message: str,
    *,
    request_id: Optional[str] = None,
    retryable: bool = False,
    retry_after: Optional[int] = None,
    extra: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    out = {
        "ok": False,
        "protocol": {"name": PROTOCOL_NAME, "version": PROTOCOL_VERSION},
        "error_code": code,
        "error_message": message,
        "retryable": retryable,
        "request_id": request_id,
    }
    if retry_after is not None:
        out["retry_after"] = retry_after
    if extra:
        out.update(extra)
    return out


def invoke_task(
    agent: str,
    task_type: str,
    payload: Optional[Dict[str, Any]] = None,
    *,
    redis_client=None,
) -> Dict[str, Any]:
    payload = payload or {}
    cap = _CAPABILITIES.get(agent)
    ledger = EconomicLedger(redis_client=redis_client)
    request_id = uuid.uuid4().hex[:12]

    if not cap:
        out = _err(
            "UNKNOWN_AGENT",
            f"Unknown agent '{agent}'",
            request_id=request_id,
            retryable=False,
            extra={"agent": agent, "task_type": task_type},
        )
        ledger.append_event(domain="protocol", action="invoke_task", status="blocked", metadata=out)
        return out
    if task_type not in cap.get("tasks", []):
        out = _err(
            "TASK_NOT_ALLOWED",
            f"Task '{task_type}' is not allowed for agent '{agent}'",
            request_id=request_id,
            retryable=False,
            extra={"agent": agent, "task_type": task_type},
        )
        ledger.append_event(domain="protocol", action="invoke_task", status="blocked", metadata=out)
        return out

    envelope = {
        "protocol": {"name": PROTOCOL_NAME, "version": PROTOCOL_VERSION},
        "request_id": request_id,
        "agent": agent,
        "task_type": task_type,
        "payload": payload,
        "ts": time.time(),
        "source": PROTOCOL_NAME,
    }

    if redis_client:
        redis_client.lpush(cap["queue"], json.dumps(envelope))
        mark_task_status(
            request_id=request_id,
            status="queued",
            redis_client=redis_client,
            agent=agent,
            task_type=task_type,
            details={"queue": cap["queue"]},
        )

    out = {
        "ok": True,
        "protocol": {"name": PROTOCOL_NAME, "version": PROTOCOL_VERSION},
        "request_id": request_id,
        "queued_to": cap["queue"],
        "agent": agent,
        "task_type": task_type,
        "status": "queued",
    }
    ledger.append_event(domain="protocol", action="invoke_task", status="ok", metadata=out)
    return out


def mark_task_status(
    *,
    request_id: str,
    status: str,
    redis_client=None,
    agent: Optional[str] = None,
    task_type: Optional[str] = None,
    details: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    details = details or {}
    payload = {
        "protocol": {"name": PROTOCOL_NAME, "version": PROTOCOL_VERSION},
        "request_id": request_id,
        "status": status,
        "agent": agent,
        "task_type": task_type,
        "details": details,
        "ts": time.time(),
    }
    if redis_client:
        key = f"kernell:protocol:requests:{request_id}"
        redis_client.hset(
            key,
            mapping={
                "status": status,
                "agent": agent or "",
                "task_type": task_type or "",
                "details": json.dumps(details),
                "updated_at": str(payload["ts"]),
            },
        )
        redis_client.expire(key, 86400 * 7)
        redis_client.lpush("kernell:protocol:requests:recent", json.dumps(payload))
        redis_client.ltrim("kernell:protocol:requests:recent", 0, 1000)

    EconomicLedger(redis_client=redis_client).append_event(
        domain="protocol",
        action="task_status",
        status="ok",
        metadata=payload,
    )
    return payload


def get_task_status(request_id: str, redis_client=None) -> Dict[str, Any]:
    if not redis_client:
        return _err(
            "REDIS_UNAVAILABLE",
            "Redis client unavailable",
            request_id=request_id,
            retryable=True,
            retry_after=5,
        )
    key = f"kernell:protocol:requests:{request_id}"
    raw = redis_client.hgetall(key) or {}
    if not raw:
        return _err(
            "REQUEST_NOT_FOUND",
            f"Request '{request_id}' not found",
            request_id=request_id,
            retryable=False,
        )
    details = raw.get("details")
    try:
        details = json.loads(details) if details else {}
    except Exception:
        details = {"raw": str(details)}
    return {
        "ok": True,
        "protocol": {"name": PROTOCOL_NAME, "version": PROTOCOL_VERSION},
        "request_id": request_id,
        "status": raw.get("status", "unknown"),
        "agent": raw.get("agent") or None,
        "task_type": raw.get("task_type") or None,
        "details": details,
        "updated_at": float(raw.get("updated_at") or 0),
    }


def list_recent_requests(limit: int = 50, redis_client=None) -> Dict[str, Any]:
    if not redis_client:
        return {
            "ok": False,
            "protocol": {"name": PROTOCOL_NAME, "version": PROTOCOL_VERSION},
            "items": [],
            "total": 0,
            "error_code": "REDIS_UNAVAILABLE",
            "error_message": "Redis client unavailable",
            "retryable": True,
            "retry_after": 5,
        }
    lim = max(1, min(int(limit), 500))
    rows = redis_client.lrange("kernell:protocol:requests:recent", 0, lim - 1) or []
    items: List[Dict[str, Any]] = []
    for row in rows:
        try:
            items.append(json.loads(row) if isinstance(row, str) else row)
        except Exception:
            continue
    return {
        "ok": True,
        "protocol": {"name": PROTOCOL_NAME, "version": PROTOCOL_VERSION},
        "items": items,
        "total": len(items),
    }


def sweep_timeouts(
    *,
    redis_client=None,
    queued_timeout_s: int = 300,
    running_timeout_s: int = 900,
) -> Dict[str, Any]:
    """
    Mark stale queued/running requests as failed_timeout.
    """
    if not redis_client:
        return _err(
            "REDIS_UNAVAILABLE",
            "Redis client unavailable",
            retryable=True,
            retry_after=5,
        )

    rows = redis_client.lrange("kernell:protocol:requests:recent", 0, 1000) or []
    now = time.time()
    timed_out = 0
    scanned = 0

    for row in rows:
        try:
            item = json.loads(row) if isinstance(row, str) else row
            request_id = item.get("request_id")
            if not request_id:
                continue
            status_obj = get_task_status(request_id, redis_client=redis_client)
            if not status_obj.get("ok"):
                continue
            scanned += 1
            status = status_obj.get("status")
            updated_at = float(status_obj.get("updated_at") or 0)
            age = now - updated_at if updated_at > 0 else 0
            if status == "queued" and age > queued_timeout_s:
                mark_task_status(
                    request_id=request_id,
                    status="failed_timeout",
                    redis_client=redis_client,
                    agent=status_obj.get("agent"),
                    task_type=status_obj.get("task_type"),
                    details={"reason": "queued_timeout", "age_s": age, "timeout_s": queued_timeout_s},
                )
                timed_out += 1
            elif status == "running" and age > running_timeout_s:
                mark_task_status(
                    request_id=request_id,
                    status="failed_timeout",
                    redis_client=redis_client,
                    agent=status_obj.get("agent"),
                    task_type=status_obj.get("task_type"),
                    details={"reason": "running_timeout", "age_s": age, "timeout_s": running_timeout_s},
                )
                timed_out += 1
        except Exception:
            continue

    out = {
        "ok": True,
        "protocol": {"name": PROTOCOL_NAME, "version": PROTOCOL_VERSION},
        "scanned": scanned,
        "timed_out": timed_out,
        "queued_timeout_s": queued_timeout_s,
        "running_timeout_s": running_timeout_s,
    }
    EconomicLedger(redis_client=redis_client).append_event(
        domain="protocol",
        action="sweep_timeouts",
        status="ok",
        metadata=out,
    )
    return out


def run_chronos_protocol_timeout_guard() -> Dict[str, Any]:
    redis_client = None
    try:
        import redis

        host = __import__("os").getenv("REDIS_HOST", "127.0.0.1").strip().strip("\"'") or "127.0.0.1"
        port = int(__import__("os").getenv("REDIS_PORT", 6380))
        password = __import__("os").getenv("REDIS_PASSWORD", "").strip().strip("\"'") or None
        redis_client = redis.Redis(
            host=host,
            port=port,
            password=password,
            decode_responses=True,
            socket_connect_timeout=5,
        )
    except Exception:
        redis_client = None

    import os as _os
    queued_timeout_s = int(_os.getenv("PROTOCOL_QUEUED_TIMEOUT_S", "300"))
    running_timeout_s = int(_os.getenv("PROTOCOL_RUNNING_TIMEOUT_S", "900"))
    return sweep_timeouts(
        redis_client=redis_client,
        queued_timeout_s=queued_timeout_s,
        running_timeout_s=running_timeout_s,
    )


def protocol_health(redis_client=None, recent_limit: int = 200) -> Dict[str, Any]:
    """
    Return protocol health metrics for observability dashboards.
    """
    if not redis_client:
        return _err(
            "REDIS_UNAVAILABLE",
            "Redis client unavailable",
            retryable=True,
            retry_after=5,
        )

    rows = redis_client.lrange("kernell:protocol:requests:recent", 0, max(1, min(recent_limit, 1000)) - 1) or []
    now = time.time()
    open_count = 0
    failed_timeout_1h = 0
    queue_ages: List[float] = []

    for row in rows:
        try:
            item = json.loads(row) if isinstance(row, str) else row
            status = str(item.get("status") or "")
            ts = float(item.get("ts") or 0.0)
            if status in ("queued", "running"):
                open_count += 1
                if ts > 0:
                    queue_ages.append(max(0.0, now - ts))
            if status == "failed_timeout" and ts > 0 and (now - ts) <= 3600:
                failed_timeout_1h += 1
        except Exception:
            continue

    avg_queue_age_s = round((sum(queue_ages) / len(queue_ages)), 2) if queue_ages else 0.0
    out = {
        "ok": True,
        "protocol": {"name": PROTOCOL_NAME, "version": PROTOCOL_VERSION},
        "open_requests": open_count,
        "failed_timeout_last_hour": failed_timeout_1h,
        "avg_queue_age_s": avg_queue_age_s,
        "sample_size": len(rows),
        "ts": now,
    }
    return out


def protocol_slo_status(redis_client=None) -> Dict[str, Any]:
    """
    Evaluate protocol SLOs and return alert-oriented status.
    Thresholds are controlled via environment variables.
    """
    if not redis_client:
        return _err(
            "REDIS_UNAVAILABLE",
            "Redis client unavailable",
            retryable=True,
            retry_after=5,
        )

    import os as _os

    max_open = int(_os.getenv("PROTOCOL_SLO_MAX_OPEN_REQUESTS", "25"))
    max_avg_queue_age_s = float(_os.getenv("PROTOCOL_SLO_MAX_AVG_QUEUE_AGE_S", "180"))
    max_failed_timeout_1h = int(_os.getenv("PROTOCOL_SLO_MAX_FAILED_TIMEOUT_1H", "0"))

    health = protocol_health(redis_client=redis_client, recent_limit=300)
    if not health.get("ok"):
        return health

    checks = {
        "open_requests": {
            "value": int(health.get("open_requests") or 0),
            "threshold": max_open,
            "ok": int(health.get("open_requests") or 0) <= max_open,
        },
        "avg_queue_age_s": {
            "value": float(health.get("avg_queue_age_s") or 0.0),
            "threshold": max_avg_queue_age_s,
            "ok": float(health.get("avg_queue_age_s") or 0.0) <= max_avg_queue_age_s,
        },
        "failed_timeout_last_hour": {
            "value": int(health.get("failed_timeout_last_hour") or 0),
            "threshold": max_failed_timeout_1h,
            "ok": int(health.get("failed_timeout_last_hour") or 0) <= max_failed_timeout_1h,
        },
    }

    failed = [name for name, item in checks.items() if not item["ok"]]
    severity = "ok"
    if failed:
        severity = "critical" if "failed_timeout_last_hour" in failed else "warning"

    alerts: List[Dict[str, Any]] = []
    for name in failed:
        row = checks[name]
        alerts.append(
            {
                "kind": "slo_breach",
                "metric": name,
                "value": row["value"],
                "threshold": row["threshold"],
                "severity": "critical" if name == "failed_timeout_last_hour" else "warning",
                "message": f"{name}={row['value']} exceeds threshold={row['threshold']}",
            }
        )

    return {
        "ok": True,
        "protocol": {"name": PROTOCOL_NAME, "version": PROTOCOL_VERSION},
        "slo_status": severity,
        "slo_ok": not failed,
        "checks": checks,
        "alerts": alerts,
        "health": health,
        "ts": time.time(),
    }

