#!/usr/bin/env python3
"""
🌐 KERNELL OS — CLAUDE WEB BROWSER AUTOMATION v2.0
======================================================
Permite a los agentes de Kernell consultar a Claude 3 Sonnet (Free)
directamente vía web (chat.anthropic.com) con Playwright.
Incorpora Rotación de Cuentas: Si una cuenta agota sus tokens gratis,
migra automáticamente a la siguiente cookie y reanuda el contexto
(pasando el macro-prompt en un nuevo chat).

Uso:
  export ANTHROPIC_SESSION_KEYS="sk-ant-sid...1,sk-ant-sid...2"
  python3 core/tools/claude_web_client.py --prompt "Desarrolla un plan de marketing"
"""

import os
import time
import logging
from typing import Dict, List
from datetime import datetime, timezone
from core.capability_enforcer import CapabilityEnforcer

logger = logging.getLogger("CLAUDE_WEB_CLIENT")

class ClaudeWebClient:
    def __init__(self, headless: bool = True, caller_agent: str = "unknown"):
        env_headless = os.getenv("CLAUDE_WEB_HEADLESS", "true").lower() == "true"
        self._headless = headless if headless is not None else env_headless
        self._user_data_dir = os.getenv("CHROME_USER_DATA_DIR", "/tmp/kernell_chromium_profile")
        self._caller_agent = caller_agent
        
        keys_env = os.getenv("ANTHROPIC_SESSION_KEYS", os.getenv("ANTHROPIC_SESSION_KEY", ""))
        self._session_cookies = [k.strip() for k in keys_env.split(",") if k.strip()]

    def ask(self, prompt: str) -> Dict:
        # 🛡️ RESTRICCIÓN DE SEGURIDAD APLICADA: Solo Forge o Auditoría pueden eludir la API.
        allowed_callers = ["forge", "auditor", "salus", "cli_test"]
        if self._caller_agent not in allowed_callers:
            logger.warning(f"ACCESO DENEGADO: El agente '{self._caller_agent}' intentó usar Claude Web Bypasser. Solo permitido para: {allowed_callers}")
            return {
                "success": False,
                "error": f"Security Policy Violation: Agent '{self._caller_agent}' is not authorized to use Web Claude Bypasser."
            }
        if not self._session_cookies and not os.path.exists(self._user_data_dir):
            return {
                "success": False, 
                "error": "Ni ANTHROPIC_SESSION_KEYS ni CHROME_USER_DATA_DIR están configurados correctamente."
            }

        # Si no hay lista de cookies pero hay un profile predeterminado, usamos un dummy array para intentar una vez
        cookies_to_try = self._session_cookies if self._session_cookies else [""]

        for idx, cookie in enumerate(cookies_to_try):
            logger.info(f"Intentando con la cuenta/cookie #{idx + 1} de {len(cookies_to_try)}")
            
            try:
                res = self._ask_with_cookie(prompt, cookie)
                if res.get("success"):
                    return res
                elif res.get("rate_limited"):
                    logger.warning(f"Cuenta #{idx + 1} agotó los mensajes gratis. Rotando a la siguiente...")
                    continue  # Pasa a la siguiente iteracion
                else:
                    logger.error(f"Error en la cuenta #{idx + 1}: {res.get('error')}")
                    # Si falla por razones críticas (Cloudflare ban, etc), abortamos
                    return res
                    
            except Exception as e:
                logger.error(f"Fallo inesperado en la cuenta #{idx + 1}: {e}")

        return {
            "success": False,
            "error": "Todas las cuentas agotaron sus mensajes gratuitos o fallaron."
        }

    def _ask_with_cookie(self, prompt: str, cookie: str) -> Dict:
        from playwright.sync_api import sync_playwright

        with sync_playwright() as p:
            context = p.chromium.launch_persistent_context(
                user_data_dir=self._user_data_dir if not cookie else f"/tmp/kernell_chromium_{hash(cookie)}",
                headless=self._headless,
                args=[
                    "--no-sandbox", 
                    "--disable-blink-features=AutomationControlled",
                    "--window-size=1280,720"
                ],
                user_agent="Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
            )

            if cookie:
                context.add_cookies([{
                    "name": "sessionKey",
                    "value": cookie,
                    "domain": ".anthropic.com",
                    "path": "/",
                    "httpOnly": True,
                    "secure": True,
                    "sameSite": "Lax"
                }])

            page = context.new_page()

            logger.info("Navegando a chat.anthropic.com...")
            try:
                page.goto("https://chat.anthropic.com/", timeout=15000)
            except Exception as ex:
                logger.warning(f"Timeout navegando, prosiguiendo: {ex}")
            
            page.wait_for_load_state("domcontentloaded")
            
            if "cf-browser-verification" in page.content() or "cloudflare" in page.title().lower():
                context.close()
                return {"success": False, "error": "Bot bloqueado por Cloudflare. Requiere Headless=False temporalmente."}

            try:
                page.wait_for_selector('div[contenteditable="true"]', timeout=15000)
            except Exception:
                page.screenshot(path="/tmp/claude_web_error.png")
                context.close()
                return {"success": False, "error": "No se localizó el chat input. ¿Sesión vencida? Revisa /tmp/claude_web_error.png"}

            logger.info("Inyectando prompt (esto migra automáticamente el contexto al nuevo chat)...")
            editor = page.locator('div[contenteditable="true"]')
            editor.click()
            page.keyboard.type(prompt, delay=5)
            page.keyboard.press("Enter")
            
            logger.info("Esperando inferencia de generación...")
            page.wait_for_timeout(3000)
            
            # Verificamos rápidamente si saltó el cartel de límite de cuota (Sonnet 3.5 Limit)
            page_text = page.content().lower()
            if "out of free messages" in page_text or "out of messages" in page_text or "upgrade to claude pro" in page_text or "until" in page_text and "pm" in page_text:
                context.close()
                return {"success": False, "rate_limited": True, "error": "Se alcanzó el Rate Limit gratuito de uso en esta cuenta."}
            
            response_locator = page.locator('.font-claude-message').last
            
            last_length = -1
            stable_count = 0
            max_wait = 120
            
            for _ in range(max_wait):
                try:
                    current_text = response_locator.inner_text()
                    current_len = len(current_text)
                except Exception:
                    current_len = 0
                    current_text = ""
                
                if current_len > 0 and current_len == last_length:
                    stable_count += 1
                    if stable_count >= 3:
                        break
                else:
                    stable_count = 0
                    last_length = current_len
                    
                page.wait_for_timeout(2000)
            
            try:
                final_text = response_locator.inner_text()
            except BaseException:
                final_text = ""
            
            context.close()
            
            # Chequeo extra por si un modal de rate limit apareció durante/después de intentar enviar
            if not final_text.strip():
                 return {"success": False, "rate_limited": True, "error": "No hubo respuesta. Rate limit posible."}

            return {
                "success": True,
                "model": "WebSession (Sonnet/Opus)",
                "response": final_text,
                "timestamp": datetime.now(timezone.utc).isoformat()
            }

# ── CLI ───────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Kernell Claude Web Caller (Multi-Account Rotation)")
    parser.add_argument("--prompt", type=str, required=True, help="Texto a consultar a Claude.")
    parser.add_argument("--visible", action="store_true", help="Lanza el navegador NO headless para debug / login manual.")
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")

    client = ClaudeWebClient(headless=not args.visible)
    
    print(f" Consultando a Claude Web (Rotación Activa | Headless={'NO' if args.visible else 'SI'})...")
    res = client.ask(args.prompt)
    
    if res.get("success"):
        print("\n" + "="*50)
        print("🤖 CLAUDE DICE:\n" + "="*50)
        print(res["response"])
        print("="*50)
    else:
        print(f"\n❌ Error Crítico: {res.get('error')}")
