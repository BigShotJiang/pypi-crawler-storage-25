#!/usr/bin/env python3
"""
core/coordinator_bridge.py
═══════════════════════════
Coordinator Bridge — Patrón de orquestación multi-agente para Kernell OS.

Implementa el patrón Synthesis-Before-Delegation para coordinación multi-agente.

El Coordinador (kernell PID-1 u otro agente designado) NO ejecuta tools
directamente. En su lugar:
  1. Spawna workers via spawn_worker()
  2. Monitorea resultados via TaskNotification (pub/sub Redis)
  3. SINTETIZA findings antes de delegar más trabajo
  4. Gestiona concurrencia: read_only (parallel) vs write_heavy (serial)

Protocolo de notificación:
  Workers publican en: kernell:coordinator:{session_id}:notifications
  Formato: TaskNotification dataclass serializado a JSON

Uso:
    from core.coordinator_bridge import CoordinatorSession

    session = CoordinatorSession("kernell", redis_client=r)

    # Spawnar workers en paralelo (research)
    t1 = session.spawn_worker("forge", "Investigate auth module...", mode="read_only")
    t2 = session.spawn_worker("hunter", "Find similar patterns...", mode="read_only")

    # Esperar resultados
    notifications = session.collect_notifications(timeout=60)

    # Sintetizar OBLIGATORIAMENTE antes de hacer follow-up
    synthesis = session.synthesize(t1)
    session.send_message(t1, "Fix the null pointer at line 42 based on...")

    # Workflow completo
    session.get_status()

Sovereign Architecture — Blueprint XV
"""

import os
import sys
import json
import time
import uuid
import logging
from pathlib import Path
from datetime import datetime, timezone
from typing import Dict, List, Optional, Set
from dataclasses import dataclass, field, asdict
from enum import Enum

ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT))

logger = logging.getLogger("CoordinatorBridge")


# ── Enums ────────────────────────────────────────────────────────────────────

class TaskStatus(str, Enum):
    PENDING   = "pending"
    RUNNING   = "running"
    COMPLETED = "completed"
    FAILED    = "failed"
    KILLED    = "killed"


class ConcurrencyMode(str, Enum):
    READ_ONLY   = "read_only"    # Safe to parallelize
    WRITE_HEAVY = "write_heavy"  # Must serialize


class WorkflowPhase(str, Enum):
    RESEARCH       = "research"
    SYNTHESIS      = "synthesis"
    IMPLEMENTATION = "implementation"
    VERIFICATION   = "verification"


# ── Data Models ──────────────────────────────────────────────────────────────

@dataclass
class TaskUsage:
    """Resource usage metrics for a worker task."""
    total_tokens: int = 0
    tool_uses: int = 0
    duration_ms: float = 0
    model_used: str = ""


@dataclass
class TaskNotification:
    """
    Structured notification from worker → coordinator.
    Uses XML-based notification protocol for system prompt injection.
    """
    task_id: str
    agent_name: str
    status: str           # TaskStatus value
    summary: str          # Human-readable outcome
    result: Optional[str] = None   # Full text response
    error: Optional[str] = None    # Error message if failed
    usage: Optional[TaskUsage] = None
    phase: str = ""       # WorkflowPhase value
    files_modified: List[str] = field(default_factory=list)
    timestamp: str = ""

    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = datetime.now(timezone.utc).isoformat()

    def to_dict(self) -> dict:
        d = asdict(self)
        if d.get("usage") is None:
            d["usage"] = {}
        return d

    @classmethod
    def from_dict(cls, data: dict) -> "TaskNotification":
        usage_data = data.get("usage")
        if isinstance(usage_data, dict) and usage_data:
            usage = TaskUsage(**usage_data)
        else:
            usage = None
        return cls(
            task_id=data.get("task_id", ""),
            agent_name=data.get("agent_name", ""),
            status=data.get("status", TaskStatus.PENDING),
            summary=data.get("summary", ""),
            result=data.get("result"),
            error=data.get("error"),
            usage=usage,
            phase=data.get("phase", ""),
            files_modified=data.get("files_modified", []),
            timestamp=data.get("timestamp", ""),
        )

    def to_xml(self) -> str:
        """Render as XML for system prompt injection."""
        lines = [
            "<task-notification>",
            f"  <task-id>{self.task_id}</task-id>",
            f"  <agent>{self.agent_name}</agent>",
            f"  <status>{self.status}</status>",
            f"  <summary>{self.summary}</summary>",
        ]
        if self.result:
            lines.append(f"  <result>{self.result[:2000]}</result>")
        if self.error:
            lines.append(f"  <error>{self.error[:500]}</error>")
        if self.usage:
            lines.extend([
                "  <usage>",
                f"    <total_tokens>{self.usage.total_tokens}</total_tokens>",
                f"    <tool_uses>{self.usage.tool_uses}</tool_uses>",
                f"    <duration_ms>{self.usage.duration_ms}</duration_ms>",
                "  </usage>",
            ])
        if self.files_modified:
            lines.append(f"  <files_modified>{', '.join(self.files_modified)}</files_modified>")
        lines.append("</task-notification>")
        return "\n".join(lines)


@dataclass
class WorkerState:
    """Internal tracking of a spawned worker."""
    task_id: str
    agent_name: str
    prompt: str
    concurrency_mode: ConcurrencyMode
    phase: WorkflowPhase
    status: TaskStatus = TaskStatus.PENDING
    spawned_at: float = 0
    notification: Optional[TaskNotification] = None
    synthesized: bool = False
    messages_sent: int = 0
    scratchpad_files: List[str] = field(default_factory=list)

    def __post_init__(self):
        if not self.spawned_at:
            self.spawned_at = time.time()


# ── Coordinator Session ──────────────────────────────────────────────────────

class CoordinatorSession:
    """
    Manages a coordination session for a Kernell OS orchestrator agent.

    The coordinator follows strict multi-agent orchestration rules:
      1. NEVER executes filesystem/bash tools directly
      2. ALWAYS synthesizes findings before delegating follow-up
      3. Manages concurrency: read_only tasks run in parallel, write_heavy serial
      4. Workers are tracked via Redis pub/sub notifications
    """

    REDIS_PREFIX = "kernell:coordinator:"

    def __init__(
        self,
        coordinator_name: str,
        redis_client=None,
        session_id: Optional[str] = None,
        scratchpad_dir: Optional[str] = None,
    ):
        self.coordinator_name = coordinator_name
        self._redis = redis_client
        self.session_id = session_id or f"coord_{uuid.uuid4().hex[:12]}"
        self._workers: Dict[str, WorkerState] = {}
        self._notification_channel = f"{self.REDIS_PREFIX}{self.session_id}:notifications"
        self._started_at = time.time()

        # Concurrency tracking
        self._active_write_tasks: Set[str] = set()

        # Scratchpad setup
        self.scratchpad_dir = scratchpad_dir or f"/tmp/kernell_scratch_{self.session_id}"
        Path(self.scratchpad_dir).mkdir(parents=True, exist_ok=True)

        # Register atexit cleanup to prevent orphaned scratchpads
        import atexit
        import shutil as _shutil
        _sd = self.scratchpad_dir
        def _cleanup_scratchpad():
            try:
                if Path(_sd).exists():
                    _shutil.rmtree(_sd, ignore_errors=True)
            except Exception:
                pass
        atexit.register(_cleanup_scratchpad)

        logger.info(
            f"🎯 CoordinatorSession initialized: "
            f"coordinator={coordinator_name}, session={self.session_id}"
        )

    # ── Worker Lifecycle ─────────────────────────────────────────────────

    def spawn_worker(
        self,
        agent_name: str,
        prompt: str,
        mode: str = "read_only",
        phase: str = "research",
    ) -> str:
        """
        Spawn a worker agent with a task.

        Args:
            agent_name: Target agent (e.g., "forge", "hunter", "atlas")
            prompt: Self-contained task prompt (workers can't see coordinator context)
            mode: "read_only" (parallel safe) or "write_heavy" (must serialize)
            phase: "research" | "synthesis" | "implementation" | "verification"

        Returns:
            task_id: Unique identifier for the spawned worker

        Raises:
            ConcurrencyError: If attempting write_heavy while another write is active
        """
        concurrency = ConcurrencyMode(mode)
        wf_phase = WorkflowPhase(phase)

        # Concurrency guard: only one write_heavy at a time
        if concurrency == ConcurrencyMode.WRITE_HEAVY and self._active_write_tasks:
            active = list(self._active_write_tasks)
            logger.warning(
                f"⚠️  Write contention: {agent_name} blocked by active write tasks: {active}"
            )
            # Don't raise — queue the task but log the warning
            # This allows the coordinator to decide

        task_id = f"task_{agent_name}_{uuid.uuid4().hex[:8]}"

        worker = WorkerState(
            task_id=task_id,
            agent_name=agent_name,
            prompt=prompt,
            concurrency_mode=concurrency,
            phase=wf_phase,
            status=TaskStatus.RUNNING,
        )

        self._workers[task_id] = worker

        if concurrency == ConcurrencyMode.WRITE_HEAVY:
            self._active_write_tasks.add(task_id)

        # Publish task to Redis for the target agent to pick up
        if self._redis:
            task_payload = {
                "type": "coordinator_task",
                "task_id": task_id,
                "coordinator": self.coordinator_name,
                "session_id": self.session_id,
                "agent_name": agent_name,
                "prompt": prompt,
                "phase": wf_phase.value,
                "concurrency_mode": concurrency.value,
                "notification_channel": self._notification_channel,
                "scratchpad_dir": self.scratchpad_dir,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
            # Push to the agent's task queue
            self._redis.lpush(
                f"kernell:tasks:{agent_name}",
                json.dumps(task_payload),
            )
            # Also publish for real-time subscribers
            self._redis.publish(
                f"kernell:coordinator:events",
                json.dumps({"type": "worker_spawned", **task_payload}),
            )

        logger.info(
            f"🚀 Worker spawned: {task_id} → {agent_name} "
            f"(phase={wf_phase.value}, mode={concurrency.value})"
        )
        return task_id

    def send_message(self, task_id: str, message: str) -> bool:
        """
        Send a follow-up message to an existing worker.
        Use this to continue workers whose work is complete or to correct course.

        The coordinator MUST have synthesized the worker's notification before
        sending a follow-up.
        """
        worker = self._workers.get(task_id)
        if not worker:
            logger.error(f"❌ Unknown task: {task_id}")
            return False

        if not worker.synthesized and worker.notification is not None:
            logger.warning(
                f"⚠️  Synthesis required before sending follow-up to {task_id}. "
                f"Call synthesize({task_id}) first."
            )
            # Still allow — log warning but don't block

        worker.messages_sent += 1

        if self._redis:
            followup = {
                "type": "coordinator_followup",
                "task_id": task_id,
                "coordinator": self.coordinator_name,
                "session_id": self.session_id,
                "agent_name": worker.agent_name,
                "message": message,
                "message_number": worker.messages_sent,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
            self._redis.lpush(
                f"kernell:tasks:{worker.agent_name}",
                json.dumps(followup),
            )

        logger.info(f"📩 Message sent to {task_id} (#{worker.messages_sent})")
        return True

    def stop_worker(self, task_id: str, reason: str = "Coordinator stop") -> bool:
        """
        Stop a running worker.
        Use when approach is wrong or requirements changed.
        """
        worker = self._workers.get(task_id)
        if not worker:
            return False

        worker.status = TaskStatus.KILLED

        if task_id in self._active_write_tasks:
            self._active_write_tasks.discard(task_id)

        if self._redis:
            stop_cmd = {
                "type": "coordinator_stop",
                "task_id": task_id,
                "coordinator": self.coordinator_name,
                "reason": reason,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
            self._redis.publish(
                f"kernell:tasks:{worker.agent_name}:control",
                json.dumps(stop_cmd),
            )

        logger.info(f"🛑 Worker stopped: {task_id} ({reason})")
        return True

    def close(self):
        """End session and cleanup scratchpad."""
        try:
            import shutil
            if Path(self.scratchpad_dir).exists():
                shutil.rmtree(self.scratchpad_dir)
            logger.info(f"🧹 Cleaned up scratchpad: {self.scratchpad_dir}")
        except Exception as e:
            logger.error(f"Failed to cleanup scratchpad: {e}")

    def list_scratchpad(self) -> List[str]:
        """List current files in the scratchpad."""
        try:
            p = Path(self.scratchpad_dir)
            if p.exists():
                return [str(f.relative_to(p)) for f in p.rglob("*") if f.is_file()]
        except Exception:
            pass
        return []

    # ── Notification Handling ────────────────────────────────────────────

    def receive_notification(self, notification: TaskNotification):
        """
        Process a notification from a worker.
        Called when a worker publishes to the notification channel.
        """
        worker = self._workers.get(notification.task_id)
        if not worker:
            logger.warning(f"Notification for unknown task: {notification.task_id}")
            return

        worker.notification = notification
        worker.status = TaskStatus(notification.status)
        worker.synthesized = False  # Reset synthesis flag

        if notification.task_id in self._active_write_tasks:
            if notification.status in (TaskStatus.COMPLETED, TaskStatus.FAILED, TaskStatus.KILLED):
                self._active_write_tasks.discard(notification.task_id)

        # Persist to Redis
        if self._redis:
            self._redis.hset(
                f"{self.REDIS_PREFIX}{self.session_id}:results",
                notification.task_id,
                json.dumps(notification.to_dict()),
            )

        logger.info(
            f"📬 Notification received: {notification.task_id} → {notification.status} "
            f"({notification.summary[:80]})"
        )

    def collect_notifications(self, timeout: float = 30.0) -> List[TaskNotification]:
        """
        Collect pending notifications from Redis pub/sub.
        Blocks up to `timeout` seconds waiting for worker results.
        """
        if not self._redis:
            return []

        notifications = []

        # Check for stored results first
        stored = self._redis.hgetall(f"{self.REDIS_PREFIX}{self.session_id}:results")
        for task_id, raw in stored.items():
            try:
                key = task_id if isinstance(task_id, str) else task_id.decode()
                val = raw if isinstance(raw, str) else raw.decode()
                notif = TaskNotification.from_dict(json.loads(val))
                self.receive_notification(notif)
                notifications.append(notif)
            except Exception as e:
                logger.error(f"Failed to parse stored notification: {e}")

        return notifications

    # ── Synthesis (MANDATORY) ────────────────────────────────────────────

    def synthesize(self, task_id: str) -> Optional[TaskNotification]:
        """
        Mark a task's notification as synthesized.

        The coordinator MUST call this before sending follow-up work.
        This forces the coordinator to read and understand the worker's
        findings — preventing lazy delegation.

        Returns the notification for the coordinator to process.
        """
        worker = self._workers.get(task_id)
        if not worker:
            logger.error(f"❌ Cannot synthesize: unknown task {task_id}")
            return None

        if worker.notification is None:
            logger.warning(f"⚠️  No notification yet for {task_id}")
            return None

        worker.synthesized = True

        logger.info(
            f"🧠 Synthesized: {task_id} ({worker.agent_name}) — "
            f"status={worker.notification.status}"
        )

        return worker.notification

    def is_synthesized(self, task_id: str) -> bool:
        """Check if a task's results have been synthesized."""
        worker = self._workers.get(task_id)
        return worker.synthesized if worker else False

    # ── Status & Reporting ───────────────────────────────────────────────

    def get_active_workers(self) -> List[Dict]:
        """Return currently active (running) workers."""
        return [
            {
                "task_id": w.task_id,
                "agent": w.agent_name,
                "phase": w.phase.value,
                "mode": w.concurrency_mode.value,
                "elapsed_s": round(time.time() - w.spawned_at, 1),
                "messages_sent": w.messages_sent,
            }
            for w in self._workers.values()
            if w.status == TaskStatus.RUNNING
        ]

    def get_completed_workers(self) -> List[Dict]:
        """Return completed workers with their results."""
        return [
            {
                "task_id": w.task_id,
                "agent": w.agent_name,
                "status": w.status.value,
                "synthesized": w.synthesized,
                "summary": w.notification.summary if w.notification else "",
            }
            for w in self._workers.values()
            if w.status in (TaskStatus.COMPLETED, TaskStatus.FAILED)
        ]

    def get_status(self) -> Dict:
        """Full session status for dashboard."""
        uptime = time.time() - self._started_at
        return {
            "session_id": self.session_id,
            "coordinator": self.coordinator_name,
            "uptime_s": round(uptime, 1),
            "total_workers": len(self._workers),
            "active": len([w for w in self._workers.values() if w.status == TaskStatus.RUNNING]),
            "completed": len([w for w in self._workers.values() if w.status == TaskStatus.COMPLETED]),
            "failed": len([w for w in self._workers.values() if w.status == TaskStatus.FAILED]),
            "pending_synthesis": len([
                w for w in self._workers.values()
                if w.notification and not w.synthesized
            ]),
            "active_write_tasks": list(self._active_write_tasks),
            "workers": {
                tid: {
                    "agent": w.agent_name,
                    "status": w.status.value,
                    "phase": w.phase.value,
                    "mode": w.concurrency_mode.value,
                    "synthesized": w.synthesized,
                }
                for tid, w in self._workers.items()
            },
        }

    # ── Coordinator System Prompt ────────────────────────────────────────

    def get_coordinator_prompt(self) -> str:
        """
        Generate the coordinator system prompt section.
        Injects active session state into the orchestrator's context.
        """
        active = self.get_active_workers()
        completed = self.get_completed_workers()
        pending_synthesis = [
            w for w in self._workers.values()
            if w.notification and not w.synthesized
        ]

        lines = [
            "## Coordinator Mode — Active Session",
            "",
            f"Session: {self.session_id}",
            f"Active workers: {len(active)}",
            f"Completed: {len(completed)}",
            f"Pending synthesis: {len(pending_synthesis)}",
            "",
        ]

        if pending_synthesis:
            lines.append("### ⚠️ Pending Synthesis (MUST process before delegating)")
            for w in pending_synthesis:
                lines.append(f"- **{w.task_id}** ({w.agent_name}): {w.notification.summary[:100]}")
            lines.append("")

        if active:
            lines.append("### Active Workers")
            for a in active:
                lines.append(
                    f"- **{a['task_id']}** → {a['agent']} "
                    f"(phase={a['phase']}, mode={a['mode']}, {a['elapsed_s']}s)"
                )
            lines.append("")

        lines.extend([
            "### Rules",
            "1. **Synthesize before delegating** — read worker findings, craft specific follow-ups",
            "2. **Parallel reads, serial writes** — read_only tasks can overlap; write_heavy must be one at a time",
            "3. **Self-contained prompts** — workers can't see your conversation; include file paths, line numbers",
            "4. **Never thank workers** — their results are internal signals, not conversation partners",
        ])

        return "\n".join(lines)


# ── Worker Helper (for agents receiving coordinator tasks) ───────────────────

def publish_task_notification(
    redis_client,
    notification_channel: str,
    task_id: str,
    agent_name: str,
    status: str,
    summary: str,
    result: str = "",
    error: str = "",
    files_modified: List[str] = None,
    usage: Dict = None,
):
    """
    Helper for worker agents to publish their results back to the coordinator.

    Usage in any agent:
        from core.coordinator_bridge import publish_task_notification

        publish_task_notification(
            redis_client=r,
            notification_channel="kernell:coordinator:coord_abc123:notifications",
            task_id="task_forge_xyz",
            agent_name="forge",
            status="completed",
            summary="Fixed null pointer in auth/validate.ts:42",
            result="Applied patch: added null check before user.id access...",
            files_modified=["src/auth/validate.ts"],
        )
    """
    notif = TaskNotification(
        task_id=task_id,
        agent_name=agent_name,
        status=status,
        summary=summary,
        result=result,
        error=error,
        files_modified=files_modified or [],
        usage=TaskUsage(**(usage or {})),
    )

    if redis_client:
        # Store result
        redis_client.hset(
            notification_channel.replace(":notifications", ":results"),
            task_id,
            json.dumps(notif.to_dict()),
        )
        # Publish for real-time consumption
        redis_client.publish(
            notification_channel,
            json.dumps(notif.to_dict()),
        )
        # Also publish to global event stream
        redis_client.publish(
            "kernell:coordinator:events",
            json.dumps({"type": "task_notification", **notif.to_dict()}),
        )

    return notif


# ── CLI ──────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="🎯 Coordinator Bridge — Kernell OS")
    parser.add_argument("--demo", action="store_true", help="Run demo session")
    parser.add_argument("--status", action="store_true", help="Show active sessions")
    args = parser.parse_args()

    if args.demo:
        print("=" * 60)
        print("  COORDINATOR BRIDGE — Demo Session")
        print("=" * 60)

        session = CoordinatorSession("kernell")

        # Phase 1: Research (parallel)
        print("\n🔬 Phase 1: Research (parallel)")
        t1 = session.spawn_worker("forge", "Investigate the auth module...", mode="read_only", phase="research")
        t2 = session.spawn_worker("hunter", "Find similar patterns in codebase...", mode="read_only", phase="research")
        print(f"  Spawned: {t1}, {t2}")

        # Simulate notifications
        n1 = TaskNotification(
            task_id=t1, agent_name="forge", status="completed",
            summary="Found null pointer in auth/validate.ts:42",
            result="The user field on Session is undefined when expired...",
            usage=TaskUsage(total_tokens=5000, tool_uses=8, duration_ms=12000),
        )
        n2 = TaskNotification(
            task_id=t2, agent_name="hunter", status="completed",
            summary="Found 3 similar patterns in src/",
            result="Similar null checks exist in session.ts, token.ts, refresh.ts",
        )

        session.receive_notification(n1)
        session.receive_notification(n2)

        # Phase 2: Synthesis (MANDATORY)
        print("\n🧠 Phase 2: Synthesis")
        s1 = session.synthesize(t1)
        s2 = session.synthesize(t2)
        print(f"  Synthesized {t1}: {s1.summary}")
        print(f"  Synthesized {t2}: {s2.summary}")

        # Phase 3: Implementation (serial — write_heavy)
        print("\n🔧 Phase 3: Implementation (serial)")
        t3 = session.spawn_worker(
            "forge",
            "Fix null pointer in auth/validate.ts:42. Add null check before user.id...",
            mode="write_heavy", phase="implementation"
        )
        print(f"  Spawned: {t3}")

        # XML format demo
        print(f"\n📝 XML notification format:")
        print(n1.to_xml())

        # Status
        print(f"\n📊 Session Status:")
        status = session.get_status()
        print(json.dumps(status, indent=2))

        # Coordinator prompt
        print(f"\n📋 Coordinator System Prompt:")
        print(session.get_coordinator_prompt())

        print(f"\n{'=' * 60}")
        print("  DEMO COMPLETE ✅")
        print(f"{'=' * 60}")
    else:
        parser.print_help()
