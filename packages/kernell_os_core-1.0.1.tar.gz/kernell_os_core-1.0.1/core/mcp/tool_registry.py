"""
Kernell OS — Tool Registry v1.0
================================
Registro centralizado de herramientas del ecosistema.
Cada tool tiene: nombre, descripción, schema, auth, rate_limit.
Almacena en Redis + expone para MCP server.

Uso:
    registry = ToolRegistry(redis_client)
    registry.register(ToolDef(...))
    tools = registry.list_tools()
    result = registry.execute("redis_query", {"command": "PING"})
"""

import json
import os
import time
import logging
import hashlib
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

logger = logging.getLogger("TOOL_REGISTRY")

from core.policy import sanitize_caller
REDIS_KEY_REGISTRY = "kernell:tools:registry"
REDIS_KEY_USAGE    = "kernell:tools:usage"
REDIS_KEY_AUDIT    = "kernell:tools:audit"


@dataclass
class ToolDef:
    """Definición de una herramienta del ecosistema."""
    name: str
    description: str
    input_schema: dict = field(default_factory=dict)
    auth: str = "internal"          # "internal" | "api_key" | "mcp"
    rate_limit: int = 60            # por minuto
    allowed_agents: list = field(default_factory=lambda: ["all"])
    category: str = "general"       # "system" | "data" | "skill" | "agent"
    handler: Optional[str] = None   # module.path:function_name
    _callable: Optional[Callable] = field(default=None, repr=False)

    def to_dict(self):
        return {
            "name": self.name,
            "description": self.description,
            "input_schema": self.input_schema,
            "auth": self.auth,
            "rate_limit": self.rate_limit,
            "allowed_agents": self.allowed_agents,
            "category": self.category,
            "handler": self.handler,
        }


class ToolRegistry:
    """Registro central de herramientas con persistencia en Redis."""

    def __init__(self, redis_client=None):
        self._tools: dict[str, ToolDef] = {}
        self._handlers: dict[str, Callable] = {}
        self.redis = redis_client
        self._mcp_allowlist = self._load_csv_set("KERNELL_MCP_ALLOWED_TOOLS")
        self._mcp_denylist = self._load_csv_set("KERNELL_MCP_DENIED_TOOLS")
        self._rate_limit_window_sec = int(os.getenv("KERNELL_TOOL_RATE_WINDOW_SEC", "60"))
        self._audit_max_entries = int(os.getenv("KERNELL_TOOL_AUDIT_MAX", "500"))
        self._register_builtin_tools()

    @staticmethod
    def _load_csv_set(env_name: str) -> set[str]:
        raw = os.getenv(env_name, "")
        if not raw.strip():
            return set()
        return {p.strip() for p in raw.split(",") if p.strip()}

    @staticmethod
    def _sanitize_caller(caller: str) -> str:
        return sanitize_caller(caller)

    def _check_authorization(self, tool: ToolDef, caller: str) -> Optional[str]:
        # Strict MCP governance: denylist > allowlist
        if caller == "mcp":
            if tool.name in self._mcp_denylist:
                return f"Tool '{tool.name}' denied by KERNELL_MCP_DENIED_TOOLS"
            if self._mcp_allowlist and tool.name not in self._mcp_allowlist:
                return (
                    f"Tool '{tool.name}' not in KERNELL_MCP_ALLOWED_TOOLS "
                    "(fail-closed MCP policy)"
                )
        return None

    def _check_rate_limit(self, tool: ToolDef, caller: str) -> Optional[str]:
        if not self.redis:
            return None
        key = f"{REDIS_KEY_USAGE}:rl:{tool.name}:{self._sanitize_caller(caller)}"
        try:
            count = self.redis.incr(key)
            if count == 1:
                self.redis.expire(key, self._rate_limit_window_sec)
            if count > max(1, int(tool.rate_limit)):
                return (
                    f"Rate limit exceeded for '{tool.name}' by '{caller}' "
                    f"({count}/{tool.rate_limit} in {self._rate_limit_window_sec}s)"
                )
        except Exception:
            # Fail-open only on Redis telemetry failures to avoid breaking control plane
            return None
        return None

    def _append_audit(self, entry: dict) -> None:
        if not self.redis:
            return
        try:
            self.redis.rpush(REDIS_KEY_AUDIT, json.dumps(entry, default=str))
            self.redis.ltrim(REDIS_KEY_AUDIT, -self._audit_max_entries, -1)
        except Exception:
            pass

    @staticmethod
    def _args_fingerprint(arguments: dict) -> str:
        try:
            payload = json.dumps(arguments or {}, sort_keys=True, default=str)
        except Exception:
            payload = str(arguments)
        return hashlib.sha256(payload.encode("utf-8", errors="ignore")).hexdigest()[:16]

    # ── Built-in Tools ────────────────────────────────────────────────────────

    def _register_builtin_tools(self):
        """Registra las herramientas internas del ecosistema."""

        # 1. Redis Query
        self.register(ToolDef(
            name="redis_query",
            description="Execute a read-only Redis command (GET, HGETALL, KEYS, LRANGE, etc.)",
            input_schema={
                "type": "object",
                "properties": {
                    "command": {"type": "string", "description": "Redis command (e.g. GET, HGETALL)"},
                    "args": {"type": "array", "items": {"type": "string"}, "description": "Command arguments"},
                },
                "required": ["command"],
            },
            auth="api_key",
            category="data",
            rate_limit=120,
        ), handler=self._handle_redis_query)

        # 2. Agent Status
        self.register(ToolDef(
            name="agent_status",
            description="Get the current status and health of all Kernell OS agents",
            input_schema={
                "type": "object",
                "properties": {
                    "agent_name": {"type": "string", "description": "Specific agent name (optional, return all if omitted)"},
                },
            },
            auth="api_key",
            category="system",
        ), handler=self._handle_agent_status)

        # 3. Skill List
        self.register(ToolDef(
            name="skill_list",
            description="List all available skills in the Kernell OS ecosystem with quality scores",
            input_schema={"type": "object", "properties": {}},
            auth="mcp",
            category="skill",
        ), handler=self._handle_skill_list)

        # 4. Skill Run
        self.register(ToolDef(
            name="skill_run",
            description="Execute a specific skill by name with given arguments",
            input_schema={
                "type": "object",
                "properties": {
                    "skill_name": {"type": "string", "description": "Name of the skill to run"},
                    "args": {"type": "array", "items": {"type": "string"}, "description": "Arguments for the skill"},
                },
                "required": ["skill_name"],
            },
            auth="api_key",
            category="skill",
            rate_limit=30,
        ), handler=self._handle_skill_run)

        # 5. GSHI Check
        self.register(ToolDef(
            name="gshi_check",
            description="Get the Global System Health Index (GSHI v2) — system stability score",
            input_schema={"type": "object", "properties": {}},
            auth="mcp",
            category="system",
        ), handler=self._handle_gshi_check)

        # 6. DEFCON Status
        self.register(ToolDef(
            name="defcon_status",
            description="Get current DEFCON level and security posture",
            input_schema={"type": "object", "properties": {}},
            auth="mcp",
            category="system",
        ), handler=self._handle_defcon_status)

        # 7. Qdrant Search
        self.register(ToolDef(
            name="qdrant_search",
            description="Semantic search across Kernell OS knowledge base (Qdrant vector DB)",
            input_schema={
                "type": "object",
                "properties": {
                    "query": {"type": "string", "description": "Natural language search query"},
                    "collection": {"type": "string", "description": "Collection name (kernell_memory, kernell_knowledge, kernell_episodes)", "default": "kernell_memory"},
                    "limit": {"type": "integer", "description": "Max results", "default": 5},
                },
                "required": ["query"],
            },
            auth="api_key",
            category="data",
            rate_limit=30,
        ), handler=self._handle_qdrant_search)

        # 8. Skill Audit
        self.register(ToolDef(
            name="skill_audit",
            description="Get the quality audit report for all skills — scores, issues, recommendations",
            input_schema={"type": "object", "properties": {}},
            auth="mcp",
            category="skill",
        ), handler=self._handle_skill_audit)

        # KMP — Kernell Marketplace (catalog / quote / order as paying agent)
        self.register(ToolDef(
            name="kernell_marketplace_catalog",
            description="KMP: list services (capability, price KERN, provider agent, reputation)",
            input_schema={
                "type": "object",
                "properties": {
                    "filter": {"type": "string", "description": "Optional filter on capability or agent name"},
                },
            },
            auth="api_key",
            category="economy",
            rate_limit=60,
        ), handler=self._handle_kmp_catalog)
        self.register(ToolDef(
            name="kernell_marketplace_quote",
            description="KMP: quote a capability — price KERN, provider, online status (no payment)",
            input_schema={
                "type": "object",
                "properties": {
                    "capability": {"type": "string", "description": "Service capability id (e.g. deep_research)"},
                },
                "required": ["capability"],
            },
            auth="api_key",
            category="economy",
            rate_limit=120,
        ), handler=self._handle_kmp_quote)
        self.register(ToolDef(
            name="kernell_marketplace_order",
            description="KMP: buy a capability — pays from buyer_agent's KERN wallet; blocks until result or timeout",
            input_schema={
                "type": "object",
                "properties": {
                    "capability": {"type": "string"},
                    "buyer_agent": {"type": "string", "description": "Swarm agent id that pays (e.g. nemesis, atlas)"},
                    "params": {"type": "object", "description": "Provider-specific parameters"},
                    "max_price_kern": {"type": "number", "default": 1000000},
                },
                "required": ["capability", "buyer_agent"],
            },
            auth="api_key",
            category="economy",
            rate_limit=20,
        ), handler=self._handle_kmp_order)

        # ── MT5 Native Engine (Local — Wine + mt5linux RPyC) ──────────
        self._mt5_engine = None  # Lazy init

        _mt5_tools = [
            # ── Data Tools ──
            ("mt5_account_info",
             "Get MT5 account health: balance, equity, margin, leverage, profit (native local)",
             {"type": "object", "properties": {}, "required": []}),

            ("mt5_symbol_price",
             "Get real-time bid/ask/spread for any MT5 symbol (~0ms latency)",
             {"type": "object", "properties": {
                 "symbol": {"type": "string", "description": "MT5 symbol (e.g., EURUSD, XAUUSD)"}
             }, "required": ["symbol"]}),

            ("mt5_get_ticks",
             "Get raw tick data (microsecond resolution) for HFT analysis",
             {"type": "object", "properties": {
                 "symbol": {"type": "string", "description": "MT5 symbol"},
                 "count": {"type": "integer", "description": "Number of ticks (max 10000)", "default": 100}
             }, "required": ["symbol"]}),

            ("mt5_get_ohlcv",
             "Get OHLCV candles from MT5 for any timeframe (M1 to MN1)",
             {"type": "object", "properties": {
                 "symbol": {"type": "string", "description": "MT5 symbol"},
                 "timeframe": {"type": "string", "description": "M1/M5/M15/M30/H1/H4/D1/W1/MN1", "default": "M15"},
                 "count": {"type": "integer", "description": "Number of candles (max 10000)", "default": 100}
             }, "required": ["symbol"]}),

            ("mt5_get_dom",
             "Get Depth of Market (Level II order book) with bids/asks",
             {"type": "object", "properties": {
                 "symbol": {"type": "string", "description": "MT5 symbol"}
             }, "required": ["symbol"]}),

            ("mt5_symbol_info",
             "Get detailed symbol info: spread, swap, margin, contract size, trade mode",
             {"type": "object", "properties": {
                 "symbol": {"type": "string", "description": "MT5 symbol"}
             }, "required": ["symbol"]}),

            # ── Trading Tools ──
            ("mt5_market_order",
             "Execute a market order (buy/sell) on MT5",
             {"type": "object", "properties": {
                 "symbol": {"type": "string", "description": "MT5 symbol"},
                 "side": {"type": "string", "description": "'buy' or 'sell'"},
                 "volume": {"type": "number", "description": "Lot size (e.g., 0.01)"},
                 "sl": {"type": "number", "description": "Stop Loss price (0=none)", "default": 0},
                 "tp": {"type": "number", "description": "Take Profit price (0=none)", "default": 0}
             }, "required": ["symbol", "side", "volume"]}),

            ("mt5_pending_order",
             "Place a pending order (buy_limit, sell_limit, buy_stop, sell_stop)",
             {"type": "object", "properties": {
                 "symbol": {"type": "string", "description": "MT5 symbol"},
                 "order_type": {"type": "string", "description": "buy_limit/sell_limit/buy_stop/sell_stop"},
                 "price": {"type": "number", "description": "Trigger price"},
                 "volume": {"type": "number", "description": "Lot size"},
                 "sl": {"type": "number", "description": "Stop Loss price", "default": 0},
                 "tp": {"type": "number", "description": "Take Profit price", "default": 0}
             }, "required": ["symbol", "order_type", "price", "volume"]}),

            ("mt5_modify_position",
             "Modify SL/TP of an open MT5 position",
             {"type": "object", "properties": {
                 "ticket": {"type": "integer", "description": "Position ticket ID"},
                 "sl": {"type": "number", "description": "New Stop Loss price", "default": 0},
                 "tp": {"type": "number", "description": "New Take Profit price", "default": 0}
             }, "required": ["ticket"]}),

            ("mt5_close_position",
             "Close an open MT5 position by ticket",
             {"type": "object", "properties": {
                 "ticket": {"type": "integer", "description": "Position ticket ID to close"}
             }, "required": ["ticket"]}),

            # ── Position/Order Query Tools ──
            ("mt5_get_positions",
             "Get all open MT5 positions with real-time P&L, swap, commission",
             {"type": "object", "properties": {
                 "symbol": {"type": "string", "description": "Filter by symbol (optional)"}
             }, "required": []}),

            ("mt5_get_orders",
             "Get all pending MT5 orders",
             {"type": "object", "properties": {
                 "symbol": {"type": "string", "description": "Filter by symbol (optional)"}
             }, "required": []}),

            ("mt5_get_history",
             "Get trade history (closed deals) with P&L",
             {"type": "object", "properties": {
                 "days": {"type": "integer", "description": "Number of days to look back", "default": 30}
             }, "required": []}),
        ]

        for name, desc, schema in _mt5_tools:
            cat = "trading" if "order" in name or "close" in name or "modify" in name else "data"
            self.register(ToolDef(
                name=name,
                description=desc,
                input_schema=schema,
                auth="mcp",
                category=cat,
                rate_limit=60 if cat == "data" else 30,
                allowed_agents=["nemesis", "overseer", "all"],
            ), handler=self._handle_mt5_native)

    # ── Registration ──────────────────────────────────────────────────────────

    def register(self, tool: ToolDef, handler: Callable = None):
        """Registra una herramienta."""
        self._tools[tool.name] = tool
        if handler:
            self._handlers[tool.name] = handler
            tool._callable = handler
        # Persist to Redis
        if self.redis:
            try:
                self.redis.hset(REDIS_KEY_REGISTRY, tool.name, json.dumps(tool.to_dict()))
            except Exception:
                pass

    def list_tools(self) -> list[dict]:
        """Lista todas las herramientas registradas."""
        return [t.to_dict() for t in self._tools.values()]

    def get_tool(self, name: str) -> Optional[ToolDef]:
        return self._tools.get(name)

    async def execute(self, name: str, arguments: dict, caller: str = "unknown") -> Any:
        """Ejecuta una herramienta por nombre."""
        ts = time.time()
        tool = self._tools.get(name)
        if not tool:
            return {"error": f"Tool '{name}' not found"}

        handler = self._handlers.get(name)
        if not handler:
            return {"error": f"No handler for tool '{name}'"}

        auth_error = self._check_authorization(tool, caller)
        if auth_error:
            self._append_audit({
                "ts": ts,
                "tool": name,
                "caller": caller,
                "args_fp": self._args_fingerprint(arguments),
                "status": "denied",
                "reason": auth_error,
            })
            return {"error": auth_error}

        rl_error = self._check_rate_limit(tool, caller)
        if rl_error:
            self._append_audit({
                "ts": ts,
                "tool": name,
                "caller": caller,
                "args_fp": self._args_fingerprint(arguments),
                "status": "rate_limited",
                "reason": rl_error,
            })
            return {"error": rl_error}

        # Track usage
        if self.redis:
            try:
                self.redis.hincrby(REDIS_KEY_USAGE, name, 1)
                self.redis.hset(f"{REDIS_KEY_USAGE}:last", name,
                               json.dumps({"caller": caller, "ts": time.time()}))
            except Exception:
                pass

        try:
            import asyncio
            # Inject tool name for handlers that need it (e.g., MT5 remote proxy)
            if handler == self._handle_mt5_remote:
                arguments = {**arguments, "__tool_name__": name}
            if asyncio.iscoroutinefunction(handler):
                result = await handler(arguments)
            else:
                result = handler(arguments)
            self._append_audit({
                "ts": ts,
                "tool": name,
                "caller": caller,
                "args_fp": self._args_fingerprint(arguments),
                "status": "ok",
                "duration_ms": int((time.time() - ts) * 1000),
            })
            return result
        except Exception as e:
            logger.error(f"Tool {name} failed: {e}")
            self._append_audit({
                "ts": ts,
                "tool": name,
                "caller": caller,
                "args_fp": self._args_fingerprint(arguments),
                "status": "error",
                "reason": str(e),
                "duration_ms": int((time.time() - ts) * 1000),
            })
            return {"error": str(e)}

    # ── Built-in Handlers ─────────────────────────────────────────────────────

    def _handle_redis_query(self, args: dict) -> dict:
        """Execute read-only Redis commands."""
        if not self.redis:
            return {"error": "Redis not available"}
        cmd = args.get("command", "").upper()
        # Security: only read commands
        ALLOWED = {"GET", "HGETALL", "HGET", "KEYS", "LRANGE", "LLEN", "SCARD",
                    "SMEMBERS", "TTL", "TYPE", "EXISTS", "DBSIZE", "INFO", "PING"}
        if cmd not in ALLOWED:
            return {"error": f"Command '{cmd}' not allowed. Read-only: {sorted(ALLOWED)}"}
        try:
            cmd_args = args.get("args", [])
            if cmd == "KEYS" and (not cmd_args or str(cmd_args[0]).strip() in ("*", "")):
                return {"error": "Command 'KEYS *' is blocked. Use a scoped pattern."}
            result = self.redis.execute_command(cmd, *cmd_args)
            # Serialize result
            if isinstance(result, bytes):
                result = result.decode("utf-8", errors="replace")
            elif isinstance(result, dict):
                result = {k.decode() if isinstance(k, bytes) else k: v.decode() if isinstance(v, bytes) else v for k, v in result.items()}
            elif isinstance(result, list):
                result = [i.decode() if isinstance(i, bytes) else i for i in result]
            return {"result": result}
        except Exception as e:
            return {"error": str(e)}

    def _handle_agent_status(self, args: dict) -> dict:
        """Get agent status from Redis heartbeats."""
        if not self.redis:
            return {"error": "Redis not available"}
        try:
            agent_name = args.get("agent_name")
            if agent_name:
                status = self.redis.get(f"kernell:agent:{agent_name}:status")
                hb = self.redis.get(f"kernell:agent:{agent_name}:heartbeat")
                return {"agent": agent_name, "status": status, "heartbeat": hb}
            # All agents
            keys = self.redis.keys("kernell:agent:*:status")
            agents = {}
            for k in keys:
                name = k.split(":")[2] if isinstance(k, str) else k.decode().split(":")[2]
                agents[name] = {
                    "status": self.redis.get(k),
                    "heartbeat": self.redis.get(f"kernell:agent:{name}:heartbeat"),
                }
            return {"agents": agents, "count": len(agents)}
        except Exception as e:
            return {"error": str(e)}

    def _handle_skill_list(self, args: dict) -> dict:
        """List all skills from filesystem."""
        import pathlib
        skills_dir = pathlib.Path("/home/anny/kernell-os/.agent/skills")
        skills = []
        if skills_dir.exists():
            for d in sorted(skills_dir.iterdir()):
                if d.is_dir() and (d / "SKILL.md").exists():
                    # Read frontmatter
                    text = (d / "SKILL.md").read_text(errors="replace")
                    name = d.name
                    desc = ""
                    for line in text.split("\n"):
                        if line.strip().startswith("description:"):
                            desc = line.split(":", 1)[1].strip()
                            break
                    has_scripts = (d / "scripts").is_dir()
                    skills.append({"name": name, "description": desc, "has_scripts": has_scripts})
        return {"skills": skills, "count": len(skills)}

    def _handle_skill_run(self, args: dict) -> dict:
        """Execute a skill's main.py script."""
        import subprocess, pathlib
        skill_name = args.get("skill_name", "")
        skill_args = args.get("args", [])
        script = pathlib.Path(f"/home/anny/kernell-os/.agent/skills/{skill_name}/scripts/main.py")
        if not script.exists():
            return {"error": f"Skill '{skill_name}' script not found at {script}"}
        try:
            result = subprocess.run(
                ["/home/anny/kernell-os/.venv/bin/python3", str(script)] + skill_args,
                capture_output=True, text=True, timeout=30,
                cwd="/home/anny/kernell-os"
            )
            return {"stdout": result.stdout, "stderr": result.stderr, "returncode": result.returncode}
        except subprocess.TimeoutExpired:
            return {"error": "Skill execution timed out (30s)"}
        except Exception as e:
            return {"error": str(e)}

    def _handle_gshi_check(self, args: dict) -> dict:
        """Get GSHI v2 from Redis."""
        if not self.redis:
            return {"error": "Redis not available"}
        try:
            raw = self.redis.get("kernell:gshi:latest")
            if raw:
                return json.loads(raw) if isinstance(raw, str) else json.loads(raw.decode())
            return {"gshi": "not_available"}
        except Exception as e:
            return {"error": str(e)}

    def _handle_defcon_status(self, args: dict) -> dict:
        """Get DEFCON level."""
        if not self.redis:
            return {"error": "Redis not available"}
        try:
            level = self.redis.get("kernell:defcon:level")
            mode = self.redis.get("kernell:defcon:mode")
            return {"defcon_level": int(level) if level else 5, "mode": mode or "BALANCED"}
        except Exception as e:
            return {"error": str(e)}

    def _handle_qdrant_search(self, args: dict) -> dict:
        """Semantic search via embedding engine + Qdrant."""
        try:
            from agents.core.memory.embedding_engine import EmbeddingEngine
            from qdrant_client import QdrantClient
            query = args.get("query", "")
            collection = args.get("collection", "kernell_memory")
            limit = min(args.get("limit", 5), 20)

            engine = EmbeddingEngine()
            vector = engine.embed(query)
            client = QdrantClient(host="127.0.0.1", port=6333)
            results = client.search(
                collection_name=collection,
                query_vector=vector,
                limit=limit,
            )
            hits = []
            for r in results:
                hits.append({
                    "score": round(r.score, 4),
                    "payload": {k: v for k, v in (r.payload or {}).items()
                               if k in ("content", "source", "agent", "ts", "type")},
                })
            return {"query": query, "collection": collection, "hits": hits, "count": len(hits)}
        except Exception as e:
            return {"error": str(e)}

    def _get_mt5_engine(self):
        """Lazy-init MT5Engine singleton."""
        if self._mt5_engine is None:
            try:
                from agents.nemesis.mt5_engine import MT5Engine
                self._mt5_engine = MT5Engine()
                self._mt5_engine.connect()
                logger.info("🔧 MT5 Native Engine connected for MCP tools")
            except Exception as e:
                logger.warning(f"MT5 Engine init failed: {e}")
                return None
        return self._mt5_engine

    def _handle_mt5_native(self, args: dict) -> dict:
        """Route MT5 tool calls to native MT5Engine (local RPyC bridge)."""
        tool_name = args.pop("__tool_name__", None)
        if not tool_name:
            return {"error": "MT5 handler called without tool name"}

        engine = self._get_mt5_engine()
        if engine is None:
            return {
                "error": "MT5 Engine not available — is the RPyC server running? "
                         "Start with: wine python -m mt5linux",
                "hint": "Ensure Wine + MT5 Terminal are running on this machine"
            }

        try:
            # ── Data Tools ──
            if tool_name == "mt5_account_info":
                return engine.account_info()

            elif tool_name == "mt5_symbol_price":
                return engine.symbol_price(args["symbol"])

            elif tool_name == "mt5_get_ticks":
                return engine.get_ticks(
                    args["symbol"],
                    count=args.get("count", 100),
                )

            elif tool_name == "mt5_get_ohlcv":
                return engine.get_ohlcv(
                    args["symbol"],
                    timeframe=args.get("timeframe", "M15"),
                    count=args.get("count", 100),
                )

            elif tool_name == "mt5_get_dom":
                return engine.get_dom(args["symbol"])

            elif tool_name == "mt5_symbol_info":
                return engine.symbol_info(args["symbol"])

            # ── Trading Tools ──
            elif tool_name == "mt5_market_order":
                return engine.market_order(
                    symbol=args["symbol"],
                    side=args["side"],
                    volume=args["volume"],
                    sl=args.get("sl", 0.0),
                    tp=args.get("tp", 0.0),
                )

            elif tool_name == "mt5_pending_order":
                return engine.pending_order(
                    symbol=args["symbol"],
                    order_type=args["order_type"],
                    price=args["price"],
                    volume=args["volume"],
                    sl=args.get("sl", 0.0),
                    tp=args.get("tp", 0.0),
                )

            elif tool_name == "mt5_modify_position":
                return engine.modify_position(
                    ticket=args["ticket"],
                    sl=args.get("sl", 0.0),
                    tp=args.get("tp", 0.0),
                )

            elif tool_name == "mt5_close_position":
                return engine.close_position(ticket=args["ticket"])

            # ── Query Tools ──
            elif tool_name == "mt5_get_positions":
                return {
                    "positions": engine.get_positions(
                        symbol=args.get("symbol")
                    )
                }

            elif tool_name == "mt5_get_orders":
                return {
                    "orders": engine.get_orders(
                        symbol=args.get("symbol")
                    )
                }

            elif tool_name == "mt5_get_history":
                from datetime import datetime, timezone, timedelta
                days = args.get("days", 30)
                to_dt = datetime.now(timezone.utc)
                from_dt = to_dt - timedelta(days=days)
                return {
                    "deals": engine.get_history_deals(from_dt, to_dt)
                }

            else:
                return {"error": f"Unknown MT5 tool: {tool_name}"}

        except Exception as e:
            logger.error(f"MT5 tool {tool_name} failed: {e}")
            return {"error": f"MT5 {tool_name} failed: {str(e)}"}

    def _handle_skill_audit(self, args: dict) -> dict:
        """Get latest skill audit from Redis."""
        if self.redis:
            try:
                raw = self.redis.get("kernell:skillforge:audit")
                if raw:
                    return json.loads(raw) if isinstance(raw, str) else json.loads(raw.decode())
            except Exception:
                pass
        return {"audit": "not_available", "hint": "SkillForge agent may not have run yet"}

    def _handle_kmp_catalog(self, args: dict) -> dict:
        if not self.redis:
            return {"error": "Redis not available"}
        from agents.interface.marketplace_endpoint import _get_services

        services = _get_services(self.redis)
        filt = (args.get("filter") or "").strip().lower()
        if filt:
            services = [
                s
                for s in services
                if filt in (s.get("capability") or "").lower()
                or filt in (s.get("agent") or "").lower()
            ]
        return {"ok": True, "count": len(services), "services": services[:200], "token": "KERN"}

    def _handle_kmp_quote(self, args: dict) -> dict:
        cap = (args.get("capability") or "").strip()
        if not cap:
            return {"error": "capability is required"}
        if not self.redis:
            return {"error": "Redis not available"}
        from agents.finance.economy.marketplace_broker import MarketplaceBroker

        broker = MarketplaceBroker(self.redis, agent_name="economy")
        ok, data = broker.quote_capability(cap)
        if not ok:
            return {"ok": False, **data}
        return {"ok": True, **data}

    def _handle_kmp_order(self, args: dict) -> dict:
        import os

        cap = (args.get("capability") or "").strip()
        buyer = (args.get("buyer_agent") or "").strip()
        if not cap:
            return {"error": "capability is required"}
        if not buyer:
            return {
                "error": "buyer_agent is required",
                "hint": "Internal swarm agent id — pays from its KERN marketplace wallet",
            }
        if not self.redis:
            return {"error": "Redis not available"}
        from agents.finance.economy.marketplace_broker import MarketplaceBroker

        broker = MarketplaceBroker(self.redis, agent_name="economy")
        try:
            timeout = float(os.environ.get("KERNELL_MCP_KMP_ORDER_TIMEOUT_S", "45"))
        except ValueError:
            timeout = 45.0
        max_price = float(args.get("max_price_kern") or 1_000_000.0)
        params = args.get("params") if isinstance(args.get("params"), dict) else {}
        ok, result = broker.request_service(
            from_agent=buyer,
            capability=cap,
            params=params,
            max_price_ku=max_price,
            timeout=timeout,
        )
        return {"ok": ok, "buyer_agent": buyer, "result": result}

