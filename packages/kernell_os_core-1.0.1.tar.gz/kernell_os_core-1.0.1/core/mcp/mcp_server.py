"""
Kernell OS — MCP Server v1.0
================================
Expone las herramientas del ecosistema como endpoints MCP-compatible.
Se monta como subruta en Herald (FastAPI) en /mcp/.

Endpoints:
  POST /mcp/tools/list        → Lista de tools con schemas
  POST /mcp/tools/call        → Ejecutar una tool
  GET  /mcp/resources/list    → Lista de resources (ontología, health, etc.)
  GET  /mcp/resources/read    → Leer un resource
  GET  /mcp/health            → Health check del MCP server

Auth: Bearer token (misma API key del vault) o query param ?token=...
"""

import json
import os
import time
import logging
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, HTTPException, Depends, Request
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel

from core.mcp.tool_registry import ToolRegistry

logger = logging.getLogger("MCP_SERVER")

# ── Auth ──────────────────────────────────────────────────────────────────────

_MCP_TOKEN = os.getenv("MCP_TOKEN") or os.getenv("HERALD_API_TOKEN") or os.getenv("API_TOKEN", "")
_ALLOW_NO_TOKEN = os.getenv("KERNELL_MCP_ALLOW_NO_TOKEN", "0") == "1"
_security = HTTPBearer(auto_error=False)


def _verify_token(
    request: Request,
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(_security),
):
    """Verifica token por Bearer header o query param."""
    if not _MCP_TOKEN:
        if _ALLOW_NO_TOKEN:
            return True
        raise HTTPException(
            status_code=503,
            detail="MCP token not configured. Set MCP_TOKEN or KERNELL_MCP_ALLOW_NO_TOKEN=1 for dev."
        )

    token = None
    if credentials:
        token = credentials.credentials
    else:
        token = request.query_params.get("token")

    if not token or token != _MCP_TOKEN:
        raise HTTPException(status_code=401, detail="Invalid or missing MCP token")
    return True


# ── Models ────────────────────────────────────────────────────────────────────

class ToolCallRequest(BaseModel):
    name: str
    arguments: dict = {}


class ToolCallResponse(BaseModel):
    content: list
    isError: bool = False


# ── Router ────────────────────────────────────────────────────────────────────

router = APIRouter(prefix="/mcp", tags=["MCP Tools"])

# Singleton registry — initialized lazily with Redis
_registry: Optional[ToolRegistry] = None


def get_registry() -> ToolRegistry:
    global _registry
    if _registry is None:
        try:
            from agents.core.config import get_redis_client
            redis = get_redis_client()
        except Exception:
            redis = None
        _registry = ToolRegistry(redis_client=redis)
        logger.info(f"🔧 MCP ToolRegistry initialized: {len(_registry.list_tools())} tools")
    return _registry


# ── Endpoints ─────────────────────────────────────────────────────────────────

@router.get("/health")
def mcp_health():
    """MCP server health check."""
    reg = get_registry()
    return {
        "status": "ok",
        "protocol": "mcp",
        "version": "1.0",
        "tools_count": len(reg.list_tools()),
        "ts": time.time(),
    }


@router.post("/tools/list")
def mcp_tools_list(_auth: bool = Depends(_verify_token)):
    """List all available tools with their input schemas (MCP compatible)."""
    reg = get_registry()
    tools = []
    for t in reg.list_tools():
        tools.append({
            "name": t["name"],
            "description": t["description"],
            "inputSchema": t.get("input_schema", {}),
        })
    return {"tools": tools}


@router.get("/tools/audit")
def mcp_tools_audit(limit: int = 50, _auth: bool = Depends(_verify_token)):
    """Return recent tool audit entries (sanitized, newest first)."""
    reg = get_registry()
    if not getattr(reg, "redis", None):
        return {"entries": [], "count": 0, "note": "Redis unavailable"}

    safe_limit = max(1, min(limit, 200))
    try:
        raw = reg.redis.lrange("kernell:tools:audit", -safe_limit, -1)
        entries = []
        for row in reversed(raw):
            if isinstance(row, bytes):
                row = row.decode("utf-8", errors="replace")
            try:
                entries.append(json.loads(row))
            except Exception:
                entries.append({"raw": str(row)})
        return {"entries": entries, "count": len(entries)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/tools/call")
async def mcp_tools_call(
    req: ToolCallRequest,
    request: Request,
    _auth: bool = Depends(_verify_token),
):
    """Execute a tool by name with given arguments (MCP compatible)."""
    reg = get_registry()
    tool = reg.get_tool(req.name)
    if not tool:
        raise HTTPException(status_code=404, detail=f"Tool '{req.name}' not found")

    caller = request.headers.get("x-kernell-caller", "mcp")
    result = await reg.execute(req.name, req.arguments, caller=caller)

    is_error = isinstance(result, dict) and "error" in result
    content_text = json.dumps(result, ensure_ascii=False, default=str)

    return {
        "content": [{"type": "text", "text": content_text}],
        "isError": is_error,
    }


# ── Resources ─────────────────────────────────────────────────────────────────

RESOURCES = {
    "kernell://ontology": {
        "uri": "kernell://ontology",
        "name": "System Ontology",
        "description": "Complete system architecture and agent definitions",
        "mimeType": "text/markdown",
        "path": "/home/anny/kernell-os/core/config/ontology.md",
    },
    "kernell://config": {
        "uri": "kernell://config",
        "name": "System Configuration",
        "description": "Active system.config.json",
        "mimeType": "application/json",
        "path": "/home/anny/kernell-os/core/config/system.config.json",
    },
    "kernell://skills-registry": {
        "uri": "kernell://skills-registry",
        "name": "Skills Registry",
        "description": "All available skills and their descriptions",
        "mimeType": "text/markdown",
        "path": "/home/anny/kernell-os/.agent/skills/REGISTRY.md",
    },
    "kernell://mt5-native": {
        "uri": "kernell://mt5-native",
        "name": "MT5 Native Engine",
        "description": "Native MetaTrader 5 integration via mt5linux RPyC (local Wine bridge)",
        "mimeType": "text/markdown",
        "path": "/home/anny/kernell-os/agents/nemesis/mt5_engine.py",
    },
    "kernell://kmp-overview": {
        "uri": "kernell://kmp-overview",
        "name": "Kernell Marketplace Protocol (KMP)",
        "description": "Settlement layer: KERN, escrow, tasks, audit trail",
        "mimeType": "text/markdown",
        "path": "/home/anny/kernell-os/docs/KMP_OVERVIEW.md",
    },
}


@router.get("/resources/list")
def mcp_resources_list(_auth: bool = Depends(_verify_token)):
    """List all available resources."""
    resources = []
    for uri, meta in RESOURCES.items():
        resources.append({
            "uri": meta["uri"],
            "name": meta["name"],
            "description": meta["description"],
            "mimeType": meta["mimeType"],
        })
    return {"resources": resources}


@router.get("/resources/read")
def mcp_resources_read(uri: str, _auth: bool = Depends(_verify_token)):
    """Read a specific resource by URI."""
    meta = RESOURCES.get(uri)
    if not meta:
        raise HTTPException(status_code=404, detail=f"Resource '{uri}' not found")

    path = Path(meta["path"])
    if not path.exists():
        raise HTTPException(status_code=404, detail=f"Resource file not found: {path}")

    try:
        content = path.read_text(encoding="utf-8", errors="replace")
        # Limit to 100KB
        if len(content) > 100_000:
            content = content[:100_000] + "\n\n... (truncated)"
        return {
            "contents": [{
                "uri": uri,
                "mimeType": meta["mimeType"],
                "text": content,
            }]
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
