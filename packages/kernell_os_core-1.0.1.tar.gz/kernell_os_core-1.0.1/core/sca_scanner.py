"""
SCA: pip-audit sobre requirements.txt del repo y entorno actual.

Chronos: task_type=sca_audit ejecuta run_sca_task inline (ver monitor_agent).
"""

from __future__ import annotations

import json
import logging
import subprocess
import sys
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Callable, Optional

logger = logging.getLogger("kernell.sca")

PROJECT_ROOT = Path(__file__).resolve().parents[1]

SEVERITY_SCORE = {
    "CRITICAL": 4,
    "HIGH": 3,
    "MODERATE": 2,
    "LOW": 1,
    "UNKNOWN": 0,
}


@dataclass
class Vulnerability:
    package: str
    installed_version: str
    vuln_id: str
    severity: str
    description: str
    fix_version: Optional[str] = None
    aliases: list[str] = field(default_factory=list)

    @property
    def score(self) -> int:
        return SEVERITY_SCORE.get(self.severity.upper(), 0)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class SCAScanner:
    def __init__(
        self,
        redis_client: Any = None,
        telegram_fn: Optional[Callable[[str], None]] = None,
    ) -> None:
        self.redis = redis_client
        self.notify = telegram_fn
        self._ensure_pip_audit()

    def _ensure_pip_audit(self) -> None:
        try:
            subprocess.run(
                [sys.executable, "-m", "pip_audit", "--version"],
                capture_output=True,
                check=True,
                timeout=30,
            )
        except (subprocess.CalledProcessError, FileNotFoundError, subprocess.TimeoutExpired):
            logger.info("Installing pip-audit…")
            subprocess.run(
                [sys.executable, "-m", "pip", "install", "pip-audit", "-q"],
                check=True,
                timeout=120,
            )

    def _collect_requirements(self) -> list[Path]:
        files: list[Path] = []
        for req in PROJECT_ROOT.rglob("requirements.txt"):
            if any(
                p.startswith("_") or p == "node_modules" or p == ".venv"
                for p in req.parts
            ):
                continue
            try:
                if req.stat().st_size > 0:
                    files.append(req)
            except OSError:
                continue
        return files

    def _run_pip_audit(self, req_file: Path) -> list[Vulnerability]:
        vulns: list[Vulnerability] = []
        try:
            result = subprocess.run(
                [
                    sys.executable,
                    "-m",
                    "pip_audit",
                    "-r",
                    str(req_file),
                    "--format",
                    "json",
                    "--progress-spinner",
                    "off",
                    "--skip-editable",
                ],
                capture_output=True,
                text=True,
                timeout=120,
            )
            output = result.stdout.strip()
            if not output:
                return []
            data = json.loads(output)
            for dep in data.get("dependencies", []):
                for vuln in dep.get("vulns", []):
                    fix_versions = vuln.get("fix_versions") or []
                    fix = fix_versions[0] if fix_versions else None
                    vulns.append(
                        Vulnerability(
                            package=dep["name"],
                            installed_version=dep["version"],
                            vuln_id=vuln["id"],
                            severity=vuln.get("severity", "UNKNOWN"),
                            description=(vuln.get("description") or "")[:200],
                            fix_version=fix,
                            aliases=list(vuln.get("aliases") or []),
                        )
                    )
        except subprocess.TimeoutExpired:
            logger.warning("pip-audit timeout: %s", req_file)
        except json.JSONDecodeError as e:
            logger.error("pip-audit JSON: %s", e)
        except Exception as e:
            logger.error("pip-audit error %s: %s", req_file, e)
        return vulns

    def _scan_installed(self) -> list[Vulnerability]:
        vulns: list[Vulnerability] = []
        try:
            result = subprocess.run(
                [
                    sys.executable,
                    "-m",
                    "pip_audit",
                    "--format",
                    "json",
                    "--progress-spinner",
                    "off",
                ],
                capture_output=True,
                text=True,
                timeout=180,
            )
            output = result.stdout.strip()
            if not output:
                return []
            data = json.loads(output)
            for dep in data.get("dependencies", []):
                for vuln in dep.get("vulns", []):
                    fv = vuln.get("fix_versions") or [None]
                    fix = fv[0]
                    vulns.append(
                        Vulnerability(
                            package=dep["name"],
                            installed_version=dep["version"],
                            vuln_id=vuln["id"],
                            severity=vuln.get("severity", "UNKNOWN"),
                            description=(vuln.get("description") or "")[:200],
                            fix_version=fix,
                        )
                    )
        except Exception as e:
            logger.error("scan_installed: %s", e)
        return vulns

    def run(self) -> dict[str, Any]:
        started = time.time()
        req_files = self._collect_requirements()
        all_vulns: list[Vulnerability] = []
        all_vulns.extend(self._scan_installed())
        for req in req_files:
            all_vulns.extend(self._run_pip_audit(req))

        seen: set[tuple[str, str]] = set()
        unique: list[Vulnerability] = []
        for v in all_vulns:
            key = (v.package, v.vuln_id)
            if key not in seen:
                seen.add(key)
                unique.append(v)
        unique.sort(key=lambda x: x.score, reverse=True)

        stats = {s: 0 for s in SEVERITY_SCORE}
        for v in unique:
            sev = v.severity.upper()
            if sev in stats:
                stats[sev] += 1
            else:
                stats["UNKNOWN"] += 1

        report: dict[str, Any] = {
            "ts": time.time(),
            "duration_s": round(time.time() - started, 2),
            "total_vulns": len(unique),
            "stats": stats,
            "req_files_scanned": len(req_files),
            "vulnerabilities": [v.to_dict() for v in unique[:50]],
            "status": "clean"
            if len(unique) == 0
            else (
                "critical"
                if stats.get("CRITICAL", 0) > 0
                else "warning"
                if stats.get("HIGH", 0) > 0
                else "info"
            ),
        }

        self._publish(report)
        self._alert_if_needed(report, unique)
        logger.info(
            "SCA done: %d vulns [C:%d H:%d]",
            len(unique),
            stats["CRITICAL"],
            stats["HIGH"],
        )
        return report

    def _publish(self, report: dict[str, Any]) -> None:
        if not self.redis:
            return
        try:
            self.redis.setex(
                "kernell:security:sca:latest", 90000, json.dumps(report)
            )
            self.redis.publish(
                "kernell:events:security",
                json.dumps(
                    {
                        "type": "sca_scan_complete",
                        "status": report["status"],
                        "total_vulns": report["total_vulns"],
                        "ts": report["ts"],
                    }
                ),
            )
        except Exception as e:
            logger.error("Redis publish: %s", e)

    def _alert_if_needed(self, report: dict[str, Any], vulns: list[Vulnerability]) -> None:
        if not self.notify:
            return
        critical = [v for v in vulns if v.score >= 3]
        if not critical:
            return
        lines = [f"SCA Alert — {len(critical)} critical/high\n"]
        for v in critical[:5]:
            fix_str = f" → fix: {v.fix_version}" if v.fix_version else ""
            lines.append(
                f"• {v.package}=={v.installed_version} [{v.severity}] {v.vuln_id}{fix_str}"
            )
        if len(critical) > 5:
            lines.append(f"… +{len(critical) - 5} more (kernell:security:sca:latest)")
        try:
            self.notify("\n".join(lines))
        except Exception as e:
            logger.error("notify: %s", e)


def run_sca_task(
    redis_client: Any = None,
    telegram_fn: Optional[Callable[[str], None]] = None,
) -> dict[str, Any]:
    return SCAScanner(redis_client=redis_client, telegram_fn=telegram_fn).run()


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    print(json.dumps(run_sca_task(), indent=2))
