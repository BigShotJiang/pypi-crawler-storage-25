"""
Kernell OS — Economic Invariants
════════════════════════════════
Enforces strict economic constraints during runtime execution.
Provides deterministic, math-backed validation of all transactions.
"""
from typing import Dict, Any

class EconomicInvariants:
    @staticmethod
    def validate_estimate(max_budget_micro: int) -> None:
        """Verifies initial budget is valid and non-exploitative."""
        if max_budget_micro <= 0:
            raise ValueError(f"Invalid budget: {max_budget_micro}. Must be strictly positive.")

    @staticmethod
    def validate_transaction(estimated_micro: int, actual_micro: int, reserved_micro: int, refunded_micro: int) -> None:
        """
        Enforce Kernell OS fundamental economic invariants.
        If any of these fail, the system is in a corrupted financial state.
        """
        if actual_micro < 0:
            raise ValueError(f"Economic Exploit Detected [Negative Cost]: actual_micro ({actual_micro}) cannot be negative.")
        
        if refunded_micro < 0:
            raise ValueError(f"Economic Exploit Detected [Negative Refund]: refunded_micro ({refunded_micro}) cannot be negative.")
        
        if actual_micro > reserved_micro:
            raise ValueError(f"Economic Exploit Detected [Overcapture]: captured ({actual_micro}) exceeds reserved ({reserved_micro}).")

        # Atomic math check: Captured + Refunded MUST perfectly equal Reserved.
        if (actual_micro + refunded_micro) != reserved_micro:
            raise ValueError(f"Ledger Inconsistency [Math Error]: actual ({actual_micro}) + refunded ({refunded_micro}) != reserved ({reserved_micro}).")
