#!/usr/bin/env python3
"""
core/security/tool_loop_guard.py
═════════════════════════════════
Tool Loop Detection & Prevention — Kernell OS

Detects and breaks infinite loops where an agent repeatedly invokes the
same tool with identical arguments (burning tokens without progress).

Detection patterns:
  1. Exact repeat: same (tool, hash(args)) ≥ N consecutive times
  2. Ping-pong: two tools alternating A→B→A→B ≥ N cycles
  3. Futile retry: same failing tool called N times within a time window

Actions:
  - Warn: Inject cognitive interruption message
  - Block: Refuse tool invocation and escalate to coordinator
  - Alert: Publish to Redis for dashboard visibility

Integration:
    from core.security.tool_loop_guard import ToolLoopGuard

    guard = ToolLoopGuard("forge")

    # Before each tool call:
    decision = guard.check(tool_name="bash", args={"command": "pip install xyz"})
    if decision.blocked:
        # Don't execute; send decision.message to agent instead
        pass
    elif decision.warning:
        # Execute but inject warning into next prompt
        pass

Sovereign Architecture — Blueprint XV
"""

import json
import time
import hashlib
import logging
from typing import Optional, Dict, List, Any, Tuple
from dataclasses import dataclass, field
from collections import deque

logger = logging.getLogger("ToolLoopGuard")


# ── Configuration ────────────────────────────────────────────────────────────

# Number of consecutive identical calls before warning
WARN_THRESHOLD = 3

# Number of consecutive identical calls before blocking
BLOCK_THRESHOLD = 5

# Ping-pong detection: minimum alternating cycles
PINGPONG_CYCLES = 3

# Time window for futile retry detection (seconds)
FUTILE_RETRY_WINDOW_S = 120

# Maximum history entries to keep per agent
MAX_HISTORY = 50

# Cooldown after a block (seconds) — prevents immediate re-attempts
BLOCK_COOLDOWN_S = 30


# ── Data Types ───────────────────────────────────────────────────────────────

@dataclass
class ToolInvocation:
    """Record of a single tool invocation."""
    tool_name: str
    args_hash: str
    timestamp: float
    succeeded: bool = True
    error: str = ""


@dataclass
class LoopDecision:
    """Result of a loop check."""
    allowed: bool = True
    warning: bool = False
    blocked: bool = False
    message: str = ""
    pattern: str = ""      # "exact_repeat" | "ping_pong" | "futile_retry"
    repeat_count: int = 0

    @property
    def requires_action(self) -> bool:
        return self.warning or self.blocked


@dataclass
class ToolGroupSummary:
    """Grouped summary of tool invocations for dashboard display."""
    tool_name: str
    count: int
    first_at: float
    last_at: float
    sample_args_hash: str
    all_failed: bool = False


# ── Tool Loop Guard ──────────────────────────────────────────────────────────

class ToolLoopGuard:
    """
    Per-agent tool loop detector and prevention system.

    Maintains a sliding window of recent tool invocations and detects
    repetitive patterns that indicate the agent is stuck.
    """

    def __init__(self, agent_name: str, redis_client=None):
        self.agent_name = agent_name
        self._redis = redis_client
        self._history: deque = deque(maxlen=MAX_HISTORY)
        self._block_until: float = 0
        self._total_warnings = 0
        self._total_blocks = 0

        logger.info(f"🔁 ToolLoopGuard initialized for [{agent_name}]")

    # ── Main API ─────────────────────────────────────────────────────────

    def check(
        self,
        tool_name: str,
        args: Any = None,
        is_retry_after_failure: bool = False,
    ) -> LoopDecision:
        """
        Check if this tool invocation looks like a loop.

        Call this BEFORE executing the tool. If the decision says blocked,
        do NOT execute and inject the decision.message into the agent's
        context instead.

        Args:
            tool_name: Name of the tool being invoked
            args: Tool arguments (will be hashed for comparison)
            is_retry_after_failure: If the previous invocation of this tool failed

        Returns:
            LoopDecision with allowed/warning/blocked flags
        """
        now = time.time()

        # Check cooldown
        if now < self._block_until:
            remaining = int(self._block_until - now)
            return LoopDecision(
                allowed=False,
                blocked=True,
                message=(
                    f"🛑 Tool execution blocked — cooldown active ({remaining}s remaining). "
                    f"Agent [{self.agent_name}] was blocked due to repetitive tool loops. "
                    "Try a fundamentally different approach."
                ),
                pattern="cooldown",
            )

        # Hash the arguments for comparison
        args_hash = self._hash_args(args)

        # Record this invocation
        invocation = ToolInvocation(
            tool_name=tool_name,
            args_hash=args_hash,
            timestamp=now,
        )

        # Check patterns BEFORE adding to history
        decision = self._detect_patterns(tool_name, args_hash, now)

        # Add to history
        self._history.append(invocation)

        # Take action
        if decision.blocked:
            self._total_blocks += 1
            self._block_until = now + BLOCK_COOLDOWN_S
            self._publish_alert(tool_name, decision)
            logger.warning(
                f"🛑 [{self.agent_name}] BLOCKED: {tool_name} — {decision.pattern} "
                f"(count={decision.repeat_count})"
            )
        elif decision.warning:
            self._total_warnings += 1
            logger.info(
                f"⚠️ [{self.agent_name}] WARNING: {tool_name} — {decision.pattern} "
                f"(count={decision.repeat_count})"
            )

        return decision

    def record_result(self, tool_name: str, succeeded: bool, error: str = ""):
        """
        Record the result of a tool execution.
        Call this AFTER execution to enable futile retry detection.
        """
        if self._history:
            last = self._history[-1]
            if last.tool_name == tool_name:
                last.succeeded = succeeded
                last.error = error

    def reset(self):
        """Reset the guard state (e.g., on new task assignment)."""
        self._history.clear()
        self._block_until = 0
        logger.info(f"🔄 [{self.agent_name}] ToolLoopGuard reset")

    # ── Pattern Detection ────────────────────────────────────────────────

    def _detect_patterns(
        self,
        tool_name: str,
        args_hash: str,
        now: float,
    ) -> LoopDecision:
        """Run all pattern detectors in order of specificity."""

        # Pattern 1: Exact repeat (same tool + same args, consecutively)
        exact = self._detect_exact_repeat(tool_name, args_hash)
        if exact is not None:
            return exact

        # Pattern 2: Ping-pong (A→B→A→B alternation)
        pingpong = self._detect_ping_pong()
        if pingpong is not None:
            return pingpong

        # Pattern 3: Futile retry (same tool failing repeatedly in time window)
        futile = self._detect_futile_retry(tool_name, now)
        if futile is not None:
            return futile

        return LoopDecision(allowed=True)

    def _detect_exact_repeat(
        self,
        tool_name: str,
        args_hash: str,
    ) -> Optional[LoopDecision]:
        """Detect N consecutive calls with same tool + same args."""
        if len(self._history) < WARN_THRESHOLD - 1:
            return None

        # Count consecutive matches from the end
        count = 0
        for inv in reversed(self._history):
            if inv.tool_name == tool_name and inv.args_hash == args_hash:
                count += 1
            else:
                break

        # +1 for the current (not yet appended) invocation
        count += 1

        if count >= BLOCK_THRESHOLD:
            return LoopDecision(
                allowed=False,
                blocked=True,
                message=(
                    f"🛑 LOOP DETECTED: You have called `{tool_name}` with identical "
                    f"arguments {count} times consecutively. This pattern burns tokens "
                    f"without progress. You MUST try a fundamentally different approach:\n"
                    f"  • Use a different tool\n"
                    f"  • Change your arguments significantly\n"
                    f"  • Ask the user for clarification\n"
                    f"  • Report that this approach is failing"
                ),
                pattern="exact_repeat",
                repeat_count=count,
            )

        if count >= WARN_THRESHOLD:
            return LoopDecision(
                allowed=True,
                warning=True,
                message=(
                    f"⚠️ REPETITION WARNING: You have called `{tool_name}` with the same "
                    f"arguments {count} times. If the approach isn't working, try something "
                    f"different. ({BLOCK_THRESHOLD - count} more repeats will trigger a block.)"
                ),
                pattern="exact_repeat",
                repeat_count=count,
            )

        return None

    def _detect_ping_pong(self) -> Optional[LoopDecision]:
        """Detect A→B→A→B alternating pattern."""
        if len(self._history) < PINGPONG_CYCLES * 2:
            return None

        # Get last N*2 entries
        recent = list(self._history)[-PINGPONG_CYCLES * 2:]
        tool_sequence = [inv.tool_name for inv in recent]

        # Check if it's a pure alternation
        if len(set(tool_sequence)) != 2:
            return None

        a, b = tool_sequence[0], tool_sequence[1]
        is_alternating = all(
            tool_sequence[i] == (a if i % 2 == 0 else b)
            for i in range(len(tool_sequence))
        )

        if is_alternating:
            cycles = len(tool_sequence) // 2
            if cycles >= PINGPONG_CYCLES:
                return LoopDecision(
                    allowed=True,
                    warning=True,
                    message=(
                        f"⚠️ PING-PONG DETECTED: You are alternating between `{a}` and `{b}` "
                        f"for {cycles} cycles. This usually indicates a stuck resolution "
                        f"strategy. Consider a different approach entirely."
                    ),
                    pattern="ping_pong",
                    repeat_count=cycles,
                )

        return None

    def _detect_futile_retry(
        self,
        tool_name: str,
        now: float,
    ) -> Optional[LoopDecision]:
        """Detect the same tool failing repeatedly within a time window."""
        if len(self._history) < WARN_THRESHOLD:
            return None

        # Count recent failures of this tool within the time window
        failure_count = 0
        for inv in reversed(self._history):
            if now - inv.timestamp > FUTILE_RETRY_WINDOW_S:
                break
            if inv.tool_name == tool_name and not inv.succeeded:
                failure_count += 1

        if failure_count >= BLOCK_THRESHOLD:
            return LoopDecision(
                allowed=False,
                blocked=True,
                message=(
                    f"🛑 FUTILE RETRY: `{tool_name}` has failed {failure_count} times "
                    f"in the last {FUTILE_RETRY_WINDOW_S}s. Stop retrying and report "
                    f"the failure to the coordinator."
                ),
                pattern="futile_retry",
                repeat_count=failure_count,
            )

        if failure_count >= WARN_THRESHOLD:
            return LoopDecision(
                allowed=True,
                warning=True,
                message=(
                    f"⚠️ FUTILE WARNING: `{tool_name}` has failed {failure_count} times "
                    f"recently. Consider whether this tool is the right approach."
                ),
                pattern="futile_retry",
                repeat_count=failure_count,
            )

        return None

    # ── Tool Grouping (for dashboard display) ────────────────────────────

    def get_grouped_summary(self) -> List[ToolGroupSummary]:
        """
        Group recent tool invocations by (tool_name, args_hash) for
        dashboard display. Inspired by groupToolUses.ts.
        """
        groups: Dict[str, ToolGroupSummary] = {}

        for inv in self._history:
            key = f"{inv.tool_name}:{inv.args_hash}"
            if key in groups:
                g = groups[key]
                g.count += 1
                g.last_at = inv.timestamp
                if inv.succeeded:
                    g.all_failed = False
            else:
                groups[key] = ToolGroupSummary(
                    tool_name=inv.tool_name,
                    count=1,
                    first_at=inv.timestamp,
                    last_at=inv.timestamp,
                    sample_args_hash=inv.args_hash,
                    all_failed=not inv.succeeded,
                )

        return sorted(groups.values(), key=lambda g: g.last_at, reverse=True)

    def get_cognitive_interruption(self) -> Optional[str]:
        """
        Generate a cognitive interruption message if any pattern is
        currently active. Inject this into the agent's system prompt.
        """
        if not self._history:
            return None

        # Check the last few entries for patterns
        recent = list(self._history)[-WARN_THRESHOLD:]
        if len(recent) < WARN_THRESHOLD:
            return None

        # All same tool+args?
        first = recent[0]
        all_same = all(
            inv.tool_name == first.tool_name and inv.args_hash == first.args_hash
            for inv in recent
        )

        if all_same:
            return (
                f"⚠️ COGNITIVE INTERRUPTION: You have repeated `{first.tool_name}` "
                f"{len(recent)} times with the same approach. Stop and reconsider. "
                f"What is fundamentally different about what you should try next?"
            )

        return None

    # ── Internal ─────────────────────────────────────────────────────────

    def _hash_args(self, args: Any) -> str:
        """Create a stable hash of tool arguments."""
        if args is None:
            return "none"
        try:
            if isinstance(args, dict):
                # Sort keys for stable hashing
                canonical = json.dumps(args, sort_keys=True, default=str)
            elif isinstance(args, str):
                canonical = args
            else:
                canonical = str(args)
            return hashlib.sha256(canonical.encode()).hexdigest()[:12]
        except Exception:
            return "unhashable"

    def _publish_alert(self, tool_name: str, decision: LoopDecision):
        """Publish loop alert to Redis."""
        if not self._redis:
            return
        try:
            event = json.dumps({
                "type": "tool_loop_guard:block",
                "agent": self.agent_name,
                "tool": tool_name,
                "pattern": decision.pattern,
                "repeat_count": decision.repeat_count,
                "timestamp": time.time(),
            })
            self._redis.publish("kernell:alerts:tool_loop", event)
            self._redis.lpush("kernell:security:tool_loops", event)
            self._redis.ltrim("kernell:security:tool_loops", 0, 99)
        except Exception:
            pass

    # ── Status ───────────────────────────────────────────────────────────

    def get_status(self) -> Dict[str, Any]:
        """Status for dashboard."""
        return {
            "agent": self.agent_name,
            "history_size": len(self._history),
            "total_warnings": self._total_warnings,
            "total_blocks": self._total_blocks,
            "cooldown_active": time.time() < self._block_until,
            "cooldown_remaining_s": max(0, int(self._block_until - time.time())),
            "groups": [
                {
                    "tool": g.tool_name,
                    "count": g.count,
                    "all_failed": g.all_failed,
                }
                for g in self.get_grouped_summary()[:10]
            ],
        }


# ── CLI ──────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print("=" * 60)
    print("  TOOL LOOP GUARD — Simulation")
    print("=" * 60)

    guard = ToolLoopGuard("forge")

    # Simulate an agent stuck in a loop
    print("\n📋 Simulating agent stuck installing a package...")

    for i in range(7):
        decision = guard.check(
            tool_name="bash",
            args={"command": "pip install nonexistent-package-xyz"},
        )
        # Simulate failure
        guard.record_result("bash", succeeded=False, error="No matching distribution")

        status = "✅" if decision.allowed else "🛑"
        extra = ""
        if decision.warning:
            extra = f" ⚠️ {decision.pattern}"
        if decision.blocked:
            extra = f" 🛑 BLOCKED ({decision.pattern})"

        print(f"  Call {i+1}: {status}{extra}")
        if decision.message:
            print(f"         → {decision.message[:80]}...")

    print(f"\n📊 Status: {json.dumps(guard.get_status(), indent=2)}")

    # Simulate ping-pong
    print("\n📋 Simulating ping-pong pattern...")
    guard2 = ToolLoopGuard("hunter")

    for i in range(8):
        tool = "bash" if i % 2 == 0 else "grep_search"
        decision = guard2.check(tool_name=tool, args={"query": "find the bug"})
        extra = f" ⚠️ {decision.pattern}" if decision.requires_action else ""
        print(f"  Call {i+1} ({tool}): {'✅' if decision.allowed else '🛑'}{extra}")

    print(f"\n{'=' * 60}")
