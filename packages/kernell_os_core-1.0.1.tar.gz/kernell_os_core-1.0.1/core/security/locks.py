import threading

_LOCKS = {}

def get_tenant_lock(tenant_id: str):
    if tenant_id not in _LOCKS:
        _LOCKS[tenant_id] = threading.Lock()
    return _LOCKS[tenant_id]
