"""
Kernell OS — Security Gate
══════════════════════════
Global security interception layer.
Prevents malformed, excessive, or malicious payloads from hitting the Core engines.
"""
from typing import Dict, Any

class SecurityGate:
    @staticmethod
    def check_payload(payload: Dict[str, Any]) -> None:
        """
        Validate incoming payload structure and limits before processing.
        """
        from core.security.events import record_security_event
        tenant_id = payload.get("tenant_id")
        
        # Input length limitation (Amplification attacks)
        task_input = payload.get("input", "")
        if len(task_input.encode("utf-8")) > 50_000:
            record_security_event(
                "INPUT_AMPLIFICATION",
                "Input too large (UTF-8 encoded size > 50k)",
                "HIGH",
                tenant_id
            )
            raise ValueError("Payload length exceeds maximum allowed limit (50,000 bytes).")
            
        if task_input.count(" ") < 5 and len(task_input) > 1000:
            record_security_event(
                "MALFORMED_PAYLOAD",
                "Input looks like garbage or attack (long string without spaces)",
                "MEDIUM",
                tenant_id
            )
            raise ValueError("Malformed payload detected.")
        
        # Valid task types
        task_type = payload.get("task_type", "simple")
        valid_types = ["simple", "multi_agent", "financial", "autonomous_loop", "stress", "general"]
        if task_type not in valid_types:
            raise ValueError(f"Invalid task type: {task_type}")

        # Basic budget bypass guard
        budget = payload.get("max_budget_micro", None)
        if budget is not None and budget <= 10:
            raise ValueError("Budget bypass attempt detected: max_budget_micro is suspiciously low.")
