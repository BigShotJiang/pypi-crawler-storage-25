import json
import time
import os

SECURITY_LOG = "data/security_events.jsonl"

def record_security_event(event_type, detail, severity, tenant_id=None):
    os.makedirs("data", exist_ok=True)
    event = {
        "type": event_type,
        "severity": severity,
        "detail": detail,
        "tenant_id": tenant_id,
        "timestamp": time.time(),
    }
    with open(SECURITY_LOG, "a") as f:
        f.write(json.dumps(event) + "\n")
