#!/usr/bin/env python3
"""
⚡ KERNELL OS — CIRCUIT BREAKER v1.0
======================================
Implementa el patrón Circuit Breaker para el sistema SALUS.
Si un agente o proceso falla 3 veces consecutivas → bloquea y escala a Telegram.

Estados del circuito:
  CLOSED   → Operación normal
  OPEN     → Bloqueado (demasiados fallos)
  HALF_OPEN → Probando recuperación

Uso desde código:
    from circuit_breaker import CircuitBreaker, CircuitBreakerRegistry

    cb = CircuitBreakerRegistry.get("forge:patch_apply")
    if cb.can_execute():
        try:
            result = apply_patch(...)
            cb.record_success()
        except Exception as e:
            cb.record_failure(str(e))
            if cb.state == "OPEN":
                # Circuit abierto — escala automáticamente a Telegram
                pass
    else:
        print("Circuit OPEN — acción bloqueada")

Uso como monitor standalone:
    python3 circuit_breaker.py --watch
    python3 circuit_breaker.py --status
    python3 circuit_breaker.py --reset forge:patch_apply
"""

import os
import json
import time
import hashlib
import argparse
from pathlib import Path
from datetime import datetime, timezone
from typing import Optional, Callable

# ── Configuración ────────────────────────────────────────────────────────────

DEFAULT_FAILURE_THRESHOLD = 3        # Fallos antes de OPEN
DEFAULT_SUCCESS_THRESHOLD = 2        # Éxitos en HALF_OPEN para CLOSED
DEFAULT_TIMEOUT_SECONDS   = 300      # 5 min en OPEN antes de intentar HALF_OPEN
REDIS_KEY_PREFIX          = "kernell:circuit_breaker:"
TELEGRAM_BOT_TOKEN        = os.getenv("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHAT_ID          = os.getenv("TELEGRAM_CHAT_ID", "")

# ── Notificación Telegram ────────────────────────────────────────────────────

def notify_telegram(message: str) -> bool:
    """Envía alerta directa a Telegram sin depender del agent Telegram Bridge."""
    if not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID:
        print(f"⚠️  [CircuitBreaker] Telegram no configurado. Mensaje: {message}")
        return False
    try:
        import urllib.request
        import urllib.parse
        payload = json.dumps({
            "chat_id": TELEGRAM_CHAT_ID,
            "text": message,
            "parse_mode": "HTML",
        }).encode()
        url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
        req = urllib.request.Request(url, data=payload,
                                     headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=5) as resp:
            return resp.status == 200
    except Exception as e:
        print(f"⚠️  [CircuitBreaker] Telegram error: {e}")
        return False


def notify_redis(r, event: dict):
    """Publica evento en Redis para que otros agentes reaccionen."""
    try:
        r.lpush("kernell:circuit_breaker:events", json.dumps(event))
        r.ltrim("kernell:circuit_breaker:events", 0, 199)
        r.publish("kernell:events", json.dumps(event))
    except Exception:
        pass

# ── Circuit Breaker Core ─────────────────────────────────────────────────────

class CircuitBreaker:
    """
    Circuit Breaker individual para un proceso/agente específico.
    Estado persiste en Redis para sobrevivir reinicios de LLM.
    """

    STATES = ("CLOSED", "OPEN", "HALF_OPEN")

    def __init__(
        self,
        name: str,
        failure_threshold: int = DEFAULT_FAILURE_THRESHOLD,
        success_threshold: int = DEFAULT_SUCCESS_THRESHOLD,
        timeout_seconds: int = DEFAULT_TIMEOUT_SECONDS,
        redis_client=None,
        on_open: Optional[Callable] = None,
    ):
        self.name              = name
        self.failure_threshold = failure_threshold
        self.success_threshold = success_threshold
        self.timeout_seconds   = timeout_seconds
        self._redis            = redis_client
        self._on_open          = on_open
        self._state_key        = f"{REDIS_KEY_PREFIX}{name}"

        # Cargar estado desde Redis o inicializar
        self._state = self._load_state()

    # ── Persistencia ──────────────────────────────────────────────────────

    def _load_state(self) -> dict:
        if self._redis:
            try:
                raw = self._redis.get(self._state_key)
                if raw:
                    return json.loads(raw)
            except Exception:
                pass

        return {
            "circuit":           "CLOSED",
            "failure_count":     0,
            "success_count":     0,
            "last_failure_at":   None,
            "last_success_at":   None,
            "opened_at":         None,
            "last_failure_reason": None,
            "total_failures":    0,
            "total_successes":   0,
            "trips":             0,         # Veces que se abrió el circuito
        }

    def _save_state(self):
        if self._redis:
            try:
                self._redis.set(
                    self._state_key,
                    json.dumps(self._state),
                    ex=86400  # 24h TTL
                )
            except Exception:
                pass

    # ── Propiedades ───────────────────────────────────────────────────────

    @property
    def state(self) -> str:
        # Si está OPEN, verificar si ya pasó el timeout (→ HALF_OPEN)
        if self._state["circuit"] == "OPEN":
            opened_at = self._state.get("opened_at")
            if opened_at:
                elapsed = time.time() - opened_at
                if elapsed >= self.timeout_seconds:
                    self._transition_to("HALF_OPEN")
        return self._state["circuit"]

    @property
    def failure_count(self) -> int:
        return self._state["failure_count"]

    @property
    def is_closed(self) -> bool:
        return self.state == "CLOSED"

    @property
    def is_open(self) -> bool:
        return self.state == "OPEN"

    # ── Transiciones ──────────────────────────────────────────────────────

    def _transition_to(self, new_state: str, reason: str = ""):
        old_state = self._state["circuit"]
        self._state["circuit"] = new_state
        now = time.time()

        if new_state == "OPEN":
            self._state["opened_at"] = now
            self._state["trips"] += 1
        elif new_state == "CLOSED":
            self._state["failure_count"] = 0
            self._state["success_count"] = 0
            self._state["opened_at"]     = None

        ts = datetime.now(timezone.utc).isoformat()
        print(f"⚡ [CircuitBreaker:{self.name}] {old_state} → {new_state} | {reason}")
        self._save_state()

        # Notificar en Redis
        if self._redis:
            event = {
                "type":       "circuit_breaker_transition",
                "circuit":    self.name,
                "from_state": old_state,
                "to_state":   new_state,
                "reason":     reason,
                "timestamp":  ts,
            }
            notify_redis(self._redis, event)

        # Si se ABRE: alerta Telegram + acción de escalado
        if new_state == "OPEN":
            self._escalate(reason)

    def _escalate(self, reason: str):
        """Escalada al Arquitecto via Telegram cuando el circuito se abre."""
        trips = self._state["trips"]
        count = self._state["failure_count"]
        ts    = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")

        message = (
            f"🔴 <b>CIRCUIT BREAKER ABIERTO</b>\n\n"
            f"📍 <b>Proceso:</b> <code>{self.name}</code>\n"
            f"🔁 <b>Fallos consecutivos:</b> {count}/{self.failure_threshold}\n"
            f"📊 <b>Total de trips:</b> {trips}\n"
            f"❌ <b>Último error:</b> {reason[:200] if reason else 'N/A'}\n"
            f"⏰ <b>Timestamp:</b> {ts}\n\n"
            f"⚠️ <b>Acción autónoma BLOQUEADA.</b>\n"
            f"🔑 Se requiere PIN o confirmación manual para desbloquear.\n\n"
            f"Comandos:\n"
            f"  <code>python3 circuit_breaker.py --reset {self.name}</code>\n"
            f"  <code>python3 circuit_breaker.py --status</code>"
        )

        notify_telegram(message)

        # Callback personalizado si fue provisto
        if self._on_open:
            try:
                self._on_open(self.name, reason)
            except Exception as e:
                print(f"⚠️  on_open callback error: {e}")

    # ── API pública ───────────────────────────────────────────────────────

    def can_execute(self) -> bool:
        """¿Puede ejecutarse la acción protegida?"""
        return self.state in ("CLOSED", "HALF_OPEN")

    def record_failure(self, reason: str = ""):
        """Registrar un fallo. Si supera el threshold → abrir circuito."""
        now = datetime.now(timezone.utc).isoformat()
        self._state["failure_count"]       += 1
        self._state["total_failures"]      += 1
        self._state["last_failure_at"]      = now
        self._state["last_failure_reason"]  = reason

        print(
            f"❌ [CircuitBreaker:{self.name}] Fallo #{self._state['failure_count']} "
            f"(threshold={self.failure_threshold}): {reason[:100]}"
        )

        if self._state["circuit"] == "HALF_OPEN":
            # En HALF_OPEN, cualquier fallo vuelve a OPEN
            self._transition_to("OPEN", reason)
        elif self._state["failure_count"] >= self.failure_threshold:
            self._transition_to("OPEN", reason)
        else:
            self._save_state()

    def record_success(self):
        """Registrar un éxito."""
        now = datetime.now(timezone.utc).isoformat()
        self._state["success_count"]  += 1
        self._state["total_successes"] += 1
        self._state["last_success_at"] = now

        if self._state["circuit"] == "HALF_OPEN":
            if self._state["success_count"] >= self.success_threshold:
                self._transition_to("CLOSED", "Recuperación exitosa")
        elif self._state["circuit"] == "CLOSED":
            # Reset contador de fallos en éxito
            if self._state["failure_count"] > 0:
                self._state["failure_count"] = 0

        self._save_state()

    def force_reset(self, reason: str = "Manual reset"):
        """Forzar reset a CLOSED (requiere PIN en producción)."""
        print(f"🔓 [CircuitBreaker:{self.name}] Reset forzado: {reason}")
        self._state["failure_count"] = 0
        self._state["success_count"] = 0
        self._state["circuit"]       = "CLOSED"
        self._state["opened_at"]     = None
        self._save_state()

        if self._redis:
            event = {
                "type":      "circuit_breaker_reset",
                "circuit":   self.name,
                "reason":    reason,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
            notify_redis(self._redis, event)

    def status(self) -> dict:
        """Retorna el estado actual del circuito."""
        return {
            "name":                  self.name,
            "state":                 self.state,
            "failure_count":         self._state["failure_count"],
            "failure_threshold":     self.failure_threshold,
            "total_failures":        self._state["total_failures"],
            "total_successes":       self._state["total_successes"],
            "trips":                 self._state["trips"],
            "last_failure_at":       self._state.get("last_failure_at"),
            "last_failure_reason":   self._state.get("last_failure_reason"),
            "opened_at":             self._state.get("opened_at"),
            "timeout_seconds":       self.timeout_seconds,
        }

# ── Registry ─────────────────────────────────────────────────────────────────

class CircuitBreakerRegistry:
    """Registro global de circuit breakers. Singleton."""

    _instance = None
    _breakers: dict[str, CircuitBreaker] = {}
    _redis = None

    @classmethod
    def initialize(cls, redis_client=None):
        cls._redis = redis_client

    @classmethod
    def get(
        cls,
        name: str,
        failure_threshold: int = DEFAULT_FAILURE_THRESHOLD,
        timeout_seconds:   int = DEFAULT_TIMEOUT_SECONDS,
        on_open: Optional[Callable] = None,
    ) -> CircuitBreaker:
        if name not in cls._breakers:
            cls._breakers[name] = CircuitBreaker(
                name=name,
                failure_threshold=failure_threshold,
                timeout_seconds=timeout_seconds,
                redis_client=cls._redis,
                on_open=on_open,
            )
        return cls._breakers[name]

    @classmethod
    def status_all(cls) -> dict:
        return {name: cb.status() for name, cb in cls._breakers.items()}

    @classmethod
    def load_from_redis(cls) -> list[str]:
        """Carga todos los circuit breakers persistidos en Redis."""
        if not cls._redis:
            return []
        loaded = []
        try:
            pattern = f"{REDIS_KEY_PREFIX}*"
            keys = cls._redis.keys(pattern)
            for key in keys:
                name = key.replace(REDIS_KEY_PREFIX, "")
                cls.get(name)  # Esto carga el estado desde Redis
                loaded.append(name)
        except Exception as e:
            print(f"⚠️  Error cargando circuitos desde Redis: {e}")
        return loaded

# ── Circuitos predefinidos de Kernell OS ────────────────────────────────────

# Lista de circuitos críticos que deben existir al arranque
KERNELL_CIRCUITS = {
    # Forge y mutaciones de código
    "forge:patch_apply":       {"failure_threshold": 3, "timeout_seconds": 600},
    "forge:code_generate":     {"failure_threshold": 5, "timeout_seconds": 300},
    "forge:deploy":            {"failure_threshold": 2, "timeout_seconds": 900},

    # SALUS auditoría
    "salus:dim1_integrity":    {"failure_threshold": 3, "timeout_seconds": 300},
    "salus:dim2_security":     {"failure_threshold": 2, "timeout_seconds": 600},
    "salus:full_audit":        {"failure_threshold": 3, "timeout_seconds": 1800},

    # Fixer
    "fixer:patch_apply":       {"failure_threshold": 3, "timeout_seconds": 600},
    "fixer:service_restart":   {"failure_threshold": 5, "timeout_seconds": 120},

    # Agentes económicos
    "economy:trade_execute":   {"failure_threshold": 2, "timeout_seconds": 1800},
    "economy:ads_publish":     {"failure_threshold": 3, "timeout_seconds": 600},

    # Infraestructura
    "infra:redis_write":       {"failure_threshold": 5, "timeout_seconds": 60},
    "infra:qdrant_write":      {"failure_threshold": 5, "timeout_seconds": 60},

    # Context Management (P0 — context window patterns)
    "compact:auto":            {"failure_threshold": 3, "timeout_seconds": 300},
    "compact:manual":          {"failure_threshold": 5, "timeout_seconds": 120},
    "tool_persist:write":      {"failure_threshold": 5, "timeout_seconds": 60},
}


def initialize_kernell_circuits(redis_client=None) -> dict[str, CircuitBreaker]:
    """Inicializa todos los circuitos predefinidos de Kernell OS."""
    CircuitBreakerRegistry.initialize(redis_client)
    circuits = {}
    for name, config in KERNELL_CIRCUITS.items():
        circuits[name] = CircuitBreakerRegistry.get(name, **config)
    return circuits

# ── CLI ───────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Kernell OS Circuit Breaker CLI")
    parser.add_argument("--status",  action="store_true",  help="Mostrar estado de todos los circuitos")
    parser.add_argument("--watch",   action="store_true",  help="Monitorear eventos en tiempo real")
    parser.add_argument("--reset",   metavar="NAME",       help="Forzar reset de un circuito")
    parser.add_argument("--reset-all", action="store_true", help="Reset de todos los circuitos")
    parser.add_argument("--test",    metavar="NAME",       help="Simular 3 fallos en un circuito")
    args = parser.parse_args()

    # Conectar Redis
    redis_client = None
    try:
        import redis as redis_lib
        password = os.getenv("REDIS_PASSWORD", "").strip().strip("\"'") or None
        redis_client = redis_lib.Redis(
            host="127.0.0.1", port=6379, password=password,
            decode_responses=True, socket_connect_timeout=2
        )
        redis_client.ping()
        print("✅ Redis conectado")
    except Exception as e:
        print(f"⚠️  Redis no disponible: {e}. Operando en modo local (sin persistencia).")

    circuits = initialize_kernell_circuits(redis_client)

    # Cargar circuitos adicionales desde Redis
    if redis_client:
        loaded = CircuitBreakerRegistry.load_from_redis()
        if loaded:
            print(f"📦 Cargados {len(loaded)} circuitos desde Redis")

    if args.status:
        print("\n" + "="*60)
        print("CIRCUIT BREAKER STATUS — KERNELL OS")
        print("="*60)
        for name, cb in sorted(circuits.items()):
            s = cb.status()
            icon = "🟢" if s["state"] == "CLOSED" else ("🔴" if s["state"] == "OPEN" else "🟡")
            print(f"{icon} {name:<35} {s['state']:<10} "
                  f"fails={s['failure_count']}/{s['failure_threshold']} "
                  f"trips={s['trips']}")

    elif args.reset:
        name = args.reset
        cb = CircuitBreakerRegistry.get(name)
        cb.force_reset("CLI manual reset")
        print(f"✅ Circuito '{name}' reseteado a CLOSED")

    elif args.reset_all:
        for name, cb in circuits.items():
            cb.force_reset("CLI reset-all")
        print(f"✅ {len(circuits)} circuitos reseteados")

    elif args.test:
        name = args.test
        cb = CircuitBreakerRegistry.get(name)
        print(f"\n🧪 Simulando 3 fallos en '{name}'...")
        for i in range(1, 4):
            print(f"  Fallo {i}...")
            cb.record_failure(f"Error simulado de prueba #{i}")
            time.sleep(0.5)
        print(f"\nEstado final: {cb.state}")

    elif args.watch:
        if not redis_client:
            print("❌ --watch requiere Redis")
            return

        print("\n📡 Monitoreando eventos de Circuit Breaker en Redis...")
        print("   Canal: kernell:events | Presiona Ctrl+C para salir\n")

        pubsub = redis_client.pubsub()
        pubsub.subscribe("kernell:events")

        try:
            for message in pubsub.listen():
                if message["type"] == "message":
                    try:
                        event = json.loads(message["data"])
                        if "circuit_breaker" in event.get("type", ""):
                            ts = event.get("timestamp", "?")[:19]
                            print(f"[{ts}] {event['type']}: {event.get('circuit', '?')} "
                                  f"→ {event.get('to_state', event.get('reason', ''))}")
                    except Exception:
                        pass
        except KeyboardInterrupt:
            print("\n👋 Monitor detenido")

    else:
        print("\n📊 Estado rápido:")
        open_circuits = [name for name, cb in circuits.items() if cb.is_open]
        closed_circuits = [name for name, cb in circuits.items() if cb.is_closed]
        print(f"  🟢 CLOSED: {len(closed_circuits)}")
        print(f"  🔴 OPEN:   {len(open_circuits)}")
        if open_circuits:
            print(f"\n⚠️  Circuitos abiertos (requieren atención):")
            for name in open_circuits:
                print(f"   - {name}")
        print("\nUsa --status para detalle completo | --help para más opciones")


if __name__ == "__main__":
    main()
