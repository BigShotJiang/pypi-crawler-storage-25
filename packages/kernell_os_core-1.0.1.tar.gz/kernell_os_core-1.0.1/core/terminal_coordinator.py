"""
Terminal Coordinator - CLI interface to Coordinator Bridge
Permite al Architect (humano/PID-1) inyectar tareas como "Coordinator" a agentes Worker.
"""

import sys
import argparse
import time
import json
from pathlib import Path
import logging

ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT))

from core.coordinator_bridge import CoordinatorSession
from agents.core.config import get_redis_client

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

def main():
    parser = argparse.ArgumentParser(description="Kernell OS Coordinator CLI")
    parser.add_argument("agent", help="Nombre del Agente trabajador (ej. forge, hunter)")
    parser.add_argument("prompt", help="El request o prompt de la tarea")
    parser.add_argument("--mode", default="read_only", choices=["read_only", "write"], help="Modo operativo")
    parser.add_argument("--timeout", type=int, default=30, help="Segundos a esperar la respuesta")

    args = parser.parse_args()

    r = get_redis_client()
    session = CoordinatorSession("architect", redis_client=r)
    
    print(f"🚀 Spawning worker [{args.agent}] en modo {args.mode}...")
    task_id = session.spawn_worker(
        agent_name=args.agent,
        prompt=args.prompt,
        mode=args.mode
    )
    print(f"📦 Tarea Creada: {task_id}")
    print(f"⏳ Esperando {args.timeout}s por findings de {args.agent}...")

    # Recolectar resultados bloqueando el proceso
    notifs = session.collect_notifications(timeout=args.timeout)
    found = [n for n in notifs if n.task_id == task_id]
    
    if not found:
        print(f"⚠️ Tiempo de espera agotado. El agente no respondio o sigue ejecutando.")
        print(f"💡 Revisa los logs de {args.agent} para confirmar la ejecucion.")
        sys.exit(1)

    result = found[0]
    print(f"\n✅ Resultado devuelto por {args.agent}:")
    print(f"Status: {result.status}")
    print(f"Findings/Context:\n{json.dumps(result.context, indent=2)}\n")
    
    print(f"🧠 Sintetizando memoria del coordinador...")
    synthesis = session.synthesize(task_id)
    print(f"Final Synthesis: {synthesis}")

if __name__ == "__main__":
    main()
