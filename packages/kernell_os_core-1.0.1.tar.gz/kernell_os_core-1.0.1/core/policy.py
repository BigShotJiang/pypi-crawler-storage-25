"""
Kernell OS — Central Policy Helpers
===================================
Small, dependency-free helpers to enforce per-action allowlists consistently
across FastAPI endpoints and MCP/tool callers.

Design goals:
- Fail-open by default for backwards compatibility (no env configured => allow).
- Fail-closed when allowlist is explicitly provided for an action.
- Keep caller IDs simple and auditable via headers/env.
"""

from __future__ import annotations

import os
from typing import Iterable, Optional, Set


def _csv_set(raw: str) -> Set[str]:
    return {p.strip() for p in (raw or "").split(",") if p.strip()}


def allowed_callers_for_action(env_prefix: str, action: str) -> Set[str]:
    """
    Return allowlisted callers for an action based on:
      f"{env_prefix}{ACTION}" (uppercased).
    Example:
      env_prefix="KERNELL_API_ALLOWED_CALLERS_"
      action="CONFIG_UPDATE"
    """
    key = f"{env_prefix}{(action or '').upper()}"
    return _csv_set(os.getenv(key, "").strip())


def is_caller_allowed(
    caller: str,
    action: str,
    *,
    env_prefix: str,
) -> bool:
    """
    Empty allowlist => allow all (compat).
    Non-empty allowlist => caller must be present (fail-closed).
    """
    allowed = allowed_callers_for_action(env_prefix, action)
    if not allowed:
        return True
    return (caller or "unknown") in allowed


def sanitize_caller(caller: Optional[str]) -> str:
    c = caller or "unknown"
    return "".join(ch if ch.isalnum() or ch in ("-", "_", ":", ".") else "_" for ch in c)


# ======================================================================
# Prediction-market policy limits (S1-T02)
# ======================================================================


def _float_env(key: str, default: float) -> float:
    try:
        return float(os.getenv(key, str(default)))
    except (TypeError, ValueError):
        return default


def _bool_env(key: str, default: bool = True) -> bool:
    val = os.getenv(key)
    if val is None:
        return default
    return val.strip().lower() in ("1", "true", "yes", "on")


# -- Master kill-switch: disables all prediction paper activity ---------
PREDICTION_ENABLED: bool = _bool_env("NEMESIS_PREDICTION_ENABLED", True)
PREDICTION_PAPER_ONLY: bool = _bool_env("NEMESIS_PREDICTION_PAPER_ONLY", True)

# -- Exposure limits (USD) ----------------------------------------------
PREDICTION_MAX_MARKET_EXPOSURE_USD: float = _float_env(
    "NEMESIS_PRED_MAX_MARKET_EXPOSURE_USD", 200.0
)
PREDICTION_MAX_TOTAL_EXPOSURE_USD: float = _float_env(
    "NEMESIS_PRED_MAX_TOTAL_EXPOSURE_USD", 500.0
)
PREDICTION_DAILY_DD_LIMIT_USD: float = _float_env(
    "NEMESIS_PRED_DAILY_DD_LIMIT_USD", 150.0
)

# -- Sizing defaults ----------------------------------------------------
PREDICTION_MIN_EDGE: float = _float_env("NEMESIS_PRED_MIN_EDGE", 0.03)
PREDICTION_BASE_STAKE_USD: float = _float_env("NEMESIS_PRED_BASE_STAKE_USD", 25.0)

# -- Kill-switch: consecutive drawdown cap before lane freeze -----------
# If the prediction lane hits this many consecutive losses → auto-freeze.
PREDICTION_MAX_CONSECUTIVE_LOSSES: int = int(
    os.getenv("NEMESIS_PRED_MAX_CONSECUTIVE_LOSSES", "5")
)

# -- Connectivity / data freshness staleness cap (seconds) ---------------
PREDICTION_DATA_STALE_THRESHOLD_S: float = _float_env(
    "NEMESIS_PRED_DATA_STALE_THRESHOLD_S", 7200.0  # 2 hours
)


def prediction_policy_snapshot() -> dict:
    """Return all prediction policy values as a dict (for API / telemetry)."""
    return {
        "enabled": PREDICTION_ENABLED,
        "paper_only": PREDICTION_PAPER_ONLY,
        "max_market_exposure_usd": PREDICTION_MAX_MARKET_EXPOSURE_USD,
        "max_total_exposure_usd": PREDICTION_MAX_TOTAL_EXPOSURE_USD,
        "daily_dd_limit_usd": PREDICTION_DAILY_DD_LIMIT_USD,
        "min_edge": PREDICTION_MIN_EDGE,
        "base_stake_usd": PREDICTION_BASE_STAKE_USD,
        "max_consecutive_losses": PREDICTION_MAX_CONSECUTIVE_LOSSES,
        "data_stale_threshold_s": PREDICTION_DATA_STALE_THRESHOLD_S,
    }

