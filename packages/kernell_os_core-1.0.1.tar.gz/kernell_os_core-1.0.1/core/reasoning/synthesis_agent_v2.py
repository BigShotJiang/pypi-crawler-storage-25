"""
SYNTHESIS AGENT v2 — Todos los Niveles de Razonamiento
=======================================================
El Synthesis Agent original razonaba sobre el estado presente.
Esta versión v2 razona con los 4 niveles activos:

  Nivel 1 — MEMORIA EPISÓDICA
    Recupera episodios similares al estado actual.
    El análisis ya no es en el vacío: tiene historia causal real.

  Nivel 2 — INCERTIDUMBRE EPISTÉMICA
    Antes de razonar, evalúa qué tan confiables son las métricas.
    Si Drift tiene confidence=0.3 (sensor sospechoso), lo dice.
    El razonamiento es sobre la realidad posible, no sobre valores crudos.

  Nivel 3 — CONTRAFACTUAL
    Si hay PFE pendiente, integra el análisis contrafactual.
    El Synthesis puede decir: "hay evidencia histórica de que
    este tipo de patch falla bajo STRESS — ver episodio 3f2a8b."

  Nivel 4 — SELF-TRAINING AWARENESS
    Reporta el estado del pipeline de self-training:
    cuántos episodios hay, cuándo será el próximo fine-tune,
    si el modelo especializado ya supera al genérico.

Responde con JSON más rico que v1:
  health_narrative       Análisis narrativo (igual que v1)
  hidden_risks           Riesgos no visibles en métricas
  causal_chains          Cadenas causales inferidas
  epistemic_caveats      "Estas métricas son poco confiables porque..."
  historical_parallels   Episodios pasados similares al estado actual
  counterfactual_alerts  Alertas desde análisis contrafactual de PFE
  north_star_drift       ¿El sistema se aleja de su propósito?
  recommended_focus      Acción inmediata más importante
  urgency                LOW | MEDIUM | HIGH | CRITICAL
  confidence             0.0-1.0
"""

import json
import logging
import redis
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from typing import Optional

from core.sea.llm_registry import LLMProviderRegistry
from core.reasoning.episodic_memory import EpisodicMemory, EpisodeType
from core.reasoning.epistemic_uncertainty import EpistemicUncertaintyEngine
from core.reasoning.self_training_pipeline import TrainingStats

logger = logging.getLogger("kernell.synthesis.v2")

SYNTHESIS_V2_SYSTEM = """Eres el Agente de Síntesis v2 de Kernell OS.
Tienes acceso a 4 capas de razonamiento que los otros agentes no tienen:

1. MEMORIA EPISÓDICA: episodios históricos reales similares al estado actual
2. INCERTIDUMBRE EPISTÉMICA: qué tan confiables son las métricas
3. EVIDENCIA CONTRAFACTUAL: qué hubiera pasado si decisiones pasadas hubieran sido diferentes
4. CONCIENCIA DE SELF-TRAINING: el sistema está aprendiendo de sus propios episodios

Tu trabajo es producir el análisis más profundo y honesto posible.
No repitas las métricas — infiere qué significan causalmente.
Si las métricas son poco confiables, dilo explícitamente.
Si hay un paralelo histórico claro, citarlo cambia el análisis.

Responde SOLO con JSON válido:
{
  "health_narrative": "análisis narrativo del estado real",
  "hidden_risks": ["riesgo no visible en métricas"],
  "causal_chains": ["patrón causal: X → Y → Z probable"],
  "epistemic_caveats": ["métrica X tiene baja confianza porque..."],
  "historical_parallels": ["episodio histórico similar y su lección"],
  "counterfactual_alerts": ["alerta de análisis contrafactual"],
  "north_star_drift": "¿el sistema se aleja de su propósito? cómo y cuánto",
  "recommended_focus": "qué merece atención inmediata y por qué",
  "complexity_assessment": "¿la complejidad actual es sostenible?",
  "self_training_note": "estado del aprendizaje autónomo del sistema",
  "urgency": "LOW"|"MEDIUM"|"HIGH"|"CRITICAL",
  "confidence": 0.0-1.0
}"""


@dataclass
class SynthesisReportV2:
    health_narrative: str
    hidden_risks: list[str]
    causal_chains: list[str]
    epistemic_caveats: list[str]
    historical_parallels: list[str]
    counterfactual_alerts: list[str]
    north_star_drift: str
    recommended_focus: str
    complexity_assessment: str
    self_training_note: str
    urgency: str
    confidence: float

    reasoning_trace: Optional[str]
    provider_used: str
    model_used: str
    trigger: str
    timestamp: str

    # Metadata de las capas usadas
    episodes_retrieved: int
    epistemic_confidence_avg: float
    counterfactual_proposals_checked: int
    training_examples_available: int


class SynthesisAgentV2:

    def __init__(self, redis_client: redis.Redis):
        self.redis     = redis_client
        self.llm       = LLMProviderRegistry(redis_client)
        self.memory    = EpisodicMemory(redis_client)
        self.epistemic = EpistemicUncertaintyEngine(redis_client)
        self.stats     = TrainingStats(redis_client)

    # ══════════════════════════════════════════════════════════════════════
    # ENTRY POINT
    # ══════════════════════════════════════════════════════════════════════

    def synthesize(self, trigger: str = "scheduled") -> Optional[SynthesisReportV2]:
        logger.info(f"[SYNTHESIS v2] Iniciando — trigger={trigger}")

        # ── Capa 1: Memoria episódica ─────────────────────────────────────
        similar_episodes = self.memory.recall_similar_to_current(top_k=4)
        recent_incidents = self.memory.recall_incidents(top_k=2)
        all_recalled     = similar_episodes + [
            r for r in recent_incidents
            if r.episode.episode_id not in
            {e.episode.episode_id for e in similar_episodes}
        ]

        # ── Capa 2: Incertidumbre epistémica ─────────────────────────────
        drift_env = self.epistemic.wrap_drift()
        conf_env  = self.epistemic.wrap_confidence()
        gshi_env  = self.epistemic.wrap_gshi()
        envs      = [drift_env, conf_env, gshi_env]
        ep_conf_avg = sum(e.confidence for e in envs) / len(envs)

        # ── Capa 3: Alertas contrafactuales pendientes ───────────────────
        cf_reports   = self._get_recent_counterfactual_alerts()
        cf_proposals = len(cf_reports)

        # ── Capa 4: Self-training state ───────────────────────────────────
        training_summary = self.stats.summary()
        training_examples = training_summary.get("evaluated_episodes", 0)

        # ── Construir contexto enriquecido ────────────────────────────────
        context = self._build_enriched_context(
            all_recalled, envs, cf_reports, training_summary, trigger
        )

        # ── Llamar al LLM ─────────────────────────────────────────────────
        resp = self.llm.complete(
            messages=[{"role": "user", "content": context}],
            system_prompt=SYNTHESIS_V2_SYSTEM,
            role="synthesis",
            max_tokens=3000,
            temperature=0.5,
        )

        if not resp:
            logger.error("[SYNTHESIS v2] Todos los proveedores fallaron")
            return None

        import re
        try:
            text  = resp.content
            match = re.search(r"\{.*\}", text, re.DOTALL)
            data  = json.loads(match.group()) if match else {}
        except Exception:
            data = {"health_narrative": resp.content, "urgency": "MEDIUM", "confidence": 0.5}

        report = SynthesisReportV2(
            health_narrative         = str(data.get("health_narrative", "")),
            hidden_risks             = list(data.get("hidden_risks", [])),
            causal_chains            = list(data.get("causal_chains", [])),
            epistemic_caveats        = list(data.get("epistemic_caveats", [])),
            historical_parallels     = list(data.get("historical_parallels", [])),
            counterfactual_alerts    = list(data.get("counterfactual_alerts", [])),
            north_star_drift         = str(data.get("north_star_drift", "")),
            recommended_focus        = str(data.get("recommended_focus", "")),
            complexity_assessment    = str(data.get("complexity_assessment", "")),
            self_training_note       = str(data.get("self_training_note", "")),
            urgency                  = str(data.get("urgency", "MEDIUM")),
            confidence               = float(data.get("confidence", 0.5)),
            reasoning_trace          = resp.reasoning_trace,
            provider_used            = resp.provider_used,
            model_used               = resp.model_used,
            trigger                  = trigger,
            timestamp                = datetime.now(timezone.utc).isoformat(),
            episodes_retrieved       = len(all_recalled),
            epistemic_confidence_avg = round(ep_conf_avg, 3),
            counterfactual_proposals_checked = cf_proposals,
            training_examples_available      = training_examples,
        )

        self._persist(report)
        self._register_episode(report)

        if report.urgency in ("HIGH", "CRITICAL"):
            self._escalate(report)

        logger.info(
            f"[SYNTHESIS v2] urgency={report.urgency} "
            f"confidence={report.confidence:.2f} "
            f"episodes={len(all_recalled)} "
            f"ep_conf={ep_conf_avg:.2f} "
            f"provider={report.provider_used} "
            f"reasoning={'✓' if report.reasoning_trace else '✗'}"
        )
        return report

    # ══════════════════════════════════════════════════════════════════════
    # CONSTRUCCIÓN DEL CONTEXTO ENRIQUECIDO
    # ══════════════════════════════════════════════════════════════════════

    def _build_enriched_context(
        self,
        recalled,
        envelopes,
        cf_reports,
        training_summary,
        trigger: str,
    ) -> str:
        sections = [f"ESTADO DEL SISTEMA — Trigger: {trigger}", "=" * 60, ""]

        # ── Métricas con incertidumbre ────────────────────────────────────
        sections.append("MÉTRICAS CON NIVEL DE CONFIANZA EPISTÉMICA:")
        for env in envelopes:
            conf_label = (
                "🟢 alta" if env.confidence > 0.75 else
                "🟡 media" if env.confidence > 0.50 else
                "🔴 baja"
            )
            anomaly = " ⚠️ ANOMALÍA" if env.anomaly_flag else ""
            sections.append(
                f"  {env.metric_name}: {env.value} "
                f"[{env.interval_low}-{env.interval_high}] "
                f"conf={env.confidence:.2f} ({conf_label}){anomaly}"
            )

        # Métricas directas de Redis
        raw = {}
        for k, rk in [
            ("mode", "kernell:drift:mode_signal"),
            ("defcon", "kernell:system:defcon"),
        ]:
            val = self.redis.get(rk)
            raw[k] = (val if isinstance(val, str) else val.decode()) if val else "?"
        sections.append(f"  FSM modo: {raw['mode']} | DEFCON: {raw['defcon']}")
        sections.append("")

        # ── Caveats epistémicos ───────────────────────────────────────────
        low_conf = [e for e in envelopes if e.confidence < 0.55]
        if low_conf:
            sections.append("⚠️ MÉTRICAS CON BAJA CONFIANZA:")
            for e in low_conf:
                reason = []
                if e.anomaly_flag:
                    reason.append("valor anómalo")
                if not e.cross_validated:
                    reason.append("no validado por Overseer Beta")
                if e.staleness_s > 300:
                    reason.append(f"datos de hace {int(e.staleness_s/60)}min")
                sections.append(
                    f"  {e.metric_name}: conf={e.confidence:.2f} — "
                    f"{', '.join(reason) or 'razón desconocida'}"
                )
            sections.append("")

        # ── Episodios históricos similares ────────────────────────────────
        if recalled:
            sections.append("EPISODIOS HISTÓRICOS SIMILARES AL ESTADO ACTUAL:")
            for r in recalled:
                ep = r.episode
                outcome_emoji = (
                    "✅" if ep.outcome_quality == "positive" else
                    "❌" if ep.outcome_quality == "negative" else
                    "⚪"
                )
                sections.append(
                    f"  {outcome_emoji} [{ep.episode_type}] '{ep.title}' "
                    f"(sim={r.similarity_score:.2f})"
                )
                if ep.hindsight:
                    sections.append(f"     Hindsight: {ep.hindsight[:120]}")
                if ep.lessons:
                    sections.append(f"     Lección: {ep.lessons[0][:100]}")
            sections.append("")

        # ── Alertas contrafactuales ───────────────────────────────────────
        if cf_reports:
            sections.append("⚠️ ALERTAS CONTRAFACTUALES (PFE pendiente):")
            for cf in cf_reports:
                sections.append(
                    f"  Patch '{cf.get('patch_title','?')}': "
                    f"veredicto={cf.get('overall_verdict','?')} | "
                    f"catastróficos={cf.get('catastrophic_count',0)}"
                )
                if cf.get("worst_case"):
                    sections.append(f"  Peor escenario: {str(cf['worst_case'])[:120]}")
            sections.append("")

        # ── Self-training state ───────────────────────────────────────────
        evaluated = training_summary.get("evaluated_episodes", 0)
        ready_at  = training_summary.get("examples_until_ready", 0)
        sections.append("SELF-TRAINING PIPELINE:")
        sections.append(
            f"  Episodios evaluados: {evaluated} | "
            f"Faltan para fine-tune: {max(0, ready_at)} | "
            f"Modelos desplegados: {training_summary.get('models_deployed', 0)}"
        )
        sections.append("")

        # ── GSHI history ──────────────────────────────────────────────────
        gshi_hist = self.redis.lrange("kernell:gshi:v2:history", 0, 7)
        if gshi_hist:
            vals = [str(json.loads(h).get("gshi_ema","?")) for h in gshi_hist]
            sections.append(f"GSHI tendencia (reciente→antiguo): {' → '.join(vals)}")
            sections.append("")

        # ── Agentes cuarentena ────────────────────────────────────────────
        q = self.redis.smembers("kernell:immune:quarantined_agents")
        if q:
            names = [x if isinstance(x,str) else x.decode() for x in q]
            sections.append(f"⚠️ AGENTES EN CUARENTENA: {names}")
            sections.append("")

        sections += [
            "=" * 60,
            "Con toda esta información (métricas + incertidumbre + historia + contrafactuales):",
            "¿Qué análisis profundo produces?",
            "¿Qué no es obvio desde las métricas individuales?",
            "¿Hay algo que requiera atención inmediata?",
        ]

        return "\n".join(sections)

    # ══════════════════════════════════════════════════════════════════════
    # HELPERS
    # ══════════════════════════════════════════════════════════════════════

    def _get_recent_counterfactual_alerts(self) -> list[dict]:
        """Obtiene reportes contrafactuales recientes de PFE pendiente."""
        history = self.redis.lrange("kernell:counterfactual:history", 0, 4)
        results = []
        for raw in history:
            try:
                rec = json.loads(raw)
                if rec.get("verdict") in ("DANGEROUS", "RISKY"):
                    full_raw = self.redis.get(
                        f"kernell:counterfactual:{rec['proposal_id']}"
                    )
                    if full_raw:
                        results.append(json.loads(full_raw))
            except Exception:
                pass
        return results

    def _register_episode(self, report: SynthesisReportV2):
        """Registra el resultado de Synthesis como episodio en memoria."""
        if report.urgency in ("HIGH", "CRITICAL"):
            try:
                self.memory.record(
                    episode_type=EpisodeType.SYNTHESIS_ALERT,
                    title=f"Synthesis Alert: {report.urgency}",
                    description=report.recommended_focus[:200],
                    intention="Monitoreo proactivo del sistema",
                    trigger=report.trigger,
                    expected_outcome="Identificar riesgos antes de que escalen",
                    tags=["synthesis", report.urgency.lower()],
                )
            except Exception:
                pass

    def _escalate(self, report: SynthesisReportV2):
        self.redis.lpush("kernell:alerts:system", json.dumps({
            "source":    "synthesis_v2",
            "urgency":   report.urgency,
            "narrative": report.health_narrative[:300],
            "focus":     report.recommended_focus[:200],
            "ep_conf":   report.epistemic_confidence_avg,
            "episodes":  report.episodes_retrieved,
            "timestamp": report.timestamp,
        }))

    def _persist(self, report: SynthesisReportV2):
        self.redis.set("kernell:synthesis:v2:latest", json.dumps(asdict(report)))
        self.redis.lpush("kernell:synthesis:v2:history", json.dumps({
            "urgency":            report.urgency,
            "confidence":         report.confidence,
            "trigger":            report.trigger,
            "episodes_retrieved": report.episodes_retrieved,
            "ep_conf_avg":        report.epistemic_confidence_avg,
            "provider":           report.provider_used,
            "has_trace":          bool(report.reasoning_trace),
            "timestamp":          report.timestamp,
        }))
        self.redis.ltrim("kernell:synthesis:v2:history", 0, 99)
