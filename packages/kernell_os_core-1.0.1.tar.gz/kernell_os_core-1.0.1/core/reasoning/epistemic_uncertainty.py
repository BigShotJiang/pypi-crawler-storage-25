"""
EPISTEMIC UNCERTAINTY LAYER
=============================
Nivel 2 del razonamiento profundo.

PROBLEMA:
  Kernell trata sus métricas como verdad absoluta.
  Drift = 68 → actuar. Sin preguntarse: ¿qué tan confiable es este 68?
  Un sensor anómalo puede trigger acciones costosas sobre datos falsos.

SOLUCIÓN:
  Cada métrica lleva un UncertaintyEnvelope:
    - value: el valor central
    - confidence: qué tan confiable es ese valor (0-1)
    - interval: [min_plausible, max_plausible]
    - source_reliability: historial del sensor que lo produce
    - cross_validated: si Overseer Beta lo confirmó independientemente
    - anomaly_flag: si hubo algo inusual en la medición

  Decisiones de alto impacto solo se autorizan cuando
  epistemic_confidence supera el umbral de la acción.
  Bajo ese umbral → buscar más evidencia antes de actuar.

GATES EPISTÉMICOS:
  KILL_SWITCH_ACTIVATE    → requiere confidence ≥ 0.85
  PFE_L1_START            → requiere confidence ≥ 0.75
  FSM_ESCALATE_CRITICAL   → requiere confidence ≥ 0.80
  NEMESIS_LARGE_POSITION  → requiere confidence ≥ 0.80
  AGENT_QUARANTINE        → requiere confidence ≥ 0.70

  Si confidence < threshold → HOLD: recolectar más evidencia.
  Si confidence < 0.40     → FREEZE: detener todo hasta aclarar.

KALMAN FILTER SIMPLIFICADO:
  Para métricas con historia (Drift, Confidence, GSHI):
  Combina predicción del modelo con nueva observación.
  Peso según fiabilidad histórica del sensor.
  Resultado: estimación más robusta que el valor crudo.
"""

import json
import logging
import math
import redis
from dataclasses import dataclass, asdict
from datetime import datetime, timezone, timedelta
from typing import Optional
from enum import Enum

logger = logging.getLogger("kernell.epistemic")


class EpistemicGate(Enum):
    """Acciones de alto impacto y su umbral de confianza requerido."""
    KILL_SWITCH_ACTIVATE   = ("kill_switch_activate",   0.85)
    KILL_SWITCH_DEACTIVATE = ("kill_switch_deactivate", 0.80)
    PFE_L1_START           = ("pfe_l1_start",           0.75)
    PFE_L2_START           = ("pfe_l2_start",           0.65)
    FSM_ESCALATE_CRITICAL  = ("fsm_escalate_critical",  0.80)
    FSM_DEESCALATE         = ("fsm_deescalate",         0.70)
    NEMESIS_LARGE_POSITION = ("nemesis_large_position", 0.80)
    NEMESIS_ANY_POSITION   = ("nemesis_any_position",   0.60)
    AGENT_QUARANTINE       = ("agent_quarantine",       0.70)
    AGENT_RELEASE          = ("agent_release",          0.75)
    HARD_FREEZE_LIFT       = ("hard_freeze_lift",       0.90)
    SVS_SECTOR_OVERRIDE    = ("svs_sector_override",    0.85)


GATE_THRESHOLDS = {gate.value[0]: gate.value[1] for gate in EpistemicGate}


@dataclass
class UncertaintyEnvelope:
    """
    Envuelve cualquier métrica con su nivel de certeza epistémica.
    """
    metric_name: str
    value: float
    confidence: float           # 0-1: qué tan confiable es el value
    interval_low: float         # Valor mínimo plausible
    interval_high: float        # Valor máximo plausible
    source_reliability: float   # Historial del sensor (0-1)
    cross_validated: bool       # Overseer Beta lo confirmó
    anomaly_flag: bool          # Algo raro en esta medición
    measurements_count: int     # Cuántas mediciones en el promedio
    staleness_s: float          # Segundos desde la última medición
    kalman_filtered: bool       # Si se aplicó Kalman filter
    timestamp: str


@dataclass
class EpistemicDecision:
    """Resultado de un gate epistémico."""
    action: str
    allowed: bool
    confidence: float
    threshold: float
    reason: str
    recommendation: str    # Qué hacer si no se permite
    timestamp: str


class EpistemicUncertaintyEngine:
    """
    Motor de incertidumbre epistémica de Kernell OS.
    Envuelve métricas con intervalos de confianza.
    Gatilla acciones de alto impacto solo cuando la confianza es suficiente.
    """

    def __init__(self, redis_client: redis.Redis):
        self.redis = redis_client

    # ══════════════════════════════════════════════════════════════════════
    # WRAPPERS DE MÉTRICAS
    # ══════════════════════════════════════════════════════════════════════

    def wrap_drift(self) -> UncertaintyEnvelope:
        """Drift con incertidumbre epistémica."""
        raw      = self._get("kernell:drift:current_value")
        history  = self._get_float_list("kernell:drift:history", n=20)
        anomaly  = self._detect_anomaly(raw, history)
        beta_val = self._get_overseer_validation("drift")

        value, confidence, interval = self._apply_kalman(
            raw, history, process_noise=2.0, measurement_noise=1.5
        )

        if beta_val is not None:
            divergence  = abs(value - beta_val) / max(abs(value), 1)
            confidence *= max(0.3, 1 - divergence * 2)

        source_rel = self._sensor_reliability("drift")
        staleness  = self._staleness("kernell:drift:last_update")

        return UncertaintyEnvelope(
            metric_name="drift",
            value=round(value, 2),
            confidence=round(min(1.0, confidence * source_rel * (0.5 if anomaly else 1.0)), 3),
            interval_low=round(interval[0], 2),
            interval_high=round(interval[1], 2),
            source_reliability=round(source_rel, 3),
            cross_validated=(beta_val is not None),
            anomaly_flag=anomaly,
            measurements_count=len(history),
            staleness_s=staleness,
            kalman_filtered=True,
            timestamp=datetime.now(timezone.utc).isoformat(),
        )

    def wrap_confidence(self) -> UncertaintyEnvelope:
        """Confidence del sistema con meta-incertidumbre."""
        raw     = self._get("kernell:confidence:value")
        history = self._get_float_list("kernell:confidence:history", n=20)
        anomaly = self._detect_anomaly(raw, history)

        value, conf, interval = self._apply_kalman(
            raw, history, process_noise=1.5, measurement_noise=1.0
        )

        source_rel = self._sensor_reliability("confidence")

        return UncertaintyEnvelope(
            metric_name="confidence",
            value=round(value, 2),
            confidence=round(min(1.0, conf * source_rel * (0.7 if anomaly else 1.0)), 3),
            interval_low=round(interval[0], 2),
            interval_high=round(interval[1], 2),
            source_reliability=round(source_rel, 3),
            cross_validated=False,
            anomaly_flag=anomaly,
            measurements_count=len(history),
            staleness_s=self._staleness("kernell:confidence:last_update"),
            kalman_filtered=True,
            timestamp=datetime.now(timezone.utc).isoformat(),
        )

    def wrap_gshi(self) -> UncertaintyEnvelope:
        """GSHI con incertidumbre sobre la incertidumbre."""
        raw_data = self.redis.get("kernell:gshi:v2:current")
        if not raw_data:
            return self._unknown_envelope("gshi")

        gshi_data  = json.loads(raw_data)
        gshi_raw   = gshi_data.get("gshi_raw", 0)
        gshi_ema   = gshi_data.get("gshi_ema", 0)
        history    = self._get_float_list("kernell:gshi:ema_history", n=10)

        # La diferencia entre raw y EMA indica volatilidad
        raw_ema_diff = abs(gshi_raw - gshi_ema)
        confidence   = max(0.4, 1.0 - (raw_ema_diff / 100))

        # Verificar si Overseer freezeó el GSHI
        frozen = self.redis.get("kernell:gshi:v2:frozen")
        if frozen:
            confidence *= 0.3   # GSHI congelado = baja confianza

        std = self._std(history) if len(history) > 3 else 10.0
        interval_half = std * 1.5

        return UncertaintyEnvelope(
            metric_name="gshi",
            value=round(gshi_ema, 2),
            confidence=round(confidence, 3),
            interval_low=round(max(0, gshi_ema - interval_half), 2),
            interval_high=round(min(100, gshi_ema + interval_half), 2),
            source_reliability=0.85,
            cross_validated=not bool(frozen),
            anomaly_flag=bool(frozen) or raw_ema_diff > 15,
            measurements_count=len(history),
            staleness_s=self._staleness("kernell:gshi:v2:current"),
            kalman_filtered=False,
            timestamp=datetime.now(timezone.utc).isoformat(),
        )

    def wrap_trust_score(self, agent_name: str) -> UncertaintyEnvelope:
        """TrustScore de un agente con confianza sobre el valor."""
        raw_data = self.redis.get(f"kernell:gshi:v2:trust:{agent_name}")
        if not raw_data:
            return self._unknown_envelope(f"trust_{agent_name}")

        data       = json.loads(raw_data)
        trust      = data.get("trust_score", 65.0)
        frozen     = data.get("frozen", False)
        validated  = data.get("overseer_validated", True)

        confidence = 0.9
        if frozen:     confidence *= 0.3
        if not validated: confidence *= 0.6

        # Historia reciente
        history_raw = self.redis.lrange(
            f"kernell:gshi:v2:trust:{agent_name}:history", 0, 9
        )
        scores = [json.loads(h).get("trust", trust) for h in history_raw]
        std    = self._std(scores) if len(scores) > 2 else 10.0
        confidence *= max(0.5, 1.0 - std / 50)

        return UncertaintyEnvelope(
            metric_name=f"trust_{agent_name}",
            value=round(trust, 2),
            confidence=round(confidence, 3),
            interval_low=round(max(0, trust - std * 1.5), 2),
            interval_high=round(min(100, trust + std * 1.5), 2),
            source_reliability=0.80,
            cross_validated=validated and not frozen,
            anomaly_flag=frozen,
            measurements_count=len(scores),
            staleness_s=self._staleness(f"kernell:gshi:v2:trust:{agent_name}"),
            kalman_filtered=False,
            timestamp=datetime.now(timezone.utc).isoformat(),
        )

    # ══════════════════════════════════════════════════════════════════════
    # GATES EPISTÉMICOS
    # ══════════════════════════════════════════════════════════════════════

    def check_gate(
        self,
        action: str,
        supporting_metrics: list[UncertaintyEnvelope] = None,
    ) -> EpistemicDecision:
        """
        Verifica si una acción de alto impacto puede ejecutarse
        dado el nivel de confianza epistémica actual.

        Args:
            action: nombre de la acción (ver EpistemicGate)
            supporting_metrics: métricas relevantes para la decisión

        Returns:
            EpistemicDecision con allowed=True/False y recomendación
        """
        threshold = GATE_THRESHOLDS.get(action, 0.70)

        if not supporting_metrics:
            # Capturar métricas automáticamente
            supporting_metrics = [
                self.wrap_drift(),
                self.wrap_confidence(),
                self.wrap_gshi(),
            ]

        # Confianza compuesta: mínimo ponderado de todas las métricas
        confidences = [m.confidence for m in supporting_metrics]
        min_conf    = min(confidences)
        avg_conf    = sum(confidences) / len(confidences)
        # Usar el más conservador (combinación de min y avg)
        composite   = 0.6 * min_conf + 0.4 * avg_conf

        # Penalizaciones adicionales
        anomalies = sum(1 for m in supporting_metrics if m.anomaly_flag)
        if anomalies > 0:
            composite *= max(0.3, 1.0 - anomalies * 0.15)

        stale = [m for m in supporting_metrics if m.staleness_s > 300]
        if stale:
            composite *= max(0.5, 1.0 - len(stale) * 0.10)

        allowed = composite >= threshold

        if allowed:
            reason = f"Confianza epistémica {composite:.2f} ≥ threshold {threshold}"
            recommendation = "Proceder con la acción"
        elif composite >= threshold * 0.8:
            reason = f"Confianza {composite:.2f} ligeramente bajo threshold {threshold}"
            recommendation = (
                "Recolectar 2-3 mediciones adicionales o esperar "
                f"{int((threshold - composite) * 10)}min para que las métricas se estabilicen"
            )
        else:
            reason = f"Confianza {composite:.2f} significativamente bajo threshold {threshold}"
            recommendation = (
                "HOLD: no ejecutar. Verificar sensores anómalos, "
                "solicitar cross-validation de Overseer Beta, "
                "considerar Synthesis análisis del estado"
            )

        decision = EpistemicDecision(
            action=action,
            allowed=allowed,
            confidence=round(composite, 3),
            threshold=threshold,
            reason=reason,
            recommendation=recommendation,
            timestamp=datetime.now(timezone.utc).isoformat(),
        )

        self._persist_decision(decision)

        if not allowed:
            logger.warning(
                f"[EPISTEMIC] GATE BLOQUEADO: {action} "
                f"(conf={composite:.2f} < threshold={threshold})"
            )

        return decision

    def check_all_gates(self) -> dict[str, EpistemicDecision]:
        """Evalúa todos los gates con las métricas actuales."""
        metrics = [self.wrap_drift(), self.wrap_confidence(), self.wrap_gshi()]
        return {
            gate.value[0]: self.check_gate(gate.value[0], metrics)
            for gate in EpistemicGate
        }

    # ══════════════════════════════════════════════════════════════════════
    # KALMAN FILTER SIMPLIFICADO
    # ══════════════════════════════════════════════════════════════════════

    def _apply_kalman(
        self,
        raw_value: Optional[float],
        history: list[float],
        process_noise: float = 2.0,
        measurement_noise: float = 1.5,
    ) -> tuple[float, float, tuple[float, float]]:
        """
        Kalman filter 1D simplificado.
        Combina predicción basada en historia con observación nueva.

        Returns:
            (filtered_value, confidence, (interval_low, interval_high))
        """
        if raw_value is None:
            if history:
                raw_value = history[0]
            else:
                return 50.0, 0.3, (0.0, 100.0)

        if len(history) < 2:
            return raw_value, 0.6, (max(0, raw_value - 10), min(100, raw_value + 10))

        # Estimación previa: promedio ponderado de historia reciente
        weights   = [0.5 ** i for i in range(len(history))]
        total_w   = sum(weights)
        predicted = sum(h * w for h, w in zip(history, weights)) / total_w

        # Varianza histórica
        mean_h  = sum(history) / len(history)
        var_h   = sum((h - mean_h) ** 2 for h in history) / len(history)
        std_h   = math.sqrt(var_h) if var_h > 0 else 5.0

        # Kalman gain
        P_pred = var_h + process_noise
        K      = P_pred / (P_pred + measurement_noise)

        # Valor filtrado
        filtered    = predicted + K * (raw_value - predicted)
        P_updated   = (1 - K) * P_pred

        # Confianza: inversa de la incertidumbre relativa
        uncertainty_pct = math.sqrt(P_updated) / max(abs(filtered), 1)
        confidence      = max(0.2, min(1.0, 1.0 - uncertainty_pct))

        # Intervalo ±1.5 std filtrada
        half = math.sqrt(P_updated) * 1.5
        return (
            round(filtered, 3),
            round(confidence, 3),
            (round(max(0, filtered - half), 2), round(min(100, filtered + half), 2)),
        )

    # ══════════════════════════════════════════════════════════════════════
    # HELPERS
    # ══════════════════════════════════════════════════════════════════════

    def _get(self, key: str) -> Optional[float]:
        raw = self.redis.get(key)
        if raw is None:
            return None
        try:
            return float(raw)
        except ValueError:
            return None

    def _get_float_list(self, key: str, n: int = 20) -> list[float]:
        raw_list = self.redis.lrange(key, 0, n - 1)
        result   = []
        for r in raw_list:
            try:
                result.append(float(r))
            except (ValueError, TypeError):
                try:
                    result.append(float(json.loads(r).get("value", 0)))
                except Exception:
                    pass
        return result

    def _detect_anomaly(self, value: Optional[float], history: list[float]) -> bool:
        if value is None or len(history) < 3:
            return False
        mean = sum(history) / len(history)
        std  = self._std(history)
        if std < 0.01:
            return False
        z_score = abs(value - mean) / std
        return z_score > 3.0   # Más de 3 sigmas = anomalía

    def _std(self, values: list[float]) -> float:
        if len(values) < 2:
            return 5.0
        mean = sum(values) / len(values)
        var  = sum((v - mean) ** 2 for v in values) / len(values)
        return math.sqrt(var)

    def _sensor_reliability(self, metric: str) -> float:
        raw = self.redis.get(f"kernell:epistemic:reliability:{metric}")
        return float(raw) if raw else 0.80

    def _get_overseer_validation(self, metric: str) -> Optional[float]:
        raw = self.redis.get(f"kernell:overseer:beta:validation:{metric}")
        if raw:
            try:
                return float(json.loads(raw).get("value"))
            except Exception:
                pass
        return None

    def _staleness(self, key: str) -> float:
        raw = self.redis.get(key)
        if not raw:
            return 9999.0
        try:
            ts    = float(raw) if raw else None
            if ts:
                return datetime.now(timezone.utc).timestamp() - ts
        except Exception:
            pass
        return 9999.0

    def _unknown_envelope(self, name: str) -> UncertaintyEnvelope:
        return UncertaintyEnvelope(
            metric_name=name, value=50.0, confidence=0.2,
            interval_low=0.0, interval_high=100.0,
            source_reliability=0.0, cross_validated=False,
            anomaly_flag=True, measurements_count=0,
            staleness_s=9999.0, kalman_filtered=False,
            timestamp=datetime.now(timezone.utc).isoformat(),
        )

    def _persist_decision(self, decision: EpistemicDecision):
        self.redis.lpush("kernell:epistemic:decisions", json.dumps(asdict(decision)))
        self.redis.ltrim("kernell:epistemic:decisions", 0, 499)
