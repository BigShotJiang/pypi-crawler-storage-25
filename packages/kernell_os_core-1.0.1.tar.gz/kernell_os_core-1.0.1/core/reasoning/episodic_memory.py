"""
EPISODIC MEMORY — Memoria Causal de Kernell OS
================================================
Nivel 1 del razonamiento profundo.

PROBLEMA:
  Kernell sabe QUÉ pasó (Redis snapshots, metrics).
  No sabe POR QUÉ pasó ni QUÉ ESPERABA que pasara.
  Sin historia causal, el Synthesis Agent razona en el vacío.

SOLUCIÓN:
  Cada evento significativo se almacena como Episodio Causal:
    - Qué ocurrió (evento)
    - Por qué se hizo (intención)
    - Qué se esperaba (predicción)
    - Qué pasó en realidad (outcome)
    - Qué aprendió el sistema (hindsight)
    - Embedding vectorial para recuperación por similitud

  Qdrant = almacenamiento vectorial + búsqueda semántica
  Redis  = índice rápido + metadata reciente

TIPOS DE EPISODIO:
  pfe_promotion     Patch promovido a producción
  pfe_rejection     Patch rechazado (por quién y por qué)
  incident          CRITICAL o Hard Freeze
  gshi_drop         Caída brusca de GSHI (>10pts)
  recovery          Sistema recuperado de estado grave
  evolution         Cambio estructural significativo
  anomaly           Comportamiento inesperado detectado
  red_team_success  Red Team detectó vulnerabilidad real

RECUPERACIÓN:
  memory.recall("incident similar to current drift spike")
  → retorna episodios más similares semánticamente
  → Synthesis Agent razona con contexto histórico real
"""

import json
import logging
import redis
import uuid
import time
from dataclasses import dataclass, asdict, field
from datetime import datetime, timezone, timedelta
from typing import Optional
from enum import Enum

logger = logging.getLogger("kernell.episodic_memory")

QDRANT_COLLECTION = "kernell_episodes"
EMBEDDING_DIM     = 768    # fastembed Jina 768d LOCAL (Kernell OS standard)
MAX_EPISODES_REDIS = 500   # Índice rápido en Redis

# Import centralized threshold
try:
    from agents.core.memory.kms_config import RAG_SCORE_THRESHOLD
except ImportError:
    RAG_SCORE_THRESHOLD = 0.65


class EpisodeType(Enum):
    PFE_PROMOTION   = "pfe_promotion"
    PFE_REJECTION   = "pfe_rejection"
    INCIDENT        = "incident"
    GSHI_DROP       = "gshi_drop"
    RECOVERY        = "recovery"
    EVOLUTION       = "evolution"
    ANOMALY         = "anomaly"
    RED_TEAM_HIT    = "red_team_hit"
    SYNTHESIS_ALERT = "synthesis_alert"


class EpisodeOutcome(Enum):
    POSITIVE  = "positive"   # Resultó mejor de lo esperado
    NEUTRAL   = "neutral"    # Como se esperaba
    NEGATIVE  = "negative"   # Peor de lo esperado
    UNKNOWN   = "unknown"    # Aún no hay suficiente tiempo para evaluar


@dataclass
class SystemSnapshot:
    """Estado del sistema en el momento del episodio."""
    gshi: Optional[float]
    mode: Optional[str]
    drift: Optional[float]
    confidence: Optional[float]
    defcon: Optional[int]
    sii: Optional[float]
    sci: Optional[float]
    active_agents: int
    quarantined: list[str]


@dataclass
class CausalEpisode:
    """
    La unidad fundamental de memoria de Kernell OS.
    No solo QUÉ pasó — sino POR QUÉ, QUÉ SE ESPERABA, y QUÉ APRENDIÓ.
    """
    episode_id: str
    episode_type: str
    timestamp: str

    # El qué
    title: str
    description: str

    # El por qué (intención)
    intention: str           # "¿Por qué se tomó esta acción?"
    trigger: str             # "¿Qué lo causó?"

    # La predicción (qué se esperaba)
    expected_outcome: str
    expected_gshi_delta: Optional[float]
    expected_sci_delta: Optional[float]

    # El resultado real
    actual_outcome: str
    actual_gshi_delta: Optional[float]
    actual_sci_delta: Optional[float]
    outcome_quality: str     # EpisodeOutcome.value

    # El aprendizaje (hindsight)
    hindsight: str           # Generado por Synthesis cuando tiene datos
    lessons: list[str]

    # Contexto
    snapshot_before: dict    # SystemSnapshot antes del evento
    snapshot_after: Optional[dict]   # SystemSnapshot después (puede ser None si muy reciente)
    related_episodes: list[str]      # IDs de episodios causalmente relacionados

    # Metadata
    patch_id: Optional[str]  # Si es PFE
    author: Optional[str]
    evaluated: bool          # Si snapshot_after fue registrado
    tags: list[str]


@dataclass
class EpisodeRecall:
    """Resultado de una búsqueda en memoria episódica."""
    episode: CausalEpisode
    similarity_score: float
    retrieval_reason: str


class EpisodicMemory:
    """
    Sistema de memoria episódica causal de Kernell OS.
    Combina Qdrant (búsqueda semántica) + Redis (acceso rápido).
    """

    def __init__(
        self,
        redis_client: redis.Redis,
        qdrant_url: str = "http://localhost:6333",
        use_qdrant: bool = True,
    ):
        self.redis       = redis_client
        self._qdrant_url = qdrant_url
        self._use_qdrant = use_qdrant
        self._llm        = None   # LLMProviderRegistry (lazy init)

        if use_qdrant:
            self._init_qdrant()

    # ══════════════════════════════════════════════════════════════════════
    # REGISTRO DE EPISODIOS
    # ══════════════════════════════════════════════════════════════════════

    def record(
        self,
        episode_type: EpisodeType,
        title: str,
        description: str,
        intention: str,
        trigger: str,
        expected_outcome: str,
        expected_gshi_delta: Optional[float] = None,
        expected_sci_delta: Optional[float] = None,
        patch_id: Optional[str] = None,
        author: Optional[str] = None,
        tags: list[str] = None,
    ) -> CausalEpisode:
        """
        Registra un nuevo episodio causal.
        snapshot_after y hindsight se completan posteriormente con evaluate().
        """
        snapshot = self._capture_snapshot()

        episode = CausalEpisode(
            episode_id=str(uuid.uuid4())[:12],
            episode_type=episode_type.value,
            timestamp=datetime.now(timezone.utc).isoformat(),
            title=title,
            description=description,
            intention=intention,
            trigger=trigger,
            expected_outcome=expected_outcome,
            expected_gshi_delta=expected_gshi_delta,
            expected_sci_delta=expected_sci_delta,
            actual_outcome="",          # Se completa en evaluate()
            actual_gshi_delta=None,
            actual_sci_delta=None,
            outcome_quality=EpisodeOutcome.UNKNOWN.value,
            hindsight="",               # Se completa por Synthesis
            lessons=[],
            snapshot_before=asdict(snapshot),
            snapshot_after=None,
            related_episodes=self._find_related(episode_type, description),
            patch_id=patch_id,
            author=author,
            evaluated=False,
            tags=tags or [],
        )

        self._persist(episode)

        if self._use_qdrant:
            self._index_in_qdrant(episode)

        logger.info(
            f"[MEMORY] Episodio registrado: {episode.episode_id} "
            f"[{episode_type.value}] '{title}'"
        )
        return episode

    def evaluate(
        self,
        episode_id: str,
        actual_outcome: str,
        lessons: list[str] = None,
    ) -> Optional[CausalEpisode]:
        """
        Cierra un episodio con su outcome real.
        Se llama cuando hay suficiente tiempo para evaluar resultados
        (típicamente 24-48h después del evento).
        """
        episode = self._load(episode_id)
        if not episode:
            logger.warning(f"[MEMORY] Episodio no encontrado: {episode_id}")
            return None

        # Capturar snapshot actual
        snapshot_after = self._capture_snapshot()
        before_gshi = episode.snapshot_before.get("gshi")
        after_gshi  = snapshot_after.gshi

        # Calcular deltas reales
        gshi_delta = round(after_gshi - before_gshi, 2) if (after_gshi and before_gshi) else None
        before_sci = episode.snapshot_before.get("sci")
        sci_delta  = round(snapshot_after.sci - before_sci, 2) if (snapshot_after.sci and before_sci) else None

        # Determinar outcome quality
        quality = self._assess_quality(
            episode.expected_gshi_delta,
            gshi_delta,
            episode.expected_outcome,
            actual_outcome,
        )

        episode.actual_outcome    = actual_outcome
        episode.actual_gshi_delta = gshi_delta
        episode.actual_sci_delta  = sci_delta
        episode.outcome_quality   = quality.value
        episode.snapshot_after    = asdict(snapshot_after)
        episode.lessons           = lessons or []
        episode.evaluated         = True

        # Generar hindsight con Synthesis
        episode.hindsight = self._generate_hindsight(episode)

        self._persist(episode)

        if self._use_qdrant:
            self._index_in_qdrant(episode)   # Re-indexar con outcome completo

        logger.info(
            f"[MEMORY] Episodio evaluado: {episode_id} → "
            f"quality={quality.value} GSHI_delta={gshi_delta}"
        )
        return episode

    # ══════════════════════════════════════════════════════════════════════
    # RECUPERACIÓN
    # ══════════════════════════════════════════════════════════════════════

    def recall(
        self,
        query: str,
        episode_types: list[EpisodeType] = None,
        top_k: int = 5,
        min_similarity: float = RAG_SCORE_THRESHOLD,
        evaluated_only: bool = False,
    ) -> list[EpisodeRecall]:
        """
        Recupera episodios similares a la query.
        Usa Qdrant para búsqueda semántica.
        Si Qdrant no está disponible, busca en Redis por tipo.
        """
        if self._use_qdrant:
            return self._recall_qdrant(query, episode_types, top_k, min_similarity, evaluated_only)
        return self._recall_redis(episode_types, top_k, evaluated_only)

    def recall_similar_to_current(
        self,
        top_k: int = 3,
    ) -> list[EpisodeRecall]:
        """
        Recupera episodios similares al estado actual del sistema.
        Útil para el Synthesis Agent antes de producir un análisis.
        """
        snapshot = self._capture_snapshot()
        query = (
            f"Sistema en modo {snapshot.mode} con GSHI {snapshot.gshi} "
            f"y drift {snapshot.drift}. "
            f"Confianza {snapshot.confidence}. DEFCON {snapshot.defcon}."
        )
        return self.recall(query, top_k=top_k)

    def recall_pfe_outcomes(
        self,
        patch_description: str,
        top_k: int = 3,
    ) -> list[EpisodeRecall]:
        """
        Recupera episodios de PFE similares al patch propuesto.
        Usado por Forge Council y Audit Council para contexto histórico.
        """
        return self.recall(
            query=patch_description,
            episode_types=[EpisodeType.PFE_PROMOTION, EpisodeType.PFE_REJECTION],
            top_k=top_k,
            evaluated_only=True,  # Solo episodios con outcome conocido
        )

    def recall_incidents(self, top_k: int = 5) -> list[EpisodeRecall]:
        """Recupera incidentes recientes para contexto de Synthesis."""
        return self.recall(
            query="incident critical failure recovery system",
            episode_types=[EpisodeType.INCIDENT, EpisodeType.RECOVERY],
            top_k=top_k,
        )

    def get_lessons(self, episode_type: EpisodeType = None) -> list[str]:
        """
        Consolida todas las lecciones aprendidas de episodios evaluados.
        Para el North Star drift assessment.
        """
        all_lessons = []
        raw_list = self.redis.lrange("kernell:memory:episodes:index", 0, 199)

        for raw in raw_list:
            ep_id = raw if isinstance(raw, str) else raw.decode()
            ep    = self._load(ep_id)
            if ep and ep.evaluated and ep.lessons:
                if episode_type is None or ep.episode_type == episode_type.value:
                    all_lessons.extend(ep.lessons)

        return list(dict.fromkeys(all_lessons))   # Dedup preservando orden

    # ══════════════════════════════════════════════════════════════════════
    # BÚSQUEDA EN QDRANT
    # ══════════════════════════════════════════════════════════════════════

    def _recall_qdrant(
        self,
        query: str,
        episode_types: list[EpisodeType],
        top_k: int,
        min_similarity: float,
        evaluated_only: bool,
    ) -> list[EpisodeRecall]:
        try:
            embedding = self._embed(query)
            if not embedding:
                return self._recall_redis(episode_types, top_k, evaluated_only)

            filter_conditions = {}
            if episode_types:
                filter_conditions["episode_type"] = {
                    "any": [et.value for et in episode_types]
                }
            if evaluated_only:
                filter_conditions["evaluated"] = {"match": {"value": True}}

            import urllib.request
            payload = {
                "vector": embedding,
                "limit": top_k,
                "score_threshold": min_similarity,
                "with_payload": True,
            }
            if filter_conditions:
                payload["filter"] = {"must": [
                    {"key": k, "match": v} for k, v in filter_conditions.items()
                ]}

            url = f"{self._qdrant_url}/collections/{QDRANT_COLLECTION}/points/search"
            req = urllib.request.Request(
                url,
                data=json.dumps(payload).encode(),
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read())

            results = []
            for point in data.get("result", []):
                ep_data = point.get("payload", {})
                try:
                    ep = CausalEpisode(**ep_data)
                    results.append(EpisodeRecall(
                        episode=ep,
                        similarity_score=point.get("score", 0),
                        retrieval_reason=f"Semantic similarity {point.get('score',0):.2f}",
                    ))
                except Exception:
                    pass

            return results

        except Exception as e:
            logger.warning(f"[MEMORY] Qdrant error: {e} — fallback a Redis")
            return self._recall_redis(episode_types, top_k, evaluated_only)

    def _recall_redis(
        self,
        episode_types: list[EpisodeType],
        top_k: int,
        evaluated_only: bool,
    ) -> list[EpisodeRecall]:
        """Fallback: recupera episodios recientes de Redis sin similitud semántica."""
        index = self.redis.lrange("kernell:memory:episodes:index", 0, top_k * 3)
        results = []

        for raw in index:
            ep_id = raw if isinstance(raw, str) else raw.decode()
            ep    = self._load(ep_id)
            if not ep:
                continue
            if evaluated_only and not ep.evaluated:
                continue
            if episode_types and ep.episode_type not in [et.value for et in episode_types]:
                continue
            results.append(EpisodeRecall(
                episode=ep,
                similarity_score=0.5,
                retrieval_reason="Redis fallback (no semantic search)",
            ))
            if len(results) >= top_k:
                break

        return results

    # ══════════════════════════════════════════════════════════════════════
    # HINDSIGHT GENERATION
    # ══════════════════════════════════════════════════════════════════════

    def _generate_hindsight(self, episode: CausalEpisode) -> str:
        """
        Genera análisis retrospectivo usando LLM.
        Solo para episodios evaluados con outcomes conocidos.
        """
        try:
            llm = self._get_llm()
            prompt = (
                f"EPISODIO EVALUADO DE KERNELL OS\n"
                f"Tipo: {episode.episode_type}\n"
                f"Título: {episode.title}\n"
                f"Intención: {episode.intention}\n"
                f"Outcome esperado: {episode.expected_outcome}\n"
                f"GSHI delta esperado: {episode.expected_gshi_delta}\n"
                f"Outcome real: {episode.actual_outcome}\n"
                f"GSHI delta real: {episode.actual_gshi_delta}\n"
                f"SCI delta real: {episode.actual_sci_delta}\n"
                f"Calidad: {episode.outcome_quality}\n\n"
                "En 2-3 oraciones, ¿qué aprendemos de este episodio? "
                "¿La predicción fue acertada? ¿Qué no se anticipó?"
            )

            resp = llm.complete(
                messages=[{"role": "user", "content": prompt}],
                role="synthesis",
                max_tokens=300,
                temperature=0.3,
            )
            return resp.content if resp else ""
        except Exception:
            return ""

    # ══════════════════════════════════════════════════════════════════════
    # EMBEDDING + QDRANT INIT
    # ══════════════════════════════════════════════════════════════════════

    def _embed(self, text: str) -> Optional[list[float]]:
        """Genera embedding 100% LOCAL via fastembed (Jina 768d)."""
        try:
            from agents.core.memory.embedding_engine import get_embedding
            return get_embedding(str(text)[:8192])
        except Exception as e:
            logger.debug(f"[MEMORY] Embedding failed: {e}")
            return None

    def _init_qdrant(self):
        """Crea la colección en Qdrant si no existe."""
        try:
            import urllib.request
            # Verificar si colección existe
            url = f"{self._qdrant_url}/collections/{QDRANT_COLLECTION}"
            try:
                urllib.request.urlopen(url, timeout=5)
                logger.info(f"[MEMORY] Qdrant colección '{QDRANT_COLLECTION}' encontrada")
                return
            except Exception:
                pass

            # Crear colección
            payload = {
                "vectors": {"size": EMBEDDING_DIM, "distance": "Cosine"}
            }
            req = urllib.request.Request(
                url, data=json.dumps(payload).encode(),
                headers={"Content-Type": "application/json"}, method="PUT",
            )
            urllib.request.urlopen(req, timeout=10)
            logger.info(f"[MEMORY] Qdrant colección '{QDRANT_COLLECTION}' creada")
        except Exception as e:
            logger.warning(f"[MEMORY] Qdrant no disponible: {e} — usando solo Redis")
            self._use_qdrant = False

    def _index_in_qdrant(self, episode: CausalEpisode):
        """Index episode in Qdrant — routes through MemoryBroker when available."""
        text = (
            f"{episode.title} {episode.description} "
            f"{episode.intention} {episode.trigger} "
            f"{episode.expected_outcome} {episode.actual_outcome} "
            f"{episode.hindsight} {' '.join(episode.lessons)}"
        )

        # Try MemoryBroker first (unified ACL, dedup, audit)
        try:
            import asyncio
            from core.memory.memory_broker import MemoryBroker, MemoryRecord, Collection

            record = MemoryRecord(
                content=text,
                agent=episode.author or "system",
                memory_type="success_pattern" if episode.outcome_quality == "positive" else "episodic",
                collection=Collection.EPISODES,
                tags=episode.tags or [],
                score=0.8 if episode.outcome_quality == "positive" else 0.5,
                extra=asdict(episode),
            )
            record.id = episode.episode_id

            async def _upsert():
                broker = await MemoryBroker.get_instance()
                await broker.upsert(record)

            try:
                loop = asyncio.get_running_loop()
                loop.create_task(_upsert())
            except RuntimeError:
                asyncio.run(_upsert())
            return
        except ImportError:
            pass
        except Exception as e:
            logger.debug(f"[MEMORY] Broker upsert failed, fallback to direct: {e}")

        # Fallback: direct Qdrant REST API
        try:
            embedding = self._embed(text)
            if not embedding:
                return

            import urllib.request
            payload = {
                "points": [{
                    "id":      episode.episode_id,
                    "vector":  embedding,
                    "payload": asdict(episode),
                }]
            }
            url = f"{self._qdrant_url}/collections/{QDRANT_COLLECTION}/points"
            req = urllib.request.Request(
                url, data=json.dumps(payload).encode(),
                headers={"Content-Type": "application/json"}, method="PUT",
            )
            urllib.request.urlopen(req, timeout=10)
        except Exception as e:
            logger.debug(f"[MEMORY] Qdrant index error: {e}")

    # ══════════════════════════════════════════════════════════════════════
    # HELPERS
    # ══════════════════════════════════════════════════════════════════════

    def _capture_snapshot(self) -> SystemSnapshot:
        def g(key): return self.redis.get(key)
        def f(raw): return float(raw) if raw else None
        def i(raw): return int(raw)   if raw else None
        def s(raw): return (raw if isinstance(raw,str) else raw.decode()) if raw else None

        quarantined = self.redis.smembers("kernell:immune:quarantined_agents")
        names = [q if isinstance(q,str) else q.decode() for q in quarantined]

        gshi_raw = g("kernell:gshi:v2:current")
        gshi_val = None
        sii_val  = None
        sci_val  = None
        if gshi_raw:
            d = json.loads(gshi_raw)
            gshi_val = d.get("gshi_ema")
            sii_val  = d.get("sii")
            sci_val  = d.get("sci")

        active = sum(1 for _ in self.redis.scan_iter("kernell:agents:heartbeats:*"))

        return SystemSnapshot(
            gshi=gshi_val,
            mode=s(g("kernell:drift:mode_signal")),
            drift=f(g("kernell:drift:current_value")),
            confidence=f(g("kernell:confidence:value")),
            defcon=i(g("kernell:system:defcon")),
            sii=sii_val,
            sci=sci_val,
            active_agents=active,
            quarantined=names,
        )

    def _assess_quality(
        self,
        expected_delta: Optional[float],
        actual_delta: Optional[float],
        expected_desc: str,
        actual_desc: str,
    ) -> EpisodeOutcome:
        if actual_delta is None or expected_delta is None:
            return EpisodeOutcome.UNKNOWN
        diff = actual_delta - expected_delta
        if diff > 3:    return EpisodeOutcome.POSITIVE
        if diff < -3:   return EpisodeOutcome.NEGATIVE
        return EpisodeOutcome.NEUTRAL

    def _find_related(self, episode_type: EpisodeType, description: str) -> list[str]:
        """Busca episodios relacionados causalmente en memoria reciente."""
        recent = self.redis.lrange("kernell:memory:episodes:index", 0, 20)
        related = []
        keywords = set(description.lower().split())
        for raw in recent:
            ep_id = raw if isinstance(raw,str) else raw.decode()
            ep    = self._load(ep_id)
            if ep and ep.episode_type == episode_type.value:
                ep_words = set((ep.title + " " + ep.description).lower().split())
                if len(keywords & ep_words) >= 3:
                    related.append(ep_id)
        return related[:3]

    def _persist(self, episode: CausalEpisode):
        data = json.dumps(asdict(episode))
        self.redis.set(f"kernell:memory:episode:{episode.episode_id}", data)
        self.redis.lpush("kernell:memory:episodes:index", episode.episode_id)
        self.redis.ltrim("kernell:memory:episodes:index", 0, MAX_EPISODES_REDIS)

        # Índice por tipo
        self.redis.lpush(
            f"kernell:memory:by_type:{episode.episode_type}",
            episode.episode_id
        )
        self.redis.ltrim(f"kernell:memory:by_type:{episode.episode_type}", 0, 99)

    def _load(self, episode_id: str) -> Optional[CausalEpisode]:
        raw = self.redis.get(f"kernell:memory:episode:{episode_id}")
        if not raw:
            return None
        try:
            data = json.loads(raw)
            return CausalEpisode(**data)
        except Exception:
            return None

    def _get_llm(self):
        if not self._llm:
            from core.sea.llm_registry import LLMProviderRegistry
            self._llm = LLMProviderRegistry(self.redis)
        return self._llm

    # ── Stats públicas ────────────────────────────────────────────────────

    def stats(self) -> dict:
        total  = self.redis.llen("kernell:memory:episodes:index")
        by_type = {}
        for et in EpisodeType:
            count = self.redis.llen(f"kernell:memory:by_type:{et.value}")
            by_type[et.value] = count

        evaluated = 0
        positive  = 0
        index = self.redis.lrange("kernell:memory:episodes:index", 0, 99)
        for raw in index:
            ep = self._load(raw if isinstance(raw,str) else raw.decode())
            if ep and ep.evaluated:
                evaluated += 1
                if ep.outcome_quality == EpisodeOutcome.POSITIVE.value:
                    positive += 1

        return {
            "total_episodes":    total,
            "evaluated":         evaluated,
            "positive_outcomes": positive,
            "by_type":           by_type,
            "qdrant_enabled":    self._use_qdrant,
        }
