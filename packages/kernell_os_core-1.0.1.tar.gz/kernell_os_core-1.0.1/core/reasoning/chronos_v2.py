"""
CHRONOS v2 — Orquestador con Razonamiento Completo
====================================================
Extiende Chronos v1 con los 4 niveles de razonamiento:

  Nivel 1: Registra episodios en EpisodicMemory
    - Cada evento significativo queda en memoria causal
    - Evalúa episodios pasados cuando hay suficiente tiempo

  Nivel 2: Epistemic gates antes de decisiones de alto impacto
    - Kill-switch solo si conf epistémica ≥ 0.85
    - PFE L1 solo si conf epistémica ≥ 0.75
    - Si confianza baja → recolectar más evidencia primero

  Nivel 3: Análisis contrafactual antes de PFE
    - Antes de procesar un patch, lo analiza contra historia
    - Si el contrafactual dice DANGEROUS → notifica y frena

  Nivel 4: Ciclos de self-training automáticos
    - Evalúa episodios cada 24h (cierra el loop causal)
    - Dispara fine-tune cuando hay ≥ 50 episodios evaluados

TAREAS NUEVAS vs v1:
  episode_evaluator   Cada 24h, evalúa episodios pendientes
  fine_tune_cycle     Cada 48h, dispara ciclo de self-training
  epistemic_monitor   Cada 15min, actualiza fiabilidad de sensores

CAMBIOS A TAREAS EXISTENTES:
  pfe_check           Ahora hace análisis contrafactual primero
  svs                 Registra resultado en EpisodicMemory
  gshi                Registra caídas bruscas como episodios
  synthesis           Usa SynthesisAgentV2 (con 4 capas)
"""

import json
import logging
import time
import threading
import random
import signal
import sys
from dataclasses import dataclass, asdict
from datetime import datetime, timezone, timedelta
from typing import Optional, Callable
import redis

logger = logging.getLogger("kernell.chronos.v2")

TASK_INTERVALS = {
    "svs":                2 * 3600,
    "gshi":               30 * 60,
    "synthesis":          4 * 3600,
    "pfe_check":          15 * 60,
    "red_team":           5 * 60,
    "heartbeat":          60,
    # ── Nuevas tareas ─────────────────────────────────────────────────────
    "episode_evaluator":  24 * 3600,    # Cierra el loop episódico
    "fine_tune_cycle":    48 * 3600,    # Self-training
    "epistemic_monitor":  15 * 60,      # Actualiza fiabilidad de sensores
}

JITTER_MAX_S = 120

ERROR_COOLDOWN = {
    "svs":              15 * 60,
    "gshi":             5  * 60,
    "synthesis":        10 * 60,
    "pfe_check":        5  * 60,
    "red_team":         2  * 60,
    "episode_evaluator": 30 * 60,
    "fine_tune_cycle":  60 * 60,
    "epistemic_monitor": 5 * 60,
}


class ChronosTask:
    def __init__(self, name: str, fn: Callable, interval_s: int, jitter_s: int = 60):
        self.name       = name
        self.fn         = fn
        self.interval_s = interval_s
        self.jitter_s   = jitter_s
        self._lock      = threading.Lock()
        self._paused    = False
        self._run_count = 0
        self._err_count = 0
        self._last_run: Optional[datetime] = None
        self._last_err: Optional[str]      = None
        self._last_result: str             = "PENDING"
        self._next_run: datetime           = datetime.now(timezone.utc)

    def should_run(self) -> bool:
        if self._paused or self._lock.locked():
            return False
        return datetime.now(timezone.utc) >= self._next_run

    def run(self):
        if not self._lock.acquire(blocking=False):
            return
        try:
            logger.info(f"[CHRONOS v2] → {self.name}")
            t0 = time.time()
            self.fn()
            self._last_result = "OK"
            self._run_count  += 1
            self._last_run    = datetime.now(timezone.utc)
            logger.info(f"[CHRONOS v2] ✓ {self.name} ({time.time()-t0:.1f}s)")
        except Exception as e:
            self._last_result = "ERROR"
            self._err_count  += 1
            self._last_err    = str(e)[:200]
            logger.error(f"[CHRONOS v2] ✗ {self.name}: {e}")
            jitter = random.uniform(0, self.jitter_s)
            self._next_run = datetime.now(timezone.utc) + timedelta(
                seconds=ERROR_COOLDOWN.get(self.name, self.interval_s) + jitter
            )
            return
        finally:
            self._lock.release()

        jitter = random.uniform(0, self.jitter_s)
        self._next_run = datetime.now(timezone.utc) + timedelta(
            seconds=self.interval_s + jitter
        )

    def trigger_immediate(self):
        self._next_run = datetime.now(timezone.utc)

    def pause(self):   self._paused = True
    def resume(self):  self._paused = False

    def status(self) -> dict:
        return {
            "name":        self.name,
            "last_run":    self._last_run.isoformat() if self._last_run else None,
            "last_result": self._last_result,
            "next_run":    self._next_run.isoformat(),
            "run_count":   self._run_count,
            "error_count": self._err_count,
            "paused":      self._paused,
        }


class ChronosV2:
    """
    Orquestador v2: incluye 4 niveles de razonamiento en cada ciclo.
    Reemplaza a Chronos v1.
    """

    def __init__(self, redis_client: redis.Redis, layer: str = "core"):
        self.redis    = redis_client
        self.layer    = layer
        self._running = False
        self._tasks: dict[str, ChronosTask] = {}

        self._init_subsystems()
        self._init_tasks()

        signal.signal(signal.SIGTERM, self._signal_handler)
        signal.signal(signal.SIGINT,  self._signal_handler)

    # ══════════════════════════════════════════════════════════════════════
    # INIT
    # ══════════════════════════════════════════════════════════════════════

    def _init_subsystems(self):
        from kernell.svs_v2.svs_v2          import SVSv2
        from kernell.gshi_v2.gshi_v2        import GSHIv2
        from core.reasoning.synthesis_agent_v2 import SynthesisAgentV2
        from core.reasoning.episodic_memory import EpisodicMemory, EpisodeType
        from core.reasoning.epistemic_uncertainty import EpistemicUncertaintyEngine
        from core.reasoning.counterfactual_reasoner import CounterfactualReasoner
        from core.reasoning.self_training_pipeline import (
            FineTuningOrchestrator, FineTuneProvider
        )

        secret          = self._get_system_secret()
        self._svs       = SVSv2(self.redis, secret)
        self._gshi      = GSHIv2(self.redis, secret)
        self._synthesis = SynthesisAgentV2(self.redis)
        self._memory    = EpisodicMemory(self.redis)
        self._epistemic = EpistemicUncertaintyEngine(self.redis)
        self._cf        = CounterfactualReasoner(self.redis)
        self._ft        = FineTuningOrchestrator(self.redis)
        self._EpisodeType   = EpisodeType
        self._FTProvider    = FineTuneProvider

        if self.layer == "core":
            from kernell.tricapa.tricapa_and_redteam import RedTeamAdversarial
            self._red_team = RedTeamAdversarial(self.redis)

    def _init_tasks(self):
        self._register("svs",              self._task_svs,              TASK_INTERVALS["svs"])
        self._register("gshi",             self._task_gshi,             TASK_INTERVALS["gshi"])
        self._register("synthesis",        self._task_synthesis,        TASK_INTERVALS["synthesis"])
        self._register("pfe_check",        self._task_pfe_check,        TASK_INTERVALS["pfe_check"])
        self._register("heartbeat",        self._task_heartbeat,        TASK_INTERVALS["heartbeat"], jitter_s=0)
        self._register("episode_evaluator",self._task_episode_evaluator,TASK_INTERVALS["episode_evaluator"])
        self._register("fine_tune_cycle",  self._task_fine_tune_cycle,  TASK_INTERVALS["fine_tune_cycle"])
        self._register("epistemic_monitor",self._task_epistemic_monitor,TASK_INTERVALS["epistemic_monitor"])

        if self.layer == "core":
            self._register("red_team", self._task_red_team, TASK_INTERVALS["red_team"])

    def _register(self, name, fn, interval_s, jitter_s=JITTER_MAX_S):
        self._tasks[name] = ChronosTask(name, fn, interval_s, jitter_s)

    # ══════════════════════════════════════════════════════════════════════
    # TAREAS EXTENDIDAS
    # ══════════════════════════════════════════════════════════════════════

    def _task_svs(self):
        """SVS + registro en memoria episódica."""
        report = self._svs.run_sweep(allow_degraded=True)
        result = report.overall_result

        self.redis.set("kernell:system:last_svs_result", result)

        if result == "FAIL":
            # Nivel 1: registrar como episodio
            self._memory.record(
                episode_type=self._EpisodeType.INCIDENT,
                title="SVS FAIL — Hard Freeze activado",
                description=f"SVS falló. Sectores: {getattr(report,'failed_sectors',[])}",
                intention="Verificación sectorial de integridad",
                trigger="Chronos SVS scheduled",
                expected_outcome="SVS PASS para autorizar PFE",
                tags=["svs", "fail", "hard_freeze"],
            )
            self._tasks["synthesis"].trigger_immediate()
            self.redis.set("kernell:chronos:synthesis_trigger", "svs_fail")

        elif report.degraded_mode:
            self._tasks["synthesis"].trigger_immediate()
            self.redis.set("kernell:chronos:synthesis_trigger", "svs_degraded")

    def _task_gshi(self):
        """GSHI + detección de caídas bruscas + epistemic update."""
        sii    = self._calculate_sii()
        report = self._gshi.calculate(sii)

        prev_gshi = self._get_prev_gshi()
        current   = report.gshi_ema

        if prev_gshi and (prev_gshi - current) > 10:
            drop = round(prev_gshi - current, 1)
            logger.warning(f"[CHRONOS v2] GSHI drop {prev_gshi:.1f}→{current:.1f} ({drop}pts)")

            # Nivel 1: registrar caída como episodio
            self._memory.record(
                episode_type=self._EpisodeType.GSHI_DROP,
                title=f"GSHI drop {drop}pts en 1 ciclo",
                description=(
                    f"GSHI cayó de {prev_gshi:.1f} a {current:.1f}. "
                    f"SII={sii:.1f}"
                ),
                intention="Monitoreo continuo de salud",
                trigger="GSHI cycle",
                expected_outcome="GSHI estable o mejorando",
                expected_gshi_delta=-drop,
                tags=["gshi", "drop", "alert"],
            )
            self.redis.set("kernell:chronos:synthesis_trigger", "gshi_drop")
            self._tasks["synthesis"].trigger_immediate()

        # Nivel 2: actualizar confianza del sensor GSHI
        gshi_env = self._epistemic.wrap_gshi()
        self.redis.set(
            "kernell:epistemic:current:gshi",
            json.dumps(asdict(gshi_env) if hasattr(gshi_env, '__dict__') else {
                "confidence": gshi_env.confidence,
                "anomaly":    gshi_env.anomaly_flag,
            }),
        )

    def _task_synthesis(self):
        """Synthesis v2 con todos los niveles de razonamiento."""
        trigger = self._decode(self.redis.get("kernell:chronos:synthesis_trigger")) or "scheduled"
        self.redis.delete("kernell:chronos:synthesis_trigger")
        self._synthesis.synthesize(trigger=trigger)

    def _task_pfe_check(self):
        """
        PFE con gates epistémicos + análisis contrafactual.
        Pipeline extendido:
          1. Verificar gate epistémico (confianza en métricas)
          2. Análisis contrafactual del patch
          3. Si DANGEROUS → notificar y no procesar
          4. Si todo OK → proceder con PFE normal
        """
        pending_raw = self.redis.lrange("kernell:pfe:pending_proposals", 0, 0)
        if not pending_raw:
            return

        proposal = json.loads(pending_raw[0])

        # ── Nivel 2: Gate epistémico ──────────────────────────────────────
        drift_env = self._epistemic.wrap_drift()
        conf_env  = self._epistemic.wrap_confidence()
        gshi_env  = self._epistemic.wrap_gshi()

        pfe_scope = "L2" if proposal.get("target_layer") == "L2" else "L1"
        gate_action = f"pfe_{pfe_scope.lower()}_start"
        gate = self._epistemic.check_gate(
            action=gate_action,
            supporting_metrics=[drift_env, conf_env, gshi_env],
        )

        if not gate.allowed:
            logger.warning(
                f"[CHRONOS v2] PFE bloqueado por epistemic gate: {gate.reason}"
            )
            self.redis.lpush("kernell:pfe:blocked_log", json.dumps({
                "proposal_id": proposal.get("proposal_id", "?"),
                "reason":      f"Epistemic gate: {gate.reason}",
                "recommendation": gate.recommendation,
                "timestamp":   datetime.now(timezone.utc).isoformat(),
            }))
            return

        # ── SVS gate ──────────────────────────────────────────────────────
        can_run, reason, scope = self._svs.is_pfe_allowed()
        if not can_run:
            logger.debug(f"[CHRONOS v2] PFE bloqueado por SVS: {reason}")
            return

        # ── Nivel 3: Análisis contrafactual ───────────────────────────────
        patch_diff  = proposal.get("proposed_diff", "")
        patch_title = proposal.get("title", "Unnamed patch")
        patch_desc  = proposal.get("description", "")

        cf_report = self._cf.analyze_patch(
            proposal_id=proposal.get("proposal_id", "unknown"),
            patch_title=patch_title,
            patch_description=patch_desc,
            patch_diff=patch_diff,
            max_episodes=4,
        )

        if cf_report.overall_verdict == "DANGEROUS":
            logger.error(
                f"[CHRONOS v2] PFE BLOQUEADO por contrafactual DANGEROUS: "
                f"{cf_report.catastrophic_count} escenarios catastróficos. "
                f"{cf_report.historical_evidence_summary[:150]}"
            )
            self.redis.lpush("kernell:pfe:blocked_log", json.dumps({
                "proposal_id":    proposal.get("proposal_id"),
                "reason":         "Counterfactual DANGEROUS",
                "worst_case":     cf_report.worst_case,
                "evidence":       cf_report.historical_evidence_summary[:300],
                "timestamp":      datetime.now(timezone.utc).isoformat(),
            }))
            # No bloquear permanentemente — añadir a cola de revisión humana
            proposal["counterfactual_warning"] = cf_report.historical_evidence_summary
            proposal["counterfactual_verdict"] = cf_report.overall_verdict
            self.redis.rpush("kernell:pfe:needs_human_review", json.dumps(proposal))
            self.redis.lpop("kernell:pfe:pending_proposals")
            return

        if cf_report.overall_verdict == "RISKY":
            logger.warning(
                f"[CHRONOS v2] PFE con advertencia contrafactual RISKY: "
                f"{cf_report.historical_evidence_summary[:150]}"
            )
            proposal["counterfactual_warning"] = cf_report.historical_evidence_summary

        # ── Nivel 1: Registrar episodio del intento ───────────────────────
        ep = self._memory.record(
            episode_type=self._EpisodeType.PFE_PROMOTION,
            title=f"PFE iniciado: {patch_title}",
            description=patch_desc,
            intention=proposal.get("intention", "evolución del sistema"),
            trigger="Chronos PFE check",
            expected_outcome=proposal.get("expected_outcome", "mejora del sistema"),
            expected_gshi_delta=proposal.get("expected_gshi_delta"),
            patch_id=proposal.get("proposal_id"),
            author=proposal.get("author", "unknown"),
            tags=["pfe", pfe_scope.lower()],
        )
        proposal["episode_id"] = ep.episode_id

        # ── Ejecutar PFE ──────────────────────────────────────────────────
        self.redis.lpop("kernell:pfe:pending_proposals")

        from kernell.pfe_v2.pfe_orchestrator import PFEOrchestrator
        orchestrator = PFEOrchestrator(self.redis)
        result = orchestrator.run_evolution(proposal, pfe_scope=scope)

        # ── Post-PFE: actualizar episodio + síntesis ──────────────────────
        if result:
            if result.promoted:
                self.redis.set("kernell:chronos:synthesis_trigger", "post_pfe_promotion")
            # Marcar episodio para evaluación en 24h
            self.redis.rpush(
                "kernell:memory:pending_evaluation",
                json.dumps({
                    "episode_id": ep.episode_id,
                    "evaluate_after": (
                        datetime.now(timezone.utc) + timedelta(hours=24)
                    ).isoformat(),
                    "result": "promoted" if result.promoted else "blocked",
                }),
            )
            self._tasks["synthesis"].trigger_immediate()

    # ── Tareas nuevas ─────────────────────────────────────────────────────

    def _task_episode_evaluator(self):
        """
        Nivel 1: Cierra el loop episódico.
        Evalúa episodios que tienen ≥24h de antigüedad.
        """
        now = datetime.now(timezone.utc)
        queue_raw = self.redis.lrange("kernell:memory:pending_evaluation", 0, 19)
        evaluated = 0

        for raw in queue_raw:
            try:
                item = json.loads(raw)
                eval_after = datetime.fromisoformat(item["evaluate_after"])

                if now < eval_after:
                    continue

                ep_id  = item["episode_id"]
                result = item.get("result", "unknown")

                # Calcular outcome real
                actual_outcome = self._build_actual_outcome(ep_id, result)
                lessons = self._generate_lessons(ep_id)

                self._memory.evaluate(
                    episode_id=ep_id,
                    actual_outcome=actual_outcome,
                    lessons=lessons,
                )

                # Remover de la cola
                self.redis.lrem("kernell:memory:pending_evaluation", 1, raw)
                evaluated += 1

            except Exception as e:
                logger.error(f"[CHRONOS v2] Episode eval error: {e}")

        if evaluated > 0:
            logger.info(f"[CHRONOS v2] {evaluated} episodios evaluados")

    def _task_fine_tune_cycle(self):
        """
        Nivel 4: Dispara ciclo de self-training si hay suficiente data.
        """
        from core.reasoning.self_training_pipeline import TrainingStats, FineTuneProvider
        stats = TrainingStats(self.redis)
        summary = stats.summary()

        if not summary.get("ready_for_training"):
            logger.info(
                f"[CHRONOS v2] Self-training: {summary['evaluated_episodes']} episodios "
                f"evaluados, faltan {summary['examples_until_ready']} para fine-tune"
            )
            return

        logger.info(
            f"[CHRONOS v2] Iniciando ciclo de self-training "
            f"({summary['evaluated_episodes']} episodios)"
        )
        job = self._ft.run_cycle(provider=FineTuneProvider.TOGETHER_AI)
        if job:
            logger.info(f"[CHRONOS v2] Fine-tune job iniciado: {job.job_id}")
            self._memory.record(
                episode_type=self._EpisodeType.EVOLUTION,
                title=f"Self-training fine-tune iniciado",
                description=(
                    f"Fine-tune con {job.examples_used} ejemplos "
                    f"en {job.provider}"
                ),
                intention="Especializar modelo de razonamiento en Kernell",
                trigger="Chronos fine_tune_cycle",
                expected_outcome="Modelo más preciso para análisis específico de Kernell",
                tags=["self_training", "fine_tune", job.provider],
            )

    def _task_epistemic_monitor(self):
        """
        Nivel 2: Actualiza fiabilidad de sensores basado en historial.
        Detecta sensores que producen valores anómalos consistentemente.
        """
        for metric in ["drift", "confidence"]:
            env = (
                self._epistemic.wrap_drift()
                if metric == "drift"
                else self._epistemic.wrap_confidence()
            )

            current_rel = float(
                self.redis.get(f"kernell:epistemic:reliability:{metric}") or 0.80
            )

            # Si hay anomalía, reducir fiabilidad levemente
            if env.anomaly_flag:
                new_rel = max(0.30, current_rel * 0.95)
            else:
                # Recuperación gradual
                new_rel = min(0.95, current_rel + 0.01)

            self.redis.set(f"kernell:epistemic:reliability:{metric}", str(round(new_rel, 4)))

            if new_rel < 0.50:
                logger.warning(
                    f"[EPISTEMIC] Sensor '{metric}' fiabilidad baja: {new_rel:.2f} "
                    f"— datos pueden no ser confiables"
                )

    def _task_red_team(self):
        self._red_team.run_single_attack()

    def _task_heartbeat(self):
        self.redis.set(
            "kernell:chronos:v2:heartbeat",
            json.dumps({
                "layer":     self.layer,
                "running":   self._running,
                "version":   "v2",
                "tasks":     {n: t.status()["last_result"] for n, t in self._tasks.items()},
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }),
            ex=120,
        )

    # ══════════════════════════════════════════════════════════════════════
    # LOOP PRINCIPAL
    # ══════════════════════════════════════════════════════════════════════

    def start(self):
        self._running = True
        logger.info(
            f"[CHRONOS v2] ═══ Iniciando — layer={self.layer} "
            f"tareas={list(self._tasks.keys())} ═══"
        )
        self._tasks["svs"].trigger_immediate()
        self._tasks["gshi"].trigger_immediate()

        while self._running:
            for task in self._tasks.values():
                if task.should_run():
                    threading.Thread(
                        target=task.run,
                        name=f"chronos2-{task.name}",
                        daemon=True,
                    ).start()
            time.sleep(5)

        logger.info("[CHRONOS v2] ═══ Detenido ═══")

    def stop(self):
        self._running = False

    def _signal_handler(self, sig, frame):
        logger.info(f"[CHRONOS v2] Señal {sig} — shutdown limpio")
        self.stop()
        sys.exit(0)

    # ══════════════════════════════════════════════════════════════════════
    # HELPERS
    # ══════════════════════════════════════════════════════════════════════

    def _build_actual_outcome(self, episode_id: str, result: str) -> str:
        gshi_raw  = self.redis.get("kernell:gshi:v2:current")
        gshi_now  = json.loads(gshi_raw).get("gshi_ema", "?") if gshi_raw else "?"
        mode_raw  = self.redis.get("kernell:drift:mode_signal")
        mode_now  = (mode_raw if isinstance(mode_raw,str) else mode_raw.decode()) if mode_raw else "?"
        return (
            f"Resultado PFE: {result}. "
            f"Estado actual 24h después — GSHI: {gshi_now}, modo: {mode_now}."
        )

    def _generate_lessons(self, episode_id: str) -> list[str]:
        """Genera lecciones a partir del outcome 24h después."""
        raw = self.redis.get(f"kernell:memory:episode:{episode_id}")
        if not raw:
            return []
        try:
            ep_data = json.loads(raw)
            ep_type = ep_data.get("episode_type", "")
            result  = ep_data.get("actual_outcome", "")
            if "promoted" in result:
                return ["PFE completado exitosamente — shadow deployment fue suficiente"]
            elif "blocked" in result:
                return ["PFE bloqueado — revisar condiciones del sistema antes del próximo intento"]
            return []
        except Exception:
            return []

    def _calculate_sii(self) -> float:
        rt_raw    = self.redis.lrange("kernell:red_team:attacks", 0, 49)
        if rt_raw:
            attacks   = [json.loads(a) for a in rt_raw]
            detected  = sum(1 for a in attacks if a.get("detected"))
            inv_str   = (detected / len(attacks) * 100) if attacks else 75.0
        else:
            inv_str   = 75.0
        rec_eff  = float(self.redis.get("kernell:system:recovery_efficiency") or 70)
        drift_std = float(self.redis.get("kernell:drift:std_30d") or 10)
        drift_stab = max(0, min(100, 100 - (drift_std - 5) * 4)) if drift_std > 5 else 100
        sii = 0.35*inv_str + 0.30*rec_eff + 0.35*drift_stab
        return round(min(100, max(0, sii)), 2)

    def _get_prev_gshi(self) -> Optional[float]:
        history = self.redis.lrange("kernell:gshi:v2:history", 1, 1)
        if history:
            return json.loads(history[0]).get("gshi_ema")
        return None

    def _get_system_secret(self) -> str:
        raw = self.redis.get("kernell:system:secret")
        if raw:
            return raw if isinstance(raw,str) else raw.decode()
        import secrets
        s = secrets.token_hex(32)
        self.redis.set("kernell:system:secret", s)
        return s

    def _decode(self, raw) -> Optional[str]:
        if raw is None: return None
        return raw if isinstance(raw,str) else raw.decode()

    def trigger_svs(self):       self._tasks["svs"].trigger_immediate()
    def trigger_synthesis(self, r="manual"):
        self.redis.set("kernell:chronos:synthesis_trigger", r)
        self._tasks["synthesis"].trigger_immediate()
    def trigger_evaluation(self): self._tasks["episode_evaluator"].trigger_immediate()
    def trigger_fine_tune(self):  self._tasks["fine_tune_cycle"].trigger_immediate()
    def status(self) -> dict:
        return {
            "version": "v2", "layer": self.layer,
            "running": self._running,
            "tasks":   {n: t.status() for n, t in self._tasks.items()},
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def pause_all(self):
        for t in self._tasks.values(): t.pause()
    def resume_all(self):
        for t in self._tasks.values(): t.resume()


def main():
    import argparse
    parser = argparse.ArgumentParser(description="Kernell OS Chronos v2")
    parser.add_argument("--layer",     default="core", choices=["core","enterprise","platform"])
    parser.add_argument("--redis-url", default="redis://localhost:6379")
    parser.add_argument("--log-level", default="INFO")
    args = parser.parse_args()

    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s %(name)-35s %(levelname)s %(message)s",
    )
    r = redis.from_url(args.redis_url, decode_responses=False)
    ChronosV2(r, layer=args.layer).start()


# Para poder importar asdict correctamente
def asdict(obj):
    if hasattr(obj, '__dataclass_fields__'):
        import dataclasses
        return dataclasses.asdict(obj)
    return obj.__dict__ if hasattr(obj, '__dict__') else {}


if __name__ == "__main__":
    main()
