"""
KERNELL OS — REASONING STACK COMPLETO
======================================
Fachada de integración de los 4 niveles de razonamiento.

Uso:
  from kernell.reasoning import ReasoningStack

  stack = ReasoningStack(redis_client)
  stack.bootstrap()

  # Nivel 1: Episodic Memory
  stack.record_episode(...)
  stack.recall_similar(query)

  # Nivel 2: Epistemic Uncertainty
  envelope = stack.wrap_drift()
  gate     = stack.check_gate("kill_switch_activate")

  # Nivel 3: Counterfactual
  cf_report = stack.analyze_patch_counterfactual(proposal)

  # Nivel 4: Self-training
  job = stack.run_self_training_cycle()

  # Full synthesis (usa los 4 niveles)
  report = stack.synthesize(trigger="manual")
"""

import json
import logging
import redis
from datetime import datetime, timezone
from typing import Optional

from core.reasoning.episodic_memory import (
    EpisodicMemory, EpisodeType, CausalEpisode
)
from core.reasoning.epistemic_uncertainty import (
    EpistemicUncertaintyEngine, UncertaintyEnvelope, EpistemicDecision
)
from core.reasoning.counterfactual_reasoner import (
    CounterfactualReasoner, CounterfactualReport
)
from core.reasoning.self_training_pipeline import (
    FineTuningOrchestrator, TrainingStats, FineTuneProvider, FineTuneJob
)
from core.reasoning.synthesis_agent_v2 import (
    SynthesisAgentV2, SynthesisReportV2
)

logger = logging.getLogger("kernell.reasoning")


class ReasoningStack:
    """
    Punto de entrada único para todos los niveles de razonamiento.
    Inicializa y conecta los 4 módulos.
    """

    def __init__(self, redis_client: redis.Redis):
        self.redis     = redis_client
        self._memory   = EpisodicMemory(redis_client)
        self._epistemic = EpistemicUncertaintyEngine(redis_client)
        self._cf       = CounterfactualReasoner(redis_client)
        self._ft       = FineTuningOrchestrator(redis_client)
        self._synthesis = SynthesisAgentV2(redis_client)
        self._stats    = TrainingStats(redis_client)

    # ── Nivel 1 ───────────────────────────────────────────────────────────

    def record_episode(
        self,
        episode_type: EpisodeType,
        title: str,
        description: str,
        intention: str,
        trigger: str,
        expected_outcome: str,
        **kwargs,
    ) -> CausalEpisode:
        return self._memory.record(
            episode_type=episode_type,
            title=title,
            description=description,
            intention=intention,
            trigger=trigger,
            expected_outcome=expected_outcome,
            **kwargs,
        )

    def evaluate_episode(self, episode_id: str, actual_outcome: str, lessons: list[str] = None):
        return self._memory.evaluate(episode_id, actual_outcome, lessons)

    def recall_similar(self, query: str, top_k: int = 5):
        return self._memory.recall(query, top_k=top_k)

    def recall_current_context(self, top_k: int = 3):
        return self._memory.recall_similar_to_current(top_k=top_k)

    def get_lessons(self, episode_type: EpisodeType = None) -> list[str]:
        return self._memory.get_lessons(episode_type)

    def memory_stats(self) -> dict:
        return self._memory.stats()

    # ── Nivel 2 ───────────────────────────────────────────────────────────

    def wrap_drift(self) -> UncertaintyEnvelope:
        return self._epistemic.wrap_drift()

    def wrap_confidence(self) -> UncertaintyEnvelope:
        return self._epistemic.wrap_confidence()

    def wrap_gshi(self) -> UncertaintyEnvelope:
        return self._epistemic.wrap_gshi()

    def wrap_trust(self, agent_name: str) -> UncertaintyEnvelope:
        return self._epistemic.wrap_trust_score(agent_name)

    def check_gate(self, action: str, metrics: list = None) -> EpistemicDecision:
        return self._epistemic.check_gate(action, metrics)

    def check_all_gates(self) -> dict:
        return self._epistemic.check_all_gates()

    def epistemic_health(self) -> dict:
        """Resumen del estado epistémico del sistema."""
        gates     = self.check_all_gates()
        available = sum(1 for g in gates.values() if g.allowed)
        return {
            "gates_available": available,
            "gates_total":     len(gates),
            "drift_confidence": self.wrap_drift().confidence,
            "gshi_confidence":  self.wrap_gshi().confidence,
            "critical_gates_blocked": [
                name for name, g in gates.items()
                if not g.allowed and "critical" in name or "kill_switch" in name
            ],
        }

    # ── Nivel 3 ───────────────────────────────────────────────────────────

    def analyze_patch_counterfactual(
        self,
        proposal_id: str,
        patch_title: str,
        patch_description: str,
        patch_diff: str,
        max_episodes: int = 5,
    ) -> CounterfactualReport:
        return self._cf.analyze_patch(
            proposal_id=proposal_id,
            patch_title=patch_title,
            patch_description=patch_description,
            patch_diff=patch_diff,
            max_episodes=max_episodes,
        )

    def get_counterfactual_report(self, proposal_id: str) -> Optional[CounterfactualReport]:
        return self._cf.get_report(proposal_id)

    # ── Nivel 4 ───────────────────────────────────────────────────────────

    def run_self_training_cycle(
        self,
        provider: FineTuneProvider = FineTuneProvider.TOGETHER_AI,
        force: bool = False,
    ) -> Optional[FineTuneJob]:
        return self._ft.run_cycle(provider=provider, force=force)

    def training_stats(self) -> dict:
        return self._stats.summary()

    # ── Synthesis (todos los niveles) ─────────────────────────────────────

    def synthesize(self, trigger: str = "manual") -> Optional[SynthesisReportV2]:
        return self._synthesis.synthesize(trigger=trigger)

    # ── Estado completo ───────────────────────────────────────────────────

    def status(self) -> dict:
        ts = self.training_stats()
        ep = self.epistemic_health()
        ms = self.memory_stats()

        return {
            "reasoning_stack_version": "v1.0",
            "timestamp":               datetime.now(timezone.utc).isoformat(),
            "level_1_episodic": {
                "total_episodes":    ms.get("total_episodes"),
                "evaluated":         ms.get("evaluated"),
                "positive_outcomes": ms.get("positive_outcomes"),
                "qdrant_enabled":    ms.get("qdrant_enabled"),
            },
            "level_2_epistemic": {
                "drift_confidence": ep.get("drift_confidence"),
                "gshi_confidence":  ep.get("gshi_confidence"),
                "gates_available":  f"{ep.get('gates_available')}/{ep.get('gates_total')}",
                "critical_blocked": ep.get("critical_gates_blocked"),
            },
            "level_3_counterfactual": {
                "reports_total": self.redis.llen("kernell:counterfactual:history"),
            },
            "level_4_self_training": {
                "episodes_evaluated":  ts.get("evaluated_episodes"),
                "ready_for_training":  ts.get("ready_for_training"),
                "models_deployed":     ts.get("models_deployed"),
                "examples_until_ready": ts.get("examples_until_ready"),
            },
        }

    def print_status(self):
        s = self.status()
        l1 = s["level_1_episodic"]
        l2 = s["level_2_epistemic"]
        l3 = s["level_3_counterfactual"]
        l4 = s["level_4_self_training"]

        print(f"""
╔══════════════════════════════════════════════════════════╗
║  KERNELL OS — REASONING STACK STATUS                     ║
╠══════════════════════════════════════════════════════════╣
║  L1 EPISODIC MEMORY                                      ║
║    Episodios: {str(l1['total_episodes']):<10} Evaluados: {str(l1['evaluated']):<10}         ║
║    Outcomes positivos: {str(l1['positive_outcomes']):<7} Qdrant: {str(l1['qdrant_enabled']):<10}   ║
╠══════════════════════════════════════════════════════════╣
║  L2 EPISTEMIC UNCERTAINTY                                ║
║    Drift conf: {str(l2['drift_confidence']):<8} GSHI conf: {str(l2['gshi_confidence']):<14}  ║
║    Gates: {str(l2['gates_available']):<14}                              ║
║    Bloqueados: {str(l2['critical_blocked']):<39}║
╠══════════════════════════════════════════════════════════╣
║  L3 COUNTERFACTUAL                                       ║
║    Análisis realizados: {str(l3['reports_total']):<30}      ║
╠══════════════════════════════════════════════════════════╣
║  L4 SELF-TRAINING                                        ║
║    Episodios evaluados: {str(l4['episodes_evaluated']):<7}                        ║
║    Listo para fine-tune: {str(l4['ready_for_training']):<7}                      ║
║    Modelos desplegados: {str(l4['models_deployed']):<8}                         ║
║    Faltan: {str(l4['examples_until_ready'])} episodios más                           ║
╚══════════════════════════════════════════════════════════╝
""")
