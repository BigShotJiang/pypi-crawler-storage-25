"""
SELF-TRAINING PIPELINE — Kernell Genera Sus Propios Datos
==========================================================
Nivel 4 del razonamiento profundo. El salto de paradigma.

PROBLEMA FUNDAMENTAL:
  Kernell usa modelos que razonan (R1, Gemini, Claude).
  Ninguno de esos modelos fue entrenado sobre Kernell.
  Cuando R1 razona sobre un patch, razona en general —
  no tiene el contexto profundo de 6 meses de incidentes,
  patrones específicos, lecciones aprendidas, el North Star.

SOLUCIÓN:
  Kernell genera su propia data de entrenamiento
  a partir de episodios evaluados + reasoning traces + outcomes.

  Luego hace fine-tuning de un modelo base (Llama 3 70B u otro)
  con esa data. El resultado es un modelo que razona
  específicamente sobre Kernell, con su historia y contexto.

  No es más inteligente en general.
  Es más inteligente sobre ESTE sistema.

PIPELINE:
  1. EpisodeLabeler
     Evalúa episodios pasados y los etiqueta como buenos/malos
     basándose en outcomes reales (GSHI delta, incidentes posteriores).

  2. TrainingDataGenerator
     Convierte episodios etiquetados en pares de entrenamiento:
     (situación → razonamiento correcto → decisión correcta)
     Formato compatible con OpenAI fine-tuning API / Axolotl.

  3. QualityFilter
     Filtra pares de baja calidad: reasoning incoherente,
     outcomes ambiguos, episodios no evaluados.

  4. FineTuningOrchestrator
     Dispara el fine-tuning cuando hay suficiente data nueva.
     Soporta: OpenAI (gpt-4o-mini), Together AI (Llama 3),
     Replicate, o local via Ollama + Axolotl.

  5. ModelEvaluator
     Evalúa el modelo fine-tuneado contra benchmarks internos
     antes de activarlo en el pipeline de Forge/Synthesis.

DATA TARGET:
  ≥ 100 episodios evaluados → primer fine-tune
  ≥ 500 episodios → modelo empieza a superar a R1 en tareas específicas
  ≥ 2000 episodios → modelo con comprensión profunda del sistema

COSTOS ESTIMADOS:
  OpenAI gpt-4o-mini fine-tune: ~$3-8 por 100 ejemplos
  Together AI Llama 3 70B: ~$0.80 por 100 ejemplos
  Local Ollama (hardware propio): $0
"""

import json
import logging
import redis
import hashlib
from dataclasses import dataclass, asdict
from datetime import datetime, timezone, timedelta
from typing import Optional
from enum import Enum

from core.reasoning.episodic_memory import (
    EpisodicMemory, CausalEpisode, EpisodeType, EpisodeOutcome
)

logger = logging.getLogger("kernell.self_training")


class FineTuneProvider(Enum):
    OPENAI        = "openai"         # gpt-4o-mini — ~$5/100 ejemplos
    TOGETHER_AI   = "together_ai"    # Llama 3 70B — ~$0.80/100 ejemplos
    REPLICATE     = "replicate"      # Varios modelos
    LOCAL_AXOLOTL = "local_axolotl"  # Fine-tune local (sin costo)
    LOCAL_OLLAMA  = "local_ollama"   # Servir modelo fine-tuneado localmente


FINE_TUNE_MIN_EXAMPLES = 50    # Mínimo para un fine-tune útil
QUALITY_MIN_SCORE      = 0.65  # Score mínimo para incluir ejemplo


@dataclass
class TrainingExample:
    """
    Un par de entrenamiento generado desde un episodio real.
    Compatible con formato de fine-tuning de OpenAI y Together AI.
    """
    example_id: str
    source_episode_id: str
    episode_type: str

    # Input al modelo (situación que el modelo debe analizar)
    system_prompt: str
    user_content: str

    # Output esperado (razonamiento correcto + decisión)
    assistant_response: str

    # Metadata de calidad
    quality_score: float        # 0-1, basado en la calidad del episodio
    outcome_quality: str        # Del episodio fuente
    includes_reasoning_trace: bool  # Si el assistant_response tiene chain-of-thought
    generated_at: str


@dataclass
class TrainingDataset:
    dataset_id: str
    version: str
    created_at: str
    examples_total: int
    examples_filtered: int        # Después de quality filter
    by_episode_type: dict
    by_outcome: dict
    avg_quality_score: float
    ready_for_finetuning: bool
    fine_tune_provider: str
    file_path: Optional[str]      # Ruta al JSONL generado


@dataclass
class FineTuneJob:
    job_id: str
    provider: str
    model_base: str
    dataset_id: str
    examples_used: int
    status: str                   # "pending"|"running"|"completed"|"failed"
    fine_tuned_model_id: Optional[str]
    evaluation_score: Optional[float]
    deployed: bool
    started_at: str
    completed_at: Optional[str]


# ══════════════════════════════════════════════════════════════════════════
# EPISODE LABELER
# ══════════════════════════════════════════════════════════════════════════

class EpisodeLabeler:
    """
    Etiqueta episodios históricos con señal de entrenamiento.
    Un episodio es un buen ejemplo de entrenamiento cuando:
      - Está evaluado (tiene outcome real)
      - El razonamiento fue correcto (predicción ≈ realidad)
      - O el razonamiento fue incorrecto de manera informativa
        (el modelo falló → aprendemos exactamente cómo)
    """

    def __init__(self, redis_client: redis.Redis):
        self.redis  = redis_client
        self.memory = EpisodicMemory(redis_client)

    def label_all(self) -> list[tuple[CausalEpisode, float]]:
        """
        Recupera todos los episodios evaluados y calcula su score
        de valor para el entrenamiento.

        Returns: [(episode, quality_score)]
        """
        index = self.redis.lrange("kernell:memory:episodes:index", 0, 999)
        labeled = []

        for raw in index:
            ep_id = raw if isinstance(raw, str) else raw.decode()
            raw_data = self.redis.get(f"kernell:memory:episode:{ep_id}")
            if not raw_data:
                continue
            try:
                ep = CausalEpisode(**json.loads(raw_data))
            except Exception:
                continue

            if not ep.evaluated:
                continue

            score = self._score_episode(ep)
            if score >= QUALITY_MIN_SCORE:
                labeled.append((ep, score))

        labeled.sort(key=lambda x: x[1], reverse=True)
        logger.info(f"[LABELER] {len(labeled)} episodios listos para entrenamiento")
        return labeled

    def _score_episode(self, ep: CausalEpisode) -> float:
        score = 0.5   # Base

        # Episodios evaluados con outcomes claros valen más
        if ep.outcome_quality == EpisodeOutcome.POSITIVE.value:
            score += 0.2
        elif ep.outcome_quality == EpisodeOutcome.NEGATIVE.value:
            score += 0.15   # Fallos informativos también valen
        elif ep.outcome_quality == EpisodeOutcome.NEUTRAL.value:
            score += 0.10

        # Con hindsight = el sistema ya reflexionó sobre este episodio
        if ep.hindsight:
            score += 0.15

        # Con lecciones explícitas
        if ep.lessons:
            score += min(0.10, len(ep.lessons) * 0.03)

        # Episodios de alta gravedad son más informativos
        if ep.episode_type in (
            EpisodeType.INCIDENT.value,
            EpisodeType.GSHI_DROP.value,
            EpisodeType.RED_TEAM_HIT.value,
        ):
            score += 0.10

        # Penalizar si delta GSHI fue muy ambiguo
        if ep.actual_gshi_delta is not None and abs(ep.actual_gshi_delta) < 1:
            score -= 0.05

        return round(min(1.0, score), 3)


# ══════════════════════════════════════════════════════════════════════════
# TRAINING DATA GENERATOR
# ══════════════════════════════════════════════════════════════════════════

class TrainingDataGenerator:
    """
    Convierte episodios etiquetados en pares de entrenamiento.
    Genera múltiples tipos de pares para cubrir diferentes tareas.
    """

    # System prompts por tarea de entrenamiento
    SYSTEM_FORGE_OPPOSITION = (
        "Eres FORGE_B de Kernell OS, opositor estructural. "
        "Tu rol es encontrar fallas en patches propuestos. "
        "Responde en JSON: {\"vote\":\"APPROVE\"|\"REJECT\"|\"ABSTAIN\","
        "\"confidence\":0.0-1.0,\"reasoning\":\"\",\"concerns\":[],\"suggestions\":[]}"
    )

    SYSTEM_SYNTHESIS = (
        "Eres el Agente de Síntesis de Kernell OS. "
        "Razona profundamente sobre el estado del sistema y detecta "
        "patrones causales que las métricas no revelan. "
        "Responde en JSON con: health_narrative, hidden_risks, "
        "causal_chains, recommended_focus, urgency."
    )

    SYSTEM_AUDIT_SECURITY = (
        "Eres AUDIT_SECURITY de Kernell OS. "
        "Detecta vulnerabilidades, race conditions, y attack vectors en patches. "
        "Responde en JSON con: vote, confidence, reasoning, vulnerabilities_found, risk_score."
    )

    SYSTEM_COUNTERFACTUAL = (
        "Eres el Razonador Contrafactual de Kernell OS. "
        "Dados un episodio histórico y un patch hipotético, "
        "razona causalmente qué hubiera ocurrido. "
        "Responde en JSON con: verdict, confidence, reasoning, "
        "critical_conditions, recommendation."
    )

    def __init__(self, redis_client: redis.Redis):
        self.redis = redis_client

    def generate(
        self,
        labeled_episodes: list[tuple[CausalEpisode, float]],
    ) -> list[TrainingExample]:
        """
        Genera ejemplos de entrenamiento desde episodios etiquetados.
        Cada episodio puede generar múltiples ejemplos (diferentes tareas).
        """
        examples = []

        for episode, score in labeled_episodes:
            # 1. Ejemplo de Synthesis (razonamiento sobre estado)
            synth_ex = self._generate_synthesis_example(episode, score)
            if synth_ex:
                examples.append(synth_ex)

            # 2. Ejemplo de Forge Opposition (si es PFE)
            if episode.episode_type in (
                EpisodeType.PFE_PROMOTION.value,
                EpisodeType.PFE_REJECTION.value,
            ):
                forge_ex = self._generate_forge_example(episode, score)
                if forge_ex:
                    examples.append(forge_ex)

            # 3. Ejemplo de Audit Security (si es incidente o PFE con vulnerabilidad)
            if episode.episode_type in (
                EpisodeType.INCIDENT.value,
                EpisodeType.RED_TEAM_HIT.value,
            ):
                audit_ex = self._generate_audit_example(episode, score)
                if audit_ex:
                    examples.append(audit_ex)

            # 4. Ejemplo contrafactual (si tiene snapshot_after)
            if episode.snapshot_after and episode.evaluated:
                cf_ex = self._generate_counterfactual_example(episode, score)
                if cf_ex:
                    examples.append(cf_ex)

        logger.info(
            f"[GENERATOR] {len(examples)} ejemplos generados "
            f"desde {len(labeled_episodes)} episodios"
        )
        return examples

    def _generate_synthesis_example(
        self, ep: CausalEpisode, score: float
    ) -> Optional[TrainingExample]:
        if not ep.hindsight:
            return None

        before = ep.snapshot_before
        user_content = (
            f"ESTADO DEL SISTEMA:\n"
            f"GSHI: {before.get('gshi','?')} | Modo: {before.get('mode','?')} | "
            f"Drift: {before.get('drift','?')} | Conf: {before.get('confidence','?')}\n"
            f"DEFCON: {before.get('defcon','?')} | SCI: {before.get('sci','?')}\n\n"
            f"Tipo de evento previo: {ep.episode_type}\n"
            f"Trigger: {ep.trigger}\n\n"
            "¿Qué análisis narrativo realizas de este estado?"
        )

        # La respuesta correcta incluye el hindsight real + lecciones
        correct_analysis = {
            "health_narrative": ep.hindsight,
            "hidden_risks": [ep.actual_outcome] if ep.actual_outcome else [],
            "causal_chains": [ep.intention + " → " + (ep.actual_outcome or "")],
            "recommended_focus": (
                ep.lessons[0] if ep.lessons else ep.hindsight[:100]
            ),
            "urgency": self._outcome_to_urgency(ep.outcome_quality),
            "confidence": score,
        }

        return TrainingExample(
            example_id=f"synth_{ep.episode_id}",
            source_episode_id=ep.episode_id,
            episode_type=ep.episode_type,
            system_prompt=self.SYSTEM_SYNTHESIS,
            user_content=user_content,
            assistant_response=json.dumps(correct_analysis, ensure_ascii=False),
            quality_score=score,
            outcome_quality=ep.outcome_quality,
            includes_reasoning_trace=False,
            generated_at=datetime.now(timezone.utc).isoformat(),
        )

    def _generate_forge_example(
        self, ep: CausalEpisode, score: float
    ) -> Optional[TrainingExample]:
        """
        Si el patch fue rechazado → el rechazo es el output correcto.
        Si fue promovido pero tuvo outcome NEGATIVO → debió rechazarse.
        """
        if not ep.description:
            return None

        was_promoted = ep.episode_type == EpisodeType.PFE_PROMOTION.value
        outcome_bad  = ep.outcome_quality == EpisodeOutcome.NEGATIVE.value

        correct_vote = "REJECT" if (not was_promoted or outcome_bad) else "APPROVE"
        reasoning = (
            f"{ep.hindsight or ep.actual_outcome or ep.description}. "
            f"GSHI delta real: {ep.actual_gshi_delta}."
        )

        concerns = []
        if outcome_bad:
            concerns.append(f"Outcome real negativo: {ep.actual_outcome[:100]}")
        concerns.extend(ep.lessons[:2])

        response = json.dumps({
            "vote": correct_vote,
            "confidence": score,
            "reasoning": reasoning,
            "concerns": concerns,
            "suggestions": [],
        }, ensure_ascii=False)

        user_content = (
            f"PROPUESTA DE EVOLUCIÓN\n"
            f"{'='*40}\n"
            f"Título: {ep.title}\n"
            f"Descripción: {ep.description}\n"
            f"Intención: {ep.intention}\n"
            f"Patch ID: {ep.patch_id or 'N/A'}\n\n"
            f"CONTEXTO DEL SISTEMA:\n"
            f"GSHI: {ep.snapshot_before.get('gshi','?')} | "
            f"Modo: {ep.snapshot_before.get('mode','?')}\n"
            "Evalúa este patch desde tu perspectiva."
        )

        return TrainingExample(
            example_id=f"forge_{ep.episode_id}",
            source_episode_id=ep.episode_id,
            episode_type=ep.episode_type,
            system_prompt=self.SYSTEM_FORGE_OPPOSITION,
            user_content=user_content,
            assistant_response=response,
            quality_score=score,
            outcome_quality=ep.outcome_quality,
            includes_reasoning_trace=False,
            generated_at=datetime.now(timezone.utc).isoformat(),
        )

    def _generate_audit_example(
        self, ep: CausalEpisode, score: float
    ) -> Optional[TrainingExample]:
        if ep.episode_type not in (
            EpisodeType.INCIDENT.value, EpisodeType.RED_TEAM_HIT.value
        ):
            return None

        vulnerabilities = ep.lessons[:3] if ep.lessons else [ep.description[:100]]

        response = json.dumps({
            "vote": "REJECT",
            "confidence": score,
            "reasoning": ep.hindsight or ep.description,
            "vulnerabilities_found": vulnerabilities,
            "risk_score": 80 if ep.outcome_quality == EpisodeOutcome.NEGATIVE.value else 60,
        }, ensure_ascii=False)

        user_content = (
            f"AUDITORÍA DE SEGURIDAD\n"
            f"Tipo de incidente: {ep.episode_type}\n"
            f"Descripción: {ep.description}\n"
            f"Estado cuando ocurrió:\n"
            f"  Drift: {ep.snapshot_before.get('drift','?')} | "
            f"Conf: {ep.snapshot_before.get('confidence','?')}\n"
            "¿Qué vulnerabilidades identificas?"
        )

        return TrainingExample(
            example_id=f"audit_{ep.episode_id}",
            source_episode_id=ep.episode_id,
            episode_type=ep.episode_type,
            system_prompt=self.SYSTEM_AUDIT_SECURITY,
            user_content=user_content,
            assistant_response=response,
            quality_score=score,
            outcome_quality=ep.outcome_quality,
            includes_reasoning_trace=False,
            generated_at=datetime.now(timezone.utc).isoformat(),
        )

    def _generate_counterfactual_example(
        self, ep: CausalEpisode, score: float
    ) -> Optional[TrainingExample]:
        if not ep.snapshot_after:
            return None

        before = ep.snapshot_before
        after  = ep.snapshot_after
        gshi_delta = ep.actual_gshi_delta or 0

        verdict = (
            "WORSE" if gshi_delta < -5 else
            "BETTER" if gshi_delta > 5 else
            "NEUTRAL"
        )

        response = json.dumps({
            "verdict": verdict,
            "confidence": score,
            "reasoning": ep.hindsight or ep.actual_outcome,
            "critical_conditions": ep.lessons[:2],
            "patch_assumptions_violated": [],
            "hypothetical_gshi_delta": gshi_delta,
            "hypothetical_outcome": ep.actual_outcome or ep.description,
            "recommendation": (
                "REJECT_PATCH" if verdict == "WORSE" else
                "APPROVE" if verdict == "BETTER" else
                "CONDITIONAL_APPROVAL"
            ),
        }, ensure_ascii=False)

        user_content = (
            f"ANÁLISIS CONTRAFACTUAL\n"
            f"EPISODIO REAL:\n"
            f"  Tipo: {ep.episode_type} | '{ep.title}'\n"
            f"  Estado antes: GSHI={before.get('gshi','?')} "
            f"Drift={before.get('drift','?')} Modo={before.get('mode','?')}\n"
            f"  Estado después: GSHI={after.get('gshi','?')} "
            f"Drift={after.get('drift','?')}\n"
            f"GSHI delta real: {gshi_delta}\n\n"
            "Si un patch de optimización hubiera estado activo, "
            "¿hubiera mejorado o empeorado este outcome?"
        )

        return TrainingExample(
            example_id=f"cf_{ep.episode_id}",
            source_episode_id=ep.episode_id,
            episode_type=ep.episode_type,
            system_prompt=self.SYSTEM_COUNTERFACTUAL,
            user_content=user_content,
            assistant_response=response,
            quality_score=score,
            outcome_quality=ep.outcome_quality,
            includes_reasoning_trace=False,
            generated_at=datetime.now(timezone.utc).isoformat(),
        )

    def _outcome_to_urgency(self, outcome: str) -> str:
        return {
            EpisodeOutcome.POSITIVE.value: "LOW",
            EpisodeOutcome.NEUTRAL.value:  "MEDIUM",
            EpisodeOutcome.NEGATIVE.value: "HIGH",
        }.get(outcome, "MEDIUM")


# ══════════════════════════════════════════════════════════════════════════
# FINE-TUNING ORCHESTRATOR
# ══════════════════════════════════════════════════════════════════════════

class FineTuningOrchestrator:
    """
    Orquesta el ciclo completo de fine-tuning:
    episodios → dataset → fine-tune → evaluación → deploy.
    """

    def __init__(self, redis_client: redis.Redis):
        self.redis     = redis_client
        self.labeler   = EpisodeLabeler(redis_client)
        self.generator = TrainingDataGenerator(redis_client)

    def run_cycle(
        self,
        provider: FineTuneProvider = FineTuneProvider.TOGETHER_AI,
        force: bool = False,
    ) -> Optional[FineTuneJob]:
        """
        Ejecuta un ciclo completo de fine-tuning si hay suficiente data nueva.

        Args:
            provider: Dónde hacer el fine-tune
            force: Ignorar el check de mínimo de ejemplos
        """
        labeled   = self.labeler.label_all()
        examples  = self.generator.generate(labeled)

        if len(examples) < FINE_TUNE_MIN_EXAMPLES and not force:
            logger.info(
                f"[FINE-TUNE] {len(examples)} ejemplos < mínimo {FINE_TUNE_MIN_EXAMPLES} "
                f"— esperando más episodios evaluados"
            )
            return None

        dataset  = self._build_dataset(examples, provider)
        jsonl    = self._export_jsonl(dataset, examples)
        job      = self._submit_fine_tune(dataset, jsonl, provider)

        self._persist_job(job)
        logger.info(
            f"[FINE-TUNE] Job iniciado: {job.job_id} "
            f"({len(examples)} ejemplos, provider={provider.value})"
        )
        return job

    def _build_dataset(
        self, examples: list[TrainingExample], provider: FineTuneProvider
    ) -> TrainingDataset:
        import uuid

        by_type    = {}
        by_outcome = {}
        for ex in examples:
            by_type[ex.episode_type]       = by_type.get(ex.episode_type, 0) + 1
            by_outcome[ex.outcome_quality] = by_outcome.get(ex.outcome_quality, 0) + 1

        avg_q = sum(e.quality_score for e in examples) / len(examples) if examples else 0

        version = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M")
        return TrainingDataset(
            dataset_id=str(uuid.uuid4())[:8],
            version=version,
            created_at=datetime.now(timezone.utc).isoformat(),
            examples_total=len(examples),
            examples_filtered=len(examples),
            by_episode_type=by_type,
            by_outcome=by_outcome,
            avg_quality_score=round(avg_q, 3),
            ready_for_finetuning=len(examples) >= FINE_TUNE_MIN_EXAMPLES,
            fine_tune_provider=provider.value,
            file_path=None,
        )

    def _export_jsonl(
        self, dataset: TrainingDataset, examples: list[TrainingExample]
    ) -> str:
        """
        Exporta el dataset en formato JSONL compatible con OpenAI y Together AI.
        """
        import tempfile, os
        path = f"/tmp/kernell_training_{dataset.version}.jsonl"

        with open(path, "w", encoding="utf-8") as f:
            for ex in examples:
                # Formato OpenAI fine-tuning
                record = {
                    "messages": [
                        {"role": "system",    "content": ex.system_prompt},
                        {"role": "user",      "content": ex.user_content},
                        {"role": "assistant", "content": ex.assistant_response},
                    ]
                }
                f.write(json.dumps(record, ensure_ascii=False) + "\n")

        dataset.file_path = path
        logger.info(f"[FINE-TUNE] Dataset exportado: {path} ({len(examples)} líneas)")
        return path

    def _submit_fine_tune(
        self,
        dataset: TrainingDataset,
        jsonl_path: str,
        provider: FineTuneProvider,
    ) -> FineTuneJob:
        import uuid

        job = FineTuneJob(
            job_id=str(uuid.uuid4())[:8],
            provider=provider.value,
            model_base=self._model_base(provider),
            dataset_id=dataset.dataset_id,
            examples_used=dataset.examples_total,
            status="pending",
            fine_tuned_model_id=None,
            evaluation_score=None,
            deployed=False,
            started_at=datetime.now(timezone.utc).isoformat(),
            completed_at=None,
        )

        try:
            if provider == FineTuneProvider.OPENAI:
                self._submit_openai(job, jsonl_path)
            elif provider == FineTuneProvider.TOGETHER_AI:
                self._submit_together(job, jsonl_path)
            elif provider == FineTuneProvider.LOCAL_OLLAMA:
                self._submit_local(job, jsonl_path)
            else:
                logger.warning(
                    f"[FINE-TUNE] Provider {provider.value} requiere setup manual. "
                    f"Dataset en: {jsonl_path}"
                )
                job.status = "manual_required"
        except Exception as e:
            job.status = f"error: {e}"
            logger.error(f"[FINE-TUNE] Submit error: {e}")

        return job

    def _submit_openai(self, job: FineTuneJob, jsonl_path: str):
        import os, urllib.request
        api_key_raw = self.redis.get("kernell:llm:keys:anthropic")
        # Para OpenAI necesitamos su propia key
        oai_key = os.environ.get("OPENAI_API_KEY")
        if not oai_key:
            job.status = "no_openai_key"
            return

        # Upload file
        with open(jsonl_path, "rb") as f:
            file_data = f.read()

        # OpenAI files upload (multipart — simplificado)
        boundary    = "---kernell_boundary"
        body        = (
            f"--{boundary}\r\n"
            f"Content-Disposition: form-data; name=\"purpose\"\r\n\r\n"
            f"fine-tune\r\n"
            f"--{boundary}\r\n"
            f"Content-Disposition: form-data; name=\"file\"; filename=\"dataset.jsonl\"\r\n"
            f"Content-Type: application/json\r\n\r\n"
        ).encode() + file_data + f"\r\n--{boundary}--\r\n".encode()

        upload_req = urllib.request.Request(
            "https://api.openai.com/v1/files",
            data=body,
            headers={
                "Authorization": f"Bearer {oai_key}",
                "Content-Type": f"multipart/form-data; boundary={boundary}",
            },
            method="POST",
        )
        with urllib.request.urlopen(upload_req, timeout=60) as r:
            file_resp = json.loads(r.read())
        file_id = file_resp.get("id")

        # Create fine-tune job
        ft_payload = json.dumps({
            "training_file": file_id,
            "model": job.model_base,
        }).encode()
        ft_req = urllib.request.Request(
            "https://api.openai.com/v1/fine_tuning/jobs",
            data=ft_payload,
            headers={
                "Authorization": f"Bearer {oai_key}",
                "Content-Type": "application/json",
            },
            method="POST",
        )
        with urllib.request.urlopen(ft_req, timeout=30) as r:
            ft_resp = json.loads(r.read())

        job.fine_tuned_model_id = ft_resp.get("id")
        job.status = "running"
        logger.info(f"[FINE-TUNE] OpenAI job: {job.fine_tuned_model_id}")

    def _submit_together(self, job: FineTuneJob, jsonl_path: str):
        import os
        together_key = os.environ.get("TOGETHER_AI_KEY") or (
            self.redis.get("kernell:llm:keys:together") or b""
        )
        if isinstance(together_key, bytes):
            together_key = together_key.decode()
        if not together_key:
            job.status = "no_together_key"
            logger.warning(
                "[FINE-TUNE] Together AI key no encontrada. "
                f"Dataset listo en {jsonl_path}. "
                "Obtén key en api.together.ai y registra: "
                "registry.register_key('together', 'tu_key')"
            )
            return

        import urllib.request
        with open(jsonl_path, "rb") as f:
            file_data = f.read()

        boundary = "---kernell_together"
        body = (
            f"--{boundary}\r\n"
            "Content-Disposition: form-data; name=\"file\"; "
            "filename=\"dataset.jsonl\"\r\n"
            "Content-Type: application/json\r\n\r\n"
        ).encode() + file_data + f"\r\n--{boundary}--\r\n".encode()

        upload_req = urllib.request.Request(
            "https://api.together.xyz/v1/files",
            data=body,
            headers={
                "Authorization": f"Bearer {together_key}",
                "Content-Type": f"multipart/form-data; boundary={boundary}",
            },
            method="POST",
        )
        with urllib.request.urlopen(upload_req, timeout=60) as r:
            upload_resp = json.loads(r.read())
        file_id = upload_resp.get("id")

        ft_payload = json.dumps({
            "training_file":  file_id,
            "model":          job.model_base,
            "n_epochs":       3,
            "learning_rate":  1e-5,
            "suffix":         "kernell-specialist",
        }).encode()
        ft_req = urllib.request.Request(
            "https://api.together.xyz/v1/fine-tunes",
            data=ft_payload,
            headers={
                "Authorization": f"Bearer {together_key}",
                "Content-Type": "application/json",
            },
            method="POST",
        )
        with urllib.request.urlopen(ft_req, timeout=30) as r:
            ft_resp = json.loads(r.read())

        job.fine_tuned_model_id = ft_resp.get("id")
        job.status = "running"
        logger.info(f"[FINE-TUNE] Together AI job: {job.fine_tuned_model_id}")

    def _submit_local(self, job: FineTuneJob, jsonl_path: str):
        """
        Fine-tune local usando Ollama + Modelfile.
        Requiere que el dataset esté preparado en el formato correcto.
        """
        logger.info(
            f"[FINE-TUNE] Fine-tune local. Dataset: {jsonl_path}\n"
            "Para fine-tune local con Axolotl:\n"
            "  1. docker run -v /tmp:/data axolotl train config.yaml\n"
            "  2. ollama create kernell-specialist -f Modelfile\n"
            "  3. ollama run kernell-specialist"
        )
        job.status = "local_manual"
        job.fine_tuned_model_id = "kernell-specialist-local"

    def _model_base(self, provider: FineTuneProvider) -> str:
        return {
            FineTuneProvider.OPENAI:        "gpt-4o-mini-2024-07-18",
            FineTuneProvider.TOGETHER_AI:   "meta-llama/Llama-3-70b-chat-hf",
            FineTuneProvider.LOCAL_AXOLOTL: "meta-llama/Llama-3-8B",
            FineTuneProvider.LOCAL_OLLAMA:  "llama3:8b",
        }.get(provider, "unknown")

    def _persist_job(self, job: FineTuneJob):
        self.redis.hset("kernell:fine_tune:jobs", job.job_id, json.dumps(asdict(job)))
        self.redis.lpush("kernell:fine_tune:history", json.dumps({
            "job_id":   job.job_id,
            "provider": job.provider,
            "examples": job.examples_used,
            "status":   job.status,
            "started":  job.started_at,
        }))
        self.redis.ltrim("kernell:fine_tune:history", 0, 49)


# ══════════════════════════════════════════════════════════════════════════
# TRAINING STATS (para monitoreo)
# ══════════════════════════════════════════════════════════════════════════

class TrainingStats:
    def __init__(self, redis_client: redis.Redis):
        self.redis = redis_client

    def summary(self) -> dict:
        jobs_raw = self.redis.hgetall("kernell:fine_tune:jobs")
        jobs     = [json.loads(v) for v in jobs_raw.values()]

        deployed = [j for j in jobs if j.get("deployed")]
        running  = [j for j in jobs if j.get("status") == "running"]

        ep_index = self.redis.lrange("kernell:memory:episodes:index", 0, -1)
        evaluated = 0
        for raw in ep_index:
            ep_raw = self.redis.get(
                f"kernell:memory:episode:{raw if isinstance(raw,str) else raw.decode()}"
            )
            if ep_raw:
                try:
                    if json.loads(ep_raw).get("evaluated"):
                        evaluated += 1
                except Exception:
                    pass

        return {
            "total_episodes":         self.redis.llen("kernell:memory:episodes:index"),
            "evaluated_episodes":     evaluated,
            "ready_for_training":     evaluated >= FINE_TUNE_MIN_EXAMPLES,
            "fine_tune_jobs_total":   len(jobs),
            "fine_tune_jobs_running": len(running),
            "models_deployed":        len(deployed),
            "examples_until_ready":   max(0, FINE_TUNE_MIN_EXAMPLES - evaluated),
            "timestamp":              datetime.now(timezone.utc).isoformat(),
        }
