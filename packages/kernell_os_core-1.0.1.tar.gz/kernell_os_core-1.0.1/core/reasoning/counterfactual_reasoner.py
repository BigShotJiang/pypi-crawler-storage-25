"""
COUNTERFACTUAL REASONER — Razonamiento Causal Sobre el Pasado
==============================================================
Nivel 3 del razonamiento profundo.

PROBLEMA:
  El Monte Carlo simula futuros probables.
  El Synthesis Agent analiza el estado presente.
  Nadie pregunta: "¿qué hubiera pasado si X hubiera existido antes?"

  Forge Council debate patches en el vacío.
  No puede decir: "este patch hubiera fallado en el incidente del 15/02
  porque bajo Drift=84 + Confidence=38, su supuesto de estabilidad
  no se sostiene — hay evidencia histórica."

SOLUCIÓN:
  CausalReplayer: dado un episodio pasado + un patch hipotético,
  razona qué hubiera ocurrido de manera causal.

  No es simulación estocástica (Monte Carlo).
  Es razonamiento causal: "dados estos inputs reales históricos,
  esta lógica de patch hubiera producido este output, porque..."

FLUJO:
  1. PFE propone patch
  2. CounterfactualReasoner busca episodios similares en EpisodicMemory
  3. Para cada episodio relevante, pregunta a DeepSeek R1:
     "Si este patch hubiera estado activo aquí, ¿qué hubiera pasado?"
  4. R1 razona con el episodio completo + el diff del patch
  5. Produce CounterfactualReport con veredicto y reasoning trace
  6. Forge y Audit Council usan este report como evidencia histórica

VALOR CLAVE:
  Un patch que parece bueno en condiciones normales
  puede ser catastrófico bajo STRESS con Drift > 80.
  El contrafactual lo detecta sin necesidad de repetir el incidente.
"""

import json
import logging
import redis
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from typing import Optional

from core.sea.llm_registry import LLMProviderRegistry
from core.reasoning.episodic_memory import (
    EpisodicMemory, CausalEpisode, EpisodeType
)

logger = logging.getLogger("kernell.counterfactual")

COUNTERFACTUAL_SYSTEM = """Eres el Razonador Contrafactual de Kernell OS.
Tu función es razonar causalmente sobre el pasado:
dado un episodio real que ocurrió en el sistema,
y un patch hipotético que NO estaba activo en ese momento,
¿qué hubiera pasado si el patch hubiera estado activo?

IMPORTANTE:
- Razona con los datos reales del episodio (drift, GSHI, modo, confianza)
- Analiza la lógica del patch frente a esas condiciones específicas
- No asumas que el patch funciona en general — funciona en ESAS condiciones
- Identifica condiciones en las que el patch hubiera fallado o empeorado las cosas
- Si el episodio fue un incidente CRITICAL, sé especialmente riguroso

Responde SOLO con JSON válido:
{
  "verdict": "BETTER"|"WORSE"|"NEUTRAL"|"CATASTROPHIC",
  "confidence": 0.0-1.0,
  "reasoning": "análisis causal detallado",
  "critical_conditions": ["condición que hubiera causado fallo"],
  "patch_assumptions_violated": ["supuesto del patch que no se sostiene aquí"],
  "hypothetical_gshi_delta": -20.0,
  "hypothetical_outcome": "descripción del outcome contrafactual",
  "recommendation": "STRENGTHEN_PATCH"|"REJECT_PATCH"|"CONDITIONAL_APPROVAL"|"APPROVE"
}"""


@dataclass
class CounterfactualResult:
    episode_id: str
    episode_title: str
    episode_type: str
    patch_title: str
    verdict: str                    # "BETTER"|"WORSE"|"NEUTRAL"|"CATASTROPHIC"
    confidence: float
    reasoning: str
    critical_conditions: list[str]  # Condiciones que hubieran causado fallo
    patch_assumptions_violated: list[str]
    hypothetical_gshi_delta: Optional[float]
    hypothetical_outcome: str
    recommendation: str             # "STRENGTHEN_PATCH"|"REJECT_PATCH"|"CONDITIONAL"|"APPROVE"
    reasoning_trace: Optional[str]  # Chain-of-thought de R1
    provider_used: str
    timestamp: str


@dataclass
class CounterfactualReport:
    proposal_id: str
    patch_title: str
    patch_description: str
    episodes_analyzed: int
    results: list[dict]

    # Veredicto consolidado
    overall_verdict: str            # "SAFE"|"CONDITIONAL"|"RISKY"|"DANGEROUS"
    worst_case: Optional[str]       # El peor escenario contrafactual encontrado
    best_case: Optional[str]        # El mejor
    stress_tested: bool             # ¿Se encontraron episodios bajo STRESS/CRITICAL?
    catastrophic_count: int         # Cuántos escenarios hubieran sido catastróficos
    recommendations: list[str]      # Recomendaciones consolidadas

    # Para Forge y Audit Council
    historical_evidence_summary: str   # Resumen para incluir en debate
    timestamp: str


class CounterfactualReasoner:
    """
    Razonador contrafactual. Pregunta al sistema sobre su propio pasado.
    Usa DeepSeek R1 en Groq — chain-of-thought nativo para razonamiento causal.
    """

    def __init__(self, redis_client: redis.Redis):
        self.redis  = redis_client
        self.memory = EpisodicMemory(redis_client)
        self.llm    = LLMProviderRegistry(redis_client)

    # ══════════════════════════════════════════════════════════════════════
    # ANÁLISIS CONTRAFACTUAL DE UN PATCH
    # ══════════════════════════════════════════════════════════════════════

    def analyze_patch(
        self,
        proposal_id: str,
        patch_title: str,
        patch_description: str,
        patch_diff: str,
        max_episodes: int = 5,
    ) -> CounterfactualReport:
        """
        Analiza un patch propuesto contra episodios históricos relevantes.

        Responde: "¿Este patch hubiera ayudado o dañado en situaciones pasadas?"
        """
        logger.info(
            f"[COUNTERFACTUAL] Analizando '{patch_title}' "
            f"contra memoria histórica..."
        )

        # Recuperar episodios relevantes
        episodes = self._retrieve_relevant_episodes(
            patch_title, patch_description, max_episodes
        )

        if not episodes:
            logger.info("[COUNTERFACTUAL] Sin episodios históricos suficientes")
            return self._no_history_report(proposal_id, patch_title, patch_description)

        # Analizar patch contra cada episodio
        results: list[CounterfactualResult] = []
        for recall in episodes:
            result = self._reason_counterfactual(
                recall.episode, patch_title, patch_description, patch_diff
            )
            results.append(result)
            logger.info(
                f"[COUNTERFACTUAL]  ep={recall.episode.episode_id[:8]} "
                f"verdict={result.verdict} conf={result.confidence:.2f}"
            )

        report = self._consolidate(
            proposal_id, patch_title, patch_description, results
        )

        self._persist(report)
        logger.info(
            f"[COUNTERFACTUAL] {proposal_id[:8]}: {report.overall_verdict} "
            f"({len(results)} episodios, {report.catastrophic_count} catastróficos)"
        )
        return report

    # ══════════════════════════════════════════════════════════════════════
    # RAZONAMIENTO POR EPISODIO
    # ══════════════════════════════════════════════════════════════════════

    def _reason_counterfactual(
        self,
        episode: CausalEpisode,
        patch_title: str,
        patch_description: str,
        patch_diff: str,
    ) -> CounterfactualResult:
        """
        Pregunta a R1: "Si este patch hubiera estado activo en este episodio, ¿qué hubiera pasado?"
        """
        import re

        prompt = self._build_prompt(episode, patch_title, patch_description, patch_diff)

        resp = self.llm.complete(
            messages=[{"role": "user", "content": prompt}],
            system_prompt=COUNTERFACTUAL_SYSTEM,
            role="synthesis",      # R1 en Groq — reasoning nativo
            max_tokens=2000,
            temperature=0.4,
        )

        if not resp:
            return self._failed_result(episode, patch_title)

        try:
            text  = resp.content
            match = re.search(r"\{.*\}", text, re.DOTALL)
            data  = json.loads(match.group()) if match else {}
        except Exception:
            data = {}

        return CounterfactualResult(
            episode_id=episode.episode_id,
            episode_title=episode.title,
            episode_type=episode.episode_type,
            patch_title=patch_title,
            verdict=data.get("verdict", "NEUTRAL"),
            confidence=float(data.get("confidence", 0.5)),
            reasoning=str(data.get("reasoning", "")),
            critical_conditions=list(data.get("critical_conditions", [])),
            patch_assumptions_violated=list(data.get("patch_assumptions_violated", [])),
            hypothetical_gshi_delta=data.get("hypothetical_gshi_delta"),
            hypothetical_outcome=str(data.get("hypothetical_outcome", "")),
            recommendation=data.get("recommendation", "CONDITIONAL_APPROVAL"),
            reasoning_trace=resp.reasoning_trace,
            provider_used=resp.provider_used,
            timestamp=datetime.now(timezone.utc).isoformat(),
        )

    def _build_prompt(
        self,
        episode: CausalEpisode,
        patch_title: str,
        patch_description: str,
        patch_diff: str,
    ) -> str:
        """Construye el prompt contrafactual con el episodio completo."""
        before = episode.snapshot_before
        after  = episode.snapshot_after or {}

        lines = [
            "═══ EPISODIO HISTÓRICO REAL ═══",
            f"Tipo:        {episode.episode_type}",
            f"Título:      {episode.title}",
            f"Descripción: {episode.description}",
            f"Trigger:     {episode.trigger}",
            f"Intención:   {episode.intention}",
            "",
            "ESTADO ANTES del episodio:",
            f"  GSHI:       {before.get('gshi', '?')}",
            f"  Modo FSM:   {before.get('mode', '?')}",
            f"  Drift:      {before.get('drift', '?')}",
            f"  Confidence: {before.get('confidence', '?')}",
            f"  DEFCON:     {before.get('defcon', '?')}",
            f"  SCI:        {before.get('sci', '?')}",
        ]

        if after:
            lines += [
                "",
                "ESTADO DESPUÉS del episodio:",
                f"  GSHI:       {after.get('gshi', '?')}",
                f"  Modo FSM:   {after.get('mode', '?')}",
                f"  Drift:      {after.get('drift', '?')}",
            ]

        lines += [
            "",
            f"Outcome real:     {episode.actual_outcome or 'no evaluado'}",
            f"Calidad outcome:  {episode.outcome_quality}",
            f"GSHI delta real:  {episode.actual_gshi_delta}",
        ]

        if episode.hindsight:
            lines.append(f"Hindsight:        {episode.hindsight}")

        lines += [
            "",
            "═══ PATCH HIPOTÉTICO (NO ESTABA ACTIVO) ═══",
            f"Título:      {patch_title}",
            f"Descripción: {patch_description}",
            "",
            "DIFF (fragmento):",
            patch_diff[:1500],
            "",
            "═══ PREGUNTA ═══",
            "Si este patch hubiera estado activo durante el episodio anterior:",
            "1. ¿Hubiera mejorado, empeorado, o no cambiado el outcome?",
            "2. ¿Qué supuestos del patch NO se sostendrían bajo esas condiciones?",
            "3. ¿Bajo qué condiciones del episodio hubiera fallado el patch?",
            "Responde SOLO con JSON.",
        ]

        return "\n".join(lines)

    # ══════════════════════════════════════════════════════════════════════
    # CONSOLIDACIÓN
    # ══════════════════════════════════════════════════════════════════════

    def _consolidate(
        self,
        proposal_id: str,
        patch_title: str,
        patch_description: str,
        results: list[CounterfactualResult],
    ) -> CounterfactualReport:
        counts = {"BETTER": 0, "NEUTRAL": 0, "WORSE": 0, "CATASTROPHIC": 0}
        for r in results:
            counts[r.verdict] = counts.get(r.verdict, 0) + 1

        catastrophic = counts.get("CATASTROPHIC", 0)
        worse        = counts.get("WORSE", 0)
        better       = counts.get("BETTER", 0)
        total        = len(results)

        stress_tested = any(
            r.episode_type in (
                EpisodeType.INCIDENT.value,
                EpisodeType.GSHI_DROP.value,
            )
            for r in results
        )

        # Veredicto global
        if catastrophic >= 1:
            overall = "DANGEROUS"
        elif worse >= total * 0.4:
            overall = "RISKY"
        elif better >= total * 0.6:
            overall = "SAFE"
        else:
            overall = "CONDITIONAL"

        # Worst/best case
        worst = next(
            (r.hypothetical_outcome for r in results if r.verdict == "CATASTROPHIC"),
            next((r.hypothetical_outcome for r in results if r.verdict == "WORSE"), None)
        )
        best = next(
            (r.hypothetical_outcome for r in results if r.verdict == "BETTER"), None
        )

        # Recomendaciones consolidadas
        all_violations = list({
            v for r in results for v in r.patch_assumptions_violated
        })
        all_conditions = list({
            c for r in results for c in r.critical_conditions
        })
        recommendations = []
        if catastrophic > 0:
            recommendations.append(
                "CRÍTICO: patch produce outcomes catastróficos bajo condiciones históricas reales"
            )
        if all_violations:
            recommendations.append(
                f"Supuestos violados bajo estrés: {'; '.join(all_violations[:3])}"
            )
        if all_conditions:
            recommendations.append(
                f"Fortalecer para condiciones: {'; '.join(all_conditions[:3])}"
            )

        # Resumen para Forge/Audit Council
        summary_lines = [
            f"Análisis contrafactual: {total} episodios históricos.",
            f"Veredicto: {overall} | "
            f"mejor={counts['BETTER']} neutro={counts['NEUTRAL']} "
            f"peor={counts['WORSE']} catastrófico={catastrophic}.",
        ]
        if stress_tested:
            summary_lines.append("Incluye episodios bajo CRITICAL/GSHI_DROP.")
        if worst:
            summary_lines.append(f"Peor escenario: {worst[:150]}")
        if recommendations:
            summary_lines.append(f"Advertencias: {recommendations[0]}")

        return CounterfactualReport(
            proposal_id=proposal_id,
            patch_title=patch_title,
            patch_description=patch_description,
            episodes_analyzed=total,
            results=[asdict(r) for r in results],
            overall_verdict=overall,
            worst_case=worst,
            best_case=best,
            stress_tested=stress_tested,
            catastrophic_count=catastrophic,
            recommendations=recommendations,
            historical_evidence_summary="\n".join(summary_lines),
            timestamp=datetime.now(timezone.utc).isoformat(),
        )

    # ══════════════════════════════════════════════════════════════════════
    # HELPERS
    # ══════════════════════════════════════════════════════════════════════

    def _retrieve_relevant_episodes(
        self, title: str, description: str, max_k: int
    ):
        query = f"{title} {description}"

        # Siempre buscar incidentes graves — stress test obligatorio
        incidents = self.memory.recall(
            query=query,
            episode_types=[EpisodeType.INCIDENT, EpisodeType.GSHI_DROP],
            top_k=2,
        )

        # + PFE similares
        pfe = self.memory.recall_pfe_outcomes(
            patch_description=query,
            top_k=2,
        )

        # + Episodios generales similares
        general = self.memory.recall(query=query, top_k=2)

        # Dedup por episode_id
        seen, combined = set(), []
        for ep_list in [incidents, pfe, general]:
            for r in ep_list:
                if r.episode.episode_id not in seen:
                    seen.add(r.episode.episode_id)
                    combined.append(r)
                    if len(combined) >= max_k:
                        break
            if len(combined) >= max_k:
                break

        return combined

    def _failed_result(self, episode: CausalEpisode, patch_title: str) -> CounterfactualResult:
        return CounterfactualResult(
            episode_id=episode.episode_id,
            episode_title=episode.title,
            episode_type=episode.episode_type,
            patch_title=patch_title,
            verdict="NEUTRAL",
            confidence=0.0,
            reasoning="LLM unavailable — no counterfactual analysis",
            critical_conditions=[], patch_assumptions_violated=[],
            hypothetical_gshi_delta=None,
            hypothetical_outcome="unknown",
            recommendation="CONDITIONAL_APPROVAL",
            reasoning_trace=None,
            provider_used="none",
            timestamp=datetime.now(timezone.utc).isoformat(),
        )

    def _no_history_report(
        self, proposal_id: str, title: str, description: str
    ) -> CounterfactualReport:
        return CounterfactualReport(
            proposal_id=proposal_id,
            patch_title=title,
            patch_description=description,
            episodes_analyzed=0,
            results=[],
            overall_verdict="CONDITIONAL",
            worst_case=None, best_case=None,
            stress_tested=False, catastrophic_count=0,
            recommendations=["Sin historia suficiente — aprobación condicional a shadow deployment"],
            historical_evidence_summary=(
                "Sin episodios históricos para análisis contrafactual. "
                "Shadow deployment es el primer test real."
            ),
            timestamp=datetime.now(timezone.utc).isoformat(),
        )

    def _persist(self, report: CounterfactualReport):
        key = f"kernell:counterfactual:{report.proposal_id}"
        self.redis.set(key, json.dumps(asdict(report)), ex=7 * 86400)
        self.redis.lpush("kernell:counterfactual:history", json.dumps({
            "proposal_id": report.proposal_id,
            "verdict":     report.overall_verdict,
            "episodes":    report.episodes_analyzed,
            "catastrophic": report.catastrophic_count,
            "timestamp":   report.timestamp,
        }))
        self.redis.ltrim("kernell:counterfactual:history", 0, 99)

    def get_report(self, proposal_id: str) -> Optional[CounterfactualReport]:
        raw = self.redis.get(f"kernell:counterfactual:{proposal_id}")
        if raw:
            return CounterfactualReport(**json.loads(raw))
        return None
