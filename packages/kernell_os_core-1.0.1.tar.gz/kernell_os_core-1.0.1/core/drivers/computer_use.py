#!/usr/bin/env python3
"""
core/drivers/computer_use.py
═════════════════════════════
Desktop & Browser Control — Kernell OS

Provides two control surfaces:
  1. DesktopController: Screenshots, mouse clicks, keyboard input via pyautogui
  2. BrowserBridge: DOM control via Chrome DevTools Protocol (CDP)

Safety:
  - Single-instance mutex lock prevents concurrent desktop control
  - All actions are logged with screenshots for audit trail
  - Kill switch integration via Redis pub/sub

Integration:
    from core.drivers.computer_use import DesktopController, BrowserBridge

    # Desktop control
    desktop = DesktopController()
    screenshot = desktop.take_screenshot()
    desktop.click(x=500, y=300)
    desktop.type_text("hello world")

    # Browser control
    browser = BrowserBridge(port=9222)
    browser.navigate("https://example.com")
    dom = browser.get_dom()
    browser.execute_js("document.querySelector('.btn').click()")

Sovereign Architecture — Blueprint XV
"""

import os
import sys
import json
import time
import base64
import logging
import tempfile
import subprocess
import threading
from pathlib import Path
from typing import Optional, Dict, List, Any, Tuple

logger = logging.getLogger("ComputerUse")

# ── Try imports ──────────────────────────────────────────────────────────────

_PYAUTOGUI_AVAILABLE = False
_REQUESTS_AVAILABLE = False

try:
    import pyautogui
    pyautogui.FAILSAFE = True  # Move mouse to corner to abort
    pyautogui.PAUSE = 0.1
    _PYAUTOGUI_AVAILABLE = True
except ImportError:
    pass

try:
    import requests
    _REQUESTS_AVAILABLE = True
except ImportError:
    pass


# ── Lock for single-instance desktop control ─────────────────────────────────

_DESKTOP_LOCK = threading.Lock()
_LOCK_FILE = Path("/tmp/kernell_computer_use.lock")


# ── Desktop Controller ──────────────────────────────────────────────────────

class DesktopController:
    """
    Controls the desktop via screenshot/click/type operations.
    Wraps pyautogui with safety features and audit logging.
    """

    def __init__(
        self,
        display: str = ":1",
        screenshot_dir: str = "/tmp/kernell_screenshots",
        redis_client=None,
    ):
        self.display = display
        self.screenshot_dir = Path(screenshot_dir)
        self.screenshot_dir.mkdir(parents=True, exist_ok=True)
        self._redis = redis_client
        self._action_count = 0
        self._last_screenshot: Optional[str] = None

        # Set display environment
        os.environ.setdefault("DISPLAY", display)

        available = "pyautogui" if _PYAUTOGUI_AVAILABLE else "subprocess-only"
        logger.info(f"🖥️ DesktopController initialized (display={display}, backend={available})")

    # ── Screenshots ──────────────────────────────────────────────────────

    def take_screenshot(self, region: Optional[Tuple[int, int, int, int]] = None) -> str:
        """
        Take a screenshot of the desktop.

        Args:
            region: Optional (x, y, width, height) to capture specific area

        Returns:
            Path to the saved screenshot file
        """
        timestamp = int(time.time() * 1000)
        filepath = self.screenshot_dir / f"screenshot_{timestamp}.png"

        try:
            if _PYAUTOGUI_AVAILABLE:
                screenshot = pyautogui.screenshot(region=region)
                screenshot.save(str(filepath))
            else:
                # Fallback: use scrot or import command
                cmd = ["scrot", "-o", str(filepath)]
                if region:
                    x, y, w, h = region
                    cmd = ["import", "-window", "root", "-crop", f"{w}x{h}+{x}+{y}", str(filepath)]
                subprocess.run(cmd, timeout=5, capture_output=True, env={**os.environ, "DISPLAY": self.display})

            self._last_screenshot = str(filepath)
            logger.debug(f"📸 Screenshot saved: {filepath}")
            return str(filepath)

        except Exception as e:
            logger.error(f"Screenshot failed: {e}")
            return ""

    def screenshot_to_base64(self, region: Optional[Tuple[int, int, int, int]] = None) -> str:
        """Take screenshot and return as base64-encoded PNG."""
        filepath = self.take_screenshot(region)
        if not filepath or not Path(filepath).exists():
            return ""
        try:
            with open(filepath, "rb") as f:
                return base64.b64encode(f.read()).decode("ascii")
        except Exception:
            return ""

    # ── Mouse Control ────────────────────────────────────────────────────

    def click(self, x: int, y: int, button: str = "left", clicks: int = 1) -> bool:
        """
        Click at position (x, y) on the screen.

        Args:
            x, y: Screen coordinates
            button: "left", "right", or "middle"
            clicks: Number of clicks (2 for double-click)
        """
        with _DESKTOP_LOCK:
            self._action_count += 1
            try:
                if _PYAUTOGUI_AVAILABLE:
                    pyautogui.click(x=x, y=y, button=button, clicks=clicks)
                else:
                    self._xdotool_click(x, y, button, clicks)

                logger.info(f"🖱️ Click at ({x}, {y}) button={button} clicks={clicks}")
                self._log_action("click", {"x": x, "y": y, "button": button, "clicks": clicks})
                return True
            except Exception as e:
                logger.error(f"Click failed: {e}")
                return False

    def move_to(self, x: int, y: int, duration: float = 0.25) -> bool:
        """Move mouse to position."""
        with _DESKTOP_LOCK:
            try:
                if _PYAUTOGUI_AVAILABLE:
                    pyautogui.moveTo(x, y, duration=duration)
                else:
                    subprocess.run(
                        ["xdotool", "mousemove", str(x), str(y)],
                        timeout=5, capture_output=True,
                        env={**os.environ, "DISPLAY": self.display},
                    )
                return True
            except Exception as e:
                logger.error(f"Mouse move failed: {e}")
                return False

    def scroll(self, x: int, y: int, clicks: int = 3) -> bool:
        """Scroll at position. Positive clicks = scroll up, negative = down."""
        with _DESKTOP_LOCK:
            try:
                if _PYAUTOGUI_AVAILABLE:
                    pyautogui.moveTo(x, y)
                    pyautogui.scroll(clicks)
                else:
                    direction = "up" if clicks > 0 else "down"
                    for _ in range(abs(clicks)):
                        subprocess.run(
                            ["xdotool", "mousemove", str(x), str(y), "click", "4" if direction == "up" else "5"],
                            timeout=5, capture_output=True,
                            env={**os.environ, "DISPLAY": self.display},
                        )
                return True
            except Exception as e:
                logger.error(f"Scroll failed: {e}")
                return False

    # ── Keyboard Control ─────────────────────────────────────────────────

    def type_text(self, text: str, interval: float = 0.02) -> bool:
        """
        Type text on the keyboard.

        Args:
            text: Content to type
            interval: Delay between keystrokes (seconds)
        """
        with _DESKTOP_LOCK:
            self._action_count += 1
            try:
                if _PYAUTOGUI_AVAILABLE:
                    pyautogui.typewrite(text, interval=interval)
                else:
                    subprocess.run(
                        ["xdotool", "type", "--delay", str(int(interval * 1000)), text],
                        timeout=30, capture_output=True,
                        env={**os.environ, "DISPLAY": self.display},
                    )
                logger.info(f"⌨️ Typed {len(text)} chars")
                self._log_action("type", {"length": len(text), "preview": text[:30]})
                return True
            except Exception as e:
                logger.error(f"Type failed: {e}")
                return False

    def press_key(self, key: str) -> bool:
        """Press a special key (enter, tab, escape, etc.)."""
        with _DESKTOP_LOCK:
            try:
                if _PYAUTOGUI_AVAILABLE:
                    pyautogui.press(key)
                else:
                    subprocess.run(
                        ["xdotool", "key", key],
                        timeout=5, capture_output=True,
                        env={**os.environ, "DISPLAY": self.display},
                    )
                logger.debug(f"⌨️ Key press: {key}")
                return True
            except Exception as e:
                logger.error(f"Key press failed: {e}")
                return False

    def hotkey(self, *keys: str) -> bool:
        """Press a key combination (e.g., hotkey('ctrl', 'c'))."""
        with _DESKTOP_LOCK:
            try:
                if _PYAUTOGUI_AVAILABLE:
                    pyautogui.hotkey(*keys)
                else:
                    combo = "+".join(keys)
                    subprocess.run(
                        ["xdotool", "key", combo],
                        timeout=5, capture_output=True,
                        env={**os.environ, "DISPLAY": self.display},
                    )
                logger.info(f"⌨️ Hotkey: {'+'.join(keys)}")
                return True
            except Exception as e:
                logger.error(f"Hotkey failed: {e}")
                return False

    # ── Screen Info ──────────────────────────────────────────────────────

    def get_screen_size(self) -> Tuple[int, int]:
        """Return (width, height) of the screen."""
        try:
            if _PYAUTOGUI_AVAILABLE:
                return pyautogui.size()
            result = subprocess.run(
                ["xdpyinfo"],
                capture_output=True, text=True, timeout=5,
                env={**os.environ, "DISPLAY": self.display},
            )
            import re
            m = re.search(r"dimensions:\s+(\d+)x(\d+)", result.stdout)
            if m:
                return int(m.group(1)), int(m.group(2))
        except Exception:
            pass
        return 1920, 1080  # Default

    # ── Internal ─────────────────────────────────────────────────────────

    def _xdotool_click(self, x: int, y: int, button: str, clicks: int):
        """Click using xdotool."""
        btn_map = {"left": "1", "middle": "2", "right": "3"}
        btn = btn_map.get(button, "1")
        for _ in range(clicks):
            subprocess.run(
                ["xdotool", "mousemove", str(x), str(y), "click", btn],
                timeout=5, capture_output=True,
                env={**os.environ, "DISPLAY": self.display},
            )

    def _log_action(self, action_type: str, data: dict):
        """Log action to Redis for audit trail."""
        if not self._redis:
            return
        try:
            event = json.dumps({
                "type": f"computer_use:{action_type}",
                "agent": "desktop_controller",
                "data": data,
                "action_count": self._action_count,
                "timestamp": time.time(),
            })
            self._redis.lpush("kernell:computer_use:actions", event)
            self._redis.ltrim("kernell:computer_use:actions", 0, 499)
        except Exception:
            pass

    def get_status(self) -> Dict[str, Any]:
        """Status for dashboard."""
        w, h = self.get_screen_size()
        return {
            "display": self.display,
            "screen_size": f"{w}x{h}",
            "pyautogui_available": _PYAUTOGUI_AVAILABLE,
            "action_count": self._action_count,
            "last_screenshot": self._last_screenshot,
        }


# ── Browser Bridge (Chrome DevTools Protocol) ───────────────────────────────

class BrowserBridge:
    """
    Controls Chrome/Chromium via Chrome DevTools Protocol.
    Provides DOM interaction, navigation, and screenshot capabilities.

    Requires Chrome launched with --remote-debugging-port:
        google-chrome --remote-debugging-port=9222
    """

    def __init__(self, host: str = "localhost", port: int = 9222):
        self.host = host
        self.port = port
        self.base_url = f"http://{host}:{port}"
        self._ws_url: Optional[str] = None
        self._connected = False

        logger.info(f"🌐 BrowserBridge initialized (CDP at {self.base_url})")

    # ── Connection ───────────────────────────────────────────────────────

    def connect(self) -> bool:
        """Connect to Chrome DevTools."""
        if not _REQUESTS_AVAILABLE:
            logger.error("requests library not available — cannot use BrowserBridge")
            return False

        try:
            resp = requests.get(f"{self.base_url}/json/version", timeout=3)
            if resp.status_code == 200:
                info = resp.json()
                self._ws_url = info.get("webSocketDebuggerUrl")
                self._connected = True
                logger.info(f"✅ Connected to Chrome {info.get('Browser', 'unknown')}")
                return True
        except Exception as e:
            logger.warning(f"Chrome CDP connection failed: {e}")

        self._connected = False
        return False

    def is_connected(self) -> bool:
        """Check if CDP connection is active."""
        if not self._connected:
            return False
        try:
            resp = requests.get(f"{self.base_url}/json/version", timeout=2)
            return resp.status_code == 200
        except Exception:
            self._connected = False
            return False

    # ── Tab Management ───────────────────────────────────────────────────

    def list_tabs(self) -> List[Dict[str, str]]:
        """List all open browser tabs."""
        if not _REQUESTS_AVAILABLE:
            return []
        try:
            resp = requests.get(f"{self.base_url}/json/list", timeout=3)
            if resp.status_code == 200:
                tabs = resp.json()
                return [
                    {
                        "id": t.get("id", ""),
                        "title": t.get("title", ""),
                        "url": t.get("url", ""),
                        "type": t.get("type", ""),
                    }
                    for t in tabs
                    if t.get("type") == "page"
                ]
        except Exception as e:
            logger.error(f"list_tabs failed: {e}")
        return []

    def open_tab(self, url: str = "") -> Optional[str]:
        """Open a new tab and return its ID."""
        if not _REQUESTS_AVAILABLE:
            return None
        try:
            target_url = f"{self.base_url}/json/new"
            if url:
                target_url += f"?{url}"
            resp = requests.put(target_url, timeout=5)
            if resp.status_code == 200:
                tab = resp.json()
                return tab.get("id")
        except Exception as e:
            logger.error(f"open_tab failed: {e}")
        return None

    def close_tab(self, tab_id: str) -> bool:
        """Close a browser tab by ID."""
        if not _REQUESTS_AVAILABLE:
            return False
        try:
            resp = requests.get(f"{self.base_url}/json/close/{tab_id}", timeout=3)
            return resp.status_code == 200
        except Exception:
            return False

    # ── Navigation ───────────────────────────────────────────────────────

    def navigate(self, url: str, tab_id: Optional[str] = None) -> bool:
        """Navigate a tab to a URL."""
        return self._send_cdp_command(
            "Page.navigate",
            {"url": url},
            tab_id=tab_id,
        ) is not None

    # ── DOM Operations ───────────────────────────────────────────────────

    def execute_js(self, expression: str, tab_id: Optional[str] = None) -> Optional[Any]:
        """
        Execute JavaScript in the browser context.

        Args:
            expression: JavaScript code to execute
            tab_id: Target tab (default: first page tab)

        Returns:
            Result of the expression, or None on failure
        """
        result = self._send_cdp_command(
            "Runtime.evaluate",
            {
                "expression": expression,
                "returnByValue": True,
                "awaitPromise": True,
            },
            tab_id=tab_id,
        )
        if result and "result" in result:
            return result["result"].get("value")
        return None

    def get_dom(self, tab_id: Optional[str] = None) -> Optional[str]:
        """Get the outer HTML of the current page."""
        return self.execute_js("document.documentElement.outerHTML", tab_id=tab_id)

    def get_page_title(self, tab_id: Optional[str] = None) -> str:
        """Get the title of the current page."""
        return self.execute_js("document.title", tab_id=tab_id) or ""

    def get_page_url(self, tab_id: Optional[str] = None) -> str:
        """Get the current URL."""
        return self.execute_js("window.location.href", tab_id=tab_id) or ""

    def click_element(self, selector: str, tab_id: Optional[str] = None) -> bool:
        """Click a DOM element by CSS selector."""
        js = f"""
        (function() {{
            const el = document.querySelector({json.dumps(selector)});
            if (el) {{ el.click(); return true; }}
            return false;
        }})()
        """
        result = self.execute_js(js, tab_id=tab_id)
        return result is True

    def fill_input(self, selector: str, value: str, tab_id: Optional[str] = None) -> bool:
        """Fill an input field by CSS selector."""
        js = f"""
        (function() {{
            const el = document.querySelector({json.dumps(selector)});
            if (el) {{
                el.value = {json.dumps(value)};
                el.dispatchEvent(new Event('input', {{ bubbles: true }}));
                el.dispatchEvent(new Event('change', {{ bubbles: true }}));
                return true;
            }}
            return false;
        }})()
        """
        result = self.execute_js(js, tab_id=tab_id)
        return result is True

    def take_page_screenshot(self, tab_id: Optional[str] = None) -> Optional[str]:
        """Take a screenshot of the page and return base64 PNG."""
        result = self._send_cdp_command(
            "Page.captureScreenshot",
            {"format": "png"},
            tab_id=tab_id,
        )
        if result and "data" in result:
            return result["data"]
        return None

    # ── CDP Communication ────────────────────────────────────────────────

    def _send_cdp_command(
        self,
        method: str,
        params: dict = None,
        tab_id: Optional[str] = None,
    ) -> Optional[Dict]:
        """
        Send a CDP command via HTTP (simple protocol).
        For complex real-time use, websocket would be needed.
        """
        if not _REQUESTS_AVAILABLE:
            return None

        try:
            # Get target tab
            if not tab_id:
                tabs = self.list_tabs()
                if not tabs:
                    return None
                tab_id = tabs[0]["id"]

            # Use the HTTP endpoint for simple commands
            # For commands that need websocket, use the evaluate workaround
            if method == "Runtime.evaluate":
                ws_url = None
                tabs_resp = requests.get(f"{self.base_url}/json/list", timeout=3)
                for tab in tabs_resp.json():
                    if tab.get("id") == tab_id:
                        ws_url = tab.get("webSocketDebuggerUrl")
                        break

                if not ws_url:
                    return None

                # Use websocket-based evaluation
                try:
                    import websocket
                    ws = websocket.create_connection(ws_url, timeout=10)
                    msg = json.dumps({
                        "id": 1,
                        "method": method,
                        "params": params or {},
                    })
                    ws.send(msg)
                    response = json.loads(ws.recv())
                    ws.close()
                    return response.get("result")
                except ImportError:
                    # Fallback: no websocket library
                    logger.warning("websocket-client not installed — CDP commands limited")
                    return None

            elif method == "Page.navigate":
                # Navigate can use the HTTP API
                url = params.get("url", "") if params else ""
                resp = requests.get(
                    f"{self.base_url}/json/activate/{tab_id}",
                    timeout=3,
                )
                # For actual navigation, use evaluate
                return self._send_cdp_command(
                    "Runtime.evaluate",
                    {"expression": f"window.location.href = {json.dumps(url)}; true;", "returnByValue": True},
                    tab_id=tab_id,
                )

            elif method == "Page.captureScreenshot":
                try:
                    import websocket
                    tabs_resp = requests.get(f"{self.base_url}/json/list", timeout=3)
                    ws_url = None
                    for tab in tabs_resp.json():
                        if tab.get("id") == tab_id:
                            ws_url = tab.get("webSocketDebuggerUrl")
                            break
                    if not ws_url:
                        return None
                    ws = websocket.create_connection(ws_url, timeout=10)
                    ws.send(json.dumps({"id": 1, "method": method, "params": params or {}}))
                    response = json.loads(ws.recv())
                    ws.close()
                    return response.get("result")
                except ImportError:
                    return None

        except Exception as e:
            logger.error(f"CDP command {method} failed: {e}")

        return None

    # ── Status ───────────────────────────────────────────────────────────

    def get_status(self) -> Dict[str, Any]:
        """Status for dashboard."""
        connected = self.is_connected()
        tabs = self.list_tabs() if connected else []
        return {
            "host": self.host,
            "port": self.port,
            "connected": connected,
            "tab_count": len(tabs),
            "tabs": [{"title": t["title"][:40], "url": t["url"][:60]} for t in tabs[:5]],
        }


# ── CLI ──────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="🖥️ Computer Use — Kernell OS")
    parser.add_argument("--screenshot", action="store_true", help="Take a screenshot")
    parser.add_argument("--browser-status", action="store_true", help="Check Chrome CDP")
    parser.add_argument("--tabs", action="store_true", help="List browser tabs")
    parser.add_argument("--screen-size", action="store_true", help="Show screen size")
    args = parser.parse_args()

    if args.screenshot:
        desktop = DesktopController()
        path = desktop.take_screenshot()
        if path:
            print(f"📸 Screenshot saved: {path}")
        else:
            print("❌ Screenshot failed")
    elif args.browser_status:
        bridge = BrowserBridge()
        if bridge.connect():
            print(json.dumps(bridge.get_status(), indent=2))
        else:
            print("❌ Chrome CDP not available")
    elif args.tabs:
        bridge = BrowserBridge()
        tabs = bridge.list_tabs()
        for tab in tabs:
            print(f"  📄 {tab['title'][:50]} — {tab['url'][:60]}")
    elif args.screen_size:
        desktop = DesktopController()
        w, h = desktop.get_screen_size()
        print(f"🖥️ Screen: {w}x{h}")
    else:
        parser.print_help()
