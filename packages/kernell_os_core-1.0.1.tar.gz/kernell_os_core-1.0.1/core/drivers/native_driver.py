import os
import evdev
from evdev import UInput, ecodes as e
import time
import subprocess

class NativeDriver:
    def __init__(self, dbus_session="/run/user/1000/bus"):
        self.dbus_addr = dbus_session
        self.mouse_caps = {
            e.EV_REL: (e.REL_X, e.REL_Y),
            e.EV_KEY: (e.BTN_LEFT, e.BTN_RIGHT, e.BTN_MIDDLE)
        }
        self.kbd_caps = {
            e.EV_KEY: e.keys.keys()
        }
        self._mouse = None
        self._keyboard = None

    def get_mouse(self):
        if not self._mouse:
            self._mouse = UInput(self.mouse_caps, name="Antigravity Native Mouse")
        return self._mouse

    def get_keyboard(self):
        if not self._keyboard:
            self._keyboard = UInput(self.kbd_caps, name="Antigravity Native Keyboard")
        return self._keyboard

    def capture_screen(self, output_path="/home/anny/native_screenshot.png"):
        env = os.environ.copy()
        env["DBUS_SESSION_BUS_ADDRESS"] = self.dbus_addr
        command = ["gnome-screenshot", "-f", output_path]
        try:
            subprocess.run(command, env=env, check=True, capture_output=True)
            return output_path
        except Exception as err:
            print(f"Capture error: {err}")
            return None

    def move_mouse(self, x_rel, y_rel):
        mouse = self.get_mouse()
        mouse.write(e.EV_REL, e.REL_X, x_rel)
        mouse.write(e.EV_REL, e.REL_Y, y_rel)
        mouse.syn()

    def click(self, button=e.BTN_LEFT):
        mouse = self.get_mouse()
        mouse.write(e.EV_KEY, button, 1)
        mouse.syn()
        time.sleep(0.1)
        mouse.write(e.EV_KEY, button, 0)
        mouse.syn()

    def key_press(self, key_code):
        kbd = self.get_keyboard()
        kbd.write(e.EV_KEY, key_code, 1)
        kbd.syn()
        time.sleep(0.05)
        kbd.write(e.EV_KEY, key_code, 0)
        kbd.syn()

    def type_text(self, text):
        # Very basic typing for demonstration
        # In a real scenario, this would map characters to ecodes
        kbd = self.get_keyboard()
        for char in text:
            # Simplified mapping for common keys
            key = getattr(e, f"KEY_{char.upper()}", None)
            if key:
                self.key_press(key)
                time.sleep(0.02)
            elif char == " ":
                self.key_press(e.KEY_SPACE)
            elif char == ".":
                self.key_press(e.KEY_DOT)
            elif char == "/":
                self.key_press(e.KEY_SLASH)

if __name__ == "__main__":
    driver = NativeDriver()
    print("Testing Screen Capture...")
    path = driver.capture_screen()
    if path:
        print(f"Success: {path}")
    print("Testing Mouse Move...")
    driver.move_mouse(50, 50)
    print("Done.")
