"""
📡 KERNELL OS — Micro-SCION · Path Oracle
══════════════════════════════════════════
Continuously probes critical communication paths and stores
RTT (Round-Trip Time) metrics in Redis.  Agents (especially
Nemesis) query the oracle before latency-sensitive operations
to select the optimal execution path.

Paths monitored:
  • Redis bus         — ping latency to the Redis server
  • MT5 Bridge REST   — HTTP health check of the native MT5 engine
  • MT5 TCP Socket    — Raw TCP probe to the MT5 data port
  • Solana RPC        — HTTPS latency to the devnet/mainnet RPC
  • Qdrant Vector DB  — gRPC/HTTP health

Stores results in:  kernell:scion:path_oracle  (Redis hash)

Usage (consumer side):
    paths = redis.hgetall("kernell:scion:path_oracle")
    mt5_rtt = float(paths.get("mt5_bridge", 9999))
    if mt5_rtt > 500:
        use_fallback_route()
"""

import os
import time
import json
import socket
import logging
import urllib.request
from typing import Optional

logger = logging.getLogger("kernell.scion.path_oracle")

# ── Configuration ────────────────────────────────────────────────

PROBE_INTERVAL = int(os.getenv("SCION_PROBE_INTERVAL", "10"))  # seconds

PATHS = {
    "redis": {
        "type": "redis_ping",
        "description": "Redis bus latency",
    },
    "mt5_bridge": {
        "type": "http",
        "url": os.getenv("MT5_BRIDGE_URL", "http://localhost:18812/health"),
        "timeout": 3,
        "description": "Native MT5 REST bridge",
    },
    "mt5_tcp": {
        "type": "tcp",
        "host": "localhost",
        "port": int(os.getenv("MT5_DATA_PORT", "8222")),
        "timeout": 2,
        "description": "MT5 data socket",
    },
    "solana_rpc": {
        "type": "http",
        "url": os.getenv("SOLANA_RPC_URL", "https://api.devnet.solana.com"),
        "timeout": 5,
        "description": "Solana RPC endpoint",
    },
    "qdrant": {
        "type": "http",
        "url": os.getenv("QDRANT_URL", "http://localhost:6333/healthz"),
        "timeout": 3,
        "description": "Qdrant vector DB",
    },
}

REDIS_KEY = "kernell:scion:path_oracle"
HISTORY_KEY = "kernell:scion:path_oracle:history"


# ── Probe functions ──────────────────────────────────────────────


def _probe_http(url: str, timeout: int = 3) -> dict:
    """Measure HTTP GET RTT in milliseconds."""
    try:
        start = time.monotonic()
        req = urllib.request.Request(url, method="GET")
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            _ = resp.read(512)  # Read minimal body
        rtt_ms = round((time.monotonic() - start) * 1000, 1)
        return {"rtt_ms": rtt_ms, "status": "up", "http_code": resp.status}
    except Exception as e:
        return {"rtt_ms": -1, "status": "down", "error": str(e)[:80]}


def _probe_tcp(host: str, port: int, timeout: int = 2) -> dict:
    """Measure raw TCP connect RTT in milliseconds."""
    try:
        start = time.monotonic()
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        sock.connect((host, port))
        rtt_ms = round((time.monotonic() - start) * 1000, 1)
        sock.close()
        return {"rtt_ms": rtt_ms, "status": "up"}
    except Exception as e:
        return {"rtt_ms": -1, "status": "down", "error": str(e)[:80]}


def _probe_redis(redis_client) -> dict:
    """Measure Redis PING RTT in milliseconds."""
    try:
        start = time.monotonic()
        redis_client.ping()
        rtt_ms = round((time.monotonic() - start) * 1000, 1)
        return {"rtt_ms": rtt_ms, "status": "up"}
    except Exception as e:
        return {"rtt_ms": -1, "status": "down", "error": str(e)[:80]}


# ── Main probe cycle ─────────────────────────────────────────────


def probe_all(redis_client=None) -> dict:
    """
    Run all path probes and return results.
    If redis_client is provided, stores results in Redis.
    """
    results = {}
    ts = time.time()

    for path_name, path_config in PATHS.items():
        probe_type = path_config["type"]

        if probe_type == "redis_ping":
            if redis_client:
                result = _probe_redis(redis_client)
            else:
                result = {"rtt_ms": -1, "status": "skipped", "error": "No redis client"}
        elif probe_type == "http":
            result = _probe_http(path_config["url"], path_config.get("timeout", 3))
        elif probe_type == "tcp":
            result = _probe_tcp(
                path_config["host"], path_config["port"], path_config.get("timeout", 2)
            )
        else:
            result = {"rtt_ms": -1, "status": "unknown_type"}

        result["description"] = path_config.get("description", "")
        result["probed_at"] = ts
        results[path_name] = result

    # Persist to Redis
    if redis_client:
        try:
            flat = {}
            for name, data in results.items():
                flat[name] = json.dumps(data)
            flat["_last_probe"] = str(ts)
            redis_client.hset(REDIS_KEY, mapping=flat)

            # Keep last 360 probes as history (1 hour at 10s interval)
            redis_client.lpush(HISTORY_KEY, json.dumps({"ts": ts, "paths": results}))
            redis_client.ltrim(HISTORY_KEY, 0, 359)
        except Exception as e:
            logger.error(f"[PathOracle] Redis persist error: {e}")

    return results


def get_best_path(
    redis_client, path_names: list, max_rtt_ms: float = 500
) -> Optional[str]:
    """
    Given a list of path names, return the one with lowest RTT
    that is currently UP and below max_rtt_ms.
    Returns None if all paths are degraded.
    """
    try:
        oracle_data = redis_client.hgetall(REDIS_KEY)
    except Exception:
        return path_names[0] if path_names else None

    best_name = None
    best_rtt = float("inf")

    for name in path_names:
        raw = oracle_data.get(name)
        if not raw:
            continue
        try:
            data = json.loads(raw)
            if data.get("status") != "up":
                continue
            rtt = data.get("rtt_ms", 9999)
            if rtt < best_rtt and rtt <= max_rtt_ms:
                best_rtt = rtt
                best_name = name
        except (json.JSONDecodeError, TypeError):
            continue

    return best_name


# ── Standalone daemon ────────────────────────────────────────────

def run_daemon():
    """Run the path oracle as a standalone daemon (for systemd/Chronos)."""
    import redis as redis_lib

    password = os.getenv("REDIS_PASSWORD", "").strip().strip("\"'") or None
    r = redis_lib.Redis(
        host="127.0.0.1",
        port=int(os.getenv("REDIS_PORT", "6380")),
        password=password,
        decode_responses=True,
        socket_connect_timeout=5,
    )

    logger.info(f"[PathOracle] Starting daemon (interval={PROBE_INTERVAL}s)")

    while True:
        try:
            results = probe_all(r)
            up = sum(1 for v in results.values() if v.get("status") == "up")
            down = sum(1 for v in results.values() if v.get("status") == "down")
            logger.info(
                f"[PathOracle] Probe complete: {up} up, {down} down, "
                f"redis={results.get('redis', {}).get('rtt_ms', '?')}ms"
            )
        except Exception as e:
            logger.error(f"[PathOracle] Probe cycle error: {e}")

        time.sleep(PROBE_INTERVAL)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")
    run_daemon()
