"""
🛡️ KERNELL OS — Micro-SCION · ISD Boundary Enforcer
═════════════════════════════════════════════════════
Runtime enforcement of Isolation Domain boundaries.

Provides:
  • can_write(agent, redis_key) → bool
  • can_read(agent, redis_key)  → bool
  • check_cross_isd(source_isd, target_isd) → (allowed, needs_multisign)
  • audit_violation(agent, key, op) → logs to Redis + Sentinel alert

The enforcer is designed to be lightweight (in-memory YAML parse,
fnmatch-based key matching) so it can be called on every Redis op
without measurable overhead.
"""

import os
import json
import time
import logging
import fnmatch
from typing import Tuple, Optional, Dict, List

logger = logging.getLogger("kernell.scion.enforcer")

# ── Lazy-loaded config ───────────────────────────────────────────
_CONFIG: Optional[dict] = None
_AGENT_ISD: Dict[str, str] = {}
_ISD_PREFIXES: Dict[str, Dict[str, List[str]]] = {}  # isd → {read: [...], write: [...]}
_CROSS_POLICY: Dict[str, dict] = {}


def _ensure_loaded():
    """Parse isd_config.yaml once and cache in module globals."""
    global _CONFIG, _AGENT_ISD, _ISD_PREFIXES, _CROSS_POLICY

    if _CONFIG is not None:
        return

    try:
        import yaml
        config_path = os.path.join(
            os.path.dirname(os.path.abspath(__file__)), "isd_config.yaml"
        )
        with open(config_path) as f:
            _CONFIG = yaml.safe_load(f)
    except Exception as e:
        logger.error(f"[SCION] Failed to load ISD config: {e}")
        _CONFIG = {"isolation_domains": {}, "cross_isd_policy": {}}
        return

    for isd_name, isd_data in _CONFIG.get("isolation_domains", {}).items():
        prefixes = isd_data.get("redis_prefixes", {})
        _ISD_PREFIXES[isd_name] = {
            "read": prefixes.get("read", []),
            "write": prefixes.get("write", []),
        }
        for agent in isd_data.get("agents", []):
            _AGENT_ISD[agent] = isd_name

    _CROSS_POLICY = _CONFIG.get("cross_isd_policy", {})


def get_agent_isd(agent_name: str) -> str:
    """Return the ISD name for a given agent, or 'unknown'."""
    _ensure_loaded()
    return _AGENT_ISD.get(agent_name, "unknown")


def _key_matches_patterns(redis_key: str, patterns: List[str]) -> bool:
    """Check if a Redis key matches any of the allowed glob patterns."""
    for pattern in patterns:
        if fnmatch.fnmatch(redis_key, pattern):
            return True
    return False


# ── Public API ───────────────────────────────────────────────────


def can_read(agent_name: str, redis_key: str) -> bool:
    """
    Check if an agent is allowed to READ a given Redis key.
    Based on ISD membership and declared read prefixes.
    """
    _ensure_loaded()
    isd = _AGENT_ISD.get(agent_name)
    if not isd:
        logger.debug(f"[SCION] Agent '{agent_name}' not in any ISD — read denied")
        return False

    prefixes = _ISD_PREFIXES.get(isd, {}).get("read", [])

    # Agents can always read their own heartbeat/status keys
    if redis_key.startswith(f"kernell:agent:{agent_name}:"):
        return True

    return _key_matches_patterns(redis_key, prefixes)


def can_write(agent_name: str, redis_key: str) -> bool:
    """
    Check if an agent is allowed to WRITE a given Redis key.
    Based on ISD membership and declared write prefixes.
    """
    _ensure_loaded()
    isd = _AGENT_ISD.get(agent_name)
    if not isd:
        logger.debug(f"[SCION] Agent '{agent_name}' not in any ISD — write denied")
        return False

    prefixes = _ISD_PREFIXES.get(isd, {}).get("write", [])

    # Agents can always write their own heartbeat/status keys
    if redis_key.startswith(f"kernell:agent:{agent_name}:"):
        return True

    return _key_matches_patterns(redis_key, prefixes)


def check_cross_isd(
    source_agent: str, target_agent: str
) -> Tuple[bool, bool]:
    """
    Check if cross-ISD communication is allowed.

    Returns:
        (allowed: bool, requires_multisign: bool)
    """
    _ensure_loaded()
    source_isd = _AGENT_ISD.get(source_agent, "unknown")
    target_isd = _AGENT_ISD.get(target_agent, "unknown")

    # Same ISD = always allowed, no multisign needed
    if source_isd == target_isd:
        return True, False

    policy = _CROSS_POLICY.get(source_isd, {})
    allowed_targets = policy.get("allowed_targets", [])
    require_multisign = policy.get("require_multisign", False)

    # Wildcard = can reach any ISD
    if "*" in allowed_targets:
        return True, require_multisign

    if target_isd in allowed_targets:
        return True, require_multisign

    return False, False


def audit_violation(
    agent_name: str,
    redis_key: str,
    operation: str,
    redis_client=None,
):
    """
    Log an ISD boundary violation. Reports to:
      1. Python logger (always)
      2. Redis event stream (if client provided)
      3. Sentinel alert queue (if client provided)
    """
    isd = get_agent_isd(agent_name)
    msg = (
        f"[SCION] 🚨 ISD VIOLATION: agent='{agent_name}' (ISD:{isd}) "
        f"attempted {operation.upper()} on key='{redis_key}'"
    )
    logger.error(msg)

    if redis_client:
        try:
            event = {
                "type": "scion_isd_violation",
                "agent": agent_name,
                "isd": isd,
                "key": redis_key,
                "operation": operation,
                "timestamp": time.time(),
            }
            redis_client.lpush("kernell:events:security", json.dumps(event))
            redis_client.ltrim("kernell:events:security", 0, 999)

            # Alert Sentinel directly
            redis_client.lpush(
                "kernell:sentinel:internal_alert",
                json.dumps({
                    "issue": f"ISD boundary violation by {agent_name}",
                    "details": msg,
                    "severity": "HIGH",
                    "source": "scion_enforcer",
                    "timestamp": time.time(),
                }),
            )
        except Exception as e:
            logger.error(f"[SCION] Could not log violation to Redis: {e}")


def get_isd_summary() -> dict:
    """
    Return a summary of all ISDs, their agents, and trust levels.
    Useful for the dashboard.
    """
    _ensure_loaded()
    summary = {}
    for isd_name, isd_data in (_CONFIG or {}).get("isolation_domains", {}).items():
        summary[isd_name] = {
            "agents": isd_data.get("agents", []),
            "trust_level": isd_data.get("trust_level", "unknown"),
            "self_protected": isd_data.get("self_protected", False),
            "read_prefixes": len(isd_data.get("redis_prefixes", {}).get("read", [])),
            "write_prefixes": len(isd_data.get("redis_prefixes", {}).get("write", [])),
        }
    return summary
