"""
🔐 KERNELL OS — Micro-SCION · Signed Message Envelope
═══════════════════════════════════════════════════════
SCION-inspired cryptographic message wrapper for inter-agent
communication via Redis.  Every message carries:

  • origin    – the agent that created the message
  • isd       – the Isolation Domain of the origin agent
  • path      – ordered list of agents the message traversed
  • timestamp – creation time (replay-attack window = 120s)
  • sig       – HMAC-SHA256 over (origin + payload + ts)

Usage:
    from core.scion.signed_envelope import sign, verify, wrap, unwrap

    envelope = wrap("nemesis", {"action": "open_trade", "symbol": "EURUSD"})
    redis.publish("kernell:tasks:risk_manager", json.dumps(envelope))

    # On receiving side:
    ok, payload, meta = unwrap(envelope_dict)
    if not ok:
        log.error(f"Rejected message: {meta['error']}")
"""

import os
import hmac
import json
import time
import hashlib
import logging
from typing import Tuple, Optional

logger = logging.getLogger("kernell.scion.envelope")

# ── Secret derivation ────────────────────────────────────────────
# Each agent derives its signing key from a shared master secret
# combined with its own name: HMAC(master, agent_name).
# This means agents can't forge signatures for other agents.

_MASTER_SECRET = os.getenv("KERNELL_MULTISIGN_SECRET", "")
if not _MASTER_SECRET:
    _seed = (
        os.getenv("REDIS_PASSWORD", "")
        + os.getenv("KERNELL_ROOT", "/home/anny/kernell-os")
    ).encode()
    _MASTER_SECRET = hashlib.sha256(_seed).hexdigest()

# Replay window — reject messages older than this
REPLAY_WINDOW_SECONDS = int(os.getenv("SCION_REPLAY_WINDOW", "120"))

# ── ISD lookup cache (loaded lazily) ─────────────────────────────
_ISD_MAP: Optional[dict] = None


def _load_isd_map() -> dict:
    """Load agent→ISD mapping from isd_config.yaml."""
    global _ISD_MAP
    if _ISD_MAP is not None:
        return _ISD_MAP

    _ISD_MAP = {}
    try:
        import yaml
        config_path = os.path.join(
            os.path.dirname(os.path.abspath(__file__)), "isd_config.yaml"
        )
        with open(config_path) as f:
            config = yaml.safe_load(f)

        for isd_name, isd_data in config.get("isolation_domains", {}).items():
            for agent in isd_data.get("agents", []):
                _ISD_MAP[agent] = isd_name
    except Exception as e:
        logger.warning(f"[SCION] Could not load ISD config: {e}")

    return _ISD_MAP


def _derive_agent_key(agent_name: str) -> bytes:
    """Derive a unique signing key for an agent from the master secret."""
    return hmac.new(
        _MASTER_SECRET.encode() if isinstance(_MASTER_SECRET, str) else _MASTER_SECRET,
        agent_name.encode(),
        hashlib.sha256,
    ).digest()


# ── Public API ───────────────────────────────────────────────────


def sign(agent_name: str, payload_bytes: bytes, timestamp: float) -> str:
    """
    Produce HMAC-SHA256 signature of (agent_name || timestamp || payload).
    Returns hex digest string.
    """
    key = _derive_agent_key(agent_name)
    message = f"{agent_name}:{timestamp}:".encode() + payload_bytes
    return hmac.new(key, message, hashlib.sha256).hexdigest()


def verify(agent_name: str, payload_bytes: bytes, timestamp: float, sig: str) -> bool:
    """
    Verify an HMAC signature. Uses constant-time comparison.
    """
    expected = sign(agent_name, payload_bytes, timestamp)
    return hmac.compare_digest(expected, sig)


def wrap(
    agent_name: str,
    payload: dict,
    path: Optional[list] = None,
) -> dict:
    """
    Wrap a payload dict into a signed SCION envelope.

    Args:
        agent_name: The agent creating the message.
        payload: The actual message content (any JSON-serializable dict).
        path: Optional ordered list of agents in the routing path.

    Returns:
        A dict envelope ready to be JSON-serialized and sent via Redis.
    """
    isd_map = _load_isd_map()
    ts = time.time()
    payload_bytes = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    sig = sign(agent_name, payload_bytes, ts)

    return {
        "scion_v": 1,
        "origin": agent_name,
        "isd": isd_map.get(agent_name, "unknown"),
        "path": path or [agent_name],
        "ts": ts,
        "sig": sig,
        "payload": payload,
    }


def unwrap(
    envelope: dict,
    max_age: Optional[int] = None,
) -> Tuple[bool, Optional[dict], dict]:
    """
    Verify and unwrap a signed SCION envelope.

    Args:
        envelope: The envelope dict (from JSON deserialization).
        max_age: Override for replay window (seconds). None = use default.

    Returns:
        Tuple of (valid: bool, payload: dict|None, meta: dict).
        meta always contains 'origin', 'isd', 'path'.
        If invalid, meta['error'] explains why.
    """
    meta = {
        "origin": envelope.get("origin", "?"),
        "isd": envelope.get("isd", "?"),
        "path": envelope.get("path", []),
    }

    # ── Version check
    if envelope.get("scion_v") != 1:
        meta["error"] = f"Unknown envelope version: {envelope.get('scion_v')}"
        return False, None, meta

    origin = envelope.get("origin")
    ts = envelope.get("ts", 0)
    sig = envelope.get("sig", "")
    payload = envelope.get("payload")

    if not origin or not sig or payload is None:
        meta["error"] = "Missing required fields (origin, sig, payload)"
        return False, None, meta

    # ── Replay attack check
    age = time.time() - ts
    window = max_age if max_age is not None else REPLAY_WINDOW_SECONDS
    if age > window:
        meta["error"] = f"Message too old: {age:.1f}s (window: {window}s)"
        return False, None, meta

    if age < -10:  # Clock skew tolerance
        meta["error"] = f"Message from the future: {age:.1f}s"
        return False, None, meta

    # ── Signature verification
    payload_bytes = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    if not verify(origin, payload_bytes, ts, sig):
        meta["error"] = f"Invalid HMAC signature from '{origin}'"
        logger.warning(f"[SCION] ⚠️ SIGNATURE MISMATCH from {origin} (ISD: {meta['isd']})")
        return False, None, meta

    return True, payload, meta


def append_path(envelope: dict, agent_name: str) -> dict:
    """
    Append an agent to the routing path of an envelope.
    Used when an agent relays a message (e.g., Herald as Border Router).
    Does NOT re-sign — the original signature remains for origin verification.
    """
    envelope = dict(envelope)  # Shallow copy
    path = list(envelope.get("path", []))
    if agent_name not in path:
        path.append(agent_name)
    envelope["path"] = path
    return envelope
