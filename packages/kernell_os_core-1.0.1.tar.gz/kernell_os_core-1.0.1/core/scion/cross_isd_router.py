"""
🌐 KERNELL OS — Micro-SCION · Cross-ISD Router
════════════════════════════════════════════════
Herald-based Border Router for cross-Isolation-Domain communication.

In SCION, Border Routers control traffic between Isolation Domains.
In Kernell OS, Herald acts as the Border Router — it's the only agent
that can relay messages between ISDs when the cross_isd_policy allows it.

This module provides:
  • route_cross_isd()  — Route a message from one ISD to another
  • validate_route()   — Check if a cross-ISD route is permitted
  • get_routing_table() — Return all permitted cross-ISD routes

The router enforces:
  1. Source ISD must be allowed to reach target ISD (policy check)
  2. If require_multisign=true, the message must carry a valid MultiSign quorum
  3. The message must carry a valid signed envelope
  4. The path header is updated with Herald as relay hop
"""

import json
import time
import logging
from typing import Dict, Any, Tuple, Optional, List

logger = logging.getLogger("kernell.scion.cross_isd_router")

# ── Dependencies (fail-open) ─────────────────────────────────────────
try:
    from core.scion.isd_enforcer import (
        check_cross_isd,
        get_agent_isd,
        get_isd_summary,
        audit_violation,
    )
    _ENFORCER_AVAILABLE = True
except ImportError:
    _ENFORCER_AVAILABLE = False

try:
    from core.scion.signed_envelope import (
        wrap as _scion_wrap,
        unwrap as _scion_unwrap,
        append_path as _scion_append_path,
    )
    _ENVELOPE_AVAILABLE = True
except ImportError:
    _ENVELOPE_AVAILABLE = False


# ── Routing table ────────────────────────────────────────────────────

BORDER_ROUTER_AGENT = "herald"


class CrossISDRouter:
    """
    Cross-ISD message router.

    Acts as a security checkpoint — validates that cross-domain
    communication is authorized before forwarding messages.
    """

    def __init__(self, redis_client):
        self.redis = redis_client
        self._stats = {
            "routed": 0,
            "blocked_policy": 0,
            "blocked_envelope": 0,
            "blocked_multisign": 0,
        }

    def validate_route(
        self,
        source_agent: str,
        target_agent: str,
    ) -> Tuple[bool, str]:
        """
        Check if a cross-ISD route is permitted.

        Returns:
            (allowed: bool, reason: str)
        """
        if not _ENFORCER_AVAILABLE:
            return True, "SCION enforcer unavailable — fail-open"

        source_isd = get_agent_isd(source_agent)
        target_isd = get_agent_isd(target_agent)

        # Same ISD = always allowed
        if source_isd == target_isd:
            return True, f"Same ISD ({source_isd})"

        allowed, needs_multisign = check_cross_isd(source_agent, target_agent)

        if not allowed:
            return False, (
                f"Cross-ISD blocked: {source_isd} → {target_isd} "
                f"(agent {source_agent} → {target_agent})"
            )

        if needs_multisign:
            return True, f"Allowed with multisign ({source_isd} → {target_isd})"

        return True, f"Allowed ({source_isd} → {target_isd})"

    def route_message(
        self,
        source_agent: str,
        target_queue: str,
        payload: dict,
        require_envelope: bool = True,
    ) -> Dict[str, Any]:
        """
        Route a message across ISD boundaries via Herald as Border Router.

        Steps:
          1. Validate the cross-ISD policy
          2. Verify the signed envelope (if required)
          3. Append Herald to the path header
          4. Forward to the target queue

        Returns:
            Dict with status, path, and routing metadata.
        """
        # Extract target agent from queue name
        # e.g., "kernell:tasks:sentinel" → "sentinel"
        parts = target_queue.split(":")
        target_agent = parts[-1] if len(parts) >= 3 else "unknown"

        # ── Step 1: Policy check ────────────────────────────────────
        allowed, reason = self.validate_route(source_agent, target_agent)
        if not allowed:
            self._stats["blocked_policy"] += 1
            logger.warning(f"[CrossISD] ⛔ {reason}")
            if _ENFORCER_AVAILABLE:
                audit_violation(source_agent, target_queue, "cross_isd_write", self.redis)
            return {
                "status": "blocked",
                "reason": reason,
                "source": source_agent,
                "target": target_agent,
            }

        # ── Step 2: Check multisign requirement ─────────────────────
        if _ENFORCER_AVAILABLE:
            _, needs_multisign = check_cross_isd(source_agent, target_agent)
            if needs_multisign:
                # For now, log the requirement — full multisign verification
                # integrates with agent_multisign.py
                has_quorum = payload.get("multisign_quorum", False)
                if not has_quorum:
                    self._stats["blocked_multisign"] += 1
                    logger.warning(
                        f"[CrossISD] ⛔ Multisign required for "
                        f"{get_agent_isd(source_agent)} → {get_agent_isd(target_agent)}"
                    )
                    return {
                        "status": "blocked",
                        "reason": "Multisign quorum required but not provided",
                        "source": source_agent,
                        "target": target_agent,
                    }

        # ── Step 3: Wrap in signed envelope + append Herald path ────
        if _ENVELOPE_AVAILABLE and require_envelope:
            envelope = _scion_wrap(source_agent, payload)
            envelope = _scion_append_path(envelope, BORDER_ROUTER_AGENT)
            message = json.dumps(envelope)
        else:
            if require_envelope:
                self._stats["blocked_envelope"] += 1
                logger.warning("[CrossISD] ⛔ Envelope required but SCION unavailable")
                return {
                    "status": "blocked",
                    "reason": "Signed envelope required but SCION module unavailable",
                    "source": source_agent,
                    "target": target_agent,
                }
            message = json.dumps(payload)

        # ── Step 4: Forward to target queue ─────────────────────────
        try:
            self.redis.lpush(target_queue, message)
            self._stats["routed"] += 1

            source_isd = get_agent_isd(source_agent) if _ENFORCER_AVAILABLE else "?"
            target_isd = get_agent_isd(target_agent) if _ENFORCER_AVAILABLE else "?"

            logger.info(
                f"[CrossISD] ✅ Routed: {source_agent}({source_isd}) "
                f"→ [{BORDER_ROUTER_AGENT}] → {target_agent}({target_isd})"
            )

            # Audit trail
            self.redis.lpush("kernell:scion:cross_isd:audit", json.dumps({
                "ts": time.time(),
                "source": source_agent,
                "source_isd": source_isd,
                "target": target_agent,
                "target_isd": target_isd,
                "target_queue": target_queue,
                "status": "routed",
            }))
            self.redis.ltrim("kernell:scion:cross_isd:audit", 0, 499)

            return {
                "status": "routed",
                "source": source_agent,
                "source_isd": source_isd,
                "target": target_agent,
                "target_isd": target_isd,
                "path": [source_agent, BORDER_ROUTER_AGENT, target_agent],
            }

        except Exception as e:
            logger.error(f"[CrossISD] Redis forward error: {e}")
            return {"status": "error", "error": str(e)}

    def get_routing_table(self) -> List[Dict[str, Any]]:
        """
        Return all permitted cross-ISD routes based on isd_config.yaml.
        Useful for dashboard visualization.
        """
        if not _ENFORCER_AVAILABLE:
            return [{"error": "ISD enforcer unavailable"}]

        summary = get_isd_summary()
        routes = []

        isd_names = list(summary.keys())
        for source_isd in isd_names:
            source_agents = summary[source_isd].get("agents", [])
            if not source_agents:
                continue
            # Use first agent as representative
            rep_source = source_agents[0]
            for target_isd in isd_names:
                if source_isd == target_isd:
                    continue
                target_agents = summary[target_isd].get("agents", [])
                if not target_agents:
                    continue
                rep_target = target_agents[0]
                allowed, needs_ms = check_cross_isd(rep_source, rep_target)
                routes.append({
                    "source_isd": source_isd,
                    "target_isd": target_isd,
                    "allowed": allowed,
                    "requires_multisign": needs_ms,
                })

        return routes

    def get_stats(self) -> dict:
        """Return routing statistics."""
        return dict(self._stats)
