import sqlite3
import uuid
import os
import time
from typing import List, Dict, Optional
from dataclasses import dataclass
from decimal import Decimal

class LedgerIntegrityError(Exception):
    pass

@dataclass
class JournalLine:
    account_id: str
    direction: str  # "debit" or "credit"
    amount_micro: int

    def __post_init__(self):
        if self.direction not in ("debit", "credit"):
            raise ValueError("Direction must be 'debit' or 'credit'")
        if self.amount_micro <= 0:
            raise ValueError("Line amount must be > 0 micro-units")

class DoubleEntryLedger:
    """
    Fintech-grade Double-Entry Accounting Ledger.
    Ensures that money cannot be created or destroyed silently.
    All balances are derived from the journal.
    """
    
    def __init__(self, db_path: str = "/var/lib/kernell/double_entry.sqlite3"):
        self.db_path = db_path
        self._ensure_db()

    def _ensure_db(self):
        if self.db_path != ":memory:":
            os.makedirs(os.path.dirname(self.db_path) or ".", exist_ok=True)
            
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("PRAGMA journal_mode=WAL;")
            conn.execute("PRAGMA foreign_keys=ON;")
            
            conn.execute("""
            CREATE TABLE IF NOT EXISTS accounts (
                account_id TEXT PRIMARY KEY,
                tenant_id TEXT NOT NULL,
                type TEXT NOT NULL,
                currency TEXT NOT NULL,
                created_at REAL NOT NULL
            )
            """)
            
            conn.execute("""
            CREATE TABLE IF NOT EXISTS journal_entries (
                entry_id TEXT PRIMARY KEY,
                tenant_id TEXT NOT NULL,
                reference_id TEXT,
                description TEXT,
                created_at REAL NOT NULL,
                entry_hash TEXT
            )
            """)
            
            # Replaced single reference_id index with multi-tenant index
            conn.execute("""
            CREATE UNIQUE INDEX IF NOT EXISTS idx_tenant_reference_id ON journal_entries(tenant_id, reference_id)
            """)
            
            conn.execute("""
            CREATE TABLE IF NOT EXISTS journal_lines (
                line_id TEXT PRIMARY KEY,
                entry_id TEXT NOT NULL,
                tenant_id TEXT NOT NULL,
                account_id TEXT NOT NULL,
                amount_micro BIGINT NOT NULL,
                direction TEXT NOT NULL CHECK (direction IN ('debit', 'credit')),
                FOREIGN KEY(entry_id) REFERENCES journal_entries(entry_id),
                FOREIGN KEY(account_id) REFERENCES accounts(account_id)
            )
            """)
            
            conn.execute("""
            CREATE TABLE IF NOT EXISTS incoming_events (
                event_id TEXT PRIMARY KEY,
                tenant_id TEXT NOT NULL,
                payload TEXT NOT NULL,
                received_at REAL NOT NULL,
                processed_at REAL,
                error_count INTEGER DEFAULT 0,
                last_error TEXT
            )
            """)
            
            conn.execute("""
            CREATE TABLE IF NOT EXISTS dead_letter_queue (
                event_id TEXT PRIMARY KEY,
                tenant_id TEXT NOT NULL,
                payload TEXT NOT NULL,
                failed_at REAL NOT NULL,
                last_error TEXT
            )
            """)

    def save_incoming_event(self, tenant_id: str, event_id: str, payload: str) -> bool:
        """Save raw event to inbox. Returns True if saved, False if already exists."""
        with sqlite3.connect(self.db_path) as conn:
            try:
                conn.execute(
                    "INSERT INTO incoming_events (event_id, tenant_id, payload, received_at) VALUES (?, ?, ?, ?)",
                    (event_id, tenant_id, payload, time.time())
                )
                return True
            except sqlite3.IntegrityError:
                return False

    def mark_event_processed(self, event_id: str):
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("UPDATE incoming_events SET processed_at = ? WHERE event_id = ?", (time.time(), event_id))

    def mark_event_failed(self, event_id: str, error: str, max_retries: int = 3):
        with sqlite3.connect(self.db_path) as conn:
            row = conn.execute("SELECT tenant_id, payload, error_count FROM incoming_events WHERE event_id = ?", (event_id,)).fetchone()
            if not row:
                return
            
            tenant_id, payload, error_count = row
            if error_count + 1 >= max_retries:
                # Move to DLQ
                conn.execute(
                    "INSERT OR IGNORE INTO dead_letter_queue (event_id, tenant_id, payload, failed_at, last_error) VALUES (?, ?, ?, ?, ?)",
                    (event_id, tenant_id, payload, time.time(), error)
                )
                conn.execute("DELETE FROM incoming_events WHERE event_id = ?", (event_id,))
            else:
                conn.execute(
                    "UPDATE incoming_events SET error_count = error_count + 1, last_error = ? WHERE event_id = ?",
                    (error, event_id)
                )

    def get_stuck_events(self, timeout_seconds: int = 120) -> List[Dict]:
        """Detect stuck events that have not been processed within timeout."""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            threshold = time.time() - timeout_seconds
            rows = conn.execute("SELECT * FROM incoming_events WHERE processed_at IS NULL AND received_at < ?", (threshold,)).fetchall()
            return [dict(r) for r in rows]

    def get_unprocessed_events(self) -> List[Dict]:
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute("SELECT * FROM incoming_events WHERE processed_at IS NULL").fetchall()
            return [dict(r) for r in rows]

    def verify_full_chain(self, tenant_id: str) -> bool:
        """
        Cryptographic Audit: Verify the entire hash chain of the ledger for a tenant.
        If this returns False, the database has been tampered with.
        """
        import hashlib
        with sqlite3.connect(self.db_path) as conn:
            # We must fetch lines in deterministic order
            entries = conn.execute("SELECT entry_id, tenant_id, reference_id, created_at, entry_hash FROM journal_entries WHERE tenant_id = ? ORDER BY rowid ASC", (tenant_id,)).fetchall()
            
            previous_hash = "GENESIS"
            for entry in entries:
                entry_id, tenant_id, ref_id, ts, stored_hash = entry
                
                # Fetch lines for this entry
                lines = conn.execute("SELECT account_id, direction, amount_micro FROM journal_lines WHERE entry_id = ? ORDER BY account_id, direction, amount_micro", (entry_id,)).fetchall()
                lines_data = "|".join([f"{l[0]}:{l[1]}:{l[2]}" for l in lines])
                
                current_entry_data = f"{entry_id}:{tenant_id}:{ref_id}:{ts}:{lines_data}"
                expected_hash = hashlib.sha256(f"{previous_hash}{current_entry_data}".encode('utf-8')).hexdigest()
                
                if expected_hash != stored_hash:
                    return False
                    
                previous_hash = stored_hash
                
            return True

    def create_account(self, tenant_id: str, account_id: str, account_type: str, currency: str = "usd"):
        """Create a new account in the chart of accounts."""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                "INSERT OR IGNORE INTO accounts (account_id, tenant_id, type, currency, created_at) VALUES (?, ?, ?, ?, ?)",
                (account_id, tenant_id, account_type, currency, time.time())
            )

    def get_account_balance(self, tenant_id: str, account_id: str) -> int:
        """
        Derive the balance dynamically. NEVER STORE BALANCES.
        For asset accounts: Balance = Debits - Credits.
        """
        with sqlite3.connect(self.db_path) as conn:
            # Check if account exists
            row = conn.execute("SELECT account_id FROM accounts WHERE account_id=? AND tenant_id=?", (account_id, tenant_id)).fetchone()
            if not row:
                raise ValueError(f"Account {account_id} not found for tenant {tenant_id}")

            # Sum Debits
            debits_row = conn.execute(
                "SELECT SUM(amount_micro) FROM journal_lines WHERE account_id=? AND tenant_id=? AND direction='debit'",
                (account_id, tenant_id)
            ).fetchone()
            debits = debits_row[0] or 0

            # Sum Credits
            credits_row = conn.execute(
                "SELECT SUM(amount_micro) FROM journal_lines WHERE account_id=? AND tenant_id=? AND direction='credit'",
                (account_id, tenant_id)
            ).fetchone()
            credits = credits_row[0] or 0

            # Balance = Debits - Credits
            return debits - credits

    def check_tenant_invariant(self, tenant_id: str) -> bool:
        """
        Multi-Tenant Invariant:
        La suma de débitos menos suma de créditos dentro de un TENANT debe ser 0.
        """
        with sqlite3.connect(self.db_path) as conn:
            row = conn.execute(
                """
                SELECT 
                    COALESCE(SUM(CASE WHEN direction = 'debit' THEN amount_micro ELSE 0 END), 0) as total_debit,
                    COALESCE(SUM(CASE WHEN direction = 'credit' THEN amount_micro ELSE 0 END), 0) as total_credit
                FROM journal_lines WHERE tenant_id = ?
                """, (tenant_id,)
            ).fetchone()
            
            total_debit, total_credit = row[0], row[1]
            return total_debit == total_credit

    def check_global_invariant(self) -> bool:
        """
        Fintech Big Four Invariant:
        La suma de TODOS los débitos en TODO el sistema menos la suma de TODOS los créditos
        DEBE ser exactamente 0 SIEMPRE.
        Si esto devuelve False, el sistema financiero está comprometido.
        """
        with sqlite3.connect(self.db_path) as conn:
            row = conn.execute(
                """
                SELECT 
                    COALESCE(SUM(CASE WHEN direction = 'debit' THEN amount_micro ELSE 0 END), 0) as total_debit,
                    COALESCE(SUM(CASE WHEN direction = 'credit' THEN amount_micro ELSE 0 END), 0) as total_credit
                FROM journal_lines
                """
            ).fetchone()
            
            total_debit, total_credit = row[0], row[1]
            return total_debit == total_credit

    def create_journal_entry(self, tenant_id: str, reference_id: str, description: str, lines: List[JournalLine]) -> str:
        """
        Safely write a balanced journal entry for a specific tenant.
        Rolls back automatically if crashes or if unbalanced.
        """
        if not lines:
            raise ValueError("A journal entry must have lines")

        total_debit = sum(l.amount_micro for l in lines if l.direction == "debit")
        total_credit = sum(l.amount_micro for l in lines if l.direction == "credit")

        if total_debit != total_credit:
            raise LedgerIntegrityError(
                f"Unbalanced journal entry: Debits ({total_debit}) != Credits ({total_credit})"
            )

        entry_id = f"je_{uuid.uuid4().hex}"
        now = time.time()
        
        # We need a stable representation of the lines for hashing
        lines_data = "|".join([f"{l.account_id}:{l.direction}:{l.amount_micro}" for l in sorted(lines, key=lambda x: (x.account_id, x.direction, x.amount_micro))])

        # Context manager for sqlite3 connections handles the BEGIN/COMMIT/ROLLBACK transaction logic
        with sqlite3.connect(self.db_path) as conn:
            # Enable Foreign Keys for this connection
            conn.execute("PRAGMA foreign_keys=ON;")
            
            try:
                # Calculate entry_hash scoped to tenant
                last_hash_row = conn.execute("SELECT entry_hash FROM journal_entries WHERE tenant_id = ? ORDER BY rowid DESC LIMIT 1", (tenant_id,)).fetchone()
                previous_hash = last_hash_row[0] if last_hash_row and last_hash_row[0] else "GENESIS"
                
                import hashlib
                current_entry_data = f"{entry_id}:{tenant_id}:{reference_id}:{now}:{lines_data}"
                entry_hash = hashlib.sha256(f"{previous_hash}{current_entry_data}".encode('utf-8')).hexdigest()
                
                # Step 1: Insert Header
                conn.execute(
                    "INSERT INTO journal_entries (entry_id, tenant_id, reference_id, description, created_at, entry_hash) VALUES (?, ?, ?, ?, ?, ?)",
                    (entry_id, tenant_id, reference_id, description, now, entry_hash)
                )
            except sqlite3.IntegrityError as e:
                # Idempotency fallback: If it's a replay of an existing tenant_id + reference_id
                existing = conn.execute("SELECT entry_id FROM journal_entries WHERE tenant_id = ? AND reference_id = ?", (tenant_id, reference_id)).fetchone()
                if existing:
                    return existing[0]
                raise

            # Step 2: Insert Lines
            for line in lines:
                line_id = f"jl_{uuid.uuid4().hex}"
                conn.execute(
                    "INSERT INTO journal_lines (line_id, entry_id, tenant_id, account_id, amount_micro, direction) VALUES (?, ?, ?, ?, ?, ?)",
                    (line_id, entry_id, tenant_id, line.account_id, line.amount_micro, line.direction)
                )

        return entry_id
