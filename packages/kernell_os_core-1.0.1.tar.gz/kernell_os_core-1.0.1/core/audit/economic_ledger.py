import hashlib
import json
import logging
import os
import time
from typing import Any, Dict, Optional

logger = logging.getLogger("ECONOMIC_LEDGER")


class EconomicLedger:
    """
    Append-only audit ledger for sensitive economic/security actions.
    Persists to JSONL file and optionally mirrors to Redis.
    """

    def __init__(self, redis_client=None, ledger_path: Optional[str] = None):
        self.redis = redis_client
        self.ledger_path = ledger_path or os.getenv(
            "KERNELL_ECONOMIC_LEDGER_PATH",
            "/home/anny/kernell-os/data/economic_ledger.jsonl",
        )
        os.makedirs(os.path.dirname(self.ledger_path), exist_ok=True)

    def append_event(
        self,
        *,
        domain: str,
        action: str,
        status: str,
        run_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        ts = time.time()
        metadata = metadata or {}
        raw = json.dumps(
            {
                "ts": ts,
                "domain": domain,
                "action": action,
                "status": status,
                "run_id": run_id,
                "metadata": metadata,
            },
            sort_keys=True,
        )
        digest = hashlib.sha256(raw.encode("utf-8")).hexdigest()
        entry = {
            "ts": ts,
            "domain": domain,
            "action": action,
            "status": status,
            "run_id": run_id,
            "metadata": metadata,
            "hash": digest,
        }
        try:
            with open(self.ledger_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry, ensure_ascii=True) + "\n")
        except Exception as e:
            logger.error("Failed to write ledger file: %s", e)

        if self.redis:
            try:
                self.redis.lpush("kernell:audit:economic_ledger", json.dumps(entry))
                self.redis.ltrim("kernell:audit:economic_ledger", 0, 5000)
            except Exception:
                pass

        return entry

