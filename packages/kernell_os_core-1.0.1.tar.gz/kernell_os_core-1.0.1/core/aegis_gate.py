"""
╔══════════════════════════════════════════════════════════════════════╗
║  PALANTIR GATE — Kernell OS Code Modification Enforcement Engine     ║
║  Versión: 1.0 | Clasificación: CORE INFRASTRUCTURE                  ║
╚══════════════════════════════════════════════════════════════════════╝

PROPÓSITO:
  Intercepta TODA intención de modificación de código, archivos de
  configuración o infraestructura por parte de agentes LLM (especialmente
  Forge) y la valida contra la normativa antes de ejecutarla.

  Si el LLM no puede hacer la llamada a AegisGate.evaluate(), no puede
  modificar el sistema. El gate es el único punto de entrada autorizado.

ARQUITECTURA:
  LLM (Forge) → AegisGate.evaluate(intent) → [ALLOW / BLOCK / ESCALATE]
                       ↓
              Compliance LLM Call (verifica la acción contra la normativa)
                       ↓
              Audit Log (inmutable, append-only)

INSTALACIÓN:
  cp aegis_gate.py ~/kernell-os/core/aegis_gate.py

INTEGRACIÓN EN FORGE:
  from core.aegis_gate import AegisGate, ModificationIntent

  gate = AegisGate(redis_client, audit_log)

  intent = ModificationIntent(
      agent="forge",
      action="write_file",
      target="agents/kernell/kernell_server.py",
      content=new_code,
      reason="Fix port binding bug",
  )

  result = await gate.evaluate(intent)
  if result.allowed:
      # recién aquí se escribe el archivo
      Path(intent.target).write_text(intent.content)
  else:
      raise PermissionError(result.block_reason)
"""

import asyncio
import hashlib
import json
import os
import re
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Optional

import redis


# ─── Enums ────────────────────────────────────────────────────────────────────

class RiskLevel(Enum):
    AUTO     = "auto"      # Atlas/Forge puede aplicar solo
    REVIEW   = "review"    # Necesita notificación al Arquitecto
    BLOCK    = "block"     # Requiere MFA + aprobación explícita


class GateDecision(Enum):
    ALLOW    = "allow"
    BLOCK    = "block"
    ESCALATE = "escalate"  # Requiere MFA del Arquitecto


# ─── Patrones de archivos por riesgo (de la normativa §6.2) ──────────────────

RISK_RULES: list[tuple[str, RiskLevel, str]] = [
    # (patrón regex, nivel de riesgo, razón)
    (r"^core/constitution\.ya?ml$",              RiskLevel.BLOCK,  "Constitución — solo Arquitecto con MFA"),
    (r"^scripts/mfa_gate\.py$",                  RiskLevel.BLOCK,  "Sistema MFA — solo Arquitecto con MFA"),
    (r"^scripts/boot_sequence\.py$",             RiskLevel.BLOCK,  "Boot sequence — solo Arquitecto con MFA"),
    (r"^core/aegis_gate\.py$",                RiskLevel.BLOCK,  "Auto-modificación del gate prohibida"),
    (r"^core/normativa\..*$",                    RiskLevel.BLOCK,  "Normativa — solo Arquitecto con MFA"),
    (r"^\.env$",                                  RiskLevel.BLOCK,  "Credenciales — nunca en el repo"),
    (r".*\.env\..*$",                             RiskLevel.BLOCK,  "Credenciales — nunca en el repo"),
    (r"^core/manifest\.ya?ml$",                  RiskLevel.REVIEW, "Manifest KSM — requiere ksm_validator"),
    (r"^core/ontology\.ya?ml$",                  RiskLevel.REVIEW, "Ontología — requiere aprobación de Atlas"),
    (r"^agents/[^/]+/[^/]+\.py$",               RiskLevel.REVIEW, "Código de agente — requiere aprobación de Atlas"),
    (r"^infra/systemd/.*\.service$",             RiskLevel.AUTO,   "Service file — Atlas aplica tras validación"),
    (r"^agents/[^/]+/config\.ya?ml$",           RiskLevel.AUTO,   "Config de agente — Atlas aplica en ciclo"),
]

# Patrones que Forge NUNCA puede escribir (normativa §5.2)
FORBIDDEN_PATTERNS: list[tuple[str, str]] = [
    (r"eval\s*\(",                    "eval() con input arbitrario — prohibido (C-04)"),
    (r"exec\s*\(",                    "exec() con input arbitrario — prohibido (C-04)"),
    (r'subprocess.*shell\s*=\s*True', "subprocess con shell=True — prohibido (C-04)"),
    (r"except\s*:",                   "bare except — prohibido (C-04), usar except Exception"),
    (r'(OPENAI|ANTHROPIC|GEMINI|API)_KEY\s*=\s*["\'][A-Za-z0-9]', "API key hardcodeada — prohibido (C-05)"),
    (r'password\s*=\s*["\'][^"\']+["\']',                          "Password hardcodeada — prohibido (C-05)"),
    (r'secret\s*=\s*["\'][^"\']+["\']',                            "Secret hardcodeado — prohibido (C-05)"),
    (r"time\.sleep\(",                "time.sleep() en código async — usar asyncio.sleep() (C-09)"),
    (r"threading\.Thread\(",          "threading.Thread sin daemon=True — revisar (C-10)"),
    (r"requests\.(get|post|put|delete|patch)\s*\([^)]*\)",         "requests sin timeout explícito — prohibido (C-07)"),
]

# Archivos protegidos que no pueden ser eliminados (solo sobrescritos con aprobación)
PROTECTED_FILES: set[str] = {
    "core/manifest.yaml",
    "core/ontology.yaml",
    "core/constitution.yaml",
    "core/normativa.docx",
    "scripts/boot_sequence.py",
    "scripts/mfa_gate.py",
    "core/aegis_gate.py",
    "agents/core/immutable_audit_log.py",
    "agents/core/ephemeral_manager.py",
}


# ─── Data Classes ─────────────────────────────────────────────────────────────

@dataclass
class ModificationIntent:
    """Representa la intención de un agente de modificar el sistema."""
    agent: str                        # "forge", "atlas", "fixer", etc.
    action: str                       # "write_file", "delete_file", "execute_command"
    target: str                       # path relativo al repo root
    content: Optional[str] = None     # contenido nuevo (para write_file)
    command: Optional[str] = None     # comando (para execute_command)
    reason: str = ""                  # justificación del LLM
    task_id: Optional[str] = None     # ID de la tarea en Redis
    mfa_token: Optional[str] = None   # token TOTP si fue provisto
    timestamp: float = field(default_factory=time.time)


@dataclass
class GateResult:
    """Resultado de la evaluación del Aegis Gate."""
    decision: GateDecision
    risk_level: RiskLevel
    allowed: bool
    block_reason: Optional[str] = None
    warnings: list[str] = field(default_factory=list)
    requires_mfa: bool = False
    audit_entry_id: Optional[str] = None
    forbidden_patterns_found: list[str] = field(default_factory=list)


# ─── Main Gate ────────────────────────────────────────────────────────────────

class AegisGate:
    """
    Aegis Gate — punto de entrada único para modificaciones del sistema.

    Principio: El LLM nunca puede bypassear este gate. Si no pasa por aquí,
    la modificación no ocurre. Point of no return.
    """

    def __init__(
        self,
        redis_client: redis.Redis,
        repo_root: str = "/home/anny/kernell-os",
        audit_log=None,       # ImmutableAuditLog instance
        llm_compliance: bool = True,  # Activar validación via LLM secundario
    ):
        self.redis = redis_client
        self.repo_root = Path(repo_root)
        self.audit_log = audit_log
        self.llm_compliance = llm_compliance

    # ── Punto de entrada principal ────────────────────────────────────────────

    async def evaluate(self, intent: ModificationIntent) -> GateResult:
        """
        Evalúa si una intención de modificación está permitida.

        Ejecuta en orden:
        1. Verificación de acción básica
        2. Clasificación de riesgo por path
        3. Validación de contenido (patrones prohibidos)
        4. Verificación MFA si aplica
        5. Validación LLM (compliance check)
        6. Registro en Audit Log
        """
        warnings = []
        forbidden = []

        # ── 1. Verificar que el agente tiene autoridad para modificar ─────────
        agent_authority = self._get_agent_authority(intent.agent)
        if agent_authority < 3:
            return self._block(
                intent,
                risk_level=RiskLevel.BLOCK,
                reason=f"Agente {intent.agent} tiene autoridad {agent_authority} — modificaciones requieren authority≥3",
                warnings=warnings,
                forbidden=forbidden,
            )

        # ── 2. Clasificar el riesgo del path objetivo ─────────────────────────
        risk_level, risk_reason = self._classify_path_risk(intent.target)

        # ── 3. Verificar archivos protegidos para DELETE ───────────────────────
        if intent.action == "delete_file":
            normalized = intent.target.lstrip("/")
            if normalized in PROTECTED_FILES:
                return self._block(
                    intent,
                    risk_level=RiskLevel.BLOCK,
                    reason=f"Archivo protegido — delete prohibido: {intent.target}",
                    warnings=warnings,
                    forbidden=forbidden,
                )

        # ── 4. Validar contenido: patrones prohibidos ─────────────────────────
        if intent.content and intent.action == "write_file":
            forbidden = self._scan_forbidden_patterns(intent.content)
            if forbidden:
                return self._block(
                    intent,
                    risk_level=RiskLevel.BLOCK,
                    reason=f"Contenido contiene {len(forbidden)} patrón(es) prohibido(s): {forbidden[0]}",
                    warnings=warnings,
                    forbidden=forbidden,
                )

        # ── 5. Verificar MFA para operaciones BLOCK ───────────────────────────
        if risk_level == RiskLevel.BLOCK:
            if not intent.mfa_token:
                result = GateResult(
                    decision=GateDecision.ESCALATE,
                    risk_level=risk_level,
                    allowed=False,
                    block_reason=f"Requiere MFA del Arquitecto: {risk_reason}",
                    warnings=warnings,
                    requires_mfa=True,
                    forbidden_patterns_found=forbidden,
                )
                await self._audit(intent, result)
                await self._escalate_to_architect(intent, risk_reason)
                return result

            valid_mfa = await self._verify_mfa_token(intent.mfa_token)
            if not valid_mfa:
                return self._block(
                    intent,
                    risk_level=risk_level,
                    reason="Token MFA inválido o expirado",
                    warnings=warnings,
                    forbidden=forbidden,
                )

        # ── 6. Validación LLM: compliance check secundario ────────────────────
        if self.llm_compliance and intent.reason:
            compliance_ok, compliance_issues = await self._llm_compliance_check(intent)
            if not compliance_ok:
                warnings.extend(compliance_issues)
                # Solo bloquea si hay issues CRÍTICOS, no todos
                critical = [i for i in compliance_issues if i.startswith("[BLOCK]")]
                if critical:
                    return self._block(
                        intent,
                        risk_level=risk_level,
                        reason=f"Compliance LLM: {critical[0]}",
                        warnings=warnings,
                        forbidden=forbidden,
                    )

        # ── 7. Para REVIEW, notificar a Atlas ─────────────────────────────────
        if risk_level == RiskLevel.REVIEW:
            await self._notify_atlas(intent, risk_reason)
            warnings.append(f"Atlas notificado: {risk_reason}")

        # ── 8. ALLOW ──────────────────────────────────────────────────────────
        result = GateResult(
            decision=GateDecision.ALLOW,
            risk_level=risk_level,
            allowed=True,
            warnings=warnings,
            forbidden_patterns_found=forbidden,
        )
        await self._audit(intent, result)
        return result

    # ── Clasificación de riesgo por path ─────────────────────────────────────

    def _classify_path_risk(self, path: str) -> tuple[RiskLevel, str]:
        """Clasifica el riesgo de modificar un path dado."""
        normalized = path.lstrip("/")

        for pattern, level, reason in RISK_RULES:
            if re.match(pattern, normalized):
                return level, reason

        # Default: código nuevo en una ruta no mapeada = REVIEW
        if normalized.endswith(".py") or normalized.endswith(".yaml"):
            return RiskLevel.REVIEW, "Archivo Python/YAML no mapeado — revisión por precaución"

        return RiskLevel.AUTO, "Archivo de bajo riesgo"

    # ── Scan de patrones prohibidos ───────────────────────────────────────────

    def _scan_forbidden_patterns(self, content: str) -> list[str]:
        """Escanea el contenido en busca de patrones prohibidos por la normativa."""
        found = []
        lines = content.split("\n")

        for i, line in enumerate(lines, 1):
            # Saltar comentarios y docstrings
            stripped = line.strip()
            if stripped.startswith("#") or stripped.startswith('"""') or stripped.startswith("'''"):
                continue

            for pattern, description in FORBIDDEN_PATTERNS:
                if re.search(pattern, line, re.IGNORECASE):
                    found.append(f"Línea {i}: {description}")
                    break  # Un error por línea es suficiente

        return found

    # ── Autoridad de agentes ──────────────────────────────────────────────────

    def _get_agent_authority(self, agent_name: str) -> int:
        """Retorna el nivel de autoridad de un agente (de ontology.yaml)."""
        AUTHORITY_MAP = {
            "kernell":   5,
            "overseer":  5,
            "atlas":     5,
            "observer":  999,  # Tier infinito
            "forge":     4,
            "fixer":     3,
            "nexus":     3,
            "chronos":   3,
            "sea":       3,
            "sentinel":  3,
            "sierra":    3,
            "economy":   2,
            "nemesis":   2,
            "herald":    2,
            "ads":       1,
            "hunter":    1,
            "scribe":    1,
            "bounty":    1,
        }
        return AUTHORITY_MAP.get(agent_name.lower(), 0)

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _block(
        self,
        intent: ModificationIntent,
        risk_level: RiskLevel,
        reason: str,
        warnings: list[str],
        forbidden: list[str],
    ) -> GateResult:
        result = GateResult(
            decision=GateDecision.BLOCK,
            risk_level=risk_level,
            allowed=False,
            block_reason=reason,
            warnings=warnings,
            forbidden_patterns_found=forbidden,
        )
        # Fire and forget — registrar el intento bloqueado
        asyncio.create_task(self._audit(intent, result))
        asyncio.create_task(self._alert_sentinel(intent, reason))
        return result

    async def _audit(self, intent: ModificationIntent, result: GateResult) -> None:
        """Registra la evaluación en el Audit Log y Redis."""
        entry = {
            "ts": intent.timestamp,
            "agent": intent.agent,
            "action": intent.action,
            "target": intent.target,
            "decision": result.decision.value,
            "risk": result.risk_level.value,
            "reason": result.block_reason or "allowed",
            "task_id": intent.task_id,
            "warnings": result.warnings,
            "forbidden_count": len(result.forbidden_patterns_found),
        }

        entry_json = json.dumps(entry)
        entry_hash = hashlib.sha256(entry_json.encode()).hexdigest()[:16]

        # Escribir en Redis (lista LIFO, max 10000 entries)
        try:
            pipe = self.redis.pipeline()
            pipe.lpush("kernell:aegis:audit", entry_json)
            pipe.ltrim("kernell:aegis:audit", 0, 9999)
            pipe.set("kernell:aegis:last_decision", entry_json, ex=3600)
            pipe.execute()
        except Exception as e:
            pass  # Audit log en Redis falló — no bloquear la operación por esto

        # Escribir en el Immutable Audit Log si está disponible
        if self.audit_log:
            try:
                await self.audit_log.append(
                    agent=intent.agent,
                    action=f"aegis:{intent.action}",
                    target=intent.target,
                    decision=result.decision.value,
                    metadata=entry,
                )
            except Exception:
                pass

    async def _alert_sentinel(self, intent: ModificationIntent, reason: str) -> None:
        """Alerta a Sentinel de un intento bloqueado."""
        try:
            alert = {
                "ts": time.time(),
                "source": "aegis_gate",
                "severity": "HIGH",
                "agent": intent.agent,
                "action": intent.action,
                "target": intent.target,
                "block_reason": reason,
            }
            self.redis.lpush("kernell:sentinel:alerts", json.dumps(alert))
            self.redis.ltrim("kernell:sentinel:alerts", 0, 999)
        except Exception:
            pass

    async def _notify_atlas(self, intent: ModificationIntent, reason: str) -> None:
        """Notifica a Atlas de una modificación en nivel REVIEW."""
        try:
            notification = {
                "ts": time.time(),
                "source": "aegis_gate",
                "type": "review_required",
                "agent": intent.agent,
                "action": intent.action,
                "target": intent.target,
                "reason": reason,
                "task_id": intent.task_id,
            }
            self.redis.lpush("kernell:tasks:atlas", json.dumps(notification))
        except Exception:
            pass

    async def _escalate_to_architect(self, intent: ModificationIntent, reason: str) -> None:
        """Escala una operación bloqueada al Arquitecto via Telegram."""
        try:
            msg = {
                "ts": time.time(),
                "source": "aegis_gate",
                "type": "mfa_required",
                "agent": intent.agent,
                "action": intent.action,
                "target": intent.target,
                "reason": reason,
                "message": (
                    f"🔐 *PALANTIR GATE — MFA Requerido*\n\n"
                    f"Agente: `{intent.agent}`\n"
                    f"Acción: `{intent.action}`\n"
                    f"Target: `{intent.target}`\n"
                    f"Razón: {reason}\n\n"
                    f"Justificación del agente:\n_{intent.reason}_\n\n"
                    f"Para aprobar: envía el token TOTP via canal de control."
                ),
            }
            self.redis.lpush("kernell:herald:outbox", json.dumps(msg))
        except Exception:
            pass

    async def _verify_mfa_token(self, token: str) -> bool:
        """Verifica un token TOTP del Arquitecto contra el sistema MFA."""
        try:
            # Publicar en el canal de verificación MFA y esperar respuesta
            request_id = hashlib.sha256(f"{token}{time.time()}".encode()).hexdigest()[:8]
            self.redis.setex(f"kernell:mfa:verify:{request_id}", 30, token)

            # Polling por resultado (max 5s)
            for _ in range(10):
                result = self.redis.get(f"kernell:mfa:result:{request_id}")
                if result:
                    return result.decode() == "ok"
                await asyncio.sleep(0.5)

            return False
        except Exception:
            return False

    async def _llm_compliance_check(
        self, intent: ModificationIntent
    ) -> tuple[bool, list[str]]:
        """
        Validación secundaria vía LLM.

        Usa un modelo liviano para verificar que la acción propuesta por Forge
        no viola las reglas de la normativa. Esto agrega una segunda capa de
        verificación que no depende de regex — puede razonar sobre la intención.

        Returns: (compliant: bool, issues: list[str])
        """
        issues = []

        # Cargar la normativa resumida desde Redis
        try:
            normativa_summary = self.redis.get("kernell:normativa:summary")
            if not normativa_summary:
                # Sin normativa en Redis, solo hacer checks básicos
                return True, []
            normativa_text = normativa_summary.decode()
        except Exception:
            return True, []

        # Construir el prompt de compliance check
        check_prompt = f"""Eres el Compliance Checker del sistema Kernell OS.
Tu única función es verificar si la siguiente acción viola alguna regla de la normativa.

=== NORMATIVA (resumen ejecutivo) ===
{normativa_text}

=== ACCIÓN PROPUESTA ===
Agente: {intent.agent}
Acción: {intent.action}
Target: {intent.target}
Razón declarada: {intent.reason}
Contenido (primeras 500 chars): {(intent.content or '')[:500]}

=== TU TAREA ===
Responde SOLO con un JSON válido con esta estructura exacta:
{{
  "compliant": true/false,
  "issues": ["[WARN] descripción", "[BLOCK] descripción crítica"],
  "summary": "evaluación en una oración"
}}

Prefija cada issue con [WARN] si es advertencia, [BLOCK] si debe bloquear la operación.
Si no hay issues, "issues" debe ser una lista vacía y "compliant" debe ser true.
"""

        try:
            import anthropic
            client = anthropic.Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))

            response = client.messages.create(
                model="claude-haiku-4-5-20251001",  # Modelo liviano para validación rápida
                max_tokens=400,
                system="Eres un compliance checker estricto. Responde solo con JSON válido.",
                messages=[{"role": "user", "content": check_prompt}],
            )

            text = response.content[0].text.strip()
            # Limpiar posibles fences
            text = re.sub(r"```(?:json)?", "", text).strip()

            parsed = json.loads(text)
            compliant = parsed.get("compliant", True)
            issues = parsed.get("issues", [])

            return compliant or not any(i.startswith("[BLOCK]") for i in issues), issues

        except Exception as e:
            # Si el compliance check LLM falla, no bloquear — solo loggear
            return True, [f"[WARN] Compliance check LLM falló: {str(e)[:80]}"]


# ─── Decorator para uso en agentes ────────────────────────────────────────────

def requires_aegis(gate_attr: str = "gate"):
    """
    Decorator que obliga a un método de agente a pasar por el Aegis Gate.

    Uso:
        class ForgeAgent:
            def __init__(self):
                self.gate = AegisGate(redis_client)

            @requires_aegis("gate")
            async def write_file(self, path: str, content: str, reason: str):
                # Este código solo se ejecuta si el gate lo permite
                Path(path).write_text(content)
    """
    def decorator(func):
        import functools

        @functools.wraps(func)
        async def wrapper(self, *args, **kwargs):
            # Extraer el gate del objeto
            gate: AegisGate = getattr(self, gate_attr, None)
            if gate is None:
                raise RuntimeError(f"AegisGate no inicializado en {self.__class__.__name__}.{gate_attr}")

            # Construir la intención desde los argumentos
            agent_name = getattr(self, "name", self.__class__.__name__.lower())
            target = args[0] if args else kwargs.get("path", kwargs.get("target", "unknown"))
            content = args[1] if len(args) > 1 else kwargs.get("content")
            reason = kwargs.get("reason", f"Llamada a {func.__name__}")

            intent = ModificationIntent(
                agent=agent_name,
                action=func.__name__,
                target=str(target),
                content=content,
                reason=reason,
                mfa_token=kwargs.get("mfa_token"),
                task_id=kwargs.get("task_id"),
            )

            result = await gate.evaluate(intent)

            if not result.allowed:
                raise PermissionError(
                    f"Aegis Gate bloqueó {func.__name__}: {result.block_reason}\n"
                    f"Risk: {result.risk_level.value} | Decision: {result.decision.value}"
                )

            if result.warnings:
                import logging
                logger = logging.getLogger("aegis")
                for w in result.warnings:
                    logger.warning(f"[{agent_name}] {w}")

            return await func(self, *args, **kwargs)

        return wrapper
    return decorator


# ─── Standalone: cargar la normativa en Redis ─────────────────────────────────

def load_normativa_into_redis(redis_client: redis.Redis, normativa_path: str) -> bool:
    """
    Carga el resumen ejecutivo de la normativa en Redis para que el
    compliance LLM pueda consultarlo sin leer el archivo completo.

    Ejecutar una vez al boot o cuando se actualice la normativa:
        python3 -c "from core.aegis_gate import load_normativa_into_redis; ..."
    """
    NORMATIVA_SUMMARY = """
PRINCIPIOS FUNDAMENTALES (violación = BLOCK inmediato):
P-01: Git es la única verdad. No existen cambios válidos fuera del repo.
P-02: Ningún cambio manual en producción sin pasar por GitOps.
P-03: Fallar en silencio está prohibido. Todo error va al Audit Log.
P-04: Ninguna operación financiera sin idempotency key.
P-05: El health score nunca puede ser hardcodeado.
P-06: Toda operación multi-agente usa Saga Pattern con compensación.
P-07: El sistema degrada con gracia — nunca todo-o-nada.

ARCHIVOS PROTEGIDOS (BLOCK — requieren MFA del Arquitecto):
- core/constitution.yaml
- scripts/mfa_gate.py
- scripts/boot_sequence.py
- core/aegis_gate.py
- core/normativa.*
- .env y variantes

CÓDIGO PROHIBIDO (BLOCK — Forge no puede escribir esto):
- eval() o exec() con input no validado
- subprocess con shell=True
- bare except:
- API keys hardcodeadas
- passwords o secrets en texto plano
- time.sleep() en código async
- requests sin timeout explícito

ACCIONES QUE REQUIEREN MFA:
- Modificar constitution.yaml
- Modificar mfa_gate.py o boot_sequence.py
- Chaos experiments con blast_radius=high
- Operaciones financieras >20% capital
- Reset de circuit breakers de Kernell o Atlas

PROCESO DE DEPLOY OBLIGATORIO:
1. Tests pasan (pytest con exit 0)
2. pre-commit hook pasa
3. Atlas aprueba (para código de agentes)
4. Canary deploy en 1 agente → 10 min de observación
5. Si GSHI estable → blue-green al resto
6. Audit Log registra todo

REGLA CRÍTICA: Fixer no puede reiniciar sin diagnóstico previo.
REGLA CRÍTICA: Forge no puede hacer deploy en modo SAFE o EMERGENCY.
"""

    try:
        redis_client.set(
            "kernell:normativa:summary",
            NORMATIVA_SUMMARY.strip(),
            ex=86400 * 30,  # 30 días
        )
        redis_client.set(
            "kernell:aegis:version",
            "1.0",
        )
        return True
    except Exception as e:
        print(f"Error cargando normativa en Redis: {e}")
        return False


# ─── CLI: testing standalone ──────────────────────────────────────────────────

if __name__ == "__main__":
    import sys

    # Test básico sin Redis real
    print("═══ PALANTIR GATE — Test de Clasificación ═══\n")

    test_paths = [
        "core/constitution.yaml",
        "scripts/boot_sequence.py",
        "agents/forge/core.py",
        "core/manifest.yaml",
        "infra/systemd/kernell-os-swarm@atlas.service",
        "agents/sentinel/config.yaml",
        "core/aegis_gate.py",
        ".env",
        "docs/README.md",
    ]

    gate = AegisGate.__new__(AegisGate)
    gate.repo_root = Path("/home/anny/kernell-os")

    for path in test_paths:
        risk, reason = gate._classify_path_risk(path)
        icon = {"auto": "✅", "review": "⚠️ ", "block": "🔴"}.get(risk.value, "❓")
        print(f"{icon} [{risk.value.upper():6}] {path}")
        print(f"          → {reason}\n")

    print("\n═══ Test de Patrones Prohibidos ═══\n")
    bad_code = """
import os

API_KEY = os.getenv("FAKE_API_KEY", "sk-proj-abc123xyz")
password = os.getenv("FAKE_PASSWORD", "supersecret123")

def risky():
    data = eval(user_input)
    exec(some_code)
    result = subprocess.run(cmd, shell=True)
    try:
        something()
    except Exception:
        pass
"""
    found = gate._scan_forbidden_patterns(bad_code)
    for f in found:
        print(f"  ❌ {f}")

    print(f"\n  Total encontrados: {len(found)} patrones prohibidos")
