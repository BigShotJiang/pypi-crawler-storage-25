"""

MODIFICATION_GUIDE = {
    "file":    "core/state/queue_enforcer.py",
    "version": "1.0",
    "purpose": (
        "Daemon que limita el tamaño de todas las listas de Redis. "
        "Corre cada 60s vía kernell-queue-enforcer.timer. "
        "Previene OOM y el DEFCON 1 causado por queue overflow."
    ),
    "extension_points": [
        "QUEUE_SCHEMA: añadir nuevas colas cuando se crea un agente nuevo.",
        "  Formato: 'kernell:tasks:{nuevo_agente}': {'max_len': 30, 'owner': 'nuevo_agente'}",
        "  Regla: task queues = 30-50 items. Logs/history = 100-500. HNP = 999.",
        "LLM_PROVIDERS: añadir el provider cuando se registre uno nuevo en llm_registry.py.",
        "enforce_loop(interval_s): ajustar intervalo si la carga cambia.",
    ],
    "invariants": [
        "NUNCA reducir max_len de una cola existente sin vaciarla primero.",
        "  Reducir ltrim a menos de lo actual borra datos históricos en producción.",
        "NUNCA eliminar kernell:events:security del schema — es la cola que causó el incidente.",
        "NUNCA cambiar la dirección del trim: siempre LTRIM 0..max_len-1 (keep newest).",
    ],
    "verify_after": [
        ".venv/bin/python3 core/state/queue_enforcer.py --check  # ver violaciones actuales",
        "systemctl status kernell-queue-enforcer.timer            # confirmar timer activo",
        "redis-cli -p 6380 -a $REDIS_PASSWORD LLEN kernell:events:security  # debe ser <= 99",
    ],
    "owner_agent": "overseer (monitorea via kernell:queue_enforcer:last_report)",
    "ontology_refs": {
        "redis_keys": ["kernell:queue_enforcer:last_report"],
        "related_modules": ["core/state/redis_schema.py (futuro)"],
        "systemd": "kernell-queue-enforcer.timer",
    },
}
core/state/queue_enforcer.py
============================
Queue Overflow Universal — garantiza que NINGUNA lista de Redis crezca
sin límite. Corre como daemon cada 60s vía systemd timer.

El bug de hoy: solo kernell:events:security tenía LTRIM.
Este módulo aplica límites a ~20 colas críticas del sistema.

Uso standalone:
  cd /home/anny/kernell-os
  .venv/bin/python3 core/state/queue_enforcer.py

Uso como módulo:
  from core.state.queue_enforcer import QueueEnforcer
  enforcer = QueueEnforcer(redis_client)
  report = enforcer.enforce_once()
"""

import os
import json
import time
import logging
import redis as redis_lib
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger("kernell.queue_enforcer")

# ── Schema canónico de colas ──────────────────────────────────────────────────
# Formato: "key_pattern": max_len
# Patrones con {agent} se expanden para todos los agentes canónicos.
# TTL en segundos (None = sin TTL automático)

QUEUE_SCHEMA: dict[str, dict] = {
    # ── Seguridad ─────────────────────────────────────────────────────────────
    "kernell:events:security":           {"max_len": 99,  "ttl": None,  "owner": "sentinel"},
    "kernell:alerts:security":           {"max_len": 99,  "ttl": None,  "owner": "sentinel"},

    # ── Errores y logs ────────────────────────────────────────────────────────
    "kernell:errors":                    {"max_len": 100, "ttl": None,  "owner": "fixer"},
    "kernell:boot:log":                  {"max_len": 200, "ttl": None,  "owner": "boot"},
    "kernell:boot:errors":               {"max_len": 100, "ttl": None,  "owner": "boot"},
    "kernell:salus:analysis_log":        {"max_len": 500, "ttl": None,  "owner": "sierra"},
    "kernell:salus:cycle_history":       {"max_len": 50,  "ttl": None,  "owner": "sierra"},
    "kernell:swarm:ledger_list":         {"max_len": 200, "ttl": None,  "owner": "overseer"},
    "kernell:architect:conversation_log":{"max_len": 100, "ttl": None,  "owner": "interface"},

    # ── HNP ───────────────────────────────────────────────────────────────────
    "kernell:hnp:quarantine:log":        {"max_len": 999, "ttl": None,  "owner": "hnp"},
    "kernell:hnp:drift:log":             {"max_len": 499, "ttl": None,  "owner": "hnp"},
    "kernell:hnp:sessions:log":          {"max_len": 199, "ttl": None,  "owner": "hnp"},

    # ── DEFCON ────────────────────────────────────────────────────────────────
    "kernell:defcon:history":            {"max_len": 200, "ttl": None,  "owner": "sentinel"},

    # ── Forge/SALUS ───────────────────────────────────────────────────────────
    "kernell:forge:ledger":              {"max_len": 100, "ttl": None,  "owner": "forge"},
    "kernell:pfe:verdict_history":       {"max_len": 99,  "ttl": None,  "owner": "forge"},
    "kernell:pfe:l0_violations":         {"max_len": 50,  "ttl": None,  "owner": "forge"},
    "kernell:salus:findings_log":        {"max_len": 500, "ttl": None,  "owner": "sierra"},

    # ── Síntesis y memoria ────────────────────────────────────────────────────
    "kernell:synthesis:history":         {"max_len": 99,  "ttl": None,  "owner": "synthesis"},
    "kernell:memory:broker:audit_log":   {"max_len": 999, "ttl": None,  "owner": "broker"},
    "kernell:gshi:v2:history":           {"max_len": 100, "ttl": None,  "owner": "sierra"},
    "kernell:resilience:sri_history":    {"max_len": 49,  "ttl": None,  "owner": "atlas"},
    "kernell:chaos:history":             {"max_len": 49,  "ttl": None,  "owner": "atlas"},

    # ── Sage ──────────────────────────────────────────────────────────────────
    "kernell:sage:signals":              {"max_len": 50,  "ttl": None,  "owner": "sage"},
    "kernell:sage:hypotheses":           {"max_len": 50,  "ttl": None,  "owner": "sage"},
    "kernell:sage:research":             {"max_len": 50,  "ttl": None,  "owner": "sage"},
    "kernell:sage:proposals":            {"max_len": 50,  "ttl": None,  "owner": "sage"},

    # ── Task queues (por agente) ──────────────────────────────────────────────
    # Límite conservador: 50 tareas pendientes por agente es mucho
    "kernell:tasks:fixer":               {"max_len": 50,  "ttl": None,  "owner": "fixer"},
    "kernell:tasks:forge":               {"max_len": 50,  "ttl": None,  "owner": "forge"},
    "kernell:tasks:sentinel":            {"max_len": 50,  "ttl": None,  "owner": "sentinel"},
    "kernell:tasks:atlas":               {"max_len": 50,  "ttl": None,  "owner": "atlas"},
    "kernell:tasks:chronos":             {"max_len": 50,  "ttl": None,  "owner": "chronos"},
    "kernell:tasks:sierra":              {"max_len": 50,  "ttl": None,  "owner": "sierra"},
    "kernell:tasks:economy":             {"max_len": 30,  "ttl": None,  "owner": "economy"},
    "kernell:tasks:hunter":              {"max_len": 30,  "ttl": None,  "owner": "hunter"},
    "kernell:tasks:herald":              {"max_len": 30,  "ttl": None,  "owner": "herald"},
    "kernell:tasks:scribe":              {"max_len": 30,  "ttl": None,  "owner": "scribe"},
    "kernell:tasks:nexus":               {"max_len": 30,  "ttl": None,  "owner": "nexus"},
    "kernell:tasks:overseer":            {"max_len": 30,  "ttl": None,  "owner": "overseer"},
    "kernell:tasks:telegram_bridge":     {"max_len": 30,  "ttl": None,  "owner": "telegram_bridge"},
    "kernell:tasks:bounty":              {"max_len": 20,  "ttl": None,  "owner": "bounty"},
    "kernell:tasks:operator":            {"max_len": 20,  "ttl": None,  "owner": "operator"},
    "kernell:tasks:observer":            {"max_len": 20,  "ttl": None,  "owner": "observer"},

    # ── Dead letter queues (capped + TTL to prevent backlog inflation) ────
    "kernell:tasks:telegram_bridge:dead_letter": {"max_len": 500, "ttl": 21600, "owner": "telegram_bridge"},
    "kernell:tasks:nexus:dead_letter":           {"max_len": 500, "ttl": 21600, "owner": "nexus"},
    "kernell:tasks:atlas:dead_letter":           {"max_len": 200, "ttl": 21600, "owner": "atlas"},
    "kernell:tasks:sierra:dead_letter":          {"max_len": 100, "ttl": 21600, "owner": "sierra"},
    "kernell:tasks:sentinel:dead_letter":        {"max_len": 100, "ttl": 21600, "owner": "sentinel"},
    "kernell:tasks:fixer:dead_letter":           {"max_len": 100, "ttl": 21600, "owner": "fixer"},
    "kernell:tasks:overseer:dead_letter":        {"max_len": 100, "ttl": 21600, "owner": "overseer"},
    "kernell:tasks:scribe:dead_letter":          {"max_len": 100, "ttl": 21600, "owner": "scribe"},
    "kernell:tasks:hunter:dead_letter":          {"max_len": 100, "ttl": 21600, "owner": "hunter"},
    "kernell:tasks:archivista:dead_letter":      {"max_len": 100, "ttl": 21600, "owner": "archivista"},

    # ── Fixer/conocimiento ────────────────────────────────────────────────────
    "kernell:fixer:cognitive_audits":    {"max_len": 50,  "ttl": None,  "owner": "fixer"},
    "memory:fixer:history":              {"max_len": 100, "ttl": None,  "owner": "fixer"},

    # ── LLM metrics ──────────────────────────────────────────────────────────
    # Por provider — 200 entries por provider
}

# Providers para los que hay métricas de LLM
LLM_PROVIDERS = [
    "groq_r1", "groq_qwen3", "gemini_flash", "gemini_pro",
    "openrouter_r1", "openrouter_r1_0528", "claude_sonnet", "claude_opus",
]

for _p in LLM_PROVIDERS:
    QUEUE_SCHEMA[f"kernell:llm:metrics:{_p}"]  = {"max_len": 199, "ttl": None, "owner": "llm_registry"}
    QUEUE_SCHEMA[f"kernell:llm:semantic:{_p}:log"] = {"max_len": 199, "ttl": None, "owner": "hnp"}


@dataclass
class EnforcerReport:
    timestamp: float = field(default_factory=time.time)
    keys_checked: int = 0
    keys_trimmed: int = 0
    total_items_removed: int = 0
    trimmed: list = field(default_factory=list)   # [(key, before, after)]
    errors: list  = field(default_factory=list)


class QueueEnforcer:
    """
    Enforces max_len limits on all Redis lists in QUEUE_SCHEMA.
    Trims from the TAIL (removes oldest items, keeps newest).
    """

    def __init__(self, redis_client: Optional[redis_lib.Redis] = None):
        self.redis = redis_client or self._connect()

    def _connect(self) -> redis_lib.Redis:
        pw = os.environ.get("REDIS_PASSWORD", "").strip().strip("\"'")
        return redis_lib.Redis(
            host=os.getenv("REDIS_HOST", "127.0.0.1"),
            port=int(os.getenv("REDIS_PORT", 6380)),
            password=pw if pw else None,
            decode_responses=True,
            socket_connect_timeout=5,
        )

    def enforce_once(self) -> EnforcerReport:
        """Run one enforcement pass over all keys in QUEUE_SCHEMA."""
        report = EnforcerReport()

        for key, spec in QUEUE_SCHEMA.items():
            if not spec.get("max_len"):
                continue
            max_len = spec["max_len"]

            try:
                # Only process lists
                key_type = self.redis.type(key)
                if key_type == "none":
                    continue  # key doesn't exist, nothing to do
                if key_type != "list":
                    continue  # not a list, skip

                current_len = self.redis.llen(key)
                report.keys_checked += 1

                if current_len > max_len:
                    # LTRIM keeps indices 0..max_len-1 (newest items)
                    self.redis.ltrim(key, 0, max_len - 1)
                    new_len = self.redis.llen(key)
                    removed = current_len - new_len
                    report.keys_trimmed += 1
                    report.total_items_removed += removed
                    report.trimmed.append((key, current_len, new_len))
                    logger.info(
                        f"QueueEnforcer: trimmed {key} "
                        f"{current_len} → {new_len} (-{removed})"
                    )

                # Apply TTL if specified in schema and key has no expiration
                ttl_spec = spec.get("ttl")
                if ttl_spec and self.redis.ttl(key) == -1:
                    self.redis.expire(key, ttl_spec)

            except Exception as e:
                report.errors.append((key, str(e)))
                logger.error(f"QueueEnforcer: error processing {key}: {e}")

        # Persist report to Redis for dashboard visibility
        try:
            self.redis.set(
                "kernell:queue_enforcer:last_report",
                json.dumps({
                    "timestamp":         report.timestamp,
                    "keys_checked":      report.keys_checked,
                    "keys_trimmed":      report.keys_trimmed,
                    "items_removed":     report.total_items_removed,
                    "trimmed_keys":      [t[0] for t in report.trimmed],
                    "errors":            len(report.errors),
                }),
                ex=300,
            )
        except Exception:
            pass

        if report.keys_trimmed > 0:
            logger.warning(
                f"QueueEnforcer: trimmed {report.keys_trimmed} queues, "
                f"removed {report.total_items_removed} items"
            )
        else:
            logger.debug(
                f"QueueEnforcer: {report.keys_checked} queues checked, all within limits"
            )

        return report

    def enforce_loop(self, interval_s: int = 60):
        """Run enforcement in a loop (for standalone daemon mode)."""
        logger.info(f"QueueEnforcer daemon started — interval={interval_s}s")
        while True:
            try:
                self.enforce_once()
            except Exception as e:
                logger.error(f"QueueEnforcer loop error: {e}")
            time.sleep(interval_s)

    def get_schema_violations(self) -> list[dict]:
        """Returns all queues currently over their limit (read-only, no trim)."""
        violations = []
        for key, spec in QUEUE_SCHEMA.items():
            if not spec.get("max_len"):
                continue
            try:
                if self.redis.type(key) != "list":
                    continue
                current = self.redis.llen(key)
                if current > spec["max_len"]:
                    violations.append({
                        "key":     key,
                        "current": current,
                        "max":     spec["max_len"],
                        "owner":   spec.get("owner", "?"),
                        "excess":  current - spec["max_len"],
                    })
            except Exception:
                pass
        return sorted(violations, key=lambda x: -x["excess"])


# ── Standalone entry point ────────────────────────────────────────────────────
if __name__ == "__main__":
    import sys

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s"
    )

    # Load .env
    from pathlib import Path
    env_file = Path("/home/anny/kernell-os/.env")
    if env_file.exists():
        for line in env_file.read_text().splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, _, v = line.partition("=")
                os.environ.setdefault(k.strip(), v.strip().strip("\"'"))

    enforcer = QueueEnforcer()

    if "--check" in sys.argv:
        # Read-only: show violations
        violations = enforcer.get_schema_violations()
        if violations:
            print(f"\n{len(violations)} queue violations:")
            for v in violations:
                print(f"  {v['key']:<45} {v['current']:>6}/{v['max']:<6} owner={v['owner']}")
        else:
            print("No queue violations.")
        sys.exit(0)

    if "--daemon" in sys.argv:
        interval = int(sys.argv[sys.argv.index("--daemon") + 1]) if len(sys.argv) > sys.argv.index("--daemon") + 1 else 60
        enforcer.enforce_loop(interval_s=interval)
    else:
        # Single run
        report = enforcer.enforce_once()
        print(f"Checked: {report.keys_checked} | Trimmed: {report.keys_trimmed} | Removed: {report.total_items_removed} items")
        if report.trimmed:
            for key, before, after in report.trimmed:
                print(f"  {key}: {before} → {after}")
        if report.errors:
            print(f"Errors: {report.errors}")
