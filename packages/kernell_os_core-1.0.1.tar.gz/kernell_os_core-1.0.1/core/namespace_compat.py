"""
Canonical object-type names and legacy aliases (Phase 3 migration).

New code should use KernellOSNode. AntigravityNode remains accepted everywhere
as a legacy alias with identical semantics.
"""

from __future__ import annotations

from typing import FrozenSet

# Legacy name -> canonical name
OBJECT_TYPE_ALIASES: dict[str, str] = {
    "AntigravityNode": "KernellOSNode",
}

# Types that share Qdrant payloads across legacy + canonical names
NODE_OBJECT_TYPES: FrozenSet[str] = frozenset({"AntigravityNode", "KernellOSNode"})


def canonical_object_type(name: str) -> str:
    """Return canonical type name for new writes / documentation."""
    return OBJECT_TYPE_ALIASES.get(name, name)


def object_type_variants(name: str) -> tuple[str, ...]:
    """All object_type payload values that must be treated as the same logical type."""
    c = canonical_object_type(name)
    legacy = [k for k, v in OBJECT_TYPE_ALIASES.items() if v == c]
    return tuple(dict.fromkeys([name, c, *legacy]))
