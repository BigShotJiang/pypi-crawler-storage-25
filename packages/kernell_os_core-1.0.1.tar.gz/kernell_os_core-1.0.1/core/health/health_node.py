"""
KERNELL OS — Health Node
==========================
Estructuras base del sistema de reportes jerárquicos de salud.

Cada nodo del árbol produce exactamente UN reporte con:
  - status:  GREEN / YELLOW / RED / GREY
  - score:   0.0 – 1.0
  - summary: 1 línea legible
  - detail:  solo si está degradado

Reglas de propagación:
  - 1+ hijo RED   → padre mínimo YELLOW (inmediato)
  - 2+ hijos RED  → padre RED (inmediato)
  - 1+ hijo GREY  → padre YELLOW (espera 2 ciclos antes de escalar)
  - todos GREEN   → padre GREEN
  - score padre   = promedio ponderado de scores hijos
"""

import time
import json
import hashlib
from enum import Enum
from typing import Any, Dict, List, Optional


class HealthStatus(str, Enum):
    GREEN  = "green"   # 0.80 – 1.00  — nominal
    YELLOW = "yellow"  # 0.50 – 0.79  — degradado, monitoreando
    RED    = "red"     # 0.00 – 0.49  — crítico, acción requerida
    GREY   = "grey"    # desconocido  — sin heartbeat


# Thresholds de score → status
SCORE_THRESHOLDS = {
    HealthStatus.GREEN:  0.80,
    HealthStatus.YELLOW: 0.50,
    HealthStatus.RED:    0.00,
}

# Íconos por status
STATUS_ICONS = {
    HealthStatus.GREEN:  "🟢",
    HealthStatus.YELLOW: "🟡",
    HealthStatus.RED:    "🔴",
    HealthStatus.GREY:   "⚫",
}

# Niveles del árbol
LEVEL_NAMES = {
    0: "ROOT",
    1: "DOMAIN",
    2: "AGENT",
}


def score_to_status(score: float) -> HealthStatus:
    if score < 0:
        return HealthStatus.GREY
    if score >= SCORE_THRESHOLDS[HealthStatus.GREEN]:
        return HealthStatus.GREEN
    if score >= SCORE_THRESHOLDS[HealthStatus.YELLOW]:
        return HealthStatus.YELLOW
    return HealthStatus.RED


class HealthMetrics:
    """Métricas estándar que todo agente puede reportar."""

    def __init__(
        self,
        heartbeat_age_s:  float = 0,    # segundos desde último heartbeat
        errors_1h:        int   = 0,    # errores en última hora
        tasks_pending:    int   = 0,    # tareas en cola sin procesar
        tasks_done_1h:    int   = 0,    # tareas completadas en 1h
        memory_ok:        bool  = True, # Qdrant / Redis accesibles
        last_action:      str   = "",   # última acción ejecutada
        custom:           Optional[Dict] = None,
    ):
        self.heartbeat_age_s = heartbeat_age_s
        self.errors_1h       = errors_1h
        self.tasks_pending   = tasks_pending
        self.tasks_done_1h   = tasks_done_1h
        self.memory_ok       = memory_ok
        self.last_action     = last_action
        self.custom          = custom or {}

    def compute_score(self) -> float:
        """
        Calcula score 0.0-1.0 basado en las métricas.
        Cada factor puede degradar el score.
        """
        score = 1.0

        # Heartbeat age — crítico si > 120s
        if self.heartbeat_age_s < 0:
            return -1.0  # GREY
        if self.heartbeat_age_s > 300:
            return 0.0   # RED — sin heartbeat por 5+ min
        if self.heartbeat_age_s > 120:
            score -= 0.40
        elif self.heartbeat_age_s > 60:
            score -= 0.15

        # Errores recientes
        if self.errors_1h >= 10:
            score -= 0.40
        elif self.errors_1h >= 5:
            score -= 0.20
        elif self.errors_1h >= 2:
            score -= 0.10

        # Cola acumulada
        if self.tasks_pending >= 50:
            score -= 0.30
        elif self.tasks_pending >= 20:
            score -= 0.15
        elif self.tasks_pending >= 10:
            score -= 0.05

        # Memoria inaccesible
        if not self.memory_ok:
            score -= 0.20

        return round(max(score, 0.0), 4)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "heartbeat_age_s": self.heartbeat_age_s,
            "errors_1h":       self.errors_1h,
            "tasks_pending":   self.tasks_pending,
            "tasks_done_1h":   self.tasks_done_1h,
            "memory_ok":       self.memory_ok,
            "last_action":     self.last_action,
            **self.custom,
        }


class HealthReport:
    """
    Reporte de salud de UN nodo del árbol.
    Es la unidad fundamental del sistema.
    """

    def __init__(
        self,
        node_id:       str,
        level:         int,
        score:         float,
        status:        Optional[HealthStatus]  = None,
        summary:       str                     = "",
        detail:        Optional[str]           = None,
        metrics:       Optional[HealthMetrics] = None,
        children:      Optional[List["HealthReport"]] = None,
        bubbled_from:  Optional[str]           = None,  # hijo que triggereó propagación
        domain:        str                     = "",
    ):
        self.node_id      = node_id
        self.level        = level
        self.score        = score
        self.status       = status or score_to_status(score)
        self.summary      = summary
        self.detail       = detail
        self.metrics      = metrics
        self.children     = children or []
        self.bubbled_from = bubbled_from
        self.domain       = domain
        self.ts           = int(time.time())
        self.hash         = self._compute_hash()

    def _compute_hash(self) -> str:
        content = json.dumps({
            "node_id": self.node_id,
            "score":   self.score,
            "status":  self.status.value,
            "ts":      self.ts,
        }, sort_keys=True)
        return hashlib.sha256(content.encode()).hexdigest()[:16]

    @property
    def icon(self) -> str:
        return STATUS_ICONS.get(self.status, "⚫")

    @property
    def is_degraded(self) -> bool:
        return self.status in (HealthStatus.YELLOW, HealthStatus.RED, HealthStatus.GREY)

    @property
    def is_critical(self) -> bool:
        return self.status == HealthStatus.RED

    def one_line(self) -> str:
        """Representación de una línea para el reporte padre."""
        pct = f"{self.score*100:.0f}%"
        return f"{self.icon} {self.node_id:<20} {pct:>5}  {self.summary}"

    def to_dict(self, include_children: bool = True) -> Dict[str, Any]:
        d = {
            "node_id":      self.node_id,
            "level":        self.level,
            "level_name":   LEVEL_NAMES.get(self.level, "?"),
            "domain":       self.domain,
            "status":       self.status.value,
            "score":        self.score,
            "score_pct":    f"{self.score*100:.1f}%",
            "icon":         self.icon,
            "summary":      self.summary,
            "detail":       self.detail,
            "bubbled_from": self.bubbled_from,
            "ts":           self.ts,
            "hash":         self.hash,
        }
        if self.metrics:
            d["metrics"] = self.metrics.to_dict()
        if include_children and self.children:
            d["children"] = [
                c.to_dict(include_children=False)
                for c in self.children
            ]
        return d

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False, default=str)


class DomainReport(HealthReport):
    """
    Reporte de un dominio funcional (nivel 1).
    Se construye agregando los reportes de sus agentes hijos.
    """

    def __init__(self, domain_id: str, agent_reports: List[HealthReport]):
        # Calcular score del dominio
        score, bubbled_from = self._aggregate(agent_reports)
        red_children   = [r for r in agent_reports if r.is_critical]
        grey_children  = [r for r in agent_reports if r.status == HealthStatus.GREY]
        deg_children   = [r for r in agent_reports if r.is_degraded]

        summary = self._build_summary(
            agent_reports, red_children, grey_children, score
        )
        detail = self._build_detail(deg_children) if deg_children else None

        super().__init__(
            node_id      = domain_id,
            level        = 1,
            score        = score,
            summary      = summary,
            detail       = detail,
            children     = agent_reports,
            bubbled_from = bubbled_from,
            domain       = domain_id,
        )

    def _aggregate(
        self, reports: List[HealthReport]
    ) -> tuple:
        """
        Calcula score del dominio y detecta propagación inmediata.
        Retorna (score, bubbled_from).
        """
        if not reports:
            return 0.5, None

        red_count  = sum(1 for r in reports if r.is_critical)
        grey_count = sum(1 for r in reports if r.status == HealthStatus.GREY)

        # Score base = promedio ponderado
        # Agentes críticos pesan más hacia abajo
        weights = []
        scores  = []
        for r in reports:
            if r.status == HealthStatus.GREY:
                w = 1.0
                s = 0.3  # grey cuenta como 30%
            elif r.is_critical:
                w = 2.0  # doble peso para críticos
                s = r.score
            else:
                w = 1.0
                s = r.score
            weights.append(w)
            scores.append(s * w)

        total_weight = sum(weights)
        score = sum(scores) / total_weight if total_weight > 0 else 0.5

        # Propagación inmediata
        bubbled_from = None
        if red_count >= 2:
            # Forzar RED si 2+ hijos críticos
            score = min(score, 0.45)
            bubbled_from = ", ".join(
                r.node_id for r in reports if r.is_critical
            )
        elif red_count == 1:
            score = min(score, 0.75)  # Forzar YELLOW mínimo
            bubbled_from = next(
                r.node_id for r in reports if r.is_critical
            )

        return round(score, 4), bubbled_from

    def _build_summary(
        self,
        all_reports:   List[HealthReport],
        red_children:  List[HealthReport],
        grey_children: List[HealthReport],
        score:         float,
    ) -> str:
        total  = len(all_reports)
        green  = sum(1 for r in all_reports if r.status == HealthStatus.GREEN)

        if not red_children and not grey_children:
            return f"{green}/{total} agentes nominales"
        parts = []
        if red_children:
            names = ", ".join(r.node_id for r in red_children[:3])
            parts.append(f"🔴 {len(red_children)} críticos: {names}")
        if grey_children:
            names = ", ".join(r.node_id for r in grey_children[:2])
            parts.append(f"⚫ {len(grey_children)} sin HB: {names}")
        return " | ".join(parts)

    def _build_detail(
        self, degraded: List[HealthReport]
    ) -> str:
        lines = []
        for r in sorted(degraded, key=lambda x: x.score):
            lines.append(f"  {r.one_line()}")
            if r.detail:
                lines.append(f"    → {r.detail}")
        return "\n".join(lines)


class RootReport(HealthReport):
    """
    Reporte raíz de todo Kernell OS (nivel 0).
    Se construye agregando los reportes de los 5 dominios.
    """

    def __init__(self, domain_reports: List[DomainReport]):
        score, bubbled_from = self._aggregate(domain_reports)
        red_domains  = [d for d in domain_reports if d.is_critical]
        deg_domains  = [d for d in domain_reports if d.is_degraded]

        summary = self._build_summary(domain_reports, score)
        detail  = self._build_detail(deg_domains) if deg_domains else None

        super().__init__(
            node_id      = "KERNELL_OS",
            level        = 0,
            score        = score,
            summary      = summary,
            detail       = detail,
            children     = domain_reports,
            bubbled_from = bubbled_from,
        )

    def _aggregate(
        self, reports: List[DomainReport]
    ) -> tuple:
        if not reports:
            return 0.5, None

        red_count = sum(1 for r in reports if r.is_critical)
        scores    = [r.score for r in reports]
        score     = sum(scores) / len(scores)

        bubbled_from = None
        if red_count >= 2:
            score        = min(score, 0.45)
            bubbled_from = ", ".join(r.node_id for r in reports if r.is_critical)
        elif red_count == 1:
            score        = min(score, 0.75)
            bubbled_from = next(r.node_id for r in reports if r.is_critical)

        return round(score, 4), bubbled_from

    def _build_summary(
        self, reports: List[DomainReport], score: float
    ) -> str:
        green  = sum(1 for r in reports if r.status == HealthStatus.GREEN)
        total  = len(reports)
        pct    = f"{score*100:.0f}%"
        if green == total:
            return f"Sistema nominal al {pct} — {total}/{total} dominios saludables"
        red = [r for r in reports if r.is_critical]
        yel = [r for r in reports if r.status == HealthStatus.YELLOW]
        parts = [f"Sistema al {pct}"]
        if red:
            parts.append(
                f"🔴 CRÍTICO: {', '.join(r.node_id for r in red)}"
            )
        if yel:
            parts.append(
                f"🟡 Degradado: {', '.join(r.node_id for r in yel)}"
            )
        return " | ".join(parts)

    def _build_detail(
        self, degraded: List[DomainReport]
    ) -> str:
        lines = []
        for d in degraded:
            lines.append(f"\n  {d.icon} DOMINIO {d.node_id} ({d.score*100:.0f}%)")
            for child in d.children:
                if child.is_degraded:
                    lines.append(f"    {child.one_line()}")
        return "\n".join(lines)

    def render(self) -> str:
        """
        Renderiza el reporte raíz en formato legible para Telegram/logs.
        """
        ts_str = time.strftime("%H:%M:%S", time.localtime(self.ts))
        lines  = [
            f"{'═'*50}",
            f"  KERNELL OS — HEALTH REPORT  {ts_str}",
            f"{'═'*50}",
            f"  {self.icon} SISTEMA: {self.score*100:.1f}%  {self.summary}",
            f"{'─'*50}",
        ]
        for domain in self.children:
            lines.append(f"  {domain.icon} {domain.node_id:<20} {domain.score*100:.0f}%")
            for agent in domain.children:
                marker = "  └─" if agent == domain.children[-1] else "  ├─"
                lines.append(
                    f"  {marker} {agent.icon} {agent.node_id:<18} "
                    f"{agent.score*100:.0f}%  {agent.summary[:35]}"
                )
        if self.detail:
            lines.append(f"{'─'*50}")
            lines.append("  DETALLE DE PROBLEMAS:")
            lines.append(self.detail)
        lines.append(f"{'═'*50}")
        return "\n".join(lines)
