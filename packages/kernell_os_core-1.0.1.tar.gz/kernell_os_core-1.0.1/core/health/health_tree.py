"""
KERNELL OS — Health Tree
==========================
El árbol de 3 niveles de Kernell OS:

  Nivel 0 — ROOT:        KERNELL_OS
  Nivel 1 — DOMINIOS:    INGRESOS | INFRAESTRUCTURA | INTELIGENCIA
                         SEGURIDAD | COMUNICACION
  Nivel 2 — AGENTES:     24 hojas

Responsabilidades:
  - Declarar a qué dominio pertenece cada agente
  - Leer micro-reportes de cada agente desde Redis
  - Agregar dominio por dominio
  - Producir el reporte raíz
  - Detectar propagación inmediata (hijo rojo → burbujea)
  - Persistir en Redis (tiempo real) y Qdrant (historial)
"""

import json
import time
import asyncio
import logging
from typing import Any, Dict, List, Optional, Tuple

from core.health.health_node import (
    HealthReport, DomainReport, RootReport,
    HealthMetrics, HealthStatus, score_to_status,
    STATUS_ICONS,
)

logger = logging.getLogger("kernell.health.tree")

# ── Declaración del árbol ─────────────────────────────────────
TREE_DEFINITION = {
    "INGRESOS": {
        "description": "Flujos de generación de ingresos",
        "agents":      ["economy", "nemesis", "ads", "hunter", "prospector"],
        "weight":      1.5,   # peso mayor — afecta directamente ingresos
    },
    "INFRAESTRUCTURA": {
        "description": "Base operacional del swarm",
        "agents":      ["sierra", "fixer", "forge", "archivista", "operator", "chronos"],
        "weight":      2.0,   # peso máximo — si falla, todo falla
    },
    "INTELIGENCIA": {
        "description": "Cognición, memoria y evolución",
        "agents":      ["atlas", "sage", "observer", "vector", "overseer", "nexus"],
        "weight":      1.2,
    },
    "SEGURIDAD": {
        "description": "Protección e integridad",
        "agents":      ["sentinel", "bounty", "scribe"],
        "weight":      1.8,   # peso alto — amenazas son urgentes
    },
    "COMUNICACION": {
        "description": "Interfaces y canales externos",
        "agents":      ["herald", "telegram_bridge", "interface", "kernell"],
        "weight":      1.0,
    },
}

# ── Redis keys ────────────────────────────────────────────────
AGENT_REPORT_KEY   = "kernell:health:agent:{agent_id}"
DOMAIN_REPORT_KEY  = "kernell:health:domain:{domain_id}"
ROOT_REPORT_KEY    = "kernell:health:root"
BUBBLE_QUEUE_KEY   = "kernell:health:bubble_queue"   # propagación inmediata
HISTORY_KEY        = "kernell:health:history"         # list de raíces
METRICS_KEY        = "kernell:health:metrics"

HEARTBEAT_KEY_TPL  = "kernell:agent:{agent_id}:heartbeat"
QUEUE_KEY_TPL      = "kernell:tasks:{agent_id}"
ERRORS_KEY_TPL     = "kernell:salus:errors:{agent_id}"

# ── Agentes con pesos especiales dentro de su dominio ────────
AGENT_WEIGHTS = {
    "sierra":          3.0,   # si sierra cae, todo se degrada
    "economy":         2.5,   # autoridad financiera
    "atlas":           2.0,   # orquestador cognitivo
    "sentinel":        2.0,   # seguridad crítica
    "nemesis":         1.5,   # trading
    "kernell":         3.0,   # PID-1
    "observer":        1.5,   # GSHI
}

# Thresholds de heartbeat (segundos)
HB_GREEN_MAX  = 60
HB_YELLOW_MAX = 120
HB_RED_MAX    = 300   # > 300s = RED


class AgentHealthReader:
    """
    Lee el estado de salud de un agente individual desde Redis.
    Produce un HealthReport de nivel 2 (hoja del árbol).
    """

    def __init__(self, redis_client):
        self.redis = redis_client

    async def read(
        self,
        agent_id: str,
        domain:   str,
    ) -> HealthReport:
        """Lee heartbeat + métricas de un agente y produce su reporte."""
        now = time.time()
        try:
            # ── Leer heartbeat ─────────────────────────────────
            hb_key = HEARTBEAT_KEY_TPL.format(agent_id=agent_id)
            hb_raw = await self.redis.get(hb_key)

            if not hb_raw:
                # Sin heartbeat → GREY
                return HealthReport(
                    node_id = agent_id,
                    level   = 2,
                    score   = -1.0,
                    status  = HealthStatus.GREY,
                    summary = "sin heartbeat",
                    domain  = domain,
                )

            # Handle both plain timestamp and JSON heartbeat formats
            hb_str = hb_raw.decode() if isinstance(hb_raw, bytes) else str(hb_raw)
            hb = {}
            try:
                parsed = json.loads(hb_str)
                if isinstance(parsed, dict):
                    hb          = parsed
                    hb_ts       = hb.get("ts", 0)
                    hb_status   = hb.get("status", "unknown")
                    last_action = hb.get("last_action", hb.get("action", ""))
                else:
                    # json.loads returned a number (plain timestamp)
                    hb_ts       = float(parsed)
                    hb_status   = "active"
                    last_action = ""
            except (json.JSONDecodeError, TypeError, ValueError):
                # Plain timestamp format (current Kernell OS standard)
                try:
                    hb_ts = float(hb_str)
                except ValueError:
                    hb_ts = 0
                hb_status   = "active"
                last_action = ""
            hb_age_s = now - hb_ts

            # ── Leer cola de tareas pendientes ─────────────────
            q_key          = QUEUE_KEY_TPL.format(agent_id=agent_id)
            tasks_pending  = 0
            try:
                tasks_pending = await self.redis.llen(q_key)
            except Exception:
                pass

            # ── Leer errores recientes ──────────────────────────
            errors_1h = await self._count_errors(agent_id, window_s=3600)

            # ── Leer métricas específicas del agente ────────────
            custom = await self._read_agent_specific(agent_id, hb)

            # ── Construir métricas ──────────────────────────────
            metrics = HealthMetrics(
                heartbeat_age_s = hb_age_s,
                errors_1h       = errors_1h,
                tasks_pending   = tasks_pending,
                last_action     = last_action[:80] if last_action else "",
                memory_ok       = True,
                custom          = custom,
            )

            score   = metrics.compute_score()
            status  = score_to_status(score)
            summary = self._build_agent_summary(
                agent_id, status, hb_age_s, tasks_pending, errors_1h,
                last_action, hb_status
            )
            detail = self._build_agent_detail(
                agent_id, metrics, custom
            ) if status != HealthStatus.GREEN else None

            report = HealthReport(
                node_id = agent_id,
                level   = 2,
                score   = score,
                status  = status,
                summary = summary,
                detail  = detail,
                metrics = metrics,
                domain  = domain,
            )
            # Persistir micro-reporte
            await self._save_agent_report(agent_id, report)
            return report

        except Exception as e:
            logger.error(f"[HEALTH_TREE] Error leyendo {agent_id}: {e}")
            return HealthReport(
                node_id = agent_id,
                level   = 2,
                score   = 0.0,
                status  = HealthStatus.RED,
                summary = f"error de lectura: {str(e)[:50]}",
                domain  = domain,
            )

    async def _count_errors(self, agent_id: str, window_s: int) -> int:
        """Cuenta errores recientes del agente."""
        cutoff = time.time() - window_s
        count  = 0
        try:
            # Errores en el stream de auditoría
            errors = await self.redis.lrange("kernell:salus:errors", 0, 99)
            for e in errors:
                try:
                    data = json.loads(e)
                    if (data.get("agent_id") == agent_id and
                            data.get("ts", 0) > cutoff):
                        count += 1
                except Exception:
                    pass
        except Exception:
            pass
        return count

    async def _read_agent_specific(
        self, agent_id: str, hb: Dict
    ) -> Dict[str, Any]:
        """Lee métricas específicas de cada agente."""
        custom = {}
        def _decode(val):
            """Decode Redis bytes to str."""
            if val is None: return None
            return val.decode() if isinstance(val, bytes) else str(val)
        try:
            if agent_id == "nemesis":
                for k in ["kernell:nemesis:pnl", "kernell:trading:allowed"]:
                    v = _decode(await self.redis.get(k))
                    if v:
                        custom[k.split(":")[-1]] = v
            elif agent_id == "economy":
                ks = _decode(await self.redis.get("kernell:economy:kill_switch"))
                custom["kill_switch"] = ks or "false"
            elif agent_id == "observer":
                gshi_raw = _decode(await self.redis.get("kernell:observer:gshi"))
                if gshi_raw:
                    custom["gshi"] = float(gshi_raw)
            elif agent_id == "sierra":
                defcon = _decode(await self.redis.get("kernell:system:defcon"))
                if defcon:
                    custom["defcon"] = int(defcon)
            elif agent_id == "archivista":
                bkp = _decode(await self.redis.get("kernell:archivista:last_backup"))
                if bkp:
                    data = json.loads(bkp)
                    age_h = (time.time() - data.get("ts", 0)) / 3600
                    custom["last_backup_h"] = round(age_h, 1)
            elif agent_id == "sage":
                cycle = _decode(await self.redis.get("kernell:sage:cycle:current"))
                if cycle:
                    data = json.loads(cycle)
                    custom["cycle_status"] = data.get("status", "unknown")
        except Exception:
            pass
        return custom

    def _build_agent_summary(
        self,
        agent_id:     str,
        status:       HealthStatus,
        hb_age_s:     float,
        tasks_pending:int,
        errors_1h:    int,
        last_action:  str,
        hb_status:    str,
    ) -> str:
        if status == HealthStatus.GREEN:
            if last_action:
                return last_action[:50]
            return f"nominal — HB hace {hb_age_s:.0f}s"
        parts = []
        if hb_age_s > HB_YELLOW_MAX:
            parts.append(f"HB hace {hb_age_s:.0f}s")
        if errors_1h > 0:
            parts.append(f"{errors_1h} errores/h")
        if tasks_pending > 10:
            parts.append(f"{tasks_pending} tareas pendientes")
        return " | ".join(parts) if parts else f"degradado ({hb_status})"

    def _build_agent_detail(
        self,
        agent_id: str,
        metrics:  HealthMetrics,
        custom:   Dict,
    ) -> str:
        parts = []
        if metrics.heartbeat_age_s > HB_YELLOW_MAX:
            parts.append(
                f"Heartbeat: hace {metrics.heartbeat_age_s:.0f}s "
                f"(máx saludable: {HB_GREEN_MAX}s)"
            )
        if metrics.errors_1h > 0:
            parts.append(f"Errores última hora: {metrics.errors_1h}")
        if metrics.tasks_pending > 0:
            parts.append(f"Cola: {metrics.tasks_pending} tareas sin procesar")
        # Métricas específicas
        if "defcon" in custom and custom["defcon"] > 1:
            parts.append(f"DEFCON: {custom['defcon']} ⚠")
        if "kill_switch" in custom and custom["kill_switch"] == "true":
            parts.append("Kill switch ACTIVO 🔴")
        if "last_backup_h" in custom and custom["last_backup_h"] > 25:
            parts.append(f"Último backup hace {custom['last_backup_h']}h ⚠")
        return " | ".join(parts)

    async def _save_agent_report(
        self, agent_id: str, report: HealthReport
    ) -> None:
        key = AGENT_REPORT_KEY.format(agent_id=agent_id)
        try:
            await self.redis.set(key, report.to_json(), ex=600)
        except Exception:
            pass


class HealthTree:
    """
    Árbol completo de salud de Kernell OS.
    Construye el reporte raíz a partir de los 24 agentes.
    """

    def __init__(self, redis_client):
        self.redis  = redis_client
        self.reader = AgentHealthReader(redis_client)
        self._last_root: Optional[RootReport] = None

    # ─────────────────────────────────────────────
    # Build completo
    # ─────────────────────────────────────────────
    async def build(self) -> RootReport:
        """
        Construye el árbol completo bottom-up.
        Nivel 2 → Nivel 1 → Nivel 0.
        """
        ts_start = time.time()

        # ── Nivel 2: leer todos los agentes en paralelo ────────
        domain_reports = []
        for domain_id, domain_def in TREE_DEFINITION.items():
            agents        = domain_def["agents"]
            agent_reports = await asyncio.gather(*[
                self.reader.read(agent_id, domain_id)
                for agent_id in agents
            ])
            # Aplicar pesos especiales dentro del dominio
            weighted = self._apply_agent_weights(list(agent_reports))

            # ── Nivel 1: agregar dominio ───────────────────────
            domain_report = DomainReport(
                domain_id    = domain_id,
                agent_reports= weighted,
            )
            await self._save_domain_report(domain_id, domain_report)
            domain_reports.append(domain_report)

        # ── Nivel 0: raíz ─────────────────────────────────────
        root = RootReport(domain_reports)
        await self._save_root_report(root)
        self._last_root = root

        elapsed = round((time.time() - ts_start) * 1000)
        logger.info(
            f"[HEALTH_TREE] Árbol construido en {elapsed}ms — "
            f"{root.icon} {root.score*100:.1f}% "
            f"({root.status.value.upper()})"
        )
        return root

    def _apply_agent_weights(
        self, reports: List[HealthReport]
    ) -> List[HealthReport]:
        """
        Ajusta scores según pesos especiales de ciertos agentes.
        Un agente pesado que cae arrastra más al dominio.
        (Noto: el weight se usa en DomainReport._aggregate)
        """
        for r in reports:
            weight = AGENT_WEIGHTS.get(r.node_id, 1.0)
            r.domain = r.domain  # preservar
            # Almacenar peso como metadata para uso en agregación
            if r.metrics:
                r.metrics.custom["_weight"] = weight
        return reports

    # ─────────────────────────────────────────────
    # Propagación inmediata
    # ─────────────────────────────────────────────
    async def bubble_up(self, agent_id: str) -> Optional[RootReport]:
        """
        Propagación inmediata: un agente reporta rojo
        sin esperar el ciclo de 5 minutos.
        Reconstruye solo el camino afectado del árbol.
        """
        domain_id = self._find_domain(agent_id)
        if not domain_id:
            logger.warning(f"[HEALTH_TREE] Agente {agent_id} no en árbol")
            return None

        logger.info(
            f"[HEALTH_TREE] 🔴 Propagación inmediata: "
            f"{agent_id} → {domain_id} → ROOT"
        )

        # Reconstruir solo el dominio afectado
        domain_def    = TREE_DEFINITION[domain_id]
        agent_reports = await asyncio.gather(*[
            self.reader.read(aid, domain_id)
            for aid in domain_def["agents"]
        ])
        domain_report = DomainReport(
            domain_id    = domain_id,
            agent_reports= list(agent_reports),
        )
        domain_report.bubbled_from = agent_id
        await self._save_domain_report(domain_id, domain_report)

        # Actualizar raíz con el dominio reconstruido
        if self._last_root:
            new_domains = [
                domain_report if d.node_id == domain_id else d
                for d in self._last_root.children
            ]
            root = RootReport(new_domains)
            root.bubbled_from = f"{agent_id}→{domain_id}"
            await self._save_root_report(root)
            self._last_root = root
            return root
        else:
            return await self.build()

    def _find_domain(self, agent_id: str) -> Optional[str]:
        for domain_id, domain_def in TREE_DEFINITION.items():
            if agent_id in domain_def["agents"]:
                return domain_id
        return None

    # ─────────────────────────────────────────────
    # Consultas
    # ─────────────────────────────────────────────
    async def get_root(self) -> Optional[Dict]:
        """Lee el último reporte raíz desde Redis."""
        raw = await self.redis.get(ROOT_REPORT_KEY)
        if raw:
            return json.loads(raw)
        return None

    async def get_domain(self, domain_id: str) -> Optional[Dict]:
        key = DOMAIN_REPORT_KEY.format(domain_id=domain_id)
        raw = await self.redis.get(key)
        return json.loads(raw) if raw else None

    async def get_agent(self, agent_id: str) -> Optional[Dict]:
        key = AGENT_REPORT_KEY.format(agent_id=agent_id)
        raw = await self.redis.get(key)
        return json.loads(raw) if raw else None

    async def get_degraded_agents(self) -> List[Dict]:
        """Retorna todos los agentes que no están GREEN."""
        degraded = []
        for domain_def in TREE_DEFINITION.values():
            for agent_id in domain_def["agents"]:
                report = await self.get_agent(agent_id)
                if report and report.get("status") not in ("green", None):
                    degraded.append(report)
        return sorted(degraded, key=lambda x: x.get("score", 1.0))

    async def get_history(self, limit: int = 20) -> List[Dict]:
        """Historial de reportes raíz."""
        raw = await self.redis.lrange(HISTORY_KEY, 0, limit - 1)
        return [json.loads(r) for r in raw]

    # ─────────────────────────────────────────────
    # Persistencia
    # ─────────────────────────────────────────────
    async def _save_root_report(self, report: RootReport) -> None:
        try:
            data = report.to_dict()
            # Add flattened 'domains' dict for diagnostic/dashboard compatibility
            data["domains"] = {
                d.node_id: {"status": d.status.value, "score": d.score}
                for d in report.children
            }
            await self.redis.set(ROOT_REPORT_KEY, json.dumps(data), ex=600)
            # Historial con TTL 7 días
            await self.redis.lpush(
                HISTORY_KEY,
                json.dumps({
                    "ts":          report.ts,
                    "status":      report.status.value,
                    "score":       report.score,
                    "summary":     report.summary,
                    "bubbled_from":report.bubbled_from,
                })
            )
            await self.redis.ltrim(HISTORY_KEY, 0, 199)

            # Publish aggregated metrics for ObserverHealthBridge
            green = yellow = red = grey = 0
            domains_summary = {}
            for domain in report.children:
                domains_summary[domain.node_id] = {
                    "status": domain.status.value,
                    "score":  domain.score,
                }
                for agent in domain.children:
                    s = agent.status.value
                    if s == "green": green += 1
                    elif s == "yellow": yellow += 1
                    elif s == "red": red += 1
                    else: grey += 1

            metrics_payload = {
                "ts": int(report.ts),
                "agents_total": green + yellow + red + grey,
                "agents_green": green,
                "agents_yellow": yellow,
                "agents_red": red,
                "agents_grey": grey,
                "root_score": report.score,
                "root_status": report.status.value,
                "domains": domains_summary,
            }
            await self.redis.set(
                METRICS_KEY, json.dumps(metrics_payload), ex=600
            )

        except Exception as e:
            logger.error(f"[HEALTH_TREE] Error guardando root: {e}")

    async def _save_domain_report(
        self, domain_id: str, report: DomainReport
    ) -> None:
        key = DOMAIN_REPORT_KEY.format(domain_id=domain_id)
        try:
            await self.redis.set(key, report.to_json(), ex=600)
        except Exception as e:
            logger.error(f"[HEALTH_TREE] Error guardando dominio {domain_id}: {e}")
