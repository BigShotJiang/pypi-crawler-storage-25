"""

MODIFICATION_GUIDE = {
    "file":    "core/health/defcon_transitions.py",
    "version": "1.0",
    "purpose": (
        "Registro inmutable de cada transición DEFCON. "
        "Hace diagnósticos posibles: antes era imposible saber POR QUÉ cambió DEFCON. "
        "Se llama desde threat_analyzer.update_defcon() en cada ciclo de Sentinel."
    ),
    "extension_points": [
        "DEFCON_AUTO_ACTIONS: añadir/quitar acciones automáticas por nivel.",
        "  Ejemplo: agregar 'suspend_economy' en DEFCON 1 para frenar trades.",
        "DEFCON_DESCRIPTIONS: actualizar el texto cuando cambie la semántica de un nivel.",
        "HISTORY_MAX: aumentar si se quiere más historial (default 200 transiciones).",
        "record_transition(extra={}): pasar métricas adicionales al record.",
        "  Ejemplo: extra={'gshi': 79.6, 'agents_alive': 21}",
    ],
    "invariants": [
        "NUNCA cambiar HISTORY_KEY — dashboard y Telegram leen esta key.",
        "NUNCA cambiar la estructura del record (from/to/score/reason/triggered_by).",
        "  Kernell, Sierra y el dashboard dependen de estos campos.",
        "NUNCA borrar CURRENT_KEY — es la fuente de verdad del DEFCON con contexto.",
    ],
    "verify_after": [
        "redis-cli -p 6380 -a $REDIS_PASSWORD LRANGE kernell:defcon:history 0 2",
        "  # Debe mostrar registros con 'from', 'to', 'reason'",
        "sudo systemctl restart kernell-os-swarm@sentinel.service",
        "  # Recargar threat_analyzer con el patch integrado",
    ],
    "owner_agent": "sentinel (escribe) + sierra (monitorea) + dashboard (lee)",
    "ontology_refs": {
        "redis_keys": ["kernell:defcon:history", "kernell:defcon:current"],
        "related_modules": ["agents/sentinel/threat_analyzer.py"],
        "dashboard_endpoint": "/api/overview → defcon field",
    },
}
core/health/defcon_transitions.py
==================================
Registro inmutable de transiciones DEFCON.

Cada vez que update_defcon() cambia el nivel, escribe un record a:
  kernell:defcon:history    (lista circular, max 200)
  kernell:defcon:current    (JSON con contexto completo)

Esto hace diagnósticos posibles: antes era imposible saber POR QUÉ
DEFCON cambió.

Integración:
  threat_analyzer.py → update_defcon() llama record_transition()

Uso standalone:
  from core.health.defcon_transitions import DefconTransitions
  dt = DefconTransitions(redis_client)
  dt.record_transition(from_defcon=3, to_defcon=1, score=0.85,
                       reason="Redis port unreachable", triggered_by="sentinel")
"""

import json
import time
import logging
from typing import Optional

logger = logging.getLogger("kernell.defcon")

# Auto-actions per DEFCON level
DEFCON_AUTO_ACTIONS: dict[int, list[str]] = {
    1: ["notify_telegram", "increase_poll_rate", "suspend_mutations"],
    2: ["notify_telegram", "increase_poll_rate"],
    3: ["log_warning"],
    4: [],
    5: [],
}

DEFCON_DESCRIPTIONS: dict[int, str] = {
    1: "WAR — sistema degradado, amenaza crítica",
    2: "ELEVATED — amenaza activa, monitoreo intensivo",
    3: "ELEVATED — anomalías detectadas",
    4: "NORMAL — operación estándar",
    5: "PEACE — sistema óptimo",
}

HISTORY_KEY  = "kernell:defcon:history"
CURRENT_KEY  = "kernell:defcon:current"
HISTORY_MAX  = 200


class DefconTransitions:

    def __init__(self, redis_client):
        self.redis = redis_client

    def record_transition(
        self,
        from_defcon: Optional[int],
        to_defcon:   int,
        score:       float,
        reason:      str      = "periodic_recalculation",
        triggered_by: str     = "sentinel",
        extra:       Optional[dict] = None,
    ) -> dict:
        """
        Record a DEFCON transition. Always writes current state.
        Only appends to history if the level actually changed.
        """
        record = {
            "timestamp":    time.time(),
            "ts_iso":       _iso_now(),
            "from":         from_defcon,
            "to":           to_defcon,
            "score":        round(score, 4),
            "reason":       reason,
            "triggered_by": triggered_by,
            "description":  DEFCON_DESCRIPTIONS.get(to_defcon, ""),
            "auto_actions": DEFCON_AUTO_ACTIONS.get(to_defcon, []),
            "changed":      from_defcon != to_defcon,
        }
        if extra:
            record.update(extra)

        try:
            # Always update current state
            self.redis.set(CURRENT_KEY, json.dumps(record), ex=3600)

            # Only append history when level changes
            if from_defcon != to_defcon:
                self.redis.lpush(HISTORY_KEY, json.dumps(record))
                self.redis.ltrim(HISTORY_KEY, 0, HISTORY_MAX - 1)

                logger.warning(
                    f"DEFCON {from_defcon} → {to_defcon} | "
                    f"score={score:.3f} | reason={reason}"
                )

        except Exception as e:
            logger.error(f"DefconTransitions.record_transition error: {e}")

        return record

    def get_history(self, limit: int = 20) -> list[dict]:
        """Returns the last N DEFCON transitions."""
        try:
            raw = self.redis.lrange(HISTORY_KEY, 0, min(limit, HISTORY_MAX) - 1)
            return [json.loads(r) for r in raw]
        except Exception:
            return []

    def get_current(self) -> Optional[dict]:
        """Returns the current DEFCON state with full context."""
        try:
            raw = self.redis.get(CURRENT_KEY)
            return json.loads(raw) if raw else None
        except Exception:
            return None

    def get_last_transition_reason(self) -> str:
        """Quick accessor for dashboard."""
        history = self.get_history(1)
        if history:
            return history[0].get("reason", "unknown")
        return "no history"


def _iso_now() -> str:
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).isoformat()


# ── Patch para threat_analyzer.py ─────────────────────────────────────────────

PATCH_DESCRIPTION = """
Patch: integrar DefconTransitions en threat_analyzer.update_defcon()

ANTES (update_defcon actual):
    self.redis.set("kernell:system:defcon", defcon)
    ... (5 redis.set calls)

DESPUÉS:
    # ── DefconTransitions log ─────────────────────────────────────────
    try:
        from core.health.defcon_transitions import DefconTransitions
        prev_raw = self.redis.get("kernell:system:defcon")
        prev_defcon = int(prev_raw) if prev_raw else None
        dt = DefconTransitions(self.redis)
        dt.record_transition(
            from_defcon  = prev_defcon,
            to_defcon    = defcon,
            score        = score,
            reason       = self._last_threat_reason,
            triggered_by = "sentinel",
        )
    except Exception as _e:
        self.logger.debug(f"DefconTransitions log error: {_e}")
    # ─────────────────────────────────────────────────────────────────

    self.redis.set("kernell:system:defcon", defcon)
    ... (resto sin cambios)
"""

if __name__ == "__main__":
    print(PATCH_DESCRIPTION)
