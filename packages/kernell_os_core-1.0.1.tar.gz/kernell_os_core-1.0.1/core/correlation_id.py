"""
Correlation ID propagation for Kernell OS (contextvars + Redis payloads).

Uso:
    from core.correlation_id import CorrelationContext, inject_cid, extract_cid, with_correlation

    with CorrelationContext.new_cycle(source="atlas") as cid:
        redis.rpush("kernell:tasks:forge", json.dumps(inject_cid({"type": "task"})))
"""

from __future__ import annotations

import contextvars
import functools
import json
import logging
import time
import uuid
from dataclasses import asdict, dataclass, field
from typing import Any, Callable, Optional

logger = logging.getLogger("kernell.correlation")

_correlation_id: contextvars.ContextVar[Optional[str]] = contextvars.ContextVar(
    "correlation_id", default=None
)
_correlation_meta: contextvars.ContextVar[dict[str, Any]] = contextvars.ContextVar(
    "correlation_meta", default={}
)


@dataclass
class TraceSpan:
    cid: str
    agent: str
    operation: str
    started_at: float = field(default_factory=time.time)
    ended_at: Optional[float] = None
    parent_cid: Optional[str] = None
    status: str = "running"
    error: Optional[str] = None
    meta: dict[str, Any] = field(default_factory=dict)

    def finish(self, status: str = "ok", error: Optional[str] = None) -> TraceSpan:
        self.ended_at = time.time()
        self.status = status
        self.error = error
        return self

    @property
    def duration_ms(self) -> Optional[float]:
        if self.ended_at:
            return round((self.ended_at - self.started_at) * 1000, 2)
        return None

    def to_log_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["duration_ms"] = self.duration_ms
        return {k: v for k, v in d.items() if v is not None}


class CorrelationContext:
    """Context manager: establece CID en contextvars para el bloque."""

    def __init__(self, cid: str, agent: str = "unknown", meta: Optional[dict] = None):
        self._cid = cid
        self._agent = agent
        self._meta = meta or {}
        self._token: Optional[contextvars.Token] = None
        self._meta_token: Optional[contextvars.Token] = None

    @classmethod
    def new_cycle(cls, source: str = "atlas", meta: Optional[dict] = None) -> CorrelationContext:
        cid = f"CID-{source[:4].upper()}-{uuid.uuid4().hex[:12]}"
        return cls(cid=cid, agent=source, meta=meta)

    @classmethod
    def from_message(cls, cid: str, agent: str = "unknown") -> CorrelationContext:
        return cls(cid=cid, agent=agent)

    def __enter__(self) -> str:
        self._token = _correlation_id.set(self._cid)
        self._meta_token = _correlation_meta.set(
            {"cid": self._cid, "agent": self._agent, **self._meta}
        )
        logger.debug("trace.start cid=%s agent=%s", self._cid, self._agent)
        return self._cid

    def __exit__(self, exc_type, exc_val, exc_tb) -> bool:
        if exc_type:
            logger.warning(
                "trace.error cid=%s agent=%s error=%s", self._cid, self._agent, exc_val
            )
        else:
            logger.debug("trace.end cid=%s agent=%s", self._cid, self._agent)
        if self._token is not None:
            _correlation_id.reset(self._token)
        if self._meta_token is not None:
            _correlation_meta.reset(self._meta_token)
        return False


def get_cid() -> Optional[str]:
    return _correlation_id.get()


def get_meta() -> dict[str, Any]:
    return _correlation_meta.get()


def inject_cid(payload: dict[str, Any]) -> dict[str, Any]:
    cid = get_cid() or f"CID-EPHM-{uuid.uuid4().hex[:12]}"
    return {**payload, "_cid": cid, "_ts": time.time()}


def extract_cid(payload: dict[str, Any] | str | bytes | None) -> Optional[str]:
    if payload is None:
        return None
    try:
        if isinstance(payload, (str, bytes)):
            data = json.loads(payload)
        else:
            data = payload
        return data.get("_cid") if isinstance(data, dict) else None
    except Exception:
        return None


def with_correlation(agent: str = "unknown") -> Callable[[Callable], Callable]:
    """Decorador: continúa CID del mensaje o abre ciclo nuevo (sync/async)."""

    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
            msg = kwargs.get("message")
            if msg is None and len(args) > 1:
                msg = args[1]
            cid = extract_cid(msg) if isinstance(msg, (dict, str, bytes)) else None
            ctx = (
                CorrelationContext.from_message(cid, agent=agent)
                if cid
                else CorrelationContext.new_cycle(source=agent)
            )
            with ctx:
                return await func(*args, **kwargs)

        @functools.wraps(func)
        def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
            msg = kwargs.get("message")
            if msg is None and len(args) > 1:
                msg = args[1]
            cid = extract_cid(msg) if isinstance(msg, (dict, str, bytes)) else None
            ctx = (
                CorrelationContext.from_message(cid, agent=agent)
                if cid
                else CorrelationContext.new_cycle(source=agent)
            )
            with ctx:
                return func(*args, **kwargs)

        import asyncio

        if asyncio.iscoroutinefunction(func):
            return async_wrapper
        return sync_wrapper

    return decorator


def log_with_cid(
    logger_instance: logging.Logger, level: str, message: str, **kwargs: Any
) -> None:
    cid = get_cid()
    meta = get_meta()
    extra = {k: v for k, v in {**meta, **kwargs}.items() if v is not None}
    extra["cid"] = cid
    extra_str = " ".join(f"{k}={v}" for k, v in extra.items() if v is not None)
    full_msg = f"{message} [{extra_str}]" if extra_str else message
    getattr(logger_instance, level)(full_msg)
