#!/usr/bin/env python3
"""
core/readme_loader.py
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Carga el README.md del agente y del root, y los inyecta al inicio
del system prompt. Esto hace que las reglas sean las primeras
instrucciones que el LLM lee — máxima prioridad de contexto.

Uso en el __init__ de cualquier agente:
    from core.readme_loader import ReadmeLoader

    loader = ReadmeLoader("atlas")
    system_prompt = loader.build_system_prompt(
        base_prompt="Eres Atlas, el monitor cognitivo del swarm..."
    )

El prompt resultante tiene esta estructura:
    [README del agente — reglas, alcance, anti-asunciones]
    [README root — infraestructura, protocolo global]
    [Estado verificado del sistema en tiempo real]
    [Prompt base del agente]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"""
import os, json, time, hashlib, logging
from pathlib import Path
from typing import Optional

logger = logging.getLogger("ReadmeLoader")

ROOT = Path(__file__).parent.parent


class ReadmeLoader:

    def __init__(self, agent_name: str, redis_client=None):
        self.agent       = agent_name
        self.r           = redis_client
        self._agent_path = ROOT / "agents" / agent_name / "README.md"
        self._root_path  = ROOT / "README.md"

    def _load_file(self, path: Path) -> Optional[str]:
        if not path.exists():
            logger.warning(f"README no encontrado: {path}")
            return None
        content = path.read_text(encoding="utf-8", errors="ignore")
        logger.debug(f"README cargado: {path} ({len(content)} chars)")
        return content

    def _hash(self, content: str) -> str:
        return hashlib.sha256(content.encode()).hexdigest()[:12]

    def _get_system_state(self) -> str:
        """
        Obtiene el estado REAL y VERIFICADO del sistema desde Redis.
        Este bloque se inyecta en cada llamada para que el LLM
        no use memoria de ciclos anteriores.
        """
        if not self.r:
            return "(Estado del sistema no disponible — Redis no configurado)"

        now   = time.time()
        lines = [f"Timestamp: {time.strftime('%Y-%m-%d %H:%M:%S UTC', time.gmtime())}"]

        # ── Estado global ────────────────────────────────────────────────────
        keys = {
            "DEFCON":        "kernell:system:defcon",
            "health_score":  "kernell:system:health_score",
            "boot_status":   "kernell:system:boot_status",
            "kill_switch":   "kernell:economy:kill_switch",
            "phantom_mode":  "kernell:system:phantom_mode",
        }
        for label, key in keys.items():
            try:
                val = self.r.get(key) or "NO_DATA"
                lines.append(f"{label}: {val}")
            except Exception:
                lines.append(f"{label}: ERROR_READING")

        # ── Heartbeats de agentes ────────────────────────────────────────────
        try:
            alive, dead = [], []
            for hb_key in (self.r.keys("kernell:agent:*:heartbeat") or []):
                name = hb_key.split(":")[2]
                raw  = self.r.get(hb_key)
                if raw:
                    try:
                        ts = json.loads(raw)
                        if isinstance(ts, dict):
                            ts = ts.get("ts") or ts.get("timestamp", 0)
                        age = now - float(ts)
                        (alive if age < 120 else dead).append(f"{name}({age:.0f}s)")
                    except Exception:
                        dead.append(f"{name}(?)")
            lines.append(f"Agentes vivos ({len(alive)}): {', '.join(sorted(alive)) or 'ninguno'}")
            if dead:
                lines.append(f"Agentes dead  ({len(dead)}): {', '.join(sorted(dead))}")
        except Exception as e:
            lines.append(f"Heartbeats: ERROR_READING ({e})")

        # ── Infraestructura ──────────────────────────────────────────────────
        import socket, shutil

        def port_status(port, label):
            try:
                s = socket.create_connection(("127.0.0.1", port), timeout=0.5)
                s.close()
                return f"{label}:{port}=OPEN"
            except Exception:
                return f"{label}:{port}=CLOSED"

        infra = [
            port_status(6379, "Redis"),
            port_status(6333, "Qdrant"),
            port_status(8765, "KernellWS"),
            port_status(8502, "Dashboard"),
        ]
        lines.append(f"Infraestructura: {' | '.join(infra)}")

        # ── RAMDisk ──────────────────────────────────────────────────────────
        try:
            usage = shutil.disk_usage("/mnt/kernell_ram")
            pct   = round(usage.used / usage.total * 100, 1)
            lines.append(f"RAMDisk: {pct}% usado ({usage.free // 1048576}MB libres)")
        except Exception:
            lines.append("RAMDisk: NO_MONTADO")

        return "\n".join(lines)

    def build_system_prompt(self, base_prompt: str = "",
                            include_state: bool = True) -> str:
        """
        Construye el system prompt completo con:
          1. README del agente (reglas + alcance + anti-asunciones)
          2. README root (infraestructura + protocolo global)
          3. Estado verificado del sistema (si include_state=True)
          4. Prompt base del agente

        Returns: string listo para usar como system prompt
        """
        sections = []

        # ── 1. README del agente ──────────────────────────────────────────────
        agent_readme = self._load_file(self._agent_path)
        if agent_readme:
            h = self._hash(agent_readme)
            # Registrar hash en Redis para auditoría
            if self.r:
                try:
                    self.r.set(
                        f"kernell:agent:{self.agent}:readme_hash",
                        h, ex=86400
                    )
                except Exception:
                    pass
            sections.append(agent_readme)
        else:
            # Si no hay README del agente, inyectar bloque mínimo de reglas
            sections.append(self._minimal_rules_block())

        # ── 2. README root (sección de infraestructura) ───────────────────────
        root_readme = self._load_file(self._root_path)
        if root_readme:
            # Solo incluir la sección de infraestructura del root para no
            # sobrecargar el contexto con el documento completo
            infra_section = self._extract_section(
                root_readme, "## 3. INFRAESTRUCTURA"
            )
            if infra_section:
                sections.append(
                    "## REFERENCIA DE INFRAESTRUCTURA DEL SISTEMA\n\n"
                    + infra_section
                )

        # ── 3. Estado verificado ──────────────────────────────────────────────
        if include_state:
            state = self._get_system_state()
            sections.append(
                "## ESTADO VERIFICADO DEL SISTEMA AHORA\n"
                f"```\n{state}\n```\n"
                "**Este es el estado real. No extrapoles más allá de estos datos.**"
            )

        # ── 4. Prompt base del agente ─────────────────────────────────────────
        if base_prompt:
            sections.append("---\n\n## TU TAREA EN ESTE CICLO\n\n" + base_prompt)

        return "\n\n---\n\n".join(sections)

    def _extract_section(self, content: str, header: str) -> Optional[str]:
        """Extrae una sección específica de un README por su header."""
        start = content.find(header)
        if start == -1:
            return None
        # Encontrar el siguiente header del mismo nivel
        level = header.count("#") - header.replace("#", "").count("#")
        prefix = "#" * level + " "
        end = content.find(f"\n{prefix}", start + len(header))
        if end == -1:
            return content[start:]
        return content[start:end]

    def _minimal_rules_block(self) -> str:
        """Bloque mínimo de reglas cuando no hay README del agente."""
        return f"""# AGENTE: {self.agent.upper()}

## REGLAS DE OPERACIÓN MÍNIMAS

**NUNCA ASUMIR — SIEMPRE VERIFICAR:**
- Si no tienes evidencia verificada de algo, NO puedes afirmarlo
- No puedes decir "asumo que", "debería estar", "ya lo hice" sin output real
- Qdrant corre NATIVO en este sistema: `curl http://127.0.0.1:6333/healthz`
- Redis corre NATIVO: `redis-cli ping`

**OPERA DENTRO DE TU ROL:**
- Si no tienes un README específico, consulta `agents/{self.agent}/README.md`
- Si no existe, pide que se genere con: `python3 scripts/generate_agent_readmes.py --agent {self.agent}`
"""

    def verify_readme_integrity(self) -> dict:
        """
        Verifica que el README del agente no fue modificado desde
        el último arranque. Detecta tampering en runtime.
        """
        agent_readme = self._load_file(self._agent_path)
        if not agent_readme:
            return {"ok": False, "reason": "README no encontrado"}

        current_hash = self._hash(agent_readme)
        result = {"ok": True, "current_hash": current_hash}

        if self.r:
            try:
                stored_hash = self.r.get(
                    f"kernell:gitops:hash:readme_{self.agent}"
                )
                if stored_hash and stored_hash != current_hash:
                    result["ok"]     = False
                    result["reason"] = (
                        f"README HASH DRIFT — "
                        f"stored={stored_hash} current={current_hash}"
                    )
                    # Alertar a sentinel
                    self.r.lpush("kernell:events:security", json.dumps({
                        "type":    "readme_integrity_violation",
                        "agent":   self.agent,
                        "stored":  stored_hash,
                        "current": current_hash,
                        "ts":      time.time(),
                    }))
                # Actualizar hash almacenado
                self.r.set(
                    f"kernell:gitops:hash:readme_{self.agent}",
                    current_hash, ex=86400 * 7
                )
            except Exception as e:
                result["redis_error"] = str(e)

        return result
