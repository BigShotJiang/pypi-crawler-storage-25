#!/usr/bin/env python3
"""
core/tool_result_persister.py
═════════════════════════════
Persistencia de resultados grandes de tools a disco.

Cuando un tool produce una salida que excede el umbral configurado,
el contenido se guarda a disco y se reemplaza en el historial de
mensajes con un preview compacto + ruta al archivo completo.

Esto ahorra entre 40-60% de tokens por turno en agentes que manejan
outputs masivos (MT5, Bash, Grep).

Uso:
    from core.tool_result_persister import ToolResultPersister

    persister = ToolResultPersister(agent_name="nemesis")

    # En el loop del agente, después de recibir un tool result:
    content = tool_output  # String potencialmente enorme
    content = persister.maybe_persist(content, tool_name="bash", tool_id="abc123")
    # Si era grande → se guardó a disco y content ahora es un preview de ~2KB
"""
import os
import sys
import json
import time
import hashlib
import logging
from pathlib import Path
from typing import Optional, NamedTuple

# Imports de Kernell OS
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.token_estimator import estimate_tokens, format_token_count

logger = logging.getLogger("ToolResultPersister")

# ── Configuración ────────────────────────────────────────────────────────────

# Directorio base para persistir resultados
PERSIST_BASE_DIR = Path("/var/lib/kernell-os/tool-results")

# Umbral por defecto: si el contenido excede ~12.5K tokens (~50K chars), persistir
DEFAULT_THRESHOLD_CHARS = 50_000

# Umbrales personalizados por tool (algunos producen outputs más grandes por diseño)
TOOL_THRESHOLDS = {
    "bash":         30_000,     # Bash tiende a producir outputs largos legítimos
    "mt5_query":    20_000,     # MT5 genera JSON enormes de ticks
    "grep":         40_000,     # Grep puede devolver muchas coincidencias
    "file_read":    60_000,     # File reads grandes son intencionales
    "qdrant_query": 25_000,     # Vectores con payloads densos
}

# Tamaño del preview en bytes
PREVIEW_SIZE = 2000

# Tags XML para marcar contenido persistido
PERSISTED_TAG_OPEN  = "<persisted-output>"
PERSISTED_TAG_CLOSE = "</persisted-output>"

# Mensaje cuando se limpia un tool_result viejo
CLEARED_MESSAGE = "[Old tool result content cleared]"


# ── Tipos ────────────────────────────────────────────────────────────────────

class PersistResult(NamedTuple):
    """Resultado de una operación de persistencia."""
    persisted: bool
    filepath: Optional[str]
    original_size: int
    preview_size: int
    tokens_saved: int


# ── Core ─────────────────────────────────────────────────────────────────────

class ToolResultPersister:
    """
    Gestiona la persistencia de tool results grandes a disco.
    Cada agente tiene su propia instancia con subdirectorio aislado.
    """

    def __init__(
        self,
        agent_name: str,
        session_id: Optional[str] = None,
        base_dir: Optional[Path] = None,
    ):
        self.agent_name = agent_name
        self.session_id = session_id or f"session_{int(time.time())}"
        self.base_dir = base_dir or PERSIST_BASE_DIR

        # Directorio del agente para esta sesión
        self._results_dir = self.base_dir / agent_name / self.session_id
        self._results_dir.mkdir(parents=True, exist_ok=True)

        # Tracking de persistencias ya realizadas (para deduplicación)
        self._persisted_ids: set[str] = set()

        # Contadores
        self.total_persisted = 0
        self.total_tokens_saved = 0

    def get_threshold(self, tool_name: str) -> int:
        """Obtiene el umbral de persistencia para un tool específico."""
        return TOOL_THRESHOLDS.get(tool_name, DEFAULT_THRESHOLD_CHARS)

    def maybe_persist(
        self,
        content: str,
        tool_name: str,
        tool_id: str,
        threshold: Optional[int] = None,
    ) -> str:
        """
        Decide si persistir el contenido a disco.

        Si el contenido excede el umbral, lo guarda a disco y retorna
        un preview compacto. Si no, retorna el contenido original.

        Args:
            content:    El texto del tool result
            tool_name:  Nombre del tool (bash, grep, mt5_query, etc.)
            tool_id:    ID único de la invocación del tool
            threshold:  Umbral personalizado (override por tool_name)

        Returns:
            El contenido original (si corto) o un preview con ruta al archivo
        """
        if not content or not content.strip():
            return f"({tool_name} completed with no output)"

        # Si ya está persistido (marcado con nuestro tag), no tocar
        if content.startswith(PERSISTED_TAG_OPEN):
            return content

        effective_threshold = threshold or self.get_threshold(tool_name)

        if len(content) <= effective_threshold:
            return content

        # Deduplicación: si ya persistimos esto, el archivo ya existe
        if tool_id in self._persisted_ids:
            # Re-generar el preview sin re-escribir el archivo
            filepath = self._get_filepath(tool_id, content)
            preview, has_more = self._generate_preview(content)
            return self._build_reference_message(filepath, len(content), preview, has_more)

        # Persistir a disco
        result = self._persist(content, tool_id, tool_name)

        if result.persisted:
            self._persisted_ids.add(tool_id)
            self.total_persisted += 1
            self.total_tokens_saved += result.tokens_saved

            logger.info(
                f"[{self.agent_name}] Persisted {tool_name} result "
                f"({format_token_count(estimate_tokens(content))} tokens → "
                f"{format_token_count(result.preview_size)} preview) "
                f"→ {result.filepath}"
            )

            preview, has_more = self._generate_preview(content)
            return self._build_reference_message(result.filepath, len(content), preview, has_more)

        # Si la persistencia falló, retornar el contenido original
        return content

    def clear_old_results(
        self,
        tool_ids: list[str],
        keep_recent: int = 3,
    ) -> list[str]:
        """
        Limpia tool results viejos dejando solo los N más recientes.
        Uses time-based eviction for token optimization.

        Args:
            tool_ids:    Lista de tool_ids en orden cronológico
            keep_recent: Cuántos resultados recientes mantener

        Returns:
            Lista de tool_ids que fueron limpiados
        """
        if len(tool_ids) <= keep_recent:
            return []

        to_clear = tool_ids[:-keep_recent]
        cleared = []

        for tid in to_clear:
            if tid in self._persisted_ids:
                # Ya está en disco, no necesitamos hacer nada más
                cleared.append(tid)
            else:
                cleared.append(tid)

        return cleared

    def get_status(self) -> dict:
        """Retorna estadísticas del persister."""
        files = list(self._results_dir.glob("*"))
        total_disk = sum(f.stat().st_size for f in files if f.is_file())

        return {
            "agent":          self.agent_name,
            "session_id":     self.session_id,
            "results_dir":    str(self._results_dir),
            "files_on_disk":  len(files),
            "disk_usage":     self._format_size(total_disk),
            "total_persisted": self.total_persisted,
            "tokens_saved":   format_token_count(self.total_tokens_saved),
        }

    # ── Internos ──────────────────────────────────────────────────────────

    def _persist(self, content: str, tool_id: str, tool_name: str) -> PersistResult:
        """Guarda el contenido a disco."""
        is_json = self._looks_like_json(content)
        filepath = self._get_filepath(tool_id, content, is_json)

        try:
            # Escritura exclusiva — si el archivo ya existe, skip
            filepath.write_text(content, encoding="utf-8")

            original_tokens = estimate_tokens(content)
            preview_tokens = estimate_tokens(content[:PREVIEW_SIZE])
            tokens_saved = max(0, original_tokens - preview_tokens - 50)  # 50 tokens de overhead

            return PersistResult(
                persisted=True,
                filepath=str(filepath),
                original_size=len(content),
                preview_size=PREVIEW_SIZE,
                tokens_saved=tokens_saved,
            )

        except Exception as e:
            logger.error(f"[{self.agent_name}] Failed to persist tool result: {e}")
            return PersistResult(
                persisted=False,
                filepath=None,
                original_size=len(content),
                preview_size=0,
                tokens_saved=0,
            )

    def _get_filepath(self, tool_id: str, content: str = "", is_json: bool = False) -> Path:
        """Genera la ruta del archivo para un tool_id."""
        # Sanitizar el tool_id para nombre de archivo
        safe_id = tool_id.replace("/", "_").replace("\\", "_")[:64]
        ext = "json" if is_json else "txt"
        return self._results_dir / f"{safe_id}.{ext}"

    def _generate_preview(self, content: str) -> tuple[str, bool]:
        """
        Genera un preview del contenido, cortando en boundary de newline.
        Retorna (preview_text, has_more).
        """
        if len(content) <= PREVIEW_SIZE:
            return content, False

        truncated = content[:PREVIEW_SIZE]
        last_newline = truncated.rfind("\n")

        # Si encontramos un newline razonable, cortar ahí
        if last_newline > PREVIEW_SIZE * 0.5:
            cut_point = last_newline
        else:
            cut_point = PREVIEW_SIZE

        return content[:cut_point], True

    def _build_reference_message(
        self,
        filepath: str,
        original_size: int,
        preview: str,
        has_more: bool,
    ) -> str:
        """Construye el mensaje de referencia con preview."""
        size_str = self._format_size(original_size)

        msg = f"{PERSISTED_TAG_OPEN}\n"
        msg += f"Output too large ({size_str}). Full output saved to: {filepath}\n\n"
        msg += f"Preview (first {self._format_size(PREVIEW_SIZE)}):\n"
        msg += preview
        if has_more:
            msg += "\n...\n"
        else:
            msg += "\n"
        msg += PERSISTED_TAG_CLOSE
        return msg

    @staticmethod
    def _looks_like_json(content: str) -> bool:
        """Verifica heurísticamente si el contenido parece JSON."""
        stripped = content.strip()
        return (stripped.startswith("{") and stripped.endswith("}")) or \
               (stripped.startswith("[") and stripped.endswith("]"))

    @staticmethod
    def _format_size(size_bytes: int) -> str:
        """Formatea bytes para display humano."""
        if size_bytes >= 1_048_576:
            return f"{size_bytes / 1_048_576:.1f}MB"
        if size_bytes >= 1_024:
            return f"{size_bytes / 1_024:.1f}KB"
        return f"{size_bytes}B"


# ── CLI ───────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Tool Result Persister — Kernell OS")
    parser.add_argument("--status", action="store_true", help="Show persistence stats")
    parser.add_argument("--cleanup", metavar="AGENT", help="Clean old results for agent")
    parser.add_argument("--demo", action="store_true", help="Run demo")
    args = parser.parse_args()

    if args.demo:
        print("📦 Tool Result Persister Demo\n")
        p = ToolResultPersister("demo_agent", base_dir=Path("/tmp/kernell-tool-results"))

        # Simular un output grande
        big_output = "\n".join(f"Line {i}: {'x' * 100}" for i in range(1000))

        result = p.maybe_persist(big_output, "bash", "test_001")
        print(f"  Original: {len(big_output):,} chars")
        print(f"  Result:   {len(result):,} chars")
        print(f"  Savings:  {(1 - len(result)/len(big_output))*100:.0f}%")
        print(f"\n  Status: {json.dumps(p.get_status(), indent=2)}")

    elif args.status:
        base = PERSIST_BASE_DIR
        if not base.exists():
            print("📦 No tool results persisted yet.")
        else:
            print(f"\n📦 Tool Results — {base}\n")
            total = 0
            for agent_dir in sorted(base.iterdir()):
                if agent_dir.is_dir():
                    files = list(agent_dir.rglob("*"))
                    size = sum(f.stat().st_size for f in files if f.is_file())
                    total += size
                    count = len([f for f in files if f.is_file()])
                    print(f"  {agent_dir.name:<20} {count:>4} files  {ToolResultPersister._format_size(size):>8}")
            print(f"\n  {'TOTAL':<20} {'':>4}        {ToolResultPersister._format_size(total):>8}")

    elif args.cleanup:
        agent = args.cleanup
        agent_dir = PERSIST_BASE_DIR / agent
        if agent_dir.exists():
            import shutil
            size = sum(f.stat().st_size for f in agent_dir.rglob("*") if f.is_file())
            shutil.rmtree(agent_dir)
            print(f"🗑️  Cleaned {ToolResultPersister._format_size(size)} for agent '{agent}'")
        else:
            print(f"No results found for agent '{agent}'")
