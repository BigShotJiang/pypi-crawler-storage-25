"""
SLO snapshots + error-budget style alerts (Redis + optional Telegram).

Redis:
  kernell:slo:{agent}:current
  kernell:slo:system:summary
  kernell:slo:alerts:queue
"""

from __future__ import annotations

import json
import logging
import math
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Optional

logger = logging.getLogger("kernell.slo")


class EventType(str, Enum):
    SUCCESS = "success"
    ERROR = "error"
    TIMEOUT = "timeout"
    DEGRADED = "degraded"


AGENT_SLOS: dict[str, dict[str, float]] = {
    "operator": {"uptime_pct": 99.0, "error_rate_max": 1.0, "latency_p95_ms": 5000},
    "forge": {"uptime_pct": 99.5, "error_rate_max": 0.5, "latency_p95_ms": 30000},
    "nemesis": {"uptime_pct": 99.9, "error_rate_max": 0.1, "latency_p95_ms": 2000},
    "sentinel": {"uptime_pct": 99.9, "error_rate_max": 0.1, "latency_p95_ms": 3000},
    "atlas": {"uptime_pct": 99.5, "error_rate_max": 0.5, "latency_p95_ms": 10000},
    "sierra": {"uptime_pct": 99.5, "error_rate_max": 0.5, "latency_p95_ms": 5000},
    "nexus": {"uptime_pct": 99.9, "error_rate_max": 0.1, "latency_p95_ms": 1000},
    "economy": {"uptime_pct": 99.0, "error_rate_max": 1.0, "latency_p95_ms": 10000},
    "observer": {"uptime_pct": 99.5, "error_rate_max": 0.5, "latency_p95_ms": 5000},
    "interface": {"uptime_pct": 99.5, "error_rate_max": 0.5, "latency_p95_ms": 3000},
    "_default": {"uptime_pct": 99.0, "error_rate_max": 2.0, "latency_p95_ms": 15000},
}


@dataclass
class SLOState:
    agent: str
    window_start: float = field(default_factory=time.time)
    total_events: int = 0
    error_events: int = 0
    timeout_events: int = 0
    latencies_ms: list[float] = field(default_factory=list)
    last_error_ts: Optional[float] = None
    last_success_ts: Optional[float] = None
    downtime_periods: list[tuple[float, Optional[float]]] = field(default_factory=list)
    _current_down_start: Optional[float] = field(default=None, repr=False)

    @property
    def error_rate_pct(self) -> float:
        if self.total_events == 0:
            return 0.0
        return round((self.error_events / self.total_events) * 100, 4)

    @property
    def uptime_pct(self) -> float:
        total_down = sum((end or time.time()) - start for start, end in self.downtime_periods)
        elapsed = time.time() - self.window_start
        if elapsed <= 0:
            return 100.0
        return round(max(0.0, (1 - total_down / elapsed)) * 100, 4)

    @property
    def p95_latency_ms(self) -> Optional[float]:
        if not self.latencies_ms:
            return None
        sorted_l = sorted(self.latencies_ms)
        idx = math.ceil(len(sorted_l) * 0.95) - 1
        return sorted_l[max(0, idx)]

    def to_dict(self) -> dict[str, Any]:
        return {
            "agent": self.agent,
            "window_start": self.window_start,
            "total_events": self.total_events,
            "error_events": self.error_events,
            "error_rate_pct": self.error_rate_pct,
            "uptime_pct": self.uptime_pct,
            "p95_latency_ms": self.p95_latency_ms,
            "last_error_ts": self.last_error_ts,
            "last_success_ts": self.last_success_ts,
            "ts": time.time(),
        }


class SLOMonitor:
    def __init__(
        self,
        redis_client: Any = None,
        telegram_fn: Optional[Callable[[str], None]] = None,
    ) -> None:
        self.redis = redis_client
        self.notify = telegram_fn
        self._states: dict[str, SLOState] = {}
        self._load_from_redis()

    def _get_state(self, agent: str) -> SLOState:
        if agent not in self._states:
            self._states[agent] = SLOState(agent=agent)
        return self._states[agent]

    def record_event(
        self,
        agent: str,
        event_type: str,
        latency_ms: Optional[float] = None,
    ) -> None:
        state = self._get_state(agent)
        state.total_events += 1
        ts = time.time()

        etype = (
            EventType(event_type)
            if event_type in EventType._value2member_map_
            else EventType.ERROR
        )

        if etype == EventType.SUCCESS:
            state.last_success_ts = ts
            if state._current_down_start is not None:
                state.downtime_periods.append((state._current_down_start, ts))
                state._current_down_start = None
        elif etype in (EventType.ERROR, EventType.TIMEOUT):
            state.error_events += 1
            state.last_error_ts = ts
            if etype == EventType.TIMEOUT:
                state.timeout_events += 1
            if state._current_down_start is None:
                state._current_down_start = ts

        if latency_ms is not None:
            state.latencies_ms.append(latency_ms)
            if len(state.latencies_ms) > 1000:
                state.latencies_ms = state.latencies_ms[-1000:]

        self._check_breach(agent, state)
        self._persist(agent, state)

    def _check_breach(self, agent: str, state: SLOState) -> None:
        slo = AGENT_SLOS.get(agent, AGENT_SLOS["_default"])
        alerts: list[str] = []

        if state.uptime_pct < slo["uptime_pct"] and state.total_events > 10:
            budget_consumed = (
                round(
                    (slo["uptime_pct"] - state.uptime_pct) / (100 - slo["uptime_pct"]) * 100,
                    1,
                )
                if slo["uptime_pct"] < 100
                else 100.0
            )
            alerts.append(
                f"UPTIME BREACH: {agent} uptime={state.uptime_pct}% "
                f"(SLO={slo['uptime_pct']}%) — budget {budget_consumed}%"
            )

        if state.error_rate_pct > slo["error_rate_max"] and state.total_events > 20:
            alerts.append(
                f"ERROR RATE BREACH: {agent} error_rate={state.error_rate_pct}% "
                f"(max={slo['error_rate_max']}%) — {state.error_events}/{state.total_events}"
            )

        p95 = state.p95_latency_ms
        if p95 and p95 > slo["latency_p95_ms"] and len(state.latencies_ms) > 20:
            alerts.append(
                f"LATENCY BREACH: {agent} p95={p95:.0f}ms (SLO={slo['latency_p95_ms']}ms)"
            )

        for alert in alerts:
            logger.warning("SLO breach: %s", alert)
            self._push_alert(agent, alert)

    def _push_alert(self, agent: str, message: str) -> None:
        if self.redis:
            try:
                alert = json.dumps(
                    {
                        "ts": time.time(),
                        "agent": agent,
                        "message": message,
                        "type": "slo_breach",
                    }
                )
                self.redis.lpush("kernell:slo:alerts:queue", alert)
                self.redis.ltrim("kernell:slo:alerts:queue", 0, 199)
            except Exception as e:
                logger.error("Redis push alert error: %s", e)

        if self.notify:
            try:
                self.notify(f"SLO Breach\n{message}")
            except Exception:
                pass

    def _persist(self, agent: str, state: SLOState) -> None:
        if not self.redis:
            return
        try:
            key = f"kernell:slo:{agent}:current"
            self.redis.setex(key, 3600, json.dumps(state.to_dict()))
        except Exception as e:
            logger.error("SLO persist error: %s", e)

    def _load_from_redis(self) -> None:
        if not self.redis:
            return
        try:
            for key in self.redis.scan_iter("kernell:slo:*:current"):
                raw = self.redis.get(key)
                if not raw:
                    continue
                d = json.loads(raw)
                agent = d.get("agent")
                if not agent:
                    continue
                self._states[agent] = SLOState(
                    agent=agent,
                    window_start=float(d.get("window_start", time.time())),
                    total_events=int(d.get("total_events", 0)),
                    error_events=int(d.get("error_events", 0)),
                )
        except Exception as e:
            logger.error("SLO load error: %s", e)

    def get_system_summary(self) -> dict[str, Any]:
        summary: dict[str, Any] = {
            "ts": time.time(),
            "total_agents_monitored": len(self._states),
            "breaching_slos": [],
            "healthy": [],
            "agents": {},
        }

        for agent, state in self._states.items():
            slo = AGENT_SLOS.get(agent, AGENT_SLOS["_default"])
            is_breaching = state.uptime_pct < slo["uptime_pct"] or (
                state.error_rate_pct > slo["error_rate_max"]
            )
            d = state.to_dict()
            d["slo"] = slo
            d["breaching"] = is_breaching
            summary["agents"][agent] = d
            if is_breaching:
                summary["breaching_slos"].append(agent)
            else:
                summary["healthy"].append(agent)

        if self.redis:
            try:
                self.redis.setex(
                    "kernell:slo:system:summary", 3600, json.dumps(summary)
                )
            except Exception as e:
                logger.error("SLO summary persist error: %s", e)

        return summary

    def seed_from_operator_errors(self, error_count: int = 1954) -> None:
        state = self._get_state("operator")
        state.total_events = error_count * 5
        state.error_events = error_count
        state.window_start = time.time() - (30 * 24 * 3600)
        logger.warning(
            "Seeded operator SLO: %d errors / %d total → error_rate=%.2f%%",
            error_count,
            state.total_events,
            state.error_rate_pct,
        )
        self._persist("operator", state)
        self._check_breach("operator", state)


def publish_slo_summary(redis_client: Any) -> dict[str, Any]:
    """Entry point for Chronos task_type=slo_summary."""
    mon = SLOMonitor(redis_client=redis_client)
    return mon.get_system_summary()
