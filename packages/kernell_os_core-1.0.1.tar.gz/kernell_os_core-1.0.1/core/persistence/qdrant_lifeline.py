#!/usr/bin/env python3
"""
Kernell OS — Qdrant Lifeline: Deterministic Checkpoint System
==============================================================
Garantiza continuidad de datos en Qdrant entre sesiones.

Cada checkpoint crea un hash SHA-256 del directorio de storage,
registrándolo en Redis y en disco. Al restaurar, el hash esperado
se compara con el hash real para validar integridad.

Funciones principales:
  create_checkpoint()   — Genera hash + metadata, escribe a Redis y disco
  verify_checkpoint()   — Compara hash esperado vs hash actual
  record_session_start()— Registra arranque + dead-time detection
  record_session_end()  — Registra motivo de cierre
  detect_dead_time()    — Calcula gap entre sesiones + cross-check

Uso CLI:
  python3 qdrant_lifeline.py checkpoint --mode backup
  python3 qdrant_lifeline.py checkpoint --mode verify
  python3 qdrant_lifeline.py checkpoint --mode shutdown
  python3 qdrant_lifeline.py session --action start
  python3 qdrant_lifeline.py session --action end --reason shutdown
  python3 qdrant_lifeline.py detect-dead-time
  python3 qdrant_lifeline.py report
"""

import os
import sys
import json
import time
import hashlib
import logging
import argparse
import subprocess
from pathlib import Path
from datetime import datetime, timezone
from typing import Optional

logger = logging.getLogger("kernell.qdrant.lifeline")

# ── Paths ──────────────────────────────────────────────────────────────
KERNELL_ROOT = Path(os.getenv("KERNELL_ROOT", "/home/anny/kernell-os"))
QDRANT_RAM = Path("/mnt/kernell_ram/qdrant")
QDRANT_DISK = KERNELL_ROOT / "data" / "qdrant_persistent"
CHECKPOINT_FILE = KERNELL_ROOT / "data" / "qdrant_lifeline_checkpoint.json"
QDRANT_URL = os.getenv("QDRANT_URL", "http://localhost:6333")

# ── Redis Keys ─────────────────────────────────────────────────────────
REDIS_PREFIX = "kernell:qdrant:lifeline"
KEY_CHECKPOINT     = f"{REDIS_PREFIX}:checkpoint"
KEY_SESSION_START  = f"{REDIS_PREFIX}:session_start"
KEY_SESSION_END    = f"{REDIS_PREFIX}:session_end"
KEY_HISTORY        = f"{REDIS_PREFIX}:history"
KEY_DEAD_INTERVALS = f"{REDIS_PREFIX}:dead_intervals"

HISTORY_MAX = 100


# ═══════════════════════════════════════════════════════════════════════
# UTILIDADES
# ═══════════════════════════════════════════════════════════════════════

def _get_redis():
    """Conexión Redis segura con timeout."""
    import redis as redis_lib
    return redis_lib.Redis(
        host=os.getenv("REDIS_HOST", "127.0.0.1"),
        port=int(os.getenv("REDIS_PORT", "6380")),
        password=os.getenv("REDIS_PASSWORD"),
        decode_responses=True,
        socket_connect_timeout=3,
        socket_timeout=5,
    )


def _iso_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _hash_directory(dirpath: Path) -> str:
    """
    Hash SHA-256 determinístico de un directorio.
    Ordena archivos alfabéticamente, hashea nombre + tamaño + mtime (int).
    NO lee contenido completo (sería lento en 1.3GB) — usa metadata.
    """
    h = hashlib.sha256()
    if not dirpath.exists():
        return "EMPTY_" + hashlib.sha256(b"empty").hexdigest()[:16]

    file_entries = []
    for f in sorted(dirpath.rglob("*")):
        if f.is_file():
            try:
                stat = f.stat()
                entry = f"{f.relative_to(dirpath)}:{stat.st_size}:{int(stat.st_mtime)}"
                file_entries.append(entry)
            except OSError:
                continue

    for entry in file_entries:
        h.update(entry.encode("utf-8"))

    return h.hexdigest()


def _count_vectors() -> dict:
    """Consulta Qdrant para contar vectores por colección."""
    import urllib.request
    result = {}
    try:
        req = urllib.request.Request(
            f"{QDRANT_URL}/collections",
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=3) as resp:
            data = json.loads(resp.read())

        for col in data.get("result", {}).get("collections", []):
            name = col["name"]
            try:
                req2 = urllib.request.Request(
                    f"{QDRANT_URL}/collections/{name}",
                    headers={"Content-Type": "application/json"},
                )
                with urllib.request.urlopen(req2, timeout=3) as resp2:
                    col_data = json.loads(resp2.read())
                    info = col_data.get("result", {})
                    result[name] = {
                        "vectors_count": info.get("vectors_count", 0),
                        "points_count": info.get("points_count", 0),
                        "status": info.get("status", "unknown"),
                    }
            except Exception:
                result[name] = {"vectors_count": -1, "status": "unreachable"}

    except Exception as e:
        logger.warning(f"Cannot reach Qdrant for vector count: {e}")

    return result


def _dir_size_bytes(dirpath: Path) -> int:
    """Tamaño total del directorio en bytes."""
    total = 0
    try:
        for f in dirpath.rglob("*"):
            if f.is_file():
                total += f.stat().st_size
    except OSError:
        pass
    return total


# ═══════════════════════════════════════════════════════════════════════
# CHECKPOINT: Crear / Verificar
# ═══════════════════════════════════════════════════════════════════════

def create_checkpoint(
    source_dir: Optional[Path] = None,
    reason: str = "manual",
) -> dict:
    """
    Crea un checkpoint determinístico del estado actual de Qdrant.
    Escribe el resultado a Redis + archivo en disco.
    """
    source = source_dir or QDRANT_RAM
    if not source.exists():
        source = QDRANT_DISK  # fallback

    logger.info(f"Creating checkpoint from {source} (reason={reason})")

    dir_hash = _hash_directory(source)
    size_bytes = _dir_size_bytes(source)
    collections = _count_vectors()

    checkpoint = {
        "hash": dir_hash,
        "timestamp": time.time(),
        "ts_iso": _iso_now(),
        "source_dir": str(source),
        "reason": reason,
        "size_bytes": size_bytes,
        "size_mb": round(size_bytes / (1024 * 1024), 2),
        "collections": collections,
        "collection_count": len(collections),
        "total_vectors": sum(
            c.get("vectors_count", 0) for c in collections.values()
            if c.get("vectors_count", -1) >= 0
        ),
        "hostname": os.uname().nodename,
    }

    # Escribir a disco (always)
    try:
        CHECKPOINT_FILE.parent.mkdir(parents=True, exist_ok=True)
        with open(CHECKPOINT_FILE, "w") as f:
            json.dump(checkpoint, f, indent=2)
        logger.info(f"Checkpoint saved to disk: {CHECKPOINT_FILE}")
    except Exception as e:
        logger.error(f"Failed to write checkpoint to disk: {e}")

    # Escribir a Redis
    try:
        r = _get_redis()
        r.set(KEY_CHECKPOINT, json.dumps(checkpoint), ex=86400 * 7)
        r.lpush(KEY_HISTORY, json.dumps(checkpoint))
        r.ltrim(KEY_HISTORY, 0, HISTORY_MAX - 1)
        logger.info(f"Checkpoint saved to Redis: hash={dir_hash[:16]}...")
    except Exception as e:
        logger.warning(f"Failed to write checkpoint to Redis: {e}")

    return checkpoint


def verify_checkpoint(target_dir: Optional[Path] = None) -> dict:
    """
    Verifica integridad: compara hash actual con el último checkpoint.
    Retorna {valid, expected_hash, actual_hash, details}.
    """
    target = target_dir or QDRANT_RAM

    # Leer checkpoint esperado
    expected = None
    try:
        r = _get_redis()
        raw = r.get(KEY_CHECKPOINT)
        if raw:
            expected = json.loads(raw)
    except Exception:
        pass

    if not expected:
        try:
            if CHECKPOINT_FILE.exists():
                with open(CHECKPOINT_FILE) as f:
                    expected = json.load(f)
        except Exception:
            pass

    if not expected:
        return {
            "valid": None,
            "reason": "no_previous_checkpoint",
            "detail": "First boot or checkpoint file missing — creating baseline",
        }

    # Hash actual
    actual_hash = _hash_directory(target)
    expected_hash = expected.get("hash", "")

    result = {
        "valid": actual_hash == expected_hash,
        "expected_hash": expected_hash[:16] + "...",
        "actual_hash": actual_hash[:16] + "...",
        "expected_hash_full": expected_hash,
        "actual_hash_full": actual_hash,
        "checkpoint_age_seconds": time.time() - expected.get("timestamp", 0),
        "checkpoint_reason": expected.get("reason", "unknown"),
        "verified_at": _iso_now(),
    }

    if result["valid"]:
        logger.info("✅ Checkpoint VERIFIED — data integrity confirmed")
    else:
        logger.warning(
            f"⚠️ Checkpoint MISMATCH — expected={expected_hash[:16]} "
            f"actual={actual_hash[:16]}"
        )

    return result


# ═══════════════════════════════════════════════════════════════════════
# SESSION TRACKING
# ═══════════════════════════════════════════════════════════════════════

def record_session_start() -> dict:
    """
    Registra el inicio de una sesión Qdrant.
    Detecta dead-time desde la última sesión.
    """
    now = time.time()
    session = {
        "timestamp": now,
        "ts_iso": _iso_now(),
        "hostname": os.uname().nodename,
        "pid": os.getpid(),
    }

    # Leer último checkpoint para hash esperado
    try:
        if CHECKPOINT_FILE.exists():
            with open(CHECKPOINT_FILE) as f:
                cp = json.load(f)
                session["expected_hash"] = cp.get("hash", "")
                session["checkpoint_age_seconds"] = now - cp.get("timestamp", 0)
    except Exception:
        session["expected_hash"] = ""

    # Detectar dead time
    dead_time = detect_dead_time()
    session["dead_time"] = dead_time

    try:
        r = _get_redis()
        r.set(KEY_SESSION_START, json.dumps(session), ex=86400 * 7)
        logger.info(f"Session START recorded. Dead time: {dead_time.get('gap_seconds', '?')}s")
    except Exception as e:
        logger.warning(f"Failed to record session start in Redis: {e}")

    return session


def record_session_end(reason: str = "shutdown") -> dict:
    """
    Registra el fin de una sesión Qdrant.
    Razones válidas: shutdown, reboot, sigterm, emergency, crash_detected
    """
    # Crear checkpoint final antes de registrar
    checkpoint = create_checkpoint(reason=f"session_end_{reason}")

    session_end = {
        "timestamp": time.time(),
        "ts_iso": _iso_now(),
        "reason": reason,
        "hash_at_close": checkpoint.get("hash", ""),
        "size_mb": checkpoint.get("size_mb", 0),
        "total_vectors": checkpoint.get("total_vectors", 0),
        "hostname": os.uname().nodename,
    }

    try:
        r = _get_redis()
        r.set(KEY_SESSION_END, json.dumps(session_end), ex=86400 * 30)
        logger.info(f"Session END recorded: reason={reason}")
    except Exception as e:
        logger.warning(f"Failed to record session end in Redis: {e}")

    # También salvar a disco (Redis puede no estar disponible al arrancar)
    try:
        end_file = KERNELL_ROOT / "data" / "qdrant_lifeline_session_end.json"
        with open(end_file, "w") as f:
            json.dump(session_end, f, indent=2)
    except Exception:
        pass

    return session_end


# ═══════════════════════════════════════════════════════════════════════
# DEAD TIME DETECTION
# ═══════════════════════════════════════════════════════════════════════

def detect_dead_time() -> dict:
    """
    Calcula el gap entre la última sesión y el arranque actual.
    Cross-referencia con systemd journal para clasificar el motivo.
    """
    now = time.time()
    result = {
        "gap_seconds": None,
        "gap_human": "unknown",
        "last_session_end": None,
        "classification": "unknown",
        "detected_at": _iso_now(),
    }

    # Buscar último session_end en Redis
    last_end = None
    try:
        r = _get_redis()
        raw = r.get(KEY_SESSION_END)
        if raw:
            last_end = json.loads(raw)
    except Exception:
        pass

    # Fallback a disco
    if not last_end:
        end_file = KERNELL_ROOT / "data" / "qdrant_lifeline_session_end.json"
        try:
            if end_file.exists():
                with open(end_file) as f:
                    last_end = json.load(f)
        except Exception:
            pass

    if not last_end:
        result["classification"] = "first_boot"
        result["gap_human"] = "No previous session found — first boot or data wiped"
        return result

    last_ts = last_end.get("timestamp", 0)
    gap = now - last_ts
    result["gap_seconds"] = round(gap, 1)
    result["last_session_end"] = last_end

    # Clasificar el gap
    if gap < 120:
        result["classification"] = "quick_restart"
        result["gap_human"] = f"Quick restart ({gap:.0f}s)"
    elif gap < 3600:
        minutes = gap / 60
        result["classification"] = "short_downtime"
        result["gap_human"] = f"Short downtime ({minutes:.1f} min)"
    elif gap < 86400:
        hours = gap / 3600
        result["classification"] = "normal_downtime"
        result["gap_human"] = f"Normal downtime ({hours:.1f} hours)"
    else:
        days = gap / 86400
        result["classification"] = "extended_downtime"
        result["gap_human"] = f"Extended downtime ({days:.1f} days)"

    # Cross-check: verificar si Qdrant tuvo una caída no programada
    last_reason = last_end.get("reason", "unknown")
    if last_reason in ("shutdown", "reboot"):
        result["clean_shutdown"] = True
    elif last_reason == "sigterm":
        result["clean_shutdown"] = True
    else:
        result["clean_shutdown"] = False
        result["classification"] = f"possible_crash ({last_reason})"

    # Cross-check con journalctl (últimas líneas de qdrant.service)
    try:
        proc = subprocess.run(
            ["journalctl", "-u", "qdrant.service", "-n", "5", "--no-pager",
             "-o", "short-iso", "--since", f"-{int(gap)+60}s"],
            capture_output=True, text=True, timeout=5,
        )
        if proc.returncode == 0:
            result["journal_tail"] = proc.stdout.strip().split("\n")[-3:]
    except Exception:
        pass

    # Registrar el intervalo
    try:
        r = _get_redis()
        interval = {
            "start": last_ts,
            "end": now,
            "gap_seconds": round(gap, 1),
            "classification": result["classification"],
            "last_reason": last_reason,
            "ts_iso": _iso_now(),
        }
        r.lpush(KEY_DEAD_INTERVALS, json.dumps(interval))
        r.ltrim(KEY_DEAD_INTERVALS, 0, 49)
    except Exception:
        pass

    return result


# ═══════════════════════════════════════════════════════════════════════
# REPORT
# ═══════════════════════════════════════════════════════════════════════

def get_continuity_report() -> dict:
    """Reporte completo para dashboard / Telegram."""
    report = {
        "generated_at": _iso_now(),
        "qdrant_url": QDRANT_URL,
        "ramdisk_path": str(QDRANT_RAM),
        "disk_path": str(QDRANT_DISK),
    }

    # Current checkpoint
    try:
        if CHECKPOINT_FILE.exists():
            with open(CHECKPOINT_FILE) as f:
                report["last_checkpoint"] = json.load(f)
    except Exception:
        report["last_checkpoint"] = None

    # Verification
    report["verification"] = verify_checkpoint()

    # Session info
    try:
        r = _get_redis()
        raw_start = r.get(KEY_SESSION_START)
        raw_end = r.get(KEY_SESSION_END)
        report["current_session"] = json.loads(raw_start) if raw_start else None
        report["last_session_end"] = json.loads(raw_end) if raw_end else None

        # History count
        report["checkpoint_history_count"] = r.llen(KEY_HISTORY)
        report["dead_intervals_count"] = r.llen(KEY_DEAD_INTERVALS)
    except Exception as e:
        report["redis_error"] = str(e)

    # Filesystem status
    report["ramdisk_exists"] = QDRANT_RAM.exists()
    report["disk_backup_exists"] = QDRANT_DISK.exists()
    if QDRANT_RAM.exists():
        report["ramdisk_size_mb"] = round(_dir_size_bytes(QDRANT_RAM) / (1024 * 1024), 2)
    if QDRANT_DISK.exists():
        report["disk_size_mb"] = round(_dir_size_bytes(QDRANT_DISK) / (1024 * 1024), 2)

    return report


# ═══════════════════════════════════════════════════════════════════════
# CLI
# ═══════════════════════════════════════════════════════════════════════

def main():
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [LIFELINE] %(message)s",
        datefmt="%H:%M:%S",
    )

    parser = argparse.ArgumentParser(description="Qdrant Lifeline — Checkpoint System")
    sub = parser.add_subparsers(dest="command")

    # checkpoint
    cp = sub.add_parser("checkpoint", help="Create or verify a checkpoint")
    cp.add_argument("--mode", choices=["backup", "verify", "shutdown"],
                     required=True, help="Checkpoint mode")

    # session
    ss = sub.add_parser("session", help="Record session start/end")
    ss.add_argument("--action", choices=["start", "end"], required=True)
    ss.add_argument("--reason", default="shutdown",
                     help="Reason for session end")

    # detect-dead-time
    sub.add_parser("detect-dead-time", help="Detect and classify dead time")

    # report
    sub.add_parser("report", help="Full continuity report")

    args = parser.parse_args()

    if args.command == "checkpoint":
        if args.mode == "backup":
            result = create_checkpoint(reason="backup")
            print(json.dumps(result, indent=2))
        elif args.mode == "verify":
            result = verify_checkpoint()
            print(json.dumps(result, indent=2))
            if result.get("valid") is False:
                sys.exit(1)
        elif args.mode == "shutdown":
            result = record_session_end(reason="shutdown")
            print(json.dumps(result, indent=2))

    elif args.command == "session":
        if args.action == "start":
            result = record_session_start()
            print(json.dumps(result, indent=2))
        elif args.action == "end":
            result = record_session_end(reason=args.reason)
            print(json.dumps(result, indent=2))

    elif args.command == "detect-dead-time":
        result = detect_dead_time()
        print(json.dumps(result, indent=2))

    elif args.command == "report":
        result = get_continuity_report()
        print(json.dumps(result, indent=2))

    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
