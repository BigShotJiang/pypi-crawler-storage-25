# core/persistence — Qdrant Lifeline & Deterministic Persistence
