#!/usr/bin/env python3
"""
Kernell OS — Qdrant Deterministic Memory Config
================================================
Gestiona operaciones de memoria de forma determinístca:
  - Orden de guardado/restauración determinístico (alfabético)
  - Validación de espacio antes de escribir
  - Circuit breaker durante operaciones críticas
  - Configuración de Qdrant optimizada para RAMDisk

Uso:
  from core.persistence.qdrant_memory_config import QdrantMemoryConfig
  config = QdrantMemoryConfig()
  config.pre_save_validate()
  config.freeze_writes()
  # ... realizar guardado ...
  config.unfreeze_writes()
"""

import os
import json
import time
import shutil
import logging
from pathlib import Path
from typing import Optional

logger = logging.getLogger("kernell.qdrant.memory_config")

KERNELL_ROOT = Path(os.getenv("KERNELL_ROOT", "/home/anny/kernell-os"))
QDRANT_RAM = Path("/mnt/kernell_ram/qdrant")
QDRANT_DISK = KERNELL_ROOT / "data" / "qdrant_persistent"
QDRANT_URL = os.getenv("QDRANT_URL", "http://localhost:6333")


class QdrantMemoryConfig:
    """
    Configuración determinística de memoria para Qdrant.
    Garantiza que las operaciones de save/restore son
    repetibles, ordenadas, y con validación previa.
    """

    # Espacio mínimo requerido en disco para backup (100MB)
    MIN_DISK_SPACE_BYTES = 100 * 1024 * 1024
    # Espacio mínimo en RAMDisk para operaciones (200MB)
    MIN_RAM_SPACE_BYTES = 200 * 1024 * 1024
    # Orden de colecciones (determinístico, alfabético)
    COLLECTION_PRIORITY = [
        "kernell_episodes",
        "kernell_fusion",
        "kernell_interactions",
        "kernell_knowledge",
        "kernell_memory",
        "kernell_skills",
    ]

    def __init__(self):
        self._frozen = False
        self._freeze_file = KERNELL_ROOT / "data" / ".qdrant_write_freeze"

    # ═══════════════════════════════════════════════════════════════════
    # PRE-SAVE VALIDATION
    # ═══════════════════════════════════════════════════════════════════

    def pre_save_validate(self) -> dict:
        """
        Validación completa antes de operación de guardado.
        Retorna {valid, checks} — si valid=False, NO proceder con save.
        """
        checks = {}

        # 1. ¿Existe el directorio RAMDisk?
        checks["ramdisk_exists"] = QDRANT_RAM.exists()

        # 2. ¿Hay espacio suficiente en disco?
        try:
            disk_usage = shutil.disk_usage(QDRANT_DISK.parent)
            checks["disk_free_mb"] = round(disk_usage.free / (1024 * 1024), 1)
            checks["disk_space_ok"] = disk_usage.free > self.MIN_DISK_SPACE_BYTES
        except Exception as e:
            checks["disk_space_ok"] = False
            checks["disk_error"] = str(e)

        # 3. ¿Hay espacio suficiente en RAMDisk?
        if QDRANT_RAM.exists():
            try:
                ram_usage = shutil.disk_usage(QDRANT_RAM)
                checks["ram_free_mb"] = round(ram_usage.free / (1024 * 1024), 1)
                checks["ram_space_ok"] = ram_usage.free > self.MIN_RAM_SPACE_BYTES
            except Exception as e:
                checks["ram_space_ok"] = False
                checks["ram_error"] = str(e)

        # 4. ¿Qdrant está corriendo?
        checks["qdrant_alive"] = self._is_qdrant_alive()

        # 5. ¿Hay colecciones?
        collections = self._list_collections()
        checks["collection_count"] = len(collections)
        checks["collections"] = collections

        # Resultado: válido solo si TODO pasa
        valid = all([
            checks.get("ramdisk_exists", False),
            checks.get("disk_space_ok", False),
            checks.get("qdrant_alive", False),
            checks.get("collection_count", 0) > 0,
        ])

        result = {"valid": valid, "checks": checks, "timestamp": time.time()}

        if not valid:
            logger.warning(f"Pre-save validation FAILED: {checks}")
        else:
            logger.info(f"Pre-save validation OK: {len(collections)} collections ready")

        return result

    # ═══════════════════════════════════════════════════════════════════
    # CIRCUIT BREAKER (Write Freeze)
    # ═══════════════════════════════════════════════════════════════════

    def freeze_writes(self, reason: str = "backup_in_progress") -> bool:
        """
        Activa circuit breaker: señaliza que no se deben hacer escrituras.
        Los agentes que chequeen is_frozen() deben pausar commits.
        """
        try:
            self._freeze_file.parent.mkdir(parents=True, exist_ok=True)
            freeze_data = {
                "frozen": True,
                "reason": reason,
                "timestamp": time.time(),
                "pid": os.getpid(),
            }
            with open(self._freeze_file, "w") as f:
                json.dump(freeze_data, f)
            self._frozen = True
            logger.info(f"Write FREEZE activated: {reason}")

            # También señalizar en Redis
            try:
                import redis as redis_lib
                r = redis_lib.Redis(
                    host=os.getenv("REDIS_HOST", "127.0.0.1"),
                    port=int(os.getenv("REDIS_PORT", "6380")),
                    password=os.getenv("REDIS_PASSWORD"),
                    decode_responses=True,
                    socket_connect_timeout=2,
                )
                r.set("kernell:qdrant:write_freeze", json.dumps(freeze_data), ex=300)
            except Exception:
                pass

            return True
        except Exception as e:
            logger.error(f"Failed to freeze writes: {e}")
            return False

    def unfreeze_writes(self) -> bool:
        """Desactiva circuit breaker: escrituras permitidas."""
        try:
            if self._freeze_file.exists():
                self._freeze_file.unlink()
            self._frozen = False
            logger.info("Write UNFREEZE — writes permitted")

            try:
                import redis as redis_lib
                r = redis_lib.Redis(
                    host=os.getenv("REDIS_HOST", "127.0.0.1"),
                    port=int(os.getenv("REDIS_PORT", "6380")),
                    password=os.getenv("REDIS_PASSWORD"),
                    decode_responses=True,
                    socket_connect_timeout=2,
                )
                r.delete("kernell:qdrant:write_freeze")
            except Exception:
                pass

            return True
        except Exception as e:
            logger.error(f"Failed to unfreeze writes: {e}")
            return False

    def is_frozen(self) -> bool:
        """Chequea si hay un freeze activo (para uso de agentes)."""
        if self._freeze_file.exists():
            try:
                with open(self._freeze_file) as f:
                    data = json.load(f)
                # Auto-expire después de 5 minutos
                if time.time() - data.get("timestamp", 0) > 300:
                    self.unfreeze_writes()
                    return False
                return True
            except Exception:
                return False
        return False

    # ═══════════════════════════════════════════════════════════════════
    # DETERMINISTIC COLLECTION ORDER
    # ═══════════════════════════════════════════════════════════════════

    def get_ordered_collections(self) -> list:
        """
        Retorna colecciones en orden determinístico (alfabético).
        Garantiza que save/restore siempre procesa en el mismo orden.
        """
        live = self._list_collections()
        # Ordenar: primero las conocidas, luego las desconocidas (también alfabéticas)
        known = [c for c in self.COLLECTION_PRIORITY if c in live]
        unknown = sorted([c for c in live if c not in self.COLLECTION_PRIORITY])
        return known + unknown

    # ═══════════════════════════════════════════════════════════════════
    # UTILIDADES INTERNAS
    # ═══════════════════════════════════════════════════════════════════

    def _is_qdrant_alive(self) -> bool:
        import urllib.request
        try:
            req = urllib.request.Request(f"{QDRANT_URL}/healthz")
            with urllib.request.urlopen(req, timeout=2):
                return True
        except Exception:
            return False

    def _list_collections(self) -> list:
        import urllib.request
        try:
            req = urllib.request.Request(
                f"{QDRANT_URL}/collections",
                headers={"Content-Type": "application/json"},
            )
            with urllib.request.urlopen(req, timeout=3) as resp:
                data = json.loads(resp.read())
            return sorted([
                c["name"] for c in data.get("result", {}).get("collections", [])
            ])
        except Exception:
            return []
