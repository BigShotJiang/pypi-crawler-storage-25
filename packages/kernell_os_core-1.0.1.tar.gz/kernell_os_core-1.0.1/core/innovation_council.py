#!/usr/bin/env python3
"""
🧪 KERNELL OS — INNOVATION COUNCIL v1.0
==========================================
Multi-LLM Committee for Experimental Evolution.

Pipeline: Discovery → Multi-LLM Panel Vote → Sandbox → Forge → MultiSign → Deploy
Every proposal, vote, sandbox result, and audit decision is logged to disk
and Redis for mathematical auditability.

Philosophy:
  "Creatividad encapsulada" — experimental ideas are welcome but NEVER
  deployed without passing through the full governance pipeline.

Integration:
  - Triggered by Chronos weekly (Sundays 2am)
  - Results displayed in Dashboard "Innovation Lab" section
  - Proposals stored in kernell:innovation:proposals
  - Audit log in /data/innovation_log/ (append-only JSON)

Blueprint XIV — Sovereign Architecture
"""

import os
import sys
import json
import time
import hashlib
import logging
from pathlib import Path
from datetime import datetime, timezone
from typing import Dict, List, Optional, Callable
from dataclasses import dataclass, field, asdict

# Add root to path
ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT))

logger = logging.getLogger("INNOVATION_COUNCIL")

# ── Directories ──────────────────────────────────────────────────────────────
LOG_DIR = Path("/data/innovation_log")
LOG_DIR.mkdir(parents=True, exist_ok=True)

# ── Constants ────────────────────────────────────────────────────────────────
PROPOSAL_TTL = 86400 * 30  # 30 days in Redis
MIN_PANEL_SCORE = 7.0      # Proposals below this score are rejected
MAX_DRIFT_POST_APPLY = 15  # Auto-rollback if drift rises > 15 points
PANEL_BENCHMARK_THRESHOLD = 7  # LLM must score >= 7/10 to join panel

DISCOVERY_SOURCES = [
    "GitHub Trending (Python/AI)",
    "Hacker News Top Stories",
    "arXiv cs.AI/cs.SE Recent",
    "Reddit r/MachineLearning",
    "Existing agent error patterns",
    "Forge engineering backlog",
]


# ── Data Models ──────────────────────────────────────────────────────────────

@dataclass
class LLMPanelist:
    """A vetted LLM model on the Innovation Council panel."""
    name: str            # e.g. "gemini-2.0-flash", "gpt-4o", "grok-3", "claude-sonnet-4"
    provider: str        # e.g. "groq", "openai", "anthropic", "xai"
    specialty: str       # e.g. "technical_depth", "creativity", "structure", "viability"
    benchmark_score: float = 0.0  # Score from the vetting benchmark
    active: bool = True

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class PanelVote:
    """Vote from a single LLM panelist on a proposal."""
    panelist: str
    viability_score: float    # 0-10: Can this actually work?
    risk_score: float         # 0-10: How risky is this? (inverted: 10=safe, 0=dangerous)
    impact_score: float       # 0-10: How much value would this add?
    reasoning: str            # LLM's analysis
    code_suggestion: str = "" # Optional code if the LLM proposes implementation
    timestamp: str = ""

    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = datetime.now(timezone.utc).isoformat()

    @property
    def weighted_score(self) -> float:
        """Weighted average: viability 40%, impact 35%, risk 25%."""
        return (self.viability_score * 0.4 +
                self.impact_score * 0.35 +
                self.risk_score * 0.25)

    def to_dict(self) -> dict:
        d = asdict(self)
        d["weighted_score"] = round(self.weighted_score, 2)
        return d


@dataclass
class Proposal:
    """An innovation proposal with its lifecycle state."""
    id: str
    title: str
    description: str
    source: str              # Where this idea came from
    category: str            # "optimization", "new_feature", "security", "architecture"
    votes: List[Dict] = field(default_factory=list)
    status: str = "pending"  # pending → voting → scored → sandbox → approved → deployed → rejected
    panel_score: float = 0.0
    sandbox_result: Dict = field(default_factory=dict)
    forge_task_id: str = ""
    created_at: str = ""
    updated_at: str = ""

    def __post_init__(self):
        if not self.created_at:
            self.created_at = datetime.now(timezone.utc).isoformat()
        if not self.id:
            self.id = f"INNOV-{datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')}-{hashlib.md5(self.title.encode()).hexdigest()[:6].upper()}"

    def to_dict(self) -> dict:
        return asdict(self)


# ── LLM Panel ────────────────────────────────────────────────────────────────

class LLMPanel:
    """
    Executes the same evaluation prompt against N different LLM models
    and aggregates their votes into a composite score.
    
    Each panelist sees the proposal and must return a structured vote.
    Different LLMs bring different perspectives:
      - GPT-4o: Commercial viability
      - Gemini: Technical depth
      - Grok: Creative lateral thinking
      - Claude: Structure and risk analysis
    """

    EVALUATION_PROMPT = """You are a member of the Innovation Council of Kernell OS, 
an autonomous multi-agent AI system. You must evaluate this proposal for a system improvement.

PROPOSAL:
Title: {title}
Description: {description}
Source: {source}
Category: {category}

Evaluate and respond ONLY in this JSON format:
{{
  "viability_score": <0-10, how feasible is this?>,
  "risk_score": <0-10, how safe? 10=very safe, 0=very dangerous>,
  "impact_score": <0-10, how valuable for the system?>,
  "reasoning": "<2-3 sentences explaining your vote>",
  "code_suggestion": "<optional: pseudo-code or approach you'd recommend>"
}}

Be rigorous. Only ideas that genuinely improve the system should score above 7.
Consider: system stability, security implications, resource cost, and maintenance burden."""

    def __init__(self, generate_fn: Callable, redis_client=None):
        self._generate = generate_fn
        self._redis = redis_client
        self._panelists: List[LLMPanelist] = []
        self._load_panelists()

    def _load_panelists(self):
        """Load vetted panelists from Redis or defaults."""
        try:
            if self._redis:
                raw = self._redis.get("kernell:innovation:panelists")
                if raw:
                    data = json.loads(raw)
                    self._panelists = [LLMPanelist(**p) for p in data]
                    return
        except Exception:
            pass
        
        # Default panel (using the LLMs available via carousel)
        self._panelists = [
            LLMPanelist(
                name="analyst",
                provider="primary",
                specialty="technical_depth",
                benchmark_score=9.0,
            ),
            LLMPanelist(
                name="strategist",
                provider="primary",
                specialty="commercial_viability",
                benchmark_score=8.5,
            ),
            LLMPanelist(
                name="adversary",
                provider="primary",
                specialty="risk_analysis",
                benchmark_score=8.0,
            ),
        ]

    def evaluate(self, proposal: Proposal) -> List[PanelVote]:
        """
        Submit a proposal to all active panelists and collect votes.
        Uses the CognitiveEngine's multi-profile system to simulate
        different LLM perspectives.
        """
        votes = []
        
        for panelist in self._panelists:
            if not panelist.active:
                continue
                
            prompt = self.EVALUATION_PROMPT.format(
                title=proposal.title,
                description=proposal.description[:2000],
                source=proposal.source,
                category=proposal.category,
            )
            
            # Prefix with panelist specialty prompt
            specialty_prefix = {
                "technical_depth": "Focus your analysis on TECHNICAL FEASIBILITY and implementation complexity.",
                "commercial_viability": "Focus your analysis on BUSINESS VALUE and market impact.",
                "risk_analysis": "Focus your analysis on SECURITY RISKS and potential system instability.",
                "creativity": "Focus on CREATIVE ALTERNATIVES and unconventional approaches.",
            }
            prefix = specialty_prefix.get(panelist.specialty, "")
            full_prompt = f"{prefix}\n\n{prompt}" if prefix else prompt
            
            try:
                raw = self._generate(full_prompt, max_tokens=1000)
                vote = self._parse_vote(raw, panelist.name)
                if vote:
                    votes.append(vote)
                    logger.info(
                        f"🗳️ [{panelist.name}] voted: "
                        f"V={vote.viability_score} R={vote.risk_score} I={vote.impact_score} "
                        f"→ {vote.weighted_score:.1f}"
                    )
            except Exception as e:
                logger.warning(f"Panelist {panelist.name} failed to vote: {e}")
        
        return votes

    def _parse_vote(self, raw: str, panelist_name: str) -> Optional[PanelVote]:
        """Parse LLM response into a structured vote."""
        import re
        try:
            json_match = re.search(r'\{[\s\S]*"viability_score"[\s\S]*\}', raw)
            if json_match:
                data = json.loads(json_match.group())
            else:
                data = json.loads(raw)
            
            return PanelVote(
                panelist=panelist_name,
                viability_score=min(10, max(0, float(data.get("viability_score", 5)))),
                risk_score=min(10, max(0, float(data.get("risk_score", 5)))),
                impact_score=min(10, max(0, float(data.get("impact_score", 5)))),
                reasoning=str(data.get("reasoning", ""))[:500],
                code_suggestion=str(data.get("code_suggestion", ""))[:2000],
            )
        except (json.JSONDecodeError, ValueError, TypeError) as e:
            logger.warning(f"Failed to parse vote from {panelist_name}: {e}")
            return None

    def benchmark_candidate(self, generate_fn: Callable) -> float:
        """
        Run a 10-question benchmark against a candidate LLM.
        Returns score 0-10. Must score >= PANEL_BENCHMARK_THRESHOLD to join.
        """
        questions = [
            "What is the time complexity of merge sort?",
            "Explain the CAP theorem in distributed systems.",
            "What's the difference between a mutex and a semaphore?",
            "How does a circuit breaker pattern work in microservices?",
            "What is eventual consistency?",
            "Explain the SOLID principles in OOP.",
            "What is a race condition and how do you prevent it?",
            "How does Docker containerization differ from VMs?",
            "What is the purpose of a reverse proxy?",
            "Explain the difference between authentication and authorization.",
        ]
        
        correct = 0
        for q in questions:
            try:
                answer = generate_fn(f"Answer concisely: {q}", max_tokens=200)
                # Simple heuristic: if answer has >30 chars and doesn't say "I don't know"
                if len(answer) > 30 and "don't know" not in answer.lower():
                    correct += 1
            except Exception:
                pass
        
        return correct  # Out of 10


# ── Innovation Council ───────────────────────────────────────────────────────

class InnovationCouncil:
    """
    The Innovation Council orchestrates the entire experimental evolution pipeline.
    
    Flow:
      1. Discover ideas (from web, agent errors, backlog)
      2. Create Proposals
      3. Submit to LLM Panel for voting
      4. If score >= 7.0, send to Sandbox (forge_sandbox.py)
      5. If sandbox passes, route to Forge with MultiSign
      6. Monitor GSHI post-deploy, rollback if drift > 15
      
    Everything logged to disk and Redis.
    """

    REDIS_PREFIX = "kernell:innovation:"

    def __init__(self, generate_fn: Callable, redis_client=None):
        self._generate = generate_fn
        self._redis = redis_client
        self.panel = LLMPanel(generate_fn, redis_client)
        self._proposal_count = 0
        
        logger.info("🧪 Innovation Council v1.0 initialized")

    # ── Proposal Management ──────────────────────────────────────────────────

    def create_proposal(
        self,
        title: str,
        description: str,
        source: str = "manual",
        category: str = "optimization",
    ) -> Proposal:
        """Create and persist a new innovation proposal."""
        proposal = Proposal(
            id="",  # Auto-generated
            title=title,
            description=description,
            source=source,
            category=category,
        )
        proposal.status = "pending"
        self._save_proposal(proposal)
        self._log_event("proposal_created", proposal.to_dict())
        logger.info(f"📋 Proposal created: [{proposal.id}] {title}")
        return proposal

    def evaluate_proposal(self, proposal: Proposal) -> Proposal:
        """Submit proposal to the LLM Panel and compute composite score."""
        proposal.status = "voting"
        self._save_proposal(proposal)

        # Collect votes from all panelists
        votes = self.panel.evaluate(proposal)
        proposal.votes = [v.to_dict() for v in votes]

        if not votes:
            proposal.status = "rejected"
            proposal.panel_score = 0.0
            self._save_proposal(proposal)
            return proposal

        # Compute composite score (average of weighted scores)
        scores = [v.weighted_score for v in votes]
        proposal.panel_score = round(sum(scores) / len(scores), 2)
        proposal.status = "scored"
        proposal.updated_at = datetime.now(timezone.utc).isoformat()
        
        self._save_proposal(proposal)
        self._log_event("proposal_scored", {
            "id": proposal.id,
            "score": proposal.panel_score,
            "votes": len(votes),
            "individual_scores": [round(s, 2) for s in scores],
        })
        
        logger.info(
            f"📊 Proposal [{proposal.id}] scored: {proposal.panel_score:.1f}/10 "
            f"({len(votes)} votes)"
        )
        return proposal

    def process_proposal(self, proposal: Proposal) -> Dict:
        """
        Full pipeline: evaluate → sandbox (if code) → route to Forge.
        Returns the pipeline result.
        """
        # Step 1: Panel evaluation
        proposal = self.evaluate_proposal(proposal)
        
        result = {
            "proposal_id": proposal.id,
            "title": proposal.title,
            "panel_score": proposal.panel_score,
            "status": proposal.status,
            "votes": len(proposal.votes),
        }

        # Step 2: Score gate
        if proposal.panel_score < MIN_PANEL_SCORE:
            proposal.status = "rejected"
            result["status"] = "rejected"
            result["reason"] = f"Panel score {proposal.panel_score:.1f} < {MIN_PANEL_SCORE} threshold"
            self._save_proposal(proposal)
            self._log_event("proposal_rejected", result)
            logger.info(f"❌ Proposal [{proposal.id}] rejected (score too low)")
            return result

        # Step 3: If code_suggestion exists, test in sandbox
        code_suggestions = [
            v.get("code_suggestion", "")
            for v in proposal.votes
            if v.get("code_suggestion")
        ]
        
        if code_suggestions:
            best_code = max(code_suggestions, key=len)
            if len(best_code) > 50:
                sandbox_result = self._test_in_sandbox(proposal, best_code)
                proposal.sandbox_result = sandbox_result
                result["sandbox"] = sandbox_result
                
                if not sandbox_result.get("approved", False):
                    proposal.status = "sandbox_failed"
                    result["status"] = "sandbox_failed"
                    self._save_proposal(proposal)
                    self._log_event("proposal_sandbox_failed", result)
                    logger.info(f"🐳 Proposal [{proposal.id}] failed sandbox")
                    return result

        # Step 4: Route to Forge queue
        proposal.status = "approved"
        forge_task = self._route_to_forge(proposal)
        proposal.forge_task_id = forge_task.get("task_id", "")
        result["status"] = "approved"
        result["forge_task_id"] = proposal.forge_task_id
        
        self._save_proposal(proposal)
        self._log_event("proposal_approved", result)
        logger.info(f"✅ Proposal [{proposal.id}] approved → routed to Forge [{proposal.forge_task_id}]")
        
        return result

    # ── Discovery ────────────────────────────────────────────────────────────

    def discover_and_propose(self) -> List[Dict]:
        """
        Triggered by Chronos weekly. Asks the generate_fn to discover
        improvement opportunities based on system state.
        """
        results = []
        
        # Get current system context
        context = self._get_system_context()
        
        discovery_prompt = f"""You are the Innovation Discovery Engine for Kernell OS.

CURRENT SYSTEM STATE:
{json.dumps(context, indent=2, default=str)[:3000]}

DISCOVERY SOURCES TO CONSIDER:
{', '.join(DISCOVERY_SOURCES)}

Identify 2-3 CONCRETE improvement proposals for the system.
Each proposal should be experimental but achievable.

Respond in JSON:
{{
  "proposals": [
    {{
      "title": "Short title",
      "description": "Detailed description of what to improve and how",
      "source": "Where this idea comes from",
      "category": "optimization|new_feature|security|architecture",
      "estimated_effort": "hours|days|weeks"
    }}
  ]
}}

Be specific. No vague suggestions. Each proposal must be actionable."""

        try:
            raw = self._generate(discovery_prompt, max_tokens=2000)
            import re
            json_match = re.search(r'\{[\s\S]*"proposals"[\s\S]*\}', raw)
            if json_match:
                data = json.loads(json_match.group())
                for p in data.get("proposals", []):
                    proposal = self.create_proposal(
                        title=p.get("title", "Untitled"),
                        description=p.get("description", ""),
                        source=p.get("source", "discovery_engine"),
                        category=p.get("category", "optimization"),
                    )
                    result = self.process_proposal(proposal)
                    results.append(result)
        except Exception as e:
            logger.error(f"Discovery failed: {e}")
        
        # Log weekly summary
        self._log_event("weekly_discovery", {
            "proposals_generated": len(results),
            "approved": sum(1 for r in results if r.get("status") == "approved"),
            "rejected": sum(1 for r in results if r.get("status") == "rejected"),
        })
        
        return results

    # ── Internal Helpers ─────────────────────────────────────────────────────

    def _test_in_sandbox(self, proposal: Proposal, code: str) -> Dict:
        """Test code suggestion in Docker sandbox via ForgeSandbox."""
        try:
            from agents.forge.forge_sandbox import ForgeSandbox
            sandbox = ForgeSandbox(redis_client=self._redis)
            result = sandbox.test_patch(
                file_path=f"/tmp/innovation_{proposal.id}.py",
                patched_content=code,
            )
            return {
                "approved": result.approved,
                "reason": result.reason,
                "execution_time": result.execution_time,
                "tests_passed": result.tests_passed,
                "tests_failed": result.tests_failed,
            }
        except ImportError:
            logger.debug("ForgeSandbox not available — skipping sandbox test")
            return {"approved": True, "reason": "sandbox_unavailable"}
        except Exception as e:
            return {"approved": False, "reason": str(e)}

    def _route_to_forge(self, proposal: Proposal) -> Dict:
        """Push approved proposal to Forge's engineering queue."""
        task_id = f"INNOV-FORGE-{proposal.id}"
        task = {
            "task_id": task_id,
            "type": "engineering",
            "description": f"[Innovation Council] {proposal.title}: {proposal.description[:500]}",
            "source": "innovation_council",
            "panel_score": proposal.panel_score,
            "priority": "low",  # Innovation tasks are never urgent
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        
        try:
            if self._redis:
                self._redis.lpush("kernell:tasks:forge", json.dumps(task))
        except Exception as e:
            logger.error(f"Failed to route to Forge: {e}")
        
        return {"task_id": task_id}

    def _get_system_context(self) -> Dict:
        """Get current system state for discovery context."""
        context = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "mode": "STABLE",
            "drift": 0.0,
            "health": 99.9,
        }
        
        try:
            if self._redis:
                raw = self._redis.get("kernell:reality:snapshot")
                if raw:
                    snapshot = json.loads(raw)
                    context["mode"] = snapshot.get("mode", "STABLE")
                    context["drift"] = snapshot.get("drift_index", 0.0)
                    context["health"] = snapshot.get("health_score", 99.9)
                    context["agents"] = snapshot.get("agents", [])
                
                # Recent errors (inspiration for improvements)
                errors = self._redis.lrange("kernell:errors", 0, 9)
                if errors:
                    context["recent_errors"] = [
                        json.loads(e)["message"][:100] if isinstance(json.loads(e), dict)
                        else str(e)[:100]
                        for e in errors[:5]
                    ]
        except Exception:
            pass
        
        return context

    def _save_proposal(self, proposal: Proposal):
        """Persist proposal to Redis."""
        try:
            if self._redis:
                key = f"{self.REDIS_PREFIX}proposals:{proposal.id}"
                self._redis.set(key, json.dumps(proposal.to_dict()), ex=PROPOSAL_TTL)
                # Also add to the active proposals list
                self._redis.sadd(f"{self.REDIS_PREFIX}active_ids", proposal.id)
        except Exception as e:
            logger.error(f"Failed to save proposal: {e}")

    def _log_event(self, event_type: str, data: Dict):
        """
        Append-only log to disk AND Redis.
        This is the mathematical audit trail.
        """
        event = {
            "type": event_type,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "data": data,
        }
        
        # Disk log (append-only, survives Redis flushes)
        try:
            log_file = LOG_DIR / f"innovation_{datetime.now(timezone.utc).strftime('%Y%m')}.jsonl"
            with open(log_file, "a", encoding="utf-8") as f:
                f.write(json.dumps(event, default=str) + "\n")
        except Exception as e:
            logger.error(f"Disk log failed: {e}")
        
        # Redis log
        try:
            if self._redis:
                self._redis.lpush(f"{self.REDIS_PREFIX}audit_log", json.dumps(event, default=str))
                self._redis.ltrim(f"{self.REDIS_PREFIX}audit_log", 0, 999)
                # Publish for dashboard real-time updates
                self._redis.publish("kernell:innovation:events", json.dumps(event, default=str))
        except Exception:
            pass

    # ── Status & Reporting ───────────────────────────────────────────────────

    def get_status(self) -> Dict:
        """Return current Innovation Council status for Dashboard."""
        status = {
            "panelists": len(self.panel._panelists),
            "active_panelists": sum(1 for p in self.panel._panelists if p.active),
            "proposals": {"total": 0, "approved": 0, "rejected": 0, "pending": 0},
        }
        
        try:
            if self._redis:
                ids = self._redis.smembers(f"{self.REDIS_PREFIX}active_ids")
                for pid in (ids or []):
                    raw = self._redis.get(f"{self.REDIS_PREFIX}proposals:{pid}")
                    if raw:
                        p = json.loads(raw)
                        status["proposals"]["total"] += 1
                        s = p.get("status", "pending")
                        if s in ("approved", "deployed"):
                            status["proposals"]["approved"] += 1
                        elif s in ("rejected", "sandbox_failed"):
                            status["proposals"]["rejected"] += 1
                        else:
                            status["proposals"]["pending"] += 1
        except Exception:
            pass
        
        return status


# ── CLI Demo ─────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Innovation Council CLI")
    parser.add_argument("--demo", action="store_true", help="Run demo proposal")
    parser.add_argument("--status", action="store_true", help="Show council status")
    args = parser.parse_args()

    # Mock generate function for demo
    def mock_generate(prompt: str, max_tokens: int = 1000) -> str:
        return json.dumps({
            "viability_score": 8.0,
            "risk_score": 7.0,
            "impact_score": 9.0,
            "reasoning": "This is a demo vote. The proposal seems feasible and high-impact.",
            "code_suggestion": "",
        })

    try:
        import redis
        r = redis.Redis(host="localhost", port=6379, decode_responses=True)
        r.ping()
    except Exception:
        r = None

    council = InnovationCouncil(generate_fn=mock_generate, redis_client=r)

    if args.status:
        print(json.dumps(council.get_status(), indent=2))
    elif args.demo:
        proposal = council.create_proposal(
            title="Add WebSocket support for real-time dashboard",
            description="Replace polling-based dashboard updates with WebSocket connections for sub-second latency on system state changes.",
            source="demo",
            category="optimization",
        )
        result = council.process_proposal(proposal)
        print(json.dumps(result, indent=2, default=str))
    else:
        parser.print_help()
