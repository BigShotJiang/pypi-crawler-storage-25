#!/usr/bin/env python3
"""
🛡️ KERNELL OS — CAPABILITY ENFORCER v1.0
==========================================
Verifica que un agente tiene los permisos necesarios para ejecutar una acción.
Lee capabilities desde ontology.yaml. Whitelist approach:
lo que no está explícitamente permitido, está prohibido.

Uso:
    from core.capability_enforcer import can_agent_do, requires_multisign

    allowed, reason = can_agent_do("forge", "code:patch_apply")
    if not allowed:
        print(f"❌ Acción bloqueada: {reason}")

    if requires_multisign("forge", "code:deploy"):
        # Iniciar flujo MultiSign
        pass
"""

import os
import yaml
from pathlib import Path
from typing import Tuple

KERNELL_ROOT = Path(os.getenv("KERNELL_ROOT", "/home/anny/kernell-os"))
ONTOLOGY_PATH = KERNELL_ROOT / "core" / "ontology.yaml"

# Cache de la ontología
_ontology_cache = None
_cache_mtime = 0.0


def _load_ontology() -> dict:
    """Carga ontology.yaml con cache basado en mtime."""
    global _ontology_cache, _cache_mtime
    
    if not ONTOLOGY_PATH.exists():
        return {}
    
    current_mtime = ONTOLOGY_PATH.stat().st_mtime
    if _ontology_cache is not None and current_mtime == _cache_mtime:
        return _ontology_cache
    
    try:
        with open(ONTOLOGY_PATH, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
        _ontology_cache = data
        _cache_mtime = current_mtime
        return data
    except Exception as e:
        print(f"⚠️ [CapabilityEnforcer] Error cargando ontología: {e}")
        return {}


def get_agent_capabilities(agent_id: str) -> dict:
    """Retorna las capabilities definidas para un agente en ontology.yaml."""
    data = _load_ontology()
    agents = data.get("agents", {})
    agent = agents.get(agent_id, {})
    return agent.get("capabilities", {})


def can_agent_do(agent_id: str, action: str) -> Tuple[bool, str]:
    """
    Verifica si un agente puede ejecutar una acción específica.
    
    Formato de action: "dominio:acción" (ej: "code:patch_apply", "service:restart")
    
    Returns: (allowed: bool, reason: str)
    """
    data = _load_ontology()
    agents = data.get("agents", {})
    
    if agent_id not in agents:
        return False, f"Agente '{agent_id}' no registrado en ontología"
    
    agent = agents[agent_id]
    
    # Verificar si el agente está activo
    if agent.get("status") != "active":
        return False, f"Agente '{agent_id}' no está activo (status: {agent.get('status')})"
    
    # Obtener capabilities
    capabilities = agent.get("capabilities", {})
    allowed_actions = capabilities.get("allowed_actions", [])
    
    # Si no hay capabilities definidas, usar permisos basados en rol
    if not capabilities and not allowed_actions:
        # Fallback: permitir basándose en el rol del agente
        role = agent.get("role", "")
        return _role_based_permission(agent_id, role, action)
    
    # Verificar si la acción está en la whitelist
    if action in allowed_actions:
        return True, f"Acción '{action}' permitida por whitelist de capabilities"
    
    # Verificar por wildcard de dominio (ej: "code:*")
    domain = action.split(":")[0] if ":" in action else action
    if f"{domain}:*" in allowed_actions:
        return True, f"Acción '{action}' permitida por wildcard '{domain}:*'"
    
    return False, f"Acción '{action}' no está en la whitelist de '{agent_id}'"


def _role_based_permission(agent_id: str, role: str, action: str) -> Tuple[bool, str]:
    """Permisos por defecto basados en el rol cuando no hay capabilities explícitas."""
    
    # Roles con permisos amplios
    wide_roles = {
        "reality_governor": ["system:*", "agent:*", "snapshot:*"],
        "security_auditor": ["audit:*", "security:*", "scan:*"],
        "code_operator": ["code:*", "forge:*"],
        "system_healer": ["fixer:*", "service:*"],
        "intelligence": ["intel:*", "osint:*", "search:*"],
    }
    
    role_lower = role.lower().replace(" ", "_")
    allowed_patterns = wide_roles.get(role_lower, [])
    
    domain = action.split(":")[0] if ":" in action else action
    
    for pattern in allowed_patterns:
        p_domain = pattern.split(":")[0]
        if p_domain == domain:
            return True, f"Permitido por rol '{role}' (patrón: {pattern})"
    
    # Default: permitir acciones de lectura, bloquear escritura
    if any(action.endswith(suffix) for suffix in [":read", ":get", ":list", ":status"]):
        return True, f"Acción de lectura '{action}' permitida por defecto"
    
    return False, f"Sin capabilities definidas y rol '{role}' no tiene permisos para '{action}'"


def requires_multisign(agent_id: str, action: str) -> bool:
    """Determina si una acción requiere firma múltiple (MultiSign Protocol)."""
    data = _load_ontology()
    agents = data.get("agents", {})
    agent = agents.get(agent_id, {})
    
    capabilities = agent.get("capabilities", {})
    
    # Si el agente tiene requires_multisign, verificar
    if capabilities.get("requires_multisign"):
        return True
    
    # Acciones que siempre requieren multisign
    critical_actions = [
        "code:deploy",
        "code:patch_apply",
        "service:stop",
        "agent:kill",
        "economy:trade",
        "infra:redis_flush",
    ]
    
    return action in critical_actions


def get_agent_risk_level(agent_id: str) -> str:
    """Retorna el nivel de riesgo de las acciones de un agente."""
    data = _load_ontology()
    agents = data.get("agents", {})
    agent = agents.get(agent_id, {})
    capabilities = agent.get("capabilities", {})
    return capabilities.get("risk_level", "medium")


# ── CLI ───────────────────────────────────────────────────────────────────────

def main():
    import argparse
    parser = argparse.ArgumentParser(description="Kernell OS Capability Enforcer")
    parser.add_argument("--check", nargs=2, metavar=("AGENT", "ACTION"),
                       help="Verificar si un agente puede ejecutar una acción")
    parser.add_argument("--agent", metavar="AGENT_ID",
                       help="Mostrar capabilities de un agente")
    parser.add_argument("--all", action="store_true",
                       help="Listar todas las capabilities")
    args = parser.parse_args()

    if args.check:
        agent_id, action = args.check
        allowed, reason = can_agent_do(agent_id, action)
        ms = requires_multisign(agent_id, action)
        icon = "✅" if allowed else "❌"
        print(f"{icon} {agent_id} → {action}")
        print(f"   Resultado: {'PERMITIDO' if allowed else 'BLOQUEADO'}")
        print(f"   Razón: {reason}")
        if ms:
            print(f"   ⚠️ Requiere MultiSign")

    elif args.agent:
        caps = get_agent_capabilities(args.agent)
        if caps:
            print(f"\n🛡️ Capabilities de '{args.agent}':")
            for k, v in caps.items():
                print(f"   {k}: {v}")
        else:
            print(f"⚠️ Sin capabilities definidas para '{args.agent}'")

    elif args.all:
        data = _load_ontology()
        agents = data.get("agents", {})
        print("\n🛡️ CAPABILITY ENFORCER — Registro Completo\n")
        for agent_id, profile in sorted(agents.items()):
            caps = profile.get("capabilities", {})
            status = profile.get("status", "unknown")
            icon = "🟢" if status == "active" else "⚫"
            print(f"{icon} {agent_id:<20} status={status}")
            if caps:
                for k, v in caps.items():
                    print(f"   ├── {k}: {v}")
            else:
                print(f"   └── (sin capabilities explícitas — permisos por rol)")
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
