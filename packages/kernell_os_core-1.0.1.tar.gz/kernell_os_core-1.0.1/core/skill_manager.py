"""
core/skill_manager.py
═════════════════════
Skill Manager V2 — Central Security Gatekeeper + Frontmatter Parser.

Original:   Hash verification and manifest validation.
V2 (NEW):   SKILL.md frontmatter parser with tool ACL, path triggers, and lifecycle hooks.

V2 Features:
  - `allowed-tools`: Limits which tools a skill can use (integrates with ToolRoom ACL)
  - `paths`: Conditional activation — skill only appears when working with matching files
  - `when_to_use`: Semantic hint for agents to know when to invoke
  - `context`: Execution mode — "fork" (isolated subprocess) or "inline" (default)
  - `hooks`: Pre/post lifecycle hooks with shell commands
  - `shell`: Shell override for hook execution

Usage:
    from core.skill_manager import SkillManager, SkillFrontmatterLoader

    # Legacy manifest-based loading
    mgr = SkillManager(redis_client)
    mgr.scan_all_skills()

    # NEW: SKILL.md frontmatter loading
    loader = SkillFrontmatterLoader()
    skills = loader.load_skills_dir(Path(".agent/skills"))
    for skill in skills:
        print(f"{skill.name}: {skill.description}")
        print(f"  Tools: {skill.allowed_tools}")
        print(f"  Paths: {skill.paths}")
        print(f"  When:  {skill.when_to_use}")
"""

import hashlib
import json
import logging
import re
import subprocess
from pathlib import Path
from typing import Dict, List, Optional
from dataclasses import dataclass, field

logger = logging.getLogger("SKILL_MANAGER")


# ══════════════════════════════════════════════════════════════════════════════
# V2: SKILL.MD FRONTMATTER PARSER
# Parses SKILL.md YAML frontmatter for structured skill definitions.
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class SkillHooks:
    """Lifecycle hooks for a skill (pre/post tool call)."""
    pre_tool_call: List[str] = field(default_factory=list)   # Shell commands
    post_tool_call: List[str] = field(default_factory=list)  # Shell commands


@dataclass
class SkillConfig:
    """
    Structured representation of a SKILL.md frontmatter.
    Supports tool ACLs, path-based activation, and lifecycle hooks.
    """
    name: str
    description: str = ""
    content: str = ""            # The markdown body (instructions)
    source_path: str = ""        # Absolute path to the SKILL.md file

    # V2 fields (structured skill metadata)
    allowed_tools: List[str] = field(default_factory=list)
    paths: List[str] = field(default_factory=list)
    when_to_use: str = ""
    context: str = "inline"      # "inline" | "fork"
    shell: str = "bash"
    hooks: SkillHooks = field(default_factory=SkillHooks)

    # Kernell OS extensions
    privilege_level: int = 3     # ToolRoom privilege level required
    agent_whitelist: List[str] = field(default_factory=list)  # Which agents can use this

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "description": self.description,
            "source_path": self.source_path,
            "allowed_tools": self.allowed_tools,
            "paths": self.paths,
            "when_to_use": self.when_to_use,
            "context": self.context,
            "shell": self.shell,
            "hooks": {
                "pre_tool_call": self.hooks.pre_tool_call,
                "post_tool_call": self.hooks.post_tool_call,
            },
            "privilege_level": self.privilege_level,
            "agent_whitelist": self.agent_whitelist,
        }

    def matches_path(self, file_path: str) -> bool:
        """Check if this skill should activate for a given file path."""
        if not self.paths:
            return True  # No path restriction = always active

        import fnmatch
        for pattern in self.paths:
            if fnmatch.fnmatch(file_path, pattern):
                return True
        return False

    def is_tool_allowed(self, tool_name: str) -> bool:
        """Check if a specific tool is allowed by this skill."""
        if not self.allowed_tools:
            return True  # No restriction = all tools allowed

        for allowed in self.allowed_tools:
            # Support wildcard patterns: "bash", "bash(git *)", "FileRead(*)"
            if "(" in allowed:
                base_tool = allowed.split("(")[0].strip().lower()
                if tool_name.lower() == base_tool:
                    return True
            elif tool_name.lower() == allowed.lower():
                return True
        return False

    def execute_hook(self, hook_type: str, cwd: str = ".") -> bool:
        """Execute lifecycle hooks."""
        hooks = (
            self.hooks.pre_tool_call if hook_type == "pre"
            else self.hooks.post_tool_call
        )
        if not hooks:
            return True

        for cmd in hooks:
            try:
                result = subprocess.run(
                    cmd, shell=True, cwd=cwd,
                    capture_output=True, text=True, timeout=30,
                    executable=f"/bin/{self.shell}" if self.shell != "bash" else None,
                )
                if result.returncode != 0:
                    logger.warning(
                        f"Skill hook failed: {cmd} → exit {result.returncode}: "
                        f"{result.stderr[:200]}"
                    )
                    return False
            except subprocess.TimeoutExpired:
                logger.error(f"Skill hook timed out: {cmd}")
                return False
            except Exception as e:
                logger.error(f"Skill hook error: {cmd} → {e}")
                return False

        return True


class SkillFrontmatterLoader:
    """
    Loads SKILL.md files with YAML frontmatter.
    Parses structured skill definitions for agent-specific tool control.

    Expected SKILL.md format:
        ---
        name: my-skill
        description: What this skill does
        allowed-tools: ["bash", "git", "FileRead(*)"]
        paths: ["src/**", "tests/**"]
        when_to_use: "When the user asks to deploy"
        context: fork
        shell: bash
        hooks:
          preToolCall:
            - "git stash"
          postToolCall:
            - "git stash pop"
        ---
        [Markdown instructions for the agent...]
    """

    # Regex for YAML frontmatter block
    FRONTMATTER_RE = re.compile(
        r"^---\s*\n(.*?)\n---\s*\n(.*)$",
        re.DOTALL
    )

    def load_skill(self, skill_md_path: Path) -> Optional[SkillConfig]:
        """
        Parse a single SKILL.md file into a SkillConfig.

        Args:
            skill_md_path: Path to the SKILL.md file

        Returns:
            SkillConfig if valid, None if parse fails
        """
        if not skill_md_path.exists():
            return None

        try:
            raw = skill_md_path.read_text(encoding="utf-8")
        except Exception as e:
            logger.error(f"Cannot read {skill_md_path}: {e}")
            return None

        match = self.FRONTMATTER_RE.match(raw)
        if not match:
            # No frontmatter — treat entire file as content with dirname as name
            return SkillConfig(
                name=skill_md_path.parent.name,
                content=raw.strip(),
                source_path=str(skill_md_path),
            )

        frontmatter_raw = match.group(1)
        body = match.group(2).strip()

        # Parse YAML frontmatter (lightweight — no PyYAML dependency required)
        fm = self._parse_yaml_lightweight(frontmatter_raw)

        # Build SkillConfig
        hooks = SkillHooks()
        hooks_raw = fm.get("hooks", {})
        if isinstance(hooks_raw, dict):
            hooks.pre_tool_call = self._ensure_list(hooks_raw.get("preToolCall", []))
            hooks.post_tool_call = self._ensure_list(hooks_raw.get("postToolCall", []))

        skill = SkillConfig(
            name=fm.get("name", skill_md_path.parent.name),
            description=fm.get("description", ""),
            content=body,
            source_path=str(skill_md_path),
            allowed_tools=self._ensure_list(fm.get("allowed-tools", fm.get("allowed_tools", []))),
            paths=self._ensure_list(fm.get("paths", [])),
            when_to_use=fm.get("when_to_use", fm.get("when-to-use", "")),
            context=fm.get("context", "inline"),
            shell=fm.get("shell", "bash"),
            hooks=hooks,
            privilege_level=int(fm.get("privilege_level", fm.get("privilege-level", 3))),
            agent_whitelist=self._ensure_list(fm.get("agent_whitelist", fm.get("agent-whitelist", []))),
        )

        logger.debug(f"Loaded skill: {skill.name} ({skill_md_path})")
        return skill

    def load_skills_dir(self, skills_dir: Path) -> List[SkillConfig]:
        """
        Load all SKILL.md files from a skills directory.

        Expected structure:
            skills_dir/
                skill_name_1/SKILL.md
                skill_name_2/SKILL.md
                ...

        Returns:
            List of parsed SkillConfig objects
        """
        if not skills_dir.exists():
            return []

        skills = []
        for child in sorted(skills_dir.iterdir()):
            if not child.is_dir() or child.name.startswith((".", "_")):
                continue

            skill_md = child / "SKILL.md"
            if not skill_md.exists():
                continue

            skill = self.load_skill(skill_md)
            if skill:
                skills.append(skill)

        logger.info(f"Loaded {len(skills)} skills from {skills_dir}")
        return skills

    def get_active_skills(
        self,
        skills: List[SkillConfig],
        current_file: str = "",
        agent_name: str = "",
    ) -> List[SkillConfig]:
        """
        Filter skills based on current context (file path, agent).
        Only returns skills that are relevant to the current work.

        Args:
            skills: All loaded skills
            current_file: File being worked on (for path matching)
            agent_name: Name of the requesting agent

        Returns:
            Filtered list of active skills
        """
        active = []
        for skill in skills:
            # Path filter
            if current_file and skill.paths and not skill.matches_path(current_file):
                continue

            # Agent whitelist filter
            if skill.agent_whitelist and agent_name not in skill.agent_whitelist:
                continue

            active.append(skill)

        return active

    def build_skill_prompt(self, skills: List[SkillConfig]) -> str:
        """
        Build a system prompt section from active skills.
        Injects skill instructions into the agent's context.
        """
        if not skills:
            return ""

        lines = ["## Active Skills\n"]
        for skill in skills:
            lines.append(f"### {skill.name}")
            if skill.description:
                lines.append(f"*{skill.description}*")
            if skill.when_to_use:
                lines.append(f"**When to use:** {skill.when_to_use}")
            if skill.allowed_tools:
                lines.append(f"**Allowed tools:** {', '.join(skill.allowed_tools)}")
            lines.append("")
            if skill.content:
                # Truncate very long skill instructions
                content = skill.content[:3000]
                if len(skill.content) > 3000:
                    content += "\n... [skill instructions truncated]"
                lines.append(content)
            lines.append("")

        return "\n".join(lines)

    # ── Internal helpers ─────────────────────────────────────────────────

    def _parse_yaml_lightweight(self, raw: str) -> dict:
        """
        Lightweight YAML parser for frontmatter.
        Handles simple key-value pairs, lists, and nested dicts.
        No external dependency (no PyYAML needed).
        """
        try:
            import yaml
            return yaml.safe_load(raw) or {}
        except ImportError:
            pass

        # Fallback: manual parsing for simple cases
        result = {}
        current_key = None
        current_list = None

        for line in raw.split("\n"):
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                continue

            # Key: value pair
            if ":" in line and not line.startswith(" ") and not line.startswith("\t"):
                key, _, value = line.partition(":")
                key = key.strip()
                value = value.strip()

                if current_key and current_list is not None:
                    result[current_key] = current_list
                    current_list = None

                current_key = key

                if value.startswith("[") and value.endswith("]"):
                    # Inline list: ["a", "b", "c"]
                    try:
                        result[key] = json.loads(value)
                    except json.JSONDecodeError:
                        result[key] = [v.strip().strip("\"'") for v in value[1:-1].split(",") if v.strip()]
                elif value:
                    result[key] = value.strip("\"'")
                else:
                    current_list = []

            elif stripped.startswith("- ") and current_key:
                if current_list is None:
                    current_list = []
                current_list.append(stripped[2:].strip().strip("\"'"))

        if current_key and current_list is not None:
            result[current_key] = current_list

        return result

    @staticmethod
    def _ensure_list(val) -> list:
        """Ensure a value is a list."""
        if isinstance(val, list):
            return val
        if isinstance(val, str):
            return [val] if val else []
        return []


# ══════════════════════════════════════════════════════════════════════════════
# V1: ORIGINAL MANIFEST-BASED SKILL MANAGER
# ══════════════════════════════════════════════════════════════════════════════

class SkillManager:
    def __init__(self, redis_client):
        """
        Manages the loading, verification, and revocation of modular skills.
        Combines V1 manifest security with V2 frontmatter parsing.
        """
        self.redis = redis_client
        self.skills_dir = Path("agents/skills")
        self.agent_skills_dir = Path(".agent/skills")
        self.frontmatter_loader = SkillFrontmatterLoader()
        self._loaded_skills: List[SkillConfig] = []

    def _calculate_hash(self, file_path: Path) -> str:
        """Calculate SHA-256 hash of a file to ensure payload integrity."""
        sha256_hash = hashlib.sha256()
        with open(file_path, "rb") as f:
            for byte_block in iter(lambda: f.read(4096), b""):
                sha256_hash.update(byte_block)
        return sha256_hash.hexdigest()

    def verify_and_load_skill(self, skill_dir: Path) -> bool:
        """
        Reads `skill.manifest.json`, verifies the payload hash against the manifest,
        and registers the skill and its ACL in Redis if structurally and cryptographically valid.
        """
        logger.info(f"Inspecting potential skill package at: {skill_dir.name}")
        manifest_path = skill_dir / "skill.manifest.json"
        
        if not manifest_path.exists():
            logger.error(f"Manifest missing for skill at {skill_dir}")
            return False
            
        try:
            with open(manifest_path, 'r') as f:
                manifest = json.load(f)
        except json.JSONDecodeError:
            logger.error(f"Invalid JSON in manifest: {manifest_path}")
            return False

        skill_id = manifest.get("id")
        entry_point = manifest.get("entry_point")
        expected_hash = manifest.get("hash")
        
        if not all([skill_id, entry_point, expected_hash]):
            logger.error(f"Manifest {skill_id} missing required structural fields (id, entry_point, hash).")
            return False

        # Phase 1: Verify Payload Hash (Cryptographic Integrity)
        payload_path = skill_dir / entry_point
        if not payload_path.exists():
            logger.error(f"Entry point {entry_point} not found for skill {skill_id}")
            self._register_revoked_skill(skill_id, manifest, "Missing Executable Payload")
            return False
            
        actual_hash = self._calculate_hash(payload_path)
        
        if actual_hash != expected_hash:
            logger.critical(f"🚨 SECURITY ALERT: Hash mismatch for skill {skill_id}.")
            logger.critical(f"Expected: {expected_hash}")
            logger.critical(f"Got:      {actual_hash}")
            self._register_revoked_skill(skill_id, manifest, "Payload Hash Mismatch / Security Compromised")
            return False
            
        logger.info(f"✅ Skill {skill_id} verified successfully (Hash: {actual_hash[:8]}...)")
        
        # Phase 2: Register in Redis CATALOG and Set ACL
        self._register_valid_skill(skill_id, manifest)
        return True

    def _register_valid_skill(self, skill_id: str, manifest: Dict):
        """Registers a verified skill into the Redis CATALOG."""
        manifest["status"] = "active"
        manifest["verified"] = True
        
        # Populate Redis Catalog
        self.redis.set(f"CATALOG:skill:{skill_id}", json.dumps(manifest))
        
        # Isolate and populate ACL (Access Control List)
        acl = manifest.get("permissions", {})
        self.redis.set(f"ACL:skill:{skill_id}", json.dumps(acl))
        
        logger.info(f"Registered {skill_id} to CATALOG and ACL boundaries established.")

    def _register_revoked_skill(self, skill_id: str, manifest: Dict, reason: str):
        """Registers a revoked/blocked skill into the Redis CATALOG and strips ACL."""
        manifest["status"] = "blocked"
        manifest["verified"] = False
        manifest["reason"] = reason
        self.redis.set(f"CATALOG:skill:{skill_id}", json.dumps(manifest))
        
        # Deny ACL
        self.redis.set(f"ACL:skill:{skill_id}", json.dumps({"status": "REVOKED", "allowed_actions": []}))
        logger.warning(f"Skill {skill_id} registered as BLOCKED. Permissions stripped.")

    def scan_all_skills(self):
        """Scans the master skills directory to discover and verify all installed packages."""
        if not self.skills_dir.exists():
            self.skills_dir.mkdir(parents=True, exist_ok=True)
            logger.info(f"Created empty skill repository at {self.skills_dir}")
            return

        skill_dirs = [d for d in self.skills_dir.iterdir() if d.is_dir() and not d.name.startswith((".", "__"))]
        
        logger.info(f"Scanning {len(skill_dirs)} skill packages in repository...")
        
        valid_count = 0
        for s_dir in skill_dirs:
            if self.verify_and_load_skill(s_dir):
                valid_count += 1
                
        logger.info(f"Catalog Build Complete. {valid_count}/{len(skill_dirs)} skills active and sandboxed.")

    # ── V2: SKILL.md Frontmatter integration ─────────────────────────────

    def load_frontmatter_skills(self, skills_dir: Optional[Path] = None) -> List[SkillConfig]:
        """
        Load all SKILL.md-based skills from a directory.
        Complementary to the manifest-based scan_all_skills().
        """
        target = skills_dir or self.agent_skills_dir
        self._loaded_skills = self.frontmatter_loader.load_skills_dir(target)

        # Register in Redis for cross-agent visibility
        for skill in self._loaded_skills:
            self.redis.hset(
                "kernell:skills:frontmatter",
                skill.name,
                json.dumps(skill.to_dict()),
            )

        return self._loaded_skills

    def get_skills_for_context(
        self,
        current_file: str = "",
        agent_name: str = "",
    ) -> List[SkillConfig]:
        """Get skills that are active for the current context."""
        return self.frontmatter_loader.get_active_skills(
            self._loaded_skills, current_file, agent_name,
        )

    def get_skill_prompt(
        self,
        current_file: str = "",
        agent_name: str = "",
    ) -> str:
        """Build a system prompt section from contextually active skills."""
        active = self.get_skills_for_context(current_file, agent_name)
        return self.frontmatter_loader.build_skill_prompt(active)


# ── CLI ───────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import argparse
    import sys

    parser = argparse.ArgumentParser(description="🧩 Skill Manager V2 — Kernell OS")
    parser.add_argument("--scan", metavar="DIR", help="Scan a skills directory for SKILL.md files")
    parser.add_argument("--test-frontmatter", action="store_true", help="Test frontmatter parser")
    parser.add_argument("--list", action="store_true", help="List all loaded skills")
    args = parser.parse_args()

    if args.test_frontmatter:
        print("═" * 60)
        print("  SKILL MANAGER V2 — Frontmatter Parser Test")
        print("═" * 60)

        # Create a test SKILL.md in memory
        test_md = '''---
name: deploy-staging
description: Deploy current branch to staging environment
allowed-tools: ["bash", "docker", "git"]
paths: ["deploy/**", "docker/**", "Dockerfile"]
when_to_use: "When user asks to deploy to staging"
context: fork
shell: bash
hooks:
  preToolCall:
    - "git stash"
  postToolCall:
    - "git stash pop"
privilege-level: 5
agent-whitelist: ["forge", "fixer"]
---
## Instructions

1. Verify the current branch is clean
2. Run `docker build -t app:staging .`
3. Push to staging registry
4. Verify deployment health
'''
        # Write temp file
        from tempfile import NamedTemporaryFile
        with NamedTemporaryFile(mode="w", suffix=".md", delete=False, dir="/tmp") as f:
            f.write(test_md)
            temp_path = Path(f.name)

        loader = SkillFrontmatterLoader()
        skill = loader.load_skill(temp_path)

        if skill:
            print(f"\n✅ Parsed successfully:")
            print(f"  Name:          {skill.name}")
            print(f"  Description:   {skill.description}")
            print(f"  Allowed tools: {skill.allowed_tools}")
            print(f"  Paths:         {skill.paths}")
            print(f"  When to use:   {skill.when_to_use}")
            print(f"  Context:       {skill.context}")
            print(f"  Shell:         {skill.shell}")
            print(f"  Hooks pre:     {skill.hooks.pre_tool_call}")
            print(f"  Hooks post:    {skill.hooks.post_tool_call}")
            print(f"  Privilege:     {skill.privilege_level}")
            print(f"  Agents:        {skill.agent_whitelist}")
            print(f"\n  Path match 'deploy/prod.yaml':   {skill.matches_path('deploy/prod.yaml')}")
            print(f"  Path match 'src/main.py':         {skill.matches_path('src/main.py')}")
            print(f"  Tool allowed 'bash':              {skill.is_tool_allowed('bash')}")
            print(f"  Tool allowed 'mt5_query':         {skill.is_tool_allowed('mt5_query')}")

            print(f"\n  System prompt section:")
            prompt = loader.build_skill_prompt([skill])
            for line in prompt.split("\n")[:15]:
                print(f"    {line}")
        else:
            print("❌ Parse failed!")

        temp_path.unlink()
        print(f"\n{'═' * 60}")
        print("  TEST COMPLETE ✅")
        print(f"{'═' * 60}")

    elif args.scan:
        loader = SkillFrontmatterLoader()
        skills = loader.load_skills_dir(Path(args.scan))
        print(f"\n📦 Found {len(skills)} skills:\n")
        for s in skills:
            print(f"  {s.name:<30} {s.description[:50]}")
            if s.allowed_tools:
                print(f"    Tools: {', '.join(s.allowed_tools)}")
            if s.paths:
                print(f"    Paths: {', '.join(s.paths)}")

    elif args.list:
        # Load from default .agent/skills
        loader = SkillFrontmatterLoader()
        root = Path(__file__).parent.parent
        skills = loader.load_skills_dir(root / ".agent" / "skills")
        print(f"\n📦 Agent Skills ({len(skills)}):\n")
        for s in skills:
            print(f"  🧩 {s.name}")
            print(f"     {s.description}")
            if s.when_to_use:
                print(f"     When: {s.when_to_use}")
            print()

    else:
        parser.print_help()
