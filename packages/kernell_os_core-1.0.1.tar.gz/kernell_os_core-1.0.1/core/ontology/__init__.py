# Ontology Module — Kernell OS
from .ontology_manager import OntologyManager

__all__ = ["OntologyManager"]
