"""
OntologyManager — Kernell OS
═══════════════════════════════════════════════════════════════
Programmatic interface to core/ontology.yaml.

Provides:
  - get_agent(name) → agent config dict
  - get_hierarchy() → authority hierarchy list
  - get_delegation_rules() → pipeline delegation rules
  - get_kms_config() → KMS/Qdrant configuration
  - get_ontology_type(agent) → agent's ontology classification
  - get_agents_by_tier(tier) → list agents of a given tier
  - validate_delegation(source, target) → check if delegation is allowed
"""

import os
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

log = logging.getLogger("OntologyManager")

# Auto-detect YAML parser
try:
    import yaml
    YAML_OK = True
except ImportError:
    YAML_OK = False


class OntologyManager:
    """
    Reads and queries core/ontology.yaml — the system's source of truth
    for agent roles, authority levels, delegation rules, and KMS config.
    """

    def __init__(self, config_path: Optional[str] = None):
        if config_path:
            self._path = Path(config_path)
        else:
            root = os.getenv("KERNELL_ROOT", "/home/anny/kernell-os")
            self._path = Path(root) / "core" / "ontology.yaml"

        self._data: Dict[str, Any] = {}
        self._loaded = False
        self._load()

    def _load(self):
        """Load ontology.yaml."""
        if not YAML_OK:
            log.error("OntologyManager: PyYAML not installed")
            return
        if not self._path.exists():
            log.error(f"OntologyManager: {self._path} not found")
            return
        try:
            with open(self._path, "r") as f:
                self._data = yaml.safe_load(f) or {}
            self._loaded = True
            agent_count = len(self._data.get("agents", {}))
            log.info(f"OntologyManager: loaded ({agent_count} agents)")
        except Exception as e:
            log.error(f"OntologyManager: failed to load: {e}")

    def reload(self):
        """Hot-reload ontology.yaml."""
        self._load()

    # ── Agent Queries ─────────────────────────────────────────

    def get_agent(self, name: str) -> Optional[Dict]:
        """Get full config for an agent."""
        return self._data.get("agents", {}).get(name)

    def get_all_agents(self) -> Dict[str, Dict]:
        """Get all agent configs."""
        return self._data.get("agents", {})

    def get_ontology_type(self, agent_name: str) -> Optional[str]:
        """Get agent's ontology classification (infrastructure, tactical, etc)."""
        agent = self.get_agent(agent_name)
        if agent:
            return agent.get("ontology_type")
        return None

    def get_agents_by_tier(self, tier: str) -> List[str]:
        """Get agent names of a given tier (meta, metacognitive, etc)."""
        agents = self._data.get("agents", {})
        return [name for name, cfg in agents.items()
                if cfg.get("tier") == tier]

    def get_agents_by_ontology(self, ontology_type: str) -> List[str]:
        """Get agent names by ontology type (infrastructure, tactical, etc)."""
        agents = self._data.get("agents", {})
        return [name for name, cfg in agents.items()
                if cfg.get("ontology_type") == ontology_type]

    # ── Hierarchy Queries ─────────────────────────────────────

    def get_hierarchy(self) -> List[Dict]:
        """Get the authority hierarchy."""
        rules = self._data.get("delegation_rules", {})
        return rules.get("authority_hierarchy", [])

    def get_authority_level(self, agent_name: str) -> Optional[int]:
        """Get an agent's authority level."""
        for entry in self.get_hierarchy():
            if entry.get("entity") == agent_name:
                level = entry.get("level")
                return int(level) if isinstance(level, (int, float)) else None
        return None

    def validate_delegation(self, source: str, target: str) -> bool:
        """Check if source can delegate to target (source must have higher authority)."""
        src_level = self.get_authority_level(source)
        tgt_level = self.get_authority_level(target)
        if src_level is None or tgt_level is None:
            return True  # permissive if unknown
        return src_level <= tgt_level  # lower number = higher authority

    # ── Delegation Rules ──────────────────────────────────────

    def get_delegation_rules(self) -> Dict:
        """Get all delegation rules."""
        return self._data.get("delegation_rules", {})

    def get_pipeline(self, pipeline_name: str) -> Optional[Dict]:
        """Get a specific pipeline definition."""
        rules = self._data.get("delegation_rules", {})
        pipelines = rules.get("pipelines", {})
        return pipelines.get(pipeline_name)

    def get_mfa_required_paths(self, pipeline_name: str = "sage_evolution") -> List[str]:
        """Get paths that require MFA for a pipeline."""
        pipeline = self.get_pipeline(pipeline_name)
        if pipeline:
            return pipeline.get("mfa_required_paths", [])
        return []

    # ── KMS Config ────────────────────────────────────────────

    def get_kms_config(self) -> Dict:
        """Get KMS configuration."""
        return self._data.get("kms", {})

    # ── LLM Config ────────────────────────────────────────────

    def get_llm_providers(self) -> Dict:
        """Get LLM provider configurations."""
        return self._data.get("llm_providers", {})

    # ── Boot Config ───────────────────────────────────────────

    def get_boot_config(self) -> Dict:
        """Get boot configuration."""
        return self._data.get("boot", {})

    # ── General ───────────────────────────────────────────────

    @property
    def is_loaded(self) -> bool:
        return self._loaded

    def get(self, key: str, default: Any = None) -> Any:
        """Generic access to any top-level key."""
        return self._data.get(key, default)
