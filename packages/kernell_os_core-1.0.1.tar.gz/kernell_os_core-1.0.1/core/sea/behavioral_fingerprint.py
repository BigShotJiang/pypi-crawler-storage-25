"""
BEHAVIORAL FINGERPRINT — Agent Profile Baseline
==================================================
Creates a statistical baseline for each agent's behavior.
Tracks: avg response time, action frequency, mutation rate,
        authority request rate, error rate.

Anomaly detection: if current behavior deviates > 2σ from
the baseline, triggers an alert.
"""

import json
import math
import logging
import redis
from datetime import datetime, timezone
from typing import Optional

logger = logging.getLogger("sea.behavioral_fingerprint")

ANOMALY_SIGMA = 2.0        # Standard deviations for anomaly threshold
BASELINE_WINDOW = 100      # N most recent samples for baseline


class BehavioralFingerprint:
    """
    Behavioral profiling engine for cross-agent anomaly detection.
    Maintains a rolling baseline (mean + stddev) per agent per metric.
    """

    METRICS = [
        "response_time_ms",
        "actions_per_cycle",
        "mutations_count",
        "authority_requests",
        "error_count",
    ]

    def __init__(self, redis_client: redis.Redis):
        self.redis = redis_client

    def record(self, agent: str, metrics: dict):
        """
        Record a new observation for an agent.
        Checks against baseline and triggers anomaly alerts.
        
        Args:
            agent: Agent name
            metrics: dict with keys matching METRICS
        """
        now = datetime.now(timezone.utc).isoformat()
        
        # Store observation
        key = f"kernell:fingerprint:{agent}:history"
        self.redis.lpush(key, json.dumps({**metrics, "timestamp": now}))
        self.redis.ltrim(key, 0, BASELINE_WINDOW - 1)

        # Check each metric for anomalies
        anomalies = []
        for metric_name in self.METRICS:
            if metric_name not in metrics:
                continue

            value = float(metrics[metric_name])
            baseline = self._get_baseline(agent, metric_name)

            if baseline is None:
                continue

            mean, stddev = baseline
            if stddev == 0:
                continue

            z_score = abs(value - mean) / stddev
            if z_score > ANOMALY_SIGMA:
                anomalies.append({
                    "metric": metric_name,
                    "value": value,
                    "mean": round(mean, 2),
                    "stddev": round(stddev, 2),
                    "z_score": round(z_score, 2),
                })

        if anomalies:
            self._alert_anomaly(agent, anomalies)

        # Update current fingerprint
        self.redis.set(f"kernell:fingerprint:{agent}:current", json.dumps({
            "agent": agent,
            "metrics": metrics,
            "anomalies": len(anomalies),
            "timestamp": now,
        }))

    def _get_baseline(self, agent: str, metric_name: str) -> Optional[tuple[float, float]]:
        """
        Calculate mean and stddev for a metric from history.
        Returns None if insufficient data.
        """
        key = f"kernell:fingerprint:{agent}:history"
        history = self.redis.lrange(key, 0, BASELINE_WINDOW - 1)

        if len(history) < 10:
            return None

        values = []
        for raw in history:
            data = json.loads(raw)
            if metric_name in data:
                values.append(float(data[metric_name]))

        if len(values) < 5:
            return None

        mean = sum(values) / len(values)
        variance = sum((v - mean) ** 2 for v in values) / len(values)
        stddev = math.sqrt(variance)

        return mean, stddev

    def _alert_anomaly(self, agent: str, anomalies: list[dict]):
        """Publish anomaly alert to Redis."""
        logger.warning(
            f"[FINGERPRINT] Anomaly detected for '{agent}': "
            f"{len(anomalies)} metrics deviated > {ANOMALY_SIGMA}σ"
        )
        self.redis.lpush("kernell:immune:anomalies", json.dumps({
            "type": "behavioral_anomaly",
            "agent": agent,
            "anomalies": anomalies,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }))
        self.redis.ltrim("kernell:immune:anomalies", 0, 49)

    def get_fingerprint(self, agent: str) -> Optional[dict]:
        """Get current fingerprint for an agent."""
        raw = self.redis.get(f"kernell:fingerprint:{agent}:current")
        return json.loads(raw) if raw else None
