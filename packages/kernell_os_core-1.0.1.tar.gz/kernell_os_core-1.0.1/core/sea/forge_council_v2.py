"""
FORGE COUNCIL v2 — Multi-Proveedor + Caché
===========================================
Corrección crítica:

PROBLEMA v1:
  Auto-evolución dependía de un único proveedor (Anthropic).
  Si la key falla, el modelo cambia comportamiento, o la API cae:
  el sistema pierde completamente capacidad evolutiva.

SOLUCIÓN v2:
  1. MULTI-PROVEEDOR — Claude primario, Gemini fallback
     Si Claude falla → Gemini toma el rol
     Si ambos fallan → modo offline con debate reducido

  2. CACHÉ DE DEBATES — Los debates se cachean por hash del patch
     Patches idénticos o muy similares reutilizan debates previos
     TTL: 6 horas (cambios recientes no se cachean)

  3. MODO OFFLINE REDUCIDO — Si ambos proveedores fallan:
     Debate estático con reglas formales predefinidas
     Solo aprueba si estimated_risk < 30 Y target_layer == "L2"
     Nunca aprueba cambios de alto riesgo sin LLM

  4. CIRCUIT BREAKER — Si un proveedor falla 3 veces seguidas,
     se marca como "degraded" y se bypasa temporalmente

NOTA: Forge solo genera propuestas y votos.
  NO ejecuta código. NO escribe en producción.
  Sus outputs son datos estructurados que pasan por PFE.
"""

import json
import logging
import redis
import hashlib
import time
from dataclasses import dataclass, asdict
from datetime import datetime, timezone, timedelta
from typing import Optional
import urllib.request
import re

logger = logging.getLogger("pfe.forge_council.v2")

# ── Providers ─────────────────────────────────────────────────────────────
PROVIDERS = {
    "claude": {
        "url":     "https://api.anthropic.com/v1/messages",
        "model":   "claude-sonnet-4-20250514",
        "headers": {"Content-Type": "application/json"},
    },
    "gemini": {
        "url":     "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-pro:generateContent",
        "model":   "gemini-1.5-pro",
        "headers": {"Content-Type": "application/json"},
    },
}

CIRCUIT_BREAKER_THRESHOLD = 3   # Fallos consecutivos antes de marcar degraded
CIRCUIT_BREAKER_RECOVERY  = 600  # Segundos antes de reintentar proveedor degraded
DEBATE_CACHE_TTL_H        = 6   # Horas que un debate previo es válido


@dataclass
class PerspectiveVote:
    perspective: str
    vote: str
    confidence: float
    reasoning: str
    concerns: list
    suggestions: list
    provider_used: str    # Nuevo: qué proveedor respondió
    cached: bool          # Nuevo: si vino de caché


@dataclass
class ProposalVerdict:
    proposal_id: str
    timestamp: str
    votes: list
    approve_count: int
    reject_count: int
    abstain_count: int
    final_decision: str
    l0_violation: bool
    consensus_strength: float
    blocking_concerns: list
    approved_for_sandbox: bool
    from_cache: bool      # Nuevo
    offline_mode: bool    # Nuevo


L0_PROTECTED = {
    "constitution", "pfe_protocol", "svs_module", "formal_verifier",
    "l0_invariants", "fsm_state_space", "safety_properties",
    "liveness_properties", "authority_matrix", "freeze_rule",
}


class CircuitBreaker:
    """Evita llamar a un proveedor que está fallando continuamente."""

    def __init__(self, name: str, redis_client: redis.Redis):
        self.name = name
        self.redis = redis_client

    def record_failure(self):
        key = f"kernell:forge:circuit:{self.name}:failures"
        self.redis.incr(key)
        self.redis.expire(key, CIRCUIT_BREAKER_RECOVERY)

    def record_success(self):
        self.redis.delete(f"kernell:forge:circuit:{self.name}:failures")
        self.redis.delete(f"kernell:forge:circuit:{self.name}:open")

    def is_open(self) -> bool:
        """True si el circuit breaker está abierto (proveedor no disponible)."""
        failures_raw = self.redis.get(f"kernell:forge:circuit:{self.name}:failures")
        return int(failures_raw or 0) >= CIRCUIT_BREAKER_THRESHOLD


class ForgeCouncilV2:
    """
    Forge Council v2 con multi-proveedor, caché y modo offline.
    """

    def __init__(self, redis_client: redis.Redis):
        self.redis = redis_client
        self._breakers = {
            name: CircuitBreaker(name, redis_client)
            for name in PROVIDERS
        }

    # ── Debate principal ──────────────────────────────────────────────────

    def debate(self, proposal) -> ProposalVerdict:
        logger.info(f"[FORGE v2] Debatiendo '{proposal.title}' (risk={proposal.estimated_risk})")

        # L0 check inmediato
        if self._violates_l0(proposal):
            return self._l0_rejection(proposal)

        # Verificar caché
        cached_verdict = self._get_cached_verdict(proposal)
        if cached_verdict:
            logger.info(f"[FORGE v2] Debate desde caché (hash={self._proposal_hash(proposal)[:8]})")
            cached_verdict.from_cache = True
            return cached_verdict

        # Detectar modo offline
        all_down = all(b.is_open() for b in self._breakers.values())
        if all_down:
            logger.warning("[FORGE v2] Todos los proveedores caídos — modo offline")
            return self._offline_debate(proposal)

        # Debate normal con fallback
        vote_a = self._call_perspective("FORGE_A", "proponent", proposal)
        vote_b = self._call_perspective("FORGE_B", "opposition", proposal)
        vote_c = self._call_perspective("FORGE_C", "minimalist", proposal)

        votes = [vote_a, vote_b, vote_c]
        approve = sum(1 for v in votes if v.vote == "APPROVE")
        reject  = sum(1 for v in votes if v.vote == "REJECT")
        abstain = sum(1 for v in votes if v.vote == "ABSTAIN")

        decision = "REJECTED" if reject >= 2 else ("APPROVED" if approve >= 2 else "NEEDS_REVISION")
        blocking = [c for v in votes if v.vote == "REJECT" for c in v.concerns]

        verdict = ProposalVerdict(
            proposal_id=proposal.proposal_id,
            timestamp=datetime.now(timezone.utc).isoformat(),
            votes=[asdict(v) for v in votes],
            approve_count=approve, reject_count=reject, abstain_count=abstain,
            final_decision=decision,
            l0_violation=False,
            consensus_strength=round(approve / 3.0, 2),
            blocking_concerns=blocking,
            approved_for_sandbox=(decision == "APPROVED"),
            from_cache=False,
            offline_mode=False,
        )

        self._cache_verdict(proposal, verdict)
        self._persist(verdict, proposal)

        logger.info(
            f"[FORGE v2] {decision} ({approve}✅ {reject}❌ {abstain}⚪)"
        )
        return verdict

    # ── Perspectivas con fallback multi-proveedor ─────────────────────────

    def _call_perspective(self, name: str, role: str, proposal) -> PerspectiveVote:
        systems = {
            "proponent":   "Eres FORGE_A, arquitecto proponente. Evalúa si el patch mejora genuinamente el sistema. Responde SOLO en JSON: {\"vote\":\"APPROVE\"|\"REJECT\"|\"ABSTAIN\",\"confidence\":0-1,\"reasoning\":\"\",\"concerns\":[],\"suggestions\":[]}",
            "opposition":  "Eres FORGE_B, opositor estructural. Busca activamente fallas, dependencias ocultas, race conditions, deuda técnica. Responde SOLO en JSON: {\"vote\":\"APPROVE\"|\"REJECT\"|\"ABSTAIN\",\"confidence\":0-1,\"reasoning\":\"\",\"concerns\":[],\"suggestions\":[]}",
            "minimalist":  "Eres FORGE_C, minimalista. ¿Es este cambio necesario? ¿Existe alternativa más simple? Cuantifica complejidad añadida. Responde SOLO en JSON: {\"vote\":\"APPROVE\"|\"REJECT\"|\"ABSTAIN\",\"confidence\":0-1,\"reasoning\":\"\",\"concerns\":[],\"suggestions\":[]}",
        }

        system_prompt = systems[role]
        user_msg = self._format_proposal(proposal, role)

        # Intentar proveedores en orden de preferencia
        for provider_name in ["claude", "gemini"]:
            breaker = self._breakers[provider_name]
            if breaker.is_open():
                logger.debug(f"[FORGE v2] {provider_name} circuit open, skipping")
                continue

            result = self._call_provider(provider_name, system_prompt, user_msg)
            if result is not None:
                breaker.record_success()
                return PerspectiveVote(
                    perspective=name,
                    vote=result.get("vote", "ABSTAIN"),
                    confidence=float(result.get("confidence", 0.5)),
                    reasoning=result.get("reasoning", ""),
                    concerns=result.get("concerns", []),
                    suggestions=result.get("suggestions", []),
                    provider_used=provider_name,
                    cached=False,
                )
            else:
                breaker.record_failure()
                logger.warning(f"[FORGE v2] {provider_name} failed for {name}")

        # Todos fallaron — abstención técnica
        logger.error(f"[FORGE v2] {name}: todos los proveedores fallaron")
        return PerspectiveVote(
            perspective=name, vote="ABSTAIN", confidence=0.0,
            reasoning="All providers failed — technical abstention",
            concerns=["No LLM available for evaluation"],
            suggestions=[],
            provider_used="none", cached=False,
        )

    def _call_provider(self, provider_name: str, system: str, user: str) -> Optional[dict]:
        config = PROVIDERS[provider_name]

        try:
            if provider_name == "claude":
                payload = json.dumps({
                    "model": config["model"],
                    "max_tokens": 1200,
                    "system": system,
                    "messages": [{"role": "user", "content": user}],
                }).encode()
            elif provider_name == "gemini":
                # Gemini format
                combined = f"{system}\n\n{user}"
                payload = json.dumps({
                    "contents": [{"parts": [{"text": combined}]}],
                    "generationConfig": {"maxOutputTokens": 1200},
                }).encode()

            req = urllib.request.Request(
                config["url"], data=payload,
                headers=config["headers"], method="POST",
            )

            with urllib.request.urlopen(req, timeout=45) as response:
                data = json.loads(response.read())

            # Extraer texto según proveedor
            if provider_name == "claude":
                text = "".join(
                    b.get("text", "") for b in data.get("content", [])
                    if b.get("type") == "text"
                )
            elif provider_name == "gemini":
                text = data.get("candidates", [{}])[0].get(
                    "content", {}
                ).get("parts", [{}])[0].get("text", "")

            # Parsear JSON
            try:
                return json.loads(text)
            except json.JSONDecodeError:
                match = re.search(r'\{.*\}', text, re.DOTALL)
                return json.loads(match.group()) if match else None

        except Exception as e:
            logger.error(f"[FORGE v2] {provider_name} error: {str(e)[:100]}")
            return None

    # ── Modo offline ──────────────────────────────────────────────────────

    def _offline_debate(self, proposal) -> ProposalVerdict:
        """
        Debate estático con reglas formales cuando ningún LLM está disponible.
        Solo aprueba cambios de bajo riesgo L2.
        """
        risk = proposal.estimated_risk
        layer = proposal.target_layer
        approved = (risk < 30 and layer == "L2")

        reason = (
            f"OFFLINE MODE — risk={risk} layer={layer} → "
            f"{'APPROVED (low risk L2)' if approved else 'REJECTED (offline requires risk<30 L2)'}"
        )

        return ProposalVerdict(
            proposal_id=proposal.proposal_id,
            timestamp=datetime.now(timezone.utc).isoformat(),
            votes=[{
                "perspective": "OFFLINE_STATIC",
                "vote": "APPROVE" if approved else "REJECT",
                "reasoning": reason,
                "concerns": [] if approved else ["Offline mode blocks non-trivial changes"],
                "suggestions": [],
                "provider_used": "none",
                "cached": False,
            }],
            approve_count=1 if approved else 0,
            reject_count=0 if approved else 1,
            abstain_count=0,
            final_decision="APPROVED" if approved else "REJECTED",
            l0_violation=False,
            consensus_strength=1.0 if approved else 0.0,
            blocking_concerns=[] if approved else ["Offline mode — cannot evaluate safely"],
            approved_for_sandbox=approved,
            from_cache=False,
            offline_mode=True,
        )

    # ── Caché ─────────────────────────────────────────────────────────────

    def _proposal_hash(self, proposal) -> str:
        content = f"{proposal.proposed_diff}{proposal.target_layer}{proposal.estimated_risk}"
        return hashlib.sha256(content.encode()).hexdigest()

    def _get_cached_verdict(self, proposal) -> Optional[ProposalVerdict]:
        h = self._proposal_hash(proposal)
        raw = self.redis.get(f"kernell:forge:debate_cache:{h}")
        if raw:
            data = json.loads(raw)
            return ProposalVerdict(**data)
        return None

    def _cache_verdict(self, proposal, verdict: ProposalVerdict):
        if verdict.offline_mode:
            return  # No cachear debates offline
        h = self._proposal_hash(proposal)
        self.redis.set(
            f"kernell:forge:debate_cache:{h}",
            json.dumps(asdict(verdict)),
            ex=DEBATE_CACHE_TTL_H * 3600,
        )

    # ── L0 protection + persist ───────────────────────────────────────────

    def _violates_l0(self, proposal) -> bool:
        if proposal.target_layer == "L0":
            return True
        return any(
            l0 in f.lower()
            for f in proposal.target_files
            for l0 in L0_PROTECTED
        )

    def _l0_rejection(self, proposal) -> ProposalVerdict:
        self.redis.lpush("kernell:pfe:l0_violations", json.dumps({
            "proposal_id": proposal.proposal_id,
            "author": proposal.author,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }))
        return ProposalVerdict(
            proposal_id=proposal.proposal_id,
            timestamp=datetime.now(timezone.utc).isoformat(),
            votes=[], approve_count=0, reject_count=3, abstain_count=0,
            final_decision="REJECTED", l0_violation=True,
            consensus_strength=0.0,
            blocking_concerns=["L0 Constitutional violation"],
            approved_for_sandbox=False,
            from_cache=False, offline_mode=False,
        )

    def _format_proposal(self, proposal, role: str) -> str:
        return (
            f"Propuesta: {proposal.title}\n"
            f"Descripción: {proposal.description}\n"
            f"Capa: {proposal.target_layer} | Risk: {proposal.estimated_risk}/100\n"
            f"Archivos: {', '.join(proposal.target_files)}\n"
            f"Impacto FSM: {proposal.impact_fsm}\n"
            f"Impacto Invariantes: {proposal.impact_invariants}\n\n"
            f"Diff:\n{proposal.proposed_diff[:2000]}\n\n"
            f"Evalúa desde perspectiva {role}. Responde SOLO en JSON."
        )

    def _persist(self, verdict: ProposalVerdict, proposal):
        self.redis.hset("kernell:pfe:verdicts", verdict.proposal_id, json.dumps(asdict(verdict)))
        self.redis.lpush("kernell:pfe:verdict_history", json.dumps({
            "id": verdict.proposal_id, "decision": verdict.final_decision,
            "from_cache": verdict.from_cache, "offline": verdict.offline_mode,
            "timestamp": verdict.timestamp,
        }))
        self.redis.ltrim("kernell:pfe:verdict_history", 0, 99)
