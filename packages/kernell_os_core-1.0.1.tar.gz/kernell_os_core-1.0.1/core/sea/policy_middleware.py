"""
Policy Engine Middleware — Agent Import Bridge
================================================
Factory function so any agent can use the centralized PolicyEngine
without Redis boilerplate.

Usage:
    from core.sea.policy_middleware import get_policy_engine

    policy = get_policy_engine()
    decision = policy.evaluate_file_modification("core/drift/engine.py", "forge")
    if not decision.allowed:
        raise PolicyViolationError(decision)
"""

import os
import redis
from typing import Optional
from core.sea.policy_engine import PolicyEngine, PolicyViolationError

REDIS_HOST = os.getenv("REDIS_HOST", "localhost")
REDIS_PORT = int(os.getenv("REDIS_PORT", 6379))
REDIS_PASSWORD = os.getenv("REDIS_PASSWORD", "")

_cached_engine: Optional[PolicyEngine] = None


def get_redis_client() -> redis.Redis:
    """Create a Redis client with env-based configuration."""
    password = REDIS_PASSWORD.strip().strip("\"'") or None
    return redis.Redis(
        host=REDIS_HOST, port=REDIS_PORT,
        db=0, decode_responses=True,
        password=password,
    )


def get_policy_engine(
    layer: str = "core",
    redis_client: Optional[redis.Redis] = None,
) -> PolicyEngine:
    """
    Get or create a PolicyEngine instance.

    Args:
        layer: Deployment layer ("core", "enterprise", "platform")
        redis_client: Optional pre-existing Redis client

    Returns:
        PolicyEngine instance ready to evaluate policies.
    """
    global _cached_engine

    if _cached_engine is not None and redis_client is None:
        return _cached_engine

    r = redis_client or get_redis_client()
    engine = PolicyEngine(r, layer=layer)

    if redis_client is None:
        _cached_engine = engine

    return engine


def check_file_modification(target_file: str, agent: str) -> bool:
    """
    Quick helper: can this agent modify this file?
    Returns True if allowed, raises PolicyViolationError if denied.
    """
    policy = get_policy_engine()
    decision = policy.evaluate_file_modification(target_file, agent)
    if not decision.allowed:
        raise PolicyViolationError(decision)
    return True


def get_layer_for_file(file_path: str) -> str:
    """Quick helper: what layer (L0/L1/L2) does this file belong to?"""
    policy = get_policy_engine()
    return policy.get_layer_classification(file_path).value
