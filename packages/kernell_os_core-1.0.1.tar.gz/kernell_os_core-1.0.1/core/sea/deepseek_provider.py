"""
core/sea/llm_registry.py  ← PATCH PARA AGREGAR DEEPSEEK
════════════════════════════════════════════════════════════════════
PATCH: Integración de DeepSeek R1 y DeepSeek Coder V2
como providers OBLIGATORIOS en el LLM Registry de Kernell OS.

CONTEXTO:
  El CircuitBreaker vive en core/ontology.yaml:
    failure_threshold: 3
    reset_seconds:     600
    timeout_seconds:   60

  Este patch agrega DeepSeek al llm_registry.py existente
  respetando el sistema de CircuitBreaker ya implementado.

PROVIDERS AGREGADOS:
  deepseek-r1:       Razonamiento profundo — Comité de Auditoría (OBLIGATORIO)
  deepseek-coder-v2: Revisión estructural de código — Comité de Forge (OBLIGATORIO)

FALLBACK CHAIN (si DeepSeek falla 3 veces → circuit OPEN):
  deepseek-r1      → claude-opus-4    → gemini-2.0-pro
  deepseek-coder-v2→ claude-sonnet-4  → gemini-flash-2.0

USO EN llm_registry.py (agregar a la clase LLMRegistry):
  registry.get_provider("deepseek-r1")
  registry.call_with_fallback("deepseek-r1", prompt, role="audit")
════════════════════════════════════════════════════════════════════
"""

import os
import time
import json
import logging
import threading
from typing import Optional, Dict, Any, List
from enum import Enum
from dataclasses import dataclass, field

logger = logging.getLogger("LLM_REGISTRY")


# ══════════════════════════════════════════════════════════════════
# CIRCUIT BREAKER STATES
# ══════════════════════════════════════════════════════════════════

class CBState(str, Enum):
    CLOSED    = "CLOSED"     # Operando normalmente
    OPEN      = "OPEN"       # Bloqueado tras 3 fallos
    HALF_OPEN = "HALF_OPEN"  # Probando recuperación


@dataclass
class CircuitBreaker:
    """
    Circuit Breaker para un LLM provider.
    Parámetros desde core/ontology.yaml:
      failure_threshold: 3
      reset_seconds:     600
      timeout_seconds:   60
    """
    provider_id:       str
    failure_threshold: int   = 3
    reset_seconds:     int   = 600
    timeout_seconds:   int   = 60

    _state:            str   = field(default=CBState.CLOSED, init=False)
    _failures:         int   = field(default=0, init=False)
    _last_failure_ts:  float = field(default=0.0, init=False)
    _lock:             Any   = field(default_factory=threading.Lock, init=False)

    @property
    def state(self) -> str:
        with self._lock:
            if self._state == CBState.OPEN:
                # Verificar si expiró el cooldown
                if time.time() - self._last_failure_ts > self.reset_seconds:
                    self._state   = CBState.HALF_OPEN
                    logger.info(f"CB [{self.provider_id}]: OPEN → HALF_OPEN (cooldown expirado)")
            return self._state

    def record_success(self) -> None:
        with self._lock:
            self._failures = 0
            if self._state in (CBState.HALF_OPEN, CBState.OPEN):
                logger.info(f"CB [{self.provider_id}]: {self._state} → CLOSED (éxito)")
            self._state = CBState.CLOSED

    def record_failure(self, error: str = "") -> None:
        with self._lock:
            self._failures       += 1
            self._last_failure_ts = time.time()

            if self._failures >= self.failure_threshold:
                prev = self._state
                self._state = CBState.OPEN
                if prev != CBState.OPEN:
                    logger.error(
                        f"CB [{self.provider_id}]: {prev} → OPEN "
                        f"({self._failures} fallos · {error[:80]})"
                    )
                    # Notificar a SALUS
                    self._notify_salus()
            else:
                logger.warning(
                    f"CB [{self.provider_id}]: fallo {self._failures}/{self.failure_threshold} "
                    f"· {error[:60]}"
                )

    def can_attempt(self) -> bool:
        """True si el provider puede intentar una llamada."""
        return self.state in (CBState.CLOSED, CBState.HALF_OPEN)

    def _notify_salus(self) -> None:
        """Notifica a SALUS el error R-B07-CB-OPEN."""
        try:
            import redis as redis_lib
            r = redis_lib.Redis(
                host=os.environ.get("REDIS_HOST", "localhost"),
                port=int(os.environ.get("REDIS_PORT", 6379)),
                decode_responses=True
            )
            r.lpush("kernell:salus:errors", json.dumps({
                "code":        "R-B07-CB-OPEN",
                "provider":    self.provider_id,
                "failures":    self._failures,
                "ts":          time.time(),
                "reset_in_s":  self.reset_seconds
            }))
            r.expire("kernell:salus:errors", 86400)
        except Exception:
            pass


# ══════════════════════════════════════════════════════════════════
# DEEPSEEK PROVIDER
# ══════════════════════════════════════════════════════════════════

class DeepSeekProvider:
    """
    Provider para DeepSeek R1 y DeepSeek Coder V2.

    API compatible con OpenAI (usa openai SDK apuntando a DeepSeek base URL).
    Requiere DEEPSEEK_API_KEY en .env

    Modelos:
      deepseek-reasoner → DeepSeek R1 (razonamiento profundo, cadena de pensamiento)
      deepseek-coder    → DeepSeek Coder V2 (revisión estructural de código)
    """

    BASE_URL       = "https://api.deepseek.com"
    MODEL_R1       = "deepseek-reasoner"    # R1 — audit committee
    MODEL_CODER    = "deepseek-chat"        # Coder V2 — forge committee
    # Nota: DeepSeek recomienda "deepseek-chat" para coder tasks
    # y "deepseek-reasoner" para R1. Actualizar según API actual.

    def __init__(self):
        self.api_key = os.environ.get("DEEPSEEK_API_KEY", "")
        self._client = None

        if not self.api_key:
            logger.warning(
                "⚠️  DEEPSEEK_API_KEY no encontrada en .env. "
                "DeepSeek es OBLIGATORIO en el Comité de Auditoría y Forge. "
                "Agregar: DEEPSEEK_API_KEY=sk-... en .env"
            )

    def _get_client(self):
        """Lazy init del cliente OpenAI apuntando a DeepSeek."""
        if self._client is None:
            try:
                from openai import OpenAI
                self._client = OpenAI(
                    api_key  = self.api_key,
                    base_url = self.BASE_URL
                )
            except ImportError:
                raise ImportError(
                    "pip install openai  ← necesario para DeepSeek "
                    "(API compatible con OpenAI)"
                )
        return self._client

    def call_r1(
        self,
        prompt:     str,
        system:     str = "Eres un auditor de arquitectura de sistemas de IA. Razona profundamente antes de responder.",
        max_tokens: int = 2000,
        temperature: float = 0.0
    ) -> str:
        """
        Llamada a DeepSeek R1 con cadena de pensamiento.
        Retorna solo el texto final (sin los bloques <think>...</think>).

        R1 es ideal para:
          - Evaluación de propuestas del Comité de Auditoría
          - Análisis estructural de código
          - Verificación de consistencia arquitectural
        """
        client = self._get_client()

        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})

        response = client.chat.completions.create(
            model       = self.MODEL_R1,
            messages    = messages,
            max_tokens  = max_tokens,
            temperature = temperature,
            stream      = False
        )

        # R1 puede incluir reasoning_content separado
        choice = response.choices[0]
        content = choice.message.content or ""

        # Limpiar bloques <think> si el modelo los incluye inline
        import re
        content = re.sub(r'<think>.*?</think>', '', content, flags=re.DOTALL).strip()

        return content

    def call_coder(
        self,
        prompt:     str,
        system:     str = "Eres un revisor experto de código Python. Analiza la correctitud, seguridad y consistencia arquitectural.",
        max_tokens: int = 1500,
        temperature: float = 0.1
    ) -> str:
        """
        Llamada a DeepSeek Coder V2 para revisión de código.

        Ideal para:
          - Validar diffs del Comité de Forge
          - Detectar inconsistencias en PatchSchema
          - Revisar compatibilidad con el stack existente
        """
        client = self._get_client()

        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})

        response = client.chat.completions.create(
            model       = self.MODEL_CODER,
            messages    = messages,
            max_tokens  = max_tokens,
            temperature = temperature
        )

        return response.choices[0].message.content or ""

    def get_reasoning_trace(
        self,
        prompt:     str,
        system:     str = "",
        max_tokens: int = 4000
    ) -> Dict[str, str]:
        """
        Retorna TANTO el razonamiento interno COMO la respuesta final de R1.
        Útil para el Comité de Auditoría para mostrar el proceso de pensamiento.

        Returns:
          {
            "thinking": "... cadena de pensamiento completa ...",
            "response": "... respuesta final ...",
            "model":    "deepseek-reasoner"
          }
        """
        client = self._get_client()

        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})

        response = client.chat.completions.create(
            model      = self.MODEL_R1,
            messages   = messages,
            max_tokens = max_tokens,
        )

        choice = response.choices[0]
        full_content = choice.message.content or ""

        # Extraer thinking si está en el contenido
        import re
        think_match = re.search(r'<think>(.*?)</think>', full_content, re.DOTALL)
        thinking = think_match.group(1).strip() if think_match else ""
        response_text = re.sub(r'<think>.*?</think>', '', full_content, flags=re.DOTALL).strip()

        # Algunos modelos R1 lo ponen en reasoning_content
        if hasattr(choice.message, 'reasoning_content') and choice.message.reasoning_content:
            thinking = choice.message.reasoning_content

        return {
            "thinking": thinking,
            "response": response_text,
            "model":    self.MODEL_R1
        }


# ══════════════════════════════════════════════════════════════════
# PATCH PARA llm_registry.py EXISTENTE
# ══════════════════════════════════════════════════════════════════
#
# El archivo llm_registry.py existente maneja Anthropic, Gemini, Groq.
# Este patch agrega DeepSeek al registry con su circuit breaker propio.
#
# AGREGAR a la clase LLMRegistry existente:

PATCH_LLM_REGISTRY = '''
# ── DEEPSEEK INTEGRATION PATCH ──────────────────────────────────
# Agregar en el __init__ de LLMRegistry, después de los providers
# existentes (Anthropic, Gemini, Groq):

from core.sea.deepseek_provider import DeepSeekProvider, CircuitBreaker, CBState

# En __init__:
self.deepseek = DeepSeekProvider()
self.cb_deepseek_r1    = CircuitBreaker("deepseek-r1",    failure_threshold=3, reset_seconds=600)
self.cb_deepseek_coder = CircuitBreaker("deepseek-coder", failure_threshold=3, reset_seconds=600)

# Agregar método call_deepseek_r1:
def call_deepseek_r1(
    self,
    prompt: str,
    system: str = "",
    max_tokens: int = 2000,
    fallback_to_claude: bool = True
) -> str:
    """
    Llama a DeepSeek R1 respetando el CircuitBreaker.
    Si el CB está OPEN → fallback a Claude Opus.
    DeepSeek R1 es OBLIGATORIO en el Comité de Auditoría.
    """
    if self.cb_deepseek_r1.can_attempt():
        try:
            result = self.deepseek.call_r1(prompt, system, max_tokens)
            self.cb_deepseek_r1.record_success()
            return result
        except Exception as e:
            self.cb_deepseek_r1.record_failure(str(e))
            logger.warning(f"DeepSeek R1 falló: {e}")

    # Circuit OPEN o fallo → fallback
    if fallback_to_claude:
        logger.warning("DeepSeek R1 CB OPEN → fallback a Claude Opus (Comité degradado)")
        return self._call_anthropic_fallback(prompt, system, max_tokens)

    raise RuntimeError(
        f"DeepSeek R1 circuit OPEN y fallback deshabilitado. "
        f"Estado CB: {self.cb_deepseek_r1.state}. "
        f"Reset en: {int(self.cb_deepseek_r1.reset_seconds - (time.time() - self.cb_deepseek_r1._last_failure_ts))}s"
    )

# Agregar método call_deepseek_coder:
def call_deepseek_coder(
    self,
    prompt: str,
    system: str = "",
    max_tokens: int = 1500,
    fallback_to_claude: bool = True
) -> str:
    """
    Llama a DeepSeek Coder V2 para revisión de código.
    Fallback a Claude Sonnet si el CB está OPEN.
    """
    if self.cb_deepseek_coder.can_attempt():
        try:
            result = self.deepseek.call_coder(prompt, system, max_tokens)
            self.cb_deepseek_coder.record_success()
            return result
        except Exception as e:
            self.cb_deepseek_coder.record_failure(str(e))

    if fallback_to_claude:
        logger.warning("DeepSeek Coder CB OPEN → fallback a Claude Sonnet (Forge degradado)")
        return self._call_anthropic_fallback(prompt, system, max_tokens, model="claude-sonnet-4")

    raise RuntimeError("DeepSeek Coder circuit OPEN")

def get_deepseek_reasoning(self, prompt: str) -> dict:
    """
    Obtiene el razonamiento completo de DeepSeek R1.
    Retorna {thinking, response, model} para mostrar en el dashboard.
    """
    if not self.cb_deepseek_r1.can_attempt():
        return {"thinking":"[CircuitBreaker OPEN]","response":"","model":"deepseek-r1"}
    try:
        result = self.deepseek.get_reasoning_trace(prompt)
        self.cb_deepseek_r1.record_success()
        return result
    except Exception as e:
        self.cb_deepseek_r1.record_failure(str(e))
        return {"thinking":f"[Error: {e}]","response":"","model":"deepseek-r1"}

def _call_anthropic_fallback(self, prompt, system="", max_tokens=1000, model="claude-opus-4-5-20251001") -> str:
    """Fallback interno a Anthropic cuando DeepSeek falla."""
    try:
        import anthropic
        client = anthropic.Anthropic(api_key=os.environ.get("ANTHROPIC_API_KEY"))
        msg = client.messages.create(
            model=model, max_tokens=max_tokens,
            system=system if system else "You are a helpful assistant.",
            messages=[{"role":"user","content":prompt}]
        )
        return msg.content[0].text
    except Exception as e:
        logger.error(f"Anthropic fallback también falló: {e}")
        return f"[FALLBACK ERROR: {e}]"
'''


# ══════════════════════════════════════════════════════════════════
# ONTOLOGY.YAML PATCH — agregar DeepSeek al registry
# ══════════════════════════════════════════════════════════════════

ONTOLOGY_PATCH = """
# PATCH: core/ontology.yaml
# Agregar DeepSeek en la sección llm_providers

llm_providers:
  circuit_breaker:
    failure_threshold: 3
    reset_seconds: 600
    timeout_seconds: 60

  # ── PROVIDERS EXISTENTES (no tocar) ──
  anthropic:
    models: [claude-opus-4, claude-sonnet-4, claude-haiku-4]
    priority: 1
    roles: [general, orchestration, coding]

  gemini:
    models: [gemini-2.0-pro, gemini-flash-2.0]
    priority: 3
    roles: [analysis, multimodal]

  groq:
    models: [llama3-70b, mixtral-8x7b]
    priority: 4
    roles: [fast_inference]

  # ── DEEPSEEK (NUEVO — OBLIGATORIO) ──
  deepseek:
    models:
      deepseek-reasoner:
        alias: deepseek-r1
        role: deep_reasoning
        mandatory_in: [audit_committee]
        description: "Razonamiento profundo con cadena de pensamiento extendida"
        max_tokens: 8000
        temperature: 0.0
      deepseek-chat:
        alias: deepseek-coder-v2
        role: code_review
        mandatory_in: [forge_committee]
        description: "Revisión estructural y análisis semántico de código"
        max_tokens: 4000
        temperature: 0.1
    priority: 2
    base_url: "https://api.deepseek.com"
    env_key: "DEEPSEEK_API_KEY"
    mandatory: true
    fallback_chain:
      deepseek-r1:    [claude-opus-4, gemini-2.0-pro]
      deepseek-coder: [claude-sonnet-4, gemini-flash-2.0]
    circuit_breaker_override:
      failure_threshold: 3
      reset_seconds: 600

# Agregar en .env:
# DEEPSEEK_API_KEY=sk-...
# (Obtener en: platform.deepseek.com/api_keys)
"""

# ══════════════════════════════════════════════════════════════════
# SAGE AUDIT COMMITTEE — versión con CircuitBreaker awareness
# ══════════════════════════════════════════════════════════════════

AUDIT_COMMITTEE_DEEPSEEK_PROMPT = """
Eres DeepSeek R1, miembro OBLIGATORIO del Comité de Auditoría de Kernell OS.
Tu rol: análisis estructural profundo con razonamiento extendido.

PROPUESTA A EVALUAR:
Dominio:         {domain}
Título:          {title}
Descripción:     {description}
Archivos target: {target_files}
Nivel de riesgo: {risk_level}
Confianza SAGE:  {confidence}%
Mejora esperada: {expected_improvement}

Evidencia de investigación:
{evidence}

CONTEXTO DEL SISTEMA:
Stack: Python 3.10 · Redis · Qdrant RAMDisk · systemd
Agentes activos: {active_agents}
GSHI actual: {gshi}
Drift score actual: {drift_score}

INSTRUCCIONES DE RAZONAMIENTO:
1. Analiza la CONSISTENCIA ARQUITECTURAL del cambio propuesto
2. Verifica COMPATIBILIDAD con el stack existente
3. Evalúa RIESGO DE REGRESIÓN (¿puede bajar el GSHI?)
4. Considera el COSTO en KU vs BENEFICIO esperado
5. Determina si requiere MFA de la Arquitecta (cambios a core/)

Responde con JSON válido solamente:
{{
  "verdict": "APROBAR|RECHAZAR|CONDICIONAL",
  "confidence": 0.0,
  "reasoning": "razonamiento estructurado de 3-5 oraciones",
  "structural_concerns": ["concern 1", "concern 2"],
  "conditions": ["condición si es CONDICIONAL"],
  "mfa_required": true/false,
  "estimated_drift_impact": 0.0,
  "ku_efficiency": "ALTO|MEDIO|BAJO"
}}
"""

FORGE_COMMITTEE_DEEPSEEK_PROMPT = """
Eres DeepSeek Coder V2, miembro OBLIGATORIO del Comité de Forge de Kernell OS.
Tu rol: validación de integridad estructural del diff antes del Aegis Sandbox.

DIFF A REVISAR:
{code_diff}

ARCHIVOS MODIFICADOS: {target_files}
TIPO DE CAMBIO: {change_type}
AGENTE DESTINO: {target_agent}

CHECKLIST OBLIGATORIO:
□ ¿El código es Python 3.10+ compatible?
□ ¿Hay imports de librerías no disponibles en el entorno?
□ ¿Hay posibles deadlocks o race conditions con Redis?
□ ¿Se respeta el patrón AgentBase?
□ ¿Hay acceso directo a filesystem sin UniversalRollback?
□ ¿El código modifica core/ sin MFA gate?
□ ¿Hay hardcoded secrets o API keys?
□ ¿El Saga Pattern está implementado si hay multi-agente?

Responde con JSON válido solamente:
{{
  "verdict": "APROBAR|RECHAZAR|REQUIERE_REVISION",
  "confidence": 0.0,
  "checklist_results": {{}},
  "critical_issues": ["issue 1"],
  "suggestions": ["sugerencia 1"],
  "safe_for_aegis": true/false,
  "mfa_required": true/false
}}
"""


if __name__ == "__main__":
    """Test de conexión a DeepSeek."""
    from dotenv import load_dotenv
    load_dotenv()

    import logging
    logging.basicConfig(level=logging.INFO)

    provider = DeepSeekProvider()

    if not provider.api_key:
        print("❌ DEEPSEEK_API_KEY no configurada")
        print("   1. Ir a: https://platform.deepseek.com/api_keys")
        print("   2. Crear API key")
        print("   3. Agregar en .env: DEEPSEEK_API_KEY=sk-...")
        exit(1)

    print("🔵 Testeando DeepSeek R1...")
    try:
        result = provider.call_r1(
            prompt="Evalúa brevemente: ¿es seguro integrar VWAP como indicador en un bot de trading para Binance con CCXT en Python?",
            system="Responde en español. Sé conciso.",
            max_tokens=300
        )
        print(f"✅ R1 respondió: {result[:200]}...")
    except Exception as e:
        print(f"❌ R1 error: {e}")

    print("\n🔵 Testeando DeepSeek Coder...")
    try:
        result = provider.call_coder(
            prompt="Revisa: `redis.lpush(key, json.dumps(data))`. ¿Hay algún problema de seguridad?",
            max_tokens=200
        )
        print(f"✅ Coder respondió: {result[:200]}...")
    except Exception as e:
        print(f"❌ Coder error: {e}")

    print("\n🔵 Testeando Reasoning Trace (R1 completo)...")
    try:
        trace = provider.get_reasoning_trace(
            prompt="¿Debería un sistema multi-agente de IA usar Redis ACLs por agente? Razona.",
        )
        print(f"✅ Thinking: {trace['thinking'][:150]}...")
        print(f"✅ Response: {trace['response'][:150]}...")
    except Exception as e:
        print(f"❌ Trace error: {e}")
