"""
GSHI Hook — Atlas Runtime Loop Bridge
=======================================
Read-only bridge that Atlas calls in its 15s micro-cycle.
Reads latest GSHI from Redis and annotates the snapshot dict.

Does NOT recalculate — that's Chronos' job via sea_scheduler.py.
This only enriches the snapshot with health data already in Redis.
"""

import json
import logging
import redis
from typing import Optional

logger = logging.getLogger("sea.gshi_hook")


class GSHIHook:
    """
    Lightweight GSHI reader for Atlas runtime loop.

    Usage in runtime_loop.py:
        self.gshi_hook = GSHIHook(redis_client=agent.redis)
        ...
        gshi_data = self.gshi_hook.annotate(snapshot_dict)
    """

    def __init__(self, redis_client: redis.Redis):
        self.redis = redis_client

    def annotate(self, snapshot_dict: dict) -> Optional[dict]:
        """
        Read latest GSHI from Redis and inject into snapshot dict.

        Adds to snapshot_dict:
          - gshi_ema: float
          - gshi_interpretation: str
          - gshi_pfe_scope: str
          - gshi_triggered_actions: list

        Returns the GSHI data dict or None if unavailable.
        """
        try:
            raw = self.redis.get("kernell:gshi:v2:current")
            if not raw:
                return None

            gshi = json.loads(raw)

            # Annotate snapshot
            snapshot_dict["gshi_ema"] = gshi.get("gshi_ema", 0)
            snapshot_dict["gshi_interpretation"] = gshi.get("interpretation", "UNKNOWN")
            snapshot_dict["gshi_pfe_scope"] = gshi.get("pfe_scope_allowed", "BLOCKED")
            snapshot_dict["gshi_triggered_actions"] = gshi.get("triggered_actions", [])

            return gshi

        except Exception as e:
            logger.debug(f"GSHI hook: no data available ({e})")
            return None

    def get_health_summary(self) -> dict:
        """Quick health summary for logging."""
        try:
            raw = self.redis.get("kernell:gshi:v2:current")
            if raw:
                data = json.loads(raw)
                return {
                    "ema": data.get("gshi_ema", 0),
                    "interp": data.get("interpretation", "?"),
                    "scope": data.get("pfe_scope_allowed", "?"),
                }
        except Exception:
            pass
        return {"ema": 0, "interp": "N/A", "scope": "N/A"}
