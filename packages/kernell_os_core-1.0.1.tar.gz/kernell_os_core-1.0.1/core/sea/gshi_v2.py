"""
GSHI v2 — Métricas Objetivas + TrustScore Firmado
====================================================
Correcciones críticas del v1:

PROBLEMA v1:
  1. TrustScore manipulable: si un atacante controla agentes,
     puede inflar artificialmente el GSHI.
  2. SCI basado en heurísticas LLM (evalución cualitativa).
     Un LLM comprometido puede falsificar la complejidad.

SOLUCIÓN v2:
  1. TRUST SCORE FIRMADO — Cada TrustScore se firma con HMAC.
     El Overseer (independiente) recalcula y compara.
     Si divergen > 5% → TrustScore congelado al último valor válido.

  2. SCI COMPLETAMENTE OBJETIVO — Basado en:
     - Nº de agentes activos (medible)
     - Nº de Redis keys por namespace (medible)
     - Nº de reglas activas en Execution Guard (medible)
     - Nº de patches en historial últimas 24h (medible)
     - Frecuencia de transiciones FSM últimas 1h (medible)
     CERO heurísticas LLM.

  3. GSHI CON MEDIA MÓVIL — No punto a punto.
     GSHI se calcula como media exponencial de las últimas 10 mediciones.
     Eso hace que manipulación puntual no afecte el índice real.

  4. OVERSEER CROSS-VALIDATION — Overseer Beta recalcula GSHI
     independientemente. Si difiere > 10% → GSHI congelado.

FÓRMULA FINAL:
  GSHI = 0.40*SII + 0.30*MediaTrust_HMAC + 0.20*(100-SCI_objetivo) + 0.10*EcoStab
  GSHI_efectivo = EMA(GSHI, alpha=0.3, n=10)
"""

import json
import hmac
import hashlib
import logging
import math
import redis
from dataclasses import dataclass, asdict
from datetime import datetime, timezone, timedelta
from typing import Optional

logger = logging.getLogger("gshi.v2")

EMA_ALPHA           = 0.3    # Peso para EMA (menor = más suave)
EMA_HISTORY_N       = 10     # Últimas N mediciones para EMA
TRUST_DIVERGENCE_MAX = 0.05  # 5% divergencia máxima de TrustScore
GSHI_DIVERGENCE_MAX  = 0.10  # 10% divergencia máxima de GSHI vs Overseer


# ═══════════════════════════════════════════════════════════════════════════
# SCI v2 — TOTALMENTE OBJETIVO
# ═══════════════════════════════════════════════════════════════════════════

@dataclass
class SCIv2Report:
    sci: float
    # Componentes objetivos individuales
    active_agents: int
    agent_component: float
    redis_key_density: int
    redis_component: float
    guard_rules_count: int
    guard_component: float
    patches_24h: int
    patch_component: float
    fsm_transitions_1h: int
    fsm_component: float
    # Metadata
    growth_rate: float
    simplification_required: bool
    timestamp: str


class SCIv2:
    """
    Structural Complexity Index completamente objetivo.
    Todos los valores son conteos reales de Redis.
    Sin LLM. Sin heurísticas.
    """

    SIMPLIFY_THRESHOLD    = 80.0
    MAX_GROWTH_PER_UPDATE = 10.0

    # Normalizadores para cada componente (valor=100 cuando componente llega aquí)
    NORM_AGENTS      = 20    # 20 agentes → component=100
    NORM_REDIS_KEYS  = 5000  # 5000 keys → component=100
    NORM_GUARD_RULES = 50    # 50 reglas → component=100
    NORM_PATCHES_24H = 10    # 10 patches/día → component=100
    NORM_FSM_TRANS   = 100   # 100 transiciones/hora → component=100

    def __init__(self, redis_client: redis.Redis):
        self.redis = redis_client

    def calculate(self) -> SCIv2Report:
        # Medir cada componente objetivamente
        active_agents = self._count_active_agents()
        redis_keys    = self._count_redis_keys()
        guard_rules   = self._count_guard_rules()
        patches_24h   = self._count_patches_24h()
        fsm_trans     = self._count_fsm_transitions_1h()

        # Normalizar a 0-100
        ac = min(100.0, (active_agents / self.NORM_AGENTS) * 100)
        rc = min(100.0, (redis_keys    / self.NORM_REDIS_KEYS) * 100)
        gc = min(100.0, (guard_rules   / self.NORM_GUARD_RULES) * 100)
        pc = min(100.0, (patches_24h   / self.NORM_PATCHES_24H) * 100)
        fc = min(100.0, (fsm_trans     / self.NORM_FSM_TRANS) * 100)

        # SCI ponderado
        sci = (
            0.20 * ac   # Agentes activos
            + 0.25 * rc   # Densidad de estado en Redis
            + 0.20 * gc   # Reglas de autorización activas
            + 0.20 * pc   # Frecuencia de cambios recientes
            + 0.15 * fc   # Frecuencia de transiciones FSM
        )
        sci = min(100.0, round(sci, 2))

        # Verificar crecimiento
        prev = self._previous_sci()
        growth = sci - prev if prev is not None else 0.0
        if growth > self.MAX_GROWTH_PER_UPDATE:
            logger.warning(f"[SCI v2] Crecimiento {growth:.1f}pts — requiere auditoría")
            self.redis.lpush("kernell:alerts:system", json.dumps({
                "type": "sci_growth_violation",
                "growth": growth, "sci": sci,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }))

        report = SCIv2Report(
            sci=sci,
            active_agents=active_agents, agent_component=round(ac, 2),
            redis_key_density=redis_keys, redis_component=round(rc, 2),
            guard_rules_count=guard_rules, guard_component=round(gc, 2),
            patches_24h=patches_24h, patch_component=round(pc, 2),
            fsm_transitions_1h=fsm_trans, fsm_component=round(fc, 2),
            growth_rate=round(growth, 2),
            simplification_required=sci > self.SIMPLIFY_THRESHOLD,
            timestamp=datetime.now(timezone.utc).isoformat(),
        )

        self._persist(report)
        return report

    def _count_active_agents(self) -> int:
        """Agentes con heartbeat activo (no expirado)."""
        # FIX B-5/B-8: canonical namespace is kernell:agent:{name}:heartbeat (singular)
        count = 0
        for _ in self.redis.scan_iter("kernell:agent:*:heartbeat"):
            count += 1
        return count

    def _count_redis_keys(self) -> int:
        """Total de keys en Redis como proxy de complejidad de estado."""
        try:
            return self.redis.dbsize()
        except Exception:
            return 0

    def _count_guard_rules(self) -> int:
        """Nº de perfiles de autorización registrados en Execution Guard."""
        profiles = self.redis.hgetall("kernell:execution_guard:profiles")
        total_scopes = 0
        for v in profiles.values():
            data = json.loads(v)
            total_scopes += len(data.get("execution_scope", []))
        return total_scopes

    def _count_patches_24h(self) -> int:
        """Nº de patches promovidos en las últimas 24h."""
        history = self.redis.lrange("kernell:pfe:promotions", 0, 49)
        cutoff = datetime.now(timezone.utc) - timedelta(hours=24)
        count = 0
        for raw in history:
            data = json.loads(raw)
            try:
                ts = datetime.fromisoformat(data.get("promoted_at", "2000-01-01"))
                if ts > cutoff:
                    count += 1
            except ValueError:
                pass
        return count

    def _count_fsm_transitions_1h(self) -> int:
        """Transiciones FSM reales en última hora (desde log de mode changes)."""
        raw = self.redis.get("kernell:system:fsm_transitions_last_hour")
        return int(raw) if raw else 0

    def _previous_sci(self) -> Optional[float]:
        raw = self.redis.get("kernell:gshi:v2:sci")
        if raw:
            return json.loads(raw).get("sci")
        return None

    def _persist(self, report: SCIv2Report):
        self.redis.set("kernell:gshi:v2:sci", json.dumps(asdict(report)))
        if report.simplification_required:
            self.redis.set("kernell:gshi:simplification_mode", "true")
        else:
            self.redis.delete("kernell:gshi:simplification_mode")


# ═══════════════════════════════════════════════════════════════════════════
# TRUST SCORE v2 — FIRMADO + OVERSEER VALIDATION
# ═══════════════════════════════════════════════════════════════════════════

@dataclass
class AgentTrustV2:
    agent_name: str
    trust_score: float
    historical_alignment: float
    low_volatility: float
    low_exploit_flag: float
    stability_contribution: float
    signature: str              # HMAC del trust_score
    overseer_validated: bool    # ¿Overseer confirma este valor?
    frozen: bool                # Congelado por divergencia
    tier: str
    timestamp: str


class TrustSystemV2:
    """
    Sistema de reputación con TrustScore firmado e inmune a manipulación.
    Overseer Beta recalcula independientemente.
    """

    # FIX B-6: was only 10 agents (42% of swarm). Now all 26 active agents.
    KNOWN_AGENTS = [
        # S0 — Sovereign Core
        "kernell", "overseer", "sentinel", "nexus",
        # S1 — Intelligence
        "atlas", "forge", "sierra", "observer",
        # S2 — Tactical
        "nemesis", "bounty", "hunter",
        # S3 — Operations
        "fixer", "economy", "operator",
        # S4 — Economic
        "ads", "prospector",
        # S5 — Meta
        "chronos", "archivista", "scribe",
        # S6 — Integrations
        "herald", "telegram_bridge", "interface", "vector",
        # Infrastructure
        "neurons", "sage", "common",
    ]

    def __init__(self, redis_client: redis.Redis, system_secret: str):
        self.redis = redis_client
        self._secret = system_secret.encode()

    def calculate_all(self, sign: bool = True) -> dict[str, AgentTrustV2]:
        profiles = {}
        for agent in self.KNOWN_AGENTS:
            profiles[agent] = self.calculate_agent(agent, sign)
        return profiles

    def calculate_agent(self, agent_name: str, sign: bool = True) -> AgentTrustV2:
        alignment   = self._historical_alignment(agent_name)
        volatility  = self._low_volatility(agent_name)
        exploit     = self._low_exploit_flag(agent_name)
        stability   = self._stability_contribution(agent_name)

        trust = (
            0.35 * alignment    # Peso mayor al historial
            + 0.25 * volatility
            + 0.25 * exploit    # Peso mayor al exploit flag
            + 0.15 * stability
        )
        trust = round(max(0.0, min(100.0, trust)), 2)

        # Verificar si está congelado
        frozen = self._is_frozen(agent_name)
        if frozen:
            # Usar último valor validado
            last_raw = self.redis.get(f"kernell:gshi:v2:trust:{agent_name}:last_valid")
            if last_raw:
                trust = float(last_raw)

        # Firmar
        signature = ""
        if sign:
            sig_data = f"{agent_name}:{trust}:{datetime.now(timezone.utc).strftime('%Y%m%d%H')}"
            signature = hmac.new(self._secret, sig_data.encode(), hashlib.sha256).hexdigest()[:16]

        tier = self._tier(trust, agent_name)

        profile = AgentTrustV2(
            agent_name=agent_name,
            trust_score=trust,
            historical_alignment=round(alignment, 2),
            low_volatility=round(volatility, 2),
            low_exploit_flag=round(exploit, 2),
            stability_contribution=round(stability, 2),
            signature=signature,
            overseer_validated=not frozen,
            frozen=frozen,
            tier=tier,
            timestamp=datetime.now(timezone.utc).isoformat(),
        )

        self._persist(profile)
        self._apply_effects(profile)
        return profile

    def validate_from_overseer(self, agent_name: str, overseer_trust: float) -> bool:
        """
        Overseer Beta llama esto con su cálculo independiente.
        Si diverge > TRUST_DIVERGENCE_MAX → congelar.
        """
        main_raw = self.redis.get(f"kernell:gshi:v2:trust:{agent_name}")
        if not main_raw:
            return True

        main_trust = json.loads(main_raw).get("trust_score", 0)
        diff_pct = abs(main_trust - overseer_trust) / max(main_trust, 1) * 100

        if diff_pct > TRUST_DIVERGENCE_MAX * 100:
            self.redis.set(f"kernell:gshi:v2:trust:{agent_name}:frozen", "true", ex=3600)
            logger.error(
                f"[TRUST v2] {agent_name} TrustScore CONGELADO: "
                f"main={main_trust:.1f} overseer={overseer_trust:.1f} ({diff_pct:.1f}% div)"
            )
            return False

        # Guardar como último válido
        self.redis.set(f"kernell:gshi:v2:trust:{agent_name}:last_valid", str(main_trust))
        return True

    def mean_trust(self) -> float:
        """Media de TrustScores firmados (ignora congelados con último válido)."""
        scores = []
        for agent in self.KNOWN_AGENTS:
            raw = self.redis.get(f"kernell:gshi:v2:trust:{agent}")
            if raw:
                data = json.loads(raw)
                if data.get("frozen"):
                    last = self.redis.get(f"kernell:gshi:v2:trust:{agent}:last_valid")
                    scores.append(float(last) if last else 65.0)
                else:
                    scores.append(data.get("trust_score", 65.0))
            else:
                scores.append(65.0)
        return sum(scores) / len(scores) if scores else 65.0

    def _historical_alignment(self, agent: str) -> float:
        violations = self.redis.lrange("kernell:guard:violations", 0, 499)
        count = sum(1 for r in violations if json.loads(r).get("agent") == agent)
        return max(0.0, 100 - count * 8)

    def _low_volatility(self, agent: str) -> float:
        baseline_raw = self.redis.get(f"kernell:immune:fingerprint:{agent}:baseline")
        if baseline_raw:
            b = json.loads(baseline_raw)
            std = b.get("std_drift_contribution", 10)
            return max(0.0, 100 - std * 4)
        return 70.0

    def _low_exploit_flag(self, agent: str) -> float:
        guard_viol = sum(
            1 for r in self.redis.lrange("kernell:guard:violations", 0, 499)
            if json.loads(r).get("agent") == agent
        )
        l0_viol = sum(
            1 for r in self.redis.lrange("kernell:pfe:l0_violations", 0, 49)
            if json.loads(r).get("author") == agent
        )
        honeypot = sum(
            1 for r in self.redis.lrange("kernell:immune:honeypot_access", 0, 99)
            if json.loads(r).get("agent") == agent
        )
        total = guard_viol + l0_viol * 5 + honeypot * 20
        return max(0.0, 100 - total * 10)

    def _stability_contribution(self, agent: str) -> float:
        # FIX B-5/B-8: canonical namespace is kernell:agent:{name}:stability_score (singular)
        raw = self.redis.get(f"kernell:agent:{agent}:stability_score")
        return float(raw) if raw else 65.0

    def _is_frozen(self, agent: str) -> bool:
        return bool(self.redis.get(f"kernell:gshi:v2:trust:{agent}:frozen"))

    def _tier(self, trust: float, agent: str) -> str:
        if trust >= 90:
            history = self.redis.lrange(f"kernell:gshi:v2:trust:{agent}:history", 0, 4)
            if len(history) >= 5 and all(json.loads(h).get("trust", 0) >= 90 for h in history):
                return "trusted"
        return "normal" if trust >= 60 else ("watch" if trust >= 40 else "quarantine")

    def _apply_effects(self, profile: AgentTrustV2):
        if profile.trust_score < 40:
            self.redis.sadd("kernell:immune:quarantined_agents", profile.agent_name)
            self.redis.set(f"kernell:immune:quarantine:{profile.agent_name}", json.dumps({
                "agent": profile.agent_name, "reason": f"TrustScore {profile.trust_score:.1f} < 40",
                "auto": True, "quarantined_at": profile.timestamp,
            }), ex=3600)
        if profile.trust_score < 60:
            self.redis.set(f"kernell:gshi:trust_weight_reduction:{profile.agent_name}", "0.75", ex=3600)
        if profile.tier == "trusted":
            self.redis.sadd("kernell:pfe:l1_eligible_agents", profile.agent_name)
        else:
            self.redis.srem("kernell:pfe:l1_eligible_agents", profile.agent_name)

    def _persist(self, profile: AgentTrustV2):
        data = asdict(profile)
        self.redis.set(f"kernell:gshi:v2:trust:{profile.agent_name}", json.dumps(data))
        self.redis.lpush(f"kernell:gshi:v2:trust:{profile.agent_name}:history",
                        json.dumps({"trust": profile.trust_score, "tier": profile.tier,
                                   "timestamp": profile.timestamp}))
        self.redis.ltrim(f"kernell:gshi:v2:trust:{profile.agent_name}:history", 0, 49)


# ═══════════════════════════════════════════════════════════════════════════
# GSHI v2 — UNIFICADOR CON EMA
# ═══════════════════════════════════════════════════════════════════════════

@dataclass
class GSHIv2Report:
    gshi_raw: float         # Cálculo instantáneo
    gshi_ema: float         # Media móvil exponencial (valor efectivo)
    interpretation: str
    sii: float
    mean_trust: float
    sci: float
    economic_stability: float
    pfe_scope_allowed: str  # "FULL" | "L2_MINOR" | "BLOCKED"
    triggered_actions: list
    overseer_validated: bool
    timestamp: str


class GSHIv2:
    """
    GSHI v2 con EMA anti-manipulación y validación de Overseer.
    """

    def __init__(self, redis_client: redis.Redis, system_secret: str):
        self.redis = redis_client
        self.sci_engine   = SCIv2(redis_client)
        self.trust_system = TrustSystemV2(redis_client, system_secret)
        self._secret = system_secret.encode()

    def calculate(self, sii: float) -> GSHIv2Report:
        """
        Args:
            sii: System Immunity Index (calculado por SIIEngine)
        """
        self.trust_system.calculate_all()
        sci_report = self.sci_engine.calculate()

        mean_trust = self.trust_system.mean_trust()
        sci        = sci_report.sci
        eco_stab   = self._economic_stability()

        gshi_raw = (
            0.40 * sii
            + 0.30 * mean_trust
            + 0.20 * (100 - sci)
            + 0.10 * eco_stab
        )
        gshi_raw = round(gshi_raw, 2)

        # Aplicar EMA
        gshi_ema = self._apply_ema(gshi_raw)

        # Determinar scope PFE basado en GSHI efectivo
        if gshi_ema >= 55:
            pfe_scope = "FULL"
        elif gshi_ema >= 40:
            pfe_scope = "L2_MINOR"
        else:
            pfe_scope = "BLOCKED"

        interpretation    = self._interpret(gshi_ema)
        triggered_actions = self._apply_rules(gshi_ema)

        report = GSHIv2Report(
            gshi_raw=gshi_raw,
            gshi_ema=round(gshi_ema, 2),
            interpretation=interpretation,
            sii=round(sii, 2),
            mean_trust=round(mean_trust, 2),
            sci=sci,
            economic_stability=round(eco_stab, 2),
            pfe_scope_allowed=pfe_scope,
            triggered_actions=triggered_actions,
            overseer_validated=True,  # Se actualiza por Overseer Beta
            timestamp=datetime.now(timezone.utc).isoformat(),
        )

        self._persist(report)

        logger.info(
            f"[GSHI v2] raw={gshi_raw:.1f} ema={gshi_ema:.1f} "
            f"({interpretation}) PFE={pfe_scope}"
        )

        return report

    def _apply_ema(self, new_value: float) -> float:
        """Exponential Moving Average — suaviza manipulación puntual.
        FIX B-6/B-7: old loop applied alpha cumulatively (weight = 0.3^10 ≈ 0)
        which made GSHI static. Now uses standard EMA formula."""
        history_raw = self.redis.lrange("kernell:gshi:v2:history", 0, EMA_HISTORY_N - 1)
        if not history_raw:
            return new_value

        history = [json.loads(h).get("gshi_raw", new_value) for h in history_raw]

        # Standard EMA: start from oldest, walk forward, newest = new_value
        # This gives newest data weight α, and properly decays older data
        values = list(reversed(history)) + [new_value]
        ema = values[0]
        for val in values[1:]:
            ema = EMA_ALPHA * val + (1 - EMA_ALPHA) * ema

        return round(ema, 2)

    def validate_from_overseer(self, overseer_gshi: float) -> bool:
        """Overseer Beta recalcula GSHI. Si difiere > 10% → congelar."""
        raw = self.redis.get("kernell:gshi:v2:current")
        if not raw:
            return True
        current = json.loads(raw).get("gshi_ema", 0)
        diff = abs(current - overseer_gshi) / max(current, 1)

        if diff > GSHI_DIVERGENCE_MAX:
            self.redis.set("kernell:gshi:v2:frozen", json.dumps({
                "frozen": True, "current": current, "overseer": overseer_gshi,
                "diff_pct": round(diff * 100, 2),
                "frozen_at": datetime.now(timezone.utc).isoformat(),
            }), ex=1800)
            logger.error(f"[GSHI v2] CONGELADO: {current:.1f} vs overseer {overseer_gshi:.1f} ({diff:.0%})")
            return False
        return True

    def _economic_stability(self) -> float:
        raw = self.redis.get("kernell:economy:state")
        if raw:
            econ = json.loads(raw)
            if econ.get("kill_switch"):
                return 10.0
            roi = econ.get("roi_7d", 0)
            if roi > 10:    return 100.0
            elif roi > 5:   return 85.0
            elif roi > 0:   return 65.0
            elif roi > -5:  return 45.0
            else:           return 15.0
        return 55.0

    def _interpret(self, gshi: float) -> str:
        if gshi >= 90:   return "ANTIFRAGILE"
        elif gshi >= 75: return "ROBUST"
        elif gshi >= 60: return "VULNERABLE"
        elif gshi >= 40: return "HIGH_RISK"
        else:            return "SYSTEMIC_RISK"

    def _apply_rules(self, gshi: float) -> list:
        actions = []
        if gshi < 45:
            self.redis.set("kernell:safe_mode:force_stress", "true")
            actions.append(f"STRESS_FORCED")
        if gshi < 55:
            self.redis.set("kernell:pfe:scope_restriction", "L2_MINOR_ONLY")
            self.redis.set("kernell:nemesis:risk_multiplier", "0.5")
            actions.extend(["PFE_L2_MINOR_ONLY", "NEMESIS_RISK_50PCT"])
        if gshi < 70:
            self.redis.set("kernell:red_team:intensity", "HIGH")
            actions.append("RED_TEAM_HIGH")
        return actions

    def _persist(self, report: GSHIv2Report):
        self.redis.set("kernell:gshi:v2:current", json.dumps(asdict(report)))
        self.redis.lpush("kernell:gshi:v2:history", json.dumps({
            "gshi_raw": report.gshi_raw,
            "gshi_ema": report.gshi_ema,
            "timestamp": report.timestamp,
        }))
        self.redis.ltrim("kernell:gshi:v2:history", 0, EMA_HISTORY_N + 5)
