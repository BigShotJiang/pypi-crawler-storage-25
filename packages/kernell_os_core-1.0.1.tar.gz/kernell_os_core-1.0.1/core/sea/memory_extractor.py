#!/usr/bin/env python3
"""
core/sea/memory_extractor.py
════════════════════════════
Sub-sistema de Extracción de Memoria en Background (Archivist V2).
Extrae y consolida memorias de conversación en archivos semánticos tipados.

Funcionalidad:
Toma el contexto de la conversación actual (messages array), hace un fork
en un hilo secundario y llama a un modelo rápido (ej. gemini_flash) para 
consolidar y organizar memorias en archivos semánticos (user_role.md, project.md).
Todo sin consumir tokens ni enlentecer al agente principal.
"""

import json
import logging
import threading
import os
from pathlib import Path

logger = logging.getLogger("MemoryExtractor")

# Directorio donde se guardarán las memorias de Kernell OS
MEMORY_BASE = Path(os.getenv("KERNELL_BRAIN_DIR", str(Path.home() / ".gemini" / "kernell")))
MEMORY_DIR = MEMORY_BASE / "knowledge" / "semantic_memory"
MEMORY_DIR.mkdir(parents=True, exist_ok=True)

MEMORY_FILES = {
    "user_role.md": "Preferencias de diseño del usuario (Themes, estetica premium), directivas recurrentes y su rol como Architect.",
    "project_status.md": "Estado general del proyecto actual (Kernell OS), arquitectura actual y goals activos a corto plazo.",
    "nemesis_state.md": "Reglas de trading de Nemesis, comportamiento del MT5, logs criticos operativos.",
}

EXTRACTOR_SYSTEM_PROMPT = """You are the Kernell OS Archivist (V2).
Your single purpose is to analyze the recent conversation context of this agent
and extract semantic, long-term memories that should be persisted for future sessions.

You MUST format your output STRICTLY as a JSON array where each element contains:
{
  "file": "filename.md",
  "content": "The exact updated markdown content to save. You must merge new info with what you deduce the current state is."
}

Available files to update:
""" + "\n".join([f"- {k}: {v}" for k, v in MEMORY_FILES.items()]) + """

Rules:
1. Extract ONLY high-value, persistent information (auth tokens, design guidelines like "use dark mode with glassmorphism everywhere", critical bugs).
2. Do NOT extract transient errors or generic code snippets unless they are standing blockers.
3. Keep the content of the files extremely brief, concise, using lists and bold texts.
4. If there are no new memories to extract or update, output an empty JSON array: []
5. Reply ONLY with the JSON array.
"""

def extract_memories_sync(messages: list[dict], agent_name: str, redis_client=None):
    """
    Job asíncrono para abstraer memorias.
    V2: Delega a MemoryDirectory si está disponible.
    """
    # V2 path: use MemoryDirectory (typed, with MEMORY.md index)
    try:
        from core.memory.memory_directory import MemoryDirectory
        memdir = MemoryDirectory()
        memdir._distill_sync(messages, agent_name, redis_client)
        logger.info(f"[{agent_name}] Archivist V2: Delegated to MemoryDirectory (V2 path)")
        return
    except ImportError:
        pass  # fallback to V1
    except Exception as e:
        logger.warning(f"[{agent_name}] MemoryDirectory delegation failed, falling back to V1: {e}")

    # V1 path: original file-based extraction
    try:
        from core.sea.llm_registry import LLMProviderRegistry
        
        if not redis_client:
            import redis
            # Intentar reconectar si falla el paso por referencia
            redis_client = redis.Redis(host='127.0.0.1', port=6379, decode_responses=True)
            
        registry = LLMProviderRegistry(redis_client)
        
        # Filtramos los últimos 30 mensajes para bajar costo y enfocar en novedad
        recent = messages[-30:] if len(messages) > 30 else messages
        
        context_str = ""
        for m in recent:
            role = m.get("role", "unknown")
            # Extraer contenido (puede ser str o lista de dicts si tiene herramientas)
            raw = m.get("content", "")
            if isinstance(raw, list):
                s = []
                for b in raw:
                    if b.get("type") == "text": s.append(b.get("text", ""))
                content = "\n".join(s)
            else:
                content = str(raw)
            
            # Cortar si es un log masivo
            if len(content) > 2000:
                content = content[:2000] + "... [TRUNCATED]"
                
            context_str += f"[{role.upper()}]:\n{content}\n\n"
            
        payload = [
            {"role": "user", "content": f"Analyze the following conversation from Agent '{agent_name}' and extract updates:\n\n{context_str}"}
        ]
        
        logger.info(f"[{agent_name}] Archivist V2: Iniciando extracción asíncrona de contexto (V1 path)...")
        
        # Invocamos al LLM con modelo 'gemini_flash' o 'groq_r1' para inferencia rápida
        resp = registry.complete(
            messages=payload,
            system_prompt=EXTRACTOR_SYSTEM_PROMPT,
            role="fallback_any",
            preferred_provider="gemini_flash", # Fast, high context window
            max_tokens=4000
        )
        
        if not resp or not resp.content:
            logger.warning(f"[{agent_name}] Archivist V2: Completición vacía o error.")
            return

        content = resp.content.strip()
        if content.startswith("```json"):
            content = content[7:-3].strip()
        elif content.startswith("```"):
            content = content[3:-3].strip()
            
        # Si no hay data vacia literal
        if content == "[]":
            logger.info(f"[{agent_name}] Archivist V2: No hay nuevas memorias (Vacío).")
            return
            
        try:
            updates = json.loads(content)
            if not isinstance(updates, list):
                logger.error(f"[{agent_name}] Archivist V2: El resultado no es una lista JSON.")
                return
                
            for update in updates:
                filename = update.get("file")
                file_content = update.get("content")
                
                if filename in MEMORY_FILES and file_content:
                    filepath = MEMORY_DIR / filename
                    
                    # Leer archivo existente para loggear diff si deseamos (opcional)
                    # Aquí lo sobrescribimos directamente porque el prompt le pide merge
                    with open(filepath, "w", encoding="utf-8") as f:
                        f.write(file_content)
                    logger.info(f"[{agent_name}] 💾 Archivist V2: Conocimiento destilado guardado en -> {filename}")
                    
        except json.JSONDecodeError as je:
            logger.error(f"[{agent_name}] Archivist V2 Error parseando JSON: {je}")
            
    except Exception as e:
        logger.error(f"[{agent_name}] Error en Archivist V2 extract_memories_sync: {e}")

def trigger_background_extraction(messages: list[dict], agent_name: str, redis_client=None):
    """
    Dispara la extracción de forma no bloqueante (Fire and forget).
    V2: Prefers MemoryDirectory for typed memory with MEMORY.md index.
    """
    # Copia simple del arreglo por seguridad
    msg_copy = list(messages)
    thread = threading.Thread(
        target=extract_memories_sync,
        args=(msg_copy, agent_name, redis_client),
        daemon=True # Muere si el agente principal muere
    )
    thread.start()

