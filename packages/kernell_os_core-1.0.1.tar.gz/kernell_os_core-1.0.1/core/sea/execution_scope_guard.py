"""
EXECUTION SCOPE GUARD — Agent Permission Enforcement
=====================================================
Enforces agent authority levels and scope permissions
as defined in core/ontology.yaml.

Each agent has:
  - authority_level: 1-5 (1=lowest, 5=Kernell only)
  - allowed_actions: list of actions the agent can perform
  - forbidden_paths: file paths the agent cannot touch
  - scope: what Redis channels and namespaces the agent can access

Guard actions:
  - validate_action(agent, action, target) → bool
  - validate_file_access(agent, file_path) → bool
  - validate_redis_scope(agent, redis_key) → bool
"""

import json
import logging
import redis
from typing import Optional

logger = logging.getLogger("sea.scope_guard")


# Agent scope definitions (derived from ontology.yaml v13.1)
AGENT_SCOPES = {
    "kernell": {
        "authority": 5,
        "can_write": ["**"],
        "can_read": ["**"],
        "redis_ns": ["kernell:*"],
    },
    "atlas": {
        "authority": 4,
        "can_write": ["agents/atlas/**", "data/snapshots/**"],
        "can_read": ["**"],
        "redis_ns": ["kernell:srs:*", "kernell:agent:*", "kernell:gshi:*"],
        "forbidden_writes": ["core/constitution.yaml", "core/ontology.yaml"],
    },
    "overseer": {
        "authority": 4,
        "can_write": ["data/overseer/**", "logs/**"],
        "can_read": ["**"],
        "redis_ns": ["kernell:overseer:*", "kernell:audit:*"],
        "forbidden_writes": ["core/constitution.yaml"],
    },
    "sentinel": {
        "authority": 3,
        "can_write": ["agents/sentinel/**", "data/security/**"],
        "can_read": ["**"],
        "redis_ns": ["kernell:security:*", "kernell:sentinel:*", "kernell:defcon:*"],
        "forbidden_writes": ["core/**"],
    },
    "sierra": {
        "authority": 3,
        "can_write": ["agents/core/verifier*", "data/verification/**"],
        "can_read": ["**"],
        "redis_ns": ["kernell:svs:*", "kernell:sierra:*", "kernell:defcon:*"],
        "forbidden_writes": ["core/**"],
    },
    "forge": {
        "authority": 3,
        "can_write": ["agents/**", "scripts/**"],
        "can_read": ["**"],
        "redis_ns": ["kernell:forge:*", "kernell:salus:*"],
        "forbidden_writes": ["core/constitution.yaml", "core/ontology.yaml"],
    },
    "nemesis": {
        "authority": 2,
        "can_write": ["agents/nemesis/**"],
        "can_read": ["agents/nemesis/**", "core/ontology.yaml"],
        "redis_ns": ["kernell:nemesis:*", "kernell:economy:*"],
        "forbidden_writes": ["core/**", "agents/*/core.py"],
    },
    "economy": {
        "authority": 3,
        "can_write": ["agents/economy/**", "data/economy/**"],
        "can_read": ["**"],
        "redis_ns": ["kernell:economy:*", "kernell:nemesis:pnl:*"],
    },
    "chronos": {
        "authority": 2,
        "can_write": ["agents/chronos/**"],
        "can_read": ["**"],
        "redis_ns": ["kernell:chronos:*", "kernell:network:*", "kernell:tasks:*"],
    },
}

# Default restrictive scope for unknown agents
DEFAULT_SCOPE = {
    "authority": 1,
    "can_write": [],
    "can_read": [],
    "redis_ns": [],
    "forbidden_writes": ["core/**", "agents/core/**"],
}


class ExecutionScopeGuard:
    """
    Technical enforcement of agent authority levels and permissions.
    Prevents agents from operating outside their defined scope.
    """

    def __init__(self, redis_client: redis.Redis):
        self.redis = redis_client

    def validate_action(
        self, agent: str, action: str, target: str, required_authority: int = 1
    ) -> tuple[bool, str]:
        """
        Validate whether an agent can perform an action.
        
        Returns: (allowed, reason)
        """
        scope = AGENT_SCOPES.get(agent, DEFAULT_SCOPE)

        if scope["authority"] < required_authority:
            reason = (
                f"Agent '{agent}' authority={scope['authority']} "
                f"< required={required_authority}"
            )
            self._log_violation(agent, action, target, reason)
            return False, reason

        return True, "OK"

    def validate_file_access(
        self, agent: str, file_path: str, write: bool = False
    ) -> tuple[bool, str]:
        """
        Validate file read/write access for an agent.
        Uses glob-like matching against scope definitions.
        """
        scope = AGENT_SCOPES.get(agent, DEFAULT_SCOPE)

        # Check forbidden writes first
        if write and "forbidden_writes" in scope:
            for pattern in scope["forbidden_writes"]:
                if self._glob_match(file_path, pattern):
                    reason = f"Agent '{agent}' forbidden to write: {file_path}"
                    self._log_violation(agent, "file_write", file_path, reason)
                    return False, reason

        # Check allowed access
        access_list = scope["can_write"] if write else scope["can_read"]
        for pattern in access_list:
            if self._glob_match(file_path, pattern):
                return True, "OK"

        reason = (
            f"Agent '{agent}' lacks {'write' if write else 'read'} "
            f"access to {file_path}"
        )
        self._log_violation(agent, "file_access", file_path, reason)
        return False, reason

    def validate_redis_scope(self, agent: str, redis_key: str) -> tuple[bool, str]:
        """Validate Redis key access for an agent."""
        scope = AGENT_SCOPES.get(agent, DEFAULT_SCOPE)

        for pattern in scope["redis_ns"]:
            if self._glob_match(redis_key, pattern):
                return True, "OK"

        reason = f"Agent '{agent}' cannot access Redis key: {redis_key}"
        self._log_violation(agent, "redis_access", redis_key, reason)
        return False, reason

    def get_agent_authority(self, agent: str) -> int:
        return AGENT_SCOPES.get(agent, DEFAULT_SCOPE)["authority"]

    @staticmethod
    def _glob_match(path: str, pattern: str) -> bool:
        """Simple glob matching: * matches segment, ** matches everything."""
        if pattern == "**":
            return True

        import fnmatch
        if "**" in pattern:
            pattern = pattern.replace("**", "*")
            return fnmatch.fnmatch(path, pattern)

        return fnmatch.fnmatch(path, pattern)

    def _log_violation(self, agent: str, action: str, target: str, reason: str):
        logger.warning(f"[SCOPE VIOLATION] {agent}/{action}: {reason}")
        self.redis.lpush("kernell:scope:violations", json.dumps({
            "agent": agent,
            "action": action,
            "target": target,
            "reason": reason,
            "timestamp": __import__("datetime").datetime.now(
                __import__("datetime").timezone.utc
            ).isoformat(),
        }))
        self.redis.ltrim("kernell:scope:violations", 0, 99)
