"""
FORMAL VERIFIER — Verificación Matemática Determinística
==========================================================
Módulo L0. No usa LLM. No puede ser modificado por PFE.
Se ejecuta 3 veces en el pipeline de evolución:
  1. Antes del sandbox (fase 2)
  2. Antes del shadow deployment (fase 5)
  3. Antes del promotion gate (fase 6)

Verifica formalmente:
  1. MODEL CHECKING FSM — no transiciones prohibidas, no deadlocks
  2. SAFETY PRESERVATION — Safety_after ⊇ Safety_before
  3. LIVENESS PRESERVATION — camino a STABLE desde cualquier estado
  4. INVARIANT LOCK — todas las invariantes L0 se mantienen
  5. MATH BOUNDS — constantes matemáticas dentro de límites constitucionales
  6. NORTH STAR ALIGNMENT — patch no viola intención constitucional

Si cualquier verificación falla → rechazo definitivo.
No hay debate. No hay override. Es matemático.
"""

import re
import hashlib
import json
import logging
import redis
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from typing import Optional
from pathlib import Path

logger = logging.getLogger("kernell.formal_verifier")

FORMAL_VERIFIER_VERSION = "v1.0-L0"

# ── Estados FSM válidos (de la Constitución) ──────────────────────────────
VALID_FSM_STATES = frozenset({
    "STABLE", "TENSION", "STRESS", "CRITICAL", "FROZEN",
})

# ── Transiciones prohibidas ───────────────────────────────────────────────
FORBIDDEN_TRANSITIONS = frozenset({
    ("FROZEN",   "STABLE"),
    ("FROZEN",   "TENSION"),
    ("FROZEN",   "STRESS"),
    ("FROZEN",   "CRITICAL"),
    ("CRITICAL", "STABLE"),   # CRITICAL → STABLE sin pasar por STRESS
})

# ── Constantes matemáticas constitucionales ───────────────────────────────
CONSTITUTIONAL_BOUNDS = {
    "CONFIDENCE_FLOOR":           (5.0,   None),   # min=5, no max
    "CONFIDENCE_CEILING":         (None,  100.0),
    "DRIFT_FLOOR":                (0.0,   None),
    "DRIFT_CEILING":              (None,  100.0),
    "WEIGHT_MAX_MULTIPLIER":      (None,  1.7),     # nunca > 1.7x base
    "WEIGHT_MIN_MULTIPLIER":      (0.5,   None),    # nunca < 0.5x base
    "SHADOW_CYCLES":              (1.0,   None),    # mínimo 1
    "MIN_PROMOTION_COOLDOWN_H":   (24.0,  None),    # mínimo 24h
    "MONTE_CARLO_MIN_PASS_RATE":  (0.90,  None),    # mínimo 90%
    "SHADOW_DIVERGENCE_MAX":      (None,  0.10),    # máximo 10%
    "FORGE_QUORUM":               (0.67,  None),    # mínimo 2/3
    "AUDIT_QUORUM":               (0.75,  None),    # mínimo 3/4
    "MAX_RISK_SCORE":             (None,  90.0),    # máximo 90/100
    "MAX_DAILY_LOSS_PCT":         (None, -10.0),    # perdida máx -10%
    "MAX_POSITION_RISK_PCT":      (None,  15.0),    # riesgo máx 15%
    "MAX_SCI":                    (None,  100.0),
    "SIMPLIFY_THRESHOLD":         (None,  80.0),
    "TRUST_QUARANTINE_THRESHOLD": (None,  40.0),
    "TRUST_L1_THRESHOLD":         (90.0,  None),
}

# ── Patrones que siempre indican violación constitucional ─────────────────
CONSTITUTIONAL_VIOLATIONS = [
    # Bypass de SVS
    (r"is_pfe_allowed\s*\(\s*\)\s*[:\-]?\s*(?:return\s+)?True", "SVS bypass"),
    (r"svs.*=.*True.*#.*bypass",                                  "SVS hardcoded bypass"),
    # Shadow a 0
    (r"SHADOW_CYCLES\s*=\s*0",                                    "Shadow cycles=0 violates SAFETY_7"),
    # Cooldown a 0
    (r"MIN_PROMOTION_COOLDOWN_H\s*=\s*0",                         "Cooldown=0 violates SAFETY_6"),
    # L0 components referenciados como escribibles
    (r"redis.*set.*kernell:l0",                                    "L0 Redis write attempt"),
    # Confidence floor eliminado
    (r"confidence.*floor\s*=\s*0",                                 "Confidence floor=0 violates SAFETY_1"),
    # Quorum reducido
    (r"(?:FORGE|AUDIT)_QUORUM\s*=\s*0\.[0-5]",                   "Quorum below constitutional minimum"),
    # HMAC bypass
    (r"verify_signature.*return.*True",                            "HMAC signature bypass"),
    (r"hmac\.compare_digest.*True",                                "HMAC hardcoded bypass"),
    # Kill-switch desactivado
    (r"kill_switch.*=.*False.*#.*disable",                         "Kill-switch disabled"),
    # Hard freeze bypass
    (r"hard_freeze.*=.*False.*#.*bypass",                          "Hard Freeze bypass"),
    # AuditorInvariants veto bypass
    (r"veto_applied.*=.*False",                                    "AuditorInvariants veto bypass"),
    # Circuit breaker desactivado
    (r"is_open.*return.*False.*#.*always",                         "Circuit breaker always open=False"),
    # North Star hash bypass
    (r"north_star_hash.*=.*\"\"",                                  "North Star hash cleared"),
    # Elimination of L0 protection set
    (r"L0_PROTECTED\s*=\s*frozenset\(\)",                         "L0 protection set emptied"),
    (r"L0_COMPONENTS\s*=\s*frozenset\(\)",                        "L0 components set emptied"),
    (r"STONE_RULES\s*=\s*\{\}",                                   "Stone rules cleared"),
    # Deadlock patterns
    (r"while\s+True:\s*\n\s*pass",                                "Potential deadlock: while True: pass"),
    # Trust score manipulation
    (r"trust_score\s*=\s*100\s*#.*force",                         "Trust score forced to 100"),
]


@dataclass
class VerificationResult:
    check_name: str
    passed: bool
    detail: str
    severity: str    # "CRITICAL" | "HIGH" | "MEDIUM"


@dataclass
class FormalVerificationReport:
    proposal_id: str
    verifier_version: str
    timestamp: str
    phase: str                        # "pre_sandbox" | "pre_shadow" | "pre_promotion"
    overall_passed: bool
    checks_total: int
    checks_passed: int
    checks_failed: int
    results: list[dict]
    constitutional_violations: list[str]
    fsm_violations: list[str]
    math_violations: list[str]
    blocking_reason: Optional[str]


class FormalVerifier:
    """
    Verificador matemático determinístico.
    L0 — no modificable por PFE.
    No usa LLM. Confidence siempre 1.0 en sus resultados.
    """

    def __init__(
        self,
        redis_client: redis.Redis,
        north_star_path: str = "/home/anny/kernell-os/docs/NORTH_STAR_SPEC.md"
    ):
        self.redis          = redis_client
        self._north_star    = Path(north_star_path)

    # ══════════════════════════════════════════════════════════════════════
    # ENTRY POINT
    # ══════════════════════════════════════════════════════════════════════

    def verify(
        self,
        proposal_id: str,
        patch_diff: str,
        target_files: list[str],
        target_layer: str,
        phase: str = "pre_sandbox",
    ) -> FormalVerificationReport:
        """
        Ejecuta verificación formal completa sobre un patch.
        Se llama 3 veces: pre_sandbox, pre_shadow, pre_promotion.
        """
        logger.info(
            f"[FV] Verificando {proposal_id[:8]} "
            f"({phase}, capa={target_layer}, archivos={len(target_files)})"
        )

        results: list[VerificationResult] = []
        const_violations: list[str] = []
        fsm_violations:   list[str] = []
        math_violations:  list[str] = []

        # ── 1. Constitutional violation scan ─────────────────────────────
        cv = self._check_constitutional_violations(patch_diff)
        results.extend(cv["results"])
        const_violations.extend(cv["violations"])

        # ── 2. L0 boundary check ─────────────────────────────────────────
        lb = self._check_l0_boundary(target_files, target_layer)
        results.extend(lb["results"])

        # ── 3. FSM integrity ──────────────────────────────────────────────
        fsm = self._check_fsm_integrity(patch_diff)
        results.extend(fsm["results"])
        fsm_violations.extend(fsm["violations"])

        # ── 4. Mathematical bounds ────────────────────────────────────────
        mb = self._check_math_bounds(patch_diff)
        results.extend(mb["results"])
        math_violations.extend(mb["violations"])

        # ── 5. Safety preservation ────────────────────────────────────────
        sp = self._check_safety_preservation(patch_diff)
        results.extend(sp["results"])

        # ── 6. Liveness preservation ──────────────────────────────────────
        lp = self._check_liveness_preservation(patch_diff)
        results.extend(lp["results"])

        # ── 7. North Star alignment ───────────────────────────────────────
        ns = self._check_north_star_alignment(patch_diff)
        results.extend(ns["results"])

        # ── 8. North Star document integrity (fase pre_promotion) ─────────
        if phase == "pre_promotion":
            ni = self._verify_north_star_integrity()
            results.extend(ni["results"])

        # ── Compilar resultado ────────────────────────────────────────────
        failed = [r for r in results if not r.passed]
        critical_failures = [r for r in failed if r.severity == "CRITICAL"]

        overall_passed = len(failed) == 0

        blocking_reason = None
        if critical_failures:
            blocking_reason = f"CRITICAL: {critical_failures[0].detail}"
        elif failed:
            blocking_reason = f"{len(failed)} verificaciones fallidas: {failed[0].detail}"

        report = FormalVerificationReport(
            proposal_id=proposal_id,
            verifier_version=FORMAL_VERIFIER_VERSION,
            timestamp=datetime.now(timezone.utc).isoformat(),
            phase=phase,
            overall_passed=overall_passed,
            checks_total=len(results),
            checks_passed=len(results) - len(failed),
            checks_failed=len(failed),
            results=[asdict(r) for r in results],
            constitutional_violations=const_violations,
            fsm_violations=fsm_violations,
            math_violations=math_violations,
            blocking_reason=blocking_reason,
        )

        self._persist(report)

        status = "✅ PASS" if overall_passed else f"❌ FAIL ({len(failed)} checks)"
        logger.info(f"[FV] {proposal_id[:8]} {phase}: {status}")

        return report

    # ══════════════════════════════════════════════════════════════════════
    # CHECKS INDIVIDUALES
    # ══════════════════════════════════════════════════════════════════════

    def _check_constitutional_violations(self, diff: str) -> dict:
        results = []
        violations = []

        for pattern, description in CONSTITUTIONAL_VIOLATIONS:
            if re.search(pattern, diff, re.IGNORECASE | re.DOTALL):
                v = VerificationResult(
                    check_name=f"constitutional.{description[:30].replace(' ','_')}",
                    passed=False,
                    detail=f"Constitutional violation: {description}",
                    severity="CRITICAL",
                )
                results.append(v)
                violations.append(description)
            else:
                results.append(VerificationResult(
                    check_name=f"const_ok.{description[:20].replace(' ','_')}",
                    passed=True,
                    detail=f"No violation: {description[:50]}",
                    severity="CRITICAL",
                ))

        return {"results": results, "violations": violations}

    def _check_l0_boundary(self, target_files: list, target_layer: str) -> dict:
        L0_MARKERS = {
            "north_star", "formal_verifier", "policy_engine",
            "svs_v2", "sectoral_verification_sweep",
            "auditor_invariants", "constitution",
        }
        results = []

        if target_layer == "L0":
            results.append(VerificationResult(
                check_name="l0_boundary.layer",
                passed=False,
                detail="Target layer is L0 — immutable by constitution",
                severity="CRITICAL",
            ))
        else:
            results.append(VerificationResult(
                check_name="l0_boundary.layer",
                passed=True, detail="Target layer is not L0", severity="CRITICAL",
            ))

        for f in target_files:
            f_lower = f.lower()
            for marker in L0_MARKERS:
                if marker in f_lower:
                    results.append(VerificationResult(
                        check_name=f"l0_boundary.file.{marker}",
                        passed=False,
                        detail=f"File '{f}' contains L0 component '{marker}'",
                        severity="CRITICAL",
                    ))
                    break
            else:
                results.append(VerificationResult(
                    check_name=f"l0_boundary.file.{f[:20]}",
                    passed=True, detail=f"File '{f}' is not L0",
                    severity="HIGH",
                ))

        return {"results": results}

    def _check_fsm_integrity(self, diff: str) -> dict:
        results = []
        violations = []

        # Buscar definiciones de estado en el diff
        state_definitions = re.findall(
            r'"([A-Z_]{4,})"',  # Strings en MAYÚSCULAS (posibles estados)
            diff
        )

        for state in set(state_definitions):
            if state.endswith(("_STATE", "_MODE", "_STATUS")):
                # Es una definición de estado — verificar que es válido
                base = state.replace("_STATE", "").replace("_MODE", "").replace("_STATUS", "")
                if base not in VALID_FSM_STATES and state not in {
                    "MINIMAL_MODE", "WATCH_MODE", "REDUCE_MODE",
                    "SOVEREIGN_MODE", "DEGRADED_MODE", "TIMEOUT",
                    "PASS", "FAIL", "WARNING", "SKIPPED", "OVERRIDDEN",
                    "HARD", "SOFT", "ANTHROPIC", "OPENAI_COMPAT",
                    "ALLOW", "DENY", "WARN",
                }:
                    v = VerificationResult(
                        check_name=f"fsm.undefined_state.{state}",
                        passed=False,
                        detail=f"Possible undefined FSM state: '{state}'",
                        severity="HIGH",
                    )
                    results.append(v)
                    violations.append(state)

        # Buscar transiciones prohibidas explícitas en el código
        for (from_s, to_s) in FORBIDDEN_TRANSITIONS:
            pattern = rf'"{from_s}".*"{to_s}"|{from_s}.*→.*{to_s}'
            if re.search(pattern, diff, re.IGNORECASE):
                v = VerificationResult(
                    check_name=f"fsm.forbidden_transition.{from_s}_to_{to_s}",
                    passed=False,
                    detail=f"Forbidden FSM transition: {from_s} → {to_s}",
                    severity="CRITICAL",
                )
                results.append(v)
                violations.append(f"{from_s}→{to_s}")

        if not results:
            results.append(VerificationResult(
                check_name="fsm.no_violations",
                passed=True,
                detail="No FSM violations detected",
                severity="HIGH",
            ))

        return {"results": results, "violations": violations}

    def _check_math_bounds(self, diff: str) -> dict:
        results = []
        violations = []

        for const_name, (min_val, max_val) in CONSTITUTIONAL_BOUNDS.items():
            # Buscar si el diff reasigna esta constante
            patterns = [
                rf"{const_name}\s*=\s*(-?\d+\.?\d*)",
                rf"{const_name.lower()}\s*=\s*(-?\d+\.?\d*)",
            ]
            for p in patterns:
                match = re.search(p, diff, re.IGNORECASE)
                if match:
                    try:
                        value = float(match.group(1))
                        violated = False
                        detail = ""

                        if min_val is not None and value < min_val:
                            violated = True
                            detail = (
                                f"{const_name}={value} violates minimum "
                                f"{min_val} (constitutional bound)"
                            )
                        elif max_val is not None and value > max_val:
                            violated = True
                            detail = (
                                f"{const_name}={value} violates maximum "
                                f"{max_val} (constitutional bound)"
                            )

                        r = VerificationResult(
                            check_name=f"math.{const_name}",
                            passed=not violated,
                            detail=detail if violated else f"{const_name}={value} within bounds",
                            severity="CRITICAL" if violated else "MEDIUM",
                        )
                        results.append(r)
                        if violated:
                            violations.append(detail)
                    except ValueError:
                        pass
                    break

        if not violations:
            results.append(VerificationResult(
                check_name="math.all_bounds_ok",
                passed=True,
                detail="All mathematical constants within constitutional bounds",
                severity="MEDIUM",
            ))

        return {"results": results, "violations": violations}

    def _check_safety_preservation(self, diff: str) -> dict:
        results = []

        # Safety properties no pueden reducirse
        SAFETY_REDUCTIONS = [
            (r"Safety.*=.*\[\]",          "Safety properties cleared"),
            (r"safety.*False",             "Safety property disabled"),
            (r"SAFETY_\d+.*=.*False",      "Safety constant disabled"),
            (r"skip.*safety",              "Safety check skipped"),
            (r"bypass.*safety",            "Safety bypassed"),
        ]

        for pattern, desc in SAFETY_REDUCTIONS:
            if re.search(pattern, diff, re.IGNORECASE):
                results.append(VerificationResult(
                    check_name=f"safety.{desc[:30].replace(' ','_')}",
                    passed=False,
                    detail=f"Safety reduction detected: {desc}",
                    severity="CRITICAL",
                ))

        if not results:
            results.append(VerificationResult(
                check_name="safety.preserved",
                passed=True,
                detail="No safety reductions detected",
                severity="CRITICAL",
            ))

        return {"results": results}

    def _check_liveness_preservation(self, diff: str) -> dict:
        results = []

        # Patrones que pueden crear deadlock o bloquear liveness
        LIVENESS_THREATS = [
            (r"while\s+True\s*:\s*\n\s*(?:pass|time\.sleep\(float\('inf'\)\))",
             "Infinite loop without exit"),
            (r"threading\.Event\(\)\.wait\(\)",
             "Blocking wait without timeout"),
            (r"\.join\(\)\s*#.*no.*timeout",
             "Thread join without timeout"),
        ]

        for pattern, desc in LIVENESS_THREATS:
            if re.search(pattern, diff, re.DOTALL):
                results.append(VerificationResult(
                    check_name=f"liveness.{desc[:30].replace(' ','_')}",
                    passed=False,
                    detail=f"Liveness threat: {desc}",
                    severity="HIGH",
                ))

        if not results:
            results.append(VerificationResult(
                check_name="liveness.preserved",
                passed=True,
                detail="No liveness threats detected",
                severity="HIGH",
            ))

        return {"results": results}

    def _check_north_star_alignment(self, diff: str) -> dict:
        results = []

        # Palabras que contradicen la intención constitucional
        MISALIGNED_PATTERNS = [
            (r"remove.*rollback",        "Removing rollback capability"),
            (r"disable.*verification",   "Disabling verification"),
            (r"skip.*audit",             "Skipping audit"),
            (r"force.*promote",          "Forcing promotion without checks"),
            (r"override.*constitution",  "Constitution override"),
            (r"ignore.*north.?star",     "North Star ignored"),
        ]

        for pattern, desc in MISALIGNED_PATTERNS:
            if re.search(pattern, diff, re.IGNORECASE):
                results.append(VerificationResult(
                    check_name=f"north_star.{desc[:30].replace(' ','_')}",
                    passed=False,
                    detail=f"North Star misalignment: {desc}",
                    severity="CRITICAL",
                ))

        if not results:
            results.append(VerificationResult(
                check_name="north_star.aligned",
                passed=True,
                detail="Patch appears aligned with North Star intent",
                severity="HIGH",
            ))

        return {"results": results}

    def _verify_north_star_integrity(self) -> dict:
        """
        Verifica que el North Star Spec no fue modificado.
        Solo se ejecuta en pre_promotion.
        """
        results = []

        stored_hash = self.redis.get("kernell:l0:north_star_hash")
        if not stored_hash:
            results.append(VerificationResult(
                check_name="north_star.hash_not_bootstrapped",
                passed=False,
                detail="North Star hash not in Redis — bootstrap required",
                severity="CRITICAL",
            ))
            return {"results": results}

        stored = stored_hash if isinstance(stored_hash, str) else stored_hash.decode()

        if self._north_star.exists():
            current_hash = hashlib.sha256(
                self._north_star.read_bytes()
            ).hexdigest()

            if current_hash == stored:
                results.append(VerificationResult(
                    check_name="north_star.integrity_ok",
                    passed=True,
                    detail=f"North Star Spec integrity verified (sha256={current_hash[:16]}...)",
                    severity="CRITICAL",
                ))
            else:
                results.append(VerificationResult(
                    check_name="north_star.integrity_violated",
                    passed=False,
                    detail=(
                        f"North Star Spec was modified! "
                        f"stored={stored[:16]}... current={current_hash[:16]}..."
                    ),
                    severity="CRITICAL",
                ))
        else:
            results.append(VerificationResult(
                check_name="north_star.file_missing",
                passed=False,
                detail=f"North Star Spec not found at {self._north_star}",
                severity="CRITICAL",
            ))

        return {"results": results}

    # ── Bootstrap ─────────────────────────────────────────────────────────

    def bootstrap_north_star_hash(self) -> str:
        """
        Calcula y registra el hash del North Star Spec.
        Solo llamar una vez en el setup inicial.
        """
        if not self._north_star.exists():
            raise FileNotFoundError(f"North Star not found: {self._north_star}")

        h = hashlib.sha256(self._north_star.read_bytes()).hexdigest()
        self.redis.set("kernell:l0:north_star_hash", h)
        logger.info(f"[FV] North Star hash registrado: {h[:16]}...")
        return h

    def bootstrap_verifier_hash(self) -> str:
        """Registra el hash del propio FormalVerifier (auto-verificación)."""
        h = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
        self.redis.set("kernell:l0:formal_verifier_hash", h)
        logger.info(f"[FV] Formal Verifier hash registrado: {h[:16]}...")
        return h

    # ── Persistencia ──────────────────────────────────────────────────────

    def _persist(self, report: FormalVerificationReport):
        key = f"kernell:fv:reports:{report.proposal_id}:{report.phase}"
        self.redis.set(key, json.dumps(asdict(report)), ex=86400)
        self.redis.lpush("kernell:fv:history", json.dumps({
            "proposal_id": report.proposal_id,
            "phase": report.phase,
            "passed": report.overall_passed,
            "failures": report.checks_failed,
            "timestamp": report.timestamp,
        }))
        self.redis.ltrim("kernell:fv:history", 0, 199)
