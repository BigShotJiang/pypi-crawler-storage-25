"""
REALITY REVISION PROTOCOL (RRP) — Structural Mutation Tracker
==============================================================
Tracks ALL structural changes to the system with:
  - Content hashes (before/after)
  - Authority signatures
  - Impact scope classification
  - Risk score
  - Rate limiting (max 1 revision per 30 minutes)
  - Auto-SALUS trigger on high-risk changes
"""

import json
import hmac
import hashlib
import logging
import redis
from datetime import datetime, timezone, timedelta
from dataclasses import dataclass, asdict
from typing import Optional

logger = logging.getLogger("sea.rrp")

MAX_REVISIONS_PER_30MIN = 1
HIGH_RISK_THRESHOLD = 70


@dataclass
class Revision:
    revision_id: str
    author: str
    authority_level: int
    target: str
    description: str
    hash_before: str
    hash_after: str
    impact_scope: str        # "local" | "sector" | "global"
    risk_score: int          # 0-100
    timestamp: str
    signature: str


class RealityRevisionProtocol:
    """
    Formal tracking of all structural mutations.
    Rate-limited and HMAC-signed for integrity.
    """

    def __init__(self, redis_client: redis.Redis, system_secret: str):
        self.redis = redis_client
        self._secret = system_secret.encode()

    def propose_revision(
        self,
        author: str,
        authority_level: int,
        target: str,
        description: str,
        content_before: str,
        content_after: str,
        impact_scope: str = "local",
        risk_score: int = 50,
    ) -> tuple[bool, str]:
        """
        Propose a structural revision. Returns (accepted, reason).
        Rejected if rate limit exceeded or authority insufficient.
        """
        # Rate limit check
        if not self._check_rate_limit():
            return False, f"Rate limit: max {MAX_REVISIONS_PER_30MIN} revisions per 30min"

        # Authority check
        if risk_score > HIGH_RISK_THRESHOLD and authority_level < 4:
            return False, f"High-risk revision (score={risk_score}) requires authority >= 4"

        # Build revision
        hash_before = hashlib.sha256(content_before.encode()).hexdigest()[:16]
        hash_after = hashlib.sha256(content_after.encode()).hexdigest()[:16]
        
        import uuid
        revision_id = str(uuid.uuid4())[:8]
        now = datetime.now(timezone.utc).isoformat()

        sig_data = f"{revision_id}:{author}:{target}:{hash_after}:{now}"
        signature = hmac.new(self._secret, sig_data.encode(), hashlib.sha256).hexdigest()[:16]

        revision = Revision(
            revision_id=revision_id,
            author=author,
            authority_level=authority_level,
            target=target,
            description=description,
            hash_before=hash_before,
            hash_after=hash_after,
            impact_scope=impact_scope,
            risk_score=risk_score,
            timestamp=now,
            signature=signature,
        )

        self._persist(revision)

        # Trigger SALUS on high-risk changes
        if risk_score > HIGH_RISK_THRESHOLD:
            self._trigger_salus(revision)

        logger.info(
            f"[RRP] Revision {revision_id}: {target} by {author} "
            f"(risk={risk_score}, scope={impact_scope})"
        )

        return True, revision_id

    def get_recent(self, count: int = 10) -> list[dict]:
        """Get recent revisions from history."""
        raw_list = self.redis.lrange("kernell:rrp:history", 0, count - 1)
        return [json.loads(r) for r in raw_list]

    def _check_rate_limit(self) -> bool:
        history = self.redis.lrange("kernell:rrp:history", 0, 9)
        now = datetime.now(timezone.utc)
        cutoff = now - timedelta(minutes=30)

        recent = 0
        for raw in history:
            data = json.loads(raw)
            try:
                ts = datetime.fromisoformat(data.get("timestamp", "2000-01-01"))
                if ts > cutoff:
                    recent += 1
            except ValueError:
                pass

        return recent < MAX_REVISIONS_PER_30MIN

    def _trigger_salus(self, revision: Revision):
        self.redis.lpush("kernell:alerts:system", json.dumps({
            "type": "rrp_high_risk",
            "revision_id": revision.revision_id,
            "target": revision.target,
            "risk_score": revision.risk_score,
            "timestamp": revision.timestamp,
        }))
        logger.warning(f"[RRP] High-risk revision {revision.revision_id} — SALUS triggered")

    def _persist(self, revision: Revision):
        data = asdict(revision)
        self.redis.lpush("kernell:rrp:history", json.dumps(data))
        self.redis.ltrim("kernell:rrp:history", 0, 99)
