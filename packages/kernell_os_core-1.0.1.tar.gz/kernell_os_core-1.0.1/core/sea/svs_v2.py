"""
SVS v2 — Sectoral Verification Sweep con Watchdog
====================================================
Corrección crítica del v1:

PROBLEMA v1:
  Si un sector queda bloqueado (falso positivo, dep caída, bug),
  TODO el sistema queda en Hard Freeze indefinidamente.
  Un sistema completamente rígido muere por rigidez.

SOLUCIÓN v2:
  1. SECTOR WATCHDOG — Timeout por sector (configurable, no el orden)
  2. DEGRADED MODE — Si un sector no-crítico falla con timeout,
     puede pasar con WARNING en lugar de FAIL si quorum se mantiene.
  3. SOVEREIGN OVERRIDE — Firma dual (TOTP + backup key) permite
     bypass de un sector específico con auditoría permanente.
  4. SECTOR CRITICALITY — No todos los sectores son iguales.
     Sector 0 y 2 son CRITICAL (nunca degradan).
     Sectores 3-7 pueden degradar con justificación.

REGLAS QUE NO CAMBIAN (talladas en piedra):
  - Orden de ejecución 0→7 es inmutable
  - Sectores CRITICAL (0, 2) nunca pueden degradar
  - Sovereign Override requiere firma dual (TOTP + backup key)
  - Todo override queda en audit trail permanente
  - Resultado degradado bloquea PFE de L1 (solo L2 minor)

WATCHDOG DEFAULTS:
  Sector 0 — timeout: 30s  | criticality: HARD
  Sector 1 — timeout: 20s  | criticality: HARD
  Sector 2 — timeout: 30s  | criticality: HARD
  Sector 3 — timeout: 45s  | criticality: SOFT
  Sector 4 — timeout: 30s  | criticality: SOFT
  Sector 5 — timeout: 20s  | criticality: SOFT
  Sector 6 — timeout: 45s  | criticality: SOFT
  Sector 7 — timeout: 60s  | criticality: SOFT (dep externas son lentas)
"""

import json
import hmac
import hashlib
import logging
import redis
import threading
import time
import subprocess
from dataclasses import dataclass, asdict
from datetime import datetime, timezone, timedelta
from typing import Optional, Callable
from enum import Enum
from pathlib import Path

logger = logging.getLogger("svs.v2")

SVS_VERSION = "v2.0-watchdog"


class SectorCriticality(Enum):
    HARD = "HARD"   # Fallo siempre es FAIL, nunca degrada
    SOFT = "SOFT"   # Fallo puede degradar a WARNING con justificación


class SectorResult(Enum):
    PASS        = "PASS"
    WARNING     = "WARNING"
    FAIL        = "FAIL"
    TIMEOUT     = "TIMEOUT"    # Nuevo: sector excedió watchdog
    DEGRADED    = "DEGRADED"   # Timeout en sector SOFT → pasa con marca
    SKIPPED     = "SKIPPED"
    OVERRIDDEN  = "OVERRIDDEN" # Sovereign override aplicado


SECTOR_CONFIG = {
    0: {"name": "Kernel Integrity",         "timeout_s": 30, "criticality": SectorCriticality.HARD},
    1: {"name": "FSM & Governance",          "timeout_s": 20, "criticality": SectorCriticality.HARD},
    2: {"name": "Invariants & Safety",       "timeout_s": 30, "criticality": SectorCriticality.HARD},
    3: {"name": "Atlas & Drift Engine",      "timeout_s": 45, "criticality": SectorCriticality.SOFT},
    4: {"name": "Economy",                   "timeout_s": 30, "criticality": SectorCriticality.SOFT},
    5: {"name": "Nemesis Operational",       "timeout_s": 20, "criticality": SectorCriticality.SOFT},
    6: {"name": "Agents & Collusion",        "timeout_s": 45, "criticality": SectorCriticality.SOFT},
    7: {"name": "External Dependencies",     "timeout_s": 60, "criticality": SectorCriticality.SOFT},
}

# Quorum para degraded mode: mínimo X sectores SOFT deben PASS (no degraded)
SOFT_QUORUM = 3   # De 5 sectores SOFT, al menos 3 deben PASS real


@dataclass
class SectorReport:
    sector_id: int
    sector_name: str
    criticality: str
    result: str
    checks_total: int
    checks_passed: int
    checks_failed: int
    failures: list
    warnings: list
    duration_ms: float
    timed_out: bool
    degraded: bool
    timestamp: str


@dataclass
class SVSSweepReport:
    sweep_id: str
    version: str
    started_at: str
    completed_at: str
    overall_result: str
    degraded_mode: bool
    soft_quorum_met: bool
    sectors: list
    pfe_scope_allowed: str   # "FULL" | "L2_MINOR" | "BLOCKED"
    sovereign_overrides: list
    signature: str


class SectorWatchdog:
    """Ejecuta un sector con timeout. Si excede → resultado TIMEOUT."""

    def __init__(self, timeout_s: int):
        self.timeout_s = timeout_s
        self._result: Optional[SectorReport] = None
        self._exception: Optional[Exception] = None

    def run(self, fn: Callable, *args) -> SectorReport:
        def target():
            try:
                self._result = fn(*args)
            except Exception as e:
                self._exception = e

        thread = threading.Thread(target=target, daemon=True)
        thread.start()
        thread.join(timeout=self.timeout_s)

        if thread.is_alive():
            # Sector excedió timeout
            return SectorReport(
                sector_id=args[0] if args else -1,
                sector_name=args[1] if len(args) > 1 else "unknown",
                criticality="UNKNOWN",
                result=SectorResult.TIMEOUT.value,
                checks_total=0, checks_passed=0, checks_failed=1,
                failures=[f"Sector timed out after {self.timeout_s}s"],
                warnings=[],
                duration_ms=self.timeout_s * 1000,
                timed_out=True,
                degraded=False,
                timestamp=datetime.now(timezone.utc).isoformat(),
            )

        if self._exception:
            return SectorReport(
                sector_id=args[0] if args else -1,
                sector_name=args[1] if len(args) > 1 else "unknown",
                criticality="UNKNOWN",
                result=SectorResult.FAIL.value,
                checks_total=0, checks_passed=0, checks_failed=1,
                failures=[f"Sector exception: {str(self._exception)[:200]}"],
                warnings=[],
                duration_ms=0,
                timed_out=False,
                degraded=False,
                timestamp=datetime.now(timezone.utc).isoformat(),
            )

        return self._result


class SVSv2:
    """
    SVS v2 con watchdog, degraded mode y sovereign override.
    El orden de sectores sigue siendo inmutable.
    La rigidez ahora tiene válvulas de seguridad.
    """

    def __init__(
        self,
        redis_client: redis.Redis,
        system_secret: str,
        codebase_path: str = "/opt/kernell"
    ):
        self.redis = redis_client
        self._secret = system_secret.encode()
        self._codebase_path = Path(codebase_path)

    # ══════════════════════════════════════════════════════════════════════
    # ENTRY POINT
    # ══════════════════════════════════════════════════════════════════════

    def run_sweep(self, allow_degraded: bool = True) -> SVSSweepReport:
        import uuid
        sweep_id = str(uuid.uuid4())[:8]
        started_at = datetime.now(timezone.utc).isoformat()

        logger.info(f"[SVS v2] ═══ SWEEP {sweep_id} (degraded_allowed={allow_degraded}) ═══")

        sector_reports = []
        hard_failed = False
        soft_failures = 0
        sovereign_overrides = []

        sector_fns = {
            0: self._sector_0_kernel_integrity,
            1: self._sector_1_fsm_governance,
            2: self._sector_2_invariants,
            3: self._sector_3_atlas_drift,
            4: self._sector_4_economy,
            5: self._sector_5_nemesis,
            6: self._sector_6_agents,
            7: self._sector_7_external,
        }

        for sector_id, config in SECTOR_CONFIG.items():
            if hard_failed:
                report = self._skipped_report(sector_id, config["name"])
                sector_reports.append(asdict(report))
                continue

            # Verificar sovereign override
            override = self._check_sovereign_override(sector_id)
            if override:
                report = self._overridden_report(sector_id, config["name"], override)
                sector_reports.append(asdict(report))
                sovereign_overrides.append({"sector": sector_id, "override": override})
                logger.warning(f"[SVS v2] Sector {sector_id} OVERRIDDEN by sovereign")
                continue

            # Ejecutar con watchdog
            t0 = time.time()
            watchdog = SectorWatchdog(config["timeout_s"])
            fn = sector_fns[sector_id]
            report = watchdog.run(fn, sector_id, config["name"])
            report.duration_ms = round((time.time() - t0) * 1000, 1)
            report.criticality = config["criticality"].value

            # Aplicar lógica de degraded mode
            if report.result in (SectorResult.FAIL.value, SectorResult.TIMEOUT.value):
                if config["criticality"] == SectorCriticality.HARD:
                    # Sector HARD falla → sweep falla
                    hard_failed = True
                    logger.error(f"[SVS v2] Sector HARD {sector_id} FAILED — sweep terminado")
                elif allow_degraded:
                    # Sector SOFT con watchdog/fail → DEGRADED
                    report.result = SectorResult.DEGRADED.value
                    report.degraded = True
                    soft_failures += 1
                    logger.warning(
                        f"[SVS v2] Sector SOFT {sector_id} DEGRADED "
                        f"({'timeout' if report.timed_out else 'fail'})"
                    )
                else:
                    # allow_degraded=False → todo falla
                    hard_failed = True

            sector_reports.append(asdict(report))
            logger.info(
                f"[SVS v2] Sector {sector_id} ({config['name']}): "
                f"{report.result} [{report.duration_ms:.0f}ms]"
            )

        # Calcular quorum SOFT
        soft_passes = sum(
            1 for r in sector_reports
            if SECTOR_CONFIG.get(r["sector_id"], {}).get("criticality") == SectorCriticality.SOFT
            and r["result"] == SectorResult.PASS.value
        )
        soft_quorum_met = soft_passes >= SOFT_QUORUM

        # Determinar resultado y scope PFE
        degraded_mode = any(r.get("degraded") for r in sector_reports)

        if hard_failed:
            overall = "FAIL"
            pfe_scope = "BLOCKED"
        elif degraded_mode and not soft_quorum_met:
            overall = "FAIL"
            pfe_scope = "BLOCKED"
        elif degraded_mode:
            overall = "DEGRADED"
            pfe_scope = "L2_MINOR"      # Solo cambios mínimos permitidos
        elif any(r["result"] == SectorResult.WARNING.value for r in sector_reports):
            overall = "WARNING"
            pfe_scope = "FULL"
        else:
            overall = "PASS"
            pfe_scope = "FULL"

        completed_at = datetime.now(timezone.utc).isoformat()
        report_payload = {
            "sweep_id": sweep_id,
            "version": SVS_VERSION,
            "started_at": started_at,
            "completed_at": completed_at,
            "overall_result": overall,
            "degraded_mode": degraded_mode,
            "soft_quorum_met": soft_quorum_met,
            "sectors": sector_reports,
            "pfe_scope_allowed": pfe_scope,
            "sovereign_overrides": sovereign_overrides,
        }

        signature = self._sign_report(report_payload)
        report_payload["signature"] = signature

        sweep = SVSSweepReport(**report_payload)
        self._persist(sweep)

        if overall == "FAIL":
            self._trigger_freeze(sweep)

        logger.info(
            f"[SVS v2] ═══ FIN {sweep_id}: {overall} | "
            f"PFE={pfe_scope} | degraded={degraded_mode} ═══"
        )

        return sweep

    # ══════════════════════════════════════════════════════════════════════
    # SOVEREIGN OVERRIDE
    # ══════════════════════════════════════════════════════════════════════

    def request_sovereign_override(
        self,
        sector_id: int,
        totp_code: str,     # Google Authenticator 6-digit code
        backup_key: str,    # Static backup key (recovery)
        justification: str,
        expiry_minutes: int = 60,
    ) -> tuple[bool, str]:
        """
        Permite bypass de un sector SOFT con firma dual (TOTP + backup key).
        Solo sectores SOFT pueden ser overrideados.
        Sectores HARD (0, 1, 2) son inmunes.

        Returns:
            (success, override_token)
        """
        config = SECTOR_CONFIG.get(sector_id)
        if not config:
            return False, "Sector inválido"

        if config["criticality"] == SectorCriticality.HARD:
            return False, f"Sector {sector_id} es HARD — no se puede override soberano"

        # Verificar firma dual: TOTP + backup key
        try:
            from agents.sierra.salus.mfa_guard import MFAGuard
            mfa = MFAGuard(self.redis)
            if not mfa.verify(totp_code):
                return False, "TOTP verification failed"
            if not mfa.verify_backup_key(backup_key):
                return False, "Backup key verification failed"
        except Exception as e:
            return False, f"MFA verification error: {e}"

        # Generate override token
        combined = f"{totp_code}:{sector_id}:{justification}:{time.time()}"
        token = hmac.new(self._secret, combined.encode(), hashlib.sha256).hexdigest()[:16]

        # Registrar con TTL
        override_data = {
            "sector_id": sector_id,
            "justification": justification,
            "token": token,
            "auth_method": "TOTP+BackupKey",
            "requested_at": datetime.now(timezone.utc).isoformat(),
            "expires_at": (datetime.now(timezone.utc) + timedelta(minutes=expiry_minutes)).isoformat(),
            "dual_signed": True,
        }

        key = f"kernell:svs:sovereign_override:{sector_id}"
        self.redis.set(key, json.dumps(override_data), ex=expiry_minutes * 60)

        # Audit trail permanente
        self.redis.lpush("kernell:svs:override_audit", json.dumps(override_data))

        logger.warning(
            f"[SVS v2] 🔑 SOVEREIGN OVERRIDE (TOTP) registrado para sector {sector_id}: "
            f"'{justification}' (expira en {expiry_minutes}min)"
        )

        return True, token

    def _check_sovereign_override(self, sector_id: int) -> Optional[dict]:
        key = f"kernell:svs:sovereign_override:{sector_id}"
        raw = self.redis.get(key)
        if raw:
            return json.loads(raw)
        return None

    # ══════════════════════════════════════════════════════════════════════
    # SECTORES (misma lógica que v1, con retorno tipado correcto)
    # ══════════════════════════════════════════════════════════════════════

    def _sector_0_kernel_integrity(self, sid: int, name: str) -> SectorReport:
        checks, failures, warnings = 0, [], []

        checks += 1
        try:
            self.redis.ping()
        except Exception as e:
            failures.append(f"Redis ping failed: {e}")

        checks += 1
        snapshot_raw = self.redis.get("kernell:reality:snapshot")
        stored_hash  = self.redis.get("kernell:reality:snapshot_hash")
        if snapshot_raw and stored_hash:
            computed = hmac.new(self._secret, snapshot_raw, hashlib.sha256).hexdigest()
            stored   = stored_hash if isinstance(stored_hash, str) else stored_hash.decode()
            if not hmac.compare_digest(computed, stored):
                failures.append("Snapshot HMAC mismatch — possible Redis tampering")
        else:
            warnings.append("No snapshot found")

        checks += 1
        try:
            svs_path     = Path(__file__)
            current_hash = hashlib.sha256(svs_path.read_bytes()).hexdigest()
            stored_svs   = self.redis.get("kernell:l0:svs_v2_module_hash")
            if stored_svs:
                stored = stored_svs if isinstance(stored_svs, str) else stored_svs.decode()
                if stored != current_hash:
                    failures.append("SVS v2 module hash mismatch — L0 may be modified")
            else:
                self.redis.set("kernell:l0:svs_v2_module_hash", current_hash)
                warnings.append("SVS v2 hash baseline established")
        except Exception as e:
            warnings.append(f"Cannot verify SVS integrity: {e}")

        checks += 1
        beta_hb = self.redis.get("kernell:agents:heartbeats:overseer_beta")
        if not beta_hb:
            warnings.append("Overseer Beta heartbeat missing")

        return self._build(sid, name, checks, failures, warnings)

    def _sector_1_fsm_governance(self, sid: int, name: str) -> SectorReport:
        checks, failures, warnings = 0, [], []
        VALID_MODES   = {"STABLE", "TENSION", "STRESS", "CRITICAL", "UNKNOWN"}
        VALID_DEFCON  = {1, 2, 3, 4, 5}

        checks += 1
        mode = self.redis.get("kernell:drift:mode_signal")
        mode_str = mode if isinstance(mode, str) else (mode.decode() if mode else None)
        if mode_str not in VALID_MODES:
            failures.append(f"Invalid mode: {mode_str}")

        checks += 1
        defcon = self.redis.get("kernell:system:defcon")
        if defcon:
            try:
                if int(defcon) not in VALID_DEFCON:
                    failures.append(f"Invalid DEFCON: {defcon}")
            except ValueError:
                failures.append(f"DEFCON not numeric")

        checks += 1
        conf = self.redis.get("kernell:confidence:value")
        if conf:
            try:
                c = float(conf)
                if not (5 <= c <= 100):
                    failures.append(f"Confidence {c} out of bounds [5-100]")
            except ValueError:
                failures.append("Confidence not numeric")

        checks += 1
        drift = self.redis.get("kernell:drift:current_value")
        if drift:
            try:
                d = float(drift)
                if not (0 <= d <= 100):
                    failures.append(f"Drift {d} out of range [0-100]")
            except ValueError:
                failures.append("Drift not numeric")

        return self._build(sid, name, checks, failures, warnings)

    def _sector_2_invariants(self, sid: int, name: str) -> SectorReport:
        checks, failures, warnings = 0, [], []

        checks += 1
        accel = self.redis.get("kernell:drift:acceleration")
        if accel:
            try:
                a = float(accel)
                if abs(a) > 25:
                    failures.append(f"Drift acceleration {a:+.1f} violates invariant ±25")
            except ValueError:
                pass

        checks += 1
        profiles = self.redis.hgetall("kernell:execution_guard:profiles")
        required = {"kernell", "atlas", "sentinel", "sierra", "forge", "fixer"}
        loaded = {k if isinstance(k, str) else k.decode() for k in profiles.keys()}
        missing = required - loaded
        if missing:
            failures.append(f"Missing execution guard profiles: {missing}")

        checks += 1
        rrp_history = self.redis.lrange("kernell:rrp:history", 0, 9)
        now = datetime.now(timezone.utc)
        recent = sum(
            1 for raw in rrp_history
            if (now - datetime.fromisoformat(
                json.loads(raw).get("timestamp", "2000-01-01")
            )).total_seconds() < 1800
        )
        if recent > 1:
            failures.append(f"RRP invariant: {recent} revisions in 30min (max 1)")

        return self._build(sid, name, checks, failures, warnings)

    def _sector_3_atlas_drift(self, sid: int, name: str) -> SectorReport:
        checks, failures, warnings = 0, [], []

        checks += 1
        metrics_raw = self.redis.get("kernell:atlas:metrics")
        if metrics_raw:
            ts_str = json.loads(metrics_raw).get("timestamp")
            if ts_str:
                age_min = (datetime.now(timezone.utc) - datetime.fromisoformat(ts_str)).total_seconds() / 60
                if age_min > 10:
                    failures.append(f"Atlas metrics stale: {age_min:.1f}min")
        else:
            warnings.append("No Atlas metrics found")

        checks += 1
        beta_val_raw = self.redis.get("kernell:overseer:beta:last_validation")
        if beta_val_raw:
            v = json.loads(beta_val_raw)
            if v.get("status") in ("mismatch", "alpha_dead"):
                failures.append(f"Overseer Beta alert: {v.get('status')}")
        else:
            warnings.append("No Overseer Beta validation found")

        return self._build(sid, name, checks, failures, warnings)

    def _sector_4_economy(self, sid: int, name: str) -> SectorReport:
        checks, failures, warnings = 0, [], []

        checks += 1
        econ_raw = self.redis.get("kernell:economy:state")
        if econ_raw:
            econ = json.loads(econ_raw)
            if econ.get("kill_switch") and econ.get("kill_switch_reason") == "unknown":
                failures.append("Kill switch active without reason")

        checks += 1
        budget_raw = self.redis.get("kernell:economy:budget_usage_pct")
        if budget_raw:
            usage = float(budget_raw)
            if usage > 95:
                failures.append(f"Budget critical: {usage:.1f}%")
            elif usage > 80:
                warnings.append(f"Budget elevated: {usage:.1f}%")

        return self._build(sid, name, checks, failures, warnings)

    def _sector_5_nemesis(self, sid: int, name: str) -> SectorReport:
        checks, failures, warnings = 0, [], []

        checks += 1
        safe_level = self.redis.get("kernell:safe_mode:level")
        nemesis_raw = self.redis.get("kernell:nemesis:active")
        if safe_level and int(safe_level) >= 3 and nemesis_raw:
            if json.loads(nemesis_raw).get("active"):
                failures.append("Nemesis executing in MINIMAL safe mode")

        checks += 1
        hb = self.redis.get("kernell:agent:nemesis:heartbeat")
        if not hb:
            warnings.append("Nemesis heartbeat missing")

        return self._build(sid, name, checks, failures, warnings)

    def _sector_6_agents(self, sid: int, name: str) -> SectorReport:
        checks, failures, warnings = 0, [], []

        checks += 1
        core = ["kernell", "atlas", "sentinel", "sierra"]
        offline = [a for a in core if not self.redis.get(f"kernell:agents:heartbeats:{a}")]
        if offline:
            failures.append(f"Core agents offline: {offline}")

        checks += 1
        quarantined = self.redis.smembers("kernell:immune:quarantined_agents")
        names = [q if isinstance(q, str) else q.decode() for q in quarantined]
        if set(names) & set(core):
            failures.append(f"Core agent in quarantine: {names}")

        checks += 1
        honeypot = self.redis.lrange("kernell:immune:honeypot_access", 0, -1)
        if honeypot:
            failures.append(f"Honeypot triggered {len(honeypot)} times")

        return self._build(sid, name, checks, failures, warnings)

    def _sector_7_external(self, sid: int, name: str) -> SectorReport:
        checks, failures, warnings = 0, [], []

        checks += 1
        ramdisk = self.redis.get("kernell:ramdisk:usage_pct")
        if ramdisk:
            usage = float(ramdisk)
            if usage > 90:
                failures.append(f"RAMDisk critical: {usage:.1f}%")
            elif usage > 75:
                warnings.append(f"RAMDisk elevated: {usage:.1f}%")

        checks += 1
        cve_raw = self.redis.get("kernell:svs:last_cve_scan")
        if cve_raw:
            scan = json.loads(cve_raw)
            if scan.get("critical_count", 0) > 0:
                failures.append(f"Critical CVEs unpatched: {scan['critical_count']}")
        else:
            warnings.append("No CVE scan on record")

        checks += 1
        try:
            result = subprocess.run(
                ["pip", "audit", "--json", "-q"],
                capture_output=True, text=True, timeout=20
            )
            if result.returncode != 0 and result.stdout:
                import json as _j
                vulns = _j.loads(result.stdout).get("vulnerabilities", [])
                crit = [v for v in vulns if "critical" in str(v).lower()]
                if crit:
                    failures.append(f"{len(crit)} critical dependency CVEs")
        except Exception:
            warnings.append("pip-audit not available")

        return self._build(sid, name, checks, failures, warnings)

    # ══════════════════════════════════════════════════════════════════════
    # HELPERS
    # ══════════════════════════════════════════════════════════════════════

    def _build(self, sid: int, name: str, checks: int, failures: list, warnings: list) -> SectorReport:
        result = (
            SectorResult.FAIL.value    if failures else
            SectorResult.WARNING.value if warnings else
            SectorResult.PASS.value
        )
        return SectorReport(
            sector_id=sid, sector_name=name,
            criticality=SECTOR_CONFIG[sid]["criticality"].value,
            result=result,
            checks_total=checks, checks_passed=checks - len(failures),
            checks_failed=len(failures),
            failures=failures, warnings=warnings,
            duration_ms=0, timed_out=False, degraded=False,
            timestamp=datetime.now(timezone.utc).isoformat(),
        )

    def _skipped_report(self, sid: int, name: str) -> SectorReport:
        return SectorReport(
            sector_id=sid, sector_name=name,
            criticality=SECTOR_CONFIG[sid]["criticality"].value,
            result=SectorResult.SKIPPED.value,
            checks_total=0, checks_passed=0, checks_failed=0,
            failures=["Skipped: preceding HARD sector failed"],
            warnings=[], duration_ms=0, timed_out=False, degraded=False,
            timestamp=datetime.now(timezone.utc).isoformat(),
        )

    def _overridden_report(self, sid: int, name: str, override: dict) -> SectorReport:
        return SectorReport(
            sector_id=sid, sector_name=name,
            criticality=SECTOR_CONFIG[sid]["criticality"].value,
            result=SectorResult.OVERRIDDEN.value,
            checks_total=0, checks_passed=0, checks_failed=0,
            failures=[],
            warnings=[f"SOVEREIGN OVERRIDE: {override.get('justification', '')}"],
            duration_ms=0, timed_out=False, degraded=False,
            timestamp=datetime.now(timezone.utc).isoformat(),
        )

    def _sign_report(self, payload: dict) -> str:
        data = json.dumps(payload, sort_keys=True)
        return hmac.new(self._secret, data.encode(), hashlib.sha256).hexdigest()

    def _persist(self, report: SVSSweepReport):
        data = asdict(report)
        self.redis.set("kernell:svs:last_sweep", json.dumps(data))
        self.redis.lpush("kernell:svs:history", json.dumps({
            "sweep_id": report.sweep_id,
            "result": report.overall_result,
            "pfe_scope": report.pfe_scope_allowed,
            "degraded": report.degraded_mode,
            "completed_at": report.completed_at,
        }))
        self.redis.ltrim("kernell:svs:history", 0, 99)

    def _trigger_freeze(self, report: SVSSweepReport):
        failed = [s["sector_name"] for s in report.sectors if s["result"] == "FAIL"]
        self.redis.set("kernell:system:hard_freeze", json.dumps({
            "frozen": True,
            "reason": f"SVS_FAIL: {failed}",
            "sweep_id": report.sweep_id,
            "frozen_at": report.completed_at,
        }))
        logger.critical(f"[SVS v2] 🔴 HARD FREEZE: {failed}")

    def is_pfe_allowed(self) -> tuple[bool, str, str]:
        """
        Returns (allowed, reason, scope)
        scope: "FULL" | "L2_MINOR" | "BLOCKED"
        """
        raw = self.redis.get("kernell:svs:last_sweep")
        if not raw:
            return False, "No SVS sweep on record", "BLOCKED"

        data = json.loads(raw)
        stored_sig = data.pop("signature", "")
        expected   = self._sign_report(data)
        if not hmac.compare_digest(expected, stored_sig):
            return False, "SVS report tampered", "BLOCKED"

        scope = data.get("pfe_scope_allowed", "BLOCKED")
        if scope == "BLOCKED":
            return False, f"Last SVS: {data.get('overall_result')}", "BLOCKED"

        try:
            ts  = datetime.fromisoformat(data.get("completed_at", ""))
            age = (datetime.now(timezone.utc) - ts).total_seconds() / 3600
            if age > 2:
                return False, f"SVS {age:.1f}h old — must re-run", "BLOCKED"
        except ValueError:
            return False, "SVS timestamp invalid", "BLOCKED"

        return True, f"SVS {data.get('overall_result')} — scope {scope}", scope
