"""
POLICY ENGINE FORMAL
=====================
Problema v1:
  Las reglas estaban distribuidas en múltiples módulos:
  - L0/L1/L2 classification en forge_council.py
  - Kill-switch logic en economy.py
  - PFE permissions en pfe_orchestrator.py
  - Tricapa enforcement en tricapa.py
  - Invariant rules en auditor_invariants.py

  Si hay conflicto entre módulos → regla ambigua → vulnerabilidad.

SOLUCIÓN:
  Un único Policy Engine es LA fuente de verdad para TODAS las reglas.
  Ningún módulo define reglas por su cuenta.
  Todo consulta al Policy Engine.

ESTRUCTURA:
  PolicyEngine.get(policy_key) → PolicyDecision
  PolicyEngine.evaluate(context) → PolicyDecision
  PolicyEngine.can(action, agent, layer) → bool

EJEMPLO:
  # En lugar de tener en forge_council.py:
  L0_PROTECTED = {"constitution", ...}
  if proposal.target in L0_PROTECTED:
      reject()

  # Ahora:
  decision = policy.evaluate({
      "action": "modify_file",
      "target": proposal.target_file,
      "agent": proposal.author,
      "layer": proposal.target_layer
  })
  if not decision.allowed:
      reject(decision.reason)

POLÍTICAS INCLUIDAS:
  - L0/L1/L2 Layer Classification
  - Execution Scope (quién puede hacer qué)
  - PFE Gate Rules (qué necesita para evolucionar)
  - Kill Switch Conditions
  - Safe Mode Triggers
  - GSHI Enforcement Rules
  - Stone Rules (inmutables)
  - Tricapa Layer Enforcement
"""

import json
import logging
import redis
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Optional, Any
from enum import Enum

logger = logging.getLogger("policy_engine")


class PolicyLayer(Enum):
    L0 = "L0"    # Constitucional — nunca modificable
    L1 = "L1"    # Gobernanza — modificable con reglas estrictas
    L2 = "L2"    # Operativo — modificable bajo PFE


class PolicyResult(Enum):
    ALLOW  = "ALLOW"
    DENY   = "DENY"
    WARN   = "WARN"


@dataclass
class PolicyDecision:
    allowed: bool
    result: str           # PolicyResult.value
    policy_id: str
    reason: str
    layer: str
    requires_approval: bool    # Si True, requiere aprobación humana adicional
    audit_required: bool       # Si True, registrar en audit trail
    timestamp: str


# ── Definición de políticas ───────────────────────────────────────────────

# Componentes que pertenecen a L0 (nunca modificables por sistema)
L0_COMPONENTS = frozenset({
    "sectoral_verification_sweep", "svs_v2", "svs.py",
    "formal_verifier", "auditor_invariants",
    "policy_engine",            # Este mismo módulo es L0
    "constitution.md", "constitution.yaml",
    "l0_invariants", "stone_rules",
    "fsm_state_space", "safety_properties", "liveness_properties",
    "authority_matrix", "freeze_rule",
    "pfe_protocol",
})

# Componentes que pertenecen a L1 (modificables con aprobación estricta)
L1_COMPONENTS = frozenset({
    "drift_thresholds", "confidence_engine",
    "hysteresis_values", "weight_limits",
    "defcon_thresholds", "safe_mode_thresholds",
    "rrp_rate_limits", "sigma_thresholds",
    "gshi_weights", "trust_thresholds",
    "audit_quorum", "forge_quorum",
    "shadow_cycles", "promotion_cooldown",
})

# Reglas de kill-switch (cuándo activar/desactivar)
KILL_SWITCH_POLICIES = {
    "economy.kill_switch.activate": {
        "conditions": ["roi_7d < -10", "confidence < 35", "drift > 70"],
        "requires_all": False,    # OR — cualquiera activa
        "layer": PolicyLayer.L1,
    },
    "economy.kill_switch.deactivate": {
        "conditions": ["roi_7d > 0", "confidence > 60", "drift < 50"],
        "requires_all": True,     # AND — todas deben cumplirse
        "layer": PolicyLayer.L1,
    },
}

# Reglas de PFE — qué necesita para ejecutar cada fase
PFE_GATE_POLICIES = {
    "pfe.start": {
        "requires": ["svs_passed", "svs_age_lt_2h", "gshi_gte_55", "cooldown_met"],
        "layer": PolicyLayer.L1,
    },
    "pfe.sandbox": {
        "requires": ["forge_council_approved"],
        "layer": PolicyLayer.L2,
    },
    "pfe.audit": {
        "requires": ["sandbox_passed", "forge_council_approved"],
        "layer": PolicyLayer.L2,
    },
    "pfe.shadow": {
        "requires": ["audit_council_approved", "shadow_cycles_gt_0"],
        "layer": PolicyLayer.L2,
    },
    "pfe.promote": {
        "requires": ["shadow_passed", "zero_violations", "consensus_gte_67pct"],
        "layer": PolicyLayer.L1,
    },
}

# Reglas de GSHI enforcement automático
GSHI_ENFORCEMENT_POLICIES = {
    "gshi.lt.45": {
        "actions": ["force_stress", "full_salus_audit", "block_pfe"],
        "description": "GSHI < 45 → forced STRESS + audit",
    },
    "gshi.lt.55": {
        "actions": ["restrict_pfe_l2_minor", "nemesis_risk_50pct"],
        "description": "GSHI < 55 → PFE restricted, Nemesis conservative",
    },
    "gshi.lt.70": {
        "actions": ["red_team_high_intensity"],
        "description": "GSHI < 70 → Red Team intensified",
    },
}

# Permisos por capa de deployment (Tricapa)
TRICAPA_PERMISSIONS = {
    "core": {
        "pfe_scopes": ["L1", "L2"],
        "red_team": True,
        "autonomous_evolution": True,
        "human_approval": False,
        "l0_access": False,
    },
    "enterprise": {
        "pfe_scopes": ["L2"],
        "red_team": False,
        "autonomous_evolution": False,
        "human_approval": True,  # Sandbox requiere aprobación
        "l0_access": False,
    },
    "platform": {
        "pfe_scopes": [],
        "red_team": False,
        "autonomous_evolution": False,
        "human_approval": True,
        "l0_access": False,
    },
}


class PolicyEngine:
    """
    Fuente única de verdad para todas las reglas del sistema.

    Uso:
        policy = PolicyEngine(redis_client)
        decision = policy.evaluate_file_modification("core/drift/drift_engine.py", "forge")
        if not decision.allowed:
            raise PolicyViolation(decision.reason)
    """

    def __init__(self, redis_client: redis.Redis, layer: str = "core"):
        self.redis = redis_client
        self.deployment_layer = layer

    # ── API principal ─────────────────────────────────────────────────────

    def evaluate(self, context: dict) -> PolicyDecision:
        """
        Evaluación central de cualquier acción.

        Args:
            context: {
                "action": str,
                "target": str,
                "agent": str,
                "layer": str,
                ...additional context
            }
        """
        action = context.get("action", "")
        target = context.get("target", "")
        agent  = context.get("agent", "")
        layer  = context.get("layer", "L2")

        # Router de políticas
        if action == "modify_file":
            return self.evaluate_file_modification(target, agent)

        elif action == "pfe_start":
            return self.evaluate_pfe_gate("pfe.start", context)

        elif action == "pfe_promote":
            return self.evaluate_pfe_gate("pfe.promote", context)

        elif action in ("kill_switch_activate", "kill_switch_deactivate"):
            return self.evaluate_kill_switch(action, context)

        elif action == "agent_execute_scope":
            scope = context.get("scope", "")
            return self.evaluate_execution_scope(agent, scope)

        elif action == "tricapa_capability":
            capability = context.get("capability", "")
            return self.evaluate_tricapa(capability)

        else:
            return self._allow(f"policy.default.{action}", "No specific policy for this action")

    def evaluate_file_modification(self, target_file: str, agent: str) -> PolicyDecision:
        """Verifica si un agente puede modificar un archivo."""
        target_lower = target_file.lower()

        # L0 check
        for l0 in L0_COMPONENTS:
            if l0 in target_lower:
                return self._deny(
                    "policy.l0.immutable",
                    f"File '{target_file}' is L0 — never modifiable by automated process",
                    layer="L0",
                    audit=True,
                )

        # L1 check — solo con reglas estrictas
        for l1 in L1_COMPONENTS:
            if l1 in target_lower:
                # Verificar si el agente tiene permisos L1
                l1_eligible = self.redis.smembers("kernell:pfe:l1_eligible_agents")
                names = {e if isinstance(e, str) else e.decode() for e in l1_eligible}
                if agent not in names and agent != "kernell":
                    return self._deny(
                        "policy.l1.restricted",
                        f"File '{target_file}' is L1 — agent '{agent}' not L1-eligible",
                        layer="L1",
                        requires_approval=True,
                        audit=True,
                    )
                return self._warn(
                    "policy.l1.requires_strict_audit",
                    f"L1 modification requires full audit pipeline",
                    layer="L1",
                )

        return self._allow("policy.l2.operational", f"L2 file — operational modification allowed")

    def evaluate_pfe_gate(self, gate_key: str, context: dict) -> PolicyDecision:
        """Verifica si un gate del PFE puede ejecutarse."""
        gate = PFE_GATE_POLICIES.get(gate_key)
        if not gate:
            return self._deny("policy.pfe.unknown_gate", f"Unknown PFE gate: {gate_key}")

        missing = []
        for requirement in gate["requires"]:
            if not self._check_pfe_requirement(requirement, context):
                missing.append(requirement)

        if missing:
            return self._deny(
                f"policy.pfe.{gate_key.replace('.', '_')}",
                f"PFE gate '{gate_key}' failed — missing: {missing}",
                layer=gate["layer"].value,
                audit=True,
            )

        return self._allow(f"policy.pfe.{gate_key.replace('.', '_')}", "Gate requirements met")

    def evaluate_kill_switch(self, action: str, context: dict) -> PolicyDecision:
        """Verifica si el kill switch puede activarse/desactivarse."""
        policy = KILL_SWITCH_POLICIES.get(f"economy.kill_switch.{action.split('_')[-1]}")
        if not policy:
            return self._deny("policy.ks.unknown", f"Unknown kill switch action")

        conditions_met = []
        for condition in policy["conditions"]:
            conditions_met.append(self._evaluate_condition(condition, context))

        if policy["requires_all"]:
            passed = all(conditions_met)
        else:
            passed = any(conditions_met)

        if passed:
            return self._allow(
                f"policy.kill_switch.{action}",
                f"Kill switch conditions met ({sum(conditions_met)}/{len(conditions_met)})",
                audit=True,
            )
        return self._deny(
            f"policy.kill_switch.{action}",
            f"Kill switch conditions not met ({sum(conditions_met)}/{len(conditions_met)})",
        )

    def evaluate_execution_scope(self, agent: str, scope: str) -> PolicyDecision:
        """
        Verifica si un agente tiene permiso para un scope.
        Consulta el Execution Guard.
        """
        profile_raw = self.redis.hget("kernell:execution_guard:profiles", agent)
        if not profile_raw:
            return self._deny("policy.scope.agent_not_registered",
                              f"Agent '{agent}' not in Execution Guard")

        profile = json.loads(profile_raw)
        if scope in profile.get("forbidden", []):
            return self._deny("policy.scope.forbidden",
                              f"Scope '{scope}' is forbidden for agent '{agent}'",
                              audit=True)

        if scope not in profile.get("execution_scope", []):
            return self._deny("policy.scope.not_permitted",
                              f"Scope '{scope}' not in execution_scope of '{agent}'",
                              audit=True)

        return self._allow("policy.scope.permitted", f"Agent '{agent}' permitted for '{scope}'")

    def evaluate_tricapa(self, capability: str) -> PolicyDecision:
        """Verifica si una capability está disponible en el deployment layer actual."""
        perms = TRICAPA_PERMISSIONS.get(self.deployment_layer, {})

        if capability == "pfe_l1":
            if "L1" not in perms.get("pfe_scopes", []):
                return self._deny("policy.tricapa.pfe_l1_not_allowed",
                                  f"Layer '{self.deployment_layer}' cannot run PFE L1")
        elif capability == "red_team":
            if not perms.get("red_team", False):
                return self._deny("policy.tricapa.red_team_not_allowed",
                                  f"Red Team not available in '{self.deployment_layer}' layer")
        elif capability == "autonomous_evolution":
            if not perms.get("autonomous_evolution", False):
                return self._deny("policy.tricapa.no_autonomous",
                                  f"Autonomous evolution not allowed in '{self.deployment_layer}'",
                                  requires_approval=True)

        return self._allow(f"policy.tricapa.{capability}", "Capability available in this layer")

    def evaluate_gshi_enforcement(self, gshi: float) -> list[dict]:
        """Retorna la lista de acciones que deben ejecutarse para el GSHI actual."""
        actions = []
        for rule_id, rule in GSHI_ENFORCEMENT_POLICIES.items():
            # Parsear threshold del rule_id
            parts = rule_id.split(".")  # "gshi.lt.45"
            if len(parts) == 3 and parts[1] == "lt":
                threshold = float(parts[2])
                if gshi < threshold:
                    actions.append({
                        "rule": rule_id,
                        "actions": rule["actions"],
                        "description": rule["description"],
                    })
        return actions

    def get_layer_classification(self, file_path: str) -> PolicyLayer:
        """Retorna la capa L0/L1/L2 de un archivo."""
        target = file_path.lower()
        for l0 in L0_COMPONENTS:
            if l0 in target:
                return PolicyLayer.L0
        for l1 in L1_COMPONENTS:
            if l1 in target:
                return PolicyLayer.L1
        return PolicyLayer.L2

    # ── Helpers ───────────────────────────────────────────────────────────

    def _check_pfe_requirement(self, req: str, context: dict) -> bool:
        if req == "svs_passed":
            raw = self.redis.get("kernell:svs:last_sweep")
            return bool(raw) and json.loads(raw).get("overall_result") in ("PASS", "WARNING", "DEGRADED")

        elif req == "svs_age_lt_2h":
            raw = self.redis.get("kernell:svs:last_sweep")
            if not raw:
                return False
            ts = json.loads(raw).get("completed_at", "")
            try:
                age = (datetime.now(timezone.utc) - datetime.fromisoformat(ts)).total_seconds() / 3600
                return age < 2
            except Exception:
                return False

        elif req == "gshi_gte_55":
            raw = self.redis.get("kernell:gshi:v2:current")
            if not raw:
                return False
            return json.loads(raw).get("gshi_ema", 0) >= 55

        elif req == "cooldown_met":
            last_raw = self.redis.get("kernell:pfe:last_promotion_at")
            if not last_raw:
                return True
            try:
                ts = datetime.fromisoformat(last_raw if isinstance(last_raw, str) else last_raw.decode())
                elapsed_h = (datetime.now(timezone.utc) - ts).total_seconds() / 3600
                return elapsed_h >= 24
            except Exception:
                return True

        elif req == "forge_council_approved":
            return context.get("forge_approved", False)

        elif req == "sandbox_passed":
            return context.get("sandbox_passed", False)

        elif req == "audit_council_approved":
            return context.get("audit_approved", False)

        elif req == "shadow_cycles_gt_0":
            raw = self.redis.get("kernell:pfe:shadow_cycles_config")
            cycles = int(raw) if raw else 10
            return cycles > 0

        elif req == "shadow_passed":
            return context.get("shadow_passed", False)

        elif req == "zero_violations":
            return context.get("violations", 0) == 0

        elif req == "consensus_gte_67pct":
            return context.get("consensus_strength", 0) >= 0.67

        return True

    def _evaluate_condition(self, condition: str, context: dict) -> bool:
        """Evalúa una condición del tipo 'roi_7d < -10'."""
        try:
            field, op, value = condition.split()
            actual = float(context.get(field, 0))
            threshold = float(value)
            return {
                "<": actual < threshold, ">": actual > threshold,
                "<=": actual <= threshold, ">=": actual >= threshold,
            }.get(op, False)
        except Exception:
            return False

    def _allow(self, policy_id: str, reason: str, layer: str = "L2",
               audit: bool = False) -> PolicyDecision:
        d = PolicyDecision(
            allowed=True, result=PolicyResult.ALLOW.value,
            policy_id=policy_id, reason=reason, layer=layer,
            requires_approval=False, audit_required=audit,
            timestamp=datetime.now(timezone.utc).isoformat(),
        )
        if audit:
            self._log_decision(d)
        return d

    def _deny(self, policy_id: str, reason: str, layer: str = "L2",
              requires_approval: bool = False, audit: bool = True) -> PolicyDecision:
        d = PolicyDecision(
            allowed=False, result=PolicyResult.DENY.value,
            policy_id=policy_id, reason=reason, layer=layer,
            requires_approval=requires_approval, audit_required=audit,
            timestamp=datetime.now(timezone.utc).isoformat(),
        )
        logger.warning(f"[POLICY] DENY {policy_id}: {reason}")
        if audit:
            self._log_decision(d)
        return d

    def _warn(self, policy_id: str, reason: str, layer: str = "L1") -> PolicyDecision:
        d = PolicyDecision(
            allowed=True, result=PolicyResult.WARN.value,
            policy_id=policy_id, reason=reason, layer=layer,
            requires_approval=True, audit_required=True,
            timestamp=datetime.now(timezone.utc).isoformat(),
        )
        logger.warning(f"[POLICY] WARN {policy_id}: {reason}")
        self._log_decision(d)
        return d

    def _log_decision(self, decision: PolicyDecision):
        self.redis.lpush("kernell:policy:decisions", json.dumps({
            "policy_id": decision.policy_id,
            "result": decision.result,
            "reason": decision.reason,
            "layer": decision.layer,
            "timestamp": decision.timestamp,
        }))
        self.redis.ltrim("kernell:policy:decisions", 0, 999)


class PolicyViolationError(Exception):
    """Lanzada cuando una política prohíbe una acción."""
    def __init__(self, decision: PolicyDecision):
        self.decision = decision
        super().__init__(f"Policy violation [{decision.policy_id}]: {decision.reason}")
