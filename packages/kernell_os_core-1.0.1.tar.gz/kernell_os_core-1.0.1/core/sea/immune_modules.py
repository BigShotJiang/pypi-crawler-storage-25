"""
IMMUNE MODULES — Consolidated System Defense Layer
====================================================
Five defense mechanisms in one module:

1. StressDecayProtocol — exponential cooldown after high-stress periods
2. StructuralInvariantMonitor — watches for L0 structural violations
3. QuarantineManager — isolates misbehaving agents
4. EconomicRealityCheck — validates economic metrics against real data
5. ChaosDaemon — controlled entropy injection for resilience testing
"""

import json
import math
import logging
import redis
import random
from datetime import datetime, timezone, timedelta
from typing import Optional

logger = logging.getLogger("sea.immune")


# ══════════════════════════════════════════════════════════════════════
# 1. STRESS DECAY PROTOCOL
# ══════════════════════════════════════════════════════════════════════

class StressDecayProtocol:
    """
    After a period of high Drift (>60), the system shouldn't snap back
    to STABLE instantly. This applies exponential cooldown:
    
      adjusted_drift = max(drift, decay_floor * e^(-lambda * t))
    
    Where t = minutes since last high-stress event.
    """

    DECAY_LAMBDA = 0.05   # Decay rate (slower = longer cooldown)
    STRESS_THRESHOLD = 60  # Drift level that triggers stress memory

    def __init__(self, redis_client: redis.Redis):
        self.redis = redis_client

    def apply(self, current_drift: float) -> float:
        """
        Apply stress decay to current drift.
        Returns adjusted drift (may be higher than raw if still cooling down).
        """
        if current_drift >= self.STRESS_THRESHOLD:
            # Record new stress event
            self.redis.set("kernell:immune:last_stress", json.dumps({
                "drift": current_drift,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }))
            return current_drift

        # Check if we're still in cooldown
        raw = self.redis.get("kernell:immune:last_stress")
        if not raw:
            return current_drift

        data = json.loads(raw)
        try:
            last_ts = datetime.fromisoformat(data["timestamp"])
            elapsed_min = (datetime.now(timezone.utc) - last_ts).total_seconds() / 60
            decay_floor = data["drift"]
            decayed = decay_floor * math.exp(-self.DECAY_LAMBDA * elapsed_min)

            return max(current_drift, decayed)
        except (ValueError, KeyError):
            return current_drift


# ══════════════════════════════════════════════════════════════════════
# 2. STRUCTURAL INVARIANT MONITOR
# ══════════════════════════════════════════════════════════════════════

class StructuralInvariantMonitor:
    """
    Watches for violations of L0 structural invariants:
    - Overseer must always exist
    - Exactly one Kernell
    - Constitution must be immutable (hash check)
    - Agent count within acceptable bounds
    """

    EXPECTED_INVARIANTS = {
        "overseer_exists": True,
        "kernell_singleton": True,
        "min_agents": 5,
        "max_agents": 25,
    }

    def __init__(self, redis_client: redis.Redis):
        self.redis = redis_client

    def check(self) -> dict:
        """
        Run all invariant checks.
        Returns: dict with check results and any violations.
        """
        violations = []

        # Check agent registry
        agents_raw = self.redis.get("kernell:srs:agents")
        if agents_raw:
            agents = json.loads(agents_raw)
            agent_names = [a.get("name", "") for a in agents] if isinstance(agents, list) else []

            if "overseer" not in agent_names and len(agent_names) > 0:
                violations.append({
                    "invariant": "overseer_exists",
                    "detail": "Overseer not found in agent registry",
                })

            count = len(agent_names)
            if count < self.EXPECTED_INVARIANTS["min_agents"]:
                violations.append({
                    "invariant": "min_agents",
                    "detail": f"Only {count} agents (min={self.EXPECTED_INVARIANTS['min_agents']})",
                })
            elif count > self.EXPECTED_INVARIANTS["max_agents"]:
                violations.append({
                    "invariant": "max_agents",
                    "detail": f"{count} agents exceed max={self.EXPECTED_INVARIANTS['max_agents']}",
                })

        result = {
            "violations": violations,
            "passed": len(violations) == 0,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

        self.redis.set("kernell:immune:invariants", json.dumps(result))

        if violations:
            logger.warning(f"[INVARIANT] {len(violations)} violations: {violations}")

        return result


# ══════════════════════════════════════════════════════════════════════
# 3. QUARANTINE MANAGER
# ══════════════════════════════════════════════════════════════════════

class QuarantineManager:
    """
    Isolates misbehaving agents by:
    1. Publishing quarantine flag to Redis
    2. Recording reason and timestamp
    3. Auto-lifting quarantine after timeout (default 30min)
    """

    DEFAULT_TIMEOUT_MIN = 30

    def __init__(self, redis_client: redis.Redis):
        self.redis = redis_client

    def quarantine(
        self, agent: str, reason: str, timeout_min: int = DEFAULT_TIMEOUT_MIN
    ):
        """Put an agent in quarantine."""
        key = f"kernell:quarantine:{agent}"
        data = {
            "agent": agent,
            "reason": reason,
            "quarantined_at": datetime.now(timezone.utc).isoformat(),
            "timeout_min": timeout_min,
        }
        self.redis.set(key, json.dumps(data), ex=timeout_min * 60)
        logger.warning(f"[QUARANTINE] Agent '{agent}' quarantined: {reason}")

        # Notify system
        self.redis.lpush("kernell:alerts:system", json.dumps({
            "type": "agent_quarantined",
            **data,
        }))

    def is_quarantined(self, agent: str) -> bool:
        """Check if an agent is currently quarantined."""
        return self.redis.exists(f"kernell:quarantine:{agent}") > 0

    def lift(self, agent: str):
        """Manually lift quarantine."""
        self.redis.delete(f"kernell:quarantine:{agent}")
        logger.info(f"[QUARANTINE] Agent '{agent}' released")

    def get_all_quarantined(self) -> list[dict]:
        """List all currently quarantined agents."""
        keys = self.redis.keys("kernell:quarantine:*")
        result = []
        for key in keys:
            raw = self.redis.get(key)
            if raw:
                result.append(json.loads(raw))
        return result


# ══════════════════════════════════════════════════════════════════════
# 4. ECONOMIC REALITY CHECK
# ══════════════════════════════════════════════════════════════════════

class EconomicRealityCheck:
    """
    Validates economic metrics against objective data.
    Prevents inflated or manipulated ROI/revenue reports.
    """

    MAX_DAILY_REVENUE_USD = 50000     # Sanity cap
    MAX_SINGLE_TRADE_USD = 10000      # Individual trade cap
    MIN_ROI_FOR_SUSPICION = 500       # ROI% that triggers investigation

    def __init__(self, redis_client: redis.Redis):
        self.redis = redis_client

    def validate(self) -> dict:
        """
        Run economic sanity checks.
        Returns: dict with validation results.
        """
        warnings = []

        # Check daily revenue claims
        revenue_raw = self.redis.get("kernell:economy:daily_revenue")
        if revenue_raw:
            revenue = float(revenue_raw)
            if revenue > self.MAX_DAILY_REVENUE_USD:
                warnings.append({
                    "check": "daily_revenue_cap",
                    "value": revenue,
                    "threshold": self.MAX_DAILY_REVENUE_USD,
                    "severity": "CRITICAL",
                })

        # Check single trade values
        last_trade_raw = self.redis.get("kernell:nemesis:last_trade_usd")
        if last_trade_raw:
            trade_val = float(last_trade_raw)
            if trade_val > self.MAX_SINGLE_TRADE_USD:
                warnings.append({
                    "check": "single_trade_cap",
                    "value": trade_val,
                    "threshold": self.MAX_SINGLE_TRADE_USD,
                    "severity": "HIGH",
                })

        # Check ROI claims
        roi_raw = self.redis.get("kernell:economy:roi_pct")
        if roi_raw:
            roi = float(roi_raw)
            if roi > self.MIN_ROI_FOR_SUSPICION:
                warnings.append({
                    "check": "suspicious_roi",
                    "value": roi,
                    "threshold": self.MIN_ROI_FOR_SUSPICION,
                    "severity": "HIGH",
                })

        result = {
            "warnings": warnings,
            "passed": len(warnings) == 0,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

        self.redis.set("kernell:immune:economic_check", json.dumps(result))
        return result


# ══════════════════════════════════════════════════════════════════════
# 5. CHAOS DAEMON
# ══════════════════════════════════════════════════════════════════════

class ChaosDaemon:
    """
    Controlled entropy injection for resilience testing.
    Only runs in STABLE mode and never touches L0 components.
    
    Scenarios:
    - Simulate agent failure (mark agent as DEAD temporarily)
    - Inject artificial Drift spike
    - Simulate Redis latency
    """

    def __init__(self, redis_client: redis.Redis):
        self.redis = redis_client
        self._active_experiment = None

    def can_run(self) -> bool:
        """Check if chaos testing is safe to run."""
        mode = self.redis.get("kernell:drift:mode_signal")
        safe_mode = self.redis.get("kernell:safe_mode:level")

        if mode and mode not in ("STABLE",):
            return False
        if safe_mode and int(safe_mode) > 0:
            return False

        return True

    def run_scenario(self, scenario: str = "agent_failure") -> dict:
        """
        Run a chaos scenario. Returns scenario result.
        """
        if not self.can_run():
            return {"status": "SKIPPED", "reason": "System not in STABLE mode"}

        if scenario == "agent_failure":
            return self._simulate_agent_failure()
        elif scenario == "drift_spike":
            return self._simulate_drift_spike()
        else:
            return {"status": "ERROR", "reason": f"Unknown scenario: {scenario}"}

    def _simulate_agent_failure(self) -> dict:
        """Temporarily mark a non-critical agent as DEAD."""
        # Only non-critical agents
        safe_targets = ["chronos", "herald", "hunter"]
        target = random.choice(safe_targets)

        key = f"kernell:chaos:simulated_failure"
        self.redis.set(key, target, ex=120)  # 2-minute TTL

        logger.info(f"[CHAOS] Simulated failure of '{target}' for 2 minutes")
        return {
            "status": "RUNNING",
            "scenario": "agent_failure",
            "target": target,
            "duration_sec": 120,
        }

    def _simulate_drift_spike(self) -> dict:
        """Inject a temporary drift spike."""
        spike = random.uniform(55, 75)
        key = "kernell:chaos:drift_injection"
        self.redis.set(key, str(spike), ex=60)  # 1-minute TTL

        logger.info(f"[CHAOS] Injected drift spike: {spike:.1f} for 1 minute")
        return {
            "status": "RUNNING",
            "scenario": "drift_spike",
            "injected_drift": round(spike, 1),
            "duration_sec": 60,
        }
