"""
SAFE MODE MANAGER — 4-Level Governance with Hysteresis
=======================================================
Levels:
  0 — NORMAL:    Full operation
  1 — WATCH:     Increased monitoring, Nemesis conservative
  2 — REDUCE:    Non-essential agents paused, PFE restricted
  3 — MINIMAL:   Cognitive model simplifies, weights freeze, Nemesis suspended

Hysteresis:
  Escalation:  Immediate on threshold breach
  Relaxation:  Requires N consecutive cycles below threshold
  
Triggers (any one is sufficient):
  L1: Drift > 50 OR Confidence < 60 OR DEFCON >= 2
  L2: Drift > 65 OR Confidence < 40 OR DEFCON >= 3
  L3: Drift > 80 OR Confidence < 25 OR DEFCON >= 4 OR GSHI < 30
"""

import json
import logging
import redis
from datetime import datetime, timezone
from typing import Optional

logger = logging.getLogger("sea.safe_mode")

RELAXATION_CYCLES = 5  # Consecutive cycles below threshold to de-escalate


class SafeModeManager:
    """
    4-level safe mode with hysteresis for transitions.
    Escalation is immediate; relaxation requires sustained improvement.
    """

    THRESHOLDS = {
        1: {"drift_gt": 50, "conf_lt": 60, "defcon_gte": 2, "gshi_lt": None},
        2: {"drift_gt": 65, "conf_lt": 40, "defcon_gte": 3, "gshi_lt": None},
        3: {"drift_gt": 80, "conf_lt": 25, "defcon_gte": 4, "gshi_lt": 30},
    }

    def __init__(self, redis_client: redis.Redis):
        self.redis = redis_client

    def evaluate(
        self,
        drift: float,
        confidence: float,
        defcon: int,
        gshi: Optional[float] = None,
    ) -> int:
        """
        Evaluate current conditions and return appropriate safe mode level.
        Applies hysteresis: immediate escalation, slow relaxation.
        
        Returns: int 0-3 (safe mode level)
        """
        current_level = self._get_current_level()

        # Determine raw level from thresholds
        raw_level = 0
        for level in [3, 2, 1]:
            t = self.THRESHOLDS[level]
            if (drift > t["drift_gt"]
                or confidence < t["conf_lt"]
                or defcon >= t["defcon_gte"]
                or (t["gshi_lt"] is not None and gshi is not None and gshi < t["gshi_lt"])):
                raw_level = level
                break

        # Hysteresis logic
        if raw_level > current_level:
            # Escalate immediately
            new_level = raw_level
            self._reset_relaxation_counter()
            logger.warning(f"[SAFE MODE] Escalated: L{current_level} → L{new_level}")
        elif raw_level < current_level:
            # Relax only after sustained improvement
            counter = self._increment_relaxation_counter()
            if counter >= RELAXATION_CYCLES:
                new_level = max(raw_level, current_level - 1)  # Step down one at a time
                self._reset_relaxation_counter()
                logger.info(f"[SAFE MODE] Relaxed: L{current_level} → L{new_level}")
            else:
                new_level = current_level
                logger.debug(
                    f"[SAFE MODE] Holding L{current_level} "
                    f"(relaxation {counter}/{RELAXATION_CYCLES})"
                )
        else:
            new_level = current_level
            self._reset_relaxation_counter()

        self._persist(new_level, drift, confidence, defcon, gshi)
        self._apply_effects(new_level)
        return new_level

    def _get_current_level(self) -> int:
        raw = self.redis.get("kernell:safe_mode:level")
        return int(raw) if raw else 0

    def _increment_relaxation_counter(self) -> int:
        key = "kernell:safe_mode:relaxation_counter"
        return self.redis.incr(key)

    def _reset_relaxation_counter(self):
        self.redis.set("kernell:safe_mode:relaxation_counter", 0)

    def _apply_effects(self, level: int):
        """Apply side effects based on safe mode level."""
        if level >= 1:
            self.redis.set("kernell:nemesis:risk_multiplier", "0.5")
        else:
            self.redis.delete("kernell:nemesis:risk_multiplier")

        if level >= 2:
            self.redis.set("kernell:pfe:scope_restriction", "L2_MINOR_ONLY")
        else:
            self.redis.delete("kernell:pfe:scope_restriction")

        if level >= 3:
            self.redis.set("kernell:nemesis:suspended", "true")
            self.redis.set("kernell:drift:weights_frozen", "true")
        else:
            self.redis.delete("kernell:nemesis:suspended")
            self.redis.delete("kernell:drift:weights_frozen")

    def _persist(self, level: int, drift: float, confidence: float, defcon: int, gshi):
        self.redis.set("kernell:safe_mode:level", str(level))
        self.redis.set("kernell:safe_mode:state", json.dumps({
            "level": level,
            "drift": drift,
            "confidence": confidence,
            "defcon": defcon,
            "gshi": gshi,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }))
