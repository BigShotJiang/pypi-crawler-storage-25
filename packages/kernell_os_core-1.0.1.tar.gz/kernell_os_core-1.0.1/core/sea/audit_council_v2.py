"""
AUDIT COUNCIL v2 — 5 Auditores + Veto Constitucional
======================================================
Corrección crítica del v1:
  v1 tenía 4 auditores: security, economy, structural, adversarial.
  El v1 verificaba invariantes constitucionales implícitamente.

v2 agrega el QUINTO auditor: AUDITOR_INVARIANTS
  - Determinístico, sin LLM, confidence siempre 1.0
  - Veto unilateral: si rechaza, el patch muere sin importar los demás
  - Analiza el diff formalmente contra reglas constitucionales

Votación v2:
  - 4/5 auditores deben APPROVE para pasar
  - AuditorInvariants tiene veto (1 REJECT = rechazo definitivo)
  - 2+ REJECTs de cualquier auditor = rechazo definitivo

Auditores y sus roles:
  AUDIT_SECURITY     → groq_r1          vulnerabilidades, attack surface
  AUDIT_ECONOMY      → gemini_flash     impacto en capital, ROI, kill-switch
  AUDIT_STRUCTURAL   → groq_qwen3       deuda técnica, SCI, acoplamiento
  AUDIT_ADVERSARIAL  → openrouter_r1    ¿cómo atacaría yo esto?
  AUDIT_INVARIANTS   → determinístico   violaciones constitucionales (veto)
"""

import json
import logging
import redis
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from typing import Optional
import re

from core.sea.llm_registry import LLMProviderRegistry, LLMResponse
from core.sea.formal_verifier import FormalVerifier

logger = logging.getLogger("kernell.pfe.audit_council_v2")

# ── System prompts ────────────────────────────────────────────────────────
SYSTEM_SECURITY = (
    "Eres AUDIT_SECURITY de Kernell OS, auditor de seguridad adversarial. "
    "Busca activamente: injection attacks, race conditions, privilege escalation, "
    "authentication bypass, HMAC bypass, data exfiltration vectors, "
    "dependency vulnerabilities, insecure deserialization. "
    "Tasa el riesgo de 0-100. "
    "Responde SOLO con JSON válido:\n"
    '{"vote":"APPROVE"|"REJECT","confidence":0.0-1.0,'
    '"reasoning":"","vulnerabilities_found":[],"risk_score":0-100}'
)

SYSTEM_ECONOMY = (
    "Eres AUDIT_ECONOMY de Kernell OS, auditor de impacto económico. "
    "Evalúa: ¿este patch puede causar pérdidas económicas? "
    "Verifica: kill-switch integridad, límites de riesgo, ROI constraints, "
    "capital de reserva, condiciones de stop-loss. "
    "Si el patch toca economía sin justificación clara → REJECT. "
    "Responde SOLO con JSON válido:\n"
    '{"vote":"APPROVE"|"REJECT","confidence":0.0-1.0,'
    '"reasoning":"","economic_risks":[],"risk_score":0-100}'
)

SYSTEM_STRUCTURAL = (
    "Eres AUDIT_STRUCTURAL de Kernell OS, auditor de arquitectura. "
    "Evalúa: ¿este patch aumenta el SCI injustificadamente? "
    "Verifica: acoplamiento nuevo, dependencias circulares, violaciones SOLID, "
    "complejidad ciclomática excesiva, deuda técnica introducida. "
    "Cuantifica el delta de complejidad esperado. "
    "Responde SOLO con JSON válido:\n"
    '{"vote":"APPROVE"|"REJECT","confidence":0.0-1.0,'
    '"reasoning":"","structural_issues":[],"expected_sci_delta":0.0,"risk_score":0-100}'
)

SYSTEM_ADVERSARIAL = (
    "Eres AUDIT_ADVERSARIAL de Kernell OS, red teamer. "
    "Piensa como un atacante con acceso interno. "
    "¿Cómo usarías este patch para comprometer el sistema? "
    "¿Introduce un vector de ataque nuevo? ¿Debilita defensas existentes? "
    "¿Permite manipular GSHI, TrustScore, o SVS? "
    "Responde SOLO con JSON válido:\n"
    '{"vote":"APPROVE"|"REJECT","confidence":0.0-1.0,'
    '"reasoning":"","attack_vectors":[],"risk_score":0-100}'
)


@dataclass
class AuditorVote:
    auditor: str
    domain: str
    vote: str                        # "APPROVE" | "REJECT"
    confidence: float
    reasoning: str
    findings: list[str]              # vulnerabilidades / riesgos encontrados
    risk_score: int                  # 0-100
    reasoning_trace: Optional[str]  # Chain-of-thought
    provider_used: str
    is_veto: bool                    # Solo True para AuditorInvariants cuando rechaza
    deterministic: bool              # True para AuditorInvariants


@dataclass
class AuditReport:
    proposal_id: str
    timestamp: str
    votes: list[dict]
    approve_count: int
    reject_count: int
    final_decision: str     # "APPROVED" | "REJECTED"
    aggregate_risk: int     # 0-100
    veto_applied: bool
    veto_reason: Optional[str]
    critical_findings: list[str]
    reasoning_traces: dict  # {auditor: trace}


class AuditCouncilV2:

    APPROVE_THRESHOLD = 4   # De 5 auditores, 4 deben APPROVE
    # Pesos para riesgo agregado
    RISK_WEIGHTS = {
        "AUDIT_SECURITY":    0.30,
        "AUDIT_ECONOMY":     0.20,
        "AUDIT_STRUCTURAL":  0.20,
        "AUDIT_ADVERSARIAL": 0.25,
        "AUDIT_INVARIANTS":  0.05,  # Peso bajo porque es binario (veto o no)
    }

    def __init__(self, redis_client: redis.Redis):
        self.redis    = redis_client
        self.registry = LLMProviderRegistry(redis_client)
        self.fv       = FormalVerifier(redis_client)

    # ── Auditoría principal ───────────────────────────────────────────────

    def audit(
        self,
        proposal_id: str,
        patch_context: dict,
        sandbox_results: dict,
    ) -> AuditReport:
        """
        Ejecuta los 5 auditores en paralelo (secuencial por seguridad).
        AuditorInvariants corre primero — si veta, los demás no corren.
        """
        logger.info(f"[AUDIT v2] Auditando {proposal_id[:8]}")

        diff         = patch_context.get("diff", "")
        target_files = patch_context.get("target_files", [])
        target_layer = patch_context.get("target_layer", "L2")
        user_content = self._format_patch(patch_context, sandbox_results)

        votes: list[AuditorVote] = []
        reasoning_traces: dict   = {}

        # ── AuditorInvariants primero (determinístico, posible veto) ──────
        inv_vote = self._audit_invariants(proposal_id, diff, target_files, target_layer)
        votes.append(inv_vote)
        if inv_vote.is_veto:
            # Veto inmediato — no gastar tokens en los demás
            return self._build_report(proposal_id, votes, reasoning_traces, veto=inv_vote)

        # ── 4 Auditores LLM ──────────────────────────────────────────────
        LLM_AUDITORS = [
            ("AUDIT_SECURITY",    "audit_security",    SYSTEM_SECURITY),
            ("AUDIT_ECONOMY",     "audit_economy",     SYSTEM_ECONOMY),
            ("AUDIT_STRUCTURAL",  "audit_structural",  SYSTEM_STRUCTURAL),
            ("AUDIT_ADVERSARIAL", "audit_adversarial", SYSTEM_ADVERSARIAL),
        ]

        for name, role, system in LLM_AUDITORS:
            resp = self.registry.complete(
                messages=[{"role": "user", "content": user_content}],
                system_prompt=system,
                role=role,
                max_tokens=1500,
                temperature=0.2,   # Bajo: auditores deben ser consistentes
            )
            vote = self._parse_llm_vote(name, role, resp)
            votes.append(vote)
            if vote.reasoning_trace:
                reasoning_traces[name] = vote.reasoning_trace

        return self._build_report(proposal_id, votes, reasoning_traces)

    # ── Auditor Invariants (determinístico) ───────────────────────────────

    def _audit_invariants(
        self,
        proposal_id: str,
        diff: str,
        target_files: list[str],
        target_layer: str,
    ) -> AuditorVote:
        """Usa el FormalVerifier para verificación matemática del patch."""
        fv_report = self.fv.verify(
            proposal_id=proposal_id,
            patch_diff=diff,
            target_files=target_files,
            target_layer=target_layer,
            phase="pre_audit",
        )

        is_veto = not fv_report.overall_passed
        findings = (
            fv_report.constitutional_violations
            + fv_report.fsm_violations
            + fv_report.math_violations
        )

        return AuditorVote(
            auditor="AUDIT_INVARIANTS",
            domain="constitutional",
            vote="APPROVE" if fv_report.overall_passed else "REJECT",
            confidence=1.0,   # Siempre 1.0 — es determinístico
            reasoning=(
                "All constitutional invariants verified"
                if fv_report.overall_passed
                else f"Constitutional violation: {fv_report.blocking_reason}"
            ),
            findings=findings,
            risk_score=0 if fv_report.overall_passed else 100,
            reasoning_trace=None,   # Sin LLM — no hay trace
            provider_used="deterministic",
            is_veto=is_veto,
            deterministic=True,
        )

    # ── Parse de voto LLM ─────────────────────────────────────────────────

    def _parse_llm_vote(
        self,
        name: str,
        role: str,
        resp: Optional[LLMResponse],
    ) -> AuditorVote:
        if resp is None:
            return AuditorVote(
                auditor=name, domain=role, vote="ABSTAIN",
                confidence=0.0, reasoning="Provider failed",
                findings=["No LLM response"], risk_score=50,
                reasoning_trace=None, provider_used="none",
                is_veto=False, deterministic=False,
            )

        try:
            text  = resp.content
            try:
                data = json.loads(text)
            except json.JSONDecodeError:
                m    = re.search(r"\{.*\}", text, re.DOTALL)
                data = json.loads(m.group()) if m else {}

            findings = (
                data.get("vulnerabilities_found")
                or data.get("economic_risks")
                or data.get("structural_issues")
                or data.get("attack_vectors")
                or []
            )

            return AuditorVote(
                auditor=name,
                domain=role,
                vote=data.get("vote", "ABSTAIN"),
                confidence=float(data.get("confidence", 0.5)),
                reasoning=str(data.get("reasoning", "")),
                findings=list(findings),
                risk_score=int(data.get("risk_score", 50)),
                reasoning_trace=resp.reasoning_trace,
                provider_used=resp.provider_used,
                is_veto=False,
                deterministic=False,
            )
        except Exception as e:
            logger.error(f"[AUDIT v2] Parse error {name}: {e}")
            return AuditorVote(
                auditor=name, domain=role, vote="ABSTAIN",
                confidence=0.0, reasoning=f"Parse error: {e}",
                findings=[], risk_score=50,
                reasoning_trace=resp.reasoning_trace if resp else None,
                provider_used=resp.provider_used if resp else "none",
                is_veto=False, deterministic=False,
            )

    # ── Construcción del reporte ──────────────────────────────────────────

    def _build_report(
        self,
        proposal_id: str,
        votes: list[AuditorVote],
        reasoning_traces: dict,
        veto: Optional[AuditorVote] = None,
    ) -> AuditReport:
        approve_count = sum(1 for v in votes if v.vote == "APPROVE")
        reject_count  = sum(1 for v in votes if v.vote == "REJECT")

        if veto:
            decision = "REJECTED"
        elif reject_count >= 2:
            decision = "REJECTED"
        elif approve_count >= self.APPROVE_THRESHOLD:
            decision = "APPROVED"
        else:
            decision = "REJECTED"  # No alcanzó quorum

        # Riesgo agregado ponderado
        aggregate_risk = 0
        for v in votes:
            w = self.RISK_WEIGHTS.get(v.auditor, 0.20)
            aggregate_risk += v.risk_score * w
        aggregate_risk = min(100, int(aggregate_risk))

        critical_findings = [
            f for v in votes if v.vote == "REJECT"
            for f in v.findings
        ]

        report = AuditReport(
            proposal_id=proposal_id,
            timestamp=datetime.now(timezone.utc).isoformat(),
            votes=[asdict(v) for v in votes],
            approve_count=approve_count,
            reject_count=reject_count,
            final_decision=decision,
            aggregate_risk=aggregate_risk,
            veto_applied=bool(veto),
            veto_reason=veto.reasoning if veto else None,
            critical_findings=critical_findings,
            reasoning_traces=reasoning_traces,
        )

        self._persist(report)
        logger.info(
            f"[AUDIT v2] {proposal_id[:8]}: {decision} "
            f"({approve_count}✅ {reject_count}❌) "
            f"risk={aggregate_risk} veto={bool(veto)}"
        )
        return report

    # ── Formato del patch para LLMs ───────────────────────────────────────

    def _format_patch(self, patch_ctx: dict, sandbox: dict) -> str:
        return (
            f"AUDITORÍA DE PATCH\n{'='*50}\n"
            f"Capa: {patch_ctx.get('target_layer','?')} | "
            f"Riesgo estimado: {patch_ctx.get('estimated_risk','?')}/100\n"
            f"Archivos: {', '.join(patch_ctx.get('target_files',[]))}\n"
            f"{'='*50}\n"
            f"DIFF:\n{patch_ctx.get('diff','')[:2000]}\n"
            f"{'='*50}\n"
            f"RESULTADOS SANDBOX:\n"
            f"  pass_rate: {sandbox.get('pass_rate','?')}\n"
            f"  violations: {sandbox.get('violations', 0)}\n"
            f"  anomalies: {sandbox.get('anomalies', [])}\n"
            f"{'='*50}\n"
            "Audita desde tu dominio de especialización. Responde SOLO en JSON."
        )

    # ── Persistencia ──────────────────────────────────────────────────────

    def _persist(self, report: AuditReport):
        self.redis.hset("kernell:pfe:audits", report.proposal_id, json.dumps(asdict(report)))
        self.redis.lpush("kernell:pfe:audit_history", json.dumps({
            "proposal_id": report.proposal_id,
            "decision":    report.final_decision,
            "risk":        report.aggregate_risk,
            "veto":        report.veto_applied,
            "timestamp":   report.timestamp,
        }))
        self.redis.ltrim("kernell:pfe:audit_history", 0, 99)
