#!/usr/bin/env python3
"""
core/sea/mcp_client.py
══════════════════════
Model Context Protocol (MCP) Client V2 for Kernell OS.

V1: Basic stdio tool discovery and invocation.
V2 (NEW): Resource listing, prompt listing, auth token support
          and connection health monitoring.

Implements modular MCP client with stdio transport for Kernell OS agents.

Usage:
    from core.sea.mcp_client import MCPClientStdio

    client = MCPClientStdio(
        ["npx", "-y", "@modelcontextprotocol/server-postgres", "postgres_url"],
        auth_token="sk-xxx"  # V2: optional auth
    )
    client.start()

    # Tools
    tools = client.list_tools()
    result = client.call_tool("query", {"sql": "SELECT 1"})

    # V2: Resources
    resources = client.list_resources()
    content = client.read_resource("file:///path/to/file")

    # V2: Prompts
    prompts = client.list_prompts()
    prompt = client.get_prompt("summarize", {"text": "..."})

    # V2: Health
    print(client.health_check())
"""

import json
import logging
import subprocess
import threading
import time
from typing import Optional, Any, Dict, List
import uuid

logger = logging.getLogger("MCPClient")


class MCPClientStdio:
    """
    Stdio-based MCP client for Kernell OS agents.
    V2: Adds resource listing, prompt listing, auth, and health monitoring.
    """
    
    def __init__(self, command: list[str], auth_token: Optional[str] = None,
                 env: Optional[Dict[str, str]] = None):
        """
        Initialize the MCP client.

        Args:
            command: Command to start the MCP server process
            auth_token: Optional auth token (injected as MCP_AUTH_TOKEN env var)
            env: Optional additional environment variables for the server process
        """
        self.command = command
        self._auth_token = auth_token
        self._extra_env = env or {}
        self.process = None
        self._lock = threading.Lock()
        self._callbacks = {}
        self._listen_thread = None
        
        self.server_name = "Unknown"
        self.server_version = "?"
        self.server_capabilities = {}
        self._connected = False
        self._connect_time = 0
        self._call_count = 0
        self._error_count = 0

    def start(self):
        """Start the MCP server process and perform handshake."""
        import os
        
        # Build environment with auth token if provided
        proc_env = os.environ.copy()
        if self._auth_token:
            proc_env["MCP_AUTH_TOKEN"] = self._auth_token
        proc_env.update(self._extra_env)
        
        logger.info(f"Iniciando MCP Server: {' '.join(self.command)}")
        self.process = subprocess.Popen(
            self.command,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1,
            env=proc_env,
        )
        self._listen_thread = threading.Thread(target=self._reader, daemon=True)
        self._listen_thread.start()
        
        self.initialize()
        self._connected = True
        self._connect_time = time.time()

    def stop(self):
        """Stop the MCP server process."""
        self._connected = False
        if self.process:
            self.process.terminate()
            try:
                self.process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.process.kill()
            self.process = None
        logger.info(f"[MCP] Server stopped: {self.server_name}")

    def _reader(self):
        """Bucle para vaciar y parsear el buffer de stdout"""
        if not self.process or not self.process.stdout:
            return
            
        for line in self.process.stdout:
            if not line.strip():
                continue
            try:
                msg = json.loads(line)
                if "id" in msg and msg["id"] in self._callbacks:
                    self._callbacks[msg["id"]](msg)
                elif "method" in msg:
                    # Log notifications
                    logger.debug(f"[MCP Notify] {msg['method']}")
            except json.JSONDecodeError:
                # No todos los servidores separan perfectamente por linea
                pass
            except Exception as e:
                logger.error(f"[MCP] Read error: {e}")

    def call_sync(self, method: str, params: dict = None, timeout: float = 20.0) -> dict:
        """Invoca a un método JSON-RPC y bloquea hasta respuesta."""
        req_id = str(uuid.uuid4())
        payload = {
            "jsonrpc": "2.0",
            "id": req_id,
            "method": method,
            "params": params or {}
        }
        
        res_container = []
        event = threading.Event()

        def cb(response):
            res_container.append(response)
            event.set()

        with self._lock:
            self._callbacks[req_id] = cb
            raw = json.dumps(payload)
            self.process.stdin.write(raw + "\n")
            self.process.stdin.flush()

        event.wait(timeout)

        with self._lock:
            if req_id in self._callbacks:
                del self._callbacks[req_id]

        self._call_count += 1

        if not res_container:
            self._error_count += 1
            raise TimeoutError(f"MCP Call '{method}' timed out ({timeout}s)")
            
        res = res_container[0]
        if "error" in res:
            self._error_count += 1
            logger.error(f"[MCP] JSON-RPC Error: {res['error']}")
            raise RuntimeError(f"MCP Error: {res['error'].get('message', str(res['error']))}")
            
        return res.get("result", {})

    def initialize(self):
        """Phase 1/2 of connecting to MCP"""
        res = self.call_sync("initialize", {
            "protocolVersion": "2024-11-05",
            "capabilities": {
                "tools": { "listChanged": True },
                "resources": { "subscribe": True, "listChanged": True },
                "prompts": { "listChanged": True },
            },
            "clientInfo": {
                "name": "Kernell-OS-Agentic-Forge",
                "version": "v2.0"
            }
        })
        
        # Send initialized notification
        notify = {
            "jsonrpc": "2.0",
            "method": "notifications/initialized",
            "params": {}
        }
        with self._lock:
            self.process.stdin.write(json.dumps(notify) + "\n")
            self.process.stdin.flush()
            
        server_info = res.get('serverInfo', {})
        self.server_name = server_info.get('name', 'Unknown')
        self.server_version = server_info.get('version', '?')
        self.server_capabilities = res.get('capabilities', {})
        logger.info(
            f"[MCP] Handshake completo. Servidor: {self.server_name} v{self.server_version} "
            f"| capabilities: {list(self.server_capabilities.keys())}"
        )
        return res

    # ── Tools (V1) ───────────────────────────────────────────────────────

    def list_tools(self) -> List[dict]:
        """Devuelve el arreglo estandarizado de Tools"""
        res = self.call_sync("tools/list")
        return res.get("tools", [])

    def call_tool(self, name: str, args: dict) -> Any:
        """Execute a tool by name with arguments."""
        try:
            res = self.call_sync("tools/call", {
                "name": name,
                "arguments": args
            })
            
            # Format return to something native (MCP yields an array of contents text/image)
            contents = res.get("content", [])
            output = []
            for c in contents:
                if c.get("type") == "text":
                    output.append(c.get("text"))
                elif c.get("type") == "image":
                    output.append(f"[IMAGE: {c.get('mimeType', 'unknown')}]")
                    
            return "\n".join(output) if output else "Tool executed. No output."
            
        except Exception as e:
            return f"Tool Execution Failed: {str(e)}"

    # ── Resources (V2) ───────────────────────────────────────────────────

    def list_resources(self) -> List[dict]:
        """
        List available resources from the MCP server.
        Resources are data the server exposes (files, DB tables, etc.).

        Returns:
            List of resource descriptors with uri, name, mimeType, etc.
        """
        if "resources" not in self.server_capabilities:
            logger.debug(f"[MCP] Server {self.server_name} does not support resources")
            return []
        try:
            res = self.call_sync("resources/list")
            return res.get("resources", [])
        except Exception as e:
            logger.warning(f"[MCP] list_resources failed: {e}")
            return []

    def read_resource(self, uri: str) -> str:
        """
        Read the content of a specific resource by URI.

        Args:
            uri: Resource URI (e.g., "file:///path/to/file" or "pg://table/name")

        Returns:
            Text content of the resource
        """
        try:
            res = self.call_sync("resources/read", {"uri": uri})
            contents = res.get("contents", [])
            parts = []
            for c in contents:
                if c.get("text"):
                    parts.append(c["text"])
                elif c.get("blob"):
                    parts.append(f"[BINARY: {len(c['blob'])} bytes]")
            return "\n".join(parts) if parts else ""
        except Exception as e:
            logger.error(f"[MCP] read_resource({uri}) failed: {e}")
            return f"Error: {e}"

    def subscribe_resource(self, uri: str) -> bool:
        """Subscribe to changes on a resource (if server supports it)."""
        if not self.server_capabilities.get("resources", {}).get("subscribe"):
            return False
        try:
            self.call_sync("resources/subscribe", {"uri": uri})
            return True
        except Exception:
            return False

    # ── Prompts (V2) ─────────────────────────────────────────────────────

    def list_prompts(self) -> List[dict]:
        """
        List available prompt templates from the MCP server.

        Returns:
            List of prompt descriptors with name, description, arguments.
        """
        if "prompts" not in self.server_capabilities:
            return []
        try:
            res = self.call_sync("prompts/list")
            return res.get("prompts", [])
        except Exception as e:
            logger.warning(f"[MCP] list_prompts failed: {e}")
            return []

    def get_prompt(self, name: str, arguments: dict = None) -> str:
        """
        Get a rendered prompt template from the server.

        Args:
            name: Prompt template name
            arguments: Arguments to fill in the template

        Returns:
            Rendered prompt text
        """
        try:
            res = self.call_sync("prompts/get", {
                "name": name,
                "arguments": arguments or {},
            })
            messages = res.get("messages", [])
            parts = []
            for msg in messages:
                content = msg.get("content", {})
                if isinstance(content, dict) and content.get("type") == "text":
                    parts.append(content["text"])
                elif isinstance(content, str):
                    parts.append(content)
            return "\n".join(parts)
        except Exception as e:
            logger.error(f"[MCP] get_prompt({name}) failed: {e}")
            return f"Error: {e}"

    # ── Health & Status (V2) ─────────────────────────────────────────────

    def health_check(self) -> dict:
        """
        Return health status of the MCP connection.

        Returns:
            Dict with connection status, uptime, call stats, etc.
        """
        alive = self._connected and self.process is not None
        if alive:
            try:
                alive = self.process.poll() is None
            except Exception:
                alive = False

        uptime = time.time() - self._connect_time if self._connect_time else 0

        return {
            "server": self.server_name,
            "version": self.server_version,
            "connected": alive,
            "uptime_s": round(uptime, 1),
            "calls": self._call_count,
            "errors": self._error_count,
            "error_rate": round(self._error_count / max(1, self._call_count), 3),
            "capabilities": list(self.server_capabilities.keys()),
            "has_auth": bool(self._auth_token),
        }

    @property
    def is_connected(self) -> bool:
        """Check if the MCP server is still running."""
        if not self._connected or not self.process:
            return False
        return self.process.poll() is None

    def __repr__(self) -> str:
        status = "connected" if self.is_connected else "disconnected"
        return f"MCPClientStdio({self.server_name}, {status}, calls={self._call_count})"

