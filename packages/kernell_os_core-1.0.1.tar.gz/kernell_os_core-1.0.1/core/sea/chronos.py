"""
CHRONOS — Orquestador Maestro de Kernell OS
============================================
El componente que faltaba: quién llama a qué y cuándo.

Sin Chronos, el SEA es un conjunto de módulos sin vida.
Chronos es el corazón que los hace latir en orden.

RESPONSABILIDADES:
  - SVS cada 2 horas (verificación sectorial)
  - GSHI cada 30 minutos (salud del sistema)
  - Synthesis cada 4 horas (razonamiento narrativo)
  - Red Team daemon en background (continuo)
  - PFE cuando hay propuestas pendientes + SVS pasó + GSHI ≥ 55
  - Escalación cuando GSHI cae > 10 puntos en 1 ciclo

DISEÑO:
  Chronos es un proceso Python que corre como daemon.
  Cada tarea tiene su propio scheduler entry con:
    - intervalo base
    - jitter aleatorio (para que no todo corra simultáneo)
    - condiciones de activación
    - timeout máximo
    - cooldown post-error

  Las tareas se ejecutan en threads separados para no bloquear.
  Chronos mismo es supervisado por el Overseer Beta.

ARRANQUE:
  python -m kernell.chronos.chronos --layer core --redis-url redis://localhost:6379

CONTROL:
  chronos.pause()           → pausa todas las tareas
  chronos.resume()          → reanuda
  chronos.trigger_svs()     → corre SVS inmediatamente
  chronos.trigger_synthesis("manual") → síntesis inmediata
  chronos.status()          → estado de todas las tareas
"""

import json
import logging
import os
import time
import threading
import random
import signal
import sys
from dataclasses import dataclass, asdict
from datetime import datetime, timezone, timedelta
from typing import Optional, Callable
import redis

logger = logging.getLogger("kernell.chronos")

# ── Intervalos de tareas (segundos) ──────────────────────────────────────
TASK_INTERVALS = {
    "svs":          2 * 3600,     # SVS cada 2 horas
    "gshi":         30 * 60,      # GSHI cada 30 min
    "synthesis":    4 * 3600,     # Synthesis cada 4 horas
    "pfe_check":    15 * 60,      # Revisar propuestas pendientes cada 15 min
    "red_team":     5 * 60,       # Red Team tick cada 5 min (+ jitter interno)
    "heartbeat":    60,           # Chronos heartbeat cada 60s
}

JITTER_MAX_S = 120   # Máximo jitter aleatorio por tarea (evita thundering herd)

# Cooldown post-error por tarea
ERROR_COOLDOWN = {
    "svs":          15 * 60,
    "gshi":         5  * 60,
    "synthesis":    10 * 60,
    "pfe_check":    5  * 60,
    "red_team":     2  * 60,
}


@dataclass
class TaskStatus:
    name: str
    last_run: Optional[str]
    last_result: str              # "OK" | "ERROR" | "SKIP" | "PENDING"
    next_run: Optional[str]
    run_count: int
    error_count: int
    last_error: Optional[str]
    paused: bool


class ChronosTask:
    """Envuelve una tarea con su estado, lock, y scheduling."""

    def __init__(
        self,
        name: str,
        fn: Callable,
        interval_s: int,
        jitter_s: int = 60,
    ):
        self.name       = name
        self.fn         = fn
        self.interval_s = interval_s
        self.jitter_s   = jitter_s
        self._lock      = threading.Lock()
        self._paused    = False
        self._run_count = 0
        self._err_count = 0
        self._last_run: Optional[datetime]  = None
        self._last_err: Optional[str]       = None
        self._last_result: str              = "PENDING"
        self._next_run: datetime            = datetime.now(timezone.utc)

    def should_run(self) -> bool:
        if self._paused:
            return False
        if self._lock.locked():
            return False   # Ya está corriendo
        return datetime.now(timezone.utc) >= self._next_run

    def run(self):
        if not self._lock.acquire(blocking=False):
            return
        try:
            logger.info(f"[CHRONOS] → {self.name}")
            t0 = time.time()
            self.fn()
            elapsed = time.time() - t0
            self._last_result = "OK"
            self._run_count  += 1
            self._last_run    = datetime.now(timezone.utc)
            logger.info(f"[CHRONOS] ✓ {self.name} ({elapsed:.1f}s)")
        except Exception as e:
            self._last_result = "ERROR"
            self._err_count  += 1
            self._last_err    = str(e)[:200]
            logger.error(f"[CHRONOS] ✗ {self.name}: {e}")
            # Cooldown extendido post-error
            jitter = random.uniform(0, self.jitter_s)
            self._next_run = datetime.now(timezone.utc) + timedelta(
                seconds=ERROR_COOLDOWN.get(self.name, self.interval_s) + jitter
            )
            return
        finally:
            self._lock.release()

        # Schedule siguiente ejecución normal
        jitter = random.uniform(0, self.jitter_s)
        self._next_run = datetime.now(timezone.utc) + timedelta(
            seconds=self.interval_s + jitter
        )

    def trigger_immediate(self):
        """Forzar ejecución inmediata en el próximo tick."""
        self._next_run = datetime.now(timezone.utc)

    def pause(self):
        self._paused = True

    def resume(self):
        self._paused = False

    def status(self) -> TaskStatus:
        return TaskStatus(
            name=self.name,
            last_run=self._last_run.isoformat() if self._last_run else None,
            last_result=self._last_result,
            next_run=self._next_run.isoformat(),
            run_count=self._run_count,
            error_count=self._err_count,
            last_error=self._last_err,
            paused=self._paused,
        )


class Chronos:
    """
    Orquestador maestro de todos los ciclos de Kernell OS.
    Daemon de larga duración. Se registra en Redis para supervisión.
    """

    def __init__(
        self,
        redis_client: redis.Redis,
        layer: str = "core",
    ):
        self.redis  = redis_client
        self.layer  = layer
        self._running = False
        self._tasks: dict[str, ChronosTask] = {}

        # Importaciones lazy para evitar circular imports en el módulo
        self._init_tasks()

        # Manejo de señales para shutdown limpio
        signal.signal(signal.SIGTERM, self._signal_handler)
        signal.signal(signal.SIGINT,  self._signal_handler)

    # ── Inicialización de tareas ──────────────────────────────────────────

    def _init_tasks(self):
        """Construye e instancia todos los módulos y sus tareas."""
        from core.sea.svs_v2 import SVSv2
        from core.sea.gshi_v2 import GSHIv2
        from core.sea.synthesis_agent import SynthesisAgent

        secret = self._get_system_secret()

        self._svs       = SVSv2(self.redis, secret)
        self._gshi      = GSHIv2(self.redis, secret)
        self._synthesis = SynthesisAgent(self.redis)

        # Tareas core (siempre activas)
        self._register("svs",       self._task_svs,       TASK_INTERVALS["svs"])
        self._register("gshi",      self._task_gshi,      TASK_INTERVALS["gshi"])
        self._register("synthesis", self._task_synthesis, TASK_INTERVALS["synthesis"])
        self._register("pfe_check", self._task_pfe_check, TASK_INTERVALS["pfe_check"])
        self._register("heartbeat", self._task_heartbeat, TASK_INTERVALS["heartbeat"], jitter_s=0)

        # Red Team solo en CORE
        if self.layer == "core":
            try:
                from core.sea.tricapa_and_redteam import RedTeamAdversarial
                self._red_team = RedTeamAdversarial(self.redis)
                self._register("red_team", self._task_red_team, TASK_INTERVALS["red_team"])
            except ImportError:
                logger.warning("[CHRONOS] RedTeamAdversarial module not found. Skipping red_team task.")

    def _register(self, name: str, fn: Callable, interval_s: int, jitter_s: int = JITTER_MAX_S):
        self._tasks[name] = ChronosTask(name, fn, interval_s, jitter_s)

    # ── Tareas ────────────────────────────────────────────────────────────

    def _task_svs(self):
        """Sectoral Verification Sweep."""
        report = self._svs.run_sweep(allow_degraded=True)

        if report.overall_result == "FAIL":
            logger.critical(f"[CHRONOS] SVS FAIL — Hard Freeze activado")
            self.redis.set("kernell:system:last_svs_result", "FAIL")
        else:
            self.redis.set("kernell:system:last_svs_result", report.overall_result)

        # Si SVS degraded → reducir frecuencia de síntesis
        if report.degraded_mode:
            self._tasks["synthesis"].trigger_immediate()
            logger.warning("[CHRONOS] SVS degraded → síntesis inmediata")

    def _task_gshi(self):
        """Global System Health Index."""
        # Calcular SII actual para pasarlo al GSHI
        sii = self._calculate_sii()
        report = self._gshi.calculate(sii)

        prev_gshi = self._get_prev_gshi()
        current   = report.gshi_ema

        # Caída > 10 puntos → síntesis inmediata
        if prev_gshi and (prev_gshi - current) > 10:
            logger.warning(
                f"[CHRONOS] GSHI drop {prev_gshi:.1f}→{current:.1f} "
                f"({prev_gshi-current:.1f}pts) → síntesis inmediata"
            )
            self._tasks["synthesis"].trigger_immediate()
            # Registrar como trigger para Synthesis
            self.redis.set("kernell:chronos:synthesis_trigger", "gshi_drop")

        # Actualizar triggers automáticos por GSHI
        from core.sea.policy_engine import PolicyEngine
        pe = PolicyEngine(self.redis, self.layer)
        actions = pe.evaluate_gshi_enforcement(current)
        for action_group in actions:
            for act in action_group.get("actions", []):
                logger.info(f"[CHRONOS] GSHI enforcement: {act}")

    def _task_synthesis(self):
        """Razonamiento narrativo profundo."""
        trigger = self._decode(self.redis.get("kernell:chronos:synthesis_trigger")) or "scheduled"
        self.redis.delete("kernell:chronos:synthesis_trigger")
        self._synthesis.synthesize(trigger=trigger)

    def _task_pfe_check(self):
        """Verifica si hay propuestas pendientes y las procesa si las condiciones lo permiten."""
        # Obtener propuestas pendientes
        pending_raw = self.redis.lrange("kernell:pfe:pending_proposals", 0, 0)
        if not pending_raw:
            return

        from core.sea.pfe_orchestrator import PFEOrchestrator
        orchestrator = PFEOrchestrator(self.redis)

        proposal_data = json.loads(pending_raw[0])

        # Verificar condiciones de PFE
        can_run, reason, scope = self._svs.is_pfe_allowed()
        if not can_run:
            logger.debug(f"[CHRONOS] PFE bloqueado: {reason}")
            return

        logger.info(f"[CHRONOS] Procesando propuesta pendiente: {proposal_data.get('proposal_id','?')[:8]}")

        # Pop de la cola y ejecutar
        self.redis.lpop("kernell:pfe:pending_proposals")
        result = orchestrator.run_evolution(proposal_data, pfe_scope=scope)

        # Después del PFE → síntesis automática
        if result and result.promoted:
            self.redis.set("kernell:chronos:synthesis_trigger", "post_pfe")
            self._tasks["synthesis"].trigger_immediate()

    def _task_red_team(self):
        """Tick del Red Team adversarial."""
        self._red_team.run_single_attack()

    def _task_heartbeat(self):
        """Registra que Chronos está vivo."""
        self.redis.set(
            "kernell:chronos:heartbeat",
            json.dumps({
                "layer":     self.layer,
                "running":   self._running,
                "tasks":     {n: t.status().last_result for n, t in self._tasks.items()},
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }),
            ex=120,  # TTL 2 min — si expira, Chronos está muerto
        )

    # ── Loop principal ────────────────────────────────────────────────────

    def _get_system_mode(self) -> str:
        """Reads kernell:system:mode from Redis. Defaults to STABLE."""
        try:
            mode = self.redis.get("kernell:system:mode")
            return mode.decode() if mode else "STABLE"
        except Exception:
            return "STABLE"

    def _apply_interval_scaling(self, mode: str):
        """Blueprint XII: Adjust task intervals dynamically based on system stress."""
        multiplier = 1.0
        if mode == "STRESS":
            multiplier = 0.5  # Run twice as fast during stress
        elif mode == "CRITICAL":
            multiplier = 0.33 # Run 3x as fast during critical events
        
        # We don't track >30min STABLE here directly to keep it simple,
        # but the base interval is already optimized for STABLE.
        
        for name, task in self._tasks.items():
            # Heartbeats always run at their fixed 60s
            if name == "heartbeat":
                continue
            
            # Use original interval stored in TASK_INTERVALS as base
            from core.sea.chronos import TASK_INTERVALS
            base_interval = TASK_INTERVALS.get(name, task.interval_s)
            task.interval_s = max(5, int(base_interval * multiplier))

    def start(self):
        """Inicia el loop principal de Chronos. Bloqueante."""
        self._running = True
        logger.info(
            f"[CHRONOS] ═══ Iniciando — layer={self.layer} "
            f"tareas={list(self._tasks.keys())} ═══"
        )

        # SVS inmediato al arranque para establecer baseline
        self._tasks["svs"].trigger_immediate()
        self._tasks["gshi"].trigger_immediate()

        while self._running:
            mode = self._get_system_mode()
            self._apply_interval_scaling(mode)
            
            for name, task in self._tasks.items():
                if task.should_run():
                    thread = threading.Thread(
                        target=task.run,
                        name=f"chronos-{name}",
                        daemon=True,
                    )
                    thread.start()

            time.sleep(5)  # Tick cada 5 segundos

        logger.info("[CHRONOS] ═══ Detenido ═══")

    def stop(self):
        self._running = False
        logger.info("[CHRONOS] Señal de parada recibida")

    def _signal_handler(self, sig, frame):
        logger.info(f"[CHRONOS] Señal {sig} recibida — shutdown limpio")
        self.stop()
        sys.exit(0)

    # ── Control manual ────────────────────────────────────────────────────

    def trigger_svs(self):
        self._tasks["svs"].trigger_immediate()

    def trigger_synthesis(self, reason: str = "manual"):
        self.redis.set("kernell:chronos:synthesis_trigger", reason)
        self._tasks["synthesis"].trigger_immediate()

    def trigger_gshi(self):
        self._tasks["gshi"].trigger_immediate()

    def pause_all(self):
        for task in self._tasks.values():
            task.pause()
        logger.warning("[CHRONOS] Todas las tareas pausadas")

    def resume_all(self):
        for task in self._tasks.values():
            task.resume()
        logger.info("[CHRONOS] Todas las tareas reanudadas")

    def status(self) -> dict:
        return {
            "layer":    self.layer,
            "running":  self._running,
            "tasks":    {n: asdict(t.status()) for n, t in self._tasks.items()},
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    # ── Helpers ───────────────────────────────────────────────────────────

    def _calculate_sii(self) -> float:
        """
        Cálculo básico del SII para pasar al GSHI.
        En producción esto vendría del SIIEngine completo.
        """
        # InvariantStrength: % de ataques Red Team detectados
        rt_raw = self.redis.lrange("kernell:red_team:attacks", 0, 49)
        if rt_raw:
            attacks   = [json.loads(a) for a in rt_raw]
            detected  = sum(1 for a in attacks if a.get("detected"))
            inv_str   = (detected / len(attacks)) * 100 if attacks else 75
        else:
            inv_str = 75.0

        # RedTeamResistance: tiempo promedio de escalación (normalizado)
        rt_avg = self.redis.get("kernell:red_team:avg_escalation_minutes")
        rt_res = min(100, float(rt_avg or 60) / 120 * 100) if rt_avg else 60.0

        # RecoveryEfficiency: tiempo CRITICAL→STABLE (de historial)
        rec_eff = float(self.redis.get("kernell:system:recovery_efficiency") or 70)

        # VulnDensity: de últimos CVE scan
        cve_raw = self.redis.get("kernell:svs:last_cve_scan")
        if cve_raw:
            crit = json.loads(cve_raw).get("critical_count", 0)
            vuln_inv = max(0, 100 - crit * 20)
        else:
            vuln_inv = 80.0

        # DriftStability: varianza del drift histórico
        drift_std = float(self.redis.get("kernell:drift:std_30d") or 10)
        drift_stab = max(0, min(100, 100 - (drift_std - 5) * 4)) if drift_std > 5 else 100

        sii = (
            0.25 * inv_str
            + 0.20 * rt_res
            + 0.20 * rec_eff
            + 0.20 * vuln_inv
            + 0.15 * drift_stab
        )
        return round(min(100, max(0, sii)), 2)

    def _get_prev_gshi(self) -> Optional[float]:
        history = self.redis.lrange("kernell:gshi:v2:history", 1, 1)
        if history:
            return json.loads(history[0]).get("gshi_ema")
        return None

    def _get_system_secret(self) -> str:
        raw = self.redis.get("kernell:system:secret")
        if raw:
            return raw if isinstance(raw, str) else raw.decode()
        # Generar y guardar si no existe
        import secrets
        s = secrets.token_hex(32)
        self.redis.set("kernell:system:secret", s)
        logger.warning("[CHRONOS] System secret generado — guardarlo de forma segura")
        return s

    def _decode(self, raw) -> Optional[str]:
        if raw is None:
            return None
        return raw if isinstance(raw, str) else raw.decode()


# ── Entry point de línea de comandos ─────────────────────────────────────

def main():
    import argparse
    parser = argparse.ArgumentParser(description="Kernell OS Chronos Orchestrator")
    parser.add_argument("--layer",     default="core",             choices=["core", "enterprise", "platform"])
    parser.add_argument("--redis-url", default=None)
    parser.add_argument("--log-level", default="INFO")
    args = parser.parse_args()

    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s %(name)s %(levelname)s %(message)s",
    )

    if args.redis_url:
        r = redis.from_url(args.redis_url, decode_responses=True)
    else:
        # FIX: default port 6380, auth from env
        pw = os.getenv("REDIS_PASSWORD", "").strip().strip("\"'") or None
        r = redis.Redis(
            host="127.0.0.1", port=int(os.getenv("REDIS_PORT", 6380)),
            decode_responses=True, password=pw,
        )
    chronos = Chronos(r, layer=args.layer)
    chronos.start()


if __name__ == "__main__":
    main()
