"""
Harlemm «Reality» pipeline — constitution file snippets + live Redis digest + RAG (Qdrant).

Ensambla el system prompt antes de `LLMProviderRegistry.complete` para `harlemm_conrrad`.
Lectura-mostly: RAG vía `agents.core.qdrant_preflight.search_before_llm` (import perezoso).
"""

from __future__ import annotations

import json
import logging
import os
import time
from pathlib import Path
from typing import Any, Optional

log = logging.getLogger("HarlemmReality")

_DEFAULT_CFG: dict[str, Any] = {
    "prompt_pack_version": "0",
    "base_instructions": "",
    "constitution_files": [],
    "grounding_rules": "",
    "rag": {"enabled": True, "agent_name": "harlemm"},
    "live_redis": {
        "defcon": "kernell:system:defcon",
        "swarm": "kernell:neurons:swarm",
        "resource_alerts": "kernell:neurons:resource_alerts",
    },
    "redis_constitution_override_key": "kernell:harlemm:constitution_override",
    "write_episodes_after_response": False,
    "write_episodes_skip_if_fallback": True,
    "write_episodes_providers_allowlist": ["hf_conrrad"],
}


def _deep_merge(base: dict, override: dict) -> dict:
    out = dict(base)
    for k, v in override.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def load_reality_config(root: Path) -> dict[str, Any]:
    env_path = os.environ.get("HARLEMM_REALITY_CONFIG", "").strip()
    if env_path:
        p = Path(env_path)
    else:
        p = root / "config" / "harlemm_reality.json"
    cfg = dict(_DEFAULT_CFG)
    if p.is_file():
        try:
            raw = json.loads(p.read_text(encoding="utf-8"))
            if isinstance(raw, dict):
                cfg = _deep_merge(cfg, raw)
        except Exception as e:
            log.warning("harlemm_reality config invalid %s: %s", p, e)
    return cfg


def _read_file_snippet(root: Path, rel: str, max_chars: int, from_start: bool) -> str:
    path = (root / rel).resolve()
    try:
        if not str(path).startswith(str(root.resolve())):
            return ""
        text = path.read_text(encoding="utf-8", errors="replace")
    except Exception as e:
        log.debug("constitution file skip %s: %s", rel, e)
        return ""
    if max_chars <= 0 or len(text) <= max_chars:
        return text
    if from_start:
        return text[:max_chars] + "\n[...truncado...]\n"
    return "[...truncado...]\n" + text[-max_chars:]


class HarlemmRealityPipeline:
    """
    Builds the Harlemm system prompt: base + optional repo snippets + LIVE digest + RAG prefix.
    """

    def __init__(self, redis_client: Any, root: Optional[Path] = None):
        self.redis = redis_client
        self.root = root or Path(__file__).resolve().parents[2]
        self._cfg = load_reality_config(self.root)

    @property
    def config(self) -> dict[str, Any]:
        return self._cfg

    def reload_config(self) -> None:
        self._cfg = load_reality_config(self.root)

    def _constitution_from_files(self) -> str:
        parts: list[str] = []
        for spec in self._cfg.get("constitution_files") or []:
            if not isinstance(spec, dict):
                continue
            rel = str(spec.get("path") or "").strip()
            if not rel:
                continue
            cap = int(spec.get("max_chars") or 8000)
            from_start = bool(spec.get("from_start", True))
            snip = _read_file_snippet(self.root, rel, cap, from_start)
            if snip.strip():
                parts.append(f"--- {rel} (extracto) ---\n{snip.strip()}")
        return "\n\n".join(parts)

    def _redis_constitution_override(self) -> str:
        key = self._cfg.get("redis_constitution_override_key") or ""
        if not key:
            return ""
        try:
            raw = self.redis.get(key)
        except Exception:
            return ""
        if raw is None:
            return ""
        if isinstance(raw, bytes):
            raw = raw.decode("utf-8", errors="replace")
        s = str(raw).strip()
        return f"--- OVERRIDE (Redis {key}) ---\n{s}" if s else ""

    def build_live_digest(self) -> str:
        """Compact Skynet / neurons snapshot from Redis (same contract as Harlemm v0)."""
        lr = self._cfg.get("live_redis") or _DEFAULT_CFG["live_redis"]
        k_def = lr.get("defcon") or "kernell:system:defcon"
        k_swarm = lr.get("swarm") or "kernell:neurons:swarm"
        k_res = lr.get("resource_alerts") or "kernell:neurons:resource_alerts"

        defcon = None
        try:
            defcon = self.redis.get(k_def)
            if isinstance(defcon, bytes):
                defcon = defcon.decode("utf-8", errors="replace")
        except Exception:
            defcon = None

        swarm = None
        try:
            raw = self.redis.get(k_swarm)
            if raw:
                if isinstance(raw, bytes):
                    raw = raw.decode("utf-8", errors="replace")
                swarm = json.loads(raw)
        except Exception:
            swarm = None

        has_resource_alert = False
        try:
            has_resource_alert = bool(self.redis.get(k_res))
        except Exception:
            has_resource_alert = False

        if not swarm:
            return (
                f"ts={int(time.time())} "
                f"defcon={defcon or 'unknown'} "
                "neurons=NO_DATA "
                f"resource_alert={has_resource_alert}"
            )

        agg = swarm.get("aggregate") or {}
        n_neurons = swarm.get("n_neurons", 0)
        avg_fit = agg.get("avg_fitness", 0)
        avg_acc = agg.get("avg_accuracy", 0)
        total_lessons = agg.get("total_lessons", 0)
        total_drastic = agg.get("total_drastic", 0)
        uptime_h = swarm.get("uptime_hours", 0)

        return (
            f"[LIVE] NeuronSwarm: n={n_neurons} avg_fitness={avg_fit} avg_acc={avg_acc} "
            f"lessons={total_lessons} drastic_total={total_drastic} "
            f"uptime_h={uptime_h} resource_alert={has_resource_alert} defcon={defcon or 'unknown'}"
        )

    def build_rag_prefix(self, question: str) -> tuple[str, dict[str, Any]]:
        rag = self._cfg.get("rag") or {}
        if not rag.get("enabled", True):
            return "", {"skipped": True}
        if os.environ.get("HARLEMM_RAG_DISABLE", "").strip().lower() in (
            "1",
            "true",
            "yes",
            "on",
        ):
            return "", {"skipped": True, "reason": "HARLEMM_RAG_DISABLE"}
        try:
            from agents.core.qdrant_preflight import search_before_llm
        except Exception as e:
            log.debug("RAG import failed: %s", e)
            return "", {"error": str(e)}

        agent_name = str(rag.get("agent_name") or "harlemm")
        try:
            pre = search_before_llm(question, agent_name=agent_name)
        except Exception as e:
            log.debug("search_before_llm failed: %s", e)
            return "", {"error": str(e)}

        block = (pre.get("enriched_prefix") or "").strip()
        meta = {
            "results_count": pre.get("results_count", 0),
            "search_ms": pre.get("search_ms", 0),
            "qdrant_available": pre.get("qdrant_available", False),
        }
        return block, meta

    def build_system_prompt(self, question: str, *, compact: bool = False) -> str:
        if compact:
            return self._build_compact_system_prompt()
        ver = self._cfg.get("prompt_pack_version", "0")
        header = f"[HARLEMM_REALITY v{ver}]"

        base = (self._cfg.get("base_instructions") or "").strip()
        constitution = self._constitution_from_files().strip()
        override = self._redis_constitution_override().strip()
        digest = self.build_live_digest().strip()
        rag_block, _meta = self.build_rag_prefix(question)
        rules = (self._cfg.get("grounding_rules") or "").strip()

        live_section = f"CONTEXTO_NEURONAL [LIVE] (digest, puede estar desfasado ≤2min):\n{digest}"
        rag_section = ""
        if rag_block:
            rag_section = f"CONTEXTO_VECTORIAL [RAG]:\n{rag_block}"

        parts = [
            header,
            base,
            constitution or None,
            override or None,
            live_section,
            rag_section or None,
            f"Reglas de citación y tono:\n{rules}" if rules else None,
        ]
        return "\n\n".join(p for p in parts if p)

    def _build_compact_system_prompt(self) -> str:
        """
        Prompt corto para modelos locales pequeños (p. ej. Derek 0.5B): sin extractos
        largos de repo ni RAG pesado — evita timeouts con system prompts de ~1.7k+ tokens.
        """
        ver = self._cfg.get("prompt_pack_version", "0")
        header = f"[HARLEMM_REALITY v{ver} COMPACT — local/pequeño contexto]"
        digest = self.build_live_digest().strip()
        base = (self._cfg.get("base_instructions") or "").strip()
        if len(base) > 1200:
            base = base[:1200] + "\n[...]\n"
        rules = (self._cfg.get("grounding_rules") or "").strip()
        if len(rules) > 600:
            rules = rules[:600] + "\n[...]\n"
        parts = [
            header,
            "Modo Kernell OS: respuestas técnicas, breves, accionables. "
            "No inventes rutas, claves ni endpoints.",
            f"CONTEXTO_LIVE:\n{digest}",
        ]
        if base:
            parts.append(f"Instrucciones base:\n{base}")
        if rules:
            parts.append(f"Citación / tono:\n{rules}")
        return "\n\n".join(p for p in parts if p)

    def build_last_resort_overlay(self, inner_system: str) -> str:
        """
        Contexto mínimo cuando fallan APIs comerciales: banner + LIVE + reglas base,
        sin RAG ni extractos de repo (menor latencia y sin dependencia de Qdrant/HF).
        """
        banner = (
            "[ÚLTIMO RECURSO KERNELL — Harlemm]\n"
            "Fallaron los proveedores del rol solicitado (API keys, red o circuit breakers). "
            "Responde con utilidad; indica explícitamente modo RESPALDO; "
            "no inventes claves ni hechos no respaldados por CONTEXTO_LIVE."
        )
        live = self.build_live_digest().strip()
        core = (self._cfg.get("base_instructions") or "").strip()
        inner = (inner_system or "").strip()
        parts = [banner, f"CONTEXTO_LIVE:\n{live}"]
        if core:
            parts.append(core)
        if inner:
            parts.append("--- Instrucciones del rol (original) ---\n" + inner)
        return "\n\n".join(p for p in parts if p)

    def should_write_episode(self, resp: Any) -> bool:
        if os.environ.get("HARLEMM_WRITE_EPISODES", "").strip().lower() in (
            "1",
            "true",
            "yes",
            "on",
        ):
            force = True
        else:
            force = False
        if not force and not self._cfg.get("write_episodes_after_response"):
            return False
        if self._cfg.get("write_episodes_skip_if_fallback", True) and getattr(
            resp, "fallback_used", False
        ):
            return False
        allow = self._cfg.get("write_episodes_providers_allowlist") or []
        if allow:
            prov = getattr(resp, "provider_used", "") or ""
            if prov not in allow:
                return False
        return True
