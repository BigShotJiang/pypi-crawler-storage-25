"""
SYNTHESIS AGENT — Razonamiento Narrativo Profundo
===================================================
El agente que faltaba en Kernell OS.

Los otros agentes reaccionan a métricas.
Synthesis *razona* sobre el sistema.

Usa DeepSeek R1 en Groq (gratis, chain-of-thought nativo).
Fallback: Gemini Pro → OpenRouter R1 → Claude Opus.

¿Qué produce?
  - Narrativa causal del estado del sistema (no solo métricas)
  - Riesgos ocultos que las métricas individuales no revelan
  - Cadenas causales detectadas
  - Detección de drift respecto al North Star
  - Hipótesis sobre anomalías no explicadas

¿Cuándo corre?
  - Cada 4 horas en modo STABLE (Chronos lo agenda)
  - Después de cada incidente CRITICAL (trigger inmediato)
  - Antes de cada PFE L1 (como input adicional al Audit Council)
  - Cuando GSHI baja más de 10 puntos en un ciclo

¿Qué NO hace?
  - No toma decisiones directas
  - No escribe en producción
  - No puede iniciar PFE
  - Solo produce análisis → humano o sistema puede actuar
"""

import json
import logging
import redis
from dataclasses import dataclass, asdict
from datetime import datetime, timezone, timedelta
from typing import Optional

from core.sea.llm_registry import LLMProviderRegistry

try:
    from core.sea.hallucination_guard import (
        run_grounding_assertions,
        check_premise_anchor,
        quarantine_write,
    )
    _HNP_AVAILABLE = True
except ImportError:
    _HNP_AVAILABLE = False

logger = logging.getLogger("kernell.synthesis")

SYNTHESIS_SYSTEM = """Eres el Agente de Síntesis de Kernell OS.
Tu función es razonar profundamente sobre el estado del sistema y producir
análisis que las métricas individuales no pueden generar.

Las métricas te dicen QUÉ está pasando.
Tu trabajo es inferir POR QUÉ, y QUÉ puede pasar después.

Debes:
1. Identificar patrones causales (no correlaciones superficiales)
2. Detectar acumulación silenciosa de riesgo no visible en métricas
3. Inferir si el sistema se aleja de su North Star
4. Proponer hipótesis sobre anomalías no explicadas
5. Evaluar si la complejidad actual es sostenible

Principio: el sistema puede verse saludable en métricas individuales
pero estar acumulando riesgo estructural invisible.

Responde SOLO con JSON válido:
{
  "health_narrative": "descripción narrativa del estado real del sistema",
  "hidden_risks": ["riesgo 1 no visible en métricas", "riesgo 2"],
  "causal_chains": ["si X sigue → Y → Z probable"],
  "anomalies": ["anomalía no explicada 1"],
  "north_star_drift": "¿el sistema se aleja de su propósito? cómo y cuánto",
  "recommended_focus": "qué merece atención inmediata y por qué",
  "complexity_assessment": "¿la complejidad actual es sostenible?",
  "confidence": 0.0-1.0,
  "urgency": "LOW"|"MEDIUM"|"HIGH"|"CRITICAL"
}"""


@dataclass
class SynthesisReport:
    health_narrative: str
    hidden_risks: list[str]
    causal_chains: list[str]
    anomalies: list[str]
    north_star_drift: str
    recommended_focus: str
    complexity_assessment: str
    confidence: float
    urgency: str
    reasoning_trace: Optional[str]   # El pensamiento completo de R1
    provider_used: str
    model_used: str
    trigger: str                      # Qué causó esta síntesis
    context_snapshot: dict            # Métricas usadas como input
    timestamp: str


class SynthesisAgent:

    def __init__(self, redis_client: redis.Redis):
        self.redis    = redis_client
        self.registry = LLMProviderRegistry(redis_client)

    # ── Entry point ───────────────────────────────────────────────────────

    def synthesize(self, trigger: str = "scheduled") -> Optional[SynthesisReport]:
        """
        Produce un análisis narrativo profundo del estado del sistema.

        Args:
            trigger: "scheduled" | "incident" | "pre_pfe" | "gshi_drop" | "manual"
        """
        logger.info(f"[SYNTHESIS] Iniciando síntesis (trigger={trigger})")

        # HNP Control 5: Grounding assertions before synthesis
        import uuid
        session_id = str(uuid.uuid4())[:8]
        grounding_ok = True
        if _HNP_AVAILABLE:
            try:
                grounding = run_grounding_assertions(session_id)
                grounding_ok = grounding.get("grounded", True)
                if not grounding_ok:
                    logger.warning(
                        f"[SYNTHESIS] HNP grounding failed — proceeding with caution. "
                        f"Output will be flagged."
                    )
            except Exception as e:
                logger.warning(f"[SYNTHESIS] HNP grounding check error: {e}")

        context = self._build_context()
        user_msg = self._format_context(context, trigger)

        resp = self.registry.complete(
            messages=[{"role": "user", "content": user_msg}],
            system_prompt=SYNTHESIS_SYSTEM,
            role="synthesis",
            max_tokens=2500,
            temperature=0.5,   # Más temperatura para razonamiento exploratorio
        )

        if not resp:
            logger.error("[SYNTHESIS] Todos los proveedores fallaron")
            return None

        import re
        try:
            text  = resp.content
            match = re.search(r"\{.*\}", text, re.DOTALL)
            data  = json.loads(match.group()) if match else {}
        except Exception:
            data = {"health_narrative": resp.content, "urgency": "MEDIUM", "confidence": 0.5}

        # HNP Control 7: Premise anchor check for CoT drift
        if _HNP_AVAILABLE:
            try:
                drift_check = check_premise_anchor(
                    original_task=user_msg[:500],
                    model_output=data,
                    model_id=resp.provider_used or "groq_r1",
                    session_id=session_id,
                )
                if drift_check.get("severity") == "HIGH":
                    logger.warning(
                        f"[SYNTHESIS] ⚠️ HNP high CoT drift detected: {drift_check['signals']}"
                    )
                    data["hnp_drift_warning"] = drift_check["signals"]
            except Exception as e:
                logger.warning(f"[SYNTHESIS] HNP drift check error: {e}")

        report = SynthesisReport(
            health_narrative   = str(data.get("health_narrative", "")),
            hidden_risks       = list(data.get("hidden_risks", [])),
            causal_chains      = list(data.get("causal_chains", [])),
            anomalies          = list(data.get("anomalies", [])),
            north_star_drift   = str(data.get("north_star_drift", "")),
            recommended_focus  = str(data.get("recommended_focus", "")),
            complexity_assessment = str(data.get("complexity_assessment", "")),
            confidence         = float(data.get("confidence", 0.5)),
            urgency            = str(data.get("urgency", "MEDIUM")),
            reasoning_trace    = resp.reasoning_trace,
            provider_used      = resp.provider_used,
            model_used         = resp.model_used,
            trigger            = trigger,
            context_snapshot   = context,
            timestamp          = datetime.now(timezone.utc).isoformat(),
        )

        self._persist(report, grounding_ok=grounding_ok)

        # Si urgency HIGH/CRITICAL → alerta inmediata
        if report.urgency in ("HIGH", "CRITICAL"):
            self._escalate(report)

        logger.info(
            f"[SYNTHESIS] Completado — urgency={report.urgency} "
            f"confidence={report.confidence:.2f} "
            f"provider={report.provider_used} "
            f"reasoning={'YES' if report.reasoning_trace else 'NO'}"
        )

        return report

    # ── Construcción del contexto ─────────────────────────────────────────

    def _build_context(self) -> dict:
        """Recopila estado completo del sistema para la síntesis."""
        ctx = {}

        # GSHI
        raw = self.redis.get("kernell:gshi:v2:current")
        if raw:
            g = json.loads(raw)
            ctx["gshi"]            = g.get("gshi_ema")
            ctx["gshi_raw"]        = g.get("gshi_raw")
            ctx["interpretation"]  = g.get("interpretation")
            ctx["sii"]             = g.get("sii")
            ctx["mean_trust"]      = g.get("mean_trust")
            ctx["sci"]             = g.get("sci")
            ctx["eco_stability"]   = g.get("economic_stability")

        # FSM
        ctx["mode"]   = self._decode(self.redis.get("kernell:drift:mode_signal"))
        ctx["drift"]  = self._decode(self.redis.get("kernell:drift:current_value"))
        ctx["conf"]   = self._decode(self.redis.get("kernell:confidence:value"))
        ctx["defcon"] = self._decode(self.redis.get("kernell:system:defcon"))

        # GSHI history — tendencia
        history_raw = self.redis.lrange("kernell:gshi:v2:history", 0, 9)
        if history_raw:
            vals = [json.loads(h).get("gshi_ema", 0) for h in history_raw]
            ctx["gshi_trend"]  = vals
            ctx["gshi_delta"]  = round(vals[0] - vals[-1], 2) if len(vals) > 1 else 0

        # Incidentes recientes (últimas 24h)
        incidents_raw = self.redis.lrange("kernell:incidents:recent", 0, 9)
        ctx["recent_incidents"] = [
            json.loads(i) for i in incidents_raw
        ] if incidents_raw else []

        # Últimas evoluciones
        promo_raw = self.redis.lrange("kernell:pfe:promotions", 0, 4)
        ctx["recent_promotions"] = [
            {k: v for k, v in json.loads(p).items() if k in ("title", "version", "promoted_at")}
            for p in promo_raw
        ] if promo_raw else []

        # Agentes en watch/quarantine
        quarantined = self.redis.smembers("kernell:immune:quarantined_agents")
        ctx["quarantined_agents"] = [
            q if isinstance(q, str) else q.decode() for q in quarantined
        ]

        # SVS último resultado
        svs_raw = self.redis.get("kernell:svs:last_sweep")
        if svs_raw:
            svs = json.loads(svs_raw)
            ctx["svs_result"]     = svs.get("overall_result")
            ctx["svs_pfe_scope"]  = svs.get("pfe_scope_allowed")
            ctx["svs_degraded"]   = svs.get("degraded_mode")

        # L0 violations recientes
        l0v_raw = self.redis.lrange("kernell:pfe:l0_violations", 0, 4)
        ctx["l0_violations_recent"] = len(l0v_raw)

        # Red Team — ataques recientes
        rt_raw = self.redis.lrange("kernell:red_team:attacks", 0, 9)
        if rt_raw:
            recent_attacks = [json.loads(a) for a in rt_raw]
            ctx["red_team_detected"]  = sum(1 for a in recent_attacks if a.get("detected"))
            ctx["red_team_total"]     = len(recent_attacks)

        # Trust profiles
        ctx["trust_profiles"] = {}
        for agent in ["kernell", "atlas", "sentinel", "sierra", "nemesis", "forge"]:
            raw = self.redis.get(f"kernell:gshi:v2:trust:{agent}")
            if raw:
                d = json.loads(raw)
                ctx["trust_profiles"][agent] = {
                    "score": d.get("trust_score"), "tier": d.get("tier")
                }

        # Últimas síntesis — para detectar patrones persistentes
        prev_raw = self.redis.lrange("kernell:synthesis:history", 0, 2)
        ctx["prev_synthesis_urgencies"] = [
            json.loads(p).get("urgency") for p in prev_raw
        ] if prev_raw else []

        return ctx

    def _format_context(self, ctx: dict, trigger: str) -> str:
        lines = [
            f"ESTADO DEL SISTEMA — Trigger: {trigger}",
            f"{'='*60}",
            "",
            f"GSHI: {ctx.get('gshi', 'N/A')} EMA ({ctx.get('interpretation', '?')})",
            f"  raw={ctx.get('gshi_raw','?')} | delta_10ciclos={ctx.get('gshi_delta','?')}",
            f"  SII={ctx.get('sii','?')} | Trust={ctx.get('mean_trust','?')} | SCI={ctx.get('sci','?')}",
            f"  EcoStab={ctx.get('eco_stability','?')}",
            "",
            f"FSM: modo={ctx.get('mode','?')} | drift={ctx.get('drift','?')} | "
            f"conf={ctx.get('conf','?')} | DEFCON={ctx.get('defcon','?')}",
            "",
        ]

        if ctx.get("gshi_trend"):
            trend_str = " → ".join(f"{v:.1f}" for v in ctx["gshi_trend"][:5])
            lines.append(f"GSHI TENDENCIA (reciente→antiguo): {trend_str}")
            lines.append("")

        if ctx.get("recent_incidents"):
            lines.append("INCIDENTES RECIENTES:")
            for inc in ctx["recent_incidents"][:5]:
                lines.append(f"  [{inc.get('type','?')}] {str(inc.get('description',''))[:80]}")
            lines.append("")

        if ctx.get("quarantined_agents"):
            lines.append(f"AGENTES EN CUARENTENA: {ctx['quarantined_agents']}")
            lines.append("")

        if ctx.get("recent_promotions"):
            lines.append("EVOLUCIONES RECIENTES:")
            for p in ctx["recent_promotions"]:
                lines.append(f"  {p.get('title','?')} → {p.get('version','?')}")
            lines.append("")

        if ctx.get("trust_profiles"):
            lines.append("TRUST SCORES:")
            for agent, info in ctx["trust_profiles"].items():
                lines.append(f"  {agent}: {info.get('score','?')}/100 [{info.get('tier','?')}]")
            lines.append("")

        lines += [
            f"SVS: {ctx.get('svs_result','?')} | PFE scope: {ctx.get('svs_pfe_scope','?')} | "
            f"degraded: {ctx.get('svs_degraded','?')}",
            f"L0 violations (recientes): {ctx.get('l0_violations_recent', 0)}",
            f"Red Team: {ctx.get('red_team_detected','?')}/{ctx.get('red_team_total','?')} detectados",
            f"Síntesis previas urgency: {ctx.get('prev_synthesis_urgencies',[])}",
            "",
            "="*60,
            "ANÁLISIS REQUERIDO:",
            "¿Qué patrones causales ves que las métricas individuales no revelan?",
            "¿Hay riesgo acumulándose silenciosamente?",
            "¿El sistema está drifteando de su North Star?",
            "¿Qué debería priorizar el equipo ahora mismo?",
        ]

        return "\n".join(lines)

    # ── Escalación ────────────────────────────────────────────────────────

    def _escalate(self, report: SynthesisReport):
        self.redis.lpush("kernell:alerts:system", json.dumps({
            "source":    "synthesis_agent",
            "urgency":   report.urgency,
            "narrative": report.health_narrative[:300],
            "focus":     report.recommended_focus[:200],
            "timestamp": report.timestamp,
        }))
        logger.warning(
            f"[SYNTHESIS] ⚠️ Escalando urgency={report.urgency}: "
            f"{report.recommended_focus[:100]}"
        )

    # ── Persistencia ──────────────────────────────────────────────────────

    def _persist(self, report: SynthesisReport, grounding_ok: bool = True):
        report_json = json.dumps(asdict(report))

        # HNP Control 1: Quarantine write for critical keys
        if _HNP_AVAILABLE:
            qr = quarantine_write(
                key="kernell:synthesis:latest",
                value=report_json,
                source_model=report.provider_used or "unknown",
            )
            if qr["status"] == "QUARANTINED":
                logger.error(
                    f"[SYNTHESIS] HNP quarantined output: {qr['violations']}"
                )
                return  # Do not persist quarantined data

        self.redis.set("kernell:synthesis:latest", report_json)
        self.redis.lpush("kernell:synthesis:history", json.dumps({
            "urgency":   report.urgency,
            "confidence": report.confidence,
            "trigger":   report.trigger,
            "narrative": report.health_narrative[:200],
            "provider":  report.provider_used,
            "has_trace": bool(report.reasoning_trace),
            "grounding_ok": grounding_ok,
            "timestamp": report.timestamp,
        }))
        self.redis.ltrim("kernell:synthesis:history", 0, 99)

    def _decode(self, raw) -> Optional[str]:
        if raw is None:
            return None
        return raw if isinstance(raw, str) else raw.decode()
