"""
Refactor Council v1 — Comité LLM para auditoría de código estable.
===================================================================
Arquitectura: 4 roles en paralelo, consenso ≥ 3/4 para PROPOSE.
Separado de forge_council_v3.py — flujo opuesto (analiza, no genera).

Roles:
  ANALYZER      (groq_r1 / DeepSeek R1)  — detecta redundancias y complejidad
  MINIMALIST    (gemini_flash)            — propone versión más simple posible
  CONSERVATIVE  (claude_sonnet)           — evalúa riesgo del cambio
  DEP_VERIFIER  (gemini_pro)              — verifica que simplificar no rompe deps

Veredicto final:
  PROPOSE   → ≥3/4 votan REFACTOR (enviar al Arquitecto)
  SKIP      → <3/4 votan REFACTOR (no vale el riesgo)
  PROTECTED → El archivo toca leyes de core/ (no tocar sin MFA)
"""

import os
import json
import asyncio
import logging
from typing import Any

logger = logging.getLogger("refactor.council")

# Importar el registry de LLMs de Kernell OS
# NOTE: Registry requires redis_client — defer init to avoid crash at import time.
# _call_model already handles _llm_registry=None gracefully (returns mock).
try:
    from core.sea.llm_registry import LLMProviderRegistry
    _llm_registry_class = LLMProviderRegistry
except ImportError:
    _llm_registry_class = None
    logger.warning("LLMProviderRegistry not available — council will use mock responses")

_llm_registry = None  # Lazily initialized on first call

# Importar HNP para role anchor y adversarial framing
try:
    from core.sea.hallucination_guard import (
        inject_role_anchor,
        apply_adversarial_framing,
        get_committee_vote_weight,
        record_semantic_failure,
        record_semantic_success,
        update_confidence_calibration
    )
    _hnp_available = True
except ImportError:
    _hnp_available = False
    logger.warning("HNP not available — running without hallucination protection")

# Temperaturas por rol
ROLE_TEMPERATURES = {
    "ANALYZER": 0.3,      # Análisis determinístico
    "MINIMALIST": 0.4,    # Algo de creatividad para simplificación
    "CONSERVATIVE": 0.2,  # Muy determinístico para evaluación de riesgo
    "DEP_VERIFIER": 0.1   # Máximamente determinístico para verificación
}

# Modelos por rol
ROLE_MODELS = {
    "ANALYZER": "groq_r1",
    "MINIMALIST": "gemini_flash",
    "CONSERVATIVE": "claude_sonnet",
    "DEP_VERIFIER": "gemini_pro"
}

# Prompts de sistema por rol
SYSTEM_PROMPTS = {
    "ANALYZER": """Eres un analizador de código experto con obsesión por la simplicidad.
Tu rol: identificar redundancias, complejidad innecesaria, y código que hace más de lo que debería.
Debes analizar el código presentado y determinar si requiere refactoring.
Responde SOLO en JSON con estructura exacta: {"vote": "REFACTOR"|"SKIP", "confidence": 0.0-1.0, 
"reason": "explicación concisa", "specific_issues": ["issue1", "issue2"], 
"estimated_reduction": "porcentaje estimado de reducción de líneas"}""",

    "MINIMALIST": """Eres un ingeniero minimalista. Tu principio: el mejor código es el que no existe.
Tu rol: proponer la versión más simple posible del código presentado, 
respetando las leyes del sistema en core/.
Responde SOLO en JSON: {"vote": "REFACTOR"|"SKIP", "confidence": 0.0-1.0,
"reason": "explicación concisa", "proposal_summary": "descripción de la versión simplificada",
"lines_before": N, "lines_estimated_after": N}""",

    "CONSERVATIVE": """Eres un ingeniero senior conservador. Tu rol: cuestionar si el refactor vale el riesgo.
Asume que el código funciona. Busca razones por las que NO refactorizar podría ser la decisión correcta.
Considera: riesgo de regresión, dependencias ocultas, complejidad real vs accidental.
Responde SOLO en JSON: {"vote": "REFACTOR"|"SKIP", "confidence": 0.0-1.0,
"reason": "explicación concisa", "risks": ["riesgo1", "riesgo2"],
"prerequisites": ["qué debe verificarse antes de refactorizar"]}""",

    "DEP_VERIFIER": """Eres un especialista en análisis de dependencias.
Tu rol: verificar que simplificar este código no rompe nada que depende de él.
Analiza los imports, las interfaces públicas, y las referencias externas.
Responde SOLO en JSON: {"vote": "REFACTOR"|"SKIP", "confidence": 0.0-1.0,
"reason": "explicación concisa", "dependent_modules": ["módulo1", "módulo2"],
"breaking_changes": ["cambio que rompería dependencias"],
"safe_to_refactor": true|false}"""
}


def _build_user_prompt(context_package: dict) -> str:
    """Construye el prompt de usuario con el contexto del hallazgo."""
    finding = context_package["finding"]
    code = context_package["code_snippet"]
    imports = context_package["direct_imports"]
    rules_summary = context_package.get("core_rules_summary", "")
    duplicates = context_package.get("duplicate_snippets", {})

    prompt_parts = [
        f"## HALLAZGO DETECTADO\n"
        f"Tipo: {finding['type']}\n"
        f"Severidad: {finding['severity']}\n"
        f"Archivo: {finding['file']}\n"
        f"Descripción: {finding['description']}\n"
        f"Métrica: {finding.get('metric', 'N/A')}\n"
    ]

    if finding.get("function"):
        prompt_parts.append(f"Función afectada: {finding['function']} (línea {finding.get('line', '?')})\n")

    if finding.get("complexity"):
        prompt_parts.append(f"Complejidad ciclomática: {finding['complexity']}\n")

    if finding.get("lines"):
        prompt_parts.append(f"Líneas: {finding['lines']}\n")

    prompt_parts.append(f"\n## CÓDIGO DEL ARCHIVO\n```python\n{code}\n```\n")

    if imports:
        prompt_parts.append(f"\n## DEPENDENCIAS DIRECTAS\n{chr(10).join(imports)}\n")

    if duplicates:
        prompt_parts.append("\n## ARCHIVOS DUPLICADOS\n")
        for dup_rel, dup_code in duplicates.items():
            prompt_parts.append(f"### {dup_rel}\n```python\n{dup_code}\n```\n")

    if rules_summary:
        prompt_parts.append(
            f"\n## LEYES DEL SISTEMA (resumen — respétalas en tu análisis)\n"
            f"{rules_summary[:1000]}\n"
        )

    prompt_parts.append(
        "\n## INSTRUCCIÓN FINAL\n"
        "Analiza el código según tu rol y responde SOLO con el JSON especificado. "
        "Sin texto adicional, sin markdown, sin explicaciones fuera del JSON."
    )

    return "".join(prompt_parts)


async def _call_model(
    model_id: str,
    role: str,
    system_prompt: str,
    user_prompt: str,
    temperature: float
) -> dict:
    """Llama al modelo LLM y retorna el JSON parseado."""
    if _llm_registry is None:
        # Mock para testing sin registry
        logger.warning(f"Mock response for {model_id} ({role})")
        return {
            "vote": "SKIP",
            "confidence": 0.5,
            "reason": "Mock response — LLMProviderRegistry not available",
            "mock": True
        }

    # Aplicar role anchor para DeepSeek R1 (r1_quirk)
    final_user_prompt = user_prompt
    if model_id in ("groq_r1", "openrouter_r1") and _hnp_available:
        role_functions = {
            "ANALYZER": "detectar redundancias y complejidad innecesaria en código estable",
            "MINIMALIST": "proponer la versión más simple posible del código",
            "CONSERVATIVE": "evaluar riesgos y razones para NO refactorizar",
            "DEP_VERIFIER": "verificar que los cambios no rompen dependencias"
        }
        fused = f"[System Instructions]\n{system_prompt}\n\n[Task]\n{user_prompt}"
        final_user_prompt = inject_role_anchor(
            fused,
            role=role,
            function=role_functions.get(role, "analizar según tu rol")
        )
        system_prompt = ""  # Ya fusionado

    # Aplicar adversarial framing para roles analíticos
    if role in ("ANALYZER", "CONSERVATIVE") and _hnp_available:
        final_user_prompt = apply_adversarial_framing(final_user_prompt, role.lower())

    try:
        response = await asyncio.get_event_loop().run_in_executor(
            None,
            lambda: _llm_registry.complete(
                model_id=model_id,
                messages=[{"role": "user", "content": final_user_prompt}],
                system=system_prompt if system_prompt else None,
                temperature=temperature,
                max_tokens=800,
                response_format={"type": "json_object"}
            )
        )

        # Parsear respuesta JSON
        content = response.get("content", response) if isinstance(response, dict) else str(response)
        if isinstance(content, list):
            content = content[0].get("text", "") if content else ""

        # Limpiar posibles backticks
        clean = content.strip().strip("```json").strip("```").strip()
        result = json.loads(clean)
        return result

    except json.JSONDecodeError as e:
        logger.warning(f"JSON parse error from {model_id}: {e}")
        if _hnp_available:
            record_semantic_failure(model_id, reason="json_parse_error")
        return {
            "vote": "SKIP",
            "confidence": 0.0,
            "reason": f"JSON parse error: {e}",
            "parse_error": True
        }
    except Exception as e:
        logger.error(f"LLM call failed for {model_id} ({role}): {e}")
        if _hnp_available:
            record_semantic_failure(model_id, reason="api_error")
        return {
            "vote": "SKIP",
            "confidence": 0.0,
            "reason": f"API error: {str(e)[:100]}",
            "api_error": True
        }


class RefactorCouncil:
    """Comité de 4 LLMs para deliberar sobre propuestas de refactoring."""

    async def deliberate(self, context_package: dict) -> dict:
        """
        Ejecuta una ronda de deliberación paralela.
        Requiere ≥3/4 votos REFACTOR para recomendar PROPOSE.

        Returns:
            dict con verdict, votes, consensus_ratio, proposal
        """
        finding = context_package["finding"]
        user_prompt = _build_user_prompt(context_package)

        # ── Ronda paralela ────────────────────────────────────────────────
        tasks = {
            role: _call_model(
                model_id=ROLE_MODELS[role],
                role=role,
                system_prompt=SYSTEM_PROMPTS[role],
                user_prompt=user_prompt,
                temperature=ROLE_TEMPERATURES[role]
            )
            for role in ROLE_MODELS
        }

        results = {}
        for role, coro in tasks.items():
            try:
                results[role] = await coro
            except Exception as e:
                logger.error(f"Role {role} failed: {e}")
                results[role] = {
                    "vote": "SKIP",
                    "confidence": 0.0,
                    "reason": f"Role execution failed: {e}"
                }

        # ── Agregar votos con pesos HNP ───────────────────────────────────
        weighted_votes = 0.0
        total_weight = 0.0
        vote_details = {}

        for role, result in results.items():
            model_id = ROLE_MODELS[role]
            vote = result.get("vote", "SKIP").upper()
            confidence = float(result.get("confidence", 0.5))

            weight = get_committee_vote_weight(model_id) if _hnp_available else 1.0
            vote_value = 1.0 if vote == "REFACTOR" else 0.0

            weighted_votes += vote_value * weight
            total_weight += weight

            vote_details[role] = {
                "model": model_id,
                "vote": vote,
                "confidence": confidence,
                "weight": weight,
                "reason": result.get("reason", ""),
                "details": {k: v for k, v in result.items()
                           if k not in ("vote", "confidence", "reason")}
            }

            logger.debug(f"  {role} ({model_id}): {vote} | conf={confidence:.2f} | w={weight:.2f}")

        # ── Calcular consenso ─────────────────────────────────────────────
        consensus_ratio = weighted_votes / total_weight if total_weight > 0 else 0.0
        # Umbral: ≥3/4 = 0.75 (más conservador que forge_council's 2/3)
        verdict = "PROPOSE" if consensus_ratio >= 0.75 else "SKIP"

        # ── Construir propuesta consolidada ──────────────────────────────
        proposal_summary = self._synthesize_proposal(results, finding)

        council_result = {
            "verdict": verdict,
            "consensus_ratio": round(consensus_ratio, 3),
            "votes": vote_details,
            "finding_type": finding["type"],
            "finding_severity": finding["severity"],
            "proposal_summary": proposal_summary,
            "requires_mfa": self._requires_mfa(finding),
            "estimated_risk": self._estimate_risk(results)
        }

        logger.info(
            f"Council deliberation complete: {verdict} "
            f"(consensus: {consensus_ratio:.2f}) "
            f"for {finding['file']}"
        )

        return council_result

    def _synthesize_proposal(self, results: dict, finding: dict) -> str:
        """Genera un resumen legible de la propuesta para el Arquitecto."""
        parts = []
        parts.append(f"**Tipo:** {finding['type']} en `{finding['file']}`")
        parts.append(f"**Hallazgo:** {finding['description']}")

        if "MINIMALIST" in results and results["MINIMALIST"].get("proposal_summary"):
            parts.append(f"**Propuesta:** {results['MINIMALIST']['proposal_summary']}")

        if "ANALYZER" in results and results["ANALYZER"].get("specific_issues"):
            issues = results["ANALYZER"]["specific_issues"][:3]
            parts.append(f"**Issues:** {', '.join(str(i) for i in issues)}")

        if "CONSERVATIVE" in results and results["CONSERVATIVE"].get("risks"):
            risks = results["CONSERVATIVE"]["risks"][:2]
            parts.append(f"**Riesgos:** {', '.join(str(r) for r in risks)}")

        if "ANALYZER" in results and results["ANALYZER"].get("estimated_reduction"):
            parts.append(f"**Reducción estimada:** {results['ANALYZER']['estimated_reduction']}")

        return "\n".join(parts)

    def _requires_mfa(self, finding: dict) -> bool:
        """Determina si el refactor requiere MFA (toca rutas protegidas)."""
        protected = {"core/", "scripts/boot_sequence.py", "agents/sierra/salus/"}
        file_path = finding.get("file", "")
        return any(file_path.startswith(p) for p in protected)

    def _estimate_risk(self, results: dict) -> str:
        """Estima el nivel de riesgo del refactor basado en el rol conservador."""
        conservative = results.get("CONSERVATIVE", {})
        risks = conservative.get("risks", [])
        breaking = results.get("DEP_VERIFIER", {}).get("breaking_changes", [])

        if breaking:
            return "HIGH"
        if len(risks) >= 2:
            return "MEDIUM"
        return "LOW"
