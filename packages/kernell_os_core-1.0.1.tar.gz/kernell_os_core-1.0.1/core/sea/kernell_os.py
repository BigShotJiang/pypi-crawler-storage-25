"""
KERNELL OS — Fachada de Integración Completa
=============================================
Punto de entrada único para todo el sistema.

Versión: v15.0 — SEA (Self-Evolution Architecture) completo

Integra:
  v14.x  Hardening matemático + Immune Layer + Atlas + Nemesis
  SEA    SVS v2, PFE v2, GSHI v2, Tricapa, Red Team
  LLM    Multi-proveedor: Claude + Groq R1 + Gemini + OpenRouter
  v15    Forge v3, Audit v2, Synthesis Agent, Chronos, Policy Engine

Arquitectura tricapa:
  CORE        → evolución autónoma completa, Red Team activo
  ENTERPRISE  → PFE L2 supervisado, sin Red Team agresivo
  PLATFORM    → sin PFE autónomo, API pública

Inicio rápido:
  from kernell.integration import KernellOS
  kernell = KernellOS(redis_url="redis://localhost:6379", layer="core")
  kernell.setup_keys(groq="gsk_...", gemini="AIza...", openrouter="sk-or-...")
  kernell.bootstrap()
  kernell.start()           # Arranca Chronos (bloqueante)

Control:
  kernell.status()          # Estado completo
  kernell.propose(patch)    # Proponer evolución
  kernell.synthesize()      # Síntesis manual
  kernell.trigger_svs()     # SVS inmediato
"""

import json
import logging
import redis
from datetime import datetime, timezone
from typing import Optional
from dataclasses import dataclass

logger = logging.getLogger("kernell.os")

KERNELL_VERSION = "v15.0-SEA"


@dataclass
class SystemStatus:
    version: str
    layer: str
    gshi: Optional[float]
    gshi_interpretation: Optional[str]
    svs_result: Optional[str]
    pfe_scope: Optional[str]
    mode: Optional[str]
    drift: Optional[float]
    confidence: Optional[float]
    defcon: Optional[int]
    active_agents: int
    quarantined_agents: list
    chronos_alive: bool
    free_reasoning_providers: list
    timestamp: str


class KernellOS:
    """
    Fachada principal de Kernell OS.
    Oculta la complejidad interna y expone una API limpia.
    """

    def __init__(
        self,
        redis_url: str = "redis://localhost:6379",
        layer: str = "core",
        log_level: str = "INFO",
    ):
        logging.basicConfig(
            level=getattr(logging, log_level),
            format="%(asctime)s %(name)-30s %(levelname)s %(message)s",
        )

        self.layer  = layer
        self.redis  = redis.from_url(redis_url, decode_responses=False)
        self._ready = False

        # Inicializar subsistemas (lazy — no importan hasta bootstrap())
        self._chronos    = None
        self._registry   = None
        self._policy     = None
        self._fv         = None

        logger.info(f"[KERNELL] v{KERNELL_VERSION} inicializando — layer={layer}")

    # ── Setup ─────────────────────────────────────────────────────────────

    def setup_keys(
        self,
        anthropic:  Optional[str] = None,
        groq:       Optional[str] = None,
        gemini:     Optional[str] = None,
        openrouter: Optional[str] = None,
    ):
        """
        Registra API keys en Redis.
        Solo llamar una vez en el setup inicial.
        Groq, Gemini y OpenRouter son gratuitos.
        """
        from core.sea.llm_registry import LLMProviderRegistry
        registry = LLMProviderRegistry(self.redis)

        if anthropic:
            registry.register_key("anthropic", anthropic)
        if groq:
            registry.register_key("groq", groq)
            logger.info("[KERNELL] Groq key registrada — DeepSeek R1 disponible (gratis)")
        if gemini:
            registry.register_key("gemini", gemini)
            logger.info("[KERNELL] Gemini key registrada — Flash/Pro disponibles (gratis)")
        if openrouter:
            registry.register_key("openrouter", openrouter)
            logger.info("[KERNELL] OpenRouter key registrada — fallback universal (gratis)")

    def bootstrap(self, north_star_path: str = "/home/anny/kernell-os/docs/NORTH_STAR_SPEC.md"):
        """
        Inicializa el sistema completo:
          1. Carga el Policy Engine
          2. Registra hash del North Star Spec
          3. Registra hash del FormalVerifier (auto-verificación L0)
          4. Inicializa Chronos con todos los subsistemas
          5. Verifica que al menos un proveedor LLM está disponible
        """
        logger.info("[KERNELL] Bootstrap iniciando...")

        # Policy Engine
        from core.sea.policy_engine import PolicyEngine
        self._policy = PolicyEngine(self.redis, self.layer)
        logger.info("[KERNELL] Policy Engine cargado")

        # Formal Verifier + hashes L0
        from core.sea.formal_verifier import FormalVerifier
        self._fv = FormalVerifier(self.redis, north_star_path)
        try:
            ns_hash = self._fv.bootstrap_north_star_hash()
            fv_hash = self._fv.bootstrap_verifier_hash()
            logger.info(f"[KERNELL] L0 hashes registrados — NS={ns_hash[:8]}... FV={fv_hash[:8]}...")
        except FileNotFoundError as e:
            logger.warning(f"[KERNELL] North Star no encontrado: {e} — continuando sin hash")

        # LLM Registry
        from core.sea.llm_registry import LLMProviderRegistry
        self._registry = LLMProviderRegistry(self.redis)
        free = self._registry.free_reasoning_available()
        if free:
            logger.info(f"[KERNELL] Proveedores gratuitos disponibles: {free}")
        else:
            logger.warning("[KERNELL] Sin proveedores gratuitos — verificar keys de Groq/Gemini/OpenRouter")

        # Chronos
        from core.sea.chronos import Chronos
        self._chronos = Chronos(self.redis, layer=self.layer)

        self._ready = True
        logger.info(f"[KERNELL] ✅ Bootstrap completo — {KERNELL_VERSION} listo")

    def start(self):
        """
        Arranca Chronos. Bloqueante — usar en proceso principal.
        Para uso no-bloqueante, iniciar Chronos en thread separado.
        """
        if not self._ready:
            raise RuntimeError("Llamar bootstrap() antes de start()")
        logger.info("[KERNELL] ═══ Arrancando Kernell OS ═══")
        self._chronos.start()

    def start_async(self):
        """Arranca Chronos en background thread (no bloqueante)."""
        import threading
        if not self._ready:
            raise RuntimeError("Llamar bootstrap() antes de start_async()")
        t = threading.Thread(target=self._chronos.start, daemon=True, name="chronos-main")
        t.start()
        logger.info("[KERNELL] Chronos iniciado en background")
        return t

    # ── Control ───────────────────────────────────────────────────────────

    def propose(self, proposal_data: dict) -> str:
        """
        Encola una propuesta de evolución para el PFE.
        Returns: proposal_id
        """
        import uuid
        if "proposal_id" not in proposal_data:
            proposal_data["proposal_id"] = str(uuid.uuid4())[:8]
        proposal_data["enqueued_at"] = datetime.now(timezone.utc).isoformat()

        self.redis.rpush("kernell:pfe:pending_proposals", json.dumps(proposal_data))
        pid = proposal_data["proposal_id"]
        logger.info(f"[KERNELL] Propuesta encolada: {pid}")
        return pid

    def synthesize(self, reason: str = "manual") -> Optional[dict]:
        """Dispara síntesis narrativa inmediata. Returns el reporte."""
        if not self._ready:
            raise RuntimeError("Bootstrap requerido")
        from core.sea.synthesis_agent import SynthesisAgent
        agent  = SynthesisAgent(self.redis)
        report = agent.synthesize(trigger=reason)
        if report:
            import dataclasses
            return dataclasses.asdict(report)
        return None

    def trigger_svs(self):
        """SVS inmediato."""
        if self._chronos:
            self._chronos.trigger_svs()

    def trigger_gshi(self):
        """GSHI inmediato."""
        if self._chronos:
            self._chronos.trigger_gshi()

    def pause(self):
        """Pausa todas las tareas de Chronos."""
        if self._chronos:
            self._chronos.pause_all()

    def resume(self):
        """Reanuda Chronos."""
        if self._chronos:
            self._chronos.resume_all()

    def evaluate_policy(self, action: str, target: str, agent: str, **kwargs) -> dict:
        """Consulta el Policy Engine para cualquier acción."""
        if not self._policy:
            raise RuntimeError("Bootstrap requerido")
        decision = self._policy.evaluate({
            "action": action, "target": target, "agent": agent, **kwargs
        })
        import dataclasses
        return dataclasses.asdict(decision)

    # ── Status ────────────────────────────────────────────────────────────

    def status(self) -> SystemStatus:
        """Estado completo del sistema."""
        gshi_raw = self.redis.get("kernell:gshi:v2:current")
        gshi_data = json.loads(gshi_raw) if gshi_raw else {}

        svs_raw = self.redis.get("kernell:svs:last_sweep")
        svs_data = json.loads(svs_raw) if svs_raw else {}

        hb_raw = self.redis.get("kernell:chronos:heartbeat")
        chronos_alive = False
        if hb_raw:
            try:
                hb = json.loads(hb_raw)
                ts = datetime.fromisoformat(hb.get("timestamp", "2000-01-01"))
                chronos_alive = (datetime.now(timezone.utc) - ts).total_seconds() < 120
            except Exception:
                pass

        quarantined_raw = self.redis.smembers("kernell:immune:quarantined_agents")
        quarantined = [q if isinstance(q, str) else q.decode() for q in quarantined_raw]

        active = sum(
            1 for _ in self.redis.scan_iter("kernell:agents:heartbeats:*")
        )

        free_llm = []
        if self._registry:
            free_llm = self._registry.free_reasoning_available()

        mode = self.redis.get("kernell:drift:mode_signal")
        if mode:
            mode = mode if isinstance(mode, str) else mode.decode()

        drift_raw = self.redis.get("kernell:drift:current_value")
        drift = float(drift_raw) if drift_raw else None

        conf_raw = self.redis.get("kernell:confidence:value")
        conf = float(conf_raw) if conf_raw else None

        defcon_raw = self.redis.get("kernell:system:defcon")
        defcon = int(defcon_raw) if defcon_raw else None

        return SystemStatus(
            version=KERNELL_VERSION,
            layer=self.layer,
            gshi=gshi_data.get("gshi_ema"),
            gshi_interpretation=gshi_data.get("interpretation"),
            svs_result=svs_data.get("overall_result"),
            pfe_scope=svs_data.get("pfe_scope_allowed"),
            mode=mode,
            drift=drift,
            confidence=conf,
            defcon=defcon,
            active_agents=active,
            quarantined_agents=quarantined,
            chronos_alive=chronos_alive,
            free_reasoning_providers=free_llm,
            timestamp=datetime.now(timezone.utc).isoformat(),
        )

    def print_status(self):
        """Imprime estado en consola de forma legible."""
        s = self.status()
        print(f"""
╔══════════════════════════════════════════════════════╗
║  KERNELL OS {s.version:<40}║
╠══════════════════════════════════════════════════════╣
║  Layer:    {s.layer:<43}║
║  GSHI:     {str(s.gshi) + ' (' + (s.gshi_interpretation or '?') + ')':<43}║
║  SVS:      {str(s.svs_result) + ' | PFE scope: ' + str(s.pfe_scope):<43}║
║  Modo:     {str(s.mode):<43}║
║  Drift:    {str(s.drift):<43}║
║  Confidence: {str(s.confidence):<41}║
║  DEFCON:   {str(s.defcon):<43}║
║  Agentes:  {str(s.active_agents) + ' activos | quarantine: ' + str(s.quarantined_agents):<43}║
║  Chronos:  {'✅ ALIVE' if s.chronos_alive else '❌ DEAD':<43}║
║  LLM Free: {str(s.free_reasoning_providers):<43}║
╚══════════════════════════════════════════════════════╝
""")
