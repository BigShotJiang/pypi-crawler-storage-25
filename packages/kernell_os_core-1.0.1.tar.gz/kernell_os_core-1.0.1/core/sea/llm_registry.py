"""
LLM PROVIDER REGISTRY — Kernell OS
=====================================
Punto de entrada único para todas las llamadas a LLM.

Proveedores:
  claude_sonnet    Anthropic     pagado     sin reasoning nativo
  claude_opus      Anthropic     pagado     extended thinking
  groq_r1          Groq          gratis     DeepSeek R1 70B, chain-of-thought
  groq_qwen3       Groq          gratis     Qwen3 32B, reasoning
  groq_kimi        Groq          gratis     Kimi K2
  gemini_flash     Google        gratis     Gemini 2.5 Flash, reasoning
  gemini_pro       Google        gratis     Gemini 2.5 Pro, reasoning
  openrouter_r1    OpenRouter    gratis     DeepSeek R1, fallback universal
  openrouter_r1_0528 OpenRouter  gratis     R1-0528 más reciente
  hf_conrrad       Colab tunnel  n/a        Conrrad (sovereign) — Harlemm primario; URL desde Redis
  local_derek      Ollama/localhost  opcional  Derek — Harlemm solo si HARLEMM_DEREK_MODE / Redis (ver complete())
  (post-cadena)    —               —         Si falla todo el rol, reintento Conrrad→Derek con overlay Harlemm
                                             (HARLEMM_LAST_RESORT_LLM, ver _harlemm_last_resort_enabled)

Características:
  - Circuit breaker por proveedor (3 fallos → bypass 10min)
  - Retry con backoff exponencial (2 reintentos)
  - Captura de reasoning_trace (R1 <think>, Opus thinking blocks)
  - R1 quirk handler: fusiona system prompt en user message
  - Gemini: API key en URL (no en Authorization header)
  - OpenRouter: headers HTTP-Referer + X-Title requeridos
  - API keys en Redis, env vars como fallback
  - Métricas de latencia y tokens por proveedor
"""

import json
import time
import logging
import re
import os
import urllib.request
import urllib.error
from dataclasses import dataclass
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Optional
from enum import Enum

import redis

logger = logging.getLogger("kernell.llm.registry")

CIRCUIT_BREAKER_THRESHOLD = 3
CIRCUIT_BREAKER_RESET_S   = 600
MAX_RETRIES               = 2
DEFAULT_TIMEOUT_S         = 60


class ProviderFormat(Enum):
    ANTHROPIC     = "anthropic"
    OPENAI_COMPAT = "openai_compat"


PROVIDER_CATALOG: dict[str, dict] = {
    "claude_sonnet": {
        "url":       "https://api.anthropic.com/v1/messages",
        "model":     "claude-sonnet-4-20250514",
        "format":    ProviderFormat.ANTHROPIC,
        "redis_key": "kernell:llm:keys:anthropic",
        "env_key":   "ANTHROPIC_API_KEY",
        "cost_tier": "paid",
        "reasoning": False,
    },
    "claude_opus": {
        "url":       "https://api.anthropic.com/v1/messages",
        "model":     "claude-opus-4-20250514",
        "format":    ProviderFormat.ANTHROPIC,
        "redis_key": "kernell:llm:keys:anthropic",
        "env_key":   "ANTHROPIC_API_KEY",
        "cost_tier": "paid_premium",
        "reasoning": True,
    },
    "groq_r1": {
        "url":       "https://api.groq.com/openai/v1/chat/completions",
        "model":     "qwen/qwen3-32b",
        "format":    ProviderFormat.OPENAI_COMPAT,
        "redis_key": "kernell:llm:keys:groq",
        "env_key":   "GROQ_API_KEY",
        "cost_tier": "free",
        "reasoning": True,
        "r1_quirk":  False,
    },
    "groq_qwen3": {
        "url":       "https://api.groq.com/openai/v1/chat/completions",
        "model":     "qwen/qwen3-32b",
        "format":    ProviderFormat.OPENAI_COMPAT,
        "redis_key": "kernell:llm:keys:groq",
        "env_key":   "GROQ_API_KEY",
        "cost_tier": "free",
        "reasoning": True,
    },
    "groq_kimi": {
        "url":       "https://api.groq.com/openai/v1/chat/completions",
        "model":     "moonshotai/kimi-k2-instruct",
        "format":    ProviderFormat.OPENAI_COMPAT,
        "redis_key": "kernell:llm:keys:groq",
        "env_key":   "GROQ_API_KEY",
        "cost_tier": "free",
        "reasoning": False,
    },
    "gemini_flash": {
        "url":       "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions",
        "model":     "gemini-2.5-flash",
        "format":    ProviderFormat.OPENAI_COMPAT,
        "redis_key": "kernell:llm:keys:gemini",
        "env_key":   "GEMINI_API_KEY",
        "cost_tier": "free",
        "reasoning": True,
        "gemini":    True,
    },
    "gemini_pro": {
        "url":       "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions",
        "model":     "gemini-2.5-pro",
        "format":    ProviderFormat.OPENAI_COMPAT,
        "redis_key": "kernell:llm:keys:gemini",
        "env_key":   "GEMINI_API_KEY",
        "cost_tier": "free",
        "reasoning": True,
        "gemini":    True,
    },
    "openrouter_r1": {
        "url":        "https://openrouter.ai/api/v1/chat/completions",
        "model":      "deepseek/deepseek-r1",
        "format":     ProviderFormat.OPENAI_COMPAT,
        "redis_key":  "kernell:llm:keys:openrouter",
        "env_key":    "OPENROUTER_API_KEY",
        "cost_tier":  "free",
        "reasoning":  True,
        "r1_quirk":   True,
        "openrouter": True,
    },
    "openrouter_r1_0528": {
        "url":        "https://openrouter.ai/api/v1/chat/completions",
        "model":      "deepseek/deepseek-r1-0528",
        "format":     ProviderFormat.OPENAI_COMPAT,
        "redis_key":  "kernell:llm:keys:openrouter",
        "env_key":    "OPENROUTER_API_KEY",
        "cost_tier":  "free",
        "reasoning":  True,
        "r1_quirk":   True,
        "openrouter": True,
    },
    "hf_conrrad": {
        # Inferencia solo vía túnel Colab (OpenAI-compatible). URL efectiva = SRANDMEMBER kernell:conrrad:endpoints.
        "url":       "",
        "model":     os.getenv("CONRRAD_COLAB_MODEL", os.getenv("CONRRAD_HF_MODEL", "conrrad-8b-q4:latest")),
        "format":    ProviderFormat.OPENAI_COMPAT,
        "redis_key": "kernell:llm:keys:huggingface",
        "env_key":   "HF_API_KEY",
        "cost_tier": "local",
        "reasoning": False,
    },
    # Derek: Qwen2.5-0.5B instrucción local (Ollama OpenAI API o llama.cpp /v1). Sin API key por defecto.
    "local_derek": {
        "url":       os.getenv("DEREK_BASE_URL", "http://127.0.0.1:11434/v1/chat/completions"),
        "model":     os.getenv("DEREK_MODEL", "derek"),
        "format":    ProviderFormat.OPENAI_COMPAT,
        "redis_key": "",
        "env_key":   "DEREK_API_KEY",
        "cost_tier": "local",
        "reasoning": False,
    },
}

# Chains por rol: preferred + fallback en orden

MODIFICATION_GUIDE = {
    "file":    "core/sea/llm_registry.py",
    "version": "1.1",
    "purpose": (
        "Punto de entrada único para TODAS las llamadas a LLM. "
        "v1.1: añade HNP role anchor injection para roles R1. "
        "Gestiona circuit breakers, retry, fallback chains y métricas."
    ),
    "extension_points": [
        "PROVIDER_CATALOG: añadir nuevos providers con su formato y redis_key.",
        "  Copiar un entry existente y ajustar url, model, env_key.",
        "ROLE_CHAINS: añadir nuevos roles cuando se creen nuevos agentes o councils.",
        "  Formato: 'nuevo_rol': {'preferred': 'provider', 'fallback': [...]}",
        "_HNP_R1_ROLES: añadir el nuevo rol si su preferred provider es R1/DeepSeek.",
        "_HNP_ROLE_FUNCTIONS: añadir descripción del rol para el role anchor.",
        "DEFAULT_TIMEOUT_S: ajustar si los providers cambian su latencia.",
        "MAX_RETRIES: actualmente 2. Subir a 3 si hay más fallos transitorios.",
    ],
    "invariants": [
        "NUNCA quitar el bloque HNP (_HNP_LLM_AVAILABLE, effective_system).",
        "  El role anchor es el principal control anti-deriva de DeepSeek R1.",
        "NUNCA cambiar complete() para saltarse effective_system.",
        "  Todos los roles R1 DEBEN recibir el [ROLE LOCK] antes de su tarea.",
        "NUNCA hardcodear API keys — siempre via redis_key o env_key.",
        "NUNCA quitar el circuit breaker — es la protección contra cascadas de fallos.",
        "El fallback chain DEBE incluir al menos un provider no-R1 como último recurso.",
    ],
    "verify_after": [
        "grep -n 'inject_role_anchor\\|effective_system' core/sea/llm_registry.py",
        "  # Debe mostrar las líneas del HNP block",
        ".venv/bin/python3 -c \"from core.sea.llm_registry import LLMProviderRegistry; print('OK')\"",
        "redis-cli -p 6380 -a $REDIS_PASSWORD KEYS 'kernell:llm:cb:*'",
        "  # Circuit breakers — ninguno debe estar OPEN en sistema saludable",
    ],
    "owner_agent": "forge, sentinel, atlas, synthesis (todos los que usan LLM)",
    "ontology_refs": {
        "redis_keys": [
            "kernell:llm:cb:{provider}:failures",
            "kernell:llm:metrics:{provider}",
            "kernell:llm:ccs:{model}",
        ],
        "related_modules": [
            "core/sea/hallucination_guard.py",
            "core/sea/forge_council_v3.py",
            "agents/nexus/ (key rotation)",
        ],
    },
}

ROLE_CHAINS: dict[str, dict] = {
    "forge_proponent":   {"preferred": "claude_sonnet",    "fallback": ["groq_r1", "gemini_flash", "openrouter_r1"]},
    "forge_proponent_opus": {"preferred": "claude_opus",   "fallback": ["claude_sonnet", "groq_r1", "gemini_flash"]},
    "forge_opposition":  {"preferred": "groq_r1",          "fallback": ["gemini_flash", "openrouter_r1", "claude_sonnet"]},
    "forge_minimalist":  {"preferred": "gemini_flash",     "fallback": ["groq_qwen3", "openrouter_r1", "claude_sonnet"]},
    "audit_security":    {"preferred": "groq_r1",          "fallback": ["openrouter_r1_0528", "gemini_flash", "claude_sonnet"]},
    "audit_economy":     {"preferred": "gemini_flash",     "fallback": ["groq_r1", "openrouter_r1", "claude_sonnet"]},
    "audit_structural":  {"preferred": "groq_qwen3",       "fallback": ["groq_r1", "gemini_flash", "claude_sonnet"]},
    "audit_adversarial": {"preferred": "openrouter_r1",    "fallback": ["groq_r1", "gemini_flash", "claude_sonnet"]},
    "synthesis":         {"preferred": "groq_r1",          "fallback": ["gemini_pro", "openrouter_r1_0528", "claude_opus"]},
    "fallback_any":      {"preferred": "groq_r1",          "fallback": ["gemini_flash", "openrouter_r1", "claude_sonnet"]},
    # SALUS multi-model audit pipeline
    "salus_primary":     {"preferred": "gemini_pro",       "fallback": ["groq_r1", "gemini_flash", "openrouter_r1"]},
    "salus_reasoning":   {"preferred": "groq_r1",          "fallback": ["openrouter_r1_0528", "groq_qwen3", "gemini_flash"]},
    # Conrrad (Colab) primario; Derek local si no hay túnel / Conrrad falla
    "harlemm_conrrad":   {"preferred": "hf_conrrad",       "fallback": ["local_derek"]},
}


def is_kernell_online(redis_client: redis.Redis) -> bool:
    """
    Check if the Kernell (Antigravity) agent is currently online.
    Returns True if heartbeat exists and is less than 300s old.
    Used by ForgeCouncilV3 to decide whether to route to Opus.
    """
    try:
        raw = redis_client.get("kernell:agent:kernell:heartbeat")
        if raw:
            ts = float(raw if isinstance(raw, str) else raw.decode())
            import time
            return (time.time() - ts) < 300
    except Exception:
        pass
    return False


@dataclass
class LLMResponse:
    content: str
    reasoning_trace: Optional[str]  # Chain-of-thought completo
    provider_used: str
    model_used: str
    is_reasoning_model: bool
    latency_ms: float
    tokens_used: int
    cost_tier: str
    fallback_used: bool
    timestamp: str
    # True si la respuesta viene de Conrrad/Derek tras fallo total de la cadena del rol
    last_resort: bool = False


# ── HNP integration ──────────────────────────────────────────────────────────
try:
    from core.sea.hallucination_guard import (
        inject_role_anchor as _hnp_inject_role_anchor,
        verify_role_consistency as _hnp_verify_role,
        record_semantic_failure as _hnp_record_fail,
    )
    _HNP_LLM_AVAILABLE = True
except ImportError:
    _HNP_LLM_AVAILABLE = False

# ── Context Middleware integration (P0 — context window patterns) ───────────────
try:
    from core.context_middleware import get_context_manager as _get_ctx_mgr
    _CTX_MIDDLEWARE_AVAILABLE = True
except ImportError:
    _CTX_MIDDLEWARE_AVAILABLE = False

# Roles cuyos preferred providers son R1 → necesitan role anchor
_HNP_R1_ROLES = frozenset({
    "forge_opposition", "audit_security", "audit_adversarial",
    "synthesis", "salus_reasoning",
})

# Descripción de función por rol para el role anchor
_HNP_ROLE_FUNCTIONS = {
    "forge_opposition":  "encontrar fallos, riesgos y debilidades en el código propuesto",
    "audit_security":    "detectar vulnerabilidades de seguridad en el código auditado",
    "audit_adversarial": "atacar activamente el código buscando vectores de explotación",
    "synthesis":         "sintetizar análisis narrativo del estado del sistema — NO generar código",
    "salus_reasoning":   "razonar sobre hallazgos de seguridad con cadena de pensamiento",
}


class LLMProviderRegistry:

    def __init__(self, redis_client: redis.Redis):
        self.redis     = redis_client
        self._breakers = {n: ProviderCircuitBreaker(n, redis_client) for n in PROVIDER_CATALOG}
        self._ctx_managers = {}  # lazy-initialized ContextManagers per role

    def _harlemm_include_local_derek(self) -> bool:
        """
        Derek (Ollama) evita CPU/RAM si no se usa: solo entra en cadena Harlemm
        cuando el modo lo permite (evita inferencias locales en operación nominal).

        HARLEMM_DEREK_MODE:
          - degraded_only (default): incluye local_derek si kernell:conrrad:endpoints
            está vacío O si Redis kernell:harlemm:force_derek_fallback = 1/true
          - on / always: siempre tras fallar Conrrad
          - off: nunca (solo Conrrad; errores si cae el túnel con endpoints listos)
        """
        mode = os.environ.get("HARLEMM_DEREK_MODE", "degraded_only").strip().lower()
        if mode in ("off", "disabled", "0", "false", "no"):
            return False
        if mode in ("on", "always", "1", "true", "yes"):
            return True
        try:
            fk = self.redis.get("kernell:harlemm:force_derek_fallback")
            if fk is not None:
                s = fk.decode() if isinstance(fk, bytes) else str(fk)
                if s.strip().lower() in ("1", "true", "yes", "on"):
                    return True
            if int(self.redis.llen("kernell:conrrad:endpoints") or 0) == 0:
                return True
        except Exception as e:
            logger.debug(f"[LLM] harlemm Derek gate: {e}")
        return False

    def _harlemm_last_resort_enabled(self) -> bool:
        """
        Tras agotar la cadena del rol, intentar hf_conrrad → local_derek (misma política Derek).
        Desactivar: HARLEMM_LAST_RESORT_LLM=0 o Redis kernell:harlemm:last_resort_llm=0/false.
        Por defecto activo: Harlemm es el respaldo cuando fallan el resto de API keys/rutas.
        """
        env = os.environ.get("HARLEMM_LAST_RESORT_LLM", "1").strip().lower()
        if env in ("0", "false", "no", "off"):
            return False
        try:
            fk = self.redis.get("kernell:harlemm:last_resort_llm")
            if fk is not None:
                s = fk.decode() if isinstance(fk, bytes) else str(fk)
                if s.strip().lower() in ("0", "false", "no", "off"):
                    return False
        except Exception as e:
            logger.debug(f"[LLM] last_resort redis flag: {e}")
        return True

    def _build_last_resort_system_prompt(self, effective_system: str) -> str:
        try:
            from core.sea.harlemm_reality_pipeline import HarlemmRealityPipeline

            root = Path(__file__).resolve().parents[2]
            pipe = HarlemmRealityPipeline(self.redis, root=root)
            return pipe.build_last_resort_overlay(effective_system)
        except Exception as e:
            logger.debug(f"[LLM] last resort overlay: {e}")
            return (
                "[ÚLTIMO RECURSO KERNELL] Fallaron APIs del rol.\n\n"
                + (effective_system or "")
            )

    # ── API principal ─────────────────────────────────────────────────────

    def _get_ctx(self, role: str):
        """Get or create a ContextManager for a role (lazy singleton)."""
        if not _CTX_MIDDLEWARE_AVAILABLE:
            return None
        if role not in self._ctx_managers:
            try:
                agent_name = role.split("_")[0] if "_" in role else role
                self._ctx_managers[role] = _get_ctx_mgr(
                    agent_name, redis_client=self.redis
                )
            except Exception:
                return None
        return self._ctx_managers[role]

    def complete(
        self,
        messages: list[dict],
        system_prompt: str = "",
        role: str = "fallback_any",
        preferred_provider: Optional[str] = None,
        max_tokens: int = 1500,
        temperature: float = 0.3,
    ) -> Optional[LLMResponse]:
        # ── Context Middleware: pre-query hook ────────────────────────────────
        ctx = self._get_ctx(role)
        if ctx:
            try:
                messages = ctx.pre_query(messages)
            except Exception as _ctx_e:
                logger.debug(f"[LLM] Context pre_query error: {_ctx_e}")

        role_cfg = ROLE_CHAINS.get(role, ROLE_CHAINS["fallback_any"])
        fallbacks = list(role_cfg.get("fallback", []))
        if role == "harlemm_conrrad" and not self._harlemm_include_local_derek():
            fallbacks = [x for x in fallbacks if x != "local_derek"]
        chain = (
            [preferred_provider] + fallbacks
            if preferred_provider
            else [role_cfg["preferred"]] + fallbacks
        )

        # ── HNP Control 4: Role anchor para roles R1 ──────────────────────────
        # Se inyecta en system_prompt; el r1_quirk lo fusionará al inicio del
        # user message, garantizando que [ROLE LOCK] llegue antes de cualquier tarea.
        effective_system = system_prompt
        if _HNP_LLM_AVAILABLE and role in _HNP_R1_ROLES and system_prompt:
            try:
                fn = _HNP_ROLE_FUNCTIONS.get(role, role)
                effective_system = _hnp_inject_role_anchor(
                    system_prompt, role=role, function=fn
                )
                logger.debug(f"[LLM] HNP role anchor injected for role='{role}'")
            except Exception as _e:
                logger.warning(f"[LLM] HNP role anchor injection error: {_e}")

        # ── Memory Paging S1: inject paging tools into system prompt ──────────
        if ctx:
            try:
                effective_system = ctx.inject_paging_system_prompt(effective_system)
            except Exception as _pg_e:
                logger.debug(f"[LLM] Paging prompt injection error: {_pg_e}")

        for i, name in enumerate(chain):
            if name not in PROVIDER_CATALOG:
                continue
            if self._breakers[name].is_open():
                logger.debug(f"[LLM] {name} circuit open — skipping")
                continue

            resp = self._call_with_retry(name, messages, effective_system, max_tokens, temperature)
            if resp:
                self._breakers[name].record_success()
                resp.fallback_used = (i > 0)
                self._record_metrics(name, resp)

                # ── Context Middleware: post-query hook ───────────────────
                if ctx:
                    try:
                        ctx.post_query(response_tokens=resp.tokens_used)
                    except Exception:
                        pass

                # ── Memory Paging S1: intercept tool calls in response ────────
                if ctx and resp.content:
                    try:
                        clean, extra = ctx.intercept_paging_tools(resp.content)
                        if extra:
                            resp.content = clean + "\n" + extra
                    except Exception as _pg_e:
                        logger.debug(f"[LLM] Paging interception error: {_pg_e}")

                # ── HNP Control 4 post-check: detectar role drift ─────────────
                if _HNP_LLM_AVAILABLE and role in _HNP_R1_ROLES and resp.content:
                    try:
                        rc = _hnp_verify_role(resp.content, expected_role=role)
                        if rc.get("severity") == "HIGH":
                            logger.warning(
                                f"[LLM] HNP HIGH drift: {name} rol='{role}' "
                                f"violations={rc['violations']}"
                            )
                            _hnp_record_fail(name, reason="role_drift_high")
                    except Exception as _e:
                        logger.debug(f"[LLM] HNP role check error: {_e}")

                if i > 0:
                    logger.info(f"[LLM] Fallback exitoso: {name} (intento {i+1}, rol={role})")
                return resp

            self._breakers[name].record_failure()
            logger.warning(f"[LLM] {name} falló para rol '{role}'")

        logger.error(f"[LLM] Todos los proveedores fallaron — rol='{role}'")

        # ── Último recurso: Conrrad (Colab) → Derek (local), sin reentrar en harlemm_conrrad ──
        if role != "harlemm_conrrad" and self._harlemm_last_resort_enabled():
            logger.warning(
                f"[LLM] Harlemm last-resort: reintentando vía hf_conrrad/local_derek (rol={role})"
            )
            emergency_system = self._build_last_resort_system_prompt(effective_system)
            lr_chain: list[str] = ["hf_conrrad"]
            if self._harlemm_include_local_derek():
                lr_chain.append("local_derek")
            for i, name in enumerate(lr_chain):
                if name not in PROVIDER_CATALOG:
                    continue
                if self._breakers[name].is_open():
                    logger.debug(f"[LLM] last-resort {name} circuit open — skip")
                    continue
                resp = self._call_with_retry(
                    name, messages, emergency_system, max_tokens, temperature
                )
                if resp:
                    self._breakers[name].record_success()
                    resp.fallback_used = True
                    resp.last_resort = True
                    self._record_metrics(name, resp)
                    try:
                        self.redis.lpush(
                            "kernell:llm:metrics:harlemm_last_resort",
                            json.dumps(
                                {
                                    "provider": name,
                                    "role": role,
                                    "timestamp": resp.timestamp,
                                }
                            ),
                        )
                        self.redis.ltrim("kernell:llm:metrics:harlemm_last_resort", 0, 99)
                    except Exception as e:
                        logger.debug(f"[LLM] last-resort metric redis: {e}")
                    logger.info(
                        f"[LLM] Harlemm last-resort OK: {name} (rol={role}, intento {i + 1})"
                    )
                    return resp
                self._breakers[name].record_failure()

        return None

    # ── Scheduled Complete (AIOS S3) ──────────────────────────────────────

    def scheduled_complete(
        self,
        messages: list[dict],
        system_prompt: str = "",
        role: str = "fallback_any",
        agent_name: str = "unknown",
        preferred_provider: Optional[str] = None,
        max_tokens: int = 1500,
        temperature: float = 0.3,
        timeout_s: float = 120.0,
    ) -> Optional[LLMResponse]:
        """
        Versión con cola de prioridad de complete().
        Si el scheduler está habilitado, encola la petición por prioridad.
        Si no, llama directamente a complete() (cero overhead).

        Migración gradual: los agentes pueden optar por usar esta versión
        sin afectar agentes que aún usen complete() directo.
        """
        try:
            from core.sea.llm_scheduler import LLMScheduler, SCHEDULER_ENABLED

            if not SCHEDULER_ENABLED:
                return self.complete(
                    messages=messages,
                    system_prompt=system_prompt,
                    role=role,
                    preferred_provider=preferred_provider,
                    max_tokens=max_tokens,
                    temperature=temperature,
                )

            if not hasattr(self, '_scheduler') or self._scheduler is None:
                self._scheduler = LLMScheduler(
                    registry=self,
                    redis_client=self.redis,
                )

            return self._scheduler.submit(
                messages=messages,
                system_prompt=system_prompt,
                role=role,
                agent_name=agent_name,
                preferred_provider=preferred_provider,
                max_tokens=max_tokens,
                temperature=temperature,
                timeout_s=timeout_s,
            )
        except ImportError:
            return self.complete(
                messages=messages,
                system_prompt=system_prompt,
                role=role,
                preferred_provider=preferred_provider,
                max_tokens=max_tokens,
                temperature=temperature,
            )

    # ── Retry ─────────────────────────────────────────────────────────────

    def _call_with_retry(self, name, messages, system_prompt, max_tokens, temperature):
        for attempt in range(MAX_RETRIES + 1):
            if attempt > 0:
                time.sleep(1.0 * (2 ** (attempt - 1)))
            r = self._call_provider(name, messages, system_prompt, max_tokens, temperature)
            if r:
                return r
        return None

    def _call_provider(self, name, messages, system_prompt, max_tokens, temperature):
        config = PROVIDER_CATALOG[name]

        # Conrrad: solo Colab — sin router Hugging Face. El watchdog mantiene una LIST de endpoints.
        if name == "hf_conrrad":
            t0 = time.time()
            try:
                # El watchdog escribe la key con RPUSH (List), usamos lrange.
                endpoints = self.redis.lrange("kernell:conrrad:endpoints", 0, -1)
                if not endpoints:
                    logger.error(
                        "[LLM] hf_conrrad: inferencia solo Colab — "
                        "kernell:conrrad:endpoints vacío (arranca swarm / túnel)."
                    )
                    return None
                
                import random
                best_ep = None
                best_lat = float('inf')
                
                # Mezclamos para balancear aleatoriamente los empates o faltas de latencia
                endpoints_str = [(ep.decode() if isinstance(ep, bytes) else str(ep)).strip().rstrip("/") for ep in endpoints]
                random.shuffle(endpoints_str)
                
                for ep_str in endpoints_str:
                    try:
                        lat_raw = self.redis.get(f"kernell:conrrad:endpoint_latency:{ep_str[:60]}")
                        lat = float(lat_raw) if lat_raw else float('inf')
                    except Exception:
                        lat = float('inf')
                    
                    if lat < best_lat:
                        best_lat = lat
                        best_ep = ep_str
                
                if not best_ep:
                    best_ep = endpoints_str[0]

                resolved_url = f"{best_ep}/v1/chat/completions"
            except Exception as e:
                logger.error(f"[LLM] hf_conrrad: error leyendo kernell:conrrad:endpoints: {e}")
                return None
            api_key = "sk-no-auth"
            try:
                raw = self._call_openai_compat(
                    config, api_key, messages, system_prompt, max_tokens, temperature, resolved_url
                )
                if not raw:
                    return None
                content, reasoning = self._extract(raw, config)
                tokens = self._extract_tokens(raw, config["format"])
                return LLMResponse(
                    content=content,
                    reasoning_trace=reasoning,
                    provider_used=name,
                    model_used=config["model"],
                    is_reasoning_model=config.get("reasoning", False),
                    latency_ms=round((time.time() - t0) * 1000, 1),
                    tokens_used=tokens,
                    cost_tier=config["cost_tier"],
                    fallback_used=False,
                    timestamp=datetime.now(timezone.utc).isoformat(),
                    last_resort=False,
                )
            except Exception as e:
                logger.error(f"[LLM] {name}: {type(e).__name__}: {str(e)[:150]}")
                return None

        if name == "local_derek":
            t0 = time.time()
            api_key = os.environ.get(config.get("env_key", "DEREK_API_KEY"), "") or "ollama"
            resolved_url = (config.get("url") or "").strip() or "http://127.0.0.1:11434/v1/chat/completions"
            try:
                raw = self._call_openai_compat(
                    config, api_key, messages, system_prompt, max_tokens, temperature, resolved_url
                )
                if not raw:
                    return None
                content, reasoning = self._extract(raw, config)
                tokens = self._extract_tokens(raw, config["format"])
                return LLMResponse(
                    content=content,
                    reasoning_trace=reasoning,
                    provider_used=name,
                    model_used=config["model"],
                    is_reasoning_model=config.get("reasoning", False),
                    latency_ms=round((time.time() - t0) * 1000, 1),
                    tokens_used=tokens,
                    cost_tier=config["cost_tier"],
                    fallback_used=False,
                    timestamp=datetime.now(timezone.utc).isoformat(),
                    last_resort=False,
                )
            except Exception as e:
                logger.error(f"[LLM] {name}: {type(e).__name__}: {str(e)[:150]}")
                return None

        api_key = self._get_api_key(config)
        if not api_key:
            logger.warning(f"[LLM] No API key para {name}")
            return None

        t0 = time.time()
        resolved_url = config["url"]

        try:
            if config["format"] == ProviderFormat.ANTHROPIC:
                raw = self._call_anthropic(config, api_key, messages, system_prompt, max_tokens, resolved_url)
            else:
                raw = self._call_openai_compat(
                    config, api_key, messages, system_prompt, max_tokens, temperature, resolved_url
                )
            if not raw:
                return None

            content, reasoning = self._extract(raw, config)
            tokens = self._extract_tokens(raw, config["format"])

            return LLMResponse(
                content=content,
                reasoning_trace=reasoning,
                provider_used=name,
                model_used=config["model"],
                is_reasoning_model=config.get("reasoning", False),
                latency_ms=round((time.time() - t0) * 1000, 1),
                tokens_used=tokens,
                cost_tier=config["cost_tier"],
                fallback_used=False,
                timestamp=datetime.now(timezone.utc).isoformat(),
                last_resort=False,
            )
        except Exception as e:
            logger.error(f"[LLM] {name}: {type(e).__name__}: {str(e)[:150]}")
            return None

    # ── Formatos de llamada ───────────────────────────────────────────────

    def _call_anthropic(self, config, api_key, messages, system_prompt, max_tokens, resolved_url=None):
        p: dict = {"model": config["model"], "max_tokens": max_tokens, "messages": messages}
        if system_prompt:
            # ── Prompt Caching: structured system block with cache_control ──
            # Anthropic caches KV matrices for blocks marked with cache_control,
            # giving 90% cost reduction and 85% latency reduction on cached tokens.
            # The system prompt is static between calls, making it ideal for caching.
            p["system"] = [
                {
                    "type": "text",
                    "text": system_prompt,
                    "cache_control": {"type": "ephemeral"},
                }
            ]
        return self._post(resolved_url or config["url"], p, {
            "Content-Type": "application/json",
            "x-api-key": api_key,
            "anthropic-version": "2023-06-01",
        })

    def _call_openai_compat(self, config, api_key, messages, system_prompt, max_tokens, temperature, resolved_url=None):
        msgs = list(messages)

        # R1 quirk: fusionar system prompt en primer user message
        if config.get("r1_quirk") and system_prompt:
            if msgs and msgs[0]["role"] == "user":
                msgs[0] = {
                    "role": "user",
                    "content": f"[System Instructions]\n{system_prompt}\n\n[Task]\n{msgs[0]['content']}",
                }
            else:
                msgs.insert(0, {"role": "user", "content": f"[System Instructions]\n{system_prompt}"})
        elif system_prompt:
            msgs = [{"role": "system", "content": system_prompt}] + msgs

        p = {"model": config["model"], "max_tokens": max_tokens, "messages": msgs, "temperature": temperature}
        h = {"Content-Type": "application/json", "Authorization": f"Bearer {api_key}"}

        url = resolved_url or config["url"]
        if config.get("openrouter"):
            h["HTTP-Referer"] = "https://kernell.os"
            h["X-Title"]      = "Kernell OS"
        if config.get("gemini"):
            url = f"{url}?key={api_key}"
            if "Authorization" in h:
                del h["Authorization"]

        return self._post(url, p, h)

    # ── Extracción ────────────────────────────────────────────────────────

    def _extract(self, raw: dict, config: dict) -> tuple[str, Optional[str]]:
        reasoning = None
        if config["format"] == ProviderFormat.ANTHROPIC:
            blocks    = raw.get("content", [])
            content   = "".join(b.get("text", "")     for b in blocks if b.get("type") == "text").strip()
            thinks    = [b.get("thinking", "")          for b in blocks if b.get("type") == "thinking"]
            if thinks:
                reasoning = "\n---\n".join(thinks).strip()
        else:
            msg     = (raw.get("choices") or [{}])[0].get("message", {})
            content = (msg.get("content") or "").strip()
            reasoning = msg.get("reasoning_content") or None
            if not reasoning and "<think>" in content:
                m = re.search(r"<think>(.*?)</think>", content, re.DOTALL)
                if m:
                    reasoning = m.group(1).strip()
                    content   = re.sub(r"<think>.*?</think>", "", content, flags=re.DOTALL).strip()
        return content, reasoning

    def _extract_tokens(self, raw: dict, fmt: ProviderFormat) -> int:
        u = raw.get("usage", {})
        if fmt == ProviderFormat.ANTHROPIC:
            total = u.get("input_tokens", 0) + u.get("output_tokens", 0)
            # Track prompt cache metrics for observability
            cache_created = u.get("cache_creation_input_tokens", 0)
            cache_read = u.get("cache_read_input_tokens", 0)
            if cache_read > 0 or cache_created > 0:
                logger.info(
                    f"[CACHE] Anthropic prompt cache: "
                    f"read={cache_read} created={cache_created} "
                    f"(saved ~{cache_read * 0.9:.0f} tokens worth of cost)"
                )
                # Publish cache stats to Redis for telemetry
                if self._redis:
                    try:
                        self._redis.hincrby("kernell:llm:cache:anthropic", "cache_read_tokens", cache_read)
                        self._redis.hincrby("kernell:llm:cache:anthropic", "cache_created_tokens", cache_created)
                        self._redis.hincrby("kernell:llm:cache:anthropic", "cache_hits", 1 if cache_read > 0 else 0)
                        self._redis.expire("kernell:llm:cache:anthropic", 86400)
                    except Exception:
                        pass
            return total
        return u.get("total_tokens", 0)

    # ── HTTP ──────────────────────────────────────────────────────────────

    def _post(self, url: str, payload: dict, headers: dict) -> Optional[dict]:
        data = json.dumps(payload, ensure_ascii=False).encode()
        req  = urllib.request.Request(url, data=data, headers={**headers, "User-Agent": "Kernell-OS/1.0"}, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=DEFAULT_TIMEOUT_S) as r:
                return json.loads(r.read().decode())
        except urllib.error.HTTPError as e:
            logger.error(f"[LLM] HTTP {e.code} {url[:60]}: {e.read().decode()[:200]}")
        except Exception as e:
            logger.error(f"[LLM] {url[:60]}: {e}")
        return None

    # ── Key management ────────────────────────────────────────────────────

    def _get_api_key(self, config: dict) -> Optional[str]:
        import random
        env_key = config.get("env_key", "")
        
        # ── API Rotation Skill Integration ──
        if env_key == "GROQ_API_KEY":
            pool_str = os.environ.get("GROQ_POOL", "[]")
            try:
                pool = json.loads(pool_str)
                if pool and isinstance(pool, list):
                    return random.choice(pool)
            except Exception:
                pass
                
        raw = self.redis.get(config.get("redis_key", ""))
        if raw:
            return raw if isinstance(raw, str) else raw.decode()
        return os.environ.get(env_key)

    def register_key(self, provider_family: str, api_key: str):
        """
        Registra API key en Redis. Llamar una vez en el setup.
        provider_family: "anthropic" | "groq" | "gemini" | "openrouter"
        """
        key_map = {
            "anthropic":  "kernell:llm:keys:anthropic",
            "groq":       "kernell:llm:keys:groq",
            "gemini":     "kernell:llm:keys:gemini",
            "openrouter": "kernell:llm:keys:openrouter",
        }
        k = key_map.get(provider_family)
        if not k:
            raise ValueError(f"Proveedor desconocido: {provider_family}")
        self.redis.set(k, api_key)
        logger.info(f"[LLM] ✓ Key registrada para {provider_family}")

    # ── Estado ────────────────────────────────────────────────────────────

    def _record_metrics(self, name: str, resp: LLMResponse):
        self.redis.lpush(f"kernell:llm:metrics:{name}", json.dumps({
            "latency_ms": resp.latency_ms, "tokens": resp.tokens_used,
            "reasoning": resp.is_reasoning_model, "fallback": resp.fallback_used,
            "last_resort": getattr(resp, "last_resort", False),
            "timestamp": resp.timestamp,
        }))
        self.redis.ltrim(f"kernell:llm:metrics:{name}", 0, 199)

    def provider_health(self) -> dict:
        return {
            n: {
                "available": not self._breakers[n].is_open(),
                "failures":  self._breakers[n].failure_count(),
                "cost_tier": PROVIDER_CATALOG[n]["cost_tier"],
                "reasoning": PROVIDER_CATALOG[n]["reasoning"],
                "model":     PROVIDER_CATALOG[n]["model"],
            }
            for n in PROVIDER_CATALOG
        }

    def free_reasoning_available(self) -> list[str]:
        return [
            n for n, c in PROVIDER_CATALOG.items()
            if c["cost_tier"] == "free" and c["reasoning"]
            and not self._breakers[n].is_open()
        ]


class ProviderCircuitBreaker:
    def __init__(self, name: str, redis_client: redis.Redis):
        self.name  = name
        self.redis = redis_client
        self._kf   = f"kernell:llm:cb:{name}:failures"
        self._ku   = f"kernell:llm:cb:{name}:open_until"

    def is_open(self) -> bool:
        raw = self.redis.get(self._ku)
        if raw:
            try:
                until = datetime.fromisoformat(raw if isinstance(raw, str) else raw.decode())
                if datetime.now(timezone.utc) < until:
                    return True
                self.redis.delete(self._ku, self._kf)
            except Exception:
                pass
        return False

    def record_failure(self):
        count = self.redis.incr(self._kf)
        self.redis.expire(self._kf, CIRCUIT_BREAKER_RESET_S * 2)
        if int(count) >= CIRCUIT_BREAKER_THRESHOLD:
            until = (datetime.now(timezone.utc) + timedelta(seconds=CIRCUIT_BREAKER_RESET_S)).isoformat()
            self.redis.set(self._ku, until)
            logger.warning(f"[CB] ⚡ {self.name} circuit ABIERTO — reset {CIRCUIT_BREAKER_RESET_S//60}min")

    def record_success(self):
        self.redis.delete(self._kf, self._ku)

    def failure_count(self) -> int:
        raw = self.redis.get(self._kf)
        return int(raw) if raw else 0


# ── DEEPSEEK via GROQ PATCH ─────────────────────────────────────
# DeepSeek R1 & Coder via GroqCloud (free, fast hardware)
# Models: deepseek-r1-distill-llama-70b, deepseek-r1-distill-qwen-32b
# Uses GROQ_API_KEY (carousel or env) — no DEEPSEEK_API_KEY needed
# ─────────────────────────────────────────────────────────────────
import os as _os
import time as _time

class _CircuitBreaker:
    def __init__(self, pid, ft=3, rs=600):
        self.pid=pid; self.ft=ft; self.rs=rs
        self._f=0; self._ts=0.0; self._state="CLOSED"
        import threading; self._lock=threading.Lock()
    def can_attempt(self):
        with self._lock:
            if self._state=="OPEN" and _time.time()-self._ts>self.rs:
                self._state="HALF_OPEN"
            return self._state!="OPEN"
    def ok(self):
        with self._lock: self._f=0; self._state="CLOSED"
    def fail(self, e=""):
        with self._lock:
            self._f+=1; self._ts=_time.time()
            if self._f>=self.ft:
                self._state="OPEN"
                import json, redis as _r
                try:
                    pw = _os.environ.get("REDIS_PASSWORD", "")
                    _r.Redis(password=pw if pw else None, decode_responses=True).lpush(
                        "kernell:salus:errors",
                        json.dumps({"code":"R-B07-CB-OPEN","provider":self.pid,"ts":self._ts}))
                except Exception: pass

_cb_r1    = _CircuitBreaker("deepseek-r1-groq")
_cb_coder = _CircuitBreaker("deepseek-coder-groq")

# Groq models — best reasoning + coding models available
_GROQ_R1_MODEL    = "qwen/qwen3-32b"              # Reasoning — 131K ctx, chain-of-thought
_GROQ_CODER_MODEL = "llama-3.3-70b-versatile"      # Coding — 131K ctx, strong at code
_GROQ_BASE_URL    = "https://api.groq.com/openai/v1/chat/completions"

def _get_groq_key():
    """Get Groq API key from GROQ_POOL (rotation), env, or Redis."""
    import json as _json
    pool_str = _os.environ.get("GROQ_POOL", "[]")
    try:
        pool = _json.loads(pool_str)
        if pool and isinstance(pool, list):
            import random
            return random.choice(pool)
    except Exception:
        pass
    return _os.environ.get("GROQ_API_KEY", "")

def _call_groq(model, prompt, system="", max_tokens=2000, temperature=0.0):
    """Generic Groq call via urllib (no SDK dependency)."""
    import urllib.request, urllib.error, json as _json
    key = _get_groq_key()
    if not key:
        raise RuntimeError("No GROQ_API_KEY available")

    # R1 quirk: system prompt fusionado en user message
    msgs = []
    if system:
        msgs.append({"role": "user", "content": f"[System Instructions]\n{system}\n\n[Task]\n{prompt}"})
    else:
        msgs.append({"role": "user", "content": prompt})

    payload = _json.dumps({
        "model": model, "messages": msgs,
        "max_tokens": max_tokens, "temperature": temperature,
    }).encode()

    req = urllib.request.Request(_GROQ_BASE_URL, data=payload, headers={
        "Content-Type": "application/json",
        "Authorization": f"Bearer {key}",
        "User-Agent": "Kernell-OS/1.0",
    }, method="POST")

    with urllib.request.urlopen(req, timeout=60) as r:
        data = _json.loads(r.read().decode())
    return data

def call_deepseek_r1(prompt, system="", max_tokens=2000):
    """DeepSeek R1 via Groq (deepseek-r1-distill-llama-70b). Fallback: Gemini → Anthropic."""
    if not _cb_r1.can_attempt():
        return _gemini_fallback(prompt, system, max_tokens)
    try:
        import re
        data = _call_groq(_GROQ_R1_MODEL, prompt, system, max_tokens)
        msg = data["choices"][0]["message"]
        text = msg.get("content", "")
        # Extract reasoning if present
        text = re.sub(r'<think>.*?</think>', '', text, flags=re.DOTALL).strip()
        _cb_r1.ok()
        return text
    except Exception as e:
        _cb_r1.fail(str(e))
        logger.warning(f"DeepSeek R1 (Groq) falló: {e}")
        return _gemini_fallback(prompt, system, max_tokens)

def call_deepseek_coder(prompt, system="", max_tokens=1500):
    """DeepSeek Coder via Groq (deepseek-r1-distill-qwen-32b). Fallback: Gemini → Anthropic."""
    if not _cb_coder.can_attempt():
        return _gemini_fallback(prompt, system, max_tokens)
    try:
        data = _call_groq(_GROQ_CODER_MODEL, prompt, system, max_tokens, temperature=0.1)
        text = data["choices"][0]["message"].get("content", "")
        _cb_coder.ok()
        return text
    except Exception as e:
        _cb_coder.fail(str(e))
        logger.warning(f"DeepSeek Coder (Groq) falló: {e}")
        return _gemini_fallback(prompt, system, max_tokens)

def get_deepseek_reasoning(prompt):
    """Get full reasoning trace from DeepSeek R1 via Groq."""
    if not _cb_r1.can_attempt():
        return {"thinking": "[CB OPEN]", "response": "", "model": _GROQ_R1_MODEL}
    try:
        import re
        data = _call_groq(_GROQ_R1_MODEL, prompt, max_tokens=4000)
        msg = data["choices"][0]["message"]
        full = msg.get("content", "")
        thinking = msg.get("reasoning_content", "")
        if not thinking:
            m = re.search(r'<think>(.*?)</think>', full, re.DOTALL)
            thinking = m.group(1).strip() if m else ""
        response = re.sub(r'<think>.*?</think>', '', full, flags=re.DOTALL).strip()
        _cb_r1.ok()
        return {"thinking": thinking, "response": response, "model": _GROQ_R1_MODEL}
    except Exception as e:
        _cb_r1.fail(str(e))
        return {"thinking": f"[Error: {e}]", "response": "", "model": _GROQ_R1_MODEL}

def _gemini_fallback(prompt, system="", max_tokens=1000):
    """Fallback to Gemini Flash (free, via carousel keys)."""
    try:
        import urllib.request, urllib.error, json as _json
        # Get Gemini key from env
        key = _os.environ.get("GEMINI_API_KEY") or _os.environ.get("GOOGLE_API_KEY", "")
        if not key:
            return _anthropic_fallback(prompt, system, max_tokens, "claude-sonnet-4-20250514")
        url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key={key}"
        full_prompt = f"{system}\n\n{prompt}" if system else prompt
        payload = _json.dumps({
            "contents": [{"parts": [{"text": full_prompt[:8000]}]}],
            "generationConfig": {"maxOutputTokens": max_tokens, "temperature": 0.3}
        }).encode()
        req = urllib.request.Request(url, data=payload, headers={"Content-Type": "application/json"}, method="POST")
        with urllib.request.urlopen(req, timeout=30) as r:
            data = _json.loads(r.read().decode())
        return data["candidates"][0]["content"]["parts"][0]["text"]
    except Exception as e:
        logger.warning(f"Gemini fallback falló: {e}")
        return _anthropic_fallback(prompt, system, max_tokens, "claude-sonnet-4-20250514")

def _anthropic_fallback(prompt, system, max_tokens, model):
    try:
        import anthropic
        c = anthropic.Anthropic(api_key=_os.environ.get("ANTHROPIC_API_KEY"))
        m = c.messages.create(model=model, max_tokens=max_tokens,
            system=system or "You are a helpful assistant.",
            messages=[{"role": "user", "content": prompt}])
        return m.content[0].text
    except Exception as e:
        return f"[FALLBACK ERROR: {e}]"
# ── END DEEPSEEK via GROQ PATCH ─────────────────────────────────
