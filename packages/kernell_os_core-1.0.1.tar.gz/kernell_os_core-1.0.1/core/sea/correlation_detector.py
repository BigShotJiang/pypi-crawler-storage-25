"""
CORRELATION DETECTOR — Cross-Agent Collusion Detection
========================================================
Monitors mutations from multiple agents for suspicious
coordinated patterns that could indicate:
  - Multi-agent collusion to bypass safeguards
  - Cascade drift amplification
  - Simultaneous authority escalation attempts
  - Coordinated resource abuse

Detection methods:
  1. Temporal clustering: many agents acting in a narrow window
  2. Pattern matching: similar targets across agents
  3. Authority request spikes
"""

import json
import logging
import redis
from datetime import datetime, timezone, timedelta
from typing import Optional
from collections import Counter

logger = logging.getLogger("sea.correlation_detector")

# Detection parameters
TEMPORAL_WINDOW_SEC = 60    # Window for clustering analysis
MIN_AGENTS_FOR_ALERT = 3   # Min agents acting together for correlation
AUTHORITY_SPIKE_THRESHOLD = 5  # Max authority requests per window
TARGET_OVERLAP_THRESHOLD = 0.6  # 60% target overlap = suspicious


class CorrelationDetector:
    """
    Detects coordinated multi-agent anomalies.
    Runs periodically (ideally every SVS cycle or on-demand).
    """

    def __init__(self, redis_client: redis.Redis):
        self.redis = redis_client

    def analyze(self) -> dict:
        """
        Run full correlation analysis across all recent activity.
        
        Returns:
            dict with: temporal_clusters, authority_spikes, 
                      target_overlaps, risk_level, alerts
        """
        now = datetime.now(timezone.utc)
        alerts = []

        # 1. Temporal clustering
        clusters = self._detect_temporal_clusters(now)
        if clusters:
            alerts.extend(clusters)

        # 2. Authority request spikes
        spikes = self._detect_authority_spikes(now)
        if spikes:
            alerts.extend(spikes)

        # 3. Target overlap detection
        overlaps = self._detect_target_overlaps(now)
        if overlaps:
            alerts.extend(overlaps)

        # Calculate overall risk
        risk = min(100, len(alerts) * 25)

        result = {
            "timestamp": now.isoformat(),
            "alerts_count": len(alerts),
            "risk_level": risk,
            "alerts": alerts,
        }

        self.redis.set("kernell:immune:correlation", json.dumps(result))

        if alerts:
            logger.warning(
                f"[CORRELATION] {len(alerts)} alerts detected, risk={risk}"
            )

        return result

    def _detect_temporal_clusters(self, now: datetime) -> list[dict]:
        """Detect unusual temporal clustering of mutations."""
        alerts = []
        cutoff = now - timedelta(seconds=TEMPORAL_WINDOW_SEC)

        # Read recent revisions
        revisions = self.redis.lrange("kernell:rrp:history", 0, 49)
        recent_agents = set()

        for raw in revisions:
            data = json.loads(raw)
            try:
                ts = datetime.fromisoformat(data.get("timestamp", ""))
                if ts > cutoff:
                    recent_agents.add(data.get("author", "unknown"))
            except (ValueError, TypeError):
                pass

        if len(recent_agents) >= MIN_AGENTS_FOR_ALERT:
            alerts.append({
                "type": "temporal_cluster",
                "agents": list(recent_agents),
                "window_sec": TEMPORAL_WINDOW_SEC,
                "severity": "HIGH",
            })

        return alerts

    def _detect_authority_spikes(self, now: datetime) -> list[dict]:
        """Detect spikes in authority escalation requests."""
        alerts = []
        cutoff = now - timedelta(seconds=TEMPORAL_WINDOW_SEC)

        requests = self.redis.lrange("kernell:scope:violations", 0, 49)
        agent_counts: Counter = Counter()

        for raw in requests:
            data = json.loads(raw)
            try:
                ts = datetime.fromisoformat(data.get("timestamp", ""))
                if ts > cutoff:
                    agent_counts[data.get("agent", "unknown")] += 1
            except (ValueError, TypeError):
                pass

        for agent, count in agent_counts.items():
            if count >= AUTHORITY_SPIKE_THRESHOLD:
                alerts.append({
                    "type": "authority_spike",
                    "agent": agent,
                    "request_count": count,
                    "threshold": AUTHORITY_SPIKE_THRESHOLD,
                    "severity": "CRITICAL",
                })

        return alerts

    def _detect_target_overlaps(self, now: datetime) -> list[dict]:
        """Detect multiple agents targeting the same resources."""
        alerts = []
        cutoff = now - timedelta(minutes=10)

        revisions = self.redis.lrange("kernell:rrp:history", 0, 49)
        agent_targets: dict[str, set] = {}

        for raw in revisions:
            data = json.loads(raw)
            try:
                ts = datetime.fromisoformat(data.get("timestamp", ""))
                if ts > cutoff:
                    agent = data.get("author", "unknown")
                    target = data.get("target", "")
                    agent_targets.setdefault(agent, set()).add(target)
            except (ValueError, TypeError):
                pass

        # Check pairwise overlap
        agents_list = list(agent_targets.keys())
        for i in range(len(agents_list)):
            for j in range(i + 1, len(agents_list)):
                a1, a2 = agents_list[i], agents_list[j]
                t1, t2 = agent_targets[a1], agent_targets[a2]
                if not t1 or not t2:
                    continue

                overlap = len(t1 & t2) / min(len(t1), len(t2))
                if overlap >= TARGET_OVERLAP_THRESHOLD:
                    alerts.append({
                        "type": "target_overlap",
                        "agents": [a1, a2],
                        "overlap_ratio": round(overlap, 2),
                        "shared_targets": list(t1 & t2),
                        "severity": "HIGH",
                    })

        return alerts
