"""
SEA v2 — Self-Evolution Architecture
=====================================
Core governance, verification, and health modules for Kernell OS.

Components:
  - SVS v2: Sectoral Verification Sweep with watchdog + degraded mode
  - Forge Council v2: Multi-provider LLM debate (Claude/Gemini)
  - GSHI v2: Global System Health Index with objective metrics + EMA
  - Auditor Invariants: Deterministic constitutional invariant checker
  - Policy Engine: Centralized rule registry (L0/L1/L2, Tricapa, PFE gates)
"""

__version__ = "2.0.0"
