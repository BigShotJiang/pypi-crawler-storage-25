"""
OVERSEER BETA — Passive Shadow Validator
==========================================
Independent shadow instance that validates Overseer Alpha's metrics.
Runs in read-only mode — never writes to primary channels.

Responsibilities:
  1. Independently calculate Drift & Confidence
  2. Compare with Alpha's published values
  3. Alert on divergence > threshold
  4. Take over validation if Alpha goes silent

Alpha silence detection:
  If kernell:overseer:heartbeat is older than 5 minutes,
  Beta starts publishing to kernell:overseer:beta:metrics.
"""

import json
import logging
import redis
from datetime import datetime, timezone, timedelta
from typing import Optional

logger = logging.getLogger("sea.overseer_beta")

ALPHA_TIMEOUT_SEC = 300       # 5 minutes without heartbeat = Alpha failure
DIVERGENCE_THRESHOLD = 15.0   # Max acceptable metric difference
BETA_NAMESPACE = "kernell:overseer:beta"


class OverseerBeta:
    """
    Passive shadow that validates Overseer Alpha's output.
    Takes over validation duties if Alpha goes silent.
    """

    def __init__(self, redis_client: redis.Redis):
        self.redis = redis_client
        self._alpha_was_active = True

    def validate_alpha(self) -> dict:
        """
        Main validation cycle.
        Returns: validation result with status and any alerts.
        """
        alpha_healthy = self._check_alpha_heartbeat()

        if alpha_healthy:
            result = self._cross_validate()
        else:
            result = self._failover_mode()

        self._publish_heartbeat(result)
        return result

    def _check_alpha_heartbeat(self) -> bool:
        """Check if Alpha is still alive."""
        heartbeat_raw = self.redis.get("kernell:overseer:heartbeat")
        if not heartbeat_raw:
            return False

        try:
            data = json.loads(heartbeat_raw)
            ts = datetime.fromisoformat(data.get("timestamp", ""))
            age = (datetime.now(timezone.utc) - ts).total_seconds()
            return age < ALPHA_TIMEOUT_SEC
        except (ValueError, KeyError, json.JSONDecodeError):
            return False

    def _cross_validate(self) -> dict:
        """Compare Alpha's metrics against independent calculation."""
        alpha_raw = self.redis.get("kernell:overseer:metrics")
        if not alpha_raw:
            return {"status": "SKIP", "reason": "No Alpha metrics available"}

        alpha = json.loads(alpha_raw)
        alpha_drift = float(alpha.get("drift", 0))
        alpha_conf = float(alpha.get("confidence", 0))

        # Beta's independent calculation from raw data
        beta_drift = self._calculate_independent_drift()
        beta_conf = self._calculate_independent_confidence(beta_drift)

        drift_div = abs(alpha_drift - beta_drift)
        conf_div = abs(alpha_conf - beta_conf)
        max_div = max(drift_div, conf_div)

        status = "VALIDATED" if max_div <= DIVERGENCE_THRESHOLD else "DIVERGENT"

        result = {
            "status": status,
            "alpha_drift": alpha_drift,
            "beta_drift": beta_drift,
            "alpha_confidence": alpha_conf,
            "beta_confidence": beta_conf,
            "drift_divergence": round(drift_div, 2),
            "conf_divergence": round(conf_div, 2),
            "max_divergence": round(max_div, 2),
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

        if status == "DIVERGENT":
            logger.warning(
                f"[BETA] Alpha divergence: drift_diff={drift_div:.1f}, "
                f"conf_diff={conf_div:.1f}"
            )
            self.redis.lpush("kernell:alerts:system", json.dumps({
                "type": "overseer_divergence",
                **result,
            }))

        return result

    def _failover_mode(self) -> dict:
        """Alpha is down — publish Beta's own metrics."""
        if self._alpha_was_active:
            logger.warning("[BETA] Alpha Overseer is SILENT. Entering failover mode.")
            self._alpha_was_active = False

        drift = self._calculate_independent_drift()
        confidence = self._calculate_independent_confidence(drift)

        # Publish to Beta namespace (not overwriting Alpha's)
        self.redis.set(f"{BETA_NAMESPACE}:metrics", json.dumps({
            "drift": drift,
            "confidence": confidence,
            "source": "overseer_beta",
            "mode": "FAILOVER",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }))

        return {
            "status": "FAILOVER",
            "beta_drift": drift,
            "beta_confidence": confidence,
            "alpha_silent_for": "5+ minutes",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def _calculate_independent_drift(self) -> float:
        """
        Beta's own drift calculation from raw system metrics.
        Uses simpler heuristic than Alpha — intentional to detect bias.
        """
        try:
            # Read raw agent statuses
            agents_raw = self.redis.get("kernell:srs:agents")
            if not agents_raw:
                return 0.0

            agents = json.loads(agents_raw)
            if not isinstance(agents, list):
                return 0.0

            # Simple distress calculation
            dead = sum(1 for a in agents if a.get("status") in ["DEAD", "UNKNOWN"])
            total = max(1, len(agents))
            agent_distress = dead / total

            # Resource check
            import psutil
            cpu = psutil.cpu_percent(interval=0.1) / 100
            mem = psutil.virtual_memory().percent / 100

            resource_distress = max(0, (cpu - 0.7) / 0.3) * 0.5 + max(0, (mem - 0.8) / 0.2) * 0.5

            # Weighted
            drift = (agent_distress * 0.4 + resource_distress * 0.3 + 0.15 + 0.15) * 100
            return max(0, min(100, round(drift, 2)))

        except Exception as e:
            logger.debug(f"Beta drift calculation error: {e}")
            return 0.0

    def _calculate_independent_confidence(self, drift: float) -> float:
        """Simple confidence = 100 - drift with floor."""
        return max(5.0, 100.0 - drift)

    def _publish_heartbeat(self, result: dict):
        self.redis.set(f"{BETA_NAMESPACE}:heartbeat", json.dumps({
            "status": result.get("status", "UNKNOWN"),
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }), ex=ALPHA_TIMEOUT_SEC * 2)
