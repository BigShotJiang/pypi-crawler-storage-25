"""
CONFIDENCE ENGINE v13 — Logistic Penalty
==========================================
Corrección sobre v12:
  v12 usaba penalidad cuadrática (drift²/100) que colapsaba
  artificialmente la confianza a 0 cuando drift > 60.

v13 usa penalidad logística:
  penalty = 100 / (1 + e^(-0.08*(drift-50)))
  
  Comportamiento:
    Drift 0-30:  penalty ~0-5 (casi sin efecto)
    Drift 30-50: penalty 5-20 (gradual)
    Drift 50-70: penalty 20-80 (agresivo)
    Drift 70+:   penalty 80-95 (severo pero nunca 100)

  Confidence floor = 5.0 (nunca 0 absoluto)
"""

import math
import json
import logging
import redis
from datetime import datetime, timezone

logger = logging.getLogger("sea.confidence_engine")

CONFIDENCE_FLOOR = 5.0
LOGISTIC_STEEPNESS = 0.08  # Controla cuán rápido crece la penalidad
LOGISTIC_MIDPOINT = 50.0   # Drift donde la penalidad es 50%


class ConfidenceEngineV13:
    """
    Motor de Confidence v13 con penalidad logística.
    Nunca colapsa a 0 — mantiene un floor de 5.0.
    """

    def __init__(self, redis_client: redis.Redis):
        self.redis = redis_client

    def calculate(self, drift: float, agent_consistency: float = 1.0) -> float:
        """
        Calcula Confidence Score.
        
        Args:
            drift: Drift Index actual (0-100)
            agent_consistency: Factor de consistencia inter-agente (0-1)
        
        Returns:
            Confidence score (CONFIDENCE_FLOOR a 100)
        """
        base = 100.0 * min(1.0, max(0.0, agent_consistency))

        # Logistic penalty: smooth S-curve
        penalty = 100.0 / (1.0 + math.exp(-LOGISTIC_STEEPNESS * (drift - LOGISTIC_MIDPOINT)))

        confidence = base - penalty
        confidence = max(CONFIDENCE_FLOOR, min(100.0, confidence))
        confidence = round(confidence, 2)

        self._persist(confidence, drift, penalty)
        return confidence

    def _persist(self, confidence: float, drift: float, penalty: float):
        now = datetime.now(timezone.utc).isoformat()
        self.redis.set("kernell:confidence:value", str(confidence))
        self.redis.lpush("kernell:confidence:history", json.dumps({
            "confidence": confidence,
            "drift": drift,
            "penalty": round(penalty, 2),
            "timestamp": now,
        }))
        self.redis.ltrim("kernell:confidence:history", 0, 49)
