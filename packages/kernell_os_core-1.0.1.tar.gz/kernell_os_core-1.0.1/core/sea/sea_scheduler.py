"""
SEA Scheduler — Chronos Entrypoint for Self-Evolution Architecture
===================================================================
Chronos ejecuta este script via cron con argumentos CLI:

   python3 core/sea/sea_scheduler.py --svs        # SVS v2 sweep (cada 2h)
   python3 core/sea/sea_scheduler.py --gshi       # GSHI v2 calculation (cada 30min)
   python3 core/sea/sea_scheduler.py --synthesis  # Synthesis reasoning (cada 4h)
   python3 core/sea/sea_scheduler.py --nemesis-reset  # Reset contadores diarios (medianoche)

Cada función es independiente y publica resultados en Redis.
"""

import os
import sys
import json
import logging
import argparse
import redis
from datetime import datetime, timezone

logger = logging.getLogger("sea.scheduler")

REDIS_HOST = os.getenv("REDIS_HOST", "localhost")
# FIX B-9: default port was 6379, system uses 6380
REDIS_PORT = int(os.getenv("REDIS_PORT", 6380))
REDIS_PASSWORD = os.getenv("REDIS_PASSWORD", "")
SYSTEM_SECRET = os.getenv("KERNELL_SYSTEM_SECRET", "kernell-sea-default-secret")
CODEBASE_PATH = os.getenv("KERNELL_CODEBASE_PATH", "/home/anny/kernell-os")


def get_redis() -> redis.Redis:
    password = REDIS_PASSWORD.strip().strip("\"'") or None
    return redis.Redis(
        host=REDIS_HOST, port=REDIS_PORT,
        db=0, decode_responses=True,
        password=password,
    )


# ══════════════════════════════════════════════════════════════════════
# SVS SWEEP
# ══════════════════════════════════════════════════════════════════════

def run_svs_sweep():
    """Ejecuta SVS v2 sectoral sweep completo y publica resultado."""
    from core.sea.svs_v2 import SVSv2

    r = get_redis()
    svs = SVSv2(r, system_secret=SYSTEM_SECRET, codebase_path=CODEBASE_PATH)

    logger.info("[SEA] Iniciando SVS v2 sweep...")
    report = svs.run_sweep(allow_degraded=True)

    logger.info(
        f"[SEA] SVS completado: {report.overall_result} | "
        f"PFE={report.pfe_scope_allowed} | degraded={report.degraded_mode}"
    )

    # Publicar señal para Sierra
    r.set("kernell:sea:last_svs_trigger", json.dumps({
        "sweep_id": report.sweep_id,
        "result": report.overall_result,
        "triggered_at": datetime.now(timezone.utc).isoformat(),
        "source": "chronos",
    }))

    return report.overall_result


# ══════════════════════════════════════════════════════════════════════
# GSHI CALCULATION
# ══════════════════════════════════════════════════════════════════════

def run_gshi_calculation():
    """Calcula GSHI v2 con métricas objetivas y publica a Redis."""
    from core.sea.gshi_v2 import GSHIv2

    r = get_redis()
    gshi = GSHIv2(r, system_secret=SYSTEM_SECRET)

    # SII (System Immunity Index) — leer de Redis si existe, o usar default
    sii_raw = r.get("kernell:immune:sii")
    sii = float(sii_raw) if sii_raw else 65.0  # Default moderado

    logger.info("[SEA] Calculando GSHI v2...")
    report = gshi.calculate(sii=sii)

    logger.info(
        f"[SEA] GSHI: raw={report.gshi_raw:.1f} ema={report.gshi_ema:.1f} "
        f"({report.interpretation}) PFE={report.pfe_scope_allowed}"
    )

    # Publicar señal para Atlas
    r.set("kernell:sea:last_gshi_trigger", json.dumps({
        "gshi_ema": report.gshi_ema,
        "interpretation": report.interpretation,
        "triggered_at": datetime.now(timezone.utc).isoformat(),
        "source": "chronos",
    }))

    return report.gshi_ema


# ══════════════════════════════════════════════════════════════════════
# SYNTHESIS REASONING
# ══════════════════════════════════════════════════════════════════════

def run_synthesis(trigger: str = "scheduled"):
    """Ejecuta Synthesis Agent para razonamiento narrativo profundo."""
    from core.sea.synthesis_agent import SynthesisAgent

    r = get_redis()
    agent = SynthesisAgent(r)

    logger.info("[SEA] Iniciando Synthesis reasoning...")
    report = agent.synthesize(trigger=trigger)

    if report:
        logger.info(
            f"[SEA] Synthesis completada: urgency={report.urgency} "
            f"confidence={report.confidence:.2f} provider={report.provider_used}"
        )
        return report.urgency
    else:
        logger.error("[SEA] Synthesis falló — todos los proveedores caídos")
        return None


# ══════════════════════════════════════════════════════════════════════
# NEMESIS DAILY RESET
# ══════════════════════════════════════════════════════════════════════

def run_nemesis_reset():
    """Resetea contadores diarios de Nemesis a medianoche."""
    r = get_redis()

    keys_to_reset = [
        "kernell:nemesis:daily_loss_usd",
        "kernell:nemesis:daily_profit_usd",
        "kernell:nemesis:daily_trades_count",
        "kernell:nemesis:daily_winning_trades",
    ]

    for key in keys_to_reset:
        r.set(key, "0")

    logger.info("[SEA] Nemesis daily counters reset.")

    r.set("kernell:sea:last_nemesis_reset", json.dumps({
        "reset_at": datetime.now(timezone.utc).isoformat(),
        "keys_reset": keys_to_reset,
        "source": "chronos",
    }))


# ══════════════════════════════════════════════════════════════════════
# CLI ENTRYPOINT
# ══════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(description="SEA v2 Scheduler — Chronos Entrypoint")
    parser.add_argument("--svs", action="store_true", help="Run SVS v2 sectoral sweep")
    parser.add_argument("--gshi", action="store_true", help="Calculate GSHI v2 health index")
    parser.add_argument("--synthesis", action="store_true", help="Run Synthesis reasoning")
    parser.add_argument("--synthesis-trigger", default="scheduled", help="Synthesis trigger reason")
    parser.add_argument("--nemesis-reset", action="store_true", help="Reset Nemesis daily counters")
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    )

    # Add project root to path for imports
    project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    if project_root not in sys.path:
        sys.path.insert(0, project_root)

    if args.svs:
        run_svs_sweep()
    elif args.gshi:
        run_gshi_calculation()
    elif args.synthesis:
        run_synthesis(trigger=args.synthesis_trigger)
    elif args.nemesis_reset:
        run_nemesis_reset()
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
