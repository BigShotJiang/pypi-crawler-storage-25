"""
DRIFT ENGINE v13 — Saturated Drift Calculation
================================================
Correcciones sobre v12:
  1. tanh saturation — Drift nunca llega a 100 por diseño
  2. Hard weight limits — ningún factor domina (0.5x-1.7x base)
  3. Drift Acceleration — nueva métrica que mide velocidad de cambio

Fórmula:
  drift_raw = sum(w_final[i] * d[i]) * 100
  drift = tanh(drift_raw / 80) * 100   # Saturación suave

Weight limits:
  w_final[i] = clamp(w_dynamic[i], w_base[i]*0.5, w_base[i]*1.7)
"""

import math
import json
import logging
import redis
from datetime import datetime, timezone
from typing import Optional

logger = logging.getLogger("sea.drift_engine")

WEIGHT_MIN_MULTIPLIER = 0.5
WEIGHT_MAX_MULTIPLIER = 1.7
SATURATION_SCALE = 80.0  # Controla cuán rápido satura el tanh
ACCELERATION_WINDOW = 5  # Últimas N mediciones para calcular aceleración


class DriftEngineV13:
    """
    Motor de Drift v13 con saturación tanh y aceleración.
    
    Base weights (sum = 1.0):
      agent_state: 0.30
      resources:   0.15
      security:    0.25
      economy:     0.20
      timeline:    0.10
    """

    W_BASE = {
        "agent_state": 0.30,
        "resources":   0.15,
        "security":    0.25,
        "economy":     0.20,
        "timeline":    0.10,
    }

    def __init__(self, redis_client: redis.Redis):
        self.redis = redis_client
        self.alpha = 0.5   # Sensitivity for dynamic weights
        self.gamma = 0.6   # Smoothing factor
        self._historical_weights = dict(self.W_BASE)

    def calculate(
        self,
        d_agents: float,    # 0-1 agent distress
        d_resources: float,  # 0-1 resource distress
        d_security: float,   # 0-1 security distress
        d_economy: float,    # 0-1 economic distress
        d_timeline: float,   # 0-1 timeline distress
    ) -> float:
        """
        Calcula Drift Index con saturación tanh.
        Returns: float 0-100 (nunca llega a 100 exacto por tanh)
        """
        dimensions = {
            "agent_state": min(1.0, max(0.0, d_agents)),
            "resources":   min(1.0, max(0.0, d_resources)),
            "security":    min(1.0, max(0.0, d_security)),
            "economy":     min(1.0, max(0.0, d_economy)),
            "timeline":    min(1.0, max(0.0, d_timeline)),
        }

        # Dynamic weights: w = w_base + alpha * distress
        w_dynamic = {}
        for key in self.W_BASE:
            w_dynamic[key] = self.W_BASE[key] + (self.alpha * dimensions[key])

        # Normalize
        total = sum(w_dynamic.values())
        w_norm = {k: v / total for k, v in w_dynamic.items()}

        # Clamp to hard limits
        w_final = {}
        for key in w_norm:
            lo = self.W_BASE[key] * WEIGHT_MIN_MULTIPLIER
            hi = self.W_BASE[key] * WEIGHT_MAX_MULTIPLIER
            w_smoothed = (self.gamma * w_norm[key]) + ((1 - self.gamma) * self._historical_weights[key])
            w_final[key] = max(lo, min(hi, w_smoothed))
            self._historical_weights[key] = w_final[key]

        # Re-normalize after clamping
        total_final = sum(w_final.values())
        w_final = {k: v / total_final for k, v in w_final.items()}

        # Weighted sum
        drift_raw = sum(w_final[k] * dimensions[k] for k in w_final) * 100

        # tanh saturation: never reaches 100
        drift = math.tanh(drift_raw / SATURATION_SCALE) * 100
        drift = round(max(0.0, drift), 2)

        # Persist and calculate acceleration
        self._persist(drift)

        return drift

    def get_acceleration(self) -> float:
        """
        Drift Acceleration = delta entre últimas 2 mediciones.
        Positivo = drift subiendo. Negativo = mejorando.
        Alerta si |accel| > 25.
        """
        history = self.redis.lrange("kernell:drift:history", 0, ACCELERATION_WINDOW - 1)
        if len(history) < 2:
            return 0.0

        values = [float(json.loads(h).get("drift", 0)) for h in history]
        accel = values[0] - values[1]  # Más reciente - anterior

        self.redis.set("kernell:drift:acceleration", str(round(accel, 2)))
        return round(accel, 2)

    def _persist(self, drift: float):
        now = datetime.now(timezone.utc).isoformat()
        self.redis.set("kernell:drift:current_value", str(drift))
        self.redis.lpush("kernell:drift:history", json.dumps({
            "drift": drift,
            "timestamp": now,
        }))
        self.redis.ltrim("kernell:drift:history", 0, 49)

        # Determine mode signal
        if drift >= 80:
            mode = "CRITICAL"
        elif drift >= 60:
            mode = "STRESS"
        elif drift >= 35:
            mode = "TENSION"
        else:
            mode = "STABLE"

        self.redis.set("kernell:drift:mode_signal", mode)
