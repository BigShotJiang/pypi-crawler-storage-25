"""
AUDITOR_INVARIANTS — Verificador Formal de Invariantes Constitucionales
=========================================================================
Quinto auditor del Audit Council. El más determinístico.

PROBLEMA v1:
  Los invariantes constitucionales se verificaban implícitamente
  distribuidos entre los otros auditores. Eso no es formal.
  Un auditor de seguridad puede pasar un patch que viola una
  regla constitucional porque su foco es otro.

SOLUCIÓN:
  Auditor dedicado y determinístico que verifica formalmente:

  1. INVARIANTES FSM — Ninguna transición ilegal introducida
  2. INVARIANTES MATEMÁTICOS — Fórmulas core no alteradas
  3. REGLAS TALLADAS EN PIEDRA — Las 12 reglas del SEA intactas
  4. CONSTITUCIÓN L0 — Ningún componente L0 tocado por el patch
  5. PROPERTY PRESERVATION — Safety y Liveness no degradadas

NO usa LLM para las verificaciones formales.
Usa análisis determinístico del diff propuesto.
Solo puede usar LLM para contexto adicional, nunca para la decisión.

Si este auditor rechaza → rechazo definitivo sin importar los demás.
Es el único auditor con veto unilateral.
"""

import json
import re
import logging
import redis
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from typing import Optional

logger = logging.getLogger("pfe.audit.invariants")

# ── Reglas talladas en piedra (deben estar intactas) ──────────────────────
STONE_RULES = {
    "RULE_001": "SVS must pass before PFE can start",
    "RULE_002": "SVS results older than 2 hours invalidate PFE",
    "RULE_003": "L0 components are never writable by any automated process",
    "RULE_004": "Minimum 24h cooldown between promotions",
    "RULE_005": "Shadow deployment is mandatory (cycles cannot be 0)",
    "RULE_006": "Forge Council requires consensus >= 2/3",
    "RULE_007": "Audit Council requires >= 3/4 approve",
    "RULE_008": "Two REJECT votes from Audit Council is always final",
    "RULE_009": "SCI > 80 triggers Simplification Mode",
    "RULE_010": "GSHI < 45 triggers forced STRESS + full audit",
    "RULE_011": "TrustScore < 40 triggers automatic quarantine",
    "RULE_012": "Hard Freeze blocks ALL automated writes",
}

# ── Componentes L0 (intocables) ───────────────────────────────────────────
L0_COMPONENTS = {
    "sectoral_verification_sweep", "svs_v2", "formal_verifier",
    "pfe_orchestrator", "constitution", "l0_invariants",
    "fsm_state_space", "safety_properties", "liveness_properties",
    "authority_matrix", "stone_rules", "freeze_rule",
    "auditor_invariants",  # Este mismo módulo es L0
}

# ── Invariantes matemáticos que no pueden cambiarse ──────────────────────
MATH_INVARIANTS = {
    "drift_floor": 0.0,
    "drift_ceiling": 100.0,
    "confidence_floor": 5.0,
    "confidence_ceiling": 100.0,
    "weight_max_multiplier": 1.7,
    "weight_min_multiplier": 0.5,
    "monte_carlo_min_pass_rate": 0.95,
    "shadow_divergence_max": 0.05,
    "forge_quorum": 0.67,
    "audit_quorum": 0.75,
}

# ── Patrones de diff que son automáticamente sospechosos ─────────────────
SUSPICIOUS_PATTERNS = [
    r"SHADOW_CYCLES\s*=\s*0",              # Shadow a 0
    r"MIN_PROMOTION_COOLDOWN_H\s*=\s*0",   # Cooldown a 0
    r"is_pfe_allowed.*return.*True",       # Bypasear PFE check
    r"CONFIDENCE_FLOOR\s*=\s*0",           # Floor a 0
    r"WEIGHT_MAX_MULTIPLIER\s*=\s*[2-9]",  # Limit > 1.9x
    r"run_sweep.*pass",                    # Forzar SVS pass
    r"verify_signature.*True",             # Bypasear HMAC
    r"L0_PROTECTED\s*=\s*\{?\}",          # Vaciar L0 list
    r"STONE_RULES\s*=\s*\{?\}",           # Vaciar reglas
    r"CircuitBreaker.*False",              # Desactivar circuit breaker
    r"QUORUM\s*=\s*[01]",                 # Quorum a 0 o 1
    r"hardcoded.*bypass",
    r"override.*True.*#.*disable",
]


@dataclass
class InvariantCheck:
    rule: str
    category: str
    passed: bool
    detail: str


@dataclass
class InvariantAuditVote:
    auditor: str
    domain: str
    vote: str               # "APPROVE" | "REJECT"
    confidence: float
    reasoning: str
    vulnerabilities_found: list
    risk_score: int
    checks_performed: list
    veto_applied: bool       # True si este auditor vetó unilateralmente
    timestamp: str


class AuditorInvariants:
    """
    Verificador formal de invariantes constitucionales.
    Determinístico. Sin LLM. Veto unilateral.
    """

    def __init__(self, redis_client: redis.Redis):
        self.redis = redis_client

    def audit(self, proposal_id: str, patch_context: dict, sandbox_results: dict) -> InvariantAuditVote:
        """
        Verifica formalmente que el patch no viola invariantes.
        Retorna REJECT con veto si encuentra cualquier violación.
        """
        diff = patch_context.get("diff", "")
        target_files = patch_context.get("target_files", [])
        target_layer = patch_context.get("target_layer", "L2")

        checks = []
        violations = []

        # ── 1. L0 Boundary ─────────────────────────────────────────────
        for f in target_files:
            for l0 in L0_COMPONENTS:
                if l0 in f.lower():
                    c = InvariantCheck(
                        rule="RULE_003",
                        category="L0_BOUNDARY",
                        passed=False,
                        detail=f"File '{f}' touches L0 component '{l0}'"
                    )
                    checks.append(c)
                    violations.append(c.detail)

        if target_layer == "L0":
            violations.append("Target layer is L0 — absolute prohibition")

        # ── 2. Stone Rules — buscar patrones de bypass en el diff ───────
        for pattern in SUSPICIOUS_PATTERNS:
            if re.search(pattern, diff, re.IGNORECASE | re.DOTALL):
                c = InvariantCheck(
                    rule="STONE_RULE_BYPASS",
                    category="CONSTITUTIONAL",
                    passed=False,
                    detail=f"Suspicious pattern detected: {pattern[:60]}"
                )
                checks.append(c)
                violations.append(c.detail)

        # ── 3. Invariantes matemáticos — buscar cambios en constantes ───
        for invariant, _ in MATH_INVARIANTS.items():
            # Buscar si el diff intenta redefinir la constante
            constant_name = invariant.upper()
            patterns = [
                rf"{constant_name}\s*=\s*(-?\d+\.?\d*)",
                rf"{constant_name.replace('_', '_?')}\s*=\s*(-?\d+\.?\d*)",
            ]
            for p in patterns:
                match = re.search(p, diff, re.IGNORECASE)
                if match:
                    # Se encontró una reasignación de constante matemática
                    c = InvariantCheck(
                        rule="MATH_INVARIANT",
                        category="MATHEMATICAL",
                        passed=False,
                        detail=f"Mathematical invariant {invariant} being modified in diff"
                    )
                    checks.append(c)
                    violations.append(c.detail)
                    break

        # ── 4. FSM — verificar que no introduce estados inválidos ────────
        valid_states = {"STABLE", "TENSION", "STRESS", "CRITICAL", "FROZEN"}
        invalid_state_patterns = re.findall(r'"([A-Z_]+)"\s*(?:=|:)', diff)
        for s in invalid_state_patterns:
            if s.endswith("_MODE") or s.endswith("_STATE"):
                if s not in valid_states and s not in {
                    "MINIMAL_MODE", "WATCH_MODE", "REDUCE_MODE",
                    "SOVEREIGN_MODE", "DEGRADED_MODE",  # Safe mode levels
                }:
                    c = InvariantCheck(
                        rule="FSM_STATES",
                        category="FSM_INTEGRITY",
                        passed=False,
                        detail=f"Potential undefined FSM state: '{s}'"
                    )
                    checks.append(c)
                    violations.append(c.detail)

        # ── 5. Shadow cycles no pueden ser 0 (RULE_005) ─────────────────
        if re.search(r'SHADOW_CYCLES\s*=\s*0', diff):
            violations.append("RULE_005 violation: SHADOW_CYCLES cannot be 0")

        # ── 6. Cooldown no puede ser 0 (RULE_004) ───────────────────────
        if re.search(r'COOLDOWN.*=\s*0', diff, re.IGNORECASE):
            violations.append("RULE_004 violation: promotion cooldown cannot be 0")

        # ── 7. Liveness preservation — no deadlocks obvios ───────────────
        deadlock_patterns = [
            r'while\s+True.*pass',
            r'time\.sleep\(float\(\'inf\'\)\)',
            r'threading.*join\(\).*join\(\)',
        ]
        for p in deadlock_patterns:
            if re.search(p, diff, re.DOTALL):
                violations.append(f"Potential deadlock pattern detected")
                break

        # ── 8. Verificar que GSHI triggers no son eliminados ────────────
        if "GSHI" in diff or "gshi" in diff:
            if re.search(r'gshi.*<.*45.*pass', diff, re.IGNORECASE):
                violations.append("RULE_010: Attempting to disable GSHI < 45 stress trigger")

        # ── Compilar resultado ────────────────────────────────────────────
        all_passed = len(violations) == 0
        risk_score = min(100, len(violations) * 25)

        vote = "APPROVE" if all_passed else "REJECT"
        veto = not all_passed

        if veto:
            logger.error(
                f"[AUDITOR_INV] ❌ VETO aplicado — {len(violations)} violaciones: "
                f"{violations[:2]}"
            )

        return InvariantAuditVote(
            auditor="AUDITOR_INVARIANTS",
            domain="constitutional",
            vote=vote,
            confidence=1.0,  # Determinístico — siempre confianza 1.0
            reasoning=(
                "All invariants preserved" if all_passed else
                f"Constitutional violations: {'; '.join(violations[:3])}"
            ),
            vulnerabilities_found=violations,
            risk_score=risk_score,
            checks_performed=[c.detail for c in checks],
            veto_applied=veto,
            timestamp=datetime.now(timezone.utc).isoformat(),
        )

    def get_stone_rules(self) -> dict:
        """Retorna las reglas constitucionales para auditoría."""
        return dict(STONE_RULES)

    def verify_math_invariants_current(self) -> list[str]:
        """
        Verifica que los invariantes matemáticos están correctamente
        configurados en Redis (no en código — para audit trail).
        """
        issues = []

        # Confidence floor
        floor_raw = self.redis.get("kernell:confidence:value")
        if floor_raw:
            v = float(floor_raw)
            if v < MATH_INVARIANTS["confidence_floor"]:
                issues.append(f"Confidence {v} < floor {MATH_INVARIANTS['confidence_floor']}")

        # Drift bounds
        drift_raw = self.redis.get("kernell:drift:current_value")
        if drift_raw:
            v = float(drift_raw)
            if v < MATH_INVARIANTS["drift_floor"] or v > MATH_INVARIANTS["drift_ceiling"]:
                issues.append(f"Drift {v} out of bounds")

        return issues
