"""
METRICS ENGINE — Decoupled Atlas Metric Calculator
====================================================
Part of the Atlas decoupling architecture.
Calculates Drift and Confidence independently using
DriftEngineV13 and ConfidenceEngineV13.

Includes cross-validation against Overseer's independent metrics.
"""

import json
import logging
import redis
from typing import Optional

from core.sea.drift_engine import DriftEngineV13
from core.sea.confidence_engine import ConfidenceEngineV13

logger = logging.getLogger("sea.metrics_engine")

DIVERGENCE_THRESHOLD = 15.0  # Max acceptable diff between Atlas and Overseer


class MetricsEngine:
    """
    Independent metrics calculator for Atlas.
    Uses DriftEngineV13 + ConfidenceEngineV13 and validates
    against Overseer's independent calculations.
    """

    def __init__(self, redis_client: redis.Redis):
        self.redis = redis_client
        self.drift_engine = DriftEngineV13(redis_client)
        self.confidence_engine = ConfidenceEngineV13(redis_client)

    def calculate_all(
        self,
        d_agents: float,
        d_resources: float,
        d_security: float,
        d_economy: float,
        d_timeline: float,
        agent_consistency: float = 1.0,
    ) -> dict:
        """
        Calculate Drift, Confidence, and Drift Acceleration.
        Cross-validates against Overseer if available.
        
        Returns dict with: drift, confidence, acceleration, mode_signal,
                          overseer_validated, divergence
        """
        drift = self.drift_engine.calculate(
            d_agents, d_resources, d_security, d_economy, d_timeline
        )
        confidence = self.confidence_engine.calculate(drift, agent_consistency)
        acceleration = self.drift_engine.get_acceleration()

        # Determine mode signal
        if drift >= 80:
            mode = "CRITICAL"
        elif drift >= 60:
            mode = "STRESS"
        elif drift >= 35:
            mode = "TENSION"
        else:
            mode = "STABLE"

        # Cross-validate with Overseer's metrics
        validated, divergence = self._validate_against_overseer(drift, confidence)

        result = {
            "drift": drift,
            "confidence": confidence,
            "acceleration": acceleration,
            "mode_signal": mode,
            "overseer_validated": validated,
            "divergence": divergence,
        }

        self.redis.set("kernell:metrics:latest", json.dumps(result))
        return result

    def _validate_against_overseer(
        self, drift: float, confidence: float
    ) -> tuple[bool, float]:
        """
        Check if our metrics align with Overseer's independent calculation.
        Returns (validated, divergence).
        """
        try:
            overseer_raw = self.redis.get("kernell:overseer:metrics")
            if not overseer_raw:
                return True, 0.0  # No Overseer data, assume valid

            overseer = json.loads(overseer_raw)
            o_drift = float(overseer.get("drift", drift))
            o_confidence = float(overseer.get("confidence", confidence))

            drift_div = abs(drift - o_drift)
            conf_div = abs(confidence - o_confidence)
            max_div = max(drift_div, conf_div)

            if max_div > DIVERGENCE_THRESHOLD:
                logger.warning(
                    f"[METRICS] Divergence with Overseer: "
                    f"drift_diff={drift_div:.1f}, conf_diff={conf_div:.1f}"
                )
                self.redis.lpush("kernell:alerts:system", json.dumps({
                    "type": "metrics_divergence",
                    "atlas_drift": drift,
                    "overseer_drift": o_drift,
                    "atlas_confidence": confidence,
                    "overseer_confidence": o_confidence,
                    "divergence": max_div,
                }))
                return False, max_div

            return True, max_div

        except Exception as e:
            logger.debug(f"Overseer validation skipped: {e}")
            return True, 0.0
