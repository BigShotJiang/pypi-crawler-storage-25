"""
Principal Council v1 — Comité de deliberación en dos rondas.
=============================================================
El único comité de Kernell OS con rondas iterativas.
Ningún modelo vota sin haber leído los diagnósticos de los demás.

Ronda 1: Diagnóstico independiente por dimensión (4 modelos en paralelo)
Ronda 2: Refutación cruzada — cada modelo lee los 4 diagnósticos (paralelo)
Síntesis: Un modelo lee ronda 1 + ronda 2 y produce el veredicto final

Roles (mapped to llm_registry ROLE_CHAINS):
  ARCHITECT    → role="forge_proponent",    preferred=claude_sonnet
  ADVERSARIAL  → role="audit_adversarial",  preferred=openrouter_r1
  EVIDENCE     → role="salus_primary",      preferred=gemini_pro
  BENCHMARKER  → role="forge_minimalist",   preferred=gemini_flash
  SYNTHESIZER  → role="synthesis",          preferred=groq_r1
"""

import json
import logging
import os
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Optional

from dotenv import load_dotenv

_ROOT = Path(__file__).parent.parent
load_dotenv(_ROOT / ".env")
sys.path.insert(0, str(_ROOT))

logger = logging.getLogger("principal.council")

# Lazy-load the registry to avoid import failures during tests
_registry = None


def _get_registry():
    global _registry
    if _registry is not None:
        return _registry
    try:
        import redis as redis_lib
        from core.sea.llm_registry import LLMProviderRegistry

        pw = os.getenv("REDIS_PASSWORD", "").strip().strip("\"'") or None
        rc = redis_lib.Redis(
            host=os.getenv("REDIS_HOST", "127.0.0.1"),
            port=int(os.getenv("REDIS_PORT", 6379)),
            password=pw,
            decode_responses=True,
            socket_connect_timeout=5,
        )
        _registry = LLMProviderRegistry(rc)
        return _registry
    except Exception as e:
        logger.error(f"Cannot init LLMProviderRegistry: {e}")
        return None


# ── Role → llm_registry mapping ──────────────────────────────────────────
ROLE_CONFIG = {
    "ARCHITECT": {
        "role_chain": "forge_proponent",
        "preferred": "claude_sonnet",
        "temperature": 0.4,
    },
    "ADVERSARIAL": {
        "role_chain": "audit_adversarial",
        "preferred": "openrouter_r1",
        "temperature": 0.3,
    },
    "EVIDENCE": {
        "role_chain": "salus_primary",
        "preferred": "gemini_pro",
        "temperature": 0.1,
    },
    "BENCHMARKER": {
        "role_chain": "forge_minimalist",
        "preferred": "gemini_flash",
        "temperature": 0.5,
    },
    "SYNTHESIZER": {
        "role_chain": "synthesis",
        "preferred": "groq_r1",
        "temperature": 0.3,
    },
}

ALL_DIMS = [
    "governance", "security", "anti_hallucination", "memory_context",
    "code_audit", "resilience", "code_quality", "testing",
]

_EMPTY_SCORES = {d: 0 for d in ALL_DIMS}


# ── System prompts ────────────────────────────────────────────────────────

SYSTEM_PROMPTS_R1 = {
    "ARCHITECT": (
        "Eres un Principal Engineer evaluando la madurez sistémica de Kernell OS.\n"
        "Para cada dimensión asigna un score 0-100 con justificación basada SOLO en datos.\n"
        'Responde SOLO en JSON: {"scores": {"governance": N, "security": N, '
        '"anti_hallucination": N, "memory_context": N, "code_audit": N, '
        '"resilience": N, "code_quality": N, "testing": N}, '
        '"overall": N, "key_findings": ["f1","f2","f3"], "confidence": 0.0-1.0}'
    ),
    "ADVERSARIAL": (
        "Eres el crítico más severo de este sistema. Busca fallas graves.\n"
        "Asume problemas serios hasta que los datos demuestren lo contrario.\n"
        'Responde SOLO en JSON: {"scores": {...8 dims...}, "overall": N, '
        '"critical_failures": ["falla1","falla2"], "confidence": 0.0-1.0}'
    ),
    "EVIDENCE": (
        "Eres un auditor de evidencia. Ninguna afirmación sin dato.\n"
        "Si un score no tiene clave Redis o métrica real, es 0.\n"
        'Responde SOLO en JSON: {"scores": {...8 dims...}, "overall": N, '
        '"unsupported_claims": ["claim1"], "evidence_quality": "HIGH|MEDIUM|LOW", '
        '"confidence": 0.0-1.0}'
    ),
    "BENCHMARKER": (
        "Compara cada dimensión contra sistemas de IA en producción reales.\n"
        'Responde SOLO en JSON: {"scores": {...8 dims...}, "overall": N, '
        '"industry_comparisons": {"dim": "contexto"}, "confidence": 0.0-1.0}'
    ),
}

SYSTEM_PROMPT_R2 = (
    "Ronda 2 — Refutación cruzada.\n"
    "Has recibido los diagnósticos de 4 evaluadores de la Ronda 1.\n"
    "Identifica donde estás en desacuerdo y cita el evaluador que refutas.\n"
    'Responde SOLO en JSON: {"scores": {...8 dims...}, "overall": N, '
    '"refutations": [{"refutes": "ROLE", "claim": "...", '
    '"counter_evidence": "..."}], "confidence": 0.0-1.0}'
)

SYNTHESIS_PROMPT = (
    "Eres el árbitro final. Has recibido diagnósticos de Ronda 1 y "
    "refutaciones de Ronda 2.\n"
    "Produce el score final de madurez con razonamiento causal.\n"
    "Penaliza dimensiones con desacuerdo extremo entre evaluadores.\n\n"
    "Responde SOLO en JSON:\n"
    "{\n"
    '  "scores": {\n'
    '    "governance": {"score": N, "reasoning": "...", "evidence": "..."},\n'
    '    "security": {"score": N, "reasoning": "...", "evidence": "..."},\n'
    '    "anti_hallucination": {"score": N, "reasoning": "...", "evidence": "..."},\n'
    '    "memory_context": {"score": N, "reasoning": "...", "evidence": "..."},\n'
    '    "code_audit": {"score": N, "reasoning": "...", "evidence": "..."},\n'
    '    "resilience": {"score": N, "reasoning": "...", "evidence": "..."},\n'
    '    "code_quality": {"score": N, "reasoning": "...", "evidence": "..."},\n'
    '    "testing": {"score": N, "reasoning": "...", "evidence": "..."}\n'
    "  },\n"
    '  "overall_score": N,\n'
    '  "critical_issues": ["issue1"],\n'
    '  "immediate_actions": ["action1"],\n'
    '  "evaluator_agreement": "HIGH|MEDIUM|LOW",\n'
    '  "confidence": 0.0-1.0,\n'
    '  "synthesizer_note": "..."\n'
    "}"
)


# ── LLM call helper ──────────────────────────────────────────────────────

def _call_llm(
    role_name: str,
    system_prompt: str,
    user_prompt: str,
) -> dict:
    """
    Call a single LLM via llm_registry.complete().
    Returns parsed JSON dict or an error fallback.
    """
    registry = _get_registry()
    if registry is None:
        return {
            "scores": dict(_EMPTY_SCORES),
            "overall": 0,
            "confidence": 0.0,
            "error": "registry_unavailable",
        }

    cfg = ROLE_CONFIG.get(role_name, ROLE_CONFIG["BENCHMARKER"])

    try:
        resp = registry.complete(
            messages=[{"role": "user", "content": user_prompt}],
            system_prompt=system_prompt,
            role=cfg["role_chain"],
            preferred_provider=cfg["preferred"],
            max_tokens=1500,
            temperature=cfg["temperature"],
        )

        if resp is None:
            return {
                "scores": dict(_EMPTY_SCORES),
                "overall": 0,
                "confidence": 0.0,
                "error": "all_providers_failed",
            }

        # resp is an LLMResponse dataclass
        content = resp.content
        if not content:
            return {
                "scores": dict(_EMPTY_SCORES),
                "overall": 0,
                "confidence": 0.0,
                "error": "empty_response",
            }

        # Clean JSON from markdown fences
        clean = content.strip()
        if clean.startswith("```"):
            clean = clean.split("\n", 1)[-1]
        if clean.endswith("```"):
            clean = clean.rsplit("```", 1)[0]
        clean = clean.strip()

        # Find the JSON object
        start = clean.find("{")
        end = clean.rfind("}") + 1
        if start >= 0 and end > start:
            clean = clean[start:end]

        result = json.loads(clean)
        result["_provider"] = resp.provider_used
        result["_model"] = resp.model_used
        result["_latency_ms"] = resp.latency_ms
        result["_tokens"] = resp.tokens_used
        return result

    except json.JSONDecodeError as e:
        logger.warning(f"JSON parse error from {role_name}: {e}")
        return {
            "scores": dict(_EMPTY_SCORES),
            "overall": 0,
            "confidence": 0.0,
            "parse_error": str(e)[:100],
        }
    except Exception as e:
        logger.error(f"LLM error for {role_name}: {e}")
        return {
            "scores": dict(_EMPTY_SCORES),
            "overall": 0,
            "confidence": 0.0,
            "api_error": str(e)[:100],
        }


# ── Prompt builders ───────────────────────────────────────────────────────

def _build_evidence_prompt(evidence: dict) -> str:
    return (
        "## EVIDENCIA DEL SISTEMA (datos reales de Redis y filesystem)\n\n"
        f"```json\n{json.dumps(evidence, indent=2, ensure_ascii=False)[:6000]}\n```\n\n"
        "Basa tu evaluación EXCLUSIVAMENTE en estos datos. "
        "Si un dato es None o ausente, cuenta como evidencia negativa."
    )


def _build_r2_prompt(evidence: dict, r1_results: dict) -> str:
    r1_summary = json.dumps(
        {
            role: {
                "scores": r.get("scores", {}),
                "overall": r.get("overall", 0),
                "key_info": (
                    r.get("key_findings")
                    or r.get("critical_failures")
                    or r.get("unsupported_claims")
                    or r.get("industry_comparisons")
                    or []
                ),
            }
            for role, r in r1_results.items()
        },
        indent=2,
        ensure_ascii=False,
    )
    return (
        "## DIAGNÓSTICOS DE RONDA 1\n\n"
        f"```json\n{r1_summary[:4000]}\n```\n\n"
        "## EVIDENCIA ORIGINAL\n\n"
        f"```json\n{json.dumps(evidence, indent=2, ensure_ascii=False)[:3000]}\n```\n\n"
        "Produce tu refutación. Cita a qué evaluador refutas y con qué dato."
    )


def _build_synthesis_prompt(evidence: dict, r1: dict, r2: dict) -> str:
    r1_compact = json.dumps(
        {
            k: {"scores": v.get("scores", {}), "overall": v.get("overall", 0)}
            for k, v in r1.items()
        },
        indent=2,
    )
    r2_compact = json.dumps(
        {
            k: {
                "scores": v.get("scores", {}),
                "refutations": v.get("refutations", []),
            }
            for k, v in r2.items()
        },
        indent=2,
    )
    exec_sum = json.dumps(
        evidence.get("executive_summary", {}), indent=2,
    )
    return (
        "## RONDA 1 — DIAGNÓSTICOS INDEPENDIENTES\n\n"
        f"```json\n{r1_compact[:3000]}\n```\n\n"
        "## RONDA 2 — REFUTACIONES CRUZADAS\n\n"
        f"```json\n{r2_compact[:3000]}\n```\n\n"
        "## RESUMEN EJECUTIVO\n\n"
        f"```json\n{exec_sum}\n```\n\n"
        "Produce el score final. Sé honesto con la incertidumbre."
    )


# ── Council class ─────────────────────────────────────────────────────────

class PrincipalCouncil:
    """Comité de deliberación en dos rondas para madurez sistémica."""

    def deliberate(self, evidence: dict) -> dict:
        """
        Synchronous two-round deliberation.
        Uses ThreadPoolExecutor to parallelize LLM calls.
        """
        evidence_prompt = _build_evidence_prompt(evidence)

        # ── RONDA 1: Diagnóstico independiente (paralelo) ─────────────
        logger.info("Principal Council — Ronda 1: diagnóstico independiente")
        r1_roles = ["ARCHITECT", "ADVERSARIAL", "EVIDENCE", "BENCHMARKER"]
        r1_results = {}

        with ThreadPoolExecutor(max_workers=4) as pool:
            futures = {
                pool.submit(
                    _call_llm, role, SYSTEM_PROMPTS_R1[role], evidence_prompt
                ): role
                for role in r1_roles
            }
            for future in as_completed(futures):
                role = futures[future]
                try:
                    r1_results[role] = future.result()
                    logger.info(
                        f"  R1 {role}: overall="
                        f"{r1_results[role].get('overall', '?')}"
                    )
                except Exception as e:
                    logger.error(f"  R1 {role} failed: {e}")
                    r1_results[role] = {
                        "scores": dict(_EMPTY_SCORES),
                        "overall": 0,
                        "error": str(e),
                    }

        # ── RONDA 2: Refutación cruzada (paralelo, leen R1) ──────────
        logger.info("Principal Council — Ronda 2: refutación cruzada")
        r2_prompt = _build_r2_prompt(evidence, r1_results)
        r2_results = {}

        with ThreadPoolExecutor(max_workers=4) as pool:
            futures = {
                pool.submit(
                    _call_llm, role, SYSTEM_PROMPT_R2, r2_prompt
                ): role
                for role in r1_roles
            }
            for future in as_completed(futures):
                role = futures[future]
                try:
                    r2_results[role] = future.result()
                    refutations = r2_results[role].get("refutations", [])
                    logger.info(f"  R2 {role}: {len(refutations)} refutaciones")
                except Exception as e:
                    logger.error(f"  R2 {role} failed: {e}")
                    r2_results[role] = {
                        "scores": dict(_EMPTY_SCORES),
                        "refutations": [],
                        "error": str(e),
                    }

        # ── SÍNTESIS FINAL (SYNTHESIZER lee R1 + R2) ──────────────────
        logger.info("Principal Council — Síntesis final")
        synthesis_prompt = _build_synthesis_prompt(evidence, r1_results, r2_results)
        final = _call_llm("SYNTHESIZER", SYNTHESIS_PROMPT, synthesis_prompt)

        logger.info(
            f"Principal Council complete: overall={final.get('overall_score', '?')} "
            f"confidence={final.get('confidence', '?')}"
        )

        return {
            "round_1": r1_results,
            "round_2": r2_results,
            "synthesis": final,
            "deliberation_timestamp": time.time(),
            "council_version": "v1",
        }
