"""
PFE ORCHESTRATOR — Patch-Forge-Evaluate Pipeline
===================================================
Full pipeline for autonomous code evolution:

   PatchProposal → ForgeCouncil (3 models) → AuditCouncil (5 models + veto)
                                            → PFE Report (persistent, auditable)

When Kernell (Antigravity) is ONLINE:
  - Forge proponent uses claude_opus (extended thinking)
  - Deeper reasoning traces captured

When Kernell is OFFLINE:
  - Forge proponent uses best free model (groq_r1)
  - Fully autonomous operation continues

All reports are persisted to Redis (kernell:pfe:reports, kernell:pfe:events).
"""

import json
import logging
import redis
from dataclasses import dataclass, asdict, field
from datetime import datetime, timezone
from typing import Optional

from core.sea.forge_council_v3 import ForgeCouncilV3, ProposalVerdict
from core.sea.audit_council_v2 import AuditCouncilV2, AuditReport

logger = logging.getLogger("kernell.pfe.orchestrator")


# ── Proposal definition ──────────────────────────────────────────────────

@dataclass
class PatchProposal:
    """Standardized proposal format for the PFE pipeline."""
    proposal_id: str
    title: str
    description: str
    author: str                     # agent name that created the proposal
    target_layer: str               # "L0" | "L1" | "L2" | "L3"
    target_files: list[str]
    proposed_diff: str
    estimated_risk: int             # 0-100
    impact_fsm: str                 # e.g. "no_change" | "state_transition"
    impact_invariants: str          # e.g. "none" | "modifies_SCI"


@dataclass
class PFEReport:
    """Unified report from the complete PFE pipeline."""
    proposal_id: str
    timestamp: str
    proposal_title: str
    proposal_author: str

    # Stage 1: Forge Council
    forge_decision: str             # "APPROVED" | "REJECTED" | "NEEDS_REVISION"
    forge_consensus: float          # 0.0-1.0
    forge_votes: list[dict]
    forge_reasoning_traces: dict
    forge_kernell_online: bool      # was Opus used?

    # Stage 2: Audit Council (only if Forge approved)
    audit_executed: bool
    audit_decision: Optional[str]   # "APPROVED" | "REJECTED" | None
    audit_risk: Optional[int]       # 0-100
    audit_veto: bool
    audit_findings: list[str]
    audit_reasoning_traces: dict

    # Final
    final_decision: str             # "APPROVED" | "REJECTED" | "FORGE_REJECTED"
    pipeline_stages: list[str]      # ["forge", "audit"] or ["forge"]
    total_models_used: int
    total_reasoning_traces: int


class PFEOrchestrator:
    """
    Orchestrates the full Patch-Forge-Evaluate pipeline.

    Usage:
        orch = PFEOrchestrator(redis_client)
        report = orch.evaluate(proposal)
    """

    def __init__(self, redis_client: redis.Redis):
        self.redis  = redis_client
        self.forge  = ForgeCouncilV3(redis_client)
        self.audit  = AuditCouncilV2(redis_client)

    def evaluate(self, proposal: PatchProposal) -> PFEReport:
        """
        Full PFE pipeline:
        1. Forge Council debates (3 perspectives, Opus if Kernell online)
        2. If APPROVED → Audit Council reviews (5 auditors + invariant veto)
        3. Generate unified PFE Report → persist to Redis
        """
        logger.info(f"[PFE] ═══ Pipeline started: '{proposal.title}' by {proposal.author} ═══")

        # ── Stage 1: Forge Council ──────────────────────────────────
        from core.sea.llm_registry import is_kernell_online
        kernell_online = is_kernell_online(self.redis)

        forge_verdict = self.forge.debate(proposal)

        logger.info(
            f"[PFE] Forge: {forge_verdict.final_decision} "
            f"(consensus={forge_verdict.consensus_strength}, "
            f"opus={'YES' if kernell_online else 'NO'})"
        )

        # ── Stage 2: Audit Council (only if Forge approved) ─────────
        audit_executed = False
        audit_report: Optional[AuditReport] = None

        if forge_verdict.final_decision == "APPROVED":
            logger.info("[PFE] Forge APPROVED → entering Audit Council")
            try:
                audit_report = self.audit.audit(
                    proposal_id=proposal.proposal_id,
                    patch_context={
                        "title":          proposal.title,
                        "description":    proposal.description,
                        "diff":           proposal.proposed_diff,
                        "target_files":   proposal.target_files,
                        "target_layer":   proposal.target_layer,
                        "estimated_risk": proposal.estimated_risk,
                        "author":         proposal.author,
                    },
                    sandbox_results={
                        "tests_passed":   True,
                        "runtime_errors": [],
                        "coverage_delta": 0,
                    },
                )
                audit_executed = True
                logger.info(
                    f"[PFE] Audit: {audit_report.final_decision} "
                    f"(risk={audit_report.aggregate_risk}, veto={audit_report.veto_applied})"
                )
            except Exception as e:
                logger.error(f"[PFE] Audit Council error: {e}")
                audit_executed = False

        # ── Build PFE Report ────────────────────────────────────────
        if forge_verdict.final_decision != "APPROVED":
            final = "FORGE_REJECTED"
        elif audit_report and audit_report.final_decision == "APPROVED":
            final = "APPROVED"
        else:
            final = "REJECTED"

        all_traces = dict(forge_verdict.reasoning_traces)
        audit_traces = {}
        audit_findings = []
        if audit_report:
            audit_traces = audit_report.reasoning_traces
            all_traces.update(audit_traces)
            audit_findings = audit_report.critical_findings

        report = PFEReport(
            proposal_id=proposal.proposal_id,
            timestamp=datetime.now(timezone.utc).isoformat(),
            proposal_title=proposal.title,
            proposal_author=proposal.author,
            forge_decision=forge_verdict.final_decision,
            forge_consensus=forge_verdict.consensus_strength,
            forge_votes=forge_verdict.votes,
            forge_reasoning_traces=forge_verdict.reasoning_traces,
            forge_kernell_online=kernell_online,
            audit_executed=audit_executed,
            audit_decision=audit_report.final_decision if audit_report else None,
            audit_risk=audit_report.aggregate_risk if audit_report else None,
            audit_veto=audit_report.veto_applied if audit_report else False,
            audit_findings=audit_findings,
            audit_reasoning_traces=audit_traces,
            final_decision=final,
            pipeline_stages=["forge", "audit"] if audit_executed else ["forge"],
            total_models_used=len(forge_verdict.votes) + (len(audit_report.votes) if audit_report else 0),
            total_reasoning_traces=len(all_traces),
        )

        self._persist(report)

        logger.info(
            f"[PFE] ═══ Pipeline complete: {final} | "
            f"{report.total_models_used} models | "
            f"{report.total_reasoning_traces} traces ═══"
        )
        return report

    def _persist(self, report: PFEReport):
        """Persist report to Redis for dashboard and audit trail."""
        try:
            report_data = asdict(report)
            # Full report
            self.redis.hset("kernell:pfe:reports", report.proposal_id, json.dumps(report_data))

            # Event stream (for dashboard live feed)
            event = {
                "type":       "pfe_complete",
                "proposal_id": report.proposal_id,
                "title":      report.proposal_title,
                "author":     report.proposal_author,
                "decision":   report.final_decision,
                "stages":     report.pipeline_stages,
                "models":     report.total_models_used,
                "traces":     report.total_reasoning_traces,
                "opus_used":  report.forge_kernell_online,
                "timestamp":  report.timestamp,
            }
            self.redis.lpush("kernell:pfe:events", json.dumps(event))
            self.redis.ltrim("kernell:pfe:events", 0, 99)

            # Publish for real-time subscribers
            self.redis.publish("kernell:pfe:live", json.dumps(event))

            logger.info(f"[PFE] Report persisted: {report.proposal_id}")
        except Exception as e:
            logger.error(f"[PFE] Persist error: {e}")

    def get_recent_reports(self, count: int = 10) -> list[dict]:
        """Fetch recent PFE events for dashboard display."""
        try:
            raw = self.redis.lrange("kernell:pfe:events", 0, count - 1)
            return [json.loads(r) for r in raw] if raw else []
        except Exception:
            return []

    def get_report(self, proposal_id: str) -> Optional[dict]:
        """Fetch a specific full report."""
        try:
            raw = self.redis.hget("kernell:pfe:reports", proposal_id)
            return json.loads(raw) if raw else None
        except Exception:
            return None
