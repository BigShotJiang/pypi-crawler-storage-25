"""
LLM TOKEN SCHEDULER — AIOS-Inspired Priority Queue
=====================================================
Cola de prioridad centralizada para peticiones LLM.

Problema:
  Múltiples agentes llaman a llm_registry.complete() de forma concurrente.
  Con rate limits (Groq free tier = 30 req/min), esto causa 429 y cascadas.

Solución:
  - Serializa peticiones por provider con semáforo configurable
  - Prioriza agentes críticos (Nemesis trading > Herald contenido)
  - Publica telemetría: profundidad de cola, latencia de espera, by-agent
  - Fail-closed: si la cola está llena, rechaza con error inmediato

Fallback:
  Si KERNELL_LLM_SCHEDULER_ENABLED=0, scheduled_complete() es un proxy
  directo a complete(). Cero overhead.

Integration:
  - llm_registry.py: nuevo método scheduled_complete()
  - Agentes migran gradualmente de complete() a scheduled_complete()
  - Telemetría Redis: kernell:llm:scheduler:*
"""

from __future__ import annotations

import json
import logging
import os
import threading
import time
from dataclasses import dataclass, field
from queue import PriorityQueue, Full, Empty
from typing import Any, Optional

logger = logging.getLogger("kernell.llm.scheduler")

# ── Config ────────────────────────────────────────────────────────────────────

SCHEDULER_ENABLED = os.getenv("KERNELL_LLM_SCHEDULER_ENABLED", "0").strip() in ("1", "true", "yes")
MAX_CONCURRENT = int(os.getenv("KERNELL_LLM_SCHEDULER_MAX_CONCURRENT", "3"))
MAX_QUEUE_DEPTH = int(os.getenv("KERNELL_LLM_SCHEDULER_MAX_QUEUE_DEPTH", "50"))

# Priority map: lower number = higher priority
PRIORITY_MAP = {
    "nemesis":    1,   # Trading = dinero real
    "sentinel":   2,   # Seguridad
    "atlas":      3,   # Gobernanza
    "forge":      4,   # Desarrollo
    "synthesis":  5,   # Análisis
    "economy":    6,   # Economía
    "overseer":   6,   # Supervisión
    "herald":     7,   # Contenido
    "bounty":     7,   # Caza de bugs
    "scribe":     8,   # Documentación
    "fallback":   9,   # Cualquier otro
}


# ── Data Models ───────────────────────────────────────────────────────────────

@dataclass(order=True)
class LLMRequest:
    """Petición LLM encolable con prioridad."""
    priority: int = field(compare=True)
    enqueued_at: float = field(compare=True)
    agent_name: str = field(compare=False)
    messages: list = field(compare=False)
    system_prompt: str = field(compare=False, default="")
    role: str = field(compare=False, default="fallback_any")
    preferred_provider: Optional[str] = field(compare=False, default=None)
    max_tokens: int = field(compare=False, default=1500)
    temperature: float = field(compare=False, default=0.3)
    # Internal: result delivery
    _result_event: threading.Event = field(compare=False, default_factory=threading.Event, repr=False)
    _result: Any = field(compare=False, default=None, repr=False)
    _error: Optional[str] = field(compare=False, default=None, repr=False)


class LLMScheduler:
    """
    Cola de prioridad threadsafe para peticiones LLM.
    Workers toman peticiones de la cola y llaman a registry.complete().
    """

    def __init__(self, registry, redis_client=None):
        self._registry = registry
        self._redis = redis_client
        self._queue: PriorityQueue = PriorityQueue(maxsize=MAX_QUEUE_DEPTH)
        self._semaphore = threading.Semaphore(MAX_CONCURRENT)
        self._workers: list[threading.Thread] = []
        self._running = False
        self._stats = {
            "submitted": 0,
            "completed": 0,
            "rejected": 0,
            "errors": 0,
            "total_wait_ms": 0,
            "by_agent": {},
            "by_priority": {},
        }
        self._lock = threading.Lock()

        if SCHEDULER_ENABLED:
            self.start()

    def start(self):
        """Arranca workers de procesamiento."""
        if self._running:
            return
        self._running = True
        for i in range(MAX_CONCURRENT):
            t = threading.Thread(
                target=self._worker_loop,
                name=f"llm-sched-{i}",
                daemon=True,
            )
            t.start()
            self._workers.append(t)
        logger.info(
            f"[SCHEDULER] Started with {MAX_CONCURRENT} workers, "
            f"max_queue={MAX_QUEUE_DEPTH}"
        )

    def stop(self):
        """Detiene workers."""
        self._running = False

    def submit(
        self,
        messages: list[dict],
        system_prompt: str = "",
        role: str = "fallback_any",
        agent_name: str = "unknown",
        preferred_provider: Optional[str] = None,
        max_tokens: int = 1500,
        temperature: float = 0.3,
        timeout_s: float = 120.0,
    ) -> Any:
        """
        Encola una petición LLM y espera resultado.
        Bloquea hasta que el worker la procese o timeout.

        Args:
            agent_name: Nombre del agente para prioridad
            timeout_s: Tiempo máximo de espera (cola + ejecución)

        Returns:
            LLMResponse o None si timeout/error

        Raises:
            RuntimeError: Si la cola está llena
        """
        if not SCHEDULER_ENABLED or not self._running:
            # Bypass: llamada directa sin scheduler
            return self._registry.complete(
                messages=messages,
                system_prompt=system_prompt,
                role=role,
                preferred_provider=preferred_provider,
                max_tokens=max_tokens,
                temperature=temperature,
            )

        priority = PRIORITY_MAP.get(agent_name, PRIORITY_MAP.get("fallback", 9))

        request = LLMRequest(
            priority=priority,
            enqueued_at=time.time(),
            agent_name=agent_name,
            messages=messages,
            system_prompt=system_prompt,
            role=role,
            preferred_provider=preferred_provider,
            max_tokens=max_tokens,
            temperature=temperature,
        )

        try:
            self._queue.put_nowait(request)
        except Full:
            with self._lock:
                self._stats["rejected"] += 1
            self._publish_stats()
            logger.warning(
                f"[SCHEDULER] Queue full ({MAX_QUEUE_DEPTH}) — "
                f"rejecting request from {agent_name}"
            )
            # Fallback: bypass queue, direct call
            return self._registry.complete(
                messages=messages,
                system_prompt=system_prompt,
                role=role,
                preferred_provider=preferred_provider,
                max_tokens=max_tokens,
                temperature=temperature,
            )

        with self._lock:
            self._stats["submitted"] += 1
            self._stats["by_agent"][agent_name] = (
                self._stats["by_agent"].get(agent_name, 0) + 1
            )
            self._stats["by_priority"][str(priority)] = (
                self._stats["by_priority"].get(str(priority), 0) + 1
            )

        self._publish_stats()

        # Esperar resultado
        if request._result_event.wait(timeout=timeout_s):
            if request._error:
                logger.warning(f"[SCHEDULER] Request for {agent_name} failed: {request._error}")
                return None
            return request._result
        else:
            logger.warning(f"[SCHEDULER] Timeout ({timeout_s}s) for {agent_name}")
            return None

    def _worker_loop(self):
        """Worker que procesa peticiones de la cola."""
        while self._running:
            try:
                request = self._queue.get(timeout=1.0)
            except Empty:
                continue

            wait_ms = (time.time() - request.enqueued_at) * 1000

            try:
                result = self._registry.complete(
                    messages=request.messages,
                    system_prompt=request.system_prompt,
                    role=request.role,
                    preferred_provider=request.preferred_provider,
                    max_tokens=request.max_tokens,
                    temperature=request.temperature,
                )
                request._result = result
                with self._lock:
                    self._stats["completed"] += 1
                    self._stats["total_wait_ms"] += wait_ms

            except Exception as e:
                request._error = str(e)
                with self._lock:
                    self._stats["errors"] += 1
                logger.error(f"[SCHEDULER] Worker error for {request.agent_name}: {e}")

            finally:
                request._result_event.set()
                self._queue.task_done()
                self._publish_stats()

    # ── Telemetry ─────────────────────────────────────────────────────────

    def _publish_stats(self):
        """Publica estadísticas en Redis."""
        if not self._redis:
            return
        try:
            with self._lock:
                completed = self._stats["completed"] or 1
                avg_wait = self._stats["total_wait_ms"] / completed

            self._redis.set("kernell:llm:scheduler:enabled", "1", ex=300)
            self._redis.set(
                "kernell:llm:scheduler:queue_depth",
                str(self._queue.qsize()),
                ex=60,
            )
            self._redis.set(
                "kernell:llm:scheduler:processed",
                str(self._stats["completed"]),
                ex=86400,
            )
            self._redis.set(
                "kernell:llm:scheduler:avg_wait_ms",
                str(round(avg_wait, 1)),
                ex=300,
            )

            with self._lock:
                if self._stats["by_agent"]:
                    self._redis.hset(
                        "kernell:llm:scheduler:by_agent",
                        mapping=self._stats["by_agent"],
                    )
                    self._redis.expire("kernell:llm:scheduler:by_agent", 86400)
        except Exception as e:
            logger.debug(f"[SCHEDULER] Stats publish error: {e}")

    @property
    def stats(self) -> dict:
        with self._lock:
            return {
                **self._stats,
                "queue_depth": self._queue.qsize(),
                "enabled": SCHEDULER_ENABLED and self._running,
                "max_concurrent": MAX_CONCURRENT,
                "max_queue_depth": MAX_QUEUE_DEPTH,
            }

    @property
    def queue_depth(self) -> int:
        return self._queue.qsize()
