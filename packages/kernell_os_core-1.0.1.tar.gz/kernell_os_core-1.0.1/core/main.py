from core.sea.kernell_os import KernellOS
import sys
import argparse
import time

def print_step(icon, title, detail, delay=1.0):
    print(f"\033[1m{icon} {title}\033[0m")
    time.sleep(0.3)
    print(f"   \033[90m{detail}\033[0m")
    time.sleep(delay)

def run_pro_demo():
    print("\n\033[1;36mBooting Kernell OS Runtime Environment...\033[0m")
    time.sleep(1.5)
    print("\033[90m[System] Authenticating license...\033[0m")
    time.sleep(0.5)
    print("\033[90m[System] License verified: Enterprise Tier\033[0m\n")
    time.sleep(1)

    print_step("🏦", "[Ledger] Initializing Economic Engine", "Funds reserved for session: 100.00 KERN", 1.2)
    print_step("🤖", "[Nexus] Orchestration layer active", "Awaiting incoming task payload...", 1.5)

    print("\n\033[1;33m>>> Incoming Task: 'Analyze market volatility and execute delta-neutral hedge'\033[0m\n")
    time.sleep(2)

    print_step("🧭", "[Nexus] Task Classification & Routing", "Decomposing task. Routing to -> agent.nemesis (Finance)", 1.8)
    print_step("🔒", "[Sentinel] Pre-flight Security Check", "Validating execution boundaries. AST bash injection guard: CLEAR.", 1.2)
    print_step("💰", "[Ledger] Transaction Lock", "HOLD applied: 0.05 KERN (Authorized for Nemesis)", 1.5)
    
    print_step("⚙️", "[Nemesis] Executing Strategy", "Fetching order book. Calculating delta. Submitting limit orders...", 2.5)
    
    print_step("✅", "[OVV] Output Verification", "Post-flight validation passed. Execution constraints respected.", 1.0)
    print_step("🧾", "[Ledger] Settlement", "CAPTURE applied: 0.042 KERN. Release: 0.008 KERN. Balance: 99.958 KERN", 1.2)

    print("\n\033[1;32m🏁 Session Completed Deterministically.\033[0m")
    print("\033[90mTotal Execution Time: 842ms | Compliance Trail: Logged | Risk Surface: 0\033[0m\n")

def main():
    parser = argparse.ArgumentParser(description="Kernell OS - Real-Time Financial Control for Compute")
    parser.add_argument("--demo", action="store_true", help="Run the full system demo")
    parser.add_argument("--start", action="store_true", help="Start the Kernell OS core runtime")
    
    args = parser.parse_args()
    
    if args.demo:
        run_pro_demo()
        sys.exit(0)
        
    if args.start:
        print("\033[1;36mBooting Kernell OS Core...\033[0m")
        # In a real scenario, we initialize the orchestrator and block
        os_instance = KernellOS()
        # os_instance.boot()
        print("Kernell OS is running. Press Ctrl+C to exit.")
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print("\nShutting down safely...")
        sys.exit(0)

    parser.print_help()

if __name__ == "__main__":
    main()
