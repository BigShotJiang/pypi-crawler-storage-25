"""
ResilienceEngine — Kernell OS
═══════════════════════════════════════════════════════════════
Orchestrates system resilience: circuit breakers, chaos tests,
health monitoring, and automatic recovery.

Components integrated:
  - CircuitBreakerRegistry (core/circuit_breaker.py)
  - ChaosDaemon (agents/core/chaos_daemon.py)
  - Health Tree (core/health/health_tree.py)

Provides:
  - get_system_resilience_index() → SRI score (0-100)
  - get_circuit_breaker_status() → all circuit breaker states
  - trigger_chaos_test(experiment) → run chaos experiment safely
  - check_and_recover() → auto-recover failed components
  - get_resilience_report() → full resilience snapshot
"""

import json
import time
import logging
import os
from typing import Any, Dict, List, Optional

log = logging.getLogger("ResilienceEngine")


class ResilienceEngine:
    """
    Unified resilience facade — combines circuit breakers, chaos testing,
    and health monitoring into a single query/control interface.
    """

    def __init__(self, redis_client):
        self.redis = redis_client

        # Lazy-load components
        self._cb_registry = None
        self._chaos_daemon = None

        self._init_components()

    def _init_components(self):
        """Gracefully load resilience components."""
        try:
            from core.circuit_breaker import CircuitBreakerRegistry
            self._cb_registry = CircuitBreakerRegistry(self.redis)
            log.info("ResilienceEngine: CircuitBreakerRegistry loaded")
        except ImportError:
            log.warning("ResilienceEngine: CircuitBreakerRegistry not available")

        try:
            from agents.core.chaos_daemon import ChaosDaemon
            self._chaos_daemon = ChaosDaemon(redis_client=self.redis)
            log.info("ResilienceEngine: ChaosDaemon loaded")
        except ImportError:
            log.warning("ResilienceEngine: ChaosDaemon not available")

    # ── System Resilience Index ───────────────────────────────

    def get_system_resilience_index(self) -> Dict[str, Any]:
        """
        Calculate SRI (System Resilience Index) from:
          - Circuit breaker health (open = bad)
          - Agent heartbeat freshness
          - DEFCON level
          - Chaos experiment results
        Returns dict with score (0-100) and breakdown.
        """
        scores = {}

        # 1. Circuit Breaker Score (50% weight)
        cb_status = self.get_circuit_breaker_status()
        total_cb = max(len(cb_status), 1)
        healthy_cb = sum(1 for cb in cb_status.values()
                         if cb.get("state") == "closed")
        scores["circuit_breakers"] = round(healthy_cb / total_cb * 100)

        # 2. DEFCON Score (30% weight)
        defcon = int(self.redis.get("kernell:system:defcon") or "3")
        defcon_scores = {1: 0, 2: 30, 3: 70, 4: 90, 5: 100}
        scores["defcon"] = defcon_scores.get(defcon, 50)

        # 3. Kill Switch Score (20% weight)
        kill_sw = self.redis.get("kernell:economy:kill_switch") == "true"
        paused = self.redis.get("kernell:system:paused") == "true"
        scores["control"] = 0 if kill_sw else (50 if paused else 100)

        # Weighted SRI
        sri = round(
            scores["circuit_breakers"] * 0.5 +
            scores["defcon"] * 0.3 +
            scores["control"] * 0.2
        )

        return {
            "sri": sri,
            "status": "healthy" if sri >= 70 else "degraded" if sri >= 40 else "critical",
            "breakdown": scores,
            "defcon": defcon,
            "ts": time.time(),
        }

    # ── Circuit Breakers ──────────────────────────────────────

    def get_circuit_breaker_status(self) -> Dict[str, Dict]:
        """Get all circuit breaker states from Redis."""
        status = {}
        try:
            cb_keys = self.redis.keys("kernell:circuit_breaker:*")
            for key in cb_keys:
                name = key.split(":")[-1] if isinstance(key, str) else key.decode().split(":")[-1]
                raw = self.redis.get(key)
                if raw:
                    try:
                        status[name] = json.loads(raw)
                    except (json.JSONDecodeError, TypeError):
                        status[name] = {"state": str(raw), "provider": name}
        except Exception as e:
            log.error(f"Failed to read circuit breakers: {e}")
        return status

    def reset_circuit_breaker(self, provider: str) -> bool:
        """Manually reset a circuit breaker to closed state."""
        try:
            key = f"kernell:circuit_breaker:{provider}"
            self.redis.set(key, json.dumps({
                "state": "closed",
                "failures": 0,
                "reset_at": time.time(),
                "reset_by": "resilience_engine",
            }))
            log.info(f"Circuit breaker reset: {provider}")
            return True
        except Exception as e:
            log.error(f"Failed to reset CB {provider}: {e}")
            return False

    # ── Chaos Testing ─────────────────────────────────────────

    def trigger_chaos_test(self, experiment: str = "heartbeat_stall",
                           target: Optional[str] = None) -> Dict[str, Any]:
        """
        Trigger a chaos experiment safely.
        Experiments: agent_kill, redis_latency, drift_spike, heartbeat_stall, memory_pressure
        """
        # Safety: refuse if DEFCON <= 2
        defcon = int(self.redis.get("kernell:system:defcon") or "3")
        if defcon <= 2:
            return {"status": "refused", "reason": f"DEFCON {defcon} — chaos disabled"}

        # Safety: refuse if kill switch active
        if self.redis.get("kernell:chaos:kill_switch") == "1":
            return {"status": "refused", "reason": "Chaos kill switch active"}

        if self._chaos_daemon:
            try:
                result = self._chaos_daemon.run_experiment(experiment, target=target)
                return {"status": "executed", "experiment": experiment, "result": result}
            except Exception as e:
                return {"status": "error", "error": str(e)}

        return {"status": "unavailable", "reason": "ChaosDaemon not loaded"}

    def get_chaos_history(self, limit: int = 10) -> List[Dict]:
        """Get recent chaos experiment results."""
        try:
            raw = self.redis.lrange("kernell:chaos:history", 0, limit - 1)
            return [json.loads(r) for r in raw]
        except Exception:
            return []

    # ── Auto-Recovery ─────────────────────────────────────────

    def check_and_recover(self) -> Dict[str, Any]:
        """
        Check for recoverable failures and attempt auto-recovery.
        Currently handles:
          - Open circuit breakers past their reset timeout
          - Stale chaos experiments
        """
        recovered = []

        # 1. Auto-reset expired circuit breakers
        for provider, status in self.get_circuit_breaker_status().items():
            if status.get("state") == "open":
                opened_at = status.get("opened_at", 0)
                reset_after = status.get("reset_seconds", 600)
                if time.time() - opened_at > reset_after:
                    self.reset_circuit_breaker(provider)
                    recovered.append(f"CB:{provider}")

        # 2. Clean stale chaos experiments
        active = self.redis.get("kernell:chaos:active")
        if active:
            try:
                exp = json.loads(active)
                if time.time() - exp.get("started_at", 0) > exp.get("ttl", 300):
                    self.redis.delete("kernell:chaos:active")
                    recovered.append("chaos:stale_experiment")
            except Exception:
                pass

        return {
            "recovered": recovered,
            "count": len(recovered),
            "ts": time.time(),
        }

    # ── Full Report ───────────────────────────────────────────

    def get_resilience_report(self) -> Dict[str, Any]:
        """Full resilience snapshot: SRI + circuit breakers + chaos history."""
        return {
            "sri": self.get_system_resilience_index(),
            "circuit_breakers": self.get_circuit_breaker_status(),
            "chaos_history": self.get_chaos_history(5),
            "auto_recovery": self.check_and_recover(),
        }


def publish_hourly_report() -> Dict[str, Any]:
    """
    Chronos entrypoint.
    Publica snapshot de resiliencia en Redis y devuelve el reporte.
    """
    try:
        import redis

        host = os.getenv("REDIS_HOST", "127.0.0.1")
        port = int(os.getenv("REDIS_PORT", "6380"))
        password = os.getenv("REDIS_PASSWORD", "").strip().strip("\"'") or None
        r = redis.Redis(host=host, port=port, password=password, decode_responses=True, socket_connect_timeout=5)
        engine = ResilienceEngine(r)
        report = engine.get_resilience_report()
        r.set("kernell:resilience:hourly_report", json.dumps(report), ex=86400)
        return report
    except Exception as e:
        log.error(f"publish_hourly_report failed: {e}")
        return {"ok": False, "error": str(e), "ts": time.time()}
