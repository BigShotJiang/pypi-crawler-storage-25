"""
Revenue Max — pipeline transversal Trading · Dropshipping · Marketing.

Orquesta lecturas de Redis, profit gates y despacho prudente de tareas a
nemesis/economy/hunter/ads vía colas existentes. No sustituye a los agentes;
coordina y audita.
"""

from core.revenue_max.hooks import safe_emit
from core.revenue_max.pipeline import RevenueMaxPipeline, run_revenue_pipeline_tick, emit_manual

__all__ = [
    "RevenueMaxPipeline",
    "run_revenue_pipeline_tick",
    "emit_manual",
    "safe_emit",
]
