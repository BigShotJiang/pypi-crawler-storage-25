"""
Orquestador de máximo nivel para los tres pilares + profit gates.

Ejecutar desde Chronos (task_type=revenue_max_tick) o:
  python3 -c "from core.revenue_max.pipeline import run_revenue_pipeline_tick; run_revenue_pipeline_tick()"
"""

from __future__ import annotations

import json
import logging
import os
import time
import uuid
from dataclasses import asdict, dataclass
from enum import Enum
from typing import Any, Optional

logger = logging.getLogger("kernell.revenue_max")

REDIS_EVENTS = "kernell:revenue:pipeline:events"
REDIS_METRICS = "kernell:revenue:pipeline:metrics"
REDIS_LAST_TICK = "kernell:revenue:pipeline:last_tick"
REDIS_LAST_FINANCE = "kernell:revenue:pipeline:last_finance_sync"
REDIS_CONFIG = "kernell:revenue:pipeline:config"


class Pillar(str, Enum):
    TRADING = "trading"
    DROPSHIP = "dropshipping"
    MARKETING = "marketing"
    GOVERNANCE = "governance"


@dataclass
class PipelineEvent:
    id: str
    ts: float
    pillar: str
    stage: str
    action: str
    detail: dict[str, Any]

    def to_json(self) -> str:
        return json.dumps(asdict(self), ensure_ascii=False)


def _redis():
    try:
        from agents.core.config import get_redis_client

        return get_redis_client()
    except Exception as e:
        logger.warning("Redis unavailable: %s", e)
        return None


def _emit(
    redis: Any,
    pillar: Pillar,
    stage: str,
    action: str,
    detail: Optional[dict[str, Any]] = None,
) -> None:
    if not redis:
        return
    ev = PipelineEvent(
        id=str(uuid.uuid4())[:12],
        ts=time.time(),
        pillar=pillar.value,
        stage=stage,
        action=action,
        detail=detail or {},
    )
    try:
        redis.lpush(REDIS_EVENTS, ev.to_json())
        redis.ltrim(REDIS_EVENTS, 0, 499)
    except Exception as e:
        logger.error("emit failed: %s", e)


def _get_defcon(redis: Any) -> int:
    try:
        raw = redis.get("kernell:system:defcon")
        if raw is None:
            return 5
        v = raw.decode() if isinstance(raw, bytes) else str(raw)
        return int(float(v))
    except Exception:
        return 5


def _parse_float(raw: Any, default: float = 0.0) -> float:
    if raw is None:
        return default
    try:
        s = raw.decode() if isinstance(raw, bytes) else str(raw)
        return float(s)
    except (TypeError, ValueError):
        return default


class RevenueMaxPipeline:
    def __init__(self, redis_client: Any = None) -> None:
        self.redis = redis_client or _redis()

    def tick(self) -> dict[str, Any]:
        """Un ciclo de orquestación: sync finanzas, métricas, despachos acotados."""
        r = self.redis
        report: dict[str, Any] = {
            "ts": time.time(),
            "dispatched": [],
            "skipped": [],
            "errors": [],
        }
        if not r:
            report["errors"].append("no_redis")
            return report

        _emit(r, Pillar.GOVERNANCE, "tick", "start", {})

        # 1) Finanzas Meta/Stripe (best-effort, no duplicar en exceso)
        now = time.time()
        last_fin = _parse_float(r.get(REDIS_LAST_FINANCE), 0.0)
        if now - last_fin > float(os.environ.get("REVENUE_PIPELINE_FINANCE_INTERVAL_S", "300")):
            try:
                from agents.finance.economy.ecosystem_integration import sync_finance_adapters

                sync_finance_adapters(r, log=logger)
                r.set(REDIS_LAST_FINANCE, str(now))
                _emit(r, Pillar.GOVERNANCE, "finance", "sync_finance_adapters", {})
            except Exception as e:
                report["errors"].append(f"finance_sync:{e}")

        defcon = _get_defcon(r)
        min_def_marketing = int(os.environ.get("REVENUE_PIPELINE_MIN_DEFCON_MARKETING", "2"))

        # 2) Profit gates
        try:
            from agents.core.profit_gates_guard import (
                dropshipping_gate_status,
                trading_real_execution_allowed,
            )

            ds_status = dropshipping_gate_status(r)
            tr_ok, tr_reason = trading_real_execution_allowed(r)
        except Exception as e:
            ds_status, tr_ok, tr_reason = "MISSING", False, str(e)

        report["defcon"] = defcon
        report["dropship_gate"] = ds_status
        report["trading_allowed"] = tr_ok
        report["trading_reason"] = tr_reason

        # 3) Dropshipping → Hunter (sourcing) si gate OK y pipeline “hambriento”
        if ds_status in ("PASS", "DEGRADED") and defcon >= min_def_marketing:
            try:
                stats = r.hgetall("ECON:pipeline:stats") or {}
                def _hget(key: str) -> Any:
                    return stats.get(key) or stats.get(key.encode())

                uniq = _parse_float(_hget("unique_products"), -1.0)
                if uniq < 0:
                    # Compat: ciclos antiguos solo guardaban total_scanned
                    uniq = _parse_float(_hget("total_scanned"), 0.0)
                threshold = float(os.environ.get("REVENUE_PIPELINE_MIN_UNIQUE_PRODUCTS", "3"))
                if uniq < threshold:
                    kw = os.environ.get(
                        "REVENUE_PIPELINE_SOURCING_KEYWORDS", "trending,dropship,2026"
                    )
                    payload = {
                        "type": "source_products",
                        "description": "revenue_max_pipeline",
                        "keywords": [k.strip() for k in kw.split(",") if k.strip()],
                        "source": "revenue_max",
                        "timestamp": time.time(),
                        "id": f"rmax_hunter_{int(time.time())}",
                    }
                    r.rpush("kernell:tasks:hunter", json.dumps(payload))
                    report["dispatched"].append("hunter:source_products")
                    _emit(
                        r,
                        Pillar.DROPSHIP,
                        "sourcing",
                        "dispatch_hunter",
                        {"keywords": payload["keywords"]},
                    )
                else:
                    report["skipped"].append("hunter:threshold_not_met")
            except Exception as e:
                report["errors"].append(f"hunter:{e}")
        else:
            report["skipped"].append("hunter:gate_or_defcon")

        # 4) Marketing → Ads (sync + evaluate) si economía no pausada y caps
        eco_pause = r.get("kernell:economy:paused")
        eco_ok = eco_pause not in (b"true", "true")
        spent = _parse_float(r.get("kernell:ads:daily_spent_usd"), 0.0)
        cap = float(os.environ.get("ADS_DAILY_CAP_USD", os.environ.get("REVENUE_PIPELINE_ADS_CAP", "200")))

        # Ads sync/evaluate: lectura/optimización — no exige veredicto trading (sí Economy + DEFCON + cap).
        if eco_ok and defcon >= min_def_marketing and spent < cap * 0.95:
            for task_type in ("sync", "evaluate"):
                payload = {
                    "type": task_type,
                    "description": "revenue_max_pipeline",
                    "source": "revenue_max",
                    "timestamp": time.time(),
                    "id": f"rmax_ads_{task_type}_{int(time.time())}",
                }
                try:
                    r.rpush("kernell:tasks:ads", json.dumps(payload))
                    report["dispatched"].append(f"ads:{task_type}")
                except Exception as e:
                    report["errors"].append(f"ads:{task_type}:{e}")
            _emit(r, Pillar.MARKETING, "ads", "dispatch_sync_evaluate", {"spent": spent, "cap": cap})
        else:
            report["skipped"].append(
                f"ads:eco={eco_ok} tr={tr_ok} defcon={defcon} spent={spent}/{cap}"
            )

        # 5) Trading — solo señal informativa (Nemesis loop propio); opcional tarea si existe contrato
        _emit(
            r,
            Pillar.TRADING,
            "observe",
            "snapshot",
            {"trading_allowed": tr_ok, "reason": tr_reason},
        )

        # 6) Métricas agregadas
        try:
            r.hset(
                REDIS_METRICS,
                mapping={
                    "last_tick_ts": str(now),
                    "last_defcon": str(defcon),
                    "last_ds_gate": ds_status,
                    "dispatched_n": str(len(report["dispatched"])),
                },
            )
            r.set(REDIS_LAST_TICK, json.dumps(report, ensure_ascii=False))
        except Exception as e:
            report["errors"].append(f"metrics:{e}")

        _emit(r, Pillar.GOVERNANCE, "tick", "done", {"dispatched": report["dispatched"]})
        logger.info("revenue_max tick: %s", report)
        return report


def run_revenue_pipeline_tick(redis_client: Any = None) -> dict[str, Any]:
    """Entry point Chronos / CLI."""
    p = RevenueMaxPipeline(redis_client=redis_client)
    return p.tick()


def emit_manual(
    pillar: str,
    stage: str,
    action: str,
    detail: Optional[dict[str, Any]] = None,
    redis_client: Any = None,
) -> None:
    """API para agentes que quieren dejar huella en el pipeline sin pasar por tick."""
    r = redis_client or _redis()
    try:
        pl = Pillar(pillar)
    except ValueError:
        pl = Pillar.GOVERNANCE
    _emit(r, pl, stage, action, detail)
