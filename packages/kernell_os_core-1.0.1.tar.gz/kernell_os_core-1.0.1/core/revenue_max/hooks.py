"""
Emisiones al pipeline Revenue Max desde agentes sin romper su flujo principal.

Usar `safe_emit` desde Economy, Ads, Nemesis, etc.: nunca importa fallos hacia arriba.
"""

from __future__ import annotations

from typing import Any, Optional


def safe_emit(
    pillar: str,
    stage: str,
    action: str,
    detail: Optional[dict[str, Any]] = None,
    redis_client: Any = None,
) -> None:
    try:
        from core.revenue_max.pipeline import emit_manual

        emit_manual(pillar, stage, action, detail, redis_client)
    except Exception:
        pass
