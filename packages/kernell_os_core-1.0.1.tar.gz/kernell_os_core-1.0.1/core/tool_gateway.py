#!/usr/bin/env python3
"""
🔌 KERNELL OS — TOOL GATEWAY v1.0
============================================================
Unified entry point for ALL external tool access.
Routes requests through ACL (ToolRoom) → MCP or HTTP API → result.

Any agent calls:
    result = gateway.call("forge", "brave_search", {"query": "..."})
    result = gateway.call("hunter", "github", {"action": "search_repos", ...})

The gateway handles:
    1. ACL check via ToolRoom
    2. Routing to MCP server or HTTP API
    3. Execution with timeout
    4. Audit logging

Sovereign Architecture — Blueprint XIV
"""

import os
import sys
import json
import time
import logging
from pathlib import Path
from datetime import datetime, timezone
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, asdict

ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT))

from core.tool_room import ToolRoom, AccessDecision

logger = logging.getLogger("TOOL_GATEWAY")


# ── MCP Server Registry ─────────────────────────────────────────────────────

# Known MCP servers and how to start them
MCP_SERVER_CONFIGS = {
    "filesystem": {
        "command": ["npx", "-y", "@modelcontextprotocol/server-filesystem", str(ROOT)],
        "description": "Read/write filesystem within project root",
        "category": "mcp_servers",
    },
    "brave_search": {
        "command": ["npx", "-y", "@modelcontextprotocol/server-brave-search"],
        "env": {"BRAVE_API_KEY": os.environ.get("BRAVE_API_KEY", "")},
        "description": "Web search via Brave Search API",
        "category": "mcp_servers",
    },
    "github": {
        "command": ["npx", "-y", "@modelcontextprotocol/server-github"],
        "env": {"GITHUB_PERSONAL_ACCESS_TOKEN": os.environ.get("GITHUB_TOKEN", "")},
        "description": "GitHub repository operations",
        "category": "mcp_servers",
    },
    "kali": {
        "command": ["docker", "run", "-i", "--rm", "kernell-mcp-kali"],
        "description": "Security tools via Kali Linux container",
        "category": "mcp_servers",
    },
}

# API key services — routed via direct HTTP, not MCP
API_KEY_SERVICES = {
    "gemini": {"provider": "google", "env_key": "GEMINI_API_KEY"},
    "groq": {"provider": "groq", "env_key": "GROQ_API_KEY"},
    "anthropic": {"provider": "anthropic", "env_key": "ANTHROPIC_API_KEY"},
    "openai": {"provider": "openai", "env_key": "OPENAI_API_KEY"},
}


# ── Result Model ─────────────────────────────────────────────────────────────

@dataclass
class ToolResult:
    """Result of a tool call."""
    success: bool
    tool_name: str
    output: Any = None
    error: str = ""
    latency_ms: float = 0
    route: str = ""  # "mcp" or "api" or "denied"

    def to_dict(self) -> dict:
        return asdict(self)


# ── Tool Gateway ─────────────────────────────────────────────────────────────

class ToolGateway:
    """
    Unified tool access gateway for Kernell OS.

    Usage:
        gateway = ToolGateway(redis_client=redis)
        result = gateway.call("hunter", "brave_search", {"query": "..."})
        if result.success:
            print(result.output)
    """

    REDIS_PREFIX = "kernell:gateway:"

    def __init__(self, redis_client=None):
        self._redis = redis_client
        self._tool_room = ToolRoom(redis_client=redis_client)
        self._mcp_clients: Dict[str, Any] = {}  # Lazily initialized
        self._call_count = 0
        self._total_latency = 0.0

        logger.info(
            f"🔌 Tool Gateway v1.0 initialized | "
            f"MCP servers: {len(MCP_SERVER_CONFIGS)} | "
            f"API services: {len(API_KEY_SERVICES)}"
        )

    # ── Public API ───────────────────────────────────────────────────────────

    def call(
        self,
        agent_id: str,
        tool_name: str,
        params: Dict[str, Any] = None,
        timeout: int = 30,
    ) -> ToolResult:
        """
        Execute a tool call with ACL enforcement.

        Args:
            agent_id: Requesting agent (e.g., "hunter", "forge")
            tool_name: Tool to call (e.g., "brave_search", "github")
            params: Tool-specific parameters
            timeout: Max execution time in seconds

        Returns:
            ToolResult with success/failure and output
        """
        start = time.time()
        params = params or {}

        # 1. Determine category
        category = self._resolve_category(tool_name)
        if not category:
            return ToolResult(
                success=False, tool_name=tool_name,
                error=f"Unknown tool: {tool_name}", route="denied"
            )

        # 2. ACL check
        decision = self._tool_room.check_access(agent_id, category, tool_name)
        if not decision.allowed:
            logger.warning(f"🚫 {agent_id} denied access to {tool_name}: {decision.reason}")
            return ToolResult(
                success=False, tool_name=tool_name,
                error=f"Access denied: {decision.reason}", route="denied"
            )

        # 3. Route to MCP or API
        if tool_name in MCP_SERVER_CONFIGS:
            result = self._call_mcp(tool_name, params, timeout)
        elif tool_name in API_KEY_SERVICES:
            result = self._call_api(tool_name, params)
        else:
            result = ToolResult(
                success=False, tool_name=tool_name,
                error=f"No handler for tool: {tool_name}", route="unknown"
            )

        # 4. Record metrics
        result.latency_ms = (time.time() - start) * 1000
        self._call_count += 1
        self._total_latency += result.latency_ms
        self._log_call(agent_id, result)

        return result

    def check(self, agent_id: str, tool_name: str) -> AccessDecision:
        """Check if an agent has access to a tool without executing."""
        category = self._resolve_category(tool_name)
        if not category:
            return AccessDecision(
                allowed=False, agent_id=agent_id,
                tool_category="unknown", tool_name=tool_name,
                granted_level="NONE", reason=f"Unknown tool: {tool_name}"
            )
        return self._tool_room.check_access(agent_id, category, tool_name)

    def list_tools(self, agent_id: str = None) -> Dict[str, dict]:
        """List all available tools, optionally filtered by agent access."""
        tools = {}

        for name, config in MCP_SERVER_CONFIGS.items():
            entry = {
                "type": "mcp",
                "description": config.get("description", ""),
                "category": config.get("category", "mcp_servers"),
            }
            if agent_id:
                decision = self.check(agent_id, name)
                entry["access"] = decision.granted_level
                entry["allowed"] = decision.allowed
            tools[name] = entry

        for name, config in API_KEY_SERVICES.items():
            has_key = bool(os.environ.get(config.get("env_key", ""), ""))
            entry = {
                "type": "api_key",
                "provider": config.get("provider", ""),
                "has_key": has_key,
                "category": "api_keys",
            }
            if agent_id:
                decision = self.check(agent_id, name)
                entry["access"] = decision.granted_level
                entry["allowed"] = decision.allowed
            tools[name] = entry

        return tools

    def get_status(self) -> dict:
        """Return gateway status for dashboard."""
        return {
            "mcp_servers": len(MCP_SERVER_CONFIGS),
            "api_services": len(API_KEY_SERVICES),
            "active_mcp_clients": len(self._mcp_clients),
            "total_calls": self._call_count,
            "avg_latency_ms": round(self._total_latency / max(self._call_count, 1), 1),
            "tool_room": self._tool_room.get_status(),
        }

    # ── Internal ─────────────────────────────────────────────────────────────

    def _resolve_category(self, tool_name: str) -> Optional[str]:
        """Determine which ToolRoom category a tool belongs to."""
        if tool_name in MCP_SERVER_CONFIGS:
            return MCP_SERVER_CONFIGS[tool_name].get("category", "mcp_servers")
        if tool_name in API_KEY_SERVICES:
            return "api_keys"
        return None

    def _call_mcp(self, tool_name: str, params: Dict, timeout: int) -> ToolResult:
        """Execute a tool via MCP protocol."""
        try:
            from agents.core.mcp_client import MCPStdioClient

            config = MCP_SERVER_CONFIGS[tool_name]

            # Lazy init: start MCP server if not running
            if tool_name not in self._mcp_clients:
                env = {**os.environ, **config.get("env", {})}
                client = MCPStdioClient(config["command"])
                client.start()
                self._mcp_clients[tool_name] = client

            client = self._mcp_clients[tool_name]

            # Determine the MCP tool to call
            mcp_tool = params.pop("_mcp_tool", tool_name)
            output = client.call_tool(mcp_tool, params, timeout=timeout)

            return ToolResult(
                success=True, tool_name=tool_name,
                output=output, route="mcp"
            )

        except Exception as e:
            logger.error(f"MCP call failed for {tool_name}: {e}")
            # Clean up dead client
            if tool_name in self._mcp_clients:
                try:
                    self._mcp_clients[tool_name].stop()
                except Exception:
                    pass
                del self._mcp_clients[tool_name]
            return ToolResult(
                success=False, tool_name=tool_name,
                error=str(e), route="mcp"
            )

    def _call_api(self, tool_name: str, params: Dict) -> ToolResult:
        """Execute a tool via API key service."""
        config = API_KEY_SERVICES.get(tool_name, {})
        env_key = config.get("env_key", "")
        api_key = os.environ.get(env_key, "")

        if not api_key:
            return ToolResult(
                success=False, tool_name=tool_name,
                error=f"API key not set: {env_key}", route="api"
            )

        # Return the key info for the agent to use directly
        # (agents use their own provider-specific clients)
        return ToolResult(
            success=True, tool_name=tool_name,
            output={"provider": config.get("provider"), "key_available": True},
            route="api"
        )

    def _log_call(self, agent_id: str, result: ToolResult):
        """Log tool call to Redis."""
        if not self._redis:
            return
        try:
            event = {
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "agent_id": agent_id,
                "tool": result.tool_name,
                "success": result.success,
                "route": result.route,
                "latency_ms": round(result.latency_ms, 1),
            }
            if result.error:
                event["error"] = result.error

            self._redis.lpush(f"{self.REDIS_PREFIX}call_log", json.dumps(event))
            self._redis.ltrim(f"{self.REDIS_PREFIX}call_log", 0, 499)
        except Exception:
            pass

    def shutdown(self):
        """Stop all active MCP clients."""
        for name, client in self._mcp_clients.items():
            try:
                client.stop()
                logger.info(f"🔌 Stopped MCP client: {name}")
            except Exception:
                pass
        self._mcp_clients.clear()

    def __del__(self):
        self.shutdown()


# ── CLI ──────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import argparse
    logging.basicConfig(level=logging.INFO, format="%(message)s")

    parser = argparse.ArgumentParser(description="🔌 Kernell OS Tool Gateway")
    parser.add_argument("--status", action="store_true", help="Show gateway status")
    parser.add_argument("--list", type=str, metavar="AGENT", help="List tools for agent")
    parser.add_argument("--check", nargs=2, metavar=("AGENT", "TOOL"), help="Check access")
    args = parser.parse_args()

    # Redis
    r = None
    try:
        import redis
        pw = os.environ.get("REDIS_PASSWORD", "")
        r = redis.Redis(host="localhost", port=6380, password=pw or None, decode_responses=True)
        r.ping()
    except Exception:
        r = None

    gw = ToolGateway(redis_client=r)

    if args.status:
        print(json.dumps(gw.get_status(), indent=2))
    elif args.list:
        tools = gw.list_tools(agent_id=args.list)
        for name, info in sorted(tools.items()):
            status = "✅" if info.get("allowed", True) else "❌"
            print(f"  {status} {name:20s} type={info['type']:8s} access={info.get('access', 'N/A')}")
    elif args.check:
        agent, tool = args.check
        d = gw.check(agent, tool)
        print(f"{'✅ ALLOWED' if d.allowed else '❌ DENIED'} — {agent} → {tool}")
        print(f"  Level: {d.granted_level}")
        if d.reason:
            print(f"  Reason: {d.reason}")
    else:
        parser.print_help()
