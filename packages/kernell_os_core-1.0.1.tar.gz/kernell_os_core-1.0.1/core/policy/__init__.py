"""Policy package with compatibility bridge to legacy core/policy.py."""

import importlib.util
from pathlib import Path

from .engine import PolicyEngine, run_policy_healthcheck

_legacy_path = Path(__file__).resolve().parent.parent / "policy.py"
if _legacy_path.exists():
    _spec = importlib.util.spec_from_file_location("core._legacy_policy", str(_legacy_path))
    if _spec and _spec.loader:
        _mod = importlib.util.module_from_spec(_spec)
        _spec.loader.exec_module(_mod)
        if hasattr(_mod, "is_caller_allowed"):
            is_caller_allowed = _mod.is_caller_allowed


