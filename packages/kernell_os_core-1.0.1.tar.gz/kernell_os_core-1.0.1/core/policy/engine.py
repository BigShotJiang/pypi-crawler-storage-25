import json
import logging
import os
import time
from typing import Any, Dict, Optional

logger = logging.getLogger("POLICY_ENGINE")


class PolicyEngine:
    """
    Simple runtime policy gate for sensitive actions.
    Reads feature flags and budget/scope constraints from env and optional Redis.
    """

    def __init__(self, redis_client=None):
        self.redis = redis_client

    def _flag(self, key: str, default: str = "0") -> str:
        if self.redis:
            try:
                val = self.redis.get(f"kernell:flags:{key}")
                if val is not None:
                    return str(val)
            except Exception:
                pass
        return os.getenv(key, default)

    def evaluate(self, domain: str, action: str, context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        context = context or {}
        decision = {
            "allow": False,
            "domain": domain,
            "action": action,
            "reason": "blocked_by_default",
            "ts": time.time(),
            "context": context,
        }

        if self._flag("KERNELL_KILL_SWITCH", "0") == "1":
            decision["reason"] = "global_kill_switch"
            return decision

        if domain == "merchant":
            live = self._flag("OLA1_AUTONOMY_LIVE", "0") == "1"
            decision["allow"] = True
            decision["reason"] = "merchant_live" if live else "merchant_dry_run"
            return decision

        if domain == "ads":
            live = self._flag("META_ADS_LIVE", "0") == "1"
            budget = int(context.get("daily_budget_cents", 0) or 0)
            max_budget = int(self._flag("META_ADS_MAX_DAILY_BUDGET_CENTS", "1000"))
            if live and budget > max_budget:
                decision["reason"] = f"budget_exceeded:{budget}>{max_budget}"
                return decision
            decision["allow"] = True
            decision["reason"] = "ads_live" if live else "ads_dry_run"
            return decision

        if domain == "hunter":
            enabled = self._flag("HUNTER_OFFENSIVE_ENABLED", "0") == "1"
            allowlist = [x.strip().lower() for x in self._flag("HUNTER_SCOPE_ALLOWLIST", "").split(",") if x.strip()]
            host = str(context.get("target_host", "")).lower()
            if not enabled:
                decision["reason"] = "hunter_disabled"
                return decision
            if allowlist and host not in allowlist:
                decision["reason"] = "target_not_in_allowlist"
                return decision
            decision["allow"] = True
            decision["reason"] = "hunter_allowed"
            return decision

        if domain == "wallet":
            live = self._flag("POLY_WALLET_FUNDER_LIVE", "0") == "1"
            amount = float(context.get("recharge_amount_matic", 0.0) or 0.0)
            cap = float(self._flag("POLY_WALLET_FUNDER_MAX_MATIC", "2.0"))
            if live and amount > cap:
                decision["reason"] = f"wallet_cap_exceeded:{amount}>{cap}"
                return decision
            decision["allow"] = True
            decision["reason"] = "wallet_live" if live else "wallet_dry_run"
            return decision

        if domain == "trading":
            allow = self._flag("NEMESIS_ALLOW_AUTO_GRADUATION", "0") == "1"
            decision["allow"] = allow
            decision["reason"] = "trading_live_allowed" if allow else "trading_paper_mode"
            return decision

        decision["allow"] = True
        decision["reason"] = "no_specific_policy"
        return decision


def run_policy_healthcheck() -> Dict[str, Any]:
    """
    Chronos entrypoint for policy status snapshot.
    """
    snapshot = {
        "ts": time.time(),
        "flags": {
            "KERNELL_KILL_SWITCH": os.getenv("KERNELL_KILL_SWITCH", "0"),
            "OLA1_AUTONOMY_LIVE": os.getenv("OLA1_AUTONOMY_LIVE", "0"),
            "META_ADS_LIVE": os.getenv("META_ADS_LIVE", "0"),
            "NEMESIS_ALLOW_AUTO_GRADUATION": os.getenv("NEMESIS_ALLOW_AUTO_GRADUATION", "0"),
            "HUNTER_OFFENSIVE_ENABLED": os.getenv("HUNTER_OFFENSIVE_ENABLED", "0"),
            "POLY_WALLET_FUNDER_LIVE": os.getenv("POLY_WALLET_FUNDER_LIVE", "0"),
        },
    }
    try:
        import redis

        host = os.getenv("REDIS_HOST", "127.0.0.1")
        port = int(os.getenv("REDIS_PORT", "6380"))
        password = os.getenv("REDIS_PASSWORD", "").strip().strip("\"'") or None
        r = redis.Redis(host=host, port=port, password=password, decode_responses=True, socket_connect_timeout=5)
        r.set("kernell:policy:healthcheck:last", json.dumps(snapshot), ex=86400)
    except Exception as e:
        logger.warning("Policy healthcheck Redis publish skipped: %s", e)
    return snapshot

