#!/usr/bin/env python3
"""
🔐 KERNELL OS — AGENT MULTISIGN v1.0
======================================
Reemplaza el PIN humano con un quórum criptográfico de agentes.
Requiere que N agentes firmen una acción antes de ejecutarla.

Firmantes de quórum por defecto (para acciones críticas):
  - Sierra  (Auditor de integridad)
  - Sentinel (Seguridad)
  - Atlas   (Reality Governor)

Mecanismo:
  1. Un agente propone una acción (emite una "Proposal")
  2. Los agentes firmantes reciben la propuesta vía Redis Pub/Sub
  3. Cada uno la evalúa con sus reglas y firma con HMAC-SHA256
  4. Cuando se alcanza el quórum → la acción se autoriza
  5. Si expira el tiempo → la acción se rechaza y escala a Telegram

Uso:
    from agent_multisign import MultiSignProtocol, Action

    # Proponer una acción que requiere quórum
    protocol = MultiSignProtocol()
    action = Action(
        name="forge:patch_apply",
        target="agents/atlas/runtime_loop.py",
        payload={"type": "code_patch", "lines": 12},
        requester="forge",
    )
    proposal_id = protocol.propose(action)

    # Cada agente firmante (Sierra, Sentinel, Atlas) llama esto:
    protocol.sign(proposal_id, signer="sierra", approve=True)
    protocol.sign(proposal_id, signer="sentinel", approve=True)

    # Verificar si el quórum fue alcanzado
    result = protocol.check_quorum(proposal_id)
    # → {"authorized": True, "proposal_id": "...", "signatures": [...]}
"""

import os
import json
import hmac
import hashlib
import time
import uuid
from datetime import datetime, timezone
from typing import Optional

# ── Configuración ────────────────────────────────────────────────────────────

# Clave maestra del sistema (debe venir de env, nunca hardcodeada)
MULTISIGN_SECRET = os.getenv("KERNELL_MULTISIGN_SECRET", "").encode()
if not MULTISIGN_SECRET:
    # Fallback derivado de variables de entorno disponibles (nunca en producción)
    import hashlib
    _seed = (os.getenv("REDIS_PASSWORD", "") + os.getenv("KERNELL_ROOT", "/home/anny/kernell-os")).encode()
    MULTISIGN_SECRET = hashlib.sha256(_seed).digest()

PROPOSAL_TTL_SECONDS = int(os.getenv("MULTISIGN_TTL_SECONDS", "120"))  # 2 min para firmar

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHAT_ID   = os.getenv("TELEGRAM_CHAT_ID", "")

# Quórum requerido por nivel de riesgo
QUORUM_RULES = {
    # Nivel 3 — Acciones críticas (código, deploy, filesystem core)
    "critical": {
        "required_signers": ["sierra", "sentinel", "atlas"],
        "min_approvals": 2,  # Al menos 2 de 3 deben aprobar (con Sierra obligatorio)
        "required_mandatory": ["sierra"],  # Sierra siempre debe aprobar
    },
    # Nivel 2 — Acciones importantes (configuración, servicios)
    "high": {
        "required_signers": ["sentinel", "atlas"],
        "min_approvals": 2,
        "required_mandatory": [],
    },
    # Nivel 1 — Acciones reversibles
    "medium": {
        "required_signers": ["sentinel"],
        "min_approvals": 1,
        "required_mandatory": [],
    },
}

# Clasificación de acciones por riesgo
ACTION_RISK_MAP = {
    "forge:patch_apply":     "critical",
    "forge:deploy":          "critical",
    "fixer:kernel_mutate":   "critical",
    "agent:config_change":   "high",
    "service:restart":       "high",
    "service:stop":          "critical",
    "economy:trade":         "critical",
    "economy:ads_publish":   "medium",
    "infra:redis_flush":     "critical",
    "agent:spawn":           "high",
    "default":               "high",
}


# ── Modelos ───────────────────────────────────────────────────────────────────

class Action:
    def __init__(
        self,
        name: str,
        payload: dict,
        requester: str,
        target: str = "",
        risk_level: str = "",
        context_hash: str = "",
    ):
        self.name         = name
        self.payload      = payload
        self.requester    = requester
        self.target       = target
        self.risk_level   = risk_level or ACTION_RISK_MAP.get(name, ACTION_RISK_MAP["default"])
        self.context_hash = context_hash
        self.timestamp    = datetime.now(timezone.utc).isoformat()

    def to_dict(self) -> dict:
        return {
            "name":         self.name,
            "payload":      self.payload,
            "requester":    self.requester,
            "target":       self.target,
            "risk_level":   self.risk_level,
            "context_hash": self.context_hash,
            "timestamp":    self.timestamp,
        }

    def canonical_string(self) -> str:
        """String determinista para firma (sin timestamps variables)."""
        return json.dumps({
            "name":    self.name,
            "target":  self.target,
            "payload": self.payload,
        }, sort_keys=True)


class Signature:
    def __init__(self, signer: str, proposal_id: str, action: Action, approved: bool, reason: str = ""):
        self.signer      = signer
        self.proposal_id = proposal_id
        self.approved    = approved
        self.reason      = reason
        self.timestamp   = datetime.now(timezone.utc).isoformat()

        # Generar HMAC de la firma
        self.hmac_value = self._compute_hmac(action)

    def _compute_hmac(self, action: Action) -> str:
        """HMAC-SHA256 de la acción + signer + aprobación."""
        message = f"{self.signer}:{self.proposal_id}:{action.canonical_string()}:{self.approved}"
        return hmac.new(
            MULTISIGN_SECRET,
            message.encode(),
            hashlib.sha256
        ).hexdigest()

    def verify(self, action: Action) -> bool:
        """Verificar integridad de la firma."""
        expected = self._compute_hmac(action)
        return hmac.compare_digest(self.hmac_value, expected)

    def to_dict(self) -> dict:
        return {
            "signer":      self.signer,
            "proposal_id": self.proposal_id,
            "approved":    self.approved,
            "reason":      self.reason,
            "timestamp":   self.timestamp,
            "hmac":        self.hmac_value,
        }


# ── Propuesta ─────────────────────────────────────────────────────────────────

class Proposal:
    def __init__(self, action: Action):
        self.id         = f"PROP-{datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')}-{uuid.uuid4().hex[:6].upper()}"
        self.action     = action
        self.signatures: list[Signature] = []
        self.status     = "PENDING"   # PENDING | AUTHORIZED | REJECTED | EXPIRED
        self.created_at = time.time()
        self.resolved_at: Optional[float] = None
        self.quorum_rule = QUORUM_RULES.get(action.risk_level, QUORUM_RULES["high"])

    @property
    def is_expired(self) -> bool:
        return (time.time() - self.created_at) > PROPOSAL_TTL_SECONDS

    @property
    def signers_who_approved(self) -> list[str]:
        return [s.signer for s in self.signatures if s.approved]

    @property
    def signers_who_rejected(self) -> list[str]:
        return [s.signer for s in self.signatures if not s.approved]

    def has_signed(self, signer: str) -> bool:
        return any(s.signer == signer for s in self.signatures)

    def evaluate_quorum(self) -> tuple[bool, str]:
        """
        Evalúa si el quórum fue alcanzado.
        Returns: (authorized, reason)
        """
        if self.is_expired:
            return False, "TTL expirado — propuesta caducada"

        rule      = self.quorum_rule
        approved  = set(self.signers_who_approved)
        rejected  = set(self.signers_who_rejected)
        mandatory = set(rule.get("required_mandatory", []))

        # Verificar firmantes requeridos
        required  = set(rule["required_signers"])
        signed    = approved | rejected
        pending   = required - signed

        # ¿Algún firmante obligatorio rechazó?
        if mandatory & rejected:
            rejectors = mandatory & rejected
            return False, f"Rechazado por firmante obligatorio: {rejectors}"

        # ¿Suficientes aprobaciones?
        if len(approved) >= rule["min_approvals"]:
            # ¿Todos los obligatorios aprobaron o aún no han firmado?
            mandatory_not_approved = mandatory - approved
            if mandatory_not_approved:
                if not pending:  # Ya firmaron todos pero los obligatorios no aprobaron
                    return False, f"Firmantes obligatorios no aprobaron: {mandatory_not_approved}"
                return False, f"Esperando firmas obligatorias de: {mandatory_not_approved}"
            return True, f"Quórum alcanzado — {len(approved)} aprobaciones"

        # ¿Es imposible alcanzar el quórum?
        max_possible = len(approved) + len(pending)
        if max_possible < rule["min_approvals"]:
            return False, f"Imposible alcanzar quórum ({len(approved)} aprobado, {len(pending)} pendiente)"

        return False, f"Pendiente — {len(approved)}/{rule['min_approvals']} aprobaciones"

    def to_dict(self) -> dict:
        authorized, reason = self.evaluate_quorum()
        return {
            "id":              self.id,
            "action":          self.action.to_dict(),
            "status":          self.status,
            "signatures":      [s.to_dict() for s in self.signatures],
            "approved_by":     self.signers_who_approved,
            "rejected_by":     self.signers_who_rejected,
            "quorum_rule":     self.quorum_rule,
            "current_verdict": {"authorized": authorized, "reason": reason},
            "created_at":      datetime.fromtimestamp(self.created_at, tz=timezone.utc).isoformat(),
            "is_expired":      self.is_expired,
        }


# ── Protocolo Principal ───────────────────────────────────────────────────────

class MultiSignProtocol:
    """
    Protocolo de multifirma de agentes para Kernell OS.
    Persiste propuestas en Redis con TTL automático.
    """

    REDIS_PREFIX = "kernell:multisign:"

    def __init__(self, redis_client=None):
        self._redis = redis_client
        self._local_proposals: dict[str, Proposal] = {}

    # ── Persistencia ──────────────────────────────────────────────────────

    def _save_proposal(self, proposal: Proposal):
        data = json.dumps(proposal.to_dict())
        if self._redis:
            try:
                self._redis.set(
                    f"{self.REDIS_PREFIX}{proposal.id}",
                    data,
                    ex=PROPOSAL_TTL_SECONDS * 2
                )
            except Exception:
                pass
        self._local_proposals[proposal.id] = proposal

    def _load_proposal(self, proposal_id: str) -> Optional[Proposal]:
        # Local cache primero
        if proposal_id in self._local_proposals:
            return self._local_proposals[proposal_id]
        # Redis fallback
        if self._redis:
            try:
                raw = self._redis.get(f"{self.REDIS_PREFIX}{proposal_id}")
                if raw:
                    # Nota: reconstrucción completa desde Redis para agentes externos
                    # En producción esto debería deserializar un Proposal completo
                    pass
            except Exception:
                pass
        return None

    # ── API pública ───────────────────────────────────────────────────────

    def propose(self, action: Action) -> str:
        """
        Crea una propuesta y la notifica a los firmantes vía Redis Pub/Sub.
        Retorna el proposal_id.
        """
        proposal = Proposal(action)

        print(f"\n📋 [MultiSign] Nueva propuesta: {proposal.id}")
        print(f"   Acción:     {action.name}")
        print(f"   Target:     {action.target}")
        print(f"   Requester:  {action.requester}")
        print(f"   Riesgo:     {action.risk_level}")
        print(f"   Firmantes:  {proposal.quorum_rule['required_signers']}")
        print(f"   TTL:        {PROPOSAL_TTL_SECONDS}s\n")

        self._save_proposal(proposal)

        # Publicar en Redis para que los agentes lo reciban
        if self._redis:
            try:
                event = {
                    "type":        "multisign_proposal",
                    "proposal_id": proposal.id,
                    "action":      action.to_dict(),
                    "signers":     proposal.quorum_rule["required_signers"],
                    "ttl_seconds": PROPOSAL_TTL_SECONDS,
                    "timestamp":   datetime.now(timezone.utc).isoformat(),
                }
                self._redis.lpush("kernell:multisign:pending", json.dumps(event))
                self._redis.publish("kernell:events", json.dumps(event))
            except Exception as e:
                print(f"⚠️  Redis publish error: {e}")

        # Notificar Telegram si es acción crítica
        if action.risk_level == "critical":
            self._notify_telegram_proposal(proposal)

        return proposal.id

    def sign(
        self,
        proposal_id: str,
        signer: str,
        approve: bool,
        reason: str = "",
        verify_reality: bool = True,
    ) -> dict:
        """
        Un agente firma (aprueba o rechaza) una propuesta.
        verify_reality: si True, verifica GSHI antes de aprobar.
        """
        proposal = self._load_proposal(proposal_id)
        if not proposal:
            return {"error": f"Propuesta {proposal_id} no encontrada"}

        if proposal.is_expired:
            proposal.status = "EXPIRED"
            self._save_proposal(proposal)
            return {"error": "Propuesta expirada"}

        if proposal.has_signed(signer):
            return {"error": f"{signer} ya firmó esta propuesta"}

        # Verificar realidad antes de aprobar (anti-alucinación)
        if approve and verify_reality and self._redis:
            reality = self._get_reality_snapshot()
            if reality:
                gshi = reality.get("gshi", 0)
                if gshi < 0.50:
                    approve = False
                    reason = f"AUTO-RECHAZADO: GSHI={gshi} < 0.50 — sistema en estado degradado"
                    print(f"⚠️  [{signer}] Aprobación convertida a rechazo por GSHI bajo: {gshi}")

        # Crear firma
        sig = Signature(signer, proposal_id, proposal.action, approve, reason)
        proposal.signatures.append(sig)

        icon = "✅" if approve else "❌"
        print(f"{icon} [MultiSign] {signer} {'aprobó' if approve else 'rechazó'} {proposal_id}")
        if reason:
            print(f"   Razón: {reason}")

        # Evaluar quórum
        authorized, verdict_reason = proposal.evaluate_quorum()

        if authorized:
            proposal.status = "AUTHORIZED"
            proposal.resolved_at = time.time()
            print(f"\n🎯 [MultiSign] AUTORIZADO: {proposal_id}")
            self._on_authorized(proposal)
        else:
            # Verificar si fue rechazado definitivamente
            is_rejected = False
            if "Rechazado" in verdict_reason or "Imposible" in verdict_reason:
                is_rejected = True
            elif proposal.is_expired:
                is_rejected = True

            if is_rejected:
                proposal.status = "REJECTED"
                proposal.resolved_at = time.time()
                print(f"\n🚫 [MultiSign] RECHAZADO: {proposal_id} — {verdict_reason}")
                self._on_rejected(proposal, verdict_reason)

        self._save_proposal(proposal)

        return {
            "proposal_id": proposal_id,
            "signer":      signer,
            "approved":    approve,
            "hmac":        sig.hmac_value[:16] + "...",
            "status":      proposal.status,
            "verdict":     verdict_reason,
        }

    def check_quorum(self, proposal_id: str) -> dict:
        """Verifica el estado de quórum de una propuesta."""
        proposal = self._load_proposal(proposal_id)
        if not proposal:
            return {"error": f"Propuesta {proposal_id} no encontrada"}

        if proposal.is_expired and proposal.status == "PENDING":
            proposal.status = "EXPIRED"
            self._on_rejected(proposal, "TTL expirado")
            self._save_proposal(proposal)

        authorized, reason = proposal.evaluate_quorum()
        return {
            "proposal_id":   proposal_id,
            "authorized":    authorized or proposal.status == "AUTHORIZED",
            "status":        proposal.status,
            "reason":        reason,
            "approved_by":   proposal.signers_who_approved,
            "rejected_by":   proposal.signers_who_rejected,
            "is_expired":    proposal.is_expired,
        }

    # ── Callbacks ─────────────────────────────────────────────────────────

    def _on_authorized(self, proposal: Proposal):
        """Acción ejecutable: publicar evento de autorización en Redis."""
        if self._redis:
            try:
                event = {
                    "type":        "multisign_authorized",
                    "proposal_id": proposal.id,
                    "action_name": proposal.action.name,
                    "approved_by": proposal.signers_who_approved,
                    "timestamp":   datetime.now(timezone.utc).isoformat(),
                }
                self._redis.publish("kernell:events", json.dumps(event))
                # Mover a cola de ejecución autorizada
                self._redis.lpush("kernell:multisign:authorized", json.dumps(event))
            except Exception:
                pass

    def _on_rejected(self, proposal: Proposal, reason: str):
        """Notificar rechazo vía Telegram si era crítico."""
        if proposal.action.risk_level == "critical":
            msg = (
                f"🚫 <b>MULTISIGN RECHAZADO</b>\n\n"
                f"📋 <b>Propuesta:</b> <code>{proposal.id}</code>\n"
                f"⚙️ <b>Acción:</b> {proposal.action.name}\n"
                f"❌ <b>Razón:</b> {reason}\n"
                f"👥 <b>Rechazado por:</b> {proposal.signers_who_rejected}\n"
                f"📊 <b>Aprobado por:</b> {proposal.signers_who_approved}"
            )
            self._notify_telegram_raw(msg)

    def _notify_telegram_proposal(self, proposal: Proposal):
        """Notificar nueva propuesta crítica al Arquitecto."""
        rule  = proposal.quorum_rule
        msg = (
            f"🔐 <b>MULTISIGN REQUERIDO</b>\n\n"
            f"📋 <b>ID:</b> <code>{proposal.id}</code>\n"
            f"⚙️ <b>Acción:</b> {proposal.action.name}\n"
            f"🎯 <b>Target:</b> {proposal.action.target or 'N/A'}\n"
            f"🔴 <b>Riesgo:</b> {proposal.action.risk_level.upper()}\n"
            f"👥 <b>Firmantes:</b> {rule['required_signers']}\n"
            f"✅ <b>Mínimo:</b> {rule['min_approvals']} aprobaciones\n"
            f"⏰ <b>TTL:</b> {PROPOSAL_TTL_SECONDS}s\n\n"
            f"Los agentes están evaluando la propuesta."
        )
        self._notify_telegram_raw(msg)

    def _notify_telegram_raw(self, message: str):
        if not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID:
            return
        try:
            import urllib.request
            payload = json.dumps({
                "chat_id": TELEGRAM_CHAT_ID,
                "text": message,
                "parse_mode": "HTML",
            }).encode()
            url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
            req = urllib.request.Request(url, data=payload,
                                         headers={"Content-Type": "application/json"})
            urllib.request.urlopen(req, timeout=5)
        except Exception:
            pass

    def _get_reality_snapshot(self) -> Optional[dict]:
        """Obtiene el snapshot de realidad desde Redis."""
        if not self._redis:
            return None
        try:
            raw = self._redis.get("kernell:reality:snapshot")
            return json.loads(raw) if raw else None
        except Exception:
            return None


# ── Entry point CLI ───────────────────────────────────────────────────────────

def main():
    import argparse
    parser = argparse.ArgumentParser(description="Kernell OS Agent MultiSign CLI")
    parser.add_argument("--demo",   action="store_true", help="Simular flujo completo")
    parser.add_argument("--status", metavar="PROPOSAL_ID", help="Estado de una propuesta")
    parser.add_argument("--pending", action="store_true",  help="Ver propuestas pendientes")
    args = parser.parse_args()

    redis_client = None
    try:
        import redis as redis_lib
        password = os.getenv("REDIS_PASSWORD", "").strip().strip("\"'") or None
        redis_client = redis_lib.Redis(
            host="127.0.0.1", port=6379, password=password,
            decode_responses=True, socket_connect_timeout=2
        )
        redis_client.ping()
        print("✅ Redis conectado")
    except Exception as e:
        print(f"⚠️  Redis no disponible: {e}")

    protocol = MultiSignProtocol(redis_client)

    if args.demo:
        print("\n🧪 DEMO: Flujo completo de MultiSign para acción crítica\n")

        action = Action(
            name="forge:patch_apply",
            target="agents/atlas/runtime_loop.py",
            payload={"type": "code_patch", "description": "Añadir GSHI_EMA"},
            requester="forge",
            risk_level="critical",
        )

        proposal_id = protocol.propose(action)
        print("\n--- Agentes firmando ---\n")

        result = protocol.sign(proposal_id, "sierra",   approve=True,  reason="Código validado, no rompe Golden Path")
        print(f"Sierra:   {result['status']}")

        result = protocol.sign(proposal_id, "sentinel", approve=True,  reason="Sin inyección de código malicioso detectada")
        print(f"Sentinel: {result['status']}")

        result = protocol.sign(proposal_id, "atlas",    approve=True,  reason="Acción coherente con directiva del Arquitecto")
        print(f"Atlas:    {result['status']}")

        final = protocol.check_quorum(proposal_id)
        print(f"\n🎯 Resultado final: authorized={final['authorized']} | {final['reason']}")

    elif args.status:
        result = protocol.check_quorum(args.status)
        print(json.dumps(result, indent=2, ensure_ascii=False))

    elif args.pending:
        if redis_client:
            pending = redis_client.lrange("kernell:multisign:pending", 0, 9)
            print(f"\n📋 Propuestas pendientes ({len(pending)}):")
            for raw in pending:
                event = json.loads(raw)
                print(f"  - {event.get('proposal_id')}: {event.get('action', {}).get('name')}")
        else:
            print("❌ Redis requerido para --pending")
    else:
        print("Usa --demo para ver un flujo completo | --help para opciones")


if __name__ == "__main__":
    main()
