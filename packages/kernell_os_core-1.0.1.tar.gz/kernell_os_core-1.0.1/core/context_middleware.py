#!/usr/bin/env python3
"""
core/context_middleware.py
══════════════════════════
Middleware de gestión de contexto para agentes de Kernell OS.
Integra:
  - Token Estimator (rough estimation por tipo)
  - Tool Result Persister (offload a disco)
  - Auto-Compact Manager (compactación por threshold y dimishing returns)
  - Circuit Breaker (protección contra loops)

Este módulo es el **punto de entrada único** para la gestión de contexto.
Los agentes no deben interactuar directamente con los subsistemas individuales.

Uso:
    from core.context_middleware import ContextManager

    ctx = ContextManager("nemesis")

    # Antes de cada query al LLM:
    messages = ctx.pre_query(messages)

    # Después de recibir un tool result:
    output = ctx.process_tool_result(output, tool_name="bash", tool_id="abc123")

    # Después de cada query:
    decision = ctx.post_query(response_tokens=1500)
    if decision.action == "stop":
        print(f"Agent should stop: {decision.reason}")

    # Status completo:
    print(ctx.status())
"""
import os
import sys
import json
import time
import logging
from pathlib import Path
from typing import Optional

sys.path.insert(0, str(Path(__file__).parent.parent))

from core.token_estimator import (
    estimate_tokens,
    estimate_messages_tokens,
    format_token_count,
    content_exceeds_threshold,
)
from core.tool_result_persister import ToolResultPersister
from core.auto_compact import (
    AutoCompactManager,
    BudgetDecision,
    MicroCompactManager,
    SessionMemoryCompact,
    APIMicroCompact,
)

logger = logging.getLogger("ContextMiddleware")

# Intentar importar Redis y Circuit Breaker
try:
    import redis as redis_lib
    _REDIS_AVAILABLE = True
except ImportError:
    _REDIS_AVAILABLE = False

try:
    from core.circuit_breaker import CircuitBreakerRegistry
    _CB_AVAILABLE = True
except ImportError:
    _CB_AVAILABLE = False

# Memory Paging (Letta-inspired)
try:
    from core.memory.paging_tools import (
        MemoryPager,
        PAGING_ENABLED,
        PAGING_SYSTEM_PROMPT_BLOCK,
        PAGING_TOOL_DEFINITIONS,
    )
    _PAGING_AVAILABLE = True
except ImportError:
    _PAGING_AVAILABLE = False
    PAGING_ENABLED = False


# ── Configuración ────────────────────────────────────────────────────────────

# Presupuesto de tokens por turno por defecto (puede sobreescribirse)
DEFAULT_TURN_BUDGET = {
    "overseer":   80_000,
    "nemesis":    60_000,
    "forge":      100_000,
    "atlas":      50_000,
    "sentinel":   30_000,
    "fixer":      60_000,
    "DEFAULT":    50_000,
}


# ── Context Manager ────────────────────────────────────────────────────────

class ContextManager:
    """
    Punto de entrada unificado para la gestión de contexto de un agente.
    Combina estimación de tokens, persistencia de resultados, y auto-compactación.
    """

    def __init__(
        self,
        agent_name: str,
        model_name: str = "DEFAULT",
        model_context_window: int = 128_000,
        session_id: Optional[str] = None,
        redis_client=None,
        turn_budget: Optional[int] = None,
    ):
        self.agent_name = agent_name
        self.model_name = model_name

        # Redis
        self._redis = redis_client or self._try_redis()

        # Subsistemas
        self.persister = ToolResultPersister(
            agent_name=agent_name,
            session_id=session_id,
        )
        self.compact = AutoCompactManager(
            agent_name=agent_name,
            model_name=model_name,
            model_context_window=model_context_window,
            redis_client=self._redis,
        )
        self.micro_compact = MicroCompactManager(agent_name)
        self.session_compact = SessionMemoryCompact(agent_name, redis_client=self._redis)
        self.api_compact = APIMicroCompact()

        # Budget por turno
        self.turn_budget = turn_budget or DEFAULT_TURN_BUDGET.get(
            agent_name, DEFAULT_TURN_BUDGET["DEFAULT"]
        )

        # Tracking
        self._turn_count = 0
        self._total_tokens_in = 0
        self._total_tokens_out = 0
        self._total_tokens_freed_micro = 0
        self._total_session_compacts = 0
        self._total_tool_results_processed = 0
        self._started_at = time.time()

        # Memory Paging (Letta-inspired S1)
        self._paging_enabled = _PAGING_AVAILABLE and PAGING_ENABLED
        self._pager = None
        if self._paging_enabled:
            try:
                self._pager = MemoryPager(
                    redis_client=self._redis,
                    agent_name=agent_name,
                )
            except Exception as e:
                logger.warning(f"[{agent_name}] Memory paging init failed: {e}")
                self._paging_enabled = False

        paging_tag = " +paging" if self._paging_enabled else ""
        logger.info(f"[{agent_name}] ContextManager V2 initialized — budget: {format_token_count(self.turn_budget)}/turn{paging_tag}")

    # ── Pre-Query Hook ───────────────────────────────────────────────────

    def pre_query(
        self,
        messages: list[dict],
        last_activity_ts: Optional[float] = None,
    ) -> list[dict]:
        """
        Hook ANTES de enviar mensajes al LLM.
        Hace time-based cleanup y verifica si necesita auto-compact.

        Returns:
            Lista de mensajes (potencialmente con tool results limpiados)
        """
        self._turn_count += 1

        # Estimar tokens actuales
        current_tokens = estimate_messages_tokens(messages)
        self._total_tokens_in += current_tokens

        # Log de contexto
        logger.debug(
            f"[{self.agent_name}] Turn {self._turn_count}: "
            f"{format_token_count(current_tokens)} tokens in context"
        )

        # ── Level 2: MicroCompact (tool result groups) ──
        # Run BEFORE threshold check — frees tokens without losing recent context
        messages, micro_freed = self.micro_compact.compact(messages)
        if micro_freed > 0:
            self._total_tokens_freed_micro += micro_freed
            current_tokens = estimate_messages_tokens(messages)

        # ── Level 1: AutoCompact (threshold check) ──
        messages = self.compact.pre_query_check(messages, last_activity_ts)

        # ── Level 4: APIMicroCompact (pre-send cleanup, non-destructive) ──
        # Note: this returns a COPY — original messages stay intact
        # The cleaned copy is what gets sent to the LLM API
        # We store the original for reference but expose the cleaned version
        messages = self.api_compact.clean(messages)

        # ── Background Memory Extraction (Archivist V2) ──
        # Desacoplamos contexto para destilación periódica
        if self._turn_count > 0 and self._turn_count % 15 == 0:
            try:
                from core.sea.memory_extractor import trigger_background_extraction
                trigger_background_extraction(messages, self.agent_name, self._redis)
            except ImportError:
                pass

        # Publicar métricas
        self._publish_metrics(current_tokens)

        return messages

    # ── Tool Result Processing ───────────────────────────────────────────

    def process_tool_result(
        self,
        content: str,
        tool_name: str,
        tool_id: str,
    ) -> str:
        """
        Procesa un tool result, persistiéndolo a disco si excede el umbral.

        Args:
            content:    Output del tool
            tool_name:  Nombre del tool (bash, grep, mt5_query, etc.)
            tool_id:    ID único de la invocación

        Returns:
            Content original (si corto) o preview con referencia a disco
        """
        self._total_tool_results_processed += 1

        # Circuit breaker check
        if _CB_AVAILABLE:
            cb = CircuitBreakerRegistry.get("tool_persist:write")
            if not cb.can_execute():
                logger.warning(f"[{self.agent_name}] Tool persist circuit OPEN — skipping")
                return content

        try:
            result = self.persister.maybe_persist(content, tool_name, tool_id)

            if _CB_AVAILABLE and result != content:
                # Persistencia exitosa
                CircuitBreakerRegistry.get("tool_persist:write").record_success()

            return result

        except Exception as e:
            logger.error(f"[{self.agent_name}] Tool result persist error: {e}")
            if _CB_AVAILABLE:
                CircuitBreakerRegistry.get("tool_persist:write").record_failure(str(e))
            return content  # Fallback: devolver el contenido original

    # ── Post-Query Hook ──────────────────────────────────────────────────

    def post_query(self, response_tokens: int = 0) -> BudgetDecision:
        """
        Hook DESPUÉS de recibir respuesta del LLM.
        Evalúa si el agente debe continuar o parar.

        Args:
            response_tokens: Tokens consumidos en la respuesta

        Returns:
            BudgetDecision con action="continue"|"stop" y reason
        """
        self._total_tokens_out += response_tokens

        total_session = self._total_tokens_in + self._total_tokens_out
        decision = self.compact.check_token_budget(
            budget=self.turn_budget * 10,  # Budget total de sesión ≈ 10 turnos
            current_tokens=total_session,
        )

        if decision.action == "stop":
            logger.warning(
                f"[{self.agent_name}] Budget decision: STOP — {decision.reason}"
            )

        return decision

    # ── Compaction Lifecycle ──────────────────────────────────────────────

    def compact_full(self, messages: list[dict]) -> list[dict]:
        """
        Full compaction cascade (multi-level compact pipeline):
          Level 2: MicroCompact → clear old tool results by group
          Level 3: SessionMemoryCompact → LLM-summarize old conversation
          Level 1: AutoCompact → standard threshold compaction

        Use when the context is critically close to overflow.
        """
        logger.info(f"[{self.agent_name}] ⚡ compact_full: starting cascade...")

        original_tokens = estimate_messages_tokens(messages)

        # Step 1: MicroCompact
        messages, micro_freed = self.micro_compact.compact(messages)

        # Step 2: SessionMemoryCompact (if still over threshold)
        current = estimate_messages_tokens(messages)
        if current > self.compact.auto_compact_threshold * 0.8:
            messages, summary = self.session_compact.compact(messages, keep_recent=6)
            if summary:
                self._total_session_compacts += 1
                self.compact.record_compact_success()

        # Step 3: API Cleanup
        messages = self.api_compact.clean(messages)

        final_tokens = estimate_messages_tokens(messages)
        total_freed = max(0, original_tokens - final_tokens)

        logger.info(
            f"[{self.agent_name}] ⚡ compact_full: "
            f"{format_token_count(original_tokens)} → {format_token_count(final_tokens)} "
            f"(freed {format_token_count(total_freed)})"
        )

        return messages

    def record_compact_success(self):
        """Notifica compactación exitosa (si implementas una external)."""
        self.compact.record_compact_success()
        if _CB_AVAILABLE:
            CircuitBreakerRegistry.get("compact:auto").record_success()

    def record_compact_failure(self, error: str = ""):
        """Notifica compactación fallida."""
        self.compact.record_compact_failure(error)
        if _CB_AVAILABLE:
            CircuitBreakerRegistry.get("compact:auto").record_failure(error)

    # ── Memory Paging ────────────────────────────────────────────────────

    def inject_paging_system_prompt(self, system_prompt: str) -> str:
        """
        Inyecta el bloque de paging tools en el system prompt del agente.
        Solo si paging está habilitado.
        """
        if not self._paging_enabled or not self._pager:
            return system_prompt
        # Evitar doble inyección
        if "<memory_paging>" in system_prompt:
            return system_prompt
        # ── Cache-Optimized Ordering ──────────────────────────────────────
        # Prompt caching (Anthropic, Gemini, OpenAI) works by matching prefixes.
        # Static content MUST come first, dynamic extensions LAST.
        # The paging block is semi-static (same tools every call) but we append
        # it after the base system prompt to keep the core prefix stable.
        return system_prompt + "\n" + PAGING_SYSTEM_PROMPT_BLOCK

    def optimize_prompt_for_caching(self, system_prompt: str) -> str:
        """
        Reordena el system prompt para maximizar cache hits de KV cache.
        
        Regla: contenido estático → semi-estático → dinámico.
        Los providers cachean por prefijo exacto. Si el prefijo cambia
        entre requests (ej. timestamp al inicio), el cache se invalida.
        
        Este método mueve timestamps y datos volátiles al final del prompt.
        """
        import re
        
        # Extraer y mover timestamps/fechas al final
        # Patterns: [2026-04-08], (timestamp: ...), Current time: ...
        time_patterns = [
            (re.compile(r'\[?\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}[^\]]*\]?'), 'timestamp'),
            (re.compile(r'(?:Current|Local)\s+(?:time|date|fecha)[:\s]+[^\n]+', re.IGNORECASE), 'time_header'),
        ]
        
        dynamic_parts = []
        static_prompt = system_prompt
        
        for pattern, label in time_patterns:
            matches = pattern.findall(static_prompt)
            for match in matches:
                if len(match) > 8:  # Avoid false positives on short strings
                    dynamic_parts.append(match)
                    static_prompt = static_prompt.replace(match, '', 1)
        
        # Clean up double newlines from removals
        static_prompt = re.sub(r'\n{3,}', '\n\n', static_prompt).strip()
        
        if dynamic_parts:
            dynamic_block = "\n<dynamic_context>\n" + "\n".join(dynamic_parts) + "\n</dynamic_context>"
            return static_prompt + "\n" + dynamic_block
        
        return system_prompt

    def intercept_paging_tools(self, response_text: str) -> tuple[str, str]:
        """
        Intercepta y ejecuta tool calls de paginación en la respuesta del LLM.
        Retorna (texto_limpio, contexto_extra_para_reinjectar).

        Si no hay tool calls o paging está deshabilitado, devuelve el texto
        original sin modificar y cadena vacía.
        """
        if not self._paging_enabled or not self._pager:
            return response_text, ""
        if "[TOOL_CALL:" not in response_text:
            return response_text, ""

        try:
            clean_text, tool_results = self._pager.parse_and_execute_tool_calls(response_text)
            if tool_results:
                extra_context = self._pager.format_tool_results_for_context(tool_results)
                return clean_text, extra_context
        except Exception as e:
            logger.warning(f"[{self.agent_name}] Paging tool interception failed: {e}")

        return response_text, ""

    @property
    def pager(self) -> Optional["MemoryPager"]:
        """Acceso directo al MemoryPager (puede ser None)."""
        return self._pager if self._paging_enabled else None

    # ── Status ───────────────────────────────────────────────────────────

    def status(self) -> dict:
        """Retorna el estado completo del context manager."""
        uptime = time.time() - self._started_at

        return {
            "agent": self.agent_name,
            "model": self.model_name,
            "uptime_minutes": round(uptime / 60, 1),
            "turns": self._turn_count,
            "tokens": {
                "total_in": self._total_tokens_in,
                "total_out": self._total_tokens_out,
                "total": self._total_tokens_in + self._total_tokens_out,
                "formatted": format_token_count(self._total_tokens_in + self._total_tokens_out),
            },
            "persister": self.persister.get_status(),
            "compact": self.compact.get_status(),
            "micro_compact": {
                "tokens_freed_total": self._total_tokens_freed_micro,
            },
            "session_compacts": self._total_session_compacts,
            "tool_results_processed": self._total_tool_results_processed,
            "paging": {
                "enabled": self._paging_enabled,
                "stats": self._pager.stats if self._pager else {},
            },
        }

    # ── Internals ────────────────────────────────────────────────────────

    def _try_redis(self):
        """Intenta conectar a Redis."""
        if not _REDIS_AVAILABLE:
            return None
        try:
            pw = os.getenv("REDIS_PASSWORD", "").strip().strip("\"'")
            r = redis_lib.Redis(
                host="127.0.0.1", port=6379, password=pw or None,
                decode_responses=True, socket_connect_timeout=2,
            )
            r.ping()
            return r
        except Exception:
            return None

    def _publish_metrics(self, token_count: int):
        """Publica métricas de contexto en Redis."""
        if not self._redis:
            return
        
        try:
            budget_total = self.turn_budget * 10
            used = self._total_tokens_in + self._total_tokens_out
            pct_used = round((used / budget_total) * 100) if budget_total > 0 else 0

            key = f"kernell:context:{self.agent_name}"
            self._redis.hset(key, mapping={
                "turn": self._turn_count,
                "tokens_current": token_count,
                "tokens_total_in": self._total_tokens_in,
                "tokens_total_out": self._total_tokens_out,
                "tool_results": self._total_tool_results_processed,
                "persisted_files": self.persister.total_persisted,
                "tokens_saved_by_persist": self.persister.total_tokens_saved,
                # New Compaction Metrics (Phase 2)
                "tokens_freed_micro": self._total_tokens_freed_micro,
                "session_compacts": self._total_session_compacts,
                "auto_compact_failures": getattr(self.compact.tracking, "consecutive_failures", 0),
                "budget_pct_used": pct_used,
                "last_updated": time.time(),
            })
            self._redis.expire(key, 86400)
        except Exception as e:
            logger.debug(f"Failed to publish context metrics: {e}")


# ── Factory ──────────────────────────────────────────────────────────────────

_managers: dict[str, ContextManager] = {}


def get_context_manager(
    agent_name: str,
    model_name: str = "DEFAULT",
    model_context_window: int = 128_000,
    **kwargs,
) -> ContextManager:
    """
    Singleton factory: un ContextManager por agente.

    Uso:
        from core.context_middleware import get_context_manager
        ctx = get_context_manager("nemesis", model_name="gemini-2.5-pro")
    """
    if agent_name not in _managers:
        _managers[agent_name] = ContextManager(
            agent_name=agent_name,
            model_name=model_name,
            model_context_window=model_context_window,
            **kwargs,
        )
    return _managers[agent_name]


def all_status() -> dict:
    """Retorna status de todos los context managers activos."""
    return {name: mgr.status() for name, mgr in _managers.items()}


# ── CLI ───────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Context Middleware — Kernell OS")
    parser.add_argument("--demo", action="store_true", help="Run integration demo")
    parser.add_argument("--status", action="store_true", help="Show all active managers")
    args = parser.parse_args()

    if args.demo:
        print("═" * 60)
        print("  CONTEXT MIDDLEWARE — Integration Demo")
        print("═" * 60)

        ctx = ContextManager("demo_agent", model_context_window=200_000)

        # 1. Pre-query
        messages = [
            {"role": "user", "content": "Analyze the codebase"},
            {"role": "assistant", "content": "I'll look at the structure..."},
        ]
        messages = ctx.pre_query(messages)
        print(f"\n✅ pre_query: {len(messages)} messages processed")

        # 2. Process tool result (small)
        small_out = "File found: main.py"
        result = ctx.process_tool_result(small_out, "grep", "grep_001")
        print(f"✅ process_tool_result (small): {len(result)} chars — NOT persisted")

        # 3. Process tool result (big)
        big_out = "\n".join(f"Match {i}: {'result_data' * 50}" for i in range(500))
        result = ctx.process_tool_result(big_out, "bash", "bash_001")
        print(f"✅ process_tool_result (big): {len(big_out):,} → {len(result):,} chars — PERSISTED")

        # 4. Post-query
        decision = ctx.post_query(response_tokens=2000)
        print(f"✅ post_query: {decision.action} — {decision.reason}")

        # 5. Status
        status = ctx.status()
        print(f"\n📊 Status:")
        print(f"   Turns: {status['turns']}")
        print(f"   Tokens total: {status['tokens']['formatted']}")
        print(f"   Persisted files: {status['persister']['total_persisted']}")
        print(f"   Tokens saved: {status['persister']['tokens_saved']}")

        print(f"\n{'═' * 60}")
        print("  INTEGRATION DEMO COMPLETE ✅")
        print(f"{'═' * 60}")

    elif args.status:
        print(json.dumps(all_status(), indent=2, default=str))

    else:
        parser.print_help()
