#!/usr/bin/env python3
"""
core/token_estimator.py
═══════════════════════
Estimador rough de tokens para Kernell OS.
Token estimation utilities for context window management in Kernell OS.

No requiere API — estima localmente usando bytes-per-token por tipo de archivo.
Conservador: aplica un pad de 33% (4/3) para evitar subestimaciones.

Uso:
    from core.token_estimator import estimate_tokens, estimate_messages_tokens

    tokens = estimate_tokens("hello world")                    # ~3
    tokens = estimate_tokens('{"key":"val"}', file_type="json") # ~7 (json = denser)
    tokens = estimate_messages_tokens(messages_list)            # sum con pad
"""
import json
import math
from typing import Union, Any

# ── Bytes-per-token por tipo de contenido ─────────────────────────────────────
# JSON tiene muchos caracteres de 1 token ({, }, :, ", ,)
# YAML es similar pero con menos overhead
# Texto normal promedia ~4 bytes por token en modelos modernos

BYTES_PER_TOKEN = {
    "text":     4,
    "txt":      4,
    "md":       4,
    "py":       4,
    "js":       4,
    "ts":       4,
    "sh":       4,
    "yaml":     3,
    "yml":      3,
    "toml":     3,
    "json":     2,
    "jsonl":    2,
    "jsonc":    2,
    "csv":      3,
    "xml":      2,
    "html":     2,
}

# Constantes fijas para contenido no-textual
IMAGE_TOKEN_SIZE = 2000
PDF_TOKEN_SIZE   = 2000

# Factor de seguridad: 33% extra para ser conservador (solo para heurística)
SAFETY_FACTOR = 4 / 3

# ── tiktoken precision layer ─────────────────────────────────────────────────
# If tiktoken is installed, use exact token counting instead of byte heuristics.
# Falls back gracefully to the heuristic if not available.

_tiktoken_enc = None
_TIKTOKEN_AVAILABLE = False

try:
    import tiktoken
    _tiktoken_enc = tiktoken.encoding_for_model("gpt-4o")
    _TIKTOKEN_AVAILABLE = True
except (ImportError, Exception):
    pass


def _count_tokens_precise(text: str) -> int:
    """Count tokens precisely using tiktoken. Returns -1 if unavailable."""
    if not _TIKTOKEN_AVAILABLE or _tiktoken_enc is None:
        return -1
    try:
        return len(_tiktoken_enc.encode(text, disallowed_special=()))
    except Exception:
        return -1


def estimate_tokens(
    content: str,
    file_type: str = "text",
    apply_safety: bool = True,
) -> int:
    """
    Estima tokens para un string de texto.
    Uses tiktoken (exact) when available, falls back to byte heuristic.

    Args:
        content:      El texto a estimar
        file_type:    Extensión del archivo (json, yaml, py, etc.)
        apply_safety: Si True, aplica el pad de 33% (solo en modo heurístico)

    Returns:
        Número estimado de tokens
    """
    if not content:
        return 0

    # Precise path: tiktoken (no safety pad needed — count is exact)
    precise = _count_tokens_precise(content)
    if precise >= 0:
        return precise

    # Heuristic fallback: bytes-per-token estimation
    bpt = BYTES_PER_TOKEN.get(file_type.lower().lstrip("."), 4)
    raw = math.ceil(len(content) / bpt)

    if apply_safety:
        return math.ceil(raw * SAFETY_FACTOR)
    return raw


def estimate_block_tokens(block: dict) -> int:
    """
    Estima tokens de un bloque de contenido (tool_result, text, image, etc.).
    Compatible con el formato de mensajes Anthropic/OpenAI.
    """
    block_type = block.get("type", "")

    if block_type == "text":
        return estimate_tokens(block.get("text", ""), apply_safety=False)

    if block_type in ("image", "document"):
        return IMAGE_TOKEN_SIZE

    if block_type == "tool_result":
        content = block.get("content", "")
        if isinstance(content, str):
            return estimate_tokens(content, apply_safety=False)
        if isinstance(content, list):
            return sum(estimate_block_tokens(b) for b in content)
        return 0

    if block_type == "tool_use":
        name = block.get("name", "")
        inp = block.get("input", {})
        serialized = name + json.dumps(inp, default=str)
        return estimate_tokens(serialized, file_type="json", apply_safety=False)

    if block_type == "thinking":
        return estimate_tokens(block.get("thinking", ""), apply_safety=False)

    # Fallback: serializar como JSON
    try:
        return estimate_tokens(json.dumps(block, default=str), file_type="json", apply_safety=False)
    except Exception:
        return 100  # Estimación segura mínima


def estimate_message_tokens(message: dict) -> int:
    """
    Estima tokens de un mensaje individual del historial.

    Args:
        message: Dict con al menos 'role' y 'content'

    Returns:
        Tokens estimados (sin safety pad — el pad se aplica al total)
    """
    content = message.get("content", "")

    if isinstance(content, str):
        return estimate_tokens(content, apply_safety=False)

    if isinstance(content, list):
        return sum(estimate_block_tokens(b) for b in content)

    return 0


def estimate_messages_tokens(
    messages: list[dict],
    apply_safety: bool = True,
) -> int:
    """
    Estima el total de tokens de una lista de mensajes.
    Aplica el safety pad de 33% al total.

    Args:
        messages:     Lista de mensajes [{role, content}, ...]
        apply_safety: Si True, aplica el pad de 33% al total

    Returns:
        Tokens totales estimados
    """
    total = sum(estimate_message_tokens(m) for m in messages)

    if apply_safety:
        return math.ceil(total * SAFETY_FACTOR)
    return total


# ── Utilidades para el Agent Swarm ────────────────────────────────────────────

def content_exceeds_threshold(content: str, threshold_tokens: int) -> bool:
    """Verifica rápidamente si un contenido excede un umbral de tokens."""
    return estimate_tokens(content) > threshold_tokens


def format_token_count(tokens: int) -> str:
    """Formatea tokens para display humano."""
    if tokens >= 1_000_000:
        return f"{tokens / 1_000_000:.1f}M"
    if tokens >= 1_000:
        return f"{tokens / 1_000:.1f}K"
    return str(tokens)


# ── CLI ───────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import sys

    if len(sys.argv) > 1:
        filepath = sys.argv[1]
        ext = filepath.rsplit(".", 1)[-1] if "." in filepath else "text"
        with open(filepath) as f:
            content = f.read()
        raw = estimate_tokens(content, file_type=ext, apply_safety=False)
        safe = estimate_tokens(content, file_type=ext, apply_safety=True)
        print(f"📊 {filepath}")
        print(f"   Bytes:           {len(content):,}")
        print(f"   File type:       {ext} ({BYTES_PER_TOKEN.get(ext, 4)} bytes/token)")
        print(f"   Tokens (raw):    {format_token_count(raw)}")
        print(f"   Tokens (padded): {format_token_count(safe)}")
    else:
        # Demo
        samples = [
            ("Hello world", "text"),
            ('{"users": [{"name": "John", "age": 30}]}', "json"),
            ("key: value\nlist:\n  - item1\n  - item2", "yaml"),
            ("def foo():\n    return 42", "py"),
        ]
        print("📊 Token Estimator Demo\n")
        for text, ft in samples:
            t = estimate_tokens(text, file_type=ft)
            print(f"  [{ft:>5}] {t:>4} tokens | {text[:50]}")
