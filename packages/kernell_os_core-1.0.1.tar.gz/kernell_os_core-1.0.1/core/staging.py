"""
Staging / paper gates: bloquea operaciones de alto riesgo fuera de producción.

Entorno (orden): KERNELL_ENV → Redis kernell:system:environment → production.
"""

from __future__ import annotations

import functools
import json
import logging
import os
import time
from enum import Enum
from typing import Any, Callable, Optional

logger = logging.getLogger("kernell.staging")


class Environment(str, Enum):
    PRODUCTION = "production"
    STAGING = "staging"
    PAPER = "paper"


HIGH_RISK_OPS = frozenset(
    {
        "open_trade",
        "close_trade",
        "modify_trade",
        "send_order",
        "mt5_order",
        "binance_order",
        "execute_signal",
        "stripe_charge",
        "stripe_refund",
        "stripe_subscription",
        "paypal_payment",
        "crypto_transfer",
        "send_bulk_email",
        "send_campaign",
        "apply_mutation",
        "os_mutate",
        "kernel_patch",
        "publish_post",
        "post_to_instagram",
        "post_to_tiktok",
        "post_to_twitter",
        "post_to_facebook",
        "create_order",
        "fulfill_order",
        "shopify_webhook",
    }
)


class StagingGate:
    REDIS_ENV_KEY = "kernell:system:environment"
    REDIS_STAGING_LOG = "kernell:staging:blocked_ops"

    def __init__(self, redis_client: Any = None) -> None:
        self.redis = redis_client
        self._env_cache: Optional[Environment] = None
        self._cache_ts: float = 0.0
        self._cache_ttl: float = 30.0

    @property
    def environment(self) -> Environment:
        now = time.time()
        if self._env_cache is not None and (now - self._cache_ts) < self._cache_ttl:
            return self._env_cache

        env_var = os.environ.get("KERNELL_ENV", "").strip().lower()
        if env_var in Environment._value2member_map_:
            self._env_cache = Environment(env_var)
            self._cache_ts = now
            return self._env_cache

        if self.redis:
            try:
                val = self.redis.get(self.REDIS_ENV_KEY)
                if val:
                    env_str = val.decode() if isinstance(val, bytes) else str(val)
                    el = env_str.strip().lower()
                    if el in Environment._value2member_map_:
                        self._env_cache = Environment(el)
                        self._cache_ts = now
                        return self._env_cache
            except Exception:
                pass

        self._env_cache = Environment.PRODUCTION
        self._cache_ts = now
        return self._env_cache

    @property
    def is_production(self) -> bool:
        return self.environment == Environment.PRODUCTION

    @property
    def is_staging(self) -> bool:
        return self.environment in (Environment.STAGING, Environment.PAPER)

    def allow(self, agent: str, operation: str) -> bool:
        if self.is_production:
            return True
        if operation in HIGH_RISK_OPS:
            self._log_blocked(agent, operation)
            logger.info(
                "[STAGING] blocked agent=%s op=%s env=%s",
                agent,
                operation,
                self.environment,
            )
            return False
        return True

    def mock_response(self, operation: str, params: Optional[dict] = None) -> dict[str, Any]:
        params = params or {}
        mocks: dict[str, dict[str, Any]] = {
            "open_trade": {
                "ticket": f"MOCK-{int(time.time())}",
                "symbol": params.get("symbol", "EURUSD"),
                "volume": params.get("volume", 0.01),
                "price": 1.0850,
                "status": "mock_filled",
                "staging": True,
            },
            "stripe_charge": {
                "id": f"mock_ch_{int(time.time())}",
                "amount": params.get("amount", 0),
                "status": "mock_succeeded",
                "staging": True,
            },
            "send_bulk_email": {
                "sent": 0,
                "queued": params.get("count", 0),
                "status": "mock_queued",
                "staging": True,
            },
            "publish_post": {
                "post_id": f"mock_{int(time.time())}",
                "platform": params.get("platform", "unknown"),
                "status": "mock_published",
                "staging": True,
            },
        }
        return mocks.get(
            operation,
            {
                "status": "mock_ok",
                "operation": operation,
                "staging": True,
                "ts": time.time(),
            },
        )

    def set_environment(self, env: Environment) -> None:
        if self.redis:
            try:
                self.redis.set(self.REDIS_ENV_KEY, env.value)
                self.redis.publish(
                    "kernell:events:system",
                    json.dumps(
                        {
                            "type": "environment_changed",
                            "environment": env.value,
                            "ts": time.time(),
                        }
                    ),
                )
            except Exception as e:
                logger.error("set_environment Redis error: %s", e)
        self._env_cache = env
        self._cache_ts = time.time()
        logger.info("environment set to %s", env.value)

    def _log_blocked(self, agent: str, operation: str) -> None:
        if not self.redis:
            return
        try:
            entry = json.dumps(
                {
                    "ts": time.time(),
                    "agent": agent,
                    "operation": operation,
                    "environment": self.environment.value,
                }
            )
            self.redis.lpush(self.REDIS_STAGING_LOG, entry)
            self.redis.ltrim(self.REDIS_STAGING_LOG, 0, 499)
        except Exception:
            pass


_default_gate = StagingGate()


def staging_guard(
    agent: str, operation: str, gate: Optional[StagingGate] = None
) -> Callable[[Callable], Callable]:
    def decorator(func: Callable) -> Callable:
        g = gate or _default_gate

        @functools.wraps(func)
        async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
            if not g.allow(agent, operation):
                return g.mock_response(operation, kwargs)
            return await func(*args, **kwargs)

        @functools.wraps(func)
        def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
            if not g.allow(agent, operation):
                return g.mock_response(operation, kwargs)
            return func(*args, **kwargs)

        import asyncio

        if asyncio.iscoroutinefunction(func):
            return async_wrapper
        return sync_wrapper

    return decorator


class PaperTradingMode:
    """Context manager: fuerza entorno PAPER vía Redis y restaura al salir."""

    def __init__(self, redis_client: Any = None) -> None:
        self._gate = StagingGate(redis_client)
        self._prev_env: Optional[Environment] = None

    def __enter__(self) -> StagingGate:
        self._prev_env = self._gate.environment
        self._gate.set_environment(Environment.PAPER)
        logger.info("PaperTradingMode on")
        return self._gate

    def __exit__(self, *args: Any) -> None:
        if self._prev_env is not None:
            self._gate.set_environment(self._prev_env)
        logger.info("PaperTradingMode restored to %s", self._prev_env)
