#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════╗
║     KERNELL OS — QDRANT COLLECTIONS INITIALIZER v1.0                   ║
║     Crea/verifica colecciones al arranque + gestiona backups.          ║
║     Se ejecuta en boot_sequence.py antes de lanzar agentes.             ║
╚══════════════════════════════════════════════════════════════════════════╝
"""

import asyncio
import logging
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

from qdrant_client import AsyncQdrantClient
from qdrant_client.models import (
    Distance, VectorParams, HnswConfigDiff,
    OptimizersConfigDiff,
    CollectionStatus,
)

log = logging.getLogger("collections_init")
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [COLLECTIONS] %(levelname)s %(message)s"
)

QDRANT_URL = os.getenv("QDRANT_URL", "http://localhost:6333")
EMBED_DIM  = 768    # gemini text-embedding-004 (Kernell OS standard)

# ─── DEFINICIÓN COMPLETA DE COLECCIONES ──────────────────────────────────────

# NOTA: Antes había varias claves duplicadas "kernell_memory"; en Python solo
# sobrevive la última → el init real solo tocaba 2 nombres y el resto del
# diseño nunca se aplicaba. Mantener solo colecciones usadas en el código vivo.
COLLECTIONS = {
    "kernell_memory": {
        "description": "Memoria principal del enjambre (RAG, skills, conocimiento)",
        "config": VectorParams(
            size=EMBED_DIM,
            distance=Distance.COSINE,
            on_disk=False,
        ),
        "hnsw": HnswConfigDiff(
            m=16,
            ef_construct=100,
            full_scan_threshold=10000,
            on_disk=False,
        ),
        "optimizer": OptimizersConfigDiff(
            deleted_threshold=0.2,
            vacuum_min_vector_number=1000,
            indexing_threshold=20000,
        ),
    },
    "kernell_episodes": {
        "description": "Episodios causales: observación → decisión → outcome",
        "config": VectorParams(
            size=EMBED_DIM,
            distance=Distance.COSINE,
            on_disk=False,
        ),
        "hnsw": HnswConfigDiff(
            m=32,
            ef_construct=200,
            on_disk=False,
        ),
        "optimizer": OptimizersConfigDiff(
            deleted_threshold=0.1,
            indexing_threshold=5000,
        ),
    },
    # Legacy / reservadas: mismas dims que el estándar; suelen existir en nodos antiguos.
    # Incluidas aquí para que initialize_all() verifique/creé y el boot no ignore el drift.
    "kernell_fusion": {
        "description": "Legacy: fusión / experimentos (768d)",
        "config": VectorParams(size=EMBED_DIM, distance=Distance.COSINE, on_disk=False),
        "hnsw": HnswConfigDiff(m=16, ef_construct=100, full_scan_threshold=10000, on_disk=False),
        "optimizer": OptimizersConfigDiff(deleted_threshold=0.2, indexing_threshold=20000),
    },
    "kernell_skills": {
        "description": "Legacy: skills vectorizados (768d)",
        "config": VectorParams(size=EMBED_DIM, distance=Distance.COSINE, on_disk=False),
        "hnsw": HnswConfigDiff(m=16, ef_construct=100, full_scan_threshold=10000, on_disk=False),
        "optimizer": OptimizersConfigDiff(deleted_threshold=0.2, indexing_threshold=20000),
    },
    "kernell_knowledge": {
        "description": "Legacy: knowledge chunks (768d)",
        "config": VectorParams(size=EMBED_DIM, distance=Distance.COSINE, on_disk=False),
        "hnsw": HnswConfigDiff(m=16, ef_construct=100, full_scan_threshold=10000, on_disk=False),
        "optimizer": OptimizersConfigDiff(deleted_threshold=0.2, indexing_threshold=20000),
    },
    "kernell_interactions": {
        "description": "Legacy: interacciones / turnos (768d)",
        "config": VectorParams(size=EMBED_DIM, distance=Distance.COSINE, on_disk=False),
        "hnsw": HnswConfigDiff(m=16, ef_construct=100, full_scan_threshold=10000, on_disk=False),
        "optimizer": OptimizersConfigDiff(deleted_threshold=0.2, indexing_threshold=20000),
    },
}


# ─── INITIALIZER ──────────────────────────────────────────────────────────────

class CollectionsInitializer:

    def __init__(self):
        self.client = None
        self.results = {}

    async def connect(self) -> bool:
        try:
            self.client = AsyncQdrantClient(url=QDRANT_URL, timeout=15)
            info = await self.client.get_collections()
            log.info(
                f"✅ Qdrant conectado. Colecciones existentes: "
                f"{[c.name for c in info.collections]}"
            )
            return True
        except Exception as e:
            log.error(f"❌ No se puede conectar a Qdrant: {e}")
            return False

    async def initialize_all(self) -> dict:
        """Crea las colecciones faltantes, verifica las existentes."""
        if not await self.connect():
            return {"status": "ERROR", "reason": "Qdrant no disponible"}

        existing = await self._get_existing_collections()
        log.info(f"Colecciones en Qdrant: {existing}")

        for name, cfg in COLLECTIONS.items():
            if name in existing:
                status = await self._verify_existing(name)
                self.results[name] = status
            else:
                status = await self._create_collection(name, cfg)
                self.results[name] = status

        self._print_summary()
        return self.results

    async def _get_existing_collections(self) -> list:
        info = await self.client.get_collections()
        return [c.name for c in info.collections]

    async def _verify_existing(self, name: str) -> dict:
        try:
            info = await self.client.get_collection(name)
            # qdrant-client expone points_count; algunas rutas REST usan vectors_count
            vectors = getattr(info, "points_count", None)
            if vectors is None:
                vectors = getattr(info, "vectors_count", None)
            if vectors is None:
                vectors = 0
            status_ok = info.status == CollectionStatus.GREEN

            result = {
                "action":  "VERIFIED",
                "status":  "OK" if status_ok else "DEGRADED",
                "vectors": vectors,
                "health":  info.status.value if hasattr(info.status, 'value') else str(info.status),
            }

            if not status_ok:
                log.warning(f"⚠️ {name}: estado {info.status} — puede necesitar optimización")
            else:
                log.info(f"✅ {name}: OK ({vectors} vectores)")

            return result

        except Exception as e:
            log.error(f"❌ Error verificando {name}: {e}")
            return {"action": "VERIFY_FAILED", "status": "ERROR", "error": str(e)}

    async def _create_collection(self, name: str, cfg: dict) -> dict:
        try:
            kwargs = {
                "collection_name": name,
                "vectors_config":  cfg["config"],
            }
            if "hnsw" in cfg:
                kwargs["hnsw_config"] = cfg["hnsw"]
            if "optimizer" in cfg:
                kwargs["optimizers_config"] = cfg["optimizer"]

            # Use recreate to handle orphaned data on disk (e.g. after RAMDisk crash)
            try:
                await self.client.recreate_collection(**kwargs)
            except Exception:
                # Fallback to create if recreate not available
                await self.client.create_collection(**kwargs)

            info = await self.client.get_collection(name)
            log.info(
                f"✅ CREADA: {name} — {cfg.get('description', '')} "
                f"(estado: {info.status})"
            )

            return {
                "action":      "CREATED",
                "status":      "OK",
                "description": cfg.get("description", ""),
                "vectors":     0,
            }

        except Exception as e:
            log.error(f"❌ Error creando {name}: {e}")
            return {"action": "CREATE_FAILED", "status": "ERROR", "error": str(e)}

    def _print_summary(self):
        log.info("\n" + "═" * 60)
        log.info("RESUMEN DE INICIALIZACIÓN DE COLECCIONES")
        log.info("═" * 60)
        all_ok = True
        for name, result in self.results.items():
            icon  = "✅" if result["status"] == "OK" else "❌"
            act   = result.get("action", "?")
            vecs  = result.get("vectors", "?")
            log.info(f"  {icon} {name:<30} [{act}] {vecs} vectores")
            if result["status"] != "OK":
                all_ok = False
        log.info("═" * 60)
        log.info(f"Estado global: {'✅ TODO OK' if all_ok else '⚠️ HAY ERRORES'}")
        log.info("═" * 60 + "\n")


# ─── BACKUP MANAGER ───────────────────────────────────────────────────────────

class QdrantBackupManager:
    """
    Gestiona snapshots de Qdrant hacia disco.
    Ejecutado por Chronos cada 6 horas.
    """

    BACKUP_DIR = "/home/anny/kernell-os/data/qdrant_persistent/snapshots"
    MAX_SNAPSHOTS = 8

    def __init__(self):
        self.client = None

    async def connect(self):
        self.client = AsyncQdrantClient(url=QDRANT_URL, timeout=30)

    async def create_all_snapshots(self) -> dict:
        """Crea un snapshot de todas las colecciones"""
        import aiohttp

        if not await self._ensure_backup_dir():
            return {"status": "ERROR", "reason": "No se puede crear directorio de backup"}

        results = {}
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")

        async with aiohttp.ClientSession() as session:
            async with session.get(f"{QDRANT_URL}/collections") as r:
                data = await r.json()
                collections = [
                    c["name"]
                    for c in data.get("result", {}).get("collections", [])
                ]

            for col in collections:
                try:
                    async with session.post(
                        f"{QDRANT_URL}/collections/{col}/snapshots",
                        timeout=aiohttp.ClientTimeout(total=60)
                    ) as r:
                        snap_data = await r.json()
                        snap_name = snap_data.get("result", {}).get("name", "")

                    if not snap_name:
                        results[col] = {"status": "ERROR", "reason": "Sin nombre de snapshot"}
                        continue

                    dest_dir = Path(self.BACKUP_DIR) / col
                    dest_dir.mkdir(parents=True, exist_ok=True)
                    dest_file = dest_dir / f"{timestamp}_{snap_name}"

                    async with session.get(
                        f"{QDRANT_URL}/collections/{col}/snapshots/{snap_name}",
                        timeout=aiohttp.ClientTimeout(total=120)
                    ) as r:
                        with open(dest_file, "wb") as f:
                            async for chunk in r.content.iter_chunked(65536):
                                f.write(chunk)

                    size_mb = dest_file.stat().st_size / 1024 / 1024
                    results[col] = {
                        "status": "OK",
                        "file":   str(dest_file),
                        "size_mb": round(size_mb, 2),
                        "ts":     timestamp,
                    }
                    log.info(f"✅ Backup {col}: {size_mb:.2f}MB → {dest_file}")

                    async with session.delete(
                        f"{QDRANT_URL}/collections/{col}/snapshots/{snap_name}"
                    ):
                        pass

                    await self._rotate_backups(dest_dir)

                except Exception as e:
                    results[col] = {"status": "ERROR", "reason": str(e)}
                    log.error(f"❌ Error backup {col}: {e}")

        return {"status": "OK", "timestamp": timestamp, "collections": results}

    async def restore_on_boot(self) -> dict:
        """Restaura desde el último snapshot al arranque si Qdrant está vacío."""
        import aiohttp

        backup_dir = Path(self.BACKUP_DIR)
        if not backup_dir.exists():
            return {"status": "NO_BACKUP", "reason": "Directorio de backup no existe"}

        results = {}

        async with aiohttp.ClientSession() as session:
            for col_dir in backup_dir.iterdir():
                if not col_dir.is_dir():
                    continue
                col_name = col_dir.name

                snapshots = sorted(col_dir.glob("*.snapshot"), reverse=True)
                if not snapshots:
                    snapshots = sorted(col_dir.iterdir(), reverse=True)
                if not snapshots:
                    log.warning(f"⚠️ Sin snapshots para {col_name}")
                    continue

                latest = snapshots[0]
                log.info(f"🔄 Restaurando {col_name} desde {latest.name}...")

                try:
                    with open(latest, "rb") as f:
                        data = aiohttp.FormData()
                        data.add_field("snapshot", f,
                                       filename=latest.name,
                                       content_type="application/octet-stream")
                        async with session.post(
                            f"{QDRANT_URL}/collections/{col_name}/snapshots/upload",
                            data=data,
                            timeout=aiohttp.ClientTimeout(total=120)
                        ) as r:
                            await r.json()

                    results[col_name] = {
                        "status": "OK",
                        "file":   latest.name,
                        "ts":     datetime.now(timezone.utc).isoformat(),
                    }
                    log.info(f"✅ {col_name} restaurado desde {latest.name}")

                except Exception as e:
                    results[col_name] = {"status": "ERROR", "reason": str(e)}
                    log.error(f"❌ Error restaurando {col_name}: {e}")

        return {"status": "OK", "restored": results}

    async def _ensure_backup_dir(self) -> bool:
        try:
            Path(self.BACKUP_DIR).mkdir(parents=True, exist_ok=True)
            return True
        except Exception as e:
            log.error(f"Error creando dir backup: {e}")
            return False

    async def _rotate_backups(self, col_dir):
        files = sorted(col_dir.iterdir(), key=lambda f: f.stat().st_mtime, reverse=True)
        for old in files[self.MAX_SNAPSHOTS:]:
            try:
                old.unlink()
                log.info(f"🗑️ Backup rotado: {old.name}")
            except Exception:
                pass


# ─── ENTRY POINT ──────────────────────────────────────────────────────────────

async def run_init():
    """Llamado desde boot_sequence.py al arranque"""
    log.info("🚀 Inicializando colecciones Qdrant...")
    init = CollectionsInitializer()
    results = await init.initialize_all()

    # Suma de vectores en todas las colecciones gestionadas por este init
    total_vectors = 0
    for r in results.values():
        if isinstance(r, dict) and r.get("status") == "OK":
            try:
                total_vectors += int(r.get("vectors") or 0)
            except (TypeError, ValueError):
                pass

    # Solo restaurar desde snapshots en disco si Qdrant quedó totalmente vacío
    # tras verify/create. Evita restore agresivo cuando ya hay datos (p. ej.
    # tras kernell-qdrant-restore → RAM) o cuando antes se leía mal points_count.
    if total_vectors == 0:
        log.warning(
            "⚠️ Qdrant: 0 vectores en colecciones Kernell tras init — "
            "intentando restore desde snapshots locales..."
        )
        backup_mgr = QdrantBackupManager()
        restore_result = await backup_mgr.restore_on_boot()
        log.info(f"Restore result: {restore_result}")
    else:
        log.info(
            f"✅ Qdrant: {total_vectors} vectores presentes — "
            "omitido restore_on_boot (datos ya cargados)"
        )

    return results


async def run_backup():
    """Llamado por Chronos cada 6 horas"""
    log.info("💾 Iniciando backup de Qdrant...")
    mgr = QdrantBackupManager()
    result = await mgr.create_all_snapshots()
    log.info(f"Backup completado: {result}")
    return result


if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "init"
    if mode == "backup":
        asyncio.run(run_backup())
    else:
        asyncio.run(run_init())
