#!/usr/bin/env python3
"""
core/memory/auto_dream.py
══════════════════════════
AutoDream — Background Memory Consolidation Daemon — Kernell OS

When the system is idle, AutoDream:
  1. Scans recent sessions for accumulated knowledge
  2. Runs a lightweight LLM pass to consolidate lessons learned
  3. Updates memory files (rules, patterns, errors) without blocking main agents

Gate system (cheapest first):
  1. Time gate:     Hours since last consolidation ≥ minHours (default 24)
  2. Session gate:  Number of new sessions since last consolidation ≥ minSessions (default 5)
  3. Lock gate:     No other dream process currently running
  4. Scan throttle: Don't re-scan more than once per 10 minutes

Integration:
    from core.memory.auto_dream import AutoDreamDaemon

    daemon = AutoDreamDaemon(redis_client=r)
    daemon.start()  # Background thread

    # Or run manually:
    daemon.run_consolidation()

Sovereign Architecture — Blueprint XV
"""

import os
import sys
import json
import time
import logging
import threading
from pathlib import Path
from datetime import datetime, timezone
from typing import Optional, List, Dict, Any
from dataclasses import dataclass, field

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

logger = logging.getLogger("AutoDream")

# ── Configuration ────────────────────────────────────────────────────────────

# Minimum hours between consolidations
DEFAULT_MIN_HOURS = 24

# Minimum new sessions required to trigger consolidation
DEFAULT_MIN_SESSIONS = 5

# Scan throttle — don't re-scan sessions more often than this
SCAN_INTERVAL_SECONDS = 600  # 10 minutes

# Maximum sessions to review in one consolidation
MAX_SESSIONS_PER_DREAM = 20

# Derive paths from environment or project root
_PROJECT_ROOT = Path(os.environ.get("KERNELL_ROOT", str(Path(__file__).parent.parent.parent)))
_DATA_DIR = Path(os.environ.get("KERNELL_DATA_DIR", str(_PROJECT_ROOT / "data")))

# Lock file path
LOCK_FILE = _DATA_DIR / "auto_dream.lock"

# Memory output directory
MEMORY_DIR = _DATA_DIR / "memory" / "auto_dream"

# Session transcripts directory
TRANSCRIPTS_DIR = _DATA_DIR / "sessions"


# ── Data Types ───────────────────────────────────────────────────────────────

@dataclass
class DreamConfig:
    """AutoDream scheduling configuration."""
    min_hours: int = DEFAULT_MIN_HOURS
    min_sessions: int = DEFAULT_MIN_SESSIONS
    enabled: bool = True
    dry_run: bool = False


@dataclass
class DreamState:
    """Current state of the AutoDream daemon."""
    last_consolidation_at: float = 0
    last_scan_at: float = 0
    sessions_reviewed: int = 0
    total_consolidations: int = 0
    is_running: bool = False
    last_error: str = ""
    files_touched: List[str] = field(default_factory=list)


@dataclass
class SessionSummary:
    """Summary of a session transcript for consolidation."""
    session_id: str
    timestamp: float
    agent: str
    task_summary: str
    decisions: List[str]
    errors: List[str]
    files_modified: List[str]


# ── Consolidation Prompt ─────────────────────────────────────────────────────

CONSOLIDATION_SYSTEM_PROMPT = """You are the Dream Agent for Kernell OS — a sovereign AI operating system.

Your role is to review recent session transcripts and consolidate the knowledge into
structured memory files. You operate during system idle time, improving the collective
intelligence of all agents.

## Your Task

Review the provided session summaries and:

1. **Extract Rules**: Identify recurring patterns, successful strategies, and things
   that consistently work. Write as if-then rules.

2. **Document Errors**: Record errors encountered and their resolutions. Future agents
   should not repeat the same debugging cycle.

3. **Update Patterns**: Identify workflow patterns that emerged across sessions.
   What sequence of actions led to success?

4. **Flag Improvements**: Note areas where agents struggled or took too many iterations.
   Suggest process improvements.

## Output Format

Produce a JSON object with these keys:
```json
{
  "rules_learned": ["rule 1", "rule 2", ...],
  "errors_documented": [{"error": "desc", "resolution": "fix"}, ...],
  "patterns_found": [{"name": "pattern name", "description": "...", "steps": ["step 1", ...]}, ...],
  "improvements": ["suggestion 1", ...],
  "summary": "One paragraph summary of key learnings"
}
```

Be concise but specific. Prefer actionable knowledge over general observations.
Maximum 500 words total."""


# ── Consolidation Lock ───────────────────────────────────────────────────────

class ConsolidationLock:
    """
    File-based lock for consolidation process.
    Uses mtime of the lock file to track last consolidation time.
    """

    def __init__(self, lock_path: Path = LOCK_FILE):
        self.lock_path = lock_path
        self.lock_path.parent.mkdir(parents=True, exist_ok=True)

    def read_last_consolidated_at(self) -> float:
        """Return the timestamp of the last consolidation."""
        try:
            if self.lock_path.exists():
                return self.lock_path.stat().st_mtime
        except Exception:
            pass
        return 0

    def try_acquire(self) -> Optional[float]:
        """
        Attempt to acquire the consolidation lock.

        Returns the prior mtime if acquired, None if lock is held.
        Acquiring = touching the file to set mtime to now.
        """
        try:
            prior = self.read_last_consolidated_at()

            # Check if another process touched it very recently (within 60s)
            if prior > 0 and (time.time() - prior) < 60:
                # Might be another process — check for PID file
                pid_file = self.lock_path.with_suffix(".pid")
                if pid_file.exists():
                    try:
                        pid = int(pid_file.read_text().strip())
                        # Check if PID is still running
                        os.kill(pid, 0)
                        return None  # Process is running
                    except (ValueError, ProcessLookupError, PermissionError):
                        pass  # Process is dead, steal the lock

            # Acquire: write our PID and touch the lock file
            pid_file = self.lock_path.with_suffix(".pid")
            pid_file.write_text(str(os.getpid()))
            self.lock_path.touch()

            return prior

        except Exception as e:
            logger.error(f"Lock acquire failed: {e}")
            return None

    def release(self):
        """Release the lock by removing the PID file."""
        try:
            pid_file = self.lock_path.with_suffix(".pid")
            if pid_file.exists():
                pid_file.unlink()
        except Exception:
            pass

    def rollback(self, prior_mtime: float):
        """Rollback: restore the prior mtime so the time gate passes again."""
        try:
            if prior_mtime > 0:
                os.utime(self.lock_path, (prior_mtime, prior_mtime))
            self.release()
        except Exception:
            pass


# ── Session Scanner ──────────────────────────────────────────────────────────

class SessionScanner:
    """Scans session transcripts for consolidation input."""

    def __init__(self, transcripts_dir: Path = TRANSCRIPTS_DIR):
        self.transcripts_dir = transcripts_dir

    def list_sessions_since(self, since_timestamp: float) -> List[str]:
        """List session IDs with activity since the given timestamp."""
        sessions = []
        if not self.transcripts_dir.exists():
            return sessions

        try:
            for entry in self.transcripts_dir.iterdir():
                if entry.is_dir() and entry.stat().st_mtime > since_timestamp:
                    sessions.append(entry.name)
                elif entry.is_file() and entry.suffix in (".json", ".jsonl", ".md"):
                    if entry.stat().st_mtime > since_timestamp:
                        sessions.append(entry.stem)
        except Exception as e:
            logger.error(f"Session scan failed: {e}")

        return sessions[:MAX_SESSIONS_PER_DREAM]

    def read_session_summary(self, session_id: str) -> Optional[SessionSummary]:
        """Read and summarize a session transcript."""
        try:
            session_path = self.transcripts_dir / session_id

            # Try different file formats
            content = ""
            if session_path.is_dir():
                # Look for overview.txt or transcript files
                for fname in ["overview.txt", "transcript.md", "transcript.json"]:
                    fpath = session_path / fname
                    if fpath.exists():
                        content = fpath.read_text(errors="replace")[:5000]
                        break
            elif session_path.with_suffix(".jsonl").exists():
                content = session_path.with_suffix(".jsonl").read_text(errors="replace")[:5000]
            elif session_path.with_suffix(".md").exists():
                content = session_path.with_suffix(".md").read_text(errors="replace")[:5000]

            if not content:
                return None

            # Basic extraction (no LLM needed for scanning)
            return SessionSummary(
                session_id=session_id,
                timestamp=time.time(),
                agent=self._extract_agent(content),
                task_summary=content[:500],
                decisions=self._extract_patterns(content, ["decided", "chose", "selected"]),
                errors=self._extract_patterns(content, ["error", "failed", "exception", "traceback"]),
                files_modified=self._extract_file_paths(content),
            )

        except Exception as e:
            logger.error(f"Failed to read session {session_id}: {e}")
            return None

    def _extract_agent(self, content: str) -> str:
        """Extract the primary agent from content."""
        for agent in ["forge", "hunter", "sentinel", "atlas", "herald", "nemesis"]:
            if agent in content.lower():
                return agent
        return "unknown"

    def _extract_patterns(self, content: str, keywords: List[str]) -> List[str]:
        """Extract lines containing any of the keywords."""
        results = []
        for line in content.split("\n"):
            line_lower = line.lower().strip()
            if any(kw in line_lower for kw in keywords) and len(line.strip()) > 10:
                results.append(line.strip()[:200])
                if len(results) >= 5:
                    break
        return results

    def _extract_file_paths(self, content: str) -> List[str]:
        """Extract file paths mentioned in content."""
        import re
        paths = re.findall(r"(?:/[\w.-]+)+\.(?:py|ts|js|yaml|yml|md|json|toml)", content)
        return list(set(paths))[:10]


# ── AutoDream Daemon ─────────────────────────────────────────────────────────

class AutoDreamDaemon:
    """
    Background memory consolidation daemon.

    Runs during system idle time, reviews recent sessions,
    and consolidates knowledge into memory files.
    """

    def __init__(
        self,
        redis_client=None,
        config: Optional[DreamConfig] = None,
        lock_path: Path = LOCK_FILE,
        memory_dir: Path = MEMORY_DIR,
        transcripts_dir: Path = TRANSCRIPTS_DIR,
    ):
        self._redis = redis_client
        self.config = config or DreamConfig()
        self.lock = ConsolidationLock(lock_path)
        self.scanner = SessionScanner(transcripts_dir)
        self.memory_dir = memory_dir
        self.memory_dir.mkdir(parents=True, exist_ok=True)
        self.state = DreamState()

        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()

        logger.info(
            f"💤 AutoDreamDaemon initialized "
            f"(min_hours={self.config.min_hours}, min_sessions={self.config.min_sessions})"
        )

    # ── Daemon Lifecycle ─────────────────────────────────────────────────

    def start(self, check_interval: int = 300):
        """Start the background consolidation thread."""
        if self._thread and self._thread.is_alive():
            logger.warning("AutoDream already running")
            return

        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._daemon_loop,
            args=(check_interval,),
            daemon=True,
            name="AutoDreamDaemon",
        )
        self._thread.start()
        logger.info(f"💤 AutoDream daemon started (check every {check_interval}s)")

    def stop(self):
        """Stop the background thread."""
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=5)
        logger.info("💤 AutoDream daemon stopped")

    def _daemon_loop(self, check_interval: int):
        """Main daemon loop."""
        while not self._stop_event.is_set():
            try:
                self.try_consolidation()
            except Exception as e:
                logger.error(f"AutoDream loop error: {e}")
                self.state.last_error = str(e)

            self._stop_event.wait(check_interval)

    # ── Gate System ──────────────────────────────────────────────────────

    def try_consolidation(self) -> bool:
        """
        Check all gates and run consolidation if conditions are met.
        Returns True if consolidation was executed.
        """
        if not self.config.enabled:
            return False

        # Gate 1: Time gate
        last_at = self.lock.read_last_consolidated_at()
        hours_since = (time.time() - last_at) / 3600 if last_at > 0 else float("inf")

        if hours_since < self.config.min_hours:
            return False

        # Gate 2: Scan throttle
        now = time.time()
        if now - self.state.last_scan_at < SCAN_INTERVAL_SECONDS:
            return False
        self.state.last_scan_at = now

        # Gate 3: Session gate
        sessions = self.scanner.list_sessions_since(last_at)
        if len(sessions) < self.config.min_sessions:
            logger.debug(
                f"Session gate: {len(sessions)}/{self.config.min_sessions} "
                f"sessions since last consolidation"
            )
            return False

        # Gate 4: Lock gate
        prior_mtime = self.lock.try_acquire()
        if prior_mtime is None:
            logger.debug("Lock gate: another consolidation is running")
            return False

        # All gates passed — run consolidation
        logger.info(
            f"💤 AutoDream firing — {hours_since:.1f}h since last, "
            f"{len(sessions)} sessions to review"
        )

        try:
            self.state.is_running = True
            self._publish_event("dream_started", {
                "hours_since": round(hours_since, 1),
                "sessions_count": len(sessions),
            })

            result = self.run_consolidation(sessions)

            self.state.is_running = False
            self.state.total_consolidations += 1
            self.state.sessions_reviewed += len(sessions)
            self.state.last_consolidation_at = time.time()
            self.lock.release()

            self._publish_event("dream_completed", {
                "sessions_reviewed": len(sessions),
                "files_touched": result.get("files_touched", []),
            })

            return True

        except Exception as e:
            logger.error(f"Consolidation failed: {e}")
            self.state.is_running = False
            self.state.last_error = str(e)
            self.lock.rollback(prior_mtime)

            self._publish_event("dream_failed", {"error": str(e)[:200]})
            return False

    # ── Consolidation Engine ─────────────────────────────────────────────

    def run_consolidation(self, session_ids: List[str]) -> Dict[str, Any]:
        """
        Run the actual consolidation process.

        1. Read session summaries
        2. Build consolidation prompt
        3. Call LLM for knowledge extraction
        4. Write results to memory files
        """
        # Step 1: Read sessions
        summaries = []
        for sid in session_ids[:MAX_SESSIONS_PER_DREAM]:
            summary = self.scanner.read_session_summary(sid)
            if summary:
                summaries.append(summary)

        if not summaries:
            logger.warning("No readable sessions found")
            return {"files_touched": []}

        logger.info(f"📖 Read {len(summaries)} session summaries")

        # Step 2: Build context
        context_parts = []
        for s in summaries:
            parts = [f"### Session: {s.session_id} (agent: {s.agent})"]
            parts.append(f"Task: {s.task_summary[:300]}")
            if s.decisions:
                parts.append("Decisions: " + "; ".join(s.decisions[:3]))
            if s.errors:
                parts.append("Errors: " + "; ".join(s.errors[:3]))
            if s.files_modified:
                parts.append("Files: " + ", ".join(s.files_modified[:5]))
            context_parts.append("\n".join(parts))

        context = "\n\n---\n\n".join(context_parts)

        # Step 3: Call LLM
        if self.config.dry_run:
            logger.info("[DRY RUN] Would send consolidation prompt to LLM")
            return {"files_touched": [], "dry_run": True}

        knowledge = self._call_llm(context)

        if not knowledge:
            logger.warning("LLM returned empty knowledge")
            return {"files_touched": []}

        # Step 4: Write to memory files
        files_touched = self._write_knowledge(knowledge)
        self.state.files_touched = files_touched

        logger.info(f"💤 Consolidation complete — touched {len(files_touched)} files")
        return {"files_touched": files_touched, "knowledge": knowledge}

    def _call_llm(self, context: str) -> Optional[Dict]:
        """Call LLM for knowledge extraction."""
        try:
            from core.sea.llm_registry import LLMProviderRegistry
            import redis as redis_lib

            r = self._redis
            if not r:
                pw = os.getenv("REDIS_PASSWORD", "").strip().strip("\"'")
                r = redis_lib.Redis(
                    host="127.0.0.1", port=6379,
                    password=pw or None, decode_responses=True,
                    socket_connect_timeout=2,
                )
                r.ping()

            registry = LLMProviderRegistry(r)
            resp = registry.complete(
                messages=[{
                    "role": "user",
                    "content": f"Review these session transcripts and consolidate knowledge:\n\n{context[:12000]}",
                }],
                system_prompt=CONSOLIDATION_SYSTEM_PROMPT,
                role="fallback_any",
                preferred_provider="gemini_flash",
                max_tokens=2000,
                temperature=0.2,
            )

            if resp and resp.content:
                # Try to parse JSON from response
                text = resp.content.strip()
                # Extract JSON from possible markdown code block
                if "```json" in text:
                    text = text.split("```json")[1].split("```")[0].strip()
                elif "```" in text:
                    text = text.split("```")[1].split("```")[0].strip()

                return json.loads(text)

        except json.JSONDecodeError as e:
            logger.warning(f"LLM response not valid JSON: {e}")
        except Exception as e:
            logger.error(f"LLM call failed: {e}")

        return None

    def _write_knowledge(self, knowledge: Dict) -> List[str]:
        """Write extracted knowledge to memory files."""
        files_touched = []
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")

        # Write rules
        rules = knowledge.get("rules_learned", [])
        if rules:
            rules_file = self.memory_dir / "rules.md"
            with open(rules_file, "a", encoding="utf-8") as f:
                f.write(f"\n\n## Dream — {timestamp}\n\n")
                for rule in rules:
                    f.write(f"- {rule}\n")
            files_touched.append(str(rules_file))

        # Write errors
        errors = knowledge.get("errors_documented", [])
        if errors:
            errors_file = self.memory_dir / "errors.md"
            with open(errors_file, "a", encoding="utf-8") as f:
                f.write(f"\n\n## Dream — {timestamp}\n\n")
                for err in errors:
                    if isinstance(err, dict):
                        f.write(f"- **{err.get('error', '?')}**: {err.get('resolution', '?')}\n")
                    else:
                        f.write(f"- {err}\n")
            files_touched.append(str(errors_file))

        # Write patterns
        patterns = knowledge.get("patterns_found", [])
        if patterns:
            patterns_file = self.memory_dir / "patterns.md"
            with open(patterns_file, "a", encoding="utf-8") as f:
                f.write(f"\n\n## Dream — {timestamp}\n\n")
                for pat in patterns:
                    if isinstance(pat, dict):
                        f.write(f"### {pat.get('name', 'Unnamed')}\n")
                        f.write(f"{pat.get('description', '')}\n")
                        for step in pat.get("steps", []):
                            f.write(f"  1. {step}\n")
                        f.write("\n")
                    else:
                        f.write(f"- {pat}\n")
            files_touched.append(str(patterns_file))

        # Write full consolidation log
        log_file = self.memory_dir / f"dream_{timestamp}.json"
        with open(log_file, "w", encoding="utf-8") as f:
            json.dump(knowledge, f, indent=2, default=str)
        files_touched.append(str(log_file))

        return files_touched

    # ── Events ───────────────────────────────────────────────────────────

    def _publish_event(self, event_type: str, data: dict):
        """Publish event to Redis."""
        if not self._redis:
            return
        try:
            event = json.dumps({
                "type": f"auto_dream:{event_type}",
                "timestamp": time.time(),
                **data,
            })
            self._redis.publish("kernell:events", event)
            self._redis.lpush("kernell:auto_dream:events", event)
            self._redis.ltrim("kernell:auto_dream:events", 0, 49)
        except Exception:
            pass

    # ── Status ───────────────────────────────────────────────────────────

    def get_status(self) -> Dict[str, Any]:
        """Status for dashboard."""
        last_at = self.lock.read_last_consolidated_at()
        hours_since = (time.time() - last_at) / 3600 if last_at > 0 else -1

        return {
            "enabled": self.config.enabled,
            "is_running": self.state.is_running,
            "hours_since_last": round(hours_since, 1),
            "total_consolidations": self.state.total_consolidations,
            "sessions_reviewed": self.state.sessions_reviewed,
            "last_error": self.state.last_error,
            "files_touched": self.state.files_touched,
            "config": {
                "min_hours": self.config.min_hours,
                "min_sessions": self.config.min_sessions,
            },
        }


# ── CLI ──────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="💤 AutoDream — Kernell OS")
    parser.add_argument("--status", action="store_true", help="Show daemon status")
    parser.add_argument("--run", action="store_true", help="Run consolidation now")
    parser.add_argument("--dry-run", action="store_true", help="Dry run (no LLM calls)")
    parser.add_argument("--daemon", action="store_true", help="Start daemon mode")
    args = parser.parse_args()

    config = DreamConfig(dry_run=args.dry_run)

    try:
        import redis as redis_lib
        pw = os.getenv("REDIS_PASSWORD", "").strip().strip("\"'")
        r = redis_lib.Redis(
            host="127.0.0.1", port=6379,
            password=pw or None, decode_responses=True,
            socket_connect_timeout=2,
        )
        r.ping()
    except Exception:
        r = None

    daemon = AutoDreamDaemon(redis_client=r, config=config)

    if args.status:
        print(json.dumps(daemon.get_status(), indent=2))
    elif args.run or args.dry_run:
        print("💤 Running consolidation...")
        success = daemon.try_consolidation()
        print(f"{'✅ Done' if success else '❌ Not triggered (gates not met)'}")
        print(json.dumps(daemon.get_status(), indent=2))
    elif args.daemon:
        print("💤 Starting AutoDream daemon...")
        daemon.start(check_interval=300)
        try:
            while True:
                time.sleep(60)
        except KeyboardInterrupt:
            daemon.stop()
    else:
        parser.print_help()
