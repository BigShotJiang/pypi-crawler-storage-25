"""
KMS — Knowledge Management System
═══════════════════════════════════════════════════════════════
Facade that wraps MemoryBroker for agent-level knowledge operations.
Used by Sage, Fixer, and other agents that need semantic memory.

Provides:
  - store(text, metadata) → store a memory with embedding
  - search(query, top_k) → semantic search
  - recall(agent, memory_type) → agent-specific recall
  - forget(memory_id) → delete a memory
  - consolidate() → nocturnal consolidation of weak memories
"""

import json
import time
import logging
from typing import Any, Dict, List, Optional

log = logging.getLogger("KMS")


class KMS:
    """
    Knowledge Management System — high-level memory facade.
    Wraps MemoryBroker for simplified agent usage.
    """

    def __init__(self, redis_client, agent_name: str, qdrant_url: Optional[str] = None):
        self.redis = redis_client
        self.agent_name = agent_name
        self._broker = None
        self._qdrant_url = qdrant_url or "http://localhost:6333"

        # Lazy-init broker to avoid import cycles
        try:
            from core.memory.memory_broker import MemoryBroker
            self._broker_class = MemoryBroker
            log.info(f"KMS initialized for agent={agent_name}")
        except ImportError:
            self._broker_class = None
            log.warning("KMS: MemoryBroker not available — operating in degraded mode")

    async def _get_broker(self):
        """Lazy-initialize the async MemoryBroker."""
        if self._broker is None and self._broker_class:
            self._broker = self._broker_class()
            await self._broker.initialize()
        return self._broker

    # ── Store ─────────────────────────────────────────────────

    async def store(self, text: str, metadata: Optional[Dict] = None,
                    memory_type: str = "knowledge", collection: str = "kernell_memory") -> Optional[str]:
        """Store a knowledge item with semantic embedding."""
        broker = await self._get_broker()
        if not broker:
            return self._store_redis_fallback(text, metadata, memory_type)

        try:
            meta = {
                "agent": self.agent_name,
                "memory_type": memory_type,
                "stored_at": time.time(),
                **(metadata or {}),
            }
            record_id = await broker.store(
                text=text,
                metadata=meta,
                collection=collection,
            )
            log.info(f"KMS.store: {memory_type} ({len(text)} chars) → {collection}")
            return record_id
        except Exception as e:
            log.error(f"KMS.store failed: {e}")
            return self._store_redis_fallback(text, metadata, memory_type)

    def _store_redis_fallback(self, text: str, metadata: Optional[Dict], memory_type: str) -> str:
        """Fallback: store in Redis when Qdrant is unavailable."""
        import hashlib
        record_id = hashlib.sha256(f"{text}{time.time()}".encode()).hexdigest()[:16]
        entry = {
            "id": record_id,
            "text": text[:2000],
            "agent": self.agent_name,
            "memory_type": memory_type,
            "ts": time.time(),
            **(metadata or {}),
        }
        self.redis.lpush(f"kernell:kms:{self.agent_name}:fallback", json.dumps(entry))
        self.redis.ltrim(f"kernell:kms:{self.agent_name}:fallback", 0, 499)
        return record_id

    # ── Search ────────────────────────────────────────────────

    async def search(self, query: str, top_k: int = 5,
                     collection: str = "kernell_memory",
                     filters: Optional[Dict] = None) -> List[Dict]:
        """Semantic search across memory."""
        broker = await self._get_broker()
        if not broker:
            return self._search_redis_fallback(query, top_k)

        try:
            results = await broker.search(
                query=query,
                top_k=top_k,
                collection=collection,
                filters=filters,
            )
            log.info(f"KMS.search: '{query[:50]}' → {len(results)} results")
            return results
        except Exception as e:
            log.error(f"KMS.search failed: {e}")
            return self._search_redis_fallback(query, top_k)

    def _search_redis_fallback(self, query: str, top_k: int) -> List[Dict]:
        """Keyword-based fallback when Qdrant is unavailable."""
        results = []
        raw = self.redis.lrange(f"kernell:kms:{self.agent_name}:fallback", 0, -1)
        query_lower = query.lower()
        for r in raw:
            try:
                entry = json.loads(r)
                if query_lower in entry.get("text", "").lower():
                    results.append(entry)
            except Exception:
                continue
        return results[:top_k]

    # ── Recall ────────────────────────────────────────────────

    async def recall(self, memory_type: str = "research_finding",
                     limit: int = 10) -> List[Dict]:
        """Recall agent-specific memories by type."""
        broker = await self._get_broker()
        if not broker:
            return []
        try:
            results = await broker.search(
                query=f"agent:{self.agent_name} type:{memory_type}",
                top_k=limit,
                collection="kernell_memory",
                filters={"agent": self.agent_name, "memory_type": memory_type},
            )
            return results
        except Exception as e:
            log.error(f"KMS.recall failed: {e}")
            return []

    # ── Stats ─────────────────────────────────────────────────

    def get_stats(self) -> Dict[str, Any]:
        """Return KMS statistics from Redis."""
        try:
            raw = self.redis.get("kernell:memory:broker_metrics")
            if raw:
                return json.loads(raw)
        except Exception:
            pass
        return {"status": "unavailable"}

    # ── Fallback Reingestion ──────────────────────────────────

    async def reingest_fallback(self) -> Dict[str, int]:
        """
        Re-ingest items stored in Redis fallback back into Qdrant.
        Called periodically by Chronos (every 6h).
        Returns: {"reingested": N, "failed": M, "remaining": R}
        """
        broker = await self._get_broker()
        if not broker:
            return {"reingested": 0, "failed": 0, "remaining": -1, "reason": "no_broker"}

        key = f"kernell:kms:{self.agent_name}:fallback"
        reingested = 0
        failed = 0

        try:
            items = self.redis.lrange(key, 0, -1) or []
            if not items:
                return {"reingested": 0, "failed": 0, "remaining": 0}

            successfully_ingested = []
            for i, raw in enumerate(items):
                try:
                    entry = json.loads(raw)
                    text = entry.get("text", "")
                    if not text:
                        successfully_ingested.append(i)
                        continue

                    metadata = {
                        k: v for k, v in entry.items()
                        if k not in ("id", "text")
                    }
                    metadata["source"] = "redis_fallback_reingestion"

                    await broker.store(
                        text=text,
                        metadata=metadata,
                        collection=entry.get("collection", "kernell_memory"),
                    )
                    successfully_ingested.append(i)
                    reingested += 1
                except Exception:
                    failed += 1

            # Remove reingested items (from end to start to preserve indices)
            if successfully_ingested:
                # Mark items for removal by setting to a sentinel value, then clean up
                pipe = self.redis.pipeline()
                for idx in successfully_ingested:
                    pipe.lset(key, idx, "__REINGESTED__")
                pipe.lrem(key, 0, "__REINGESTED__")
                pipe.execute()

            remaining = self.redis.llen(key) or 0
            log.info(f"KMS.reingest: {reingested} ok, {failed} failed, {remaining} remaining")

        except Exception as e:
            log.error(f"KMS.reingest_fallback error: {e}")
            remaining = -1

        return {"reingested": reingested, "failed": failed, "remaining": remaining}
