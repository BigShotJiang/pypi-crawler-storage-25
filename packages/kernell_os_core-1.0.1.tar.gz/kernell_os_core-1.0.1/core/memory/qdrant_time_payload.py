"""
Metadatos temporales canónicos para payloads Qdrant (Kernell OS).

Política:
  - Valor de verdad: UTC (ts_unix + ts_utc_iso).
  - Lectura humana local: America/Bogota (ts_bogota_iso) — hora de operación del Arquitecto.
  - No sobrescribe claves ya presentes (setdefault), salvo que se pida lo contrario.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Dict, Optional

try:
    from zoneinfo import ZoneInfo
except ImportError:  # pragma: no cover
    ZoneInfo = None  # type: ignore[misc, assignment]

KERNEL_TZ_BOGOTA = "America/Bogota"
KERNEL_TZ_POLICY = "canonical=UTC;display=America/Bogota"


def _bogota_iso(utc_dt: datetime) -> str:
    if ZoneInfo is None:
        return utc_dt.isoformat()
    return utc_dt.astimezone(ZoneInfo(KERNEL_TZ_BOGOTA)).isoformat()


def attach_kernell_time_metadata(
    payload: Dict[str, Any],
    *,
    agent: str = "",
    source: str = "",
) -> Dict[str, Any]:
    """
    Enriquece el payload in-place con marcas temporales y trazabilidad mínima.

    Campos añadidos (si faltan):
      ts_unix, ts_utc_iso, ts_bogota_iso, tz_policy
    Opcionales:
      agent, source
    """
    now = datetime.now(timezone.utc)
    payload.setdefault("ts_unix", now.timestamp())
    payload.setdefault("ts_utc_iso", now.isoformat())
    payload.setdefault("ts_bogota_iso", _bogota_iso(now))
    payload.setdefault("tz_policy", KERNEL_TZ_POLICY)
    if agent and not payload.get("agent"):
        payload["agent"] = agent
    if source and not payload.get("source"):
        payload["source"] = source
    return payload


def utc_now_iso() -> str:
    """ISO 8601 UTC (helper para logs / tests)."""
    return datetime.now(timezone.utc).isoformat()


def utc_to_bogota_iso(utc_dt: Optional[datetime] = None) -> str:
    """Convierte un instante UTC a ISO en America/Bogota."""
    if utc_dt is None:
        utc_dt = datetime.now(timezone.utc)
    elif utc_dt.tzinfo is None:
        utc_dt = utc_dt.replace(tzinfo=timezone.utc)
    return _bogota_iso(utc_dt)
