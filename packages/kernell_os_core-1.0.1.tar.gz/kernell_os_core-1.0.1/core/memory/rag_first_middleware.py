#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════╗
║     KERNELL OS — RAG-FIRST MIDDLEWARE v1.0                              ║
║     Adaptado para AgentBase síncrono (agents/core/agent_base.py)       ║
║     GAP CRÍTICO CERRADO: Agentes consultaban LLM sin revisar Qdrant.   ║
╚══════════════════════════════════════════════════════════════════════════╝

Instrucción de integración:
  En agents/core/agent_base.py, importa y aplica el decorador:

    from core.memory.rag_first_middleware import rag_first

    class AgentBase:
        @rag_first
        def _call_api(self, provider, key, prompt, max_tokens, target_model="unknown"):
            ...

IMPORTANTE: _call_api es SÍNCRONO (usa requests). Este decorador es síncrono
y ejecuta la consulta a Qdrant en un thread con timeout para no bloquear.

Protocolo completo por prioridad:
  1. kernell_episodes  → ¿Hice algo similar antes? ¿Con qué resultado?
  2. kernell_memory→ ¿Tengo un skill optimizado para esto?
  3. kernell_memory    → ¿Qué sabe el sistema sobre este dominio?
  4. → Si score > umbral: inyectar en prompt
  5. → LLM call con contexto enriquecido
  6. → Registrar episodio post-ejecución (fire and forget)
"""

import asyncio
import concurrent.futures
import functools
import logging
import threading
import time
from typing import Callable, Optional, Any

log = logging.getLogger("rag_first")

try:
    from agents.core.memory.kms_config import RAG_SCORE_THRESHOLD
except ImportError:
    RAG_SCORE_THRESHOLD = 0.65

# Timeout para no bloquear al agente si Qdrant tarda
RAG_TIMEOUT_SECONDS = 2.0

# Cuántos resultados máximos por colección
RAG_TOP_K = 4

# Thread-local event loop for async→sync bridge
_thread_pool = concurrent.futures.ThreadPoolExecutor(max_workers=2, thread_name_prefix="rag")
_async_lock = threading.Lock()


def _run_async(coro):
    """Run an async coroutine from sync context with a dedicated event loop."""
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None

    if loop and loop.is_running():
        # We're inside an existing event loop — run in thread
        future = _thread_pool.submit(asyncio.run, coro)
        return future.result(timeout=RAG_TIMEOUT_SECONDS + 1)
    else:
        # No event loop — create one
        return asyncio.run(coro)


def rag_first(func: Callable) -> Callable:
    """
    Decorador SÍNCRONO que añade RAG-first a _call_api de AgentBase.

    Uso:
        @rag_first
        def _call_api(self, provider, key, prompt, max_tokens, target_model="unknown"):
            ...

    El método debe tener 'self' con atributos:
        self.agent_name: str  — nombre del agente
    """
    @functools.wraps(func)
    def wrapper(self, provider, key, prompt, max_tokens, target_model="unknown"):
        agent_name = getattr(self, "agent_name", "unknown")
        enriched_prompt = prompt

        try:
            memory_ctx = _run_async(
                _query_memory_with_timeout(agent_name, prompt)
            )

            if memory_ctx and memory_ctx.get("inject_prompt"):
                enriched_prompt = memory_ctx["inject_prompt"] + "\n\n" + prompt
                log.info(
                    f"[{agent_name}] RAG inyectado: "
                    f"{len(memory_ctx.get('episodes', []))} episodios, "
                    f"{len(memory_ctx.get('skills', []))} skills, "
                    f"{len(memory_ctx.get('general', []))} general"
                )
            else:
                log.debug(f"[{agent_name}] Sin memoria relevante en Qdrant")

        except concurrent.futures.TimeoutError:
            log.warning(f"[{agent_name}] RAG timeout ({RAG_TIMEOUT_SECONDS}s) — continuando sin memoria")
        except Exception as e:
            log.warning(f"[{agent_name}] RAG error: {e} — continuando sin memoria")

        # Ejecutar el call original con el prompt enriquecido
        t0 = time.monotonic()
        result = func(self, provider, key, enriched_prompt, max_tokens, target_model)
        duration_ms = (time.monotonic() - t0) * 1000

        # Registrar episodio post-ejecución (fire and forget en thread)
        try:
            _thread_pool.submit(
                _record_episode_sync, agent_name, prompt, result, duration_ms
            )
        except Exception:
            pass

        return result

    return wrapper


async def _query_memory_with_timeout(agent_name: str, prompt: str) -> Optional[dict]:
    """Query memory with async timeout."""
    return await asyncio.wait_for(
        _query_memory(agent_name, prompt),
        timeout=RAG_TIMEOUT_SECONDS
    )


async def _query_memory(agent_name: str, prompt: str) -> Optional[dict]:
    """Consulta el MemoryBroker."""
    try:
        from core.memory.memory_broker import MemoryBroker
        broker = await MemoryBroker.get_instance()
        return await broker.recall_for_agent(agent_name, prompt, top_k=RAG_TOP_K)
    except Exception as e:
        log.debug(f"MemoryBroker no disponible: {e}")
        return None


def _record_episode_sync(
    agent_name: str,
    prompt: str,
    result: Any,
    duration_ms: float,
):
    """Registra el episodio sincrónicamente en un thread background."""
    try:
        asyncio.run(_record_episode_async(agent_name, prompt, result, duration_ms))
    except Exception as e:
        log.debug(f"Error registrando episodio: {e}")


async def _record_episode_async(
    agent_name: str,
    prompt: str,
    result: Any,
    duration_ms: float,
):
    """Registra el episodio en Qdrant."""
    try:
        from core.memory.memory_broker import MemoryBroker, EpisodeRecord
    except ImportError:
        return

    try:
        success = _infer_success(result)
        outcome = _extract_outcome(result)

        broker = await MemoryBroker.get_instance()
        episode = EpisodeRecord(
            agent=agent_name,
            observation=prompt[:300],
            decision="LLM call via agent_base",
            action=f"_call_api con prompt de {len(prompt)} chars",
            outcome=outcome,
            success=success,
            task_type="llm_call",
            duration_ms=round(duration_ms, 1),
        )
        await broker.upsert_episode(episode)

    except Exception as e:
        log.debug(f"Error registrando episodio: {e}")


def _infer_success(result: Any) -> bool:
    """Heurística simple para detectar si el resultado es exitoso"""
    if result is None:
        return False
    if isinstance(result, dict):
        if result.get("status") in ("ERROR", "FAILED", "error"):
            return False
        if result.get("error"):
            return False
        return True
    if isinstance(result, str):
        if result.startswith("Error:"):
            return False
        error_keywords = ["error", "failed", "exception", "traceback"]
        return not any(k in result.lower()[:200] for k in error_keywords)
    return True


def _extract_outcome(result: Any) -> str:
    """Extrae una descripción del resultado"""
    if result is None:
        return "Sin resultado"
    if isinstance(result, str):
        return result[:400]
    if isinstance(result, dict):
        return str(result.get("message", result.get("result", str(result))))[:400]
    return str(result)[:400]


# ─── MIDDLEWARE PARA SKILL LOOKUP ─────────────────────────────────────────────

class SkillLookup:
    """
    Helper para que los agentes busquen skills antes de ejecutar tareas.
    Uso directo (sync wrapper):

        skill = SkillLookup.find_sync(agent_name="forge", task="fix python bug")
        if skill:
            print(skill["content"])
    """

    @staticmethod
    async def find(
        agent_name: str,
        task: str,
        min_score: float = 0.78,
    ) -> Optional[dict]:
        """Busca el skill más relevante en kernell_memory."""
        try:
            from core.memory.memory_broker import MemoryBroker, Collection
            broker = await MemoryBroker.get_instance()
            results = await broker.query(
                text=task,
                collection=Collection.SKILLS,
                top_k=1,
                score_threshold=min_score,
                filter_agent=agent_name,
            )
            return results[0] if results else None
        except Exception as e:
            log.debug(f"SkillLookup error: {e}")
            return None

    @staticmethod
    def find_sync(agent_name: str, task: str, min_score: float = 0.78) -> Optional[dict]:
        """Sync wrapper for find()."""
        try:
            return _run_async(SkillLookup.find(agent_name, task, min_score))
        except Exception:
            return None

    @staticmethod
    async def find_similar_episode(
        agent_name: str,
        task: str,
        success_only: bool = False,
        min_score: float = 0.75,
    ) -> list:
        """Busca episodios similares pasados del agente."""
        try:
            from core.memory.memory_broker import MemoryBroker, Collection
            broker = await MemoryBroker.get_instance()
            filter_type = "success_pattern" if success_only else None
            return await broker.query(
                text=task,
                collection=Collection.EPISODES,
                top_k=5,
                score_threshold=min_score,
                filter_agent=agent_name,
                filter_type=filter_type,
            )
        except Exception as e:
            log.debug(f"Episode lookup error: {e}")
            return []
