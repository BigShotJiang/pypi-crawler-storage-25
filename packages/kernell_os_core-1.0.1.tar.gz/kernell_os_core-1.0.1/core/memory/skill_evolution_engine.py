#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════╗
║     KERNELL OS — SKILL EVOLUTION ENGINE v1.0                            ║
║     Ciclo autónomo de mejora de skills basado en episodios              ║
║     Ejecutado por Chronos: consolidación 1h, evolución semanal         ║
╚══════════════════════════════════════════════════════════════════════════╝

El ciclo completo (propuesto por Kernell):

  1. ACCIÓN      → Agente ejecuta → EpisodeRecord en Qdrant
  2. EVALUACIÓN  → Score calculado (éxito=0.8, fallo=0.2)
  3. CONSOLIDACIÓN (1h) → Agrupar episodios, detectar patrones (>3 ocurrencias)
  4. RECALL PRE-ACCIÓN → RAG-First Middleware lo maneja
  5. SKILL EVOLUTION (semanal) → Generar/versionar skill docs con IA
"""

import asyncio
import json
import logging
import os
import time
from collections import defaultdict
from datetime import datetime, timezone, timedelta
from typing import Optional

import aiohttp
import redis.asyncio as aioredis

log = logging.getLogger("skill_evolution")

REDIS_URL      = os.getenv("REDIS_URL", "redis://:@localhost:6379")
ANTHROPIC_KEY  = os.getenv("ANTHROPIC_API_KEY", "")
GEMINI_KEY     = os.getenv("GEMINI_API_KEY", "")

# Umbrales del ciclo
PATTERN_MIN_OCCURRENCES = 3      # Mínimo de episodios para detectar patrón
SKILL_UPGRADE_THRESHOLD = 0.1    # Mejora mínima de score para versionar skill
CONSOLIDATION_WINDOW_H  = 1      # Horas de ventana para consolidación
EVOLUTION_WINDOW_DAYS   = 7      # Días de episodios para evolución semanal


# ─── PHASE 1: EPISODE CONSOLIDATOR ───────────────────────────────────────────

class EpisodeConsolidator:
    """
    Ejecutado cada 1 hora por Chronos.
    Lee episodios recientes de Qdrant, detecta patrones y upsertea en kernell_memory.
    """

    async def run(self) -> dict:
        """Ciclo de consolidación completo"""
        log.info("🔄 Iniciando consolidación de episodios...")

        try:
            from .memory_broker import MemoryBroker, Collection, MemoryRecord
        except ImportError:
            from memory_broker import MemoryBroker, Collection, MemoryRecord

        broker = await MemoryBroker.get_instance()
        results = {"patterns_detected": 0, "facts_written": 0, "agents_processed": []}

        # Episodios de la última hora
        since = (datetime.now(timezone.utc) - timedelta(hours=CONSOLIDATION_WINDOW_H))

        # Buscar episodios recientes de todos los agentes
        all_episodes = await broker.query(
            text="tarea ejecutada resultado éxito fallo acción agente",
            collection=Collection.EPISODES,
            top_k=100,
            score_threshold=0.0,  # Todos los episodios recientes
        )

        # Filtrar por timestamp
        recent = [
            e for e in all_episodes
            if e.get("ts", "") >= since.isoformat()
        ]
        log.info(f"Episodios recientes: {len(recent)}")

        if not recent:
            return results

        # Agrupar por agente y tipo de tarea
        by_agent = defaultdict(list)
        for ep in recent:
            by_agent[ep.get("agent", "unknown")].append(ep)

        for agent, episodes in by_agent.items():
            patterns = self._detect_patterns(episodes)
            results["agents_processed"].append(agent)

            for pattern in patterns:
                # Escribir patrón en kernell_memory como knowledge
                record = MemoryRecord(
                    content=pattern["description"],
                    agent="episode_consolidator",
                    memory_type="architectural_decision"
                    if pattern["type"] == "success_pattern" else "error_resolution",
                    collection=Collection.MEMORY,
                    score=pattern["confidence"],
                    tags=["pattern", agent, pattern["type"]],
                    extra={
                        "pattern_type":   pattern["type"],
                        "occurrences":    pattern["count"],
                        "agent":          agent,
                        "confidence":     pattern["confidence"],
                        "examples":       pattern["examples"][:3],
                    },
                )
                r = await broker.upsert(record)
                if r["status"] == "OK":
                    results["facts_written"] += 1
                    results["patterns_detected"] += 1

        log.info(
            f"Consolidación: {results['patterns_detected']} patrones, "
            f"{results['facts_written']} escritos"
        )
        return results

    def _detect_patterns(self, episodes: list[dict]) -> list[dict]:
        """Detecta patrones recurrentes en episodios de un agente"""
        patterns = []

        # Agrupar por tipo de tarea
        by_task_type = defaultdict(list)
        for ep in episodes:
            task = ep.get("task_type", "general")
            by_task_type[task].append(ep)

        for task_type, task_episodes in by_task_type.items():
            if len(task_episodes) < PATTERN_MIN_OCCURRENCES:
                continue

            successes = [e for e in task_episodes if e.get("success", False)]
            failures  = [e for e in task_episodes if not e.get("success", True)]
            success_rate = len(successes) / len(task_episodes)

            if len(successes) >= PATTERN_MIN_OCCURRENCES:
                patterns.append({
                    "type":        "success_pattern",
                    "task_type":   task_type,
                    "count":       len(successes),
                    "confidence":  min(0.95, success_rate),
                    "description": self._describe_pattern(task_type, successes, "éxito"),
                    "examples":    [e["content"] for e in successes[:3]],
                })

            if len(failures) >= PATTERN_MIN_OCCURRENCES:
                patterns.append({
                    "type":        "error_resolution",
                    "task_type":   task_type,
                    "count":       len(failures),
                    "confidence":  min(0.9, 1 - success_rate),
                    "description": self._describe_pattern(task_type, failures, "fallo"),
                    "examples":    [e["content"] for e in failures[:3]],
                })

        return patterns

    def _describe_pattern(
        self, task_type: str, episodes: list[dict], pattern_class: str
    ) -> str:
        outcomes = [e.get("outcome", "") for e in episodes[:5]]
        outcome_summary = "; ".join(o[:100] for o in outcomes if o)
        return (
            f"Patrón de {pattern_class} detectado para tarea '{task_type}' "
            f"({len(episodes)} ocurrencias). "
            f"Outcomes típicos: {outcome_summary}"
        )


# ─── PHASE 2: SKILL EVOLVER ───────────────────────────────────────────────────

class SkillEvolver:
    """
    Ejecutado semanalmente por Chronos.
    Analiza clusters de episodios positivos y genera/actualiza skill docs.
    Usa IA (Claude/Gemini) para sintetizar el skill a partir de evidencia.
    """

    SYSTEM_PROMPT = """Eres el gestor de skills de Kernell OS.
Recibes episodios de éxito de un agente y debes sintetizar un SKILL optimizado.

El skill debe ser:
1. Accionable — instrucciones concretas que el agente puede seguir
2. Generalizable — aplica a casos similares futuros
3. Medible — incluye criterios de éxito

Responde SOLO en JSON:
{
  "skill_name": "nombre_corto_del_skill",
  "description": "qué hace este skill y cuándo usarlo",
  "steps": ["paso 1", "paso 2", "paso 3"],
  "success_criteria": "cómo saber que funcionó",
  "failure_indicators": "señales de que algo está saliendo mal",
  "learned_from": "resumen de los episodios de evidencia",
  "score": 0.0-1.0,
  "version_notes": "qué mejoró respecto a la versión anterior si existe"
}"""

    async def run(self) -> dict:
        """Ciclo de evolución de skills completo"""
        log.info("🧬 Iniciando evolución de skills...")

        try:
            from .memory_broker import MemoryBroker, Collection
        except ImportError:
            from memory_broker import MemoryBroker, Collection

        broker = await MemoryBroker.get_instance()
        results = {"skills_created": 0, "skills_updated": 0, "skills_deprecated": 0}

        # Episodios de los últimos EVOLUTION_WINDOW_DAYS días
        since = (
            datetime.now(timezone.utc) - timedelta(days=EVOLUTION_WINDOW_DAYS)
        ).isoformat()

        # Buscar episodios de éxito con score alto
        success_episodes = await broker.query(
            text="éxito tarea completada resultado positivo skill efectivo",
            collection=Collection.EPISODES,
            top_k=200,
            score_threshold=0.6,
            filter_type="success_pattern",
        )

        # Filtrar por fecha
        recent_successes = [
            e for e in success_episodes
            if e.get("ts", "") >= since
        ]
        log.info(f"Episodios de éxito para analizar: {len(recent_successes)}")

        # Agrupar por agente y tipo de tarea
        clusters = self._cluster_episodes(recent_successes)
        log.info(f"Clusters detectados: {len(clusters)}")

        for cluster_key, cluster_episodes in clusters.items():
            agent, task_type = cluster_key

            if len(cluster_episodes) < PATTERN_MIN_OCCURRENCES:
                continue

            # Buscar skill existente para este agente+tarea
            existing_skill = await broker.query(
                text=f"skill {task_type} agente {agent}",
                collection=Collection.SKILLS,
                top_k=1,
                score_threshold=0.80,
                filter_agent=agent,
            )

            # Generar nuevo skill con IA
            new_skill = await self._generate_skill(agent, task_type, cluster_episodes)
            if not new_skill:
                continue

            if existing_skill:
                # Comparar scores
                old_score = existing_skill[0].get("score", 0)
                new_score = new_skill.get("score", 0)
                improvement = new_score - old_score

                if improvement >= SKILL_UPGRADE_THRESHOLD:
                    # Versionar y actualizar
                    old_version = existing_skill[0].get("version", 1)
                    await broker.upsert_skill(
                        agent=agent,
                        skill_name=new_skill["skill_name"],
                        skill_content=json.dumps(new_skill),
                        score=new_score,
                        version=old_version + 1,
                        evidence_ids=[e.get("id", "") for e in cluster_episodes[:10]],
                    )
                    results["skills_updated"] += 1
                    log.info(
                        f"⬆️ Skill actualizado: {agent}/{new_skill['skill_name']} "
                        f"v{old_version}→v{old_version+1} "
                        f"(score: {old_score:.2f}→{new_score:.2f})"
                    )
                else:
                    log.debug(
                        f"Skill {agent}/{new_skill['skill_name']}: "
                        f"mejora insuficiente ({improvement:.2f})"
                    )
            else:
                # Skill nuevo
                await broker.upsert_skill(
                    agent=agent,
                    skill_name=new_skill["skill_name"],
                    skill_content=json.dumps(new_skill),
                    score=new_skill.get("score", 0.5),
                    version=1,
                    evidence_ids=[e.get("id", "") for e in cluster_episodes[:10]],
                )
                results["skills_created"] += 1
                log.info(
                    f"✨ Skill creado: {agent}/{new_skill['skill_name']} "
                    f"(score: {new_skill.get('score', 0):.2f}, "
                    f"evidencia: {len(cluster_episodes)} episodios)"
                )

        log.info(f"Evolución: {results}")
        return results

    def _cluster_episodes(
        self, episodes: list[dict]
    ) -> dict[tuple, list[dict]]:
        """Agrupa episodios por (agente, tipo_de_tarea)"""
        clusters = defaultdict(list)
        for ep in episodes:
            agent     = ep.get("agent", "unknown")
            task_type = ep.get("task_type", "general")
            clusters[(agent, task_type)].append(ep)
        return dict(clusters)

    async def _generate_skill(
        self, agent: str, task_type: str, episodes: list[dict]
    ) -> Optional[dict]:
        """Genera un skill usando IA basado en episodios de éxito"""
        if not ANTHROPIC_KEY and not GEMINI_KEY:
            return self._generate_skill_heuristic(agent, task_type, episodes)

        # Preparar evidencia
        evidence = "\n".join([
            f"- Episodio {i+1}: {ep.get('content', '')[:200]}"
            for i, ep in enumerate(episodes[:10])
        ])

        user_msg = (
            f"Agente: {agent}\n"
            f"Tipo de tarea: {task_type}\n"
            f"Episodios de éxito ({len(episodes)} total, mostrando 10):\n"
            f"{evidence}\n\n"
            f"Sintetiza el skill óptimo para este agente en esta tarea."
        )

        try:
            if ANTHROPIC_KEY:
                return await self._call_claude(user_msg)
            else:
                return await self._call_gemini(user_msg)
        except Exception as e:
            log.warning(f"Error generando skill con IA: {e} — usando heurística")
            return self._generate_skill_heuristic(agent, task_type, episodes)

    async def _call_claude(self, user_msg: str) -> Optional[dict]:
        async with aiohttp.ClientSession() as s:
            async with s.post(
                "https://api.anthropic.com/v1/messages",
                headers={
                    "x-api-key": ANTHROPIC_KEY,
                    "anthropic-version": "2023-06-01",
                    "content-type": "application/json",
                },
                json={
                    "model":      "claude-sonnet-4-20250514",
                    "max_tokens": 1024,
                    "system":     self.SYSTEM_PROMPT,
                    "messages":   [{"role": "user", "content": user_msg}],
                },
                timeout=aiohttp.ClientTimeout(total=30)
            ) as r:
                data = await r.json()
                raw = data["content"][0]["text"]
                raw = raw.strip().lstrip("```json").lstrip("```").rstrip("```").strip()
                return json.loads(raw)

    async def _call_gemini(self, user_msg: str) -> Optional[dict]:
        async with aiohttp.ClientSession() as s:
            async with s.post(
                f"https://generativelanguage.googleapis.com/v1beta/models/"
                f"gemini-2.0-flash:generateContent?key={GEMINI_KEY}",
                json={
                    "systemInstruction": {"parts": [{"text": self.SYSTEM_PROMPT}]},
                    "contents": [{"parts": [{"text": user_msg}]}],
                    "generationConfig": {"responseMimeType": "application/json"},
                },
                timeout=aiohttp.ClientTimeout(total=30)
            ) as r:
                data = await r.json()
                raw = data["candidates"][0]["content"]["parts"][0]["text"]
                return json.loads(raw)

    def _generate_skill_heuristic(
        self, agent: str, task_type: str, episodes: list[dict]
    ) -> dict:
        """Generación de skill sin IA — heurística básica"""
        avg_score = sum(e.get("score", 0.5) for e in episodes) / len(episodes)
        outcomes = [e.get("outcome", "")[:100] for e in episodes[:5] if e.get("outcome")]
        return {
            "skill_name":         f"{agent}_{task_type}_skill",
            "description":        f"Skill de {agent} para tareas de tipo '{task_type}'",
            "steps":              ["Consultar episodios similares", "Ejecutar tarea", "Registrar resultado"],
            "success_criteria":   "Tarea completada sin errores",
            "failure_indicators": "Excepción o resultado vacío",
            "learned_from":       f"{len(episodes)} episodios exitosos. Ejemplos: {'; '.join(outcomes)}",
            "score":              round(avg_score, 3),
            "version_notes":      "Generado automáticamente por heurística",
        }


# ─── PHASE 3: SKILL AUDITOR ───────────────────────────────────────────────────

class SkillAuditor:
    """
    Audita los skills existentes y depreca los que ya no son efectivos.
    Integra con SALUS para reportar el estado del conocimiento del enjambre.
    """

    async def audit(self) -> dict:
        """Auditoría completa de todos los skills"""
        try:
            from .memory_broker import MemoryBroker, Collection
        except ImportError:
            from memory_broker import MemoryBroker, Collection

        broker = await MemoryBroker.get_instance()

        # Obtener todos los skills
        all_skills = await broker.query(
            text="skill agente capacidad",
            collection=Collection.SKILLS,
            top_k=500,
            score_threshold=0.0,
        )

        report = {
            "total_skills":      len(all_skills),
            "by_agent":          defaultdict(list),
            "high_score":        [],
            "low_score":         [],
            "deprecated":        [],
            "recommendations":   [],
            "ts":                datetime.now(timezone.utc).isoformat(),
        }

        for skill in all_skills:
            agent = skill.get("agent", "?")
            score = skill.get("score", 0)
            name  = skill.get("skill_name", skill.get("content", "")[:50])
            ver   = skill.get("version", 1)

            report["by_agent"][agent].append({
                "name": name, "score": score, "version": ver
            })

            if score >= 0.75:
                report["high_score"].append(f"{agent}/{name} (v{ver}, score={score:.2f})")
            elif score < 0.4:
                report["low_score"].append(f"{agent}/{name} (v{ver}, score={score:.2f})")
                report["recommendations"].append(
                    f"Skill débil: {agent}/{name} — considerar reentrenamiento"
                )

        # Publicar resumen en Redis para SALUS
        try:
            redis = await aioredis.from_url(REDIS_URL, decode_responses=True)
            await redis.set(
                "kernell:memory:skill_audit",
                json.dumps({
                    "total":       report["total_skills"],
                    "high_score":  len(report["high_score"]),
                    "low_score":   len(report["low_score"]),
                    "agents":      list(report["by_agent"].keys()),
                    "ts":          report["ts"],
                }),
                ex=86400
            )
            await redis.aclose()
        except Exception:
            pass

        log.info(
            f"Auditoría skills: {report['total_skills']} total, "
            f"{len(report['high_score'])} alto score, "
            f"{len(report['low_score'])} bajo score"
        )

        return report


# ─── ENTRY POINTS PARA CHRONOS ────────────────────────────────────────────────

async def run_consolidation():
    """Llamado por Chronos cada 1 hora"""
    consolidator = EpisodeConsolidator()
    return await consolidator.run()


async def run_skill_evolution():
    """Llamado por Chronos cada semana"""
    evolver = SkillEvolver()
    result = await evolver.run()

    # Auditoría post-evolución
    auditor = SkillAuditor()
    audit   = await auditor.audit()

    return {"evolution": result, "audit": audit}


async def run_skill_audit():
    """Llamado por SALUS en cada ciclo de verificación"""
    auditor = SkillAuditor()
    return await auditor.audit()


def run_hourly_consolidation() -> dict:
    """
    Sync wrapper esperado por Chronos jobs registry.
    """
    return asyncio.run(run_consolidation())


def run_weekly_evolution() -> dict:
    """
    Sync wrapper esperado por Chronos jobs registry.
    """
    return asyncio.run(run_skill_evolution())


if __name__ == "__main__":
    import sys
    mode = sys.argv[1] if len(sys.argv) > 1 else "consolidate"
    if mode == "evolve":
        asyncio.run(run_skill_evolution())
    elif mode == "audit":
        asyncio.run(run_skill_audit())
    else:
        asyncio.run(run_consolidation())
