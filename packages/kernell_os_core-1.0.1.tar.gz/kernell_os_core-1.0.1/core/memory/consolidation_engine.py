import os
import json
import logging
import sqlite3
from pathlib import Path
from datetime import datetime, timedelta

# Local imports
from core.memory.schema import CognitiveSchema, DB_PATH

logger = logging.getLogger(__name__)

class ConsolidationEngine:
    def __init__(self, db_path: Path = DB_PATH):
        self.schema = CognitiveSchema(db_path)
    
    def run_garbage_collection(self, days_threshold: int = 7):
        """
        Memory Fading: 
        Deletes isolated nodes or summarizes heavily linked old nodes.
        """
        logger.info(f"🧠 [Consolidation] Starting cognitive fade for memories older than {days_threshold} days.")
        cutoff_date = (datetime.utcnow() - timedelta(days=days_threshold)).isoformat()
        
        with sqlite3.connect(self.schema.db_path) as conn:
            cursor = conn.cursor()
            
            # Find old nodes that are not 'Agent'
            cursor.execute('''
                SELECT id, label, properties 
                FROM nodes 
                WHERE created_at < ? AND label != 'Agent'
            ''', (cutoff_date,))
            
            old_nodes = cursor.fetchall()
            
            if not old_nodes:
                logger.info("🧠 [Consolidation] No old memories to consolidate.")
                return 0
                
            purged = 0
            for row in old_nodes:
                node_id = row[0]
                
                # Check degree (how many connections it has)
                cursor.execute('SELECT COUNT(*) FROM edges WHERE source_id = ? OR target_id = ?', (node_id, node_id))
                degree = cursor.fetchone()[0]
                
                # If isolated or minimally connected, fade it
                if degree <= 1:
                    logger.debug(f"Fading weak memory: {node_id}")
                    cursor.execute('DELETE FROM edges WHERE source_id = ? OR target_id = ?', (node_id, node_id))
                    cursor.execute('DELETE FROM nodes WHERE id = ?', (node_id,))
                    purged += 1
                else:
                    # TODO: If heavily connected, summarize it using LLM and replace with a "Rule" node
                    pass
            
            conn.commit()
            logger.info(f"🧠 [Consolidation] Faded {purged} weak memories into oblivion.")
            return purged

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    engine = ConsolidationEngine()
    engine.run_garbage_collection()
