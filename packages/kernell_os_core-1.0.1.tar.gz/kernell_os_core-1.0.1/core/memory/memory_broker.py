#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════╗
║     KERNELL OS — MEMORY BROKER v1.0                                     ║
║     Puerta de entrada centralizada a Qdrant. Ningún agente escribe      ║
║     directo. Todo pasa por aquí: auditoría, deduplicación, métricas.    ║
╚══════════════════════════════════════════════════════════════════════════╝

Colecciones gestionadas:
  kernell_memory    · Memoria principal (docs, facts, walkthroughs)
  kernell_episodes  · Episodios causales (acción → outcome)
  kernell_memory    · Entidades correlacionadas cross-domain
  kernell_memory· Skills aprendidos por agente
  kernell_memory· Interacciones entre agentes

Adaptado para Kernell OS:
  - Embeddings via fastembed LOCAL (768d, sin API keys)
  - Modelos: jina-embeddings-v2-base-es (multilenguaje) + jina-embeddings-v2-base-code
  - Redis sync para auditoría (el broker puede correr sync o async)
"""

import asyncio
import hashlib
import json
import logging
import os
import sys
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Optional

import redis.asyncio as aioredis
from qdrant_client import AsyncQdrantClient
from qdrant_client.models import (
    Distance, VectorParams, PointStruct,
    Filter, FieldCondition, MatchValue,
    UpdateStatus, ScoredPoint,
)

# Ensure project root in path
ROOT = os.getenv("KERNELL_ROOT", "/home/anny/kernell-os")
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

log = logging.getLogger("memory_broker")

# ─── CONFIG ───────────────────────────────────────────────────────────────────

QDRANT_URL    = os.getenv("QDRANT_URL", "http://localhost:6333")
# Canónico Kernell: estado en :6380 (ver agents/core/config get_redis_state_client)
REDIS_URL     = os.getenv("REDIS_STATE_URL", os.getenv("REDIS_URL", "redis://127.0.0.1:6380"))
EMBED_DIM     = 768          # fastembed Jina 768d LOCAL (Kernell OS standard)

# Import centralized threshold
try:
    from agents.core.memory.kms_config import RAG_SCORE_THRESHOLD
except ImportError:
    RAG_SCORE_THRESHOLD = 0.65

from .qdrant_time_payload import attach_kernell_time_metadata

# Audit channel en Redis
AUDIT_CHANNEL  = "kernell:memory:audit"
AUDIT_LOG_KEY  = "kernell:memory:audit_log"
METRICS_KEY    = "kernell:memory:broker_metrics"
DEDUP_TTL      = 86400 * 7   # 7 días para deduplicación por hash


# ─── COLECCIONES ──────────────────────────────────────────────────────────────

class Collection(str, Enum):
    """
    Valores físicos: kernell_memory | kernell_episodes (ADR MEMORY_COLLECTIONS_ADR).
    FUSION/SKILLS/INTERACTIONS son alias lógicos al mismo string — distinguir por
    payload.memory_type / tags, no por nombre de colección duplicado en Qdrant.
    """

    MEMORY       = "kernell_memory"
    EPISODES     = "kernell_episodes"
    FUSION       = "kernell_memory"
    SKILLS       = "kernell_memory"
    INTERACTIONS = "kernell_memory"


COLLECTION_SCHEMAS = {
    Collection.MEMORY: {
        "description": "Memoria principal: docs, facts, walkthroughs, ADRs",
        "vector_params": VectorParams(size=EMBED_DIM, distance=Distance.COSINE),
        "allowed_writers": ["atlas", "archivist", "forge", "memory_cortex", "memory_attention"],
        "allowed_types": ["documentation", "journal", "key_value", "distilled",
                          "architectural_decision", "error_resolution"],
    },
    Collection.EPISODES: {
        "description": "Episodios causales: observación → decisión → acción → outcome",
        "vector_params": VectorParams(size=EMBED_DIM, distance=Distance.COSINE),
        "allowed_writers": ["*"],   # Todos los agentes pueden registrar episodios
        "allowed_types": ["success_pattern", "error_resolution", "decision",
                          "skill_execution", "task_result"],
    },
    Collection.FUSION: {
        "description": "Entidades correlacionadas cross-domain",
        "vector_params": VectorParams(size=EMBED_DIM, distance=Distance.COSINE),
        "allowed_writers": ["atlas", "kernel", "chronos"],
        "allowed_types": ["entity_correlation", "domain_synthesis", "pattern_cluster"],
    },
    Collection.SKILLS: {
        "description": "Skills aprendidos por agente, versionados con score",
        "vector_params": VectorParams(size=EMBED_DIM, distance=Distance.COSINE),
        "allowed_writers": ["*"],
        "allowed_types": ["skill_v1", "skill_update", "skill_deprecation"],
    },
    Collection.INTERACTIONS: {
        "description": "Interacciones inter-agente para análisis de red",
        "vector_params": VectorParams(size=EMBED_DIM, distance=Distance.COSINE),
        "allowed_writers": ["overseer", "atlas", "kernel"],
        "allowed_types": ["agent_interaction", "delegation", "collaboration"],
    },
}


# ─── MODELOS DE DATOS ─────────────────────────────────────────────────────────

@dataclass
class MemoryRecord:
    """Un registro a insertar en Qdrant"""
    content: str                          # Texto principal (se embedea)
    agent: str                            # Agente que escribe
    memory_type: str                      # Tipo dentro de la colección
    collection: Collection = Collection.MEMORY

    # Metadata rica
    tags: list = field(default_factory=list)
    source: Optional[str] = None          # Archivo, URL, tarea origen
    score: float = 0.5                    # Score inicial de relevancia
    version: int = 1
    extra: dict = field(default_factory=dict)

    # Autogenerados
    id: Optional[str] = None
    timestamp: Optional[str] = None
    content_hash: Optional[str] = None

    def __post_init__(self):
        if not self.id:
            self.id = str(uuid.uuid4())
        if not self.timestamp:
            self.timestamp = datetime.now(timezone.utc).isoformat()
        if not self.content_hash:
            self.content_hash = hashlib.sha256(
                self.content.encode()
            ).hexdigest()[:16]

    def to_payload(self) -> dict:
        p = {
            "content":      self.content,
            "agent":        self.agent,
            "memory_type":  self.memory_type,
            "tags":         self.tags,
            "source":       self.source,
            "score":        self.score,
            "version":      self.version,
            "timestamp":    self.timestamp,
            "content_hash": self.content_hash,
            **self.extra,
        }
        attach_kernell_time_metadata(
            p,
            agent=self.agent,
            source=(self.source or "memory_broker"),
        )
        return p


@dataclass
class EpisodeRecord:
    """Episodio causal completo para kernell_episodes"""
    agent: str
    observation: str          # Qué vio el agente
    decision: str             # Qué decidió hacer
    action: str               # Qué ejecutó
    outcome: str              # Qué pasó
    success: bool             # ¿Fue exitoso?

    task_type: Optional[str] = None
    error_msg: Optional[str] = None
    duration_ms: Optional[float] = None
    skill_used: Optional[str] = None
    score: float = 0.0        # Calculado post-ejecución

    id: Optional[str] = None
    timestamp: Optional[str] = None

    def __post_init__(self):
        if not self.id:
            self.id = str(uuid.uuid4())
        if not self.timestamp:
            self.timestamp = datetime.now(timezone.utc).isoformat()
        # Score automático basado en éxito
        if self.score == 0.0:
            self.score = 0.8 if self.success else 0.2

    def to_content(self) -> str:
        """Texto para embedear — captura la semántica del episodio"""
        status = "ÉXITO" if self.success else "FALLO"
        return (
            f"[{status}] Agente {self.agent} ejecutó {self.task_type or 'tarea'}. "
            f"Observó: {self.observation}. "
            f"Decidió: {self.decision}. "
            f"Acción: {self.action}. "
            f"Resultado: {self.outcome}."
            + (f" Error: {self.error_msg}" if self.error_msg else "")
        )

    def to_payload(self) -> dict:
        return {
            "agent":        self.agent,
            "observation":  self.observation,
            "decision":     self.decision,
            "action":       self.action,
            "outcome":      self.outcome,
            "success":      self.success,
            "task_type":    self.task_type,
            "error_msg":    self.error_msg,
            "duration_ms":  self.duration_ms,
            "skill_used":   self.skill_used,
            "score":        self.score,
            "timestamp":    self.timestamp,
            "memory_type":  "success_pattern" if self.success else "error_resolution",
        }


# ─── EMBEDDER ─────────────────────────────────────────────────────────────────

class Embedder:
    """
    Genera embeddings usando fastembed local (100% offline).
    Modelo multilenguaje: jinaai/jina-embeddings-v2-base-es (768d)
    Modelo código: jinaai/jina-embeddings-v2-base-code (768d)
    """

    def embed_sync(self, text: str, task_type: str = "retrieval_document") -> list:
        """Synchronous embedding — used by the broker internally."""
        from agents.core.embedding_config import get_embedding, get_query_embedding
        if task_type == "retrieval_query":
            return get_query_embedding(text[:8192])
        return get_embedding(text[:8192])

    async def embed(self, text: str) -> list:
        """Async wrapper for embedding — runs sync call in executor."""
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(
            None, self.embed_sync, text, "retrieval_document"
        )

    async def embed_query(self, text: str) -> list:
        """Async wrapper for query embedding."""
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(
            None, self.embed_sync, text, "retrieval_query"
        )

    async def embed_batch(self, texts: list) -> list:
        return [await self.embed(t) for t in texts]


# ─── MEMORY BROKER ────────────────────────────────────────────────────────────

class MemoryBroker:
    """
    Puerta única de escritura y lectura a Qdrant.

    Garantías:
    - Auditoría de cada operación en Redis
    - Deduplicación por hash de contenido (7 días)
    - Control de acceso por colección
    - Métricas en tiempo real
    """

    _instance = None

    @classmethod
    async def get_instance(cls) -> "MemoryBroker":
        if cls._instance is None:
            broker = cls()
            await broker.connect()
            cls._instance = broker
        else:
            # Self-healing: if dependencies failed during boot, retry connection
            if cls._instance.redis is None or cls._instance.qdrant is None:
                log.info("⚠️ MemoryBroker degraded (missing connections). Reconnecting...")
                await cls._instance.connect()
        return cls._instance

    def __init__(self):
        self.qdrant: Optional[AsyncQdrantClient] = None
        self.redis: Optional[aioredis.Redis] = None
        self.embedder = Embedder()
        self._metrics = {
            "writes_ok": 0, "writes_dedup": 0, "writes_denied": 0,
            "reads_ok": 0, "reads_miss": 0, "errors": 0,
        }

    async def connect(self):
        try:
            self.qdrant = AsyncQdrantClient(url=QDRANT_URL, timeout=10)
            log.info(f"✅ Qdrant conectado: {QDRANT_URL}")
        except Exception as e:
            log.error(f"❌ Qdrant no disponible: {e}")

        try:
            # URI explícita gana; si no, password+host+puerto; si no, constante de módulo (:6380).
            explicit = (
                os.getenv("REDIS_STATE_URL", "").strip()
                or os.getenv("REDIS_URL", "").strip()
            )
            pw = os.getenv("REDIS_PASSWORD", "").strip().strip("\"'")
            if explicit:
                redis_url = explicit
            elif pw:
                host = os.getenv("REDIS_HOST", "127.0.0.1")
                port = int(os.getenv("REDIS_PORT", "6380"))
                redis_url = f"redis://:{pw}@{host}:{port}"
            else:
                redis_url = REDIS_URL
            self.redis = await aioredis.from_url(
                redis_url, decode_responses=True,
                socket_connect_timeout=5
            )
            await self.redis.ping()
            log.info("✅ Redis conectado para auditoría")
        except Exception as e:
            log.warning(f"⚠️ Redis no disponible para auditoría: {e}")
            self.redis = None

    # ── ESCRITURA ──────────────────────────────────────────────────────────────

    async def upsert(self, record: MemoryRecord) -> dict:
        """Insertar o actualizar un registro de memoria"""
        t0 = time.monotonic()

        # 1. Control de acceso
        if not self._can_write(record.agent, record.collection, record.memory_type):
            self._metrics["writes_denied"] += 1
            return {"status": "DENIED",
                    "reason": f"{record.agent} no puede escribir en {record.collection}"}

        # 2. Deduplicación por hash
        if await self._is_duplicate(record.content_hash, record.collection):
            self._metrics["writes_dedup"] += 1
            return {"status": "DEDUP",
                    "id": record.id,
                    "reason": "Contenido idéntico ya existe"}

        # 3. Generar embedding
        try:
            vector = await self.embedder.embed(record.content)
        except Exception as e:
            self._metrics["errors"] += 1
            log.error(f"Error generando embedding: {e}")
            return {"status": "ERROR", "reason": str(e)}

        # 4. Escribir en Qdrant
        try:
            result = await self.qdrant.upsert(
                collection_name=record.collection.value,
                points=[PointStruct(
                    id=record.id,
                    vector=vector,
                    payload=record.to_payload()
                )]
            )
            if result.status != UpdateStatus.COMPLETED:
                raise RuntimeError(f"Qdrant upsert status: {result.status}")
        except Exception as e:
            self._metrics["errors"] += 1
            log.error(f"Error escribiendo en Qdrant [{record.collection}]: {e}")
            return {"status": "ERROR", "reason": str(e)}

        # 5. Marcar hash como procesado
        await self._mark_hash(record.content_hash, record.collection)

        # 6. Auditar
        elapsed = (time.monotonic() - t0) * 1000
        self._metrics["writes_ok"] += 1
        await self._audit("WRITE", record.collection.value, record.agent, {
            "id": record.id, "type": record.memory_type,
            "latency_ms": round(elapsed, 1), "tags": record.tags,
        })

        return {"status": "OK", "id": record.id, "latency_ms": round(elapsed, 1)}

    async def upsert_batch(self, records: list) -> dict:
        """Insertar múltiples registros eficientemente"""
        results = {"ok": 0, "dedup": 0, "denied": 0, "errors": 0, "ids": []}
        tasks = [self.upsert(r) for r in records]
        outcomes = await asyncio.gather(*tasks, return_exceptions=True)

        for outcome in outcomes:
            if isinstance(outcome, Exception):
                results["errors"] += 1
            elif outcome["status"] == "OK":
                results["ok"] += 1
                results["ids"].append(outcome["id"])
            elif outcome["status"] == "DEDUP":
                results["dedup"] += 1
            elif outcome["status"] == "DENIED":
                results["denied"] += 1
            else:
                results["errors"] += 1

        return results

    async def upsert_episode(self, episode: EpisodeRecord) -> dict:
        """Registrar un episodio causal en kernell_episodes"""
        record = MemoryRecord(
            content=episode.to_content(),
            agent=episode.agent,
            memory_type="success_pattern" if episode.success else "error_resolution",
            collection=Collection.EPISODES,
            score=episode.score,
            tags=[episode.task_type or "general",
                  "success" if episode.success else "failure"],
            extra=episode.to_payload(),
        )
        record.id = episode.id
        return await self.upsert(record)

    async def upsert_skill(
        self,
        agent: str,
        skill_name: str,
        skill_content: str,
        score: float,
        version: int,
        evidence_ids: list = None,
    ) -> dict:
        """Versionar un skill aprendido en kernell_memory"""
        record = MemoryRecord(
            content=f"SKILL [{skill_name}] agente {agent}: {skill_content}",
            agent=agent,
            memory_type="skill_update",
            collection=Collection.SKILLS,
            score=score,
            version=version,
            tags=[skill_name, agent, f"v{version}"],
            extra={
                "skill_name":   skill_name,
                "evidence_ids": evidence_ids or [],
            },
        )
        return await self.upsert(record)

    # ── LECTURA / RAG ──────────────────────────────────────────────────────────

    async def query(
        self,
        text: str,
        collection: Collection = Collection.MEMORY,
        top_k: int = 5,
        score_threshold: float = RAG_SCORE_THRESHOLD,
        filter_agent: Optional[str] = None,
        filter_type: Optional[str] = None,
    ) -> list:
        """
        Consulta semántica. SIEMPRE se llama antes de ir al LLM.
        Retorna lista de resultados ordenados por score.
        """
        if not self.qdrant:
            self._metrics["reads_miss"] += 1
            return []

        try:
            vector = await self.embedder.embed_query(text)
        except Exception as e:
            log.error(f"Error embedding query: {e}")
            return []

        # Construir filtro opcional
        must_conditions = []
        if filter_agent:
            must_conditions.append(
                FieldCondition(key="agent", match=MatchValue(value=filter_agent))
            )
        if filter_type:
            must_conditions.append(
                FieldCondition(key="memory_type", match=MatchValue(value=filter_type))
            )

        query_filter = Filter(must=must_conditions) if must_conditions else None

        try:
            results: list = await self.qdrant.search(
                collection_name=collection.value,
                query_vector=vector,
                limit=top_k,
                score_threshold=score_threshold,
                query_filter=query_filter,
                with_payload=True,
            )
        except Exception as e:
            log.error(f"Error en query Qdrant [{collection}]: {e}")
            self._metrics["reads_miss"] += 1
            return []

        self._metrics["reads_ok"] += 1
        await self._audit("READ", collection.value, "query", {
            "text_preview": text[:80],
            "results": len(results),
            "top_score": results[0].score if results else 0,
        })

        return [
            {
                "id":      r.id,
                "score":   round(r.score, 4),
                "content": r.payload.get("content", ""),
                "type":    r.payload.get("memory_type", ""),
                "agent":   r.payload.get("agent", ""),
                "tags":    r.payload.get("tags", []),
                "ts":      r.payload.get("timestamp", ""),
                **{k: v for k, v in r.payload.items()
                   if k not in ("content", "memory_type", "agent", "tags", "timestamp")},
            }
            for r in results
        ]

    async def query_all_collections(self, text: str, top_k: int = 3) -> dict:
        """
        Consulta TODOS los niveles de memoria en paralelo.
        Implementa el protocolo 'Qdrant First' para todos los agentes.
        """
        tasks = {
            col: self.query(text, col, top_k=top_k)
            for col in Collection
        }
        results = await asyncio.gather(*tasks.values(), return_exceptions=True)
        return {
            col_name: (r if not isinstance(r, Exception) else [])
            for col_name, r in zip(tasks.keys(), results)
        }

    async def recall_for_agent(
        self, agent: str, task_description: str, top_k: int = 5
    ) -> dict:
        """
        Punto de entrada principal para los agentes antes de llamar al LLM.
        Consulta episodios pasados + skills + memoria general del agente.
        """
        results = await asyncio.gather(
            # Episodios del propio agente
            self.query(task_description, Collection.EPISODES,
                       top_k=top_k, filter_agent=agent),
            # Skills relevantes del agente
            self.query(task_description, Collection.SKILLS,
                       top_k=3, filter_agent=agent),
            # Memoria general relacionada
            self.query(task_description, Collection.MEMORY, top_k=top_k),
        )

        episodes, skills, general = results
        has_memory = any([episodes, skills, general])

        return {
            "has_memory":    has_memory,
            "episodes":      episodes,
            "skills":        skills,
            "general":       general,
            "inject_prompt": self._format_for_prompt(episodes, skills, general),
        }

    def _format_for_prompt(
        self,
        episodes: list, skills: list, general: list
    ) -> str:
        """Formatea los resultados de memoria como bloque de contexto para el LLM"""
        parts = []

        if episodes:
            parts.append("## Episodios relevantes de tu historial:")
            for e in episodes[:3]:
                status = "✅" if e.get("success") else "❌"
                parts.append(
                    f"{status} [{e['score']:.2f}] {e['content'][:200]}"
                )

        if skills:
            parts.append("\n## Skills disponibles:")
            for s in skills[:2]:
                parts.append(
                    f"- {s.get('skill_name', '?')} (score: {s.get('score', 0):.2f}): "
                    f"{s['content'][:150]}"
                )

        if general:
            parts.append("\n## Conocimiento relevante del sistema:")
            for g in general[:3]:
                parts.append(f"- [{g['score']:.2f}] {g['content'][:200]}")

        if not parts:
            return ""

        return (
            "\n<kernell_memory>\n"
            + "\n".join(parts)
            + "\n</kernell_memory>\n"
        )

    # ── CONTROL DE ACCESO ─────────────────────────────────────────────────────

    def _can_write(
        self, agent: str, collection: Collection, memory_type: str
    ) -> bool:
        schema = COLLECTION_SCHEMAS.get(collection, {})
        allowed_writers = schema.get("allowed_writers", [])
        allowed_types   = schema.get("allowed_types", [])

        if "*" not in allowed_writers and agent not in allowed_writers:
            log.warning(
                f"ACCESO DENEGADO: {agent} intentó escribir en {collection}"
            )
            return False

        if allowed_types and memory_type not in allowed_types:
            log.warning(
                f"TIPO INVÁLIDO: {memory_type} no permitido en {collection}"
            )
            return False

        return True

    # ── DEDUPLICACIÓN ─────────────────────────────────────────────────────────

    async def _is_duplicate(self, content_hash: str, collection: Collection) -> bool:
        if not self.redis:
            return False
        key = f"kernell:memory:dedup:{collection.value}:{content_hash}"
        try:
            return bool(await self.redis.exists(key))
        except Exception:
            return False

    async def _mark_hash(self, content_hash: str, collection: Collection):
        if not self.redis:
            return
        key = f"kernell:memory:dedup:{collection.value}:{content_hash}"
        try:
            await self.redis.set(key, "1", ex=DEDUP_TTL)
        except Exception:
            pass

    # ── AUDITORÍA ─────────────────────────────────────────────────────────────

    async def _audit(
        self, op: str, collection: str, agent: str, data: dict
    ):
        if not self.redis:
            return
        entry = {
            "ts":         datetime.now(timezone.utc).isoformat(),
            "op":         op,
            "collection": collection,
            "agent":      agent,
            **data,
        }
        try:
            await self.redis.publish(AUDIT_CHANNEL, json.dumps(entry))
            await self.redis.lpush(AUDIT_LOG_KEY, json.dumps(entry))
            await self.redis.ltrim(AUDIT_LOG_KEY, 0, 999)
        except Exception:
            pass

    # ── MÉTRICAS ──────────────────────────────────────────────────────────────

    async def flush_metrics(self):
        if not self.redis:
            return
        payload = {
            "ts": datetime.now(timezone.utc).isoformat(),
            **self._metrics,
        }
        try:
            await self.redis.set(METRICS_KEY, json.dumps(payload), ex=300)
        except Exception:
            pass

    @property
    def metrics(self) -> dict:
        return dict(self._metrics)
