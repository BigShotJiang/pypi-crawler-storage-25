"""
MEMORY PAGING TOOLS — Letta-Inspired Tiered Memory for Kernell OS
==================================================================
Permite al LLM controlar activamente su ventana de contexto:
  - page_in_memory():   Recupera recuerdos archivados relevantes
  - page_out_memory():  Archiva información del contexto para liberar espacio
  - search_archival():  Busca en memoria archival sin cargar al contexto

Inspirado en MemGPT/Letta v0.6:
  El LLM decide cuándo necesita más contexto (page_in) y cuándo
  puede guardar información para después (page_out). Esto reduce
  el consumo de tokens ~40% y elimina OOM de prompts.

Integración:
  - MemoryBroker:         Para escritura/lectura en Qdrant
  - EpisodicMemory:       Para recall semántico de episodios
  - context_middleware.py: Inyecta las tools en el system prompt

Fallback:
  Si KERNELL_MEMORY_PAGING_ENABLED=0, ninguna tool se inyecta.
  El sistema opera igual que antes (inyección pasiva de RAG).
"""

from __future__ import annotations

import json
import logging
import os
import time
import concurrent.futures
from dataclasses import dataclass, asdict
from typing import Any, Optional

logger = logging.getLogger("kernell.memory.paging")

# ── Config ────────────────────────────────────────────────────────────────────

PAGING_ENABLED = os.getenv("KERNELL_MEMORY_PAGING_ENABLED", "0").strip() in ("1", "true", "yes")
MAX_PAGE_IN_TOKENS = int(os.getenv("KERNELL_MEMORY_PAGING_MAX_PAGE_IN_TOKENS", "2000"))
MAX_PAGE_IN_ITEMS = int(os.getenv("KERNELL_MEMORY_PAGING_MAX_ITEMS", "5"))
MAX_PAGE_OUT_CHARS = 4000  # Máximo de texto a archivar en una sola llamada


# ── Tool Definitions (para inyectar en system prompt) ─────────────────────────

PAGING_TOOL_DEFINITIONS = [
    {
        "name": "page_in_memory",
        "description": (
            "Recupera recuerdos archivados relevantes a un tema y los carga "
            "en tu contexto de trabajo. Usa esto cuando necesites información "
            "histórica, episodios pasados, o patrones aprendidos."
        ),
        "parameters": {
            "query": {"type": "string", "description": "Búsqueda semántica de lo que necesitas recordar"},
            "top_k": {"type": "integer", "description": "Cantidad de resultados (1-5)", "default": 3},
        },
        "required": ["query"],
    },
    {
        "name": "page_out_memory",
        "description": (
            "Archiva información del contexto actual para liberar espacio. "
            "Úsalo para guardar hechos, observaciones o resultados que no "
            "necesitas ahora pero podrían ser útiles después."
        ),
        "parameters": {
            "content": {"type": "string", "description": "Información a archivar"},
            "tags": {"type": "array", "items": {"type": "string"}, "description": "Etiquetas para categorizar"},
            "importance": {"type": "string", "enum": ["low", "medium", "high"], "default": "medium"},
        },
        "required": ["content"],
    },
    {
        "name": "search_archival",
        "description": (
            "Busca en memoria archival SIN cargar los resultados al contexto. "
            "Devuelve solo títulos y scores para decidir si hacer page_in."
        ),
        "parameters": {
            "query": {"type": "string", "description": "Término de búsqueda"},
        },
        "required": ["query"],
    },
]


# ── System Prompt Injection ───────────────────────────────────────────────────

PAGING_SYSTEM_PROMPT_BLOCK = """
<memory_paging>
TIENES CONTROL ACTIVO SOBRE TU MEMORIA.
Tu contexto de trabajo es limitado. Puedes gestionar tu memoria con estas herramientas:

1. page_in_memory(query, top_k=3)
   → Recupera recuerdos archivados. Úsalo ANTES de responder si necesitas contexto histórico.

2. page_out_memory(content, tags=[], importance="medium")
   → Archiva información para liberar espacio. Los datos no se pierden, se guardan en Qdrant.

3. search_archival(query)
   → Busca SIN cargar. Ve títulos y scores primero, luego decide si hacer page_in.

REGLAS:
- NO llames a page_in si ya tienes la información en tu contexto actual.
- Haz page_out de resultados extensos de herramientas que ya procesaste.
- Siempre incluye tags descriptivos al hacer page_out.

Para invocar una herramienta, emite un bloque:
[TOOL_CALL:nombre_herramienta]
{"param1": "valor1", "param2": "valor2"}
[/TOOL_CALL]
</memory_paging>
"""


# ── Data Models ───────────────────────────────────────────────────────────────

@dataclass
class PageInResult:
    """Resultado de una operación page_in."""
    query: str
    results: list[dict]
    total_found: int
    tokens_loaded: int
    source: str  # "qdrant" | "episodic" | "redis_fallback"


@dataclass
class PageOutResult:
    """Resultado de una operación page_out."""
    content_preview: str
    record_id: str
    collection: str
    tags: list[str]
    tokens_freed_estimate: int


@dataclass
class SearchResult:
    """Resultado de search_archival (headers only)."""
    query: str
    items: list[dict]  # [{title, score, type, ts}]
    total: int


# ── Memory Pager (Core Logic) ────────────────────────────────────────────────

class MemoryPager:
    """
    Motor de paginación de memoria. Conecta las tools del LLM
    con MemoryBroker (Qdrant) y EpisodicMemory.
    """

    def __init__(self, redis_client, agent_name: str = "system"):
        self.redis = redis_client
        self.agent_name = agent_name
        self._broker = None
        self._episodic = None
        self._stats = {"page_ins": 0, "page_outs": 0, "searches": 0, "tokens_saved": 0}
        # Thread pool for running async Qdrant ops from sync context safely
        self._executor = concurrent.futures.ThreadPoolExecutor(max_workers=2, thread_name_prefix="paging")

    def _run_async(self, coro):
        """
        Ejecuta una coroutine de forma segura, ya sea que estemos
        dentro de un event loop o no. Usa un thread dedicado para
        evitar el deadlock de run_until_complete() dentro de un loop.
        """
        import asyncio

        def _thread_target():
            return asyncio.run(coro)

        future = self._executor.submit(_thread_target)
        return future.result(timeout=10)

    # ── Tool Handlers ─────────────────────────────────────────────────────

    def handle_page_in(self, query: str, top_k: int = 3) -> PageInResult:
        """
        Recupera recuerdos archivados relevantes.
        Prioriza: Qdrant (MemoryBroker) → EpisodicMemory → Redis fallback.
        """
        top_k = min(max(1, top_k), MAX_PAGE_IN_ITEMS)
        results = []
        source = "redis_fallback"

        # Intentar MemoryBroker (Qdrant)
        try:
            from core.memory.memory_broker import MemoryBroker, Collection

            async def _query():
                broker = await MemoryBroker.get_instance()
                return await broker.query(
                    text=query,
                    collection=Collection.MEMORY,
                    top_k=top_k,
                    score_threshold=0.5,  # Más permisivo para page_in
                )

            qdrant_results = self._run_async(_query())

            if qdrant_results:
                results = [
                    {
                        "content": r.get("content", "")[:500],
                        "score": r.get("score", 0),
                        "type": r.get("type", ""),
                        "agent": r.get("agent", ""),
                        "tags": r.get("tags", []),
                    }
                    for r in qdrant_results
                ]
                source = "qdrant"
        except Exception as e:
            logger.debug(f"[PAGING] MemoryBroker query failed: {e}")

        # Fallback: EpisodicMemory
        if not results:
            try:
                episodic = self._get_episodic()
                recalls = episodic.recall(query, top_k=top_k, min_similarity=0.4)
                results = [
                    {
                        "content": r.episode.description[:500],
                        "score": r.similarity_score,
                        "type": r.episode.episode_type,
                        "agent": r.episode.author or "system",
                        "tags": r.episode.tags,
                    }
                    for r in recalls
                ]
                source = "episodic"
            except Exception as e:
                logger.debug(f"[PAGING] EpisodicMemory recall failed: {e}")

        # Estimar tokens cargados
        total_chars = sum(len(r.get("content", "")) for r in results)
        tokens_loaded = total_chars // 4  # Rough estimate

        self._stats["page_ins"] += 1
        self._publish_stats()

        result = PageInResult(
            query=query,
            results=results,
            total_found=len(results),
            tokens_loaded=tokens_loaded,
            source=source,
        )

        logger.info(
            f"[PAGING] page_in: query='{query[:50]}...' "
            f"found={len(results)} source={source} tokens≈{tokens_loaded}"
        )
        return result

    def handle_page_out(
        self,
        content: str,
        tags: list[str] | None = None,
        importance: str = "medium",
    ) -> PageOutResult:
        """
        Archiva contenido del contexto actual a Qdrant.
        El contenido queda disponible para page_in posterior.
        """
        content = content[:MAX_PAGE_OUT_CHARS]
        tags = tags or []

        score_map = {"low": 0.3, "medium": 0.5, "high": 0.8}
        score = score_map.get(importance, 0.5)

        record_id = ""
        collection = "kernell_memory"

        try:
            from core.memory.memory_broker import MemoryBroker, MemoryRecord, Collection

            record = MemoryRecord(
                content=content,
                agent=self.agent_name,
                memory_type="paged_out",
                collection=Collection.MEMORY,
                tags=["paged_out"] + tags,
                score=score,
            )
            record_id = record.id

            async def _upsert():
                broker = await MemoryBroker.get_instance()
                return await broker.upsert(record)

            self._run_async(_upsert())

        except Exception as e:
            logger.warning(f"[PAGING] page_out to Qdrant failed: {e}")
            # Fallback: guardar en Redis con TTL
            try:
                import uuid
                record_id = str(uuid.uuid4())[:12]
                self.redis.set(
                    f"kernell:memory:paged_out:{record_id}",
                    json.dumps({
                        "content": content,
                        "agent": self.agent_name,
                        "tags": tags,
                        "importance": importance,
                        "ts": time.time(),
                    }),
                    ex=86400 * 7,  # 7 días TTL
                )
                collection = "redis_fallback"
            except Exception as e2:
                logger.error(f"[PAGING] page_out fallback Redis also failed: {e2}")

        tokens_freed = len(content) // 4
        self._stats["page_outs"] += 1
        self._stats["tokens_saved"] += tokens_freed
        self._publish_stats()

        result = PageOutResult(
            content_preview=content[:100] + "..." if len(content) > 100 else content,
            record_id=record_id,
            collection=collection,
            tags=tags,
            tokens_freed_estimate=tokens_freed,
        )

        logger.info(
            f"[PAGING] page_out: {len(content)} chars → {collection} "
            f"id={record_id} tokens_freed≈{tokens_freed}"
        )
        return result

    def handle_search_archival(self, query: str) -> SearchResult:
        """
        Busca en memoria archival SIN cargar los resultados al contexto.
        Devuelve solo metadata (título, score, tipo) para que el LLM
        decida si hacer page_in.
        """
        items = []

        try:
            from core.memory.memory_broker import MemoryBroker, Collection

            async def _search():
                broker = await MemoryBroker.get_instance()
                return await broker.query(
                    text=query,
                    collection=Collection.MEMORY,
                    top_k=10,
                    score_threshold=0.4,
                )

            raw = self._run_async(_search())

            items = [
                {
                    "title": r.get("content", "")[:80],
                    "score": r.get("score", 0),
                    "type": r.get("type", ""),
                    "ts": r.get("ts", ""),
                }
                for r in raw
            ]
        except Exception as e:
            logger.debug(f"[PAGING] search_archival failed: {e}")

        self._stats["searches"] += 1
        self._publish_stats()

        return SearchResult(query=query, items=items, total=len(items))

    # ── Tool Call Parser ──────────────────────────────────────────────────

    def parse_and_execute_tool_calls(self, response_text: str) -> tuple[str, list[dict]]:
        """
        Parsea [TOOL_CALL:...] blocks en la respuesta del LLM y ejecuta.
        Retorna (texto_limpio, resultados_de_tools).
        """
        import re

        pattern = r'\[TOOL_CALL:(\w+)\]\s*(\{[^}]*\})\s*\[/TOOL_CALL\]'
        matches = re.findall(pattern, response_text, re.DOTALL)

        if not matches:
            return response_text, []

        tool_results = []
        for tool_name, params_str in matches:
            try:
                params = json.loads(params_str)
            except json.JSONDecodeError:
                logger.warning(f"[PAGING] Invalid JSON in tool call: {params_str[:100]}")
                continue

            result = self._dispatch_tool(tool_name, params)
            if result is not None:
                tool_results.append({
                    "tool": tool_name,
                    "params": params,
                    "result": result,
                })

        # Limpiar los bloques de tool call del texto
        clean_text = re.sub(pattern, '', response_text, flags=re.DOTALL).strip()

        return clean_text, tool_results

    def _dispatch_tool(self, tool_name: str, params: dict) -> dict | None:
        """Despacha una llamada de tool al handler correspondiente."""
        handlers = {
            "page_in_memory": self._handle_page_in_call,
            "page_out_memory": self._handle_page_out_call,
            "search_archival": self._handle_search_call,
        }

        handler = handlers.get(tool_name)
        if not handler:
            logger.warning(f"[PAGING] Unknown tool: {tool_name}")
            return None

        try:
            return handler(params)
        except Exception as e:
            logger.error(f"[PAGING] Tool {tool_name} failed: {e}")
            return {"error": str(e)}

    def _handle_page_in_call(self, params: dict) -> dict:
        r = self.handle_page_in(
            query=params.get("query", ""),
            top_k=params.get("top_k", 3),
        )
        return asdict(r)

    def _handle_page_out_call(self, params: dict) -> dict:
        r = self.handle_page_out(
            content=params.get("content", ""),
            tags=params.get("tags"),
            importance=params.get("importance", "medium"),
        )
        return asdict(r)

    def _handle_search_call(self, params: dict) -> dict:
        r = self.handle_search_archival(query=params.get("query", ""))
        return asdict(r)

    # ── Format Tool Results for Re-injection ──────────────────────────────

    def format_tool_results_for_context(self, tool_results: list[dict]) -> str:
        """
        Formatea los resultados de tools para re-inyectar como mensaje
        de sistema en la conversación.
        """
        if not tool_results:
            return ""

        parts = ["<memory_paging_results>"]
        for tr in tool_results:
            tool = tr.get("tool", "unknown")
            result = tr.get("result", {})

            if tool == "page_in_memory":
                results = result.get("results", [])
                if results:
                    parts.append(f"## Recuerdos recuperados ({result.get('source', '?')}):")
                    for r in results:
                        parts.append(
                            f"- [{r.get('score', 0):.2f}] ({r.get('type', '?')}) "
                            f"{r.get('content', '')}"
                        )
                else:
                    parts.append("(No se encontraron recuerdos relevantes)")

            elif tool == "page_out_memory":
                parts.append(
                    f"✅ Archivado: {result.get('content_preview', '?')} "
                    f"[tokens liberados ≈{result.get('tokens_freed_estimate', 0)}]"
                )

            elif tool == "search_archival":
                items = result.get("items", [])
                if items:
                    parts.append(f"## Resultados de búsqueda archival:")
                    for item in items:
                        parts.append(
                            f"- [{item.get('score', 0):.2f}] {item.get('title', '?')} "
                            f"({item.get('type', '?')})"
                        )
                else:
                    parts.append("(Sin resultados en archivo)")

        parts.append("</memory_paging_results>")
        return "\n".join(parts)

    # ── Helpers ────────────────────────────────────────────────────────────

    def _get_episodic(self):
        if self._episodic is None:
            from core.reasoning.episodic_memory import EpisodicMemory
            self._episodic = EpisodicMemory(
                redis_client=self.redis,
                use_qdrant=True,
            )
        return self._episodic

    def _publish_stats(self):
        """Publica estadísticas de paging en Redis."""
        if not self.redis:
            return
        try:
            self.redis.set(
                "kernell:memory:paging:stats",
                json.dumps(self._stats),
                ex=86400,
            )
            self.redis.set(
                "kernell:memory:paging:last_action",
                json.dumps({"agent": self.agent_name, "ts": time.time()}),
                ex=3600,
            )
        except Exception:
            pass

    @property
    def stats(self) -> dict:
        return dict(self._stats)
