import sqlite3
import json
import os
import logging
from pathlib import Path
from typing import List, Dict, Optional, Any
from pydantic import BaseModel, Field
from datetime import datetime

logger = logging.getLogger(__name__)

DB_PATH = Path("/home/anny/kernell-os/core/state/cognitive_graph.db")

class GraphNode(BaseModel):
    id: str = Field(description="Unique ID, can match Qdrant UUID")
    label: str = Field(description="Type of entity: Agent, Concept, File, Memory")
    properties: Dict[str, Any] = Field(default_factory=dict)
    created_at: str = Field(default_factory=lambda: datetime.utcnow().isoformat())

class GraphEdge(BaseModel):
    source_id: str
    target_id: str
    relation: str = Field(description="e.g., MODIFIED, EXPLAINS, BLOCKED_BY, RESOLVED")
    score: float = 1.0
    created_at: str = Field(default_factory=lambda: datetime.utcnow().isoformat())

class CognitiveSchema:
    def __init__(self, db_path: Path = DB_PATH):
        self.db_path = db_path
        self._init_db()

    def _init_db(self):
        os.makedirs(self.db_path.parent, exist_ok=True)
        with sqlite3.connect(self.db_path) as conn:
            conn.execute('''
                CREATE TABLE IF NOT EXISTS nodes (
                    id TEXT PRIMARY KEY,
                    label TEXT,
                    properties TEXT,
                    created_at TEXT
                )
            ''')
            conn.execute('''
                CREATE TABLE IF NOT EXISTS edges (
                    source_id TEXT,
                    target_id TEXT,
                    relation TEXT,
                    score REAL,
                    created_at TEXT,
                    PRIMARY KEY (source_id, target_id, relation),
                    FOREIGN KEY(source_id) REFERENCES nodes(id),
                    FOREIGN KEY(target_id) REFERENCES nodes(id)
                )
            ''')
            conn.commit()

    def add_node(self, node: GraphNode):
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                "INSERT OR REPLACE INTO nodes (id, label, properties, created_at) VALUES (?, ?, ?, ?)",
                (node.id, node.label, json.dumps(node.properties), node.created_at)
            )
            conn.commit()

    def add_edge(self, edge: GraphEdge):
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                "INSERT OR REPLACE INTO edges (source_id, target_id, relation, score, created_at) VALUES (?, ?, ?, ?, ?)",
                (edge.source_id, edge.target_id, edge.relation, edge.score, edge.created_at)
            )
            conn.commit()

    def get_related(self, node_id: str) -> List[Dict]:
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Forward references
            cursor.execute('''
                SELECT target_id as peer_id, relation, 'outgoing' as direction 
                FROM edges WHERE source_id = ?
                UNION
                SELECT source_id as peer_id, relation, 'incoming' as direction 
                FROM edges WHERE target_id = ?
            ''', (node_id, node_id))
            
            return [dict(row) for row in cursor.fetchall()]
