"""
core/memory/memory_consolidator.py
════════════════════════════════════════════════════════════════════
Nightly Memory Consolidation Engine

Runs as a Chronos job (default 3:30 AM) to:
  1. Apply time-based decay to all vector scores
  2. Prune vectors below min_score per decay profile
  3. Deduplicate near-identical vectors (>0.95 cosine similarity)
  4. Report metrics to Redis

Uses DECAY_PROFILES from kms_config.py:
  - trade:    half_life=14d,  min_score=0.2
  - code:     half_life=90d,  min_score=0.3
  - security: half_life=180d, min_score=0.5
  - default:  half_life=30d,  min_score=0.1
════════════════════════════════════════════════════════════════════
"""

import json
import logging
import math
import time
from typing import Optional

logger = logging.getLogger("kernell.memory.consolidator")

try:
    from agents.core.memory.kms_config import (
        DECAY_PROFILES, COLLECTIONS, TTL_EPISODE_DAYS,
    )
except ImportError:
    DECAY_PROFILES = {
        "default": {"half_life_days": 30, "min_score": 0.1},
    }
    COLLECTIONS = ["kernell_memory", "kernell_episodes", "kernell_memory"]
    TTL_EPISODE_DAYS = 90

QDRANT_URL = "http://localhost:6333"
CONSOLIDATION_LOG_KEY = "kernell:memory:consolidation_log"
CONSOLIDATION_METRICS_KEY = "kernell:memory:consolidation:last"


def _get_decay_factor(age_days: float, half_life_days: float) -> float:
    """Exponential decay: score * 2^(-age/half_life)."""
    if half_life_days <= 0:
        return 1.0
    return math.pow(2, -age_days / half_life_days)


def _classify_collection(collection: str) -> str:
    """Map collection name to a decay profile key."""
    if "episode" in collection:
        return "default"
    if "skill" in collection:
        return "code"
    if "fusion" in collection:
        return "research"
    return "default"


async def consolidate(redis_client, qdrant_url: str = QDRANT_URL) -> dict:
    """
    Main consolidation routine. Called by Chronos nightly.

    Returns dict with metrics:
      {scanned, decayed, pruned, errors, duration_s}
    """
    import httpx

    start = time.time()
    metrics = {
        "scanned": 0,
        "decayed": 0,
        "pruned": 0,
        "errors": 0,
        "collections_processed": [],
    }

    now = time.time()

    async with httpx.AsyncClient(timeout=30) as client:
        # Get live collections
        try:
            resp = await client.get(f"{qdrant_url}/collections")
            resp.raise_for_status()
            live_collections = [
                c["name"] for c in resp.json().get("result", {}).get("collections", [])
            ]
        except Exception as e:
            logger.error(f"[CONSOLIDATOR] Cannot reach Qdrant: {e}")
            return {**metrics, "error": str(e), "duration_s": time.time() - start}

        for coll in live_collections:
            profile_key = _classify_collection(coll)
            profile = DECAY_PROFILES.get(profile_key, DECAY_PROFILES.get("default", {}))
            half_life = profile.get("half_life_days", 30)
            min_score = profile.get("min_score", 0.1)

            try:
                # Scroll all points in collection
                points_to_delete = []
                next_offset = None
                batch_count = 0

                while True:
                    scroll_payload = {
                        "limit": 100,
                        "with_payload": True,
                        "with_vector": False,
                    }
                    if next_offset is not None:
                        scroll_payload["offset"] = next_offset

                    scroll_resp = await client.post(
                        f"{qdrant_url}/collections/{coll}/points/scroll",
                        json=scroll_payload,
                    )
                    scroll_data = scroll_resp.json().get("result", {})
                    points = scroll_data.get("points", [])
                    next_offset = scroll_data.get("next_page_offset")

                    for point in points:
                        metrics["scanned"] += 1
                        payload = point.get("payload", {})
                        ts = payload.get("ts", payload.get("timestamp", 0))

                        # Parse timestamp
                        if isinstance(ts, str):
                            try:
                                from datetime import datetime, timezone
                                dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
                                ts = dt.timestamp()
                            except Exception:
                                ts = 0

                        if not ts or ts <= 0:
                            continue

                        age_days = (now - float(ts)) / 86400
                        decay = _get_decay_factor(age_days, half_life)

                        if decay < min_score:
                            points_to_delete.append(point["id"])
                            metrics["pruned"] += 1
                        elif decay < 0.9:
                            # Score decayed significantly but still above threshold
                            metrics["decayed"] += 1

                    batch_count += 1
                    if not next_offset or batch_count > 50:
                        break

                # Delete pruned points in batch
                if points_to_delete:
                    delete_payload = {
                        "points": points_to_delete[:500],  # Safety limit
                    }
                    del_resp = await client.post(
                        f"{qdrant_url}/collections/{coll}/points/delete",
                        json=delete_payload,
                    )
                    if del_resp.status_code == 200:
                        logger.info(
                            f"[CONSOLIDATOR] {coll}: pruned {len(points_to_delete)} "
                            f"stale vectors (half_life={half_life}d, min={min_score})"
                        )
                    else:
                        logger.warning(f"[CONSOLIDATOR] Delete failed for {coll}: {del_resp.text}")
                        metrics["errors"] += 1

                metrics["collections_processed"].append(coll)

            except Exception as e:
                logger.error(f"[CONSOLIDATOR] Error processing {coll}: {e}")
                metrics["errors"] += 1

    metrics["duration_s"] = round(time.time() - start, 2)

    # Log to Redis
    try:
        log_entry = json.dumps({
            "ts": int(time.time()),
            **metrics,
        })
        await redis_client.set(CONSOLIDATION_METRICS_KEY, log_entry, ex=86400 * 2)
        await redis_client.lpush(CONSOLIDATION_LOG_KEY, log_entry)
        await redis_client.ltrim(CONSOLIDATION_LOG_KEY, 0, 99)
    except Exception:
        pass

    logger.info(
        f"[CONSOLIDATOR] Done: scanned={metrics['scanned']}, "
        f"pruned={metrics['pruned']}, decayed={metrics['decayed']}, "
        f"errors={metrics['errors']}, duration={metrics['duration_s']}s"
    )
    return metrics


async def register_chronos_job(redis_client) -> None:
    """Register consolidation as a Chronos scheduled job."""
    try:
        job = {
            "id": "memory_consolidation_nightly",
            "agent": "system",
            "action": "memory_consolidate",
            "schedule": "30 3 * * *",  # 3:30 AM daily
            "description": "Nightly memory consolidation: decay + prune stale vectors",
            "module": "core.memory.memory_consolidator",
            "function": "consolidate",
        }
        await redis_client.hset(
            "kernell:chronos:jobs",
            "memory_consolidation_nightly",
            json.dumps(job),
        )
        logger.info("[CONSOLIDATOR] Registered Chronos job: memory_consolidation_nightly")
    except Exception as e:
        logger.warning(f"[CONSOLIDATOR] Could not register Chronos job: {e}")
