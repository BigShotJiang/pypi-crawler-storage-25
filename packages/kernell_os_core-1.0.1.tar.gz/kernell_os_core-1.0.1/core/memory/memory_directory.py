#!/usr/bin/env python3
"""
core/memory/memory_directory.py
════════════════════════════════
Memory Directory System — Persistent, typed memory index for Kernell OS.
Implements a file-backed memory taxonomy with auto-truncation.

Implements:
  1. MEMORY.md Index — Centralized index file (max 200 lines, 25KB)
  2. Typed Taxonomy — user | feedback | project | reference
  3. Topic Files — Individual memory files with YAML frontmatter
  4. Auto-Truncation — Line + byte cap with priority eviction

The MEMORY.md file is loaded into every agent's system prompt,
providing persistent cross-session knowledge.

Usage:
    from core.memory.memory_directory import MemoryDirectory

    memdir = MemoryDirectory()

    # Add a memory
    memdir.add_memory(
        title="Architect prefers dark glassmorphism",
        content="Always use dark mode with glassmorphism effects...",
        memory_type="user",
    )

    # Get the MEMORY.md index for system prompt injection
    index = memdir.get_index()

    # Load all memories of a specific type
    user_mems = memdir.get_memories_by_type("project")

    # Auto-distill from conversation
    memdir.distill_from_conversation(messages, agent_name="forge")

Sovereign Architecture — Blueprint XV
"""

import os
import sys
import json
import time
import logging
import hashlib
from pathlib import Path
from datetime import datetime, timezone
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field, asdict

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

logger = logging.getLogger("MemoryDirectory")


# ── Configuration ────────────────────────────────────────────────────────────

# Default memory directory location
DEFAULT_BASE_DIR = Path(os.getenv("KERNELL_BRAIN_DIR", str(Path.home() / ".gemini" / "kernell")))
DEFAULT_MEMORY_DIR = DEFAULT_BASE_DIR / "knowledge" / "memory"

# Index constraints
MAX_INDEX_LINES = 200
MAX_INDEX_BYTES = 25_000

# Topic file constraints
MAX_TOPIC_BYTES = 10_000

# Memory types (structured taxonomy)
MEMORY_TYPES = {
    "user":      "User preferences, role, recurring directives, design aesthetics",
    "feedback":  "LLM corrections, trust adjustments, behavioral feedback",
    "project":   "Project state, architecture decisions, active goals, blockers",
    "reference": "External data, URLs, API endpoints, configuration values",
}

# Priority for eviction (lower = evicted first when over cap)
TYPE_PRIORITY = {
    "reference": 1,
    "feedback":  2,
    "project":   3,
    "user":      4,
}


# ── Data Models ──────────────────────────────────────────────────────────────

@dataclass
class MemoryEntry:
    """A single memory entry with metadata."""
    title: str
    memory_type: str          # user | feedback | project | reference
    description: str = ""     # One-line hook for MEMORY.md
    content: str = ""         # Full content in topic file
    filename: str = ""        # Topic file name (auto-generated)
    created: str = ""
    updated: str = ""
    source_agent: str = ""    # Which agent created this
    priority: int = 0         # Higher = more important

    def __post_init__(self):
        now = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        if not self.created:
            self.created = now
        if not self.updated:
            self.updated = now
        if not self.filename:
            # Generate filename from title
            safe = self.title.lower().replace(" ", "_")
            safe = "".join(c for c in safe if c.isalnum() or c == "_")[:50]
            self.filename = f"{self.memory_type}_{safe}.md"
        if not self.priority:
            self.priority = TYPE_PRIORITY.get(self.memory_type, 2)

    def to_frontmatter(self) -> str:
        """Render topic file with YAML frontmatter."""
        lines = [
            "---",
            f"name: {self.title}",
            f"type: {self.memory_type}",
            f"description: {self.description or self.title}",
            f"created: {self.created}",
            f"updated: {self.updated}",
            f"source_agent: {self.source_agent}",
            f"priority: {self.priority}",
            "---",
            "",
        ]
        if self.content:
            lines.append(self.content)
        return "\n".join(lines)

    def to_index_line(self) -> str:
        """Render as a MEMORY.md index line."""
        hook = self.description or self.title
        return f"- [{self.title}]({self.filename}) — {hook}"


# ── Memory Directory Manager ────────────────────────────────────────────────

class MemoryDirectory:
    """
    Manages persistent memory files with a central MEMORY.md index.
    Uses priority-based eviction and typed taxonomy for cross-session persistence.
    """

    def __init__(self, memory_dir: Optional[Path] = None):
        self.memory_dir = memory_dir or DEFAULT_MEMORY_DIR
        self.memory_dir.mkdir(parents=True, exist_ok=True)
        self.index_path = self.memory_dir / "MEMORY.md"

        # In-memory cache
        self._entries: Dict[str, MemoryEntry] = {}
        self._load_existing()

    # ── Core CRUD ────────────────────────────────────────────────────────

    def add_memory(
        self,
        title: str,
        content: str,
        memory_type: str = "project",
        description: str = "",
        source_agent: str = "",
        priority: int = 0,
    ) -> MemoryEntry:
        """
        Add or update a memory entry.

        If a memory with the same title exists, it's updated.
        The MEMORY.md index is automatically rebuilt.
        """
        if memory_type not in MEMORY_TYPES:
            logger.warning(f"Unknown memory type '{memory_type}', defaulting to 'project'")
            memory_type = "project"

        # Check for existing entry with same title
        existing = self._find_by_title(title)
        if existing:
            existing.content = content
            existing.description = description or existing.description
            existing.updated = datetime.now(timezone.utc).strftime("%Y-%m-%d")
            existing.source_agent = source_agent or existing.source_agent
            entry = existing
        else:
            entry = MemoryEntry(
                title=title,
                memory_type=memory_type,
                description=description,
                content=content,
                source_agent=source_agent,
                priority=priority,
            )

        self._entries[entry.filename] = entry

        # Write topic file
        self._write_topic_file(entry)

        # Rebuild index
        self._rebuild_index()

        logger.info(f"💾 Memory {'updated' if existing else 'added'}: [{memory_type}] {title}")
        return entry

    def remove_memory(self, title: str) -> bool:
        """Remove a memory entry by title."""
        entry = self._find_by_title(title)
        if not entry:
            return False

        # Remove topic file
        topic_path = self.memory_dir / entry.filename
        if topic_path.exists():
            topic_path.unlink()

        # Remove from cache
        del self._entries[entry.filename]

        # Rebuild index
        self._rebuild_index()

        logger.info(f"🗑️  Memory removed: {title}")
        return True

    def get_memory(self, title: str) -> Optional[MemoryEntry]:
        """Get a specific memory by title."""
        return self._find_by_title(title)

    def get_memories_by_type(self, memory_type: str) -> List[MemoryEntry]:
        """Get all memories of a specific type."""
        return [e for e in self._entries.values() if e.memory_type == memory_type]

    def get_all_memories(self) -> List[MemoryEntry]:
        """Get all memories sorted by type then priority."""
        entries = list(self._entries.values())
        entries.sort(key=lambda e: (-e.priority, e.memory_type, e.title))
        return entries

    # ── Index Management ─────────────────────────────────────────────────

    def get_index(self) -> str:
        """
        Get the MEMORY.md index content for system prompt injection.
        Reads from disk to ensure freshness.
        """
        if self.index_path.exists():
            return self.index_path.read_text(encoding="utf-8")
        return ""

    def _rebuild_index(self):
        """
        Rebuild the MEMORY.md index from all entries.
        Respects MAX_INDEX_LINES and MAX_INDEX_BYTES constraints.
        Uses priority-based eviction when over cap.
        """
        entries = self.get_all_memories()

        lines = [
            "# MEMORY.md — Kernell OS Persistent Memory Index",
            "",
            f"*Last updated: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}*",
            f"*Entries: {len(entries)}*",
            "",
        ]

        # Group by type
        for mem_type, type_desc in MEMORY_TYPES.items():
            type_entries = [e for e in entries if e.memory_type == mem_type]
            if not type_entries:
                continue

            lines.append(f"## {mem_type.capitalize()}")
            lines.append(f"*{type_desc}*")
            lines.append("")

            for entry in type_entries:
                lines.append(entry.to_index_line())

            lines.append("")

        # Apply constraints
        content = "\n".join(lines)

        # Byte cap
        if len(content.encode("utf-8")) > MAX_INDEX_BYTES:
            content = self._truncate_by_bytes(lines)

        # Line cap
        final_lines = content.split("\n")
        if len(final_lines) > MAX_INDEX_LINES:
            final_lines = final_lines[:MAX_INDEX_LINES]
            final_lines.append(f"\n*... {len(entries) - MAX_INDEX_LINES + 10} entries truncated*")
            content = "\n".join(final_lines)

        self.index_path.write_text(content, encoding="utf-8")

    def _truncate_by_bytes(self, lines: List[str]) -> str:
        """Truncate index by priority (evict lowest priority first)."""
        # Remove entry lines starting from lowest priority type
        result = []
        current_bytes = 0
        skipped = 0

        for line in lines:
            line_bytes = len(line.encode("utf-8")) + 1  # +1 for newline
            if current_bytes + line_bytes > MAX_INDEX_BYTES:
                skipped += 1
                continue
            result.append(line)
            current_bytes += line_bytes

        if skipped > 0:
            result.append(f"\n*{skipped} entries truncated due to size limit*")

        return "\n".join(result)

    # ── Distillation (integrate with memory_extractor) ───────────────────

    def distill_from_conversation(
        self,
        messages: list,
        agent_name: str = "",
        redis_client=None,
    ):
        """
        Extract memories from a conversation using the Archivist V2 pipeline.
        Upgrades the existing memory_extractor to write structured topic files.

        This runs in the background (fire-and-forget).
        """
        import threading

        def _distill():
            try:
                self._distill_sync(messages, agent_name, redis_client)
            except Exception as e:
                logger.error(f"Distillation error: {e}")

        thread = threading.Thread(target=_distill, daemon=True)
        thread.start()

    def _distill_sync(self, messages: list, agent_name: str, redis_client):
        """Synchronous distillation worker."""
        try:
            from core.sea.llm_registry import LLMProviderRegistry
            import redis as redis_lib

            r = redis_client
            if not r:
                pw = os.getenv("REDIS_PASSWORD", "").strip().strip("\"'")
                r = redis_lib.Redis(
                    host="127.0.0.1", port=6379,
                    password=pw or None, decode_responses=True,
                    socket_connect_timeout=2,
                )
                r.ping()

            registry = LLMProviderRegistry(r)

            # Build context from recent messages
            recent = messages[-30:] if len(messages) > 30 else messages
            context_parts = []
            for msg in recent:
                role = msg.get("role", "unknown")
                content = msg.get("content", "")
                if isinstance(content, list):
                    parts = [b.get("text", "") for b in content if isinstance(b, dict) and b.get("type") == "text"]
                    content = "\n".join(parts)
                if isinstance(content, str) and content.strip():
                    if len(content) > 1500:
                        content = content[:1500] + "...[TRUNCATED]"
                    context_parts.append(f"[{role.upper()}]: {content}")

            context_str = "\n\n".join(context_parts)

            system_prompt = f"""You are the Kernell OS Memory Distiller.
Analyze this conversation from agent '{agent_name}' and extract persistent memories.

Output STRICTLY as a JSON array. Each element:
{{
  "title": "Short descriptive title",
  "type": "user|feedback|project|reference",
  "description": "One-line hook for the index",
  "content": "Full content (markdown, concise, max 500 words)"
}}

Memory types:
- user: Preferences, role, recurring directives
- feedback: LLM corrections, trust adjustments
- project: Architecture decisions, goals, blockers
- reference: URLs, API endpoints, config values

Rules:
1. Only extract HIGH-VALUE, persistent information
2. Do NOT extract transient errors or generic code
3. Merge with existing knowledge if applicable
4. If nothing new to extract, return: []
5. Reply ONLY with the JSON array."""

            resp = registry.complete(
                messages=[{"role": "user", "content": f"Conversation:\n\n{context_str[:15000]}"}],
                system_prompt=system_prompt,
                role="fallback_any",
                preferred_provider="gemini_flash",
                max_tokens=3000,
                temperature=0.2,
            )

            if not resp or not resp.content:
                return

            content = resp.content.strip()
            # Strip markdown code fences
            if content.startswith("```json"):
                content = content[7:]
            if content.startswith("```"):
                content = content[3:]
            if content.endswith("```"):
                content = content[:-3]
            content = content.strip()

            if content == "[]":
                logger.info(f"[{agent_name}] Memory distillation: no new memories")
                return

            updates = json.loads(content)
            if not isinstance(updates, list):
                return

            for update in updates:
                self.add_memory(
                    title=update.get("title", "Untitled"),
                    content=update.get("content", ""),
                    memory_type=update.get("type", "project"),
                    description=update.get("description", ""),
                    source_agent=agent_name,
                )

            logger.info(f"[{agent_name}] 💾 Distilled {len(updates)} memories")

        except json.JSONDecodeError as e:
            logger.error(f"[{agent_name}] Memory distillation JSON error: {e}")
        except Exception as e:
            logger.error(f"[{agent_name}] Memory distillation error: {e}")

    # ── Internals ────────────────────────────────────────────────────────

    def _load_existing(self):
        """Load all existing topic files from disk."""
        for path in self.memory_dir.glob("*.md"):
            if path.name == "MEMORY.md":
                continue
            try:
                entry = self._parse_topic_file(path)
                if entry:
                    self._entries[entry.filename] = entry
            except Exception as e:
                logger.debug(f"Could not parse {path.name}: {e}")

        logger.info(f"Loaded {len(self._entries)} existing memories from {self.memory_dir}")

    def _parse_topic_file(self, path: Path) -> Optional[MemoryEntry]:
        """Parse a topic file with YAML frontmatter into a MemoryEntry."""
        import re

        raw = path.read_text(encoding="utf-8")
        match = re.match(r"^---\s*\n(.*?)\n---\s*\n(.*)$", raw, re.DOTALL)

        if not match:
            # No frontmatter — treat as simple content
            return MemoryEntry(
                title=path.stem,
                memory_type="project",
                content=raw.strip(),
                filename=path.name,
            )

        fm_raw = match.group(1)
        body = match.group(2).strip()

        # Parse frontmatter
        fm = {}
        for line in fm_raw.split("\n"):
            if ":" in line:
                key, _, value = line.partition(":")
                fm[key.strip()] = value.strip()

        return MemoryEntry(
            title=fm.get("name", path.stem),
            memory_type=fm.get("type", "project"),
            description=fm.get("description", ""),
            content=body,
            filename=path.name,
            created=fm.get("created", ""),
            updated=fm.get("updated", ""),
            source_agent=fm.get("source_agent", ""),
            priority=int(fm.get("priority", TYPE_PRIORITY.get(fm.get("type", "project"), 2))),
        )

    def _write_topic_file(self, entry: MemoryEntry):
        """Write a topic file with frontmatter."""
        content = entry.to_frontmatter()

        # Enforce size limit
        if len(content.encode("utf-8")) > MAX_TOPIC_BYTES:
            # Truncate content, keep frontmatter
            lines = content.split("\n")
            fm_end = -1
            for i, line in enumerate(lines):
                if i > 0 and line.strip() == "---":
                    fm_end = i
                    break

            if fm_end > 0:
                frontmatter = "\n".join(lines[:fm_end + 1])
                remaining_budget = MAX_TOPIC_BYTES - len(frontmatter.encode("utf-8")) - 100
                body = "\n".join(lines[fm_end + 1:])
                if len(body.encode("utf-8")) > remaining_budget:
                    body = body[:remaining_budget] + "\n\n*[Content truncated]*"
                content = frontmatter + "\n\n" + body

        filepath = self.memory_dir / entry.filename
        filepath.write_text(content, encoding="utf-8")

    def _find_by_title(self, title: str) -> Optional[MemoryEntry]:
        """Find an entry by title (case-insensitive)."""
        title_lower = title.lower()
        for entry in self._entries.values():
            if entry.title.lower() == title_lower:
                return entry
        return None

    # ── Status ───────────────────────────────────────────────────────────

    def get_status(self) -> dict:
        """Return status of the memory directory."""
        index_size = 0
        if self.index_path.exists():
            index_size = self.index_path.stat().st_size

        by_type = {}
        for mem_type in MEMORY_TYPES:
            by_type[mem_type] = len(self.get_memories_by_type(mem_type))

        return {
            "memory_dir": str(self.memory_dir),
            "total_entries": len(self._entries),
            "by_type": by_type,
            "index_size_bytes": index_size,
            "index_lines": len(self.get_index().split("\n")) if self.index_path.exists() else 0,
            "max_lines": MAX_INDEX_LINES,
            "max_bytes": MAX_INDEX_BYTES,
        }


# ── CLI ──────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="💾 Memory Directory — Kernell OS")
    parser.add_argument("--demo", action="store_true", help="Run demo")
    parser.add_argument("--status", action="store_true", help="Show memory status")
    parser.add_argument("--index", action="store_true", help="Print MEMORY.md index")
    parser.add_argument("--list", action="store_true", help="List all memories")
    args = parser.parse_args()

    if args.demo:
        print("=" * 60)
        print("  MEMORY DIRECTORY — Demo")
        print("=" * 60)

        memdir = MemoryDirectory()

        # Add some test memories
        memdir.add_memory(
            title="Architect Design Preferences",
            content="- Always use dark mode with glassmorphism\n- Premium aesthetic required\n- Micro-animations for engagement",
            memory_type="user",
            description="Design guidelines: dark glassmorphism, premium feel",
            source_agent="kernell",
        )

        memdir.add_memory(
            title="Nemesis Trading Rules",
            content="- Never trade during news events\n- Max drawdown 2% per trade\n- Gold (XAUUSD) primary instrument",
            memory_type="project",
            description="Core Nemesis MT5 trading constraints",
            source_agent="nemesis",
        )

        memdir.add_memory(
            title="Redis Connection",
            content="Host: 127.0.0.1\nPort: 6379\nPassword: from REDIS_PASSWORD env var",
            memory_type="reference",
            description="Redis connection parameters",
            source_agent="forge",
        )

        memdir.add_memory(
            title="DeepSeek R1 Role Drift",
            content="R1 tends to role-drift when given creative tasks. Always inject [ROLE LOCK] anchor.",
            memory_type="feedback",
            description="LLM behavioral note: R1 role drift mitigation",
            source_agent="sentinel",
        )

        # Show index
        print(f"\n📋 MEMORY.md Index:\n")
        print(memdir.get_index())

        # Status
        print(f"\n📊 Status:")
        print(json.dumps(memdir.get_status(), indent=2))

        print(f"\n{'=' * 60}")
        print("  DEMO COMPLETE ✅")
        print(f"{'=' * 60}")

    elif args.status:
        memdir = MemoryDirectory()
        print(json.dumps(memdir.get_status(), indent=2))

    elif args.index:
        memdir = MemoryDirectory()
        idx = memdir.get_index()
        if idx:
            print(idx)
        else:
            print("No MEMORY.md index found.")

    elif args.list:
        memdir = MemoryDirectory()
        memories = memdir.get_all_memories()
        if not memories:
            print("No memories found.")
        else:
            print(f"\n💾 Memories ({len(memories)}):\n")
            for m in memories:
                print(f"  [{m.memory_type:>9}] {m.title}")
                if m.description:
                    print(f"             {m.description}")

    else:
        parser.print_help()
