"""Sand Weekly Nest"""
__version__ = "1.0.0"
