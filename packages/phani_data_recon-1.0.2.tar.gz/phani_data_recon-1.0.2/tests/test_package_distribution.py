import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))


def test_package_import_and_api_exposed():
    import phani_data_recon.api as api

    assert hasattr(api, "run_reconciliation")


def test_cli_parse_args_accepts_new_defaults():
    from phani_data_recon import cli

    args = cli.parse_args(["--dry-run"])
    assert args.dry_run is True
    assert args.config is None
