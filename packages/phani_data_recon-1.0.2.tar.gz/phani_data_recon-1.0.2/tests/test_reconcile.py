import sys
from pathlib import Path
import duckdb
import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))
from load_data   import load_config, load_csv_to_duckdb, apply_derived_columns
from standardize import standardize
from reconcile   import deduplicate, get_duplicates, exact_join, get_matched, get_sap_only, get_sf_only, compare_fields

FIXTURES = Path(__file__).parent / "fixtures"
CONFIG   = Path(__file__).parent.parent / "config" / "rules.yaml"


def _full_setup():
    con = duckdb.connect()
    cfg = load_config(str(CONFIG))
    load_csv_to_duckdb(con, str(FIXTURES / "sap_sample.csv"), "sap_raw")
    load_csv_to_duckdb(con, str(FIXTURES / "sf_sample.csv"),  "sf_raw")
    con.execute("CREATE TABLE sap_work AS SELECT *, ROW_NUMBER() OVER () AS _rownum FROM sap_raw;")
    con.execute("CREATE TABLE sf_work  AS SELECT *, ROW_NUMBER() OVER () AS _rownum FROM sf_raw;")
    derived = cfg.get("derived_columns", {}).get("sap", [])
    if derived:
        apply_derived_columns(con, "sap_work", derived)
    standardize(con, cfg)
    return con, cfg


def test_deduplication_reduces_sap():
    con, cfg = _full_setup()
    counts = deduplicate(con, cfg)
    # SAP has 9 rows with 2 duplicate IDs → 7 unique
    assert counts["sap_unique_count"] == 7
    assert counts["sap_dup_count"] == 2


def test_deduplication_sf_no_duplicates():
    con, cfg = _full_setup()
    counts = deduplicate(con, cfg)
    assert counts["sf_unique_count"] == 9
    assert counts["sf_dup_count"] == 0


def test_get_duplicates_sap():
    con, cfg = _full_setup()
    deduplicate(con, cfg)
    dup_sap, dup_sf = get_duplicates(con, cfg)
    assert len(dup_sap) == 4   # 2 IDs × 2 rows each
    assert len(dup_sf) == 0


def test_exact_join_produces_tables():
    con, cfg = _full_setup()
    deduplicate(con, cfg)
    counts = exact_join(con, cfg)
    # Sample data has no overlapping IDs → all SAP-only and SF-only
    assert counts["matched_count"]  == 0
    assert counts["sap_only_count"] == 7
    assert counts["sf_only_count"]  == 9


def test_sap_only_dataframe():
    con, cfg = _full_setup()
    deduplicate(con, cfg)
    exact_join(con, cfg)
    df = get_sap_only(con)
    assert len(df) == 7
    assert "SAP_Unique_ID" in df.columns


def test_sf_only_dataframe():
    con, cfg = _full_setup()
    deduplicate(con, cfg)
    exact_join(con, cfg)
    df = get_sf_only(con)
    assert len(df) == 9


def test_matched_empty_when_no_overlap():
    con, cfg = _full_setup()
    deduplicate(con, cfg)
    exact_join(con, cfg)
    df = get_matched(con)
    assert len(df) == 0


def test_field_comparison_returns_dataframe():
    con, cfg = _full_setup()
    deduplicate(con, cfg)
    exact_join(con, cfg)
    df = compare_fields(con, cfg)
    # No matches → no field mismatches either
    assert "field_label" in df.columns or df.empty


def test_exact_join_uses_primary_only_when_fallback_disabled():
    con = duckdb.connect()
    con.execute(
        """
        CREATE TABLE sap_clean (
            SAP_Unique_ID VARCHAR,
            name1 VARCHAR,
            _rownum BIGINT
        );
        CREATE TABLE sf_clean (
            BP_PowerCerv_Account_Id__c VARCHAR,
            WC_SAP_Identification__c VARCHAR,
            Name VARCHAR,
            _rownum BIGINT
        );
        INSERT INTO sap_clean VALUES ('100', 'Acme Dental', 1);
        INSERT INTO sf_clean VALUES ('', '100', 'Acme Dental', 1);
        """
    )

    cfg = {
        "join": {
            "primary": {"sap_col": "SAP_Unique_ID", "sf_col": "BP_PowerCerv_Account_Id__c"},
            "fallback": {"enabled": False, "sf_col": "WC_SAP_Identification__c"},
        },
        "dedup": {"sap_strategy": "keep_first", "sf_strategy": "keep_first"},
        "field_mappings": [],
    }

    deduplicate(con, cfg)
    counts = exact_join(con, cfg)
    assert counts["matched_count"] == 0
    assert counts["sap_only_count"] == 1
    assert counts["sf_only_count"] == 1


def test_exact_join_can_use_fallback_when_enabled():
    con = duckdb.connect()
    con.execute(
        """
        CREATE TABLE sap_clean (
            SAP_Unique_ID VARCHAR,
            name1 VARCHAR,
            _rownum BIGINT
        );
        CREATE TABLE sf_clean (
            BP_PowerCerv_Account_Id__c VARCHAR,
            WC_SAP_Identification__c VARCHAR,
            Name VARCHAR,
            _rownum BIGINT
        );
        INSERT INTO sap_clean VALUES ('100', 'Acme Dental', 1);
        INSERT INTO sf_clean VALUES ('', '100', 'Acme Dental LLC', 1);
        """
    )

    cfg = {
        "join": {
            "primary": {"sap_col": "SAP_Unique_ID", "sf_col": "BP_PowerCerv_Account_Id__c"},
            "fallback": {"enabled": True, "sf_col": "WC_SAP_Identification__c"},
        },
        "dedup": {"sap_strategy": "keep_first", "sf_strategy": "keep_first"},
        "field_mappings": [
            {
                "label": "Account Name",
                "sap_col": "name1",
                "sf_col": "Name",
                "severity": "CRITICAL",
                "compare": "exact",
                "enabled": True,
            }
        ],
    }

    deduplicate(con, cfg)
    counts = exact_join(con, cfg)
    assert counts["matched_count"] == 1
    assert counts["sap_only_count"] == 0
    assert counts["sf_only_count"] == 0

    mismatches = compare_fields(con, cfg)
    assert len(mismatches) == 1
    assert mismatches.iloc[0]["field_label"] == "Account Name"


def test_dedup_flag_all_counts_surplus_rows():
    con = duckdb.connect()
    con.execute(
        """
        CREATE TABLE sap_clean (
            SAP_Unique_ID VARCHAR,
            _rownum BIGINT
        );
        CREATE TABLE sf_clean (
            BP_PowerCerv_Account_Id__c VARCHAR,
            _rownum BIGINT
        );
        INSERT INTO sap_clean VALUES
            ('A', 1), ('A', 2), ('A', 3), ('B', 4);
        INSERT INTO sf_clean VALUES ('X', 1);
        """
    )

    cfg = {
        "join": {
            "primary": {"sap_col": "SAP_Unique_ID", "sf_col": "BP_PowerCerv_Account_Id__c"},
        },
        "dedup": {"sap_strategy": "flag_all", "sf_strategy": "keep_first"},
        "field_mappings": [],
    }

    counts = deduplicate(con, cfg)
    assert counts["sap_unique_count"] == 4
    assert counts["sap_dup_count"] == 2
