from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from utils import report_filename


def test_report_filename_includes_run_id():
    out_dir = Path("output")
    run_id = "20260508T123456-abcd1234"
    p = report_filename(out_dir, "reconciliation_report", run_id, "xlsx")
    assert run_id in p.name
    assert p.suffix == ".xlsx"
