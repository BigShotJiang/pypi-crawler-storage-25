"""
Integration test: full pipeline run on sample fixtures.
Asserts all 10 Excel sheets exist and HTML file is written.
"""

import sys
import tempfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from datetime import datetime
import duckdb

from load_data   import load_config, ingest
from standardize import standardize
from validate    import run_dq_checks
from reconcile   import deduplicate, get_duplicates, exact_join, get_matched, get_sap_only, get_sf_only, compare_fields
from fuzzy_match import run_fuzzy_match
from report      import generate_excel, generate_html
from models      import ReconciliationResult, RunMetadata
from utils       import make_run_id

FIXTURES = Path(__file__).parent / "fixtures"
CONFIG   = Path(__file__).parent.parent / "config" / "rules.yaml"
TEMPLATES= Path(__file__).parent.parent / "templates"

EXPECTED_SHEETS = [
    "Summary", "Exact_Matches", "Field_Mismatches",
    "SAP_Only", "SF_Only", "SAP_Duplicates", "SF_Duplicates",
    "Fuzzy_Match_Candidates", "Data_Quality_Issues", "Action_Plan",
]


def _run_pipeline(sap_path, sf_path, config_path):
    cfg = load_config(str(config_path))
    con = duckdb.connect()
    counts   = ingest(con, str(sap_path), str(sf_path), cfg)
    standardize(con, cfg)
    dq_df    = run_dq_checks(con, cfg)
    dedup_c  = deduplicate(con, cfg)
    dup_sap, dup_sf = get_duplicates(con, cfg)
    join_c   = exact_join(con, cfg)
    matched  = get_matched(con)
    sap_only = get_sap_only(con)
    sf_only  = get_sf_only(con)
    mismatches = compare_fields(con, cfg)
    fuzzy    = run_fuzzy_match(sap_only, sf_only, cfg)

    summary = {**counts, **dedup_c, **join_c,
               "field_mismatch_count": len(mismatches),
               "field_critical_count": int((mismatches["severity"] == "CRITICAL").sum()) if not mismatches.empty and "severity" in mismatches.columns else 0,
               "field_high_count":     int((mismatches["severity"] == "HIGH").sum())     if not mismatches.empty and "severity" in mismatches.columns else 0,
               "field_info_count":     int((mismatches["severity"] == "INFO").sum())     if not mismatches.empty and "severity" in mismatches.columns else 0,
               "fuzzy_candidate_count": len(fuzzy),
               "dq_issue_count": int(dq_df["Row Count"].sum()) if not dq_df.empty else 0,
               "sf_blank_sap_id_count": 0,
               "match_rate_pct": 0.0,
               "exception_rate_pct": 100.0,
               }

    meta = RunMetadata(
        run_id=make_run_id(),
        run_timestamp=datetime.now(),
        sap_file=str(sap_path),
        sf_file=str(sf_path),
        config_file=str(config_path),
        config_version=cfg.get("version", "1.0"),
    )
    return ReconciliationResult(
        summary=summary, matched=matched, sap_only=sap_only, sf_only=sf_only,
        field_mismatches=mismatches, duplicates_sap=dup_sap, duplicates_sf=dup_sf,
        fuzzy_candidates=fuzzy, data_quality=dq_df, metadata=meta,
    ), cfg


def test_excel_has_all_sheets():
    from openpyxl import load_workbook
    result, cfg = _run_pipeline(
        FIXTURES / "sap_sample.csv",
        FIXTURES / "sf_sample.csv",
        CONFIG,
    )
    with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as td:
        out = Path(td) / "test_report.xlsx"
        generate_excel(result, cfg, out)
        assert out.exists(), "Excel file was not created"
        wb = load_workbook(out, read_only=True)
        sheet_names = wb.sheetnames
        wb.close()
        for sheet in EXPECTED_SHEETS:
            assert sheet in sheet_names, f"Missing sheet: {sheet}"


def test_html_generated_and_nonempty():
    result, cfg = _run_pipeline(
        FIXTURES / "sap_sample.csv",
        FIXTURES / "sf_sample.csv",
        CONFIG,
    )
    with tempfile.TemporaryDirectory() as td:
        out = Path(td) / "test_report.html"
        generate_html(result, cfg, out, TEMPLATES)
        assert out.exists(), "HTML file was not created"
        size = out.stat().st_size
        assert size > 5000, f"HTML file suspiciously small: {size} bytes"


def test_summary_counts_correct():
    result, _ = _run_pipeline(
        FIXTURES / "sap_sample.csv",
        FIXTURES / "sf_sample.csv",
        CONFIG,
    )
    s = result.summary
    assert s["sap_raw_count"]   == 9
    assert s["sf_raw_count"]    == 9
    assert s["sap_unique_count"] == 7
    assert s["sap_dup_count"]   == 2
    assert s["matched_count"]   == 0     # sample has no overlapping IDs
    assert s["sap_only_count"]  == 7
    assert s["sf_only_count"]   == 9
