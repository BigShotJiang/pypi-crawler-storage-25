import sys
from pathlib import Path
import duckdb
import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))
from load_data   import load_config, load_csv_to_duckdb, apply_derived_columns
from standardize import standardize

FIXTURES = Path(__file__).parent / "fixtures"
CONFIG   = Path(__file__).parent.parent / "config" / "rules.yaml"


def _setup(con):
    cfg = load_config(str(CONFIG))
    load_csv_to_duckdb(con, str(FIXTURES / "sap_sample.csv"), "sap_raw")
    load_csv_to_duckdb(con, str(FIXTURES / "sf_sample.csv"),  "sf_raw")
    con.execute("CREATE TABLE sap_work AS SELECT *, ROW_NUMBER() OVER () AS _rownum FROM sap_raw;")
    con.execute("CREATE TABLE sf_work  AS SELECT *, ROW_NUMBER() OVER () AS _rownum FROM sf_raw;")
    derived = cfg.get("derived_columns", {}).get("sap", [])
    if derived:
        apply_derived_columns(con, "sap_work", derived)
    return cfg


def test_standardize_creates_clean_tables():
    con = duckdb.connect()
    cfg = _setup(con)
    standardize(con, cfg)
    tables = [r[0] for r in con.execute("SHOW TABLES").fetchall()]
    assert "sap_clean" in tables
    assert "sf_clean"  in tables


def test_sap_id_trimmed():
    con = duckdb.connect()
    cfg = _setup(con)
    standardize(con, cfg)
    ids = con.execute("SELECT SAP_Unique_ID FROM sap_clean").fetchdf()["SAP_Unique_ID"].tolist()
    for id_ in ids:
        if id_:
            assert id_ == id_.strip()


def test_nullify_sentinels():
    con = duckdb.connect()
    # Inject a sentinel value
    con.execute("CREATE TABLE sap_raw (SAP_Unique_ID VARCHAR, name1 VARCHAR, Name_and_address VARCHAR, vkorg VARCHAR, vtweg VARCHAR, tel_number VARCHAR, smtp_addr VARCHAR);")
    con.execute("INSERT INTO sap_raw VALUES ('999', 'N/A', 'Test,City,12345,US', 'US18', '5', '5551234567', 'unit@example.com');")
    con.execute("CREATE TABLE sap_work AS SELECT *, ROW_NUMBER() OVER () AS _rownum FROM sap_raw;")
    con.execute("CREATE TABLE sf_raw (Id VARCHAR, Name VARCHAR, BP_PowerCerv_Account_Id__c VARCHAR, WC_SAP_Identification__c VARCHAR, BillingCity VARCHAR, BillingPostalCode VARCHAR, BillingCountryCode VARCHAR, Phone VARCHAR, WC_Email__c VARCHAR, BP_Sales_Group__c VARCHAR, BP_Account_Group__c VARCHAR);")
    con.execute("CREATE TABLE sf_work AS SELECT *, ROW_NUMBER() OVER () AS _rownum FROM sf_raw;")

    from load_data import load_config
    cfg = load_config(str(CONFIG))
    standardize(con, cfg)
    row = con.execute("SELECT name1 FROM sap_clean WHERE SAP_Unique_ID = '999'").fetchone()
    assert row[0] is None
