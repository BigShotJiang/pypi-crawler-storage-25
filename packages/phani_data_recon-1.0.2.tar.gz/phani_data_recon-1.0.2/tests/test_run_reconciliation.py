import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from run_reconciliation import resolve_input_paths, resolve_output_settings


def test_resolve_input_paths_prefers_cli_values():
    args = argparse.Namespace(sap="custom/sap.csv", sf="custom/sf.csv")
    cfg = {
        "input": {
            "sap": {"directory": "input", "file_name": "sap_accounts.csv"},
            "sf": {"directory": "input", "file_name": "sf_accounts.csv"},
        }
    }
    sap, sf = resolve_input_paths(args, cfg)
    assert sap == "custom/sap.csv"
    assert sf == "custom/sf.csv"


def test_resolve_input_paths_uses_config_when_cli_missing():
    args = argparse.Namespace(sap=None, sf=None)
    cfg = {
        "input": {
            "sap": {"directory": "input", "file_name": "sap_accounts.csv"},
            "sf": {"directory": "input", "file_name": "sf_accounts.csv"},
        }
    }
    sap, sf = resolve_input_paths(args, cfg)
    assert sap == str(Path("input") / "sap_accounts.csv")
    assert sf == str(Path("input") / "sf_accounts.csv")


def test_resolve_output_settings_uses_report_block_when_present():
    args = argparse.Namespace(output_dir=None)
    cfg = {
        "output": {
            "formats": ["excel", "html"],
            "report": {"directory": "business_output", "file_name": "daily_recon"},
            "directory": "output",
            "filename_prefix": "reconciliation_report",
        }
    }
    out_dir, name = resolve_output_settings(args, cfg)
    assert out_dir == Path("business_output")
    assert name == "daily_recon"


def test_resolve_output_settings_falls_back_to_legacy_fields():
    args = argparse.Namespace(output_dir=None)
    cfg = {
        "output": {
            "formats": ["excel", "html"],
            "directory": "output",
            "filename_prefix": "reconciliation_report",
        }
    }
    out_dir, name = resolve_output_settings(args, cfg)
    assert out_dir == Path("output")
    assert name == "reconciliation_report"


def test_resolve_output_settings_cli_dir_takes_precedence():
    args = argparse.Namespace(output_dir="cli_out")
    cfg = {
        "output": {
            "formats": ["excel", "html"],
            "report": {"directory": "business_output", "file_name": "daily_recon"},
        }
    }
    out_dir, name = resolve_output_settings(args, cfg)
    assert out_dir == Path("cli_out")
    assert name == "daily_recon"
