import sys
from pathlib import Path
import duckdb
import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))
from load_data import load_config, load_csv_to_duckdb, apply_derived_columns

FIXTURES = Path(__file__).parent / "fixtures"
CONFIG   = Path(__file__).parent.parent / "config" / "rules.yaml"


def test_load_config_valid():
    cfg = load_config(str(CONFIG))
    assert cfg["version"] == "1.0"
    assert "join" in cfg
    assert cfg["join"]["primary"]["sap_col"] == "SAP_Unique_ID"


def test_load_config_missing_file():
    with pytest.raises(FileNotFoundError):
        load_config("nonexistent.yaml")


def test_load_sap_csv():
    con = duckdb.connect()
    count = load_csv_to_duckdb(con, str(FIXTURES / "sap_sample.csv"), "sap_raw")
    assert count == 9    # 9 rows including 2 duplicates for 2 IDs


def test_load_sf_csv():
    con = duckdb.connect()
    count = load_csv_to_duckdb(con, str(FIXTURES / "sf_sample.csv"), "sf_raw")
    assert count == 9


def test_derived_columns():
    con = duckdb.connect()
    load_csv_to_duckdb(con, str(FIXTURES / "sap_sample.csv"), "sap_raw")
    con.execute("CREATE TABLE sap_work AS SELECT *, ROW_NUMBER() OVER () AS _rownum FROM sap_raw;")
    derived = [
        {"name": "_derived_city",    "expression": "trim(split_part(Name_and_address, ',', 2))"},
        {"name": "_derived_postal",  "expression": "trim(split_part(Name_and_address, ',', 3))"},
        {"name": "_derived_country", "expression": "trim(split_part(Name_and_address, ',', 4))"},
    ]
    apply_derived_columns(con, "sap_work", derived)
    row = con.execute("SELECT _derived_city, _derived_postal, _derived_country FROM sap_work WHERE SAP_Unique_ID = '100626085'").fetchone()
    assert row[0] == "Mesa"
    assert row[1] == "85210-1311"
    assert row[2] == "US"


def test_missing_csv():
    con = duckdb.connect()
    with pytest.raises(FileNotFoundError):
        load_csv_to_duckdb(con, "no_such_file.csv", "test_table")
