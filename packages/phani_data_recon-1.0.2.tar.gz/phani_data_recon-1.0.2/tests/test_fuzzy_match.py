import sys
from pathlib import Path
import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))
from fuzzy_match import run_fuzzy_match
from load_data   import load_config

CONFIG = Path(__file__).parent.parent / "config" / "rules.yaml"


def test_fuzzy_disabled():
    cfg = load_config(str(CONFIG))
    cfg["fuzzy_match"]["enabled"] = False
    sap = pd.DataFrame([{"name1": "Test Dental", "smtp_addr": "unit@example.com", "tel_number": "5551234567", "SAP_Unique_ID": "999"}])
    sf  = pd.DataFrame([{"Name": "Test Dental Care", "WC_Email__c": "unit@example.com", "Phone": "5551234567", "BP_PowerCerv_Account_Id__c": ""}])
    result = run_fuzzy_match(sap, sf, cfg)
    assert result.empty


def test_fuzzy_enabled_finds_candidate():
    cfg = load_config(str(CONFIG))
    cfg["fuzzy_match"]["enabled"]   = True
    cfg["fuzzy_match"]["min_score"] = 50
    sap = pd.DataFrame([{
        "name1": "Louisiana Dental Center",
        "smtp_addr": "fuzzy@example.com",
        "tel_number": "5556438800",
        "SAP_Unique_ID": "101133024",
    }])
    sf = pd.DataFrame([{
        "Name": "Louisiana Dental Ctr",
        "WC_Email__c": "fuzzy@example.com",
        "Phone": "5556438800",
        "BP_PowerCerv_Account_Id__c": "101133024_sf",
    }])
    result = run_fuzzy_match(sap, sf, cfg)
    assert len(result) >= 1
    assert result.iloc[0]["Confidence_Score"] > 50


def test_fuzzy_empty_inputs():
    cfg = load_config(str(CONFIG))
    cfg["fuzzy_match"]["enabled"] = True
    result = run_fuzzy_match(pd.DataFrame(), pd.DataFrame(), cfg)
    assert result.empty


def test_fuzzy_below_threshold():
    cfg = load_config(str(CONFIG))
    cfg["fuzzy_match"]["enabled"]   = True
    cfg["fuzzy_match"]["min_score"] = 99
    sap = pd.DataFrame([{"name1": "ABC Corp", "smtp_addr": "abc@example.com", "tel_number": "5550000000", "SAP_Unique_ID": "001"}])
    sf  = pd.DataFrame([{"Name": "XYZ Inc",  "WC_Email__c": "xyz@example.com", "Phone":       "6660000000", "BP_PowerCerv_Account_Id__c": "002"}])
    result = run_fuzzy_match(sap, sf, cfg)
    assert result.empty
