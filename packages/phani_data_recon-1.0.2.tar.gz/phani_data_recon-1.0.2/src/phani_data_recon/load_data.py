"""
Phase A: Load CSVs into DuckDB and apply derived columns.
"""

import logging
from pathlib import Path
from typing import Any

import duckdb
import yaml
import jsonschema

logger = logging.getLogger("recon.load_data")

_SCHEMA_PATH = Path(__file__).parent / "config" / "rules.schema.json"


def load_config(config_path: str) -> dict:
    import json
    path = Path(config_path)
    if not path.exists():
        raise FileNotFoundError(f"Config not found: {config_path}")
    with open(path, encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    if _SCHEMA_PATH.exists():
        with open(_SCHEMA_PATH, encoding="utf-8") as f:
            schema = json.load(f)
        jsonschema.validate(cfg, schema)
        logger.info("Config schema validation passed.")
    return cfg


def load_csv_to_duckdb(
    con: duckdb.DuckDBPyConnection,
    csv_path: str,
    table_name: str,
    memory_limit: str = "2GB",
) -> int:
    import pandas as pd

    path = Path(csv_path)
    if not path.exists():
        raise FileNotFoundError(f"CSV not found: {csv_path}")

    con.execute(f"SET memory_limit='{memory_limit}';")

    # Pandas handles BOM (utf-8-sig) transparently; DuckDB picks it up via register()
    df = pd.read_csv(path, dtype=str, encoding="utf-8-sig", keep_default_na=False)
    df.columns = df.columns.str.strip()

    con.execute(f"DROP TABLE IF EXISTS {table_name};")
    con.register("_tmp_load", df)
    con.execute(f"CREATE TABLE {table_name} AS SELECT * FROM _tmp_load;")
    con.unregister("_tmp_load")

    count = con.execute(f"SELECT COUNT(*) FROM {table_name}").fetchone()[0]
    logger.info("Loaded %s → table '%s' (%d rows)", path.name, table_name, count)
    return count


def apply_derived_columns(
    con: duckdb.DuckDBPyConnection,
    table_name: str,
    derived_cols: list[dict],
) -> None:
    for col in derived_cols:
        name = col["name"]
        expr = col["expression"]
        con.execute(
            f"ALTER TABLE {table_name} ADD COLUMN IF NOT EXISTS \"{name}\" VARCHAR;"
        )
        con.execute(
            f"UPDATE {table_name} SET \"{name}\" = {expr};"
        )
        logger.debug("Derived column '%s' applied on '%s'", name, table_name)


def add_row_number(con: duckdb.DuckDBPyConnection, table_name: str) -> None:
    has_rownum = con.execute(
        f"SELECT column_name FROM information_schema.columns "
        f"WHERE table_name='{table_name}' AND column_name='_rownum'"
    ).fetchone()
    if not has_rownum:
        con.execute(
            f"ALTER TABLE {table_name} ADD COLUMN _rownum INTEGER DEFAULT 0;"
        )
        con.execute(
            f"UPDATE {table_name} SET _rownum = (SELECT COUNT(*) FROM {table_name} t2 WHERE t2.rowid <= {table_name}.rowid);"
        )


def ingest(
    con: duckdb.DuckDBPyConnection,
    sap_path: str,
    sf_path: str,
    cfg: dict,
) -> dict:
    perf = cfg.get("performance", {})
    mem  = perf.get("duckdb_memory_limit", "2GB")
    derived_sap = cfg.get("derived_columns", {}).get("sap", [])

    sap_raw = load_csv_to_duckdb(con, sap_path, "sap_raw", mem)
    sf_raw  = load_csv_to_duckdb(con, sf_path,  "sf_raw",  mem)

    # Clone to working tables before mutation
    con.execute("DROP TABLE IF EXISTS sap_work; CREATE TABLE sap_work AS SELECT *, ROW_NUMBER() OVER () AS _rownum FROM sap_raw;")
    con.execute("DROP TABLE IF EXISTS sf_work;  CREATE TABLE sf_work  AS SELECT *, ROW_NUMBER() OVER () AS _rownum FROM sf_raw;")

    if derived_sap:
        apply_derived_columns(con, "sap_work", derived_sap)

    return {"sap_raw_count": sap_raw, "sf_raw_count": sf_raw}
