"""
Phase A (continued): Standardise both tables — trim, nullify blanks,
normalize phone/email, produce sap_clean and sf_clean.
"""

import logging
import duckdb

logger = logging.getLogger("recon.standardize")

_NULL_SENTINELS = ("''", "'N/A'", "'NONE'", "'NULL'", "'NA'", "'-'")


def _nullify_expression(col: str) -> str:
    casts = " OR ".join(f"UPPER(TRIM(\"{col}\")) = {s}" for s in ("'N/A'", "'NONE'", "'NULL'", "'NA'", "'-'"))
    return f"CASE WHEN TRIM(\"{col}\") = '' OR {casts} THEN NULL ELSE TRIM(\"{col}\") END"


def _build_clean_select(con: duckdb.DuckDBPyConnection, table: str) -> str:
    cols = [
        r[0]
        for r in con.execute(
            f"SELECT column_name FROM information_schema.columns "
            f"WHERE table_name = '{table}' ORDER BY ordinal_position"
        ).fetchall()
    ]
    parts = []
    for col in cols:
        if col == "_rownum":
            parts.append('"_rownum"')
        else:
            parts.append(f'{_nullify_expression(col)} AS "{col}"')
    return ", ".join(parts)


_OPERATOR_SQL = {
    "eq":       lambda f, v: f'UPPER(TRIM("{f}")) = UPPER(\'{v}\')',
    "neq":      lambda f, v: f'UPPER(TRIM("{f}")) <> UPPER(\'{v}\')',
    "in":       lambda f, v: f'UPPER(TRIM("{f}")) IN ({",".join(f"UPPER(\'{x.strip()}\')" for x in v.split(","))})',
    "not_null": lambda f, _: f'"{f}" IS NOT NULL AND TRIM("{f}") <> \'\'',
    "is_true":  lambda f, _: f'UPPER(TRIM("{f}")) IN (\'TRUE\', \'1\', \'YES\')',
    "is_false": lambda f, _: f'UPPER(TRIM("{f}")) IN (\'FALSE\', \'0\', \'NO\')',
}


def _build_filter_clause(filters: list[dict]) -> str:
    active = [f for f in filters if f.get("enabled", True)]
    if not active:
        return ""
    parts = []
    for flt in active:
        field    = flt["field"]
        operator = flt["operator"]
        value    = str(flt.get("value", ""))
        fn = _OPERATOR_SQL.get(operator)
        if fn is None:
            raise ValueError(f"Unknown filter operator '{operator}' for field '{field}'")
        parts.append(fn(field, value))
    return "WHERE " + " AND ".join(parts)


def standardize(con: duckdb.DuckDBPyConnection, cfg: dict) -> None:
    sap_id = cfg["join"]["primary"]["sap_col"]
    sf_id  = cfg["join"]["primary"]["sf_col"]
    sf_fb  = cfg.get("join", {}).get("fallback", {}).get("sf_col", "")

    # Build clean tables (trim + nullify sentinels)
    sap_select = _build_clean_select(con, "sap_work")
    sf_select  = _build_clean_select(con, "sf_work")

    con.execute(f"DROP TABLE IF EXISTS sap_clean; CREATE TABLE sap_clean AS SELECT {sap_select} FROM sap_work;")

    # Apply SF source filters before creating sf_clean
    sf_filters     = cfg.get("filters", {}).get("sf", [])
    active_filters = [f for f in sf_filters if f.get("enabled", True)]

    # Only apply filters whose column actually exists in the source table
    sf_cols_present = {
        r[0] for r in con.execute(
            "SELECT column_name FROM information_schema.columns WHERE table_name = 'sf_work'"
        ).fetchall()
    }
    valid_filters = [f for f in active_filters if f["field"] in sf_cols_present]
    skipped       = [f["field"] for f in active_filters if f["field"] not in sf_cols_present]
    if skipped:
        logger.warning("SF filter skipped — column(s) not found in source: %s", skipped)

    sf_where = _build_filter_clause(valid_filters)
    con.execute(f"DROP TABLE IF EXISTS sf_clean; CREATE TABLE sf_clean AS SELECT {sf_select} FROM sf_work {sf_where};")

    sf_total    = con.execute("SELECT COUNT(*) FROM sf_work").fetchone()[0]
    sf_filtered = con.execute("SELECT COUNT(*) FROM sf_clean").fetchone()[0]
    if valid_filters:
        logger.info(
            "SF filter applied: %d / %d rows retained — rules: %s",
            sf_filtered, sf_total,
            ", ".join(f"{f['field']} {f['operator']}" for f in valid_filters),
        )

    # Cast ID columns to VARCHAR and strip whitespace
    for tbl, id_col in [("sap_clean", sap_id), ("sf_clean", sf_id)]:
        con.execute(f"UPDATE {tbl} SET \"{id_col}\" = TRIM(CAST(\"{id_col}\" AS VARCHAR));")

    if sf_fb:
        con.execute(f"UPDATE sf_clean SET \"{sf_fb}\" = TRIM(CAST(\"{sf_fb}\" AS VARCHAR)) WHERE \"{sf_fb}\" IS NOT NULL;")

    logger.info("Standardization complete: sap_clean and sf_clean ready.")
