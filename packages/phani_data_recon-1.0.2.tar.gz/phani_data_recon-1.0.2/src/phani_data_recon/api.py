"""Programmatic API for running reconciliation from Python code."""

from __future__ import annotations

from pathlib import Path
from typing import Iterable

from . import cli


def run_reconciliation(
    sap: str | None = None,
    sf: str | None = None,
    config: str = "config/rules.yaml",
    output_dir: str | None = None,
    formats: Iterable[str] | None = None,
    dry_run: bool = False,
    no_fuzzy: bool = False,
    verbose: bool = False,
) -> int:
    """Execute reconciliation and return process-style exit code.

    This mirrors CLI behavior, but lets other applications call it directly.
    """
    argv: list[str] = ["--config", config]

    if sap:
        argv.extend(["--sap", str(Path(sap))])
    if sf:
        argv.extend(["--sf", str(Path(sf))])
    if output_dir:
        argv.extend(["--output-dir", str(Path(output_dir))])
    if formats:
        argv.append("--formats")
        argv.extend(list(formats))
    if dry_run:
        argv.append("--dry-run")
    if no_fuzzy:
        argv.append("--no-fuzzy")
    if verbose:
        argv.append("--verbose")

    return cli.main(argv)
