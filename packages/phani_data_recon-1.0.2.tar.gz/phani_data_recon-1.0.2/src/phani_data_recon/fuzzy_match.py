"""
Phase G: Fuzzy matching for unmatched records.
Runs only on SAP-Only and SF-Only sets to find likely-same accounts
that were not linked by ID.
"""

import logging
import re
from typing import Any

import pandas as pd
from rapidfuzz import fuzz

logger = logging.getLogger("recon.fuzzy_match")


def _digits_only(value: Any) -> str:
    if not value or str(value).strip().lower() in ("", "nan", "none"):
        return ""
    return re.sub(r"\D", "", str(value))


def _norm(value: Any) -> str:
    if not value or str(value).strip().lower() in ("", "nan", "none"):
        return ""
    return str(value).strip().upper()


def _score_pair(sap_row: pd.Series, sf_row: pd.Series, field_cfg: list[dict]) -> float:
    total_weight = sum(f["weight"] for f in field_cfg)
    weighted_score = 0.0
    for fc in field_cfg:
        sap_val = _norm(sap_row.get(fc["sap_col"], ""))
        sf_val  = _norm(sf_row.get(fc["sf_col"], ""))
        if not sap_val and not sf_val:
            field_score = 100.0
        elif not sap_val or not sf_val:
            field_score = 0.0
        else:
            field_score = fuzz.token_sort_ratio(sap_val, sf_val)
        weighted_score += field_score * fc["weight"]
    return round(weighted_score / total_weight, 2) if total_weight else 0.0


def run_fuzzy_match(
    sap_only: pd.DataFrame,
    sf_only: pd.DataFrame,
    cfg: dict,
) -> pd.DataFrame:
    fm_cfg = cfg.get("fuzzy_match", {})
    if not fm_cfg.get("enabled", False):
        logger.info("Fuzzy matching disabled in config.")
        return pd.DataFrame()

    min_score  = fm_cfg.get("min_score", 70)
    field_cfg  = fm_cfg.get("fields", [])

    if sap_only.empty or sf_only.empty or not field_cfg:
        logger.info("Fuzzy matching skipped — empty unmatched sets or no fields configured.")
        return pd.DataFrame()

    logger.info(
        "Running fuzzy match: %d SAP-only × %d SF-only records (min_score=%d).",
        len(sap_only), len(sf_only), min_score,
    )

    candidates = []
    sap_records = sap_only.to_dict("records")
    sf_records  = sf_only.to_dict("records")

    for sap_row in sap_records:
        best_score = -1.0
        best_sf    = None
        for sf_row in sf_records:
            score = _score_pair(sap_row, sf_row, field_cfg)
            if score > best_score:
                best_score = score
                best_sf    = sf_row
        if best_score >= min_score and best_sf is not None:
            sap_id_col = cfg["join"]["primary"]["sap_col"]
            sf_id_col  = cfg["join"]["primary"]["sf_col"]
            candidates.append({
                "SAP_ID":             sap_row.get(sap_id_col, ""),
                "SAP_Name":           sap_row.get("name1", ""),
                "SAP_Email":          sap_row.get("smtp_addr", ""),
                "SAP_Phone":          sap_row.get("tel_number", ""),
                "SF_ID":              best_sf.get(sf_id_col, ""),
                "SF_Name":            best_sf.get("Name", ""),
                "SF_Email":           best_sf.get("WC_Email__c", ""),
                "SF_Phone":           best_sf.get("Phone", ""),
                "Confidence_Score":   best_score,
                "Action":             "Manual Review — confirm or reject match",
            })

    df = pd.DataFrame(candidates).sort_values("Confidence_Score", ascending=False) if candidates else \
         pd.DataFrame(columns=["SAP_ID", "SAP_Name", "SAP_Email", "SAP_Phone",
                                "SF_ID",  "SF_Name",  "SF_Email",  "SF_Phone",
                                "Confidence_Score", "Action"])

    logger.info("Fuzzy matching complete — %d candidates above threshold.", len(df))
    return df
