"""
SAP <-> Salesforce Account Data Reconciliation Utility
Entry point: python run_reconciliation.py --sap <path> --sf <path> [options]
"""

import argparse
import sys
from datetime import datetime
from pathlib import Path

import duckdb
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, TimeElapsedColumn

from .fuzzy_match import run_fuzzy_match
from .load_data import ingest, load_config
from .models import ReconciliationResult, RunMetadata
from .reconcile import (
    compare_fields,
    deduplicate,
    exact_join,
    get_duplicates,
    get_matched,
    get_sap_only,
    get_sf_only,
)
from .report import generate_excel, generate_html
from .standardize import standardize
from .utils import make_run_id, report_filename, setup_logging
from .validate import run_dq_checks

console = Console()


def parse_args(argv: list[str] | None = None):
    p = argparse.ArgumentParser(
        description="SAP <-> Salesforce Account Data Reconciliation Utility",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  reconcile-accounts --sap input/sap.csv --sf input/sf.csv
  reconcile-accounts --sap input/sap.csv --sf input/sf.csv --config config/rules.yaml --output-dir output/2026-05-08
  reconcile-accounts --sap input/sap.csv --sf input/sf.csv --dry-run
  reconcile-accounts --sap input/sap.csv --sf input/sf.csv --no-fuzzy --verbose
        """,
    )
    p.add_argument("--sap",        required=False, help="Path to SAP accounts CSV file (optional if config input.sap is set)")
    p.add_argument("--sf",         required=False, help="Path to Salesforce accounts CSV file (optional if config input.sf is set)")
    p.add_argument("--config",     default=None, help="Path to rules YAML config (default: ./config/rules.yaml, then package default)")
    p.add_argument("--output-dir", default=None,   help="Output directory (default: from config)")
    p.add_argument("--formats",    nargs="+",      choices=["excel", "html"], default=None, help="Output formats (default: from config)")
    p.add_argument("--dry-run",    action="store_true", help="Validate config and file headers only — no report written")
    p.add_argument("--no-fuzzy",   action="store_true", help="Skip fuzzy matching step")
    p.add_argument("--verbose",    action="store_true", help="Verbose logging")
    return p.parse_args(argv)


def _path_from_input_cfg(source_cfg: dict) -> str:
    directory = str(source_cfg.get("directory", "")).strip()
    file_name = str(source_cfg.get("file_name", "")).strip()
    if not directory or not file_name:
        return ""
    return str(Path(directory) / file_name)


def resolve_input_paths(args, cfg) -> tuple[str, str]:
    input_cfg = cfg.get("input", {})
    sap_cfg = input_cfg.get("sap", {})
    sf_cfg = input_cfg.get("sf", {})

    sap_path = args.sap or _path_from_input_cfg(sap_cfg)
    sf_path = args.sf or _path_from_input_cfg(sf_cfg)

    if not sap_path or not sf_path:
        console.print("[bold red]ERROR:[/] SAP/SF file paths are missing. Pass --sap/--sf or configure input.sap and input.sf in rules.yaml.")
        sys.exit(2)

    return sap_path, sf_path


def resolve_output_settings(args, cfg) -> tuple[Path, str]:
    out_cfg = cfg.get("output", {})
    report_cfg = out_cfg.get("report", {})

    out_dir = args.output_dir or report_cfg.get("directory") or out_cfg.get("directory", "output")
    file_name = report_cfg.get("file_name") or out_cfg.get("filename_prefix", "reconciliation_report")

    return Path(str(out_dir)), str(file_name)


def validate_inputs(sap_path: str, sf_path: str, cfg: dict):
    for path, label in [(sap_path, "SAP"), (sf_path, "Salesforce")]:
        if not Path(path).exists():
            console.print(f"[bold red]ERROR:[/] {label} file not found: {path}")
            sys.exit(2)
    console.print("[green]✓[/] Input files exist.")

    # Header check via pandas (avoids DuckDB encoding constraint)
    import pandas as _pd
    for path, label in [(sap_path, "SAP"), (sf_path, "SF")]:
        cols = list(_pd.read_csv(path, nrows=0, dtype=str, encoding="utf-8-sig").columns.str.strip())
        console.print(f"[green]✓[/] {label} columns ({len(cols)}): {', '.join(cols[:6])}{'...' if len(cols) > 6 else ''}")

    sap_id   = cfg["join"]["primary"]["sap_col"]
    sf_id    = cfg["join"]["primary"]["sf_col"]
    sap_cols = list(_pd.read_csv(sap_path, nrows=0, dtype=str, encoding="utf-8-sig").columns.str.strip())
    sf_cols  = list(_pd.read_csv(sf_path,  nrows=0, dtype=str, encoding="utf-8-sig").columns.str.strip())
    if sap_id not in sap_cols:
        console.print(f"[bold red]ERROR:[/] SAP join key '{sap_id}' not found in SAP file columns.")
        sys.exit(2)
    if sf_id not in sf_cols:
        console.print(f"[yellow]WARNING:[/] SF primary join key '{sf_id}' not found. Will rely on fallback key.")
    console.print("[green]✓[/] Config and header validation passed.")


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    run_id = make_run_id()

    # Resolve config path preference: CLI arg -> local default -> packaged default
    local_default = Path("config") / "rules.yaml"
    package_default = Path(__file__).parent / "config" / "rules.yaml"
    config_path = args.config or (str(local_default) if local_default.exists() else str(package_default))

    # Load config
    try:
        cfg = load_config(config_path)
    except Exception as e:
        console.print(f"[bold red]CONFIG ERROR:[/] {e}")
        sys.exit(1)

    sap_path, sf_path = resolve_input_paths(args, cfg)

    # Resolve output dir and report filename settings
    out_cfg   = cfg.get("output", {})
    out_dir, prefix = resolve_output_settings(args, cfg)
    formats   = args.formats or out_cfg.get("formats", ["excel", "html"])
    mem_limit = cfg.get("performance", {}).get("duckdb_memory_limit", "2GB")

    # Setup logging
    logger = setup_logging(out_dir, run_id, args.verbose)
    logger.info("Run ID: %s", run_id)
    logger.info("SAP file: %s | SF file: %s | Config: %s", sap_path, sf_path, config_path)

    # Input validation
    console.rule("[bold blue]SAP <-> Salesforce Reconciliation")
    validate_inputs(sap_path, sf_path, cfg)
    if args.dry_run:
        console.print("[bold green]Dry run complete — no report written.[/]")
        sys.exit(0)

    con = duckdb.connect()
    con.execute(f"SET memory_limit = '{mem_limit}'")
    summary: dict = {}

    with Progress(SpinnerColumn(), TextColumn("{task.description}"), TimeElapsedColumn(), console=console) as prog:

        # Phase A: Ingest
        t = prog.add_task("Phase A — Loading and ingesting CSVs...", total=None)
        counts = ingest(con, sap_path, sf_path, cfg)
        summary.update(counts)
        prog.update(t, description=f"Phase A — Loaded SAP: {counts['sap_raw_count']:,} | SF: {counts['sf_raw_count']:,}")
        prog.stop_task(t)

        # Phase A continued: Standardize
        t = prog.add_task("Phase A — Standardizing...", total=None)
        standardize(con, cfg)
        prog.stop_task(t)

        # Phase B: Validate
        t = prog.add_task("Phase B — Running data quality checks...", total=None)
        dq_df = run_dq_checks(con, cfg)
        summary["dq_issue_count"] = int(dq_df["Row Count"].sum()) if not dq_df.empty else 0
        prog.stop_task(t)

        # Phase C: Dedup
        t = prog.add_task("Phase C — Deduplicating...", total=None)
        dedup_counts = deduplicate(con, cfg)
        summary.update(dedup_counts)
        dup_sap, dup_sf = get_duplicates(con, cfg)
        prog.stop_task(t)

        # Phase D: Exact Join
        t = prog.add_task("Phase D — Running exact ID reconciliation...", total=None)
        join_counts = exact_join(con, cfg)
        summary.update(join_counts)
        matched_df  = get_matched(con)
        sap_only_df = get_sap_only(con)
        sf_only_df  = get_sf_only(con)
        prog.stop_task(t)

        # Phase E: Field comparison
        t = prog.add_task("Phase E — Comparing fields...", total=None)
        mismatches_df = compare_fields(con, cfg)
        summary["field_mismatch_count"] = len(mismatches_df)
        if not mismatches_df.empty and "severity" in mismatches_df.columns:
            summary["field_critical_count"] = int((mismatches_df["severity"] == "CRITICAL").sum())
            summary["field_high_count"]     = int((mismatches_df["severity"] == "HIGH").sum())
            summary["field_info_count"]     = int((mismatches_df["severity"] == "INFO").sum())
        else:
            summary["field_critical_count"] = summary["field_high_count"] = summary["field_info_count"] = 0
        prog.stop_task(t)

        # Phase G: Fuzzy match
        fuzzy_df = __import__("pandas").DataFrame()
        if not args.no_fuzzy and cfg.get("fuzzy_match", {}).get("enabled", False):
            t = prog.add_task("Phase G — Running fuzzy matching...", total=None)
            fuzzy_df = run_fuzzy_match(sap_only_df, sf_only_df, cfg)
            summary["fuzzy_candidate_count"] = len(fuzzy_df)
            prog.stop_task(t)
        else:
            summary["fuzzy_candidate_count"] = 0

        # Additional summary metrics
        sf_id  = cfg["join"]["primary"]["sf_col"]
        blank_id_col = sf_id
        if blank_id_col in sf_only_df.columns:
            summary["sf_blank_sap_id_count"] = int(
                sf_only_df[blank_id_col].isna().sum() + (sf_only_df[blank_id_col] == "").sum()
            )
        else:
            summary["sf_blank_sap_id_count"] = 0

        sap_unique = summary.get("sap_unique_count", 1)
        matched    = summary.get("matched_count", 0)
        total      = summary.get("sap_raw_count", 0) + summary.get("sf_raw_count", 0)
        unmatched  = summary.get("sap_only_count", 0) + summary.get("sf_only_count", 0)
        summary["match_rate_pct"]     = round(matched / sap_unique * 100, 2) if sap_unique else 0.0
        summary["exception_rate_pct"] = round(unmatched / total * 100, 2) if total else 0.0

    # Build result
    metadata = RunMetadata(
        run_id=run_id,
        run_timestamp=datetime.now(),
        sap_file=sap_path,
        sf_file=sf_path,
        config_file=config_path,
        config_version=cfg.get("version", "1.0"),
    )
    result = ReconciliationResult(
        summary=summary,
        matched=matched_df,
        sap_only=sap_only_df,
        sf_only=sf_only_df,
        field_mismatches=mismatches_df,
        duplicates_sap=dup_sap,
        duplicates_sf=dup_sf,
        fuzzy_candidates=fuzzy_df,
        data_quality=dq_df,
        metadata=metadata,
    )

    # Print summary
    console.rule("[bold blue]Reconciliation Summary")
    console.print(result.log_summary())

    # Phase H: Reports
    out_dir.mkdir(parents=True, exist_ok=True)
    console.rule("[bold blue]Generating Reports")

    if "excel" in formats:
        xlsx_path = report_filename(out_dir, prefix, run_id, "xlsx")
        with console.status("Writing Excel report..."):
            generate_excel(result, cfg, xlsx_path)
        console.print(f"[green]✓[/] Excel: {xlsx_path}")

    if "html" in formats:
        html_path = report_filename(out_dir, prefix, run_id, "html")
        tpl_dir   = Path(__file__).parent / "templates"
        with console.status("Writing HTML report..."):
            generate_html(result, cfg, html_path, tpl_dir)
        console.print(f"[green]✓[/] HTML:  {html_path}")

    con.close()
    console.rule("[bold green]Done")
    logger.info("Reconciliation complete. Run ID: %s", run_id)
    return 0


if __name__ == "__main__":
    sys.exit(main())
