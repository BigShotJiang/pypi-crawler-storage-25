"""
Phase H: Generate Excel (10-tab) and HTML dashboard reports.
Uses openpyxl write-only streaming for large sheets.
"""

import logging
from datetime import datetime
from pathlib import Path
from typing import Any

import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import PatternFill, Font, Alignment
from openpyxl.utils import get_column_letter
from openpyxl.utils.dataframe import dataframe_to_rows
from jinja2 import Environment, FileSystemLoader

from .models import ReconciliationResult

logger = logging.getLogger("recon.report")

# ── Palette ───────────────────────────────────────────────────────────────────
C = {
    "header":   "1F4E79",
    "sub":      "2E75B6",
    "matched":  "C6EFCE",
    "matched2": "E2EFDA",
    "sap_only": "FFEB9C",
    "sap_only2":"FFF7CD",
    "sf_only":  "FCE4D6",
    "sf_only2": "FDE9D9",
    "crit":     "FFD7D7",
    "high":     "FFE0B2",
    "info":     "FFF9C4",
    "dup":      "E8D5F5",
    "dup2":     "F3E9FC",
    "fuzzy":    "FFE0CC",
    "dq_crit":  "FF9999",
    "dq_high":  "FFD580",
    "dq_info":  "FFFFCC",
    "p1":       "FF4444",
    "p2":       "FF8800",
    "p3":       "FFCC00",
    "p4":       "92D050",
    "white":    "FFFFFF",
    "grey":     "F2F2F2",
}

SEVERITY_FILL = {"CRITICAL": C["crit"], "HIGH": C["high"], "INFO": C["info"]}
DQ_FILL       = {"CRITICAL": C["dq_crit"], "HIGH": C["dq_high"], "INFO": C["dq_info"]}
PRIORITY_FILL = {"P1 — Urgent": C["p1"], "P2 — High": C["p2"], "P3 — Medium": C["p3"], "P4 — Low": C["p4"]}


# ── Helpers ───────────────────────────────────────────────────────────────────

def _hdr(ws, row: int, ncols: int, text: str, fill: str, size: int = 12):
    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=ncols)
    c = ws.cell(row=row, column=1, value=text)
    c.fill = PatternFill("solid", fgColor=fill)
    c.font = Font(bold=True, color="FFFFFF", size=size)
    c.alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[row].height = 24


def _col_hdr(ws, row: int, cols: list, fill: str):
    for i, v in enumerate(cols, 1):
        c = ws.cell(row=row, column=i, value=v)
        c.fill = PatternFill("solid", fgColor=fill)
        c.font = Font(bold=True, color="FFFFFF")
        c.alignment = Alignment(horizontal="center", wrap_text=True)
    ws.row_dimensions[row].height = 20


def _write_df(ws, df: pd.DataFrame, start_row: int, fill_a: str, fill_b: str, max_rows: int = 500_000):
    df = df.fillna("").astype(str)
    for r_idx, row in enumerate(df.itertuples(index=False), start_row):
        if r_idx - start_row >= max_rows:
            ws.append(["[Truncated — see CSV export for full data]"])
            break
        fill = fill_a if r_idx % 2 == 0 else fill_b
        for c_idx, val in enumerate(row, 1):
            cell = ws.cell(row=r_idx, column=c_idx, value=val)
            cell.fill = PatternFill("solid", fgColor=fill)


def _auto_width(ws, min_w: int = 10, max_w: int = 50):
    for col in ws.columns:
        lens = [len(str(c.value)) if c.value else 0 for c in col]
        ws.column_dimensions[get_column_letter(col[0].column)].width = min(max_w, max(min_w, max(lens) + 2))


def _sort_for_render(df: pd.DataFrame, keys: list[str]) -> pd.DataFrame:
    if df.empty:
        return df
    present = [k for k in keys if k in df.columns]
    if not present:
        return df
    return df.sort_values(by=present, ascending=True, na_position="last", kind="mergesort")


def _get_report_sort_keys(cfg: dict) -> tuple[list[str], list[str]]:
    sap_id = cfg.get("join", {}).get("primary", {}).get("sap_col", "")
    sf_id = cfg.get("join", {}).get("primary", {}).get("sf_col", "")

    default_sap = ["vkorg", sap_id]
    default_sf = ["BillingCountryCode", sf_id]

    sort_cfg = cfg.get("report_sort", {})
    sap_cfg = sort_cfg.get("sap", default_sap)
    sf_cfg = sort_cfg.get("sf", default_sf)

    sap_keys = [k for k in sap_cfg if isinstance(k, str) and k.strip()]
    sf_keys = [k for k in sf_cfg if isinstance(k, str) and k.strip()]

    return (sap_keys or default_sap), (sf_keys or default_sf)


# ── Sheets ────────────────────────────────────────────────────────────────────

def _sheet_summary(wb: Workbook, result: ReconciliationResult):
    ws = wb.create_sheet("Summary", 0)
    s  = result.summary
    m  = result.metadata
    _hdr(ws, 1, 4, "SAP ↔ Salesforce Account Reconciliation Report", C["header"], 14)
    ws.cell(row=2, column=1, value=f"Run ID: {m.run_id}   │   {m.run_timestamp.strftime('%Y-%m-%d %H:%M:%S')}   │   Config v{m.config_version}")
    ws.cell(row=2, column=1).font = Font(italic=True, size=10)

    blocks = [
        ("RECORD COUNTS", [
            ("SAP raw records",   s.get("sap_raw_count", 0)),
            ("SAP unique records",s.get("sap_unique_count", 0)),
            ("SAP duplicates",    s.get("sap_dup_count", 0)),
            ("SF  raw records",   s.get("sf_raw_count", 0)),
            ("SF  unique records",s.get("sf_unique_count", 0)),
            ("SF  duplicates",    s.get("sf_dup_count", 0)),
        ]),
        ("MATCH ANALYSIS", [
            ("Matched (both systems)", s.get("matched_count", 0)),
            ("SAP Only",               s.get("sap_only_count", 0)),
            ("SF Only",                s.get("sf_only_count", 0)),
            ("Match Rate",             f"{s.get('match_rate_pct', 0):.2f}%"),
            ("Exception Rate",         f"{s.get('exception_rate_pct', 0):.2f}%"),
        ]),
        ("DATA QUALITY", [
            ("Field Mismatches",      s.get("field_mismatch_count", 0)),
            ("  — CRITICAL",          s.get("field_critical_count", 0)),
            ("  — HIGH",              s.get("field_high_count", 0)),
            ("  — INFO",              s.get("field_info_count", 0)),
            ("Fuzzy Match Candidates",s.get("fuzzy_candidate_count", 0)),
            ("DQ Issues",             s.get("dq_issue_count", 0)),
        ]),
    ]

    row = 4
    for block_title, items in blocks:
        c = ws.cell(row=row, column=1, value=block_title)
        c.fill = PatternFill("solid", fgColor=C["sub"])
        c.font = Font(bold=True, color="FFFFFF")
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=2)
        row += 1
        for label, value in items:
            ws.cell(row=row, column=1, value=label).font = Font(size=11)
            ws.cell(row=row, column=2, value=value).font = Font(bold=True, size=11)
            row += 1
        row += 1

    ws.column_dimensions["A"].width = 35
    ws.column_dimensions["B"].width = 20


def _sheet_matched(wb: Workbook, result: ReconciliationResult, cfg: dict):
    ws   = wb.create_sheet("Exact_Matches")
    sap_id = cfg["join"]["primary"]["sap_col"]
    sf_id  = cfg["join"]["primary"]["sf_col"]
    sap_sort_keys, sf_sort_keys = _get_report_sort_keys(cfg)
    df = _sort_for_render(result.matched, sap_sort_keys + sf_sort_keys)
    _hdr(ws, 1, 8, f"Exact Matches — {len(df):,} records", C["sub"])

    display_cols = ["_join_id", sap_id, "name1", "Name", "tel_number", "Phone", "smtp_addr", "WC_Email__c"]
    display_cols = [c for c in display_cols if c in df.columns]
    col_labels   = [c.replace("_join_id", "Join ID") for c in display_cols]
    _col_hdr(ws, 2, col_labels, C["sub"])
    _write_df(ws, df[display_cols], 3, C["matched"], C["matched2"])
    _auto_width(ws)


def _sheet_field_mismatches(wb: Workbook, result: ReconciliationResult):
    ws  = wb.create_sheet("Field_Mismatches")
    df  = result.field_mismatches
    _hdr(ws, 1, 6, f"Field Mismatches — {len(df):,} records", C["sub"])
    cols = ["_join_id", "sap_id", "field_label", "sap_value", "sf_value", "severity"]
    cols = [c for c in cols if c in df.columns]
    _col_hdr(ws, 2, [c.replace("_", " ").title() for c in cols], C["sub"])

    df_out = df[cols].fillna("").astype(str)
    for r_idx, row in enumerate(df_out.itertuples(index=False), 3):
        sev   = row[-1] if cols[-1] == "severity" else "INFO"
        fill  = SEVERITY_FILL.get(sev, C["info"])
        for c_idx, val in enumerate(row, 1):
            cell = ws.cell(row=r_idx, column=c_idx, value=val)
            cell.fill = PatternFill("solid", fgColor=fill)
    _auto_width(ws)


def _sheet_sap_only(wb: Workbook, result: ReconciliationResult, cfg: dict):
    ws  = wb.create_sheet("SAP_Only")
    sap_id = cfg["join"]["primary"]["sap_col"]
    sap_sort_keys, _ = _get_report_sort_keys(cfg)
    df = _sort_for_render(result.sap_only, sap_sort_keys)
    _hdr(ws, 1, 7, f"SAP Only (Missing in Salesforce) — {len(df):,} records", "C55A11")
    base_cols = [sap_id, "name1", "Name_and_address", "vkorg", "tel_number", "smtp_addr"]
    display   = [c for c in base_cols if c in df.columns]
    display.append("Action_Required")
    df = df.copy()
    df["Action_Required"] = "CREATE in Salesforce OR document intentional exclusion"
    _col_hdr(ws, 2, [c.replace("_", " ").title() for c in display], "C55A11")
    _write_df(ws, df[display], 3, C["sap_only"], C["sap_only2"])
    _auto_width(ws)


def _sheet_sf_only(wb: Workbook, result: ReconciliationResult, cfg: dict):
    ws  = wb.create_sheet("SF_Only")
    sf_id = cfg["join"]["primary"]["sf_col"]
    _, sf_sort_keys = _get_report_sort_keys(cfg)
    df = _sort_for_render(result.sf_only, sf_sort_keys)
    _hdr(ws, 1, 7, f"Salesforce Only (Missing in SAP) — {len(df):,} records", "843C0C")
    base_cols = [sf_id, "Id", "Name", "BillingCity", "BillingCountryCode", "BP_Account_Hold_Status__c"]
    display   = [c for c in base_cols if c in df.columns]
    display.append("Action_Required")
    df = df.copy()
    df["Action_Required"] = "VALIDATE: prospect vs. active customer; create in SAP if active"
    _col_hdr(ws, 2, [c.replace("_", " ").title() for c in display], "843C0C")
    _write_df(ws, df[display], 3, C["sf_only"], C["sf_only2"])
    _auto_width(ws)


def _sheet_duplicates(
    wb: Workbook,
    dup_df: pd.DataFrame,
    sheet_name: str,
    id_col: str,
    title_prefix: str,
    sort_keys: list[str] | None = None,
):
    ws  = wb.create_sheet(sheet_name)
    sorted_df = _sort_for_render(dup_df, sort_keys or [])
    _hdr(ws, 1, 6, f"{title_prefix} Duplicates — {len(sorted_df):,} rows", "7030A0")
    display = [c for c in sorted_df.columns if not c.startswith("_")][:8]
    _col_hdr(ws, 2, [c.replace("_", " ").title() for c in display], "7030A0")
    _write_df(ws, sorted_df[display], 3, C["dup"], C["dup2"])
    _auto_width(ws)


def _sheet_fuzzy(wb: Workbook, result: ReconciliationResult):
    ws  = wb.create_sheet("Fuzzy_Match_Candidates")
    df  = result.fuzzy_candidates
    _hdr(ws, 1, 10, f"Fuzzy Match Candidates — {len(df):,} records (manual review required)", "E65C00")
    if not df.empty:
        _col_hdr(ws, 2, [c.replace("_", " ").title() for c in df.columns], "E65C00")
        for r_idx, row in enumerate(df.fillna("").astype(str).itertuples(index=False), 3):
            try:
                score = float(row[df.columns.get_loc("Confidence_Score")])
            except Exception:
                score = 0.0
            fill = C["fuzzy"] if score >= 85 else C["sap_only"]
            for c_idx, val in enumerate(row, 1):
                ws.cell(row=r_idx, column=c_idx, value=val).fill = PatternFill("solid", fgColor=fill)
    _auto_width(ws)


def _sheet_dq(wb: Workbook, result: ReconciliationResult):
    ws  = wb.create_sheet("Data_Quality_Issues")
    df  = result.data_quality
    _hdr(ws, 1, 5, f"Data Quality Issues — {len(df):,} checks flagged", C["sub"])
    if not df.empty:
        _col_hdr(ws, 2, list(df.columns), C["sub"])
        for r_idx, row in enumerate(df.fillna("").astype(str).itertuples(index=False), 3):
            sev  = row[df.columns.get_loc("Severity")] if "Severity" in df.columns else "INFO"
            fill = DQ_FILL.get(sev, C["dq_info"])
            for c_idx, val in enumerate(row, 1):
                ws.cell(row=r_idx, column=c_idx, value=val).fill = PatternFill("solid", fgColor=fill)
    _auto_width(ws)


def _sheet_action_plan(wb: Workbook, result: ReconciliationResult):
    ws   = wb.create_sheet("Action_Plan")
    s    = result.summary
    _hdr(ws, 1, 5, "Reconciliation — Plan of Action", C["header"])
    _col_hdr(ws, 2, ["Priority", "Category", "Count", "Recommended Action", "Owner"], C["sub"])

    actions = [
        ("P1 — Urgent", "SAP Duplicate Records",
         s.get("sap_dup_count", 0),
         "Dedup SAP: apply keep_first rule; notify SAP data team; fix at source",
         "SAP Data Steward"),
        ("P1 — Urgent", "CRITICAL Field Mismatches",
         s.get("field_critical_count", 0),
         "Determine system of record per field; sync authoritative value; log the change",
         "Data Governance"),
        ("P2 — High", "SAP Only (missing in Salesforce)",
         s.get("sap_only_count", 0),
         "For each record: (a) create Account in SF, or (b) document intentional exclusion",
         "Salesforce Admin"),
        ("P2 — High", "SF Only (missing in SAP)",
         s.get("sf_only_count", 0),
         "Validate: prospect vs. active customer. If active, create in SAP",
         "SAP Data Team"),
        ("P3 — Medium", "HIGH Field Mismatches (City, Postal)",
         s.get("field_high_count", 0),
         "Review address formatting; align normalisation rules between systems",
         "Data Steward"),
        ("P3 — Medium", "Fuzzy Match Candidates",
         s.get("fuzzy_candidate_count", 0),
         "Human review: confirm or reject each candidate; update linking field if confirmed",
         "Data Analyst"),
        ("P3 — Medium", "SF records with blank BP_PowerCerv_Account_Id__c",
         s.get("sf_blank_sap_id_count", 0),
         "Enrich from WC_SAP_Identification__c or manual mapping; assign SAP ID",
         "Integration Team"),
        ("P4 — Low", "INFO Field Mismatches (Country, Sales Org)",
         s.get("field_info_count", 0),
         "Review and align; low business impact — schedule for next data cleanse cycle",
         "Data Analyst"),
        ("P4 — Low", "Data Quality Issues (nulls, bad formats)",
         s.get("dq_issue_count", 0),
         "Clean at source; add validation rules to upstream feeds",
         "Data Engineering"),
    ]

    for r, (pri, cat, cnt, action, owner) in enumerate(actions, 3):
        row_data = [pri, cat, cnt, action, owner]
        pfill    = PRIORITY_FILL.get(pri, C["grey"])
        for c, val in enumerate(row_data, 1):
            cell = ws.cell(row=r, column=c, value=val)
            if c == 1:
                cell.fill = PatternFill("solid", fgColor=pfill)
                cell.font = Font(bold=True, color="FFFFFF")
            else:
                cell.fill = PatternFill("solid", fgColor=C["grey"] if r % 2 == 0 else C["white"])
            cell.alignment = Alignment(wrap_text=True)
        ws.row_dimensions[r].height = 45

    ws.column_dimensions["A"].width = 15
    ws.column_dimensions["B"].width = 38
    ws.column_dimensions["C"].width = 10
    ws.column_dimensions["D"].width = 68
    ws.column_dimensions["E"].width = 22


# ── Excel entry point ─────────────────────────────────────────────────────────

def generate_excel(result: ReconciliationResult, cfg: dict, output_path: Path) -> None:
    wb = Workbook()
    wb.remove(wb.active)

    sap_id = cfg["join"]["primary"]["sap_col"]
    sf_id = cfg["join"]["primary"]["sf_col"]
    sap_sort_keys, sf_sort_keys = _get_report_sort_keys(cfg)

    _sheet_summary(wb, result)
    _sheet_matched(wb, result, cfg)
    _sheet_field_mismatches(wb, result)
    _sheet_sap_only(wb, result, cfg)
    _sheet_sf_only(wb, result, cfg)
    _sheet_duplicates(wb, result.duplicates_sap, "SAP_Duplicates", sap_id, "SAP", sap_sort_keys)
    _sheet_duplicates(wb, result.duplicates_sf,  "SF_Duplicates",  sf_id,  "SF", sf_sort_keys)
    _sheet_fuzzy(wb, result)
    _sheet_dq(wb, result)
    _sheet_action_plan(wb, result)

    # Apply freeze panes and autofilter if configured
    excel_cfg = cfg.get("output", {}).get("excel", {})
    for ws in wb.worksheets:
        if excel_cfg.get("freeze_panes"):
            ws.freeze_panes = "A3"
        if excel_cfg.get("auto_filter") and ws.max_row >= 2:
            ws.auto_filter.ref = ws.dimensions

    wb.save(output_path)
    logger.info("Excel report saved: %s", output_path)


# ── HTML entry point ──────────────────────────────────────────────────────────

def generate_html(result: ReconciliationResult, cfg: dict, output_path: Path, template_dir: Path) -> None:
    env = Environment(loader=FileSystemLoader(str(template_dir)), autoescape=True)
    tpl = env.get_template("report.html.j2")

    def df_to_records(df: pd.DataFrame, max_rows: int = 5000, columns: list[str] | None = None) -> list:
        if df.empty:
            return []
        cols = columns or [c for c in df.columns if not c.startswith("_")]
        display = df[cols]
        return display.head(max_rows).fillna("").astype(str).to_dict("records")

    def df_columns(df: pd.DataFrame) -> list:
        return [c for c in df.columns if not c.startswith("_")]

    # Keep SF Only tab minimal: SF primary key + Name + up to two useful SF fields.
    sap_primary_col = cfg.get("join", {}).get("primary", {}).get("sap_col", "")
    sf_primary_col = cfg.get("join", {}).get("primary", {}).get("sf_col", "")
    sap_sort_keys, sf_sort_keys = _get_report_sort_keys(cfg)

    matched_sorted = _sort_for_render(result.matched, sap_sort_keys + sf_sort_keys)
    sap_only_sorted = _sort_for_render(result.sap_only, sap_sort_keys)
    sf_only_sorted = _sort_for_render(result.sf_only, sf_sort_keys)
    dup_sap_sorted = _sort_for_render(result.duplicates_sap, sap_sort_keys)
    dup_sf_sorted = _sort_for_render(result.duplicates_sf, sf_sort_keys)

    sf_only_cols_all = df_columns(sf_only_sorted)
    base_cols = [c for c in [sf_primary_col, "Name"] if c and c in sf_only_cols_all]
    extra_candidates = ["Phone", "WC_Email__c", "BillingCity", "BillingCountryCode", "Id"]
    extra_cols = [c for c in extra_candidates if c in sf_only_cols_all and c not in base_cols][:2]
    sf_only_cols = base_cols + extra_cols

    # Fallback for unexpected schemas: keep first 3 visible columns.
    if not sf_only_cols:
        sf_only_cols = sf_only_cols_all[:3]

    html = tpl.render(
        metadata=result.metadata,
        summary=result.summary,
        matched_cols=df_columns(matched_sorted),
        matched_rows=df_to_records(matched_sorted),
        mismatch_cols=df_columns(result.field_mismatches),
        mismatch_rows=df_to_records(result.field_mismatches),
        sap_only_cols=df_columns(sap_only_sorted),
        sap_only_rows=df_to_records(sap_only_sorted),
        sf_only_cols=sf_only_cols,
        sf_only_rows=df_to_records(sf_only_sorted, columns=sf_only_cols),
        dup_sap_cols=df_columns(dup_sap_sorted),
        dup_sap_rows=df_to_records(dup_sap_sorted),
        dup_sf_cols=df_columns(dup_sf_sorted),
        dup_sf_rows=df_to_records(dup_sf_sorted),
        fuzzy_cols=df_columns(result.fuzzy_candidates),
        fuzzy_rows=df_to_records(result.fuzzy_candidates),
        dq_cols=df_columns(result.data_quality),
        dq_rows=df_to_records(result.data_quality),
        generated_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    )

    output_path.write_text(html, encoding="utf-8")
    logger.info("HTML report saved: %s", output_path)
