import logging
import re
import uuid
from datetime import datetime
from pathlib import Path


def make_run_id() -> str:
    return datetime.now().strftime("%Y%m%dT%H%M%S") + "-" + str(uuid.uuid4())[:8]


def setup_logging(output_dir: Path, run_id: str, verbose: bool = False) -> logging.Logger:
    log_dir = output_dir / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / f"run_{run_id}.log"

    level = logging.DEBUG if verbose else logging.INFO
    fmt = "%(asctime)s [%(levelname)s] %(name)s — %(message)s"

    logging.basicConfig(
        level=level,
        format=fmt,
        handlers=[
            logging.FileHandler(log_file, encoding="utf-8"),
            logging.StreamHandler(),
        ],
    )
    return logging.getLogger("recon")


def normalize_phone(value: str) -> str:
    if not value or str(value).strip().lower() in ("", "nan", "none", "null"):
        return ""
    return re.sub(r"\D", "", str(value))


def normalize_email(value: str) -> str:
    if not value or str(value).strip().lower() in ("", "nan", "none", "null"):
        return ""
    return str(value).strip().lower()


def normalize_str(value: str, mode: str = "") -> str:
    if not value or str(value).strip().lower() in ("", "nan", "none", "null"):
        return ""
    v = str(value).strip()
    if mode == "uppercase":
        return v.upper()
    if mode == "lowercase":
        return v.lower()
    return v


def safe_output_dir(directory: str, prefix: str, run_id: str) -> Path:
    p = Path(directory)
    p.mkdir(parents=True, exist_ok=True)
    return p


def report_filename(output_dir: Path, prefix: str, run_id: str, ext: str) -> Path:
    ts = datetime.now().strftime("%Y%m%dT%H%M")
    return output_dir / f"{prefix}_{ts}_{run_id}.{ext}"
