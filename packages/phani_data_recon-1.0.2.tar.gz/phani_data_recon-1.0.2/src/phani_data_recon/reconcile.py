"""
Phases C–E: Deduplication, exact-ID join, field-level comparison.
Returns summary counts + result DataFrames.
"""

import logging
from typing import Any

import duckdb
import pandas as pd
from rapidfuzz.distance import JaroWinkler

logger = logging.getLogger("recon.reconcile")


# ── Deduplication ─────────────────────────────────────────────────────────────

def _dedup(con: duckdb.DuckDBPyConnection, src: str, dest: str, id_col: str, strategy: str) -> tuple[int, int]:
    raw_count  = con.execute(f"SELECT COUNT(*) FROM {src}").fetchone()[0]
    norm_id = f"NULLIF(TRIM(CAST(\"{id_col}\" AS VARCHAR)), '')"
    partition_key = f"COALESCE({norm_id}, CONCAT('__ROW__', CAST(_rownum AS VARCHAR)))"

    if strategy == "flag_all":
        con.execute(
            f"DROP TABLE IF EXISTS {dest}; "
            f"CREATE TABLE {dest} AS "
            f"SELECT *, "
            f"CASE WHEN {norm_id} IS NULL THEN FALSE "
            f"ELSE COUNT(*) OVER (PARTITION BY {norm_id}) > 1 END AS _is_duplicate "
            f"FROM {src};"
        )
        dedup_count = raw_count
    else:
        order = "ASC" if strategy == "keep_first" else "DESC"
        # Get column list excluding _rn which only exists in the subquery
        cols = [
            f'"{r[0]}"'
            for r in con.execute(
                f"SELECT column_name FROM information_schema.columns "
                f"WHERE table_name='{src}' ORDER BY ordinal_position"
            ).fetchall()
        ]
        col_list = ", ".join(cols)
        con.execute(
            f"DROP TABLE IF EXISTS {dest}; "
            f"CREATE TABLE {dest} AS "
            f"SELECT {col_list} FROM ("
            f"  SELECT *, ROW_NUMBER() OVER (PARTITION BY {partition_key} ORDER BY _rownum {order}) AS _rn "
            f"  FROM {src}"
            f") t WHERE t._rn = 1;"
        )
        dedup_count = con.execute(f"SELECT COUNT(*) FROM {dest}").fetchone()[0]

    # Count surplus rows beyond first occurrence for non-blank IDs only.
    dup_count = con.execute(
        f"SELECT COALESCE(SUM(c - 1), 0) FROM ("
        f"  SELECT COUNT(*) AS c FROM {src} "
        f"  WHERE {norm_id} IS NOT NULL "
        f"  GROUP BY {norm_id} "
        f"  HAVING COUNT(*) > 1"
        f")"
    ).fetchone()[0]

    logger.info("%s: %d raw → %d unique (%d duplicates removed/flagged)", dest, raw_count, dedup_count, dup_count)
    return dedup_count, dup_count


def deduplicate(con: duckdb.DuckDBPyConnection, cfg: dict) -> dict:
    sap_id = cfg["join"]["primary"]["sap_col"]
    sf_id  = cfg["join"]["primary"]["sf_col"]
    sap_strategy = cfg["dedup"]["sap_strategy"]
    sf_strategy  = cfg["dedup"]["sf_strategy"]

    sap_dedup, sap_dups = _dedup(con, "sap_clean", "sap_dedup", sap_id, sap_strategy)
    sf_dedup,  sf_dups  = _dedup(con, "sf_clean",  "sf_dedup",  sf_id,  sf_strategy)

    return {
        "sap_unique_count": sap_dedup,
        "sap_dup_count":    sap_dups,
        "sf_unique_count":  sf_dedup,
        "sf_dup_count":     sf_dups,
    }


def get_duplicates(con: duckdb.DuckDBPyConnection, cfg: dict) -> tuple[pd.DataFrame, pd.DataFrame]:
    sap_id = cfg["join"]["primary"]["sap_col"]
    sf_id  = cfg["join"]["primary"]["sf_col"]

    dup_sap = con.execute(
        f"SELECT * FROM sap_clean WHERE \"{sap_id}\" IN ("
        f"  SELECT \"{sap_id}\" FROM sap_clean WHERE \"{sap_id}\" IS NOT NULL "
        f"  GROUP BY \"{sap_id}\" HAVING COUNT(*) > 1"
        f") ORDER BY \"{sap_id}\", _rownum"
    ).df()

    dup_sf = con.execute(
        f"SELECT * FROM sf_clean WHERE \"{sf_id}\" IS NOT NULL AND TRIM(\"{sf_id}\") <> '' "
        f"AND \"{sf_id}\" IN ("
        f"  SELECT \"{sf_id}\" FROM sf_clean WHERE \"{sf_id}\" IS NOT NULL "
        f"  GROUP BY \"{sf_id}\" HAVING COUNT(*) > 1"
        f") ORDER BY \"{sf_id}\", _rownum"
    ).df()

    return dup_sap, dup_sf


# ── Exact Join ────────────────────────────────────────────────────────────────

def exact_join(con: duckdb.DuckDBPyConnection, cfg: dict) -> dict:
    sap_id  = cfg["join"]["primary"]["sap_col"]
    sf_id   = cfg["join"]["primary"]["sf_col"]
    fb_cfg = cfg.get("join", {}).get("fallback", {})
    sf_fb = fb_cfg.get("sf_col", "") if fb_cfg.get("enabled", False) else ""

    fallback_clause = ""
    if sf_fb:
        fallback_clause = f'OR sap."{sap_id}" = sf."{sf_fb}"'

    con.execute(
        f"""
        DROP TABLE IF EXISTS reconciliation;
        CREATE TABLE reconciliation AS
        SELECT
            COALESCE(sap."{sap_id}", sf."{sf_id}") AS _join_id,
            CASE
                WHEN sap._rownum IS NOT NULL AND sf._rownum IS NOT NULL THEN 'MATCHED'
                WHEN sap._rownum IS NOT NULL THEN 'SAP_ONLY'
                ELSE 'SF_ONLY'
            END AS _match_status,
            sap.*,
            sf.*
        FROM sap_dedup sap
        FULL OUTER JOIN sf_dedup sf
            ON sap."{sap_id}" = sf."{sf_id}"
            {fallback_clause};
        """
    )

    matched    = con.execute("SELECT COUNT(*) FROM reconciliation WHERE _match_status = 'MATCHED'").fetchone()[0]
    sap_only   = con.execute("SELECT COUNT(*) FROM reconciliation WHERE _match_status = 'SAP_ONLY'").fetchone()[0]
    sf_only    = con.execute("SELECT COUNT(*) FROM reconciliation WHERE _match_status = 'SF_ONLY'").fetchone()[0]

    logger.info("Join complete — Matched: %d | SAP-Only: %d | SF-Only: %d", matched, sap_only, sf_only)
    return {"matched_count": matched, "sap_only_count": sap_only, "sf_only_count": sf_only}


def get_sap_only(con: duckdb.DuckDBPyConnection) -> pd.DataFrame:
    return con.execute("SELECT * FROM reconciliation WHERE _match_status = 'SAP_ONLY'").df()


def get_sf_only(con: duckdb.DuckDBPyConnection) -> pd.DataFrame:
    return con.execute("SELECT * FROM reconciliation WHERE _match_status = 'SF_ONLY'").df()


def get_matched(con: duckdb.DuckDBPyConnection) -> pd.DataFrame:
    return con.execute("SELECT * FROM reconciliation WHERE _match_status = 'MATCHED'").df()


# ── Field Comparison ──────────────────────────────────────────────────────────

def _jaro_winkler_udf(a: str, b: str) -> float:
    if not a or not b:
        return 0.0
    return JaroWinkler.normalized_similarity(str(a), str(b))


def compare_fields(con: duckdb.DuckDBPyConnection, cfg: dict) -> pd.DataFrame:
    sap_id   = cfg["join"]["primary"]["sap_col"]
    mappings = cfg.get("field_mappings", [])

    con.create_function("jaro_winkler", _jaro_winkler_udf, [str, str], float)

    rows: list[dict] = []

    for fm in mappings:
        if not fm.get("enabled", True):
            logger.debug("Field '%s' skipped (enabled: false)", fm.get("label", ""))
            continue
        label     = fm["label"]
        sap_col   = fm["sap_col"]
        sf_col    = fm["sf_col"]
        severity  = fm["severity"]
        compare   = fm["compare"]
        norm      = fm.get("normalize", "")
        tolerance = fm.get("tolerance", 0.85)

        try:
            if compare == "exact":
                if norm == "uppercase":
                    expr = f'UPPER(TRIM(COALESCE(rec."{sap_col}", \'\'))) <> UPPER(TRIM(COALESCE(rec."{sf_col}", \'\')))' 
                elif norm == "lowercase":
                    expr = f'LOWER(TRIM(COALESCE(rec."{sap_col}", \'\'))) <> LOWER(TRIM(COALESCE(rec."{sf_col}", \'\')))' 
                else:
                    expr = f'TRIM(COALESCE(rec."{sap_col}", \'\')) <> TRIM(COALESCE(rec."{sf_col}", \'\'))'

                results = con.execute(
                    f"""
                    SELECT
                        rec."_join_id",
                        rec."{sap_id}" AS sap_id,
                        '{label}' AS field_label,
                        rec."{sap_col}" AS sap_value,
                        rec."{sf_col}"  AS sf_value,
                        '{severity}' AS severity,
                        'MISMATCH' AS result
                    FROM reconciliation rec
                    WHERE rec._match_status = 'MATCHED'
                      AND {expr}
                    """
                ).df()

            elif compare == "numeric":
                results = con.execute(
                    f"""
                    SELECT
                        rec."_join_id",
                        rec."{sap_id}" AS sap_id,
                        '{label}' AS field_label,
                        rec."{sap_col}" AS sap_value,
                        rec."{sf_col}"  AS sf_value,
                        '{severity}' AS severity,
                        'MISMATCH' AS result
                    FROM reconciliation rec
                    WHERE rec._match_status = 'MATCHED'
                      AND regexp_replace(COALESCE(rec."{sap_col}", ''), '[^0-9]', '', 'g')
                       <> regexp_replace(COALESCE(rec."{sf_col}", ''),  '[^0-9]', '', 'g')
                    """
                ).df()

            elif compare == "fuzzy":
                results = con.execute(
                    f"""
                    SELECT
                        rec."_join_id",
                        rec."{sap_id}" AS sap_id,
                        '{label}' AS field_label,
                        rec."{sap_col}" AS sap_value,
                        rec."{sf_col}"  AS sf_value,
                        '{severity}' AS severity,
                        'MISMATCH' AS result
                    FROM reconciliation rec
                    WHERE rec._match_status = 'MATCHED'
                      AND jaro_winkler(
                            UPPER(TRIM(COALESCE(rec."{sap_col}", ''))),
                            UPPER(TRIM(COALESCE(rec."{sf_col}", '')))
                          ) < {tolerance}
                    """
                ).df()

            else:
                results = pd.DataFrame()

            rows.append(results)
            logger.debug("Field '%s': %d mismatches", label, len(results))

        except Exception as e:
            logger.warning("Field comparison skipped for '%s': %s", label, e)

    non_empty = [r for r in rows if not r.empty]
    if non_empty:
        df = pd.concat(non_empty, ignore_index=True)
    else:
        df = pd.DataFrame(columns=["_join_id", "sap_id", "field_label", "sap_value", "sf_value", "severity", "result"])

    logger.info("Field comparison complete — %d total mismatches.", len(df))
    return df
