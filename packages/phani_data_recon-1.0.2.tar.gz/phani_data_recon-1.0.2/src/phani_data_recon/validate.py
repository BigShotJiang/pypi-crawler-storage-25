"""
Phase B: Data quality checks — null IDs, duplicates, format issues.
Returns a DataFrame of findings for the Data_Quality_Issues report tab.
Uses plain DuckDB SQL (no Great Expectations server needed).
Great Expectations integration available via run_ge_suite() if GE is installed.
"""

import logging
import duckdb
import pandas as pd

logger = logging.getLogger("recon.validate")


def run_dq_checks(con: duckdb.DuckDBPyConnection, cfg: dict) -> pd.DataFrame:
    sap_id = cfg["join"]["primary"]["sap_col"]
    sf_id  = cfg["join"]["primary"]["sf_col"]
    sf_fb  = cfg.get("join", {}).get("fallback", {}).get("sf_col", "")

    issues: list[dict] = []

    def _add(source, check, severity, count, example=""):
        if count:
            issues.append({
                "Source":    source,
                "Check":     check,
                "Severity":  severity,
                "Row Count": count,
                "Example":   example,
            })

    # ── SAP checks ────────────────────────────────────────────────────────────
    r = con.execute(f"SELECT COUNT(*) FROM sap_clean WHERE \"{sap_id}\" IS NULL").fetchone()[0]
    _add("SAP", f"Null {sap_id}", "CRITICAL", r)

    r = con.execute(
        f"SELECT COUNT(*) FROM (SELECT \"{sap_id}\", COUNT(*) c FROM sap_clean "
        f"WHERE \"{sap_id}\" IS NOT NULL GROUP BY \"{sap_id}\" HAVING c > 1)"
    ).fetchone()[0]
    _add("SAP", f"Duplicate {sap_id}", "HIGH", r)

    r = con.execute("SELECT COUNT(*) FROM sap_clean WHERE name1 IS NULL").fetchone()[0]
    _add("SAP", "Null Account Name (name1)", "HIGH", r)

    r = con.execute(
        "SELECT COUNT(*) FROM sap_clean WHERE smtp_addr IS NOT NULL "
        "AND smtp_addr NOT LIKE '%@%'"
    ).fetchone()[0]
    _add("SAP", "Invalid email format (smtp_addr)", "INFO", r)

    r = con.execute(
        "SELECT COUNT(*) FROM sap_clean WHERE tel_number IS NOT NULL "
        "AND regexp_matches(tel_number, '[^0-9 +().\\-]')"
    ).fetchone()[0]
    _add("SAP", "Suspicious phone characters (tel_number)", "INFO", r)

    # ── SF checks ─────────────────────────────────────────────────────────────
    r = con.execute(f"SELECT COUNT(*) FROM sf_clean WHERE \"{sf_id}\" IS NULL OR TRIM(\"{sf_id}\") = ''").fetchone()[0]
    _add("SF", f"Null/blank {sf_id}", "HIGH", r)

    if sf_fb:
        r = con.execute(f"SELECT COUNT(*) FROM sf_clean WHERE \"{sf_fb}\" IS NULL OR TRIM(\"{sf_fb}\") = ''").fetchone()[0]
        _add("SF", f"Null/blank {sf_fb} (fallback key)", "INFO", r)

    r = con.execute(
        f"SELECT COUNT(*) FROM (SELECT \"{sf_id}\", COUNT(*) c FROM sf_clean "
        f"WHERE \"{sf_id}\" IS NOT NULL AND TRIM(\"{sf_id}\") <> '' "
        f"GROUP BY \"{sf_id}\" HAVING c > 1)"
    ).fetchone()[0]
    _add("SF", f"Duplicate {sf_id}", "HIGH", r)

    r = con.execute("SELECT COUNT(*) FROM sf_clean WHERE Name IS NULL").fetchone()[0]
    _add("SF", "Null Account Name (Name)", "HIGH", r)

    r = con.execute(
        "SELECT COUNT(*) FROM sf_clean WHERE WC_Email__c IS NOT NULL "
        "AND WC_Email__c NOT LIKE '%@%'"
    ).fetchone()[0]
    _add("SF", "Invalid email format (WC_Email__c)", "INFO", r)

    df = pd.DataFrame(issues) if issues else pd.DataFrame(
        columns=["Source", "Check", "Severity", "Row Count", "Example"]
    )
    total = int(df["Row Count"].sum()) if not df.empty else 0
    logger.info("DQ checks complete — %d issue types found (%d total rows affected).", len(df), total)
    return df
