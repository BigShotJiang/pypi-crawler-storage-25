from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional
import pandas as pd


@dataclass
class RunMetadata:
    run_id: str
    run_timestamp: datetime
    sap_file: str
    sf_file: str
    config_file: str
    config_version: str


@dataclass
class ReconciliationResult:
    summary: dict
    matched: pd.DataFrame
    sap_only: pd.DataFrame
    sf_only: pd.DataFrame
    field_mismatches: pd.DataFrame
    duplicates_sap: pd.DataFrame
    duplicates_sf: pd.DataFrame
    fuzzy_candidates: pd.DataFrame
    data_quality: pd.DataFrame
    metadata: RunMetadata

    def log_summary(self) -> str:
        s = self.summary
        lines = [
            f"Run ID          : {self.metadata.run_id}",
            f"Timestamp       : {self.metadata.run_timestamp.strftime('%Y-%m-%d %H:%M:%S')}",
            f"SAP file        : {self.metadata.sap_file}",
            f"SF file         : {self.metadata.sf_file}",
            "─" * 48,
            f"SAP raw records : {s.get('sap_raw_count', 0):>10,}",
            f"SAP unique      : {s.get('sap_unique_count', 0):>10,}",
            f"SAP duplicates  : {s.get('sap_dup_count', 0):>10,}",
            f"SF  raw records : {s.get('sf_raw_count', 0):>10,}",
            f"SF  unique      : {s.get('sf_unique_count', 0):>10,}",
            f"SF  duplicates  : {s.get('sf_dup_count', 0):>10,}",
            "─" * 48,
            f"Matched         : {s.get('matched_count', 0):>10,}",
            f"SAP Only        : {s.get('sap_only_count', 0):>10,}",
            f"SF  Only        : {s.get('sf_only_count', 0):>10,}",
            f"Field mismatches: {s.get('field_mismatch_count', 0):>10,}",
            f"Fuzzy candidates: {s.get('fuzzy_candidate_count', 0):>10,}",
            f"DQ issues       : {s.get('dq_issue_count', 0):>10,}",
            "─" * 48,
            f"Match rate      : {s.get('match_rate_pct', 0.0):>9.2f}%",
            f"Exception rate  : {s.get('exception_rate_pct', 0.0):>9.2f}%",
        ]
        return "\n".join(lines)
