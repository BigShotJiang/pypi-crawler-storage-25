"""
dashboard/app.py — FastAPI application for the WinSecAudit read-only dashboard.

Design decisions:
  - All DB access goes through db/database.py public functions only — no raw SQL here.
  - cve_map.json is read directly for TI data (threat_intel.py owns the file format
    and this module is the authoritative consumer for the dashboard read path).
  - system_value / expected_value are stored as JSON strings in SQLite and deserialized
    to Python objects by _deserialize_result(); _to_str() re-encodes them as JSON
    strings to satisfy CheckResultRow's str type contract.
  - StaticFiles is mounted LAST so /api/* routes always win over the catch-all.
  - init_db() is called in the lifespan context so the engine is ready before the
    first request, and the TestClient path (which never triggers lifespan startup
    unless explicitly enabled) uses the already-initialized engine from the caller.
  - CORS is restricted to localhost:8080 / 127.0.0.1:8080 — this is a local-only tool
    and there is no authentication layer.
"""
from __future__ import annotations

import json
import logging
from collections import defaultdict
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

from dashboard.models import (
    CategoryScore,
    CheckResultRow,
    CVEDetail,
    DashboardOverview,
    DriftReport,
    RemediationItem,
    ScanDetail,
    ScanSummary,
)

logger = logging.getLogger(__name__)

# Path resolution — delegated to runtime_paths so the dashboard works in
# both source-tree and pip-installed modes.
from winsecaudit_paths import CVE_CACHE_PATH as _CVE_CACHE_PATH

_PROJECT_ROOT  = Path(__file__).resolve().parent.parent
_STATIC_DIR    = Path(__file__).resolve().parent / "static"

# Severity ordering used for sorting remediation results
_SEVERITY_ORDER = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}


# ---------------------------------------------------------------------------
# Lifespan — ensures DB is ready before any request
# ---------------------------------------------------------------------------

@asynccontextmanager
async def lifespan(app: FastAPI):
    from db.database import init_db
    init_db()
    yield


# ---------------------------------------------------------------------------
# App + CORS
# ---------------------------------------------------------------------------

app = FastAPI(
    title="WinSecAudit",
    description="Read-only REST API for the WinSecAudit security dashboard.",
    version="2.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:8080", "http://127.0.0.1:8080"],
    # GET for read-only views, POST for the in-dashboard "Scan Now" trigger.
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)


# ---------------------------------------------------------------------------
# Internal helpers — coercion, normalization
# ---------------------------------------------------------------------------

def _to_str(value: Any) -> str:
    """Convert any DB-deserialized value to a JSON string for the API response."""
    if value is None:
        return "null"
    if isinstance(value, str):
        return value
    try:
        return json.dumps(value, default=str)
    except Exception:
        return str(value)


def _coerce_cve_ids(raw: Any) -> list[str]:
    """Normalize cve_ids from DB (list, JSON string, or None) → list[str]."""
    if raw is None:
        return []
    if isinstance(raw, (list, tuple)):
        return [str(c) for c in raw if c]
    if isinstance(raw, str):
        try:
            parsed = json.loads(raw)
            if isinstance(parsed, list):
                return [str(c) for c in parsed if c]
        except Exception:
            pass
    return []


def _result_to_row(r: dict) -> CheckResultRow:
    """Convert a DB result dict to a CheckResultRow Pydantic model."""
    return CheckResultRow(
        check_name            = r.get("check_name", "") or "",
        category              = r.get("category", "") or "",
        status                = r.get("status", "") or "",
        severity              = r.get("severity", "") or "",
        weight                = int(r.get("weight") or 0),
        system_value          = _to_str(r.get("system_value")),
        expected_value        = _to_str(r.get("expected_value")),
        cve_ids               = _coerce_cve_ids(r.get("cve_ids")),
        mitre_technique       = r.get("mitre_technique", "") or "",
        cis_id                = r.get("cis_id", "") or "",
        remediation_cmd       = r.get("remediation_cmd", "") or "",
        remediation_supported = bool(r.get("remediation_supported", False)),
        error_message         = r.get("error_message") or None,
    )


def _scan_to_summary(s: dict) -> ScanSummary:
    """Convert a DB scan dict (no results) to a ScanSummary Pydantic model."""
    return ScanSummary(
        id               = s.get("id", ""),
        machine_id       = s.get("machine_id", ""),
        timestamp        = s.get("timestamp", ""),
        profile          = s.get("profile", "") or "",
        score            = float(s.get("score") or 0.0),
        grade            = s.get("grade", "") or "",
        total_checks     = int(s.get("total_checks") or 0),
        passed_checks    = int(s.get("passed_checks") or 0),
        failed_checks    = int(s.get("failed_checks") or 0),
        error_checks     = int(s.get("error_checks") or 0),
        skipped_checks   = int(s.get("skipped_checks") or 0),
        duration_seconds = float(s.get("duration_seconds") or 0.0),
    )


def _compute_category_scores(results: list[dict]) -> list[CategoryScore]:
    """Compute per-category pass/fail/total/score_pct from a list of result dicts."""
    cat: dict[str, dict] = defaultdict(lambda: {"total": 0, "passed": 0, "failed": 0, "earned": 0, "max_w": 0})
    for r in results:
        c      = r.get("category", "Unknown") or "Unknown"
        status = r.get("status", "") or ""
        weight = int(r.get("weight") or 1)
        cat[c]["total"] += 1
        if status == "SKIPPED":
            continue
        cat[c]["max_w"] += weight
        if status == "PASS":
            cat[c]["passed"]  += 1
            cat[c]["earned"]  += weight
        elif status == "FAIL":
            cat[c]["failed"] += 1

    rows: list[CategoryScore] = []
    for name, d in cat.items():
        score_pct = round(d["earned"] / d["max_w"] * 100, 1) if d["max_w"] > 0 else 100.0
        rows.append(CategoryScore(
            category  = name,
            total     = d["total"],
            passed    = d["passed"],
            failed    = d["failed"],
            score_pct = score_pct,
        ))
    rows.sort(key=lambda x: x.score_pct)
    return rows


def _load_cve_cache() -> dict:
    """Read cve_map.json; return {} on any error. Only dict-valued entries are TI data."""
    try:
        text = _CVE_CACHE_PATH.read_text(encoding="utf-8")
        raw  = json.loads(text)
        # Filter to TI enrichment dicts only (legacy string entries are excluded)
        return {k: v for k, v in raw.items() if isinstance(v, dict)}
    except Exception as exc:
        logger.debug("CVE cache read failed: %s", exc)
        return {}


def _build_cve_detail(entry: dict) -> CVEDetail:
    return CVEDetail(
        cve_id             = entry.get("cve_id", ""),
        cvss_score         = entry.get("cvss_score"),
        epss_score         = entry.get("epss_score"),
        in_cisa_kev        = bool(entry.get("in_cisa_kev", False)),
        kev_ransomware_use = entry.get("kev_ransomware_use") or None,
    )


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

@app.get("/api/v1/overview", response_model=DashboardOverview)
def overview() -> DashboardOverview:
    """Aggregate dashboard overview: latest scan, score trend, category scores, top CVEs."""
    try:
        from db.database import get_latest_scan, list_scans

        latest_raw = get_latest_scan()
        scans_raw  = list_scans(limit=10)

        latest_summary: ScanSummary | None = None
        category_scores: list[CategoryScore] = []
        critical_failures: list[CheckResultRow] = []
        high_failures: list[CheckResultRow] = []
        cisa_kev_count = 0
        top_cves: list[CVEDetail] = []

        # Score trend — lightweight summary rows (no results)
        score_trend = [
            {
                "id":        s.get("id", ""),
                "timestamp": s.get("timestamp", ""),
                "score":     float(s.get("score") or 0.0),
                "grade":     s.get("grade", ""),
            }
            for s in scans_raw
        ]

        if latest_raw:
            latest_summary = _scan_to_summary(latest_raw)
            results        = latest_raw.get("results", [])

            category_scores = _compute_category_scores(results)

            # Collect CVE IDs from FAIL results for KEV counting
            failed_cve_ids: set[str] = set()
            for r in results:
                status = r.get("status", "")
                if status == "FAIL":
                    cid_list = _coerce_cve_ids(r.get("cve_ids"))
                    failed_cve_ids.update(cid_list)

            # Build critical / high failure lists (sorted: severity then weight DESC)
            fail_results = [r for r in results if r.get("status") == "FAIL"]
            fail_results.sort(key=lambda r: (
                _SEVERITY_ORDER.get(r.get("severity", "LOW"), 99),
                -(int(r.get("weight") or 0)),
            ))
            for r in fail_results:
                sev = r.get("severity", "")
                row = _result_to_row(r)
                if sev == "CRITICAL":
                    critical_failures.append(row)
                elif sev == "HIGH":
                    high_failures.append(row)

            # CVE cache — KEV count restricted to CVEs from failing checks
            cve_cache = _load_cve_cache()
            cisa_kev_count = sum(
                1 for cid, entry in cve_cache.items()
                if cid in failed_cve_ids and entry.get("in_cisa_kev")
            )

            # Top 5 CVEs by EPSS score across all cache entries
            ti_entries = list(cve_cache.values())
            ti_entries.sort(key=lambda e: float(e.get("epss_score") or 0.0), reverse=True)
            top_cves = [_build_cve_detail(e) for e in ti_entries[:5]]

        return DashboardOverview(
            latest_scan       = latest_summary,
            total_scans       = len(scans_raw),
            score_trend       = score_trend,
            category_scores   = category_scores,
            critical_failures = critical_failures,
            high_failures     = high_failures,
            cisa_kev_count    = cisa_kev_count,
            top_cves          = top_cves,
        )

    except Exception as exc:
        logger.exception("overview() failed")
        raise HTTPException(status_code=500, detail={"error": str(exc)})


@app.get("/api/v1/scans", response_model=list[ScanSummary])
def scans_list(
    limit:      int         = Query(20, ge=1, le=5000, description="Max results"),
    machine_id: str | None  = Query(None, description="Filter by machine hostname"),
) -> list[ScanSummary]:
    """List saved scans ordered by timestamp DESC."""
    try:
        from db.database import list_scans
        rows = list_scans(machine_id=machine_id, limit=limit)
        return [_scan_to_summary(r) for r in rows]
    except Exception as exc:
        logger.exception("scans_list() failed")
        raise HTTPException(status_code=500, detail={"error": str(exc)})


@app.get("/api/v1/scans/{scan_id}", response_model=ScanDetail)
def scan_detail(scan_id: str) -> ScanDetail:
    """Return a single scan with all result rows."""
    try:
        from db.database import get_scan
        raw = get_scan(scan_id)
        if raw is None:
            raise HTTPException(status_code=404, detail={"error": "Not found"})

        return ScanDetail(
            **_scan_to_summary(raw).model_dump(),
            results=[_result_to_row(r) for r in raw.get("results", [])],
        )
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("scan_detail(%s) failed", scan_id)
        raise HTTPException(status_code=500, detail={"error": str(exc)})


@app.get("/api/v1/scans/{scan_id}/categories", response_model=list[CategoryScore])
def scan_categories(scan_id: str) -> list[CategoryScore]:
    """Per-category pass/fail breakdown for a specific scan."""
    try:
        from db.database import get_scan
        raw = get_scan(scan_id)
        if raw is None:
            raise HTTPException(status_code=404, detail={"error": "Not found"})
        return _compute_category_scores(raw.get("results", []))
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("scan_categories(%s) failed", scan_id)
        raise HTTPException(status_code=500, detail={"error": str(exc)})


@app.get("/api/v1/drift", response_model=DriftReport)
def drift(
    scan_a: str | None = Query(None, description="Older scan ID"),
    scan_b: str | None = Query(None, description="Newer scan ID"),
) -> DriftReport:
    """
    Compare two scans.  If scan_a / scan_b are omitted, uses the two most recent
    scans (oldest → newest).  Returns 404 if fewer than 2 scans exist.
    """
    try:
        from db.database import get_drift, list_scans

        if scan_a is None or scan_b is None:
            recent = list_scans(limit=2)
            if len(recent) < 2:
                raise HTTPException(
                    status_code=404,
                    detail={"error": "Fewer than 2 scans available for drift comparison"},
                )
            # list_scans returns newest first; drift is older → newer
            scan_a = recent[1]["id"]
            scan_b = recent[0]["id"]

        raw = get_drift(scan_a, scan_b)
        return DriftReport(
            scan_a        = raw.get("scan_a", scan_a),
            scan_b        = raw.get("scan_b", scan_b),
            score_delta   = float(raw.get("score_delta", 0.0)),
            regressions   = raw.get("regressions", []),
            improvements  = raw.get("improvements", []),
            stable_pass   = int(raw.get("stable_pass", 0)),
            stable_fail   = int(raw.get("stable_fail", 0)),
            new_checks    = raw.get("new_checks", []),
            removed_checks= raw.get("removed_checks", []),
        )
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("drift() failed")
        raise HTTPException(status_code=500, detail={"error": str(exc)})


@app.get("/api/v1/drift-detailed")
def drift_detailed(
    scan_a: str | None = Query(None, description="Older scan ID (Baseline)"),
    scan_b: str | None = Query(None, description="Newer scan ID (Current)"),
) -> dict:
    """
    Rich drift comparison powering the Drift Analysis page.

    Walks both scans' full result lists and enriches every check with:
      - check_name, check_id, category, severity, weight
      - mitre_technique, cve_ids
      - status_a, status_b
      - pts  (severity-based score-impact indicator)
      - impact (Low / Medium / High)

    Buckets:
      regressions   = PASS → FAIL
      improvements  = FAIL → PASS
      stable_pass   = PASS → PASS
      stable_fail   = FAIL → FAIL
      new_failures  = present in B (FAIL), absent in A
      new_passes    = present in B (PASS), absent in A
      removed       = present in A, absent in B
    """
    try:
        from db.database import get_scan, list_scans

        # Default to the latest two scans (oldest → newest order)
        if not scan_a or not scan_b:
            recent = list_scans(limit=2)
            if len(recent) < 2:
                raise HTTPException(
                    status_code=404,
                    detail={"error": "Need at least 2 scans for drift comparison",
                            "scans_available": len(recent)},
                )
            scan_a = recent[1]["id"]
            scan_b = recent[0]["id"]

        a = get_scan(scan_a)
        b = get_scan(scan_b)
        if not a or not b:
            raise HTTPException(status_code=404, detail={"error": "Scan not found"})

        # Severity → impact label + pts (matches the reference design's expectation
        # so panel reviewers see clean -25 / -20 / -15 / -10 increments)
        SEV_PTS = {"CRITICAL": 25, "HIGH": 20, "MEDIUM": 15, "LOW": 10}
        SEV_IMPACT = {"CRITICAL": "High", "HIGH": "High", "MEDIUM": "Medium", "LOW": "Low"}

        def _idx(scan: dict) -> dict[str, dict]:
            out = {}
            for r in (scan.get("results") or []):
                name = r.get("check_name")
                if name:
                    out[name] = r
            return out

        a_idx = _idx(a)
        b_idx = _idx(b)

        def _enrich(name: str, ra: dict | None, rb: dict | None, kind: str) -> dict:
            base = rb or ra or {}
            sev  = (base.get("severity") or "").upper()
            pts_abs = SEV_PTS.get(sev, 5)
            # Sign depends on bucket
            if kind in ("regression", "new_failure", "stable_fail"): pts = -pts_abs
            elif kind in ("improvement", "new_pass"):                pts = +pts_abs
            else:                                                    pts = 0
            return {
                "check_name":      base.get("check_name", name),
                "check_id":        base.get("check_id") or "",
                "category":        base.get("category"),
                "severity":        sev,
                "weight":          base.get("weight"),
                "mitre_technique": base.get("mitre_technique"),
                "cve_ids":         base.get("cve_ids") or [],
                "status_a":        (ra or {}).get("status"),
                "status_b":        (rb or {}).get("status"),
                "pts":             pts,
                "impact":          SEV_IMPACT.get(sev, "Low"),
            }

        regressions, improvements = [], []
        stable_pass, stable_fail  = [], []
        new_failures, new_passes  = [], []
        removed                   = []

        # Walk B as the universe; pair with A
        seen = set()
        for name, rb in b_idx.items():
            seen.add(name)
            ra = a_idx.get(name)
            sa = (ra or {}).get("status", "").upper()
            sb = (rb or {}).get("status", "").upper()
            if ra is None:
                if sb == "FAIL":   new_failures.append(_enrich(name, ra, rb, "new_failure"))
                elif sb == "PASS": new_passes.append(_enrich(name, ra, rb, "new_pass"))
                continue
            if sa == "PASS" and sb == "FAIL":   regressions.append(_enrich(name, ra, rb, "regression"))
            elif sa == "FAIL" and sb == "PASS": improvements.append(_enrich(name, ra, rb, "improvement"))
            elif sa == "PASS" and sb == "PASS": stable_pass.append(_enrich(name, ra, rb, "stable_pass"))
            elif sa == "FAIL" and sb == "FAIL": stable_fail.append(_enrich(name, ra, rb, "stable_fail"))

        # Removed = in A but not in B
        for name, ra in a_idx.items():
            if name in seen: continue
            removed.append(_enrich(name, ra, None, "removed"))

        # Sort each bucket by severity → category for stable, predictable rendering
        sev_rank = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}
        sort_key = lambda r: (sev_rank.get((r.get("severity") or "").upper(), 9),
                              r.get("category") or "", r.get("check_name") or "")
        for arr in (regressions, improvements, stable_pass, stable_fail,
                    new_failures, new_passes, removed):
            arr.sort(key=sort_key)

        score_a = float(a.get("score") or 0.0)
        score_b = float(b.get("score") or 0.0)

        return {
            "scan_a": {
                "id":         a.get("id"),
                "timestamp":  a.get("timestamp"),
                "machine_id": a.get("machine_id"),
                "profile":    a.get("profile"),
                "score":      score_a,
                "grade":      a.get("grade"),
            },
            "scan_b": {
                "id":         b.get("id"),
                "timestamp":  b.get("timestamp"),
                "machine_id": b.get("machine_id"),
                "profile":    b.get("profile"),
                "score":      score_b,
                "grade":      b.get("grade"),
            },
            "score_delta":   round(score_b - score_a, 2),
            "regressions":   regressions,
            "improvements":  improvements,
            "stable_pass":   stable_pass,
            "stable_fail":   stable_fail,
            "new_failures":  new_failures,
            "new_passes":    new_passes,
            "removed":       removed,
            "totals": {
                "regressions":  len(regressions),
                "improvements": len(improvements),
                "stable_pass":  len(stable_pass),
                "stable_fail":  len(stable_fail),
                "new_failures": len(new_failures),
                "new_passes":   len(new_passes),
                "removed":      len(removed),
            },
        }

    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("drift_detailed() failed")
        raise HTTPException(status_code=500, detail={"error": str(exc)})


@app.get("/api/v1/checks/history/{check_name}", response_model=list[dict])
def check_history(
    check_name: str,
    limit: int = Query(10, ge=1, le=100),
) -> list[dict]:
    """Return the last N results for a specific check across scans."""
    try:
        from db.database import get_check_history
        rows = get_check_history(check_name, limit=limit)
        # Coerce JSON fields so all values are JSON-serializable
        out = []
        for r in rows:
            d = dict(r)
            d["system_value"]   = _to_str(d.get("system_value"))
            d["expected_value"] = _to_str(d.get("expected_value"))
            d["cve_ids"]        = _coerce_cve_ids(d.get("cve_ids"))
            out.append(d)
        return out
    except Exception as exc:
        logger.exception("check_history(%s) failed", check_name)
        raise HTTPException(status_code=500, detail={"error": str(exc)})


@app.get("/api/v1/remediation", response_model=list[RemediationItem])
def remediation() -> list[RemediationItem]:
    """
    Return FAIL results from the latest scan where remediation_supported=True,
    sorted by severity (CRITICAL first).
    """
    try:
        from db.database import get_latest_scan

        latest = get_latest_scan()
        if latest is None:
            return []

        results = latest.get("results", [])
        items = [
            r for r in results
            if r.get("status") == "FAIL" and r.get("remediation_supported")
        ]
        items.sort(key=lambda r: _SEVERITY_ORDER.get(r.get("severity", "LOW"), 99))

        return [
            RemediationItem(
                check_name      = r.get("check_name", "") or "",
                category        = r.get("category", "") or "",
                severity        = r.get("severity", "") or "",
                remediation_cmd = r.get("remediation_cmd", "") or "",
                cve_ids         = _coerce_cve_ids(r.get("cve_ids")),
            )
            for r in items
        ]
    except Exception as exc:
        logger.exception("remediation() failed")
        raise HTTPException(status_code=500, detail={"error": str(exc)})


_MITRE_TACTIC_MAP = {
    # Compact technique-prefix to tactic map covering the IDs WinSecAudit checks emit.
    # Maps (technique_id_prefix → tactic_short_code).  Extend as new checks land.
    "T1078":   "init",   "T1133":   "init",   "T1190":   "init",
    "T1059":   "exec",   "T1106":   "exec",   "T1203":   "exec",   "T1569":   "exec",
    "T1547":   "pers",   "T1543":   "pers",   "T1098":   "pers",   "T1136":   "pers",
    "T1548":   "priv",   "T1068":   "priv",   "T1134":   "priv",   "T1484":   "priv",
    "T1562":   "def",    "T1070":   "def",    "T1112":   "def",    "T1027":   "def",   "T1218": "def",
    "T1110":   "cred",   "T1003":   "cred",   "T1555":   "cred",   "T1212":   "cred",  "T1552": "cred",
    "T1083":   "disc",   "T1057":   "disc",   "T1018":   "disc",   "T1518":   "disc",
    "T1021":   "lat",    "T1080":   "lat",    "T1210":   "lat",    "T1534":   "lat",
    "T1486":   "imp",    "T1490":   "imp",    "T1561":   "imp",    "T1489":   "imp",
    "T1595":   "recon",  "T1592":   "recon",  "T1589":   "recon",
}

_TACTICS = [
    ("recon", "Recon"),
    ("init",  "Init. Access"),
    ("exec",  "Execution"),
    ("pers",  "Persistence"),
    ("priv",  "Priv. Esc"),
    ("def",   "Defense Evasion"),
    ("cred",  "Cred. Access"),
    ("disc",  "Discovery"),
    ("lat",   "Lateral Movement"),
    ("imp",   "Impact"),
]


def _tactic_for(technique_id: str) -> str | None:
    """Return tactic short-code for a MITRE technique ID, or None if unknown."""
    if not technique_id:
        return None
    base = technique_id.split(".")[0]  # T1078.003 -> T1078
    return _MITRE_TACTIC_MAP.get(base)


@app.get("/api/v1/mitre")
def mitre_matrix() -> dict:
    """
    MITRE ATT&CK matrix for the latest scan.

    Returns three-row × ten-column matrix where:
      - rows are observation tiers (detected / potential / not_observed)
      - columns are tactics (recon, init, exec, pers, priv, def, cred, disc, lat, imp)

    `detected`     = check FAILED  (the technique works against this host)
    `potential`    = check ERROR'd or SKIPPED
    `not_observed` = check PASSED  (the technique is mitigated)
    """
    try:
        from db.database import get_latest_scan
        scan = get_latest_scan()
        if not scan:
            return {"tactics": [{"key": k, "label": l} for k, l in _TACTICS],
                    "rows": [], "techniques": [], "scan_id": None}

        # Build counts
        rows = {
            "detected":     {k: 0 for k, _ in _TACTICS},
            "potential":    {k: 0 for k, _ in _TACTICS},
            "not_observed": {k: 0 for k, _ in _TACTICS},
        }
        # Per-cell technique listings for tooltip / drill-down
        cells: dict[str, list[dict]] = {}

        for r in (scan.get("results") or []):
            tid    = (r.get("mitre_technique") or "").strip()
            tactic = _tactic_for(tid)
            if not tactic:
                continue
            status = (r.get("status") or "").upper()
            if status == "FAIL":
                row_key = "detected"
            elif status in ("ERROR", "SKIPPED"):
                row_key = "potential"
            elif status == "PASS":
                row_key = "not_observed"
            else:
                continue
            rows[row_key][tactic] += 1
            cells.setdefault(f"{row_key}:{tactic}", []).append({
                "check_name": r.get("check_name", ""),
                "severity":   r.get("severity", ""),
                "technique":  tid,
                "status":     status,
            })

        # Materialise into row arrays in tactic order
        out_rows = []
        for label, key in [
            ("Detected",     "detected"),
            ("Potential",    "potential"),
            ("Not Observed", "not_observed"),
        ]:
            out_rows.append({
                "label":  label,
                "key":    key,
                "values": [rows[key][k] for k, _ in _TACTICS],
            })

        return {
            "tactics":    [{"key": k, "label": l} for k, l in _TACTICS],
            "rows":       out_rows,
            "cells":      cells,
            "scan_id":    scan.get("id"),
            "timestamp":  scan.get("timestamp"),
        }

    except Exception as exc:
        logger.exception("mitre_matrix() failed")
        raise HTTPException(status_code=500, detail={"error": str(exc)})


@app.get("/api/v1/checks-history")
def checks_history(history_limit: int = Query(50, ge=2, le=500)) -> dict:
    """
    Aggregated per-check intelligence for the Check History page.

    Walks every persisted scan (capped at `history_limit`), groups all results
    by check_name, and computes:
      - first/last seen timestamps
      - per-check execution count
      - last 10-status trend array
      - stability classification (stable / improving / degrading / flapping)
      - severity, category, MITRE technique pulled from the latest occurrence

    Plus aggregate dashboards:
      - category breakdown (latest scan)
      - overall health (latest score + grade + delta vs prev)
      - execution health (% passed / failed / warnings)
      - per-day execution timeline (last 7 days with scans)
    """
    try:
        from collections import defaultdict
        from db.database import get_latest_scan, get_scan, list_scans

        scans = list_scans(limit=history_limit)
        if not scans:
            return {
                "categories":          {},
                "overall_health":      {"score": None, "grade": None, "delta_from_last": None,
                                        "trend": []},
                "execution_health":    {"total": 0, "passed": 0, "failed": 0, "warnings": 0,
                                        "passed_pct": 0, "failed_pct": 0, "warning_pct": 0},
                "execution_timeline":  {"dates": [], "passed": [], "failed": [], "warnings": []},
                "checks":              [],
                "scans_available":     0,
            }

        latest_summary = scans[0]
        latest = get_scan(latest_summary["id"]) or {}
        prev_summary = scans[1] if len(scans) > 1 else None

        # ── Build per-check aggregate by walking every scan's results ──────
        per_check: dict[str, dict] = {}
        for s in scans:
            full = get_scan(s["id"])
            if not full:
                continue
            for r in (full.get("results") or []):
                name = r.get("check_name") or ""
                if not name:
                    continue
                ent = per_check.setdefault(name, {
                    "check_name":       name,
                    "category":         r.get("category"),
                    "severity":         r.get("severity"),
                    "mitre_technique":  r.get("mitre_technique"),
                    "cve_ids":          r.get("cve_ids") or [],
                    "executions":       [],
                })
                # Refresh metadata from latest occurrence
                ent["category"]        = r.get("category") or ent["category"]
                ent["severity"]        = r.get("severity") or ent["severity"]
                ent["mitre_technique"] = r.get("mitre_technique") or ent["mitre_technique"]
                if r.get("cve_ids"):
                    ent["cve_ids"]     = r.get("cve_ids")
                ent["executions"].append({
                    "scan_id":  s["id"],
                    "timestamp": s["timestamp"],
                    "status":   (r.get("status") or "").upper(),
                })

        # ── Stability heuristic ────────────────────────────────────────────
        def stability_of(statuses: list[str]) -> str:
            if len(statuses) < 2:
                return "stable"
            uniq = set(statuses)
            if len(uniq) == 1:
                return "stable"
            transitions = sum(1 for i in range(1, len(statuses))
                              if statuses[i] != statuses[i - 1])
            # Flapping = many transitions relative to length
            if transitions >= len(statuses) * 0.4 and transitions >= 3:
                return "flapping"
            # Compare halves
            half = len(statuses) // 2
            recent_fail = sum(1 for s in statuses[half:] if s == "FAIL")
            older_fail  = sum(1 for s in statuses[:half] if s == "FAIL")
            recent_pct = recent_fail / max(1, len(statuses) - half)
            older_pct  = older_fail  / max(1, half)
            if recent_pct < older_pct - 0.15: return "improving"
            if recent_pct > older_pct + 0.15: return "degrading"
            return "stable"

        # ── Materialise check rows ─────────────────────────────────────────
        checks_out = []
        for idx, (name, c) in enumerate(sorted(per_check.items()), start=1):
            execs = sorted(c["executions"], key=lambda e: e["timestamp"] or "")
            if not execs:
                continue
            statuses = [e["status"] for e in execs]
            checks_out.append({
                "check_id":         f"CHK-{idx:03d}",
                "check_name":       name,
                "category":         c["category"],
                "severity":         c["severity"],
                "mitre_technique":  c["mitre_technique"],
                "cve_ids":          c["cve_ids"][:5] if isinstance(c["cve_ids"], list) else [],
                "current_result":   statuses[-1],
                "first_seen":       execs[0]["timestamp"],
                "last_seen":        execs[-1]["timestamp"],
                "execution_count":  len(execs),
                "trend":            statuses[-10:],
                "stability":        stability_of(statuses),
            })

        # ── Category breakdown — from latest scan's results ────────────────
        cat: dict[str, dict] = defaultdict(lambda: {"total": 0, "passed": 0, "failed": 0, "warnings": 0})
        for r in (latest.get("results") or []):
            c = r.get("category") or "Other"
            cat[c]["total"] += 1
            st = (r.get("status") or "").upper()
            if st == "PASS":   cat[c]["passed"]   += 1
            elif st == "FAIL": cat[c]["failed"]   += 1
            else:              cat[c]["warnings"] += 1
        categories = dict(cat)

        # ── Overall health — score, grade, delta ───────────────────────────
        score = float(latest.get("score") or 0.0)
        grade = latest.get("grade") or "?"
        delta = None
        if prev_summary is not None:
            try:
                delta = round(score - float(prev_summary.get("score") or 0.0), 2)
            except Exception:
                delta = None
        score_trend = [{"id": s["id"], "ts": s["timestamp"],
                        "score": float(s.get("score") or 0.0),
                        "grade": s.get("grade") or ""} for s in reversed(scans[:10])]
        overall_health = {
            "score":           score,
            "grade":           grade,
            "delta_from_last": delta,
            "trend":           score_trend,
        }

        # ── Execution health — % pass / fail / warning of latest scan ──────
        counts = {"PASS": 0, "FAIL": 0, "WARN": 0}
        for r in (latest.get("results") or []):
            s = (r.get("status") or "").upper()
            if s == "PASS":   counts["PASS"] += 1
            elif s == "FAIL": counts["FAIL"] += 1
            else:             counts["WARN"] += 1
        total = sum(counts.values()) or 1
        execution_health = {
            "total":       sum(counts.values()),
            "passed":      counts["PASS"],
            "failed":      counts["FAIL"],
            "warnings":    counts["WARN"],
            "passed_pct":  round(counts["PASS"] / total * 100, 1),
            "failed_pct":  round(counts["FAIL"] / total * 100, 1),
            "warning_pct": round(counts["WARN"] / total * 100, 1),
        }

        # ── Execution timeline (last 7 distinct dates with scans) ──────────
        by_date = defaultdict(lambda: {"passed": 0, "failed": 0, "warnings": 0})
        for s in scans:
            d = (s.get("timestamp") or "")[:10]
            if not d: continue
            by_date[d]["passed"]   += int(s.get("passed_checks") or 0)
            by_date[d]["failed"]   += int(s.get("failed_checks") or 0)
            by_date[d]["warnings"] += int(s.get("error_checks") or 0) + int(s.get("skipped_checks") or 0)
        # last 7 dates with scans, in chronological order
        timeline_dates = sorted(by_date.keys())[-7:]
        execution_timeline = {
            "dates":    timeline_dates,
            "passed":   [by_date[d]["passed"]   for d in timeline_dates],
            "failed":   [by_date[d]["failed"]   for d in timeline_dates],
            "warnings": [by_date[d]["warnings"] for d in timeline_dates],
        }

        return {
            "categories":         categories,
            "overall_health":     overall_health,
            "execution_health":   execution_health,
            "execution_timeline": execution_timeline,
            "checks":             checks_out,
            "scans_available":    len(scans),
            "latest_scan_id":     latest.get("id"),
        }

    except Exception as exc:
        logger.exception("checks_history() failed")
        raise HTTPException(status_code=500, detail={"error": str(exc)})


@app.get("/api/v1/remediation-detailed")
def remediation_detailed() -> dict:
    """
    Rich remediation intelligence for the Remediation page.

    Returns a list of remediable checks (remediation_supported=True) with:
      - check_name, check_id, category, severity, cve_ids, mitre_technique
      - current_status (PASS / FAIL / ERROR / SKIPPED)
      - failure_count (number of historical scans where this check failed)
      - scans_analysed (size of history window)
      - why_matters (plain-English risk summary, parsed from BaseCheck.risk_summary)
      - fix_explanation (plain-English fix rationale, parsed from BaseCheck.fix_steps)
      - automated.command (the PowerShell / reg / netsh command)
      - automated.warnings (list of safety notes)
      - manual_steps (auto-generated step list derived from the command)
      - tab_default ('automated' or 'manual')

    Plus aggregate `summary` for the four hero cards.
    """
    try:
        from collections import defaultdict
        from db.database import get_latest_scan, get_scan, list_scans
        from checks.base import CheckRegistry
        # Re-use the CHECKS_DIR resolution from the CLI module
        from cli.main import CHECKS_DIR

        latest = get_latest_scan()
        if latest is None:
            return {
                "items":   [],
                "summary": {"critical": 0, "high": 0, "medium": 0, "low": 0, "total": 0},
                "scans_available": 0,
            }

        # Discover all check classes so we can read risk_summary, fix_steps, etc.
        try:
            all_classes = CheckRegistry.discover(CHECKS_DIR)
            by_name = {cls.name: cls for cls in all_classes}
        except Exception:
            by_name = {}

        # Walk all scans for failure-count history
        scans = list_scans(limit=999)
        fail_count: dict[str, int] = defaultdict(int)
        for s in scans:
            full = get_scan(s["id"])
            if not full:
                continue
            for r in (full.get("results") or []):
                if (r.get("status") or "").upper() == "FAIL":
                    fail_count[r.get("check_name", "")] += 1

        # Helper to extract plain-English text from "SIMPLE: ... | TECH: ..." blobs
        def _simple(s: str) -> str:
            if not s:
                return ""
            if "SIMPLE:" in s and "| TECH:" in s:
                return s.split("SIMPLE:", 1)[1].split("| TECH:", 1)[0].strip()
            if "SIMPLE:" in s:
                return s.split("SIMPLE:", 1)[1].strip()
            return s.strip()

        # Best-effort parse of the remediation command into operator-friendly steps
        def _generate_manual_steps(cmd: str) -> list[dict]:
            if not cmd:
                return []
            text = cmd.strip()
            lower = text.lower()

            # Multi-statement scripts split on `;` so the user gets a step per command
            if ";" in text and len(text) > 80:
                parts = [p.strip() for p in text.split(";") if p.strip()]
                if len(parts) > 1:
                    return [
                        {"label": "Open elevated PowerShell",
                         "detail": "Right-click the Start button and choose 'Windows Terminal (Admin)' or 'PowerShell (Admin)'."},
                    ] + [
                        {"label": f"Run command {i + 1}",
                         "detail": p}
                        for i, p in enumerate(parts)
                    ] + [
                        {"label": "Verify", "detail": "Re-run the WinSecAudit scan to confirm the fix landed."}
                    ]

            if lower.startswith("reg add"):
                # Crude parse: extract the key path between quotes
                key = ""
                if '"' in text:
                    parts = text.split('"')
                    if len(parts) >= 2:
                        key = parts[1]
                # Extract value name and data
                value_name = ""
                value_data = ""
                if "/v " in text:
                    after = text.split("/v ", 1)[1]
                    value_name = after.split(" ", 1)[0]
                if "/d " in text:
                    after = text.split("/d ", 1)[1]
                    value_data = after.split(" ", 1)[0].rstrip("/f").strip()
                return [
                    {"label": "Open Registry Editor",
                     "detail": "Press Win + R, type regedit, and press Enter."},
                    {"label": "Navigate to the key",
                     "detail": f"Go to:  HKEY_{key}" if key else "Use the path indicated in the command above."},
                    {"label": f"Modify {value_name or 'the value'}",
                     "detail": f"Right-click in the right pane, choose New > DWORD (32-bit) Value, name it {value_name or '...'} and set the value to {value_data or '...'}."},
                    {"label": "Apply Changes",
                     "detail": "Close the editor and restart the system if required for the change to take effect."},
                ]
            if "set-itemproperty" in lower or "set-mppreference" in lower or lower.startswith("set-"):
                return [
                    {"label": "Open elevated PowerShell",
                     "detail": "Right-click the Start button and choose 'Windows Terminal (Admin)'."},
                    {"label": "Run the command",
                     "detail": text},
                    {"label": "Verify",
                     "detail": "Re-run the WinSecAudit scan to confirm the fix landed."},
                ]
            if "netsh" in lower:
                return [
                    {"label": "Open elevated Command Prompt",
                     "detail": "Press Win + X and choose 'Terminal (Admin)' or 'Command Prompt (Admin)'."},
                    {"label": "Run the netsh command",
                     "detail": text},
                    {"label": "Verify",
                     "detail": "Run `netsh advfirewall show allprofiles` to confirm — or re-scan."},
                ]
            if "stop-service" in lower or "set-service" in lower:
                return [
                    {"label": "Open Services console",
                     "detail": "Press Win + R, type services.msc, press Enter."},
                    {"label": "Find the service",
                     "detail": "Look up the service named in the command above."},
                    {"label": "Stop and disable",
                     "detail": "Right-click → Stop. Then right-click → Properties → Startup type: Disabled → OK."},
                    {"label": "Verify",
                     "detail": "Re-run the WinSecAudit scan."},
                ]
            if "disable-windowsoptionalfeature" in lower:
                return [
                    {"label": "Open Windows Features",
                     "detail": "Press Win + R, type optionalfeatures, press Enter."},
                    {"label": "Disable the feature",
                     "detail": "Find the feature named in the command above, untick the checkbox, click OK."},
                    {"label": "Restart the machine",
                     "detail": "Windows will prompt to reboot — confirm to apply the change."},
                ]
            # Generic fallback
            return [
                {"label": "Open elevated terminal",
                 "detail": "PowerShell or Command Prompt as Administrator."},
                {"label": "Run the command",
                 "detail": text},
                {"label": "Verify",
                 "detail": "Re-run the WinSecAudit scan to confirm the fix landed."},
            ]

        # Build the items list — every remediable check, regardless of current
        # status (the user wants visibility into what they can fix preemptively).
        latest_results = latest.get("results") or []
        seen: dict[str, dict] = {}
        for r in latest_results:
            if not r.get("remediation_supported"):
                continue
            name = r.get("check_name") or ""
            if not name or name in seen:
                continue
            seen[name] = r

        items = []
        for idx, (name, r) in enumerate(sorted(seen.items()), start=1):
            cls = by_name.get(name)
            risk    = _simple(getattr(cls, "risk_summary", "")) if cls else ""
            fix_exp = _simple(getattr(cls, "fix_steps",   "")) if cls else ""
            cmd     = r.get("remediation_cmd", "") or ""
            sev     = (r.get("severity") or "").upper()
            warnings = []
            if "reg " in cmd.lower() or "set-itemproperty" in cmd.lower():
                warnings.append("This script modifies system registry settings.")
            if "netsh" in cmd.lower():
                warnings.append("Network configuration will be modified.")
            if any(t in cmd.lower() for t in ("set-service", "stop-service", "disable-")):
                warnings.append("A service or feature will be stopped or disabled.")

            items.append({
                "check_id":         f"CHK-{idx:03d}",
                "check_name":       name,
                "category":         r.get("category"),
                "severity":         sev,
                "cve_ids":          r.get("cve_ids") or [],
                "mitre_technique":  r.get("mitre_technique"),
                "current_status":   (r.get("status") or "").upper(),
                "failure_count":    fail_count.get(name, 0),
                "scans_analysed":   len(scans),
                "why_matters":      risk,
                "fix_explanation":  fix_exp,
                "automated": {
                    "command":      cmd,
                    "shell":        "powershell" if any(s in cmd for s in ("Set-", "Get-", "$")) else "cmd",
                    "warnings":     warnings,
                    "needs_admin":  True,
                },
                "manual_steps":     _generate_manual_steps(cmd),
            })

        # Sort by severity DESC, then by check name
        sev_rank = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}
        items.sort(key=lambda it: (sev_rank.get(it["severity"], 9), it["check_name"]))

        # Hero counters
        summary = {"critical": 0, "high": 0, "medium": 0, "low": 0}
        for it in items:
            k = it["severity"].lower()
            if k in summary: summary[k] += 1
        summary["total"] = len(items)

        return {
            "items":            items,
            "summary":          summary,
            "scans_available":  len(scans),
            "latest_scan_id":   latest.get("id"),
        }
    except Exception as exc:
        logger.exception("remediation_detailed() failed")
        raise HTTPException(status_code=500, detail={"error": str(exc)})


@app.get("/api/v1/threat-intel")
def threat_intel_full() -> dict:
    """
    Full threat-intelligence aggregate for the Threat Intel page.

    Sources are ALL real:
      - cve_map.json   (NVD CVSS + FIRST EPSS + CISA KEV enrichment cache)
      - cisa_kev_cache.json (CISA KEV catalogue, ~1500 entries)
      - SQLite scan history (every cve_id seen across all scans)

    Output:
      - summary  (4 hero metrics: KEV exposure, high-EPSS, CVEs in failures, total)
      - sparkline series for each summary card (per-scan history)
      - epss_distribution (CVE counts by EPSS band)
      - severity_distribution (CVE counts by CVSS severity)
      - kev_trend  (per-day "added"/"resolved" timeline based on env presence)
      - cve_catalogue (full CVE list with CVSS/EPSS/KEV/affected-checks/first/last seen)
    """
    try:
        from collections import defaultdict
        from datetime import date, timedelta
        from db.database import get_scan, list_scans

        cve_cache = _load_cve_cache()  # already returns only enriched dict entries

        # ── Walk all scans to build per-CVE first/last-seen + affected-checks ──
        scans = list_scans(limit=999)
        cve_stats: dict[str, dict] = {}
        latest_scan_id = scans[0]["id"] if scans else None
        latest_scan = get_scan(latest_scan_id) if latest_scan_id else None

        # also build per-scan TI metrics for sparklines (real history)
        per_scan_ti = []
        for s in scans:
            full = get_scan(s["id"])
            if not full:
                continue
            cves_in_scan: set[str] = set()
            cves_in_failures: set[str] = set()
            for r in (full.get("results") or []):
                for cve in (r.get("cve_ids") or []):
                    if not cve:
                        continue
                    cves_in_scan.add(cve)
                    sev = (r.get("severity") or "").upper()
                    if (r.get("status") or "").upper() == "FAIL" and sev in ("CRITICAL", "HIGH"):
                        cves_in_failures.add(cve)
                    # Update per-CVE first/last seen
                    st = cve_stats.setdefault(cve, {
                        "first_seen": s["timestamp"], "last_seen": s["timestamp"],
                        "affected_checks": set(),
                    })
                    st["affected_checks"].add(r.get("check_name", ""))
                    if (s["timestamp"] or "") < (st["first_seen"] or ""):
                        st["first_seen"] = s["timestamp"]
                    if (s["timestamp"] or "") > (st["last_seen"]  or ""):
                        st["last_seen"]  = s["timestamp"]

            # Compute per-scan TI metric snapshot
            kev_count_scan  = sum(1 for c in cves_in_scan if cve_cache.get(c, {}).get("in_cisa_kev"))
            high_epss_scan  = sum(1 for c in cves_in_scan if (cve_cache.get(c, {}).get("epss_score") or 0) >= 0.5)
            per_scan_ti.append({
                "ts":               s["timestamp"],
                "scan_id":          s["id"],
                "kev_exposure":     kev_count_scan,
                "high_epss":        high_epss_scan,
                "cves_in_failures": len(cves_in_failures),
                "total_cves":       len(cves_in_scan),
            })

        # Reverse so the sparklines render chronologically
        per_scan_ti.reverse()
        # Trim to last 20 for readable sparklines
        per_scan_ti = per_scan_ti[-20:]

        # ── Build CVE catalogue from intersection of cache + observed CVEs ──
        observed_cves = set(cve_stats.keys())
        # Always include cache entries even if not yet observed (so panel shows the cache)
        for cve_id in cve_cache.keys():
            cve_stats.setdefault(cve_id, {
                "first_seen": None, "last_seen": None, "affected_checks": set(),
            })

        cve_list = []
        for cve_id, stat in cve_stats.items():
            meta = cve_cache.get(cve_id) or {}
            cve_list.append({
                "cve_id":               cve_id,
                "cvss_score":           meta.get("cvss_score"),
                "cvss_severity":        (meta.get("cvss_severity") or "UNKNOWN").upper(),
                "epss_score":           meta.get("epss_score"),
                "epss_percentile":      meta.get("epss_percentile"),
                "in_cisa_kev":          bool(meta.get("in_cisa_kev")),
                "kev_date_added":       meta.get("kev_date_added"),
                "kev_ransomware_use":   meta.get("kev_ransomware_use"),
                "description":          meta.get("description"),
                "published_date":       meta.get("published_date"),
                "first_seen":           stat["first_seen"],
                "last_seen":            stat["last_seen"],
                "affected_checks_count": len(stat["affected_checks"]),
                "affected_checks":      sorted(filter(None, stat["affected_checks"]))[:10],
                "observed":             cve_id in observed_cves,
            })

        # Sort by EPSS desc, then CVSS desc — most-exploitable first
        cve_list.sort(key=lambda c: (-(c["epss_score"] or 0), -(c["cvss_score"] or 0)))

        # ── Hero metric summary (latest scan's posture) ──
        latest_per = per_scan_ti[-1] if per_scan_ti else None
        summary = {
            "total_cves":       len(observed_cves),
            "kev_exposure":     latest_per["kev_exposure"]     if latest_per else 0,
            "high_epss_cves":   latest_per["high_epss"]        if latest_per else 0,
            "cves_in_failures": latest_per["cves_in_failures"] if latest_per else 0,
        }

        # ── EPSS distribution ──
        epss_bands = {"critical": 0, "high": 0, "medium": 0, "low": 0}
        for c in cve_list:
            e = (c["epss_score"] or 0) * 100  # 0..100
            if   e >= 90: epss_bands["critical"] += 1
            elif e >= 70: epss_bands["high"]     += 1
            elif e >= 30: epss_bands["medium"]   += 1
            else:         epss_bands["low"]      += 1

        # ── Severity distribution ──
        sev_dist = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0, "UNKNOWN": 0}
        for c in cve_list:
            s = (c["cvss_severity"] or "UNKNOWN").upper()
            sev_dist[s if s in sev_dist else "UNKNOWN"] += 1

        # ── KEV trend over time (per-day add/resolve in *our* environment) ──
        # Add  = KEV CVE first seen in our scans on that day
        # Resolve = KEV CVE last seen on a date earlier than the latest scan,
        #           AND it's no longer present in the latest scan
        # Build a 30-day window ending today.
        kev_added_by_day  : dict[str, int] = defaultdict(int)
        kev_resolved_by_day: dict[str, int] = defaultdict(int)
        latest_cves = set()
        if latest_scan:
            for r in (latest_scan.get("results") or []):
                for cve in (r.get("cve_ids") or []):
                    if cve: latest_cves.add(cve)
        for cve_id, stat in cve_stats.items():
            if not cve_cache.get(cve_id, {}).get("in_cisa_kev"):
                continue
            fs = (stat["first_seen"] or "")[:10]
            ls = (stat["last_seen"]  or "")[:10]
            if fs:
                kev_added_by_day[fs] += 1
            if ls and cve_id not in latest_cves:
                kev_resolved_by_day[ls] += 1

        # Construct daily timeline for last 30 days containing scans
        all_days: set[str] = set()
        for s in scans:
            d = (s.get("timestamp") or "")[:10]
            if d: all_days.add(d)
        timeline = sorted(all_days)[-30:]
        kev_trend = {
            "dates":     timeline,
            "added":     [kev_added_by_day.get(d, 0)   for d in timeline],
            "resolved":  [kev_resolved_by_day.get(d, 0) for d in timeline],
        }

        return {
            "summary":               summary,
            "sparklines": {
                "kev_exposure":      [p["kev_exposure"]     for p in per_scan_ti],
                "high_epss":         [p["high_epss"]        for p in per_scan_ti],
                "cves_in_failures":  [p["cves_in_failures"] for p in per_scan_ti],
                "total_cves":        [p["total_cves"]       for p in per_scan_ti],
                "scan_ids":          [p["scan_id"]          for p in per_scan_ti],
                "timestamps":        [p["ts"]               for p in per_scan_ti],
            },
            "epss_distribution":     epss_bands,
            "severity_distribution": sev_dist,
            "kev_trend":             kev_trend,
            "cve_catalogue":         cve_list,
            "scans_available":       len(scans),
        }
    except Exception as exc:
        logger.exception("threat_intel_full() failed")
        raise HTTPException(status_code=500, detail={"error": str(exc)})


@app.get("/api/v1/drift-history")
def drift_history(limit: int = Query(10, ge=2, le=30)) -> dict:
    """
    Real per-scan-pair drift history for the dashboard sparklines.

    Returns four parallel arrays (degraded / improved / changed / new) plus
    metadata about each scan-pair, in chronological order.  Driven entirely
    by `get_drift()` over consecutive scans in the database.
    """
    try:
        from db.database import get_drift, list_scans
        # Need limit+1 scans to form `limit` consecutive pairs
        recent = list_scans(limit=limit + 1)
        if len(recent) < 2:
            return {
                "pairs":  [],
                "series": {"degraded": [], "improved": [], "changed": [], "new": [], "score_delta": []},
                "scans_available": len(recent),
            }
        # list_scans returns DESC (newest first); walk backwards to build chronological pairs
        pairs = []
        deg, imp, chg, new, sd = [], [], [], [], []
        for i in range(len(recent) - 1):
            newer = recent[i]
            older = recent[i + 1]
            d = get_drift(older["id"], newer["id"])
            pairs.append({
                "older_id":   older["id"],
                "newer_id":   newer["id"],
                "older_ts":   older["timestamp"],
                "newer_ts":   newer["timestamp"],
                "older_score": older.get("score"),
                "newer_score": newer.get("score"),
                "score_delta": d.get("score_delta"),
            })
            deg.append(len(d.get("regressions", [])))
            imp.append(len(d.get("improvements", [])))
            chg.append(d.get("stable_fail", 0))
            new.append(len(d.get("new_checks", [])))
            sd.append(float(d.get("score_delta") or 0.0))
        # Reverse to chronological (oldest pair first)
        pairs.reverse()
        return {
            "pairs":           pairs,
            "series": {
                "degraded":    list(reversed(deg)),
                "improved":    list(reversed(imp)),
                "changed":     list(reversed(chg)),
                "new":         list(reversed(new)),
                "score_delta": list(reversed(sd)),
            },
            "scans_available": len(recent),
        }
    except Exception as exc:
        logger.exception("drift_history() failed")
        raise HTTPException(status_code=500, detail={"error": str(exc)})


@app.get("/api/v1/posture-stats")
def posture_stats() -> dict:
    """
    Aggregated counts the new dashboard hero-cards need but don't get from
    /overview directly: severity distribution + drift summary numbers.
    """
    try:
        from db.database import get_latest_scan, get_drift, list_scans

        scan = get_latest_scan()
        if not scan:
            return {
                "severity_breakdown": {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0},
                "drift": {"degraded": 0, "changed": 0, "improved": 0, "new": 0},
                "trend":  [],
            }

        sev = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0}
        for r in (scan.get("results") or []):
            if (r.get("status") or "").upper() != "FAIL":
                continue
            s = (r.get("severity") or "").upper()
            if s in sev:
                sev[s] += 1

        # Drift between the two most recent scans, if available
        drift = {"degraded": 0, "changed": 0, "improved": 0, "new": 0}
        scans = list_scans(limit=2)
        if len(scans) >= 2:
            d = get_drift(scans[1]["id"], scans[0]["id"])
            drift = {
                "degraded": len(d.get("regressions", [])),
                "changed":  d.get("stable_fail", 0),
                "improved": len(d.get("improvements", [])),
                "new":      len(d.get("new_checks", [])),
            }

        # Recent score history (last 10 in chronological order)
        recent = list_scans(limit=10)
        trend = [
            {"score": float(s.get("score") or 0.0),
             "grade": s.get("grade", ""),
             "ts":    s.get("timestamp", "")}
            for s in reversed(recent)
        ]

        return {
            "severity_breakdown": sev,
            "drift":              drift,
            "trend":              trend,
        }

    except Exception as exc:
        logger.exception("posture_stats() failed")
        raise HTTPException(status_code=500, detail={"error": str(exc)})


@app.get("/api/v1/health")
def health() -> dict:
    """Liveness check — returns DB path, scan count, engine version, host info."""
    try:
        from db.database import list_scans, _DB_PATH, get_latest_scan
        scan_count = len(list_scans(limit=9999))
        # Engine version pulled from the installed package metadata.  Falls back
        # to a sensible string if the metadata isn't reachable (eg. dev tree).
        try:
            from importlib.metadata import version as _pkg_version
            engine_version = _pkg_version("winsecaudit")
        except Exception:
            engine_version = "dev"
        # Surface the OS / hostname of the latest scan.  Cheap because get_latest_scan
        # already fetches the freshest row.
        latest = get_latest_scan()
        os_version = (latest or {}).get("os_version") or ""
        hostname   = (latest or {}).get("machine_id")  or ""
        return {
            "status":         "ok",
            "db_path":        str(_DB_PATH),
            "scan_count":     scan_count,
            "engine_version": engine_version,
            "os_version":     os_version,
            "hostname":       hostname,
        }
    except Exception as exc:
        logger.exception("health() failed")
        raise HTTPException(status_code=500, detail={"error": str(exc)})


@app.get("/api/v1/system-info")
def system_info() -> dict:
    """
    Operational-transparency endpoint surfaced in the dashboard footer.
    Reports real engine / DB / enrichment-cache state — never fabricated.
    """
    import os as _os, time as _time2
    try:
        from db.database import list_scans, _DB_PATH, get_latest_scan
        from winsecaudit_paths import CVE_CACHE_PATH, KEV_CACHE_PATH

        try:
            from importlib.metadata import version as _pkg_version
            engine_version = _pkg_version("winsecaudit")
        except Exception:
            engine_version = "dev"

        scan_count = len(list_scans(limit=9999))
        latest = get_latest_scan()

        # File mtime → human-readable freshness for each enrichment cache
        def _stat(path):
            try:
                if path.exists():
                    return {
                        "exists":       True,
                        "size_bytes":   path.stat().st_size,
                        "mtime":        path.stat().st_mtime,
                        "age_seconds":  _time2.time() - path.stat().st_mtime,
                    }
            except Exception:
                pass
            return {"exists": False, "size_bytes": 0, "mtime": None, "age_seconds": None}

        cve_stat = _stat(CVE_CACHE_PATH)
        kev_stat = _stat(KEV_CACHE_PATH)

        # DB file size & mtime
        db_path = _DB_PATH
        db_size = db_path.stat().st_size if db_path.exists() else 0

        # Active scan state
        with _scan_lock:
            scan_running = _scan_state["status"] == "running"
            current_job  = dict(_scan_state) if scan_running else None

        return {
            "engine_version": engine_version,
            "db": {
                "path":        str(db_path),
                "size_bytes":  db_size,
                "scan_count":  scan_count,
                "wal_mode":    True,
            },
            "host": {
                "hostname":   (latest or {}).get("machine_id"),
                "os_version": (latest or {}).get("os_version"),
                "last_scan":  (latest or {}).get("timestamp"),
            },
            "enrichment": {
                "nvd": {
                    "cache_exists":  cve_stat["exists"],
                    "cache_size":    cve_stat["size_bytes"],
                    "cache_age_sec": cve_stat["age_seconds"],
                },
                "epss": {
                    # EPSS data lives in the same cve_map.json — share the file mtime
                    "cache_exists":  cve_stat["exists"],
                    "cache_age_sec": cve_stat["age_seconds"],
                },
                "kev": {
                    "cache_exists":  kev_stat["exists"],
                    "cache_size":    kev_stat["size_bytes"],
                    "cache_age_sec": kev_stat["age_seconds"],
                },
            },
            "scan_engine": {
                "status":      "running" if scan_running else "idle",
                "current_job": current_job,
            },
            "binding": {
                "host": "127.0.0.1",
                "port": 8080,
                "remote_access": False,
            },
        }
    except Exception as exc:
        logger.exception("system_info() failed")
        raise HTTPException(status_code=500, detail={"error": str(exc)})


# ---------------------------------------------------------------------------
# Live-scan execution & progress tracking
#
# The previous implementation forked `winsecaudit scan` as a subprocess and
# returned only the final result.  That gave the dashboard a 22-second blank
# wait with no insight.  This in-process version:
#
#   - Runs the scan in a background thread inside the dashboard process
#   - Updates a thread-safe `_scan_state` dict from a runner progress callback
#   - Exposes `/api/v1/scan/status` so the frontend can poll for live updates
#   - Exposes `/api/v1/scan` (POST) which now returns immediately with a job ID
#
# Thread safety: SQLite is opened with `check_same_thread=False` and uses WAL
# journalling, so the background thread can save while the main thread serves
# read queries.  A module-level lock guards `_scan_state` mutation.
# ---------------------------------------------------------------------------

import threading as _threading
import time as _time
import uuid as _uuid

_scan_lock  = _threading.Lock()
_scan_state: dict = {
    "status":           "idle",   # idle | running | completed | failed
    "job_id":           None,
    "started_at":       None,
    "finished_at":      None,
    "elapsed":          0.0,
    "profile":          None,
    "threat_intel":     False,
    "current_index":    0,
    "total_checks":     0,
    "current_check":    None,
    "current_category": None,
    "counts": {"PASS": 0, "FAIL": 0, "ERROR": 0, "SKIPPED": 0},
    "scan_id":          None,
    "error":            None,
}


def _reset_scan_state(profile: str, threat_intel: bool) -> str:
    job_id = _uuid.uuid4().hex[:12]
    with _scan_lock:
        _scan_state.update({
            "status":           "running",
            "job_id":           job_id,
            "started_at":       _time.time(),
            "finished_at":      None,
            "elapsed":          0.0,
            "profile":          profile,
            "threat_intel":     threat_intel,
            "current_index":    0,
            "total_checks":     0,
            "current_check":    None,
            "current_category": None,
            "counts":           {"PASS": 0, "FAIL": 0, "ERROR": 0, "SKIPPED": 0},
            "scan_id":          None,
            "error":            None,
        })
    return job_id


def _execute_scan(profile_name: str, threat_intel: bool, job_id: str) -> None:
    """
    Background-thread entry point. Reproduces the CLI scan command in-process,
    updating `_scan_state` after each check via the runner's progress callback.
    """
    import socket as _socket
    from datetime import datetime as _dt, timezone as _tz
    try:
        from db.database import init_db, save_scan
        from engine.comparator import apply_profile, load_profile
        from engine.risk import build_scan_summary, results_to_db_rows
        from engine.runner import run_all_checks
        from engine.scorer import calculate_score
        from checks.base import CheckRegistry
        from cli.main import CHECKS_DIR, PROFILES_DIR

        init_db()
        profile_data = load_profile(profile_name, PROFILES_DIR)

        all_classes = CheckRegistry.discover(CHECKS_DIR)
        check_meta  = {c.name: c for c in all_classes}
        total       = len(all_classes)
        with _scan_lock:
            _scan_state["total_checks"] = total

        # Per-check progress callback: invoked AFTER each check completes
        # We have to peek at the partial results list to update PASS/FAIL counters,
        # so wrap run_all_checks in a closure-style accumulator below.
        partial_results: list = []

        def progress_cb(check_name: str, current: int, total: int) -> None:
            # The result for the just-completed check is the last entry the
            # runner appended.  Read its status to update counters.
            result_status = None
            if partial_results:
                result_status = (partial_results[-1].status.value
                                 if hasattr(partial_results[-1].status, "value")
                                 else str(partial_results[-1].status))
            cls = check_meta.get(check_name)
            with _scan_lock:
                _scan_state["current_index"]    = current
                _scan_state["current_check"]    = check_name
                _scan_state["current_category"] = cls.category if cls else None
                _scan_state["elapsed"] = _time.time() - (_scan_state["started_at"] or _time.time())
                if result_status and result_status in _scan_state["counts"]:
                    _scan_state["counts"][result_status] += 1

        # Monkey-wrap run_all_checks to expose partial_results to the callback.
        # We do this by re-implementing the small loop here so the callback can
        # see each result as soon as it lands.
        import dataclasses
        from checks.base import CheckResult, CheckStatus
        weight_overrides = profile_data.get("weight_overrides") or {}
        scan_start = _time.monotonic()
        for cls in all_classes:
            instance = cls()
            try:
                r = instance.run()
            except Exception as exc:
                logger.error("Unhandled exception in check '%s': %s", cls.name, exc)
                r = CheckResult(
                    check_name=cls.name, category=cls.category,
                    status=CheckStatus.ERROR,
                    system_value=None, expected_value=None,
                    severity=cls.severity, weight=cls.weight,
                    cve_ids=list(cls.cve_ids),
                    mitre_technique=cls.mitre_technique, cis_id=cls.cis_id,
                    remediation_cmd=cls.remediation_cmd,
                    remediation_supported=cls.remediation_supported,
                    error_message=f"Unhandled exception: {exc}",
                )
            if cls.name in weight_overrides:
                ow = int(weight_overrides[cls.name])
                if ow != r.weight:
                    r = dataclasses.replace(r, weight=ow)
            partial_results.append(r)
            progress_cb(cls.name, len(partial_results), total)
        duration = _time.monotonic() - scan_start
        raw_results = partial_results

        # Apply profile relaxations
        adjusted = apply_profile(raw_results, profile_data)

        # Optional TI enrichment
        if threat_intel:
            try:
                from engine.threat_intel import enrich_results
                with _scan_lock:
                    _scan_state["current_check"] = "Enriching CVEs (NVD / EPSS / CISA KEV)…"
                enrich_results(adjusted)
            except Exception as exc:
                logger.warning("TI enrichment failed: %s", exc)

        # Score and save
        score_data    = calculate_score(adjusted)
        timestamp_tag = _dt.now(_tz.utc).replace(tzinfo=None).strftime("%Y%m%d_%H%M%S")
        hostname      = _socket.gethostname()
        scan_id       = f"scan_{hostname}_{timestamp_tag}"
        scan_summary  = build_scan_summary(adjusted, score_data, profile_name, scan_id, duration)
        db_rows       = results_to_db_rows(adjusted, scan_id)
        save_scan(scan_summary, db_rows)

        with _scan_lock:
            _scan_state.update({
                "status":      "completed",
                "scan_id":     scan_id,
                "finished_at": _time.time(),
                "elapsed":     duration,
            })

    except Exception as exc:
        logger.exception("background scan failed")
        with _scan_lock:
            _scan_state.update({
                "status":      "failed",
                "error":       str(exc),
                "finished_at": _time.time(),
            })


@app.get("/api/v1/scan/status")
def scan_status() -> dict:
    """
    Live snapshot of the currently-running scan (or the last completed one).
    Frontend polls this every ~500 ms while a scan is active.
    """
    with _scan_lock:
        snap = dict(_scan_state)
    # Recompute elapsed for live display when running
    if snap["status"] == "running" and snap.get("started_at"):
        snap["elapsed"] = _time.time() - snap["started_at"]
    return snap


# ---------------------------------------------------------------------------
# POST /api/v1/scan — trigger a new scan from the dashboard's "Scan Now" button
# ---------------------------------------------------------------------------

@app.post("/api/v1/scan")
async def trigger_scan(
    profile:     str  = Query("basic", description="Profile name (basic | hardened)"),
    threat_intel: bool = Query(False, description="Enable NVD / EPSS / KEV enrichment"),
) -> dict:
    """
    Run a new audit scan on the local machine in a child process.

    Behaviour:
      - Forks `winsecaudit scan` (the same code path the CLI uses).
      - Returns once the scan completes (typically 8-15 seconds).
      - Returns 200 with the new scan id on success, 5xx on failure.
      - Heads-up: this endpoint is single-tenant by design (the dashboard
        binds to 127.0.0.1 only). It must remain non-public.
    """
    # If a scan is already running, refuse to start another (one at a time).
    with _scan_lock:
        if _scan_state["status"] == "running":
            raise HTTPException(
                status_code=409,
                detail={"error": "A scan is already in progress",
                        "job_id": _scan_state.get("job_id")},
            )

    job_id = _reset_scan_state(profile, threat_intel)
    t = _threading.Thread(
        target=_execute_scan,
        args=(profile, threat_intel, job_id),
        name=f"winsecaudit-scan-{job_id}",
        daemon=True,
    )
    t.start()
    return {
        "status": "started",
        "job_id": job_id,
        "profile": profile,
        "threat_intel": threat_intel,
        "poll_url": "/api/v1/scan/status",
    }


# ---------------------------------------------------------------------------
# Static files — mounted LAST so /api/* routes always take priority
#
# Custom subclass that sets Cache-Control headers so users *never* see a stale
# dashboard UI after upgrading the pip package.  Without this, every browser
# aggressively caches index.html and ignores newer JS/CSS until the user does
# a hard refresh — which broke the worldwide upgrade story for v1.x.
#
# Strategy:
#   - HTML responses (index.html etc.):  no-cache + must-revalidate
#       Forces the browser to round-trip to the server on every navigation.
#       Combined with the auto-generated ETag this is cheap (304 on no change).
#   - Other static (CSS/JS/images):      no-cache as well — same reason
#
# This is the right call for a single-tenant local dashboard where the network
# round-trip is sub-millisecond.  No latency cost; full freshness guarantee.
# ---------------------------------------------------------------------------

class _NoCacheStaticFiles(StaticFiles):
    """StaticFiles subclass that disables browser caching for the dashboard."""

    async def get_response(self, path: str, scope):
        response = await super().get_response(path, scope)
        # Force revalidation on every request; ETag still allows 304 fast-paths
        response.headers["Cache-Control"] = "no-cache, must-revalidate, max-age=0"
        response.headers["Pragma"]        = "no-cache"
        response.headers["Expires"]       = "0"
        return response


if _STATIC_DIR.exists():
    app.mount("/", _NoCacheStaticFiles(directory=str(_STATIC_DIR), html=True),
              name="static")
