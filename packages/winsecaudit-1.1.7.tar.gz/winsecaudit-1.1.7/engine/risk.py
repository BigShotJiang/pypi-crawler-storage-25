"""
engine/risk.py — risk grading, priority ranking, and scan serialization.

All grade thresholds live exclusively in this module.
To add a new grade tier (e.g. "A+" for scores >= 95), add an entry to
_GRADE_THRESHOLDS and nothing else needs to change elsewhere.
"""
from __future__ import annotations

import json
import logging
import socket
from datetime import datetime, timezone

from checks.base import CheckResult, CheckStatus, Severity

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Grade thresholds — sorted descending so the first match wins.
# To add "A+": insert (95.0, "A+") before the (90.0, "A") entry.
# ---------------------------------------------------------------------------
_GRADE_THRESHOLDS: list[tuple[float, str]] = [
    (90.0, "A"),
    (75.0, "B"),
    (60.0, "C"),
    (40.0, "D"),
    (0.0,  "F"),
]

# Severity ordering for priority sort — lower index = higher priority
_SEVERITY_ORDER: dict[str, int] = {
    Severity.CRITICAL.value: 0,
    Severity.HIGH.value:     1,
    Severity.MEDIUM.value:   2,
    Severity.LOW.value:      3,
}


def assign_grade(score: float) -> str:
    """
    Convert a numeric score (0.0–100.0) to a letter grade.

    Thresholds (inclusive lower bound):
      90–100 → A
      75–89  → B
      60–74  → C
      40–59  → D
       0–39  → F
    """
    for threshold, grade in _GRADE_THRESHOLDS:
        if score >= threshold:
            return grade
    return "F"


def get_priority_failures(
    results: list[CheckResult],
    max_items: int = 5,
) -> list[CheckResult]:
    """
    Return the top *max_items* failing checks ordered by:
      1. Severity (CRITICAL → HIGH → MEDIUM → LOW)
      2. Weight descending within the same severity tier

    Only FAIL status results are included.
    """
    failures = [r for r in results if r.status == CheckStatus.FAIL]
    failures.sort(
        key=lambda r: (
            _SEVERITY_ORDER.get(r.severity.value, 99),
            -r.weight,
        )
    )
    return failures[:max_items]


def build_scan_summary(
    results: list[CheckResult],
    score_data: dict,
    profile_name: str,
    scan_id: str,
    duration_seconds: float,
) -> dict:
    """
    Assemble the scan metadata dict ready for db.database.save_scan().
    Uses socket.gethostname() as machine_id.
    """
    return {
        "id":               scan_id,
        "machine_id":       socket.gethostname(),
        "timestamp":        datetime.now(timezone.utc).replace(tzinfo=None).isoformat(),
        "profile":          profile_name,
        "score":            score_data["score"],
        "grade":            assign_grade(score_data["score"]),
        "total_checks":     score_data["total_checks"],
        "passed_checks":    score_data["passed_checks"],
        "failed_checks":    score_data["failed_checks"],
        "error_checks":     score_data["error_checks"],
        "skipped_checks":   score_data["skipped_checks"],
        "duration_seconds": duration_seconds,
    }


def results_to_db_rows(results: list[CheckResult], scan_id: str) -> list[dict]:
    """
    Convert a list of CheckResult objects into dicts suitable for
    db.database.save_scan()'s *results* parameter.

    Serialization rules:
      - system_value / expected_value → json.dumps()
      - cve_ids (tuple)               → json.dumps(list(...))
      - status                        → CheckStatus.name  ("PASS", "FAIL", …)
      - severity                      → Severity.name     ("CRITICAL", "HIGH", …)
      - remediation_supported         → int(bool)
    """
    rows: list[dict] = []
    for r in results:
        try:
            system_val   = json.dumps(r.system_value)
            expected_val = json.dumps(r.expected_value)
        except (TypeError, ValueError):
            # Fallback: stringify anything that isn't JSON-serialisable
            system_val   = json.dumps(str(r.system_value))
            expected_val = json.dumps(str(r.expected_value))

        rows.append({
            "scan_id":              scan_id,
            "check_name":           r.check_name,
            "category":             r.category,
            "status":               r.status.name,
            "severity":             r.severity.name,
            "weight":               r.weight,
            "system_value":         system_val,
            "expected_value":       expected_val,
            "cve_ids":              json.dumps(list(r.cve_ids)),
            "mitre_technique":      r.mitre_technique,
            "cis_id":               r.cis_id,
            "remediation_cmd":      r.remediation_cmd,
            "remediation_supported": int(r.remediation_supported),
            "error_message":        r.error_message,
        })
    return rows
