"""
SQLAlchemy Core database layer for WinSecAudit v2.

Three tables: machines, scans, results.
All datetime strings are ISO 8601 UTC.  system_value / expected_value /
cve_ids are stored as JSON strings and transparently deserialized on read.

Design decisions:
- SQLAlchemy Core only (no ORM / declarative Base) for portability.
- Single module-level Engine; init_db() must be called before any other
  function — it also fires the WAL + foreign-key pragmas via a connect event.
- WAL journal mode is applied via sqlalchemy.event so it fires on every new
  physical connection regardless of pool churn.
- get_drift() uses two LEFT JOINs + UNION to emulate FULL OUTER JOIN because
  SQLite does not support FULL OUTER JOIN natively.
"""
from __future__ import annotations

import json
import logging
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Generator

from sqlalchemy import (
    Column,
    Float,
    Index,
    Integer,
    MetaData,
    String,
    Table,
    Text,
    create_engine,
    event,
    text,
)
from sqlalchemy.engine import Connection, Engine

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Path resolution — delegates to runtime_paths so installed mode writes to a
# user data dir while dev mode stays repo-relative.
# ---------------------------------------------------------------------------

from winsecaudit_paths import DB_PATH as _DB_PATH  # noqa: E402

# ---------------------------------------------------------------------------
# Module-level engine — created once by init_db()
# ---------------------------------------------------------------------------

_engine: Engine | None = None
_metadata = MetaData()

# ---------------------------------------------------------------------------
# Table definitions (SQLAlchemy Core)
# ---------------------------------------------------------------------------

machines_table = Table(
    "machines",
    _metadata,
    Column("id",         String, primary_key=True),   # hostname
    Column("os_version", String),
    Column("last_seen",  String),                      # ISO 8601
)

scans_table = Table(
    "scans",
    _metadata,
    Column("id",               String,  primary_key=True),
    Column("machine_id",       String,  nullable=False),
    Column("timestamp",        String,  nullable=False),
    Column("profile",          String),
    Column("score",            Float),
    Column("grade",            String),
    Column("total_checks",     Integer),
    Column("passed_checks",    Integer),
    Column("failed_checks",    Integer),
    Column("error_checks",     Integer),
    Column("skipped_checks",   Integer),
    Column("duration_seconds", Float),
)

results_table = Table(
    "results",
    _metadata,
    Column("id",                   Integer, primary_key=True, autoincrement=True),
    Column("scan_id",              String,  nullable=False),
    Column("check_name",           String),
    Column("category",             String),
    Column("status",               String),   # CheckStatus.name
    Column("severity",             String),   # Severity.name
    Column("weight",               Integer),
    Column("system_value",         Text),     # JSON string
    Column("expected_value",       Text),     # JSON string
    Column("cve_ids",              Text),     # JSON string
    Column("mitre_technique",      String),
    Column("cis_id",               String),
    Column("remediation_cmd",      Text),
    Column("remediation_supported", Integer), # 0/1
    Column("error_message",        Text),     # NULL when no error
)

# Indexes — defined here so create_all() picks them up automatically
Index("idx_scans_machine_id",   scans_table.c.machine_id)
Index("idx_scans_timestamp",    scans_table.c.timestamp)
Index("idx_results_scan_id",    results_table.c.scan_id)
Index("idx_results_check_name", results_table.c.check_name)
Index("idx_results_status",     results_table.c.status)

# ---------------------------------------------------------------------------
# Per-connection pragmas
# ---------------------------------------------------------------------------

def _configure_connection(dbapi_conn: Any, _connection_record: Any) -> None:
    """Fire SQLite pragmas on every new physical connection."""
    cursor = dbapi_conn.cursor()
    cursor.execute("PRAGMA journal_mode=WAL")
    cursor.execute("PRAGMA foreign_keys=ON")
    cursor.close()

# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def init_db() -> None:
    """
    Create tables and indexes if they do not exist.
    Safe to call multiple times.  Must be called before any other db function.
    """
    global _engine

    _DB_PATH.parent.mkdir(parents=True, exist_ok=True)

    _engine = create_engine(
        f"sqlite:///{_DB_PATH}",
        connect_args={"check_same_thread": False},
        # StaticPool is not used; SQLite file-based DBs handle their own locking.
    )
    event.listen(_engine, "connect", _configure_connection)

    _metadata.create_all(_engine)
    logger.info("Database initialised at %s", _DB_PATH)


@contextmanager
def _get_conn() -> Generator[Connection, None, None]:
    """Yield a transactional connection; roll back on exception."""
    if _engine is None:
        raise RuntimeError("init_db() must be called before any database operation.")
    with _engine.begin() as conn:
        yield conn


# ---------------------------------------------------------------------------
# Serialization helpers
# ---------------------------------------------------------------------------

def _serialize(value: Any) -> str:
    """JSON-encode a Python value for storage."""
    try:
        return json.dumps(value)
    except (TypeError, ValueError):
        return json.dumps(str(value))


def _deserialize(value: str | None) -> Any:
    """JSON-decode a stored string; return the raw string on parse failure."""
    if value is None:
        return None
    try:
        return json.loads(value)
    except (json.JSONDecodeError, TypeError):
        return value


def _deserialize_result(row: Any) -> dict:
    """Convert a results row (mapping) to a plain dict with decoded JSON fields."""
    d = dict(row._mapping)
    d["system_value"]  = _deserialize(d.get("system_value"))
    d["expected_value"] = _deserialize(d.get("expected_value"))
    d["cve_ids"]        = _deserialize(d.get("cve_ids"))
    d["remediation_supported"] = bool(d.get("remediation_supported", 0))
    return d


def _row_to_scan(row: Any) -> dict:
    """Convert a scans row to a plain dict (no results)."""
    return dict(row._mapping)


# ---------------------------------------------------------------------------
# 1. save_scan
# ---------------------------------------------------------------------------

def save_scan(scan_data: dict, results: list[dict]) -> str:
    """
    Insert one scan and all its results in a single transaction.
    Upserts the machine record (INSERT OR REPLACE).
    Returns the scan_id on success.
    """
    scan_id: str = scan_data["id"]
    try:
        with _get_conn() as conn:
            # Upsert machine record
            conn.execute(
                text(
                    "INSERT OR REPLACE INTO machines (id, os_version, last_seen) "
                    "VALUES (:id, :os_version, :last_seen)"
                ),
                {
                    "id":         scan_data["machine_id"],
                    "os_version": scan_data.get("os_version", ""),
                    "last_seen":  datetime.now(timezone.utc).replace(tzinfo=None).isoformat(),
                },
            )

            # Insert scan row
            conn.execute(scans_table.insert(), scan_data)

            # Insert all result rows
            if results:
                conn.execute(results_table.insert(), results)

    except Exception as exc:
        logger.error("save_scan failed for %s: %s", scan_id, exc)
        raise

    return scan_id


# ---------------------------------------------------------------------------
# 2. get_scan
# ---------------------------------------------------------------------------

def get_scan(scan_id: str) -> dict | None:
    """
    Return the full scan dict including a 'results' list.
    Returns None if scan_id not found.
    """
    try:
        with _get_conn() as conn:
            scan_row = conn.execute(
                scans_table.select().where(scans_table.c.id == scan_id)
            ).fetchone()

            if scan_row is None:
                return None

            result_rows = conn.execute(
                results_table.select().where(results_table.c.scan_id == scan_id)
            ).fetchall()

        scan = _row_to_scan(scan_row)
        scan["results"] = [_deserialize_result(r) for r in result_rows]
        return scan

    except Exception as exc:
        logger.error("get_scan failed for %s: %s", scan_id, exc)
        return None


# ---------------------------------------------------------------------------
# 3. list_scans
# ---------------------------------------------------------------------------

def list_scans(machine_id: str | None = None, limit: int = 20) -> list[dict]:
    """
    Return scan summaries (no results) ordered by timestamp DESC.
    Optionally filtered by machine_id.
    """
    try:
        with _get_conn() as conn:
            q = scans_table.select().order_by(scans_table.c.timestamp.desc()).limit(limit)
            if machine_id is not None:
                q = q.where(scans_table.c.machine_id == machine_id)
            rows = conn.execute(q).fetchall()
        return [_row_to_scan(r) for r in rows]
    except Exception as exc:
        logger.error("list_scans failed: %s", exc)
        return []


# ---------------------------------------------------------------------------
# 4. get_drift
# ---------------------------------------------------------------------------

def get_drift(scan_id_a: str, scan_id_b: str) -> dict:
    """
    Compare two scans via SQL JOIN — no Python-level dict comparison.

    SQLite lacks FULL OUTER JOIN so we use two LEFT JOINs + UNION ALL
    to reconstruct the complete picture:
      • LEFT JOIN a→b  finds checks in A (may or may not exist in B)
      • LEFT JOIN b→a  finds checks in B that are absent in A
    Together they cover all four quadrants (in-both, a-only, b-only).
    """
    base: dict = {
        "scan_a":          scan_id_a,
        "scan_b":          scan_id_b,
        "score_delta":     0.0,
        "regressions":     [],
        "improvements":    [],
        "stable_pass":     0,
        "stable_fail":     0,
        "new_checks":      [],
        "removed_checks":  [],
    }

    try:
        with _get_conn() as conn:
            # Score delta
            scores = conn.execute(
                text(
                    "SELECT s.id, s.score FROM scans s "
                    "WHERE s.id IN (:a, :b)"
                ),
                {"a": scan_id_a, "b": scan_id_b},
            ).fetchall()

            score_map = {row[0]: row[1] for row in scores}
            score_a = score_map.get(scan_id_a, 0.0) or 0.0
            score_b = score_map.get(scan_id_b, 0.0) or 0.0
            base["score_delta"] = round(score_b - score_a, 1)

            # Full outer join via UNION of two left joins
            # Columns: check_name, status_a, status_b
            drift_sql = text("""
                SELECT
                    COALESCE(ra.check_name, rb.check_name) AS check_name,
                    ra.status  AS status_a,
                    rb.status  AS status_b,
                    ra.category,
                    ra.severity,
                    ra.weight
                FROM
                    (SELECT * FROM results WHERE scan_id = :a) ra
                    LEFT JOIN
                    (SELECT * FROM results WHERE scan_id = :b) rb
                    ON ra.check_name = rb.check_name

                UNION ALL

                SELECT
                    COALESCE(ra.check_name, rb.check_name) AS check_name,
                    ra.status  AS status_a,
                    rb.status  AS status_b,
                    rb.category,
                    rb.severity,
                    rb.weight
                FROM
                    (SELECT * FROM results WHERE scan_id = :b) rb
                    LEFT JOIN
                    (SELECT * FROM results WHERE scan_id = :a) ra
                    ON rb.check_name = ra.check_name
                WHERE ra.check_name IS NULL
            """)

            rows = conn.execute(drift_sql, {"a": scan_id_a, "b": scan_id_b}).fetchall()

    except Exception as exc:
        logger.error("get_drift failed (%s vs %s): %s", scan_id_a, scan_id_b, exc)
        return base

    regressions:  list[dict] = []
    improvements: list[dict] = []
    stable_pass  = 0
    stable_fail  = 0
    new_checks:     list[str] = []
    removed_checks: list[str] = []

    for row in rows:
        check_name = row[0]
        status_a   = row[1]
        status_b   = row[2]
        category   = row[3]
        severity   = row[4]
        weight     = row[5]

        entry = {
            "check_name": check_name,
            "category":   category,
            "severity":   severity,
            "weight":     weight,
            "status_a":   status_a,
            "status_b":   status_b,
        }

        if status_a is None:
            # In B but not in A
            new_checks.append(check_name)
        elif status_b is None:
            # In A but not in B
            removed_checks.append(check_name)
        elif status_a == "PASS" and status_b == "FAIL":
            regressions.append(entry)
        elif status_a == "FAIL" and status_b == "PASS":
            improvements.append(entry)
        elif status_a == "PASS" and status_b == "PASS":
            stable_pass += 1
        elif status_a == "FAIL" and status_b == "FAIL":
            stable_fail += 1
        # ERROR/SKIPPED transitions are not counted as regressions or improvements

    base["regressions"]    = regressions
    base["improvements"]   = improvements
    base["stable_pass"]    = stable_pass
    base["stable_fail"]    = stable_fail
    base["new_checks"]     = new_checks
    base["removed_checks"] = removed_checks
    return base


# ---------------------------------------------------------------------------
# 5. get_latest_scan
# ---------------------------------------------------------------------------

def get_latest_scan(machine_id: str | None = None) -> dict | None:
    """
    Return the most recent scan (with results).
    If machine_id is None, returns the most recent scan across all machines.
    """
    try:
        with _get_conn() as conn:
            q = (
                scans_table.select()
                .order_by(scans_table.c.timestamp.desc())
                .limit(1)
            )
            if machine_id is not None:
                q = q.where(scans_table.c.machine_id == machine_id)
            row = conn.execute(q).fetchone()

        if row is None:
            return None

        return get_scan(dict(row._mapping)["id"])

    except Exception as exc:
        logger.error("get_latest_scan failed: %s", exc)
        return None


# ---------------------------------------------------------------------------
# 6. get_check_history
# ---------------------------------------------------------------------------

def get_check_history(
    check_name: str,
    machine_id: str | None = None,
    limit: int = 10,
) -> list[dict]:
    """
    Return the last N results for a specific check across scans,
    ordered by scan timestamp DESC.

    Match strategy: exact match first, falling back to a case-insensitive
    LIKE substring match. So passing "BitLocker" will match the real check
    "BitLocker Enabled on C: Drive". Optionally scoped to a single machine.
    """
    pattern = f"%{check_name}%"
    try:
        with _get_conn() as conn:
            if machine_id is not None:
                sql = text("""
                    SELECT r.*, s.timestamp, s.machine_id
                    FROM results r
                    JOIN scans s ON r.scan_id = s.id
                    WHERE (
                        r.check_name = :exact
                        OR LOWER(r.check_name) LIKE LOWER(:pattern)
                    )
                      AND s.machine_id = :machine_id
                    ORDER BY s.timestamp DESC
                    LIMIT :limit
                """)
                rows = conn.execute(
                    sql,
                    {
                        "exact":      check_name,
                        "pattern":    pattern,
                        "machine_id": machine_id,
                        "limit":      limit,
                    },
                ).fetchall()
            else:
                sql = text("""
                    SELECT r.*, s.timestamp, s.machine_id
                    FROM results r
                    JOIN scans s ON r.scan_id = s.id
                    WHERE r.check_name = :exact
                       OR LOWER(r.check_name) LIKE LOWER(:pattern)
                    ORDER BY s.timestamp DESC
                    LIMIT :limit
                """)
                rows = conn.execute(
                    sql,
                    {"exact": check_name, "pattern": pattern, "limit": limit},
                ).fetchall()

        return [_deserialize_result(r) for r in rows]

    except Exception as exc:
        logger.error("get_check_history failed for '%s': %s", check_name, exc)
        return []


# ---------------------------------------------------------------------------
# 7. delete_scan
# ---------------------------------------------------------------------------

def delete_scan(scan_id: str) -> bool:
    """
    Delete a scan and all its results.
    Returns True if the scan existed and was deleted, False otherwise.
    Results are deleted first to satisfy the FK constraint (no CASCADE in SQLite
    without explicit ON DELETE CASCADE in DDL — we handle it explicitly here).
    """
    try:
        with _get_conn() as conn:
            # Check existence first
            row = conn.execute(
                scans_table.select().where(scans_table.c.id == scan_id)
            ).fetchone()

            if row is None:
                return False

            conn.execute(
                results_table.delete().where(results_table.c.scan_id == scan_id)
            )
            conn.execute(
                scans_table.delete().where(scans_table.c.id == scan_id)
            )
        return True

    except Exception as exc:
        logger.error("delete_scan failed for %s: %s", scan_id, exc)
        return False
