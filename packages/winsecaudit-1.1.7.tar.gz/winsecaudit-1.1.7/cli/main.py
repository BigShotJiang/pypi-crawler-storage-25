"""
cli/main.py — Typer CLI commands for WinSecAudit v2.

Boundary: this module orchestrates the pipeline and delegates all terminal
output to cli/output.py. It never imports Rich directly.

Engine and db imports are deferred to inside each command function so that
`winsecaudit --help` loads in milliseconds with no scanner overhead.
"""
from __future__ import annotations

import io
import json
import socket
import sys
from contextlib import nullcontext
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

# Windows console initialisation
#
# Two things must be true for Rich to render correctly on Windows PowerShell:
#   1. The stdout / stderr streams must be UTF-8 so Unicode glyphs (box-drawing,
#      arrows, em-dashes) survive the encoding round-trip.
#   2. The console must have ENABLE_VIRTUAL_TERMINAL_PROCESSING enabled so the
#      ANSI colour escape codes Rich emits get interpreted instead of printed
#      verbatim as `\x1b[36m...`.
#
# Modern terminals (Windows Terminal, pwsh 7+) enable VT mode by default;
# legacy `powershell.exe` (PowerShell 5.1) does not. We force it on via the
# `os.system("")` trick — cheaper and dependency-free than calling the kernel32
# SetConsoleMode API directly.
if sys.platform == "win32":
    import os as _os
    try:
        # Trigger VT processing on the active console
        _os.system("")
    except Exception:
        pass
    try:
        if hasattr(sys.stdout, "buffer"):
            sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
        if hasattr(sys.stderr, "buffer"):
            sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="replace")
    except Exception:
        pass  # already wrapped, or non-standard stream — Rich will still degrade gracefully

import typer

# Path resolution — single source of truth in runtime_paths.py.
# CHECKS_DIR / PROFILES_DIR are read-only and travel with the package;
# OUTPUT_DIR is writable and lands in the user data dir when pip-installed.
from winsecaudit_paths import CHECKS_DIR, PROFILES_DIR, OUTPUT_DIR

_CLI_DIR     = Path(__file__).resolve().parent
PROJECT_ROOT = _CLI_DIR.parent

app = typer.Typer(
    name="winsecaudit",
    help="WinSecAudit v2 — Windows Security Misconfiguration Auditor",
    add_completion=False,
    rich_markup_mode="rich",
    no_args_is_help=True,
)


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

def _err(msg: str, code: int = 1) -> None:
    """Print a Rich error to stderr and exit."""
    from cli.output import err_console
    err_console.print(f"[bold red]Error:[/] {msg}")
    raise typer.Exit(code=code)


def _find_check(name_fragment: str) -> type:
    """
    Discover all checks and return the unique class matching name_fragment
    (case-insensitive partial match). Exits with a helpful message on 0 or 2+ matches.
    """
    from checks.base import CheckRegistry
    check_classes = CheckRegistry.discover(CHECKS_DIR)
    needle  = name_fragment.lower()
    matches = [c for c in check_classes if needle in c.name.lower()]

    if len(matches) == 0:
        from cli.output import err_console
        err_console.print(f"[red]No check found matching '[bold]{name_fragment}[/]'.[/]\n")
        err_console.print("Available checks:")
        for cls in check_classes:
            err_console.print(f"  [dim]{cls.name}[/]")
        raise typer.Exit(code=1)

    if len(matches) > 1:
        from cli.output import err_console
        err_console.print(
            f"[yellow]Multiple checks match '[bold]{name_fragment}[/]'. "
            f"Be more specific:[/]"
        )
        for cls in matches:
            err_console.print(f"  {cls.name}")
        raise typer.Exit(code=1)

    return matches[0]


# ─────────────────────────────────────────────────────────────────────────────
# Post-scan interactive fix prompt
# ─────────────────────────────────────────────────────────────────────────────

def _scan_fix_prompt(results: list) -> None:
    """Loop through CRITICAL/HIGH remediable failures and offer to fix each one."""
    from checks.base import CheckRegistry
    from cli.output import console, render_single_check, _SEVERITY_STYLE

    def _sev(r: Any) -> str:
        s = getattr(r, "severity", None)
        if s is not None:
            return s.value if hasattr(s, "value") else str(s)
        return r.get("severity", "") if isinstance(r, dict) else ""

    def _status(r: Any) -> str:
        st = getattr(r, "status", None)
        if st is not None:
            return st.name if hasattr(st, "name") else str(st)
        return r.get("status", "") if isinstance(r, dict) else ""

    def _attr(r: Any, key: str, default: Any = "") -> Any:
        if isinstance(r, dict):
            return r.get(key, default)
        return getattr(r, key, default)

    targets = [
        r for r in results
        if _status(r) == "FAIL"
        and _sev(r) in ("CRITICAL", "HIGH")
        and _attr(r, "remediation_supported")
    ]

    if not targets:
        return

    _SEV_ORDER = {"CRITICAL": 0, "HIGH": 1}
    targets.sort(key=lambda r: _SEV_ORDER.get(_sev(r), 99))

    total = len(targets)
    W = 52

    console.print()
    console.print(f'┌{"─" * W}┐')
    header = f"  Interactive Fix Mode  ({total} remediable issue{'s' if total != 1 else ''})"
    console.print(f'│{header:<{W}}│')
    hint   = "  Type y / n for each issue, or q to quit early"
    console.print(f'│{hint:<{W}}│')
    console.print(f'└{"─" * W}┘')

    check_map = {cls.name: cls for cls in CheckRegistry.discover(CHECKS_DIR)}
    fixed = 0

    for i, r in enumerate(targets, start=1):
        name    = _attr(r, "check_name")
        sev     = _sev(r)
        rem_cmd = _attr(r, "remediation_cmd") or ""
        sev_style = _SEVERITY_STYLE.get(sev, "white")

        console.print()
        console.print(f"  [{sev_style}]{sev}[/]  [{i}/{total}]  [bold]{name}[/]")
        if rem_cmd:
            cmd_disp = (rem_cmd[:W - 8] + "…") if len(rem_cmd) > W - 8 else rem_cmd
            console.print(f"  [dim]cmd:[/] {cmd_disp}")

        try:
            raw = input("  Fix? [y/n/q]: ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            console.print("\n[dim]Interrupted — exiting fix mode.[/]")
            break

        if raw == "q":
            console.print("[dim]Exiting fix mode.[/]")
            break
        if raw != "y":
            continue

        check_cls = check_map.get(name)
        if check_cls is None:
            console.print(f'  [yellow]Check class not found for "{name}" — skipping.[/]')
            continue

        instance = check_cls()
        try:
            instance.remediate()
            after = instance.verify()
            console.print("  [green]✓ Fixed.[/]")
            render_single_check(after)
            fixed += 1
        except NotImplementedError as exc:
            console.print(f"  [yellow]Skipped: {exc}[/]")
        except Exception as exc:
            console.print(f"  [red]Failed: {exc}[/]")

    console.print()
    noun = "issue" if total == 1 else "issues"
    if fixed:
        console.print(
            f"[bold green]Fixed {fixed} of {total} {noun}.[/]  "
            f"Re-run scan to update your score."
        )
    else:
        console.print(f"[dim]Fixed 0 of {total} {noun}. Re-run scan to update your score.[/]")


# ─────────────────────────────────────────────────────────────────────────────
# COMMAND 1: scan
# ─────────────────────────────────────────────────────────────────────────────

@app.command()
def scan(
    profile:         str           = typer.Option("basic",    "--profile",         help="Profile name to use"),
    category:        Optional[str] = typer.Option(None,       "--category",        help="Run only checks in this category (partial match, case-insensitive)"),
    output:          str           = typer.Option("terminal", "--output",          help="Output format: terminal | json | silent"),
    no_threat_intel: bool          = typer.Option(False,      "--no-threat-intel", is_flag=True, help="Skip CVE enrichment (faster)"),
    target:          Optional[str] = typer.Option(None,       "--target",          help="Remote target IP/hostname (reserved, not yet implemented)"),
    explain_mode:    str           = typer.Option("simple",   "--explain-mode",    help="Explanation style for failures: simple | technical"),
) -> None:
    """Run a full security audit scan."""
    from db.database import init_db, save_scan
    from engine.comparator import apply_profile, load_profile
    from engine.risk import build_scan_summary, results_to_db_rows
    from engine.runner import run_all_checks
    from engine.scorer import calculate_score

    # 1. Init DB
    try:
        init_db()
    except Exception as exc:
        _err(f"Database initialisation failed: {exc}")

    # 2. Load profile
    try:
        profile_data = load_profile(profile, PROFILES_DIR)
    except FileNotFoundError as exc:
        _err(str(exc))

    # 3. Discover total check count for the progress bar (terminal mode only)
    _check_map: dict = {}
    if output == "terminal":
        from checks.base import CheckRegistry
        from cli.output import scan_progress_context
        _all_classes = CheckRegistry.discover(CHECKS_DIR)
        total        = len(_all_classes)
        _check_map   = {cls.name: cls for cls in _all_classes}
        progress_cm  = scan_progress_context(total)
    else:
        progress_cm = nullcontext(lambda *_: None)

    # 4. Run checks
    try:
        with progress_cm as progress_callback:
            raw_results, duration = run_all_checks(
                CHECKS_DIR,
                profile_data,
                target=target,
                progress_callback=progress_callback,
            )
    except Exception as exc:
        _err(f"Scan failed: {exc}")

    # 5. Optional category filter (before scoring so filtered checks are excluded)
    if category:
        needle = category.lower()
        raw_results = [r for r in raw_results if needle in r.category.lower()]
        if not raw_results:
            _err(
                f"No checks found in category matching '{category}'. "
                f"Run 'winsecaudit scan' without --category to see all category names."
            )

    # 6. Apply profile relaxations
    adjusted = apply_profile(raw_results, profile_data)

    # 7. TI enrichment — runs after profile so only the active result set is enriched.
    #    Best-effort: any failure yields ti_data={} and the scan continues normally.
    ti_data: dict = {}
    if not no_threat_intel:
        from engine.threat_intel import enrich_results, get_enriched_summary
        from rich.progress import Progress, SpinnerColumn, TextColumn

        # Show spinner for terminal mode; use nullcontext for json/silent so no
        # progress bar leaks into stdout when the output is being piped.
        if output == "terminal":
            from cli.output import console as _ti_console
            ti_progress_cm = Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=_ti_console,
                transient=True,
            )
        else:
            ti_progress_cm = nullcontext()

        try:
            with ti_progress_cm as _prog:
                if _prog is not None:
                    _task = _prog.add_task(
                        "[cyan]Enriching CVEs with NVD / EPSS / CISA KEV…[/]",
                        total=None,
                    )
                ti_data = enrich_results(adjusted)

            ti_summary = get_enriched_summary(adjusted, ti_data)

            if output == "terminal":
                from cli.output import console
                kev_n = ti_summary.get("cisa_kev_count", 0)
                if kev_n > 0:
                    console.print(
                        f"[bold red]\u26a0  {kev_n} CVE(s) in the "
                        f"CISA Known Exploited Vulnerabilities catalog[/bold red]"
                    )
                else:
                    console.print(
                        f"[dim]TI: {ti_summary.get('total_cves', 0)} CVEs enriched — "
                        f"0 in CISA KEV[/dim]"
                    )
        except Exception as exc:
            from cli.output import err_console
            err_console.print(f"[yellow]Warning:[/] TI enrichment failed: {exc}")

    # 8. Score
    score_data = calculate_score(adjusted)

    # 9. Build scan summary + save
    timestamp_tag = datetime.now(timezone.utc).replace(tzinfo=None).strftime("%Y%m%d_%H%M%S")
    hostname      = socket.gethostname()
    scan_id       = f"scan_{hostname}_{timestamp_tag}"
    scan_summary  = build_scan_summary(adjusted, score_data, profile, scan_id, duration)
    db_rows       = results_to_db_rows(adjusted, scan_id)

    try:
        save_scan(scan_summary, db_rows)
    except Exception as exc:
        from cli.output import err_console
        err_console.print(f"[yellow]Warning:[/] Could not save to database: {exc}")

    # 10. Render
    if output == "terminal":
        from cli.output import render_scan_results
        render_scan_results(
            adjusted, score_data, scan_summary,
            ti_data=ti_data,
            explain_mode=explain_mode,
            check_map=_check_map if _check_map else None,
        )
        _scan_fix_prompt(adjusted)
    elif output == "json":
        print(json.dumps(scan_summary, indent=2))
    # silent: no output


# ─────────────────────────────────────────────────────────────────────────────
# COMMAND 2: check
# ─────────────────────────────────────────────────────────────────────────────

@app.command()
def check(
    check_name:   str  = typer.Argument(..., help="Check name (case-insensitive partial match)"),
    fix:          bool = typer.Option(False,     "--fix",          is_flag=True, help="Run remediation after check if FAIL"),
    explain:      bool = typer.Option(False,     "--explain",      is_flag=True, help="Show CVE details and ATT&CK info"),
    explain_mode: str  = typer.Option("simple",  "--explain-mode",              help="Explanation style: simple | technical"),
) -> None:
    """Run and display a single security check by name."""
    from checks.base import CheckStatus
    from cli.output import console, render_single_check

    check_cls = _find_check(check_name)
    instance  = check_cls()

    try:
        result = instance.run()
    except Exception as exc:
        _err(f"Check '{check_cls.name}' raised an exception: {exc}")

    render_single_check(result, check_class=check_cls, explain_mode=explain_mode)

    if explain:
        _explain_result(result)

    if fix:
        if result.status != CheckStatus.FAIL:
            console.print(f"\n[dim]Check is not FAIL (status: {result.status.value}) — no fix needed.[/]")
            raise typer.Exit(code=0)

        if not result.remediation_supported:
            console.print("\n[yellow]Automated remediation is not supported for this check.[/]")
            if result.remediation_cmd:
                console.print(f"Manual fix: [dim]{result.remediation_cmd}[/]")
            raise typer.Exit(code=0)

        console.print(f"\n[bold]Remediation command:[/] [dim]{result.remediation_cmd}[/]")
        if typer.confirm("Run this fix?", default=False):
            try:
                instance.remediate()
            except NotImplementedError as exc:
                _err(str(exc))
            except Exception as exc:
                _err(f"Remediation failed: {exc}")

            console.print("\n[bold cyan]After fix:[/]")
            after = instance.verify()
            render_single_check(after)


def _explain_result(result: Any) -> None:
    """Print expanded CVE / ATT&CK / CIS detail for a result."""
    from cli.output import console

    cve_ids = []
    raw = getattr(result, "cve_ids", None)
    if raw is None and isinstance(result, dict):
        raw = result.get("cve_ids")
    if isinstance(raw, (list, tuple)):
        cve_ids = list(raw)
    elif isinstance(raw, str):
        try:
            cve_ids = json.loads(raw)
        except Exception:
            cve_ids = []

    def _attr(key: str) -> str:
        if isinstance(result, dict):
            return result.get(key) or ""
        return getattr(result, key, "") or ""

    mitre  = _attr("mitre_technique")
    cis_id = _attr("cis_id")

    console.print("\n[bold cyan]--- Details ---[/]")
    if cve_ids:
        console.print(f"CVE IDs:          [yellow]{', '.join(cve_ids)}[/]")
    else:
        console.print("CVE IDs:          [dim]None[/]")

    if mitre:
        # Build MITRE URL: T1021.002 → T1021/002
        url_frag = mitre.replace(".", "/")
        console.print(
            f"MITRE ATT&CK:     [dim]{mitre}[/]  "
            f"[link=https://attack.mitre.org/techniques/{url_frag}]"
            f"https://attack.mitre.org/techniques/{url_frag}[/link]"
        )
    if cis_id:
        console.print(f"CIS Benchmark ID: [dim]{cis_id}[/]")


# ─────────────────────────────────────────────────────────────────────────────
# COMMAND 3: report
# ─────────────────────────────────────────────────────────────────────────────

@app.command()
def report(
    format:  str           = typer.Option("terminal", "--format",  help="Output format: terminal | json | csv | pdf | docx"),
    scan_id: Optional[str] = typer.Option(None,       "--scan-id", help="Specific scan ID [default: latest]"),
    since:   Optional[str] = typer.Option(None,       "--since",   help="Only include scans after this date (YYYY-MM-DD)"),
) -> None:
    """Display or export a security audit report."""
    import csv as _csv

    from db.database import get_latest_scan, get_scan, init_db, list_scans

    try:
        init_db()
    except Exception as exc:
        _err(f"Database initialisation failed: {exc}")

    if scan_id:
        scan = get_scan(scan_id)
        if scan is None:
            _err(f"Scan '{scan_id}' not found. Run 'winsecaudit report' to list available scans.")
    elif since:
        # Find the latest scan after the given date
        scans = list_scans(limit=100)
        cutoff = since.strip()
        filtered = [s for s in scans if s.get("timestamp", "") >= cutoff]
        if not filtered:
            _err(
                f"No scans found after {since}. "
                f"Run 'winsecaudit scan' to generate one, or remove --since."
            )
        scan = get_scan(filtered[0]["id"])
    else:
        scan = get_latest_scan()

    if scan is None:
        from cli.output import console
        console.print("[yellow]No scans found. Run:[/]  winsecaudit scan")
        raise typer.Exit(code=0)

    if format == "terminal":
        from cli.output import render_report
        render_report(scan)

    elif format == "json":
        print(json.dumps(scan, indent=2, default=str))

    elif format == "csv":
        from exporters.csv_export import export_csv
        from cli.output import console
        OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        ts         = datetime.now(timezone.utc).replace(tzinfo=None).strftime("%Y%m%d_%H%M%S")
        machine_id = scan.get("machine_id", "unknown")
        out_path   = OUTPUT_DIR / f"winsecaudit_{machine_id}_{ts}.csv"
        path       = export_csv(scan, out_path)
        console.print(f"[green]CSV saved:[/green] {path}")

    elif format == "pdf":
        from exporters.pdf import export_pdf
        from cli.output import console
        OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        ts         = datetime.now(timezone.utc).replace(tzinfo=None).strftime("%Y%m%d_%H%M%S")
        machine_id = scan.get("machine_id", "unknown")
        out_path   = OUTPUT_DIR / f"winsecaudit_{machine_id}_{ts}.pdf"
        try:
            path = export_pdf(scan, out_path)
        except Exception as exc:
            _err(f"PDF export failed: {exc}")
        console.print(f"[green]PDF saved:[/green] {path}")

    elif format == "docx":
        from exporters.docx_export import export_docx
        from cli.output import console
        OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        ts         = datetime.now(timezone.utc).replace(tzinfo=None).strftime("%Y%m%d_%H%M%S")
        machine_id = scan.get("machine_id", "unknown")
        out_path   = OUTPUT_DIR / f"winsecaudit_{machine_id}_{ts}.docx"
        try:
            path = export_docx(scan, out_path)
        except Exception as exc:
            _err(f"DOCX export failed: {exc}")
        console.print(f"[green]DOCX saved:[/green] {path}")

    else:
        _err(f"Unknown format '{format}'. Use: terminal | json | csv | pdf | docx")


# ─────────────────────────────────────────────────────────────────────────────
# COMMAND 4: drift
# ─────────────────────────────────────────────────────────────────────────────

@app.command()
def drift(
    scans: Optional[str] = typer.Option(None,   "--scans", help="Two scan IDs separated by comma: scan_a,scan_b [default: latest two]"),
    show:  str           = typer.Option("all",  "--show",  help="Filter: all | regressions | improvements"),
) -> None:
    """Compare two scans and show security posture drift."""
    from db.database import get_drift, init_db, list_scans

    try:
        init_db()
    except Exception as exc:
        _err(f"Database initialisation failed: {exc}")

    if scans:
        parts = [s.strip() for s in scans.split(",")]
        if len(parts) != 2:
            _err("--scans expects exactly two IDs separated by a comma: 'scan_a,scan_b'")
        scan_id_a, scan_id_b = parts
    else:
        recent = list_scans(limit=2)
        if len(recent) < 2:
            from cli.output import console
            console.print(
                "[yellow]Fewer than 2 scans in the database.[/]\n"
                "Run [bold]winsecaudit scan[/] at least twice to enable drift comparison."
            )
            raise typer.Exit(code=0)
        # list_scans returns newest first; drift compares older → newer
        scan_id_a = recent[1]["id"]
        scan_id_b = recent[0]["id"]

    if show not in ("all", "regressions", "improvements"):
        _err(f"Unknown --show value '{show}'. Use: all | regressions | improvements")

    drift_data = get_drift(scan_id_a, scan_id_b)

    from cli.output import render_drift
    render_drift(drift_data, show=show)


# ─────────────────────────────────────────────────────────────────────────────
# COMMAND 5: fix
# ─────────────────────────────────────────────────────────────────────────────

@app.command()
def fix(
    check_name: Optional[str] = typer.Argument(None,  help="Name of the check to fix (partial match)"),
    all_high:   bool          = typer.Option(False, "--all-high", is_flag=True, help="Fix all HIGH and CRITICAL failures from latest scan"),
    dry_run:    bool          = typer.Option(False, "--dry-run",  is_flag=True, help="Show what would be changed, don't execute"),
    list_:      bool          = typer.Option(False, "--list",     is_flag=True, help="List all checks with automated remediation"),
) -> None:
    """Apply automated remediations for security misconfigurations."""
    if list_:
        _fix_list()
        return

    if check_name:
        _fix_single(check_name, dry_run=dry_run)
        return

    if all_high:
        _fix_all_high(dry_run=dry_run)
        return

    from cli.output import err_console
    err_console.print("[yellow]Specify a target or flag.[/]")
    err_console.print("  winsecaudit fix 'Windows Firewall'   # fix a specific check")
    err_console.print("  winsecaudit fix --all-high            # fix all CRITICAL/HIGH failures")
    err_console.print("  winsecaudit fix --list                # list remediable checks")
    raise typer.Exit(code=1)


def _fix_list() -> None:
    """Print a table of all checks where remediation_supported=True."""
    from checks.base import CheckRegistry
    from cli.output import console
    from rich.table import Table

    check_classes = CheckRegistry.discover(CHECKS_DIR)
    remediable    = [c for c in check_classes if c.remediation_supported]

    if not remediable:
        console.print("[dim]No checks have automated remediation support.[/]")
        raise typer.Exit(code=0)

    table = Table(
        title=f"Remediable Checks ({len(remediable)})",
        show_header=True,
        header_style="bold cyan",
        border_style="dim",
        expand=False,
    )
    table.add_column("Check",     min_width=30)
    table.add_column("Category",  min_width=20)
    table.add_column("Severity",  min_width=10)
    table.add_column("Command",   min_width=30)

    from cli.output import _SEVERITY_STYLE
    for cls in remediable:
        sev_style = _SEVERITY_STYLE.get(cls.severity.value, "white")
        table.add_row(
            cls.name,
            cls.category,
            f"[{sev_style}]{cls.severity.value}[/]",
            f"[dim]{cls.remediation_cmd[:60]}[/]" if cls.remediation_cmd else "[dim]—[/]",
        )

    console.print(table)


def _fix_single(name_fragment: str, dry_run: bool = False) -> None:
    """Fix a single check by partial name match."""
    from checks.base import CheckStatus
    from cli.output import console, render_single_check

    check_cls = _find_check(name_fragment)
    instance  = check_cls()

    try:
        result = instance.run()
    except Exception as exc:
        _err(f"Check '{check_cls.name}' raised an exception: {exc}")

    console.print("[bold]Current state:[/]")
    render_single_check(result)

    if result.status != CheckStatus.FAIL:
        console.print(f"\n[green]Check is {result.status.value} — no fix needed.[/]")
        raise typer.Exit(code=0)

    if not result.remediation_supported:
        console.print("\n[yellow]Automated remediation is not supported for this check.[/]")
        if result.remediation_cmd:
            console.print(f"Manual fix: [dim]{result.remediation_cmd}[/]")
        raise typer.Exit(code=0)

    if dry_run:
        console.print(f"\n[bold yellow]DRY RUN — would execute:[/]")
        console.print(f"  [dim]{result.remediation_cmd}[/]")
        raise typer.Exit(code=0)

    console.print(f"\n[bold]Remediation command:[/] [dim]{result.remediation_cmd}[/]")
    if typer.confirm("Run this fix?", default=False):
        try:
            instance.remediate()
        except NotImplementedError as exc:
            _err(str(exc))
        except Exception as exc:
            _err(f"Remediation failed: {exc}")

        console.print("\n[bold cyan]After fix:[/]")
        render_single_check(instance.verify())


def _fix_all_high(dry_run: bool = False) -> None:
    """Fix all CRITICAL/HIGH failures from the latest scan."""
    from checks.base import CheckRegistry
    from cli.output import console, render_single_check, _SEVERITY_STYLE
    from db.database import get_latest_scan, init_db

    try:
        init_db()
    except Exception as exc:
        _err(f"Database initialisation failed: {exc}")

    scan = get_latest_scan()
    if scan is None:
        _err("No scans found in database. Run 'winsecaudit scan' first.")

    targets = [
        r for r in scan.get("results", [])
        if r.get("status") == "FAIL"
        and r.get("severity") in ("CRITICAL", "HIGH")
        and r.get("remediation_supported")
    ]

    if not targets:
        console.print("[green]No CRITICAL/HIGH remediable failures found in the latest scan.[/]")
        raise typer.Exit(code=0)

    check_map = {cls.name: cls for cls in CheckRegistry.discover(CHECKS_DIR)}

    fixed   = 0
    skipped = 0

    for r in targets:
        name      = r.get("check_name", "")
        sev       = r.get("severity", "")
        sev_style = _SEVERITY_STYLE.get(sev, "white")

        console.rule(f"[{sev_style}]{sev}[/]  [bold]{name}[/]")

        check_cls = check_map.get(name)
        if check_cls is None:
            console.print(f"[dim]Check class not found for '{name}' — skipping.[/]")
            skipped += 1
            continue

        instance = check_cls()

        if dry_run:
            rem_cmd = getattr(check_cls, "remediation_cmd", "") or ""
            console.print(f"[bold yellow]DRY RUN:[/] {rem_cmd}")
            continue

        if not typer.confirm(f"Fix '{name}'?", default=False):
            skipped += 1
            continue

        try:
            instance.remediate()
            after = instance.verify()
            render_single_check(after)
            fixed += 1
        except NotImplementedError as exc:
            console.print(f"[yellow]Skipped:[/] {exc}")
            skipped += 1
        except Exception as exc:
            console.print(f"[red]Failed:[/] {exc}")
            skipped += 1

    console.print()
    if dry_run:
        console.print(f"[bold yellow]DRY RUN complete.[/] {len(targets)} checks would be fixed.")
    else:
        console.print(f"[bold]Done.[/] Fixed: {fixed}  |  Skipped: {skipped}")


# ─────────────────────────────────────────────────────────────────────────────
# COMMAND 6: dashboard
# ─────────────────────────────────────────────────────────────────────────────

@app.command()
def dashboard(
    port:         int  = typer.Option(8080,        "--port",         help="Port to serve on"),
    host:         str  = typer.Option("127.0.0.1", "--host",         help="Host to bind"),
    open_browser: bool = typer.Option(False,        "--open-browser", is_flag=True, help="Auto-open browser after starting"),
) -> None:
    """Start the read-only security dashboard API (http://<host>:<port>)."""
    from cli.output import console
    console.print(f"[bold green]WinSecAudit Dashboard[/] starting on [bold]http://{host}:{port}[/]")
    console.print("[dim]Press Ctrl+C to stop.[/]")

    # Deferred import keeps --help fast; uvicorn is only loaded when actually needed
    from dashboard.server import launch
    launch(host=host, port=port, open_browser=open_browser)


# ─────────────────────────────────────────────────────────────────────────────
# COMMAND 7: pipeline  (end-to-end orchestrator)
# ─────────────────────────────────────────────────────────────────────────────

@app.command()
def pipeline(
    quick:     bool = typer.Option(False, "--quick",
        is_flag=True, help="Demo mode: skip the second scan, run faster (under 30 s)."),
    skip_scan: bool = typer.Option(False, "--skip-scan",
        is_flag=True, help="Reuse existing DB scans; do not run new scans."),
    with_ti:   bool = typer.Option(False, "--with-ti",
        is_flag=True, help="Enable NVD/EPSS/CISA-KEV threat-intel enrichment."),
    serve:     bool = typer.Option(True, "--serve/--no-serve",
        help="Launch the local dashboard at the end (auto-opens browser)."),
) -> None:
    """End-to-end audit pipeline: discovery, scans, drift, PDF report, dashboard."""
    from datetime import datetime
    from cli.output import console
    from rich.panel import Panel
    from rich.rule import Rule
    from rich.table import Table
    from rich.text import Text
    from db.database import init_db, list_scans

    init_db()

    # ── Banner ──────────────────────────────────────────────────────────
    console.print()
    console.print(
        Panel.fit(
            Text.from_markup(
                "[bold cyan]WinSecAudit v2[/]  ·  "
                "[white]End-to-End Audit Pipeline[/]\n\n"
                "[dim]Plugin-based  ·  Layered  ·  Auto-discovered checks  ·  "
                "Threat-intel-enriched[/]",
                justify="center",
            ),
            border_style="cyan",
            padding=(1, 4),
        ),
        justify="center",
    )
    console.print(
        f"[dim]Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}[/]\n",
        justify="center",
    )

    total_phases = 5 if quick else 6

    def section(title: str, num: int, narration: str = "") -> None:
        """Print a phase divider plus a one-line plain-English narration."""
        console.print()
        console.print(Rule(
            f"[bold cyan]Phase {num}/{total_phases} : {title}[/]",
            style="cyan"
        ))
        if narration:
            console.print(f"[italic dim]{narration}[/]")
        console.print()

    # Plain-English descriptions of every check category, shown after Phase 1
    CATEGORY_DESCRIPTIONS = {
        "Access Control":
            "Who can do what on this machine. Covers User Account Control "
            "(the prompt that asks 'Allow this app to make changes?'), admin "
            "shares, AutoRun, and PowerShell execution policy.",
        "Authentication Security":
            "How the machine confirms 'is this really you?'. Covers password "
            "rules, account lock-out, the Guest account, and renaming the "
            "default Administrator.",
        "Credential Security":
            "How passwords and tokens are protected against theft. Covers "
            "Credential Guard, LAPS, WDigest, and cached domain logons.",
        "Kernel & Memory":
            "Low-level CPU and memory protections that block exploits. Covers "
            "ASLR, DEP, Virtualization-Based Security, and Kernel DMA "
            "Protection (the safeguards inside the chip).",
        "Logging & Auditing":
            "What activity the machine records, so you can investigate after "
            "an incident. Covers PowerShell logging, Sysmon, and Advanced "
            "Audit Policy.",
        "Network Security":
            "Which old or insecure network protocols are turned off. Covers "
            "SMBv1, LLMNR, NetBIOS, NTLMv1, RDP NLA, and WPAD.",
        "Services":
            "Background Windows services that should stay disabled unless "
            "needed. Covers Print Spooler, Telnet, FTP, SNMP, and WinRM.",
        "System Hardening":
            "Core machine-wide protections. Covers BitLocker disk encryption, "
            "Windows Defender, Windows Firewall, automatic updates, and "
            "Secure Boot.",
    }

    # ── Phase 1: Check discovery ────────────────────────────────────────
    section(
        "Check Discovery",
        1,
        narration=(
            "We scan the project tree for every plugin check we know about. "
            "Each check tests one specific Windows security setting."
        ),
    )
    from checks.base import CheckRegistry
    classes = CheckRegistry.discover(CHECKS_DIR)
    console.print(f"[bold green]Discovered {len(classes)} security checks[/]\n")
    cats: dict[str, list[str]] = {}
    for c in classes:
        cats.setdefault(c.category, []).append(c.name)
    tbl = Table(
        title="Plugin Check Catalogue",
        header_style="bold white on cyan",
        show_lines=False,
    )
    tbl.add_column("Category",        style="cyan",  no_wrap=True)
    tbl.add_column("# Checks",        style="white", justify="right", no_wrap=True)
    tbl.add_column("What it covers",  style="dim",   overflow="fold")
    for cat in sorted(cats):
        n = len(cats[cat])
        desc = CATEGORY_DESCRIPTIONS.get(cat, "Various security controls.")
        tbl.add_row(cat, str(n), desc)
    console.print(tbl)

    # Pre-existing scan count (used to decide whether we have data for drift)
    pre_existing = len(list_scans(limit=2))

    # ── Phase 2: Scan #1 (basic profile) ────────────────────────────────
    if not skip_scan:
        section(
            "Scan #1 (basic profile)",
            2,
            narration=(
                "We now run all checks against your Windows machine. "
                "The 'basic' profile relaxes a handful of settings that are "
                "typical on developer or workstation builds (e.g. BitLocker "
                "may not be enforced)."
            ),
        )
        try:
            scan(profile="basic", category=None, output="terminal",
                 no_threat_intel=not with_ti, target=None,
                 explain_mode="simple")
        except SystemExit:
            pass

    # ── Phase 3: Scan #2 (hardened profile) — skipped in --quick ────────
    if not skip_scan and not quick:
        section(
            "Scan #2 (hardened profile)",
            3,
            narration=(
                "Now the strict 'hardened' profile, used for servers and "
                "high-security workstations. No relaxations — every control "
                "is enforced at full weight."
            ),
        )
        try:
            scan(profile="hardened", category=None, output="terminal",
                 no_threat_intel=not with_ti, target=None,
                 explain_mode="simple")
        except SystemExit:
            pass

    # ── Phase 4: Drift ──────────────────────────────────────────────────
    drift_phase = 3 if quick else 4
    section(
        "Drift Comparison",
        drift_phase,
        narration=(
            "We compare the two most recent scans to surface what got better "
            "(improvements), what got worse (regressions), and which checks "
            "are new or removed since last time."
        ),
    )
    try:
        if pre_existing >= 2 or not skip_scan:
            drift(scans=None, show="all")
        else:
            console.print("[yellow]Need at least 2 scans for drift comparison.[/]")
    except SystemExit:
        pass

    # ── Phase: PDF report (cached in %TEMP%, not persistent on disk) ────
    reports_phase = 4 if quick else 5
    section(
        "PDF Report (cached)",
        reports_phase,
        narration=(
            "We render the latest scan as a single PDF report. The file is "
            "placed in your system's temp / cache directory so it doesn't "
            "permanently consume disk space — Windows clears %TEMP% over time."
        ),
    )
    import tempfile
    cache_dir = Path(tempfile.gettempdir()) / "winsecaudit"
    cache_dir.mkdir(parents=True, exist_ok=True)

    pdf_path: Path | None = None
    try:
        # Generate PDF directly into the cache dir using the exporter API
        from db.database import get_latest_scan
        from exporters.pdf import export_pdf
        scan_data = get_latest_scan()
        if scan_data is None:
            console.print("[yellow]No scan data available to render.[/]")
        else:
            stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            pdf_path = cache_dir / f"winsecaudit_{scan_data.get('machine_id','machine')}_{stamp}.pdf"
            export_pdf(scan_data, pdf_path)
            console.print(f"[green]✓ PDF saved to cache:[/] [cyan]{pdf_path}[/]")
    except Exception as exc:
        console.print(f"[yellow]PDF generation failed: {exc}[/]")

    # ── Final phase: Summary + Dashboard launch ─────────────────────────
    section(
        "Summary  &  Dashboard",
        total_phases,
        narration=(
            "All scan data lives only on this machine in your private user "
            "data folder — nothing is uploaded anywhere. We now launch the "
            "local web dashboard at http://127.0.0.1:8080. Press Ctrl+C in "
            "this terminal when you're done viewing it."
        ),
    )
    sum_tbl = Table(
        title="Pipeline Artefacts",
        title_style="bold cyan",
        header_style="bold white on cyan",
    )
    sum_tbl.add_column("Type",     style="cyan",  no_wrap=True)
    sum_tbl.add_column("Location", style="white")
    if pdf_path is not None and pdf_path.exists():
        sum_tbl.add_row("PDF report (cache)", str(pdf_path))
    sum_tbl.add_row("Cache directory", str(cache_dir))
    sum_tbl.add_row("Local database",  "private user-data dir (per-user)")
    sum_tbl.add_row("Network exposure", "127.0.0.1 only — no remote access")
    console.print(sum_tbl)

    console.print()
    if serve:
        console.print(
            Panel.fit(
                Text.from_markup(
                    "[bold green]Pipeline complete.[/]  Launching the local "
                    "dashboard now …\n\n"
                    "[white]The browser will open automatically at[/] "
                    "[cyan]http://127.0.0.1:8080[/]\n\n"
                    "[dim]Press Ctrl+C in this terminal to stop the server "
                    "when you're done.[/]"
                ),
                border_style="green",
                title="[bold]Dashboard Starting[/]",
                padding=(1, 3),
            )
        )
        # Block here while the dashboard runs — user terminates with Ctrl+C
        try:
            from dashboard.server import launch
            launch(host="127.0.0.1", port=8080, open_browser=True)
        except KeyboardInterrupt:
            console.print("\n[dim]Dashboard stopped. Goodbye.[/]")
    else:
        console.print(
            Panel.fit(
                Text.from_markup(
                    "[bold green]Pipeline complete.[/]\n\n"
                    "[white]Next steps:[/]\n"
                    "  · Open the PDF in the path above.\n"
                    "  · Launch the dashboard manually:  "
                    "[cyan]winsecaudit dashboard[/]"
                ),
                border_style="green",
                title="[bold]Pipeline Finished[/]",
                padding=(1, 3),
            )
        )


# ─────────────────────────────────────────────────────────────────────────────
# Module entrypoint — required so `python -m cli.main` actually invokes Typer.
# Without this, the module loads, defines `app`, and exits with no-op (the
# bug that made the dashboard's "Scan Now" button finish in <1 second without
# running anything).
# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    app()
