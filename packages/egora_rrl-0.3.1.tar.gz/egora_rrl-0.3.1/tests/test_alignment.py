"""Unit tests for egora_rrl.alignment (no model required)."""

import numpy as np
import torch
import pytest


def test_compute_alignment_basic():
    """Cosine alignment between identical gradients should be 1.0."""
    from egora_rrl.alignment import compute_alignment

    grad = {"layer.0.q_proj.weight": torch.randn(64)}
    heads, alphas = compute_alignment(grad, grad)

    assert len(heads) == 1
    assert len(alphas) == 1
    assert alphas[0] == pytest.approx(1.0, abs=1e-5)


def test_compute_alignment_opposite():
    """Opposite gradients → α ≈ -1."""
    from egora_rrl.alignment import compute_alignment

    g = torch.randn(64)
    grad_a = {"layer.0.q_proj.weight": g}
    grad_b = {"layer.0.q_proj.weight": -g}

    heads, alphas = compute_alignment(grad_a, grad_b)
    assert alphas[0] == pytest.approx(-1.0, abs=1e-5)


def test_compute_alignment_orthogonal():
    """Orthogonal gradients → α ≈ 0."""
    from egora_rrl.alignment import compute_alignment

    g1 = torch.zeros(64)
    g1[0] = 1.0
    g2 = torch.zeros(64)
    g2[1] = 1.0

    grad_a = {"layer.0.q_proj.weight": g1}
    grad_b = {"layer.0.q_proj.weight": g2}

    heads, alphas = compute_alignment(grad_a, grad_b)
    assert abs(alphas[0]) < 0.01


def test_identify_critical_heads():
    """Critical heads are correctly identified by threshold."""
    from egora_rrl.alignment import identify_critical_heads

    heads = [
        {"name": "a", "layer": 0, "proj_type": "q_proj", "alpha": -0.9,
         "grad_magnitude_capability": 1.0, "grad_magnitude_finetune": 1.0},
        {"name": "b", "layer": 1, "proj_type": "k_proj", "alpha": 0.5,
         "grad_magnitude_capability": 1.0, "grad_magnitude_finetune": 1.0},
        {"name": "c", "layer": 2, "proj_type": "v_proj", "alpha": -0.8,
         "grad_magnitude_capability": 1.0, "grad_magnitude_finetune": 1.0},
    ]
    alphas = np.array([-0.9, 0.5, -0.8])

    critical = identify_critical_heads(heads, alphas, threshold=-0.7)
    assert len(critical) == 2
    assert critical[0]["name"] == "a"  # most severe first
    assert critical[1]["name"] == "c"


def test_identify_critical_heads_none():
    """No critical heads when all alphas are positive."""
    from egora_rrl.alignment import identify_critical_heads

    heads = [{"name": "a", "layer": 0, "proj_type": "q_proj", "alpha": 0.9,
              "grad_magnitude_capability": 1.0, "grad_magnitude_finetune": 1.0}]
    alphas = np.array([0.9])

    critical = identify_critical_heads(heads, alphas, threshold=-0.7)
    assert len(critical) == 0


def test_compute_cross_modal_alignment():
    """Cross-modal alignment returns three alpha values per head."""
    from egora_rrl.alignment import compute_cross_modal_alignment

    g = torch.randn(64)
    grad_mmlu = {"layer.0.q_proj.weight": g}
    grad_modal = {"layer.0.q_proj.weight": -g}
    grad_tune = {"layer.0.q_proj.weight": g * 0.5}

    heads = compute_cross_modal_alignment(grad_mmlu, grad_modal, grad_tune)
    assert len(heads) == 1
    assert "alpha_mmlu" in heads[0]
    assert "alpha_modal" in heads[0]
    assert "alpha_cross" in heads[0]
    # tune is same direction as mmlu → alpha_mmlu ≈ 1
    assert heads[0]["alpha_mmlu"] == pytest.approx(1.0, abs=1e-4)
    # tune is opposite to modal → alpha_modal ≈ -1
    assert heads[0]["alpha_modal"] == pytest.approx(-1.0, abs=1e-4)


def test_identify_universal_critical_heads():
    """Universal critical = anti-aligned with both modalities."""
    from egora_rrl.alignment import identify_universal_critical_heads

    cross_heads = [
        {"name": "a", "layer": 0, "proj_type": "q_proj",
         "alpha_mmlu": -0.8, "alpha_modal": -0.9, "alpha_cross": 0.5},
        {"name": "b", "layer": 1, "proj_type": "k_proj",
         "alpha_mmlu": -0.6, "alpha_modal": 0.3, "alpha_cross": -0.2},
        {"name": "c", "layer": 2, "proj_type": "v_proj",
         "alpha_mmlu": 0.5, "alpha_modal": -0.7, "alpha_cross": 0.1},
    ]

    universal = identify_universal_critical_heads(cross_heads, threshold=-0.5)
    assert len(universal) == 1
    assert universal[0]["name"] == "a"


def test_parse_head_info():
    """_parse_head_info extracts layer and proj type."""
    from egora_rrl.alignment import _parse_head_info

    layer, proj = _parse_head_info("model.layers.5.self_attn.q_proj.weight")
    assert layer == 5
    assert proj == "q_proj"

    layer, proj = _parse_head_info("model.layers.12.self_attn.v_proj.weight")
    assert layer == 12
    assert proj == "v_proj"


def test_collect_target_param_names():
    """_collect_target_param_names finds attention projection weights."""
    from egora_rrl.alignment import _collect_target_param_names
    import torch.nn as nn

    class SelfAttn(nn.Module):
        def __init__(self):
            super().__init__()
            self.q_proj = nn.Linear(32, 32)
            self.k_proj = nn.Linear(32, 32)

    class FakeModel(nn.Module):
        def __init__(self):
            super().__init__()
            self.self_attn = SelfAttn()
            self.mlp = nn.Linear(32, 32)

    model = FakeModel()
    names = _collect_target_param_names(model, ['q_proj', 'k_proj'])
    assert len(names) == 2
    assert any("q_proj" in n for n in names)
    assert any("k_proj" in n for n in names)
    assert not any("mlp" in n for n in names)
