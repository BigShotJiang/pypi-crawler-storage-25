"""Unit tests for egora_rrl.knowledge_map (no model required)."""

import numpy as np
import pytest


def test_knowledge_domains_structure():
    """KNOWLEDGE_DOMAINS has expected domains and prompts."""
    from egora_rrl.knowledge_map import KNOWLEDGE_DOMAINS

    assert "factual" in KNOWLEDGE_DOMAINS
    assert "syntactic" in KNOWLEDGE_DOMAINS
    assert "reasoning" in KNOWLEDGE_DOMAINS

    for domain, data in KNOWLEDGE_DOMAINS.items():
        assert "prompts" in data
        assert len(data["prompts"]) >= 4
        for prompt, answer in data["prompts"]:
            assert isinstance(prompt, str)
            assert isinstance(answer, str)


def test_knowledge_concentration_index():
    """KCI computation on synthetic head assignments."""
    from egora_rrl.knowledge_map import knowledge_concentration_index

    head_assignments = []
    for i in range(32):
        scores = {
            "factual": float(np.random.uniform(0, 1)),
            "syntactic": float(np.random.uniform(0, 1)),
            "reasoning": float(np.random.uniform(0, 1)),
        }
        dominant = max(scores, key=scores.get)
        head_assignments.append({
            "layer": i // 8,
            "head": i % 8,
            "dominant_domain": dominant,
            "scores": scores,
            "specificity": max(scores.values()) / (sum(scores.values()) + 1e-10),
        })

    result = knowledge_concentration_index(head_assignments)
    assert "overall" in result
    assert "per_domain" in result
    assert 0 <= result["overall"] <= 1.0
    for domain in ["factual", "syntactic", "reasoning"]:
        assert domain in result["per_domain"]


def test_kci_uniform_is_low():
    """Uniform head contributions → low Gini (distributed knowledge)."""
    from egora_rrl.knowledge_map import knowledge_concentration_index

    head_assignments = []
    for i in range(100):
        head_assignments.append({
            "layer": i // 10,
            "head": i % 10,
            "dominant_domain": "factual",
            "scores": {"factual": 1.0, "syntactic": 1.0, "reasoning": 1.0},
            "specificity": 1.0 / 3,
        })

    result = knowledge_concentration_index(head_assignments)
    assert result["overall"] < 0.1  # near-zero Gini for uniform


def test_kci_concentrated_is_high():
    """One dominant head → high Gini (concentrated knowledge)."""
    from egora_rrl.knowledge_map import knowledge_concentration_index

    head_assignments = []
    for i in range(50):
        if i == 0:
            scores = {"factual": 100.0, "syntactic": 0.01, "reasoning": 0.01}
        else:
            scores = {"factual": 0.01, "syntactic": 0.01, "reasoning": 0.01}
        head_assignments.append({
            "layer": i // 10,
            "head": i % 10,
            "dominant_domain": max(scores, key=scores.get),
            "scores": scores,
            "specificity": max(scores.values()) / (sum(scores.values()) + 1e-10),
        })

    result = knowledge_concentration_index(head_assignments)
    assert result["per_domain"]["factual"] > 0.8  # high Gini
