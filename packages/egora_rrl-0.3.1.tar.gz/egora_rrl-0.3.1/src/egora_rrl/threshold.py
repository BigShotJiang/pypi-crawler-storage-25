"""
Rotation-Retention Threshold Analysis
======================================
Tests the theoretical prediction that the critical rotation threshold
is governed by head dimensionality:

    θ_crit = arcsin(1/√d_head)

This connects the empirical 5° threshold to the information-theoretic
resolution limit of the representational space.

Four checks:
  1. Dimensionality threshold: arcsin(1/√d) vs empirical bimodal split
  2. Golden ratio k-check: does k ≈ 1/φ ≈ 0.618 pp/degree?
  3. Phase transition: is there a real discontinuity at θ_crit?
  4. Cross-architecture validation: predicted vs observed threshold per model

Usage::

    from egora_rrl.threshold import run_threshold_analysis

    results = run_threshold_analysis(
        geometry_results,
        model_name="llama_8b",
        mmlu_base=63.42,
        mmlu_after=62.86,
        output_dir="analysis/",
    )
"""

import json
import os
from typing import Any, Dict, List, Optional, Sequence

import numpy as np

# Optional imports — graceful fallback
try:
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    HAS_MATPLOTLIB = True
except ImportError:
    HAS_MATPLOTLIB = False

try:
    from scipy.stats import gaussian_kde
    from scipy.signal import argrelmin
    from scipy.optimize import curve_fit
    from scipy.stats import f as f_dist
    HAS_SCIPY = True
except ImportError:
    HAS_SCIPY = False


# ── Known architecture head dimensions ────────────────────────────────────────
HEAD_DIMS: Dict[str, int] = {
    "llama_8b":         128,
    "llama_3b":         128,
    "llama_1b":          64,
    "mistral_7b":       128,
    "phi3_mini":         96,
    "llava_7b":         128,
    "qwen2_vl_7b":      128,
    "whisper_large":     64,
    "qwen2_audio_7b":   128,
    "musicgen_7b":       128,
}

PHI = (1 + np.sqrt(5)) / 2  # Golden ratio ≈ 1.6180


def predicted_threshold(d_head: int) -> float:
    """Compute predicted critical threshold: θ_crit = arcsin(1/√d_head) in degrees.

    Args:
        d_head: Head dimension (e.g. 64, 96, 128).

    Returns:
        Critical threshold angle in degrees.
    """
    return float(np.degrees(np.arcsin(1.0 / np.sqrt(d_head))))


# ═══════════════════════════════════════════════════════════════════════════════
# CHECK 1 — Dimensionality Threshold
# ═══════════════════════════════════════════════════════════════════════════════

def check_dimensionality_threshold(
    theta_per_head: Sequence[float],
    d_head: int,
    model_name: str = "model",
    output_dir: Optional[str] = None,
) -> Dict[str, Any]:
    """Test whether the bimodal split in the θ distribution matches arcsin(1/√d_head).

    Args:
        theta_per_head: Rotation angles (degrees) per head.
        d_head: Head dimension.
        model_name: Label for output.
        output_dir: Where to save plots/JSON (optional).

    Returns:
        Dict with predicted vs empirical threshold and damaged fractions.
    """
    thetas = np.array(theta_per_head)
    pred = predicted_threshold(d_head)

    result: Dict[str, Any] = {
        "model": model_name,
        "d_head": d_head,
        "predicted_threshold_deg": round(pred, 4),
        "n_heads": len(thetas),
        "theta_mean": round(float(np.mean(thetas)), 4),
        "theta_std": round(float(np.std(thetas)), 4),
        "damaged_at_predicted": round(float(np.mean(thetas > pred) * 100), 2),
        "damaged_at_5deg": round(float(np.mean(thetas > 5.0) * 100), 2),
    }

    # Try to find empirical bimodal split via KDE
    empirical_split = None
    if HAS_SCIPY and len(thetas) > 10:
        try:
            kde = gaussian_kde(thetas, bw_method=0.3)
            x = np.linspace(0, max(20, np.max(thetas) * 1.5), 1000)
            kde_values = kde(x)
            local_mins = argrelmin(kde_values, order=30)[0]
            if len(local_mins) > 0:
                valleys = x[local_mins]
                valleys = valleys[(valleys > 1.0) & (valleys < 15.0)]
                if len(valleys) > 0:
                    idx = np.argmin(np.abs(valleys - pred))
                    empirical_split = float(valleys[idx])
        except Exception:
            pass

    if empirical_split is not None:
        result["empirical_split_deg"] = round(empirical_split, 4)
        result["predicted_vs_empirical_diff"] = round(abs(pred - empirical_split), 4)
    else:
        result["empirical_split_deg"] = None
        result["predicted_vs_empirical_diff"] = None

    # Generate plot if matplotlib available
    if HAS_MATPLOTLIB and HAS_SCIPY and output_dir:
        _plot_threshold(thetas, pred, empirical_split, d_head, model_name, output_dir)

    if output_dir:
        os.makedirs(output_dir, exist_ok=True)
        path = os.path.join(output_dir, 'dimensionality_threshold.json')
        with open(path, 'w') as f:
            json.dump(result, f, indent=2)

    return result


def _plot_threshold(thetas, predicted, empirical, d_head, model_name, output_dir):
    """Generate KDE plot with predicted and empirical thresholds."""
    try:
        kde = gaussian_kde(thetas, bw_method=0.3)
        x = np.linspace(0, max(15, np.max(thetas) * 1.2), 500)

        fig, ax = plt.subplots(figsize=(10, 5))
        ax.fill_between(x, kde(x), alpha=0.3, color='steelblue')
        ax.plot(x, kde(x), 'b-', linewidth=2, label='θ distribution')
        ax.axvline(x=predicted, color='red', linestyle='--', linewidth=2,
                   label=f'arcsin(1/√{d_head}) = {predicted:.2f}°')
        if d_head != 128:
            ax.axvline(x=5.0, color='green', linestyle=':', linewidth=1.5,
                       label='5° reference (d=128)')
        if empirical is not None:
            ax.axvline(x=empirical, color='orange', linewidth=2,
                       label=f'Empirical split: {empirical:.2f}°')
        ax.set_xlabel('Rotation angle θ (degrees)', fontsize=12)
        ax.set_ylabel('Density', fontsize=12)
        ax.set_title(f'Dimensionality Threshold — {model_name} (d_head={d_head})',
                     fontsize=13, fontweight='bold')
        ax.legend(fontsize=10)

        os.makedirs(output_dir, exist_ok=True)
        path = os.path.join(output_dir, 'dimensionality_threshold.png')
        plt.savefig(path, dpi=150, bbox_inches='tight', facecolor='white')
        plt.close()
    except Exception:
        pass


# ═══════════════════════════════════════════════════════════════════════════════
# CHECK 2 — Golden Ratio k-check
# ═══════════════════════════════════════════════════════════════════════════════

def check_golden_ratio_k(
    theta_bar: float,
    mmlu_delta: float,
    model_name: str = "model",
    output_dir: Optional[str] = None,
) -> Dict[str, Any]:
    """Test whether sensitivity coefficient k = |ΔM|/θ̄ is close to 1/φ.

    Args:
        theta_bar: Mean rotation angle (degrees).
        mmlu_delta: MMLU change (percentage points, e.g. −3.5).
        model_name: Label.
        output_dir: Where to save (optional).

    Returns:
        Dict with k value and comparison to 1/φ.
    """
    if theta_bar < 0.01:
        return {"model": model_name, "k": None, "note": "theta_bar too small"}

    k = abs(mmlu_delta) / theta_bar
    target = 1.0 / PHI

    result = {
        "model": model_name,
        "theta_bar_deg": round(theta_bar, 4),
        "mmlu_delta_pp": round(mmlu_delta, 4),
        "k": round(k, 4),
        "one_over_phi": round(target, 4),
        "k_minus_target": round(k - target, 4),
        "relative_error_pct": round(abs(k - target) / target * 100, 2),
    }

    if output_dir:
        os.makedirs(output_dir, exist_ok=True)
        path = os.path.join(output_dir, 'golden_ratio_k.json')
        with open(path, 'w') as f:
            json.dump(result, f, indent=2)

    return result


def check_golden_ratio_k_aggregate(
    k_values: Sequence[float],
    labels: Optional[List[str]] = None,
    output_dir: Optional[str] = None,
) -> Dict[str, Any]:
    """Statistical test of all k values against mathematical constants.

    Args:
        k_values: List of k values from multiple conditions.
        labels: Optional labels for each k value.
        output_dir: Where to save (optional).

    Returns:
        Dict with mean k, std, and comparisons to 1/φ, 1/e, 1/π, etc.
    """
    k_arr = np.array([k for k in k_values if k is not None and not np.isnan(k)])
    if len(k_arr) == 0:
        return {"error": "no valid k values"}

    mean_k = float(np.mean(k_arr))
    std_k = float(np.std(k_arr))

    alternatives = {
        "1/phi": 1.0 / PHI,
        "1/e": 1.0 / np.e,
        "1/pi": 1.0 / np.pi,
        "sqrt2/2": np.sqrt(2) / 2,
        "ln2": np.log(2),
        "2/pi": 2.0 / np.pi,
    }

    comparisons = {}
    for name, value in alternatives.items():
        diff = abs(mean_k - value)
        comparisons[name] = {"value": round(value, 6), "diff": round(diff, 6)}

    result = {
        "n_conditions": len(k_arr),
        "mean_k": round(mean_k, 4),
        "std_k": round(std_k, 4),
        "median_k": round(float(np.median(k_arr)), 4),
        "k_values": [round(float(k), 4) for k in k_arr],
        "labels": labels,
        "comparisons": comparisons,
        "best_match": min(comparisons.items(), key=lambda x: x[1]["diff"])[0],
    }

    if output_dir:
        os.makedirs(output_dir, exist_ok=True)
        path = os.path.join(output_dir, 'golden_ratio_k_aggregate.json')
        with open(path, 'w') as f:
            json.dump(result, f, indent=2)

    return result


# ═══════════════════════════════════════════════════════════════════════════════
# CHECK 3 — Phase Transition
# ═══════════════════════════════════════════════════════════════════════════════

def check_phase_transition(
    theta_values: Sequence[float],
    mmlu_loss_values: Sequence[float],
    labels: Optional[List[str]] = None,
    output_dir: Optional[str] = None,
) -> Dict[str, Any]:
    """Test for a phase transition (piecewise-linear vs single-linear fit).

    Compares:
      Model A: ΔM = k·θ  (single line through origin)
      Model B: ΔM = k₁·θ for θ < θ_crit, then k₁·θ_crit + k₂·(θ−θ_crit)

    Uses F-test to determine significance.

    Args:
        theta_values: Array of θ̄ values (degrees).
        mmlu_loss_values: Array of |ΔM| values (positive = loss).
        labels: Optional labels for each data point.
        output_dir: Where to save (optional).

    Returns:
        Dict with model fits, F-statistic, p-value, conclusion.
    """
    if not HAS_SCIPY:
        return {"error": "scipy required for phase transition check"}

    theta = np.array(theta_values, dtype=float)
    loss = np.abs(np.array(mmlu_loss_values, dtype=float))

    if len(theta) < 5:
        return {"error": "need at least 5 data points", "n_points": len(theta)}

    # Model A: single linear through origin
    def linear(x, k):
        return k * x

    try:
        popt_a, _ = curve_fit(linear, theta, loss)
    except Exception:
        popt_a = [np.mean(loss) / max(np.mean(theta), 0.01)]

    residuals_a = loss - linear(theta, *popt_a)
    ss_res_a = float(np.sum(residuals_a**2))

    # Model B: piecewise linear with break point
    def piecewise(x, theta_crit, k1, k2):
        return np.where(x < theta_crit,
                        k1 * x,
                        k1 * theta_crit + k2 * (x - theta_crit))

    best_ss = np.inf
    best_params = None

    for tc_try in np.linspace(2.5, 8.0, 60):
        try:
            p0 = [tc_try, 0.3, 0.8]
            popt_b, _ = curve_fit(piecewise, theta, loss, p0=p0, maxfev=5000)
            residuals_b = loss - piecewise(theta, *popt_b)
            ss = float(np.sum(residuals_b**2))
            if ss < best_ss:
                best_ss = ss
                best_params = popt_b
        except Exception:
            continue

    if best_params is None:
        return {"error": "piecewise fit failed"}

    # F-test
    n = len(theta)
    df1 = 2
    df2 = max(n - 3, 1)

    if best_ss > 0:
        f_stat = ((ss_res_a - best_ss) / df1) / (best_ss / df2)
    else:
        f_stat = float('inf')

    p_value = float(1 - f_dist.cdf(max(f_stat, 0), df1, df2))
    is_transition = p_value < 0.05

    result = {
        "n_points": n,
        "linear_k": round(float(popt_a[0]), 4),
        "linear_ss_res": round(ss_res_a, 6),
        "piecewise_theta_crit": round(float(best_params[0]), 4),
        "piecewise_k_before": round(float(best_params[1]), 4),
        "piecewise_k_after": round(float(best_params[2]), 4),
        "piecewise_ss_res": round(best_ss, 6),
        "f_statistic": round(f_stat, 4),
        "p_value": round(p_value, 6),
        "is_phase_transition": is_transition,
        "conclusion": ("Phase transition detected" if is_transition
                        else "Single linear law (no discontinuity)"),
    }

    if HAS_MATPLOTLIB and output_dir:
        _plot_phase_transition(theta, loss, labels, popt_a, best_params,
                               is_transition, output_dir)

    if output_dir:
        os.makedirs(output_dir, exist_ok=True)
        path = os.path.join(output_dir, 'phase_transition.json')
        with open(path, 'w') as f:
            json.dump(result, f, indent=2)

    return result


def _plot_phase_transition(theta, loss, labels, popt_a, best_params,
                           is_transition, output_dir):
    """Plot phase transition analysis."""
    try:
        fig, axes = plt.subplots(1, 2, figsize=(14, 6))
        x_plot = np.linspace(0, max(theta) * 1.2, 200)

        ax = axes[0]
        ax.scatter(theta, loss, s=120, c='steelblue', zorder=5, edgecolors='white')
        if labels is not None:
            for t, l, lbl in zip(theta, loss, labels):
                ax.annotate(lbl, (t, l), fontsize=7, alpha=0.7,
                            textcoords="offset points", xytext=(3, 3))

        ax.plot(x_plot, popt_a[0] * x_plot, 'b-', linewidth=2,
                label=f'Linear: k={popt_a[0]:.3f}', alpha=0.7)

        def pw(x):
            return np.where(x < best_params[0],
                            best_params[1] * x,
                            best_params[1] * best_params[0] + best_params[2] * (x - best_params[0]))
        ax.plot(x_plot, pw(x_plot), 'r--', linewidth=2,
                label=f'Piecewise: kink at {best_params[0]:.2f}°')

        pred_128 = predicted_threshold(128)
        ax.axvline(x=pred_128, color='green', linestyle=':', linewidth=1.5,
                   alpha=0.6, label=f'arcsin(1/√128)={pred_128:.2f}°')
        ax.set_xlabel('θ̄ (degrees)', fontsize=12)
        ax.set_ylabel('|ΔMMLU| (pp)', fontsize=12)
        ax.set_title('Phase Transition Check', fontsize=13, fontweight='bold')
        ax.legend(fontsize=9)

        ax2 = axes[1]
        res_a = loss - popt_a[0] * theta
        res_b = loss - pw(theta)
        ax2.scatter(theta, res_a, s=80, alpha=0.7, label='Linear residuals')
        ax2.scatter(theta, res_b, s=80, alpha=0.7, label='Piecewise residuals')
        ax2.axhline(y=0, color='black', linestyle='-', linewidth=0.5)
        ax2.axvline(x=best_params[0], color='red', linestyle='--', alpha=0.5)
        ax2.set_xlabel('θ̄ (degrees)', fontsize=12)
        ax2.set_ylabel('Residual', fontsize=12)
        ax2.set_title('Residual Analysis', fontsize=13, fontweight='bold')
        ax2.legend(fontsize=9)

        plt.tight_layout()
        os.makedirs(output_dir, exist_ok=True)
        path = os.path.join(output_dir, 'phase_transition.png')
        plt.savefig(path, dpi=150, bbox_inches='tight', facecolor='white')
        plt.close()
    except Exception:
        pass


# ═══════════════════════════════════════════════════════════════════════════════
# CHECK 4 — Cross-Architecture Threshold Validation
# ═══════════════════════════════════════════════════════════════════════════════

def check_cross_architecture(
    model_results: List[Dict[str, Any]],
    output_dir: Optional[str] = None,
) -> Dict[str, Any]:
    """Compare predicted arcsin(1/√d) against empirical threshold across architectures.

    Args:
        model_results: List of dicts, each with ``"model"``, ``"d_head"``,
            and either ``"theta_per_head"`` or ``"empirical_split_deg"``.
        output_dir: Where to save (optional).

    Returns:
        Dict with per-model comparison and correlation.
    """
    predictions = []
    empiricals = []
    model_names = []

    for mr in model_results:
        model_name = mr.get("model", "unknown")
        d_head = mr.get("d_head")
        if d_head is None:
            d_head = HEAD_DIMS.get(model_name)
        if d_head is None:
            continue

        pred = predicted_threshold(d_head)
        emp = mr.get("empirical_split_deg")
        if emp is None and "theta_per_head" in mr:
            check = check_dimensionality_threshold(
                mr["theta_per_head"], d_head, model_name
            )
            emp = check.get("empirical_split_deg")

        if emp is not None:
            predictions.append(pred)
            empiricals.append(emp)
            model_names.append(model_name)

    if len(predictions) < 2:
        return {"error": "need at least 2 models with bimodal splits"}

    pred_arr = np.array(predictions)
    emp_arr = np.array(empiricals)
    correlation = float(np.corrcoef(pred_arr, emp_arr)[0, 1])
    mae = float(np.mean(np.abs(pred_arr - emp_arr)))

    result = {
        "n_models": len(predictions),
        "models": model_names,
        "predictions_deg": [round(p, 4) for p in predictions],
        "empiricals_deg": [round(e, 4) for e in empiricals],
        "correlation": round(correlation, 4),
        "mae_deg": round(mae, 4),
        "formula_confirmed": correlation > 0.7 and mae < 1.5,
    }

    if HAS_MATPLOTLIB and output_dir and len(predictions) >= 2:
        _plot_cross_architecture(pred_arr, emp_arr, model_names, correlation, output_dir)

    if output_dir:
        os.makedirs(output_dir, exist_ok=True)
        path = os.path.join(output_dir, 'cross_architecture_threshold.json')
        with open(path, 'w') as f:
            json.dump(result, f, indent=2)

    return result


def _plot_cross_architecture(predictions, empiricals, model_names, correlation, output_dir):
    """Plot predicted vs empirical threshold."""
    try:
        fig, ax = plt.subplots(figsize=(8, 8))
        ax.scatter(predictions, empiricals, s=150, c='steelblue',
                   edgecolors='white', zorder=5)
        for m, p, e in zip(model_names, predictions, empiricals):
            ax.annotate(m, (p, e), fontsize=9, alpha=0.8,
                        textcoords="offset points", xytext=(5, 5))
        lim_lo = min(min(predictions), min(empiricals)) - 0.5
        lim_hi = max(max(predictions), max(empiricals)) + 0.5
        ax.plot([lim_lo, lim_hi], [lim_lo, lim_hi], 'r--', linewidth=2,
                label='Perfect prediction', alpha=0.6)
        ax.set_xlabel('Predicted threshold arcsin(1/√d) (°)', fontsize=12)
        ax.set_ylabel('Empirical threshold (°)', fontsize=12)
        ax.set_title(f'Cross-Architecture Threshold Validation\nr = {correlation:.4f}',
                     fontsize=13, fontweight='bold')
        ax.legend(fontsize=10)
        ax.set_aspect('equal')
        os.makedirs(output_dir, exist_ok=True)
        path = os.path.join(output_dir, 'cross_architecture_threshold.png')
        plt.savefig(path, dpi=150, bbox_inches='tight', facecolor='white')
        plt.close()
    except Exception:
        pass


# ═══════════════════════════════════════════════════════════════════════════════
# MAIN ENTRY POINT
# ═══════════════════════════════════════════════════════════════════════════════

def run_threshold_analysis(
    geometry_results: Dict[str, Any],
    model_name: Optional[str] = None,
    d_head: Optional[int] = None,
    mmlu_base: Optional[float] = None,
    mmlu_after: Optional[float] = None,
    output_dir: Optional[str] = None,
) -> Dict[str, Any]:
    """Run all applicable threshold checks on geometry results from a single model.

    This is the main entry point — call after ``egora.compute_head_geometry()``.

    Args:
        geometry_results: Dict from ``egora.compute_head_geometry()``.
        model_name: Model identifier (e.g. ``"llama_8b"``).
            Used to auto-detect ``d_head`` from :data:`HEAD_DIMS`.
        d_head: Head dimension (auto-detected if ``model_name`` is known).
        mmlu_base: Base model MMLU (%) — needed for k-check.
        mmlu_after: Fine-tuned model MMLU (%) — needed for k-check.
        output_dir: Base directory for output files.

    Returns:
        Dict with all check results.
    """
    if model_name and d_head is None:
        d_head = HEAD_DIMS.get(model_name)

    if d_head is None:
        return {"error": "d_head not known — provide d_head or a known model_name"}

    if output_dir is None:
        output_dir = "."

    threshold_dir = os.path.join(output_dir, "threshold_analysis")
    os.makedirs(threshold_dir, exist_ok=True)

    all_results: Dict[str, Any] = {"model": model_name, "d_head": d_head}

    # Extract theta per head
    thetas = None
    if "heads" in geometry_results:
        thetas = np.array([h["rotation_angle_deg"] for h in geometry_results["heads"]])

    # CHECK 1 — Dimensionality threshold
    if thetas is not None:
        check1 = check_dimensionality_threshold(
            thetas, d_head, model_name=model_name or "model",
            output_dir=threshold_dir
        )
        all_results["dimensionality_check"] = check1

    # CHECK 2 — Golden ratio k
    if mmlu_base is not None and mmlu_after is not None:
        theta_bar = geometry_results.get("theta_bar_deg", 0)
        mmlu_delta = mmlu_after - mmlu_base
        check2 = check_golden_ratio_k(
            theta_bar, mmlu_delta,
            model_name=model_name or "model",
            output_dir=threshold_dir
        )
        all_results["golden_ratio_k"] = check2

    # Save combined results
    combined_path = os.path.join(threshold_dir, 'threshold_analysis_summary.json')
    with open(combined_path, 'w') as f:
        json.dump(all_results, f, indent=2, default=str)

    return all_results
