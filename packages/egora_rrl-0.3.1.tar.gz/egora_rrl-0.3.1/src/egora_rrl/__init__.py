"""
EgoRA RRL — Rotation-Retention Law & Knowledge Mapping
========================================================

Advanced diagnostic tools for analyzing fine-tuned neural networks.
Companion package to `egora <https://pypi.org/project/egora/>`_.

Three modules:

1. **Threshold Analysis** — Tests the Rotation-Retention Law:
   θ_crit = arcsin(1/√d_head), golden ratio k-check, phase transition detection.

2. **Knowledge Map** — Logit lens, attention probing, and Knowledge
   Concentration Index (KCI) to locate where knowledge lives in the model.

3. **Alignment Landscape** — Per-head gradient alignment between fine-tuning
   and capability-preservation directions. Identifies critical heads.

Quick start::

    from egora import compute_head_geometry
    from egora_rrl import run_threshold_analysis, run_knowledge_map

    # After fine-tuning with EgoRA:
    geo = compute_head_geometry(base_model, tuned_model)

    # Rotation-Retention Law analysis
    results = run_threshold_analysis(
        geo, model_name="llama_8b",
        mmlu_base=63.42, mmlu_after=62.86,
        output_dir="analysis/",
    )

    # Knowledge map
    summary = run_knowledge_map(model, tokenizer, output_dir="analysis/")
"""

from egora_rrl._version import __version__

# ── Threshold Analysis (Rotation-Retention Law) ──────────────────────────────
from egora_rrl.threshold import (
    run_threshold_analysis,
    predicted_threshold,
    check_dimensionality_threshold,
    check_golden_ratio_k,
    check_golden_ratio_k_aggregate,
    check_phase_transition,
    check_cross_architecture,
    HEAD_DIMS,
)

# ── Knowledge Map ─────────────────────────────────────────────────────────────
from egora_rrl.knowledge_map import (
    run_knowledge_map,
    logit_lens,
    attention_probe,
    knowledge_concentration_index,
    KNOWLEDGE_DOMAINS,
)

# ── Alignment Landscape ──────────────────────────────────────────────────────
from egora_rrl.alignment import (
    run_alignment_landscape,
    compute_capability_gradient,
    compute_finetune_gradient,
    compute_alignment,
    identify_critical_heads,
    compute_cross_modal_alignment,
    identify_universal_critical_heads,
)

__all__ = [
    "__version__",
    # Threshold
    "run_threshold_analysis",
    "predicted_threshold",
    "check_dimensionality_threshold",
    "check_golden_ratio_k",
    "check_golden_ratio_k_aggregate",
    "check_phase_transition",
    "check_cross_architecture",
    "HEAD_DIMS",
    # Knowledge Map
    "run_knowledge_map",
    "logit_lens",
    "attention_probe",
    "knowledge_concentration_index",
    "KNOWLEDGE_DOMAINS",
    # Alignment
    "run_alignment_landscape",
    "compute_capability_gradient",
    "compute_finetune_gradient",
    "compute_alignment",
    "identify_critical_heads",
    "compute_cross_modal_alignment",
    "identify_universal_critical_heads",
]
