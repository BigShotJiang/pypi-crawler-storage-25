"""
Alignment Landscape — Per-Head Gradient Alignment
====================================================
Computes the cosine alignment between fine-tuning gradients and
capability-preservation gradients (MMLU, vision, audio benchmarks).

For each attention head *i*:

  αᵢ = cos(g_i^tune, g_i^MMLU)

- αᵢ ≈ +1  → fine-tuning *improves* this capability
- αᵢ ≈  0  → orthogonal (neutral)
- αᵢ ≈ −1  → fine-tuning *destroys* this capability → **CRITICAL HEAD**

Usage::

    from egora_rrl.alignment import run_alignment_landscape

    results = run_alignment_landscape(
        model, tokenizer, train_loader,
        output_dir="analysis/",
        modality="text",
    )
    print(f"Critical heads: {results['mmlu_alignment']['n_critical']}")
"""

import json
import os
from collections import defaultdict
from typing import Any, Dict, List, Optional, Sequence

import numpy as np
import torch
import torch.nn.functional as F


DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


# ═══════════════════════════════════════════════════════════════════════════════
# Gradient extraction helpers
# ═══════════════════════════════════════════════════════════════════════════════

def _collect_target_param_names(
    model: torch.nn.Module,
    target_modules: Optional[List[str]] = None,
) -> List[str]:
    """Get names of all target attention projection weight parameters."""
    if target_modules is None:
        target_modules = ['q_proj', 'k_proj', 'v_proj', 'o_proj']
    names = []
    for name, param in model.named_parameters():
        for tm in target_modules:
            if (f".{tm}." in name or name.endswith(f".{tm}.weight")) and name.endswith('.weight'):
                names.append(name)
                break
    return names


def _extract_per_head_gradients(
    model: torch.nn.Module,
    target_param_names: List[str],
) -> Dict[str, torch.Tensor]:
    """Extract gradient vector per target parameter after a backward pass.

    Returns:
        Dict mapping parameter name to flattened gradient tensor (CPU).
    """
    grads = {}
    for name, param in model.named_parameters():
        if name in target_param_names and param.grad is not None:
            grads[name] = param.grad.float().flatten().cpu().clone()
    return grads


def _parse_head_info(name: str):
    """Extract layer number and projection type from parameter name."""
    layer_num = None
    proj_type = None
    for part in name.split('.'):
        if part.isdigit():
            layer_num = int(part)
        if part in ('q_proj', 'k_proj', 'v_proj', 'o_proj', 'qkv_proj', 'out_proj'):
            proj_type = part
    if proj_type is None:
        for tm in ['q_proj', 'k_proj', 'v_proj', 'o_proj', 'qkv_proj', 'out_proj']:
            if tm in name:
                proj_type = tm
                break
    return layer_num, proj_type


# ═══════════════════════════════════════════════════════════════════════════════
# Capability gradient computation
# ═══════════════════════════════════════════════════════════════════════════════

def compute_capability_gradient(
    model: torch.nn.Module,
    tokenizer,
    benchmark: str = 'mmlu',
    max_samples: int = 500,
    target_modules: Optional[List[str]] = None,
) -> Dict[str, torch.Tensor]:
    """Compute per-head gradient of a capability benchmark loss.

    This is ∇_{uᵢ} L_benchmark — the direction the weights would need
    to move to *improve* the benchmark score.

    Args:
        model: The fine-tuned model (with or without LoRA merged).
        tokenizer: The tokenizer.
        benchmark: ``'mmlu'``, ``'mmbench'``, or ``'librispeech'``.
        max_samples: Number of benchmark samples for gradient estimation.
        target_modules: Which projection layers to analyze.

    Returns:
        Dict mapping parameter name to gradient tensor (flattened CPU).
    """
    target_param_names = _collect_target_param_names(model, target_modules)

    original_requires_grad = {}
    for name, param in model.named_parameters():
        original_requires_grad[name] = param.requires_grad
        if name in target_param_names:
            param.requires_grad_(True)
        else:
            param.requires_grad_(False)

    model.zero_grad()
    model.eval()

    if benchmark == 'mmlu':
        _accumulate_mmlu_gradient(model, tokenizer, max_samples)
    elif benchmark == 'mmbench':
        _accumulate_text_qa_gradient(model, tokenizer, max_samples,
                                      dataset_name='mmbench')
    elif benchmark == 'librispeech':
        _accumulate_text_qa_gradient(model, tokenizer, max_samples,
                                      dataset_name='librispeech_proxy')
    else:
        _accumulate_mmlu_gradient(model, tokenizer, max_samples)

    grads = _extract_per_head_gradients(model, target_param_names)

    for name, param in model.named_parameters():
        param.requires_grad_(original_requires_grad[name])

    model.zero_grad()
    return grads


def _accumulate_mmlu_gradient(model, tokenizer, max_samples=500):
    """Forward-backward on MMLU samples to accumulate gradient."""
    from datasets import load_dataset

    try:
        ds = load_dataset("cais/mmlu", "all", split="test")
    except Exception:
        try:
            ds = load_dataset("lukaemon/mmlu", "all", split="test")
        except Exception:
            ds = load_dataset("tasksource/mmlu", "all", split="test")

    if len(ds) > max_samples:
        indices = np.random.choice(len(ds), max_samples, replace=False)
        ds = ds.select(indices)

    choices = ['A', 'B', 'C', 'D']

    for item in ds:
        question = item.get('question', '')
        answer_idx = item.get('answer', 0)
        if isinstance(answer_idx, str):
            answer_idx = choices.index(answer_idx) if answer_idx in choices else 0

        option_texts = []
        for key in choices:
            opt = item.get(key, item.get('choices', [''] * 4)[choices.index(key)] if 'choices' in item else '')
            if isinstance(opt, list):
                opt = opt[choices.index(key)] if choices.index(key) < len(opt) else ''
            option_texts.append(str(opt))

        prompt = f"Question: {question}\n"
        for i, opt in enumerate(option_texts):
            prompt += f"{choices[i]}. {opt}\n"
        prompt += "Answer: "
        target = choices[answer_idx]
        full_text = prompt + target

        try:
            tokens = tokenizer(full_text, return_tensors='pt', truncation=True,
                                max_length=512).to(DEVICE)
            labels = tokens['input_ids'].clone()
            prompt_tokens = tokenizer(prompt, return_tensors='pt', truncation=True,
                                       max_length=512)
            prompt_len = prompt_tokens['input_ids'].shape[1]
            labels[0, :prompt_len] = -100
            outputs = model(**tokens, labels=labels)
            loss = outputs.loss / max_samples
            loss.backward()
        except Exception:
            continue


def _accumulate_text_qa_gradient(model, tokenizer, max_samples=500,
                                   dataset_name='mmbench'):
    """Generic text QA gradient accumulation for vision/audio proxy benchmarks."""
    from datasets import load_dataset

    if dataset_name == 'librispeech_proxy':
        try:
            ds = load_dataset("wikitext", "wikitext-2-raw-v1", split="test")
        except Exception:
            return
    else:
        try:
            ds = load_dataset("cais/mmlu", "all", split="test")
        except Exception:
            return

    if len(ds) > max_samples:
        indices = np.random.choice(len(ds), max_samples, replace=False)
        ds = ds.select(indices)

    for item in ds:
        text = item.get('text', item.get('question', ''))
        if not text or len(text.strip()) < 20:
            continue
        try:
            tokens = tokenizer(text, return_tensors='pt', truncation=True,
                                max_length=256).to(DEVICE)
            labels = tokens['input_ids'].clone()
            outputs = model(**tokens, labels=labels)
            loss = outputs.loss / max_samples
            loss.backward()
        except Exception:
            continue


# ═══════════════════════════════════════════════════════════════════════════════
# Fine-tuning gradient extraction
# ═══════════════════════════════════════════════════════════════════════════════

def compute_finetune_gradient(
    model: torch.nn.Module,
    train_loader,
    max_batches: int = 50,
    target_modules: Optional[List[str]] = None,
) -> Dict[str, torch.Tensor]:
    """Compute per-head gradient of the fine-tuning loss.

    This is ∇_{uᵢ} L_tune — the direction fine-tuning pushes each head.

    Args:
        model: The model (during training or loaded from checkpoint).
        train_loader: Training data loader.
        max_batches: Number of batches to average over.
        target_modules: Which projection layers to analyze.

    Returns:
        Dict mapping parameter name to gradient tensor (flattened CPU).
    """
    target_param_names = _collect_target_param_names(model, target_modules)

    original_requires_grad = {}
    for name, param in model.named_parameters():
        original_requires_grad[name] = param.requires_grad
        if name in target_param_names:
            param.requires_grad_(True)
        else:
            param.requires_grad_(False)

    model.zero_grad()
    model.train()

    n_batches = 0
    for batch in train_loader:
        if n_batches >= max_batches:
            break
        try:
            input_ids = batch['input_ids'].to(DEVICE)
            attention_mask = batch['attention_mask'].to(DEVICE)
            labels = batch['labels'].to(DEVICE)
            outputs = model(input_ids=input_ids, attention_mask=attention_mask,
                            labels=labels)
            loss = outputs.loss / max_batches
            loss.backward()
            n_batches += 1
        except Exception:
            continue

    grads = _extract_per_head_gradients(model, target_param_names)

    for name, param in model.named_parameters():
        param.requires_grad_(original_requires_grad[name])
    model.zero_grad()

    return grads


# ═══════════════════════════════════════════════════════════════════════════════
# Alignment computation
# ═══════════════════════════════════════════════════════════════════════════════

def compute_alignment(
    grad_capability: Dict[str, torch.Tensor],
    grad_finetune: Dict[str, torch.Tensor],
    target_modules: Optional[List[str]] = None,
) -> tuple:
    """Compute per-head cosine alignment between capability and fine-tuning gradients.

    αᵢ = cos(g_i^capability, g_i^tune)

    Args:
        grad_capability: Per-head capability gradients.
        grad_finetune: Per-head fine-tuning gradients.
        target_modules: Unused, kept for API compatibility.

    Returns:
        Tuple of ``(heads_list, alphas_array)``.
    """
    heads = []
    alphas = []

    common_names = sorted(set(grad_capability.keys()) & set(grad_finetune.keys()))

    for name in common_names:
        g_cap = grad_capability[name]
        g_tune = grad_finetune[name]

        alpha = F.cosine_similarity(
            g_cap.unsqueeze(0), g_tune.unsqueeze(0)
        ).item()

        mag_cap = g_cap.norm().item()
        mag_tune = g_tune.norm().item()
        layer_num, proj_type = _parse_head_info(name)

        heads.append({
            'name': name,
            'layer': layer_num,
            'proj_type': proj_type,
            'alpha': alpha,
            'grad_magnitude_capability': mag_cap,
            'grad_magnitude_finetune': mag_tune,
        })
        alphas.append(alpha)

    alphas = np.array(alphas)
    return heads, alphas


def identify_critical_heads(
    heads: List[Dict[str, Any]],
    alphas: np.ndarray,
    threshold: float = -0.7,
) -> List[Dict[str, Any]]:
    """Identify critical heads — those with α < threshold (anti-aligned).

    These are heads where fine-tuning pushes directly away from the
    capability benchmark — maximum knowledge destruction.

    Args:
        heads: Per-head info from :func:`compute_alignment`.
        alphas: Array of α values.
        threshold: Alignment threshold for "critical" classification.

    Returns:
        List of critical head dicts, sorted by severity.
    """
    critical = []
    for h, a in zip(heads, alphas):
        if a < threshold:
            critical.append({**h, 'severity': abs(a)})

    critical.sort(key=lambda x: -x['severity'])
    return critical


# ═══════════════════════════════════════════════════════════════════════════════
# Cross-modal alignment
# ═══════════════════════════════════════════════════════════════════════════════

def compute_cross_modal_alignment(
    grad_mmlu: Dict[str, torch.Tensor],
    grad_modal: Dict[str, torch.Tensor],
    grad_tune: Dict[str, torch.Tensor],
) -> List[Dict[str, Any]]:
    """Compute three alignment values per head for cross-modal analysis.

    For each head *i*:
      - α_i^MMLU  = cos(g_i^tune, g_i^MMLU) — text knowledge alignment
      - α_i^modal = cos(g_i^tune, g_i^modal) — modal knowledge alignment
      - α_i^cross = cos(g_i^MMLU, g_i^modal) — cross-modal alignment

    Args:
        grad_mmlu: MMLU capability gradients.
        grad_modal: Modal (vision/audio) capability gradients.
        grad_tune: Fine-tuning gradients.

    Returns:
        List of per-head dicts with the three alignment values.
    """
    common = sorted(set(grad_mmlu.keys()) & set(grad_modal.keys()) & set(grad_tune.keys()))

    heads = []
    for name in common:
        g_mmlu = grad_mmlu[name]
        g_modal = grad_modal[name]
        g_tune = grad_tune[name]

        alpha_mmlu = F.cosine_similarity(g_tune.unsqueeze(0), g_mmlu.unsqueeze(0)).item()
        alpha_modal = F.cosine_similarity(g_tune.unsqueeze(0), g_modal.unsqueeze(0)).item()
        alpha_cross = F.cosine_similarity(g_mmlu.unsqueeze(0), g_modal.unsqueeze(0)).item()

        layer_num, proj_type = _parse_head_info(name)
        heads.append({
            'name': name,
            'layer': layer_num,
            'proj_type': proj_type,
            'alpha_mmlu': alpha_mmlu,
            'alpha_modal': alpha_modal,
            'alpha_cross': alpha_cross,
        })

    return heads


def identify_universal_critical_heads(
    cross_heads: List[Dict[str, Any]],
    threshold: float = -0.5,
) -> List[Dict[str, Any]]:
    """Find heads that are critical across BOTH modalities.

    Universal critical = α_mmlu < threshold AND α_modal < threshold.

    Args:
        cross_heads: Output of :func:`compute_cross_modal_alignment`.
        threshold: Alignment threshold.

    Returns:
        List of universal critical head dicts.
    """
    universal = []
    for h in cross_heads:
        if h['alpha_mmlu'] < threshold and h['alpha_modal'] < threshold:
            universal.append({
                **h,
                'severity': (abs(h['alpha_mmlu']) + abs(h['alpha_modal'])) / 2,
            })

    universal.sort(key=lambda x: -x['severity'])
    return universal


# ═══════════════════════════════════════════════════════════════════════════════
# Full pipeline
# ═══════════════════════════════════════════════════════════════════════════════

def _save_gradient_npy(grads: Dict[str, torch.Tensor], path: str) -> None:
    """Save per-head gradients as a .npz file."""
    npz_path = path.replace('.npy', '.npz')
    np.savez(npz_path, **{name: g.numpy() for name, g in grads.items()})


def run_alignment_landscape(
    model: torch.nn.Module,
    tokenizer,
    train_loader,
    output_dir: str,
    target_modules: Optional[List[str]] = None,
    modality: str = 'text',
    capability_benchmarks: Optional[List[str]] = None,
    max_capability_samples: int = 500,
    max_tune_batches: int = 50,
) -> Dict[str, Any]:
    """Full alignment landscape computation and saving.

    Args:
        model: Fine-tuned model.
        tokenizer: Tokenizer.
        train_loader: Training data (for fine-tuning gradient).
        output_dir: Where to save results (``alignment_landscape/`` subfolder).
        target_modules: Projection layers to analyze.
        modality: ``'text'``, ``'text+image'``, ``'audio'``, or ``'text+audio'``.
        capability_benchmarks: Override which benchmarks to compute gradients for.
        max_capability_samples: Samples per benchmark gradient.
        max_tune_batches: Batches for fine-tuning gradient.

    Returns:
        Dict with all alignment results.
    """
    al_dir = os.path.join(output_dir, 'alignment_landscape')
    os.makedirs(al_dir, exist_ok=True)

    # 1. Fine-tuning gradient
    grad_tune = compute_finetune_gradient(
        model, train_loader, max_batches=max_tune_batches,
        target_modules=target_modules
    )
    if grad_tune:
        _save_gradient_npy(grad_tune, os.path.join(al_dir, 'tune_gradient_per_head.npy'))

    # 2. MMLU capability gradient
    grad_mmlu = None
    if modality in ('text', 'text+image', 'text+audio'):
        grad_mmlu = compute_capability_gradient(
            model, tokenizer, benchmark='mmlu',
            max_samples=max_capability_samples, target_modules=target_modules
        )
        if grad_mmlu:
            _save_gradient_npy(grad_mmlu, os.path.join(al_dir, 'mmlu_gradient_per_head.npy'))

    # 3. Compute alignment
    results: Dict[str, Any] = {}
    if grad_mmlu and grad_tune:
        heads, alphas = compute_alignment(grad_mmlu, grad_tune, target_modules)
        np.save(os.path.join(al_dir, 'cosine_alignment.npy'), alphas)

        critical = identify_critical_heads(heads, alphas)
        with open(os.path.join(al_dir, 'critical_heads.json'), 'w') as f:
            json.dump(critical, f, indent=2)

        results['mmlu_alignment'] = {
            'heads': heads,
            'alphas': alphas.tolist(),
            'mean_alpha': float(np.mean(alphas)),
            'std_alpha': float(np.std(alphas)),
            'n_critical': len(critical),
            'n_total': len(heads),
            'critical_fraction': len(critical) / max(len(heads), 1),
        }

    # 4. Cross-modal (vision/audio models only)
    grad_modal = None
    if modality == 'text+image':
        grad_modal = compute_capability_gradient(
            model, tokenizer, benchmark='mmbench',
            max_samples=max_capability_samples, target_modules=target_modules
        )
    elif modality in ('audio', 'text+audio'):
        grad_modal = compute_capability_gradient(
            model, tokenizer, benchmark='librispeech',
            max_samples=max_capability_samples, target_modules=target_modules
        )

    if grad_modal:
        _save_gradient_npy(grad_modal, os.path.join(al_dir, 'modal_gradient_per_head.npy'))

        if grad_mmlu and grad_tune:
            cross_dir = os.path.join(output_dir, 'cross_modal')
            os.makedirs(cross_dir, exist_ok=True)

            cross_heads = compute_cross_modal_alignment(grad_mmlu, grad_modal, grad_tune)
            alpha_cross = np.array([h['alpha_cross'] for h in cross_heads])
            np.save(os.path.join(cross_dir, 'cross_modal_alignment.npy'), alpha_cross)

            universal = identify_universal_critical_heads(cross_heads)
            with open(os.path.join(cross_dir, 'universal_critical_heads.json'), 'w') as f:
                json.dump(universal, f, indent=2)

            results['cross_modal'] = {
                'heads': cross_heads,
                'n_universal_critical': len(universal),
                'n_total': len(cross_heads),
            }

    # Save summary
    summary = {k: v for k, v in results.items()}
    if 'mmlu_alignment' in summary and 'heads' in summary['mmlu_alignment']:
        summary['mmlu_alignment'] = {k: v for k, v in summary['mmlu_alignment'].items()
                                      if k != 'heads'}
    with open(os.path.join(al_dir, 'alignment_summary.json'), 'w') as f:
        json.dump(summary, f, indent=2, default=str)

    return results
