"""installation status checker for mbo_utilities optional dependencies.

checks for proper GPU configuration of suite2p (pytorch), suite3d (cupy),
and rastermap. provides structured data for CLI and GUI display.

also provides HAS_* flags for quick import checks without actually importing.
uses environment cache for faster repeated checks.
"""

from dataclasses import dataclass, field
from enum import Enum
import importlib.util
import subprocess
import sys
import contextlib


# quick import availability checks (no actual imports)
def _check_import(module_name: str) -> bool:
    """check if a module can be imported without actually importing it."""
    return importlib.util.find_spec(module_name) is not None


def _get_cached_flag(key: str, fallback_check: callable) -> bool:
    """get flag from cache if valid, otherwise compute and return."""
    try:
        from mbo_utilities.env_cache import get_cached_packages
        cached = get_cached_packages()
        if cached and key in cached:
            return cached[key].get("available", False)
    except Exception:
        pass
    return fallback_check()


def _has_working_suite3d_from_cache() -> bool | None:
    """Check cached install_status for a *working* suite3d (cupy GPU OK).

    Returns True/False when the cache is valid, None when the cache is missing
    so the caller can fall back to a cheap import probe.
    """
    try:
        from mbo_utilities.env_cache import get_cached_install_status
        status = get_cached_install_status()
        if status is None:
            return None
        suite3d_feat = next((f for f in status.features if f.name == "Suite3D"), None)
        if suite3d_feat is None:
            return None
        return suite3d_feat.status == Status.OK
    except Exception:
        return None


# HAS_* flags - use cache when available, fallback to direct check
HAS_SUITE2P: bool = _get_cached_flag(
    "suite2p", lambda: _check_import("lbm_suite2p_python") and _check_import("suite2p")
)
def _resolve_has_suite3d() -> bool:
    """Resolve HAS_SUITE3D.

    Prefer the cached install_status (which knows whether cupy actually
    initializes the GPU and matches the driver). Fall back to a cheap
    importability check that requires both `suite3d` and `cupy` to be
    importable. Note: the cheap fallback can be optimistic — it does not
    detect a cupy that imports but fails on first GPU call.
    """
    cached = _has_working_suite3d_from_cache()
    if cached is not None:
        return cached
    return _check_import("suite3d") and _check_import("cupy")


HAS_SUITE3D: bool = _resolve_has_suite3d()
HAS_CUPY: bool = _get_cached_flag(
    "cupy", lambda: _check_import("cupy")
)
HAS_TORCH: bool = _get_cached_flag(
    "torch", lambda: _check_import("torch")
)
HAS_RASTERMAP: bool = _get_cached_flag(
    "rastermap", lambda: _check_import("rastermap")
)
HAS_IMGUI: bool = _get_cached_flag(
    "imgui_bundle", lambda: _check_import("imgui_bundle")
)
HAS_FASTPLOTLIB: bool = _get_cached_flag(
    "fastplotlib", lambda: _check_import("fastplotlib")
)
HAS_PYQT6: bool = _get_cached_flag(
    "pyqt6", lambda: _check_import("PyQt6")
)
HAS_NAPARI: bool = _get_cached_flag(
    "napari", lambda: _check_import("napari")
)
HAS_NAPARI_OME_ZARR: bool = _get_cached_flag(
    "napari_ome_zarr", lambda: _check_import("napari_ome_zarr")
)
HAS_NAPARI_ANIMATION: bool = _get_cached_flag(
    "napari_animation", lambda: _check_import("napari_animation")
)


class Status(Enum):
    """installation status for a feature."""

    OK = "ok"           # installed and working
    WARN = "warn"       # installed but degraded (e.g., no GPU)
    ERROR = "error"     # installed but broken
    MISSING = "missing" # not installed


@dataclass
class FeatureStatus:
    """status of a single feature/package."""

    name: str
    status: Status
    version: str = ""
    message: str = ""
    gpu_ok: bool | None = None  # None = n/a, True/False for GPU features


@dataclass
class CudaInfo:
    """cuda environment information."""

    nvcc_version: str | None = None      # cuda toolkit version (nvcc)
    driver_version: str | None = None    # nvidia driver cuda version (nvidia-smi)
    pytorch_cuda: str | None = None      # pytorch compiled cuda version
    cupy_cuda: str | None = None         # cupy cuda runtime version
    device_name: str | None = None       # gpu name
    device_count: int = 0


@dataclass
class InstallStatus:
    """complete installation status."""

    mbo_version: str = ""
    python_version: str = ""
    cuda_info: CudaInfo = field(default_factory=CudaInfo)
    features: list[FeatureStatus] = field(default_factory=list)

    @property
    def all_ok(self) -> bool:
        """True if all installed features are working properly."""
        return all(f.status in (Status.OK, Status.MISSING) for f in self.features)


def recommended_cupy_package(driver_cuda: str | None = None) -> str:
    """Pick the cupy wheel that matches the detected CUDA driver.

    Parameters
    ----------
    driver_cuda : str | None
        Driver-supported CUDA version (e.g. "12.4", "13.0"). If None, the
        function probes nvidia-smi.

    Returns
    -------
    str
        The pip package name (e.g. "cupy-cuda12x"). Falls back to
        "cupy-cuda12x" when the CUDA major version cannot be determined,
        since CUDA 12 currently has the broadest cupy wheel coverage.
    """
    if driver_cuda is None:
        driver_cuda = _get_nvidia_smi_cuda()
    if driver_cuda:
        try:
            major = int(str(driver_cuda).split(".")[0])
        except (ValueError, IndexError):
            major = None
        if major is not None:
            # cupy ships separate wheels per CUDA major: cupy-cuda11x,
            # cupy-cuda12x, cupy-cuda13x. anything older falls back to 11x.
            if major >= 13:
                return "cupy-cuda13x"
            if major >= 12:
                return "cupy-cuda12x"
            return "cupy-cuda11x"
    return "cupy-cuda12x"


def cupy_install_hint(driver_cuda: str | None = None) -> str:
    """Human-readable install hint, e.g. 'uv pip install cupy-cuda12x'."""
    pkg = recommended_cupy_package(driver_cuda)
    return f"uv pip install {pkg}"


def _get_nvcc_version() -> str | None:
    """Get cuda toolkit version from nvcc."""
    try:
        result = subprocess.run(
            ["nvcc", "--version"],
            check=False, capture_output=True,
            text=True,
            timeout=5
        )
        if result.returncode == 0:
            # parse "release X.Y" from output
            for line in result.stdout.split("\n"):
                if "release" in line.lower():
                    parts = line.split("release")[-1].strip().split(",")[0]
                    return parts.strip()
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass
    return None


def _get_nvidia_smi_cuda() -> str | None:
    """Get driver-supported cuda version from nvidia-smi."""
    try:
        result = subprocess.run(
            ["nvidia-smi", "--query-gpu=driver_version", "--format=csv,noheader"],
            check=False, capture_output=True,
            text=True,
            timeout=5
        )
        if result.returncode == 0:
            # also get cuda version
            result2 = subprocess.run(
                ["nvidia-smi"],
                check=False, capture_output=True,
                text=True,
                timeout=5
            )
            if result2.returncode == 0:
                # parse "CUDA Version: X.Y" from output
                for line in result2.stdout.split("\n"):
                    if "CUDA Version" in line:
                        return line.split("CUDA Version:")[-1].strip().split()[0]
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass
    return None


def _check_pytorch() -> tuple[FeatureStatus, str | None]:
    """Check pytorch installation and cuda support."""
    pytorch_cuda = None
    try:
        import torch
        version = torch.__version__

        # check cuda availability
        if torch.cuda.is_available():
            pytorch_cuda = torch.version.cuda
            device_name = torch.cuda.get_device_name(0)
            return FeatureStatus(
                name="PyTorch",
                status=Status.OK,
                version=version,
                message=f"CUDA {pytorch_cuda}, {device_name}",
                gpu_ok=True
            ), pytorch_cuda
        # pytorch installed but no cuda
        pytorch_cuda = getattr(torch.version, "cuda", None)
        return FeatureStatus(
            name="PyTorch",
            status=Status.WARN,
            version=version,
            message="CPU only (no CUDA)",
            gpu_ok=False
        ), pytorch_cuda
    except ImportError:
        return FeatureStatus(
            name="PyTorch",
            status=Status.MISSING,
            message="not installed"
        ), None


def _check_cupy(driver_cuda: str | None = None) -> tuple[FeatureStatus, str | None]:
    """Check cupy installation and cuda support.

    When cupy is missing, broken, or built against a CUDA major version that
    does not match the installed driver, the returned message embeds a
    `uv pip install cupy-cudaXXx` hint matching the driver.
    """
    cupy_cuda = None
    install_hint = cupy_install_hint(driver_cuda)
    try:
        import cupy as cp
        version = cp.__version__

        # check cuda functionality
        try:
            # simple cuda test
            _ = cp.array([1, 2, 3])
            cuda_ver = cp.cuda.runtime.runtimeGetVersion()
            cuda_major = cuda_ver // 1000
            cuda_minor = (cuda_ver % 1000) // 10
            cupy_cuda = f"{cuda_major}.{cuda_minor}"

            # detect driver/cupy major mismatch (e.g. cupy-cuda11x on a CUDA 13 driver)
            if driver_cuda:
                try:
                    drv_major = int(str(driver_cuda).split(".")[0])
                    if drv_major != cuda_major:
                        return FeatureStatus(
                            name="CuPy",
                            status=Status.ERROR,
                            version=version,
                            message=(
                                f"CuPy built for CUDA {cuda_major}.x but driver "
                                f"is CUDA {driver_cuda}. Reinstall: {install_hint}"
                            ),
                            gpu_ok=False,
                        ), cupy_cuda
                except (ValueError, IndexError):
                    pass

            # test nvrtc (required for suite3d)
            try:
                kernel = cp.ElementwiseKernel(
                    "float32 x", "float32 y", "y = x * 2", "test_kernel"
                )
                test_in = cp.array([1.0], dtype="float32")
                test_out = cp.empty_like(test_in)
                kernel(test_in, test_out)

                device = cp.cuda.Device()
                device_name = device.attributes.get("Name", "GPU")
                return FeatureStatus(
                    name="CuPy",
                    status=Status.OK,
                    version=version,
                    message=f"CUDA {cupy_cuda}, {device_name}",
                    gpu_ok=True
                ), cupy_cuda
            except Exception:
                return FeatureStatus(
                    name="CuPy",
                    status=Status.ERROR,
                    version=version,
                    message=f"NVRTC missing (install CUDA toolkit, or: {install_hint})",
                    gpu_ok=False
                ), cupy_cuda
        except Exception as e:
            return FeatureStatus(
                name="CuPy",
                status=Status.ERROR,
                version=version,
                message=f"CUDA init failed: {str(e)[:40]} (try: {install_hint})",
                gpu_ok=False
            ), None
    except ImportError:
        return FeatureStatus(
            name="CuPy",
            status=Status.MISSING,
            message=f"not installed ({install_hint})",
        ), None


def _check_suite2p() -> FeatureStatus:
    """Check suite2p installation."""
    try:
        import suite2p
        version = getattr(suite2p, "__version__", "installed")
        return FeatureStatus(
            name="Suite2p",
            status=Status.OK,
            version=version,
            message="ready"
        )
    except ImportError:
        return FeatureStatus(
            name="Suite2p",
            status=Status.MISSING,
            message="not installed"
        )


def _check_suite3d(cupy_status: FeatureStatus | None = None, driver_cuda: str | None = None) -> FeatureStatus:
    """Check suite3d installation.

    Suite3D requires a working CuPy install. If `cupy_status` indicates CuPy
    is missing or broken, this returns MISSING with the cupy install hint —
    importing suite3d alone is not enough to make it usable.
    """
    try:
        import suite3d
        version = getattr(suite3d, "__version__", "installed")
    except ImportError:
        return FeatureStatus(
            name="Suite3D",
            status=Status.MISSING,
            message="not installed",
        )

    # cupy is mandatory for suite3d preprocessing — if it's missing or broken
    # the user effectively does not have a working suite3d install.
    if cupy_status is None or cupy_status.status in (Status.MISSING, Status.ERROR):
        hint = cupy_install_hint(driver_cuda)
        if cupy_status is None or cupy_status.status == Status.MISSING:
            why = "CuPy not installed"
        else:
            why = f"CuPy broken: {cupy_status.message}"
        return FeatureStatus(
            name="Suite3D",
            status=Status.MISSING,
            version=version,
            message=f"unavailable - {why}. Try: {hint}",
        )

    return FeatureStatus(
        name="Suite3D",
        status=Status.OK,
        version=version,
        message="ready",
    )


def _check_rastermap() -> FeatureStatus:
    """Check rastermap installation."""
    try:
        import rastermap
        version = getattr(rastermap, "__version__", "installed")
        return FeatureStatus(
            name="Rastermap",
            status=Status.OK,
            version=version,
            message="ready"
        )
    except ImportError:
        return FeatureStatus(
            name="Rastermap",
            status=Status.MISSING,
            message="not installed"
        )


def _check_napari() -> FeatureStatus:
    """Check napari installation."""
    try:
        import napari
        version = getattr(napari, "__version__", "installed")
        return FeatureStatus(
            name="Napari",
            status=Status.OK,
            version=version,
            message="ready"
        )
    except ImportError:
        return FeatureStatus(
            name="Napari",
            status=Status.MISSING,
            message="not installed (pip install napari[all])"
        )


def _check_napari_ome_zarr() -> FeatureStatus:
    """Check napari-ome-zarr plugin installation."""
    try:
        import napari_ome_zarr
        version = getattr(napari_ome_zarr, "__version__", "installed")
        return FeatureStatus(
            name="napari-ome-zarr",
            status=Status.OK,
            version=version,
            message="ready"
        )
    except ImportError:
        return FeatureStatus(
            name="napari-ome-zarr",
            status=Status.MISSING,
            message="not installed (pip install napari-ome-zarr)"
        )


def _check_napari_animation() -> FeatureStatus:
    """Check napari-animation plugin installation."""
    try:
        import napari_animation
        version = getattr(napari_animation, "__version__", "installed")
        return FeatureStatus(
            name="napari-animation",
            status=Status.OK,
            version=version,
            message="ready"
        )
    except ImportError:
        return FeatureStatus(
            name="napari-animation",
            status=Status.MISSING,
            message="not installed (pip install napari-animation)"
        )


def check_installation(callback: type[object] | None = None) -> InstallStatus:
    """Run full installation check and return structured status.

    Args:
        callback: optional callable(progress: float, message: str) for status updates
    """
    def _update(p: float, msg: str):
        if callback:
            with contextlib.suppress(Exception):
                callback(p, msg)

    status = InstallStatus()
    _update(0.1, "Checking Python version...")

    # basic info
    try:
        import mbo_utilities
        status.mbo_version = getattr(mbo_utilities, "__version__", "unknown")
    except ImportError:
        status.mbo_version = "not installed"

    status.python_version = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"

    # cuda environment
    _update(0.2, "Checking CUDA environment...")
    status.cuda_info.nvcc_version = _get_nvcc_version()
    status.cuda_info.driver_version = _get_nvidia_smi_cuda()

    # check pytorch (needed for suite2p GPU)
    _update(0.3, "Checking PyTorch...")
    pytorch_status, pytorch_cuda = _check_pytorch()
    status.cuda_info.pytorch_cuda = pytorch_cuda
    status.features.append(pytorch_status)

    # check cupy (needed for suite3d)
    _update(0.5, "Checking CuPy...")
    cupy_status, cupy_cuda = _check_cupy(driver_cuda=status.cuda_info.driver_version)
    status.cuda_info.cupy_cuda = cupy_cuda
    status.features.append(cupy_status)

    # get gpu name from cupy if available
    if cupy_status.gpu_ok:
        try:
            import cupy as cp
            device = cp.cuda.Device()
            status.cuda_info.device_name = device.attributes.get("Name", None)
            status.cuda_info.device_count = cp.cuda.runtime.getDeviceCount()
        except Exception:
            pass

    # check pipelines
    _update(0.7, "Checking Suite2p...")
    suite2p_status = _check_suite2p()
    # if suite2p is installed but pytorch has no GPU, warn
    if suite2p_status.status == Status.OK and pytorch_status.gpu_ok is False:
        suite2p_status = FeatureStatus(
            name="Suite2p",
            status=Status.WARN,
            version=suite2p_status.version,
            message="PyTorch has no GPU support",
            gpu_ok=False
        )
    elif suite2p_status.status == Status.OK:
        suite2p_status.gpu_ok = pytorch_status.gpu_ok
    status.features.append(suite2p_status)

    _update(0.8, "Checking Suite3D...")
    suite3d_status = _check_suite3d(
        cupy_status=cupy_status,
        driver_cuda=status.cuda_info.driver_version,
    )
    if suite3d_status.status == Status.OK:
        suite3d_status.gpu_ok = cupy_status.gpu_ok
    status.features.append(suite3d_status)

    _update(0.85, "Checking Rastermap...")
    status.features.append(_check_rastermap())

    _update(0.9, "Checking Napari...")
    napari_status = _check_napari()
    status.features.append(napari_status)

    # Only check napari plugins if napari is installed
    if napari_status.status == Status.OK:
        _update(0.93, "Checking napari-ome-zarr...")
        status.features.append(_check_napari_ome_zarr())

        _update(0.96, "Checking napari-animation...")
        status.features.append(_check_napari_animation())

    _update(1.0, "Done")
    return status


def print_status_cli(status: InstallStatus):
    """Print installation status to CLI with colors."""
    import click

    click.echo(f"\nmbo_utilities v{status.mbo_version} | Python {status.python_version}")
    click.echo("=" * 50)

    # cuda info
    if status.cuda_info.nvcc_version or status.cuda_info.driver_version:
        click.echo("\nCUDA Environment:")
        if status.cuda_info.nvcc_version:
            click.echo(f"  CUDA Toolkit (nvcc): {status.cuda_info.nvcc_version}")
        if status.cuda_info.driver_version:
            click.echo(f"  Driver CUDA:         {status.cuda_info.driver_version}")
        if status.cuda_info.device_name:
            click.echo(f"  GPU:                 {status.cuda_info.device_name}")

    # features table
    click.echo("\nFeatures:")
    for f in status.features:
        # format version string (skip 'v' prefix if version is 'installed')
        if f.version and f.version != "installed":
            ver = f" v{f.version}"
        elif f.version == "installed":
            ver = ""
        else:
            ver = ""

        if f.status == Status.OK:
            icon = click.style("[OK]", fg="green")
            msg = click.style(f"{f.name}{ver}", fg="green")
            extra = f" ({f.message})" if f.message and f.message != "ready" else ""
        elif f.status == Status.WARN:
            icon = click.style("[! ]", fg="yellow")
            msg = click.style(f"{f.name}{ver}", fg="yellow")
            extra = f" - {f.message}" if f.message else ""
        elif f.status == Status.ERROR:
            icon = click.style("[X ]", fg="red")
            msg = click.style(f"{f.name}{ver}", fg="red")
            extra = f" - {f.message}" if f.message else ""
        else:  # MISSING
            icon = click.style("[ -]", fg="bright_black")
            msg = click.style(f"{f.name}", fg="bright_black")
            extra = " (not installed)"

        click.echo(f"  {icon} {msg}{extra}")

    # summary
    click.echo("")
    if status.all_ok:
        click.secho("Installation OK", fg="green", bold=True)
    else:
        click.secho("Issues detected - see warnings above", fg="yellow")
