"""
imread - Lazy load imaging data from supported file types.

This module provides the imread() function for loading imaging data from
various file formats as lazy arrays.
"""

from __future__ import annotations

import inspect
from functools import lru_cache
from pathlib import Path

import numpy as np

from mbo_utilities import log
from mbo_utilities.arrays import (
    BinArray,
    ClusterPTArray,
    LBMPiezoArray,
    H5Array,
    IsoviewArray,
    IsoViewOutputArray,
    LBMArray,
    NumpyArray,
    PiezoArray,
    ScanImageArray,
    SinglePlaneArray,
    Suite2pArray,
    TiffArray,
    ZarrArray,
    _extract_tiff_plane_number,
    open_scanimage,
)
from mbo_utilities.arrays.isoview import (
    _find_tm_folders,
    _has_tm_pattern,
    _TILED_CORRECTED_PATTERN,
    _TILED_FUSED_PATTERN,
    EXCLUDE_PATTERNS as ISOVIEW_EXCLUDE_PATTERNS,
)
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Sequence

logger = log.get("reader")

# UI dropdown shows these formats (excludes .tif to avoid duplication)
MBO_SUPPORTED_FTYPES = [".tiff", ".zarr", ".bin", ".h5", ".npy", ".klb"]
# reading accepts .tif as alias for .tiff
MBO_READABLE_FTYPES = [".tiff", ".tif", ".zarr", ".bin", ".h5", ".npy", ".klb"]

# Re-export PIPELINE_TAGS for backward compatibility (canonical location is file_io.py)


@lru_cache(maxsize=32)
def _get_init_params(cls: type) -> set[str]:
    """
    Get the set of parameter names accepted by a class's __init__.

    Uses inspect.signature for dynamic introspection rather than hardcoded
    mappings. Results are cached for performance.

    Parameters
    ----------
    cls : type
        The class to inspect.

    Returns
    -------
    set[str]
        Set of parameter names (excluding 'self').
    """
    try:
        sig = inspect.signature(cls.__init__)
        # Exclude 'self' and collect all parameter names
        return {
            name
            for name, param in sig.parameters.items()
            if name != "self" and param.kind
            not in (inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD)
        }
    except (ValueError, TypeError):
        # Fallback for classes without inspectable __init__
        return set()


def _filter_kwargs(cls, kwargs):
    """
    Filter kwargs to only those accepted by cls.__init__.

    Uses dynamic introspection via _get_init_params rather than
    hardcoded mappings.
    """
    allowed = _get_init_params(cls)
    return {k: v for k, v in kwargs.items() if k in allowed}


def imread(
    inputs: str | Path | np.ndarray | Sequence[str | Path],
    **kwargs,
):
    """
    Lazy load imaging data from supported file types.

    Currently supported file types:
    - .bin: Suite2p binary files (.bin + ops.npy)
    - .tif/.tiff: TIFF files (BigTIFF, OME-TIFF and raw ScanImage TIFFs)
    - .h5: HDF5 files
    - .zarr: Zarr v3
    - .npy: NumPy arrays
    - np.ndarray: In-memory numpy arrays (wrapped as NumpyArray)

    Parameters
    ----------
    inputs : str, Path, ndarray, or sequence of str/Path
        Input source. Can be:
        - Path to a file or directory
        - List/tuple of file paths
        - A numpy array (will be wrapped as NumpyArray for full imwrite support)
        - An existing lazy array (passed through unchanged)
    **kwargs
        Extra keyword arguments passed to specific array readers.

    Returns
    -------
    array_like
        A lazy array appropriate for the input format. Use `mbo formats` CLI
        command to list all supported formats and their array types.

    Examples
    --------
    >>> from mbo_utilities import imread, imwrite
    >>> arr = imread("/data/raw")  # directory with supported files
    >>> arr = imread("data.tiff")  # single file
    >>> arr = imread(["file1.tiff", "file2.tiff"])  # multiple files

    >>> # Wrap numpy array for imwrite compatibility
    >>> data = np.random.randn(100, 512, 512)
    >>> arr = imread(data)  # Returns NumpyArray
    >>> imwrite(arr, "output", ext=".zarr")  # Full write support
    """
    # Wrap numpy arrays in NumpyArray for full imwrite/protocol support
    if isinstance(inputs, np.ndarray):
        logger.debug(f"Wrapping numpy array with shape {inputs.shape} as NumpyArray")
        return NumpyArray(inputs, **_filter_kwargs(NumpyArray, kwargs))
    # Pass through already-loaded lazy arrays (has _imwrite method)
    if hasattr(inputs, "_imwrite") and hasattr(inputs, "shape"):
        return inputs

    if "isoview" in kwargs.items():
        return IsoviewArray(inputs)

    if isinstance(inputs, (str, Path)):
        p = Path(inputs)
        if not p.exists():
            raise ValueError(f"Input path does not exist: {p}")

        # if the user (or a file dialog) handed us a path inside a .zarr v3
        # store, redirect to the store root. file pickers default to selecting
        # the inner zarr.json/zgroup.json/zarray rather than the .zarr folder
        # itself, and that previously failed with "no supported files".
        if not p.is_dir():
            for ancestor in p.parents:
                if ancestor.suffix.lower() == ".zarr" and ancestor.is_dir():
                    logger.debug(
                        f"Redirecting {p.name} -> parent zarr store {ancestor}"
                    )
                    p = ancestor
                    break

        if p.suffix.lower() == ".zarr" and p.is_dir():
            paths = [p]
        elif p.is_dir():
            logger.debug(f"Input is a directory, searching for supported files in {p}")

            # Check for raw Isoview structure: .stack files with XML metadata
            stack_files = list(p.glob("*.stack"))
            if stack_files:
                xml_files = list(p.glob("*.xml"))
                if xml_files:
                    logger.info(
                        f"Detected raw Isoview structure with {len(stack_files)} .stack files."
                    )
                    return IsoviewArray(p)

            # Check for tiled corrected/fused isoview TIF files (no TM folders)
            tiled_tifs = [
                f for f in p.glob("*.tif")
                if not any(x in f.name for x in ISOVIEW_EXCLUDE_PATTERNS)
            ]
            if tiled_tifs:
                if any(_TILED_FUSED_PATTERN.match(f.name) for f in tiled_tifs):
                    logger.info("Detected tiled fused isoview data")
                    return IsoviewArray(p)
                if any(_TILED_CORRECTED_PATTERN.match(f.name) for f in tiled_tifs):
                    logger.info("Detected tiled corrected isoview data")
                    return IsoviewArray(p)

            # Check for IsoView output structure: TM* subfolders with data files
            # supports both "TM000000" and "Dme_E1.TM000000_multiFused" naming
            tm_folders = _find_tm_folders(p)
            if tm_folders:
                # check first TM folder for file types
                first_tm = tm_folders[0]
                klb_files = list(first_tm.glob("*.klb"))
                zarr_files = list(first_tm.glob("*.zarr"))
                # tif files excluding masks
                tif_files = [f for f in first_tm.glob("*.tif")
                             if not any(x in f.name for x in ["Mask", "mask", "minIntensity"])]

                if tif_files:
                    logger.info(
                        f"Detected IsoView output with {len(tm_folders)} TM folders and TIF files."
                    )
                    return IsoViewOutputArray(p)
                elif klb_files:
                    logger.info(
                        f"Detected IsoView output with {len(tm_folders)} TM folders and KLB files."
                    )
                    return IsoViewOutputArray(p)
                elif zarr_files:
                    logger.info(
                        f"Detected Isoview structure with {len(tm_folders)} TM folders."
                    )
                    return IsoviewArray(p)

            # Check if this IS a TM folder (single timepoint)
            # supports both "TM000000" and "Dme_E1.TM000000_multiFused" naming
            if _has_tm_pattern(p.name):
                klbs = list(p.glob("*.klb"))
                zarrs = list(p.glob("*.zarr"))
                tifs = [f for f in p.glob("*.tif")
                        if not any(x in f.name for x in ["Mask", "mask", "minIntensity"])]
                if tifs:
                    logger.info(
                        f"Detected single TM folder with {len(tifs)} TIF files."
                    )
                    return IsoViewOutputArray(p)
                elif klbs:
                    logger.info(
                        f"Detected single TM folder with {len(klbs)} KLB files."
                    )
                    return IsoViewOutputArray(p)
                elif zarrs:
                    logger.info(
                        f"Detected single TM folder with {len(zarrs)} zarr files."
                    )
                    return IsoviewArray(p)

            zarrs = list(p.glob("*.zarr"))
            if zarrs:
                logger.debug(
                    f"Found {len(zarrs)} zarr stores in {p}, loading as ZarrArray."
                )
                paths = zarrs
            else:
                # Check for Suite2p structure (ops.npy or plane subdirs)
                # unified Suite2pArray handles both single plane and volume
                ops_file = p / "ops.npy"
                if ops_file.exists():
                    logger.info(f"Detected Suite2p directory at {p}")
                    return Suite2pArray(p)

                # Check for plane subdirectories (volumetric suite2p)
                plane_subdirs = [d for d in p.iterdir() if d.is_dir() and (d / "ops.npy").exists()]
                if plane_subdirs:
                    logger.info(f"Detected Suite2p volume with {len(plane_subdirs)} planes in {p}")
                    return Suite2pArray(p)

                # Check for TIFF volume structure (planeXX.tiff files)
                # unified TiffArray handles both single files and plane volumes
                plane_tiffs = sorted(p.glob("plane*.tif*"))
                if plane_tiffs:
                    logger.info(f"Detected TIFF volume with {len(plane_tiffs)} planes in {p}")
                    return TiffArray(p)

                paths = [Path(f) for f in p.glob("*") if f.is_file()]
                logger.debug(f"Found {len(paths)} files in {p}")
        else:
            paths = [p]
    elif isinstance(inputs, (list, tuple)):
        if not inputs:
            raise ValueError("Input list is empty")

        # Check if all items are ndarrays
        if all(isinstance(item, np.ndarray) for item in inputs):
            return inputs

        # Check if all items are paths
        if not all(isinstance(item, (str, Path)) for item in inputs):
            raise TypeError(
                f"Mixed input types in list. Expected all paths or all ndarrays. "
                f"Got: {[type(item).__name__ for item in inputs]}"
            )

        paths = [Path(p) for p in inputs]
    else:
        raise TypeError(f"Unsupported input type: {type(inputs)}")

    if not paths:
        raise ValueError("No input files found.")

    filtered = [p for p in paths if p.suffix.lower() in MBO_READABLE_FTYPES]
    if not filtered:
        raise ValueError(
            f"No supported files in {inputs}. \n"
            f"Supported file types are: {MBO_READABLE_FTYPES}"
        )
    paths = filtered

    # filter out pollen calibration result files (*_pollen.h5)
    # these are output files, not source data
    paths = [p for p in paths if not p.name.endswith("_pollen.h5")]
    if not paths:
        raise ValueError(
            f"No source data files found in {inputs}. "
            f"Only pollen calibration result files (*_pollen.h5) were found."
        )

    parent = paths[0].parent if paths else None
    ops_file = parent / "ops.npy" if parent else None

    # Suite2p ops file
    if ops_file and ops_file.exists():
        if len(paths) == 1 and paths[0].suffix.lower() == ".bin":
            logger.debug(f"Ops.npy detected - reading specific binary {paths[0]}.")
            return Suite2pArray(paths[0])
        logger.debug(f"Ops.npy detected - reading from {ops_file}.")
        return Suite2pArray(ops_file)

    exts = {p.suffix.lower() for p in paths}
    first = paths[0]

    if len(exts) > 1:
        if exts == {".bin", ".npy"}:
            npy_file = first.parent / "ops.npy"
            logger.debug(f"Reading {npy_file} from {npy_file}.")
            return Suite2pArray(npy_file)
        raise ValueError(f"Multiple file types found in input: {exts!r}")

    if first.suffix in [".tif", ".tiff"]:
        # Check if list of files represents multiple distinct planes
        # (this takes priority over type detection - it's a structural choice)
        if len(paths) > 1:
            plane_nums = {_extract_tiff_plane_number(p.name) for p in paths}
            plane_nums.discard(None)
            if len(plane_nums) > 1:
                logger.debug("Detected multiple planes in file list, loading as volumetric TiffArray.")
                return TiffArray(paths, **_filter_kwargs(TiffArray, kwargs))

        # Try array classes in priority order (most specific first)
        # Each class's can_open() checks if it can handle the file
        TIFF_ARRAY_CLASSES = [
            # Specialized ScanImage subclasses (most specific)
            (LBMArray, "LBM stack"),
            (PiezoArray, "piezo stack"),
            (LBMPiezoArray, "LBM+piezo stack"),
            (SinglePlaneArray, "single-plane ScanImage"),
            # Generic ScanImage (raw acquisition data)
            (ScanImageArray, "raw ScanImage"),
            # Fallback: TiffArray handles both standard TIFFs and ImageJ hyperstacks
            (TiffArray, "TIFF"),
        ]

        for array_cls, description in TIFF_ARRAY_CLASSES:
            if array_cls.can_open(first):
                # filter to only files this class can open, so saved
                # outputs or unrelated tiffs in the same folder are excluded
                if len(paths) > 1:
                    valid = [p for p in paths if array_cls.can_open(p)]
                    if not valid:
                        continue
                    if len(valid) < len(paths):
                        logger.info(
                            f"Filtered {len(paths) - len(valid)} non-{description} "
                            f"file(s) from directory load"
                        )
                    paths = valid
                logger.debug(f"Detected {description}, loading as {array_cls.__name__}.")
                return array_cls(paths, **_filter_kwargs(array_cls, kwargs))

    if first.suffix == ".bin":
        if isinstance(inputs, (str, Path)) and Path(inputs).suffix == ".bin":
            logger.debug(f"Reading binary file as BinArray: {first}")
            return BinArray(first, **_filter_kwargs(BinArray, kwargs))

        npy_file = first.parent / "ops.npy"
        if npy_file.exists():
            logger.debug(f"Reading Suite2p directory from {npy_file}.")
            return Suite2pArray(npy_file)

        raise ValueError(
            "Cannot read .bin file without ops.npy or shape parameter. "
            "Provide shape=(nframes, Ly, Lx) as kwarg or ensure ops.npy exists."
        )

    if first.suffix == ".h5":
        logger.debug(f"Reading HDF5 files from {first}.")
        return H5Array(first, **_filter_kwargs(H5Array, kwargs))

    if first.suffix == ".zarr":
        # Case 1: nested zarrs inside
        sub_zarrs = list(first.glob("*.zarr"))
        if sub_zarrs:
            logger.info("Detected nested zarr stores, loading as ZarrArray.")
            return ZarrArray(sub_zarrs, **_filter_kwargs(ZarrArray, kwargs))

        # Case 2: flat zarr store with zarr.json
        if (first / "zarr.json").exists():
            # Check if this is an isoview consolidated zarr (has camera_N groups)
            camera_dirs = [d for d in first.iterdir() if d.is_dir() and d.name.startswith("camera_")]
            if camera_dirs:
                logger.info(f"Detected isoview consolidated zarr with {len(camera_dirs)} cameras.")
                # For a single consolidated zarr, find the parent TM folder
                # or use the zarr's parent as the isoview root
                parent = first.parent
                if parent.name.startswith("TM"):
                    # Single TM folder
                    return IsoviewArray(parent)
                # The zarr file IS the isoview structure (single timepoint)
                return IsoviewArray(parent)

            logger.info("Detected zarr.json, loading as ZarrArray.")
            return ZarrArray(paths, **_filter_kwargs(ZarrArray, kwargs))

        raise ValueError(
            f"Zarr path {first} is not a valid store. "
            "Expected nested *.zarr dirs or a zarr.json inside."
        )

    if first.suffix == ".json":
        logger.debug(f"Reading JSON files from {first}.")
        return ZarrArray(first.parent, **_filter_kwargs(ZarrArray, kwargs))

    if first.suffix == ".npy":
        # Check for PMD demixer arrays
        if (first.parent / "pmd_demixer.npy").is_file():
            raise NotImplementedError("PMD Arrays are not yet supported.")

        logger.debug(f"Loading .npy file as NumpyArray: {first}")
        return NumpyArray(first, **_filter_kwargs(NumpyArray, kwargs))

    if first.suffix == ".klb":
        import pyklb

        # if only one KLB file specified, read it directly
        if len(paths) == 1:
            logger.info(f"Loading KLB file: {first}")
            data = pyklb.readfull(str(first))
            return NumpyArray(data)

        # check if this looks like a clusterPT structure
        parent = first.parent
        if parent.name.startswith("TM"):
            # inside a TM folder - use parent of TM as base
            logger.info(f"Detected KLB file in TM folder, loading as ClusterPTArray.")
            return ClusterPTArray(parent.parent)

        # check if parent has TM* folders (clusterPT output root)
        tm_folders = [d for d in parent.iterdir() if d.is_dir() and d.name.startswith("TM")]
        if tm_folders:
            logger.info(f"Detected KLB file in clusterPT root, loading as ClusterPTArray.")
            return ClusterPTArray(parent)

        # standalone KLB file - read directly as numpy array
        logger.info(f"Loading standalone KLB file: {first}")
        data = pyklb.readfull(str(first))
        return NumpyArray(data)

    raise TypeError(f"Unsupported file type: {first.suffix}")


