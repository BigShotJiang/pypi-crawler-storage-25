# energyscope-mcp

MCP server for AI agents to search, forecast, and analyse energy market data via EnergyScope.

17 tools: search 1.4M series, multi-factor XGBoost forecasts, Prophet, ARIMA, Theta, breakpoint detection, correlation, volatility, cointegration, and more.

## Quick Start

```bash
# No install needed — uvx runs it directly
claude mcp add energyscope -- uvx energyscope-mcp

# Set your server and API key
export ENERGYSCOPE_SERVER=grpc+tls://data.energyscope.io:443
export ENERGYSCOPE_API_KEY=your-api-key
```

Then ask Claude: *"What's the latest WTI price and has there been a regime change?"*

## Tools

**Data (6):** search, get_data, latest, browse, datasets, health

**Analytics (11):** forecast, arima, prophet, theta, breakpoints, stats, volatility, correlation, unit_root, cointegration

## Links

- Website: https://energyscope.io
- AI Integration: https://energyscope.io/ai
- Excel Add-in: https://energyscope.io/excel
- Forecasting: https://energyscope.io/forecast
- Sign up: https://energyscope.io/signup
