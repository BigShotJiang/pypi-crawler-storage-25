"""openOcto - Let your AI agent control any terminal, anywhere."""

__version__ = "0.1.0"
