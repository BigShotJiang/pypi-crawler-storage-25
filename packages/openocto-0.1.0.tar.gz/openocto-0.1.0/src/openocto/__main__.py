from openocto.cli import main

main()
