"""Custom exceptions for Killstats."""
