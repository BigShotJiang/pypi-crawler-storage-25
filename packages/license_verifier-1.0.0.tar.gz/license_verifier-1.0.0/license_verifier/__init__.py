"""Healthcare License Verification API client — verify professional licenses across all 50 US states."""

import requests

__version__ = "1.0.0"

BASE_URL = "https://healthcare-license.p.rapidapi.com"


class LicenseVerifier:
    """Client for the Healthcare License Verification API on RapidAPI.

    Get your API key at: https://rapidapi.com/lulzasaur9192/api/healthcare-license
    """

    def __init__(self, api_key: str):
        if not api_key:
            raise ValueError(
                "API key required — get one at "
                "https://rapidapi.com/lulzasaur9192/api/healthcare-license"
            )
        self.session = requests.Session()
        self.session.headers.update({
            "x-rapidapi-key": api_key,
            "x-rapidapi-host": "healthcare-license.p.rapidapi.com",
        })

    def _get(self, path: str, params: dict = None) -> dict:
        resp = self.session.get(f"{BASE_URL}{path}", params=params)
        resp.raise_for_status()
        return resp.json()

    def verify(self, state: str, last_name: str = None, first_name: str = None,
               license_type: str = None, npi_number: str = None, limit: int = 50) -> dict:
        """Verify a healthcare professional's license.

        Args:
            state: US state code (e.g. "CA", "FL", "TX")
            last_name: Provider's last name (required unless using npi_number)
            first_name: Provider's first name (optional)
            license_type: License type (MD, DO, RN, LPN, NP, APRN, CNA, PT, PTA,
                         OT, OTA, SLP, CF, PSYCH, RPH, PHARMD, DDS, DMD, PA, DC, OD, DPM)
            npi_number: NPI number (alternative to name search)
            limit: Max results (default 50)
        """
        params = {"state": state, "limit": limit}
        if last_name:
            params["lastName"] = last_name
        if first_name:
            params["firstName"] = first_name
        if license_type:
            params["licenseType"] = license_type
        if npi_number:
            params["npiNumber"] = npi_number
        return self._get("/healthcare/verify", params)

    def lookup_npi(self, npi: str) -> dict:
        """Look up a provider by NPI number.

        Args:
            npi: 10-digit NPI number
        """
        return self._get(f"/healthcare/npi/{npi}")

    def search_by_name(self, last_name: str, state: str, first_name: str = None,
                       license_type: str = None, limit: int = 50) -> dict:
        """Search for providers by name and state.

        Args:
            last_name: Provider's last name
            state: US state code
            first_name: First name (optional)
            license_type: License type filter (optional)
            limit: Max results (default 50)
        """
        return self.verify(state=state, last_name=last_name, first_name=first_name,
                          license_type=license_type, limit=limit)
