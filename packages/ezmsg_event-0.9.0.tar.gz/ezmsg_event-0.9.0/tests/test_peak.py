import os
import tempfile
from pathlib import Path

import ezmsg.core as ez
import numpy as np
import pytest
import sparse
from conftest import CHUNK_LEN, FS, N_CH, make_dense_msg
from ezmsg.util.messagecodec import message_log
from ezmsg.util.messagelogger import MessageLogger
from ezmsg.util.messages.axisarray import AxisArray
from ezmsg.util.messages.chunker import ArrayChunker, array_chunker
from ezmsg.util.terminate import TerminateOnTotal

from ezmsg.event.peak import (
    OutputFormat,
    ThresholdCrossing,
    ThresholdCrossingTransformer,
    ThresholdSettings,
)
from ezmsg.event.util.simulate import generate_white_noise_with_events


@pytest.mark.parametrize("return_peak_val", [True, False])
def test_threshold_crossing(return_peak_val: bool):
    fs = 30_000.0
    dur = 10.0
    n_chans = 128
    threshold = 2.5
    rate_range = (1, 100)
    chunk_dur = 0.02
    refrac_dur = 0.001
    refrac_width = int(fs * refrac_dur)
    chunk_len = int(fs * chunk_dur)

    in_dat = generate_white_noise_with_events(fs, dur, n_chans, rate_range, chunk_dur, threshold)

    bkup_dat = in_dat.copy()
    msg_gen = array_chunker(data=in_dat, chunk_len=chunk_len, axis=0, fs=fs, tzero=0.0)

    # Extract spikes
    transform = ThresholdCrossingTransformer(
        threshold=threshold,
        refrac_dur=refrac_dur,
        return_peak_val=return_peak_val,
    )
    msgs_out = [transform(_) for _ in msg_gen]

    # Calculated expected spikes -- easy to do all at once without chunk boundaries or performance constraints.
    expected = np.logical_and(bkup_dat[:-1] < threshold, bkup_dat[1:] >= threshold)
    expected = np.concatenate((np.zeros((1, n_chans), dtype=bool), expected), axis=0)
    exp_samp_inds = []
    exp_feat_inds = []
    # Remove refractory violations from expected
    for ch_ix, exp in enumerate(expected.T):
        ev_ix = np.where(exp)[0]
        while np.any(np.diff(ev_ix) <= refrac_width):
            ieis = np.hstack(([refrac_width + 1], np.diff(ev_ix)))
            drop_idx = np.where(ieis <= refrac_width)[0][0]
            ev_ix = np.delete(ev_ix, drop_idx)
        exp_samp_inds.extend(ev_ix)
        exp_feat_inds.extend([ch_ix] * len(ev_ix))
    exp_feat_inds = np.array(exp_feat_inds)
    exp_samp_inds = np.array(exp_samp_inds)

    final_arr = sparse.concatenate([_.data for _ in msgs_out], axis=0)
    samp_inds, feat_inds = final_arr.nonzero()
    # Sort by feature then time to match the expected ordering (which is built channel-by-channel).
    sort_order = np.lexsort((samp_inds, feat_inds))
    samp_inds = samp_inds[sort_order]
    feat_inds = feat_inds[sort_order]

    """
    # This block of code was used to debug some discrepancies that popped up when the last sample of the last chunk
    #  had an event, but the processing node wouldn't return it because it was unfinished.
    if len(samp_inds) != len(exp_samp_inds):
        uq_feats, feat_splits = np.unique(feat_inds, return_index=True)
        feat_crosses = {k: v for k, v in zip(uq_feats, np.split(samp_inds, feat_splits[1:]))}
        uq_feats, feat_splits = np.unique(exp_feat_inds, return_index=True)
        exp_feat_crosses = {k: v for k, v in zip(uq_feats, np.split(exp_samp_inds, feat_splits[1:]))}
        for k, v in feat_crosses.items():
            if not np.array_equal(v, exp_feat_crosses[k]):
                print(f"Channel {k}:")
                if len(exp_feat_crosses[k]) > len(v):
                    print(f"\tMissing: {np.setdiff1d(exp_feat_crosses[k], v)}")
                else:
                    print(f"\tExtra: {np.setdiff1d(v, exp_feat_crosses[k])}")
    """

    assert len(samp_inds) == len(exp_samp_inds)
    assert len(feat_inds) == len(exp_feat_inds)
    assert np.array_equal(samp_inds, exp_samp_inds)
    assert np.array_equal(feat_inds, exp_feat_inds)


def get_test_fn(test_name: str | None = None, extension: str = "txt") -> Path:
    """PYTEST compatible temporary test file creator"""
    if test_name is None:
        test_name = os.environ.get("PYTEST_CURRENT_TEST")
        if test_name is not None:
            test_name = test_name.split(":")[-1].split(" ")[0]
        else:
            test_name = __name__

    file_path = Path(tempfile.gettempdir())
    file_path = file_path / Path(f"{test_name}.{extension}")

    # Create the file
    with open(file_path, "w"):
        pass

    return file_path


def test_system():
    fs = 30_000.0
    dur = 2.0
    n_chans = 128
    threshold = 2.5
    rate_range = (1, 100)
    chunk_dur = 0.02
    chunk_len = int(fs * chunk_dur)

    data = generate_white_noise_with_events(fs, dur, n_chans, rate_range, chunk_dur, threshold)
    test_filename = get_test_fn()

    comps = {
        "SOURCE": ArrayChunker(data, chunk_len, fs=fs),
        "THRESH": ThresholdCrossing(threshold=threshold),
        "SINK": MessageLogger(output=test_filename),
        "TERM": TerminateOnTotal(int(fs * dur / chunk_len)),
    }
    conns = (
        (comps["SOURCE"].OUTPUT_SIGNAL, comps["THRESH"].INPUT_SIGNAL),
        (comps["THRESH"].OUTPUT_SIGNAL, comps["SINK"].INPUT_MESSAGE),
        (comps["SINK"].OUTPUT_MESSAGE, comps["TERM"].INPUT_MESSAGE),
    )
    ez.run(components=comps, connections=conns)

    messages = [_ for _ in message_log(test_filename)]
    os.remove(test_filename)

    for msg_ix, msg in enumerate(messages):
        assert isinstance(msg.data, sparse.SparseArray)
        assert msg.axes["time"].gain == 1 / fs
        assert np.round(msg.axes["time"].offset, 3) == np.round(msg_ix * chunk_dur, 3)


@pytest.mark.parametrize("return_peak_val", [False, True])
@pytest.mark.parametrize("auto_scale_tau", [0.0, 0.5])
def test_threshold_crossing_empty_time_after_init(return_peak_val: bool, auto_scale_tau: float):
    """Normal → empty → normal: mid-stream empty message should not crash or corrupt state."""
    proc = ThresholdCrossingTransformer(
        ThresholdSettings(
            threshold=-3.5,
            return_peak_val=return_peak_val,
            auto_scale_tau=auto_scale_tau,
        )
    )
    msg1 = make_dense_msg(CHUNK_LEN, offset=0.0)
    msg_empty = make_dense_msg(0, offset=CHUNK_LEN / FS)
    msg2 = make_dense_msg(CHUNK_LEN, offset=CHUNK_LEN / FS)

    out1 = proc(msg1)
    assert isinstance(out1.data, sparse.SparseArray)

    out_empty = proc(msg_empty)
    assert isinstance(out_empty.data, sparse.SparseArray)
    assert out_empty.data.shape[1] == N_CH

    out2 = proc(msg2)
    assert isinstance(out2.data, sparse.SparseArray)
    assert out2.data.shape[1] == N_CH


def _require_mlx():
    mx = pytest.importorskip("mlx.core")
    try:
        mx.eval(mx.array([1.0], dtype=mx.float32))
    except RuntimeError as exc:
        pytest.skip(f"MLX device unavailable: {exc}")
    return mx


@pytest.mark.parametrize(
    ("threshold", "refrac_dur", "stride"),
    [
        (1.0, 0.030, 31),  # PR's adversarial spacing — refractory bites every time.
        (-1.0, 0.001, 17),  # Negative threshold path; refractory effectively disabled.
    ],
)
def test_threshold_crossing_mlx_dense_matches_numpy_dense(threshold: float, refrac_dur: float, stride: int):
    """MLX inputs (which auto-route through Metal) must match numpy DENSE output across chunk boundaries."""
    mx = _require_mlx()
    fs = 1000.0
    data = np.zeros((1000, 4), dtype=np.float32)
    sign = 1.0 if threshold >= 0 else -1.0
    for ch in range(data.shape[1]):
        for samp in range(ch + 1, data.shape[0], stride):
            data[samp, ch] = 2.0 * sign

    chunks = [data[:137], data[137:503], data[503:777], data[777:]]

    def run(use_mlx: bool) -> list[np.ndarray]:
        proc = ThresholdCrossingTransformer(
            ThresholdSettings(
                threshold=threshold,
                refrac_dur=refrac_dur,
                output_format=OutputFormat.DENSE,
            )
        )
        outs, samp_off = [], 0
        for chunk in chunks:
            data_in = mx.array(chunk) if use_mlx else chunk
            msg = AxisArray(
                data=data_in,
                dims=["time", "ch"],
                axes={"time": AxisArray.TimeAxis(fs=fs, offset=samp_off / fs)},
            )
            out = proc(msg)
            if use_mlx:
                mx.eval(out.data)
            outs.append(np.asarray(out.data))
            samp_off += chunk.shape[0]
        return outs

    np_outs = run(False)
    mlx_outs = run(True)
    for np_chunk, mlx_chunk in zip(np_outs, mlx_outs):
        assert np_chunk.shape == mlx_chunk.shape
        np.testing.assert_array_equal(np_chunk != 0, mlx_chunk != 0)


@pytest.mark.parametrize("return_peak_val", [False, True])
def test_threshold_crossing_dense_matches_sparse(return_peak_val: bool):
    """OutputFormat.DENSE must match sparse output element-for-element after densification."""
    fs = 30_000.0
    dur = 0.5
    n_chans = 16
    threshold = 2.5
    rate_range = (1, 100)
    chunk_dur = 0.02
    chunk_len = int(fs * chunk_dur)
    refrac_dur = 0.001

    in_dat = generate_white_noise_with_events(fs, dur, n_chans, rate_range, chunk_dur, threshold)

    def run(output_format: OutputFormat):
        proc = ThresholdCrossingTransformer(
            ThresholdSettings(
                threshold=threshold,
                refrac_dur=refrac_dur,
                return_peak_val=return_peak_val,
                output_format=output_format,
            )
        )
        msg_gen = array_chunker(data=in_dat.copy(), chunk_len=chunk_len, axis=0, fs=fs, tzero=0.0)
        return [proc(m) for m in msg_gen]

    sp_msgs = run(OutputFormat.SPARSE)
    ds_msgs = run(OutputFormat.DENSE)

    assert len(sp_msgs) == len(ds_msgs)
    for sp_msg, ds_msg in zip(sp_msgs, ds_msgs):
        assert isinstance(sp_msg.data, sparse.SparseArray)
        assert not isinstance(ds_msg.data, sparse.SparseArray)
        assert sp_msg.data.shape == ds_msg.data.shape
        assert ds_msg.data.dtype == (in_dat.dtype if return_peak_val else np.bool_)
        np.testing.assert_array_equal(sp_msg.data.todense(), ds_msg.data)
        assert sp_msg.axes["time"].offset == ds_msg.axes["time"].offset
        assert sp_msg.axes["time"].gain == ds_msg.axes["time"].gain


@pytest.mark.parametrize("return_peak_val", [False, True])
@pytest.mark.parametrize("auto_scale_tau", [0.0, 0.5])
def test_threshold_crossing_empty_time_first(return_peak_val: bool, auto_scale_tau: float):
    """Empty → normal: empty first message triggers _reset_state on empty data."""
    proc = ThresholdCrossingTransformer(
        ThresholdSettings(
            threshold=-3.5,
            return_peak_val=return_peak_val,
            auto_scale_tau=auto_scale_tau,
        )
    )
    msg_empty = make_dense_msg(0, offset=0.0)
    msg_normal = make_dense_msg(CHUNK_LEN, offset=0.0)

    out_empty = proc(msg_empty)
    assert isinstance(out_empty.data, sparse.SparseArray)

    out_normal = proc(msg_normal)
    assert isinstance(out_normal.data, sparse.SparseArray)
    assert out_normal.data.shape[1] == N_CH
