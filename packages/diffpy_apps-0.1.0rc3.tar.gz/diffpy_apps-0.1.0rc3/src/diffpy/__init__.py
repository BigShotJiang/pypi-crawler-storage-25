#!/usr/bin/env python
##############################################################################
#
# (c) 2026 The Trustees of Columbia University in the City of New York.
# All rights reserved.
#
# File coded by: Billinge Group members and community contributors.
#
# See GitHub contributions for a more detailed list of contributors.
# https://github.com/diffpy/diffpy.apps/graphs/contributors
#
# See LICENSE.rst for license information.
#
##############################################################################
