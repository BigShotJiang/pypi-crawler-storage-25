"""Evidentia command-line interface."""
