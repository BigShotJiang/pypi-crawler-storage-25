# DevOps Lab Assistant 🚀

An interactive CLI tool designed to help you learn and remember essential DevOps commands for Docker, Git, Prometheus, and Kubernetes.

## Installation 💻

You can install the package directly from PyPI (once published):

```bash
pip install devops-lab-assistant
```

## Usage 🛠️

After installation, simply run the following command in your terminal:

```bash
devops33
```

## Features ✨

- **Interactive Menu**: Navigate through different tool categories.
- **Categorized Commands**: Clear lists for Docker, Git, Prometheus, and Kubernetes.
- **One-Line Explanations**: Every command comes with a concise explanation.
- **Full List View**: View all commands at once for a quick overview.

## Commands Included 📝

- **Docker**: WSL setup, image management, container lifecycle, Docker Hub.
- **Git**: Repository initialization, staging, committing, remote sync.
- **Prometheus & Utils**: File management, Docker Compose.
- **Kubernetes**: Minikube management, pod/service/deployment operations, scaling.

## License 📄

This project is licensed under the MIT License.
