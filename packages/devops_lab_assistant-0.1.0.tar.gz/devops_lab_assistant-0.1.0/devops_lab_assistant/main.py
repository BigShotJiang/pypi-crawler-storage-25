import os
import sys
import time

# --- ANSI Color Codes for Premium Look ---
class Colors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
    END = '\033[0m'

# --- Command Data ---
COMMANDS = {
    "Docker": [
        {"cmd": "wsl -d Ubuntu", "desc": "Opens the Ubuntu WSL distribution from PowerShell."},
        {"cmd": "sudo docker --version", "desc": "Verifies if Docker is installed and shows the version."},
        {"cmd": "sudo docker run hello-world", "desc": "Tests if Docker is working correctly by running a tiny test container."},
        {"cmd": "sudo docker images", "desc": "Lists all Docker images currently downloaded on your system."},
        {"cmd": "sudo docker ps -a", "desc": "Shows all containers, including those that are currently stopped."},
        {"cmd": "sudo docker pull nginx", "desc": "Downloads the official Nginx image from Docker Hub."},
        {"cmd": "sudo docker run -d --name mynginx -p 8080:80 nginx", "desc": "Runs an Nginx container in detached mode with port mapping."},
        {"cmd": "sudo docker stop mynginx", "desc": "Stops a running container named 'mynginx'."},
        {"cmd": "sudo docker rm mynginx", "desc": "Permanently removes a stopped container named 'mynginx'."},
        {"cmd": "sudo docker build -t mypythonapp .", "desc": "Builds a custom Docker image from the Dockerfile in the current directory."},
        {"cmd": "sudo docker login", "desc": "Authenticates your local Docker client with your Docker Hub account."},
        {"cmd": "sudo docker tag mypythonapp user/app:v1", "desc": "Tags a local image for uploading to a specific Docker Hub repository."},
        {"cmd": "sudo docker push user/app:v1", "desc": "Uploads the tagged image to your Docker Hub repository."},
        {"cmd": "sudo docker rmi mypythonapp", "desc": "Removes a local Docker image from your system."}
    ],
    "Git": [
        {"cmd": "sudo apt update", "desc": "Updates the local package list to ensure you get the latest software."},
        {"cmd": "git --version", "desc": "Checks the installed version of Git on your system."},
        {"cmd": "git init", "desc": "Initializes a new Git repository in the current directory."},
        {"cmd": "git status", "desc": "Shows the current state of the working directory and staging area."},
        {"cmd": "git config --global user.name 'Name'", "desc": "Sets your name globally for all Git commits on the machine."},
        {"cmd": "git add <file>", "desc": "Adds specific file changes to the staging area for the next commit."},
        {"cmd": "git commit -m 'message'", "desc": "Saves your staged changes as a permanent snapshot in history."},
        {"cmd": "git log --oneline", "desc": "Displays a compact, one-line version of your commit history."},
        {"cmd": "git remote add origin <url>", "desc": "Links your local repository to a remote repository on GitHub/GitLab."},
        {"cmd": "git push -u origin main", "desc": "Uploads your local commits to the remote 'main' branch."}
    ],
    "Prometheus & Utils": [
        {"cmd": "mkdir folder_name", "desc": "Creates a new directory for your project files."},
        {"cmd": "nano filename", "desc": "Opens a simple text editor in the terminal to create or edit files."},
        {"cmd": "cat filename", "desc": "Displays the entire contents of a file directly in the terminal."},
        {"cmd": "sudo docker compose up -d", "desc": "Starts multi-container applications in detached mode using a compose file."},
        {"cmd": "sudo docker compose down", "desc": "Stops and removes all containers defined in the compose file."}
    ],
    "Kubernetes": [
        {"cmd": "minikube start", "desc": "Starts the local Kubernetes cluster using Minikube."},
        {"cmd": "minikube status", "desc": "Checks the status of the local Minikube cluster."},
        {"cmd": "kubectl version --client", "desc": "Verifies that the kubectl client is installed and working."},
        {"cmd": "kubectl run my-pod --image=nginx", "desc": "Creates and runs a simple Nginx pod in the cluster."},
        {"cmd": "kubectl get pods", "desc": "Lists all pods currently running in the cluster."},
        {"cmd": "kubectl get pod my-pod -o wide", "desc": "Shows detailed information about a specific pod, including its IP."},
        {"cmd": "minikube service my-service --url", "desc": "Generates a URL to access a service running in Minikube."},
        {"cmd": "kubectl port-forward pod/my-pod 8080:80", "desc": "Forwards local port 8080 to the pod's port 80 for local access."},
        {"cmd": "kubectl expose pod my-pod --type=NodePort", "desc": "Exposes a pod to external traffic using a NodePort service."},
        {"cmd": "kubectl get services", "desc": "Lists all services currently active in the cluster."},
        {"cmd": "kubectl delete service my-service", "desc": "Removes a service from the Kubernetes cluster."},
        {"cmd": "kubectl delete pod my-pod", "desc": "Deletes a specific pod from the cluster."},
        {"cmd": "kubectl create deployment my-deploy", "desc": "Creates a deployment to manage a set of replicated pods."},
        {"cmd": "kubectl get deployment", "desc": "Lists all deployments and their current status."},
        {"cmd": "kubectl scale deployment --replicas=5", "desc": "Changes the number of replicas for a specific deployment."},
        {"cmd": "minikube stop", "desc": "Stops the running local Kubernetes cluster."}
    ]
}

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def print_banner():
    banner = f"""
{Colors.CYAN}{Colors.BOLD}=================================================
       DEVOPS LAB COMMAND ASSISTANT
================================================={Colors.END}
    """
    print(banner)

def print_all_commands():
    clear_screen()
    print_banner()
    print(f"{Colors.YELLOW}{Colors.BOLD}PRINTING ALL COMMANDS:{Colors.END}\n")
    
    for category, cmds in COMMANDS.items():
        print(f"{Colors.HEADER}--- {category} ---{Colors.END}")
        for item in cmds:
            print(f"{Colors.GREEN}{item['cmd']:<45}{Colors.END} | {item['desc']}")
        print()
    
    input(f"\n{Colors.BLUE}Press Enter to return to menu...{Colors.END}")

def show_category(category):
    clear_screen()
    print_banner()
    print(f"{Colors.YELLOW}{Colors.BOLD}{category.upper()} COMMANDS:{Colors.END}\n")
    
    for item in COMMANDS[category]:
        print(f"{Colors.GREEN}{item['cmd']:<45}{Colors.END} | {item['desc']}")
    
    input(f"\n{Colors.BLUE}Press Enter to return to menu...{Colors.END}")

def main():
    while True:
        clear_screen()
        print_banner()
        print(f"{Colors.BOLD}Select an option:{Colors.END}")
        print(f"{Colors.CYAN}1.{Colors.END} View Docker Commands")
        print(f"{Colors.CYAN}2.{Colors.END} View Git Commands")
        print(f"{Colors.CYAN}3.{Colors.END} View Prometheus & Utils")
        print(f"{Colors.CYAN}4.{Colors.END} View Kubernetes Commands")
        print(f"{Colors.CYAN}5.{Colors.END} {Colors.BOLD}Print ALL Commands{Colors.END}")
        print(f"{Colors.RED}6. Exit{Colors.END}")
        
        choice = input(f"\n{Colors.YELLOW}Enter choice (1-6): {Colors.END}")
        
        if choice == '1':
            show_category("Docker")
        elif choice == '2':
            show_category("Git")
        elif choice == '3':
            show_category("Prometheus & Utils")
        elif choice == '4':
            show_category("Kubernetes")
        elif choice == '5':
            print_all_commands()
        elif choice == '6':
            print(f"\n{Colors.GREEN}Happy Coding! Exiting...{Colors.END}")
            time.sleep(1)
            break
        else:
            print(f"\n{Colors.RED}Invalid choice, try again.{Colors.END}")
            time.sleep(1)

def run():
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n\n{Colors.RED}Program interrupted. Exiting...{Colors.END}")
        sys.exit(0)

if __name__ == "__main__":
    run()
