# Copyright (c) 2023 - 2025, AG2ai, Inc., AG2ai open-source projects maintainers and core contributors
#
# SPDX-License-Identifier: Apache-2.0

import warnings
from collections.abc import Callable
from typing import TYPE_CHECKING, Any

from a2a.compat.v0_3 import conversions as _v03_conversions
from a2a.compat.v0_3.types import AgentCapabilities, AgentCard, AgentExtension, AgentSkill
from a2a.server.request_handlers import DefaultRequestHandler
from a2a.server.routes import create_agent_card_routes, create_jsonrpc_routes
from a2a.server.tasks import InMemoryTaskStore
from pydantic import Field
from starlette.applications import Starlette

from autogen import ConversableAgent
from autogen.doc_utils import export_module

from .agent_executor import AutogenAgentExecutor
from .utils import make_async_card_modifier, make_async_extended_card_modifier

if TYPE_CHECKING:
    from a2a.server.agent_execution import RequestContextBuilder
    from a2a.server.context import ServerCallContext
    from a2a.server.events import QueueManager
    from a2a.server.request_handlers import RequestHandler
    from a2a.server.routes.common import ServerCallContextBuilder
    from a2a.server.tasks import PushNotificationConfigStore, PushNotificationSender, TaskStore
    from starlette.middleware.base import BaseHTTPMiddleware

    from autogen import ConversableAgent


@export_module("autogen.a2a")
class CardSettings(AgentCard):
    """Original A2A AgentCard object inheritor making some fields optional."""

    name: str | None = None  # type: ignore[assignment]
    """
    A human-readable name for the agent. Uses original agent name if not set.
    """

    description: str | None = None  # type: ignore[assignment]
    """
    A human-readable description of the agent, assisting users and other agents
    in understanding its purpose. Uses original agent description if not set.
    """

    url: str | None = None  # type: ignore[assignment]
    """
    The preferred endpoint URL for interacting with the agent.
    This URL MUST support the transport specified by 'preferredTransport'.
    Uses original A2aAgentServer url if not set.
    """

    version: str = "0.1.0"
    """
    The agent's own version number. The format is defined by the provider.
    """

    default_input_modes: list[str] = Field(default_factory=lambda: ["text"])
    """
    Default set of supported input MIME types for all skills, which can be
    overridden on a per-skill basis.
    """

    default_output_modes: list[str] = Field(default_factory=lambda: ["text"])
    """
    Default set of supported output MIME types for all skills, which can be
    overridden on a per-skill basis.
    """

    capabilities: AgentCapabilities = Field(default_factory=lambda: AgentCapabilities(streaming=True))
    """
    A declaration of optional capabilities supported by the agent.
    """

    skills: list[AgentSkill] = Field(default_factory=list)
    """
    The set of skills, or distinct capabilities, that the agent can perform.
    """


@export_module("autogen.a2a")
class A2aAgentServer:
    """A server wrapper for running an AG2 agent via the A2A protocol.

    This class provides functionality to wrap an AG2 ConversableAgent into an A2A server
    that can be used to interact with the agent through A2A requests.
    """

    def __init__(
        self,
        agent: "ConversableAgent",
        *,
        url: str | None = "http://localhost:8000",
        agent_card: CardSettings | None = None,
        card_modifier: Callable[["AgentCard"], "AgentCard"] | None = None,
        extended_agent_card: CardSettings | None = None,
        extended_card_modifier: Callable[["AgentCard", "ServerCallContext"], "AgentCard"] | None = None,
    ) -> None:
        """Initialize the A2aAgentServer.

        Args:
            agent: The Autogen ConversableAgent to serve.
            url: The base URL for the A2A server.
            agent_card: Configuration for the base agent card.
            card_modifier: Function to modify the base agent card.
            extended_agent_card: Configuration for the extended agent card.
            extended_card_modifier: Function to modify the extended agent card.
        """
        self.agent = agent

        if not agent_card:
            agent_card = CardSettings()

        if agent_card.url and url != "http://localhost:8000":
            warnings.warn(
                (
                    "You can't use `agent_card.url` and `url` options in the same time. "
                    f"`agent_card.url` has a higher priority, so `{agent_card.url}` will be used."
                ),
                RuntimeWarning,
                stacklevel=2,
            )

        self.card = AgentCard.model_validate({
            # use agent options by default
            "name": agent.name,
            "description": agent.description,
            "url": url,
            "supports_authenticated_extended_card": extended_agent_card is not None,
            # exclude name and description if not provided
            **agent_card.model_dump(exclude_none=True),
        })

        self.extended_agent_card: AgentCard | None = None
        if extended_agent_card:
            if extended_agent_card.url and url != "http://localhost:8000":
                warnings.warn(
                    (
                        "You can't use `extended_agent_card.url` and `url` options in the same time. "
                        f"`agent_card.url` has a higher priority, so `{extended_agent_card.url}` will be used."
                    ),
                    RuntimeWarning,
                    stacklevel=2,
                )

            self.extended_agent_card = AgentCard.model_validate({
                "name": agent.name,
                "description": agent.description,
                "url": url,
                **extended_agent_card.model_dump(exclude_none=True),
            })

        # Auto-add A2UI extension to card if wrapping an A2UIAgent.
        # Declares the extension URI and supportedCatalogIds in the agent card
        # so clients know what A2UI version and catalogs this agent supports.
        try:
            from autogen.agents.experimental.a2ui import A2UIAgent
            from autogen.agents.experimental.a2ui.a2a_helpers import A2UI_EXTENSION_URI

            if isinstance(agent, A2UIAgent):
                existing_extensions = list(self.card.capabilities.extensions or [])
                if not any(e.uri == A2UI_EXTENSION_URI for e in existing_extensions):
                    # Build params with supportedCatalogIds per A2UI extension spec
                    params: dict[str, Any] = {
                        "supportedCatalogIds": [agent.catalog_id],
                    }
                    existing_extensions.append(
                        AgentExtension(
                            uri=A2UI_EXTENSION_URI,
                            description="Provides agent-driven UI using the A2UI v0.9 JSON format.",
                            params=params,
                        )
                    )
                    self.card.capabilities.extensions = existing_extensions
        except (ImportError, NameError):
            pass

        self.card_modifier = card_modifier
        self.extended_card_modifier = extended_card_modifier
        self.middlewares: list[tuple[BaseHTTPMiddleware, dict[str, Any]]] = []

    def add_middleware(self, middleware: "BaseHTTPMiddleware", **kwargs: Any) -> None:
        """Add a middleware to the A2A server."""
        self.middlewares.append((middleware, kwargs))

    @property
    def executor(self) -> AutogenAgentExecutor:
        """Get the A2A agent executor.

        Auto-detects ``A2UIAgent`` and returns an ``A2UIAgentExecutor`` that
        preserves A2UI DataParts in responses and handles extension negotiation.
        """
        try:
            from autogen.agents.experimental.a2ui import A2UIAgent
            from autogen.agents.experimental.a2ui.a2a_executor import A2UIAgentExecutor

            if isinstance(self.agent, A2UIAgent):
                return A2UIAgentExecutor(  # type: ignore[return-value]
                    self.agent,
                    delimiter=self.agent._response_delimiter,
                    version_string=self.agent.protocol_version,
                )
        except (ImportError, NameError):
            pass
        return AutogenAgentExecutor(self.agent)

    def build_request_handler(
        self,
        *,
        task_store: "TaskStore | None" = None,
        queue_manager: "QueueManager | None" = None,
        push_config_store: "PushNotificationConfigStore | None" = None,
        push_sender: "PushNotificationSender | None" = None,
        request_context_builder: "RequestContextBuilder | None" = None,
    ) -> "RequestHandler":
        """Build a request handler for A2A application.

        Args:
            task_store: The task store to use.
            queue_manager: The queue manager to use.
            push_config_store: The push notification config store to use.
            push_sender: The push notification sender to use.
            request_context_builder: The request context builder to use.

        Returns:
            A configured RequestHandler instance.
        """
        # Bridge our public sync v0.3-pydantic extended_card_modifier to the
        # async proto-pydantic-proto signature SDK 1.0 expects, so the user
        # callback runs per request with a real ServerCallContext.
        extended_card_modifier_bridge = (
            make_async_extended_card_modifier(self.extended_card_modifier)
            if self.extended_card_modifier is not None
            else None
        )

        return DefaultRequestHandler(
            agent_executor=self.executor,
            task_store=task_store or InMemoryTaskStore(),
            agent_card=_v03_conversions.to_core_agent_card(self.card),
            queue_manager=queue_manager,
            push_config_store=push_config_store,
            push_sender=push_sender,
            request_context_builder=request_context_builder,
            extended_agent_card=(
                _v03_conversions.to_core_agent_card(self.extended_agent_card)
                if self.extended_agent_card is not None
                else None
            ),
            extended_card_modifier=extended_card_modifier_bridge,
        )

    def build_starlette_app(
        self,
        *,
        request_handler: "RequestHandler | None" = None,
        context_builder: "ServerCallContextBuilder | None" = None,
    ) -> Starlette:
        """Build a Starlette A2A application for ASGI server.

        Args:
            request_handler: The request handler to use.
            context_builder: The context builder to use.

        Returns:
            A configured Starlette application instance.
        """
        handler = request_handler or self.build_request_handler()

        # Bridge sync v0.3-pydantic card_modifier to async proto-pydantic-proto
        # so SDK 1.0 invokes it per request when the well-known card is fetched.
        card_modifier_bridge = make_async_card_modifier(self.card_modifier) if self.card_modifier is not None else None

        routes = list(
            create_agent_card_routes(
                _v03_conversions.to_core_agent_card(self.card),
                card_modifier=card_modifier_bridge,
            )
        )
        routes.extend(
            create_jsonrpc_routes(
                handler,
                rpc_url="/",
                context_builder=context_builder,
                enable_v0_3_compat=True,
            )
        )

        app = Starlette(routes=routes)

        for middleware, kwargs in self.middlewares:
            app.add_middleware(middleware, **kwargs)  # type: ignore[arg-type]

        return app

    build = build_starlette_app  # default alias for build_starlette_app
