"""
Native Linux Python3 driver for the SI5351 clock generator.

Ported from the Adafruit CircuitPython SI5351 library:
    https://github.com/adafruit/Adafruit_CircuitPython_SI5351

Uses smbus2 for I2C communication instead of CircuitPython's busio/adafruit_bus_device.

Example usage on Raspberry Pi::

    from si5351 import SI5351

    si = SI5351(bus=1)  # /dev/i2c-1

    # Configure PLL A to 900 MHz (25 MHz * 36)
    si.pll_a.configure_integer(36)

    # Clock 0 at 25 MHz (900 MHz / 36)
    si.clock_0.configure_integer(si.pll_a, 36)

    # Enable outputs
    si.outputs_enabled = True

    print(si.clock_0.frequency)
"""

from __future__ import annotations

import math

from smbus2 import SMBus

__version__ = "1.0.0"

# SI5351 default I2C address (ADDR pin low)
_SI5351_ADDRESS = 0x60

# Crystal frequency on the Adafruit breakout board
_SI5351_CRYSTAL_FREQUENCY = 25_000_000.0

# Register addresses
_REG_DEVICE_STATUS = 0
_REG_OUTPUT_ENABLE_CONTROL = 3
_REG_PLL_INPUT_SOURCE = 15
_REG_CLK0_CONTROL = 16
_REG_CLK1_CONTROL = 17
_REG_CLK2_CONTROL = 18
_REG_MULTISYNTH0_BASE = 42
_REG_MULTISYNTH1_BASE = 50
_REG_MULTISYNTH2_BASE = 58
_REG_PLL_RESET = 177
_REG_CRYSTAL_LOAD = 183

# R divider constants
R_DIV_1 = 0
R_DIV_2 = 1
R_DIV_4 = 2
R_DIV_8 = 3
R_DIV_16 = 4
R_DIV_32 = 5
R_DIV_64 = 6
R_DIV_128 = 7


class SI5351:
    """SI5351 clock generator driver for native Linux I2C.

    :param bus: I2C bus number (e.g. 1 for /dev/i2c-1) or an already-opened
        ``smbus2.SMBus`` instance.
    :param address: I2C address of the SI5351 (default 0x60).
    """

    class _PLL:
        def __init__(self, si5351: SI5351, base_address: int, clock_control_enabled: int) -> None:
            self._si5351 = si5351
            self._base = base_address
            self._frequency: float | None = None
            self.clock_control_enabled = clock_control_enabled

        @property
        def frequency(self) -> float | None:
            """PLL frequency in hertz, or None if not configured."""
            return self._frequency

        def _configure_registers(self, p1: int, p2: int, p3: int) -> None:
            buf = [
                (p3 >> 8) & 0xFF,
                p3 & 0xFF,
                (p1 >> 16) & 0x03,
                (p1 >> 8) & 0xFF,
                p1 & 0xFF,
                ((p3 >> 12) & 0xF0) | ((p2 >> 16) & 0x0F),
                (p2 >> 8) & 0xFF,
                p2 & 0xFF,
            ]
            self._si5351._write_block(self._base, buf)
            # Reset both PLLs
            self._si5351._write_u8(_REG_PLL_RESET, (1 << 7) | (1 << 5))

        def configure_integer(self, multiplier: int) -> None:
            """Configure the PLL with an integer multiplier (15..90).

            This is the most accurate mode. The PLL output frequency will be
            ``25 MHz * multiplier``.
            """
            if not 15 <= multiplier <= 90:
                raise ValueError("Multiplier must be in range 15 to 90.")
            multiplier = int(multiplier)
            self._configure_registers(128 * multiplier - 512, 0, 1)
            self._frequency = _SI5351_CRYSTAL_FREQUENCY * multiplier

        def configure_fractional(self, multiplier: int, numerator: int, denominator: int) -> None:
            """Configure the PLL with a fractional multiplier.

            PLL frequency = 25 MHz * (multiplier + numerator/denominator).

            :param multiplier: Integer part (15..90).
            :param numerator: Numerator (0..0xFFFFF).
            :param denominator: Denominator (1..0xFFFFF).
            """
            if not 15 <= multiplier <= 90:
                raise ValueError("Multiplier must be in range 15 to 90.")
            if not 0 < denominator <= 0xFFFFF:
                raise ValueError("Denominator must be in range 1 to 0xFFFFF.")
            if not 0 <= numerator < 0xFFFFF:
                raise ValueError("Numerator must be in range 0 to 0xFFFFF.")
            multiplier = int(multiplier)
            numerator = int(numerator)
            denominator = int(denominator)
            frac = numerator / denominator
            p1 = int(128 * multiplier + math.floor(128 * frac) - 512)
            p2 = int(128 * numerator - denominator * math.floor(128 * frac))
            p3 = denominator
            self._configure_registers(p1, p2, p3)
            self._frequency = _SI5351_CRYSTAL_FREQUENCY * (multiplier + frac)

    class _Clock:
        def __init__(
            self,
            si5351: SI5351,
            base_address: int,
            control_register: int,
            r_register: int,
        ) -> None:
            self._si5351 = si5351
            self._base = base_address
            self._control = control_register
            self._r = r_register
            self._pll: SI5351._PLL | None = None
            self._divider: float | None = None

        @property
        def frequency(self) -> float | None:
            """Output frequency in hertz (computed from PLL and dividers),
            or None if not configured."""
            if self._pll is None or self._divider is None:
                return None
            base = self._pll.frequency / self._divider
            r = self.r_divider
            return base / (1 << r)

        @property
        def r_divider(self) -> int:
            """R output divider. Must be one of the ``R_DIV_*`` constants."""
            return (self._si5351._read_u8(self._r) >> 4) & 0x07

        @r_divider.setter
        def r_divider(self, divider: int) -> None:
            if not 0 <= divider <= 7:
                raise ValueError("Divider must be in range 0 to 7 (use R_DIV_* constants).")
            reg = self._si5351._read_u8(self._r)
            reg = (reg & 0x0F) | ((divider & 0x07) << 4)
            self._si5351._write_u8(self._r, reg)

        def _configure_registers(self, p1: int, p2: int, p3: int) -> None:
            buf = [
                (p3 >> 8) & 0xFF,
                p3 & 0xFF,
                (p1 >> 16) & 0x03,
                (p1 >> 8) & 0xFF,
                p1 & 0xFF,
                ((p3 >> 12) & 0xF0) | ((p2 >> 16) & 0x0F),
                (p2 >> 8) & 0xFF,
                p2 & 0xFF,
            ]
            self._si5351._write_block(self._base, buf)

        def configure_integer(self, pll: SI5351._PLL, divider: int, inverted: bool = False) -> None:
            """Configure this clock with an integer divider.

            :param pll: PLL source (``si.pll_a`` or ``si.pll_b``).
            :param divider: Integer divider (4..2048).
            :param inverted: Invert the output signal.
            """
            if not 4 <= divider <= 2048:
                raise ValueError("Divider must be in range 4 to 2048.")
            if pll.frequency is None:
                raise RuntimeError("PLL must be configured before the clock.")
            divider = int(divider)
            self._configure_registers(128 * divider - 512, 0, 1)
            control = 0x0F | pll.clock_control_enabled | (1 << 6)
            if inverted:
                control |= 0b00010000
            self._si5351._write_u8(self._control, control)
            self._pll = pll
            self._divider = divider

        def configure_fractional(
            self,
            pll: SI5351._PLL,
            divider: int,
            numerator: int,
            denominator: int,
            inverted: bool = False,
        ) -> None:
            """Configure this clock with a fractional divider.

            Output frequency = PLL_frequency / (divider + numerator/denominator).

            :param pll: PLL source (``si.pll_a`` or ``si.pll_b``).
            :param divider: Integer part of divider (4..2048).
            :param numerator: Numerator (0..0xFFFFF).
            :param denominator: Denominator (1..0xFFFFF).
            :param inverted: Invert the output signal.
            """
            if not 4 <= divider <= 2048:
                raise ValueError("Divider must be in range 4 to 2048.")
            if not 0 < denominator <= 0xFFFFF:
                raise ValueError("Denominator must be in range 1 to 0xFFFFF.")
            if not 0 <= numerator < 0xFFFFF:
                raise ValueError("Numerator must be in range 0 to 0xFFFFF.")
            if pll.frequency is None:
                raise RuntimeError("PLL must be configured before the clock.")
            divider = int(divider)
            numerator = int(numerator)
            denominator = int(denominator)
            frac = numerator / denominator
            p1 = int(128 * divider + math.floor(128 * frac) - 512)
            p2 = int(128 * numerator - denominator * math.floor(128 * frac))
            p3 = denominator
            self._configure_registers(p1, p2, p3)
            control = 0x0F | pll.clock_control_enabled
            if inverted:
                control |= 0b00010000
            self._si5351._write_u8(self._control, control)
            self._pll = pll
            self._divider = divider + frac

    def __init__(self, bus: int | SMBus = 1, *, address: int = _SI5351_ADDRESS) -> None:
        if isinstance(bus, int):
            self._bus = SMBus(bus)
            self._owns_bus = True
        else:
            self._bus = bus
            self._owns_bus = False
        self._address = address

        # Disable all outputs
        self._write_u8(_REG_OUTPUT_ENABLE_CONTROL, 0xFF)
        # Power down all clock outputs
        for reg in range(_REG_CLK0_CONTROL, _REG_CLK0_CONTROL + 8):
            self._write_u8(reg, 0x80)

        self.pll_a = self._PLL(self, 26, 0)
        self.pll_b = self._PLL(self, 34, (1 << 5))

        self.clock_0 = self._Clock(self, _REG_MULTISYNTH0_BASE, _REG_CLK0_CONTROL, 44)
        self.clock_1 = self._Clock(self, _REG_MULTISYNTH1_BASE, _REG_CLK1_CONTROL, 52)
        self.clock_2 = self._Clock(self, _REG_MULTISYNTH2_BASE, _REG_CLK2_CONTROL, 60)

    def close(self) -> None:
        """Close the I2C bus if we opened it."""
        if self._owns_bus:
            self._bus.close()

    def __enter__(self) -> SI5351:
        return self

    def __exit__(self, *exc) -> None:
        self.close()

    def _read_u8(self, register: int) -> int:
        return self._bus.read_byte_data(self._address, register)

    def _write_u8(self, register: int, value: int) -> None:
        self._bus.write_byte_data(self._address, register, value & 0xFF)

    def _write_block(self, register: int, data: list[int]) -> None:
        self._bus.write_i2c_block_data(self._address, register, data)

    @property
    def outputs_enabled(self) -> bool:
        """Enable or disable all clock outputs."""
        return self._read_u8(_REG_OUTPUT_ENABLE_CONTROL) == 0x00

    @outputs_enabled.setter
    def outputs_enabled(self, val: bool) -> None:
        self._write_u8(_REG_OUTPUT_ENABLE_CONTROL, 0x00 if val else 0xFF)
        self.reset_plls()

    def reset_plls(self) -> None:
        """Reset both PLLs. Required after enabling outputs for
        deterministic phase alignment between clocks."""
        self._write_u8(_REG_PLL_RESET, (1 << 7) | (1 << 5))
