
.. _ref_release_notes:

Release notes
#############

.. vale off

.. towncrier release notes start

`1.8.0 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v1.8.0>`_ (May 19, 2026)
=========================================================================================

.. tab-set::


  .. tab-item:: Added

    .. list-table::
        :header-rows: 0
        :widths: auto

        * - Use python \`3.14\`
          - `#938 <https://github.com/ansys/ansys-sphinx-theme/pull/938>`_

        * - Add  option to globally hide the secondary sidebar page TOC
          - `#943 <https://github.com/ansys/ansys-sphinx-theme/pull/943>`_


  .. tab-item:: Fixed

    .. list-table::
        :header-rows: 0
        :widths: auto

        * - Resolve type checking errors
          - `#856 <https://github.com/ansys/ansys-sphinx-theme/pull/856>`_

        * - \`\`backstop\`\` test config for tablet and pdf build
          - `#882 <https://github.com/ansys/ansys-sphinx-theme/pull/882>`_

        * - Search bar for copy-paste
          - `#927 <https://github.com/ansys/ansys-sphinx-theme/pull/927>`_

        * - \`backstop\` tests issue with collapsible sidebar
          - `#955 <https://github.com/ansys/ansys-sphinx-theme/pull/955>`_

        * - Sphinx tags style with \`ansys-sphinx-theme\`
          - `#965 <https://github.com/ansys/ansys-sphinx-theme/pull/965>`_

        * - \`cheatsheet\` extension version
          - `#975 <https://github.com/ansys/ansys-sphinx-theme/pull/975>`_


  .. tab-item:: Documentation

    .. list-table::
        :header-rows: 0
        :widths: auto

        * - Update \`\`CONTRIBUTORS.md\`\` with the latest contributors
          - `#883 <https://github.com/ansys/ansys-sphinx-theme/pull/883>`_


  .. tab-item:: Dependencies

    .. list-table::
        :header-rows: 0
        :widths: auto

        * - Bump jupytext from 1.19.0 to 1.19.1
          - `#879 <https://github.com/ansys/ansys-sphinx-theme/pull/879>`_

        * - Bump notebook from 7.5.2 to 7.5.3
          - `#880 <https://github.com/ansys/ansys-sphinx-theme/pull/880>`_

        * - Bump pyvista[jupyter] from 0.46.5 to 0.47.0
          - `#885 <https://github.com/ansys/ansys-sphinx-theme/pull/885>`_

        * - Bump sphinx-autoapi from 3.6.1 to 3.7.0
          - `#888 <https://github.com/ansys/ansys-sphinx-theme/pull/888>`_

        * - Bump tox from 4.34.1 to 4.36.0
          - `#890 <https://github.com/ansys/ansys-sphinx-theme/pull/890>`_

        * - Bump tox from 4.36.1 to 4.38.0
          - `#892 <https://github.com/ansys/ansys-sphinx-theme/pull/892>`_

        * - Bump tox from 4.38.0 to 4.39.0
          - `#897 <https://github.com/ansys/ansys-sphinx-theme/pull/897>`_

        * - Bump notebook from 7.5.3 to 7.5.4
          - `#900 <https://github.com/ansys/ansys-sphinx-theme/pull/900>`_

        * - Bump pyvista[jupyter] from 0.47.0 to 0.47.1
          - `#901 <https://github.com/ansys/ansys-sphinx-theme/pull/901>`_

        * - Bump tox from 4.39.0 to 4.44.0
          - `#902 <https://github.com/ansys/ansys-sphinx-theme/pull/902>`_

        * - Bump tox from 4.44.0 to 4.45.0
          - `#905 <https://github.com/ansys/ansys-sphinx-theme/pull/905>`_

        * - Bump tox from 4.45.0 to 4.46.0
          - `#907 <https://github.com/ansys/ansys-sphinx-theme/pull/907>`_

        * - Bump tox from 4.46.0 to 4.46.3
          - `#908 <https://github.com/ansys/ansys-sphinx-theme/pull/908>`_

        * - Bump tox from 4.46.3 to 4.47.0
          - `#911 <https://github.com/ansys/ansys-sphinx-theme/pull/911>`_

        * - Bump plotly from 6.5.2 to 6.6.0
          - `#913 <https://github.com/ansys/ansys-sphinx-theme/pull/913>`_

        * - Bump tox from 4.47.0 to 4.47.3
          - `#914 <https://github.com/ansys/ansys-sphinx-theme/pull/914>`_

        * - Bump tox from 4.47.3 to 4.48.0
          - `#916 <https://github.com/ansys/ansys-sphinx-theme/pull/916>`_

        * - Bump sphinx-autoapi from 3.7.0 to 3.8.0
          - `#917 <https://github.com/ansys/ansys-sphinx-theme/pull/917>`_

        * - Bump tox from 4.48.0 to 4.49.0
          - `#918 <https://github.com/ansys/ansys-sphinx-theme/pull/918>`_

        * - Bump notebook from 7.5.4 to 7.5.5
          - `#919 <https://github.com/ansys/ansys-sphinx-theme/pull/919>`_

        * - Bump tox from 4.49.0 to 4.49.1
          - `#920 <https://github.com/ansys/ansys-sphinx-theme/pull/920>`_

        * - Bump tox from 4.49.1 to 4.50.2
          - `#926 <https://github.com/ansys/ansys-sphinx-theme/pull/926>`_

        * - Bump pygithub from 2.8.1 to 2.9.0
          - `#929 <https://github.com/ansys/ansys-sphinx-theme/pull/929>`_

        * - Bump tox from 4.50.2 to 4.50.3
          - `#930 <https://github.com/ansys/ansys-sphinx-theme/pull/930>`_

        * - Bump requests from 2.32.5 to 2.33.0
          - `#931 <https://github.com/ansys/ansys-sphinx-theme/pull/931>`_

        * - Bump requests from 2.33.0 to 2.33.1
          - `#933 <https://github.com/ansys/ansys-sphinx-theme/pull/933>`_

        * - Bump tox from 4.50.3 to 4.52.0
          - `#936 <https://github.com/ansys/ansys-sphinx-theme/pull/936>`_

        * - Update pydata-sphinx-theme requirement from <0.17,>=0.15.4 to >=0.15.4,<0.18
          - `#941 <https://github.com/ansys/ansys-sphinx-theme/pull/941>`_

        * - Bump tox from 4.52.0 to 4.52.1
          - `#944 <https://github.com/ansys/ansys-sphinx-theme/pull/944>`_

        * - Bump pyvista from 0.47.1 to 0.47.3
          - `#945 <https://github.com/ansys/ansys-sphinx-theme/pull/945>`_

        * - Bump plotly from 6.6.0 to 6.7.0
          - `#946 <https://github.com/ansys/ansys-sphinx-theme/pull/946>`_

        * - Bump pygithub from 2.9.0 to 2.9.1
          - `#949 <https://github.com/ansys/ansys-sphinx-theme/pull/949>`_

        * - Bump pydantic from 2.12.5 to 2.13.0
          - `#950 <https://github.com/ansys/ansys-sphinx-theme/pull/950>`_

        * - Bump tox from 4.52.1 to 4.53.0
          - `#951 <https://github.com/ansys/ansys-sphinx-theme/pull/951>`_

        * - Bump pydantic from 2.13.0 to 2.13.1
          - `#952 <https://github.com/ansys/ansys-sphinx-theme/pull/952>`_

        * - Bump pydantic from 2.13.1 to 2.13.2
          - `#953 <https://github.com/ansys/ansys-sphinx-theme/pull/953>`_

        * - Bump pydantic from 2.13.2 to 2.13.3
          - `#956 <https://github.com/ansys/ansys-sphinx-theme/pull/956>`_

        * - Bump ty from 0.0.29 to 0.0.32
          - `#958 <https://github.com/ansys/ansys-sphinx-theme/pull/958>`_

        * - Bump notebook from 7.5.5 to 7.5.6
          - `#960 <https://github.com/ansys/ansys-sphinx-theme/pull/960>`_

        * - Bump sphinx-gallery from 0.20.0 to 0.21.0
          - `#961 <https://github.com/ansys/ansys-sphinx-theme/pull/961>`_

        * - Bump ty from 0.0.32 to 0.0.33
          - `#962 <https://github.com/ansys/ansys-sphinx-theme/pull/962>`_

        * - Bump ty from 0.0.33 to 0.0.34
          - `#966 <https://github.com/ansys/ansys-sphinx-theme/pull/966>`_

        * - Bump tox from 4.53.0 to 4.53.1
          - `#967 <https://github.com/ansys/ansys-sphinx-theme/pull/967>`_

        * - Bump pyvista from 0.47.3 to 0.48.0
          - `#968 <https://github.com/ansys/ansys-sphinx-theme/pull/968>`_

        * - Bump pydantic from 2.13.3 to 2.13.4
          - `#969 <https://github.com/ansys/ansys-sphinx-theme/pull/969>`_

        * - Bump pyvista from 0.48.0 to 0.48.1
          - `#971 <https://github.com/ansys/ansys-sphinx-theme/pull/971>`_

        * - Bump pyvista from 0.48.1 to 0.48.2
          - `#972 <https://github.com/ansys/ansys-sphinx-theme/pull/972>`_

        * - Bump jupytext from 1.19.1 to 1.19.2
          - `#973 <https://github.com/ansys/ansys-sphinx-theme/pull/973>`_

        * - Bump ty from 0.0.34 to 0.0.35
          - `#974 <https://github.com/ansys/ansys-sphinx-theme/pull/974>`_


  .. tab-item:: Maintenance

    .. list-table::
        :header-rows: 0
        :widths: auto

        * - Update CHANGELOG for v1.7.0
          - `#877 <https://github.com/ansys/ansys-sphinx-theme/pull/877>`_

        * - Bump version 1.8.dev0
          - `#878 <https://github.com/ansys/ansys-sphinx-theme/pull/878>`_

        * - Extend the cool down period up to 5 days for the patch releases.
          - `#881 <https://github.com/ansys/ansys-sphinx-theme/pull/881>`_

        * - Bump ansys/actions from 10.2.3 to 10.2.4 in the actions group
          - `#884 <https://github.com/ansys/ansys-sphinx-theme/pull/884>`_

        * - Update CHANGELOG for v1.7.1
          - `#896 <https://github.com/ansys/ansys-sphinx-theme/pull/896>`_

        * - Update CHANGELOG for v1.7.2
          - `#904 <https://github.com/ansys/ansys-sphinx-theme/pull/904>`_

        * - Bump actions/download-artifact from 7.0.0 to 8.0.0 in the actions group
          - `#906 <https://github.com/ansys/ansys-sphinx-theme/pull/906>`_

        * - Bump actions/upload-artifact from 6.0.0 to 7.0.0 in the actions group
          - `#909 <https://github.com/ansys/ansys-sphinx-theme/pull/909>`_

        * - Bump the actions group with 2 updates
          - `#912 <https://github.com/ansys/ansys-sphinx-theme/pull/912>`_

        * - Bump actions/setup-node from 6.2.0 to 6.3.0 in the actions group
          - `#915 <https://github.com/ansys/ansys-sphinx-theme/pull/915>`_

        * - Bump actions/download-artifact from 8.0.0 to 8.0.1 in the actions group
          - `#921 <https://github.com/ansys/ansys-sphinx-theme/pull/921>`_

        * - Bump astral-sh/setup-uv from 7.3.1 to 7.6.0 in the actions group
          - `#924 <https://github.com/ansys/ansys-sphinx-theme/pull/924>`_

        * - Bump the actions group across 1 directory with 3 updates
          - `#939 <https://github.com/ansys/ansys-sphinx-theme/pull/939>`_

        * - Bump actions/upload-artifact from 7.0.0 to 7.0.1 in the actions group
          - `#947 <https://github.com/ansys/ansys-sphinx-theme/pull/947>`_

        * - Update license metadata in pyproject.toml
          - `#948 <https://github.com/ansys/ansys-sphinx-theme/pull/948>`_

        * - Bump astral-sh/setup-uv from 8.0.0 to 8.1.0 in the actions group
          - `#954 <https://github.com/ansys/ansys-sphinx-theme/pull/954>`_, `#959 <https://github.com/ansys/ansys-sphinx-theme/pull/959>`_

        * - Bump actions/setup-node from 6.3.0 to 6.4.0 in the actions group
          - `#957 <https://github.com/ansys/ansys-sphinx-theme/pull/957>`_

        * - Bump ansys/actions from 10.2.12 to 10.3.0 in the actions group across 1 directory
          - `#964 <https://github.com/ansys/ansys-sphinx-theme/pull/964>`_

        * - Bump actions/labeler from 6.0.1 to 6.1.0 in the actions group
          - `#970 <https://github.com/ansys/ansys-sphinx-theme/pull/970>`_


`1.7.2 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v1.7.2>`_ (March 02, 2026)
===========================================================================================

.. tab-set::


  .. tab-item:: Fixed

    .. list-table::
        :header-rows: 0
        :widths: auto

        * - Cheatsheet logging and remove commands
          - `#903 <https://github.com/ansys/ansys-sphinx-theme/pull/903>`_


`1.7.1 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v1.7.1>`_ (February 25, 2026)
==============================================================================================

.. tab-set::


  .. tab-item:: Fixed

    .. list-table::
        :header-rows: 0
        :widths: auto

        * - Add flexible dependency versions for \`\`Python 3.10+\`\`  support and new \"all\" extras target
          - `#893 <https://github.com/ansys/ansys-sphinx-theme/pull/893>`_


  .. tab-item:: Dependencies

    .. list-table::
        :header-rows: 0
        :widths: auto

        * - Bump tox from 4.36.0 to 4.36.1
          - `#891 <https://github.com/ansys/ansys-sphinx-theme/pull/891>`_


  .. tab-item:: Maintenance

    .. list-table::
        :header-rows: 0
        :widths: auto

        * - Bump the actions group across 1 directory with 2 updates
          - `#887 <https://github.com/ansys/ansys-sphinx-theme/pull/887>`_


`1.7.0 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v1.7.0>`_ (January 28, 2026)
=============================================================================================

.. tab-set::


  .. tab-item:: Added

    .. list-table::
        :header-rows: 0
        :widths: auto

        * - Cleanup \`\`js\`\`
          - `#798 <https://github.com/ansys/ansys-sphinx-theme/pull/798>`_

        * - Add backstop js test
          - `#804 <https://github.com/ansys/ansys-sphinx-theme/pull/804>`_

        * - Use dependency groups
          - `#823 <https://github.com/ansys/ansys-sphinx-theme/pull/823>`_

        * - Add dataclass and pydantic class example
          - `#832 <https://github.com/ansys/ansys-sphinx-theme/pull/832>`_


  .. tab-item:: Fixed

    .. list-table::
        :header-rows: 0
        :widths: auto

        * - Style fixes with navigation dropdown
          - `#785 <https://github.com/ansys/ansys-sphinx-theme/pull/785>`_

        * - Update contact mail
          - `#821 <https://github.com/ansys/ansys-sphinx-theme/pull/821>`_

        * - Doc-deploy-pr
          - `#825 <https://github.com/ansys/ansys-sphinx-theme/pull/825>`_

        * - Update license year
          - `#862 <https://github.com/ansys/ansys-sphinx-theme/pull/862>`_

        * - Sphinx design version
          - `#872 <https://github.com/ansys/ansys-sphinx-theme/pull/872>`_

        * - Workflow layout
          - `#874 <https://github.com/ansys/ansys-sphinx-theme/pull/874>`_


  .. tab-item:: Documentation

    .. list-table::
        :header-rows: 0
        :widths: auto

        * - Update \`\`CONTRIBUTORS.md\`\` with the latest contributors
          - `#835 <https://github.com/ansys/ansys-sphinx-theme/pull/835>`_

        * - Update CONTRIBUTING.md
          - `#846 <https://github.com/ansys/ansys-sphinx-theme/pull/846>`_


  .. tab-item:: Dependencies

    .. list-table::
        :header-rows: 0
        :widths: auto

        * - Bump pyvista[jupyter] from 0.46.2 to 0.46.3
          - `#782 <https://github.com/ansys/ansys-sphinx-theme/pull/782>`_

        * - Bump jupytext from 1.17.2 to 1.17.3
          - `#786 <https://github.com/ansys/ansys-sphinx-theme/pull/786>`_

        * - Bump tox from 4.28.4 to 4.29.0
          - `#787 <https://github.com/ansys/ansys-sphinx-theme/pull/787>`_

        * - Bump pygithub from 2.7.0 to 2.8.1
          - `#789 <https://github.com/ansys/ansys-sphinx-theme/pull/789>`_

        * - Bump tox from 4.29.0 to 4.30.2
          - `#791 <https://github.com/ansys/ansys-sphinx-theme/pull/791>`_

        * - Bump pyyaml from 6.0.2 to 6.0.3
          - `#800 <https://github.com/ansys/ansys-sphinx-theme/pull/800>`_

        * - Bump notebook from 7.4.5 to 7.4.7
          - `#802 <https://github.com/ansys/ansys-sphinx-theme/pull/802>`_

        * - Bump pandas from 2.3.2 to 2.3.3
          - `#803 <https://github.com/ansys/ansys-sphinx-theme/pull/803>`_

        * - Bump tox from 4.30.2 to 4.30.3
          - `#806 <https://github.com/ansys/ansys-sphinx-theme/pull/806>`_

        * - Bump plotly from 6.3.0 to 6.3.1
          - `#807 <https://github.com/ansys/ansys-sphinx-theme/pull/807>`_

        * - Bump tox from 4.30.3 to 4.31.0
          - `#819 <https://github.com/ansys/ansys-sphinx-theme/pull/819>`_

        * - Bump jupytext from 1.17.3 to 1.18.1
          - `#822 <https://github.com/ansys/ansys-sphinx-theme/pull/822>`_

        * - Update to tox==4.32.0
          - `#827 <https://github.com/ansys/ansys-sphinx-theme/pull/827>`_

        * - Bump pyvista[jupyter] from 0.46.3 to 0.46.4
          - `#828 <https://github.com/ansys/ansys-sphinx-theme/pull/828>`_

        * - Bump plotly from 6.3.1 to 6.4.0
          - `#831 <https://github.com/ansys/ansys-sphinx-theme/pull/831>`_

        * - Bump pydantic from 2.12.3 to 2.12.4
          - `#834 <https://github.com/ansys/ansys-sphinx-theme/pull/834>`_

        * - Bump plotly from 6.4.0 to 6.5.0
          - `#836 <https://github.com/ansys/ansys-sphinx-theme/pull/836>`_

        * - Bump notebook from 7.4.7 to 7.5.0
          - `#837 <https://github.com/ansys/ansys-sphinx-theme/pull/837>`_

        * - Bump pydantic from 2.12.4 to 2.12.5
          - `#841 <https://github.com/ansys/ansys-sphinx-theme/pull/841>`_

        * - Bump nbsphinx from 0.9.7 to 0.9.8
          - `#842 <https://github.com/ansys/ansys-sphinx-theme/pull/842>`_

        * - Bump numpydoc from 1.9.0 to 1.10.0
          - `#844 <https://github.com/ansys/ansys-sphinx-theme/pull/844>`_

        * - Bump sphinx-gallery from 0.19.0 to 0.20.0
          - `#845 <https://github.com/ansys/ansys-sphinx-theme/pull/845>`_

        * - Bump notebook from 7.5.0 to 7.5.1
          - `#857 <https://github.com/ansys/ansys-sphinx-theme/pull/857>`_

        * - Bump sphinx-theme-builder[cli] from 0.2.0b2 to 0.2.0
          - `#858 <https://github.com/ansys/ansys-sphinx-theme/pull/858>`_

        * - Bump sphinx-theme-builder[cli] from 0.2.0 to 0.3.2
          - `#859 <https://github.com/ansys/ansys-sphinx-theme/pull/859>`_

        * - Bump tox from 4.32.0 to 4.33.0
          - `#860 <https://github.com/ansys/ansys-sphinx-theme/pull/860>`_

        * - Bump plotly from 6.5.0 to 6.5.1
          - `#861 <https://github.com/ansys/ansys-sphinx-theme/pull/861>`_

        * - Bump notebook from 7.5.1 to 7.5.2
          - `#864 <https://github.com/ansys/ansys-sphinx-theme/pull/864>`_

        * - Bump plotly from 6.5.1 to 6.5.2
          - `#865 <https://github.com/ansys/ansys-sphinx-theme/pull/865>`_

        * - Bump pyvista[jupyter] from 0.46.4 to 0.46.5
          - `#866 <https://github.com/ansys/ansys-sphinx-theme/pull/866>`_

        * - Bump tox from 4.33.0 to 4.34.1
          - `#868 <https://github.com/ansys/ansys-sphinx-theme/pull/868>`_

        * - Bump jupytext from 1.18.1 to 1.19.0
          - `#870 <https://github.com/ansys/ansys-sphinx-theme/pull/870>`_


  .. tab-item:: Maintenance

    .. list-table::
        :header-rows: 0
        :widths: auto

        * - Update CHANGELOG for v1.6.0
          - `#781 <https://github.com/ansys/ansys-sphinx-theme/pull/781>`_

        * - Bump version 1.7.dev0
          - `#783 <https://github.com/ansys/ansys-sphinx-theme/pull/783>`_

        * - Bump the actions group with 3 updates
          - `#793 <https://github.com/ansys/ansys-sphinx-theme/pull/793>`_, `#871 <https://github.com/ansys/ansys-sphinx-theme/pull/871>`_

        * - Update CHANGELOG for v1.6.1
          - `#797 <https://github.com/ansys/ansys-sphinx-theme/pull/797>`_

        * - Bump ansys/actions from 10.0.20 to 10.1.1 in the actions group
          - `#799 <https://github.com/ansys/ansys-sphinx-theme/pull/799>`_

        * - Bump ansys/actions from 10.1.1 to 10.1.2 in the actions group
          - `#801 <https://github.com/ansys/ansys-sphinx-theme/pull/801>`_

        * - Bump ansys/actions from 10.1.2 to 10.1.4 in the actions group
          - `#808 <https://github.com/ansys/ansys-sphinx-theme/pull/808>`_

        * - Add pull request preview action
          - `#813 <https://github.com/ansys/ansys-sphinx-theme/pull/813>`_

        * - Update CHANGELOG for v1.6.2
          - `#817 <https://github.com/ansys/ansys-sphinx-theme/pull/817>`_

        * - Update CHANGELOG for v1.6.3
          - `#818 <https://github.com/ansys/ansys-sphinx-theme/pull/818>`_

        * - Add \`zizmor\` security actions
          - `#820 <https://github.com/ansys/ansys-sphinx-theme/pull/820>`_

        * - Bump actions/download-artifact from 5.0.0 to 6.0.0 in the actions group
          - `#826 <https://github.com/ansys/ansys-sphinx-theme/pull/826>`_

        * - Bump ansys/actions from 10.1.4 to 10.1.5 in the actions group
          - `#829 <https://github.com/ansys/ansys-sphinx-theme/pull/829>`_

        * - Bump actions/checkout from 5.0.0 to 6.0.0 in the actions group
          - `#839 <https://github.com/ansys/ansys-sphinx-theme/pull/839>`_

        * - Update missing or outdated files
          - `#843 <https://github.com/ansys/ansys-sphinx-theme/pull/843>`_

        * - Update doc-deploy-pr configuration in workflow
          - `#847 <https://github.com/ansys/ansys-sphinx-theme/pull/847>`_

        * - Update CHANGELOG for v1.6.4
          - `#850 <https://github.com/ansys/ansys-sphinx-theme/pull/850>`_

        * - Bump the actions group across 1 directory with 3 updates
          - `#851 <https://github.com/ansys/ansys-sphinx-theme/pull/851>`_

        * - Update workflow
          - `#852 <https://github.com/ansys/ansys-sphinx-theme/pull/852>`_

        * - Update workflow dependencies
          - `#853 <https://github.com/ansys/ansys-sphinx-theme/pull/853>`_

        * - Update job dependencies
          - `#854 <https://github.com/ansys/ansys-sphinx-theme/pull/854>`_

        * - Bump actions/checkout from 6.0.1 to 6.0.2 in the actions group
          - `#869 <https://github.com/ansys/ansys-sphinx-theme/pull/869>`_

        * - Fix labels
          - `#876 <https://github.com/ansys/ansys-sphinx-theme/pull/876>`_


`1.6.4 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v1.6.4>`_ (December 09, 2025)
==============================================================================================

.. tab-set::


  .. tab-item:: Fixed

    .. list-table::
        :header-rows: 0
        :widths: auto

        * - Index anchors
          - `#848 <https://github.com/ansys/ansys-sphinx-theme/pull/848>`_


`1.6.3 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v1.6.3>`_ (October 08, 2025)
=============================================================================================

.. tab-set::


  .. tab-item:: Fixed

    .. list-table::
        :header-rows: 0
        :widths: auto

        * - Logo name
          - `#816 <https://github.com/ansys/ansys-sphinx-theme/pull/816>`_


`1.6.2 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v1.6.2>`_ (October 08, 2025)
=============================================================================================

.. tab-set::


  .. tab-item:: Added

    .. list-table::
        :header-rows: 0
        :widths: auto

        * - Adapt new logo
          - `#811 <https://github.com/ansys/ansys-sphinx-theme/pull/811>`_


  .. tab-item:: Fixed

    .. list-table::
        :header-rows: 0
        :widths: auto

        * - Add flexible range for the \`\`pyyaml\`\` version
          - `#814 <https://github.com/ansys/ansys-sphinx-theme/pull/814>`_


  .. tab-item:: Dependencies

    .. list-table::
        :header-rows: 0
        :widths: auto

        * - Bump sphinx-autoapi from 3.6.0 to 3.6.1
          - `#810 <https://github.com/ansys/ansys-sphinx-theme/pull/810>`_


`1.6.1 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v1.6.1>`_ (September 11, 2025)
===============================================================================================

.. tab-set::


  .. tab-item:: Fixed

    .. list-table::
        :header-rows: 0
        :widths: auto

        * - Home link reference
          - `#795 <https://github.com/ansys/ansys-sphinx-theme/pull/795>`_


`1.6.0 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v1.6.0>`_ (August 27, 2025)
============================================================================================

.. tab-set::


  .. tab-item:: Added

    .. list-table::
        :header-rows: 0
        :widths: auto

        * - Dropdown for navigation bar
          - `#723 <https://github.com/ansys/ansys-sphinx-theme/pull/723>`_

        * - Add physics meta tag to headers
          - `#751 <https://github.com/ansys/ansys-sphinx-theme/pull/751>`_

        * - Update actions
          - `#756 <https://github.com/ansys/ansys-sphinx-theme/pull/756>`_

        * - Add multiple tags for `meta-data`
          - `#758 <https://github.com/ansys/ansys-sphinx-theme/pull/758>`_


  .. tab-item:: Fixed

    .. list-table::
        :header-rows: 0
        :widths: auto

        * - the search title case
          - `#715 <https://github.com/ansys/ansys-sphinx-theme/pull/715>`_

        * - Cache of autoapi options with ansys sphinx theme
          - `#728 <https://github.com/ansys/ansys-sphinx-theme/pull/728>`_

        * - Raise exception for deprecated index pattern
          - `#729 <https://github.com/ansys/ansys-sphinx-theme/pull/729>`_

        * - Remove the deprecated pymeilisearch options
          - `#733 <https://github.com/ansys/ansys-sphinx-theme/pull/733>`_

        * - Update the literal  `codespace` to `monospace` font
          - `#744 <https://github.com/ansys/ansys-sphinx-theme/pull/744>`_

        * - Change the  background color
          - `#746 <https://github.com/ansys/ansys-sphinx-theme/pull/746>`_

        * - Add padding on top for breadcrumbs
          - `#752 <https://github.com/ansys/ansys-sphinx-theme/pull/752>`_

        * - Minor improvements in ``jinja`` auto escape and ``subprocess`` call
          - `#754 <https://github.com/ansys/ansys-sphinx-theme/pull/754>`_

        * - Remove deprecated theme option from code base
          - `#755 <https://github.com/ansys/ansys-sphinx-theme/pull/755>`_

        * - Add home section
          - `#769 <https://github.com/ansys/ansys-sphinx-theme/pull/769>`_

        * - Search bar display at ``navbar_end``
          - `#780 <https://github.com/ansys/ansys-sphinx-theme/pull/780>`_


  .. tab-item:: Documentation

    .. list-table::
        :header-rows: 0
        :widths: auto

        * - Update ``CONTRIBUTORS.md`` with the latest contributors
          - `#718 <https://github.com/ansys/ansys-sphinx-theme/pull/718>`_, `#767 <https://github.com/ansys/ansys-sphinx-theme/pull/767>`_


  .. tab-item:: Dependencies

    .. list-table::
        :header-rows: 0
        :widths: auto

        * - bump jupytext from 1.17.1 to 1.17.2
          - `#719 <https://github.com/ansys/ansys-sphinx-theme/pull/719>`_

        * - Bump pandas from 2.2.3 to 2.3.0
          - `#724 <https://github.com/ansys/ansys-sphinx-theme/pull/724>`_

        * - Bump requests from 2.32.3 to 2.32.4
          - `#727 <https://github.com/ansys/ansys-sphinx-theme/pull/727>`_

        * - Bump tox from 4.26.0 to 4.27.0
          - `#732 <https://github.com/ansys/ansys-sphinx-theme/pull/732>`_

        * - Bump numpydoc from 1.8.0 to 1.9.0
          - `#735 <https://github.com/ansys/ansys-sphinx-theme/pull/735>`_

        * - Bump plotly from 6.1.2 to 6.2.0
          - `#738 <https://github.com/ansys/ansys-sphinx-theme/pull/738>`_

        * - Bump notebook from 7.4.3 to 7.4.4
          - `#743 <https://github.com/ansys/ansys-sphinx-theme/pull/743>`_

        * - Bump pandas from 2.3.0 to 2.3.1
          - `#750 <https://github.com/ansys/ansys-sphinx-theme/pull/750>`_

        * - Bump pyvista[jupyter] from 0.45.2 to 0.45.3
          - `#753 <https://github.com/ansys/ansys-sphinx-theme/pull/753>`_

        * - Bump tox from 4.27.0 to 4.28.0
          - `#757 <https://github.com/ansys/ansys-sphinx-theme/pull/757>`_

        * - Bump tox from 4.28.0 to 4.28.1
          - `#759 <https://github.com/ansys/ansys-sphinx-theme/pull/759>`_

        * - Bump tox from 4.28.1 to 4.28.3
          - `#760 <https://github.com/ansys/ansys-sphinx-theme/pull/760>`_

        * - Bump pygithub from 2.6.1 to 2.7.0
          - `#762 <https://github.com/ansys/ansys-sphinx-theme/pull/762>`_

        * - Bump tox from 4.28.3 to 4.28.4
          - `#763 <https://github.com/ansys/ansys-sphinx-theme/pull/763>`_

        * - Bump notebook from 7.4.4 to 7.4.5
          - `#770 <https://github.com/ansys/ansys-sphinx-theme/pull/770>`_

        * - Bump pyvista[jupyter] from 0.45.3 to 0.46.0
          - `#771 <https://github.com/ansys/ansys-sphinx-theme/pull/771>`_

        * - Bump pyvista[jupyter] from 0.46.0 to 0.46.1
          - `#773 <https://github.com/ansys/ansys-sphinx-theme/pull/773>`_

        * - Bump plotly from 6.2.0 to 6.3.0
          - `#774 <https://github.com/ansys/ansys-sphinx-theme/pull/774>`_

        * - Bump requests from 2.32.4 to 2.32.5
          - `#777 <https://github.com/ansys/ansys-sphinx-theme/pull/777>`_

        * - Bump pandas from 2.3.1 to 2.3.2
          - `#778 <https://github.com/ansys/ansys-sphinx-theme/pull/778>`_

        * - Bump pyvista[jupyter] from 0.46.1 to 0.46.2
          - `#779 <https://github.com/ansys/ansys-sphinx-theme/pull/779>`_


  .. tab-item:: Maintenance

    .. list-table::
        :header-rows: 0
        :widths: auto

        * - update CHANGELOG for v1.5.0
          - `#711 <https://github.com/ansys/ansys-sphinx-theme/pull/711>`_

        * - bump version 1.6.dev0
          - `#712 <https://github.com/ansys/ansys-sphinx-theme/pull/712>`_

        * - update the actions to commit hash
          - `#717 <https://github.com/ansys/ansys-sphinx-theme/pull/717>`_

        * - update CHANGELOG for v1.5.1
          - `#720 <https://github.com/ansys/ansys-sphinx-theme/pull/720>`_

        * - update CHANGELOG for v1.5.2
          - `#722 <https://github.com/ansys/ansys-sphinx-theme/pull/722>`_

        * - Bump ansys/actions from 9.0.13 to 10.0.8 in the actions group
          - `#726 <https://github.com/ansys/ansys-sphinx-theme/pull/726>`_

        * - Bump ansys/actions from 10.0.8 to 10.0.11 in the actions group
          - `#731 <https://github.com/ansys/ansys-sphinx-theme/pull/731>`_

        * - Bump ansys/actions from 10.0.11 to 10.0.12 in the actions group
          - `#742 <https://github.com/ansys/ansys-sphinx-theme/pull/742>`_

        * - Update changelog for v1.5.3
          - `#748 <https://github.com/ansys/ansys-sphinx-theme/pull/748>`_

        * - Bump ansys/actions from 10.0.12 to 10.0.13 in the actions group
          - `#761 <https://github.com/ansys/ansys-sphinx-theme/pull/761>`_

        * - Add `trusted publishers pypi release`
          - `#766 <https://github.com/ansys/ansys-sphinx-theme/pull/766>`_

        * - Bump the actions group with 2 updates
          - `#772 <https://github.com/ansys/ansys-sphinx-theme/pull/772>`_

        * - Bump actions/checkout from 4.2.2 to 5.0.0 in the actions group
          - `#776 <https://github.com/ansys/ansys-sphinx-theme/pull/776>`_


`1.5.3 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v1.5.3>`_ (July 02, 2025)
==========================================================================================

.. tab-set::


  .. tab-item:: Fixed

    .. list-table::
        :header-rows: 0
        :widths: auto

        * - Add the search button to ``navbar end`` by default
          - `#747 <https://github.com/ansys/ansys-sphinx-theme/pull/747>`_


`1.5.2 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v1.5.2>`_ (June 02, 2025)
==========================================================================================

.. tab-set::


  .. tab-item:: Fixed

    .. list-table::
        :header-rows: 0
        :widths: auto

        * - remove font weight on highlight
          - `#721 <https://github.com/ansys/ansys-sphinx-theme/pull/721>`_


`1.5.1 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v1.5.1>`_ (June 02, 2025)
==========================================================================================

.. tab-set::


  .. tab-item:: Fixed

    .. list-table::
        :header-rows: 0
        :widths: auto

        * - revert the main content style
          - `#714 <https://github.com/ansys/ansys-sphinx-theme/pull/714>`_


`1.5.0 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v1.5.0>`_ (May 28, 2025)
=========================================================================================

.. tab-set::


  .. tab-item:: Added

    .. list-table::
        :header-rows: 0
        :widths: auto

        * - add multi index searching and filtering
          - `#674 <https://github.com/ansys/ansys-sphinx-theme/pull/674>`_

        * - small layout adjustments
          - `#691 <https://github.com/ansys/ansys-sphinx-theme/pull/691>`_

        * - add customization instructions for SCSS files in developer documentation
          - `#694 <https://github.com/ansys/ansys-sphinx-theme/pull/694>`_

        * - add 'serve' command to Makefile and make.bat for serving documentation
          - `#698 <https://github.com/ansys/ansys-sphinx-theme/pull/698>`_


  .. tab-item:: Fixed

    .. list-table::
        :header-rows: 0
        :widths: auto

        * - smaller screen view and search for mobile views
          - `#689 <https://github.com/ansys/ansys-sphinx-theme/pull/689>`_

        * - style for back to top button
          - `#693 <https://github.com/ansys/ansys-sphinx-theme/pull/693>`_

        * - url for fetch extra source file
          - `#707 <https://github.com/ansys/ansys-sphinx-theme/pull/707>`_


  .. tab-item:: Documentation

    .. list-table::
        :header-rows: 0
        :widths: auto

        * - update the multi-index docs
          - `#708 <https://github.com/ansys/ansys-sphinx-theme/pull/708>`_


  .. tab-item:: Dependencies

    .. list-table::
        :header-rows: 0
        :widths: auto

        * - bump notebook from 7.4.1 to 7.4.2
          - `#684 <https://github.com/ansys/ansys-sphinx-theme/pull/684>`_

        * - update snowballstemmer requirement from <3 to <4
          - `#688 <https://github.com/ansys/ansys-sphinx-theme/pull/688>`_

        * - bump pyvista[jupyter] from 0.45.0 to 0.45.1
          - `#690 <https://github.com/ansys/ansys-sphinx-theme/pull/690>`_

        * - bump pyvista[jupyter] from 0.45.1 to 0.45.2
          - `#699 <https://github.com/ansys/ansys-sphinx-theme/pull/699>`_

        * - bump tox from 4.25.0 to 4.26.0
          - `#700 <https://github.com/ansys/ansys-sphinx-theme/pull/700>`_

        * - bump plotly from 6.0.1 to 6.1.1
          - `#701 <https://github.com/ansys/ansys-sphinx-theme/pull/701>`_

        * - bump notebook from 7.4.2 to 7.4.3
          - `#705 <https://github.com/ansys/ansys-sphinx-theme/pull/705>`_

        * - bump plotly from 6.1.1 to 6.1.2
          - `#709 <https://github.com/ansys/ansys-sphinx-theme/pull/709>`_


  .. tab-item:: Maintenance

    .. list-table::
        :header-rows: 0
        :widths: auto

        * - update CHANGELOG for v1.4.5
          - `#706 <https://github.com/ansys/ansys-sphinx-theme/pull/706>`_


`1.4.5 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v1.4.5>`_ (May 27, 2025)
=========================================================================================

.. tab-set::


  .. tab-item:: Added

    .. list-table::
        :header-rows: 0
        :widths: auto

        * - add deprecated warning for `index_pattern` search option
          - `#704 <https://github.com/ansys/ansys-sphinx-theme/pull/704>`_


`1.4.4 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v1.4.4>`_ (May 08, 2025)
=========================================================================================

.. tab-set::


  .. tab-item:: Added

    .. list-table::
        :header-rows: 0
        :widths: auto

        * - add metatag content
          - `#680 <https://github.com/ansys/ansys-sphinx-theme/pull/680>`_


  .. tab-item:: Fixed

    .. list-table::
        :header-rows: 0
        :widths: auto

        * - block snowbalstemmer <3 for now
          - `#686 <https://github.com/ansys/ansys-sphinx-theme/pull/686>`_


  .. tab-item:: Documentation

    .. list-table::
        :header-rows: 0
        :widths: auto

        * - Update ``CONTRIBUTORS.md`` with the latest contributors
          - `#669 <https://github.com/ansys/ansys-sphinx-theme/pull/669>`_, `#677 <https://github.com/ansys/ansys-sphinx-theme/pull/677>`_


  .. tab-item:: Dependencies

    .. list-table::
        :header-rows: 0
        :widths: auto

        * - bump tox from 4.24.2 to 4.25.0
          - `#668 <https://github.com/ansys/ansys-sphinx-theme/pull/668>`_

        * - bump pyvista[jupyter] from 0.44.2 to 0.45.0
          - `#675 <https://github.com/ansys/ansys-sphinx-theme/pull/675>`_

        * - bump notebook from 7.3.3 to 7.4.1
          - `#676 <https://github.com/ansys/ansys-sphinx-theme/pull/676>`_

        * - bump jupytext from 1.16.7 to 1.17.1
          - `#678 <https://github.com/ansys/ansys-sphinx-theme/pull/678>`_


  .. tab-item:: Maintenance

    .. list-table::
        :header-rows: 0
        :widths: auto

        * - add github token
          - `#661 <https://github.com/ansys/ansys-sphinx-theme/pull/661>`_

        * - update CHANGELOG for v1.4.0
          - `#662 <https://github.com/ansys/ansys-sphinx-theme/pull/662>`_

        * - bump version 1.5.dev0
          - `#663 <https://github.com/ansys/ansys-sphinx-theme/pull/663>`_

        * - update CHANGELOG for v1.4.1
          - `#665 <https://github.com/ansys/ansys-sphinx-theme/pull/665>`_

        * - bump ansys/actions from 8 to 9 in the actions group
          - `#670 <https://github.com/ansys/ansys-sphinx-theme/pull/670>`_


`1.4.3 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v1.4.3>`_ (May 07, 2025)
=========================================================================================

.. tab-set::


  .. tab-item:: Added

    .. list-table::
        :header-rows: 0
        :widths: auto

        * - add metatag content
          - `#680 <https://github.com/ansys/ansys-sphinx-theme/pull/680>`_


  .. tab-item:: Maintenance

    .. list-table::
        :header-rows: 0
        :widths: auto

        * - bump ansys/actions from 8 to 9 in the actions group
          - `#670 <https://github.com/ansys/ansys-sphinx-theme/pull/670>`_


`1.4.2 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v1.4.2>`_ (March 27, 2025)
===========================================================================================

.. tab-set::


  .. tab-item:: Fixed

    .. list-table::
        :header-rows: 0
        :widths: auto

        * - autoapi child class template
          - `#666 <https://github.com/ansys/ansys-sphinx-theme/pull/666>`_


`1.4.1 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v1.4.1>`_ (March 27, 2025)
===========================================================================================

.. tab-set::


  .. tab-item:: Fixed

    .. list-table::
        :header-rows: 0
        :widths: auto

        * - quarto std logging
          - `#664 <https://github.com/ansys/ansys-sphinx-theme/pull/664>`_


`1.4.0 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v1.4.0>`_ (March 27, 2025)
===========================================================================================

.. tab-set::


  .. tab-item:: Added

    .. list-table::
        :header-rows: 0
        :widths: auto

        * - enable matplotlib and plotly in examples
          - `#567 <https://github.com/ansys/ansys-sphinx-theme/pull/567>`_

        * - feat: add python 3.13 support
          - `#635 <https://github.com/ansys/ansys-sphinx-theme/pull/635>`_

        * - feat: Add Tox environment for documentation preview
          - `#642 <https://github.com/ansys/ansys-sphinx-theme/pull/642>`_

        * - migrate css to scss
          - `#644 <https://github.com/ansys/ansys-sphinx-theme/pull/644>`_


  .. tab-item:: Fixed

    .. list-table::
        :header-rows: 0
        :widths: auto

        * - update the style for highlight name function
          - `#652 <https://github.com/ansys/ansys-sphinx-theme/pull/652>`_

        * - update the changelog action only for PR
          - `#654 <https://github.com/ansys/ansys-sphinx-theme/pull/654>`_

        * - change logging info to error in quarto build
          - `#655 <https://github.com/ansys/ansys-sphinx-theme/pull/655>`_

        * - quarto error logging
          - `#658 <https://github.com/ansys/ansys-sphinx-theme/pull/658>`_


  .. tab-item:: Documentation

    .. list-table::
        :header-rows: 0
        :widths: auto

        * - chore: update CHANGELOG for v1.3.0
          - `#614 <https://github.com/ansys/ansys-sphinx-theme/pull/614>`_

        * - chore: update CHANGELOG for v1.3.1
          - `#618 <https://github.com/ansys/ansys-sphinx-theme/pull/618>`_

        * - chore: update CHANGELOG for v1.3.2
          - `#631 <https://github.com/ansys/ansys-sphinx-theme/pull/631>`_

        * - docs: add contribute section
          - `#636 <https://github.com/ansys/ansys-sphinx-theme/pull/636>`_

        * - docs: add contribute page in toctree
          - `#638 <https://github.com/ansys/ansys-sphinx-theme/pull/638>`_

        * - chore: update CHANGELOG for v1.3.3
          - `#648 <https://github.com/ansys/ansys-sphinx-theme/pull/648>`_


  .. tab-item:: Dependencies

    .. list-table::
        :header-rows: 0
        :widths: auto

        * - chore(deps): bump jupytext from 1.16.6 to 1.16.7
          - `#622 <https://github.com/ansys/ansys-sphinx-theme/pull/622>`_

        * - chore(deps): bump sphinx-autoapi from 3.4.0 to 3.5.0
          - `#623 <https://github.com/ansys/ansys-sphinx-theme/pull/623>`_

        * - chore(deps): bump sphinx-gallery from 0.18.0 to 0.19.0
          - `#625 <https://github.com/ansys/ansys-sphinx-theme/pull/625>`_

        * - chore(deps): bump pygithub from 2.5.0 to 2.6.0
          - `#626 <https://github.com/ansys/ansys-sphinx-theme/pull/626>`_

        * - chore(deps): bump sphinx from 8.1.3 to 8.2.0
          - `#628 <https://github.com/ansys/ansys-sphinx-theme/pull/628>`_

        * - chore(deps): bump sphinx-autoapi from 3.5.0 to 3.6.0
          - `#629 <https://github.com/ansys/ansys-sphinx-theme/pull/629>`_

        * - build: bump nbsphinx from 0.9.6 to 0.9.7
          - `#637 <https://github.com/ansys/ansys-sphinx-theme/pull/637>`_

        * - build: bump tox from 4.24.1 to 4.24.2
          - `#645 <https://github.com/ansys/ansys-sphinx-theme/pull/645>`_

        * - build: bump notebook from 7.3.2 to 7.3.3
          - `#651 <https://github.com/ansys/ansys-sphinx-theme/pull/651>`_


  .. tab-item:: Maintenance

    .. list-table::
        :header-rows: 0
        :widths: auto

        * - feat: migrate the builds system to stb
          - `#639 <https://github.com/ansys/ansys-sphinx-theme/pull/639>`_


  .. tab-item:: Miscellaneous

    .. list-table::
        :header-rows: 0
        :widths: auto

        * - chore: bump version 1.4.dev0
          - `#615 <https://github.com/ansys/ansys-sphinx-theme/pull/615>`_

        * - fix: remove flake8 configuration file
          - `#641 <https://github.com/ansys/ansys-sphinx-theme/pull/641>`_

        * - fix: improve Logging in Quarto cheatsheet build process
          - `#646 <https://github.com/ansys/ansys-sphinx-theme/pull/646>`_

        * - cheatsheet and whatsnew functions into separate modules and implement sidebar ordering
          - `#656 <https://github.com/ansys/ansys-sphinx-theme/pull/656>`_

        * - ansys sphinx theme variables
          - `#657 <https://github.com/ansys/ansys-sphinx-theme/pull/657>`_


`1.3.3 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v1.3.3>`_ (March 11, 2025)
===========================================================================================

Dependencies
^^^^^^^^^^^^

- chore(deps): bump pygithub from 2.6.0 to 2.6.1 `#632 <https://github.com/ansys/ansys-sphinx-theme/pull/632>`_


Miscellaneous
^^^^^^^^^^^^^

- fix: alignment and styles for primary sidebar `#621 <https://github.com/ansys/ansys-sphinx-theme/pull/621>`_
- fix: typo in autoapi template `#630 <https://github.com/ansys/ansys-sphinx-theme/pull/630>`_


Documentation
^^^^^^^^^^^^^

- Fix: whatsnew config instructions `#619 <https://github.com/ansys/ansys-sphinx-theme/pull/619>`_


Maintenance
^^^^^^^^^^^

- fix: prettier pre-commit hook `#627 <https://github.com/ansys/ansys-sphinx-theme/pull/627>`_

`1.3.1 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v1.3.1>`_ (2025-02-06)
=======================================================================================

Documentation
^^^^^^^^^^^^^

- Fix: optimize imports for whatsnew `#617 <https://github.com/ansys/ansys-sphinx-theme/pull/617>`_

`1.3.0 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v1.3.0>`_ (2025-02-05)
=======================================================================================

Dependencies
^^^^^^^^^^^^

- chore(deps): bump pygithub from 2.4.0 to 2.5.0 `#582 <https://github.com/ansys/ansys-sphinx-theme/pull/582>`_
- chore(deps): bump pyvista[jupyter] from 0.44.1 to 0.44.2 `#589 <https://github.com/ansys/ansys-sphinx-theme/pull/589>`_
- chore(deps): bump sphinx-autoapi from 3.3.3 to 3.4.0 `#592 <https://github.com/ansys/ansys-sphinx-theme/pull/592>`_
- chore(deps): bump notebook from 7.2.2 to 7.3.1 `#596 <https://github.com/ansys/ansys-sphinx-theme/pull/596>`_
- chore(deps): bump jupytext from 1.16.4 to 1.16.5 `#598 <https://github.com/ansys/ansys-sphinx-theme/pull/598>`_
- chore(deps): bump jupytext from 1.16.5 to 1.16.6 `#600 <https://github.com/ansys/ansys-sphinx-theme/pull/600>`_
- chore(deps): bump notebook from 7.3.1 to 7.3.2 `#606 <https://github.com/ansys/ansys-sphinx-theme/pull/606>`_
- chore(deps): bump nbsphinx from 0.9.5 to 0.9.6 `#607 <https://github.com/ansys/ansys-sphinx-theme/pull/607>`_
- chore(deps): bump sphinx-notfound-page from 1.0.4 to 1.1.0 `#611 <https://github.com/ansys/ansys-sphinx-theme/pull/611>`_


Miscellaneous
^^^^^^^^^^^^^

- chore: bump version 1.3.dev0 `#577 <https://github.com/ansys/ansys-sphinx-theme/pull/577>`_
- fix: CONTRIBUTORS.md `#578 <https://github.com/ansys/ansys-sphinx-theme/pull/578>`_
- fix: errors and warnings caused by CSS imports `#588 <https://github.com/ansys/ansys-sphinx-theme/pull/588>`_
- fix:  typo in date variable for last modified `#602 <https://github.com/ansys/ansys-sphinx-theme/pull/602>`_
- chore: update CHANGELOG for v1.2.5 `#609 <https://github.com/ansys/ansys-sphinx-theme/pull/609>`_


Documentation
^^^^^^^^^^^^^

- chore: update CHANGELOG for v1.2.0 `#576 <https://github.com/ansys/ansys-sphinx-theme/pull/576>`_
- feat: add whatsnew options `#583 <https://github.com/ansys/ansys-sphinx-theme/pull/583>`_
- chore: update CHANGELOG for v1.2.1 `#585 <https://github.com/ansys/ansys-sphinx-theme/pull/585>`_
- chore: update CHANGELOG for v1.2.2 `#587 <https://github.com/ansys/ansys-sphinx-theme/pull/587>`_
- chore: update CHANGELOG for v1.2.3 `#595 <https://github.com/ansys/ansys-sphinx-theme/pull/595>`_
- chore: update CHANGELOG for v1.2.4 `#604 <https://github.com/ansys/ansys-sphinx-theme/pull/604>`_
- chore: update CHANGELOG for v1.2.7 `#613 <https://github.com/ansys/ansys-sphinx-theme/pull/613>`_


Maintenance
^^^^^^^^^^^

- fix: style and license headers `#608 <https://github.com/ansys/ansys-sphinx-theme/pull/608>`_

`1.2.7 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v1.2.7>`_ - 2025-02-04
=======================================================================================

Maintenance
^^^^^^^^^^^

- fix: astroid version `#612 <https://github.com/ansys/ansys-sphinx-theme/pull/612>`_

`1.2.5 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v1.2.5>`_ - 2025-01-13
=======================================================================================

Dependencies
^^^^^^^^^^^^

- chore(deps): update pydata-sphinx-theme requirement from <0.16,>=0.15.4 to >=0.15.4,<0.17 `#605 <https://github.com/ansys/ansys-sphinx-theme/pull/605>`_

`1.2.4 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v1.2.4>`_ - 2024-12-20
=======================================================================================

Miscellaneous
^^^^^^^^^^^^^

- fix: impose upper version for the pydata-sphinx-theme `#603 <https://github.com/ansys/ansys-sphinx-theme/pull/603>`_

`1.2.3 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v1.2.3>`_ - 2024-12-05
=======================================================================================

Miscellaneous
^^^^^^^^^^^^^

- fix: rename the ``date`` to ``ast_build_date`` in js `#594 <https://github.com/ansys/ansys-sphinx-theme/pull/594>`_

`1.2.2 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v1.2.2>`_ - 2024-11-21
=======================================================================================

Miscellaneous
^^^^^^^^^^^^^

- fix: section ids with search `#586 <https://github.com/ansys/ansys-sphinx-theme/pull/586>`_

`1.2.1 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v1.2.1>`_ - 2024-11-13
=======================================================================================

Miscellaneous
^^^^^^^^^^^^^

- fix: enable local page `Search` and default to PyData search on 'Enter' `#584 <https://github.com/ansys/ansys-sphinx-theme/pull/584>`_


Documentation
^^^^^^^^^^^^^

- Enable 'show_prev_next' in the documented defaults `#580 <https://github.com/ansys/ansys-sphinx-theme/pull/580>`_

`1.2.0 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v1.2.0>`_ - 2024-10-31
=======================================================================================

Fixed
^^^^^

- fix: contributors file `#529 <https://github.com/ansys/ansys-sphinx-theme/pull/529>`_
- fix: padding for toctree entry in sidebar `#554 <https://github.com/ansys/ansys-sphinx-theme/pull/554>`_
- fix: revisit header size `#555 <https://github.com/ansys/ansys-sphinx-theme/pull/555>`_


Dependencies
^^^^^^^^^^^^

- chore: bump version 1.2.dev0 `#518 <https://github.com/ansys/ansys-sphinx-theme/pull/518>`_
- chore(deps): bump sphinx-gallery from 0.17.1 to 0.18.0 `#538 <https://github.com/ansys/ansys-sphinx-theme/pull/538>`_
- chore(deps): bump sphinx from 8.0.2 to 8.1.3 `#546 <https://github.com/ansys/ansys-sphinx-theme/pull/546>`_
- chore(deps): update pydata-sphinx-theme requirement from <0.16,>=0.15.4 to >=0.15.4,<0.17 `#562 <https://github.com/ansys/ansys-sphinx-theme/pull/562>`_
- chore(deps): bump sphinx-autoapi from 3.3.2 to 3.3.3 `#569 <https://github.com/ansys/ansys-sphinx-theme/pull/569>`_


Miscellaneous
^^^^^^^^^^^^^

- fix: cleanup autoapi templates using macros `#556 <https://github.com/ansys/ansys-sphinx-theme/pull/556>`_
- fix: typos `#560 <https://github.com/ansys/ansys-sphinx-theme/pull/560>`_
- fix: change the display of math rendering `#568 <https://github.com/ansys/ansys-sphinx-theme/pull/568>`_


Documentation
^^^^^^^^^^^^^

- chore: update CHANGELOG for v1.1.0 `#516 <https://github.com/ansys/ansys-sphinx-theme/pull/516>`_
- chore: update CHANGELOG for v1.1.1 `#520 <https://github.com/ansys/ansys-sphinx-theme/pull/520>`_
- chore: update CHANGELOG for v1.1.2 `#522 <https://github.com/ansys/ansys-sphinx-theme/pull/522>`_
- docs: adding ``title`` in example section `#524 <https://github.com/ansys/ansys-sphinx-theme/pull/524>`_
- fix: add more components to the search indexing `#541 <https://github.com/ansys/ansys-sphinx-theme/pull/541>`_
- chore: update CHANGELOG for v1.1.3 `#545 <https://github.com/ansys/ansys-sphinx-theme/pull/545>`_
- chore: update CHANGELOG for v1.1.4 `#547 <https://github.com/ansys/ansys-sphinx-theme/pull/547>`_
- chore: update CHANGELOG for v1.1.5 `#550 <https://github.com/ansys/ansys-sphinx-theme/pull/550>`_
- doc: allow developer to skip examples build `#553 <https://github.com/ansys/ansys-sphinx-theme/pull/553>`_
- chore: update CHANGELOG for v1.1.6 `#559 <https://github.com/ansys/ansys-sphinx-theme/pull/559>`_
- docs: update the landing page `#561 <https://github.com/ansys/ansys-sphinx-theme/pull/561>`_
- chore: update CHANGELOG for v1.1.7 `#566 <https://github.com/ansys/ansys-sphinx-theme/pull/566>`_
- fix: exclude search files `#572 <https://github.com/ansys/ansys-sphinx-theme/pull/572>`_


Maintenance
^^^^^^^^^^^

- ci: bump ansys/actions from 7 to 8 `#530 <https://github.com/ansys/ansys-sphinx-theme/pull/530>`_
- chore: add hacktoberfest labels `#535 <https://github.com/ansys/ansys-sphinx-theme/pull/535>`_
- ci: add new labels `#549 <https://github.com/ansys/ansys-sphinx-theme/pull/549>`_
- ci: update labeling strategy `#558 <https://github.com/ansys/ansys-sphinx-theme/pull/558>`_

`1.1.7 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v1.1.7>`_ - 2024-10-23
=======================================================================================

Miscellaneous
^^^^^^^^^^^^^

- fix: ensure app.builder.outdir is a Path object `#565 <https://github.com/ansys/ansys-sphinx-theme/pull/565>`_

`1.1.6 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v1.1.6>`_ - 2024-10-18
=======================================================================================

Fixed
^^^^^

- fix: add the default search options in the config env `#557 <https://github.com/ansys/ansys-sphinx-theme/pull/557>`_

`1.1.5 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v1.1.5>`_ - 2024-10-15
=======================================================================================

Fixed
^^^^^

- use ansys-sphinx-theme variables in CSS files `#537 <https://github.com/ansys/ansys-sphinx-theme/pull/537>`_

`1.1.4 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v1.1.4>`_ - 2024-10-14
=======================================================================================

Fixed
^^^^^

- fix: static search performance `#525 <https://github.com/ansys/ansys-sphinx-theme/pull/525>`_

`1.1.3 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v1.1.3>`_ - 2024-10-11
=======================================================================================

Fixed
^^^^^

- fix: add default `enter` for search `#542 <https://github.com/ansys/ansys-sphinx-theme/pull/542>`_

`1.1.2 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v1.1.2>`_ - 2024-10-02
=======================================================================================

Fixed
^^^^^

- fix: add version as params in cheatsheet `#521 <https://github.com/ansys/ansys-sphinx-theme/pull/521>`_

`1.1.1 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v1.1.1>`_ - 2024-10-01
=======================================================================================

Fixed
^^^^^

- fix(ci): update to Ansys actions v8 `#517 <https://github.com/ansys/ansys-sphinx-theme/pull/517>`_
- fix: update the token and email of bot for changelog actions `#519 <https://github.com/ansys/ansys-sphinx-theme/pull/519>`_

`1.1.0 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v1.1.0>`_ - 2024-10-01
=======================================================================================

Added
^^^^^

- feat: add static search `#487 <https://github.com/ansys/ansys-sphinx-theme/pull/487>`_


Changed
^^^^^^^

- chore: update CHANGELOG for v1.0.0 `#445 <https://github.com/ansys/ansys-sphinx-theme/pull/445>`_
- chore: update CHANGELOG for v1.0.1 `#447 <https://github.com/ansys/ansys-sphinx-theme/pull/447>`_
- chore: update CHANGELOG for v1.0.2 `#451 <https://github.com/ansys/ansys-sphinx-theme/pull/451>`_
- chore: update CHANGELOG for v1.0.3 `#455 <https://github.com/ansys/ansys-sphinx-theme/pull/455>`_


Fixed
^^^^^

- maint: update tooling, cleanup and drop python 3.9 `#484 <https://github.com/ansys/ansys-sphinx-theme/pull/484>`_
- feat: implement default search bar expansion behavior `#496 <https://github.com/ansys/ansys-sphinx-theme/pull/496>`_
- fix: the anchor url of search with the switcher version `#497 <https://github.com/ansys/ansys-sphinx-theme/pull/497>`_
- fix: change file location for `search.json` file `#509 <https://github.com/ansys/ansys-sphinx-theme/pull/509>`_
- maint: styles for dark theme search bar `#511 <https://github.com/ansys/ansys-sphinx-theme/pull/511>`_
- fix: style for smaller media `#513 <https://github.com/ansys/ansys-sphinx-theme/pull/513>`_
- fix: navigation end columns `#514 <https://github.com/ansys/ansys-sphinx-theme/pull/514>`_
- fix: add title breadcrumbs `#515 <https://github.com/ansys/ansys-sphinx-theme/pull/515>`_


Dependencies
^^^^^^^^^^^^

- maint: version 1.1.dev0 `#448 <https://github.com/ansys/ansys-sphinx-theme/pull/448>`_
- build(deps): bump pygithub from 2.3.0 to 2.4.0 `#480 <https://github.com/ansys/ansys-sphinx-theme/pull/480>`_
- build(deps): bump notebook from 7.2.1 to 7.2.2 `#482 <https://github.com/ansys/ansys-sphinx-theme/pull/482>`_
- build(deps): bump sphinx-autoapi from 3.2.1 to 3.3.0 `#485 <https://github.com/ansys/ansys-sphinx-theme/pull/485>`_
- build(deps): bump sphinx-autoapi from 3.3.0 to 3.3.1 `#488 <https://github.com/ansys/ansys-sphinx-theme/pull/488>`_
- build(deps): bump pandas from 2.2.2 to 2.2.3 `#508 <https://github.com/ansys/ansys-sphinx-theme/pull/508>`_
- build(deps): bump sphinx-autoapi from 3.3.1 to 3.3.2 `#512 <https://github.com/ansys/ansys-sphinx-theme/pull/512>`_


Documentation
^^^^^^^^^^^^^

- chore: update CHANGELOG for v1.0.4 `#463 <https://github.com/ansys/ansys-sphinx-theme/pull/463>`_
- chore: update CHANGELOG for v1.0.6 `#476 <https://github.com/ansys/ansys-sphinx-theme/pull/476>`_
- chore: update CHANGELOG for v1.0.7 `#478 <https://github.com/ansys/ansys-sphinx-theme/pull/478>`_
- chore: update CHANGELOG for v1.0.8 `#491 <https://github.com/ansys/ansys-sphinx-theme/pull/491>`_
- chore: update CHANGELOG for v1.0.9 `#501 <https://github.com/ansys/ansys-sphinx-theme/pull/501>`_
- chore: update CHANGELOG for v1.0.10 `#504 <https://github.com/ansys/ansys-sphinx-theme/pull/504>`_
- chore: update CHANGELOG for v1.0.11 `#507 <https://github.com/ansys/ansys-sphinx-theme/pull/507>`_

`1.0.11 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v1.0.11>`_ - 2024-09-19
=========================================================================================

Fixed
^^^^^

- fix: location of nbsphinx `#506 <https://github.com/ansys/ansys-sphinx-theme/pull/506>`_

`1.0.10 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v1.0.10>`_ - 2024-09-18
=========================================================================================

Fixed
^^^^^

- fix: do not display captions for nbgallery `#503 <https://github.com/ansys/ansys-sphinx-theme/pull/503>`_

`1.0.9 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v1.0.9>`_ - 2024-09-16
=======================================================================================

Added
^^^^^

- feat: add member_order to autoapi `#495 <https://github.com/ansys/ansys-sphinx-theme/pull/495>`_


Fixed
^^^^^

- fix: ``autoapi`` relative directory path wrt ``tox`` env `#494 <https://github.com/ansys/ansys-sphinx-theme/pull/494>`_

`1.0.8 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v1.0.8>`_ - 2024-09-03
=======================================================================================

Fixed
^^^^^

- fix: Align jupyter cell output `#489 <https://github.com/ansys/ansys-sphinx-theme/pull/489>`_
- fix: the download in sphinx gallery `#490 <https://github.com/ansys/ansys-sphinx-theme/pull/490>`_

`1.0.7 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v1.0.7>`_ - 2024-08-23
=======================================================================================

Fixed
^^^^^

- fix: autoapi extension `#472 <https://github.com/ansys/ansys-sphinx-theme/pull/472>`_
- fix: admonitions styles for ``topic`` admonition `#477 <https://github.com/ansys/ansys-sphinx-theme/pull/477>`_

`1.0.6 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v1.0.6>`_ - 2024-08-23
=======================================================================================

Fixed
^^^^^

- fix: download icon with sphinx-gallery and nbsphinx `#471 <https://github.com/ansys/ansys-sphinx-theme/pull/471>`_
- feat: add different width for different media for main content `#473 <https://github.com/ansys/ansys-sphinx-theme/pull/473>`_
- fix: the scrollbar on sidebar `#474 <https://github.com/ansys/ansys-sphinx-theme/pull/474>`_


Documentation
^^^^^^^^^^^^^

- chore: update CHANGELOG for v1.0.5 `#470 <https://github.com/ansys/ansys-sphinx-theme/pull/470>`_

`1.0.5 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v1.0.5>`_ - 2024-08-16
=======================================================================================

Fixed
^^^^^

- feat: add default logo links for Ansys and PyAnsys logos `#469 <https://github.com/ansys/ansys-sphinx-theme/pull/469>`_


Dependencies
^^^^^^^^^^^^

- build(deps): bump nbsphinx from 0.9.4 to 0.9.5 `#465 <https://github.com/ansys/ansys-sphinx-theme/pull/465>`_

`1.0.4 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v1.0.4>`_ - 2024-08-13
=======================================================================================

Fixed
^^^^^

- fix: tables and cell output `#460 <https://github.com/ansys/ansys-sphinx-theme/pull/460>`_


Dependencies
^^^^^^^^^^^^

- ci: bump ansys/actions from 6 to 7 `#457 <https://github.com/ansys/ansys-sphinx-theme/pull/457>`_
- build(deps): bump numpydoc from 1.7.0 to 1.8.0 `#459 <https://github.com/ansys/ansys-sphinx-theme/pull/459>`_

`1.0.3 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v1.0.3>`_ - 2024-08-09
=======================================================================================

Fixed
^^^^^

- fix: minor style changes `#452 <https://github.com/ansys/ansys-sphinx-theme/pull/452>`_
- fix: downgrade the autoapi and keep ``autoapi`` toctree to ``True`` by default `#453 <https://github.com/ansys/ansys-sphinx-theme/pull/453>`_
- fix: `pygment_styles` with dark and light theme and dark theme table `#454 <https://github.com/ansys/ansys-sphinx-theme/pull/454>`_

`1.0.2 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v1.0.2>`_ - 2024-08-08
=======================================================================================

Changed
^^^^^^^

- maint: update ansys actions `#449 <https://github.com/ansys/ansys-sphinx-theme/pull/449>`_


Fixed
^^^^^

- fix: sphinx design image background `#450 <https://github.com/ansys/ansys-sphinx-theme/pull/450>`_

`1.0.1 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v1.0.1>`_ - 2024-08-08
=======================================================================================

Fixed
^^^^^

- fix: stable docs indexing package name `#446 <https://github.com/ansys/ansys-sphinx-theme/pull/446>`_

`1.0.0 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v1.0.0>`_ - 2024-08-08
=======================================================================================

Added
^^^^^

- fix: update the github icon `#401 <https://github.com/ansys/ansys-sphinx-theme/pull/401>`_
- feat: add default logo and update logo option with theme `#425 <https://github.com/ansys/ansys-sphinx-theme/pull/425>`_
- feat: add quarto cheat sheet extension with cheat sheet option `#428 <https://github.com/ansys/ansys-sphinx-theme/pull/428>`_


Changed
^^^^^^^

- chore: update CHANGELOG for v0.16.2 `#381 <https://github.com/ansys/ansys-sphinx-theme/pull/381>`_
- chore: update CHANGELOG for v0.16.3 `#389 <https://github.com/ansys/ansys-sphinx-theme/pull/389>`_
- chore: update CHANGELOG for v0.16.4 `#390 <https://github.com/ansys/ansys-sphinx-theme/pull/390>`_
- chore: update CHANGELOG for v0.16.5 `#394 <https://github.com/ansys/ansys-sphinx-theme/pull/394>`_
- chore: update CHANGELOG for v0.16.6 `#402 <https://github.com/ansys/ansys-sphinx-theme/pull/402>`_


Fixed
^^^^^

- fix: Align cheat sheet center `#382 <https://github.com/ansys/ansys-sphinx-theme/pull/382>`_
- fix: reformat the style files `#406 <https://github.com/ansys/ansys-sphinx-theme/pull/406>`_
- fix: reformat the table styles `#408 <https://github.com/ansys/ansys-sphinx-theme/pull/408>`_
- fix: reformat navigation bar and background `#409 <https://github.com/ansys/ansys-sphinx-theme/pull/409>`_
- fix: `primary` ,`secondary` sidebars and links `#411 <https://github.com/ansys/ansys-sphinx-theme/pull/411>`_
- fix: sphinx design reformat `#412 <https://github.com/ansys/ansys-sphinx-theme/pull/412>`_
- fix: update the breadcrumbs `#419 <https://github.com/ansys/ansys-sphinx-theme/pull/419>`_
- fix: admonitions style `#424 <https://github.com/ansys/ansys-sphinx-theme/pull/424>`_
- fix: sidebar borders and overflow `#427 <https://github.com/ansys/ansys-sphinx-theme/pull/427>`_
- fix: search bar styles `#429 <https://github.com/ansys/ansys-sphinx-theme/pull/429>`_
- fix: updated the logo options `#431 <https://github.com/ansys/ansys-sphinx-theme/pull/431>`_
- fix: add dropdown styles for the header navigation bar `#437 <https://github.com/ansys/ansys-sphinx-theme/pull/437>`_
- fix: dark theme variables `#438 <https://github.com/ansys/ansys-sphinx-theme/pull/438>`_
- fix: sphinx card `box shadow` on focus `#439 <https://github.com/ansys/ansys-sphinx-theme/pull/439>`_
- fix: focus links with keyboard `#440 <https://github.com/ansys/ansys-sphinx-theme/pull/440>`_
- fix: search bar style for dark theme, icons links `#442 <https://github.com/ansys/ansys-sphinx-theme/pull/442>`_


Dependencies
^^^^^^^^^^^^

- build(deps-dev): update pydata-sphinx-theme requirement from <0.15,>=0.14 to >=0.15 `#336 <https://github.com/ansys/ansys-sphinx-theme/pull/336>`_
- chore: version 0.17.dev0 `#386 <https://github.com/ansys/ansys-sphinx-theme/pull/386>`_
- chore(deps): bump requests from 2.32.2 to 2.32.3 `#391 <https://github.com/ansys/ansys-sphinx-theme/pull/391>`_
- docs: reformat the documentation `#396 <https://github.com/ansys/ansys-sphinx-theme/pull/396>`_
- chore(deps): bump sphinx-autoapi from 3.1.1 to 3.1.2 `#405 <https://github.com/ansys/ansys-sphinx-theme/pull/405>`_
- build(deps): bump pyvista[jupyter] from 0.43.10 to 0.44.0 `#413 <https://github.com/ansys/ansys-sphinx-theme/pull/413>`_
- build(deps): bump jupytext from 1.16.2 to 1.16.3 `#415 <https://github.com/ansys/ansys-sphinx-theme/pull/415>`_
- build(deps): bump sphinx from 7.3.7 to 7.4.4 `#416 <https://github.com/ansys/ansys-sphinx-theme/pull/416>`_
- build(deps): bump sphinx from 7.4.4 to 7.4.5 `#417 <https://github.com/ansys/ansys-sphinx-theme/pull/417>`_
- build(deps): bump sphinx from 7.4.5 to 7.4.6 `#418 <https://github.com/ansys/ansys-sphinx-theme/pull/418>`_
- build(deps): bump sphinx-autoapi from 3.1.2 to 3.2.0 `#420 <https://github.com/ansys/ansys-sphinx-theme/pull/420>`_
- build(deps): bump sphinx-gallery from 0.16.0 to 0.17.0 `#421 <https://github.com/ansys/ansys-sphinx-theme/pull/421>`_
- build(deps): bump pyvista[jupyter] from 0.44.0 to 0.44.1 `#422 <https://github.com/ansys/ansys-sphinx-theme/pull/422>`_
- build(deps): bump sphinx from 7.4.6 to 7.4.7 `#423 <https://github.com/ansys/ansys-sphinx-theme/pull/423>`_
- build(deps): bump sphinx-autoapi from 3.2.0 to 3.2.1 `#426 <https://github.com/ansys/ansys-sphinx-theme/pull/426>`_
- build(deps): bump sphinx-notfound-page from 1.0.2 to 1.0.3 `#432 <https://github.com/ansys/ansys-sphinx-theme/pull/432>`_
- build(deps): bump jupytext from 1.16.3 to 1.16.4 `#433 <https://github.com/ansys/ansys-sphinx-theme/pull/433>`_
- build(deps): bump sphinx-notfound-page from 1.0.3 to 1.0.4 `#434 <https://github.com/ansys/ansys-sphinx-theme/pull/434>`_
- build(deps): bump sphinx-design from 0.6.0 to 0.6.1 `#435 <https://github.com/ansys/ansys-sphinx-theme/pull/435>`_
- build(deps): bump sphinx from 7.4.7 to 8.0.2 `#436 <https://github.com/ansys/ansys-sphinx-theme/pull/436>`_
- build(deps): bump sphinx-gallery from 0.17.0 to 0.17.1 `#441 <https://github.com/ansys/ansys-sphinx-theme/pull/441>`_


Miscellaneous
^^^^^^^^^^^^^

- refactor: remove function duplicate `#407 <https://github.com/ansys/ansys-sphinx-theme/pull/407>`_
- docs: Update `mail id` in README.rst `#414 <https://github.com/ansys/ansys-sphinx-theme/pull/414>`_

`0.16.6 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v0.16.6>`_ - 2024-06-18
=========================================================================================

Fixed
^^^^^

- fix: wrong env var name for PACKAGE_NAME `#395 <https://github.com/ansys/ansys-sphinx-theme/pull/395>`_

`0.16.5 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v0.16.5>`_ - 2024-05-31
=========================================================================================

Fixed
^^^^^

- fix:  sphinx design card font size `#393 <https://github.com/ansys/ansys-sphinx-theme/pull/393>`_

`0.16.4 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v0.16.4>`_ - 2024-05-29
=========================================================================================

Added
^^^^^

- feat: adapt package to general PyAnsys repository layout `#387 <https://github.com/ansys/ansys-sphinx-theme/pull/387>`_


Dependencies
^^^^^^^^^^^^

- chore(deps): bump sphinx-design from 0.5.0 to 0.6.0 `#383 <https://github.com/ansys/ansys-sphinx-theme/pull/383>`_
- chore(deps): bump sphinx-notfound-page from 1.0.1 to 1.0.2 `#384 <https://github.com/ansys/ansys-sphinx-theme/pull/384>`_
- chore(deps): bump sphinx-autoapi from 3.1.0 to 3.1.1 `#385 <https://github.com/ansys/ansys-sphinx-theme/pull/385>`_

`0.16.3 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v0.16.3>`_ - 2024-05-29
=========================================================================================

Fixed
^^^^^

- fix: update the sphinx design style to disable display of name `#388 <https://github.com/ansys/ansys-sphinx-theme/pull/388>`_

`0.16.2 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v0.16.2>`_ - 2024-05-22
=========================================================================================

Changed
^^^^^^^

- chore: update CHANGELOG for v0.16.1 `#379 <https://github.com/ansys/ansys-sphinx-theme/pull/379>`_


Miscellaneous
^^^^^^^^^^^^^

- docs: update changelog_template.jinja `#380 <https://github.com/ansys/ansys-sphinx-theme/pull/380>`_

`0.16.1 <https://github.com/ansys/ansys-sphinx-theme/releases/tag/v0.16.1>`_ - 2024-05-22
=========================================================================================

Added
^^^^^

- feat: add nerd fonts for ``autoapi`` templates icon `#362 <https://github.com/ansys/ansys-sphinx-theme/pull/362>`_
- feat: add the changelog action `#370 <https://github.com/ansys/ansys-sphinx-theme/pull/370>`_
- feat: add autoapi extension `#372 <https://github.com/ansys/ansys-sphinx-theme/pull/372>`_


Fixed
^^^^^

- fix: add changelog action in ci-cd `#378 <https://github.com/ansys/ansys-sphinx-theme/pull/378>`_


Dependencies
^^^^^^^^^^^^

- chore(deps): bump requests from 2.31.0 to 2.32.1 `#374 <https://github.com/ansys/ansys-sphinx-theme/pull/374>`_
- maint: update the sphinx-autoapi version `#375 <https://github.com/ansys/ansys-sphinx-theme/pull/375>`_
- chore(deps): bump sphinx-notfound-page from 1.0.0 to 1.0.1 `#376 <https://github.com/ansys/ansys-sphinx-theme/pull/376>`_
- chore(deps): bump requests from 2.32.1 to 2.32.2 `#377 <https://github.com/ansys/ansys-sphinx-theme/pull/377>`_

.. vale on
