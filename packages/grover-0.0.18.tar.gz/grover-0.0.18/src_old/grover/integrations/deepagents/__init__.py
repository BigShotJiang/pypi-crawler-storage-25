"""Grover integration with deepagents (LangGraph agent framework).

Provides ``GroverBackend`` (``BackendProtocol`` implementation) and
``GroverMiddleware`` (version/search/graph/trash tools) so any LangGraph
deep agent can use Grover as its storage backend.

Both classes accept ``Grover`` (sync) or ``GroverAsync`` (native async).

Sync usage::

    from grover import Grover
    from grover.backends.local import LocalFileSystem
    from grover.integrations.deepagents import GroverBackend, GroverMiddleware

    g = Grover()
    g.add_mount("project", LocalFileSystem(workspace_dir="/tmp/test"))

    backend = GroverBackend(g)
    middleware = GroverMiddleware(g)

Async usage::

    from grover import GroverAsync
    from grover.backends.local import LocalFileSystem
    from grover.integrations.deepagents import GroverBackend, GroverMiddleware

    ga = GroverAsync()
    await ga.add_mount("project", LocalFileSystem(workspace_dir="/tmp/test"))

    backend = GroverBackend(ga)
    middleware = GroverMiddleware(ga)

    # Async methods call GroverAsync natively
    content = await backend.aread("/project/file.txt")
"""

try:
    from deepagents.backends.protocol import BackendProtocol as _BackendProtocol
except ImportError as _exc:
    raise ImportError(
        "deepagents is required for the Grover deepagents integration. "
        "Install it with: pip install 'grover[deepagents]'"
    ) from _exc

from grover.integrations.deepagents.backend import GroverBackend
from grover.integrations.deepagents.middleware import GroverMiddleware

__all__ = ["GroverBackend", "GroverMiddleware"]
