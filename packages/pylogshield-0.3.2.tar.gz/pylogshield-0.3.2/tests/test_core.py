"""Tests for PyLogShield core functionality."""

from __future__ import annotations

import io
import json
import logging
from pathlib import Path

import pytest

from pylogshield import PyLogShield, add_log_level, get_logger
from pylogshield.config import add_sensitive_fields
from tests.conftest import close_logger


class TestPyLogShieldBasic:
    """Basic PyLogShield functionality tests."""

    def test_create_logger(self, temp_log_dir: Path) -> None:
        """Test basic logger creation."""
        logger = PyLogShield(
            name="test_basic",
            log_directory=temp_log_dir,
            add_console=False,
        )
        assert logger.name == "test_basic"
        assert logger.log_level == logging.INFO
        close_logger(logger)

    def test_log_level_string(self, temp_log_dir: Path) -> None:
        """Test logger creation with string log level."""
        logger = PyLogShield(
            name="test_level_str",
            log_level="DEBUG",
            log_directory=temp_log_dir,
            add_console=False,
        )
        assert logger.log_level == logging.DEBUG
        close_logger(logger)

    def test_log_level_int(self, temp_log_dir: Path) -> None:
        """Test logger creation with integer log level."""
        logger = PyLogShield(
            name="test_level_int",
            log_level=logging.WARNING,
            log_directory=temp_log_dir,
            add_console=False,
        )
        assert logger.log_level == logging.WARNING
        close_logger(logger)

    def test_set_log_level(self, basic_logger: PyLogShield) -> None:
        """Test dynamic log level changes."""
        basic_logger.set_log_level("DEBUG")
        assert basic_logger.log_level == logging.DEBUG

        basic_logger.set_log_level(logging.ERROR)
        assert basic_logger.log_level == logging.ERROR

    def test_log_file_created(self, basic_logger: PyLogShield) -> None:
        """Test that log file is created on first write."""
        basic_logger.info("Test message")
        assert basic_logger.log_file_path.exists()

    def test_repr(self, basic_logger: PyLogShield) -> None:
        """Test logger repr string."""
        repr_str = repr(basic_logger)
        assert "PyLogShield" in repr_str
        assert "test_logger" in repr_str


class TestPyLogShieldMasking:
    """Tests for sensitive data masking."""

    def test_mask_dict_password(self, basic_logger: PyLogShield) -> None:
        """Test masking password in dict."""
        data = {"user": "john", "password": "secret123"}
        masked = basic_logger._mask(data)
        assert masked["user"] == "john"
        assert masked["password"] == "***"

    def test_mask_dict_token(self, basic_logger: PyLogShield) -> None:
        """Test masking token in dict."""
        data = {"api_key": "abc123", "data": "value"}
        masked = basic_logger._mask(data)
        assert masked["api_key"] == "***"
        assert masked["data"] == "value"

    def test_mask_nested_dict(self, basic_logger: PyLogShield) -> None:
        """Test masking in nested dictionaries."""
        data = {"user": "john", "credentials": {"password": "secret", "token": "xyz"}}
        masked = basic_logger._mask(data)
        assert masked["user"] == "john"
        assert masked["credentials"]["password"] == "***"
        assert masked["credentials"]["token"] == "***"

    def test_mask_list_of_dicts(self, basic_logger: PyLogShield) -> None:
        """Test masking in list of dictionaries."""
        data = [
            {"user": "john", "password": "secret1"},
            {"user": "jane", "password": "secret2"},
        ]
        masked = basic_logger._mask(data)
        assert masked[0]["user"] == "john"
        assert masked[0]["password"] == "***"
        assert masked[1]["user"] == "jane"
        assert masked[1]["password"] == "***"

    def test_mask_tuple(self, basic_logger: PyLogShield) -> None:
        """Test masking preserves tuple type."""
        data = ({"password": "secret"},)
        masked = basic_logger._mask(data)
        assert isinstance(masked, tuple)
        assert masked[0]["password"] == "***"

    def test_mask_string_inside_list_partial(self, basic_logger: PyLogShield) -> None:
        """Strings inside a list use partial substitution, not whole-string replacement."""
        data = ["user info: alice", "password: secret123", "token: abc"]
        masked = basic_logger._mask(data)
        # Non-sensitive string must be preserved exactly
        assert masked[0] == "user info: alice"
        # Sensitive strings: only the value is replaced, not the whole string
        assert "password" in masked[1]
        assert "secret123" not in masked[1]
        assert "token" in masked[2]
        assert "abc" not in masked[2]

    def test_mask_string_with_password(self, basic_logger: PyLogShield) -> None:
        """Test masking password pattern in string."""
        text = "Connection with password: secret123 established"
        masked = basic_logger._mask(text)
        assert "secret123" not in masked
        assert "***" in masked

    def test_mask_string_with_token(self, basic_logger: PyLogShield) -> None:
        """Test masking token pattern in string."""
        text = "Using api_key=myapikey123 for auth"
        masked = basic_logger._mask(text)
        assert "myapikey123" not in masked

    def test_no_mask_when_disabled(self, basic_logger: PyLogShield) -> None:
        """Test that masking can be disabled."""
        data = {"password": "secret"}
        # _process_message with mask=False should not mask
        processed = basic_logger._process_message(data, mask=False)
        assert processed["password"] == "secret"

    def test_mask_case_insensitive(self, basic_logger: PyLogShield) -> None:
        """Test that masking is case-insensitive."""
        data = {"PASSWORD": "secret", "Token": "xyz"}
        masked = basic_logger._mask(data)
        assert masked["PASSWORD"] == "***"
        assert masked["Token"] == "***"

    def test_mask_custom_field(self, basic_logger: PyLogShield) -> None:
        """Test masking with custom sensitive fields."""
        add_sensitive_fields(["custom_secret"])
        data = {"custom_secret": "value", "normal": "data"}
        masked = basic_logger._mask(data)
        assert masked["custom_secret"] == "***"
        assert masked["normal"] == "data"

    def test_mask_idempotent_string(self, basic_logger: PyLogShield) -> None:
        """Masking an already-masked string must produce the same result."""
        text = "password: supersecret"
        once = basic_logger._mask(text)
        twice = basic_logger._mask(once)
        assert once == twice, (
            "Masking is not idempotent — double-masking changed the output"
        )

    def test_mask_idempotent_dict(self, basic_logger: PyLogShield) -> None:
        """Masking an already-masked dict must produce the same result."""
        data = {"password": "supersecret", "note": "token: abc123"}
        once = basic_logger._mask(data)
        twice = basic_logger._mask(once)
        assert once == twice, "Masking is not idempotent on dicts"

    def test_mask_empty_string_value(self, basic_logger: PyLogShield) -> None:
        """Regex must match and mask empty quoted values like password: ''."""
        text = "login failed: password: ''"
        masked = basic_logger._mask(text)
        assert "***" in masked, "Empty quoted password value was not masked"


class TestPyLogShieldLogging:
    """Tests for actual logging operations."""

    def test_info_log(self, basic_logger: PyLogShield) -> None:
        """Test info level logging."""
        basic_logger.info("Test info message")
        content = basic_logger.log_file_path.read_text()
        assert "Test info message" in content
        assert "INFO" in content

    def test_debug_log(self, temp_log_dir: Path) -> None:
        """Test debug level logging."""
        logger = PyLogShield(
            name="test_debug",
            log_level="DEBUG",
            log_directory=temp_log_dir,
            add_console=False,
        )
        logger.debug("Test debug message")
        content = logger.log_file_path.read_text()
        assert "Test debug message" in content
        assert "DEBUG" in content
        close_logger(logger)

    def test_warning_log(self, basic_logger: PyLogShield) -> None:
        """Test warning level logging."""
        basic_logger.warning("Test warning message")
        content = basic_logger.log_file_path.read_text()
        assert "Test warning message" in content
        assert "WARNING" in content

    def test_error_log(self, basic_logger: PyLogShield) -> None:
        """Test error level logging."""
        basic_logger.error("Test error message")
        content = basic_logger.log_file_path.read_text()
        assert "Test error message" in content
        assert "ERROR" in content

    def test_critical_log(self, basic_logger: PyLogShield) -> None:
        """Test critical level logging."""
        basic_logger.critical("Test critical message")
        content = basic_logger.log_file_path.read_text()
        assert "Test critical message" in content
        assert "CRITICAL" in content

    def test_warn_alias(self, basic_logger: PyLogShield) -> None:
        """Test warn alias for warning."""
        basic_logger.warn("Test warn message")
        content = basic_logger.log_file_path.read_text()
        assert "Test warn message" in content
        assert "WARNING" in content

    def test_log_with_mask(self, basic_logger: PyLogShield) -> None:
        """Test logging with masking enabled."""
        basic_logger.info({"password": "secret"}, mask=True)
        content = basic_logger.log_file_path.read_text()
        assert "secret" not in content
        assert "***" in content

    def test_exception_log(self, basic_logger: PyLogShield) -> None:
        """Test exception logging."""
        try:
            raise ValueError("Test error")
        except ValueError:
            basic_logger.exception("An error occurred")
        content = basic_logger.log_file_path.read_text()
        assert "An error occurred" in content
        assert "ValueError" in content


class TestPyLogShieldJSON:
    """Tests for JSON logging."""

    def test_json_format(self, json_logger: PyLogShield) -> None:
        """Test JSON formatted output."""
        json_logger.info("Test JSON message")
        content = json_logger.log_file_path.read_text().strip()
        data = json.loads(content)
        assert data["message"] == "Test JSON message"
        assert data["level"] == "INFO"
        assert "timestamp" in data
        assert "logger" in data

    def test_json_with_dict_message(self, json_logger: PyLogShield) -> None:
        """Test JSON logging with dict message."""
        json_logger.info({"key": "value"})
        content = json_logger.log_file_path.read_text().strip()
        data = json.loads(content)
        # Message should be JSON-serialized dict
        assert "key" in data["message"]


class TestGetLogger:
    """Tests for get_logger function."""

    def test_get_logger_creates_new(
        self, temp_log_dir: Path, clean_logger_registry: None
    ) -> None:
        """Test get_logger creates new logger."""
        logger = get_logger(
            "test_new_logger",
            log_directory=temp_log_dir,
            add_console=False,
        )
        assert isinstance(logger, PyLogShield)
        assert logger.name == "test_new_logger"
        close_logger(logger)

    def test_get_logger_returns_existing(
        self, temp_log_dir: Path, clean_logger_registry: None
    ) -> None:
        """Test get_logger returns existing logger."""
        logger1 = get_logger(
            "test_existing",
            log_directory=temp_log_dir,
            add_console=False,
        )
        logger2 = get_logger("test_existing")
        assert logger1 is logger2
        close_logger(logger1)

    def test_get_logger_force_replace(
        self, temp_log_dir: Path, clean_logger_registry: None
    ) -> None:
        """Test get_logger force replacement."""
        # Create a standard logger first
        std_logger = logging.getLogger("test_force")
        logging.Logger.manager.loggerDict["test_force"] = std_logger

        # Should raise without force
        with pytest.raises(TypeError):
            get_logger("test_force")

        # Should succeed with force
        logger = get_logger(
            "test_force",
            force=True,
            log_directory=temp_log_dir,
            add_console=False,
        )
        assert isinstance(logger, PyLogShield)
        close_logger(logger)


class TestPyLogShieldFromConfig:
    """Tests for from_config class method."""

    def test_from_config_basic(self, temp_log_dir: Path) -> None:
        """Test creating logger from config dict."""
        config = {
            "level": "DEBUG",
            "enable_json": True,
            "log_directory": str(temp_log_dir),
            "add_console": False,
        }
        logger = PyLogShield.from_config("test_config", config)
        assert logger.log_level == logging.DEBUG
        assert logger.enable_json is True
        close_logger(logger)

    def test_from_config_with_filter(self, temp_log_dir: Path) -> None:
        """Test creating logger with filter from config."""
        config = {
            "log_directory": str(temp_log_dir),
            "add_console": False,
            "log_filter": ["error", "critical"],
        }
        logger = PyLogShield.from_config("test_config_filter", config)
        assert logger is not None
        close_logger(logger)


class TestExceptionMasking:
    """Tests for exception argument masking."""

    def test_mask_exception_args(self, basic_logger: PyLogShield) -> None:
        """Test that exception args are masked when mask=True."""
        stream = io.StringIO()
        handler = logging.StreamHandler(stream)
        handler.setLevel(logging.DEBUG)
        basic_logger.addHandler(handler)
        try:
            try:
                raise ValueError("password=supersecret")
            except ValueError:
                basic_logger.exception("auth error", mask=True)
        finally:
            basic_logger.removeHandler(handler)
            handler.close()

        output = stream.getvalue()
        # The exception repr (e.g. "ValueError: password=supersecret") must be masked.
        # Traceback source-code lines are formatter output and cannot be redacted
        # by masking — they reflect the literal source text, not the exception value.
        assert "ValueError: password=supersecret" not in output
        # The masked form should appear instead
        assert "ValueError:" in output


def test_exception_args_not_mutated(basic_logger):
    """Masking must not permanently alter the exception's .args."""
    err = ValueError("password: secret123")
    try:
        raise err
    except ValueError:
        basic_logger.exception("error occurred", mask=True, exc_info=True)

    # Original exception args must be intact after logging
    assert err.args == ("password: secret123",)


def test_exception_args_not_mutated_explicit_tuple(basic_logger):
    """Same guarantee when exc_info is passed as a tuple."""
    import sys

    err = ValueError("token: abc-123")
    try:
        raise err
    except ValueError:
        ei = sys.exc_info()
    basic_logger.error("oops", mask=True, exc_info=ei)
    assert err.args == ("token: abc-123",)


class TestQueueLogging:
    """Tests for async logging with use_queue=True."""

    def test_queue_logger_delivers_messages(self, tmp_path):
        """use_queue=True must deliver messages to the file handler."""
        logger = PyLogShield(
            name="test_queue_delivery",
            log_directory=tmp_path,
            log_file="queue.log",
            use_queue=True,
            add_console=False,
        )
        logger.info("queue_test_marker")
        logger.shutdown()

        log_content = (tmp_path / "queue.log").read_text()
        assert "queue_test_marker" in log_content
        close_logger(logger)

    def test_queue_logger_shutdown_flushes_all(self, tmp_path):
        """shutdown() must flush all queued messages before stopping."""
        logger = PyLogShield(
            name="test_queue_flush",
            log_directory=tmp_path,
            log_file="flush.log",
            use_queue=True,
            add_console=False,
        )
        for i in range(50):
            logger.info(f"msg_{i}")
        logger.shutdown()

        log_content = (tmp_path / "flush.log").read_text()
        for i in range(50):
            assert f"msg_{i}" in log_content, f"msg_{i} was dropped"
        close_logger(logger)

    def test_queue_logger_concurrent_writers(self, tmp_path):
        """Multiple threads writing via queue must not lose messages."""
        import threading

        logger = PyLogShield(
            name="test_queue_concurrent",
            log_directory=tmp_path,
            log_file="concurrent.log",
            use_queue=True,
            add_console=False,
        )

        def write_messages(thread_id: int):
            for i in range(20):
                logger.info(f"thread_{thread_id}_msg_{i}")

        threads = [threading.Thread(target=write_messages, args=(t,)) for t in range(5)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        logger.shutdown()

        log_content = (tmp_path / "concurrent.log").read_text()
        for thread_id in range(5):
            for i in range(20):
                assert f"thread_{thread_id}_msg_{i}" in log_content
        close_logger(logger)


# ─────────────────────────────────────────────────────────────────────────────
# Custom log levels
# ─────────────────────────────────────────────────────────────────────────────


class TestCustomLogLevel:
    """Custom log levels registered on PyLogShield via add_log_level."""

    def test_custom_level_appears_in_log_file(self, temp_log_dir: Path) -> None:
        """Custom level method writes to the log file at the correct level."""

        class _LS(PyLogShield):
            pass

        add_log_level("NOTICE", 25, logger_cls=_LS)
        logger = _LS(
            name="test_notice_logger",
            log_directory=temp_log_dir,
            log_file="notice.log",
            log_level="DEBUG",
            add_console=False,
        )
        logger.notice("System notice fired")  # type: ignore[attr-defined]
        close_logger(logger)

        content = (temp_log_dir / "notice.log").read_text()
        assert "NOTICE" in content
        assert "System notice fired" in content

    def test_custom_level_respects_min_level(self, temp_log_dir: Path) -> None:
        """Custom level below logger threshold is suppressed."""

        class _LS2(PyLogShield):
            pass

        add_log_level("TRACE2", 5, logger_cls=_LS2)
        logger = _LS2(
            name="test_trace2_logger",
            log_directory=temp_log_dir,
            log_file="trace2.log",
            log_level="INFO",  # TRACE2=5 is below INFO=20
            add_console=False,
        )
        logger.trace2("Should be suppressed")  # type: ignore[attr-defined]
        close_logger(logger)

        content = (temp_log_dir / "trace2.log").read_text()
        assert "Should be suppressed" not in content

    def test_custom_level_mask_redacts_sensitive_string(
        self, temp_log_dir: Path
    ) -> None:
        """mask=True on a custom-level method redacts sensitive patterns."""

        class _LS3(PyLogShield):
            pass

        add_log_level("SECLOG", 35, logger_cls=_LS3)
        logger = _LS3(
            name="test_seclog_logger",
            log_directory=temp_log_dir,
            log_file="seclog.log",
            log_level="DEBUG",
            add_console=False,
        )
        logger.seclog("api_key: topsecret", mask=True)  # type: ignore[attr-defined]
        close_logger(logger)

        content = (temp_log_dir / "seclog.log").read_text()
        assert "topsecret" not in content
        assert "***" in content

    def test_custom_level_mask_redacts_dict(self, temp_log_dir: Path) -> None:
        """mask=True on a custom-level method redacts sensitive dict keys."""

        class _LS4(PyLogShield):
            pass

        add_log_level("AUDITLOG", 26, logger_cls=_LS4)
        logger = _LS4(
            name="test_auditlog_logger",
            log_directory=temp_log_dir,
            log_file="auditlog.log",
            log_level="DEBUG",
            add_console=False,
        )
        logger.auditlog(  # type: ignore[attr-defined]
            {"user": "alice", "token": "abc123", "action": "login"},
            mask=True,
        )
        close_logger(logger)

        content = (temp_log_dir / "auditlog.log").read_text()
        assert "abc123" not in content
        assert "alice" in content
        assert "login" in content


# ─────────────────────────────────────────────────────────────────────────────
# Custom sensitive fields
# ─────────────────────────────────────────────────────────────────────────────


class TestCustomSensitiveFields:
    """Custom fields registered via add_sensitive_fields."""

    def test_custom_string_field_masked_in_dict(
        self, basic_logger: PyLogShield
    ) -> None:
        """Custom field with string value is masked."""
        add_sensitive_fields(["national_id"])
        data = {"user": "alice", "national_id": "GB123456A"}
        masked = basic_logger._mask(data)
        assert masked["national_id"] == "***"
        assert masked["user"] == "alice"

    def test_custom_field_non_string_value_masked(
        self, basic_logger: PyLogShield
    ) -> None:
        """Custom field with integer/float/None value is still masked."""
        add_sensitive_fields(["account_number", "balance"])
        data = {
            "account_number": 12345678,  # int
            "balance": 9999.99,  # float
            "name": "Alice",  # not sensitive
        }
        masked = basic_logger._mask(data)
        assert masked["account_number"] == "***"
        assert masked["balance"] == "***"
        assert masked["name"] == "Alice"

    def test_custom_field_masked_inline_string(self, basic_logger: PyLogShield) -> None:
        """Custom field name in 'key: value' pattern is redacted from strings."""
        add_sensitive_fields(["sort_code"])
        text = "Payment details sort_code: 12-34-56 amount: 100"
        masked = basic_logger._mask(text)
        assert "12-34-56" not in masked
        assert "***" in masked
        assert "100" in masked  # non-sensitive portion preserved

    def test_custom_fields_logged_with_mask(self, basic_logger: PyLogShield) -> None:
        """End-to-end: custom fields are redacted in the written log file."""
        add_sensitive_fields(["dob", "nhs_number"])
        basic_logger.info(
            {"patient": "Bob", "dob": "1990-01-15", "nhs_number": "123 456 7890"},
            mask=True,
        )
        content = basic_logger.log_file_path.read_text()
        assert "1990-01-15" not in content
        assert "123 456 7890" not in content
        assert "Bob" in content

    def test_custom_fields_nested_dict_masked(self, basic_logger: PyLogShield) -> None:
        """Custom sensitive fields are masked at any nesting depth."""
        add_sensitive_fields(["secret_pin"])
        data = {"user": "carol", "payment": {"secret_pin": 9876, "card": "Visa"}}
        masked = basic_logger._mask(data)
        assert masked["payment"]["secret_pin"] == "***"
        assert masked["payment"]["card"] == "Visa"

    def test_non_sensitive_fields_preserved(self, basic_logger: PyLogShield) -> None:
        """Fields not in the sensitive registry pass through unchanged."""
        data = {"order_id": "ORD-001", "amount": 49.99, "status": "paid"}
        masked = basic_logger._mask(data)
        assert masked == data


def test_rotating_file_handler_rotates(tmp_path: Path) -> None:
    """rotate_file=True must produce backup files after the size threshold."""
    logger = PyLogShield(
        name="test_rotation_unique",
        log_directory=tmp_path,
        log_file="rotate.log",
        rotate_file=True,
        rotate_max_bytes=500,
        rotate_backup_count=2,
        add_console=False,
    )
    # Write enough data to force at least one rotation (500 bytes / ~30 bytes per line)
    for i in range(50):
        logger.info("x" * 20)
    for h in logger.handlers:
        h.flush()
    close_logger(logger)

    log_files = list(tmp_path.glob("rotate.log*"))
    assert len(log_files) > 1, (
        f"Expected rotation to create backup files, found: {log_files}"
    )
