"""Scrapurrr — agentic web scraper with pluggable LLM providers."""

from __future__ import annotations

__all__ = ["CrawlResult", "Scrapurrr", "__version__"]

import asyncio
import json
import logging
from typing import TYPE_CHECKING, Any, TypeVar, cast

from pydantic import BaseModel

from scrapurrr.agent.loop import AgentLoop
from scrapurrr.agent.tools import Tool, ToolRegistry
from scrapurrr.browser.engine import PlaywrightEngine
from scrapurrr.browser.pool import PagePool
from scrapurrr.browser.proxy import ProxyRotator
from scrapurrr.browser.stealth import StealthManager
from scrapurrr.core.config import ScrapurrConfig
from scrapurrr.core.exceptions import ExtractionError, NavigationError
from scrapurrr.core.schemas import SchemaHelper
from scrapurrr.crawler import CrawlResult, DeepCrawler
from scrapurrr.extraction import Extractor
from scrapurrr.network.captcha import CaptchaSolver, NullCaptchaSolver
from scrapurrr.network.ratelimit import RateLimiter
from scrapurrr.pipeline.chunker import chunk
from scrapurrr.pipeline.cleaner import clean
from scrapurrr.pipeline.fetcher import fetch
from scrapurrr.pipeline.http_fetcher import http_fetch
from scrapurrr.providers.litellm import LiteLLMProvider
from scrapurrr.storage.cache import PageCache

if TYPE_CHECKING:
    from collections.abc import AsyncIterator, Awaitable, Callable
    from pathlib import Path

    from scrapurrr.core.types import LLMProvider, StealthHook
    from scrapurrr.extraction.element import ElementCollection, ElementInfo

__version__ = "0.3.2"

logger = logging.getLogger(__name__)

T = TypeVar("T", bound=BaseModel)


def _count_populated_fields(obj: Any) -> int:
    if not hasattr(obj, "model_fields"):
        return 0
    count = 0
    for field_name in obj.model_fields:
        value = getattr(obj, field_name, None)
        if value is not None and value != "" and value != 0:
            count += 1
    return count


def _needs_browser(html: str) -> bool:
    """Detect if a page likely needs JavaScript rendering."""
    spa_markers = [
        '<div id="root"></div>',
        '<div id="app"></div>',
        '<div id="__next"></div>',
        "window.__NUXT__",
        "window.__NEXT_DATA__",
        "__GATSBY",
        "ng-app=",
        "data-reactroot",
    ]
    html_lower = html.lower()
    for marker in spa_markers:
        if marker.lower() in html_lower:
            return True

    if "<noscript>" in html_lower and "javascript" in html_lower:
        return True

    from bs4 import BeautifulSoup

    soup = BeautifulSoup(html, "html.parser")
    body = soup.find("body")
    if body:
        text = body.get_text(strip=True)
        if len(text) < 100:
            return True

    return False


class Scrapurrr:
    """Public API facade — integrates browser, pipeline, extraction, and agent."""

    def __init__(
        self,
        provider: str | None = None,
        api_key: str | None = None,
        base_url: str | None = None,
        config_path: Path | None = None,
        stealth_hooks: list[StealthHook] | None = None,
        captcha_solver: CaptchaSolver | None = None,
        on_complete: Callable[[Any], Awaitable[None]] | None = None,
    ) -> None:
        if config_path is not None:
            self._config = ScrapurrConfig.from_yaml(config_path)
        else:
            self._config = ScrapurrConfig()

        self._config = self._config.override(
            provider=provider,
            api_key=api_key,
            base_url=base_url,
        )

        self._stealth = StealthManager(
            level=self._config.browser.stealth,
            hooks=stealth_hooks or [],
        )
        self._rotator: ProxyRotator | None = (
            ProxyRotator(self._config.browser.proxy)
            if isinstance(self._config.browser.proxy, list)
            else None
        )
        self._engine: Any = PlaywrightEngine(self._config.browser, self._stealth, self._rotator)
        self._llm: LLMProvider = LiteLLMProvider(
            model=self._config.llm.provider,
            api_key=self._config.llm.api_key,
            base_url=self._config.llm.base_url,
        )
        self._extractor = Extractor(
            provider=self._llm,
            strategy=self._config.extraction.strategy,
        )
        self._launched = False
        self._pool: PagePool | None = None
        self._extra_tools: list[Tool] = []
        self._cache: PageCache | None = (
            PageCache(ttl=self._config.cache.ttl) if self._config.cache.enabled else None
        )
        self._captcha_solver: CaptchaSolver = captcha_solver or NullCaptchaSolver()
        self._on_complete = on_complete
        self._rate_limiter = RateLimiter(
            requests_per_second=self._config.browser.requests_per_second
        )

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def _ensure_launched(self) -> None:
        if not self._launched:
            await self._engine.launch()
            self._pool = PagePool(self._engine, max_pages=5)
            self._launched = True
            logger.debug("Browser launched")

    async def _get_page(self) -> Any:
        await self._ensure_launched()
        assert self._pool is not None
        return await self._pool.acquire()

    async def _release_page(self, page: Any) -> None:
        if self._pool is not None:
            await self._pool.release(page)

    async def close(self) -> None:
        if self._launched:
            await self._engine.close()
            self._launched = False
            self._pool = None

    async def __aenter__(self) -> Scrapurrr:
        return self

    async def __aexit__(self, *_: Any) -> None:
        await self.close()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def extract(self, url: str, schema: type[T]) -> T:
        """Fetch *url* and extract structured data matching *schema*.

        The fetch path is controlled by ``browser.mode``:
        - ``"never"``: HTTP-only (fastest, no JS support)
        - ``"always"``: always use the browser
        - ``"auto"`` (default): try HTTP first, fall back to browser when content is minimal
        """
        logger.info(
            "Extracting from %s with strategy=%s mode=%s",
            url,
            self._config.extraction.strategy,
            self._config.browser.mode,
        )

        if self._config.respect_robots:
            from scrapurrr.pipeline.robots import is_allowed

            if not await is_allowed(url):
                raise NavigationError(f"Blocked by robots.txt: {url}")

        if self._cache is not None:
            cached = self._cache.get(url)
            if cached is not None:
                fetch_result = cached
            else:
                fetch_result = await self._do_fetch(url)
                self._cache.put(url, fetch_result)
        else:
            fetch_result = await self._do_fetch(url)

        clean_result = clean(fetch_result.html)
        chunk_result = chunk(clean_result.markdown, source_url=url)

        if len(chunk_result.chunks) == 1:
            # Pass cleaned HTML so CSSExtractor can use selectors; LLMExtractor handles both
            result = await self._extractor.extract(clean_result.html, schema)
            if self._on_complete is not None:
                await self._on_complete(result)
            return result

        # Multiple chunks — extract from each in parallel and merge
        raw_results = await asyncio.gather(
            *[self._extractor.extract(c, schema) for c in chunk_result.chunks],
            return_exceptions=True,
        )

        successful: list[T] = [r for r in raw_results if not isinstance(r, Exception)]  # type: ignore[misc]

        if not successful:
            raise ExtractionError("All chunk extractions failed")

        if SchemaHelper.is_list_type(schema):
            merged: list[Any] = []
            for r in successful:
                data = r.model_dump()
                if isinstance(data, list):
                    merged.extend(data)
                else:
                    merged.append(data)
            result = cast("T", SchemaHelper.validate(merged, schema))
            if self._on_complete is not None:
                await self._on_complete(result)
            return result

        # For single schemas, pick the result with the most populated fields
        best = max(successful, key=_count_populated_fields)
        if self._on_complete is not None:
            await self._on_complete(best)
        return best

    async def extract_many(
        self,
        urls: list[str],
        schema: type[T],
        concurrency: int = 5,
        deduplicate_by: list[str] | None = None,
    ) -> list[T]:
        """Extract from multiple URLs with controlled concurrency."""
        semaphore = asyncio.Semaphore(concurrency)

        async def _extract_one(url: str) -> T | None:
            async with semaphore:
                try:
                    return await self.extract(url, schema)
                except Exception as exc:
                    logger.warning("Failed to extract from %s: %s", url, exc)
                    return None

        raw_results = await asyncio.gather(*[_extract_one(url) for url in urls])
        results: list[T] = [r for r in raw_results if r is not None]

        if deduplicate_by is not None:
            from scrapurrr.storage.dedup import deduplicate

            results = deduplicate(results, deduplicate_by)  # type: ignore[assignment]

        if self._on_complete is not None:
            await self._on_complete(results)
        return results

    async def extract_all_pages(
        self,
        url: str,
        schema: type[T],
        max_pages: int = 10,
        deduplicate_by: list[str] | None = None,
    ) -> list[T]:
        """Extract from all pages following pagination links."""
        from scrapurrr.network.pagination import find_next_page_url

        all_results: list[T] = []
        current_url: str | None = url
        visited: set[str] = set()

        for page_num in range(max_pages):
            if current_url is None or current_url in visited:
                break
            visited.add(current_url)
            logger.info("Extracting page %d: %s", page_num + 1, current_url)

            result = await self.extract(current_url, schema)
            if isinstance(result, list):
                all_results.extend(result)
            else:
                all_results.append(result)

            fetch_result = await self._do_fetch(current_url)
            current_url = find_next_page_url(fetch_result.html, current_url)

        if deduplicate_by is not None:
            from scrapurrr.storage.dedup import deduplicate

            all_results = deduplicate(all_results, deduplicate_by)  # type: ignore[assignment]

        if self._on_complete is not None:
            await self._on_complete(all_results)
        return all_results

    async def agent(
        self,
        task: str,
        schema: type[T],
        max_steps: int | None = None,
    ) -> T:
        """Run a ReAct agent to accomplish *task* and return data matching *schema*."""
        await self._ensure_launched()
        tools = self._build_agent_tools()
        for extra in self._extra_tools:
            tools.register(extra)

        steps = max_steps if max_steps is not None else self._config.agent.max_steps
        logger.info("Starting agent: %s (max_steps=%d)", task, steps)
        loop = AgentLoop(
            provider=self._llm,
            tools=tools,
            schema=schema,
            max_steps=steps,
        )
        result: Any = await loop.run(task, timeout=self._config.agent.timeout)
        if self._on_complete is not None:
            await self._on_complete(result)
        return cast("T", result)

    def register_tool(self, tool: Tool) -> None:
        """Register a custom tool available to the agent."""
        self._extra_tools.append(tool)

    async def agent_stream(
        self,
        task: str,
        schema: type[T],
        max_steps: int | None = None,
    ) -> AsyncIterator[Any]:
        """Stream agent steps as they happen, yielding AgentStep for each action."""
        await self._ensure_launched()
        tools = self._build_agent_tools()
        for extra in self._extra_tools:
            tools.register(extra)

        steps = max_steps if max_steps is not None else self._config.agent.max_steps
        logger.info("Starting agent stream: %s (max_steps=%d)", task, steps)
        loop = AgentLoop(
            provider=self._llm,
            tools=tools,
            schema=schema,
            max_steps=steps,
        )
        async for step in loop.run_stream(task, timeout=self._config.agent.timeout):
            yield step

    async def extract_elements(
        self,
        url: str | None = None,
        tag: str | None = None,
        text: str | None = None,
        max_elements: int = 500,
    ) -> ElementCollection:
        """Extract visible DOM elements from a page and return an ElementCollection.

        Args:
            url: If provided, navigate to this URL first.
            tag: Filter results to elements with this tag name.
            text: Filter results to elements containing this text (case-insensitive substring).
            max_elements: Maximum number of elements to extract.

        Returns:
            ElementCollection of matching elements.
        """
        from scrapurrr.extraction.element import extract_elements as _extract

        page = await self._get_page()
        try:
            if url is not None:
                await page.navigate(url)
            collection = await _extract(page, max_elements)
        finally:
            await self._release_page(page)

        if tag is not None or text is not None:
            collection = collection.filter(tag=tag, text=text)
        return collection

    async def find_element(
        self,
        text: str | None = None,
        *,
        url: str | None = None,
        css: str | None = None,
        xpath: str | None = None,
    ) -> ElementInfo | None:
        """Find the first DOM element matching the given criteria.

        Args:
            text: Find first element where this is a case-insensitive substring of el.text.
            url: If provided, navigate to this URL first.
            css: Find first element where this is a case-insensitive substring of el.css.
            xpath: Find first element where this is a case-insensitive substring of el.xpath.

        Returns:
            The first matching ElementInfo, or None if not found.
        """
        from scrapurrr.extraction.element import extract_elements as _extract

        page = await self._get_page()
        try:
            if url is not None:
                await page.navigate(url)
            collection = await _extract(page)
        finally:
            await self._release_page(page)

        if css is not None:
            css_lower = css.lower()
            for el in collection:
                if css_lower in el.css.lower():
                    return el
            return None

        if xpath is not None:
            xpath_lower = xpath.lower()
            for el in collection:
                if xpath_lower in el.xpath.lower():
                    return el
            return None

        if text is not None:
            text_lower = text.lower()
            for el in collection:
                if text_lower in el.text.lower():
                    return el
            return None

        return collection.first()

    # ------------------------------------------------------------------
    # Deep Crawl
    # ------------------------------------------------------------------

    async def crawl(
        self,
        url: str,
        max_depth: int = 3,
        max_pages: int = 50,
        same_domain: bool = True,
        url_pattern: str | None = None,
    ) -> list[CrawlResult]:
        """Deep crawl a site starting from url."""
        await self._ensure_launched()
        crawler = DeepCrawler(
            scraper=self,
            max_depth=max_depth,
            max_pages=max_pages,
            same_domain=same_domain,
            url_pattern=url_pattern,
        )
        return await crawler.crawl(url)

    async def crawl_and_extract(
        self,
        url: str,
        schema: type[T],
        max_depth: int = 3,
        max_pages: int = 50,
    ) -> list[T]:
        """Deep crawl and extract structured data from every page."""
        await self._ensure_launched()
        crawler = DeepCrawler(
            scraper=self,
            max_depth=max_depth,
            max_pages=max_pages,
        )
        return await crawler.crawl_and_extract(url, schema)

    # ------------------------------------------------------------------
    # Authentication / session management
    # ------------------------------------------------------------------

    async def warm_up(self, target_url: str, steps: int = 3) -> None:
        """Warm up browser session before scraping target URL.

        Simulates organic browsing (visiting popular sites, scrolling, searching)
        to establish a realistic session state and referrer chain before hitting
        the target domain.
        """
        from urllib.parse import urlparse

        from scrapurrr.browser.warmup import warm_up_session

        domain = urlparse(target_url).netloc
        page = await self._get_page()
        try:
            await warm_up_session(page, domain, steps=steps)
        finally:
            await self._release_page(page)

    async def login(
        self,
        url: str,
        credentials: dict[str, str],
        username_selector: str = "input[name=username], input[type=email], #username, #email",
        password_selector: str = "input[name=password], input[type=password], #password",
        submit_selector: str = "button[type=submit], input[type=submit]",
    ) -> None:
        """Login to a website by filling and submitting a login form."""
        page = await self._get_page()
        try:
            await page.navigate(url)
            username = credentials.get("username") or credentials.get("email", "")
            password = credentials.get("password", "")
            await page.type_text(username_selector, username)
            await page.type_text(password_selector, password)
            await page.click(submit_selector)
            await asyncio.sleep(2)
            logger.info("Login attempted at %s", url)
        finally:
            await self._release_page(page)

    async def set_cookies(self, cookies: list[dict[str, str]]) -> None:
        """Set cookies on the browser context for session management."""
        page = await self._get_page()
        try:
            context = page._page.context
            await context.add_cookies(cookies)
            logger.info("Set %d cookies", len(cookies))
        finally:
            await self._release_page(page)

    async def get_cookies(self) -> list[dict[str, Any]]:
        """Get all cookies from the browser context."""
        page = await self._get_page()
        try:
            context = page._page.context
            return cast("list[dict[str, Any]]", await context.cookies())
        finally:
            await self._release_page(page)

    # ------------------------------------------------------------------
    # Internal fetch helper
    # ------------------------------------------------------------------

    def _next_proxy(self) -> str | None:
        """Return next proxy from rotator, or static proxy string, or None."""
        if self._rotator is not None:
            return self._rotator.next()
        if isinstance(self._config.browser.proxy, str):
            return self._config.browser.proxy
        return None

    async def _do_fetch(self, url: str) -> Any:
        """Perform the actual fetch according to browser.mode config."""
        await self._rate_limiter.wait(url)

        if self._config.browser.mode == "never":
            result = await http_fetch(
                url,
                timeout=self._config.browser.timeout // 1000,
                proxy=self._next_proxy(),
            )
        elif self._config.browser.mode == "always":
            page = await self._get_page()
            try:
                result = await fetch(page, url, max_retries=self._config.browser.max_retries)
            finally:
                await self._release_page(page)
        else:  # auto
            result = await http_fetch(
                url,
                timeout=self._config.browser.timeout // 1000,
                proxy=self._next_proxy(),
            )
            if _needs_browser(result.html):
                logger.info("HTTP fetch returned JS-heavy content — retrying with browser")
                page = await self._get_page()
                try:
                    result = await fetch(page, url, max_retries=self._config.browser.max_retries)
                finally:
                    await self._release_page(page)

        # CAPTCHA detection after fetch
        captcha_type = await self._captcha_solver.detect(result.html)
        if captcha_type is not None:
            solved = await self._captcha_solver.solve(
                None,
                captcha_type,
            )
            if solved:
                logger.info("CAPTCHA solved (%s), re-fetching %s", captcha_type, url)
                # Re-fetch after solving
                if self._config.browser.mode != "never":
                    page = await self._get_page()
                    try:
                        result = await fetch(
                            page, url, max_retries=self._config.browser.max_retries
                        )
                    finally:
                        await self._release_page(page)

        return result

    # ------------------------------------------------------------------
    # Agent tool construction
    # ------------------------------------------------------------------

    def _build_agent_tools(self) -> ToolRegistry:
        from pydantic import Field

        registry = ToolRegistry()

        # ---- param models (defined inline, closed over self) ----

        class NavParams(BaseModel):
            url: str = Field(description="URL to navigate to")

        class ScrollParams(BaseModel):
            direction: str = Field(default="down", description="'down' or 'up'")

        class WaitParams(BaseModel):
            selector: str = Field(description="CSS selector to wait for")
            timeout: int = Field(default=10000, description="Timeout in ms")

        class ExtractParams(BaseModel):
            pass  # operates on current page

        class ReadPageParams(BaseModel):
            pass  # operates on current page

        class ListLinksParams(BaseModel):
            pass  # operates on current page

        class ClickParams(BaseModel):
            selector: str = Field(description="CSS selector of element to click")

        class TypeParams(BaseModel):
            selector: str = Field(description="CSS selector of input field")
            text: str = Field(description="Text to type into the field")

        class SelectParams(BaseModel):
            selector: str = Field(description="CSS selector of the dropdown")
            value: str = Field(description="Option value to select")

        class BackParams(BaseModel):
            pass

        class DismissCookiesParams(BaseModel):
            pass

        # ---- tool functions ----

        async def _navigate(params: NavParams) -> str:
            page = await self._get_page()
            await page.navigate(params.url)
            if self._cache is not None:
                html = await page.get_html()
                from scrapurrr.core.types import FetchResult

                self._cache.put(
                    params.url,
                    FetchResult(url=params.url, html=html, status=200, headers={}),
                )
                logger.debug("Cached page for %s", params.url)
            return f"Navigated to {params.url}"

        async def _scroll(params: ScrollParams) -> str:
            page = await self._get_page()
            await page.scroll(params.direction)
            return f"Scrolled {params.direction}"

        async def _wait(params: WaitParams) -> str:
            page = await self._get_page()
            await page.wait_for(params.selector, timeout=params.timeout)
            return f"Element '{params.selector}' appeared"

        async def _extract(params: ExtractParams) -> str:
            page = await self._get_page()
            html = await page.get_html()
            from scrapurrr.agent.dom import simplify_dom

            dom_summary = simplify_dom(html, max_elements=150)
            cleaned = clean(html)
            return f"## Simplified DOM\n{dom_summary}\n\n## Content\n{cleaned.markdown[:2000]}"

        async def _read_page(params: ReadPageParams) -> str:
            page = await self._get_page()
            html = await page.get_html()
            from scrapurrr.agent.dom import simplify_dom

            dom_summary = simplify_dom(html, max_elements=150)
            cleaned = clean(html)
            return f"## Simplified DOM\n{dom_summary}\n\n## Content\n{cleaned.markdown[:2000]}"

        async def _list_links(params: ListLinksParams) -> str:
            from bs4 import BeautifulSoup

            page = await self._get_page()
            html = await page.get_html()
            soup = BeautifulSoup(html, "html.parser")
            links = [
                {"text": a.get_text(strip=True), "url": a.get("href")}
                for a in soup.find_all("a", href=True)
            ]
            return json.dumps(links[:100])

        async def _click(params: ClickParams) -> str:
            page = await self._get_page()
            await page.click(params.selector)
            return f"Clicked {params.selector}"

        async def _type_text(params: TypeParams) -> str:
            page = await self._get_page()
            await page.type_text(params.selector, params.text)
            return f"Typed '{params.text}' into {params.selector}"

        async def _select(params: SelectParams) -> str:
            page = await self._get_page()
            await page.select_option(params.selector, params.value)
            return f"Selected '{params.value}' in {params.selector}"

        async def _go_back(params: BackParams) -> str:
            page = await self._get_page()
            await page.go_back()
            return "Went back"

        async def _dismiss_cookies(params: DismissCookiesParams) -> str:
            page = await self._get_page()
            selectors = [
                "button[id*=accept]",
                "button[class*=accept]",
                "button[id*=cookie]",
                "button[class*=cookie]",
                "button[id*=consent]",
                "button[class*=consent]",
                "[data-testid*=accept]",
                "[data-testid*=cookie]",
                "button:has-text('Accept')",
                "button:has-text('Accept All')",
                "button:has-text('I agree')",
                "button:has-text('OK')",
                "button:has-text('Got it')",
                "button:has-text('Allow')",
            ]
            for sel in selectors:
                try:
                    await page.click(sel)
                    return f"Dismissed cookies via {sel}"
                except Exception:
                    continue
            return "No cookie dialog found"

        registry.register(
            Tool(
                name="navigate",
                description="Navigate the browser to a URL",
                parameters=NavParams,
                execute=_navigate,
            )
        )
        registry.register(
            Tool(
                name="scroll",
                description="Scroll the current page up or down",
                parameters=ScrollParams,
                execute=_scroll,
            )
        )
        registry.register(
            Tool(
                name="wait",
                description="Wait for a CSS selector to appear on the page",
                parameters=WaitParams,
                execute=_wait,
            )
        )
        registry.register(
            Tool(
                name="extract",
                description=(
                    "Extract the main content from the current page"
                    " as clean markdown, focused on data. Use this"
                    " when you want to get structured data."
                    " Returns up to 2000 characters."
                ),
                parameters=ExtractParams,
                execute=_extract,
            )
        )
        registry.register(
            Tool(
                name="read_page",
                description=(
                    "Read the full page content as markdown."
                    " Use this to understand page layout, find"
                    " navigation links, or explore before"
                    " extracting. Returns up to 4000 characters."
                ),
                parameters=ReadPageParams,
                execute=_read_page,
            )
        )
        registry.register(
            Tool(
                name="list_links",
                description="Return a JSON list of {text, url} links on the current page",
                parameters=ListLinksParams,
                execute=_list_links,
            )
        )
        registry.register(
            Tool(
                name="click",
                description="Click an element by CSS selector",
                parameters=ClickParams,
                execute=_click,
            )
        )
        registry.register(
            Tool(
                name="type",
                description="Type text into an input field by CSS selector",
                parameters=TypeParams,
                execute=_type_text,
            )
        )
        registry.register(
            Tool(
                name="select",
                description="Select an option from a dropdown by CSS selector and value",
                parameters=SelectParams,
                execute=_select,
            )
        )
        registry.register(
            Tool(
                name="back",
                description="Go back to the previous page",
                parameters=BackParams,
                execute=_go_back,
            )
        )
        registry.register(
            Tool(
                name="dismiss_cookies",
                description="Dismiss cookie consent dialog",
                parameters=DismissCookiesParams,
                execute=_dismiss_cookies,
            )
        )

        class InspectParams(BaseModel):
            tag: str | None = Field(default=None, description="Filter by tag name")
            text: str | None = Field(default=None, description="Filter by text content")
            limit: int = Field(default=20, description="Max elements to return")

        async def _inspect_elements(params: InspectParams) -> str:
            from scrapurrr.extraction.element import extract_elements

            page = await self._get_page()
            elements = await extract_elements(page, max_elements=params.limit)
            if params.tag:
                elements = elements.filter(tag=params.tag)
            if params.text:
                elements = elements.filter(text=params.text)
            lines = []
            for el in elements:
                lines.append(
                    f'[{el.index}] <{el.tag}> "{el.text[:50]}" css={el.css} xpath={el.xpath}'
                )
            return "\n".join(lines) if lines else "No elements found"

        registry.register(
            Tool(
                name="inspect_elements",
                description=(
                    "List page elements with their CSS selectors"
                    " and XPaths. Use to find specific elements"
                    " for clicking or extracting."
                ),
                parameters=InspectParams,
                execute=_inspect_elements,
            )
        )

        return registry
