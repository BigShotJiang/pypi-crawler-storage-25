from pathlib import Path
from audiotown.consts.video.video_record import VideoRecord, VideoContainer
from audiotown.video.policies.avi import AVIPolicy
from audiotown.video.policies.mkv import MKVPolicy
from audiotown.video.policies.rmvb import RMVBPolicy
from audiotown.video.policies.mp4 import MP4Policy
from audiotown.video.policies.default import DefaultPolicy
from audiotown.video.policies.base_format import BaseFormatPolicy
from audiotown.logger import logger, SessionLogger
import logging

class PolicyService:
    # 1. Define as a class-level constant with explicit type hints
    # This tells Pylance exactly what the keys and values are.
    _POLICY_MAP: dict[VideoContainer, type[BaseFormatPolicy]] = {
        VideoContainer.AVI: AVIPolicy,
        VideoContainer.MKV: MKVPolicy,
        VideoContainer.RMVB: RMVBPolicy,
        VideoContainer.MP4: MP4Policy,
    }

    def __init__(self, service_logger: SessionLogger = logger):
        self.selected_policy = DefaultPolicy()
        self.logger = service_logger
        self._POLICY_MAP  = {
        VideoContainer.AVI: AVIPolicy,
        VideoContainer.MKV: MKVPolicy,
        VideoContainer.RMVB: RMVBPolicy,
        VideoContainer.MP4: MP4Policy,
        
        
        }
        

    def get_policy_for_path(self, file_path: Path) -> BaseFormatPolicy:
        """Backup function based on file extension."""
        suffix = file_path.suffix.lower()
        
        # We find the matching container enum by suffix
        container = next((c for c in VideoContainer if c.suffix == suffix), None)
        
        # 3. Handle the None case explicitly before calling .get()
        # This prevents Pylance from complaining about passing 'None' to a dict key lookup
        if container is None:
            return DefaultPolicy()

        policy_class = self._POLICY_MAP.get(container, DefaultPolicy)
        return policy_class()

    def get_policy_based_on_video_record(self, video_record: VideoRecord) -> BaseFormatPolicy:
        """Primary selection based on probed container name."""
        if not video_record.has_playable_av:
            self.logger.regular_log(f"No playable streams found for {video_record.file.name}")
            return DefaultPolicy()

        if video_record.container_name is None:
            return DefaultPolicy()
        policy_class = self._POLICY_MAP.get(video_record.container_name, DefaultPolicy)
        
        # Update state and return
        self.selected_policy = policy_class()
        return self.selected_policy

    # def get_policy_for_path(self, file_path: Path) -> BaseFormatPolicy:
    #     suffix = file_path.suffix.lower()

    #     if suffix == VideoContainer.AVI.suffix:
    #         return AVIPolicy()
    #     if suffix == VideoContainer.MKV.suffix:
    #         return MKVPolicy()
    #     if suffix == VideoContainer.RMVB.suffix:
    #         return RMVBPolicy()
    #     return DefaultPolicy()

    # def get_policy_based_on_media_info(
    #     self, media:VideoRecord
    # ) -> BaseFormatPolicy | None:

    #     if not video_record.has_playable_av:
    #         self.selected_policy = None
    #     if video_record.container_name == VideoContainer.AVI:
    #         self.selected_policy = AVIPolicy()
    #     elif video_record.container_name == VideoContainer.RMVB:
    #         self.selected_policy = RMVBPolicy()
    #     elif video_record.container_name == VideoContainer.MKV:
    #         self.selected_policy =MKVPolicy()
    #     return self.selected_policy
