# Changelog

All notable changes to doubled-graph. Format: [Keep a Changelog](https://keepachangelog.com/en/1.1.0/). Versioning: [SemVer](https://semver.org/).

## [1.5.6] — 2026-05-03

### Fixed — Python 3.14 silently breaks all CGC parsing
`tree-sitter-language-pack` has no cp314 wheels. `pipx install` on
Python 3.14 succeeds but CGC can't parse any language at runtime —
`analyze` silently returns 0 symbols, `detect_changes` false-reports
everything as drift, `health` shows misleading numbers.

- **`requires-python`** capped to `>=3.11,<3.14` until the ecosystem
  ships 3.14 wheels. pip/pipx will now refuse to install on 3.14
  instead of producing a broken env.
- **`health`** (CLI + MCP) now includes a `cgc.ok` / `cgc.diagnostic`
  field. Probes `TreeSitterParser("python")` — if tree-sitter is
  broken, `health` reports it with actionable install instructions
  instead of silently degrading.
- **`CGC.check_parser()`** — new diagnostic method. Returns `None` if
  healthy, or a string with the error + `pipx inject` / `pip install`
  / `pipx install --python 3.12` hints.

## [1.5.5] — 2026-05-03

### Removed — `Config.repo_path` and `Config.repo_name`
Dead fields: nothing in the codebase read them from Config. All callers
pass `repo_path` as a function argument. Their presence caused a
pydantic validation error when users wrote a minimal `config.yaml`
without `repo_path` (regression from 1.5.4).

Removed entirely. `model_config = {"extra": "ignore"}` so old configs
that still contain these fields don't crash.

## [1.5.4] — 2026-05-03

### Added — `scan.exclude` config
`.doubled-graph/config.{json,yaml,yml}` now supports `scan.exclude`
patterns. `detect_changes` filters out matching files before drift
analysis. Patterns ending with `/` match directory prefixes; others
use fnmatch against the full relative path.

```yaml
scan:
  exclude:
    - research/
    - methodology/
    - prompts/
    - "*.generated.ts"
```

### Fixed — config.yaml not loaded
Config loader only looked for `config.json`. Now checks `config.yaml`
and `config.yml` first (YAML requires `PyYAML`; falls back to JSON
parsing if PyYAML is not installed).

## [1.5.3] — 2026-05-03

### Fixed — bare `&` in XML silently drops entire file
`_safe_parse` now auto-escapes bare `&` (e.g. "R&D") on retry instead
of silently returning `None`. Common in hand-written `docs/*.xml`.
Parse errors now surface in `loaded_from` with a diagnostic message
instead of a bare `!` prefix.

## [1.5.2] — 2026-05-02

### Fixed — sub-agents can't see MCP tools
Documentation described MCP tools for "the agent" (singular), never
stating that sub-agents (workers, reviewers) inherit MCP config. AI
correctly inferred MCP is main-session-only → sub-agents fell back to
CLI or skipped tool calls entirely.
- `tools.md` — "agent видит" → all agents see 9 tools.
- `roles.md` — added MCP access block: who calls what per role.
- `claude-code.md` § Sub-agents — sub-agents inherit `.mcp.json`.
- `06-generate.md` — worker steps now use `context()` + `analyze()`;
  reviewer steps use `lint()` + `detect_changes()`.

### Fixed — AI goes to GitHub instead of using local skills
`artifacts.md` header said "source of truth = upstream GitHub templates"
→ AI fetched from GitHub instead of using local inline examples.
- Rewrote `artifacts.md` header: inline examples are the source of truth.
- Fixed `requirements.xml` examples from `<UseCase id="UC-001">` to
  `<UC-001 ACTOR="…" ACTION="…">` (ID-in-tag-name convention).
- Removed actionable upstream GitHub links from `approval-checkpoints.md`,
  `workflow.md`, `02-requirements.md`, `local-llm.md`.
- Fixed remaining `<Module>` → `<M-*>` refs in `on-before-edit.md`,
  `roles.md`, `principles.md`, `workflow.md`.
- Fixed `<paths>` → `<target>` in all 7 language-adapters.
- Fixed `<Purpose>` + `<PublicExports>` → lowercase in `ARTICLE.md`.

## [1.5.0] — 2026-05-02

Full alignment with upstream grace-marketplace XML schema. Two
independent bugs that compound: (1) our declared-graph parser read a
non-existent `<Module id="…">` shape; (2) all bundled prompts, skills,
and methodology docs taught AI to generate that same non-existent shape.
Net effect: nothing worked end-to-end on any real repo.

### Fixed — parser (`graphs/declared.py`)
- **Module discovery** via tag-name regex `^M-[A-Za-z0-9_-]+$`
  (was: `iter("Module")`).
- **`purpose`** from `<contract><purpose>` (dev-plan) / `<purpose>` (kg).
- **`paths`** from `<target><source>` + `<target><tests>` (dev-plan)
  and `<path>` (kg), deduplicated.
- **`exports`** from `<interface>/*` (dev-plan) and `<annotations>/*`
  (kg) for tags prefixed `export-`/`fn-`/`type-`.
- **`CrossLink`** `from`/`to`/`relation` discovered at any depth,
  attached to source module's `crosslinks`.
- **Verification** entries via tag regex `^V-M-…$`, module from
  `MODULE` attr (uppercase), kind from `PRIORITY`.

### Fixed — shipped content (prompts, methodology, skills)
All XML examples rewritten from legacy form to grace-marketplace schema:
- `methodology/artifacts.md` — canonical reference, all 6 XML sections
  including `requirements.xml` (`<UC-001 ACTOR="…" ACTION="…">` form).
- `prompts/new-project/02-requirements.md`,
  `04-development-plan.md`, `05-verification-plan.md`,
  `07-post-init-sync.md`.
- `prompts/migrate-existing-project/02-reconstruct-intent.md`,
  `04-markup-codebase.md`, `05-verification-and-logs.md`,
  `06-validation-gates.md`.
- `prompts/maintenance/on-drift-detected.md`, `on-after-edit.md`,
  `on-before-edit.md`.
- All 5 bundled skills (`doubled-graph-after-edit`, `-drift`,
  `-refactor`, `-verify`, `-manual-edit`).
- All 7 language-adapters (TS, Python, Go, Rust, Java, C#, Swift).
- `methodology/artifacts.md`, `approval-checkpoints.md`,
  `auto-scaling.md`, `drift-and-priority.md`, `workflow.md`,
  `roles.md`, `principles.md`.
- `ARTICLE.md`.

### Fixed — "go to GitHub" instructions
`artifacts.md` header and several prompts/methodology files contained
links instructing AI to fetch upstream grace-marketplace templates from
GitHub instead of using local inline examples. Removed actionable
upstream links; `artifacts.md` inline examples are now the stated
source of truth for XML generation.

**Schema convention** (matches upstream grace-marketplace v3.7+):
- Module IDs encoded in tag name: `<M-AUTH-VALIDATE NAME="…" TYPE="…"
  STATUS="…">`, not `<Module id="…">`.
- `CRITICALITY="critical|standard|helper"` — doubled-graph custom attr
  (uppercase, on ID-tag). Upstream `grace lint` tolerates unknown attrs.
- Children lowercase/kebab: `<contract>`, `<target>`, `<interface>`,
  `<depends>`, `<observability>`, `<verification-ref>`.
- Verification: `<V-M-AUTH MODULE="M-AUTH" PRIORITY="high">` with
  `<scenarios>`, `<test-files>`, `<module-checks>`, not
  `<Verification id="…" module="…" kind="…">`.
- CrossLinks: `<CrossLink from="…" to="…" relation="…"/>` at
  `<Project>` level in kg, not `<CrossLink to="…"/>` inside Module.
- Phases: `<Phase-1 name="…" status="…">`, not `<Phase id="…">`.
- DataFlows: `<DF-LOGIN NAME="…" TRIGGER="…">`, not `<DataFlow id="…">`.

### Notes for upgrade
```bash
pipx upgrade doubled-graph
doubled-graph setup       # overwrites skills/prompts with fixed schema
doubled-graph health      # should now show real module count
```

If your existing `docs/*.xml` use the old `<Module id="…">` form, they
need migration to upstream form. Run `grace init` to regenerate templates,
or manually rewrite following the examples in `methodology/artifacts.md`.

## [1.4.7] — 2026-05-01

`doubled-graph setup` now **overwrites** existing bundled content
(prompts, methodology, skills) instead of skipping. Earlier behavior
left users on stale workflows after `pipx upgrade` until they manually
deleted the old files. Skills and prompts are doubled-graph-managed
content — they ship with the package and update with it.

### Changed
- **`_copy_bundle`** (prompts/, methodology/) now always overwrites
  existing files. Status tracking renamed: `written` (new) /
  `overwritten` (was already there) instead of `copied` / `skipped_existing`.
- **`_write_skill_file`** (per-IDE skill files: `.claude/skills/...`,
  `.cursor/rules/...`, `.continue/rules/...`, `.roo/rules/...`,
  `.kilocode/rules/...`, `.opencode/rules/...`) now always overwrites.
  Status: `written` / `overwritten`.
- **`_install_skills_windsurf`** replaces the marker-fenced
  `<!-- doubled-graph-skills:start --> ... :end -->` block in-place
  instead of skipping when present. Other content in `.windsurfrules`
  outside the block is preserved bit-for-bit (regression-tested).
- **Setup output** changes wording: `done (5 skills × 8 IDE targets;
  N fresh, M overwritten)` instead of `... N written, M kept existing`.

### Notes for upgrade
Standard upgrade flow is now zero-step:

```bash
pipx upgrade doubled-graph
doubled-graph setup    # overwrites stale skills/prompts; IDE re-spawns MCP via step 0 kill
```

If you've made local edits to bundled skill/prompt files and want to
preserve them: fork to a separate path (e.g. `.cursor/rules/my-team/`)
or commit your edits to git before running `setup` so you can `git
restore` the modified files after.

## [1.4.6] — 2026-05-01

Documentation-only release. Two related issues:

1. Methodology / prompts / skills referenced phantom commands (`doubled-graph
   init/plan/execute/verification/reviewer/refresh/fix/refactor/ask/multiagent_execute`)
   that aren't MCP tools, aren't CLI subcommands, aren't available skills,
   and aren't templates. Most of the methodology was written in terms of
   these — agents tried to call them and stalled.
2. Shipped docs were sprinkled with version-history annotations ("ранее",
   "since 1.4.0", "pre-1.4.x", "до 1.4.0", "(1.4.0)") describing the
   gateway-pattern history. Confusing for new users — they don't know /
   shouldn't care about previous architecture decisions. Version history
   belongs in CHANGELOG.

### Fixed
- **All references to phantom subcommands removed** from shipped content
  (methodology/, prompts/, for-humans/, for-ai-*/, docs/, ARTICLE.md,
  INDEX.md, src/doubled_graph/data/skills/, src/doubled_graph/setup.py).
  Replaced with concrete current-state actions:
  - `doubled-graph init` → "agent uses `Write` for `docs/*.xml` shells +
    `AGENTS.md` with phase block (see `prompts/new-project/02-requirements.md`)"
  - `doubled-graph plan` → "agent drafts `<Module>` records via `Edit` +
    architecture approval-gate"
  - `doubled-graph execute` → "agent generates code by phases, see
    `prompts/new-project/06-generate.md`"
  - `doubled-graph refresh` → "`Edit` `docs/knowledge-graph.xml` /
    `development-plan.xml` (skill `doubled-graph-after-edit` step 2)"
  - `doubled-graph fix` → "`Edit` code under existing contract
    (skill `doubled-graph-drift` § B.3)"
  - `doubled-graph verification` → "skill `doubled-graph-verify`"
  - `doubled-graph refactor` → "skill `doubled-graph-refactor`"
  - `doubled-graph reviewer` / `ask` / `multiagent_execute` — replaced
    with descriptions of how the agent does the same work via existing
    MCP tools + general-purpose `Read`/`Edit`/`Write`/`Bash`.
- **All version-history annotations stripped** from shipped content
  ("ранее", "до 1.4.0", "since 1.4.0", "pre-X.Y", "(1.4.0)" markers).
  CHANGELOG.md keeps its full version history (that's its purpose); other
  docs describe current state only.
- **`prompts/maintenance/*` rewritten** as thin entry-points that point
  at the canonical `doubled-graph-*` skill and give the gist (response
  shapes, soft-failure handling, anti-patterns). Was duplicating skill
  content with stale phantom references.
- **`methodology/workflow.md`, `principles.md`, `approval-checkpoints.md`,
  `artifacts.md`, `drift-and-priority.md`, `roles.md`, `tools.md`, all
  runtime-adapters/`** rewritten to describe the current architecture
  without "we used to do X but now do Y" framing.

### Notes for upgrade
Pure docs change — no runtime / API behavior diff. Re-run
`doubled-graph setup` to pick up updated skills if you want them in
your repo (idempotent: existing files preserved, see CHANGELOG 1.3.0
migration note for force-refresh recipe).

## [1.4.5] — 2026-05-01

Documentation-only release. Removes broken relative links that pointed at
local-checkout dev paths (`extra/research/grace-marketplace-main/...`,
`extra/research/CodeGraphContext-main/...`) which:
- Don't exist on user machines (`extra/` is in `.gitignore`, not shipped)
- Don't even exist on developer machines (those research dirs were
  removed long ago, but link references survived)

Audit ran across all shipped markdown (`methodology/`, `prompts/`,
`docs/`, `for-humans/`, `src/doubled_graph/data/skills/`, root README /
ARTICLE / INDEX). 92 → 68 relative links after cleanup, 28 broken → 0.

### Fixed
- **`extra/research/grace-marketplace-main/...` references** in
  `methodology/artifacts.md`, `methodology/approval-checkpoints.md` (5
  occurrences with `[link](../extra/extra/...)` typo), `methodology/
  runtime-adapters/{continue,cursor,codex,windsurf,local-llm}.md`,
  `for-humans/deep-dive.md`, `for-humans/FAQ.md`, `docs/SPEC.md`,
  `docs/TOOLS.md`. All replaced with absolute upstream URLs:
  - grace-marketplace → `https://github.com/osovv/grace-marketplace/...`
  - CodeGraphContext → `https://github.com/Shashankss1205/CodeGraphContext/...`
- **`extra/extra/...` typo** (double `extra/` from a copy-paste of a
  relative path that already had `../extra/`) — same files, fixed in
  the same pass.
- **Runtime-adapter docs (continue / cursor / codex / windsurf / local-llm)
  rewritten** to drop the "if MCP returns `delegated_to: upstream-skill:
  grace-X`, manually run the skill from local checkout" sections. With
  1.4.0 dropping the gateway pattern, those instructions described a
  workflow that doesn't exist anymore — replaced with current state:
  "skills install per-IDE via `setup` step 4, agent reads them as rules /
  on-demand discovery".
- **Dev-only doc references** (`PLAN.md`, `QUESTIONS.md`,
  `METHODOLOGY_DRAFT.md`, `QUESTIONS_FOR_REVIEW.md`) in
  `for-humans/deep-dive.md` and `for-humans/FAQ.md` — those live in
  gitignored `extra/` and never shipped. Replaced with pointers to
  `docs/CHANGELOG.md` (real release history) where applicable, removed
  where stale.
- **`ARTICLE.md` reference to `../doubled-graph/src/...`** — wrong
  layout assumption (we ARE doubled-graph, not a sibling repo). Rewritten
  to describe the post-1.4.0 reality (refresh as workflow in skills, not
  as a CLI command).
- **`INDEX.md` references to `PLAN.md` / `CLAUDE.md` / `AGENTS.md`** at
  repo root (don't exist) — replaced with pointers to actual artefacts
  (CHANGELOG, AGENTS.md-in-user-repo conventions).

### Removed
- **`docs/METHODOLOGY_README.md`** — orphan duplicate of
  `methodology/README.md` with stale internal layout assumptions (most
  of its 13 broken relative links were here). Nothing referenced it; the
  canonical README is `methodology/README.md`.

### Notes for upgrade
Pure docs change — no runtime / API behavior diff. Upgrade is optional
unless you've been hitting "file not found" on links inside our shipped
markdown.

## [1.4.4] — 2026-05-01

Stops MCP from dressing up understood scenarios as `GRACE_CLI_ERROR`. Pre-1.4.4
the wrapper methods (`module_show`, `module_find`, `file_show`) raised on any
non-zero rc — including the entirely normal "module not in declared graph",
"no matches for query", "file without anchors" cases. The MCP layer caught
the RuntimeError and surfaced it as `{"error": "GRACE_CLI_ERROR", "detail":
"rc=1 ..."}`, indistinguishable from real tool crashes (rc≥2). Models
couldn't tell signal from noise — every "lookup-with-no-result" looked
catastrophic.

### Fixed
- **Soft-failure semantics across all grace wrappers.** New protocol:
  rc=0 = success, rc=1 = expected non-success (findings / not-found /
  no-matches), rc≥2 (or rc=1 with completely empty stdout AND stderr) =
  real failure. Lint already had this from 1.4.2; module_show / file_show
  / module_find now match.
- **`module_show` returns `ModuleRecord(found=False, raw={...})`** instead
  of raising when grace can't find the module. MCP surfaces this as
  `{"result": {"found": false, "id": "M-X", "raw": {"stdout": ..., "stderr": ...}}}`
  — clear "no such module" signal, no error noise.
- **`file_show` returns `FileRecord(found=False, raw={...})`** for missing
  files / files without anchors. Same shape as module_show.
- **`module_find` returns `{"matches": [], "found": false}`** for empty
  search results. No raise, no error wrapping.
- **`module_show` / `file_show` / `module_find` CLI commands exit 1 on
  not-found** (was implicitly raising → exit 4 GRACE_CLI_ERROR pre-1.4.4).
  Same shell-gate semantics as `lint` — `&&` chaining works as expected:
  `doubled-graph module show M-AUTH && commit ...` short-circuits on
  not-found.

### Added
- **`GraceCLI._run_soft` helper.** Returns structured `{rc, ok, stdout,
  stderr}`; raises only on rc≥2 or ambiguous rc=1-with-no-output. Used by
  `lint`, `module_show`, `file_show`, `module_find`, and
  `_show_with_json_fallback` — single source of truth for grace exit-code
  classification. Legacy `_run` kept for callers that genuinely want
  raise-on-failure semantics (none of the wrappers use it anymore).
- **`found: bool = True` field on `ModuleRecord` and `FileRecord`.**
  Backwards-compatible default (existing code reads success records as
  `found=True` implicitly); soft-failure path sets it to False.
- **`found: bool` field on `module_find` return dict** + matches list
  always present (was `stdout` string fallback only). Models can branch
  on `found` instead of guessing from output shape.

### Changed
- **`_show_with_json_fallback` distinguishes "rc=1 unsupported flag"
  from "rc=1 not found".** When grace rejects `--json` (older versions),
  the helper retries without it; if THAT also returns rc=1, the lookup
  genuinely failed → constructor called with `found=False`.
- **SKILL.md guide + before-edit updated** with the new response shapes
  for `file_show` / `module_show` so models know to branch on
  `found` and not treat every soft-failure as a tool crash.

## [1.4.3] — 2026-05-01

Audit-driven release: applied the same fixes 1.4.2 made to `lint` across
every other grace-wrapper command, and cleared the long-standing TODOs
in the codebase.

### Fixed
- **CLI grace-wrapper handlers no longer leak Python tracebacks.** Pre-1.4.3,
  `_cmd_lint`, `_cmd_module_show`, `_cmd_module_find`, `_cmd_file_show` all
  caught only `GraceCLIMissing` — any `RuntimeError` from `_run` (rc != 0
  from grace itself) escaped and surfaced as a Python traceback to the
  user. New `_grace_cli_call` helper wraps every grace-wrapper handler:
  - `GraceCLIMissing` → JSON `{"error": "GRACE_CLI_MISSING", ...}`, exit 3
  - `RuntimeError` → JSON `{"error": "GRACE_CLI_ERROR", "detail": "..."}`,
    exit 4 (detail includes rc + stdout + stderr from the 1.4.2 `_run` fix)
  - Success → JSON payload on stdout, exit 0 (or 1 for lint findings)
- **`doubled-graph lint` exits 1 on findings, 0 on clean.** Pre-1.4.3
  always returned 0 regardless of `ok`/`exit_code` in the lint payload —
  meaning `doubled-graph lint && commit` could never gate. Now propagates
  `ok: false` as exit 1 so the command works as a CI / pre-commit gate
  without an extra wrapper script.

### Added
- **`GraceCLI.module_find()` public method.** Pre-1.4.3 the CLI handler
  bypassed the wrapper class and called `_run(["module", "find", ...])`
  directly — inconsistent with sibling commands and made future
  rc/JSON improvements harder to apply uniformly. Now both CLI and MCP
  dispatch route through this method.
- **`_show_with_json_fallback` helper** in `GraceCLI`. Both `module_show`
  and `file_show` now try `--json` first, fall back to plain text under
  `raw.stdout` when grace doesn't support the flag (older grace versions
  reject `--json` with rc=1). Returns structured `purpose` / `exports` /
  `crosslinks` (for modules) or `module_contract` / `contracts` / `blocks`
  (for files) when JSON parses; the pre-1.4.3 raw-text behaviour is
  preserved as a fallback.

### Changed
- **MCP `module_find` dispatch uses the new public method** instead of
  inlining `_run`. Same observable output, but the implementation is
  consolidated.
- **TODO comments cleared.** Two lingering `TODO[integration]` and
  `TODO[schema-verify]` markers from 1.0 were either resolved (the
  module_show / file_show TODOs by `_show_with_json_fallback`) or
  rewritten as a doc comment explaining the actual upstream conventions
  (declared.py XML tag conventions). Codebase has zero `TODO` / `FIXME` /
  `XXX` / `HACK` markers as of this release.

### Migration note
If you have a pre-commit hook or CI step that runs `doubled-graph lint`,
the exit code semantics changed from "always 0" to "1 on findings" —
your CI may start gating where it didn't before. That's intended
(methodology requires a clean lint before commit), but if you want the
old behaviour, parse the JSON output and decide yourself instead of
relying on exit code.

## [1.4.2] — 2026-05-01

Three issues exposed by the user upgrade flow after 1.4.1's tsx fix landed:

1. `doubled-graph lint` (and `module show` / `file show`) returned
   `GRACE_CLI_ERROR (rc=1)` with no detail — the actual lint findings
   were on stdout, but `_run` raised with only stderr in the message.
2. `grace lint` exits 1 when it finds violations (anchors broken, refs
   dangling). Treating that as "tool failure" hid normal-but-non-empty
   results from the agent.
3. After `pipx install --force doubled-graph`, the long-lived MCP
   server in the user's IDE kept the OLD code in memory. Users had to
   discover manually that they needed to restart their IDE — every fix
   we shipped looked like it didn't take effect.

### Fixed
- **`GraceCLI._run` includes stdout in error messages.** Pre-1.4.2 only
  surfaced stderr; the actual diagnostic from grace tools (anchor
  violations, missing-file paths, etc) lives on stdout. Errors now look
  like `grace lint failed (rc=1)\n  stderr: ...\n  stdout: ...`.
- **`GraceCLI.lint` distinguishes findings from failures.** rc=0 →
  clean; rc=1 with non-empty stdout → findings (returned with
  `exit_code: 1`, `ok: false`); rc≥2 OR rc=1 with empty stdout → real
  tool failure (raises). Bypasses `_run`'s strict raise-on-rc!=0 to keep
  this contract.

### Added
- **`doubled-graph kill-server` subcommand.** SIGTERM (then SIGKILL after
  2s grace) any running `python -m doubled_graph serve` processes. The
  IDE auto-respawns its MCP server on the next tool call, picking up the
  freshly-installed code. Standard recipe before any upgrade:
  ```bash
  doubled-graph kill-server
  pipx upgrade doubled-graph
  # IDE will restart the server automatically on next /mcp interaction
  ```
- **Setup auto-runs `kill_running_mcp_servers` as step 0.** Logs a
  `[pre] Killed N running MCP server(s)` line when it finds any. Makes
  the upgrade-then-setup workflow zero-step: user runs setup, server
  gets killed, IDE re-spawns with new code, all bug fixes take effect.
- **`kill_running_mcp_servers()` in `setup.py`** — public helper.
  Filters out our own PID and parent (defensive against accidentally
  killing ourselves). Skips on Windows (no MCP-Windows-from-IDE user has
  hit this; can add `taskkill` later). Returns structured report:
  `killed` / `no_running_servers` / `dry_run` / `skipped_windows`.

### Notes for upgrade
If you're upgrading FROM 1.3.x or 1.4.0/1.4.1 and `doubled-graph lint`
was crashing with `rc=127 env: bun: No such file or directory`, the flow
is now:

```bash
# 1. Kill any running MCP servers (or close your IDE; either works).
doubled-graph kill-server

# 2. Upgrade the package.
pipx upgrade doubled-graph        # or: pipx install --force doubled-graph

# 3. (Optional) re-run setup — it kills any servers it finds again,
#    so this is idempotent and safe even if you skipped step 1.
doubled-graph setup
```

If you skip step 1 OR don't restart your IDE manually, the IDE keeps
running the old in-memory code until the next IDE restart — looks like
the upgrade didn't take effect.

## [1.4.1] — 2026-05-01

Fixes a regression in `doubled-graph lint` (and `module show` / `file show`)
where MCP/CLI calls returned `GRACE_CLI_ERROR (rc=127): env: bun: No such
file or directory` — even when a previous `doubled-graph setup` had
correctly wired up the tsx-based fallback for Node-only environments.

### Fixed
- **`GraceCLI._check` now dispatches on the `runtime` field**, not on
  `status`. The bug: `try_install_grace_cli` returns
  `status="already_installed"` for both bun-direct AND tsx-fallback paths
  (when a prior setup left tsx wired up). The pre-1.4.1 `_check` looked
  only at `status` and cached `("bun", [grace])` for either case — the
  next `_run` then exec'd the bun-shebang grace binary, the kernel
  exec failed when env couldn't find bun, and the call returned rc=127.
  Fixed by inspecting `result["runtime"]` (set unambiguously by
  `try_install_grace_cli`) and caching the tsx invocation when it's
  `"tsx"`.
- **`GraceCLI._check` resolves tsx to an absolute path** rather than
  caching the literal `"tsx"` string. Same GUI-launcher PATH-stripping
  class of bug we fixed for the MCP entry in 1.0.11: a yarn/pnpm-installed
  tsx whose global bin dir isn't on `$PATH` (common on freshly bootstrapped
  systems before `pnpm setup` runs) wouldn't be found at exec time.

### Added
- **Regression test** `test_grace_cli_check_caches_tsx_when_already_installed_via_tsx`
  in `tests/test_smoke.py` — pins the fixed dispatch by stubbing
  `try_install_grace_cli` to return the tsx-flavored `already_installed`
  shape and asserting `_invocation` and `_build_cmd` route through tsx,
  not bun.

## [1.4.0] — 2026-05-01

**BREAKING.** Removes the 11 phantom "gateway" subcommands and MCP tools
that delegated to upstream `osovv/grace-marketplace` skills.

The fiction we cleared: `doubled-graph` claimed to expose `init`, `plan`,
`execute`, `multiagent_execute`, `verification`, `reviewer`, `refresh`,
`fix`, `ask`, `health`, `refactor` as both CLI subcommands and MCP tools.
Each call returned a JSON directive `{"delegated_to":
"upstream-skill:grace-X", ...}` instructing the agent to trigger the
upstream skill in its IDE's skill system. But: (a) `doubled-graph setup`
stopped installing those upstream skills in 1.2.0 (they polluted the
global namespace and created circular delegation); (b) most IDEs (Cursor,
Roo, Kilo, Continue, Windsurf, OpenCode) have no skill-trigger API at
all — directives there pointed nowhere. Net result: methodology
workflows got stuck mid-step, doc/code drift went unfixed, the model had
no real way to complete a refresh / plan / fix cycle.

Solution: stop pretending. Real work belongs in real tools or in skill
markdown the agent executes with its own `Read`/`Edit`/`Write`/`Bash`.

### Removed
- **11 CLI subcommands** (`init`, `plan`, `execute`, `multiagent-execute`,
  `verification`, `reviewer`, `refresh`, `fix`, `ask`, `health`,
  `refactor`) — argparse rejects them with the standard "invalid choice"
  error.
- **11 MCP tools** with the same names — `_dispatch` returns
  `{"error": "UNKNOWN_TOOL"}` for them.
- **`_SKILL_GATEWAYS` dict, `_make_skill_gateway` factory, `_cmd_refresh`
  function** in `cli.py`.
- **`skill_map` block** in `server.py:_dispatch`.
- **`test_cli_skill_gateways_emit_directive`,
  `test_cli_refresh_returns_directive`,
  `test_cli_refresh_dry_run_in_directive`** tests — they locked in the
  old broken behavior; replaced by a regression test asserting the
  phantom subcommands stay removed.

### Added
- **Real `doubled-graph health`** subcommand and MCP tool. Same name as
  the phantom it replaces, but does actual work: combos
  `detect_changes` (drift count by type) + declared module/V-M-* coverage
  + open `DRIFT.md` entries. Exit 0 if everything is clean, exit 1 if
  any health metric crosses a threshold (`drift_count > 0` /
  `open_drift_entries > 0` / `modules_without_verification` non-empty).
  Designed for CI as a one-shot project-state check.
- **`doubled-graph-refactor` SKILL.md** — workflow for safe rename / move
  / split / extract using `impact()` + `Edit` for whole-file coordination
  (code + `docs/*.xml` + `verification-plan.xml` references). Replaces
  the dropped `doubled-graph.refactor()` gateway with an agent-side
  workflow that actually completes.
- **`doubled-graph-verify` SKILL.md** — workflow for adding `V-M-*`
  records + minimal test scaffold proportional to module criticality
  (critical = full coverage, standard = happy + 1 error case, helper =
  smoke). Used by `doubled-graph-drift §B.5` and standalone when the
  user asks "add tests for M-X".

### Changed
- **All 5 existing SKILL.md files rewritten** to drop references to the
  dropped gateway tools. Where a skill said "call `doubled-graph.refresh()`",
  it now says "Edit `docs/knowledge-graph.xml` to update `<Export>` /
  `<CrossLink>` for module M-X" with explicit XPath-like guidance.
  Maintenance loop becomes self-contained: agent uses real MCP tools
  (`analyze`/`impact`/`context`/`detect_changes`/`lint`/`module_show`/
  `file_show`/`health`) plus its own `Read`/`Edit`/`Write`/`Bash`.
- **`methodology/tools.md` §1 rewritten** — drops the gateway-architecture
  framing, explains the new lean tool-surface (9 MCP-tools + 6 CLI-only
  + 7 skills) and explicitly documents the 1.4.0 removal as a "what was
  fiction, what is real" section.
- **Setup ships 7 skills** (was 5): the matrix in step 4/8 expands by 2
  (refactor + verify). Tests updated.

### Migration note
If you have skill files from doubled-graph 1.3.x in your repo
(`.claude/skills/doubled-graph-*`, `.cursor/rules/doubled-graph-*`, etc),
re-run `doubled-graph setup` — it will not overwrite (idempotent), but
the phantom-tool references in your old files will be subtly broken.
Either delete the old skill files first to pick up our 1.4.0 versions:

```bash
rm -rf .claude/skills/doubled-graph-* .cursor/rules/doubled-graph-* \
       .continue/rules/doubled-graph-* .roo/rules/doubled-graph-* \
       .kilocode/rules/doubled-graph-* .opencode/rules/doubled-graph-*
# Manually delete the doubled-graph-skills:start..end block in .windsurfrules.
doubled-graph setup
```

If your prompts or scripts called `doubled-graph refresh` / `plan` /
etc, replace those calls per the workflow guidance in the new SKILL.md
files (mostly: `Edit docs/*.xml` instead of `refresh`, agent-side
planning instead of `plan`, etc).

## [1.3.1] — 2026-05-01

Decouples `.gitignore` updates from the hooks step so `doubled-graph setup`
always leaves the user's `git status` clean — even with `--skip-hooks`.

The runtime dirs `.doubled-graph/cache/` and `.doubled-graph/logs/` are
populated by `analyze` and the MCP server, not by the post-commit hook.
In 1.3.0 (and earlier), the `.gitignore` append happened as a side
effect of `_install_hooks`, so users running `setup --skip-hooks` ended
up with `.doubled-graph/cache/` showing up untracked on first analyze.
This release hoists the gitignore concern out of hooks and into its
own setup step.

### Added
- **New `ensure_gitignore_entries` public helper** in `hooks_installer.py`.
  Idempotent — running twice never duplicates lines. Decoupled from
  `install_hooks`. Used by both `doubled-graph setup` and `doubled-graph
  init-hooks`.
- **New step 5/8 in `doubled-graph setup`**: "Ensuring .gitignore covers
  .doubled-graph runtime dirs…". Runs unconditionally — no `--skip-*`
  flag turns it off (the runtime dirs always exist after first analyze;
  there's no scenario where leaving them out of gitignore is correct).
- **`gitignore` key at top level of setup report** (was previously nested
  inside `hooks.report.gitignore`, easy to miss).

### Changed
- **`install_hooks` no longer touches `.gitignore`.** Old call sites that
  relied on `report["gitignore"]` from `install_hooks` now find the same
  data at the top level of the setup report (or, for standalone
  `doubled-graph init-hooks`, at `report["gitignore"]` — the CLI handler
  calls the helper directly).
- **Setup step count: 7 → 8.** Step list (1.3.1):
  1. grace-cli, 2. cgc deps, 3. bundle copy, 4. skills, **5. gitignore (new)**,
  6. MCP register, 7. hooks, 8. analyze.

## [1.3.0] — 2026-05-01

Adds the discovery layer that 1.2.0 promised. doubled-graph now ships its
**own** SKILL.md files (5 standalone skills covering the maintenance loop)
and `doubled-graph setup` writes them into every known IDE skill path
unconditionally — we don't know which IDE the user will run with, and the
cost of an unused `.roo/rules/` directory is far lower than the cost of
the user discovering their IDE doesn't pick up our skills.

The skills are **standalone** — each SKILL.md contains the full workflow,
risk-gate, anti-patterns, and a <1KB cheatsheet. They do not reference
`prompts/` or `methodology/`, so they keep working even if the user
deletes those directories.

### Added
- **5 bundled skills** in `src/doubled_graph/data/skills/<name>/SKILL.md`:
  - `doubled-graph-guide` — overview + tools/CLI reference + skill router
  - `doubled-graph-before-edit` — `impact` risk-gate before any edit
  - `doubled-graph-after-edit` — drift / lint / tests / contract-check before commit
  - `doubled-graph-drift` — per-type resolution (code_without_module, contract_mismatch, etc) with externalized state
  - `doubled-graph-manual-edit` — re-analyze + lint + CHANGE_SUMMARY for human edits
- **New setup step `_install_skills`** writes to all 7 IDE-native paths:
  | IDE | Path | Format |
  |---|---|---|
  | Claude Code | `.claude/skills/<name>/SKILL.md` | YAML frontmatter (verbatim) |
  | Cursor | `.cursor/rules/<name>.mdc` | mdc frontmatter (description + alwaysApply) |
  | Continue | `.continue/rules/<name>.md` | plain MD, frontmatter stripped |
  | Roo Code | `.roo/rules/<name>.md` | plain MD, frontmatter stripped |
  | Kilo Code | `.kilocode/rules/<name>.md` | plain MD, frontmatter stripped |
  | OpenCode | `.opencode/rules/<name>.md` + `opencode.json` glob merge | plain MD, frontmatter stripped |
  | Windsurf | `.windsurfrules` | single concat block, marker-fenced |
- **`--skip-skills` flag** for `doubled-graph setup`. For users who manage
  rules out-of-band or who want only the MCP server.
- **`skills` key in setup report** alongside `grace_cli`, `cgc_deps`,
  `prompts`, `methodology`, `mcp_register`, `hooks`, `analyze`. Step count
  went from 6 to 7; otherwise back-compat.

### Changed
- **Setup writes per-IDE skill files unconditionally**, regardless of the
  detected IDE. The `--ide` flag still scopes MCP registration to one IDE,
  but skills always go to all 7 paths so swap-in works without re-running
  setup. Existing files are not overwritten — re-running setup is safe and
  reports which paths kept their existing content.
- **Skills installed are project-local**, written under the repo root.
  Matches the pattern of `.cursor/rules/` and `.windsurfrules` users
  already commit to their repos. Global install (`~/.claude/skills/...`)
  is intentionally not used: skill content is methodology-coupled, not
  user-coupled.

### Notes
- For Windsurf, all 5 skills are concatenated into a single
  `<!-- doubled-graph-skills:start -->` … `<!-- doubled-graph-skills:end -->`
  block in `.windsurfrules`. This is by design: Windsurf reads only one
  rules file and always loads its full content. Marker-fencing makes the
  block recognizable for idempotent re-runs and easy manual removal.
- For OpenCode, we add `.opencode/rules/*.md` to `opencode.json`'s
  `instructions` glob list rather than touching `AGENTS.md`. The
  methodology already manages `AGENTS.md` via `doubled-graph init` (phase
  block + module index), and silently appending to it would conflict
  with that ownership.
- **Updating skills across doubled-graph releases.** `setup` is
  idempotent — once a skill file exists in your repo, re-running
  `doubled-graph setup` will not overwrite it. This protects local edits,
  but it also means a newer doubled-graph version's improved skills
  won't auto-replace older copies on disk. To pick up bundled skill
  changes from a doubled-graph upgrade, delete the relevant files first:
  ```bash
  rm -rf .claude/skills/doubled-graph-* .cursor/rules/doubled-graph-* \
         .continue/rules/doubled-graph-* .roo/rules/doubled-graph-* \
         .kilocode/rules/doubled-graph-* .opencode/rules/doubled-graph-*
  # In .windsurfrules, delete the
  # <!-- doubled-graph-skills:start --> … <!-- :end --> block manually.
  doubled-graph setup
  ```
  We deliberately do not auto-overwrite — silently destroying user edits
  to skill files would be far worse than leaving stale skills until an
  explicit refresh.

## [1.2.0] — 2026-05-01

Reverts the upstream-skills install added in 1.1.0/1.1.1. That step was a
design mistake: it pulled `osovv/grace-marketplace` skills (86 files) into
the user's **global** `~/.claude/skills/grace/` directory, polluting a
namespace doubled-graph doesn't own and creating a circular delegation
where `doubled-graph init` (MCP gateway) returned "trigger upstream-skill
grace-init", which then created XML by upstream's templates instead of
ours. doubled-graph already ships its own methodology in `prompts/` —
those are content. The discovery layer (skills) for our methodology will
be added in a follow-up release; it will install **our own** SKILL.md
files, not upstream's.

### Removed
- **`try_install_grace_skills` function** in `integrations/grace_cli.py`.
- **`_install_grace_skills` step** (the old step 2) in `run_setup`.
- **`--skip-skills` flag** for `doubled-graph setup`.
- **`skills` key** from the setup report; correspondingly removed from
  `report["ok"]` calculation.
- **`opkg`-via-bun/npm/yarn/pnpm bootstrap path.** No transitive
  dependency on OpenPackage anymore.

### Unchanged from 1.1.x
- **tsx-based fallback for grace-cli** (lint/module/file). When Bun is
  absent but Node is available, we still install grace-cli via npm/yarn/
  pnpm and run it via `tsx <path>/grace.ts`. This is unrelated to skills
  and remains useful regardless.
- **Multi-PM lookup helpers** (`_global_node_modules_roots`,
  `_pm_global_bin`, `_resolve_executable`). They'll be reused when we add
  our own skills install.
- **MCP entry uses `sys.executable` + `python -m doubled_graph serve`**
  (from 1.0.11) — survives GUI-launcher PATH stripping.
- **Startup self-check in `serve`** (from 1.0.11) — actionable error if
  `codegraphcontext` isn't importable.

### Migration note
If you ran `doubled-graph setup` with 1.1.0 or 1.1.1, you have upstream
GRACE skills in `~/.claude/skills/grace/`. To remove them:

```bash
opkg uninstall gh@osovv/grace-marketplace -g  # if opkg is still around
# or, manually:
rm -rf ~/.claude/skills/grace
```

Skills aren't required for doubled-graph to work — gateway tools
(`init`/`plan`/etc) emit delegation directives that the agent can
interpret directly via the bundled `prompts/` until our own skills
ship.

## [1.1.1] — 2026-05-01

Fixes the grace-cli runtime trap and adds a Node-based fallback so users
without Bun still get a working `grace`.

The problem: @osovv/grace-cli's bin is a TypeScript file with
`#!/usr/bin/env bun` shebang. npm/yarn/pnpm install it successfully, but
every invocation fails with `env: bun: No such file or directory`.
Earlier ladders treated install exit code 0 as success without verifying
the binary actually runs.

The grace source itself uses no Bun-specific APIs (verified against
upstream 3.8.0 — only `citty` + stdlib). So we can run it under any
TypeScript runner; we picked `tsx` (Node-based, ~5MB npm install).

### Fixed
- **Runtime-aware installer ladder.** `try_install_grace_cli` keeps the
  bun→npm→yarn→pnpm ladder, but after each successful install runs
  `_grace_runs_ok()` (executes `grace --help`, checks exit code and
  stderr for `bun: No such file`). A binary that's on PATH but doesn't
  execute no longer counts as "installed".
- **Self-heal on existing broken installs.** Same smoke-test runs
  pre-install: a previously-broken `grace` is treated as "not installed"
  and triggers a fresh install on the next `doubled-graph setup`.

### Added
- **tsx (Node-based) fallback.** When a Node-only installer places
  grace.ts on disk but the Bun shebang fails, we install `tsx` via the
  same package manager and verify `tsx <path-to>/grace.ts --help` works.
  If yes, the install report returns `status: "installed_via_tsx"` with
  the entry path. `GraceCLI._run` routes calls through tsx instead of
  the broken shebang. Users on Node-only environments get full
  `grace lint` / `module show` / `file show` functionality without ever
  installing Bun.
- **`GraceCLI._build_cmd` + `_invocation` caching.** First call probes
  the environment once (direct Bun → tsx fallback → fail with clear
  hint), subsequent calls reuse the cached argv prefix.
- **Multi-PM-aware lookup helpers.**
  `_global_node_modules_roots()` walks every available PM's reported
  global root (npm/pnpm/yarn/bun) plus standard hardcoded paths so
  `_locate_grace_entry` finds grace.ts regardless of which PM installed
  it. `_pm_global_bin(pm)` returns each PM's bin dir using the
  appropriate command per PM (and per PM version — npm 9+ removed
  `npm bin -g`, so we use `npm prefix -g` + "/bin" instead).
  `_resolve_executable(name, prefer_pm=...)` falls back from $PATH to
  every PM's global bin so binaries placed by yarn/pnpm work even when
  their bin dirs aren't on $PATH (a common gap until users run
  `pnpm setup` / shell-profile changes).
- **opkg invoked by absolute path** in `try_install_grace_skills`. Step
  2 used to require `opkg` on $PATH, breaking when yarn/pnpm bootstrapped
  it but didn't update PATH. Now we resolve through `_resolve_executable`
  and run opkg by full path. If $PATH lookup failed, the report carries
  a `path_warning` field telling the user which dir to add to PATH for
  manual opkg use.

### Unchanged
- **opkg has no Bun-runtime requirement.** Its `bin/openpackage` ships
  precompiled JS (`engines` is empty), so the bun→npm→yarn→pnpm
  bootstrap ladder for opkg stays without a tsx-style fallback.

## [1.1.0] — 2026-05-01

`doubled-graph setup` now installs upstream GRACE skills as part of
onboarding. Without this, gateway tools (`init`, `plan`, `execute`,
`refresh`, …) returned a delegation directive that the IDE skill-system
had no skill to fulfil, dead-ending the user. The fix keeps doubled-graph
as a true facade: it tells upstream's `opkg` what to install, opkg places
the skills where the active IDE looks for them.

### Added
- **New setup step: GRACE skills install via `opkg`.** `setup` now runs
  `opkg install gh@osovv/grace-marketplace -g` after the grace-cli step.
  `opkg` is auto-installed via the existing bun → npm → yarn → pnpm
  fallback ladder if it isn't on PATH. Skills land in the IDE's skill
  directory (`~/.claude/skills/grace-*` for Claude Code, etc.) — the
  placement stays opkg's responsibility.
- **`--skip-skills` flag for `doubled-graph setup`.** For users who
  manage skills out-of-band, or for environments where opkg is
  unavailable. Setup logs `status: skipped` and continues; gateway
  tools that need skills will still emit their delegation directives
  but the user knows up front the skill isn't installed.
- **`integrations.grace_cli.try_install_grace_skills()`** — public
  function mirroring `try_install_grace_cli()` shape so callers
  (setup, future lazy-install paths) get a structured install report.

### Changed
- **Setup report grew a `skills` key** alongside `grace_cli`, `cgc_deps`,
  `mcp_register`, `hooks`, `analyze`. `report["ok"]` now also requires
  the skills step to be `installed`/`already_installed`/`skipped`/`dry_run`.
  Step count went from 6 to 7; the existing JSON schema is otherwise
  back-compat.

## [1.0.11] — 2026-05-01

Fixes a class of "doubled-graph looks broken in the IDE but works in the
terminal" bugs caused by GUI launchers (Claude Desktop / Cursor /
Continue) inheriting a stripped PATH from `launchd` that doesn't contain
`~/.local/bin`. The `command: "doubled-graph"` shim couldn't be resolved,
the IDE-side error surfaced as a confusing missing-module trace, and the
fix wasn't obvious without diffing PATHs.

### Fixed
- **`doubled-graph setup` writes a PATH-independent MCP entry.** The
  generated `.mcp.json` (and the equivalent for Cursor/Continue) now
  uses `command: <sys.executable>` + `args: ["-m", "doubled_graph",
  "serve"]`, pinning the exact Python the install ran from (pipx venv
  or otherwise). Removes the dependency on the GUI process having
  `~/.local/bin` in PATH.

### Added
- **Startup self-check in `serve`.** If `codegraphcontext` cannot be
  imported when the MCP server starts, we now raise a `RuntimeError`
  with an actionable two-line fix (`pipx reinstall doubled-graph` →
  `doubled-graph setup`) instead of starting cleanly and failing on the
  first tool call deep inside a dispatcher. The message is visible in
  the MCP client's stderr log.

### Changed
- **`.mcp.json` no longer tracked in this repo.** It was a developer's
  per-machine config that pinned `command` to a path which didn't exist
  on other machines. Now in `.gitignore`; regenerated locally via
  `doubled-graph setup`.

## [1.0.10] — 2026-04-27

### Fixed
- **`GraphBuilder` constructor mismatch with CGC ≥0.4.** CGC 0.4 added two
  required positional args to `GraphBuilder.__init__`: a `JobManager` and an
  asyncio event loop. Our `integrations/cgc.py:_ensure` was still calling
  `GraphBuilder(db_manager)`, which produced
  `TypeError: GraphBuilder.__init__() missing 2 required positional arguments:
  'job_manager' and 'loop'` on every analyze. Now constructs a `JobManager()`
  and a dedicated `asyncio.new_event_loop()` per CGC instance and passes them
  through. Also catches future signature drift explicitly with a
  `CGCUnavailable` that names the actual problem instead of bubbling up a
  raw TypeError.

## [1.0.9] — 2026-04-27

Two bugs visible to users on cutting-edge Python (3.14):

### Fixed
- **CGC self-heal loop no longer spins** when `pip install` reports
  `Requirement already satisfied` but the import still fails. That
  combination almost always means the package is on disk but its wheels
  don't support the current Python (e.g. native ABI3 `.so` that doesn't
  load on Python 3.14 yet). The heal step now detects the same package
  reappearing as missing right after a "successful" reinstall and bails
  out with `status: "import_broken"` plus an actionable hint pointing at
  Python version: `pipx install --python python3.12 --force doubled-graph`.
- **Runtime CGC error message** in `integrations/cgc.py` now appends the
  same Python-version fallback advice, so users hitting this from
  `doubled-graph analyze` (without going through `setup`) see the right
  fix rather than just `pipx inject` instructions that silently no-op.

## [1.0.8] — 2026-04-27

### Fixed
- **`meta.tool_version` no longer lies.** `__version__` was hardcoded in
  `src/doubled_graph/__init__.py`, so every release silently shipped with
  `tool_version: "1.0.0"` in JSON output unless someone remembered to bump
  the constant separately from `pyproject.toml`. It now resolves through
  `importlib.metadata.version("doubled-graph")` — the runtime always reports
  whatever pipx/pip actually installed. Source checkouts without an
  installed dist fall through to `0.0.0+source`, so the suffix makes that
  state obvious.

## [1.0.7] — 2026-04-27

Real fix for the `No module named 'tree_sitter_language_pack'` crash that
1.0.6 still left some users hitting. Diagnosis: CGC 0.4.2 *does* pin its
tree-sitter transitive deps itself, but earlier CGC releases (0.1.x / 0.2.x)
did not — and our `codegraphcontext>=0.1` floor in pyproject was loose
enough that pipx could legitimately resolve to one of those incomplete
versions.

### Changed
- **`codegraphcontext` floor raised from `>=0.1` to `>=0.4.2`** in
  `pyproject.toml`. Any new `pipx install doubled-graph` now resolves to
  a CGC release whose own pins guarantee the parser pack is brought in
  transitively — no more "incomplete but successful" installs.
- Direct pin of `tree-sitter-language-pack` tightened from `>=0.1` to
  `>=0.6` to match what CGC 0.4.2 itself requires.

### Notes for upgrade
- Users on doubled-graph 1.0.0 who hit this need to actually upgrade their
  install — `pipx install --force doubled-graph` (or `pipx upgrade
  doubled-graph` once 1.0.7 is on PyPI). The pyproject pin only takes
  effect at install time.

## [1.0.6] — 2026-04-27

Onboarding-reliability release. Three classes of issues a fresh user could hit
during `pipx install doubled-graph` + `doubled-graph setup` are addressed.

### Added
- **Self-healing CGC dependency check** in `doubled-graph setup` (new step
  2/6, `cgc_deps`). After grace-cli, the setup pre-imports
  `codegraphcontext.{core,tools.*}`. If a transitive dep is missing
  (e.g. `tree_sitter_language_pack` — CGC 0.1.x doesn't pin it), runs
  `<sys.executable> -m pip install <pkg>` to inject it. Loops up to 5
  iterations, since uncovering one missing module often surfaces another.
  Works in pipx venvs (pipx ships pip), regular venvs, and conda envs alike.
- **PM-aware error classification** for grace-cli install failures. Failed
  installs now return a structured record with `command`, `exit_code`,
  `error_type` (`network_timeout` / `network_unreachable` / `permission_denied`
  / `package_not_found` / `conflict` / `install_failed`), and an actionable
  `hint` that references the actual package manager used (no more telling a
  bun user to `npm config set proxy`).
- **Step-by-step progress logging** in `doubled-graph setup` (stderr).
  Previously the command printed only the final JSON report — users saw a
  blank terminal for 30+s and assumed it was hung. Now each step prints
  `[N/6] <what's happening>…` followed by a one-line summary.
- **Live streaming of package-manager output** during grace-cli install.
  Replaces the silent `subprocess.run(capture_output=True)` with a
  Popen+tee pattern so users see npm/bun progress in real time.
- **README install instructions** rewritten around `pipx`. Cross-platform
  install table for pipx itself (macOS / Debian / Ubuntu / Fedora / Arch /
  Windows). New "Удаление" section covers `pipx uninstall` plus the artifacts
  `setup` leaves in the repo (`.mcp.json` entry, `prompts/`, `methodology/`,
  git hook, `.doubled-graph/`, grace-cli).

### Fixed
- **`doubled-graph setup` no longer silently leaves grace-cli uninstalled**
  when Bun is missing. The fallback chain (`bun → npm → yarn → pnpm`) was
  already implemented in `integrations/grace_cli.py` for lazy-install via
  `GraceCLI._check`, but `setup.py:_install_grace_cli` had its own
  bun-only path. Both call sites now go through a single shared helper
  (`try_install_grace_cli`).
- **CGC error message no longer misleads pipx users.** Previously the
  catch-all suggested `pip install codegraphcontext`, which both (a) doesn't
  apply when CGC is already installed and a transitive dep is what's
  missing, and (b) fails on PEP 668 / pipx-isolated environments. The
  message now distinguishes the two cases and orders `pipx inject` /
  `pip install` hints by detected install path.
- **`tree-sitter-language-pack` pinned directly** in `pyproject.toml`.
  Belt-and-suspenders with the runtime self-heal — pinning here means a
  fresh PyPI install no longer needs the heal to fire.
- **Versions synced.** `__init__.py` was stuck at `1.0.0` while
  `pyproject.toml` had moved to `1.0.4`; reports printed the old number.
  Both now `1.0.6`.

### Changed
- `doubled-graph setup` step count: 5 → 6 (CGC dep verify inserted as
  step 2). Output format unchanged otherwise.

## [1.0.2] — 2026-04-20

Initial public release.

### Added
- `doubled-graph setup` — single-shot onboarding: installs `@osovv/grace-cli`,
  copies bundled prompts + methodology into the repo, registers MCP for the
  detected IDE (Claude Code / Cursor / Continue), installs the git post-commit
  hook, runs the first full analyze. Supports `--dry-run` and `--ide` override.
- Real CGC integration in `integrations/cgc.py`:
  - `analyze_full`, `analyze_incremental` wired to `GraphBuilder`
    (`add_repository_to_graph` / `delete_file_from_graph` / `parse_file` /
    `link_function_calls` / `link_inheritance`)
  - `find_callers`, `find_callees` wired to
    `CodeFinder.analyze_code_relationships(find_all_callers / find_all_callees)`
  - `find_symbol` wired to `CodeFinder.find_by_function_name`
  - `symbols_in_file` via Cypher fallback
- `impact` now returns populated `direct` / `transitive` / `affected_modules` /
  `affected_verification`. Risk classification uses real caller counts +
  phase + verification-touch.
- `context` fully implemented — joins CGC symbol, declared module, and
  extracts `MODULE_CONTRACT` / `CONTRACT:fn` blocks from source.
- `detect_changes` fully implemented — `code_without_module`,
  `module_without_code`, `stale_crosslinks`, `missing_verification`,
  `markup_missing`. Resolution hint branches on `migration` vs
  `post_migration`.
- `analyze` now persists `.doubled-graph/cache/code-fingerprint.json` on
  every successful run (enables `mode=auto` incremental detection).
- CLI subcommands `impact`, `context`, `detect-changes` are no longer stubs —
  they dispatch into the tools package.
- Bundled `prompts/` and `methodology/` shipped inside the wheel via
  `hatch force-include`; loaded with `importlib.resources` by `setup.py`.
- 29 smoke tests covering CGC stubs, impact risk escalation, context joins,
  drift detection, CLI wiring, setup dry-run + MCP registration.

### Changed
- Bumped version 0.1.0.dev0 → 0.1.0.
- pyproject: added classifiers, keywords, URLs, `anyio` runtime dep, sdist
  manifest.
- `README.md` replaces `SPEC.md` as the PyPI long description.

### Removed
- `NotImplementedError` stubs in `integrations/cgc.py`.
- `NOT_IMPLEMENTED_MVP` stub classes for `context` and `detect_changes`.
- CLI `NOT_IMPLEMENTED_MVP` fallback for `impact` / `context` /
  `detect-changes`.
