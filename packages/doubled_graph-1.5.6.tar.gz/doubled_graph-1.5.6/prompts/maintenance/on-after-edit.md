# on-after-edit — после правки, до коммита

**Целевая аудитория:** ИИ-ассистент.
**Триггер:** только что сохранён изменённый файл.

---

## Канонический workflow — skill `doubled-graph-after-edit`

`doubled-graph setup` устанавливает skill `doubled-graph-after-edit` (см. `.claude/skills/doubled-graph-after-edit/SKILL.md` в твоём репо или эквиваленты для Cursor/Roo/Kilo/etc). Skill активируется автоматически по триггеру `description` (Claude Code, Cursor) либо как always-on rule (Roo / Kilo / Continue / Windsurf / OpenCode).

Этот промпт-файл — fallback для ситуаций когда skill не загружен (старый клиент, ручной режим). Логика идентична skill'у.

---

## Шаги (краткая форма)

**1. Обновить computed graph для тронутых файлов** (если в IDE нет PostToolUse hook):

```
doubled-graph.analyze(mode="incremental", paths=["<тронутые-файлы>"])
```

**2. Обновить declared graph через `Edit`, если правка семантическая.** Семантическая = изменение публичных экспортов модуля, новый импорт из другого `M-*`, изменение поведения, влияющего на `verification-plan.xml`.

- `Edit` `docs/knowledge-graph.xml` — обнови `<export-.../>` / `<fn-.../>`, `<CrossLink from="..." to="..." relation="..."/>`, `<contract>` (purpose/inputs/outputs/errors) под новую реальность.
- `Edit` `docs/development-plan.xml` — если сменился `<source>`/`<path>` или `CRITICALITY`.

Возьми текущий контракт через `doubled-graph.module_show(target="<M-id>")` как baseline.

**3. Drift check:**

```
doubled-graph.detect_changes(scope="staged")
```

- `result.drift` пуст → продолжай.
- `result.drift` непуст → перейди на `on-drift-detected.md` (skill `doubled-graph-drift`).

**4. Lint якорей:**

```
doubled-graph.lint()
```

| Ответ | Действие |
|---|---|
| `{"result": {"ok": true}}` | продолжай шаг 5 |
| `{"result": {"ok": false, "violations": [...]}}` | для каждого `{file, line, rule, detail}` — `Edit` файл, поправь. Перезапусти lint. **Не коммить через `--no-verify`** до `ok: true`. |
| `{"error": "GRACE_CLI_ERROR", "detail": "..."}` | grace сам упал, разбирайся отдельно (не lint findings) |

**5. Релевантные тесты.** Из `verification-plan.xml` найди `V-M-*` записи для тронутого модуля, выполни их `Command` через Bash. Тесты упали → останови, покажи ошибку. Не коммить сломанное.

**6. Contract-change check.** Если правка изменила сигнатуру публичного экспорта, `<contract>` (purpose/inputs/outputs/errors), `<interface>` (`<export-.../>` / `<fn-.../>`), CrossLinks или `CRITICALITY` — **остановись**, покажи отдельным блоком:

```
⚠ CONTRACT CHANGE в <M-ID>:
  было: <old signature/pre/post/inv>
  стало: <new signature/pre/post/inv>
  причина: <из задачи / из diff>
  callers затронуты: <из impact depth=1>
```

Жди явного подтверждения от пользователя («contract change ок», «откати» и т.п.). Без подтверждения — не коммить. Внутренние правки этого шага не требуют.

**7. Коммит.** Все четыре gate должны быть зелёные:
- `detect_changes` пусто;
- `lint` clean (`ok: true`);
- тесты прошли;
- `impact` перед правкой был не CRITICAL (или явно одобрен).

Commit-message:

```
<краткое описание изменения>

Affected: <M-ids через запятую>
LINKS: <UC-ids через запятую>
```

Если был contract-change — добавь строку `Contract-change: <M-ID> <что>`.

---

## Что коммитить, что не коммитить

**Коммитим:** изменённый код, обновлённые `docs/*.xml`, обновлённый `CHANGE_SUMMARY` в коде.
**НЕ коммитим:** `.doubled-graph/cache/` (в .gitignore), `.doubled-graph/logs/` (в .gitignore), временные файлы тестов.

**Отдельными коммитами при больших правках:** chore-правки (rename без логики), markup-правки (только якоря в `migration` режиме).

---

## Anti-patterns

- Не коммить без `detect_changes`.
- Не коммить только `docs/*.xml` без кода (если это не drift-resolution pass).
- Не коммить через `--no-verify`. Если gate упал — поправь проблему.
- Не смешивай правку > 1 модуля в один коммит без обоснования.
