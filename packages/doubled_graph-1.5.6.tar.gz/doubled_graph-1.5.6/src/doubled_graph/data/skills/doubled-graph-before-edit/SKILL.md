---
name: doubled-graph-before-edit
description: "Use BEFORE editing any function, class, method, or file in the codebase. Calls doubled-graph.impact to assess blast radius and stop dangerous changes before they happen. Triggers: editing existing code, modifying a function, refactoring, renaming, changing a signature, updating a class method, touching shared infrastructure."
---

# doubled-graph — перед правкой кода

**Триггер:** ты собираешься править существующую функцию / класс / метод / файл.
**Цель:** не сломать зависимый код, не нарушить контракт модуля, дать пользователю шанс остановить опасную правку до факта.

Этот skill — обязательный risk-gate. Без него правки идут «вслепую».

**Маршрут:** все шаги через MCP-tools `doubled-graph.*`. Bash — только если MCP недоступен.

---

## Шаг 1 — обновить computed graph (если нужно)

Если с момента последнего `analyze` правились файлы и **в IDE НЕТ автоматического PostToolUse hook** (Claude Code ставит его через `doubled-graph init-hooks`):

```
doubled-graph.analyze(mode="incremental", paths=["<тронутые-файлы>"])
```

В Claude Code с активным hook'ом — пропусти, hook это делает за тебя.

---

## Шаг 2 — impact analysis (обязательно)

```
doubled-graph.impact(
  target="<имя-функции / класса / путь к файлу>",
  direction="upstream",
  depth=3
)
```

Если символ неоднозначен — в `warnings[]` появится запись с `code: "INVALID_INPUT"` и списком кандидатов в `detail`. Покажи их пользователю, попроси уточнить, повтори вызов с уточнённым `target` (например, `module.fn` или путь к файлу).

Возвращается JSON со структурой:

- `risk.level` — `NONE` / `LOW` / `MEDIUM` / `HIGH` / `CRITICAL`
- `risk.reasons` — список причин классификации
- `direct` / `transitive` — callers по уровням depth
- `affected_modules` — список `M-*` ID, которые затронуты
- `affected_verification` — список `V-M-*` тестов, которые могут упасть
- `target_resolved.module_id` — `M-*` ID самого правимого символа

---

## Шаг 3 — интерпретация risk.level

| risk.level | Действие |
|---|---|
| `NONE` / `LOW` | Продолжай правку без дополнительного подтверждения. |
| `MEDIUM` | Скажи пользователю отдельной строкой: «правлю X, затрагивает N прямых потребителей: [...]». Продолжай. |
| `HIGH` | **Останови.** Покажи `risk.reasons`. Жди явного «продолжай» от пользователя. |
| `CRITICAL` | **Останови.** Покажи `risk.reasons` + `affected_modules` + `affected_verification`. Предложи альтернативу: «могу ли я вместо этого сделать ...». Жди явного «продолжай». |

«Молча игнорировать HIGH/CRITICAL» — анти-паттерн. Пользователь должен видеть объяснение.

---

## Шаг 4 — режим и контракт

Прочитай `AGENTS.md`, ищи блок `<!-- doubled-graph:phase:start -->`.

**В `post_migration` (артефакты = ground-truth):**

1. Возьми `module_id` из `impact().target_resolved.module_id`.
2. Прочитай контракт модуля:
   ```
   doubled-graph.file_show(path="<file>", contracts=true)
   ```

   Возможные ответы:
   - `{"result": {"found": true, "module_contract": "...", "contracts": [...]}}` — есть, читай.
   - `{"result": {"found": false, "raw": {...}}}` — у файла нет якорей `MODULE_CONTRACT`. Это значит контракт ещё не зафиксирован — правишь свободнее, но запиши в `CHANGE_SUMMARY` что разметка появится в следующем коммите (или попроси пользователя инициировать planning-цикл).
   - `{"error": "GRACE_CLI_ERROR", ...}` — реально упал grace, разбирайся отдельно.

3. Если правка нарушает контракт (сигнатура публичного экспорта, pre/post/invariant) — это **новое требование**. **Останови.** Скажи пользователю: «Это contract change. По методологии перед правкой нужно (1) обновить требование UC-* / module M-* в `docs/*.xml`, (2) явно одобрить новый контракт. Запустить planning-цикл (см. `prompts/maintenance/` или provide ad-hoc — добавить `<UC-*>` и обновить `<M-...>` в development-plan.xml через Edit) — или откатиться на правку в рамках текущего контракта?»

**В `migration` (код = ground-truth):**

- Правки разрешены свободнее.
- После правки **обязательно** обнови `docs/*.xml` через `Edit` под новые экспорты/сигнатуру (см. `doubled-graph-after-edit` шаг 2).

Если `AGENTS.md` нет — default `post_migration`, предупреди пользователя.

---

## Шаг 5 — провести правку

- Используй Edit / Write (название инструмента зависит от IDE).
- **Сохрани якоря**: `START_CONTRACT: fnName` / `END_CONTRACT: fnName`, `START_BLOCK_*` / `END_BLOCK_*`, `MODULE_CONTRACT`, `MODULE_MAP`. Их синтаксис фиксирован — `doubled-graph.lint()` после правки вернёт `ok: false` со списком violations, если что-то сломано.
- Если в файле есть `START_CHANGE_SUMMARY` — добавь запись с датой ISO и кратким why (≤ 1 строка).

---

## Шаг 6 — переход на `doubled-graph-after-edit`

После сохранения файла активируй skill `doubled-graph-after-edit`. Без него правку нельзя коммитить.

---

## Anti-patterns

- Не правь без `impact`. Это базовый risk-gate всей методологии.
- Не игнорируй HIGH/CRITICAL «молча» — пользователь должен видеть `risk.reasons`.
- Не меняй `phase:` в `AGENTS.md` без явной просьбы пользователя.
- Не удаляй якоря при правке. `lint` упадёт после, и это не «можно поправить потом» — это блокирующий gate.
- Не утверждай «я починил всех вызывающих» без явного `detect_changes` или повторного `impact` после.

---

## Шпаргалка (<1 KB для локальных моделей)

```
BEFORE-EDIT (всё через MCP):
1. doubled-graph.analyze(mode="incremental", paths=[touched]) if no PostToolUse hook
2. doubled-graph.impact(target=X, direction="upstream", depth=3)
3. risk HIGH/CRITICAL -> STOP, ask user
4. read AGENTS.md phase:
   - post_migration: doubled-graph.file_show(path=F, contracts=true) -> do not break contract
                     contract change -> STOP, ask user for planning cycle
   - migration: free edit, must Edit docs/*.xml after (knowledge-graph + plan)
5. edit (keep anchors intact, update CHANGE_SUMMARY)
6. goto doubled-graph-after-edit
```

---

## Если инструмент недоступен

- **MCP `doubled-graph` не зарегистрирован** (degraded mode): fallback в Bash — `doubled-graph impact <X> --direction upstream --depth 3`, `doubled-graph file show <file> --contracts`. Эквивалентный результат, медленнее.
- **`doubled-graph.impact` упал**: предупреди пользователя «impact-анализ недоступен, оцениваю риск приближённо», сделай `grep` вызовов руками, классифицируй risk консервативно (default = `MEDIUM`).
- **`doubled-graph.file_show` недоступен** (`grace` CLI не установлен): прочитай файл напрямую через Read, найди `MODULE_CONTRACT` / `CONTRACT` блоки руками.
- **`AGENTS.md` нет**: default `post_migration`, предупреди пользователя.
