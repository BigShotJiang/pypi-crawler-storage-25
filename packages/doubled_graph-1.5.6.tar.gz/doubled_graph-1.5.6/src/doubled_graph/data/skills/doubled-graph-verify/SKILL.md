---
name: doubled-graph-verify
description: "Use when a module M-* is missing a V-M-* verification entry, when detect_changes returns missing_verification drift, or when the user asks to add tests for a specific module. Drafts a V-M-* record + minimal test scaffold proportional to module criticality. Triggers: add tests for M-X, missing verification, write tests, V-M missing."
---

# doubled-graph — добавить verification (V-M-*) для модуля

**Триггер:**
- `doubled-graph.detect_changes()` вернул `missing_verification` на каком-то модуле;
- пользователь сказал «добавь тесты для `M-X`»;
- `doubled-graph.health` показал `modules.without_verification` непустой.

**Цель:** для каждого `M-*` без покрытия — создать запись `V-M-*` в `verification-plan.xml` + минимальный test-файл, чтобы prematurely покрыть критический путь.

**Маршрут:** `module_show` берёт контракт, `impact` определяет critical-path, генерация теста — через `Edit` в новом файле; запись `<V-M-*>` — через `Edit` `verification-plan.xml`.

---

## Шаг 1 — получить контракт модуля

```
doubled-graph.module_show(target="<M-id>", with_verification=true)
```

Вернёт:
- `criticality` — `critical` / `standard` / `helper`;
- `purpose`, `pre`/`post`/`invariants`;
- `public_exports[]` — функции, которые надо покрыть;
- `existing_v_m[]` — что уже есть (если `with_verification=true`).

Если `CRITICALITY="helper"` и пользователь не настаивает — можно отложить: запиши в `docs/DRIFT.md` как «verification pending, low priority». Дальше шаг 7.

---

## Шаг 2 — определить scope теста по criticality

| criticality | Что обязательно покрыть |
|---|---|
| `critical` | каждый public export из `<annotations>`, все pre/post/invariant assertions, edge cases (null, empty, oversize), error paths |
| `standard` | каждый public export из `<annotations>` happy-path + один представительный error case |
| `helper` | smoke test (просто что вызывается без exception), 1 happy-path |

---

## Шаг 3 — найти test framework проекта

Прочитай `AGENTS.md` или `docs/technology.xml` — там объявлен test framework (`pytest` / `jest` / `vitest` / `go test` / etc).
Если не объявлен — посмотри `package.json` / `pyproject.toml` / `Cargo.toml` через Read.
Если ничего — спроси пользователя.

---

## Шаг 4 — определить путь к новому тесту

Конвенция: `tests/test_<module-slug>.py` (Python), `__tests__/<module>.test.ts` (JS), и т.п. Спроси пользователя, если в проекте уже существует другой паттерн.

---

## Шаг 5 — сгенерировать test stub

Через `Edit` (новый файл). Для `critical` модуля — сразу полный набор кейсов; для остальных — happy-path как минимум.

Пример для Python / pytest:

```python
# tests/test_auth_validate.py
# START_MODULE_CONTRACT
# purpose: tests for M-AUTH-VALIDATE.validateUser
# links: M-AUTH-VALIDATE
# END_MODULE_CONTRACT

import pytest
from src.auth.validate import validateUser


# V-M-AUTH-1: happy path
def test_validate_user_returns_user_on_valid_token():
    user = validateUser({"token": "valid-token"})
    assert user is not None
    assert user.id


# V-M-AUTH-2: invalid token returns null
def test_validate_user_returns_null_on_invalid_token():
    assert validateUser({"token": "bad-token"}) is None


# V-M-AUTH-3: pre-condition: missing token raises
def test_validate_user_raises_on_missing_token():
    with pytest.raises(KeyError):
        validateUser({})
```

Каждый тест связан с конкретным `V-M-*` через комментарий — это даст traceability в `detect_changes`.

---

## Шаг 6 — добавить `<V-M-*>` записи в `verification-plan.xml`

Через `Edit` `docs/verification-plan.xml`:

```xml
<V-M-AUTH MODULE="M-AUTH-VALIDATE" PRIORITY="high">
  <Description>happy path: valid token returns user</Description>
  <Command>pytest tests/test_auth_validate.py::test_validate_user_returns_user_on_valid_token</Command>
  <Asserts>returns User object with id</Asserts>
</V-M-AUTH>

<V-M-AUTH MODULE="M-AUTH-VALIDATE" PRIORITY="high">
  <Description>invalid token returns null</Description>
  <Command>pytest tests/test_auth_validate.py::test_validate_user_returns_null_on_invalid_token</Command>
  <Asserts>returns None</Asserts>
</V-M-AUTH>

<V-M-AUTH MODULE="M-AUTH-VALIDATE" PRIORITY="high">
  <Description>missing token raises KeyError (pre-condition)</Description>
  <Command>pytest tests/test_auth_validate.py::test_validate_user_raises_on_missing_token</Command>
  <Asserts>raises KeyError</Asserts>
</V-M-AUTH>
```

`<Command>` должна быть исполняемой строкой — `doubled-graph-after-edit` шаг 5 использует её для прогона.

---

## Шаг 7 — прогон тестов

Через Bash:

```bash
pytest tests/test_auth_validate.py -v
```

Все упали → проверь импорты, моки, фикстуры. Не коммить с красными тестами.
Все зелёные → продолжай.

---

## Шаг 8 — финальные проверки

```
doubled-graph.lint()                    # ID-ссылки V-M-* → M-* проверены
doubled-graph.detect_changes(scope="staged")  # missing_verification должен исчезнуть для этого модуля
```

Если `missing_verification` всё ещё есть для того же `M-*` — посмотри какой именно public export из `<annotations>` ещё не покрыт. Это твой следующий тест.

---

## Шаг 9 — коммит

```
test: add V-M-AUTH-1..3 for M-AUTH-VALIDATE

Affected: M-AUTH-VALIDATE
LINKS: UC-001 (если applicable)
```

---

## Anti-patterns

- Не пиши тест без `<V-M-*>` записи — `lint` упадёт на orphan-test или `detect_changes` найдёт `missing_verification`.
- Не делай тест, который читает internal state модуля — тесты на контракт (publicExports), не на implementation.
- Не «генерируй» тесты для всех модулей сразу автоматически — каждый должен быть осмысленным, лучше N качественных, чем 100 шаблонных.
- Не пропускай `CRITICALITY="critical"` без всех edge-case покрытий — это будущий баг в production.

---

## Шпаргалка

```
VERIFY (add V-M-* for module):
1. doubled-graph.module_show(target=<M-id>, with_verification=true)
2. choose scope by criticality (critical=full / standard=happy+error / helper=smoke)
3. read test framework from AGENTS.md / docs/technology.xml
4. choose test path by project convention (or ask)
5. Edit new test file with V-M-* comments per test
6. Edit docs/verification-plan.xml — add <V-M-*> records with <Command>
7. run tests via Bash
8. doubled-graph.lint() + .detect_changes() — missing_verification must clear
9. git commit "test: add V-M-* for M-X"
```
