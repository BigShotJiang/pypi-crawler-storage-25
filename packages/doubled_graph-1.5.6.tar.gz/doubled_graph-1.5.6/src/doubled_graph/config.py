"""Configuration loading for `.doubled-graph/config.{json,yaml}`."""

from __future__ import annotations

import json
from fnmatch import fnmatch
from pathlib import Path

from pydantic import BaseModel, Field


class CGCConfig(BaseModel):
    backend: str = "auto"
    backend_overrides: dict[str, str] = Field(default_factory=dict)


class ScanConfig(BaseModel):
    exclude: list[str] = Field(default_factory=list)


class Config(BaseModel):
    model_config = {"extra": "ignore"}

    version: str = "1"
    cgc: CGCConfig = Field(default_factory=CGCConfig)
    scan: ScanConfig = Field(default_factory=ScanConfig)
    grace_cli_command: str = "grace"
    phase_source: str = "AGENTS.md"
    phase_default: str = "post_migration"


def _config_candidates(repo_path: Path) -> list[Path]:
    base = repo_path / ".doubled-graph"
    return [base / "config.yaml", base / "config.yml", base / "config.json"]


def config_path(repo_path: Path) -> Path:
    for p in _config_candidates(repo_path):
        if p.exists():
            return p
    return repo_path / ".doubled-graph" / "config.json"


def _load_yaml(p: Path) -> dict:
    try:
        import yaml  # type: ignore[import-untyped]
    except ModuleNotFoundError:
        import json as _json

        with p.open("r", encoding="utf-8") as f:
            return _json.load(f)
    with p.open("r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


def load_config(repo_path: Path) -> Config:
    """Load config or return defaults if missing."""
    p = config_path(repo_path)
    if not p.exists():
        return Config()
    if p.suffix in (".yaml", ".yml"):
        data = _load_yaml(p)
    else:
        with p.open("r", encoding="utf-8") as f:
            data = json.load(f)
    return Config(**data)


def is_excluded(file_rel: str, exclude: list[str]) -> bool:
    """Check if *file_rel* matches any exclude pattern.

    Patterns ending with ``/`` match directory prefixes (``research/``
    matches ``research/scripts/foo.py``).  Other patterns use fnmatch
    against the full relative path.
    """
    for pat in exclude:
        if pat.endswith("/"):
            if file_rel.startswith(pat) or file_rel.startswith(pat.rstrip("/")):
                return True
        elif fnmatch(file_rel, pat):
            return True
    return False


def save_config(repo_path: Path, cfg: Config) -> None:
    p = config_path(repo_path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("w", encoding="utf-8") as f:
        json.dump(cfg.model_dump(), f, indent=2)
