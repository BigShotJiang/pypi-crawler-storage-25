"""MCP server — registers the four tools and serves them over stdio.

Notes on MCP-SDK usage:

The `mcp` Python package (Anthropic) provides a low-level stdio server.
This file targets the public API shape as of the 0.9.x line (April 2026).
If the SDK API surface drifts, the wiring is localized here — tools/* stay
unchanged.

If `mcp` is not installed, `run_stdio` raises a clear error. That's
intentional: without a transport, there's no useful MCP server to start.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from doubled_graph.tools.analyze import analyze as tool_analyze
from doubled_graph.tools.context import context as tool_context
from doubled_graph.tools.detect_changes import detect_changes as tool_detect_changes
from doubled_graph.tools.impact import impact as tool_impact


TOOL_DEFINITIONS: list[dict[str, Any]] = [
    # -------- Doubled-graph native tools (act on computed × declared graphs) --------
    {
        "name": "analyze",
        "description": "Build or incrementally update the computed code graph (CGC). Returns stats and warnings. See TOOLS.md §1.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "mode": {"type": "string", "enum": ["auto", "full", "incremental"], "default": "auto"},
                "since_ref": {"type": ["string", "null"], "default": None},
                "paths": {"type": ["array", "null"], "items": {"type": "string"}, "default": None},
                "force": {"type": "boolean", "default": False},
            },
        },
    },
    {
        "name": "impact",
        "description": "Blast-radius analysis for a symbol. MUST be called before editing. See TOOLS.md §2.",
        "inputSchema": {
            "type": "object",
            "required": ["target"],
            "properties": {
                "target": {"type": "string"},
                "direction": {"type": "string", "enum": ["upstream", "downstream", "both"], "default": "upstream"},
                "depth": {"type": "integer", "default": 3, "minimum": 1, "maximum": 10},
                "include_tests": {"type": "boolean", "default": True},
                "scope": {"type": "string", "enum": ["full", "module", "file"], "default": "full"},
            },
        },
    },
    {
        "name": "context",
        "description": "360° view on a symbol (computed+declared+source). See TOOLS.md §3.",
        "inputSchema": {
            "type": "object",
            "required": ["name"],
            "properties": {
                "name": {"type": "string"},
                "depth_callers": {"type": "integer", "default": 2, "minimum": 0, "maximum": 5},
                "depth_callees": {"type": "integer", "default": 2, "minimum": 0, "maximum": 5},
            },
        },
    },
    {
        "name": "detect_changes",
        "description": "Detect drift between computed (CGC) and declared (docs/*.xml) graphs. See TOOLS.md §4.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "scope": {"type": "string", "enum": ["staged", "branch", "all", "compare"], "default": "staged"},
                "base_ref": {"type": "string", "default": "main"},
                "since_ref": {"type": "string", "default": "HEAD~1"},
                "include_unchanged": {"type": "boolean", "default": False},
            },
        },
    },
    # Artifact validation and navigation — thin wrappers over underlying tooling.
    {
        "name": "lint",
        "description": "Validate doubled-graph artifacts: anchor pairing, block uniqueness within file, reference integrity UC-* → M-* → V-M-*.",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "module_show",
        "description": "Return a module record: contract (pre/post/invariants), public exports, dependencies; optionally its V-M-* verification entries.",
        "inputSchema": {
            "type": "object",
            "required": ["target"],
            "properties": {
                "target": {"type": "string"},
                "with_verification": {"type": "boolean", "default": False},
            },
        },
    },
    {
        "name": "module_find",
        "description": "Resolve a module by id, name, path substring or annotation. Returns the matching M-* record(s).",
        "inputSchema": {
            "type": "object",
            "required": ["query"],
            "properties": {"query": {"type": "string"}},
        },
    },
    {
        "name": "file_show",
        "description": "Extract MODULE_CONTRACT / CONTRACT:fn / BLOCK_* / CHANGE_SUMMARY sections from a file — the anchor-framed slice, not the whole file. Use this instead of reading the full file when only the contract/blocks are needed.",
        "inputSchema": {
            "type": "object",
            "required": ["path"],
            "properties": {
                "path": {"type": "string"},
                "contracts": {"type": "boolean", "default": True},
                "blocks": {"type": "boolean", "default": True},
            },
        },
    },
    # Read-only health report. Real native impl, not a delegation directive
    # (CHANGELOG 1.4.0 dropped the gateway pattern). Combos: declared graph
    # counts + detect_changes + open DRIFT.md entries. Intended for CI.
    {
        "name": "health",
        "description": "Project health report: total modules, modules without V-M-* coverage, drift count by type, open DRIFT.md entries. Read-only, no side effects.",
        "inputSchema": {"type": "object", "properties": {}},
    },
]


def _dispatch(tool_name: str, args: dict[str, Any], repo_path: Path) -> dict[str, Any]:
    """Route an MCP tool call to the right implementation.

    Why this function exists: MCP server.py is transport-only — all business
    logic lives in tools/* and integrations/*. Dispatch keeps that separation
    explicit and makes it trivial to add new gateway wrappers.
    """
    if tool_name == "analyze":
        return tool_analyze(repo_path=repo_path, **args).model_dump(mode="json")
    if tool_name == "impact":
        return tool_impact(repo_path=repo_path, **args).model_dump(mode="json")
    if tool_name == "context":
        return tool_context(
            repo_path=repo_path,
            name=args.get("name", ""),
            depth_callers=int(args.get("depth_callers", 2)),
            depth_callees=int(args.get("depth_callees", 2)),
        ).model_dump(mode="json")
    if tool_name == "detect_changes":
        return tool_detect_changes(
            repo_path=repo_path,
            scope=args.get("scope", "staged"),
            base_ref=args.get("base_ref", "main"),
            since_ref=args.get("since_ref", "HEAD~1"),
            include_unchanged=bool(args.get("include_unchanged", False)),
        ).model_dump(mode="json")

    # Gateway wrappers — lazy-import grace_cli so the MCP server doesn't fail
    # to start just because grace CLI isn't on PATH yet.
    if tool_name in ("lint", "module_show", "module_find", "file_show"):
        from doubled_graph.integrations.grace_cli import GraceCLI, GraceCLIMissing

        try:
            cli = GraceCLI(repo_path)
            if tool_name == "lint":
                return {"result": cli.lint()}
            if tool_name == "module_show":
                rec = cli.module_show(args["target"], with_verification=bool(args.get("with_verification")))
                return {"result": rec.__dict__}
            if tool_name == "module_find":
                # Uses the public module_find method (1.4.3) so MCP and CLI
                # share the same JSON-with-fallback path; previously inlined
                # `_run` here, which bypassed that consolidation.
                return {"result": cli.module_find(args["query"])}
            if tool_name == "file_show":
                rec = cli.file_show(
                    args["path"],
                    contracts=bool(args.get("contracts", True)),
                    blocks=bool(args.get("blocks", True)),
                )
                return {"result": rec.__dict__}
        except GraceCLIMissing as e:
            return {"error": "GRACE_CLI_MISSING", "detail": str(e)}
        except Exception as e:  # noqa: BLE001 — surface as structured error
            return {"error": "GRACE_CLI_ERROR", "detail": str(e)}

    # Real native health report (CHANGELOG 1.4.0): combos detect_changes
    # + declared module/V-M-* coverage + open DRIFT.md entries. Replaces the
    # old `grace-status` skill gateway with actual data.
    if tool_name == "health":
        from doubled_graph.graphs.declared import load_declared_graph
        from doubled_graph.integrations.cgc import CGC
        from doubled_graph.policy.phase import read_phase

        declared = load_declared_graph(repo_path)
        verified_module_ids = {
            v.module_id for v in declared.verification.values() if v.module_id
        }
        modules_without_verification = sorted(
            mid for mid in declared.modules if mid not in verified_module_ids
        )
        try:
            drift_result = tool_detect_changes(repo_path=repo_path, scope="all")
            drift_by_type = {
                "code_without_module": len(drift_result.drift.code_without_module),
                "module_without_code": len(drift_result.drift.module_without_code),
                "stale_crosslinks": len(drift_result.drift.stale_crosslinks),
                "missing_verification": len(drift_result.drift.missing_verification),
                "markup_missing": len(drift_result.drift.markup_missing),
            }
            drift_count = sum(drift_by_type.values())
        except Exception as e:  # noqa: BLE001
            drift_count = -1
            drift_by_type = {"_error": str(e)}

        drift_md = repo_path / "docs" / "DRIFT.md"
        open_drift_entries = 0
        if drift_md.exists():
            text = drift_md.read_text(encoding="utf-8")
            sections = [s for s in text.split("\n## D-") if s.strip()]
            open_drift_entries = sum(
                1 for s in sections if "Resolved" not in s and "resolved" not in s
            )

        cgc_diag = CGC(repo_path).check_parser()

        return {
            "phase": read_phase(repo_path),
            "cgc": {"ok": cgc_diag is None, "diagnostic": cgc_diag},
            "modules": {
                "total": len(declared.modules),
                "verified": len(verified_module_ids & set(declared.modules.keys())),
                "without_verification": modules_without_verification,
            },
            "verification": {"total_v_m_records": len(declared.verification)},
            "drift": {"total": drift_count, "by_type": drift_by_type},
            "drift_md": {"open_entries": open_drift_entries},
            "ok": (
                cgc_diag is None
                and drift_count == 0
                and open_drift_entries == 0
                and not modules_without_verification
            ),
        }

    return {"error": "UNKNOWN_TOOL", "tool": tool_name}


def _check_runtime_deps() -> None:
    """Fail fast on startup if `codegraphcontext` can't be imported.

    Without this, the server starts cleanly and only fails on the first
    `analyze`/`impact`/`context`/`detect_changes` call — deep inside a
    tool, with a bare `No module named 'codegraphcontext'` that surfaces
    in the IDE log without any hint at the cause. The most frequent cause
    is the IDE launching doubled-graph from a Python that doesn't have
    the doubled-graph deps (e.g. when `command: "doubled-graph"` resolved
    to a different shim than the pipx one). Up-front check turns the
    silent runtime failure into an actionable startup error.
    """
    try:
        from codegraphcontext.core import get_database_manager  # noqa: F401
        from codegraphcontext.tools.code_finder import CodeFinder  # noqa: F401
        from codegraphcontext.tools.graph_builder import GraphBuilder  # noqa: F401
    except ModuleNotFoundError as e:
        raise RuntimeError(
            f"doubled-graph: backend `codegraphcontext` is not importable "
            f"in this environment (missing module: {e.name}). Likely the IDE "
            f"is launching doubled-graph from a different Python than the one "
            f"it was installed into, or the install is broken. Fix:\n"
            f"  1. pipx reinstall doubled-graph\n"
            f"  2. doubled-graph setup    # in your repo, regenerates .mcp.json\n"
            f"     with an absolute Python path that doesn't depend on PATH."
        ) from e


def run_stdio(repo_path: Path | None = None) -> None:
    """Start the MCP server. Blocks until stdin closes."""
    _check_runtime_deps()
    repo = (repo_path or Path.cwd()).resolve()

    try:
        # Lazy import — keeps unit tests runnable without the full MCP SDK.
        from mcp.server import Server  # type: ignore
        from mcp.server.stdio import stdio_server  # type: ignore
        from mcp.types import Tool, TextContent  # type: ignore
    except ImportError as e:  # pragma: no cover
        raise RuntimeError(
            "mcp package not available. Install via `pip install mcp` (>=0.9)."
        ) from e

    server = Server("doubled-graph")

    @server.list_tools()  # type: ignore[misc]
    async def _list_tools() -> list[Tool]:
        return [
            Tool(name=t["name"], description=t["description"], inputSchema=t["inputSchema"])
            for t in TOOL_DEFINITIONS
        ]

    @server.call_tool()  # type: ignore[misc]
    async def _call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
        result = _dispatch(name, arguments or {}, repo)
        return [TextContent(type="text", text=json.dumps(result, indent=2, default=str))]

    import anyio

    async def _main() -> None:
        async with stdio_server() as (read_stream, write_stream):
            await server.run(read_stream, write_stream, server.create_initialization_options())

    anyio.run(_main)
