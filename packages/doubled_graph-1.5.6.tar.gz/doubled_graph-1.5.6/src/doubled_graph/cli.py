"""Minimal CLI dispatcher — wraps MCP server + utility subcommands.

Why this CLI exists:
  doubled-graph is the single gateway between the methodology and its two
  underlying tools (CodeGraphContext and grace-marketplace CLI). Every user
  or agent interaction goes through `doubled-graph <subcommand>`. The CLI
  never contains business logic — it just dispatches into tools/ or
  integrations/.

Subcommand groups:
  Direct-action (our tool):
    - serve            : start MCP server (stdio JSON-RPC)
    - analyze          : build/refresh computed graph (wraps CGC library)
    - init-hooks       : install git + Claude Code hooks
    - status           : print config, phase, index freshness
    - phase            : read or switch phase (migration <-> post_migration)

  Wrappers over `grace` CLI (upstream, Bun) — methodology talks to these
  through doubled-graph so the user never sees two tool names:
    - lint             : grace lint
    - module show/find : grace module show / find
    - file show        : grace file show

  Stubs (returning NOT_IMPLEMENTED_MVP until Phase 5 follow-up):
    - impact, context, detect-changes
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any


def _cmd_serve(_args: argparse.Namespace) -> int:
    """Start the MCP server on stdio."""
    from doubled_graph.server import run_stdio

    run_stdio()
    return 0


def _cmd_analyze(args: argparse.Namespace) -> int:
    from doubled_graph.tools.analyze import analyze

    repo = Path(args.repo or ".").resolve()
    result = analyze(
        repo_path=repo,
        mode=args.mode,
        since_ref=args.since_ref,
        paths=args.paths,
        force=args.force,
    )
    if not args.silent:
        print(json.dumps(result.model_dump(), indent=2, default=str))
    return 0


def _cmd_init_hooks(args: argparse.Namespace) -> int:
    from doubled_graph.hooks_installer import ensure_gitignore_entries, install_hooks

    repo = Path(args.repo or ".").resolve()
    report = install_hooks(
        repo_path=repo,
        post_commit=args.post_commit or args.all,
        claude_code=args.claude_code or args.all,
        prepare_commit_msg=args.prepare_commit_msg,
        dry_run=args.dry_run,
    )
    # Update .gitignore separately — same operation `doubled-graph setup`
    # runs at step 5. Decoupled from `install_hooks` since 1.3.1 so users
    # who go through `setup --skip-hooks` still get a clean .gitignore.
    report["gitignore"] = ensure_gitignore_entries(repo, dry_run=args.dry_run)
    print(json.dumps(report, indent=2))
    return 0


def _cmd_status(args: argparse.Namespace) -> int:
    """Summary of repo state: active config + current phase.

    Used by CI and by agents at session start to verify the gateway sees the
    repo correctly before any destructive action.
    """
    from doubled_graph.config import load_config
    from doubled_graph.policy.phase import read_phase

    repo = Path(args.repo or ".").resolve()
    cfg = load_config(repo)
    phase = read_phase(repo)
    print(json.dumps({"config": cfg.model_dump(), "phase": phase}, indent=2, default=str))
    return 0


# ---------------------------------------------------------------------------
# Wrappers over `grace` CLI (upstream Bun tool). Kept thin — we do NOT
# interpret output here, just forward. Methodology references these names
# (`doubled-graph lint`, `doubled-graph module show`, …) so users and agents
# have a single entry point. If the upstream grace CLI signature changes, the
# change is localized in `integrations/grace_cli.py`.
# ---------------------------------------------------------------------------


def _grace_cli_call(repo: Path, fn_name: str, *args, **kwargs) -> tuple[Any, int]:
    """Run a GraceCLI method with unified error→JSON conversion.

    Why this helper exists (1.4.3): every grace-wrapper CLI handler had the
    same try/except boilerplate that ONLY caught `GraceCLIMissing`. Any
    `RuntimeError` from `_run` (rc != 0 from grace itself) escaped and
    surfaced as a Python traceback to the user — ugly, unactionable, and
    inconsistent with the GRACE_CLI_MISSING JSON-error contract.

    Returns (json_payload, exit_code). Caller prints the payload to the
    appropriate stream (stderr for errors, stdout for success) and returns
    the exit code.
    """
    from doubled_graph.integrations.grace_cli import GraceCLI, GraceCLIMissing

    try:
        method = getattr(GraceCLI(repo), fn_name)
        result = method(*args, **kwargs)
        return result, 0
    except GraceCLIMissing as e:
        return ({"error": "GRACE_CLI_MISSING", "detail": str(e)}, 3)
    except RuntimeError as e:
        # `_run` raises RuntimeError with rc + stdout + stderr embedded in
        # the message. Surface it as structured JSON so the agent (or CI
        # reading exit code + JSON) gets actionable info.
        return ({"error": "GRACE_CLI_ERROR", "detail": str(e)}, 4)


def _cmd_lint(args: argparse.Namespace) -> int:
    """`grace lint` gateway — validates anchor pairing, block uniqueness, cross-refs.

    Methodology invariant: this gate runs before commit and in CI. Exposing it
    via our CLI keeps the methodology tool-name-consistent (one namespace).

    Exit codes (1.4.3):
      0 — lint clean (no findings)
      1 — lint found violations (`ok: false` in JSON; CI should fail)
      3 — GRACE_CLI_MISSING (grace not installed / not runnable)
      4 — GRACE_CLI_ERROR (grace tool itself crashed, rc≥2)
    Treating "lint findings" as non-zero exit lets `doubled-graph lint` work
    as a pre-commit / CI gate without an extra wrapper script.
    """
    # `--path` is an alias for `--repo` (upstream `grace lint --path .` uses
    # the same semantic — we accept both so hand-typed invocations from docs
    # work without rewording).
    repo = Path(args.path or args.repo or ".").resolve()
    payload, rc = _grace_cli_call(repo, "lint", verbose=bool(args.verbose))
    if rc != 0:
        print(json.dumps(payload, indent=2, ensure_ascii=False), file=sys.stderr)
        return rc
    print(json.dumps(payload, indent=2, ensure_ascii=False))
    # Lint findings (rc=1 from grace) are now in payload as `ok: false` /
    # `exit_code: 1`. Propagate as exit 1 so CI gates work.
    return 0 if payload.get("ok", True) else 1


def _cmd_module_show(args: argparse.Namespace) -> int:
    """`grace module show <id|path>` gateway — module record with optional verification.

    Agents use this to read MODULE_CONTRACT + dependencies + (opt) V-M-* before
    edits. Single entry via doubled-graph avoids agents drifting between tool
    names across prompts.

    Exit codes (1.4.4): 0 found / 1 not found / 3 GRACE_CLI_MISSING /
    4 GRACE_CLI_ERROR. "Not found" exits 1 so shell users can branch on it
    without parsing JSON; the JSON payload still carries `found: false` for
    agents.
    """
    repo = Path(args.repo or ".").resolve()
    payload, rc = _grace_cli_call(
        repo, "module_show", args.target, with_verification=args.with_verification
    )
    if rc != 0:
        print(json.dumps(payload, indent=2, ensure_ascii=False), file=sys.stderr)
        return rc
    # Returned object is a ModuleRecord dataclass — surface its dict.
    print(json.dumps(payload.__dict__, indent=2, ensure_ascii=False, default=str))
    return 0 if getattr(payload, "found", True) else 1


def _cmd_module_find(args: argparse.Namespace) -> int:
    """`grace module find <query>` gateway — search modules by id/name/path/annotation.

    Useful for the migration `03-draft-plan` and maintenance `on-drift-detected`
    flows where agent needs to resolve "which M-* does this file belong to".

    Exit code (1.4.4): 0 if matches found, 1 if no matches. Same shell-gate
    semantics as `lint` and `module show`.
    """
    repo = Path(args.repo or ".").resolve()
    payload, rc = _grace_cli_call(repo, "module_find", args.query)
    if rc != 0:
        print(json.dumps(payload, indent=2, ensure_ascii=False), file=sys.stderr)
        return rc
    print(json.dumps(payload, indent=2, ensure_ascii=False))
    return 0 if payload.get("found", True) else 1


def _cmd_file_show(args: argparse.Namespace) -> int:
    """`grace file show <path>` gateway — MODULE_CONTRACT/MAP/CHANGE_SUMMARY extractor.

    Used by `on-before-edit` and `grace-fix`-style flows to read only the
    relevant contract+blocks instead of loading whole files into the LLM
    context (important for local models with short context windows).

    Exit code (1.4.4): 0 if file/anchors found, 1 if not (file missing or
    no anchors).
    """
    repo = Path(args.repo or ".").resolve()
    payload, rc = _grace_cli_call(
        repo, "file_show", args.path, contracts=args.contracts, blocks=args.blocks
    )
    if rc != 0:
        print(json.dumps(payload, indent=2, ensure_ascii=False), file=sys.stderr)
        return rc
    print(json.dumps(payload.__dict__, indent=2, ensure_ascii=False, default=str))
    return 0 if getattr(payload, "found", True) else 1


def _cmd_health(args: argparse.Namespace) -> int:
    """Read-only project health report — combo of declared graph counts +
    detect_changes drift + open DRIFT.md entries.

    Real native implementation, not a delegation directive. Designed for CI:
    a single subcommand that fails (exit 1) when any health metric crosses
    a threshold (drift_count > 0 or unresolved DRIFT.md entries > 0).
    """
    from doubled_graph.graphs.declared import load_declared_graph
    from doubled_graph.policy.phase import read_phase
    from doubled_graph.tools.detect_changes import detect_changes

    repo = Path(args.repo or ".").resolve()
    declared = load_declared_graph(repo)

    # Module → V-M-* coverage map: which modules have at least one verification
    # entry attached. Modules without any are surfaced as a coverage gap.
    verified_module_ids = {v.module_id for v in declared.verification.values() if v.module_id}
    modules_without_verification = sorted(
        mid for mid in declared.modules if mid not in verified_module_ids
    )

    # Drift count via the same machinery agents use — single source of truth.
    # Drift items are grouped by type inside .drift; we surface counts per type.
    try:
        drift_result = detect_changes(repo_path=repo, scope="all")
        drift_by_type = {
            "code_without_module": len(drift_result.drift.code_without_module),
            "module_without_code": len(drift_result.drift.module_without_code),
            "stale_crosslinks": len(drift_result.drift.stale_crosslinks),
            "missing_verification": len(drift_result.drift.missing_verification),
            "markup_missing": len(drift_result.drift.markup_missing),
        }
        drift_count = sum(drift_by_type.values())
    except Exception as e:  # noqa: BLE001 — degrade gracefully, surface as warning
        drift_count = -1
        drift_by_type = {"_error": str(e)}

    # Unresolved DRIFT.md entries: line count of `## D-*` headers that lack a
    # `**Resolved:**` line. Cheap parse, no XML.
    drift_md = repo / "docs" / "DRIFT.md"
    open_drift_entries = 0
    if drift_md.exists():
        text = drift_md.read_text(encoding="utf-8")
        # Sections separated by `## D-`; resolved if section contains "Resolved"
        sections = [s for s in text.split("\n## D-") if s.strip()]
        open_drift_entries = sum(1 for s in sections if "Resolved" not in s and "resolved" not in s)

    # CGC parser sanity check — surface "tree-sitter broken" early
    # instead of letting analyze silently return 0 symbols.
    from doubled_graph.integrations.cgc import CGC
    cgc_diag = CGC(repo).check_parser()

    report = {
        "repo": str(repo),
        "phase": read_phase(repo),
        "cgc": {
            "ok": cgc_diag is None,
            "diagnostic": cgc_diag,
        },
        "modules": {
            "total": len(declared.modules),
            "verified": len(verified_module_ids & set(declared.modules.keys())),
            "without_verification": modules_without_verification,
        },
        "verification": {
            "total_v_m_records": len(declared.verification),
        },
        "drift": {
            "total": drift_count,
            "by_type": drift_by_type,
        },
        "drift_md": {
            "open_entries": open_drift_entries,
            "path": str(drift_md.relative_to(repo)) if drift_md.exists() else None,
        },
        "ok": (
            cgc_diag is None
            and drift_count == 0
            and open_drift_entries == 0
            and not modules_without_verification
        ),
    }
    print(json.dumps(report, indent=2, ensure_ascii=False))
    return 0 if report["ok"] else 1


def _cmd_phase(args: argparse.Namespace) -> int:
    """Read or set the repo phase (migration <-> post_migration).

    Why here and not a separate tool: phase is the root policy switch of the
    methodology — agents must read it before every drift decision. The phase
    lives as a block in AGENTS.md (not a secondary file) so it's visible at
    PR-review time; this subcommand is the single writer, avoiding hand-edits.
    """
    from doubled_graph.policy.phase import read_phase, set_phase

    repo = Path(args.repo or ".").resolve()
    if args.action == "get":
        print(read_phase(repo))
        return 0
    # `set` — atomic rewrite of AGENTS.md phase-block.
    result = set_phase(repo, args.value, reason=args.reason)
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 0


def _cmd_impact(args: argparse.Namespace) -> int:
    from doubled_graph.tools.impact import impact

    repo = Path(args.repo or ".").resolve()
    result = impact(
        repo_path=repo,
        target=args.target,
        direction=args.direction,
        depth=args.depth,
        include_tests=not args.no_tests,
        scope=args.scope,
    )
    print(json.dumps(result.model_dump(mode="json"), indent=2, ensure_ascii=False))
    return 0


def _cmd_context(args: argparse.Namespace) -> int:
    from doubled_graph.tools.context import context

    repo = Path(args.repo or ".").resolve()
    result = context(
        repo_path=repo,
        name=args.name,
        depth_callers=args.depth_callers,
        depth_callees=args.depth_callees,
    )
    print(json.dumps(result.model_dump(mode="json"), indent=2, ensure_ascii=False))
    return 0


def _cmd_detect_changes(args: argparse.Namespace) -> int:
    from doubled_graph.tools.detect_changes import detect_changes

    repo = Path(args.repo or ".").resolve()
    result = detect_changes(
        repo_path=repo,
        scope=args.scope,
        base_ref=args.base_ref,
        since_ref=args.since_ref,
    )
    print(json.dumps(result.model_dump(mode="json"), indent=2, ensure_ascii=False))
    return 0


def _cmd_kill_server(args: argparse.Namespace) -> int:
    """Kill any running `python -m doubled_graph serve` processes.

    Why this exists (1.4.2): IDE-spawned MCP servers are long-lived, and
    `pipx install --force` (or any reinstall) replaces the package on disk
    without touching the in-memory copy. Users run `pipx upgrade
    doubled-graph`, expect the new version to take effect immediately, and
    instead hit the same bug they were trying to fix until they manually
    figure out to restart their IDE. `doubled-graph kill-server` does the
    restart for them: SIGTERM the running server, IDE auto-respawns it
    with the fresh code on its next MCP call.

    Standard recipe before any uninstall/upgrade:
      doubled-graph kill-server
      pipx upgrade doubled-graph     # or: pipx install --force <wheel>

    `setup` runs this automatically as step 0; this command exists for
    explicit invocation in upgrade scripts and uninstall workflows.
    """
    from doubled_graph.setup import kill_running_mcp_servers

    report = kill_running_mcp_servers(dry_run=args.dry_run)
    print(json.dumps(report, indent=2, ensure_ascii=False))
    return 0 if report["status"] in ("killed", "no_running_servers", "dry_run") else 1


def _cmd_setup(args: argparse.Namespace) -> int:
    from doubled_graph.setup import run_setup

    repo = Path(args.repo or ".").resolve()
    report = run_setup(
        repo_path=repo,
        ide=args.ide,
        skip_grace_cli=args.skip_grace_cli,
        skip_hooks=args.skip_hooks,
        skip_analyze=args.skip_analyze,
        skip_skills=args.skip_skills,
        dry_run=args.dry_run,
    )
    print(json.dumps(report, indent=2, ensure_ascii=False))
    return 0 if report.get("ok") else 1


def main(argv_default: list[str] | None = None, argv: list[str] | None = None) -> int:
    """Entry point.

    - `argv` (explicit) overrides anything — used by tests.
    - `argv_default` is used only when no sys.argv was passed (e.g. `python -m doubled_graph`).
    """
    parser = argparse.ArgumentParser(prog="doubled-graph")
    sub = parser.add_subparsers(dest="command", required=True)

    p_serve = sub.add_parser("serve", help="Start MCP server on stdio")
    p_serve.set_defaults(func=_cmd_serve)

    p_an = sub.add_parser("analyze", help="One-shot analyze (hooks/CI)")
    p_an.add_argument("--repo", help="Repository path (default: cwd)")
    p_an.add_argument("--mode", choices=["auto", "full", "incremental"], default="auto")
    p_an.add_argument("--since-ref", default=None)
    p_an.add_argument("--paths", nargs="*", default=None)
    p_an.add_argument("--force", action="store_true")
    p_an.add_argument("--silent", action="store_true")
    p_an.set_defaults(func=_cmd_analyze)

    p_hooks = sub.add_parser("init-hooks", help="Install hooks")
    p_hooks.add_argument("--repo")
    p_hooks.add_argument("--all", action="store_true")
    p_hooks.add_argument("--post-commit", action="store_true")
    p_hooks.add_argument("--claude-code", action="store_true")
    p_hooks.add_argument("--prepare-commit-msg", action="store_true")
    p_hooks.add_argument("--dry-run", action="store_true")
    p_hooks.set_defaults(func=_cmd_init_hooks)

    p_status = sub.add_parser("status", help="Show config + phase + freshness")
    p_status.add_argument("--repo")
    p_status.set_defaults(func=_cmd_status)

    # Kill running MCP servers (before upgrade/uninstall). Standalone command
    # so users who hit the "stale in-memory MCP after pipx upgrade" trap can
    # fix it explicitly. `setup` also runs this automatically as step 0.
    p_kill = sub.add_parser(
        "kill-server",
        help="Kill any running `python -m doubled_graph serve` processes (IDE will respawn)",
    )
    p_kill.add_argument("--dry-run", action="store_true", help="report what would be killed")
    p_kill.set_defaults(func=_cmd_kill_server)

    # Gateway wrappers over `grace` CLI (upstream). Keeping these under our
    # namespace so methodology talks to a single tool.
    p_lint = sub.add_parser("lint", help="Validate anchors, block uniqueness, and UC/M/V-M references")
    p_lint.add_argument("--repo")
    p_lint.add_argument("--path", default=None, help="alias for --repo")
    p_lint.add_argument("--verbose", action="store_true")
    p_lint.set_defaults(func=_cmd_lint)

    p_mod = sub.add_parser("module", help="Module records: show / find")
    mod_sub = p_mod.add_subparsers(dest="module_cmd", required=True)
    p_mod_show = mod_sub.add_parser("show", help="Show module record (contract, exports, deps)")
    p_mod_show.add_argument("target")
    p_mod_show.add_argument("--with-verification", action="store_true")
    p_mod_show.add_argument("--repo")
    p_mod_show.set_defaults(func=_cmd_module_show)
    p_mod_find = mod_sub.add_parser("find", help="Resolve module by id/name/path/annotation")
    p_mod_find.add_argument("query")
    p_mod_find.add_argument("--repo")
    p_mod_find.set_defaults(func=_cmd_module_find)

    p_file = sub.add_parser("file", help="File-level records: show")
    file_sub = p_file.add_subparsers(dest="file_cmd", required=True)
    p_file_show = file_sub.add_parser("show", help="Extract MODULE_CONTRACT / CONTRACT:fn / BLOCK_* sections")
    p_file_show.add_argument("path")
    p_file_show.add_argument("--contracts", action="store_true")
    p_file_show.add_argument("--blocks", action="store_true")
    p_file_show.add_argument("--repo")
    p_file_show.set_defaults(func=_cmd_file_show)

    # Real read-only health report — combines detect_changes + module/V-M-* counts
    # + open DRIFT.md entries. NOT a gateway: actual work, real result. Use in CI
    # as a one-shot project-state check.
    p_health = sub.add_parser(
        "health",
        help="Project health report: artifact coverage, drift count, verification coverage, open DRIFT entries",
    )
    p_health.add_argument("--repo")
    p_health.set_defaults(func=_cmd_health)

    # Phase policy — single writer/reader of AGENTS.md phase-block.
    p_phase = sub.add_parser("phase", help="Read or set phase (migration | post_migration)")
    phase_sub = p_phase.add_subparsers(dest="action", required=True)
    p_phase_get = phase_sub.add_parser("get", help="Print current phase")
    p_phase_get.add_argument("--repo")
    p_phase_get.set_defaults(func=_cmd_phase)
    p_phase_set = phase_sub.add_parser("set", help="Set phase (atomic rewrite of AGENTS.md phase-block)")
    p_phase_set.add_argument("value", choices=["migration", "post_migration"])
    p_phase_set.add_argument("--reason", default="")
    p_phase_set.add_argument("--repo")
    p_phase_set.set_defaults(func=_cmd_phase)

    # Native graph tools — no longer stubs.
    p_impact = sub.add_parser("impact", help="Blast-radius analysis for a symbol")
    p_impact.add_argument("target")
    p_impact.add_argument(
        "--direction", choices=["upstream", "downstream", "both"], default="upstream"
    )
    p_impact.add_argument("--depth", type=int, default=3)
    p_impact.add_argument("--no-tests", action="store_true", help="exclude test files from dependents")
    p_impact.add_argument("--scope", choices=["full", "module", "file"], default="full")
    p_impact.add_argument("--repo")
    p_impact.set_defaults(func=_cmd_impact)

    p_ctx = sub.add_parser("context", help="360° view on a symbol (computed+declared+source)")
    p_ctx.add_argument("name")
    p_ctx.add_argument("--depth-callers", type=int, default=2, dest="depth_callers")
    p_ctx.add_argument("--depth-callees", type=int, default=2, dest="depth_callees")
    p_ctx.add_argument("--repo")
    p_ctx.set_defaults(func=_cmd_context)

    p_dc = sub.add_parser("detect-changes", help="Drift between computed and declared graphs")
    p_dc.add_argument(
        "--scope", choices=["staged", "branch", "all", "compare"], default="staged"
    )
    p_dc.add_argument("--base-ref", default="main", dest="base_ref")
    p_dc.add_argument("--since-ref", default="HEAD~1", dest="since_ref")
    p_dc.add_argument("--repo")
    p_dc.set_defaults(func=_cmd_detect_changes)

    # Onboarding — single-shot bootstrap for new users.
    p_setup = sub.add_parser(
        "setup",
        help="Onboard: install grace CLI, copy prompts, register MCP, install hooks, first analyze",
    )
    p_setup.add_argument("--repo", help="target repository (default: cwd)")
    p_setup.add_argument(
        "--ide",
        choices=["auto", "claude-code", "cursor", "continue", "none"],
        default="auto",
        help="which IDE's MCP config to write (auto-detected by default)",
    )
    p_setup.add_argument("--skip-grace-cli", action="store_true", help="don't try to `bun add -g`")
    p_setup.add_argument("--skip-hooks", action="store_true", help="don't install git post-commit hook")
    p_setup.add_argument("--skip-analyze", action="store_true", help="don't run first full analyze")
    p_setup.add_argument("--skip-skills", action="store_true", help="don't write per-IDE skill files")
    p_setup.add_argument("--dry-run", action="store_true", help="plan only; no fs/network changes")
    p_setup.set_defaults(func=_cmd_setup)

    if argv is not None:
        effective = argv
    elif argv_default is not None and len(sys.argv) == 1:
        effective = argv_default
    else:
        effective = None  # let argparse read sys.argv[1:]
    args = parser.parse_args(effective)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
