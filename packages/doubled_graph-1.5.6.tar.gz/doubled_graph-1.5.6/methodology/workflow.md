# Workflow doubled-graph

Три сценария, один скелет.

## Общий скелет

```
            ┌───────────────────────────────────────────────────┐
            │  requirements gather → docs/*.xml (агент через Edit) │
            │       ↓                                            │
            │  code + markup (агент по утверждённому плану)      │
            │       ↓                                            │
            │  verification: V-M-* записи + тесты                │
            │       ↓                                            │
            │  declared graph sync (Edit docs/*.xml) + analyze   │
            │       ↺ (loop on drift, см. drift-and-priority.md) │
            └───────────────────────────────────────────────────┘
```

Все три сценария проходят эти стадии. Различается только **входная точка** и **что считается ground-truth** на первом шаге.

Ground-truth по режимам (см. `drift-and-priority.md`):

- **Новый проект** — с 1-го шага режим `post_migration`: артефакты = ground-truth.
- **Миграция** — режим `migration`: код = ground-truth, артефакты догоняют.
- **Поддержка** — режим тот, который установлен в `AGENTS.md` (обычно `post_migration` после завершения миграции).

---

## Сценарий 1. Новый проект

Entry-prompt: `prompts/new-project/00-entry-prompt.md`. Вся последовательность исполняется агентом через свои `Read`/`Edit`/`Write`/`Bash` + наши MCP-tools (`analyze`, `impact`, `context`, `detect_changes`, `lint`, `module_show`, `file_show`, `health`).

1. **Intent-интервью** (человек ↔ ИИ). ИИ задаёт ~10 вопросов: продукт, аудитория, нефункциональные ограничения, стек-предпочтения. Глубина заполнения артефактов — всегда максимальная (см. `auto-scaling.md`), объём зависит от реального количества UC/модулей.
2. **Bootstrap артефактов** — агент создаёт через `Write`:
   - `docs/requirements.xml`, `docs/technology.xml`, `docs/development-plan.xml`, `docs/knowledge-graph.xml`, `docs/verification-plan.xml`, `docs/operational-packets.xml` (форматы — `methodology/artifacts.md`),
   - `AGENTS.md` с phase-блоком (`phase: post_migration`).
3. **Архитектура модулей** — агент по `UC-*` записям из `requirements.xml` драфтит `<M-*>` записи в `docs/development-plan.xml` (Edit). **Approval-gate**: пользователь подтверждает список модулей, CRITICALITY, экспорты.
4. **Verification draft** — агент драфтит `<V-M-*>` записи в `docs/verification-plan.xml`. **Approval-gate**: пользователь подтверждает покрытие.
5. **План исполнения** — агент драфтит фазы / порядок генерации в `docs/development-plan.xml`. **Approval-gate**: пользователь подтверждает план.
6. **Генерация кода** — по фазам `development-plan.xml`. ИИ размечает файлы якорями (см. `artifacts.md § markup`). После каждой фазы — `doubled-graph.analyze(mode="incremental", paths=[...])`.
7. **Первичный `doubled-graph.analyze(mode="full")`** — создаёт computed graph поверх только что написанного кода.
8. **Verification** — для модулей без `V-M-*` активируй skill `doubled-graph-verify`. Прогон тестов через Bash.
9. **Установка hooks** — `doubled-graph init-hooks` ставит git post-commit и (если Claude Code) PostToolUse.

С этого момента переход в **Сценарий 3 — Поддержка**.

---

## Сценарий 2. Миграция существующего

Entry-prompt: `prompts/migrate-existing-project/00-entry-prompt.md`.

**Контекст:** код существует, артефактов нет.

1. **Обнаружение** — `prompts/migrate-existing-project/01-discover.md`. ИИ запускает `doubled-graph.analyze(mode="full")` на существующем коде. Получает computed-graph, считает метрики (модули по кластерам, LOC, языки), проверяет наличие legacy-документации (README, ARCHITECTURE.md, docs/).
2. **Восстановление замысла** — `02-reconstruct-intent.md`. ИИ по коду + README восстанавливает draft `docs/requirements.xml` через `Write` и задаёт пользователю 5–10 уточняющих вопросов (что намерение, что случайность). **Approval-gate: требования**.
3. **Черновик плана** — `03-draft-plan.md`. `docs/development-plan.xml` собирается через `Write`/`Edit` по кластерам computed-graph. **Approval-gate: архитектура**.
4. **Постепенная разметка** — `04-markup-codebase.md`. **Критичный нюанс:** в режиме `migration` не правим логику, только добавляем якоря и контракты, без семантических изменений. После каждого файла — `Edit` `docs/knowledge-graph.xml` для синхронизации declared graph (см. skill `doubled-graph-after-edit` шаг 2).
5. **Verification** — `05-verification-and-logs.md`. Если legacy-тестов нет — ИИ предлагает минимальный набор для критических модулей (skill `doubled-graph-verify`); если есть — привязывает существующие к `V-M-*` записям через `Edit` `docs/verification-plan.xml`.
6. **Gates** — `06-validation-gates.md`. Критерии готовности миграции (`doubled-graph.lint()` clean, все модули имеют contract, computed ≈ declared, `doubled-graph.detect_changes()` пуст).
7. **Переключение режима** — `doubled-graph phase set post_migration --reason "migration complete"`. С этого момента политика дрейфа разворачивается (артефакты = ground-truth).

**Persistence режима между волнами миграции:** `phase: migration` сохраняется **на весь период миграции**, через все волны и коммиты. Не сбрасывается per wave. Каждая волна заканчивается синхронизацией `docs/*.xml`, но режим остаётся `migration` до финального `06-validation-gates.md`. Это важно: если режим случайно переключился на `post_migration` посреди миграции, следующая волна будет блокировать правки, которые легитимны для миграционного контекста. Если это произошло — откат через `DRIFT.md` запись (см. `drift-and-priority.md § Переключение режима`).

**Типичные провалы миграции** (учтено в промптах):

- Попытка разметить весь репозиторий сразу. *Митигация:* идём по кластерам computed-graph, начинаем с критичных.
- «ИИ понял замысел неправильно» — человек спорит с восстановленными требованиями. *Митигация:* Approval-gate на требованиях; фиксация разногласий в `docs/DRIFT.md`.
- Случайные семантические правки во время разметки. *Митигация:* `04-markup-codebase.md` явно запрещает менять логику; `git diff` ревью каждого файла.

---

## Сценарий 3. Поддержка (день-в-день)

Entry-prompts: skills семейства `doubled-graph-*` (см. `tools.md §1`). Предполагается: режим `post_migration`, hooks установлены, computed/declared graphs согласованы.

### Поток «новая фича»

1. Человек/ИИ формулирует изменение в `requirements.xml` (новый `UC-xxx`) через `Edit`.
2. ИИ драфтит обновление `development-plan.xml` (новые/изменённые `M-xxx`) через `Edit`. **Approval-gate**: пользователь подтверждает архитектуру.
3. ИИ драфтит план исполнения (порядок, фазы). **Approval-gate**.
4. Код + разметка + V-M-* + тесты — по плану. После каждой правки — skill `doubled-graph-after-edit`.
5. Коммит → `post-commit` hook → `doubled-graph analyze --mode incremental`.
6. Pre-commit (опц., рекомендовано в CI): `doubled-graph detect-changes --scope staged` + `doubled-graph lint`.

### Поток «обнаружен дрейф»

Триггер: `doubled-graph.detect_changes()` вернул непустой drift ИЛИ пользователь поправил код вручную и hook зарегистрировал это в логах.

Процесс — skill `doubled-graph-drift`:

1. ИИ смотрит тип дрейфа (`code_without_module` / `module_without_code` / `contract_mismatch` / `stale_crosslinks` / `missing_verification` / `markup_missing`).
2. Применяет политику (см. `drift-and-priority.md`):
   - В `post_migration`: спрашивает пользователя «новое требование или баг?».
   - «Новое требование» → возврат в поток «новая фича», шаг 2.
   - «Баг» → `Edit` кода под существующий контракт + запись в `CHANGE_SUMMARY`.
   - «Не знаю» → запись в `docs/DRIFT.md`, модуль блокируется для правок ИИ до разрешения.
3. В `migration` — `Edit` `docs/*.xml` обновляет артефакты под код без вопросов.

### Поток «ручная правка человека»

Триггер: `prepare-commit-msg` hook (если включён) распознал trailer `DG-Authored: human` или `mixed`, либо пользователь явно говорит «я поправил X сам».

Процесс — skill `doubled-graph-manual-edit`:

1. `doubled-graph.analyze(mode="incremental", paths=[touched])` (если post-commit hook ещё не запустился).
2. `doubled-graph.detect_changes(scope="branch", base_ref="main")` — если drift ∅, ничего не делаем.
3. Если drift есть — переход в skill `doubled-graph-drift`.
4. `doubled-graph.lint()` — проверка якорей.
5. `Edit` `CHANGE_SUMMARY` с записью `(DG-Authored: human)`.

### Перед любой правкой кода ИИ

Skill `doubled-graph-before-edit`:

1. `doubled-graph.impact(target=<символ>, direction="upstream")`.
2. Если `risk.level ∈ {HIGH, CRITICAL}` — остановка, показываем пользователю, ждём подтверждения.
3. Иначе — продолжаем правку.

### После правки (до коммита)

Skill `doubled-graph-after-edit`:

1. `doubled-graph.analyze(mode="incremental", paths=[touched])` (PostToolUse hook в Claude Code делает автоматически).
2. Если правка семантическая — `Edit` `docs/knowledge-graph.xml` / `development-plan.xml` под новые экспорты/контракт.
3. `doubled-graph.detect_changes(scope="staged")` — проверка дрейфа перед коммитом.
4. `doubled-graph.lint()` — проверка якорей.
5. Прогон `V-M-*` тестов через Bash.
6. Контракт-change check + commit.

---

## Приёмные критерии каждого шага

Формализованы в `approval-checkpoints.md`. Правило без исключений: **если gate не пройден, следующий шаг не начинается**. Технически это обеспечивают skill workflow'ы (явная остановка и ожидание ответа пользователя) + `doubled-graph lint` в CI.
