# Инструменты: лёгкий tool-surface, методология в skills

Методология **не работает** без обоих. Это — precondition, не рекомендация (см. `README.md`).

**Ключевой принцип:** `doubled-graph` — это **9 реальных tool'ов** для работы с дуальным графом плюс CLI-обёртки над `grace`. Всё остальное — **методологические workflow'ы в SKILL.md**, исполняемые агентом своими `Read`/`Edit`/`Write`/`Bash` tools.

---

## 1. doubled-graph — наш инструмент

- **Автор:** этот репозиторий. MIT.
- **Роль:** дуальный граф + drift detection + obвёртки над `grace` CLI. Не оркестратор методологии — это делают skills.
- **Исходник:** `../docs/SPEC.md`, `../docs/TOOLS.md`, `../docs/HOOKS.md`.

### MCP-tools (всё, что есть)

**Native** (computed × declared graph operations, in-process):

| MCP-tool | CLI | Назначение |
|---|---|---|
| `analyze` | `doubled-graph analyze [--mode ...]` | индексировать/обновить computed graph через CGC |
| `impact` | `doubled-graph impact <target>` | blast-radius перед правкой (mandatory-gate) |
| `context` | `doubled-graph context <name>` | 360-view на символ |
| `detect_changes` | `doubled-graph detect-changes` | drift computed×declared |
| `health` | `doubled-graph health` | health-отчёт: модули без `V-M-*`, drift count, open `DRIFT.md` (для CI) |

**Wrappers** над upstream `grace` CLI (subprocess, прозрачные):

| MCP-tool | CLI | Проксирует в |
|---|---|---|
| `lint` | `doubled-graph lint` | `grace lint` — валидация якорей и ссылок |
| `module_show` | `doubled-graph module show <id>` | `grace module show` |
| `module_find` | `doubled-graph module find <q>` | `grace module find` |
| `file_show` | `doubled-graph file show <path>` | `grace file show` — MODULE_CONTRACT/BLOCK_*/CHANGE_SUMMARY |

**Это весь публичный MCP-периметр** — 9 tool'ов. Никаких `refresh`/`plan`/`execute`/`fix`/`refactor`/`verification`/`reviewer`/`ask`/`init`/`multiagent_execute` как MCP-tools нет (см. ниже § «Что было удалено»).

### CLI-only (для человека, не AI)

| Команда | Назначение |
|---|---|
| `doubled-graph setup` | онбординг репо: prompts + skills + MCP + hooks + первый analyze |
| `doubled-graph init-hooks [--all]` | git/Claude Code hooks |
| `doubled-graph phase get` | прочитать текущий phase из `AGENTS.md` |
| `doubled-graph phase set <val> [--reason "..."]` | переключить phase (atomic rewrite `AGENTS.md` phase-блока) |
| `doubled-graph status` | диагностика: config + phase + freshness |
| `doubled-graph serve` | старт MCP-сервера на stdio (используется IDE автоматически) |

### Skills (workflows для агента)

`doubled-graph setup` ставит наши SKILL.md в `.claude/skills/`, `.cursor/rules/`, `.continue/rules/`, `.roo/rules/`, `.kilocode/rules/`, `.opencode/rules/`, `.windsurfrules` (per-IDE format). Семейство:

| Skill | Когда |
|---|---|
| `doubled-graph-guide` | overview методологии и навигация |
| `doubled-graph-before-edit` | до любой правки кода — обязательный impact-gate |
| `doubled-graph-after-edit` | после правки, до коммита — drift / lint / tests / contract-check |
| `doubled-graph-drift` | `detect_changes` вернул непустой drift |
| `doubled-graph-manual-edit` | человек поправил код вручную |
| `doubled-graph-refactor` | rename/move/split/extract — координация code + XML + V-M-* |
| `doubled-graph-verify` | модуль без `V-M-*` тестов — добавить покрытие |

### Что НЕ является MCP-tool'ом

11 операций намеренно **не** экспонируются как MCP-tools: `init`, `plan`, `execute`, `multiagent_execute`, `refresh`, `verification`, `reviewer`, `fix`, `ask`, `refactor`. Это **agent-side workflows**, не tools — они исполняются агентом через стандартные `Read`/`Edit`/`Write`/`Bash` под руководством наших SKILL.md, а не как отдельные subprocess-команды.

Где живёт каждая операция:

- **`init` / `plan` / `execute`** — one-off scenarios в `prompts/new-project/` и `prompts/migrate-existing-project/`. Bootstrap артефактов делается агентом через `Write` `docs/*.xml`; planning/execute — итеративные workflow с approval-gates.
- **`refresh`** — skill `doubled-graph-after-edit` шаг 2 + `doubled-graph-drift` § A. Агент `Edit`-ит `docs/knowledge-graph.xml` и `docs/development-plan.xml` под код.
- **`fix`** — skill `doubled-graph-drift` § B.3. Агент `Edit`-ит код обратно под существующий контракт + `CHANGE_SUMMARY` запись.
- **`verification`** — skill `doubled-graph-verify`. Workflow добавления `<V-M-*>` записей + test scaffold пропорционально criticality.
- **`refactor`** — skill `doubled-graph-refactor`. Координация code + XML + V-M-* через `impact()` + `Edit`.
- **`reviewer`** — agent через `Read` + сравнение diff (нет dedicated workflow, выполняется в рамках general code review).
- **`ask`** — комбо `context()` + `module_show()` + `Read` для grounded Q&A.
- **`multiagent_execute`** — параллельная кодогенерация через sub-agents (опционально, см. `prompts/new-project/06-generate.md`).

### Почему такое разделение

1. **Честность.** Tool делает работу в-процессе и возвращает результат; skill описывает workflow для агента. Не смешиваем два понятия.
2. **Когнитивная нагрузка.** 9 реальных tools проще, чем 20 (включая 11 которые делают делегирование). Локальные модели среднего размера не путаются.
3. **Расширяемость.** Новые workflow'ы — это новые SKILL.md (markdown, легко аудитировать через git), не код в `tools/*.py`.
4. **Универсальность.** Skills работают во всех 7 IDE (Claude/Cursor/Continue/Roo/Kilo/OpenCode/Windsurf). Native skill API есть только в Claude Code; в остальных skills загружаются как always-on или как named rules — что эквивалентно нашему usage.

---

## 2. grace-marketplace (upstream, не наш)

- **Автор:** osovv. GitHub: `osovv/grace-marketplace`. MIT.
- **Версия** на момент написания методологии: v3.7.0 (апрель 2026, сверять актуальность).
- **Что даёт:**
  - 14 **skills** для Claude Code (агентные процедуры, не CLI).
  - CLI `grace` на Bun — `lint`, `module show/find`, `file show`.

**Как мы к ним обращаемся:**
- **CLI `grace`** — агент НЕ вызывает напрямую. Все три команды (`lint`, `module show/find`, `file show`) проксируются через wrapper-tools `doubled-graph.lint`, `doubled-graph.module_show/find`, `doubled-graph.file_show` (см. §1 Wrappers). Это даёт единый namespace `doubled-graph.*`, общую точку логирования (`.doubled-graph/logs/`) и возможность enforcement'а policy.
- **Upstream skills** (`grace-init`, `grace-plan`, `grace-execute`, etc.) — **методология их не использует**. Это markdown-инструкции для агента, не CLI. Аналогичные workflow'ы покрываются нашими SKILL.md (`doubled-graph-*` семейство, см. §1) и one-off prompts в `prompts/new-project/` и `prompts/migrate-existing-project/`. Upstream skills остаются полезными как референсный материал для XML-шаблонов и approval-конвенций.

`doubled-graph setup` ставит `grace` CLI автоматически (через `bun add -g @osovv/grace-cli`, либо через npm/yarn/pnpm + tsx-фолбек если Bun отсутствует).

---

## 3. CodeGraphContext — внешняя зависимость, не трогаем

- **Автор:** внешний, MIT.
- **Что используем:** Python-библиотека (`GraphBuilder`, `CodeFinder`, `DatabaseManager`). Импортируется в `src/doubled_graph/integrations/cgc.py`.
- **Что НЕ используем:** MCP-сервер CGC (`cgc mcp start`) — чтобы агент не видел 14 tool'ов.
- **Поддержка 19 языков** (Python, JS, TS, Go, Java, C/C++/C#, Rust, Ruby, PHP, Kotlin, Scala, Swift, Dart, Elixir, Perl, Haskell).
- **Backends:** FalkorDB Lite (Unix default), KùzuDB (Windows/fallback), Neo4j (remote). Выбор автоматический, переопределяется `CGC_RUNTIME_DB_TYPE`.

Известные ограничения CGC:
- Haskell-парсер помечен как unstable в исходнике.
- FalkorDB Lite требует Python 3.12+.
- Windows Neo4j driver 6.x имеет баги — workaround `pip install "neo4j<6"`.

---

## 4. BlackboxBook — источник обоснований, не процесс

Используется как **ссылочный материал**, не как source-of-truth:

- гл. 7 (семантическая разметка) — обоснование для принципа 3.
- гл. 9 (декомпозиция) — обоснование для принципа 1.
- гл. 13 (LDD + антигаллюцинационный контур) — обоснование для принципов 7 и 8.
- гл. 14 (eval-дисциплина) — `approval-checkpoints.md § 4`.
- гл. 17 (OTel GenAI) — **не** применяем как обязательное (см. memory `project_otel_dropped.md`).

Главы 5 и 24 — не используются (спекулятивные места).

---

## 5. GitNexus — почему не используется

GitNexus — граф-анализатор кода, функционально близкий к CGC. На вид — удобнее (больше tools, richer MCP surface). **Лицензия:** PolyForm Noncommercial.

**Решение 2026-04-17:** исключён. PolyForm NC запрещает коммерческое использование; методология, претендующая на публичную публикацию и применимость в enterprise, не может опираться на NC-лицензированные зависимости. Это не техническое решение, а лицензионное.

**Что заменяет:** CodeGraphContext (MIT) + наш `doubled-graph` (MIT). Не даёт всех фич GitNexus (например, embeddings и cluster detection по Leiden), но закрывает базовые потребности методологии.

`doubled-graph` не импортирует ни строки кода из GitNexus. Проверяется commit-time test: `grep -r "gitnexus" src/ | wc -l` == 0.

---

## 6. Взаимодействие инструментов — картина целиком

```
                   ┌─────────────┐
                   │ Пользователь│
                   └──────┬──────┘
                          │
                   IDE (с MCP+tools)
                          │
         ┌────────────────┴────────────────┐
         │                                 │
    [ via skills ]                  [ via MCP ]
         │                                 │
    grace skills                    doubled-graph MCP
    (inline в IDE)                  (4 tools: analyze,
         │                           impact, context,
         │                           detect_changes)
         │                                 │
         ▼                                 ▼
    CLI `grace`                    CGC (Python lib)
    (валидация,                    + grace CLI subprocess
    navigation)                           │
                                          ▼
                                  .doubled-graph/ logs
                                  CGC DB (FalkorDB/Kùzu/Neo4j)
```

- **grace skills** — agent-level расширения поведения в IDE.
- **doubled-graph MCP** — все агенты (controller, workers, reviewers) видят 9 tool'ов. Sub-agents наследуют MCP-конфигурацию проекта.
- **grace CLI** — dialected text-UI, инструмент для человека и hook'ов; doubled-graph шеллит его для `module show` / `file show` / `lint`.
- **CGC backend** — хранилище computed graph; пользователь обычно не трогает.

---

## 7. Установка одной командой

`for-humans/getting-started.md` (Phase 4) будет содержать финальную команду. Ожидаемая форма (черновик):

```bash
# Python tooling
pipx install doubled-graph

# Bun tooling
bun add -g @osovv/grace-cli

# hooks
doubled-graph init-hooks --all
```

Отдельно для Claude Code — настройка MCP-сервера в `~/.claude/config.json`. Пример — `runtime-adapters/claude-code.md`.
