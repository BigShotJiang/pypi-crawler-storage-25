"""Generated OpenAPI-derived pydantic models. Do not edit by hand."""
# ruff: noqa: E501

from __future__ import annotations

from typing import TYPE_CHECKING

from pydantic import BaseModel as _BaseModel
from pydantic import ConfigDict as _ConfigDict

if TYPE_CHECKING:
    from .grid import Grid
    from .pager import Pager


class GridResponse(_BaseModel):
    """OpenAPI schema `GridResponse`."""

    model_config = _ConfigDict(extra="allow", populate_by_name=True, defer_build=True)

    listGrid: Grid | None = None
    pager: Pager | None = None
