"""Generated OpenAPI-derived pydantic models. Do not edit by hand."""
# ruff: noqa: E501

from __future__ import annotations

from pydantic import BaseModel as _BaseModel
from pydantic import ConfigDict as _ConfigDict


class I18nOutput(_BaseModel):
    """OpenAPI schema `I18nOutput`."""

    model_config = _ConfigDict(extra="allow", populate_by_name=True, defer_build=True)

    translations: dict[str, str] | None = None
