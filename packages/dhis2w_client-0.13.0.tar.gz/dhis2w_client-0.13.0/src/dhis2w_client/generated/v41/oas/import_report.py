"""Generated OpenAPI-derived pydantic models. Do not edit by hand."""
# ruff: noqa: E501

from __future__ import annotations

from typing import TYPE_CHECKING

from pydantic import BaseModel as _BaseModel
from pydantic import ConfigDict as _ConfigDict

if TYPE_CHECKING:
    from .metadata_import_params import MetadataImportParams
    from .stats import Stats
    from .type_report import TypeReport


class ImportReport(_BaseModel):
    """OpenAPI schema `ImportReport`."""

    model_config = _ConfigDict(extra="allow", populate_by_name=True, defer_build=True)

    importParams: MetadataImportParams | None = None
    stats: Stats | None = None
    status: str | None = None
    typeReports: list[TypeReport] | None = None
