"""Generated OpenAPI-derived pydantic models. Do not edit by hand."""
# ruff: noqa: E501

from __future__ import annotations

from pydantic import BaseModel as _BaseModel
from pydantic import ConfigDict as _ConfigDict


class DisableInactiveUsersJobParameters(_BaseModel):
    """OpenAPI schema `DisableInactiveUsersJobParameters`."""

    model_config = _ConfigDict(extra="allow", populate_by_name=True, defer_build=True)

    inactiveMonths: int | None = None
    reminderDaysBefore: int | None = None
