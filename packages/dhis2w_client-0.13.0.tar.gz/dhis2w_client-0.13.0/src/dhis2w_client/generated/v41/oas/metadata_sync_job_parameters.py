"""Generated OpenAPI-derived pydantic models. Do not edit by hand."""
# ruff: noqa: E501

from __future__ import annotations

from pydantic import BaseModel as _BaseModel
from pydantic import ConfigDict as _ConfigDict


class MetadataSyncJobParameters(_BaseModel):
    """OpenAPI schema `MetadataSyncJobParameters`."""

    model_config = _ConfigDict(extra="allow", populate_by_name=True, defer_build=True)

    dataValuesPageSize: int | None = None
    eventProgramPageSize: int | None = None
    trackerProgramPageSize: int | None = None
