"""Generated OpenAPI-derived pydantic models. Do not edit by hand."""
# ruff: noqa: E501

from __future__ import annotations

from pydantic import BaseModel as _BaseModel
from pydantic import ConfigDict as _ConfigDict
from pydantic import Field as _Field


class TrackerProgramOwner(_BaseModel):
    """OpenAPI schema `TrackerProgramOwner`."""

    model_config = _ConfigDict(extra="allow", populate_by_name=True, defer_build=True)

    orgUnit: str | None = None
    program: str | None = None
    trackedEntity: str | None = _Field(default=None, description="A UID for an TrackerTrackedEntity object  ")
