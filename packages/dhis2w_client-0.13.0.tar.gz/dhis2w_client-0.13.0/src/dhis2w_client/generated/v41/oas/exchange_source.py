"""Generated OpenAPI-derived pydantic models. Do not edit by hand."""
# ruff: noqa: E501

from __future__ import annotations

from typing import TYPE_CHECKING

from pydantic import BaseModel as _BaseModel
from pydantic import ConfigDict as _ConfigDict

if TYPE_CHECKING:
    from .source_params import SourceParams
    from .source_request import SourceRequest


class ExchangeSource(_BaseModel):
    """OpenAPI schema `ExchangeSource`."""

    model_config = _ConfigDict(extra="allow", populate_by_name=True, defer_build=True)

    params: SourceParams | None = None
    requests: list[SourceRequest] | None = None
