"""Generated OpenAPI-derived pydantic models. Do not edit by hand."""
# ruff: noqa: E501

from __future__ import annotations

from pydantic import BaseModel as _BaseModel
from pydantic import ConfigDict as _ConfigDict
from pydantic import Field as _Field


class AppIcons(_BaseModel):
    """OpenAPI schema `AppIcons`."""

    model_config = _ConfigDict(extra="allow", populate_by_name=True, defer_build=True)

    field_128: str | None = _Field(default=None, alias="128")
    field_16: str | None = _Field(default=None, alias="16")
    field_48: str | None = _Field(default=None, alias="48")
