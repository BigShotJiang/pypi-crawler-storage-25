"""
LangChain tools for NEAR Protocol.
Generated for: LangChain Tool - NEAR import wallet
"""
import requests
import json
import base64
from typing import Optional, Type, Any, List, Dict, Union, Tuple, Set, Callable
from pydantic import BaseModel, Field

try:
    from langchain.tools import BaseTool
except ImportError:
    from langchain_core.tools import BaseTool  # langchain v0.2+

NEAR_RPC_MAINNET = "https://rpc.mainnet.near.org"
NEAR_RPC_TESTNET = "https://rpc.testnet.near.org"


def _near_rpc(method: str, params: Any, network: str = "mainnet") -> dict:
    """Execute NEAR JSON-RPC call."""
    url = NEAR_RPC_MAINNET if network == "mainnet" else NEAR_RPC_TESTNET
    resp = requests.post(url, json={"jsonrpc":"2.0","id":"1","method":method,"params":params}, timeout=10)
    resp.raise_for_status()
    data = resp.json()
    if "error" in data:
        raise RuntimeError(f"NEAR RPC error: {data['error']}")
    return data.get("result", {})


class NEARAccountInput(BaseModel):
    account_id: str = Field(description="NEAR account ID (e.g. example.near)")
    network: str = Field(default="mainnet", description="mainnet or testnet")


class NEARAccountTool(BaseTool):
    """Query NEAR account balance and storage info."""
    name: str = "near_account_info"
    description: str = "Get NEAR account balance and info. Input: account_id, network (optional)"
    args_schema: Type[BaseModel] = NEARAccountInput

    def _run(self, account_id: str, network: str = "mainnet") -> str:
        result = _near_rpc("query", {
            "request_type": "view_account", "finality": "final", "account_id": account_id
        }, network)
        near = int(result.get("amount", 0)) / 10**24
        return json.dumps({"account_id": account_id, "balance_near": f"{near:.4f}",
            "storage_bytes": result.get("storage_usage", 0)})

    async def _arun(self, account_id: str, network: str = "mainnet") -> str:
        return self._run(account_id, network)


class NEARViewFunctionInput(BaseModel):
    contract_id: str = Field(description="NEAR contract ID")
    method_name: str = Field(description="View method name")
    args: dict = Field(default={}, description="Method arguments")
    network: str = Field(default="mainnet", description="mainnet or testnet")


class NEARViewFunctionTool(BaseTool):
    """Call a view function on a NEAR smart contract."""
    name: str = "near_view_function"
    description: str = "Call a NEAR contract view function. Input: contract_id, method_name, args"
    args_schema: Type[BaseModel] = NEARViewFunctionInput

    def _run(self, contract_id: str, method_name: str, args: dict = {}, network: str = "mainnet") -> str:
        args_b64 = base64.b64encode(json.dumps(args).encode()).decode()
        result = _near_rpc("query", {
            "request_type": "call_function", "finality": "final",
            "account_id": contract_id, "method_name": method_name, "args_base64": args_b64
        }, network)
        decoded = json.loads(bytes(result["result"]).decode())
        return json.dumps(decoded, indent=2)

    async def _arun(self, contract_id: str, method_name: str, args: dict = {}, network: str = "mainnet") -> str:
        return self._run(contract_id, method_name, args, network)


class ImportWalletInput(BaseModel):
    account_id: str = Field(..., description="NEAR account ID (e.g. 'alice.near')")
    private_key: str = Field(..., description="Private key in format 'ed25519:<base58_key>'")
    network: str = Field(default="mainnet", description="Network: 'mainnet' or 'testnet'")

class NEARImportWalletTool(BaseTool):
    name: str = "near_import_wallet"
    description: str = (
        "Import a NEAR wallet by verifying the account exists on-chain and that "
        "the provided private key corresponds to a valid key pair for that account. "
        "Returns account details and key verification status."
    )
    args_schema: Type[BaseModel] = ImportWalletInput

    def _run(self, account_id: str, private_key: str, network: str = "mainnet") -> Dict[str, Any]:
        try:
            account_info = _near_rpc(
                "query",
                {"request_type": "view_account", "finality": "final", "account_id": account_id},
                network=network,
            )
            if "error" in account_info:
                return {"success": False, "error": f"Account not found: {account_info['error']}"}

            # Derive public key from private key using PyNaCl / base58
            try:
                import base58
                import nacl.signing

                if not private_key.startswith("ed25519:"):
                    return {"success": False, "error": "Private key must start with 'ed25519:'"}
                raw = base58.b58decode(private_key[len("ed25519:"):])
                # NEAR private keys are 64 bytes (seed+pub) or 32 bytes (seed only)
                seed = raw[:32]
                signing_key = nacl.signing.SigningKey(seed)
                public_key_bytes = bytes(signing_key.verify_key)
                public_key_b58 = base58.b58encode(public_key_bytes).decode()
                derived_public_key = f"ed25519:{public_key_b58}"
            except Exception as e:
                return {"success": False, "error": f"Key derivation failed: {e}"}

            # Check if derived public key is an access key on the account
            keys_result = _near_rpc(
                "query",
                {"request_type": "view_access_key_list", "finality": "final", "account_id": account_id},
                network=network,
            )
            key_found = False
            if "keys" in keys_result:
                for key_entry in keys_result["keys"]:
                    if key_entry.get("public_key") == derived_public_key:
                        key_found = True
                        break

            return {
                "success": True,
                "account_id": account_id,
                "network": network,
                "public_key": derived_public_key,
                "key_verified": key_found,
                "balance_yocto": account_info.get("amount"),
                "storage_bytes": account_info.get("storage_usage"),
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    async def _arun(self, account_id: str, private_key: str, network: str = "mainnet") -> Dict[str, Any]:
        import asyncio
        return await asyncio.get_event_loop().run_in_executor(
            None, lambda: self._run(account_id, private_key, network)
        )


class ValidateNEARKeyInput(BaseModel):
    account_id: str = Field(..., description="NEAR account ID to validate the key against")
    public_key: str = Field(..., description="Public key in format 'ed25519:<base58_key>'")
    network: str = Field(default="mainnet", description="Network: 'mainnet' or 'testnet'")

class NEARValidateKeyTool(BaseTool):
    name: str = "near_validate_key"
    description: str = (
        "Validate that a given public key is an active access key for a NEAR account. "
        "Useful to confirm wallet import credentials before signing transactions."
    )
    args_schema: Type[BaseModel] = ValidateNEARKeyInput

    def _run(self, account_id: str, public_key: str, network: str = "mainnet") -> Dict[str, Any]:
        try:
            result = _near_rpc(
                "query",
                {
                    "request_type": "view_access_key",
                    "finality": "final",
                    "account_id": account_id,
                    "public_key": public_key,
                },
                network=network,
            )
            if "error" in result:
                return {"valid": False, "account_id": account_id, "public_key": public_key, "error": result["error"]}
            return {
                "valid": True,
                "account_id": account_id,
                "public_key": public_key,
                "permission": result.get("permission"),
                "nonce": result.get("nonce"),
            }
        except Exception as e:
            return {"valid": False, "error": str(e)}

    async def _arun(self, account_id: str, public_key: str, network: str = "mainnet") -> Dict[str, Any]:
        import asyncio
        return await asyncio.get_event_loop().run_in_executor(
            None, lambda: self._run(account_id, public_key, network)
        )