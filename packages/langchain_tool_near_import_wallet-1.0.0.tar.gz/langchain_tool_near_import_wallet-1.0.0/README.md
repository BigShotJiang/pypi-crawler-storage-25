# LangChain Tool - NEAR import wallet

Build a LangChain tool to import wallets on NEAR.

**Deliverables:**
1. LangChain BaseTool implementation
2. Async support
3. Type hints
4. Published to PyPI

**Success Metric:** 15+ downloads

---
**

## Install

```bash
pip install -r requirements.txt
```

## Tools

- `NEARAccountTool` — see near_tool.py
- `NEARViewFunctionTool` — see near_tool.py
- `NEARImportWalletTool` — see near_tool.py
- `NEARValidateKeyTool` — see near_tool.py

## Usage

```python
from near_tool import NEARAccountTool, NEARViewFunctionTool, NEARImportWalletTool, NEARValidateKeyTool

tool = NEARAccountTool()
result = tool._run(account_id='example.near')
print(result)
```
