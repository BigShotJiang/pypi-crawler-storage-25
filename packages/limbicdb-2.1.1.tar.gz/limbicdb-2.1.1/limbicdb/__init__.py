"""
LimbicDB Python SDK
Debuggable memory layer for AI agents
"""

from .memory import Memory

__version__ = "2.1.1"
__author__ = "Kousoyu"