# LimbicDB Python SDK

> Debuggable AI Memory for Python

Your AI is not wrong. Its memory is.

LimbicDB makes AI memory **observable, explainable, and debuggable**.

## Installation

```bash
pip install limbicdb
```

> **Note**: This package requires [LimbicDB](https://github.com/Kousoyu/limbicdb) to be installed locally.
> The Python SDK is a thin wrapper around the LimbicDB CLI.

## Quick Start

```python
from limbicdb import Memory

# Initialize memory with default path
memory = Memory()

# Explain memory retrieval decisions
explanation = memory.explain("anime")
print(explanation)

# Check for conflicts
if explanation["conflicts"]:
    print("⚠️  Conflicting memories detected!")
```

## Core Features

- **🔍 Inspect Memory**: See what your AI actually remembers
- **⚠️ Detect Conflicts**: Identify contradictory information automatically  
- **🧠 Explain Decisions**: Understand why specific memories were chosen
- **🛠️ Debug Behavior**: Fix AI inconsistencies at the memory level

## Integration

Works seamlessly with:
- LangChain
- AutoGen  
- Custom AI agents

## Philosophy

Memory should not be a black box. LimbicDB makes AI memory observable, explainable, and controllable.

## License

MIT