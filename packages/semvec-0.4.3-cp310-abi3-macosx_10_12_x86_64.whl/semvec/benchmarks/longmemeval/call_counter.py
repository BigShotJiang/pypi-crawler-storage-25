"""LLMCallCounter — proxy wrapper that tracks LLM call metrics.

Wraps any callable LLM client to count calls and sum token usage
without altering the underlying call semantics. Ported from
``pss.benchmarks.longmemeval.call_counter``.
"""

from __future__ import annotations

from collections.abc import Callable
from contextlib import contextmanager


class _CounterScope:
    """Live view of counter increments within a ``with`` block."""

    def __init__(self, counter: LLMCallCounter) -> None:
        self._counter = counter
        self._start_calls = counter.total_calls
        self._start_prompt = counter.total_prompt_tokens
        self._start_completion = counter.total_completion_tokens

    @property
    def calls(self) -> int:
        return self._counter.total_calls - self._start_calls

    @property
    def prompt_tokens(self) -> int:
        return self._counter.total_prompt_tokens - self._start_prompt

    @property
    def completion_tokens(self) -> int:
        return self._counter.total_completion_tokens - self._start_completion


class LLMCallCounter:
    """Proxy that tracks calls and token usage for any callable LLM client.

    The wrapped callable must accept a ``messages`` argument and may expose
    a ``last_usage`` attribute with ``prompt_tokens``/``completion_tokens``
    keys after each call. The counter mirrors ``last_usage`` on itself so
    existing code that reads ``counter.last_usage`` continues to work.
    """

    def __init__(self, inner: Callable) -> None:
        self._inner = inner
        self._total_calls = 0
        self._total_prompt_tokens = 0
        self._total_completion_tokens = 0
        self.last_usage: dict | None = None

    def __call__(self, messages):
        self._total_calls += 1
        try:
            response = self._inner(messages)
        except Exception:
            self.last_usage = getattr(self._inner, "last_usage", None)
            raise

        usage = getattr(self._inner, "last_usage", None)
        if isinstance(usage, dict):
            pt = usage.get("prompt_tokens")
            ct = usage.get("completion_tokens")
            if isinstance(pt, int):
                self._total_prompt_tokens += pt
            if isinstance(ct, int):
                self._total_completion_tokens += ct
            self.last_usage = dict(usage)
        else:
            self.last_usage = None
        return response

    @property
    def total_calls(self) -> int:
        return self._total_calls

    @property
    def total_prompt_tokens(self) -> int:
        return self._total_prompt_tokens

    @property
    def total_completion_tokens(self) -> int:
        return self._total_completion_tokens

    def reset(self) -> None:
        self._total_calls = 0
        self._total_prompt_tokens = 0
        self._total_completion_tokens = 0
        self.last_usage = None

    @contextmanager
    def scope(self):
        """Yield a live view of call/token deltas made inside the block."""
        snap = _CounterScope(self)
        yield snap
