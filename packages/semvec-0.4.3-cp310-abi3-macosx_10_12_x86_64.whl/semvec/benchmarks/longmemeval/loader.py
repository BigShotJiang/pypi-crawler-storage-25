"""Loader for LongMemEval benchmark data.

Supports loading from a local JSON file or downloading from HuggingFace.
Ported from ``pss.benchmarks.longmemeval.loader``.
"""

from __future__ import annotations

import json
from pathlib import Path

from .schema import LongMemEvalDataset, LongMemEvalEntry, Session

_DATA_DIR = Path(__file__).parent / "data"

_HF_BASE = "https://huggingface.co/datasets/xiaowu0162/longmemeval-cleaned" "/resolve/main"

_VARIANT_FILES = {
    "S": "longmemeval_s_cleaned.json",
    "M": "longmemeval_m_cleaned.json",
    "oracle": "longmemeval_oracle.json",
}


def _parse_entry(raw: dict) -> LongMemEvalEntry:
    """Parse a single raw JSON entry into a LongMemEvalEntry.

    HuggingFace format:
      - ``haystack_sessions``: list of sessions, each a list of turn dicts.
      - ``haystack_session_ids``: parallel array of session IDs.
      - ``answer_session_ids``: which sessions contain the answer.
    Fixture format alternative: each session may instead be a dict with
    ``{"session_id", "conversation", "has_answer"}`` keys.
    """
    raw_sessions = raw.get("haystack_sessions", [])
    session_ids = raw.get("haystack_session_ids", [])
    session_dates = raw.get("haystack_dates", [])
    answer_sids = set(raw.get("answer_session_ids", []))

    sessions: list[Session] = []
    for i, raw_turns in enumerate(raw_sessions):
        sid = session_ids[i] if i < len(session_ids) else f"session_{i}"
        date = session_dates[i] if i < len(session_dates) else ""
        if isinstance(raw_turns, dict):
            sid = raw_turns.get("session_id", sid)
            turns = raw_turns.get("conversation", [])
            has_answer = raw_turns.get("has_answer", sid in answer_sids)
        else:
            turns = raw_turns
            has_answer = sid in answer_sids
        sessions.append(
            Session(
                session_id=sid,
                turns=turns,
                has_answer=has_answer,
                session_date=date,
            )
        )

    answer = raw.get("answer", "")
    if isinstance(answer, list):
        answer = "; ".join(str(a) for a in answer)

    return LongMemEvalEntry(
        question_id=str(raw["question_id"]),
        question_type=raw["question_type"],
        question=raw["question"],
        answer=str(answer),
        question_date=raw.get("question_date", ""),
        haystack_sessions=sessions,
        answer_session_ids=raw.get("answer_session_ids", []),
    )


def load_from_file(path: Path, variant: str = "S") -> LongMemEvalDataset:
    """Load a LongMemEval dataset from a local JSON file."""
    if not path.exists():
        raise FileNotFoundError(f"Dataset file not found: {path}")
    with open(path, encoding="utf-8") as f:
        raw_entries = json.load(f)
    entries = [_parse_entry(raw) for raw in raw_entries]
    return LongMemEvalDataset(variant=variant, entries=entries)


def download_dataset(variant: str = "S") -> Path:
    """Download a LongMemEval variant from HuggingFace if not cached."""
    if variant not in _VARIANT_FILES:
        raise ValueError(f"Unknown variant: {variant!r}. Available: {list(_VARIANT_FILES)}")
    filename = _VARIANT_FILES[variant]
    local_path = _DATA_DIR / filename
    if local_path.exists():
        return local_path

    import urllib.request

    url = f"{_HF_BASE}/{filename}?download=true"
    _DATA_DIR.mkdir(parents=True, exist_ok=True)
    print(f"Downloading LongMemEval-{variant} from {url} ...")
    urllib.request.urlretrieve(url, local_path)  # noqa: S310
    print(f"Saved to {local_path}")
    return local_path


def load_dataset(variant: str = "S") -> LongMemEvalDataset:
    """Download (if needed) and load a LongMemEval dataset."""
    path = download_dataset(variant)
    return load_from_file(path, variant=variant)
