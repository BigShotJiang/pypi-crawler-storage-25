"""Ground-truth evaluator for LongMemEval.

Uses an LLM judge to compare PSS and baseline responses against the
known correct answer, producing pass/fail per entry and aggregate
metrics. Ported from ``pss.benchmarks.longmemeval.evaluator``.
"""

from __future__ import annotations

import json
import re
from collections import defaultdict
from collections.abc import Callable
from dataclasses import dataclass

from semvec.token_reduction import ChatMessage

from .runner import EntryResult


def _majority_vote(votes: list[bool]) -> bool:
    """Strict majority. Tie on even N → False (conservative)."""
    if not votes:
        return False
    n_true = sum(1 for v in votes if v)
    return n_true > len(votes) / 2


@dataclass
class SimpleEvalVerdict:
    """Light-weight verdict for the one-shot ``evaluate()`` helper."""

    passed: bool
    explanation: str


@dataclass
class EvalResult:
    """Evaluation outcome for a single entry (pss-compat)."""

    question_id: str
    question_type: str
    pss_correct: bool
    baseline_correct: bool
    explanation: str
    pss_query_tokens: int
    baseline_query_tokens: int
    pss_total_calls: int = 0
    baseline_total_calls: int = 0
    pss_total_tokens: int = 0
    baseline_total_tokens: int = 0
    wall_clock_seconds: float = 0.0


@dataclass
class BenchmarkSummary:
    """Aggregate benchmark metrics."""

    total_entries: int
    pss_accuracy: float
    baseline_accuracy: float
    total_pss_tokens: int
    total_baseline_tokens: int
    savings_pct: float
    per_type: dict[str, dict[str, float]]
    total_memory_system_calls: int = 0
    total_memory_system_tokens: int = 0
    total_baseline_calls: int = 0
    total_baseline_full_tokens: int = 0
    total_wall_clock_seconds: float = 0.0
    avg_wall_clock_seconds_per_entry: float = 0.0

    @classmethod
    def from_results(cls, results: list[EvalResult]) -> BenchmarkSummary:
        n = len(results)
        if n == 0:
            return cls(0, 0.0, 0.0, 0, 0, 0.0, {})

        pss_correct = sum(1 for r in results if r.pss_correct)
        base_correct = sum(1 for r in results if r.baseline_correct)
        total_pss = sum(r.pss_query_tokens for r in results)
        total_base = sum(r.baseline_query_tokens for r in results)
        savings = (1.0 - total_pss / total_base) * 100 if total_base > 0 else 0.0

        total_mem_calls = sum(r.pss_total_calls for r in results)
        total_mem_tokens = sum(r.pss_total_tokens for r in results)
        total_base_calls = sum(r.baseline_total_calls for r in results)
        total_base_full_tokens = sum(r.baseline_total_tokens for r in results)
        total_wall = sum(r.wall_clock_seconds for r in results)
        avg_wall = total_wall / n if n > 0 else 0.0

        by_type: dict[str, list[EvalResult]] = defaultdict(list)
        for r in results:
            by_type[r.question_type].append(r)

        per_type = {}
        for qtype, type_results in sorted(by_type.items()):
            tn = len(type_results)
            per_type[qtype] = {
                "count": tn,
                "pss_accuracy": sum(1 for r in type_results if r.pss_correct) / tn,
                "baseline_accuracy": sum(1 for r in type_results if r.baseline_correct) / tn,
            }

        return cls(
            total_entries=n,
            pss_accuracy=pss_correct / n,
            baseline_accuracy=base_correct / n,
            total_pss_tokens=total_pss,
            total_baseline_tokens=total_base,
            savings_pct=round(savings, 1),
            per_type=per_type,
            total_memory_system_calls=total_mem_calls,
            total_memory_system_tokens=total_mem_tokens,
            total_baseline_calls=total_base_calls,
            total_baseline_full_tokens=total_base_full_tokens,
            total_wall_clock_seconds=round(total_wall, 2),
            avg_wall_clock_seconds_per_entry=round(avg_wall, 3),
        )

    def to_dict(self) -> dict:
        return {
            "total_entries": self.total_entries,
            "pss_accuracy": round(self.pss_accuracy, 4),
            "baseline_accuracy": round(self.baseline_accuracy, 4),
            "total_pss_tokens": self.total_pss_tokens,
            "total_baseline_tokens": self.total_baseline_tokens,
            "savings_pct": self.savings_pct,
            "per_type": self.per_type,
            "total_memory_system_calls": self.total_memory_system_calls,
            "total_memory_system_tokens": self.total_memory_system_tokens,
            "total_baseline_calls": self.total_baseline_calls,
            "total_baseline_full_tokens": self.total_baseline_full_tokens,
            "total_wall_clock_seconds": self.total_wall_clock_seconds,
            "avg_wall_clock_seconds_per_entry": self.avg_wall_clock_seconds_per_entry,
        }


# ---------------------------------------------------------------------------
# Judge prompts


_JUDGE_SYSTEM = (
    "You are an expert evaluator. You will compare two AI responses against "
    "a known correct answer. Determine if each response is correct. "
    "Respond ONLY with valid JSON, no other text."
)

_JUDGE_TEMPLATE = (
    "Question: {question}\n\n"
    "Correct answer: {ground_truth}\n\n"
    "Response A (PSS):\n{pss_response}\n\n"
    "Response B (Baseline):\n{baseline_response}\n\n"
    "Evaluate whether each response correctly answers the question based "
    "on the correct answer. A response is correct if it contains the key "
    "information from the correct answer, even if worded differently.\n\n"
    "Respond with this exact JSON format:\n"
    '{{"pss_correct": true/false, "baseline_correct": true/false, '
    '"explanation": "..."}}'
)

_SIMPLE_JUDGE_SYSTEM = (
    "You are an evaluator. Decide whether a candidate response conveys the "
    "correct information. Start your reply with exactly one word on the first "
    "line: either PASS or FAIL. You may add one line of explanation after."
)


class GroundTruthEvaluator:
    """Evaluates entry results against ground truth using an LLM judge.

    Supports an ensemble of N judges — majority vote on each correctness
    flag, tie → False (conservative). See the module docstring for the
    parity contract with ``pss.benchmarks.longmemeval.evaluator``.
    """

    def __init__(
        self,
        judge_llm: Callable[[list[ChatMessage]], str],
        n_judges: int = 1,
    ) -> None:
        if n_judges < 1:
            raise ValueError(f"n_judges must be >= 1, got {n_judges}")
        self._judge = judge_llm
        self._n_judges = n_judges

    # --- full A/B judge -----------------------------------------------------

    def evaluate_entry(self, entry_result: EntryResult) -> EvalResult:
        prompt = _JUDGE_TEMPLATE.format(
            question=entry_result.question,
            ground_truth=entry_result.ground_truth,
            pss_response=entry_result.pss_response or "(empty)",
            baseline_response=entry_result.baseline_response or "(empty)",
        )
        messages = [
            ChatMessage(role="system", content=_JUDGE_SYSTEM),
            ChatMessage(role="user", content=prompt),
        ]

        pss_votes: list[bool] = []
        base_votes: list[bool] = []
        explanations: list[str] = []
        for _ in range(self._n_judges):
            raw = self._judge(messages)
            parsed = self._parse_judge_response(raw)
            pss_votes.append(bool(parsed.get("pss_correct", False)))
            base_votes.append(bool(parsed.get("baseline_correct", False)))
            exp = parsed.get("explanation", "")
            if exp:
                explanations.append(str(exp))

        pss_correct = _majority_vote(pss_votes)
        base_correct = _majority_vote(base_votes)

        if self._n_judges == 1:
            explanation = explanations[0] if explanations else ""
        else:
            pss_pass = sum(1 for v in pss_votes if v)
            base_pass = sum(1 for v in base_votes if v)
            n = self._n_judges
            explanation = (
                f"Ensemble votes: PSS {pss_pass}/{n} pass, " f"Baseline {base_pass}/{n} pass. "
            )
            if explanations:
                explanation += "Judge notes: " + " | ".join(explanations[:3])

        return EvalResult(
            question_id=entry_result.question_id,
            question_type=entry_result.question_type,
            pss_correct=pss_correct,
            baseline_correct=base_correct,
            explanation=explanation,
            pss_query_tokens=entry_result.pss_query_tokens,
            baseline_query_tokens=entry_result.baseline_query_tokens,
            pss_total_calls=entry_result.pss_total_calls,
            baseline_total_calls=entry_result.baseline_total_calls,
            pss_total_tokens=entry_result.pss_total_tokens,
            baseline_total_tokens=entry_result.baseline_total_tokens,
            wall_clock_seconds=entry_result.wall_clock_seconds,
        )

    def evaluate_all(self, results: list[EntryResult]) -> list[EvalResult]:
        return [self.evaluate_entry(r) for r in results]

    # --- simple single-response judge --------------------------------------

    def evaluate(
        self,
        question: str,
        correct_answer: str,
        candidate_response: str,
    ) -> SimpleEvalVerdict:
        """Single-response PASS/FAIL convenience judge.

        Asks the judge to tag the first line of the response as
        ``PASS`` or ``FAIL``. Handy for spot-checks outside the full A/B
        benchmark pipeline.
        """
        if not candidate_response.strip():
            return SimpleEvalVerdict(passed=False, explanation="empty response")
        user = (
            f"Question: {question}\n\n"
            f"Correct answer: {correct_answer}\n\n"
            f"Candidate response: {candidate_response}\n\n"
            "Your verdict:"
        )
        messages = [
            ChatMessage(role="system", content=_SIMPLE_JUDGE_SYSTEM),
            ChatMessage(role="user", content=user),
        ]
        raw = self._judge(messages)
        upper = raw.upper()
        # Scan from the end so "thinking" models with long reasoning chains
        # get parsed correctly.
        pass_idx = upper.rfind("PASS")
        fail_idx = upper.rfind("FAIL")
        passed = pass_idx > fail_idx
        return SimpleEvalVerdict(passed=passed, explanation=raw.strip()[:200])

    # --- helpers -----------------------------------------------------------

    @staticmethod
    def _parse_judge_response(raw: str) -> dict:
        """Parse the judge's JSON response, tolerating markdown fences."""
        text = raw.strip()
        match = re.search(r"```(?:json)?\s*(.*?)\s*```", text, re.DOTALL)
        if match:
            text = match.group(1)
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            return {
                "pss_correct": False,
                "baseline_correct": False,
                "explanation": f"Judge parse error: {raw[:200]}",
            }
