"""LongMemEval runners: Single-PSS + Multi-PSS.

Two-phase execution per entry:
  1. Ingest: feed all haystack sessions into PSS states.
  2. Query: answer the question via PSS-compressed context and
     full-history baseline, so the two paths can be compared.

Ported from ``pss.benchmarks.longmemeval.runner``. The semvec port
requires an explicit ``embedder`` keyword argument — there is no
hash-based fallback (see MIGRATION.md §What was intentionally dropped
and ``semvec.coding.engine``).
"""

from __future__ import annotations

import time
from collections.abc import Callable
from dataclasses import dataclass
from typing import Protocol

import numpy as np

from semvec import PSS_State_V4, PSSConfig
from semvec.token_reduction import (
    ChatMessage,
    PSSStateSerializer,
    SerializerConfig,
)

from .call_counter import LLMCallCounter
from .schema import LongMemEvalDataset, LongMemEvalEntry


class Embedder(Protocol):
    def get_embedding(self, text: str) -> np.ndarray: ...
    def get_dimension(self) -> int: ...


@dataclass
class EntryResult:
    """Result of running one LongMemEval entry.

    Query-phase metrics (narrow): the final memory-system LLM call vs
    baseline full-history call. Total-cost metrics (honest): sum across
    every ingest + query call made by each system.
    """

    question_id: str
    question_type: str
    question: str
    ground_truth: str
    pss_response: str
    baseline_response: str
    pss_query_tokens: int
    baseline_query_tokens: int
    sessions_ingested: int
    pss_total_calls: int = 0
    baseline_total_calls: int = 0
    pss_total_tokens: int = 0
    baseline_total_tokens: int = 0
    wall_clock_seconds: float = 0.0


def _safe_counted_call(counter: LLMCallCounter, messages: list[ChatMessage]) -> tuple[str, int]:
    """Call a counter-wrapped LLM with error handling.

    Returns ``(response_text, prompt_tokens_for_this_call)``. On failure the
    response is empty and tokens is 0 — the counter still increments its
    call count for accurate accounting.
    """
    try:
        response = counter(messages)
    except Exception as exc:
        print(f"    LLM call failed ({type(exc).__name__}: {exc}), recording empty response")
        return "", 0
    usage = counter.last_usage
    if isinstance(usage, dict) and usage.get("prompt_tokens") is not None:
        return response or "", int(usage["prompt_tokens"])
    return response or "", 0


# ---------------------------------------------------------------------------
# Single-PSS runner


class LongMemEvalRunner:
    """Single-PSS LongMemEval runner — one PSS state per entry."""

    def __init__(
        self,
        dataset: LongMemEvalDataset,
        llm: Callable[[list[ChatMessage]], str],
        embedder: Embedder,
        pss_config_dimension: int = 384,
        serializer_config: SerializerConfig | None = None,
        system_prompt: str = "You are a helpful assistant with memory of past conversations.",
    ) -> None:
        if embedder is None:
            raise RuntimeError(
                "LongMemEvalRunner requires an explicit `embedder=` argument. "
                "See MIGRATION.md — no hash-based fallback is provided."
            )
        self._dataset = dataset
        self._llm = llm
        self._pss_config = PSSConfig(dimension=pss_config_dimension)
        self._serializer_config = serializer_config or SerializerConfig(
            top_k=10, max_memory_chars=500
        )
        self._system_prompt = system_prompt
        self._embedder = embedder

    def run_entry(self, entry: LongMemEvalEntry) -> EntryResult:
        start_time = time.perf_counter()

        mem_counter = LLMCallCounter(self._llm)
        baseline_counter = LLMCallCounter(self._llm)

        pss_state = PSS_State_V4(config=self._pss_config)
        serializer = PSSStateSerializer(self._serializer_config)

        # Phase 1: ingest
        baseline_history: list[ChatMessage] = [
            ChatMessage(role="system", content=self._system_prompt),
        ]
        for session in entry.haystack_sessions:
            turns = session.turns
            i = 0
            while i < len(turns):
                role = turns[i].get("role", "user")
                content = turns[i].get("content", "")
                baseline_history.append(ChatMessage(role=role, content=content))

                if (
                    role == "user"
                    and i + 1 < len(turns)
                    and turns[i + 1].get("role") == "assistant"
                ):
                    answer_content = turns[i + 1].get("content", "")
                    chunk = f"Q: {content} A: {answer_content}"
                    baseline_history.append(ChatMessage(role="assistant", content=answer_content))
                    i += 2
                else:
                    chunk = f"{role}: {content}"
                    i += 1

                embedding = self._embedder.get_embedding(chunk)
                if np.linalg.norm(embedding) > 1e-8:
                    pss_state.update(embedding, chunk)

        # Phase 2: query
        query_embedding = self._embedder.get_embedding(entry.question)
        pss_context = serializer.serialize(pss_state, query_embedding=query_embedding)

        pss_messages = [
            ChatMessage(
                role="system",
                content=f"{self._system_prompt}\n\n{pss_context}",
            ),
            ChatMessage(role="user", content=entry.question),
        ]
        pss_response, pss_query_tokens = _safe_counted_call(mem_counter, pss_messages)

        baseline_messages = list(baseline_history) + [
            ChatMessage(role="user", content=entry.question),
        ]
        baseline_response, baseline_query_tokens = _safe_counted_call(
            baseline_counter, baseline_messages
        )

        wall_clock = time.perf_counter() - start_time

        return EntryResult(
            question_id=entry.question_id,
            question_type=entry.question_type,
            question=entry.question,
            ground_truth=entry.answer,
            pss_response=pss_response,
            baseline_response=baseline_response,
            pss_query_tokens=pss_query_tokens,
            baseline_query_tokens=baseline_query_tokens,
            sessions_ingested=entry.total_sessions,
            pss_total_calls=mem_counter.total_calls,
            baseline_total_calls=baseline_counter.total_calls,
            pss_total_tokens=mem_counter.total_prompt_tokens,
            baseline_total_tokens=baseline_counter.total_prompt_tokens,
            wall_clock_seconds=wall_clock,
        )

    def run_all(self) -> list[EntryResult]:
        return [self.run_entry(e) for e in self._dataset.entries]


# ---------------------------------------------------------------------------
# Multi-PSS runner


class MultiPSSRunner:
    """3-PSS LongMemEval runner for improved recall.

    Architecture:
      - PSS-User:      ingests only user turns
      - PSS-Assistant: ingests only assistant turns
      - PSS-QA:        ingests combined Q&A pairs (cluster view)

    At query time retrieves from all three, dedupes by text prefix, and
    keeps the top-1 full-text + remaining truncated. Temporal metadata
    (``[YYYY-MM-DD]`` prefix) is prepended to each chunk.
    """

    def __init__(
        self,
        dataset: LongMemEvalDataset,
        llm: Callable[[list[ChatMessage]], str],
        embedder: Embedder,
        pss_config_dimension: int = 384,
        top_k_per_instance: int = 5,
        max_memory_chars: int = 500,
        system_prompt: str = "You are a helpful assistant with memory of past conversations.",
    ) -> None:
        if embedder is None:
            raise RuntimeError("MultiPSSRunner requires an explicit `embedder=` argument.")
        self._dataset = dataset
        self._llm = llm
        self._pss_config = PSSConfig(dimension=pss_config_dimension)
        self._embedder = embedder
        self._top_k_per = top_k_per_instance
        self._max_memory_chars = max_memory_chars
        self._system_prompt = system_prompt

    def run_entry(self, entry: LongMemEvalEntry) -> EntryResult:
        # Inside the method so semvec.memory is only imported when used.
        from semvec import safe_cosine_similarity

        start_time = time.perf_counter()
        mem_counter = LLMCallCounter(self._llm)
        baseline_counter = LLMCallCounter(self._llm)

        pss_user = PSS_State_V4(config=self._pss_config)
        pss_assistant = PSS_State_V4(config=self._pss_config)
        pss_qa = PSS_State_V4(config=self._pss_config)

        baseline_history: list[ChatMessage] = [
            ChatMessage(role="system", content=self._system_prompt),
        ]

        # Phase 1: ingest with temporal metadata
        for session in entry.haystack_sessions:
            date_prefix = f"[{session.session_date}] " if session.session_date else ""
            turns = session.turns
            i = 0
            while i < len(turns):
                role = turns[i].get("role", "user")
                content = turns[i].get("content", "")
                baseline_history.append(ChatMessage(role=role, content=content))

                if (
                    role == "user"
                    and i + 1 < len(turns)
                    and turns[i + 1].get("role") == "assistant"
                ):
                    answer_content = turns[i + 1].get("content", "")
                    baseline_history.append(ChatMessage(role="assistant", content=answer_content))

                    user_chunk = f"{date_prefix}Q: {content}"
                    u_emb = self._embedder.get_embedding(user_chunk)
                    if np.linalg.norm(u_emb) > 1e-8:
                        pss_user.update(u_emb, user_chunk)

                    asst_chunk = f"{date_prefix}A: {answer_content}"
                    a_emb = self._embedder.get_embedding(asst_chunk)
                    if np.linalg.norm(a_emb) > 1e-8:
                        pss_assistant.update(a_emb, asst_chunk)

                    qa_chunk = f"{date_prefix}Q: {content} A: {answer_content}"
                    qa_emb = self._embedder.get_embedding(qa_chunk)
                    if np.linalg.norm(qa_emb) > 1e-8:
                        pss_qa.update(qa_emb, qa_chunk)

                    i += 2
                else:
                    chunk = f"{date_prefix}{role}: {content}"
                    emb = self._embedder.get_embedding(chunk)
                    if np.linalg.norm(emb) > 1e-8:
                        if role == "user":
                            pss_user.update(emb, chunk)
                        else:
                            pss_assistant.update(emb, chunk)
                        pss_qa.update(emb, chunk)
                    i += 1

        # Phase 2: merged retrieval from all 3 instances
        query_embedding = self._embedder.get_embedding(entry.question)

        all_memories: list[tuple[object, float]] = []
        for pss_state in (pss_user, pss_assistant, pss_qa):
            memories = pss_state.memory.get_relevant_memories(
                query_embedding, top_k=self._top_k_per
            )
            for mem in memories:
                score = safe_cosine_similarity(query_embedding, np.asarray(mem.embedding))
                all_memories.append((mem, float(score)))

        # Dedup by text prefix, keep highest score
        seen: dict[str, tuple[object, float]] = {}
        for mem, score in all_memories:
            key = mem.text[:80]
            if key not in seen or score > seen[key][1]:
                seen[key] = (mem, score)

        ranked = sorted(seen.values(), key=lambda x: x[1], reverse=True)

        lines = ["Relevant context:"]
        for i, (mem, score) in enumerate(ranked[: self._top_k_per * 2]):
            text = mem.text.replace("\n", " ")
            if i != 0:
                text = text[: self._max_memory_chars]
            lines.append(f"  {i + 1}. [{score:.2f}] {text}")
        pss_context = "\n".join(lines)

        pss_messages = [
            ChatMessage(
                role="system",
                content=f"{self._system_prompt}\n\n{pss_context}",
            ),
            ChatMessage(role="user", content=entry.question),
        ]
        pss_response, pss_query_tokens = _safe_counted_call(mem_counter, pss_messages)

        baseline_messages = list(baseline_history) + [
            ChatMessage(role="user", content=entry.question),
        ]
        baseline_response, baseline_query_tokens = _safe_counted_call(
            baseline_counter, baseline_messages
        )

        wall_clock = time.perf_counter() - start_time

        return EntryResult(
            question_id=entry.question_id,
            question_type=entry.question_type,
            question=entry.question,
            ground_truth=entry.answer,
            pss_response=pss_response,
            baseline_response=baseline_response,
            pss_query_tokens=pss_query_tokens,
            baseline_query_tokens=baseline_query_tokens,
            sessions_ingested=entry.total_sessions,
            pss_total_calls=mem_counter.total_calls,
            baseline_total_calls=baseline_counter.total_calls,
            pss_total_tokens=mem_counter.total_prompt_tokens,
            baseline_total_tokens=baseline_counter.total_prompt_tokens,
            wall_clock_seconds=wall_clock,
        )

    def run_all(self) -> list[EntryResult]:
        return [self.run_entry(e) for e in self._dataset.entries]
