"""HyperLogLog diversity sketch — clone-trainer detection.

Background
----------
A surrogate-cloning attacker needs hundreds of thousands of distinct
inputs to fit the calculate_* coefficient calculations. Legitimate
conversation use produces single-digit-thousand distinct inputs per
day at the absolute upper end. The cardinality of inputs to
`SemvecState.calculate_*` is therefore a strong distinguishing
signal — much higher than what any legitimate user would generate,
without revealing what those inputs are.

We accumulate a per-process HyperLogLog sketch over the
`norm_history` argument of `calculate_fsm` / `calculate_metrics` /
`calculate_advanced_metrics`. At process exit the estimated
cardinality (an integer) is reported alongside the existing init
ping. No raw inputs leave the process.

The HLL implementation is a small pure-Python one (no extra
dependency); precision = 12 buckets gives ~1.6 % standard error,
which is plenty for "is this 200 vs 200 000 distinct inputs".

Privacy
-------
The reported value is a single integer (estimated cardinality). It
does not contain any input bytes. The opt-out path is the same env
var as the init telemetry — `SEMVEC_TELEMETRY=0` disables both.
"""

from __future__ import annotations

import atexit
import hashlib
import math
import os
import struct
import threading

# 2 ** _LOG_M buckets = 4096; ~1.6% standard error.
_LOG_M = 12
_M = 1 << _LOG_M

# Linear-counting threshold — when more than ~30% of the buckets
# are still zero, switch to linear counting (more accurate at the
# low end, which is the legitimate-user regime).
_LINEAR_THRESHOLD = int(2.5 * _M)


def _alpha() -> float:
    """HLL bias-correction constant for our bucket count."""
    if _M <= 16:
        return 0.673
    if _M <= 32:
        return 0.697
    if _M <= 64:
        return 0.709
    return 0.7213 / (1 + 1.079 / _M)


_LOCK = threading.Lock()
_BUCKETS = bytearray(_M)
_REPORTED = False


def _hash64(payload: bytes) -> int:
    """64-bit hash of the canonical bytes of an input vector."""
    digest = hashlib.sha256(payload).digest()
    return struct.unpack(">Q", digest[:8])[0]


def _canonicalize(values) -> bytes:
    """Stable byte representation of a numeric sequence."""
    out = bytearray()
    for v in values:
        try:
            out.extend(struct.pack("<d", float(v)))
        except (TypeError, ValueError):
            out.extend(b"\x00" * 8)
    return bytes(out)


def add(values) -> None:
    """Add an input vector to the sketch.

    Cheap (one SHA-256 per call). Thread-safe. Silently ignores
    any error so we cannot break a calling state-bound method by
    mis-handling weird input types.
    """
    try:
        h = _hash64(_canonicalize(values))
    except Exception:
        return
    bucket_idx = h >> (64 - _LOG_M)
    remainder = (h << _LOG_M) & ((1 << 64) - 1)
    if remainder == 0:
        leading_zeros = 64 - _LOG_M + 1
    else:
        leading_zeros = (remainder.bit_length() ^ 63) - _LOG_M + 1
        if leading_zeros < 1:
            leading_zeros = 1
    with _LOCK:
        if leading_zeros > _BUCKETS[bucket_idx]:
            _BUCKETS[bucket_idx] = leading_zeros


def estimate() -> int:
    """Return the current estimated cardinality."""
    with _LOCK:
        buckets = list(_BUCKETS)

    raw_estimate = _alpha() * _M * _M
    denom = sum(2.0**-b for b in buckets) or 1.0
    raw_estimate /= denom

    zero_count = sum(1 for b in buckets if b == 0)
    if raw_estimate <= _LINEAR_THRESHOLD and zero_count > 0:
        # Linear counting for sparse sketches.
        return int(_M * math.log(_M / zero_count))
    return int(raw_estimate)


def maybe_report_at_exit(version: str) -> None:
    """Register an atexit hook that posts the cardinality estimate
    to the configured telemetry endpoint, **only if telemetry is
    enabled**. The post path is the existing telemetry worker; the
    body shape adds a 'usage_diversity' integer alongside the
    established init schema, which is forward-compatible with any
    worker that ignores unknown fields. A separate /usage endpoint
    can be added server-side later without changing this client."""
    global _REPORTED
    if _REPORTED:
        return
    _REPORTED = True

    if os.environ.get("SEMVEC_TELEMETRY", "") == "0":
        return

    def _report() -> None:
        cardinality = estimate()
        if cardinality <= 0:
            # No calculate_* calls happened — nothing to report.
            return
        try:
            from semvec import _telemetry as t

            payload = {
                **__import__("json").loads(t._payload(version).decode("utf-8")),
                "diversity": cardinality,
            }
            body = __import__("json").dumps(payload, separators=(",", ":")).encode("utf-8")
            endpoint = os.environ.get("SEMVEC_TELEMETRY_ENDPOINT", "").strip() or t.DEFAULT_ENDPOINT
            t._send(endpoint, body, version)
        except Exception:
            # Never break interpreter shutdown for telemetry.
            pass

    atexit.register(_report)


def reset_for_tests() -> None:
    """Test seam — wipe the sketch and the one-shot guard."""
    global _REPORTED
    with _LOCK:
        for i in range(_M):
            _BUCKETS[i] = 0
        _REPORTED = False
