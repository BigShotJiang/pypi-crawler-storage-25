"""PSS-compressed chat proxy that manages conversation with token tracking.

Maintains both the PSS-compressed path (used for actual LLM calls) and a
full history baseline (for token comparison), demonstrating O(1) vs O(n)
input cost per turn.

Ported from ``pss.token_reduction.chat_proxy``. Unlike the pss reference,
this port refuses to silently fall back to a hash-based pseudo-embedder —
if no ``embedding_service`` is passed and ``sentence-transformers`` is not
installed, construction raises ``RuntimeError``.

Q&A Chunking
------------
Each turn stores a single combined chunk ``"Q: <user_msg> A: <response>"``
instead of two separate entries. This avoids orphan questions in PSS memory
and produces richer, more retrievable context in future turns.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass

import numpy as np

from semvec import SemvecConfig, SemvecState

from .serializer import SemvecStateSerializer, SerializerConfig
from .token_counter import TokenCounter, TurnTokens, estimate_tokens


@dataclass
class ChatMessage:
    """A single chat message."""

    role: str  # "system", "user", "assistant"
    content: str


@dataclass
class TurnResult:
    """Result of a single chat turn."""

    response: str
    pss_input_tokens: int | None
    baseline_input_tokens: int | None
    pss_prompt: str
    phase: str
    turn_number: int


_MISSING_EMBEDDER_MSG = (
    "SemvecChatProxy requires an explicit embedding_service= — there is no "
    "hash-based fallback. Pass a SentenceTransformer-compatible wrapper "
    "with `get_embedding(text) -> np.ndarray` and `get_dimension() -> int`, "
    "or install sentence-transformers and construct a wrapper as shown in "
    "MIGRATION.md. Example:\n\n"
    "    from sentence_transformers import SentenceTransformer\n"
    "    import numpy as np\n"
    "    class STEmbedder:\n"
    "        def __init__(self, name='all-MiniLM-L6-v2', device='cpu'):\n"
    "            self._m = SentenceTransformer(name, device=device)\n"
    "            self._d = self._m.get_sentence_embedding_dimension()\n"
    "        def get_dimension(self): return self._d\n"
    "        def get_embedding(self, text):\n"
    "            if not text.strip(): return np.zeros(self._d)\n"
    "            return np.asarray(self._m.encode(text, normalize_embeddings=True,\n"
    "                show_progress_bar=False, convert_to_numpy=True), dtype=np.float64)\n"
    "    proxy = SemvecChatProxy(embedding_service=STEmbedder())"
)


class SemvecChatProxy:
    """Chat proxy that routes conversations through PSS-compressed context.

    Tracks both PSS-compressed and full-history token counts for comparison.
    The ``llm_call`` callable receives a list of ChatMessage and returns a
    string response. By default, uses a mock that echoes the input.
    """

    def __init__(
        self,
        llm_call: Callable[[list[ChatMessage]], str] | None = None,
        system_prompt: str = "You are a helpful assistant.",
        pss_config: SemvecConfig | None = None,
        serializer_config: SerializerConfig | None = None,
        embedding_service: object | None = None,
    ) -> None:
        self._llm_call = llm_call or self._default_llm_call
        self._system_prompt = system_prompt
        self._pss_config = pss_config or SemvecConfig()
        self._pss_state = SemvecState(config=self._pss_config)
        self._serializer = SemvecStateSerializer(serializer_config)
        self._token_counter = TokenCounter()
        self._embedding_service = embedding_service or self._resolve_embedder()
        self._full_history: list[ChatMessage] = [
            ChatMessage(role="system", content=system_prompt),
        ]
        self._turn_number = 0
        self._last_response: str | None = None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def chat(self, user_message: str) -> TurnResult:
        """Process a user message through PSS-compressed context.

        Steps:
            1. Embed user message
            2. Serialize PSS state into compact context (before storing message,
               to avoid self-retrieval with relevance 1.0)
            3. Buffer user message — stored as Q&A chunk after LLM response
            4. Build PSS messages (system + context, user)
            5. Call llm_call with PSS messages only
            6. Embed Q&A and update PSS state
            7. Append to full history for baseline tracking
            8. Return TurnResult with both token counts
        """
        self._turn_number += 1

        # Step 1
        user_embedding = self._embedding_service.get_embedding(user_message)

        # Step 2: serialize BEFORE storing the current message so we don't
        # self-retrieve with relevance 1.0.
        pss_context = self._serializer.serialize(
            self._pss_state,
            query_embedding=user_embedding,
            last_response=self._last_response,
        )

        # Step 4: build PSS messages
        pss_system = f"{self._system_prompt}\n\n{pss_context}"
        pss_messages = [
            ChatMessage(role="system", content=pss_system),
            ChatMessage(role="user", content=user_message),
        ]

        # Step 5: call the LLM
        response = self._llm_call(pss_messages) or ""

        # Real token counts from API; None if not available (no estimate fallback)
        real_usage = getattr(self._llm_call, "last_usage", None)
        if isinstance(real_usage, dict) and real_usage.get("prompt_tokens") is not None:
            pss_input_tokens: int | None = int(real_usage["prompt_tokens"])
        else:
            pss_input_tokens = None
        baseline_input_tokens: int | None = None

        self._last_response = response

        # Step 6: store Q&A pair as single combined chunk
        qa_chunk = f"Q: {user_message} A: {response}"
        qa_embedding = self._embedding_service.get_embedding(qa_chunk)
        if np.linalg.norm(qa_embedding) > 1e-8:
            self._pss_state.update(qa_embedding, qa_chunk[:500])

        # Step 7: append to full history for baseline tracking
        self._full_history.append(ChatMessage(role="user", content=user_message))
        self._full_history.append(ChatMessage(role="assistant", content=response))

        # Step 8: record and return
        phase = self._pss_state.phase_detector.current_phase
        output_tokens = estimate_tokens(response)

        self._token_counter.record_turn(
            TurnTokens(
                turn_number=self._turn_number,
                pss_input_tokens=pss_input_tokens,
                baseline_input_tokens=baseline_input_tokens,
                output_tokens=output_tokens,
                phase=phase,
            )
        )

        return TurnResult(
            response=response,
            pss_input_tokens=pss_input_tokens,
            baseline_input_tokens=baseline_input_tokens,
            pss_prompt=pss_context,
            phase=phase,
            turn_number=self._turn_number,
        )

    def get_summary(self) -> dict:
        """Return token usage summary from the counter."""
        return self._token_counter.get_summary()

    def print_report(self) -> None:
        """Print the formatted token comparison report."""
        self._token_counter.print_report()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _resolve_embedder(self) -> object:
        """Load a SentenceTransformer-backed embedder, or hard-fail.

        NO hash fallback — the library refuses to silently substitute
        random-noise vectors (see SemvecChatProxy module docstring and
        MIGRATION.md §What was intentionally dropped).
        """
        try:
            from sentence_transformers import SentenceTransformer
        except ImportError as e:
            raise RuntimeError(_MISSING_EMBEDDER_MSG) from e

        try:
            model = SentenceTransformer(
                self._pss_config.model_name,
                device=self._pss_config.device,
            )
        except Exception as e:
            raise RuntimeError(
                f"Failed to load SentenceTransformer model "
                f"{self._pss_config.model_name!r} on device "
                f"{self._pss_config.device!r}: {e}\n\n{_MISSING_EMBEDDER_MSG}"
            ) from e

        # sentence-transformers ≥ 3.x renamed the dim accessor; older
        # builds still ship the legacy name. hasattr-pick the new one
        # when present so we don't trip the FutureWarning.
        if hasattr(model, "get_embedding_dimension"):
            dim = model.get_embedding_dimension()
        else:
            dim = model.get_sentence_embedding_dimension()

        class _SentenceTransformerEmbedder:
            def __init__(self) -> None:
                self._m = model
                self._dim = int(dim or self._pss_config.dimension)

            def get_dimension(self) -> int:
                return self._dim

            def get_embedding(self, text: str) -> np.ndarray:
                if not text.strip():
                    return np.zeros(self._dim, dtype=np.float64)
                vec = self._m.encode(
                    text,
                    normalize_embeddings=True,
                    show_progress_bar=False,
                    convert_to_numpy=True,
                )
                return np.asarray(vec, dtype=np.float64)

        return _SentenceTransformerEmbedder()

    @staticmethod
    def _default_llm_call(messages: list[ChatMessage]) -> str:
        """Mock LLM that acknowledges the input (used when no LLM is wired)."""
        user_msgs = [m for m in messages if m.role == "user"]
        if user_msgs:
            content = user_msgs[-1].content
            preview = content[:100] + ("..." if len(content) > 100 else "")
            return f"Acknowledged: {preview}"
        return "Acknowledged."
