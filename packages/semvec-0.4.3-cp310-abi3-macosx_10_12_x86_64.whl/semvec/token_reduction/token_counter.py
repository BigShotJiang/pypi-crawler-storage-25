"""Token counting and comparison reporting for PSS vs baseline."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class TurnTokens:
    """Per-turn token measurement."""

    turn_number: int
    pss_input_tokens: int | None
    baseline_input_tokens: int | None
    output_tokens: int
    phase: str


_TIKTOKEN_ENCODER = None


def estimate_tokens(text: str) -> int:
    """Count tokens exactly using ``tiktoken`` (``cl100k_base``).

    There is NO heuristic fallback. The previous ``chars / 4``
    approximation was removed because it silently mis-counted real LLM
    prompt distributions (off by up to ~30% for short strings). If
    token parity matters for your benchmarks, the real count must come
    from either this function (tiktoken) or the LLM's own
    ``usage.prompt_tokens`` field.

    Raises:
        RuntimeError: If ``tiktoken`` is not installed. The message
            includes the exact install command and points at the LLM's
            usage dict as the alternative measurement source.
    """
    global _TIKTOKEN_ENCODER
    if _TIKTOKEN_ENCODER is None:
        try:
            import tiktoken
        except ImportError as e:
            raise RuntimeError(
                "estimate_tokens requires tiktoken — the chars/4 heuristic "
                "fallback was removed to prevent silent mis-counts.\n\n"
                "Install:\n"
                "    pip install tiktoken\n\n"
                "Or read the real token count from the LLM's response "
                "metadata: after an OpenAI-compatible call, "
                "`client.last_usage['prompt_tokens']` carries the exact "
                "server-side count."
            ) from e
        _TIKTOKEN_ENCODER = tiktoken.get_encoding("cl100k_base")
    return len(_TIKTOKEN_ENCODER.encode(text))


class TokenCounter:
    """Accumulates per-turn token data and produces comparison reports."""

    def __init__(self) -> None:
        self._turns: list[TurnTokens] = []

    def record_turn(self, turn: TurnTokens) -> None:
        """Record a single turn's token measurements."""
        self._turns.append(turn)

    @property
    def turns(self) -> list[TurnTokens]:
        return list(self._turns)

    def get_summary(self) -> dict:
        """Return aggregate statistics comparing PSS vs baseline."""
        if not self._turns:
            return {
                "total_turns": 0,
                "total_pss_tokens": None,
                "total_baseline_tokens": None,
                "total_output_tokens": 0,
                "savings_pct": None,
                "per_turn": [],
            }

        def _sum_or_none(values: list[int | None]) -> int | None:
            known = [v for v in values if v is not None]
            return sum(known) if known else None

        total_pss = _sum_or_none([t.pss_input_tokens for t in self._turns])
        total_baseline = _sum_or_none([t.baseline_input_tokens for t in self._turns])
        total_output = sum(t.output_tokens for t in self._turns)

        savings_pct = (
            round((1 - total_pss / total_baseline) * 100, 1)
            if total_pss is not None and total_baseline is not None and total_baseline > 0
            else None
        )

        per_turn = []
        for t in self._turns:
            turn_savings = (
                round((1 - t.pss_input_tokens / t.baseline_input_tokens) * 100, 1)
                if t.pss_input_tokens is not None
                and t.baseline_input_tokens is not None
                and t.baseline_input_tokens > 0
                else None
            )
            per_turn.append(
                {
                    "turn": t.turn_number,
                    "pss_tokens": t.pss_input_tokens,
                    "baseline_tokens": t.baseline_input_tokens,
                    "savings_pct": turn_savings,
                    "phase": t.phase,
                }
            )

        return {
            "total_turns": len(self._turns),
            "total_pss_tokens": total_pss,
            "total_baseline_tokens": total_baseline,
            "total_output_tokens": total_output,
            "savings_pct": savings_pct,
            "per_turn": per_turn,
        }

    def print_report(self) -> None:  # pragma: no cover — stdout rendering
        """Print a formatted comparison table to stdout."""
        summary = self.get_summary()
        if summary["total_turns"] == 0:
            print("No turns recorded.")
            return

        header = (
            f"{'Turn':>5} | {'Phase':<15} | {'PSS Tokens':>11} | "
            f"{'Baseline':>10} | {'Savings':>8}"
        )
        sep = "-" * len(header)

        print("\n" + sep)
        print("  PSS Token Reduction Report")
        print(sep)
        print(header)
        print(sep)

        def _fmt_int(v: int | None, width: int) -> str:
            return f"{v:>{width},}" if v is not None else f"{'N/A':>{width}}"

        def _fmt_pct(v: float | None) -> str:
            return f"{v:>7.1f}%" if v is not None else f"{'N/A':>8}"

        for t in summary["per_turn"]:
            print(
                f"{t['turn']:>5} | {t['phase']:<15} | "
                f"{_fmt_int(t['pss_tokens'], 11)} | "
                f"{_fmt_int(t['baseline_tokens'], 10)} | "
                f"{_fmt_pct(t['savings_pct'])}"
            )

        print(sep)
        tp = summary["total_pss_tokens"]
        tb = summary["total_baseline_tokens"]
        print(
            f"{'Total':>5} | {'':<15} | "
            f"{_fmt_int(tp, 11)} | {_fmt_int(tb, 10)} | "
            f"{_fmt_pct(summary['savings_pct'])}"
        )
        print(sep)
        print(f"  Output tokens: {summary['total_output_tokens']:,}")
        if tp is not None and tb is not None:
            print(f"  Net savings:   {tb - tp:,} input tokens")
        else:
            print("  Net savings:   N/A")
        print(sep + "\n")
