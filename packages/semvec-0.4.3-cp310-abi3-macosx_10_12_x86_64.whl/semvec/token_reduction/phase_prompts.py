"""Phase-aware instruction templates — thin forwarder to the Rust binary.

Up to and including ``0.2.0a7``, this module carried the LLM prompt
strings as a plain-text dict (``PHASE_PROMPTS``). The 0.2.0a8 audit
flagged that as a trivial-to-extract patent leak: any installed wheel
exposed the wording verbatim. The strings now live in the compiled
``semvec._core`` extension; this module forwards through the
internal entry point. Source-level inspection of this file no longer
reveals the prompt text, and as of 0.3.3 the Rust function is
registered under a private ``_internal_*`` name so it no longer
surfaces in ``dir(semvec._core)``.
"""

from __future__ import annotations

from semvec._core import _internal_phase_prompt as _core_get_phase_prompt


def get_phase_prompt(phase: str) -> str:
    """Return the LLM instruction template for the given PSS phase.

    Forwards to the internal Rust entry point. The phase strings
    recognised by the underlying implementation are
    ``initialization``, ``exploration``, ``convergence``,
    ``resonance``, ``stability``, ``instability``; any other input
    returns a generic fallback.
    """
    return _core_get_phase_prompt(phase)


__all__ = ["get_phase_prompt"]
