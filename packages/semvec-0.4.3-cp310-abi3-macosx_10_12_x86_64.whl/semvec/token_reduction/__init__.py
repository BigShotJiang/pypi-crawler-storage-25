"""Token-reduction utilities for converting semvec state into LLM context.

These modules sit on top of the Rust-backed ``SemvecState`` API and do
not contain any patent-pending algorithmic IP — they are pure Python for
easier downstream customisation.

Public surface (PEP-8 PascalCase):

- ``SemvecStateSerializer`` — fixed-budget prompt builder
- ``SemvecChatProxy`` — drop-in chat proxy with token accounting
- ``OpenAIClient`` / ``OllamaClient`` / ``BaseLLMClient`` — LLM client
  abstractions
- ``LLMConfig`` / ``create_llm_client`` — env-driven client factory
- ``ChatMessage`` / ``TurnResult`` / ``SerializerConfig`` — dataclasses
- ``TokenCounter`` / ``TurnTokens`` / ``estimate_tokens`` — accounting
- ``get_phase_prompt`` — phase-specific instruction lookup. The
  pre-0.2.0a8 plaintext ``PHASE_PROMPTS`` dict was retired; the
  prompt strings now live in the Rust binary and are reached via
  the function. The dict name no longer exists on this module.

Legacy aliases (``PSSChatProxy``, ``PSSStateSerializer``) remain
importable with a ``DeprecationWarning``. Scheduled for removal in
semvec 0.2.0.
"""

from __future__ import annotations

import warnings as _warnings
from typing import Any as _Any

from semvec.token_reduction.chat_proxy import (
    ChatMessage,
    SemvecChatProxy,
    TurnResult,
)
from semvec.token_reduction.llm_client import (
    BaseLLMClient,
    LLMConfig,
    OllamaClient,
    OpenAIClient,
    create_llm_client,
)
from semvec.token_reduction.phase_prompts import get_phase_prompt
from semvec.token_reduction.serializer import (
    SemvecStateSerializer,
    SerializerConfig,
)
from semvec.token_reduction.token_counter import (
    TokenCounter,
    TurnTokens,
    estimate_tokens,
)

__all__ = [
    "BaseLLMClient",
    "ChatMessage",
    "LLMConfig",
    "OllamaClient",
    "OpenAIClient",
    "SemvecChatProxy",
    "SemvecStateSerializer",
    "SerializerConfig",
    "TokenCounter",
    "TurnResult",
    "TurnTokens",
    "create_llm_client",
    "estimate_tokens",
    "get_phase_prompt",
]


# ---------------------------------------------------------------------------
# Deprecated aliases — emit a DeprecationWarning on access, resolve to the
# current PEP-8 names. Scheduled for removal in 0.2.0.

_DEPRECATED_ALIASES: dict[str, tuple[str, _Any]] = {
    "PSSChatProxy": ("SemvecChatProxy", SemvecChatProxy),
    "PSSStateSerializer": ("SemvecStateSerializer", SemvecStateSerializer),
}


def __getattr__(name: str) -> _Any:
    alias = _DEPRECATED_ALIASES.get(name)
    if alias is not None:
        replacement_name, obj = alias
        _warnings.warn(
            f"{name} is deprecated and will be removed in semvec 0.2.0. "
            f"Use {replacement_name} instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return obj
    raise AttributeError(f"module 'semvec.token_reduction' has no attribute {name!r}")
