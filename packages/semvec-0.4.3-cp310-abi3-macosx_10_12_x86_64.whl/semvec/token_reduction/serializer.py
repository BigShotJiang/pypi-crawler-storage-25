"""Serialize PSS state into a compact prompt string for LLM context injection."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

import numpy as np

from semvec import safe_cosine_similarity
from semvec.token_reduction.phase_prompts import get_phase_prompt

if TYPE_CHECKING:
    from semvec import MemoryUnit, PSS_State_V4


_DEFAULTS = None


def _defaults() -> dict:
    """Lazy-load the serializer-tuning defaults from the Rust core.

    Pre-0.3.0a1 this module shipped the numbers (`top_k=5`,
    `max_memory_chars=200`, `max_last_response_chars=500`) as
    Python literals — that turned the `cat .../serializer.py` view
    into a complete tuning-study leak. The numbers now live in the
    compiled extension and are read on demand, so anyone reading
    this source sees only the variable names.
    """
    global _DEFAULTS
    if _DEFAULTS is None:
        from semvec._core import _internal_tuning_defaults

        _DEFAULTS = _internal_tuning_defaults()
    return _DEFAULTS


@dataclass
class SerializerConfig:
    """Configuration for PSS state serialization."""

    top_k: int | None = None
    max_memory_chars: int | None = None
    include_phase_prompt: bool = True
    include_metrics: bool = True
    include_last_response: bool = True
    max_last_response_chars: int | None = None

    def __post_init__(self) -> None:
        d = _defaults()
        if self.top_k is None:
            self.top_k = d["serializer_top_k"]
        if self.max_memory_chars is None:
            self.max_memory_chars = d["serializer_max_memory_chars"]
        if self.max_last_response_chars is None:
            self.max_last_response_chars = d["serializer_max_last_response_chars"]


class SemvecStateSerializer:
    """Converts a PSS state object into a compact prompt string.

    The output has a fixed token budget (~150-350 tokens) regardless
    of conversation length, achieving O(1) input cost per turn.
    """

    def __init__(self, config: SerializerConfig | None = None) -> None:
        self.config = config or SerializerConfig()

    def serialize(
        self,
        pss_state: PSS_State_V4,
        query_embedding: np.ndarray | None = None,
        last_response: str | None = None,
        query_text: str | None = None,
    ) -> str:
        """Serialize the PSS state into a compact context string."""
        phase = pss_state.phase_detector.current_phase
        turn = pss_state.interaction_count
        total_memories = pss_state.get_total_stored()

        # Section 1: Header
        sections: list[str] = [
            f"[PSS Context | Phase: {phase} | Turn {turn} | {total_memories} memories]"
        ]

        # Section 2: Phase prompt
        if self.config.include_phase_prompt:
            sections.append(get_phase_prompt(phase))

        # Section 3: Metrics summary
        if self.config.include_metrics and pss_state.beta_history:
            beta = pss_state.beta_history[-1]
            fsm = pss_state.fsm_history[-1] if pss_state.fsm_history else 0.0
            sections.append(f"State: beta={beta:.3f}, fsm={fsm:.3f}")

        # Section 4: Topic-switch hint (the Rust core exposes this via the
        # last update result; absent when no update has happened yet.)
        topic_switch = getattr(pss_state, "_topic_switch_magnitude", 0.0)
        if topic_switch > 0.1:
            sections.append(
                f"[Topic shift detected (magnitude: {topic_switch:.2f}) - adapt to new direction]"
            )

        # Section 5: Relevant memories
        query = (
            np.asarray(pss_state.semantic_state)
            if query_embedding is None
            else np.asarray(query_embedding)
        )

        if turn > 0 and np.linalg.norm(query) > 1e-8:
            memories = pss_state.memory.get_relevant_memories(query, top_k=self.config.top_k)
            if memories:
                sections.append(self._format_memories(memories, query))

        # Section 6: Last response verbatim buffer
        if self.config.include_last_response and last_response and last_response.strip():
            truncated = last_response[: self.config.max_last_response_chars]
            sections.append(f"Last response:\n  {truncated}")

        # Section 7: Literal cache — verbatim code entities matching the query
        literal_cache = getattr(pss_state, "literal_cache", None)
        if literal_cache is not None and query_text:
            matches = literal_cache.query(query_text, max_results=8)
            if matches:
                sections.append(literal_cache.to_context_block(matches))

        return "\n".join(sections)

    def _format_memories(
        self,
        memories: list[MemoryUnit],
        query: np.ndarray,
    ) -> str:
        """Format retrieved memories with relevance scores."""
        lines = ["Relevant context:"]
        for i, mem in enumerate(memories, 1):
            score = safe_cosine_similarity(query, mem.embedding)
            text = mem.text[: self.config.max_memory_chars].replace("\n", " ")
            lines.append(f"  {i}. [{score:.2f}] {text}")
        return "\n".join(lines)
