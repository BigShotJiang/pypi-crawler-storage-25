"""Configuration container for the Compliance Pack.

Reads ``SEMVEC_ENABLE_*`` and retention env vars with conservative
defaults — every feature is **off** unless the operator opts in.
Boolean parsing accepts ``1`` / ``true`` / ``yes`` / ``on`` (case-
insensitive); anything else is treated as ``False``.

Validation:
* ``retention_days_chat`` and ``retention_days_audit`` must be
  non-negative. ``0`` means *expire immediately on next sweep* — the
  retention sweeper does not crash on it but the operator should set
  a deliberate value.
"""

from __future__ import annotations

import os
from dataclasses import dataclass


def _parse_bool(value: str | None) -> bool:
    if value is None:
        return False
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _parse_int(value: str | None, default: int) -> int:
    if value is None or value == "":
        return default
    try:
        return int(value)
    except ValueError as e:
        raise ValueError(f"compliance config: cannot parse {value!r} as int") from e


@dataclass(frozen=True)
class ComplianceConfig:
    enable_event_store: bool = False
    enable_retention_sweeper: bool = False
    enable_hmac_signing: bool = False
    enable_rs256_jwt: bool = False
    enable_numeric_extractor: bool = False
    retention_days_chat: int = 30
    retention_days_audit: int = 2555  # 7 years — typical legal floor

    @classmethod
    def from_env(cls) -> ComplianceConfig:
        retention_chat = _parse_int(os.environ.get("SEMVEC_RETENTION_DAYS_CHAT"), 30)
        retention_audit = _parse_int(os.environ.get("SEMVEC_RETENTION_DAYS_AUDIT"), 2555)
        if retention_chat < 0 or retention_audit < 0:
            raise ValueError(
                "compliance config: retention day counts must be non-negative "
                f"(got chat={retention_chat}, audit={retention_audit})"
            )
        return cls(
            enable_event_store=_parse_bool(os.environ.get("SEMVEC_ENABLE_EVENT_STORE")),
            enable_retention_sweeper=_parse_bool(os.environ.get("SEMVEC_ENABLE_RETENTION_SWEEPER")),
            enable_hmac_signing=_parse_bool(os.environ.get("SEMVEC_ENABLE_HMAC_SIGNING")),
            enable_rs256_jwt=_parse_bool(os.environ.get("SEMVEC_ENABLE_RS256_JWT")),
            enable_numeric_extractor=_parse_bool(os.environ.get("SEMVEC_ENABLE_NUMERIC_EXTRACTOR")),
            retention_days_chat=retention_chat,
            retention_days_audit=retention_audit,
        )


__all__ = ["ComplianceConfig"]
