"""HMAC request-signing facade — calls into the Rust core.

Wire format (AWS-SigV4-style):

    canonical_request = METHOD + "\\n" + PATH + "\\n" + SHA256(body)
                       + "\\n" + TIMESTAMP + "\\n" + NONCE
    signature         = HMAC-SHA256(user_secret, canonical_request)

The Rust core (``src/compliance.rs``) does the SHA-256 + HMAC +
constant-time verify. This module is the Python-friendly entry
point used by the FastAPI middleware and by client libraries that
need to sign their requests.
"""

from __future__ import annotations

from semvec._core import (
    _internal_hmac_canonical,
    _internal_hmac_sign,
    _internal_hmac_verify,
)


def canonical_request(
    *,
    method: str,
    path: str,
    body: bytes,
    timestamp: str,
    nonce: str,
) -> str:
    """Build the canonical request string used as HMAC input.

    ``method`` is upper-cased automatically; everything else is
    embedded verbatim. ``body`` is hashed inline so the signature
    commits to its content.
    """
    return _internal_hmac_canonical(method, path, body, timestamp, nonce)


def sign_request(
    *,
    secret: bytes,
    method: str,
    path: str,
    body: bytes,
    timestamp: str,
    nonce: str,
) -> str:
    """HMAC-SHA256 over the canonical request. Returns lowercase hex."""
    canon = canonical_request(
        method=method,
        path=path,
        body=body,
        timestamp=timestamp,
        nonce=nonce,
    )
    return _internal_hmac_sign(secret, canon)


def verify_signed_request(
    *,
    secret: bytes,
    method: str,
    path: str,
    body: bytes,
    timestamp: str,
    nonce: str,
    signature_hex: str,
) -> bool:
    """Constant-time verification. Never raises — returns ``False``
    on malformed input (wrong length, non-hex chars)."""
    canon = canonical_request(
        method=method,
        path=path,
        body=body,
        timestamp=timestamp,
        nonce=nonce,
    )
    return _internal_hmac_verify(secret, canon, signature_hex)


__all__ = [
    "canonical_request",
    "sign_request",
    "verify_signed_request",
]
