"""Regex-based extractors for numeric / date / identifier facts.

Run on the *write* path of the PSS pipeline — they peel verbatim,
exact values out of free-form text **before** the input is folded
into the EMA vector. Extracted facts go to the LiteralCache so they
survive the lossiness of embedding-based retrieval.

Design rules:

* No LLM in the hot path — pure regex
* ``Decimal`` for numeric values to preserve cent precision
* tz-aware ``datetime`` for dates; bare dates default to UTC midnight
* Strict whitelist of supported units to avoid false positives
* IBAN validation via the ISO 13616 mod-97 checksum
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from decimal import Decimal
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from semvec import CodeEntity


# ---------------------------------------------------------------------------
# Data classes


@dataclass(frozen=True)
class _BaseFact:
    raw: str
    start: int
    end: int

    def _entity_key(self) -> str:
        return self.raw

    def to_code_entity(self) -> CodeEntity:
        from semvec import CodeEntity

        return CodeEntity(
            key=self._entity_key(),
            kind=self.kind,  # type: ignore[attr-defined]
            value=self._entity_value(),
            context=self._entity_context(),
        )

    def _entity_value(self) -> str:
        raise NotImplementedError

    def _entity_context(self) -> str:
        return f"offset={self.start}:{self.end}"


@dataclass(frozen=True)
class NumericFact(_BaseFact):
    value: Decimal = field(default_factory=lambda: Decimal(0))
    unit: str = ""
    kind: str = "numeric"

    def _entity_value(self) -> str:
        return f"{self.value} {self.unit}".strip()


@dataclass(frozen=True)
class DateFact(_BaseFact):
    value: datetime = field(default_factory=lambda: datetime(1970, 1, 1, tzinfo=timezone.utc))
    kind: str = "date"

    def _entity_value(self) -> str:
        return self.value.isoformat()


@dataclass(frozen=True)
class IdFact(_BaseFact):
    value: str = ""
    id_type: str = ""
    kind: str = "identifier"

    def _entity_value(self) -> str:
        return self.value

    def _entity_context(self) -> str:
        return f"type={self.id_type}; offset={self.start}:{self.end}"


Fact = NumericFact | DateFact | IdFact


# ---------------------------------------------------------------------------
# Numeric extraction

_UNIT_MAP: dict[str, str] = {
    "€": "EUR",
    "EUR": "EUR",
    "EURO": "EUR",
    "$": "USD",
    "USD": "USD",
    "kWh": "kWh",
    "KWH": "kWh",
    "%": "%",
    "kg": "kg",
    "KG": "kg",
    "h": "h",
    "g": "g",
    "MB": "MB",
    "GB": "GB",
    "TB": "TB",
}

_NUMBER_PATTERN = re.compile(
    r"""
    (?P<num>-?\d{1,3}(?:[.,]\d{3})*(?:[.,]\d+)?|-?\d+(?:[.,]\d+)?)
    \s*
    (?P<unit>€|EUR|EURO|\$|USD|kWh|KWH|%|kg|KG|MB|GB|TB)
    """,
    re.IGNORECASE | re.VERBOSE,
)


def _normalise_number(raw: str) -> Decimal | None:
    """Convert a localised numeric string to ``Decimal``.

    * Both ``.`` and ``,`` present: the rightmost separator is the
      decimal mark; the other is a thousand separator.
    * Only ``,``: decimal mark (DE/EU style).
    * Only ``.``: decimal mark (EN/US style) **unless** there are
      multiple dots — that is treated as a version and rejected.
    """
    if raw.count(".") >= 2 and "," not in raw:
        return None
    txt = raw.strip()
    has_comma = "," in txt
    has_dot = "." in txt
    if has_comma and has_dot:
        if txt.rfind(",") > txt.rfind("."):
            txt = txt.replace(".", "").replace(",", ".")
        else:
            txt = txt.replace(",", "")
    elif has_comma:
        txt = txt.replace(",", ".")
    try:
        return Decimal(txt)
    except Exception:
        return None


def extract_numerics(text: str) -> list[NumericFact]:
    out: list[NumericFact] = []
    for m in _NUMBER_PATTERN.finditer(text):
        unit_raw = m.group("unit")
        unit = _UNIT_MAP.get(unit_raw, _UNIT_MAP.get(unit_raw.upper(), unit_raw))
        value = _normalise_number(m.group("num"))
        if value is None:
            continue
        out.append(
            NumericFact(
                raw=m.group(0),
                start=m.start(),
                end=m.end(),
                value=value,
                unit=unit,
            )
        )
    return out


# ---------------------------------------------------------------------------
# Date extraction

_DATE_PATTERNS: tuple[tuple[re.Pattern[str], str], ...] = (
    (
        re.compile(
            r"\b(?P<y>\d{4})-(?P<m>\d{2})-(?P<d>\d{2})" r"(?:[ T](?P<hh>\d{2}):(?P<mm>\d{2}))?\b"
        ),
        "iso",
    ),
    (re.compile(r"\b(?P<d>\d{2})\.(?P<m>\d{2})\.(?P<y>\d{4})\b"), "de"),
    (re.compile(r"\b(?P<m>\d{2})/(?P<d>\d{2})/(?P<y>\d{4})\b"), "us"),
)


def extract_dates(text: str) -> list[DateFact]:
    out: list[DateFact] = []
    seen: set[tuple[int, int]] = set()
    for pattern, _kind in _DATE_PATTERNS:
        for m in pattern.finditer(text):
            span = (m.start(), m.end())
            if span in seen:
                continue
            seen.add(span)
            try:
                year = int(m.group("y"))
                month = int(m.group("m"))
                day = int(m.group("d"))
                hour = int(m.group("hh")) if m.groupdict().get("hh") else 0
                minute = int(m.group("mm")) if m.groupdict().get("mm") else 0
                dt = datetime(year, month, day, hour, minute, tzinfo=timezone.utc)
            except (ValueError, IndexError):
                continue
            out.append(
                DateFact(
                    raw=m.group(0),
                    start=m.start(),
                    end=m.end(),
                    value=dt,
                )
            )
    return out


# ---------------------------------------------------------------------------
# Identifier extraction

_UUID_PATTERN = re.compile(
    r"\b[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-" r"[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\b"
)
_IBAN_PATTERN = re.compile(r"\b[A-Z]{2}\d{2}(?:\s?\d{4}){3,7}\s?\d{0,4}\b")
_VAT_DE_PATTERN = re.compile(r"\bDE\d{9}\b")


def _validate_iban(raw: str) -> bool:
    s = raw.replace(" ", "").upper()
    if len(s) < 15 or len(s) > 34:
        return False
    rearranged = s[4:] + s[:4]
    digits: list[str] = []
    for ch in rearranged:
        if ch.isdigit():
            digits.append(ch)
        elif ch.isalpha():
            digits.append(str(ord(ch) - 55))
        else:
            return False
    try:
        return int("".join(digits)) % 97 == 1
    except ValueError:
        return False


def extract_identifiers(text: str) -> list[IdFact]:
    out: list[IdFact] = []

    for m in _UUID_PATTERN.finditer(text):
        out.append(
            IdFact(
                raw=m.group(0),
                start=m.start(),
                end=m.end(),
                value=m.group(0),
                id_type="uuid",
            )
        )

    for m in _IBAN_PATTERN.finditer(text):
        candidate = m.group(0)
        if _validate_iban(candidate):
            out.append(
                IdFact(
                    raw=candidate,
                    start=m.start(),
                    end=m.end(),
                    value=candidate.replace(" ", ""),
                    id_type="iban",
                )
            )

    for m in _VAT_DE_PATTERN.finditer(text):
        out.append(
            IdFact(
                raw=m.group(0),
                start=m.start(),
                end=m.end(),
                value=m.group(0),
                id_type="vat_de",
            )
        )

    return out


def extract_facts(text: str) -> list[Fact]:
    """Convenience wrapper — returns *all* fact kinds in one pass."""
    facts: list[Fact] = []
    facts.extend(extract_numerics(text))
    facts.extend(extract_dates(text))
    facts.extend(extract_identifiers(text))
    return facts


__all__ = [
    "NumericFact",
    "DateFact",
    "IdFact",
    "Fact",
    "extract_numerics",
    "extract_dates",
    "extract_identifiers",
    "extract_facts",
]
