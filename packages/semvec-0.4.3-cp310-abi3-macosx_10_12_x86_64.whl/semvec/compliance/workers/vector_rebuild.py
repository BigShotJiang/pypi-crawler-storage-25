"""Async vector-rebuild worker.

After a DELETE in the event store the derived state vector is stale
until the remaining events get folded back into a fresh state. The
worker decouples that replay from the request path:

* The DELETE endpoint enqueues a rebuild and returns immediately.
* This worker drains the queue in a background thread and writes
  the rebuilt vector back through a caller-supplied
  :type:`StateRebuildSink`.

The default :class:`InMemoryRebuildWorker` is enough for tests, the
demo, and single-process deployments. Multi-replica servers should
swap it for a Celery / RQ / Postgres-NOTIFY backed implementation
that satisfies the same enqueue / flush surface — that swap is a
half-day port.
"""

from __future__ import annotations

import threading
from collections.abc import Callable
from queue import Queue
from typing import TYPE_CHECKING, Protocol

import numpy as np

from semvec.compliance.event_replay import EventReplayService

if TYPE_CHECKING:
    from semvec import SemvecConfig
    from semvec.compliance.event_store import EventStore


class StateRebuildSink(Protocol):
    """Where the worker writes the rebuilt vector. Implementations
    persist into whatever backing store the API layer uses for the
    *current* state vector — typically the session-manager."""

    def __call__(self, user_id: str, semantic_state: np.ndarray) -> None: ...


class InMemoryRebuildWorker:
    """Single-threaded background worker.

    The worker spins up one daemon thread on first enqueue and keeps
    it alive for the process lifetime. ``flush()`` blocks until every
    queued task has been drained — used by tests and by graceful-
    shutdown hooks. ``shutdown()`` stops the thread for good.
    """

    _SENTINEL = object()

    def __init__(
        self,
        *,
        store: EventStore,
        sink: StateRebuildSink,
        config_factory: Callable[[], SemvecConfig],
        subject: str = "anonymous",
    ) -> None:
        self._store = store
        self._sink = sink
        self._config_factory = config_factory
        self._subject = subject
        self._queue: Queue = Queue()
        self._thread: threading.Thread | None = None
        self._lock = threading.Lock()

    def _ensure_thread(self) -> None:
        with self._lock:
            if self._thread is not None and self._thread.is_alive():
                return
            t = threading.Thread(target=self._run, daemon=True)
            t.start()
            self._thread = t

    def _run(self) -> None:
        from semvec import SemvecState

        replay = EventReplayService(store=self._store)
        while True:
            item = self._queue.get()
            try:
                if item is self._SENTINEL:
                    return
                user_id = item
                state = SemvecState(
                    self._config_factory(),
                    _test_subject_override=self._subject,
                )
                replay.replay(state, user_id=user_id)
                self._sink(user_id, np.asarray(state.semantic_state))
            finally:
                self._queue.task_done()

    def enqueue(self, user_id: str) -> None:
        self._ensure_thread()
        self._queue.put(user_id)

    def flush(self) -> None:
        self._queue.join()

    def shutdown(self) -> None:
        with self._lock:
            t = self._thread
            if t is None:
                return
            self._queue.put(self._SENTINEL)
            t.join(timeout=5.0)
            self._thread = None


__all__ = ["InMemoryRebuildWorker", "StateRebuildSink"]
