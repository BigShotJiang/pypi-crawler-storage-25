"""Replay events from the store back into a :class:`SemvecState`.

The store is the authoritative source for what the user has seen.
The state vector + memory tiers + literal cache are derived; if any
of them gets corrupted (or the operator wants to inspect "what does
the state look like with event X removed?"), :class:`EventReplayService`
rebuilds them deterministically.

Replay calls :meth:`SemvecState._internal_record_replay_step` rather
than the public ``update()`` so the per-state community-tier
rate-limit (100/s) does not lock the replay path out of its own
event log on a thousand-event rebuild.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from semvec import SemvecState
    from semvec.compliance.event_store import EventStore


class EventReplayService:
    """Rebuilds derived state by folding events back into a fresh
    :class:`SemvecState`.

    Stateless aside from the store reference; safe to share across
    threads.
    """

    def __init__(self, *, store: EventStore) -> None:
        self._store = store

    def replay(self, state: SemvecState, *, user_id: str) -> int:
        """Apply every event for ``user_id`` to ``state`` in
        chronological order.

        Returns the number of events folded in. The caller is
        responsible for supplying a fresh state — the service does
        not reset the input.
        """
        events = self._store.list_by_user(user_id)
        for ev in events:
            state._internal_record_replay_step(ev.embedding, ev.content)
        return len(events)


__all__ = ["EventReplayService"]
