"""DeletionCertificate — RSA-PSS-SHA256 signed receipt for DSGVO Art. 17.

The certificate carries a small, JSON-serialisable payload (user id,
event count, timestamp, reason, issuer) that is signed with the
operator's compliance private key. A customer can verify the
certificate against the matching public key without contacting our
infrastructure.

**Algorithm**: RSA-PSS with SHA-256 (RFC 8017 §8.1) — the only
algorithm wired here. Pass an RSA private key (PEM-encoded PKCS#8,
2048 bits or stronger). Ed25519 keys are *not* accepted; an
``AttributeError`` from the cryptography lib bubbles up to the
caller. Ed25519 support is roadmapped for a future release.

Key sources at runtime:

* ``SEMVEC_COMPLIANCE_PRIVKEY_FILE`` — path to the PEM private key.
* ``SEMVEC_COMPLIANCE_PRIVKEY_PEM`` — full PEM body in the env var.
* ``SEMVEC_COMPLIANCE_PUBKEY_FILE`` / ``SEMVEC_COMPLIANCE_PUBKEY_PEM``
  — same idea for the verify side.

Either ``_FILE`` or ``_PEM`` is sufficient; both can be set, the file
wins. Tests pass PEM bytes directly.
"""

from __future__ import annotations

import base64
import json
import os
from dataclasses import asdict, dataclass, replace
from datetime import datetime
from typing import Any

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding


@dataclass(frozen=True)
class DeletionCertificate:
    user_id: str
    event_count: int
    deleted_at: datetime
    reason: str  # "user_request", "ttl_expired"
    issuer: str  # tenant or operator identifier
    signature_b64: str = ""

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["deleted_at"] = self.deleted_at.isoformat()
        return d


def canonical_payload(cert: DeletionCertificate) -> bytes:
    """Stable canonical-JSON representation for signing.

    Sorted keys, ASCII-only, deterministic separators — two
    DeletionCertificate instances that compare equal produce the
    same canonical payload regardless of construction order.
    """
    body = {
        "user_id": cert.user_id,
        "event_count": cert.event_count,
        "deleted_at": cert.deleted_at.isoformat(),
        "reason": cert.reason,
        "issuer": cert.issuer,
    }
    return json.dumps(
        body,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
    ).encode("utf-8")


def _resolve_priv_pem(priv_pem: bytes | None) -> bytes:
    if priv_pem is not None:
        return priv_pem
    file_path = os.environ.get("SEMVEC_COMPLIANCE_PRIVKEY_FILE")
    if file_path:
        with open(file_path, "rb") as f:
            return f.read()
    env_body = os.environ.get("SEMVEC_COMPLIANCE_PRIVKEY_PEM")
    if env_body:
        return env_body.encode("utf-8")
    raise RuntimeError(
        "compliance private key missing — set "
        "SEMVEC_COMPLIANCE_PRIVKEY_FILE or pass priv_pem= explicitly"
    )


def _resolve_pub_pem(pub_pem: bytes | None) -> bytes:
    """Resolve the verify-side public key in fixed precedence order.

    1. explicit ``pub_pem`` kwarg
    2. ``SEMVEC_COMPLIANCE_PUBKEY_FILE`` env var (path)
    3. ``SEMVEC_COMPLIANCE_PUBKEY_PEM`` env var (PEM body)
    4. embedded pubkey baked into the wheel at build time by
       ``scripts/embed_compliance_pubkey.py``

    The embedded fallback (4) lets a customer who pulls the wheel
    verify a DeletionCertificate without configuring anything.
    Operators who run their own deployment override (1)–(3).
    """
    if pub_pem is not None:
        return pub_pem
    file_path = os.environ.get("SEMVEC_COMPLIANCE_PUBKEY_FILE")
    if file_path:
        with open(file_path, "rb") as f:
            return f.read()
    env_body = os.environ.get("SEMVEC_COMPLIANCE_PUBKEY_PEM")
    if env_body:
        return env_body.encode("utf-8")
    # Lowest-precedence fallback: build-time-embedded pubkey.
    from semvec.compliance import _embedded_pubkey

    embedded = _embedded_pubkey.embedded_pubkey_pem()
    if embedded:
        return embedded
    raise RuntimeError(
        "compliance public key missing — set "
        "SEMVEC_COMPLIANCE_PUBKEY_FILE / SEMVEC_COMPLIANCE_PUBKEY_PEM, "
        "pass pub_pem= explicitly, or rebuild the wheel with the "
        "SEMVEC_COMPLIANCE_PUBKEY_PEM build-time secret set."
    )


def sign_certificate(
    cert: DeletionCertificate,
    *,
    priv_pem: bytes | None = None,
) -> DeletionCertificate:
    """Sign ``cert`` with the operator's RSA-PSS-SHA256 key.

    Returns a new :class:`DeletionCertificate` with ``signature_b64``
    populated — caller should treat the returned instance as the
    authoritative one.
    """
    priv_bytes = _resolve_priv_pem(priv_pem)
    priv = serialization.load_pem_private_key(priv_bytes, password=None)
    payload = canonical_payload(cert)
    sig = priv.sign(
        payload,
        padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=padding.PSS.MAX_LENGTH),
        hashes.SHA256(),
    )
    return replace(cert, signature_b64=base64.b64encode(sig).decode("ascii"))


def verify_certificate(
    cert: DeletionCertificate,
    *,
    pub_pem: bytes | None = None,
) -> bool:
    """Return True iff ``cert.signature_b64`` is a valid RSA-PSS
    signature over ``cert``'s canonical payload."""
    if not cert.signature_b64:
        return False
    pub_bytes = _resolve_pub_pem(pub_pem)
    pub = serialization.load_pem_public_key(pub_bytes)
    try:
        pub.verify(
            base64.b64decode(cert.signature_b64),
            canonical_payload(cert),
            padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=padding.PSS.MAX_LENGTH),
            hashes.SHA256(),
        )
        return True
    except InvalidSignature:
        return False


__all__ = [
    "DeletionCertificate",
    "canonical_payload",
    "sign_certificate",
    "verify_certificate",
]
