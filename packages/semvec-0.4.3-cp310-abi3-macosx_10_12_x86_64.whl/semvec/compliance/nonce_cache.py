"""Replay defence for HMAC-signed requests.

Once a (user_id, nonce) pair has been observed within the configured
window the signature is rejected even if it verifies — this defeats
the trivial replay attack. The cache window must match the timestamp
window the server enforces (default ±60 s).

Two backends ship:

* :class:`InMemoryNonceCache` — single-process default, fine for
  unit tests, the demo, and small single-replica deployments.
* :class:`PostgresNonceCache` (skeleton; not enabled until Phase 7) —
  cluster-safe replay defence backed by a Postgres TTL table.

The seam is module-level ``_now()`` so tests can monkeypatch a
deterministic clock.
"""

from __future__ import annotations

import time
from threading import Lock


def _now() -> float:
    """Monotonic-ish wall clock. Tests monkeypatch this."""
    return time.time()


class InMemoryNonceCache:
    """In-process nonce cache.

    Keeps ``(user_id, nonce) -> first_seen_at`` and prunes entries
    older than ``window_seconds`` lazily on each ``observe_nonce``
    call. Thread-safe.
    """

    def __init__(self, window_seconds: float = 60.0) -> None:
        self._window = float(window_seconds)
        self._seen: dict[tuple[str, str], float] = {}
        self._lock = Lock()

    def observe_nonce(self, user_id: str, nonce: str) -> bool:
        """Return ``True`` if this is the first time we see the
        ``(user_id, nonce)`` pair within the window — caller proceeds.
        Return ``False`` if the pair was already observed inside the
        window (replay).
        """
        now = _now()
        cutoff = now - self._window
        key = (user_id, nonce)
        with self._lock:
            self._prune(cutoff)
            seen_at = self._seen.get(key)
            if seen_at is not None and seen_at >= cutoff:
                return False
            self._seen[key] = now
            return True

    def _prune(self, cutoff: float) -> None:
        # Lazy pruning: cheap when the cache is small (typical), and
        # the per-entry cost stays O(1) amortised. For high-volume
        # deployments swap this with the Postgres backend.
        stale = [k for k, ts in self._seen.items() if ts < cutoff]
        for k in stale:
            del self._seen[k]

    def __len__(self) -> int:
        return len(self._seen)


__all__ = ["InMemoryNonceCache"]
