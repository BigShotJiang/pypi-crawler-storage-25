"""RS256 user-JWT verification facade.

Distinct from the licence JWT (Ed25519 against the wheel-embedded
operator key). RS256 user-JWTs are signed with the *caller's*
private key — typically held in their browser's WebCrypto store or a
hardware token, never on the server. The server registers each
user's public key once via :class:`KeyRegistry` and verifies every
incoming request against it.

Public surface:

* :class:`UserJwtClaims` — typed result of a successful verify.
* :func:`verify_user_jwt` — Python facade over the
  ``_internal_verify_user_rs256_jwt`` PyO3 binding.
"""

from __future__ import annotations

from dataclasses import dataclass

from semvec._core import _internal_verify_user_rs256_jwt


@dataclass(frozen=True)
class UserJwtClaims:
    subject: str
    expiry_unix: int
    issued_at_unix: int | None
    scope: list[str]


def verify_user_jwt(token: str, *, public_key_pem: bytes) -> UserJwtClaims:
    """Verify ``token`` against ``public_key_pem`` (RS256 SPKI PEM).

    Raises :class:`semvec.LicenseError` on signature / format
    failures and :class:`semvec.LicenseExpiredError` on an
    expired ``exp`` claim. Tokens missing the required ``sub``
    claim are rejected as malformed.
    """
    raw = _internal_verify_user_rs256_jwt(token, public_key_pem)
    return UserJwtClaims(
        subject=raw["subject"],
        expiry_unix=int(raw["expiry_unix"]),
        issued_at_unix=raw.get("issued_at_unix"),
        scope=list(raw.get("scope") or []),
    )


__all__ = ["UserJwtClaims", "verify_user_jwt"]
