"""Semvec Compliance Pack — enterprise / regulated-industry features.

Adds the data-protection and cryptographic verification layers that
regulated tenants need on top of the base ``SemvecState``:

* **Event-Sourcing** — append-only event store, replayable into the
  three-tier memory + EMA vector + literal cache.
* **30-day retention sweeper** with optional GDPR Art. 17 forget
  endpoint and a signed deletion certificate.
* **NumericFact / DateFact / IdFact extractors** — verbatim,
  ``Decimal``-precision facts that bypass embedding compression.
* **RS256 user-JWT** + **HMAC request signing** for cryptographically
  verifiable auth.

Every feature is gated behind a ``SEMVEC_ENABLE_*`` environment
variable, all defaulting to ``False`` so an existing deployment that
imports ``semvec`` does not pick up new behaviour by accident.

Public surface here re-exports ``ComplianceConfig`` so callers can do
``from semvec.compliance import ComplianceConfig``. Submodules
(``event_store``, ``extractors``, ``retention``, ...) are imported
lazily by the consumers that need them.
"""

from __future__ import annotations

from semvec.compliance.config import ComplianceConfig

__all__ = ["ComplianceConfig"]
