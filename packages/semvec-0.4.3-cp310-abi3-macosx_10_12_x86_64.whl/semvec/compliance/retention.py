"""Retention sweeper + DSGVO Art. 17 forget facade.

The sweeper runs as a cron job (typically nightly): it walks every
user in the event store and purges anything older than
``retention_days``. The forget facade is the synchronous DSGVO
counterpart — wipes all events for one user immediately and returns
a signed :class:`DeletionCertificate` the customer can verify.

Both paths emit :class:`AuditLogEntry` records. Both paths are
idempotent — a second call is a no-op when the previous call left
nothing to do.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import TYPE_CHECKING

from semvec.compliance.audit import AuditLogEntry, InMemoryAuditLog
from semvec.compliance.certificates import (
    DeletionCertificate,
    _resolve_priv_pem,
    sign_certificate,
)

if TYPE_CHECKING:
    from semvec.compliance.audit import AuditLog
    from semvec.compliance.event_store import EventStore


@dataclass
class SweepReport:
    deleted_total: int = 0
    deleted_per_user: dict[str, int] = field(default_factory=dict)
    cutoff_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    dry_run: bool = False


def _all_user_ids(store: EventStore) -> list[str]:
    """Walk the store and collect distinct user_ids.

    The :class:`EventStore` ABC does not require a ``users()``
    method; we lean on the SQLite backend's introspection capability
    via a small protocol check, falling back to a no-op.
    """
    listing = getattr(store, "list_user_ids", None)
    if callable(listing):
        return list(listing())
    # Generic fallback: enumerate via SQL on the SQLite backend.
    conn = getattr(store, "_connect", None)
    if conn is None:
        return []
    with conn() as c:
        rows = c.execute("SELECT DISTINCT user_id FROM memory_events").fetchall()
    return [r["user_id"] for r in rows]


class RetentionSweeper:
    """Walk the event store and purge anything older than the
    configured retention window.

    Parameters
    ----------
    store:
        The :class:`EventStore` to sweep.
    audit_log:
        Optional audit log; defaults to an in-memory log so even a
        no-config caller gets an inspectable record.
    issuer:
        Identifier folded into every audit entry (typically the
        deployment tenant name).
    """

    def __init__(
        self,
        *,
        store: EventStore,
        audit_log: AuditLog | None = None,
        issuer: str = "semvec-compliance",
    ) -> None:
        self._store = store
        self._audit = audit_log if audit_log is not None else InMemoryAuditLog()
        self._issuer = issuer

    def sweep(
        self,
        *,
        retention_days: int,
        dry_run: bool = False,
    ) -> SweepReport:
        cutoff = datetime.now(timezone.utc) - timedelta(days=retention_days)
        report = SweepReport(cutoff_at=cutoff, dry_run=dry_run)
        users = _all_user_ids(self._store)
        for uid in users:
            if dry_run:
                # Count what *would* be deleted without mutating.
                events = self._store.list_by_user(uid)
                n = sum(1 for e in events if e.created_at < cutoff)
            else:
                n = self._store.delete_older_than(uid, cutoff)
            if n > 0:
                report.deleted_per_user[uid] = n
                report.deleted_total += n
                if not dry_run:
                    self._audit.write(
                        AuditLogEntry(
                            user_id=uid,
                            action="data_deleted",
                            reason="ttl_expired",
                            event_count=n,
                            issuer=self._issuer,
                        )
                    )
        return report


def forget_user(
    *,
    user_id: str,
    store: EventStore,
    audit_log: AuditLog,
    priv_pem: bytes | None = None,
    issuer: str = "semvec-compliance",
) -> DeletionCertificate:
    """DSGVO Art. 17 — wipe every event for ``user_id`` and return a
    signed deletion certificate.

    Always returns a signed certificate, even when the user had no
    events to begin with — the certificate then proves "we looked,
    found nothing, confirmed".

    Resolution-failures on the operator's compliance private key
    (env var or kwarg missing) raise **before** the delete runs,
    so a misconfiguration cannot silently eat user data without
    leaving a verifiable receipt.
    """
    # Pre-flight: confirm we can sign before we delete. Catches the
    # operator-side mis-config from REPORT_v0.4.0_compliance.md
    # finding 2 — without this the data is gone *and* the caller
    # gets a generic 500 instead of a typed signal.
    _resolve_priv_pem(priv_pem)

    n = store.delete_by_user(user_id)
    cert = DeletionCertificate(
        user_id=user_id,
        event_count=n,
        deleted_at=datetime.now(timezone.utc),
        reason="user_request",
        issuer=issuer,
    )
    signed = sign_certificate(cert, priv_pem=priv_pem)
    audit_log.write(
        AuditLogEntry(
            user_id=user_id,
            action="data_deleted",
            reason="user_request",
            event_count=n,
            issuer=issuer,
            cert_signature_b64=signed.signature_b64,
        )
    )
    return signed


__all__ = ["RetentionSweeper", "SweepReport", "forget_user"]
