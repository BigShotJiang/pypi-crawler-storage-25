"""Per-user key registry — RSA public key + HMAC secret + revocation.

Backs the auth path used by the FastAPI middleware:

* :func:`InMemoryKeyRegistry.register` — first-time key registration.
* :func:`InMemoryKeyRegistry.rotate` — register a new key, mark the
  previous one revoked but keep it valid for ``grace_hours`` so
  in-flight callers don't fail mid-request.
* :func:`InMemoryKeyRegistry.revoke` — hard revoke without grace.

All three mutation methods take **keyword-only** arguments
(``register(user_id=..., public_key_pem=..., hmac_secret=...)``).
The :class:`UserKey` dataclass is read-side only — it ships in
``list_for_user`` / ``active_for_user`` / ``get`` results, but you
do *not* construct a :class:`UserKey` and pass it to ``register``.

The in-memory implementation is the default for tests, the demo,
and small single-replica deployments. Production multi-replica
servers should use a Postgres-backed implementation behind the same
:class:`KeyRegistry` Protocol — that swap is a one-day port.
"""

from __future__ import annotations

import secrets
import time
from dataclasses import dataclass
from threading import Lock
from typing import Protocol


@dataclass(frozen=True)
class UserKey:
    user_id: str
    key_id: str
    public_key_pem: bytes
    hmac_secret: bytes
    created_at: float
    revoked_at: float | None = None
    grace_until: float | None = None


class KeyRegistry(Protocol):
    def register(
        self,
        *,
        user_id: str,
        public_key_pem: bytes,
        hmac_secret: bytes,
    ) -> str: ...

    def rotate(
        self,
        *,
        user_id: str,
        new_public_key_pem: bytes,
        new_hmac_secret: bytes,
    ) -> str: ...

    def revoke(self, *, user_id: str, key_id: str) -> bool: ...

    def get(self, *, user_id: str, key_id: str) -> UserKey | None: ...

    def list_for_user(self, user_id: str) -> list[UserKey]: ...

    def active_for_user(self, user_id: str) -> list[UserKey]: ...


class InMemoryKeyRegistry:
    """In-process :class:`KeyRegistry`.

    A revoked key with a non-expired ``grace_until`` still counts as
    active so callers in flight at rotation time don't fail.
    """

    def __init__(self, *, default_grace_hours: int = 24) -> None:
        self._grace_seconds = float(default_grace_hours) * 3600.0
        self._keys: dict[tuple[str, str], UserKey] = {}
        self._lock = Lock()

    @staticmethod
    def _new_key_id() -> str:
        # 16 bytes of entropy, hex — fits comfortably in a JWT `kid`.
        return secrets.token_hex(16)

    def register(
        self,
        *,
        user_id: str,
        public_key_pem: bytes,
        hmac_secret: bytes,
    ) -> str:
        kid = self._new_key_id()
        now = time.time()
        with self._lock:
            self._keys[(user_id, kid)] = UserKey(
                user_id=user_id,
                key_id=kid,
                public_key_pem=public_key_pem,
                hmac_secret=hmac_secret,
                created_at=now,
            )
        return kid

    def rotate(
        self,
        *,
        user_id: str,
        new_public_key_pem: bytes,
        new_hmac_secret: bytes,
    ) -> str:
        new_kid = self._new_key_id()
        now = time.time()
        with self._lock:
            # Mark every currently-active key revoked with grace.
            for (uid, kid), uk in list(self._keys.items()):
                if uid != user_id or uk.revoked_at is not None:
                    continue
                self._keys[(uid, kid)] = UserKey(
                    **{**uk.__dict__, "revoked_at": now, "grace_until": now + self._grace_seconds},
                )
            self._keys[(user_id, new_kid)] = UserKey(
                user_id=user_id,
                key_id=new_kid,
                public_key_pem=new_public_key_pem,
                hmac_secret=new_hmac_secret,
                created_at=now,
            )
        return new_kid

    def revoke(self, *, user_id: str, key_id: str) -> bool:
        now = time.time()
        with self._lock:
            uk = self._keys.get((user_id, key_id))
            if uk is None:
                return False
            self._keys[(user_id, key_id)] = UserKey(
                **{**uk.__dict__, "revoked_at": now, "grace_until": None},
            )
            return True

    def get(self, *, user_id: str, key_id: str) -> UserKey | None:
        with self._lock:
            return self._keys.get((user_id, key_id))

    def list_for_user(self, user_id: str) -> list[UserKey]:
        with self._lock:
            return [uk for (uid, _), uk in self._keys.items() if uid == user_id]

    def active_for_user(self, user_id: str) -> list[UserKey]:
        now = time.time()
        out: list[UserKey] = []
        with self._lock:
            for (uid, _), uk in self._keys.items():
                if uid != user_id:
                    continue
                if uk.revoked_at is None or uk.grace_until is not None and uk.grace_until > now:
                    out.append(uk)
            return out


__all__ = ["KeyRegistry", "InMemoryKeyRegistry", "UserKey"]
