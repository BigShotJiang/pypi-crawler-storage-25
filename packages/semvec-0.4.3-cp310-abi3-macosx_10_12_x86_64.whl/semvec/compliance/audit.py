"""Append-only audit-log entries for compliance-relevant deletes.

Lightweight: an :class:`AuditLogEntry` is a JSON-safe dataclass and
:class:`InMemoryAuditLog` is the default in-memory backend the unit
tests and the demo run against. Production deployments should
substitute a database-backed implementation behind the same
``AuditLog`` Protocol — that swap is a one-day port.

The audit log carries **only IDs and counts**, never raw user
content. The original DSGVO concern is "audit trail must not
re-leak the data we just deleted".
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any, Protocol


@dataclass(frozen=True)
class AuditLogEntry:
    user_id: str
    action: str  # "data_deleted", "key_rotated", ...
    reason: str  # "ttl_expired", "user_request", ...
    event_count: int
    issued_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    cert_signature_b64: str | None = None
    issuer: str | None = None

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["issued_at"] = self.issued_at.isoformat()
        return d


class AuditLog(Protocol):
    def write(self, entry: AuditLogEntry) -> None: ...

    def entries_for_user(self, user_id: str) -> list[AuditLogEntry]: ...


class InMemoryAuditLog:
    """Default audit-log backend for tests and single-process runs."""

    def __init__(self) -> None:
        self._entries: list[AuditLogEntry] = []

    def write(self, entry: AuditLogEntry) -> None:
        self._entries.append(entry)

    def entries_for_user(self, user_id: str) -> list[AuditLogEntry]:
        return [e for e in self._entries if e.user_id == user_id]

    def all(self) -> list[AuditLogEntry]:
        return list(self._entries)


__all__ = ["AuditLog", "AuditLogEntry", "InMemoryAuditLog"]
