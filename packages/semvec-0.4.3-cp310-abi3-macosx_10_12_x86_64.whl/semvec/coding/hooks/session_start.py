"""SessionStart hook for Claude Code.

Fires when a new Claude Code session starts. Loads semvec's
CodingEngine state from disk and logs a summary of what's available
from prior sessions.

Claude Code sends JSON to stdin::

    {
        "session_id": "abc123",
        "cwd": "/workspace"
    }

Ported from ``pss.compaction.hooks.session_start``. semvec requires an
explicit embedder — the subprocess constructs one from a shared
``SentenceTransformer`` (no hash fallback).
"""

from __future__ import annotations

import json
import logging
import sys
from typing import Any

log = logging.getLogger(__name__)


def handle_session_start(
    hook_input: dict[str, Any],
    state_dir: str | None = None,
    embedder: object | None = None,
) -> dict[str, Any]:
    """Handle a SessionStart hook event.

    Args:
        hook_input: Parsed JSON payload from Claude Code stdin.
        state_dir:  Override for PSS state directory (env or ``.semvec``).
        embedder:   Optional embedder. Defaults to SentenceTransformer
                    built from ``$PSS_EMBED_MODEL`` / ``$PSS_EMBED_DEVICE``.

    Returns:
        Result dict with ``status``, ``state_loaded``, ``code_pointers``,
        ``negative_attractors``, ``context``, ``session_id``.
    """
    from semvec.coding import CodingEngine
    from semvec.coding.mcp_server import _env

    state_dir = state_dir or _env("STATE_DIR", default=".semvec")
    workspace_dir = hook_input.get("cwd")

    if embedder is None:
        from semvec.coding.mcp_server import _build_embedder

        embedder = _build_embedder(
            _env("EMBED_MODEL", default="all-MiniLM-L6-v2"),
            _env("EMBED_DEVICE", default="cpu"),
        )

    engine = CodingEngine(
        state_dir=state_dir,
        workspace_dir=workspace_dir,
        embedder=embedder,
    )
    state_loaded = engine.load_state()

    context = engine.get_compacted_context(
        task=f"session start {hook_input.get('session_id', '')}",
    )

    result = {
        "status": "ok",
        "state_loaded": state_loaded,
        "code_pointers": engine.code_pointers.size,
        "negative_attractors": engine.negative_attractors.size,
        "context": context,
        "session_id": hook_input.get("session_id", ""),
    }

    log.info(
        "session_start: loaded=%s pointers=%d attractors=%d",
        state_loaded,
        engine.code_pointers.size,
        engine.negative_attractors.size,
    )

    return result


def main() -> None:
    """Entry point: read JSON from stdin, process, log to stderr."""
    data = sys.stdin.read()
    try:
        hook_input = json.loads(data)
    except json.JSONDecodeError:
        print(data, end="")
        sys.exit(0)

    result = handle_session_start(hook_input)

    print(json.dumps(result), file=sys.stderr)
    print(data, end="")


if __name__ == "__main__":
    main()
