"""In-process pub/sub for drift events (Layer 3).

Thread-safe event bus using bounded deques per region. Subscribers are
synchronous callbacks invoked inline during :meth:`publish`.
"""

from __future__ import annotations

import collections
import contextlib
import logging
import threading
from collections.abc import Callable
from dataclasses import dataclass

logger = logging.getLogger(__name__)

_MAX_EVENTS_PER_REGION = 1000


@dataclass
class DriftEvent:
    """A single drift event published by a cluster within a region."""

    cluster_id: str
    region_id: str
    drift_score: float
    drift_phase: str  # "stable" | "shifting" | "drifted"
    timestamp: float


class DriftEventBus:
    """Thread-safe in-process pub/sub for drift events."""

    def __init__(self) -> None:
        self._events: dict[str, collections.deque[DriftEvent]] = {}
        self._subscribers: dict[str, list[Callable[[DriftEvent], None]]] = {}
        self._lock = threading.Lock()

    def publish(self, event: DriftEvent) -> None:
        with self._lock:
            if event.region_id not in self._events:
                self._events[event.region_id] = collections.deque(maxlen=_MAX_EVENTS_PER_REGION)
            self._events[event.region_id].append(event)
            callbacks = list(self._subscribers.get(event.region_id, []))

        for cb in callbacks:
            try:
                cb(event)
            except Exception:  # pragma: no cover — log + continue
                logger.exception("Subscriber callback failed for region %s", event.region_id)

    def subscribe(self, region_id: str, callback: Callable[[DriftEvent], None]) -> None:
        with self._lock:
            self._subscribers.setdefault(region_id, []).append(callback)

    def unsubscribe(self, region_id: str, callback: Callable[[DriftEvent], None]) -> None:
        with self._lock:
            subs = self._subscribers.get(region_id, [])
            with contextlib.suppress(ValueError):
                subs.remove(callback)

    def get_recent_events(self, region_id: str, limit: int = 50) -> list[DriftEvent]:
        with self._lock:
            deq = self._events.get(region_id)
            if deq is None:
                return []
            items = list(deq)
        if limit >= len(items):
            return items
        return items[-limit:]

    def clear(self, region_id: str) -> None:
        with self._lock:
            if region_id in self._events:
                self._events[region_id].clear()
