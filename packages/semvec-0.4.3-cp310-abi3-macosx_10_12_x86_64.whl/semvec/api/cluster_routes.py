"""Phase D — Layer 2 cluster routes."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Request

from semvec.api.auth import license_subject, verify_license
from semvec.api.cluster_manager import ClusterManager
from semvec.api.schemas import (
    ClusterCreate,
    ClusterFeedbackResponse,
    ClusterInfo,
    ClusterListItem,
    ClusterState,
    DeletedResponse,
    MemberRemovedResponse,
    MemberRequest,
    MemberResponse,
    RunRequest,
    RunResponse,
)

cluster_router = APIRouter(prefix="/v1/cluster")

_NOT_FOUND = "Cluster not found"


def _get_manager() -> ClusterManager:
    raise RuntimeError("ClusterManager not injected")


def set_cluster_manager(manager: ClusterManager) -> None:
    global _get_manager

    def _impl() -> ClusterManager:
        return manager

    _get_manager = _impl  # type: ignore[assignment]


@cluster_router.post(
    "/",
    response_model=ClusterInfo,
    status_code=201,
    dependencies=[Depends(verify_license)],
)
def create_cluster(request: Request, req: ClusterCreate):
    mgr = _get_manager()
    subject = license_subject(request)
    try:
        rec = mgr.create_cluster(
            req.name,
            owner_subject=subject,
            aggregation_mode=req.aggregation_mode,
            coupling_factor=req.coupling_factor,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return ClusterInfo(
        cluster_id=rec.cluster_id,
        name=rec.name,
        aggregation_mode=rec.aggregation_mode,
        coupling_factor=rec.coupling_factor,
    )


@cluster_router.get(
    "/",
    response_model=list[ClusterListItem],
    dependencies=[Depends(verify_license)],
)
def list_clusters(request: Request):
    mgr = _get_manager()
    subject = license_subject(request)
    return [
        ClusterListItem(
            cluster_id=r.cluster_id,
            name=r.name,
            member_count=len(r.member_session_ids),
        )
        for r in mgr.list_clusters(owner_subject=subject)
    ]


@cluster_router.get(
    "/{cluster_id}",
    response_model=ClusterState,
    dependencies=[Depends(verify_license)],
)
def get_cluster(cluster_id: str, request: Request):
    mgr = _get_manager()
    subject = license_subject(request)
    state = mgr.get_cluster_state(cluster_id, owner_subject=subject)
    if state is None:
        raise HTTPException(status_code=404, detail=_NOT_FOUND)
    return ClusterState(
        cluster_id=state["cluster_id"],
        name=state["name"],
        aggregation_mode=state["aggregation_mode"],
        coupling_factor=state["coupling_factor"],
        member_count=state["member_count"],
        phase=state["phase"],
        interaction_count=state["interaction_count"],
        total_memories=state["total_memories"],
        aggregate_vector=state["aggregate_vector"],
    )


@cluster_router.delete(
    "/{cluster_id}",
    response_model=DeletedResponse,
    dependencies=[Depends(verify_license)],
)
def delete_cluster(cluster_id: str, request: Request):
    mgr = _get_manager()
    subject = license_subject(request)
    if not mgr.delete_cluster(cluster_id, owner_subject=subject):
        raise HTTPException(status_code=404, detail=_NOT_FOUND)
    return DeletedResponse(deleted=True)


# ---------------------------------------------------------------------------
# Members


@cluster_router.post(
    "/{cluster_id}/members",
    response_model=MemberResponse,
    dependencies=[Depends(verify_license)],
)
def add_member(cluster_id: str, request: Request, req: MemberRequest):
    mgr = _get_manager()
    subject = license_subject(request)
    added = mgr.add_member(cluster_id, req.session_id, owner_subject=subject)
    if not added:
        raise HTTPException(status_code=404, detail=_NOT_FOUND)
    return MemberResponse(cluster_id=cluster_id, session_id=req.session_id, added=True)


@cluster_router.delete(
    "/{cluster_id}/members/{session_id}",
    response_model=MemberRemovedResponse,
    dependencies=[Depends(verify_license)],
)
def remove_member(cluster_id: str, session_id: str, request: Request):
    mgr = _get_manager()
    subject = license_subject(request)
    removed = mgr.remove_member(cluster_id, session_id, owner_subject=subject)
    if not removed:
        raise HTTPException(status_code=404, detail="Member or cluster not found")
    return MemberRemovedResponse(cluster_id=cluster_id, session_id=session_id, removed=True)


# ---------------------------------------------------------------------------
# Store / Run / Feedback


@cluster_router.post("/{cluster_id}/store", dependencies=[Depends(verify_license)])
def store_in_cluster(cluster_id: str, request: Request, body: dict):
    mgr = _get_manager()
    subject = license_subject(request)
    message = body.get("message")
    response = body.get("response")
    if not message or not response:
        raise HTTPException(status_code=422, detail="Both 'message' and 'response' are required")
    result = mgr.store_in_cluster(
        cluster_id, message=message, response=response, owner_subject=subject
    )
    if result is None:
        raise HTTPException(status_code=404, detail=_NOT_FOUND)
    return result


@cluster_router.post(
    "/{cluster_id}/run",
    response_model=RunResponse,
    dependencies=[Depends(verify_license)],
)
def run_cluster(cluster_id: str, request: Request, req: RunRequest):
    """Query the cluster's backing Semvec session.

    ``cluster_id`` IS the session_id — we pin it here so callers can
    drive cluster conversations with a single identifier.
    """
    mgr = _get_manager()
    subject = license_subject(request)
    if mgr.get_cluster(cluster_id, owner_subject=subject) is None:
        raise HTTPException(status_code=404, detail=_NOT_FOUND)

    from semvec.api.routes import run as _run

    pinned = RunRequest(
        message=req.message,
        session_id=cluster_id,
        response=req.response,
        short_circuit_threshold=req.short_circuit_threshold,
        reset_context=req.reset_context,
    )
    return _run(request=request, req=pinned)


@cluster_router.post(
    "/{cluster_id}/feedback",
    response_model=ClusterFeedbackResponse,
    dependencies=[Depends(verify_license)],
)
def apply_coupling_feedback(cluster_id: str, request: Request):
    mgr = _get_manager()
    subject = license_subject(request)
    updated = mgr.apply_coupling_feedback(cluster_id, owner_subject=subject)
    if updated < 0:
        raise HTTPException(status_code=404, detail=_NOT_FOUND)
    return ClusterFeedbackResponse(cluster_id=cluster_id, sessions_updated=updated)
