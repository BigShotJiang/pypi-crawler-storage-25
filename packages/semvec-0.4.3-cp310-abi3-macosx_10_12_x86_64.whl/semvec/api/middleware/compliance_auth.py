"""FastAPI HMAC request-signing middleware for the compliance pack.

Wraps every request that targets ``/v1/compliance/...`` with the
AWS-SigV4-style verification flow:

1. Mandatory headers (``X-Semvec-{User-Id, Key-Id, Timestamp,
   Nonce, Signature}``).
2. Timestamp must lie within ``±timestamp_window_seconds`` of the
   server clock.
3. Nonce must be fresh (not seen for the same user inside the
   sliding window).
4. The ``user_id`` claim must match the path's ``user_id`` parameter
   when present — otherwise alice's signature could authorise a
   request against bob's data.
5. The HMAC signature is verified constant-time against the
   registered key's secret. Wrong signature → 401.

Failures map to short, machine-readable ``detail`` codes:
``missing_signature``, ``timestamp_out_of_window``,
``unknown_key``, ``user_id_mismatch``, ``bad_signature``,
``nonce_replayed``.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import TYPE_CHECKING

from fastapi import Request
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware

from semvec.compliance.hmac_signing import verify_signed_request

if TYPE_CHECKING:
    from starlette.types import ASGIApp

    from semvec.compliance.key_registry import KeyRegistry
    from semvec.compliance.nonce_cache import InMemoryNonceCache


# Path-param extraction: every protected route lives under
# ``/v1/compliance/users/{uid}/...``. We extract the path's user-id
# segment to compare against the signed header.
_USER_ID_IN_PATH = re.compile(r"^/v1/compliance/users/([^/]+)")


@dataclass
class _SignedHeaders:
    user_id: str
    key_id: str
    timestamp: str
    nonce: str
    signature_hex: str


def _read_signed_headers(request: Request) -> _SignedHeaders | None:
    h = request.headers
    user_id = h.get("X-Semvec-User-Id")
    key_id = h.get("X-Semvec-Key-Id")
    ts = h.get("X-Semvec-Timestamp")
    nonce = h.get("X-Semvec-Nonce")
    sig = h.get("X-Semvec-Signature")
    if not all([user_id, key_id, ts, nonce, sig]):
        return None
    return _SignedHeaders(
        user_id=user_id,  # type: ignore[arg-type]
        key_id=key_id,  # type: ignore[arg-type]
        timestamp=ts,  # type: ignore[arg-type]
        nonce=nonce,  # type: ignore[arg-type]
        signature_hex=sig,  # type: ignore[arg-type]
    )


def _timestamp_in_window(ts_str: str, window: float) -> bool:
    try:
        ts = datetime.fromisoformat(ts_str)
    except ValueError:
        return False
    if ts.tzinfo is None:
        ts = ts.replace(tzinfo=timezone.utc)
    delta = abs((datetime.now(timezone.utc) - ts).total_seconds())
    return delta <= window


def _user_id_from_path(path: str) -> str | None:
    m = _USER_ID_IN_PATH.match(path)
    return m.group(1) if m else None


def _err(detail: str, *, status_code: int = 401) -> JSONResponse:
    return JSONResponse(status_code=status_code, content={"detail": detail})


class ComplianceHmacMiddleware(BaseHTTPMiddleware):
    """Starlette middleware enforcing the HMAC request-signing flow.

    Constructor args:

    * ``registry`` — :class:`KeyRegistry` for key lookups.
    * ``nonce_cache`` — :class:`InMemoryNonceCache` (or compatible).
    * ``protected_prefix`` — only paths starting with this prefix are
      gated; everything else passes through unchanged.
    * ``timestamp_window_seconds`` — clock skew tolerance.
    """

    def __init__(
        self,
        app: ASGIApp,
        *,
        registry: KeyRegistry,
        nonce_cache: InMemoryNonceCache,
        protected_prefix: str = "/v1/compliance",
        timestamp_window_seconds: float = 60.0,
    ) -> None:
        super().__init__(app)
        self._registry = registry
        self._nonce = nonce_cache
        self._prefix = protected_prefix
        self._window = float(timestamp_window_seconds)

    async def dispatch(self, request, call_next):  # type: ignore[override]
        path = request.url.path
        if not path.startswith(self._prefix):
            return await call_next(request)

        signed = _read_signed_headers(request)
        if signed is None:
            return _err("missing_signature")

        if not _timestamp_in_window(signed.timestamp, self._window):
            return _err("timestamp_out_of_window")

        # Path user-id must match the signed user-id claim.
        path_uid = _user_id_from_path(path)
        if path_uid is not None and path_uid != signed.user_id:
            return _err("user_id_mismatch")

        key = self._registry.get(user_id=signed.user_id, key_id=signed.key_id)
        if key is None:
            return _err("unknown_key")

        # Verify before consuming the nonce — a bad signature must
        # not lock out the next genuine retry from the same nonce.
        body = await request.body()

        # Re-attach the body so the route handler can still read it.
        # Starlette's BaseHTTPMiddleware caches it on the request.
        async def _replay() -> dict:
            return {"type": "http.request", "body": body, "more_body": False}

        request._receive = _replay  # type: ignore[attr-defined]

        ok = verify_signed_request(
            secret=key.hmac_secret,
            method=request.method,
            path=path,
            body=body,
            timestamp=signed.timestamp,
            nonce=signed.nonce,
            signature_hex=signed.signature_hex,
        )
        if not ok:
            return _err("bad_signature")

        if not self._nonce.observe_nonce(signed.user_id, signed.nonce):
            return _err("nonce_replayed", status_code=409)

        return await call_next(request)


__all__ = ["ComplianceHmacMiddleware"]
