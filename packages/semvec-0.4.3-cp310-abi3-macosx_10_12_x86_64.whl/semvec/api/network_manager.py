"""Layer 5 — Network manager for cross-session operations.

Covers three feature-delta features as HTTP surface on top of the Rust
core's existing primitives:

* **Semantic delta-vector transfer** (delta 27) — blend source
  session's normalised semantic state into the target.
* **User-isolated instance partitioning** (delta 29) — maintain
  independent Semvec states per ``user_id``, hot-swap via ``switch_user``.
* **Trust-based consensus** (delta 30) — simple Python-level trust
  tracker. Proposers earn / lose trust based on how well their proposed
  target aligns with their own current semantic state.
"""

from __future__ import annotations

import threading
from typing import TYPE_CHECKING, Any

import numpy as np

from semvec import SemvecConfig, SemvecState

if TYPE_CHECKING:
    from semvec.api.session_manager import SessionManager


_DEFAULT_USER = "default"


class _UserPartition:
    """Snapshot of a user partition: the saved SemvecState and config."""

    __slots__ = ("state", "config")

    def __init__(self, state: SemvecState, config: SemvecConfig) -> None:
        self.state = state
        self.config = config


class NetworkManager:
    """Cross-session operations on top of :class:`SessionManager`."""

    def __init__(self, session_manager: SessionManager) -> None:
        self._sm = session_manager
        self._lock = threading.Lock()
        self._active_user: str = _DEFAULT_USER
        self._partitions: dict[str, _UserPartition] = {}
        self._trust_scores: dict[str, float] = {}
        self._registered_instances: set[str] = set()

    # ------------------------------------------------------------------
    # Semantic delta-vector transfer

    def transfer_delta(
        self,
        source_session_id: str,
        target_session_id: str,
        max_weight: float = 0.15,
    ) -> dict[str, Any] | None:
        src = self._sm.get_session(source_session_id)
        tgt = self._sm.get_session(target_session_id)
        if src is None or tgt is None:
            return None

        sv_src = np.asarray(src.pss_state.semantic_state, dtype=np.float64)
        sv_tgt = np.asarray(tgt.pss_state.semantic_state, dtype=np.float64)

        norm_src = float(np.linalg.norm(sv_src))
        norm_tgt = float(np.linalg.norm(sv_tgt))
        if norm_src < 1e-8 or norm_tgt < 1e-8:
            return {"delta_norm": 0.0}

        n_src = sv_src / norm_src
        n_tgt = sv_tgt / norm_tgt
        delta = n_src - n_tgt
        delta_norm = float(np.linalg.norm(delta))
        scale = min(delta_norm, max_weight)
        delta_scaled = delta * (scale / delta_norm) if delta_norm > 1e-10 else delta

        new_vec = sv_tgt + delta_scaled
        tgt.pss_state.semantic_state = new_vec.copy()
        return {"delta_norm": round(delta_norm, 6)}

    # ------------------------------------------------------------------
    # User partitioning

    def get_active_user(self) -> str:
        with self._lock:
            return self._active_user

    def switch_user(self, user_id: str) -> dict[str, Any]:
        """Save the current user's snapshot and activate *user_id*.

        If *user_id* hasn't been seen before, a fresh SemvecState is
        created and associated with the partition.
        """
        with self._lock:
            previous = self._active_user
            if previous == user_id:
                return {"active_user": previous, "previous_user": previous}

            # Snapshot the currently-active user: grab it from
            # SessionManager's per-session store under the reserved
            # key "_partition:<user_id>". We use SessionManager as a
            # backing store of live states per partition.
            active_sid = f"_partition:{previous}"
            active_session = self._sm.get_session(active_sid)
            if active_session is not None:
                self._partitions[previous] = _UserPartition(
                    state=active_session.pss_state, config=active_session.config
                )

            target_sid = f"_partition:{user_id}"
            if self._sm.get_session(target_sid) is None:
                # Fresh state for a brand-new user partition.
                if user_id in self._partitions:
                    snap = self._partitions[user_id]
                    self._sm.create_session(session_id=target_sid)
                    new_session = self._sm.get_session(target_sid)
                    if new_session is not None:
                        new_session.pss_state = snap.state
                        new_session.config = snap.config
                else:
                    self._sm.create_session(session_id=target_sid)

            self._active_user = user_id
            return {"active_user": user_id, "previous_user": previous}

    def serialize_user(self, user_id: str) -> dict[str, Any] | None:
        """Return the user partition's exported state, or None if unknown."""
        with self._lock:
            if user_id in self._partitions:
                return self._partitions[user_id].state.to_dict()
            sid = f"_partition:{user_id}"
            session = self._sm.get_session(sid)
            if session is None:
                return None
            return session.pss_state.to_dict()

    # ------------------------------------------------------------------
    # Trust-based consensus

    def propose_consensus(
        self,
        proposer_session_id: str,
        target_embedding: list[float],
    ) -> dict[str, Any] | None:
        """Propose a consensus vector from a session.

        Registers the proposer if new, then measures how well the
        proposed embedding aligns with the proposer's current semantic
        state. Acceptance threshold is cosine ≥ 0.0 (positive alignment);
        trust is an EMA of the alignment.
        """
        session = self._sm.get_session(proposer_session_id)
        if session is None:
            return None

        vec = np.asarray(target_embedding, dtype=np.float64)
        n_vec = float(np.linalg.norm(vec))
        if n_vec > 1e-8:
            vec = vec / n_vec
        cur = np.asarray(session.pss_state.semantic_state, dtype=np.float64)
        n_cur = float(np.linalg.norm(cur))
        if n_cur > 1e-8:
            cur_normed = cur / n_cur
            alignment = float(np.clip(np.dot(cur_normed, vec), -1.0, 1.0))
        else:
            alignment = 0.0

        accepted = alignment >= 0.0
        with self._lock:
            self._registered_instances.add(proposer_session_id)
            prior = self._trust_scores.get(proposer_session_id, 0.5)
            # Map alignment [-1, 1] → [0, 1] then EMA.
            mapped = (alignment + 1.0) / 2.0
            self._trust_scores[proposer_session_id] = float(
                np.clip(0.8 * prior + 0.2 * mapped, 0.0, 1.0)
            )
            scores = dict(self._trust_scores)
        return {"accepted": bool(accepted), "trust_scores": scores}

    def get_trust_scores(self) -> dict[str, float]:
        with self._lock:
            return dict(self._trust_scores)
