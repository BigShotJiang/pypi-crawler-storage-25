"""FastAPI router for the Compliance Pack.

Exposes the GDPR-relevant operations as HTTP endpoints under the
``/v1/compliance`` prefix:

* ``GET    /v1/compliance/users/{uid}/memory`` — list (or cosine-
  query) the user's events.
* ``DELETE /v1/compliance/users/{uid}/memory/{event_id}`` — drop a
  single event.
* ``DELETE /v1/compliance/users/{uid}/memory`` — wipe the user's
  events without issuing a certificate (alias for the lazy path).
* ``POST   /v1/compliance/users/{uid}/forget`` — full DSGVO Art. 17
  wipe with a signed :class:`DeletionCertificate` in the response.
* ``GET    /v1/compliance/users/{uid}/facts`` — facts extracted from
  the user's events, filterable by ``type=numeric|date|identifier``.

Authentication / HMAC request signing comes in Phase 6 — for now the
router runs without auth so callers can integrate via a reverse
proxy that handles their own AuthN.
"""

from __future__ import annotations

import uuid
from typing import Any

from fastapi import APIRouter, HTTPException, Query

from semvec.compliance.audit import AuditLog, InMemoryAuditLog
from semvec.compliance.event_store import EventStore
from semvec.compliance.extractors import extract_facts
from semvec.compliance.retention import forget_user

# ---------------------------------------------------------------------------
# Module-level singletons populated by the app factory.
#
# Mirrors the pattern in semvec.api.routes (set_session_manager,
# set_layer3_managers, ...): the router holds module-level handles
# that the FastAPI app initialises in its startup factory. Keeps the
# route handlers free of per-request DI machinery.

_store: EventStore | None = None
_audit: AuditLog | None = None
_issuer: str = "semvec-compliance"


def set_compliance_dependencies(
    *,
    store: EventStore,
    audit_log: AuditLog | None = None,
    issuer: str = "semvec-compliance",
) -> None:
    """Wire the router's storage layer at app-startup time."""
    global _store, _audit, _issuer
    _store = store
    _audit = audit_log if audit_log is not None else InMemoryAuditLog()
    _issuer = issuer


def _require_store() -> EventStore:
    if _store is None:
        raise HTTPException(
            status_code=503,
            detail="compliance: event store not configured",
        )
    return _store


def _require_audit() -> AuditLog:
    if _audit is None:
        raise HTTPException(
            status_code=503,
            detail="compliance: audit log not configured",
        )
    return _audit


# ---------------------------------------------------------------------------
# Router

compliance_router = APIRouter(prefix="/v1/compliance", tags=["compliance"])


@compliance_router.get("/users/{user_id}/memory")
def list_user_memory(
    user_id: str,
    limit: int = Query(default=50, ge=1, le=500),
) -> dict[str, Any]:
    store = _require_store()
    events = store.list_by_user(user_id)[:limit]
    return {
        "events": [
            {
                "event_id": str(ev.event_id),
                "user_id": ev.user_id,
                "created_at": ev.created_at.isoformat(),
                "content": ev.content,
                "meta": ev.meta,
            }
            for ev in events
        ]
    }


@compliance_router.delete(
    "/users/{user_id}/memory/{event_id}",
    status_code=204,
)
def delete_user_event(user_id: str, event_id: uuid.UUID) -> None:
    store = _require_store()
    ok = store.delete(event_id)
    if not ok:
        raise HTTPException(
            status_code=404,
            detail=f"event {event_id} not found",
        )


@compliance_router.delete("/users/{user_id}/memory")
def wipe_user_memory(user_id: str) -> dict[str, int]:
    store = _require_store()
    n = store.delete_by_user(user_id)
    return {"deleted": n}


@compliance_router.post("/users/{user_id}/forget")
def forget_user_endpoint(user_id: str) -> dict[str, Any]:
    """DSGVO Art. 17 — wipe + signed certificate."""
    store = _require_store()
    audit = _require_audit()
    try:
        cert = forget_user(
            user_id=user_id,
            store=store,
            audit_log=audit,
            issuer=_issuer,
        )
    except RuntimeError as e:
        # Raised by certificates._resolve_priv_pem when the operator
        # has not configured a signing key. The pre-flight check in
        # forget_user() guarantees the data is still intact at this
        # point — a typed 503 is the right way to surface it.
        if "private key missing" in str(e):
            raise HTTPException(
                status_code=503,
                detail="compliance_keypair_unconfigured",
            ) from e
        raise
    return {
        "user_id": cert.user_id,
        "event_count": cert.event_count,
        "deleted_at": cert.deleted_at.isoformat(),
        "reason": cert.reason,
        "issuer": cert.issuer,
        "signature_b64": cert.signature_b64,
    }


@compliance_router.get("/users/{user_id}/facts")
def list_user_facts(
    user_id: str,
    type: str | None = Query(default=None, pattern="^(numeric|date|identifier)$"),
) -> dict[str, Any]:
    store = _require_store()
    events = store.list_by_user(user_id)
    out: list[dict[str, Any]] = []
    for ev in events:
        for fact in extract_facts(ev.content):
            if type is not None and fact.kind != type:
                continue
            entry: dict[str, Any] = {
                "kind": fact.kind,
                "raw": fact.raw,
                "event_id": str(ev.event_id),
            }
            # Render typed value as JSON-friendly string — Decimal /
            # datetime / id strings round-trip cleanly.
            if fact.kind == "numeric":
                entry["value"] = str(fact.value)
                entry["unit"] = fact.unit
            elif fact.kind == "date":
                entry["value"] = fact.value.isoformat()
            else:  # identifier
                entry["value"] = fact.value
                entry["id_type"] = fact.id_type
            out.append(entry)
    return {"facts": out}


__all__ = ["compliance_router", "set_compliance_dependencies"]
