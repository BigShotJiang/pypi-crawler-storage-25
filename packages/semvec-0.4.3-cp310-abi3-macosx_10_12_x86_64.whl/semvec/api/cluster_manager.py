"""Layer 2 — Cluster manager for the Semvec REST API.

A cluster is a named group of agent sessions sharing one backing Semvec
session. ``cluster_id`` doubles as the Semvec ``session_id`` so callers
only ever need one identifier.

Thread-safe via a dedicated lock (separate from the SessionManager's
internal lock so we never hold both concurrently).
"""

from __future__ import annotations

import logging
import threading
import uuid
from dataclasses import dataclass, field
from typing import Any

import numpy as np

from semvec.api.session_manager import SessionManager

logger = logging.getLogger(__name__)

_VALID_AGGREGATION_MODES = frozenset({"weighted_average", "attention"})


@dataclass
class ClusterRecord:
    cluster_id: str
    name: str
    member_session_ids: set[str] = field(default_factory=set)
    owner_subject: str | None = None
    aggregation_mode: str = "weighted_average"
    coupling_factor: float = 0.0


class ClusterManager:
    """Thread-safe in-memory store for Semvec clusters."""

    def __init__(self, session_manager: SessionManager) -> None:
        self._session_manager = session_manager
        self._clusters: dict[str, ClusterRecord] = {}
        self._lock = threading.Lock()

    # ------------------------------------------------------------------
    # Ownership helper

    @staticmethod
    def _check_ownership(record: ClusterRecord, owner_subject: str | None) -> bool:
        if owner_subject is None or record.owner_subject is None:
            return True
        return record.owner_subject == owner_subject

    # ------------------------------------------------------------------
    # CRUD

    def create_cluster(
        self,
        name: str,
        owner_subject: str | None = None,
        aggregation_mode: str = "weighted_average",
        coupling_factor: float = 0.0,
    ) -> ClusterRecord:
        if aggregation_mode not in _VALID_AGGREGATION_MODES:
            raise ValueError(
                f"aggregation_mode must be one of {sorted(_VALID_AGGREGATION_MODES)!r}, "
                f"got {aggregation_mode!r}"
            )
        if not 0.0 <= coupling_factor <= 1.0:
            raise ValueError(f"coupling_factor must be in [0.0, 1.0], got {coupling_factor!r}")
        cluster_id = str(uuid.uuid4())
        # cluster_id doubles as session_id.
        self._session_manager.create_session(owner_subject=owner_subject, session_id=cluster_id)
        record = ClusterRecord(
            cluster_id=cluster_id,
            name=name,
            member_session_ids=set(),
            owner_subject=owner_subject,
            aggregation_mode=aggregation_mode,
            coupling_factor=coupling_factor,
        )
        with self._lock:
            self._clusters[cluster_id] = record
        logger.info("Created cluster %s (%s)", cluster_id, name)
        return record

    def get_cluster(
        self, cluster_id: str, owner_subject: str | None = None
    ) -> ClusterRecord | None:
        with self._lock:
            record = self._clusters.get(cluster_id)
        if record is None:
            return None
        if not self._check_ownership(record, owner_subject):
            return None
        return record

    def list_clusters(self, owner_subject: str | None = None) -> list[ClusterRecord]:
        with self._lock:
            return [r for r in self._clusters.values() if self._check_ownership(r, owner_subject)]

    def delete_cluster(self, cluster_id: str, owner_subject: str | None = None) -> bool:
        with self._lock:
            record = self._clusters.get(cluster_id)
            if record is None:
                return False
            if not self._check_ownership(record, owner_subject):
                return False
            del self._clusters[cluster_id]
        self._session_manager.delete_session(record.cluster_id, owner_subject=owner_subject)
        logger.info("Deleted cluster %s", cluster_id)
        return True

    # ------------------------------------------------------------------
    # Member management

    def add_member(
        self,
        cluster_id: str,
        session_id: str,
        owner_subject: str | None = None,
    ) -> bool:
        with self._lock:
            record = self._clusters.get(cluster_id)
            if record is None:
                return False
            if not self._check_ownership(record, owner_subject):
                return False
            record.member_session_ids.add(session_id)
        return True

    def remove_member(
        self,
        cluster_id: str,
        session_id: str,
        owner_subject: str | None = None,
    ) -> bool:
        with self._lock:
            record = self._clusters.get(cluster_id)
            if record is None:
                return False
            if not self._check_ownership(record, owner_subject):
                return False
            if session_id not in record.member_session_ids:
                return False
            record.member_session_ids.discard(session_id)
        return True

    def get_cluster_for_session(self, session_id: str) -> str | None:
        with self._lock:
            for record in self._clusters.values():
                if session_id in record.member_session_ids:
                    return record.cluster_id
        return None

    # ------------------------------------------------------------------
    # Aggregation + feedback

    def get_cluster_aggregate_vector(
        self, cluster_id: str, owner_subject: str | None = None
    ) -> np.ndarray | None:
        record = self.get_cluster(cluster_id, owner_subject=owner_subject)
        if record is None:
            return None

        vectors: list[list[float]] = []
        weights: list[float] = []
        for sid in record.member_session_ids:
            vec = self._session_manager.get_session_vector(sid)
            if vec is None or np.linalg.norm(vec) <= 1e-8:
                continue
            metrics = self._session_manager.get_metrics(sid)
            ic = metrics["interaction_count"] if metrics else 0
            vectors.append(list(np.asarray(vec, dtype=np.float64)))
            weights.append(float(max(ic, 1)))

        if not vectors:
            vec = self._session_manager.get_session_vector(record.cluster_id)
            if vec is None:
                return None
            return np.asarray(vec, dtype=np.float64)

        # Late import so we never pay for cortex if no cluster endpoints are hit.
        from semvec.cortex import AttentionAggregation, WeightedAverageAggregation

        dim = len(vectors[0])
        if record.aggregation_mode == "attention":
            aggregator: Any = AttentionAggregation(attention_dim=dim, dimension=dim)
        else:
            aggregator = WeightedAverageAggregation(dimension=dim)
        return np.asarray(aggregator.aggregate(vectors, weights), dtype=np.float64)

    def apply_coupling_feedback(self, cluster_id: str, owner_subject: str | None = None) -> int:
        """Blend the cluster vector back into member sessions.

        Returns the number of member sessions updated, or -1 if the
        cluster is not found.
        """
        record = self.get_cluster(cluster_id, owner_subject=owner_subject)
        if record is None:
            return -1

        coupling = record.coupling_factor
        if coupling < 1e-10:
            return 0

        global_vec = self._session_manager.get_session_vector(record.cluster_id)
        if global_vec is None or np.linalg.norm(global_vec) < 1e-8:
            return 0

        updated = 0
        for sid in list(record.member_session_ids):
            local_vec = self._session_manager.get_session_vector(sid)
            if local_vec is None or np.linalg.norm(local_vec) < 1e-8:
                continue
            blended = (1.0 - coupling) * np.asarray(local_vec) + coupling * np.asarray(global_vec)
            self._session_manager.set_session_vector(sid, blended)
            updated += 1
        return updated

    def get_cluster_state(
        self, cluster_id: str, owner_subject: str | None = None
    ) -> dict[str, Any] | None:
        record = self.get_cluster(cluster_id, owner_subject=owner_subject)
        if record is None:
            return None
        metrics = self._session_manager.get_metrics(record.cluster_id, owner_subject=owner_subject)
        if metrics is None:
            return None
        metrics["cluster_id"] = record.cluster_id
        metrics["name"] = record.name
        metrics["member_count"] = len(record.member_session_ids)
        metrics["aggregation_mode"] = record.aggregation_mode
        metrics["coupling_factor"] = record.coupling_factor

        agg = self.get_cluster_aggregate_vector(cluster_id, owner_subject=owner_subject)
        metrics["aggregate_vector"] = list(agg.tolist()) if agg is not None else []
        return metrics

    def store_in_cluster(
        self,
        cluster_id: str,
        message: str,
        response: str,
        owner_subject: str | None = None,
    ) -> dict[str, Any] | None:
        record = self.get_cluster(cluster_id, owner_subject=owner_subject)
        if record is None:
            return None
        session = self._session_manager.get_session(record.cluster_id, owner_subject=owner_subject)
        if session is None:
            return None
        session.pending_message = message
        return self._session_manager.store_qa(
            record.cluster_id, response, owner_subject=owner_subject
        )
