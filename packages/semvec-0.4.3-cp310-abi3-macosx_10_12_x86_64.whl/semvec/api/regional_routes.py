"""Phase E — Layer 3 region routes."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query, Request

from semvec.api.auth import license_subject, verify_license
from semvec.api.regional_manager import RegionalManager
from semvec.api.schemas import (
    DriftEventItem,
    RegionClusterRequest,
    RegionCreate,
    RegionInfo,
    RegionListItem,
    RegionState,
)

regional_router = APIRouter(prefix="/v1/region")

_NOT_FOUND = "Region not found"


def _get_manager() -> RegionalManager:
    raise RuntimeError("RegionalManager not injected")


def set_regional_manager(manager: RegionalManager) -> None:
    global _get_manager

    def _impl() -> RegionalManager:
        return manager

    _get_manager = _impl  # type: ignore[assignment]


@regional_router.post(
    "/",
    response_model=RegionInfo,
    status_code=201,
    dependencies=[Depends(verify_license)],
)
def create_region(request: Request, req: RegionCreate):
    mgr = _get_manager()
    subject = license_subject(request)
    rec = mgr.create_region(
        name=req.name,
        consensus_threshold=req.consensus_threshold,
        vote_window_seconds=req.vote_window_seconds,
        owner_subject=subject,
    )
    return RegionInfo(
        region_id=rec.region_id,
        name=rec.name,
        meta_session_id=rec.meta_session_id,
    )


@regional_router.get(
    "/",
    response_model=list[RegionListItem],
    dependencies=[Depends(verify_license)],
)
def list_regions(request: Request):
    mgr = _get_manager()
    subject = license_subject(request)
    return [
        RegionListItem(region_id=r.region_id, name=r.name, cluster_count=len(r.cluster_ids))
        for r in mgr.list_regions(owner_subject=subject)
    ]


@regional_router.get(
    "/{region_id}",
    response_model=RegionState,
    dependencies=[Depends(verify_license)],
)
def get_region(region_id: str, request: Request):
    mgr = _get_manager()
    subject = license_subject(request)
    state = mgr.get_region_state(region_id, owner_subject=subject)
    if state is None:
        raise HTTPException(status_code=404, detail=_NOT_FOUND)
    return RegionState(**state)


@regional_router.delete("/{region_id}", dependencies=[Depends(verify_license)])
def delete_region(region_id: str, request: Request):
    mgr = _get_manager()
    subject = license_subject(request)
    if not mgr.delete_region(region_id, owner_subject=subject):
        raise HTTPException(status_code=404, detail=_NOT_FOUND)
    return {"deleted": True}


@regional_router.post(
    "/{region_id}/clusters",
    dependencies=[Depends(verify_license)],
)
def add_cluster(region_id: str, request: Request, req: RegionClusterRequest):
    mgr = _get_manager()
    subject = license_subject(request)
    added = mgr.add_cluster(region_id, req.cluster_id, owner_subject=subject)
    if not added:
        raise HTTPException(status_code=404, detail=_NOT_FOUND)
    return {"added": True}


@regional_router.delete(
    "/{region_id}/clusters/{cluster_id}",
    dependencies=[Depends(verify_license)],
)
def remove_cluster(region_id: str, cluster_id: str, request: Request):
    mgr = _get_manager()
    subject = license_subject(request)
    removed = mgr.remove_cluster(region_id, cluster_id, owner_subject=subject)
    if not removed:
        raise HTTPException(status_code=404, detail="Cluster or region not found")
    return {"removed": True}


@regional_router.get(
    "/{region_id}/events",
    response_model=list[DriftEventItem],
    dependencies=[Depends(verify_license)],
)
def region_events(
    region_id: str,
    request: Request,
    limit: int = Query(default=20, ge=1, le=1000),
):
    mgr = _get_manager()
    subject = license_subject(request)
    if mgr.get_region(region_id, owner_subject=subject) is None:
        raise HTTPException(status_code=404, detail=_NOT_FOUND)
    return [
        DriftEventItem(
            cluster_id=ev.cluster_id,
            region_id=ev.region_id,
            drift_score=ev.drift_score,
            drift_phase=ev.drift_phase,
            timestamp=ev.timestamp,
        )
        for ev in mgr.get_recent_events(region_id, limit=limit)
    ]
