"""Layer 4 — Read-only global observer.

Scans cluster states from registered regions to detect anomalies:
  * cross_cluster_convergence: 3+ clusters in different regions
    converging to the same non-initialization phase.
  * systemic_drift: >50% of observed clusters show drift indicators.
  * cluster_divergence: a single cluster has an interaction_count >3x
    the region average.

Thread-safe and read-only w.r.t. every cluster / member session.
"""

from __future__ import annotations

import collections
import contextlib
import logging
import threading
import time
import uuid
from dataclasses import dataclass
from typing import Any

import numpy as np

from semvec.api.cluster_manager import ClusterManager
from semvec.api.regional_manager import RegionalManager
from semvec.api.session_manager import SessionManager

logger = logging.getLogger(__name__)

_DEFAULT_MAX_ANOMALIES = 1000


@dataclass
class AnomalyEvent:
    anomaly_id: str
    timestamp: float
    anomaly_type: str
    affected_cluster_ids: list[str]
    description: str
    severity: float


class GlobalObserver:
    """Read-only observer scanning registered regions for anomalies."""

    def __init__(
        self,
        cluster_manager: ClusterManager,
        regional_manager: RegionalManager,
        session_manager: SessionManager | None = None,
        sample_interval_seconds: float = 30.0,
        max_anomalies: int = _DEFAULT_MAX_ANOMALIES,
    ) -> None:
        self.observer_id: str = str(uuid.uuid4())
        self._cluster_manager = cluster_manager
        self._regional_manager = regional_manager
        self._session_manager = session_manager
        self.sample_interval_seconds = sample_interval_seconds
        self._registered_regions: list[str] = []
        self._anomalies: collections.deque[AnomalyEvent] = collections.deque(maxlen=max_anomalies)
        self._last_sample_time: float | None = None
        self._lock = threading.Lock()

        # Observer's own meta-session for the pattern vector (G8).
        if session_manager is not None:
            self.meta_session_id: str = session_manager.create_session()
        else:
            self.meta_session_id = ""

    # ------------------------------------------------------------------
    # Region registration

    def register_region(self, region_id: str) -> None:
        with self._lock:
            if region_id not in self._registered_regions:
                self._registered_regions.append(region_id)

    def unregister_region(self, region_id: str) -> None:
        with self._lock, contextlib.suppress(ValueError):
            self._registered_regions.remove(region_id)

    def get_registered_regions(self) -> list[str]:
        with self._lock:
            return list(self._registered_regions)

    # ------------------------------------------------------------------
    # Sampling

    def sample(self) -> dict[str, Any]:
        start = time.time()

        with self._lock:
            region_ids = list(self._registered_regions)

        region_cluster_states: dict[str, list[dict[str, Any]]] = {}
        all_cluster_states: list[dict[str, Any]] = []
        total_clusters = 0

        for rid in region_ids:
            region = self._regional_manager.get_region(rid)
            if region is None:
                continue
            cluster_ids = list(region.cluster_ids)
            states: list[dict[str, Any]] = []
            for cid in cluster_ids:
                state = self._cluster_manager.get_cluster_state(cid)
                if state is None:
                    continue
                state["_region_id"] = rid
                states.append(state)
                total_clusters += 1
            region_cluster_states[rid] = states
            all_cluster_states.extend(states)

        new_anomalies: list[AnomalyEvent] = []
        new_anomalies.extend(self._detect_cross_cluster_convergence(region_cluster_states))
        new_anomalies.extend(self._detect_systemic_drift(all_cluster_states))
        new_anomalies.extend(self._detect_cluster_divergence(region_cluster_states))

        with self._lock:
            for anomaly in new_anomalies:
                self._anomalies.append(anomaly)
            self._last_sample_time = time.time()
            total_anomalies = len(self._anomalies)

        self._update_pattern_vector(all_cluster_states)

        elapsed_ms = (time.time() - start) * 1000
        return {
            "sampled_at": self._last_sample_time,
            "sample_duration_ms": round(elapsed_ms, 2),
            "regions_sampled": len(region_ids),
            "clusters_sampled": total_clusters,
            "new_anomalies": len(new_anomalies),
            "total_anomalies": total_anomalies,
        }

    def _update_pattern_vector(self, all_cluster_states: list[dict[str, Any]]) -> None:
        if self._session_manager is None or not self.meta_session_id:
            return
        vectors: list[list[float]] = []
        weights: list[float] = []
        for state in all_cluster_states:
            agg = state.get("aggregate_vector")
            if agg is None:
                continue
            vec = np.asarray(agg, dtype=np.float64)
            if np.linalg.norm(vec) < 1e-8:
                continue
            vectors.append(list(vec))
            weights.append(float(max(state.get("interaction_count", 0), 1)))
        if not vectors:
            return
        from semvec.cortex import WeightedAverageAggregation

        dim = len(vectors[0])
        aggregator = WeightedAverageAggregation(dimension=dim)
        pattern = np.asarray(aggregator.aggregate(vectors, weights))
        self._session_manager.set_session_vector(self.meta_session_id, pattern)

    def get_pattern_vector(self) -> np.ndarray | None:
        if self._session_manager is None or not self.meta_session_id:
            return None
        vec = self._session_manager.get_session_vector(self.meta_session_id)
        if vec is None or np.linalg.norm(vec) < 1e-8:
            return None
        return vec

    # ------------------------------------------------------------------
    # Anomaly detection

    def _detect_cross_cluster_convergence(
        self, region_cluster_states: dict[str, list[dict[str, Any]]]
    ) -> list[AnomalyEvent]:
        anomalies: list[AnomalyEvent] = []
        phase_to_clusters: dict[str, list[tuple[str, str]]] = {}
        for rid, states in region_cluster_states.items():
            for s in states:
                if s.get("interaction_count", 0) > 2:
                    phase = s.get("phase", "initialization")
                    cid = s.get("cluster_id", "")
                    phase_to_clusters.setdefault(phase, []).append((cid, rid))

        for phase, pairs in phase_to_clusters.items():
            unique_regions = {r for _, r in pairs}
            if len(unique_regions) >= 2 and len(pairs) >= 3:
                affected = [cid for cid, _ in pairs]
                n = len(affected)
                severity = min(1.0, (n - 2) / 5)
                anomalies.append(
                    AnomalyEvent(
                        anomaly_id=str(uuid.uuid4()),
                        timestamp=time.time(),
                        anomaly_type="cross_cluster_convergence",
                        affected_cluster_ids=affected,
                        description=(
                            f"{n} clusters across {len(unique_regions)} "
                            f"regions converged to phase '{phase}'"
                        ),
                        severity=severity,
                    )
                )
        return anomalies

    def _detect_systemic_drift(
        self, all_cluster_states: list[dict[str, Any]]
    ) -> list[AnomalyEvent]:
        if not all_cluster_states:
            return []
        drifted_ids: list[str] = []
        for s in all_cluster_states:
            ic = s.get("interaction_count", 0)
            sim_history = s.get("similarity_history", [])
            if ic >= 10 and len(sim_history) >= 5:
                recent = sim_history[-5:]
                if len(recent) >= 2:
                    mean_sim = sum(recent) / len(recent)
                    variance = sum((x - mean_sim) ** 2 for x in recent) / len(recent)
                    if variance > 0.01 or mean_sim < 0.3:
                        drifted_ids.append(s.get("cluster_id", ""))

        total = len(all_cluster_states)
        if total > 0 and len(drifted_ids) / total > 0.5:
            severity = min(1.0, len(drifted_ids) / total)
            return [
                AnomalyEvent(
                    anomaly_id=str(uuid.uuid4()),
                    timestamp=time.time(),
                    anomaly_type="systemic_drift",
                    affected_cluster_ids=drifted_ids,
                    description=(f"{len(drifted_ids)}/{total} clusters show drift signals"),
                    severity=severity,
                )
            ]
        return []

    def _detect_cluster_divergence(
        self, region_cluster_states: dict[str, list[dict[str, Any]]]
    ) -> list[AnomalyEvent]:
        anomalies: list[AnomalyEvent] = []
        for states in region_cluster_states.values():
            if len(states) < 2:
                continue
            counts = [s.get("interaction_count", 0) for s in states]
            avg = sum(counts) / len(counts)
            if avg < 1:
                continue
            for s in states:
                ic = s.get("interaction_count", 0)
                if ic > avg * 3:
                    cid = s.get("cluster_id", "")
                    anomalies.append(
                        AnomalyEvent(
                            anomaly_id=str(uuid.uuid4()),
                            timestamp=time.time(),
                            anomaly_type="cluster_divergence",
                            affected_cluster_ids=[cid],
                            description=(
                                f"Cluster {cid} has {ic} interactions vs "
                                f"region avg {avg:.1f} (>3x)"
                            ),
                            severity=0.5,
                        )
                    )
        return anomalies

    # ------------------------------------------------------------------
    # Anomaly retrieval

    def get_anomalies(self, limit: int = 20) -> list[AnomalyEvent]:
        with self._lock:
            items = list(self._anomalies)
        items.reverse()
        return items[:limit]

    def clear_anomalies(self) -> int:
        with self._lock:
            count = len(self._anomalies)
            self._anomalies.clear()
        return count

    def get_summary(self) -> dict[str, Any]:
        with self._lock:
            regions = list(self._registered_regions)
            last_sample = self._last_sample_time
            total_logged = len(self._anomalies)
            recent = list(self._anomalies)
        recent.reverse()
        recent_dicts = [
            {
                "anomaly_id": a.anomaly_id,
                "timestamp": a.timestamp,
                "anomaly_type": a.anomaly_type,
                "affected_cluster_ids": a.affected_cluster_ids,
                "description": a.description,
                "severity": a.severity,
            }
            for a in recent[:5]
        ]
        return {
            "observer_id": self.observer_id,
            "registered_regions": len(regions),
            "total_clusters_observed": sum(
                len(self._regional_manager.get_region(r).cluster_ids)
                for r in regions
                if self._regional_manager.get_region(r) is not None
            ),
            "last_sample_at": last_sample,
            "anomaly_count": total_logged,
            "recent_anomalies": recent_dicts,
            "meta_session_id": self.meta_session_id,
        }


class ObserverManager:
    """Registry of GlobalObserver instances — one per license subject."""

    def __init__(
        self,
        cluster_manager: ClusterManager,
        regional_manager: RegionalManager,
        session_manager: SessionManager | None = None,
    ) -> None:
        self._cluster_manager = cluster_manager
        self._regional_manager = regional_manager
        self._session_manager = session_manager
        self._observers: dict[str, tuple[GlobalObserver, str | None]] = {}
        self._by_owner: dict[str, str] = {}
        self._lock = threading.Lock()

    def get_for_subject(self, owner_subject: str | None) -> GlobalObserver | None:
        if owner_subject is None:
            return None
        with self._lock:
            oid = self._by_owner.get(owner_subject)
            if oid is None:
                return None
            entry = self._observers.get(oid)
        if entry is None:
            return None
        return entry[0]

    def create_observer(
        self,
        sample_interval_seconds: float = 30.0,
        owner_subject: str | None = None,
    ) -> GlobalObserver:
        with self._lock:
            if owner_subject is not None:
                oid = self._by_owner.get(owner_subject)
                if oid is not None:
                    entry = self._observers.get(oid)
                    if entry is not None:
                        return entry[0]

            obs = GlobalObserver(
                cluster_manager=self._cluster_manager,
                regional_manager=self._regional_manager,
                session_manager=self._session_manager,
                sample_interval_seconds=sample_interval_seconds,
            )
            self._observers[obs.observer_id] = (obs, owner_subject)
            if owner_subject is not None:
                self._by_owner[owner_subject] = obs.observer_id
        return obs

    def delete_observer(self, observer_id: str, owner_subject: str | None = None) -> bool:
        with self._lock:
            entry = self._observers.get(observer_id)
            if entry is None:
                return False
            _, stored_owner = entry
            if (
                owner_subject is not None
                and stored_owner is not None
                and stored_owner != owner_subject
            ):
                return False
            del self._observers[observer_id]
            if stored_owner is not None:
                self._by_owner.pop(stored_owner, None)
        return True
