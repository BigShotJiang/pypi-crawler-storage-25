"""Command-line entry point: ``semvec serve ...``.

Exposed as a console-script via the ``[project.scripts]`` table in
``pyproject.toml``. Installs alongside the package.
"""

from __future__ import annotations

import argparse
import logging
import sys


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="semvec", description="Semvec REST API server")
    sub = parser.add_subparsers(dest="command", required=True)

    serve = sub.add_parser("serve", help="Run the Semvec REST API")
    serve.add_argument("--host", default="0.0.0.0")
    serve.add_argument("--port", type=int, default=8080)
    serve.add_argument("--reload", action="store_true")
    serve.add_argument(
        "--log-level", default="info", choices=["critical", "error", "warning", "info", "debug"]
    )

    args = parser.parse_args(argv)

    if args.command == "serve":
        logging.basicConfig(level=getattr(logging, args.log_level.upper()))
        try:
            import uvicorn
        except ImportError:
            print(
                "uvicorn is required to serve the API. Install with: " 'pip install "semvec[api]"',
                file=sys.stderr,
            )
            return 2
        uvicorn.run(
            "semvec.api:create_app",
            factory=True,
            host=args.host,
            port=args.port,
            reload=args.reload,
            log_level=args.log_level,
        )
        return 0

    return 1


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
