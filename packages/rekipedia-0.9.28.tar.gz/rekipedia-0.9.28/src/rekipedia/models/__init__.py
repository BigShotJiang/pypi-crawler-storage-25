"""rekipedia.models package."""
