<p align="center">
  <a href="https://github.com/VLDB-Toolkits/VLDB-Toolkits"><img src="https://raw.githubusercontent.com/VLDB-Toolkits/VLDB-Toolkits/main/docs/screenshots/readme/logo.png" width="160" height="160" alt="VLDB-Toolkits"></a>
</p>

<h1 align="center">VLDB-Toolkits</h1>

<p align="center">
  A cross-platform desktop application for VLDB / SIGMOD / ICDE program committees — ingest CMT submission exports, detect quota violations, disambiguate duplicate author identities, and export styled Excel reports for the PC chair.
</p>

<p align="center">
  <a href="https://pypi.org/project/vldb-toolkits/"><img src="https://img.shields.io/pypi/v/vldb-toolkits?style=for-the-badge&labelColor=0f172a&color=00d9ff"></a>
  <a href="https://github.com/VLDB-Toolkits/VLDB-Toolkits/blob/main/LICENSE"><img src="https://img.shields.io/badge/License-MIT-f97316?style=for-the-badge&labelColor=0f172a"></a>
  <img src="https://img.shields.io/badge/Platform-macOS_|_Windows_|_Linux-22c55e?style=for-the-badge&labelColor=0f172a">
  <img src="https://img.shields.io/badge/Tauri-2.x-a855f7?style=for-the-badge&labelColor=0f172a">
</p>

---

## Contents

- [What is this?](#what-is-this)
- [Screenshots](#screenshots)
- [Install](#install)
- [Quick start](#quick-start)
- [Features](#features)
- [Duplicate detection](#duplicate-detection)
- [How the pip wrapper works](#how-the-pip-wrapper-works)
- [Reporting issues](#reporting-issues)
- [Author](#author)
- [License](#license)

---

## What is this?

Modern database conferences receive thousands of submissions per cycle,
and the program committee must verify that no single author exceeds the
per-conference submission quota (typically two papers). Doing so by hand
is error-prone: author names appear in multiple spelling variants
(`Yinbin Miao` vs. `Y.B. Miao` vs. `Yinbin MIAO`), the same person
submits under different institutional emails, and CMT exports do not
provide built-in cross-paper author aggregation.

**VLDB-Toolkits automates this entire workflow.** Given an Excel export
from the conference management system, it parses every submission,
aggregates authors across papers, flags anyone exceeding the quota,
proactively surfaces likely duplicates with confidence scores, lets
reviewers link author variants into a single canonical identity, and
finally exports a styled Excel report in the exact format PC chairs
expect.

It is built as a **Tauri 2 desktop binary** with a Rust backend for
native-speed streaming Excel I/O and in-memory querying, and a React
frontend for interactive review. Files with **300,000+ submissions**
have been tested on a standard laptop without exceeding browser memory
limits — the frontend holds only a 100-row pagination window, and every
search, filter, and aggregation runs in Rust.

## Screenshots

<p align="center">
  <img src="https://raw.githubusercontent.com/VLDB-Toolkits/VLDB-Toolkits/main/docs/screenshots/readme/authors-page-dark.jpg" alt="Authors page with seven inline filters and smart suggestions button" width="820">
</p>

<p align="center"><em>Authors page — seven inline filters (quota violations, email conflicts, duplicate names, fuzzy names, name + organization, linked, not linked) plus a one-click smart-suggestions button.</em></p>

<p align="center">
  <img src="https://raw.githubusercontent.com/VLDB-Toolkits/VLDB-Toolkits/main/docs/screenshots/readme/suggestions-dialog.jpg" alt="Duplicate suggestions dialog" width="720">
</p>

<p align="center"><em>Smart suggestions dialog — ranked candidate duplicate pairs with confidence scores, one-click Link / Dismiss. Dismissed pairs are remembered across sessions.</em></p>

<p align="center">
  <img src="https://raw.githubusercontent.com/VLDB-Toolkits/VLDB-Toolkits/main/docs/screenshots/readme/papers-page.jpg" alt="Papers page with author badges and quota warnings" width="820">
</p>

<p align="center"><em>Papers page — warning rows highlighted, author badges color-coded (red = over quota, blue = corresponding author, purple = linked group).</em></p>

<p align="center">
  <img src="https://raw.githubusercontent.com/VLDB-Toolkits/VLDB-Toolkits/main/docs/screenshots/readme/authors-linked-filter.jpg" alt="Linked authors filter with tooltip showing group members" width="820">
</p>

<p align="center"><em>Linked-authors filter active — merge groups show a purple link badge; hovering it reveals every group member with the primary record highlighted.</em></p>

## Install

```bash
pip install vldb-toolkits
vldb-toolkits
```

The Python package is a thin wrapper (~50 KB) that downloads the
appropriate platform binary from GitHub Releases on first launch into
`~/.vldb-toolkits/`. Subsequent launches are instant.

Alternatively, download a signed installer directly from the
[latest GitHub release](https://github.com/VLDB-Toolkits/VLDB-Toolkits/releases/latest):

| Platform              | Asset                                                 |
| --------------------- | ----------------------------------------------------- |
| macOS (Apple Silicon) | `VLDB-Toolkits_*_aarch64.dmg` — signed with Developer ID |
| macOS (Intel)         | `VLDB-Toolkits_*_x64.dmg` — signed with Developer ID     |
| Windows 10 / 11       | `VLDB-Toolkits_*_setup.exe` (NSIS) or `*_x64.msi`     |
| Linux (any)           | `VLDB-Toolkits_*.AppImage`                             |

### CLI reference

```bash
vldb-toolkits                 # launch the desktop app
vldb-toolkits --version       # print installed version
vldb-toolkits --path          # print binary install path
vldb-toolkits --check-update  # query GitHub for a newer release
vldb-toolkits --update        # download and install the latest release
vldb-toolkits --install       # force-reinstall the binary
vldb-toolkits --uninstall     # remove binary + shell profile entries
```

## Quick start

1. **Launch** the app and drop your CMT `.xlsx` export onto the Data
   Import page (or use the file picker).
2. **Review** the Authors page. Turn on *Quota violations* to see
   every author exceeding the per-conference limit. Use *Fuzzy names*,
   *Name + org*, or *Duplicate names* to surface spelling variants.
3. **Click the *N suggestions* button** next to the search box — the
   backend has already ranked the most likely duplicate pairs. Use
   *Link* for one-click merge, *Dismiss* to hide a false positive
   (dismissals are remembered forever).
4. **Annotate** individual papers with free-text notes from the
   Actions column on the Papers page.
5. **Export** a styled Excel report via the Export button. The output
   file is a 45-column styled workbook ready for delivery to the PC
   chair, with rich-text coloring for over-quota authors, linked
   groups, and your notes.

## Features

- **Import** `.xlsx` / `.xls` exports from CMT / Microsoft Research
  Academic — including 500 MB files with 300,000+ submissions.
- **Quota detection** with a ranked warning system that excludes the
  author's first two accepted slots.
- **Seven inline author filters** with hover tooltips:
  *Quota violations*, *Email conflicts*, *Duplicate names*,
  *Fuzzy names*, *Name + organization*, *Linked*, *Not linked*.
- **Smart duplicate suggestions** — three parallel backend passes
  (exact name, fuzzy / initial variant, email-handle fingerprint),
  ranked and scored for confidence, one-click merge or dismiss.
- **Anti-evasion normalization** — see
  [Duplicate detection](#duplicate-detection).
- **Manual linking** into named merge groups, with unlink and
  group-manage dialogs.
- **Inline paper notes** that persist across sessions and are
  included in exports.
- **Styled Excel export** — 45 columns, rich-text coloring for
  quota-violating and linked authors, merge-group annotations.
- **Server-side paginated queries** — the frontend never holds more
  than 100 rows in memory regardless of dataset size.
- **Cross-platform** signed installers; English and Simplified Chinese UI.

## Duplicate detection

The duplicate detector is designed to defeat common evasion tactics:

| Evasion technique                                | Defence                                                       |
| ------------------------------------------------ | ------------------------------------------------------------- |
| Same name, change of institution                 | Exact-name pass ignores organization                          |
| Given-name typo (1–2 chars)                      | Bounded Levenshtein with a tight threshold                    |
| Added or dropped middle initial                  | Structural matcher with two-pointer token alignment           |
| Dotted initials (`J.M. Smith`)                   | Normalization turns dots into spaces                          |
| Uppercase / mixed case                           | Normalization lowercases everything                           |
| Zero-width space / NBSP inserted into a name     | Normalization drops invisible characters and folds NBSP       |
| Latin diacritics (`Miáo` vs `Miao`)              | `strip_diacritics` folds a hand-rolled table of 50+ marks     |
| Gmail dot / `+tag` aliasing                      | `normalize_email` strips dots and `+tag` for Gmail            |
| Same handle across institutional emails          | Email-handle pass matches on alphanumeric local-part fingerprint |
| Org abbreviation vs full name                    | `orgs_equivalent` matches `MIT` to `Massachusetts Institute of Technology` |
| `Tokyo University` vs `University of Tokyo`      | Token sort after stopword removal                             |
| `MIT` vs `MIT CSAIL` (subgroup)                  | Prefix containment on the stopword-free canonical             |

**Hard constraints** the matcher enforces to avoid false positives:

- The **family name** must align (exact or single-letter initial).
  `Qingqing Ye` and `Qingying Xu` have full-string edit distance 3
  but different surnames, so they are never merged.
- **Middle initials** that appear at the same position must match.
  `John A Smith` and `John B Smith` are rejected outright.
- Typo threshold is **capped at 1–2 characters** — real typos rarely
  exceed this, and anything further apart is overwhelmingly likely
  to be a different person.

The full algorithm is covered by **28 Rust unit tests** and is
specified in detail in the
[user manual](https://github.com/VLDB-Toolkits/VLDB-Toolkits/blob/main/docs/vldb_toolkits_manual.pdf).

## How the pip wrapper works

This Python package does **not** contain the desktop application
itself. It is a small (~50 KB) wrapper that:

1. Detects your operating system and architecture
   (`darwin_arm64`, `darwin_x86_64`, `linux_x86_64`, `windows_x86_64`).
2. Queries the GitHub Releases API for the matching signed binary
   asset (signed DMG for macOS, NSIS / MSI for Windows, AppImage for
   Linux).
3. Downloads the binary into `~/.vldb-toolkits/` on first launch.
4. Launches the desktop application; subsequent launches are instant.

On macOS the wrapper mounts the downloaded `.dmg`, copies the `.app`
bundle out, and detaches the image — the `.app` is preserved intact so
the Developer ID signature remains valid.

## Reporting issues

Please open an issue at
[github.com/VLDB-Toolkits/VLDB-Toolkits/issues](https://github.com/VLDB-Toolkits/VLDB-Toolkits/issues)
with:

- your platform and installed version (`vldb-toolkits --version`);
- a minimal Excel file that reproduces the problem, if applicable;
- the exact steps to reproduce;
- any console output or error dialog text.

## Author

**Silan Hu** — School of Computing, National University of Singapore
(silan.hu@u.nus.edu).

*Advised by Prof. Xiaokui Xiao, Editor-in-Chief of the Proceedings of
the VLDB Endowment (PVLDB) 2025 and Trustee of the VLDB Endowment
(2022–present, Secretary since 2024). The design of this tool was
directly informed by the practical workload of managing a real VLDB
submission cycle.*

## License

MIT License — see
[`LICENSE`](https://github.com/VLDB-Toolkits/VLDB-Toolkits/blob/main/LICENSE).

Built with [Tauri 2](https://tauri.app/), [React](https://react.dev/),
[shadcn/ui](https://ui.shadcn.com/),
[Zustand](https://zustand-demo.pmnd.rs/),
[calamine](https://github.com/tafia/calamine), and
[rust_xlsxwriter](https://github.com/jmcnamara/rust_xlsxwriter).
