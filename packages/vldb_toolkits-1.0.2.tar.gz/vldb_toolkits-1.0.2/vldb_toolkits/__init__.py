"""VLDB-Toolkits Python Wrapper

A Python wrapper for VLDB-Toolkits desktop application.
"""

__version__ = "1.0.2"
__author__ = "Silan Hu"
__email__ = "silan.hu@u.nus.edu"

from .cli import main
from .downloader import check_for_update, update_to_latest, get_latest_version

__all__ = ["main", "__version__", "check_for_update", "update_to_latest", "get_latest_version"]
