from __future__ import annotations

from collections import deque
from typing import NamedTuple
from typing import TYPE_CHECKING

import torch
from torch import Tensor

if TYPE_CHECKING:
    from rectokens.decoding.trie import Trie


class CompactCSRTrie(NamedTuple):
    """A trie encoded in Compressed Sparse Row (CSR) format for GPU-accelerated constrained decoding.

    Represents a prefix tree (trie) over valid token sequences as a sparse transition
    matrix in CSR format, enabling the tree traversal to be expressed as batched tensor
    operations on hardware accelerators. This avoids the severe latency penalties of
    pointer-chasing through a conventional trie on GPUs/TPUs.

    Proposed by Su et al. as the STATIC (Sparse Transition Matrix-Accelerated Trie Index
    for Constrained Decoding) method in:

        "Vectorizing the Trie: Efficient Constrained Decoding for LLM-based Generative
        Retrieval on Accelerators", Su et al. (2026).
        https://arxiv.org/abs/2602.22647
    """

    row_ptrs: Tensor
    stacked_cols_vals: Tensor
    layer_max_branches: list[int]
    dense_mask_by_layer: list[Tensor]
    dense_states: Tensor
    vocab_size: int

    @classmethod
    def from_trie(
        cls, trie: Trie, vocab_size: int, dense_lookup_layers: int = 2
    ) -> CompactCSRTrie:
        row_ptrs = []
        col_idxs = []
        max_children_at_depth: dict[int, int] = {}
        dense_lookup_mask = torch.zeros(
            [vocab_size] * dense_lookup_layers, dtype=torch.bool
        )
        dense_states = torch.zeros([vocab_size] * dense_lookup_layers, dtype=torch.long)

        next_bfs_idx = 1  # root is BFS row 0
        frontier: deque[tuple] = deque([(trie.root, 0, ())])
        while frontier:
            node, depth, path = frontier.popleft()
            row_ptrs.append(len(col_idxs))

            n_children = len(node.children)
            max_children_at_depth[depth] = max(
                max_children_at_depth.get(depth, 0), n_children
            )

            for token, child in node.children.items():
                col_idxs.append(token)
                child_path = path + (token,)

                if len(child_path) == dense_lookup_layers:
                    dense_lookup_mask[child_path] = True
                    dense_states[child_path] = next_bfs_idx

                frontier.append((child, depth + 1, child_path))
                next_bfs_idx += 1

        col_idxs.append(-1)
        values = list(range(1, len(col_idxs))) + [-1]

        layer_max_branches = [
            max_children_at_depth.get(d, 0)
            for d in range(max(max_children_at_depth, default=-1) + 1)
        ]

        mask = dense_lookup_mask
        dense_mask_by_layer = []
        for _ in range(dense_lookup_layers - 1, -1, -1):
            dense_mask_by_layer.append(mask)
            mask = mask.any(dim=-1)
        dense_mask_by_layer.reverse()

        return cls(
            row_ptrs=torch.tensor(row_ptrs),
            stacked_cols_vals=torch.stack(
                [torch.tensor(col_idxs), torch.tensor(values)]
            ),
            layer_max_branches=layer_max_branches,
            dense_mask_by_layer=dense_mask_by_layer,
            dense_states=dense_states,
            vocab_size=vocab_size,
        )

    @classmethod
    def from_sorted_batch(
        cls, sem_ids: Tensor, vocab_size: int, dense_lookup_layers: int = 2
    ) -> CompactCSRTrie:
        """
        Expects sem_ids to be a 2D tensor with rows lexicographically sorted.
        """
        N, L = sem_ids.shape
        dense_lookup_layers = min(dense_lookup_layers, L)
        device = sem_ids.device

        sem_ids_aug = torch.cat([torch.full_like(sem_ids[:1], -1), sem_ids], dim=0)
        is_new_node = (sem_ids_aug[1:] != sem_ids_aug[:-1]).cumsum(dim=-1) > 0  # (N, L)

        is_new_node_T = is_new_node.T.contiguous()  # (L, N)
        node_ids = is_new_node_T.flatten().cumsum(0).view(L, N)

        cols = torch.cat(
            [
                sem_ids.T[is_new_node_T],
                torch.tensor([-1], dtype=sem_ids.dtype, device=device),
            ]
        )

        # Parent IDs for each edge — sorted by construction (node_ids is a cumsum)
        parts = [
            torch.zeros(int(is_new_node[:, 0].sum()), dtype=torch.long, device=device)
        ]
        layer_max_branches = [len(parts[0])]
        for d in range(1, L):
            t = node_ids[d - 1][is_new_node[:, d]]
            parts.append(t)
            layer_max_branches.append(int(t.bincount().max()) if len(t) > 0 else 0)
        parents = torch.cat(parts)  # (nnz,) sorted

        changes = (
            torch.where(parents.diff() != 0)[0] + 1
            if len(parents) > 1
            else torch.zeros(0, dtype=torch.long, device=device)
        )

        n_edges = len(cols) - 1
        rows = torch.cat(
            [
                torch.zeros(1, dtype=torch.long, device=device),
                changes,
                torch.full(
                    (n_edges - len(changes),), n_edges, dtype=torch.long, device=device
                ),
            ]
        )

        vals = torch.arange(1, len(cols) + 1, device=device)
        vals[-1] = -1

        stacked = torch.stack([cols, vals])

        if dense_lookup_layers == 0:
            return cls(
                row_ptrs=rows,
                stacked_cols_vals=stacked,
                layer_max_branches=layer_max_branches,
                dense_mask_by_layer=[],
                dense_states=torch.zeros(0, dtype=torch.long, device=device),
                vocab_size=vocab_size,
            )

        mask = torch.zeros(
            [vocab_size] * dense_lookup_layers, dtype=torch.bool, device=sem_ids.device
        )
        mask[sem_ids[:, :dense_lookup_layers].unbind(-1)] = True

        dense_states = torch.zeros(
            [vocab_size] * dense_lookup_layers, dtype=torch.long, device=device
        )
        dense_states[sem_ids[:, :dense_lookup_layers].unbind(-1)] = node_ids[
            dense_lookup_layers - 1
        ]

        dense_mask_by_layer = []
        for _ in range(dense_lookup_layers - 1, -1, -1):
            dense_mask_by_layer.append(mask)
            mask = mask.any(dim=-1)
        dense_mask_by_layer.reverse()

        return cls(
            row_ptrs=rows,
            stacked_cols_vals=stacked,
            layer_max_branches=layer_max_branches,
            dense_mask_by_layer=dense_mask_by_layer,
            dense_states=dense_states,
            vocab_size=vocab_size,
        )
