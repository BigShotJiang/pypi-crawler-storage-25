"""
MigraFlow CLI - Ferramenta de Consultoria
Uso: migraflow schema.sql [contexto] [--api-key mk_consultant_...]
"""
import sys
import os
import json
import argparse
import httpx
import time
from pathlib import Path
from datetime import datetime

DEFAULT_API_URL = "https://api.migraflow.com.br/api/v1"
VERSION = "1.3.2"

# ── Cores ANSI ────────────────────────────────────────────────────────────────
CYAN    = "\033[96m"
BLUE    = "\033[94m"
GREEN   = "\033[92m"
YELLOW  = "\033[93m"
RED     = "\033[91m"
GRAY    = "\033[90m"
BOLD    = "\033[1m"
RESET   = "\033[0m"

BANNER = f"""{CYAN}
  __  __ _                 _____ _
 |  \\/  (_)               |  ___| |
 | .  . |_  __ _ _ __ __ _| |_  | | _____      __
 | |\\/| | |/ _` | '__/ _` |  _| | |/ _ \\ \\ /\\ / /
 | |  | | | (_| | | | (_| | |   | | (_) \\ V  V /
 |_|  |_|_|\\__, |_|  \\__,_\\_|   |_|\\___/ \\_/\\_/
            __/ |
           |___/{RESET}  {GRAY}v{VERSION} — AI-powered database migration{RESET}
"""

def _enable_ansi():
    """Enable ANSI colors on Windows."""
    if sys.platform == "win32":
        import ctypes
        kernel32 = ctypes.windll.kernel32
        kernel32.SetConsoleMode(kernel32.GetStdHandle(-11), 7)

def _step(label: str, fn, *args, **kwargs):
    """Run a step showing spinner and elapsed time."""
    print(f"  {GRAY}{label:<35}{RESET}", end="", flush=True)
    t0 = time.time()
    result = fn(*args, **kwargs)
    elapsed = time.time() - t0
    print(f"{GREEN}OK{RESET}  {GRAY}({elapsed:.1f}s){RESET}")
    return result

def get_api_key(args_key):
    return args_key or os.getenv("MIGRAFLOW_API_KEY", "")

def _call_api(url, api_key, payload, timeout=180.0):
    try:
        response = httpx.post(
            url,
            headers={"Authorization": f"Bearer {api_key}"},
            json=payload,
            timeout=timeout,
        )
        response.raise_for_status()
        return response.json()
    except httpx.HTTPStatusError as e:
        print(f"\n  {RED}ERRO na API: {e.response.status_code}{RESET}")
        print(f"  {GRAY}{e.response.text}{RESET}\n")
        sys.exit(1)
    except httpx.TimeoutException:
        print(f"\n  {RED}ERRO: Timeout — schema muito grande, tente dividir em partes{RESET}\n")
        sys.exit(1)

def _build_risk_report(risk, summary, findings, sql_file, output_file):
    criticos = [f for f in findings if f.get("severity", "").lower().replace("í", "i") == "critico"]
    altos    = [f for f in findings if f.get("severity", "").lower() == "alto"]
    medios   = [f for f in findings if f.get("severity", "").lower() in ("medio", "médio")]
    score    = risk.get("score", 0)

    report = f"""# Relatorio de Riscos - MigraFlow
Gerado em: {datetime.now().strftime('%d/%m/%Y %H:%M')}
Arquivo: {sql_file}

## Score de Risco: {score}/100 - {risk.get('category', 'N/A')}

| Metrica | Valor |
|---------|-------|
| Tabelas | {summary.get('total_tables', 0)} |
| Colunas | {summary.get('total_columns', 0)} |
| Relacionamentos | {summary.get('total_relationships', 0)} |
| Downtime estimado | {risk.get('downtime_estimate', 'N/A')} |
| Complexidade | {summary.get('migration_complexity', 'N/A')} |
| Tempo estimado | {summary.get('estimated_time_hours', 0)}h |

## Findings

| Severidade | Qtd |
|-----------|-----|
| CRITICO | {len(criticos)} |
| ALTO | {len(altos)} |
| MEDIO | {len(medios)} |

"""
    for label, items in [("CRITICOS", criticos), ("ALTOS", altos), ("MEDIOS", medios)]:
        if items:
            report += f"## Riscos {label}\n\n"
            for f in items:
                loc = f"{f.get('table','')}.{f.get('column','')}" if f.get('column') else f.get('table', '')
                report += f"**{loc}** - {f.get('finding','')}\n"
                if f.get('recommendation'):
                    report += f"> `{f['recommendation']}`\n"
                report += "\n"

    Path(output_file).write_text(report, encoding="utf-8")
    return criticos, altos, medios

def _build_review_report(review, output_file):
    score = review.get("quality_score", 0)
    issues = review.get("issues", [])
    suggestions = review.get("suggestions", [])
    missing_indexes = review.get("missing_indexes", [])
    missing_constraints = review.get("missing_constraints", [])

    by_sev = {"critical": [], "high": [], "medium": [], "low": []}
    for issue in issues:
        by_sev.setdefault(issue.get("severity", "low"), []).append(issue)

    nivel = "[OTIMO]" if score >= 85 else "[BOM]" if score >= 70 else "[REGULAR]" if score >= 50 else "[RUIM]"
    report = f"""# Review do Script de Migracao - MigraFlow
Gerado em: {datetime.now().strftime('%d/%m/%Y %H:%M')}

## Score de Qualidade: {score}/100 {nivel}

{review.get('summary', '')}

"""
    for sev_label, sev_key in [("CRITICOS", "critical"), ("ALTOS", "high"), ("MEDIOS", "medium"), ("BAIXOS", "low")]:
        items = by_sev.get(sev_key, [])
        if items:
            report += f"## Problemas {sev_label}\n\n"
            for issue in items:
                table = f"`{issue['table']}`" if issue.get("table") else ""
                report += f"**{table}** {issue.get('description', '')}\n"
                if issue.get("fix"):
                    report += f"```sql\n{issue['fix']}\n```\n"
                report += "\n"

    if suggestions:
        report += "## Sugestoes de Melhoria\n\n"
        for s in suggestions:
            table = f"`{s['table']}`" if s.get("table") else ""
            report += f"**{table}** {s.get('description', '')}\n"
            if s.get("sql"):
                report += f"```sql\n{s['sql']}\n```\n"
            report += "\n"

    if missing_indexes:
        report += "## Indexes Faltando\n\n```sql\n" + "\n".join(missing_indexes) + "\n```\n\n"

    if missing_constraints:
        report += "## Constraints Faltando\n\n```sql\n" + "\n".join(missing_constraints) + "\n```\n\n"

    Path(output_file).write_text(report, encoding="utf-8")
    return score

def _risk_color(score):
    if score <= 25:  return GREEN
    if score <= 50:  return YELLOW
    if score <= 75:  return YELLOW
    return RED

def _risk_label(score):
    if score <= 25:  return "[BAIXO]"
    if score <= 50:  return "[MEDIO]"
    if score <= 75:  return "[ALTO]"
    return "[CRITICO]"

def _quality_color(score):
    if score >= 85:  return GREEN
    if score >= 70:  return GREEN
    if score >= 50:  return YELLOW
    return RED

def _quality_label(score):
    if score >= 85:  return "[OTIMO]"
    if score >= 70:  return "[BOM]"
    if score >= 50:  return "[REGULAR]"
    return "[RUIM]"

def main():
    _enable_ansi()

    parser = argparse.ArgumentParser(
        prog="migraflow",
        description="MigraFlow CLI - Analise de migracao de schema com IA",
    )
    parser.add_argument("sql_file", nargs="?", help="Arquivo .sql com o schema legado")
    parser.add_argument("context", nargs="?", default="", help="Contexto de negocio (ex: 'ERP Oracle 11g')")
    parser.add_argument("--api-key", default=None, help="Consultant API key (ou defina MIGRAFLOW_API_KEY). Docs: https://docs.wimeisoftwares.com")
    parser.add_argument("--target", default="postgresql", help="Dialeto de destino. Default: postgresql")
    parser.add_argument("--output", "-o", default=None, help="Diretorio de saida. Default: entrega_TIMESTAMP/")
    parser.add_argument("--url", default=DEFAULT_API_URL, help="URL da API MigraFlow")
    parser.add_argument("--review", action="store_true", help="Executa review de qualidade no migration.sql gerado")
    parser.add_argument("--validate", action="store_true", help="Apenas valida o schema sem gerar mapeamento completo")
    parser.add_argument("--version", "-v", action="version", version=f"%(prog)s {VERSION}")
    args = parser.parse_args()

    print(BANNER)

    if not args.sql_file:
        parser.print_help()
        sys.exit(1)

    api_key = get_api_key(args.api_key)
    if not api_key:
        print(f"  {RED}ERRO: API key nao encontrada.{RESET}")
        print(f"  {GRAY}Use --api-key mk_consultant_... ou defina MIGRAFLOW_API_KEY{RESET}\n")
        sys.exit(1)

    if not Path(args.sql_file).exists():
        print(f"  {RED}ERRO: Arquivo nao encontrado: {args.sql_file}{RESET}\n")
        sys.exit(1)

    ddl = Path(args.sql_file).read_text(encoding="utf-8", errors="ignore")
    output_dir = args.output or f"entrega_{datetime.now().strftime('%Y%m%d_%H%M%S')}"

    print(f"  {GRAY}Arquivo : {args.sql_file}{RESET}")
    if args.context:
        print(f"  {GRAY}Contexto: {args.context}{RESET}")
    print(f"  {GRAY}Target  : {args.target}{RESET}")
    print()

    # 0. Validate only (quick check)
    if args.validate:
        validate_data = _step(
            "Validando schema...",
            _call_api,
            f"{args.url}/mappings/analyze",
            api_key,
            {"ddl": ddl},
            60.0,
        )
        is_valid = validate_data.get("is_valid", False)
        db_type = validate_data.get("database_type", "Unknown")
        errors = validate_data.get("errors", [])
        preview = validate_data.get("preview", [])

        print()
        print(f"  {GRAY}{'─' * 51}{RESET}")
        print(f"  {BOLD}VALIDACAO{RESET}")
        print(f"  {GRAY}{'─' * 51}{RESET}")
        vc = GREEN if is_valid else RED
        print(f"  Status    {vc}{BOLD}{'VALIDO' if is_valid else 'INVALIDO'}{RESET}")
        print(f"  Dialeto   {db_type}")
        print(f"  Tabelas   {len(preview)}")
        if errors:
            print(f"\n  {RED}Erros:{RESET}")
            for e in errors:
                print(f"    - {e}")
        print(f"  {GRAY}{'─' * 51}{RESET}")
        print()
        return

    # 1. Analyze
    data = _step(
        "Analisando schema com IA...",
        _call_api,
        f"{args.url}/cli/analyze",
        api_key,
        {"ddl": ddl, "target_dialect": args.target, "context": args.context or None},
    )

    summary  = data.get("summary", {})
    risk     = data.get("risk_score", {})
    findings = risk.get("findings", [])
    migration_sql = data.get("migration_sql", "")

    # Save artifacts
    def _save():
        Path(output_dir).mkdir(exist_ok=True)
        Path(f"{output_dir}/migration.sql").write_text(migration_sql, encoding="utf-8")
        Path(f"{output_dir}/rollback.sql").write_text(data.get("rollback_sql", ""), encoding="utf-8")
        Path(f"{output_dir}/resultado_completo.json").write_text(
            json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8"
        )
        # Debug log
        log_entry = (
            f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] "
            f"file={args.sql_file} target={args.target} "
            f"tables={summary.get('total_tables', 0)} "
            f"risk={risk.get('score', 0)}/100 "
            f"output={output_dir}\n"
        )
        log_path = Path.home() / ".migraflow" / "cli.log"
        log_path.parent.mkdir(exist_ok=True)
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(log_entry)

    _step("Salvando artefatos...", _save)

    criticos, altos, medios = _step(
        "Gerando risk_report.md...",
        _build_risk_report,
        risk, summary, findings, args.sql_file, f"{output_dir}/risk_report.md",
    )

    # 2. Review (optional)
    review_score = None
    if args.review and migration_sql:
        review = _step(
            "Revisando migration.sql...",
            _call_api,
            f"{args.url}/cli/review",
            api_key,
            {"migration_sql": migration_sql, "target_dialect": args.target, "context": args.context or None},
            120.0,
        )
        review_score = _step(
            "Gerando review_report.md...",
            _build_review_report,
            review, f"{output_dir}/review_report.md",
        )

    # ── Resultado final ───────────────────────────────────────────────────────
    score = risk.get("score", 0)
    rc = _risk_color(score)
    rl = _risk_label(score)

    print()
    print(f"  {GRAY}{'─' * 51}{RESET}")
    print(f"  {BOLD}RESULTADO{RESET}")
    print(f"  {GRAY}{'─' * 51}{RESET}")
    print(f"  Risk Score    {rc}{BOLD}{score}/100  {rl}{RESET}")
    if review_score is not None:
        qc = _quality_color(review_score)
        ql = _quality_label(review_score)
        print(f"  SQL Quality   {qc}{BOLD}{review_score}/100  {ql}{RESET}")
    print(f"  Tabelas       {summary.get('total_tables', 0)}")
    print(f"  Colunas       {summary.get('total_columns', 0)}")
    print(f"  Downtime      {risk.get('downtime_estimate', 'N/A')}")

    total_criticos = len(criticos)
    if total_criticos > 0:
        print()
        print(f"  {YELLOW}{BOLD}REVISAO NECESSARIA — {total_criticos} risco(s) critico(s) detectado(s){RESET}")
        print(f"  {GRAY}Veja detalhes em: {output_dir}/risk_report.md{RESET}")

    print(f"  {GRAY}{'─' * 51}{RESET}")
    print()
    print(f"  {GRAY}Arquivos gerados em: {RESET}{BOLD}{output_dir}/{RESET}")
    print(f"  {GRAY}  - migration.sql{RESET}")
    print(f"  {GRAY}  - rollback.sql{RESET}")
    print(f"  {GRAY}  - risk_report.md{RESET}")
    if review_score is not None:
        print(f"  {GRAY}  - review_report.md{RESET}")
    print(f"  {GRAY}  - resultado_completo.json{RESET}")
    print()


if __name__ == "__main__":
    main()
