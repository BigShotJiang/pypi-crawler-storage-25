"""Asyncio game server: tick loop and per-client reader/writer coroutines."""

from __future__ import annotations

import asyncio
import logging
import statistics
import time
import uuid as _uuid_mod
from collections import deque
from typing import TYPE_CHECKING, Any

import numpy as np

from faraway_realms.ai import fov as _fov
from faraway_realms.ai.fov import DEFAULT_SIGHT_RANGE as _PLAYER_SIGHT_RANGE
from faraway_realms.game_logger import log_event
from faraway_realms.net.protocol import recv_message, send_message
from faraway_realms.net.serialization import (
    collect_entities,
    serialize_per_client,
    serialize_shared,
    serialize_tile_reveal,
)
from faraway_realms.types import Pos
from faraway_realms.world.commands import CommandParser, CommandResolver
from faraway_realms.world.events import Event, EventType

if TYPE_CHECKING:
    from faraway_realms.game import Game
    from faraway_realms.net.serialization import EntitySnapshot
    from faraway_realms.world.map import Map

_log = logging.getLogger(__name__)
_RECONNECT_GRACE_S: float = 30.0

# Thresholds for immediate warnings.
_WARN_TICK_MS: float = 50.0  # half the 10 Hz budget
_WARN_QUEUE: int = 20  # commands backed up across one inter-tick window


class _ServerMetrics:
    """Rolling tick-time and queue-depth statistics; logs every 10 seconds."""

    _LOG_INTERVAL: float = 10.0
    _WINDOW: int = 100  # ticks kept for rolling stats (~10 s at 10 Hz)

    _WARMUP_S: float = 2.0  # suppress warnings during startup (JIT + coverage overhead)

    def __init__(self) -> None:
        self._times: deque[float] = deque(maxlen=self._WINDOW)
        self._queue_hwm: int = 0
        self._bytes: deque[int] = deque(maxlen=self._WINDOW)
        self._ser_times: deque[float] = deque(maxlen=self._WINDOW)
        self._game_tick_ms: deque[float] = deque(maxlen=self._WINDOW)
        self._fov_ms: deque[float] = deque(maxlen=self._WINDOW)
        self._ser_pc_ms: deque[float] = deque(maxlen=self._WINDOW)
        self._send_ms: deque[float] = deque(maxlen=self._WINDOW)
        self._npc_ms: deque[float] = deque(maxlen=self._WINDOW)
        self._commands_ms: deque[float] = deque(maxlen=self._WINDOW)
        self._systems_ms: deque[float] = deque(maxlen=self._WINDOW)
        self._entity_count: int = 0
        self._events_fired: int = 0
        self._max_cascade: int = 0
        self._last_log: float = 0.0
        self._start: float = time.monotonic()

    def record(self, duration: float, queue_size: int, n_clients: int) -> None:
        """Record one tick's timing and queue depth."""
        self._times.append(duration)
        self._queue_hwm = max(self._queue_hwm, queue_size)
        if time.monotonic() - self._start >= self._WARMUP_S:
            self._warn_if_notable(duration, queue_size)
        self._maybe_log(n_clients)

    def record_broadcast(self, total_bytes: int, ser_ms: float) -> None:
        """Record one broadcast's outbound bytes and serialization time."""
        self._bytes.append(total_bytes)
        self._ser_times.append(ser_ms)

    def record_phases(
        self, game_tick_ms: float, fov_ms: float, ser_pc_ms: float, send_ms: float
    ) -> None:
        """Record per-phase timings for the current tick."""
        self._game_tick_ms.append(game_tick_ms)
        self._fov_ms.append(fov_ms)
        self._ser_pc_ms.append(ser_pc_ms)
        self._send_ms.append(send_ms)

    def record_game_stats(
        self,
        entity_count: int,
        events_fired: int,
        max_cascade: int,
        npc_ms: float,
        commands_ms: float,
        systems_ms: float,
    ) -> None:
        """Record game-internal stats for the current tick."""
        self._entity_count = entity_count
        self._events_fired += events_fired
        self._max_cascade = max(self._max_cascade, max_cascade)
        self._npc_ms.append(npc_ms)
        self._commands_ms.append(commands_ms)
        self._systems_ms.append(systems_ms)

    def _warn_if_notable(self, duration: float, queue_size: int) -> None:
        if duration * 1000 >= _WARN_TICK_MS:
            _log.warning(
                "slow tick %.1f ms (queue depth %d)", duration * 1000, queue_size
            )
        elif queue_size >= _WARN_QUEUE:
            _log.warning("command queue depth %d", queue_size)

    def _maybe_log(self, n_clients: int) -> None:
        now = time.monotonic()
        if now - self._last_log < self._LOG_INTERVAL or not self._times:
            return
        self._emit_log(n_clients)
        self._queue_hwm = 0
        self._events_fired = 0
        self._max_cascade = 0
        self._last_log = now

    @staticmethod
    def _mean(d: deque) -> float:  # type: ignore[type-arg]
        return statistics.mean(d) if d else 0.0

    def _emit_log(self, n_clients: int) -> None:
        avg_ms = statistics.mean(self._times) * 1000
        max_ms = max(self._times) * 1000
        _log.info(
            "server tick avg=%.1f ms  max=%.1f ms  queue_hwm=%d  clients=%d",
            avg_ms,
            max_ms,
            self._queue_hwm,
            n_clients,
        )
        log_event(
            "tick_stats",
            avg_ms=round(avg_ms, 2),
            max_ms=round(max_ms, 2),
            queue_hwm=self._queue_hwm,
            clients=n_clients,
            entity_count=self._entity_count,
            events_fired=self._events_fired,
            max_cascade=self._max_cascade,
            avg_npc_ms=round(self._mean(self._npc_ms), 2),
            avg_commands_ms=round(self._mean(self._commands_ms), 2),
            avg_systems_ms=round(self._mean(self._systems_ms), 2),
            avg_game_tick_ms=round(self._mean(self._game_tick_ms), 2),
            avg_fov_ms=round(self._mean(self._fov_ms), 2),
            avg_ser_pc_ms=round(self._mean(self._ser_pc_ms), 2),
            avg_send_ms=round(self._mean(self._send_ms), 2),
        )
        if self._bytes:
            _log.info(
                "broadcast avg=%.1f KB/tick  ser_shared avg=%.2f ms  max=%.2f ms",
                statistics.mean(self._bytes) / 1024,
                statistics.mean(self._ser_times),
                max(self._ser_times),
            )
        if self._game_tick_ms:
            _log.info(
                "phases avg ms: game_tick=%.2f  fov=%.2f  ser_pc=%.2f  send=%.2f"
                "  npc=%.2f  commands=%.2f  systems=%.2f",
                self._mean(self._game_tick_ms),
                self._mean(self._fov_ms),
                self._mean(self._ser_pc_ms),
                self._mean(self._send_ms),
                self._mean(self._npc_ms),
                self._mean(self._commands_ms),
                self._mean(self._systems_ms),
            )


class _ClientSession:
    def __init__(self, uuid: str, entity_id: int, username: str = "") -> None:
        self.uuid = uuid
        self.entity_id = entity_id
        self.username = username
        self.writer: asyncio.StreamWriter | None = None
        self._disconnected_at: float | None = None
        self._connected_at: float = time.monotonic()
        # Visibility culling state — persists across reconnects
        self.visible_entity_ids: frozenset[int] = frozenset()
        self.explored_tiles: set[Pos] = set()
        # Chat delivery offset: index of next undelivered message in game history
        self.chat_seq: int = 0
        # Death tracking — payload is set by the ENTITY_DIED subscriber; sent once
        self.alive: bool = True
        self.kills: int = 0
        self.joined_at_abs_tick: int = 0
        self.death_message_payload: dict[str, Any] | None = None

    def attach(self, writer: asyncio.StreamWriter) -> None:
        """Attach a writer and clear the disconnection timestamp."""
        self.writer = writer
        self._disconnected_at = None

    def detach(self) -> None:
        """Mark this session as disconnected."""
        self.writer = None
        self._disconnected_at = asyncio.get_event_loop().time()

    def grace_expired(self, now: float) -> bool:
        """Return True when the reconnection grace period has elapsed."""
        if self._disconnected_at is None:
            return False
        return now - self._disconnected_at > _RECONNECT_GRACE_S


def _fov_visible_tiles(game_map: Map, px: int, py: int) -> frozenset[Pos]:
    """Return (x, y) tiles visible from (px, py) within the player sight range."""
    fov = _fov.compute_fov(game_map, px, py, _PLAYER_SIGHT_RANGE)
    ys, xs = np.where(fov)
    return frozenset(zip(xs.tolist(), ys.tolist(), strict=True))


def _update_session_entities(
    session: _ClientSession,
    all_snaps: list[EntitySnapshot],
    visible: frozenset[Pos],
) -> frozenset[int]:
    """Update session visibility; return IDs that left FOV since last tick."""
    now_visible = frozenset(
        s.entity_id
        for s in all_snaps
        if (s.x, s.y) in visible or s.entity_id == session.entity_id
    )
    removed = session.visible_entity_ids - now_visible
    session.visible_entity_ids = now_visible
    return removed


class GameServer:
    """Asyncio server that owns the authoritative game tick loop.

    Parameters
    ----------
    game : Game
        The authoritative game state.
    host : str
        Bind address.
    port : int
        Bind port; use ``0`` to let the OS assign a free port.
    max_clients : int
        Maximum simultaneous connected clients.
    """

    def __init__(self, game: Game, host: str, port: int, max_clients: int = 8) -> None:
        self._game = game
        self._host = host
        self._port = port
        self._max_clients = max_clients
        self._sessions: dict[str, _ClientSession] = {}
        self._server: asyncio.Server | None = None
        self._loop: asyncio.AbstractEventLoop | None = None
        game.bus.subscribe(EventType.ENTITY_DYING, self._on_entity_dying, priority=0)
        game.bus.subscribe(EventType.ENTITY_DIED, self._on_entity_died, priority=0)

    @property
    def bound_port(self) -> int:
        """Resolved port after binding (useful when ``port=0``)."""
        if self._server is None:
            raise RuntimeError("Server not yet started")
        sock = self._server.sockets[0]
        return int(sock.getsockname()[1])

    async def run(self) -> None:
        """Start the tick loop and serve clients forever."""
        self._loop = asyncio.get_running_loop()
        self._server = await asyncio.start_server(
            self._handle_client, self._host, self._port
        )
        asyncio.create_task(self._tick_loop())  # noqa: RUF006
        async with self._server:
            try:
                await self._server.serve_forever()
            except asyncio.CancelledError:
                pass  # stop() was called; exit cleanly

    def stop(self) -> None:
        """Signal the server to stop from any thread."""
        server = self._server
        loop = self._loop
        if server is not None and loop is not None and not loop.is_closed():
            loop.call_soon_threadsafe(server.close)

    async def _tick_loop(self) -> None:
        interval = 1.0 / self._game.tick_rate
        metrics = _ServerMetrics()
        next_tick = time.monotonic()
        while True:
            t0 = time.monotonic()
            q = self._game.command_queue_size
            t_game = time.monotonic()
            self._game.tick()
            game_tick_ms = (time.monotonic() - t_game) * 1000
            event_stats = self._game.take_event_stats()
            phases = self._game.last_tick_phases
            await self._broadcast_tick(metrics, game_tick_ms)
            metrics.record_game_stats(
                entity_count=self._game.entity_count,
                events_fired=event_stats["events_fired"],
                max_cascade=event_stats["max_cascade_depth"],
                npc_ms=phases.get("npc_ms", 0.0),
                commands_ms=phases.get("commands_ms", 0.0),
                systems_ms=phases.get("systems_ms", 0.0),
            )
            self._reap_expired_sessions()
            metrics.record(time.monotonic() - t0, q, self._connected_count())
            next_tick += interval
            delay = next_tick - time.monotonic()
            if delay > 0:
                try:
                    loop = asyncio.get_event_loop()
                    await loop.run_in_executor(None, time.sleep, delay)
                except RuntimeError:
                    return  # executor shut down; exit tick loop cleanly
            else:
                next_tick = time.monotonic()  # too far behind; resync

    def _connected_count(self) -> int:
        return sum(1 for s in self._sessions.values() if s.writer is not None)

    def _session_visibility(
        self,
        session: _ClientSession,
        all_snaps: list[EntitySnapshot],
    ) -> tuple[frozenset[Pos], frozenset[int], frozenset[Pos]]:
        """Compute FOV; update session state; return (visible, removed, new_tiles)."""
        try:
            px, py = self._game.game_map.get_entity_position(session.entity_id)
        except KeyError:
            removed = frozenset(session.visible_entity_ids)
            session.visible_entity_ids = frozenset()
            return frozenset(), removed, frozenset()
        visible = _fov_visible_tiles(self._game.game_map, px, py)
        removed = _update_session_entities(session, all_snaps, visible)
        new_tiles = visible - session.explored_tiles
        session.explored_tiles |= visible
        return visible, removed, new_tiles

    def _session_for_entity(self, entity_id: int) -> _ClientSession | None:
        return next(
            (s for s in self._sessions.values() if s.entity_id == entity_id), None
        )

    def _on_entity_dying(self, event: Event) -> None:
        """Credit a kill to the session whose entity landed the killing blow."""
        entity = self._game.entity(event.source_id)
        if entity is None or entity.last_hit_by is None:
            return
        killer_session = self._session_for_entity(entity.last_hit_by)
        if killer_session is not None:
            killer_session.kills += 1

    def _on_entity_died(self, event: Event) -> None:
        """Stash a death payload on the session when a player entity is removed."""
        session = self._session_for_entity(event.source_id)
        if session is None or not session.alive:
            return
        session.alive = False
        ticks_alive = self._game.abs_tick - session.joined_at_abs_tick
        session.death_message_payload = {
            "type": "death",
            "lore": self._game.death_message,
            "kills": session.kills,
            "ticks_alive": ticks_alive,
            "tick_rate": self._game.tick_rate,
        }
        log_event(
            "player_death",
            username=session.username,
            entity_id=event.source_id,
            kills=session.kills,
            ticks_alive=ticks_alive,
        )

    async def _send_session_tick(
        self,
        session: _ClientSession,
        shared: dict[str, Any],
        all_snaps: list[EntitySnapshot],
        dirty_tiles: frozenset[Pos] | set[Pos],
    ) -> tuple[int, float, float, float]:
        """Send one tick payload to *session*.

        Returns (bytes, fov_ms, ser_ms, send_ms).
        """
        t = time.monotonic()
        visible, removed, new_tiles = self._session_visibility(session, all_snaps)
        fov_ms = (time.monotonic() - t) * 1000
        t = time.monotonic()
        new_messages = self._game.get_chat_since(session.chat_seq)
        session.chat_seq = self._game.chat_count
        per_client = serialize_per_client(
            self._game,
            session.entity_id,
            all_snaps,
            visible,
            removed,
            new_tiles,
            dirty_tiles=dirty_tiles,
            explored_tiles=session.explored_tiles,
            new_messages=new_messages,
        )
        ser_ms = (time.monotonic() - t) * 1000
        t = time.monotonic()
        n = await send_message(session.writer, shared | per_client)  # type: ignore[arg-type]
        return n, fov_ms, ser_ms, (time.monotonic() - t) * 1000

    async def _dispatch_session_msg(
        self,
        session: _ClientSession,
        shared: dict[str, Any],
        all_snaps: list[EntitySnapshot],
        dirty_tiles: frozenset[Pos] | set[Pos],
    ) -> tuple[int, float, float, float]:
        """Route a session to its outbound message.

        Returns (bytes, fov_ms, ser_ms, send_ms).
        """
        if session.death_message_payload is not None:
            await self._send_session_tick(session, shared, all_snaps, dirty_tiles)
            payload = session.death_message_payload
            n = await send_message(session.writer, payload)  # type: ignore[arg-type]
            session.death_message_payload = None
            return n, 0.0, 0.0, 0.0
        if session.alive:
            return await self._send_session_tick(
                session, shared, all_snaps, dirty_tiles
            )
        return 0, 0.0, 0.0, 0.0

    async def _broadcast_tick(
        self, metrics: _ServerMetrics, game_tick_ms: float
    ) -> None:
        t0 = time.monotonic()
        dirty_tiles = self._game.game_map.drain_dirty_tiles()
        shared = serialize_shared(self._game)
        all_snaps = collect_entities(self._game)
        ser_ms = (time.monotonic() - t0) * 1000
        total_bytes = 0
        fov_ms = ser_pc_ms = send_ms = 0.0
        for session in list(self._sessions.values()):
            if session.writer is None:
                continue
            try:
                nb, fm, sm, dm = await self._dispatch_session_msg(
                    session, shared, all_snaps, dirty_tiles
                )
                total_bytes += nb
                fov_ms += fm
                ser_pc_ms += sm
                send_ms += dm
            except OSError, ConnectionResetError:
                session.detach()
        metrics.record_broadcast(total_bytes, ser_ms)
        metrics.record_phases(game_tick_ms, fov_ms, ser_pc_ms, send_ms)

    def _despawn_entity(self, entity_id: int) -> None:
        """Queue ENTITY_DYING for a player entity leaving the game.

        The event is delivered on the next game.tick() → bus.flush() call.
        Safe to call for an already-dead entity; DeathSystem no-ops if the
        entity is absent from the map.
        """
        self._game.bus.publish(
            Event(
                event_type=EventType.ENTITY_DYING,
                source_id=entity_id,
                resolve_at_tick=self._game.abs_tick,
            )
        )

    def _on_goodbye(self, session: _ClientSession) -> None:
        """Immediately remove session and despawn entity on graceful disconnect.

        Session is popped before publishing ENTITY_DYING so that the
        kill-attribution and death-payload subscribers find no active session —
        correct, since there is nobody left to deliver a death message to.
        """
        self._sessions.pop(session.uuid, None)
        self._despawn_entity(session.entity_id)
        duration = round(time.monotonic() - session._connected_at, 1)
        log_event(
            "player_disconnect",
            username=session.username,
            entity_id=session.entity_id,
            graceful=True,
            duration_s=duration,
        )

    def _reap_expired_sessions(self) -> None:
        now = asyncio.get_event_loop().time()
        expired = [uuid for uuid, s in self._sessions.items() if s.grace_expired(now)]
        for uuid in expired:
            s = self._sessions.pop(uuid)
            duration = round(time.monotonic() - s._connected_at, 1)
            log_event(
                "player_session_end",
                username=s.username,
                entity_id=s.entity_id,
                duration_s=duration,
            )
            self._despawn_entity(s.entity_id)

    async def _handle_client(
        self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter
    ) -> None:
        try:
            await self._run_client(reader, writer)
        except OSError, asyncio.IncompleteReadError, KeyError:
            pass
        finally:
            writer.close()

    def _initial_explored_tiles(self, session: _ClientSession) -> set[Pos]:
        """Add the starting FOV to session.explored_tiles; return all explored tiles."""
        try:
            px, py = self._game.game_map.get_entity_position(session.entity_id)
            visible = _fov_visible_tiles(self._game.game_map, px, py)
        except KeyError:
            visible = frozenset()
        session.explored_tiles |= visible
        return session.explored_tiles

    def _build_welcome(
        self, session: _ClientSession, explored: set[Pos]
    ) -> dict[str, Any]:
        """Build the welcome message, culling to the client's explored tiles."""
        static_objects = [
            {"x": o.x, "y": o.y, "char": o.char, "fg_color": list(o.fg_color)}
            for o in self._game.static_objects
            if (o.x, o.y) in explored
        ]
        fp = self._game.fog_params
        catalogue = self._game.entity_catalogue()
        player_overrides = catalogue.pop("player_overrides", {})
        return {
            "type": "welcome",
            "entity_id": session.entity_id,
            "map_width": self._game.game_map.width,
            "map_height": self._game.game_map.height,
            "map_tiles": serialize_tile_reveal(self._game.game_map, explored),
            "static_objects": static_objects,
            "ambient": self._game.ambient,
            "fog": {
                "density": fp.density,
                "scale": fp.scale,
                "wind_x": fp.wind_x,
                "wind_y": fp.wind_y,
                "color": list(fp.color),
                "opacity_min": fp.opacity_min,
                "opacity_max": fp.opacity_max,
                "seed": fp.seed,
            },
            "type_catalogue": catalogue,
            "player_overrides": player_overrides,
        }

    async def _broadcast_player_override(self, new_session: _ClientSession) -> None:
        """Notify existing clients about a newly-connected player's display data."""
        entity = self._game.entity(new_session.entity_id)
        if entity is None:
            return
        msg: dict[str, Any] = {
            "type": "catalogue_update",
            "player_overrides": {
                str(new_session.entity_id): {
                    "display_name": entity.display_name,
                    "fg_color": list(entity.fg_color),
                }
            },
        }
        for s in list(self._sessions.values()):
            if s.uuid != new_session.uuid and s.writer is not None:
                await send_message(s.writer, msg)

    async def _run_client(
        self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter
    ) -> None:
        auth = await recv_message(reader)
        if auth.get("type") != "auth":
            await send_message(writer, {"type": "error", "message": "expected auth"})
            return
        session = self._auth_session(auth, writer)
        if session is None:
            await send_message(writer, {"type": "error", "message": "server full"})
            return
        explored = self._initial_explored_tiles(session)
        await send_message(writer, self._build_welcome(session, explored))
        await self._broadcast_player_override(session)
        await self._recv_loop(reader, session)

    def _auth_session(
        self, auth: dict[str, Any], writer: asyncio.StreamWriter
    ) -> _ClientSession | None:
        uuid = str(auth.get("uuid", ""))
        username = str(auth.get("username", "player"))
        if uuid in self._sessions:
            session = self._sessions[uuid]
            if session.writer is None:
                # True reconnect — previous connection dropped, reuse session.
                session.attach(writer)
                log_event(
                    "player_reconnect",
                    username=session.username,
                    entity_id=session.entity_id,
                )
                return session
            # UUID collision but existing session is still live (two clients
            # sharing the same client.uuid file, e.g. both on same machine).
            # Create an independent session under a fresh unique key.
            uuid = str(_uuid_mod.uuid4())
        return self._create_session(uuid, username, auth, writer)

    def _create_session(
        self,
        uuid: str,
        username: str,
        auth: dict[str, Any],
        writer: asyncio.StreamWriter,
    ) -> _ClientSession | None:
        if len(self._sessions) >= self._max_clients:
            return None
        entity_id = self._game.player_entity_id(username)
        if entity_id is not None and self._entity_claimed(entity_id):
            entity_id = None
        if entity_id is None:
            entity_id = self._spawn_player_from_auth(username, auth)
        session = _ClientSession(uuid=uuid, entity_id=entity_id, username=username)
        session.attach(writer)
        session.joined_at_abs_tick = self._game.abs_tick
        self._sessions[uuid] = session
        log_event("player_connect", username=username, entity_id=entity_id)
        return session

    def _entity_claimed(self, entity_id: int) -> bool:
        """Return True if an active session already holds *entity_id*."""
        return any(
            s.entity_id == entity_id and s.writer is not None
            for s in self._sessions.values()
        )

    def _spawn_player_from_auth(self, username: str, auth: dict[str, Any]) -> int:
        char_name = str(auth.get("char_name", username))
        raw = auth.get("color", [255, 255, 0])
        color = (int(raw[0]), int(raw[1]), int(raw[2]))
        return self._game.spawn_player(username, char_name, color)

    def _handle_command_msg(
        self, msg: dict[str, Any], parser: CommandParser, resolver: CommandResolver
    ) -> None:
        raw = str(msg.get("raw", ""))
        if raw:
            self._game.enqueue_command(resolver.resolve(parser.parse(raw)))

    async def _recv_loop(
        self, reader: asyncio.StreamReader, session: _ClientSession
    ) -> None:
        parser = CommandParser()
        resolver = CommandResolver(session.entity_id)
        try:
            while True:
                msg = await recv_message(reader)
                if msg.get("type") == "goodbye":
                    self._on_goodbye(session)
                    break
                await self._dispatch_client_msg(msg, parser, resolver, session)
        except OSError, asyncio.IncompleteReadError:
            session.detach()
            log_event(
                "player_disconnect",
                username=session.username,
                entity_id=session.entity_id,
                graceful=False,
            )

    async def _dispatch_client_msg(
        self,
        msg: dict[str, Any],
        parser: CommandParser,
        resolver: CommandResolver,
        session: _ClientSession,
    ) -> None:
        if msg.get("type") == "command":
            self._handle_command_msg(msg, parser, resolver)
        elif msg.get("type") == "ping":
            await self._handle_ping(msg, session)

    async def _handle_ping(self, msg: dict[str, Any], session: _ClientSession) -> None:
        if session.writer is not None:
            await send_message(session.writer, {"type": "pong", "t": msg.get("t", 0.0)})
