"""Game state — holds the map, players, chat history, and tick processor."""

from __future__ import annotations

import itertools
import random
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

from faraway_realms.chat import DEFAULT_COLOR, ChatMessage
from faraway_realms.combat.abilities import ABILITY_REGISTRY, Ability
from faraway_realms.combat.projectile import Projectile
from faraway_realms.combat.status import StatusInstance, is_stunned
from faraway_realms.effects.fog import FogParams
from faraway_realms.effects.light import LightSource, collect_light_sources
from faraway_realms.entities.entity import (
    Entity,
    GameEntity,
    Player,
)
from faraway_realms.entities.static_object import StaticObject
from faraway_realms.systems.ability_effects import AbilityEffectsSystem
from faraway_realms.systems.blood import BloodSystem
from faraway_realms.systems.casting import CastingSystem
from faraway_realms.systems.combat import CombatSystem
from faraway_realms.systems.combat_log import CombatLog
from faraway_realms.systems.contact import ContactResolutionSystem
from faraway_realms.systems.death import DeathSystem
from faraway_realms.systems.interaction_system import InteractionSystem
from faraway_realms.systems.movement import MovementSystem
from faraway_realms.systems.npc_intent import NpcIntentSystem
from faraway_realms.systems.projectile import ProjectileSystem
from faraway_realms.systems.spawn import SpawnSystem
from faraway_realms.systems.status import StatusEffectSystem
from faraway_realms.systems.targeting import TargetingSystem
from faraway_realms.types import Pos
from faraway_realms.world.commands import Command, CommandType
from faraway_realms.world.event_bus import EventBus
from faraway_realms.world.events import Event, EventType
from faraway_realms.world.factions import FactionRelations
from faraway_realms.world.map import Map, is_adjacent

_MAX_EVENT_DEPTH: int = 10


def _ser_entity_type(ct: Any, *, is_player: bool) -> dict:
    cp = ct.combat_profile
    return {
        "char": ct.char,
        "fg_color": list(ct.fg_color),
        "display_name": ct.display_name or ct.name,
        "faction": ct.faction,
        "abilities": list(ct.abilities),
        "blood_color": list(cp.blood_color) if cp.blood_color else None,
        "is_player": is_player,
        "description": ct.description,
    }


def _ser_ability_type(a: Any) -> dict:
    return {
        "description": a.description,
        "abbreviation": a.abbreviation,
        "cooldown": a.cooldown,
        "cast_time": a.cast_time,
        "range_tiles": a.range_tiles,
        "gcd": a.gcd,
    }


def _ser_static_object_type(s: Any) -> dict:
    return {
        "char": s.char,
        "fg_color": list(s.fg_color),
        "display_name": s.display_name or s.name,
        "description": s.description,
        "labels": list(s.labels),
    }


def _ser_stat_type(sd: Any) -> dict:
    return {
        "abbreviation": sd.abbreviation,
        "kind": sd.kind,
        "bar_filled": list(sd.bar_filled) if sd.bar_filled else None,
        "bar_empty": list(sd.bar_empty) if sd.bar_empty else None,
    }


def _ser_tile_type(tt: Any) -> dict:
    return {
        "walkable": tt.walkable,
        "display_name": tt.display_name,
        "description": tt.description,
        "char": tt.char,
        "fg_color": list(tt.fg_color),
        "bg_color": list(tt.bg_color),
    }


def _ser_tile_overlay(to: Any) -> dict:
    return {"description": to.description, "name": to.name}


@dataclass
class Game:
    """Central game state: map, players, chat history, and command queue.

    Parameters
    ----------
    game_map : Map
        The active map.
    tick_rate : float
        Target ticks per second for game state updates.
    faction_relations : FactionRelations
        Defines which factions are hostile to each other.
    """

    game_map: Map
    tick_rate: float = 10.0
    faction_relations: FactionRelations = field(default_factory=FactionRelations)
    _players: dict[str, Player] = field(default_factory=dict)
    _npcs: list[Entity] = field(default_factory=list)
    _entities: dict[int, GameEntity] = field(default_factory=dict)
    _command_queue: list[Command] = field(default_factory=list)
    _abs_tick: int = field(default=0)
    _creature_registry: dict[str, Callable[[int], Entity]] = field(default_factory=dict)
    _next_entity_id: int = field(default=1000)
    player_spawn_tiles: list[Pos] = field(default_factory=list)
    ambient: float = field(default=0.35)
    fog_params: FogParams = field(default_factory=FogParams)
    death_message: str = field(default="")
    _static_objects: list[StaticObject] = field(default_factory=list, init=False)

    def __post_init__(self) -> None:
        """Initialise systems and command/event dispatch tables."""
        self._bus = EventBus()
        self._casting = CastingSystem(self._entities, self.game_map, self._bus)
        self._npc_intent = NpcIntentSystem(
            self.game_map,
            self._npcs,
            self._entities,
            self.faction_relations,
            casting_system=self._casting,
            bus=self._bus,
        )
        self._movement = MovementSystem(
            self.game_map, self._entities, self.faction_relations, self._bus
        )
        self._combat = CombatSystem(self._entities, self._bus)
        self._targeting = TargetingSystem(
            self._entities,
            self.game_map,
            self.faction_relations,
            players=self._players,
            command_queue=self._command_queue,
            bus=self._bus,
        )
        self._contact = ContactResolutionSystem(
            self._entities,
            command_queue=self._command_queue,
            players=self._players,
            bus=self._bus,
        )
        self._death = DeathSystem(
            self.game_map, self._entities, self._npcs, bus=self._bus
        )
        self._status_fx = StatusEffectSystem(self._entities, self._bus)
        self._combat_log = CombatLog(self._entities, self._players, bus=self._bus)
        self._spawn_sys = SpawnSystem(
            entities=self._entities,
            game_map=self.game_map,
            players=self._players,
            creature_registry=self._creature_registry,
            allocate_id=self._allocate_entity_id,
        )
        self._movement_trails: list = []
        self._ability_effects = AbilityEffectsSystem(
            entities=self._entities,
            game_map=self.game_map,
            bus=self._bus,
            movement_trails=self._movement_trails,
        )
        self._projectile_sys = ProjectileSystem(
            self._entities, self.game_map, self._bus, self._ability_effects
        )
        self._melee_anims: list[
            tuple[
                Pos,
                Pos,
                tuple[int, int, int],
                tuple[int, int, int] | None,
            ]
        ] = []
        self._blood_sys = BloodSystem(
            self._entities, self.game_map, self._bus, self._melee_anims
        )
        self._interaction = InteractionSystem(self.game_map, self._bus)
        self._last_tick_phases: dict[str, float] = {}

        self._handlers: dict[CommandType, Callable[[Command], None]] = {
            CommandType.MOVE: self._dispatch_move,
            CommandType.ATTACK: self._dispatch_attack,
            CommandType.OPPORTUNITY_ATTACK: self._dispatch_opportunity_attack,
            CommandType.TARGET: self._dispatch_target,
            CommandType.SPAWN: self._dispatch_spawn,
            CommandType.PRIME_COOLDOWN: self._dispatch_prime_cooldown,
            CommandType.CLEAR_PRIME: self._dispatch_clear_prime,
            CommandType.CAST: self._dispatch_cast,
            CommandType.INTERACT: self._dispatch_interact,
        }

    def add_npc(self, npc: Entity) -> None:
        """Register an NPC in the game.

        Parameters
        ----------
        npc : Entity
            The NPC to add.
        """
        self._npcs.append(npc)
        self._entities[npc.entity_id] = npc

    def add_player(self, player: Player) -> None:
        """Register a player in the game.

        Parameters
        ----------
        player : Player
            The player to add.
        """
        self._players[str(player.entity.entity_id)] = player
        self._entities[player.entity.entity_id] = player.entity

    def register_creature(self, name: str, factory: Callable[[int], Entity]) -> None:
        """Register a creature factory for GM spawn commands.

        Parameters
        ----------
        name : str
            Creature type name used in ``/spawn me <name> <pos>``.
        factory : Callable[[int], Entity]
            Callable that receives an entity ID and returns a configured NPC.
        """
        self._creature_registry[name] = factory

    @property
    def command_queue_size(self) -> int:
        """Number of player/NPC commands queued ahead of the next tick."""
        return len(self._command_queue)

    def enqueue_command(self, command: Command) -> None:
        """Add a command to the queue for the current tick's drain.

        Parameters
        ----------
        command : Command
            The command to enqueue.
        """
        self._command_queue.append(command)

    def emit_event(self, event: Event) -> None:
        """Emit an event to be resolved after the current command drain.

        Parameters
        ----------
        event : Event
            The event to emit.
        """
        self._bus.publish(event)

    def subscribe_events(
        self,
        event_type: EventType,
        handler: Callable[[Event], None],
        priority: int = 50,
    ) -> None:
        """Subscribe an external observer to game events.

        Intended for observability only — handlers must be read-only and must
        not mutate game state or enqueue commands.

        Parameters
        ----------
        event_type : EventType
            The event type to listen for.
        handler : Callable[[Event], None]
            Called for each matching event after it resolves.
        priority : int
            Delivery order; lower fires first.  Use values > 10 to fire after
            all built-in systems (max built-in priority is 10).
        """
        self._bus.subscribe(event_type, handler, priority)

    def tick(self) -> None:
        """Advance game state: gather NPC intents, drain commands, drain events."""
        self._melee_anims.clear()
        self._movement_trails.clear()
        self._abs_tick += 1
        _t0 = time.perf_counter()
        self._command_queue.extend(self._npc_intent.gather(self._abs_tick))
        _t1 = time.perf_counter()
        queue = self._command_queue[:]
        self._command_queue.clear()
        for command in queue:
            self._process_command(command)
        self._drain_events()
        _t2 = time.perf_counter()
        self._bus.publish(
            Event(
                event_type=EventType.TICK,
                source_id=0,
                resolve_at_tick=self._abs_tick,
            )
        )
        self._drain_events()
        _t3 = time.perf_counter()
        self._last_tick_phases = {
            "npc_ms": round((_t1 - _t0) * 1000, 2),
            "commands_ms": round((_t2 - _t1) * 1000, 2),
            "systems_ms": round((_t3 - _t2) * 1000, 2),
        }

    # ------------------------------------------------------------------
    # Command dispatch
    # ------------------------------------------------------------------

    def add_chat_message(
        self,
        message: str,
        color: tuple[int, int, int] = DEFAULT_COLOR,
    ) -> None:
        """Append a message to the chat history.

        Parameters
        ----------
        message : str
            The message text.
        color : tuple[int, int, int]
            RGB foreground color.  Defaults to
            :data:`~faraway_realms.chat.DEFAULT_COLOR`.
        """
        self._combat_log.add_message(message, color)

    def get_chat_since(self, offset: int) -> list[ChatMessage]:
        """Return messages added since *offset* (index into full history).

        Parameters
        ----------
        offset : int
            Start index; pass the ``chat_count`` from the previous delivery.

        Returns
        -------
        list[ChatMessage]
            Messages at positions ``[offset:]``.
        """
        return self._combat_log.get_since(offset)

    @property
    def chat_count(self) -> int:
        """Total number of chat messages ever added (monotonically increasing)."""
        return self._combat_log.count

    def get_chat_history(self, last_n: int = 20) -> list[ChatMessage]:
        """Return the most recent chat messages.

        Parameters
        ----------
        last_n : int
            Maximum number of messages to return.

        Returns
        -------
        list[ChatMessage]
            The last ``last_n`` messages.
        """
        return self._combat_log.get_history(last_n)

    def _process_command(self, command: Command) -> None:
        handler = self._handlers.get(command.command_type)
        if handler is not None:
            handler(command)

    def _dispatch_interact(self, command: Command) -> None:
        actor_id = self._resolve_actor(command.actor)
        if actor_id is None or not command.args:
            return
        direction = command.args[0].lower()
        self._interaction.handle(actor_id, direction)

    def _dispatch_move(self, command: Command) -> None:
        actor_id = self._resolve_actor(command.actor)
        if actor_id is None or not command.args:
            return
        direction = command.args[0].lower()
        self._movement.handle(actor_id, direction, self._abs_tick)

    def _in_melee_range(self, a: int, b: int) -> bool:
        if not self.game_map.has_entity(a) or not self.game_map.has_entity(b):
            return False
        ax, ay = self.game_map.get_entity_position(a)
        bx, by = self.game_map.get_entity_position(b)
        return is_adjacent(ax, ay, bx, by)

    def _dispatch_attack(self, command: Command) -> None:
        attacker_id = self._resolve_actor(command.actor)
        if attacker_id is None or not command.args:
            return
        if self._attack_blocked(attacker_id):
            return
        target_id = self._resolve_target(attacker_id, command.args[0])
        if target_id is None or not self._in_melee_range(attacker_id, target_id):
            return
        self._combat.handle(attacker_id, target_id, self._abs_tick)

    def _attack_blocked(self, attacker_id: int) -> bool:
        """Return True when the attacker cannot swing (casting or stunned)."""
        entity = self._entities.get(attacker_id)
        return self._casting.is_casting(attacker_id) or (
            entity is not None and is_stunned(entity, self._abs_tick)
        )

    def _dispatch_opportunity_attack(self, command: Command) -> None:
        attacker_id = self._resolve_actor(command.actor)
        if attacker_id is None or not command.args:
            return
        target_id = self._resolve_target(attacker_id, command.args[0])
        if target_id is None:
            return
        self._combat.handle(
            attacker_id, target_id, self._abs_tick, bypass_cooldown=True
        )

    def get_hit_seq(self, entity_id: int) -> int:
        """Return how many times *entity_id* has been hit (monotonically increasing)."""
        return self._blood_sys.get_hit_seq(entity_id)

    def get_crit_dealt_seq(self, entity_id: int) -> int:
        """Return how many crits *entity_id* has landed (monotonically increasing).

        Parameters
        ----------
        entity_id : int
            Entity to query.

        Returns
        -------
        int
            Monotonically increasing crit count; ``0`` until first crit.
        """
        return self._blood_sys.get_crit_dealt_seq(entity_id)

    @property
    def abs_tick(self) -> int:
        """Return the current absolute tick counter."""
        return self._abs_tick

    @property
    def entity_count(self) -> int:
        """Number of entities currently registered in the game."""
        return len(self._entities)

    @property
    def last_tick_phases(self) -> dict[str, float]:
        """Per-phase durations (ms) from the most recent tick."""
        return self._last_tick_phases

    @property
    def bus(self) -> EventBus:
        """The game event bus — exposed for server-level subscribers."""
        return self._bus

    def take_event_stats(self) -> dict[str, int]:
        """Return and reset per-tick event bus counters.

        Returns
        -------
        dict[str, int]
            ``events_fired`` and ``max_cascade_depth`` since last call.
        """
        return self._bus.take_tick_stats()

    def melee_anim_events(
        self,
    ) -> list[
        tuple[
            Pos,
            Pos,
            tuple[int, int, int],
            tuple[int, int, int] | None,
        ]
    ]:
        """Return ``(attacker_pos, target_pos, color, blood_color)`` for each hit.

        Populated by :class:`~faraway_realms.systems.blood.BloodSystem` via a
        shared list during event handling, so killing blows are included.
        """
        return list(self._melee_anims)

    def movement_trail_events(
        self,
    ) -> list[tuple[int, int, tuple[int, int, int], list[Pos]]]:
        """Return ``(entity_id, char, fg_color, path)`` for each push trail.

        Populated by
        :class:`~faraway_realms.systems.ability_effects.AbilityEffectsSystem`
        when a backstep or knockback moves an entity.  Cleared at the start of
        each tick so callers always see only the current tick's trails.
        """
        return list(self._movement_trails)

    @property
    def active_projectiles(self) -> list[Projectile]:
        """Return the current list of in-flight projectiles for rendering."""
        return self._projectile_sys.active_projectiles

    @property
    def static_objects(self) -> list[StaticObject]:
        """Return all static objects placed on the map."""
        return self._static_objects

    def add_static_object(self, obj: StaticObject) -> None:
        """Place a static object on the map.

        Parameters
        ----------
        obj : StaticObject
            The object to add.
        """
        self._static_objects.append(obj)

    def all_player_entities(self) -> list[GameEntity]:
        """Return all player-controlled entities."""
        return [p.entity for p in self._players.values()]

    def all_npcs(self) -> list[Entity]:
        """Return all NPC entities (those carrying a ``BehaviourComponent``)."""
        return [e for e in self._npcs if "behaviour" in e.components]

    def entity(self, entity_id: int) -> GameEntity | None:
        """Return entity by ID, or None."""
        return self._entities.get(entity_id)

    def entity_catalogue(self) -> dict[str, dict]:
        """Return all static registry data for the client catalogue."""
        from faraway_realms.combat.stat_definitions import (
            STAT_DEF_REGISTRY,  # noqa: PLC0415
        )
        from faraway_realms.entities.character_type import (
            CHARACTER_REGISTRY,  # noqa: PLC0415
        )
        from faraway_realms.entities.creature_type import (
            CREATURE_REGISTRY,  # noqa: PLC0415
        )
        from faraway_realms.entities.static_object import (
            STATIC_OBJECT_REGISTRY,  # noqa: PLC0415
        )
        from faraway_realms.mapgen.texture import TILE_OVERLAY_REGISTRY  # noqa: PLC0415
        from faraway_realms.world.tile import TILE_REGISTRY  # noqa: PLC0415

        entity_types: dict[str, dict] = {}
        for name, ct in CREATURE_REGISTRY.items():
            entity_types[name] = _ser_entity_type(ct, is_player=False)
        for name, ct in CHARACTER_REGISTRY.items():
            entity_types[name] = _ser_entity_type(ct, is_player=True)
        player_ids = {p.entity.entity_id for p in self._players.values()}
        player_overrides = {
            str(e.entity_id): {
                "display_name": e.display_name,
                "fg_color": list(e.fg_color),
            }
            for e in self._entities.values()
            if e.entity_id in player_ids
        }
        return {
            "entity_types": entity_types,
            "ability_types": {
                n: _ser_ability_type(a) for n, a in ABILITY_REGISTRY.items()
            },
            "static_object_types": {
                n: _ser_static_object_type(s) for n, s in STATIC_OBJECT_REGISTRY.items()
            },
            "stat_types": {
                n: _ser_stat_type(sd) for n, sd in STAT_DEF_REGISTRY.items()
            },
            "tile_types": {n: _ser_tile_type(tt) for n, tt in TILE_REGISTRY.items()},
            "tile_overlays": {
                n: _ser_tile_overlay(to) for n, to in TILE_OVERLAY_REGISTRY.items()
            },
            "player_overrides": player_overrides,
        }

    def player_entity_id(self, username: str) -> int | None:
        """Return the entity ID for *username*, or None if not registered."""
        for p in self._players.values():
            if p.username == username:
                return p.entity.entity_id
        return None

    def spawn_player(
        self, username: str, char_name: str, color: tuple[int, int, int]
    ) -> int:
        """Spawn a new player entity and register it under *username*.

        Parameters
        ----------
        username : str
            Account name used to authenticate.
        char_name : str
            Display name for the character.
        color : tuple[int, int, int]
            RGB foreground colour.

        Returns
        -------
        int
            Entity ID of the newly created player entity.
        """
        from faraway_realms.entities.character_type import (
            CHARACTER_REGISTRY,  # noqa: PLC0415
        )

        entity_id = self._allocate_entity_id()
        entity = CHARACTER_REGISTRY["hero"].to_entity(entity_id)
        entity.name = char_name
        entity.fg_color = color
        self.add_player(Player(username=username, entity=entity))
        x, y = self._pick_spawn_tile()
        self.game_map.place_entity(entity_id, x, y)
        return entity_id

    def _allocate_entity_id(self) -> int:
        eid = self._next_entity_id
        self._next_entity_id += 1
        return eid

    def _pick_spawn_tile(self) -> Pos:
        occupied = frozenset(self.game_map.get_all_positions().values())
        candidates = [t for t in self.player_spawn_tiles if t not in occupied]
        if not candidates:
            candidates = self._all_walkable_unoccupied(occupied)
        return random.choice(candidates) if candidates else (1, 1)  # noqa: S311

    def _all_walkable_unoccupied(self, occupied: frozenset[Pos]) -> list[Pos]:
        return [
            (x, y)
            for y in range(self.game_map.height)
            for x in range(self.game_map.width)
            if self.game_map.is_walkable(x, y) and (x, y) not in occupied
        ]

    def _static_lights(self):
        for obj in self._static_objects:
            yield obj.x, obj.y, obj.components

    def _entity_lights(self):
        for eid, entity in self._entities.items():
            try:
                x, y = self.game_map.get_entity_position(eid)
                yield x, y, entity.components
            except KeyError:
                pass

    def _tile_lights(self):
        for x in range(self.game_map.width):
            for y in range(self.game_map.height):
                tile = self.game_map.get_tile(x, y)
                if tile.components:
                    yield x, y, tile.components

    def light_sources(self) -> list[tuple[int, int, LightSource]]:
        """Collect all active light source positions for rendering.

        Returns
        -------
        list[tuple[int, int, LightSource]]
            ``(x, y, light_source)`` for every static object, entity, tile,
            and in-flight projectile that emits light.
        """
        all_positioned = itertools.chain(
            self._static_lights(), self._entity_lights(), self._tile_lights()
        )
        sources = collect_light_sources(all_positioned)
        for proj in self._projectile_sys.active_projectiles:
            if proj.light_source is not None:
                sources.append((proj.x, proj.y, proj.light_source))
        return sources

    def _dispatch_prime_cooldown(self, command: Command) -> None:
        entity_id = self._resolve_actor(command.actor)
        if entity_id is None:
            return
        self._combat.prime(entity_id, self._abs_tick)

    def _dispatch_clear_prime(self, command: Command) -> None:
        entity_id = self._resolve_actor(command.actor)
        if entity_id is None:
            return
        self._combat.forget(entity_id)

    def _dispatch_cast(self, command: Command) -> None:
        resolved = self._resolve_cast_args(command)
        if resolved is None:
            return
        actor_id, ability, target_id = resolved
        actor = self._entities.get(actor_id)
        if actor is not None and is_stunned(actor, self._abs_tick):
            return
        self._begin_cast(actor_id, ability, target_id)

    def _begin_cast(self, actor_id: int, ability: Ability, target_id: int) -> None:
        self._casting.begin_cast(actor_id, ability, target_id, self._abs_tick)

    def _resolve_cast_args(self, command: Command) -> tuple[int, Ability, int] | None:
        actor_id = self._resolve_actor(command.actor)
        if actor_id is None or len(command.args) < 2:
            return None
        return self._resolve_cast_ability(actor_id, command.args[0], command.args[1])

    def _resolve_cast_ability(
        self, actor_id: int, ability_name: str, target_arg: str
    ) -> tuple[int, Ability, int] | None:
        actor = self._entities.get(actor_id)
        if actor is None:
            return None
        ability = actor.abilities.get(ability_name)
        if ability is None:
            return None
        target_id = self._resolve_target(actor_id, target_arg)
        if target_id is None:
            return None
        return actor_id, ability, target_id

    def _dispatch_target(self, command: Command) -> None:
        entity_id = self._resolve_actor(command.actor)
        if entity_id is None:
            return
        entity = self._entities.get(entity_id)
        old_target = entity.target_id if entity else None
        if command.args and command.args[0] == "next":
            self._targeting.cycle(entity_id)
        else:
            self._targeting.handle(entity_id, self._resolve_new_target(command.args))
        new_target = entity.target_id if entity else None
        if new_target is not None and new_target != old_target:
            self._bus.publish(
                Event(
                    event_type=EventType.TARGET_CHANGED,
                    source_id=entity_id,
                    resolve_at_tick=self._abs_tick,
                )
            )

    def _dispatch_spawn(self, command: Command) -> None:
        actor_id = self._resolve_actor(command.actor)
        if actor_id is None:
            return
        result = self._spawn_sys.handle(actor_id, command.args)
        if result is not None:
            self.add_npc(result.entity)
            self.game_map.place_entity(result.entity.entity_id, result.x, result.y)
            self._combat_log.add_message(result.message)

    def gcd_fraction(self, entity_id: int) -> float | None:
        """Return entity's GCD progress (0.0–1.0) while active, else ``None``.

        Parameters
        ----------
        entity_id : int
            Entity to query.

        Returns
        -------
        float | None
            Fraction through the GCD window, or ``None`` when inactive.
        """
        return self._casting.gcd_fraction(entity_id, self._abs_tick)

    def cast_fraction(self, entity_id: int) -> float | None:
        """Return entity's cast progress (0.0–1.0) if casting, else ``None``.

        Parameters
        ----------
        entity_id : int
            Entity to query.

        Returns
        -------
        float | None
            Fraction through the cast time, or ``None`` when not casting.
        """
        return self._casting.cast_fraction(entity_id, self._abs_tick)

    def attack_cooldown_fraction(self, entity_id: int) -> float:
        """Return how far through the attack cooldown *entity_id* is (0–1).

        Parameters
        ----------
        entity_id : int
            Entity to query.

        Returns
        -------
        float
            ``0.0`` immediately after an attack; ``1.0`` when ready.
        """
        return self._combat.cooldown_fraction(entity_id, self._abs_tick)

    def ability_cooldown_fraction(self, entity_id: int, ability_name: str) -> float:
        """Return remaining cooldown for *ability_name* (1.0=just used, 0.0=ready).

        Parameters
        ----------
        entity_id : int
            Entity to query.
        ability_name : str
            Ability name.

        Returns
        -------
        float
            0.0 when ready or ability is unknown; otherwise fraction remaining.
        """
        entity = self._entities.get(entity_id)
        if entity is None:
            return 0.0
        ability = entity.abilities.get(ability_name)
        if ability is None:
            return 0.0
        return self._casting.ability_cooldown_fraction(
            entity_id, ability_name, ability.cooldown, self._abs_tick
        )

    def active_statuses(self, entity_id: int) -> list[StatusInstance]:
        """Return the non-expired status effects on *entity_id*.

        Parameters
        ----------
        entity_id : int
            Entity to query.

        Returns
        -------
        list[StatusInstance]
            Status effects whose ``expires_at`` is still in the future.
        """
        entity = self._entities.get(entity_id)
        if entity is None:
            return []
        return [s for s in entity.status_effects if not s.is_expired(self._abs_tick)]

    def has_active_status(self, entity_id: int, status_name: str) -> bool:
        """Return ``True`` when *entity_id* has a non-expired *status_name* status.

        Parameters
        ----------
        entity_id : int
            Entity to query.
        status_name : str
            Status name to look for.

        Returns
        -------
        bool
            ``True`` when at least one matching, non-expired status is found.
        """
        return any(s.name == status_name for s in self.active_statuses(entity_id))

    def _resolve_new_target(self, args: tuple[str, ...]) -> int | None:
        """Parse numeric target arg, or return ``None`` to clear."""
        return int(args[0]) if args else None

    # ------------------------------------------------------------------
    # Event dispatch
    # ------------------------------------------------------------------

    def _drain_events(self) -> None:
        self._bus.flush(self._abs_tick, depth=_MAX_EVENT_DEPTH)

    # ------------------------------------------------------------------
    # Actor / target resolution
    # ------------------------------------------------------------------

    def _resolve_actor(self, actor: str) -> int | None:
        if actor == "@self":
            player = next(iter(self._players.values()), None)
            if player is None:
                return None
            eid = player.entity.entity_id
        else:
            try:
                eid = int(actor)
            except ValueError:
                return None
        return eid if self.game_map.has_entity(eid) else None

    def _resolve_target(self, actor_id: int, arg: str) -> int | None:
        """Resolve a target argument, expanding ``@target`` to the actor's target.

        Parameters
        ----------
        actor_id : int
            Resolved entity ID of the attacker; used to look up ``target_id``
            when *arg* is ``"@target"``.
        arg : str
            Raw target argument from the command.

        Returns
        -------
        int | None
            Resolved target entity ID, or ``None`` if unresolvable.
        """
        if arg == "@target":
            entity = self._entities.get(actor_id)
            return entity.target_id if entity is not None else None
        return self._resolve_actor(arg)
