"""Stat definition registry — display metadata for named stat keys.

StatDefinition stores the presentation layer for a stat (abbreviation,
bar colours, kind) separately from the numeric values that live on
entities.  STAT_DEF_REGISTRY is populated at startup from YAML by
content_parsers/stat_definitions.py.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from faraway_realms.combat.stats import Pool, Stat


@dataclass(frozen=True)
class StatDefinition:
    """Display and construction metadata for a named stat.

    Parameters
    ----------
    name : str
        Registry key (e.g. ``"health"``).
    kind : str
        ``"pool"`` for depletable resources, ``"stat"`` for flat attributes.
    abbreviation : str
        Short label shown in the UI.
    bar_filled : tuple[int, int, int] | None
        Filled-bar RGB color; only meaningful for pools.
    bar_empty : tuple[int, int, int] | None
        Empty-bar RGB color; only meaningful for pools.
    regen_per_tick : float
        Flat amount restored each tick; only meaningful for pools.
    """

    name: str
    kind: str
    abbreviation: str = ""
    bar_filled: tuple[int, int, int] | None = None
    bar_empty: tuple[int, int, int] | None = None
    regen_per_tick: float = field(default=0.0)

    def make(self, base: int) -> Stat | Pool:
        """Instantiate a Stat or Pool with the given base value.

        Parameters
        ----------
        base : int
            Base value for the stat or pool maximum.

        Returns
        -------
        Stat | Pool
            A configured instance using this definition's metadata.
        """
        if self.kind == "pool":
            return Pool(
                base=base,
                abbreviation=self.abbreviation or None,
                bar_filled=self.bar_filled,
                bar_empty=self.bar_empty,
                regen_per_tick=self.regen_per_tick,
            )
        return Stat(
            base=base,
            abbreviation=self.abbreviation or None,
            bar_filled=self.bar_filled,
            bar_empty=self.bar_empty,
        )


STAT_DEF_REGISTRY: dict[str, StatDefinition] = {}
