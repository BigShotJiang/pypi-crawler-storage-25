"""Stat and Pool — flat attributes and depletable resources."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class Stat:
    """A flat attribute with an optional bonus from equipment or buffs.

    Parameters
    ----------
    base : int
        Intrinsic base value.
    bonus : int
        Additive modifier from equipment, buffs, or curses.
    abbreviation : str | None
        Short display label (e.g. ``"STR"``). Falls back to the stat key
        if ``None``.
    """

    base: int
    bonus: int = 0
    abbreviation: str | None = None
    bar_filled: tuple[int, int, int] | None = None
    bar_empty: tuple[int, int, int] | None = None

    @property
    def value(self) -> int:
        """Effective value after bonuses.

        Returns
        -------
        int
            ``base + bonus``.
        """
        return self.base + self.bonus


@dataclass
class Pool(Stat):
    """A depletable resource with a current and maximum value.

    The maximum is ``base + bonus`` (inherited from :class:`Stat`).
    ``current`` starts at the maximum and is clamped to ``[0, maximum]``
    by :meth:`modify`.

    Parameters
    ----------
    base : int
        Base maximum value.
    bonus : int
        Additive bonus to the maximum.
    regen_per_tick : float
        Flat amount restored each game tick; ``0`` disables regen.
    """

    regen_per_tick: float = 0.0
    current: int = field(init=False)
    _regen_acc: float = field(default=0.0, init=False, repr=False)

    def __post_init__(self) -> None:
        """Initialise ``current`` to the full maximum."""
        self.current = self.value

    def modify(self, delta: float) -> None:
        """Apply *delta* to ``current``, clamping to ``[0, maximum]``.

        Parameters
        ----------
        delta : float
            Positive to heal/restore, negative to damage/spend.
        """
        self.current = max(0, min(self.value, round(self.current + delta)))

    def tick_regen(self) -> int:
        """Accumulate fractional regen and return whole points applied."""
        self._regen_acc += self.regen_per_tick
        whole = int(self._regen_acc)
        if whole and self.current < self.value:
            self._regen_acc -= whole
            self.modify(whole)
            return whole
        return 0

    @property
    def is_empty(self) -> bool:
        """Return ``True`` when ``current`` has reached zero.

        Returns
        -------
        bool
            ``True`` if depleted.
        """
        return self.current <= 0
