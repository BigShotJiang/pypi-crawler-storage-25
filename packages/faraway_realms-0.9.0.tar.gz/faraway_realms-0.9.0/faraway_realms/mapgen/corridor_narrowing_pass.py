"""Corridor narrowing pass — blocks one tile of each door candidate before texturing."""

from __future__ import annotations

import random

from faraway_realms.mapgen.base import DoorCandidate, MapGenResult, PopulationPass
from faraway_realms.mapgen.map_profile import MapProfile
from faraway_realms.world.tile import TILE_REGISTRY

_FALLBACK_WALL = "cave_wall"


class CorridorNarrowingPass(PopulationPass):
    """Converts one tile of each 2-wide door candidate into a wall.

    Runs before texture passes so the placed wall receives the same noise
    colour variation and scatter replacements as surrounding walls.  The
    wall tile type is inferred from an orthogonal non-walkable neighbour of
    the candidate position so it matches the generator's wall tile.

    Skipped when ``profile.narrow_doors`` is False.

    Parameters
    ----------
    profile : MapProfile
        Map profile supplying ``narrow_doors``.
    """

    def __init__(self, profile: MapProfile) -> None:
        self._profile = profile

    def apply(self, result: MapGenResult, rng: random.Random) -> None:
        """Narrow each door candidate from 2 tiles wide to 1.

        Parameters
        ----------
        result : MapGenResult
            Generation result with ``door_candidates`` populated.
        rng : random.Random
            Unused; present to satisfy :class:`PopulationPass` interface.
        """
        if not self._profile.narrow_doors:
            return
        for candidate in result.door_candidates:
            _narrow_candidate(result, candidate)


def _infer_wall_tile(result: MapGenResult, x: int, y: int) -> str:
    """Return the tile-type name of the first non-walkable orthogonal neighbour."""
    for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1)):
        if not result.map.is_walkable(x + dx, y + dy):
            tid = result.tile_type_ids.get((x + dx, y + dy))
            if tid:
                return tid
    return _FALLBACK_WALL


def _is_corridor_near_flank_solid(
    result: MapGenResult, candidate: DoorCandidate
) -> bool:
    """Return True when the near perpendicular flank of the candidate is a wall.

    Narrowing only makes sense when the first tile of the candidate is at the
    edge of a corridor — i.e. the terrain on the side *opposite* the artificial
    wall is already solid.  If that flank is open, the candidate is inside a
    room or junction and placing a wall stub there would leave a floating tile.
    """
    x, y = candidate.x, candidate.y
    if candidate.horizontal:
        return not result.map.is_walkable(x - 1, y)
    return not result.map.is_walkable(x, y - 1)


def _narrow_candidate(result: MapGenResult, candidate: DoorCandidate) -> None:
    """Block the second tile of a 2-wide corridor opening with a wall.

    Skipped when the candidate's near perpendicular flank is open, which
    indicates the candidate lies inside a room or corridor junction rather
    than at a genuine corridor edge.
    """
    x2 = candidate.x + (1 if candidate.horizontal else 0)
    y2 = candidate.y + (0 if candidate.horizontal else 1)
    if not result.map.is_walkable(x2, y2):
        return
    if not _is_corridor_near_flank_solid(result, candidate):
        return
    wall_name = _infer_wall_tile(result, candidate.x, candidate.y)
    result.map.set_tile(x2, y2, TILE_REGISTRY[wall_name].make())
    result.tile_type_ids[(x2, y2)] = wall_name
