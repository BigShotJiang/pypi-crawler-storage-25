"""Status-effect system — DoT ticking and status expiry."""

from __future__ import annotations

from typing import TYPE_CHECKING

from faraway_realms.combat.stats import Pool
from faraway_realms.entities.entity import get_combat_profile
from faraway_realms.systems.base import System
from faraway_realms.world.events import Event, EventType

if TYPE_CHECKING:
    from faraway_realms.combat.status import StatusInstance
    from faraway_realms.entities.entity import GameEntity
    from faraway_realms.world.event_bus import EventBus


class StatusEffectSystem(System):
    """Ticks DoT damage and expires status effects each game tick.

    Parameters
    ----------
    entities : dict[int, GameEntity]
        Shared entity registry.
    bus : EventBus
        Event bus; ENTITY_DYING events are published directly.
    """

    def __init__(self, entities: dict[int, GameEntity], bus: EventBus) -> None:
        self._entities = entities
        self._bus = bus
        bus.subscribe(EventType.TICK, self._on_tick, priority=20)

    def _on_tick(self, event: Event) -> None:
        """Process status effects for this tick."""
        self.tick(event.resolve_at_tick)

    def tick(self, abs_tick: int) -> None:
        """Process all active status effects for every entity.

        Parameters
        ----------
        abs_tick : int
            Current absolute tick.
        """
        for entity in self._entities.values():
            self._process_entity(entity, abs_tick)

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _process_entity(self, entity: GameEntity, abs_tick: int) -> None:
        """Expire old statuses, apply any due DoT ticks, and regenerate mana."""
        expired = [s for s in entity.status_effects if s.is_expired(abs_tick)]
        entity.status_effects = [
            s for s in entity.status_effects if not s.is_expired(abs_tick)
        ]
        for s in expired:
            self._publish_expired(entity, s, abs_tick)
        for status in entity.status_effects:
            if status.dot_due(abs_tick):
                self._apply_dot(entity, status, abs_tick)
        self._tick_mana_regen(entity, abs_tick)

    def _publish_expired(
        self,
        entity: GameEntity,
        status: StatusInstance,
        abs_tick: int,
    ) -> None:
        """Publish STATUS_EXPIRED for a single expired status."""
        self._bus.publish(
            Event(
                event_type=EventType.STATUS_EXPIRED,
                source_id=entity.entity_id,
                resolve_at_tick=abs_tick,
                payload={
                    "status_name": status.name,
                    "stun": status.stun,
                    "immobilize": status.immobilize,
                },
            )
        )

    def _tick_mana_regen(self, entity: GameEntity, abs_tick: int) -> None:
        mana = entity.stats.get("mana")
        if not isinstance(mana, Pool) or mana.regen_per_tick <= 0:
            return
        delta = mana.tick_regen()
        if delta:
            self._bus.publish(
                Event(
                    event_type=EventType.RESOURCE_CHANGED,
                    source_id=entity.entity_id,
                    resolve_at_tick=abs_tick,
                    payload={
                        "pool": "mana",
                        "delta": delta,
                        "current": mana.current,
                        "maximum": mana.value,
                    },
                )
            )

    def _apply_dot(
        self, entity: GameEntity, status: StatusInstance, abs_tick: int
    ) -> None:
        """Apply one DoT/HoT tick; publish ENTITY_DYING if the entity is killed."""
        hp = entity.stats.get(get_combat_profile(entity).death_stat)
        if not isinstance(hp, Pool):
            return
        status.next_dot_tick = abs_tick + status.dot_interval
        self._apply_hp_change(entity, hp, status, abs_tick)

    def _apply_hp_change(
        self,
        entity: GameEntity,
        hp: Pool,
        status: StatusInstance,
        abs_tick: int,
    ) -> None:
        """Modify HP for a DoT or HoT tick; publish ENTITY_DYING if pool empties."""
        if status.tick_damage > 0:
            hp.modify(-status.tick_damage)
            if hp.is_empty:
                self._bus.publish(
                    Event(
                        event_type=EventType.ENTITY_DYING,
                        source_id=entity.entity_id,
                        target_id=None,
                        resolve_at_tick=abs_tick,
                    )
                )
        elif status.tick_heal > 0:
            hp.modify(status.tick_heal)
