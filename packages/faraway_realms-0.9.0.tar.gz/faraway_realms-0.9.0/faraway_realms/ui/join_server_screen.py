"""Join Server screen — host/port entry, character setup, recent servers."""

from __future__ import annotations

from typing import TYPE_CHECKING, Callable

import tcod.console
import tcod.event

from faraway_realms.settings import ConnectionSettings, save_connection_settings
from faraway_realms.ui.app_loop import AppState
from faraway_realms.ui.layout import CONSOLE_HEIGHT, CONSOLE_WIDTH
from faraway_realms.ui.text_input import TextInput

if TYPE_CHECKING:
    import tcod.context

# ---------------------------------------------------------------------------
# Visual constants
# ---------------------------------------------------------------------------

_BOX_W = 50
_BOX_H = 28
_FIELD_X_OFFSET = 14  # column offset from bx where text inputs start
_FIELD_W = _BOX_W - _FIELD_X_OFFSET - 3  # 33 chars wide

_BG: tuple[int, int, int] = (6, 6, 10)
_BORDER_FG: tuple[int, int, int] = (60, 55, 45)
_TITLE_COLOR: tuple[int, int, int] = (200, 160, 55)
_SECTION_COLOR: tuple[int, int, int] = (110, 90, 50)
_ITEM_NORMAL: tuple[int, int, int] = (130, 130, 130)
_ITEM_SELECT: tuple[int, int, int] = (230, 210, 130)
_HINT_COLOR: tuple[int, int, int] = (50, 50, 50)
_ERROR_COLOR: tuple[int, int, int] = (200, 80, 80)

# ---------------------------------------------------------------------------
# Color palette
# ---------------------------------------------------------------------------

_PALETTE: tuple[tuple[str, tuple[int, int, int]], ...] = (
    ("Yellow", (255, 255, 0)),
    ("White", (220, 220, 220)),
    ("Cyan", (0, 255, 255)),
    ("Red", (255, 80, 80)),
    ("Green", (80, 255, 80)),
    ("Magenta", (255, 80, 255)),
    ("Orange", (255, 165, 0)),
)

# ---------------------------------------------------------------------------
# Focus index constants
# ---------------------------------------------------------------------------

_FOCUS_HOST = 0
_FOCUS_PORT = 1
_FOCUS_USERNAME = 2
_FOCUS_CHARNAME = 3
_FOCUS_COLOR = 4
_FOCUS_RECENT_BASE = 5

# Type alias for the connection callable
ConnectFn = Callable[[str, str, str, tuple[int, int, int]], None]


# ---------------------------------------------------------------------------
# Screen
# ---------------------------------------------------------------------------


class JoinServerScreen:
    """Join server screen: text fields, color picker, and recent servers list."""

    def __init__(
        self,
        ctx: tcod.context.Context,
        connect_fn: ConnectFn,
        conn: ConnectionSettings,
    ) -> None:
        self._ctx = ctx
        self._connect_fn = connect_fn
        self._conn = conn
        self._recent = conn.recent_servers

        self._host = TextInput(max_len=64)
        self._port = TextInput(max_len=5)
        self._username = TextInput(max_len=32)
        self._charname = TextInput(max_len=32)
        self._fields = [self._host, self._port, self._username, self._charname]

        if self._recent:
            self._host.buffer = self._recent[0][0]
            self._port.buffer = str(self._recent[0][1])
        else:
            self._host.buffer = conn.default_host
            self._port.buffer = str(conn.default_port)
        self._username.buffer = conn.last_username
        self._charname.buffer = conn.last_char_name

        self._color_idx: int = min(conn.last_color_idx, len(_PALETTE) - 1)
        self._focus: int = 0
        self._error: str | None = None

        TextInput.start_input(ctx)

    @property
    def _focus_connect(self) -> int:
        return _FOCUS_RECENT_BASE + len(self._recent)

    @property
    def _total_foci(self) -> int:
        return _FOCUS_RECENT_BASE + len(self._recent) + 1

    def tick(self) -> None:
        """No per-frame logic needed."""

    def render(self, console: tcod.console.Console) -> None:
        """Draw the join server box onto *console*."""
        console.clear(bg=_BG)
        bx = (CONSOLE_WIDTH - _BOX_W) // 2
        by = (CONSOLE_HEIGHT - _BOX_H) // 2
        console.draw_frame(bx, by, _BOX_W, _BOX_H, fg=_BORDER_FG, bg=_BG)
        self._draw_title(console, bx, by)
        self._draw_connection(console, bx, by)
        self._draw_character(console, bx, by)
        self._draw_recent(console, bx, by)
        self._draw_bottom(console, bx, by)

    def handle_event(self, event: tcod.event.Event) -> AppState | None:
        """Route SDL events."""
        if isinstance(event, tcod.event.Quit):
            self._save_fields()
            return AppState.QUITTING
        if isinstance(event, tcod.event.KeyDown):
            return self._handle_key(event)
        if isinstance(event, tcod.event.TextInput):
            self._handle_text(event)
        return None

    # ------------------------------------------------------------------
    # Input
    # ------------------------------------------------------------------

    def _handle_key(self, event: tcod.event.KeyDown) -> AppState | None:
        if self._handle_nav_key(event):
            return None
        return self._handle_action_key(event)

    def _tab_delta(self, event: tcod.event.KeyDown) -> int:
        return -1 if event.mod & tcod.event.Modifier.SHIFT else 1

    def _handle_nav_key(self, event: tcod.event.KeyDown) -> bool:
        in_text_field = self._focused_text_input() is not None
        if event.sym == tcod.event.KeySym.DOWN or (
            not in_text_field and event.sym == tcod.event.KeySym(ord("j"))
        ):
            self._move(1)
            return True
        if event.sym == tcod.event.KeySym.UP or (
            not in_text_field and event.sym == tcod.event.KeySym(ord("k"))
        ):
            self._move(-1)
            return True
        if event.sym == tcod.event.KeySym.TAB:
            self._move(self._tab_delta(event))
            return True
        return False

    def _edit_delta(self, event: tcod.event.KeyDown) -> int:
        if event.sym in (tcod.event.KeySym.LEFT, tcod.event.KeySym(ord("h"))):
            return -1
        if event.sym in (tcod.event.KeySym.RIGHT, tcod.event.KeySym(ord("l"))):
            return 1
        return 0

    def _handle_action_key(self, event: tcod.event.KeyDown) -> AppState | None:
        delta = self._edit_delta(event)
        if delta and self._focus == _FOCUS_COLOR:
            self._color_idx = (self._color_idx + delta) % len(_PALETTE)
            return None
        if event.sym == tcod.event.KeySym.RETURN:
            return self._handle_enter()
        if event.sym == tcod.event.KeySym.ESCAPE:
            self._save_fields()
            return AppState.MAIN_MENU
        self._active_input_handle_key(event)
        return None

    def _handle_enter(self) -> AppState | None:
        if self._focus == self._focus_connect:
            return self._attempt_connect()
        if self._focus >= _FOCUS_RECENT_BASE:
            self._select_recent(self._focus - _FOCUS_RECENT_BASE)
            return None
        self._move(1)
        return None

    def _handle_text(self, event: tcod.event.TextInput) -> None:
        inp = self._focused_text_input()
        if inp is not None:
            inp.handle_text(event)

    def _active_input_handle_key(self, event: tcod.event.KeyDown) -> None:
        inp = self._focused_text_input()
        if inp is not None:
            inp.handle_key(event)

    def _focused_text_input(self) -> TextInput | None:
        if self._focus < len(self._fields):
            return self._fields[self._focus]
        return None

    def _move(self, delta: int) -> None:
        self._error = None
        self._focus = (self._focus + delta) % self._total_foci

    def _select_recent(self, idx: int) -> None:
        host, port = self._recent[idx]
        self._host.buffer = host
        self._port.buffer = str(port)
        self._focus = _FOCUS_USERNAME

    # ------------------------------------------------------------------
    # Connection
    # ------------------------------------------------------------------

    def _validate_connect(self) -> str | None:
        if not self._host.buffer.strip():
            return "Enter a host."
        if not self._port.buffer.strip().isdigit():
            return "Enter a valid port number."
        return None

    def _attempt_connect(self) -> AppState | None:
        err = self._validate_connect()
        if err:
            self._error = err
            return None
        host = self._host.buffer.strip()
        port = int(self._port.buffer.strip())
        username = self._username.buffer.strip() or "player1"
        char_name = self._charname.buffer.strip() or username
        color = _PALETTE[self._color_idx][1]
        return self._do_connect(host, port, username, char_name, color)

    def _do_connect(
        self,
        host: str,
        port: int,
        username: str,
        char_name: str,
        color: tuple[int, int, int],
    ) -> AppState | None:
        try:
            self._connect_fn(f"{host}:{port}", username, char_name, color)
        except (RuntimeError, OSError) as exc:
            self._error = str(exc)
            return None
        self._save_after_connect(host, port, username, char_name)
        return AppState.IN_GAME

    def _save_fields(self) -> None:
        username = self._username.buffer.strip() or "player1"
        char_name = self._charname.buffer.strip()
        port_str = self._port.buffer.strip()
        port = int(port_str) if port_str.isdigit() else self._conn.default_port
        save_connection_settings(
            self._host.buffer.strip() or self._conn.default_host,
            port,
            username,
            char_name,
            self._color_idx,
            list(self._recent),
        )
        TextInput.stop_input(self._ctx)

    def _save_after_connect(
        self, host: str, port: int, username: str, char_name: str
    ) -> None:
        new_recent = [(host, port)] + [r for r in self._recent if r != (host, port)]
        save_connection_settings(
            host, port, username, char_name, self._color_idx, new_recent[:5]
        )

    # ------------------------------------------------------------------
    # Rendering
    # ------------------------------------------------------------------

    def _draw_title(self, console: tcod.console.Console, bx: int, by: int) -> None:
        title = "JOIN SERVER"
        x = bx + (_BOX_W - len(title)) // 2
        console.print(x, by + 2, title, fg=_TITLE_COLOR)

    def _draw_field(
        self,
        console: tcod.console.Console,
        bx: int,
        y: int,
        label: str,
        field: TextInput,
        focused: bool,
    ) -> None:
        fg = _ITEM_SELECT if focused else _ITEM_NORMAL
        prefix = "> " if focused else "  "
        console.print(bx + 2, y, prefix + label, fg=fg)
        field.render(console, bx + _FIELD_X_OFFSET, y, _FIELD_W, focused, fg)

    def _draw_color_row(self, console: tcod.console.Console, bx: int, y: int) -> None:
        focused = self._focus == _FOCUS_COLOR
        fg = _ITEM_SELECT if focused else _ITEM_NORMAL
        prefix = "> " if focused else "  "
        name, rgb = _PALETTE[self._color_idx]
        console.print(bx + 2, y, prefix + "Color     ", fg=fg)
        console.print(bx + _FIELD_X_OFFSET, y, "\u2588 ", fg=rgb)
        console.print(bx + _FIELD_X_OFFSET + 2, y, name, fg=fg)

    def _draw_connection(self, console: tcod.console.Console, bx: int, by: int) -> None:
        console.print(bx + 3, by + 4, "Connection", fg=_SECTION_COLOR)
        self._draw_field(
            console,
            bx,
            by + 6,
            "Host      ",
            self._host,
            self._focus == _FOCUS_HOST,
        )
        self._draw_field(
            console,
            bx,
            by + 7,
            "Port      ",
            self._port,
            self._focus == _FOCUS_PORT,
        )

    def _draw_character(self, console: tcod.console.Console, bx: int, by: int) -> None:
        console.print(bx + 3, by + 9, "Character", fg=_SECTION_COLOR)
        self._draw_field(
            console,
            bx,
            by + 11,
            "Username  ",
            self._username,
            self._focus == _FOCUS_USERNAME,
        )
        self._draw_field(
            console,
            bx,
            by + 12,
            "Name      ",
            self._charname,
            self._focus == _FOCUS_CHARNAME,
        )
        self._draw_color_row(console, bx, by + 13)

    def _draw_recent(self, console: tcod.console.Console, bx: int, by: int) -> None:
        console.print(bx + 3, by + 15, "Recent Servers", fg=_SECTION_COLOR)
        if not self._recent:
            console.print(bx + 4, by + 17, "(none)", fg=_ITEM_NORMAL)
            return
        for i, (host, port) in enumerate(self._recent[:5]):
            focused = self._focus == _FOCUS_RECENT_BASE + i
            fg = _ITEM_SELECT if focused else _ITEM_NORMAL
            prefix = "> " if focused else "  "
            console.print(bx + 2, by + 17 + i, f"{prefix}{host}:{port}", fg=fg)

    def _draw_bottom(self, console: tcod.console.Console, bx: int, by: int) -> None:
        focused = self._focus == self._focus_connect
        fg = _ITEM_SELECT if focused else _ITEM_NORMAL
        connect_text = "[ Connect ]"
        cx = bx + (_BOX_W - len(connect_text)) // 2
        console.print(cx, by + 24, connect_text, fg=fg)
        if self._error:
            console.print(bx + 2, by + 23, self._error[: _BOX_W - 4], fg=_ERROR_COLOR)
        hint = "Tab/\u2191\u2193 navigate  \u00b7  ESC back"
        hx = bx + (_BOX_W - len(hint)) // 2
        console.print(hx, by + _BOX_H - 3, hint, fg=_HINT_COLOR)
