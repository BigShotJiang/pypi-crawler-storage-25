"""Shared window-creation helpers for AppLoop and GameUI."""

from __future__ import annotations

import os
from typing import TYPE_CHECKING

import tcod.console
import tcod.context
import tcod.tileset

from faraway_realms.ui.layout import (
    CONSOLE_HEIGHT,
    CONSOLE_WIDTH,
    TILE_PX,
    TILESET_CHARMAP,
    TILESET_ROWS,
)

if TYPE_CHECKING:
    from pathlib import Path

    from faraway_realms.settings import DisplaySettings

# Maps DisplaySettings bool attrs → SDL window flag values.
_SDL_FLAG_MAP: tuple[tuple[str, int], ...] = (
    ("fullscreen", tcod.context.SDL_WINDOW_FULLSCREEN),
    ("allow_highdpi", tcod.context.SDL_WINDOW_ALLOW_HIGHDPI),
    ("borderless", tcod.context.SDL_WINDOW_BORDERLESS),
    ("maximized", tcod.context.SDL_WINDOW_MAXIMIZED),
    ("resizable", tcod.context.SDL_WINDOW_RESIZABLE),
)

# Maps scale_quality setting strings to SDL hint values.
_SCALE_QUALITY: dict[str, str] = {"nearest": "0", "linear": "1", "best": "2"}


def sdl_flags(settings: DisplaySettings) -> int:
    """OR together all SDL window flags enabled by *settings*."""
    return sum(flag for attr, flag in _SDL_FLAG_MAP if getattr(settings, attr))


def pixel_size(settings: DisplaySettings) -> dict[str, int]:
    """Return explicit pixel dimensions when integer scaling is active."""
    if settings.fullscreen or settings.integer_scale <= 1:
        return {}
    return {
        "width": CONSOLE_WIDTH * TILE_PX * settings.integer_scale,
        "height": CONSOLE_HEIGHT * TILE_PX * settings.integer_scale,
    }


def context_kwargs(settings: DisplaySettings) -> dict:
    """Build keyword arguments for ``tcod.context.new`` from display settings."""
    flags = sdl_flags(settings)
    _wpos = [("x", settings.window_x), ("y", settings.window_y)]
    pos = {k: v for k, v in _wpos if v is not None}
    kwargs: dict = {"vsync": settings.vsync, **pos, **pixel_size(settings)}
    if flags:
        kwargs["sdl_window_flags"] = flags
    return kwargs


def apply_scale_quality(settings: DisplaySettings) -> None:
    """Set SDL scale-quality hint from display settings (must be called early)."""
    os.environ["SDL_RENDER_SCALE_QUALITY"] = _SCALE_QUALITY.get(
        settings.scale_quality, "0"
    )


def new_console() -> tcod.console.Console:
    """Return a fresh console sized to the game layout."""
    return tcod.console.Console(CONSOLE_WIDTH, CONSOLE_HEIGHT, order="C")


def new_tileset(path: Path | str) -> tcod.tileset.Tileset:
    """Load the unified tilesheet from *path*."""
    return tcod.tileset.load_tilesheet(path, 16, TILESET_ROWS, TILESET_CHARMAP)
