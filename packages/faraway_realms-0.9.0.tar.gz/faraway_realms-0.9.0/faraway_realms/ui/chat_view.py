"""Chat pane: input state, history, message rendering, and scrollback."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import tcod.console
import tcod.context
import tcod.event

from faraway_realms.ui.layout import (
    _INPUT_BG,
    CHAT_HEIGHT,
    CHAT_WIDTH,
    CHAT_X,
    CHAT_Y,
    INPUT_Y,
)
from faraway_realms.ui.scroll_view import ScrollView
from faraway_realms.ui.text_input import TextInput

if TYPE_CHECKING:
    from faraway_realms.game_protocol import GameProtocol

_DEFAULT_COLOR = (200, 200, 200)
_PAGE_SCROLL = 5


@dataclass
class ChatView:
    """Owns chat input state and renders the chat pane.

    Parameters
    ----------
    game : Game
        Game instance used to read/write chat history.
    """

    game: GameProtocol
    _input: TextInput = field(init=False, repr=False)
    _focused: bool = field(default=False, init=False, repr=False)
    _history: list[str] = field(default_factory=list, init=False, repr=False)
    _history_idx: int = field(default=-1, init=False, repr=False)
    _history_buffer: str = field(default="", init=False, repr=False)
    _user_scrolled: bool = field(default=False, init=False, repr=False)
    _scroll: ScrollView = field(init=False, repr=False)

    def __post_init__(self) -> None:  # noqa: D105
        self._input = TextInput()
        self._scroll = ScrollView(lines=[], height=CHAT_HEIGHT, width=CHAT_WIDTH - 1)

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def buffer(self) -> str:
        """Current text in the input buffer."""
        return self._input.buffer

    @buffer.setter
    def buffer(self, value: str) -> None:
        self._input.buffer = value

    @property
    def focused(self) -> bool:
        """True when the chat input has keyboard focus."""
        return self._focused

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def focus(self, ctx: tcod.context.Context) -> None:
        """Give keyboard focus to the chat input."""
        self._focused = True
        TextInput.start_input(ctx)

    def unfocus(self, ctx: tcod.context.Context) -> None:
        """Remove keyboard focus and reset transient input state."""
        self._focused = False
        self._input.buffer = ""
        self._history_idx = -1
        self._history_buffer = ""
        TextInput.stop_input(ctx)

    def submit(self) -> str | None:
        """Return stripped buffer text and clear it; ``None`` if empty.

        Returns
        -------
        str | None
            The submitted text, or ``None`` if the buffer was blank.
        """
        text = self._input.buffer.strip()
        self._input.buffer = ""
        self._history_idx = -1
        self._history_buffer = ""
        return text if text else None

    def record_history(self, text: str) -> None:
        """Append *text* to the slash-command history."""
        self._history.append(text)

    def handle_text_input(self, event: tcod.event.TextInput) -> None:
        """Append typed character to the buffer when focused."""
        if self._focused:
            self._input.handle_text(event)
            self._history_idx = -1

    def handle_backspace(self) -> None:
        """Delete the last character from the input buffer when focused."""
        if self._focused:
            self._input.buffer = self._input.buffer[:-1]

    def handle_history_key(self, event: tcod.event.KeyDown) -> bool:
        """Navigate command history with ↑/↓ when focused.

        Parameters
        ----------
        event : tcod.event.KeyDown
            Incoming key event.

        Returns
        -------
        bool
            ``True`` if the key was consumed, ``False`` otherwise.
        """
        if not self._focused:
            return False
        if event.sym == tcod.event.KeySym.UP:
            self._history_older()
            return True
        if event.sym == tcod.event.KeySym.DOWN:
            self._history_newer()
            return True
        return False

    def scroll_up(self) -> None:
        """Scroll chat history up by one page (called by keybind dispatcher)."""
        self._scroll.scroll_up(_PAGE_SCROLL)
        self._user_scrolled = True

    def scroll_down(self) -> None:
        """Scroll chat history down by one page (called by keybind dispatcher)."""
        self._scroll.scroll_down(_PAGE_SCROLL)
        if self._scroll.at_bottom:
            self._user_scrolled = False

    def refresh_scroll(self) -> None:
        """Rebuild the ScrollView from the current game chat history."""
        history = self.game.get_chat_history()
        self._scroll.lines = [(m.text, m.color) for m in history]
        if not self._user_scrolled:
            self._scroll.scroll_to_bottom()

    def render(self, console: tcod.console.Console) -> None:
        """Render the chat history and input line.

        Parameters
        ----------
        console : tcod.console.Console
            Target console.
        """
        self.refresh_scroll()
        self._scroll.render(console, CHAT_X + 1, CHAT_Y)
        self._render_input_line(console)

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _render_input_line(self, console: tcod.console.Console) -> None:
        console.rgb[INPUT_Y, CHAT_X + 1 : CHAT_X + CHAT_WIDTH - 1]["bg"] = _INPUT_BG
        prompt = "> " + self._input.buffer
        if self._focused:
            prompt += "_"
        console.print(CHAT_X + 1, INPUT_Y, prompt[: CHAT_WIDTH - 2], fg=(255, 255, 255))

    def _history_older(self) -> None:
        if not self._history:
            return
        if self._history_idx < 0:
            self._history_buffer = self._input.buffer
            self._history_idx = len(self._history) - 1
        elif self._history_idx > 0:
            self._history_idx -= 1
        self._input.buffer = self._history[self._history_idx]

    def _history_newer(self) -> None:
        if self._history_idx < 0:
            return
        self._history_idx += 1
        if self._history_idx >= len(self._history):
            self._history_idx = -1
            self._input.buffer = self._history_buffer
        else:
            self._input.buffer = self._history[self._history_idx]
