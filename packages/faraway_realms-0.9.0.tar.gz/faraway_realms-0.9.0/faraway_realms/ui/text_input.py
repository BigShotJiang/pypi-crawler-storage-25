"""Reusable single-line text input widget."""

from __future__ import annotations

from typing import TYPE_CHECKING

import tcod.console
import tcod.event

if TYPE_CHECKING:
    import tcod.context


class TextInput:
    """Single-line text input with backspace and SDL text-input mode."""

    def __init__(self, max_len: int = 40) -> None:
        self.buffer: str = ""
        self._max_len = max_len

    def handle_key(self, event: tcod.event.KeyDown) -> bool:
        """Consume a key event; return True if handled."""
        if event.sym == tcod.event.KeySym.BACKSPACE:
            self.buffer = self.buffer[:-1]
            return True
        return False

    def handle_text(self, event: tcod.event.TextInput) -> None:
        """Append printable text, respecting max_len."""
        remaining = self._max_len - len(self.buffer)
        self.buffer += event.text[:remaining]

    def render(
        self,
        console: tcod.console.Console,
        x: int,
        y: int,
        width: int,
        focused: bool,
        fg: tuple[int, int, int],
    ) -> None:
        """Draw the buffer with a cursor when focused."""
        display = (self.buffer + ("_" if focused else " "))[:width]
        console.print(x, y, display.ljust(width), fg=fg)

    @staticmethod
    def start_input(ctx: tcod.context.Context) -> None:
        """Enable SDL text-input mode (required for printable characters)."""
        if ctx.sdl_window is not None:
            ctx.sdl_window.start_text_input()  # type: ignore[attr-defined]

    @staticmethod
    def stop_input(ctx: tcod.context.Context) -> None:
        """Disable SDL text-input mode."""
        if ctx.sdl_window is not None:
            ctx.sdl_window.stop_text_input()  # type: ignore[attr-defined]
