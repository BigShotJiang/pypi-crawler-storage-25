"""YAML-driven key binding loader and event matcher."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import tcod.event
import yaml

# Only these modifier bits matter for binding comparisons; strip CAPS/NUMLOCK.
_MOD_MASK: int = (
    int(tcod.event.Modifier.SHIFT)
    | int(tcod.event.Modifier.CTRL)
    | int(tcod.event.Modifier.ALT)
)

_SHIFT = int(tcod.event.Modifier.SHIFT)
_CTRL = int(tcod.event.Modifier.CTRL)
_ALT = int(tcod.event.Modifier.ALT)

_MOD_NAMES: dict[str, int] = {
    "shift": _SHIFT,
    "ctrl": _CTRL,
    "alt": _ALT,
}

_NAMED_KEYS: dict[str, tcod.event.KeySym] = {
    "left": tcod.event.KeySym.LEFT,
    "right": tcod.event.KeySym.RIGHT,
    "up": tcod.event.KeySym.UP,
    "down": tcod.event.KeySym.DOWN,
    "tab": tcod.event.KeySym.TAB,
    "return": tcod.event.KeySym.RETURN,
    "enter": tcod.event.KeySym.RETURN,
    "escape": tcod.event.KeySym.ESCAPE,
    "backspace": tcod.event.KeySym.BACKSPACE,
    "pageup": tcod.event.KeySym.PAGEUP,
    "pagedown": tcod.event.KeySym.PAGEDOWN,
    "space": tcod.event.KeySym.SPACE,
    "home": tcod.event.KeySym.HOME,
    "end": tcod.event.KeySym.END,
    "insert": tcod.event.KeySym.INSERT,
    "delete": tcod.event.KeySym.DELETE,
    "f1": tcod.event.KeySym.F1,
    "f2": tcod.event.KeySym.F2,
    "f3": tcod.event.KeySym.F3,
    "f4": tcod.event.KeySym.F4,
    "f5": tcod.event.KeySym.F5,
    "f6": tcod.event.KeySym.F6,
    "f7": tcod.event.KeySym.F7,
    "f8": tcod.event.KeySym.F8,
    "f9": tcod.event.KeySym.F9,
    "f10": tcod.event.KeySym.F10,
    "f11": tcod.event.KeySym.F11,
    "f12": tcod.event.KeySym.F12,
}

# SDL may report a shifted punctuation char as either the shifted KeySym
# (e.g. QUESTION) or as the base key + SHIFT modifier (e.g. SLASH+SHIFT).
# This table maps (base_sym, SHIFT) → canonical (shifted_sym, 0) so that
# match_event can transparently handle either SDL form.
_SHIFT_ALIASES: dict[tuple[int, int], tuple[int, int]] = {
    (int(tcod.event.KeySym.SLASH), _SHIFT): (int(tcod.event.KeySym.QUESTION), 0),
    (int(tcod.event.KeySym.LEFTBRACKET), _SHIFT): (ord("{"), 0),
    (int(tcod.event.KeySym.RIGHTBRACKET), _SHIFT): (ord("}"), 0),
    (int(tcod.event.KeySym(ord("1"))), _SHIFT): (int(tcod.event.KeySym.EXCLAIM), 0),
    (int(tcod.event.KeySym(ord("."))), _SHIFT): (ord(">"), 0),
    (int(tcod.event.KeySym(ord(","))), _SHIFT): (ord("<"), 0),
}

# KeybindMap: (sym_int, mods_int) → action string ("/command" or ":ui_action")
KeybindMap = dict[tuple[int, int], str]

_DATA_PATH = Path(__file__).parent.parent / "data" / "keybinds" / "default.yaml"
_USER_PATH = Path.home() / ".faraway_realms" / "keybinds.yaml"


def parse_key(s: str) -> tuple[int, int]:
    """Parse a key string like ``"e"``, ``"shift+e"``, ``"?"`` into ``(sym, mods)``.

    Parameters
    ----------
    s : str
        Key string from the YAML keybind file.

    Returns
    -------
    tuple[int, int]
        ``(KeySym value, modifier bitmask)``.
    """
    parts = s.split("+")
    mods = 0
    i = 0
    while i < len(parts) - 1 and parts[i].lower() in _MOD_NAMES:
        mods |= _MOD_NAMES[parts[i].lower()]
        i += 1
    key_str = "+".join(parts[i:])
    sym = _resolve_sym(key_str)
    return (int(sym), mods & _MOD_MASK)


def _resolve_sym(s: str) -> tcod.event.KeySym:
    lower = s.lower()
    if lower in _NAMED_KEYS:
        return _NAMED_KEYS[lower]
    if len(s) == 1:
        return tcod.event.KeySym(ord(s))
    raise ValueError(f"Unknown key name: {s!r}")


def build_keybind_map(entries: dict[str, str]) -> KeybindMap:
    """Build a lookup dict from YAML ``key: action`` entries."""
    result: KeybindMap = {}
    for key_str, action in entries.items():
        pair = parse_key(str(key_str))
        result[pair] = str(action)
    return result


def _normalize_mods(raw: int) -> int:
    """Collapse L/R modifier variants into combined flags and strip CAPS/NUMLOCK."""
    result = 0
    if raw & int(tcod.event.Modifier.SHIFT):
        result |= _SHIFT
    if raw & int(tcod.event.Modifier.CTRL):
        result |= _CTRL
    if raw & int(tcod.event.Modifier.ALT):
        result |= _ALT
    return result


def match_event(km: KeybindMap, event: tcod.event.KeyDown) -> str | None:
    """Return the action bound to *event*, or ``None`` if unbound.

    Checks SDL shift aliases on a miss so that e.g. SLASH+SHIFT and QUESTION
    both match a ``"?"`` binding.
    """
    mods = _normalize_mods(int(event.mod))
    sym = int(event.sym)
    action = km.get((sym, mods))
    if action is not None:
        return action
    canonical = _SHIFT_ALIASES.get((sym, mods))
    if canonical is not None:
        return km.get(canonical)
    return None


def load_keybinds(preset: str | None = None) -> KeybindMap:
    """Load keybind map from the bundled default plus optional user override.

    Merge order (last wins per key):
    1. ``faraway_realms/data/keybinds/default.yaml`` — ``global`` section
    2. ``~/.faraway_realms/keybinds.yaml`` — ``global`` section
    3. ``default.yaml`` — ``presets.<preset>`` section (if *preset* given)
    4. user file — ``presets.<preset>`` section (if present)

    Parameters
    ----------
    preset : str | None
        Preset name to overlay on top of the global section (e.g. ``"hero"``).
    """
    default = _read_yaml(_DATA_PATH)
    user: dict[str, Any] = _read_yaml(_USER_PATH) if _USER_PATH.exists() else {}

    entries: dict[str, str] = {}
    entries.update(default.get("global", {}))
    entries.update(user.get("global", {}))
    if preset:
        entries.update(default.get("presets", {}).get(preset, {}))
        entries.update(user.get("presets", {}).get(preset, {}))
    return build_keybind_map(entries)


def _read_yaml(path: Path) -> dict[str, Any]:
    with path.open(encoding="utf-8") as fh:
        return yaml.safe_load(fh) or {}
