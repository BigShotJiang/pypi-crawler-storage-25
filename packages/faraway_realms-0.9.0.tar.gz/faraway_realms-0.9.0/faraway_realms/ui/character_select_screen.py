"""Character preset selection screen — shown between main menu and game launch."""

from __future__ import annotations

import textwrap
from typing import Any, Callable

import tcod.console
import tcod.event

from faraway_realms.ui.app_loop import AppState
from faraway_realms.ui.layout import CONSOLE_HEIGHT, CONSOLE_WIDTH

_BOX_W = 62
_BOX_H = 30
_LIST_W = 16
_DIVIDER_X = _LIST_W + 1  # relative to box interior

_BG: tuple[int, int, int] = (6, 6, 10)
_BORDER_FG: tuple[int, int, int] = (60, 55, 45)
_TITLE_COLOR: tuple[int, int, int] = (200, 160, 55)
_ITEM_SELECT: tuple[int, int, int] = (230, 210, 130)
_ITEM_NORMAL: tuple[int, int, int] = (130, 130, 130)
_HINT_COLOR: tuple[int, int, int] = (50, 50, 50)
_STAT_KEY_COLOR: tuple[int, int, int] = (100, 100, 100)
_STAT_VAL_COLOR: tuple[int, int, int] = (200, 200, 180)
_DESC_COLOR: tuple[int, int, int] = (160, 155, 140)
_SECTION_COLOR: tuple[int, int, int] = (110, 90, 50)
_CHAR_COLOR: tuple[int, int, int] = (255, 240, 150)


class CharacterSelectScreen:
    """Two-pane screen: class list on the left, stats + description on the right.

    Parameters
    ----------
    char_types : list[tuple[str, object]]
        Ordered list of (registry_key, CreatureType) pairs.
    on_select : Callable[[str], None]
        Called with the chosen registry key when the player confirms.
    """

    def __init__(
        self,
        char_types: list[tuple[str, Any]],
        on_select: Callable[[str], None],
    ) -> None:
        self._types = char_types
        self._on_select = on_select
        self._selected = 0

    def tick(self) -> None:
        """No per-frame logic needed."""

    def render(self, console: tcod.console.Console) -> None:
        """Draw the screen."""
        console.clear(bg=_BG)
        bx = (CONSOLE_WIDTH - _BOX_W) // 2
        by = (CONSOLE_HEIGHT - _BOX_H) // 2
        console.draw_frame(bx, by, _BOX_W, _BOX_H, fg=_BORDER_FG, bg=_BG)

        title = "CHOOSE YOUR CLASS"
        console.print(bx + (_BOX_W - len(title)) // 2, by + 1, title, fg=_TITLE_COLOR)

        self._draw_list(console, bx, by)
        self._draw_divider(console, bx, by)
        self._draw_detail(console, bx, by)
        self._draw_hint(console, bx, by)

    def handle_event(self, event: tcod.event.Event) -> AppState | None:
        """Handle navigation and selection."""
        if isinstance(event, tcod.event.Quit):
            return AppState.QUITTING
        if isinstance(event, tcod.event.KeyDown):
            return self._handle_key(event)
        return None

    # ------------------------------------------------------------------

    def _handle_key(self, event: tcod.event.KeyDown) -> AppState | None:
        sym = event.sym
        if sym in (tcod.event.KeySym(ord("k")), tcod.event.KeySym.UP):
            self._selected = (self._selected - 1) % len(self._types)
        elif sym in (tcod.event.KeySym(ord("j")), tcod.event.KeySym.DOWN):
            self._selected = (self._selected + 1) % len(self._types)
        else:
            return self._handle_action_key(sym)
        return None

    def _handle_action_key(self, sym: tcod.event.KeySym) -> AppState | None:
        if sym == tcod.event.KeySym.RETURN:
            key, _ = self._types[self._selected]
            self._on_select(key)
            return AppState.IN_GAME
        if sym == tcod.event.KeySym.ESCAPE:
            return AppState.MAIN_MENU
        return None

    def _draw_list(self, console: tcod.console.Console, bx: int, by: int) -> None:
        for i, (key, ct) in enumerate(self._types):
            y = by + 3 + i * 2
            name = getattr(ct, "name", key).upper()
            prefix = "> " if i == self._selected else "  "
            color = _ITEM_SELECT if i == self._selected else _ITEM_NORMAL
            console.print(bx + 1, y, f"{prefix}{name}", fg=color)

    def _draw_divider(self, console: tcod.console.Console, bx: int, by: int) -> None:
        dx = bx + _DIVIDER_X + _LIST_W
        for dy in range(1, _BOX_H - 2):
            console.print(dx, by + dy, "\u2502", fg=_BORDER_FG)
        console.print(dx, by, "\u252c", fg=_BORDER_FG)
        console.print(dx, by + _BOX_H - 1, "\u2534", fg=_BORDER_FG)

    def _draw_detail(self, console: tcod.console.Console, bx: int, by: int) -> None:
        _, ct = self._types[self._selected]
        rx = bx + _DIVIDER_X + _LIST_W + 2
        detail_w = _BOX_W - _LIST_W - _DIVIDER_X - 3
        char_val = getattr(ct, "char", ord("?"))
        name = getattr(ct, "name", "?").upper()
        console.print(rx, by + 2, chr(char_val), fg=_CHAR_COLOR)
        console.print(rx + 2, by + 2, name, fg=_ITEM_SELECT)
        row = by + 4
        row = self._draw_stats(console, ct, rx, row)
        row = self._draw_abilities(console, ct, rx, row, detail_w)
        self._draw_description(console, ct, rx, row, detail_w, by)

    _STAT_LABELS: dict[str, str] = {
        "health": "HP",
        "mana": "MP",
        "strength": "STR",
        "armor": "ARM",
        "crit_chance": "CRIT",
        "constitution": "CON",
    }

    def _draw_stats(
        self, console: tcod.console.Console, ct: Any, rx: int, row: int
    ) -> int:
        stats: dict = getattr(ct, "stats", {})
        for key, label in self._STAT_LABELS.items():
            if key in stats:
                suffix = "%" if key == "crit_chance" else ""
                console.print(rx, row, f"{label}:", fg=_STAT_KEY_COLOR)
                console.print(rx + 6, row, f"{stats[key]}{suffix}", fg=_STAT_VAL_COLOR)
                row += 1
        return row

    def _draw_abilities(
        self, console: tcod.console.Console, ct: Any, rx: int, row: int, detail_w: int
    ) -> int:
        abilities: tuple = getattr(ct, "abilities", ())
        if not abilities:
            return row
        row += 1
        console.print(rx, row, "Abilities", fg=_SECTION_COLOR)
        row += 1
        ability_text = "  ".join(a.replace("_", " ") for a in abilities)
        for line in textwrap.wrap(ability_text, detail_w):
            console.print(rx, row, line, fg=_ITEM_NORMAL)
            row += 1
        return row

    def _draw_description(
        self,
        console: tcod.console.Console,
        ct: Any,
        rx: int,
        row: int,
        detail_w: int,
        by: int,
    ) -> None:
        description: str | None = getattr(ct, "description", None)
        if not description:
            return
        row += 1
        for line in textwrap.wrap(description, detail_w):
            console.print(rx, row, line, fg=_DESC_COLOR)
            row += 1
            if row >= by + _BOX_H - 3:
                return

    def _draw_hint(self, console: tcod.console.Console, bx: int, by: int) -> None:
        hint = "\u2191\u2193 navigate  \u00b7  Enter select  \u00b7  Esc back"
        console.print(
            bx + (_BOX_W - len(hint)) // 2,
            by + _BOX_H - 2,
            hint,
            fg=_HINT_COLOR,
        )
