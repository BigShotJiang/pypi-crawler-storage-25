"""Main menu screen — the first screen shown on launch."""

from __future__ import annotations

import tcod.console
import tcod.event

from faraway_realms.ui.app_loop import AppState
from faraway_realms.ui.layout import CONSOLE_HEIGHT, CONSOLE_WIDTH

_BOX_W = 36
_BOX_H = 20
_BG: tuple[int, int, int] = (6, 6, 10)
_BORDER_FG: tuple[int, int, int] = (60, 55, 45)
_TITLE_COLOR: tuple[int, int, int] = (200, 160, 55)
_ITEM_NORMAL: tuple[int, int, int] = (130, 130, 130)
_ITEM_SELECT: tuple[int, int, int] = (230, 210, 130)
_HINT_COLOR: tuple[int, int, int] = (50, 50, 50)

_ITEMS: tuple[str, ...] = ("Play", "Join Server", "Settings", "Quit")

# Vertical positions relative to box top-left
_TITLE_ROW = 2  # "FARAWAY"
_MENU_START = 6  # first item row; items spaced 2 apart
_HINT_ROW = _BOX_H - 2


class MainMenuScreen:
    """Floating centred menu with title, item list, and nav hint."""

    def __init__(self) -> None:
        self._selected = 0

    def tick(self) -> None:
        """No per-frame logic needed for the main menu."""

    def render(self, console: tcod.console.Console) -> None:
        """Draw the menu onto *console*."""
        console.clear(bg=_BG)
        bx = (CONSOLE_WIDTH - _BOX_W) // 2
        by = (CONSOLE_HEIGHT - _BOX_H) // 2
        self._draw_box(console, bx, by)
        self._draw_title(console, bx, by)
        self._draw_items(console, bx, by)
        self._draw_hint(console, bx, by)

    def handle_event(self, event: tcod.event.Event) -> AppState | None:
        """Route SDL events; return next state or None to stay."""
        if isinstance(event, tcod.event.Quit):
            return AppState.QUITTING
        if isinstance(event, tcod.event.KeyDown):
            return self._handle_key(event)
        return None

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _handle_key(self, event: tcod.event.KeyDown) -> AppState | None:
        if event.sym in (tcod.event.KeySym(ord("k")), tcod.event.KeySym.UP):
            self._selected = (self._selected - 1) % len(_ITEMS)
        elif event.sym in (tcod.event.KeySym(ord("j")), tcod.event.KeySym.DOWN):
            self._selected = (self._selected + 1) % len(_ITEMS)
        elif event.sym == tcod.event.KeySym.RETURN:
            return self._activate()
        return None

    def _activate(self) -> AppState:
        item = _ITEMS[self._selected]
        if item == "Play":
            return AppState.CHARACTER_SELECT
        if item == "Join Server":
            return AppState.JOIN_SERVER
        if item == "Settings":
            return AppState.SETTINGS
        return AppState.QUITTING

    def _draw_box(self, console: tcod.console.Console, bx: int, by: int) -> None:
        console.draw_frame(bx, by, _BOX_W, _BOX_H, fg=_BORDER_FG, bg=_BG)

    def _cx(self, bx: int, text: str) -> int:
        return bx + (_BOX_W - len(text)) // 2

    def _draw_title(self, console: tcod.console.Console, bx: int, by: int) -> None:
        title = "FARAWAY REALMS"
        console.print(self._cx(bx, title), by + _TITLE_ROW, title, fg=_TITLE_COLOR)

    def _draw_items(self, console: tcod.console.Console, bx: int, by: int) -> None:
        block_x = self._cx(bx, "  " + max(_ITEMS, key=len))
        for i, item in enumerate(_ITEMS):
            y = by + _MENU_START + i * 2
            prefix = "> " if i == self._selected else "  "
            color = _ITEM_SELECT if i == self._selected else _ITEM_NORMAL
            console.print(block_x, y, prefix + item, fg=color)

    def _draw_hint(self, console: tcod.console.Console, bx: int, by: int) -> None:
        hint = "\u2191\u2193 navigate  \u00b7  Enter select"
        console.print(self._cx(bx, hint), by + _HINT_ROW, hint, fg=_HINT_COLOR)
