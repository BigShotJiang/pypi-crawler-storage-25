"""Application state machine and top-level render loop."""

from __future__ import annotations

import time
from enum import Enum, auto
from typing import TYPE_CHECKING, Callable, Protocol

import tcod.console
import tcod.context
import tcod.event

from faraway_realms.settings import load_display_settings
from faraway_realms.ui.layout import _FRAME_DURATION
from faraway_realms.ui.window import (
    apply_scale_quality,
    context_kwargs,
    new_console,
    new_tileset,
)

if TYPE_CHECKING:
    from pathlib import Path


class AppState(Enum):
    """Top-level application states."""

    MAIN_MENU = auto()
    CHARACTER_SELECT = auto()
    SETTINGS = auto()
    JOIN_SERVER = auto()
    IN_GAME = auto()
    QUITTING = auto()


class Screen(Protocol):
    """Protocol every application screen must satisfy."""

    def tick(self) -> None:
        """Call once per frame before events are processed."""
        ...

    def render(self, console: tcod.console.Console) -> None:
        """Draw this screen onto *console*."""
        ...

    def handle_event(self, event: tcod.event.Event) -> AppState | None:
        """Handle a single SDL event.

        Returns the next ``AppState`` to transition to, or ``None`` to stay.
        """
        ...


class AppLoop:
    """Owns the TCOD window and drives the state-machine render loop.

    Parameters
    ----------
    tileset_path : Path | str
        Path to the tilesheet PNG.
    factories : dict
        Maps each ``AppState`` to a callable ``(ctx) -> Screen``.
    """

    def __init__(
        self,
        tileset_path: Path | str,
        factories: dict[AppState, Callable[[tcod.context.Context], Screen]],
    ) -> None:
        self._tileset_path = tileset_path
        self._factories = factories

    def run(self, initial_state: AppState) -> None:
        """Open the window and run until ``AppState.QUITTING`` or window close."""
        settings = load_display_settings()
        apply_scale_quality(settings)
        tileset = new_tileset(self._tileset_path)
        console = new_console()
        with tcod.context.new(
            console=console,
            tileset=tileset,
            title="Faraway Realms",
            **context_kwargs(settings),
        ) as ctx:
            screen: Screen = self._factories[initial_state](ctx)
            self._run_loop(ctx, console, screen)

    def _run_loop(
        self,
        ctx: tcod.context.Context,
        console: tcod.console.Console,
        screen: Screen,
    ) -> None:
        while True:
            now = time.monotonic()
            screen.tick()
            screen = self._process_events(ctx, screen)  # type: ignore[assignment]
            if screen is None:
                break
            screen.render(console)
            ctx.present(console)
            time.sleep(max(0.0, _FRAME_DURATION - (time.monotonic() - now)))

    def _process_events(
        self, ctx: tcod.context.Context, screen: Screen
    ) -> Screen | None:
        for event in tcod.event.get():
            result = screen.handle_event(event)
            if result is not None:
                return self._transition(ctx, result)
        return screen

    def _transition(self, ctx: tcod.context.Context, state: AppState) -> Screen | None:
        if state == AppState.QUITTING:
            return None
        factory = self._factories.get(state)
        return factory(ctx) if factory is not None else None
