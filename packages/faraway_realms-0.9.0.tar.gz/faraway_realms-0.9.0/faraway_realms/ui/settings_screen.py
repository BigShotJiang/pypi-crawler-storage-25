"""Settings screen — declarative, expandable display-settings editor."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Callable

import tcod.console
import tcod.event

from faraway_realms.settings import load_display_settings, save_display_settings
from faraway_realms.ui.app_loop import AppState
from faraway_realms.ui.layout import CONSOLE_HEIGHT, CONSOLE_WIDTH

if TYPE_CHECKING:
    import tcod.context

# ---------------------------------------------------------------------------
# Declarative metadata
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class SettingEntry:
    """Metadata for one editable display setting."""

    section: str
    attr: str
    label: str
    kind: str  # "bool" | "int" | "choice"
    choices: tuple[str, ...] = ()
    min_val: int = 1
    max_val: int = 8


_SETTINGS_DEFS: tuple[SettingEntry, ...] = (
    SettingEntry("Display", "fullscreen", "Fullscreen", "bool"),
    SettingEntry("Display", "borderless", "Borderless Window", "bool"),
    SettingEntry("Display", "maximized", "Start Maximized", "bool"),
    SettingEntry("Display", "resizable", "Resizable", "bool"),
    SettingEntry("Display", "allow_highdpi", "Allow High DPI", "bool"),
    SettingEntry("Display", "vsync", "VSync", "bool"),
    SettingEntry(
        "Display", "integer_scale", "Integer Scale", "int", min_val=1, max_val=8
    ),
    SettingEntry(
        "Display",
        "scale_quality",
        "Scale Quality",
        "choice",
        choices=("nearest", "linear", "best"),
    ),
)

# ---------------------------------------------------------------------------
# Internal row model
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class _Row:
    label: str
    entry: SettingEntry | None  # None = non-selectable section header


def _build_rows(defs: tuple[SettingEntry, ...]) -> list[_Row]:
    rows: list[_Row] = []
    seen: set[str] = set()
    for entry in defs:
        if entry.section not in seen:
            rows.append(_Row(label=entry.section, entry=None))
            rows.append(_Row(label="", entry=None))
            seen.add(entry.section)
        rows.append(_Row(label=entry.label, entry=entry))
    return rows


# ---------------------------------------------------------------------------
# Visual constants
# ---------------------------------------------------------------------------

_BOX_W = 46
_BOX_H = 26
_LIST_Y = 4  # first list row, relative to by
_LIST_H = 18  # number of visible list rows

_BG: tuple[int, int, int] = (6, 6, 10)
_BORDER_FG: tuple[int, int, int] = (60, 55, 45)
_TITLE_COLOR: tuple[int, int, int] = (200, 160, 55)
_SECTION_COLOR: tuple[int, int, int] = (110, 90, 50)
_ITEM_NORMAL: tuple[int, int, int] = (130, 130, 130)
_ITEM_SELECT: tuple[int, int, int] = (230, 210, 130)
_HINT_COLOR: tuple[int, int, int] = (50, 50, 50)
_RESTART_COLOR: tuple[int, int, int] = (60, 55, 45)

# ---------------------------------------------------------------------------
# Live-apply handlers — absent key means restart required
# ---------------------------------------------------------------------------


def _apply_fullscreen(ctx: tcod.context.Context, val: object) -> None:
    if ctx.sdl_window is not None:
        ctx.sdl_window.fullscreen = bool(val)  # type: ignore[attr-defined]


def _apply_resizable(ctx: tcod.context.Context, val: object) -> None:
    if ctx.sdl_window is not None:
        ctx.sdl_window.resizable = bool(val)  # type: ignore[attr-defined]


def _apply_maximized(ctx: tcod.context.Context, val: object) -> None:
    if ctx.sdl_window is None:
        return
    if bool(val):
        ctx.sdl_window.maximize()  # type: ignore[attr-defined]
    else:
        ctx.sdl_window.restore()  # type: ignore[attr-defined]


_LIVE_APPLY: dict[str, Callable[[tcod.context.Context, object], None]] = {
    "fullscreen": _apply_fullscreen,
    "resizable": _apply_resizable,
    "maximized": _apply_maximized,
}


# ---------------------------------------------------------------------------
# Screen
# ---------------------------------------------------------------------------


class SettingsScreen:
    """Scrollable, keyboard-driven settings editor."""

    def __init__(self, ctx: tcod.context.Context) -> None:
        self._ctx = ctx
        settings = load_display_settings()
        self._values: dict[str, object] = {
            e.attr: getattr(settings, e.attr) for e in _SETTINGS_DEFS
        }
        self._rows: list[_Row] = _build_rows(_SETTINGS_DEFS)
        self._selectable: list[int] = [
            i for i, r in enumerate(self._rows) if r.entry is not None
        ]
        self._sel_idx: int = 0
        self._scroll: int = 0
        self._needs_restart: bool = False

    @property
    def _cursor(self) -> int:
        return self._selectable[self._sel_idx]

    def tick(self) -> None:
        """No per-frame logic needed."""

    def render(self, console: tcod.console.Console) -> None:
        """Draw the settings box onto *console*."""
        console.clear(bg=_BG)
        bx = (CONSOLE_WIDTH - _BOX_W) // 2
        by = (CONSOLE_HEIGHT - _BOX_H) // 2
        console.draw_frame(bx, by, _BOX_W, _BOX_H, fg=_BORDER_FG, bg=_BG)
        self._draw_title(console, bx, by)
        self._draw_rows(console, bx, by)
        self._draw_hint(console, bx, by)
        if self._needs_restart:
            self._draw_restart_notice(console, bx, by)

    def handle_event(self, event: tcod.event.Event) -> AppState | None:
        """Route SDL events; save and return to main menu on ESC."""
        if isinstance(event, tcod.event.Quit):
            self._save()
            return AppState.QUITTING
        if isinstance(event, tcod.event.KeyDown):
            return self._handle_key(event)
        return None

    # ------------------------------------------------------------------
    # Input
    # ------------------------------------------------------------------

    def _handle_key(self, event: tcod.event.KeyDown) -> AppState | None:
        if self._handle_nav_key(event):
            return None
        return self._handle_edit_key(event)

    def _handle_nav_key(self, event: tcod.event.KeyDown) -> bool:
        if event.sym in (tcod.event.KeySym(ord("k")), tcod.event.KeySym.UP):
            self._move(-1)
            return True
        if event.sym in (tcod.event.KeySym(ord("j")), tcod.event.KeySym.DOWN):
            self._move(1)
            return True
        return False

    def _handle_edit_key(self, event: tcod.event.KeyDown) -> AppState | None:
        delta = self._edit_delta(event)
        if delta != 0:
            self._edit(delta)
            return None
        if event.sym == tcod.event.KeySym.ESCAPE:
            self._save()
            return AppState.MAIN_MENU
        return None

    def _edit_delta(self, event: tcod.event.KeyDown) -> int:
        if event.sym in (tcod.event.KeySym.LEFT, tcod.event.KeySym(ord("h"))):
            return -1
        if event.sym in (
            tcod.event.KeySym.RIGHT,
            tcod.event.KeySym(ord("l")),
            tcod.event.KeySym.SPACE,
        ):
            return 1
        return 0

    def _move(self, delta: int) -> None:
        self._sel_idx = (self._sel_idx + delta) % len(self._selectable)
        self._adjust_scroll()

    def _adjust_scroll(self) -> None:
        cursor = self._cursor
        if cursor < self._scroll:
            self._scroll = cursor
        if cursor >= self._scroll + _LIST_H:
            self._scroll = cursor - _LIST_H + 1

    def _edit(self, delta: int) -> None:
        row = self._rows[self._cursor]
        if row.entry is not None:
            self._change_value(row.entry, delta)

    def _change_value(self, entry: SettingEntry, delta: int) -> None:
        val = self._values[entry.attr]
        if entry.kind == "bool":
            self._values[entry.attr] = not val
        elif entry.kind == "int":
            self._values[entry.attr] = max(
                entry.min_val,
                min(entry.max_val, int(val) + delta),  # type: ignore[arg-type,call-overload]
            )
        elif entry.kind == "choice":
            idx = entry.choices.index(str(val))
            self._values[entry.attr] = entry.choices[(idx + delta) % len(entry.choices)]
        self._maybe_live_apply(entry)

    def _maybe_live_apply(self, entry: SettingEntry) -> None:
        handler = _LIVE_APPLY.get(entry.attr)
        if handler is not None:
            handler(self._ctx, self._values[entry.attr])
        else:
            self._needs_restart = True

    def _save(self) -> None:
        save_display_settings(dict(self._values))

    # ------------------------------------------------------------------
    # Rendering
    # ------------------------------------------------------------------

    def _draw_title(self, console: tcod.console.Console, bx: int, by: int) -> None:
        title = "SETTINGS"
        x = bx + (_BOX_W - len(title)) // 2
        console.print(x, by + 2, title, fg=_TITLE_COLOR)

    def _draw_rows(self, console: tcod.console.Console, bx: int, by: int) -> None:
        ix = bx + 2
        iw = _BOX_W - 7  # 2 left interior + 4 right padding = 6 chars consumed
        visible = self._rows[self._scroll : self._scroll + _LIST_H]
        for i, row in enumerate(visible):
            y = by + _LIST_Y + i
            if row.entry is None:
                console.print(ix + 1, y, row.label, fg=_SECTION_COLOR)
            else:
                selected = (self._scroll + i) == self._cursor
                self._draw_entry(console, ix, y, iw, row, selected)

    def _draw_entry(
        self,
        console: tcod.console.Console,
        x: int,
        y: int,
        width: int,
        row: _Row,
        selected: bool,
    ) -> None:
        if row.entry is None:
            return
        prefix = "> " if selected else "  "
        fg = _ITEM_SELECT if selected else _ITEM_NORMAL
        label = prefix + row.label
        value = self._fmt(row.entry)
        dots = "." * max(1, width - len(label) - len(value))
        console.print(x, y, label + dots + value, fg=fg)

    def _fmt(self, entry: SettingEntry) -> str:
        val = self._values[entry.attr]
        if entry.kind == "bool":
            return "On" if val else "Off"
        return str(val)

    def _draw_hint(self, console: tcod.console.Console, bx: int, by: int) -> None:
        hint = "\u2190\u2192 change  \u00b7  ESC back"
        x = bx + (_BOX_W - len(hint)) // 2
        console.print(x, by + _BOX_H - 3, hint, fg=_HINT_COLOR)

    def _draw_restart_notice(
        self, console: tcod.console.Console, bx: int, by: int
    ) -> None:
        notice = "restart to apply"
        x = bx + (_BOX_W - len(notice)) // 2
        console.print(x, by + _BOX_H - 2, notice, fg=_RESTART_COLOR)
