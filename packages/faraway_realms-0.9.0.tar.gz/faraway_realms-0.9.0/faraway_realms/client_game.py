"""ClientGame: GameProtocol implementation backed by a NetworkClient snapshot."""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from faraway_realms.chat import ChatMessage
from faraway_realms.combat.status import StatusInstance
from faraway_realms.effects.fog import FogParams
from faraway_realms.effects.light import LightSource
from faraway_realms.entities.entity import Entity, GameEntity
from faraway_realms.entities.static_object import StaticObject
from faraway_realms.world.factions import FactionRelations
from faraway_realms.world.map import Map
from faraway_realms.world.tile import Tile

if TYPE_CHECKING:
    from faraway_realms.combat.projectile import Projectile
    from faraway_realms.net.client import NetworkClient
    from faraway_realms.net.serialization import EntitySnapshot
    from faraway_realms.world.commands import Command


@dataclass(frozen=True)
class _ClientProjectile:
    """Lightweight projectile view reconstructed from a network snapshot."""

    x: int
    y: int
    color: tuple[int, int, int]
    trail: deque  # type: ignore[type-arg]
    trail_char: str


@dataclass
class _SnapshotEntity(GameEntity):
    """Lightweight GameEntity reconstructed from a network snapshot."""

    _display_name_val: str = field(default="", kw_only=True)

    @property
    def display_name(self) -> str:
        """Return the entity's display name from the snapshot."""
        return self._display_name_val


def _deserialize_stat(d: dict[str, Any]) -> Any:
    """Reconstruct a Stat or Pool from its serialized dict."""
    from faraway_realms.combat.stats import Pool, Stat

    abbr = d.get("abbreviation")
    bf = tuple(d["bar_filled"]) if d.get("bar_filled") else None
    be = tuple(d["bar_empty"]) if d.get("bar_empty") else None
    if d.get("is_pool"):
        pool = Pool(
            base=d["base"],
            bonus=d.get("bonus", 0),
            abbreviation=abbr,
            bar_filled=bf,
            bar_empty=be,
        )  # type: ignore[arg-type]
        pool.current = d.get("current", pool.value)
        return pool
    return Stat(
        base=d["base"],
        bonus=d.get("bonus", 0),
        abbreviation=abbr,
        bar_filled=bf,
        bar_empty=be,
    )  # type: ignore[arg-type]


def _build_snapshot_entity(
    snap_e: EntitySnapshot,
    cat_entry: dict,
    override: dict,
) -> _SnapshotEntity:
    from faraway_realms.combat.abilities import ABILITY_REGISTRY
    from faraway_realms.entities.components import CombatProfile

    abilities = {
        name: ABILITY_REGISTRY.get(name) for name in cat_entry.get("abilities", [])
    }
    stats = {k: _deserialize_stat(v) for k, v in snap_e.stats.items()}
    raw_bc = cat_entry.get("blood_color")
    blood: tuple[int, int, int] | None = tuple(raw_bc) if raw_bc else None  # type: ignore[assignment]
    components: dict[str, Any] = {"combat_profile": CombatProfile(blood_color=blood)}
    raw_fg = override.get("fg_color") or cat_entry.get("fg_color") or [255, 255, 255]
    return _SnapshotEntity(
        entity_id=snap_e.entity_id,
        char=cat_entry.get("char", ord("?")),
        fg_color=tuple(raw_fg),  # type: ignore[arg-type]
        faction=cat_entry.get("faction", "neutral"),
        target_id=snap_e.target_id,
        abilities=abilities,  # type: ignore[arg-type]
        stats=stats,
        components=components,
        type_id=snap_e.type_id,
        _display_name_val=override.get("display_name")
        or cat_entry.get("display_name", "?"),
    )


def _statuses_from_dicts(
    dicts: list[dict[str, Any]],
) -> list[StatusInstance]:
    return [
        StatusInstance(
            name=s["name"],
            expires_at=s["expires_at"],
            immobilize=s.get("immobilize", False),
            stun=s.get("stun", False),
            haste=s.get("haste", 1.0),
        )
        for s in dicts
    ]


class ClientGame:
    """GameProtocol implementation backed by a NetworkClient.

    Parameters
    ----------
    client : NetworkClient
        The network client providing tick snapshots.
    game_map : Map
        Static map tiles (never change; received in welcome message).
    tick_rate : float
        Server tick rate (from welcome or default).
    initial_static_objects : list[dict] | None
        Raw static-object dicts from the welcome message (sent once).
    """

    def __init__(
        self,
        client: NetworkClient,
        game_map: Map,
        tick_rate: float = 10.0,
        initial_static_objects: list[dict] | None = None,
        ambient: float = 0.35,
        fog_params: FogParams | None = None,
        type_catalogue: dict[str, dict] | None = None,
    ) -> None:
        self._client = client
        self._game_map = game_map
        self._tick_rate = tick_rate
        self._ambient = ambient
        self._fog_params = fog_params if fog_params is not None else FogParams()
        self._type_catalogue: dict[str, dict] = type_catalogue or {}
        self._entities_cache: dict[int, _SnapshotEntity] = {}
        self._chat_cache: list[ChatMessage] = []
        self._static_objects_cache: list[StaticObject] = [
            StaticObject(
                x=o["x"],
                y=o["y"],
                char=o["char"],
                fg_color=tuple(o["fg_color"]),  # type: ignore[arg-type]
            )
            for o in (initial_static_objects or [])
        ]

    # ------------------------------------------------------------------
    # GameProtocol properties
    # ------------------------------------------------------------------

    @property
    def abs_tick(self) -> int:
        """Return the current absolute tick from the latest snapshot."""
        snap = self._client.latest_snapshot()
        return snap.abs_tick if snap is not None else 0

    @property
    def game_map(self) -> Map:
        """Return the static map (tile data never changes)."""
        self._sync_entity_positions()
        return self._game_map

    @property
    def active_projectiles(self) -> list[Projectile]:
        """Return in-flight projectiles from the latest snapshot."""
        snap = self._client.latest_snapshot()
        if snap is None:
            return []  # type: ignore[return-value]
        projectiles: list[Projectile] = []
        for p in snap.projectiles:
            projectiles.append(  # type: ignore[arg-type]
                _ClientProjectile(
                    x=p["x"],
                    y=p["y"],
                    color=tuple(p["color"]),  # type: ignore[arg-type]
                    trail=deque(tuple(pos) for pos in p.get("trail", [])),
                    trail_char=p.get("trail_char", "+"),
                )
            )
        return projectiles

    @property
    def static_objects(self) -> list[StaticObject]:
        """Return static objects (initialised once from welcome message)."""
        return self._static_objects_cache

    @property
    def faction_relations(self) -> FactionRelations:
        """Return a default FactionRelations (client has no combat logic)."""
        return FactionRelations()

    def entity_catalogue(self) -> dict[str, dict]:
        """Return the static type catalogue received from the server."""
        return self._type_catalogue

    @property
    def tick_rate(self) -> float:
        """Server tick rate."""
        return self._tick_rate

    @property
    def ambient(self) -> float:
        """Ambient light level received from the server welcome message."""
        return self._ambient

    @property
    def fog_params(self) -> FogParams:
        """Fog parameters received from the server welcome message."""
        return self._fog_params

    # ------------------------------------------------------------------
    # Entity access
    # ------------------------------------------------------------------

    def all_player_entities(self) -> list[GameEntity]:
        """Return all player entities from the latest snapshot."""
        snap = self._client.latest_snapshot()
        if snap is None:
            return []
        entity_types = self._type_catalogue.get("entity_types", {})
        return [
            self._get_or_update_entity(e)
            for e in snap.entities
            if entity_types.get(e.type_id, {}).get("is_player", False)
        ]

    def all_npcs(self) -> list[Entity]:
        """Return all NPC entities from the latest snapshot."""
        from typing import cast

        snap = self._client.latest_snapshot()
        if snap is None:
            return []
        entity_types = self._type_catalogue.get("entity_types", {})
        entities = [
            self._get_or_update_entity(e)
            for e in snap.entities
            if not entity_types.get(e.type_id, {}).get("is_player", False)
        ]
        return cast(list[Entity], entities)

    def entity(self, entity_id: int) -> GameEntity | None:
        """Return entity by ID from the latest snapshot."""
        snap = self._client.latest_snapshot()
        if snap is None:
            return None
        for e in snap.entities:
            if e.entity_id == entity_id:
                return self._get_or_update_entity(e)
        return None

    # ------------------------------------------------------------------
    # Animation queries (pure state-read, no drain)
    # ------------------------------------------------------------------

    def melee_anim_events(
        self,
    ) -> list[
        tuple[
            tuple[int, int],
            tuple[int, int],
            tuple[int, int, int],
            tuple[int, int, int] | None,
        ]
    ]:
        """Return ``(attacker_pos, target_pos, color, blood_color)`` for each hit."""
        snap = self._client.latest_snapshot()
        if snap is None:
            return []
        return [
            (tuple(a[0]), tuple(a[1]), tuple(a[2]), tuple(a[3]) if a[3] else None)
            for a in snap.melee_animations
        ]

    def movement_trail_events(
        self,
    ) -> list[tuple[int, int, tuple[int, int, int], list[tuple[int, int]]]]:
        """Return ``(entity_id, char, fg_color, path)`` for each push trail."""
        snap = self._client.latest_snapshot()
        if snap is None:
            return []
        return [
            (t[0], t[1], tuple(t[2]), [(p[0], p[1]) for p in t[3]])  # type: ignore[misc]
            for t in snap.movement_trails
        ]

    # ------------------------------------------------------------------
    # Cooldown / status queries
    # ------------------------------------------------------------------

    def _snap_fraction(self, entity_id: int, own_attr: str, target_attr: str, default):
        snap = self._client.latest_snapshot()
        if snap is None:
            return default
        if entity_id == snap.target_entity_id:
            return getattr(snap, target_attr)
        return getattr(snap, own_attr)

    def attack_cooldown_fraction(self, entity_id: int) -> float:
        """Return pre-computed cooldown fraction from snapshot."""
        return self._snap_fraction(
            entity_id, "attack_cooldown_fraction", "target_attack_fraction", 0.0
        )

    def gcd_fraction(self, entity_id: int) -> float | None:
        """Return pre-computed GCD fraction from snapshot."""
        return self._snap_fraction(
            entity_id, "gcd_fraction", "target_gcd_fraction", None
        )

    def cast_fraction(self, entity_id: int) -> float | None:
        """Return pre-computed cast fraction from snapshot."""
        return self._snap_fraction(
            entity_id, "cast_fraction", "target_cast_fraction", None
        )

    def ability_cooldown_fraction(
        self,
        entity_id: int,
        ability_name: str,  # noqa: ARG002
    ) -> float:
        """Return ability cooldown fraction from snapshot."""
        snap = self._client.latest_snapshot()
        if snap is None:
            return 0.0
        return snap.ability_cooldowns.get(ability_name) or 0.0

    def active_statuses(self, entity_id: int) -> list[StatusInstance]:
        """Return status effects for entity from snapshot."""
        snap = self._client.latest_snapshot()
        if snap is None:
            return []
        for e in snap.entities:
            if e.entity_id == entity_id:
                return _statuses_from_dicts(e.status_effects)
        return []

    def has_active_status(self, entity_id: int, status_name: str) -> bool:
        """Return True when entity has the named status."""
        return any(s.name == status_name for s in self.active_statuses(entity_id))

    def get_chat_history(self, last_n: int = 20) -> list[ChatMessage]:
        """Return chat messages, accumulating server-side deltas each call."""
        snap = self._client.latest_snapshot()
        if snap is not None and snap.chat_messages:
            for m in snap.chat_messages:
                self._chat_cache.append(
                    ChatMessage(
                        text=m["text"],
                        color=tuple(m["color"]),  # type: ignore[arg-type]
                    )
                )
            snap.chat_messages.clear()
        return self._chat_cache[-last_n:]

    def get_hit_seq(self, entity_id: int) -> int:  # noqa: ARG002
        """Return the hit sequence counter from the latest snapshot."""
        snap = self._client.latest_snapshot()
        return snap.hit_seq if snap is not None else 0

    def get_crit_dealt_seq(self, entity_id: int) -> int:  # noqa: ARG002
        """Return the crit-dealt sequence counter from the latest snapshot."""
        snap = self._client.latest_snapshot()
        return snap.crit_dealt_seq if snap is not None else 0

    def light_sources(self) -> list[tuple[int, int, LightSource]]:
        """Return light sources from the latest snapshot."""
        snap = self._client.latest_snapshot()
        if snap is None:
            return []
        from faraway_realms.net.serialization import _deser_animation  # noqa: PLC0415

        result = []
        for src in snap.light_sources:
            x, y, radius, intensity, color = src[:5]
            anim_data = src[5] if len(src) > 5 else None
            ls = LightSource(
                radius=radius,
                intensity=intensity,
                color=tuple(color),  # type: ignore[arg-type]
                animation=_deser_animation(anim_data),
            )
            result.append((x, y, ls))
        return result

    def death_payload(self) -> dict | None:
        """Return the death message payload from the server, or None if alive."""
        return self._client.death_payload()

    def is_player_dead(self) -> bool:
        """Return True once the server has sent a death message for this session."""
        return self._client.death_payload() is not None

    def add_chat_message(
        self,
        message: str,
        color: tuple[int, int, int] = (200, 200, 200),
    ) -> None:
        """No-op on client; chat is server-authoritative."""

    def enqueue_command(self, command: Command) -> None:
        """Send command to the server via the network client."""
        self._client.send_command(command)

    # ------------------------------------------------------------------
    # Internal sync helpers
    # ------------------------------------------------------------------

    def _get_or_update_entity(self, snap_e: EntitySnapshot) -> _SnapshotEntity:
        eid = snap_e.entity_id
        cat_entry = self._type_catalogue.get("entity_types", {}).get(snap_e.type_id, {})
        override = self._client.player_overrides().get(str(eid), {})
        existing = self._entities_cache.get(eid)
        if existing is None:
            existing = _build_snapshot_entity(snap_e, cat_entry, override)
            self._entities_cache[eid] = existing
        else:
            existing.target_id = snap_e.target_id
            existing.stats = {k: _deserialize_stat(v) for k, v in snap_e.stats.items()}
            existing.last_hit_tick = snap_e.last_hit_tick
            existing.last_hit_by = snap_e.last_hit_by
            if override:
                self._apply_override(existing, override)
        return existing

    def _apply_override(self, existing: _SnapshotEntity, override: dict) -> None:
        raw_fg = override.get("fg_color")
        if raw_fg:
            existing.fg_color = tuple(raw_fg)  # type: ignore[assignment]
        dn = override.get("display_name")
        if dn:
            existing._display_name_val = dn  # noqa: SLF001

    def _apply_tile_reveals(self, tile_reveals: list[dict]) -> None:
        for cell in tile_reveals:
            self._game_map.set_tile(
                cell["x"],
                cell["y"],
                Tile(
                    walkable=cell["walkable"],
                    char=cell.get("char", ord(".")),
                    fg_color=tuple(cell["fg"]),  # type: ignore[arg-type]
                    bg_color=tuple(cell["bg"]),  # type: ignore[arg-type]
                ),
            )
            zone = cell.get("zone_name")
            if zone:
                self._game_map.tile_zones[(cell["x"], cell["y"])] = zone
            tile_type_id = cell.get("tile_type_id")
            if tile_type_id:
                self._game_map.tile_type_ids[(cell["x"], cell["y"])] = tile_type_id

    def _sync_entity_positions(self) -> None:
        snap = self._client.latest_snapshot()
        if snap is None:
            return
        for eid in snap.removed_entity_ids:
            self._entities_cache.pop(eid, None)
        snap.removed_entity_ids.clear()
        self._apply_tile_reveals(snap.tile_reveals)
        snap.tile_reveals.clear()
        self._apply_tile_reveals(snap.tile_updates)
        snap.tile_updates.clear()
        self._apply_static_object_reveals(snap.static_object_reveals)
        snap.static_object_reveals.clear()
        self._clear_entity_positions()
        self._place_snapshot_entities(snap.entities)

    def _apply_static_object_reveals(self, reveals: list[dict]) -> None:
        existing = {(o.x, o.y) for o in self._static_objects_cache}
        for o in reveals:
            if (o["x"], o["y"]) not in existing:
                self._static_objects_cache.append(
                    StaticObject(
                        x=o["x"],
                        y=o["y"],
                        char=o["char"],
                        fg_color=tuple(o["fg_color"]),  # type: ignore[arg-type]
                        type_id=o.get("type_id", ""),
                    )
                )

    def _clear_entity_positions(self) -> None:
        for eid in list(self._game_map.get_all_positions()):
            self._game_map.remove_entity(eid)

    def _place_snapshot_entities(self, entities: list) -> None:
        for e in entities:
            if e.x >= 0 and e.y >= 0:
                self._game_map.place_entity(e.entity_id, e.x, e.y)
