"""Unit tests for the YAML keybind loader and event matcher."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock

import pytest
import tcod.event

from faraway_realms.ui.keybinds import (
    _SHIFT_ALIASES,
    KeybindMap,
    load_keybinds,
    match_event,
    parse_key,
)

_SHIFT_VAL = int(tcod.event.Modifier.SHIFT)


# ---------------------------------------------------------------------------
# parse_key
# ---------------------------------------------------------------------------


def test_parse_key_simple_char() -> None:
    sym, mods = parse_key("e")
    assert sym == ord("e")
    assert mods == 0


def test_parse_key_named_key_left() -> None:
    sym, mods = parse_key("left")
    assert sym == int(tcod.event.KeySym.LEFT)
    assert mods == 0


def test_parse_key_tab() -> None:
    sym, mods = parse_key("tab")
    assert sym == int(tcod.event.KeySym.TAB)
    assert mods == 0


def test_parse_key_pageup() -> None:
    sym, mods = parse_key("pageup")
    assert sym == int(tcod.event.KeySym.PAGEUP)
    assert mods == 0


def test_parse_key_shift_explicit() -> None:
    sym, mods = parse_key("shift+e")
    assert sym == ord("e")
    assert mods == _SHIFT_VAL


def test_parse_key_natural_question_mark() -> None:
    sym, mods = parse_key("?")
    assert sym == int(tcod.event.KeySym.QUESTION)
    assert mods == 0


def test_parse_key_natural_lbrace() -> None:
    sym, mods = parse_key("{")
    assert sym == ord("{")
    assert mods == 0


def test_parse_key_slash_shift_equivalent() -> None:
    # shift+/ and ? should parse to different canonical forms but the
    # alias table bridges them at match time.
    slash_shift = parse_key("shift+/")
    assert slash_shift == (int(tcod.event.KeySym.SLASH), _SHIFT_VAL)
    question = parse_key("?")
    assert question == (int(tcod.event.KeySym.QUESTION), 0)
    # They should be in the alias table
    assert _SHIFT_ALIASES.get(slash_shift) == question


def test_parse_key_unknown_raises() -> None:
    with pytest.raises(ValueError, match="Unknown key name"):
        parse_key("banana")


# ---------------------------------------------------------------------------
# match_event helpers
# ---------------------------------------------------------------------------


def _make_event(sym: tcod.event.KeySym, mod: int = 0) -> tcod.event.KeyDown:
    ev = MagicMock(spec=tcod.event.KeyDown)
    ev.sym = sym
    ev.mod = mod
    return ev


# ---------------------------------------------------------------------------
# match_event
# ---------------------------------------------------------------------------


def test_match_event_direct() -> None:
    km: KeybindMap = {(int(tcod.event.KeySym.QUESTION), 0): ":help"}
    ev = _make_event(tcod.event.KeySym.QUESTION, 0)
    assert match_event(km, ev) == ":help"


def test_match_event_slash_shift_alias_matches_question_binding() -> None:
    km: KeybindMap = {(int(tcod.event.KeySym.QUESTION), 0): ":help"}
    ev = _make_event(tcod.event.KeySym.SLASH, _SHIFT_VAL)
    assert match_event(km, ev) == ":help"


def test_match_event_lbrace_alias() -> None:
    km: KeybindMap = {(ord("{"), 0): ":scroll_up"}
    ev = _make_event(tcod.event.KeySym.LEFTBRACKET, _SHIFT_VAL)
    assert match_event(km, ev) == ":scroll_up"


def test_match_event_rbrace_alias() -> None:
    km: KeybindMap = {(ord("}"), 0): ":scroll_down"}
    ev = _make_event(tcod.event.KeySym.RIGHTBRACKET, _SHIFT_VAL)
    assert match_event(km, ev) == ":scroll_down"


def test_match_event_no_match_returns_none() -> None:
    km: KeybindMap = {(ord("e"), 0): "/cast kick @target"}
    ev = _make_event(tcod.event.KeySym(ord("z")), 0)
    assert match_event(km, ev) is None


def test_match_event_modifier_mismatch_returns_none() -> None:
    km: KeybindMap = {(ord("e"), 0): "/cast kick @target"}
    ev = _make_event(tcod.event.KeySym(ord("e")), _SHIFT_VAL)
    assert match_event(km, ev) is None


def test_match_event_strips_caps_lock() -> None:
    km: KeybindMap = {(ord("e"), 0): "/cast kick @target"}
    caps = int(tcod.event.Modifier.CAPS)
    ev = _make_event(tcod.event.KeySym(ord("e")), caps)
    assert match_event(km, ev) == "/cast kick @target"


# ---------------------------------------------------------------------------
# load_keybinds (integration with default.yaml)
# ---------------------------------------------------------------------------


def test_load_keybinds_global_movement() -> None:
    km = load_keybinds()
    assert km[(ord("h"), 0)] == "/move left"
    assert km[(ord("j"), 0)] == "/move down"
    assert km[(int(tcod.event.KeySym.LEFT), 0)] == "/move left"


def test_load_keybinds_global_ui_actions() -> None:
    km = load_keybinds()
    assert km[(int(tcod.event.KeySym.QUESTION), 0)] == ":help"
    assert km[(int(tcod.event.KeySym.SLASH), 0)] == ":chat"
    assert km[(ord("]"), 0)] == ":cycle_panel"
    assert km[(int(tcod.event.KeySym.PAGEUP), 0)] == ":scroll_up"
    assert km[(ord("{"), 0)] == ":scroll_up"


def test_load_keybinds_hero_preset() -> None:
    km = load_keybinds(preset="hero")
    assert km[(ord("e"), 0)] == "/cast kick @target"
    # Global keys still present
    assert km[(ord("h"), 0)] == "/move left"


def test_load_keybinds_no_preset_no_ability_keys() -> None:
    km = load_keybinds()
    # Without a preset, "e" is not bound
    assert (ord("e"), 0) not in km


def test_load_keybinds_user_override(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    user_file = tmp_path / "keybinds.yaml"
    user_file.write_text("global:\n  h: /move right\n", encoding="utf-8")
    monkeypatch.setattr("faraway_realms.ui.keybinds._USER_PATH", user_file)
    km = load_keybinds()
    assert km[(ord("h"), 0)] == "/move right"
    # Other global keys unaffected
    assert km[(ord("j"), 0)] == "/move down"
