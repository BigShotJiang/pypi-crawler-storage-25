"""Tests for TextInput widget, ConnectionSettings, and JoinServerScreen."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest
import tcod.console
import tcod.event

from faraway_realms.settings import (
    ConnectionSettings,
    load_connection_settings,
    save_connection_settings,
)
from faraway_realms.ui.app_loop import AppState
from faraway_realms.ui.join_server_screen import _PALETTE, JoinServerScreen
from faraway_realms.ui.text_input import TextInput

# ---------------------------------------------------------------------------
# TextInput
# ---------------------------------------------------------------------------


def _backspace_event() -> tcod.event.KeyDown:
    ev = MagicMock(spec=tcod.event.KeyDown)
    ev.sym = tcod.event.KeySym.BACKSPACE
    return ev


def _other_key_event() -> tcod.event.KeyDown:
    ev = MagicMock(spec=tcod.event.KeyDown)
    ev.sym = tcod.event.KeySym.RETURN
    return ev


def _text_event(text: str) -> tcod.event.TextInput:
    ev = MagicMock(spec=tcod.event.TextInput)
    ev.text = text
    return ev


class TestTextInput:
    def test_backspace_removes_last_char(self) -> None:
        ti = TextInput()
        ti.buffer = "abc"
        consumed = ti.handle_key(_backspace_event())
        assert consumed is True
        assert ti.buffer == "ab"

    def test_backspace_on_empty_is_safe(self) -> None:
        ti = TextInput()
        ti.handle_key(_backspace_event())
        assert ti.buffer == ""

    def test_other_key_not_consumed(self) -> None:
        ti = TextInput()
        consumed = ti.handle_key(_other_key_event())
        assert consumed is False

    def test_handle_text_appends(self) -> None:
        ti = TextInput()
        ti.handle_text(_text_event("hi"))
        assert ti.buffer == "hi"

    def test_handle_text_respects_max_len(self) -> None:
        ti = TextInput(max_len=3)
        ti.buffer = "ab"
        ti.handle_text(_text_event("cde"))
        assert ti.buffer == "abc"

    def test_render_focused_shows_cursor(self) -> None:
        ti = TextInput()
        ti.buffer = "ab"
        console = MagicMock(spec=tcod.console.Console)
        ti.render(console, 0, 0, 10, focused=True, fg=(255, 255, 255))
        printed = console.print.call_args[0][2]
        assert "_" in printed

    def test_render_unfocused_no_cursor(self) -> None:
        ti = TextInput()
        ti.buffer = "ab"
        console = MagicMock(spec=tcod.console.Console)
        ti.render(console, 0, 0, 10, focused=False, fg=(255, 255, 255))
        printed = console.print.call_args[0][2]
        assert "_" not in printed

    def test_start_stop_input_with_sdl_window(self) -> None:
        ctx = MagicMock()
        TextInput.start_input(ctx)
        ctx.sdl_window.start_text_input.assert_called_once()
        TextInput.stop_input(ctx)
        ctx.sdl_window.stop_text_input.assert_called_once()

    def test_start_stop_input_without_sdl_window(self) -> None:
        ctx = MagicMock()
        ctx.sdl_window = None
        TextInput.start_input(ctx)
        TextInput.stop_input(ctx)


# ---------------------------------------------------------------------------
# ConnectionSettings
# ---------------------------------------------------------------------------


class TestConnectionSettings:
    def test_defaults(self) -> None:
        cs = ConnectionSettings()
        assert cs.default_host == "localhost"
        assert cs.default_port == 9999
        assert cs.last_username == "player1"
        assert cs.last_char_name == ""
        assert cs.last_color_idx == 0
        assert cs.recent_servers == ()

    def test_save_and_load_roundtrip(self, tmp_path: pytest.FixtureRequest) -> None:
        settings_file = tmp_path / "settings.yaml"
        with (
            patch("faraway_realms.settings._USER_SETTINGS", settings_file),
            patch("faraway_realms.settings._DATA_SETTINGS", settings_file),
        ):
            save_connection_settings(
                "myhost",
                1234,
                "alice",
                "Alyssa",
                2,
                [("myhost", 1234), ("other", 5678)],
            )
            cs = load_connection_settings()

        assert cs.default_host == "myhost"
        assert cs.default_port == 1234
        assert cs.last_username == "alice"
        assert cs.last_char_name == "Alyssa"
        assert cs.last_color_idx == 2
        assert cs.recent_servers == (("myhost", 1234), ("other", 5678))

    def test_recent_servers_capped_at_five(
        self, tmp_path: pytest.FixtureRequest
    ) -> None:
        settings_file = tmp_path / "settings.yaml"
        many = [(f"host{i}", 9000 + i) for i in range(8)]
        with (
            patch("faraway_realms.settings._USER_SETTINGS", settings_file),
            patch("faraway_realms.settings._DATA_SETTINGS", settings_file),
        ):
            save_connection_settings("h", 1, "u", "c", 0, many)
            cs = load_connection_settings()

        assert len(cs.recent_servers) == 5

    def test_load_with_missing_user_file(self, tmp_path: pytest.FixtureRequest) -> None:
        missing = tmp_path / "missing.yaml"
        with (
            patch("faraway_realms.settings._USER_SETTINGS", missing),
            patch("faraway_realms.settings._DATA_SETTINGS", missing),
        ):
            cs = load_connection_settings()
        assert cs == ConnectionSettings()


# ---------------------------------------------------------------------------
# JoinServerScreen helpers
# ---------------------------------------------------------------------------


def _make_screen(recent: list[tuple[str, int]] | None = None) -> JoinServerScreen:
    ctx = MagicMock()
    connect_fn = MagicMock()
    conn = ConnectionSettings(
        default_host="localhost",
        default_port=9999,
        last_username="tester",
        last_char_name="Hero",
        last_color_idx=0,
        recent_servers=tuple(recent or []),
    )
    return JoinServerScreen(ctx, connect_fn, conn)


def _key(sym: tcod.event.KeySym) -> tcod.event.KeyDown:
    ev = MagicMock(spec=tcod.event.KeyDown)
    ev.sym = sym
    ev.mod = tcod.event.Modifier.NONE
    return ev


# ---------------------------------------------------------------------------
# JoinServerScreen: init pre-fills
# ---------------------------------------------------------------------------


class TestJoinServerScreenInit:
    def test_prefills_from_defaults_when_no_recent(self) -> None:
        s = _make_screen()
        assert s._host.buffer == "localhost"  # noqa: SLF001
        assert s._port.buffer == "9999"  # noqa: SLF001

    def test_prefills_from_recent_when_available(self) -> None:
        s = _make_screen(recent=[("remotehost", 1234)])
        assert s._host.buffer == "remotehost"  # noqa: SLF001
        assert s._port.buffer == "1234"  # noqa: SLF001

    def test_prefills_username_and_charname(self) -> None:
        s = _make_screen()
        assert s._username.buffer == "tester"  # noqa: SLF001
        assert s._charname.buffer == "Hero"  # noqa: SLF001


# ---------------------------------------------------------------------------
# JoinServerScreen: navigation
# ---------------------------------------------------------------------------


class TestJoinServerScreenNav:
    def test_down_advances_focus(self) -> None:
        s = _make_screen()
        assert s._focus == 0  # noqa: SLF001
        s.handle_event(_key(tcod.event.KeySym.DOWN))
        assert s._focus == 1  # noqa: SLF001

    def test_up_retreats_focus(self) -> None:
        s = _make_screen()
        s._focus = 2  # noqa: SLF001
        s.handle_event(_key(tcod.event.KeySym.UP))
        assert s._focus == 1  # noqa: SLF001

    def test_j_navigates_on_non_text_focus(self) -> None:
        s = _make_screen()
        s._focus = 4  # color row — not a text field  # noqa: SLF001
        s.handle_event(_key(tcod.event.KeySym(ord("j"))))
        assert s._focus == 5  # noqa: SLF001

    def test_k_navigates_on_non_text_focus(self) -> None:
        s = _make_screen()
        s._focus = 4  # color row — not a text field  # noqa: SLF001
        s.handle_event(_key(tcod.event.KeySym(ord("k"))))
        assert s._focus == 3  # noqa: SLF001

    def test_j_does_not_steal_input_on_text_field(self) -> None:
        s = _make_screen()
        s._focus = 0  # Host text field  # noqa: SLF001
        s.handle_event(_key(tcod.event.KeySym(ord("j"))))
        assert s._focus == 0  # focus unchanged  # noqa: SLF001

    def test_k_does_not_steal_input_on_text_field(self) -> None:
        s = _make_screen()
        s._focus = 2  # Username text field  # noqa: SLF001
        s.handle_event(_key(tcod.event.KeySym(ord("k"))))
        assert s._focus == 2  # focus unchanged  # noqa: SLF001

    def test_focus_wraps_forward(self) -> None:
        s = _make_screen()
        total = s._total_foci  # noqa: SLF001
        s._focus = total - 1  # noqa: SLF001
        s.handle_event(_key(tcod.event.KeySym.DOWN))
        assert s._focus == 0  # noqa: SLF001

    def test_escape_returns_main_menu(self) -> None:
        s = _make_screen()
        result = s.handle_event(_key(tcod.event.KeySym.ESCAPE))
        assert result == AppState.MAIN_MENU

    def test_quit_event_returns_quitting(self) -> None:
        s = _make_screen()
        result = s.handle_event(MagicMock(spec=tcod.event.Quit))
        assert result == AppState.QUITTING


# ---------------------------------------------------------------------------
# JoinServerScreen: color cycling
# ---------------------------------------------------------------------------


class TestJoinServerScreenColor:
    def test_right_cycles_color_forward(self) -> None:
        s = _make_screen()
        s._focus = 4  # _FOCUS_COLOR  # noqa: SLF001
        s._color_idx = 0  # noqa: SLF001
        s.handle_event(_key(tcod.event.KeySym.RIGHT))
        assert s._color_idx == 1  # noqa: SLF001

    def test_left_cycles_color_backward(self) -> None:
        s = _make_screen()
        s._focus = 4  # noqa: SLF001
        s._color_idx = 0  # noqa: SLF001
        s.handle_event(_key(tcod.event.KeySym.LEFT))
        assert s._color_idx == len(_PALETTE) - 1  # noqa: SLF001


# ---------------------------------------------------------------------------
# JoinServerScreen: recent server selection
# ---------------------------------------------------------------------------


class TestJoinServerScreenRecent:
    def test_enter_on_recent_prefills_host_port(self) -> None:
        s = _make_screen(recent=[("srv1", 8080), ("srv2", 9090)])
        s._focus = 5  # _FOCUS_RECENT_BASE + 0  # noqa: SLF001
        s.handle_event(_key(tcod.event.KeySym.RETURN))
        assert s._host.buffer == "srv1"  # noqa: SLF001
        assert s._port.buffer == "8080"  # noqa: SLF001
        assert s._focus == 2  # jumped to _FOCUS_USERNAME  # noqa: SLF001


# ---------------------------------------------------------------------------
# JoinServerScreen: validation and connection
# ---------------------------------------------------------------------------


class TestJoinServerScreenConnect:
    def test_empty_host_shows_error(self) -> None:
        s = _make_screen()
        s._host.buffer = ""  # noqa: SLF001
        s._focus = s._focus_connect  # noqa: SLF001
        result = s.handle_event(_key(tcod.event.KeySym.RETURN))
        assert result is None
        assert s._error is not None  # noqa: SLF001

    def test_non_digit_port_shows_error(self) -> None:
        s = _make_screen()
        s._port.buffer = "abc"  # noqa: SLF001
        s._focus = s._focus_connect  # noqa: SLF001
        s.handle_event(_key(tcod.event.KeySym.RETURN))
        assert s._error is not None  # noqa: SLF001

    def test_successful_connect_returns_in_game(self) -> None:
        ctx = MagicMock()
        connect_fn = MagicMock()
        conn = ConnectionSettings(default_host="localhost", default_port=9999)
        s = JoinServerScreen(ctx, connect_fn, conn)
        s._focus = s._focus_connect  # noqa: SLF001
        result = s.handle_event(_key(tcod.event.KeySym.RETURN))
        assert result == AppState.IN_GAME
        connect_fn.assert_called_once()

    def test_connect_error_shows_message(self) -> None:
        ctx = MagicMock()
        connect_fn = MagicMock(side_effect=OSError("refused"))
        conn = ConnectionSettings(default_host="localhost", default_port=9999)
        s = JoinServerScreen(ctx, connect_fn, conn)
        s._focus = s._focus_connect  # noqa: SLF001
        result = s.handle_event(_key(tcod.event.KeySym.RETURN))
        assert result is None
        assert "refused" in s._error  # noqa: SLF001


# ---------------------------------------------------------------------------
# MainMenuScreen routing
# ---------------------------------------------------------------------------


class TestMainMenuScreenRouting:
    def _enter(self) -> tcod.event.KeyDown:
        return _key(tcod.event.KeySym.RETURN)

    def _down(self) -> tcod.event.KeyDown:
        return _key(tcod.event.KeySym.DOWN)

    def test_play_returns_character_select(self) -> None:
        from faraway_realms.ui.main_menu_screen import MainMenuScreen

        s = MainMenuScreen()
        result = s.handle_event(self._enter())
        assert result == AppState.CHARACTER_SELECT

    def test_join_server_returns_join_server_state(self) -> None:
        from faraway_realms.ui.main_menu_screen import MainMenuScreen

        s = MainMenuScreen()
        s.handle_event(self._down())
        result = s.handle_event(self._enter())
        assert result == AppState.JOIN_SERVER

    def test_settings_returns_settings_state(self) -> None:
        from faraway_realms.ui.main_menu_screen import MainMenuScreen

        s = MainMenuScreen()
        s.handle_event(self._down())
        s.handle_event(self._down())
        result = s.handle_event(self._enter())
        assert result == AppState.SETTINGS

    def test_quit_returns_quitting(self) -> None:
        from faraway_realms.ui.main_menu_screen import MainMenuScreen

        s = MainMenuScreen()
        for _ in range(3):
            s.handle_event(self._down())
        result = s.handle_event(self._enter())
        assert result == AppState.QUITTING
