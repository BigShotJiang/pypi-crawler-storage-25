"""Integration tests: GameServer + raw TCP client over real localhost sockets.

These tests verify the full server pipeline: game tick → serialization →
msgpack framing → TCP → deserialization, plus the command path back from
client to server.  A minimal 10×10 map is used so tests run fast and FOV
always covers the entire interior.
"""

from __future__ import annotations

import asyncio

import pytest
import pytest_asyncio

from faraway_realms.game import Game
from faraway_realms.net.protocol import recv_message, send_message
from faraway_realms.net.server import GameServer
from faraway_realms.world.factions import FACTION_RELATIONS
from faraway_realms.world.map import make_bordered_map

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

# 10×10 map: 8×8 walkable interior; max diagonal ≈ 11 tiles — always within
# the server's sight range of 12 so all players are visible to each other.
_MAP_W = 10
_MAP_H = 10


def _make_test_game(tick_rate: float = 50.0) -> Game:
    """Minimal game suitable for integration tests."""
    game_map = make_bordered_map(_MAP_W, _MAP_H)
    # Restrict spawn to the inner area (2 tiles from each border) so the player
    # always has room to move in any cardinal direction — prevents flaky test
    # failures when the player spawns adjacent to the border wall.
    spawn_tiles = [
        (x, y)
        for y in range(2, _MAP_H - 2)
        for x in range(2, _MAP_W - 2)
        if game_map.is_walkable(x, y)
    ]
    return Game(
        game_map=game_map,
        faction_relations=FACTION_RELATIONS,
        player_spawn_tiles=spawn_tiles,
        tick_rate=tick_rate,
    )


async def _auth_payload(
    uuid: str = "test-uuid",
    username: str = "player",
    char_name: str = "Tester",
    color: list[int] | None = None,
) -> dict:
    return {
        "type": "auth",
        "uuid": uuid,
        "username": username,
        "char_name": char_name,
        "color": color if color is not None else [200, 200, 200],
    }


async def _connect(port: int) -> tuple[asyncio.StreamReader, asyncio.StreamWriter]:
    return await asyncio.open_connection("localhost", port)


async def _connect_and_auth(
    port: int,
    uuid: str = "test-uuid",
    username: str = "player",
    char_name: str = "Tester",
    color: list[int] | None = None,
) -> tuple[asyncio.StreamReader, asyncio.StreamWriter, dict]:
    """Open connection, send auth, receive welcome (or error) message."""
    reader, writer = await _connect(port)
    await send_message(writer, await _auth_payload(uuid, username, char_name, color))
    msg = await asyncio.wait_for(recv_message(reader), timeout=2.0)
    return reader, writer, msg


async def _recv_tick(reader: asyncio.StreamReader, timeout: float = 2.0) -> dict:
    """Read messages from *reader* until a ``'tick'`` message arrives."""
    while True:
        msg = await asyncio.wait_for(recv_message(reader), timeout=timeout)
        if msg.get("type") == "tick":
            return msg


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


async def _make_server(game: Game) -> GameServer:
    """Start a GameServer and wait for it to bind. Caller cancels tasks."""
    srv = GameServer(game, "localhost", 0)
    asyncio.create_task(srv.run())
    await asyncio.sleep(0.05)
    return srv


async def _teardown_server() -> None:
    pending = [t for t in asyncio.all_tasks() if t is not asyncio.current_task()]
    for t in pending:
        t.cancel()
    await asyncio.gather(*pending, return_exceptions=True)


@pytest_asyncio.fixture
async def server():
    """Spin up a real GameServer on localhost:0; yield it; cancel on teardown."""
    srv = await _make_server(_make_test_game())
    yield srv
    await _teardown_server()


@pytest_asyncio.fixture
async def server_two_players():
    """GameServer with alpha at (2,2) and beta at (7,7) — guaranteed non-adjacent.

    Tests that assert individual movement must use this fixture rather than
    ``server`` so that random spawn placement never puts one player in the
    path of the other's move direction.
    """
    from faraway_realms.entities.character_type import CHARACTER_REGISTRY
    from faraway_realms.entities.entity import Player

    game = _make_test_game()
    for username, eid, x, y in (
        ("alpha", 1000, 2, 2),
        ("beta", 1001, 7, 7),
    ):
        entity = CHARACTER_REGISTRY["hero"].to_entity(entity_id=eid)
        entity.name = username.capitalize()
        game.add_player(Player(username=username, entity=entity))
        game.game_map.place_entity(eid, x, y)
    srv = await _make_server(game)
    yield srv
    await _teardown_server()


@pytest_asyncio.fixture
async def server_prespawn():
    """GameServer with a pre-spawned host entity (mirrors _build_game in __main__)."""
    from faraway_realms.entities.character_type import CHARACTER_REGISTRY
    from faraway_realms.entities.entity import Player

    game = _make_test_game()
    host_entity = CHARACTER_REGISTRY["hero"].to_entity(entity_id=1)
    host_entity.name = "Host"
    host_entity.fg_color = (255, 255, 0)
    game.add_player(Player(username="player1", entity=host_entity))
    game.game_map.place_entity(1, 5, 5)
    srv = await _make_server(game)
    yield srv
    await _teardown_server()


# ---------------------------------------------------------------------------
# Welcome message — structure and content
# ---------------------------------------------------------------------------


async def test_welcome_type(server):
    _, writer, welcome = await _connect_and_auth(server.bound_port)
    assert welcome.get("type") == "welcome"
    writer.close()


async def test_welcome_entity_id_is_positive_int(server):
    _, writer, welcome = await _connect_and_auth(server.bound_port)
    assert isinstance(welcome.get("entity_id"), int)
    assert welcome["entity_id"] > 0
    writer.close()


async def test_welcome_map_dimensions(server):
    _, writer, welcome = await _connect_and_auth(server.bound_port)
    assert welcome["map_width"] == _MAP_W
    assert welcome["map_height"] == _MAP_H
    writer.close()


async def test_welcome_map_tiles_non_empty(server):
    _, writer, welcome = await _connect_and_auth(server.bound_port)
    assert len(welcome.get("map_tiles", [])) > 0
    writer.close()


async def test_welcome_tile_has_expected_fields(server):
    _, writer, welcome = await _connect_and_auth(server.bound_port)
    tile = welcome["map_tiles"][0]
    for key in ("x", "y", "walkable", "char", "fg", "bg"):
        assert key in tile
    writer.close()


async def test_welcome_ambient_value(server):
    _, writer, welcome = await _connect_and_auth(server.bound_port)
    assert welcome["ambient"] == pytest.approx(0.35)
    writer.close()


async def test_welcome_fog_structure(server):
    _, writer, welcome = await _connect_and_auth(server.bound_port)
    fog = welcome.get("fog", {})
    for key in (
        "density",
        "scale",
        "wind_x",
        "wind_y",
        "color",
        "opacity_min",
        "opacity_max",
    ):
        assert key in fog, f"fog missing key {key!r}"
    assert len(fog["color"]) == 3
    writer.close()


# ---------------------------------------------------------------------------
# Tick snapshots — delivery and content
# ---------------------------------------------------------------------------


async def test_tick_snapshot_arrives(server):
    reader, writer, _ = await _connect_and_auth(server.bound_port)
    tick = await _recv_tick(reader)
    assert tick.get("type") == "tick"
    writer.close()


async def test_tick_abs_tick_is_monotonically_increasing(server):
    reader, writer, _ = await _connect_and_auth(server.bound_port)
    tick1 = await _recv_tick(reader)
    tick2 = await _recv_tick(reader)
    tick3 = await _recv_tick(reader)
    assert tick1["abs_tick"] < tick2["abs_tick"] < tick3["abs_tick"]
    writer.close()


async def test_tick_has_expected_top_level_keys(server):
    reader, writer, _ = await _connect_and_auth(server.bound_port)
    tick = await _recv_tick(reader)
    for key in (
        "abs_tick",
        "entities",
        "tile_reveals",
        "projectiles",
        "light_sources",
        "attack_cooldown_fraction",
    ):
        assert key in tick, f"tick snapshot missing key {key!r}"
    writer.close()


async def test_welcome_contains_initial_map_tiles(server):
    """Initial visible tiles are delivered in the welcome message as map_tiles."""
    _, writer, welcome = await _connect_and_auth(server.bound_port)
    assert len(welcome.get("map_tiles", [])) > 0
    writer.close()


async def test_stable_ticks_have_empty_tile_reveals(server):
    """When not moving, subsequent ticks should not re-reveal already-seen tiles."""
    reader, writer, _ = await _connect_and_auth(server.bound_port)
    # Skip the first tick (may still carry initial reveals from racing connects)
    await _recv_tick(reader)
    for _ in range(3):
        tick = await _recv_tick(reader)
        assert tick["tile_reveals"] == []
    writer.close()


# ---------------------------------------------------------------------------
# Player entity in snapshot
# ---------------------------------------------------------------------------


async def test_player_entity_appears_in_snapshot(server):
    reader, writer, welcome = await _connect_and_auth(server.bound_port)
    entity_id = welcome["entity_id"]
    tick = await _recv_tick(reader)
    ids = [e["entity_id"] for e in tick.get("entities", [])]
    assert entity_id in ids
    writer.close()


async def test_player_entity_has_is_player_true(server):
    reader, writer, welcome = await _connect_and_auth(server.bound_port)
    entity_id = welcome["entity_id"]
    tick = await _recv_tick(reader)
    entity = next(e for e in tick["entities"] if e["entity_id"] == entity_id)
    catalogue = welcome.get("type_catalogue", {})
    entity_type = catalogue.get("entity_types", {}).get(entity["type_id"], {})
    assert entity_type.get("is_player") is True
    writer.close()


async def test_player_entity_has_stats(server):
    reader, writer, welcome = await _connect_and_auth(server.bound_port)
    entity_id = welcome["entity_id"]
    tick = await _recv_tick(reader)
    entity = next(e for e in tick["entities"] if e["entity_id"] == entity_id)
    assert len(entity["stats"]) > 0
    writer.close()


async def test_player_entity_position_is_within_map(server):
    reader, writer, welcome = await _connect_and_auth(server.bound_port)
    entity_id = welcome["entity_id"]
    tick = await _recv_tick(reader)
    entity = next(e for e in tick["entities"] if e["entity_id"] == entity_id)
    assert 0 <= entity["x"] < _MAP_W
    assert 0 <= entity["y"] < _MAP_H
    writer.close()


# ---------------------------------------------------------------------------
# MOVE command — verifies command → game → snapshot pipeline
# ---------------------------------------------------------------------------


async def test_move_command_changes_player_position(server):
    """Send a single MOVE right; verify position in snapshot changes."""
    reader, writer, welcome = await _connect_and_auth(server.bound_port)
    entity_id = welcome["entity_id"]

    tick0 = await _recv_tick(reader)
    entity0 = next(e for e in tick0["entities"] if e["entity_id"] == entity_id)
    x0, y0 = entity0["x"], entity0["y"]

    # Interior is fully walkable; moving right always succeeds unless at border.
    await send_message(writer, {"type": "command", "raw": "/move right"})

    moved_entity = None
    for _ in range(20):
        tick = await _recv_tick(reader)
        ents = {e["entity_id"]: e for e in tick.get("entities", [])}
        if entity_id in ents:
            e = ents[entity_id]
            if (e["x"], e["y"]) != (x0, y0):
                moved_entity = e
                break

    assert moved_entity is not None, "Position never changed after MOVE right"
    writer.close()


async def test_move_command_position_stays_on_walkable_tile(server):
    """Player position must always be on a walkable tile after moving."""
    reader, writer, welcome = await _connect_and_auth(server.bound_port)
    entity_id = welcome["entity_id"]

    for direction in ("right", "down"):
        await send_message(writer, {"type": "command", "raw": f"/move {direction}"})
        await _recv_tick(reader)

    tick = await _recv_tick(reader)
    ents = {e["entity_id"]: e for e in tick.get("entities", [])}
    assert entity_id in ents
    x, y = ents[entity_id]["x"], ents[entity_id]["y"]
    assert server._game.game_map.is_walkable(x, y)
    writer.close()


# ---------------------------------------------------------------------------
# Two concurrent clients
# ---------------------------------------------------------------------------


async def test_two_clients_get_different_entity_ids(server):
    _, w1, welcome1 = await _connect_and_auth(
        server.bound_port, uuid="uuid-a", username="alpha"
    )
    _, w2, welcome2 = await _connect_and_auth(
        server.bound_port, uuid="uuid-b", username="beta"
    )
    assert welcome1["entity_id"] != welcome2["entity_id"]
    w1.close()
    w2.close()


async def test_two_clients_both_receive_ticks(server):
    r1, w1, _ = await _connect_and_auth(
        server.bound_port, uuid="uuid-a", username="alpha"
    )
    r2, w2, _ = await _connect_and_auth(
        server.bound_port, uuid="uuid-b", username="beta"
    )
    tick1 = await _recv_tick(r1)
    tick2 = await _recv_tick(r2)
    assert tick1["abs_tick"] >= 1
    assert tick2["abs_tick"] >= 1
    w1.close()
    w2.close()


async def test_two_clients_see_each_other(server):
    """On a 10×10 map the full interior is always within FOV sight range."""
    r1, w1, welcome1 = await _connect_and_auth(
        server.bound_port, uuid="uuid-a", username="alpha"
    )
    _, w2, welcome2 = await _connect_and_auth(
        server.bound_port, uuid="uuid-b", username="beta"
    )
    eid2 = welcome2["entity_id"]

    # Drain up to 15 ticks for both entities to appear in client-1's FOV.
    visible_ids: list[int] = []
    for _ in range(15):
        tick = await _recv_tick(r1)
        visible_ids = [e["entity_id"] for e in tick.get("entities", [])]
        if eid2 in visible_ids:
            break

    assert eid2 in visible_ids, "Second player never appeared in first player's FOV"
    w1.close()
    w2.close()


# ---------------------------------------------------------------------------
# Ping / pong
# ---------------------------------------------------------------------------


async def test_ping_pong_roundtrip(server):
    reader, writer, _ = await _connect_and_auth(server.bound_port)
    t_sent = 42.0
    await send_message(writer, {"type": "ping", "t": t_sent})
    pong = None
    for _ in range(30):
        msg = await asyncio.wait_for(recv_message(reader), timeout=2.0)
        if msg.get("type") == "pong":
            pong = msg
            break
    assert pong is not None
    assert pong["t"] == pytest.approx(t_sent)
    writer.close()


# ---------------------------------------------------------------------------
# Protocol error handling
# ---------------------------------------------------------------------------


async def test_wrong_auth_type_returns_error(server):
    reader, writer = await _connect(server.bound_port)
    await send_message(writer, {"type": "not_auth", "data": "nope"})
    response = await asyncio.wait_for(recv_message(reader), timeout=2.0)
    assert response["type"] == "error"
    assert "auth" in response["message"]
    writer.close()


async def test_server_full_returns_error():
    """A server with max_clients=1 rejects the second client."""
    game = _make_test_game()
    srv = GameServer(game, "localhost", 0, max_clients=1)
    task = asyncio.create_task(srv.run())
    await asyncio.sleep(0.05)
    port = srv.bound_port
    try:
        _, w1, welcome1 = await _connect_and_auth(port, uuid="u1", username="p1")
        assert welcome1["type"] == "welcome"
        _, w2, response = await _connect_and_auth(port, uuid="u2", username="p2")
        assert response["type"] == "error"
        assert "full" in response["message"]
        w1.close()
        w2.close()
    finally:
        pending = [t for t in asyncio.all_tasks() if t is not asyncio.current_task()]
        for t in pending:
            t.cancel()
        await asyncio.gather(*pending, return_exceptions=True)
        del task


# ---------------------------------------------------------------------------
# Reconnect — same UUID reuses existing session
# ---------------------------------------------------------------------------


async def test_reconnect_same_uuid_reuses_entity_id(server):
    """Reconnecting with the same UUID must yield the same entity_id."""
    _, w1, welcome1 = await _connect_and_auth(
        server.bound_port, uuid="stable-uuid", username="bob"
    )
    eid1 = welcome1["entity_id"]
    w1.close()
    await asyncio.sleep(0.05)  # let server notice the disconnect

    _, w2, welcome2 = await _connect_and_auth(
        server.bound_port, uuid="stable-uuid", username="bob"
    )
    eid2 = welcome2["entity_id"]
    assert eid1 == eid2
    w2.close()


async def test_same_uuid_live_session_gets_independent_entity(server):
    """Two live connections sharing a UUID (same machine) get different entities.

    This mirrors the scenario where two clients both load the same
    ~/.faraway_realms/client.uuid file and connect to the same server.
    The second connection must NOT hijack the first client's session.
    """
    r1, w1, welcome1 = await _connect_and_auth(
        server.bound_port,
        uuid="shared-uuid",
        username="player1",
        color=[255, 0, 0],
    )
    # w1 is still open — session is live when second client connects.
    r2, w2, welcome2 = await _connect_and_auth(
        server.bound_port,
        uuid="shared-uuid",  # same UUID as first client
        username="player1",
        color=[0, 0, 255],
    )
    eid1 = welcome1["entity_id"]
    eid2 = welcome2["entity_id"]

    # Core assertion: same UUID must not hijack the live session.
    assert eid1 != eid2, "UUID collision hijacked first client's session"

    # Both entities must appear in their respective snapshots.
    pos1 = await _entity_pos(r1, eid1)
    pos2 = await _entity_pos(r2, eid2)
    assert pos1 is not None
    assert pos2 is not None

    w1.close()
    w2.close()


# ---------------------------------------------------------------------------
# Serialization round-trip
# ---------------------------------------------------------------------------


async def test_deserialize_snapshot_from_live_tick(server):
    """End-to-end: tick dict from server is valid input to deserialize_snapshot."""
    from faraway_realms.net.serialization import deserialize_snapshot

    reader, writer, _ = await _connect_and_auth(server.bound_port)
    tick = await _recv_tick(reader)
    snap = deserialize_snapshot(tick)
    assert snap.abs_tick >= 1
    assert isinstance(snap.entities, list)
    writer.close()


async def test_deserialize_snapshot_player_entity(server):
    """Deserialized snapshot contains the player's EntitySnapshot."""
    from faraway_realms.net.serialization import deserialize_snapshot

    reader, writer, welcome = await _connect_and_auth(server.bound_port)
    entity_id = welcome["entity_id"]
    tick = await _recv_tick(reader)
    snap = deserialize_snapshot(tick)
    ids = [e.entity_id for e in snap.entities]
    assert entity_id in ids
    writer.close()


async def test_entity_snapshot_stats_round_trip(server):
    """Stats serialized on the server must survive the msgpack round-trip."""
    from faraway_realms.net.serialization import deserialize_snapshot

    reader, writer, welcome = await _connect_and_auth(server.bound_port)
    entity_id = welcome["entity_id"]
    tick = await _recv_tick(reader)
    snap = deserialize_snapshot(tick)
    entity = next(e for e in snap.entities if e.entity_id == entity_id)
    assert len(entity.stats) > 0
    for stat_data in entity.stats.values():
        assert "base" in stat_data
        assert "abbreviation" in stat_data
    writer.close()


# ---------------------------------------------------------------------------
# Two-client multiplayer: independent movement and correct colors
# ---------------------------------------------------------------------------


async def _entity_pos(
    reader: asyncio.StreamReader, entity_id: int, max_ticks: int = 5
) -> tuple[int, int] | None:
    """Return the position of *entity_id* in the next snapshot that contains it."""
    for _ in range(max_ticks):
        tick = await _recv_tick(reader)
        ents = {e["entity_id"]: e for e in tick.get("entities", [])}
        if entity_id in ents:
            return ents[entity_id]["x"], ents[entity_id]["y"]
    return None


async def _wait_for_move(
    reader: asyncio.StreamReader,
    entity_id: int,
    start: tuple[int, int],
    max_ticks: int = 20,
) -> tuple[int, int] | None:
    """Read ticks until *entity_id* moves away from *start*, return new pos."""
    for _ in range(max_ticks):
        tick = await _recv_tick(reader)
        ents = {e["entity_id"]: e for e in tick.get("entities", [])}
        if entity_id in ents:
            pos = ents[entity_id]["x"], ents[entity_id]["y"]
            if pos != start:
                return pos
    return None


async def test_two_clients_have_distinct_colors(server):
    """player_overrides in welcome must reflect each client's requested color."""
    _, w1, welcome1 = await _connect_and_auth(
        server.bound_port,
        uuid="uuid-red",
        username="red",
        char_name="Red",
        color=[255, 0, 0],
    )
    _, w2, welcome2 = await _connect_and_auth(
        server.bound_port,
        uuid="uuid-blue",
        username="blue",
        char_name="Blue",
        color=[0, 0, 255],
    )
    eid1 = welcome1["entity_id"]
    eid2 = welcome2["entity_id"]

    overrides1 = welcome1.get("player_overrides", {})
    overrides2 = welcome2.get("player_overrides", {})

    assert overrides1.get(str(eid1), {}).get("fg_color") == [255, 0, 0]
    assert overrides2.get(str(eid2), {}).get("fg_color") == [0, 0, 255]
    w1.close()
    w2.close()


async def test_two_clients_same_username_get_different_entities(server):
    """Two connections with the same username get separate entities."""
    _, w1, welcome1 = await _connect_and_auth(
        server.bound_port, uuid="uuid-1", username="player1"
    )
    _, w2, welcome2 = await _connect_and_auth(
        server.bound_port, uuid="uuid-2", username="player1"
    )
    assert welcome1["entity_id"] != welcome2["entity_id"]
    w1.close()
    w2.close()


async def test_move_only_affects_own_entity(server_two_players):
    """A MOVE command from client A must not change client B's position."""
    r1, w1, welcome1 = await _connect_and_auth(
        server_two_players.bound_port,
        uuid="uuid-a",
        username="alpha",
        color=[255, 0, 0],
    )
    r2, w2, welcome2 = await _connect_and_auth(
        server_two_players.bound_port,
        uuid="uuid-b",
        username="beta",
        color=[0, 0, 255],
    )
    eid1 = welcome1["entity_id"]
    eid2 = welcome2["entity_id"]

    # Drain one tick each so both clients have a stable baseline position.
    pos1_start = await _entity_pos(r1, eid1)
    pos2_start = await _entity_pos(r2, eid2)
    assert pos1_start is not None
    assert pos2_start is not None

    # Client 1 moves right.
    await send_message(w1, {"type": "command", "raw": "/move right"})
    pos1_after = await _wait_for_move(r1, eid1, pos1_start)
    assert pos1_after is not None, "Client 1's entity never moved"

    # Client 2 should NOT have moved — sample a few ticks from r2.
    for _ in range(5):
        tick = await _recv_tick(r2)
        ents = {e["entity_id"]: e for e in tick.get("entities", [])}
        if eid2 in ents:
            assert (ents[eid2]["x"], ents[eid2]["y"]) == pos2_start, (
                "Client 2's entity moved even though client 2 sent no command"
            )

    w1.close()
    w2.close()


async def test_each_client_controls_own_entity(server_two_players):
    """Client A and client B can each move their own entity independently."""
    r1, w1, welcome1 = await _connect_and_auth(
        server_two_players.bound_port,
        uuid="uuid-a",
        username="alpha",
        color=[255, 0, 0],
    )
    r2, w2, welcome2 = await _connect_and_auth(
        server_two_players.bound_port,
        uuid="uuid-b",
        username="beta",
        color=[0, 0, 255],
    )
    eid1 = welcome1["entity_id"]
    eid2 = welcome2["entity_id"]

    pos1_start = await _entity_pos(r1, eid1)
    pos2_start = await _entity_pos(r2, eid2)
    assert pos1_start is not None
    assert pos2_start is not None

    # Client 1 moves right, client 2 moves down — both from their own windows.
    await send_message(w1, {"type": "command", "raw": "/move right"})
    await send_message(w2, {"type": "command", "raw": "/move down"})

    pos1_after = await _wait_for_move(r1, eid1, pos1_start)
    pos2_after = await _wait_for_move(r2, eid2, pos2_start)

    assert pos1_after is not None, "Client 1's entity never moved"
    assert pos2_after is not None, "Client 2's entity never moved"
    assert pos1_after != pos1_start
    assert pos2_after != pos2_start

    w1.close()
    w2.close()


# ---------------------------------------------------------------------------
# Pre-spawned host entity (mirrors _build_game in __main__.py)
# ---------------------------------------------------------------------------
# _build_game always creates entity_id=1 before any client connects. The host
# client reuses it; a second client with the same username must get a new entity.


async def test_prespawn_host_reuses_entity_id_1(server_prespawn):
    """First client with matching username must reuse the pre-spawned entity."""
    _, w, welcome = await _connect_and_auth(
        server_prespawn.bound_port, uuid="uuid-host", username="player1"
    )
    assert welcome["entity_id"] == 1
    w.close()


async def test_prespawn_second_client_gets_new_entity(server_prespawn):
    """Second client (same username) must receive a different entity_id."""
    _, w1, welcome1 = await _connect_and_auth(
        server_prespawn.bound_port, uuid="uuid-a", username="player1"
    )
    _, w2, welcome2 = await _connect_and_auth(
        server_prespawn.bound_port, uuid="uuid-b", username="player1"
    )
    assert welcome2["entity_id"] != welcome1["entity_id"]
    w1.close()
    w2.close()


async def test_prespawn_host_can_move(server_prespawn):
    """First client (entity_id=1) must be able to move after connecting."""
    r1, w1, welcome1 = await _connect_and_auth(
        server_prespawn.bound_port,
        uuid="uuid-host",
        username="player1",
        color=[255, 255, 0],
    )
    eid1 = welcome1["entity_id"]
    assert eid1 == 1

    pos1_start = await _entity_pos(r1, eid1)
    assert pos1_start is not None, "Host entity_id=1 not found in tick snapshot"

    await send_message(w1, {"type": "command", "raw": "/move right"})
    pos1_after = await _wait_for_move(r1, eid1, pos1_start)
    assert pos1_after is not None, "Host entity never moved after /move right"
    w1.close()


async def test_prespawn_two_clients_move_independently(server_prespawn):
    """Host (entity_id=1) and second client both move only their own entity."""
    r1, w1, welcome1 = await _connect_and_auth(
        server_prespawn.bound_port,
        uuid="uuid-host",
        username="player1",
        color=[255, 255, 0],
    )
    r2, w2, welcome2 = await _connect_and_auth(
        server_prespawn.bound_port,
        uuid="uuid-guest",
        username="player1",
        color=[0, 100, 255],
    )
    eid1 = welcome1["entity_id"]
    eid2 = welcome2["entity_id"]
    assert eid1 == 1
    assert eid2 != 1

    pos1_start = await _entity_pos(r1, eid1)
    pos2_start = await _entity_pos(r2, eid2)
    assert pos1_start is not None, "Host entity not in tick"
    assert pos2_start is not None, "Guest entity not in tick"

    await send_message(w1, {"type": "command", "raw": "/move right"})
    await send_message(w2, {"type": "command", "raw": "/move down"})

    pos1_after = await _wait_for_move(r1, eid1, pos1_start)
    pos2_after = await _wait_for_move(r2, eid2, pos2_start)

    assert pos1_after is not None, "Host entity never moved"
    assert pos2_after is not None, "Guest entity never moved"
    w1.close()
    w2.close()


async def test_prespawn_second_client_color_respected(server_prespawn):
    """Second client's fg_color from auth must appear in player_overrides."""
    _, w1, _ = await _connect_and_auth(
        server_prespawn.bound_port,
        uuid="uuid-host",
        username="player1",
        color=[255, 255, 0],
    )
    _, w2, welcome2 = await _connect_and_auth(
        server_prespawn.bound_port,
        uuid="uuid-guest",
        username="player1",
        char_name="Guest",
        color=[0, 100, 255],
    )
    eid2 = welcome2["entity_id"]
    overrides2 = welcome2.get("player_overrides", {})
    assert overrides2.get(str(eid2), {}).get("fg_color") == [0, 100, 255]
    w1.close()
    w2.close()


@pytest.mark.asyncio
async def test_server_stop_exits_cleanly():
    """GameServer.stop() must let serve_forever exit without raising."""
    srv = await _make_server(_make_test_game())
    srv.stop()
    # Give the loop one iteration to process the close.
    await asyncio.sleep(0)
    # Teardown should find no pending tasks (run() task already completed).
    await _teardown_server()


# ---------------------------------------------------------------------------
# Graceful disconnect / session reaper
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_goodbye_removes_entity_immediately():
    """Sending 'goodbye' removes the session and despawns the entity immediately."""
    srv = await _make_server(_make_test_game())
    reader, writer, welcome = await _connect_and_auth(srv.bound_port)
    entity_id = welcome["entity_id"]

    # Confirm entity exists before goodbye.
    assert srv._game.entity(entity_id) is not None  # noqa: SLF001

    await send_message(writer, {"type": "goodbye"})
    writer.close()

    # Give server time to process goodbye and run a tick (ENTITY_DYING → flush).
    await asyncio.sleep(0.1)

    # Session should be gone immediately.
    assert not any(  # noqa: SLF001
        s.entity_id == entity_id for s in srv._sessions.values()
    )
    # Entity should be despawned after the next tick flushes ENTITY_DYING.
    assert srv._game.entity(entity_id) is None  # noqa: SLF001

    await _teardown_server()


@pytest.mark.asyncio
async def test_goodbye_no_grace_period(monkeypatch):
    """After goodbye, no session lingers in _sessions regardless of grace period."""
    import faraway_realms.net.server as server_mod

    monkeypatch.setattr(server_mod, "_RECONNECT_GRACE_S", 9999.0)

    srv = await _make_server(_make_test_game())
    reader, writer, welcome = await _connect_and_auth(srv.bound_port)
    entity_id = welcome["entity_id"]

    await send_message(writer, {"type": "goodbye"})
    writer.close()
    await asyncio.sleep(0.1)

    # With a huge grace period, ungraceful disconnects would linger — goodbye must not.
    assert not any(  # noqa: SLF001
        s.entity_id == entity_id for s in srv._sessions.values()
    )

    await _teardown_server()


@pytest.mark.asyncio
async def test_ungraceful_disconnect_entity_removed_after_grace(monkeypatch):
    """Ungraceful disconnect: entity is removed once the grace period expires."""
    import faraway_realms.net.server as server_mod

    monkeypatch.setattr(server_mod, "_RECONNECT_GRACE_S", 0.05)

    srv = await _make_server(_make_test_game())
    reader, writer, welcome = await _connect_and_auth(srv.bound_port)
    entity_id = welcome["entity_id"]

    # Close abruptly — no goodbye.
    writer.close()

    # Before grace expires: entity should still exist.
    await asyncio.sleep(0.02)
    assert srv._game.entity(entity_id) is not None  # noqa: SLF001

    # After grace expires and the reaper runs: entity should be gone.
    await asyncio.sleep(0.15)
    assert srv._game.entity(entity_id) is None  # noqa: SLF001

    await _teardown_server()
