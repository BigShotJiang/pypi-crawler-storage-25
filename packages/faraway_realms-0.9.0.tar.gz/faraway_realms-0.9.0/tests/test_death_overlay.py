"""Tests for the player-death notification path.

Covers four layers:
  1. GameServer._on_entity_died — stashes death payload on the session
  2. NetworkClient.death_payload() — stores and exposes the death message
  3. ClientGame.is_player_dead() / death_payload() — delegates to the client
  4. DeathOverlay — renders without error; any key returns False (exit signal)
"""

from __future__ import annotations

import asyncio
from unittest.mock import MagicMock

import pytest
import pytest_asyncio
import tcod.console
import tcod.event

from faraway_realms.client_game import ClientGame
from faraway_realms.game import Game
from faraway_realms.net.protocol import recv_message, send_message
from faraway_realms.net.server import GameServer, _ClientSession
from faraway_realms.ui.layout import CONSOLE_HEIGHT, CONSOLE_WIDTH
from faraway_realms.ui.overlays import DeathOverlay
from faraway_realms.world.events import Event, EventType
from faraway_realms.world.factions import FACTION_RELATIONS
from faraway_realms.world.map import make_bordered_map

# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

_MAP_W, _MAP_H = 10, 10


def _make_game(death_message: str = "") -> Game:
    game_map = make_bordered_map(_MAP_W, _MAP_H)
    spawn = [
        (x, y)
        for y in range(2, _MAP_H - 2)
        for x in range(2, _MAP_W - 2)
        if game_map.is_walkable(x, y)
    ]
    return Game(
        game_map=game_map,
        faction_relations=FACTION_RELATIONS,
        player_spawn_tiles=spawn,
        tick_rate=50.0,
        death_message=death_message,
    )


def _make_client_game(death_payload: dict | None = None) -> ClientGame:
    mock_client = MagicMock()
    mock_client.latest_snapshot.return_value = None
    mock_client.player_overrides.return_value = {}
    mock_client.death_payload.return_value = death_payload
    return ClientGame(client=mock_client, game_map=make_bordered_map(10, 10))


def _key(sym: tcod.event.KeySym) -> tcod.event.KeyDown:
    return tcod.event.KeyDown(sym=sym, mod=tcod.event.Modifier.NONE, scancode=sym)


# ---------------------------------------------------------------------------
# 1. GameServer._on_entity_died
# ---------------------------------------------------------------------------


def test_on_entity_died_stashes_payload_on_matching_session() -> None:
    game = _make_game(death_message="The cave claims you.")
    srv = GameServer(game, "localhost", 0)

    session = _ClientSession(uuid="u1", entity_id=42)
    session.joined_at_abs_tick = 0
    srv._sessions["u1"] = session  # noqa: SLF001

    event = Event(event_type=EventType.ENTITY_DIED, source_id=42)
    srv._on_entity_died(event)  # noqa: SLF001

    assert not session.alive
    assert session.death_message_payload is not None
    assert session.death_message_payload["type"] == "death"
    assert session.death_message_payload["lore"] == "The cave claims you."
    assert session.death_message_payload["kills"] == 0


def test_on_entity_died_noop_for_unknown_entity() -> None:
    game = _make_game()
    srv = GameServer(game, "localhost", 0)

    session = _ClientSession(uuid="u1", entity_id=42)
    srv._sessions["u1"] = session  # noqa: SLF001

    # Entity 99 has no session — must not raise or mutate the existing session
    event = Event(event_type=EventType.ENTITY_DIED, source_id=99)
    srv._on_entity_died(event)  # noqa: SLF001

    assert session.alive
    assert session.death_message_payload is None


def test_on_entity_died_noop_when_already_dead() -> None:
    game = _make_game()
    srv = GameServer(game, "localhost", 0)

    session = _ClientSession(uuid="u1", entity_id=42)
    session.alive = False
    srv._sessions["u1"] = session  # noqa: SLF001

    event = Event(event_type=EventType.ENTITY_DIED, source_id=42)
    srv._on_entity_died(event)  # noqa: SLF001

    assert session.death_message_payload is None  # not overwritten


def test_on_entity_dying_credits_kill_to_attacker_session() -> None:
    from faraway_realms.entities.character_type import CHARACTER_REGISTRY

    game = _make_game()
    srv = GameServer(game, "localhost", 0)

    # Place attacker entity in game with a session
    attacker = CHARACTER_REGISTRY["hero"].to_entity(entity_id=10)
    game._entities[10] = attacker  # noqa: SLF001
    attacker_session = _ClientSession(uuid="attacker", entity_id=10)
    srv._sessions["attacker"] = attacker_session  # noqa: SLF001

    # Place victim entity with last_hit_by pointing to attacker
    victim = CHARACTER_REGISTRY["hero"].to_entity(entity_id=20)
    victim.last_hit_by = 10
    game._entities[20] = victim  # noqa: SLF001

    event = Event(event_type=EventType.ENTITY_DYING, source_id=20)
    srv._on_entity_dying(event)  # noqa: SLF001

    assert attacker_session.kills == 1


def test_on_entity_dying_no_kill_when_last_hit_by_none() -> None:
    from faraway_realms.entities.character_type import CHARACTER_REGISTRY

    game = _make_game()
    srv = GameServer(game, "localhost", 0)

    victim = CHARACTER_REGISTRY["hero"].to_entity(entity_id=20)
    victim.last_hit_by = None
    game._entities[20] = victim  # noqa: SLF001

    event = Event(event_type=EventType.ENTITY_DYING, source_id=20)
    srv._on_entity_dying(event)  # noqa: SLF001
    # No sessions — must not raise


def test_on_entity_died_kills_reflect_credited_count() -> None:
    from faraway_realms.entities.character_type import CHARACTER_REGISTRY

    game = _make_game()
    srv = GameServer(game, "localhost", 0)

    # Player session
    player_entity = CHARACTER_REGISTRY["hero"].to_entity(entity_id=10)
    game._entities[10] = player_entity  # noqa: SLF001
    player_session = _ClientSession(uuid="p1", entity_id=10)
    player_session.joined_at_abs_tick = 0
    player_session.kills = 3  # pre-credited
    srv._sessions["p1"] = player_session  # noqa: SLF001

    event = Event(event_type=EventType.ENTITY_DIED, source_id=10)
    srv._on_entity_died(event)  # noqa: SLF001

    assert player_session.death_message_payload["kills"] == 3


def test_on_entity_died_ticks_alive_is_correct() -> None:
    game = _make_game()
    srv = GameServer(game, "localhost", 0)

    session = _ClientSession(uuid="u1", entity_id=42)
    session.joined_at_abs_tick = 5
    srv._sessions["u1"] = session  # noqa: SLF001

    # Advance the game tick counter to 15
    game._abs_tick = 15  # noqa: SLF001

    event = Event(event_type=EventType.ENTITY_DIED, source_id=42)
    srv._on_entity_died(event)  # noqa: SLF001

    assert session.death_message_payload["ticks_alive"] == 10


# ---------------------------------------------------------------------------
# 2. NetworkClient.death_payload()
# ---------------------------------------------------------------------------


def test_death_payload_none_before_death_message() -> None:
    from faraway_realms.net.client import NetworkClient

    client = NetworkClient("localhost", 9999, "uuid", "player")
    assert client.death_payload() is None


def test_death_payload_set_after_death_message_dispatched() -> None:
    from faraway_realms.net.client import NetworkClient, _ClientMetrics

    client = NetworkClient("localhost", 9999, "uuid", "player")
    metrics = _ClientMetrics()
    payload = {"type": "death", "lore": "You died.", "kills": 2, "ticks_alive": 100}
    client._dispatch_msg(payload, metrics)  # noqa: SLF001

    result = client.death_payload()
    assert result is not None
    assert result["lore"] == "You died."
    assert result["kills"] == 2


def test_death_payload_not_overwritten_by_tick_message() -> None:
    from faraway_realms.net.client import NetworkClient, _ClientMetrics

    client = NetworkClient("localhost", 9999, "uuid", "player")
    metrics = _ClientMetrics()
    death = {"type": "death", "lore": "Gone.", "kills": 0, "ticks_alive": 50}
    client._dispatch_msg(death, metrics)  # noqa: SLF001

    tick = {"type": "tick", "entities": [], "attack_cooldown_fraction": 0.0}
    client._dispatch_msg(tick, metrics)  # noqa: SLF001

    assert client.death_payload()["lore"] == "Gone."


# ---------------------------------------------------------------------------
# 3. ClientGame.is_player_dead() / death_payload()
# ---------------------------------------------------------------------------


def test_client_game_not_dead_when_no_payload() -> None:
    cg = _make_client_game(death_payload=None)
    assert not cg.is_player_dead()
    assert cg.death_payload() is None


def test_client_game_dead_when_payload_present() -> None:
    payload = {"type": "death", "lore": "Frozen.", "kills": 1, "ticks_alive": 200}
    cg = _make_client_game(death_payload=payload)
    assert cg.is_player_dead()
    assert cg.death_payload()["lore"] == "Frozen."


# ---------------------------------------------------------------------------
# 4. DeathOverlay
# ---------------------------------------------------------------------------


@pytest.fixture
def console() -> tcod.console.Console:
    return tcod.console.Console(CONSOLE_WIDTH, CONSOLE_HEIGHT, order="C")


def _death_payload(**kwargs) -> dict:
    base = {
        "type": "death",
        "lore": "You perished.",
        "kills": 3,
        "ticks_alive": 600,
        "tick_rate": 10.0,
    }
    base.update(kwargs)
    return base


def test_death_overlay_render_does_not_raise(console: tcod.console.Console) -> None:
    overlay = DeathOverlay(_death_payload())
    overlay.render(console)  # must not raise


def test_death_overlay_render_with_empty_lore(console: tcod.console.Console) -> None:
    overlay = DeathOverlay(_death_payload(lore=""))
    overlay.render(console)


def test_death_overlay_any_key_returns_false() -> None:
    overlay = DeathOverlay(_death_payload())
    for sym in (
        tcod.event.KeySym.RETURN,
        tcod.event.KeySym.ESCAPE,
        tcod.event.KeySym(ord("q")),
        tcod.event.KeySym.SPACE,
    ):
        assert overlay.handle_key(_key(sym)) is False


# ---------------------------------------------------------------------------
# 5. Integration — death message delivered over real TCP
# ---------------------------------------------------------------------------


async def _teardown_server() -> None:
    pending = [t for t in asyncio.all_tasks() if t is not asyncio.current_task()]
    for t in pending:
        t.cancel()
    await asyncio.gather(*pending, return_exceptions=True)


@pytest_asyncio.fixture
async def death_server():
    from faraway_realms.entities.character_type import CHARACTER_REGISTRY
    from faraway_realms.entities.entity import Player

    game = _make_game(death_message="Test lore.")
    entity = CHARACTER_REGISTRY["hero"].to_entity(entity_id=1)
    player = Player(username="player1", entity=entity)
    game.add_player(player)
    game.game_map.place_entity(1, 5, 5)

    srv = GameServer(game, "localhost", 0)
    asyncio.create_task(srv.run())
    await asyncio.sleep(0.05)

    yield srv, game, entity

    await _teardown_server()


@pytest.mark.asyncio
async def test_death_message_sent_after_player_entity_dies(death_server) -> None:
    srv, game, entity = death_server

    reader, writer = await asyncio.open_connection("localhost", srv.bound_port)
    await send_message(
        writer,
        {
            "type": "auth",
            "uuid": "u-death",
            "username": "player1",
            "char_name": "Hero",
            "color": [255, 255, 0],
        },
    )
    # Consume welcome
    await asyncio.wait_for(recv_message(reader), timeout=2.0)

    # Kill the player entity directly via the event bus
    from faraway_realms.world.events import Event, EventType

    game.bus.publish(
        Event(event_type=EventType.ENTITY_DYING, source_id=entity.entity_id)
    )
    game.tick()

    # Server sends a final tick (entity removed) then the death message
    tick_msg = await asyncio.wait_for(recv_message(reader), timeout=2.0)
    assert tick_msg["type"] == "tick"
    msg = await asyncio.wait_for(recv_message(reader), timeout=2.0)
    assert msg["type"] == "death"
    assert msg["lore"] == "Test lore."
    assert "kills" in msg
    assert "ticks_alive" in msg

    writer.close()
