"""Tests for the map generation pipeline."""

import random

import pytest

from faraway_realms.mapgen import (
    CaveGenerator,
    CellularAutomataGenerator,
    GeneratorConfig,
    Rect,
    make_generator,
)
from faraway_realms.mapgen.base import DoorCandidate, MapGenResult
from faraway_realms.mapgen.cave import _padded
from faraway_realms.mapgen.corridor_narrowing_pass import (
    CorridorNarrowingPass,
    _narrow_candidate,
)
from faraway_realms.mapgen.door_population_pass import DoorPopulationPass
from faraway_realms.mapgen.map_profile import MAP_PROFILE_REGISTRY
from faraway_realms.world.map import Map
from faraway_realms.world.tile import floor_tile, wall_tile

# ---------------------------------------------------------------------------
# Rect
# ---------------------------------------------------------------------------


def test_rect_x2_y2() -> None:
    r = Rect(2, 3, 6, 4)
    assert r.x2 == 8
    assert r.y2 == 7


def test_rect_center_even_dimensions() -> None:
    assert Rect(0, 0, 10, 10).center == (5, 5)


def test_rect_center_odd_dimensions() -> None:
    assert Rect(0, 0, 5, 5).center == (2, 2)


def test_rect_intersects_overlapping() -> None:
    a = Rect(0, 0, 5, 5)
    b = Rect(3, 3, 5, 5)
    assert a.intersects(b)
    assert b.intersects(a)


def test_rect_intersects_fully_inside() -> None:
    outer = Rect(0, 0, 10, 10)
    inner = Rect(2, 2, 4, 4)
    assert outer.intersects(inner)


def test_rect_no_intersect_separated() -> None:
    a = Rect(0, 0, 3, 3)
    b = Rect(5, 5, 3, 3)
    assert not a.intersects(b)


def test_rect_no_intersect_touching_edge() -> None:
    """Rects that share only an edge (x2 == other.x) must not intersect."""
    a = Rect(0, 0, 3, 3)
    b = Rect(3, 0, 3, 3)
    assert not a.intersects(b)


def test_rect_padded_expands_correctly() -> None:
    r = Rect(5, 5, 4, 4)
    p = _padded(r, 1)
    assert p.x == 4
    assert p.y == 4
    assert p.width == 6
    assert p.height == 6


# ---------------------------------------------------------------------------
# CaveGenerator — map structure
# ---------------------------------------------------------------------------


def _gen(seed: int = 42, width: int = 80, height: int = 50) -> MapGenResult:
    return CaveGenerator().generate(width, height, random.Random(seed))


def test_cave_generator_correct_dimensions() -> None:
    result = _gen()
    assert result.map.width == 80
    assert result.map.height == 50


def test_cave_generator_produces_rooms() -> None:
    assert len(_gen().rooms) > 0


def test_cave_generator_player_start_walkable() -> None:
    result = _gen()
    x, y = result.player_start
    assert result.map.is_walkable(x, y)


def test_cave_generator_player_start_is_first_room_centre() -> None:
    result = _gen()
    assert result.player_start == result.rooms[0].center


def test_cave_generator_room_centres_are_walkable() -> None:
    result = _gen()
    for room in result.rooms:
        cx, cy = room.center
        assert result.map.is_walkable(cx, cy)


def test_cave_generator_border_stays_impassable() -> None:
    """The outermost ring of tiles must never be carved."""
    result = _gen()
    m = result.map
    for x in range(m.width):
        assert not m.is_walkable(x, 0), f"top border at x={x} is walkable"
        assert not m.is_walkable(x, m.height - 1), f"bottom border at x={x} is walkable"
    for y in range(m.height):
        assert not m.is_walkable(0, y), f"left border at y={y} is walkable"
        assert not m.is_walkable(m.width - 1, y), f"right border at y={y} is walkable"


def test_cave_generator_rooms_do_not_overlap() -> None:
    result = _gen()
    rooms = result.rooms
    for i, r1 in enumerate(rooms):
        for r2 in rooms[i + 1 :]:
            assert not r1.intersects(r2), f"rooms {i} and {i + 1} overlap"


def test_cave_generator_corridors_two_tiles_wide() -> None:
    """Both the primary row and row+1 of each horizontal tunnel are walkable."""
    result = _gen()
    if len(result.rooms) < 2:
        pytest.skip("need at least 2 rooms")
    r1, r2 = result.rooms[0], result.rooms[1]
    _, cy1 = r1.center
    cx1, _ = r1.center
    cx2, _ = r2.center
    mid_x = (cx1 + cx2) // 2
    assert result.map.is_walkable(mid_x, cy1), "horizontal corridor row missing"
    assert result.map.is_walkable(mid_x, cy1 + 1), "second corridor row missing"


def test_cave_generator_rooms_minimum_size() -> None:
    result = _gen()
    for room in result.rooms:
        assert room.width >= 4
        assert room.height >= 4


def test_cave_generator_deterministic() -> None:
    """Same seed must produce identical room lists."""
    r1 = CaveGenerator().generate(80, 50, random.Random(7))
    r2 = CaveGenerator().generate(80, 50, random.Random(7))
    assert r1.rooms == r2.rooms
    assert r1.player_start == r2.player_start


def test_cave_generator_different_seeds_differ() -> None:
    r1 = CaveGenerator().generate(80, 50, random.Random(1))
    r2 = CaveGenerator().generate(80, 50, random.Random(999))
    assert r1.rooms != r2.rooms


def test_cave_generator_custom_params() -> None:
    gen = CaveGenerator(max_rooms=5, room_min_size=5, room_max_size=6)
    result = gen.generate(80, 50, random.Random(42))
    assert len(result.rooms) <= 5
    for room in result.rooms:
        assert 5 <= room.width <= 6
        assert 5 <= room.height <= 6


def test_cave_generator_empty_fallback_when_no_rooms_fit() -> None:
    """Tiny map that can't fit any room returns empty rooms list and fallback start."""
    gen = CaveGenerator(room_min_size=4, room_max_size=4)
    # 4x4 interior + 1 border on each side = exactly 6 wide/tall
    result = gen.generate(6, 6, random.Random(0))
    # May or may not fit; just verify the result is valid
    x, y = result.player_start
    assert 0 <= x < result.map.width
    assert 0 <= y < result.map.height


# ---------------------------------------------------------------------------
# CaveGenerator — spawn zones
# ---------------------------------------------------------------------------


def test_cave_generator_spawn_zones_count_matches_rooms() -> None:
    result = _gen()
    assert len(result.spawn_zones) == len(result.rooms)


def test_cave_generator_spawn_zones_all_walkable() -> None:
    result = _gen()
    for zone in result.spawn_zones:
        for x, y in zone:
            assert result.map.is_walkable(x, y)


def test_cave_generator_player_zone_index_is_zero() -> None:
    assert _gen().player_zone_index == 0


def test_cave_generator_player_start_in_player_zone() -> None:
    result = _gen()
    player_zone = set(result.spawn_zones[result.player_zone_index])
    assert result.player_start in player_zone


def test_cave_generator_door_candidates_produced() -> None:
    result = CaveGenerator().generate(80, 50, random.Random(42))
    if len(result.rooms) >= 2:
        assert len(result.door_candidates) > 0


# ---------------------------------------------------------------------------
# CellularAutomataGenerator
# ---------------------------------------------------------------------------


def _ca_gen(seed: int = 42, width: int = 80, height: int = 50) -> MapGenResult:
    return CellularAutomataGenerator().generate(width, height, random.Random(seed))


def test_ca_generator_correct_dimensions() -> None:
    result = _ca_gen()
    assert result.map.width == 80
    assert result.map.height == 50


def test_ca_generator_player_start_walkable() -> None:
    result = _ca_gen()
    x, y = result.player_start
    assert result.map.is_walkable(x, y)


def test_ca_generator_no_rooms() -> None:
    assert _ca_gen().rooms == []


def test_ca_generator_has_spawn_zones() -> None:
    result = _ca_gen()
    assert len(result.spawn_zones) > 0


def test_ca_generator_player_zone_index_zero() -> None:
    assert _ca_gen().player_zone_index == 0


def test_ca_generator_player_start_in_player_zone() -> None:
    result = _ca_gen()
    player_zone = set(result.spawn_zones[result.player_zone_index])
    assert result.player_start in player_zone


def test_ca_generator_spawn_zones_all_walkable() -> None:
    result = _ca_gen()
    for zone in result.spawn_zones:
        for x, y in zone:
            assert result.map.is_walkable(x, y)


def test_ca_generator_border_stays_impassable() -> None:
    result = _ca_gen()
    m = result.map
    for x in range(m.width):
        assert not m.is_walkable(x, 0)
        assert not m.is_walkable(x, m.height - 1)
    for y in range(m.height):
        assert not m.is_walkable(0, y)
        assert not m.is_walkable(m.width - 1, y)


def test_ca_generator_deterministic() -> None:
    r1 = CellularAutomataGenerator().generate(80, 50, random.Random(7))
    r2 = CellularAutomataGenerator().generate(80, 50, random.Random(7))
    assert r1.player_start == r2.player_start
    assert len(r1.spawn_zones) == len(r2.spawn_zones)


def test_ca_generator_different_seeds_differ() -> None:
    r1 = CellularAutomataGenerator().generate(80, 50, random.Random(1))
    r2 = CellularAutomataGenerator().generate(80, 50, random.Random(999))
    assert r1.player_start != r2.player_start or len(r1.spawn_zones) != len(
        r2.spawn_zones
    )


def test_ca_generator_min_region_culled() -> None:
    """With a high min_region_size, tiny voids should be filled."""
    gen = CellularAutomataGenerator(min_region_size=100)
    result = gen.generate(80, 50, random.Random(42))
    for zone in result.spawn_zones:
        assert len(zone) >= 100


# ---------------------------------------------------------------------------
# GeneratorConfig and make_generator factory
# ---------------------------------------------------------------------------


def test_generator_config_default_is_cave() -> None:
    config = GeneratorConfig()
    gen = make_generator(config)
    assert isinstance(gen, CaveGenerator)


def test_generator_config_cellular_automata() -> None:
    config = GeneratorConfig(kind="cellular_automata")
    gen = make_generator(config)
    assert isinstance(gen, CellularAutomataGenerator)


def test_generator_config_params_forwarded() -> None:
    config = GeneratorConfig(kind="cave", params=(("max_rooms", 5),))
    gen = make_generator(config)
    assert isinstance(gen, CaveGenerator)
    assert gen.max_rooms == 5


def test_make_generator_unknown_kind_raises() -> None:
    config = GeneratorConfig(kind="unknown_generator")
    with pytest.raises(ValueError, match="unknown_generator"):
        make_generator(config)


# ---------------------------------------------------------------------------
# DoorPopulationPass._is_chokepoint
# ---------------------------------------------------------------------------


def _make_map(rows: list[str]) -> Map:
    """Build a Map from a list of strings: '.' = floor, anything else = wall."""
    height = len(rows)
    width = max(len(r) for r in rows)
    tiles = [
        [floor_tile() if rows[y][x] == "." else wall_tile() for x in range(width)]
        for y in range(height)
    ]
    return Map(width, height, tiles)


def test_is_chokepoint_rejects_open_area_horizontal_false() -> None:
    """Door candidate where north flank is open — not a true chokepoint."""
    # Corridor junction: y-1=0 is walkable (open to the north).
    # horizontal=False → near check is not walkable(x, y-1) → False → rejected.
    #   ...  row 0  <- y-1 is walkable
    #   .c.  row 1  <- candidate (x=1, y=1)
    #   ...  row 2  <- second door tile
    #   ...  row 3
    game_map = _make_map(["...", "...", "...", "..."])
    candidate = DoorCandidate(x=1, y=1, horizontal=False)
    assert not DoorPopulationPass._is_chokepoint(game_map, candidate)  # noqa: SLF001


def test_is_chokepoint_accepts_corridor_horizontal_false() -> None:
    """Real E-W corridor chokepoint: walls on N and S flanks."""
    #   ###  row 0  <- y-1=0 is a wall (north flank solid)
    #   ...  row 1  <- candidate (x=1, y=1)
    #   ...  row 2  <- second door tile
    #   ###  row 3  <- y+2=3 is a wall (south flank solid)
    game_map = _make_map(["###", "...", "...", "###"])
    candidate = DoorCandidate(x=1, y=1, horizontal=False)
    assert DoorPopulationPass._is_chokepoint(game_map, candidate)  # noqa: SLF001


def test_is_chokepoint_accepts_narrow_door_horizontal_false() -> None:
    """Narrow (1-tile) door: second tile (y+1) already a wall from narrowing pass."""
    #   #  row 0 (y-1 = wall)
    #   .  row 1 (candidate)
    #   #  row 2 (second tile, walled by narrowing)
    #   .  row 3 (corridor continues beyond)
    game_map = _make_map(["###", "...", "###", "..."])
    candidate = DoorCandidate(x=1, y=1, horizontal=False)
    # y-1=0 is wall (near ok); y+1=2 is wall (narrow=True) → far check short-circuits
    assert DoorPopulationPass._is_chokepoint(game_map, candidate)  # noqa: SLF001


def test_is_chokepoint_rejects_open_area_horizontal_true() -> None:
    """Floating door — horizontal=True candidate with open W and E sides."""
    # Candidate at (1,1) horizontal=True: door tiles (1,1) and (2,1).
    # Left of x-1=0 is floor → rejects.
    game_map = _make_map(["#####", ".....", "#####"])
    candidate = DoorCandidate(x=1, y=1, horizontal=True)
    assert not DoorPopulationPass._is_chokepoint(game_map, candidate)  # noqa: SLF001


def test_is_chokepoint_accepts_corridor_horizontal_true() -> None:
    """Real N-S corridor chokepoint: walls on W and E flanks."""
    # Corridor runs N-S at columns 1–2; walls at columns 0 and 3.
    game_map = _make_map(["#..#", "#..#", "#..#"])
    candidate = DoorCandidate(x=1, y=1, horizontal=True)
    assert DoorPopulationPass._is_chokepoint(game_map, candidate)  # noqa: SLF001


# ---------------------------------------------------------------------------
# CorridorNarrowingPass — floating wall guard
# ---------------------------------------------------------------------------


def _make_narrow_result(rows: list[str]) -> MapGenResult:
    game_map = _make_map(rows)
    result = MapGenResult(map=game_map, rooms=[], player_start=(1, 1))
    # Seed tile_type_ids so _infer_wall_tile can find a wall name
    for y in range(game_map.height):
        for x in range(game_map.width):
            if not game_map.is_walkable(x, y):
                result.tile_type_ids[(x, y)] = "cave_wall"
    return result


def test_narrow_candidate_skipped_when_near_flank_open() -> None:
    """No wall placed when the candidate's near flank is open (junction/room)."""
    # All walkable — near flank (y-1) is open for horizontal=False candidate.
    result = _make_narrow_result(["...", "...", "...", "..."])
    candidate = DoorCandidate(x=1, y=1, horizontal=False)
    _narrow_candidate(result, candidate)
    assert result.map.is_walkable(1, 2), "second tile must stay walkable"


def test_narrow_candidate_walls_second_tile_in_real_corridor() -> None:
    """Wall placed when near flank is solid (genuine corridor edge)."""
    result = _make_narrow_result(["###", "...", "...", "..."])
    candidate = DoorCandidate(x=1, y=1, horizontal=False)
    _narrow_candidate(result, candidate)
    assert not result.map.is_walkable(1, 2), "second tile must be walled"


# ---------------------------------------------------------------------------
# DoorPopulationPass — integration: no floating doors in dungeon seed 100
# ---------------------------------------------------------------------------


def _dungeon_gen_result(seed: int = 100) -> MapGenResult:
    """Run the full dungeon generation pipeline (narrowing + doors)."""
    profile = MAP_PROFILE_REGISTRY["dungeon"]
    rng = random.Random(seed)
    result = CaveGenerator(**profile.generator.as_dict()).generate(
        80, 50, random.Random(seed)
    )
    CorridorNarrowingPass(profile).apply(result, rng)
    DoorPopulationPass(profile).apply(result, rng)
    return result


def test_dungeon_seed100_no_floating_doors() -> None:
    """Every door tile must have at most 2 walkable orthogonal neighbors."""
    result = _dungeon_gen_result(100)
    game_map = result.map
    door_positions = [
        pos for pos, tid in result.tile_type_ids.items() if tid == "dungeon_door_closed"
    ]
    assert door_positions, "no doors placed — test would be vacuously true"
    for x, y in door_positions:
        walkable_neighbors = sum(
            game_map.is_walkable(x + dx, y + dy)
            for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1))
        )
        assert walkable_neighbors <= 2, (  # noqa: PLR2004
            f"floating door at ({x},{y}): {walkable_neighbors} walkable neighbors"
        )
