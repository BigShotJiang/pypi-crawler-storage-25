"""Tests for the CastingSystem."""

from faraway_realms.combat.abilities import (
    Ability,
    ApplyStatusEffect,
    DamageEffect,
    ProjectileEffect,
)
from faraway_realms.combat.stats import Pool
from faraway_realms.entities.entity import CharacterEntity, NonPlayerEntity
from faraway_realms.systems.casting import CastingSystem
from faraway_realms.world.event_bus import EventBus
from faraway_realms.world.events import EventType
from faraway_realms.world.map import make_bordered_map

KICK = Ability(
    name="kick",
    cooldown=300,
    cast_time=0,
    range_tiles=1,
    effects=(
        ApplyStatusEffect(status_name="immobilize", duration=10, immobilize=True),
    ),
)
BITE = Ability(
    name="bite",
    cooldown=50,
    cast_time=10,
    range_tiles=1,
    gcd=False,
    effects=(
        ApplyStatusEffect(
            status_name="bleed", duration=30, tick_damage=1, dot_interval=5
        ),
    ),
)
FIREBOLT = Ability(
    name="firebolt",
    cooldown=30,
    cast_time=0,
    range_tiles=12,
    resource_cost=("mana", 15),
    effects=(
        ProjectileEffect(base=5, damage_type="fire", speed=2.0, color=(255, 100, 0)),
    ),
)


def _make_casting_system():
    game_map = make_bordered_map(20, 20)
    caster = CharacterEntity(
        entity_id=1, char=ord("@"), fg_color=(255, 255, 0), name="Hero"
    )
    target = NonPlayerEntity(
        entity_id=2, char=ord("Z"), fg_color=(0, 180, 0), name="Zombie"
    )
    entities = {1: caster, 2: target}
    game_map.place_entity(1, 5, 5)
    game_map.place_entity(2, 6, 5)  # adjacent
    bus = EventBus()
    published: list = []
    bus.subscribe(EventType.CAST_COMPLETE, published.append)
    bus.subscribe(EventType.CHANNEL_TICK, published.append)
    bus.subscribe(EventType.CAST_STARTED, published.append)
    return (
        CastingSystem(entities, game_map, bus),
        game_map,
        caster,
        target,
        bus,
        published,
    )


def test_begin_cast_instant_returns_complete_event():
    cs, game_map, caster, target, bus, published = _make_casting_system()
    accepted = cs.begin_cast(1, KICK, 2, abs_tick=10)
    assert accepted is True
    bus.flush(abs_tick=10)
    complete = [e for e in published if e.event_type == EventType.CAST_COMPLETE]
    assert len(complete) == 1
    assert complete[0].source_id == 1
    assert complete[0].target_id == 2
    assert complete[0].resolve_at_tick == 10  # instant: cast_time=0
    assert complete[0].payload == {"ability": "kick"}


def test_begin_cast_with_cast_time_queues_future_event():
    cs, game_map, caster, target, bus, published = _make_casting_system()
    accepted = cs.begin_cast(1, BITE, 2, abs_tick=10)
    assert accepted is True
    # Event is deferred (resolve_at=20); flush at tick 20 to deliver it
    bus.flush(abs_tick=20)
    complete = [e for e in published if e.event_type == EventType.CAST_COMPLETE]
    assert len(complete) == 1
    assert complete[0].resolve_at_tick == 20  # abs_tick=10 + cast_time=10


def test_begin_cast_respects_cooldown():
    cs, game_map, caster, target, bus, published = _make_casting_system()
    cs.begin_cast(1, KICK, 2, abs_tick=10)
    # KICK cooldown = 300 ticks; GCD = 10; try again at tick 15
    accepted = cs.begin_cast(1, KICK, 2, abs_tick=15)
    assert accepted is False


def test_begin_cast_respects_gcd():
    cs, game_map, caster, target, bus, published = _make_casting_system()
    # Use a custom instant ability with GCD
    instant_ability = Ability(
        name="zap",
        cooldown=5,
        cast_time=0,
        range_tiles=5,
        gcd=True,
        effects=(DamageEffect(base=3),),
    )
    cs.begin_cast(1, instant_ability, 2, abs_tick=10)
    # GCD lasts 10 ticks; try at tick 12
    accepted = cs.begin_cast(1, instant_ability, 2, abs_tick=12)
    assert accepted is False


def test_begin_cast_respects_range():
    cs, game_map, caster, target, bus, published = _make_casting_system()
    # Move target far away
    game_map.place_entity(2, 15, 15)
    accepted = cs.begin_cast(1, KICK, 2, abs_tick=10)
    assert accepted is False


def test_begin_cast_fails_if_caster_not_on_map():
    cs, game_map, caster, target, bus, published = _make_casting_system()
    # Entity 99 is not on the map
    accepted = cs.begin_cast(99, KICK, 2, abs_tick=10)
    assert accepted is False


def test_begin_cast_fails_if_target_not_on_map():
    cs, game_map, caster, target, bus, published = _make_casting_system()
    accepted = cs.begin_cast(1, KICK, 99, abs_tick=10)
    assert accepted is False


def test_interrupt_removes_casting_state():
    cs, game_map, caster, target, bus, published = _make_casting_system()
    cs.begin_cast(1, BITE, 2, abs_tick=10)
    assert 1 in cs._casting  # noqa: SLF001
    cs.interrupt(1)
    assert 1 not in cs._casting  # noqa: SLF001


def test_interrupt_noop_when_not_casting():
    cs, game_map, caster, target, bus, published = _make_casting_system()
    cs.interrupt(1)  # should not raise


def test_cooldowns_for_returns_on_cooldown_abilities():
    cs, game_map, caster, target, bus, published = _make_casting_system()
    cs.begin_cast(1, KICK, 2, abs_tick=10)
    cds = cs.cooldowns_for(1, abs_tick=15)
    assert "kick" in cds


def test_cooldowns_for_returns_empty_after_cooldown_expires():
    cs, game_map, caster, target, bus, published = _make_casting_system()
    cs.begin_cast(1, KICK, 2, abs_tick=10)
    # KICK cooldown: avail_at = 10 + 0 + 300 = 310
    cds = cs.cooldowns_for(1, abs_tick=400)
    assert "kick" not in cds


def test_is_on_cooldown_true_during_cooldown():
    cs, game_map, caster, target, bus, published = _make_casting_system()
    cs.begin_cast(1, KICK, 2, abs_tick=10)
    assert cs.is_on_cooldown(1, "kick", abs_tick=15) is True


def test_is_on_cooldown_false_before_use():
    cs, game_map, caster, target, bus, published = _make_casting_system()
    assert cs.is_on_cooldown(1, "kick", abs_tick=10) is False


def test_channel_produces_multiple_events():
    cs, game_map, caster, target, bus, published = _make_casting_system()
    channeled = Ability(
        name="channel_test",
        cooldown=100,
        cast_time=30,
        range_tiles=5,
        gcd=False,
        channel_interval=10,
        effects=(DamageEffect(base=2),),
    )
    cs.begin_cast(1, channeled, 2, abs_tick=0)
    bus.flush(abs_tick=30)  # deliver all events up to cast_time=30
    channel_ticks = [e for e in published if e.event_type == EventType.CHANNEL_TICK]
    complete_events = [e for e in published if e.event_type == EventType.CAST_COMPLETE]
    # channel_interval=10, cast_time=30: ticks at 10, 20, 30
    assert len(channel_ticks) == 3
    assert len(complete_events) == 1
    tick_times = sorted(e.resolve_at_tick for e in channel_ticks)
    assert tick_times == [10, 20, 30]
    assert complete_events[0].resolve_at_tick == 30


def test_is_casting_true_during_timed_cast():
    cs, _, _, _, bus, _ = _make_casting_system()
    cs.begin_cast(1, BITE, 2, abs_tick=0)  # cast_time=10
    assert cs.is_casting(1)


def test_is_casting_false_for_instant_cast():
    cs, _, _, _, bus, _ = _make_casting_system()
    cs.begin_cast(1, KICK, 2, abs_tick=0)  # cast_time=0
    assert not cs.is_casting(1)


def test_cast_fraction_increases_over_time():
    cs, _, _, _, bus, _ = _make_casting_system()
    cs.begin_cast(1, BITE, 2, abs_tick=0)  # cast_time=10
    assert cs.cast_fraction(1, abs_tick=5) == 0.5
    assert cs.cast_fraction(1, abs_tick=10) == 1.0


def test_cast_fraction_none_when_not_casting():
    cs, _, _, _, bus, _ = _make_casting_system()
    assert cs.cast_fraction(1, abs_tick=0) is None


def test_attack_blocked_during_cast():
    """Attacker cannot land a melee hit while a timed cast is in progress."""
    from faraway_realms.combat.stats import Pool, Stat
    from faraway_realms.entities.entity import Player
    from faraway_realms.game import Game
    from faraway_realms.world.commands import Command, CommandType
    from faraway_realms.world.factions import FactionRelations
    from faraway_realms.world.map import make_bordered_map

    game_map = make_bordered_map(20, 20)
    entity = CharacterEntity(
        entity_id=1,
        char=ord("@"),
        fg_color=(255, 255, 0),
        name="Hero",
        faction="player",
        stats={"health": Pool(base=100), "strength": Stat(base=5)},
        abilities={BITE.name: BITE},
    )
    player = Player(username="tester", entity=entity)
    npc = NonPlayerEntity(
        entity_id=2,
        char=ord("Z"),
        fg_color=(0, 180, 0),
        name="Zombie",
        faction="hostile",
        stats={"health": Pool(base=50)},
    )
    relations = FactionRelations()
    relations.set_hostile("player", "hostile", True)
    game = Game(game_map=game_map, faction_relations=relations)
    game.add_player(player)
    game.add_npc(npc)
    game_map.place_entity(1, 5, 5)
    game_map.place_entity(2, 6, 5)

    cast_cmd = Command(
        command_type=CommandType.CAST,
        actor="1",
        args=("bite", "2"),
        raw="/cast 1 bite 2",
    )
    attack_cmd = Command(
        command_type=CommandType.ATTACK, actor="1", args=("2",), raw="/attack 1 2"
    )
    game.enqueue_command(cast_cmd)
    game.enqueue_command(attack_cmd)
    game.tick()

    hp: Pool = npc.stats["health"]  # type: ignore[assignment]
    assert hp.current == 50  # attack was blocked during cast


# ------------------------------------------------------------------
# Resource cost (mana)
# ------------------------------------------------------------------


def _make_mana_system(mana_current: int = 100):
    """Return a casting system with a caster that has a mana pool."""
    game_map = make_bordered_map(20, 20)
    caster = CharacterEntity(
        entity_id=1,
        char=ord("@"),
        fg_color=(255, 255, 0),
        name="Hero",
        stats={"mana": Pool(base=100)},
    )
    caster.stats["mana"].current = mana_current  # type: ignore[union-attr]
    target = NonPlayerEntity(
        entity_id=2, char=ord("Z"), fg_color=(0, 180, 0), name="Zombie"
    )
    entities = {1: caster, 2: target}
    game_map.place_entity(1, 5, 5)
    game_map.place_entity(2, 8, 5)  # within FIREBOLT range (8 tiles)
    bus = EventBus()
    published: list = []
    bus.subscribe(EventType.CAST_COMPLETE, published.append)
    return CastingSystem(entities, game_map, bus), caster, published


def test_begin_cast_fails_without_mana():
    cs, caster, published = _make_mana_system(mana_current=0)
    accepted = cs.begin_cast(1, FIREBOLT, 2, abs_tick=0)
    assert accepted is False


def test_begin_cast_deducts_mana_on_success():
    cs, caster, published = _make_mana_system(mana_current=100)
    mana_before = caster.stats["mana"].current  # type: ignore[union-attr]
    cs.begin_cast(1, FIREBOLT, 2, abs_tick=0)
    mana_after = caster.stats["mana"].current  # type: ignore[union-attr]
    assert mana_after == mana_before - 15  # FIREBOLT costs 15 mana


def test_begin_cast_free_ability_ignores_missing_mana():
    """KICK has no resource cost; it should succeed even with no mana."""
    cs, caster, published = _make_mana_system(mana_current=0)
    bus = cs._bus  # noqa: SLF001
    # Move target adjacent for KICK range
    cs._game_map.place_entity(2, 6, 5)  # noqa: SLF001
    accepted = cs.begin_cast(1, KICK, 2, abs_tick=0)
    assert accepted is True  # instant cast accepted
    bus.flush(abs_tick=0)
    assert any(e.event_type == EventType.CAST_COMPLETE for e in published)


def test_begin_cast_exact_mana_required_succeeds():
    cs, caster, published = _make_mana_system(
        mana_current=15
    )  # exactly enough for FIREBOLT
    bus = cs._bus  # noqa: SLF001
    accepted = cs.begin_cast(1, FIREBOLT, 2, abs_tick=0)
    assert accepted is True
    bus.flush(abs_tick=0)
    assert len(published) == 1


def test_begin_cast_one_below_mana_required_fails():
    cs, caster, published = _make_mana_system(mana_current=14)
    accepted = cs.begin_cast(1, FIREBOLT, 2, abs_tick=0)
    assert accepted is False


# ------------------------------------------------------------------
# RESOURCE_CHANGED published on cast with resource cost
# ------------------------------------------------------------------


def test_resource_changed_published_when_mana_spent():
    """RESOURCE_CHANGED fires with correct delta when casting a mana ability."""
    from faraway_realms.world.events import EventType

    cs, caster, _ = _make_mana_system(mana_current=100)
    bus = cs._bus  # noqa: SLF001
    resource_events: list = []
    bus.subscribe(EventType.RESOURCE_CHANGED, resource_events.append)
    cs.begin_cast(1, FIREBOLT, 2, abs_tick=0)
    bus.flush(abs_tick=0)
    # FIREBOLT costs 15 mana — RESOURCE_CHANGED should be flushed
    rc = [e for e in resource_events if e.payload and e.payload.get("pool") == "mana"]
    assert len(rc) == 1
    assert rc[0].source_id == 1
    assert rc[0].payload["delta"] == -15  # type: ignore[index]
    assert rc[0].payload["current"] == 85  # type: ignore[index]


# ------------------------------------------------------------------
# Stun-interrupts-cast regression
# ------------------------------------------------------------------


def test_stun_interrupting_cast_publishes_cast_cancelled():
    """CAST_CANCELLED must fire when a stun interrupts an active timed cast.

    Before the fix, _on_stun called interrupt() without publishing
    CAST_CANCELLED, leaving CombatSystem._casting_entities permanently set
    and the entity's attack bar frozen at zero after the stun expired.
    """
    from faraway_realms.world.events import Event, EventType

    cs, game_map, caster, target, bus, _ = _make_casting_system()
    cancelled: list = []
    bus.subscribe(EventType.CAST_CANCELLED, cancelled.append)

    cs.begin_cast(1, BITE, 2, abs_tick=0)
    assert cs.is_casting(1)

    stun_event = Event(
        event_type=EventType.STUN_APPLIED,
        source_id=2,
        target_id=1,
        resolve_at_tick=3,
    )
    bus.publish(stun_event)
    bus.flush(abs_tick=3)

    assert not cs.is_casting(1)
    assert len(cancelled) == 1
    assert cancelled[0].source_id == 1
    assert cancelled[0].payload["ability_name"] == "bite"  # type: ignore[index]


def test_stun_not_casting_does_not_publish_cast_cancelled():
    """STUN_APPLIED on an entity with no active cast must not publish CAST_CANCELLED."""
    from faraway_realms.world.events import Event, EventType

    cs, game_map, caster, target, bus, _ = _make_casting_system()
    cancelled: list = []
    bus.subscribe(EventType.CAST_CANCELLED, cancelled.append)

    stun_event = Event(
        event_type=EventType.STUN_APPLIED,
        source_id=2,
        target_id=1,
        resolve_at_tick=3,
    )
    bus.publish(stun_event)
    bus.flush(abs_tick=3)

    assert len(cancelled) == 0
