"""Tests for the stat definition YAML parser."""

from pathlib import Path

import pytest

from faraway_realms.combat.stat_definitions import STAT_DEF_REGISTRY
from faraway_realms.combat.stats import Pool, Stat
from faraway_realms.content import ContentLoader
from faraway_realms.content_parsers.stat_definitions import parse_stat_definitions

_STATS_DIR = Path(__file__).parent.parent / "faraway_realms" / "data" / "stats"


@pytest.fixture(autouse=True)
def clean_registry():
    """Isolate each test — clear and restore the registry."""
    saved = dict(STAT_DEF_REGISTRY)
    STAT_DEF_REGISTRY.clear()
    yield
    STAT_DEF_REGISTRY.clear()
    STAT_DEF_REGISTRY.update(saved)


@pytest.fixture()
def load_shipped():
    """Load the shipped YAML data files into the registry."""
    loader = ContentLoader(dirs=[_STATS_DIR])
    loader.register_parser("stat_definitions", parse_stat_definitions)
    loader.load()


# ------------------------------------------------------------------
# make() returns correct type
# ------------------------------------------------------------------


def test_kind_pool_makes_pool():
    parse_stat_definitions({"hit_points": {"kind": "pool", "abbreviation": "HP"}})
    result = STAT_DEF_REGISTRY["hit_points"].make(30)
    assert isinstance(result, Pool)
    assert result.value == 30


def test_kind_stat_makes_stat():
    parse_stat_definitions({"power": {"kind": "stat", "abbreviation": "PWR"}})
    result = STAT_DEF_REGISTRY["power"].make(10)
    assert isinstance(result, Stat)
    assert not isinstance(result, Pool)
    assert result.value == 10


# ------------------------------------------------------------------
# Field parsing
# ------------------------------------------------------------------


def test_bar_filled_parsed_as_tuple():
    parse_stat_definitions(
        {
            "vitality": {
                "kind": "pool",
                "bar_filled": [180, 20, 20],
                "bar_empty": [60, 0, 0],
            }
        }
    )
    sd = STAT_DEF_REGISTRY["vitality"]
    assert sd.bar_filled == (180, 20, 20)
    assert sd.bar_empty == (60, 0, 0)


def test_regen_per_tick_default_is_zero():
    parse_stat_definitions({"mp": {"kind": "pool"}})
    assert STAT_DEF_REGISTRY["mp"].regen_per_tick == 0


def test_regen_per_tick_parsed():
    parse_stat_definitions({"mana": {"kind": "pool", "regen_per_tick": 3}})
    assert STAT_DEF_REGISTRY["mana"].regen_per_tick == 3


def test_pool_make_passes_regen_per_tick():
    parse_stat_definitions({"mana": {"kind": "pool", "regen_per_tick": 2}})
    pool = STAT_DEF_REGISTRY["mana"].make(50)
    assert isinstance(pool, Pool)
    assert pool.regen_per_tick == 2


# ------------------------------------------------------------------
# Shipped YAML round-trip
# ------------------------------------------------------------------


def test_shipped_yaml_contains_all_stats(load_shipped):
    for name in ("health", "mana", "strength", "armor"):
        assert name in STAT_DEF_REGISTRY, f"Missing stat definition: {name}"


def test_shipped_health_is_pool(load_shipped):
    sd = STAT_DEF_REGISTRY["health"]
    assert sd.kind == "pool"
    assert isinstance(sd.make(100), Pool)


def test_shipped_mana_has_regen(load_shipped):
    assert STAT_DEF_REGISTRY["mana"].regen_per_tick == 0.5


def test_shipped_strength_is_stat(load_shipped):
    sd = STAT_DEF_REGISTRY["strength"]
    assert sd.kind == "stat"
    result = sd.make(5)
    assert isinstance(result, Stat)
    assert not isinstance(result, Pool)


def test_shipped_health_bar_colors(load_shipped):
    sd = STAT_DEF_REGISTRY["health"]
    assert sd.bar_filled == (180, 20, 20)
    assert sd.bar_empty == (60, 0, 0)
