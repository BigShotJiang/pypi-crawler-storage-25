::: gool.log_clustering
