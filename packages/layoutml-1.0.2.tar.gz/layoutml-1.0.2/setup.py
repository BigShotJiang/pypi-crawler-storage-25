from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="layoutml",
    version="1.0.2",
    author="feed619",
    author_email="azimovpro@gmail.com",
    description="LayoutML - a library for creating HTML pages using Python",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/feed619/LayoutML",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Topic :: Internet :: WWW/HTTP :: Dynamic Content",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    package_data={
        "crt": ["assets/logo.ico"],
    },
    python_requires=">=3.8",
    # install_requires=requirements,
    include_package_data=True,
    zip_safe=False,
)
