# Builtin cognitive skills shipped with cc-cortex.
# These are high-quality defaults that users can override
# by placing their own version in .claude/skills/<name>/SKILL.md
