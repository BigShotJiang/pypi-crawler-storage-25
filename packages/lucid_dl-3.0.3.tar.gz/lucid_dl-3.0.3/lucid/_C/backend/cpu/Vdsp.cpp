// lucid/_C/backend/cpu/Vdsp.cpp
//
// Implements the vDSP wrapper functions declared in Vdsp.h.  Each function is
// a one-line delegate to the corresponding Apple Accelerate vDSP_* intrinsic
// with unit stride (ia=1, ib=1, ic=1).  The anonymous helper L() converts the
// Lucid std::size_t element count to vDSP_Length (also std::size_t on Apple
// Silicon, but the cast documents the intent).
//
// Note on vDSP_vsub / vDSP_vdiv argument order: vDSP uses (B, ib, A, ia, C,
// ic, N) with the convention C = A - B and C = A / B.  Both vsub_f32 and
// vdiv_f32 therefore swap the a/b argument order when calling vDSP so that the
// wrapper's semantics match the caller's expectation (out = a op b).

#include "Vdsp.h"

#include <complex>
#include <cstring>

#include <Accelerate/Accelerate.h>

namespace lucid::backend::cpu {

namespace {

// Converts a std::size_t element count to the vDSP_Length type expected by
// the Accelerate framework APIs.
inline vDSP_Length L(std::size_t n) {
    return static_cast<vDSP_Length>(n);
}

}  // namespace

void vadd_f32(const float* a, const float* b, float* out, std::size_t n) {
    vDSP_vadd(a, 1, b, 1, out, 1, L(n));
}

void vsub_f32(const float* a, const float* b, float* out, std::size_t n) {
    vDSP_vsub(b, 1, a, 1, out, 1, L(n));
}

void vmul_f32(const float* a, const float* b, float* out, std::size_t n) {
    vDSP_vmul(a, 1, b, 1, out, 1, L(n));
}

void vdiv_f32(const float* a, const float* b, float* out, std::size_t n) {
    vDSP_vdiv(b, 1, a, 1, out, 1, L(n));
}

void vadd_f64(const double* a, const double* b, double* out, std::size_t n) {
    vDSP_vaddD(a, 1, b, 1, out, 1, L(n));
}

void vsub_f64(const double* a, const double* b, double* out, std::size_t n) {
    vDSP_vsubD(b, 1, a, 1, out, 1, L(n));
}

void vmul_f64(const double* a, const double* b, double* out, std::size_t n) {
    vDSP_vmulD(a, 1, b, 1, out, 1, L(n));
}

void vdiv_f64(const double* a, const double* b, double* out, std::size_t n) {
    vDSP_vdivD(b, 1, a, 1, out, 1, L(n));
}

void vneg_f32(const float* in, float* out, std::size_t n) {
    vDSP_vneg(in, 1, out, 1, L(n));
}

void vabs_f32(const float* in, float* out, std::size_t n) {
    vDSP_vabs(in, 1, out, 1, L(n));
}

void vsq_f32(const float* in, float* out, std::size_t n) {
    vDSP_vsq(in, 1, out, 1, L(n));
}

void vneg_f64(const double* in, double* out, std::size_t n) {
    vDSP_vnegD(in, 1, out, 1, L(n));
}

void vabs_f64(const double* in, double* out, std::size_t n) {
    vDSP_vabsD(in, 1, out, 1, L(n));
}

void vsq_f64(const double* in, double* out, std::size_t n) {
    vDSP_vsqD(in, 1, out, 1, L(n));
}

void vsadd_f32(const float* in, float scalar, float* out, std::size_t n) {
    vDSP_vsadd(in, 1, &scalar, out, 1, L(n));
}

void vsmul_f32(const float* in, float scalar, float* out, std::size_t n) {
    vDSP_vsmul(in, 1, &scalar, out, 1, L(n));
}

void vsadd_f64(const double* in, double scalar, double* out, std::size_t n) {
    vDSP_vsaddD(in, 1, &scalar, out, 1, L(n));
}

void vsmul_f64(const double* in, double scalar, double* out, std::size_t n) {
    vDSP_vsmulD(in, 1, &scalar, out, 1, L(n));
}

void vrelu_f32(const float* in, float* out, std::size_t n) {
    float zero = 0.0f;
    vDSP_vthres(in, 1, &zero, out, 1, L(n));
}

void vrelu_f64(const double* in, double* out, std::size_t n) {
    double zero = 0.0;
    vDSP_vthresD(in, 1, &zero, out, 1, L(n));
}

void vmax_f32(const float* a, const float* b, float* out, std::size_t n) {
    vDSP_vmax(a, 1, b, 1, out, 1, L(n));
}

void vmin_f32(const float* a, const float* b, float* out, std::size_t n) {
    vDSP_vmin(a, 1, b, 1, out, 1, L(n));
}

void vmax_f64(const double* a, const double* b, double* out, std::size_t n) {
    vDSP_vmaxD(a, 1, b, 1, out, 1, L(n));
}

void vmin_f64(const double* a, const double* b, double* out, std::size_t n) {
    vDSP_vminD(a, 1, b, 1, out, 1, L(n));
}

void vge_mask_f32(const float* a, const float* b, float* out, std::size_t n) {
    for (std::size_t i = 0; i < n; ++i)
        out[i] = (a[i] >= b[i]) ? 1.0f : 0.0f;
}

void vle_mask_f32(const float* a, const float* b, float* out, std::size_t n) {
    for (std::size_t i = 0; i < n; ++i)
        out[i] = (a[i] < b[i]) ? 1.0f : 0.0f;
}

void vge_mask_f64(const double* a, const double* b, double* out, std::size_t n) {
    for (std::size_t i = 0; i < n; ++i)
        out[i] = (a[i] >= b[i]) ? 1.0 : 0.0;
}

void vle_mask_f64(const double* a, const double* b, double* out, std::size_t n) {
    for (std::size_t i = 0; i < n; ++i)
        out[i] = (a[i] < b[i]) ? 1.0 : 0.0;
}

float vsum_f32(const float* in, std::size_t n) {
    float s = 0.f;
    vDSP_sve(in, 1, &s, L(n));
    return s;
}
double vsum_f64(const double* in, std::size_t n) {
    double s = 0.0;
    vDSP_sveD(in, 1, &s, L(n));
    return s;
}
float vmean_f32(const float* in, std::size_t n) {
    float m = 0.f;
    vDSP_meanv(in, 1, &m, L(n));
    return m;
}
double vmean_f64(const double* in, std::size_t n) {
    double m = 0.0;
    vDSP_meanvD(in, 1, &m, L(n));
    return m;
}
float vmaxval_f32(const float* in, std::size_t n) {
    float m = 0.f;
    vDSP_maxv(in, 1, &m, L(n));
    return m;
}
double vmaxval_f64(const double* in, std::size_t n) {
    double m = 0.0;
    vDSP_maxvD(in, 1, &m, L(n));
    return m;
}
float vdotpr_f32(const float* a, const float* b, std::size_t n) {
    float s = 0.f;
    vDSP_dotpr(a, 1, b, 1, &s, L(n));
    return s;
}
double vdotpr_f64(const double* a, const double* b, std::size_t n) {
    double s = 0.0;
    vDSP_dotprD(a, 1, b, 1, &s, L(n));
    return s;
}
void vmadd_f32(const float* a, const float* b, const float* c, float* out, std::size_t n) {
    vDSP_vma(a, 1, b, 1, c, 1, out, 1, L(n));
}
void vmadd_f64(const double* a, const double* b, const double* c, double* out, std::size_t n) {
    vDSP_vmaD(a, 1, b, 1, c, 1, out, 1, L(n));
}

void vadd_i32(const std::int32_t* a, const std::int32_t* b, std::int32_t* out, std::size_t n) {
    for (std::size_t i = 0; i < n; ++i)
        out[i] = a[i] + b[i];
}

void vadd_i64(const std::int64_t* a, const std::int64_t* b, std::int64_t* out, std::size_t n) {
    for (std::size_t i = 0; i < n; ++i)
        out[i] = a[i] + b[i];
}

void vzmul_c64(const float* a, const float* b, float* out, std::size_t n) {
    // vDSP's ``zvmul`` operates on split-complex ``DSPSplitComplex`` (separate
    // real / imag arrays), but Lucid's C64 storage is interleaved
    // ``[re, im, re, im, ...]``.  Going through ``vDSP_ctoz`` + ``zvmul``
    // + ``vDSP_ztoc`` would mean two extra full passes over the data; a
    // straight ``std::complex<float>`` loop is simpler and the compiler
    // auto-vectorises it with NEON on Apple Silicon.
    const auto* ac = reinterpret_cast<const std::complex<float>*>(a);
    const auto* bc = reinterpret_cast<const std::complex<float>*>(b);
    auto* oc = reinterpret_cast<std::complex<float>*>(out);
    for (std::size_t i = 0; i < n; ++i)
        oc[i] = ac[i] * bc[i];
}

void vzconj_c64(const float* a, float* out, std::size_t n) {
    // Copy the full interleaved buffer, then negate only the imag halves
    // via a stride-2 view starting at offset 1.  ``vDSP_vneg`` handles the
    // stride natively.
    std::memcpy(out, a, n * 2 * sizeof(float));
    vDSP_vneg(out + 1, 2, out + 1, 2, L(n));
}

}  // namespace lucid::backend::cpu
