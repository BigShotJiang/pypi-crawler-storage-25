-- Enable pg_cron and pg_net for scheduled email delivery
CREATE EXTENSION IF NOT EXISTS pg_cron WITH SCHEMA pg_catalog;
CREATE EXTENSION IF NOT EXISTS pg_net WITH SCHEMA extensions;

-- Schedule hourly trigger for send-scheduled edge function
SELECT cron.schedule(
  'distillate-scheduled-emails',
  '0 * * * *',
  $$SELECT net.http_post(
    url := 'https://eplzanzldszhyfbvlego.supabase.co/functions/v1/send-scheduled',
    headers := '{"Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImVwbHphbnpsZHN6aHlmYnZsZWdvIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3NDI0NTQ2MSwiZXhwIjoyMDg5ODIxNDYxfQ.8x4FcgmeIXhKNPuhS7wcCLPVvv9GW_RN5WNP-yYFieU"}'::jsonb,
    body := '{}'::jsonb
  );$$
);
