"""atlassiancli — zero-pip-dep Python CLI for Atlassian (Jira + Confluence) operations."""

from importlib.metadata import PackageNotFoundError
from importlib.metadata import version as _pkg_version

try:
    # Read from the installed distribution metadata so the version is always
    # in lockstep with `pyproject.toml` (which release-please bumps). No
    # hardcoded string here — eliminates the dual-source drift footgun.
    __version__ = _pkg_version("inovagio-atlassian")
except PackageNotFoundError:
    # Editable check-out without metadata installed (rare — `pip install -e .`
    # writes the metadata). Fall back to a sentinel rather than crashing.
    __version__ = "0.0.0+local"


# Lazy import to avoid module execution warning when running with `python -m`
def cli_main() -> int:
    """Entry point for CLI - lazy import to avoid double-import warning"""
    from atlassiancli.cli.main import main

    return main()


__all__ = ["__version__", "cli_main"]
