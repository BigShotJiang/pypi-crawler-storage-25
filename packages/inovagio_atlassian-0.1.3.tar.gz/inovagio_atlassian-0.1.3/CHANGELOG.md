# Changelog

All notable changes to atlassiancli are documented here.
The format is based on [Keep a Changelog](https://keepachangelog.com/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [0.1.3](https://github.com/inovagio/atlassiancli/compare/v0.1.2...v0.1.3) (2026-05-09)


### Bug Fixes

* **docs:** drop stale hardcoded v0.1.0 from README ([#34](https://github.com/inovagio/atlassiancli/issues/34)) ([44c612f](https://github.com/inovagio/atlassiancli/commit/44c612f6af3b168a64d3b68d5c4ecc2665e47499))

## [0.1.2](https://github.com/inovagio/atlassiancli/compare/v0.1.1...v0.1.2) (2026-05-09)


### Bug Fixes

* **version:** read __version__ from package metadata ([#32](https://github.com/inovagio/atlassiancli/issues/32)) ([f6e06b4](https://github.com/inovagio/atlassiancli/commit/f6e06b4c8fe2cf579a0b89a66691e53bd672af7a))

## [0.1.1](https://github.com/inovagio/atlassiancli/compare/v0.1.0...v0.1.1) (2026-05-09)


### Documentation

* reframe — DevCycle is the system; CLI is one of three components ([#29](https://github.com/inovagio/atlassiancli/issues/29)) ([fe22182](https://github.com/inovagio/atlassiancli/commit/fe22182c786b7d89fd7badcb9cfb9854f21d4565))
* reframe as autonomous AI-agent development system ([#28](https://github.com/inovagio/atlassiancli/issues/28)) ([da644cb](https://github.com/inovagio/atlassiancli/commit/da644cb95c829c6b7452717f0af00d80eead9a47))

## [Unreleased]

### Changed
- **PyPI distribution name renamed from `atlassiancli` to `inovagio-atlassian`.** The `atlassian-cli` name on PyPI is taken and PyPI's normalizer treats `atlassiancli` as the same canonical name, so the package publishes under the org-prefixed form. The installed binary command stays `atlassiancli` and the importable Python module stays `atlassiancli` — only the `pip install` line changes.
  - Old (never actually published): `pip install atlassiancli`
  - New: `pip install inovagio-atlassian`
- OSS governance + supply-chain hardening: SECURITY.md / CODE_OF_CONDUCT.md / CODEOWNERS / SUPPORT.md, issue + PR templates, SHA-pinned actions in CI/release, least-privilege workflow permissions, deployment environments (`pypi` with required reviewer, `test-pypi` tag-only), CodeQL default setup, secret scanning + push protection, Dependabot security updates.
- CI runner unified on pytest (drops broken `unittest discover` step that was hidden by Actions being disabled at the org).

### Added
- Stack-aware SOP autogeneration: `framework bootstrap --auto-sops` (default ON) detects Python / TypeScript / Go / Rust / C++ / Java / Kotlin / C# / Ruby / JavaScript and emits SOPs tuned to the toolchain. New `framework regenerate-sops` command.
- `atlassiancli review <KEY>` — unified story-time gate composing `analyze ready` + `analyze sop` + `analyze architecture` with worst-of verdict.
- Multi-tenant profiles via `~/.atlassiancli/<profile>.toml` and an interactive `configure` wizard.

## [0.1.0] - 2026-05-09

### Added
- Initial release: standalone, zero-pip-dep Python 3.12+ CLI
- 24+ Atlassian basics subcommands (create / analyze / transition / sprint / report / docs / etc.)
- Agent-callable layer: `--json` output, exit-code contract (0 / 1 / 75 / 77), idempotency guarantees
- Story analysis tier: `analyze lint`, `analyze atomicity`, `analyze ready`, `enhance`, `template`
- Doc framework bridge: `framework {create-stories,verify-stories,reverse-sync,sync-docs,bootstrap}`
- Pure-Python YAML codec, stdlib HTTP client, stdlib `.env` loader
- Markdown to Confluence storage XHTML formatter
- DDD-layered architecture (domain / application / infrastructure / cli)
- CI workflows (push + PR), release workflow (tag-triggered, manual approval to PyPI)
- Examples: minimal-project, doc-framework-product, agent-driven-workflow

[Unreleased]: https://github.com/inovagio/atlassiancli/compare/v0.1.0...HEAD
[0.1.0]: https://github.com/inovagio/atlassiancli/releases/tag/v0.1.0
