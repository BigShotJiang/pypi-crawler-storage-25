"""Tests for magnitude model."""
