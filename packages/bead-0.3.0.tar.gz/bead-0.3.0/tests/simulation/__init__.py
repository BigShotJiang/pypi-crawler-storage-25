"""Tests for simulation module."""
