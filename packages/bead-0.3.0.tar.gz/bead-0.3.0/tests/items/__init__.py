"""Tests for items module."""
