"""Tests for bead adapters."""
