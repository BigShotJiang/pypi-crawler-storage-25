"""Tests for the public-corpus loader and the public-slice provenance.

Numbers locked to Phase 4.8 frozen corpus (510 closed-problem instances
plus 50 C4-OPEN instances; 560 total, 393 public / 167 hidden):
  - 560 total instances, 393 public (70 pct), 167 hidden (30 pct)
  - Public axis breakdown: C1=134, C2=162, C3=62, C4O=35
  - Source corpus SHA-256: a8c9842ea4d59072802689603b1e38c679fd1695194aa1cf73f81c076903daf6
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from conjure_eval.corpus import (
    PUBLIC_CORPUS_PATH,
    load_public_corpus,
    public_instance_by_id,
    public_instance_ids,
)

_EXPECTED_COUNT = 393
_EXPECTED_AXIS_COUNTS = {"C1": 134, "C2": 162, "C3": 62, "C4O": 35}
_EXPECTED_SHA256 = (
    "a8c9842ea4d59072802689603b1e38c679fd1695194aa1cf73f81c076903daf6"
)
_EXPECTED_PHASE = "4.8"


def test_public_corpus_loads_and_has_expected_size():
    corpus = load_public_corpus()
    assert "instances" in corpus
    assert len(corpus["instances"]) == _EXPECTED_COUNT, (
        f"public slice must be {_EXPECTED_COUNT} instances "
        f"(Phase 4.8 frozen corpus, 70 pct of 560)"
    )


def test_public_axis_split_matches_committed_provenance():
    corpus = load_public_corpus()
    counts: dict[str, int] = {}
    for inst in corpus["instances"]:
        counts[inst["axis"]] = counts.get(inst["axis"], 0) + 1
    assert counts == _EXPECTED_AXIS_COUNTS

    prov = corpus.get("public_split_provenance")
    assert prov is not None
    assert prov["split_schema_version"] == "1.0"
    assert prov["split_seed"] == 4317
    assert prov["split_public_ratio"] == 0.7
    assert prov["public_axis_counts"] == _EXPECTED_AXIS_COUNTS
    assert prov["corpus_sha256"] == _EXPECTED_SHA256
    assert prov.get("frozen_corpus_phase") == _EXPECTED_PHASE


def test_public_corpus_axis_counts_field_matches_instances():
    """The top-level axis_counts must match what is actually in instances."""
    corpus = load_public_corpus()
    actual: dict[str, int] = {}
    for inst in corpus["instances"]:
        actual[inst["axis"]] = actual.get(inst["axis"], 0) + 1
    assert corpus.get("axis_counts") == actual, (
        "corpus top-level axis_counts drifted from the actual instance list; "
        "re-run scripts/build_conjure_split.py to fix"
    )
    assert corpus.get("expected_count") == len(corpus["instances"]), (
        "corpus top-level expected_count drifted from actual instance count"
    )


def test_public_instance_ids_are_sorted_and_393_long():
    ids = public_instance_ids()
    assert ids == sorted(ids)
    assert len(ids) == _EXPECTED_COUNT


def test_public_instance_by_id_round_trips():
    iid = public_instance_ids()[0]
    inst = public_instance_by_id(iid)
    assert inst.instance_id == iid
    assert inst.axis in {"C1", "C2", "C3", "C4O"}
    assert isinstance(inst.prompt, str)


def test_public_instance_by_id_rejects_unknown_id():
    with pytest.raises(KeyError, match="not in the public slice"):
        public_instance_by_id("Not-A-Real-Id")


def test_public_corpus_file_is_packaged_data():
    assert Path(str(PUBLIC_CORPUS_PATH)).exists()
    json.loads(Path(str(PUBLIC_CORPUS_PATH)).read_text(encoding="utf-8"))
