"""Tests for the conjure-eval model runner and the `run` CLI subcommand."""

from __future__ import annotations

import io
import json
import urllib.error
import urllib.request
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from conjure_eval.cli import main
from conjure_eval.corpus import load_public_corpus
from conjure_eval.runner import RunRecord, run_against_endpoint


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _fake_completion(content: str = "def P := True") -> bytes:
    """Return a minimal OpenAI chat-completions JSON response body."""
    return json.dumps(
        {
            "choices": [
                {"message": {"role": "assistant", "content": content}}
            ]
        }
    ).encode()


def _fake_urlopen(response_bytes: bytes):
    """Return a context-manager mock that reads ``response_bytes``."""
    mock_resp = MagicMock()
    mock_resp.__enter__ = lambda s: s
    mock_resp.__exit__ = MagicMock(return_value=False)
    mock_resp.read.return_value = response_bytes
    return mock_resp


# ---------------------------------------------------------------------------
# Unit tests on run_against_endpoint
# ---------------------------------------------------------------------------

def test_run_happy_path_writes_jsonl(tmp_path: Path):
    out = tmp_path / "subs.jsonl"
    fake_instances = [
        {"instance_id": "C1-bv-001", "axis": "C1", "prompt": "stub prompt"},
        {"instance_id": "C1-bv-002", "axis": "C1", "prompt": "stub prompt 2"},
    ]
    with patch("urllib.request.urlopen", return_value=_fake_urlopen(_fake_completion())):
        records = run_against_endpoint(
            base_url="https://fake.endpoint/v1",
            api_key="tok",
            model="test-model",
            out_path=str(out),
            instances=fake_instances,
        )

    assert len(records) == 2
    lines = [l for l in out.read_text().splitlines() if l.strip()]
    assert len(lines) == 2
    for line in lines:
        rec = json.loads(line)
        assert rec["submission"] == "def P := True"
        assert rec["model"] == "test-model"
        assert rec["error"] is None


def test_run_limit_stops_early(tmp_path: Path):
    out = tmp_path / "subs.jsonl"
    corpus = load_public_corpus()
    with patch("urllib.request.urlopen", return_value=_fake_urlopen(_fake_completion())):
        records = run_against_endpoint(
            base_url="https://fake.endpoint/v1",
            api_key="tok",
            model="test-model",
            out_path=str(out),
            instances=corpus["instances"],
            limit=3,
        )
    assert len(records) == 3
    lines = [l for l in out.read_text().splitlines() if l.strip()]
    assert len(lines) == 3


def test_run_retries_on_429_then_succeeds(tmp_path: Path):
    out = tmp_path / "subs.jsonl"
    fake_instances = [
        {"instance_id": "C1-bv-001", "axis": "C1", "prompt": "stub"},
    ]
    call_count = {"n": 0}

    def _side_effect(req, timeout):
        call_count["n"] += 1
        if call_count["n"] < 3:
            raise urllib.error.HTTPError(
                url="", code=429, msg="Too Many Requests",
                hdrs=None, fp=None,
            )
        return _fake_urlopen(_fake_completion())

    with patch("urllib.request.urlopen", side_effect=_side_effect):
        records = run_against_endpoint(
            base_url="https://fake.endpoint/v1",
            api_key="tok",
            model="test-model",
            out_path=str(out),
            instances=fake_instances,
            max_retries=3,
        )

    assert call_count["n"] == 3
    assert records[0].error is None
    assert records[0].submission == "def P := True"


def test_run_records_error_on_http_failure(tmp_path: Path):
    out = tmp_path / "subs.jsonl"
    fake_instances = [
        {"instance_id": "C1-bv-001", "axis": "C1", "prompt": "stub"},
    ]
    with patch(
        "urllib.request.urlopen",
        side_effect=urllib.error.HTTPError(
            url="", code=500, msg="Internal Server Error",
            hdrs=None, fp=None,
        ),
    ):
        records = run_against_endpoint(
            base_url="https://fake.endpoint/v1",
            api_key="tok",
            model="test-model",
            out_path=str(out),
            instances=fake_instances,
            max_retries=0,
        )

    assert records[0].error is not None
    assert "500" in records[0].error or "HTTPError" in records[0].error
    # Record still written even on failure.
    lines = [l for l in out.read_text().splitlines() if l.strip()]
    assert len(lines) == 1


# ---------------------------------------------------------------------------
# CLI tests
# ---------------------------------------------------------------------------

def test_cli_run_missing_api_key_env_returns_2(
    tmp_path: Path, capsys: pytest.CaptureFixture, monkeypatch: pytest.MonkeyPatch
):
    monkeypatch.delenv("MISSING_KEY_XYZ", raising=False)
    rc = main([
        "run",
        "--base-url", "https://fake/v1",
        "--api-key-env", "MISSING_KEY_XYZ",
        "--model", "m",
        "--out", str(tmp_path / "out.jsonl"),
    ])
    assert rc == 2
    err = capsys.readouterr().err
    assert "MISSING_KEY_XYZ" in err


def test_cli_run_limit_2_produces_well_formed_jsonl(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
):
    monkeypatch.setenv("TEST_API_KEY", "fake-token")
    out = tmp_path / "subs.jsonl"
    with patch("urllib.request.urlopen", return_value=_fake_urlopen(_fake_completion())):
        rc = main([
            "run",
            "--base-url", "https://fake/v1",
            "--api-key-env", "TEST_API_KEY",
            "--model", "test-model",
            "--out", str(out),
            "--limit", "2",
        ])
    assert rc == 0
    lines = [l for l in out.read_text().splitlines() if l.strip()]
    assert len(lines) == 2
    # All records must pass verify-submission
    rc2 = main(["verify-submission", str(out)])
    assert rc2 == 0
