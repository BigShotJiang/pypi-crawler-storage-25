"""Frozen public-corpus data for `conjure-eval`."""
