"""Public-corpus loader for `conjure-eval`.

The frozen public-slice corpus JSON ships as package data under
`conjure_eval/data/public_corpus.json`. This module loads it lazily and
exposes a thin typed view over the instance records.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from importlib import resources
from typing import Any


PUBLIC_CORPUS_RESOURCE = ("conjure_eval.data", "public_corpus.json")

# Filesystem path is exposed for tests and the CLI; package-data lookup is
# the source of truth at runtime.
PUBLIC_CORPUS_PATH = resources.files("conjure_eval.data").joinpath(
    "public_corpus.json"
)


@dataclass(frozen=True)
class Instance:
    """A single public-slice CONJURE instance.

    The `raw` field preserves the full source JSON record so downstream
    tooling can read schema fields this package doesn't model yet.
    """

    instance_id: str
    axis: str
    prompt: str
    raw: dict[str, Any]


def load_public_corpus() -> dict[str, Any]:
    """Return the parsed public-corpus JSON.

    Raises
    ------
    FileNotFoundError
        If the package was installed without the data file present (i.e.,
        somebody mis-built the wheel).
    """
    pkg, name = PUBLIC_CORPUS_RESOURCE
    text = resources.files(pkg).joinpath(name).read_text(encoding="utf-8")
    return json.loads(text)


def public_instance_ids() -> list[str]:
    """Return the sorted list of public instance IDs."""
    corpus = load_public_corpus()
    return sorted(inst["instance_id"] for inst in corpus["instances"])


def public_instance_by_id(instance_id: str) -> Instance:
    """Look up a single public-slice instance by ID.

    Raises
    ------
    KeyError
        If the ID is not part of the public slice.
    """
    corpus = load_public_corpus()
    for inst in corpus["instances"]:
        if inst["instance_id"] == instance_id:
            return Instance(
                instance_id=inst["instance_id"],
                axis=inst["axis"],
                prompt=inst.get("prompt", ""),
                raw=inst,
            )
    raise KeyError(
        f"{instance_id!r} is not in the public slice (or not present in "
        f"this conjure-eval release)"
    )
