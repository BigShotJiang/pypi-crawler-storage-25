"""Model runner for the CONJURE public-slice evaluation.

Drives an OpenAI-compatible chat-completions endpoint against every instance
in the public slice and writes one JSONL record per instance to an output
file. Requires no third-party libraries: only the Python standard library.

Usage via CLI:

    conjure-eval run \\
        --base-url https://api.openai.com/v1 \\
        --api-key-env OPENAI_API_KEY \\
        --model gpt-4o \\
        --out submissions.jsonl

For Anthropic's Mythos (OpenAI-compatible endpoint):

    conjure-eval run \\
        --base-url $MYTHOS_BASE_URL \\
        --api-key-env MYTHOS_API_KEY \\
        --model mythos-frontier \\
        --out submissions.jsonl

The output JSONL passes ``conjure-eval verify-submission`` so you can check
it is well-formed before sending it to the hidden-split adjudicator.

Author: Patrick Cooper.
"""

from __future__ import annotations

import json
import os
import time
import urllib.error
import urllib.request
from dataclasses import asdict, dataclass
from typing import Any


_CHAT_COMPLETIONS_PATH = "/chat/completions"


@dataclass
class RunRecord:
    """One row in the output JSONL."""

    instance_id: str
    submission: str
    model: str
    latency_ms: float
    error: str | None = None

    def to_jsonl_line(self) -> str:
        return json.dumps(asdict(self), ensure_ascii=False)


def _build_request(
    base_url: str,
    api_key: str,
    model: str,
    prompt: str,
    timeout_s: float,
) -> tuple[urllib.request.Request, float]:
    """Return (Request, timeout_seconds)."""
    url = base_url.rstrip("/") + _CHAT_COMPLETIONS_PATH
    payload = json.dumps(
        {
            "model": model,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 4096,
        },
        ensure_ascii=False,
    ).encode()
    req = urllib.request.Request(
        url,
        data=payload,
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
        },
        method="POST",
    )
    return req, timeout_s


def _extract_submission(response_body: bytes) -> str:
    """Pull the first choice's message content out of a chat-completions response."""
    data: dict[str, Any] = json.loads(response_body)
    choices = data.get("choices") or []
    if not choices:
        raise ValueError("response has no choices")
    return choices[0]["message"]["content"]


def _call_with_retry(
    req: urllib.request.Request,
    timeout_s: float,
    max_retries: int,
) -> bytes:
    """Call the endpoint with exponential back-off on 429 / 5xx."""
    delay = 1.0
    for attempt in range(max_retries + 1):
        try:
            with urllib.request.urlopen(req, timeout=timeout_s) as resp:
                return resp.read()
        except urllib.error.HTTPError as exc:
            if attempt == max_retries:
                raise
            if exc.code in (429, 500, 502, 503, 504):
                time.sleep(delay)
                delay = min(delay * 2, 60.0)
                continue
            raise
    raise RuntimeError("unreachable")


def run_against_endpoint(
    *,
    base_url: str,
    api_key: str,
    model: str,
    out_path: str,
    instances: list[dict[str, Any]],
    limit: int | None = None,
    rate_limit_ms: int = 0,
    max_retries: int = 3,
    timeout_s: float = 120.0,
    progress_fn: Any = None,
) -> list[RunRecord]:
    """Drive the endpoint and write submissions to ``out_path``.

    Parameters
    ----------
    base_url:
        OpenAI-compatible base URL, e.g. ``https://api.openai.com/v1``.
    api_key:
        Bearer token for the endpoint.
    model:
        Model name string passed to the endpoint.
    out_path:
        Path to the output JSONL file. Opened in append mode so partial runs
        can be resumed manually.
    instances:
        List of public-slice instance dicts (from ``load_public_corpus()``).
    limit:
        If set, stop after this many instances (useful for smoke tests).
    rate_limit_ms:
        Milliseconds to sleep between requests. Defaults to 0.
    max_retries:
        Maximum number of retries on 429 / 5xx before giving up.
    timeout_s:
        Per-request HTTP timeout in seconds.
    progress_fn:
        Optional callable ``progress_fn(i: int, total: int, record: RunRecord)``
        called after each request, for progress reporting.

    Returns
    -------
    list[RunRecord]
        One record per instance processed.
    """
    subset = instances[:limit] if limit is not None else instances
    records: list[RunRecord] = []

    with open(out_path, "a", encoding="utf-8") as fh:
        for i, inst in enumerate(subset):
            iid = inst["instance_id"]
            prompt = inst.get("prompt", "")
            t0 = time.monotonic()
            error: str | None = None
            submission = ""

            try:
                req, tout = _build_request(
                    base_url, api_key, model, prompt, timeout_s
                )
                body = _call_with_retry(req, tout, max_retries)
                submission = _extract_submission(body)
            except Exception as exc:
                error = f"{type(exc).__name__}: {exc}"

            latency_ms = (time.monotonic() - t0) * 1000.0
            rec = RunRecord(
                instance_id=iid,
                submission=submission,
                model=model,
                latency_ms=round(latency_ms, 1),
                error=error,
            )
            fh.write(rec.to_jsonl_line() + "\n")
            fh.flush()
            records.append(rec)

            if progress_fn is not None:
                progress_fn(i + 1, len(subset), rec)

            if rate_limit_ms > 0 and i < len(subset) - 1:
                time.sleep(rate_limit_ms / 1000.0)

    return records
