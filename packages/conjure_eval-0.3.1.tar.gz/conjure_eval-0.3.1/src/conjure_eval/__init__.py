"""Public-slice harness for the CONJURE transformative-creativity benchmark.

This package ships the 393-instance public split (70 percent of the
560-instance Phase 4.8 frozen corpus, 510 closed-problem instances
across 17 Lakatos families plus the 50-instance C4-OPEN axis of
formalised open mathematical conjectures). See README.md for the full
description and the hidden-split policy.
"""

from __future__ import annotations

from .corpus import (
    PUBLIC_CORPUS_PATH,
    Instance,
    load_public_corpus,
    public_instance_ids,
    public_instance_by_id,
)

__all__ = [
    "PUBLIC_CORPUS_PATH",
    "Instance",
    "load_public_corpus",
    "public_instance_ids",
    "public_instance_by_id",
    "__version__",
]

__version__ = "0.3.1"
