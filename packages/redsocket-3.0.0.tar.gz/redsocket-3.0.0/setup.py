from setuptools import setup, find_packages

setup(
    name="RedSocket",  # Il nome del pacchetto
    version="3.0.0",  # Versione con formato x.y.z
    packages=find_packages(),
    install_requires=[  # Le dipendenze del pacchetto
        'nmap',  # Dipendenza
    ],
    entry_points={
        'console_scripts': [
            'redsocket=redsocket:redsocket',  # Comando principale per il programma
        ],
    },
    author="Phantom",  # Il tuo nome
    author_email="tuo-email@example.com",  # La tua email
    description="A tool that automates Nmap scans and saves results to a file.",
    long_description=open('README.md').read(),  # Descrizione lunga
    long_description_content_type='text/markdown',  # Tipo di descrizione
    url="https://github.com/phantomsecuritydev-ctrl/RedSocket",  # URL del progetto su GitHub
    license="GPL-3.0",  # Licenza
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: GNU General Public License v3 (GPLv3)",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.8',  # Versione minima di Python
)
