"""Command-line interface for dlprac package."""

from pathlib import Path
import shutil

import click

from . import __version__, get_notebooks_path, list_notebooks


DOWNLOAD_SUBDIR = "dlprac_files"


@click.group()
@click.version_option(version=__version__)
def main() -> None:
    """dlprac - Deep Learning Practice Files."""


@main.command()
@click.option(
    "--dest",
    "-d",
    default=".",
    help="Base directory where a dlprac_files subfolder will be created",
)
@click.option(
    "--list",
    "-l",
    "list_only",
    is_flag=True,
    help="List available files without downloading",
)
def download(dest: str, list_only: bool) -> None:
    """Download packaged practice files into a subfolder under destination."""
    notebooks = list_notebooks()

    if not notebooks:
        click.echo("No practice files found in the package.", err=True)
        return

    if list_only:
        click.echo(f"Available practice files ({len(notebooks)}):")
        for nb in notebooks:
            click.echo(f"  - {nb}")
        return

    base_dest_path = Path(dest).resolve()
    dest_path = base_dest_path / DOWNLOAD_SUBDIR
    dest_path.mkdir(parents=True, exist_ok=True)

    source_path = get_notebooks_path()
    click.echo(
        f"Downloading {len(notebooks)} practice files to {dest_path}..."
    )

    success_count = 0
    for notebook in notebooks:
        src = source_path / notebook
        dst = dest_path / notebook
        try:
            shutil.copy2(src, dst)
            click.echo(f"  OK {notebook}")
            success_count += 1
        except OSError as exc:
            click.echo(f"  FAIL {notebook} - Error: {exc}", err=True)

    click.echo(
        f"\nSuccessfully downloaded {success_count}/{len(notebooks)} practice files!"
    )


@main.command()
def info() -> None:
    """Display package information."""
    notebooks = list_notebooks()
    click.echo(f"dlprac version: {__version__}")
    click.echo(f"Total practice files: {len(notebooks)}")
    click.echo(f"Practice files location: {get_notebooks_path()}")
    click.echo("\nTo download files, run:")
    click.echo("  dlprac download")


if __name__ == "__main__":
    main()
