'''
Analyze the convergence behavior and performance of a supervised single-layer feedforward neural network
trained using different learning algorithms (SGD, Mini-Batch GD, Batch GD). Compare their efficiency and
training outcomes.
'''

import numpy as np
import matplotlib.pyplot as plt 
# Dataset: Area vs Price
X = np.array([
500, 520, 540, 560, 580, 600, 620, 640, 660, 680,
700, 720, 740, 760, 780, 800, 820, 840, 860, 880,
900, 920, 940, 960, 980,1000,1020,1040,1060,1080,
1100,1120,1140,1160,1180,1200,1220,1240,1260,1280,
1300,1320,1340,1360,1380,1400,1420,1440,1460,1480,
1500,1520,1540,1560,1580,1600,1620,1640,1660,1680,
1700,1720,1740,1760,1780,1800,1820,1840,1860,1880,
1900,1920,1940,1960,1980,2000,2020,2040,2060,2080,
2100,2120,2140,2160,2180,2200,2220,2240,2260,2280
], dtype=float) / 1000 # normalize
y = np.array([
25, 26, 27, 28, 29, 30, 31, 32, 33, 34,
35, 36, 37, 38, 39, 40, 41, 42, 43, 44,
45, 46, 47, 48, 49, 50, 51, 52, 53, 54,
55, 56, 57, 58, 59, 60, 61, 62, 63, 64,
65, 66, 67, 68, 69, 70, 71, 72, 73, 74,
75, 76, 77, 78, 79, 80, 81, 82, 83, 84,
85, 86, 87, 88, 89, 90, 91, 92, 93, 94,
95, 96, 97, 98, 99,100,101,102,103,104,
105,106,107,108,109,110,111,112,113,114
], dtype=float) 
# Parameters
n = len(X)
lr = 0.01
epochs = 80
batch_size = 10
def predict(X, w, b):
    return w * X + b
def loss(y, y_hat):
    return np.mean((y - y_hat)**2)
def gradients(X, y, y_hat):
    dw = (-2/len(X)) * np.sum(X*(y - y_hat)) 
    db = (-2/len(X)) * np.sum(y - y_hat)
    return dw, db

# SGD
w_sgd, b_sgd = 0.0, 0.0
loss_sgd = []
for _ in range(epochs):
    for i in range(n):
        y_hat = predict(X[i], w_sgd, b_sgd)
        dw = -2 * X[i] * (y[i] - y_hat)
        db = -2 * (y[i] - y_hat)
        w_sgd -= lr * dw
        b_sgd -= lr * db
        loss_sgd.append(loss(y, predict(X, w_sgd, b_sgd)))
# Batch GD
w_bg, b_bg = 0.0, 0.0
loss_bg = []
for _ in range(epochs):
    y_hat = predict(X, w_bg, b_bg)
    dw, db = gradients(X, y, y_hat)
    w_bg -= lr * dw
    b_bg -= lr * db
    loss_bg.append(loss(y, predict(X, w_bg, b_bg))) 

# Mini-Batch GD
w_mbg, b_mbg = 0.0, 0.0
loss_mbg = []
for _ in range(epochs):
    for i in range(0, n, batch_size):
        Xb, yb = X[i:i+batch_size], y[i:i+batch_size]
        y_hat = predict(Xb, w_mbg, b_mbg)
        dw, db = gradients(Xb, yb, y_hat)
        w_mbg -= lr * dw
        b_mbg -= lr * db
        loss_mbg.append(loss(y, predict(X, w_mbg, b_mbg)))

# After Stochastic Gradient Descent
print(f"SGD Learned Parameters -> w: {w_sgd:.3f}, b: {b_sgd:.3f}")
# After Batch Gradient Descent
print(f"Batch GD Learned Parameters -> w: {w_bg:.3f}, b: {b_bg:.3f}")
# After Mini-Batch Gradient Descent
print(f"Mini-Batch GD Learned Parameters -> w: {w_mbg:.3f}, b: {b_mbg:.3f}")

# Plot: Predictions over Actual Data
plt.figure(figsize=(10,6))
plt.scatter(X, y, color='black', s=20, label='Actual Data')
X_line = np.linspace(min(X), max(X), 100)
plt.plot(X_line, w_sgd*X_line + b_sgd, linestyle='--', color='blue', linewidth=2, label='SGD Prediction', zorder=5)
plt.plot(X_line, w_bg*X_line + b_bg, linestyle='--', color='green', linewidth=2, label='Batch GD Prediction', zorder=5)
plt.plot(X_line, w_mbg*X_line + b_mbg, linestyle='--', color='red', linewidth=2, label='Mini-Batch Prediction', zorder=5)
plt.xlabel("House Area (1000 sq.ft)")
plt.ylabel("Price ( Rs. Lakhs)")
plt.title("House Price Predictions by Gradient Descent Variants")
plt.legend()
plt.grid(True)
plt.show() 

'''
Exercise 1:
Analyze and compare the training performance of a single-layer feedforward neural network using different
activation functions (Sigmoid, Tanh, ReLU). Assess their impact on convergence behavior, loss reduction, and
prediction outcomes. 
'''
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
# Load the dataset
df = pd.read_csv('/content/bmw.csv')
# Display the first few rows and check for missing values
print("DataFrame head:\n", df.head())
print("\nMissing values per column:\n", df.isnull().sum()) 
median_price = df['price'].median()
df['price_binary'] = (df['price'] >= median_price).astype(int)
X = df.drop(['price', 'price_binary'], axis=1)
y = df['price_binary']
print(f"Median price: {median_price}")
print("Price binary value counts:\n", y.value_counts())
print("Features (X) head:\n", X.head())
print("Target (y) head:\n", y.head()) 
categorical_cols = X.select_dtypes(include=['object']).columns
numerical_cols = X.select_dtypes(include=np.number).columns
# Apply one-hot encoding to categorical features
X_categorical = pd.get_dummies(X[categorical_cols], drop_first=True)
# Apply StandardScaler to numerical features
scaler = StandardScaler()
X_numerical_scaled = scaler.fit_transform(X[numerical_cols]) 
X_numerical_scaled = pd.DataFrame(X_numerical_scaled, columns=numerical_cols, index=X.index)
# Combine preprocessed features
X_processed = pd.concat([X_numerical_scaled, X_categorical], axis=1)
print("Preprocessed features (X_processed) head:", X_processed.head()) 
X_train, X_test, y_train, y_test = train_test_split(X_processed, y, test_size=0.2, random_state=42)
print("Shape of X_train:", X_train.shape)
print("Shape of X_test:", X_test.shape)
print("Shape of y_train:", y_train.shape)
print("Shape of y_test:", y_test.shape)


import numpy as np
# Sigmoid activation function and its derivative
def sigmoid(x):
    return 1 / (1 + np.exp(-x))
def sigmoid_derivative(a):
 # a is the output of the sigmoid function (activation)
    return a * (1 - a)
# Tanh activation function and its derivative
def tanh(x):
    return np.tanh(x)
def tanh_derivative(a):
 # a is the output of the tanh function (activation)
    return 1 - a**2
# ReLU activation function and its derivative
def relu(x):
    return np.maximum(0, x)
def relu_derivative(x):
    return np.where(x > 0, 1, 0)
print("Activation functions and their derivatives defined successfully.") 

import numpy as np 
# 1. Function to initialize weights and biases
def initialize_parameters(num_features):
    # Initialize weights with small random values to break symmetry
    W = np.random.randn(num_features, 1) * 0.01
    # Initialize bias to zero
    b = 0.0
    return W, b
# 2. Function for the forward pass
def forward_pass(X, W, b, activation_function):
    Z = X @ W + b
    A = activation_function(Z)
    return Z, A
# 3. Function to compute Binary Cross-Entropy loss
def compute_loss(y_true, y_pred):
    epsilon = 1e-10 # To prevent log(0)
    y_pred = np.clip(y_pred, epsilon, 1 - epsilon)
    loss = -np.mean(y_true * np.log(y_pred) + (1 - y_true) * np.log(1 - y_pred))
    return loss 
# 4. Function to compute accuracy
def compute_accuracy(y_true, y_pred):
    y_pred_binary = (y_pred >= 0.5).astype(int)
    accuracy = np.mean(y_pred_binary == y_true)
    return accuracy
print("Neural network core functions (initialize_parameters, forward_pass, compute_loss, compute_accuracy) defined successfully.") 


import numpy as np
# Function for the backward pass
def backward_pass(X, Z, A, y_true, activation_derivative_func):  
    m = X.shape[0] # Number of samples
    # Reshape y_true to be a column vector for consistent operations
    y_true = y_true.reshape(-1, 1)
    # Calculate dZ: gradient of loss with respect to Z.
    # For Binary Cross-Entropy loss with a single-layer network, this simplifies
    # to (A - y_true) / m when averaged, but dZ is (A - y_true) before averaging.
    # The provided instruction specifies dZ = (A - y_true).
    dZ = A - y_true
    # Calculate dW: gradient of loss with respect to weights W
    # X.T is (num_features, m), dZ is (m, 1), result is (num_features, 1)
    dW = (1/m) * X.T @ dZ
    # Calculate db: gradient of loss with respect to bias b
    # Sum dZ over all samples, result is a scalar
    db = (1/m) * np.sum(dZ)
    return dW, db
print("Backward pass function (backward_pass) defined successfully.") 


import numpy as np
# train_model function
def train_model(X_train, y_train, X_test, y_test, activation_func, activation_derivative_func, learning_rate, epochs):
    num_features = X_train.shape[1]
    # Initialize weights and bias
    W, b = initialize_parameters(num_features)
    train_losses = []
    train_accuracies = []
    for epoch in range(epochs):
        # Forward pass for training data
        Z_train, A_train = forward_pass(X_train, W, b, activation_func)
        # Reshape y_train for loss and accuracy consistency
        y_train_reshaped = y_train.values.reshape(-1, 1) if hasattr(y_train, 'values') else y_train.reshape(-1, 1)
        # Compute and store training loss
        loss = compute_loss(y_train_reshaped, A_train)
        train_losses.append(loss)
        # Compute and store training accuracy
        accuracy = compute_accuracy(y_train_reshaped, A_train)
        train_accuracies.append(accuracy)
        # Backward pass
        dW, db = backward_pass(X_train, Z_train, A_train, y_train_reshaped, activation_derivative_func)
        # Update parameters
        W -= learning_rate * dW
        b -= learning_rate * db
        # Optional: Print progress
        # if (epoch + 1) % 100 == 0:
        # print(f"Epoch {epoch+1}/{epochs}, Loss: {loss:.4f}, Accuracy: {accuracy:.4f}")
        return W, b, train_losses, train_accuracies

print("Universal training function (train_model) defined successfully.") 
learning_rate = 0.01
epochs = 1000
# Convert DataFrames/Series to NumPy arrays with float dtype before passing to the training function 
X_train_np = X_train.values.astype(float)
y_train_np = y_train.values.astype(float)
X_test_np = X_test.values.astype(float)
y_test_np = y_test.values.astype(float)
# Train model with Sigmoid activation
W_sigmoid, b_sigmoid, losses_sigmoid, accuracies_sigmoid = train_model(
 X_train_np, y_train_np, X_test_np, y_test_np, sigmoid, sigmoid_derivative, learning_rate, epochs
)
print("Sigmoid model trained.")
# Train model with Tanh activation
W_tanh, b_tanh, losses_tanh, accuracies_tanh = train_model(
 X_train_np, y_train_np, X_test_np, y_test_np, tanh, tanh_derivative, learning_rate, epochs
)
print("Tanh model trained.")
# Train model with ReLU activation
W_relu, b_relu, losses_relu, accuracies_relu = train_model(
 X_train_np, y_train_np, X_test_np, y_test_np, relu, relu_derivative, learning_rate, epochs
)
print("ReLU model trained.")
print("All three models (Sigmoid, Tanh, ReLU) have been trained successfully.") 

# Evaluate Sigmoid model
Z_train_sigmoid, A_train_sigmoid = forward_pass(X_train_np, W_sigmoid, b_sigmoid, sigmoid)
train_accuracy_sigmoid = compute_accuracy(y_train_np, A_train_sigmoid)
Z_test_sigmoid, A_test_sigmoid = forward_pass(X_test_np, W_sigmoid, b_sigmoid, sigmoid)
test_accuracy_sigmoid = compute_accuracy(y_test_np, A_test_sigmoid)
print(f"\nSigmoid - Training Accuracy: {train_accuracy_sigmoid:.4f}") 
print(f"Sigmoid - Test Accuracy: {test_accuracy_sigmoid:.4f}")
# Evaluate Tanh model
Z_train_tanh, A_train_tanh = forward_pass(X_train_np, W_tanh, b_tanh, tanh)
train_accuracy_tanh = compute_accuracy(y_train_np, A_train_tanh)
Z_test_tanh, A_test_tanh = forward_pass(X_test_np, W_tanh, b_tanh, tanh)
test_accuracy_tanh = compute_accuracy(y_test_np, A_test_tanh)
print(f"\nTanh - Training Accuracy: {train_accuracy_tanh:.4f}")
print(f"Tanh - Test Accuracy: {test_accuracy_tanh:.4f}")
# Evaluate ReLU model
Z_train_relu, A_train_relu = forward_pass(X_train_np, W_relu, b_relu, relu)
train_accuracy_relu = compute_accuracy(y_train_np, A_train_relu)
Z_test_relu, A_test_relu = forward_pass(X_test_np, W_relu, b_relu, relu)
test_accuracy_relu = compute_accuracy(y_test_np, A_test_relu)
print(f"\nReLU - Training Accuracy: {train_accuracy_relu:.4f}")
print(f"ReLU - Test Accuracy: {test_accuracy_relu:.4f}") 


'''
Exercise 2:
With the help of an example, analyze the impact of bias and variance on supervised learning models. Compare
a high-bias model and a high-variance model trained on the same dataset, and discuss their learning behavior,
error trends, and ability to generalize to unseen data. 
'''
import pandas as pd
from sklearn.model_selection import train_test_split
# Load the dataset (assuming it's available from previous steps or same path)
df = pd.read_csv('/content/bmw.csv')
# Extract 'mileage' as feature (X) and 'price' as target (y)
X_reg = df['mileage'].values.reshape(-1, 1)
y_reg = df['price'].values.reshape(-1, 1)
print("Shape of X_reg:", X_reg.shape)
print("Shape of y_reg:", y_reg.shape)
print("First 5 elements of X_reg:\n", X_reg[:5])
print("First 5 elements of y_reg:\n", y_reg[:5]) 
X_train_reg, X_test_reg, y_train_reg, y_test_reg = train_test_split(X_reg, y_reg, test_size=0.2,random_state=42)
print("Shape of X_train_reg:", X_train_reg.shape)
print("Shape of X_test_reg:", X_test_reg.shape)
print("Shape of y_train_reg:", y_train_reg.shape)
print("Shape of y_test_reg:", y_test_reg.shape) 
from sklearn.linear_model import LinearRegression
# Instantiate the LinearRegression model
linear_model = LinearRegression()
# Train the model using the training data
linear_model.fit(X_train_reg, y_train_reg)
print("Linear Regression model trained successfully.") 
from sklearn.preprocessing import PolynomialFeatures
# Instantiate PolynomialFeatures with a high degree
poly_features = PolynomialFeatures(degree=10)
# Transform X_train_reg and X_test_reg to create polynomial features
X_train_poly = poly_features.fit_transform(X_train_reg)
X_test_poly = poly_features.transform(X_test_reg)
# Instantiate a LinearRegression model
poly_model = LinearRegression()
# Train the polynomial regression model
poly_model.fit(X_train_poly, y_train_reg)
print("Polynomial Regression model (high-variance) trained successfully.")
print(f"Shape of X_train_poly: {X_train_poly.shape}")
print(f"Shape of X_test_poly: {X_test_poly.shape}") 
from sklearn.metrics import mean_squared_error
# 1. Linear Regression Model Evaluation
print("\n--- Linear Regression (High-Bias Model) ---")
# Make predictions on training and testing data
y_train_pred_linear = linear_model.predict(X_train_reg)
y_test_pred_linear = linear_model.predict(X_test_reg)
# Calculate Mean Squared Error
mse_train_linear = mean_squared_error(y_train_reg, y_train_pred_linear)
mse_test_linear = mean_squared_error(y_test_reg, y_test_pred_linear)
print(f"Training MSE (Linear Model): {mse_train_linear:.2f}")
print(f"Testing MSE (Linear Model): {mse_test_linear:.2f}")
# 2. Polynomial Regression Model Evaluation
print("\n--- Polynomial Regression (High-Variance Model) ---")
# Make predictions on training and testing data (using polynomial features)
y_train_pred_poly = poly_model.predict(X_train_poly)
y_test_pred_poly = poly_model.predict(X_test_poly)
# Calculate Mean Squared Error
mse_train_poly = mean_squared_error(y_train_reg, y_train_pred_poly)
mse_test_poly = mean_squared_error(y_test_reg, y_test_pred_poly)
print(f"Training MSE (Polynomial Model): {mse_train_poly:.2f}")
print(f"Testing MSE (Polynomial Model): {mse_test_poly:.2f}") 
import matplotlib.pyplot as plt
import numpy as np # Import numpy for linspace
# Create a figure and an axes object for the plot
plt.figure(figsize=(12, 8))
# Plot the original training data points
plt.scatter(X_train_reg, y_train_reg, s=20, label='Training Data', alpha=0.6)
# Plot the original testing data points
plt.scatter(X_test_reg, y_test_reg, s=20, label='Testing Data', alpha=0.6)
# Generate a range of X values for plotting the regression lines/curves
X_plot = np.linspace(X_reg.min(), X_reg.max(), 100).reshape(-1, 1) 
# Plot predictions of the linear regression model
y_plot_linear = linear_model.predict(X_plot)
plt.plot(X_plot, y_plot_linear, color='red', label='Linear Regression Fit', linewidth=2)
# Plot predictions of the polynomial regression model
X_plot_poly = poly_features.transform(X_plot)
y_plot_poly = poly_model.predict(X_plot_poly)
plt.plot(X_plot, y_plot_poly, color='green', label='Polynomial Regression Fit (Degree 10)', linewidth=2)
# Add title, labels, and legend
plt.title('Regression Model Fits: Linear vs. Polynomial')
plt.xlabel('Mileage')
plt.ylabel('Price')
plt.legend()
plt.grid(True)
plt.show()
