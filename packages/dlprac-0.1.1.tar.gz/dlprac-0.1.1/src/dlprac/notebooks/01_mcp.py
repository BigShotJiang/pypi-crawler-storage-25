''' 
Design a Mc-Culloch–Pitts neuron-based decision unit for a smart classroom power control system.
The neuron should accept binary inputs from an occupancy sensor and an authorized faculty detection system.
Using appropriate selection of weights and threshold values, implement:
1. An AND logic to control the projector operation
2. An OR logic to control the classroom lighting system
Validate the neuron outputs for all possible input combinations and compare them with standard AND and OR
truth tables
'''

# Mc-Culloch-Pitts neuron implementation for AND and OR logic
def mcp_neuron(inputs, weights, threshold):
    weighted_sum=sum(i*w for i, w in zip(inputs, weights))
    return 1 if weighted_sum>=threshold else 0
# Input combinations: [Occupancy, Authorized Faculty]
input_combinations= [
 [0,0],
 [0,1],
 [1,0],
 [1,1]]

#AND Gate: Projector control
#Weights and threshold chosen for AND: w1=w2=1, threshold=2
and_weights=[1,1]
and_threshold=2
#OR Gate: Light control
#Weights and threshold chosen for OR : w1=w2=1, threshold=1
or_weights=[1,1]
or_threshold=1
print("Smart Classrooom Control Using MCP Neuron\n")
print("Input Combination -> Projector -> Lights")
print("----------------------------------------")
for inputs in input_combinations:
    #MCP outputs
    projector_output=mcp_neuron(inputs, and_weights, and_threshold)
    lights_control=mcp_neuron(inputs, or_weights, or_threshold)

    #Map Output to meaningful status
    projector_status="ON" if projector_output else "OFF"
    lights_status="ON" if lights_control else "OFF"
    print(f"{inputs} ----------------> {projector_status} -----> {lights_status}")

'''
Exercise 1:
Design and implement a Mc-Culloch–Pitts neuron model for a railway crossing control system that operates based on predefined logical rules. The system receives binary inputs from a train detection sensor and a manual override signal. Using appropriate weights and threshold values, implement AND and OR logic functions to control the warning signals at the railway crossing. Verify the correctness of the system by evaluating the neuron output for all possible input combinations.
'''
# Mc-Culloch-Pitts neuron function
def mcp_neuron(inputs, weights, threshold):
    weighted_sum = sum(i * w for i, w in zip(inputs, weights))
    return 1 if weighted_sum >= threshold else 0
# Input combinations: [Train Detection, Manual Override]
input_combinations = [
 [0, 0],
 [0, 1],
 [1, 0],
 [1, 1]
]
print("Railway Crossing Control using MCP Neuron\n")
print("Inputs [Train, Override] -> NOT Output -> NAND Output")
print("--------------------------------------------------------")
# NOT Gate (Warning when no train detected)
# Implemented inhibitory connection as NOT T → weight = -1, threshold = 0
not_weights = [-1]
not_threshold = 0
# NAND Gate
# NAND = NOT(AND)
# Implemented excitatory connection as weights = [1, 1], threshold = 2, then invert output
nand_weights = [1, 1]
nand_threshold = 2
for inputs in input_combinations:
    train, override = inputs
    # NOT Logic 
    not_output = mcp_neuron([train], not_weights, not_threshold)
    # AND logic inside NAND
    and_output = mcp_neuron(inputs, nand_weights, nand_threshold)
    nand_output = 0 if and_output == 1 else 1
    # Status mapping
    not_status = "WARNING ON" if not_output else "WARNING OFF"
    nand_status = "WARNING ON" if nand_output else "WARNING OFF"
    print(f"{inputs} ------------------> {not_status} ---> {nand_status}")
