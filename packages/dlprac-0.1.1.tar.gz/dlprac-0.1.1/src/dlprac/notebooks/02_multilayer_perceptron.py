'''
Design and implement a Multilayer Perceptron (MLP) using a deep learning library to model the behavior of a two-way light switching system. The light should turn ON only when exactly one of the two switches is ON
'''
# Import libraries
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from tensorflow.keras.optimizers import SGD
#-------------------------------
# Step 0: Set seeds for reproducibility
np.random.seed(42) 
tf.random.set_seed(42)
#-------------------------------
# Step 1: Prepare the dataset (Truth table for XOR)
X=np.array(
 [
 [0,0],
 [0,1],
 [1,0],
 [1,1]
 ], dtype=np.float32)
y=np.array(
 [
 [0], #Light OFF
 [1], #Light ON
 [1], #Light ON
 [0] #Light OFF
 ], dtype=np.float32)
#------------------------------
# Step 2: Define the MLP models
model=Sequential()
model.add(Dense(4, input_dim=2, activation='relu')) # Hidden layer
model.add(Dense(1, activation='sigmoid')) # Output layer
#------------------------------
# Step 3: Compile the model
model.compile(optimizer=SGD(learning_rate=0.1),
    loss='binary_crossentropy',
    metrics=['accuracy'])
#------------------------------
# Step 4: Train the model
history = model.fit(X, y, epochs=500, verbose=0)
#------------------------------
# Step 5: Test the model
predictions=model.predict(X) 
predictions_binary=(predictions>0.5).astype(int)
#------------------------------
# Step 6: Display results
def light_status(value):
    return "Light ON" if value == 1 else "Light OFF"
print("Switches\tPredicted\tActual")
for i in range(len(X)):
    print(f"{X[i]}\t{light_status(predictions_binary[i][0])}\t{light_status(int(y[i][0]))}")


'''
Exercise 1:
Demonstrate why a single-layer perceptron cannot model this behavior by implementing single layer perceptron model. Abstract: This exercise is aimed at demonstrating that SLP cannot model nonlinear behavior. A single-layer perceptron is implemented to model the two-way light switching system, where the light turns ON only when exactly one switch is ON. The model fails to learn the correct behavior, demonstrating that the problem is not linearly separable. This highlights the necessity of hidden layers in a Multilayer Perceptron (MLP) to capture non-linear relationships. 
'''

# Import libraries
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from tensorflow.keras.optimizers import SGD
#-------------------------------
# Step 0: Set seeds for reproducibility
np.random.seed(42)
tf.random.set_seed(42)
#-------------------------------
# Step 1: Prepare the dataset (Truth table for XOR)
X=np.array(
 [
 [0,0],
 [0,1],
 [1,0],
 [1,1]
 ], dtype=np.float32)
y=np.array(
 [
 [0], #Light OFF
 [1], #Light ON
 [1], #Light ON
 [0] #Light OFF
 ], dtype=np.float32)
#------------------------------ 
# Step 2: Define the Single-Layer Perceptron model
# An SLP has no hidden layers, only input and output.
slp_model = Sequential()
slp_model.add(Dense(1, input_dim=2, activation='sigmoid')) # Output layer with sigmoid for binary classification
#------------------------------
# Step 3: Compile the model
slp_model.compile(optimizer=SGD(learning_rate=0.1),
 loss='binary_crossentropy',
 metrics=['accuracy'])
#------------------------------
# Step 4: Train the model
# We expect this model to struggle with XOR
slp_model.fit(X, y, epochs=500, verbose=0)
#------------------------------
# Step 5: Test the model
slp_predictions = slp_model.predict(X) 
slp_predictions_binary = (slp_predictions > 0.5).astype(int)
#------------------------------
# Step 6: Display results
def light_status(value):
 return "Light ON" if value == 1 else "Light OFF"
print("Single-Layer Perceptron Results:")
print("Switches\tPredicted\tActual")
for i in range(len(X)):
 print(f"{X[i]}\t{light_status(slp_predictions_binary[i][0])}\t{light_status(int(y[i][0]))}")
# Evaluate accuracy
loss, accuracy = slp_model.evaluate(X, y, verbose=0)
print(f"\nSLP Model Accuracy: {accuracy*100:.2f}%")
print("\nAs you can see, the single-layer perceptron struggles to learn the XOR pattern, often achieving around 50% accuracy.\nThis demonstrates that it cannot model non-linearly separable problems like the two-way light switch (XOR).") 

'''
Using Python deep learning libraries, build a neural network regression model to predict exam scores based on study hours and attendance percentage. Tasks:
1. Implement the model without a hidden layer and evaluate its performance using MSE and MAE.
2. Implement the model with one hidden layer (using ReLU activation) and evaluate its performance.
3. Compare the predictions of both models and explain how the hidden layer improves the model’s ability to capture nonlinear patterns in the data.
4. Discuss why hidden layers are important in regression models when input features interact in complex ways. Use following data for training the network. 
'''

# dataset: students_exam_data.csv
# Columns: Study Hours, Attendance %, Exam Score
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler
# Load the dataset 
df = pd.read_csv('student_exam_data.csv')
# Separate features (X) and target (y)
X = df[['Study Hours', 'Attendance (%)']]
y = df['Exam Score']
# Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
# Initialize MinMaxScaler
scaler = MinMaxScaler()
# Fit the scaler on training data and transform both training and testing data
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)
print("Data loaded, split, and features scaled successfully.")
print(f"X_train_scaled shape: {X_train_scaled.shape}")
print(f"X_test_scaled shape: {X_test_scaled.shape}")
print(f"y_train shape: {y_train.shape}")
print(f"y_test shape: {y_test.shape}") 

# 1. Implement the model without a hidden layer and evaluate its performance using MSE and MAE. 
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from tensorflow.keras.optimizers import Adam 
# Step 1: Define the model architecture (no hidden layers)
model_no_hidden = Sequential()
model_no_hidden.add(Dense(1, input_dim=X_train_scaled.shape[1], activation='linear',
name='output_layer'))
# Step 2: Compile the model
model_no_hidden.compile(optimizer=Adam(learning_rate=0.01),
 loss='mean_squared_error',
 metrics=['mae', 'mse'])
# Step 3: Train the model
print("Training Model 1 (No Hidden Layer)...")
history_no_hidden = model_no_hidden.fit(X_train_scaled, y_train, epochs=200, verbose=0)
print("Training complete.")
# Step 4: Evaluate the model
loss_no_hidden, mae_no_hidden, mse_no_hidden = model_no_hidden.evaluate(X_test_scaled, y_test,
verbose=0)
print(f"\n--- Model 1 (No Hidden Layer) Evaluation ---")
print(f"Test MSE: {mse_no_hidden:.4f}")
print(f"Test MAE: {mae_no_hidden:.4f}")
# Step 5: Make predictions
predictions_no_hidden = model_no_hidden.predict(X_test_scaled)
print(f"\nSample Predictions (No Hidden Layer):\n{predictions_no_hidden.flatten()[:5]}")
print(f"Corresponding Actual Values:\n{y_test.values[:5]}") 


# 2. Implement the model with one hidden layer (using ReLU activation) and evaluate its performance.
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from tensorflow.keras.optimizers import Adam
# Step 1: Define the model architecture (with one hidden layer)
model_with_hidden = Sequential()
model_with_hidden.add(Dense(32, input_dim=X_train_scaled.shape[1], activation='relu',
name='hidden_layer')) # Hidden layer
model_with_hidden.add(Dense(1, activation='linear', name='output_layer')) # Output layer
# Step 2: Compile the model
model_with_hidden.compile(optimizer=Adam(learning_rate=0.01),
 loss='mean_squared_error',
 metrics=['mae', 'mse'])
# Step 3: Train the model
print("Training Model 2 (With One Hidden Layer)...")
history_with_hidden = model_with_hidden.fit(X_train_scaled, y_train, epochs=200, verbose=0)
print("Training complete.") 
# Step 4: Evaluate the model
loss_with_hidden, mae_with_hidden, mse_with_hidden = model_with_hidden.evaluate(X_test_scaled, y_test, verbose=0)
print(f"\n--- Model 2 (With One Hidden Layer) Evaluation ---")
print(f"Test MSE: {mse_with_hidden:.4f}")
print(f"Test MAE: {mae_with_hidden:.4f}")
# Step 5: Make predictions
predictions_with_hidden = model_with_hidden.predict(X_test_scaled)
print(f"\nSample Predictions (With One Hidden Layer):\n{predictions_with_hidden.flatten()[:5]}")
print(f"Corresponding Actual Values:\n{y_test.values[:5]}") 

# 3. Compare the predictions of both models and explain how the hidden layer improves the model’s ability to capture nonlinear patterns in the data. 

print("--- Model Comparison ---")
print(f"Model 1 (No Hidden Layer) - Test MSE: {mse_no_hidden:.4f}, Test MAE: {mae_no_hidden:.4f}")
print(f"Model 2 (With One Hidden Layer) - Test MSE: {mse_with_hidden:.4f}, Test MAE: {mae_with_hidden:.4f}")
print("\n--- Sample Predictions Comparison ---")
print("Actual\t\tNo Hidden Layer\tWith Hidden Layer")
for i in range(len(y_test)):
    print(f"{y_test.values[i]:.0f}\t\t{predictions_no_hidden.flatten()[i]:.2f}\t\t{predictions_with_hidden.flatten()[i]:.2f}")

# 4. Discuss why hidden layers are important in regression models when input features interact in complex ways. Use following data for training the network. 
print("\n--- Discussion on Hidden Layers ---")
print("As observed from the evaluation metrics, Model 2 (With One Hidden Layer) achieved significantly lower MSE and MAE compared to Model 1 (No Hidden Layer).")
print(f"Specifically, Model 1 had MSE of {mse_no_hidden:.2f} and MAE of {mae_no_hidden:.2f}, while Model 2 had MSE of {mse_with_hidden:.2f} and MAE of {mae_with_hidden:.2f}.")
print("This clearly demonstrates that the hidden layer improved the model's ability to capture the underlying patterns in the data.")
print("Hidden layers are crucial in regression models because they allow the network to learn non-linear relationships between inputs and outputs.")
print("Without a hidden layer, the model is limited to learning only linear relationships, which is often insufficient for complex real-world data where features interact in non-linear ways. The ReLU activation function in the hidden layer introduces this non-linearity, enabling the model to approximate more complex functions.")
