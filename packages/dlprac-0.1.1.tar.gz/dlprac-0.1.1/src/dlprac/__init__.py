"""dlprac - Deep Learning Practice Files."""

from pathlib import Path

__version__ = "0.1.1"
__author__ = "Yash"
__email__ = "22102074.yash@gmail.com"

PACKAGE_DIR = Path(__file__).parent
NOTEBOOKS_DIR = PACKAGE_DIR / "notebooks"


def get_notebooks_path() -> Path:
    """Return the path to packaged practice files."""
    return NOTEBOOKS_DIR


def list_notebooks() -> list[str]:
    """List all available practice files (.ipynb and .py) in the package."""
    if NOTEBOOKS_DIR.exists():
        allowed_suffixes = {".ipynb", ".py"}
        return sorted(
            item.name
            for item in NOTEBOOKS_DIR.iterdir()
            if item.is_file() and item.suffix in allowed_suffixes
        )
    return []
