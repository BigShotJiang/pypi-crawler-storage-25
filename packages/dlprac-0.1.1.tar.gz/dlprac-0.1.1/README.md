# dlprac - Deep Learning Practice Files

A practical collection of deep learning practice files that includes both Python scripts (`.py`) and Jupyter notebooks (`.ipynb`).

## Installation

Install the package using pip:

```bash
pip install dlprac
```

## Usage

### Download Practice Files

After installation, you can download all packaged practice files. The command creates a `dlprac_files` subfolder in the target location and stores all files there:

```bash
dlprac download
```

Or specify a custom destination:

```bash
dlprac download --dest my-files
```

This will create `my-files/dlprac_files` and place all packaged files inside it.

### List Available Files

To see all available files without downloading:

```bash
dlprac download --list
```

### Package Information

Get information about the package:

```bash
dlprac info
```

## Packaged Contents

Current packaged files:

- `01_mcp.py`
- `02_multilayer_perceptron.py`
- `03_sup_sl_feedforward_sgd_mbgd_bgd.py`
- `04_fc_denoising_autoenc_mnist.ipynb`
- `05_fc_autoenc_compression_layers.ipynb`
- `06_cnn_catdog.ipynb`
- `07_rnn_wordseq.ipynb`
- `08_lstm_sentimentimdb.ipynb`

## Requirements

The practice files use common ML/DL libraries such as:
- NumPy
- Pandas
- Matplotlib
- Seaborn
- Scikit-learn

Install them separately:

```bash
pip install numpy pandas matplotlib seaborn scikit-learn jupyter
```

## Python API

You can also use the package programmatically in Python:

```python
import dlprac

# Get the path to packaged files
files_path = dlprac.get_notebooks_path()

# List all available packaged practice files
files = dlprac.list_notebooks()
for item in files:
  print(item)
```

## License

MIT License