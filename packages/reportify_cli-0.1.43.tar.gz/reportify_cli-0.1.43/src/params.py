"""Parameter metadata definitions for all SDK methods."""

from dataclasses import dataclass
from typing import Any


@dataclass
class ParamDef:
    """Parameter definition."""

    name: str
    type: str
    description: str
    required: bool = False
    default: Any | None = None


# Search module parameters
SEARCH_ALL_PARAMS = [
    ParamDef("query", "string", "Search keywords", required=True),
    ParamDef("num", "int", "Number of results, max 100", default=10),
    ParamDef(
        "categories",
        "list[str]",
        "Document category filter: news, reports, filings, transcripts, socials",
    ),
    ParamDef(
        "symbols",
        "list[str]",
        "Stock symbol filter, format: market:ticker, e.g. ['US:AAPL', 'HK:00700', 'SH:600519', 'SZ:000001']",
    ),
    ParamDef("industries", "list[str]", "Industry filter"),
    ParamDef("channel_ids", "list[str]", "Channel ID filter"),
    ParamDef("start_datetime", "str", "Start time, format: YYYY-MM-DD or YYYY-MM-DD HH:MM:SS"),
    ParamDef("end_datetime", "str", "End time, format: YYYY-MM-DD or YYYY-MM-DD HH:MM:SS"),
]

SEARCH_NEWS_PARAMS = [
    ParamDef("query", "string", "Search keywords", required=True),
    ParamDef("num", "int", "Number of results", default=10),
    ParamDef(
        "symbols", "list[str]", "Stock symbol filter, format: market:ticker, e.g. US:AAPL, HK:00700"
    ),
    ParamDef("channel_ids", "list[str]", "Channel ID filter"),
    ParamDef("start_datetime", "str", "Start time"),
    ParamDef("end_datetime", "str", "End time"),
]

SEARCH_REPORTS_PARAMS = [
    ParamDef("query", "string", "Search keywords", required=True),
    ParamDef("num", "int", "Number of results", default=10),
    ParamDef(
        "symbols", "list[str]", "Stock symbol filter, format: market:ticker, e.g. US:AAPL, HK:00700"
    ),
    ParamDef("industries", "list[str]", "Industry filter"),
    ParamDef("channel_ids", "list[str]", "Channel ID filter"),
    ParamDef("start_datetime", "str", "Start time"),
    ParamDef("end_datetime", "str", "End time"),
]

SEARCH_FILINGS_PARAMS = [
    ParamDef("query", "string", "Search keywords", required=True),
    ParamDef(
        "symbols",
        "list[str]",
        "Stock symbol list, format: market:ticker, e.g. US:AAPL, HK:00700 (required)",
        required=True,
    ),
    ParamDef("num", "int", "Number of results", default=10),
    ParamDef("start_datetime", "str", "Start time"),
    ParamDef("end_datetime", "str", "End time"),
]

SEARCH_CONFERENCE_CALLS_PARAMS = [
    ParamDef(
        "query",
        "string",
        "Search query (optional). If not provided, returns documents sorted by date desc; if provided, sorts by relevance",
    ),
    ParamDef(
        "symbols",
        "list[str]",
        "Stock symbols in market:ticker format, e.g. US:AAPL, HK:00700 (required)",
        required=True,
    ),
    ParamDef("num", "int", "Number of results to return", default=10),
    ParamDef("start_datetime", "str", "Start datetime filter"),
    ParamDef("end_datetime", "str", "End datetime filter"),
    ParamDef("fiscal_year", "str", "Fiscal year filter, e.g. '2025'"),
    ParamDef("fiscal_quarter", "str", "Fiscal quarter filter, e.g. 'Q1', 'Q2', 'Q3', 'Q4'"),
    ParamDef(
        "sort_by",
        "str",
        "Sort order: 'date_desc' (default when no query), 'relevance' (recommended when query provided), 'date_asc'",
        default="date_desc",
    ),
]

SEARCH_EARNINGS_PACK_PARAMS = [
    ParamDef(
        "query",
        "string",
        "Search query (optional). If not provided, returns documents sorted by date desc; if provided, sorts by relevance",
    ),
    ParamDef(
        "symbols",
        "list[str]",
        "Stock symbols in market:ticker format, e.g. US:AAPL, HK:00700 (required)",
        required=True,
    ),
    ParamDef("num", "int", "Number of results to return", default=10),
    ParamDef("start_datetime", "str", "Start datetime filter"),
    ParamDef("end_datetime", "str", "End datetime filter"),
    ParamDef("fiscal_year", "str", "Fiscal year filter"),
    ParamDef("fiscal_quarter", "str", "Fiscal quarter filter"),
    ParamDef(
        "sort_by",
        "str",
        "Sort order: 'date_desc' (default when no query), 'relevance' (recommended when query provided), 'date_asc'",
        default="date_desc",
    ),
]

SEARCH_MINUTES_PARAMS = [
    ParamDef("query", "string", "Search keywords", required=True),
    ParamDef("num", "int", "Number of results", default=10),
    ParamDef(
        "symbols", "list[str]", "Stock symbol filter, format: market:ticker, e.g. US:AAPL, HK:00700"
    ),
    ParamDef("start_datetime", "str", "Start time"),
    ParamDef("end_datetime", "str", "End time"),
]

SEARCH_SOCIALS_PARAMS = [
    ParamDef("query", "string", "Search keywords", required=True),
    ParamDef("num", "int", "Number of results", default=10),
    ParamDef(
        "symbols", "list[str]", "Stock symbol filter, format: market:ticker, e.g. US:AAPL, HK:00700"
    ),
    ParamDef("channel_ids", "list[str]", "Channel ID filter"),
    ParamDef("start_datetime", "str", "Start time"),
    ParamDef("end_datetime", "str", "End time"),
]

SEARCH_WEBPAGES_PARAMS = [
    ParamDef("query", "string", "Search keywords", required=True),
    ParamDef("num", "int", "Number of results", default=10),
    ParamDef("start_datetime", "str", "Start time"),
    ParamDef("end_datetime", "str", "End time"),
]

# Docs module parameters
DOCS_GET_PARAMS = [
    ParamDef("doc_id", "string", "Document ID", required=True),
]

DOCS_SUMMARY_PARAMS = [
    ParamDef("doc_id", "string", "Document ID", required=True),
]

DOCS_LIST_BY_SYMBOLS_PARAMS = [
    ParamDef("symbol", "string", "Stock symbol, format: market:ticker", required=True),
    ParamDef("categories", "list[str]", "Document category filter"),
    ParamDef("num", "int", "Number of results", default=10),
    ParamDef("start_date", "str", "Start date"),
    ParamDef("end_date", "str", "End date"),
]

DOCS_RAW_CONTENT_PARAMS = [
    ParamDef("doc_id", "string", "Document ID", required=True),
]

DOCS_LIST_PARAMS = [
    ParamDef(
        "symbols", "list[str]", "Stock symbol list, format: market:ticker, e.g. US:AAPL, HK:00700"
    ),
    ParamDef(
        "categories",
        "list[str]",
        "Document category filter: financials, transcripts, reports, news, files, filings, socials",
    ),
    ParamDef("markets", "list[str]", "Market filter: cn, hk, us"),
    ParamDef("institutions", "list[str]", "Institution filter"),
    ParamDef("tags", "dict", "Tag filter (dict format)"),
    ParamDef("folder_ids", "list[str]", "Folder ID filter"),
    ParamDef("start_date", "str", "Start date, format: YYYY-MM-DD"),
    ParamDef("end_date", "str", "End date, format: YYYY-MM-DD"),
    ParamDef("min_score", "float", "Minimum relevance score"),
    ParamDef("extended_filters", "list[dict]", "Extended filter conditions"),
    ParamDef("page_num", "int", "Page number", default=1),
    ParamDef("page_size", "int", "Page size", default=10),
]

DOCS_SEARCH_PARAMS = [
    ParamDef("query", "string", "Search keywords"),
    ParamDef("symbols", "list[str]", "Stock symbol list"),
    ParamDef("categories", "list[str]", "Document category filter"),
    ParamDef("markets", "list[str]", "Market filter"),
    ParamDef("institutions", "list[str]", "Institution filter"),
    ParamDef("tags", "dict", "Tag filter"),
    ParamDef("folder_ids", "list[str]", "Folder ID filter"),
    ParamDef("start_date", "str", "Start date"),
    ParamDef("end_date", "str", "End date"),
    ParamDef("min_score", "float", "Minimum relevance score"),
    ParamDef("extended_filters", "list[dict]", "Extended filter conditions"),
    ParamDef("num", "int", "Number of results", default=10),
]

DOCS_SEARCH_CHUNKS_PARAMS = [
    ParamDef("query", "string", "Search keywords", required=True),
    ParamDef("symbols", "list[str]", "Stock symbol list"),
    ParamDef("categories", "list[str]", "Document category filter"),
    ParamDef("markets", "list[str]", "Market filter"),
    ParamDef("institutions", "list[str]", "Institution filter"),
    ParamDef("tags", "dict", "Tag filter"),
    ParamDef("folder_ids", "list[str]", "Folder ID filter"),
    ParamDef("doc_ids", "list[str]", "Document ID filter"),
    ParamDef("start_date", "str", "Start date"),
    ParamDef("end_date", "str", "End date"),
    ParamDef("min_score", "float", "Minimum relevance score"),
    ParamDef("extended_filters", "list[dict]", "Extended filter conditions"),
    ParamDef("num", "int", "Number of results", default=10),
    ParamDef("include_doc_extra_details", "bool", "Include extra document details", default=False),
    ParamDef("refine_question", "bool", "Refine search query", default=False),
    ParamDef("date_range", "str", "Date range: h, d, w, m, y"),
]

DOCS_CREATE_FOLDER_PARAMS = [
    ParamDef("name", "string", "Folder name", required=True),
]

DOCS_DELETE_FOLDER_PARAMS = [
    ParamDef("folder_id", "string", "Folder ID", required=True),
]

DOCS_UPLOAD_PARAMS = [
    ParamDef(
        "docs", "list[dict]", "Document list, each containing url, name fields", required=True
    ),
    ParamDef("folder_id", "str", "Folder ID (optional)"),
    ParamDef("pdf_parsing_mode", "int", "PDF parsing mode: 1=by page, 3=by logic", default=1),
]

DOCS_UPLOAD_ASYNC_PARAMS = [
    ParamDef(
        "docs", "list[dict]", "Document list, each containing url, name fields", required=True
    ),
    ParamDef("folder_id", "str", "Folder ID (optional)"),
    ParamDef("pdf_parsing_mode", "int", "PDF parsing mode: 1=by page, 3=by logic", default=1),
]

DOCS_GET_UPLOAD_STATUS_PARAMS = [
    ParamDef("doc_id", "string", "Document ID", required=True),
]

DOCS_DELETE_PARAMS = [
    ParamDef("doc_ids", "list[str]", "List of document IDs to delete", required=True),
]

# Stock module parameters
STOCK_OVERVIEW_PARAMS = [
    ParamDef("symbols", "string", "Stock symbols, comma-separated, e.g. 'AAPL,00700' (also accepts 'symbol' for single stock)"),
    ParamDef("names", "string", "Stock names, comma-separated, e.g. 'Tencent,Apple'"),
]

STOCK_SHAREHOLDERS_PARAMS = [
    ParamDef("symbol", "string", "Stock symbol", required=True),
]

STOCK_INCOME_STATEMENT_PARAMS = [
    ParamDef("symbol", "string", "Stock symbol", required=True),
    ParamDef("period", "string", "Report period: annual or quarterly", default="annual"),
    ParamDef("limit", "int", "Number of periods", default=8),
    ParamDef("start_date", "str", "Start date, format: YYYY-MM-DD"),
    ParamDef("end_date", "str", "End date, format: YYYY-MM-DD"),
    ParamDef("calendar", "str", "Calendar type: calendar or fiscal", default="fiscal"),
    ParamDef("fiscal_year", "str", "Fiscal year, e.g. '2023'"),
    ParamDef("fiscal_quarter", "str", "Fiscal quarter: Q1, Q2, Q3, Q4, FY, H1"),
]

STOCK_BALANCE_SHEET_PARAMS = [
    ParamDef("symbol", "string", "Stock symbol", required=True),
    ParamDef("period", "string", "Report period: annual or quarterly", default="annual"),
    ParamDef("limit", "int", "Number of periods", default=8),
    ParamDef("start_date", "str", "Start date"),
    ParamDef("end_date", "str", "End date"),
    ParamDef("calendar", "str", "Calendar type: calendar or fiscal", default="fiscal"),
    ParamDef("fiscal_year", "str", "Fiscal year"),
    ParamDef("fiscal_quarter", "str", "Fiscal quarter"),
]

STOCK_CASHFLOW_STATEMENT_PARAMS = [
    ParamDef("symbol", "string", "Stock symbol", required=True),
    ParamDef(
        "period",
        "string",
        "Report period: annual, quarterly, or cumulative quarterly",
        default="annual",
    ),
    ParamDef("limit", "int", "Number of periods", default=8),
    ParamDef("start_date", "str", "Start date"),
    ParamDef("end_date", "str", "End date"),
    ParamDef("calendar", "str", "Calendar type: calendar or fiscal", default="fiscal"),
    ParamDef("fiscal_year", "str", "Fiscal year"),
    ParamDef("fiscal_quarter", "str", "Fiscal quarter"),
]

STOCK_REVENUE_BREAKDOWN_PARAMS = [
    ParamDef("symbol", "string", "Stock symbol", required=True),
    ParamDef("period", "str", "Report period, e.g. 'FY', 'Q2'"),
    ParamDef("limit", "int", "Number of records", default=6),
    ParamDef("start_date", "str", "Start date"),
    ParamDef("end_date", "str", "End date"),
    ParamDef("fiscal_year", "str", "Fiscal year"),
]

STOCK_QUOTE_PARAMS = [
    ParamDef("symbol", "string", "Stock symbol, e.g. 'AAPL', '688001', '00700'", required=True),
    ParamDef("start_date", "str", "Start date, format: YYYY-MM-DD"),
    ParamDef("end_date", "str", "End date, format: YYYY-MM-DD"),
]

STOCK_INDEX_CONSTITUENTS_PARAMS = [
    ParamDef(
        "symbol", "string", "Index code, e.g. '000300' (CSI 300), '399006' (ChiNext)", required=True
    ),
]

STOCK_INDEX_TRACKING_FUNDS_PARAMS = [
    ParamDef("symbol", "string", "Index code, e.g. '000300', '000905'", required=True),
]

STOCK_INDUSTRY_CONSTITUENTS_PARAMS = [
    ParamDef("market", "string", "Stock market: cn, hk, us", required=True),
    ParamDef("name", "string", "Industry name, e.g. 'Defense', 'Technology'", required=True),
    ParamDef("type", "string", "Industry classification: sw (Shenwan), wind, hs (Hang Seng), GICS"),
]

STOCK_EARNINGS_CALENDAR_PARAMS = [
    ParamDef("market", "string", "Stock market: cn, hk, us", required=True),
    ParamDef("start_date", "str", "Start date"),
    ParamDef("end_date", "str", "End date"),
    ParamDef("symbol", "str", "Stock symbol"),
]

STOCK_IPO_CALENDAR_HK_PARAMS = [
    ParamDef(
        "status",
        "string",
        "IPO status: Filing, Hearing, Priced",
        default="Filing",
    ),
]

STOCK_INDEX_QUOTE_PARAMS = [
    ParamDef("symbol", "string", "Index code, e.g. '000300', 'HSI', 'SPX'", required=True),
    ParamDef("start_date", "str", "Start date, format: YYYY-MM-DD"),
    ParamDef("end_date", "str", "End date, format: YYYY-MM-DD"),
]

# Timeline module parameters
TIMELINE_COMPANIES_PARAMS = [
    ParamDef("num", "int", "Number of results, range 1-100", default=10),
]

TIMELINE_TOPICS_PARAMS = [
    ParamDef("num", "int", "Number of results, range 1-100", default=10),
]

TIMELINE_INSTITUTES_PARAMS = [
    ParamDef("num", "int", "Number of results, range 1-100", default=10),
]

TIMELINE_PUBLIC_MEDIA_PARAMS = [
    ParamDef("num", "int", "Number of results, range 1-100", default=10),
]

TIMELINE_SOCIAL_MEDIA_PARAMS = [
    ParamDef("num", "int", "Number of results, range 1-100", default=10),
]

# KB module parameters
KB_SEARCH_PARAMS = [
    ParamDef("query", "string", "Search keywords", required=True),
    ParamDef("folder_ids", "list[str]", "Folder ID list, searches all folders if not provided"),
    ParamDef("doc_ids", "list[str]", "Document ID list, limits search scope"),
    ParamDef("start_date", "str", "Start date filter (YYYY-MM-DD)"),
    ParamDef("end_date", "str", "End date filter (YYYY-MM-DD)"),
    ParamDef("num", "int", "Number of results", default=10),
]

# User module parameters
USER_FOLLOWED_COMPANIES_PARAMS = []

USER_FOLLOW_COMPANY_PARAMS = [
    ParamDef("symbol", "string", "Stock symbol, format: market:ticker, e.g. US:AAPL, HK:00700, SH:600519", required=True),
]

USER_UNFOLLOW_COMPANY_PARAMS = [
    ParamDef("symbol", "string", "Stock symbol, format: market:ticker, e.g. US:AAPL, HK:00700, SH:600519", required=True),
]

# Search crawl parameters
SEARCH_CRAWL_PARAMS = [
    ParamDef("urls", "list[str]", "List of URLs to crawl", required=True),
    ParamDef("text", "bool|dict", "Extract text content (true or options dict with max_characters, include_html_tags, verbosity)", default=True),
    ParamDef("highlights", "dict", "Extract highlights, e.g. {\"query\": \"key data\", \"max_characters\": 500, \"num_sentences\": 3, \"highlights_per_url\": 2}"),
    ParamDef("summary", "dict", "Extract summary, e.g. {\"query\": \"summarize key points\"}"),
    ParamDef("subpages", "int", "Max number of subpages to crawl per URL"),
    ParamDef("subpage_target", "list[str]", "Keywords to prioritize when selecting subpages"),
    ParamDef("max_age_hours", "int", "Maximum age of cached content in hours"),
    ParamDef("livecrawl_timeout", "int", "Timeout in ms for live crawling fallback"),
]

# Quant module parameters
QUANT_LIST_FACTORS_PARAMS = []

QUANT_COMPUTE_FACTORS_PARAMS = [
    ParamDef("symbols", "list[str]", "Stock symbol list", required=True),
    ParamDef(
        "formula",
        "str",
        "Factor formula, expressions on both sides of logical operators (&/|/AND/OR) must be wrapped in ()",
        required=True,
    ),
    ParamDef("market", "str", "Market", default="cn"),
    ParamDef("start_date", "str", "Start date"),
    ParamDef("end_date", "str", "End date"),
]

QUANT_SCREEN_PARAMS = [
    ParamDef(
        "formula",
        "str",
        "Screening formula, expressions on both sides of logical operators (&/|/AND/OR) must be wrapped in ()",
        required=True,
    ),
    ParamDef("market", "str", "Market", default="cn"),
    ParamDef("check_date", "str", "Check date, defaults to latest trading day"),
    ParamDef("symbols", "list[str]", "Stock pool, None for entire market"),
]

QUANT_OHLCV_PARAMS = [
    ParamDef("symbol", "str", "Stock symbol", required=True),
    ParamDef("market", "str", "Market", default="cn"),
    ParamDef("start_date", "str", "Start date, defaults to 1 month ago"),
    ParamDef("end_date", "str", "End date, defaults to today"),
]

QUANT_OHLCV_BATCH_PARAMS = [
    ParamDef("symbols", "list[str]", "Stock symbol list", required=True),
    ParamDef("market", "str", "Market", default="cn"),
    ParamDef("start_date", "str", "Start date"),
    ParamDef("end_date", "str", "End date"),
]

QUANT_BACKTEST_PARAMS = [
    ParamDef("start_date", "str", "Backtest start date (YYYY-MM-DD)", required=True),
    ParamDef("end_date", "str", "Backtest end date (YYYY-MM-DD)", required=True),
    ParamDef("symbols", "list[str]", "Stock symbols (optional if filter_formula is provided)"),
    ParamDef("filter_formula", "str", "Pre-filter formula, e.g., 'NOT(IS_ST)'"),
    ParamDef("market", "str", "Market (cn/hk/us)", default="cn"),
    ParamDef("stock_type", "str", "Stock type: stock/etf/index/sw", default="stock"),
    ParamDef(
        "entry_formula",
        "str",
        "Entry formula (result > 0 triggers buy), logical operators must be wrapped in ()",
    ),
    ParamDef(
        "strategy_code",
        "str",
        "Custom backtest strategy Python code",
    ),
    ParamDef(
        "exit_formula",
        "str",
        "Exit formula (result > 0 triggers sell), logical operators must be wrapped in ()",
    ),
    ParamDef("initial_cash", "float", "Initial capital", default=100000),
    ParamDef("commission", "float", "Commission rate for both buy and sell", default=0),
    ParamDef("buy_commission", "float", "Buy commission rate, takes priority over commission", default=0),
    ParamDef("sell_commission", "float", "Sell commission rate, takes priority over commission", default=0),
    ParamDef("min_commission_amount", "float", "Minimum commission per trade in CNY", default=0),
    ParamDef("slippage", "float", "Slippage ratio, buy price up / sell price down", default=0),
    ParamDef("stop_loss", "float", "Stop loss ratio (0 to disable)", default=0),
    ParamDef("position_size", "float", "Max position size ratio per stock based on total assets"),
    ParamDef("max_positions", "int", "Max number of holding stocks"),
    ParamDef("min_volume", "int", "Minimum trading volume", default=100),
    ParamDef("auto_close", "bool", "Auto close positions", default=True),
    ParamDef("cheat_on_open", "bool", "Execute T-day signals at T-day open (default: False, execute at T+1 open)", default=False),
    ParamDef("signal_factors", "dict[str, str]", "Signal factors dictionary for custom strategy pre-computation"),
    ParamDef(
        "benchmark",
        "dict",
        "Benchmark config dict for comparison, e.g. {'symbol': '000905', 'market': 'cn', 'stock_type': 'index'}; do not pass a plain string like '000905'",
    ),
]

QUANT_KLINE_PARAMS = [
    ParamDef("symbol", "str", "Stock symbol", required=True),
    ParamDef("kline_type", "str", "Kline type: 1M/5M/15M/30M/60M/1D/1W/1MO", default="1D"),
    ParamDef("market", "str", "Market (cn/hk/us)", default="cn"),
    ParamDef("stock_type", "str", "Stock type: stock/etf/index/sw", default="stock"),
    ParamDef("start_datetime", "str", "Start datetime (YYYY-MM-DD HH:MM:SS)"),
    ParamDef("end_datetime", "str", "End datetime (YYYY-MM-DD HH:MM:SS)"),
]

QUANT_KLINE_BATCH_PARAMS = [
    ParamDef("symbols", "list[str]", "Stock symbol list", required=True),
    ParamDef("kline_type", "str", "Kline type: 1M/5M/15M/30M/60M/1D/1W/1MO", default="1D"),
    ParamDef("market", "str", "Market (cn/hk/us)", default="cn"),
    ParamDef("stock_type", "str", "Stock type: stock/etf/index/sw", default="stock"),
    ParamDef("start_datetime", "str", "Start datetime (YYYY-MM-DD HH:MM:SS)"),
    ParamDef("end_datetime", "str", "End datetime (YYYY-MM-DD HH:MM:SS)"),
]

QUANT_MINUTE_PARAMS = [
    ParamDef("symbol", "str", "Stock symbol", required=True),
    ParamDef("start_datetime", "str", "Start datetime (YYYY-MM-DD HH:MM:SS)", required=True),
    ParamDef("end_datetime", "str", "End datetime (YYYY-MM-DD HH:MM:SS)", required=True),
    ParamDef("market", "str", "Market (cn/hk/us)", default="cn"),
]

QUANT_MINUTE_BATCH_PARAMS = [
    ParamDef("symbols", "list[str]", "Stock symbol list", required=True),
    ParamDef("start_datetime", "str", "Start datetime (YYYY-MM-DD HH:MM:SS)", required=True),
    ParamDef("end_datetime", "str", "End datetime (YYYY-MM-DD HH:MM:SS)", required=True),
    ParamDef("market", "str", "Market (cn/hk/us)", default="cn"),
]

# Concepts module parameters
CONCEPTS_LATEST_PARAMS = [
    ParamDef("include_docs", "bool", "Include related documents", default=True),
]

CONCEPTS_TODAY_PARAMS = []

# Channels module parameters
CHANNELS_SEARCH_PARAMS = [
    ParamDef("query", "string", "Search keywords or URL", required=True),
    ParamDef("page_num", "int", "Page number", default=1),
    ParamDef("page_size", "int", "Page size", default=10),
]

CHANNELS_FOLLOWINGS_PARAMS = [
    ParamDef("page_num", "int", "Page number", default=1),
    ParamDef("page_size", "int", "Page size", default=10),
]

CHANNELS_FOLLOW_PARAMS = [
    ParamDef("channel_id", "string", "Channel ID", required=True),
]

CHANNELS_UNFOLLOW_PARAMS = [
    ParamDef("channel_id", "string", "Channel ID", required=True),
]

CHANNELS_GET_DOCS_PARAMS = [
    ParamDef("channel_ids", "string", "Channel ID list (comma-separated)"),
    ParamDef("page_num", "int", "Page number", default=1),
    ParamDef("page_size", "int", "Page size", default=10),
]

# Agent module parameters
AGENT_CREATE_CONVERSATION_PARAMS = [
    ParamDef("agent_id", "int", "Agent ID (optional, uses system default if not provided)"),
    ParamDef("title", "string", "Conversation title"),
    ParamDef(
        "conversation_type",
        "string",
        "Conversation type: agent_chat, task_chat, debug_chat, bot_chat",
    ),
    ParamDef("meta", "dict", "Metadata dict"),
    ParamDef("channel", "string", "Source channel: universal-bridge, openclaw-weixin, telegram"),
]

AGENT_GET_CONVERSATION_PARAMS = [
    ParamDef("conversation_id", "int", "Conversation ID", required=True),
]

AGENT_CHAT_PARAMS = [
    ParamDef("conversation_id", "int", "Conversation ID", required=True),
    ParamDef("message", "string", "User message content", required=True),
    ParamDef(
        "documents",
        "list[dict]",
        "Related documents, each with doc_id, doc_title, file_type",
    ),
    ParamDef("stream", "bool", "Whether to use streaming response", default=True),
    ParamDef(
        "background",
        "bool",
        "Whether to run agent task in background, returns immediately when true",
        default=False,
    ),
]

AGENT_LIST_MESSAGES_PARAMS = [
    ParamDef("conversation_id", "int", "Conversation ID", required=True),
    ParamDef("limit", "int", "Number of messages to return, max 100", default=10),
    ParamDef("before_message_id", "int", "Fetch messages before this message ID"),
]

AGENT_GET_MESSAGE_EVENTS_PARAMS = [
    ParamDef("conversation_id", "int", "Conversation ID", required=True),
    ParamDef("assistant_message_id", "string", "Assistant message ID", required=True),
    ParamDef("stream", "bool", "Whether to stream events via SSE", default=True),
    ParamDef("timeout", "int", "Timeout in seconds for streaming mode", default=1800),
    ParamDef("from_offset", "int", "Start streaming from specific offset", default=0),
]

AGENT_CANCEL_EXECUTION_PARAMS = [
    ParamDef("conversation_id", "int", "Conversation ID", required=True),
    ParamDef("assistant_message_id", "string", "Assistant message ID to cancel", required=True),
]

AGENT_GET_FILE_PARAMS = [
    ParamDef("file_id", "string", "Agent generated file ID", required=True),
]

# Macro module parameters
MACRO_COMMODITIES_PARAMS = [
    ParamDef(
        "type",
        "string",
        "Commodity type: oil, gold, gas, silver, or platinum",
        required=True,
    ),
    ParamDef("start_date", "str", "Start date (YYYY-MM-DD)", required=True),
    ParamDef(
        "end_date",
        "str",
        "End date (YYYY-MM-DD). Interval must not exceed 10 years.",
        required=True,
    ),
]
