"""Utility functions for CLI."""

import json

from src.params import ParamDef


def generate_epilog(params: list[ParamDef], examples: list[str]) -> str:
    """Generate epilog text with parameter table and examples.

    Args:
        params: List of parameter definitions
        examples: List of example commands

    Returns:
        str: Formatted epilog text
    """
    sections = []

    # Add parameter table
    if params:
        param_lines = ["[bold cyan]Input Parameters:[/bold cyan]"]

        # Calculate column widths
        max_name_len = max(len(p.name) for p in params) if params else 0
        max_type_len = max(len(p.type) for p in params) if params else 0

        for param in params:
            required_mark = "*" if param.required else " "
            name_col = f"{required_mark} {param.name}".ljust(max_name_len + 2)
            type_col = param.type.ljust(max_type_len)

            desc = param.description
            if param.default is not None:
                desc += f" [dim]\\[default: {param.default}][/dim]"

            param_lines.append(f"  {name_col}  {type_col}  {desc}")

        sections.append("\n\n".join(param_lines))

    # Add examples
    if examples:
        example_lines = ["[bold cyan]Examples:[/bold cyan]"]
        for example in examples:
            example_lines.append(f"  {example}")

        sections.append("\n\n".join(example_lines))

    return "\n\n".join(sections)


def parse_json_input(input_str: str) -> dict:
    """Parse JSON input string.

    Args:
        input_str: JSON string

    Returns:
        dict: Parsed JSON object

    Raises:
        ValueError: If JSON is invalid
    """
    if not input_str or input_str == "{}":
        return {}

    try:
        return json.loads(input_str)
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid JSON input: {e}")
