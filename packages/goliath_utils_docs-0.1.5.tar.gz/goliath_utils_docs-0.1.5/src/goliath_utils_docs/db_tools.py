"""Read-only PostgreSQL schema inspection tools for the MCP server.

Provides three capabilities:
  - list_tables: enumerate tables in a schema
  - describe_table: full column/constraint/index details for a table
  - run_query: execute safe, read-only SELECT queries
"""

from __future__ import annotations

import os
import re
from pathlib import Path


def _load_env() -> None:
    """Load .env from the project root (git root) if present."""
    try:
        from dotenv import load_dotenv
    except ImportError:
        return
    # Walk up from cwd to find the git root
    cwd = Path.cwd()
    for parent in [cwd, *cwd.parents]:
        env_file = parent / ".env"
        if env_file.is_file():
            load_dotenv(env_file)
            return


# ── Lazy connection ────────────────────────────────────────────────────────

_db = None


def _get_db():
    """Return a shared Database instance, creating it on first call."""
    global _db
    if _db is None:
        _load_env()
        try:
            from goliath_utils.db import get_db
        except ImportError:
            raise RuntimeError(
                "goliath_utils.db is not available. "
                "Upgrade goliath-utils to a version that includes the db module."
            )
        dsn = os.environ.get("GOLIATH_DB_DSN")
        if dsn:
            _db = get_db(dsn)
        else:
            _db = get_db()
    return _db


_CONNECTION_HELP = (
    "Could not connect to the database. "
    "Set GOLIATH_DB_DSN with a PostgreSQL connection string, "
    "or set GOLIATH_API_URL and GOLIATH_API_KEY for secrets-based connection."
)

# ── list_tables ────────────────────────────────────────────────────────────

_LIST_TABLES_SQL = (
    "SELECT table_name "
    "FROM information_schema.tables "
    "WHERE table_schema = :schema "
    "  AND table_type = 'BASE TABLE' "
    "ORDER BY table_name"
)


def list_tables(schema: str = "public") -> str:
    """List all tables in the given database schema."""
    try:
        db = _get_db()
        rows = db.fetch_all(_LIST_TABLES_SQL, {"schema": schema})
    except RuntimeError as exc:
        return str(exc)
    except Exception as exc:
        if "connect" in str(exc).lower() or "connection" in str(exc).lower():
            return _CONNECTION_HELP
        return f"Database error: {exc}"

    if not rows:
        return f"No tables found in schema '{schema}'."

    names = [r["table_name"] for r in rows]
    lines = [f"Tables in '{schema}' ({len(names)}):"]
    lines.extend(f"  - {n}" for n in names)
    return "\n".join(lines)


# ── describe_table ─────────────────────────────────────────────────────────

_COLUMNS_SQL = (
    "SELECT "
    "  c.column_name, "
    "  c.data_type, "
    "  c.udt_name, "
    "  c.character_maximum_length, "
    "  c.is_nullable, "
    "  c.column_default "
    "FROM information_schema.columns c "
    "WHERE c.table_schema = :schema "
    "  AND c.table_name = :table "
    "ORDER BY c.ordinal_position"
)

_CONSTRAINTS_SQL = (
    "SELECT "
    "  tc.constraint_name, "
    "  tc.constraint_type, "
    "  kcu.column_name "
    "FROM information_schema.table_constraints tc "
    "JOIN information_schema.key_column_usage kcu "
    "  ON tc.constraint_name = kcu.constraint_name "
    "  AND tc.table_schema = kcu.table_schema "
    "WHERE tc.table_schema = :schema "
    "  AND tc.table_name = :table "
    "  AND tc.constraint_type IN ('PRIMARY KEY', 'UNIQUE', 'FOREIGN KEY') "
    "ORDER BY tc.constraint_type, tc.constraint_name, kcu.ordinal_position"
)

_FK_REFS_SQL = (
    "SELECT "
    "  kcu.constraint_name, "
    "  kcu.column_name, "
    "  ccu.table_schema AS ref_schema, "
    "  ccu.table_name AS ref_table, "
    "  ccu.column_name AS ref_column "
    "FROM information_schema.key_column_usage kcu "
    "JOIN information_schema.constraint_column_usage ccu "
    "  ON kcu.constraint_name = ccu.constraint_name "
    "  AND kcu.table_schema = ccu.table_schema "
    "JOIN information_schema.table_constraints tc "
    "  ON tc.constraint_name = kcu.constraint_name "
    "  AND tc.table_schema = kcu.table_schema "
    "WHERE kcu.table_schema = :schema "
    "  AND kcu.table_name = :table "
    "  AND tc.constraint_type = 'FOREIGN KEY'"
)

_INDEXES_SQL = (
    "SELECT "
    "  i.relname AS index_name, "
    "  ix.indisunique AS is_unique, "
    "  ix.indisprimary AS is_primary, "
    "  array_to_string(ARRAY("
    "    SELECT a.attname "
    "    FROM unnest(ix.indkey) WITH ORDINALITY AS k(attnum, ord) "
    "    JOIN pg_attribute a ON a.attrelid = t.oid AND a.attnum = k.attnum "
    "    ORDER BY k.ord"
    "  ), ', ') AS columns "
    "FROM pg_class t "
    "JOIN pg_index ix ON t.oid = ix.indrelid "
    "JOIN pg_class i ON i.oid = ix.indexrelid "
    "JOIN pg_namespace n ON n.oid = t.relnamespace "
    "WHERE n.nspname = :schema "
    "  AND t.relname = :table "
    "ORDER BY i.relname"
)


def describe_table(table: str, schema: str = "public") -> str:
    """Return full schema definition for a table."""
    try:
        db = _get_db()
        params = {"schema": schema, "table": table}

        columns = db.fetch_all(_COLUMNS_SQL, params)
        if not columns:
            return f"Table '{schema}.{table}' not found."

        constraints = db.fetch_all(_CONSTRAINTS_SQL, params)
        fk_refs = db.fetch_all(_FK_REFS_SQL, params)
        indexes = db.fetch_all(_INDEXES_SQL, params)
    except RuntimeError as exc:
        return str(exc)
    except Exception as exc:
        if "connect" in str(exc).lower() or "connection" in str(exc).lower():
            return _CONNECTION_HELP
        return f"Database error: {exc}"

    return _format_table_description(schema, table, columns, constraints, fk_refs, indexes)


def _format_table_description(
    schema: str,
    table: str,
    columns: list[dict],
    constraints: list[dict],
    fk_refs: list[dict],
    indexes: list[dict],
) -> str:
    lines = [f"## {schema}.{table}", ""]

    # Columns
    lines.append("### Columns")
    lines.append("")
    col_header = f"{'Column':<30} {'Type':<20} {'Nullable':<10} {'Default'}"
    lines.append(col_header)
    lines.append("-" * len(col_header))
    for col in columns:
        type_str = col["udt_name"]
        max_len = col.get("character_maximum_length")
        if max_len:
            type_str = f"{type_str}({max_len})"
        nullable = col["is_nullable"]
        default = col.get("column_default") or ""
        lines.append(f"{col['column_name']:<30} {type_str:<20} {nullable:<10} {default}")
    lines.append("")

    # Primary key
    pk_cols = [c["column_name"] for c in constraints if c["constraint_type"] == "PRIMARY KEY"]
    if pk_cols:
        lines.append(f"### Primary Key: ({', '.join(pk_cols)})")
        lines.append("")

    # Unique constraints
    unique_map: dict[str, list[str]] = {}
    for c in constraints:
        if c["constraint_type"] == "UNIQUE":
            unique_map.setdefault(c["constraint_name"], []).append(c["column_name"])
    if unique_map:
        lines.append("### Unique Constraints")
        for name, cols in unique_map.items():
            lines.append(f"  - {name}: ({', '.join(cols)})")
        lines.append("")

    # Foreign keys
    fk_map: dict[str, dict] = {}
    for fk in fk_refs:
        fk_map.setdefault(fk["constraint_name"], []).append(fk)
    if fk_map:
        lines.append("### Foreign Keys")
        for name, refs in fk_map.items():
            for ref in refs:
                lines.append(
                    f"  - {ref['column_name']} -> "
                    f"{ref['ref_schema']}.{ref['ref_table']}({ref['ref_column']})"
                )
        lines.append("")

    # Indexes
    non_pk_indexes = [ix for ix in indexes if not ix.get("is_primary")]
    if non_pk_indexes:
        lines.append("### Indexes")
        for ix in non_pk_indexes:
            unique_tag = " UNIQUE" if ix.get("is_unique") else ""
            lines.append(f"  - {ix['index_name']} ({ix['columns']}){unique_tag}")
        lines.append("")

    return "\n".join(lines)


# ── run_query (read-only) ─────────────────────────────────────────────────

_FORBIDDEN_PATTERN = re.compile(
    r"\b("
    r"INSERT|UPDATE|DELETE|DROP|ALTER|TRUNCATE|CREATE|GRANT|REVOKE|"
    r"COPY|LOCK|VACUUM|REINDEX|CLUSTER|REFRESH|COMMENT|SECURITY|"
    r"SET\s+ROLE|SET\s+SESSION|REASSIGN|DO\s+\$"
    r")\b",
    re.IGNORECASE,
)

_ALLOWED_START = re.compile(
    r"^\s*(SELECT|WITH|EXPLAIN)\b",
    re.IGNORECASE,
)


def _validate_query(query: str) -> str | None:
    """Return an error message if the query is unsafe, else None."""
    stripped = query.strip().rstrip(";").strip()

    if not stripped:
        return "Empty query."

    if not _ALLOWED_START.match(stripped):
        return "Only SELECT, WITH, and EXPLAIN queries are allowed."

    if _FORBIDDEN_PATTERN.search(stripped):
        return "Query contains forbidden statements. Only read-only queries are allowed."

    # Block multiple statements — strip string literals then check for semicolons
    no_strings = re.sub(r"'[^']*'", "", stripped)
    no_strings = re.sub(r"\$\$.*?\$\$", "", no_strings, flags=re.DOTALL)
    if ";" in no_strings:
        return "Multiple statements are not allowed."

    return None


def _apply_limit(query: str, limit: int) -> str:
    """Append LIMIT if the query doesn't already have one."""
    if re.search(r"\bLIMIT\b", query, re.IGNORECASE):
        return query
    return f"{query.rstrip().rstrip(';')} LIMIT {limit}"


def _format_results(rows: list[dict]) -> str:
    """Format query results as a readable text table."""
    if not rows:
        return "Query returned 0 rows."

    cols = list(rows[0].keys())
    widths = [len(c) for c in cols]
    str_rows = []
    for row in rows:
        vals = [str(row.get(c, "")) for c in cols]
        for i, v in enumerate(vals):
            widths[i] = max(widths[i], len(v))
        str_rows.append(vals)

    header = " | ".join(c.ljust(w) for c, w in zip(cols, widths))
    sep = "-+-".join("-" * w for w in widths)
    body = "\n".join(
        " | ".join(v.ljust(w) for v, w in zip(vals, widths))
        for vals in str_rows
    )

    return f"{len(rows)} row(s):\n\n{header}\n{sep}\n{body}"


def run_query(query: str, limit: int = 100) -> str:
    """Execute a read-only SQL query with safety validation."""
    limit = max(1, min(limit, 500))

    error = _validate_query(query)
    if error:
        return f"Query rejected: {error}"

    try:
        db = _get_db()

        # Defense in depth: read-only transaction
        db.execute("BEGIN TRANSACTION READ ONLY")
        try:
            wrapped = _apply_limit(query, limit)
            rows = db.fetch_all(wrapped)
        except Exception:
            db.execute("ROLLBACK")
            raise
        else:
            db.execute("ROLLBACK")  # always rollback, never commit

    except RuntimeError as exc:
        return str(exc)
    except Exception as exc:
        if "connect" in str(exc).lower() or "connection" in str(exc).lower():
            return _CONNECTION_HELP
        return f"Query error: {exc}"

    return _format_results(rows)
