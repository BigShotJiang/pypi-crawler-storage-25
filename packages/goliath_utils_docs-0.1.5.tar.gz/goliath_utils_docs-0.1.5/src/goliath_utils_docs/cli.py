"""CLI for installing/uninstalling the MCP server and running it directly."""

from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path

SERVER_NAME = "goliath-utils-docs"
MCP_CONFIG = {
    "command": "uvx",
    "args": ["goliath-utils-docs", "serve"],
}


def _find_project_root() -> Path:
    """Walk up to find a git root, fall back to cwd."""
    cwd = Path.cwd()
    for parent in [cwd, *cwd.parents]:
        if (parent / ".git").exists():
            return parent
    return cwd


def _mcp_path() -> Path:
    return _find_project_root() / ".mcp.json"


def _read_mcp(path: Path) -> dict:
    if path.exists():
        return json.loads(path.read_text(encoding="utf-8"))
    return {}


def _write_mcp(path: Path, data: dict) -> None:
    path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")


def install() -> None:
    """Register the MCP server in the project's .mcp.json."""
    path = _mcp_path()
    data = _read_mcp(path)
    data.setdefault("mcpServers", {})
    data["mcpServers"][SERVER_NAME] = MCP_CONFIG
    _write_mcp(path, data)
    print(f"Installed {SERVER_NAME} in {path}")
    print("Restart Claude Code to activate.")


def uninstall() -> None:
    """Remove the MCP server from the project's .mcp.json."""
    path = _mcp_path()
    data = _read_mcp(path)
    servers = data.get("mcpServers", {})
    if SERVER_NAME in servers:
        del servers[SERVER_NAME]
        _write_mcp(path, data)
        print(f"Removed {SERVER_NAME} from {path}")
    else:
        print(f"{SERVER_NAME} not found in {path}")


def serve() -> None:
    """Run the MCP server (stdio transport)."""
    from .server import main as server_main
    asyncio.run(server_main())


def main() -> None:
    args = sys.argv[1:]

    if not args or args[0] in ("-h", "--help"):
        print("Usage: goliath-utils-docs <command>")
        print()
        print("Commands:")
        print("  install    Add MCP server to project .mcp.json")
        print("  uninstall  Remove MCP server from project .mcp.json")
        print("  serve      Run the MCP server directly")
        return

    command = args[0]

    if command == "install":
        install()
    elif command == "uninstall":
        uninstall()
    elif command == "serve":
        serve()
    else:
        print(f"Unknown command: {command}")
        sys.exit(1)
