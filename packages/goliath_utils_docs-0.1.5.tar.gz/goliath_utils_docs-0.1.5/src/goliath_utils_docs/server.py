"""MCP server exposing goliath-utils documentation and database schema to Claude Code."""

from __future__ import annotations

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

from .db_tools import describe_table, list_tables, run_query
from .introspect import (
    MODULES,
    ModuleDoc,
    extract_all,
    format_module_docs,
    format_overview,
    search_docs,
)

app = Server("goliath-utils-docs")

_docs: dict[str, ModuleDoc] | None = None


def _get_docs() -> dict[str, ModuleDoc]:
    global _docs
    if _docs is None:
        _docs = extract_all()
    return _docs


@app.list_tools()
async def list_tools() -> list[Tool]:
    return [
        # ── Documentation tools ────────────────────────────────────────
        Tool(
            name="list_available_utils",
            description=(
                "List all available goliath-utils modules, classes, and functions "
                "with a high-level overview. Call this first to understand what "
                "utilities are available."
            ),
            inputSchema={"type": "object", "properties": {}},
        ),
        Tool(
            name="get_module_docs",
            description=(
                "Get full API documentation for a specific goliath-utils module. "
                "Returns all classes, methods with signatures and descriptions. "
                "Modules: atrax, s3, sns, secrets, helpers."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "module": {
                        "type": "string",
                        "description": "Module name: atrax, s3, sns, secrets, or helpers",
                        "enum": list(MODULES.keys()),
                    },
                },
                "required": ["module"],
            },
        ),
        Tool(
            name="search_utils",
            description=(
                "Search across all goliath-utils APIs by keyword. "
                "Returns matching methods and functions with their signatures "
                "and descriptions. Useful when you know what you want to do "
                "but not which module or method to use."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Search terms (e.g., 'groupby aggregate', 'upload file s3', 'merge join')",
                    },
                },
                "required": ["query"],
            },
        ),
        # ── Database schema tools ──────────────────────────────────────
        Tool(
            name="list_tables",
            description=(
                "List all tables in the Goliath platform PostgreSQL database. "
                "Use this to explore the database, see what tables exist, "
                "or when the user asks about the database schema or structure. "
                "Returns table names in the specified schema (default: public)."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "schema": {
                        "type": "string",
                        "description": "Database schema to list tables from (default: public)",
                        "default": "public",
                    },
                },
            },
        ),
        Tool(
            name="describe_table",
            description=(
                "Get the full schema definition for a table in the Goliath "
                "PostgreSQL database. Use this to understand table structure "
                "before writing queries, or when the user asks about columns, "
                "types, or relationships for a specific table. Returns columns "
                "(name, type, nullable, default), primary keys, foreign keys, "
                "and indexes."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "table": {
                        "type": "string",
                        "description": "Table name to describe",
                    },
                    "schema": {
                        "type": "string",
                        "description": "Database schema (default: public)",
                        "default": "public",
                    },
                },
                "required": ["table"],
            },
        ),
        Tool(
            name="run_query",
            description=(
                "Execute a read-only SQL query against the Goliath PostgreSQL "
                "database. Use this to explore data, check row counts, verify "
                "relationships, or answer questions about what is in the database. "
                "Only SELECT, WITH, and EXPLAIN statements are allowed. "
                "Results are limited to prevent large result sets."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "SQL SELECT query to execute",
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Maximum rows to return (default: 100, max: 500)",
                        "default": 100,
                        "minimum": 1,
                        "maximum": 500,
                    },
                },
                "required": ["query"],
            },
        ),
    ]


@app.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:

    # ── Documentation tools ────────────────────────────────────────────
    if name == "list_available_utils":
        docs = _get_docs()
        text = format_overview(docs)
        return [TextContent(type="text", text=text)]

    elif name == "get_module_docs":
        docs = _get_docs()
        module = arguments.get("module", "")
        if module not in MODULES:
            return [TextContent(
                type="text",
                text=f"Unknown module: {module}. Available: {', '.join(MODULES.keys())}",
            )]
        doc = docs.get(module)
        if doc is None:
            return [TextContent(type="text", text=f"Module {module} could not be loaded.")]
        text = format_module_docs(doc)
        return [TextContent(type="text", text=text)]

    elif name == "search_utils":
        docs = _get_docs()
        query = arguments.get("query", "")
        if not query.strip():
            return [TextContent(type="text", text="Please provide a search query.")]
        text = search_docs(docs, query)
        return [TextContent(type="text", text=text)]

    # ── Database schema tools ──────────────────────────────────────────
    elif name == "list_tables":
        schema = arguments.get("schema", "public")
        text = list_tables(schema)
        return [TextContent(type="text", text=text)]

    elif name == "describe_table":
        table = arguments.get("table", "")
        if not table:
            return [TextContent(type="text", text="Please provide a table name.")]
        schema = arguments.get("schema", "public")
        text = describe_table(table, schema)
        return [TextContent(type="text", text=text)]

    elif name == "run_query":
        query = arguments.get("query", "")
        if not query.strip():
            return [TextContent(type="text", text="Please provide a SQL query.")]
        limit = arguments.get("limit", 100)
        text = run_query(query, limit)
        return [TextContent(type="text", text=text)]

    return [TextContent(type="text", text=f"Unknown tool: {name}")]


async def main():
    async with stdio_server() as (read, write):
        await app.run(read, write, app.create_initialization_options())
