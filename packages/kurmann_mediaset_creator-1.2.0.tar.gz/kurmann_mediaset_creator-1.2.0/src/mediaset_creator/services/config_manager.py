"""Konfigurationsmanagement für die CLI (persistent in ~/.config/mediaset-creator/config.toml)."""

from pathlib import Path

# tomllib ist ab Python 3.11 in der Standardbibliothek
import tomllib

CONFIG_DIR = Path.home() / ".config" / "mediaset-creator"
CONFIG_PATH = CONFIG_DIR / "config.toml"

# Erlaubte Schlüssel mit Beschreibung und Standardwert
ALLOWED_KEYS: dict[str, tuple[str, str]] = {
    "og.base_url": ("Stamm-URL für OG-Tags (z.B. https://example.com/shares/)", ""),
    "og.enabled": ("OG-Tags aktivieren (true/false)", "true"),
    "og.site_name": ("OG site_name Metadatum", ""),
    "og.locale": ("OG locale Metadatum", "de_CH"),
    "thumbnails.sidecar": ("Sidecar-Bilder als Landscape-Quelle verwenden (true/false)", "true"),
    "title.filename_fallback": ("Dateiname als Titel-Fallback verwenden (true/false)", "true"),
    "filename.date_prefix": ("Datum als Dateiname-Prefix verwenden (true/false)", "true"),
    "tools.ffmpeg": ("Pfad zur ffmpeg-Binärdatei", "ffmpeg"),
    "tools.ffprobe": ("Pfad zur ffprobe-Binärdatei", "ffprobe"),
    "tools.nice_level": ("CPU-Priorität für ffmpeg via nice (0–19, leer = keine Drosselung)", ""),
    "video.auto_compress": ("Automatische Videokomprimierung bei >4K oder >50 Mbit/s (true/false)", "true"),
}


def _load_raw() -> dict:
    """Liest die TOML-Datei und gibt das rohe Dict zurück."""
    if not CONFIG_PATH.exists():
        return {}
    return tomllib.loads(CONFIG_PATH.read_text(encoding="utf-8"))


def _save_raw(data: dict) -> None:
    """Schreibt das Dict als TOML-Datei. Einfacher Writer ohne externe Dependency."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    lines: list[str] = []
    for section_key, section_val in sorted(data.items()):
        if isinstance(section_val, dict):
            lines.append(f"[{section_key}]")
            for k, v in sorted(section_val.items()):
                lines.append(f'{k} = "{v}"')
            lines.append("")
        else:
            lines.append(f'{section_key} = "{section_val}"')
    CONFIG_PATH.write_text("\n".join(lines) + "\n", encoding="utf-8")


def get(key: str) -> str | None:
    """Liest einen Konfigurationswert. Gibt None zurück wenn nicht gesetzt."""
    if key not in ALLOWED_KEYS:
        return None
    parts = key.split(".", 1)
    data = _load_raw()
    if len(parts) == 2:
        section = data.get(parts[0], {})
        if isinstance(section, dict):
            return str(section.get(parts[1], "")) or None
    return str(data.get(key, "")) or None


def get_with_default(key: str) -> str:
    """Liest einen Konfigurationswert mit Fallback auf den Standardwert."""
    val = get(key)
    if val is not None:
        return val
    if key in ALLOWED_KEYS:
        return ALLOWED_KEYS[key][1]
    return ""


def set_value(key: str, value: str) -> bool:
    """Speichert einen Konfigurationswert. Gibt False zurück wenn der Schlüssel ungültig ist."""
    if key not in ALLOWED_KEYS:
        return False
    parts = key.split(".", 1)
    data = _load_raw()
    if len(parts) == 2:
        section = data.setdefault(parts[0], {})
        if not isinstance(section, dict):
            data[parts[0]] = {}
            section = data[parts[0]]
        section[parts[1]] = value
    else:
        data[key] = value
    _save_raw(data)
    return True


def list_all() -> dict[str, str]:
    """Gibt alle konfigurierten Werte zurück (nur gesetzte Werte, keine Defaults)."""
    data = _load_raw()
    result: dict[str, str] = {}
    for key in ALLOWED_KEYS:
        parts = key.split(".", 1)
        if len(parts) == 2:
            section = data.get(parts[0], {})
            if isinstance(section, dict) and parts[1] in section:
                result[key] = str(section[parts[1]])
        elif key in data:
            result[key] = str(data[key])
    return result
