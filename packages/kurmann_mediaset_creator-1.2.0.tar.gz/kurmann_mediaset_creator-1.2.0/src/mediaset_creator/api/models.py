"""Request/Result-Modelle und Events für die öffentliche API."""

from dataclasses import dataclass, field
from enum import StrEnum
from pathlib import Path


@dataclass
class MediaItem:
    """Ein Medienelement im Mediaset. Aktuell nur Video unterstützt."""

    source_path: Path
    media_type: str = "video"
    title: str | None = None
    description: str | None = None
    category: str | None = None
    recording_date: str | None = None
    quality_label: str | None = None


@dataclass
class CreateMediasetRequest:
    """Fachlicher Request zur Erstellung eines Mediasets."""

    items: list[MediaItem]
    mediaset_title: str | None = None
    output_dir: Path | None = None
    enable_og_tags: bool = True


@dataclass
class RuntimeOptions:
    """Technische Laufzeitoptionen, getrennt vom fachlichen Request."""

    base_url: str = ""
    ffmpeg_path: str = "ffmpeg"
    ffprobe_path: str = "ffprobe"


@dataclass
class MediasetResult:
    """Ergebnis der Mediaset-Erstellung."""

    success: bool
    output_dir: Path | None = None
    html_path: Path | None = None
    zip_paths: list[Path] = field(default_factory=list)
    landscape_paths: list[Path] = field(default_factory=list)
    portrait_paths: list[Path] = field(default_factory=list)
    error_message: str | None = None


class MediasetCreatorStage(StrEnum):
    """Stabile Stage-IDs für strukturierte Events."""

    MEDIASET_GESTARTET = "mediaset_gestartet"
    VIDEO_ANALYSIERT = "video_analysiert"
    VIDEO_KOPIERT = "video_kopiert"
    VIDEO_KOMPRIMIERT = "video_komprimiert"
    THUMBNAILS_ERSTELLT = "thumbnails_erstellt"
    ZIP_ERSTELLT = "zip_erstellt"
    HTML_GENERIERT = "html_generiert"
    MEDIASET_ABGESCHLOSSEN = "mediaset_abgeschlossen"


@dataclass
class MediasetCreatorEvent:
    """Strukturiertes Event für Fortschrittsinformationen."""

    stage_id: str
    message: str
    current: int | None = None
    total: int | None = None
