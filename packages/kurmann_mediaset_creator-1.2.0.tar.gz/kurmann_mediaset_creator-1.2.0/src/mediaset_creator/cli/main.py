"""CLI-Adapter für den Mediaset Creator."""

import json
import sys
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console

from mediaset_creator.api import (
    CreateMediasetRequest,
    MediaItem,
    MediasetCreatorEvent,
    RuntimeOptions,
    create_mediaset,
)
from mediaset_creator.services import config_manager

app = typer.Typer(invoke_without_command=True)
config_app = typer.Typer()
app.add_typer(config_app, name="config", help="Konfiguration verwalten.")

stderr_console = Console(stderr=True)


@app.callback()
def main(ctx: typer.Context) -> None:
    """Mediaset Creator – Erstellt Mediensets (statisches HTML) aus Videodateien."""
    if ctx.invoked_subcommand is None:
        # Hilfe anzeigen wenn ohne Subcommand aufgerufen
        ctx.get_help()


@app.command(name="create")
def create_cmd(
    video: Optional[Path] = typer.Argument(
        None,
        help="Pfad zur Videodatei (für Einzelvideo-Modus).",
        exists=True,
        dir_okay=False,
    ),
    from_json: Optional[Path] = typer.Option(
        None,
        "--from-json",
        help="JSON-Datei mit Metadaten für Multi-Video-Mediaset.",
        exists=True,
        dir_okay=False,
    ),
    title: Optional[str] = typer.Option(
        None,
        "--title",
        help="Übergeordneter Mediaset-Titel (h1).",
    ),
    video_title: Optional[str] = typer.Option(
        None,
        "--video-title",
        help="Titel des Videos.",
    ),
    video_description: Optional[str] = typer.Option(
        None,
        "--video-description",
        help="Beschreibung des Videos.",
    ),
    video_category: Optional[str] = typer.Option(
        None,
        "--video-category",
        help="Kategorie des Videos.",
    ),
    video_date: Optional[str] = typer.Option(
        None,
        "--video-date",
        help="Aufnahmedatum des Videos (Freitext, z.B. '1. Juli 2024').",
    ),
    video_quality: Optional[str] = typer.Option(
        None,
        "--video-quality",
        help="Qualitätsangabe (z.B. 'Dolby Vision', '4K HDR').",
    ),
    output_dir: Optional[Path] = typer.Option(
        None,
        "--output-dir",
        help="Basisverzeichnis für die Ausgabe. Default: Verzeichnis der Quelldatei.",
    ),
    no_og_tags: bool = typer.Option(
        False,
        "--no-og-tags",
        help="OG-Tags deaktivieren.",
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        "-v",
        help="Zusätzliche Ablaufinformationen auf stderr ausgeben.",
    ),
) -> None:
    """Erstellt ein Mediaset aus einer oder mehreren Videodateien."""
    # Eingabe validieren
    if video is None and from_json is None:
        stderr_console.print("[red]Fehler:[/red] Entweder VIDEO oder --from-json angeben.")
        raise typer.Exit(code=2)

    if video is not None and from_json is not None:
        stderr_console.print("[red]Fehler:[/red] VIDEO und --from-json können nicht gleichzeitig verwendet werden.")
        raise typer.Exit(code=2)

    # Request zusammenstellen
    if from_json is not None:
        request = _build_request_from_json(from_json, output_dir, no_og_tags)
    else:
        assert video is not None
        # Einzelvideo: video-title fällt auf mediaset-title zurück
        effective_video_title = video_title or title
        # Dateiname als letzter Fallback (abschaltbar via Config)
        if not effective_video_title:
            use_filename = config_manager.get_with_default("title.filename_fallback").lower() != "false"
            if use_filename:
                effective_video_title = video.stem
        # Mediaset-Titel: expliziter Titel oder Video-Titel
        effective_mediaset_title = title or effective_video_title
        item = MediaItem(
            source_path=video,
            media_type="video",
            title=effective_video_title,
            description=video_description,
            category=video_category,
            recording_date=video_date,
            quality_label=video_quality,
        )
        request = CreateMediasetRequest(
            items=[item],
            mediaset_title=effective_mediaset_title,
            output_dir=output_dir,
            enable_og_tags=not no_og_tags,
        )

    # OG-Tags: Config-Wert beachten wenn nicht explizit deaktiviert
    if not no_og_tags:
        og_enabled_cfg = config_manager.get_with_default("og.enabled")
        if og_enabled_cfg.lower() == "false":
            request.enable_og_tags = False

    # RuntimeOptions aus Config zusammenstellen
    runtime = RuntimeOptions(
        base_url=config_manager.get_with_default("og.base_url"),
        ffmpeg_path=config_manager.get_with_default("tools.ffmpeg"),
        ffprobe_path=config_manager.get_with_default("tools.ffprobe"),
    )

    # Event-Callback
    def on_event(event: MediasetCreatorEvent) -> None:
        label = f" [{event.current}/{event.total}]" if event.current is not None else ""
        stderr_console.print(f"  {event.message}{label}")

    event_callback = on_event if verbose else None

    # API aufrufen
    result = create_mediaset(request, runtime, on_event=event_callback)

    if not result.success:
        stderr_console.print(f"[red]Fehler:[/red] {result.error_message}")
        raise typer.Exit(code=1)

    # Ergebnis auf stdout
    print(result.output_dir)


def _build_request_from_json(
    json_path: Path,
    output_dir: Path | None,
    no_og_tags: bool,
) -> CreateMediasetRequest:
    """Liest eine JSON-Datei und baut daraus einen CreateMediasetRequest."""
    data = json.loads(json_path.read_text(encoding="utf-8"))

    items: list[MediaItem] = []
    for v in data.get("videos", []):
        items.append(MediaItem(
            source_path=Path(v["path"]),
            media_type="video",
            title=v.get("title"),
            description=v.get("description"),
            category=v.get("category"),
            recording_date=v.get("recording_date"),
            quality_label=v.get("quality_label"),
        ))

    if not items:
        stderr_console.print("[red]Fehler:[/red] Keine Videos in der JSON-Datei gefunden.")
        raise typer.Exit(code=2)

    return CreateMediasetRequest(
        items=items,
        mediaset_title=data.get("title"),
        output_dir=output_dir,
        enable_og_tags=not no_og_tags,
    )


# --- Config-Subcommands ---

@config_app.command(name="set")
def config_set_cmd(
    key: str = typer.Argument(..., help="Konfigurationsschlüssel (z.B. 'og.base_url')."),
    value: str = typer.Argument(..., help="Wert."),
) -> None:
    """Speichert einen Konfigurationswert."""
    if not config_manager.set_value(key, value):
        stderr_console.print(f"[red]Fehler:[/red] Unbekannter Schlüssel '{key}'.")
        stderr_console.print("Erlaubte Schlüssel:")
        for k, (desc, default) in config_manager.ALLOWED_KEYS.items():
            stderr_console.print(f"  {k}: {desc} (Standard: {default or '(leer)'})")
        raise typer.Exit(code=2)
    stderr_console.print(f"Gespeichert: {key} = {value}")


@config_app.command(name="get")
def config_get_cmd(
    key: str = typer.Argument(..., help="Konfigurationsschlüssel."),
) -> None:
    """Liest einen Konfigurationswert."""
    if key not in config_manager.ALLOWED_KEYS:
        stderr_console.print(f"[red]Fehler:[/red] Unbekannter Schlüssel '{key}'.")
        raise typer.Exit(code=2)
    val = config_manager.get(key)
    if val is None:
        desc, default = config_manager.ALLOWED_KEYS[key]
        stderr_console.print(f"(nicht gesetzt, Standard: {default or '(leer)'})")
    else:
        print(val)


@config_app.command(name="list")
def config_list_cmd() -> None:
    """Zeigt alle konfigurierten Werte an."""
    stored = config_manager.list_all()
    if not stored:
        stderr_console.print("Keine Konfigurationswerte gespeichert.")
        stderr_console.print(f"Konfigurationsdatei: {config_manager.CONFIG_PATH}")
        return
    for key, val in sorted(stored.items()):
        print(f"{key} = {val}")
