"""Videoprobing und -komprimierung via ffprobe/ffmpeg."""

import json
import subprocess
from dataclasses import dataclass
from pathlib import Path


@dataclass
class VideoInfo:
    """Technische Metadaten eines Videos."""

    width: int
    height: int
    bitrate_bps: int
    codec_name: str
    duration_seconds: float = 0.0

    @property
    def exceeds_4k(self) -> bool:
        """True wenn Auflösung grösser als 4K UHD (3840×2160)."""
        return self.width * self.height > 3840 * 2160

    @property
    def exceeds_bitrate_threshold(self) -> bool:
        """True wenn Bitrate über 50 Mbit/s liegt."""
        return self.bitrate_bps > 50_000_000

    @property
    def needs_compression(self) -> bool:
        """True wenn Kompression empfohlen wird (>4K oder >50 Mbit/s)."""
        return self.exceeds_4k or self.exceeds_bitrate_threshold

    def summary(self) -> str:
        """Lesbare Zusammenfassung für Log-Ausgaben."""
        megapixel = self.width * self.height / 1_000_000
        mbit = self.bitrate_bps / 1_000_000
        return f"{self.width}×{self.height} ({megapixel:.1f} MP) | {mbit:.0f} Mbit/s | {self.codec_name}"


def probe_video(source_path: Path, ffprobe_path: str = "ffprobe") -> VideoInfo | None:
    """Analysiert Videoauflösung und Bitrate via ffprobe.

    Returns:
        VideoInfo mit Metadaten, oder None bei Fehler.
    """
    cmd = [
        ffprobe_path,
        "-v", "quiet",
        "-print_format", "json",
        "-show_streams",
        "-show_format",
        str(source_path),
    ]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        data = json.loads(result.stdout)
    except (subprocess.CalledProcessError, FileNotFoundError, json.JSONDecodeError):
        return None

    # Ersten Video-Stream suchen
    video_stream = next(
        (s for s in data.get("streams", []) if s.get("codec_type") == "video"),
        None,
    )
    if not video_stream:
        return None

    try:
        width = int(video_stream["width"])
        height = int(video_stream["height"])
        codec_name = video_stream.get("codec_name", "unbekannt")
        bitrate_bps = int(data["format"]["bit_rate"])
        duration_seconds = float(data["format"].get("duration", 0))
    except (KeyError, ValueError, TypeError):
        return None

    return VideoInfo(
        width=width, height=height, bitrate_bps=bitrate_bps,
        codec_name=codec_name, duration_seconds=duration_seconds,
    )


def compress_video(
    source_path: Path,
    output_path: Path,
    ffmpeg_path: str = "ffmpeg",
    nice_level: int | None = None,
) -> Path:
    """Komprimiert Video zu MP4 (HEVC/VideoToolbox, 2560×1440).

    Verwendet macOS-spezifische Hardware-Beschleunigung (hevc_videotoolbox, aac_at).
    Auf anderen Plattformen schlägt ffmpeg fehl und CalledProcessError wird geworfen.

    Args:
        source_path: Quelldatei (z.B. .mov, .mp4)
        output_path: Zieldatei (immer .mp4)
        ffmpeg_path: Pfad zur ffmpeg-Binärdatei
        nice_level: CPU-Priorität via nice (0–19); None = keine Drosselung

    Returns:
        Pfad zur komprimierten MP4-Datei.

    Raises:
        subprocess.CalledProcessError: Wenn ffmpeg einen Fehler zurückgibt.
    """
    ffmpeg_cmd = [
        ffmpeg_path,
        "-i", str(source_path),
        "-vf", "scale=2560:1440:flags=lanczos",
        "-c:v", "hevc_videotoolbox",
        "-profile:v", "main10",
        "-pix_fmt", "p010le",
        "-q:v", "72",
        "-tag:v", "hvc1",
        "-g", "30",
        "-c:a", "aac_at",
        "-b:a", "192k",
        "-movflags", "+faststart",
        str(output_path),
    ]

    if nice_level is not None:
        cmd = ["nice", "-n", str(nice_level)] + ffmpeg_cmd
    else:
        cmd = ffmpeg_cmd

    subprocess.run(cmd, check=True)
    return output_path
