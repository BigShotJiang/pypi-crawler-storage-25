"""Thumbnail-Erzeugung, NFO-Generierung und ZIP-Erstellung für Video-Medienelemente."""

import shutil
import zipfile
from pathlib import Path
from xml.dom.minidom import parseString
from xml.etree.ElementTree import Element, SubElement, tostring

from vorschaubild_manager import ExtractRequest, RuntimeOptions as VMRuntimeOptions, extract

from mediaset_creator.api.models import RuntimeOptions

# Bildformate, die als Sidecar-Dateien akzeptiert werden
_IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".tiff", ".tif", ".heic", ".heif"}


def find_sidecar_image(video_path: Path) -> Path | None:
    """Sucht eine Sidecar-Bilddatei neben dem Video.

    Akzeptiert Dateien mit gleichem Stamm oder gleichem Stamm + beliebigem Suffix
    (z.B. video.jpg, video-landscape.jpg, video_thumb.png).

    Returns:
        Pfad zur gefundenen Sidecar-Datei oder None.
    """
    stem = video_path.stem
    parent = video_path.parent

    # Exakter Name zuerst (video.jpg)
    for ext in _IMAGE_EXTENSIONS:
        candidate = parent / f"{stem}{ext}"
        if candidate.exists():
            return candidate

    # Gleicher Stamm mit Suffix (video-landscape.jpg, video_thumb.png)
    for path in parent.iterdir():
        if not path.is_file():
            continue
        if path.suffix.lower() not in _IMAGE_EXTENSIONS:
            continue
        if path.stem.startswith(stem) and path.stem != stem:
            return path

    return None


def create_video_thumbnails(
    source_path: Path,
    output_dir: Path,
    runtime: RuntimeOptions | None = None,
    use_sidecar: bool = True,
    title: str | None = None,
    category: str | None = None,
    recording_date: str | None = None,
) -> tuple[Path, Path]:
    """Erstellt Landscape- und Portrait-Vorschaubilder für ein Video.

    Wenn use_sidecar True ist und eine Sidecar-Bilddatei neben dem Video liegt,
    wird diese als Landscape-Bild kopiert und daraus ein Portrait-Poster erstellt.
    Andernfalls werden beide Bilder automatisch aus dem Video extrahiert.

    Titel, Kategorie und Datum werden als Overlay-Text an den
    vorschaubild-manager übergeben und ins Poster eingebettet.

    Returns:
        Tuple aus (landscape_path, portrait_path).
    """
    runtime = runtime or RuntimeOptions()
    vm_runtime = VMRuntimeOptions(
        ffmpeg=runtime.ffmpeg_path,
        ffprobe=runtime.ffprobe_path,
    )

    # Overlay-Parameter für Poster
    overlay_kwargs: dict[str, str] = {}
    if title:
        overlay_kwargs["overlay_title"] = title
    if category:
        overlay_kwargs["overlay_category"] = category
    if recording_date:
        overlay_kwargs["overlay_note"] = recording_date

    sidecar = find_sidecar_image(source_path) if use_sidecar else None

    if sidecar is not None:
        # Sidecar als Landscape verwenden
        landscape_dest = output_dir / f"{source_path.stem}-landscape{sidecar.suffix}"
        shutil.copy2(sidecar, landscape_dest)
        landscape_path = landscape_dest

        # Portrait-Poster aus dem Sidecar-Bild via vorschaubild-manager
        portrait_result = extract(
            ExtractRequest(
                input_path=str(sidecar),
                format="poster",
                mode="auto",
                output_dir=str(output_dir),
                output_name_suffix="-poster",
                **overlay_kwargs,
            ),
            runtime=vm_runtime,
        )
        portrait_path = Path(portrait_result.poster_path)
    else:
        # Landscape (16:9, 1920x1080) aus dem Video
        landscape_result = extract(
            ExtractRequest(
                input_path=str(source_path),
                format="landscape",
                mode="auto",
                output_dir=str(output_dir),
                output_name_suffix="-landscape",
            ),
            runtime=vm_runtime,
        )
        landscape_path = Path(landscape_result.poster_path)

        # Portrait / Poster (2:3, 1080x1620) aus dem Video
        portrait_result = extract(
            ExtractRequest(
                input_path=str(source_path),
                format="poster",
                mode="auto",
                output_dir=str(output_dir),
                output_name_suffix="-poster",
                **overlay_kwargs,
            ),
            runtime=vm_runtime,
        )
        portrait_path = Path(portrait_result.poster_path)

    return landscape_path, portrait_path


def create_nfo(
    video_stem: str,
    output_dir: Path,
    title: str | None = None,
    published: str | None = None,
    category: str | None = None,
    description: str | None = None,
) -> Path:
    """Erstellt eine NFO-Datei im Firecore/Infuse-Format (media type=Other).

    Verwendet das «Other»-Format für nicht-kommerzielle Videos,
    wie von Firecore empfohlen.

    Args:
        video_stem: Dateiname-Stamm (ohne Erweiterung), muss zum Video passen.
        output_dir: Ausgabeverzeichnis.
        title: Titel des Videos.
        published: Veröffentlichungsdatum im ISO-Format (YYYY-MM-DD).
        category: Kategorie (wird als Author verwendet).
        description: Beschreibung des Videos.

    Returns:
        Pfad zur erstellten NFO-Datei.
    """
    media = Element("media", attrib={"type": "Other"})

    if title:
        el = SubElement(media, "title")
        el.text = title

    if description:
        el = SubElement(media, "description")
        el.text = description

    if published:
        el = SubElement(media, "published")
        el.text = published

    # Genre ist immer "Family"
    genres = SubElement(media, "genres")
    genre = SubElement(genres, "genre")
    genre.text = "Family"

    # Kategorie wird als Author verwendet
    if category:
        authors = SubElement(media, "authors")
        author = SubElement(authors, "author")
        author.text = category

    nfo_path = output_dir / f"{video_stem}.nfo"
    raw_xml = tostring(media, encoding="unicode")
    pretty_xml = parseString(raw_xml).toprettyxml(indent="  ", encoding="UTF-8")
    nfo_path.write_bytes(pretty_xml)
    return nfo_path


def create_zip(
    video_path: Path,
    landscape_path: Path,
    portrait_path: Path,
    output_dir: Path,
    zip_video_path: Path | None = None,
    nfo_path: Path | None = None,
) -> Path:
    """Erstellt ein ZIP-Archiv mit Video, Vorschaubildern und optional NFO.

    Args:
        video_path: Video im Ausgabeverzeichnis (bestimmt ZIP-Namen).
        zip_video_path: Überschreibt welche Videodatei ins ZIP kommt (z.B. Original
            bei automatischer Komprimierung). Wenn None, wird video_path verwendet.
        nfo_path: Optionale NFO-Datei für Infuse/Kodi-Metadaten.

    Returns:
        Pfad zum erstellten ZIP-Archiv.
    """
    zip_name = f"{video_path.stem}.zip"
    zip_path = output_dir / zip_name
    video_source = zip_video_path if zip_video_path is not None else video_path

    # ZIP_STORED: keine Kompression, da Video bereits komprimiert ist
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_STORED) as zf:
        zf.write(video_source, video_source.name)
        zf.write(landscape_path, landscape_path.name)
        zf.write(portrait_path, portrait_path.name)
        if nfo_path and nfo_path.exists():
            zf.write(nfo_path, nfo_path.name)

    return zip_path


def copy_video(source_path: Path, output_dir: Path, target_stem: str | None = None) -> Path:
    """Kopiert die Videodatei ins Ausgabeverzeichnis.

    Args:
        target_stem: Optionaler Dateiname-Stamm (ohne Erweiterung).

    Returns:
        Pfad zur kopierten Datei.
    """
    stem = target_stem or source_path.stem
    dest = output_dir / f"{stem}{source_path.suffix}"
    if dest != source_path:
        shutil.copy2(source_path, dest)
    return dest
