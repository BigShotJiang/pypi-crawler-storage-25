"""Orchestrierung der Mediaset-Erstellung: Dateien kopieren, Thumbnails erzeugen, HTML rendern."""

import subprocess
from collections.abc import Callable
from datetime import datetime
from pathlib import Path

from ulid import ULID

from mediaset_creator.api.models import (
    CreateMediasetRequest,
    MediaItem,
    MediasetCreatorEvent,
    MediasetCreatorStage,
    MediasetResult,
    RuntimeOptions,
)
from mediaset_creator.core.asset_builder import copy_video, create_nfo, create_video_thumbnails, create_zip
from mediaset_creator.core.date_utils import format_date_german, parse_iso_date
from mediaset_creator.core.html_renderer import OgConfig, VideoRenderData, render_html
from mediaset_creator.core.video_processor import compress_video, probe_video


def _emit(
    on_event: Callable[[MediasetCreatorEvent], None] | None,
    stage_id: str,
    message: str,
    current: int | None = None,
    total: int | None = None,
) -> None:
    if on_event:
        on_event(MediasetCreatorEvent(
            stage_id=stage_id,
            message=message,
            current=current,
            total=total,
        ))


def assemble_mediaset(
    request: CreateMediasetRequest,
    runtime: RuntimeOptions | None = None,
    on_event: Callable[[MediasetCreatorEvent], None] | None = None,
) -> MediasetResult:
    """Erstellt ein komplettes Mediaset aus den angegebenen Medienelementen.

    Returns:
        MediasetResult mit Pfaden zu allen erzeugten Dateien.
    """
    runtime = runtime or RuntimeOptions()

    if not request.items:
        return MediasetResult(success=False, error_message="Keine Medienelemente angegeben.")

    # Ausgabeverzeichnis bestimmen
    base_dir = request.output_dir or request.items[0].source_path.parent
    ulid = str(ULID())
    output_dir = base_dir / ulid
    output_dir.mkdir(parents=True, exist_ok=True)

    _emit(on_event, MediasetCreatorStage.MEDIASET_GESTARTET,
          f"Mediaset wird erstellt in {output_dir}")

    total = len(request.items)
    zip_paths: list[Path] = []
    landscape_paths: list[Path] = []
    portrait_paths: list[Path] = []
    render_items: list[VideoRenderData] = []

    use_sidecar = _get_config_value("thumbnails.sidecar").lower() != "false"
    use_date_prefix = _get_config_value("filename.date_prefix").lower() != "false"
    use_auto_compress = _get_config_value("video.auto_compress").lower() != "false"
    nice_raw = _get_config_value("tools.nice_level").strip()
    nice_level = int(nice_raw) if nice_raw.lstrip("-").isdigit() else None

    for i, item in enumerate(request.items, 1):
        if item.media_type != "video":
            # Aktuell nur Video unterstützt
            continue

        # Datum: ISO für Dateiname-Prefix, Long-Format für Anzeige
        iso_date = item.recording_date or ""
        display_date = format_date_german(iso_date) if iso_date else None

        # Dateiname-Stamm mit optionalem Datum-Prefix
        base_stem = item.source_path.stem
        if use_date_prefix and parse_iso_date(iso_date):
            target_stem = f"{iso_date} {base_stem}"
        else:
            target_stem = base_stem

        # Video immer analysieren (für Dauer und ggf. Kompression)
        video_info = probe_video(item.source_path, ffprobe_path=runtime.ffprobe_path)
        duration_seconds = video_info.duration_seconds if video_info else 0.0

        # Komprimierung prüfen
        zip_source: Path | None = None
        if use_auto_compress:
            if video_info:
                if video_info.needs_compression:
                    analyse_msg = f"Komprimierung nötig: {video_info.summary()}"
                else:
                    analyse_msg = f"Keine Komprimierung: {video_info.summary()}"
            else:
                analyse_msg = "Videoanalyse nicht möglich – Original wird verwendet"
            _emit(on_event, MediasetCreatorStage.VIDEO_ANALYSIERT,
                  analyse_msg, current=i, total=total)

            if video_info and video_info.needs_compression:
                output_path = output_dir / f"{target_stem}.mp4"
                try:
                    video_dest = compress_video(
                        item.source_path, output_path,
                        ffmpeg_path=runtime.ffmpeg_path,
                        nice_level=nice_level,
                    )
                    zip_source = item.source_path
                    _emit(on_event, MediasetCreatorStage.VIDEO_KOMPRIMIERT,
                          f"Video komprimiert: {video_dest.name}", current=i, total=total)
                except subprocess.CalledProcessError:
                    video_dest = copy_video(item.source_path, output_dir, target_stem=target_stem)
                    _emit(on_event, MediasetCreatorStage.VIDEO_KOPIERT,
                          f"Komprimierung fehlgeschlagen – Original kopiert: {item.source_path.name}",
                          current=i, total=total)
            else:
                video_dest = copy_video(item.source_path, output_dir, target_stem=target_stem)
                _emit(on_event, MediasetCreatorStage.VIDEO_KOPIERT,
                      f"Video kopiert: {item.source_path.name}", current=i, total=total)
        else:
            video_dest = copy_video(item.source_path, output_dir, target_stem=target_stem)
            _emit(on_event, MediasetCreatorStage.VIDEO_KOPIERT,
                  f"Video kopiert: {item.source_path.name}", current=i, total=total)

        # Thumbnails erstellen
        landscape_path, portrait_path = create_video_thumbnails(
            item.source_path, output_dir, runtime, use_sidecar=use_sidecar,
            title=item.title, category=item.category,
            recording_date=display_date,
        )

        # Thumbnail-Dateien umbenennen mit Datum-Prefix
        if target_stem != base_stem:
            new_landscape = output_dir / f"{target_stem}-landscape{landscape_path.suffix}"
            landscape_path = landscape_path.rename(new_landscape)
            new_portrait = output_dir / f"{target_stem}-poster{portrait_path.suffix}"
            portrait_path = portrait_path.rename(new_portrait)

        landscape_paths.append(landscape_path)
        portrait_paths.append(portrait_path)
        _emit(on_event, MediasetCreatorStage.THUMBNAILS_ERSTELLT,
              f"Vorschaubilder erstellt für: {item.source_path.name}", current=i, total=total)

        # NFO-Datei für Infuse erstellen (Firecore «Other»-Format)
        nfo_path = create_nfo(
            video_stem=video_dest.stem,
            output_dir=output_dir,
            title=item.title,
            published=iso_date or None,
            category=item.category,
            description=item.description,
        )

        # ZIP erstellen (bei Kompression: Original ins ZIP, sonst komprimierte/kopierte Datei)
        zip_path = create_zip(video_dest, landscape_path, portrait_path, output_dir,
                              zip_video_path=zip_source, nfo_path=nfo_path)
        zip_paths.append(zip_path)
        _emit(on_event, MediasetCreatorStage.ZIP_ERSTELLT,
              f"ZIP erstellt: {zip_path.name}", current=i, total=total)

        # Render-Daten sammeln
        render_items.append(VideoRenderData(
            video_filename=video_dest.name,
            landscape_filename=landscape_path.name,
            portrait_filename=portrait_path.name,
            zip_filename=zip_path.name,
            title=item.title,
            description=item.description,
            category=item.category,
            recording_date=display_date,
            quality_label=item.quality_label,
            duration_seconds=duration_seconds,
            zip_size_bytes=zip_path.stat().st_size,
        ))

    # HTML rendern
    og_config = OgConfig(
        enabled=request.enable_og_tags,
        base_url=runtime.base_url,
        site_name=_get_config_value("og.site_name"),
        locale=_get_config_value("og.locale") or "de_CH",
        ulid=ulid,
    )

    created_at = datetime.now().strftime("%d.%m.%Y, %H:%M Uhr")

    html_content = render_html(
        items=render_items,
        mediaset_title=request.mediaset_title,
        og_config=og_config,
        created_at=created_at,
    )
    html_path = output_dir / "index.html"
    html_path.write_text(html_content, encoding="utf-8")
    _emit(on_event, MediasetCreatorStage.HTML_GENERIERT, "HTML-Seite generiert")

    _emit(on_event, MediasetCreatorStage.MEDIASET_ABGESCHLOSSEN,
          f"Mediaset abgeschlossen: {output_dir}")

    return MediasetResult(
        success=True,
        output_dir=output_dir,
        html_path=html_path,
        zip_paths=zip_paths,
        landscape_paths=landscape_paths,
        portrait_paths=portrait_paths,
    )


def _get_config_value(key: str) -> str:
    """Liest einen Config-Wert. Fängt ImportError ab falls Config nicht verfügbar."""
    try:
        from mediaset_creator.services import config_manager
        return config_manager.get_with_default(key)
    except Exception:
        return ""
