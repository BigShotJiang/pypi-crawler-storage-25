# contmemo

<!-- v2 | 2026-05-03 | scope: memory only; recipes live in sibling contrecipe -->

> Memory custodian agent for the **Cont Hive** ecosystem.
> Offline, air-gapped, single-writer, deterministic-first.

`contmemo` is the kâtip ("scribe") of the Cont Hive. It is the **only** module
that writes to Cont's memory. Every other agent — including `cont` itself —
submits **proposals**; `contmemo` evaluates them and decides what gets persisted.

**Scope is memory only.** Recipe sanity, lifecycle, and evolution are the
responsibility of the sibling agent `contrecipe`. The two are peers, not nested.

See [`docs/architecture.md`](docs/architecture.md) for the full design.

## Status

**Sprint M1 — Skeleton.** Repo structure, CLI parser, test harness.
No runtime behavior yet. Each `core/*.py` module exposes a stub class so
later sprints can fill in their own corner without touching the wiring.

| Sprint | Scope                                    | Status |
| ------ | ---------------------------------------- | ------ |
| M1     | Skeleton                                 | done   |
| M2     | Event log (append-only JSONL + lookup)   | done   |
| M3     | Proposal inbox watcher + deterministic   | done   |
| M4     | Single-writer Cont memory writer         | done   |
| M5     | Light-mode runtime (trace watching)      | done   |
| M6     | Bulk mode + mini-LLM client              | done   |
| M7     | PyPI publish (offline-friendly artifact) | next   |
| M8     | Cont integration (shim layer in `cont`)  | —      |

## Install (dev)

```bash
git clone <repo>
cd contmemo
pip install -e ".[dev]"
pytest
```

## Usage

```bash
contmemo --watch              # light-mode daemon (live in M5+)
contmemo --report --last 50   # event-log tail as JSONL on stdout (M5+)
contmemo --bulk --since "1 hour ago"  # LLM-driven reflection (M6+)
contmemo --bulk --dry-run             # call the LLM, don't write
```

`--watch` accepts `--max-iterations N` for smoke runs and CI; without it
the loop runs as a daemon until SIGTERM / SIGINT / `request_shutdown`.
See [`docs/operations.md`](docs/operations.md) for the operator playbook.

## Design invariants

These never bend, regardless of sprint:

1. **Single-writer.** Cont memory is written by `contmemo` and nothing else.
2. **Proposal-only.** Cont thinks it writes; it actually submits.
3. **Deterministic before LLM.** Light path has no model. LLM only in bulk.
4. **Append-only event log.** Contmemo's own memory has no LLM in the loop —
   no recursion, no self-summarization.
5. **Air-gapped.** Zero cloud, zero outbound network, zero telemetry.

## License

Private — internal Cont Hive component. Not for redistribution.
