# Changelog

All notable changes to `contmemo`. Format follows
[Keep a Changelog](https://keepachangelog.com/) loosely.
Versioning per sprint: `0.M.x` while pre-1.0.

## [0.5.0] — 2026-05-02 — Sprint M6: Bulk mode + Ollama LLM client

First LLM in the loop. The light path stays LLM-free per design;
everything model-related lives in `--bulk`.

### Added
- `core/ollama_client.py` — stdlib-only `urllib` HTTP client.
  `available()` / `complete()` matching the M1 `LLMClient` Protocol.
  Endpoint locked to loopback at construction (banking defense). Raises
  `LLMError` on transport / HTTP / decoding failure.
- `core/bulk_processor.py` — drains `processed/deferred/`, re-classifies
  each proposal through M3 once more (paranoia), prompts the LLM, parses
  a strict-but-fence-tolerant JSON, hands the resulting Decision to the
  M4 writer, and archives. `summarize_patterns()` walks
  `pattern_detected` events, honors a per-signal cooldown (default 1 d),
  emits one `pattern_summarized` per hit. Prompt hash (sha256[:16]) is
  audited; the full prompt is intentionally not stored.
- `Runtime.run_bulk(*, since, max_items, dry_run) → dict`. Lazy-imports
  `OllamaClient` + `BulkProcessor` so the light path never pays for
  them. An empty `[llm].model` in config ⇒ graceful skip + a
  `bulk_skipped` event with `reason="llm_unavailable"`.
- CLI: `--bulk` is live; new `--max-items N` (per-run cap) and
  `--dry-run` (call the LLM but don't write or move files); summary is
  printed as JSON on stdout.
- `prompts/failure_analysis.txt` and `prompts/memory_evaluation.txt`
  now hold the real Turkish prompts; both pin a strict JSON output
  shape.
- `config/default.toml` v4: `[llm]` section (model defaults to `""` by
  design — Borg-style "operator must set"), `[bulk]` section.
- `docs/llm_setup.md` for the operator picking a mini-model.
- 39 new tests: `test_ollama_client.py` (13, urllib mocked, loopback
  paranoia), `test_bulk_processor.py` (17, scripted FakeLLM),
  `test_runtime_bulk.py` (6 incl. light-mode-doesn't-import-ollama
  invariant), `test_cli_bulk.py` (3). 160 tests total green.

### Changed
- `ProposalInbox._classify` → `classify` (public) so the bulk re-check
  can run without side effects.
- `tests/test_smoke.py`: removed the legacy `test_main_bulk_still_exits_two`;
  the per-mode tests live in `test_cli_*` now.

### Notes
- Light-mode hot path verified test-time: `contmemo.core.ollama_client`
  is not imported during `run_light`. The M6 invariant has a regression
  fence.
- LLM responses are validated against tiny "required keys + types"
  schemas. Output that doesn't fit collapses to `kind="reject"` with
  `reason="llm_output_invalid"` — no half-trusted writes.

## [0.4.0] — 2026-05-02 — Sprint M5: Light runtime & pattern detector

### Added
- `core/runtime.py` — `Runtime.run_light(*, max_iterations=None)` that
  ties M3 ProposalInbox, M4 MemoryWriter, the new PatternDetector, and
  the M2 EventLog into one polling loop. Optional injection of any
  component for testability.
- `core/pattern_detect.py` — `PatternDetector` with bounded deque +
  Counter. Friction-only signal extraction:
  `proposal_processed{kind ∈ reject, defer}` and `memory_write_attempt`.
  Configurable `window`, `threshold`, and `pattern_emit_cooldown_s`.
- CLI: `--watch` runs `Runtime.run_light`; `--report` dumps the event
  log tail as JSONL on stdout. New flags `--max-iterations` (smoke)
  and `--inbox-dir` (override). `--bulk` still exits 2 (M6).
- `Runtime.request_shutdown()` for clean termination from a test thread
  or any non-main caller; SIGTERM / SIGINT handlers also install
  best-effort.
- `config/default.toml` (v3): `paths.memory_path`, `paths.memory_backup_dir`,
  and the new `[detector]` section.
- `docs/operations.md` — short operator how-to for the daemon.
- `tests/test_pattern_detect.py` (10), `tests/test_runtime.py` (10),
  `tests/test_cli_integration.py` (3).

### Changed
- `requires-python = ">=3.11"` (stdlib `tomllib` for config loading;
  no third-party deps).
- `ProposalInbox._read` → `read` (public) so the runtime loop can share
  the parser without going through `watch()`. Internal call site
  updated; M3 contract / unit tests unaffected.
- `tests/test_smoke.py` updated: only `--bulk` still expects exit 2 in
  M5+; the prior all-modes sweep would have blocked on `--watch`.

### Notes
- Light-mode latency is not asserted in tests (would be flaky); the hot
  path stays I/O-bound (glob + read + classify + write + log) per brief
  invariant. No LLM in M5.
- Pattern state is in-memory; restart resets the window. Persistence
  comes via M6 bulk replay over the event log.
- Detector refresh is naïve full-rescan of `event_log.query(last=window)`
  per iteration. Profiling-driven optimization deferred.

## [0.3.0] — 2026-05-02 — Sprint M4: Memory writer

### Added
- `core/memory_writer.py` — the only module that mutates Cont's memory
  on disk. Single-writer flock + tmp/rename + parent-dir fsync; one-
  rotation backup with file + dir fsync.
- `WriteResult` dataclass (frozen): `kind`, `reason`, `target_path`,
  `backup_path`, `bytes_written`, `decision_proposal_id`. `kind` ∈
  {`written`, `skipped`, `failed`, `rolled_back`, `no_backup`}.
- Memory format v1: `~/.cont/memory.jsonl`, one JSON entry per line
  with `id = mem_<sha256(content)[:16]>` for content-addressable dedup.
- Append handler for `lesson` / `fact` / `word`; `forget` handler scoped
  to `target == "memory_id"` (other targets are an explicit M4 defense
  failure even though M3 rejects them upstream).
- `rollback()` restores the single-rotation backup; no backup ⇒
  `kind=no_backup`, never raises.
- Event log integration: every `write` and `rollback` (success, skip,
  failure, no-op) emits one entry — the audit trail is complete.
- `tests/test_memory_writer.py` — 26 cases: append + forget pipelines,
  duplicate-id and not-an-accept skips, atomicity (tmp+rename spy,
  simulated mid-swap crash leaves target unchanged), 5×10 concurrent
  writers, backup creation + rollback (incl. idempotency), event-log
  payloads, lock-file release, parent-dir fsync.

### Notes
- `_fsync_dir` uses `O_DIRECTORY` (Linux). Cont production is Linux;
  no portability fallback by design.
- Constructor extended with keyword-only `backup_dir` / `event_log` /
  `config`; the M1 stub's positional `target_path` continues to work.
- `--watch` and `--report` CLI flags still exit 2 — runtime hookup is M5.

## [0.2.0] — 2026-05-02 — Sprint M3: Proposal inbox

### Added
- `core/proposal_inbox.py` — deterministic accept/reject/defer pipeline
  for memory proposals dropped into a filesystem inbox. No LLM in M3;
  anything that needs a model lands in `processed/deferred/` for M6.
- `Decision` dataclass (frozen) carrying `proposal_id`, `kind`, `reason`,
  `proposal`, `source_path`, `final_path`, `content_hash`. `to_dict()`
  yields a JSON-serializable view.
- Subtype rules:
  - **word** — `\b`-anchored Unicode word match against `user_message`
    (case-insensitive). "kalem" does not match "kalemler".
  - **forget** — Turkish positive imperatives (unut/kaldır/sil/çıkar/
    hatırlama) accept; negatives (unutma/...) gate, ambiguous → defer.
  - **lesson / fact** — too-short / too-long / generic-platitude reject;
    repeated `content_hash` (≥5 in event log) rejected as priming;
    otherwise defer.
- Regression fences: `subtype` starting with `recipe` → reject
  `out_of_scope_recipe`; `type` other than `memory_write` → reject
  `out_of_scope_type`; unknown subtype → `out_of_scope_subtype`.
- Atomic `os.rename` to `processed/{accepted,rejected,deferred,quarantine}/`
  with `_collision_<n>` retries up to 3, then fall back to quarantine.
  Never silently overwrites.
- Idempotency: `process()` consults the M2 event log for any prior
  `proposal_id` and short-circuits as `duplicate`.
- `watch()` polling generator (default 1 s), FIFO via sorted glob,
  KeyboardInterrupt exits cleanly.
- 31 unit tests + 12 human-labelled golden fixtures (`tests/golden/*.json`)
  covering the full decision matrix. 73 tests total, all green.

### Notes
- Constructor signature extended with keyword-only `event_log` and
  `config`; the M1 contract test continues to pass.
- `--watch` CLI flag still exits 2 — the runtime hookup (M5) is what
  finally exercises the loop end-to-end.
- Memory write itself is still M4. M3 only decides; M4 will persist.

## [0.1.0] — 2026-05-02 — Sprint M2: Event log

### Added
- `core/event_log.py` — append-only JSONL with the following invariants:
  flock-guarded `append` + `fsync`, UTC ISO 8601 `ts` auto-stamp when
  missing (preserved when present), 4 KiB per-line ceiling raising
  `ValueError("event_too_large", n)`, parent dir auto-creation.
- `EventLog.query()` lazy generator with filter chain
  `event_type → since → until → last` (`last=N` via `deque(maxlen=N)`).
  Missing file returns an empty iterator. Torn / corrupt JSON lines are
  skipped with a stderr warning rather than aborting the stream.
- Module-level `_now_iso()` / `_parse_ts()` helpers so future bulk-mode
  replay (M6) can monkeypatch the clock and tolerate trailing-`Z` ISO.
- `tests/test_event_log.py` — 15 cases covering basic append, ts
  semantics, filter combinations, lazy iteration, corrupt-line skip, and
  a 5×20 concurrent-writer no-interleaving test.

### Notes
- `--report` CLI hookup is intentionally deferred (M2.5 / kapsam dışı).
  The flag still exits 2 with its sprint pointer.

## [0.0.2] — 2026-05-03 — Brief v2: scope narrowed to memory only

### Build
- Removed `Private :: Do Not Upload` classifier from `pyproject.toml` to
  enable PyPI publish of the existing 0.0.2 artifact. No code or contract
  change; same memory-only scope.


Brief v2 update note clarifies that recipe-related work (sanity checks,
lifecycle, semantic review) belongs to a sibling agent `contrecipe`, not
to `contmemo`. This release applies that scope cut to the M1 skeleton.

### Removed
- `contmemo/prompts/recipe_sanity.txt` placeholder. Recipe prompts now
  live in `contrecipe`.
- `recipe_state` from `[evaluation].fast_track_types` in
  `config/default.toml`. Per brief v2, recipe execution state is held in
  a separate transient store on the Cont side and never reaches the
  contmemo proposal inbox.

### Changed
- `contmemo/__init__.py` docstring: explicit "memory only" scope, sibling
  agent named.
- `pyproject.toml` description: same scope clarification.
- `core/proposal_inbox.py` docstring: documents the four valid memory
  subtypes (`lesson`, `fact`, `word`, `forget`) and the contract that a
  misrouted recipe-shaped payload must be rejected with reason
  `out_of_scope_recipe` (work to be done in M3).
- `docs/architecture.md`: new top-level "Scope" section, expanded
  "What is not in scope" listing recipe work as permanently siblinged.
- `README.md`: scope statement near the top.
- `tests/test_skeleton.py`: prompts presence test no longer expects
  `recipe_sanity.txt` and now asserts it must **not** be there
  (regression fence against scope creep).

### Notes
- No code path was implemented yet, so this is a paper change — but the
  contracts and prompt manifest are now correct and won't have to be
  unwound in M3 or M6.

## [0.0.1] — 2026-05-02 — Sprint M1: Skeleton

### Added
- Repo + package layout matching `contbrief`/`contdlp` convention.
- `pyproject.toml` (PEP 621, setuptools backend, zero runtime deps).
- `contmemo.__main__` CLI with mutually exclusive `--watch` / `--bulk` /
  `--report` modes; each mode currently exits 2 pointing at its target sprint.
- Stub modules under `contmemo/core/` for runtime, proposal inbox, event
  log, pattern detector, LLM client, memory writer. Each exposes the named
  class with `NotImplementedError("Sprint Mx")` bodies so later sprints have
  a clear contract.
- `prompts/*.txt` placeholders (failure_analysis, recipe_sanity,
  memory_evaluation).
- `config/default.toml` with paths, runtime tunables, hook flag (off),
  LLM provider stub.
- pytest test harness: smoke tests (import, `--help`, `--version`) +
  structural tests (every planned module exposes its class).
- `tests/golden/` placeholder directory for the deterministic gold set
  (filled in M3).
- `docs/architecture.md` developer cheat sheet (full design lives in the
  brief; this is the working summary).

### Notes
- No runtime dependencies on purpose. Air-gap-friendly.
- Hook subsystem is **not** scaffolded yet — config flag exists, code lands
  with the IPC sprint (post-MVP).
