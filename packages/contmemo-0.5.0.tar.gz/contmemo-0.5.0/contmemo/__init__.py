# v7 | 2026-05-02 | bump 0.5.0 (M6 bulk mode + Ollama LLM client)
"""contmemo — memory custodian for the Cont Hive ecosystem.

Single-writer, deterministic-first, air-gapped. Cont submits proposals;
contmemo evaluates and decides. **Memory only** — recipe-related work
lives in the sibling agent ``contrecipe``. See ``docs/architecture.md``.
"""

__version__ = "0.5.0"

__all__ = ["__version__"]
