# v2 | 2026-05-02 | M4 single-writer impl
"""MemoryWriter — the **only** module that writes to Cont's memory.

Single-writer is the core invariant. Every memory mutation in the Cont
Hive flows through one instance of this class. That is what gives
contmemo its "tek hâkim" status: filtering happens upstream (M3), the
actual disk mutation happens here, atomically.

Pipeline duties (Sprint M4):
  - exclusive flock on a sidecar ``.lock`` file
  - atomic mutation via tmp-file + ``os.rename`` + parent-dir fsync
  - one-rotation backup so a bad write can be reverted without consulting
    the event log's source of truth
  - JSONL memory format: one entry per line, ``id = mem_<sha256[:16]>``
    derived from the content payload (deterministic dedup)

Memory format (M4):

    ~/.cont/memory.jsonl
    {"id":"mem_...","subtype":"lesson","content":{...},"added_ts":"...",
     "source_proposal_id":"...","session_id":"..."}

``forget`` semantics in M4: ``content == {"target": "memory_id",
"value": "mem_..."}``. Pattern / fuzzy targets are a future-sprint
concern (require LLM resolution).

Pattern reference: CQRS write-side; SQLite WAL single-writer; dpkg
tmp-rename atomicity; git's content-addressable object store.
"""

from __future__ import annotations

import fcntl
import hashlib
import json
import os
import shutil
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator, Literal

from contmemo.core.event_log import EventLog
from contmemo.core.proposal_inbox import Decision

ResultKind = Literal["written", "skipped", "failed", "rolled_back", "no_backup"]


@dataclass(frozen=True)
class WriteResult:
    kind: ResultKind
    reason: str
    target_path: Path
    backup_path: Path | None
    bytes_written: int
    decision_proposal_id: str | None


_DEFAULT_CONFIG: dict = {}


def _now_iso() -> str:
    """UTC ISO 8601 timestamp. Module-level so tests can monkeypatch."""
    return datetime.now(timezone.utc).isoformat()


def _canonical_hash(content: dict) -> str:
    canonical = json.dumps(content, sort_keys=True, ensure_ascii=False)
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def _fsync_dir(path: Path) -> None:
    """Ensure a directory entry change is durable.

    Linux-only: O_DIRECTORY is a Linux extension. Cont production is Linux,
    so no portability fallback. macOS would need a different shape.
    """
    fd = os.open(str(path), os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def _normalize_decision(decision: Decision | dict[str, Any]) -> dict:
    """Accept either a Decision dataclass or a plain dict."""
    if hasattr(decision, "to_dict"):
        return decision.to_dict()
    return dict(decision)


class MemoryWriter:
    """Single point of write for Cont's persisted memory."""

    def __init__(
        self,
        target_path: Path,
        *,
        backup_dir: Path | None = None,
        event_log: EventLog | None = None,
        config: dict | None = None,
    ) -> None:
        self.target_path = Path(target_path)
        self.backup_dir = Path(backup_dir) if backup_dir else self.target_path.parent / ".backups"
        self.event_log = event_log
        self.config = {**_DEFAULT_CONFIG, **(config or {})}
        self.lock_path = self.target_path.with_suffix(".lock")

    # ---- public API ----

    def write(self, decision: Decision | dict[str, Any]) -> WriteResult:
        """Apply an accepted Decision. Idempotent on (id, content) collisions."""
        d = _normalize_decision(decision)
        proposal_id = d.get("proposal_id")

        if d.get("kind") != "accept":
            result = WriteResult(
                kind="skipped", reason="not_an_accept",
                target_path=self.target_path, backup_path=None,
                bytes_written=0, decision_proposal_id=proposal_id,
            )
            self._log_write(result, subtype=None, memory_id=None)
            return result

        proposal = d.get("proposal")
        if not isinstance(proposal, dict):
            result = WriteResult(
                kind="failed", reason="empty_proposal",
                target_path=self.target_path, backup_path=None,
                bytes_written=0, decision_proposal_id=proposal_id,
            )
            self._log_write(result, subtype=None, memory_id=None)
            return result

        subtype = proposal.get("subtype")
        content = proposal.get("content")
        if not isinstance(content, dict):
            result = WriteResult(
                kind="failed", reason="empty_proposal",
                target_path=self.target_path, backup_path=None,
                bytes_written=0, decision_proposal_id=proposal_id,
            )
            self._log_write(result, subtype=subtype, memory_id=None)
            return result

        with self._exclusive_lock():
            backup_path = self._backup()
            try:
                if subtype == "forget":
                    result, memory_id, removed_ids = self._do_forget(
                        proposal, proposal_id, backup_path
                    )
                elif subtype in ("lesson", "fact", "word"):
                    result, memory_id = self._do_append(
                        proposal, proposal_id, subtype, backup_path
                    )
                    removed_ids = None
                else:
                    result = WriteResult(
                        kind="failed", reason="subtype_unsupported",
                        target_path=self.target_path, backup_path=backup_path,
                        bytes_written=0, decision_proposal_id=proposal_id,
                    )
                    memory_id = None
                    removed_ids = None
            except OSError as exc:
                result = WriteResult(
                    kind="failed",
                    reason=f"atomic_swap_failed:{type(exc).__name__}",
                    target_path=self.target_path, backup_path=backup_path,
                    bytes_written=0, decision_proposal_id=proposal_id,
                )
                memory_id = None
                removed_ids = None

        self._log_write(result, subtype=subtype, memory_id=memory_id, removed_ids=removed_ids)
        return result

    def rollback(self) -> WriteResult:
        """Restore the previous version from the single-rotation backup."""
        backup_path = self.backup_dir / self.target_path.name
        if not backup_path.exists():
            result = WriteResult(
                kind="no_backup", reason="nothing_to_restore",
                target_path=self.target_path, backup_path=None,
                bytes_written=0, decision_proposal_id=None,
            )
            self._log_rollback(result)
            return result

        with self._exclusive_lock():
            try:
                tmp = self.target_path.with_suffix(self.target_path.suffix + ".tmp")
                shutil.copy2(backup_path, tmp)
                # durable: fsync the tmp before swap
                fd = os.open(str(tmp), os.O_RDONLY)
                try:
                    os.fsync(fd)
                finally:
                    os.close(fd)
                os.rename(tmp, self.target_path)
                _fsync_dir(self.target_path.parent)
                size = self.target_path.stat().st_size
            except OSError as exc:
                result = WriteResult(
                    kind="failed",
                    reason=f"rollback_failed:{type(exc).__name__}",
                    target_path=self.target_path, backup_path=backup_path,
                    bytes_written=0, decision_proposal_id=None,
                )
                self._log_rollback(result)
                return result

        result = WriteResult(
            kind="rolled_back", reason="restored_from_backup",
            target_path=self.target_path, backup_path=backup_path,
            bytes_written=size, decision_proposal_id=None,
        )
        self._log_rollback(result)
        return result

    # ---- internals ----

    @contextmanager
    def _exclusive_lock(self) -> Iterator[None]:
        self.lock_path.parent.mkdir(parents=True, exist_ok=True)
        lock_fd = os.open(str(self.lock_path), os.O_RDWR | os.O_CREAT, 0o644)
        try:
            fcntl.flock(lock_fd, fcntl.LOCK_EX)
            yield
        finally:
            fcntl.flock(lock_fd, fcntl.LOCK_UN)
            os.close(lock_fd)

    def _backup(self) -> Path | None:
        if not self.target_path.exists():
            return None
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        backup_path = self.backup_dir / self.target_path.name
        shutil.copy2(self.target_path, backup_path)
        fd = os.open(str(backup_path), os.O_RDONLY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)
        _fsync_dir(self.backup_dir)
        return backup_path

    def _read_entries(self) -> list[dict]:
        if not self.target_path.exists():
            return []
        out: list[dict] = []
        with open(self.target_path, "rb") as f:
            for raw in f:
                text = raw.decode("utf-8", errors="replace").rstrip("\n")
                if not text:
                    continue
                try:
                    obj = json.loads(text)
                except json.JSONDecodeError:
                    continue
                if isinstance(obj, dict):
                    out.append(obj)
        return out

    def _atomic_write(self, entries: list[dict]) -> int:
        self.target_path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.target_path.with_suffix(self.target_path.suffix + ".tmp")
        text = "".join(
            json.dumps(e, ensure_ascii=False, separators=(",", ":")) + "\n"
            for e in entries
        )
        data = text.encode("utf-8")
        with open(tmp, "wb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        os.rename(tmp, self.target_path)
        _fsync_dir(self.target_path.parent)
        return len(data)

    def _do_append(
        self, proposal: dict, proposal_id: str | None, subtype: str, backup_path: Path | None
    ) -> tuple[WriteResult, str]:
        content = proposal["content"]
        memory_id = f"mem_{_canonical_hash(content)[:16]}"

        entries = self._read_entries()
        if any(e.get("id") == memory_id for e in entries):
            return (
                WriteResult(
                    kind="skipped", reason="duplicate_memory_id",
                    target_path=self.target_path, backup_path=backup_path,
                    bytes_written=0, decision_proposal_id=proposal_id,
                ),
                memory_id,
            )

        entry = {
            "id":                 memory_id,
            "subtype":            subtype,
            "content":            content,
            "added_ts":           _now_iso(),
            "source_proposal_id": proposal_id,
            "session_id":         proposal.get("session_id"),
        }
        entries.append(entry)
        bytes_written = self._atomic_write(entries)

        return (
            WriteResult(
                kind="written", reason="appended",
                target_path=self.target_path, backup_path=backup_path,
                bytes_written=bytes_written, decision_proposal_id=proposal_id,
            ),
            memory_id,
        )

    def _do_forget(
        self, proposal: dict, proposal_id: str | None, backup_path: Path | None
    ) -> tuple[WriteResult, str | None, list[str] | None]:
        content = proposal["content"]
        target = content.get("target")
        value = content.get("value")

        if target != "memory_id":
            return (
                WriteResult(
                    kind="failed", reason="forget_target_unsupported",
                    target_path=self.target_path, backup_path=backup_path,
                    bytes_written=0, decision_proposal_id=proposal_id,
                ),
                None, None,
            )
        if not isinstance(value, str) or not value:
            return (
                WriteResult(
                    kind="failed", reason="forget_value_missing",
                    target_path=self.target_path, backup_path=backup_path,
                    bytes_written=0, decision_proposal_id=proposal_id,
                ),
                None, None,
            )

        entries = self._read_entries()
        removed_ids = [e.get("id") for e in entries if e.get("id") == value]
        if not removed_ids:
            return (
                WriteResult(
                    kind="skipped", reason="forget_target_not_found",
                    target_path=self.target_path, backup_path=backup_path,
                    bytes_written=0, decision_proposal_id=proposal_id,
                ),
                value, None,
            )

        remaining = [e for e in entries if e.get("id") != value]
        bytes_written = self._atomic_write(remaining)

        return (
            WriteResult(
                kind="written", reason="forgot",
                target_path=self.target_path, backup_path=backup_path,
                bytes_written=bytes_written, decision_proposal_id=proposal_id,
            ),
            value,
            removed_ids,
        )

    def _log_write(
        self, result: WriteResult, subtype: str | None, memory_id: str | None,
        removed_ids: list[str] | None = None,
    ) -> None:
        if self.event_log is None:
            return
        payload = {
            "event":         "memory_written" if result.kind == "written" else "memory_write_attempt",
            "kind":          result.kind,
            "reason":        result.reason,
            "subtype":       subtype,
            "memory_id":     memory_id,
            "proposal_id":   result.decision_proposal_id,
            "bytes_written": result.bytes_written,
            "backup_path":   str(result.backup_path) if result.backup_path else None,
        }
        if removed_ids is not None:
            payload["removed_ids"] = removed_ids
        self.event_log.append(payload)

    def _log_rollback(self, result: WriteResult) -> None:
        if self.event_log is None:
            return
        self.event_log.append({
            "event":        "memory_rolled_back",
            "kind":         result.kind,
            "reason":       result.reason,
            "from_backup":  str(result.backup_path) if result.backup_path else None,
            "bytes":        result.bytes_written,
        })
