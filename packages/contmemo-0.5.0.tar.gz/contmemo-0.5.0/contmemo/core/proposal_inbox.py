# v5 | 2026-05-02 | M6: expose classify() for bulk-mode re-check
"""ProposalInbox — watches the filesystem inbox and yields decisions.

Layout (qmail/maildir-flavored):
  ${inbox_dir}/<ts>_<subtype>_<short_id>.json    incoming
  ${processed_dir}/accepted/                     archived after decision
  ${processed_dir}/rejected/
  ${processed_dir}/deferred/                     M6 bulk mode picks these
  ${processed_dir}/quarantine/                   parse / schema failures

Default transport is filesystem polling (1 s). The hook-based path
(Unix socket + JSON-RPC 2.0) is built but disabled at the config level
and is not part of M3.

**Subtype contract (brief v2).** This inbox is for *memory* proposals
only. The accepted subtypes are::

    lesson  fact  word  forget

Anything recipe-shaped (``recipe_proposal``, ``recipe_update``,
``recipe_state``, ...) does **not** belong here — it is routed to the
sibling agent ``contrecipe`` by the Cont-side shim before it ever
reaches the filesystem. If such a payload nonetheless lands in this
inbox, M3 rejects it with reason ``out_of_scope_recipe`` and moves it
untouched to ``processed/rejected/`` so the misroute is auditable.

Pipeline is fully deterministic. Anything that needs a model lands in
``deferred/`` and waits for M6 bulk mode.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import time
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Iterator, Literal

from contmemo.core.event_log import EventLog, _parse_ts

DecisionKind = Literal["accept", "reject", "defer", "duplicate", "malformed"]

_VALID_SUBTYPES: frozenset[str] = frozenset({"lesson", "fact", "word", "forget"})
_RECIPE_SUBTYPE_PREFIX = "recipe"

_REQUIRED_FIELDS: tuple[str, ...] = (
    "proposal_id", "from", "session_id", "turn_id",
    "type", "subtype", "content", "user_message", "ts",
)

# Small starting list. Substring match, case-insensitive. Easy to extend.
_GENERIC_PLATITUDES: tuple[str, ...] = (
    "always sanitize",
    "be careful",
    "double check",
    "validate inputs",
)

# Turkish forget keywords. Word-boundary, lower-cased.
_FORGET_POSITIVE: tuple[str, ...] = ("unut", "kaldır", "sil", "çıkar", "hatırlama")
_FORGET_NEGATIVE: tuple[str, ...] = ("unutma", "kaldırma", "silme", "çıkarma")

_KIND_TO_DIR: dict[str, str] = {
    "accept":    "accepted",
    "reject":    "rejected",
    "defer":     "deferred",
    "duplicate": "rejected",   # share rejected/; audit trail is in event log
    "malformed": "quarantine",
}

_DEFAULT_CONFIG: dict = {
    "min_lesson_chars": 8,
    "max_lesson_chars": 2000,
    "lesson_priming_repeat_threshold": 5,
    "forget_positive": list(_FORGET_POSITIVE),
    "forget_negative": list(_FORGET_NEGATIVE),
    "generic_platitudes": list(_GENERIC_PLATITUDES),
}


@dataclass(frozen=True)
class Decision:
    """Outcome of evaluating a single proposal. Frozen for safety in tests."""
    proposal_id: str | None
    kind: DecisionKind
    reason: str
    proposal: dict | None
    source_path: Path
    final_path: Path | None
    content_hash: str | None

    def to_dict(self) -> dict:
        """asdict-equivalent with Path → str so it is JSON-serializable."""
        return {
            "proposal_id":  self.proposal_id,
            "kind":         self.kind,
            "reason":       self.reason,
            "proposal":     self.proposal,
            "source_path":  str(self.source_path),
            "final_path":   str(self.final_path) if self.final_path else None,
            "content_hash": self.content_hash,
        }


def _hash_content(content: object) -> str | None:
    if content is None:
        return None
    try:
        canonical = json.dumps(content, sort_keys=True, ensure_ascii=False)
    except (TypeError, ValueError):
        return None
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def _has_word(text: str, word: str) -> bool:
    """Unicode-aware word-boundary match, case-insensitive."""
    if not text or not word:
        return False
    pattern = r"\b" + re.escape(word.lower()) + r"\b"
    return bool(re.search(pattern, text.lower(), flags=re.UNICODE))


class ProposalInbox:
    """Filesystem-based proposal queue with deterministic accept/reject."""

    def __init__(
        self,
        inbox_dir: Path,
        processed_dir: Path,
        *,
        event_log: EventLog | None = None,
        config: dict | None = None,
    ) -> None:
        self.inbox_dir = Path(inbox_dir)
        self.processed_dir = Path(processed_dir)
        self.event_log = event_log
        self.config = {**_DEFAULT_CONFIG, **(config or {})}

        self.inbox_dir.mkdir(parents=True, exist_ok=True)
        for sub in ("accepted", "rejected", "deferred", "quarantine"):
            (self.processed_dir / sub).mkdir(parents=True, exist_ok=True)

    # ---- public API ----

    def process(self, proposal: dict | None, source_path: Path) -> Decision:
        """Classify, archive, log. End-to-end side-effecting pipeline."""
        decision = self.classify(proposal, Path(source_path))
        final_path = self._archive(decision)
        decision = replace(decision, final_path=final_path)
        self._log(decision)
        return decision

    def classify(self, proposal: dict | None, source_path: Path) -> Decision:
        """Pure deterministic re-check, no archive, no event log. M6 bulk
        mode reuses this to confirm a deferred proposal still parses + still
        defers under the current rule set before paying for an LLM call."""
        return self._classify(proposal, Path(source_path))

    def watch(self, poll_interval_s: float = 1.0) -> Iterator[Decision]:
        """Poll the inbox forever, yielding a Decision per proposal seen.

        Stops cleanly on KeyboardInterrupt. The M5 runtime drives the loop
        via ``read`` + ``process`` directly so it can interleave detector
        updates and signal handling.
        """
        try:
            while True:
                paths = sorted(self.inbox_dir.glob("*.json"))
                if not paths:
                    time.sleep(poll_interval_s)
                    continue
                for path in paths:
                    proposal = self.read(path)
                    yield self.process(proposal, path)
        except KeyboardInterrupt:
            return

    # ---- classification (pure-ish; no file move, no log) ----

    def _classify(self, proposal: dict | None, source_path: Path) -> Decision:
        if not isinstance(proposal, dict):
            return Decision(
                proposal_id=None, kind="malformed", reason="json_decode_error",
                proposal=None, source_path=source_path, final_path=None,
                content_hash=None,
            )

        missing = [f for f in _REQUIRED_FIELDS if f not in proposal]
        if missing:
            return Decision(
                proposal_id=_safe_str(proposal.get("proposal_id")),
                kind="malformed", reason="schema_violation",
                proposal=proposal, source_path=source_path, final_path=None,
                content_hash=_hash_content(proposal.get("content")),
            )

        proposal_id = proposal["proposal_id"]
        if not isinstance(proposal_id, str) or not proposal_id:
            return Decision(
                proposal_id=None, kind="malformed", reason="schema_violation",
                proposal=proposal, source_path=source_path, final_path=None,
                content_hash=_hash_content(proposal.get("content")),
            )

        content_hash = _hash_content(proposal["content"])

        if self._is_duplicate(proposal_id):
            return Decision(
                proposal_id=proposal_id, kind="duplicate", reason="proposal_id_seen",
                proposal=proposal, source_path=source_path, final_path=None,
                content_hash=content_hash,
            )

        if proposal["type"] != "memory_write":
            return Decision(
                proposal_id=proposal_id, kind="reject", reason="out_of_scope_type",
                proposal=proposal, source_path=source_path, final_path=None,
                content_hash=content_hash,
            )

        subtype = proposal["subtype"]
        if isinstance(subtype, str) and subtype.startswith(_RECIPE_SUBTYPE_PREFIX):
            return Decision(
                proposal_id=proposal_id, kind="reject", reason="out_of_scope_recipe",
                proposal=proposal, source_path=source_path, final_path=None,
                content_hash=content_hash,
            )
        if subtype not in _VALID_SUBTYPES:
            return Decision(
                proposal_id=proposal_id, kind="reject", reason="out_of_scope_subtype",
                proposal=proposal, source_path=source_path, final_path=None,
                content_hash=content_hash,
            )

        if _parse_ts(proposal["ts"]) is None:
            return Decision(
                proposal_id=proposal_id, kind="malformed", reason="schema_violation",
                proposal=proposal, source_path=source_path, final_path=None,
                content_hash=content_hash,
            )

        if not isinstance(proposal["content"], dict):
            return Decision(
                proposal_id=proposal_id, kind="malformed", reason="schema_violation",
                proposal=proposal, source_path=source_path, final_path=None,
                content_hash=content_hash,
            )

        if subtype == "word":
            return self._classify_word(proposal, source_path, content_hash)
        if subtype == "forget":
            return self._classify_forget(proposal, source_path, content_hash)
        if subtype == "lesson":
            return self._classify_text("lesson", proposal, source_path, content_hash)
        if subtype == "fact":
            return self._classify_text("fact", proposal, source_path, content_hash)
        # unreachable — guarded above
        raise AssertionError(f"unhandled subtype {subtype!r}")

    # ---- subtype classifiers ----

    def _classify_word(self, proposal: dict, source_path: Path, content_hash: str | None) -> Decision:
        word = proposal["content"].get("word")
        if not isinstance(word, str) or not word.strip():
            return Decision(
                proposal_id=proposal["proposal_id"], kind="reject",
                reason="word_missing_in_content",
                proposal=proposal, source_path=source_path, final_path=None,
                content_hash=content_hash,
            )
        if _has_word(proposal["user_message"], word):
            return Decision(
                proposal_id=proposal["proposal_id"], kind="accept",
                reason="word_attested_in_user_msg",
                proposal=proposal, source_path=source_path, final_path=None,
                content_hash=content_hash,
            )
        return Decision(
            proposal_id=proposal["proposal_id"], kind="reject",
            reason="word_not_in_user_msg",
            proposal=proposal, source_path=source_path, final_path=None,
            content_hash=content_hash,
        )

    def _classify_forget(self, proposal: dict, source_path: Path, content_hash: str | None) -> Decision:
        msg = proposal["user_message"]
        positives = self.config["forget_positive"]
        negatives = self.config["forget_negative"]
        has_pos = any(_has_word(msg, w) for w in positives)
        has_neg = any(_has_word(msg, w) for w in negatives)
        if has_pos and not has_neg:
            return Decision(
                proposal_id=proposal["proposal_id"], kind="accept",
                reason="forget_imperative_attested",
                proposal=proposal, source_path=source_path, final_path=None,
                content_hash=content_hash,
            )
        return Decision(
            proposal_id=proposal["proposal_id"], kind="defer",
            reason="forget_evidence_unclear",
            proposal=proposal, source_path=source_path, final_path=None,
            content_hash=content_hash,
        )

    def _classify_text(
        self, subtype: str, proposal: dict, source_path: Path, content_hash: str | None
    ) -> Decision:
        text = proposal["content"].get("text")
        text = text if isinstance(text, str) else ""
        min_chars = self.config["min_lesson_chars"]
        max_chars = self.config["max_lesson_chars"]
        if len(text.strip()) < min_chars:
            return Decision(
                proposal_id=proposal["proposal_id"], kind="reject",
                reason=f"{subtype}_too_short",
                proposal=proposal, source_path=source_path, final_path=None,
                content_hash=content_hash,
            )
        if len(text) > max_chars:
            return Decision(
                proposal_id=proposal["proposal_id"], kind="reject",
                reason=f"{subtype}_too_long",
                proposal=proposal, source_path=source_path, final_path=None,
                content_hash=content_hash,
            )
        text_lower = text.lower()
        for cliche in self.config["generic_platitudes"]:
            if cliche.lower() in text_lower:
                return Decision(
                    proposal_id=proposal["proposal_id"], kind="reject",
                    reason=f"{subtype}_generic_platitude",
                    proposal=proposal, source_path=source_path, final_path=None,
                    content_hash=content_hash,
                )
        if content_hash is not None and self._hash_repeat_count(content_hash) >= self.config[
            "lesson_priming_repeat_threshold"
        ]:
            return Decision(
                proposal_id=proposal["proposal_id"], kind="reject",
                reason=f"{subtype}_priming_repeat",
                proposal=proposal, source_path=source_path, final_path=None,
                content_hash=content_hash,
            )
        return Decision(
            proposal_id=proposal["proposal_id"], kind="defer",
            reason=f"{subtype}_needs_llm_review",
            proposal=proposal, source_path=source_path, final_path=None,
            content_hash=content_hash,
        )

    # ---- helpers ----

    def _is_duplicate(self, proposal_id: str) -> bool:
        if self.event_log is None:
            return False
        for ev in self.event_log.query(event_type="proposal_processed"):
            if ev.get("proposal_id") == proposal_id:
                return True
        return False

    def _hash_repeat_count(self, content_hash: str) -> int:
        if self.event_log is None:
            return 0
        return sum(
            1
            for ev in self.event_log.query(event_type="proposal_processed")
            if ev.get("content_hash") == content_hash
        )

    def read(self, path: Path) -> dict | None:
        """Best-effort proposal load. Returns None on parse / IO failure so
        the caller can route the file to ``quarantine/`` via ``process``."""
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError, UnicodeDecodeError):
            return None

    def _archive(self, decision: Decision) -> Path | None:
        source = Path(decision.source_path)
        if not source.exists():
            return None
        target_dir = self.processed_dir / _KIND_TO_DIR[decision.kind]
        target_dir.mkdir(parents=True, exist_ok=True)
        candidate = target_dir / source.name
        for n in range(4):
            if not candidate.exists():
                os.rename(source, candidate)
                return candidate
            candidate = target_dir / f"{source.stem}_collision_{n + 1}{source.suffix}"
        # 3 retries exhausted → quarantine, never silent overwrite.
        quarantine = self.processed_dir / "quarantine" / source.name
        n = 0
        while quarantine.exists():
            n += 1
            quarantine = self.processed_dir / "quarantine" / f"{source.stem}_collision_{n}{source.suffix}"
        os.rename(source, quarantine)
        return quarantine

    def _log(self, decision: Decision) -> None:
        if self.event_log is None:
            return
        proposal = decision.proposal or {}
        payload = {
            "event":        "proposal_processed",
            "proposal_id":  decision.proposal_id,
            "kind":         decision.kind,
            "reason":       decision.reason,
            "subtype":      proposal.get("subtype") if isinstance(proposal, dict) else None,
            "content_hash": decision.content_hash,
            "source_path":  str(decision.source_path),
            "final_path":   str(decision.final_path) if decision.final_path else None,
        }
        self.event_log.append(payload)


def _safe_str(v: object) -> str | None:
    return v if isinstance(v, str) and v else None
