# v1 | 2026-05-02 | M6 Ollama client
"""OllamaClient — concrete LLMClient against a local Ollama server.

Stdlib HTTP only (``urllib.request``); no ``requests`` dep so the air-
gapped banking deployment stays clean. The endpoint is locked to the
loopback interface at construction — see ``_assert_loopback`` — so a
config typo can never cause an outbound DNS lookup or HTTP call.

Two methods, narrow surface (matches the M1 ``LLMClient`` Protocol):

  - ``available()``  GET  /api/tags     → does the model exist locally?
  - ``complete()``   POST /api/generate → one bounded round-trip.

Failure modes raise ``LLMError`` (this module). ``available()`` always
returns a bool — exceptions there are logged-and-swallowed because a
not-running daemon is the common case, not a bug.
"""

from __future__ import annotations

import json
import logging
import socket
import sys
import urllib.error
import urllib.parse
import urllib.request
from typing import Any

_LOG = logging.getLogger("contmemo.ollama")


class LLMError(Exception):
    """Anything that prevented a clean LLM round-trip."""


_LOOPBACK_HOSTS = frozenset({"127.0.0.1", "localhost", "::1"})


def _assert_loopback(endpoint: str) -> None:
    """Banking defense: refuse non-loopback endpoints at init time."""
    parsed = urllib.parse.urlparse(endpoint)
    host = (parsed.hostname or "").lower()
    if host not in _LOOPBACK_HOSTS:
        raise ValueError(
            f"endpoint must be loopback (127.0.0.1, localhost, ::1); got {host!r}"
        )


class OllamaClient:
    """Thin Ollama HTTP client. One instance per Runtime."""

    def __init__(
        self,
        *,
        endpoint: str = "http://127.0.0.1:11434",
        model: str = "",
        timeout_s: float = 30.0,
        config: dict | None = None,
    ) -> None:
        _assert_loopback(endpoint)
        self.endpoint = endpoint.rstrip("/")
        self.model = model
        self.timeout_s = float(timeout_s)
        self.config = config or {}

    # ---- public API ----

    def available(self) -> bool:
        """True iff endpoint responds and ``self.model`` appears in /api/tags."""
        if not self.model:
            return False
        try:
            url = self.endpoint + "/api/tags"
            req = urllib.request.Request(url, method="GET")
            with urllib.request.urlopen(req, timeout=2.0) as resp:
                data = json.loads(resp.read().decode("utf-8"))
        except (urllib.error.URLError, socket.timeout, OSError, json.JSONDecodeError) as exc:
            _LOG.info("ollama unavailable: %s", exc)
            return False

        models = data.get("models") or []
        for entry in models:
            name = entry.get("name") if isinstance(entry, dict) else None
            if isinstance(name, str) and name.startswith(self.model):
                return True
        return False

    def complete(self, prompt: str, *, max_tokens: int = 512) -> str:
        """One generate call. Returns the ``response`` field. Raises LLMError."""
        body = json.dumps({
            "model":   self.model,
            "prompt":  prompt,
            "stream":  False,
            "options": {
                "num_predict": int(max_tokens),
                "temperature": float(self.config.get("temperature", 0.0)),
            },
        }, ensure_ascii=False).encode("utf-8")

        url = self.endpoint + "/api/generate"
        req = urllib.request.Request(
            url,
            data=body,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=self.timeout_s) as resp:
                payload = json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            raise LLMError(f"http_error_{exc.code}") from exc
        except (urllib.error.URLError, socket.timeout, OSError) as exc:
            raise LLMError(f"transport_error:{type(exc).__name__}") from exc
        except json.JSONDecodeError as exc:
            raise LLMError("body_not_json") from exc

        out = payload.get("response")
        if not isinstance(out, str):
            raise LLMError("missing_response_field")
        return out
