# v1 | 2026-05-02 | core package marker
"""contmemo.core — runtime, storage, and decision modules.

Each submodule has a single named class as its public surface. Later sprints
fill in the bodies; the contracts stay stable.
"""
