# v2 | 2026-05-02 | M2 event log impl
"""EventLog — append-only JSONL, Contmemo's own deterministic memory.

This is the one part of contmemo's memory that has **no LLM in the loop**.
That is intentional: it breaks the "Contmemo's Contmemo" recursion. Every
decision, every accepted/rejected proposal, every detected failure pattern
lands here as a raw record. Summaries, if any, are derived views computed
on read, never stored as truth.

Pattern reference: event sourcing; git's append-only object store.

Hard invariants:
  - Append-only. No edit, no delete.
  - Atomic per line. Single events kept under 4 KiB so the kernel-level
    write cannot tear them; an exclusive flock guards multi-writer races.
  - ts auto-stamped (UTC ISO 8601) when missing; preserved when present.
  - Crash-safe reads: a torn final line is skipped with a warning.
  - Air-gapped: stdlib only.
"""

from __future__ import annotations

import fcntl
import json
import os
import sys
from collections import deque
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterator

_MAX_EVENT_BYTES = 4096


def _now_iso() -> str:
    """UTC ISO 8601 timestamp. Module-level so tests can monkeypatch."""
    return datetime.now(timezone.utc).isoformat()


def _parse_ts(s: object) -> datetime | None:
    """Tolerant ISO 8601 → datetime. Accepts trailing Z. Returns None on failure."""
    if not isinstance(s, str):
        return None
    try:
        if s.endswith("Z"):
            s = s[:-1] + "+00:00"
        return datetime.fromisoformat(s)
    except ValueError:
        return None


class EventLog:
    """Append-only JSONL with a small lookup API."""

    def __init__(self, path: Path) -> None:
        self.path = Path(path)

    def append(self, event: dict) -> None:
        """Atomically append a single event. Adds ``ts`` if absent.

        Raises ``ValueError("event_too_large", n)`` if the serialized line
        (JSON + newline, UTF-8) exceeds 4 KiB — kernel atomicity ceiling.
        """
        ev = dict(event)
        ev.setdefault("ts", _now_iso())
        line = (json.dumps(ev, ensure_ascii=False, separators=(",", ":")) + "\n").encode("utf-8")
        if len(line) > _MAX_EVENT_BYTES:
            raise ValueError("event_too_large", len(line))
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.path, "ab") as f:
            try:
                fcntl.flock(f.fileno(), fcntl.LOCK_EX)
                f.write(line)
                f.flush()
                os.fsync(f.fileno())
            finally:
                fcntl.flock(f.fileno(), fcntl.LOCK_UN)

    def query(
        self,
        *,
        last: int | None = None,
        event_type: str | None = None,
        since: datetime | None = None,
        until: datetime | None = None,
    ) -> Iterator[dict]:
        """Stream matching events. All filters AND together.

        Order: ``event_type`` → ``since`` → ``until`` → ``last``.
        Missing file ⇒ empty iterator (no error). Torn / unparseable lines
        are skipped with a stderr warning so a single corrupt tail does
        not poison the stream.
        """
        if not self.path.exists():
            return iter(())

        def _stream() -> Iterator[dict]:
            with open(self.path, "rb") as f:
                for raw in f:
                    text = raw.decode("utf-8", errors="replace").rstrip("\n")
                    if not text:
                        continue
                    try:
                        ev = json.loads(text)
                    except json.JSONDecodeError:
                        print(
                            f"contmemo.event_log: skipping corrupt line in {self.path}",
                            file=sys.stderr,
                        )
                        continue
                    if not isinstance(ev, dict):
                        continue
                    if event_type is not None and ev.get("event") != event_type:
                        continue
                    if since is not None or until is not None:
                        ts = _parse_ts(ev.get("ts"))
                        if ts is None:
                            continue
                        if since is not None and ts < since:
                            continue
                        if until is not None and ts > until:
                            continue
                    yield ev

        if last is None:
            return _stream()
        # Last-N: bounded memory via deque; still a generator from caller's view.
        return iter(deque(_stream(), maxlen=last))
