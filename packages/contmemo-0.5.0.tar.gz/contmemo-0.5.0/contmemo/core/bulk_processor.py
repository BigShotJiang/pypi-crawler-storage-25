# v1 | 2026-05-02 | M6 bulk processor
"""BulkProcessor — drains processed/deferred/ + summarizes friction patterns.

This is the only place in the contmemo codebase that calls an LLM. The
light path stays LLM-free per the M6 brief invariant. Every LLM round-
trip lands as one ``llm_evaluation`` (or ``pattern_summarized``) event
in the M2 event log; the prompt itself is hashed not stored, so the
event log carries an audit trail without leaking the full prompt.

Flow (process_deferred):

  glob deferred/*.json  →  parse  →  M3 re-classify  →  prompt LLM
                        →  parse JSON  →  Decision  →  M4 writer
                        →  move file to accepted/ or rejected/
                        →  llm_evaluation event

Flow (summarize_patterns): walk pattern_detected since cutoff, skip ones
already summarized inside the cooldown window, prompt + emit one
``pattern_summarized`` event each.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from contmemo.core.event_log import EventLog
from contmemo.core.memory_writer import MemoryWriter
from contmemo.core.proposal_inbox import Decision, ProposalInbox

# Local Protocol shim — duck-typed; matches OllamaClient and FakeLLM in tests.
class _LLMLike:
    def available(self) -> bool: ...  # pragma: no cover
    def complete(self, prompt: str, *, max_tokens: int = 512) -> str: ...  # pragma: no cover


_MEMORY_EVAL_SCHEMA: dict = {
    "required": ["decision", "reason_tag"],
    "types":    {"decision": str, "reason_tag": str, "rationale": str},
}

_FAILURE_ANALYSIS_SCHEMA: dict = {
    "required": ["summary", "severity", "tags"],
    "types":    {"summary": str, "severity": str, "tags": list},
}

_DEFAULT_CONFIG: dict = {
    "max_items_per_run":           50,
    "pattern_summary_cooldown_s":  86400,
    "memory_context_max_entries":  20,
    "recent_events_max":           20,
}


def parse_llm_json(raw: str, *, schema: dict | None = None) -> dict:
    """Strip optional code fence, parse JSON, optionally enforce a tiny schema.

    Designed for instruct-tuned models that decorate output with ```json
    ... ``` even when told not to.
    """
    s = raw.strip()
    if s.startswith("```"):
        s = re.sub(r"^```(?:json)?\s*\n?", "", s)
        s = re.sub(r"\n?```\s*$", "", s)
    obj = json.loads(s)
    if not isinstance(obj, dict):
        raise ValueError("not_an_object")
    if schema is not None:
        for key in schema.get("required", []):
            if key not in obj:
                raise ValueError(f"missing_key:{key}")
        for key, typ in schema.get("types", {}).items():
            if key in obj and not isinstance(obj[key], typ):
                raise ValueError(f"bad_type:{key}")
    return obj


def parse_since(expr: str | None) -> datetime | None:
    """Tolerant relative-time parser. None / empty → None.

    Forms: ``"30 seconds ago"``, ``"5 minutes ago"``, ``"2 hours ago"``,
    ``"1 day ago"``, ``"yesterday"``. ISO 8601 is also accepted as a
    fallback so callers can pin an absolute moment.
    """
    if expr is None:
        return None
    s = expr.strip().lower()
    if not s:
        return None
    if s == "yesterday":
        return datetime.now(timezone.utc) - timedelta(days=1)
    m = re.match(r"^(\d+)\s+(second|minute|hour|day)s?\s+ago$", s)
    if m:
        n = int(m.group(1))
        unit = m.group(2)
        seconds = {"second": 1, "minute": 60, "hour": 3600, "day": 86400}[unit]
        return datetime.now(timezone.utc) - timedelta(seconds=n * seconds)
    # ISO fallback.
    try:
        if s.endswith("z"):
            s = s[:-1] + "+00:00"
        return datetime.fromisoformat(s)
    except ValueError:
        return None


def _prompt_hash(prompt: str) -> str:
    return hashlib.sha256(prompt.encode("utf-8")).hexdigest()[:16]


class BulkProcessor:
    """Drains the deferred inbox, evaluates with the LLM, surfaces patterns."""

    def __init__(
        self,
        *,
        llm: Any,
        event_log: EventLog,
        writer: MemoryWriter,
        inbox: ProposalInbox,
        deferred_dir: Path,
        processed_dir: Path,
        memory_path: Path,
        prompts_dir: Path | None = None,
        config: dict | None = None,
    ) -> None:
        self.llm = llm
        self.event_log = event_log
        self.writer = writer
        self.inbox = inbox
        self.deferred_dir = Path(deferred_dir)
        self.processed_dir = Path(processed_dir)
        self.memory_path = Path(memory_path)
        self.prompts_dir = Path(prompts_dir) if prompts_dir else None
        self.config = {**_DEFAULT_CONFIG, **(config or {})}

    # ---- prompts ----

    def _load_prompt(self, name: str) -> str:
        if self.prompts_dir is not None:
            return (self.prompts_dir / name).read_text(encoding="utf-8")
        from importlib import resources
        return resources.files("contmemo.prompts").joinpath(name).read_text(encoding="utf-8")

    # ---- public API ----

    def process_deferred(
        self,
        *,
        since: datetime | None = None,
        max_items: int | None = None,
        dry_run: bool = False,
    ) -> dict:
        summary = {
            "deferred_processed": 0,
            "deferred_accepted":  0,
            "deferred_rejected":  0,
            "deferred_skipped":   0,
        }
        if not self.deferred_dir.exists():
            return summary

        files = sorted(self.deferred_dir.glob("*.json"))
        if since is not None:
            cutoff = since.timestamp()
            files = [f for f in files if f.stat().st_mtime >= cutoff]
        cap = max_items if max_items is not None else self.config["max_items_per_run"]
        files = files[:cap]

        prompt_template = self._load_prompt("memory_evaluation.txt")

        for path in files:
            summary["deferred_processed"] += 1
            try:
                proposal = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError, UnicodeDecodeError):
                summary["deferred_skipped"] += 1
                self._archive_to(path, "rejected")
                self._log_evaluation(
                    proposal_id=None, latency_s=0.0, prompt_hash=None,
                    raw_response=None, parsed=None, decision_kind="skipped",
                    reason="parse_fail",
                )
                continue

            proposal_id = proposal.get("proposal_id") if isinstance(proposal, dict) else None

            # Paranoia: deterministic rules may have tightened since the
            # original M3 pass. Re-classify before paying the LLM.
            recheck = self.inbox.classify(proposal, path)
            if recheck.kind == "reject":
                self._apply(recheck, path, archive_kind="rejected", dry_run=dry_run)
                summary["deferred_rejected"] += 1
                self._log_evaluation(
                    proposal_id=proposal_id, latency_s=0.0, prompt_hash=None,
                    raw_response=None, parsed=None, decision_kind="reject",
                    reason=f"recheck_{recheck.reason}",
                )
                continue

            existing = self._load_recent_memory(
                subtype=proposal.get("subtype") if isinstance(proposal, dict) else None,
                limit=int(self.config["memory_context_max_entries"]),
            )
            prompt = _render(prompt_template, {
                "proposal_json": json.dumps(proposal, ensure_ascii=False, indent=2),
                "user_message":  proposal.get("user_message", "") if isinstance(proposal, dict) else "",
                "existing_memory": json.dumps(existing, ensure_ascii=False, indent=2),
            })

            t0 = time.monotonic()
            try:
                raw = self.llm.complete(prompt)
                latency = time.monotonic() - t0
            except Exception as exc:
                summary["deferred_skipped"] += 1
                self._log_evaluation(
                    proposal_id=proposal_id, latency_s=time.monotonic() - t0,
                    prompt_hash=_prompt_hash(prompt), raw_response=None,
                    parsed=None, decision_kind="skipped",
                    reason=f"llm_call_failed:{type(exc).__name__}",
                )
                continue

            try:
                parsed = parse_llm_json(raw, schema=_MEMORY_EVAL_SCHEMA)
            except (ValueError, json.JSONDecodeError) as exc:
                summary["deferred_rejected"] += 1
                synthesized = Decision(
                    proposal_id=proposal_id, kind="reject",
                    reason="llm_output_invalid",
                    proposal=proposal, source_path=path, final_path=None,
                    content_hash=recheck.content_hash,
                )
                self._apply(synthesized, path, archive_kind="rejected", dry_run=dry_run)
                self._log_evaluation(
                    proposal_id=proposal_id, latency_s=latency,
                    prompt_hash=_prompt_hash(prompt), raw_response=raw,
                    parsed=None, decision_kind="reject",
                    reason=f"llm_output_invalid:{exc}",
                )
                continue

            llm_decision = parsed["decision"]
            tag = parsed.get("reason_tag", "llm_eval")
            if llm_decision == "accept":
                final = Decision(
                    proposal_id=proposal_id, kind="accept",
                    reason=f"llm_eval_accept:{tag}",
                    proposal=proposal, source_path=path, final_path=None,
                    content_hash=recheck.content_hash,
                )
                self._apply(final, path, archive_kind="accepted", dry_run=dry_run)
                summary["deferred_accepted"] += 1
            else:
                final = Decision(
                    proposal_id=proposal_id, kind="reject",
                    reason=f"llm_eval_reject:{tag}",
                    proposal=proposal, source_path=path, final_path=None,
                    content_hash=recheck.content_hash,
                )
                self._apply(final, path, archive_kind="rejected", dry_run=dry_run)
                summary["deferred_rejected"] += 1

            self._log_evaluation(
                proposal_id=proposal_id, latency_s=latency,
                prompt_hash=_prompt_hash(prompt), raw_response=raw,
                parsed=parsed, decision_kind=llm_decision,
                reason=tag,
            )

        return summary

    def summarize_patterns(
        self,
        *,
        since: datetime | None = None,
        dry_run: bool = False,
    ) -> dict:
        out = {"patterns_summarized": 0}

        cutoff = since
        hits = list(self.event_log.query(event_type="pattern_detected", since=cutoff))
        if not hits:
            return out

        cooldown_s = int(self.config["pattern_summary_cooldown_s"])
        cooldown_cutoff = datetime.now(timezone.utc) - timedelta(seconds=cooldown_s)
        recent_summaries = list(self.event_log.query(
            event_type="pattern_summarized", since=cooldown_cutoff,
        ))
        already = {json.dumps(ev.get("signal"), sort_keys=True) for ev in recent_summaries}

        prompt_template = self._load_prompt("failure_analysis.txt")
        recent_events_max = int(self.config["recent_events_max"])
        recent_events = list(self.event_log.query(last=recent_events_max))

        for hit in hits:
            sig_key = json.dumps(hit.get("signal"), sort_keys=True)
            if sig_key in already:
                continue

            prompt = _render(prompt_template, {
                "signal_json":    json.dumps(hit.get("signal"), ensure_ascii=False),
                "count":          str(hit.get("count", "")),
                "first_seen_ts":  str(hit.get("first_seen_ts", "")),
                "last_seen_ts":   str(hit.get("last_seen_ts", "")),
                "recent_events":  json.dumps(recent_events, ensure_ascii=False, indent=2),
            })
            t0 = time.monotonic()
            try:
                raw = self.llm.complete(prompt)
                latency = time.monotonic() - t0
            except Exception as exc:
                self._log_pattern_summary(
                    hit, latency_s=time.monotonic() - t0, prompt_hash=_prompt_hash(prompt),
                    parsed=None, status="skipped",
                    reason=f"llm_call_failed:{type(exc).__name__}",
                )
                continue

            try:
                parsed = parse_llm_json(raw, schema=_FAILURE_ANALYSIS_SCHEMA)
            except (ValueError, json.JSONDecodeError) as exc:
                self._log_pattern_summary(
                    hit, latency_s=latency, prompt_hash=_prompt_hash(prompt),
                    parsed=None, status="skipped",
                    reason=f"llm_output_invalid:{exc}",
                )
                continue

            if not dry_run:
                self._log_pattern_summary(
                    hit, latency_s=latency, prompt_hash=_prompt_hash(prompt),
                    parsed=parsed, status="ok", reason=None,
                )
                already.add(sig_key)
            out["patterns_summarized"] += 1

        return out

    # ---- internals ----

    def _apply(
        self, decision: Decision, source_path: Path, *,
        archive_kind: str, dry_run: bool,
    ) -> None:
        if dry_run:
            return
        if decision.kind == "accept":
            try:
                self.writer.write(decision)
            except Exception:
                pass  # writer logs its own failures via M4
        self._archive_to(source_path, archive_kind)

    def _archive_to(self, source_path: Path, kind: str) -> Path | None:
        if not source_path.exists():
            return None
        target_dir = self.processed_dir / kind
        target_dir.mkdir(parents=True, exist_ok=True)
        target = target_dir / source_path.name
        n = 0
        while target.exists():
            n += 1
            target = target_dir / f"{source_path.stem}_collision_{n}{source_path.suffix}"
        os.rename(source_path, target)
        return target

    def _load_recent_memory(self, subtype: str | None, limit: int) -> list[dict]:
        if not self.memory_path.exists():
            return []
        out: list[dict] = []
        try:
            for line in self.memory_path.read_text(encoding="utf-8").splitlines():
                if not line.strip():
                    continue
                try:
                    entry = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if subtype is None or entry.get("subtype") == subtype:
                    out.append(entry)
        except OSError:
            return []
        return out[-limit:]

    def _log_evaluation(
        self, *, proposal_id, latency_s, prompt_hash, raw_response,
        parsed, decision_kind, reason,
    ) -> None:
        self.event_log.append({
            "event":        "llm_evaluation",
            "proposal_id":  proposal_id,
            "latency_s":    round(float(latency_s), 4),
            "prompt_hash":  prompt_hash,
            "raw_response": raw_response,
            "parsed":       parsed,
            "decision_kind": decision_kind,
            "reason":       reason,
        })

    def _log_pattern_summary(
        self, hit: dict, *, latency_s, prompt_hash, parsed, status, reason,
    ) -> None:
        self.event_log.append({
            "event":        "pattern_summarized",
            "signal":       hit.get("signal"),
            "count":        hit.get("count"),
            "first_seen_ts": hit.get("first_seen_ts"),
            "last_seen_ts":  hit.get("last_seen_ts"),
            "latency_s":    round(float(latency_s), 4),
            "prompt_hash":  prompt_hash,
            "summary":      parsed,
            "status":       status,
            "reason":       reason,
        })


def _render(template: str, fields: dict[str, str]) -> str:
    """Minimal {placeholder} substitution. Avoids ``str.format``'s clash with
    JSON braces in the template body."""
    out = template
    for key, value in fields.items():
        out = out.replace("{" + key + "}", value)
    return out
