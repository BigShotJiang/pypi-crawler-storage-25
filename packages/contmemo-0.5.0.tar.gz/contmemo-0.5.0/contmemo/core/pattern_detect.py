# v2 | 2026-05-02 | M5 detector impl
"""PatternDetector — counter-based recurrence detection.

Light-mode duty: maintain a rolling deque of the most recent N events,
extract a hashable "signal key" from each, and surface every key whose
count crosses the threshold. **No LLM, no embeddings, no fuzzy matching.**

Signal key is the friction shape, not the success shape — accepts and
clean memory writes are skipped. The detector is interested only in
``proposal_processed`` events with kind ∈ {reject, defer} and in
``memory_write_attempt`` events (which only fire on skip / fail in M4).

State is in-memory only. Restart resets the window; pattern history is
recoverable from the event log via M6 bulk replay.

Pattern reference: streaming top-K / heavy-hitters problem, but at the
toy end (window=50, threshold=3); a Counter on a bounded deque is enough.
"""

from __future__ import annotations

from collections import Counter, deque
from typing import Iterable

# Tuple shape: (kind, reason, subtype). subtype is None for events that
# do not carry one (e.g. memory_write_attempt). Three slots keep the key
# uniform across event types so a Counter can pool them safely.
SignalKey = tuple[str, str, str | None]


def _signal_key(event: dict) -> SignalKey | None:
    """Return the friction signal for an event, or None if not interesting."""
    if not isinstance(event, dict):
        return None
    name = event.get("event")
    kind = event.get("kind")
    reason = event.get("reason")
    if not isinstance(kind, str) or not isinstance(reason, str):
        return None

    if name == "proposal_processed":
        if kind not in ("reject", "defer"):
            return None
        subtype = event.get("subtype")
        subtype = subtype if isinstance(subtype, str) else None
        return (kind, reason, subtype)

    if name == "memory_write_attempt":
        # Only skipped/failed memory writes hit this event name in M4.
        return (kind, reason, None)

    return None


class PatternDetector:
    """Rolling tally of friction-shaped events."""

    def __init__(
        self,
        *,
        window: int = 50,
        threshold: int = 3,
        config: dict | None = None,
    ) -> None:
        self.window = window
        self.threshold = threshold
        self.config = config or {}
        self._events: deque[dict] = deque(maxlen=window)

    def update(self, event: dict) -> None:
        """Fold an event into the window. Cheap; no signal extraction yet."""
        self._events.append(event)

    def detect(self) -> list[dict]:
        """Return current pattern hits as plain dicts. Empty list if none."""
        counts: Counter[SignalKey] = Counter()
        first_ts: dict[SignalKey, str] = {}
        last_ts: dict[SignalKey, str] = {}
        for ev in self._events:
            key = _signal_key(ev)
            if key is None:
                continue
            counts[key] += 1
            ts = ev.get("ts")
            if isinstance(ts, str):
                if key not in first_ts:
                    first_ts[key] = ts
                last_ts[key] = ts

        hits: list[dict] = []
        for key, n in counts.items():
            if n < self.threshold:
                continue
            kind, reason, subtype = key
            hits.append({
                "pattern": "recurring_friction",
                "signal":  {"kind": kind, "reason": reason, "subtype": subtype},
                "count":   n,
                "window":  self.window,
                "first_seen_ts": first_ts.get(key),
                "last_seen_ts":  last_ts.get(key),
            })
        return hits
