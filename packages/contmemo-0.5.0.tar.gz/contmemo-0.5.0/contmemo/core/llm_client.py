# v1 | 2026-05-02 | skeleton; concrete client in M6
"""LLMClient — thin interface to the mini model used in bulk mode.

Mini-model selection is deferred to Sprint M6. Candidates documented in
the brief (qwen2.5-coder-1.5b, -7b, phi-3-mini-4k, gemma-2-2b). Final
choice depends on VRAM budget alongside the 30B production cont model
and on Turkish + reasoning quality on real failure traces.

The interface is deliberately narrow:
  - ``available()``      Can we even reach the model?
  - ``complete()``       One round-trip; bounded latency.
The contract stays this small so swapping model or transport (Ollama,
llama.cpp server, etc.) doesn't ripple through the codebase.

Implementation:
  - Sprint M6: pick model, implement ``complete``, prompt-template the
    three files under ``contmemo/prompts/``.
"""

from __future__ import annotations

from typing import Protocol


class LLMClient(Protocol):
    """Structural type — any object with these methods is a client."""

    def available(self) -> bool:
        """Return True if the backend is reachable and the model is loaded."""
        ...

    def complete(self, prompt: str, *, max_tokens: int = 512) -> str:
        """Return a single completion. Raises on transport / model failure."""
        ...
