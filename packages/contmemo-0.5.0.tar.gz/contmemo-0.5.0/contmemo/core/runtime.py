# v3 | 2026-05-02 | M6 bulk hookup
"""Runtime — orchestrates light and bulk modes.

Light mode (M5): per-iteration deterministic pipeline.

  glob inbox  →  read+process each (M3 ProposalInbox)
              →  if accept → write (M4 MemoryWriter)
              →  refresh detector window from event log
              →  detect()  →  emit pattern_detected (cooldown-gated)
              →  sleep poll_interval_s when no work

Bulk mode (M6): unimplemented — stays NotImplementedError until that
sprint lands the LLM client.

Two-mode design parallels lambda architecture (hot streaming + batch);
M5 ships the streaming side.
"""

from __future__ import annotations

import os
import signal
import sys
import time
import tomllib
from datetime import datetime, timedelta, timezone
from importlib import resources
from pathlib import Path
from typing import Any, Iterator

from contmemo.core.event_log import EventLog
from contmemo.core.memory_writer import MemoryWriter
from contmemo.core.pattern_detect import PatternDetector
from contmemo.core.proposal_inbox import Decision, ProposalInbox


def _expand(p: str) -> Path:
    return Path(os.path.expanduser(p))


def load_config(path: str | Path | None = None) -> dict[str, Any]:
    """Load TOML config. ``path=None`` ⇒ bundled ``config/default.toml``.

    Python 3.11+ stdlib ``tomllib`` only — air-gapped, no extra deps.
    """
    if path:
        with open(path, "rb") as f:
            return tomllib.load(f)
    text = resources.files("contmemo.config").joinpath("default.toml").read_text(encoding="utf-8")
    return tomllib.loads(text)


class Runtime:
    """Top-level orchestrator. One instance per process."""

    def __init__(
        self,
        config: dict[str, Any] | None = None,
        *,
        inbox: ProposalInbox | None = None,
        writer: MemoryWriter | None = None,
        event_log: EventLog | None = None,
        detector: PatternDetector | None = None,
        llm: Any | None = None,
    ) -> None:
        self.config = config or load_config()
        paths = self.config.get("paths", {})
        runtime_cfg = self.config.get("runtime", {})
        detector_cfg = self.config.get("detector", {})

        self.poll_interval_s = float(runtime_cfg.get("poll_interval_s", 1.0))
        self.cooldown_s = int(detector_cfg.get("pattern_emit_cooldown_s", 60))

        # Build components from config when not injected.
        if event_log is not None:
            self.event_log = event_log
        else:
            self.event_log = EventLog(_expand(paths.get("event_log", "~/.cont/contmemo/event_log.jsonl")))

        if inbox is not None:
            self.inbox = inbox
        else:
            self.inbox = ProposalInbox(
                inbox_dir=_expand(paths.get("proposals_inbox", "~/.cont/proposals/inbox")),
                processed_dir=_expand(paths.get("processed_proposals", "~/.cont/contmemo/proposals/processed")),
                event_log=self.event_log,
                config=self.config.get("evaluation"),
            )

        if writer is not None:
            self.writer = writer
        else:
            self.writer = MemoryWriter(
                target_path=_expand(paths.get("memory_path", "~/.cont/memory.jsonl")),
                backup_dir=_expand(paths.get("memory_backup_dir", "~/.cont/.backups")),
                event_log=self.event_log,
            )

        if detector is not None:
            self.detector = detector
        else:
            self.detector = PatternDetector(
                window=int(detector_cfg.get("window", 50)),
                threshold=int(detector_cfg.get("threshold", 3)),
                config=detector_cfg,
            )

        self.llm = llm  # Lazy-built in run_bulk; light path must never import OllamaClient.
        self._shutdown_requested = False

    # ---- public API ----

    def request_shutdown(self) -> None:
        """Trigger a clean exit from ``run_light``. Test-friendly."""
        self._shutdown_requested = True

    def run_light(self, *, max_iterations: int | None = None) -> int:
        """Light-mode loop. Returns count of decisions processed.

        ``max_iterations=None`` runs as a daemon. A finite value runs that
        many polling rounds and returns; this is the path tests use.
        """
        self._install_signal_handlers()
        decision_count = 0
        iteration = 0

        while not self._shutdown_requested:
            iteration += 1
            if max_iterations is not None and iteration > max_iterations:
                break

            any_work = False
            for decision in self._scan_inbox_once():
                any_work = True
                decision_count += 1
                if decision.kind == "accept":
                    try:
                        self.writer.write(decision)
                    except Exception as exc:  # never let a writer hiccup kill the loop
                        self._log_runtime_error("writer_failed", exc, decision)

                self._update_detector_from_log()
                for hit in self.detector.detect():
                    self._maybe_emit_pattern(hit)

            if not any_work:
                time.sleep(self.poll_interval_s)

        return decision_count

    def run_bulk(
        self,
        *,
        since: str | None = None,
        max_items: int | None = None,
        dry_run: bool = False,
    ) -> dict:
        """Bulk reflection over the deferred queue + recent friction patterns.

        Lazy-imports OllamaClient + BulkProcessor so the light path never
        pulls them — the M6 invariant.
        """
        # Local imports — light mode must not pay this cost or expose the dep.
        from contmemo.core.bulk_processor import BulkProcessor, parse_since

        empty = {
            "deferred_processed": 0, "deferred_accepted": 0,
            "deferred_rejected":  0, "deferred_skipped":  0,
            "patterns_summarized": 0, "duration_s": 0.0,
        }

        if self.llm is None:
            self.llm = self._build_llm()

        if self.llm is None or not self.llm.available():
            self.event_log.append({"event": "bulk_skipped", "reason": "llm_unavailable"})
            return empty

        paths = self.config.get("paths", {})
        deferred_dir = self.inbox.processed_dir / "deferred"
        bp = BulkProcessor(
            llm=self.llm,
            event_log=self.event_log,
            writer=self.writer,
            inbox=self.inbox,
            deferred_dir=deferred_dir,
            processed_dir=self.inbox.processed_dir,
            memory_path=self.writer.target_path,
            config=self.config.get("bulk"),
        )

        since_dt = parse_since(since)

        import time as _time
        t0 = _time.monotonic()
        deferred = bp.process_deferred(
            since=since_dt, max_items=max_items, dry_run=dry_run,
        )
        patterns = bp.summarize_patterns(since=since_dt, dry_run=dry_run)
        duration = _time.monotonic() - t0

        return {**deferred, **patterns, "duration_s": round(duration, 4)}

    def _build_llm(self) -> Any | None:
        """Construct an OllamaClient from config. Returns None if disabled."""
        llm_cfg = self.config.get("llm", {})
        model = llm_cfg.get("model") or ""
        if not model:
            return None
        try:
            from contmemo.core.ollama_client import OllamaClient
        except ImportError:
            return None
        try:
            return OllamaClient(
                endpoint=llm_cfg.get("endpoint", "http://127.0.0.1:11434"),
                model=model,
                timeout_s=float(llm_cfg.get("timeout_s", 30.0)),
                config=llm_cfg,
            )
        except ValueError as exc:
            # Loopback assertion failed; refuse to build rather than dial out.
            self.event_log.append({
                "event":  "bulk_skipped",
                "reason": f"llm_config_invalid:{exc}",
            })
            return None

    # ---- internals ----

    def _scan_inbox_once(self) -> Iterator[Decision]:
        for path in sorted(self.inbox.inbox_dir.glob("*.json")):
            try:
                proposal = self.inbox.read(path)
                yield self.inbox.process(proposal, source_path=path)
            except Exception as exc:  # transient malformed input must not kill loop
                self._log_runtime_error("inbox_iter_failed", exc, source_path=path)
                continue

    def _update_detector_from_log(self) -> None:
        # Naïve full-window refresh; brief explicitly defers incremental
        # update until profiling shows it matters.
        self.detector._events.clear()
        for ev in self.event_log.query(last=self.detector.window):
            self.detector.update(ev)

    def _maybe_emit_pattern(self, hit: dict) -> None:
        cutoff = datetime.now(timezone.utc) - timedelta(seconds=self.cooldown_s)
        for ev in self.event_log.query(event_type="pattern_detected", since=cutoff):
            if ev.get("signal") == hit["signal"]:
                return
        self.event_log.append({"event": "pattern_detected", **hit})

    def _install_signal_handlers(self) -> None:
        def handler(signum: int, frame: Any) -> None:
            self._shutdown_requested = True
        try:
            signal.signal(signal.SIGTERM, handler)
            signal.signal(signal.SIGINT, handler)
        except (ValueError, OSError):
            # Not running on the main thread (e.g. inside a test thread).
            # request_shutdown() is the supported escape hatch there.
            pass

    def _log_runtime_error(
        self, reason: str, exc: BaseException,
        decision: Decision | None = None, source_path: Path | None = None,
    ) -> None:
        try:
            self.event_log.append({
                "event":          "runtime_error",
                "reason":         reason,
                "error_type":     type(exc).__name__,
                "error_message":  str(exc)[:300],
                "proposal_id":    getattr(decision, "proposal_id", None),
                "source_path":    str(source_path) if source_path else None,
            })
        except Exception:
            # Even the logger is broken — last-ditch stderr.
            print(f"contmemo runtime: {reason} ({type(exc).__name__})", file=sys.stderr)
