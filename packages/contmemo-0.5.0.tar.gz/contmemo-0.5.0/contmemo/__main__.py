# v4 | 2026-05-02 | M6 CLI: --bulk wired live (LLM in the loop)
"""contmemo CLI entry point.

Modes (mutually exclusive, exactly one required):
  --watch    Light-mode daemon: scan inbox, decide, write, detect patterns.
             Wired to ``Runtime.run_light`` in M5.
  --bulk     One-shot bulk reflection over a recent window.
             Lands in Sprint M6 (still exits 2 here).
  --report   Print the tail of the event log as JSONL on stdout.
             M5 ships a small dump; richer formatting can come later.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

from contmemo import __version__


def build_parser() -> argparse.ArgumentParser:
    """Construct the top-level argparse parser. Pure; safe to call in tests."""
    parser = argparse.ArgumentParser(
        prog="contmemo",
        description=(
            "Memory custodian for the Cont Hive ecosystem. "
            "Evaluates and persists memory proposals from cont and friends."
        ),
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"contmemo {__version__}",
    )

    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--watch",  action="store_true", help="Run light-mode daemon (M5).")
    mode.add_argument("--bulk",   action="store_true", help="One-shot bulk reflection (Sprint M6).")
    mode.add_argument("--report", action="store_true", help="Print event-log tail on stdout.")

    parser.add_argument(
        "--inbox-dir",
        type=str,
        default=None,
        help="Proposal inbox directory (default from config).",
    )
    parser.add_argument(
        "--since",
        type=str,
        default=None,
        help="Bulk window, e.g. '1 hour ago' (used with --bulk).",
    )
    parser.add_argument(
        "--last",
        type=int,
        default=None,
        help="Tail N events (used with --report).",
    )
    parser.add_argument(
        "--max-iterations",
        type=int,
        default=None,
        help="Stop --watch after N polling rounds (smoke / integration tests).",
    )
    parser.add_argument(
        "--max-items",
        type=int,
        default=None,
        help="Cap deferred items per --bulk run (operational throttle).",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="With --bulk: call the LLM but don't write or move files.",
    )
    parser.add_argument(
        "--config",
        type=str,
        default=None,
        help="Path to a config TOML (default: bundled config/default.toml).",
    )

    return parser


def _run_watch(args: argparse.Namespace) -> int:
    from contmemo.core.runtime import Runtime, load_config

    config = load_config(args.config)
    if args.inbox_dir:
        config.setdefault("paths", {})["proposals_inbox"] = args.inbox_dir
    runtime = Runtime(config=config)
    n = runtime.run_light(max_iterations=args.max_iterations)
    print(
        f"contmemo: processed {n} decisions, exiting cleanly.",
        file=sys.stderr,
    )
    return 0


def _run_bulk(args: argparse.Namespace) -> int:
    from contmemo.core.runtime import Runtime, load_config

    config = load_config(args.config)
    runtime = Runtime(config=config)
    summary = runtime.run_bulk(
        since=args.since,
        max_items=args.max_items,
        dry_run=args.dry_run,
    )
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0


def _run_report(args: argparse.Namespace) -> int:
    from contmemo.core.event_log import EventLog
    from contmemo.core.runtime import _expand, load_config

    config = load_config(args.config)
    log_path = _expand(config.get("paths", {}).get("event_log", "~/.cont/contmemo/event_log.jsonl"))
    log = EventLog(log_path)
    last = args.last if args.last is not None else 20
    for ev in log.query(last=last):
        print(json.dumps(ev, ensure_ascii=False))
    return 0


def main(argv: list[str] | None = None) -> int:
    """Process CLI args. Returns process exit code."""
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.watch:
        return _run_watch(args)
    if args.report:
        return _run_report(args)
    if args.bulk:
        return _run_bulk(args)

    # argparse mutual exclusion makes this unreachable.
    parser.error("no mode selected")
    return 2  # pragma: no cover


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
