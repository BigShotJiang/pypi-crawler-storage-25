# v1 | 2026-05-02 | M2 event log tests
"""EventLog behavior + invariants. Stdlib only — no fixtures beyond tmp_path."""

from __future__ import annotations

import json
import threading
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

from contmemo.core.event_log import EventLog


@pytest.fixture
def tmp_log(tmp_path: Path) -> Path:
    return tmp_path / "events.jsonl"


def _read_lines(p: Path) -> list[dict]:
    return [json.loads(line) for line in p.read_text().splitlines() if line.strip()]


# ---------- append ----------


def test_append_creates_file(tmp_log: Path) -> None:
    EventLog(tmp_log).append({"event": "x"})
    assert tmp_log.exists()


def test_append_adds_ts_when_missing(tmp_log: Path) -> None:
    EventLog(tmp_log).append({"event": "x"})
    rows = _read_lines(tmp_log)
    assert "ts" in rows[0]
    datetime.fromisoformat(rows[0]["ts"])  # parses cleanly


def test_append_preserves_ts_when_present(tmp_log: Path) -> None:
    fixed = "2025-01-01T00:00:00+00:00"
    EventLog(tmp_log).append({"event": "x", "ts": fixed})
    assert _read_lines(tmp_log)[0]["ts"] == fixed


def test_append_is_append_only(tmp_log: Path) -> None:
    log = EventLog(tmp_log)
    for i in range(3):
        log.append({"event": "x", "i": i})
    rows = _read_lines(tmp_log)
    assert [r["i"] for r in rows] == [0, 1, 2]


def test_append_too_large_raises(tmp_log: Path) -> None:
    big = {"event": "x", "blob": "a" * 5000}
    with pytest.raises(ValueError) as exc:
        EventLog(tmp_log).append(big)
    assert exc.value.args[0] == "event_too_large"
    assert isinstance(exc.value.args[1], int) and exc.value.args[1] > 4096


def test_append_creates_parent_dir(tmp_path: Path) -> None:
    nested = tmp_path / "a" / "b" / "events.jsonl"
    EventLog(nested).append({"event": "x"})
    assert nested.exists()


# ---------- query ----------


def test_query_empty_log_returns_empty_iterator(tmp_log: Path) -> None:
    tmp_log.touch()
    assert list(EventLog(tmp_log).query()) == []


def test_query_missing_file_returns_empty_iterator(tmp_path: Path) -> None:
    assert list(EventLog(tmp_path / "never.jsonl").query()) == []


def test_query_last_n(tmp_log: Path) -> None:
    log = EventLog(tmp_log)
    for i in range(10):
        log.append({"event": "x", "i": i})
    out = list(log.query(last=3))
    assert [r["i"] for r in out] == [7, 8, 9]


def test_query_event_type_filter(tmp_log: Path) -> None:
    log = EventLog(tmp_log)
    log.append({"event": "accept", "i": 1})
    log.append({"event": "reject", "i": 2})
    log.append({"event": "accept", "i": 3})
    out = list(log.query(event_type="accept"))
    assert [r["i"] for r in out] == [1, 3]


def test_query_since_until_window(tmp_log: Path) -> None:
    log = EventLog(tmp_log)
    base = datetime(2026, 5, 2, 12, 0, 0, tzinfo=timezone.utc)
    for offset_min in (-30, 0, 30, 60, 90):
        ts = (base + timedelta(minutes=offset_min)).isoformat()
        log.append({"event": "x", "off": offset_min, "ts": ts})
    out = list(log.query(since=base, until=base + timedelta(minutes=60)))
    assert [r["off"] for r in out] == [0, 30, 60]


def test_query_combined_filters(tmp_log: Path) -> None:
    log = EventLog(tmp_log)
    base = datetime(2026, 5, 2, tzinfo=timezone.utc)
    for i in range(6):
        log.append({
            "event": "accept" if i % 2 == 0 else "reject",
            "i": i,
            "ts": (base + timedelta(minutes=i)).isoformat(),
        })
    out = list(log.query(
        event_type="accept",
        since=base + timedelta(minutes=1),
        last=2,
    ))
    assert [r["i"] for r in out] == [2, 4]


def test_query_skips_corrupt_lines(tmp_log: Path, capsys: pytest.CaptureFixture) -> None:
    log = EventLog(tmp_log)
    log.append({"event": "ok", "i": 1})
    # simulate a torn write: invalid JSON in the middle
    with open(tmp_log, "ab") as f:
        f.write(b'{"event": "broken", "ts":\n')  # missing close
    log.append({"event": "ok", "i": 2})
    out = list(log.query())
    assert [r["i"] for r in out] == [1, 2]
    err = capsys.readouterr().err
    assert "corrupt" in err.lower()


def test_query_is_lazy(tmp_log: Path) -> None:
    """Generator should not exhaust the file unless iterated."""
    log = EventLog(tmp_log)
    for i in range(50):
        log.append({"event": "x", "i": i})
    it = log.query()
    first = next(it)
    assert first["i"] == 0
    # Pulling one more proves we did not buffer the whole file at construction.
    second = next(it)
    assert second["i"] == 1


# ---------- concurrency ----------


def test_concurrent_appends_no_interleaving(tmp_log: Path) -> None:
    log = EventLog(tmp_log)
    n_threads, per_thread = 5, 20

    def worker(tid: int) -> None:
        for k in range(per_thread):
            log.append({"event": "x", "tid": tid, "k": k})

    threads = [threading.Thread(target=worker, args=(t,)) for t in range(n_threads)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    rows = _read_lines(tmp_log)
    assert len(rows) == n_threads * per_thread
    # Every line parsed cleanly = no torn writes.
    seen = {(r["tid"], r["k"]) for r in rows}
    assert len(seen) == n_threads * per_thread
