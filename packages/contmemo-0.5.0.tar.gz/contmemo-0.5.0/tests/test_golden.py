# v1 | 2026-05-02 | M3 golden suite — human-labelled, deterministic
"""Golden regression set.

Per brief v2 there is no LLM-as-judge. Each fixture pins a (proposal,
expected_kind, expected_reason) triple. Failures here mean either the
classifier drifted or someone changed a reason string without updating
the fixtures — both worth surfacing loudly.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from contmemo.core.proposal_inbox import ProposalInbox

GOLDEN_DIR = Path(__file__).parent / "golden"
FIXTURES = sorted(GOLDEN_DIR.glob("*.json"))


@pytest.mark.parametrize(
    "fixture_path",
    FIXTURES,
    ids=[p.stem for p in FIXTURES],
)
def test_golden(fixture_path: Path, inbox: ProposalInbox, tmp_path: Path) -> None:
    case = json.loads(fixture_path.read_text(encoding="utf-8"))
    # Use a tmp surrogate as source_path so process()'s archive step never
    # touches the real fixture file (an early M3 run shipped fixtures into
    # the test's processed/ tmp dir and lost them on cleanup).
    surrogate = tmp_path / fixture_path.name
    decision = inbox.process(case["proposal"], surrogate)
    assert decision.kind == case["expected_kind"], (
        f"{fixture_path.name}: expected kind={case['expected_kind']}, got {decision.kind}"
    )
    assert decision.reason == case["expected_reason"], (
        f"{fixture_path.name}: expected reason={case['expected_reason']}, got {decision.reason}"
    )
