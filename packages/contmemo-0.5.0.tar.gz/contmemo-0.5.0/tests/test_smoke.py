# v3 | 2026-05-02 | M6: --bulk is wired too; mode-by-mode tests live elsewhere
"""Smoke tests: package imports cleanly, CLI runs."""

import subprocess
import sys

import pytest

import contmemo
from contmemo.__main__ import build_parser, main


@pytest.mark.smoke
def test_version_attribute():
    assert contmemo.__version__
    assert isinstance(contmemo.__version__, str)
    # Sanity: looks like semver.
    parts = contmemo.__version__.split(".")
    assert len(parts) >= 2
    assert all(p.isdigit() for p in parts)


@pytest.mark.smoke
def test_parser_builds():
    parser = build_parser()
    # Parser must recognize the three modes.
    for flag in ("--watch", "--bulk", "--report"):
        ns = parser.parse_args([flag])
        # Exactly one mode set.
        modes = [getattr(ns, m) for m in ("watch", "bulk", "report")]
        assert sum(modes) == 1


@pytest.mark.smoke
def test_parser_requires_a_mode():
    parser = build_parser()
    with pytest.raises(SystemExit):
        parser.parse_args([])


@pytest.mark.smoke
def test_parser_modes_are_mutually_exclusive():
    parser = build_parser()
    with pytest.raises(SystemExit):
        parser.parse_args(["--watch", "--bulk"])


# All three modes are live in M6+. Per-mode behavior lives in
# test_cli_integration.py (--watch, --report) and test_cli_bulk.py (--bulk).


@pytest.mark.smoke
def test_cli_help_runs():
    result = subprocess.run(
        [sys.executable, "-m", "contmemo", "--help"],
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0
    assert "contmemo" in result.stdout.lower()


@pytest.mark.smoke
def test_cli_version_runs():
    result = subprocess.run(
        [sys.executable, "-m", "contmemo", "--version"],
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0
    assert contmemo.__version__ in result.stdout
