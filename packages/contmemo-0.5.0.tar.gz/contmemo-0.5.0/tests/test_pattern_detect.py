# v1 | 2026-05-02 | M5 pattern detector tests
"""Counter-on-deque detector. Cheap, deterministic, no LLM."""

from __future__ import annotations

from contmemo.core.pattern_detect import PatternDetector, _signal_key


def _ev(**kwargs) -> dict:
    base = {"event": "proposal_processed", "kind": "reject", "reason": "out_of_scope_subtype", "subtype": "lesson"}
    base.update(kwargs)
    return base


# ---------- detect ----------


def test_empty_detect_returns_empty_list() -> None:
    assert PatternDetector().detect() == []


def test_below_threshold_no_pattern() -> None:
    d = PatternDetector(threshold=3)
    d.update(_ev())
    d.update(_ev())
    assert d.detect() == []


def test_at_threshold_pattern_detected() -> None:
    d = PatternDetector(threshold=3)
    for _ in range(3):
        d.update(_ev())
    hits = d.detect()
    assert len(hits) == 1
    assert hits[0]["pattern"] == "recurring_friction"
    assert hits[0]["count"] == 3
    assert hits[0]["signal"] == {
        "kind": "reject",
        "reason": "out_of_scope_subtype",
        "subtype": "lesson",
    }


def test_distinct_signals_dont_combine() -> None:
    d = PatternDetector(threshold=3)
    for _ in range(3):
        d.update(_ev(reason="word_not_in_user_msg", subtype="word"))
    for _ in range(2):
        d.update(_ev(reason="lesson_too_short", subtype="lesson"))
    hits = d.detect()
    assert len(hits) == 1
    assert hits[0]["signal"]["reason"] == "word_not_in_user_msg"


def test_window_slide_drops_old_events() -> None:
    d = PatternDetector(window=5, threshold=3)
    # 3 of one kind, then 5 of another → first three pushed out.
    for _ in range(3):
        d.update(_ev(reason="r1"))
    for _ in range(5):
        d.update(_ev(reason="r2"))
    hits = d.detect()
    reasons = {h["signal"]["reason"] for h in hits}
    assert reasons == {"r2"}


def test_accept_events_ignored() -> None:
    d = PatternDetector(threshold=3)
    for _ in range(5):
        d.update(_ev(kind="accept", reason="word_attested_in_user_msg"))
    assert d.detect() == []


def test_pattern_includes_first_and_last_seen_ts() -> None:
    d = PatternDetector(threshold=3)
    for i, ts in enumerate([
        "2026-05-02T12:00:00+00:00",
        "2026-05-02T12:00:01+00:00",
        "2026-05-02T12:00:02+00:00",
    ]):
        d.update(_ev(ts=ts, i=i))
    hit = d.detect()[0]
    assert hit["first_seen_ts"] == "2026-05-02T12:00:00+00:00"
    assert hit["last_seen_ts"] == "2026-05-02T12:00:02+00:00"


def test_window_size_respected() -> None:
    d = PatternDetector(window=10, threshold=2)
    for _ in range(50):
        d.update(_ev())
    assert len(d._events) == 10


# ---------- signal_key ----------


def test_signal_key_for_proposal_processed() -> None:
    assert _signal_key(_ev(kind="reject", reason="r", subtype="word")) == ("reject", "r", "word")
    assert _signal_key(_ev(kind="defer", reason="r", subtype="lesson")) == ("defer", "r", "lesson")
    # accept / duplicate / malformed → no signal
    assert _signal_key(_ev(kind="accept", reason="r", subtype="word")) is None
    assert _signal_key(_ev(kind="duplicate", reason="r", subtype="word")) is None
    assert _signal_key(_ev(kind="malformed", reason="r", subtype="word")) is None


def test_signal_key_for_memory_write_attempt() -> None:
    ev = {"event": "memory_write_attempt", "kind": "skipped", "reason": "duplicate_memory_id"}
    assert _signal_key(ev) == ("skipped", "duplicate_memory_id", None)
    # Other event types → None
    assert _signal_key({"event": "memory_written", "kind": "written", "reason": "appended"}) is None
    assert _signal_key({"event": "pattern_detected"}) is None
