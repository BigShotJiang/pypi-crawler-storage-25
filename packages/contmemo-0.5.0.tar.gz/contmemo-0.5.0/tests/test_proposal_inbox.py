# v1 | 2026-05-02 | M3 proposal inbox tests
"""Deterministic accept/reject pipeline. No LLM, no network."""

from __future__ import annotations

import json
import threading
import time
from pathlib import Path
from typing import Callable

import pytest

from contmemo.core.event_log import EventLog
from contmemo.core.proposal_inbox import Decision, ProposalInbox


def _drop_to_inbox(inbox_dir: Path, proposal: dict, name: str | None = None) -> Path:
    inbox_dir.mkdir(parents=True, exist_ok=True)
    name = name or f"{proposal['ts'].replace(':', '-')}_{proposal['subtype']}_{proposal['proposal_id']}.json"
    p = inbox_dir / name
    p.write_text(json.dumps(proposal, ensure_ascii=False), encoding="utf-8")
    return p


# ---------- schema & parse ----------


def test_valid_proposal_no_schema_error(inbox: ProposalInbox, make_proposal: Callable, tmp_inbox: Path) -> None:
    src = _drop_to_inbox(tmp_inbox, make_proposal())
    d = inbox.process(json.loads(src.read_text()), src)
    assert d.kind != "malformed"


def test_missing_required_field_quarantines(inbox: ProposalInbox, make_proposal: Callable, tmp_inbox: Path) -> None:
    p = make_proposal()
    p.pop("session_id")
    src = _drop_to_inbox(tmp_inbox, p)
    d = inbox.process(p, src)
    assert d.kind == "malformed"
    assert d.reason == "schema_violation"
    assert d.final_path is not None and "quarantine" in str(d.final_path)


def test_malformed_json_quarantines(inbox: ProposalInbox, tmp_inbox: Path) -> None:
    src = tmp_inbox / "broken.json"
    tmp_inbox.mkdir(parents=True, exist_ok=True)
    src.write_text("{not valid json", encoding="utf-8")
    d = inbox.process(None, src)
    assert d.kind == "malformed"
    assert d.reason == "json_decode_error"
    assert "quarantine" in str(d.final_path)


def test_unknown_top_level_type_rejects(inbox: ProposalInbox, make_proposal: Callable, tmp_inbox: Path) -> None:
    p = make_proposal(type="recipe_call")
    src = _drop_to_inbox(tmp_inbox, p)
    d = inbox.process(p, src)
    assert d.kind == "reject"
    assert d.reason == "out_of_scope_type"


def test_unknown_subtype_rejects_out_of_scope(inbox: ProposalInbox, make_proposal: Callable, tmp_inbox: Path) -> None:
    p = make_proposal(subtype="emotion", content={"text": "feeling cheerful"})
    src = _drop_to_inbox(tmp_inbox, p)
    d = inbox.process(p, src)
    assert d.kind == "reject"
    assert d.reason == "out_of_scope_subtype"


def test_recipe_subtype_rejects_out_of_scope_recipe(inbox: ProposalInbox, make_proposal: Callable, tmp_inbox: Path) -> None:
    p = make_proposal(subtype="recipe_proposal", content={"name": "auth-flow"})
    src = _drop_to_inbox(tmp_inbox, p)
    d = inbox.process(p, src)
    assert d.kind == "reject"
    assert d.reason == "out_of_scope_recipe"


# ---------- subtype = word ----------


def test_word_accept_when_user_taught_it_verbatim(inbox: ProposalInbox, make_proposal: Callable, tmp_inbox: Path) -> None:
    p = make_proposal(content={"word": "stigmergy"}, user_message="stigmergy diye bir kavram var")
    src = _drop_to_inbox(tmp_inbox, p)
    d = inbox.process(p, src)
    assert d.kind == "accept"
    assert d.reason == "word_attested_in_user_msg"


def test_word_accept_case_insensitive(inbox: ProposalInbox, make_proposal: Callable, tmp_inbox: Path) -> None:
    p = make_proposal(content={"word": "Stigmergy"}, user_message="sana STIGMERGY öğreteyim")
    src = _drop_to_inbox(tmp_inbox, p)
    d = inbox.process(p, src)
    assert d.kind == "accept"


def test_word_reject_when_word_absent_from_user_msg(inbox: ProposalInbox, make_proposal: Callable, tmp_inbox: Path) -> None:
    p = make_proposal(content={"word": "stigmergy"}, user_message="bana bir şey anlat")
    src = _drop_to_inbox(tmp_inbox, p)
    d = inbox.process(p, src)
    assert d.kind == "reject"
    assert d.reason == "word_not_in_user_msg"


def test_word_word_boundary_no_substring_match(inbox: ProposalInbox, make_proposal: Callable, tmp_inbox: Path) -> None:
    # "kalem" must not match inside "kalemler".
    p = make_proposal(content={"word": "kalem"}, user_message="masada kalemler var")
    src = _drop_to_inbox(tmp_inbox, p)
    d = inbox.process(p, src)
    assert d.kind == "reject"
    assert d.reason == "word_not_in_user_msg"


# ---------- subtype = forget ----------


def test_forget_accept_with_imperative(inbox: ProposalInbox, make_proposal: Callable, tmp_inbox: Path) -> None:
    p = make_proposal(subtype="forget", content={"target": "old_lesson_42"}, user_message="şunu unut artık")
    src = _drop_to_inbox(tmp_inbox, p)
    d = inbox.process(p, src)
    assert d.kind == "accept"
    assert d.reason == "forget_imperative_attested"


def test_forget_defer_when_no_evidence(inbox: ProposalInbox, make_proposal: Callable, tmp_inbox: Path) -> None:
    p = make_proposal(subtype="forget", content={"target": "x"}, user_message="bilmiyorum nasıl olduğunu")
    src = _drop_to_inbox(tmp_inbox, p)
    d = inbox.process(p, src)
    assert d.kind == "defer"
    assert d.reason == "forget_evidence_unclear"


def test_forget_negative_doesnt_trigger_accept(inbox: ProposalInbox, make_proposal: Callable, tmp_inbox: Path) -> None:
    p = make_proposal(subtype="forget", content={"target": "x"}, user_message="sakın unutma bunu")
    src = _drop_to_inbox(tmp_inbox, p)
    d = inbox.process(p, src)
    assert d.kind == "defer"


# ---------- subtype = lesson ----------


def test_lesson_reject_too_short(inbox: ProposalInbox, make_proposal: Callable, tmp_inbox: Path) -> None:
    p = make_proposal(subtype="lesson", content={"text": "ok"}, user_message="")
    src = _drop_to_inbox(tmp_inbox, p)
    d = inbox.process(p, src)
    assert d.kind == "reject"
    assert d.reason == "lesson_too_short"


def test_lesson_reject_too_long(inbox: ProposalInbox, make_proposal: Callable, tmp_inbox: Path) -> None:
    p = make_proposal(subtype="lesson", content={"text": "a" * 3000}, user_message="")
    src = _drop_to_inbox(tmp_inbox, p)
    d = inbox.process(p, src)
    assert d.kind == "reject"
    assert d.reason == "lesson_too_long"


def test_lesson_reject_generic_platitude(inbox: ProposalInbox, make_proposal: Callable, tmp_inbox: Path) -> None:
    p = make_proposal(subtype="lesson", content={"text": "Always sanitize all user input."}, user_message="")
    src = _drop_to_inbox(tmp_inbox, p)
    d = inbox.process(p, src)
    assert d.kind == "reject"
    assert d.reason == "lesson_generic_platitude"


def test_lesson_reject_priming_repeat(
    tmp_inbox: Path, tmp_processed: Path, event_log: EventLog, make_proposal: Callable
) -> None:
    inbox = ProposalInbox(tmp_inbox, tmp_processed, event_log=event_log)
    text = "Database migrations should run inside an explicit transaction block."
    # Pre-seed event log with 5 prior decisions sharing the same content_hash.
    p_seed = make_proposal(subtype="lesson", content={"text": text}, user_message="")
    src_seed = _drop_to_inbox(tmp_inbox, p_seed, name="seed.json")
    seed_decision = inbox.process(p_seed, src_seed)
    seed_hash = seed_decision.content_hash
    assert seed_hash is not None
    for i in range(4):
        event_log.append({
            "event":        "proposal_processed",
            "proposal_id":  f"prior-{i}",
            "kind":         "defer",
            "reason":       "lesson_needs_llm_review",
            "subtype":      "lesson",
            "content_hash": seed_hash,
        })
    p = make_proposal(subtype="lesson", content={"text": text}, user_message="")
    src = _drop_to_inbox(tmp_inbox, p)
    d = inbox.process(p, src)
    assert d.kind == "reject"
    assert d.reason == "lesson_priming_repeat"


def test_lesson_defer_when_passes_checks(inbox: ProposalInbox, make_proposal: Callable, tmp_inbox: Path) -> None:
    p = make_proposal(
        subtype="lesson",
        content={"text": "Cont log lines longer than 4 KiB get split mid-record under flock contention."},
        user_message="",
    )
    src = _drop_to_inbox(tmp_inbox, p)
    d = inbox.process(p, src)
    assert d.kind == "defer"
    assert d.reason == "lesson_needs_llm_review"


# ---------- subtype = fact ----------


def test_fact_defer_when_passes_checks(inbox: ProposalInbox, make_proposal: Callable, tmp_inbox: Path) -> None:
    p = make_proposal(
        subtype="fact",
        content={"text": "Sertan's primary timezone is Europe/Istanbul."},
        user_message="",
    )
    src = _drop_to_inbox(tmp_inbox, p)
    d = inbox.process(p, src)
    assert d.kind == "defer"
    assert d.reason == "fact_needs_llm_review"


def test_fact_reject_too_short(inbox: ProposalInbox, make_proposal: Callable, tmp_inbox: Path) -> None:
    p = make_proposal(subtype="fact", content={"text": "yes"}, user_message="")
    src = _drop_to_inbox(tmp_inbox, p)
    d = inbox.process(p, src)
    assert d.kind == "reject"
    assert d.reason == "fact_too_short"


# ---------- idempotency ----------


def test_duplicate_proposal_id_returns_duplicate(inbox: ProposalInbox, make_proposal: Callable, tmp_inbox: Path) -> None:
    p = make_proposal(content={"word": "stigmergy"}, user_message="stigmergy")
    src1 = _drop_to_inbox(tmp_inbox, p, name="first.json")
    inbox.process(p, src1)

    src2 = _drop_to_inbox(tmp_inbox, p, name="second.json")
    d2 = inbox.process(p, src2)
    assert d2.kind == "duplicate"
    assert d2.reason == "proposal_id_seen"


# ---------- filesystem ----------


@pytest.mark.parametrize(
    "kind_setup,expected_dir",
    [
        ("accept",    "accepted"),
        ("reject",    "rejected"),
        ("defer",     "deferred"),
        ("malformed", "quarantine"),
    ],
)
def test_processed_files_moved_to_correct_subdir(
    kind_setup: str, expected_dir: str,
    inbox: ProposalInbox, make_proposal: Callable, tmp_inbox: Path,
) -> None:
    if kind_setup == "accept":
        p = make_proposal(content={"word": "stigmergy"}, user_message="stigmergy var")
    elif kind_setup == "reject":
        p = make_proposal(subtype="lesson", content={"text": "ok"}, user_message="")
    elif kind_setup == "defer":
        p = make_proposal(subtype="forget", content={"target": "x"}, user_message="bilmiyorum")
    else:  # malformed
        p = make_proposal()
        p.pop("ts")
    src = _drop_to_inbox(tmp_inbox, p, name=f"{kind_setup}.json")
    d = inbox.process(p if kind_setup != "malformed" or "ts" not in p else p, src)
    # Accept/reject/defer/malformed all move the file.
    assert d.final_path is not None
    assert expected_dir in str(d.final_path)
    assert d.final_path.exists()
    assert not src.exists()


def test_atomic_move_collision_avoided(inbox: ProposalInbox, make_proposal: Callable, tmp_inbox: Path, tmp_processed: Path) -> None:
    p = make_proposal(content={"word": "stigmergy"}, user_message="stigmergy")
    src1 = _drop_to_inbox(tmp_inbox, p, name="dup.json")
    inbox.process(p, src1)
    # Manually pre-create a colliding file in the target dir, then process a
    # second proposal whose source path has the same basename.
    p2 = make_proposal(content={"word": "stigmergy"}, user_message="stigmergy gene")
    src2 = _drop_to_inbox(tmp_inbox, p2, name="dup.json")
    d2 = inbox.process(p2, src2)
    assert d2.final_path is not None
    assert d2.final_path.exists()
    assert "collision" in d2.final_path.name
    assert not src2.exists()


def test_inbox_subdirs_created_on_init(tmp_path: Path) -> None:
    ProposalInbox(tmp_path / "in", tmp_path / "out")
    for sub in ("accepted", "rejected", "deferred", "quarantine"):
        assert (tmp_path / "out" / sub).is_dir()
    assert (tmp_path / "in").is_dir()


# ---------- event log integration ----------


def test_decision_recorded_in_event_log(
    inbox: ProposalInbox, event_log: EventLog, make_proposal: Callable, tmp_inbox: Path,
) -> None:
    p = make_proposal(content={"word": "stigmergy"}, user_message="stigmergy")
    src = _drop_to_inbox(tmp_inbox, p)
    inbox.process(p, src)
    events = list(event_log.query(event_type="proposal_processed"))
    assert len(events) == 1
    assert events[0]["proposal_id"] == p["proposal_id"]
    assert events[0]["kind"] == "accept"


def test_event_payload_includes_required_fields(
    inbox: ProposalInbox, event_log: EventLog, make_proposal: Callable, tmp_inbox: Path,
) -> None:
    p = make_proposal(content={"word": "stigmergy"}, user_message="stigmergy")
    src = _drop_to_inbox(tmp_inbox, p)
    inbox.process(p, src)
    ev = next(event_log.query(event_type="proposal_processed"))
    for field in ("proposal_id", "kind", "reason", "subtype", "content_hash", "source_path", "final_path", "ts"):
        assert field in ev


# ---------- watch loop ----------


def test_watch_yields_decisions_for_new_files(inbox: ProposalInbox, make_proposal: Callable, tmp_inbox: Path) -> None:
    p = make_proposal(content={"word": "stigmergy"}, user_message="stigmergy")
    _drop_to_inbox(tmp_inbox, p)
    it = inbox.watch(poll_interval_s=0.01)
    decision = next(it)
    assert decision.proposal_id == p["proposal_id"]
    assert decision.kind == "accept"


def test_watch_skips_already_processed(inbox: ProposalInbox, make_proposal: Callable, tmp_inbox: Path) -> None:
    p1 = make_proposal(content={"word": "stigmergy"}, user_message="stigmergy")
    _drop_to_inbox(tmp_inbox, p1, name="first.json")
    it = inbox.watch(poll_interval_s=0.01)
    d1 = next(it)
    assert d1.proposal_id == p1["proposal_id"]
    p2 = make_proposal(content={"word": "kalem"}, user_message="kalem var")
    _drop_to_inbox(tmp_inbox, p2, name="second.json")
    # Pull the next decision in a thread so we can fail fast if the loop
    # mistakenly re-yields the moved file.
    box: list[Decision] = []
    th = threading.Thread(target=lambda: box.append(next(it)), daemon=True)
    th.start()
    th.join(timeout=1.0)
    assert box and box[0].proposal_id == p2["proposal_id"]
    assert box[0].proposal_id != p1["proposal_id"]
