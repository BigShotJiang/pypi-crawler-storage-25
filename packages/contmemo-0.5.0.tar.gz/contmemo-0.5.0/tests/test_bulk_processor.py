# v1 | 2026-05-02 | M6 bulk processor tests
"""BulkProcessor with a scripted fake LLM. No network."""

from __future__ import annotations

import json
import os
import time
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Callable

import pytest

from contmemo.core.bulk_processor import (
    BulkProcessor,
    parse_llm_json,
    parse_since,
    _prompt_hash,
)
from contmemo.core.event_log import EventLog
from contmemo.core.memory_writer import MemoryWriter
from contmemo.core.proposal_inbox import ProposalInbox


class FakeLLM:
    """Scripted responses; matches the LLMClient Protocol shape."""
    def __init__(self, scripted: list[str], available: bool = True):
        self._responses = list(scripted)
        self._available = available
        self.calls: list[str] = []
    def available(self) -> bool:
        return self._available
    def complete(self, prompt: str, *, max_tokens: int = 512) -> str:
        self.calls.append(prompt)
        if not self._responses:
            raise RuntimeError("FakeLLM: no scripted response")
        return self._responses.pop(0)


@pytest.fixture
def bulk_env(tmp_path: Path):
    inbox_dir = tmp_path / "inbox"
    processed_dir = tmp_path / "processed"
    deferred_dir = processed_dir / "deferred"
    memory_path = tmp_path / "memory.jsonl"
    backup_dir = tmp_path / ".backups"
    log_path = tmp_path / "events.jsonl"

    event_log = EventLog(log_path)
    inbox = ProposalInbox(inbox_dir, processed_dir, event_log=event_log)
    writer = MemoryWriter(memory_path, backup_dir=backup_dir, event_log=event_log)

    return {
        "inbox":         inbox,
        "writer":        writer,
        "event_log":     event_log,
        "deferred_dir":  deferred_dir,
        "processed_dir": processed_dir,
        "memory_path":   memory_path,
    }


def _proposal(subtype: str = "lesson", text: str = "Sample lesson body present here for tests.", **overrides) -> dict:
    pid = overrides.pop("proposal_id", f"prop-{uuid.uuid4().hex[:8]}")
    base = {
        "proposal_id":  pid,
        "from":         "cont",
        "session_id":   "sess",
        "turn_id":      "t",
        "type":         "memory_write",
        "subtype":      subtype,
        "content":      {"text": text},
        "user_message": "",
        "ts":           "2026-05-02T12:00:00+00:00",
    }
    base.update(overrides)
    return base


def _drop_deferred(deferred_dir: Path, proposal: dict, name: str | None = None) -> Path:
    deferred_dir.mkdir(parents=True, exist_ok=True)
    nm = name or f"{proposal['proposal_id']}.json"
    p = deferred_dir / nm
    p.write_text(json.dumps(proposal, ensure_ascii=False), encoding="utf-8")
    return p


def _make_bp(env, llm, **cfg) -> BulkProcessor:
    base_cfg = {"pattern_summary_cooldown_s": 86400}
    base_cfg.update(cfg)
    return BulkProcessor(
        llm=llm,
        event_log=env["event_log"],
        writer=env["writer"],
        inbox=env["inbox"],
        deferred_dir=env["deferred_dir"],
        processed_dir=env["processed_dir"],
        memory_path=env["memory_path"],
        config=base_cfg,
    )


# ---------- helpers ----------


def test_parse_llm_json_strips_code_fence() -> None:
    raw = '```json\n{"decision": "accept", "reason_tag": "ok"}\n```'
    obj = parse_llm_json(raw, schema={"required": ["decision"], "types": {"decision": str}})
    assert obj == {"decision": "accept", "reason_tag": "ok"}


def test_parse_llm_json_missing_required_raises() -> None:
    with pytest.raises(ValueError):
        parse_llm_json('{"reason_tag": "x"}', schema={"required": ["decision"]})


def test_parse_since_relative() -> None:
    now = datetime.now(timezone.utc)
    five_min_ago = parse_since("5 minutes ago")
    assert five_min_ago is not None
    assert (now - five_min_ago).total_seconds() == pytest.approx(300, abs=2)
    assert parse_since("yesterday") < now
    assert parse_since(None) is None
    assert parse_since("garbage input") is None


# ---------- process_deferred ----------


def test_no_deferred_files_returns_zero_counts(bulk_env) -> None:
    bp = _make_bp(bulk_env, FakeLLM([]))
    out = bp.process_deferred()
    assert out == {
        "deferred_processed": 0, "deferred_accepted": 0,
        "deferred_rejected": 0,  "deferred_skipped": 0,
    }


def test_processes_deferred_lesson_accept(bulk_env) -> None:
    _drop_deferred(bulk_env["deferred_dir"], _proposal())
    llm = FakeLLM(['{"decision": "accept", "reason_tag": "specific_and_useful", "rationale": "ok"}'])
    bp = _make_bp(bulk_env, llm)
    out = bp.process_deferred()
    assert out["deferred_processed"] == 1
    assert out["deferred_accepted"] == 1
    assert (bulk_env["processed_dir"] / "accepted").iterdir()
    rows = [json.loads(l) for l in bulk_env["memory_path"].read_text().splitlines() if l.strip()]
    assert len(rows) == 1


def test_processes_deferred_lesson_reject(bulk_env) -> None:
    _drop_deferred(bulk_env["deferred_dir"], _proposal())
    llm = FakeLLM(['{"decision": "reject", "reason_tag": "duplicate_of_existing"}'])
    bp = _make_bp(bulk_env, llm)
    out = bp.process_deferred()
    assert out["deferred_rejected"] == 1
    assert not bulk_env["memory_path"].exists()


def test_invalid_json_response_falls_back_to_reject(bulk_env) -> None:
    _drop_deferred(bulk_env["deferred_dir"], _proposal())
    llm = FakeLLM(["this is not json at all"])
    bp = _make_bp(bulk_env, llm)
    out = bp.process_deferred()
    assert out["deferred_rejected"] == 1


def test_missing_decision_key_falls_back_to_reject(bulk_env) -> None:
    _drop_deferred(bulk_env["deferred_dir"], _proposal())
    llm = FakeLLM(['{"reason_tag": "no_decision_field"}'])
    bp = _make_bp(bulk_env, llm)
    out = bp.process_deferred()
    assert out["deferred_rejected"] == 1


def test_dry_run_does_not_call_writer(bulk_env) -> None:
    _drop_deferred(bulk_env["deferred_dir"], _proposal())
    llm = FakeLLM(['{"decision": "accept", "reason_tag": "ok"}'])
    bp = _make_bp(bulk_env, llm)
    bp.process_deferred(dry_run=True)
    assert not bulk_env["memory_path"].exists()


def test_dry_run_does_not_move_files(bulk_env) -> None:
    src = _drop_deferred(bulk_env["deferred_dir"], _proposal())
    llm = FakeLLM(['{"decision": "accept", "reason_tag": "ok"}'])
    bp = _make_bp(bulk_env, llm)
    bp.process_deferred(dry_run=True)
    assert src.exists()


def test_max_items_respected(bulk_env) -> None:
    for i in range(5):
        _drop_deferred(bulk_env["deferred_dir"], _proposal(text=f"unique body number {i} ok"), name=f"d{i}.json")
    llm = FakeLLM(['{"decision": "reject", "reason_tag": "x"}'] * 10)
    bp = _make_bp(bulk_env, llm)
    out = bp.process_deferred(max_items=2)
    assert out["deferred_processed"] == 2
    assert len(llm.calls) == 2


def test_since_filter_excludes_old_files(bulk_env) -> None:
    old = _drop_deferred(bulk_env["deferred_dir"], _proposal(text="old body content here"), name="old.json")
    # Backdate the old file by 2 hours.
    two_hours_ago = time.time() - 7200
    os.utime(old, (two_hours_ago, two_hours_ago))
    fresh = _drop_deferred(bulk_env["deferred_dir"], _proposal(text="fresh body content here"), name="fresh.json")
    llm = FakeLLM(['{"decision": "reject", "reason_tag": "x"}'])
    bp = _make_bp(bulk_env, llm)
    cutoff = datetime.now(timezone.utc) - timedelta(minutes=30)
    out = bp.process_deferred(since=cutoff)
    assert out["deferred_processed"] == 1
    assert len(llm.calls) == 1


def test_paranoia_redet_runs_m3_check_first(bulk_env) -> None:
    """An M3-rule-violating proposal in deferred (e.g. file moved by hand)
    must be rejected without paying for an LLM call."""
    bad = _proposal(text="ok")  # too short → M3 rejects
    _drop_deferred(bulk_env["deferred_dir"], bad)
    llm = FakeLLM([])  # would raise if called
    bp = _make_bp(bulk_env, llm)
    out = bp.process_deferred()
    assert out["deferred_rejected"] == 1
    assert llm.calls == []


# ---------- summarize_patterns ----------


def test_pattern_summarize_emits_event(bulk_env) -> None:
    bulk_env["event_log"].append({
        "event":   "pattern_detected",
        "pattern": "recurring_friction",
        "signal":  {"kind": "reject", "reason": "lesson_too_short", "subtype": "lesson"},
        "count":   3,
        "first_seen_ts": "2026-05-02T11:00:00+00:00",
        "last_seen_ts":  "2026-05-02T11:30:00+00:00",
    })
    llm = FakeLLM([
        '{"summary": "Sürtüşme tekrar ediyor.", "severity": "medium", "tags": ["lesson", "short"]}'
    ])
    bp = _make_bp(bulk_env, llm)
    out = bp.summarize_patterns()
    assert out["patterns_summarized"] == 1
    summaries = list(bulk_env["event_log"].query(event_type="pattern_summarized"))
    assert len(summaries) == 1
    assert summaries[0]["summary"]["severity"] == "medium"


def test_pattern_summarize_respects_cooldown(bulk_env) -> None:
    signal = {"kind": "reject", "reason": "lesson_too_short", "subtype": "lesson"}
    bulk_env["event_log"].append({
        "event": "pattern_detected", "signal": signal, "count": 3,
        "first_seen_ts": "2026-05-02T10:00:00+00:00", "last_seen_ts": "2026-05-02T10:30:00+00:00",
    })
    bulk_env["event_log"].append({
        "event": "pattern_summarized", "signal": signal, "status": "ok",
        "summary": {"summary": "old", "severity": "low", "tags": []},
    })
    llm = FakeLLM([])  # raises if called
    bp = _make_bp(bulk_env, llm)
    out = bp.summarize_patterns()
    assert out["patterns_summarized"] == 0
    assert llm.calls == []


# ---------- audit ----------


def test_event_log_records_each_evaluation(bulk_env) -> None:
    _drop_deferred(bulk_env["deferred_dir"], _proposal())
    llm = FakeLLM(['{"decision": "accept", "reason_tag": "ok"}'])
    bp = _make_bp(bulk_env, llm)
    bp.process_deferred()
    evals = list(bulk_env["event_log"].query(event_type="llm_evaluation"))
    assert len(evals) == 1
    assert evals[0]["decision_kind"] == "accept"


def test_event_log_records_prompt_hash_not_full_prompt(bulk_env) -> None:
    proposal = _proposal()
    _drop_deferred(bulk_env["deferred_dir"], proposal)
    llm = FakeLLM(['{"decision": "accept", "reason_tag": "ok"}'])
    bp = _make_bp(bulk_env, llm)
    bp.process_deferred()
    ev = next(bulk_env["event_log"].query(event_type="llm_evaluation"))
    assert isinstance(ev["prompt_hash"], str)
    assert len(ev["prompt_hash"]) == 16
    # The hash should match what _prompt_hash produces on the same prompt.
    assert ev["prompt_hash"] == _prompt_hash(llm.calls[0])
    # Full prompt is NOT in the event payload.
    full_prompt = llm.calls[0]
    assert full_prompt not in json.dumps(ev, ensure_ascii=False)
