# v1 | 2026-05-02 | M4 memory writer tests
"""Single-writer pipeline. flock + tmp/rename + fsync + one-rotation backup.

The single-writer invariant is what makes contmemo the "tek hâkim" of
Cont memory; these tests are the disk-level proof. Anything that drifts
from atomic / locked / restorable behavior shows up here.
"""

from __future__ import annotations

import fcntl
import json
import os
import threading
from pathlib import Path
from typing import Callable

import pytest

from contmemo.core import memory_writer as mw
from contmemo.core.event_log import EventLog
from contmemo.core.memory_writer import MemoryWriter, WriteResult, _canonical_hash


def _read_lines(p: Path) -> list[dict]:
    return [json.loads(line) for line in p.read_text().splitlines() if line.strip()]


# ---------- write: append handler ----------


def test_write_creates_file_when_missing(writer: MemoryWriter, make_decision: Callable, tmp_target: Path) -> None:
    assert not tmp_target.exists()
    result = writer.write(make_decision())
    assert result.kind == "written"
    assert tmp_target.exists()
    assert _read_lines(tmp_target)


def test_write_appends_entry_to_existing_file(writer: MemoryWriter, make_decision: Callable, tmp_target: Path) -> None:
    writer.write(make_decision(text="first lesson body present here"))
    writer.write(make_decision(text="second lesson body present here"))
    rows = _read_lines(tmp_target)
    assert len(rows) == 2


def test_write_skips_non_accept_decisions(writer: MemoryWriter, make_decision: Callable, tmp_target: Path) -> None:
    result = writer.write(make_decision(kind="defer"))
    assert result.kind == "skipped"
    assert result.reason == "not_an_accept"
    assert not tmp_target.exists()


def test_write_returns_failed_on_empty_proposal(writer: MemoryWriter, make_decision: Callable) -> None:
    decision = make_decision()
    bad = {**decision.to_dict(), "proposal": None}
    result = writer.write(bad)
    assert result.kind == "failed"
    assert result.reason == "empty_proposal"


def test_write_skips_duplicate_memory_id(writer: MemoryWriter, make_decision: Callable, tmp_target: Path) -> None:
    writer.write(make_decision(text="identical body identical body"))
    result = writer.write(make_decision(text="identical body identical body"))
    assert result.kind == "skipped"
    assert result.reason == "duplicate_memory_id"
    assert len(_read_lines(tmp_target)) == 1


def test_write_assigns_deterministic_memory_id(writer: MemoryWriter, make_decision: Callable, tmp_target: Path) -> None:
    writer.write(make_decision(text="assignable body for hashing here"))
    entry = _read_lines(tmp_target)[0]
    expected = f"mem_{_canonical_hash({'text': 'assignable body for hashing here'})[:16]}"
    assert entry["id"] == expected


def test_written_entry_has_required_fields(writer: MemoryWriter, make_decision: Callable, tmp_target: Path) -> None:
    writer.write(make_decision(text="entry with required fields here ok"))
    entry = _read_lines(tmp_target)[0]
    for field in ("id", "subtype", "content", "added_ts", "source_proposal_id", "session_id"):
        assert field in entry


# ---------- write: forget handler ----------


def _seed_one(writer: MemoryWriter, make_decision: Callable, text: str = "seed entry alpha bravo charlie") -> str:
    writer.write(make_decision(text=text))
    return _read_lines(writer.target_path)[0]["id"]


def test_forget_removes_matching_memory_id(writer: MemoryWriter, make_decision: Callable, tmp_target: Path) -> None:
    mem_id = _seed_one(writer, make_decision)
    result = writer.write(make_decision(subtype="forget", value=mem_id))
    assert result.kind == "written"
    assert result.reason == "forgot"
    assert _read_lines(tmp_target) == []


def test_forget_skipped_when_target_not_found(writer: MemoryWriter, make_decision: Callable, tmp_target: Path) -> None:
    _seed_one(writer, make_decision)
    result = writer.write(make_decision(subtype="forget", value="mem_never_seen"))
    assert result.kind == "skipped"
    assert result.reason == "forget_target_not_found"
    assert len(_read_lines(tmp_target)) == 1


def test_forget_failed_on_unsupported_target_type(writer: MemoryWriter, make_decision: Callable) -> None:
    result = writer.write(make_decision(subtype="forget", target="match_pattern", value="mem_.*"))
    assert result.kind == "failed"
    assert result.reason == "forget_target_unsupported"


def test_forget_does_not_touch_other_entries(writer: MemoryWriter, make_decision: Callable, tmp_target: Path) -> None:
    keep_id = _seed_one(writer, make_decision, text="entry that must survive forgetting")
    # Add a second seed we will forget.
    writer.write(make_decision(text="entry to be forgotten very soon"))
    rows = _read_lines(tmp_target)
    forget_id = next(r["id"] for r in rows if r["id"] != keep_id)
    writer.write(make_decision(subtype="forget", value=forget_id))
    remaining = _read_lines(tmp_target)
    assert len(remaining) == 1
    assert remaining[0]["id"] == keep_id


# ---------- atomicity ----------


def test_write_uses_tmp_then_rename(writer: MemoryWriter, make_decision: Callable, monkeypatch: pytest.MonkeyPatch) -> None:
    calls: list[tuple[str, str]] = []
    real = mw.os.rename

    def spy(src, dst):
        calls.append((str(src), str(dst)))
        return real(src, dst)

    monkeypatch.setattr(mw.os, "rename", spy)
    writer.write(make_decision(text="rename spy lesson body present"))
    assert any(src.endswith(".tmp") and dst.endswith("memory.jsonl") for src, dst in calls)


def test_no_partial_file_on_simulated_crash(
    writer: MemoryWriter, make_decision: Callable, tmp_target: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    # Pre-existing memory; failed write must leave it unchanged.
    writer.write(make_decision(text="seed lesson body present here only"))
    original = tmp_target.read_text()

    def boom(src, dst):
        raise OSError("simulated disk failure")

    monkeypatch.setattr(mw.os, "rename", boom)
    result = writer.write(make_decision(text="write that will be torn mid-flight"))
    assert result.kind == "failed"
    assert result.reason.startswith("atomic_swap_failed")
    assert tmp_target.read_text() == original


def test_concurrent_writes_serialize(writer: MemoryWriter, make_decision: Callable, tmp_target: Path) -> None:
    n_threads, per_thread = 5, 10

    def worker(tid: int) -> None:
        for k in range(per_thread):
            writer.write(make_decision(text=f"thread-{tid}-entry-{k} body content"))

    threads = [threading.Thread(target=worker, args=(t,)) for t in range(n_threads)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    rows = _read_lines(tmp_target)
    assert len(rows) == n_threads * per_thread
    ids = {r["id"] for r in rows}
    assert len(ids) == n_threads * per_thread


# ---------- backup & rollback ----------


def test_backup_created_before_overwrite(writer: MemoryWriter, make_decision: Callable, tmp_backup_dir: Path) -> None:
    writer.write(make_decision(text="first body here for backup test"))
    writer.write(make_decision(text="second body distinct enough for hash"))
    assert (tmp_backup_dir / "memory.jsonl").exists()


def test_first_write_no_backup_needed(writer: MemoryWriter, make_decision: Callable, tmp_backup_dir: Path) -> None:
    result = writer.write(make_decision(text="only ever first body present"))
    assert result.kind == "written"
    assert result.backup_path is None
    assert not (tmp_backup_dir / "memory.jsonl").exists()


def test_rollback_restores_previous_version(
    writer: MemoryWriter, make_decision: Callable, tmp_target: Path,
) -> None:
    writer.write(make_decision(text="version-A body distinct hash one"))
    state_a = tmp_target.read_text()
    writer.write(make_decision(text="version-B body distinct hash two"))
    assert tmp_target.read_text() != state_a
    result = writer.rollback()
    assert result.kind == "rolled_back"
    assert tmp_target.read_text() == state_a


def test_rollback_no_op_when_no_backup(writer: MemoryWriter) -> None:
    result = writer.rollback()
    assert result.kind == "no_backup"
    assert result.reason == "nothing_to_restore"


def test_rollback_is_idempotent(writer: MemoryWriter, make_decision: Callable) -> None:
    writer.write(make_decision(text="rollback idempotent body line one"))
    writer.write(make_decision(text="rollback idempotent body line two"))
    first = writer.rollback()
    assert first.kind == "rolled_back"
    # Second rollback overwrites target with same backup (still present, single rotation).
    second = writer.rollback()
    assert second.kind == "rolled_back"


# ---------- event log integration ----------


def test_write_emits_event(writer: MemoryWriter, event_log: EventLog, make_decision: Callable) -> None:
    writer.write(make_decision(text="emits event lesson body present here"))
    events = list(event_log.query(event_type="memory_written"))
    assert len(events) == 1
    assert events[0]["kind"] == "written"


def test_skip_emits_event(writer: MemoryWriter, event_log: EventLog, make_decision: Callable) -> None:
    writer.write(make_decision(kind="defer"))
    events = list(event_log.query(event_type="memory_write_attempt"))
    assert len(events) == 1
    assert events[0]["kind"] == "skipped"


def test_rollback_emits_event(writer: MemoryWriter, event_log: EventLog, make_decision: Callable) -> None:
    writer.write(make_decision(text="rollback emits body line one here"))
    writer.write(make_decision(text="rollback emits body line two here"))
    writer.rollback()
    events = list(event_log.query(event_type="memory_rolled_back"))
    assert len(events) == 1
    assert events[0]["kind"] == "rolled_back"


def test_event_includes_proposal_id(writer: MemoryWriter, event_log: EventLog, make_decision: Callable) -> None:
    decision = make_decision(text="event includes proposal id body here")
    writer.write(decision)
    ev = next(event_log.query(event_type="memory_written"))
    assert ev["proposal_id"] == decision.proposal_id


# ---------- lock ----------


def test_lock_file_created_and_released(writer: MemoryWriter, make_decision: Callable) -> None:
    writer.write(make_decision(text="lock lifecycle body present here ok"))
    assert writer.lock_path.exists()
    fd = os.open(str(writer.lock_path), os.O_RDWR)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        fcntl.flock(fd, fcntl.LOCK_UN)
    finally:
        os.close(fd)


def test_lock_file_path_uses_suffix(tmp_path: Path) -> None:
    w = MemoryWriter(tmp_path / "memory.jsonl")
    assert w.lock_path == tmp_path / "memory.lock"


# ---------- fsync ----------


def test_directory_fsync_called(
    writer: MemoryWriter, make_decision: Callable, monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[Path] = []
    real = mw._fsync_dir

    def spy(path: Path) -> None:
        calls.append(path)
        real(path)

    monkeypatch.setattr(mw, "_fsync_dir", spy)
    writer.write(make_decision(text="dir fsync body present here ok"))
    assert any(str(p).endswith(str(writer.target_path.parent)) for p in calls)
