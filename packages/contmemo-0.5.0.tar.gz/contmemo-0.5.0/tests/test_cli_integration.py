# v1 | 2026-05-02 | M5 CLI integration tests
"""--watch and --report through the real argparse entrypoint.

Subprocess testing is fragile and slow; instead we drive ``main(argv)``
in-process with a tmp config TOML so the runtime points at tmp paths.
"""

from __future__ import annotations

import json
import uuid
from pathlib import Path

import pytest

from contmemo.__main__ import main


def _write_config(tmp_path: Path) -> Path:
    cfg = tmp_path / "config.toml"
    inbox = (tmp_path / "inbox").as_posix()
    processed = (tmp_path / "processed").as_posix()
    memory = (tmp_path / "memory.jsonl").as_posix()
    backups = (tmp_path / ".backups").as_posix()
    log = (tmp_path / "events.jsonl").as_posix()
    cfg.write_text(f"""
[paths]
proposals_inbox     = "{inbox}"
processed_proposals = "{processed}"
memory_path         = "{memory}"
memory_backup_dir   = "{backups}"
event_log           = "{log}"

[runtime]
poll_interval_s = 0.01

[detector]
window                  = 20
threshold               = 3
pattern_emit_cooldown_s = 60
""", encoding="utf-8")
    return cfg


def _drop(inbox_dir: Path, *, subtype: str = "word", word: str = "stigmergy", text: str = "msg") -> None:
    inbox_dir.mkdir(parents=True, exist_ok=True)
    pid = f"prop-{uuid.uuid4().hex[:8]}"
    if subtype == "word":
        content = {"word": word}
        user_message = f"{word} diye"
    else:
        content = {"text": text}
        user_message = ""
    proposal = {
        "proposal_id":  pid,
        "from":         "cont",
        "session_id":   "sess",
        "turn_id":      "t",
        "type":         "memory_write",
        "subtype":      subtype,
        "content":      content,
        "user_message": user_message,
        "ts":           "2026-05-02T12:00:00+00:00",
    }
    (inbox_dir / f"{pid}.json").write_text(json.dumps(proposal), encoding="utf-8")


# ---------- --watch ----------


def test_watch_runs_and_processes(tmp_path: Path, capsys: pytest.CaptureFixture) -> None:
    cfg = _write_config(tmp_path)
    _drop(tmp_path / "inbox")
    _drop(tmp_path / "inbox")
    rc = main(["--watch", "--config", str(cfg), "--max-iterations", "1"])
    assert rc == 0
    err = capsys.readouterr().err
    assert "processed 2" in err
    assert (tmp_path / "memory.jsonl").exists()


def test_watch_max_iterations_zero_inbox(tmp_path: Path, capsys: pytest.CaptureFixture) -> None:
    cfg = _write_config(tmp_path)
    rc = main(["--watch", "--config", str(cfg), "--max-iterations", "1"])
    assert rc == 0
    err = capsys.readouterr().err
    assert "processed 0" in err


# ---------- --report ----------


def test_report_dumps_recent_events(tmp_path: Path, capsys: pytest.CaptureFixture) -> None:
    cfg = _write_config(tmp_path)
    _drop(tmp_path / "inbox")
    main(["--watch", "--config", str(cfg), "--max-iterations", "1"])
    capsys.readouterr()  # discard --watch stderr

    rc = main(["--report", "--config", str(cfg), "--last", "10"])
    assert rc == 0
    out = capsys.readouterr().out
    lines = [json.loads(l) for l in out.splitlines() if l.strip()]
    assert lines
    event_names = {ev.get("event") for ev in lines}
    assert "proposal_processed" in event_names
