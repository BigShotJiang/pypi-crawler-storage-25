# v2 | 2026-05-03 | structural / contract tests; recipe prompt removed (out of scope)
"""Structural tests — every planned core module exposes its named class.

These are intentionally trivial. Their job is to fail loudly the moment a
later sprint deletes a module or renames a public class without coming
back here to update the contract. Cheap insurance against silent drift.
"""

import importlib
import inspect

import pytest

CORE_CONTRACT = [
    ("contmemo.core.runtime",        "Runtime"),
    ("contmemo.core.proposal_inbox", "ProposalInbox"),
    ("contmemo.core.event_log",      "EventLog"),
    ("contmemo.core.pattern_detect", "PatternDetector"),
    ("contmemo.core.llm_client",     "LLMClient"),
    ("contmemo.core.memory_writer",  "MemoryWriter"),
]


@pytest.mark.parametrize("module_name,class_name", CORE_CONTRACT)
def test_module_exposes_named_class(module_name, class_name):
    module = importlib.import_module(module_name)
    assert hasattr(module, class_name), (
        f"{module_name} is missing {class_name} — sprint contract broken."
    )
    obj = getattr(module, class_name)
    # Must be a class (or a Protocol, which is also a class at runtime).
    assert inspect.isclass(obj), f"{module_name}.{class_name} is not a class"


def test_prompts_present():
    """Prompt placeholders ship with the package; bodies fill in M6.

    Per brief v2 the recipe-sanity prompt is **not** part of contmemo —
    that work belongs to the sibling agent contrecipe.
    """
    from importlib import resources
    expected = {"failure_analysis.txt", "memory_evaluation.txt"}
    found = {
        p.name
        for p in resources.files("contmemo.prompts").iterdir()
        if p.name.endswith(".txt")
    }
    assert expected <= found, f"missing prompt placeholders: {expected - found}"
    # And recipe_sanity.txt must NOT have crept back in.
    assert "recipe_sanity.txt" not in found, (
        "recipe_sanity.txt is out of scope for contmemo (brief v2). "
        "Recipe prompts belong in the contrecipe package."
    )


def test_default_config_present():
    from importlib import resources
    cfg = resources.files("contmemo.config") / "default.toml"
    assert cfg.is_file(), "config/default.toml missing from package data"
    text = cfg.read_text(encoding="utf-8")
    # Sanity: a few section headers we promise to keep stable.
    for section in ("[paths]", "[runtime]", "[llm]", "[hook]"):
        assert section in text, f"default.toml missing {section}"
