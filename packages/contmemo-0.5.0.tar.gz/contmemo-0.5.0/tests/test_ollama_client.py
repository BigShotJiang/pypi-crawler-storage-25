# v1 | 2026-05-02 | M6 Ollama client tests
"""Stdlib-only HTTP via urllib; mock urlopen for transport assertions."""

from __future__ import annotations

import json
import socket
from io import BytesIO
from typing import Any

import pytest
import urllib.error
import urllib.request

from contmemo.core.ollama_client import LLMError, OllamaClient


class _FakeResp:
    def __init__(self, payload: dict | str):
        body = payload if isinstance(payload, str) else json.dumps(payload)
        self._buf = BytesIO(body.encode("utf-8"))
    def read(self) -> bytes:
        return self._buf.read()
    def __enter__(self):
        return self
    def __exit__(self, *a):
        self._buf.close()


def _patch_urlopen(monkeypatch: pytest.MonkeyPatch, handler):
    """handler(req, timeout) → _FakeResp or raises."""
    def fake(req, timeout=None):
        return handler(req, timeout)
    monkeypatch.setattr("contmemo.core.ollama_client.urllib.request.urlopen", fake)


# ---------- available() ----------


def test_available_true_when_model_listed(monkeypatch: pytest.MonkeyPatch) -> None:
    def handler(req, timeout):
        assert req.full_url.endswith("/api/tags")
        return _FakeResp({"models": [{"name": "qwen2.5-coder:1.5b"}]})
    _patch_urlopen(monkeypatch, handler)
    c = OllamaClient(model="qwen2.5-coder")
    assert c.available() is True


def test_available_false_when_model_missing(monkeypatch: pytest.MonkeyPatch) -> None:
    _patch_urlopen(monkeypatch, lambda req, t: _FakeResp({"models": [{"name": "phi3"}]}))
    c = OllamaClient(model="qwen2.5-coder")
    assert c.available() is False


def test_available_false_on_connection_error(monkeypatch: pytest.MonkeyPatch) -> None:
    def boom(req, timeout):
        raise urllib.error.URLError("connection refused")
    _patch_urlopen(monkeypatch, boom)
    c = OllamaClient(model="qwen2.5-coder")
    assert c.available() is False


def test_available_false_on_timeout(monkeypatch: pytest.MonkeyPatch) -> None:
    def boom(req, timeout):
        raise socket.timeout("timed out")
    _patch_urlopen(monkeypatch, boom)
    c = OllamaClient(model="qwen2.5-coder")
    assert c.available() is False


def test_available_false_when_model_empty() -> None:
    # No urlopen mock needed — short-circuits on empty model.
    c = OllamaClient(model="")
    assert c.available() is False


# ---------- complete() ----------


def test_complete_posts_correct_body(monkeypatch: pytest.MonkeyPatch) -> None:
    captured: dict[str, Any] = {}
    def handler(req, timeout):
        captured["url"] = req.full_url
        captured["method"] = req.get_method()
        captured["body"] = json.loads(req.data.decode("utf-8"))
        return _FakeResp({"response": "hello"})
    _patch_urlopen(monkeypatch, handler)
    c = OllamaClient(model="phi3", timeout_s=5.0)
    out = c.complete("hi", max_tokens=128)
    assert out == "hello"
    assert captured["url"].endswith("/api/generate")
    assert captured["method"] == "POST"
    assert captured["body"]["model"] == "phi3"
    assert captured["body"]["prompt"] == "hi"
    assert captured["body"]["stream"] is False
    assert captured["body"]["options"]["num_predict"] == 128
    assert captured["body"]["options"]["temperature"] == 0.0


def test_complete_returns_response_field(monkeypatch: pytest.MonkeyPatch) -> None:
    _patch_urlopen(monkeypatch, lambda req, t: _FakeResp({"response": "world"}))
    c = OllamaClient(model="phi3")
    assert c.complete("x") == "world"


def test_complete_raises_on_http_error(monkeypatch: pytest.MonkeyPatch) -> None:
    def boom(req, timeout):
        raise urllib.error.HTTPError(req.full_url, 500, "boom", {}, None)
    _patch_urlopen(monkeypatch, boom)
    c = OllamaClient(model="phi3")
    with pytest.raises(LLMError) as exc:
        c.complete("x")
    assert "http_error_500" in str(exc.value)


def test_complete_raises_on_timeout(monkeypatch: pytest.MonkeyPatch) -> None:
    def boom(req, timeout):
        raise socket.timeout("timeout")
    _patch_urlopen(monkeypatch, boom)
    c = OllamaClient(model="phi3")
    with pytest.raises(LLMError):
        c.complete("x")


def test_complete_raises_on_missing_response_field(monkeypatch: pytest.MonkeyPatch) -> None:
    _patch_urlopen(monkeypatch, lambda req, t: _FakeResp({"other": "x"}))
    c = OllamaClient(model="phi3")
    with pytest.raises(LLMError):
        c.complete("x")


# ---------- loopback paranoia ----------


def test_endpoint_must_be_loopback() -> None:
    with pytest.raises(ValueError):
        OllamaClient(endpoint="http://example.com:11434", model="phi3")


def test_endpoint_loopback_v6_ok() -> None:
    OllamaClient(endpoint="http://[::1]:11434", model="phi3")


def test_endpoint_localhost_ok() -> None:
    OllamaClient(endpoint="http://localhost:11434", model="phi3")
