# v1 | 2026-05-02 | M6 runtime.run_bulk tests
"""Runtime.run_bulk wires lazy LLM build + BulkProcessor with the rest."""

from __future__ import annotations

import json
import sys
import uuid
from pathlib import Path

import pytest

from contmemo.core.event_log import EventLog
from contmemo.core.memory_writer import MemoryWriter
from contmemo.core.proposal_inbox import ProposalInbox
from contmemo.core.runtime import Runtime


class FakeLLM:
    def __init__(self, scripted: list[str], available: bool = True):
        self._scripted = list(scripted)
        self._available = available
        self.calls: list[str] = []
    def available(self) -> bool:
        return self._available
    def complete(self, prompt: str, *, max_tokens: int = 512) -> str:
        self.calls.append(prompt)
        return self._scripted.pop(0)


@pytest.fixture
def runtime_with_llm(tmp_path: Path):
    inbox_dir = tmp_path / "inbox"
    processed_dir = tmp_path / "processed"
    memory_path = tmp_path / "memory.jsonl"
    backup_dir = tmp_path / ".backups"
    log_path = tmp_path / "events.jsonl"

    event_log = EventLog(log_path)
    inbox = ProposalInbox(inbox_dir, processed_dir, event_log=event_log)
    writer = MemoryWriter(memory_path, backup_dir=backup_dir, event_log=event_log)

    def _build(llm) -> Runtime:
        return Runtime(
            config={
                "paths": {},
                "runtime": {"poll_interval_s": 0.01},
                "detector": {"window": 20, "threshold": 3, "pattern_emit_cooldown_s": 60},
                "bulk": {"pattern_summary_cooldown_s": 86400},
            },
            inbox=inbox, writer=writer, event_log=event_log, llm=llm,
        )

    return {"build": _build, "tmp_path": tmp_path,
            "deferred_dir": processed_dir / "deferred", "event_log": event_log,
            "memory_path": memory_path}


def _drop_deferred(deferred_dir: Path, **content) -> Path:
    deferred_dir.mkdir(parents=True, exist_ok=True)
    pid = f"prop-{uuid.uuid4().hex[:8]}"
    proposal = {
        "proposal_id":  pid,
        "from":         "cont",
        "session_id":   "sess",
        "turn_id":      "t",
        "type":         "memory_write",
        "subtype":      "lesson",
        "content":      content or {"text": "Sample lesson body present here for tests."},
        "user_message": "",
        "ts":           "2026-05-02T12:00:00+00:00",
    }
    p = deferred_dir / f"{pid}.json"
    p.write_text(json.dumps(proposal), encoding="utf-8")
    return p


# ---------- LLM unavailable ----------


def test_run_bulk_with_no_llm_skips_gracefully(runtime_with_llm) -> None:
    rt = runtime_with_llm["build"](None)  # no llm; auto-build will see model=""
    out = rt.run_bulk()
    assert out["deferred_processed"] == 0
    skips = list(runtime_with_llm["event_log"].query(event_type="bulk_skipped"))
    assert skips and skips[-1]["reason"] == "llm_unavailable"


def test_run_bulk_with_unavailable_llm_skips(runtime_with_llm) -> None:
    rt = runtime_with_llm["build"](FakeLLM([], available=False))
    out = rt.run_bulk()
    assert out["deferred_processed"] == 0


# ---------- end-to-end ----------


def test_run_bulk_processes_deferred_end_to_end(runtime_with_llm) -> None:
    _drop_deferred(runtime_with_llm["deferred_dir"])
    rt = runtime_with_llm["build"](FakeLLM([
        '{"decision": "accept", "reason_tag": "specific"}',
    ]))
    out = rt.run_bulk()
    assert out["deferred_processed"] == 1
    assert out["deferred_accepted"] == 1
    assert runtime_with_llm["memory_path"].exists()


def test_run_bulk_dry_run_no_side_effects(runtime_with_llm) -> None:
    src = _drop_deferred(runtime_with_llm["deferred_dir"])
    rt = runtime_with_llm["build"](FakeLLM([
        '{"decision": "accept", "reason_tag": "ok"}',
    ]))
    out = rt.run_bulk(dry_run=True)
    assert out["deferred_processed"] == 1
    assert src.exists()
    assert not runtime_with_llm["memory_path"].exists()


def test_run_bulk_summary_dict_structure(runtime_with_llm) -> None:
    rt = runtime_with_llm["build"](FakeLLM([], available=False))
    out = rt.run_bulk()
    expected = {
        "deferred_processed", "deferred_accepted", "deferred_rejected",
        "deferred_skipped", "patterns_summarized", "duration_s",
    }
    assert expected <= set(out.keys())


# ---------- M6 invariant: light path stays LLM-free ----------


def test_light_mode_does_not_import_ollama_client(tmp_path: Path) -> None:
    """run_light must not pull contmemo.core.ollama_client."""
    # Drop any pre-loaded copy (an earlier test may have imported it).
    sys.modules.pop("contmemo.core.ollama_client", None)

    inbox_dir = tmp_path / "inbox"
    processed_dir = tmp_path / "processed"
    memory_path = tmp_path / "memory.jsonl"
    backup_dir = tmp_path / ".backups"
    log_path = tmp_path / "events.jsonl"
    event_log = EventLog(log_path)
    inbox = ProposalInbox(inbox_dir, processed_dir, event_log=event_log)
    writer = MemoryWriter(memory_path, backup_dir=backup_dir, event_log=event_log)
    rt = Runtime(
        config={"paths": {}, "runtime": {"poll_interval_s": 0.01},
                "detector": {"window": 20, "threshold": 3, "pattern_emit_cooldown_s": 60}},
        inbox=inbox, writer=writer, event_log=event_log,
    )
    rt.run_light(max_iterations=1)
    assert "contmemo.core.ollama_client" not in sys.modules
