# v1 | 2026-05-02 | M6 CLI --bulk integration
"""--bulk runs end-to-end via the real argparse entry."""

from __future__ import annotations

import json
import uuid
from pathlib import Path

import pytest

from contmemo.__main__ import main


def _write_config(tmp_path: Path) -> Path:
    cfg = tmp_path / "config.toml"
    cfg.write_text(f"""
[paths]
proposals_inbox     = "{(tmp_path / 'inbox').as_posix()}"
processed_proposals = "{(tmp_path / 'processed').as_posix()}"
memory_path         = "{(tmp_path / 'memory.jsonl').as_posix()}"
memory_backup_dir   = "{(tmp_path / '.backups').as_posix()}"
event_log           = "{(tmp_path / 'events.jsonl').as_posix()}"

[runtime]
poll_interval_s = 0.01

[detector]
window = 20
threshold = 3
pattern_emit_cooldown_s = 60

[llm]
provider = "ollama"
endpoint = "http://127.0.0.1:11434"
model    = ""
""", encoding="utf-8")
    return cfg


def test_bulk_flag_no_llm_skips_cleanly(tmp_path: Path, capsys: pytest.CaptureFixture) -> None:
    cfg = _write_config(tmp_path)
    rc = main(["--bulk", "--config", str(cfg)])
    assert rc == 0
    out = capsys.readouterr().out
    summary = json.loads(out)
    assert summary["deferred_processed"] == 0
    # event log should record the skip
    log_lines = (tmp_path / "events.jsonl").read_text().splitlines()
    events = [json.loads(l) for l in log_lines if l.strip()]
    skip_events = [ev for ev in events if ev.get("event") == "bulk_skipped"]
    assert skip_events


def test_bulk_dry_run_flag_passes_through(tmp_path: Path, capsys: pytest.CaptureFixture) -> None:
    cfg = _write_config(tmp_path)
    rc = main(["--bulk", "--config", str(cfg), "--dry-run"])
    assert rc == 0
    summary = json.loads(capsys.readouterr().out)
    assert "duration_s" in summary


def test_bulk_max_items_flag_passes_through(tmp_path: Path, capsys: pytest.CaptureFixture) -> None:
    cfg = _write_config(tmp_path)
    rc = main(["--bulk", "--config", str(cfg), "--max-items", "10"])
    assert rc == 0
    summary = json.loads(capsys.readouterr().out)
    assert summary["deferred_processed"] == 0
