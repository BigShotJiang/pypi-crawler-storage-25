# v1 | 2026-05-02 | M5 runtime tests
"""Runtime: light-mode loop wiring inbox → writer → detector → event log."""

from __future__ import annotations

import json
import threading
import time
import uuid
from pathlib import Path
from typing import Callable

import pytest

from contmemo.core.event_log import EventLog
from contmemo.core.memory_writer import MemoryWriter
from contmemo.core.pattern_detect import PatternDetector
from contmemo.core.proposal_inbox import ProposalInbox
from contmemo.core.runtime import Runtime


@pytest.fixture
def runtime_env(tmp_path: Path):
    """Wire a full Runtime against tmp dirs without going through TOML."""
    inbox_dir = tmp_path / "inbox"
    processed_dir = tmp_path / "processed"
    memory_path = tmp_path / "memory.jsonl"
    backup_dir = tmp_path / ".backups"
    log_path = tmp_path / "events.jsonl"

    event_log = EventLog(log_path)
    inbox = ProposalInbox(inbox_dir, processed_dir, event_log=event_log)
    writer = MemoryWriter(memory_path, backup_dir=backup_dir, event_log=event_log)
    detector = PatternDetector(window=20, threshold=3)
    runtime = Runtime(
        config={
            "paths": {},
            "runtime": {"poll_interval_s": 0.01},
            "detector": {"pattern_emit_cooldown_s": 60, "window": 20, "threshold": 3},
        },
        inbox=inbox,
        writer=writer,
        event_log=event_log,
        detector=detector,
    )
    return {
        "runtime":   runtime,
        "inbox_dir": inbox_dir,
        "processed_dir": processed_dir,
        "memory_path":   memory_path,
        "log_path":      log_path,
        "event_log":     event_log,
        "writer":        writer,
        "inbox":         inbox,
    }


def _drop(inbox_dir: Path, proposal: dict, name: str | None = None) -> Path:
    inbox_dir.mkdir(parents=True, exist_ok=True)
    nm = name or f"{proposal['proposal_id']}.json"
    p = inbox_dir / nm
    p.write_text(json.dumps(proposal, ensure_ascii=False), encoding="utf-8")
    return p


def _proposal(subtype: str = "word", **overrides) -> dict:
    pid = overrides.pop("proposal_id", f"prop-{uuid.uuid4().hex[:8]}")
    if subtype == "word":
        content = {"word": "stigmergy"}
        user_message = "stigmergy diye"
    elif subtype == "lesson":
        content = {"text": "Sample lesson body present here for tests."}
        user_message = ""
    else:
        content = {"target": "old_lesson_42"}
        user_message = "şunu unut"
    base = {
        "proposal_id":  pid,
        "from":         "cont",
        "session_id":   "sess-test",
        "turn_id":      "t-001",
        "type":         "memory_write",
        "subtype":      subtype,
        "content":      content,
        "user_message": user_message,
        "ts":           "2026-05-02T12:00:00+00:00",
    }
    base.update(overrides)
    return base


# ---------- core loop ----------


def test_run_light_processes_pending_proposals(runtime_env) -> None:
    _drop(runtime_env["inbox_dir"], _proposal())
    _drop(runtime_env["inbox_dir"], _proposal())
    n = runtime_env["runtime"].run_light(max_iterations=2)
    assert n == 2


def test_run_light_max_iterations_terminates(runtime_env) -> None:
    # Empty inbox: each iteration sleeps poll_interval (0.01 s) and returns.
    started = time.time()
    n = runtime_env["runtime"].run_light(max_iterations=3)
    elapsed = time.time() - started
    assert n == 0
    assert elapsed < 2.0  # never block on the empty inbox


def test_accept_decision_triggers_memory_write(runtime_env) -> None:
    _drop(runtime_env["inbox_dir"], _proposal(subtype="word"))
    runtime_env["runtime"].run_light(max_iterations=1)
    assert runtime_env["memory_path"].exists()
    rows = [json.loads(l) for l in runtime_env["memory_path"].read_text().splitlines() if l.strip()]
    assert len(rows) == 1
    assert rows[0]["subtype"] == "word"


def test_reject_decision_does_not_write(runtime_env) -> None:
    _drop(runtime_env["inbox_dir"], _proposal(subtype="lesson", content={"text": "ok"}))
    runtime_env["runtime"].run_light(max_iterations=1)
    assert not runtime_env["memory_path"].exists()


def test_defer_decision_archives_to_deferred(runtime_env) -> None:
    _drop(runtime_env["inbox_dir"], _proposal(subtype="forget", user_message="bilmiyorum"))
    runtime_env["runtime"].run_light(max_iterations=1)
    deferred = runtime_env["processed_dir"] / "deferred"
    assert any(deferred.iterdir())


def test_runtime_idempotent_on_restart(runtime_env) -> None:
    _drop(runtime_env["inbox_dir"], _proposal(), name="a.json")
    _drop(runtime_env["inbox_dir"], _proposal(), name="b.json")
    n1 = runtime_env["runtime"].run_light(max_iterations=1)
    assert n1 == 2
    # Re-drop the *same* proposal_ids (M3 dedup should kick in if anyone
    # re-submits) — but really the files are already moved. So the next
    # round sees zero pending, and that is exactly the idempotency claim.
    n2 = runtime_env["runtime"].run_light(max_iterations=1)
    assert n2 == 0


# ---------- pattern detection ----------


def test_pattern_emitted_on_recurring_friction(runtime_env) -> None:
    runtime = runtime_env["runtime"]
    event_log = runtime_env["event_log"]
    # 3× lesson_too_short — same friction signal three times.
    for i in range(3):
        _drop(runtime_env["inbox_dir"],
              _proposal(subtype="lesson", content={"text": "no"}, proposal_id=f"r-{i}"),
              name=f"r{i}.json")
    runtime.run_light(max_iterations=1)
    pattern_events = list(event_log.query(event_type="pattern_detected"))
    assert pattern_events, "expected at least one pattern_detected event"
    assert pattern_events[-1]["signal"] == {
        "kind": "reject",
        "reason": "lesson_too_short",
        "subtype": "lesson",
    }


def test_pattern_emit_cooldown(runtime_env) -> None:
    runtime = runtime_env["runtime"]
    event_log = runtime_env["event_log"]
    # First trigger.
    for i in range(3):
        _drop(runtime_env["inbox_dir"],
              _proposal(subtype="lesson", content={"text": "no"}, proposal_id=f"r-{i}"),
              name=f"r{i}.json")
    runtime.run_light(max_iterations=1)

    # Second trigger immediately — cooldown should suppress the duplicate emission.
    for i in range(3, 6):
        _drop(runtime_env["inbox_dir"],
              _proposal(subtype="lesson", content={"text": "no"}, proposal_id=f"r-{i}"),
              name=f"r{i}.json")
    runtime.run_light(max_iterations=1)

    events = list(event_log.query(event_type="pattern_detected"))
    assert len(events) == 1


# ---------- robustness ----------


def test_runtime_survives_malformed_proposal(runtime_env) -> None:
    bad = runtime_env["inbox_dir"] / "broken.json"
    runtime_env["inbox_dir"].mkdir(parents=True, exist_ok=True)
    bad.write_text("{not valid json", encoding="utf-8")
    _drop(runtime_env["inbox_dir"], _proposal(), name="good.json")
    n = runtime_env["runtime"].run_light(max_iterations=1)
    assert n == 2  # both decisions yielded; malformed went to quarantine


def test_request_shutdown_breaks_loop(runtime_env) -> None:
    runtime = runtime_env["runtime"]
    box: list[int] = []

    def runner():
        box.append(runtime.run_light())  # no max_iterations → runs forever

    th = threading.Thread(target=runner, daemon=True)
    th.start()
    time.sleep(0.05)
    runtime.request_shutdown()
    th.join(timeout=2.0)
    assert not th.is_alive()
    assert box == [0]
