from __future__ import annotations

from llm_input_hardening.cli import *  # noqa: F403
from llm_input_hardening.cli import main


if __name__ == "__main__":
    raise SystemExit(main())
