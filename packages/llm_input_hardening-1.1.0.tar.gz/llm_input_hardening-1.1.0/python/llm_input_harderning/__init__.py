from __future__ import annotations

from importlib import import_module
import sys
from typing import Any

_CANONICAL_PACKAGE = "llm_input_hardening"
_canonical = import_module(_CANONICAL_PACKAGE)

__all__ = list(getattr(_canonical, "__all__", ()))

for _name in __all__:
    globals()[_name] = getattr(_canonical, _name)

for _submodule in (
    "confusables",
    "enforcement",
    "json_sanitize",
    "meter",
    "middleware",
    "policies",
    "postprocess",
    "reason_codes",
    "telemetry",
    "types",
):
    sys.modules[f"{__name__}.{_submodule}"] = import_module(
        f"{_CANONICAL_PACKAGE}.{_submodule}"
    )


def __getattr__(name: str) -> Any:
    return getattr(_canonical, name)
