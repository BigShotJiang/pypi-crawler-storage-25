# llm-input-harderning compatibility package

This package exists only to migrate users from the original misspelled
distribution name to `llm-input-hardening`.

Publish order:

1. Publish `llm-input-hardening>=1.1.0`.
2. Publish this compatibility distribution as `llm-input-harderning==1.0.6`.

The corrected package provides both import paths:

- `llm_input_hardening`
- `llm_input_harderning`

