from __future__ import annotations


def test_legacy_package_import_reexports_canonical_api() -> None:
    from llm_input_hardening import sanitize as canonical_sanitize
    from llm_input_harderning import sanitize as legacy_sanitize
    from llm_input_harderning.enforcement import sanitize_and_decide

    assert legacy_sanitize is canonical_sanitize
    clean, report = legacy_sanitize("abc\u202Edef")
    assert clean == "abcdef"
    assert report["changed"] is True
    assert callable(sanitize_and_decide)
