# cython: language_level=3
from admm cimport *
from libc.stdlib cimport malloc, free
from enum import Enum as _Enum
import numbers as _numbers
import numpy as _np
import scipy.sparse as _sp
import scipy.special as _ss
import builtins as _builtins
import functools as _functools
import threading as _threading
import traceback as _traceback
from collections import namedtuple as _namedtuple
import socket
import urllib.parse
import os
import sys

__all__ = [
    'epsilon', 'inf', "MINIMIZE", "MAXIMIZE", "REVISION", "ADMMError", "Options", "OptionConstClass", "Model", "Constr", "Constant",  "Param", "Var", "Expr", "TuningContext", "UDFBase"
]

import sys

class ThisModule(sys.__class__):

    @property
    def epsilon(self):
        return admm_get_epsilon()

    @epsilon.setter
    def epsilon(self, value):
        if value < 0:
            raise ValueError("non-negative value expected")
        admm_set_epsilon(value)

sys.modules[__name__].__class__ = ThisModule


inf = _np.inf

cdef tensorattrnames = {}

cdef loadTensorAttrs():
    cdef const char** names
    cdef int len
    global tensorattrnames
    tensorattrnames = {}
    admm_load_tensor_attrs(&names, &len)
    for i in range(len):
        tensorattrnames[str(names[i], "utf8")] = i

# load tensor attribute names
loadTensorAttrs()


cdef str BAD_ARG            = "BAD_ARG_TYPE"
cdef str OPT_NOT_FOUND      = "OPT_NOT_FOUND"
cdef str SHAPE_MISMATCHED   = "SHAPE_MISMATCHED"


cdef int OT_NOP      = 0
cdef int OT_NEG      = 1
cdef int OT_T        = 2
cdef int OT_SLICE    = 3
cdef int OT_RESHAPE  = 4
cdef int OT_ADD      = 5
cdef int OT_SUB      = 6
cdef int OT_MUL      = 7
cdef int OT_DIV      = 8
cdef int OT_MML      = 9
cdef int OT_POW      = 10

cdef OPNAMES = ["NOP", "NEG", "TRANSPOSE", "SLICE", "RESHAPE", "ADD", "SUB", "MUL", "DIV", "MATMUL", "POW"]


cdef int AT_RANGE        = 0
cdef int AT_SHAPE        = 1
cdef int AT_SPARSE       = 2
cdef int AT_DENSE        = 3
cdef int AT_PARAMETER    = 4
cdef int AT_VARIABLE     = 5
cdef int AT_EXPR         = 6


cdef callbackLock = _threading.Lock()

cdef constant(f):
    def fset(self, value):
        raise TypeError('Value is readonly')
    def fget(self):
        return f(self)
    return property(fget, fset, None, f.__doc__)

cdef class ADMMError(Exception):
    '''\nThis exception can be caught for most routines. It has 2 properties (errno and\nmessage) to indicate which error occurred.\n\n\n\n\n'''
    cdef int errno_
    cdef str message_

    def __init__(self, arg1, str arg2 = None):
        message = None
        errno = -1
        if isinstance(arg1, str) or isinstance(arg1, bytes):
            message = arg1 if isinstance(arg1, str) else str(arg1, "utf8")
            errno = admm_error_code(bytes(message, "utf8"))
        else:
            errno = int(arg1)
            if arg2 is not None:
                message = arg2
            else:
                raw = admm_explain_err(errno)
                message =  str(raw, 'utf8')

        self.message_ = message
        self.errno_ = errno
        super(ADMMError, self).__init__(self.message_)

    @constant
    def errno(self):
        '''type: int\n\nThe error number for error just occurred. \n\n\n\n\n'''
        return self.errno_

    @constant
    def message(self):
        '''type: str\n\nThe text message to explain what error just occurred.\n\n\n\n\n'''
        return self.message_

cdef ensure_array_type(obj):
    if isinstance(obj, (TensorLike, _np.ndarray, _sp.spmatrix)):
        return obj
    arr = _np.array(obj)
    if arr.dtype == object:
        raise NotImplementedError
    if not _np.issubdtype(arr.dtype, _np.number) and arr.dtype != _np.bool_:
        raise TypeError("expected numeric input, got dtype {}".format(arr.dtype))
    return arr

def _start_doc_server(port = 8080):
    '''
    Start the document server at a specific port.

    Parameters
    ----------
    port : int
        Port for document web service startup.
    
    '''
    modulepath = os.path.abspath(__file__)
    pwd = os.path.dirname(modulepath)
    ROOT = os.path.join(pwd, "doc")

    if not os.path.exists(ROOT) or not os.path.isdir(ROOT):
        raise OSError(f"Directory '{ROOT}' does not exist")
    
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    except OSError:
        pass

    sock.bind(('127.0.0.1', port))

    def bad_req(client):
        client.send(b'HTTP/1.1 400 Bad Request\n\n')
        client.close()

    def not_found(client, proto):
        msg = f'{proto} 404 Not Found\n\n'
        client.send(msg.encode())
        client.close()

    def redirect(client, proto, path):
        msg = f'{proto} 301 Moved Permanently\nLocation: {path}\n\n'
        client.send(msg.encode())
        client.close()

    def guess_mime_type(file):
        ext = ''
        idx = file.rfind('.')
        if idx >= 0:
            ext = file[idx + 1 :]
        
        if ext == '': return 'application/octet-stream'
        ext = ext.lower()

        map = {
            'html': 'text/html',
            'htm': 'text/html',
            'css': 'text/css',
            'js': 'text/javascript',
            'json': 'application/json',
            'png': 'image/apng',
            'gif': 'image/gif',
            'jpg': 'image/jpg',
            'jpeg': 'image/jpeg',
            'svg': 'image/svg+xml',
            'woff': 'font/woff',
            'woff2': 'font/woff',
            'ttf': 'font/ttf',
            'otf': 'font/otf'
        }

        mtype = map.get(ext)

        return 'application/octet-stream' if mtype is None else mtype

    def resp(client, path, proto):
        mimeType = guess_mime_type(os.path.basename(path))
        with open(path, 'rb') as f:
            data = f.read()
            msg = f'{proto} 200 OK\nContent-Length:{len(data)}\n'
            msg += f'Content-Type: {mimeType}\n\n'

            msg = msg.encode() + data
            client.send(msg)
            client.close()

    sock.listen(1024)

    sys.stderr.write(f'The documentation server has been started on port {port}\n')
    sys.stderr.write(f'To access the documentation, please go to: http://127.0.0.1:{port}\n')
    sys.stderr.write(f'Press Ctrl+C to stop the current server\n')
    sys.stderr.flush()

    try:
        while True:
            client, _ = sock.accept()
            client.settimeout(30)
            req = client.recv(1024)

            if not req.startswith(b"GET /"):
                bad_req(client)
                continue

            idx = req.find(b'\n')
            if idx < 0: 
                bad_req(client)
                continue
            
            path_proto = req[4 : idx]
            idx = path_proto.rfind(b' ')
            if idx < 0:
                bad_req(client)
                continue
            
            path = path_proto[0 : idx].strip().decode()
            path = urllib.parse.unquote(path)
            proto = path_proto[idx + 1 :].strip().decode()

            if proto not in ['HTTP/1.0', 'HTTP/1.1', 'HTTP/2.0']:
                bad_req(client)
                continue
            
            if '/.' in path or '/..' in path:
                not_found(client, proto)
                continue
            
            last = path.rfind('/')
            ppos = path.rfind('?')
            if ppos >= 0 and ppos > last:
                path = path[:ppos]

            fpath = os.path.join(ROOT, path[1:])

            # Prevent symlink escape
            if not os.path.realpath(fpath).startswith(os.path.realpath(ROOT)):
                not_found(client, proto)
                continue

            if not os.path.exists(fpath):
                not_found(client, proto)
                continue
            
            if os.path.isdir(fpath):
                IDX1 = 'index.html'
                IDX2 = 'index.htm'

                idxfile1 = os.path.join(fpath, IDX1)
                idxfile2 = os.path.join(fpath, IDX2)
                if os.path.exists(idxfile1) and os.path.isfile(idxfile1):
                    redirect(client, proto, os.path.join(path, IDX1))
                    continue
                elif os.path.exists(idxfile2) and os.path.isfile(idxfile2):
                    redirect(client, proto, os.path.join(path, IDX2))
                    continue
                else:
                    not_found(client, proto)
                    continue
                
            resp(client, fpath, proto)
    except KeyboardInterrupt:
        pass

cdef isConstExp(expr):
    return not isinstance(expr, (Param, Var, UDFBase, Expr))

class OptionConstClass:
    '''\nA namespace to hold option names. It has a builtin instance `admm.Options`.\n\nFor example:\n\n\n\n  # Set the maximum number of iterations as 1000 for solving the original problem\n\n  model.setOption(admm.Options.admm_max_iteration, 1000)\n\n\n\n\n\n\n'''
    @constant
    def sub_problem_count_upper_bound(self):
        '''type: int\nmin: -1, max: 100000, default: -1\nSpecifies the maximum number of sub-problems generated by the algorithm, with -1 indicating no maximum limit.'''
        return "sub_problem_count_upper_bound"

    @constant
    def sub_problem_solving_order(self):
        '''type: int\nmin: 0, max: 1, default: 0\nSpecifies the order to solve sub-problems.
 * 0: Gauss-Seidel sequential execution
 * 1: Jacobi parallel execution'''
        return "sub_problem_solving_order"

    @constant
    def linear_system_solver(self):
        '''type: int\nmin: 0, max: 2, default: 1\nSpecifies the solver to solve the linear system.
 * 0: Unknown solver
 * 1: DIRECT linear solver
 * 2: INDIRECT linear solver'''
        return "linear_system_solver"

    @constant
    def sub_problem_max_iteration(self):
        '''type: int\nmin: 1, max: 10000, default: 10\nSpecifies the maximum number of iterations to solve sub-problems.'''
        return "sub_problem_max_iteration"

    @constant
    def admm_max_iteration(self):
        '''type: int\nmin: 1, max: 1000000000, default: 1000\nSpecifies the maximum number of iterations for solving the original problem.'''
        return "admm_max_iteration"

    @constant
    def solver_verbosity_level(self):
        '''type: int\nmin: 0, max: 6, default: 2\nSpecifies the verbosity level of the solver output.
 * 0: DETAIL
 * 1: INFO
 * 2: SUMMARY
 * 3: SILENT
 * 4: WARNING
 * 5: ERROR
 * 6: FATAL'''
        return "solver_verbosity_level"

    @constant
    def solver_output_precision(self):
        '''type: int\nmin: -1, max: 100, default: 2\nSpecifies the number of digits after the decimal mark for solver output.
 * -1: default value'''
        return "solver_output_precision"

    @constant
    def solver_message_print_interval(self):
        '''type: int\nmin: 1, max: 10000, default: 1000\nSpecifies the interval in iterations between each message output by the solver during its operation.'''
        return "solver_message_print_interval"

    @constant
    def message_lines_per_header(self):
        '''type: int\nmin: 20, max: 1000, default: 20\nSpecifies the number of message lines printed between each header information output.'''
        return "message_lines_per_header"

    @constant
    def hyper_param_info_collection_interval(self):
        '''type: int\nmin: 1, max: 100, default: 10\nSpecifies the interval to collect hyperparameter-related information.'''
        return "hyper_param_info_collection_interval"

    @constant
    def penalty_param_update_upper_bound(self):
        '''type: int\nmin: 0, max: 10000, default: 20\nSpecifies the maximum number for penalty parameter tuning.'''
        return "penalty_param_update_upper_bound"

    @constant
    def over_relaxation_param_update_upper_bound(self):
        '''type: int\nmin: 0, max: 10000, default: 10\nSpecifies the maximum number of updates for the over-relaxation parameter.'''
        return "over_relaxation_param_update_upper_bound"

    @constant
    def hyper_param_update_min_interval(self):
        '''type: int\nmin: 1, max: 100000, default: 300\nSpecifies the minimum iteration interval for hyperparameter updates.'''
        return "hyper_param_update_min_interval"

    @constant
    def spectral_radius_tuning_interval(self):
        '''type: int\nmin: 1, max: 10000, default: 5\nSpecifies the iteration interval for updating the penalty parameter using the spectral radius approximation method.'''
        return "spectral_radius_tuning_interval"

    @constant
    def computational_data_type_preference(self):
        '''type: int\nmin: -1, max: 1, default: 0\nSpecifies the preferred data type for computational procedures.
 * 0: float
 * 1: double
 * -1: default setting'''
        return "computational_data_type_preference"

    @constant
    def anderson_acceleration_lookback(self):
        '''type: int\nmin: 0, max: 100, default: 0\nSpecifies the memory length (number of past iterations) for Anderson acceleration. If > 0, enables Anderson acceleration. Set to 0 to disable.'''
        return "anderson_acceleration_lookback"

    @constant
    def anderson_acceleration_interval(self):
        '''type: int\nmin: 1, max: 1000, default: 10\nSpecifies the interval (in iterations) for applying Anderson acceleration. Acceleration is applied every N iterations.'''
        return "anderson_acceleration_interval"

    @constant
    def merge_linobj_enable(self):
        '''type: int\nmin: 0, max: 1, default: 0\nSpecifies whether to consolidate linear functions of multiple variables in the objective as a unified linear function'''
        return "merge_linobj_enable"

    @constant
    def rescale_by_constr_kind_enable(self):
        '''type: int\nmin: 0, max: 1, default: 0\nSpecifies whether to rescale the constraints based on their type. Specifically, for constraints involving only two variables, where one of the variables does not appear in the objective function, both sides of the equality in such constraints are to be multiplied by a factor ranging from 0 to 1.'''
        return "rescale_by_constr_kind_enable"

    @constant
    def merge_zero_obj_var_enable(self):
        '''type: int\nmin: 0, max: 1, default: 1\nSpecifies whether to aggregate variables. Specifically, for two variables, (x) and (y), that do not appear in the objective function (represented as (0 \cdot x) and (0 \cdot y) respectively), this operation aggregates them into a single new variable, denoted as (xy).'''
        return "merge_zero_obj_var_enable"

    @constant
    def display_sub_solver_details(self):
        '''type: int\nmin: 0, max: 1, default: 0\nSpecifies whether to output the sub-solver details.'''
        return "display_sub_solver_details"

    @constant
    def log_iteration_details_to_file(self):
        '''type: int\nmin: 0, max: 1, default: 0\nSpecifies whether to write iteration details to a file.'''
        return "log_iteration_details_to_file"

    @constant
    def constraint_specific_penalty_enable(self):
        '''type: int\nmin: 0, max: 1, default: 0\nSpecifies whether to enable distinct penalty parameters for each constraint.'''
        return "constraint_specific_penalty_enable"

    @constant
    def penalty_param_auto(self):
        '''type: int\nmin: 0, max: 1, default: 1\nSpecifies whether to enable the penalty parameter be tunable automatically.'''
        return "penalty_param_auto"

    @constant
    def over_relaxation_usage(self):
        '''type: int\nmin: 0, max: 1, default: 0\nSpecifies whether to use the over-relaxation technique in iterations.'''
        return "over_relaxation_usage"

    @constant
    def spectral_radius_tuning_application(self):
        '''type: int\nmin: 0, max: 1, default: 1\nSpecifies whether to use the spectral radius approximation in parameter tuning.'''
        return "spectral_radius_tuning_application"

    @constant
    def anderson_acceleration_type1(self):
        '''type: int\nmin: 0, max: 1, default: 1\nSpecifies whether to use Type-I (true) or Type-II (false) Anderson acceleration.'''
        return "anderson_acceleration_type1"


    @constant
    def sub_solver_absolute_tol(self):
        '''type: float\nmin: 1e-08, max: 1.0, default: 0.001\nSpecifies the absolute tolerance threshold for the iterative solution of sub-problems.'''
        return "sub_solver_absolute_tol"

    @constant
    def sub_solver_relative_tol(self):
        '''type: float\nmin: 1e-08, max: 1.0, default: 0.001\nSpecifies the relative tolerance threshold for the iterative solution of sub-problems.'''
        return "sub_solver_relative_tol"

    @constant
    def solver_max_time_limit(self):
        '''type: float\nmin: 0.0, max: 10000000.0, default: 1000.0\nSpecifies the maximum solving time in seconds.'''
        return "solver_max_time_limit"

    @constant
    def initial_penalty_param_value(self):
        '''type: float\nmin: 0.0, max: 100000000.0, default: 1.0\nSpecifies the initial value for the penalty parameter.'''
        return "initial_penalty_param_value"

    @constant
    def residual_balance_tuning_mu(self):
        '''type: float\nmin: 0.0001, max: 10000.0, default: 30.0\nSpecifies the parameter mu used in the residual balance method.'''
        return "residual_balance_tuning_mu"

    @constant
    def residual_balance_inc_tau(self):
        '''type: float\nmin: 1.0, max: 1000.0, default: 1.5\nSpecifies the increment parameter inc_tau for the residual balance penalty tuning strategy.'''
        return "residual_balance_inc_tau"

    @constant
    def residual_balance_dec_tau(self):
        '''type: float\nmin: 1.0, max: 1000.0, default: 1.5\nSpecifies the decrement parameter dec_tau for the residual balance penalty tuning strategy.'''
        return "residual_balance_dec_tau"

    @constant
    def max_penalty_param(self):
        '''type: float\nmin: 10000.0, max: 100000000.0, default: 1000000.0\nSpecifies the maximum value for the penalty parameter.'''
        return "max_penalty_param"

    @constant
    def min_penalty_param(self):
        '''type: float\nmin: 1e-08, max: 0.0001, default: 1e-06\nSpecifies the minimum value for the penalty parameter.'''
        return "min_penalty_param"

    @constant
    def initial_over_relaxation_param(self):
        '''type: float\nmin: 0.0, max: 1.618, default: 1.6\nSpecifies the initial value for the over-relaxation parameter.'''
        return "initial_over_relaxation_param"

    @constant
    def min_over_relaxation_param(self):
        '''type: float\nmin: 0.0, max: 1.0, default: 0.0\nSpecifies the minimum value for the over-relaxation parameter.'''
        return "min_over_relaxation_param"

    @constant
    def max_over_relaxation_param(self):
        '''type: float\nmin: 1.0, max: 1.618, default: 1.618\nSpecifies the maximum value for the over-relaxation parameter.'''
        return "max_over_relaxation_param"

    @constant
    def spectral_radius_approximation_inc_tau(self):
        '''type: float\nmin: 1.0, max: 1000.0, default: 10.0\nSpecifies the increment parameter inc_tau for the spectral radius approximation method.'''
        return "spectral_radius_approximation_inc_tau"

    @constant
    def spectral_radius_approximation_dec_tau(self):
        '''type: float\nmin: 1.0, max: 1000.0, default: 10.0\nSpecifies the decrement parameter dec_tau for the spectral radius approximation method.'''
        return "spectral_radius_approximation_dec_tau"

    @constant
    def termination_absolute_error_threshold(self):
        '''type: float\nmin: 1e-16, max: 0.1, default: 1e-06\nSpecifies the maximum absolute error threshold between two successive iterations as the termination criterion.'''
        return "termination_absolute_error_threshold"

    @constant
    def termination_relative_error_threshold(self):
        '''type: float\nmin: 1e-16, max: 0.1, default: 1e-06\nSpecifies the maximum relative error threshold between two successive iterations as the termination criterion.'''
        return "termination_relative_error_threshold"

    @constant
    def termination_relative_primal_dual_gap(self):
        '''type: float\nmin: 1e-16, max: 0.1, default: 0.0001\nSpecifies the maximum relative error threshold between the primal and dual objective values.'''
        return "termination_relative_primal_dual_gap"

    @constant
    def strict_constraint_tol(self):
        '''type: float\nmin: 1e-18, max: 1.0, default: 1e-08\nSpecifies the tolerance value for strict constraint.'''
        return "strict_constraint_tol"

    @constant
    def anderson_acceleration_regularization(self):
        '''type: float\nmin: 1e-15, max: 0.001, default: 1e-08\nRegularization parameter for Anderson acceleration. Type-I typically uses 1e-8, Type-II uses 1e-12.'''
        return "anderson_acceleration_regularization"

    @constant
    def anderson_acceleration_relaxation(self):
        '''type: float\nmin: 0.0, max: 2.0, default: 1.0\nRelaxation parameter for Anderson acceleration in range [0,2]. 1.0 is standard.'''
        return "anderson_acceleration_relaxation"

    @constant
    def anderson_acceleration_safeguard_factor(self):
        '''type: float\nmin: 0.1, max: 10.0, default: 1.5\nSafeguard factor controlling safeguard checks for Anderson acceleration. Larger values are more aggressive but less stable.'''
        return "anderson_acceleration_safeguard_factor"

    @constant
    def anderson_acceleration_max_weight_norm(self):
        '''type: float\nmin: 1.0, max: 1000000000000000.0, default: 10000000000.0\nMaximum norm of Anderson acceleration weights. If exceeded, AA step is rejected.'''
        return "anderson_acceleration_max_weight_norm"


Options = OptionConstClass()

cdef IntOptNames = {
    "sub_problem_count_upper_bound": (b"sub_problem_count_upper_bound", -1, 100000, -1),
    "sub_problem_solving_order": (b"sub_problem_solving_order", 0, 1, 0),
    "linear_system_solver": (b"linear_system_solver", 0, 2, 1),
    "sub_problem_max_iteration": (b"sub_problem_max_iteration", 1, 10000, 10),
    "admm_max_iteration": (b"admm_max_iteration", 1, 1000000000, 1000),
    "solver_verbosity_level": (b"solver_verbosity_level", 0, 6, 2),
    "solver_output_precision": (b"solver_output_precision", -1, 100, 2),
    "solver_message_print_interval": (b"solver_message_print_interval", 1, 10000, 1000),
    "message_lines_per_header": (b"message_lines_per_header", 20, 1000, 20),
    "hyper_param_info_collection_interval": (b"hyper_param_info_collection_interval", 1, 100, 10),
    "penalty_param_update_upper_bound": (b"penalty_param_update_upper_bound", 0, 10000, 20),
    "over_relaxation_param_update_upper_bound": (b"over_relaxation_param_update_upper_bound", 0, 10000, 10),
    "hyper_param_update_min_interval": (b"hyper_param_update_min_interval", 1, 100000, 300),
    "spectral_radius_tuning_interval": (b"spectral_radius_tuning_interval", 1, 10000, 5),
    "computational_data_type_preference": (b"computational_data_type_preference", -1, 1, 0),
    "anderson_acceleration_lookback": (b"anderson_acceleration_lookback", 0, 100, 0),
    "anderson_acceleration_interval": (b"anderson_acceleration_interval", 1, 1000, 10),
    "merge_linobj_enable": (b"merge_linobj_enable", 0, 1, 0),
    "rescale_by_constr_kind_enable": (b"rescale_by_constr_kind_enable", 0, 1, 0),
    "merge_zero_obj_var_enable": (b"merge_zero_obj_var_enable", 0, 1, 1),
    "display_sub_solver_details": (b"display_sub_solver_details", 0, 1, 0),
    "log_iteration_details_to_file": (b"log_iteration_details_to_file", 0, 1, 0),
    "constraint_specific_penalty_enable": (b"constraint_specific_penalty_enable", 0, 1, 0),
    "penalty_param_auto": (b"penalty_param_auto", 0, 1, 1),
    "over_relaxation_usage": (b"over_relaxation_usage", 0, 1, 0),
    "spectral_radius_tuning_application": (b"spectral_radius_tuning_application", 0, 1, 1),
    "anderson_acceleration_type1": (b"anderson_acceleration_type1", 0, 1, 1),
}


cdef DblOptNames = {
    "sub_solver_absolute_tol": (b"sub_solver_absolute_tol", 1e-08, 1.0, 0.001),
    "sub_solver_relative_tol": (b"sub_solver_relative_tol", 1e-08, 1.0, 0.001),
    "solver_max_time_limit": (b"solver_max_time_limit", 0.0, 10000000.0, 1000.0),
    "initial_penalty_param_value": (b"initial_penalty_param_value", 0.0, 100000000.0, 1.0),
    "residual_balance_tuning_mu": (b"residual_balance_tuning_mu", 0.0001, 10000.0, 30.0),
    "residual_balance_inc_tau": (b"residual_balance_inc_tau", 1.0, 1000.0, 1.5),
    "residual_balance_dec_tau": (b"residual_balance_dec_tau", 1.0, 1000.0, 1.5),
    "max_penalty_param": (b"max_penalty_param", 10000.0, 100000000.0, 1000000.0),
    "min_penalty_param": (b"min_penalty_param", 1e-08, 0.0001, 1e-06),
    "initial_over_relaxation_param": (b"initial_over_relaxation_param", 0.0, 1.618, 1.6),
    "min_over_relaxation_param": (b"min_over_relaxation_param", 0.0, 1.0, 0.0),
    "max_over_relaxation_param": (b"max_over_relaxation_param", 1.0, 1.618, 1.618),
    "spectral_radius_approximation_inc_tau": (b"spectral_radius_approximation_inc_tau", 1.0, 1000.0, 10.0),
    "spectral_radius_approximation_dec_tau": (b"spectral_radius_approximation_dec_tau", 1.0, 1000.0, 10.0),
    "termination_absolute_error_threshold": (b"termination_absolute_error_threshold", 1e-16, 0.1, 1e-06),
    "termination_relative_error_threshold": (b"termination_relative_error_threshold", 1e-16, 0.1, 1e-06),
    "termination_relative_primal_dual_gap": (b"termination_relative_primal_dual_gap", 1e-16, 0.1, 0.0001),
    "strict_constraint_tol": (b"strict_constraint_tol", 1e-18, 1.0, 1e-08),
    "anderson_acceleration_regularization": (b"anderson_acceleration_regularization", 1e-15, 0.001, 1e-08),
    "anderson_acceleration_relaxation": (b"anderson_acceleration_relaxation", 0.0, 2.0, 1.0),
    "anderson_acceleration_safeguard_factor": (b"anderson_acceleration_safeguard_factor", 0.1, 10.0, 1.5),
    "anderson_acceleration_max_weight_norm": (b"anderson_acceleration_max_weight_norm", 1.0, 1000000000000000.0, 10000000000.0),
}

cdef FunInfo = {
    101: "abs",
    102: "exp",
    103: "norm",
    104: "norm",
    105: "norm",
    106: "entropy",
    107: "log",
    109: "square",
    110: "sqrt",
    111: "sum",
    112: "diag",
    113: "log_det",
    114: "trace",
    116: "norm",
    117: "norm",
    118: "max",
    119: "min",
    121: "norm",
    122: "squared_hinge",
    201: "maximum",
    202: "minimum",
    203: "power",
    204: "logistic",
    205: "huber",
    206: "kl_div",
    207: "bathtub",
    208: "squared_bathtub",
    209: "vapnik",
    210: "conv2d",
    211: "conv2d",
    212: "conv2d",
    220: "corr2d",
    221: "corr2d",
    222: "corr2d",
    223: "tv2d",
    301: "inrange",
    302: "tv1d",
    303: "scalene",
    901: "hstack",
    902: "vstack",
}

__all__ += ['power', 'norm', 'bathtub', 'kl_div', 'diag', 'squared_hinge', 'log_det', 'square', 'maximum', 'inrange', 'sqrt', 'conv2d', 'scalene', 'tv2d', 'entropy', 'hstack', 'max', 'tv1d', 'exp', 'corr2d', 'min', 'logistic', 'abs', 'trace', 'squared_bathtub', 'vapnik', 'log', 'vstack', 'minimum', 'sum', 'huber']

cdef class TuningContext:
    '''\nThe hyper parameter accessor.\n\nIf user defined its hyper parameter tuner, use this class to retrieve information\nand set new value for hyper parameters.\n\n\n\n\n'''
    cdef int* nactive_
    cdef int* dactive_
    cdef int* nval_
    cdef double* dval_


    def __metacls__(self):

        class MetaClass(type):
            # this meta class is to pretty pydoc for TuningContext
            def __dir__(self):
                return ['ITER_NUM', 'constr_penalty', 'over_relaxation_alpha', 'TIME', 'PRIMAL_OBJ', 'ALM_OBJ', 'PRIMAL_INF', 'DUAL_INF', 'RHO', 'ALPHA', 'METRIC1']

        return MetaClass

    cdef bind(self, int* nactive, int* dactive, int* nval, double* dval):
        self.nactive_ = nactive
        self.dactive_ = dactive
        self.nval_ = nval
        self.dval_ = dval

        nhypers = 1
        dhypers = 10

        for i in range(nhypers):
            self.nactive_[i] = 0

        for i in range(dhypers):
            self.dactive_[i] = 0


    @property
    def ITER_NUM(self):
        '''type: int\nmin: 0, max: 1000000\nIteration number'''
        return self.nval_[0]

    @ITER_NUM.setter
    def ITER_NUM(self, value):
        if not isinstance(value, _numbers.Number):
            raise ValueError('expect an numeric value')
        if value < 0 or value > 1000000:
            raise ValueError('value is out of range')
        self.nactive_[0] = 1
        self.nval_[0] = int(value)




    @property
    def constr_penalty (self):
        '''type: float\nmin: 1e-06, max: 1000000.0\nConstraint penalty factor'''
        return self.dval_[0]

    @constr_penalty.setter
    def constr_penalty(self, value):
        if not isinstance(value, _numbers.Number):
            raise ValueError('expect an numeric value')
        if value < 1e-06 or value > 1000000.0:
            raise ValueError('value is out of range')
        self.dactive_[0] = 1
        self.dval_[0] = float(value)


    @property
    def over_relaxation_alpha (self):
        '''type: float\nmin: 0.1, max: 1.618\nOver-relaxation factor'''
        return self.dval_[1]

    @over_relaxation_alpha.setter
    def over_relaxation_alpha(self, value):
        if not isinstance(value, _numbers.Number):
            raise ValueError('expect an numeric value')
        if value < 0.1 or value > 1.618:
            raise ValueError('value is out of range')
        self.dactive_[1] = 1
        self.dval_[1] = float(value)


    @property
    def TIME (self):
        '''type: float\nmin: 0.0, max: 100000000.0\nSolving time(s)'''
        return self.dval_[2]

    @TIME.setter
    def TIME(self, value):
        if not isinstance(value, _numbers.Number):
            raise ValueError('expect an numeric value')
        if value < 0.0 or value > 100000000.0:
            raise ValueError('value is out of range')
        self.dactive_[2] = 1
        self.dval_[2] = float(value)


    @property
    def PRIMAL_OBJ (self):
        '''type: float\nmin: -1e+30, max: 1e+30\nPrimal objective value'''
        return self.dval_[3]

    @PRIMAL_OBJ.setter
    def PRIMAL_OBJ(self, value):
        if not isinstance(value, _numbers.Number):
            raise ValueError('expect an numeric value')
        if value < -1e+30 or value > 1e+30:
            raise ValueError('value is out of range')
        self.dactive_[3] = 1
        self.dval_[3] = float(value)


    @property
    def ALM_OBJ (self):
        '''type: float\nmin: -1e+30, max: 1e+30\nArgument lagrange multipliers value'''
        return self.dval_[4]

    @ALM_OBJ.setter
    def ALM_OBJ(self, value):
        if not isinstance(value, _numbers.Number):
            raise ValueError('expect an numeric value')
        if value < -1e+30 or value > 1e+30:
            raise ValueError('value is out of range')
        self.dactive_[4] = 1
        self.dval_[4] = float(value)


    @property
    def PRIMAL_INF (self):
        '''type: float\nmin: 0.0, max: 1e+30\nPrimal residual'''
        return self.dval_[5]

    @PRIMAL_INF.setter
    def PRIMAL_INF(self, value):
        if not isinstance(value, _numbers.Number):
            raise ValueError('expect an numeric value')
        if value < 0.0 or value > 1e+30:
            raise ValueError('value is out of range')
        self.dactive_[5] = 1
        self.dval_[5] = float(value)


    @property
    def DUAL_INF (self):
        '''type: float\nmin: 0.0, max: 1e+30\nDual residual'''
        return self.dval_[6]

    @DUAL_INF.setter
    def DUAL_INF(self, value):
        if not isinstance(value, _numbers.Number):
            raise ValueError('expect an numeric value')
        if value < 0.0 or value > 1e+30:
            raise ValueError('value is out of range')
        self.dactive_[6] = 1
        self.dval_[6] = float(value)


    @property
    def RHO (self):
        '''type: float\nmin: 1e-06, max: 1000000.0\nConstraint penalty multiplier'''
        return self.dval_[7]

    @RHO.setter
    def RHO(self, value):
        if not isinstance(value, _numbers.Number):
            raise ValueError('expect an numeric value')
        if value < 1e-06 or value > 1000000.0:
            raise ValueError('value is out of range')
        self.dactive_[7] = 1
        self.dval_[7] = float(value)


    @property
    def ALPHA (self):
        '''type: float\nmin: 0.1, max: 1.618\nOver-relaxation alpha'''
        return self.dval_[8]

    @ALPHA.setter
    def ALPHA(self, value):
        if not isinstance(value, _numbers.Number):
            raise ValueError('expect an numeric value')
        if value < 0.1 or value > 1.618:
            raise ValueError('value is out of range')
        self.dactive_[8] = 1
        self.dval_[8] = float(value)


    @property
    def METRIC1 (self):
        '''type: float\nmin: 0.0, max: 1e+30\nOne metric for dual during solving (|1/rho y - Bz|_inf)'''
        return self.dval_[9]

    @METRIC1.setter
    def METRIC1(self, value):
        if not isinstance(value, _numbers.Number):
            raise ValueError('expect an numeric value')
        if value < 0.0 or value > 1e+30:
            raise ValueError('value is out of range')
        self.dactive_[9] = 1
        self.dval_[9] = float(value)



cdef void _tune(object pyfun, int* nactive, int* dactive, int* nval, double* dval):
    with (callbackLock):
        ctx = TuningContext()
        ctx.bind(nactive, dactive, nval, dval)
        try:
            pyfun(ctx)
        except Exception as e:
            _traceback.print_exc()

cdef void ctuner(object pyfun, int* nactive, int* dactive, int* nval, double* dval):
    gillock = pygillock()
    try:
        # Never inline the following function call
        # Otherwise python may raise error 'GIL released'
        _tune(pyfun, nactive, dactive, nval, dval)
    finally:
        pygilrelease(gillock)


cdef _unary_fun_impl(fun, expr):
    cdef int rdim
    cdef Constant c

    expr = ensure_array_type(expr)
    shapearr = _np.array(expr.shape, dtype=_np.int32)

    err = admm_shape_unary_fun(fun, shapearr.size,
        numpy_int_buffer(shapearr), &rdim, NULL)
    if err != 0: raise ADMMError(err)

    rshapearr = _np.zeros(rdim, dtype=_np.int32)
    err = admm_shape_unary_fun(fun, shapearr.size,
        numpy_int_buffer(shapearr), &rdim, numpy_int_buffer(rshapearr))

    if err != 0: raise ADMMError(err)

    if isConstExp(expr):
        c = Constant(expr)
        err = admm_tensor_unary_fun(fun, c.tensor_)
        if err != 0: raise ADMMError(err)
        return c

    return Expr(tuple(rshapearr.tolist()[:rdim]), fun, [expr])

cdef _binary_fun_impl(fun, expr1, expr2):
    cdef int rdim
    cdef Constant t1
    cdef Constant t2

    expr1 = ensure_array_type(expr1)
    expr2 = ensure_array_type(expr2)

    shapearr1 = _np.array(expr1.shape, dtype=_np.int32)
    shapearr2 = _np.array(expr2.shape, dtype=_np.int32)

    err = admm_shape_binary_fun(fun, shapearr1.size,
        numpy_int_buffer(shapearr1), shapearr2.size,
        numpy_int_buffer(shapearr2), &rdim, NULL)
    if err != 0: raise ADMMError(err)

    rshapearr = _np.zeros(rdim, dtype=_np.int32)
    err = admm_shape_binary_fun(fun, shapearr1.size,
        numpy_int_buffer(shapearr1), shapearr2.size,
        numpy_int_buffer(shapearr2), &rdim, numpy_int_buffer(rshapearr))
    if err != 0: raise ADMMError(err)


    if isConstExp(expr1) and isConstExp(expr2):
        t1 = Constant(expr1)
        t2 = Constant(expr2)
        err = admm_tensor_binary_fun(fun, t1.tensor_, t2.tensor_)
        if err != 0: raise ADMMError(err)
        return t1

    return Expr(tuple(rshapearr.tolist()[:rdim]), fun, [expr1, expr2])

cdef _ternary_fun_impl(fun, expr1, expr2, expr3):
    cdef int rdim
    cdef Constant t1
    cdef Constant t2
    cdef Constant t3

    expr1 = ensure_array_type(expr1)
    expr2 = ensure_array_type(expr2)
    expr3 = ensure_array_type(expr3)

    shapearr1 = _np.array(expr1.shape, dtype=_np.int32)
    shapearr2 = _np.array(expr2.shape, dtype=_np.int32)
    shapearr3 = _np.array(expr3.shape, dtype=_np.int32)

    err = admm_shape_ternary_fun(fun, shapearr1.size,
        numpy_int_buffer(shapearr1), shapearr2.size,
        numpy_int_buffer(shapearr2), shapearr3.size,
        numpy_int_buffer(shapearr3), &rdim, NULL)
    if err != 0: raise ADMMError(err)

    rshapearr = _np.zeros(rdim, dtype=_np.int32)
    err = admm_shape_ternary_fun(fun, shapearr1.size,
        numpy_int_buffer(shapearr1), shapearr2.size,
        numpy_int_buffer(shapearr2), shapearr3.size,
        numpy_int_buffer(shapearr3), &rdim, numpy_int_buffer(rshapearr))
    if err != 0: raise ADMMError(err)

    if isConstExp(expr1) and isConstExp(expr2) and isConstExp(expr3):
        t1 = Constant(expr1)
        t2 = Constant(expr2)
        t3 = Constant(expr3)
        err = admm_tensor_ternary_fun(fun, t1.tensor_, t2.tensor_, t3.tensor_)
        if err != 0: raise ADMMError(err)
        return t1

    return Expr(tuple(rshapearr.tolist()[:rdim]), fun, [expr1, expr2, expr3])




def abs(x):
    '''\nGet the absolute value for an expression.\n\nParameters\n----------\nx: Union[TensorLike, ArrayLike]\n\n  The expression.\n  \nReturns\n-------\nUnion[Expr, Constant]\n\nThe absolute value.\n\n\n\n\n'''
    return _unary_fun_impl(101, x)
def exp(x):
    '''\nReturn e ^ x.\n\nParameters\n----------\nx: Union[TensorLike, ArrayLike]\n\n  The expression for exponent.\n  \nReturns\n-------\nUnion[Expr, Constant]\n\nThe result expression.\n\n\n\n\n'''
    return _unary_fun_impl(102, x)
def norm(x, ord=None):
    '''\nCompute the norm for an expression or constant.\n\nParameters\n----------\nx: Union[TensorLike, ArrayLike]\n\n  The expression or constant.\n  \nord: Union[int, str] = None\n\n  The norm level:\n  \n    * None - level 2 norm for vector and Frobenius norm for matrix.\n  \n    * 1 - for level 1 norm. It is, sum(abs(x)) for vector, and for matrix, max column\n      sum of absolute values.\n  \n    * 2 - for level 2 norm. It is, sqrt(sum(x^2)) for vector, and largest singular\n      value for matrix.\n  \n    * inf - for inf norm. It is, max(abs(x)) for vector, and max row sum of absolute\n      values for matrix.\n  \n    * 'fro' - for frobenius norm. It is, sqrt(sum(x^2)) for matrix.\n  \n    * 'nuc' - for nuclear norm. It is, sum for all singular values.\n  \nReturns\n-------\nUnion[Expr, Constant]\n\nThe scalar norm value.\n\n\n\n\n'''
    if ord==1: return _unary_fun_impl(103, x)
    if ord==2: return _unary_fun_impl(104, x)
    if ord=='fro': return _unary_fun_impl(105, x)
    if ord==inf: return _unary_fun_impl(116, x)
    if ord==None: return _unary_fun_impl(117, x)
    if ord=='nuc': return _unary_fun_impl(121, x)
    raise ValueError("unexpected argument(s)")
def entropy(x):
    '''\nReturn a tensor, each element indicates the result of x * log(x).\n\nParameters\n----------\nx: Union[TensorLike, ArrayLike]\n\n  The expression which requires each element to be greater than 0.\n  \nReturns\n-------\nUnion[Expr, Constant]\n\nThe result tensor.\n\nNotes\n-----\n\nStandard Shannon entropy: -sum(x * log(x)), that is: -sum(entropy(x))\n\nExamples\n--------\n\n\n\n  >>> c = numpy.square(numpy.random.randn(10))\n\n  >>> scipy.stats.entropy(c) + numpy.sum(entropy(c / numpy.sum(c)))\n\n  0.0\n\n\n\n\n\n\n'''
    return _unary_fun_impl(106, x)
def log(x):
    '''\nReturn log(x).\n\nParameters\n----------\nx: Union[TensorLike, ArrayLike]\n\n  The argument for log.\n  \nReturns\n-------\nUnion[Expr, Constant]\n\nThe result.\n\n\n\n\n'''
    return _unary_fun_impl(107, x)
def square(x):
    '''\nCompute x ^ 2 elementwise.\n\nParameters\n----------\nx: Union[TensorLike, ArrayLike]\n\n  The source tensor.\n  \nReturns\n-------\nUnion[Expr, Constant]\n\nThe result tensor.\n\n\n\n\n'''
    return _unary_fun_impl(109, x)
def sqrt(x):
    '''\nCompute x ^ 1/2 elementwise.\n\nParameters\n----------\nx: Union[TensorLike, ArrayLike]\n\n  The source tensor.\n  \nReturns\n-------\nUnion[Expr, Constant]\n\nThe result tensor.\n\n\n\n\n'''
    return _unary_fun_impl(110, x)
def sum(x):
    '''\nCompute the summation of all elements in tensor.\n\nParameters\n----------\nx: Union[TensorLike, ArrayLike]\n\n  The source tensor.\n  \nReturns\n-------\nUnion[Expr, Constant]\n\nThe result scalar.\n\n\n\n\n'''
    return _unary_fun_impl(111, x)
def diag(x):
    '''\nFor matrix, retrieve the elements in main diagonal as a vector. In this case it\nshould be a square matrix.\n\nFor vector, construct a diagonal matrix with this vector.\n\nParameters\n----------\nx: Union[TensorLike, ArrayLike]\n\n  The vector or matrix.\n  \nReturns\n-------\nUnion[Expr, Constant]\n\nThe result matrix or vector.\n\n\n\n\n'''
    return _unary_fun_impl(112, x)
def log_det(x):
    '''\nReturn a scalar which indicates the log-determinant result of a matrix.\n\nParameters\n----------\nx: Union[TensorLike, ArrayLike]\n\n  The expression which should be a square matrix.\n  \nReturns\n-------\nUnion[Expr, Constant]\n\nThe result scalar. Returns inf if `x` is not a strictly positive definite matrix.\n\n\n\n\n'''
    return _unary_fun_impl(113, x)
def trace(x):
    '''\nReturn a scalar which indicates the sum of the diagonal entries of a matrix.\n\nParameters\n----------\nx: Union[TensorLike, ArrayLike]\n\n  The expression.\n  \nReturns\n-------\nUnion[Expr, Constant]\n\nThe result scalar.\n\n\n\n\n'''
    return _unary_fun_impl(114, x)
def max(x):
    '''\nReturn a scalar which indicates the largest item in the tensor.\n\nParameters\n----------\nx: Union[TensorLike, ArrayLike]\n\n  The expression to which the maximum function will be applied.\n  \nReturns\n-------\nUnion[Expr, Constant]\n\nThe result scalar.\n\n\n\n\n'''
    return _unary_fun_impl(118, x)
def min(x):
    '''\nReturn a scalar which indicates the least item in the tensor.\n\nParameters\n----------\nx: Union[TensorLike, ArrayLike]\n\n  The expression to which the minimum function will be applied.\n  \nReturns\n-------\nUnion[Expr, Constant]\n\nThe result scalar.\n\n\n\n\n'''
    return _unary_fun_impl(119, x)
def squared_hinge(x):
    '''\nCompute max(1 - x, 0) ^ 2 elementwise.\n\nParameters\n----------\nx: Union[TensorLike, ArrayLike]\n\n  The source tensor.\n  \nReturns\n-------\nUnion[Expr, Constant]\n\nThe result tensor.\n\n\n\n\n'''
    return _unary_fun_impl(122, x)
def maximum(x, b):
    '''\nReturn a new tensor, each element of new tensor is the larger of the corresponding\nelements in `x` and `b`.\n\nParameters\n----------\nx: Union[TensorLike, ArrayLike]\n\n  The expression.\n  \nb: ArrayLike\n\n  The lower bound tensor constant.\n  \nReturns\n-------\nUnion[Expr, Constant]\n\nThe result expression.\n\n\n\n\n'''
    if isinstance(b, (Var, Expr)):
        raise TypeError("constant expression is expected for argument `b`")
    return _binary_fun_impl(201, x, b)
def minimum(x, b):
    '''\nReturn a new tensor, each element of new tensor is the smaller of the corresponding\nelements in `x` and `b`.\n\nParameters\n----------\nx: Union[TensorLike, ArrayLike]\n\n  The expression.\n  \nb: ArrayLike\n\n  The upper bound tensor constant.\n  \nReturns\n-------\nUnion[Expr, Constant]\n\nThe result expression.\n\n\n\n\n'''
    if isinstance(b, (Var, Expr)):
        raise TypeError("constant expression is expected for argument `b`")
    return _binary_fun_impl(202, x, b)
def power(x, p):
    '''\nReturn a tensor, each element indicates the result of an operation to raise `p`\nto the power separately.\n\nParameters\n----------\nx: Union[TensorLike, ArrayLike]\n\n  The expression `x`. When `0 < p < 1`, every element of `x` is required to be\n  greater than or equal to 0.\n  \np: ArrayLike\n\n  The scalar parameter `p` requires greater than 0.\n  \nReturns\n-------\nUnion[Expr, Constant]\n\nThe result tensor.\n\n\n\n\n'''
    if isinstance(p, (Var, Expr)):
        raise TypeError("constant expression is expected for argument `p`")
    return _binary_fun_impl(203, x, p)
def logistic(x, b=1):
    '''\nReturn a tensor, each element indicates the result of log(e ^ x + b).\n\nParameters\n----------\nx: Union[TensorLike, ArrayLike]\n\n  The input expression `x`.\n  \nb: ArrayLike = 1\n\n  The tensor parameter `b` in logistic function.\n  \nReturns\n-------\nUnion[Expr, Constant]\n\nThe result tensor.\n\n\n\n\n'''
    if isinstance(b, (Var, Expr)):
        raise TypeError("constant expression is expected for argument `b`")
    return _binary_fun_impl(204, x, b)
def huber(x, delta=1):
    '''\nReturn a tensor, each element indicates the result of huber function.\n\nParameters\n----------\nx: Union[TensorLike, ArrayLike]\n\n  The expression to which the huber function will be applied.\n  \ndelta: ArrayLike = 1\n\n  The threshold of huber function.\n  \nReturns\n-------\nUnion[Expr, Constant]\n\nThe result tensor.\n\n\n\n\n'''
    if isinstance(delta, (Var, Expr)):
        raise TypeError("constant expression is expected for argument `delta`")
    return _binary_fun_impl(205, x, delta)
def kl_div(p, q):
    '''\nReturn a tensor, each element indicates the result of p * log(p / q). The sum of\nthe result represents the Kullback-Leibler (KL) divergence between p and q.\n\nParameters\n----------\np: Union[TensorLike, ArrayLike]\n\n  The expression `p` which requires each element to be greater than 0.\n  \nq: Union[TensorLike, ArrayLike]\n\n  The expression `q` which requires each element to be greater than 0.\n  \nReturns\n-------\nUnion[Expr, Constant]\n\nThe result tensor.\n\nNotes\n-----\n\nStandard Kullback-Leibler divergence (relative entropy) is: sum(p * log(p / q)),\nthat is: sum(kl_div(p, q))\n\n\n\n\n\nExamples\n--------\n\n\n\n  >>> p = numpy.square(numpy.random.randn(10))\n\n  >>> q = numpy.square(numpy.random.randn(10))\n\n  >>> pnorm = p / numpy.sum(p)\n\n  >>> qnorm = q / numpy.sum(q)\n\n  >>> scipy.stats.entropy(p, q) - numpy.sum(kl_div(pnorm, qnorm))\n\n  0.0\n'''
    return _binary_fun_impl(206, p, q)
def bathtub(x, delta=1):
    '''\nReturn a tensor, each element indicates the result of w-insensitive loss function.\n\nParameters\n----------\nx: Union[TensorLike, ArrayLike]\n\n  The expression to which the w-insensitive loss function will be applied.\n  \ndelta: ArrayLike = 1\n\n  The threshold of w-insensitive loss function.\n  \nReturns\n-------\nUnion[Expr, Constant]\n\nThe result tensor.\n\n\n\n\n'''
    if isinstance(delta, (Var, Expr)):
        raise TypeError("constant expression is expected for argument `delta`")
    return _binary_fun_impl(207, x, delta)
def squared_bathtub(x, delta=1):
    '''\nReturn a tensor, each element indicates the result of squared w-insensitive loss\nfunction.\n\nParameters\n----------\nx: Union[TensorLike, ArrayLike]\n\n  The expression to which the squared w-insensitive loss will be applied.\n  \ndelta: ArrayLike = 1\n\n  The threshold of squared w-insensitive loss function.\n  \nReturns\n-------\nUnion[Expr, Constant]\n\nThe result tensor.\n\n\n\n\n'''
    if isinstance(delta, (Var, Expr)):
        raise TypeError("constant expression is expected for argument `delta`")
    return _binary_fun_impl(208, x, delta)
def vapnik(x, epsilon=0):
    '''\nReturn Vapnik loss: max(norm(x, 2) - epsilon, 0).\n\nParameters\n----------\nx: Union[TensorLike, ArrayLike]\n\n  The expression.\n  \nepsilon: ArrayLike = 0\n\n  The threshold.\n  \nReturns\n-------\nUnion[Expr, Constant]\n\nThe result scalar.\n\n\n\n\n'''
    if isinstance(epsilon, (Var, Expr)):
        raise TypeError("constant expression is expected for argument `epsilon`")
    return _binary_fun_impl(209, x, epsilon)
def conv2d(x, k, mode='same'):
    '''\nPerform 2d convolution. \n\nParameters\n----------\nx: Union[TensorLike, ArrayLike]\n\n  The expression, should be a matrix.\n  \nk: ArrayLike\n\n  Another matrix.\n  \nmode: str = 'same'\n\n  Padding strategy:\n  \n  Assume x has shape `(m, n)`, k has `(p, q)`\n  \n    * 'full': Fill with 0s, returns all elements. Result shape is `(m + p - 1, n + q\n      - 1)` .\n  \n    * 'same': Result shape is the same size as `x`, it is the sub matrix centered with\n      respect to the 'full' output.\n  \n    * 'valid': Return result containing only elements that do not rely on the padding.\n      Result shape is `(max(m, p) - min(m, p) + 1, max(n, q) - min(n, q) + 1)` .\n  \nReturns\n-------\nUnion[Expr, Constant]\n\nThe result matrix.\n\nNotes\n-----\n\nIf `mode` is 'valid', shapes for `x(m, n)` and `k(p, q)` should satisfy:\n\n`(m - p) * (n - q) >= 0`\n\nThat is, one matrix can be placed into another.\n\n\n\n\n'''
    if isinstance(k, (Var, Expr)):
        raise TypeError("constant expression is expected for argument `k`")
    if mode=='same': return _binary_fun_impl(210, x, k)
    if mode=='valid': return _binary_fun_impl(211, x, k)
    if mode=='full': return _binary_fun_impl(212, x, k)
    raise ValueError("unexpected argument(s)")
def corr2d(x, k, mode='same'):
    '''\nCompute cross-correlation. In some machine learning frameworks, convolution operator\nis actually cross-correlation (e.g. tensorflow.nn.conv2d).\n\nParameters\n----------\nx: Union[TensorLike, ArrayLike]\n\n  The expression, should be a matrix.\n  \nk: ArrayLike\n\n  Another matrix.\n  \nmode: str = 'same'\n\n  Padding strategy:\n  \n  Assume x has shape `(m, n)`, k has `(p, q)`\n  \n    * 'full': Fill with 0s, returns all elements. Result shape is `(m + p - 1, n + q\n      - 1)` .\n  \n    * 'same': Result shape is the same size as `x`, it is the sub matrix centered with\n      respect to the 'full' output.\n  \n    * 'valid': Return result containing only elements that do not rely on the padding.\n      Result shape is `(max(m, p) - min(m, p) + 1, max(n, q) - min(n, q) + 1)` .\n  \nReturns\n-------\nUnion[Expr, Constant]\n\nThe result matrix.\n\nNotes\n-----\n\nIf `mode` is 'valid', shapes for `x(m, n)` and `k(p, q)` should satisfy:\n\n`(m - p) * (n - q) >= 0`\n\nThat is, one matrix can be placed into another.\n\n\n\n\n'''
    if isinstance(k, (Var, Expr)):
        raise TypeError("constant expression is expected for argument `k`")
    if mode=='same': return _binary_fun_impl(220, x, k)
    if mode=='valid': return _binary_fun_impl(221, x, k)
    if mode=='full': return _binary_fun_impl(222, x, k)
    raise ValueError("unexpected argument(s)")
def tv2d(x, p=1):
    '''\nReturn total variation for matrix.\n\nParameters\n----------\nx: Union[TensorLike, ArrayLike]\n\n  The expression, should be a matrix.\n  \np: int = 1\n\n  The norm level, supports 1 or 2.\n  \nReturns\n-------\nUnion[Expr, Constant]\n\nThe result scalar.\n'''
    if isinstance(p, (Var, Expr)):
        raise TypeError("constant expression is expected for argument `p`")
    return _binary_fun_impl(223, x, p)
def inrange(x, lb, ub):
    '''\nReturn a tensor, contains only `inf` and `0`, each element indicates whether an\nelement in x is in range [lb, ub].\n\nParameters\n----------\nx: Union[TensorLike, ArrayLike]\n\n  The expression to be tested.\n  \nlb: ArrayLike\n\n  The lower bound constant. It can be broadcasted.\n  \nub: ArrayLike\n\n  The upper bound constant. It can be broadcasted.\n  \nReturns\n-------\nUnion[Expr, Constant]\n\nThe indicator tensor.\n\n\n\n\n'''
    if isinstance(lb, (Var, Expr)):
        raise TypeError("constant expression is expected for argument `lb`")
    if isinstance(ub, (Var, Expr)):
        raise TypeError("constant expression is expected for argument `ub`")
    return _ternary_fun_impl(301, x, lb, ub)
def tv1d(x, w = 1, p = 1):
    '''\nOne dimensional total variation.\n\nParameters\n----------\nx: Union[TensorLike, ArrayLike]\n\n  The expression, should be a vector.\n  \nw: ArrayLike = 1\n\n  The weights, can be broadcasted.\n  \np: int = 1\n\n  The norm level.\n  \nReturns\n-------\nUnion[Expr, Constant]\n\nThe result scalar.\n\n\n\n\n'''
    if isinstance(w, (Var, Expr)):
        raise TypeError("constant expression is expected for argument `w`")
    if isinstance(p, (Var, Expr)):
        raise TypeError("constant expression is expected for argument `p`")
    return _ternary_fun_impl(302, x, w, p)
def scalene(x, a=-1, b=1):
    '''\nReturn a new tensor, each element of which depends on the corresponding element\nof x\n\n  1. when x<0, element = ax\n\n  2. when x=0, element = 0\n\n  3. when x>0, element = bx\n\nParameters\n----------\nx: Union[TensorLike, ArrayLike]\n\n  The expression.\n  \na: ArrayLike = -1\n\n  The coefficient for negative entries.\n  \nb: ArrayLike = 1\n\n  The coefficient for positive entries.\n  \nReturns\n-------\nUnion[Expr, Constant]\n\nThe result expression.\n\n\n\n\n'''
    if isinstance(a, (Var, Expr)):
        raise TypeError("constant expression is expected for argument `a`")
    if isinstance(b, (Var, Expr)):
        raise TypeError("constant expression is expected for argument `b`")
    return _ternary_fun_impl(303, x, a, b)
def hstack(*tensors):
    '''\nStack expressions in sequence horizontally (column wise).\n\nParameters\n----------\n*tensors: Union[TensorLike, ArrayLike]\n\n  The expressions to stack.\n  \nReturns\n-------\nUnion[Expr, Constant]\n\nThe result expression.\n\n\n\n\n'''
    cdef tensor_t* tarr
    cdef int rdim
    cdef int* ndim
    cdef int** shape

    ID = 901

    nopr = len(tensors)
    t = [ensure_array_type(tensor) for tensor in tensors]
    arr = [_np.array(tensor.shape, dtype=_np.int32) for tensor in t]
    maxdim = _np.max([tensor.ndim for tensor in t])
    # shape_eval may promote dimensions (e.g. 1-D → 2-D), so allocate extra room
    _bufdim = maxdim + 1 if maxdim + 1 > 2 else 2
    rshapearr = _np.empty(_bufdim, dtype=_np.int32)

    ndim = <int*>malloc(sizeof(int) * nopr)
    shape = <int**>malloc(sizeof(int*) * nopr)

    try:
        for i in range(len(t)):
            ndim[i] = t[i].ndim
            shape[i] = numpy_int_buffer(arr[i])

        err = admm_shape_variadic_fun(ID, nopr, ndim, shape, &rdim, numpy_int_buffer(rshapearr))
        if err != 0: raise ADMMError(err)
    finally:
        free(ndim)
        free(shape)

    def merge(t, start, stop):
        numConst = stop - start
        constants = [Constant(t[i]) for i in range(start, stop)]
        tarr = <tensor_t*>malloc(sizeof(tensor_t) * numConst)
        try:
            for i in range(numConst):
                tarr[i] = (<Constant>(constants[i])).tensor_
            err = admm_tensor_variadic_fun(ID, numConst, tarr)
            if err != 0: raise ADMMError(err)
            return constants[0]
        finally:
            free(tarr)

    merged = []
    constStart = 0

    for i in range(len(t)):
        if not isConstExp(t[i]):
            numConst = i - constStart
            if numConst == 1:
                merged.append(t[constStart])
            elif numConst > 1:
                merged.append(merge(t, constStart, i))

            constStart = i + 1
            merged.append(t[i])

    numConst = len(t) - constStart
    if numConst == 1:
        merged.append(t[constStart])
    elif numConst > 1:
        merged.append(merge(t, constStart, len(t)))

    if len(merged) == 1:
        return merged[0]

    return Expr(tuple(rshapearr[:rdim].tolist()), ID, merged)


def vstack(*tensors):
    '''\nStack expressions in sequence vertically (row wise).\n\nParameters\n----------\n*tensors: Union[TensorLike, ArrayLike]\n\n  The expressions to stack.\n  \nReturns\n-------\nUnion[Expr, Constant]\n\nThe result expression.\n\n\n\n\n'''
    cdef tensor_t* tarr
    cdef int rdim
    cdef int* ndim
    cdef int** shape

    ID = 902

    nopr = len(tensors)
    t = [ensure_array_type(tensor) for tensor in tensors]
    arr = [_np.array(tensor.shape, dtype=_np.int32) for tensor in t]
    maxdim = _np.max([tensor.ndim for tensor in t])
    # shape_eval may promote dimensions (e.g. 1-D → 2-D), so allocate extra room
    _bufdim = maxdim + 1 if maxdim + 1 > 2 else 2
    rshapearr = _np.empty(_bufdim, dtype=_np.int32)

    ndim = <int*>malloc(sizeof(int) * nopr)
    shape = <int**>malloc(sizeof(int*) * nopr)

    try:
        for i in range(len(t)):
            ndim[i] = t[i].ndim
            shape[i] = numpy_int_buffer(arr[i])

        err = admm_shape_variadic_fun(ID, nopr, ndim, shape, &rdim, numpy_int_buffer(rshapearr))
        if err != 0: raise ADMMError(err)
    finally:
        free(ndim)
        free(shape)

    def merge(t, start, stop):
        numConst = stop - start
        constants = [Constant(t[i]) for i in range(start, stop)]
        tarr = <tensor_t*>malloc(sizeof(tensor_t) * numConst)
        try:
            for i in range(numConst):
                tarr[i] = (<Constant>(constants[i])).tensor_
            err = admm_tensor_variadic_fun(ID, numConst, tarr)
            if err != 0: raise ADMMError(err)
            return constants[0]
        finally:
            free(tarr)

    merged = []
    constStart = 0

    for i in range(len(t)):
        if not isConstExp(t[i]):
            numConst = i - constStart
            if numConst == 1:
                merged.append(t[constStart])
            elif numConst > 1:
                merged.append(merge(t, constStart, i))

            constStart = i + 1
            merged.append(t[i])

    numConst = len(t) - constStart
    if numConst == 1:
        merged.append(t[constStart])
    elif numConst > 1:
        merged.append(merge(t, constStart, len(t)))

    if len(merged) == 1:
        return merged[0]

    return Expr(tuple(rshapearr[:rdim].tolist()), ID, merged)


cdef class UDFBase(TensorLike):
    '''\nThe base class for user-defined functions. A subclass must implement arguments()\nand eval(), plus either argmin() (proximal operator path) or grad() (gradient\npath).\n\n\n\n\n'''
    cdef int index_
    cdef int type_

    @constant
    def index(self):
        return self.index_

    @constant
    def type(self):
        return AT_EXPR

    @constant
    def shape(self):
        # Check if it's illegal as early as possible
        # Method `shape` will be called for each time it participates arithmetic operation
        getUdfId(self)
        return tuple()

    def arguments(self):
        '''\nMethod to get function argument list. Each argument should be a Var or a non-const\nexpression.\n\nReturns\n-------\nlist\n\nA list of Var or Expr objects that this UDF operates on.\n\n\n\n\n'''
        raise NotImplementedError

    def eval(self, tensorlist):
        '''\nMethod to evaluate this function.\n\nFor indicator functions, return 0.0 if feasible and float("inf") otherwise.\n\nParameters\n----------\ntensorlist: list\n\n  List of `numpy.ndarray`. Each one is a value for corresponding variable associated.\n  \nReturns\n-------\nfloat\n\nThe function value. For indicator functions, return 0.0 if feasible and float("inf")\notherwise.\n\n\n\n\n'''
        raise NotImplementedError

    def argmin(self, lamb, tensorlist):
        '''\nMethod to minimize function value.\n\nThe implementation must solve: argmin_x { lamb * f(x) + (1/2)||x - v||^2 }, where\nv is the current iterate passed via tensorlist.\n\nFor indicator functions, the argmin reduces to projection onto the feasible set.\n\nParameters\n----------\nlamb: float\n\n  The penalty weight (rho) provided by the ADMM iteration. The argmin method must\n  solve: argmin_x { lamb * f(x) + (1/2)||x - v||^2 }.\n  \ntensorlist: list\n\n  List of `numpy.ndarray`, the current iterate values for each associated variable.\n  \nReturns\n-------\nlist\n\nThe variable value list that minimizes the proximal subproblem, or `None` to stop\nthe optimization.\n\n\n\n\n'''
        raise NotImplementedError

    def grad(self, tensorlist):
        '''Compute gradient of the UDF at the given point.'''
        raise NotImplementedError

cdef hasMethod(obj, fnames):
    for fun in fnames:
        if not hasattr(obj, fun) or not callable(getattr(obj, fun)):
            return False
        method = getattr(obj, fun)
        className = method.__qualname__[:-len(fun) - 1]
        if className == UDFBase.__qualname__:
            return False
    return True

cdef assertUdf(obj):
    has_argmin = hasMethod(obj, ("arguments", "eval", "argmin"))
    has_grad = hasMethod(obj, ("arguments", "eval", "grad"))
    if not isinstance(obj, UDFBase) or not (has_argmin or has_grad):
        raise TypeError("not a valid UDF: must implement (arguments, eval, argmin) or (arguments, eval, grad)")

cdef int _udf_eval(void* userdata, int nexprs, int* ndims, int* shapes, double* tensors, double* data):
    cdef object udf
    cdef size_t dimoffset
    cdef size_t dataoffset

    dimoffset = 0
    dataoffset = 0

    try:
        udf = <object>userdata
        arrays = []
        for i in range(nexprs):
            shapelist = []
            for j in range(ndims[i]):
                shapelist.append(shapes[dimoffset])
                dimoffset += 1

            ndarr = _np.empty(tuple(shapelist), dtype=_np.float64)
            numpy_copy_ptr_to_arr(tensors + dataoffset, ndarr)
            dataoffset += _np.prod(ndarr.shape)
            arrays.append(ndarr)

        result = udf.eval(arrays)

        if isinstance(result, _np.ndarray) and _np.prod(result.shape) != 1:
            raise ValueError("{}.eval is expected to return a scalar value".format(type(udf).__name__))

        if isinstance(result, _np.ndarray):
            result = result.flat[0]
        
        if result is None or not isinstance(result, _numbers.Number):
            raise TypeError("{}.eval is expected to return a numeric value".format(type(udf).__name__))

        data[0] = float(result)
    except BaseException as e:
        _traceback.print_exc()
        return -1

    return 0

cdef int _udf_argmin(void* userdata, double lam, int nexprs, int* ndims, int* shapes, double* tensors):
    cdef object udf
    cdef size_t dimoffset
    cdef size_t dataoffset

    dimoffset = 0
    dataoffset = 0

    try:
        udf = <object>userdata
        arrays = []

        for i in range(nexprs):
            shapelist = []
            for j in range(ndims[i]):
                shapelist.append(shapes[dimoffset])
                dimoffset += 1
            ndarr = _np.empty(tuple(shapelist), dtype=_np.float64)
            numpy_copy_ptr_to_arr(tensors + dataoffset, ndarr)
            dataoffset += _np.prod(ndarr.shape)
            arrays.append(ndarr)

        result = udf.argmin(lam, arrays)

        if result is None:
            raise StopIteration("None value returned")

        if isinstance(result, (_numbers.Number, _np.ndarray, _sp.spmatrix, Constant)):
            result = [result]

        if not isinstance(result, (tuple, list)):
            raise TypeError("{}.argmin is expected to return a list".format(type(udf).__name__))
        
        if len(result) != nexprs:
            raise ValueError("{}.argmin is expected to return a list with {} elements".format(type(udf).__name__, nexprs))

        dataoffset = 0
        for i in range(len(result)):
            if isinstance(result[i], _numbers.Number):
                result[i] = _np.array(result[i], dtype=_np.float64)
            elif isinstance(result[i], _sp.spmatrix):
                result[i] = result[i].toarray().astype(dtype=_np.float64)
            elif isinstance(result[i], Constant):
                result[i] = result[i].asDense().data

            if not isinstance(result[i], _np.ndarray):
                result[i] = _np.array(result[i], dtype=_np.float64)

            if _np.prod(result[i].shape) == 1 and _np.prod(arrays[i].shape) == 1:
                pass
            elif result[i].shape != arrays[i].shape:
                raise ValueError("{}.argmin returned a tensor with mismatched shape".format(type(udf).__name__))

            numpy_copy_arr_to_ptr(result[i], tensors + dataoffset);
            dataoffset += _np.prod(result[i].shape)

    except BaseException as e:
        _traceback.print_exc()
        return -1

    return 0

cdef int _udf_grad(void* userdata, int nexprs, int* ndims, int* shapes, double* tensors, double* grad_out):
    cdef object udf
    cdef size_t dimoffset
    cdef size_t dataoffset

    dimoffset = 0
    dataoffset = 0

    try:
        udf = <object>userdata
        arrays = []
        for i in range(nexprs):
            shapelist = []
            for j in range(ndims[i]):
                shapelist.append(shapes[dimoffset])
                dimoffset += 1

            ndarr = _np.empty(tuple(shapelist), dtype=_np.float64)
            numpy_copy_ptr_to_arr(tensors + dataoffset, ndarr)
            dataoffset += _np.prod(ndarr.shape)
            arrays.append(ndarr)

        result = udf.grad(arrays)

        if result is None:
            raise StopIteration("None value returned from grad")

        if isinstance(result, (_numbers.Number, _np.ndarray, _sp.spmatrix, Constant)):
            result = [result]

        if not isinstance(result, (tuple, list)):
            raise TypeError("{}.grad is expected to return a list".format(type(udf).__name__))

        if len(result) != nexprs:
            raise ValueError("{}.grad is expected to return a list with {} elements".format(type(udf).__name__, nexprs))

        dataoffset = 0
        for i in range(len(result)):
            if isinstance(result[i], _numbers.Number):
                result[i] = _np.array(result[i], dtype=_np.float64)
            elif isinstance(result[i], _sp.spmatrix):
                result[i] = result[i].toarray().astype(dtype=_np.float64)
            elif isinstance(result[i], Constant):
                result[i] = result[i].asDense().data

            if not isinstance(result[i], _np.ndarray):
                result[i] = _np.array(result[i], dtype=_np.float64)

            if _np.prod(result[i].shape) == 1 and _np.prod(arrays[i].shape) == 1:
                pass
            elif result[i].shape != arrays[i].shape:
                raise ValueError("{}.grad returned a tensor with mismatched shape".format(type(udf).__name__))

            numpy_copy_arr_to_ptr(result[i], grad_out + dataoffset);
            dataoffset += _np.prod(result[i].shape)

    except BaseException as e:
        _traceback.print_exc()
        return -1

    return 0

cdef int udf_eval(void* userdata, int nexprs, int* ndims, int* shapes, double* tensors, double* data):
    gillock = pygillock()

    try:
        # Never inline the following function call
        # Otherwise python may raise error 'GIL released'
        return _udf_eval(userdata, nexprs, ndims, shapes, tensors, data)
    finally:
        pygilrelease(gillock)

cdef int udf_argmin(void* userdata, double lam, int nexprs, int* ndims, int* shapes, double* tensors):
    gillock = pygillock()

    try:
        # Never inline the following function call
        # Otherwise python may raise error 'GIL released'
        return _udf_argmin(userdata, lam, nexprs, ndims, shapes, tensors)
    finally:
        pygilrelease(gillock)

cdef int udf_grad(void* userdata, int nexprs, int* ndims, int* shapes, double* tensors, double* grad_out):
    gillock = pygillock()

    try:
        return _udf_grad(userdata, nexprs, ndims, shapes, tensors, grad_out)
    finally:
        pygilrelease(gillock)

# udf class type -> udfid
cdef dict udfs = {}

cdef getUdfId(obj):
    cdef int udfid
    assertUdf(obj)
    udft = type(obj)

    if udft in udfs:
        return udfs[udft]

    name = udft.__qualname__
    rawname = bytes(name, "utf8")

    has_argmin = hasMethod(obj, ("argmin",))
    has_grad = hasMethod(obj, ("grad",))

    if has_argmin:
        err = admm_custom_udf(rawname, <value_eval_t>udf_eval, <argmin_t>udf_argmin, &udfid)
    elif has_grad:
        err = admm_custom_udf_with_grad(rawname, <value_eval_t>udf_eval, <grad_t>udf_grad, &udfid)
    else:
        raise TypeError("UDF must implement argmin() or grad()")

    if err != 0: raise ADMMError(err)

    udfs[udft] = udfid
    return udfid



cdef class TensorLike:
    '''\nThe base class for `Constant`, `Var`, `Param` and `Expr`.\n\n\n\n\n'''

    @constant
    def ndim(self):
        '''type: int\n\nThe number of dimensions for this tensor.\n\n\n\n\n'''
        return len(self.shape)

    @constant
    def shape(self):
        '''type: Tuple[int]\n\nThe shape of this tensor.\n\n\n\n\n'''
        raise NotImplementedError()

    @constant
    def index(self):
        '''type: int\n\nIndex of this tensor. It is -1 until tensor is added to model.\n\n\n\n\n'''
        raise NotImplementedError()

    @constant
    def type(self):
        '''type: int\n\nThe type for this tensor. \n\nIt is: \n\n  * 2 for sparse constant.\n\n  * 3 for dense constant.\n\n  * 4 for parameter.\n\n  * 5 for variable.\n\n  * and 6, for expression.\n\n\n\n\n'''
        raise NotImplementedError()

    @constant
    def T(self):
        '''type: Expr\n\nTranspose of the tensor.\n\n\n\n\n'''
        cdef int rdim
        shapearr = _np.array(self.shape, dtype=_np.int32)
        rshapearr = _np.empty_like(shapearr)
        err = admm_shape_t(shapearr.size, numpy_int_buffer(shapearr), &rdim, numpy_int_buffer(rshapearr))

        if err != 0: raise ADMMError(err)
        return Expr(tuple(rshapearr.tolist()[:rdim]), OT_T, [self])

    def reshape(self, *shape):
        '''\nReshape this tensor, number of elements should not be changed between new shape\nand original shape.\n\nParameters\n----------\n*shape: int\n\n  The dimensions for new shape.\n  \nReturns\n-------\nExpr\n\nThe reshaped tensor.\n\n\n\n\n'''
        oldshapearr = _np.array(self.shape, dtype=_np.int32)
        newshapearr = _np.array(shape, dtype=_np.int32)
        err = admm_shape_reshape(oldshapearr.size, numpy_int_buffer(oldshapearr), 
                newshapearr.size, numpy_int_buffer(newshapearr))
        if err != 0: raise ADMMError(err)
        return Expr(tuple(shape), OT_RESHAPE, [tuple(shape), self])
    
    def __getitem__(self, slc):
        '''\nGet sub-tensor from this tensor.\n\nParameters\n----------\nslc: slice\n\n  The index range for each dimension for sub-tensor.\n  \nReturns\n-------\nExpr\n\nThe sub-tensor.\n\n\n\n\n'''
        cdef int rdim
        shapearr = _np.array(self.shape, dtype=_np.int32)
        rshapearr = _np.empty_like(shapearr)

        nranges = 1 if isinstance(slc, (_numbers.Number, slice)) else len(slc)
        shape = self.shape

        starts = _np.empty((nranges, ), dtype=_np.int32)
        stops = _np.empty((nranges, ), dtype=_np.int32)
        steps = _np.empty((nranges, ), dtype=_np.int32)

        if nranges == 1: slc = [slc]

        for i in range(nranges):
            if isinstance(slc[i], _numbers.Number):
                # For single indices, set stops to -1 to indicate single element
                starts[i], stops[i], steps[i] =   slc[i], -1, 1
            else:
                triple = slc[i].indices(self.shape[i])
                starts[i], stops[i], steps[i] = triple
            if -starts[i] > shape[i] or starts[i] >= shape[i]:
                raise IndexError("index is out of range")
            if starts[i] < 0: starts[i] = shape[i] + starts[i]

        err = admm_shape_slice(shapearr.size, numpy_int_buffer(shapearr), starts.size,
                numpy_int_buffer(starts), numpy_int_buffer(stops), numpy_int_buffer(steps),
                &rdim, numpy_int_buffer(rshapearr))

        slices = [(starts[i], stops[i], steps[i]) for i in range(starts.size)]

        if err != 0: raise ADMMError(err)
        return Expr(tuple(rshapearr.tolist()[:rdim]), OT_SLICE, [slices, self])

    
    def __neg__(self):
        '''\nReturns -tensor.\n\nReturns\n-------\nExpr\n\n-tensor.\n\n\n\n\n'''
        return Expr(tuple(self.shape), OT_NEG, [self])

    cdef _l_bin_opr(self, r, opr, matmul = False):
        cdef int rdim
        r = ensure_array_type(r)

        shapearr1 = _np.array(self.shape, dtype=_np.int32)
        shapearr2 = _np.array(r.shape, dtype=_np.int32)
        rshapearr = _np.empty((_builtins.max(shapearr1.size, shapearr2.size),), dtype=_np.int32)
        err = 0
        if matmul:
            err = admm_shape_mmul(shapearr1.size, numpy_int_buffer(shapearr1), 
                shapearr2.size, numpy_int_buffer(shapearr2),
                &rdim, numpy_int_buffer(rshapearr))
        else:
            err = admm_shape_add(shapearr1.size, numpy_int_buffer(shapearr1), 
                shapearr2.size, numpy_int_buffer(shapearr2),
                &rdim, numpy_int_buffer(rshapearr))

        if err != 0: raise ADMMError(err)
        return Expr(tuple(rshapearr.tolist()[:rdim]), opr, [self, r])

    cdef _r_bin_opr(self, l, opr, matmul = False):
        cdef int rdim
        l = ensure_array_type(l)

        shapearr1 = _np.array(l.shape, dtype=_np.int32)
        shapearr2 = _np.array(self.shape, dtype=_np.int32)

        rshapearr = _np.empty((_builtins.max(shapearr1.size, shapearr2.size),), dtype=_np.int32)

        err = 0
        if matmul:
            err = admm_shape_mmul(shapearr1.size, numpy_int_buffer(shapearr1), 
                shapearr2.size, numpy_int_buffer(shapearr2),
                &rdim, numpy_int_buffer(rshapearr))
        else:
            err = admm_shape_add(shapearr1.size, numpy_int_buffer(shapearr1), 
                shapearr2.size, numpy_int_buffer(shapearr2),
                &rdim, numpy_int_buffer(rshapearr))

        if err != 0: raise ADMMError(err)
        return Expr(tuple(rshapearr.tolist()[:rdim]), opr, [l, self])
    
    def __add__(self, r):
        '''\nTensor + object. Operands may be broadcasted.\n\nParameters\n----------\nr: Union[TensorLike, ArrayLike]\n\n  The right-hand-side object \n  \nReturns\n-------\nExpr\n\nThe result of add operation.\n\n\n\n\n'''
        return self._l_bin_opr(r, OT_ADD)

    def __radd__(self, l):
        '''\nObject + tensor.\n\nOperands may be broadcasted.\n\nParameters\n----------\nl: Union[TensorLike, ArrayLike]\n\n  The left-hand-side object.\n  \nReturns\n-------\nExpr\n\nThe result of add operation.\n\n\n\n\n'''
        return self._r_bin_opr(l, OT_ADD)
    
    def __sub__(self, r):
        '''\nTensor - object.\n\nOperands may be broadcasted.\n\nParameters\n----------\nr: Union[TensorLike, ArrayLike]\n\n  The right-hand-side object \n  \nReturns\n-------\nExpr\n\nThe result of subtraction.\n\n\n\n\n'''
        return self._l_bin_opr(r, OT_SUB)

    def __rsub__(self, l):
        '''\nObject - tensor.\n\nOperands may be broadcasted.\n\nParameters\n----------\nl: Union[TensorLike, ArrayLike]\n\n  The left-hand-side object.\n  \nReturns\n-------\nExpr\n\nThe result of subtraction.\n\n\n\n\n'''
        return self._r_bin_opr(l, OT_SUB)
    
    def __mul__(self, r):
        '''\nTensor * object.\n\nOperands may be broadcasted.\n\nParameters\n----------\nr: Union[TensorLike, ArrayLike]\n\n  The right-hand-side object \n  \nReturns\n-------\nExpr\n\nThe result of multiplication.\n\nNotes\n-----\n\nThis operation is element-wise multiplication.\n\n\n\n\n'''
        return self._l_bin_opr(r, OT_MUL)

    def __rmul__(self, l):
        '''\nObject * tensor.\n\nOperands may be broadcasted.\n\nParameters\n----------\nl: Union[TensorLike, ArrayLike]\n\n  The left-hand-side object.\n  \nReturns\n-------\nExpr\n\nThe result of multiplication.\n\nNotes\n-----\n\nThis operation is element-wise multiplication.\n\n\n\n\n'''
        return self._r_bin_opr(l, OT_MUL)
    
    def __truediv__(self, r):
        '''\nTensor / object.\n\nOperands may be broadcasted.\n\nParameters\n----------\nr: Union[TensorLike, ArrayLike]\n\n  The right-hand-side object \n  \nReturns\n-------\nExpr\n\nThe result of division.\n\nNotes\n-----\n\nThis operation is element-wise division.\n\n\n\n\n'''
        return self._l_bin_opr(r, OT_DIV)

    def __rtruediv__(self, l):
        '''\nTensor / object.\n\nOperands may be broadcasted.\n\nParameters\n----------\nr: Union[TensorLike, ArrayLike]\n\n  The right-hand-side object \n  \nReturns\n-------\nExpr\n\nThe result of division.\n\nNotes\n-----\n\nThis operation is element-wise division.\n\n\n\n\n'''
        return self._r_bin_opr(l, OT_DIV)
    
    def __matmul__(self, r):
        '''\nTensor @ object.\n\nOperands may be broadcasted.\n\nParameters\n----------\nr: Union[TensorLike, ArrayLike]\n\n  The right-hand-side object \n  \nReturns\n-------\nExpr\n\nThe result of multiplication operation.\n\nNotes\n-----\n\nThis operation is matrix multiplication. \n\n\n\n\n'''
        return self._l_bin_opr(r, OT_MML, True)

    def __rmatmul__(self, l):
        '''\nObject @ tensor.\n\nOperands may be broadcasted.\n\nParameters\n----------\nl: Union[TensorLike, ArrayLike]\n\n  The left-hand-side object.\n  \nReturns\n-------\nExpr\n\nThe result of multiplication.\n\nNotes\n-----\n\nThis operation is matrix multiplication.\n\n\n\n\n'''
        return self._r_bin_opr(l, OT_MML, True)
    
    def __pow__(self, r):
        '''\nTensor ** object.\n\nOperands may be broadcasted.\n\nParameters\n----------\nr: Union[TensorLike, ArrayLike]\n\n  The right-hand-side object \n  \nReturns\n-------\nExpr\n\nThe result of exponentiation.\n\nNotes\n-----\n\nThis operation is element-wise exponentiation.\n\n\n\n\n'''
        return self._l_bin_opr(r, OT_POW)

    def __rpow__(self, l):
        '''\nObject ** tensor.\n\nOperands may be broadcasted.\n\nParameters\n----------\nl: Union[TensorLike, ArrayLike]\n\n  The left-hand-side object.\n  \nReturns\n-------\nExpr\n\nThe result of exponentiation.\n\nNotes\n-----\n\nThis operation is element-wise exponentiation.\n\n\n\n\n'''
        return self._r_bin_opr(l, OT_POW)

    def __ge__(self, r):
        '''\nTensor >= object. Operands may be broadcasted.\n\nParameters\n----------\nr: Union[TensorLike, ArrayLike]\n\n  The right-hand-side for comparison.\n  \nReturns\n-------\nConstr\n\nThe constraint.\n\n\n\n\n'''
        return Constr(self, '>', r)

    def __le__(self, r):
        '''\nTensor <= object.\n\nOperands may be broadcasted.\n\nParameters\n----------\nr: Union[TensorLike, ArrayLike]\n\n  The right-hand-side for comparison.\n  \nReturns\n-------\nConstr\n\nThe constraint.\n\n\n\n\n'''
        return Constr(self, '<', r)

    def __eq__(self, r):
        '''\nTensor == object. Operands may be broadcasted.\n\nParameters\n----------\nr: Union[TensorLike, ArrayLike]\n\n  The right-hand-side for comparison.\n  \nReturns\n-------\nConstr\n\nThe constraint.\n\n\n\n\n'''
        return Constr(self, '=', r)

    def __lshift__(self, zero):
        '''\nConstraint: tensor is NSD.\n\nParameters\n----------\nr: int\n\n  Must be zero.\n  \nReturns\n-------\nConstr\n\nThe NSD constraint.\n\n\n\n\n'''
        if zero != 0:
            raise ValueError("rhs of an NSD constraint accepts only zero")
        return Constr(self, 'N', 0)

    def __rshift__(self, zero):
        '''\nConstraint: tensor is PSD.\n\nParameters\n----------\nr: int\n\n  Must be zero.\n  \nReturns\n-------\nConstr\n\nThe PSD constraint.\n\n\n\n\n'''
        if zero != 0:
            raise ValueError("rhs of an PSD constraint accepts only zero")
        return Constr(self, 'P', 0)

    def __rlshift__(self, zero):
        '''\nConstraint: tensor is PSD.\n\nParameters\n----------\nl: int\n\n  Must be zero.\n  \nReturns\n-------\nConstr\n\nThe PSD constraint.\n\n\n\n\n'''
        if zero != 0:
            raise ValueError("rhs of an PSD constraint accepts only zero")
        return Constr(self, 'P', 0)

    def __rrshift__(self, zero):
        '''\nConstraint: tensor is NSD.\n\nParameters\n----------\nl: int\n\n  Must be zero.\n  \nReturns\n-------\nConstr\n\nThe NSD constraint.\n\n\n\n\n'''
        if zero != 0:
            raise ValueError("rhs of an NSD constraint accepts only zero")
        return Constr(self, 'N', 0)

    @constant
    def __array_priority__(self):
        return 100000000.0
cdef class Constant(TensorLike):
    '''\nThis class represents a tensor constant.\n\nThe tensor may be dense or sparse, it is n-dimensional.\n\nFor example:\n\n\n\n  listdata = [[0, 1], [2, 3]]\n\n  ndarray = numpy.array(listdata)\n\n  coo_mat = scipy.sparse.coo_matrix(ndarray)\n\n  \n\n  # From scalar\n\n  scalar = Constant(0)\n\n  # From iterable\n\n  dense1 = Constant(listdata)\n\n  # From numpy ndarray\n\n  dense2 = Constant(ndarray)\n\n  # From shape, coordinates, values\n\n  sparse1 = Constant((2, 2), [(0, 0), (1, 1)], [1, 1])\n\n  # From shape, flat indices, values\n\n  sparse2 = Constant((2, 2), [0, 3], [1, 1])\n\n  # From scipy sparse matrix\n\n  sparse3 = Constant(coo_mat)\n\n\n\n\n\nUsually, users do not need to use this class, a list of number, a numpy ndarray,\neven a scipy sparse matrix may be preferred.\n\nA scenario for this class is, a sparse tensor with more than 2 dimensions can be\nand only can be created by using this class.\n\nFor example:\n\n\n\n  >>> A = [[1, 2], [3, 4]]\n\n  >>> X = Var(2, 2)\n\n  \n\n  >>> A @ X\n\n  Expr((2, 2), MATMUL('ndarray', 'Var'))\n\n  >>> numpy.array(A) @ X\n\n  Expr((2, 2), MATMUL('ndarray', 'Var'))\n\n  >>> Constant(A) @ X\n\n  Expr((2, 2), MATMUL('Constant', 'Var'))\n\n  >>> scipy.sparse.coo_matrix(A) @ X\n\n  Expr((2, 2), MATMUL('coo_matrix', 'Var'))\n\n  >>> # When A is a sparse cube\n\n  >>> Constant((2, 2, 2), range(8), range(8)) @ X\n\n  Expr((2, 2, 2), MATMUL('Constant', 'Var'))\n\n\n\nThis class is numpy compatible:\n\n\n\n  >>> c = Constant([[1, 2], [3, 4]])\n\n  >>> numpy.abs(norm(c, ord=2) - numpy.linalg.norm(c, ord=2)) < 1e-9\n\n  True\n\n\n\n\n\n\n'''
    cdef tensor_t tensor_
    cdef int freed_
    cdef Model model_
    cdef int id_

    def __init__(self, arr, ind=None, val=None):
        '''\nConstruct a constant.\n\nParameters\n----------\narr: Union[Constant, ArrayLike]\n\n  The value for this constant.\n  \n  Can be another constant, a scipy sparse matrix, an array-like object like a list,\n  or a numpy ndarray.\n  \nind: Optional[ArrayLike] = None\n\n  If ind is not None, it should be an array-like object to provide indices for sparse\n  tensor. In this case arr should be a shape.\n  \nval: Optional[ArrayLike] = None\n\n  If val is not None, it should be an array-like object to provide values for sparse\n  tensor. In this case arr should be a shape.\n  \n  \n  \n  \n  '''
        self.freed_ = 1
        self.id_ = -1
        self.model_ = None

        if isinstance(arr, Constant):
            err = admm_tensor_copy(&self.tensor_, (<Constant>arr).tensor_)
            if err != 0: raise ADMMError(err)
            self.freed_ = 0
            
        elif ind is None and val is None:
            arr = ensure_array_type(arr)
            shape = _np.array(arr.shape, dtype=_np.int32)

            if isinstance(arr, _sp.spmatrix):
                arr = arr.tocoo()
                if arr.nnz == 0:
                    # Empty sparse matrix: create as dense zeros
                    arr = _np.zeros(shape, dtype=_np.float64)
                    err = admm_create_dense(&self.tensor_, shape.size, numpy_int_buffer(shape), numpy_double_buffer(arr))
                else:
                    ind = arr.row * shape[1] + arr.col
                    ind = _np.ascontiguousarray(ind, dtype=_np.uint64)
                    val = _np.ascontiguousarray(arr.data, dtype=_np.float64)
                    err = admm_create_sparse(&self.tensor_, shape.size, numpy_int_buffer(shape),
                        arr.nnz, <size_t*>numpy_ulong_buffer(ind), numpy_double_buffer(val))
                if err != 0: raise ADMMError(err)
                self.freed_ = 0
            else:
                arr = _np.ascontiguousarray(arr, dtype=_np.float64)
                err = admm_create_dense(&self.tensor_, shape.size, numpy_int_buffer(shape), numpy_double_buffer(arr))
                if err != 0: raise ADMMError(err)
                self.freed_ = 0
        else:
            if arr is None or ind is None or val is None:
                raise TypeError("expect 3 arrays, shape, index, value")

            shape = ensure_array_type(arr)
            val = ensure_array_type(val)

            if len(ind) != len(val):
                raise ValueError("index has different size from value")

            if len(ind) > 0:
                if isinstance(ind[0], _numbers.Number):
                    ind = ensure_array_type(ind)
                else:
                    wts = [1]
                    for i in range(shape.size - 1): wts.append(wts[-1] * shape[-i - 1])
                    wts.reverse()
                    try:
                        ind = _np.matmul(ind, wts)
                    except:
                        raise ValueError("index has different number of dimension from shape")

            if not isinstance(shape, _np.ndarray) or not isinstance(ind, _np.ndarray) or not isinstance(val, _np.ndarray):
                raise TypeError("expect 3 arrays, shape, index, value")

            shape = _np.array(shape, dtype=_np.int32)
            ind = _np.ascontiguousarray(ind, dtype=_np.uint64)
            val = _np.ascontiguousarray(val, dtype=_np.float64)

            space = _np.prod(shape, dtype=_np.int64)
            if _np.any(ind >= space): raise IndexError("index is out of range")

            err = admm_create_sparse(&self.tensor_, shape.size, numpy_int_buffer(shape),
                    ind.size, <size_t*>numpy_ulong_buffer(ind), numpy_double_buffer(val))

            if err != 0: raise ADMMError(err)
            self.freed_ = 0

    cdef saved(self, Model model, int isdense, int cid):
        cdef int ndim
        cdef int nnz

        self.model_ = model
        self.id_ = cid
        self.dispose()

        err = admm_create_from_model(&self.tensor_, model.mdl_, isdense, cid)
        if err != 0: raise ADMMError(err)
        self.freed_ = 0
        

    @constant
    def index(self):
        '''type: int\n\nIndex of this tensor. It is -1 until tensor is added to model.\n\n\n\n\n'''
        return self.id_

    @constant
    def type(self):
        '''type: int\n\nThe type for this tensor. \n\nIt is: \n\n  * 2 for sparse constant.\n\n  * 3 for dense constant.\n\n  * 4 for parameter.\n\n  * 5 for variable.\n\n  * and 6, for expression.\n\n\n\n\n'''
        return AT_DENSE if self.isDense() else AT_SPARSE

    def isDense(self):
        '''\nCheck if this constant is a dense tensor.\n\nReturns\n-------\nbool\n\nTrue if constant is dense, False otherwise\n\n\n\n\n'''
        dense = admm_tensor_is_dense(self.tensor_)
        return dense != 0

    def isSparse(self):
        '''\nCheck if this constant is a sparse tensor.\n\nReturns\n-------\nbool\n\nTrue if constant is sparse, False otherwise\n\n\n\n\n'''
        return not self.isDense()

    @constant
    def data(self):
        '''type: Union[np.ndarray, Tuple[np.ndarray, np.ndarray]]\n\nThe content of this constant.\n\nIt is a numpy ndarray for dense. In case of sparse, this is a tuple contains 2\nndarray, the indices and values.\n\n\n\n\n'''
        cdef size_t nzs

        if self.isDense():
            data = _np.empty(self.shape, dtype=_np.float64)
            err = admm_tensor_get_dense(self.tensor_, numpy_double_buffer(data));
            if err != 0: raise ADMMError(err)
            return data
        else:
            err = admm_tensor_get_sparse(self.tensor_, &nzs, NULL, NULL)
            if err != 0: raise ADMMError(err)

            ind = _np.empty(nzs, dtype=_np.uint64)
            val = _np.empty(nzs, dtype=_np.float64)

            err = admm_tensor_get_sparse(self.tensor_, &nzs, <size_t*>numpy_ulong_buffer(ind), numpy_double_buffer(val))
            if err != 0: raise ADMMError(err)
            return (ind, val)

    @constant
    def ndim(self):
        '''type: int\n\nThe number of dimensions for this tensor.\n\n\n\n\n'''
        return len(self.shape)

    @constant
    def shape(self):
        '''type: Tuple[int]\n\nThe shape of this tensor.\n\n\n\n\n'''
        cdef int ndim

        err = admm_tensor_get_shape(self.tensor_, &ndim, NULL)
        if err != 0: raise ADMMError(err)

        shape = _np.empty(ndim, dtype=_np.int32)

        err = admm_tensor_get_shape(self.tensor_, &ndim, numpy_int_buffer(shape))
        if err != 0: raise ADMMError(err)
        return tuple(shape.tolist())


    def asScalar(self):
        '''\nConvert this tensor to a scalar value.\n\nReturns\n-------\nfloat\n\nThe value of only element contained by tensor. if tensor has more elements, this\nmethod raise exception.\n\n\n\n\n'''
        shape = self.shape
        if _np.prod(shape) != 1:
            raise ValueError("not a scalar")
        if self.isDense():
            return self.data.flat[0]
        else: return self.data[1].flat[0]

    def asDense(self):
        '''\nIf constant is sparse, make a dense copy for it.\n\nReturns\n-------\nConstant\n\nThe dense copy for sparse constant. No copy will be made if constant is dense.\n\n\n\n\n'''
        if self.isDense():
            return self
        else:
            res = Constant(self)
            err = admm_tensor_toggle_type((<Constant>res).tensor_)
            if err != 0: raise ADMMError(err)
            return res

    def asSparse(self):
        '''\nIf constant is dense, make a sparse copy for it.\n\nReturns\n-------\nConstant\n\nThe sparse copy for dense constant. No copy will be made if constant is sparse.\n\n\n\n\n'''
        if self.isSparse():
            return self
        else:
            res = Constant(self)
            err = admm_tensor_toggle_type((<Constant>res).tensor_)
            if err != 0: raise ADMMError(err)
            return res

    def hasAttr(self, **kws):
        '''\nCheck if constant has a specified attribute.\n\nParameters\n----------\n**kwargs: bool\n\n  The attribute to check. Attributes include:\n  \n    * nonneg\n  \n    * nonpos\n  \n    * symmetric\n  \n    * diag\n  \n    * PSD\n  \n    * NSD\n  \n    * pos\n  \n    * neg\n  \n  Value of this argument should be True. A False-valued argument will be ignored.\n  \nReturns\n-------\nbool\n\nTrue if constant has specified attribute.\n\nExamples\n--------\n\n\n\n  c = Constant([[1, 0], [0, 1]])\n\n  c.hasAttr(symmetric=True)\n\n  # Expression is True\n\n  c.hasAttr(neg=True)\n\n  # Expression is False\n\n\n\n\n\n\n'''
        cdef int attr
        cdef int res

        attr = 0

        for key in kws:
            if key not in tensorattrnames:
                raise KeyError("unknown attr {}".format(key))
            if kws[key]:
                attr |= (1 << tensorattrnames[key])

        err = admm_tensor_has_attr(self.tensor_, attr, &res)
        if err != 0:
            # C backend does not support attr queries on user-created tensors
            # (only model-registered ones). User-created Constants have no
            # declared attributes, so the correct answer is False.
            return False
        return res != 0

    @constant
    def T(self):
        '''type: Constant\n\nTranspose of the constant.\n\n\n\n\n'''
        res = Constant(self)
        err = admm_tensor_unary_op((<Constant>res).tensor_, OT_T)
        if err != 0: raise ADMMError(err)
        return res

    def reshape(self, *shape):
        '''\nReshape this constant, number of elements should not be changed between new shape\nand original shape.\n\nParameters\n----------\n*shape: int\n\n  The dimensions for new shape.\n  \nReturns\n-------\nConstant\n\nThe reshaped constant.\n\n\n\n\n'''
        res = Constant(self)
        shapearr = _np.array(shape, dtype=_np.int32)
        err = admm_tensor_reshape_op((<Constant>res).tensor_, shapearr.size, numpy_int_buffer(shapearr))
        if err != 0: raise ADMMError(err)
        return res

    def __neg__(self):
        '''\nReturns -constant.\n\nReturns\n-------\nConstant\n\n-constant.\n\n\n\n\n'''
        res = Constant(self)
        err = admm_tensor_unary_op((<Constant>res).tensor_, OT_NEG)
        if err != 0: raise ADMMError(err)
        return res

    def __getitem__(self, slc):
        '''\nGet sub-tensor from this constant.\n\nParameters\n----------\nslc: slice\n\n  The index range for each dimension for sub-tensor.\n  \nReturns\n-------\nConstant\n\nThe sub-tensor.\n\n\n\n\n'''
        res = Constant(0)

        nranges = 1 if isinstance(slc, (_numbers.Number, slice)) else len(slc)

        shape = self.shape

        starts = _np.empty((nranges, ), dtype=_np.int32)
        stops = _np.empty((nranges, ), dtype=_np.int32)
        steps = _np.empty((nranges, ), dtype=_np.int32)

        if nranges == 1: slc = [slc]

        for i in range(nranges):
            if isinstance(slc[i], _numbers.Number):
                starts[i], stops[i], steps[i] = slc[i], -1, 1
            else:
                triple = slc[i].indices(self.shape[i])
                starts[i], stops[i], steps[i] = triple
            if -starts[i] > shape[i] or starts[i] >= shape[i]:
                raise IndexError("index is out of range")
            if starts[i] < 0: starts[i] = shape[i] + starts[i]

        err = admm_tensor_slice_op(self.tensor_, nranges, numpy_int_buffer(starts), 
                numpy_int_buffer(stops), numpy_int_buffer(steps), (<Constant>res).tensor_)

        if err != 0: raise ADMMError(err)
        return res

    cdef _binop(self, l, r, op):
        # Invoke super op
        if not isinstance(l, Constant) and isinstance(l, TensorLike):
            return None
        if not isinstance(r, Constant) and isinstance(r, TensorLike):
            return None

        # First operand l expected to be a copy
        l = Constant(l)
        # Second operand r expected to be Constant typed
        if not isinstance(r, Constant):
            r = Constant(r)        

        err = admm_tensor_binary_op((<Constant>l).tensor_, (<Constant>r).tensor_, op)
        if err != 0: raise ADMMError(err)
        return l

    def __add__(self, r):
        '''\nConstant + object. Operands may be broadcasted.\n\nParameters\n----------\nr: Union[TensorLike, ArrayLike]\n\n  The right-hand-side object \n  \nReturns\n-------\nUnion[Constant, Expr]\n\nThe result of add operation.\n\n\n\n\n'''
        res = self._binop(self, r, OT_ADD)
        return res if res is not None else super().__add__(r)

    def __radd__(self, l):
        '''\nobject + constant. Operands may be broadcasted.\n\nParameters\n----------\nl: Union[TensorLike, ArrayLike]\n\n  The left-hand-side object.\n  \nReturns\n-------\nUnion[Constant, Expr]\n\nThe result of add operation.\n\n\n\n\n'''
        res = self._binop(l, self, OT_ADD)
        return res if res is not None else super().__radd__(l)

    def __sub__(self, r):
        '''\nConstant - object. Operands may be broadcasted.\n\nParameters\n----------\nr: Union[TensorLike, ArrayLike]\n\n  The right-hand-side object \n  \nReturns\n-------\nUnion[Constant, Expr]\n\nThe result of subtraction.\n\n\n\n\n'''
        res = self._binop(self, r, OT_SUB)
        return res if res is not None else super().__sub__(r)

    def __rsub__(self, l):
        '''\nobject - constant. Operands may be broadcasted.\n\nParameters\n----------\nl: Union[TensorLike, ArrayLike]\n\n  The left-hand-side object.\n  \nReturns\n-------\nUnion[Constant, Expr]\n\nThe result of subtraction.\n\n\n\n\n'''
        res = self._binop(l, self, OT_SUB)
        return res if res is not None else super().__rsub__(l)

    def __mul__(self, r):
        '''\nConstant * object. Operands may be broadcasted.\n\nParameters\n----------\nr: Union[TensorLike, ArrayLike]\n\n  The right-hand-side object \n  \nReturns\n-------\nUnion[Constant, Expr]\n\nThe result of multiplication.\n\nNotes\n-----\n\nThis operation is element-wise multiplication.\n\n\n\n\n'''
        res = self._binop(self, r, OT_MUL)
        return res if res is not None else super().__mul__(r)

    def __rmul__(self, l):
        '''\nobject * constant. Operands may be broadcasted.\n\nParameters\n----------\nl: Union[TensorLike, ArrayLike]\n\n  The left-hand-side object.\n  \nReturns\n-------\nUnion[Constant, Expr]\n\nThe result of multiplication.\n\nNotes\n-----\n\nThis operation is element-wise multiplication.\n\n\n\n\n'''
        res = self._binop(l, self, OT_MUL)
        return res if res is not None else super().__rmul__(l)

    def __truediv__(self, r):
        '''\nConstant * object. Operands may be broadcasted.\n\nParameters\n----------\nr: Union[TensorLike, ArrayLike]\n\n  The right-hand-side object \n  \nReturns\n-------\nUnion[Constant, Expr]\n\nThe result of multiplication.\n\nNotes\n-----\n\nThis operation is element-wise multiplication.\n\n\n\n\n'''
        res = self._binop(self, r, OT_DIV)
        return res if res is not None else super().__truediv__(r)

    def __rtruediv__(self, l):
        '''\nobject * constant. Operands may be broadcasted.\n\nParameters\n----------\nl: Union[TensorLike, ArrayLike]\n\n  The left-hand-side object.\n  \nReturns\n-------\nUnion[Constant, Expr]\n\nThe result of multiplication.\n\nNotes\n-----\n\nThis operation is element-wise multiplication.\n\n\n\n\n'''
        res = self._binop(l, self, OT_DIV)
        return res if res is not None else super().__rtruediv__(l)

    def __matmul__(self, r):
        '''\nConstant @ object. Operands may be broadcasted.\n\nParameters\n----------\nr: Union[TensorLike, ArrayLike]\n\n  The right-hand-side object \n  \nReturns\n-------\nUnion[Constant, Expr]\n\nThe result of multiplication operation.\n\nNotes\n-----\n\nThis operation is matrix multiplication. \n\n\n\n\n'''
        res = self._binop(self, r, OT_MML)
        return res if res is not None else super().__matmul__(r)

    def __rmatmul__(self, l):
        '''\nobject @ constant. Operands may be broadcasted.\n\nParameters\n----------\nl: Union[TensorLike, ArrayLike]\n\n  The left-hand-side object.\n  \nReturns\n-------\nUnion[Constant, Expr]\n\nThe result of multiplication.\n\nNotes\n-----\n\nThis operation is matrix multiplication.\n\n\n\n\n'''
        res = self._binop(l, self, OT_MML)
        return res if res is not None else super().__rmatmul__(l)
    
    def __pow__(self, r):
        '''\nConstant ** object. Operands may be broadcasted.\n\nParameters\n----------\nr: Union[TensorLike, ArrayLike]\n\n  The right-hand-side object \n  \nReturns\n-------\nUnion[Constant, Expr]\n\nThe result of exponentiation.\n\nNotes\n-----\n\nThis operation is element-wise exponentiation.\n\n\n\n\n'''
        res = self._binop(self, r, OT_POW)
        return res if res is not None else super().__pow__(r)

    def __rpow__(self, l):
        '''\nobject ** constant. Operands may be broadcasted.\n\nParameters\n----------\nl: Union[TensorLike, ArrayLike]\n\n  The left-hand-side object.\n  \nReturns\n-------\nUnion[Constant, Expr]\n\nThe result of exponentiation.\n\nNotes\n-----\n\nThis operation is element-wise exponentiation.\n\n\n\n\n'''
        res = self._binop(l, self, OT_POW)
        return res if res is not None else super().__rpow__(l)

    def dispose(self):
        '''\nInstantly free memory for constant object, or constant may be freed automatically\nby garbage collector.\n\n\n\n\n'''
        if self.freed_ == 0:
            self.freed_ = 1
            admm_destroy_tensor(self.tensor_)

    def __str__(self):
        cdef size_t nzs
        shape = self.shape

        if self.isDense():
            return self.data.__str__()
        else:
            ind, val = self.data
            
            wts = [1]
            for i in range(len(shape)): wts.append(wts[-1] * shape[-i - 1])
            wts.pop()

            result = str(shape)

            minval = inf
            maxval = -1
            hasminus = False

            fmt = "{:.8}"

            r = range(val.size)
            if val.size > 32:
                r = list(range(16))
                r += list(range(val.size - 16, val.size))
            for i in r:
                v = _builtins.abs(val[i])
                minval = _builtins.min(minval, v)
                maxval = _builtins.max(maxval, v)

                if 1000 * (_builtins.max(minval, 1)) <= maxval:
                    fmt = "{:.8e}"
                if str(val[i]).startswith("-"):
                    hasminus = True

            for i in r:
                cord = []
                index = ind[i]
                for j in range(len(shape)):
                    cord.append(int(index // wts[-j - 1]))
                    index %= wts[-j - 1]
                result += "\n"
                value = fmt.format(val[i])
                if not value.startswith('-') and hasminus: value = " " + value
                result += str(tuple(cord)) + " = " + value

                if isinstance(r, list) and i == 15:
                    result += "\n... {} nonzero(s) omitted ...".format(val.size - 32)

            return result


    def __repr__(self):
        if self.isDense():
            return "Dense({}\n{})".format(self.shape, self.__str__())
        return "Sparse({})".format(self.__str__())

    def __del__(self):
        self.dispose()

    def __dealloc__(self):
        self.dispose()

    def __array__(self, dtype = None):
        arr = self if self.isDense() else self.asDense()
        data = arr.data
        return data if dtype is None else data.astype(dtype)


cdef class Param(TensorLike):
    '''\nParameter is a place-holder for constant at modeling phase. Parameter has a shape\nbut its data is undetermined at modeling phase.\n\n\n\n\n'''
    cdef Model model_
    cdef int id_
    cdef str name_
    cdef tuple shape_
    cdef int attr_

    def __init__(self, name, *shape, **attr):
        '''\nConstruct a new parameter.\n\nParameters\n----------\nname: str\n\n  The name for new parameter.\n  \n*shape: int\n\n  The parameter shape.\n  \n**attr: bool\n\n  The attribute parameter has. Attributes include:\n  \n    * nonneg\n  \n    * nonpos\n  \n    * symmetric\n  \n    * diag\n  \n    * PSD\n  \n    * NSD\n  \n    * pos\n  \n    * neg\n  '''
        if not isinstance(name, str): raise TypeError("name expect a string")
        if name is None or len(name.strip()) == 0: raise ValueError("invalid value for name")
        if not isinstance(shape, tuple): raise TypeError("shape expect a tuple")

        for c in name:
            if not (c.isalnum() or c == '_'):
                raise ValueError(f'parameter name must contain only letters, digits, and underscores (got {c!r})')

        self.name_ = name

        self.shape_ = shape

        # Unwrap single-element tuple shape: Param('p', (3, 4)) → shape_ = (3, 4)
        if len(self.shape_) == 1 and isinstance(self.shape_[0], (tuple, list)):
            self.shape_ = tuple(self.shape_[0])

        # Validate dimensions: must be positive integers
        _validated = []
        for _d in self.shape_:
            try:
                _di = int(_d)
            except (TypeError, ValueError):
                raise TypeError("parameter dimensions must be integers, got {}".format(type(_d).__name__))
            if _di <= 0:
                raise ValueError("parameter dimensions must be positive, got {}".format(_di))
            _validated.append(_di)
        self.shape_ = tuple(_validated)

        self.attr_ = 0
        self.id_ = -1

        for key in attr:
            if key not in tensorattrnames:
                raise KeyError("unknown attribute `{}`".format(key))
            if not attr[key]: continue
            if self.attr_ != 0:
                raise ValueError("accept only 1 attribute")
            self.attr_ = 1 << tensorattrnames[key]

    @constant
    def shape(self):
        '''type: Tuple[int]\n\nThe shape of this tensor.\n\n\n\n\n'''
        cdef int dim

        if self.index < 0:
            return self.shape_

        err = admm_get_param(self.model_.mdl_, self.id_, &dim, NULL, NULL, NULL);
        if err != 0: raise ADMMError(err)

        shape = _np.empty((dim, ), dtype=_np.int32)
        err = admm_get_param(self.model_.mdl_, self.id_, &dim, numpy_int_buffer(shape), NULL, NULL);
        if err != 0: raise ADMMError(err)

        return tuple(shape.tolist())        

    @constant
    def attr(self):
        '''type: int\n\nThe declared attribute for parameter.\n\nAttributes include:\n\n  * nonneg = 0\n\n  * nonpos = 1\n\n  * symmetric = 2\n\n  * diag = 3\n\n  * PSD = 4\n\n  * NSD = 5\n\n  * pos = 6\n\n  * neg = 7\n\nFor example, if parameter is declared as PSD, this value is 16(1 << 4).\n\n\n\n\n'''
        cdef int attr
        if self.index < 0:
            return self.attr_
        err = admm_get_param(self.model_.mdl_, self.id_, NULL, NULL, NULL, &attr)
        if err != 0: raise ADMMError(err)
        return attr

    @constant
    def index(self):
        '''type: int\n\nIndex of this tensor. It is -1 until tensor is added to model.\n\n\n\n\n'''
        return self.id_

    @constant
    def name(self):
        '''type: str\n\nThe name of this parameter\n\n\n\n\n'''
        cdef char* name

        if self.index < 0:
            return self.name_

        err = admm_get_param(self.model_.mdl_, self.id_, NULL, NULL, &name, NULL);
        if err != 0: raise ADMMError(err)
        return str(name, "utf8")

    @constant
    def type(self):
        '''type: int\n\nThe type for this tensor. \n\nIt is: \n\n  * 2 for sparse constant.\n\n  * 3 for dense constant.\n\n  * 4 for parameter.\n\n  * 5 for variable.\n\n  * and 6, for expression.\n\n\n\n\n'''
        return AT_PARAMETER
        
    def __repr__(self):
        return "Param({}, {})".format(self.name, self.shape)

    def __str__(self):
        return "Param({}, {})".format(self.name, self.shape)

cdef class Var(TensorLike):
    '''\nThe decision variable to be optimized.\n\n\n\n\n'''
    cdef Model model_
    cdef int id_
    cdef str name_
    cdef tuple shape_
    cdef int attr_
    cdef Constant start_

    def __init__(self, *shape, **attr):
        '''\nConstruct a new variable.\n\nParameters\n----------\nname: str = None\n\n  The name for new variable.\n  \n*shape: int\n\n  The variable shape.\n  \n**attr: bool\n\n  The attribute variable has.\n  \n  Attributes include:\n  \n    * nonneg\n  \n    * nonpos\n  \n    * symmetric\n  \n    * diag\n  \n    * PSD\n  \n    * NSD\n  \n    * pos\n  \n    * neg\n  '''
        if len(shape) > 0 and isinstance(shape[0], (str, bytes, bytearray)):
            # Variable name specified
            name = shape[0]
            if isinstance(name, (bytes, bytearray)):
                name = str(name, "utf8")
            if name.startswith('$'):
                raise ValueError('user specified variable name must not start with $')
            for c in name:
                if not (c.isalnum() or c == '_'):
                    raise ValueError(f'variable name must contain only letters, digits, and underscores (got {c!r})')
            self.name_ = name
            self.shape_ = tuple(shape[1:])
        else:
            self.name_ = None
            self.shape_ = tuple(shape)

        # Unwrap single-element tuple shape: Var('X', (3, 4)) → shape_ = (3, 4)
        if len(self.shape_) == 1 and isinstance(self.shape_[0], (tuple, list)):
            self.shape_ = tuple(self.shape_[0])

        # Validate dimensions: must be non-negative integers
        _validated = []
        for _d in self.shape_:
            try:
                _di = int(_d)
            except (TypeError, ValueError):
                raise TypeError("variable dimensions must be integers, got {}".format(type(_d).__name__))
            if _di <= 0:
                raise ValueError("variable dimensions must be positive, got {}".format(_di))
            _validated.append(_di)
        self.shape_ = tuple(_validated)

        self.attr_ = 0
        self.id_ = -1

        for key in attr:
            if key not in tensorattrnames:
                raise KeyError("unknown attribute `{}`".format(key))
            if not attr[key]: continue
            if self.attr_ != 0:
                raise ValueError("accept only 1 attribute")
            self.attr_ = 1 << tensorattrnames[key]

        self.start_ = None

    @property
    def start(self):
        '''type: ArrayLike\n\nThe value for variable to warm start. Its initial value is None, which indicates\nthat no start value specified.\n\n\n\n\n'''
        return self.start_

    @start.setter
    def start(self, value):
        self.start_ = Constant(value)
        if self.start_.shape != self.shape:
            self.start_ = None
            raise ValueError("mismatched shape")

    @constant
    def shape(self):
        '''type: Tuple[int]\n\nThe shape of this tensor.\n\n\n\n\n'''
        cdef int dim

        if self.index < 0:
            return self.shape_

        err = admm_get_var(self.model_.mdl_, self.id_, &dim, NULL, NULL, NULL);
        if err != 0: raise ADMMError(err)

        shape = _np.empty((dim, ), dtype=_np.int32)
        err = admm_get_var(self.model_.mdl_, self.id_, &dim, numpy_int_buffer(shape), NULL, NULL);
        if err != 0: raise ADMMError(err)

        return tuple(shape.tolist())

    @constant
    def attr(self):
        '''type: int\n\nThe declared attribute for variable.\n\nAttributes include:\n\n  * nonneg = 0\n\n  * nonpos = 1\n\n  * symmetric = 2\n\n  * diag = 3\n\n  * PSD = 4\n\n  * NSD = 5\n\n  * pos = 6\n\n  * neg = 7\n\nFor example, if variable is declared as PSD, this value is 16(1 << 4).\n\n\n\n\n'''
        cdef int attr
        if self.index < 0:
            return self.attr_
        err = admm_get_var(self.model_.mdl_, self.id_, NULL, NULL, NULL, &attr)
        if err != 0: raise ADMMError(err)
        return attr

    @constant
    def X(self):
        '''type: np.ndarray\n\nThe solution of this variable.\n\n\n\n\n'''
        shape = self.shape
        sol = _np.empty(shape, dtype=_np.float64)
        err = admm_get_var_solution(self.model_.mdl_, self.id_, numpy_double_buffer(sol))
        if err != 0: raise ADMMError(err)
        return sol

    @constant
    def index(self):
        '''type: int\n\nIndex of this tensor. It is -1 until tensor is added to model.\n\n\n\n\n'''
        return self.id_

    @constant
    def name(self):
        '''type: str\n\nThe name of this parameter\n\n\n\n\n'''
        cdef char* name

        if self.index < 0:
            return self.name_

        err = admm_get_var(self.model_.mdl_, self.id_, NULL, NULL, &name, NULL);
        if err != 0: raise ADMMError(err)
        return str(name, "utf8")

    @constant
    def type(self):
        '''type: int\n\nThe type for this tensor. \n\nIt is: \n\n  * 2 for sparse constant.\n\n  * 3 for dense constant.\n\n  * 4 for parameter.\n\n  * 5 for variable.\n\n  * and 6, for expression.\n\n\n\n\n'''
        return AT_VARIABLE

    def __repr__(self):
        name = self.name
        return "Var({}, {})".format("unamed" if name is None else name, self.shape)

    def __str__(self):
        name = self.name
        return "Var({}, {})".format("unamed" if name is None else name, self.shape)

cdef wrapPyObject(Model model, int oid, int otype):
    cdef int nslices
    if otype == AT_RANGE:
        err = admm_get_slice(model.mdl_, oid, &nslices, NULL, NULL, NULL)
        if err != 0: raise ADMMError(err)

        starts = _np.empty((nslices,), dtype=_np.int32)
        stops = _np.empty((nslices,), dtype=_np.int32)
        steps = _np.empty((nslices,), dtype=_np.int32)

        err = admm_get_slice(model.mdl_, oid, &nslices, 
            numpy_int_buffer(starts), numpy_int_buffer(stops), numpy_int_buffer(steps))
        if err != 0: raise ADMMError(err)

        slicelist = []
        for i in range(nslices):
            slicelist.append((starts[i], stops[i], steps[i]))
        return slicelist

    elif otype == AT_SPARSE:
        o = Constant(0)
        (<Constant>o).saved(model, 0, oid)
        return o
    elif otype == AT_DENSE:
        o = Constant(0)
        (<Constant>o).saved(model, 1, oid)
        return o
    elif otype == AT_PARAMETER:
        o = Param("somewhat")
        (<Param>o).model_ = model
        (<Param>o).id_ = oid
        return o
    elif otype == AT_VARIABLE:
        o = Var()
        (<Var>o).model_ = model
        (<Var>o).id_ = oid
        return o
    elif otype == AT_EXPR:
        return Expr.new(model, oid)
    else:
        raise ADMMError(10001, "UNKNOWN_ARG_TYPE")


cdef class Expr(TensorLike):
    '''\nThe expression.\n\n\n\n\n'''
    cdef Model model_
    cdef int id_
    cdef tuple shape_
    cdef int opr_
    cdef int nargs_
    cdef list operands_

    @staticmethod
    cdef new(Model model, int eid):
        expr = Expr(None, OT_NOP, [])
        expr.model_ = model
        expr.id_ = eid
        return expr
    
    def __init__(self, shape, operator, operands):
        self.id_ = -1
        self.shape_ = shape
        self.opr_ = operator
        self.nargs_ = len(operands)
        self.operands_ = list(operands)

    @constant
    def index(self):
        '''type: int\n\nIndex of this tensor. It is -1 until tensor is added to model.\n\n\n\n\n'''
        return self.id_

    @constant
    def type(self):
        '''type: int\n\nThe type for this tensor. \n\nIt is: \n\n  * 2 for sparse constant.\n\n  * 3 for dense constant.\n\n  * 4 for parameter.\n\n  * 5 for variable.\n\n  * and 6, for expression.\n\n\n\n\n'''
        return AT_EXPR

    @constant
    def operator(self):
        '''type: int\n\nThe operator id for this expression.\n\n\n\n\n'''
        cdef int oprt
        cdef int ndim
        cdef int nargs

        if self.id_ < 0:
            oprt = self.opr_
        else:
            err = admm_get_expr(self.model_.mdl_, self.id_, &oprt, &ndim, NULL, &nargs, NULL, NULL, NULL)
            if err != 0: raise ADMMError(err)

        return oprt
        #if oprt < 100:      return OprType(oprt)
        #elif oprt < 200:    return UnaryFun(oprt)
        #elif oprt < 300:    return BinaryFun(oprt)
        #else:               return TernaryFun(oprt)

    @constant
    def nargs(self):
        '''type: int\n\nThe number of operands this expression has.\n\n\n\n\n'''
        cdef int oprt
        cdef int ndim
        cdef int nargs
        
        if self.id_ < 0: return self.nargs_

        err = admm_get_expr(self.model_.mdl_, self.id_, &oprt, &ndim, NULL, &nargs, NULL, NULL, NULL)
        if err != 0: raise ADMMError(err)
        return nargs

    def arg(self, index):
        '''\nRetrieve the nth operand.\n\nParameters\n----------\nn: int\n\n  The ordinal for operand to be retrieved.\n  \nReturns\n-------\nUnion[TensorLike, ArrayLike]\n\nThe nth operand.\n\n\n\n\n'''
        cdef int oprt
        cdef int ndim
        cdef int nargs

        if self.id_ < 0: return self.operands_[index]

        nargs = self.nargs
        args = _np.empty((nargs,), dtype=_np.int32)
        atypes = _np.empty((nargs,), dtype=_np.int32)

        err = admm_get_expr(self.model_.mdl_, self.id_, &oprt, &ndim, NULL, 
            &nargs, numpy_int_buffer(args), numpy_int_buffer(atypes), NULL)

        if err != 0: raise ADMMError(err)
        return wrapPyObject(self.model_, args[index], atypes[index])

    @constant
    def args(self):
        '''type: List[Union[TensorLike, ArrayLike]]\n\nList of operands in expression.\n\n\n\n\n'''
        return [self.arg(i) for i in range(self.nargs)]


    @constant
    def shape(self):
        '''type: Tuple[int]\n\nThe shape of this tensor.\n\n\n\n\n'''
        cdef int oprt
        cdef int ndim
        cdef int nargs

        if self.id_ < 0: return self.shape_

        err = admm_get_expr(self.model_.mdl_, self.id_, &oprt, &ndim, NULL, &nargs, NULL, NULL, NULL)
        if err != 0: raise ADMMError(err)

        shape = _np.empty((ndim,), dtype=_np.int32)
        err = admm_get_expr(self.model_.mdl_, self.id_, &oprt, &ndim, numpy_int_buffer(shape), &nargs, NULL, NULL, NULL)
        if err != 0: raise ADMMError(err)
        return tuple(shape.tolist())

    def __repr__(self):
        li = []
        for i in range(self.nargs):
            li.append(type(self.arg(i)).__name__)
        fname = None
        if self.operator in FunInfo:
            fname = FunInfo[self.operator]
        if fname is None:
            if self.operator < len(OPNAMES):
                fname = OPNAMES[self.operator]
            else:
                for udft, udfid in udfs.items():
                    if self.operator == udfid:
                        fname = udft.__qualname__
        return "Expr({}, {}({}))".format(self.shape, fname, str(li)[1:-1])

    def __str__(self):
        li = []
        for i in range(self.nargs):
            li.append(type(self.arg(i)).__name__)
        fname = None
        if self.operator in FunInfo:
            fname = FunInfo[self.operator]
        if fname is None:
            if self.operator < len(OPNAMES):
                fname = OPNAMES[self.operator]
            else:
                for udft, udfid in udfs.items():
                    if self.operator == udfid:
                        fname = udft.__qualname__
        return "Expr({}, {}({}))".format(self.shape, fname, str(li)[1:-1])



cdef class Constr:
    '''\nThis class represents a constraint.\n\nIt is usually generated by comparison between expressions.\n\n\n\n\n'''
    cdef Model model_
    cdef int id_
    cdef object lhs_
    cdef str sense_
    cdef object rhs_

    @staticmethod
    cdef new(Model model, int cid):
        c = Constr(None, None, None)
        c.model_ = model
        c.id_ = cid
        return c

    def __init__(self, lhs, sense, rhs):
        self.id_ = -1
        self.lhs_ = lhs
        self.sense_ = sense
        self.rhs_ = rhs

    @constant
    def index(self):
        '''type: int\n\nThis index of this constraint.\n\n\n\n\n'''
        return self.id_

    @constant
    def lhs(self):
        '''type: Union[TensorLike, ArrayLike]\n\nThe left-hand-side value for this constraint.\n\n\n\n\n'''
        cdef int le
        cdef int lt
        cdef int sn
        cdef int re
        cdef int rt
        if self.id_ < 0: return self.lhs_
        err = admm_get_constr(self.model_.mdl_, self.id_, &le, &lt, &sn, &re, &rt);
        if err != 0: raise ADMMError(err)
        return wrapPyObject(self.model_, le, lt)

    @constant
    def sense(self):
        '''type: str\n\nThe comparator for this constraint.\n\n\n\n\n'''
        cdef int le
        cdef int lt
        cdef int sn
        cdef int re
        cdef int rt
        if self.id_ < 0: return self.sense_
        err = admm_get_constr(self.model_.mdl_, self.id_, &le, &lt, &sn, &re, &rt);
        if err != 0: raise ADMMError(err)
        return ('<', '=', ">", 'N', 'P')[sn]

    @constant
    def rhs(self):
        '''type: Union[TensorLike, ArrayLike]\n\nThe right-hand-side value for this constraint.\n\n\n\n\n'''
        cdef int le
        cdef int lt
        cdef int sn
        cdef int re
        cdef int rt
        if self.id_ < 0: return self.rhs_
        err = admm_get_constr(self.model_.mdl_, self.id_, &le, &lt, &sn, &re, &rt);
        if err != 0: raise ADMMError(err)
        return wrapPyObject(self.model_, re, rt)


    def __repr__(self):
        if self.sense == 'N':
            return "Constr(NSD {})".format(self.lhs)
        elif self.sense == 'P':
            return "Constr(PSD {})".format(self.lhs)
        return "Constr({} {} {})".format(self.lhs, self.sense, self.rhs)

    def __str__(self):
        if self.sense == 'N':
            return "Constr(NSD {})".format(self.lhs)
        elif self.sense == 'P':
            return "Constr(PSD {})".format(self.lhs)
        return "Constr({} {} {})".format(self.lhs, self.sense, self.rhs)
MINIMIZE = 1
MAXIMIZE = -1

cdef declare_rw(f):
    def fset(self, value):
        raise self.__setattr__(f.__name__, value)
    def fget(self):
        return self.__getattr__(f.__name__)
    return property(fget, fset, None, f.__doc__)

cdef declare_ro(f):
    def fset(self, value):
        raise TypeError('{} is readonly'.format(f.__name__))
    def fget(self):
        return self.__getattr__(f.__name__)
    return property(fget, fset, None, f.__doc__)

cdef class Model:
    '''\nThe optimization model.\n\n\n\n\n'''
    cdef model_t mdl_
    cdef int needfree_
    cdef list vars_
    cdef list constrs_
    cdef list udfrefs_

    def __init__(self, obj = None, file = None, logfile=None):
        '''\nConstruct a model.\n\nParameters\n----------\nobj: Optional[Model] = None\n\n  The model to copy. When both `obj` and `file` have assigned values, `obj` is used\n  and `file` is ignored.\n  \nfile: Optional[str] = None\n\n  The file to read model from. The compression type is encoded in the file name as\n  a suffix (.gz, .bz2), for instance "model.input.gz" implies a gzip compression\n  type.\n  \n  \n  \nlogfile: Optional[str] = None\n\n  The file to write log to.\n  \n  \n  \n  \n  '''
        cdef char* name = NULL
        cdef char* filename = NULL
        cdef bytes logfilename = None

        rawname = None
        rawfilename = None
        self.needfree_ = 0
        self.vars_ = []
        self.constrs_ = []
        self.udfrefs_ = []


        if obj is not None and isinstance(obj, Model):
            self.mdl_ = admm_copy((<Model>obj).mdl_)
            self.needfree_ = 1
            self.populate()
        else:
            if logfile is not None:
                if not isinstance(logfile, str):
                    raise TypeError("expect a string for argument logfile")
                if logfile.strip() != "":
                    logfilename = bytes(logfile.strip(), "utf8")
        
        if self.needfree_ == 0:
            if obj is not None:
                if isinstance(obj, str):
                    rawname = bytes(obj, "utf8")
                elif isinstance(obj, (bytes, bytearray)):
                    rawname = obj
                else: raise ADMMError(BAD_ARG)
                name = rawname
            if file is not None:
                if isinstance(file, str):
                    rawfilename = bytes(file, "utf8")
                elif isinstance(file, (bytes, bytearray)):
                    rawfilename = file
                else: raise ADMMError(BAD_ARG)
                filename = rawfilename

            if logfilename is None:
                err = admm_create(&self.mdl_, name, filename, NULL)
            else:
                err = admm_create(&self.mdl_, name, filename, logfilename)

            if err != 0: raise ADMMError(err)

            if file is not None:
                self.populate()

            self.needfree_ = 1

    cdef populate(self):
        if len(self.vars_) > 0 or len(self.constrs_) > 0:
            raise RuntimeError("Non empty model")

        for i in range(self.numvars):
            v = Var()
            v.model_ = self
            v.id_ = i
            self.vars_.append(v)

        for j in range(self.numconstrs):
            c = Constr.new(self, j)
            self.constrs_.append(c)
        

    def getParam(self, str name):
        '''\nRetrieve the parameter in this model.\n\nParameters\n----------\nname: str\n\n  The parameter name.\n  \nReturns\n-------\nParam\n\nThe parameter to be retrieved.\n\n\n\n\n'''
        cdef int pid

        if name is None: raise ADMMError(BAD_ARG)

        rawname = bytes(name, "utf8")
        err = admm_get_param_by_name(self.mdl_, rawname, &pid)

        if err != 0: raise ADMMError(err)
        r = Param(name)
        r.model_ = self
        r.id_ = pid
        return r


    cdef addConstant(self, Constant c):
        cdef int cid
        if c.index >= 0: return c
        if c.isDense():
            data = c.data
            shape = _np.array(data.shape, dtype=_np.int32)
            err = admm_add_dense(self.mdl_, shape.size, 
                numpy_int_buffer(shape), numpy_double_buffer(data), &cid)
            if err != 0: raise ADMMError(err)
            c.saved(self, 1, cid)
        else:
            shape = _np.array(c.shape, dtype=_np.int32)
            data = c.data
            err = admm_add_sparse(self.mdl_, shape.size, numpy_int_buffer(shape), data[0].size,
                <size_t*>numpy_ulong_buffer(data[0]), numpy_double_buffer(data[1]), &cid)
            if err != 0: raise ADMMError(err)
            c.saved(self, 0, cid)
        return c


    cdef addParam(self, Param param):
        cdef int pid

        if param.index < 0:
            shape = _np.array(param.shape, dtype=_np.int32)
            name = bytes(param.name, "utf8")
            err = admm_add_param(self.mdl_, shape.size, numpy_int_buffer(shape), name, param.attr, &pid);
            if err != 0: raise ADMMError(err)
            param.id_ = pid
            param.model_ = self

        return param

    cdef addVar(self, Var var):
        cdef int vid
        cdef char* name
        namebytes = None

        if var.index < 0:
            shape = _np.array(var.shape, dtype=_np.int32)
            if var.name_ is None:
                name = NULL
            else:
                namebytes = bytes(var.name_, "utf8")
                name = namebytes
            err = admm_add_var(self.mdl_, shape.size, numpy_int_buffer(shape), name, var.attr, &vid)
            if err != 0: raise ADMMError(err)
            var.id_ = vid
            var.model_ = self
            self.vars_.append(var)
        return var

    cdef addLeaf(self, leaf):
        if isinstance(leaf, (_np.ndarray, _sp.spmatrix, tuple, list)):
            return self.addConstant(Constant(leaf))
        elif isinstance(leaf, Constant):
            return self.addConstant(leaf)
        elif isinstance(leaf, Param):
            return self.addParam(leaf)
        elif isinstance(leaf, Var):
            return self.addVar(leaf)
        else:
            return self.addConstant(Constant(leaf))

    cdef addNopExpr(self, Expr expr):
        if expr.id_ >= 0: return expr
        operand = self.addExprOrConst(expr.operands_[0])
        err = admm_add_expr_nop(self.mdl_, operand.index, operand.type, &expr.id_)
        if err != 0: raise ADMMError(err)
        expr.model_ = self
        return expr

    cdef addNegExpr(self, Expr expr):
        if expr.id_ >= 0: return expr
        operand = self.addExprOrConst(expr.operands_[0])
        err = admm_add_expr_neg(self.mdl_, operand.index, operand.type, &expr.id_)
        if err != 0: raise ADMMError(err)
        expr.model_ = self
        return expr

    cdef addTransExpr(self, Expr expr):
        if expr.id_ >= 0: return expr
        operand = self.addExprOrConst(expr.operands_[0])
        err = admm_add_expr_trans(self.mdl_, operand.index, operand.type, &expr.id_)
        if err != 0: raise ADMMError(err)
        expr.model_ = self
        return expr

    cdef addSliceExpr(self, Expr expr):
        if expr.id_ >= 0: return expr
        operand = self.addExprOrConst(expr.operands_[1])

        ranges = expr.operands_[0]
        starts = _np.empty((len(ranges),), dtype=_np.int32)
        stops = _np.empty((len(ranges),), dtype=_np.int32)
        steps = _np.empty((len(ranges),), dtype=_np.int32)

        for i in range(len(ranges)):
            starts[i] = ranges[i][0]
            stops[i] = ranges[i][1]
            steps[i] = ranges[i][2]

        err = admm_add_expr_slice(self.mdl_, operand.index, operand.type,
            len(expr.operands_[0]), numpy_int_buffer(starts), numpy_int_buffer(stops), 
            numpy_int_buffer(steps), &expr.id_)

        if err != 0: raise ADMMError(err)
        expr.model_ = self
        return expr

    cdef addReshapeExpr(self, Expr expr):
        if expr.id_ >= 0: return expr
        operand = self.addExprOrConst(expr.operands_[1])

        shape = expr.operands_[0]
        shapearr = _np.array(shape, dtype=_np.int32)
        err = admm_add_expr_reshape(self.mdl_, operand.index, operand.type,
                shapearr.size, numpy_int_buffer(shapearr), &expr.id_)

        if err != 0: raise ADMMError(err)
        expr.model_ = self
        return expr

    cdef addPlusExpr(self, Expr expr):
        if expr.id_ >= 0: return expr
        le = self.addExprOrConst(expr.operands_[0])
        re = self.addExprOrConst(expr.operands_[1])

        err = admm_add_expr_add(self.mdl_, le.index, le.type, re.index, re.type, &expr.id_)
        if err != 0: raise ADMMError(err)
        expr.model_ = self
        return expr

    cdef addSubExpr(self, Expr expr):
        if expr.id_ >= 0: return expr
        le = self.addExprOrConst(expr.operands_[0])
        re = self.addExprOrConst(expr.operands_[1])

        err = admm_add_expr_sub(self.mdl_, le.index, le.type, re.index, re.type, &expr.id_)
        if err != 0: raise ADMMError(err)
        expr.model_ = self
        return expr

    cdef addMulExpr(self, Expr expr):
        if expr.id_ >= 0: return expr
        le = self.addExprOrConst(expr.operands_[0])
        re = self.addExprOrConst(expr.operands_[1])

        err = admm_add_expr_mul(self.mdl_, le.index, le.type, re.index, re.type, &expr.id_)
        if err != 0: raise ADMMError(err)
        expr.model_ = self
        return expr

    cdef addDivExpr(self, Expr expr):
        if expr.id_ >= 0: return expr
        le = self.addExprOrConst(expr.operands_[0])
        re = self.addExprOrConst(expr.operands_[1])

        err = admm_add_expr_div(self.mdl_, le.index, le.type, re.index, re.type, &expr.id_)
        if err != 0: raise ADMMError(err)
        expr.model_ = self
        return expr

    cdef addMMulExpr(self, Expr expr):
        if expr.id_ >= 0: return expr

        le = self.addExprOrConst(expr.operands_[0])
        re = self.addExprOrConst(expr.operands_[1])

        err = admm_add_expr_matmul(self.mdl_, le.index, le.type, re.index, re.type, &expr.id_)
        if err != 0: raise ADMMError(err)
        expr.model_ = self
        return expr
    
    cdef addPowExpr(self, Expr expr):
        if expr.id_ >= 0: return expr

        le = self.addExprOrConst(expr.operands_[0])
        re = self.addExprOrConst(expr.operands_[1])

        err = admm_add_expr_pow(self.mdl_, le.index, le.type, re.index, re.type, &expr.id_)
        if err != 0: raise ADMMError(err)
        expr.model_ = self
        return expr

    cdef addUnaryFun(self, fun, Expr expr):
        if expr.id_ >= 0: return expr
        operand = self.addExprOrConst(expr.operands_[0])

        err = admm_add_unary_fun(self.mdl_, fun, 
            operand.index, operand.type, &expr.id_)
        if err != 0: raise ADMMError(err)
        expr.model_ = self
        return expr

    cdef addBinaryFun(self, fun, Expr expr):
        if expr.id_ >= 0: return expr
        le = self.addExprOrConst(expr.operands_[0])
        re = self.addExprOrConst(expr.operands_[1])

        err = admm_add_binary_fun(self.mdl_, fun, le.index, 
            le.type, re.index, re.type, &expr.id_)
        if err != 0: raise ADMMError(err)
        expr.model_ = self
        return expr

    cdef addTernaryFun(self, fun, Expr expr):
        if expr.id_ >= 0: return expr
        o1 = self.addExprOrConst(expr.operands_[0])
        o2 = self.addExprOrConst(expr.operands_[1])
        o3 = self.addExprOrConst(expr.operands_[2])

        err = admm_add_ternary_fun(self.mdl_, fun, o1.index, 
            o1.type, o2.index, o2.type, o3.index, o3.type, &expr.id_)
        if err != 0: raise ADMMError(err)
        expr.model_ = self
        return expr

    cdef addVariadicFun(self, fun, Expr expr):
        operands = [self.addExprOrConst(o) for o in expr.operands_]
        args = _np.array([o.index for o in operands], dtype=_np.int32)
        types = _np.array([o.type for o in operands], dtype=_np.int32)

        err = admm_add_variadic_fun(self.mdl_, fun, len(operands), numpy_int_buffer(args), numpy_int_buffer(types), &expr.id_)
        if err != 0: raise ADMMError(err)
        expr.model_ = self
        return expr

    cdef addUdfExpr(self, e):
        cdef int exprid
        udfid = getUdfId(e)
        exprs = e.arguments()
        for expr in exprs:
            if isConstExp(expr):
                raise TypeError("{}.arguments is expected to return a list of non-const expression".format(type(e).__name__))
        if len(exprs) == 0:
            raise ValueError("{}.arguments returned an empty list".format(type(e).__name__))

        exprs = [self.addExprOrConst(expr) for expr in exprs]
        indices = _np.array([expr.index for expr in exprs], dtype=_np.int32)
        etypes = _np.array([expr.type for expr in exprs], dtype=_np.int32)

        err = admm_add_expr_udf(self.mdl_, udfid, indices.size, numpy_int_buffer(indices), numpy_int_buffer(etypes), <void*>e, &exprid)
        # Increase refcount for e
        self.udfrefs_.append(e)
        if err != 0: raise ADMMError(err)
        (<UDFBase>e).index_ = exprid
        return e

    cdef addExprOrConst(self, object expr):
        cdef Expr e

        if isinstance(expr, Expr):
            e = <Expr>expr
            
            if e.opr_ == OT_NOP:
                return self.addNopExpr(e)
            elif e.opr_ == OT_NEG:
                return self.addNegExpr(e)
            elif e.opr_ == OT_T:
                return self.addTransExpr(e)
            elif e.opr_ == OT_SLICE:
                return self.addSliceExpr(e)
            elif e.opr_ == OT_RESHAPE:
                return self.addReshapeExpr(e)
            elif e.opr_ == OT_ADD:
                return self.addPlusExpr(e)
            elif e.opr_ == OT_SUB:
                return self.addSubExpr(e)
            elif e.opr_ == OT_MUL:
                return self.addMulExpr(e)
            elif e.opr_ == OT_DIV:
                return self.addDivExpr(e)
            elif e.opr_ == OT_MML:
                return self.addMMulExpr(e)
            elif e.opr_ == OT_POW:
                return self.addPowExpr(e)
            elif e.opr_ < 200:
                return self.addUnaryFun(e.opr_, e)
            elif e.opr_ < 300:
                return self.addBinaryFun(e.opr_, e)
            elif e.opr_ < 400:
                return self.addTernaryFun(e.opr_, e)
            elif e.opr_ // 100 == 9:
                # variadic function
                return self.addVariadicFun(e.opr_, e)
            else:
                raise ADMMError(BAD_ARG)
        elif isinstance(expr, UDFBase):
            return self.addUdfExpr(expr)
        else:
            return self.addLeaf(expr)

    cdef addExpr(self, expr):
        if not isinstance(expr, (Expr, UDFBase)):
            raise ADMMError(BAD_ARG)
        return self.addExprOrConst(expr)

    def addConstr(self, lexpr, sense=None, rexpr=None):
        '''\nAdd a new constraint to this model.\n\nParameters\n----------\nlexpr: Union[TensorLike, ArrayLike, Constr]\n\n  The left-side-hand value for new constraint. If it is a Constr, the rest arguments\n  will be ignored.\n  \nsense: Optional[str] = None\n\n  The comparator for new constraint.\n  \n  It is:\n  \n    * '<' for less than or equal to.\n  \n    * '>' for greater than or equal to.\n  \n    * '=' for equal to.\n  \n    * 'N' for NSD.\n  \n    * 'P' for PSD\n  \nrexpr: Union[TensorLike, ArrayLike, Constr] = None\n\n  The right-side-hand value for new constraint.\n  \nReturns\n-------\nConstr\n\nThe newly added constraint.\n\n\n\n\n'''
        cdef int constr
        cdef Constr c

        isConstr = isinstance(lexpr, Constr)
        if isConstr:
            c = <Constr>lexpr
            if c.id_ >= 0: return lexpr
            lexpr = c.lhs
            sense = c.sense
            rexpr = c.rhs

        le = self.addExprOrConst(lexpr)
        re = self.addExprOrConst(rexpr)

        if sense not in ('<', '=', '>', 'N', 'P'): raise ADMMError(BAD_ARG)
        s = ('<', '=', '>', 'N', 'P').index(sense)
        if s < 0: raise ADMMError(BAD_ARG)

        err = admm_add_constr(self.mdl_, le.index, le.type, s, re.index, re.type, &constr)
        if err != 0: raise ADMMError(err)

        if isConstr:
            c.model_ = self
            c.id_ = constr
        else:
            c = Constr.new(self, constr)

        self.constrs_.append(c)
        return c

    def removeConstr(self, constrs):
        '''\nRemove constraint(s) from model.\n\nParameters\n----------\nconstrs: Union[Constr, Iterable[Constr]]\n\n  The constraints to be removed.\n  \n  \n  \n  \n  '''
        if isinstance(constrs, Constr):
            constrs = [constrs]
        li = _np.array([constr.index for constr in constrs], dtype=_np.int32)
        err = admm_remove_constr_list(self.mdl_, numpy_int_buffer(li), li.size)
        if err != 0: raise ADMMError(err)
        indices = sorted(li)
        i = 0
        p = 0
        offset = 0
        while i + offset < len(self.constrs_):
            if p < len(indices) and i == indices[p]:
                (<Constr>self.constrs_[i]).id_ = -1 - (<Constr>self.constrs_[i]).id_
                p += 1
                offset += 1
                while p < len(indices) and i == indices[p]: p += 1
            self.constrs_[i] = self.constrs_[i + offset]
            (<Constr>self.constrs_[i]).id_ -= offset
            i += 1
        del self.constrs_[len(self.constrs_) - offset:]

    def getVar(self, index):
        '''\nGet variable object by its index.\n\nParameters\n----------\nindex: int\n\n  Variable index.\n  \nReturns\n-------\nVar\n\nThe indexed variable.\n\n\n\n\n'''
        if index < 0 or index >= self.numvars:
            raise KeyError("index out of range <{}>".format(index))
        return self.vars_[index]

    def getVarByName(self, name):
        '''\nGet variable by its name.\n\nParameters\n----------\nname: str\n\n  Variable name.\n  \nReturns\n-------\nVar\n\nThe variable, or `None` if no such variable exist.\n\n\n\n\n'''
        cdef int var
        rawname = bytes(name, "utf8")
        err = admm_get_var_by_name(self.mdl_, rawname, &var)
        if err != 0: raise ADMMError(err)
        if var >= 0: return self.getVar(var)
        return None

    def getConstr(self, index):
        '''\nGet constraint object by its index.\n\nParameters\n----------\nindex: int\n\n  Constraint index.\n  \nReturns\n-------\nConstr\n\nThe indexed constraint.\n\n\n\n\n'''
        if index < 0 or index >= self.numconstrs:
            raise KeyError("index out of range <{}>".format(index))
        return self.constrs_[index]

    cdef containsVariable(self, expr):
        if isinstance(expr, (Var, UDFBase)):
            return True
        elif isinstance(expr, (_numbers.Number, _np.ndarray, _sp.spmatrix)):
            return False
        elif isinstance(expr, Expr):
            args = expr.args
            for arg in args:
                if self.containsVariable(arg):
                    return True
            return False
        else:
            return False

    def setObjective(self, expr, modelsense = 0):
        '''\nSet objective function for this model.\n\nNote that only scalar or expression with 1 element can be set as objective\nfunction.\n\nParameters\n----------\nexpr: Union[TensorLike, ArrayLike]\n\n  The objective function. Pass a `None` to clear objective function.\n  \nmodelsense: int = 0\n\n  Optimization sense, MINIMIZE(1) or MAXIMIZE(-1). Default 0 means keep the current\n  sense (minimize if not previously set).\n  \n  \n  \n  \n  '''
        if expr is None:
            err = admm_set_objective(self.mdl_, -1)
            if err != 0: raise ADMMError(err)
            return

        try:
            expr = ensure_array_type(expr)
        except:
            pass
        if not hasattr(expr, "shape"):
            raise TypeError("objective expects an expression or constant")
        if _np.prod(expr.shape) != 1:
            raise ValueError("objective expects a scalar")


        if not isinstance(expr, Expr) or not self.containsVariable(expr):
            expr = Expr(expr.shape, OT_NOP, [expr])

        if modelsense in [-1, 1]: self.modelsense = modelsense

        e = self.addExpr(expr)
        err = admm_set_objective(self.mdl_, e.index)
        if err != 0: raise ADMMError(err)

    def getObjective(self):
        '''\nGet the objective function as an expression.\n\nReturns\n-------\nExpr\n\nThe objective function.\n\nNotes\n-----\n\nIf model has no objective function, this method raise an error.\n\n\n\n\n'''
        cdef int expr
        err = admm_get_objective(self.mdl_, &expr)
        if err != 0: raise ADMMError(err)
        return Expr.new(self, expr)

    def __getattr__(self, name):
        cdef int n
        cdef double f
        rawname = bytes(name.lower(), "utf8")
        if name.lower() == "minsense":
            return admm_is_minsense(self.mdl_) != 0
        elif name.lower() == "modelsense":
            return admm_model_sense(self.mdl_)
        elif name.lower() == "name":
            modelname = admm_get_model_name(self.mdl_)
            return str(modelname, "utf8") if modelname else None
        elif name.lower() in ["numvars", "numconstrs", "numiters", "status"]:
            err = admm_get_int_attr(self.mdl_, rawname, &n)
            if err != 0: raise ADMMError(err)
            return n
        elif name.lower() in ["primalobjval", "objval", "dualobjval", "solvertime", "primalgap", "dualgap"]:
            err = admm_get_double_attr(self.mdl_, rawname, &f)
            if err != 0: raise ADMMError(err)
            return f
        elif name.lower() == "statusstring":
            rawname = b'status'
            err = admm_get_int_attr(self.mdl_, rawname, &n)
            if err != 0: raise ADMMError(err)
            return [
                'SOLVE_UNKNOWN',
                'SOLVE_OPT_SUCCESS',
                'SOLVE_INFEASIBLE',
                'SOLVE_UNBOUNDED',
                'SOLVE_OVER_MAX_ITER',
                'SOLVE_OVER_MAX_TIME',
                'SOLVE_NAN_FOUND',
                'SOLVE_PRE_FAILURE',
                'SOLVE_EXCEPT_ERROR',
                'SOLVE_GET_SOL_FAILURE',
                'SOLVE_ERROR'
            ][n]
        else:
            raise AttributeError("Model has no readable attr <{}>".format(name))


    def __setattr__(self, name, value):
        if name.lower() == "minsense":
            admm_set_minsense(self.mdl_, 1 if value else 0)
        elif name.lower() == "modelsense":
            admm_set_minsense(self.mdl_, 1 if value == 1 else 0)
        else:
            raise AttributeError("Model has no writable attr <{}>".format(name))

    @declare_ro
    def NumVars(self):
        '''Number of variables in the model (read-only).'''
        pass

    @declare_ro
    def NumConstrs(self):
        '''type: int\n\nThe number of constraints this model has.\n\n\n\n\n'''
        pass

    @declare_rw
    def MinSense(self):
        '''type: bool\n\nCheck if this model is to be minimized.\n\n\n\n\n'''
        pass

    @declare_rw
    def ModelSense(self):
        '''type: int\n\nModel sense (minimization(1) or maximization(-1)).\n\n\n\n\n'''
        pass

    @declare_ro
    def Name(self):
        '''type: str\n\nThe name of this model.\n\n\n\n\n'''
        pass

    @declare_ro
    def NumIters(self):
        '''type: int\n\nThe number of optimization iterations.\n\n\n\n\n'''
        pass

    @declare_ro
    def Status(self):
        '''type: int\n\nThe optimization status.\n\n  * SOLVE_UNKNOWN = 0\n\n  * SOLVE_OPT_SUCCESS = 1\n\n  * SOLVE_INFEASIBLE = 2\n\n  * SOLVE_UNBOUNDED = 3\n\n  * SOLVE_OVER_MAX_ITER = 4\n\n  * SOLVE_OVER_MAX_TIME = 5\n\n  * SOLVE_NAN_FOUND = 6\n\n  * SOLVE_PRE_FAILURE = 7\n\n  * SOLVE_EXCEPT_ERROR = 8\n\n  * SOLVE_GET_SOL_FAILURE = 9\n\n  * SOLVE_ERROR = 10\n\n\n\n\n'''
        pass

    @declare_ro
    def StatusString(self):
        '''type: str\n\nThe optimization status string message.\n\n\n\n\n'''
        pass

    @declare_ro
    def PrimalObjVal(self):
        '''type: float\n\nThe objective value for primal problem.\n\n\n\n\n'''
        pass

    @declare_ro
    def ObjVal(self):
        '''type: float\n\nThe objective value for primal problem.\n\n\n\n\n'''
        pass

    @declare_ro
    def DualObjVal(self):
        '''type: float\n\nThe objective value for dual problem.\n\n\n\n\n'''
        pass

    @declare_ro
    def SolverTime(self):
        '''type: float\n\nThe optimization time.\n\n\n\n\n'''
        pass

    @declare_ro
    def PrimalGap(self):
        '''type: float\n\nThe gap for primal problem.\n\n\n\n\n'''
        pass

    @declare_ro
    def DualGap(self):
        '''type: float\n\nThe gap for dual problem.\n\n\n\n\n'''
        pass



    def setOption(self, name, value):
        '''\nSet a new value for an option.\n\nParameters\n----------\nname: str\n\n  The option name.\n  \nvalue: Union[int, float]\n\n  The new option value.\n  \n  \n  \nNotes\n-----\n\nUser may use `Options.XXX` to specify option name.\n\n\n\n\n'''
        name = name.lower()
        if name in IntOptNames:
            nval = int(value)
            err = admm_set_int_opt(self.mdl_, IntOptNames[name][0], nval)
            if err != 0: raise ADMMError(err)
        elif name.lower() in DblOptNames:
            fval = float(value)
            err = admm_set_double_opt(self.mdl_, DblOptNames[name][0], fval)
            if err != 0: raise ADMMError(err)
        else:
            raise ADMMError(OPT_NOT_FOUND)

    def getOption(self, name):
        '''\nGet value for an option.\n\nParameters\n----------\nname: str\n\n  The option name.\n  \nReturns\n-------\nUnion[int, float]\n\nThe current option value.\n\nNotes\n-----\n\nUser may use `Options.XXX` to specify option name.\n\n\n\n\n'''
        cdef int nval
        cdef double fval
        name = name.lower()
        if name in IntOptNames:
            err = admm_get_int_opt(self.mdl_, IntOptNames[name][0], &nval)
            if err != 0: raise ADMMError(err)
            return nval
        elif name in DblOptNames:
            err = admm_get_double_opt(self.mdl_, DblOptNames[name][0], &fval)
            if err != 0: raise ADMMError(err)
            return fval
        else:
            raise ADMMError(OPT_NOT_FOUND)

    def getOptionInfo(self, name):
        '''\nGet the metadata for an option.\n\nParameters\n----------\nname: str\n\n  The option name.\n  \nReturns\n-------\nTuple[str, Union[int, float], Union[int, float], Union[int, float]]\n\nA tuple with 4 elements will be returned: the canonical option name, the minimal\nvalue allowed (inclusive), the maximal value allowed(inclusive), and the default\nvalue\n\nNotes\n-----\n\nUser may use `Options.XXX` to specify option name.\n\n\n\n\n'''
        if name is None: raise ADMMError(BAD_ARG)
        name = name.lower()
        if name in IntOptNames:
            return (str(IntOptNames[name][0], "utf8"), ) + IntOptNames[name][1:]
        elif name in DblOptNames:
            return (str(DblOptNames[name][0], "utf8"), ) + DblOptNames[name][1:]
        else:
            raise ADMMError(OPT_NOT_FOUND)

    def optimize(self, paramdict = None, tuner = None):
        '''\nOptimize this model.\n\nParameters\n----------\nparamdict: Optional[Dict[str, ArrayLike]] = {}\n\n  The constant value to be bounded to parameter.\n  \ntuner: Optional[Callable[[TuningContext], None]] = None\n\n  The customized hyper parameter tuning function.\n  \nExamples\n--------\n\n\n\n  def hptune(ctx: TuningContext):\n\n      print(ctx)\n\n  \n\n  p = Param("param1", 2, 2)\n\n  x = Var(2, 2)\n\n  \n\n  model.setObjective(sum(p @ x))\n\n  model.optimize({"param1": [[1, 2], [3, 4]]}, hptune)\n\n\n\n\n\n\n'''
        cdef int pid
        cdef int rdim
        cdef tuning_callback_t cb
        cdef void* pytuner
        cdef problem_ctx_t ctx
        cdef int dense
        cdef char* errmsg

        if paramdict is None:
            paramdict = {}

        # Check all expressions
        contained_exprs = []

        try:
            contained_exprs.append(self.getObjective())
        except:
            pass

        # BFS
        for i in range(self.NumConstrs):
            c = self.getConstr(i)
            surface = len(contained_exprs)
            contained_exprs.append(c.lhs)
            contained_exprs.append(c.rhs)

            while surface < len(contained_exprs):
                cur = contained_exprs[surface]
                surface += 1

                if isinstance(cur, Expr):
                    contained_exprs += cur.args

        err = admm_create_problem_ctx(&ctx)
        if err != 0: raise ADMMError(err)

        for name in paramdict:
            rawname = bytes(name, "utf8")

            err = admm_get_param_by_name(self.mdl_, rawname, &pid)
            if err != 0:
                admm_destroy_problem_ctx(ctx)
                raise ADMMError(err)

            err = admm_get_param(self.mdl_, pid, &rdim, NULL, NULL, NULL)
            if err != 0:
                admm_destroy_problem_ctx(ctx)
                raise ADMMError(err)

            shapearr = _np.empty((rdim, ), dtype=_np.int32)
            err = admm_get_param(self.mdl_, pid, &rdim, numpy_int_buffer(shapearr), NULL, NULL)
            if err != 0:
                admm_destroy_problem_ctx(ctx)
                raise ADMMError(err)

            shape = tuple(shapearr.tolist())
            value = paramdict[name]

            if not isinstance(value, Constant):
                value = Constant(value)

            if shape != value.shape:
                admm_destroy_problem_ctx(ctx)
                raise ADMMError(SHAPE_MISMATCHED)
            
            if value.isDense():
                data = value.data
                err = admm_add_dense_binding(ctx, rawname, data.size, numpy_double_buffer(data))
            else:
                ind, val = value.data
                err = admm_add_sparse_binding(ctx, rawname, ind.size, 
                    <size_t*>numpy_ulong_buffer(ind), numpy_double_buffer(val))

            if err != 0:
                admm_destroy_problem_ctx(ctx)
                raise ADMMError(err)

        if tuner is not None:
            cb = <tuning_callback_t>ctuner
            pytuner = <void*>tuner
        else:
            cb = NULL
            pytuner = NULL

        # add start value for variables
        for var in self.vars_:
            if var.start is not None:
                start = var.start.asDense()
                npshape = _np.array(start.shape, dtype=_np.int32)
                err = admm_add_dense(self.mdl_, start.ndim, numpy_int_buffer(npshape), numpy_double_buffer(start.data), &dense)
                if err != 0: raise ADMMError(err)
                err = admm_set_variable_start(self.mdl_, var.index, dense)
                if err != 0: raise ADMMError(err)

        if tuner is not None:
            tstate = pysavethread()
        try:
            err = admm_optimize(self.mdl_, ctx, cb, pytuner, &errmsg)
        finally:
            if tuner is not None: pyrestorethread(tstate)

        admm_destroy_problem_ctx(ctx)
        if err != 0:
            e = ADMMError(err)
            if e.message == 'OPTIMIZER_ERROR':
                raise ADMMError(err, str(errmsg, "utf-8"))
            raise e

    def write(self, fname):
        '''\nWrite this model to a file. \n\nParameters\n----------\nfname: str\n\n  The output file name. The compression type is encoded in the file name as a suffix\n  (.gz, .bz2), for instance "model.output.gz" implies a gzip compression type.\n  \nNotes\n-----\n\nA model with user defined function (aka. UDF) can not be serialized to file.\n\n\n\n\n'''
        err = admm_model_write(self.mdl_, bytes(fname, "utf8"))
        if err != 0: raise ADMMError(err)

    def dispose(self):
        '''\nInstantly free memory for model object, or model may be freed automatically by\ngarbage collector.\n\n\n\n\n'''
        if self.needfree_ == 1:
            self.needfree_ = 0
            self.udfrefs_ = []
            admm_destroy(self.mdl_)

    def __del__(self):
        self.dispose()

    def __dealloc__(self):
        self.dispose()

def tv2d(x, p=1):
    '''\nReturn total variation for matrix.\n\nParameters\n----------\nx: Union[TensorLike, ArrayLike]\n\n  The expression, should be a matrix.\n  \np: int = 1\n\n  The norm level, supports 1 or 2.\n  \nReturns\n-------\nUnion[Expr, Constant]\n\nThe result scalar.\n'''
    if isinstance(p, (Var, Expr)):
        raise TypeError("constant expression is expected for argument `p`")
    if p == 1 or p == 2:
        return _binary_fun_impl(223, x, p)
    raise ValueError("unsupported p (only 1 or 2)")

# --- Bug-fix overrides (must come AFTER include "dynamic.pxi" so they shadow ---
# --- the auto-generated versions when the module loads)                       ---

def norm(x, ord=None):
    '''\nCompute the norm for an expression or constant.\n\nParameters\n----------\nx: Union[TensorLike, ArrayLike]\n\n  The expression or constant.\n  \nord: Union[int, str] = None\n\n  The norm level:\n  \n    * None - level 2 norm for vector and Frobenius norm for matrix.\n  \n    * 1 - for level 1 norm. It is, sum(abs(x)) for vector, and for matrix, max column\n      sum of absolute values.\n  \n    * 2 - for level 2 norm. It is, sqrt(sum(x^2)) for vector, and largest singular\n      value for matrix.\n  \n    * inf - for inf norm. It is, max(abs(x)) for vector, and max row sum of absolute\n      values for matrix.\n  \n    * 'fro' - for frobenius norm. It is, sqrt(sum(x^2)) for matrix.\n  \n    * 'nuc' - for nuclear norm. It is, sum for all singular values.\n  \nReturns\n-------\nUnion[Expr, Constant]\n\nThe scalar norm value.\n\n\n\n\n'''
    if ord==1: return _unary_fun_impl(103, x)
    if ord==2: return _unary_fun_impl(104, x)
    if ord=='fro': return _unary_fun_impl(105, x)
    if ord==inf: return _unary_fun_impl(116, x)
    if ord==None: return _unary_fun_impl(117, x)
    if ord=='nuc': return _unary_fun_impl(121, x)
    raise ValueError("unexpected argument(s)")

def maximum(x, b):
    '''\nReturn a new tensor, each element of new tensor is the larger of the corresponding\nelements in `x` and `b`.\n\nParameters\n----------\nx: Union[TensorLike, ArrayLike]\n\n  The expression.\n  \nb: ArrayLike\n\n  The lower bound tensor constant.\n  \nReturns\n-------\nUnion[Expr, Constant]\n\nThe result expression.\n\n\n\n\n'''
    if isinstance(b, (Var, Expr)):
        # maximum is commutative — accept maximum(const, expr) by swapping args
        if isinstance(x, (Var, Expr)):
            raise TypeError("constant expression is expected for argument `b`")
        return _binary_fun_impl(201, b, x)
    return _binary_fun_impl(201, x, b)
REVISION='1.0.2604111441'
