# (C) Copyright 2025 Anemoi contributors.
#
# This software is licensed under the terms of the Apache Licence Version 2.0
# which can be obtained at http://www.apache.org/licenses/LICENSE-2.0.
#
# In applying this licence, ECMWF does not waive the privileges and immunities
# granted to it by virtue of its status as an intergovernmental organisation
# nor does it submit to any jurisdiction.


import argparse
import logging
import os

import numpy as np

from anemoi.transform.commands import Command
from anemoi.transform.constants import L_1_degree_earth_arc_length_km as L_1d_km

LOG = logging.getLogger(__name__)


def _xr_ds_lat_lon(path: str, lat_name: str, lon_name: str) -> tuple[np.ndarray, np.ndarray]:
    import xarray as xr

    ds = xr.open_dataset(path)
    lat = ds[lat_name].values.flatten()
    lon = ds[lon_name].values.flatten()
    return lat, lon


def _ds_to_lat_lon(path: str) -> tuple[np.ndarray, np.ndarray]:
    import earthkit.data as ekd

    try:
        ds = ekd.from_source("file", path)
        return ds[0].grid_points()
    except TypeError:
        # This is a workaround for datasets that do not have data variables,
        # but have "latitude" and "longitude" coordinates.
        return _xr_ds_lat_lon(path, "latitude", "longitude")


def _path_to_lat_lon(path: str) -> tuple[np.ndarray, np.ndarray]:
    """Extract latitudes and longitudes from a file path."""
    import numpy as np

    if path.endswith(".npz"):
        data = np.load(path)
        return data["latitudes"], data["longitudes"]
    if path.endswith(".zarr"):
        # assume anemoi-dataset first - load with xarray
        try:
            return _xr_ds_lat_lon(path, "latitudes", "longitudes")
        except KeyError:
            pass

    # fallback to earthkit-data
    return _ds_to_lat_lon(path)


def check_duplicate_latlons(input_file: str, latitudes: np.ndarray, longitudes: np.ndarray) -> None:
    LOG.info(f"Checking for duplicate lat/lon pairs in {input_file}...")
    seen = set()
    for lat, lon in zip(latitudes, longitudes):
        if (lat, lon) in seen:
            raise ValueError(f"Duplicate latitude/longitude pair found in {input_file}: ({lat}, {lon})")
        seen.add((lat, lon))


def round_lat_lon(latitudes: np.ndarray, longitudes: np.ndarray, num_decimals: int) -> tuple[np.ndarray, np.ndarray]:
    import numpy as np

    LOG.info(
        f"Rounding latitudes and longitudes to {num_decimals} decimal places ({L_1d_km / (10) ** num_decimals} m)."
    )
    return np.round(latitudes, num_decimals), np.round(longitudes, num_decimals)


class MakeMIRMatrix:
    """Extract the grid from a pair GRIB or NetCDF files extract the MIR interpolation matrix to be used
    by earthkit-regrid.
    """

    def add_arguments(self, command_parser: argparse.ArgumentParser) -> None:
        """Add arguments to the command parser.

        Parameters
        ----------
        command_parser : argparse.ArgumentParser
            The argument parser to add arguments to.
        """
        command_parser.add_argument("--source-grid", help="Input file (GRIB or NetCDF).", required=True)
        command_parser.add_argument("--target-grid", help="Input file (GRIB or NetCDF).", required=True)

        command_parser.add_argument(
            "--mir", default=os.environ.get("MIR_COMMAND", "mir"), help="MIR command (default: 'mir')."
        )
        command_parser.add_argument(
            "--rounding",
            type=int,
            help="Round latitudes and longitudes to this precision (default: None).",
        )
        command_parser.add_argument("--check", action="store_true", help="Check for duplicate lat/lon pairs.")
        command_parser.add_argument(
            "--mir_args",
            nargs="*",
            help="MIR arguments. Usage: --mir_args arg1=val1 arg2=val2 ...",
            type=lambda kv: kv.split("="),
        )
        command_parser.add_argument(
            "--output",
            type=str,
            help="Output NPZ file. The name will be used to determine the type of regrid file to create.",
            required=True,
        )

    def run(self, args: argparse.Namespace) -> None:
        """Run the command with the provided arguments.

        Parameters
        ----------
        args : argparse.Namespace
            The arguments to run the command with.
        """
        mir_kwargs = dict(args.mir_args) if args.mir_args is not None else {}
        source_lat, source_lon = _path_to_lat_lon(args.source_grid)
        target_lat, target_lon = _path_to_lat_lon(args.target_grid)

        if args.rounding is not None:
            source_lat, source_lon = round_lat_lon(source_lat, source_lon, args.rounding)
            target_lat, target_lon = round_lat_lon(target_lat, target_lon, args.rounding)

        if args.check:
            check_duplicate_latlons(args.source_grid, source_lat, source_lon)
            check_duplicate_latlons(args.target_grid, target_lat, target_lon)

        MakeMIRMatrix.make_mir_matrix(
            source_lat, source_lon, target_lat, target_lon, output=args.output, mir=args.mir, **mir_kwargs
        )

    @staticmethod
    def make_mir_matrix(lat1, lon1, lat2, lon2, output=None, mir="mir", **mir_kwargs):

        import numpy as np
        from earthkit.regrid.utils.mir import mir_make_matrix

        sparse_array = mir_make_matrix(lat1, lon1, lat2, lon2, output=None, mir=mir, **mir_kwargs)

        np.savez(
            output,
            matrix_data=sparse_array.data,
            matrix_indices=sparse_array.indices,
            matrix_indptr=sparse_array.indptr,
            matrix_shape=sparse_array.shape,
            in_latitudes=lat1,
            in_longitudes=lon1,
            out_latitudes=lat2,
            out_longitudes=lon2,
        )


class MakeGlobalOnLamMask:

    def add_arguments(self, command_parser: argparse.ArgumentParser) -> None:
        """Add arguments to the command parser.

        Parameters
        ----------
        command_parser : argparse.ArgumentParser
            The argument parser to add arguments to.
        """
        command_parser.add_argument("--lam-grid", help="Input file (GRIB or NetCDF).", required=True)
        command_parser.add_argument("--global-grid", help="Input file (GRIB or NetCDF).", required=True)
        command_parser.add_argument(
            "--distance-km",
            type=float,
            default=None,
            help="Distance in kilometers to consider for the mask. If None, use the spacing of the global grid.",
        )
        command_parser.add_argument(
            "--output",
            type=str,
            help="Output NPZ file. The name will be used to determine the type of regrid file to create.",
            required=True,
        )
        command_parser.add_argument(
            "--plot",
            type=str,
            help="A path in which to plot the mask.",
        )

    def run(self, args: argparse.Namespace) -> None:
        """Run the command with the provided arguments.

        Parameters
        ----------
        args : argparse.Namespace
            The arguments to run the command with.
        """

        lam_lat, lam_lon = _path_to_lat_lon(args.lam_grid)
        global_lat, global_lon = _path_to_lat_lon(args.global_grid)

        MakeGlobalOnLamMask.make_global_on_lam_mask(
            lam_lat,
            lam_lon,
            global_lat,
            global_lon,
            output=args.output,
            plot_path=args.plot,
            distance_km=args.distance_km,
        )

    @staticmethod
    def _lat_lon_plot(lat: np.ndarray, lon: np.ndarray, plot_path: str) -> None:
        import matplotlib.pyplot as plt
        import numpy as np

        lon = np.where(lon >= 180, lon - 360, lon)
        plt.figure(figsize=(10, 5))
        plt.scatter(lon, lat, s=0.1, c="k")
        plt.savefig(plot_path)

    @staticmethod
    def make_global_on_lam_mask(
        lam_lat: np.ndarray,
        lam_lon: np.ndarray,
        global_lat: np.ndarray,
        global_lon: np.ndarray,
        output: str,
        plot_path: str | None = None,
        **kwargs,
    ) -> None:
        import numpy as np

        from anemoi.transform.spatial import global_on_lam_mask

        mask = global_on_lam_mask(lam_lat, lam_lon, global_lat, global_lon, **kwargs)
        np.savez(output, mask=mask)
        if plot_path:
            MakeGlobalOnLamMask._lat_lon_plot(global_lat[mask], global_lon[mask], plot_path)


OPTIONS = {
    "mir-matrix": MakeMIRMatrix,
    "global-on-lam-mask": MakeGlobalOnLamMask,
}


class MakeRegridFile(Command):
    """Extract the grid from a pair GRIB or NetCDF files extract the MIR interpolation matrix to be used
    by earthkit-regrid.
    """

    def add_arguments(self, command_parser: argparse.ArgumentParser) -> None:
        """Add arguments to the command parser.

        Parameters
        ----------
        command_parser : argparse.ArgumentParser
            The argument parser to add arguments to.
        """

        subparsers = command_parser.add_subparsers(dest="type", required=True)

        for k, v in OPTIONS.items():
            subparser = subparsers.add_parser(k, help=v.__doc__)
            v().add_arguments(subparser)

    def run(self, args: argparse.Namespace) -> None:
        OPTIONS[args.type]().run(args)


command = MakeRegridFile
