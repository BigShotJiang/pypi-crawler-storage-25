# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

Please add your functional changes to the appropriate section in the PR.
Keep it human-readable, your future self will thank you!


## [0.2.0](https://github.com/ecmwf/anemoi-transform/compare/0.1.29...0.2.0) (2026-04-15)


### ⚠ BREAKING CHANGES

* Add ability to call tabular filters from `anemoi-datasets` ([#268](https://github.com/ecmwf/anemoi-transform/issues/268))

### Features

* Add ability to call tabular filters from `anemoi-datasets` ([#268](https://github.com/ecmwf/anemoi-transform/issues/268)) ([a8e8b50](https://github.com/ecmwf/anemoi-transform/commit/a8e8b509ae011c5c0213d68df4429b20822d60b9))

## [0.1.29](https://github.com/ecmwf/anemoi-transform/compare/0.1.28...0.1.29) (2026-03-20)


### Features

* Add dispatching filters for filters which work on both tabular/field data ([#265](https://github.com/ecmwf/anemoi-transform/issues/265)) ([4839cd3](https://github.com/ecmwf/anemoi-transform/commit/4839cd3aa49d9675a64426c55ca4de662bfa69f9))
* Add the ability to merge filter registries ([#267](https://github.com/ecmwf/anemoi-transform/issues/267)) ([064745f](https://github.com/ecmwf/anemoi-transform/commit/064745fa8fe0daf3a915c4c512a372da4d122eb5))
* Allow masking from numpy ([#254](https://github.com/ecmwf/anemoi-transform/issues/254)) ([ece1a88](https://github.com/ecmwf/anemoi-transform/commit/ece1a8876959df450ca5219f2bb0a42904bfff4f))


### Bug Fixes

* Argument reference from mir_kwargs to mir_args ([#256](https://github.com/ecmwf/anemoi-transform/issues/256)) ([83d1118](https://github.com/ecmwf/anemoi-transform/commit/83d11183f9e8d1b8a0ab12321034890ba3e95fe6))

## [0.1.28](https://github.com/ecmwf/anemoi-transform/compare/0.1.27...0.1.28) (2026-03-13)


### Features

* Ability for apply-mask to work on a single param ([#251](https://github.com/ecmwf/anemoi-transform/issues/251)) ([8f4ed7c](https://github.com/ecmwf/anemoi-transform/commit/8f4ed7ce3788787d0e25cd2d75b78934c7760604))

## [0.1.27](https://github.com/ecmwf/anemoi-transform/compare/0.1.26...0.1.27) (2026-02-26)


### Features

* Add `return_distances` option to nearest grid point lookup function ([#237](https://github.com/ecmwf/anemoi-transform/issues/237)) ([c1d3133](https://github.com/ecmwf/anemoi-transform/commit/c1d3133e2dc2daf5d6f660c17b0f9f4ecab67d55))
* Import tabular filters ([#216](https://github.com/ecmwf/anemoi-transform/issues/216)) ([548e2fa](https://github.com/ecmwf/anemoi-transform/commit/548e2fabf18a2ed1197b03969ce7eb179c3e8608))


### Bug Fixes

* Grouping key changed to frozenset ([#239](https://github.com/ecmwf/anemoi-transform/issues/239)) ([7a5b427](https://github.com/ecmwf/anemoi-transform/commit/7a5b427eee0bb37e9407a45d13277ae853801f26))

## [0.1.26](https://github.com/ecmwf/anemoi-transform/compare/0.1.25...0.1.26) (2026-02-18)


### Features

* Add `num_neighbours_to_return` parameter to nearest_grid_points ([#233](https://github.com/ecmwf/anemoi-transform/issues/233)) ([be82c69](https://github.com/ecmwf/anemoi-transform/commit/be82c692319dfeef818f62698fa740281e5e2034))
* Add DispatchingFilter class ([#218](https://github.com/ecmwf/anemoi-transform/issues/218)) ([f0d877a](https://github.com/ecmwf/anemoi-transform/commit/f0d877a0f2ed9b8537788238e12bf8318b626051))

## [0.1.25](https://github.com/ecmwf/anemoi-transform/compare/0.1.24...0.1.25) (2026-02-17)


### Bug Fixes

* Compute length of 1deg arc based on data points ([#229](https://github.com/ecmwf/anemoi-transform/issues/229)) ([5ab1db3](https://github.com/ecmwf/anemoi-transform/commit/5ab1db33cd503d6fa23b6428a2ce1842a8efbf26))

## [0.1.24](https://github.com/ecmwf/anemoi-transform/compare/0.1.23...0.1.24) (2026-02-16)


### Bug Fixes

* Length of 1deg arc constant ([#222](https://github.com/ecmwf/anemoi-transform/issues/222)) ([a98974c](https://github.com/ecmwf/anemoi-transform/commit/a98974ce08170a15565fbed471c0f2e6dba3d215))

## [0.1.23](https://github.com/ecmwf/anemoi-transform/compare/0.1.22...0.1.23) (2026-02-05)


### Features

* **cutout_mask:** Add new optional argument `max_distance_km` to cutout_mask() function ([#214](https://github.com/ecmwf/anemoi-transform/issues/214)) ([b1e015f](https://github.com/ecmwf/anemoi-transform/commit/b1e015f5a4c0b9bd4df53636809e640e748dc7b3))

## [0.1.22](https://github.com/ecmwf/anemoi-transform/compare/0.1.21...0.1.22) (2026-01-28)


### Bug Fixes

* Pin min version for ruamel-yaml ([#209](https://github.com/ecmwf/anemoi-transform/issues/209)) ([78bd07f](https://github.com/ecmwf/anemoi-transform/commit/78bd07f88e4112b0e10aff8baff87d3e843671ec))

## [0.1.21](https://github.com/ecmwf/anemoi-transform/compare/0.1.20...0.1.21) (2026-01-23)


### Features

* Add support for masks in `regrid` filter ([#108](https://github.com/ecmwf/anemoi-transform/issues/108)) ([89d5214](https://github.com/ecmwf/anemoi-transform/commit/89d521430744ddafdb285a645ff2d4ac02b47e05))


### Bug Fixes

* Add `patch_data_request` to some filters ([#203](https://github.com/ecmwf/anemoi-transform/issues/203)) ([22abaf7](https://github.com/ecmwf/anemoi-transform/commit/22abaf7547b7357bae5b280e1422302c2d040c00))
* Remove `variable` key in `GroupByParamVertical` ([#202](https://github.com/ecmwf/anemoi-transform/issues/202)) ([b3e338b](https://github.com/ecmwf/anemoi-transform/commit/b3e338b9efe281754459249078104b57ec13b903))

## [0.1.20](https://github.com/ecmwf/anemoi-transform/compare/0.1.19...0.1.20) (2026-01-15)


### Features

* Add param option to the remove_nans filter ([#190](https://github.com/ecmwf/anemoi-transform/issues/190)) ([eaaeef5](https://github.com/ecmwf/anemoi-transform/commit/eaaeef5a114d701470a8e95f28f7d4d0a537a99a))
* Rotate/unrotate winds filters ([#150](https://github.com/ecmwf/anemoi-transform/issues/150)) ([3f957a2](https://github.com/ecmwf/anemoi-transform/commit/3f957a212ac4e5739248ce705da8812860386f0f))


### Bug Fixes

* Fix time metadata ([#188](https://github.com/ecmwf/anemoi-transform/issues/188)) ([96b3c3e](https://github.com/ecmwf/anemoi-transform/commit/96b3c3e8dcc551fc5d2ed0294070c8d3ec7af878))

## [0.1.19](https://github.com/ecmwf/anemoi-transform/compare/0.1.18...0.1.19) (2025-11-07)


### Features

* Support formats in rename filter ([#186](https://github.com/ecmwf/anemoi-transform/issues/186)) ([00e9890](https://github.com/ecmwf/anemoi-transform/commit/00e989013018bfde8d8f73da17c0b59265d7760b))


### Bug Fixes

* Update README to reflect project maturity status ([#184](https://github.com/ecmwf/anemoi-transform/issues/184)) ([d183f94](https://github.com/ecmwf/anemoi-transform/commit/d183f94c44f3729a97d5d09fe00e865191856973))

## [0.1.18](https://github.com/ecmwf/anemoi-transform/compare/0.1.17...0.1.18) (2025-10-30)


### Features

* Add AccumToInterval filter transform ([#168](https://github.com/ecmwf/anemoi-transform/issues/168)) ([0801a4b](https://github.com/ecmwf/anemoi-transform/commit/0801a4b1ea040262efcc4edd654419e0e73ecc54))
* Generic cos sin from rad filter ([#180](https://github.com/ecmwf/anemoi-transform/issues/180)) ([7fabff9](https://github.com/ecmwf/anemoi-transform/commit/7fabff9d00b685513c36eb4d71aae54368b0d199))


### Bug Fixes

* Clarify error message ([#181](https://github.com/ecmwf/anemoi-transform/issues/181)) ([1cd0536](https://github.com/ecmwf/anemoi-transform/commit/1cd0536f68d560cd02644cd9ba305b9db2deebf0))
* Remove variable from xarray metadata when grouping ([#182](https://github.com/ecmwf/anemoi-transform/issues/182)) ([46465cd](https://github.com/ecmwf/anemoi-transform/commit/46465cdab7518d49e660bacded13763547730d0f))

## [0.1.17](https://github.com/ecmwf/anemoi-transform/compare/0.1.16...0.1.17) (2025-10-01)


### Features

* Add lsnp to sp filter ([#163](https://github.com/ecmwf/anemoi-transform/issues/163)) ([7c19393](https://github.com/ecmwf/anemoi-transform/commit/7c19393aa2347a329c7a41488cfd83de821fae2d))
* Add methods to MD() in field wrapper ([#173](https://github.com/ecmwf/anemoi-transform/issues/173)) ([c564459](https://github.com/ecmwf/anemoi-transform/commit/c56445974e0eb73ac5fd54df414b79d146f99bb6))
* Control returned inputs in filters ([#100](https://github.com/ecmwf/anemoi-transform/issues/100)) ([32cb937](https://github.com/ecmwf/anemoi-transform/commit/32cb937bc64d89140523d8797e62650d2256db75))
* **filters:** Add filter for thermodynamic conversions at specific height levels ([#140](https://github.com/ecmwf/anemoi-transform/issues/140)) ([c28fd07](https://github.com/ecmwf/anemoi-transform/commit/c28fd07e0acbcc7453d6b02dfb17af585fc46ab5))


### Bug Fixes

* **filter:** Fix small bug in rename filter ([#164](https://github.com/ecmwf/anemoi-transform/issues/164)) ([8fb7158](https://github.com/ecmwf/anemoi-transform/commit/8fb7158c6aa9bd15993ef705a2e5d859151187ab))
* Rename filter metadata handling ([#165](https://github.com/ecmwf/anemoi-transform/issues/165)) ([eb16768](https://github.com/ecmwf/anemoi-transform/commit/eb167687fd99ab109dec5a7901041a2b7d7cdd1f))
* Replace assert with warning ([#157](https://github.com/ecmwf/anemoi-transform/issues/157)) ([ca55a62](https://github.com/ecmwf/anemoi-transform/commit/ca55a62b5511471dc3d9df14c2ec6c0b56cf55d6))


### Documentation

* Filter documentation review ([#172](https://github.com/ecmwf/anemoi-transform/issues/172)) ([c606ed6](https://github.com/ecmwf/anemoi-transform/commit/c606ed69a6e6e2ab34402bbcb3d003083a701467))
* Revisit documentation of filters ([#169](https://github.com/ecmwf/anemoi-transform/issues/169)) ([2657b13](https://github.com/ecmwf/anemoi-transform/commit/2657b13bea53fe7b1782221551a8c714a5f1bc78))

## [0.1.16](https://github.com/ecmwf/anemoi-transform/compare/0.1.15...0.1.16) (2025-08-05)


### Features

* Improve conftest types ([#144](https://github.com/ecmwf/anemoi-transform/issues/144)) ([bc9c4cd](https://github.com/ecmwf/anemoi-transform/commit/bc9c4cd16b08399f74d8d3a8f0f874be82fda97d))
* Rodeo filters add docs and fix masking of QI ([#145](https://github.com/ecmwf/anemoi-transform/issues/145)) ([0104c00](https://github.com/ecmwf/anemoi-transform/commit/0104c008cc3666a988fa8814447d490ec7ca59fd))

## [0.1.15](https://github.com/ecmwf/anemoi-transform/compare/0.1.14...0.1.15) (2025-07-31)


### Features

* Add tox config ([#131](https://github.com/ecmwf/anemoi-transform/issues/131)) ([11766a0](https://github.com/ecmwf/anemoi-transform/commit/11766a0f10d562577c869937b61ebf26e9ff1d19))
* Remove python 3.9 from pyproject.toml. ([#142](https://github.com/ecmwf/anemoi-transform/issues/142)) ([fb476a2](https://github.com/ecmwf/anemoi-transform/commit/fb476a269bbcd69e01e47a7fdc2bda286c72bd82))


### Bug Fixes

* Apply_mask with non-boolean masks ([#91](https://github.com/ecmwf/anemoi-transform/issues/91)) ([b6f2222](https://github.com/ecmwf/anemoi-transform/commit/b6f22221428a77157a2f3e78c611b52a7a71358b))


### Documentation

* Filter migration ([#134](https://github.com/ecmwf/anemoi-transform/issues/134)) ([da0052c](https://github.com/ecmwf/anemoi-transform/commit/da0052cf07b949bc108c6480ecae7a918f0ded02))

## [0.1.14](https://github.com/ecmwf/anemoi-transform/compare/0.1.13...0.1.14) (2025-07-22)


### Features

* **variable:** Period property for non-instant fields ([#132](https://github.com/ecmwf/anemoi-transform/issues/132)) ([a086896](https://github.com/ecmwf/anemoi-transform/commit/a086896e9cf4c5f7987e50b993296fcae1bc080a))


### Bug Fixes

* Remove need for nested rename in YAML ([#128](https://github.com/ecmwf/anemoi-transform/issues/128)) ([d92bf7f](https://github.com/ecmwf/anemoi-transform/commit/d92bf7fcd91ad0114c17aa0ee2c08a1370d14c99))

## [0.1.13](https://github.com/ecmwf/anemoi-transform/compare/0.1.12...0.1.13) (2025-07-14)


### Bug Fixes

* Warn rather than fail on metadata mismatch in matching filter ([#126](https://github.com/ecmwf/anemoi-transform/issues/126)) ([bd4fa73](https://github.com/ecmwf/anemoi-transform/commit/bd4fa73f761852622e19314361db9a6f9f69b9de))

## [0.1.12](https://github.com/ecmwf/anemoi-transform/compare/0.1.11...0.1.12) (2025-07-14)


### Features

* Add orography to surface geopotential filter ([#115](https://github.com/ecmwf/anemoi-transform/issues/115)) ([9b7fd8d](https://github.com/ecmwf/anemoi-transform/commit/9b7fd8d74227461e7bb2f4abd1775ea9342da461))
* Add SingleFieldFilter ([#104](https://github.com/ecmwf/anemoi-transform/issues/104)) ([914d1df](https://github.com/ecmwf/anemoi-transform/commit/914d1df883732c12b32cb4f4f0e0389875e044d7))
* Filter migration from anemoi-datasets + testing ([#93](https://github.com/ecmwf/anemoi-transform/issues/93)) ([abfb33d](https://github.com/ecmwf/anemoi-transform/commit/abfb33d20f26604d481099e9ed8a0a4fe4e1f2cd))
* General purpose clipping filter ([#96](https://github.com/ecmwf/anemoi-transform/issues/96)) ([f70b1ab](https://github.com/ecmwf/anemoi-transform/commit/f70b1abc37844046e1f2a7bf9ba60818ccfbecaa))
* Migrate sum filter ([#121](https://github.com/ecmwf/anemoi-transform/issues/121)) ([3b5596e](https://github.com/ecmwf/anemoi-transform/commit/3b5596e37797a645582b6a2b49b5eae4c1391c90))
* Set resolution metadata in filter operation. ([#98](https://github.com/ecmwf/anemoi-transform/issues/98)) ([7844fea](https://github.com/ecmwf/anemoi-transform/commit/7844fea7cf5f849a9dfd7242440eb9721d0ee9f8))


### Bug Fixes

* Docs sphinx dependency python&gt;=3.11 ([#116](https://github.com/ecmwf/anemoi-transform/issues/116)) ([29f6290](https://github.com/ecmwf/anemoi-transform/commit/29f62906b53af2db87520ec2a93406258861e677))
* Fixed typo in error message ([#120](https://github.com/ecmwf/anemoi-transform/issues/120)) ([242c836](https://github.com/ecmwf/anemoi-transform/commit/242c836e6ca4c267755ea143f4d83993ba61471f))

## [0.1.11](https://github.com/ecmwf/anemoi-transform/compare/0.1.10...0.1.11) (2025-05-26)


### Features

* Extend Variable Class ([#94](https://github.com/ecmwf/anemoi-transform/issues/94)) ([dd32ccf](https://github.com/ecmwf/anemoi-transform/commit/dd32ccfcfae54d17b02d82aa869b39dff886df41))
* thermo conversions ([#86](https://github.com/ecmwf/anemoi-transform/issues/86)) ([fce0db5](https://github.com/ecmwf/anemoi-transform/commit/fce0db53c6352fdc39b9dc2f3ff9e2715dd8d279))


### Bug Fixes

* Rodeo delivery ([#101](https://github.com/ecmwf/anemoi-transform/issues/101)) ([54ccd7f](https://github.com/ecmwf/anemoi-transform/commit/54ccd7f95813e8f58353b8593c41ef21218ea1c3))

## [Unreleased](https://github.com/ecmwf/anemoi-utils/transform/0.0.5...HEAD/compare/0.0.9...HEAD)

## [0.0.9](https://github.com/ecmwf/anemoi-utils/transform/0.0.5...HEAD/compare/0.0.8...0.0.9) - 2024-11-01
## [0.1.10](https://github.com/ecmwf/anemoi-transform/compare/0.1.9...0.1.10) (2025-05-06)


### Bug Fixes

* change literal string to variable in `icon_grid` ([#88](https://github.com/ecmwf/anemoi-transform/issues/88)) ([a7459ea](https://github.com/ecmwf/anemoi-transform/commit/a7459ea5862d06d45c4a0f9458bbeecf589a7fa4))

## [0.1.9](https://github.com/ecmwf/anemoi-transform/compare/0.1.8...0.1.9) (2025-04-05)


### Features

* add grid class and factory ([#71](https://github.com/ecmwf/anemoi-transform/issues/71)) ([db0b70a](https://github.com/ecmwf/anemoi-transform/commit/db0b70ad8eb00945d573c69b665fe1859b0889d9))


### Bug Fixes

* grid support ([#82](https://github.com/ecmwf/anemoi-transform/issues/82)) ([c1dc21d](https://github.com/ecmwf/anemoi-transform/commit/c1dc21d487853e5414decf50a637ce04d629ea54))


### Documentation

* fix typo ([#80](https://github.com/ecmwf/anemoi-transform/issues/80)) ([7bb1d2d](https://github.com/ecmwf/anemoi-transform/commit/7bb1d2d027d1b1f84b5945df6c6ad1bdec80ec79))

## [0.1.8](https://github.com/ecmwf/anemoi-transform/compare/0.1.7...0.1.8) (2025-03-31)


### Bug Fixes

* sea ice concentration correctly treated in oras6_clipping ([#78](https://github.com/ecmwf/anemoi-transform/issues/78)) ([703813a](https://github.com/ecmwf/anemoi-transform/commit/703813aebcdd883d6710a4d15674f9f1bde24a56))

## [0.1.7](https://github.com/ecmwf/anemoi-transform/compare/0.1.6...0.1.7) (2025-03-31)


### Documentation

* fix ([#76](https://github.com/ecmwf/anemoi-transform/issues/76)) ([fc8acad](https://github.com/ecmwf/anemoi-transform/commit/fc8acad014a3e1f5179e403171f1ef2c924accd2))

## [0.1.6](https://github.com/ecmwf/anemoi-transform/compare/0.1.5...0.1.6) (2025-03-31)


### Features

* add GRIB flavours ([#72](https://github.com/ecmwf/anemoi-transform/issues/72)) ([a5cb523](https://github.com/ecmwf/anemoi-transform/commit/a5cb523712d8ad5ad48e644524ca43c4bdf73361))

## [0.1.5](https://github.com/ecmwf/anemoi-transform/compare/0.1.4...0.1.5) (2025-03-28)


### Bug Fixes

* missing metadata attribute ([#68](https://github.com/ecmwf/anemoi-transform/issues/68)) ([4f69cb4](https://github.com/ecmwf/anemoi-transform/commit/4f69cb480cc09c1b9b466a81b671b8427c87866d))


### Documentation

* Docathon ([#62](https://github.com/ecmwf/anemoi-transform/issues/62)) ([413665c](https://github.com/ecmwf/anemoi-transform/commit/413665cf8b475bbf673017bca66b9b1360ded4ea))

## [0.1.4](https://github.com/ecmwf/anemoi-transform/compare/0.1.3...0.1.4) (2025-03-24)


### Features

* plugin support ([#65](https://github.com/ecmwf/anemoi-transform/issues/65)) ([7481145](https://github.com/ecmwf/anemoi-transform/commit/7481145c51f4fbf2fdd43a9b8822b18e32b62449))
* Rodeo transform update ([#61](https://github.com/ecmwf/anemoi-transform/issues/61)) ([3e669c0](https://github.com/ecmwf/anemoi-transform/commit/3e669c0207c68b897126e128a76d82a921960522))


### Bug Fixes

* fix regrid arguments ([#67](https://github.com/ecmwf/anemoi-transform/issues/67)) ([1a730cd](https://github.com/ecmwf/anemoi-transform/commit/1a730cd6354cdd00eedc82ec5bf57eea34e8f797))
* return unmodified fields ([#57](https://github.com/ecmwf/anemoi-transform/issues/57)) ([6f0e6f4](https://github.com/ecmwf/anemoi-transform/commit/6f0e6f46506f8eef28219a26e1cfddca6b81793d))
* undetected as dry pixels and meaningful naming ([#59](https://github.com/ecmwf/anemoi-transform/issues/59)) ([b66ce25](https://github.com/ecmwf/anemoi-transform/commit/b66ce25af3f1affc5c8162567a5754dc91b14889))


### Documentation

* links to GitHub ([#66](https://github.com/ecmwf/anemoi-transform/issues/66)) ([10f5c13](https://github.com/ecmwf/anemoi-transform/commit/10f5c138a6c96f1420d476d0171c5f1850cac43b))

## [0.1.3](https://github.com/ecmwf/anemoi-transform/compare/0.1.2...0.1.3) (2025-03-06)


### Features

* Add `icon_refinement_level` filter ([#32](https://github.com/ecmwf/anemoi-transform/issues/32)) ([a2c0711](https://github.com/ecmwf/anemoi-transform/commit/a2c07114c18e6b631401f92519bd760564f8e1ac))
* Clipping strategy to solve issues in the ORAS6 reanalysis ([#56](https://github.com/ecmwf/anemoi-transform/issues/56)) ([179d602](https://github.com/ecmwf/anemoi-transform/commit/179d602f84ad87d5f7d6fe3b7d2348ed74d55a13))
* Matching fields ([#55](https://github.com/ecmwf/anemoi-transform/issues/55)) ([b6f52d6](https://github.com/ecmwf/anemoi-transform/commit/b6f52d6073b3b5de7e44e5e4694b8eeab0b339c2))


### Bug Fixes

* for opera mask ([#40](https://github.com/ecmwf/anemoi-transform/issues/40)) ([a1f8bf8](https://github.com/ecmwf/anemoi-transform/commit/a1f8bf8b49db74d7b79dea0a800d00dabdaa1ba2))


### Documentation

* fix readthedocs ([#51](https://github.com/ecmwf/anemoi-transform/issues/51)) ([42e874b](https://github.com/ecmwf/anemoi-transform/commit/42e874b1020f6d542d6bf9d20ee3c43483c2abcb))
* use new logo ([#42](https://github.com/ecmwf/anemoi-transform/issues/42)) ([aa13ac5](https://github.com/ecmwf/anemoi-transform/commit/aa13ac5b9424d40f5d6bce8279ecbe73292bcc0b))

## 0.1.2 (2025-02-04)

<!-- Release notes generated using configuration in .github/release.yml at main -->

## What's Changed
### Other Changes 🔗
* chore: synced file(s) with ecmwf-actions/reusable-workflows by @DeployDuck in https://github.com/ecmwf/anemoi-transform/pull/30

## New Contributors
* @DeployDuck made their first contribution in https://github.com/ecmwf/anemoi-transform/pull/30

**Full Changelog**: https://github.com/ecmwf/anemoi-transform/compare/0.1.1...0.1.2

## [Unreleased](https://github.com/ecmwf/anemoi-utils/transform/0.0.5...HEAD/compare/0.1.0...HEAD)

### Added

- Add regrid filter
- Added repeat-member #18
- Add `get-grid` command
- Add `cos_sin_mean_wave_direction` filter
- Add `icon_refinement_level` filter

## [0.1.0](https://github.com/ecmwf/anemoi-utils/transform/0.0.5...HEAD/compare/0.0.8...0.1.0) - 2024-11-18

## [0.0.8](https://github.com/ecmwf/anemoi-utils/transform/0.0.5...HEAD/compare/0.0.5...0.0.8) - 2024-10-26

### Added

- Add CONTRIBUTORS.md (#5)

### Changed

- Add more attributes to typed variables
- Fix `__version__` import in init
- Update copyright notice
- Add more methods

## [0.0.1] - Initial Release

### Added

- Project skeleton
