__version__ = "1.0.4"

from subs_down_n_sync.core import run

__all__ = ["run", "__version__"]
