"""Procedural skill packages for Aegis."""

from .builtins import builtin_skill_definitions
from .hub import (
    SkillHub,
    SkillHubEntry,
    SkillHubSource,
    builtin_aegis_skill_source_root,
    default_aegis_skill_source_root,
    default_authored_aegis_skill_source_root,
    default_installed_aegis_skill_source_root,
    default_skill_hub_sources,
)
from .inventory import SKILL_SURFACES
from .search import (
    FetchedSkillBundle,
    RawSkillBundle,
    SkillSearchEntry,
    SkillSearchHub,
    SkillSearchSource,
    default_skill_search_sources,
)
from .runtime import (
    InMemorySkillCatalog,
    JsonSkillLoader,
    SkillPackageLoader,
    SkillActivationContext,
    SkillActivationRecord,
    SkillCatalog,
    SkillDefinition,
    SkillDependency,
    SkillLoader,
    SkillManifest,
    SkillManifestLoadRecord,
    SkillRuntime,
    SkillScope,
    load_skill_package_definition,
)
from .authoring import materialize_skill_package

__all__ = [
    "InMemorySkillCatalog",
    "JsonSkillLoader",
    "SKILL_SURFACES",
    "SkillHub",
    "SkillHubEntry",
    "SkillHubSource",
    "SkillActivationContext",
    "SkillActivationRecord",
    "SkillCatalog",
    "SkillDefinition",
    "SkillDependency",
    "SkillLoader",
    "SkillManifest",
    "SkillManifestLoadRecord",
    "SkillPackageLoader",
    "SkillSearchEntry",
    "SkillSearchHub",
    "SkillSearchSource",
    "SkillRuntime",
    "SkillScope",
    "FetchedSkillBundle",
    "RawSkillBundle",
    "builtin_skill_definitions",
    "builtin_aegis_skill_source_root",
    "default_aegis_skill_source_root",
    "default_authored_aegis_skill_source_root",
    "default_installed_aegis_skill_source_root",
    "default_skill_search_sources",
    "default_skill_hub_sources",
    "load_skill_package_definition",
    "materialize_skill_package",
]
