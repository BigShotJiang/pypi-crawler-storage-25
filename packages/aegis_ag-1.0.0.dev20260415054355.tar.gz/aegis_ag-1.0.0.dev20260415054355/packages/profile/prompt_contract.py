"""Prompt contract assembly for Aegis identity, clone state, and friend context."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from .governance import (
    aegis_text,
    build_companion_identity_state,
    clone_text,
    friend_profile_fields,
    friend_text,
    missing_friend_good_to_have_questions,
    missing_friend_required_questions,
)
from .loader import LoadedProfile

PromptMode = Literal["full", "minimal"]


@dataclass(frozen=True, slots=True)
class PromptContract:
    prompt_mode: PromptMode
    section_names: tuple[str, ...]
    instruction_refs: tuple[str, ...]


def build_identity_kernel(profile: LoadedProfile) -> tuple[str, ...]:
    identity = build_companion_identity_state(profile)
    return (
        "section:identity-kernel",
        "identity-product=Aegis",
        f"identity-display-name={identity.display_name}",
        "identity-source=aegis-charter, clone-charter, friend-profile, continuity-governance",
        (
            f"Answer as {identity.display_name}, a named Aegis clone. Let the immutable AEGIS charter "
            "define the core contract, let CLONE.md define this clone's voice, and let FRIEND.md "
            "define durable context about the user."
        ),
    )


def build_aegis_section(profile: LoadedProfile) -> tuple[str, ...]:
    path = profile.aegis_path or "<packaged>"
    return (
        "section:aegis",
        f"aegis-path={path}",
        f"aegis-charter={aegis_text(profile)}",
    )


def build_clone_section(
    profile: LoadedProfile,
    *,
    prompt_mode: PromptMode = "full",
) -> tuple[str, ...]:
    identity = build_companion_identity_state(profile)
    lines = [
        "section:clone",
        f"clone-path={profile.state.clone_path or '<none>'}",
        f"clone-charter={clone_text(profile)}",
        f"clone-preset={identity.personality_preset}",
        f"clone-label={identity.personality_label}",
        f"clone-traits={', '.join(identity.personality_traits) or 'grounded, durable'}",
    ]
    if prompt_mode == "full":
        lines.extend(
            (
                f"clone-summary={identity.personality_summary}",
                f"clone-initiative={identity.initiative}",
                f"clone-relational-stance={identity.relational_stance}",
            )
        )
    return tuple(lines)


def build_friend_section(
    profile: LoadedProfile,
    *,
    prompt_mode: PromptMode = "full",
) -> tuple[str, ...]:
    identity = build_companion_identity_state(profile)
    current_friend_text = friend_text(profile)
    known_fields = friend_profile_fields(profile)
    missing_required = tuple(question.field_id for question in missing_friend_required_questions(profile))
    missing_good_to_have = tuple(question.field_id for question in missing_friend_good_to_have_questions(profile))
    if missing_required:
        profile_status = "needs-required-fields"
    elif missing_good_to_have:
        profile_status = "needs-enrichment"
    else:
        profile_status = "ready"
    lines = [
        "section:friend",
        f"friend-path={profile.friend_path or '<none>'}",
        f"friend-profile-status={profile_status}",
        f"friend-filled-fields={', '.join(known_fields.keys()) or 'none'}",
        f"friend-missing-required={', '.join(missing_required) or 'none'}",
        f"friend-missing-good-to-have={', '.join(missing_good_to_have) or 'none'}",
        f"friend-profile={current_friend_text or 'FRIEND.md has no stable user fields yet.'}",
    ]
    if prompt_mode == "full":
        lines.extend(
            (
                f"active-display-name={identity.display_name}",
                f"mode={identity.mode}",
                f"continuity-notes={', '.join(identity.continuity_notes) or 'none'}",
                (
                    "friend-canonical-fields="
                    "Preferred name, Current work, School, Current city, MBTI, Dream, "
                    "Creative hobby, Media hobby, Movement hobby, Boundaries"
                ),
            )
        )
    return tuple(lines)


def build_personality_section(
    profile: LoadedProfile,
    *,
    prompt_mode: PromptMode = "full",
) -> tuple[str, ...]:
    return build_clone_section(profile, prompt_mode=prompt_mode)


def build_user_snapshot_section(
    profile: LoadedProfile,
    *,
    prompt_mode: PromptMode = "full",
) -> tuple[str, ...]:
    return build_friend_section(profile, prompt_mode=prompt_mode)


def build_runtime_contract_section(
    profile: LoadedProfile,
    *,
    prompt_mode: PromptMode = "full",
) -> tuple[str, ...]:
    identity = build_companion_identity_state(profile)
    missing_required = missing_friend_required_questions(profile)
    missing_good_to_have = missing_friend_good_to_have_questions(profile)
    friend_ready = not missing_required
    lines = [
        "section:runtime-contract",
        f"prompt-mode={prompt_mode}",
        "Protect continuity, disclose uncertainty, and stay legible.",
        "Keep one coherent long-lived identity across wake, recovery, chat, and voice surfaces.",
        "Treat AEGIS.md as immutable core identity; never try to rewrite it.",
        "Canonical personal-AI writes use tool.identity.manage, tool.user.manage, and tool.relationship.manage instead of file-patching semantics.",
        "Keep shared user state limited to stable user facts; do not store transient tasks, one-off asks, or generic session chatter there.",
        (
            "When you update shared user truth, prefer action=set and either pass text in concise labeled lines or pass a generic fields object keyed by canonical labels or field ids "
            "using Preferred name, Current work, School, Current city, MBTI, Dream, Creative hobby, Media hobby, Movement hobby, and Boundaries."
        ),
        "When the friend shares concrete durable identity, preferences, boundaries, or recurring work context, proactively update shared user truth through tool.user.manage; do not wait for an explicit 'remember this' instruction.",
        "If the friend asks what you already know, answer from current identity, user, and relationship state first; only write when the turn adds or corrects durable facts.",
        "Keep shared user truth compact; once you know enough to hold the relationship coherently, stop running a formal onboarding flow and let normal memory, continuity, and later turns carry the rest.",
        "If the runtime context has no durable goals yet, naturally help the friend name one foundational ongoing goal for this clone once the opening grounding is sufficient.",
        "When the friend names that foundational thread, settle it durably with tool.goal.manage instead of leaving it as chat-only context.",
        "When the friend explicitly redefines this clone's voice or stance, update clone self-state through tool.identity.manage so the change persists.",
        "When clone-local collaboration rhythm, expectations, or continuity notes change, persist that relationship delta through tool.relationship.manage.",
        "When the friend explicitly asks you to change your presence or initiative, persist that durable posture change through tool.identity.manage with personality_preset and/or initiative.",
    ]
    if prompt_mode == "full":
        if not friend_ready:
            friend_onboarding = (
                "friend-onboarding=Stable user grounding is still thin: "
                + ", ".join(question.field_id for question in missing_required)
                + ". At the start of a relationship, ask naturally for the few durable basics you still need. "
                "Do not use a fixed questionnaire, headings, buckets, or a long all-at-once interview. "
                "Prefer one or two concise, human questions at a time, adapt to what the friend already volunteered, "
                "and write FRIEND.md once the stable facts are clear."
            )
        elif missing_good_to_have:
            friend_onboarding = (
                "friend-onboarding=Required FRIEND.md fields are set. "
                + "Do not reopen a structured onboarding flow. You may ask for more durable profile context only when it naturally helps continuity or the current conversation: "
                + ", ".join(question.field_id for question in missing_good_to_have)
                + "."
            )
        else:
            friend_onboarding = (
                "friend-onboarding=FRIEND.md has enough stable grounding. "
                "Do not reopen onboarding unless durable facts actually changed."
            )
        lines.extend(
            (
                f"governance={identity.governance_summary}",
                f"voice-identity={identity.voice_identity_summary}",
                friend_onboarding,
            )
        )
    return tuple(lines)


def build_prompt_contract(
    profile: LoadedProfile,
    *,
    prompt_mode: PromptMode = "full",
) -> PromptContract:
    sections: list[tuple[str, tuple[str, ...]]] = [
        ("identity-kernel", build_identity_kernel(profile)),
        ("aegis", build_aegis_section(profile)),
        ("clone", build_clone_section(profile, prompt_mode=prompt_mode)),
        ("friend", build_friend_section(profile, prompt_mode=prompt_mode)),
        ("runtime-contract", build_runtime_contract_section(profile, prompt_mode=prompt_mode)),
    ]
    instruction_refs = tuple(line for _, lines in sections for line in lines)
    return PromptContract(
        prompt_mode=prompt_mode,
        section_names=tuple(name for name, _ in sections),
        instruction_refs=instruction_refs,
    )
