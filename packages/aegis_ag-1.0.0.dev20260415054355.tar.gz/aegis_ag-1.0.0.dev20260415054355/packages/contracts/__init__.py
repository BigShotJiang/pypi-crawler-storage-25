"""Shared runtime contracts for Aegis.

This package is intentionally dependency-light and side-effect-free. It defines
the stable data shapes that the kernel, modules, and surfaces can share while
developing in parallel.
"""

from .inventory import CONTRACT_SURFACES
from .runtime import (
    AgentRunState,
    AgentRunStep,
    ArtifactRecord,
    CloneIdentityRecord,
    ContextBundle,
    EvidenceGraph,
    EventEnvelope,
    ExperienceRecord,
    ExecutionResult,
    GoalNode,
    MemoryRecord,
    PlanDraft,
    PlanStep,
    ProcedureLibrary,
    ProcedureRecord,
    ProcedureStep,
    ProfileGraph,
    ProfileGrowthState,
    ProfileState,
    RelationshipMemoryRecord,
    SessionContinuityState,
    SessionState,
    UserCardRecord,
    WorkGraph,
)

__all__ = [
    "ArtifactRecord",
    "AgentRunState",
    "AgentRunStep",
    "CloneIdentityRecord",
    "CONTRACT_SURFACES",
    "ContextBundle",
    "EvidenceGraph",
    "EventEnvelope",
    "ExperienceRecord",
    "ExecutionResult",
    "GoalNode",
    "MemoryRecord",
    "PlanDraft",
    "PlanStep",
    "ProcedureLibrary",
    "ProcedureRecord",
    "ProcedureStep",
    "ProfileGraph",
    "ProfileGrowthState",
    "ProfileState",
    "RelationshipMemoryRecord",
    "SessionContinuityState",
    "SessionState",
    "UserCardRecord",
    "WorkGraph",
]
