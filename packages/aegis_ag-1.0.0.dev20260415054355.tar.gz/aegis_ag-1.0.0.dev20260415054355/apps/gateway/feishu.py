"""Feishu transport bootstrap for the gateway surface."""

from __future__ import annotations

from collections.abc import Callable, Mapping
from dataclasses import dataclass, field, replace
import importlib.util
import json
import logging
import os
import queue
import threading
import time
from pathlib import Path
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen
from uuid import uuid4

from packages.gateway_core import (
    DEFAULT_GATEWAY_ACCOUNT_ID,
    GatewayExchange,
    GatewayInboundMessage,
    GatewayOutboundMessage,
)

from apps.provider_runtime import EnvironmentSecretStore, secret_reference_from_payload
from apps.runtime_layout import default_cli_state_dir, default_profile_dir
from packages.auth import AuthProfile, ProfileCredentialResolver, SecretReference

from .cli_control import (
    CliRuntimeFactory,
    FeishuCliBindingStore,
    FeishuCliControlService,
    load_feishu_cli_control_config,
)
from .plugins import GatewayManagedRuntime, GatewayPluginRegistry, default_gateway_runtime_path
from .runtime import FEISHU_ADAPTER_ID, FeishuMessagingAdapter, GatewayApp, build_gateway_app

DEFAULT_FEISHU_APP_ID_ENV = "AEGIS_FEISHU_APP_ID"
DEFAULT_FEISHU_APP_SECRET_ENV = "AEGIS_FEISHU_APP_SECRET"
LEGACY_FEISHU_APP_ID_ENV = "FEISHU_APP_ID"
LEGACY_FEISHU_APP_SECRET_ENV = "FEISHU_APP_SECRET"
DEFAULT_FEISHU_BASE_URL = "https://open.feishu.cn"
DEFAULT_FEISHU_EVENT_PATH = "/feishu/events"
DEFAULT_FEISHU_TOKEN_PATH = "/open-apis/auth/v3/tenant_access_token/internal"
SUPPORTED_FEISHU_TRANSPORTS = ("long-connection",)
FEISHU_SDK_PIP_SPEC = "lark-oapi>=1.5.3,<2"
DEFAULT_FEISHU_INBOUND_EVENT_RETENTION_SECONDS = 60 * 60 * 24 * 3
DEFAULT_FEISHU_INBOUND_EVENT_MAX_RECORDS = 4096
DEFAULT_FEISHU_ASYNC_JOB_RETENTION_SECONDS = DEFAULT_FEISHU_INBOUND_EVENT_RETENTION_SECONDS
DEFAULT_FEISHU_ASYNC_JOB_MAX_RECORDS = DEFAULT_FEISHU_INBOUND_EVENT_MAX_RECORDS
DEFAULT_FEISHU_ASYNC_WORKER_COUNT = 2
DEFAULT_FEISHU_ASYNC_FAILURE_HISTORY = 5
DEFAULT_FEISHU_PLACEHOLDER_BODY = "已收到，正在处理中..."
DEFAULT_FEISHU_FAILURE_BODY = "处理失败，请稍后重试。"

HttpJsonRequester = Callable[[str, str, Mapping[str, object], Mapping[str, str]], Mapping[str, object]]
FeishuWSClientFactory = Callable[[Any, str, str, object, object | None], object]

LOGGER = logging.getLogger(__name__)


def _mapping(value: object) -> Mapping[str, object] | None:
    return value if isinstance(value, Mapping) else None


def _optional_text(value: object) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def _normalize_path(value: str | None) -> str:
    text = str(value or DEFAULT_FEISHU_EVENT_PATH).strip() or DEFAULT_FEISHU_EVENT_PATH
    return text if text.startswith("/") else f"/{text}"


def _normalize_transport(value: str | None) -> str:
    normalized = str(value or "webhook").strip().lower().replace("_", "-")
    if normalized in {"long-connection", "longconnection", "websocket", "ws"}:
        return "long-connection"
    if normalized in {"event-subscription", "callback", "http", "webhook"}:
        return "webhook"
    raise ValueError("feishu transport must be one of long-connection, webhook")


def _normalize_configured_transport(value: str | None) -> str:
    normalized = str(value or "long-connection").strip().lower().replace("_", "-")
    if normalized in {"long-connection", "longconnection", "websocket", "ws"}:
        return "long-connection"
    if normalized in {"event-subscription", "callback", "http", "webhook"}:
        return "long-connection"
    raise ValueError("feishu configured transport must resolve to long-connection")


def _json_bytes(payload: Mapping[str, object]) -> bytes:
    return json.dumps(dict(payload), ensure_ascii=False).encode("utf-8")


def _default_json_request(
    method: str,
    url: str,
    payload: Mapping[str, object],
    headers: Mapping[str, str],
) -> Mapping[str, object]:
    request = Request(
        url,
        data=_json_bytes(payload),
        method=method.upper(),
        headers={
            "Content-Type": "application/json; charset=utf-8",
            "Accept": "application/json",
            "User-Agent": "aegis-gateway/feishu",
            **dict(headers),
        },
    )
    try:
        with urlopen(request, timeout=30) as response:
            raw = response.read().decode("utf-8")
    except HTTPError as exc:
        detail = exc.read().decode("utf-8")
        raise RuntimeError(
            f"feishu request failed with HTTP {exc.code}: {detail or exc.reason}"
        ) from exc
    except URLError as exc:
        raise RuntimeError(f"feishu request failed: {exc.reason}") from exc
    try:
        parsed = json.loads(raw or "{}")
    except json.JSONDecodeError as exc:
        raise RuntimeError("feishu request returned a non-JSON response") from exc
    if not isinstance(parsed, dict):
        raise RuntimeError("feishu request returned a non-object JSON response")
    if int(parsed.get("code", 0) or 0) != 0:
        raise RuntimeError(
            f"feishu request rejected: code={parsed.get('code')} msg={parsed.get('msg')}"
        )
    return parsed


def _lark_sdk_dependency_status() -> str:
    return "installed" if importlib.util.find_spec("lark_oapi") is not None else "missing_optional_dependency"


def _load_lark_sdk(lark_module: Any | None = None) -> Any:
    if lark_module is not None:
        return lark_module
    try:
        import lark_oapi as lark  # type: ignore[import-not-found]
    except ImportError as exc:  # pragma: no cover - exercised by integration path
        raise RuntimeError(
            "Feishu long-connection transport requires the bundled dependency "
            "'lark-oapi'. Reinstall Aegis or add the package to your environment if it is missing."
        ) from exc
    return lark


def _lark_log_level(lark_module: Any, level_name: str) -> object | None:
    log_levels = getattr(lark_module, "LogLevel", None)
    if log_levels is None:
        return None
    normalized = str(level_name or "INFO").strip().upper().replace("-", "_")
    return getattr(log_levels, normalized, None)


def _lark_event_payload(event: object, *, lark_module: Any) -> Mapping[str, object]:
    marshaled = getattr(getattr(lark_module, "JSON", None), "marshal", None)
    if not callable(marshaled):
        raise RuntimeError("lark_oapi.JSON.marshal is unavailable")
    raw = marshaled(event)
    try:
        parsed = json.loads(str(raw or "{}"))
    except json.JSONDecodeError as exc:
        raise RuntimeError("lark_oapi long-connection event was not valid JSON") from exc
    if not isinstance(parsed, Mapping):
        raise RuntimeError("lark_oapi long-connection event did not marshal to a JSON object")
    return parsed


def _default_ws_client_factory(
    lark_module: Any,
    app_id: str,
    app_secret: str,
    event_handler: object,
    log_level: object | None,
) -> object:
    ws_client = getattr(getattr(lark_module, "ws", None), "Client", None)
    if ws_client is None:
        raise RuntimeError("lark_oapi long-connection client is unavailable")
    return ws_client(
        app_id,
        app_secret,
        event_handler=event_handler,
        log_level=log_level,
    )


@dataclass(frozen=True, slots=True)
class FeishuGatewayAccountConfig:
    account_id: str = DEFAULT_GATEWAY_ACCOUNT_ID
    app_id_env_var: str = DEFAULT_FEISHU_APP_ID_ENV
    app_secret_env_var: str = DEFAULT_FEISHU_APP_SECRET_ENV
    secret_references: tuple[SecretReference, ...] = ()
    surface: str = "webhook"
    event_path: str = DEFAULT_FEISHU_EVENT_PATH
    base_url: str = DEFAULT_FEISHU_BASE_URL
    token_path: str = DEFAULT_FEISHU_TOKEN_PATH
    metadata: Mapping[str, object] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class FeishuResolvedAccount:
    account_id: str
    app_id: str
    app_secret: str
    config: FeishuGatewayAccountConfig


@dataclass(frozen=True, slots=True)
class FeishuGatewayEventResult:
    exchange: GatewayExchange | None
    response_body: Mapping[str, object]
    delivery_request: Mapping[str, object] | None = None
    delivery_response: Mapping[str, object] | None = None


@dataclass(slots=True)
class _FeishuTokenCacheEntry:
    token: str
    expires_at: float


@dataclass(frozen=True, slots=True)
class FeishuInboundEventRecord:
    account_id: str
    event_id: str | None
    message_id: str | None
    response_body: Mapping[str, object]
    recorded_at: float


@dataclass(slots=True)
class FeishuInboundEventStore:
    path: Path | None = None
    retention_seconds: int = DEFAULT_FEISHU_INBOUND_EVENT_RETENTION_SECONDS
    max_records: int = DEFAULT_FEISHU_INBOUND_EVENT_MAX_RECORDS
    _records: dict[str, FeishuInboundEventRecord] = field(default_factory=dict, init=False, repr=False)
    _aliases: dict[str, str] = field(default_factory=dict, init=False, repr=False)
    _inflight: set[str] = field(default_factory=set, init=False, repr=False)
    _lock: threading.RLock = field(default_factory=threading.RLock, init=False, repr=False)

    def __post_init__(self) -> None:
        with self._lock:
            self._records = self._load()
            self._prune()

    def begin(
        self,
        *,
        account_id: str,
        event_id: str | None,
        message_id: str | None,
    ) -> tuple[str, FeishuInboundEventRecord | None]:
        with self._lock:
            aliases = self._alias_keys(
                account_id=account_id,
                event_id=event_id,
                message_id=message_id,
            )
            self._prune()
            for alias in aliases:
                canonical_key = self._aliases.get(alias)
                if canonical_key is None:
                    continue
                record = self._records.get(canonical_key)
                if record is not None:
                    return "duplicate", record
            if any(alias in self._inflight for alias in aliases):
                return "inflight", None
            self._inflight.update(aliases)
            return "fresh", None

    def commit(
        self,
        *,
        account_id: str,
        event_id: str | None,
        message_id: str | None,
        response_body: Mapping[str, object],
    ) -> FeishuInboundEventRecord:
        with self._lock:
            aliases = self._alias_keys(
                account_id=account_id,
                event_id=event_id,
                message_id=message_id,
            )
            recorded_at = time.time()
            canonical_key = aliases[0] if aliases else f"{account_id}:unknown:{recorded_at:.6f}"
            record = FeishuInboundEventRecord(
                account_id=account_id,
                event_id=event_id,
                message_id=message_id,
                response_body=dict(response_body),
                recorded_at=recorded_at,
            )
            self._records[canonical_key] = record
            for alias in aliases:
                self._inflight.discard(alias)
            self._prune()
            self._persist()
            return record

    def abort(
        self,
        *,
        account_id: str,
        event_id: str | None,
        message_id: str | None,
    ) -> None:
        with self._lock:
            for alias in self._alias_keys(
                account_id=account_id,
                event_id=event_id,
                message_id=message_id,
            ):
                self._inflight.discard(alias)

    def _alias_keys(
        self,
        *,
        account_id: str,
        event_id: str | None,
        message_id: str | None,
    ) -> tuple[str, ...]:
        aliases: list[str] = []
        if message_id:
            aliases.append(f"{account_id}:message:{message_id}")
        if event_id:
            aliases.append(f"{account_id}:event:{event_id}")
        return tuple(dict.fromkeys(aliases))

    def _load(self) -> dict[str, FeishuInboundEventRecord]:
        if self.path is None or not self.path.exists():
            return {}
        payload = json.loads(self.path.read_text(encoding="utf-8"))
        items = payload.get("records")
        if not isinstance(items, list):
            return {}
        loaded: dict[str, FeishuInboundEventRecord] = {}
        for item in items:
            if not isinstance(item, dict):
                continue
            response_body = _mapping(item.get("response_body"))
            if response_body is None:
                continue
            account_id = _optional_text(item.get("account_id"))
            event_id = _optional_text(item.get("event_id"))
            message_id = _optional_text(item.get("message_id"))
            if account_id is None:
                continue
            aliases = self._alias_keys(
                account_id=account_id,
                event_id=event_id,
                message_id=message_id,
            )
            if not aliases:
                continue
            recorded_at = float(item.get("recorded_at") or 0.0)
            record = FeishuInboundEventRecord(
                account_id=account_id,
                event_id=event_id,
                message_id=message_id,
                response_body=dict(response_body),
                recorded_at=recorded_at,
            )
            loaded[aliases[0]] = record
        return loaded

    def _prune(self) -> None:
        cutoff = time.time() - max(self.retention_seconds, 0)
        kept = [
            (key, record)
            for key, record in self._records.items()
            if record.recorded_at >= cutoff
        ]
        kept.sort(key=lambda item: item[1].recorded_at, reverse=True)
        if self.max_records > 0:
            kept = kept[: self.max_records]
        self._records = dict(kept)
        aliases: dict[str, str] = {}
        for canonical_key, record in self._records.items():
            for alias in self._alias_keys(
                account_id=record.account_id,
                event_id=record.event_id,
                message_id=record.message_id,
            ):
                aliases[alias] = canonical_key
        self._aliases = aliases

    def _persist(self) -> None:
        if self.path is None:
            return
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "records": [
                {
                    "account_id": record.account_id,
                    "event_id": record.event_id,
                    "message_id": record.message_id,
                    "response_body": dict(record.response_body),
                    "recorded_at": record.recorded_at,
                }
                for _, record in sorted(
                    self._records.items(),
                    key=lambda item: item[1].recorded_at,
                    reverse=True,
                )
            ]
        }
        self.path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")


@dataclass(frozen=True, slots=True)
class FeishuAsyncJobRecord:
    account_id: str
    conversation_id: str
    event_id: str | None
    message_id: str | None
    transport: str
    payload: Mapping[str, object]
    status: str
    placeholder_sent: bool
    placeholder_message_id: str | None
    response_body: Mapping[str, object] | None
    external_message_id: str | None
    failure_summary: str | None
    retry_count: int
    created_at: float
    updated_at: float
    started_at: float | None = None
    completed_at: float | None = None
    failed_at: float | None = None


@dataclass(slots=True)
class FeishuAsyncJobStore:
    path: Path | None = None
    retention_seconds: int = DEFAULT_FEISHU_ASYNC_JOB_RETENTION_SECONDS
    max_records: int = DEFAULT_FEISHU_ASYNC_JOB_MAX_RECORDS
    _records: dict[str, FeishuAsyncJobRecord] = field(default_factory=dict, init=False, repr=False)
    _aliases: dict[str, str] = field(default_factory=dict, init=False, repr=False)
    _lock: threading.RLock = field(default_factory=threading.RLock, init=False, repr=False)

    def __post_init__(self) -> None:
        with self._lock:
            self._records = self._load()
            self._prune()

    def create_or_get(
        self,
        *,
        account_id: str,
        conversation_id: str,
        event_id: str | None,
        message_id: str | None,
        payload: Mapping[str, object],
        transport: str,
    ) -> tuple[str, FeishuAsyncJobRecord, bool]:
        with self._lock:
            aliases = self._alias_keys(
                account_id=account_id,
                event_id=event_id,
                message_id=message_id,
            )
            self._prune()
            for alias in aliases:
                canonical_key = self._aliases.get(alias)
                if canonical_key is None:
                    continue
                record = self._records.get(canonical_key)
                if record is not None:
                    return canonical_key, record, False
            now = time.time()
            canonical_key = aliases[0] if aliases else f"{account_id}:job:{uuid4().hex}"
            record = FeishuAsyncJobRecord(
                account_id=account_id,
                conversation_id=conversation_id,
                event_id=event_id,
                message_id=message_id,
                transport=transport,
                payload=dict(payload),
                status="queued",
                placeholder_sent=False,
                placeholder_message_id=None,
                response_body=None,
                external_message_id=None,
                failure_summary=None,
                retry_count=0,
                created_at=now,
                updated_at=now,
            )
            self._records[canonical_key] = record
            self._prune()
            self._persist()
            return canonical_key, record, True

    def get(self, key: str) -> FeishuAsyncJobRecord | None:
        with self._lock:
            self._prune()
            return self._records.get(key)

    def mark_running(self, key: str) -> FeishuAsyncJobRecord | None:
        with self._lock:
            record = self._records.get(key)
            if record is None:
                return None
            now = time.time()
            updated = replace(
                record,
                status="running",
                retry_count=record.retry_count + 1,
                started_at=now,
                updated_at=now,
                failed_at=None,
                failure_summary=None,
            )
            self._records[key] = updated
            self._prune()
            self._persist()
            return updated

    def mark_placeholder_sent(
        self,
        key: str,
        *,
        placeholder_message_id: str | None,
    ) -> FeishuAsyncJobRecord | None:
        with self._lock:
            record = self._records.get(key)
            if record is None:
                return None
            now = time.time()
            updated = replace(
                record,
                placeholder_sent=True,
                placeholder_message_id=placeholder_message_id,
                updated_at=now,
            )
            self._records[key] = updated
            self._prune()
            self._persist()
            return updated

    def complete(
        self,
        key: str,
        *,
        response_body: Mapping[str, object],
        external_message_id: str | None,
    ) -> FeishuAsyncJobRecord | None:
        with self._lock:
            record = self._records.get(key)
            if record is None:
                return None
            now = time.time()
            updated = replace(
                record,
                status="completed",
                response_body=dict(response_body),
                external_message_id=external_message_id,
                updated_at=now,
                completed_at=now,
                failed_at=None,
                failure_summary=None,
            )
            self._records[key] = updated
            self._prune()
            self._persist()
            return updated

    def fail(
        self,
        key: str,
        *,
        failure_summary: str,
        response_body: Mapping[str, object] | None = None,
    ) -> FeishuAsyncJobRecord | None:
        with self._lock:
            record = self._records.get(key)
            if record is None:
                return None
            now = time.time()
            updated = replace(
                record,
                status="failed",
                response_body=None if response_body is None else dict(response_body),
                failure_summary=failure_summary,
                external_message_id=None,
                updated_at=now,
                failed_at=now,
            )
            self._records[key] = updated
            self._prune()
            self._persist()
            return updated

    def incomplete_records(self) -> tuple[tuple[str, FeishuAsyncJobRecord], ...]:
        with self._lock:
            self._prune()
            items = [
                (key, record)
                for key, record in self._records.items()
                if record.status in {"queued", "running"}
            ]
        items.sort(key=lambda item: (item[1].created_at, item[0]))
        return tuple(items)

    def summary(self, *, failure_limit: int = DEFAULT_FEISHU_ASYNC_FAILURE_HISTORY) -> Mapping[str, object]:
        with self._lock:
            self._prune()
            queue_depth = 0
            running_jobs = 0
            failures: list[dict[str, object]] = []
            for record in self._records.values():
                if record.status == "queued":
                    queue_depth += 1
                elif record.status == "running":
                    running_jobs += 1
                elif record.status == "failed":
                    failures.append(
                        {
                            "account_id": record.account_id,
                            "conversation_id": record.conversation_id,
                            "event_id": record.event_id,
                            "message_id": record.message_id,
                            "failure_summary": record.failure_summary,
                            "failed_at": record.failed_at,
                        }
                    )
        failures.sort(key=lambda item: float(item.get("failed_at") or 0.0), reverse=True)
        return {
            "queue_depth": queue_depth,
            "running_jobs": running_jobs,
            "recent_failures": tuple(failures[: max(failure_limit, 0)]),
        }

    def _alias_keys(
        self,
        *,
        account_id: str,
        event_id: str | None,
        message_id: str | None,
    ) -> tuple[str, ...]:
        aliases: list[str] = []
        if message_id:
            aliases.append(f"{account_id}:message:{message_id}")
        if event_id:
            aliases.append(f"{account_id}:event:{event_id}")
        return tuple(dict.fromkeys(aliases))

    def _load(self) -> dict[str, FeishuAsyncJobRecord]:
        if self.path is None or not self.path.exists():
            return {}
        payload = json.loads(self.path.read_text(encoding="utf-8"))
        items = payload.get("records")
        if not isinstance(items, list):
            return {}
        loaded: dict[str, FeishuAsyncJobRecord] = {}
        for item in items:
            if not isinstance(item, dict):
                continue
            payload_mapping = _mapping(item.get("payload"))
            account_id = _optional_text(item.get("account_id"))
            conversation_id = _optional_text(item.get("conversation_id"))
            transport = _optional_text(item.get("transport"))
            if (
                payload_mapping is None
                or account_id is None
                or conversation_id is None
                or transport is None
            ):
                continue
            event_id = _optional_text(item.get("event_id"))
            message_id = _optional_text(item.get("message_id"))
            aliases = self._alias_keys(
                account_id=account_id,
                event_id=event_id,
                message_id=message_id,
            )
            canonical_key = aliases[0] if aliases else _optional_text(item.get("canonical_key"))
            if canonical_key is None:
                continue
            response_body = _mapping(item.get("response_body"))
            loaded[canonical_key] = FeishuAsyncJobRecord(
                account_id=account_id,
                conversation_id=conversation_id,
                event_id=event_id,
                message_id=message_id,
                transport=transport,
                payload=dict(payload_mapping),
                status=str(item.get("status") or "queued"),
                placeholder_sent=bool(item.get("placeholder_sent", False)),
                placeholder_message_id=_optional_text(item.get("placeholder_message_id")),
                response_body=None if response_body is None else dict(response_body),
                external_message_id=_optional_text(item.get("external_message_id")),
                failure_summary=_optional_text(item.get("failure_summary")),
                retry_count=int(item.get("retry_count") or 0),
                created_at=float(item.get("created_at") or 0.0),
                updated_at=float(item.get("updated_at") or 0.0),
                started_at=(
                    None if item.get("started_at") is None else float(item.get("started_at"))
                ),
                completed_at=(
                    None
                    if item.get("completed_at") is None
                    else float(item.get("completed_at"))
                ),
                failed_at=(
                    None if item.get("failed_at") is None else float(item.get("failed_at"))
                ),
            )
        return loaded

    def _prune(self) -> None:
        cutoff = time.time() - max(self.retention_seconds, 0)
        kept = [
            (key, record)
            for key, record in self._records.items()
            if record.updated_at >= cutoff
        ]
        kept.sort(key=lambda item: item[1].updated_at, reverse=True)
        if self.max_records > 0:
            kept = kept[: self.max_records]
        self._records = dict(kept)
        aliases: dict[str, str] = {}
        for canonical_key, record in self._records.items():
            for alias in self._alias_keys(
                account_id=record.account_id,
                event_id=record.event_id,
                message_id=record.message_id,
            ):
                aliases[alias] = canonical_key
        self._aliases = aliases

    def _persist(self) -> None:
        if self.path is None:
            return
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "records": [
                {
                    "canonical_key": canonical_key,
                    "account_id": record.account_id,
                    "conversation_id": record.conversation_id,
                    "event_id": record.event_id,
                    "message_id": record.message_id,
                    "transport": record.transport,
                    "payload": dict(record.payload),
                    "status": record.status,
                    "placeholder_sent": record.placeholder_sent,
                    "placeholder_message_id": record.placeholder_message_id,
                    "response_body": (
                        None if record.response_body is None else dict(record.response_body)
                    ),
                    "external_message_id": record.external_message_id,
                    "failure_summary": record.failure_summary,
                    "retry_count": record.retry_count,
                    "created_at": record.created_at,
                    "updated_at": record.updated_at,
                    "started_at": record.started_at,
                    "completed_at": record.completed_at,
                    "failed_at": record.failed_at,
                }
                for canonical_key, record in sorted(
                    self._records.items(),
                    key=lambda item: item[1].updated_at,
                    reverse=True,
                )
            ]
        }
        self.path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")


def _feishu_event_identifiers(payload: Mapping[str, object]) -> tuple[str | None, str | None]:
    header = _mapping(payload.get("header")) or {}
    event = _mapping(payload.get("event")) or {}
    message = _mapping(event.get("message")) or {}
    return (
        _optional_text(header.get("event_id")),
        _optional_text(message.get("message_id")),
    )


def _feishu_secret_reference_from_payload(
    payload: Mapping[str, object],
    *,
    account_id: str,
) -> SecretReference:
    normalized_payload = dict(payload)
    secret_key = str(normalized_payload.get("secret_key") or "")
    if not secret_key:
        raise ValueError(
            f"feishu account '{account_id}' secret_references entries must declare secret_key"
        )
    normalized_payload.setdefault("provider_id", FEISHU_ADAPTER_ID)
    normalized_payload.setdefault("secret_name", secret_key)
    reference = secret_reference_from_payload(normalized_payload)
    if reference.provider_id != FEISHU_ADAPTER_ID:
        raise ValueError(
            f"feishu account '{account_id}' secret reference provider_id must be {FEISHU_ADAPTER_ID}"
        )
    return reference


def _secret_reference_env_alias(
    references: tuple[SecretReference, ...],
    secret_key: str,
) -> str | None:
    for reference in references:
        if reference.secret_key != secret_key:
            continue
        candidates = reference.env_var_candidates()
        if candidates:
            return candidates[0]
    return None


def _credential_env_vars(config: FeishuGatewayAccountConfig) -> tuple[str, ...]:
    if config.secret_references:
        return tuple(
            dict.fromkeys(
                env_var
                for reference in config.secret_references
                for env_var in reference.env_var_candidates()
            )
        )
    env_vars = [config.app_id_env_var, config.app_secret_env_var]
    return tuple(dict.fromkeys(value for value in env_vars if value))


def _feishu_account_profile(config: FeishuGatewayAccountConfig) -> AuthProfile:
    return AuthProfile(
        profile_id=f"gateway.feishu.{config.account_id}",
        provider_id=FEISHU_ADAPTER_ID,
        transport_id="gateway-feishu",
        auth_method="secret_reference",
        provider_kind="service",
        secret_references=config.secret_references,
        metadata={
            "surface": "gateway.feishu",
            "account_id": config.account_id,
        },
    )


def load_feishu_gateway_accounts(
    app: GatewayApp,
    *,
    respect_enabled: bool = True,
) -> tuple[FeishuGatewayAccountConfig, ...]:
    manifest = app.loaded_profile.manifest if app.loaded_profile is not None else {}
    gateway_payload = _mapping(manifest.get("gateway")) or {}
    adapters_payload = _mapping(gateway_payload.get("adapters")) or {}
    feishu_payload = _mapping(adapters_payload.get("feishu"))
    if respect_enabled and feishu_payload is not None and feishu_payload.get("enabled") is False:
        return ()

    default_surface = _normalize_configured_transport((feishu_payload or {}).get("surface"))
    default_event_path = _normalize_path((feishu_payload or {}).get("event_path"))
    default_base_url = str((feishu_payload or {}).get("base_url") or DEFAULT_FEISHU_BASE_URL)
    default_token_path = _normalize_path(
        (feishu_payload or {}).get("token_path") or DEFAULT_FEISHU_TOKEN_PATH
    )
    accounts_payload = (feishu_payload or {}).get("accounts")
    if isinstance(accounts_payload, list) and accounts_payload:
        resolved: list[FeishuGatewayAccountConfig] = []
        for index, account_payload in enumerate(accounts_payload):
            account_mapping = _mapping(account_payload)
            if account_mapping is None:
                raise ValueError("gateway.adapters.feishu.accounts entries must be JSON objects")
            account_id = str(account_mapping.get("account_id") or DEFAULT_GATEWAY_ACCOUNT_ID)
            env_payload = _mapping(account_mapping.get("env")) or {}
            secret_references_payload = account_mapping.get("secret_references")
            if secret_references_payload is None:
                secret_references = ()
            elif isinstance(secret_references_payload, list):
                secret_references = tuple(
                    _feishu_secret_reference_from_payload(item, account_id=account_id)
                    for item in secret_references_payload
                    if isinstance(item, Mapping)
                )
                if len(secret_references) != len(secret_references_payload):
                    raise ValueError(
                        f"feishu account '{account_id}' secret_references entries must be JSON objects"
                    )
            else:
                raise ValueError(
                    f"feishu account '{account_id}' secret_references must be a JSON array"
                )
            app_id_env_var = str(
                env_payload.get("app_id")
                or _secret_reference_env_alias(secret_references, "app_id")
                or ("" if secret_references else DEFAULT_FEISHU_APP_ID_ENV)
            )
            app_secret_env_var = str(
                env_payload.get("app_secret")
                or _secret_reference_env_alias(secret_references, "app_secret")
                or ("" if secret_references else DEFAULT_FEISHU_APP_SECRET_ENV)
            )
            resolved.append(
                FeishuGatewayAccountConfig(
                    account_id=account_id,
                    app_id_env_var=app_id_env_var,
                    app_secret_env_var=app_secret_env_var,
                    secret_references=secret_references,
                    surface=str(account_mapping.get("surface") or default_surface),
                    event_path=_normalize_path(account_mapping.get("event_path") or default_event_path),
                    base_url=str(account_mapping.get("base_url") or default_base_url),
                    token_path=_normalize_path(account_mapping.get("token_path") or default_token_path),
                    metadata={"manifest_index": index},
                )
            )
        return tuple(resolved)

    return (
        FeishuGatewayAccountConfig(
            event_path=default_event_path,
            surface=default_surface,
            base_url=default_base_url,
            token_path=default_token_path,
        ),
    )


def resolve_feishu_account(
    config: FeishuGatewayAccountConfig,
    *,
    environ: Mapping[str, str] | None = None,
) -> FeishuResolvedAccount:
    env = environ or os.environ
    if config.secret_references:
        credentials = ProfileCredentialResolver(EnvironmentSecretStore(env)).resolve(
            _feishu_account_profile(config)
        ).as_mapping()
        app_id = str(credentials.get("app_id") or "")
        app_secret = str(credentials.get("app_secret") or "")
        if not app_id or not app_secret:
            raise LookupError(
                f"feishu account '{config.account_id}' secret references must resolve app_id and app_secret"
            )
        return FeishuResolvedAccount(
            account_id=config.account_id,
            app_id=app_id,
            app_secret=app_secret,
            config=config,
        )

    app_id = str(env.get(config.app_id_env_var) or "")
    app_secret = str(env.get(config.app_secret_env_var) or "")
    if not app_id and config.app_id_env_var == DEFAULT_FEISHU_APP_ID_ENV:
        app_id = str(env.get(LEGACY_FEISHU_APP_ID_ENV) or "")
    if not app_secret and config.app_secret_env_var == DEFAULT_FEISHU_APP_SECRET_ENV:
        app_secret = str(env.get(LEGACY_FEISHU_APP_SECRET_ENV) or "")
    if not app_id or not app_secret:
        raise LookupError(
            f"feishu account '{config.account_id}' requires "
            f"{config.app_id_env_var} and {config.app_secret_env_var}"
        )
    return FeishuResolvedAccount(
        account_id=config.account_id,
        app_id=app_id,
        app_secret=app_secret,
        config=config,
    )


@dataclass(slots=True)
class FeishuGatewayService:
    app: GatewayApp
    account_configs: tuple[FeishuGatewayAccountConfig, ...] = ()
    http_requester: HttpJsonRequester = _default_json_request
    environ: Mapping[str, str] = field(default_factory=lambda: dict(os.environ))
    adapter: FeishuMessagingAdapter | None = None
    cli_runtime_factory: CliRuntimeFactory | None = None
    cli_binding_store: FeishuCliBindingStore | None = None
    cli_control: FeishuCliControlService | None = None
    inbound_event_store: FeishuInboundEventStore | None = None
    async_job_store: FeishuAsyncJobStore | None = None
    default_cli_profile_dir: str | None = None
    default_cli_state_dir: str | None = None
    runtime_dependency_ensurer: Callable[..., object] | None = None
    respect_enabled: bool = True
    service_key: str = "feishu"
    async_worker_count: int = DEFAULT_FEISHU_ASYNC_WORKER_COUNT
    async_placeholder_body: str = DEFAULT_FEISHU_PLACEHOLDER_BODY
    async_failure_body: str = DEFAULT_FEISHU_FAILURE_BODY
    _token_cache: dict[str, _FeishuTokenCacheEntry] = field(
        init=False,
        default_factory=dict,
        repr=False,
    )
    _async_queue: queue.Queue[str | None] = field(
        init=False,
        default_factory=queue.Queue,
        repr=False,
    )
    _async_workers_started: bool = field(default=False, init=False, repr=False)
    _async_workers: list[threading.Thread] = field(default_factory=list, init=False, repr=False)
    _async_stop_event: threading.Event = field(
        default_factory=threading.Event,
        init=False,
        repr=False,
    )
    _async_worker_lock: threading.Lock = field(
        default_factory=threading.Lock,
        init=False,
        repr=False,
    )
    _async_schedule_lock: threading.Lock = field(
        default_factory=threading.Lock,
        init=False,
        repr=False,
    )
    _scheduled_job_keys: set[str] = field(default_factory=set, init=False, repr=False)
    _conversation_locks: dict[str, threading.Lock] = field(
        default_factory=dict,
        init=False,
        repr=False,
    )
    _conversation_locks_guard: threading.Lock = field(
        default_factory=threading.Lock,
        init=False,
        repr=False,
    )

    def __post_init__(self) -> None:
        if not self.account_configs:
            self.account_configs = load_feishu_gateway_accounts(
                self.app,
                respect_enabled=self.respect_enabled,
            )
        if self.inbound_event_store is None:
            state_root = self.app.state_dir
            dedupe_path = (
                None
                if state_root is None
                else os.path.join(state_root, "feishu-inbound-events.json")
            )
            self.inbound_event_store = FeishuInboundEventStore(
                path=None if dedupe_path is None else Path(dedupe_path)
            )
        if self.async_job_store is None:
            state_root = self.app.state_dir
            async_jobs_path = (
                None if state_root is None else os.path.join(state_root, "feishu-async-jobs.json")
            )
            self.async_job_store = FeishuAsyncJobStore(
                path=None if async_jobs_path is None else Path(async_jobs_path)
            )
        if self.adapter is None:
            self.adapter = FeishuMessagingAdapter(app=self.app)
        if self.cli_control is None and self.app.loaded_profile is not None:
            config = load_feishu_cli_control_config(self.app.loaded_profile.manifest)
            if config is not None:
                binding_store = self.cli_binding_store
                if binding_store is None:
                    state_root = self.app.state_dir
                    binding_path = (
                        None
                        if state_root is None
                        else os.path.join(state_root, "feishu-cli-bindings.json")
                    )
                    binding_store = FeishuCliBindingStore(
                        path=None if binding_path is None else Path(binding_path)
                    )
                self.cli_control = FeishuCliControlService(
                    config=self._resolved_cli_control_config(config),
                    runtime_factory=self.cli_runtime_factory,
                    binding_store=binding_store,
                )

    def _resolved_cli_control_config(self, config):
        profile_dir = config.profile_dir or self.default_cli_profile_dir or self.app.profile_dir
        if profile_dir is None:
            profile_dir = str(default_profile_dir(environ=self.environ))
        state_dir = config.state_dir or self.default_cli_state_dir or self._inferred_cli_state_dir()
        if state_dir is None:
            state_dir = str(default_cli_state_dir(environ=self.environ))
        return type(config)(
            profile_dir=profile_dir,
            state_dir=state_dir,
            default_clone_id=config.default_clone_id,
            default_session_id=config.default_session_id,
            auto_create_clone=config.auto_create_clone,
            allow_group_chats=config.allow_group_chats,
        )

    def _inferred_cli_state_dir(self) -> str | None:
        if self.app.state_dir is None:
            return None
        state_dir = Path(self.app.state_dir)
        if state_dir.name == "gateway" and state_dir.parent != state_dir:
            return str(state_dir.parent)
        return str(state_dir)

    def _async_summary(self) -> Mapping[str, object]:
        if self.async_job_store is None:
            return {
                "queue_depth": 0,
                "running_jobs": 0,
                "recent_failures": (),
            }
        return self.async_job_store.summary()

    def _ensure_async_workers(self) -> None:
        with self._async_worker_lock:
            if self._async_workers_started:
                return
            worker_count = max(int(self.async_worker_count or 0), 1)
            self._async_stop_event.clear()
            self._async_workers = []
            for index in range(worker_count):
                worker = threading.Thread(
                    target=self._async_worker_loop,
                    name=f"feishu-async-worker-{index + 1}",
                    daemon=True,
                )
                worker.start()
                self._async_workers.append(worker)
            self._async_workers_started = True
            self._recover_async_jobs()

    def shutdown_async_processing(self, *, timeout: float = 1.0) -> None:
        with self._async_worker_lock:
            if not self._async_workers_started:
                return
            self._async_stop_event.set()
            for _ in self._async_workers:
                self._async_queue.put(None)
            for worker in self._async_workers:
                worker.join(timeout=timeout)
            self._async_workers = []
            self._async_workers_started = False
            with self._async_schedule_lock:
                self._scheduled_job_keys.clear()

    def _recover_async_jobs(self) -> None:
        assert self.async_job_store is not None
        for job_key, _ in self.async_job_store.incomplete_records():
            self._schedule_async_job(job_key)

    def _schedule_async_job(self, job_key: str) -> bool:
        with self._async_schedule_lock:
            if job_key in self._scheduled_job_keys:
                return False
            self._scheduled_job_keys.add(job_key)
        self._async_queue.put(job_key)
        return True

    def _conversation_lock(self, account_id: str, conversation_id: str) -> threading.Lock:
        key = f"{account_id}:{conversation_id}"
        with self._conversation_locks_guard:
            lock = self._conversation_locks.get(key)
            if lock is None:
                lock = threading.Lock()
                self._conversation_locks[key] = lock
            return lock

    def _async_worker_loop(self) -> None:
        while not self._async_stop_event.is_set():
            job_key = self._async_queue.get()
            if job_key is None:
                self._async_queue.task_done()
                break
            try:
                self._run_async_job(job_key)
            except Exception:
                LOGGER.exception("Feishu async worker crashed for job=%s", job_key)
            finally:
                with self._async_schedule_lock:
                    self._scheduled_job_keys.discard(job_key)
                self._async_queue.task_done()

    def _run_async_job(self, job_key: str) -> None:
        assert self.async_job_store is not None
        record = self.async_job_store.get(job_key)
        if record is None or record.status in {"completed", "failed"}:
            return
        try:
            account = self._match_account(record.payload, account_id=record.account_id)
            assert self.adapter is not None
            inbound = self.adapter.normalize_event(
                record.payload,
                account_id=record.account_id,
                transport=record.transport,
            )
        except Exception as exc:
            failure_summary = str(exc).strip() or exc.__class__.__name__
            LOGGER.exception(
                "Feishu async job could not be reconstructed for account=%s conversation=%s",
                record.account_id,
                record.conversation_id,
            )
            self.async_job_store.fail(
                job_key,
                failure_summary=failure_summary,
                response_body={
                    **self._base_response_body(transport=record.transport),
                    "account_id": record.account_id,
                    "conversation_id": record.conversation_id,
                    "delivery_outcome": "failed",
                    "async_job_status": "failed",
                    "summary": failure_summary,
                },
            )
            return
        running_record = self.async_job_store.mark_running(job_key)
        if running_record is not None:
            record = running_record
        if not record.placeholder_sent and not inbound.sender.is_bot:
            try:
                self._send_placeholder_notice(job_key, account=account, inbound=inbound)
            except Exception:
                LOGGER.exception(
                    "Feishu async placeholder send failed for account=%s conversation=%s",
                    inbound.account_id,
                    inbound.conversation_id,
                )
        conversation_lock = self._conversation_lock(record.account_id, record.conversation_id)
        with conversation_lock:
            try:
                self.process_accepted_event(job_key, account=account, inbound=inbound)
            except Exception as exc:
                self._handle_async_job_failure(job_key, account=account, inbound=inbound, exc=exc)

    def _handle_async_job_failure(
        self,
        job_key: str,
        *,
        account: FeishuResolvedAccount,
        inbound: GatewayInboundMessage,
        exc: Exception,
    ) -> None:
        assert self.async_job_store is not None
        failure_summary = str(exc).strip() or exc.__class__.__name__
        LOGGER.exception(
            "Feishu async job failed for account=%s conversation=%s message=%s",
            inbound.account_id,
            inbound.conversation_id,
            inbound.event_id,
        )
        failure_response = {
            **self._base_response_body(transport="long-connection"),
            "account_id": inbound.account_id,
            "conversation_id": inbound.conversation_id,
            "delivery_outcome": "failed",
            "async_job_status": "failed",
            "summary": failure_summary,
        }
        try:
            self._send_failure_notice(account=account, inbound=inbound)
        except Exception:
            LOGGER.exception(
                "Feishu async failure notice send failed for account=%s conversation=%s",
                inbound.account_id,
                inbound.conversation_id,
            )
        self.async_job_store.fail(
            job_key,
            failure_summary=failure_summary,
            response_body=failure_response,
        )

    def _build_async_notice_outbound(
        self,
        inbound: GatewayInboundMessage,
        *,
        body: str,
        kind: str,
    ) -> GatewayOutboundMessage:
        return GatewayOutboundMessage(
            message_id=f"feishu-{kind}:{inbound.conversation_id}:{uuid4().hex[:12]}",
            account=inbound.account,
            conversation=inbound.conversation,
            session_id=f"{kind}:{inbound.conversation_id}",
            body=body,
            reply_to_message_id=inbound.event_id,
            attachment_refs=(),
            metadata={
                **dict(inbound.metadata),
                "delivery_surface": inbound.account.surface or f"feishu-{kind}",
                "runtime_surface": kind,
            },
        )

    def _send_placeholder_notice(
        self,
        job_key: str,
        *,
        account: FeishuResolvedAccount,
        inbound: GatewayInboundMessage,
    ) -> None:
        assert self.adapter is not None
        assert self.async_job_store is not None
        outbound = self._build_async_notice_outbound(
            inbound,
            body=self.async_placeholder_body,
            kind="async-placeholder",
        )
        delivery_request = self.adapter.build_reply_request(outbound)
        delivery_response = self._send_outbound(account, outbound, delivery_request)
        self.async_job_store.mark_placeholder_sent(
            job_key,
            placeholder_message_id=self._external_message_id(delivery_response),
        )

    def _send_failure_notice(
        self,
        *,
        account: FeishuResolvedAccount,
        inbound: GatewayInboundMessage,
    ) -> None:
        assert self.adapter is not None
        outbound = self._build_async_notice_outbound(
            inbound,
            body=self.async_failure_body,
            kind="async-failure",
        )
        delivery_request = self.adapter.build_reply_request(outbound)
        self._send_outbound(account, outbound, delivery_request)

    @property
    def event_paths(self) -> tuple[str, ...]:
        return tuple(dict.fromkeys(config.event_path for config in self.account_configs))

    @property
    def http_paths(self) -> tuple[str, ...]:
        return self.event_paths

    def handle_http_event(
        self,
        payload: Mapping[str, object],
        *,
        path: str,
    ) -> tuple[str, Mapping[str, object]]:
        try:
            result = self.dispatch_event(payload, transport="webhook")
        except LookupError as exc:
            return "503 Service Unavailable", {"ok": False, "error": str(exc)}
        except ValueError as exc:
            return "400 Bad Request", {"ok": False, "error": str(exc)}
        except RuntimeError as exc:
            return "502 Bad Gateway", {"ok": False, "error": str(exc)}
        payload_body = dict(result.response_body)
        if result.delivery_request is not None:
            payload_body["delivery_request_path"] = result.delivery_request.get("path", "")
        return "200 OK", payload_body

    def describe(self) -> Mapping[str, object]:
        async_summary = self._async_summary()
        accounts: list[dict[str, object]] = []
        for config in self.account_configs:
            status = "configured"
            resolved_app_id: str | None = None
            try:
                resolved = resolve_feishu_account(config, environ=self.environ)
                resolved_app_id = resolved.app_id
            except LookupError:
                status = "missing_credentials"
            accounts.append(
                {
                    "account_id": config.account_id,
                    "surface": config.surface,
                    "event_path": config.event_path,
                    "app_id_env_var": config.app_id_env_var,
                    "app_secret_env_var": config.app_secret_env_var,
                    "credential_env_vars": _credential_env_vars(config),
                    "secret_reference_ids": tuple(
                        reference.reference_id for reference in config.secret_references
                    ),
                    "credentials_source": (
                        "secret_references" if config.secret_references else "environment"
                    ),
                    "credentials_status": status,
                    "resolved_app_id": resolved_app_id,
                }
            )
        configured_transport: str | None = None
        configured_transport_error: str | None = None
        try:
            configured_transport = self.configured_transport()
        except (LookupError, ValueError) as exc:
            configured_transport_error = str(exc)
        return {
            "adapter_id": FEISHU_ADAPTER_ID,
            "profile_id": self.app.profile_id,
            "workspace_id": self.app.workspace_id,
            "preferred_transport": "long-connection",
            "implemented_transports": (
                "python-sdk-long-connection",
            ),
            "configured_transport": configured_transport,
            "configured_transport_error": configured_transport_error,
            "sdk_dependency_status": _lark_sdk_dependency_status(),
            "event_paths": self.event_paths,
            "accounts": tuple(accounts),
            "async_delivery_enabled": True,
            "queue_depth": async_summary.get("queue_depth", 0),
            "running_jobs": async_summary.get("running_jobs", 0),
            "worker_count": max(int(self.async_worker_count or 0), 1),
            "recent_failures": async_summary.get("recent_failures", ()),
            "control": (
                self.cli_control.describe()
                if self.cli_control is not None
                else {"enabled": True, "runtime": "cli-runtime", "runtime_status": "unavailable"}
            ),
        }

    def configured_transport(self) -> str:
        if not self.account_configs:
            return "long-connection"
        transports = tuple(
            dict.fromkeys(_normalize_transport(config.surface) for config in self.account_configs)
        )
        if len(transports) == 1:
            return transports[0]
        raise LookupError(
            "configured Feishu accounts use multiple transport surfaces; pass --transport explicitly"
        )

    def configured_runtime_target(self) -> str:
        return self.configured_transport()

    def managed_runtime(
        self,
        *,
        args: Any,
        target: str,
    ) -> GatewayManagedRuntime:
        normalized_target = _normalize_configured_transport(target)
        state_dir = Path(args.state_dir)
        return GatewayManagedRuntime(
            service_key=self.service_key,
            runtime_id=f"{self.service_key}:{normalized_target}",
            target=normalized_target,
            label=f"Feishu {normalized_target} transport",
            pid_path=default_gateway_runtime_path(
                state_dir,
                service_key=self.service_key,
                target=normalized_target,
                suffix="pid",
            ),
            log_path=default_gateway_runtime_path(
                state_dir,
                service_key=self.service_key,
                target=normalized_target,
                suffix="log",
            ),
            record_path=default_gateway_runtime_path(
                state_dir,
                service_key=self.service_key,
                target=normalized_target,
                suffix="runtime.json",
            ),
        )

    def build_detached_runtime_command(
        self,
        *,
        args: Any,
        target: str,
    ) -> tuple[str, ...]:
        command = [
            os.sys.executable,
            "-m",
            "apps.launcher",
            "im",
            "start",
            "--transport",
            _normalize_configured_transport(target),
            "--profile-dir",
            str(args.profile_dir),
            "--state-dir",
            str(args.state_dir),
            "--cli-profile-dir",
            str(args.cli_profile_dir),
            "--cli-state-dir",
            str(args.cli_state_dir),
            "--workspace-id",
            str(args.workspace_id),
            "--host",
            str(args.host),
            "--port",
            str(args.port),
        ]
        if args.account_id:
            command.extend(["--account-id", str(args.account_id)])
        return tuple(command)

    def prepare_managed_runtime(self, *, action: str, target: str) -> None:
        if _normalize_configured_transport(target) != "long-connection":
            return
        if self.runtime_dependency_ensurer is None:
            return
        self.runtime_dependency_ensurer(
            reason=f"Feishu long-connection {action}",
        )

    def managed_runtime_log_hint(self, *, target: str) -> str:
        return (
            "aegis im logs --transport "
            f"{_normalize_configured_transport(target)} --follow"
        )

    def accept_long_connection_event(
        self,
        payload: Mapping[str, object],
        *,
        account_id: str | None = None,
    ) -> FeishuGatewayEventResult:
        challenge = payload.get("challenge")
        if challenge is not None and payload.get("event") is None:
            return FeishuGatewayEventResult(
                exchange=None,
                response_body={"ok": True, "challenge": str(challenge)},
            )

        account = self._match_account(payload, account_id=account_id)
        transport = "long-connection"
        response_body = self._base_response_body(transport=transport)
        assert self.adapter is not None
        assert self.async_job_store is not None
        inbound = self.adapter.normalize_event(
            payload,
            account_id=account.account_id,
            transport=transport,
        )
        raw_event_id, raw_message_id = _feishu_event_identifiers(payload)
        job_key, record, created = self.async_job_store.create_or_get(
            account_id=inbound.account_id,
            conversation_id=inbound.conversation_id,
            event_id=raw_event_id or inbound.metadata.get("event_id") or inbound.event_id,
            message_id=raw_message_id or _optional_text(inbound.metadata.get("message_id")),
            payload=payload,
            transport=transport,
        )
        if not created:
            if record.status == "completed" and record.response_body is not None:
                return self._duplicate_event_result(
                    inbound,
                    transport=transport,
                    response_body=record.response_body,
                )
            if record.status == "failed":
                return self._failed_duplicate_event_result(
                    inbound,
                    transport=transport,
                    failure_summary=record.failure_summary,
                )
            self._ensure_async_workers()
            self._schedule_async_job(job_key)
            return self._async_duplicate_event_result(
                inbound,
                transport=transport,
                status=record.status,
            )
        self._ensure_async_workers()
        self._schedule_async_job(job_key)
        response_body.update(
            {
                "account_id": inbound.account_id,
                "conversation_id": inbound.conversation_id,
                "delivery_outcome": "queued",
                "async_job_status": "queued",
                "summary": "Feishu event accepted and queued for async processing.",
            }
        )
        return FeishuGatewayEventResult(exchange=None, response_body=response_body)

    def process_accepted_event(
        self,
        job_key: str,
        *,
        account: FeishuResolvedAccount | None = None,
        inbound: GatewayInboundMessage | None = None,
    ) -> FeishuGatewayEventResult:
        assert self.async_job_store is not None
        assert self.inbound_event_store is not None
        record = self.async_job_store.get(job_key)
        if record is None:
            raise LookupError(f"unknown Feishu async job: {job_key}")
        if record.status == "completed" and record.response_body is not None:
            return FeishuGatewayEventResult(exchange=None, response_body=record.response_body)
        account = account or self._match_account(record.payload, account_id=record.account_id)
        assert self.adapter is not None
        inbound = inbound or self.adapter.normalize_event(
            record.payload,
            account_id=record.account_id,
            transport=record.transport,
        )
        response_body = self._base_response_body(transport=record.transport)
        if self.cli_control is not None:
            result = self._dispatch_cli_control(
                inbound,
                account=account,
                transport=record.transport,
                response_body=response_body,
                raise_on_error=True,
            )
        else:
            result = self._dispatch_shared_runtime(
                inbound,
                account=account,
                transport=record.transport,
                response_body=response_body,
            )
        external_message_id = _optional_text(result.response_body.get("external_message_id"))
        self.async_job_store.complete(
            job_key,
            response_body=result.response_body,
            external_message_id=external_message_id,
        )
        self.inbound_event_store.commit(
            account_id=inbound.account_id,
            event_id=record.event_id or inbound.event_id,
            message_id=record.message_id or _optional_text(inbound.metadata.get("message_id")),
            response_body=result.response_body,
        )
        return result

    def dispatch_event(
        self,
        payload: Mapping[str, object],
        *,
        account_id: str | None = None,
        transport: str | None = None,
    ) -> FeishuGatewayEventResult:
        challenge = payload.get("challenge")
        if challenge is not None and payload.get("event") is None:
            return FeishuGatewayEventResult(
                exchange=None,
                response_body={"ok": True, "challenge": str(challenge)},
            )

        account = self._match_account(payload, account_id=account_id)
        resolved_transport = _normalize_transport(transport or account.config.surface)
        response_body = self._base_response_body(transport=resolved_transport)
        assert self.adapter is not None
        assert self.inbound_event_store is not None
        inbound = self.adapter.normalize_event(
            payload,
            account_id=account.account_id,
            transport=resolved_transport,
        )
        raw_event_id, raw_message_id = _feishu_event_identifiers(payload)
        dedupe_status, prior_record = self.inbound_event_store.begin(
            account_id=inbound.account_id,
            event_id=raw_event_id or inbound.event_id,
            message_id=raw_message_id or _optional_text(inbound.metadata.get("message_id")),
        )
        if dedupe_status == "duplicate" and prior_record is not None:
            return self._duplicate_event_result(
                inbound,
                transport=resolved_transport,
                response_body=prior_record.response_body,
            )
        if dedupe_status == "inflight":
            return self._inflight_duplicate_event_result(
                inbound,
                transport=resolved_transport,
            )
        try:
            if self.cli_control is not None:
                result = self._dispatch_cli_control(
                    inbound,
                    account=account,
                    transport=resolved_transport,
                    response_body=response_body,
                )
            else:
                result = self._dispatch_shared_runtime(
                    inbound,
                    account=account,
                    transport=resolved_transport,
                    response_body=response_body,
                )
        except Exception:
            self.inbound_event_store.abort(
                account_id=inbound.account_id,
                event_id=raw_event_id or inbound.event_id,
                message_id=raw_message_id or _optional_text(inbound.metadata.get("message_id")),
            )
            raise
        self.inbound_event_store.commit(
            account_id=inbound.account_id,
            event_id=raw_event_id or inbound.event_id,
            message_id=raw_message_id or _optional_text(inbound.metadata.get("message_id")),
            response_body=result.response_body,
        )
        return result

    def _base_response_body(self, *, transport: str) -> dict[str, object]:
        return {
            "ok": True,
            "adapter_id": FEISHU_ADAPTER_ID,
            "transport": transport,
        }

    def _dispatch_cli_control(
        self,
        inbound: GatewayInboundMessage,
        *,
        account: FeishuResolvedAccount,
        transport: str,
        response_body: Mapping[str, object],
        raise_on_error: bool = False,
    ) -> FeishuGatewayEventResult:
        assert self.cli_control is not None
        result = self.cli_control.handle_message(inbound)
        if raise_on_error and result.summary == "control error":
            raise RuntimeError(result.body or "cli control error")
        enriched_response = {
            **dict(response_body),
            "account_id": inbound.account_id,
            "conversation_id": inbound.conversation_id,
            "control_mode": "cli-runtime",
            "delivery_outcome": "ignored" if result.body is None else "delivered",
            "summary": result.summary or "",
        }
        if result.clone_id is not None:
            enriched_response["clone_id"] = result.clone_id
        if result.session_id is not None:
            enriched_response["session_id"] = result.session_id
        if result.body is None:
            return FeishuGatewayEventResult(exchange=None, response_body=enriched_response)
        outbound = self._build_control_outbound(inbound, body=result.body, session_id=result.session_id)
        return self._deliver_outbound_result(
            account,
            outbound,
            exchange=None,
            response_body=enriched_response,
        )

    def _dispatch_shared_runtime(
        self,
        inbound: GatewayInboundMessage,
        *,
        account: FeishuResolvedAccount,
        transport: str,
        response_body: Mapping[str, object],
    ) -> FeishuGatewayEventResult:
        exchange = self.app.handle_message(
            inbound,
            reply_to_message_id=inbound.event_id,
            attachment_refs=inbound.attachment_refs,
            metadata={
                **dict(inbound.metadata),
                "delivery_surface": inbound.account.surface or f"feishu-{transport}",
            },
        )
        enriched_response = {
            **dict(response_body),
            "account_id": exchange.route.inbound.account_id,
            "conversation_id": exchange.route.inbound.conversation_id,
            "session_id": exchange.route.session.session_id,
            "policy_decision": str(exchange.delivery.policy_result.decision),
            "delivery_outcome": exchange.delivery.outcome,
        }
        if exchange.delivery.outbound is None:
            enriched_response["summary"] = exchange.delivery.summary
            return FeishuGatewayEventResult(exchange=exchange, response_body=enriched_response)
        return self._deliver_outbound_result(
            account,
            exchange.delivery.outbound,
            exchange=exchange,
            response_body=enriched_response,
        )

    def _deliver_outbound_result(
        self,
        account: FeishuResolvedAccount,
        outbound: GatewayOutboundMessage,
        *,
        exchange: GatewayExchange | None,
        response_body: Mapping[str, object],
    ) -> FeishuGatewayEventResult:
        assert self.adapter is not None
        delivery_request = self.adapter.build_reply_request(outbound)
        delivery_response = self._send_outbound(account, outbound, delivery_request)
        enriched_response = {
            **dict(response_body),
            "external_message_id": self._external_message_id(delivery_response),
        }
        return FeishuGatewayEventResult(
            exchange=exchange,
            response_body=enriched_response,
            delivery_request=delivery_request,
            delivery_response=delivery_response,
        )

    def _duplicate_event_result(
        self,
        inbound: GatewayInboundMessage,
        *,
        transport: str,
        response_body: Mapping[str, object],
    ) -> FeishuGatewayEventResult:
        duplicate_response = dict(response_body)
        previous_outcome = _optional_text(duplicate_response.get("delivery_outcome"))
        if previous_outcome is not None:
            duplicate_response["initial_delivery_outcome"] = previous_outcome
        duplicate_response["ok"] = True
        duplicate_response["adapter_id"] = FEISHU_ADAPTER_ID
        duplicate_response["transport"] = transport
        duplicate_response["account_id"] = inbound.account_id
        duplicate_response["conversation_id"] = inbound.conversation_id
        duplicate_response["delivery_outcome"] = "deduplicated"
        duplicate_response["duplicate_event"] = True
        duplicate_response["duplicate_handling"] = "replayed-no-delivery"
        duplicate_response["summary"] = (
            "Duplicate Feishu event ignored; the original event was already processed."
        )
        return FeishuGatewayEventResult(exchange=None, response_body=duplicate_response)

    def _inflight_duplicate_event_result(
        self,
        inbound: GatewayInboundMessage,
        *,
        transport: str,
    ) -> FeishuGatewayEventResult:
        response_body = self._base_response_body(transport=transport)
        response_body.update(
            {
                "account_id": inbound.account_id,
                "conversation_id": inbound.conversation_id,
                "delivery_outcome": "deduplicating",
                "duplicate_event": True,
                "duplicate_handling": "inflight",
                "summary": "Duplicate Feishu event is already being processed.",
            }
        )
        return FeishuGatewayEventResult(exchange=None, response_body=response_body)

    def _async_duplicate_event_result(
        self,
        inbound: GatewayInboundMessage,
        *,
        transport: str,
        status: str,
    ) -> FeishuGatewayEventResult:
        response_body = self._base_response_body(transport=transport)
        summary = {
            "queued": "Duplicate Feishu event is queued for async processing.",
            "running": "Duplicate Feishu event is already being processed asynchronously.",
        }.get(status, "Duplicate Feishu event is already being handled asynchronously.")
        delivery_outcome = "processing" if status == "running" else "queued"
        response_body.update(
            {
                "account_id": inbound.account_id,
                "conversation_id": inbound.conversation_id,
                "delivery_outcome": delivery_outcome,
                "async_job_status": status,
                "duplicate_event": True,
                "duplicate_handling": status,
                "summary": summary,
            }
        )
        return FeishuGatewayEventResult(exchange=None, response_body=response_body)

    def _failed_duplicate_event_result(
        self,
        inbound: GatewayInboundMessage,
        *,
        transport: str,
        failure_summary: str | None,
    ) -> FeishuGatewayEventResult:
        response_body = self._base_response_body(transport=transport)
        response_body.update(
            {
                "account_id": inbound.account_id,
                "conversation_id": inbound.conversation_id,
                "delivery_outcome": "failed",
                "async_job_status": "failed",
                "duplicate_event": True,
                "duplicate_handling": "failed",
                "summary": failure_summary or "Feishu event previously failed and will not auto-retry.",
            }
        )
        return FeishuGatewayEventResult(exchange=None, response_body=response_body)

    def _external_message_id(self, response: Mapping[str, object]) -> str:
        data = _mapping(response.get("data")) or {}
        return str(data.get("message_id") or "")

    def build_long_connection_client(
        self,
        *,
        account_id: str | None = None,
        lark_module: Any | None = None,
        client_factory: FeishuWSClientFactory = _default_ws_client_factory,
        log_level: str = "INFO",
    ) -> object:
        if account_id is None and len(self.account_configs) != 1:
            raise LookupError(
                "long-connection mode requires --account-id when multiple Feishu accounts are configured"
            )
        account = self._match_account({}, account_id=account_id)
        self._ensure_async_workers()
        lark = _load_lark_sdk(lark_module)
        handler = self._build_long_connection_handler(
            account=account,
            lark_module=lark,
            log_level=log_level,
        )
        return client_factory(
            lark,
            account.app_id,
            account.app_secret,
            handler,
            _lark_log_level(lark, log_level),
        )

    def start_long_connection(
        self,
        *,
        account_id: str | None = None,
        lark_module: Any | None = None,
        client_factory: FeishuWSClientFactory = _default_ws_client_factory,
        log_level: str = "INFO",
    ) -> object:
        client = self.build_long_connection_client(
            account_id=account_id,
            lark_module=lark_module,
            client_factory=client_factory,
            log_level=log_level,
        )
        start = getattr(client, "start", None)
        if not callable(start):
            raise RuntimeError("feishu long-connection client does not expose start()")
        start()
        return client

    def _build_control_outbound(
        self,
        inbound: GatewayInboundMessage,
        *,
        body: str,
        session_id: str | None,
    ) -> GatewayOutboundMessage:
        return GatewayOutboundMessage(
            message_id=f"feishu-control:{session_id or inbound.conversation_id}:{uuid4().hex[:12]}",
            account=inbound.account,
            conversation=inbound.conversation,
            session_id=session_id or f"control:{inbound.conversation_id}",
            body=body,
            reply_to_message_id=inbound.event_id,
            attachment_refs=(),
            metadata={
                **dict(inbound.metadata),
                "delivery_surface": inbound.account.surface or "feishu-control",
                "runtime_surface": "cli-runtime",
            },
        )

    def _build_long_connection_handler(
        self,
        *,
        account: FeishuResolvedAccount,
        lark_module: Any,
        log_level: str,
    ) -> object:
        dispatcher = getattr(lark_module, "EventDispatcherHandler", None)
        if dispatcher is None or not hasattr(dispatcher, "builder"):
            raise RuntimeError("lark_oapi EventDispatcherHandler builder is unavailable")

        def _handle_message(event: object) -> None:
            payload = _lark_event_payload(event, lark_module=lark_module)
            self.accept_long_connection_event(
                payload,
                account_id=account.account_id,
            )

        builder = dispatcher.builder("", "", _lark_log_level(lark_module, log_level))
        builder = builder.register_p2_im_message_receive_v1(_handle_message)
        return builder.build()

    def _match_account(
        self,
        payload: Mapping[str, object],
        *,
        account_id: str | None = None,
    ) -> FeishuResolvedAccount:
        if not self.account_configs:
            raise LookupError("no Feishu gateway accounts are configured")
        if account_id is not None:
            for config in self.account_configs:
                if config.account_id == account_id:
                    return resolve_feishu_account(config, environ=self.environ)
            raise LookupError(f"unknown Feishu gateway account: {account_id}")

        header_payload = _mapping(payload.get("header")) or {}
        event_app_id = str(header_payload.get("app_id") or "")
        if event_app_id:
            matches: list[FeishuResolvedAccount] = []
            for config in self.account_configs:
                try:
                    resolved = resolve_feishu_account(config, environ=self.environ)
                except LookupError:
                    continue
                if resolved.app_id == event_app_id:
                    matches.append(resolved)
            if len(matches) == 1:
                return matches[0]

        if len(self.account_configs) == 1:
            return resolve_feishu_account(self.account_configs[0], environ=self.environ)
        raise LookupError("could not match Feishu event to a configured gateway account")

    def _tenant_access_token(self, account: FeishuResolvedAccount) -> str:
        cached = self._token_cache.get(account.account_id)
        now = time.time()
        if cached is not None and cached.expires_at - 60 > now:
            return cached.token
        response = self.http_requester(
            "POST",
            f"{account.config.base_url}{account.config.token_path}",
            {
                "app_id": account.app_id,
                "app_secret": account.app_secret,
            },
            {},
        )
        token = str(response.get("tenant_access_token") or "")
        if not token:
            raise RuntimeError("feishu token response did not include tenant_access_token")
        expires_in = int(response.get("expire", 7200) or 7200)
        self._token_cache[account.account_id] = _FeishuTokenCacheEntry(
            token=token,
            expires_at=now + expires_in,
        )
        return token

    def _send_outbound(
        self,
        account: FeishuResolvedAccount,
        outbound: GatewayOutboundMessage,
        delivery_request: Mapping[str, object],
    ) -> Mapping[str, object]:
        path = str(delivery_request.get("path") or "")
        method = str(delivery_request.get("method") or "POST")
        body = _mapping(delivery_request.get("body"))
        if not path or body is None:
            raise RuntimeError("feishu delivery request is missing a path or body payload")
        token = self._tenant_access_token(account)
        return self.http_requester(
            method,
            f"{account.config.base_url}{path}",
            body,
            {"Authorization": f"Bearer {token}"},
        )


def register_feishu_gateway_service(registry: GatewayPluginRegistry) -> GatewayPluginRegistry:
    registry.register_service(
        "feishu",
        factory=lambda app, **kwargs: FeishuGatewayService(app=app, **kwargs),
        enabled_by_default=True,
    )
    return registry


def build_feishu_gateway_service(
    *,
    profile_id: str = "profile:default",
    workspace_id: str | None = None,
    provider_profile: Mapping[str, Any] | None = None,
    profile_dir: str | None = None,
    state_dir: str | None = None,
    default_cli_profile_dir: str | Path | None = None,
    default_cli_state_dir: str | Path | None = None,
    environ: Mapping[str, str] | None = None,
    http_requester: HttpJsonRequester = _default_json_request,
    plugin_registry: GatewayPluginRegistry | None = None,
) -> FeishuGatewayService:
    app, _, _ = build_gateway_app(
        profile_id=profile_id,
        workspace_id=workspace_id,
        provider_profile=provider_profile,
        profile_dir=profile_dir,
        state_dir=state_dir,
        plugin_registry=plugin_registry,
    )
    return FeishuGatewayService(
        app=app,
        http_requester=http_requester,
        environ=dict(environ or os.environ),
        default_cli_profile_dir=(
            None if default_cli_profile_dir is None else str(Path(default_cli_profile_dir))
        ),
        default_cli_state_dir=(
            None if default_cli_state_dir is None else str(Path(default_cli_state_dir))
        ),
    )


def create_gateway_web_app(service: FeishuGatewayService):
    return create_gateway_http_app(service, app=service.app)


__all__ = [
    "DEFAULT_FEISHU_APP_ID_ENV",
    "DEFAULT_FEISHU_APP_SECRET_ENV",
    "LEGACY_FEISHU_APP_ID_ENV",
    "LEGACY_FEISHU_APP_SECRET_ENV",
    "DEFAULT_FEISHU_EVENT_PATH",
    "DEFAULT_FEISHU_BASE_URL",
    "DEFAULT_FEISHU_TOKEN_PATH",
    "SUPPORTED_FEISHU_TRANSPORTS",
    "FeishuGatewayAccountConfig",
    "FeishuGatewayEventResult",
    "FeishuGatewayService",
    "FeishuResolvedAccount",
    "build_feishu_gateway_service",
    "create_gateway_web_app",
    "load_feishu_gateway_accounts",
    "register_feishu_gateway_service",
    "resolve_feishu_account",
]
