"""Gateway application bootstrap and real messaging adapter pair."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, replace
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import tempfile
from typing import Any
from uuid import uuid4

from apps.provider_runtime import (
    EnvironmentSecretStore,
    SurfaceModelProviderCapability,
    load_provider_profile,
    provider_fallback_summary,
    provider_profile_from_payload,
    provider_profile_summary,
)
from packages.auth import AuthProfile, PersistentAuthProfileStore, ProfileCredentialResolver
from packages.capabilities.runtime import (
    CapabilityDescriptor,
    ContextCapability,
    MemoryCapability,
    ModelProviderCapability,
    PlanningCapability,
    TelemetrySinkCapability,
)
from packages.context import ContextRuntime
from packages.contracts.runtime import (
    ContextBundle,
    EventEnvelope,
    ExecutionResult,
    GoalNode,
    MemoryRecord,
    ProfileState,
    SessionState,
)
from packages.gateway_core import (
    DEFAULT_GATEWAY_ACCOUNT_ID,
    FileGatewayIdentityStore,
    FileGatewaySessionStore,
    GatewayAccountRef,
    GatewayAttachmentRef,
    GatewayConversationRef,
    GatewayCoreDependencies,
    GatewayCoreService,
    GatewayExchange,
    GatewayIdentityRecord,
    GatewayInboundMessage,
    GatewayOutboundMessage,
    GatewayPolicyHint,
    GatewaySenderRef,
    InMemoryGatewayIdentityStore,
    InMemoryGatewaySessionStore,
)
from packages.kernel import KernelDependencies, KernelService, KernelTurnRequest
from packages.memory import MemoryRuntime
from packages.planning import GoalGraph, PlanningDecision, PlanningMode, PlanningService
from packages.profile import DEFAULT_CLONE_TEXT, LoadedProfile, ProfileLoader, build_prompt_contract
from packages.security.runtime import SecurityPolicy
from packages.storage import RuntimeStorageRepository
from packages.voice import VoiceInputRequest, VoiceInputResolution, VoiceTurnResult, build_provider_voice_service

from .plugins import GatewayAdapterDescriptor, GatewayPluginRegistry

CHAT_BOT_ADAPTER_ID = "messaging.chat-bot"
WEBHOOK_ADAPTER_ID = "messaging.webhook"
TELEGRAM_ADAPTER_ID = "messaging.telegram"
FEISHU_ADAPTER_ID = "messaging.feishu"
DISCORD_ADAPTER_ID = "messaging.discord"


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _object_map(payload: Mapping[str, object] | None) -> dict[str, object]:
    if payload is None:
        return {}
    return {str(key): value for key, value in payload.items()}


def _string_payload(payload: Mapping[str, object] | None) -> dict[str, str]:
    if payload is None:
        return {}
    return {str(key): str(value) for key, value in payload.items()}


def _account_ref(
    adapter_id: str,
    *,
    account_id: str = DEFAULT_GATEWAY_ACCOUNT_ID,
    surface: str | None = None,
    tenant_id: str | None = None,
    metadata: Mapping[str, object] | None = None,
) -> GatewayAccountRef:
    return GatewayAccountRef(
        adapter_id=adapter_id,
        account_id=account_id,
        tenant_id=tenant_id,
        surface=surface,
        metadata=_object_map(metadata),
    )


def _conversation_ref(
    conversation_id: str,
    *,
    parent_conversation_id: str | None = None,
    thread_id: str | None = None,
    chat_type: str | None = None,
    title: str | None = None,
    metadata: Mapping[str, object] | None = None,
) -> GatewayConversationRef:
    return GatewayConversationRef(
        conversation_id=conversation_id,
        parent_conversation_id=parent_conversation_id,
        thread_id=thread_id,
        chat_type=chat_type,
        title=title,
        metadata=_object_map(metadata),
    )


def _sender_ref(
    external_user_id: str,
    *,
    display_name: str | None = None,
    username: str | None = None,
    is_bot: bool = False,
    is_self: bool = False,
    metadata: Mapping[str, object] | None = None,
) -> GatewaySenderRef:
    return GatewaySenderRef(
        external_user_id=external_user_id,
        display_name=display_name,
        username=username,
        is_bot=is_bot,
        is_self=is_self,
        metadata=_object_map(metadata),
    )


def _attachment_refs(
    attachment_ids: tuple[str, ...],
    *,
    kind: str = "file",
) -> tuple[GatewayAttachmentRef, ...]:
    deduped = tuple(dict.fromkeys(attachment_ids))
    return tuple(
        GatewayAttachmentRef(
            attachment_id=attachment_id,
            kind=kind,
            platform_fetch_ref=attachment_id,
        )
        for attachment_id in deduped
    )


def _policy_hint(
    *,
    target_trusted_default: bool,
    consent_default: bool,
    is_external_default: bool,
    audience_scope: str | None = None,
    metadata: Mapping[str, object] | None = None,
) -> GatewayPolicyHint:
    return GatewayPolicyHint(
        target_trusted_default=target_trusted_default,
        consent_default=consent_default,
        is_external_default=is_external_default,
        audience_scope=audience_scope,
        metadata=_object_map(metadata),
    )


def _normalized_chat_type(chat_type: str) -> str:
    if chat_type == "private":
        return "direct"
    if chat_type == "p2p":
        return "direct"
    if chat_type in {"group", "supergroup"}:
        return "group"
    if chat_type == "channel":
        return "channel"
    return chat_type


def _telegram_display_name(payload: Mapping[str, object]) -> str | None:
    first_name = str(payload.get("first_name") or "").strip()
    last_name = str(payload.get("last_name") or "").strip()
    username = str(payload.get("username") or "").strip()
    combined = " ".join(part for part in (first_name, last_name) if part)
    if combined:
        return combined
    if username:
        return f"@{username}"
    return None


def _telegram_attachment_ids(message: Mapping[str, object]) -> tuple[str, ...]:
    attachments: list[str] = []
    photos = message.get("photo")
    if isinstance(photos, list):
        for item in photos:
            if isinstance(item, Mapping) and item.get("file_id") is not None:
                attachments.append(str(item["file_id"]))
    for key in ("document", "audio", "video", "voice", "sticker"):
        value = message.get(key)
        if isinstance(value, Mapping) and value.get("file_id") is not None:
            attachments.append(str(value["file_id"]))
    return tuple(dict.fromkeys(attachments))


def _telegram_delivery_defaults(chat_type: str) -> tuple[bool, bool, bool]:
    if chat_type == "private":
        return True, True, False
    return False, False, True


def _telegram_conversation_id(chat_id: str, thread_id: object | None) -> str:
    if thread_id is None:
        return chat_id
    return f"{chat_id}:{thread_id}"


def _discord_display_name(
    author: Mapping[str, object],
    *,
    member: Mapping[str, object] | None = None,
) -> str | None:
    if member is not None and member.get("nick") is not None:
        nickname = str(member.get("nick") or "").strip()
        if nickname:
            return nickname
    for key in ("global_name", "display_name", "username"):
        value = str(author.get(key) or "").strip()
        if value:
            return value
    return None


def _discord_attachment_refs(
    attachments: object,
) -> tuple[GatewayAttachmentRef, ...]:
    if not isinstance(attachments, list):
        return ()
    resolved: list[GatewayAttachmentRef] = []
    for item in attachments:
        if not isinstance(item, Mapping):
            continue
        attachment_id = str(item.get("id") or "").strip()
        if not attachment_id:
            continue
        filename = str(item.get("filename") or "").strip()
        content_type = str(item.get("content_type") or "").strip()
        resolved.append(
            GatewayAttachmentRef(
                attachment_id=attachment_id,
                kind="file",
                platform_fetch_ref=str(item.get("url") or attachment_id),
                metadata={
                    "filename": filename,
                    "content_type": content_type,
                },
            )
        )
    return tuple(resolved)


def _discord_chat_type(payload: Mapping[str, object]) -> str:
    explicit = str(payload.get("chat_type") or "").strip().lower()
    if explicit in {"direct", "channel", "topic"}:
        return explicit
    channel_type = payload.get("channel_type")
    try:
        channel_type_value = int(channel_type) if channel_type is not None else None
    except (TypeError, ValueError):
        channel_type_value = None
    if channel_type_value == 1:
        return "direct"
    if channel_type_value in {10, 11, 12}:
        return "topic"
    if payload.get("thread_id") is not None or payload.get("parent_id") is not None:
        return "topic"
    if payload.get("guild_id") is not None:
        return "channel"
    return "direct"


def _discord_delivery_defaults(chat_type: str) -> tuple[bool, bool, bool]:
    if chat_type == "direct":
        return True, True, False
    return False, False, True


def _discord_body(payload: Mapping[str, object]) -> str:
    content = str(payload.get("content") or "").strip()
    if content:
        return content
    attachments = _discord_attachment_refs(payload.get("attachments"))
    if attachments:
        filenames = [
            str(ref.metadata.get("filename") or "").strip()
            for ref in attachments
            if str(ref.metadata.get("filename") or "").strip()
        ]
        if filenames:
            return f"[attachments] {' '.join(filenames)}"
        return "[attachments]"
    return "discord-message"


_COMMAND_PREFIX_RE = re.compile(
    r"^(?:[$>]\s*)?(?:"
    r"aegis|uv|python(?:3)?|pip|pytest|git|npm|pnpm|yarn|node|bash|sh|zsh|fish|"
    r"cd|ls|cat|echo|cp|mv|rm|mkdir|touch|chmod|chown|grep|rg|sed|awk|curl|wget|"
    r"tar|zip|unzip|docker(?:-compose)?|kubectl|helm|terraform|ansible|make|cmake|"
    r"go|cargo|java|javac|mvn|gradle|poetry|uvicorn|flask|sqlite3|psql|mysql|redis-cli|"
    r"systemctl|journalctl|(?:/[\w./-]+)|(?:\./[\w./-]+)|(?:/[a-z][\w-]*)(?:\s+.+)?"
    r")\b"
)
_LATEX_COMMAND_RE = re.compile(
    r"\\(?:frac|sum|int|sqrt|alpha|beta|gamma|delta|theta|lambda|mu|pi|sigma|Delta|cdot|times|leq|geq)\b"
)
_CODE_PREFIXES = (
    "def ",
    "class ",
    "import ",
    "from ",
    "async def ",
    "return ",
    "if ",
    "elif ",
    "else:",
    "for ",
    "while ",
    "try:",
    "except ",
    "finally:",
    "with ",
    "const ",
    "let ",
    "var ",
    "function ",
    "interface ",
    "type ",
    "SELECT ",
    "INSERT ",
    "UPDATE ",
    "DELETE ",
    "{",
    "[",
    "<",
    "</",
)
_CODE_SIGNAL_RE = re.compile(
    r"(\b[A-Za-z_][\w.]*\([^\n]*\)|\s:=\s|\s=\s|->|=>|::|\{.*\}|</?[A-Za-z][^>]*>|;\s*$)"
)



def _is_command_line(line: str) -> bool:
    stripped = line.strip()
    if not stripped:
        return False
    if stripped.startswith(("```", "- ", "* ", "+ ")):
        return False
    return _COMMAND_PREFIX_RE.match(stripped) is not None



def _is_formula_line(line: str) -> bool:
    stripped = line.strip()
    if not stripped or _is_command_line(stripped):
        return False
    if stripped.startswith(("$$", "\\(", "\\[", "\\begin{")):
        return True
    if stripped.endswith(("$$", "\\)", "\\]", "\\end{")):
        return True
    if _LATEX_COMMAND_RE.search(stripped):
        return True
    if not re.fullmatch(r"[A-Za-z0-9_(){}\[\] +\-*/=^<>|.,\\]+", stripped):
        return False
    operator_count = len(re.findall(r"[+\-*/=^<>]", stripped))
    if operator_count < 1:
        return False
    alpha_count = sum(character.isalpha() for character in stripped)
    return alpha_count <= max(16, len(stripped) // 2)



def _looks_like_code_line(line: str) -> bool:
    stripped = line.strip()
    if not stripped or _is_command_line(stripped) or _is_formula_line(stripped):
        return False
    if stripped.startswith(("- ", "* ", "+ ", "> ")):
        return False
    if stripped.startswith(_CODE_PREFIXES):
        return True
    return _CODE_SIGNAL_RE.search(stripped) is not None



def _detect_code_fence_language(lines: list[str]) -> str:
    first = next((line.strip() for line in lines if line.strip()), "")
    if not first:
        return ""
    if _is_command_line(first):
        return "bash"
    if _is_formula_line(first):
        return "tex"
    if first.startswith(("def ", "class ", "import ", "from ", "async def ")):
        return "python"
    if first.startswith(("const ", "let ", "var ", "function ", "interface ", "type ")):
        return "ts"
    if first.startswith(("SELECT ", "INSERT ", "UPDATE ", "DELETE ")):
        return "sql"
    if first.startswith(("{", "[")):
        return "json"
    if first.startswith(("<", "</")):
        return "html"
    return "text"



def _fenced_block(lines: list[str], *, language: str) -> list[str]:
    opening = f"```{language}" if language else "```"
    return [opening, *lines, "```"]



def _wrap_rich_text_block(lines: list[str]) -> list[str]:
    if not lines:
        return []
    meaningful_lines = [line for line in lines if line.strip()]
    if not meaningful_lines:
        return lines
    if all(_is_command_line(line) for line in meaningful_lines):
        return _fenced_block(lines, language="bash")
    if all(_is_formula_line(line) for line in meaningful_lines):
        return _fenced_block(lines, language="tex")
    code_like_lines = [line for line in meaningful_lines if _looks_like_code_line(line)]
    if code_like_lines and (
        len(meaningful_lines) == 1 or len(code_like_lines) >= max(1, len(meaningful_lines) - 1)
    ):
        return _fenced_block(lines, language=_detect_code_fence_language(meaningful_lines))
    return lines



def _render_rich_text_plain_segment(lines: list[str]) -> list[str]:
    rendered: list[str] = []
    block: list[str] = []

    def flush_block() -> None:
        if not block:
            return
        rendered.extend(_wrap_rich_text_block(block))
        block.clear()

    for raw_line in lines:
        if not raw_line.strip():
            flush_block()
            if rendered and rendered[-1] != "":
                rendered.append("")
            continue
        block.append(raw_line)
    flush_block()
    return rendered



def _render_rich_text_body(body: str) -> str:
    normalized = body.replace("\r\n", "\n")
    if not normalized.strip():
        return normalized
    rendered: list[str] = []
    plain_segment: list[str] = []
    in_fence = False
    for raw_line in normalized.split("\n"):
        stripped = raw_line.strip()
        if stripped.startswith("```"):
            if plain_segment:
                rendered.extend(_render_rich_text_plain_segment(plain_segment))
                plain_segment.clear()
            rendered.append(raw_line)
            in_fence = not in_fence
            continue
        if in_fence:
            rendered.append(raw_line)
            continue
        plain_segment.append(raw_line)
    if plain_segment:
        rendered.extend(_render_rich_text_plain_segment(plain_segment))
    return "\n".join(rendered)



def _discord_reply_request(outbound: GatewayOutboundMessage) -> Mapping[str, object]:
    rendered_body = _render_rich_text_body(outbound.body)
    body: dict[str, object] = {
        "content": rendered_body,
        "allowed_mentions": {"parse": [], "replied_user": False},
    }
    guild_id = str(outbound.metadata.get("guild_id") or "").strip()
    if outbound.reply_to_message_id is not None:
        body["message_reference"] = {
            "message_id": outbound.reply_to_message_id,
            "channel_id": outbound.conversation_id,
        }
        if guild_id:
            body["message_reference"]["guild_id"] = guild_id
    return {
        "method": "POST",
        "path": f"/channels/{outbound.conversation_id}/messages",
        "path_label": "/channels/{channel_id}/messages",
        "channel_id": outbound.conversation_id,
        "guild_id": guild_id,
        "body": body,
    }


def _feishu_sender_user_id(payload: Mapping[str, object]) -> str:
    sender_id = payload.get("sender_id")
    if isinstance(sender_id, Mapping):
        for key in ("open_id", "user_id", "union_id"):
            value = sender_id.get(key)
            if value is not None:
                return str(value)
    for key in ("open_id", "user_id", "union_id"):
        value = payload.get(key)
        if value is not None:
            return str(value)
    raise ValueError("feishu sender payload requires sender_id.open_id, sender_id.user_id, or sender_id.union_id")


def _feishu_display_name(payload: Mapping[str, object]) -> str | None:
    for key in ("name", "display_name", "sender_name"):
        value = payload.get(key)
        if value is not None:
            normalized = str(value).strip()
            if normalized:
                return normalized
    return None


def _feishu_message_content(content: object) -> dict[str, object]:
    if isinstance(content, Mapping):
        return {str(key): value for key, value in content.items()}
    if content is None:
        return {}
    if isinstance(content, str):
        try:
            parsed = json.loads(content)
        except json.JSONDecodeError:
            return {"raw": content}
        if isinstance(parsed, Mapping):
            return {str(key): value for key, value in parsed.items()}
        return {"raw": content}
    return {"raw": str(content)}


def _feishu_attachment_refs(content: Mapping[str, object]) -> tuple[GatewayAttachmentRef, ...]:
    deduped: dict[str, GatewayAttachmentRef] = {}
    for field_name, kind in (
        ("image_key", "image"),
        ("file_key", "file"),
        ("audio_key", "audio"),
        ("media_key", "media"),
    ):
        value = content.get(field_name)
        if value is None:
            continue
        attachment_id = str(value)
        deduped.setdefault(
            attachment_id,
            GatewayAttachmentRef(
                attachment_id=attachment_id,
                kind=kind,
                platform_fetch_ref=attachment_id,
            ),
        )
    return tuple(deduped.values())


def _feishu_post_rows_text(rows: object) -> str | None:
    if not isinstance(rows, list):
        return None
    rendered_rows: list[str] = []
    for row in rows:
        if not isinstance(row, list):
            continue
        fragments: list[str] = []
        for item in row:
            if not isinstance(item, Mapping):
                continue
            text = item.get("text")
            if text is not None:
                fragments.append(str(text))
        if fragments:
            rendered_rows.append("".join(fragments))
    if not rendered_rows:
        return None
    return "\n".join(rendered_rows)


def _feishu_message_body(
    message_type: str,
    content: Mapping[str, object],
) -> str:
    if message_type == "text":
        text = content.get("text")
        if text is not None:
            return str(text)
    if message_type == "post":
        for locale in ("zh_cn", "en_us"):
            locale_payload = content.get(locale)
            if isinstance(locale_payload, Mapping):
                title = str(locale_payload.get("title") or "").strip()
                rows_text = _feishu_post_rows_text(locale_payload.get("content"))
                if title and rows_text:
                    return f"{title}\n{rows_text}"
                if title:
                    return title
                if rows_text:
                    return rows_text
        title = str(content.get("title") or "").strip()
        rows_text = _feishu_post_rows_text(content.get("content"))
        if title and rows_text:
            return f"{title}\n{rows_text}"
        if title:
            return title
        if rows_text:
            return rows_text
    if "text" in content and content["text"] is not None:
        return str(content["text"])
    return f"feishu-{message_type}-message"


def _feishu_extract_title_and_body(body: str) -> tuple[str, str]:
    normalized = body.replace("\r\n", "\n")
    title = "Aegis"
    lines = normalized.split("\n")
    for index, raw_line in enumerate(lines):
        stripped = raw_line.strip()
        if not stripped:
            continue
        heading = re.fullmatch(r"#{1,6}\s+(.+)", stripped)
        if heading is not None:
            title = heading.group(1).strip() or title
            lines = [*lines[:index], *lines[index + 1 :]]
            break
        if len(stripped) <= 72 and not re.match(r"^([-*•]|\d+[.)]|`{3}|>)\s*", stripped):
            remaining = [line.strip() for line in lines[index + 1 :] if line.strip()]
            if remaining and re.match(r"^([-*•]|\d+[.)])\s+", remaining[0]):
                title = stripped.rstrip(":：").strip() or title
                lines = [*lines[:index], *lines[index + 1 :]]
            break
        break
    return title, "\n".join(lines).strip() or normalized.strip() or "(empty reply)"



def _feishu_json_v2_markdown_body(body: str) -> str:
    normalized = body.replace("\r\n", "\n")
    language_aliases = {
        "tex": "latex",
        "ts": "typescript",
        "text": "plain_text",
    }
    rendered_lines: list[str] = []
    for raw_line in normalized.split("\n"):
        stripped = raw_line.strip()
        if stripped.startswith("```") and len(stripped) > 3:
            language = stripped[3:].strip().lower()
            mapped = language_aliases.get(language, language)
            rendered_lines.append(f"```{mapped}")
            continue
        rendered_lines.append(raw_line)
    return "\n".join(rendered_lines)



def _feishu_interactive_payload(body: str) -> dict[str, object]:
    title, markdown_body = _feishu_extract_title_and_body(body)
    return {
        "schema": "2.0",
        "config": {"wide_screen_mode": True},
        "body": {
            "direction": "vertical",
            "padding": "12px 12px 12px 12px",
            "elements": [
                {
                    "tag": "markdown",
                    "content": _feishu_json_v2_markdown_body(markdown_body),
                    "text_align": "left",
                }
            ],
        },
        "header": {
            "title": {
                "tag": "plain_text",
                "content": title,
            },
            "padding": "12px 12px 12px 12px",
        },
    }



def _feishu_reply_request(outbound: "GatewayOutboundMessage") -> dict[str, object]:
    if not outbound.reply_to_message_id:
        raise ValueError("feishu reply request requires reply_to_message_id")
    rendered_body = _render_rich_text_body(outbound.body)
    delivery_uuid = f"aegis-{hashlib.sha256(outbound.message_id.encode('utf-8')).hexdigest()[:32]}"
    return {
        "method": "POST",
        "path": f"/open-apis/im/v1/messages/{outbound.reply_to_message_id}/reply",
        "body": {
            "content": json.dumps(_feishu_interactive_payload(rendered_body), ensure_ascii=False),
            "msg_type": "interactive",
            "reply_in_thread": outbound.conversation.thread_id is not None,
            "uuid": delivery_uuid,
        },
    }


def _runtime_database_path(state_dir: Path | None) -> Path:
    if state_dir is not None:
        state_dir.mkdir(parents=True, exist_ok=True)
        return state_dir / "gateway-runtime.sqlite3"
    return Path(tempfile.mkdtemp(prefix="aegis-gateway-runtime-")) / "gateway-runtime.sqlite3"


def _default_loaded_profile(profile_id: str) -> LoadedProfile:
    state = ProfileState(
        profile_id=profile_id,
        display_name="Aegis",
        mode="her",
    )
    return LoadedProfile(
        state=state,
        her_mode=None,
        profile_dir="",
        manifest_path=None,
        clone_text=DEFAULT_CLONE_TEXT,
    )


class GatewayTelemetrySink(TelemetrySinkCapability):
    def __init__(self) -> None:
        self.descriptor = CapabilityDescriptor(
            capability_id="gateway.telemetry",
            kind="telemetry_sink",
            version="1.0.0",
            metadata={"description": "In-process telemetry sink for gateway shared-runtime turns."},
        )
        self._events: list[dict[str, Any]] = []

    @property
    def events(self) -> tuple[dict[str, Any], ...]:
        return tuple(self._events)

    def emit(self, event: Mapping[str, Any]) -> None:
        self._events.append(dict(event))


class GatewayMemoryCapability(MemoryCapability):
    def __init__(self, runtime: MemoryRuntime) -> None:
        self.descriptor = CapabilityDescriptor(
            capability_id="gateway.memory",
            kind="memory",
            version="1.0.0",
            metadata={"description": "Shared memory adapter for gateway turns."},
        )
        self.runtime = runtime

    def record(self, memory: MemoryRecord) -> None:
        self.runtime.store.upsert(memory)

    def search(
        self,
        session_id: str,
        query: str,
        *,
        goal_ids: tuple[str, ...] = (),
        scope_session_ids: tuple[str, ...] = (),
        scope_reason: str = "",
    ) -> tuple[MemoryRecord, ...]:
        result = self.runtime.retrieve(
            session_id,
            query,
            goal_ids=goal_ids,
            scope_session_ids=scope_session_ids,
            scope_reason=scope_reason,
        )
        return tuple(candidate.record for candidate in result.candidates)


class GatewayContextCapability(ContextCapability):
    def __init__(self, profile: LoadedProfile, *, total_tokens: int = 3072) -> None:
        self.prompt_contract = build_prompt_contract(profile, prompt_mode="full")
        self.descriptor = CapabilityDescriptor(
            capability_id="gateway.context",
            kind="context",
            version="1.0.0",
            metadata={"description": "Prompt-contract-aware context adapter for gateway turns."},
        )
        self.runtime = ContextRuntime(
            instruction_refs=self.prompt_contract.instruction_refs,
            total_tokens=total_tokens,
        )

    def assemble(
        self,
        session: SessionState,
        goals: tuple[GoalNode, ...],
        memories: tuple[MemoryRecord, ...],
    ) -> ContextBundle:
        bundle = self.runtime.assemble(session, goals, memories)
        return replace(
            bundle,
            bundle_id=f"bundle:{session.session_id}:{len(goals)}:{len(memories)}",
            instruction_refs=self.prompt_contract.instruction_refs,
        )


class GatewayPlanningCapability(PlanningCapability):
    def __init__(self, service: PlanningService) -> None:
        self.descriptor = CapabilityDescriptor(
            capability_id="gateway.planning",
            kind="planning",
            version="1.0.0",
            metadata={"description": "Shared planning adapter for gateway turns."},
        )
        self.service = service

    def choose_next_step(
        self,
        *,
        session: SessionState,
        graph: GoalGraph,
        memories: tuple[MemoryRecord, ...] = (),
        mode: PlanningMode = "guided",
        initiative_hint: str | None = None,
        continuity_notes: tuple[str, ...] = (),
        now: datetime | None = None,
    ) -> PlanningDecision:
        return self.service.choose_next_step(
            session=session,
            graph=graph,
            memories=memories,
            mode=mode,
            initiative_hint=initiative_hint,
            continuity_notes=continuity_notes,
            now=now,
        )

    def maintain_goal_graph(
        self,
        *,
        session: SessionState,
        graph: GoalGraph,
        prompt: str,
        goal_query: str | None = None,
        event: EventEnvelope | None = None,
        now: datetime | None = None,
    ):
        return self.service.maintain_goal_graph(
            session=session,
            graph=graph,
            prompt=prompt,
            goal_query=goal_query,
            event=event,
            now=now,
        )

    def reconcile_goal_graph(
        self,
        *,
        session: SessionState,
        graph: GoalGraph,
        prompt: str,
        execution: ExecutionResult,
        decision: PlanningDecision | None = None,
        event: EventEnvelope | None = None,
        now: datetime | None = None,
    ):
        return self.service.reconcile_goal_graph(
            session=session,
            graph=graph,
            prompt=prompt,
            execution=execution,
            decision=decision,
            event=event,
            now=now,
        )


class GatewayPreviewModelProvider(ModelProviderCapability):
    def __init__(self) -> None:
        self.descriptor = CapabilityDescriptor(
            capability_id="gateway.model.preview",
            kind="model_provider",
            version="1.0.0",
            metadata={"description": "Deterministic conversational fallback for gateway turns."},
        )

    def generate(
        self,
        *,
        profile: ProfileState,
        session: SessionState,
        context: ContextBundle,
        prompt: str,
    ) -> ExecutionResult:
        normalized = prompt.strip()
        lowered = normalized.lower()
        if not normalized:
            summary = "I'm here with you."
        elif "who are you" in lowered:
            summary = "I'm Aegis, your persistent AI, staying with the thread across time."
        elif normalized.endswith("?"):
            summary = f"I’m tracking this with you: {normalized}"
        else:
            summary = f"I’m with you on this: {normalized}"
        return ExecutionResult(
            execution_id=f"gateway.model:{session.session_id}:{uuid4().hex}",
            session_id=session.session_id,
            outcome="ok",
            summary=summary,
            side_effects=("gateway-preview-provider", profile.mode),
        )


class GatewaySurfaceModelProvider(ModelProviderCapability):
    def __init__(
        self,
        *,
        repository: RuntimeStorageRepository,
        fallback: ModelProviderCapability,
        active_provider_profile: AuthProfile | None,
        runtime_environ: Mapping[str, str] | None = None,
    ) -> None:
        credential_resolver = None
        if runtime_environ is not None:
            credential_resolver = ProfileCredentialResolver(EnvironmentSecretStore(runtime_environ))
        self.surface = SurfaceModelProviderCapability(
            repository=repository,
            secret_key_path=repository.database_path.parent / "provider-secrets.key",
            fallback=fallback,
            credential_resolver=credential_resolver,
            active_provider_profile_id=(
                active_provider_profile.profile_id if active_provider_profile is not None else None
            ),
            active_provider_id=(
                active_provider_profile.provider_id if active_provider_profile is not None else None
            ),
            capability_id="gateway.model.runtime",
            surface_label="gateway",
        )
        self.descriptor = self.surface.descriptor
        self.fallback = fallback

    def describe(self) -> Mapping[str, object]:
        return self.surface.describe()

    def generate(
        self,
        *,
        profile: ProfileState,
        session: SessionState,
        context: ContextBundle,
        prompt: str,
    ) -> ExecutionResult:
        try:
            return self.surface.generate(
                profile=profile,
                session=session,
                context=context,
                prompt=prompt,
            )
        except LookupError:
            return self.fallback.generate(
                profile=profile,
                session=session,
                context=context,
                prompt=prompt,
            )


@dataclass(frozen=True, slots=True)
class GatewayApp:
    core: GatewayCoreService
    profile_id: str
    provider_runtime: Mapping[str, object]
    repository: RuntimeStorageRepository
    auth_store: PersistentAuthProfileStore
    memory_runtime: MemoryRuntime
    kernel: KernelService
    telemetry: GatewayTelemetrySink
    model_provider: GatewaySurfaceModelProvider
    plugin_registry: GatewayPluginRegistry | None = None
    workspace_id: str | None = None
    profile_dir: str | None = None
    state_dir: str | None = None
    loaded_profile: LoadedProfile | None = None
    provider_profile: AuthProfile | None = None

    def handle_message(
        self,
        inbound: GatewayInboundMessage,
        *,
        reply_body: str | None = None,
        reply_to_message_id: str | None = None,
        attachment_refs: tuple[GatewayAttachmentRef, ...] = (),
        metadata: Mapping[str, object] | None = None,
        target_trusted: bool | None = None,
        consent_given: bool | None = None,
        is_external: bool | None = None,
    ) -> GatewayExchange:
        route = self.core.route_inbound(
            inbound,
            profile_id=self.profile_id,
            workspace_id=self.workspace_id,
        )
        session = self._ensure_runtime_session(route.session)
        event = self._event_for_inbound(inbound, session_id=session.session_id)
        self.memory_runtime.append_event(event)
        outcome = self.kernel.run(
            KernelTurnRequest(
                event=event,
                prompt=inbound.body,
            )
        )
        refreshed_session = outcome.session
        self.core.dependencies.session_store.save(refreshed_session)
        route = replace(route, session=refreshed_session)
        provider_summary = self.model_provider.describe()
        delivery = self.core.deliver(
            route,
            body=reply_body or outcome.execution.summary,
            reply_to_message_id=reply_to_message_id
            or inbound.reply_to_message_id
            or inbound.event_id,
            attachment_refs=attachment_refs,
            metadata={
                **dict(metadata or {}),
                "runtime_surface": "gateway.shared-runtime",
                "context_bundle_id": outcome.context.bundle_id,
                "execution_id": outcome.execution.execution_id,
                "provider_id": str(provider_summary.get("provider_id") or "preview"),
            },
            target_trusted=target_trusted,
            consent_given=consent_given,
            is_external=is_external,
        )
        return GatewayExchange(route=route, delivery=delivery)

    def provider_summary(self) -> Mapping[str, object]:
        return dict(self.model_provider.describe())

    def voice_summary(self) -> Mapping[str, object]:
        return self._build_voice_service().provider_summary()

    def voice_doctor(self) -> Mapping[str, object]:
        if self.loaded_profile is None:
            return {
                "status": "not-ready",
                "checks": (
                    {"check": "profile_bundle", "status": "missing"},
                ),
                "supported_path": "one-shot gateway voice remains subordinate to the text delivery path",
                "non_goals": (
                    "always-on duplex voice",
                    "provider-specific delivery forks in the gateway layer",
                ),
                "provider": self.voice_summary(),
            }
        return self._build_voice_service().doctor(self.loaded_profile)

    def setup_summary(self) -> Mapping[str, object]:
        registry = self.plugin_registry or _builtin_gateway_plugin_registry()
        return {
            "profile_id": self.profile_id,
            "profile_dir": self.profile_dir,
            "state_dir": self.state_dir,
            "workspace_id": self.workspace_id,
            "adapters": registry.adapter_id_map(),
            "adapter_setup": registry.adapter_setup_payload(),
            "provider": dict(self.provider_runtime),
            "voice": dict(self.voice_summary()),
        }

    def identity_records(self) -> tuple[GatewayIdentityRecord, ...]:
        return self.core.dependencies.identity_store.list_records()

    def session_records(self) -> tuple[SessionState, ...]:
        return self.core.dependencies.session_store.list_records()

    def memory_records(self, session_id: str | None = None) -> tuple[MemoryRecord, ...]:
        return self.memory_runtime.store.list(session_id=session_id)

    def interrupt_session(
        self,
        session_id: str,
        *,
        interruption_state: str,
        interrupted_at: datetime | None = None,
    ) -> SessionState:
        session = self.core.dependencies.session_store.lookup(session_id)
        if session is None:
            raise KeyError(session_id)
        updated = replace(
            session,
            status="interrupted",
            interruption_state=interruption_state,
            updated_at=interrupted_at or _utc_now(),
        )
        self.core.dependencies.session_store.save(updated)
        self.repository.upsert_session(updated)
        return updated

    def handle_voice_message(
        self,
        inbound: GatewayInboundMessage,
        *,
        audio_bytes: bytes,
        audio_name: str,
        audio_format: str | None = None,
        reply_body: str | None = None,
        reply_to_message_id: str | None = None,
        attachment_refs: tuple[GatewayAttachmentRef, ...] = (),
        metadata: Mapping[str, object] | None = None,
        target_trusted: bool | None = None,
        consent_given: bool | None = None,
        is_external: bool | None = None,
        voice_output_enabled: bool = False,
        output_audio_format: str = "mp3",
    ) -> "GatewayVoiceExchange":
        if self.loaded_profile is None:
            raise ValueError("gateway voice mode requires a loaded profile bundle")
        voice_service = self._build_voice_service()
        resolved_consent_given = (
            inbound.policy_hint.consent_default
            if consent_given is None
            else consent_given
        )
        voice_session = voice_service.open_session(
            self.loaded_profile,
            f"session:{inbound.adapter_id}:{inbound.account_id}:{inbound.conversation_id}",
        )
        resolution = voice_service.resolve_input(
            self.loaded_profile,
            voice_session,
            VoiceInputRequest(
                request_id=f"{inbound.event_id}:voice",
                session_id=voice_session.session_id,
                profile_id=self.profile_id,
                source="provider-backed",
                consent_given=resolved_consent_given,
                recording_enabled=False,
                metadata={
                    "adapter_id": inbound.adapter_id,
                    "account_id": inbound.account_id,
                },
                audio_bytes=audio_bytes,
                audio_format=audio_format,
                audio_name=audio_name,
            ),
        )
        normalized_inbound = GatewayInboundMessage(
            event_id=inbound.event_id,
            account=inbound.account,
            conversation=inbound.conversation,
            sender=inbound.sender,
            body=resolution.transcript or inbound.body,
            body_format=inbound.body_format,
            reply_to_message_id=inbound.reply_to_message_id,
            attachment_refs=inbound.attachment_refs,
            policy_hint=inbound.policy_hint,
            received_at=inbound.received_at,
            metadata={
                **dict(inbound.metadata),
                "voice_input_source": resolution.request.source,
                **{key: value for key, value in resolution.metadata.items() if value},
            },
        )
        exchange = self.handle_message(
            normalized_inbound,
            reply_body=reply_body,
            reply_to_message_id=reply_to_message_id,
            attachment_refs=attachment_refs,
            metadata=metadata,
            target_trusted=target_trusted,
            consent_given=consent_given,
            is_external=is_external,
        )
        voice_turn = voice_service.complete_output(
            self.loaded_profile,
            voice_session,
            resolution,
            response_transcript=exchange.delivery.summary,
            voice_output_enabled=voice_output_enabled,
            audio_format=output_audio_format,
        )
        if exchange.delivery.outbound is not None:
            outbound = replace(
                exchange.delivery.outbound,
                metadata={
                    **dict(exchange.delivery.outbound.metadata),
                    **(
                        dict(voice_turn.output.metadata)
                        if voice_turn.output is not None and voice_turn.output.metadata is not None
                        else {}
                    ),
                    "voice_output_mode": voice_turn.output.delivery_mode if voice_turn.output is not None else "text",
                    "voice_output_provider_id": (
                        voice_turn.output.provider_id
                        if voice_turn.output is not None and voice_turn.output.provider_id is not None
                        else ""
                    ),
                },
            )
            exchange = GatewayExchange(
                route=exchange.route,
                delivery=replace(exchange.delivery, outbound=outbound),
            )
        return GatewayVoiceExchange(
            exchange=exchange,
            input_resolution=resolution,
            voice_turn=voice_turn,
        )

    def _build_voice_service(self):
        return build_provider_voice_service(provider_profile=self.provider_profile)

    def _ensure_runtime_session(self, session: SessionState) -> SessionState:
        existing = self.repository.load_session(session.session_id)
        if existing is None:
            resolved = session
        else:
            resolved = replace(
                existing,
                workspace_id=session.workspace_id,
                status=session.status,
                updated_at=session.updated_at,
                interruption_state=session.interruption_state,
            )
        self.repository.upsert_session(resolved)
        return resolved

    def _event_for_inbound(
        self,
        inbound: GatewayInboundMessage,
        *,
        session_id: str,
    ) -> EventEnvelope:
        payload = {
            "message": inbound.body,
            "content": inbound.body,
            "summary": inbound.body,
            "adapter_id": inbound.adapter_id,
            "account_id": inbound.account_id,
            "delivery_surface": inbound.account.surface or "",
            "conversation_id": inbound.conversation_id,
            "parent_conversation_id": inbound.parent_conversation_id or "",
            "thread_id": inbound.thread_id or "",
            "chat_type": inbound.chat_type or "",
            "external_user_id": inbound.external_user_id,
            "display_name": inbound.display_name or "",
            "attachments": ",".join(inbound.attachments),
            **_string_payload(inbound.metadata),
        }
        return EventEnvelope(
            event_id=f"gateway:{inbound.event_id}",
            event_type="turn.received",
            session_id=session_id,
            source=f"gateway:{inbound.adapter_id}",
            payload=payload,
        )


@dataclass(frozen=True, slots=True)
class GatewayVoiceExchange:
    exchange: GatewayExchange
    input_resolution: VoiceInputResolution
    voice_turn: VoiceTurnResult


@dataclass(frozen=True, slots=True)
class ChatBotMessagingAdapter:
    app: GatewayApp
    adapter_id: str = CHAT_BOT_ADAPTER_ID

    def receive_text(
        self,
        *,
        conversation_id: str,
        external_user_id: str,
        body: str,
        account_id: str = DEFAULT_GATEWAY_ACCOUNT_ID,
        display_name: str | None = None,
        event_id: str | None = None,
        attachments: tuple[str, ...] = (),
        metadata: Mapping[str, object] | None = None,
        reply_body: str | None = None,
        target_trusted: bool = True,
        consent_given: bool = True,
        is_external: bool = False,
    ) -> GatewayExchange:
        attachment_refs = _attachment_refs(attachments)
        inbound_metadata = _object_map(metadata)
        inbound = GatewayInboundMessage(
            event_id=event_id or f"{self.adapter_id}:{conversation_id}:{external_user_id}",
            account=_account_ref(
                self.adapter_id,
                account_id=account_id,
                surface="local-chat",
            ),
            conversation=_conversation_ref(
                conversation_id,
                chat_type="direct",
            ),
            sender=_sender_ref(
                external_user_id,
                display_name=display_name,
            ),
            body=body,
            attachment_refs=attachment_refs,
            policy_hint=_policy_hint(
                target_trusted_default=target_trusted,
                consent_default=consent_given,
                is_external_default=is_external,
                audience_scope="direct",
            ),
            metadata=inbound_metadata,
        )
        return self.app.handle_message(
            inbound,
            reply_body=reply_body,
            attachment_refs=attachment_refs,
            metadata={
                "channel": "chat-bot",
                **inbound_metadata,
            },
        )

    def receive_voice(
        self,
        *,
        conversation_id: str,
        external_user_id: str,
        audio_bytes: bytes,
        audio_name: str,
        account_id: str = DEFAULT_GATEWAY_ACCOUNT_ID,
        audio_format: str | None = None,
        display_name: str | None = None,
        event_id: str | None = None,
        attachments: tuple[str, ...] = (),
        metadata: Mapping[str, object] | None = None,
        reply_body: str | None = None,
        target_trusted: bool = True,
        consent_given: bool = True,
        is_external: bool = False,
        voice_output_enabled: bool = False,
        output_audio_format: str = "mp3",
    ) -> GatewayVoiceExchange:
        attachment_refs = _attachment_refs(attachments)
        inbound_metadata = _object_map(metadata)
        inbound = GatewayInboundMessage(
            event_id=event_id or f"{self.adapter_id}:{conversation_id}:{external_user_id}:voice",
            account=_account_ref(
                self.adapter_id,
                account_id=account_id,
                surface="local-chat",
            ),
            conversation=_conversation_ref(
                conversation_id,
                chat_type="direct",
            ),
            sender=_sender_ref(
                external_user_id,
                display_name=display_name,
            ),
            body="voice-input",
            attachment_refs=attachment_refs,
            policy_hint=_policy_hint(
                target_trusted_default=target_trusted,
                consent_default=consent_given,
                is_external_default=is_external,
                audience_scope="direct",
            ),
            metadata=inbound_metadata,
        )
        return self.app.handle_voice_message(
            inbound,
            audio_bytes=audio_bytes,
            audio_name=audio_name,
            audio_format=audio_format,
            reply_body=reply_body,
            attachment_refs=attachment_refs,
            metadata={
                "channel": "chat-bot",
                **inbound_metadata,
            },
            voice_output_enabled=voice_output_enabled,
            output_audio_format=output_audio_format,
        )


@dataclass(frozen=True, slots=True)
class WebhookMessagingAdapter:
    app: GatewayApp
    adapter_id: str = WEBHOOK_ADAPTER_ID

    def receive_event(
        self,
        payload: Mapping[str, object],
        *,
        reply_body: str | None = None,
        target_trusted: bool = True,
        consent_given: bool = True,
        is_external: bool = False,
    ) -> GatewayExchange:
        attachments = tuple(str(item) for item in payload.get("attachments", ()))
        attachment_refs = _attachment_refs(attachments)
        inbound_metadata = {
            "channel": "webhook",
            **_object_map(payload.get("metadata")),
        }
        inbound = GatewayInboundMessage(
            event_id=str(payload.get("event_id") or payload.get("message_id") or payload["conversation_id"]),
            account=_account_ref(
                self.adapter_id,
                account_id=str(payload.get("account_id") or DEFAULT_GATEWAY_ACCOUNT_ID),
                tenant_id=(
                    str(payload["tenant_id"])
                    if payload.get("tenant_id") is not None
                    else None
                ),
                surface="generic-webhook",
            ),
            conversation=_conversation_ref(
                str(payload["conversation_id"]),
                chat_type=str(payload.get("chat_type") or "external"),
            ),
            sender=_sender_ref(
                str(payload["external_user_id"]),
                display_name=(
                    str(payload["display_name"])
                    if payload.get("display_name") is not None
                    else None
                ),
            ),
            body=str(payload["body"]),
            reply_to_message_id=(
                str(payload["reply_to_message_id"])
                if payload.get("reply_to_message_id") is not None
                else (
                    str(payload["reply_to_event_id"])
                    if payload.get("reply_to_event_id") is not None
                    else None
                )
            ),
            attachment_refs=attachment_refs,
            policy_hint=_policy_hint(
                target_trusted_default=target_trusted,
                consent_default=consent_given,
                is_external_default=is_external,
                audience_scope=str(payload.get("chat_type") or "external"),
            ),
            metadata=inbound_metadata,
        )
        response_metadata = {
            "channel": "webhook",
            **_object_map(payload.get("metadata")),
        }
        callback_url = payload.get("callback_url")
        if callback_url is not None:
            response_metadata["callback_url"] = str(callback_url)
        return self.app.handle_message(
            inbound,
            reply_body=reply_body,
            reply_to_message_id=inbound.reply_to_message_id or inbound.event_id,
            attachment_refs=inbound.attachment_refs,
            metadata=response_metadata,
        )

    def receive_voice_event(
        self,
        payload: Mapping[str, object],
        *,
        reply_body: str | None = None,
        target_trusted: bool = True,
        consent_given: bool = True,
        is_external: bool = False,
        voice_output_enabled: bool = False,
        output_audio_format: str = "mp3",
    ) -> GatewayVoiceExchange:
        attachments = tuple(str(item) for item in payload.get("attachments", ()))
        attachment_refs = _attachment_refs(attachments)
        inbound_metadata = {
            "channel": "webhook",
            **_object_map(payload.get("metadata")),
        }
        inbound = GatewayInboundMessage(
            event_id=str(payload.get("event_id") or payload.get("message_id") or payload["conversation_id"]),
            account=_account_ref(
                self.adapter_id,
                account_id=str(payload.get("account_id") or DEFAULT_GATEWAY_ACCOUNT_ID),
                tenant_id=(
                    str(payload["tenant_id"])
                    if payload.get("tenant_id") is not None
                    else None
                ),
                surface="generic-webhook",
            ),
            conversation=_conversation_ref(
                str(payload["conversation_id"]),
                chat_type=str(payload.get("chat_type") or "external"),
            ),
            sender=_sender_ref(
                str(payload["external_user_id"]),
                display_name=(
                    str(payload["display_name"])
                    if payload.get("display_name") is not None
                    else None
                ),
            ),
            body="voice-input",
            reply_to_message_id=(
                str(payload["reply_to_message_id"])
                if payload.get("reply_to_message_id") is not None
                else (
                    str(payload["reply_to_event_id"])
                    if payload.get("reply_to_event_id") is not None
                    else None
                )
            ),
            attachment_refs=attachment_refs,
            policy_hint=_policy_hint(
                target_trusted_default=target_trusted,
                consent_default=consent_given,
                is_external_default=is_external,
                audience_scope=str(payload.get("chat_type") or "external"),
            ),
            metadata=inbound_metadata,
        )
        response_metadata = {
            "channel": "webhook",
            **_object_map(payload.get("metadata")),
        }
        callback_url = payload.get("callback_url")
        if callback_url is not None:
            response_metadata["callback_url"] = str(callback_url)
        return self.app.handle_voice_message(
            inbound,
            audio_bytes=bytes(payload["audio_bytes"]),
            audio_name=str(payload.get("audio_name") or "voice-input.wav"),
            audio_format=str(payload.get("audio_format")) if payload.get("audio_format") is not None else None,
            reply_body=reply_body,
            reply_to_message_id=inbound.reply_to_message_id or inbound.event_id,
            attachment_refs=inbound.attachment_refs,
            metadata=response_metadata,
            voice_output_enabled=voice_output_enabled,
            output_audio_format=output_audio_format,
        )


@dataclass(frozen=True, slots=True)
class TelegramMessagingAdapter:
    app: GatewayApp
    adapter_id: str = TELEGRAM_ADAPTER_ID

    def receive_update(
        self,
        payload: Mapping[str, object],
        *,
        account_id: str = DEFAULT_GATEWAY_ACCOUNT_ID,
        reply_body: str | None = None,
        target_trusted: bool | None = None,
        consent_given: bool | None = None,
        is_external: bool | None = None,
    ) -> GatewayExchange:
        update_kind = "message"
        message = payload.get("message")
        callback_data: str | None = None
        if not isinstance(message, Mapping):
            message = payload.get("edited_message")
            if isinstance(message, Mapping):
                update_kind = "edited_message"
        if not isinstance(message, Mapping):
            callback_query = payload.get("callback_query")
            if isinstance(callback_query, Mapping):
                nested_message = callback_query.get("message")
                if isinstance(nested_message, Mapping):
                    message = nested_message
                    update_kind = "callback_query"
                    if callback_query.get("data") is not None:
                        callback_data = str(callback_query["data"])
                    if not isinstance(message.get("from"), Mapping) and isinstance(
                        callback_query.get("from"), Mapping
                    ):
                        message = {
                            **message,
                            "from": callback_query["from"],
                        }
        if not isinstance(message, Mapping):
            raise ValueError("telegram update requires message, edited_message, or callback_query.message")
        chat = message.get("chat")
        sender = message.get("from")
        if not isinstance(chat, Mapping) or not isinstance(sender, Mapping):
            raise ValueError("telegram update requires chat and from payloads")
        chat_id = str(chat["id"])
        chat_type = str(chat.get("type") or "private")
        thread_id = message.get("message_thread_id")
        normalized_chat_type = _normalized_chat_type(chat_type)
        attachment_refs = _attachment_refs(_telegram_attachment_ids(message))
        message_id = (
            str(message["message_id"])
            if message.get("message_id") is not None
            else None
        )
        metadata = {
            "channel": "telegram",
            "chat_type": chat_type,
            "update_kind": update_kind,
            "chat_id": chat_id,
        }
        if message_id is not None:
            metadata["message_id"] = message_id
        if sender.get("username") is not None:
            metadata["username"] = str(sender["username"])
        if thread_id is not None:
            metadata["message_thread_id"] = str(thread_id)
        if message.get("reply_to_message") is not None:
            metadata["reply_to_message_id"] = str(
                dict(message["reply_to_message"]).get("message_id") or ""
            )
        if callback_data is not None:
            metadata["callback_data"] = callback_data
        target_trusted_default, consent_default, external_default = _telegram_delivery_defaults(chat_type)
        resolved_thread_id = str(thread_id) if thread_id is not None else None
        inbound = GatewayInboundMessage(
            event_id=str(payload.get("update_id") or message.get("message_id") or chat["id"]),
            account=_account_ref(
                self.adapter_id,
                account_id=account_id,
                surface="telegram-bot-api",
            ),
            conversation=_conversation_ref(
                _telegram_conversation_id(chat_id, thread_id),
                parent_conversation_id=chat_id if resolved_thread_id is not None else None,
                thread_id=resolved_thread_id,
                chat_type=normalized_chat_type,
                metadata={"raw_chat_type": chat_type},
            ),
            sender=_sender_ref(
                str(sender["id"]),
                display_name=_telegram_display_name(sender),
                username=(
                    f"@{str(sender['username'])}"
                    if sender.get("username") is not None
                    else None
                ),
                is_bot=bool(sender.get("is_bot", False)),
            ),
            body=str(message.get("text") or message.get("caption") or callback_data or "telegram-event"),
            reply_to_message_id=(
                str(metadata.get("reply_to_message_id") or message_id or "") or None
            ),
            attachment_refs=attachment_refs,
            policy_hint=_policy_hint(
                target_trusted_default=(
                    target_trusted_default if target_trusted is None else target_trusted
                ),
                consent_default=consent_default if consent_given is None else consent_given,
                is_external_default=external_default if is_external is None else is_external,
                audience_scope=normalized_chat_type,
                metadata={"raw_chat_type": chat_type},
            ),
            metadata=metadata,
        )
        return self.app.handle_message(
            inbound,
            reply_body=reply_body,
            reply_to_message_id=inbound.reply_to_message_id or inbound.event_id,
            attachment_refs=attachment_refs,
            metadata={
                **metadata,
                "delivery_surface": "telegram-bot-api",
            },
        )


@dataclass(frozen=True, slots=True)
class DiscordMessagingAdapter:
    app: GatewayApp
    adapter_id: str = DISCORD_ADAPTER_ID

    def normalize_event(
        self,
        payload: Mapping[str, object],
        *,
        account_id: str = DEFAULT_GATEWAY_ACCOUNT_ID,
        transport: str = "gateway",
        target_trusted: bool | None = None,
        consent_given: bool | None = None,
        is_external: bool | None = None,
    ) -> GatewayInboundMessage:
        message_id = str(payload.get("id") or "").strip()
        if not message_id:
            raise ValueError("discord event requires id")
        channel_id = str(payload.get("channel_id") or "").strip()
        if not channel_id:
            raise ValueError("discord event requires channel_id")
        author = payload.get("author")
        if not isinstance(author, Mapping):
            raise ValueError("discord event requires author payload")
        member = payload.get("member")
        if member is not None and not isinstance(member, Mapping):
            raise ValueError("discord event member payload must be an object when present")
        chat_type = _discord_chat_type(payload)
        thread_id = str(payload.get("thread_id") or "").strip() or None
        parent_conversation_id = str(payload.get("parent_id") or "").strip() or None
        if chat_type == "topic":
            thread_id = thread_id or channel_id
        else:
            thread_id = None
            parent_conversation_id = None
        conversation_id = thread_id or channel_id
        attachment_refs = _discord_attachment_refs(payload.get("attachments"))
        reply_reference = payload.get("message_reference")
        reply_to_message_id = None
        if isinstance(reply_reference, Mapping) and reply_reference.get("message_id") is not None:
            reply_to_message_id = str(reply_reference["message_id"])
        elif payload.get("reply_to_message_id") is not None:
            reply_to_message_id = str(payload["reply_to_message_id"])
        target_trusted_default, consent_default, external_default = _discord_delivery_defaults(chat_type)
        metadata = {
            "channel": "discord",
            "guild_id": str(payload.get("guild_id") or ""),
            "channel_id": channel_id,
            "chat_type": chat_type,
            "transport": transport,
        }
        if parent_conversation_id is not None:
            metadata["parent_id"] = parent_conversation_id
        if thread_id is not None:
            metadata["thread_id"] = thread_id
        return GatewayInboundMessage(
            event_id=message_id,
            account=_account_ref(
                self.adapter_id,
                account_id=account_id,
                surface=f"discord-{transport}",
                metadata={"event_transport": transport},
            ),
            conversation=_conversation_ref(
                conversation_id,
                parent_conversation_id=parent_conversation_id,
                thread_id=thread_id,
                chat_type=chat_type,
                metadata={
                    "channel_id": channel_id,
                },
            ),
            sender=_sender_ref(
                str(author.get("id") or ""),
                display_name=_discord_display_name(author, member=member),
                username=(
                    f"@{str(author['username'])}"
                    if author.get("username") is not None
                    else None
                ),
                is_bot=bool(author.get("bot", False)),
                metadata={"global_name": str(author.get("global_name") or "")},
            ),
            body=_discord_body(payload),
            reply_to_message_id=reply_to_message_id,
            attachment_refs=attachment_refs,
            policy_hint=_policy_hint(
                target_trusted_default=(
                    target_trusted_default if target_trusted is None else target_trusted
                ),
                consent_default=consent_default if consent_given is None else consent_given,
                is_external_default=external_default if is_external is None else is_external,
                audience_scope=chat_type,
                metadata={"chat_type": chat_type},
            ),
            metadata=metadata,
        )

    def receive_event(
        self,
        payload: Mapping[str, object],
        *,
        account_id: str = DEFAULT_GATEWAY_ACCOUNT_ID,
        transport: str = "gateway",
        reply_body: str | None = None,
        target_trusted: bool | None = None,
        consent_given: bool | None = None,
        is_external: bool | None = None,
    ) -> GatewayExchange:
        inbound = self.normalize_event(
            payload,
            account_id=account_id,
            transport=transport,
            target_trusted=target_trusted,
            consent_given=consent_given,
            is_external=is_external,
        )
        return self.app.handle_message(
            inbound,
            reply_body=reply_body,
            reply_to_message_id=inbound.reply_to_message_id or inbound.event_id,
            attachment_refs=inbound.attachment_refs,
            metadata={
                **dict(inbound.metadata),
                "delivery_surface": inbound.account.surface or f"discord-{transport}",
            },
        )

    def build_reply_request(self, outbound: GatewayOutboundMessage) -> Mapping[str, object]:
        if outbound.adapter_id != self.adapter_id:
            raise ValueError("discord reply request requires a discord outbound message")
        return _discord_reply_request(outbound)


@dataclass(frozen=True, slots=True)
class FeishuMessagingAdapter:
    app: GatewayApp
    adapter_id: str = FEISHU_ADAPTER_ID

    def normalize_event(
        self,
        payload: Mapping[str, object],
        *,
        account_id: str | None = None,
        transport: str = "long-connection",
        target_trusted: bool | None = None,
        consent_given: bool | None = None,
        is_external: bool | None = None,
    ) -> GatewayInboundMessage:
        header = payload.get("header")
        if not isinstance(header, Mapping):
            raise ValueError("feishu event requires a header payload")
        event = payload.get("event")
        if not isinstance(event, Mapping):
            raise ValueError("feishu event requires an event payload")
        sender = event.get("sender")
        message = event.get("message")
        if not isinstance(sender, Mapping) or not isinstance(message, Mapping):
            raise ValueError("feishu event requires sender and message payloads")

        event_type = str(header.get("event_type") or "")
        if event_type and event_type != "im.message.receive_v1":
            raise ValueError(f"unsupported feishu event type: {event_type}")

        tenant_key = (
            str(header["tenant_key"])
            if header.get("tenant_key") is not None
            else (
                str(event["tenant_key"])
                if event.get("tenant_key") is not None
                else None
            )
        )
        resolved_account_id = account_id or (
            str(header["app_id"])
            if header.get("app_id") is not None
            else DEFAULT_GATEWAY_ACCOUNT_ID
        )

        chat_id = str(message.get("chat_id") or "")
        if not chat_id:
            raise ValueError("feishu message payload requires chat_id")
        chat_type = str(message.get("chat_type") or "group")
        normalized_chat_type = _normalized_chat_type(chat_type)
        message_id = str(message.get("message_id") or header.get("event_id") or "")
        if not message_id:
            raise ValueError("feishu message payload requires message_id")
        root_id = (
            str(message["root_id"])
            if message.get("root_id") is not None and str(message["root_id"]).strip()
            else None
        )
        parent_id = (
            str(message["parent_id"])
            if message.get("parent_id") is not None and str(message["parent_id"]).strip()
            else None
        )
        message_type = str(message.get("message_type") or "text")
        content = _feishu_message_content(message.get("content"))
        attachment_refs = _feishu_attachment_refs(content)
        conversation_id = f"{chat_id}:{root_id}" if root_id is not None else chat_id
        transport_label = str(transport or "event-subscription").strip() or "event-subscription"

        inbound_metadata = {
            "channel": "feishu",
            "event_type": event_type or "im.message.receive_v1",
            "chat_id": chat_id,
            "chat_type": chat_type,
            "message_type": message_type,
            "message_id": message_id,
            "tenant_key": tenant_key or "",
        }
        if root_id is not None:
            inbound_metadata["root_id"] = root_id
        if parent_id is not None:
            inbound_metadata["parent_id"] = parent_id
        mentions = event.get("mentions")
        if isinstance(mentions, list):
            inbound_metadata["mention_count"] = len(mentions)

        target_trusted_default = chat_type == "p2p"
        consent_default = chat_type == "p2p"
        external_default = chat_type != "p2p"
        inbound = GatewayInboundMessage(
            event_id=message_id,
            account=_account_ref(
                self.adapter_id,
                account_id=resolved_account_id,
                tenant_id=tenant_key,
                surface=f"feishu-{transport_label}",
                metadata={"event_transport": transport_label},
            ),
            conversation=_conversation_ref(
                conversation_id,
                parent_conversation_id=chat_id if root_id is not None else None,
                thread_id=root_id,
                chat_type=normalized_chat_type,
                metadata={
                    "raw_chat_type": chat_type,
                    "message_id": message_id,
                },
            ),
            sender=_sender_ref(
                _feishu_sender_user_id(sender),
                display_name=_feishu_display_name(sender),
                is_bot=str(sender.get("sender_type") or "user") != "user",
                metadata={
                    "sender_type": str(sender.get("sender_type") or "user"),
                    "tenant_key": (
                        str(sender["tenant_key"])
                        if sender.get("tenant_key") is not None
                        else ""
                    ),
                },
            ),
            body=_feishu_message_body(message_type, content),
            reply_to_message_id=parent_id or root_id or message_id,
            attachment_refs=attachment_refs,
            policy_hint=_policy_hint(
                target_trusted_default=(
                    target_trusted_default if target_trusted is None else target_trusted
                ),
                consent_default=consent_default if consent_given is None else consent_given,
                is_external_default=external_default if is_external is None else is_external,
                audience_scope=normalized_chat_type,
                metadata={
                    "raw_chat_type": chat_type,
                    "tenant_key": tenant_key or "",
                },
            ),
            metadata=inbound_metadata,
        )
        return inbound

    def receive_event(
        self,
        payload: Mapping[str, object],
        *,
        account_id: str | None = None,
        transport: str = "long-connection",
        reply_body: str | None = None,
        target_trusted: bool | None = None,
        consent_given: bool | None = None,
        is_external: bool | None = None,
    ) -> GatewayExchange:
        inbound = self.normalize_event(
            payload,
            account_id=account_id,
            transport=transport,
            target_trusted=target_trusted,
            consent_given=consent_given,
            is_external=is_external,
        )
        return self.app.handle_message(
            inbound,
            reply_body=reply_body,
            reply_to_message_id=inbound.event_id,
            attachment_refs=inbound.attachment_refs,
            metadata={
                **dict(inbound.metadata),
                "delivery_surface": inbound.account.surface or f"feishu-{transport}",
            },
        )

    def build_reply_request(self, outbound: GatewayOutboundMessage) -> Mapping[str, object]:
        if outbound.adapter_id != self.adapter_id:
            raise ValueError("feishu reply request requires a feishu outbound message")
        return _feishu_reply_request(outbound)


def register_builtin_gateway_adapters(registry: GatewayPluginRegistry) -> GatewayPluginRegistry:
    registry.register_adapter(
        GatewayAdapterDescriptor(
            key="chat_bot",
            adapter_id=CHAT_BOT_ADAPTER_ID,
            surface="local-chat",
            default_account_id=DEFAULT_GATEWAY_ACCOUNT_ID,
            operator_action="none",
        ),
        factory=lambda app: ChatBotMessagingAdapter(app=app),
    )
    registry.register_adapter(
        GatewayAdapterDescriptor(
            key="webhook",
            adapter_id=WEBHOOK_ADAPTER_ID,
            surface="generic-webhook",
            default_account_id=DEFAULT_GATEWAY_ACCOUNT_ID,
            operator_action="supply callback_url in inbound payload",
        ),
        factory=lambda app: WebhookMessagingAdapter(app=app),
    )
    registry.register_adapter(
        GatewayAdapterDescriptor(
            key="telegram",
            adapter_id=TELEGRAM_ADAPTER_ID,
            surface="telegram-bot-api",
            default_account_id=DEFAULT_GATEWAY_ACCOUNT_ID,
            operator_action="configure TELEGRAM_BOT_TOKEN and forward Bot API updates into the gateway",
            identity_mapping="account_id + chat.id + from.id (+ message_thread_id when present)",
            supported_updates=("message", "edited_message", "callback_query"),
            delivery_defaults={
                "private": "allow",
                "group": "review",
                "supergroup": "review",
                "channel": "review",
            },
        ),
        factory=lambda app: TelegramMessagingAdapter(app=app),
    )
    registry.register_adapter(
        GatewayAdapterDescriptor(
            key="discord",
            adapter_id=DISCORD_ADAPTER_ID,
            surface="discord-gateway",
            default_account_id=DEFAULT_GATEWAY_ACCOUNT_ID,
            operator_action="configure AEGIS_DISCORD_BOT_TOKEN, enable the MESSAGE_CONTENT intent, and run the managed Discord gateway service",
            identity_mapping="account_id + channel_id + author.id (+ thread_id when present)",
            preferred_transport="gateway",
            implemented_transports=("discord.py-gateway",),
            supported_events=("MESSAGE_CREATE", "THREAD_CREATE", "THREAD_UPDATE"),
            delivery_defaults={
                "direct": "allow",
                "channel": "review",
                "topic": "review",
            },
            delivery_api="/channels/{channel_id}/messages",
        ),
        factory=lambda app: DiscordMessagingAdapter(app=app),
    )
    registry.register_adapter(
        GatewayAdapterDescriptor(
            key="feishu",
            adapter_id=FEISHU_ADAPTER_ID,
            surface="feishu-messaging",
            default_account_id=DEFAULT_GATEWAY_ACCOUNT_ID,
            operator_action="configure gateway.adapters.feishu account env refs for the SDK long-connection path used by im.message.receive_v1",
            identity_mapping="account_id + chat_id + sender_id (+ root_id when replying in thread)",
            preferred_transport="long-connection",
            implemented_transports=(
                "python-sdk-long-connection",
            ),
            supported_events=("im.message.receive_v1",),
            delivery_defaults={
                "p2p": "allow",
                "group": "review",
            },
            delivery_api="/open-apis/im/v1/messages/:message_id/reply",
        ),
        factory=lambda app: FeishuMessagingAdapter(app=app),
    )
    return registry


def _builtin_gateway_plugin_registry() -> GatewayPluginRegistry:
    registry = GatewayPluginRegistry()
    return register_builtin_gateway_adapters(registry)


def build_gateway_app(
    *,
    profile_id: str = "profile:default",
    workspace_id: str | None = None,
    provider_profile: Mapping[str, Any] | None = None,
    profile_dir: str | Path | None = None,
    state_dir: str | Path | None = None,
    runtime_environ: Mapping[str, str] | None = None,
    plugin_registry: GatewayPluginRegistry | None = None,
) -> tuple[GatewayApp, ChatBotMessagingAdapter, WebhookMessagingAdapter]:
    registry = plugin_registry or _builtin_gateway_plugin_registry()
    resolved_profile_dir = Path(profile_dir) if profile_dir is not None else None
    resolved_state_dir = Path(state_dir) if state_dir is not None else None
    loaded_profile: LoadedProfile | None = None

    if resolved_profile_dir is not None:
        loader = ProfileLoader(resolved_profile_dir)
        loaded_profile = (
            loader.load()
            if profile_id == "profile:default"
            else loader.load(profile_id=profile_id)
        )
        profile_id = loaded_profile.state.profile_id
    else:
        loaded_profile = _default_loaded_profile(profile_id)

    if resolved_state_dir is None:
        identity_store = InMemoryGatewayIdentityStore()
        session_store = InMemoryGatewaySessionStore()
    else:
        identity_store = FileGatewayIdentityStore(
            resolved_state_dir / "gateway-identities.json"
        )
        session_store = FileGatewaySessionStore(
            resolved_state_dir / "gateway-sessions.json"
        )

    telemetry = GatewayTelemetrySink()
    core = GatewayCoreService(
        GatewayCoreDependencies(
            identity_store=identity_store,
            session_store=session_store,
            security_policy=SecurityPolicy.default(),
            default_profile_id=profile_id,
            default_workspace_id=workspace_id,
            telemetry_sink=telemetry,
        )
    )
    runtime_repository = RuntimeStorageRepository(_runtime_database_path(resolved_state_dir))
    runtime_repository.bootstrap()
    runtime_repository.upsert_profile(loaded_profile.state)
    auth_store = PersistentAuthProfileStore(runtime_repository)

    resolved_provider_profile = provider_profile
    loaded_provider_profile: AuthProfile | None = None
    if resolved_provider_profile is None and resolved_profile_dir is not None:
        loaded_provider_profile = load_provider_profile(resolved_profile_dir)
        if loaded_provider_profile is not None:
            provider_runtime = provider_profile_summary(loaded_provider_profile)
        else:
            provider_runtime = provider_fallback_summary()
    elif resolved_provider_profile is None:
        provider_runtime = provider_fallback_summary()
    else:
        loaded_provider_profile = provider_profile_from_payload(resolved_provider_profile)
        provider_runtime = provider_profile_summary(loaded_provider_profile)
    if loaded_provider_profile is not None:
        auth_store.register(loaded_provider_profile)

    preview_model_provider = GatewayPreviewModelProvider()
    model_provider = GatewaySurfaceModelProvider(
        repository=runtime_repository,
        fallback=preview_model_provider,
        active_provider_profile=loaded_provider_profile,
        runtime_environ=runtime_environ,
    )
    memory_runtime = MemoryRuntime.from_repository(runtime_repository)
    kernel = KernelService(
        dependencies=KernelDependencies(
            storage=runtime_repository,
            context=GatewayContextCapability(loaded_profile),
            planning=GatewayPlanningCapability(PlanningService()),
            memory=GatewayMemoryCapability(memory_runtime),
            model_provider=model_provider,
            telemetry=telemetry,
        )
    )

    app = GatewayApp(
        core=core,
        profile_id=profile_id,
        workspace_id=workspace_id,
        provider_runtime=provider_runtime,
        repository=runtime_repository,
        auth_store=auth_store,
        memory_runtime=memory_runtime,
        kernel=kernel,
        telemetry=telemetry,
        model_provider=model_provider,
        plugin_registry=registry,
        profile_dir=str(resolved_profile_dir) if resolved_profile_dir is not None else None,
        state_dir=str(resolved_state_dir) if resolved_state_dir is not None else None,
        loaded_profile=loaded_profile,
        provider_profile=loaded_provider_profile,
    )
    chat_adapter = registry.create_adapter("chat_bot", app)
    webhook_adapter = registry.create_adapter("webhook", app)
    if not isinstance(chat_adapter, ChatBotMessagingAdapter):
        raise TypeError("gateway adapter plugin 'chat_bot' must build ChatBotMessagingAdapter")
    if not isinstance(webhook_adapter, WebhookMessagingAdapter):
        raise TypeError("gateway adapter plugin 'webhook' must build WebhookMessagingAdapter")
    return (
        app,
        chat_adapter,
        webhook_adapter,
    )
