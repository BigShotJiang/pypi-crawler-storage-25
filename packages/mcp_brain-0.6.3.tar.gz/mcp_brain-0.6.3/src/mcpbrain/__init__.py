"""MCP: Multi-agent Cognitive Processing Framework."""

__version__ = "0.5.0"
