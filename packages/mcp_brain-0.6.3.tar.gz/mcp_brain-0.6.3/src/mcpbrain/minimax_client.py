"""MiniMax AI API client."""

import json
import os
import requests
from typing import Optional, List, Dict, Any, Iterator, Union


class MiniMaxError(Exception):
    """Raised when MiniMax API returns an error."""
    pass


class MiniMaxClient:
    """Client for MiniMax Chat API."""

    def __init__(self, api_key: Optional[str] = None, base_url: str = "https://api.minimax.io/v1"):
        self.api_key = api_key or os.environ.get("MINIMAX_API_KEY")
        if not self.api_key:
            raise ValueError("MiniMax API key not found. Set MINIMAX_API_KEY env var or pass api_key.")
        self.base_url = base_url.rstrip("/")
        self._session = requests.Session()
        self._session.headers.update({
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        })

    def generate(
        self,
        prompt: str,
        model: str = "MiniMax-M2.7",
        max_tokens: int = 2000,
        temperature: float = 0.7,
        tools: Optional[list] = None,
    ) -> str:
        """Generate a response from MiniMax."""
        messages = [{"role": "user", "content": prompt}]
        payload = {
            "model": model,
            "messages": messages,
            "max_tokens": max_tokens,
            "temperature": temperature,
        }
        if tools:
            payload["tools"] = tools

        resp = self._session.post(
            f"{self.base_url}/chat/completions",
            json=payload,
            timeout=120,
        )

        if resp.status_code != 200:
            raise MiniMaxError(f"API Error {resp.status_code}: {resp.text}")

        result = resp.json()
        return result["choices"][0]["message"]["content"]

    def generate_stream(
        self,
        prompt: str,
        model: str = "MiniMax-M2.7",
        max_tokens: int = 2000,
        temperature: float = 0.7,
        tools: Optional[List[Dict[str, Any]]] = None,
    ) -> Iterator[Union[str, Dict[str, Any]]]:
        """Stream a response from MiniMax.

        When tools are provided, yields dicts with type info to support tool_calls:
            {"type": "token", "content": "..."}
            {"type": "tool_call", "name": "skill_view", "arguments": "{\"skill_name\": \"llm-wiki\"}"}

        When tools are NOT provided, yields plain strings (backward compatible).
        """
        messages = [{"role": "user", "content": prompt}]
        payload = {
            "model": model,
            "messages": messages,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "stream": True,
        }
        if tools:
            payload["tools"] = tools

        resp = self._session.post(
            f"{self.base_url}/chat/completions",
            json=payload,
            stream=True,
            timeout=120,
        )

        if resp.status_code != 200:
            raise MiniMaxError(f"API Error {resp.status_code}: {resp.text}")

        # Accumulate tool_call chunks by index (OpenAI streams tool_calls piecemeal)
        pending_tool_calls: Dict[int, Dict[str, Any]] = {}
        emit_dicts = tools is not None  # yield dicts when tools are present

        for line in resp.iter_lines():
            if line:
                line = line.decode("utf-8")
                if line.startswith("data: "):
                    data = line[6:]
                    if data.strip() == "[DONE]":
                        # Emit any accumulated tool_calls before finishing
                        for tc in sorted(pending_tool_calls.values(), key=lambda x: x.get("index", 0)):
                            yield tc
                        break
                    try:
                        chunk = json.loads(data)
                    except json.JSONDecodeError:
                        continue
                    
                    delta = chunk.get("choices", [{}])[0].get("delta", {})
                    finish_reason = chunk.get("choices", [{}])[0].get("finish_reason")

                    # Check for tool_calls in delta (OpenAI / MiniMax format)
                    if "tool_calls" in delta:
                        for tc in delta["tool_calls"]:
                            idx = tc.get("index", 0)
                            fn = tc.get("function", {})
                            name = fn.get("name")
                            args = fn.get("arguments", "")

                            if idx not in pending_tool_calls:
                                pending_tool_calls[idx] = {
                                    "type": "tool_call",
                                    "index": idx,
                                    "name": name,
                                    "arguments": "",
                                }
                            if name:
                                pending_tool_calls[idx]["name"] = name
                            if args:
                                pending_tool_calls[idx]["arguments"] += args
                    
                    elif "content" in delta and delta["content"]:
                        content = delta["content"]
                        if emit_dicts:
                            yield {"type": "token", "content": content}
                        else:
                            yield content
                    
                    # Emit accumulated tool_calls when finish_reason indicates completion
                    # (MiniMax may not send [DONE] after tool_calls)
                    if finish_reason in ("tool_calls", "stop"):
                        for tc in sorted(pending_tool_calls.values(), key=lambda x: x.get("index", 0)):
                            yield tc
                        pending_tool_calls.clear()
                        if finish_reason == "tool_calls":
                            break

    def generate_stream_from_messages(
        self,
        messages: List[Dict[str, str]],
        model: str = "MiniMax-M2.7",
        max_tokens: int = 2000,
        temperature: float = 0.7,
        tools: Optional[List[Dict[str, Any]]] = None,
    ) -> Iterator[Union[str, Dict[str, Any]]]:
        """Stream a response from MiniMax using a full messages array.

        Unlike generate_stream() which wraps a single prompt string in [user] role,
        this sends the messages directly — preserving system role, history, etc.

        When tools are provided, yields dicts with type info:
            {"type": "token", "content": "..."}
            {"type": "tool_call", "name": "...", "arguments": "{...}"}

        When tools are NOT provided, yields plain strings (backward compatible).
        """
        payload = {
            "model": model,
            "messages": messages,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "stream": True,
        }
        if tools:
            payload["tools"] = tools

        resp = self._session.post(
            f"{self.base_url}/chat/completions",
            json=payload,
            stream=True,
            timeout=120,
        )

        if resp.status_code != 200:
            raise MiniMaxError(f"API Error {resp.status_code}: {resp.text}")

        pending_tool_calls: Dict[int, Dict[str, Any]] = {}
        emit_dicts = tools is not None

        for line in resp.iter_lines():
            if line:
                line = line.decode("utf-8")
                if line.startswith("data: "):
                    data = line[6:]
                    if data.strip() == "[DONE]":
                        for tc in sorted(pending_tool_calls.values(), key=lambda x: x.get("index", 0)):
                            yield tc
                        break
                    try:
                        chunk = json.loads(data)
                    except json.JSONDecodeError:
                        continue

                    delta = chunk.get("choices", [{}])[0].get("delta", {})
                    finish_reason = chunk.get("choices", [{}])[0].get("finish_reason")

                    if "tool_calls" in delta:
                        for tc in delta["tool_calls"]:
                            idx = tc.get("index", 0)
                            fn = tc.get("function", {})
                            name = fn.get("name")
                            args = fn.get("arguments", "")

                            if idx not in pending_tool_calls:
                                pending_tool_calls[idx] = {
                                    "type": "tool_call",
                                    "index": idx,
                                    "name": name,
                                    "arguments": "",
                                }
                            if name:
                                pending_tool_calls[idx]["name"] = name
                            if args:
                                pending_tool_calls[idx]["arguments"] += args

                    elif "content" in delta and delta["content"]:
                        content = delta["content"]
                        if emit_dicts:
                            yield {"type": "token", "content": content}
                        else:
                            yield content

                    if finish_reason in ("tool_calls", "stop"):
                        for tc in sorted(pending_tool_calls.values(), key=lambda x: x.get("index", 0)):
                            yield tc
                        pending_tool_calls.clear()
                        if finish_reason == "tool_calls":
                            break

    # Known MiniMax chat models (fallback when /v1/models is unavailable)
    KNOWN_MODELS = [
        "MiniMax-M2.7",
        "MiniMax-M2",
        "MiniMax-M2.5",
    ]

    def list_models(self) -> List[Dict[str, Any]]:
        """List available models — tries /v1/models, falls back to known models."""
        try:
            resp = self._session.get(
                f"{self.base_url}/models",
                timeout=15,
            )
            if resp.status_code == 200:
                data = resp.json()
                return data.get("data", [])
        except Exception:
            pass
        # Fallback: return known models as synthetic entries
        return [{"id": m, "object": "model"} for m in self.KNOWN_MODELS]
