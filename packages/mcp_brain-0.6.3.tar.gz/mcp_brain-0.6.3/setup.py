from setuptools import setup, find_packages

setup(
    name="mcp-brain",
    version="0.6.3",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    install_requires=[
        "requests>=2.25.0",
        "rich>=10.0.0",
        "click>=8.0.0",
        "mcp[cli]>=1.0.0",
        "fastapi>=0.100.0",
        "uvicorn>=0.23.0",
    ],
    entry_points={
        "console_scripts": [
            "mcp=mcpbrain.cli:main",
            "mcp-brain-server=mcpbrain.server:main",
            "mcp-brain-http=mcpbrain.http_server:main",
        ],
    },
    author="MC",
    description="Multi-agent Cognitive Processing Framework with MiniMax — CLI and MCP server",
    python_requires=">=3.8",
)
