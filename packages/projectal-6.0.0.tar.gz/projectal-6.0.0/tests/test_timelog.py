import projectal
from .base_test import BaseTest
from .common import CommonTester


class TestTimelog(BaseTest):
    def setUp(self):
        self.common = CommonTester(projectal.Timelog)
        self.staff = self.make_staff()
        self.project = self.make_project()
        self.task = self.make_task(self.project)
        self.activity = projectal.Activity.create({"name": "Timelog Activity"})

    def make_timelog_payload(self, suffix=""):
        return {
            "identifier": "timelog-{}".format(self.random()),
            "name": "Test Timelog{}".format(suffix),
            "clockIn": 1710115200000,
            "clockOut": 1710118800000,
            "duration": 60,
            "status": "Pending",
            "description": "Timelog created by API wrapper tests",
        }

    def create_timelog(self, suffix="", entity_ref=None):
        payload = self.make_timelog_payload(suffix)
        if entity_ref:
            payload["entityRef"] = entity_ref
        return projectal.Timelog.create(self.staff, payload)

    def test_crud(self):
        new = self.create_timelog()
        assert new["uuId"]
        assert new["staffRef"] == self.staff["uuId"]

        uuId = new["uuId"]
        entity = self.common.test_get(uuId)
        assert entity["staffRef"] == self.staff["uuId"]

        changed = {
            "uuId": uuId,
            "name": "Updated Timelog",
            "description": "Updated description",
            "duration": 120,
            "status": "Submitted",
        }
        self.common.test_update(old=entity, changed=changed)
        self.common.test_delete(uuId)

    def test_create_batch_sets_staff_ref(self):
        timelogs = projectal.Timelog.create(
            self.staff,
            [self.make_timelog_payload(" A"), self.make_timelog_payload(" B")],
        )

        assert len(timelogs) == 2
        assert all(timelog["staffRef"] == self.staff["uuId"] for timelog in timelogs)

        fetched = projectal.Timelog.get([timelog["uuId"] for timelog in timelogs])
        assert len(fetched) == 2
        assert all(timelog["staffRef"] == self.staff["uuId"] for timelog in fetched)

        projectal.Timelog.delete([timelog["uuId"] for timelog in timelogs])

    def test_link_file(self):
        timelog = self.create_timelog()
        file = projectal.File.create(b"testdata", {"name": "Timelog File"})
        timelog.link_file(file)
        timelog.unlink_file(file)

    def test_link_tag(self):
        timelog = self.create_timelog()
        tag = self.make_tag()
        timelog.link_tag(tag)
        timelog.unlink_tag(tag)

    def test_link_note(self):
        timelog = self.create_timelog()
        note = projectal.Note.create(timelog, {"text": "Timelog note"})
        assert len(timelog["noteList"]) == 1
        assert timelog["noteList"][0]["uuId"] == note["uuId"]

        timelog = projectal.Timelog.get(timelog["uuId"], links=["NOTE"])
        projectal.Note.create(timelog, {"text": "Timelog note 2"})
        assert len(timelog["noteList"]) == 2

    def test_attach_task(self):
        timelog = self.create_timelog(entity_ref=self.task["uuId"])
        assert timelog["entityRef"] == self.task["uuId"]

        task = projectal.Task.get(self.task["uuId"], links=["TIMELOG"])
        assert len(task["timelogList"]) == 1
        assert task["timelogList"][0]["uuId"] == timelog["uuId"]

    def test_attach_project(self):
        timelog = self.create_timelog(entity_ref=self.project["uuId"])
        assert timelog["entityRef"] == self.project["uuId"]

        project = projectal.Project.get(self.project["uuId"], links=["TIMELOG"])
        assert len(project["timelogList"]) == 1
        assert project["timelogList"][0]["uuId"] == timelog["uuId"]

    def test_attach_activity(self):
        timelog = self.create_timelog(entity_ref=self.activity["uuId"])
        assert timelog["entityRef"] == self.activity["uuId"]

        activity = projectal.Activity.get(self.activity["uuId"], links=["TIMELOG"])
        assert len(activity["timelogList"]) == 1
        assert activity["timelogList"][0]["uuId"] == timelog["uuId"]

    def test_list(self):
        timelog = self.create_timelog()
        timelogs = projectal.Timelog.list(expand=True)
        assert any(entity["uuId"] == timelog["uuId"] for entity in timelogs)
        assert isinstance(timelogs[0], projectal.Timelog)

    def test_match_and_search(self):
        timelog = self.create_timelog()
        identifier = timelog["identifier"]
        name_prefix = timelog["name"][:8]
        name_suffix = timelog["name"][-4:]

        matches = projectal.Timelog.match("identifier", identifier)
        assert len(matches) == 1
        assert matches[0]["uuId"] == timelog["uuId"]

        matches = projectal.Timelog.match_startswith("name", name_prefix)
        assert any(match["uuId"] == timelog["uuId"] for match in matches)

        matches = projectal.Timelog.match_endswith("name", name_suffix)
        assert any(match["uuId"] == timelog["uuId"] for match in matches)

        matches = projectal.Timelog.search(["name", "identifier"], identifier)
        assert any(match["uuId"] == timelog["uuId"] for match in matches)

    def test_query(self):
        timelog = self.create_timelog()
        matches = projectal.Timelog.query(
            [["STAFF.TIMELOG.identifier", "eq", timelog["identifier"]]]
        )

        assert len(matches) == 1
        assert matches[0]["uuId"] == timelog["uuId"]
