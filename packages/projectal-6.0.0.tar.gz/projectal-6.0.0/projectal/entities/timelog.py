import projectal
from projectal.entity import Entity
from projectal.linkers import *
from projectal import api


class Timelog(
    Entity,
    FileLinker,
    NoteLinker,
    TagLinker,
):
    """
    Implementation of the [Timelog](https://projectal.com/docs/latest/#tag/Timelog) API.
    """

    _path = "timelog"
    _name = "timelog"

    _links = [
        FileLinker,
        NoteLinker,
        TagLinker,
    ]

    @classmethod
    def create(
        cls,
        holder,
        entities,
        batch_linking=True,
        disable_system_features=True,
        enable_system_features_on_exit=True,
    ):
        """Create a Timelog

        `holder`: An instance or the `uuId` of the Staff

        `entities`: `dict` containing the fields of the entity to be created,
        or a list of such `dict`s to create in bulk.
        """
        holder_id = holder["uuId"] if isinstance(holder, dict) else holder
        params = "?holder=" + holder_id
        out = super().create(
            entities,
            params,
            batch_linking,
            disable_system_features,
            enable_system_features_on_exit,
        )

        # Timelogs should always refer to their Staff. We don't get this information from the
        # creation api method, but we can insert them ourselves because we know what they are.
        def add_fields(obj):
            obj.set_readonly("staffRef", holder_id)

        if isinstance(out, dict):
            add_fields(out)
        if isinstance(out, list):
            for obj in out:
                add_fields(obj)
        return out

    @classmethod
    def list(cls, expand=False, links=None):
        """Return a list of all entity UUIDs of this type.

        You may pass in `expand=True` to get full Entity objects
        instead, but be aware this may be very slow if you have
        thousands of objects.

        If you are expanding the objects, you may further expand
        the results with `links`.
        """

        payload = {
            "name": "List all entities of type {}".format(cls._name.upper()),
            "type": "msql",
            "start": 0,
            "limit": -1,
            "select": [["STAFF.{}.uuId".format(cls._name.upper())]],
        }
        ids = api.query(payload)
        ids = [id[0] for id in ids]
        if ids:
            return cls.get(ids, links=links) if expand else ids
        return []

    @classmethod
    def match(cls, field, term, links=None):
        """Find entities where `field`=`term` (exact match), optionally
        expanding the results with `links`.

        Relies on `Entity.query()` with a pre-built set of rules.
        ```
        projects = projectal.Project.match('identifier', 'zmb-005')
        ```
        """
        filter = [["STAFF.{}.{}".format(cls._name.upper(), field), "eq", term]]
        return cls.query(filter, links)

    @classmethod
    def match_startswith(cls, field, term, links=None):
        """Find entities where `field` starts with the text `term`,
        optionally expanding the results with `links`.

        Relies on `Entity.query()` with a pre-built set of rules.
        ```
        projects = projectal.Project.match_startswith('name', 'Zomb')
        ```
        """
        filter = [["STAFF.{}.{}".format(cls._name.upper(), field), "prefix", term]]
        return cls.query(filter, links)

    @classmethod
    def match_endswith(cls, field, term, links=None):
        """Find entities where `field` ends with the text `term`,
        optionally expanding the results with `links`.

        Relies on `Entity.query()` with a pre-built set of rules.
        ```
        projects = projectal.Project.match_endswith('identifier', '-2023')
        ```
        """
        term = "(?i).*{}$".format(term)
        filter = [["STAFF.{}.{}".format(cls._name.upper(), field), "regex", term]]
        return cls.query(filter, links)

    @classmethod
    def search(cls, fields=None, term="", case_sensitive=True, links=None):
        """Find entities that contain the text `term` within `fields`.
        `fields` is a list of field names to target in the search.

        `case_sensitive`: Optionally turn off case sensitivity in the search.

        Relies on `Entity.query()` with a pre-built set of rules.
        ```
        projects = projectal.Project.search(['name', 'description'], 'zombie')
        ```
        """
        filter = []
        term = "(?{}).*{}.*".format("" if case_sensitive else "?", term)
        for field in fields:
            filter.append(
                ["STAFF.{}.{}".format(cls._name.upper(), field), "regex", term]
            )
        filter = ["_or_", filter]
        return cls.query(filter, links)

    @classmethod
    def query(cls, filter, links=None, timeout=30):
        """Run a query on this entity with the supplied filter.

        The query is already set up to target this entity type, and the
        results will be converted into full objects when found, optionally
        expanded with the `links` provided. You only need to supply a
        filter to reduce the result set.

        See [the filter documentation](https://projectal.com/docs/v1.1.1#section/Filter-section)
        for a detailed overview of the kinds of filters you can construct.
        """
        ids = []
        request_completed = False
        limit = projectal.query_chunk_size
        start = 0
        while not request_completed:
            payload = {
                "name": "Python library entity query ({})".format(cls._name.upper()),
                "type": "msql",
                "start": start,
                "limit": limit,
                "select": [["STAFF.{}.uuId".format(cls._name.upper())]],
                "filter": filter,
                "timeout": timeout,
            }
            result = projectal.query(payload)
            ids.extend(result)
            if len(result) < limit:
                request_completed = True
            else:
                start += limit

        ids = [id[0] for id in ids]
        if ids:
            return cls.get(ids, links=links)
        return []
