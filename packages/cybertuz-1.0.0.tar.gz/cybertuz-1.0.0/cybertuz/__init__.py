"""
CyberTuz - Comprehensive Cyber Security Learning Platform
A terminal-based cybersecurity learning tool for Termux and Linux.
"""

__version__ = "1.0.0"
__author__ = "djunekz"
__license__ = "MIT"
