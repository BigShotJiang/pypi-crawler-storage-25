"""
Fallback setup.py for older pip versions that don't support pyproject.toml.
The primary build config is in pyproject.toml.
"""
from setuptools import setup, find_packages
import os

def read_file(fname):
    with open(os.path.join(os.path.dirname(__file__), fname), encoding="utf-8") as f:
        return f.read()

def collect_data_files():
    """Collect all .sh files from data/ and data/modules/"""
    data_files = []
    base = os.path.join("cybertuz", "data")
    # Root data dir
    sh_files = [os.path.join(base, f) for f in os.listdir(base) if f.endswith(".sh")]
    if sh_files:
        data_files.append((base, sh_files))
    # Modules subdirectory
    modules_dir = os.path.join(base, "modules")
    if os.path.isdir(modules_dir):
        mod_files = [os.path.join(modules_dir, f)
                     for f in os.listdir(modules_dir) if f.endswith(".sh")]
        if mod_files:
            data_files.append((modules_dir, mod_files))
    return data_files

setup(
    name="cybertuz",
    version="1.0.0",
    description="Comprehensive Cyber Security Learning Platform for Termux & Linux",
    long_description=read_file("README.md"),
    long_description_content_type="text/markdown",
    author="djunekz",
    url="https://github.com/djunekz/cybertuz",
    license="MIT",
    packages=find_packages(),
    package_data={
        "cybertuz": [
            "data/*.sh",
            "data/modules/*.sh",
        ],
    },
    entry_points={
        "console_scripts": [
            "cybertuz=cybertuz.cli:main",
        ],
    },
    python_requires=">=3.8",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Environment :: Console",
        "Intended Audience :: Education",
        "License :: OSI Approved :: MIT License",
        "Operating System :: POSIX :: Linux",
        "Programming Language :: Python :: 3",
        "Topic :: Education",
        "Topic :: Security",
    ],
)
