# CyberTuz

<div align="center">

**Comprehensive Cyber Security Learning Platform**

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![Platform](https://img.shields.io/badge/Platform-Termux%20%7C%20Linux%20%7C%20macOS-green.svg)](https://github.com/djunekz/cybertuz)
[![PyPI](https://img.shields.io/pypi/v/cybertuz.svg)](https://pypi.org/project/cybertuz)
[![Python](https://img.shields.io/pypi/pyversions/cybertuz.svg)](https://pypi.org/project/cybertuz)
[![Languages](https://img.shields.io/badge/Languages-13-orange.svg)](#language-support)
[![Modules](https://img.shields.io/badge/Modules-17-red.svg)](#modules)

</div>

---

## What is CyberTuz?

CyberTuz is a free, open-source, terminal-based cyber security learning platform built in Bash. It covers ethical hacking, penetration testing, network security, web application security, cryptography, digital forensics, CTF challenges, and real-world pentest simulations — all from your terminal.

> **For educational purposes only.** All content is designed to teach legal and ethical security practices.

---

## Installation

### Option 1: pip (recommended)

```bash
pip install cybertuz
```

Then simply run:

```bash
cybertuz
```

### Option 2: Manual (Termux / Linux)

```bash
# Clone repository
git clone https://github.com/djunekz/cybertuz
cd cybertuz

# Run installer (adds `cybertuz` command to PATH)
bash install.sh

# Then run from anywhere:
cybertuz
```

### Option 3: Direct run (no install)

```bash
git clone https://github.com/djunekz/cybertuz
cd cybertuz
bash cybertuz.sh
```

---

## Uninstall

### pip install:
```bash
pip uninstall cybertuz
```

### Manual install:
```bash
bash install.sh --uninstall
```

---

## Features

- **17 learning modules** — beginner to expert
- **13 language support** — English, Indonesian, Hindi, Malay, Russian, Chinese, Japanese, Thai, Vietnamese, Arabic, Spanish, Italian, Korean
- **Training Arena** — leveled hands-on practice (Newbie → Expert)
- **Mission System** — real-world pentest simulation tasks
- **CTF Challenges** — capture the flag practice exercises
- **Live practice** — real commands against safe targets
- **Progress tracking** — scores and mission completion saved locally
- **No internet required** for most features
- **Completely free** — no ads, no subscriptions

---

## Modules

| # | Module |
|---|--------|
| 1 | Basic Theory of Cyber Security |
| 2 | Reconnaissance & Information Gathering |
| 3 | Network Scanning & Enumeration |
| 4 | Vulnerability Assessment |
| 5 | Web Application Security |
| 6 | Cryptography & Encryption |
| 7 | Password Security & Cracking |
| 8 | Social Engineering Awareness |
| 9 | Network Security & Firewall |
| 10 | Wireless Security |
| 11 | Digital Forensics |
| 12 | Malware Analysis Basics |
| 13 | CTF & Practice Challenges |
| 14 | Tools & Complete Cheatsheet |
| 15 | Reports & Learning Progress |
| 16 | Training Arena (Newbie → Expert) |
| 17 | Mission System (Real Pentest Simulation) |

---

## Language Support

English · Indonesian · Hindi · Malay · Russian · Chinese · Japanese · Thai · Vietnamese · Arabic · Spanish · Italian · Korean

---

## Requirements

- Python 3.8+
- Bash 4.0+
- Linux, macOS, or Android (Termux)
- Optional: `nmap`, `curl`, `dnsutils`, `whois`, `python3` for live labs

---

## Links

- GitHub: https://github.com/djunekz/cybertuz
- Issues: https://github.com/djunekz/cybertuz/issues

---

## License

MIT © djunekz
