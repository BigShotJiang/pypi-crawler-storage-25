"""Curated public package interface with lazily resolved top-level exports."""

from __future__ import annotations

from importlib import import_module
from importlib.metadata import PackageNotFoundError, version
from typing import TYPE_CHECKING

from design_research_agents._lazy_exports import module_dir, resolve_lazy_export
from design_research_agents._public_exports import (
    TOP_LEVEL_EXPORTS,
    TOP_LEVEL_PUBLIC_API,
    TOP_LEVEL_SUBMODULES,
)

__all__ = list(TOP_LEVEL_PUBLIC_API)

try:
    __version__ = version("design-research-agents")
except PackageNotFoundError:
    __version__ = "0+unknown"


def __getattr__(name: str) -> object:
    """Resolve and cache one deferred public export.

    Args:
        name: Public symbol name requested from the package module.

    Returns:
        Resolved export object.

    Raises:
        AttributeError: If ``name`` is not part of the public export map.
    """
    if name in TOP_LEVEL_SUBMODULES:
        module = import_module(TOP_LEVEL_SUBMODULES[name])
        globals()[name] = module
        return module

    return resolve_lazy_export(
        module_name=__name__,
        exports=TOP_LEVEL_EXPORTS,
        export_name=name,
        namespace=globals(),
    )


def __dir__() -> list[str]:
    """Return package attributes, including deferred exports.

    Returns:
        Sorted attribute list for interactive discovery.
    """
    return module_dir(globals(), __all__)


if TYPE_CHECKING:
    from ._contracts import DelegateBatchStep as DelegateBatchStep
    from ._contracts import DelegateStep as DelegateStep
    from ._contracts import ExecutionResult as ExecutionResult
    from ._contracts import LLMMessage as LLMMessage
    from ._contracts import LLMRequest as LLMRequest
    from ._contracts import LLMResponse as LLMResponse
    from ._contracts import LogicStep as LogicStep
    from ._contracts import LoopStep as LoopStep
    from ._contracts import MemoryReadStep as MemoryReadStep
    from ._contracts import MemoryWriteStep as MemoryWriteStep
    from ._contracts import ModelStep as ModelStep
    from ._contracts import ToolStep as ToolStep
    from ._implementations._patterns import AdaptiveSchedule as AdaptiveSchedule
    from ._implementations._patterns import ExponentialSchedule as ExponentialSchedule
    from ._implementations._patterns import LinearSchedule as LinearSchedule
    from ._implementations._patterns import LogarithmicSchedule as LogarithmicSchedule
    from ._implementations._patterns import TemperatureSchedule as TemperatureSchedule
    from ._tracing import Tracer as Tracer
    from .agent import DirectLLMCall as DirectLLMCall
    from .agent import MultiStepAgent as MultiStepAgent
    from .agent import PromptWorkflowAgent as PromptWorkflowAgent
    from .agent import SeededRandomBaselineAgent as SeededRandomBaselineAgent
    from .llm import AnthropicServiceLLMClient as AnthropicServiceLLMClient
    from .llm import AzureOpenAIServiceLLMClient as AzureOpenAIServiceLLMClient
    from .llm import GeminiServiceLLMClient as GeminiServiceLLMClient
    from .llm import GroqServiceLLMClient as GroqServiceLLMClient
    from .llm import LlamaCppServerLLMClient as LlamaCppServerLLMClient
    from .llm import MLXLocalLLMClient as MLXLocalLLMClient
    from .llm import OllamaLLMClient as OllamaLLMClient
    from .llm import OpenAICompatibleHTTPLLMClient as OpenAICompatibleHTTPLLMClient
    from .llm import OpenAIServiceLLMClient as OpenAIServiceLLMClient
    from .llm import SGLangServerLLMClient as SGLangServerLLMClient
    from .llm import TransformersLocalLLMClient as TransformersLocalLLMClient
    from .llm import VLLMServerLLMClient as VLLMServerLLMClient
    from .model_selection import ModelCatalog as ModelCatalog
    from .model_selection import ModelFlight as ModelFlight
    from .model_selection import ModelFlightRegistry as ModelFlightRegistry
    from .model_selection import ModelSelector as ModelSelector
    from .patterns import BlackboardPattern as BlackboardPattern
    from .patterns import DebatePattern as DebatePattern
    from .patterns import NominalTeamPattern as NominalTeamPattern
    from .patterns import PlanExecutePattern as PlanExecutePattern
    from .patterns import ProposeCriticPattern as ProposeCriticPattern
    from .patterns import RAGPattern as RAGPattern
    from .patterns import RalphLoopPattern as RalphLoopPattern
    from .patterns import RoundBasedCoordinationPattern as RoundBasedCoordinationPattern
    from .patterns import RouterDelegatePattern as RouterDelegatePattern
    from .patterns import SimulatedAnnealingPattern as SimulatedAnnealingPattern
    from .patterns import TreeSearchPattern as TreeSearchPattern
    from .patterns import TwoSpeakerConversationPattern as TwoSpeakerConversationPattern
    from .skills import SkillsConfig as SkillsConfig
    from .study import AgentExecutionEnvelope as AgentExecutionEnvelope
    from .study import AgentRunRequest as AgentRunRequest
    from .study import StudyCondition as StudyCondition
    from .study import execute_agent_request as execute_agent_request
    from .study import execute_agent_run as execute_agent_run
    from .study import normalize_agent_execution as normalize_agent_execution
    from .tools import CallableToolConfig as CallableToolConfig
    from .tools import MCPServerConfig as MCPServerConfig
    from .tools import ScriptToolConfig as ScriptToolConfig
    from .tools import Toolbox as Toolbox
    from .tools import ToolResult as ToolResult
    from .workflow import CompiledExecution as CompiledExecution
    from .workflow import Workflow as Workflow
    from .workflow import build_json_prompt_workflow as build_json_prompt_workflow
