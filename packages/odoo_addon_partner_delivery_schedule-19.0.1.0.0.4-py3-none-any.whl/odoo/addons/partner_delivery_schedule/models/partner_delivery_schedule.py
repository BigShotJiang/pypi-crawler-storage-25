# Copyright 2018 Tecnativa - Sergio Teruel
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl).
from odoo import api, fields, models
from odoo.exceptions import ValidationError


class DeliverySchedule(models.Model):
    _name = "delivery.schedule"
    _description = "Delivery Schedule"

    name = fields.Char(required=True)
    color = fields.Integer(string="Color Index")
    hour_from = fields.Float(string="From")
    hour_to = fields.Float(string="To", default=24.00, required=True)
    monday = fields.Boolean(default=True)
    tuesday = fields.Boolean(default=True)
    wednesday = fields.Boolean(default=True)
    thursday = fields.Boolean(default=True)
    friday = fields.Boolean(default=True)
    saturday = fields.Boolean()
    sunday = fields.Boolean()

    partner_ids = fields.Many2many(
        comodel_name="res.partner",
        relation="res_partner_delivery_schedule_rel",
        column1="delivery_schedule_id",
        column2="partner_id",
        string="Partners",
        compute="_compute_partner_ids",
        inverse="_inverse_partner_ids",
    )

    def _compute_partner_ids(self):
        all_partners = self.env["res.partner"].search(
            [("delivery_schedule_ids", "in", self.ids)]
        )
        for schedule in self:
            schedule.partner_ids = all_partners.filtered(
                lambda p, s=schedule: s in p.delivery_schedule_ids
            )

    def _inverse_partner_ids(self):
        for schedule in self:
            to_add = schedule.partner_ids.filtered(
                lambda p, s=schedule: s not in p.delivery_schedule_ids
            )
            if to_add:
                to_add.write({"delivery_schedule_ids": [(4, schedule.id)]})

    @api.constrains("hour_from", "hour_to")
    def _check_hour_interval(self):
        if (
            self.hour_from < 0.0
            or self.hour_to > 24.0
            or self.hour_from >= self.hour_to
        ):
            raise ValidationError(
                self.env._(
                    "Error ! You can not set hour_from greater or equal than hour_to ."
                )
            )
        return True

    @api.constrains(
        "monday",
        "tuesday",
        "wednesday",
        "thursday",
        "friday",
        "saturday",
        "sunday",
    )
    def _check_day_selected(self):
        if not any([self[x[0]] for x in self._days_of_week()]):
            raise ValidationError(
                self.env._("Error ! You must set one day to delivery.")
            )
        return True

    def _days_of_week(self):
        return [
            ("monday", self.env._("Monday")),
            ("tuesday", self.env._("Tuesday")),
            ("wednesday", self.env._("Wednesday")),
            ("thursday", self.env._("Thursday")),
            ("friday", self.env._("Friday")),
            ("saturday", self.env._("Saturday")),
            ("sunday", self.env._("Sunday")),
        ]

    @api.depends(
        "hour_from",
        "hour_to",
        "monday",
        "tuesday",
        "wednesday",
        "thursday",
        "friday",
        "saturday",
        "sunday",
    )
    def _compute_display_name(self):
        for schedule in self:
            hour_from = "{:02.0f}:{:02.0f}".format(*divmod(schedule.hour_from * 60, 60))
            hour_to = "{:02.0f}:{:02.0f}".format(*divmod(schedule.hour_to * 60, 60))
            days_accepted = [
                d[1][:2] for d in schedule._days_of_week() if schedule[d[0]]
            ]
            days = (
                ", ".join(days_accepted)
                if days_accepted and len(days_accepted) < 7
                else self.env._("All days")
            )
            schedule.display_name = f"{hour_from}-{hour_to} ({days})"
