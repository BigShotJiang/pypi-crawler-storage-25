# GSE AI Server API

This package provides an API for connecting to UB GSE's API server. 
See [the Computational Literacies Lab handbook page](https://computationalliteracies.net/handbook/tools/ai-server/)
for details about the server. 

The [documentation](https://docs.makingwithcode.org/gseai) provides details on 
using the API. 

## Quickstart

```python3
from gseai import GSEAIServer

with GSEAIServer("your-api-token") as server:
    # List available models
    models = server.list_models()

    # Chat using the native API
    response = server.chat("model-id", "What is machine learning?")

    # Chat using the OpenAI-compatible API
    response = server.chat_completions(
        "model-id",
        messages=[{"role": "user", "content": "What is machine learning?"}],
    )

```
