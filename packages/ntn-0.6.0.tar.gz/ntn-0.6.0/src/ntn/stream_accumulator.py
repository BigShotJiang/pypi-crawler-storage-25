"""Streaming event accumulator.

Turns unified provider stream events into a normalized content_list matching the
non-streaming response format.

If show_thinking_content is enabled, thinking deltas are also printed as they
stream (same color as thinking).
"""

from __future__ import annotations

import json
from typing import Any

from colorama import Style


class StreamAccumulator:
    """Accumulate streaming events into a content_list.

    Fields that grow token-by-token (_current_text, _current_thinking, etc.)
    use list[str] + "".join() at flush time instead of str +=.

    CPython's str-concatenation optimisation (realloc-in-place) only fires when
    refcount == 1. Instance attributes always have refcount >= 2 (instance dict +
    operand stack), so `self.s += chunk` always allocates a new string and copies
    the entire accumulated text — O(n²) for n total chars. Using list.append is
    O(1) amortised; join is one O(n) pass at flush.
    """

    __slots__ = (
        "print_text",
        "assistant_prefix",
        "get_assistant_color",
        "show_think_content",
        "content_list",
        "_current_text",
        "_current_thinking",
        "_current_signature",
        "_tool_use",
        "_tool_input_json",
        "_thinking_shown",
        "_text_started",
        "_thinking_print_last_char",
    )

    def __init__(
        self,
        print_text: bool,
        assistant_prefix: str,
        get_assistant_color: Any,
        show_think_content: bool = False,
    ) -> None:
        self.print_text = print_text
        self.assistant_prefix = assistant_prefix
        self.get_assistant_color = get_assistant_color
        self.show_think_content = show_think_content

        self.content_list: list[dict[str, Any]] = []
        self._current_text: list[str] = []
        self._current_thinking: list[str] = []
        self._current_signature: list[str] = []
        self._tool_use: dict[str, Any] | None = None
        self._tool_input_json: list[str] = []
        self._thinking_shown: bool = False
        self._text_started: bool = False
        self._thinking_print_last_char: str = ""

    @staticmethod
    def _normalize_thinking_for_display(
        chunk: str, last_char: str
    ) -> tuple[str, str]:
        """Strip tokenizer-artefact newlines from short thinking deltas.

        Some OpenRouter free-tier reasoning models (tencent/hy3-preview,
        certain free deepseek variants) stream their reasoning one token
        at a time, with each token prefixed by ``\\n``. Joined verbatim
        this looks like one word per terminal line, and even worse,
        sub-word pieces (``Se`` + ``\\nah`` + ``\\norse``) render as
        ``Se ah orse`` instead of ``Seahorse``.

        Well-formed models (Claude, GPT-5, Sonnet) stream their reasoning
        in much larger chunks (tens to hundreds of chars) and use ``\\n``
        meaningfully (paragraph breaks, list items, code indentation).

        We therefore apply normalization **only to short deltas (< 32
        chars) that start with a single newline**: drop the leading
        ``\\n`` so the delta concatenates cleanly with the previous
        chunk's last char. Larger deltas, paragraph-break-prefixed
        deltas (``\\n\\n``), and any delta whose internal text contains
        meaningful newlines are passed through unchanged.

        ``last_char`` is unused (kept for backward compat with the
        per-instance state field) but returned as the new last char so
        the StreamAccumulator can keep its bookkeeping symmetric.
        """
        if not chunk:
            return "", last_char

        SHORT = 32
        # Strip leading whitespace runs on short deltas. The signal is
        # the small chunk size: well-formed models stream their
        # reasoning in much larger chunks and put meaningful newlines
        # *inside* a chunk (not as the chunk's prefix). Pathological
        # streams emit one tokenizer-piece at a time, each prefixed
        # with one or more newlines; stripping those prefixes lets the
        # pieces concatenate cleanly with whatever came before.
        #
        # Pure-whitespace deltas (e.g. a standalone "\n\n" paragraph
        # break delta from a well-formed model) are passed through; only
        # deltas that contain real text after a leading newline run get
        # their prefix stripped.
        if len(chunk) < SHORT and chunk[0] in "\n\r":
            i = 0
            while i < len(chunk) and chunk[i] in "\n\r":
                i += 1
            if i < len(chunk):
                chunk = chunk[i:]

        return chunk, chunk[-1] if chunk else last_char

    def on_event(self, event: Any) -> None:
        et = getattr(event, "type", None)
        if et is None:
            return

        # Most common events first to minimise comparisons per token.
        if et == "text_delta":
            self._current_text.append(event.data)
            if self.print_text:
                print(f"{self.get_assistant_color('assistant')}{event.data}", end="", flush=True)
            return

        if et == "thinking_delta":
            self._current_thinking.append(event.data)
            if self.print_text and self.show_think_content:
                disp, self._thinking_print_last_char = (
                    self._normalize_thinking_for_display(
                        event.data, self._thinking_print_last_char
                    )
                )
                if disp:
                    print(f"{self.get_assistant_color('thinking')}{disp}{Style.RESET_ALL}", end="", flush=True)
            return

        if et == "tool_input_delta":
            self._tool_input_json.append(event.data)
            return

        if et == "content_block_stop":
            self._flush_block()
            return

        if et == "thinking_start":
            self._current_thinking = []
            self._current_signature = []
            self._thinking_print_last_char = ""
            if self.print_text and not self._thinking_shown:
                suffix = " " if self.show_think_content else "...\n"
                print(
                    f"{self.get_assistant_color('thinking')}🧠 Thinking:{suffix}{Style.RESET_ALL}",
                    end="",
                    flush=True,
                )
                self._thinking_shown = True
            return

        if et == "text_start":
            if self.print_text:
                print(
                    f"{self.get_assistant_color('assistant')}{self.assistant_prefix} ",
                    end="",
                    flush=True,
                )
            self._text_started = True
            return

        if et == "tool_use_start":
            self._tool_use = {"id": event.data["id"], "name": event.data["name"], "input": {}}
            self._tool_input_json = []
            return

        if et == "signature_delta":
            self._current_signature.append(event.data)
            return

        if et == "raw_block":
            # Provider emits a fully-formed content block (e.g. opaque
            # reasoning state for round-tripping) that should be appended
            # verbatim without going through the text/thinking accumulator.
            data = getattr(event, "data", None)
            if isinstance(data, dict):
                self.content_list.append(data)
            return

    def _flush_block(self) -> None:
        # Always reset the thinking-shown flag on any block close so a stray
        # thinking_start with no deltas doesn't suppress the leading newline
        # before the next text/tool block.
        thinking_text = "".join(self._current_thinking)
        sig_text = "".join(self._current_signature)

        if self._thinking_shown and not (thinking_text or sig_text):
            if self.print_text:
                print()
            self._thinking_shown = False

        if thinking_text or sig_text:
            thinking_block: dict[str, Any] = {"type": "thinking", "thinking": thinking_text}
            if sig_text:
                thinking_block["signature"] = sig_text
            self.content_list.append(thinking_block)
            if self.print_text and self._thinking_shown:
                print()
                self._thinking_shown = False
            self._current_thinking = []
            self._current_signature = []

        current_text = "".join(self._current_text)
        if current_text:
            self.content_list.append({"type": "text", "text": current_text})
            if self.print_text and self._text_started:
                print()  # newline
            self._current_text = []
            self._text_started = False

        if self._tool_use:
            raw = "".join(self._tool_input_json)
            if raw:
                try:
                    self._tool_use["input"] = json.loads(raw)
                except json.JSONDecodeError as e:
                    # Surface the malformed payload so the tool execution layer
                    # reports a useful error instead of silently calling with {}.
                    self._tool_use["input"] = {
                        "_malformed_json": raw[:500],
                        "_parse_error": str(e),
                    }
            else:
                self._tool_use["input"] = {}

            self.content_list.append(
                {
                    "type": "tool_use",
                    "id": self._tool_use["id"],
                    "name": self._tool_use["name"],
                    "input": self._tool_use["input"],
                }
            )
            self._tool_use = None
            self._tool_input_json = []
