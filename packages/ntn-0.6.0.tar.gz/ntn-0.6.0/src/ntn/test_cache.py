#!/usr/bin/env python3
"""
Test script to verify prompt caching token requirements.

This script verifies that the system prompt + tools meet the minimum
token requirements for prompt caching on different models.

Usage:
    python src/ntn/test_cache.py
"""
import os
import sys
import time
from typing import Optional

# Add src to path if running directly
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))

import anthropic
from ntn.config import config
from ntn.tools import TerminalTool, WebSearchTool, FetchWebTool
from ntn.prompts import get_system_prompt, detect_host_env


# Model cache requirements from centralized config
CACHE_REQUIREMENTS = config.models.cache_requirements


def get_test_system_prompt():
    """Get system prompt for testing with sample values."""
    workspace_dir = "D:\\Downloads\\project"
    return get_system_prompt(workspace_dir, detect_host_env(), [workspace_dir])


def _cache_chunk_size(model: str) -> int:
    """Empirical cache-report granularity for non-Anthropic providers.

    Cached-token counts are reported as a multiple of a provider-specific
    chunk size (the prefill batch / KV-block size). Predicting in this
    granularity lets the multi-turn diff hit 0 instead of bouncing on
    sub-chunk growth.

    Empirically observed (re-run the multi-turn test to re-derive):
      * gpt-5.x        : 256
      * deepseek-v4-pro: 128
      * moonshotai/kimi: 32
      * tencent/hy3    : 64
      * default        : 128
    """
    if model.startswith("gpt-"):
        return 256
    if model.startswith("deepseek/"):
        return 128
    if model.startswith("moonshotai/"):
        return 32
    if model.startswith("tencent/"):
        return 64
    return 128


def _make_provider(model: str):
    """Pick the right provider class for a model id (matches config.models)."""
    from ntn.providers import AnthropicProvider, OpenAIProvider, OpenRouterProvider
    if model.startswith("claude-"):
        p = AnthropicProvider(model)
    elif model.startswith("gpt-"):
        p = OpenAIProvider(model)
    else:
        p = OpenRouterProvider(model)
    p.set_session_id(f"cache-test-{model}")
    return p


def _provider_family(model: str) -> str:
    if model.startswith("claude-"):
        return "anthropic"
    if model.startswith("gpt-"):
        return "openai"
    return "openrouter"


def _get_or_balance() -> Optional[float]:
    """Return current OpenRouter total_usage (USD) or None if unreachable."""
    import urllib.request
    import json as _json
    key = os.getenv("OPENROUTER_API_KEY")
    if not key:
        return None
    try:
        req = urllib.request.Request(
            "https://openrouter.ai/api/v1/credits",
            headers={"Authorization": f"Bearer {key}"},
        )
        with urllib.request.urlopen(req, timeout=10) as r:
            data = _json.loads(r.read())
        return float(data["data"]["total_usage"])
    except Exception:
        return None


def _get_or_generation_cost(gen_id: str) -> Optional[float]:
    """Return total_cost (USD) for a single OR generation, or None on error.

    OR's /api/v1/generation endpoint reports the exact billed amount per
    request. There's a small propagation lag (~10-60s) before a generation
    becomes queryable; callers should sleep before the first lookup and
    handle 404s with retries.
    """
    import urllib.request
    import urllib.error
    import json as _json
    key = os.getenv("OPENROUTER_API_KEY")
    if not key:
        return None
    try:
        req = urllib.request.Request(
            f"https://openrouter.ai/api/v1/generation?id={gen_id}",
            headers={"Authorization": f"Bearer {key}"},
        )
        with urllib.request.urlopen(req, timeout=10) as r:
            data = _json.loads(r.read())
        return float(data["data"]["total_cost"])
    except Exception:
        return None




def test_openai_caching(model, system_text, tools):
    """Verify OpenAI prompt caching for a gpt-5.x model via OpenAIProvider.

    OpenAI caches automatically for prompts >= 1024 tokens. Cache hits surface
    as ``usage.input_tokens_details.cached_tokens`` on the second identical
    call. We exercise the production provider (which sends
    ``prompt_cache_retention=24h`` and ``prompt_cache_key=<session_id>``) so
    the test reflects real behavior.
    """
    from ntn.providers import OpenAIProvider
    if not os.getenv("OPENAI_API_KEY"):
        return {"error": "OPENAI_API_KEY not set"}
    provider = OpenAIProvider(model)
    provider.set_session_id(f"cache-test-{model}")
    messages = [{"role": "user", "content": "Say hello"}]

    resp1 = provider.create(messages=messages, system=system_text, tools=tools, max_tokens=50, effort="medium")
    time.sleep(2)
    resp2 = provider.create(messages=messages, system=system_text, tools=tools, max_tokens=50, effort="medium")
    return {
        "input_tokens_1": resp1.usage.input_tokens,
        "input_tokens_2": resp2.usage.input_tokens,
        "cached_1": resp1.usage.cache_read_input_tokens,
        "cached_2": resp2.usage.cache_read_input_tokens,
    }


def test_or_caching(model, system_text, tools):
    """Verify OpenRouter prompt caching via OpenRouterProvider.

    Most OR providers (DeepSeek, Moonshot/Kimi, Grok, etc.) cache
    automatically. With ``usage.include=true`` (now sent by the provider) the
    cached-token count surfaces on ``usage.cache_read_input_tokens``.
    """
    from ntn.providers import OpenRouterProvider
    if not os.getenv("OPENROUTER_API_KEY"):
        return {"error": "OPENROUTER_API_KEY not set"}
    provider = OpenRouterProvider(model)
    provider.set_session_id(f"cache-test-{model}")
    messages = [{"role": "user", "content": "Say hello"}]
    resp1 = provider.create(messages=messages, system=system_text, tools=tools, max_tokens=50)
    time.sleep(3)
    resp2 = provider.create(messages=messages, system=system_text, tools=tools, max_tokens=50)
    return {
        "input_tokens_1": resp1.usage.input_tokens,
        "input_tokens_2": resp2.usage.input_tokens,
        "cached_1": resp1.usage.cache_read_input_tokens,
        "cached_2": resp2.usage.cache_read_input_tokens,
        "cache_write_1": resp1.usage.cache_creation_input_tokens,
    }



def get_tool_schemas():
    """Get tool schemas matching CodingAgent._get_tool_schemas()."""
    tools = [
        TerminalTool("D:\\Downloads\\project"),
        WebSearchTool(),
        FetchWebTool(),
    ]
    return [tool.get_schema() for tool in tools]


def count_tokens(client, model, system_text, tools=None):
    """Count tokens for the given system prompt and tools.

    Uses minimal 'x' message (1 token) so the count is dominated by tools+system.
    The returned number is RAW (includes the probe + framing); we only use it
    as a sanity-check sizing, never to predict cache size.
    """
    system = [{"type": "text", "text": system_text, "cache_control": {"type": "ephemeral"}}]
    kwargs = {
        "model": model,
        "system": system,
        "messages": [{"role": "user", "content": "x"}]
    }
    if tools:
        kwargs["tools"] = tools

    response = client.messages.count_tokens(**kwargs)
    return response.input_tokens


def test_caching(client, model, system_text, tools):
    """Test if caching actually works by making two identical requests.

    Real round-trip check (no magic constants):
      - Request 1 writes the cache. ``cache_creation_input_tokens`` is the
        ground-truth size of what was cached.
      - Request 2 (identical) should read exactly that. ``cache_read`` from
        request 2 must equal ``cache_creation`` from request 1.

    Uses ``AnthropicProvider`` so this exercises the *real* cache breakpoint
    logic shipped in production (1h system breakpoint + 5m last-message
    breakpoint).
    """
    from ntn.providers import AnthropicProvider

    provider = AnthropicProvider(model)
    messages = [{"role": "user", "content": "Say hello"}]

    resp1 = provider.create(messages=messages, system=system_text, tools=tools, max_tokens=50)
    cache_creation = resp1.usage.cache_creation_input_tokens

    cache_read = 0
    for _ in range(6):
        time.sleep(3)
        resp2 = provider.create(messages=messages, system=system_text, tools=tools, max_tokens=50)
        cache_read = resp2.usage.cache_read_input_tokens
        if cache_read >= cache_creation:
            break

    return {
        "cache_creation": cache_creation,
        "cache_read": cache_read,
        "caching_works": cache_read > 0,
        "exact_match": cache_read == cache_creation,
    }


def test_multi_turn_caching(model, system_text, tools, num_turns=5):
    """Simulate an N-turn conversation and verify the cache reads the growing
    history on every subsequent turn.

    Works for all three provider families. Prediction model differs slightly
    because the providers report cache differently:

      * Anthropic returns ``cache_creation`` + ``cache_read`` separately, and
        the breakpoint set on turn N-1 covers exactly ``read_{N-1} +
        creation_{N-1}`` tokens. So:
            predicted_read_at_N = read_{N-1} + creation_{N-1}
        Diff should be 0 for a stable prefix.

      * OpenAI / OpenRouter (DeepSeek, Kimi, Hunyuan, …) only report
        ``cached_tokens``. There's no separate "creation" — the entire prefix
        of every request is implicitly cached. A turn N request whose first
        ~all-of-input matches turn N-1's prefix should read ~``input_{N-1}``
        cached tokens. So:
            predicted_read_at_N = input_{N-1}
        On these providers diff can legitimately be slightly negative
        (alignment / chunk boundaries on the provider side); large negatives
        signal cache miss.

    Per-run UUID nonce isolates each run from earlier test cache entries.

    Returns (rows, generation_ids) where generation_ids is the list of
    OpenRouter generation ids captured (empty for non-OR providers).
    """
    import uuid

    nonce = uuid.uuid4().hex
    provider = _make_provider(model)
    is_anthropic = model.startswith("claude-")
    is_openrouter = not is_anthropic and not model.startswith("gpt-")
    generation_ids: list = []

    messages = []
    rows = []
    for turn in range(1, num_turns + 1):
        messages.append({
            "role": "user",
            "content": f"[run={nonce}] Turn {turn}: respond with one short word.",
        })
        kwargs = dict(messages=messages, system=system_text, tools=tools, max_tokens=20)
        if not is_anthropic:
            # Use a low effort for non-Anthropic to keep the test cheap.
            kwargs["effort"] = "medium" if model.startswith("gpt-") else "low"
        resp = provider.create(**kwargs)

        if is_openrouter:
            raw = getattr(resp, "raw_response", None)
            gid = getattr(raw, "id", None) if raw is not None else None
            if gid:
                generation_ids.append(gid)

        if turn == 1:
            predicted = 0
        elif is_anthropic:
            prev = rows[-1]
            predicted = prev["cache_read"] + prev["cache_creation"]
        else:
            # Non-Anthropic: cache reports come back floored to a
            # provider-specific chunk size. Predict the largest multiple of
            # that chunk size <= the prior turn's full input.
            chunk = _cache_chunk_size(model)
            predicted = (rows[-1]["input"] // chunk) * chunk

        actual = resp.usage.cache_read_input_tokens
        rows.append({
            "turn": turn,
            "input": resp.usage.input_tokens,
            "cache_creation": resp.usage.cache_creation_input_tokens,
            "cache_creation_5m": getattr(resp.usage, "cache_creation_5m_tokens", 0),
            "cache_creation_1h": getattr(resp.usage, "cache_creation_1h_tokens", 0),
            "cache_read": actual,
            "predicted_read": predicted,
            "diff": actual - predicted,
            "output": resp.usage.output_tokens,
        })
        # Append the assistant response so the next turn has a real prefix to cache.
        assistant_text = ""
        for block in resp.content:
            if isinstance(block, dict) and block.get("type") == "text":
                assistant_text += block.get("text", "")
        messages.append({
            "role": "assistant",
            "content": assistant_text or "ok",
        })
        # Brief pause so cache writes from turn N propagate before turn N+1.
        time.sleep(2)
    return rows, generation_ids



def main():
    """Run cache verification tests."""
    api_key = os.getenv("ANTHROPIC_API_KEY")
    if not api_key:
        print("❌ ANTHROPIC_API_KEY not set")
        sys.exit(1)
    
    client = anthropic.Anthropic(api_key=api_key)
    
    # Get system prompt and tools (now from shared prompts module!)
    system_text = get_test_system_prompt()
    tools = get_tool_schemas()
    
    print("=" * 60)
    print("PROMPT CACHING TOKEN VERIFICATION")
    print("=" * 60)
    
    # Test each Anthropic model (skip non-claude entries)
    for model, min_tokens in CACHE_REQUIREMENTS.items():
        if not model.startswith("claude-"):
            continue
        model_short = model.split("-")[1]  # opus, sonnet, haiku
        print(f"\n📊 {model_short.upper()} ({model})")
        print(f"   Minimum for caching: {min_tokens} tokens")
        
        try:
            # Raw token count for system + tools + minimal "x" probe message.
            # This is what Anthropic's count_tokens API reports - we use it
            # only as a sanity-check sizing, NOT to predict cache size.
            raw_count = count_tokens(client, model, system_text, tools)
            print(f"   System+tools+probe (raw count_tokens): {raw_count} tokens")

            # Check if the raw size is even close to the minimum. The actual
            # cacheable size will be slightly less (the "x" probe and a few
            # framing tokens are excluded from the cache prefix).
            if raw_count < min_tokens - 10:  # leave margin for framing
                print(f"   ⚠️  Raw count ({raw_count}) likely below minimum ({min_tokens}); may not cache")

            print("   Testing actual cache behavior...")
            result = test_caching(client, model, system_text, tools)

            if result["caching_works"]:
                marker = "✓ exact match" if result["exact_match"] else f"(creation={result['cache_creation']}, read={result['cache_read']})"
                meets = "✅ MEETS" if result["cache_creation"] >= min_tokens else "❌ BELOW"
                print(f"   {meets} minimum requirement (cached={result['cache_creation']} vs min={min_tokens})")
                print(f"   ✅ CACHING WORKS! Read on retry: {result['cache_read']} tokens {marker}")
            else:
                print(f"   ❌ CACHING NOT WORKING (created: {result['cache_creation']}, read: {result['cache_read']})")

        except Exception as e:
            print(f"   ❌ Error: {e}")
    
    print("\n" + "=" * 60)
    print("VERIFICATION COMPLETE")
    print("=" * 60)

    # Aggregated per-model spend (used for end-of-test summary table).
    all_costs: list = []  # list of dicts: model, family, computed, api, gen_ids
    if os.getenv("OPENROUTER_API_KEY"):
        print("\n💳 OpenRouter per-request cost verification will use /api/v1/generation after the multi-turn loop.")

    # === Multi-turn caching simulation (all models) ===
    print("\n" + "=" * 60)
    print("MULTI-TURN CACHING (5-turn simulation per model)")
    print("=" * 60)
    for model in CACHE_REQUIREMENTS:
        # Skip providers whose API keys aren't set, instead of error-spamming.
        if model.startswith("gpt-") and not os.getenv("OPENAI_API_KEY"):
            continue
        if (not model.startswith(("claude-", "gpt-"))) and not os.getenv("OPENROUTER_API_KEY"):
            continue
        print(f"\n📊 {model}")
        family = _provider_family(model)
        try:
            rows, gen_ids = test_multi_turn_caching(model, system_text, tools, num_turns=5)
        except Exception as e:
            print(f"   ❌ Error: {e}")
            continue
        is_anthropic = model.startswith("claude-")
        if is_anthropic:
            print(f"   {'turn':>4} {'input':>6} {'create':>7} {'5m':>6} {'1h':>6} {'read':>6} {'predict':>8} {'diff':>5} {'out':>4}")
            for r in rows:
                diff_str = f"{r['diff']:+d}" if r['turn'] > 1 else "—"
                pred_str = str(r['predicted_read']) if r['turn'] > 1 else "—"
                print(f"   {r['turn']:>4} {r['input']:>6} {r['cache_creation']:>7} {r.get('cache_creation_5m', 0):>6} {r.get('cache_creation_1h', 0):>6} {r['cache_read']:>6} {pred_str:>8} {diff_str:>5} {r['output']:>4}")
        else:
            print(f"   {'turn':>4} {'input':>6} {'create':>7} {'read':>6} {'predict':>8} {'diff':>5} {'out':>4}")
            for r in rows:
                diff_str = f"{r['diff']:+d}" if r['turn'] > 1 else "—"
                pred_str = str(r['predicted_read']) if r['turn'] > 1 else "—"
                print(f"   {r['turn']:>4} {r['input']:>6} {r['cache_creation']:>7} {r['cache_read']:>6} {pred_str:>8} {diff_str:>5} {r['output']:>4}")
        # Sanity asserts: turn >=2 should read cache; turn >=3 should read more than turn 2.
        t2 = rows[1] if len(rows) >= 2 else None
        t_last = rows[-1]
        min_tokens = CACHE_REQUIREMENTS.get(model, 0)
        if t2 and t2["cache_read"] > 0:
            print(f"   ✅ Turn 2 reads cache ({t2['cache_read']} tokens)")
        elif t2 and t2["input"] < min_tokens:
            first_hit = next((r for r in rows if r["cache_read"] > 0), None)
            if first_hit:
                print(f"   ✅ Cache activates at turn {first_hit['turn']} (prefix crossed {min_tokens}-token min)")
            else:
                print(f"   ⚠️  Conversation never reached {min_tokens}-token min - cache never activated")
        else:
            print("   ❌ Turn 2 had no cache read - caching NOT working for this model")
        if t_last["cache_read"] > (t2["cache_read"] if t2 else 0):
            print(f"   ✅ Cache grows over time (turn {t_last['turn']} reads {t_last['cache_read']} vs turn 2 {t2['cache_read'] if t2 else 0})")
        else:
            print(f"   ⚠️  Cache did not grow (turn {t_last['turn']}={t_last['cache_read']}, turn 2={t2['cache_read'] if t2 else 0})")
        last_billable = t_last["input"] - t_last["cache_read"]
        print(f"   ℹ️  Final turn billable input (uncached): {last_billable} tokens (input={t_last['input']}, cached={t_last['cache_read']})")
        # Cost sanity: compare with-cache cost vs hypothetical no-cache cost,
        # using the production CodingAgent.calculate_cost_from_usage formula.
        from ntn.agent import CodingAgent
        total_cached_cost = 0.0
        total_nocache_cost = 0.0
        for r in rows:
            with_cache = {
                "input": r["input"],
                "output": r["output"],
                "cache_write": r["cache_creation"],
                "cache_write_5m": r.get("cache_creation_5m", 0),
                "cache_write_1h": r.get("cache_creation_1h", 0),
                "cache_read": r["cache_read"],
            }
            # Reconstruct what the bill would be if cache were off. For
            # Anthropic, input is uncached-only so add back read+create.
            # For OpenAI/OR, input already includes read+write.
            if model.startswith("claude-"):
                no_cache_input = r["input"] + r["cache_creation"] + r["cache_read"]
            else:
                no_cache_input = r["input"]
            no_cache = {"input": no_cache_input, "output": r["output"], "cache_write": 0, "cache_read": 0}
            total_cached_cost += CodingAgent.calculate_cost_from_usage(with_cache, model)
            total_nocache_cost += CodingAgent.calculate_cost_from_usage(no_cache, model)
        if total_nocache_cost > 0:
            savings_pct = 100 * (1 - total_cached_cost / total_nocache_cost)
            print(f"   💰 5-turn cost: ${total_cached_cost:.6f}  vs no-cache: ${total_nocache_cost:.6f}  ({savings_pct:+.1f}% savings)")
        else:
            print(f"   💰 5-turn cost: ${total_cached_cost:.6f} (free model)")

        # API-side per-model verification is done in the post-loop /generation
        # pass for OpenRouter; Anthropic + OpenAI have no live balance API.
        # OR per-request cost is fetched in the post-loop /generation pass
        # (more accurate than /credits diff which has lots of confounders
        # like concurrent traffic and 30-60s lag).
        all_costs.append({
            "model": model,
            "family": family,
            "computed": total_cached_cost,
            "api": None,  # filled in below for OR via /generation
            "gen_ids": gen_ids,
            "turns": len(rows),
            "input_tokens": sum(r["input"] for r in rows),
            "output_tokens": sum(r["output"] for r in rows),
            "cache_read": sum(r["cache_read"] for r in rows),
            "cache_write": sum(r["cache_creation"] for r in rows),
        })

    # ===== OpenRouter per-request cost verification via /generation =====
    or_models_with_ids = [c for c in all_costs if c["family"] == "openrouter" and c["gen_ids"]]
    if or_models_with_ids:
        total_or_gens = sum(len(c["gen_ids"]) for c in or_models_with_ids)
        print(f"\n⏳ Waiting 60s for {total_or_gens} OpenRouter generations to become queryable...")
        time.sleep(60)
        for c in or_models_with_ids:
            api_total = 0.0
            missing = 0
            for gid in c["gen_ids"]:
                cost = _get_or_generation_cost(gid)
                if cost is None:
                    missing += 1
                else:
                    api_total += cost
            if missing == 0:
                c["api"] = api_total
            else:
                # Retry once after another wait for any that returned 404
                print(f"   ⏳ {c['model']}: {missing} gens not yet queryable, retrying in 30s...")
                time.sleep(30)
                api_total = 0.0
                missing2 = 0
                for gid in c["gen_ids"]:
                    cost = _get_or_generation_cost(gid)
                    if cost is None:
                        missing2 += 1
                    else:
                        api_total += cost
                if missing2 == 0:
                    c["api"] = api_total
                else:
                    print(f"   ⚠️  {c['model']}: {missing2}/{len(c['gen_ids'])} gens still unqueryable; api total skipped")

    # === OpenAI gpt-5.x (single-shot sanity check) ===
    openai_models = [m for m in CACHE_REQUIREMENTS if m.startswith("gpt-")]
    if openai_models and os.getenv("OPENAI_API_KEY"):
        print("\n" + "=" * 60)
        print("OPENAI SINGLE-SHOT CACHING (automatic, >=1024 tokens, 24h retention)")
        print("=" * 60)
        for model in openai_models:
            min_tokens = CACHE_REQUIREMENTS[model]
            print(f"\n📊 {model}  (min {min_tokens})")
            try:
                r = test_openai_caching(model, system_text, tools)
                if "error" in r:
                    print(f"   ❌ {r['error']}")
                    continue
                print(f"   Request 1: input={r['input_tokens_1']}, cached={r['cached_1']}")
                print(f"   Request 2: input={r['input_tokens_2']}, cached={r['cached_2']}")
                if r["cached_2"] > 0:
                    pct = 100 * r["cached_2"] / r["input_tokens_2"]
                    print(f"   ✅ CACHING WORKS! {r['cached_2']}/{r['input_tokens_2']} tokens cached ({pct:.0f}%)")
                else:
                    print("   ❌ CACHING NOT WORKING (cached_tokens=0 on retry)")
            except Exception as e:
                print(f"   ❌ Error: {e}")

    # === OpenRouter (single-shot sanity check) ===
    or_models = [m for m in CACHE_REQUIREMENTS if not m.startswith(("claude-", "gpt-"))]
    if or_models and os.getenv("OPENROUTER_API_KEY"):
        print("\n" + "=" * 60)
        print("OPENROUTER SINGLE-SHOT CACHING (provider-automatic via usage.include)")
        print("=" * 60)
        for model in or_models:
            print(f"\n📊 {model}")
            try:
                r = test_or_caching(model, system_text, tools)
                if "error" in r:
                    print(f"   ❌ {r['error']}")
                    continue
                print(f"   Request 1: input={r['input_tokens_1']}, cached={r['cached_1']}, write={r['cache_write_1']}")
                print(f"   Request 2: input={r['input_tokens_2']}, cached={r['cached_2']}")
                if r["cached_2"] > 0:
                    pct = 100 * r["cached_2"] / max(r["input_tokens_2"], 1)
                    print(f"   ✅ CACHING WORKS! {r['cached_2']}/{r['input_tokens_2']} tokens cached ({pct:.0f}%)")
                else:
                    print("   ⚠️  cached_tokens=0 on retry (provider may not support cache or below its min)")
            except Exception as e:
                print(f"   ❌ Error: {e}")

    # Use per-model API deltas captured during the multi-turn loop above.
    # ===== Final per-model + per-provider cost summary =====
    print("\n" + "=" * 110)
    print("COST SUMMARY")
    print("=" * 110)
    print(f"{'Model':<32} {'Family':<11} {'In/Out/CR/CW tokens':<28} {'Computed':>11} {'API':>11} {'Diff %':>9}")
    print("-" * 110)
    by_family: dict = {}
    for c in all_costs:
        toks = f"{c['input_tokens']}/{c['output_tokens']}/{c['cache_read']}/{c['cache_write']}"
        api_str = f"${c['api']:.6f}" if c['api'] is not None else "n/a"
        if c['api'] is not None and c['computed'] > 0:
            diff_str = f"{100*(c['api']-c['computed'])/c['computed']:+.2f}%"
        else:
            diff_str = "—"
        print(f"{c['model']:<32} {c['family']:<11} {toks:<28} ${c['computed']:>10.6f} {api_str:>11} {diff_str:>9}")
        agg = by_family.setdefault(c['family'], {"computed": 0.0, "api": 0.0, "api_seen": False})
        agg["computed"] += c['computed']
        if c['api'] is not None:
            agg["api"] += c['api']
            agg["api_seen"] = True
    print("-" * 110)
    for fam, agg in by_family.items():
        if agg.get("api_seen"):
            if agg['computed'] > 0:
                pct = 100 * (agg['api'] - agg['computed']) / agg['computed']
                api_str = f"api=${agg['api']:.6f} (diff {pct:+.2f}%)"
            else:
                api_str = f"api=${agg['api']:.6f}"
        else:
            api_str = "api=n/a (no balance API for standard key)"
        print(f"  {fam:<10} computed=${agg['computed']:.6f}   {api_str}")
    print("=" * 110)
    print(
        "Note: Anthropic and OpenAI do not expose live per-request cost via\n"
        "      their standard API keys (admin keys required). For OpenRouter,\n"
        "      'API' is the exact billed amount fetched from\n"
        "      /api/v1/generation?id=<gen_id> for each request — this matches\n"
        "      what OR actually charged. For Anthropic/OpenAI, 'Computed' is\n"
        "      exact-by-formula: token counts the API itself returned\n"
        "      (input/output/cache_read/cache_write_5m/cache_write_1h) ×\n"
        "      per-million prices in config.yaml."
    )

    # ===== Dashboard verification — print per-provider totals so the user
    # can cross-check against the live billing dashboards. =====
    print("\n" + "=" * 110)
    print("💳 DASHBOARD VERIFICATION — compare these totals to the provider dashboards")
    print("=" * 110)
    fam_dashboards = {
        "anthropic":  "https://console.anthropic.com/settings/usage",
        "openai":     "https://platform.openai.com/usage",
        "openrouter": "https://openrouter.ai/activity",
    }
    for fam, agg in by_family.items():
        url = fam_dashboards.get(fam, "(no dashboard URL)")
        line = f"  {fam:<10} total computed = ${agg['computed']:.6f}"
        if agg.get("api_seen"):
            line += f"   (API actual = ${agg['api']:.6f})"
        print(line)
        print(f"             → {url}")
    print("=" * 110)
    print(
        "How to verify:\n"
        "  • OpenRouter: the 'API actual' above is already pulled from\n"
        "    /api/v1/generation per request — should match the dashboard\n"
        "    line items exactly (DeepSeek pinned to AtlasCloud, Kimi to\n"
        "    Cloudflare, so no fallback surprises).\n"
        "  • Anthropic / OpenAI: open the dashboard, filter by today, and\n"
        "    confirm the new line items add up to roughly the 'computed'\n"
        "    total above (dashboards may aggregate per minute/hour and lag\n"
        "    a few minutes).\n"
    )


if __name__ == "__main__":
    main()
