"""
Centralized configuration for the ntn agent.

Loads configuration from config.yaml bundled with the package.
API keys are read from environment variables (ANTHROPIC_API_KEY, OPENAI_API_KEY).

Usage:
    from ntn.config import config, get_color

    model_id = config.models.aliases["opus"]
    limits = config.models.get_limits(model_id)
    provider = config.models.get_provider(model_id)
    color = get_color("assistant")  # Returns Fore.GREEN
"""

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Optional

import os

import yaml
from colorama import Fore, Style


@dataclass(frozen=True)
class ModelPricing:
    """Pricing per 1M tokens for a specific model.

    `cache_write` is the single rate used by OpenAI/OpenRouter providers
    (where there is one TTL or no extra write cost). For Anthropic we
    additionally track `cache_write_5m` and `cache_write_1h` because the
    Claude API returns the breakdown and we send mixed TTLs (1h on the
    system block, 5m on the last user message). When the YAML only
    provides `cache_write`, the 5m/1h fields default to it for back-compat.
    """

    input: float
    output: float
    cache_read: float
    cache_write: float = 0.0
    cache_write_5m: Optional[float] = None
    cache_write_1h: Optional[float] = None

    def write_5m(self) -> float:
        return self.cache_write_5m if self.cache_write_5m is not None else self.cache_write

    def write_1h(self) -> float:
        return self.cache_write_1h if self.cache_write_1h is not None else self.cache_write


@dataclass(frozen=True)
class ModelLimits:
    """Per-model context and output limits."""

    max_context_tokens: int
    max_output_tokens: int


@dataclass(frozen=True)
class ModelsConfig:
    """Model-related configuration."""

    aliases: Dict[str, str]
    providers: Dict[str, str]
    default: str
    limits: Dict[str, ModelLimits]
    thinking: Dict[str, Dict]
    pricing: Dict[str, ModelPricing]
    cache_requirements: Dict[str, int]
    openrouter_provider_pin: Dict[str, str]

    def get_model_id(self, short_name: str) -> str:
        """Resolve short name to full model ID."""
        return self.aliases.get(short_name, self.aliases[self.default])

    def get_provider(self, model_id: str) -> str:
        """Get provider name for a model ID."""
        return self.providers.get(model_id, "anthropic")

    def get_limits(self, model_id: str) -> Optional[ModelLimits]:
        """Get context/output limits for a model."""
        return self.limits.get(model_id)

    def get_thinking(self, model_id: str) -> Dict:
        """Get per-model thinking config: {mode: adaptive|enabled|legacy, [budget_tokens]}."""
        return self.thinking.get(model_id, {"mode": "adaptive"})

    def get_thinking_budget(self, model_id: str) -> int:
        """Legacy: budget_tokens for models that still use manual budgeting (Haiku, OpenAI)."""
        return self.thinking.get(model_id, {}).get("budget_tokens", 63999)

    def normalize_effort(self, model_id: str, effort: Optional[str]) -> Optional[str]:
        """Clamp a CLI effort value to what `model_id` actually supports.

        Some Anthropic models accept fewer effort levels than others
        (e.g. Sonnet 4.6 has no `xhigh`). When a requested level is not in
        the model's whitelist we map it to the nearest supported level
        instead of letting the API reject the request.
        """
        if not effort:
            return effort
        spec = self.thinking.get(model_id, {})
        allowed = spec.get("effort_levels")
        if not allowed or effort in allowed:
            return effort
        rank = ["low", "medium", "high", "xhigh", "max"]
        if effort not in rank:
            return effort
        # Walk down the rank list to find the highest supported level
        # at or below the requested one; if none, walk up.
        idx = rank.index(effort)
        for cand in reversed(rank[: idx + 1]):
            if cand in allowed:
                return cand
        for cand in rank[idx + 1 :]:
            if cand in allowed:
                return cand
        return effort


@dataclass(frozen=True)
class PrefixesConfig:
    """Display prefixes for roles."""

    user: str
    assistant: str


@dataclass(frozen=True)
class ColorsConfig:
    """Color names for different elements."""

    user: str
    assistant: str
    thinking: str
    tool: str
    tool_path: str
    error: str
    warning: str
    system: str
    success: str


@dataclass(frozen=True)
class UIConfig:
    """UI display configuration."""

    divider_width: int
    show_compact_content: bool
    show_drop_indicator: bool
    show_think_content: bool
    prefixes: PrefixesConfig
    colors: ColorsConfig


@dataclass(frozen=True)
class AgentConfig:
    """Agent behavior configuration."""

    max_turns: int
    max_retries: int



@dataclass(frozen=True)
class WebSearchConfig:
    """Web search tool configuration."""

    max_results: int
    region: str


@dataclass(frozen=True)
class WebFetchConfig:
    """Web fetch tool configuration."""

    timeout: int
    content_limit: int


@dataclass(frozen=True)
class ToolsConfig:
    """Tool-related configuration."""

    dangerous_commands: frozenset
    web_search: WebSearchConfig
    web_fetch: WebFetchConfig
    shell_timeout: int = 120


@dataclass(frozen=True)
class CacheConfig:
    """Cache testing configuration."""

    message_overhead: int
    message_overhead_overrides: Dict[str, int]

    def overhead_for(self, model: str) -> int:
        """Return the framing overhead in tokens for a specific model."""
        return self.message_overhead_overrides.get(model, self.message_overhead)


@dataclass(frozen=True)
class Config:
    """Root configuration object."""

    models: ModelsConfig
    ui: UIConfig
    agent: AgentConfig
    tools: ToolsConfig
    cache: CacheConfig


# Color name to colorama mapping
_COLOR_MAP = {
    "BLACK": Fore.BLACK,
    "RED": Fore.RED,
    "GREEN": Fore.GREEN,
    "YELLOW": Fore.YELLOW,
    "BLUE": Fore.BLUE,
    "MAGENTA": Fore.MAGENTA,
    "CYAN": Fore.CYAN,
    "WHITE": Fore.WHITE,
    "RESET": Style.RESET_ALL,
}


def _load_config() -> Config:
    """Load configuration from YAML file bundled with the package."""
    config_path = Path(__file__).parent / "config.yaml"

    with open(config_path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)

    # Build nested config objects
    models = ModelsConfig(
        aliases=data["models"]["aliases"],
        providers=data["models"]["providers"],
        default=data["models"]["default"],
        limits={
            model: ModelLimits(**limits)
            for model, limits in data["models"]["limits"].items()
        },
        thinking=data["models"]["thinking"],
        pricing={
            model: ModelPricing(**pricing)
            for model, pricing in data["models"]["pricing"].items()
        },
        cache_requirements=data["models"]["cache_requirements"],
        openrouter_provider_pin=data["models"].get("openrouter_provider_pin", {}) or {},
    )

    tools = ToolsConfig(
        dangerous_commands=frozenset(data["tools"]["dangerous_commands"]),
        web_search=WebSearchConfig(**data["tools"]["web_search"]),
        web_fetch=WebFetchConfig(**data["tools"]["web_fetch"]),
        shell_timeout=int(data["tools"].get("shell_timeout", 120)),
    )

    ui = UIConfig(
        divider_width=data["ui"]["divider_width"],
        show_compact_content=data["ui"]["show_compact_content"],
        show_drop_indicator=data["ui"]["show_drop_indicator"],
        show_think_content=data["ui"].get("show_think_content", False),
        prefixes=PrefixesConfig(**data["ui"]["prefixes"]),
        colors=ColorsConfig(**data["ui"]["colors"]),
    )

    return Config(
        models=models,
        ui=ui,
        agent=AgentConfig(**data["agent"]),
        tools=tools,
        cache=CacheConfig(
            message_overhead=data["cache"]["message_overhead"],
            message_overhead_overrides=data["cache"].get("message_overhead_overrides", {}) or {},
        ),
    )


# Module-level singleton - loaded once on first import
config = _load_config()


def get_color(role: str) -> str:
    """Get colorama color code for a role.

    Args:
        role: One of 'user', 'assistant', 'thinking', 'tool', 'error', 'warning', 'system', 'success'

    Returns:
        Colorama color code (e.g., Fore.GREEN)
    """
    color_name = getattr(config.ui.colors, role, "RESET")
    return _COLOR_MAP.get(color_name.upper(), Style.RESET_ALL)


def _windows_documents_path() -> Optional[Path]:
    """Resolve Windows' Documents folder via SHGetKnownFolderPath.

    Honors OneDrive Known Folder Move (so users whose Documents are
    redirected to ``C:\\Users\\<u>\\OneDrive\\Documents`` get the redirected
    path, not the stale ``C:\\Users\\<u>\\Documents``). Returns None on any
    failure or non-Windows OS so the caller can fall back.
    """
    if os.name != "nt":
        return None
    try:
        import ctypes
        from ctypes import wintypes

        # FOLDERID_Documents - {FDD39AD0-238F-46AF-ADB4-6C85480369C7}
        class _GUID(ctypes.Structure):
            _fields_ = [
                ("Data1", wintypes.DWORD),
                ("Data2", wintypes.WORD),
                ("Data3", wintypes.WORD),
                ("Data4", ctypes.c_byte * 8),
            ]

        FOLDERID_Documents = _GUID(
            0xFDD39AD0,
            0x238F,
            0x46AF,
            (ctypes.c_byte * 8)(-83, -76, 0x6C, -123, 0x48, 0x03, 0x69, -57),
        )

        SHGetKnownFolderPath = ctypes.windll.shell32.SHGetKnownFolderPath
        SHGetKnownFolderPath.argtypes = [
            ctypes.POINTER(_GUID),
            wintypes.DWORD,
            wintypes.HANDLE,
            ctypes.POINTER(ctypes.c_wchar_p),
        ]
        SHGetKnownFolderPath.restype = ctypes.HRESULT

        path_ptr = ctypes.c_wchar_p()
        hr = SHGetKnownFolderPath(
            ctypes.byref(FOLDERID_Documents), 0, None, ctypes.byref(path_ptr)
        )
        if hr != 0 or not path_ptr.value:
            return None
        try:
            return Path(path_ptr.value)
        finally:
            ctypes.windll.ole32.CoTaskMemFree(path_ptr)
    except Exception:
        return None


def get_documents_dir() -> Path:
    """Return the user's Documents folder, honoring OneDrive redirection on Windows.

    Resolution order:
      1. Windows ``SHGetKnownFolderPath(FOLDERID_Documents)`` — returns the
         OneDrive-redirected path when Known Folder Move is enabled.
      2. ``$XDG_DOCUMENTS_DIR`` env var (Linux/macOS convention).
      3. ``~/Documents``.
    """
    win = _windows_documents_path()
    if win is not None and win.exists():
        return win
    xdg = os.environ.get("XDG_DOCUMENTS_DIR")
    if xdg:
        p = Path(os.path.expandvars(xdg)).expanduser()
        if p.exists():
            return p
    return Path.home() / "Documents"


def get_debug_dir(workspace_dir: str) -> Path:
    """Return the per-workspace debug directory under the user's Documents folder.

    Layout: <Documents>/ntn/<6-char-hash>/

    The hash of the absolute workspace path uniquely identifies the workspace.
    The directory is created if it does not exist.
    """
    import hashlib

    abs_ws = os.path.abspath(workspace_dir)
    digest = hashlib.sha1(abs_ws.encode("utf-8")).hexdigest()[:6]
    debug_dir = get_documents_dir() / "ntn" / digest
    debug_dir.mkdir(parents=True, exist_ok=True)
    return debug_dir
