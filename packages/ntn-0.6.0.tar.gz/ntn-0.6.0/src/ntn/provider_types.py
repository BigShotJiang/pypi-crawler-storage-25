"""Provider shared types.

Separated into its own module to avoid circular imports when providers are split
across files.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Dict, Generator, List, Optional


@dataclass
class Usage:
    """Unified token usage across providers."""

    input_tokens: int
    output_tokens: int
    cache_creation_input_tokens: int = 0
    cache_read_input_tokens: int = 0
    reasoning_tokens: int = 0
    # Anthropic-only: when cache_control uses different TTLs (5m vs 1h),
    # the API returns the breakdown in `cache_creation`. We track them
    # separately so we can price each at its own multiplier (1.25x vs 2x).
    # cache_creation_input_tokens == sum of these for Anthropic.
    # Other providers leave them at 0; their writes (if any) live in
    # cache_creation_input_tokens with cache_write priced at one rate.
    cache_creation_5m_tokens: int = 0
    cache_creation_1h_tokens: int = 0


@dataclass
class StreamEvent:
    """Unified streaming event."""

    type: str
    data: Any = None


@dataclass
class APIResponse:
    """Unified API response."""

    content: List[Dict]
    stop_reason: str
    usage: Usage
    raw_response: Any
    # Provider-native finish reason (e.g. OpenAI "length", "stop", "tool_calls").
    # Optional — Anthropic responses don't carry this; keep None for them.
    finish_reason: Optional[str] = None


class BaseProvider(ABC):
    """Base class for LLM providers."""

    # Optional per-session identifier used by some providers as a cache routing
    # key (e.g. OpenAI's `prompt_cache_key`). Subclasses should read self.session_id
    # in their create/stream calls if they support it. Default: None.
    session_id: Optional[str] = None

    def set_session_id(self, session_id: Optional[str]) -> None:
        """Attach a stable session identifier for cache routing."""
        self.session_id = session_id

    @abstractmethod
    def create(
        self,
        messages: List[Dict],
        system: str,
        tools: List[Dict],
        max_tokens: int,
        thinking_config: Optional[Dict] = None,
        effort: Optional[str] = None,
    ) -> APIResponse:
        pass

    @abstractmethod
    def stream(
        self,
        messages: List[Dict],
        system: str,
        tools: List[Dict],
        max_tokens: int,
        thinking_config: Optional[Dict] = None,
        effort: Optional[str] = None,
    ) -> Generator[StreamEvent, None, APIResponse]:
        pass

    @abstractmethod
    def count_tokens(self, messages: List[Dict], system: str, tools: List[Dict]) -> int:
        pass

    @abstractmethod
    def convert_tools(self, tools: List[Dict]) -> List[Dict]:
        pass

    @abstractmethod
    def get_rate_limit_info(self, response: Any) -> Dict:
        pass
