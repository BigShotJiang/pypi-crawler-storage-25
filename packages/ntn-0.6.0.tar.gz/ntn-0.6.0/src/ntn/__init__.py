"""NTN - Minimal AI coding agent"""

try:
    from ._version import __version__
except ImportError:
    __version__ = "0.1.0"  # Fallback for editable installs

__author__ = "NTN"

# Public API re-exports
from .agent import CodingAgent
from .ui import print_divider
from .tools import TerminalTool, WebSearchTool, FetchWebTool

__all__ = [
    "CodingAgent",
    "print_divider",
    "TerminalTool",
    "WebSearchTool",
    "FetchWebTool",
]
