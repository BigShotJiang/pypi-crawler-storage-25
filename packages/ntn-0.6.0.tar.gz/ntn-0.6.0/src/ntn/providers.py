"""Provider abstraction layer for LLM APIs."""

from __future__ import annotations

import json
import os
from typing import Any, Dict, Generator, List, Optional

from .provider_types import APIResponse, BaseProvider, StreamEvent, Usage
from .config import config


class AnthropicProvider(BaseProvider):
    """Anthropic Claude API provider."""

    def __init__(self, model: str):
        import anthropic

        self.client = anthropic.Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))
        self.model = model

    def create(
        self,
        messages: List[Dict],
        system: str,
        tools: List[Dict],
        max_tokens: int,
        thinking_config: Optional[Dict] = None,
        effort: Optional[str] = None,
    ) -> APIResponse:
        """Make non-streaming Anthropic API call."""
        kwargs = {
            "model": self.model,
            "max_tokens": max_tokens,
            "system": self._format_system(system),
            "tools": self.convert_tools(tools),
            "messages": self._inject_message_cache_control(messages),
        }
        if thinking_config:
            kwargs["thinking"] = thinking_config
        if effort:
            kwargs["output_config"] = {"effort": effort}

        response = self.client.messages.create(**kwargs)
        return self._normalize_response(response)

    def stream(
        self,
        messages: List[Dict],
        system: str,
        tools: List[Dict],
        max_tokens: int,
        thinking_config: Optional[Dict] = None,
        effort: Optional[str] = None,
    ) -> Generator[StreamEvent, None, APIResponse]:
        """Stream Anthropic API response."""
        kwargs = {
            "model": self.model,
            "max_tokens": max_tokens,
            "system": self._format_system(system),
            "tools": self.convert_tools(tools),
            "messages": self._inject_message_cache_control(messages),
        }
        if thinking_config:
            kwargs["thinking"] = thinking_config
        if effort:
            kwargs["output_config"] = {"effort": effort}

        with self.client.messages.stream(**kwargs) as stream:
            for event in stream:
                converted = self._convert_stream_event(event)
                if converted:
                    yield converted
            final_response = stream.get_final_message()
            raw_response = stream.response

        return self._normalize_response(final_response, raw_response)

    def count_tokens(
        self, messages: List[Dict], system: str, tools: List[Dict]
    ) -> int:
        """Count tokens using Anthropic API."""
        response = self.client.messages.count_tokens(
            model=self.model,
            system=self._format_system(system),
            tools=self.convert_tools(tools),
            messages=self._inject_message_cache_control(messages),
        )
        return response.input_tokens

    def convert_tools(self, tools: List[Dict]) -> List[Dict]:
        """Anthropic tools use input_schema. No cache_control needed here -
        the system breakpoint already caches everything before it (tools come
        before system in Anthropic's prefix order: tools -> system -> messages),
        which frees a breakpoint slot for the message-level cache.
        """
        if not tools:
            return []
        return [tool.copy() for tool in tools]

    def _format_system(self, system: str) -> List[Dict]:
        """Format system prompt with 1-hour cache control.

        System + tools are stable for the whole session, so 1h TTL pays off:
        write costs 2x base but reads are still 0.1x. A session that reuses
        the prefix more than ~1-2 times comes out ahead vs the 5m default.
        """
        return [{
            "type": "text",
            "text": system,
            "cache_control": {"type": "ephemeral", "ttl": "1h"},
        }]

    def _inject_message_cache_control(self, messages: List[Dict]) -> List[Dict]:
        """Add a 5-minute cache breakpoint on the last block of the last message.

        On turn N this writes a cache entry for the full prefix (tools + system
        + all prior messages). On turn N+1 the lookback (20-block window) finds
        that entry, so the entire growing conversation history gets billed at
        cache-read rates (0.1x base) instead of full input rates.

        Uses 5m TTL because messages turn over fast - paying 2x to write a 1h
        entry that's superseded next turn is wasteful. The 1h TTL stays on the
        static system prefix where it amortizes.
        """
        if not messages:
            return messages
        result = list(messages)
        last = dict(result[-1])
        content = last.get("content")
        if isinstance(content, str):
            last["content"] = [{
                "type": "text",
                "text": content,
                "cache_control": {"type": "ephemeral"},
            }]
        elif isinstance(content, list) and content:
            new_blocks = [dict(b) for b in content]
            new_blocks[-1] = {**new_blocks[-1], "cache_control": {"type": "ephemeral"}}
            last["content"] = new_blocks
        else:
            return messages
        result[-1] = last
        return result

    def _convert_stream_event(self, event) -> Optional[StreamEvent]:
        """Convert Anthropic stream event to unified format."""
        if event.type == "content_block_start":
            if hasattr(event, "content_block") and hasattr(event.content_block, "type"):
                if event.content_block.type in ("thinking", "redacted_thinking"):
                    return StreamEvent("thinking_start")
                elif event.content_block.type == "text":
                    return StreamEvent("text_start")
                elif event.content_block.type == "tool_use":
                    return StreamEvent(
                        "tool_use_start",
                        {"id": event.content_block.id, "name": event.content_block.name},
                    )
        elif event.type == "content_block_delta":
            if hasattr(event, "delta") and hasattr(event.delta, "type"):
                if event.delta.type == "thinking_delta":
                    return StreamEvent("thinking_delta", event.delta.thinking)
                elif event.delta.type == "signature_delta":
                    return StreamEvent("signature_delta", event.delta.signature)
                elif event.delta.type == "text_delta":
                    return StreamEvent("text_delta", event.delta.text)
                elif event.delta.type == "input_json_delta":
                    return StreamEvent("tool_input_delta", event.delta.partial_json)
        elif event.type == "content_block_stop":
            return StreamEvent("content_block_stop")

        return None

    def _normalize_response(
        self, response, raw_response=None
    ) -> APIResponse:
        """Convert Anthropic response to unified format."""
        content = []
        for block in response.content:
            if block.type == "thinking":
                thinking_block = {"type": "thinking", "thinking": block.thinking}
                if hasattr(block, "signature") and block.signature:
                    thinking_block["signature"] = block.signature
                content.append(thinking_block)
            elif block.type == "redacted_thinking":
                # Encrypted thinking block — must be preserved unchanged so the
                # server can reconstruct reasoning context on the next turn
                # (e.g. during interleaved tool use). Don't try to decode `data`.
                content.append({"type": "redacted_thinking", "data": getattr(block, "data", "")})
            elif hasattr(block, "text"):
                content.append({"type": "text", "text": block.text})
            elif block.type == "tool_use":
                content.append(
                    {
                        "type": "tool_use",
                        "id": block.id,
                        "name": block.name,
                        "input": block.input,
                    }
                )

        # Anthropic returns either a flat `cache_creation_input_tokens` int OR
        # a structured `cache_creation` dict with `ephemeral_5m_input_tokens`
        # + `ephemeral_1h_input_tokens` (when the request mixes TTLs, like our
        # 1h-system + 5m-last-message setup). Capture both so we can price
        # each TTL bucket at its own write rate.
        cc_total = getattr(response.usage, "cache_creation_input_tokens", 0) or 0
        cc_obj = getattr(response.usage, "cache_creation", None)
        cc_5m = 0
        cc_1h = 0
        if cc_obj is not None:
            cc_5m = getattr(cc_obj, "ephemeral_5m_input_tokens", None)
            cc_1h = getattr(cc_obj, "ephemeral_1h_input_tokens", None)
            if cc_5m is None and isinstance(cc_obj, dict):
                cc_5m = cc_obj.get("ephemeral_5m_input_tokens", 0)
                cc_1h = cc_obj.get("ephemeral_1h_input_tokens", 0)
            cc_5m = cc_5m or 0
            cc_1h = cc_1h or 0
        # Fallback when only the flat total is reported: bucket everything
        # into 5m (the default TTL) so we don't undercount, but the agent
        # specifically uses 1h on system + 5m on last message, so this should
        # rarely fire on a current SDK.
        if cc_total and not (cc_5m + cc_1h):
            cc_5m = cc_total

        usage = Usage(
            input_tokens=getattr(response.usage, "input_tokens", 0) or 0,
            output_tokens=getattr(response.usage, "output_tokens", 0) or 0,
            cache_creation_input_tokens=cc_5m + cc_1h,
            cache_read_input_tokens=getattr(
                response.usage, "cache_read_input_tokens", 0
            )
            or 0,
            cache_creation_5m_tokens=cc_5m,
            cache_creation_1h_tokens=cc_1h,
        )

        return APIResponse(
            content=content,
            stop_reason=response.stop_reason,
            usage=usage,
            raw_response=raw_response or response,
        )

    def get_rate_limit_info(self, response: Any) -> Dict:
        """Extract Anthropic rate limit headers."""
        headers = {}
        if hasattr(response, "headers"):
            headers = response.headers
        elif hasattr(response, "_raw_response") and response._raw_response:
            headers = response._raw_response.headers

        def get_int(key):
            val = headers.get(key)
            return int(val) if val else None

        return {
            "request_limit": get_int("anthropic-ratelimit-requests-limit"),
            "request_remaining": get_int("anthropic-ratelimit-requests-remaining"),
            "input_limit": get_int("anthropic-ratelimit-input-tokens-limit"),
            "input_remaining": get_int("anthropic-ratelimit-input-tokens-remaining"),
            "output_limit": get_int("anthropic-ratelimit-output-tokens-limit"),
            "output_remaining": get_int("anthropic-ratelimit-output-tokens-remaining"),
        }


class OpenAIProvider(BaseProvider):
    """OpenAI GPT API provider using Responses API.

    This enables:
    - reasoning token accounting via usage.output_tokens_details.reasoning_tokens
    - optional reasoning summaries ("thinking content") when requested
    - tool calling via output items of type "function_call"
    - streaming deltas for both assistant text and reasoning summaries
    """

    def __init__(self, model: str):
        import openai
        import tiktoken

        self.client = openai.OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
        self.model = model
        self.encoding = tiktoken.get_encoding("cl100k_base")

    def create(
        self,
        messages: List[Dict],
        system: str,
        tools: List[Dict],
        max_tokens: int,
        thinking_config: Optional[Dict] = None,
        effort: Optional[str] = None,
    ) -> APIResponse:
        """Make non-streaming OpenAI API call using Responses API."""
        reasoning = self._build_reasoning(thinking_config, effort)
        kwargs: Dict[str, Any] = {
            "model": self.model,
            "instructions": system,
            "input": self._convert_messages(messages),
            "reasoning": reasoning,
            "max_output_tokens": max_tokens,
            # Request encrypted reasoning state so we can round-trip the
            # model's chain of thought across tool-call turns without
            # using server-side conversation storage.
            "include": ["reasoning.encrypted_content"],
        }
        self._apply_cache_kwargs(kwargs)
        # Per Responses API: only send `tools`/`tool_choice` when we actually
        # have tools. Sending tools=[] with tool_choice="none" is technically
        # accepted but inconsistent and some intermediaries 400 on it.
        if tools:
            kwargs["tools"] = self.convert_tools(tools)
            kwargs["tool_choice"] = "auto"
        resp = self.client.responses.create(**kwargs)
        return self._normalize_response(resp)

    def stream(
        self,
        messages: List[Dict],
        system: str,
        tools: List[Dict],
        max_tokens: int,
        thinking_config: Optional[Dict] = None,
        effort: Optional[str] = None,
    ) -> Generator[StreamEvent, None, APIResponse]:
        """Stream OpenAI API response using Responses API."""
        reasoning = self._build_reasoning(thinking_config, effort)
        kwargs: Dict[str, Any] = {
            "model": self.model,
            "instructions": system,
            "input": self._convert_messages(messages),
            "reasoning": reasoning,
            "max_output_tokens": max_tokens,
            "include": ["reasoning.encrypted_content"],
            "stream": True,
        }
        self._apply_cache_kwargs(kwargs)
        if tools:
            kwargs["tools"] = self.convert_tools(tools)
            kwargs["tool_choice"] = "auto"
        stream = self.client.responses.create(**kwargs)

        import openai.types.responses as r

        text_started = False
        thinking_started = False
        first_summary_part = True
        final_response = None

        for ev in stream:
            if isinstance(ev, r.ResponseCompletedEvent):
                final_response = ev.response
                continue

            # Reasoning summary stream -> thinking
            # OpenAI Responses API emits multiple `summary_text` parts within
            # one reasoning item. Treat them all as a single thinking block:
            # only emit `thinking_start` once and put a blank-line separator
            # between parts. Otherwise the agent would record one thinking
            # block per part (often 30-50 per turn), bloating context and
            # spamming the UI with duplicate "🧠 Thinking:" headers.
            if isinstance(ev, r.ResponseReasoningSummaryPartAddedEvent):
                if not thinking_started:
                    thinking_started = True
                    first_summary_part = True
                    yield StreamEvent("thinking_start")
                elif not first_summary_part:
                    yield StreamEvent("thinking_delta", "\n\n")
                first_summary_part = False
                continue

            if isinstance(ev, r.ResponseReasoningSummaryTextDeltaEvent):
                if not thinking_started:
                    thinking_started = True
                    first_summary_part = False
                    yield StreamEvent("thinking_start")
                yield StreamEvent("thinking_delta", ev.delta)
                continue

            if isinstance(ev, r.ResponseReasoningSummaryTextDoneEvent):
                # Don't close the block here; wait for text/tool/stream-end.
                continue

            # Raw reasoning text (distinct from summary parts). Newer GPT-5
            # builds may emit these alongside or instead of summary text;
            # treat them identically so we don't silently drop tokens.
            if isinstance(ev, r.ResponseReasoningTextDeltaEvent):
                if not thinking_started:
                    thinking_started = True
                    first_summary_part = False
                    yield StreamEvent("thinking_start")
                yield StreamEvent("thinking_delta", ev.delta)
                continue

            if isinstance(ev, r.ResponseReasoningTextDoneEvent):
                continue

            # Visible assistant text
            if isinstance(ev, r.ResponseTextDeltaEvent):
                if thinking_started:
                    thinking_started = False
                    yield StreamEvent("content_block_stop")
                if not text_started:
                    text_started = True
                    yield StreamEvent("text_start")
                yield StreamEvent("text_delta", ev.delta)
                continue

            if isinstance(ev, r.ResponseTextDoneEvent):
                if text_started:
                    text_started = False
                    yield StreamEvent("content_block_stop")
                continue

            # Refusal content (message blocks may contain `refusal` parts).
            # Surface as text so the user sees why the model declined instead
            # of getting a silent empty response.
            if isinstance(ev, r.ResponseRefusalDeltaEvent):
                if thinking_started:
                    thinking_started = False
                    yield StreamEvent("content_block_stop")
                if not text_started:
                    text_started = True
                    yield StreamEvent("text_start")
                yield StreamEvent("text_delta", ev.delta)
                continue

            if isinstance(ev, r.ResponseRefusalDoneEvent):
                continue

            # Tool calling
            if isinstance(ev, r.ResponseOutputItemAddedEvent):
                item = ev.item
                if getattr(item, "type", None) == "function_call":
                    # Close the thinking block before tool use so the
                    # accumulator persists it as a single block.
                    if thinking_started:
                        thinking_started = False
                        yield StreamEvent("content_block_stop")
                    yield StreamEvent("tool_use_start", {"id": item.call_id, "name": item.name})
                continue

            if isinstance(ev, r.ResponseFunctionCallArgumentsDeltaEvent):
                yield StreamEvent("tool_input_delta", ev.delta)
                continue

            if isinstance(ev, r.ResponseFunctionCallArgumentsDoneEvent):
                yield StreamEvent("content_block_stop")
                continue

            # Reasoning state for round-tripping. The reasoning item is
            # finalized in ResponseOutputItemDoneEvent and (when the request
            # included `reasoning.encrypted_content`) carries an
            # `encrypted_content` blob plus its `id` and `summary` parts.
            # We append the item verbatim into content_list via raw_block so
            # `_convert_messages` can re-emit it on the next turn, letting
            # the model statelessly continue its chain of thought across
            # tool-call boundaries.
            if isinstance(ev, r.ResponseOutputItemDoneEvent):
                item = getattr(ev, "item", None)
                if item is not None and getattr(item, "type", None) == "reasoning":
                    enc = getattr(item, "encrypted_content", None)
                    rid = getattr(item, "id", None)
                    if enc and rid:
                        # Serialize summary parts to plain dicts so the block
                        # is JSON-safe (it ends up in self.messages).
                        summary_dump: list[dict] = []
                        for part in getattr(item, "summary", None) or []:
                            if isinstance(part, dict):
                                summary_dump.append(part)
                            elif hasattr(part, "model_dump"):
                                summary_dump.append(part.model_dump())
                        block = {
                            "type": "_openai_reasoning_item",
                            "id": rid,
                            "encrypted_content": enc,
                            "summary": summary_dump,
                        }
                        yield StreamEvent("raw_block", block)
                continue

        # Close any open block
        if thinking_started or text_started:
            yield StreamEvent("content_block_stop")

        if final_response is None:
            usage = Usage(0, 0, 0, 0, 0)
            return APIResponse(content=[], stop_reason="end_turn", usage=usage, raw_response=getattr(stream, "response", None))

        return self._normalize_response(final_response)

    def count_tokens(self, messages: List[Dict], system: str, tools: List[Dict]) -> int:
        """Approximate token count using chat-style formula."""
        num_tokens = 0
        num_tokens += 3
        num_tokens += len(self.encoding.encode(system))
        for message in messages:
            num_tokens += 3
            for key, value in message.items():
                if isinstance(value, str):
                    num_tokens += len(self.encoding.encode(value))
                elif isinstance(value, list):
                    for item in value:
                        if isinstance(item, dict):
                            if "text" in item:
                                num_tokens += len(self.encoding.encode(item["text"]))
                            elif "content" in item:
                                num_tokens += len(self.encoding.encode(str(item["content"])))
                            else:
                                num_tokens += len(self.encoding.encode(json.dumps(item)))
                if key == "name":
                    num_tokens += 1
        num_tokens += 3
        return num_tokens

    def convert_tools(self, tools: List[Dict]) -> List[Dict]:
        """Convert Anthropic tool format to Responses API function format."""
        converted = []
        for tool in tools:
            converted.append(
                {
                    "type": "function",
                    "name": tool["name"],
                    "description": tool.get("description", ""),
                    "parameters": tool.get("input_schema", {}),
                }
            )
        return converted

    def get_rate_limit_info(self, response: Any) -> Dict:
        """Extract OpenAI rate limit headers."""
        headers = {}
        if hasattr(response, "headers"):
            headers = response.headers
        elif hasattr(response, "response") and getattr(response, "response") is not None:
            headers = response.response.headers

        def get_int(key: str):
            val = headers.get(key)
            return int(val) if val else None

        return {
            "request_limit": get_int("x-ratelimit-limit-requests"),
            "request_remaining": get_int("x-ratelimit-remaining-requests"),
            "input_limit": get_int("x-ratelimit-limit-tokens"),
            "input_remaining": get_int("x-ratelimit-remaining-tokens"),
            "output_limit": None,
            "output_remaining": None,
        }

    def _apply_cache_kwargs(self, kwargs: Dict[str, Any]) -> None:
        """Attach prompt-cache hints to a Responses API request.

        OpenAI prompt caching is automatic at >=1024 input tokens, but two
        knobs measurably improve hit rate:
          * ``prompt_cache_retention="24h"`` extends key/value retention from
            ~5–10 min in-memory up to 24h on GPU-local storage. Free of
            charge. For ``gpt-5.5`` / future models 24h is already the
            default; sending it explicitly is a no-op there.
          * ``prompt_cache_key=<session_id>`` is mixed into the routing
            hash so requests sharing our long static prefix (instructions +
            tools) consistently land on the same backend, keeping the
            cache warm for the whole session.
        """
        # 24h retention is supported on every gpt-5.x family member; cheaply
        # safe to send to gpt-4.1 too.
        kwargs["prompt_cache_retention"] = "24h"
        if self.session_id:
            kwargs["prompt_cache_key"] = self.session_id

    def _build_reasoning(self, thinking_config: Optional[Dict], effort: Optional[str] = None) -> Dict:
        """Build reasoning configuration for Responses API.

        Priority: explicit `effort` arg (from CLI -e) > derived from thinking_config
        budget. Maps Anthropic-style CLI values to OpenAI's accepted set.

        Mapping (per user spec; applies to all gpt-5.x models):
            low      -> medium   (gpt-5.x rejects 'low')
            max      -> xhigh    (OpenAI's max-equivalent)
            medium / high / xhigh -> passthrough
            minimal  -> medium   (also rejected)
        """
        cli_to_openai = {"low": "medium", "minimal": "medium", "medium": "medium",
                         "high": "high", "xhigh": "xhigh", "max": "xhigh"}

        if effort and effort in cli_to_openai:
            chosen = cli_to_openai[effort]
        elif not thinking_config:
            chosen = "medium"
        else:
            budget = thinking_config.get("budget_tokens", 0)
            if budget > 50000:
                chosen = "high"
            elif budget > 20000:
                chosen = "medium"
            else:
                chosen = "medium"  # was "low" but OpenAI rejects it on gpt-5.x

        return {"effort": chosen, "summary": "auto"}

    @staticmethod
    def map_cli_effort(cli_effort: str) -> str:
        """Public helper for CLI banner: show the effort actually sent to OpenAI."""
        return {"low": "medium", "minimal": "medium", "medium": "medium",
                "high": "high", "xhigh": "xhigh", "max": "xhigh"}.get(cli_effort, cli_effort)

    def _convert_messages(self, messages: List[Dict]) -> List[Dict]:
        """Convert messages from Anthropic to Responses API format."""
        items = []
        for msg in messages:
            role = msg.get("role")
            content = msg.get("content")

            if role == "user":
                if isinstance(content, str):
                    items.append({"role": "user", "content": content})
                elif isinstance(content, list) and content and content[0].get("type") == "tool_result":
                    for tr in content:
                        items.append(
                            {
                                "type": "function_call_output",
                                "call_id": tr.get("tool_use_id"),
                                "output": str(tr.get("content", "")),
                            }
                        )
                else:
                    items.append({"role": "user", "content": json.dumps(content)})

            elif role == "assistant":
                if isinstance(content, str):
                    items.append({"role": "assistant", "content": content})
                elif isinstance(content, list):
                    for block in content:
                        btype = block.get("type")
                        if btype == "tool_use":
                            items.append(
                                {
                                    "type": "function_call",
                                    "call_id": block.get("id"),
                                    "name": block.get("name"),
                                    "arguments": json.dumps(block.get("input", {})),
                                }
                            )
                        elif btype == "text":
                            items.append({"role": "assistant", "content": block.get("text", "")})
                        elif btype == "_openai_reasoning_item":
                            # Re-emit a reasoning item the server can decrypt
                            # to restore prior chain-of-thought context. Only
                            # `id`, `summary`, and `encrypted_content` are
                            # needed; per Responses API the server uses the
                            # encrypted blob to reconstruct the full state.
                            ri: Dict[str, Any] = {
                                "type": "reasoning",
                                "id": block.get("id"),
                                "summary": block.get("summary") or [],
                            }
                            enc = block.get("encrypted_content")
                            if enc:
                                ri["encrypted_content"] = enc
                            items.append(ri)
                        # display-only thinking blocks omitted

        return items

    def _normalize_response(self, response: Any) -> APIResponse:
        """Convert Responses API response to unified format."""
        content = []

        # 1) thinking summary (if any) - collapse all reasoning items
        # AND all summary parts into a single thinking block per response
        # to match streaming behavior and avoid bloating message history.
        # In parallel, capture each reasoning item's encrypted_content (when
        # the request asked for it via include=) as an opaque round-trip
        # block so the next turn can hand the model back its prior state.
        all_summary_texts: list[str] = []
        for item in getattr(response, "output", []) or []:
            if getattr(item, "type", None) == "reasoning":
                summary_parts = getattr(item, "summary", None) or []
                summary_dump: list[dict] = []
                for part in summary_parts:
                    if isinstance(part, dict):
                        if part.get("type") == "summary_text":
                            all_summary_texts.append(part.get("text", ""))
                        summary_dump.append(part)
                    else:
                        if getattr(part, "type", None) == "summary_text":
                            all_summary_texts.append(getattr(part, "text", ""))
                        if hasattr(part, "model_dump"):
                            summary_dump.append(part.model_dump())
                # Newer reasoning items may also carry a `content` array of
                # `reasoning_text` parts (raw, non-summarized). Collect them
                # so we don't lose tokens when models emit both shapes.
                content_parts = getattr(item, "content", None) or []
                for part in content_parts:
                    if isinstance(part, dict):
                        if part.get("type") == "reasoning_text":
                            all_summary_texts.append(part.get("text", ""))
                    else:
                        if getattr(part, "type", None) == "reasoning_text":
                            all_summary_texts.append(getattr(part, "text", ""))
                enc = getattr(item, "encrypted_content", None)
                rid = getattr(item, "id", None)
                if enc and rid:
                    content.append(
                        {
                            "type": "_openai_reasoning_item",
                            "id": rid,
                            "encrypted_content": enc,
                            "summary": summary_dump,
                        }
                    )
        if all_summary_texts:
            content.append(
                {
                    "type": "thinking",
                    "thinking": "\n\n".join(all_summary_texts),
                    "signature": "openai_summary",
                }
            )

        # 2) tool calls
        for item in getattr(response, "output", []) or []:
            if getattr(item, "type", None) == "function_call":
                try:
                    args = json.loads(getattr(item, "arguments", "") or "{}")
                except Exception:
                    args = {}
                content.append(
                    {
                        "type": "tool_use",
                        "id": getattr(item, "call_id", ""),
                        "name": getattr(item, "name", ""),
                        "input": args,
                    }
                )

        # 3) assistant text (and refusals, surfaced as text)
        for item in getattr(response, "output", []) or []:
            if getattr(item, "type", None) == "message" and getattr(item, "role", None) == "assistant":
                for part in getattr(item, "content", []) or []:
                    pt = getattr(part, "type", None)
                    if pt == "output_text":
                        content.append({"type": "text", "text": getattr(part, "text", "")})
                    elif pt == "refusal":
                        # Surface refusal as visible text so the agent loop
                        # doesn't end with an empty assistant turn.
                        refusal_text = getattr(part, "refusal", "") or ""
                        if refusal_text:
                            content.append({"type": "text", "text": refusal_text})

        usage_obj = getattr(response, "usage", None)
        cached_tokens = (
            getattr(getattr(usage_obj, "input_tokens_details", None), "cached_tokens", 0) if usage_obj else 0
        )
        reasoning_tokens = (
            getattr(getattr(usage_obj, "output_tokens_details", None), "reasoning_tokens", 0) if usage_obj else 0
        )

        usage = Usage(
            input_tokens=getattr(usage_obj, "input_tokens", 0) or 0,
            output_tokens=getattr(usage_obj, "output_tokens", 0) or 0,
            cache_creation_input_tokens=0,
            cache_read_input_tokens=cached_tokens or 0,
            reasoning_tokens=reasoning_tokens or 0,
        )

        # Surface non-success terminal states so the agent loop doesn't
        # treat an empty/partial response as a clean completion. Per
        # Responses API: status ∈ {completed, in_progress, incomplete,
        # failed, cancelled, queued}; `incomplete_details.reason` ∈
        # {max_output_tokens, content_filter}; `error.message` populated
        # when status="failed".
        status = getattr(response, "status", None)
        incomplete = getattr(response, "incomplete_details", None)
        err = getattr(response, "error", None)
        has_tool_use = any(b.get("type") == "tool_use" for b in content)

        if status == "failed" and err is not None:
            err_msg = getattr(err, "message", None) or str(err)
            content.append({"type": "text", "text": f"[OpenAI error] {err_msg}"})
            stop_reason = "stop_sequence"
        elif status == "incomplete" and incomplete is not None:
            reason = getattr(incomplete, "reason", None)
            if reason == "max_output_tokens":
                stop_reason = "max_tokens"
            elif reason == "content_filter":
                stop_reason = "stop_sequence"
            else:
                stop_reason = "tool_use" if has_tool_use else "end_turn"
        elif status == "cancelled":
            stop_reason = "stop_sequence"
        else:
            stop_reason = "tool_use" if has_tool_use else "end_turn"
        return APIResponse(content=content, stop_reason=stop_reason, usage=usage, raw_response=response)


def create_provider(model_id: str, provider_name: str) -> BaseProvider:
    """Factory function to create the appropriate provider."""
    if provider_name == "openai":
        return OpenAIProvider(model_id)
    if provider_name == "openrouter":
        return OpenRouterProvider(model_id)
    return AnthropicProvider(model_id)


class OpenRouterProvider(BaseProvider):
    """OpenRouter provider (OpenAI-compatible Chat Completions API).

    Used for models like moonshotai/kimi-k2:free that aren't available on the
    Anthropic / native-OpenAI APIs. Talks to /v1/chat/completions, NOT the
    OpenAI Responses API.
    """

    BASE_URL = "https://openrouter.ai/api/v1"

    def __init__(self, model: str):
        import openai
        import tiktoken

        self.client = openai.OpenAI(
            api_key=os.getenv("OPENROUTER_API_KEY"),
            base_url=self.BASE_URL,
            default_headers={
                "HTTP-Referer": "https://github.com/ntnghia/coding-agent",
                "X-Title": "ntn",
            },
        )
        self.model = model
        self.encoding = tiktoken.get_encoding("cl100k_base")

    # ---- public API ---------------------------------------------------

    def create(
        self,
        messages: List[Dict],
        system: str,
        tools: List[Dict],
        max_tokens: int,
        thinking_config: Optional[Dict] = None,
        effort: Optional[str] = None,
    ) -> APIResponse:
        kwargs = self._build_kwargs(messages, system, tools, max_tokens, thinking_config, effort)
        resp = self.client.chat.completions.create(**kwargs)
        return self._normalize_response(resp)

    def stream(
        self,
        messages: List[Dict],
        system: str,
        tools: List[Dict],
        max_tokens: int,
        thinking_config: Optional[Dict] = None,
        effort: Optional[str] = None,
    ) -> Generator[StreamEvent, None, APIResponse]:
        kwargs = self._build_kwargs(messages, system, tools, max_tokens, thinking_config, effort)
        kwargs["stream"] = True
        kwargs["stream_options"] = {"include_usage": True}
        stream = self.client.chat.completions.create(**kwargs)

        # Block lifecycle: emit thinking_start once we see reasoning, text_start
        # once we see content, content_block_stop when transitioning between
        # block types. Tool calls are tracked per index with separate
        # start/input_delta/stop events.
        # current_block: None | "thinking" | "text" | ("tool", idx)
        current_block: Any = None
        # idx -> {"id":..., "name":..., "started":bool}
        tool_state: Dict[int, Dict[str, Any]] = {}
        any_tool_started = False
        finish_reason = None
        usage_obj = None
        # Some OpenRouter reasoning models stream `reasoning_details` (list of
        # structured per-step objects) on the delta. Accumulate them so we
        # can attach the full list to the assistant turn for round-tripping
        # on the next call.
        rd_acc: List[Dict[str, Any]] = []

        def close_current():
            nonlocal current_block
            if current_block is not None:
                current_block = None
                return [StreamEvent(type="content_block_stop")]
            return []

        for chunk in stream:
            choices = getattr(chunk, "choices", None) or []
            if choices:
                choice = choices[0]
                delta = getattr(choice, "delta", None)
                if delta is not None:
                    rtxt = getattr(delta, "reasoning", None)
                    text = getattr(delta, "content", None)
                    refusal = getattr(delta, "refusal", None)
                    tcs = getattr(delta, "tool_calls", None) or []
                    rd = getattr(delta, "reasoning_details", None)
                    if isinstance(rd, list):
                        for item in rd:
                            if isinstance(item, dict):
                                rd_acc.append(item)
                            elif hasattr(item, "model_dump"):
                                rd_acc.append(item.model_dump())

                    if isinstance(rtxt, str) and rtxt:
                        if current_block != "thinking":
                            for ev in close_current():
                                yield ev
                            yield StreamEvent(type="thinking_start")
                            current_block = "thinking"
                        yield StreamEvent(type="thinking_delta", data=rtxt)

                    # Treat refusal text the same as content so the user sees
                    # why the model declined rather than getting nothing.
                    if isinstance(refusal, str) and refusal:
                        if current_block != "text":
                            for ev in close_current():
                                yield ev
                            yield StreamEvent(type="text_start")
                            current_block = "text"
                        yield StreamEvent(type="text_delta", data=refusal)

                    if isinstance(text, str) and text:
                        if current_block != "text":
                            for ev in close_current():
                                yield ev
                            yield StreamEvent(type="text_start")
                            current_block = "text"
                        yield StreamEvent(type="text_delta", data=text)

                    for tc in tcs:
                        idx = getattr(tc, "index", 0) or 0
                        slot = tool_state.setdefault(
                            idx, {"id": "", "name": "", "started": False}
                        )
                        if getattr(tc, "id", None):
                            slot["id"] = tc.id
                        fn = getattr(tc, "function", None)
                        arg_chunk = ""
                        if fn is not None:
                            if getattr(fn, "name", None):
                                slot["name"] = fn.name
                            arg_chunk = getattr(fn, "arguments", None) or ""
                        # Start the tool block if ready and we're not already in it
                        if not slot["started"] and slot["id"] and slot["name"]:
                            if current_block != ("tool", idx):
                                for ev in close_current():
                                    yield ev
                                yield StreamEvent(
                                    type="tool_use_start",
                                    data={"id": slot["id"], "name": slot["name"]},
                                )
                                current_block = ("tool", idx)
                            slot["started"] = True
                            any_tool_started = True
                        elif slot["started"] and current_block != ("tool", idx):
                            # Resuming a different tool index? Switch blocks.
                            for ev in close_current():
                                yield ev
                            yield StreamEvent(
                                type="tool_use_start",
                                data={"id": slot["id"], "name": slot["name"]},
                            )
                            current_block = ("tool", idx)
                        if arg_chunk and slot["started"] and current_block == ("tool", idx):
                            yield StreamEvent(type="tool_input_delta", data=arg_chunk)

                fr = getattr(choice, "finish_reason", None)
                if fr:
                    finish_reason = fr
            if getattr(chunk, "usage", None):
                usage_obj = chunk.usage

        for ev in close_current():
            yield ev

        if rd_acc:
            yield StreamEvent(type="raw_block", data={"type": "_openrouter_reasoning_details", "data": rd_acc})

        usage = self._usage_from(usage_obj)
        stop_reason = self._map_stop_reason(finish_reason, any_tool_started)
        # raw_response is None for streaming (the SDK doesn't expose the
        # underlying httpx response on the iterator); we attach finish_reason
        # so the agent can still surface why a turn ended.
        return APIResponse(
            content=[],
            stop_reason=stop_reason,
            usage=usage,
            raw_response=None,
            finish_reason=finish_reason,
        )

    def count_tokens(self, messages: List[Dict], system: str, tools: List[Dict]) -> int:
        """Approximate token count using tiktoken cl100k_base."""
        n = 3 + len(self.encoding.encode(system or ""))
        for msg in messages:
            n += 3
            content = msg.get("content")
            if isinstance(content, str):
                n += len(self.encoding.encode(content))
            elif isinstance(content, list):
                for item in content:
                    if isinstance(item, dict):
                        if "text" in item:
                            n += len(self.encoding.encode(item["text"]))
                        elif "content" in item:
                            n += len(self.encoding.encode(str(item["content"])))
                        else:
                            n += len(self.encoding.encode(json.dumps(item)))
        for t in tools or []:
            n += len(self.encoding.encode(json.dumps(t)))
        return n + 3

    def convert_tools(self, tools: List[Dict]) -> List[Dict]:
        """Anthropic tool schema -> OpenAI Chat Completions function format."""
        out = []
        for tool in tools:
            out.append(
                {
                    "type": "function",
                    "function": {
                        "name": tool["name"],
                        "description": tool.get("description", ""),
                        "parameters": tool.get("input_schema", {}),
                    },
                }
            )
        return out

    def get_rate_limit_info(self, response: Any) -> Dict:
        headers = {}
        if hasattr(response, "headers"):
            headers = response.headers
        elif hasattr(response, "response") and getattr(response, "response") is not None:
            headers = response.response.headers

        def get_int(key: str):
            val = headers.get(key) if headers else None
            return int(val) if val else None

        return {
            "request_limit": get_int("x-ratelimit-limit"),
            "request_remaining": get_int("x-ratelimit-remaining"),
            "input_limit": None,
            "input_remaining": None,
            "output_limit": None,
            "output_remaining": None,
        }

    # ---- helpers ------------------------------------------------------

    def _build_kwargs(
        self,
        messages,
        system,
        tools,
        max_tokens,
        thinking_config: Optional[Dict] = None,
        effort: Optional[str] = None,
    ) -> Dict:
        chat_messages = [{"role": "system", "content": system}] if system else []
        chat_messages.extend(self._convert_messages(messages))
        kwargs: Dict[str, Any] = {
            "model": self.model,
            "messages": chat_messages,
            # `max_tokens` is deprecated in OpenRouter's Chat Completions schema
            # (per docs: "Maximum tokens (deprecated, use max_completion_tokens)").
            "max_completion_tokens": max_tokens,
            # OpenRouter strips per-provider usage details by default. Opting
            # into `usage.include` surfaces `prompt_tokens_details.cached_tokens`
            # / `cache_write_tokens`, which is how DeepSeek/Moonshot/Grok auto
            # caching becomes visible in our metrics + cost calc.
            "extra_body": {"usage": {"include": True}},
        }
        # Pin sub-provider when configured. OpenRouter would otherwise route
        # to whichever endpoint it picks (often a more expensive one or one
        # that fails over mid-call), invalidating our pricing assumptions.
        # `allow_fallbacks=False` makes the request fail loudly instead of
        # silently switching providers.
        try:
            pin_map = config.models.openrouter_provider_pin or {}
        except Exception:
            pin_map = {}
        pinned = pin_map.get(self.model)
        if pinned:
            kwargs["extra_body"]["provider"] = {
                "order": [pinned],
                "allow_fallbacks": False,
            }
        if tools:
            kwargs["tools"] = self.convert_tools(tools)
            kwargs["tool_choice"] = "auto"
        # OpenRouter supports a unified `reasoning` param across providers.
        # Only attach when the model has reasoning enabled (mode != "none")
        # and an effort value was supplied; otherwise the model decides.
        if thinking_config:
            mode = thinking_config.get("mode")
            if mode and mode != "none" and effort:
                # OpenRouter exposes effort levels: xhigh|high|medium|low|minimal|none.
                # Our internal `max` is the highest tier — map it to `xhigh`.
                or_effort = "xhigh" if effort == "max" else effort
                kwargs["reasoning"] = {"effort": or_effort}
        return kwargs

    def _convert_messages(self, messages: List[Dict]) -> List[Dict]:
        """Anthropic content blocks -> Chat Completions messages."""
        out: List[Dict] = []
        for msg in messages:
            role = msg.get("role")
            content = msg.get("content")

            if role == "user":
                if isinstance(content, str):
                    out.append({"role": "user", "content": content})
                elif isinstance(content, list):
                    # Tool results become role:tool messages; non-tool blocks
                    # (text, etc.) carry over as a separate user message so we
                    # don't silently drop user-provided context.
                    text_parts = []
                    for blk in content:
                        if blk.get("type") == "tool_result":
                            tool_call_id = blk.get("tool_use_id") or ""
                            if not tool_call_id:
                                # Without a call id Chat Completions rejects
                                # the tool message; surface as user text.
                                text_parts.append(
                                    f"[tool_result without id]: "
                                    f"{_stringify_tool_result(blk.get('content', ''))}"
                                )
                                continue
                            out.append(
                                {
                                    "role": "tool",
                                    "tool_call_id": tool_call_id,
                                    "content": _stringify_tool_result(blk.get("content", "")),
                                }
                            )
                        elif blk.get("type") == "text":
                            text_parts.append(blk.get("text", ""))
                    if text_parts:
                        out.append({"role": "user", "content": "\n".join(text_parts)})

            elif role == "assistant":
                if isinstance(content, str):
                    out.append({"role": "assistant", "content": content})
                elif isinstance(content, list):
                    text_parts = []
                    tool_calls = []
                    rd_payload: Optional[List[Dict[str, Any]]] = None
                    for blk in content:
                        t = blk.get("type")
                        if t == "text":
                            text_parts.append(blk.get("text", ""))
                        elif t == "tool_use":
                            tool_calls.append(
                                {
                                    "id": blk.get("id", ""),
                                    "type": "function",
                                    "function": {
                                        "name": blk.get("name", ""),
                                        "arguments": json.dumps(blk.get("input", {})),
                                    },
                                }
                            )
                        elif t == "_openrouter_reasoning_details":
                            data = blk.get("data")
                            if isinstance(data, list) and data:
                                rd_payload = data
                        # thinking blocks omitted — most OpenRouter models
                        # don't accept them on input.
                    asst: Dict[str, Any] = {"role": "assistant"}
                    text = "\n".join(text_parts)
                    if tool_calls:
                        asst["tool_calls"] = tool_calls
                        # Per OpenAI Chat Completions spec, content may be null
                        # when tool_calls is present; supply empty string for
                        # broader compatibility (some routers reject null).
                        asst["content"] = text or ""
                    else:
                        # No tool calls — content is required and must not be
                        # null. Default to "" if the assistant produced nothing
                        # textual (e.g., reasoning-only turn).
                        asst["content"] = text
                    if rd_payload is not None:
                        # OpenRouter accepts `reasoning_details` on the
                        # assistant message to restore prior chain-of-thought
                        # for providers that need it (Anthropic signatures,
                        # Gemini thought signatures, etc.).
                        asst["reasoning_details"] = rd_payload
                    out.append(asst)
        return out

    def _normalize_response(self, response: Any) -> APIResponse:
        content: List[Dict] = []
        choices = getattr(response, "choices", None) or []
        finish_reason = None
        if choices:
            choice = choices[0]
            finish_reason = getattr(choice, "finish_reason", None)
            msg = getattr(choice, "message", None)
            if msg is not None:
                text = getattr(msg, "content", None)
                if text:
                    content.append({"type": "text", "text": text})
                for tc in getattr(msg, "tool_calls", None) or []:
                    fn = getattr(tc, "function", None)
                    try:
                        args = json.loads(getattr(fn, "arguments", "") or "{}")
                    except Exception:
                        args = {}
                    content.append(
                        {
                            "type": "tool_use",
                            "id": getattr(tc, "id", ""),
                            "name": getattr(fn, "name", "") if fn else "",
                            "input": args,
                        }
                    )

        usage = self._usage_from(getattr(response, "usage", None))
        # Capture reasoning text (OpenRouter exposes message.reasoning for reasoning models).
        # Insert as a thinking block at the front so the agent can render it.
        reasoning_text = None
        reasoning_details = None
        if choices:
            msg = getattr(choices[0], "message", None)
            if msg is not None:
                r = getattr(msg, "reasoning", None)
                # Only accept str — some routers return objects/dicts that
                # would crash the renderer.
                if isinstance(r, str) and r.strip():
                    reasoning_text = r
                # Structured per-model reasoning blocks (OpenRouter's
                # cross-provider normalization). Round-trip these so models
                # that need their own reasoning payloads back (Anthropic
                # signature, Gemini thought signature, etc.) can continue
                # the chain on the next turn.
                rd = getattr(msg, "reasoning_details", None)
                if isinstance(rd, list) and rd:
                    reasoning_details = [
                        item if isinstance(item, dict) else (
                            item.model_dump() if hasattr(item, "model_dump") else dict(item)
                        )
                        for item in rd
                    ]
        if reasoning_details:
            content.insert(0, {"type": "_openrouter_reasoning_details", "data": reasoning_details})
        if reasoning_text:
            content.insert(0, {"type": "thinking", "thinking": reasoning_text, "signature": "openrouter_reasoning"})

        stop_reason = self._map_stop_reason(
            finish_reason, any(b.get("type") == "tool_use" for b in content)
        )
        return APIResponse(
            content=content,
            stop_reason=stop_reason,
            usage=usage,
            raw_response=response,
            finish_reason=finish_reason,
        )

    @staticmethod
    def _map_stop_reason(finish_reason: Optional[str], has_tool_use: bool) -> str:
        """Map OpenAI finish_reason → unified stop_reason.

        - "tool_calls" or any tool block in content → "tool_use"
        - "length"      → "max_tokens" (so the agent stops looping; the
                          model didn't choose to end, the budget did)
        - "content_filter" → "stop_sequence" (treat as terminal)
        - "error"       → "stop_sequence" (mid-stream error sentinel from
                          OpenRouter; treat as terminal so the agent surfaces
                          whatever partial content arrived rather than looping)
        - everything else (incl. "stop", None, "function_call") → "end_turn"
        """
        if finish_reason == "tool_calls" or has_tool_use:
            return "tool_use"
        if finish_reason == "length":
            return "max_tokens"
        if finish_reason in ("content_filter", "error"):
            return "stop_sequence"
        return "end_turn"

    @staticmethod
    def _usage_from(usage_obj: Any) -> Usage:
        if not usage_obj:
            return Usage(input_tokens=0, output_tokens=0)
        # OpenRouter exposes prompt_tokens_details.cached_tokens when caching is active.
        # With `usage.include=true` the field may come back as a plain dict on
        # the parsed object instead of a typed sub-object — handle both.
        cached = 0
        cache_write = 0
        details = getattr(usage_obj, "prompt_tokens_details", None)
        if details is None and isinstance(usage_obj, dict):
            details = usage_obj.get("prompt_tokens_details")
        if isinstance(details, dict):
            cached = details.get("cached_tokens", 0) or 0
            cache_write = details.get("cache_write_tokens", 0) or 0
        elif details is not None:
            cached = getattr(details, "cached_tokens", 0) or 0
            cache_write = getattr(details, "cache_write_tokens", 0) or 0

        def _g(name: str, default: int = 0) -> int:
            if isinstance(usage_obj, dict):
                return usage_obj.get(name, default) or default
            return getattr(usage_obj, name, default) or default

        return Usage(
            input_tokens=_g("prompt_tokens"),
            output_tokens=_g("completion_tokens"),
            cache_creation_input_tokens=cache_write,
            cache_read_input_tokens=cached,
            reasoning_tokens=0,
        )


def _stringify_tool_result(content: Any) -> str:
    """Anthropic tool_result.content can be a string or list of blocks."""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = []
        for blk in content:
            if isinstance(blk, dict):
                if blk.get("type") == "text":
                    parts.append(blk.get("text", ""))
                else:
                    parts.append(json.dumps(blk))
            else:
                parts.append(str(blk))
        return "\n".join(parts)
    return str(content)
