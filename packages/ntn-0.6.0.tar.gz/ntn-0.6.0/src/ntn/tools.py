import os
import re
import subprocess
import sys

import requests
from bs4 import BeautifulSoup
from ddgs import DDGS

from .config import config


def _run_with_timeout(args, *, shell=False, cwd=None, timeout=120, text=True, encoding=None, errors=None):
    """Run a command with a real, tree-killing timeout.

    ``subprocess.run(timeout=...)`` only kills the immediate child on Windows,
    so grandchildren (e.g. python.exe under cmd.exe) keep the stdout pipe open
    and block ``communicate``. We use Popen + manual timeout + ``taskkill /T``
    (Windows) or ``killpg`` (POSIX) to terminate the whole process tree.

    Returns a ``subprocess.CompletedProcess``-like object on success, or raises
    ``subprocess.TimeoutExpired`` on timeout.
    """
    popen_kwargs = dict(
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        stdin=subprocess.DEVNULL,  # crucial: prevents cat/read-from-stdin hangs
        cwd=cwd,
        shell=shell,
        text=text,
    )
    if encoding is not None:
        popen_kwargs["encoding"] = encoding
    if errors is not None:
        popen_kwargs["errors"] = errors
    if os.name == "nt":
        popen_kwargs["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP
    else:  # pragma: no cover - POSIX path
        popen_kwargs["start_new_session"] = True

    proc = subprocess.Popen(args, **popen_kwargs)
    try:
        stdout, stderr = proc.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        if os.name == "nt":
            subprocess.run(
                ["taskkill", "/F", "/T", "/PID", str(proc.pid)],
                capture_output=True,
                timeout=10,
            )
        else:  # pragma: no cover - POSIX path
            import signal
            try:
                os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
            except ProcessLookupError:
                pass
        try:
            stdout, stderr = proc.communicate(timeout=5)
        except subprocess.TimeoutExpired:
            stdout, stderr = "", ""
        raise subprocess.TimeoutExpired(args, timeout, output=stdout, stderr=stderr)
    return subprocess.CompletedProcess(args, proc.returncode, stdout, stderr)


def _split_cd_prefix(cmd: str) -> tuple[str | None, str]:
    """Extract (cwd, remainder) from `cd <cwd> && <remainder>` (or `;`).

    The optional cmd.exe ``/D`` flag (`cd /D D:\\foo && …`) is stripped from
    the captured cwd so it doesn't end up as part of the path.
    """
    cmd = cmd.strip()
    m = re.match(r"^cd\s+(?:/[Dd]\s+)?([^\n]+?)\s*(?:&&|;)\s*(.+)$", cmd, flags=re.S)
    if not m:
        return None, cmd

    cwd = m.group(1).strip().strip('"').strip("'")
    remainder = m.group(2).strip()
    return cwd, remainder


def _describe_tool_exec(cmd: str) -> str:
    cwd, remainder = _split_cd_prefix(cmd)
    desc = _parse_exec_command(remainder)
    return f"{desc} (In {cwd})" if cwd else desc


def _describe_shell_exec(cmd: str) -> tuple[str, str | None]:
    """Helper for shell tool exec - returns (description, path)."""
    cwd, remainder = _split_cd_prefix(cmd)
    desc = _parse_exec_command(remainder)
    return (desc, cwd)


def _short(s: str, n: int) -> str:
    return s if len(s) <= n else s[:n] + "..."


def get_tool_description(tool_name, tool_input):
    """Convert tool call to human-readable description.

    Returns:
        tuple[str, str | None]: (description, path) where path is the working directory or None
    """
    if tool_name == "execute_command":
        cmd = tool_input.get("command", "")
        cwd, remainder = _split_cd_prefix(cmd)

        # Detect inline Python (heredoc or -c style)
        if re.search(r"^python\s+.*<<\s*['\"]?\w+['\"]?", remainder, flags=re.S):
            desc = "🐍 Run inline Python"
        elif re.match(r"^python\s+-c\s+", remainder):
            desc = "🐍 Run inline Python"
        else:
            desc = f"⚡ Run: {_short(remainder, 60)}"

        return (desc, cwd)

    if tool_name == "web_search":
        return (f"🔍 Search: {tool_input.get('query', '')}", None)

    if tool_name == "fetch_webpage":
        return (f"🌐 Fetch: {_short(tool_input.get('url', ''), 50)}", None)

    return (f"🔧 {tool_name}", None)


def _parse_exec_command(cmd: str) -> str:
    """Parse a container exec command into a short human-readable description."""
    parts = [p.strip() for p in cmd.split("|")]
    main_cmd = parts[0]

    if re.search(r"^python(3)?\s+.*<<\s*['\"]?\w+['\"]?", main_cmd, flags=re.S):
        return "🐍 Run inline Python"

    # Check for line limiting in pipe
    line_info = ""
    for part in parts[1:]:
        match = re.match(r"(head|tail)\s+(?:-n\s*)?(\d+)", part)
        if match:
            line_info = f" ({'first' if match.group(1) == 'head' else 'last'} {match.group(2)} lines)"

    # Simple command mappings
    for prefix, desc in (
        ("ls", "📂 List files"),
        ("find ", "🔎 Find files"),
        ("grep ", "🔎 Search in files"),
        ("wc ", "📊 Count lines/words"),
    ):
        if main_cmd.startswith(prefix):
            return desc

    # File read/write commands
    if main_cmd.startswith("cat"):
        if ">>" in main_cmd or main_cmd.startswith("cat >"):
            match = re.search(r"cat\s*>>?\s*([^\s<]+)", main_cmd)
            filename = match.group(1).split("/")[-1] if match else "file"
            return f"✏️  {'Append to' if '>>' in main_cmd else 'Edit'} {filename}"
        if ">" not in main_cmd:
            match = re.search(r"cat\s+([^|]+)", main_cmd)
            if match:
                return f"📄 Read {match.group(1).strip().split('/')[-1]}{line_info}"

    for cmd_name, direction in (("head", "first"), ("tail", "last")):
        if main_cmd.startswith(f"{cmd_name} "):
            match = re.match(rf"{cmd_name}\s+(?:-n\s*)?(-?\d+)?\s*(.+)?", main_cmd)
            if match and match.group(2):
                num, filepath = match.group(1), match.group(2)
                filename = filepath.strip().split("/")[-1]
                suffix = f" ({direction} {num.lstrip('-')} lines)" if num else ""
                return f"📄 Read {filename}{suffix}"
            return "📄 Read file"

    if main_cmd.startswith("sed "):
        match = re.match(r"sed\s+-n\s+['\"]?(\d+),(\d+)p['\"]?\s+(.+)", main_cmd)
        if match:
            start, end, filepath = match.groups()
            filename = filepath.strip().split("/")[-1]
            return f"📄 Read {filename} (lines {start}-{end})"

    return f"⚡ Run: {_short(cmd, 50)}"


def _build_shell_argv(shell: str, command: str) -> list[str]:
    """Translate a free-form ``command`` into argv for the requested shell.

    Without this, ``subprocess.Popen(shell=True)`` always invokes ``cmd.exe``
    (COMSPEC) on Windows, even when the user is running PowerShell. The
    system prompt advertises the detected shell, so the agent must actually
    invoke that shell - otherwise the model writes PowerShell that cmd.exe
    can't parse.
    """
    s = (shell or "").lower()
    if s in ("pwsh", "powershell"):
        exe = "pwsh" if s == "pwsh" else "powershell"
        return [exe, "-NoLogo", "-NoProfile", "-Command", command]
    if s == "cmd":
        comspec = os.environ.get("COMSPEC", "cmd.exe")
        return [comspec, "/d", "/c", command]
    # POSIX: respect $SHELL if it points to something runnable.
    shell_path = os.environ.get("SHELL") or "/bin/sh"
    return [shell_path, "-c", command]


class TerminalTool:
    """Execute shell commands in workspace."""

    DANGEROUS_COMMANDS = config.tools.dangerous_commands

    def __init__(self, workspace_dir, confirm_callback=None, shell=None):
        self.workspace_dir = workspace_dir
        self.confirm_callback = confirm_callback or self._default_confirm
        self.shell = shell or _default_shell_name()

    @staticmethod
    def _default_confirm(command):
        print(f"\n⚠️  DANGEROUS COMMAND DETECTED: {command}")
        response = input("Allow execution? (y/N): ").strip().lower()
        return response == "y"

    def get_schema(self):
        return {
            "name": "execute_command",
            "description": (
                "Executes a shell command in the user's native shell (PowerShell / cmd / bash / "
                "zsh - whichever was advertised in the system prompt) and returns stdout, stderr, "
                "and the exit code.\n"
                "\n"
                "USE THIS TOOL FOR: file operations (read, write, edit, list, find, grep), running "
                "scripts and binaries, package managers (pip, npm, cargo, go), version control "
                "(git, gh), builds, tests, linters, and any developer workflow.\n"
                "\n"
                "EXECUTION MODEL\n"
                "- Each call starts a FRESH shell at the user's default working directory. The "
                "working directory and shell variables (env vars, functions, aliases) DO NOT "
                "persist between calls. Use absolute paths, or prefix with `cd <abs path> && ...` "
                "(POSIX/cmd) / `Set-Location <abs path>; ...` (PowerShell) when you need to run "
                "in a specific directory.\n"
                "- The command runs non-interactively. Anything that would prompt for input "
                "(`Read-Host`, `Get-Credential`, `git rebase -i`, `git add -i`, `pause`, "
                "`apt install` without `-y`) will hang until it times out. Pass non-interactive "
                "flags or pipe input from a file/heredoc instead.\n"
                "- Default timeout is bounded by `config.tools.shell_timeout`; long-running "
                "commands (servers, watchers) will be killed when the timeout expires. For long "
                "tasks, redirect output to a file and poll, or run in the background with proper "
                "detachment.\n"
                "\n"
                "SYNTAX RULES\n"
                "- Use the syntax of the shell advertised in the system prompt. Do NOT mix POSIX "
                "syntax into a PowerShell call or vice versa.\n"
                "- Quote any path or argument that contains spaces.\n"
                "- DO NOT use raw newlines to separate commands - use the shell's chain operator "
                "(`;` for PowerShell, `&&` / `||` / `;` for POSIX/cmd). Newlines inside quoted "
                "strings or here-strings are fine.\n"
                "- Before creating new files or directories, verify the parent exists "
                "(`ls <parent>` / `Get-ChildItem <parent>`).\n"
                "\n"
                "PARALLELISM\n"
                "- If you need to run multiple INDEPENDENT commands (e.g. `git status` and "
                "`git diff`), issue them as multiple `execute_command` calls in a SINGLE "
                "response - they run in parallel.\n"
                "- If commands depend on each other, chain them in ONE call with the shell's "
                "chain operator so they share intermediate state. Use `&&` / `if ($LASTEXITCODE "
                "-eq 0)` when later steps must abort if an earlier step fails.\n"
                "\n"
                "GIT SAFETY (when running git via this tool)\n"
                "- Only commit when the user explicitly asks. Don't be proactive about commits.\n"
                "- Never run destructive git operations (`push --force`, `reset --hard`, "
                "`checkout .`, `clean -f`, `branch -D`) unless the user explicitly requests them.\n"
                "- Never bypass hooks (`--no-verify`) or signing (`--no-gpg-sign`) unless the user "
                "explicitly requests it. If a hook fails, fix the underlying issue and create a "
                "NEW commit (don't `--amend`, since the failed commit didn't actually happen).\n"
                "- Stage specific files (`git add path/to/file`) rather than `git add -A` / "
                "`git add .` to avoid accidentally including secrets or build artifacts.\n"
                "- Never `git config` changes without permission.\n"
                "\n"
                "DANGEROUS COMMANDS\n"
                "- Commands matching the configured dangerous-command list (e.g. `rm`, "
                "`Remove-Item`, `del`, `format`, `dd`, `shutdown`) will trigger a user "
                "confirmation prompt before execution. Don't try to evade this by aliasing or "
                "obfuscating - just ask the user first if you genuinely need to run them.\n"
                "\n"
                "OUTPUT\n"
                "- stdout and stderr are returned separately along with the exit code. If your "
                "command produces a lot of output, pipe through `head` / `tail` / `Select-Object` "
                "or redirect to a file you can inspect in slices."
            ),
            "input_schema": {
                "type": "object",
                "properties": {
                    "command": {
                        "type": "string",
                        "description": (
                            "The exact command line to execute, written in the syntax of the "
                            "shell advertised in the system prompt. Use absolute paths or a "
                            "`cd`/`Set-Location` prefix; do not assume any working directory "
                            "from a previous call."
                        ),
                    }
                },
                "required": ["command"],
            },
        }

    def execute(self, command):
        all_parts = command.replace("|", " ").replace("&&", " ").replace(";", " ").split()
        dangerous_found = [p for p in all_parts if p.lower() in self.DANGEROUS_COMMANDS]

        if dangerous_found and not self.confirm_callback(command):
            return {
                "error": f"Command rejected by user. Dangerous commands detected: {dangerous_found}"
            }

        argv = _build_shell_argv(self.shell, command)
        try:
            try:
                result = _run_with_timeout(
                    argv,
                    shell=False,
                    cwd=self.workspace_dir,
                    text=True,
                    timeout=getattr(config.tools, "shell_timeout", 120),
                )
            except subprocess.TimeoutExpired as te:
                return {
                    "error": (
                        f"Command timed out after {te.timeout}s and was killed (process tree terminated). "
                        "If it was waiting on stdin (e.g. `cat > file` without a heredoc), "
                        "use a heredoc (`cat > file <<'EOF' ... EOF`) or pipe input from a file. "
                        "For long-running tasks, run them in the background or raise "
                        "config.tools.shell_timeout."
                    ),
                    "stdout": te.stdout or "",
                    "stderr": te.stderr or "",
                }
            return {"stdout": result.stdout, "stderr": result.stderr, "returncode": result.returncode}
        except Exception as e:
            return {"error": str(e)}


def _default_shell_name() -> str:
    # Lazy import to avoid circular dependency at module-load time.
    from .prompts import detect_host_env
    return detect_host_env().get("shell") or ("cmd" if os.name == "nt" else "sh")


class WebSearchTool:
    """Search web using ddgs."""

    def __init__(self):
        self.ddgs = DDGS()

    def get_schema(self):
        return {
            "name": "web_search",
            "description": (
                "Searches the web via DuckDuckGo and returns a list of results "
                "(title, URL, snippet).\n"
                "\n"
                "USE THIS TOOL FOR\n"
                "- Information that may have changed since the model's knowledge cutoff "
                "(library versions, API changes, recent events, latest docs).\n"
                "- Finding the canonical URL for documentation, a package's homepage, a "
                "GitHub issue/repo, an error message, or a Stack Overflow answer.\n"
                "- Discovering candidate sources before reading them with `fetch_webpage`.\n"
                "\n"
                "QUERY GUIDELINES\n"
                "- Include the current year when searching for \"latest\" / \"recent\" / "
                "\"new\" content - the model's training year is stale.\n"
                "- Be specific: include the library name, version, error code, or function "
                "name. Generic queries waste a turn.\n"
                "- For GitHub-specific lookups (PRs, issues, releases, repo files) prefer the "
                "`gh` CLI via `execute_command` - it returns structured data faster.\n"
                "\n"
                "OUTPUT\n"
                "- Returns up to `config.tools.web_search.max_results` results. Each result is "
                "a snippet, not the full page - use `fetch_webpage` to read the full content of "
                "a specific URL.\n"
                "- When you cite information from search results in your final answer, include "
                "the source URLs as markdown links so the user can verify."
            ),
            "input_schema": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": (
                            "The search query. Be specific. Include the current year for "
                            "\"latest\"-style questions, the library/tool name, and any "
                            "error code or symbol you're researching."
                        ),
                    }
                },
                "required": ["query"],
            },
        }

    def execute(self, query):
        try:
            results = list(
                self.ddgs.text(
                    query,
                    region=config.tools.web_search.region,
                    max_results=config.tools.web_search.max_results,
                )
            )
            return {"results": results}
        except Exception as e:
            return {"error": str(e)}


class FetchWebTool:
    """Fetch webpage content."""

    def get_schema(self):
        return {
            "name": "fetch_webpage",
            "description": (
                "Fetches a URL, strips scripts/styles, and returns the visible text content "
                "(truncated to `config.tools.web_fetch.content_limit` characters).\n"
                "\n"
                "USE THIS TOOL FOR\n"
                "- Reading documentation pages, READMEs, API references, blog posts, or RFCs "
                "after `web_search` (or the user) gave you a specific URL.\n"
                "- Inspecting raw text/JSON/yaml endpoints (e.g. `raw.githubusercontent.com` "
                "URLs).\n"
                "\n"
                "USAGE NOTES\n"
                "- The URL must be fully formed and include the scheme (`https://...`).\n"
                "- Read-only: does not modify any local or remote state.\n"
                "- Output is truncated for large pages; if you need a specific section, search "
                "for it inside the returned content rather than re-fetching.\n"
                "- For GitHub URLs (issues, PRs, repo contents, releases), prefer the `gh` CLI "
                "via `execute_command` - it returns structured data without HTML parsing.\n"
                "- Don't fetch a URL just to mention its title - only fetch when you need the "
                "content to answer the user."
            ),
            "input_schema": {
                "type": "object",
                "properties": {
                    "url": {
                        "type": "string",
                        "description": (
                            "Fully-qualified URL to fetch, including the `https://` scheme."
                        ),
                    }
                },
                "required": ["url"],
            },
        }

    def execute(self, url):
        try:
            response = requests.get(url, timeout=config.tools.web_fetch.timeout)
            soup = BeautifulSoup(response.content, "html.parser")

            for script in soup(["script", "style"]):
                script.decompose()

            text = soup.get_text()
            lines = (line.strip() for line in text.splitlines())
            chunks = (phrase.strip() for line in lines for phrase in line.split("  "))
            text = "\n".join(chunk for chunk in chunks if chunk)

            return {"content": text[: config.tools.web_fetch.content_limit]}
        except Exception as e:
            return {"error": str(e)}
