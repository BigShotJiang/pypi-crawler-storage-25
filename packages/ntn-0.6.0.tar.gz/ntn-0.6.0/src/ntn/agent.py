"""Core agent implementation.

This file hosts the CodingAgent class extracted from agent.py.
agent.py can remain as a thin compatibility layer/import.
"""

from __future__ import annotations

import json
import os
import re  # noqa: F401  (kept for compatibility with downstream patches)
import time
from datetime import datetime

from colorama import Fore, Style, init

from .config import config, get_color, get_debug_dir
from . import providers
from .prompts import get_system_prompt, detect_host_env
from .session_log import SessionLogger
from .tools import get_tool_description
from .ui import print_divider, print_status_box

# Initialize colorama
init(autoreset=True)


class CodingAgent:
    """Minimal AI agent for coding workspace."""

    MODELS = config.models.aliases

    COMPACT_PROMPT = """\
You are compacting an in-progress agent session so it can continue without losing important context.

IMPORTANT: This message you are reading right now is a system instruction, NOT the user's request.
The user's actual most recent message is the LAST user-role message in the conversation history above this instruction (excluding this instruction itself).

Output ONLY the following two sections, in this exact format, with no preamble, headers, or closing remarks:

This is the current user message:
[Reproduce the user's most recent actual message VERBATIM — copy it word-for-word, preserving all formatting, language (Vietnamese, English, etc.), bullet points, code blocks, and line breaks. Do NOT paraphrase, summarize, or translate it. This is the message the agent must respond to next.]

This is a summary of the whole context:
[Write a thorough, exhaustive summary of the entire prior conversation. This summary will become the agent's only memory of everything that came before, so include every detail that could matter for completing the current user message. Specifically cover:
  - The overall goal/project and what the user is trying to build or accomplish
  - All requirements, constraints, design decisions, and rationale agreed upon so far
  - All clarifications the user has given, especially recent ones (rules, preferences, scope, edge cases) — preserve specific values, names, and technical terms verbatim
  - Repository / workspace layout: paths, key files, languages, frameworks, dependencies
  - Important file contents, code snippets, function signatures, data shapes, and APIs the agent has read or written
  - Tool outputs that materially shaped decisions (commands run, errors seen, what worked, what didn't)
  - Mistakes the agent made and corrections — so it does not repeat them
  - Current progress: what has been implemented, what is partially done, what is not yet started
  - The immediate next step the agent was about to take when compaction triggered

Be long and detailed. Err strongly on the side of including too much rather than too little — this summary replaces the entire conversation history. Do not omit specifics. Do not add a conclusion or sign-off.]"""

    def __init__(
        self,
        tools,
        workspace_dir,
        debug_file=None,
        session_info=None,
        stream=False,
        think=True,
        model="opus",
        effort="max",
    ):
        self.model_short = model
        self.model = self.MODELS.get(model, self.MODELS[config.models.default])

        self.provider_name = config.models.get_provider(self.model)
        limits = config.models.get_limits(self.model)
        self.max_context_tokens = limits.max_context_tokens if limits else 200000
        self.max_output_tokens = limits.max_output_tokens if limits else 64000

        self.provider = providers.create_provider(self.model, self.provider_name)

        self.workspace_dir = workspace_dir
        self.messages = []
        self.tools = tools
        self.tool_map = {tool.get_schema()["name"]: tool for tool in tools}
        self.display_history = []
        self.stream = stream
        self.think = think
        self.effort = config.models.normalize_effort(self.model, effort)
        self.thinking_spec = config.models.get_thinking(self.model)
        self.supports_effort = bool(self.thinking_spec.get("supports_effort", False))

        self.rate_limit_info = None
        self.context_tokens = 0

        self.session_cost = 0.0
        self.run_cost = 0.0
        self.last_req_cost = 0.0
        self.last_usage = None

        if debug_file:
            self.debug_file = debug_file
            self.logger = SessionLogger(self.debug_file)

            if session_info and session_info.get("session_id"):
                session_id = session_info["session_id"]
                working_dirs = list(session_info.get("working_dirs", []))
            else:
                debug_basename = os.path.basename(debug_file)
                session_name = debug_basename.replace("debug_", "").replace(".txt", "")
                session_id = f"sess_{session_name}"
                working_dirs = []

            if workspace_dir not in working_dirs:
                working_dirs.append(workspace_dir)

            self.session_id = session_id
            self.working_dirs = working_dirs
            self._last_logged_session_info = session_info
            self.logger.resume()
        else:
            debug_dir = get_debug_dir(workspace_dir)
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            self.debug_file = str(debug_dir / f"debug_{timestamp}.txt")
            self.logger = SessionLogger(self.debug_file)

            self.session_id = f"sess_{timestamp}"
            self.working_dirs = [workspace_dir]
            self._last_logged_session_info = None
            self.logger.session_start(self.workspace_dir, self.session_id)

        self.host_env = detect_host_env()
        self._announce_host_env()
        self._log_session_info()
        self._update_system_message()
        # Attach session id to the provider for cache routing (OpenAI uses
        # this as `prompt_cache_key` to keep our long, mostly-static prefix
        # routed to the same backend across requests).
        self.provider.set_session_id(self.session_id)


    def _is_openai_model(self) -> bool:
        """True if current model uses the OpenAI provider."""
        return self.provider_name == "openai"

    # ---- host env + prompt ----

    def _announce_host_env(self):
        env = self.host_env
        os_name = env.get("os", "Unknown")
        release = env.get("os_release") or ""
        shell = env.get("shell", "unknown")
        os_label = f"{os_name} {release}".strip() if release else os_name
        print(f"{Fore.GREEN}🖥  Shell: {shell} on {os_label}{Style.RESET_ALL}")

    def _update_system_message(self):
        self.system_prompt = get_system_prompt(self.workspace_dir, self.host_env, self.working_dirs)

    def add_working_directory(self, path):
        abs_path = os.path.abspath(path)
        if abs_path in self.working_dirs:
            return {"status": "already_recorded", "path": abs_path}
        self.working_dirs.append(abs_path)
        self._update_system_message()
        self._log_session_info()
        return {"status": "added", "path": abs_path}

    def _log_session_info(self):
        info = {
            "session_id": self.session_id,
            "working_dirs": list(self.working_dirs),
        }
        if info != self._last_logged_session_info:
            self.logger.session_info(info)
            self._last_logged_session_info = info

    def cleanup_empty_session(self):
        has_user_message = any(
            msg.get("role") == "user" and isinstance(msg.get("content"), str) for msg in self.messages
        )
        if has_user_message:
            return False

        # Release the open log handle before unlinking - Windows refuses to
        # delete a file while any process has it open.
        self.logger.close()

        if os.path.exists(self.debug_file):
            os.remove(self.debug_file)
            print(f"{Fore.YELLOW}🧹 Cleaned up empty session{Style.RESET_ALL}")
        return True

    # ---- token counting + context mgmt ----

    def _count_tokens(self, messages):
        try:
            tool_schemas = [tool.get_schema() for tool in self.tools]
            return self.provider.count_tokens(messages=messages, system=self.system_prompt, tools=tool_schemas)
        except Exception:
            total_chars = len(self.system_prompt)
            for msg in messages:
                c = msg.get("content")
                if isinstance(c, str):
                    total_chars += len(c)
                elif isinstance(c, list):
                    for item in c:
                        if isinstance(item, dict):
                            total_chars += len(json.dumps(item))
            return total_chars // 4

    def _get_turns(self):
        turns = []
        current_turn = []
        for msg in self.messages:
            if msg["role"] == "user" and current_turn:
                content = msg.get("content", "")
                if (
                    isinstance(content, list)
                    and content
                    and isinstance(content[0], dict)
                    and content[0].get("type") == "tool_result"
                ):
                    current_turn.append(msg)
                else:
                    turns.append(current_turn)
                    current_turn = [msg]
            else:
                current_turn.append(msg)
        if current_turn:
            turns.append(current_turn)
        return turns

    def _is_context_error(self, error):
        error_str = str(error).lower()
        return any(
            x in error_str
            for x in [
                "context_length_exceeded",
                "max_tokens",
                "too many tokens",
                "too long",
                "maximum context length",
                "context window",
                "exceed",
            ]
        )

    @staticmethod
    def _is_transient_error(error: Exception) -> bool:
        """Network blips, gateway errors, server hiccups — anything worth a
        silent retry. Matches by exception class name and message substring so
        we don't need to import provider SDKs here.
        """
        cls = type(error).__name__
        if cls in {
            # OpenAI / OpenRouter SDK
            "APIConnectionError", "APITimeoutError", "InternalServerError",
            "BadGatewayError", "ServiceUnavailableError", "GatewayTimeoutError",
            # Anthropic SDK
            "APIStatusError",
            # httpx / urllib
            "RemoteProtocolError", "ConnectError", "ReadError", "ReadTimeout",
            "ConnectTimeout", "WriteError", "PoolTimeout", "ProtocolError",
            "ConnectionResetError", "ConnectionAbortedError",
        }:
            return True
        msg = str(error).lower()
        transient_phrases = (
            "network connection lost",
            "connection error",
            "connection reset",
            "connection aborted",
            "connection refused",
            "remote disconnected",
            "timed out",
            "timeout",
            "temporarily unavailable",
            "bad gateway",
            "service unavailable",
            "gateway timeout",
            "internal server error",
            "stream interrupted",
            "incomplete read",
            "ssl",
            "upstream error",
        )
        if any(p in msg for p in transient_phrases):
            return True
        # HTTP 5xx codes that aren't already named above
        for code in ("500", "502", "503", "504", "520", "521", "522", "524"):
            if code in msg:
                return True
        return False

    # ---- provider/cost ----

    def _capture_rate_limit_info(self, response):
        if response and response.raw_response:
            self.rate_limit_info = self.provider.get_rate_limit_info(response.raw_response)
        else:
            self.rate_limit_info = {}

        if response and response.usage:
            usage = response.usage
            self.context_tokens = usage.input_tokens + usage.cache_creation_input_tokens + usage.cache_read_input_tokens
            self._calculate_cost(usage)
            self._set_last_thought_tokens(response)

    @staticmethod
    def calculate_cost_from_usage(usage, model="claude-opus-4-7"):
        """Compute USD cost for one request.

        Token-accounting differs by provider family:

          * **Anthropic**: ``input_tokens`` is the *uncached* prompt only.
            ``cache_read_input_tokens`` and the cache-write buckets are
            reported separately and must be priced at their own rates.
            We send mixed TTLs (1h on system, 5m on last message), so the
            response's `cache_creation` dict carries both
            `ephemeral_5m_input_tokens` and `ephemeral_1h_input_tokens`.
            The 1h write rate is 2x base input; 5m is 1.25x. Charging
            both at one rate (as we used to) under-bills the 1h portion.
          * **OpenAI Responses API** and **OpenRouter Chat Completions**:
            ``prompt_tokens`` (surfaced as ``input``) is the *total* prompt,
            **including** cached tokens. Charging the full input rate on
            ``input`` plus the cache-read rate on ``cache_read`` would
            double-bill the cached portion. We subtract here.

        Reasoning tokens on OpenAI/OR are already included in the provider's
        ``completion_tokens`` (and so in ``output``), so they're priced at
        the regular output rate.
        """
        pricing = config.models.pricing.get(model)
        if not pricing:
            return 0.0
        input_t = usage.get("input", 0) or 0
        output_t = usage.get("output", 0) or 0
        cache_read = usage.get("cache_read", 0) or 0
        cache_write = usage.get("cache_write", 0) or 0
        cw_5m = usage.get("cache_write_5m", 0) or 0
        cw_1h = usage.get("cache_write_1h", 0) or 0

        is_anthropic = model.startswith("claude-")
        if is_anthropic:
            uncached_input = input_t
            # Prefer the per-TTL breakdown when present (it always should be
            # for current Anthropic SDK responses). Fall back to the lumped
            # `cache_write` priced at the 5m rate (matches old behaviour).
            if cw_5m or cw_1h:
                write_cost = cw_5m * pricing.write_5m() + cw_1h * pricing.write_1h()
            else:
                write_cost = cache_write * pricing.write_5m()
        else:
            uncached_input = max(input_t - cache_read - cache_write, 0)
            write_cost = cache_write * pricing.cache_write

        return (
            uncached_input * pricing.input
            + output_t * pricing.output
            + write_cost
            + cache_read * pricing.cache_read
        ) / 1_000_000

    def _calculate_cost(self, usage):
        self.last_usage = {
            "input": usage.input_tokens,
            "output": usage.output_tokens,
            "cache_write": usage.cache_creation_input_tokens,
            "cache_write_5m": getattr(usage, "cache_creation_5m_tokens", 0),
            "cache_write_1h": getattr(usage, "cache_creation_1h_tokens", 0),
            "cache_read": usage.cache_read_input_tokens,
            "reasoning": getattr(usage, "reasoning_tokens", 0),
        }
        self.last_req_cost = self.calculate_cost_from_usage(self.last_usage, self.model)
        self.run_cost += self.last_req_cost
        self.session_cost += self.last_req_cost

    
    def _set_last_thought_tokens(self, response) -> None:
        """Compute last thought token count for UI.

        OpenAI: uses response.usage.reasoning_tokens (from providers.OpenAIProvider).
        Anthropic: no separate thinking token count, so we estimate from thinking text
        length if a thinking block exists.
        """
        self._last_thought_tokens = 0

        if response and getattr(response, "usage", None):
            self._last_thought_tokens = int(getattr(response.usage, "reasoning_tokens", 0) or 0)

        if self._last_thought_tokens <= 0 and response and getattr(response, "content", None):
            for b in response.content:
                if isinstance(b, dict) and b.get("type") == "thinking":
                    t = b.get("thinking", "") or ""
                    self._last_thought_tokens = max(1, len(t) // 4)
                    return
# ---- UI ----

    def _fast_estimate_context_tokens(self) -> int:
        """Cheap local estimate: total chars / 4.

        Used only when context_tokens is 0 (e.g. first print_status on resume
        before any API response has populated _capture_rate_limit_info).
        Never triggers a network call.
        """
        total_chars = len(self.system_prompt or "")
        for msg in self.messages:
            c = msg.get("content")
            if isinstance(c, str):
                total_chars += len(c)
            elif isinstance(c, list):
                for item in c:
                    if isinstance(item, dict):
                        total_chars += len(item.get("text") or item.get("content") or json.dumps(item))
        return total_chars // 4

    def print_status(self):
        effective_limit = self.max_context_tokens - self.max_output_tokens
        # self.context_tokens is kept up to date by _capture_rate_limit_info()
        # after each API call using the provider-reported usage.  On first
        # display (e.g. a fresh resume before any API call), the value is 0;
        # compute a cheap local estimate once so the box shows something
        # reasonable.  The authoritative count updates after the next response.
        if self.context_tokens == 0 and self.messages:
            self.context_tokens = self._fast_estimate_context_tokens()

        print_status_box(
            divider_width=config.ui.divider_width,
            run_cost=self.run_cost,
            session_cost=self.session_cost,
            rate_limit_info=self.rate_limit_info,
            context_tokens=self.context_tokens,
            effective_limit=effective_limit,
        )

    # ---- API calls ----

    def _request_llm_once(self, *, tool_schemas, thinking_config, print_text: bool):
        if self.stream:
            return self._call_api_streaming(print_text=print_text, thinking_config=thinking_config)

        response = self.provider.create(
            messages=self.messages,
            system=self.system_prompt,
            tools=tool_schemas,
            max_tokens=self.max_output_tokens,
            thinking_config=thinking_config,
            effort=self.effort if self.supports_effort else None,
        )
        self._capture_rate_limit_info(response)
        return response, response.content

    def _build_thinking_config(self):
        """Build thinking_config dict to send to the provider, based on
        self.think (CLI on/off) and the per-model `thinking` spec from config.yaml.

        Returns None when thinking is disabled or unsupported for this model."""
        if not self.think:
            return None
        spec = self.thinking_spec or {}
        mode = spec.get("mode", "adaptive")
        if mode == "none":
            return None
        if mode == "adaptive":
            # display=summarized makes Opus 4.7 stream actual thinking text instead of
            # an empty block (its API default is display=omitted).
            return {"type": "adaptive", "display": "summarized"}
        if mode in ("enabled", "legacy"):
            # OpenAI ("legacy") path: providers._build_reasoning derives effort
            # from budget_tokens; Anthropic ("enabled") accepts it directly.
            return {"type": "enabled", "budget_tokens": spec.get("budget_tokens", 63999)}
        return None

    def _drop_for_context_error(self, e: Exception) -> bool:
        """Common context-window-exceeded recovery used by both call paths.

        Recovery:
          1. Progressively truncate the oldest tool outputs (replace each with
             a tiny placeholder) until the remaining history fits within the
             effective context limit, so the upcoming compact API call can
             succeed.
          2. Compact the remaining history into a single summary user message.

        Returns True if recovery succeeded and the call should be retried,
        False if recovery itself failed (caller should re-raise).
        """
        self._shrink_until_fits()
        return self._compact_immediately()

    def _call_api(self, print_text=True):
        max_retries = config.agent.max_retries
        tool_schemas = [tool.get_schema() for tool in self.tools]

        thinking_config = self._build_thinking_config()
        transient_attempts = 0
        max_transient = 5  # generous: network blips deserve more than max_retries

        while True:
            for attempt in range(max_retries + 1):
                try:
                    response, content_list = self._request_llm_once(
                        tool_schemas=tool_schemas,
                        thinking_config=thinking_config,
                        print_text=print_text,
                    )
                    # Streaming path prints incrementally inside StreamAccumulator.
                    # Non-streaming path prints once via _process_response in the
                    # agent loop. Don't print here — _print_content would duplicate.
                    return response, content_list

                except Exception as e:
                    error_str = str(e).lower()

                    if self._is_context_error(e):
                        if not self._drop_for_context_error(e):
                            raise
                        break

                    if self._is_transient_error(e):
                        if transient_attempts >= max_transient:
                            print(
                                f"{Fore.RED}Network error persists after {max_transient} retries: {e}{Style.RESET_ALL}"
                            )
                            raise
                        transient_attempts += 1
                        delay = min(30, 2 ** transient_attempts)  # 2,4,8,16,30
                        print(
                            f"\n{Fore.YELLOW}🌐 Network hiccup ({type(e).__name__}); "
                            f"retrying in {delay}s ({transient_attempts}/{max_transient})...{Style.RESET_ALL}"
                        )
                        time.sleep(delay)
                        continue

                    if "rate" in error_str or "429" in error_str:
                        if attempt == max_retries:
                            print(
                                f"{Fore.RED}Rate limit exceeded after {max_retries + 1} attempts{Style.RESET_ALL}"
                            )
                            raise

                        retry_after = None
                        if hasattr(e, "response") and e.response is not None:
                            retry_after = getattr(e.response.headers, "get", lambda _x: None)("retry-after")
                        delay = int(retry_after) if retry_after else 30
                        print(
                            f"{Fore.YELLOW}⏳ Rate limited, waiting {delay}s before retry ({attempt + 1}/{max_retries})...{Style.RESET_ALL}"
                        )
                        time.sleep(delay)
                    else:
                        raise
            else:
                break

    def _collect_stream_error_info(
        self,
        *,
        exc: Exception,
        attempt: int,
        max_attempts: int,
        classification: str,
        stream_started_at: float,
        partial_blocks,
        request_messages,
        request_system,
        request_tools,
    ) -> dict:
        """Build a forensic record for a streaming-API failure.

        All fields are best-effort and never raise: any sub-error is captured
        as a string in `_collection_errors`. Goal is to make every
        Stream interrupted event in the console correspond to one
        STREAM_ERROR block in the debug log so we can diagnose whether the
        cause is upstream (5xx, 524, RemoteProtocolError), bad request
        (4xx, oversized body), our own timeout firing, or the parser
        choking on an unexpected stream shape.
        """
        info: dict = {
            "exception_class": type(exc).__name__,
            "exception_module": getattr(type(exc), "__module__", None),
            "exception_message": str(exc)[:4000],
            "classification": classification,
            "attempt": attempt,
            "max_attempts": max_attempts,
            "elapsed_seconds_in_stream": round(time.time() - stream_started_at, 3),
            "partial_blocks_received": 0,
            "partial_block_types": [],
            "partial_text_chars": 0,
            "partial_thinking_chars": 0,
            "request_message_count": None,
            "request_body_bytes_estimate": None,
            "request_tools_count": None,
            "http_status": None,
            "http_reason": None,
            "http_headers": None,
            "http_body_excerpt": None,
            "request_id": None,
            "model": getattr(self, "model_short", None),
            "provider_class": type(getattr(self, "provider", None)).__name__,
        }
        errs: list[str] = []

        try:
            if partial_blocks:
                info["partial_blocks_received"] = len(partial_blocks)
                info["partial_block_types"] = [b.get("type") for b in partial_blocks]
                for b in partial_blocks:
                    t = b.get("type")
                    if t == "text":
                        info["partial_text_chars"] += len(b.get("text", ""))
                    elif t == "thinking":
                        info["partial_thinking_chars"] += len(b.get("thinking", ""))
        except Exception as ce:
            errs.append(f"partial_blocks: {ce!r}")

        try:
            info["request_message_count"] = len(request_messages)
            info["request_tools_count"] = len(request_tools) if request_tools else 0
            info["request_body_bytes_estimate"] = len(
                json.dumps(
                    {"system": request_system, "messages": request_messages, "tools": request_tools},
                    default=str,
                ).encode("utf-8", errors="replace")
            )
        except Exception as ce:
            errs.append(f"request_size: {ce!r}")

        # Most SDKs (openai, anthropic, httpx) attach an HTTP response.
        try:
            resp = getattr(exc, "response", None)
            if resp is not None:
                info["http_status"] = getattr(resp, "status_code", None)
                info["http_reason"] = getattr(resp, "reason_phrase", None) or getattr(resp, "reason", None)
                try:
                    info["http_headers"] = {
                        k: v for k, v in dict(resp.headers).items()
                        if k.lower() in {
                            "content-type", "content-length", "x-request-id",
                            "x-ratelimit-remaining-requests", "x-ratelimit-remaining-tokens",
                            "retry-after", "cf-ray", "server", "openai-version",
                            "anthropic-ratelimit-requests-remaining",
                        }
                    }
                except Exception as he:
                    errs.append(f"headers: {he!r}")
                # Body may already be consumed by the streaming reader; try anyway.
                body = None
                for getter in ("text", "content"):
                    try:
                        body = getattr(resp, getter, None)
                        if callable(body):
                            body = body()
                        if body:
                            break
                    except Exception:
                        body = None
                if body:
                    if isinstance(body, bytes):
                        body = body.decode("utf-8", errors="replace")
                    info["http_body_excerpt"] = str(body)[:4000]
        except Exception as ce:
            errs.append(f"http_response: {ce!r}")

        # Common SDK fields.
        for attr in ("status_code", "code", "type", "param", "request_id"):
            try:
                v = getattr(exc, attr, None)
                if v is not None:
                    info.setdefault("sdk_attrs", {})[attr] = v
            except Exception:
                pass

        # If a body dict came back (e.g. openai BadRequestError.body), include it.
        try:
            body_dict = getattr(exc, "body", None)
            if body_dict:
                info["sdk_body"] = str(body_dict)[:4000]
        except Exception:
            pass

        if errs:
            info["_collection_errors"] = errs
        return info

    def _call_api_streaming(self, print_text=True, thinking_config=None):
        from .stream_accumulator import StreamAccumulator

        tool_schemas = [tool.get_schema() for tool in self.tools]
        transient_attempts = 0
        max_transient = 5

        while True:
            acc = None
            stream_started_at = time.time()
            try:
                stream_gen = self.provider.stream(
                    messages=self.messages,
                    system=self.system_prompt,
                    tools=tool_schemas,
                    max_tokens=self.max_output_tokens,
                    thinking_config=thinking_config,
                    effort=self.effort if self.supports_effort else None,
                )

                acc = StreamAccumulator(
                    print_text=print_text,
                    assistant_prefix=config.ui.prefixes.assistant,
                    get_assistant_color=get_color,
                    show_think_content=config.ui.show_think_content,
                )

                final_response = None
                try:
                    while True:
                        acc.on_event(next(stream_gen))
                except StopIteration as e:
                    final_response = e.value

                content_list = acc.content_list

                if final_response:
                    final_response.content = content_list
                    self._capture_rate_limit_info(final_response)
                return final_response, content_list

            except Exception as e:
                if self._is_context_error(e):
                    if not self._drop_for_context_error(e):
                        raise
                    continue

                is_transient = self._is_transient_error(e)
                # Capture forensic detail for *every* streaming failure
                # (transient or fatal) before deciding what to do. Without
                # this, the debug log goes silent on failure and we cannot
                # tell timeout from 5xx from oversized-body from parser bug.
                try:
                    err_info = self._collect_stream_error_info(
                        exc=e,
                        attempt=transient_attempts + 1,
                        max_attempts=max_transient,
                        classification="transient" if is_transient else "fatal",
                        stream_started_at=stream_started_at,
                        partial_blocks=acc.content_list if acc is not None else [],
                        request_messages=self.messages,
                        request_system=self.system_prompt,
                        request_tools=tool_schemas,
                    )
                    self.logger.stream_error(err_info)
                except Exception as log_err:
                    # Logging must never mask the real error.
                    try:
                        self.logger.raw(f"stream_error logging failed: {log_err!r}")
                    except Exception:
                        pass

                if is_transient:
                    if transient_attempts >= max_transient:
                        print(
                            f"\n{Fore.RED}Network error persists after {max_transient} retries: {e}{Style.RESET_ALL}"
                        )
                        raise
                    transient_attempts += 1
                    delay = min(30, 2 ** transient_attempts)
                    # The stream may have printed partial output; insert a clear
                    # notice on its own line so the user understands the restart.
                    print(
                        f"\n{Fore.YELLOW}🌐 Stream interrupted ({type(e).__name__}); "
                        f"restarting turn in {delay}s ({transient_attempts}/{max_transient})...{Style.RESET_ALL}"
                    )
                    time.sleep(delay)
                    continue

                raise

    def chat(self, message):
        self.messages.append({"role": "user", "content": message})
        response, content_list = self._call_api()
        self.messages.append({"role": "assistant", "content": content_list})
        return response

    def _print_content(self, content_list):
        for block in content_list:
            block_type = block.get("type")
            if block_type == "thinking":
                t = block.get('thinking', '') if config.ui.show_think_content else ''
                if t:
                    print(f"{Fore.MAGENTA}🧠 Thinking: {t}{Style.RESET_ALL}")
                else:
                    print(f"{Fore.MAGENTA}🧠 Thinking...{Style.RESET_ALL}")
            elif block_type == "text":
                text = block.get("text", "")
                if text:
                    print(f"{Fore.GREEN}Agent:{Style.RESET_ALL} {text}")

    # ---- tool execution + response processing ----

    def _ensure_thinking_blocks(self):
        for msg in self.messages:
            if msg.get("role") == "assistant":
                content = msg.get("content", [])
                if isinstance(content, list):
                    msg["content"] = [
                        block
                        for block in content
                        if block.get("type") != "thinking" or block.get("signature")
                    ]

    def _execute_tools(self, response, prefix=""):
        from .tool_exec import execute_tool_uses

        def _print(line: str, path: str | None = None) -> None:
            if path:
                tool_color = get_color('tool')
                path_color = get_color('tool_path')
                print(f"{tool_color}{line}{Style.RESET_ALL} {path_color}(In {path}){Style.RESET_ALL}")
            else:
                print(f"{get_color('tool')}{line}{Style.RESET_ALL}")

        tool_results = execute_tool_uses(
            tool_uses=response.content,
            tool_map=self.tool_map,
            describe=get_tool_description,
            print_line=_print,
            prefix=prefix,
        )

        for block in response.content:
            if block.get("type") == "tool_use":
                description, path = get_tool_description(block["name"], block["input"])
                # Store description with path for display history
                full_desc = f"{description} (In {path})" if path else description
                self.display_history.append(("tool", full_desc))

        for tr in tool_results:
            try:
                parsed = json.loads(tr["content"])
            except Exception:
                parsed = {"error": "Tool returned non-JSON"}
                tr["content"] = json.dumps(parsed)
            if isinstance(parsed, dict) and "error" in parsed:
                print(f"{Fore.RED}  \u2717 Error: {parsed['error']}{Style.RESET_ALL}")

        return tool_results

    def _process_response(self, content_list):
        agent_texts = []
        found_thinking = False
        for block in content_list:
            if block.get("type") == "thinking":
                found_thinking = True
                t = block.get('thinking', '') if config.ui.show_think_content else ''
                line = f"🧠 Thinking: {t}" if t else "🧠 Thinking..."
                self.display_history.append(("thinking", line))
                if not self.stream:
                    print(f"{Fore.MAGENTA}{line}{Style.RESET_ALL}")
            elif block.get("type") == "text":
                if not self.stream:
                    print(f"{Fore.GREEN}Agent: {block['text']}{Style.RESET_ALL}")
                agent_texts.append(block["text"])
        return agent_texts

    # ---- compaction ----

    _COMPACT_PROMPT_OVERHEAD_TOKENS = 4096  # safety margin for COMPACT_PROMPT + output

    def _iter_tool_result_blocks_oldest_first(self):
        """Yield (block_dict, current_text) for every tool_result, oldest first."""
        for msg in self.messages:
            if msg.get("role") != "user":
                continue
            content = msg.get("content")
            if not isinstance(content, list):
                continue
            for block in content:
                if block.get("type") != "tool_result":
                    continue
                result = block.get("content", "")
                if isinstance(result, str):
                    yield ("str", block, result)
                elif isinstance(result, list):
                    for sub in result:
                        if isinstance(sub, dict) and sub.get("type") == "text":
                            yield ("text_part", sub, sub.get("text", ""))

    def _shrink_until_fits(self) -> None:
        """Truncate the oldest tool outputs (replace each with a placeholder)
        one at a time until the messages fit within the effective context
        budget for the compact API call.

        Effective budget = max_context_tokens - max_output_tokens
                           - _COMPACT_PROMPT_OVERHEAD_TOKENS.

        Uses a fast local char-based estimator inside the loop to avoid
        making a separate Anthropic /messages/count_tokens HTTP call per
        truncation step (which could mean 50+ network round-trips for one
        compaction). The authoritative provider count is consulted only at
        the start (to decide if shrinking is needed) and at the end (to
        verify the result actually fits).
        """
        budget = (
            self.max_context_tokens
            - self.max_output_tokens
            - self._COMPACT_PROMPT_OVERHEAD_TOKENS
        )
        if self._count_tokens(self.messages) <= budget:
            return

        def _fast_estimate() -> int:
            total_chars = len(self.system_prompt or "")
            for msg in self.messages:
                c = msg.get("content")
                if isinstance(c, str):
                    total_chars += len(c)
                elif isinstance(c, list):
                    for item in c:
                        if isinstance(item, dict):
                            if "text" in item:
                                total_chars += len(item["text"])
                            elif "content" in item:
                                total_chars += len(str(item["content"]))
                            else:
                                total_chars += len(json.dumps(item))
            return total_chars // 4

        placeholder = "[truncated to fit context]"
        truncated_count = 0
        for kind, block, text in self._iter_tool_result_blocks_oldest_first():
            if not text or text == placeholder:
                continue
            if kind == "str":
                block["content"] = placeholder
            else:  # text_part
                block["text"] = placeholder
            truncated_count += 1
            if _fast_estimate() <= budget:
                break

        # Final verification with the real (provider) counter — if the local
        # estimate was optimistic, keep shrinking the rest.
        if truncated_count and self._count_tokens(self.messages) > budget:
            for kind, block, text in self._iter_tool_result_blocks_oldest_first():
                if not text or text == placeholder:
                    continue
                if kind == "str":
                    block["content"] = placeholder
                else:
                    block["text"] = placeholder
                truncated_count += 1
                if self._count_tokens(self.messages) <= budget:
                    break

        if truncated_count:
            self.logger.raw(
                f"Truncated {truncated_count} oldest tool outputs to fit compact request."
            )

    def _compact_immediately(self) -> bool:
        """Compact self.messages into a single summary user-message in-place.

        Algorithm:
          1. Send self.messages + COMPACT_PROMPT to the LLM (no tools). The
             caller (_drop_for_context_error) is responsible for ensuring
             messages fit (via _shrink_until_fits) before this is invoked.
             The compact prompt asks the LLM to embed the current user request
             inside the summary, so the result is self-contained.
          2. Replace self.messages with [user: summary_text] only. On retry the
             LLM sees a single user turn that already contains the current
             task — no need to re-append the original request.
          3. Return True on success, False if compaction itself fails.
        """
        print()
        print_divider(config.ui.divider_width)
        print()
        print(f"{Fore.YELLOW}📦 Compacting...{Style.RESET_ALL}")

        compact_msg = {"role": "user", "content": self.COMPACT_PROMPT}
        messages_with_compact = self.messages + [compact_msg]

        try:
            stream_gen = self.provider.stream(
                messages=messages_with_compact,
                system=self.system_prompt,
                tools=[],
                max_tokens=self.max_output_tokens,
            )

            summary_text = ""
            final_response = None
            try:
                while True:
                    event = next(stream_gen)
                    if event.type == "text_delta":
                        summary_text += event.data
            except StopIteration as e:
                final_response = e.value

            if final_response:
                self._capture_rate_limit_info(final_response)

            if not summary_text.strip():
                print(f"{Fore.RED}⚠️  Compaction produced empty summary; keeping history.{Style.RESET_ALL}")
                self.logger.raw("Compaction produced empty summary; history preserved.")
                return False

            num_turns = len(self._get_turns())
            self.logger.compaction(
                "Immediate compaction (context overflow)",
                f"1-{num_turns}",
                summary_text,
            )
            self.logger.raw("")
            self.logger.req_usage(self.model_short, self.last_usage)

            # Replace history with a single user message containing the compact
            # context.  The next LLM call will see this as its conversation start.
            self.messages = [{"role": "user", "content": summary_text}]

            if config.ui.show_compact_content:
                print(f"{get_color('system')}{summary_text}{Style.RESET_ALL}")

            return True

        except Exception as e:
            print(f"{Fore.RED}⚠️  Compaction failed: {e}{Style.RESET_ALL}")
            self.logger.raw(f"Compaction error: {e}")
            return False

    # ---- run loop ----

    def run(self, user_input, max_turns=None, initial_messages=None, display_history=None):
        if initial_messages is not None:
            self.messages = initial_messages
        if display_history is not None:
            self.display_history = display_history

        self.display_history.append(("user", user_input))

        if self.think and self.messages:
            self._ensure_thinking_blocks()

        turn_num = len([h for h in self.display_history if h[0] == "user"])
        self.logger.turn_start(turn_num, user_input)

        if max_turns is None:
            max_turns = config.agent.max_turns

        response = self._agent_loop(user_input, max_turns)

        return response

    def _agent_loop(self, initial_input, max_turns):
        current_input = initial_input
        response = None

        for _ in range(max_turns):
            if current_input is not None:
                response = self.chat(current_input)
                content_list = self.messages[-1]["content"]
            else:
                response, content_list = self._call_api()
                self.messages.append({"role": "assistant", "content": content_list})

            self.logger.assistant(content_list)
            self.logger.req_usage(self.model_short, self.last_usage)
            agent_texts = self._process_response(content_list)

            if response.stop_reason == "tool_use":
                tool_results = self._execute_tools(response)
                self.logger.tool_results(tool_results)
                current_input = tool_results
            else:
                # If the provider stopped because the output budget ran out,
                # surface a clear warning so the user understands the truncation.
                if response.stop_reason == "max_tokens":
                    print(
                        f"{Fore.YELLOW}⚠️  Output truncated: max_output_tokens "
                        f"({self.max_output_tokens}) reached. "
                        f"Increase the budget or shorten the prompt.{Style.RESET_ALL}"
                    )
                # Some reasoning models (notably Hunyuan via OpenRouter) finish
                # a turn with reasoning only and no text/tool block. Without a
                # placeholder the user sees nothing after "🧠 Thinking...".
                if not agent_texts and not any(
                    b.get("type") == "tool_use" for b in content_list
                ):
                    has_thinking = any(b.get("type") == "thinking" for b in content_list)
                    placeholder = (
                        "(no visible response — the model produced only reasoning. "
                        "Try rephrasing or use a different model.)"
                        if has_thinking
                        else "(no response from model)"
                    )
                    print(f"{Fore.GREEN}Agent:{Style.RESET_ALL} {Fore.YELLOW}{placeholder}{Style.RESET_ALL}")
                    agent_texts = [placeholder]
                self.logger.end_turn()
                if agent_texts:
                    self.display_history.append(("assistant", "\n".join(agent_texts)))
                return response

        print(f"{Fore.RED}Max turns reached{Style.RESET_ALL}")
        self.logger.raw("Max turns reached")
        return response

    def continue_incomplete_turn(self, incomplete_turn, max_turns=None):
        if incomplete_turn["type"] == "execute_tools":
            class _Tmp:
                def __init__(self, content):
                    self.content = content

            tmp_response = _Tmp(incomplete_turn.get("tool_uses", []))
            tool_results = self._execute_tools(tmp_response, prefix="(Resuming) ")
            self.messages.append({"role": "user", "content": tool_results})
            self.logger.tool_results(tool_results)

        elif incomplete_turn["type"] != "continue":
            print(f"{Fore.RED}Unknown incomplete turn type: {incomplete_turn['type']}{Style.RESET_ALL}")
            return None

        if self.think:
            self._ensure_thinking_blocks()

        if max_turns is None:
            max_turns = config.agent.max_turns

        return self._agent_loop(None, max_turns)

    def get_state_for_resume(self):
        return {
            "messages": self.messages,
            "display_history": self.display_history,
            "session_info": {
                "session_id": self.session_id,
                "working_dirs": list(self.working_dirs),
            },
        }

    def _log_end_turn(self):
        """Mark current turn as ended (e.g., due to interruption)."""
        self.logger.end_turn()
