"""Session logging for resume/debug.

Keeps the log format identical to the previous inline implementation.
"""

from __future__ import annotations

import atexit
import json
from datetime import datetime
from pathlib import Path
from typing import Any, IO


class SessionLogger:
    """Append-only logger that holds the debug file open for the agent's lifetime.

    Opening / closing the file on every write (one syscall per event, ~5-8 events
    per turn) added measurable latency on Windows. Keeping the handle open and
    flushing after each write preserves crash-safety while removing the open/close
    overhead.
    """

    def __init__(self, debug_file: str) -> None:
        self.debug_file = debug_file
        Path(self.debug_file).parent.mkdir(parents=True, exist_ok=True)
        self._fh: IO[str] = open(self.debug_file, "a", encoding="utf-8")
        atexit.register(self._safe_close)

    def _safe_close(self) -> None:
        try:
            if self._fh and not self._fh.closed:
                self._fh.flush()
                self._fh.close()
        except Exception:
            pass

    def close(self) -> None:
        self._safe_close()

    def _write(self, message: str) -> None:
        self._fh.write(message + "\n")
        self._fh.flush()

    def session_start(self, workspace_dir: str, session_id: str) -> None:
        self._write("=== SESSION START ===")
        self._write(f"Timestamp: {datetime.now().isoformat()}")
        self._write(f"Workspace: {workspace_dir}")
        self._write(f"Session: {session_id}")

    def resume(self) -> None:
        self._write("\n=== RESUME ===")
        self._write(f"Timestamp: {datetime.now().isoformat()}")

    def turn_start(self, turn_num: int, user_input: Any) -> None:
        self._write(f"\n=== TURN {turn_num} ===")
        self._write("--- USER ---")
        if isinstance(user_input, str):
            self._write(user_input)
        else:
            self._write(json.dumps(user_input, indent=2, ensure_ascii=False))

    def assistant(self, content_list: Any) -> None:
        self._write("\n--- ASSISTANT ---")
        self._write(json.dumps(content_list, indent=2, ensure_ascii=False))

    def req_usage(self, model_short: str, last_usage: dict[str, Any] | None) -> None:
        if last_usage:
            usage_with_model = {"model": model_short, **last_usage}
            self._write(f"--- USAGE: {json.dumps(usage_with_model)} ---")

    def tool_results(self, tool_results: Any) -> None:
        self._write("\n--- TOOL_RESULT ---")
        self._write(json.dumps(tool_results, indent=2, ensure_ascii=False))

    def end_turn(self) -> None:
        self._write("\n--- END_TURN ---")

    def drop_turn_marker(self) -> None:
        self._write("--- DROP_TURN ---")

    def compaction(self, reason: str, removed_turns: str, summary_content: str) -> None:
        self._write("\n=== COMPACTION EVENT ===")
        self._write(f"Reason: {reason}")
        self._write(f"Removed turns: {removed_turns}")
        self._write(f"Summary content:\n{summary_content}")

    def session_info(self, info: dict[str, Any]) -> None:
        self._write("\n=== SESSION INFO ===")
        self._write(json.dumps(info))

    def raw(self, message: str) -> None:
        self._write(message)

    def stream_error(self, info: dict[str, Any]) -> None:
        """Log a streaming-API failure with full forensic detail.

        Called from the retry path in CodingAgent._call_api_streaming so that
        every Stream interrupted event has a corresponding structured entry
        (exception class, HTTP status/body, elapsed time inside the stream,
        partial content received, request size, etc.). Without this, the
        debug log goes silent on every failure and post-mortem is impossible.
        """
        self._write("\n--- STREAM_ERROR ---")
        self._write(json.dumps(info, indent=2, ensure_ascii=False, default=str))
