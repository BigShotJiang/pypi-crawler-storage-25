"""Custom hatch build hook for git-based versioning."""
import subprocess
from pathlib import Path
from hatchling.builders.hooks.plugin.interface import BuildHookInterface

# Base: last commit before 0.5.x (so first commit after = 0.5.0)
BASE_COMMIT = "3b4488b"
BASE_MINOR = 6
BASE_OFFSET = -5  # Counter rebased at 0.6.0 release (commit count was 4 pre-bump)

def get_version():
    """Calculate version from git commit count since base.

    Formula: 0.{BASE_MINOR}.{count + offset}
    - 1 commit after base → 0.5.0
    - 2 commits → 0.5.1
    - 12 commits → 0.5.11
    """
    try:
        count = int(subprocess.check_output(
            ["git", "rev-list", "--count", f"{BASE_COMMIT}..HEAD"],
            stderr=subprocess.DEVNULL, text=True
        ).strip()) + BASE_OFFSET
        return f"0.{BASE_MINOR}.{count}"
    except Exception:
        return "0.5.0"

class CustomBuildHook(BuildHookInterface):
    """Build hook that generates _version.py."""
    
    def initialize(self, version, build_data):
        version = get_version()
        version_file = Path(self.root) / "src" / "ntn" / "_version.py"
        version_file.write_text(f'__version__ = "{version}"\n')
        build_data["force_include"][str(version_file)] = "ntn/_version.py"
