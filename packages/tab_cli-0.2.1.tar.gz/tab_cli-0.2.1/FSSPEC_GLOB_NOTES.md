# Notes On Object-Store Glob Performance In `fsspec`

This note is intended as background for a future upstream issue or PR against `fsspec` and/or object-store backends such as `s3fs`, `adlfs`, and `gcsfs`.

It reflects two things:

- current code inspection
- practical measurements against a real S3 dataset

## Motivation

We observed severe slowdown on this pattern:

```text
s3://aws-public-blockchain/v1.0/btc/blocks/date=2026-01-*/*
```

This should match one month of partition directories, where each partition contains a single Parquet file.

In practice, raw cloud globbing remained unacceptably slow, while a manual segmented expansion strategy completed in a few seconds.

## Important Clarification

An earlier simplified characterization of cloud globbing as just:

```text
find(root) + regex filter
```

is too coarse for modern async/cloud implementations.

Current cloud backends may already do some server-side pruning by passing a fixed prefix down into backend-specific listing logic.

However, that optimization is still not sufficient for common partition-style patterns like:

```text
.../date=2026-01-*/*
.../year=2026/month=01/day=*/*
.../chain=btc/date=*/part-*.parquet
```

The practical performance problem still exists.

## What Object Stores Actually Provide

Object stores like S3, GCS, and Azure Blob do not provide a true server-side glob primitive.

They typically provide:

- list by prefix
- get object metadata
- fetch object

So wildcard matching is always a derived client-side operation.

The main optimization opportunity is therefore not "make glob server-side", but rather:

- minimize how much gets listed
- keep listing aligned with prefix-oriented object-store APIs

## What We Observed In Practice

Using the public S3 dataset above:

- backend authentication was not the bottleneck
- listing the parent `blocks/` prefix was reasonable
- per-file metadata lookup for the final 31 files was negligible
- raw glob expansion was the expensive step

Measured behavior:

- `ls blocks/`: about 1.0 to 1.2 seconds
- filter matching `date=2026-01-*` partition directories locally: negligible
- `ls` the 31 matched directories: about 2.4 seconds
- total manual segmented expansion: about 3.6 seconds
- raw `s3fs.glob(...)`: still too slow to finish within 120 seconds in our testing
- raw async `_glob(...)`: also too slow to be useful for this pattern

So even if current cloud paths already do some fixed-prefix pruning, the remaining strategy is still too expensive for this type of layout.

## Why Partition Patterns Are Special

These layouts are common in data lakes:

- many sibling partition directories
- each segment encodes a structured partition key
- only one or two path levels after the wildcard segment

For this case, the optimal traversal is not a generic recursive discovery step.

The optimal traversal is:

1. list the fixed parent prefix
2. match only the next path segment against the wildcard pattern
3. recurse only into matched children
4. continue one segment at a time

That is a much closer match to object-store capabilities.

## Current State By Backend

### `s3fs`

`s3fs` has custom async `_find()` behavior and can use prefix-aware listing to narrow traversal.

This is better than the most naive possible implementation.

However, for the tested partition glob, it was still too slow in practice.

The missing piece is full segmented traversal by path component, not just fixed-prefix narrowing.

### `gcsfs`

`gcsfs` also has backend-specific listing behavior and can push fixed-prefix narrowing into object listing.

That improves things compared with a totally naive subtree walk.

But it still does not amount to path-segment-aware traversal.

### `adlfs`

`adlfs` similarly narrows object listing by fixed prefix.

Again, this is helpful, but still not the same as matching segment-by-segment and descending only through matched directories.

## Remaining Gap

The important gap is:

- current pruning is mostly based on the fixed prefix before wildcarding
- partition-style globs often still need a better strategy after that point

In other words, "prefix pruning exists" does not mean "glob is now efficient enough".

For the tested workload, it was not.

## Candidate Optimization

For object-store-style backends, use segmented traversal when the pattern is compatible.

### Proposed Strategy

1. Split the path into segments.
2. Keep the longest fixed prefix before the first wildcard segment.
3. List that prefix one level at a time using delimiter-based listing semantics.
4. Apply wildcard matching only to the current segment name.
5. Recurse only into matched directory segments.
6. Fall back to the current generic strategy for complex patterns.

### Good Candidates For Segmented Traversal

- `*`
- `?`
- character classes like `[abc]` or `[0-9]`
- partition-style patterns with a fixed bucket and a fixed leading prefix

### Fallback Cases

- `**`
- brace expansion if supported externally
- bucket-level wildcarding
- backend-specific edge cases that do not map cleanly to hierarchical traversal

## Why This Still Seems Worthwhile

Even if some newer implementations already do partial pruning:

- the observed wall-clock behavior is still poor
- the remaining inefficiency appears algorithmic
- the manual segmented approach performed much better on the motivating example

So there is still a strong case for improving glob expansion for object-store partition patterns.

## Where This Could Live

Two plausible options:

### Option 1: `fsspec` Core

Improve generic glob traversal in `fsspec` when the filesystem exposes object-store-style hierarchical listing semantics.

Pros:

- shared behavior across backends
- one place to reason about segmented traversal

Cons:

- may be too specialized for a generic base implementation
- care is needed not to regress non-object-store filesystems

### Option 2: Backend Overrides

Implement optimized segmented glob traversal directly in:

- `s3fs`
- `gcsfs`
- `adlfs`

Pros:

- easier to exploit backend-specific listing semantics
- simpler to tune for object stores

Cons:

- duplicated logic
- less consistency across backends

## Recommended Framing For An Upstream Discussion

Suggested framing:

- object stores do not provide server-side glob
- fixed-prefix pruning already exists in some newer cloud backends
- but partition-style patterns are still too slow in practice
- segmented traversal by path component would better match object-store APIs
- common data-lake glob patterns would benefit significantly

## Minimal Repro Pattern

```text
s3://aws-public-blockchain/v1.0/btc/blocks/date=2026-01-*/*
```

Equivalent layouts are common across S3, GCS, and Azure.
