# Claude Code 协调器与上下文继承机制分析报告

## 一、项目概述

- **项目名称**: Claude Code
- **技术栈**: TypeScript + React + Bun
- **项目类型**: AI编程助手（安全研究/教育目的）

---

## 二、协调器核心文件分析

### 2.1 coordinatorMode.ts (`/src/coordinator/coordinatorMode.ts`)

#### 核心导出函数

| 函数名 | 签名 | 功能 |
|--------|------|------|
| `isCoordinatorMode()` | `() => boolean` | 检查协调器模式是否启用 |
| `matchSessionMode(sessionMode)` | `(sessionMode: 'coordinator' \| 'normal' \| undefined) => string \| undefined` | 匹配会话模式，必要时切换环境变量 |
| `getCoordinatorUserContext(mcpClients, scratchpadDir?)` | `(mcpClients, scratchpadDir?) => { [k: string]: string }` | 获取Worker上下文 |
| `getCoordinatorSystemPrompt()` | `() => string` | 获取协调器系统提示词 |

#### 关键常量

```typescript
const INTERNAL_WORKER_TOOLS = new Set([
  TEAM_CREATE_TOOL_NAME,
  TEAM_DELETE_TOOL_NAME,
  SEND_MESSAGE_TOOL_NAME,
  SYNTHETIC_OUTPUT_TOOL_NAME,
])
```

#### 协调器工具集配置

**Simple模式** (`CLAUDE_CODE_SIMPLE=true`):
- Bash, Read, Edit

**完整模式**:
- ASYNC_AGENT_ALLOWED_TOOLS 减去内部工具

---

### 2.2 系统提示词模板 (getCoordinatorSystemPrompt)

协调器角色定义:
- 编排软件工程任务到多个worker
- 向用户报告结果，不与worker通信
- Worker结果作为`<task-notification>` XML消息到达

**四阶段工作流**:

| 阶段 | 执行者 | 目的 |
|------|--------|------|
| Research | Workers(并行) | 调研代码库，理解问题 |
| Synthesis | Coordinator | 综合发现，制定实现规范 |
| Implementation | Workers | 按规范实现变更 |
| Verification | Workers | 测试验证 |

**Continue vs Spawn决策矩阵**:

| 情况 | 机制 | 原因 |
|------|------|------|
| 研究正好覆盖需编辑的文件 | Continue | 上下文重叠+清晰计划 |
| 研究广泛但实现狭窄 | Spawn fresh | 避免探索噪声 |
| 纠正失败/扩展最近工作 | Continue | 有错误上下文 |
| 验证其他worker刚写的代码 | Spawn fresh | 避免锚定假设 |
| 第一次尝试方向完全错误 | Spawn fresh | 错误上下文污染 |
| 完全无关任务 | Spawn fresh | 无有用上下文 |

---

## 三、上下文继承机制分析

### 3.1 任务系统 (Task.ts)

#### 任务类型枚举
```typescript
export type TaskType =
  | 'local_bash'
  | 'local_agent'
  | 'remote_agent'
  | 'in_process_teammate'
  | 'local_workflow'
  | 'monitor_mcp'
  | 'dream'
```

#### 任务状态枚举
```typescript
export type TaskStatus =
  | 'pending'
  | 'running'
  | 'completed'
  | 'failed'
  | 'killed'
```

#### 任务ID生成
```typescript
// 前缀规则
const TASK_ID_PREFIXES: Record<string, string> = {
  local_bash: 'b',
  local_agent: 'a',
  remote_agent: 'r',
  in_process_teammate: 't',
  local_workflow: 'w',
  monitor_mcp: 'm',
  dream: 'd',
}
```

---

### 3.2 本地Agent任务 (LocalAgentTask.tsx)

#### LocalAgentTaskState 状态结构
```typescript
export type LocalAgentTaskState = TaskStateBase & {
  type: 'local_agent'
  agentId: string
  prompt: string
  selectedAgent?: AgentDefinition
  agentType: string
  model?: string
  abortController?: AbortController
  error?: string
  result?: AgentToolResult
  progress?: AgentProgress
  messages?: Message[]
  isBackgrounded: boolean  // 后台运行标记
  pendingMessages: string[]  // 待处理消息队列
  retain: boolean           // UI持有标记
  diskLoaded: boolean       // 磁盘加载完成标记
}
```

#### 核心函数

| 函数 | 签名 | 功能 |
|------|------|------|
| `registerAsyncAgent()` | `(params) => LocalAgentTaskState` | 注册异步agent任务 |
| `registerAgentForeground()` | `(params) => {taskId, backgroundSignal}` | 注册前台agent任务 |
| `completeAgentTask()` | `(result, setAppState) => void` | 完成任务 |
| `failAgentTask()` | `(taskId, error, setAppState) => void` | 标记任务失败 |
| `killAsyncAgent()` | `(taskId, setAppState) => void` | 终止agent任务 |
| `killAllRunningAgentTasks()` | `(tasks, setAppState) => void` | 终止所有运行中的agent |

#### 进度追踪器
```typescript
export type ProgressTracker = {
  toolUseCount: number
  latestInputTokens: number
  cumulativeOutputTokens: number
  recentActivities: ToolActivity[]
}
```

---

### 3.3 AgentTool 实现 (AgentTool.tsx)

#### 输入模式
```typescript
const baseInputSchema = z.object({
  description: z.string(),      // 任务描述(3-5词)
  prompt: z.string(),           // 任务指令
  subagent_type: z.string().optional(),  // agent类型
  model: z.enum(['sonnet', 'opus', 'haiku']).optional(),  // 模型选择
  run_in_background: z.boolean().optional(),  // 后台运行
})

const fullInputSchema = z.object({
  ...baseInputSchema,
  name: z.string().optional(),           // worker名称(用于SendMessage)
  team_name: z.string().optional(),     // 团队名称
  mode: permissionModeSchema().optional(),  // 权限模式
  isolation: z.enum(['worktree', 'remote']).optional(),  // 隔离模式
  cwd: z.string().optional(),            // 工作目录覆盖
})
```

#### 输出模式
```typescript
// 同步完成
{ status: 'completed', prompt, ... }

// 异步启动
{ status: 'async_launched', agentId, description, outputFile, ... }

// teammate spawn
{ status: 'teammate_spawned', ... }

// remote launch
{ status: 'remote_launched', taskId, sessionUrl, ... }
```

#### Agent上下文继承机制

**Fork路径** (subagent_type为空且fork功能启用):
```typescript
// Fork路径继承父agent的:
1. 系统提示词 (systemPrompt)
2. 完整对话历史 (forkContextMessages)
3. 精确工具列表 (useExactTools)
4. thinkingConfig
5. isNonInteractiveSession
```

**Normal路径**:
```typescript
// 使用子agent自己的:
1. selectedAgent.getSystemPrompt() 生成的系统提示
2. 简化的 user message (prompt内容)
3. assembleToolPool 组装的工具池
```

#### 工作目录隔离
```typescript
// 支持三种隔离方式:
1. worktree: git worktree隔离
2. remote: 远程CCR环境
3. cwd: 显式工作目录覆盖
```

---

### 3.4 QueryEngine (QueryEngine.ts)

#### 核心类: QueryEngine

```typescript
export class QueryEngine {
  private config: QueryEngineConfig
  private mutableMessages: Message[]
  private abortController: AbortController
  private permissionDenials: SDKPermissionDenial[]
  private totalUsage: NonNullableUsage
  private readFileState: FileStateCache
  private discoveredSkillNames = new Set<string>()
  private loadedNestedMemoryPaths = new Set<string>()
}
```

#### 上下文构建流程

```typescript
// 1. 获取系统提示部分
const { defaultSystemPrompt, userContext: baseUserContext, systemContext } 
  = await fetchSystemPromptParts({...})

// 2. 合并协调器用户上下文
const userContext = {
  ...baseUserContext,
  ...getCoordinatorUserContext(mcpClients, scratchpadDir),
}

// 3. 构建最终系统提示
const systemPrompt = asSystemPrompt([
  ...(customPrompt ?? defaultSystemPrompt),
  ...(memoryMechanicsPrompt ?? []),
  ...(appendSystemPrompt ?? []),
])
```

#### 协调器上下文注入
```typescript
// 在QueryEngine中的条件导入
const getCoordinatorUserContext = feature('COORDINATOR_MODE')
  ? require('./coordinator/coordinatorMode.js').getCoordinatorUserContext
  : () => ({})
```

---

### 3.5 上下文继承关键参数传递

#### ToolUseContext 结构
```typescript
interface ToolUseContext {
  options: {
    commands: Command[]
    tools: Tools
    mainLoopModel: string
    thinkingConfig: ThinkingConfig
    mcpClients: MCPServerConnection[]
    agentDefinitions: { activeAgents: AgentDefinition[], allAgents: [] }
    customSystemPrompt?: string
    appendSystemPrompt?: string
    theme: string
    maxBudgetUsd?: number
  }
  getAppState: () => AppState
  setAppState: (f: (prev: AppState) => AppState) => void
  abortController: AbortController
  readFileState: FileStateCache
  messages: Message[]  // 对话历史
  // ...
}
```

---

## 四、Worker通信机制

### 4.1 消息通知格式
```xml
<task-notification>
<task-id>{agentId}</task-id>
<status>completed|failed|killed</status>
<summary>{summary}</summary>
<result>{final_text_response}</result>
<usage>
  <total_tokens>N</total_tokens>
  <tool_uses>N</tool_uses>
  <duration_ms>N</duration_ms>
</usage>
</task-notification>
```

### 4.2 协调器指令
- `${AGENT_TOOL_NAME}`: 启动新worker
- `${SEND_MESSAGE_TOOL_NAME}`: 继续已有worker
- `${TASK_STOP_TOOL_NAME}`: 停止运行中的worker

---

## 五、关键发现总结

### 5.1 上下文继承策略
1. **Fork模式**: 继承父agent完整上下文，适合紧密协作
2. **Spawn模式**: 使用独立上下文，适合独立任务
3. **Continue机制**: 基于SendMessage传递增量上下文

### 5.2 状态流转
```
pending → running → completed/failed/killed
```

### 5.3 隔离机制
- Worktree隔离: Git worktree
- Remote隔离: 远程CCR环境
- 内存隔离: 独立ProgressTracker

### 5.4 协调器特性
- 无直接worker间通信
- Worker结果作为XML消息到达
- 支持并行研究、串行实现、并行验证

---

## 六、文件位置索引

| 功能 | 文件路径 |
|------|----------|
| 协调器核心 | `/src/coordinator/coordinatorMode.ts` |
| 任务系统 | `/src/Task.ts` |
| 本地Agent任务 | `/src/tasks/LocalAgentTask/LocalAgentTask.tsx` |
| Agent工具 | `/src/tools/AgentTool/AgentTool.tsx` |
| 查询引擎 | `/src/QueryEngine.ts` |
| 上下文管理 | `/src/context.ts` |
| 状态管理 | `/src/state/AppState.ts` |

---

*报告生成时间: 2024*
*分析版本: Claude Code Main Branch*
