# 重规划与审查节点分析报告

## 项目：Claude Code 源码分析

**项目路径**: `/Users/fuqingrong/Documents/agent开发/claude-code-main`

---

## 一、重规划（Replan）机制分析

### 1.1 核心实现文件

| 文件路径 | 功能说明 |
|---------|---------|
| `src/utils/permissions/permissionSetup.ts` | 核心重规划模式切换逻辑 |
| `src/tools/ExitPlanModeTool/ExitPlanModeV2Tool.ts` | 退出计划模式工具 |
| `src/types/permissions.ts` | 权限模式类型定义 |
| `src/screens/REPL.tsx` | REPL 界面中的计划模式处理 |

### 1.2 关键机制：prePlanMode

**概念**：进入计划模式前，保存当前权限模式作为 `prePlanMode`，退出时恢复。

```typescript
// src/utils/permissions/permissionSetup.ts
export function prepareContextForPlanMode(context) {
  return { ...context, prePlanMode: currentMode }
}

export function kickOutOfAutoIfNeeded(ctx, reason) {
  if (ctx.prePlanMode === 'auto') {
    return { ...ctx, prePlanMode: 'default' }
  }
}
```

**状态流转**：
1. 用户进入计划模式 → `prePlanMode` 保存当前模式（如 'auto'）
2. 计划模式执行期间 → 临时权限状态
3. 退出计划模式 → `prePlanMode` 恢复或置为 'default'

### 1.3 上下文继承机制

**核心组件**：`src/utils/forkedAgent.ts`

#### CacheSafeParams 结构
```typescript
export type CacheSafeParams = {
  systemPrompt: SystemPrompt        // 系统提示词
  userContext: { [k: string]: string }  // 用户上下文
  systemContext: { [k: string]: string } // 系统上下文
  toolUseContext: ToolUseContext    // 工具使用上下文
  forkContextMessages: Message[]     // 父级消息（用于缓存共享）
}
```

#### createSubagentContext 隔离策略
- **readFileState**: 克隆自父级
- **abortController**: 创建子控制器，父级 abort 时传播
- **getAppState**: 包装以设置 `shouldAvoidPermissionPrompts`
- **Mutation callbacks**: 默认 no-op，可选共享

```typescript
// 默认隔离（后台代理）
setAppState: () => {},

// 交互式子代理可选择共享
shareSetAppState: true,  // 共享 setAppState
shareAbortController: true,  // 共享 abortController
```

---

## 二、审查（Review）节点分析

### 2.1 核心实现文件

| 文件路径 | 功能说明 |
|---------|---------|
| `src/commands/review.ts` | 本地代码审查命令 |
| `src/tools/AgentTool/built-in/verificationAgent.ts` | 内置验证代理 |
| `src/commands/review/reviewRemote.ts` | 远程审查（UltraReview） |
| `src/services/autoDream/autoDream.ts` | 自动记忆整合（类似后台审查） |

### 2.2 验证代理（Verification Agent）

**系统提示核心策略**：

```typescript
const VERIFICATION_SYSTEM_PROMPT = `
You are a verification specialist. Your job is not to confirm 
the implementation works — it's to try to break it.
`
```

**验证策略矩阵**：
| 变更类型 | 验证策略 |
|---------|---------|
| 前端变更 | 启动 dev server → 使用浏览器自动化 → 检查控制台 |
| 后端/API 变更 | 启动 server → curl/fetch → 验证响应结构 |
| CLI/脚本变更 | 运行代表性输入 → 验证 stdout/stderr/exit codes |
| Bug 修复 | 复现 bug → 验证修复 → 回归测试 |
| 数据/ML 管道 | 验证输出 schema → 测试边界值处理 |

**必需输出格式**：
```
### Check: [what you're verifying]
**Command run:**
  [exact command]
**Output observed:**
  [actual output]
**Result: PASS / FAIL / PARTIAL**
```

**判定规则**：
- `VERDICT: PASS` - 所有检查通过
- `VERDICT: FAIL` - 发现实际问题
- `VERDICT: PARTIAL` - 环境限制无法完成验证

### 2.3 自动记忆整合（AutoDream）

**后台审查机制**：
- 触发条件：24小时 + 5个会话
- 使用锁文件防止并发
- 以 forked 子代理运行

```typescript
// src/services/autoDream/autoDream.ts
async function runAutoDream(context, appendSystemMessage) {
  // Gate 检查：时间、会话数、锁
  const hoursSince = (Date.now() - lastAt) / 3_600_000
  const sessionIds = await listSessionsTouchedSince(lastAt)
  
  // 以 forked 代理运行记忆整合
  await runForkedAgent({
    promptMessages: [createUserMessage({ content: prompt })],
    cacheSafeParams: createCacheSafeParams(context),
    forkLabel: 'auto_dream',
  })
}
```

---

## 三、任务类型与上下文继承

### 3.1 任务状态类型

```typescript
// src/Task.ts
export type TaskType =
  | 'local_bash'      // 本地 bash 任务
  | 'local_agent'     // 本地代理任务
  | 'remote_agent'    // 远程代理任务
  | 'in_process_teammate'  // 进程中队友
  | 'local_workflow'  // 本地工作流
  | 'monitor_mcp'     // MCP 监控
  | 'dream'           // 记忆整合
```

### 3.2 LocalAgentTask 上下文

```typescript
// src/tasks/LocalAgentTask/LocalAgentTask.tsx
export type LocalAgentTaskState = TaskStateBase & {
  type: 'local_agent'
  agentId: string
  prompt: string
  selectedAgent?: AgentDefinition
  agentType: string
  model?: string
  abortController?: AbortController
  progress?: AgentProgress
  messages?: Message[]
  isBackgrounded: boolean
  retain: boolean      // UI 是否持有此任务
  diskLoaded: boolean  // 磁盘加载标记
}
```

### 3.3 代理上下文隔离

```typescript
// src/utils/agentContext.ts
export type SubagentContext = {
  agentId: string
  agentType: 'subagent'
  subagentName?: string
  isBuiltIn?: boolean
  invokingRequestId?: string
  invocationKind?: 'spawn' | 'resume'
}

export type TeammateAgentContext = {
  agentId: string
  agentName: string
  teamName: string
  planModeRequired: boolean  // 队友是否需要进入计划模式
  agentType: 'teammate'
}
```

---

## 四、关键发现总结

### 4.1 重规划机制特点
1. **权限上下文保存**：通过 `prePlanMode` 保存进入计划模式前的权限状态
2. **自动恢复**：退出计划模式时自动恢复到原状态
3. **临时过渡**：`prePlanMode === 'auto'` 时退出到 'default' 而非 'auto'

### 4.2 上下文继承机制
1. **缓存共享**：`CacheSafeParams` 确保 forked 代理与父代理共享提示词缓存
2. **状态隔离**：默认隔离所有可变状态，通过 `overrides` 可选择性共享
3. **AsyncLocalStorage**：用于跨异步操作追踪代理身份

### 4.3 审查机制特点
1. **对抗性验证**：验证代理尝试打破实现，而非确认其工作
2. **命令执行证据**：必须包含实际命令和输出，不接受代码阅读
3. **自动后台审查**：AutoDream 在条件满足时自动触发记忆整合

---

## 五、文件清单

### 核心分析文件
1. `src/utils/permissions/permissionSetup.ts` - 权限和计划模式逻辑
2. `src/utils/forkedAgent.ts` - Forked 代理和上下文隔离
3. `src/utils/agentContext.ts` - 代理上下文管理
4. `src/tasks/LocalAgentTask/LocalAgentTask.tsx` - 本地代理任务实现
5. `src/tools/AgentTool/built-in/verificationAgent.ts` - 验证代理
6. `src/services/autoDream/autoDream.ts` - 自动记忆整合
7. `src/Task.ts` - 任务类型定义
8. `src/types/permissions.ts` - 权限类型定义
