"""PaperForge skills package."""
