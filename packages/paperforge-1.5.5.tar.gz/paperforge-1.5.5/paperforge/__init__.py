"""paperforge — PaperForge package."""

__version__ = "1.5.5"
