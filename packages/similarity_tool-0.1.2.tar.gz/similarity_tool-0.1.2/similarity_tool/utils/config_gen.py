import yaml
import os
from .logger import logger

class ConfigGenerator:
    """Generates a schema config with per-field scoring logic and feature universes."""
    
    @staticmethod
    def generate_schema(text_field_map, structured_possibilities, output_path="configs/schema_config.yaml"):
        """
        text_field_map: List of dicts with semantic/syntactic weights.
        structured_possibilities: Dict of {feature: [universe_list]} with weights/alpha/beta.
        """
        logger.info(f"Generating schema at {output_path}...")
        
        text_fields = text_field_map 

        structured_collections = []
        for name, props in structured_possibilities.items():
            structured_collections.append({
                "name": name,
                "universe": sorted(props.get("universe", [])),
                "alpha": props.get("alpha", 1.0),
                "beta": props.get("beta", 1.0),
                "weight": props.get("weight", 0.3)
            })

        full_schema = {
            "text_fields": text_fields,
            "structured_collections": structured_collections
        }

        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        with open(output_path, 'w') as f:
            yaml.dump(full_schema, f, default_flow_style=False, sort_keys=False)
            
        logger.info("Schema config successfully written.")