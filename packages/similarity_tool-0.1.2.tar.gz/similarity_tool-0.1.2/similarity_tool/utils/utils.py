import signal
import logging

class Shutdown:
    """Listens for termination signals and executes a callback."""
    def __init__(self, cleanup_callback):
        self.cleanup_callback = cleanup_callback
        signal.signal(signal.SIGINT, self.exit_gracefully)
        signal.signal(signal.SIGTERM, self.exit_gracefully)

    def exit_gracefully(self, *args):
        logging.info("Termination signal received. Cleaning up resources...")
        self.cleanup_callback()
        logging.info("Shutdown complete. Exiting.")
        exit(0)