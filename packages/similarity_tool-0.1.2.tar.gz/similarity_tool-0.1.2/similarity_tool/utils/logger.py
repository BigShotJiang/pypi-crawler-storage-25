import logging
import sys
import os
from logging.handlers import RotatingFileHandler

def setup_logger(name="Similarity Anything", log_level=logging.INFO, log_file="logs/app.log"):
    """
    Configures a global logger with both console and rotating file handlers.
    """
    log_dir = os.path.dirname(log_file)
    if log_dir and not os.path.exists(log_dir):
        os.makedirs(log_dir)

    logger = logging.getLogger(name)
    logger.setLevel(log_level)

    if logger.hasHandlers():
        return logger

    console_fmt = logging.Formatter(
        '%(asctime)s | %(levelname)-8s | %(message)s', 
        datefmt='%H:%M:%S'
    )
    file_fmt = logging.Formatter(
        '%(asctime)s | %(name)s | %(levelname)s | %(filename)s:%(lineno)d | %(message)s'
    )

    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(console_fmt)
    logger.addHandler(console_handler)

    file_handler = RotatingFileHandler(
        log_file, maxBytes=10*1024*1024, backupCount=5
    )
    file_handler.setFormatter(file_fmt)
    logger.addHandler(file_handler)

    return logger

# Initialize a default instance
logger = setup_logger()