import pandas as pd
import json
from tqdm.auto import tqdm
from .logger import logger

class DataMapper:
    """Utility to transform flat tabular data into the Tool's ingestion format."""

    @staticmethod
    def transform_row(row, text_columns, collection_columns, id_column="id", delimiter=",", query=False):
        """
        row: A pandas Series or dictionary representing one row.
        text_columns: List of column names for semantic/syntactic processing.
        collection_columns: List of column names containing lists/tags.
        delimiter: The character separating items in collection strings (default: ",").
        """
        doc_id = str(row[id_column])
        ret = {}
        
        # Extract text fields
        text_fields = {col: str(row[col]) for col in text_columns if col in row}
        ret["text_fields"] = text_fields
        
        # Extract and clean collections
        collections = {}
        for col in collection_columns:
            val = row.get(col, [])
            
            if isinstance(val, str):
                # Attempt JSON parsing first for standard formats like "['a', 'b']"
                if val.strip().startswith('[') and val.strip().endswith(']'):
                    try:
                        collections[col] = json.loads(val.replace("'", '"'))
                        continue # Move to next column if successful
                    except:
                        pass # Fallback to custom delimiter split
                
                # Split by custom delimiter and clean whitespace
                collections[col] = [item.strip() for item in val.split(delimiter) if item.strip()]
            
            elif isinstance(val, list):
                collections[col] = val
            else:
                # Handle NaN or empty values
                collections[col] = []
        ret["collections"] = collections
                
        if query == True:
            return ret
        else:
            return doc_id, text_fields, collections

    @staticmethod
    def batch_ingest_dataframe(tool, df, text_columns, collection_columns, id_column="id", delimiter=",", batch_size=16):
        logger.info(f"Starting optimized batch ingestion loop (Batch Size: {batch_size})...")
        
        rows_pool = []
        success_count = 0
        
        pbar = tqdm(total=len(df), desc="Batched Ingestion", unit="doc")

        with tool.ingestor.conn:
            for _, row in df.iterrows():
                doc_id, text_fields, collections = DataMapper.transform_row(
                    row, text_columns, collection_columns, id_column, delimiter
                )
                rows_pool.append((doc_id, text_fields, collections))
                
                if len(rows_pool) == batch_size:
                    success_count += DataMapper._process_ingest_batch(tool, rows_pool)
                    pbar.update(len(rows_pool))
                    rows_pool.clear()
            
            if rows_pool:
                success_count += DataMapper._process_ingest_batch(tool, rows_pool)
                pbar.update(len(rows_pool))
                rows_pool.clear()

        pbar.close()
        
        tool.ingestor.save_index()
        logger.info(f"Ingestion Finished Successfully: {success_count}/{len(df)}")

    @staticmethod
    def _process_ingest_batch(tool, batch_pool) -> int:
        """Helper to compute model extraction and forward passes cleanly over pools."""
        primary_field = list(batch_pool[0][1].keys())[0]
        raw_texts = [fields[primary_field] for _, fields, _ in batch_pool]
        
        if tool.extractor is not None:
            clean_texts = tool.extractor.extract_batch(raw_texts)
        else:
            clean_texts = raw_texts

        success = 0
        for idx, (doc_id, text_fields, collections) in enumerate(batch_pool):
            try:
                text_fields[primary_field] = clean_texts[idx]
                
                full_embs = {}
                for field, text in text_fields.items():
                    full_embs[field] = tool.sem_enc._encode_single_text(text)
                
                tool.ingestor.ingest_buffered(doc_id, text_fields, collections, full_embs)
                success += 1
            except Exception as e:
                logger.error(f"Failed inside chunk execution index block: {e}")
        return success