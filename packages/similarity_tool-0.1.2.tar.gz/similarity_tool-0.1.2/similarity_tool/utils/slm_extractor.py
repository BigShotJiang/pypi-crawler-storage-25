import torch
#import os
from transformers import AutoModelForCausalLM, AutoProcessor
#from vllm import LLM, SamplingParams
import random
import numpy as np
from .logger import logger

# os.environ["VLLM_LOGGING_LEVEL"] = "WARNING"
# os.environ["VLLM_ENGINE_ITERATION_TIMEOUT_S"] = "60"
# os.environ["RAY_LOG_TO_STDERR"] = "0"

def set_determinism(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False

set_determinism(42)

class LLMExtractor:
    def __init__(self, model_id="LiquidAI/LFM2.5-1.2B-Instruct", device="cuda"):
        """
        Initializes a local, small LLM specifically tuned for text distillation.
        """
        self.device = device if torch.cuda.is_available() else "cpu"
        logger.info(f"Loading Local Distillation Engine ({model_id}) on {self.device}...")

        self.processor = AutoProcessor.from_pretrained(model_id)
        if hasattr(self.processor, "tokenizer") and self.processor.tokenizer is not None:
            self.processor.tokenizer.padding_side = "right"
            if self.processor.tokenizer.pad_token is None:
                self.processor.tokenizer.pad_token = self.processor.tokenizer.eos_token

        self.model = AutoModelForCausalLM.from_pretrained(
            model_id,
            dtype=torch.float16 if self.device == "cuda" else torch.float32,
            #attn_implementation="flash_attention_2", # enable for prod
            device_map="auto" if self.device == "cuda" else None
        )
        # self.model = LLM(
        #     model=model_id,
        #     trust_remote_code=True,
        #     dtype="float16",
        #     max_model_len=8192
        # )

        # self.sampling_params = SamplingParams(
        #     temperature=0,
        #     #top_p=0.9,
        #     #repetition_penalty=1.2,
        #     max_tokens=512
        # )

        if self.device == "cpu":
            self.model.to(self.device)

    def extract_batch(self, texts: list) -> list:
        """
        Takes a list of raw long strings and distills them concurrently 
        using GPU batch tensor operations.
        """
        if not texts:
            return []

        prompts = []
        for text in texts:
            if not text or len(text.strip()) < 50:
                prompts.append(text)
                continue
                
            messages = [
                {
                    "role": "user",
                    "content": (
                        "You are a professional information extraction engine. Your task is to extract "
                        "all core professional mandates, required hard and soft skills, any responsibilities, and the semantic core "
                        "from the following text. Ignore all conversational filler, boilerplate benefits / introduction / application instructions, "
                        "and repetitive sentences. Provide a concise, but thorough and high-density summary. Do not provide any other explanantion or commentary.\n\n"
                        f"TEXT TO EXTRACT:\n{text}"
                    )
                }
            ]
            prompt = self.processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=True, enable_thinking=False)
            prompts.append(prompt)
            # prompt = f"<|user|>\nYou are a professional information extraction engine. Your task is to extract \
            #     all core professional mandates, required hard and soft skills, any responsibilities, and the semantic core \
            #     from the following text. Ignore all conversational filler, boilerplate benefits / introduction / application instructions,\
            #         and repetitive sentences. Provide a concise, but thorough and high-density summary. \
            #             \n\n TEXT TO EXTRACT:\n{text} <|assistant|>\n"
            # prompts.append(prompt)

        try:
            inputs = self.processor(text=prompts, return_tensors="pt", padding=True, truncation=True).to(self.device)

            target_pad_id = self.processor.tokenizer.pad_token_id if hasattr(self.processor, "tokenizer") else self.model.config.eos_token_id

            attention_mask = inputs["attention_mask"]
            position_ids = attention_mask.long().cumsum(-1) - 1
            position_ids.masked_fill_(attention_mask == 0, 1)

            with torch.no_grad():
                outputs = self.model.generate(
                    input_ids=inputs["input_ids"],
                    attention_mask=attention_mask,
                    position_ids=position_ids,
                    max_new_tokens=256,
                    do_sample=True,
                    temperature=0.001,
                    repetition_penalty=1.5,
                    pad_token_id=target_pad_id,
                    eos_token_id=self.model.config.eos_token_id
                )
            
            results = []
            for idx, out in enumerate(outputs):
                input_len = inputs.input_ids[idx].shape[-1]
                generated_tokens = out[input_len:]
                summary = self.processor.decode(generated_tokens, skip_special_tokens=True).strip()
                results.append(summary)
                print(summary)

            # outputs = self.model.generate(prompts, self.sampling_params, use_tqdm=False)
            # results =  [out.outputs[0].text.strip() for out in outputs]
            # print(results)
                
            return results
        except Exception as e:
            logger.error(f"Batch extraction failed: {e}. Falling back to raw text batch.")
            return [t[:1000] for t in texts]