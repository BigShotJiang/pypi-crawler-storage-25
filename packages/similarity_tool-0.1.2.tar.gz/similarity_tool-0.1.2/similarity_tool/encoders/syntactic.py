# similarity_tool/encoders/syntactic.py

import numpy as np
from rank_bm25 import BM25Okapi

class SyntacticEncoder:
    def __init__(self, config):
        """
        config: List of text field configs from your YAML, 
        e.g., [{'name': 'text', 'syntactic_weight': 0.3}, {'name': 'title', 'syntactic_weight': 0.0}]
        """
        # Handle structural naming variances from your main_config / schema_config mappings
        self.field_configs = {f['name']: f for f in config}
        self.n_gram_range = (3, 5)

    def _tokenize(self, text):
        """Standard lower-case split tokenization."""
        if not text: 
            return []
        return text.lower().split()

    def _get_char_ngrams(self, text):
        """Generates sub-token character n-grams for typo-resistant matching paths."""
        n_min, n_max = self.n_gram_range
        text = text.lower()
        ngrams = set()
        for n in range(n_min, n_max + 1):
            for i in range(len(text) - n + 1):
                ngrams.add(text[i:i+n])
        return ngrams

    def calculate_similarity_1to1(self, text_fields_a, text_fields_b):
        """
        Fallback isolated 1:1 comparison utilizing token-overlap parameters.
        Used strictly when context profiles cannot be evaluated globally.
        """
        if isinstance(self.field_configs, list):
            self.field_configs = {f['name']: f for f in self.field_configs if isinstance(f, dict) and 'name' in f}

        field_scores = []
        total_weight = 0

        for field_name, cfg in self.field_configs.items():
            text_a = text_fields_a.get(field_name, "")
            text_b = text_fields_b.get(field_name, "")
            
            ngrams_a = self._get_char_ngrams(text_a)
            ngrams_b = self._get_char_ngrams(text_b)
            
            intersection = len(ngrams_a.intersection(ngrams_b))
            union = len(ngrams_a.union(ngrams_b))
            ngram_sim = intersection / union if union > 0 else 0.0

            words_a = set(self._tokenize(text_a))
            words_b = set(self._tokenize(text_b))
            word_sim = len(words_a.intersection(words_b)) / len(words_a.union(words_b)) if (words_a or words_b) else 0.0

            # Structural configuration fallback keys tracking handler
            weight = cfg.get('syntactic_weight', cfg.get('weight', 1.0))
            
            field_score = (ngram_sim * 0.7) + (word_sim * 0.3)
            field_scores.append(field_score * weight)
            total_weight += weight

        return sum(field_scores) / total_weight if total_weight > 0 else 0.0

    def calculate_batch_bm25_scores(self, query_doc: dict, candidates: list) -> np.ndarray:
        """
        Instantiates a localized statistical BM25 model directly over the candidate pool. Combines term frequency scaling with Jaccard sub-tokens.
        """
        if not candidates:
            return np.zeros(0)
        
        if isinstance(self.field_configs, list):
            self.field_configs = {f['name']: f for f in self.field_configs if isinstance(f, dict) and 'name' in f}

        # Initialize cumulative scores array matching our candidate list size
        total_fused_scores = np.zeros(len(candidates))
        total_field_weight = 0.0

        for field_name, cfg in self.field_configs.items():
            weight = cfg.get('syntactic_weight', cfg.get('weight', 1.0))
            if weight == 0.0:
                continue

            total_field_weight += weight
            query_text = query_doc['text_fields'].get(field_name, "")
            query_tokens = self._tokenize(query_text)

            # Build local corpus matrix from candidates for this specific text field
            cand_corpus_tokens = []
            for cand in candidates:
                cand_text = cand['text_fields'].get(field_name, "")
                cand_corpus_tokens.append(self._tokenize(cand_text))

            # Fit BM25 statistical frequencies onto the candidate sub-pool text arrays
            try:
                bm25_model = BM25Okapi(cand_corpus_tokens)
                raw_bm25_scores = np.array(bm25_model.get_scores(query_tokens), dtype=np.float32)
                
                # Apply local pool min-max normalization to fit scores between [0, 1]
                s_min, s_max = raw_bm25_scores.min(), raw_bm25_scores.max()
                bm25_range = (s_max - s_min) if s_max > s_min else 1.0
                norm_bm25_scores = (raw_bm25_scores - s_min) / bm25_range
            except Exception:
                norm_bm25_scores = np.zeros(len(candidates))

            # Compute structural character Jaccard arrays for sub-token support (typo protection)
            jaccard_scores = []
            for cand in candidates:
                cand_text = cand['text_fields'].get(field_name, "")
                
                ngrams_q = self._get_char_ngrams(query_text)
                ngrams_c = self._get_char_ngrams(cand_text)
                
                inter = len(ngrams_q.intersection(ngrams_c))
                uni = len(ngrams_q.union(ngrams_c))
                jaccard_scores.append(inter / uni if uni > 0 else 0.0)
                
            jaccard_scores = np.array(jaccard_scores, dtype=np.float32)

            # Fuse statistical TF-IDF data with typo protection vectors
            field_fused_score = (norm_bm25_scores * 0.6) + (jaccard_scores * 0.4)
            total_fused_scores += field_fused_score * weight

        if total_field_weight > 0:
            total_fused_scores /= total_field_weight

        return total_fused_scores