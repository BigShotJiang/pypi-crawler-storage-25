class StructuredEncoder:
    def __init__(self, schema_config):
        """
        schema_config: List of dicts from YAML 'structured_collections'
        """
        self.field_configs = {c['name']: c for c in schema_config}

    def _tversky(self, set_a, set_b, alpha, beta):
        """Internal math for Tversky similarity."""
        intersection = len(set_a.intersection(set_b))
        only_a = len(set_a - set_b)
        only_b = len(set_b - set_a)
        
        denom = intersection + (alpha * only_a) + (beta * only_b)
        return intersection / denom if denom > 0 else 0.0
    
    def encode(self, collections_dict: dict) -> dict:
        """
        Converts raw collection lists into python sets for Tversky math.
        """
        encoded_collections = {}
        for field_name, items in collections_dict.items():
            if isinstance(items, list):
                encoded_collections[field_name] = set(items)
            elif isinstance(items, set):
                encoded_collections[field_name] = items
            elif isinstance(items, str):
                encoded_collections[field_name] = {items}
            else:
                encoded_collections[field_name] = set()
        return encoded_collections

    def calculate_similarity(self, encoded_a, encoded_b):
        """
        Fuses all structured categories into one holistic structured score.
        Inputs are dicts of sets: {'tasks': {1, 2}, 'skills': {5, 9}}
        """
        weighted_scores = []
        total_weight = 0

        for field_name, cfg in self.field_configs.items():
            # Get sets for this specific category (default to empty set)
            set_a = encoded_a.get(field_name, set())
            set_b = encoded_b.get(field_name, set())
            
            score = self._tversky(
                set_a, 
                set_b, 
                cfg.get('alpha', 1.0), 
                cfg.get('beta', 1.0)
            )
            
            weight = cfg.get('weight', 1.0)
            weighted_scores.append(score * weight)
            total_weight += weight

        return sum(weighted_scores) / total_weight if total_weight > 0 else 0.0