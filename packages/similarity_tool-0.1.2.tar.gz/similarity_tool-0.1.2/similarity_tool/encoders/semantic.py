import numpy as np
import torch
from sentence_transformers import SentenceTransformer, util
from ..utils.logger import logger

class SemanticEncoder:
    def __init__(self, model_configs: list, strategy="concatenate"):
        """
        model_configs: List of dicts, e.g., [{'name': 'all-mpnet-base-v2', 'weight': 0.7}]
        strategy: "concatenate" or "weighted_average" (latter requires same dimensions)
        """
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self.models = {cfg['name']: SentenceTransformer(cfg['name'], device=self.device) for cfg in model_configs}
        self.weights = {cfg['name']: cfg.get('weight', 1.0) for cfg in model_configs}
        self.strategy = strategy

    def chunk_text(self, text, tokenizer, max_length=128, overlap=10):
        tokens = tokenizer.encode(text, add_special_tokens=False)
        chunks = []
        stride = max_length - overlap
        
        if stride <= 0:
            stride = max_length // 2

        # If text is short, just return it as a single chunk
        if len(tokens) <= max_length:
            return [tokenizer.decode(tokens, skip_special_tokens=True)]

        for i in range(0, len(tokens), stride):
            chunk = tokens[i : i + max_length]
            chunks.append(tokenizer.decode(chunk, skip_special_tokens=True))
            if i + max_length >= len(tokens): 
                break
        return chunks

    def encode_document(self, text_fields: dict):
        """
        Expects {'field_name': 'text_content'}
        Returns {field_name: embedding_data}
        """
        encoded_doc = {}
        for field, text in text_fields.items():
            if self.extractor is not None:
                logger.debug(f"Distilling field '{field}' via local LLM before embedding...")
                summary = self.extractor.extract_core_propositions(text)
            else:
                summary = text
            encoded_doc[field] = self._encode_single_text(summary)
        return encoded_doc

    def _encode_single_text(self, text: str):
        """Processes sliding window chunks and returns a unified, flat vector."""
        model_embeddings = {}
        
        for name, model in self.models.items():
            max_len = getattr(model, "max_seq_length", 128)
            chunks = self.chunk_text(text, model.tokenizer, max_length=max_len, overlap=20)
            if len(chunks) > 50:
                chunks = chunks[:50]

            chunk_embs = model.encode(chunks, convert_to_tensor=True, show_progress_bar=False)
            if chunk_embs.ndim > 1:
                model_embeddings[name] = torch.mean(chunk_embs, dim=0)
            else:
                model_embeddings[name] = chunk_embs

        # Strategy A: CONCATENATE (Safe fallback for different sized models)
        if self.strategy == "concatenate" or self._has_mismatched_dimensions(model_embeddings):
            if self.strategy == "weighted_average":
                logger.warning("Mismatched model dimensions detected! Automatically switching strategy to 'concatenate'.")
            return np.concatenate([e.cpu().numpy() for e in model_embeddings.values()])
            
        # Strategy B: WEIGHTED AVERAGE (Only runs if all models have matching dimensions)
        total_weight = sum(self.weights.values())
        fused_vector = None
        
        for name, emb in model_embeddings.items():
            weight = self.weights[name]
            emb_np = emb.cpu().numpy()
            
            if fused_vector is None:
                fused_vector = emb_np * (weight / total_weight)
            else:
                fused_vector += emb_np * (weight / total_weight)
                
        return fused_vector

    def _has_mismatched_dimensions(self, model_embeddings):
        """Helper to check if the ensemble contains models with different shapes."""
        shapes = [emb.shape for emb in model_embeddings.values()]
        return len(set(shapes)) > 1
    
    def calculate_similarity(self, encoded_a, encoded_b, field_weights):
        """Calculates cosine similarity over pre-flattened vectors."""
        field_scores = []
        for field, weight in field_weights.items():
            vec_a = encoded_a[field]
            vec_b = encoded_b[field]
            
            norm_a = vec_a / np.linalg.norm(vec_a)
            norm_b = vec_b / np.linalg.norm(vec_b)
            score = float(np.dot(norm_a, norm_b))
            
            field_scores.append(score * weight)
        return sum(field_scores)