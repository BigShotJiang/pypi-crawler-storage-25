import sys
try:
    import lzma
except ImportError:
    from backports import lzma
    sys.modules['lzma'] = lzma

from .main import SimilarityTool
from .engine.orchestrator import DocumentMatcher
from .engine.ingestor import IngestionUtility
from .encoders.semantic import SemanticEncoder
from .encoders.syntactic import SyntacticEncoder
from .encoders.structured import StructuredEncoder
from .utils.config_gen import ConfigGenerator
from .utils.logger import logger
from .utils.data_mapper import DataMapper

__all__ = [
    "SimilarityTool",
    "DocumentMatcher",
    "IngestionUtility",
    "SemanticEncoder",
    "SyntacticEncoder",
    "StructuredEncoder",
    "ConfigGenerator",
    "logger",
    "DataMapper"
]

__version__ = "0.0.1"