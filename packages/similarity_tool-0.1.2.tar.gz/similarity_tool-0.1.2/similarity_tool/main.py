import yaml
import numpy as np
from .encoders.semantic import SemanticEncoder
from .encoders.syntactic import SyntacticEncoder
from .encoders.structured import StructuredEncoder
from .engine.orchestrator import DocumentMatcher
from .engine.ingestor import IngestionUtility
from .utils.slm_extractor import LLMExtractor
import torch
import gc
import atexit

from .utils.logger import logger

class SimilarityTool:
    def __init__(self, main_config="configs/main_config.yaml", schema_config="configs/schema_config.yaml", use_llm_distillation=True):
        logger.info(f"Initializing SimilarityTool...")
        with open(main_config, 'r') as f:
            self.config = yaml.safe_load(f)

        logger.info(f"Main config loaded from {main_config}")

        with open(schema_config, 'r') as f:
            self.config['schema'] = yaml.safe_load(f)

        logger.info(f"Schema loaded from {schema_config}")

        self.extractor = None
        if use_llm_distillation:
            try:
                self.extractor = LLMExtractor()
            except Exception as e:
                logger.error(f"Could not boot LLM: {e}. Moving forward with raw text fallback processing.")
        
        self.sem_enc = SemanticEncoder(self.config['semantic_engine']['models'])
        self.syn_enc = SyntacticEncoder(self.config['schema']['text_fields'])
        self.str_enc = StructuredEncoder(self.config['schema']['structured_collections'])
        
        self.ingestor = IngestionUtility(self.config['storage'])
        
        self.matcher = DocumentMatcher(
            self.sem_enc, self.syn_enc, self.str_enc, self.config
        )

        atexit.register(self.shutdown)

        from .utils.utils import Shutdown
        self.killer = Shutdown(self.shutdown)

    def shutdown(self):
        """Orchestrates the deletion and cleanup of all components."""
        logger.info("\n[Shutting Down System]")
        
        if hasattr(self, 'ingestor') and self.ingestor is not None:
            self.ingestor.close()

        if hasattr(self, 'matcher') and self.matcher is not None:
            if hasattr(self.matcher, 'reranker'):
                logger.info("Unloading Cross-Encoder Reranker...")
                del self.matcher.reranker
            del self.matcher

        if hasattr(self, 'sem_enc') and self.sem_enc is not None:
            logger.info("Unloading Semantic Ensemble Models...")
            del self.sem_enc

        if hasattr(self, 'extractor') and self.extractor is not None:
            logger.info("Unloading Distillation Engine...")
            if hasattr(self.extractor, 'model'):
                del self.extractor.model
            if hasattr(self.extractor, 'tokenizer'):
                del self.extractor.tokenizer
            del self.extractor

        gc.collect()
        if torch.cuda.is_available():
            logger.info("Flushing CUDA memory...")
            torch.cuda.empty_cache()
            torch.cuda.ipc_collect()
        gc.collect()
            
        logger.info("All system resources and GPU spaces released successfully.")

    def add_to_corpus(self, doc_id, text_fields, collections, verbose=False):
        """
        Ingest a single document into the dual-store.
        text_fields: {'title': '...', 'body': '...'}
        collections: {'tasks': [...], 'skills': [...]}
        """
        encoders = {
            'semantic': self.sem_enc,
            'syntactic': self.syn_enc
        }
        self.ingestor.ingest(doc_id, text_fields, collections, encoders, verbose)

    def search(self, query_doc, limit=1000, top_k=10):
        """
        Executes candidate retrieval via FAISS and passes them to the Multi-Channel Matcher.
        """
        if hasattr(self.ingestor, 'flush_buffers'):
            self.ingestor.flush_buffers()

        primary_field = self.config['schema']['text_fields'][0]['name']
        query_text = query_doc['text_fields'][primary_field]

        if self.extractor is not None:
            logger.debug(f"Distilling single query text field via local LLM...")
            query_text = self.extractor.extract_batch([query_text])[0]
            query_doc['text_fields'][primary_field] = query_text
        
        logger.debug("Encoding query document...")
        query_emb = self.sem_enc._encode_single_text(query_text)
        
        logger.debug("Querying FAISS index with semantic encoding...")
        candidates = self.ingestor.search_vectors(query_emb, limit=limit)
        
        return self.matcher.search(query_doc, candidates=candidates, top_k=top_k)
    
    def search_composite(self, query_docs: list, limit=100, top_k=10):
        """
        N:N Search Mode.
        Fuses N query documents into a single composite query, then executes a high-speed 1:N waterfall search against the corpus.
        """
        if hasattr(self.ingestor, 'flush_buffers'):
            self.ingestor.flush_buffers()

        if not query_docs:
            raise ValueError("The query_docs list cannot be empty.")
        
        if len(query_docs) == 1:
            return self.search(query_docs[0], limit=limit, top_k=top_k)

        logger.info(f"Fusing {len(query_docs)} documents into a composite search query...")

        primary_field = self.config['schema']['text_fields'][0]['name']

        if self.extractor is not None:
            logger.debug(f"Distilling {len(query_docs)} query fields...")
            raw_texts = [doc['text_fields'].get(primary_field, "") for doc in query_docs]
            clean_texts = self.extractor.extract_batch(raw_texts)
            for idx, doc in enumerate(query_docs):
                doc['text_fields'][primary_field] = clean_texts[idx]
        
        fused_text_fields = {}
        for field_cfg in self.config['schema']['text_fields']:
            f_name = field_cfg['name']
            combined_text = " ".join([doc['text_fields'].get(f_name, "") for doc in query_docs])
            fused_text_fields[f_name] = combined_text

        fused_collections = {}
        for coll_cfg in self.config['schema']['structured_collections']:
            c_name = coll_cfg['name']
            combined_set = set()
            for doc in query_docs:
                items = doc['collections'].get(c_name, [])
                combined_set.update(items)
            fused_collections[c_name] = list(combined_set)

        composite_query_doc = {
            "text_fields": fused_text_fields,
            "collections": fused_collections
        }

        logger.debug("Encoding query documents...")
        query_embs_list = []
        for doc in query_docs:
            text_to_encode = doc['text_fields'].get(primary_field, "")
            query_embs_list.append(self.sem_enc._encode_single_text(text_to_encode))
        
        composite_query_emb = np.mean(query_embs_list, axis=0)

        logger.debug("Querying FAISS index with composite semantic centroid...")
        candidates = self.ingestor.search_vectors(composite_query_emb, limit=limit)

        return self.matcher.search(composite_query_doc, candidates=candidates, top_k=top_k)

    def compare(self, doc_a, doc_b):
        """Executes an isolated 1:1 cross-comparison score calculation."""
        return self.matcher.match_1_to_1(doc_a, doc_b)
    
    def update_config(self, category: str, key: str, value, target_name: str = None):
        """
        Allows runtime dynamic modifications of configuration parameters.
        
        Args:
            category: 'orchestrator' or 'schema'
            key: The configuration parameter key (e.g., 'weights', 'structured_collections')
            value: The new target value
            target_name: (Optional) The 'name' of the specific field or collection to modify.
            
        Usage:
            # Change macro orchestration weights:
            tool.update_config('orchestrator', 'weights', {'semantic': 0.5, 'syntactic': 0.5, 'structured': 0.0})
            
            # Change specific sub-weights or Tversky parameters inside your schema config:
            tool.update_config('schema', 'text_fields', 0.9, target_name='text')  # Modifies semantic_weight default
            tool.update_config('schema', 'structured_collections', 1.8, target_name='skills') # Modifies beta
        """
        if category == 'orchestrator':
            if category not in self.config:
                self.config[category] = {}
            self.config[category][key] = value
            
            if key == 'weights' and hasattr(self, 'matcher'):
                self.matcher.weights = value
                logger.info("Successfully hot-swapped Fusion Weights in DocumentMatcher.")
            return

        if category == 'schema':
            schema_list = self.config['schema'].get(key, [])
            
            # If the user targets a specific sub-attribute named list item
            if target_name and isinstance(schema_list, list):
                for item in schema_list:
                    if item.get('name') == target_name:
                        if key == 'text_fields':
                            if isinstance(value, dict):
                                item.update(value)
                            else:
                                item['semantic_weight'] = value
                        elif key == 'structured_collections':
                            if isinstance(value, dict):
                                item.update(value)
                            else:
                                logger.warning(f"Pass a dict to modify specific Tversky parameters for '{target_name}'.")
                                
                        logger.info(f"Dynamic Schema Hot-Swap -> Updated '{target_name}' in {key}: {item}")
                        break
            else:
                self.config['schema'][key] = value

            if hasattr(self, 'matcher'):
                self.matcher.schema = self.config['schema']
                
            if key == 'structured_collections' and hasattr(self, 'str_enc'):
                self.str_enc.field_configs = {c['name']: c for c in self.config['schema']['structured_collections']}
                logger.info("Refreshed Structured Tversky encoder field mappings.")