"""Package to manage airflow jobs"""

__version__ = "0.4.3"
