"""
CheckV: Assessing the quality of metagenome-assembled viral genomes
"""

from loguru import logger

logger.disable("checkv")

from checkv.modules import (
    complete_genomes,
    completeness,
    contamination,
    download_database,
    end_to_end,
    quality_summary,
    update_database,
)

__version__ = "1.1.1"
