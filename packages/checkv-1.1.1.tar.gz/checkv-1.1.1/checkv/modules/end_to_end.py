import os
import shutil

import checkv


def main(args):

    # if restart flag, delete tmp only 1x
    args["tmp"] = os.path.join(args["output"], "tmp")
    if args["restart"] and os.path.exists(args["tmp"]):
        shutil.rmtree(args["tmp"])
    args["restart"] = False

    checkv.contamination.main(args)
    checkv.completeness.main(args)
    checkv.complete_genomes.main(args)
    checkv.quality_summary.main(args)

    if args["remove_tmp"] and os.path.exists(args["tmp"]):
        shutil.rmtree(args["tmp"])
