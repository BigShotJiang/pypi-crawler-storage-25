import click

import checkv
from checkv.utility import get_n_available_cpus

CONTEXT_SETTINGS = {"help_option_names": ["-h", "--help"]}

INPUT_FASTA = click.Path(
    exists=True,
    file_okay=True,
    dir_okay=False,
    readable=True,
    path_type=str,
)
OUTPUT_DIR = click.Path(file_okay=False, dir_okay=True, writable=True, path_type=str)
EXISTING_DIR = click.Path(
    exists=True,
    file_okay=False,
    dir_okay=True,
    readable=True,
    path_type=str,
)
EXISTING_FILE = click.Path(
    exists=True,
    file_okay=True,
    dir_okay=False,
    readable=True,
    path_type=str,
)


class HelpOnNoArgsCommand(click.Command):
    def parse_args(self, ctx, args):
        if not args and not ctx.resilient_parsing:
            click.echo(ctx.get_help(), color=ctx.color)
            ctx.exit(0)
        return super().parse_args(ctx, args)


class HelpOnNoArgsGroup(click.Group):
    def parse_args(self, ctx, args):
        if not args and not ctx.resilient_parsing:
            click.echo(ctx.get_help(), color=ctx.color)
            ctx.exit(0)
        return super().parse_args(ctx, args)


def _run(func, program, **kwargs):
    args = dict(kwargs)
    args["program"] = program
    func(args)


def _common_sequence_options(func):
    func = click.option(
        "--quiet",
        is_flag=True,
        default=False,
        help="Suppress logging messages",
    )(func)
    return func


def _db_option(func):
    return click.option(
        "-d",
        "db",
        type=EXISTING_DIR,
        required=False,
        metavar="PATH",
        help="Reference database path. By default the CHECKVDB environment variable is used",
    )(func)


def _threads_option(help_text):
    return click.option(
        "-t",
        "threads",
        type=click.IntRange(min=1),
        default=get_n_available_cpus(),
        show_default=True,
        metavar="INT",
        help=help_text,
    )


def _restart_option(func):
    return click.option(
        "--restart",
        is_flag=True,
        default=False,
        help="Overwrite existing intermediate files. By default CheckV continues where program left off",
    )(func)


def _trimming_options(func):
    func = click.option(
        "--aggressive-trimming",
        is_flag=True,
        default=False,
        help="Identify more host regions during contamination trimming",
    )(func)
    func = click.option(
        "--conservative-trimming",
        is_flag=True,
        default=False,
        help="Identify fewer host regions during contamination trimming",
    )(func)
    return func


def _resolve_delta_cutoff(conservative_trimming, aggressive_trimming):
    if conservative_trimming and aggressive_trimming:
        raise click.UsageError(
            "--conservative-trimming and --aggressive-trimming are mutually exclusive"
        )
    if conservative_trimming:
        return 1.4
    if aggressive_trimming:
        return 1.11
    return 1.285


@click.group(cls=HelpOnNoArgsGroup, context_settings=CONTEXT_SETTINGS)
@click.version_option(version=checkv.__version__, prog_name="CheckV")
def cli():
    """CheckV: assessing the quality of metagenome-assembled viral genomes.

    Read the documentation at:
    https://bitbucket.org/berkeleylab/checkv
    """


@cli.command(
    "end_to_end",
    cls=HelpOnNoArgsCommand,
    context_settings=CONTEXT_SETTINGS,
    short_help="Run full pipeline to estimate completeness, contamination, and identify closed genomes",
)
@click.argument("input", type=INPUT_FASTA)
@click.argument("output", type=OUTPUT_DIR)
@click.version_option(version=checkv.__version__, prog_name="CheckV")
@_db_option
@click.option(
    "--remove_tmp",
    is_flag=True,
    default=False,
    help="Delete intermediate files from the output directory",
)
@_threads_option("Number of threads to use")
@_restart_option
@_common_sequence_options
@_trimming_options
def end_to_end(
    input,
    output,
    db,
    remove_tmp,
    threads,
    restart,
    quiet,
    conservative_trimming,
    aggressive_trimming,
):
    """Run full pipeline to estimate completeness, contamination, and identify closed genomes."""
    _run(
        checkv.end_to_end.main,
        "end_to_end",
        input=input,
        output=output,
        db=db,
        remove_tmp=remove_tmp,
        threads=threads,
        restart=restart,
        quiet=quiet,
        delta_cutoff=_resolve_delta_cutoff(
            conservative_trimming, aggressive_trimming
        ),
    )


@cli.command(
    "download_database",
    cls=HelpOnNoArgsCommand,
    context_settings=CONTEXT_SETTINGS,
    short_help="Download the latest version of CheckV's database",
)
@click.argument("destination", type=OUTPUT_DIR)
@click.version_option(version=checkv.__version__, prog_name="CheckV")
@click.option(
    "--quiet",
    is_flag=True,
    default=False,
    help="Suppress logging messages",
)
def download_database(destination, quiet):
    """Download the latest version of CheckV's database."""
    _run(
        checkv.download_database.main,
        "download_database",
        destination=destination,
        quiet=quiet,
    )


@cli.command(
    "update_database",
    cls=HelpOnNoArgsCommand,
    context_settings=CONTEXT_SETTINGS,
    short_help="Update CheckV's database with your own complete genomes",
)
@click.argument("source_db", type=EXISTING_DIR)
@click.argument("dest_db", type=OUTPUT_DIR)
@click.argument("genomes", type=EXISTING_FILE)
@click.version_option(version=checkv.__version__, prog_name="CheckV")
@click.option(
    "--quiet",
    is_flag=True,
    default=False,
    help="Suppress logging messages",
)
@click.option(
    "--restart",
    is_flag=True,
    default=False,
    help="Overwrite existing database",
)
@click.option(
    "--threads",
    type=click.IntRange(min=1),
    default=1,
    show_default=True,
    metavar="INT",
    help="Number of threads to use",
)
def update_database(source_db, dest_db, genomes, quiet, restart, threads):
    """Update CheckV's database with your own complete genomes."""
    _run(
        checkv.update_database.main,
        "update_database",
        source_db=source_db,
        dest_db=dest_db,
        genomes=genomes,
        quiet=quiet,
        restart=restart,
        threads=threads,
    )


@cli.command(
    "contamination",
    cls=HelpOnNoArgsCommand,
    context_settings=CONTEXT_SETTINGS,
    short_help="Identify and remove host contamination on integrated proviruses",
)
@click.argument("input", type=INPUT_FASTA)
@click.argument("output", type=OUTPUT_DIR)
@click.version_option(version=checkv.__version__, prog_name="CheckV")
@_db_option
@_threads_option("Number of threads to use")
@_restart_option
@_common_sequence_options
@_trimming_options
@click.option(
    "--exclude",
    type=EXISTING_FILE,
    required=False,
    metavar="PATH",
    hidden=True,
)
def contamination(
    input,
    output,
    db,
    threads,
    restart,
    quiet,
    conservative_trimming,
    aggressive_trimming,
    exclude,
):
    """Estimate host contamination for integrated proviruses."""
    _run(
        checkv.contamination.main,
        "contamination",
        input=input,
        output=output,
        db=db,
        threads=threads,
        restart=restart,
        quiet=quiet,
        delta_cutoff=_resolve_delta_cutoff(
            conservative_trimming, aggressive_trimming
        ),
        exclude=exclude,
    )


@cli.command(
    "completeness",
    cls=HelpOnNoArgsCommand,
    context_settings=CONTEXT_SETTINGS,
    short_help="Estimate completeness for genome fragments",
)
@click.argument("input", type=INPUT_FASTA)
@click.argument("output", type=OUTPUT_DIR)
@click.version_option(version=checkv.__version__, prog_name="CheckV")
@_db_option
@_threads_option("Number of threads to use")
@_restart_option
@click.option(
    "--percent_of_top_hit",
    type=click.FloatRange(min=0.0, max=100.0),
    default=50.0,
    hidden=True,
)
@click.option(
    "--max_aai",
    type=click.FloatRange(min=0.0, max=100.0),
    default=None,
    hidden=True,
)
@click.option(
    "--exclude_identical",
    is_flag=True,
    default=False,
    hidden=True,
)
@click.option(
    "--exclude_list",
    type=EXISTING_FILE,
    default=None,
    metavar="PATH",
    hidden=True,
)
@_common_sequence_options
def completeness(
    input,
    output,
    db,
    threads,
    restart,
    percent_of_top_hit,
    max_aai,
    exclude_identical,
    exclude_list,
    quiet,
):
    """Estimate completeness for genome fragments."""
    _run(
        checkv.completeness.main,
        "completeness",
        input=input,
        output=output,
        db=db,
        threads=threads,
        restart=restart,
        percent_of_top_hit=percent_of_top_hit,
        max_aai=max_aai,
        exclude_identical=exclude_identical,
        exclude_list=exclude_list,
        quiet=quiet,
    )


@cli.command(
    "complete_genomes",
    cls=HelpOnNoArgsCommand,
    context_settings=CONTEXT_SETTINGS,
    short_help="Identify complete genomes based on terminal repeats and flanking host regions",
)
@click.argument("input", type=INPUT_FASTA)
@click.argument("output", type=OUTPUT_DIR)
@click.version_option(version=checkv.__version__, prog_name="CheckV")
@click.option(
    "--tr_min_len",
    type=click.IntRange(min=1),
    default=21,
    show_default=True,
    metavar="INT",
    help="Minimum length of terminal repeat",
)
@click.option(
    "--tr_max_count",
    type=click.IntRange(min=0),
    default=8,
    show_default=True,
    metavar="INT",
    help="Maximum occurences of terminal repeat per contig",
)
@click.option(
    "--tr_max_ambig",
    type=click.FloatRange(min=0.0, max=1.0),
    default=0.20,
    show_default=True,
    metavar="FLOAT",
    help="Maximum fraction of terminal repeat composed of Ns",
)
@click.option(
    "--tr_max_basefreq",
    type=click.FloatRange(min=0.0, max=1.0),
    default=0.75,
    show_default=True,
    metavar="FLOAT",
    help="Maximum fraction of terminal repeat composed of single nucleotide",
)
@click.option(
    "--kmer_max_freq",
    type=click.FloatRange(min=0.0),
    default=1.5,
    show_default=True,
    metavar="FLOAT",
    help=(
        "Maximum kmer frequency. Computed by splitting genome into kmers, counting "
        "occurence of each kmer, and taking the average count. Expected value "
        "of 1.0 for no duplicated regions; 2.0 for the same genome repeated "
        "back-to-back"
    ),
)
@_common_sequence_options
def complete_genomes(
    input,
    output,
    tr_min_len,
    tr_max_count,
    tr_max_ambig,
    tr_max_basefreq,
    kmer_max_freq,
    quiet,
):
    """Identify complete genomes based on terminal repeats and flanking host regions."""
    _run(
        checkv.complete_genomes.main,
        "repeats",
        input=input,
        output=output,
        tr_min_len=tr_min_len,
        tr_max_count=tr_max_count,
        tr_max_ambig=tr_max_ambig,
        tr_max_basefreq=tr_max_basefreq,
        kmer_max_freq=kmer_max_freq,
        quiet=quiet,
    )


@cli.command(
    "quality_summary",
    cls=HelpOnNoArgsCommand,
    context_settings=CONTEXT_SETTINGS,
    short_help="Summarize results across modules",
)
@click.argument("input", type=INPUT_FASTA)
@click.argument("output", type=OUTPUT_DIR)
@click.version_option(version=checkv.__version__, prog_name="CheckV")
@click.option(
    "--remove_tmp",
    is_flag=True,
    default=False,
    help="Delete intermediate files from the output directory",
)
@_common_sequence_options
def quality_summary(input, output, remove_tmp, quiet):
    """Summarize results across modules."""
    _run(
        checkv.quality_summary.main,
        "quality_summary",
        input=input,
        output=output,
        remove_tmp=remove_tmp,
        quiet=quiet,
    )
