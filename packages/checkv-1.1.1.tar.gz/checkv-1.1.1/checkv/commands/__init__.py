"""Standalone command-line tools shipped with CheckV."""
