"""
FERAL Skill Executor — Actually Calls the APIs
=================================================
The blind vault pattern: LLM outputs tool calls,
this executor injects auth and makes the HTTP requests.
The LLM NEVER sees API keys or OAuth tokens.
"""

from __future__ import annotations
import asyncio
import os
import json
import logging
import uuid
from typing import Optional


def _check_shell_quotes(command: str) -> str | None:
    """Return an error string if shell quotes are unbalanced, else None."""
    in_single = False
    in_double = False
    i = 0
    while i < len(command):
        ch = command[i]
        if ch == '\\' and not in_single:
            i += 2
            continue
        if ch == "'" and not in_double:
            in_single = not in_single
        elif ch == '"' and not in_single:
            in_double = not in_double
        i += 1
    if in_single or in_double:
        return (
            "Shell syntax error: unbalanced quotes in command. "
            "Tip: use computer_use__write_file to create files with "
            "arbitrary content instead of shell echo/printf."
        )
    return None
import httpx

from config.loader import feral_home
from models.skill_manifest import SkillManifest, SkillEndpoint
from skills.sandbox_ports import SandboxPort, default_sandbox_port

logger = logging.getLogger("feral.executor")

# W3-A12: dangerous runners must not silently fall back to host execution.
# Keep a hardcoded fallback set so legacy manifests still get protected even
# before they add explicit `requires_sandbox: true`.
SANDBOX_REQUIRED_SKILL_IDS = {"workspace_scripts", "code_interpreter"}


class SkillExecutor:
    """
    Executes tool calls against skill endpoints.
    
    Security model (blind vault):
    1. LLM outputs: {tool: "weather_current__current", args: {q: "London"}}
    2. Executor looks up the skill manifest
    3. Executor pulls auth credentials from local vault (env vars for now)
    4. Executor makes the HTTP request with injected auth headers
    5. Executor sanitizes the response and returns it to the LLM
    6. LLM NEVER sees the raw API key
    """

    def __init__(
        self,
        daemons: dict = None,
        *,
        sandbox_port: Optional[SandboxPort] = None,
    ):
        self.client = httpx.AsyncClient(timeout=15.0)
        self._daemons = daemons or {}
        self._daemon_types: dict[str, str] = {}
        self._vault: dict[str, str] = {}
        self._blind_vault = None
        self._pending_results: dict[str, asyncio.Future] = {}
        self._wasm_sandbox = None
        # W3-A14: prefer narrow facade over a direct ``api.state`` import so
        # tests can inject and so global-state coupling shrinks.
        self._sandbox_port: SandboxPort = sandbox_port or default_sandbox_port()

    def set_sandbox_port(self, port: SandboxPort) -> None:
        """Replace the sandbox facade (used for tests/embedding scenarios)."""
        self._sandbox_port = port

    def load_vault_from_env(self):
        """Load API keys from environment variables."""
        for key, value in os.environ.items():
            if key.startswith("FERAL_KEY_"):
                skill_id = key[len("FERAL_KEY_"):]
                self._vault[skill_id] = value
                logger.info(f"Vault: loaded key for skill '{skill_id}'")

    def set_key(self, skill_id: str, key: str):
        """Manually set an API key for a skill."""
        self._vault[skill_id] = key

    def set_blind_vault(self, vault):
        """Connect the BlindVault for secure credential retrieval."""
        self._blind_vault = vault

    def set_wasm_sandbox(self, sandbox):
        """Connect the WASM sandbox for skill execution."""
        self._wasm_sandbox = sandbox

    @staticmethod
    def _is_sandbox_required(skill: SkillManifest, endpoint: SkillEndpoint) -> bool:
        if bool(getattr(endpoint, "requires_sandbox", False)):
            return True
        if bool(getattr(skill, "requires_sandbox", False)):
            return True
        return str(getattr(skill, "skill_id", "") or "") in SANDBOX_REQUIRED_SKILL_IDS

    def _sandbox_requirement_status(
        self,
        skill: SkillManifest,
        endpoint: SkillEndpoint,
    ) -> tuple[bool, str]:
        runtime = getattr(skill, "runtime", None) or getattr(endpoint, "runtime", None)
        if runtime == "wasm":
            wasm = self._wasm_sandbox
            if wasm is None:
                # W3-A14: support the narrow facade for WASM too so callers that
                # inject ``SandboxPort`` can fully avoid global state.
                try:
                    wasm = self._sandbox_port.get_wasm_sandbox()
                except Exception:
                    wasm = None
            if not wasm:
                return False, "WASM sandbox not configured"
            available_attr = getattr(wasm, "available", False)
            available = available_attr() if callable(available_attr) else bool(available_attr)
            if not available:
                return False, "WASM sandbox unavailable"
            return True, "ok"

        # Default strict boundary is Docker sandbox for host-code runners.
        try:
            docker_sandbox = self._sandbox_port.get_docker_sandbox()
        except Exception as exc:
            return False, f"sandbox port unavailable: {exc}"

        if docker_sandbox is None:
            return False, "Docker sandbox unavailable"

        try:
            available_attr = getattr(docker_sandbox, "available", None)
            available = (
                bool(available_attr())
                if callable(available_attr)
                else bool(available_attr)
            )
        except Exception as exc:
            return False, f"Docker sandbox health check failed: {exc}"

        if not available:
            return False, "Docker sandbox is not healthy"
        return True, "ok"

    def _get_key(self, skill_id: str) -> Optional[str]:
        """Get API key — checks BlindVault first, then env cache."""
        if self._blind_vault:
            key = self._blind_vault.retrieve(skill_id, requester="executor")
            if key:
                return key
        return self._vault.get(skill_id)

    async def execute(
        self,
        tool_name: str,
        args: dict,
        skill: SkillManifest,
        endpoint: SkillEndpoint,
    ) -> dict:
        """
        Execute a skill endpoint call.
        """
        logger.info(f"Executing: {tool_name} → {endpoint.method} {endpoint.url}")
        logger.info(f"  args: {args}")

        from observability.metrics import increment, observe
        import time as _time
        increment("feral.skill.invocations_total", attributes={"skill": skill.skill_id, "endpoint": endpoint.id})
        _t0 = _time.time()
        try:
            return await self._execute_inner(tool_name, args, skill, endpoint)
        finally:
            observe("feral.skill.exec_latency_ms", (_time.time() - _t0) * 1000,
                    {"skill": skill.skill_id, "endpoint": endpoint.id})

    async def _execute_inner(
        self, tool_name: str, args: dict, skill: SkillManifest, endpoint: SkillEndpoint,
    ) -> dict:
        sandbox_required = self._is_sandbox_required(skill, endpoint)
        if sandbox_required:
            sandbox_ok, sandbox_reason = self._sandbox_requirement_status(skill, endpoint)
            if not sandbox_ok:
                msg = (
                    f"Sandbox required for '{skill.skill_id}__{endpoint.id}' "
                    f"but unavailable: {sandbox_reason}"
                )
                logger.warning(msg)
                return {
                    "success": False,
                    "status_code": 503,
                    "data": None,
                    "error": msg,
                }

        # 1. Check if there's a Python implementation backing this skill
        from skills.impl import get_implementation
        impl = get_implementation(skill.skill_id)
        if impl:
            logger.info(f"Executing via Python backing class: {impl.__class__.__name__}")
            # W3-A14: keep backing implementations on the same sandbox facade
            # as the executor (avoids split-brain in tests/embedding).
            if hasattr(impl, "set_sandbox_port"):
                try:
                    impl.set_sandbox_port(self._sandbox_port)
                except Exception as exc:
                    logger.debug("impl sandbox-port injection skipped: %s", exc)
            exec_args = dict(args or {})
            if sandbox_required:
                # Let backing implementations know host fallback is forbidden.
                exec_args["_feral_require_sandbox"] = True
            try:
                result = await impl.execute(endpoint.id, exec_args, self._vault)
                if isinstance(result, dict) and "success" in result:
                    return {
                        "success": result["success"],
                        "status_code": result.get("status_code", 200),
                        "data": self._sanitize_response(result.get("data")),
                        "error": result.get("error")
                    }
                else:
                    return {
                        "success": True,
                        "status_code": 200,
                        "data": self._sanitize_response(result),
                        "error": None
                    }
            except Exception as e:
                logger.error(f"Python Skill error: {e}", exc_info=True)
                return {"success": False, "status_code": 500, "data": None, "error": str(e)}

        # 2. WASM runtime — execute in sandbox
        runtime = getattr(skill, 'runtime', None) or getattr(endpoint, 'runtime', None)
        if runtime == "wasm" and self._wasm_sandbox and self._wasm_sandbox.available:
            return await self._execute_via_wasm(tool_name, endpoint, args, skill)

        # 3. WS_EXECUTE — route to a connected daemon via WebSocket
        if endpoint.method == "WS_EXECUTE":
            return await self._execute_via_daemon(tool_name, endpoint, args, skill)

        # 4. daemon:// protocol — local shell/AppleScript execution
        if endpoint.url.startswith("daemon://"):
            return await self._execute_local_daemon(endpoint, args)

        # 5. Fallback to standard HTTP generic JSON runner
        url = endpoint.url
        method = endpoint.method.upper()
        headers = {}

        # Inject auth from vault (BlindVault → env cache fallback)
        auth_query_params = {}
        api_key = self._get_key(skill.skill_id)
        if skill.auth.type == "api_key" and api_key:
            header_name = skill.auth.api_key_header or "Authorization"
            # Some APIs (e.g. OpenWeather) use query params instead of headers
            if header_name.islower() and "-" not in header_name:
                auth_query_params[header_name] = api_key
            else:
                headers[header_name] = api_key
        elif skill.auth.type == "bearer" and api_key:
            headers["Authorization"] = f"Bearer {api_key}"

        # URL parameter substitution (e.g., /restaurants/{id}/menu)
        for param_name, param_value in args.items():
            placeholder = f"{{{param_name}}}"
            if placeholder in url:
                url = url.replace(placeholder, str(param_value))

        try:
            if method == "GET":
                query_params = {k: v for k, v in args.items() if f"{{{k}}}" not in endpoint.url}
                query_params.update(auth_query_params)
                resp = await self.client.get(url, params=query_params, headers=headers)
            elif method in ("POST", "PUT", "PATCH"):
                resp = await self.client.request(method, url, json=args, headers=headers)
            elif method == "DELETE":
                resp = await self.client.delete(url, headers=headers)
            else:
                return {"success": False, "status_code": 0, "data": None, "error": f"Unknown method: {method}"}

            # Parse response
            try:
                data = resp.json()
            except Exception:
                data = {"raw_text": resp.text[:1000]}

            # Sanitize — strip any potential prompt injection from response
            sanitized = self._sanitize_response(data)

            return {
                "success": 200 <= resp.status_code < 300,
                "status_code": resp.status_code,
                "data": sanitized,
                "error": None if resp.status_code < 400 else f"HTTP {resp.status_code}",
            }

        except httpx.TimeoutException:
            logger.error(f"Timeout calling {url}")
            return {"success": False, "status_code": 0, "data": None, "error": "Request timed out"}
        except Exception as e:
            logger.error(f"Error calling {url}: {e}")
            return {"success": False, "status_code": 0, "data": None, "error": str(e)}

    async def _execute_local_daemon(self, endpoint: SkillEndpoint, args: dict) -> dict:
        """Execute daemon:// URLs as local shell or AppleScript commands."""
        import subprocess

        path = endpoint.url.replace("daemon://local/", "")
        command = args.get("script") or args.get("command") or ""
        if not command:
            return {"success": False, "status_code": 400, "data": None, "error": "No command or script provided"}

        try:
            if path == "applescript":
                proc = await asyncio.to_thread(
                    subprocess.run,
                    ["osascript", "-e", command],
                    capture_output=True, text=True, timeout=15,
                )
            elif path == "shell":
                BLOCKED_COMMANDS = {
                    "rm ", "rm -", "rmdir", "del ", "format ", "mkfs", "dd ",
                    "> /dev/", "chmod 777", "sudo ", "sudo\t",
                    "find / -delete", "find . -delete",
                    "python -c", "python3 -c", "perl -e", "ruby -e",
                    "curl | sh", "curl | bash", "wget | sh",
                    ":(){ :|:& };:",
                }
                if any(bc in command.lower() for bc in BLOCKED_COMMANDS):
                    return {"success": False, "error": "Command blocked by safety filter", "data": {}}
                quote_err = _check_shell_quotes(command)
                if quote_err:
                    return {"success": False, "status_code": 400, "data": None, "error": quote_err}
                proc = await asyncio.to_thread(
                    subprocess.run,
                    command, shell=True,
                    capture_output=True, text=True, timeout=15,
                )
            else:
                return {"success": False, "status_code": 400, "data": None, "error": f"Unknown daemon path: {path}"}

            output = proc.stdout.strip() or proc.stderr.strip()
            return {
                "success": proc.returncode == 0,
                "status_code": 200 if proc.returncode == 0 else 500,
                "data": {"output": output, "exit_code": proc.returncode},
                "error": proc.stderr.strip() if proc.returncode != 0 else None,
            }
        except subprocess.TimeoutExpired:
            return {"success": False, "status_code": 0, "data": None, "error": "Command timed out (15s)"}
        except Exception as e:
            logger.error(f"Local daemon execution failed: {e}")
            return {"success": False, "status_code": 0, "data": None, "error": str(e)}

    async def _execute_via_wasm(
        self, tool_name: str, endpoint: SkillEndpoint, args: dict, skill: SkillManifest,
    ) -> dict:
        """Execute a skill via the WASM sandbox."""
        skills_dir = feral_home() / "skills" / skill.skill_id
        wasm_files = list(skills_dir.glob("*.wasm"))
        if not wasm_files:
            return {"success": False, "status_code": 404, "data": None, "error": f"No .wasm file found for {skill.skill_id}"}

        result = await self._wasm_sandbox.execute(
            wasm_path=str(wasm_files[0]),
            params=args,
            entry_point=endpoint.id,
        )

        return {
            "success": result.get("success", False),
            "status_code": 200 if result.get("success") else 500,
            "data": self._sanitize_response(result.get("data")),
            "error": result.get("error"),
        }

    def register_daemon_type(self, node_id: str, node_type: str):
        """Record the declared type of a connected daemon node."""
        self._daemon_types[node_id] = node_type.lower() if node_type else "unknown"

    def unregister_daemon(self, node_id: str):
        """Remove daemon type record when a node disconnects."""
        self._daemon_types.pop(node_id, None)

    async def _execute_via_daemon(
        self, tool_name: str, endpoint: SkillEndpoint, args: dict, skill: SkillManifest,
    ) -> dict:
        """Route a WS_EXECUTE skill call to the appropriate connected daemon with strict type matching."""
        target_type = (skill.daemon_node_type or "robot").lower()

        target_daemon = None
        target_ws = None

        if target_type == "any":
            for node_id, ws in self._daemons.items():
                target_daemon = node_id
                target_ws = ws
                break
        else:
            for node_id, ws in self._daemons.items():
                registered_type = self._daemon_types.get(node_id, "unknown")
                if registered_type == target_type or target_type in node_id.lower():
                    target_daemon = node_id
                    target_ws = ws
                    break

        if not target_ws:
            available = {nid: self._daemon_types.get(nid, "unknown") for nid in self._daemons}
            available_str = ", ".join(f"{nid} ({t})" for nid, t in available.items()) or "none"
            return {
                "success": False, "status_code": 503, "data": None,
                "error": f"No connected daemon of type '{target_type}' to execute {tool_name}. Available daemons: {available_str}",
            }

        request_id = str(uuid.uuid4())
        execute_msg = {
            "hop": "brain",
            "type": "execute",
            "msg_id": request_id,
            "payload": {
                "executor": endpoint.id,
                "args": args,
                "skill_id": skill.skill_id,
            },
        }

        future = asyncio.get_event_loop().create_future()
        self._pending_results[request_id] = future

        try:
            await target_ws.send_json(execute_msg)
            logger.info(f"WS_EXECUTE → {target_daemon}: {endpoint.id} (req={request_id})")

            result = await asyncio.wait_for(future, timeout=15.0)
            return {
                "success": result.get("status") == "success",
                "status_code": 200 if result.get("status") == "success" else 500,
                "data": self._sanitize_response(result.get("stdout") or result.get("data")),
                "error": result.get("error"),
            }

        except asyncio.TimeoutError:
            self._pending_results.pop(request_id, None)
            return {
                "success": False, "status_code": 504, "data": None,
                "error": f"Daemon {target_daemon} timed out executing {endpoint.id}",
            }
        except Exception as e:
            self._pending_results.pop(request_id, None)
            return {"success": False, "status_code": 500, "data": None, "error": str(e)}

    def resolve_daemon_result(self, request_id: str, result: dict):
        """Called when a daemon sends back an execute_result."""
        future = self._pending_results.pop(request_id, None)
        if future and not future.done():
            future.set_result(result)

    def _sanitize_response(self, data, max_depth: int = 5, max_str_len: int = 2000) -> any:
        """
        Sanitize API response data before feeding back to the LLM.
        Prevents:
        - Prompt injection via response content
        - Excessive data that would overflow context
        """
        if max_depth <= 0:
            return "[truncated]"

        if isinstance(data, dict):
            return {k: self._sanitize_response(v, max_depth - 1) for k, v in list(data.items())[:50]}
        elif isinstance(data, list):
            return [self._sanitize_response(item, max_depth - 1) for item in data[:20]]
        elif isinstance(data, str):
            # Truncate long strings
            if len(data) > max_str_len:
                return data[:max_str_len] + "...[truncated]"
            return data
        else:
            return data

    async def close(self):
        await self.client.aclose()
