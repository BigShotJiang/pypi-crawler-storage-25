import asyncio
import hashlib
import logging
from typing import Any

import httpx

from botjamesbot.config import SDK_VERSION
from botjamesbot.exceptions import (
    BudgetExhausted,
    InsufficientCredits,
    RateLimited,
    OrderNotActive,
)
from botjamesbot.rates import RatesCache
from botjamesbot.tokenizer import count_tokens
from botjamesbot.llm.proxy import create_llm_proxy
from botjamesbot.operations.http import TrackedHTTPClient
from botjamesbot.operations.search import TrackedSearch

logger = logging.getLogger("botjamesbot")


class Order:
    """Per-run context. Tracks all operations and handles billing."""

    BudgetExhausted = BudgetExhausted

    def __init__(
        self,
        order_id: str,
        requirements: Any,
        estimate: dict | None,
        http: httpx.AsyncClient,
        rates: RatesCache,
    ):
        self.order_id = order_id
        self.requirements = requirements
        self.estimate = estimate
        self._http = http
        self._rates = rates
        self._pending_ops: list[dict] = []
        self._flush_task: asyncio.Task | None = None
        self._closed = False

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self._flush_pending()
        self._closed = True
        return False

    def track(self, client: Any) -> Any:
        """Wrap an LLM client for automatic operation tracking."""
        return create_llm_proxy(client, self)

    @property
    def http(self) -> "TrackedHTTPClient":
        return TrackedHTTPClient(self)

    @property
    def search(self) -> "TrackedSearch":
        return TrackedSearch(self)

    async def deliver(self, result: str, files: dict | None = None) -> dict:
        """Deliver the order result."""
        await self._flush_pending()

        payload: dict = {"orderId": self.order_id}
        if result:
            payload["deliverables"] = result
        if files:
            payload["files"] = files

        resp = await self._http.post("/deliver-order", json=payload)
        if resp.status_code != 200:
            logger.error(f"Delivery failed: {resp.status_code} {resp.text}")
            raise Exception(f"Delivery failed: {resp.text}")

        self._closed = True
        return resp.json()

    async def report_operation(
        self,
        operation_type: str,
        model: str | None = None,
        input_tokens: int = 0,
        output_tokens: int = 0,
        input_text: str = "",
        response_size_kb: float = 0,
    ) -> dict | None:
        """Report an operation to the platform for billing."""
        if self._closed:
            return None

        input_text_hash = ""
        if input_text:
            input_text_hash = hashlib.sha256(input_text.encode()).hexdigest()[:16]

        payload = {
            "orderId": self.order_id,
            "operation_type": operation_type,
            "model": model,
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "input_text_hash": input_text_hash,
            "response_size_kb": response_size_kb,
            "sdk_version": SDK_VERSION,
        }

        try:
            resp = await self._http.post("/consume-credits", json=payload)

            if resp.status_code == 200:
                return resp.json()
            elif resp.status_code == 402:
                data = resp.json()
                error_type = data.get("error", "")
                if error_type == "BUDGET_EXHAUSTED":
                    raise BudgetExhausted(
                        total_consumed=data.get("order_consumed", 0),
                        budget=data.get("budget", 0),
                    )
                elif error_type == "INSUFFICIENT_CREDITS":
                    raise InsufficientCredits(data.get("message", "Insufficient credits"))
                else:
                    raise BudgetExhausted()
            elif resp.status_code == 429:
                raise RateLimited()
            else:
                logger.warning(f"consume-credits returned {resp.status_code}: {resp.text}")
                return None

        except (BudgetExhausted, InsufficientCredits, RateLimited):
            raise
        except Exception as e:
            logger.warning(f"SDK billing error (non-fatal): {e}")
            return None

    async def _flush_pending(self):
        pass  # v1: operations sent immediately, no batching
