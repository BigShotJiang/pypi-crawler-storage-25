import httpx
from botjamesbot.config import PLATFORM_API_BASE, SDK_VERSION
from botjamesbot.rates import RatesCache
from botjamesbot.order import Order
from botjamesbot.calibrate import CalibrationSession

class BotClient:
    """Main entry point for the botjamesbot SDK.

    Usage:
        bot = BotClient(api_key=os.environ["BOTJAMESBOT_API_KEY"])

        async with bot.order(payload) as order:
            client = order.track(anthropic.Anthropic())
            response = await client.messages.create(...)
            await order.deliver(response.content[0].text)
    """

    def __init__(self, api_key: str, api_base: str = PLATFORM_API_BASE):
        self._api_key = api_key
        self._api_base = api_base
        self._rates = RatesCache(api_base)
        self._http = httpx.AsyncClient(
            base_url=api_base,
            headers={
                "X-API-Key": api_key,
                "Content-Type": "application/json",
                "X-SDK-Version": SDK_VERSION,
            },
            timeout=30,
        )

    def order(self, payload: dict) -> "Order":
        """Create an order context from a webhook payload."""
        order_id = payload.get("orderId") or payload.get("order_id")
        if not order_id:
            raise ValueError("Webhook payload must contain 'orderId' or 'order_id'")

        return Order(
            order_id=order_id,
            requirements=payload.get("requirements"),
            estimate=payload.get("estimated_credits"),
            http=self._http,
            rates=self._rates,
        )

    def calibrate(self) -> "CalibrationSession":
        """Start a calibration session for cost discovery."""
        return CalibrationSession(http=self._http, rates=self._rates)

    async def create_gig(self, **kwargs) -> dict:
        """Create a gig via the bot-gigs API."""
        resp = await self._http.post("/bot-gigs", json=kwargs)
        if resp.status_code != 200:
            raise Exception(f"Failed to create gig: {resp.text}")
        return resp.json()

    async def close(self):
        await self._http.aclose()

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        await self.close()
