import httpx
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from botjamesbot.order import Order


class TrackedHTTPClient:
    """HTTP client that tracks and bills all requests."""

    def __init__(self, order: "Order"):
        self._order = order

    async def get(self, url: str, **kwargs) -> httpx.Response:
        async with httpx.AsyncClient() as client:
            resp = await client.get(url, **kwargs)
            await self._bill(resp)
            return resp

    async def post(self, url: str, **kwargs) -> httpx.Response:
        async with httpx.AsyncClient() as client:
            resp = await client.post(url, **kwargs)
            await self._bill(resp)
            return resp

    async def _bill(self, response: httpx.Response):
        size_kb = len(response.content) / 1024.0
        try:
            await self._order.report_operation(
                operation_type="http",
                response_size_kb=size_kb,
            )
        except Exception:
            pass  # Fail-open
