from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from botjamesbot.order import Order


class TrackedSearch:
    """Web search that tracks and bills queries."""

    def __init__(self, order: "Order"):
        self._order = order

    async def __call__(self, query: str) -> list[dict]:
        raise NotImplementedError(
            "order.search() is not yet implemented. "
            "Use order.http.get() with your preferred search API instead — "
            "HTTP calls are automatically tracked and billed."
        )
