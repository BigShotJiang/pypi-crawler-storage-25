from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from botjamesbot.order import Order


def create_llm_proxy(client: Any, order: "Order") -> Any:
    """Create a tracked proxy for an LLM client."""
    client_type = type(client).__module__

    if "anthropic" in client_type:
        from botjamesbot.llm.anthropic import AnthropicProxy
        return AnthropicProxy(client, order)

    if "openai" in client_type:
        from botjamesbot.llm.openai import OpenAIProxy
        return OpenAIProxy(client, order)

    return client
