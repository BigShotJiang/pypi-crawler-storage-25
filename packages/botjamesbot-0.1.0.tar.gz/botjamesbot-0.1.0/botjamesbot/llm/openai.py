import asyncio
from typing import Any, TYPE_CHECKING

from botjamesbot.tokenizer import count_tokens, count_messages_tokens

if TYPE_CHECKING:
    from botjamesbot.order import Order


class OpenAIChatCompletionsProxy:
    """Proxy for openai.OpenAI().chat.completions that tracks create() calls."""

    def __init__(self, completions: Any, order: "Order"):
        self._completions = completions
        self._order = order

    def create(self, **kwargs) -> Any:
        response = self._completions.create(**kwargs)
        self._track(kwargs, response)
        return response

    async def acreate(self, **kwargs) -> Any:
        response = await self._completions.create(**kwargs)
        self._track(kwargs, response)
        return response

    def _track(self, kwargs: dict, response: Any):
        model = kwargs.get("model", "unknown")

        messages = kwargs.get("messages", [])
        input_tokens = count_messages_tokens(messages)

        output_text = ""
        if hasattr(response, "choices") and response.choices:
            msg = response.choices[0].message
            if hasattr(msg, "content") and msg.content:
                output_text = msg.content
        output_tokens = count_tokens(output_text)

        full_input = " ".join(
            m.get("content", "") if isinstance(m.get("content"), str) else ""
            for m in messages
        )

        try:
            loop = asyncio.get_running_loop()
            loop.create_task(
                self._order.report_operation(
                    operation_type="llm",
                    model=model,
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                    input_text=full_input[:1000],
                )
            )
        except RuntimeError:
            import threading
            threading.Thread(
                target=lambda: asyncio.run(
                    self._order.report_operation(
                        operation_type="llm",
                        model=model,
                        input_tokens=input_tokens,
                        output_tokens=output_tokens,
                        input_text=full_input[:1000],
                    )
                ),
                daemon=True,
            ).start()

    def __getattr__(self, name):
        return getattr(self._completions, name)


class OpenAIChatProxy:
    def __init__(self, chat: Any, order: "Order"):
        self._chat = chat
        self._order = order
        self.completions = OpenAIChatCompletionsProxy(chat.completions, order)

    def __getattr__(self, name):
        if name == "completions":
            return self.completions
        return getattr(self._chat, name)


class OpenAIProxy:
    """Proxy for openai.OpenAI() that wraps .chat.completions with tracking."""

    def __init__(self, client: Any, order: "Order"):
        self._client = client
        self._order = order
        self.chat = OpenAIChatProxy(client.chat, order)

    def __getattr__(self, name):
        if name == "chat":
            return self.chat
        return getattr(self._client, name)
