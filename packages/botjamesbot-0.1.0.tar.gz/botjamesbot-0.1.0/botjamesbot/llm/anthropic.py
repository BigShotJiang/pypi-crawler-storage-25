import asyncio
from typing import Any, TYPE_CHECKING

from botjamesbot.tokenizer import count_tokens, count_messages_tokens

if TYPE_CHECKING:
    from botjamesbot.order import Order


class AnthropicMessagesProxy:
    """Proxy for anthropic.Anthropic().messages that tracks create() calls."""

    def __init__(self, messages: Any, order: "Order"):
        self._messages = messages
        self._order = order

    def create(self, **kwargs) -> Any:
        response = self._messages.create(**kwargs)
        self._track(kwargs, response)
        return response

    async def acreate(self, **kwargs) -> Any:
        response = await self._messages.create(**kwargs)
        self._track(kwargs, response)
        return response

    def _track(self, kwargs: dict, response: Any):
        model = kwargs.get("model", "unknown")

        messages = kwargs.get("messages", [])
        system = kwargs.get("system", "")
        input_text = system if isinstance(system, str) else ""
        input_tokens = count_tokens(input_text) + count_messages_tokens(messages)

        output_text = ""
        if hasattr(response, "content"):
            for block in response.content:
                if hasattr(block, "text"):
                    output_text += block.text
        output_tokens = count_tokens(output_text)

        full_input = input_text + " ".join(
            m.get("content", "") if isinstance(m.get("content"), str) else ""
            for m in messages
        )

        try:
            loop = asyncio.get_running_loop()
            loop.create_task(
                self._order.report_operation(
                    operation_type="llm",
                    model=model,
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                    input_text=full_input[:1000],
                )
            )
        except RuntimeError:
            import threading
            threading.Thread(
                target=lambda: asyncio.run(
                    self._order.report_operation(
                        operation_type="llm",
                        model=model,
                        input_tokens=input_tokens,
                        output_tokens=output_tokens,
                        input_text=full_input[:1000],
                    )
                ),
                daemon=True,
            ).start()

    def __getattr__(self, name):
        return getattr(self._messages, name)


class AnthropicProxy:
    """Proxy for anthropic.Anthropic() that wraps .messages with tracking."""

    def __init__(self, client: Any, order: "Order"):
        self._client = client
        self._order = order
        self.messages = AnthropicMessagesProxy(client.messages, order)

    def __getattr__(self, name):
        if name == "messages":
            return self.messages
        return getattr(self._client, name)
