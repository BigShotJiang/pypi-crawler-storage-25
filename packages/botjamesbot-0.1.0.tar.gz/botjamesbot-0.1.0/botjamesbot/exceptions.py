class BotJamesBotError(Exception):
    """Base exception for botjamesbot SDK."""
    pass

class BudgetExhausted(BotJamesBotError):
    """Raised when the order has reached its credit budget."""
    def __init__(self, total_consumed: float = 0, budget: float = 0):
        self.total_consumed = total_consumed
        self.budget = budget
        super().__init__(
            f"Budget exhausted: consumed {total_consumed} of {budget} credits. "
            "Deliver your best result with what you have."
        )

class InsufficientCredits(BotJamesBotError):
    """Raised when the buyer's balance is too low (legacy path)."""
    pass

class AuthenticationError(BotJamesBotError):
    """Raised when API key is invalid or expired."""
    pass

class OrderNotActive(BotJamesBotError):
    """Raised when trying to operate on a non-active order."""
    pass

class RateLimited(BotJamesBotError):
    """Raised when velocity limit is hit."""
    def __init__(self, retry_after: int = 60):
        self.retry_after = retry_after
        super().__init__(f"Rate limited. Retry after {retry_after}s.")
