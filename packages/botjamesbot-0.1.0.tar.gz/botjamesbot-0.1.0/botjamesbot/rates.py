import time
import httpx
from botjamesbot.config import PLATFORM_API_BASE, RATES_CACHE_TTL_SECONDS

class RatesCache:
    """Fetches and caches platform rates table."""

    def __init__(self, api_base: str = PLATFORM_API_BASE):
        self._api_base = api_base
        self._rates: list[dict] = []
        self._fetched_at: float = 0

    async def get_rates(self) -> list[dict]:
        if time.time() - self._fetched_at > RATES_CACHE_TTL_SECONDS or not self._rates:
            await self._refresh()
        return self._rates

    async def _refresh(self):
        try:
            async with httpx.AsyncClient() as client:
                resp = await client.get(f"{self._api_base}/sdk-rates", timeout=10)
                if resp.status_code == 200:
                    data = resp.json()
                    self._rates = data.get("rates", [])
                    self._fetched_at = time.time()
        except Exception:
            if not self._rates:
                self._rates = _FALLBACK_RATES
                self._fetched_at = time.time()

    def find_rate(self, model: str, operation_type: str = "llm") -> dict | None:
        import fnmatch
        for rate in self._rates:
            if rate["operation_type"] != operation_type:
                continue
            if fnmatch.fnmatch(model, rate["model_pattern"]):
                return rate
        return None

_FALLBACK_RATES = [
    {"model_pattern": "claude-sonnet-*", "operation_type": "llm", "input_credits_per_1m": 45, "output_credits_per_1m": 225},
    {"model_pattern": "claude-haiku-*", "operation_type": "llm", "input_credits_per_1m": 4, "output_credits_per_1m": 19},
    {"model_pattern": "claude-opus-*", "operation_type": "llm", "input_credits_per_1m": 225, "output_credits_per_1m": 1125},
    {"model_pattern": "gpt-4o", "operation_type": "llm", "input_credits_per_1m": 38, "output_credits_per_1m": 150},
    {"model_pattern": "gpt-4o-mini", "operation_type": "llm", "input_credits_per_1m": 3, "output_credits_per_1m": 9},
    {"model_pattern": "http_request", "operation_type": "http", "flat_credits_per_op": 1, "size_credits_per_100kb": 0.5},
    {"model_pattern": "web_search", "operation_type": "search", "flat_credits_per_op": 2},
    {"model_pattern": "mcp_tool_call", "operation_type": "mcp", "flat_credits_per_op": 1},
]
