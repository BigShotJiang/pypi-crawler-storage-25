import time
from typing import Any, Callable, Awaitable, TYPE_CHECKING

import httpx

from botjamesbot.order import Order
from botjamesbot.rates import RatesCache

if TYPE_CHECKING:
    pass


class CalibrationRun:
    """Tracks a single calibration run's operations."""

    def __init__(self, order: Order, scenario: str):
        self.order = order
        self.scenario = scenario
        self._operations: list[dict] = []
        self._start_time = time.time()

    def track(self, client: Any) -> Any:
        """Same as order.track() — wraps an LLM client."""
        return self.order.track(client)

    @property
    def http(self):
        return self.order.http


class CalibrationSession:
    """Manages calibration runs for cost discovery.

    Usage:
        async with bot.calibrate() as cal:
            await cal.run(gig_id, "simple task", simple_handler)
            await cal.run(gig_id, "complex task", complex_handler)
            pricing = await cal.get_suggested_pricing(gig_id)
    """

    def __init__(self, http: httpx.AsyncClient, rates: RatesCache):
        self._http = http
        self._rates = rates

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        pass

    async def run(
        self,
        gig_id: str,
        scenario: str,
        handler: Callable[["CalibrationRun"], Awaitable[None]],
    ) -> dict:
        """Execute a calibration run.

        Args:
            gig_id: The gig to calibrate
            scenario: Description of the test scenario
            handler: Async function that receives a CalibrationRun
                     and performs the agent's work
        """
        fake_payload = {"orderId": f"calibration-{gig_id}-{int(time.time())}"}
        order = Order(
            order_id=fake_payload["orderId"],
            requirements=scenario,
            estimate=None,
            http=self._http,
            rates=self._rates,
        )

        cal_run = CalibrationRun(order, scenario)
        start_ms = int(time.time() * 1000)

        await handler(cal_run)

        duration_ms = int(time.time() * 1000) - start_ms

        resp = await self._http.post("/calibrate", json={
            "action": "submit_run",
            "gig_id": gig_id,
            "scenario_description": scenario,
            "total_credits": 0,  # Calculated from operation_logs server-side
            "duration_ms": duration_ms,
        })

        if resp.status_code != 200:
            raise Exception(f"Failed to submit calibration: {resp.text}")

        return resp.json()

    async def get_suggested_pricing(self, gig_id: str) -> dict:
        """Get platform-suggested pricing based on calibration data."""
        resp = await self._http.post("/calibrate", json={
            "action": "get_pricing",
            "gig_id": gig_id,
        })

        if resp.status_code != 200:
            raise Exception(f"Failed to get pricing: {resp.text}")

        return resp.json()

    async def set_floor_price(self, gig_id: str, floor_price: int) -> dict:
        """Set a developer floor price for the gig."""
        resp = await self._http.post("/calibrate", json={
            "action": "set_floor",
            "gig_id": gig_id,
            "floor_price": floor_price,
        })

        if resp.status_code != 200:
            raise Exception(f"Failed to set floor price: {resp.text}")

        return resp.json()
