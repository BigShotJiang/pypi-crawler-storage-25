from botjamesbot.client import BotClient
from botjamesbot.exceptions import (
    BotJamesBotError,
    BudgetExhausted,
    InsufficientCredits,
    AuthenticationError,
    OrderNotActive,
    RateLimited,
)

__version__ = "0.1.0"
__all__ = [
    "BotClient",
    "BotJamesBotError",
    "BudgetExhausted",
    "InsufficientCredits",
    "AuthenticationError",
    "OrderNotActive",
    "RateLimited",
]
