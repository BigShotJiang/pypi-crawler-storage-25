from __future__ import annotations

from typing import Any

from .runtime import Element, create_element


def analogsimulation(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <analogsimulation /> element."""
    return create_element("analogsimulation", *elements, children=children, **props)


def battery(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <battery /> element."""
    return create_element("battery", *elements, children=children, **props)


def board(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <board /> element."""
    return create_element("board", *elements, children=children, **props)


def breakout(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <breakout /> element."""
    return create_element("breakout", *elements, children=children, **props)


def breakoutpoint(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <breakoutpoint /> element."""
    return create_element("breakoutpoint", *elements, children=children, **props)


def cadassembly(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <cadassembly /> element."""
    return create_element("cadassembly", *elements, children=children, **props)


def cadmodel(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <cadmodel /> element."""
    return create_element("cadmodel", *elements, children=children, **props)


def capacitor(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <capacitor /> element."""
    return create_element("capacitor", *elements, children=children, **props)


def chip(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <chip /> element."""
    return create_element("chip", *elements, children=children, **props)


def connector(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <connector /> element."""
    return create_element("connector", *elements, children=children, **props)


def constrainedlayout(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <constrainedlayout /> element."""
    return create_element("constrainedlayout", *elements, children=children, **props)


def constraint(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <constraint /> element."""
    return create_element("constraint", *elements, children=children, **props)


def copperpour(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <copperpour /> element."""
    return create_element("copperpour", *elements, children=children, **props)


def coppertext(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <coppertext /> element."""
    return create_element("coppertext", *elements, children=children, **props)


def courtyardcircle(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <courtyardcircle /> element."""
    return create_element("courtyardcircle", *elements, children=children, **props)


def courtyardoutline(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <courtyardoutline /> element."""
    return create_element("courtyardoutline", *elements, children=children, **props)


def courtyardpill(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <courtyardpill /> element."""
    return create_element("courtyardpill", *elements, children=children, **props)


def courtyardrect(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <courtyardrect /> element."""
    return create_element("courtyardrect", *elements, children=children, **props)


def crystal(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <crystal /> element."""
    return create_element("crystal", *elements, children=children, **props)


def currentsource(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <currentsource /> element."""
    return create_element("currentsource", *elements, children=children, **props)


def cutout(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <cutout /> element."""
    return create_element("cutout", *elements, children=children, **props)


def diode(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <diode /> element."""
    return create_element("diode", *elements, children=children, **props)


def fabricationnotedimension(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <fabricationnotedimension /> element."""
    return create_element("fabricationnotedimension", *elements, children=children, **props)


def fabricationnotepath(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <fabricationnotepath /> element."""
    return create_element("fabricationnotepath", *elements, children=children, **props)


def fabricationnoterect(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <fabricationnoterect /> element."""
    return create_element("fabricationnoterect", *elements, children=children, **props)


def fabricationnotetext(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <fabricationnotetext /> element."""
    return create_element("fabricationnotetext", *elements, children=children, **props)


def fiducial(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <fiducial /> element."""
    return create_element("fiducial", *elements, children=children, **props)


def footprint(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <footprint /> element."""
    return create_element("footprint", *elements, children=children, **props)


def fuse(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <fuse /> element."""
    return create_element("fuse", *elements, children=children, **props)


def group(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <group /> element."""
    return create_element("group", *elements, children=children, **props)


def hole(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <hole /> element."""
    return create_element("hole", *elements, children=children, **props)


def inductor(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <inductor /> element."""
    return create_element("inductor", *elements, children=children, **props)


def interconnect(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <interconnect /> element."""
    return create_element("interconnect", *elements, children=children, **props)


def jumper(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <jumper /> element."""
    return create_element("jumper", *elements, children=children, **props)


def led(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <led /> element."""
    return create_element("led", *elements, children=children, **props)


def mosfet(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <mosfet /> element."""
    return create_element("mosfet", *elements, children=children, **props)


def mountedboard(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <mountedboard /> element."""
    return create_element("mountedboard", *elements, children=children, **props)


def net(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <net /> element."""
    return create_element("net", *elements, children=children, **props)


def netalias(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <netalias /> element."""
    return create_element("netalias", *elements, children=children, **props)


def netlabel(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <netlabel /> element."""
    return create_element("netlabel", *elements, children=children, **props)


def opamp(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <opamp /> element."""
    return create_element("opamp", *elements, children=children, **props)


def panel(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <panel /> element."""
    return create_element("panel", *elements, children=children, **props)


def pcbkeepout(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <pcbkeepout /> element."""
    return create_element("pcbkeepout", *elements, children=children, **props)


def pcbnotedimension(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <pcbnotedimension /> element."""
    return create_element("pcbnotedimension", *elements, children=children, **props)


def pcbnoteline(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <pcbnoteline /> element."""
    return create_element("pcbnoteline", *elements, children=children, **props)


def pcbnotepath(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <pcbnotepath /> element."""
    return create_element("pcbnotepath", *elements, children=children, **props)


def pcbnoterect(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <pcbnoterect /> element."""
    return create_element("pcbnoterect", *elements, children=children, **props)


def pcbnotetext(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <pcbnotetext /> element."""
    return create_element("pcbnotetext", *elements, children=children, **props)


def pcbtrace(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <pcbtrace /> element."""
    return create_element("pcbtrace", *elements, children=children, **props)


def pinheader(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <pinheader /> element."""
    return create_element("pinheader", *elements, children=children, **props)


def pinout(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <pinout /> element."""
    return create_element("pinout", *elements, children=children, **props)


def platedhole(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <platedhole /> element."""
    return create_element("platedhole", *elements, children=children, **props)


def port(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <port /> element."""
    return create_element("port", *elements, children=children, **props)


def potentiometer(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <potentiometer /> element."""
    return create_element("potentiometer", *elements, children=children, **props)


def powersource(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <powersource /> element."""
    return create_element("powersource", *elements, children=children, **props)


def pushbutton(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <pushbutton /> element."""
    return create_element("pushbutton", *elements, children=children, **props)


def resistor(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <resistor /> element."""
    return create_element("resistor", *elements, children=children, **props)


def resonator(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <resonator /> element."""
    return create_element("resonator", *elements, children=children, **props)


def schematicarc(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <schematicarc /> element."""
    return create_element("schematicarc", *elements, children=children, **props)


def schematicbox(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <schematicbox /> element."""
    return create_element("schematicbox", *elements, children=children, **props)


def schematiccell(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <schematiccell /> element."""
    return create_element("schematiccell", *elements, children=children, **props)


def schematiccircle(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <schematiccircle /> element."""
    return create_element("schematiccircle", *elements, children=children, **props)


def schematicline(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <schematicline /> element."""
    return create_element("schematicline", *elements, children=children, **props)


def schematicpath(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <schematicpath /> element."""
    return create_element("schematicpath", *elements, children=children, **props)


def schematicrect(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <schematicrect /> element."""
    return create_element("schematicrect", *elements, children=children, **props)


def schematicrow(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <schematicrow /> element."""
    return create_element("schematicrow", *elements, children=children, **props)


def schematictable(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <schematictable /> element."""
    return create_element("schematictable", *elements, children=children, **props)


def schematictext(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <schematictext /> element."""
    return create_element("schematictext", *elements, children=children, **props)


def silkscreencircle(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <silkscreencircle /> element."""
    return create_element("silkscreencircle", *elements, children=children, **props)


def silkscreenline(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <silkscreenline /> element."""
    return create_element("silkscreenline", *elements, children=children, **props)


def silkscreenpath(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <silkscreenpath /> element."""
    return create_element("silkscreenpath", *elements, children=children, **props)


def silkscreenrect(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <silkscreenrect /> element."""
    return create_element("silkscreenrect", *elements, children=children, **props)


def silkscreentext(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <silkscreentext /> element."""
    return create_element("silkscreentext", *elements, children=children, **props)


def smtpad(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <smtpad /> element."""
    return create_element("smtpad", *elements, children=children, **props)


def solderjumper(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <solderjumper /> element."""
    return create_element("solderjumper", *elements, children=children, **props)


def solderpaste(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <solderpaste /> element."""
    return create_element("solderpaste", *elements, children=children, **props)


def stampboard(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <stampboard /> element."""
    return create_element("stampboard", *elements, children=children, **props)


def subcircuit(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <subcircuit /> element."""
    return create_element("subcircuit", *elements, children=children, **props)


def subpanel(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <subpanel /> element."""
    return create_element("subpanel", *elements, children=children, **props)


def switch(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <switch /> element."""
    return create_element("switch", *elements, children=children, **props)


def symbol(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <symbol /> element."""
    return create_element("symbol", *elements, children=children, **props)


def testpoint(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <testpoint /> element."""
    return create_element("testpoint", *elements, children=children, **props)


def toolingrail(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <toolingrail /> element."""
    return create_element("toolingrail", *elements, children=children, **props)


def trace(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <trace /> element."""
    return create_element("trace", *elements, children=children, **props)


def tracehint(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <tracehint /> element."""
    return create_element("tracehint", *elements, children=children, **props)


def transistor(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <transistor /> element."""
    return create_element("transistor", *elements, children=children, **props)


def via(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <via /> element."""
    return create_element("via", *elements, children=children, **props)


def voltageprobe(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <voltageprobe /> element."""
    return create_element("voltageprobe", *elements, children=children, **props)


def voltagesource(
    *elements: Any, children: Any = None, **props: Any
) -> Element:
    """Create a <voltagesource /> element."""
    return create_element("voltagesource", *elements, children=children, **props)


__all__ = [
  "analogsimulation",
  "battery",
  "board",
  "breakout",
  "breakoutpoint",
  "cadassembly",
  "cadmodel",
  "capacitor",
  "chip",
  "connector",
  "constrainedlayout",
  "constraint",
  "copperpour",
  "coppertext",
  "courtyardcircle",
  "courtyardoutline",
  "courtyardpill",
  "courtyardrect",
  "crystal",
  "currentsource",
  "cutout",
  "diode",
  "fabricationnotedimension",
  "fabricationnotepath",
  "fabricationnoterect",
  "fabricationnotetext",
  "fiducial",
  "footprint",
  "fuse",
  "group",
  "hole",
  "inductor",
  "interconnect",
  "jumper",
  "led",
  "mosfet",
  "mountedboard",
  "net",
  "netalias",
  "netlabel",
  "opamp",
  "panel",
  "pcbkeepout",
  "pcbnotedimension",
  "pcbnoteline",
  "pcbnotepath",
  "pcbnoterect",
  "pcbnotetext",
  "pcbtrace",
  "pinheader",
  "pinout",
  "platedhole",
  "port",
  "potentiometer",
  "powersource",
  "pushbutton",
  "resistor",
  "resonator",
  "schematicarc",
  "schematicbox",
  "schematiccell",
  "schematiccircle",
  "schematicline",
  "schematicpath",
  "schematicrect",
  "schematicrow",
  "schematictable",
  "schematictext",
  "silkscreencircle",
  "silkscreenline",
  "silkscreenpath",
  "silkscreenrect",
  "silkscreentext",
  "smtpad",
  "solderjumper",
  "solderpaste",
  "stampboard",
  "subcircuit",
  "subpanel",
  "switch",
  "symbol",
  "testpoint",
  "toolingrail",
  "trace",
  "tracehint",
  "transistor",
  "via",
  "voltageprobe",
  "voltagesource"
]
