from opentdx import TdxClient
def get_stock_market(stock_code):
    if stock_code.startswith(('600', '601', '603', '605', '688', '689')):
        return 'sh'
    elif stock_code.startswith(('000', '001', '002', '003', '300', '301')):
        return 'sz'
    else:
        raise ValueError(f"Invalid stock code {stock_code}. Cannot determine market.")  

def get_nearest_trade_day(client: TdxClient):
    return client.server_info()['last_trading_day']
    