# stock_sdk

A 股行情数据 SDK - 基于 HamunaStockApi

## 安装

```bash
pip install stock_sdk -U -i https://pypi.tuna.tsinghua.edu.cn/simple
```

## 快速开始

```python
import asyncio
from stock_sdk import HamunaStockApi

async def main():
    api = HamunaStockApi(
        base_url='https://stock.ai.hamuna.club',
        token='your_token'
    )

    # 获取股票列表
    stocks = await api.get_stock_list(filter_st=True)
    print(f"股票数量: {len(stocks)}")

    # 获取日K线
    kline = await api.get_daily_kline('000001', count=10)

    # 获取9:25竞价快照
    auction = await api.get_auction_0925('600000', '2026-05-15')

    # 获取昨日涨停列表
    zt = await api.get_lastday_limit()

asyncio.run(main())
```

## API

| 方法 | 说明 |
|------|------|
| `get_stock_list()` | 获取股票列表 |
| `get_daily_kline()` | 获取日K线 |
| `get_minute_kline()` | 获取分钟K线 |
| `get_auction_0925()` | 9:25竞价快照 |
| `get_lastday_limit()` | 昨日涨停列表 |
| `get_boards_tdx()` | 板块列表 |
| `get_board_members_tdx()` | 板块成员 |
| `stock_fund_flow_summary_tdx()` | 资金流 |

## 环境变量

| 变量 | 说明 |
|------|------|
| `HAMUNA_API_URL` | API 地址（默认 https://stock.ai.hamuna.club） |
| `HAMUNA_API_TOKEN` | API Token |

## License

MIT
