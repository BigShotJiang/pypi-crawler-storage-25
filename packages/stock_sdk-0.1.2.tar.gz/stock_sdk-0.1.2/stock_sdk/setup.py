from setuptools import setup, find_packages
import os
import shutil
import subprocess
import sys

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()


def clean():
    """清理旧文件"""
    for d in ['dist', 'build', 'stock_sdk.egg-info']:
        if os.path.exists(d):
            shutil.rmtree(d)


def build():
    """自动打包"""
    clean()
    # 打包
    subprocess.run([sys.executable, 'setup.py', 'sdist'], check=True)
    print("\n✅ 打包完成!")
    print("包位置: dist/")


setup(
    name="stock_sdk",
    version="0.1.2",
    author="hamuna",
    description="Hamuna Stock SDK - A股行情数据SDK",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/your-repo/stock_sdk",
    packages=find_packages(include=['stock_sdk', 'stock_sdk.*']),
    include_package_data=True,
    package_data={
        '': ['*.md', '*.json', '*.yaml'],
    },
    python_requires=">=3.8",
    install_requires=[
        "eltdx",
        "pandas",
        "httpx",
        "tqdm",
        "fake-useragent",
        "uvloop",
    ],
    extras_require={
        "dev": [
            "pytest",
            "pytest-asyncio",
            "twine",
            "build",
        ],
    },
)

# 入口命令
if __name__ == '__main__':
    if len(sys.argv) > 1:
        if sys.argv[1] == 'build':
            build()
        elif sys.argv[1] == 'clean':
            clean()
