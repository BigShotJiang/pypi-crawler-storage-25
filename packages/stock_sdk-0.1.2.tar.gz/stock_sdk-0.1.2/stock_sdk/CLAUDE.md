# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## 代码库概述

hamuna-stock-sdk 是一个股票数据 SDK，通过两个数据源获取行情：
- **通达信 TDX 协议**：直接连接 TDX 行情服务器（TCP 端口 7709/7727）
- **HTTP API**：访问远程 API（base_url + token 认证）

## 项目结构

```
stock_sdk/
├── api.py              # HamunaStockApi：HTTP API 统一入口
├── cache.py             # 磁盘缓存（diskcache）
├── utils.py            # 工具函数
├── setup.py            # 包配置
└── opentdx/
    ├── tdxClient.py    # TDX 客户端统一入口
    ├── const.py        # 常量定义（MARKET/PERIOD/ADJUST/SORT_TYPE/CATEGORY 等）
    └── client/
        ├── transport.py    # TCP 传输层（socket + 心跳）
        ├── macStandardClient.py    # A股 MAC 协议客户端
        └── macExtendedClient.py    # 扩展市场客户端
```

## TdxClient 用法

```python
from opentdx.tdxClient import TdxClient
from opentdx.const import MARKET, PERIOD, ADJUST

# 上下文管理器（推荐）
with TdxClient() as client:
    kline = client.stock_kline(MARKET.SZ, '000001', PERIOD.DAILY, count=10)

# 获取市场列表
client.stock_list(MARKET.SH)

# 获取 K 线
client.stock_kline(MARKET.SH, '600000', PERIOD.DAILY, count=250)

# 获取板块成员
client.stock_board_members("881001")
```

## HamunaStockApi 用法

```python
import asyncio
from api import HamunaStockApi

async def main():
    api = HamunaStockApi(base_url='https://stock.ai.hamuna.club', token='xxx')
    stocks = await api.get_stock_list(filter_st=True)
    klines = await api.batch_stock_fundflow_summary_tdx([s['code'] for s in stocks])

asyncio.run(main())
```

## 数据单位约定

价格 — 元 (float)
成交量 — 股 (int)
成交额 — 元 (float)
换手率 — % (float)
涨跌幅 — % (float)
时间 — datetime / time 对象

## 常用命令

```bash
# 运行主入口测试
python api.py

# 带参数运行
python -c "from opentdx.tdxClient import *; ..."
```

## 注意事项

- 需要 `stock_cache/` 目录存在（缓存存储位置）
- 需要 Python 3.12+
- TDX 服务器连接超时默认 5 秒
- HTTP 请求支持重试（最多 4 次，指数退避）