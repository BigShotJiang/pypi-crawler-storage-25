#!/bin/bash
# termflux - quick audio player script
# Author: MERO:TG@QP4RM
# Usage: ./quick_audio.sh <audio_path>

if [ -z "$1" ]; then
    echo "Usage: ./quick_audio.sh <audio_path_or_url>"
    exit 1
fi

termflux "$1" -t audio
