#!/bin/bash
# termflux - quick video player script
# Author: MERO:TG@QP4RM
# Usage: ./quick_video.sh <video_path>

if [ -z "$1" ]; then
    echo "Usage: ./quick_video.sh <video_path_or_url>"
    exit 1
fi

termflux "$1" -t video -b bold --border-color 255,100,200 -r quarter
