#!/bin/bash
# termflux - quick image display script
# Author: MERO:TG@QP4RM
# Usage: ./quick_image.sh <image_path>

if [ -z "$1" ]; then
    echo "Usage: ./quick_image.sh <image_path_or_url>"
    exit 1
fi

termflux "$1" -t image -b round --border-color 255,215,0 -r quarter
