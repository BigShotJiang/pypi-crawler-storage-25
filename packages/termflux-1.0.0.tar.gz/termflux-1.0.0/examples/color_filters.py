"""
termflux - color filter showcase
Author: MERO:TG@QP4RM

Shows the same image with different color filters applied.
Usage:
    python color_filters.py <image_path>
"""
import sys
import time
import termflux

if len(sys.argv) < 2:
    print("Usage: python color_filters.py <image_path>")
    sys.exit(1)

source = sys.argv[1]
img = termflux.Image(source)

filters = [
    {"name": "Normal", "brightness": 1.0, "contrast": 1.0, "saturation": 1.0,
     "grayscale": False, "invert": False},
    {"name": "High Contrast", "brightness": 1.0, "contrast": 1.5, "saturation": 1.0,
     "grayscale": False, "invert": False},
    {"name": "Vivid", "brightness": 1.1, "contrast": 1.1, "saturation": 1.8,
     "grayscale": False, "invert": False},
    {"name": "Grayscale", "brightness": 1.0, "contrast": 1.0, "saturation": 1.0,
     "grayscale": True, "invert": False},
    {"name": "Inverted", "brightness": 1.0, "contrast": 1.0, "saturation": 1.0,
     "grayscale": False, "invert": True},
    {"name": "Bright", "brightness": 1.5, "contrast": 1.0, "saturation": 1.0,
     "grayscale": False, "invert": False},
    {"name": "Dark", "brightness": 0.5, "contrast": 1.0, "saturation": 1.0,
     "grayscale": False, "invert": False},
    {"name": "Desaturated", "brightness": 1.0, "contrast": 1.0, "saturation": 0.3,
     "grayscale": False, "invert": False},
]

try:
    for f in filters:
        termflux.clear_screen()
        termflux.hide_cursor()
        sys.stderr.write("\033[1;1H\033[37mFilter: {}\033[0m".format(f["name"]))
        img.show(
            border_style=termflux.BORDER_ROUND,
            border_r=200, border_g=200, border_b=200,
            position="center",
            render_mode=termflux.RENDER_QUARTER,
            brightness=f["brightness"],
            contrast=f["contrast"],
            saturation=f["saturation"],
            grayscale=f["grayscale"],
            invert=f["invert"],
        )
        time.sleep(2.5)
except KeyboardInterrupt:
    pass
finally:
    termflux.reset()
