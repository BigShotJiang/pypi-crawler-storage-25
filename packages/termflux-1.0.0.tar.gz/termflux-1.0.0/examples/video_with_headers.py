import termflux
import sys
import time
import signal
import subprocess

from termflux.loader import fetch

try:
    from termflux._decoder import Decoder
    _HAS_DECODER = True
except ImportError:
    _HAS_DECODER = False


class _FallbackDecoder:
    def __init__(self, path):
        self._path = path
        info = subprocess.run(
            ["ffprobe", "-v", "quiet", "-select_streams", "v:0",
             "-show_entries", "stream=width,height,r_frame_rate,duration",
             "-show_entries", "format=duration",
             "-of", "csv=p=0", path],
            capture_output=True, text=True,
        )
        lines = info.stdout.strip().split("\n")
        parts = lines[0].split(",")
        self.width = int(parts[0])
        self.height = int(parts[1])
        if "/" in parts[2]:
            num, den = parts[2].split("/")
            self.fps = float(num) / float(den) if float(den) else 30.0
        else:
            self.fps = float(parts[2]) if parts[2] else 30.0
        try:
            self.duration = float(parts[3]) if len(parts) > 3 and parts[3] else 0.0
        except (ValueError, IndexError):
            self.duration = 0.0
        if self.duration == 0.0 and len(lines) > 1:
            try:
                self.duration = float(lines[1].strip())
            except (ValueError, IndexError):
                pass
        self._proc = None
        self._start_decode()

    def _start_decode(self):
        if self._proc and self._proc.poll() is None:
            self._proc.kill()
        self._proc = subprocess.Popen(
            ["ffmpeg", "-i", self._path,
             "-f", "rawvideo", "-pix_fmt", "rgb24", "-"],
            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
        )

    def next_frame(self):
        frame_size = self.width * self.height * 3
        data = self._proc.stdout.read(frame_size)
        if len(data) < frame_size:
            return None
        return data


def draw_header(tw, title, subtitle, info_left, info_right, frame_num, total_frames):
    parts = []
    bar_color = "\033[48;2;20;20;30m\033[38;2;0;255;200m"
    dim_color = "\033[48;2;20;20;30m\033[38;2;120;120;140m"
    bright_color = "\033[48;2;20;20;30m\033[38;2;255;255;255m"
    accent_color = "\033[48;2;20;20;30m\033[38;2;0;200;255m"
    reset = "\033[0m"

    parts.append("\033[1;1H")
    parts.append(bar_color + " " * tw + reset)
    parts.append("\033[1;2H")
    parts.append(bright_color + " termflux " + reset)
    parts.append(bar_color + "| " + reset)
    parts.append(accent_color + title + reset)
    ver_text = "v1.0.0 "
    parts.append("\033[1;{}H".format(tw - len(ver_text)))
    parts.append(dim_color + ver_text + reset)

    parts.append("\033[2;1H")
    parts.append(bar_color + " " * tw + reset)
    parts.append("\033[2;2H")
    parts.append(dim_color + " " + subtitle + reset)

    parts.append("\033[3;1H")
    parts.append(bar_color + " " * tw + reset)
    parts.append("\033[3;2H")
    parts.append(dim_color + " " + info_left + reset)
    parts.append("\033[3;{}H".format(tw - len(info_right) - 1))
    parts.append(dim_color + info_right + " " + reset)

    if total_frames > 0:
        progress = frame_num / total_frames
        bar_w = tw - 4
        filled = int(bar_w * progress)
        parts.append("\033[4;1H")
        parts.append(bar_color + " " * tw + reset)
        parts.append("\033[4;3H")
        parts.append("\033[38;2;0;255;200m")
        parts.append("\xe2\x96\x88" * filled)
        parts.append("\033[38;2;40;40;60m")
        parts.append("\xe2\x96\x91" * (bar_w - filled))
        parts.append(reset)

    return "".join(parts)


def main():
    source = "/home/ubuntu/pinterest_video.mp4"
    local = fetch(source)

    if _HAS_DECODER:
        decoder = Decoder(path=local)
    else:
        decoder = _FallbackDecoder(local)

    tw, th = termflux.get_terminal_size()
    sys.stderr.write("Terminal: {}x{}\n".format(tw, th))
    sys.stderr.write("Video: {}x{} @ {}fps, {:.1f}s\n".format(
        decoder.width, decoder.height, decoder.fps, decoder.duration))

    header_rows = 5
    video_th = th - header_rows
    video_tw = tw

    from termflux.image import _compute_display_size, _compute_offset
    rw, rh = _compute_display_size(
        decoder.width, decoder.height,
        video_tw, video_th, None, None, "fit",
        termflux.BORDER_NONE, 0, 0)
    ox, oy = _compute_offset("center", rw, rh, video_tw, video_th)
    oy += header_rows

    running = True
    prev_handler = signal.getsignal(signal.SIGINT)
    def _stop(sig, frame):
        nonlocal running
        running = False
    signal.signal(signal.SIGINT, _stop)

    termflux.clear_screen()
    termflux.hide_cursor()

    audio_proc = None
    try:
        audio_proc = subprocess.Popen(
            ["ffplay", "-nodisp", "-autoexit", "-loglevel", "quiet", local],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )
    except Exception:
        pass

    spf = 1.0 / decoder.fps
    t0 = time.monotonic()
    frame_idx = 0
    total_frames = int(decoder.fps * decoder.duration) if decoder.duration else 0

    try:
        while running:
            frame_data = decoder.next_frame()
            if frame_data is None:
                break

            now = time.monotonic()
            target = t0 + frame_idx * spf
            if now - target > spf * 2:
                frame_idx += 1
                continue

            rendered = termflux.render_frame(
                frame_data, decoder.width, decoder.height,
                term_width=rw, term_height=rh,
                offset_x=ox, offset_y=oy,
                border_style=termflux.BORDER_NONE,
                render_mode=termflux.RENDER_QUARTER,
                brightness=1.05,
                saturation=1.15,
            )

            elapsed = time.monotonic() - t0
            minutes = int(elapsed) // 60
            seconds = int(elapsed) % 60
            total_sec = decoder.duration
            t_min = int(total_sec) // 60
            t_sec = int(total_sec) % 60

            header = draw_header(
                tw,
                "4K Nature Cinematic",
                "Pinterest HD Collection | Lanczos3 Engine | 60fps",
                "{}:{:02d} / {}:{:02d}".format(minutes, seconds, t_min, t_sec),
                "{}x{} @ {}fps".format(decoder.width, decoder.height, int(decoder.fps)),
                frame_idx,
                total_frames,
            )

            sys.stdout.write(header)
            termflux.flush_frame(rendered)

            frame_idx += 1
            target = t0 + frame_idx * spf
            now = time.monotonic()
            if target > now:
                termflux.sleep_precise(target - now)

    except KeyboardInterrupt:
        pass
    finally:
        if audio_proc:
            audio_proc.kill()
        termflux.show_cursor()
        termflux.reset()
        signal.signal(signal.SIGINT, prev_handler)

    sys.stderr.write("Played {} frames in {:.2f}s\n".format(
        frame_idx, time.monotonic() - t0))


if __name__ == "__main__":
    main()
