"""
termflux - play audio in terminal
Author: MERO:TG@QP4RM

Usage:
    python play_audio.py <audio_path_or_url>
    python play_audio.py song.mp3
"""
import sys
import time
import termflux

if len(sys.argv) < 2:
    print("Usage: python play_audio.py <audio_path_or_url>")
    sys.exit(1)

source = sys.argv[1]
audio = termflux.Audio(source)
print("Playing: {}".format(source))
print("Press Ctrl+C to stop")

try:
    audio.play_background()
    while True:
        time.sleep(0.5)
except KeyboardInterrupt:
    audio.stop()
    print("\nStopped.")
