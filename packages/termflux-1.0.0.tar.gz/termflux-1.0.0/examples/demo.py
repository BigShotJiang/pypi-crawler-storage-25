import sys
import termflux


def demo_image():
    if len(sys.argv) < 3:
        print("usage: python demo.py image <path_or_url>")
        return
    img = termflux.Image(sys.argv[2])
    img.show(
        border_style=termflux.BORDER_ROUND,
        border_r=0, border_g=200, border_b=255,
        position="center",
    )
    input()
    termflux._engine.reset()


def demo_video():
    if len(sys.argv) < 3:
        print("usage: python demo.py video <path_or_url>")
        return
    vid = termflux.Video(sys.argv[2])
    vid.play(
        border_style=termflux.BORDER_DOUBLE,
        border_r=255, border_g=255, border_b=0,
        position="center",
    )


def demo_audio():
    if len(sys.argv) < 3:
        print("usage: python demo.py audio <path_or_url>")
        return
    aud = termflux.Audio(sys.argv[2])
    aud.play()


def demo_player():
    if len(sys.argv) < 3:
        print("usage: python demo.py play <path_or_url>")
        return
    p = termflux.Player(sys.argv[2])
    p.border(termflux.BORDER_ROUND, 100, 255, 100)
    p.position("center")
    p.show()


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("usage: python demo.py <image|video|audio|play> <source>")
        sys.exit(1)

    cmd = sys.argv[1]
    handlers = {
        "image": demo_image,
        "video": demo_video,
        "audio": demo_audio,
        "play": demo_player,
    }

    handler = handlers.get(cmd)
    if handler:
        handler()
    else:
        print("unknown command: {}".format(cmd))
        sys.exit(1)
