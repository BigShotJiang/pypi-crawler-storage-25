"""
termflux - show image in terminal
Author: MERO:TG@QP4RM

Usage:
    python show_image.py <image_path_or_url>
    python show_image.py photo.jpg
    python show_image.py https://example.com/image.png
"""
import sys
import termflux

if len(sys.argv) < 2:
    print("Usage: python show_image.py <image_path_or_url>")
    sys.exit(1)

source = sys.argv[1]
img = termflux.Image(source)
img.show(
    border_style=termflux.BORDER_ROUND,
    border_r=255, border_g=215, border_b=0,
    position="center",
    render_mode=termflux.RENDER_QUARTER,
)

try:
    input()
except (EOFError, KeyboardInterrupt):
    pass
finally:
    termflux.reset()
