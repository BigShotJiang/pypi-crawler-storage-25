"""
termflux - play video in terminal with HD rendering
Author: MERO:TG@QP4RM

Usage:
    python play_video.py <video_path_or_url>
    python play_video.py movie.mp4
    python play_video.py https://example.com/video.mp4
"""
import sys
import termflux

if len(sys.argv) < 2:
    print("Usage: python play_video.py <video_path_or_url>")
    sys.exit(1)

source = sys.argv[1]
vid = termflux.Video(source)
print("Video: {}x{} @ {} fps".format(vid.width, vid.height, vid.fps))

try:
    vid.play(
        border_style=termflux.BORDER_BOLD,
        border_r=255, border_g=100, border_b=200,
        position="center",
        render_mode=termflux.RENDER_QUARTER,
        with_audio=True,
    )
except KeyboardInterrupt:
    pass
finally:
    termflux.reset()
