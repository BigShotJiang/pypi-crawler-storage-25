"""
termflux - Player API usage example
Author: MERO:TG@QP4RM

The Player class provides a chainable API for media playback.
Usage:
    python player_api.py <media_path_or_url>
"""
import sys
import termflux

if len(sys.argv) < 2:
    print("Usage: python player_api.py <media_path_or_url>")
    sys.exit(1)

source = sys.argv[1]

try:
    p = termflux.Player(source)
    p.border(termflux.BORDER_ROUND, 255, 215, 0)
    p.border_thickness(1)
    p.set_padding(0)
    p.position("center")
    p.render_mode(termflux.RENDER_QUARTER)
    p.set_brightness(1.05)
    p.set_saturation(1.2)
    p.show()

    if p._type == "image":
        try:
            input()
        except EOFError:
            pass
except KeyboardInterrupt:
    pass
finally:
    termflux.reset()
