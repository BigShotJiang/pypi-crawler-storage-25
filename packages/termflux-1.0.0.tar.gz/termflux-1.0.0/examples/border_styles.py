"""
termflux - border style showcase
Author: MERO:TG@QP4RM

Shows the same image with different border styles, colors, and thickness.
Usage:
    python border_styles.py <image_path>
"""
import sys
import time
import termflux

if len(sys.argv) < 2:
    print("Usage: python border_styles.py <image_path>")
    sys.exit(1)

source = sys.argv[1]
img = termflux.Image(source)

borders = [
    {"name": "No Border", "style": termflux.BORDER_NONE, "r": 255, "g": 255, "b": 255, "thick": 1},
    {"name": "Single White", "style": termflux.BORDER_SINGLE, "r": 255, "g": 255, "b": 255, "thick": 1},
    {"name": "Double Gold", "style": termflux.BORDER_DOUBLE, "r": 255, "g": 215, "b": 0, "thick": 1},
    {"name": "Bold Cyan", "style": termflux.BORDER_BOLD, "r": 0, "g": 255, "b": 255, "thick": 1},
    {"name": "Round Green", "style": termflux.BORDER_ROUND, "r": 0, "g": 255, "b": 128, "thick": 1},
    {"name": "Double Red Thick", "style": termflux.BORDER_DOUBLE, "r": 255, "g": 50, "b": 50, "thick": 2},
    {"name": "Round Pink + Padding", "style": termflux.BORDER_ROUND, "r": 255, "g": 100, "b": 200, "thick": 1},
]

try:
    for b in borders:
        termflux.clear_screen()
        termflux.hide_cursor()
        sys.stderr.write("\033[1;1H\033[37m{}\033[0m".format(b["name"]))
        padding = 1 if "Padding" in b["name"] else 0
        img.show(
            border_style=b["style"],
            border_r=b["r"], border_g=b["g"], border_b=b["b"],
            position="center",
            render_mode=termflux.RENDER_QUARTER,
            border_thick=b["thick"],
            padding=padding,
        )
        time.sleep(2.0)
except KeyboardInterrupt:
    pass
finally:
    termflux.reset()
