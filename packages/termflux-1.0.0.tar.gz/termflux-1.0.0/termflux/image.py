import sys

import termflux

try:
    from termflux._decoder import decode_image
    _HAS_DECODER = True
except ImportError:
    _HAS_DECODER = False

from termflux.loader import fetch


def _decode_fallback(path):
    import subprocess
    proc = subprocess.run(
        ["ffprobe", "-v", "quiet", "-select_streams", "v:0",
         "-show_entries", "stream=width,height",
         "-of", "csv=p=0", path],
        capture_output=True, text=True,
    )
    if proc.returncode != 0:
        raise RuntimeError("ffprobe failed: " + proc.stderr)
    parts = proc.stdout.strip().split(",")
    w, h = int(parts[0]), int(parts[1])
    proc = subprocess.run(
        ["ffmpeg", "-i", path, "-vframes", "1",
         "-f", "rawvideo", "-pix_fmt", "rgb24", "-"],
        capture_output=True,
    )
    if proc.returncode != 0:
        raise RuntimeError("ffmpeg decode failed")
    return proc.stdout, w, h


class Image:

    def __init__(self, source):
        local = fetch(source)
        if _HAS_DECODER:
            rgb_data, self._width, self._height = decode_image(local)
        else:
            rgb_data, self._width, self._height = _decode_fallback(local)
        self._pixels = rgb_data

    @property
    def width(self):
        return self._width

    @property
    def height(self):
        return self._height

    @property
    def pixels(self):
        return self._pixels

    def show(self, border_style=termflux.BORDER_NONE,
             border_r=255, border_g=255, border_b=255,
             position="center", width=None, height=None,
             render_mode=termflux.RENDER_QUARTER,
             border_thick=1, padding=0,
             brightness=1.0, contrast=1.0, saturation=1.0,
             grayscale=False, invert=False,
             aspect="fit"):
        tw, th = termflux.get_terminal_size()

        rw, rh = _compute_display_size(
            self._width, self._height, tw, th,
            width, height, aspect, border_style, border_thick, padding)

        ox, oy = _compute_offset(position, rw, rh, tw, th)

        termflux.clear_screen()
        termflux.hide_cursor()

        frame = termflux.render_frame(
            self._pixels, self._width, self._height,
            term_width=rw, term_height=rh,
            offset_x=ox, offset_y=oy,
            border_style=border_style,
            border_r=border_r, border_g=border_g, border_b=border_b,
            render_mode=render_mode,
            border_thick=border_thick, padding=padding,
            brightness=brightness, contrast=contrast,
            saturation=saturation,
            grayscale=int(grayscale), invert=int(invert),
        )
        termflux.flush_frame(frame)

    def to_rgb(self, width=None, height=None):
        if width is None and height is None:
            return self._pixels
        w = width or self._width
        h = height or self._height
        return termflux.scale(self._pixels, self._width, self._height, w, h)


def _compute_display_size(src_w, src_h, tw, th, user_w, user_h,
                          aspect, border_style, border_thick, padding):
    border_cells = 0
    if border_style != termflux.BORDER_NONE:
        border_cells = border_thick * 2
    pad_cells = padding * 2

    avail_w = tw
    avail_h = th

    if user_w and user_h:
        return user_w, user_h
    elif user_w:
        return user_w, int(src_h * (user_w / src_w))
    elif user_h:
        return int(src_w * (user_h / src_h)), user_h

    if aspect == "stretch":
        return avail_w, avail_h

    inner_w = avail_w - border_cells - pad_cells
    inner_h = avail_h - border_cells - pad_cells
    if inner_w <= 0 or inner_h <= 0:
        return avail_w, avail_h

    visual_w = inner_w
    visual_h = inner_h * 2

    src_aspect = src_w / src_h
    dst_aspect = visual_w / visual_h

    if aspect == "fill":
        if src_aspect > dst_aspect:
            rh = avail_h
            rw = int(inner_h * 2 * src_aspect) + border_cells + pad_cells
        else:
            rw = avail_w
            rh = int(inner_w / src_aspect / 2) + border_cells + pad_cells
        return max(rw, 1), max(rh, 1)
    else:
        if src_aspect > dst_aspect:
            rw = avail_w
            content_h = int(inner_w / src_aspect / 2)
            rh = content_h + border_cells + pad_cells
        else:
            rh = avail_h
            content_w = int(inner_h * 2 * src_aspect)
            rw = content_w + border_cells + pad_cells
        return max(rw, 1), max(rh, 1)


def _compute_offset(position, rw, rh, tw, th):
    if position == "center":
        ox = max(0, (tw - rw) // 2)
        oy = max(0, (th - rh) // 2)
    elif position == "top":
        ox = max(0, (tw - rw) // 2)
        oy = 0
    elif position == "bottom":
        ox = max(0, (tw - rw) // 2)
        oy = max(0, th - rh)
    elif position == "left":
        ox = 0
        oy = max(0, (th - rh) // 2)
    elif position == "right":
        ox = max(0, tw - rw)
        oy = max(0, (th - rh) // 2)
    elif position == "top-left":
        ox, oy = 0, 0
    elif position == "top-right":
        ox = max(0, tw - rw)
        oy = 0
    elif position == "bottom-left":
        ox = 0
        oy = max(0, th - rh)
    elif position == "bottom-right":
        ox = max(0, tw - rw)
        oy = max(0, th - rh)
    else:
        ox, oy = 0, 0

    return ox, oy
