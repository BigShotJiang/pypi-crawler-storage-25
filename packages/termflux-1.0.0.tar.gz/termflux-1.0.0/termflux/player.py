import os
import sys

import termflux
from termflux.image import Image
from termflux.video import Video
from termflux.audio import Audio
from termflux.loader import is_url


_IMAGE_EXT = {".png", ".jpg", ".jpeg", ".bmp", ".gif", ".tiff", ".webp", ".ico"}
_VIDEO_EXT = {".mp4", ".avi", ".mkv", ".mov", ".webm", ".flv", ".wmv", ".m4v"}
_AUDIO_EXT = {".mp3", ".wav", ".ogg", ".flac", ".aac", ".m4a", ".wma", ".opus"}


def _detect_type(source):
    path = source.split("?")[0]
    ext = os.path.splitext(path)[-1].lower()
    if ext in _IMAGE_EXT:
        return "image"
    if ext in _VIDEO_EXT:
        return "video"
    if ext in _AUDIO_EXT:
        return "audio"
    return "video"


class Player:

    def __init__(self, source=None, media_type=None):
        self._source = source
        self._type = media_type or (_detect_type(source) if source else None)
        self._obj = None
        self._border_style = termflux.BORDER_NONE
        self._border_color = (255, 255, 255)
        self._border_thick = 1
        self._padding = 0
        self._position_val = "center"
        self._width = None
        self._height = None
        self._loop_val = False
        self._render_mode_val = termflux.RENDER_QUARTER
        self._aspect = "fit"
        self._brightness = 1.0
        self._contrast = 1.0
        self._saturation = 1.0
        self._grayscale = False
        self._invert = False

    def load(self, source, media_type=None):
        self._source = source
        self._type = media_type or _detect_type(source)
        self._obj = None
        return self

    def border(self, style, r=255, g=255, b=255):
        self._border_style = style
        self._border_color = (r, g, b)
        return self

    def border_thickness(self, thick):
        self._border_thick = thick
        return self

    def set_padding(self, padding):
        self._padding = padding
        return self

    def position(self, pos):
        self._position_val = pos
        return self

    def size(self, width=None, height=None):
        self._width = width
        self._height = height
        return self

    def loop(self, enabled=True):
        self._loop_val = enabled
        return self

    def render_mode(self, mode):
        self._render_mode_val = mode
        return self

    def set_aspect(self, aspect):
        self._aspect = aspect
        return self

    def set_brightness(self, v):
        self._brightness = v
        return self

    def set_contrast(self, v):
        self._contrast = v
        return self

    def set_saturation(self, v):
        self._saturation = v
        return self

    def set_grayscale(self, v):
        self._grayscale = v
        return self

    def set_invert(self, v):
        self._invert = v
        return self

    def show(self):
        if not self._source:
            raise ValueError("no media loaded")

        if sys.platform == "win32":
            termflux.enable_ansi()

        if self._type == "image":
            img = Image(self._source)
            img.show(
                border_style=self._border_style,
                border_r=self._border_color[0],
                border_g=self._border_color[1],
                border_b=self._border_color[2],
                position=self._position_val,
                width=self._width,
                height=self._height,
                render_mode=self._render_mode_val,
                border_thick=self._border_thick,
                padding=self._padding,
                brightness=self._brightness,
                contrast=self._contrast,
                saturation=self._saturation,
                grayscale=self._grayscale,
                invert=self._invert,
                aspect=self._aspect,
            )

        elif self._type == "video":
            vid = Video(self._source)
            vid.play(
                border_style=self._border_style,
                border_r=self._border_color[0],
                border_g=self._border_color[1],
                border_b=self._border_color[2],
                position=self._position_val,
                width=self._width,
                height=self._height,
                loop=self._loop_val,
                render_mode=self._render_mode_val,
                border_thick=self._border_thick,
                padding=self._padding,
                brightness=self._brightness,
                contrast=self._contrast,
                saturation=self._saturation,
                grayscale=self._grayscale,
                invert=self._invert,
                aspect=self._aspect,
            )

        elif self._type == "audio":
            aud = Audio(self._source)
            aud.play(show_ui=True)

        else:
            raise ValueError("unsupported media type: " + str(self._type))

        return self

    def play(self):
        return self.show()
