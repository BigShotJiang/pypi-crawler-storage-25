import os
import tempfile
import urllib.request
import urllib.error
import hashlib


_cache_dir = os.path.join(tempfile.gettempdir(), "termflux_cache")


def _ensure_cache():
    os.makedirs(_cache_dir, exist_ok=True)


def is_url(path):
    return path.startswith("http://") or path.startswith("https://")


def fetch(source):
    if not is_url(source):
        if not os.path.isfile(source):
            raise FileNotFoundError(source)
        return source

    _ensure_cache()
    key = hashlib.sha256(source.encode()).hexdigest()[:16]
    ext = os.path.splitext(source.split("?")[0])[-1] or ".bin"
    cached = os.path.join(_cache_dir, key + ext)

    if os.path.isfile(cached):
        return cached

    req = urllib.request.Request(
        source,
        headers={"User-Agent": "termflux/1.0"},
    )
    with urllib.request.urlopen(req, timeout=30) as resp:
        data = resp.read()

    with open(cached, "wb") as f:
        f.write(data)

    return cached


def fetch_to_memory(source):
    if not is_url(source):
        with open(source, "rb") as f:
            return f.read()

    req = urllib.request.Request(
        source,
        headers={"User-Agent": "termflux/1.0"},
    )
    with urllib.request.urlopen(req, timeout=30) as resp:
        return resp.read()


def clear_cache():
    if os.path.isdir(_cache_dir):
        for f in os.listdir(_cache_dir):
            try:
                os.remove(os.path.join(_cache_dir, f))
            except OSError:
                pass
