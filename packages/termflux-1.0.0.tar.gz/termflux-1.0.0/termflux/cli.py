import argparse
import sys

import termflux
from termflux.player import Player


BORDER_MAP = {
    "none": termflux.BORDER_NONE,
    "single": termflux.BORDER_SINGLE,
    "double": termflux.BORDER_DOUBLE,
    "bold": termflux.BORDER_BOLD,
    "round": termflux.BORDER_ROUND,
}

RENDER_MAP = {
    "quarter": termflux.RENDER_QUARTER,
    "half": termflux.RENDER_HALF,
    "sixel": termflux.RENDER_SIXEL,
}


def main():
    parser = argparse.ArgumentParser(
        prog="termflux",
        description="termflux v{} - terminal media engine".format(termflux.__version__),
    )
    parser.add_argument("source", help="file path or URL to media")
    parser.add_argument(
        "-t", "--type",
        choices=["image", "video", "audio"],
        default=None,
        help="force media type",
    )
    parser.add_argument(
        "-W", "--width",
        type=int, default=None,
        help="render width in columns",
    )
    parser.add_argument(
        "-H", "--height",
        type=int, default=None,
        help="render height in rows",
    )
    parser.add_argument(
        "-p", "--position",
        default="center",
        choices=[
            "center", "top", "bottom", "left", "right",
            "top-left", "top-right", "bottom-left", "bottom-right",
        ],
        help="position on screen",
    )
    parser.add_argument(
        "-b", "--border",
        default="none",
        choices=list(BORDER_MAP.keys()),
        help="border style",
    )
    parser.add_argument(
        "--border-color",
        default="255,255,255",
        help="border RGB color (e.g. 255,0,0)",
    )
    parser.add_argument(
        "--border-thick",
        type=int, default=1,
        help="border thickness (1-5)",
    )
    parser.add_argument(
        "--padding",
        type=int, default=0,
        help="padding inside border (cells)",
    )
    parser.add_argument(
        "-r", "--render",
        default="quarter",
        choices=list(RENDER_MAP.keys()),
        help="render mode: sixel (4K pixel), quarter (HD), half (classic)",
    )
    parser.add_argument(
        "--aspect",
        default="fit",
        choices=["fit", "fill", "stretch"],
        help="aspect ratio mode",
    )
    parser.add_argument(
        "--brightness",
        type=float, default=1.0,
        help="brightness (0.0-3.0, default 1.0)",
    )
    parser.add_argument(
        "--contrast",
        type=float, default=1.0,
        help="contrast (0.0-3.0, default 1.0)",
    )
    parser.add_argument(
        "--saturation",
        type=float, default=1.0,
        help="saturation (0.0-3.0, default 1.0)",
    )
    parser.add_argument(
        "--grayscale",
        action="store_true",
        help="convert to grayscale",
    )
    parser.add_argument(
        "--invert",
        action="store_true",
        help="invert colors",
    )
    parser.add_argument(
        "-l", "--loop",
        action="store_true",
        help="loop video playback",
    )
    parser.add_argument(
        "-v", "--version",
        action="version",
        version="termflux {}".format(termflux.__version__),
    )

    args = parser.parse_args()

    br, bg, bb = 255, 255, 255
    if args.border_color:
        parts = args.border_color.split(",")
        if len(parts) == 3:
            br, bg, bb = int(parts[0]), int(parts[1]), int(parts[2])

    if sys.platform == "win32":
        termflux.enable_ansi()

    try:
        p = Player(args.source, media_type=args.type)
        p.border(BORDER_MAP[args.border], br, bg, bb)
        p.border_thickness(args.border_thick)
        p.set_padding(args.padding)
        p.position(args.position)
        p.size(args.width, args.height)
        p.render_mode(RENDER_MAP[args.render])
        p.set_aspect(args.aspect)
        p.set_brightness(args.brightness)
        p.set_contrast(args.contrast)
        p.set_saturation(args.saturation)
        p.set_grayscale(args.grayscale)
        p.set_invert(args.invert)
        p.loop(args.loop)
        p.show()
        if p._type == "image":
            try:
                input()
            except EOFError:
                pass
    except KeyboardInterrupt:
        pass
    except Exception as exc:
        sys.stderr.write("termflux: {}\n".format(exc))
        sys.exit(1)
    finally:
        termflux.reset()


if __name__ == "__main__":
    main()
