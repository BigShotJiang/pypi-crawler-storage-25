import os
import sys
import time

BORDER_NONE = 0
BORDER_SINGLE = 1
BORDER_DOUBLE = 2
BORDER_BOLD = 3
BORDER_ROUND = 4

RENDER_HALF = 0
RENDER_QUARTER = 1
RENDER_SIXEL = 2

_BORDER_CHARS = {
    0: ("", "", "", "", "", ""),
    1: ("\u250c", "\u2510", "\u2514", "\u2518", "\u2500", "\u2502"),
    2: ("\u2554", "\u2557", "\u255a", "\u255d", "\u2550", "\u2551"),
    3: ("\u250f", "\u2513", "\u2517", "\u251b", "\u2501", "\u2503"),
    4: ("\u256d", "\u256e", "\u2570", "\u256f", "\u2500", "\u2502"),
}

_QBLOCK = [
    " ",        # 0000
    "\u2597",   # 0001 BR
    "\u2596",   # 0010 BL
    "\u2584",   # 0011 lower half
    "\u259d",   # 0100 TR
    "\u2590",   # 0101 right half
    "\u259e",   # 0110 BL+TR
    "\u259f",   # 0111 BL+TR+BR
    "\u2598",   # 1000 TL
    "\u259a",   # 1001 TL+BR
    "\u258c",   # 1010 left half
    "\u2599",   # 1011 TL+BL+BR
    "\u2580",   # 1100 upper half
    "\u259c",   # 1101 TL+TR+BR
    "\u259b",   # 1110 TL+TR+BL
    "\u2588",   # 1111 full block
]


def _clamp(v, lo, hi):
    if v < lo:
        return lo
    if v > hi:
        return hi
    return v


def get_terminal_size():
    try:
        sz = os.get_terminal_size()
        return (sz.columns, sz.lines)
    except OSError:
        return (80, 24)


def scale(pixels, sw, sh, dw, dh):
    src = pixels
    dst = bytearray(dw * dh * 3)
    sx = sw / dw
    sy = sh / dh

    for y in range(dh):
        for x in range(dw):
            fx = (x + 0.5) * sx - 0.5
            fy = (y + 0.5) * sy - 0.5
            x0 = _clamp(int(fx), 0, sw - 1)
            y0 = _clamp(int(fy), 0, sh - 1)
            x1 = _clamp(x0 + 1, 0, sw - 1)
            y1 = _clamp(y0 + 1, 0, sh - 1)
            dx = max(fx - x0, 0.0)
            dy = max(fy - y0, 0.0)

            i00 = (y0 * sw + x0) * 3
            i10 = (y0 * sw + x1) * 3
            i01 = (y1 * sw + x0) * 3
            i11 = (y1 * sw + x1) * 3

            di = (y * dw + x) * 3
            for c in range(3):
                v = (src[i00+c]*(1-dx)*(1-dy) + src[i10+c]*dx*(1-dy) +
                     src[i01+c]*(1-dx)*dy + src[i11+c]*dx*dy)
                dst[di+c] = _clamp(int(v), 0, 255)

    return bytes(dst)


def _apply_filters(pixels, width, height, brightness=1.0, contrast=1.0,
                   saturation=1.0, grayscale=0, invert=0):
    if (brightness == 1.0 and contrast == 1.0 and saturation == 1.0
            and not grayscale and not invert):
        return pixels

    data = bytearray(pixels)
    total = width * height
    for i in range(total):
        idx = i * 3
        r, g, b = float(data[idx]), float(data[idx+1]), float(data[idx+2])

        if saturation != 1.0:
            gray = 0.299 * r + 0.587 * g + 0.114 * b
            r = gray + saturation * (r - gray)
            g = gray + saturation * (g - gray)
            b = gray + saturation * (b - gray)

        if grayscale:
            gray = 0.299 * r + 0.587 * g + 0.114 * b
            r = g = b = gray

        if brightness != 1.0:
            r *= brightness
            g *= brightness
            b *= brightness

        if contrast != 1.0:
            r = 128.0 + contrast * (r - 128.0)
            g = 128.0 + contrast * (g - 128.0)
            b = 128.0 + contrast * (b - 128.0)

        if invert:
            r, g, b = 255.0 - r, 255.0 - g, 255.0 - b

        data[idx] = _clamp(int(r), 0, 255)
        data[idx+1] = _clamp(int(g), 0, 255)
        data[idx+2] = _clamp(int(b), 0, 255)

    return bytes(data)


def _color_dist_sq(r1, g1, b1, r2, g2, b2):
    dr = r1 - r2
    dg = g1 - g2
    db = b1 - b2
    rmean = (r1 + r2) // 2
    return ((512 + rmean) * dr * dr >> 8) + 4 * dg * dg + \
           ((767 - rmean) * db * db >> 8)


def render_frame(pixels, width, height, term_width=-1, term_height=-1,
                 offset_x=0, offset_y=0, border_style=BORDER_NONE,
                 border_r=255, border_g=255, border_b=255,
                 render_mode=RENDER_QUARTER, border_thick=1, padding=0,
                 brightness=1.0, contrast=1.0, saturation=1.0,
                 grayscale=0, invert=0):
    if term_width < 0 or term_height < 0:
        tw, th = get_terminal_size()
        if term_width < 0:
            term_width = tw
        if term_height < 0:
            term_height = th

    pixels = _apply_filters(pixels, width, height, brightness, contrast,
                            saturation, grayscale, invert)

    if render_mode == RENDER_SIXEL:
        return _render_sixel(pixels, width, height, term_width, term_height)
    elif render_mode == RENDER_QUARTER:
        return _render_quarter(pixels, width, height, term_width, term_height,
                               offset_x, offset_y, border_style,
                               border_r, border_g, border_b, border_thick, padding)
    else:
        return _render_half(pixels, width, height, term_width, term_height,
                            offset_x, offset_y, border_style,
                            border_r, border_g, border_b, border_thick, padding)


def _render_border(parts, term_width, term_height, offset_x, offset_y,
                   border_style, border_r, border_g, border_b, border_thick):
    if border_style == BORDER_NONE or border_style not in _BORDER_CHARS:
        return

    bc = _BORDER_CHARS[border_style]
    cr, cg, cb = border_r, border_g, border_b

    for t in range(border_thick):
        row_top = offset_y + 1 + t
        row_bot = offset_y + term_height - t
        col_left = offset_x + 1 + t
        col_right = offset_x + term_width - t
        inner_w = term_width - 2 - t * 2

        parts.append("\033[{};{}H\033[38;2;{};{};{}m".format(
            row_top, col_left, cr, cg, cb))
        if t == 0:
            parts.append(bc[0] + bc[4] * inner_w + bc[1])
        else:
            parts.append(bc[5] + bc[4] * inner_w + bc[5])

        inner_h = term_height - 2 - t * 2
        for r in range(1, inner_h + 1):
            parts.append("\033[{};{}H{}".format(row_top + r, col_left, bc[5]))
            parts.append("\033[{};{}H{}".format(row_top + r, col_right, bc[5]))

        parts.append("\033[{};{}H".format(row_bot, col_left))
        if t == 0:
            parts.append(bc[2] + bc[4] * inner_w + bc[3])
        else:
            parts.append(bc[5] + bc[4] * inner_w + bc[5])


def _render_quarter(pixels, width, height, term_width, term_height,
                    offset_x, offset_y, border_style,
                    border_r, border_g, border_b, border_thick, padding):
    boff = 0
    rw = term_width
    rh = term_height

    if border_style != BORDER_NONE:
        rw -= border_thick * 2
        rh -= border_thick * 2
        boff = border_thick

    rw -= padding * 2
    rh -= padding * 2
    if rw <= 0 or rh <= 0:
        return b""

    pixel_w = rw * 2
    pixel_h = rh * 2

    if width != pixel_w or height != pixel_h:
        pixels = scale(pixels, width, height, pixel_w, pixel_h)
    src = pixels

    parts = ["\033[?25l"]
    _render_border(parts, term_width, term_height, offset_x, offset_y,
                   border_style, border_r, border_g, border_b, border_thick)

    base_row = offset_y + 1 + boff + padding
    base_col = offset_x + 1 + boff + padding

    for row in range(rh):
        parts.append("\033[{};{}H".format(base_row + row, base_col))
        sy = row * 2
        for col in range(rw):
            sx = col * 2
            i_tl = (sy * pixel_w + sx) * 3
            i_tr = (sy * pixel_w + sx + 1) * 3
            i_bl = ((sy + 1) * pixel_w + sx) * 3
            i_br = ((sy + 1) * pixel_w + sx + 1) * 3

            tl = (src[i_tl], src[i_tl+1], src[i_tl+2])
            tr = (src[i_tr], src[i_tr+1], src[i_tr+2])
            bl = (src[i_bl], src[i_bl+1], src[i_bl+2])
            br = (src[i_br], src[i_br+1], src[i_br+2])

            pxs = [tl, tr, bl, br]
            fg_c = tl
            bg_c = tl
            max_d = 0
            for i in range(4):
                for j in range(i + 1, 4):
                    d = _color_dist_sq(*pxs[i], *pxs[j])
                    if d > max_d:
                        max_d = d
                        fg_c = pxs[i]
                        bg_c = pxs[j]

            if max_d < 50:
                ar = (tl[0] + tr[0] + bl[0] + br[0] + 2) // 4
                ag = (tl[1] + tr[1] + bl[1] + br[1] + 2) // 4
                ab = (tl[2] + tr[2] + bl[2] + br[2] + 2) // 4
                parts.append("\033[48;2;{};{};{}m ".format(ar, ag, ab))
                continue

            pattern = 0
            for i in range(4):
                d_fg = _color_dist_sq(*pxs[i], *fg_c)
                d_bg = _color_dist_sq(*pxs[i], *bg_c)
                if d_fg <= d_bg:
                    pattern |= (8 >> i)

            fg_r = fg_g = fg_b = fg_n = 0
            bg_r = bg_g = bg_b = bg_n = 0
            for i in range(4):
                if pattern & (8 >> i):
                    fg_r += pxs[i][0]; fg_g += pxs[i][1]; fg_b += pxs[i][2]
                    fg_n += 1
                else:
                    bg_r += pxs[i][0]; bg_g += pxs[i][1]; bg_b += pxs[i][2]
                    bg_n += 1
            if fg_n > 0:
                fg_c = (fg_r // fg_n, fg_g // fg_n, fg_b // fg_n)
            if bg_n > 0:
                bg_c = (bg_r // bg_n, bg_g // bg_n, bg_b // bg_n)

            parts.append("\033[38;2;{};{};{}m\033[48;2;{};{};{}m{}".format(
                fg_c[0], fg_c[1], fg_c[2], bg_c[0], bg_c[1], bg_c[2],
                _QBLOCK[pattern]))

        parts.append("\033[0m")

    parts.append("\033[0m")
    return "".join(parts).encode("utf-8")


def _render_half(pixels, width, height, term_width, term_height,
                 offset_x, offset_y, border_style,
                 border_r, border_g, border_b, border_thick, padding):
    boff = 0
    rw = term_width
    rh = term_height * 2

    if border_style != BORDER_NONE:
        rw -= border_thick * 2
        rh -= border_thick * 4
        boff = border_thick

    rw -= padding * 2
    rh -= padding * 4
    if rw <= 0 or rh <= 0:
        return b""

    if width != rw or height != rh:
        pixels = scale(pixels, width, height, rw, rh)
    src = pixels

    parts = ["\033[?25l"]
    _render_border(parts, term_width, term_height, offset_x, offset_y,
                   border_style, border_r, border_g, border_b, border_thick)

    base_row = offset_y + 1 + boff + padding
    base_col = offset_x + 1 + boff + padding

    for row in range(0, rh, 2):
        parts.append("\033[{};{}H".format(base_row + row // 2, base_col))
        for col in range(rw):
            ti = (row * rw + col) * 3
            t_r, t_g, t_b = src[ti], src[ti+1], src[ti+2]
            if row + 1 < rh:
                bi = ((row+1) * rw + col) * 3
                b_r, b_g, b_b = src[bi], src[bi+1], src[bi+2]
            else:
                b_r = b_g = b_b = 0
            parts.append("\033[38;2;{};{};{}m\033[48;2;{};{};{}m\u2580".format(
                t_r, t_g, t_b, b_r, b_g, b_b))
        parts.append("\033[0m")

    parts.append("\033[0m")
    return "".join(parts).encode("utf-8")


def _render_sixel(pixels, width, height, term_width, term_height):
    sixel_w = term_width * 8
    sixel_h = term_height * 16
    if sixel_w > 1920:
        sixel_w = 1920
    if sixel_h > 1080:
        sixel_h = 1080

    src_asp = width / height
    dst_asp = sixel_w / sixel_h
    if src_asp > dst_asp:
        final_w = sixel_w
        final_h = max(1, int(sixel_w / src_asp))
    else:
        final_h = sixel_h
        final_w = max(1, int(sixel_h * src_asp))

    if width != final_w or height != final_h:
        pixels = scale(pixels, width, height, final_w, final_h)
    src = pixels

    hist = {}
    total = final_w * final_h
    for i in range(total):
        r = src[i * 3] >> 3
        g = src[i * 3 + 1] >> 3
        b = src[i * 3 + 2] >> 3
        key = (r, g, b)
        if key not in hist:
            hist[key] = [0, 0, 0, 0]
        hist[key][0] += 1
        hist[key][1] += src[i * 3]
        hist[key][2] += src[i * 3 + 1]
        hist[key][3] += src[i * 3 + 2]

    sorted_buckets = sorted(hist.items(), key=lambda x: -x[1][0])
    ncolors = min(256, len(sorted_buckets))
    palette = []
    for i in range(ncolors):
        _, vals = sorted_buckets[i]
        c = vals[0]
        palette.append((vals[1] // c, vals[2] // c, vals[3] // c))

    indexed = bytearray(total)
    for i in range(total):
        best = 0
        best_dist = 0x7FFFFFFF
        pr, pg, pb = src[i * 3], src[i * 3 + 1], src[i * 3 + 2]
        for ci in range(ncolors):
            cr, cg, cb = palette[ci]
            d = _color_dist_sq(pr, pg, pb, cr, cg, cb)
            if d < best_dist:
                best_dist = d
                best = ci
        indexed[i] = best

    parts = ["\033[?25l\033[H"]
    parts.append("\033Pq\"1;1;{};{}".format(final_w, final_h))

    for i in range(ncolors):
        sr = palette[i][0] * 100 // 255
        sg = palette[i][1] * 100 // 255
        sb = palette[i][2] * 100 // 255
        parts.append("#{};2;{};{};{}".format(i, sr, sg, sb))

    for band in range(0, final_h, 6):
        band_h = min(6, final_h - band)
        for ci in range(ncolors):
            has_px = False
            for y in range(band, band + band_h):
                for x in range(final_w):
                    if indexed[y * final_w + x] == ci:
                        has_px = True
                        break
                if has_px:
                    break
            if not has_px:
                continue

            parts.append("#{}".format(ci))
            run_start = 0
            run_val = -1
            for x in range(final_w + 1):
                sv = 0
                if x < final_w:
                    for dy in range(band_h):
                        if indexed[(band + dy) * final_w + x] == ci:
                            sv |= (1 << dy)

                if x < final_w and sv == run_val:
                    continue

                if run_val >= 0:
                    run_len = x - run_start
                    ch = chr(run_val + 63)
                    if run_len >= 4:
                        parts.append("!{}{}".format(run_len, ch))
                    else:
                        parts.append(ch * run_len)

                run_start = x
                run_val = sv
            parts.append("$")
        parts.append("-")

    parts.append("\033\\")
    return "".join(parts).encode("utf-8")


def hide_cursor():
    sys.stdout.write("\033[?25l")
    sys.stdout.flush()


def show_cursor():
    sys.stdout.write("\033[?25h")
    sys.stdout.flush()


def clear_screen():
    sys.stdout.write("\033[2J\033[H")
    sys.stdout.flush()


def reset():
    sys.stdout.write("\033[0m\033[?25h\033[2J\033[H")
    sys.stdout.flush()


def flush_frame(data):
    if isinstance(data, bytes):
        sys.stdout.buffer.write(data)
    else:
        sys.stdout.write(data)
    sys.stdout.flush()


def sleep_precise(seconds):
    if seconds > 0:
        time.sleep(seconds)


def enable_ansi():
    if sys.platform == "win32":
        try:
            import ctypes
            kernel32 = ctypes.windll.kernel32
            handle = kernel32.GetStdHandle(-11)
            mode = ctypes.c_ulong()
            kernel32.GetConsoleMode(handle, ctypes.byref(mode))
            kernel32.SetConsoleMode(handle, mode.value | 0x0004)
        except Exception:
            pass
