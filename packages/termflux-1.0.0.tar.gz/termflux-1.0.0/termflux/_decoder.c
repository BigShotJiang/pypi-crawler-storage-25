#define PY_SSIZE_T_CLEAN
#include <Python.h>
#include <libavformat/avformat.h>
#include <libavcodec/avcodec.h>
#include <libavutil/imgutils.h>
#include <libavutil/opt.h>
#include <libswscale/swscale.h>

typedef struct {
    PyObject_HEAD
    AVFormatContext *fmt_ctx;
    AVCodecContext *codec_ctx;
    int video_stream_idx;
    struct SwsContext *sws_ctx;
    AVFrame *frame;
    AVFrame *rgb_frame;
    AVPacket *pkt;
    int width;
    int height;
    double fps;
    double duration;
    int frame_count;
    uint8_t *rgb_buffer;
} DecoderObject;

static void Decoder_dealloc(DecoderObject *self) {
    if (self->rgb_buffer) av_free(self->rgb_buffer);
    if (self->rgb_frame) av_frame_free(&self->rgb_frame);
    if (self->frame) av_frame_free(&self->frame);
    if (self->pkt) av_packet_free(&self->pkt);
    if (self->sws_ctx) sws_freeContext(self->sws_ctx);
    if (self->codec_ctx) avcodec_free_context(&self->codec_ctx);
    if (self->fmt_ctx) avformat_close_input(&self->fmt_ctx);
    Py_TYPE(self)->tp_free((PyObject *)self);
}

static int Decoder_init(DecoderObject *self, PyObject *args, PyObject *kwargs) {
    const char *path;
    static char *kwlist[] = {"path", NULL};
    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "s", kwlist, &path))
        return -1;

    self->fmt_ctx = NULL;
    self->codec_ctx = NULL;
    self->video_stream_idx = -1;
    self->sws_ctx = NULL;
    self->frame = NULL;
    self->rgb_frame = NULL;
    self->pkt = NULL;
    self->rgb_buffer = NULL;

    int ret = avformat_open_input(&self->fmt_ctx, path, NULL, NULL);
    if (ret < 0) {
        char errbuf[256];
        av_strerror(ret, errbuf, sizeof(errbuf));
        PyErr_Format(PyExc_IOError, "cannot open media: %s", errbuf);
        return -1;
    }

    ret = avformat_find_stream_info(self->fmt_ctx, NULL);
    if (ret < 0) {
        PyErr_SetString(PyExc_IOError, "cannot find stream info");
        return -1;
    }

    for (unsigned int i = 0; i < self->fmt_ctx->nb_streams; i++) {
        if (self->fmt_ctx->streams[i]->codecpar->codec_type == AVMEDIA_TYPE_VIDEO) {
            self->video_stream_idx = (int)i;
            break;
        }
    }

    if (self->video_stream_idx < 0) {
        PyErr_SetString(PyExc_ValueError, "no video stream found");
        return -1;
    }

    AVStream *vstream = self->fmt_ctx->streams[self->video_stream_idx];
    AVCodecParameters *par = vstream->codecpar;

    const AVCodec *codec = avcodec_find_decoder(par->codec_id);
    if (!codec) {
        PyErr_SetString(PyExc_RuntimeError, "unsupported codec");
        return -1;
    }

    self->codec_ctx = avcodec_alloc_context3(codec);
    if (!self->codec_ctx) {
        PyErr_NoMemory();
        return -1;
    }

    avcodec_parameters_to_context(self->codec_ctx, par);

    ret = avcodec_open2(self->codec_ctx, codec, NULL);
    if (ret < 0) {
        PyErr_SetString(PyExc_RuntimeError, "cannot open codec");
        return -1;
    }

    self->width = self->codec_ctx->width;
    self->height = self->codec_ctx->height;

    if (vstream->avg_frame_rate.den > 0)
        self->fps = av_q2d(vstream->avg_frame_rate);
    else if (vstream->r_frame_rate.den > 0)
        self->fps = av_q2d(vstream->r_frame_rate);
    else
        self->fps = 30.0;

    if (self->fmt_ctx->duration > 0)
        self->duration = (double)self->fmt_ctx->duration / AV_TIME_BASE;
    else
        self->duration = 0.0;

    self->frame_count = (int)(vstream->nb_frames);

    self->sws_ctx = sws_getContext(
        self->width, self->height, self->codec_ctx->pix_fmt,
        self->width, self->height, AV_PIX_FMT_RGB24,
        SWS_BILINEAR, NULL, NULL, NULL
    );
    if (!self->sws_ctx) {
        PyErr_SetString(PyExc_RuntimeError, "cannot init scaler");
        return -1;
    }

    self->frame = av_frame_alloc();
    self->rgb_frame = av_frame_alloc();
    self->pkt = av_packet_alloc();
    if (!self->frame || !self->rgb_frame || !self->pkt) {
        PyErr_NoMemory();
        return -1;
    }

    int buf_size = av_image_get_buffer_size(AV_PIX_FMT_RGB24,
                                             self->width, self->height, 1);
    self->rgb_buffer = (uint8_t *)av_malloc(buf_size);
    if (!self->rgb_buffer) {
        PyErr_NoMemory();
        return -1;
    }

    av_image_fill_arrays(self->rgb_frame->data, self->rgb_frame->linesize,
                         self->rgb_buffer, AV_PIX_FMT_RGB24,
                         self->width, self->height, 1);

    return 0;
}

static PyObject *Decoder_next_frame(DecoderObject *self, PyObject *args) {
    while (1) {
        int ret;
        Py_BEGIN_ALLOW_THREADS
        ret = av_read_frame(self->fmt_ctx, self->pkt);
        Py_END_ALLOW_THREADS

        if (ret < 0) Py_RETURN_NONE;

        if (self->pkt->stream_index != self->video_stream_idx) {
            av_packet_unref(self->pkt);
            continue;
        }

        ret = avcodec_send_packet(self->codec_ctx, self->pkt);
        av_packet_unref(self->pkt);
        if (ret < 0) continue;

        ret = avcodec_receive_frame(self->codec_ctx, self->frame);
        if (ret < 0) continue;

        Py_BEGIN_ALLOW_THREADS
        sws_scale(self->sws_ctx,
                  (const uint8_t * const *)self->frame->data,
                  self->frame->linesize, 0, self->height,
                  self->rgb_frame->data, self->rgb_frame->linesize);
        Py_END_ALLOW_THREADS

        int data_size = self->width * self->height * 3;
        if (self->rgb_frame->linesize[0] == self->width * 3) {
            return PyBytes_FromStringAndSize(
                (const char *)self->rgb_frame->data[0], data_size);
        }

        PyObject *result = PyBytes_FromStringAndSize(NULL, data_size);
        if (!result) return NULL;
        char *dst = PyBytes_AS_STRING(result);
        for (int y = 0; y < self->height; y++) {
            memcpy(dst + y * self->width * 3,
                   self->rgb_frame->data[0] + y * self->rgb_frame->linesize[0],
                   self->width * 3);
        }
        return result;
    }
}

static PyObject *Decoder_seek(DecoderObject *self, PyObject *args) {
    double timestamp;
    if (!PyArg_ParseTuple(args, "d", &timestamp))
        return NULL;
    int64_t ts = (int64_t)(timestamp * AV_TIME_BASE);
    av_seek_frame(self->fmt_ctx, -1, ts, AVSEEK_FLAG_BACKWARD);
    avcodec_flush_buffers(self->codec_ctx);
    Py_RETURN_NONE;
}

static PyObject *Decoder_get_width(DecoderObject *self, void *closure) {
    return PyLong_FromLong(self->width);
}

static PyObject *Decoder_get_height(DecoderObject *self, void *closure) {
    return PyLong_FromLong(self->height);
}

static PyObject *Decoder_get_fps(DecoderObject *self, void *closure) {
    return PyFloat_FromDouble(self->fps);
}

static PyObject *Decoder_get_duration(DecoderObject *self, void *closure) {
    return PyFloat_FromDouble(self->duration);
}

static PyObject *Decoder_get_frame_count(DecoderObject *self, void *closure) {
    return PyLong_FromLong(self->frame_count);
}

static PyMethodDef Decoder_methods[] = {
    {"next_frame", (PyCFunction)Decoder_next_frame, METH_NOARGS,
     "Decode and return next video frame as RGB bytes."},
    {"seek", (PyCFunction)Decoder_seek, METH_VARARGS,
     "Seek to timestamp in seconds."},
    {NULL}
};

static PyGetSetDef Decoder_getset[] = {
    {"width", (getter)Decoder_get_width, NULL, "Video width", NULL},
    {"height", (getter)Decoder_get_height, NULL, "Video height", NULL},
    {"fps", (getter)Decoder_get_fps, NULL, "Frames per second", NULL},
    {"duration", (getter)Decoder_get_duration, NULL, "Duration in seconds", NULL},
    {"frame_count", (getter)Decoder_get_frame_count, NULL, "Total frames", NULL},
    {NULL}
};

static PyTypeObject DecoderType = {
    PyVarObject_HEAD_INIT(NULL, 0)
    .tp_name = "_decoder.Decoder",
    .tp_basicsize = sizeof(DecoderObject),
    .tp_dealloc = (destructor)Decoder_dealloc,
    .tp_flags = Py_TPFLAGS_DEFAULT,
    .tp_doc = "FFmpeg-based media decoder",
    .tp_methods = Decoder_methods,
    .tp_getset = Decoder_getset,
    .tp_init = (initproc)Decoder_init,
    .tp_new = PyType_GenericNew,
};

static PyObject *decode_image(PyObject *self, PyObject *args) {
    const char *path;
    if (!PyArg_ParseTuple(args, "s", &path))
        return NULL;

    AVFormatContext *fmt = NULL;
    int ret = avformat_open_input(&fmt, path, NULL, NULL);
    if (ret < 0) {
        char errbuf[256];
        av_strerror(ret, errbuf, sizeof(errbuf));
        PyErr_Format(PyExc_IOError, "cannot open: %s", errbuf);
        return NULL;
    }

    avformat_find_stream_info(fmt, NULL);

    int vidx = -1;
    for (unsigned int i = 0; i < fmt->nb_streams; i++) {
        if (fmt->streams[i]->codecpar->codec_type == AVMEDIA_TYPE_VIDEO) {
            vidx = (int)i;
            break;
        }
    }

    if (vidx < 0) {
        avformat_close_input(&fmt);
        PyErr_SetString(PyExc_ValueError, "no image data");
        return NULL;
    }

    AVCodecParameters *par = fmt->streams[vidx]->codecpar;
    const AVCodec *codec = avcodec_find_decoder(par->codec_id);
    AVCodecContext *ctx = avcodec_alloc_context3(codec);
    avcodec_parameters_to_context(ctx, par);
    avcodec_open2(ctx, codec, NULL);

    AVPacket *pkt = av_packet_alloc();
    AVFrame *frame = av_frame_alloc();
    PyObject *result = NULL;

    while (av_read_frame(fmt, pkt) >= 0) {
        if (pkt->stream_index != vidx) {
            av_packet_unref(pkt);
            continue;
        }
        avcodec_send_packet(ctx, pkt);
        av_packet_unref(pkt);

        if (avcodec_receive_frame(ctx, frame) == 0) {
            int w = frame->width;
            int h = frame->height;

            struct SwsContext *sws = sws_getContext(
                w, h, ctx->pix_fmt, w, h, AV_PIX_FMT_RGB24,
                SWS_BILINEAR, NULL, NULL, NULL
            );

            uint8_t *rgb_buf = (uint8_t *)av_malloc(w * h * 3);
            uint8_t *dst_data[1] = {rgb_buf};
            int dst_linesize[1] = {w * 3};

            sws_scale(sws, (const uint8_t * const *)frame->data,
                      frame->linesize, 0, h, dst_data, dst_linesize);

            result = Py_BuildValue("(y#ii)",
                                   (const char *)rgb_buf, (Py_ssize_t)(w * h * 3),
                                   w, h);
            av_free(rgb_buf);
            sws_freeContext(sws);
            break;
        }
    }

    av_frame_free(&frame);
    av_packet_free(&pkt);
    avcodec_free_context(&ctx);
    avformat_close_input(&fmt);

    if (!result) {
        PyErr_SetString(PyExc_RuntimeError, "failed to decode image");
        return NULL;
    }
    return result;
}

static PyMethodDef decoder_methods[] = {
    {"decode_image", decode_image, METH_VARARGS,
     "Decode image file to (rgb_bytes, width, height)."},
    {NULL, NULL, 0, NULL}
};

static struct PyModuleDef decoder_module = {
    PyModuleDef_HEAD_INIT,
    "_decoder",
    "FFmpeg media decoder for termflux",
    -1,
    decoder_methods
};

PyMODINIT_FUNC PyInit__decoder(void) {
    PyObject *m = PyModule_Create(&decoder_module);
    if (!m) return NULL;
    if (PyType_Ready(&DecoderType) < 0) return NULL;
    Py_INCREF(&DecoderType);
    PyModule_AddObject(m, "Decoder", (PyObject *)&DecoderType);
    return m;
}
