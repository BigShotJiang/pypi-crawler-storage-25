import subprocess
import os
import sys
import signal
import shutil
import time
import math
import struct

import termflux
from termflux.loader import fetch


def _find_audio_player():
    if sys.platform == "win32":
        return "ffplay"
    for cmd in ("ffplay", "mpv", "play", "aplay", "termux-media-player"):
        if shutil.which(cmd):
            return cmd
    return "ffplay"


def _get_audio_info(path):
    try:
        proc = subprocess.run(
            ["ffprobe", "-v", "quiet", "-print_format", "json",
             "-show_format", "-show_streams", path],
            capture_output=True, text=True,
        )
        if proc.returncode != 0:
            return {"duration": 0.0, "sample_rate": 44100, "channels": 2,
                    "codec": "unknown", "bitrate": 0, "title": "", "artist": ""}
        import json
        info = json.loads(proc.stdout)
        fmt = info.get("format", {})
        tags = fmt.get("tags", {})
        stream = {}
        for s in info.get("streams", []):
            if s.get("codec_type") == "audio":
                stream = s
                break
        return {
            "duration": float(fmt.get("duration", 0)),
            "sample_rate": int(stream.get("sample_rate", 44100)),
            "channels": int(stream.get("channels", 2)),
            "codec": stream.get("codec_name", "unknown"),
            "bitrate": int(fmt.get("bit_rate", 0)) // 1000,
            "title": tags.get("title", tags.get("TITLE", "")),
            "artist": tags.get("artist", tags.get("ARTIST", "")),
        }
    except Exception:
        return {"duration": 0.0, "sample_rate": 44100, "channels": 2,
                "codec": "unknown", "bitrate": 0, "title": "", "artist": ""}


def _extract_waveform(path, num_samples=200):
    try:
        proc = subprocess.run(
            ["ffmpeg", "-i", path, "-ac", "1", "-ar", "8000",
             "-f", "s16le", "-t", "60", "-"],
            capture_output=True,
        )
        if proc.returncode != 0 or len(proc.stdout) < 4:
            return [0.0] * num_samples
        raw = proc.stdout
        n = len(raw) // 2
        samples = struct.unpack("<{}h".format(n), raw[:n * 2])
        chunk = max(1, n // num_samples)
        result = []
        for i in range(num_samples):
            start = i * chunk
            end = min(start + chunk, n)
            if start >= n:
                result.append(0.0)
                continue
            peak = max(abs(s) for s in samples[start:end])
            result.append(peak / 32768.0)
        return result
    except Exception:
        return [0.0] * num_samples


class Audio:

    def __init__(self, source):
        self._path = fetch(source)
        self._process = None
        self._player = _find_audio_player()
        self._info = None
        self._waveform = None
        self._source_name = os.path.basename(
            source.split("?")[0] if "://" in source else source)

    def _build_cmd(self):
        if self._player == "ffplay":
            return ["ffplay", "-nodisp", "-autoexit", "-loglevel", "quiet",
                    self._path]
        elif self._player == "mpv":
            return ["mpv", "--no-video", "--really-quiet", self._path]
        elif self._player == "termux-media-player":
            return ["termux-media-player", "play", self._path]
        elif self._player == "play":
            return ["play", "-q", self._path]
        elif self._player == "aplay":
            return ["aplay", "-q", self._path]
        return ["ffplay", "-nodisp", "-autoexit", "-loglevel", "quiet",
                self._path]

    def play_background(self):
        devnull = open(os.devnull, "w")
        try:
            self._process = subprocess.Popen(
                self._build_cmd(),
                stdout=devnull,
                stderr=devnull,
            )
        except FileNotFoundError:
            pass

    def play(self, show_ui=True):
        if show_ui:
            self._play_with_ui()
        else:
            self.play_background()
            if self._process:
                self._process.wait()

    def _play_with_ui(self):
        if self._info is None:
            self._info = _get_audio_info(self._path)
        if self._waveform is None:
            self._waveform = _extract_waveform(self._path, 200)

        self.play_background()
        if not self._process:
            return

        running = True
        prev_handler = signal.getsignal(signal.SIGINT)

        def _stop(sig, frame):
            nonlocal running
            running = False

        signal.signal(signal.SIGINT, _stop)
        termflux.clear_screen()
        termflux.hide_cursor()

        tw, th = termflux.get_terminal_size()
        t0 = time.monotonic()
        duration = self._info["duration"]
        if duration <= 0:
            duration = 60.0

        try:
            while running and self.is_playing:
                elapsed = time.monotonic() - t0
                progress = min(elapsed / duration, 1.0) if duration > 0 else 0.0
                self._draw_ui(tw, th, elapsed, duration, progress)
                termflux.sleep_precise(0.05)
        except KeyboardInterrupt:
            running = False
        finally:
            self.stop()
            termflux.show_cursor()
            termflux.reset()
            signal.signal(signal.SIGINT, prev_handler)

    def _draw_ui(self, tw, th, elapsed, duration, progress):
        parts = []
        reset = "\033[0m"
        bg = "\033[48;2;15;15;25m"
        accent = "\033[38;2;0;220;180m"
        bright = "\033[38;2;255;255;255m"
        dim = "\033[38;2;90;90;110m"
        bar_fill = "\033[38;2;0;200;160m"
        bar_empty = "\033[38;2;35;35;50m"
        wave_color = "\033[38;2;0;180;255m"
        wave_play = "\033[38;2;0;255;200m"

        for row in range(1, th + 1):
            parts.append("\033[{};1H".format(row))
            parts.append(bg + " " * tw + reset)

        cy = th // 2
        title = self._info.get("title", "") or self._source_name
        artist = self._info.get("artist", "")

        parts.append("\033[{};1H".format(cy - 8))
        parts.append(bg + accent + "  termflux audio player" + reset)

        parts.append("\033[{};1H".format(cy - 6))
        label = "  {}".format(title[:tw - 4])
        parts.append(bg + bright + label + reset)

        if artist:
            parts.append("\033[{};1H".format(cy - 5))
            parts.append(bg + dim + "  {}".format(artist[:tw - 4]) + reset)

        info_row = cy - 3
        codec = self._info.get("codec", "")
        sr = self._info.get("sample_rate", 0)
        ch = self._info.get("channels", 0)
        br = self._info.get("bitrate", 0)
        info_str = "  {} | {}Hz | {}ch | {}kbps".format(codec, sr, ch, br)
        parts.append("\033[{};1H".format(info_row))
        parts.append(bg + dim + info_str[:tw - 2] + reset)

        wave_y_start = cy - 1
        wave_h = 6
        wave_w = tw - 4
        if wave_w > 0 and self._waveform:
            num_samples = len(self._waveform)
            play_pos = int(progress * wave_w)
            for wy in range(wave_h):
                parts.append("\033[{};3H".format(wave_y_start + wy))
                level = (wave_h - 1 - wy) / (wave_h - 1)
                line_chars = []
                for wx in range(wave_w):
                    si = int(wx * num_samples / wave_w)
                    si = min(si, num_samples - 1)
                    amp = self._waveform[si]
                    if amp >= level * 0.8:
                        if wx <= play_pos:
                            line_chars.append(wave_play + "\xe2\x96\x88")
                        else:
                            line_chars.append(wave_color + "\xe2\x96\x88")
                    else:
                        line_chars.append(bar_empty + "\xe2\x96\x91")
                parts.append(bg + "".join(line_chars) + reset)

        bar_y = cy + wave_h + 1
        bar_w = tw - 6
        if bar_w > 0:
            filled = int(bar_w * progress)
            parts.append("\033[{};4H".format(bar_y))
            parts.append(bg + bar_fill + "\xe2\x96\x88" * filled)
            parts.append(bar_empty + "\xe2\x96\x91" * (bar_w - filled) + reset)

        e_min = int(elapsed) // 60
        e_sec = int(elapsed) % 60
        d_min = int(duration) // 60
        d_sec = int(duration) % 60
        time_str = "  {}:{:02d} / {}:{:02d}".format(e_min, e_sec, d_min, d_sec)
        parts.append("\033[{};1H".format(bar_y + 2))
        parts.append(bg + bright + time_str + reset)

        status = "  PLAYING" if self.is_playing else "  STOPPED"
        parts.append("\033[{};{}H".format(bar_y + 2, tw - 10))
        parts.append(bg + accent + status + reset)

        parts.append("\033[{};1H".format(th - 1))
        parts.append(bg + dim + "  Ctrl+C to stop | MERO:TG@QP4RM" + reset)

        sys.stdout.write("".join(parts))
        sys.stdout.flush()

    def stop(self):
        if self._process and self._process.poll() is None:
            if sys.platform == "win32":
                self._process.terminate()
            else:
                self._process.send_signal(signal.SIGTERM)
            try:
                self._process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                self._process.kill()
            self._process = None

    @property
    def is_playing(self):
        return self._process is not None and self._process.poll() is None
