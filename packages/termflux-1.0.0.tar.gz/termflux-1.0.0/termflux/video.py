import sys
import time
import signal
import subprocess

import termflux
from termflux.loader import fetch
from termflux.audio import Audio
from termflux.image import _compute_offset, _compute_display_size

try:
    from termflux._decoder import Decoder
    _HAS_DECODER = True
except ImportError:
    _HAS_DECODER = False


class _FallbackDecoder:

    def __init__(self, path):
        self._path = path
        info = subprocess.run(
            ["ffprobe", "-v", "quiet", "-select_streams", "v:0",
             "-show_entries", "stream=width,height,r_frame_rate,duration",
             "-show_entries", "format=duration",
             "-of", "csv=p=0", path],
            capture_output=True, text=True,
        )
        lines = info.stdout.strip().split("\n")
        parts = lines[0].split(",")
        self.width = int(parts[0])
        self.height = int(parts[1])
        if "/" in parts[2]:
            num, den = parts[2].split("/")
            self.fps = float(num) / float(den) if float(den) else 30.0
        else:
            self.fps = float(parts[2]) if parts[2] else 30.0
        try:
            self.duration = float(parts[3]) if len(parts) > 3 and parts[3] else 0.0
        except (ValueError, IndexError):
            self.duration = 0.0
        if self.duration == 0.0 and len(lines) > 1:
            try:
                self.duration = float(lines[1].strip())
            except (ValueError, IndexError):
                pass
        self.frame_count = int(self.fps * self.duration) if self.duration else 0
        self._proc = None
        self._start_decode()

    def _start_decode(self):
        if self._proc and self._proc.poll() is None:
            self._proc.kill()
        self._proc = subprocess.Popen(
            ["ffmpeg", "-i", self._path,
             "-f", "rawvideo", "-pix_fmt", "rgb24", "-"],
            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
        )

    def next_frame(self):
        frame_size = self.width * self.height * 3
        data = self._proc.stdout.read(frame_size)
        if len(data) < frame_size:
            return None
        return data

    def seek(self, ts):
        self._start_decode()


class Video:

    def __init__(self, source, audio_source=None):
        local = fetch(source)
        if _HAS_DECODER:
            self._decoder = Decoder(path=local)
        else:
            self._decoder = _FallbackDecoder(local)
        self._audio = None
        self._audio_source = audio_source if audio_source else local
        self._running = False

    @property
    def width(self):
        return self._decoder.width

    @property
    def height(self):
        return self._decoder.height

    @property
    def fps(self):
        return self._decoder.fps

    @property
    def duration(self):
        return self._decoder.duration

    def play(self, border_style=termflux.BORDER_NONE,
             border_r=255, border_g=255, border_b=255,
             position="center", width=None, height=None,
             with_audio=True, loop=False,
             render_mode=termflux.RENDER_QUARTER,
             border_thick=1, padding=0,
             brightness=1.0, contrast=1.0, saturation=1.0,
             grayscale=False, invert=False,
             aspect="fit"):
        tw, th = termflux.get_terminal_size()

        rw, rh = _compute_display_size(
            self._decoder.width, self._decoder.height,
            tw, th, width, height, aspect,
            border_style, border_thick, padding)

        ox, oy = _compute_offset(position, rw, rh, tw, th)

        self._running = True
        prev_handler = signal.getsignal(signal.SIGINT)

        def _stop(sig, frame):
            self._running = False

        signal.signal(signal.SIGINT, _stop)

        termflux.clear_screen()
        termflux.hide_cursor()

        if with_audio:
            try:
                self._audio = Audio(self._audio_source)
                self._audio.play_background()
            except Exception:
                self._audio = None

        spf = 1.0 / self._decoder.fps
        t0 = time.monotonic()
        frame_idx = 0
        drop_threshold = spf * 2.0

        try:
            while self._running:
                frame_data = self._decoder.next_frame()
                if frame_data is None:
                    if loop:
                        self._decoder.seek(0.0)
                        frame_idx = 0
                        t0 = time.monotonic()
                        continue
                    break

                now = time.monotonic()
                target = t0 + frame_idx * spf
                if now - target > drop_threshold:
                    frame_idx += 1
                    continue

                rendered = termflux.render_frame(
                    frame_data, self._decoder.width, self._decoder.height,
                    term_width=rw, term_height=rh,
                    offset_x=ox, offset_y=oy,
                    border_style=border_style,
                    border_r=border_r, border_g=border_g, border_b=border_b,
                    render_mode=render_mode,
                    border_thick=border_thick, padding=padding,
                    brightness=brightness, contrast=contrast,
                    saturation=saturation,
                    grayscale=int(grayscale), invert=int(invert),
                )
                termflux.flush_frame(rendered)

                frame_idx += 1
                target = t0 + frame_idx * spf
                now = time.monotonic()
                if target > now:
                    termflux.sleep_precise(target - now)
        finally:
            if self._audio:
                self._audio.stop()
            termflux.show_cursor()
            termflux.reset()
            signal.signal(signal.SIGINT, prev_handler)

    def stop(self):
        self._running = False

    def seek(self, seconds):
        self._decoder.seek(seconds)
