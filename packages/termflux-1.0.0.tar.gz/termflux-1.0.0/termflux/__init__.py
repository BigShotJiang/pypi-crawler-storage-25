"""termflux - terminal media engine with pixel-accurate rendering."""

__version__ = "1.0.0"
__author__ = "MERO:TG@QP4RM"

try:
    from termflux._engine import (
        BORDER_NONE,
        BORDER_SINGLE,
        BORDER_DOUBLE,
        BORDER_BOLD,
        BORDER_ROUND,
        RENDER_HALF,
        RENDER_QUARTER,
        RENDER_SIXEL,
        render_frame,
        scale,
        get_terminal_size,
        hide_cursor,
        show_cursor,
        clear_screen,
        reset,
        flush_frame,
        sleep_precise,
        enable_ansi,
    )
    _NATIVE = True
except ImportError:
    from termflux._fallback import (
        BORDER_NONE,
        BORDER_SINGLE,
        BORDER_DOUBLE,
        BORDER_BOLD,
        BORDER_ROUND,
        RENDER_HALF,
        RENDER_QUARTER,
        RENDER_SIXEL,
        render_frame,
        scale,
        get_terminal_size,
        hide_cursor,
        show_cursor,
        clear_screen,
        reset,
        flush_frame,
        sleep_precise,
        enable_ansi,
    )
    _NATIVE = False

from termflux.image import Image
from termflux.video import Video
from termflux.audio import Audio
from termflux.player import Player

__all__ = [
    "Image",
    "Video",
    "Audio",
    "Player",
    "BORDER_NONE",
    "BORDER_SINGLE",
    "BORDER_DOUBLE",
    "BORDER_BOLD",
    "BORDER_ROUND",
    "RENDER_HALF",
    "RENDER_QUARTER",
    "RENDER_SIXEL",
]
