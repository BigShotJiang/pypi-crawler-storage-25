#define PY_SSIZE_T_CLEAN
#include <Python.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <math.h>
#include <stdarg.h>

#ifdef _WIN32
#include <windows.h>
#include <io.h>
#define STDOUT_FD 1
#define platform_write(fd, buf, len) _write(fd, buf, (unsigned int)(len))
#else
#include <sys/ioctl.h>
#include <unistd.h>
#include <time.h>
#define STDOUT_FD STDOUT_FILENO
#define platform_write(fd, buf, len) write(fd, buf, len)
#endif

#define BORDER_NONE   0
#define BORDER_SINGLE 1
#define BORDER_DOUBLE 2
#define BORDER_BOLD   3
#define BORDER_ROUND  4

#define RENDER_HALF   0
#define RENDER_QUARTER 1
#define RENDER_SIXEL  2

#define SIXEL_MAX_COLORS 256
#define M_PI_LOCAL 3.14159265358979323846

static const char *border_chars[][6] = {
    {"", "", "", "", "", ""},
    {"\xe2\x94\x8c", "\xe2\x94\x90", "\xe2\x94\x94", "\xe2\x94\x98", "\xe2\x94\x80", "\xe2\x94\x82"},
    {"\xe2\x95\x94", "\xe2\x95\x97", "\xe2\x95\x9a", "\xe2\x95\x9d", "\xe2\x95\x90", "\xe2\x95\x91"},
    {"\xe2\x94\x8f", "\xe2\x94\x93", "\xe2\x94\x97", "\xe2\x94\x9b", "\xe2\x94\x81", "\xe2\x94\x83"},
    {"\xe2\x95\xad", "\xe2\x95\xae", "\xe2\x95\xb0", "\xe2\x95\xaf", "\xe2\x94\x80", "\xe2\x94\x82"},
};

/* Quarter-block characters: 16 patterns for 2x2 grid (TL,TR,BL,BR) */
/* Index = (TL<<3)|(TR<<2)|(BL<<1)|BR -> maps to character */
static const char *qblock[16] = {
    " ",                           /* 0000 empty */
    "\xe2\x96\x97",               /* 0001 BR */
    "\xe2\x96\x96",               /* 0010 BL */
    "\xe2\x96\x84",               /* 0011 BL+BR = lower half */
    "\xe2\x96\x9d",               /* 0100 TR */
    "\xe2\x96\x90",               /* 0101 TR+BR = right half */
    "\xe2\x96\x9e",               /* 0110 BL+TR */
    "\xe2\x96\x9f",               /* 0111 BL+TR+BR */
    "\xe2\x96\x98",               /* 1000 TL */
    "\xe2\x96\x9a",               /* 1001 TL+BR */
    "\xe2\x96\x8c",               /* 1010 TL+BL = left half */
    "\xe2\x96\x99",               /* 1011 TL+BL+BR */
    "\xe2\x96\x80",               /* 1100 TL+TR = upper half */
    "\xe2\x96\x9c",               /* 1101 TL+TR+BR */
    "\xe2\x96\x9b",               /* 1110 TL+TR+BL */
    "\xe2\x96\x88",               /* 1111 full block */
};

typedef struct {
    unsigned char r, g, b;
} Pixel;

typedef struct {
    char *data;
    size_t len;
    size_t cap;
} StrBuf;

static void strbuf_init(StrBuf *buf, size_t initial_cap) {
    buf->data = (char *)malloc(initial_cap);
    buf->len = 0;
    buf->cap = initial_cap;
    if (buf->data) buf->data[0] = '\0';
}

static void strbuf_ensure(StrBuf *buf, size_t additional) {
    if (buf->len + additional + 1 > buf->cap) {
        size_t new_cap = (buf->cap + additional + 1) * 2;
        char *new_data = (char *)realloc(buf->data, new_cap);
        if (new_data) {
            buf->data = new_data;
            buf->cap = new_cap;
        }
    }
}

static void strbuf_append(StrBuf *buf, const char *s, size_t slen) {
    strbuf_ensure(buf, slen);
    memcpy(buf->data + buf->len, s, slen);
    buf->len += slen;
    buf->data[buf->len] = '\0';
}

static void strbuf_appendf(StrBuf *buf, const char *fmt, ...) {
    char tmp[128];
    va_list args;
    va_start(args, fmt);
    int n = vsnprintf(tmp, sizeof(tmp), fmt, args);
    va_end(args);
    if (n > 0) strbuf_append(buf, tmp, (size_t)n);
}

static void strbuf_free(StrBuf *buf) {
    free(buf->data);
    buf->data = NULL;
    buf->len = 0;
    buf->cap = 0;
}

static inline int clamp_i(int v, int lo, int hi) {
    return v < lo ? lo : (v > hi ? hi : v);
}

static inline double clamp_d(double v, double lo, double hi) {
    return v < lo ? lo : (v > hi ? hi : v);
}

static Pixel sample_bilinear(const unsigned char *src, int sw, int sh,
                              double fx, double fy) {
    int x0 = (int)fx;
    int y0 = (int)fy;
    int x1 = x0 + 1;
    int y1 = y0 + 1;
    x0 = clamp_i(x0, 0, sw - 1);
    y0 = clamp_i(y0, 0, sh - 1);
    x1 = clamp_i(x1, 0, sw - 1);
    y1 = clamp_i(y1, 0, sh - 1);
    double dx = fx - (double)(int)fx;
    double dy = fy - (double)(int)fy;
    if (dx < 0) dx = 0;
    if (dy < 0) dy = 0;

    const unsigned char *p00 = src + (y0 * sw + x0) * 3;
    const unsigned char *p10 = src + (y0 * sw + x1) * 3;
    const unsigned char *p01 = src + (y1 * sw + x0) * 3;
    const unsigned char *p11 = src + (y1 * sw + x1) * 3;

    Pixel out;
    out.r = (unsigned char)clamp_i((int)(p00[0]*(1-dx)*(1-dy) + p10[0]*dx*(1-dy) +
                            p01[0]*(1-dx)*dy + p11[0]*dx*dy + 0.5), 0, 255);
    out.g = (unsigned char)clamp_i((int)(p00[1]*(1-dx)*(1-dy) + p10[1]*dx*(1-dy) +
                            p01[1]*(1-dx)*dy + p11[1]*dx*dy + 0.5), 0, 255);
    out.b = (unsigned char)clamp_i((int)(p00[2]*(1-dx)*(1-dy) + p10[2]*dx*(1-dy) +
                            p01[2]*(1-dx)*dy + p11[2]*dx*dy + 0.5), 0, 255);
    return out;
}

static inline double sinc(double x) {
    if (fabs(x) < 1e-8) return 1.0;
    double px = M_PI_LOCAL * x;
    return sin(px) / px;
}

static inline double lanczos3_kernel(double x) {
    if (fabs(x) >= 3.0) return 0.0;
    return sinc(x) * sinc(x / 3.0);
}

static Pixel sample_lanczos3(const unsigned char *src, int sw, int sh,
                              double fx, double fy) {
    int ix = (int)floor(fx);
    int iy = (int)floor(fy);
    double r = 0, g = 0, b = 0, wsum = 0;
    for (int dy = -2; dy <= 3; dy++) {
        int sy = clamp_i(iy + dy, 0, sh - 1);
        double wy = lanczos3_kernel(fy - (iy + dy));
        for (int dx = -2; dx <= 3; dx++) {
            int sx = clamp_i(ix + dx, 0, sw - 1);
            double wx = lanczos3_kernel(fx - (ix + dx));
            double w = wx * wy;
            const unsigned char *p = src + (sy * sw + sx) * 3;
            r += p[0] * w;
            g += p[1] * w;
            b += p[2] * w;
            wsum += w;
        }
    }
    Pixel out;
    if (wsum > 0.0) {
        out.r = (unsigned char)clamp_i((int)(r / wsum + 0.5), 0, 255);
        out.g = (unsigned char)clamp_i((int)(g / wsum + 0.5), 0, 255);
        out.b = (unsigned char)clamp_i((int)(b / wsum + 0.5), 0, 255);
    } else {
        out.r = out.g = out.b = 0;
    }
    return out;
}

static unsigned char *scale_pixels(const unsigned char *src, int sw, int sh,
                                    int dw, int dh) {
    unsigned char *dst = (unsigned char *)malloc(dw * dh * 3);
    if (!dst) return NULL;

    double sx = (double)sw / (double)dw;
    double sy = (double)sh / (double)dh;

    int use_lanczos = (sx > 1.2 || sy > 1.2 || sx < 0.8 || sy < 0.8);

    for (int y = 0; y < dh; y++) {
        for (int x = 0; x < dw; x++) {
            double fx = ((double)x + 0.5) * sx - 0.5;
            double fy = ((double)y + 0.5) * sy - 0.5;
            Pixel p;
            if (use_lanczos)
                p = sample_lanczos3(src, sw, sh, fx, fy);
            else
                p = sample_bilinear(src, sw, sh, fx, fy);
            unsigned char *d = dst + (y * dw + x) * 3;
            d[0] = p.r;
            d[1] = p.g;
            d[2] = p.b;
        }
    }
    return dst;
}

static void append_move_cursor(StrBuf *buf, int row, int col) {
    strbuf_appendf(buf, "\033[%d;%dH", row, col);
}

static void append_fg_color(StrBuf *buf, unsigned char r, unsigned char g,
                            unsigned char b) {
    strbuf_appendf(buf, "\033[38;2;%d;%d;%dm", r, g, b);
}

static void append_bg_color(StrBuf *buf, unsigned char r, unsigned char g,
                            unsigned char b) {
    strbuf_appendf(buf, "\033[48;2;%d;%d;%dm", r, g, b);
}

static void append_reset(StrBuf *buf) {
    strbuf_append(buf, "\033[0m", 4);
}

static inline int color_dist_sq(Pixel a, Pixel b) {
    int dr = (int)a.r - (int)b.r;
    int dg = (int)a.g - (int)b.g;
    int db = (int)a.b - (int)b.b;
    int rmean = ((int)a.r + (int)b.r) / 2;
    return ((512 + rmean) * dr * dr >> 8) + 4 * dg * dg +
           ((767 - rmean) * db * db >> 8);
}

static void render_quarter_block(StrBuf *out, const unsigned char *src,
                                  int pw, int ph, int term_w, int term_h,
                                  int off_x, int off_y,
                                  int border_style, int border_r, int border_g, int border_b,
                                  int border_thick, int padding) {
    int boff = 0;
    int rw = term_w;
    int rh = term_h;

    if (border_style != BORDER_NONE) {
        rw -= border_thick * 2;
        rh -= border_thick * 2;
        boff = border_thick;
    }
    rw -= padding * 2;
    rh -= padding * 2;
    if (rw <= 0 || rh <= 0) return;

    int pixel_w = rw * 2;
    int pixel_h = rh * 2;

    unsigned char *scaled = NULL;
    if (pw != pixel_w || ph != pixel_h) {
        scaled = scale_pixels(src, pw, ph, pixel_w, pixel_h);
        if (!scaled) return;
        src = scaled;
    }

    strbuf_append(out, "\033[?25l", 6);

    if (border_style != BORDER_NONE && border_style >= 1 && border_style <= 4) {
        const char **bc = border_chars[border_style];

        for (int t = 0; t < border_thick; t++) {
            append_move_cursor(out, off_y + 1 + t, off_x + 1 + t);
            append_fg_color(out, border_r, border_g, border_b);
            if (t == 0) {
                strbuf_append(out, bc[0], strlen(bc[0]));
                for (int i = 0; i < term_w - 2 - t * 2; i++)
                    strbuf_append(out, bc[4], strlen(bc[4]));
                strbuf_append(out, bc[1], strlen(bc[1]));
            } else {
                strbuf_append(out, bc[5], strlen(bc[5]));
                for (int i = 0; i < term_w - 2 - t * 2; i++)
                    strbuf_append(out, bc[4], strlen(bc[4]));
                strbuf_append(out, bc[5], strlen(bc[5]));
            }

            int inner_rows = term_h - 2 - t * 2;
            for (int r = 1; r < inner_rows + 1; r++) {
                append_move_cursor(out, off_y + 1 + t + r, off_x + 1 + t);
                strbuf_append(out, bc[5], strlen(bc[5]));
                append_move_cursor(out, off_y + 1 + t + r, off_x + term_w - t);
                strbuf_append(out, bc[5], strlen(bc[5]));
            }

            append_move_cursor(out, off_y + term_h - t, off_x + 1 + t);
            if (t == 0) {
                strbuf_append(out, bc[2], strlen(bc[2]));
                for (int i = 0; i < term_w - 2 - t * 2; i++)
                    strbuf_append(out, bc[4], strlen(bc[4]));
                strbuf_append(out, bc[3], strlen(bc[3]));
            } else {
                strbuf_append(out, bc[5], strlen(bc[5]));
                for (int i = 0; i < term_w - 2 - t * 2; i++)
                    strbuf_append(out, bc[4], strlen(bc[4]));
                strbuf_append(out, bc[5], strlen(bc[5]));
            }
        }
    }

    int base_row = off_y + 1 + boff + padding;
    int base_col = off_x + 1 + boff + padding;

    for (int row = 0; row < rh; row++) {
        append_move_cursor(out, base_row + row, base_col);

        for (int col = 0; col < rw; col++) {
            int sy = row * 2;
            int sx = col * 2;

            Pixel tl, tr, bl, br;
            const unsigned char *p;

            p = src + (sy * pixel_w + sx) * 3;
            tl.r = p[0]; tl.g = p[1]; tl.b = p[2];

            p = src + (sy * pixel_w + sx + 1) * 3;
            tr.r = p[0]; tr.g = p[1]; tr.b = p[2];

            p = src + ((sy + 1) * pixel_w + sx) * 3;
            bl.r = p[0]; bl.g = p[1]; bl.b = p[2];

            p = src + ((sy + 1) * pixel_w + sx + 1) * 3;
            br.r = p[0]; br.g = p[1]; br.b = p[2];

            Pixel pixels[4] = {tl, tr, bl, br};

            Pixel fg = tl, bg = tl;
            int max_dist = 0;
            for (int i = 0; i < 4; i++) {
                for (int j = i + 1; j < 4; j++) {
                    int d = color_dist_sq(pixels[i], pixels[j]);
                    if (d > max_dist) {
                        max_dist = d;
                        fg = pixels[i];
                        bg = pixels[j];
                    }
                }
            }

            if (max_dist < 50) {
                int ar = ((int)tl.r + tr.r + bl.r + br.r + 2) / 4;
                int ag = ((int)tl.g + tr.g + bl.g + br.g + 2) / 4;
                int ab = ((int)tl.b + tr.b + bl.b + br.b + 2) / 4;
                append_bg_color(out, ar, ag, ab);
                strbuf_append(out, " ", 1);
                continue;
            }

            int pattern = 0;
            for (int i = 0; i < 4; i++) {
                int d_fg = color_dist_sq(pixels[i], fg);
                int d_bg = color_dist_sq(pixels[i], bg);
                if (d_fg <= d_bg)
                    pattern |= (8 >> i);
            }

            int fg_r = 0, fg_g = 0, fg_b = 0, fg_cnt = 0;
            int bg_r = 0, bg_g = 0, bg_b = 0, bg_cnt = 0;
            for (int i = 0; i < 4; i++) {
                if (pattern & (8 >> i)) {
                    fg_r += pixels[i].r; fg_g += pixels[i].g; fg_b += pixels[i].b;
                    fg_cnt++;
                } else {
                    bg_r += pixels[i].r; bg_g += pixels[i].g; bg_b += pixels[i].b;
                    bg_cnt++;
                }
            }
            if (fg_cnt > 0) {
                fg.r = fg_r / fg_cnt; fg.g = fg_g / fg_cnt; fg.b = fg_b / fg_cnt;
            }
            if (bg_cnt > 0) {
                bg.r = bg_r / bg_cnt; bg.g = bg_g / bg_cnt; bg.b = bg_b / bg_cnt;
            }

            append_fg_color(out, fg.r, fg.g, fg.b);
            append_bg_color(out, bg.r, bg.g, bg.b);
            const char *ch = qblock[pattern];
            strbuf_append(out, ch, strlen(ch));
        }
        append_reset(out);
    }

    append_reset(out);
    free(scaled);
}

static void render_half_block(StrBuf *out, const unsigned char *src,
                               int pw, int ph, int term_w, int term_h,
                               int off_x, int off_y,
                               int border_style, int border_r, int border_g, int border_b,
                               int border_thick, int padding) {
    int boff = 0;
    int rw = term_w;
    int rh = term_h * 2;

    if (border_style != BORDER_NONE) {
        rw -= border_thick * 2;
        rh -= border_thick * 4;
        boff = border_thick;
    }
    rw -= padding * 2;
    rh -= padding * 4;
    if (rw <= 0 || rh <= 0) return;

    unsigned char *scaled = NULL;
    if (pw != rw || ph != rh) {
        scaled = scale_pixels(src, pw, ph, rw, rh);
        if (!scaled) return;
        src = scaled;
    }

    strbuf_append(out, "\033[?25l", 6);

    if (border_style != BORDER_NONE && border_style >= 1 && border_style <= 4) {
        const char **bc = border_chars[border_style];
        for (int t = 0; t < border_thick; t++) {
            append_move_cursor(out, off_y + 1 + t, off_x + 1 + t);
            append_fg_color(out, border_r, border_g, border_b);
            strbuf_append(out, t == 0 ? bc[0] : bc[5], strlen(t == 0 ? bc[0] : bc[5]));
            for (int i = 0; i < term_w - 2 - t * 2; i++)
                strbuf_append(out, bc[4], strlen(bc[4]));
            strbuf_append(out, t == 0 ? bc[1] : bc[5], strlen(t == 0 ? bc[1] : bc[5]));

            int inner_h = term_h - 2 - t * 2;
            for (int r = 1; r <= inner_h; r++) {
                append_move_cursor(out, off_y + 1 + t + r, off_x + 1 + t);
                strbuf_append(out, bc[5], strlen(bc[5]));
                append_move_cursor(out, off_y + 1 + t + r, off_x + term_w - t);
                strbuf_append(out, bc[5], strlen(bc[5]));
            }

            append_move_cursor(out, off_y + term_h - t, off_x + 1 + t);
            strbuf_append(out, t == 0 ? bc[2] : bc[5], strlen(t == 0 ? bc[2] : bc[5]));
            for (int i = 0; i < term_w - 2 - t * 2; i++)
                strbuf_append(out, bc[4], strlen(bc[4]));
            strbuf_append(out, t == 0 ? bc[3] : bc[5], strlen(t == 0 ? bc[3] : bc[5]));
        }
    }

    int base_row = off_y + 1 + boff + padding;
    int base_col = off_x + 1 + boff + padding;

    for (int row = 0; row < rh; row += 2) {
        append_move_cursor(out, base_row + row / 2, base_col);
        for (int col = 0; col < rw; col++) {
            const unsigned char *top = src + (row * rw + col) * 3;
            unsigned char br2 = 0, bg2 = 0, bb2 = 0;
            if (row + 1 < rh) {
                const unsigned char *bot = src + ((row + 1) * rw + col) * 3;
                br2 = bot[0]; bg2 = bot[1]; bb2 = bot[2];
            }
            append_fg_color(out, top[0], top[1], top[2]);
            append_bg_color(out, br2, bg2, bb2);
            strbuf_append(out, "\xe2\x96\x80", 3);
        }
        append_reset(out);
    }

    append_reset(out);
    free(scaled);
}

/* ---- Sixel Graphics Renderer ---- */

typedef struct {
    unsigned char r, g, b;
    int count;
} ColorBucket;

static int find_closest_color(unsigned char r, unsigned char g, unsigned char b,
                               ColorBucket *palette, int ncolors) {
    int best = 0;
    int best_dist = 0x7FFFFFFF;
    for (int i = 0; i < ncolors; i++) {
        int dr = (int)r - (int)palette[i].r;
        int dg = (int)g - (int)palette[i].g;
        int db = (int)b - (int)palette[i].b;
        int rmean = ((int)r + (int)palette[i].r) / 2;
        int d = ((512 + rmean) * dr * dr >> 8) + 4 * dg * dg +
                ((767 - rmean) * db * db >> 8);
        if (d < best_dist) {
            best_dist = d;
            best = i;
        }
    }
    return best;
}

static int build_palette(const unsigned char *pixels, int w, int h,
                          ColorBucket *palette) {
    int hist_size = 32 * 32 * 32;
    int *hist = (int *)calloc(hist_size, sizeof(int));
    int *hist_r = (int *)calloc(hist_size, sizeof(int));
    int *hist_g = (int *)calloc(hist_size, sizeof(int));
    int *hist_b = (int *)calloc(hist_size, sizeof(int));
    if (!hist || !hist_r || !hist_g || !hist_b) {
        free(hist); free(hist_r); free(hist_g); free(hist_b);
        return 0;
    }

    int total = w * h;
    for (int i = 0; i < total; i++) {
        int r = pixels[i * 3] >> 3;
        int g = pixels[i * 3 + 1] >> 3;
        int b = pixels[i * 3 + 2] >> 3;
        int idx = (r << 10) | (g << 5) | b;
        hist[idx]++;
        hist_r[idx] += pixels[i * 3];
        hist_g[idx] += pixels[i * 3 + 1];
        hist_b[idx] += pixels[i * 3 + 2];
    }

    typedef struct { int count; int idx; } BucketSort;
    BucketSort *sortable = (BucketSort *)malloc(hist_size * sizeof(BucketSort));
    if (!sortable) {
        free(hist); free(hist_r); free(hist_g); free(hist_b);
        return 0;
    }

    int nused = 0;
    for (int i = 0; i < hist_size; i++) {
        if (hist[i] > 0) {
            sortable[nused].count = hist[i];
            sortable[nused].idx = i;
            nused++;
        }
    }

    for (int i = 0; i < nused - 1 && i < SIXEL_MAX_COLORS; i++) {
        int best = i;
        for (int j = i + 1; j < nused; j++) {
            if (sortable[j].count > sortable[best].count)
                best = j;
        }
        if (best != i) {
            BucketSort tmp = sortable[i];
            sortable[i] = sortable[best];
            sortable[best] = tmp;
        }
    }

    int ncolors = nused < SIXEL_MAX_COLORS ? nused : SIXEL_MAX_COLORS;
    for (int i = 0; i < ncolors; i++) {
        int idx = sortable[i].idx;
        int c = hist[idx];
        palette[i].r = (unsigned char)(hist_r[idx] / c);
        palette[i].g = (unsigned char)(hist_g[idx] / c);
        palette[i].b = (unsigned char)(hist_b[idx] / c);
        palette[i].count = c;
    }

    free(hist); free(hist_r); free(hist_g); free(hist_b);
    free(sortable);
    return ncolors;
}

static void render_sixel(StrBuf *out, const unsigned char *src,
                          int pw, int ph, int target_w, int target_h) {
    unsigned char *scaled = NULL;
    const unsigned char *pixels = src;

    if (pw != target_w || ph != target_h) {
        scaled = scale_pixels(src, pw, ph, target_w, target_h);
        if (!scaled) return;
        pixels = scaled;
    }

    ColorBucket palette[SIXEL_MAX_COLORS];
    int ncolors = build_palette(pixels, target_w, target_h, palette);
    if (ncolors == 0) { free(scaled); return; }

    int *indexed = (int *)malloc(target_w * target_h * sizeof(int));
    if (!indexed) { free(scaled); return; }

    for (int i = 0; i < target_w * target_h; i++) {
        indexed[i] = find_closest_color(pixels[i * 3], pixels[i * 3 + 1],
                                         pixels[i * 3 + 2], palette, ncolors);
    }

    /* Floyd-Steinberg dithering */
    {
        int *err_r = (int *)calloc(target_w * target_h, sizeof(int));
        int *err_g = (int *)calloc(target_w * target_h, sizeof(int));
        int *err_b = (int *)calloc(target_w * target_h, sizeof(int));
        if (err_r && err_g && err_b) {
            for (int y = 0; y < target_h; y++) {
                for (int x = 0; x < target_w; x++) {
                    int i = y * target_w + x;
                    int cr = clamp_i((int)pixels[i * 3] + err_r[i], 0, 255);
                    int cg = clamp_i((int)pixels[i * 3 + 1] + err_g[i], 0, 255);
                    int cb = clamp_i((int)pixels[i * 3 + 2] + err_b[i], 0, 255);
                    int ci = find_closest_color(cr, cg, cb, palette, ncolors);
                    indexed[i] = ci;
                    int er = cr - (int)palette[ci].r;
                    int eg = cg - (int)palette[ci].g;
                    int eb = cb - (int)palette[ci].b;
                    if (x + 1 < target_w) {
                        err_r[i + 1] += er * 7 / 16;
                        err_g[i + 1] += eg * 7 / 16;
                        err_b[i + 1] += eb * 7 / 16;
                    }
                    if (y + 1 < target_h) {
                        if (x > 0) {
                            err_r[i + target_w - 1] += er * 3 / 16;
                            err_g[i + target_w - 1] += eg * 3 / 16;
                            err_b[i + target_w - 1] += eb * 3 / 16;
                        }
                        err_r[i + target_w] += er * 5 / 16;
                        err_g[i + target_w] += eg * 5 / 16;
                        err_b[i + target_w] += eb * 5 / 16;
                        if (x + 1 < target_w) {
                            err_r[i + target_w + 1] += er * 1 / 16;
                            err_g[i + target_w + 1] += eg * 1 / 16;
                            err_b[i + target_w + 1] += eb * 1 / 16;
                        }
                    }
                }
            }
        }
        free(err_r); free(err_g); free(err_b);
    }

    strbuf_append(out, "\033[?25l", 6);
    strbuf_append(out, "\033[H", 3);

    strbuf_appendf(out, "\033Pq\"1;1;%d;%d", target_w, target_h);

    for (int i = 0; i < ncolors; i++) {
        int sr = (int)(palette[i].r * 100 / 255);
        int sg = (int)(palette[i].g * 100 / 255);
        int sb = (int)(palette[i].b * 100 / 255);
        strbuf_appendf(out, "#%d;2;%d;%d;%d", i, sr, sg, sb);
    }

    for (int band = 0; band < target_h; band += 6) {
        int band_h = (band + 6 <= target_h) ? 6 : target_h - band;

        for (int ci = 0; ci < ncolors; ci++) {
            int has_pixels = 0;
            for (int y = band; y < band + band_h && !has_pixels; y++) {
                for (int x = 0; x < target_w && !has_pixels; x++) {
                    if (indexed[y * target_w + x] == ci)
                        has_pixels = 1;
                }
            }
            if (!has_pixels) continue;

            strbuf_appendf(out, "#%d", ci);

            int run_start = 0;
            int run_val = -1;

            for (int x = 0; x <= target_w; x++) {
                int sixel_val = 0;
                if (x < target_w) {
                    for (int dy = 0; dy < band_h; dy++) {
                        int py = band + dy;
                        if (indexed[py * target_w + x] == ci)
                            sixel_val |= (1 << dy);
                    }
                }

                if (x < target_w && sixel_val == run_val) {
                    continue;
                }

                if (run_val >= 0) {
                    int run_len = x - run_start;
                    int ch = run_val + 63;
                    if (run_len >= 4) {
                        strbuf_appendf(out, "!%d%c", run_len, ch);
                    } else {
                        char tmp[4];
                        for (int r = 0; r < run_len; r++) tmp[r] = (char)ch;
                        strbuf_append(out, tmp, run_len);
                    }
                }

                run_start = x;
                run_val = sixel_val;
            }
            strbuf_append(out, "$", 1);
        }
        strbuf_append(out, "-", 1);
    }

    strbuf_append(out, "\033\\", 2);

    free(indexed);
    free(scaled);
}

static PyObject *engine_render_frame(PyObject *self, PyObject *args,
                                      PyObject *kwargs) {
    Py_buffer pixel_buf;
    int src_w, src_h;
    int term_w = -1, term_h = -1;
    int off_x = 0, off_y = 0;
    int border_style = BORDER_NONE;
    int border_r = 255, border_g = 255, border_b = 255;
    int render_mode = RENDER_QUARTER;
    int border_thick = 1;
    int padding = 0;
    double brightness = 1.0;
    double contrast = 1.0;
    double saturation = 1.0;
    int grayscale = 0;
    int invert = 0;

    static char *kwlist[] = {
        "pixels", "width", "height", "term_width", "term_height",
        "offset_x", "offset_y", "border_style",
        "border_r", "border_g", "border_b",
        "render_mode", "border_thick", "padding",
        "brightness", "contrast", "saturation",
        "grayscale", "invert",
        NULL
    };

    if (!PyArg_ParseTupleAndKeywords(args, kwargs,
            "y*ii|iiiiiiiiiiidddii", kwlist,
            &pixel_buf, &src_w, &src_h,
            &term_w, &term_h, &off_x, &off_y,
            &border_style,
            &border_r, &border_g, &border_b,
            &render_mode, &border_thick, &padding,
            &brightness, &contrast, &saturation,
            &grayscale, &invert))
        return NULL;

    if (pixel_buf.len < (Py_ssize_t)(src_w * src_h * 3)) {
        PyBuffer_Release(&pixel_buf);
        PyErr_SetString(PyExc_ValueError, "pixel buffer too small");
        return NULL;
    }

    if (term_w < 0 || term_h < 0) {
#ifdef _WIN32
        CONSOLE_SCREEN_BUFFER_INFO csbi;
        HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
        if (GetConsoleScreenBufferInfo(hOut, &csbi)) {
            if (term_w < 0) term_w = csbi.srWindow.Right - csbi.srWindow.Left + 1;
            if (term_h < 0) term_h = csbi.srWindow.Bottom - csbi.srWindow.Top + 1;
        } else {
            if (term_w < 0) term_w = 80;
            if (term_h < 0) term_h = 24;
        }
#else
        struct winsize ws;
        if (ioctl(STDOUT_FD, TIOCGWINSZ, &ws) == 0) {
            if (term_w < 0) term_w = ws.ws_col;
            if (term_h < 0) term_h = ws.ws_row;
        } else {
            if (term_w < 0) term_w = 80;
            if (term_h < 0) term_h = 24;
        }
#endif
    }

    unsigned char *processed = NULL;
    const unsigned char *src = (const unsigned char *)pixel_buf.buf;

    if (brightness != 1.0 || contrast != 1.0 || saturation != 1.0 ||
        grayscale || invert) {
        int total = src_w * src_h * 3;
        processed = (unsigned char *)malloc(total);
        if (!processed) {
            PyBuffer_Release(&pixel_buf);
            PyErr_NoMemory();
            return NULL;
        }
        memcpy(processed, src, total);

        for (int i = 0; i < src_w * src_h; i++) {
            int idx = i * 3;
            double r = processed[idx];
            double g = processed[idx + 1];
            double b = processed[idx + 2];

            if (saturation != 1.0) {
                double gray = 0.299 * r + 0.587 * g + 0.114 * b;
                r = gray + saturation * (r - gray);
                g = gray + saturation * (g - gray);
                b = gray + saturation * (b - gray);
            }

            if (grayscale) {
                double gray = 0.299 * r + 0.587 * g + 0.114 * b;
                r = g = b = gray;
            }

            if (brightness != 1.0) {
                r *= brightness;
                g *= brightness;
                b *= brightness;
            }

            if (contrast != 1.0) {
                r = 128.0 + contrast * (r - 128.0);
                g = 128.0 + contrast * (g - 128.0);
                b = 128.0 + contrast * (b - 128.0);
            }

            if (invert) {
                r = 255.0 - r;
                g = 255.0 - g;
                b = 255.0 - b;
            }

            processed[idx]     = (unsigned char)clamp_i((int)(r + 0.5), 0, 255);
            processed[idx + 1] = (unsigned char)clamp_i((int)(g + 0.5), 0, 255);
            processed[idx + 2] = (unsigned char)clamp_i((int)(b + 0.5), 0, 255);
        }
        src = processed;
    }

    size_t est_size = (size_t)(term_w * term_h) * 80;
    StrBuf out;
    strbuf_init(&out, est_size);

    Py_BEGIN_ALLOW_THREADS

    if (render_mode == RENDER_SIXEL) {
        int sixel_w = term_w * 8;
        int sixel_h = term_h * 16;
        if (sixel_w > 1920) sixel_w = 1920;
        if (sixel_h > 1080) sixel_h = 1080;

        double src_asp = (double)src_w / (double)src_h;
        double dst_asp = (double)sixel_w / (double)sixel_h;
        int final_w, final_h;
        if (src_asp > dst_asp) {
            final_w = sixel_w;
            final_h = (int)(sixel_w / src_asp);
        } else {
            final_h = sixel_h;
            final_w = (int)(sixel_h * src_asp);
        }
        if (final_w < 1) final_w = 1;
        if (final_h < 1) final_h = 1;

        render_sixel(&out, src, src_w, src_h, final_w, final_h);
    } else if (render_mode == RENDER_QUARTER) {
        render_quarter_block(&out, src, src_w, src_h, term_w, term_h,
                             off_x, off_y, border_style, border_r, border_g, border_b,
                             border_thick, padding);
    } else {
        render_half_block(&out, src, src_w, src_h, term_w, term_h,
                          off_x, off_y, border_style, border_r, border_g, border_b,
                          border_thick, padding);
    }

    Py_END_ALLOW_THREADS

    free(processed);
    PyBuffer_Release(&pixel_buf);

    PyObject *result = PyBytes_FromStringAndSize(out.data, (Py_ssize_t)out.len);
    strbuf_free(&out);
    return result;
}

static PyObject *engine_scale(PyObject *self, PyObject *args) {
    Py_buffer pixel_buf;
    int sw, sh, dw, dh;

    if (!PyArg_ParseTuple(args, "y*iiii", &pixel_buf, &sw, &sh, &dw, &dh))
        return NULL;

    if (pixel_buf.len < (Py_ssize_t)(sw * sh * 3)) {
        PyBuffer_Release(&pixel_buf);
        PyErr_SetString(PyExc_ValueError, "buffer too small");
        return NULL;
    }

    unsigned char *dst;
    Py_BEGIN_ALLOW_THREADS
    dst = scale_pixels((const unsigned char *)pixel_buf.buf, sw, sh, dw, dh);
    Py_END_ALLOW_THREADS

    PyBuffer_Release(&pixel_buf);

    if (!dst) {
        PyErr_NoMemory();
        return NULL;
    }

    PyObject *result = PyBytes_FromStringAndSize((const char *)dst, dw * dh * 3);
    free(dst);
    return result;
}

static PyObject *engine_get_terminal_size(PyObject *self, PyObject *args) {
#ifdef _WIN32
    CONSOLE_SCREEN_BUFFER_INFO csbi;
    HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
    if (GetConsoleScreenBufferInfo(hOut, &csbi)) {
        int cols = csbi.srWindow.Right - csbi.srWindow.Left + 1;
        int rows = csbi.srWindow.Bottom - csbi.srWindow.Top + 1;
        return Py_BuildValue("(ii)", cols, rows);
    }
#else
    struct winsize ws;
    if (ioctl(STDOUT_FD, TIOCGWINSZ, &ws) == 0) {
        return Py_BuildValue("(ii)", ws.ws_col, ws.ws_row);
    }
#endif
    return Py_BuildValue("(ii)", 80, 24);
}

static PyObject *engine_hide_cursor(PyObject *self, PyObject *args) {
    platform_write(STDOUT_FD, "\033[?25l", 6);
    Py_RETURN_NONE;
}

static PyObject *engine_show_cursor(PyObject *self, PyObject *args) {
    platform_write(STDOUT_FD, "\033[?25h", 6);
    Py_RETURN_NONE;
}

static PyObject *engine_clear_screen(PyObject *self, PyObject *args) {
    platform_write(STDOUT_FD, "\033[2J\033[H", 7);
    Py_RETURN_NONE;
}

static PyObject *engine_reset(PyObject *self, PyObject *args) {
    platform_write(STDOUT_FD, "\033[0m\033[?25h\033[2J\033[H", 18);
    Py_RETURN_NONE;
}

static PyObject *engine_flush_frame(PyObject *self, PyObject *args) {
    Py_buffer buf;
    if (!PyArg_ParseTuple(args, "y*", &buf))
        return NULL;
    Py_BEGIN_ALLOW_THREADS
    platform_write(STDOUT_FD, buf.buf, buf.len);
    Py_END_ALLOW_THREADS
    PyBuffer_Release(&buf);
    Py_RETURN_NONE;
}

static PyObject *engine_sleep_precise(PyObject *self, PyObject *args) {
    double seconds;
    if (!PyArg_ParseTuple(args, "d", &seconds))
        return NULL;
    if (seconds <= 0.0) Py_RETURN_NONE;
#ifdef _WIN32
    Py_BEGIN_ALLOW_THREADS
    Sleep((DWORD)(seconds * 1000.0));
    Py_END_ALLOW_THREADS
#else
    struct timespec ts;
    ts.tv_sec = (time_t)seconds;
    ts.tv_nsec = (long)((seconds - (double)ts.tv_sec) * 1e9);
    Py_BEGIN_ALLOW_THREADS
    nanosleep(&ts, NULL);
    Py_END_ALLOW_THREADS
#endif
    Py_RETURN_NONE;
}

static PyObject *engine_enable_ansi(PyObject *self, PyObject *args) {
#ifdef _WIN32
    HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
    DWORD mode = 0;
    GetConsoleMode(hOut, &mode);
    mode |= 0x0004;
    SetConsoleMode(hOut, mode);
    SetConsoleOutputCP(65001);
#endif
    Py_RETURN_NONE;
}

static PyMethodDef engine_methods[] = {
    {"render_frame", (PyCFunction)engine_render_frame, METH_VARARGS | METH_KEYWORDS,
     "Render RGB pixels to terminal with quarter-block or half-block mode."},
    {"scale", engine_scale, METH_VARARGS,
     "Scale RGB pixel buffer using bilinear interpolation."},
    {"get_terminal_size", engine_get_terminal_size, METH_NOARGS,
     "Get terminal dimensions (cols, rows)."},
    {"hide_cursor", engine_hide_cursor, METH_NOARGS, NULL},
    {"show_cursor", engine_show_cursor, METH_NOARGS, NULL},
    {"clear_screen", engine_clear_screen, METH_NOARGS, NULL},
    {"reset", engine_reset, METH_NOARGS, NULL},
    {"flush_frame", engine_flush_frame, METH_VARARGS, NULL},
    {"sleep_precise", engine_sleep_precise, METH_VARARGS, NULL},
    {"enable_ansi", engine_enable_ansi, METH_NOARGS, NULL},
    {NULL, NULL, 0, NULL}
};

static struct PyModuleDef engine_module = {
    PyModuleDef_HEAD_INIT,
    "_engine",
    "termflux native pixel rendering engine with quarter-block HD mode",
    -1,
    engine_methods
};

PyMODINIT_FUNC PyInit__engine(void) {
    PyObject *m = PyModule_Create(&engine_module);
    if (!m) return NULL;
    PyModule_AddIntConstant(m, "BORDER_NONE", BORDER_NONE);
    PyModule_AddIntConstant(m, "BORDER_SINGLE", BORDER_SINGLE);
    PyModule_AddIntConstant(m, "BORDER_DOUBLE", BORDER_DOUBLE);
    PyModule_AddIntConstant(m, "BORDER_BOLD", BORDER_BOLD);
    PyModule_AddIntConstant(m, "BORDER_ROUND", BORDER_ROUND);
    PyModule_AddIntConstant(m, "RENDER_HALF", RENDER_HALF);
    PyModule_AddIntConstant(m, "RENDER_QUARTER", RENDER_QUARTER);
    PyModule_AddIntConstant(m, "RENDER_SIXEL", RENDER_SIXEL);
    return m;
}
