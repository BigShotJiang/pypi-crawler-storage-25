import subprocess
import sys
import os
from setuptools import setup, Extension
from setuptools.command.build_ext import build_ext


def pkg_config(lib, flag):
    try:
        out = subprocess.check_output(
            ["pkg-config", flag, lib],
            stderr=subprocess.DEVNULL,
        )
        return out.decode().strip().split()
    except (subprocess.CalledProcessError, FileNotFoundError):
        return []


def collect_flags(*libs):
    cflags = []
    ldflags = []
    for lib in libs:
        cflags.extend(pkg_config(lib, "--cflags"))
        ldflags.extend(pkg_config(lib, "--libs"))
    include_dirs = [f[2:] for f in cflags if f.startswith("-I")]
    library_dirs = [f[2:] for f in ldflags if f.startswith("-L")]
    libraries = [f[2:] for f in ldflags if f.startswith("-l")]
    extra_compile = [f for f in cflags if not f.startswith("-I")]
    extra_link = [f for f in ldflags if not f.startswith("-L") and not f.startswith("-l")]
    return include_dirs, library_dirs, libraries, extra_compile, extra_link


class OptionalBuildExt(build_ext):
    def build_extension(self, ext):
        try:
            super().build_extension(ext)
        except Exception as e:
            print("WARNING: Failed to build {}: {}".format(ext.name, e))
            print("WARNING: Using pure Python fallback for this extension.")


engine_ext = Extension(
    "termflux._engine",
    sources=["termflux/_engine.c"],
    extra_compile_args=["-O2", "-Wall"] if os.name != "nt" else ["/O2"],
)

av_include, av_libdirs, av_libs, av_cflags, av_ldflags = collect_flags(
    "libavformat", "libavcodec", "libavutil", "libswscale",
)

if not av_libs and os.name != "nt":
    av_libs = ["avformat", "avcodec", "avutil", "swscale"]

decoder_ext = Extension(
    "termflux._decoder",
    sources=["termflux/_decoder.c"],
    include_dirs=av_include,
    library_dirs=av_libdirs,
    libraries=av_libs,
    extra_compile_args=(["-O2", "-Wall"] if os.name != "nt" else ["/O2"]) + av_cflags,
    extra_link_args=av_ldflags,
)

setup(
    ext_modules=[engine_ext, decoder_ext],
    cmdclass={"build_ext": OptionalBuildExt},
)
