# tracine

Infrastructure for safe, observable AI development.

> This is a placeholder release. See [tracine.dev](https://tracine.dev) for details.
>
> **Products:**
> - [tracine-guard](https://pypi.org/project/tracine-guard/) — Security hooks for Claude Code
> - [tracine-convo](https://pypi.org/project/tracine-convo/) — Behavioral analytics CLI for AI sessions
