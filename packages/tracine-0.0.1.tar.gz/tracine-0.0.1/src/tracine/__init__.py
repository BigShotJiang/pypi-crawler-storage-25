"""Infrastructure for safe, observable AI development."""

__version__ = "0.0.1"
