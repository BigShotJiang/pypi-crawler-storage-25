from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any
from urllib.parse import urljoin

import requests


class UPyPiError(Exception):
    pass


class UPyPiNetworkError(UPyPiError):
    pass


class UPyPiResponseError(UPyPiError):
    pass


@dataclass(frozen=True)
class PackageFile:
    target_path: str
    source_path: str
    download_url: str


@dataclass(frozen=True)
class PackageDetails:
    name: str
    version: str
    description: str
    author: str
    package_url: str
    uploaded_at: str | None
    files: list[PackageFile]
    dependencies: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class SearchResult:
    name: str
    package_url: str
    details: PackageDetails | None = None


class UPyPiClient:
    base_url = "https://upypi.net/"

    def __init__(self, timeout: float = 15.0) -> None:
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": "thonny-upypi-manager/0.1.0"})

    def search_packages(self, query: str) -> list[SearchResult]:
        payload = self._get_json(f"{self.base_url}api/search", params={"q": query})
        results = payload.get("results", [])
        search_results: list[SearchResult] = []
        for item in results:
            name = str(item.get("name", "")).strip()
            package_url = str(item.get("url", "")).strip()
            if name and package_url:
                search_results.append(SearchResult(name=name, package_url=package_url))

        return search_results

    def fetch_details(self, package_url: str) -> PackageDetails:
        normalized_url = package_url.rstrip("/") + "/"
        payload = self._get_json(urljoin(normalized_url, "package.json"))
        version = str(payload.get("version", "")).strip() or self._infer_version_from_url(normalized_url)
        name = str(payload.get("name", "")).strip() or self._infer_name_from_url(normalized_url)
        description = str(payload.get("description", "")).strip()
        author = str(payload.get("author", "")).strip() or "Unknown"
        uploaded_at = self._extract_uploaded_at(payload)
        files = self._extract_files(payload, normalized_url)
        dependencies = self._extract_dependencies(payload)
        return PackageDetails(
            name=name,
            version=version,
            description=description,
            author=author,
            package_url=normalized_url.rstrip("/"),
            uploaded_at=uploaded_at,
            files=files,
            dependencies=dependencies,
        )

    def download_file(self, download_url: str, destination: Path) -> None:
        destination.parent.mkdir(parents=True, exist_ok=True)
        data = self._read_bytes(download_url)
        destination.write_bytes(data)

    def _get_json(self, url: str, params: dict[str, str] | None = None) -> dict[str, Any]:
        try:
            raw = self._read_bytes(url, params=params)
        except UPyPiNetworkError:
            raise
        try:
            payload = json.loads(raw.decode("utf-8"))
        except json.JSONDecodeError as exc:
            raise UPyPiResponseError(f"Invalid JSON returned from {url}") from exc

        if not isinstance(payload, dict):
            raise UPyPiResponseError(f"Unexpected JSON payload from {url}")

        return payload

    def _read_bytes(self, url: str, params: dict[str, str] | None = None) -> bytes:
        try:
            response = self.session.get(url, params=params, timeout=self.timeout)
            response.raise_for_status()
            return response.content
        except requests.HTTPError as exc:
            status_code = exc.response.status_code if exc.response is not None else "unknown"
            raise UPyPiNetworkError(f"HTTP error {status_code} for {url}") from exc
        except requests.RequestException as exc:
            raise UPyPiNetworkError(f"Network error for {url}: {exc}") from exc
        except OSError as exc:
            raise UPyPiNetworkError(f"Failed to access {url}: {exc}") from exc

    def _extract_dependencies(self, payload: dict[str, Any]) -> list[str]:
        deps = payload.get("deps", [])
        if not isinstance(deps, list):
            return []
        result = []
        for item in deps:
            if isinstance(item, list) and item:
                url = str(item[0]).strip()
                if url:
                    result.append(url)
        return result

    def _extract_files(self, payload: dict[str, Any], package_url: str) -> list[PackageFile]:
        urls = payload.get("urls", [])
        files: list[PackageFile] = []
        if not isinstance(urls, list):
            return files

        for item in urls:
            if not isinstance(item, list) or len(item) != 2:
                continue
            target_path = str(item[0]).strip().lstrip("/")
            source_path = str(item[1]).strip().lstrip("/")
            if not target_path or not source_path:
                continue
            files.append(
                PackageFile(
                    target_path=target_path,
                    source_path=source_path,
                    download_url=urljoin(package_url, source_path),
                )
            )

        return files

    def _extract_uploaded_at(self, payload: dict[str, Any]) -> str | None:
        for key in ("uploaded_at", "upload_time", "created_at", "updated_at"):
            value = payload.get(key)
            if value:
                return str(value)
        return None

    def _infer_name_from_url(self, package_url: str) -> str:
        parts = [part for part in package_url.split("/") if part]
        if len(parts) >= 2:
            return parts[-2]
        return package_url

    def _infer_version_from_url(self, package_url: str) -> str:
        parts = [part for part in package_url.split("/") if part]
        if parts:
            return parts[-1]
        return "Unknown"
