from __future__ import annotations

from datetime import datetime
from pathlib import Path
import threading
import time
import tkinter as tk
import tkinter.font as tkfont
from tkinter import messagebox, ttk

from .client import PackageDetails, SearchResult, UPyPiClient, UPyPiError, UPyPiNetworkError
from .installer import DeviceInfo, DownloadedPackage, InstallError, PackageInstaller

VIEW_LABEL = "uPyPi Package Manager"
VIEW_LOCATION = "ne"
VIEW_ID = "UPyPiManagerView"
TOOLBAR_ICON_PATH = str(Path(__file__).resolve().with_name("icon.png"))


class UPyPiManagerView(ttk.Frame):
    def __init__(self, master: tk.Misc) -> None:
        super().__init__(master)
        self.client = UPyPiClient()
        self.installer = PackageInstaller(self.client)
        self.results_by_item: dict[str, SearchResult] = {}
        self.download_cache: dict[str, DownloadedPackage] = {}
        self.devices_by_label: dict[str, DeviceInfo] = {}
        self._busy = False

        self._build_ui()

    def focus_search(self) -> None:
        self.search_entry.focus_set()

    def _build_ui(self) -> None:
        self._configure_styles()
        self.columnconfigure(0, weight=1)
        self.rowconfigure(2, weight=1)

        controls_frame = ttk.Frame(self)
        controls_frame.grid(row=0, column=0, columnspan=2, sticky="ew", padx=8, pady=(8, 4))
        controls_frame.columnconfigure(0, weight=1)

        self.search_var = tk.StringVar()

        search_entry_frame = tk.Frame(
            controls_frame,
            background="#c8c8c8",
            highlightthickness=0,
            borderwidth=0,
        )
        search_entry_frame.grid(row=0, column=0, sticky="ew")
        search_entry_frame.columnconfigure(1, weight=1)

        self.search_entry_pad = tk.Label(search_entry_frame, text="", background="#ffffff", width=0)
        self.search_entry_pad.grid(
            row=0, column=0, sticky="nsw", padx=(1, 0), pady=1
        )

        self.search_entry = tk.Entry(
            search_entry_frame,
            textvariable=self.search_var,
            font=self.search_font,
            bg="#ffffff",
            fg="#000000",
            relief="flat",
            borderwidth=0,
            highlightthickness=0,
            insertbackground="#000000",
            selectbackground="#000000",
            selectforeground="#ffffff",
        )
        self.search_entry.grid(row=0, column=1, sticky="ew", padx=(0, 1), pady=1, ipady=5)
        self.search_entry.bind("<Return>", self._on_search)
        self._search_entry_normal_bg = "#ffffff"
        self._search_entry_busy_bg = "#f2f2f2"
        self._search_entry_disabled_fg = "#6f6f6f"

        self.search_button = ttk.Button(
            controls_frame,
            text="Search",
            style="UPyPi.TButton",
            width=16,
            command=self._on_search,
        )
        self.search_button.grid(row=0, column=1, padx=(6, 0))

        self.device_var = tk.StringVar()
        self.device_combo = ttk.Combobox(
            controls_frame,
            textvariable=self.device_var,
            state="readonly",
            values=[],
        )
        self.device_combo.grid(row=1, column=0, sticky="ew", pady=(6, 0))
        self.device_combo.bind("<<ComboboxSelected>>", self._on_device_selected)

        self.refresh_devices_button = ttk.Button(
            controls_frame,
            text="Refresh Boards",
            style="UPyPi.TButton",
            width=16,
            command=self._refresh_devices,
        )
        self.refresh_devices_button.grid(row=1, column=1, padx=(6, 0), pady=(6, 0))

        columns = ("name", "version", "author", "description")
        self.results_tree = ttk.Treeview(self, columns=columns, show="headings", height=12)
        self.results_tree.grid(row=2, column=0, sticky="nsew", padx=8, pady=4)
        self.results_tree.bind("<<TreeviewSelect>>", self._on_select)
        self.results_tree.heading("name", text="Package")
        self.results_tree.heading("version", text="Version")
        self.results_tree.heading("author", text="Author")
        self.results_tree.heading("description", text="Description")
        self.results_tree.column("name", width=180, anchor="w")
        self.results_tree.column("version", width=90, anchor="w")
        self.results_tree.column("author", width=120, anchor="w")
        self.results_tree.column("description", width=380, anchor="w")

        scrollbar = ttk.Scrollbar(self, orient="vertical", command=self.results_tree.yview)
        scrollbar.grid(row=2, column=1, sticky="ns", pady=4)
        self.results_tree.configure(yscrollcommand=scrollbar.set)

        actions = ttk.Frame(self)
        actions.grid(row=3, column=0, sticky="ew", padx=8, pady=(4, 18))
        for column in range(4):
            actions.columnconfigure(column, weight=1, uniform="action")

        self.download_button = ttk.Button(
            actions,
            text="Download Package",
            style="UPyPi.TButton",
            command=self._download_selected,
        )
        self.download_button.grid(row=0, column=0, sticky="ew", padx=(0, 6))

        self.install_button = ttk.Button(
            actions,
            text="Install To Device",
            style="UPyPi.TButton",
            command=self._install_selected,
        )
        self.install_button.grid(row=0, column=1, sticky="ew", padx=(0, 6))

        self.refresh_button = ttk.Button(
            actions,
            text="Refresh Details",
            style="UPyPi.TButton",
            command=self._refresh_selected,
        )
        self.refresh_button.grid(row=0, column=2, sticky="ew", padx=(0, 6))

        self.clear_log_button = ttk.Button(
            actions,
            text="Clear Log",
            style="UPyPi.TButton",
            command=self._clear_log,
        )
        self.clear_log_button.grid(row=0, column=3, sticky="ew")

        log_header = ttk.Frame(self)
        log_header.grid(row=4, column=0, columnspan=2, sticky="ew", padx=8, pady=(0, 4))
        ttk.Label(log_header, text="Log").grid(row=0, column=0, sticky="w")

        log_frame = tk.Frame(
            self,
            background="#c8c8c8",
            highlightthickness=0,
            borderwidth=0,
        )
        log_frame.grid(row=5, column=0, columnspan=2, sticky="nsew", padx=8, pady=(0, 8))
        log_frame.columnconfigure(0, weight=1)
        log_frame.rowconfigure(0, weight=1)
        self.rowconfigure(5, weight=1)

        self.log_text = tk.Text(
            log_frame,
            height=10,
            wrap="word",
            relief="flat",
            borderwidth=0,
            highlightthickness=0,
            padx=6,
            pady=6,
            bg="#ffffff",
            fg="#1f1f1f",
            insertwidth=0,
            selectbackground="#cccccc",
            selectforeground="#1f1f1f",
        )
        self.log_text.grid(row=0, column=0, sticky="nsew", padx=1, pady=1)
        self.log_text.bind("<Key>", self._handle_log_keypress)
        self.log_text.bind("<<Paste>>", lambda event: "break")
        self.log_text.bind("<<Cut>>", lambda event: "break")
        self.log_text.bind("<Button-1>", self._sync_log_selection_style)
        self.log_text.bind("<B1-Motion>", self._sync_log_selection_style)
        self.log_text.bind("<ButtonRelease-1>", self._sync_log_selection_style)
        self.log_text.bind("<KeyRelease>", self._sync_log_selection_style)
        self.log_text.bind("<FocusIn>", self._sync_log_selection_style)
        self.log_text.tag_configure("header", foreground="#0f3d75")
        self.log_text.tag_configure("info", foreground="#1f1f1f")
        self.log_text.tag_configure("success", foreground="#1f7a1f")
        self.log_text.tag_configure("error", foreground="#a12626")
        self.log_text.tag_configure("command", foreground="#666666")
        self.log_text.tag_configure("selected_text", foreground="#1f1f1f")
        log_scrollbar = ttk.Scrollbar(log_frame, orient="vertical", command=self.log_text.yview)
        log_scrollbar.grid(row=0, column=1, sticky="ns")
        self.log_text.configure(yscrollcommand=log_scrollbar.set)

        self._refresh_devices(initial=True)
        self._update_action_state()

    def _on_search(self, event: tk.Event[tk.Misc] | None = None) -> None:
        query = self.search_var.get().strip()
        if not query or self._busy:
            return

        self._set_busy(True, "Searching...")
        self._clear_results()
        self._log_section(f"Search: {query}")

        def worker() -> None:
            try:
                search_results = self.client.search_packages(query)
                enriched_results: list[SearchResult] = []
                for result in search_results:
                    detail_started = time.perf_counter()
                    try:
                        details = self.client.fetch_details(result.package_url)
                        detail_elapsed = time.perf_counter() - detail_started
                        enriched_results.append(
                            SearchResult(name=result.name, package_url=result.package_url, details=details)
                        )
                        self._call_in_ui_thread(
                            self._log,
                            f"Fetched details for {result.name} in {detail_elapsed:.2f}s.",
                        )
                    except UPyPiError as exc:
                        detail_elapsed = time.perf_counter() - detail_started
                        enriched_results.append(result)
                        self._call_in_ui_thread(
                            self._log,
                            f"Skipping detail fetch for {result.name} after {detail_elapsed:.2f}s: {exc}",
                        )

                self._call_in_ui_thread(self._show_results, enriched_results)
            except UPyPiNetworkError:
                self._call_in_ui_thread(
                    self._handle_error,
                    "Search failed",
                    "Please check your network and try again.",
                )
            except UPyPiError as exc:
                self._call_in_ui_thread(self._handle_error, "Search failed", str(exc))
            finally:
                self._call_in_ui_thread(self._set_busy, False, "Search complete.")

        threading.Thread(target=worker, daemon=True).start()

    def _show_results(self, results: list[SearchResult]) -> None:
        if not results:
            self._log("No matching packages found. Please try other keywords.")
            return

        count = len(results)
        noun = "package" if count == 1 else "packages"
        self._log(f"Found {count} {noun}.")
        for result in results:
            details = result.details
            values = (
                result.name,
                details.version if details else "Unknown",
                details.author if details else "Unknown",
                self._format_description(details.description if details else ""),
            )
            item_id = self.results_tree.insert("", "end", values=values)
            self.results_by_item[item_id] = result

        first = self.results_tree.get_children()
        if first:
            self.results_tree.selection_set(first[0])

    def _download_selected(self) -> None:
        result = self._get_selected_result()
        if result is None or self._busy:
            return

        details = self._ensure_details(result)
        if details is None:
            return

        self._set_busy(True, f"Downloading {details.name}...")
        self._log_section(f"Download: {details.name} {details.version}")

        def worker() -> None:
            try:
                package = self.installer.download_package(details, log=self._thread_safe_log)
                self.download_cache[self._cache_key(details)] = package
                self._call_in_ui_thread(
                    self._log,
                    f"Downloaded {details.name} {details.version} to local cache: {package.root_dir}",
                    "success",
                )
            except (InstallError, UPyPiError) as exc:
                self._call_in_ui_thread(self._handle_error, "Download failed", str(exc))
            finally:
                self._call_in_ui_thread(self._set_busy, False, "Ready.")

        threading.Thread(target=worker, daemon=True).start()

    def _install_selected(self) -> None:
        result = self._get_selected_result()
        if result is None or self._busy:
            return

        details = self._ensure_details(result)
        if details is None:
            return

        self._set_busy(True, f"Installing {details.name} to device...")
        self._log_section(f"Install: {details.name} {details.version}")

        def worker() -> None:
            try:
                selected_device = self._get_selected_device()
                if selected_device is None:
                    self._call_in_ui_thread(self._refresh_devices, False, True)
                    raise InstallError("Board not detected. Please reconnect your device and try again.")

                devices = self.installer.list_devices()
                if not any(device.port == selected_device.port for device in devices):
                    self._call_in_ui_thread(self._refresh_devices, False, True)
                    raise InstallError("Board not detected. Please reconnect your device and try again.")

                package = self.download_cache.get(self._cache_key(details))
                if package is None:
                    self._thread_safe_log("Package not in cache, downloading first.")
                    package = self.installer.download_package(details, log=self._thread_safe_log)
                    self.download_cache[self._cache_key(details)] = package

                # install dependencies first, then main package
                for dep_url in details.dependencies:
                    self._thread_safe_log(f"Installing dependency: {dep_url}")
                    dep_details = self.installer.client.fetch_details(dep_url)
                    dep_package = self.installer.download_package(dep_details, log=self._thread_safe_log)
                    self.installer.install_downloaded_package(dep_package, device_port=selected_device.port, log=self._thread_safe_log)

                self.installer.install_downloaded_package(
                    package,
                    device_port=selected_device.port,
                    log=self._thread_safe_log,
                )
                self._call_in_ui_thread(
                    self._log,
                    f"Installed {details.name} {details.version} to /lib on the device.",
                    "success",
                )
            except (InstallError, UPyPiError) as exc:
                self._call_in_ui_thread(self._handle_error, "Install failed", str(exc))
            finally:
                self._call_in_ui_thread(self._set_busy, False, "Ready.")

        threading.Thread(target=worker, daemon=True).start()

    def _refresh_selected(self) -> None:
        result = self._get_selected_result()
        if result is None or self._busy:
            return

        self._set_busy(True, f"Refreshing {result.name}...")
        self._log_section(f"Refresh: {result.name}")

        def worker() -> None:
            try:
                details = self.client.fetch_details(result.package_url)
                refreshed = SearchResult(name=result.name, package_url=result.package_url, details=details)
                self._call_in_ui_thread(self._replace_selected_result, refreshed)
            except UPyPiError as exc:
                self._call_in_ui_thread(self._handle_error, "Refresh failed", str(exc))
            finally:
                self._call_in_ui_thread(self._set_busy, False, "Ready.")

        threading.Thread(target=worker, daemon=True).start()

    def _replace_selected_result(self, refreshed: SearchResult) -> None:
        selection = self.results_tree.selection()
        if not selection:
            return

        item_id = selection[0]
        self.results_by_item[item_id] = refreshed
        details = refreshed.details
        self.results_tree.item(
            item_id,
            values=(
                refreshed.name,
                details.version if details else "Unknown",
                details.author if details else "Unknown",
                self._format_description(details.description if details else ""),
            ),
        )
        self._log(f"Refreshed metadata for {refreshed.name}.", "success")

    def _on_select(self, event: tk.Event[tk.Misc] | None = None) -> None:
        self._update_action_state()

    def _on_device_selected(self, event: tk.Event[tk.Misc] | None = None) -> None:
        self._update_action_state()

    def _update_action_state(self) -> None:
        selected = self._get_selected_result() is not None
        has_device = self._get_selected_device() is not None
        state = "disabled" if self._busy or not selected else "normal"
        self.download_button.config(state=state)
        self.install_button.config(state="disabled" if self._busy or not selected or not has_device else "normal")
        self.refresh_button.config(state=state)
        self.clear_log_button.config(state="disabled" if self._busy else "normal")
        self.search_button.config(state="disabled" if self._busy else "normal")
        self.refresh_devices_button.config(state="disabled" if self._busy else "normal")
        self.device_combo.config(state="disabled" if self._busy else "readonly")

    def _set_busy(self, busy: bool, status_text: str) -> None:
        self._busy = busy
        self.search_button.config(text="Searching..." if busy else "Search")
        self.search_entry.config(
            state="normal",
            bg=self._search_entry_busy_bg if busy else self._search_entry_normal_bg,
            disabledbackground=self._search_entry_busy_bg,
            fg=self._search_entry_disabled_fg if busy else "#000000",
            disabledforeground=self._search_entry_disabled_fg,
        )
        self.search_entry_pad.config(
            background=self._search_entry_busy_bg if busy else self._search_entry_normal_bg
        )
        self._update_action_state()

    def _handle_error(self, title: str, message: str) -> None:
        self._log_section(title)
        self._log(f"{title}: {message}", "error")
        messagebox.showerror(title, message)

    def _clear_results(self) -> None:
        self.results_by_item.clear()
        for item_id in self.results_tree.get_children():
            self.results_tree.delete(item_id)
        self._update_action_state()

    def _get_selected_result(self) -> SearchResult | None:
        selection = self.results_tree.selection()
        if not selection:
            return None
        return self.results_by_item.get(selection[0])

    def _get_selected_device(self) -> DeviceInfo | None:
        return self.devices_by_label.get(self.device_var.get().strip())

    def _refresh_devices(self, initial: bool = False, report_missing: bool = False) -> None:
        previous_port = self._get_selected_device().port if self._get_selected_device() else None
        try:
            devices = self.installer.list_devices()
        except InstallError as exc:
            if not initial:
                self._handle_error("Board refresh failed", str(exc))
            return

        self.devices_by_label = {device.label: device for device in devices}
        labels = list(self.devices_by_label.keys())
        self.device_combo["values"] = labels

        selected_label = ""
        if previous_port:
            for device in devices:
                if device.port == previous_port:
                    selected_label = device.label
                    break
        if not selected_label and labels:
            selected_label = labels[0]

        self.device_var.set(selected_label)
        if report_missing and not labels:
            self._log("Board not detected. Please reconnect your device and try again.", "error")

        self._update_action_state()

    def _ensure_details(self, result: SearchResult) -> PackageDetails | None:
        if result.details is not None:
            return result.details

        try:
            details = self.client.fetch_details(result.package_url)
        except UPyPiError as exc:
            self._handle_error("Metadata unavailable", str(exc))
            return None

        selection = self.results_tree.selection()
        if selection:
            self.results_by_item[selection[0]] = SearchResult(
                name=result.name,
                package_url=result.package_url,
                details=details,
            )
        return details

    def _thread_safe_log(self, message: str) -> None:
        level = "command" if message.startswith("$ ") else "info"
        self._call_in_ui_thread(self._log, message, level)

    def _log(self, message: str, level: str = "info") -> None:
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.log_text.insert("end", f"[{timestamp}] {message}\n", (level,))
        self.log_text.see("end")
        self._sync_log_selection_style()

    def _clear_log(self) -> None:
        self.log_text.delete("1.0", "end")
        self._sync_log_selection_style()

    def _log_section(self, title: str) -> None:
        timestamp = datetime.now().strftime("%H:%M:%S")
        if self.log_text.index("end-1c") != "1.0":
            self.log_text.insert("end", "\n")
        self.log_text.insert("end", f"[{timestamp}] {title}\n", ("header",))
        self.log_text.see("end")
        self._sync_log_selection_style()

    def _sync_log_selection_style(self, event: tk.Event[tk.Misc] | None = None) -> None:
        self.log_text.tag_remove("selected_text", "1.0", "end")
        try:
            start = self.log_text.index("sel.first")
            end = self.log_text.index("sel.last")
        except tk.TclError:
            return
        self.log_text.tag_add("selected_text", start, end)

    def _handle_log_keypress(self, event: tk.Event[tk.Misc]) -> str | None:
        # Keep the log read-only, but allow normal copy/select-all shortcuts.
        state = getattr(event, "state", 0)
        command_pressed = bool(state & 0x0008) or bool(state & 0x0004)
        keysym = (event.keysym or "").lower()
        char = (event.char or "").lower()

        if command_pressed and (keysym in {"c", "a"} or char in {"c", "a"}):
            return None

        navigation_keys = {
            "left",
            "right",
            "up",
            "down",
            "home",
            "end",
            "prior",
            "next",
            "shift_l",
            "shift_r",
            "command",
            "meta_l",
            "meta_r",
            "alt_l",
            "alt_r",
            "control_l",
            "control_r",
        }
        if keysym in navigation_keys:
            return None

        return "break"

    def _call_in_ui_thread(self, callback, *args) -> None:
        self.after(0, lambda: callback(*args))

    def _format_description(self, description: str) -> str:
        text = description.strip() or "No description available."
        if len(text) > 90:
            return text[:87] + "..."
        return text


    def _cache_key(self, details: PackageDetails) -> str:
        return f"{details.name}@{details.version}"

    def _configure_styles(self) -> None:
        self.search_font = tkfont.nametofont("TkDefaultFont").copy()
        self.search_font.configure(size=13)

        style = ttk.Style(self)
        style.configure("UPyPi.TButton", padding=(10, 6))
        style.map(
            "Treeview",
            background=[("selected", "#000000")],
            foreground=[("selected", "#ffffff")],
        )


def load_plugin() -> None:
    from thonny import get_workbench

    workbench = get_workbench()
    _register_view(workbench)

    def open_manager() -> None:
        _show_manager(workbench)

    def toggle_manager() -> None:
        _toggle_manager(workbench)

    workbench.add_command(
        command_id="open_upypi_manager",
        menu_name="tools",
        command_label=VIEW_LABEL,
        handler=toggle_manager,
        image=TOOLBAR_ICON_PATH,
        caption="uPyPi",
        alternative_caption="Hide uPyPi",
        include_in_toolbar=True,
    )

    workbench.add_command(
        command_id="toggle_upypi_manager",
        menu_name="view",
        command_label=f"Toggle {VIEW_LABEL}",
        handler=toggle_manager,
    )


def _register_view(workbench: object) -> None:
    add_view = getattr(workbench, "add_view", None)
    if add_view is None:
        return

    signatures = [
        (UPyPiManagerView, VIEW_LABEL, VIEW_LOCATION),
        (UPyPiManagerView, VIEW_LABEL),
    ]
    for args in signatures:
        try:
            add_view(*args)
            return
        except TypeError:
            continue
        except Exception:
            return


def _open_fallback_window(workbench: object) -> None:
    existing = getattr(workbench, "_upypi_manager_window", None)
    if existing is not None and existing.winfo_exists():
        existing.deiconify()
        existing.lift()
        existing.focus_force()
        return

    root = getattr(workbench, "winfo_toplevel", lambda: workbench)()
    window = tk.Toplevel(root)
    window.title(VIEW_LABEL)
    window.geometry("900x600")
    setattr(workbench, "_upypi_manager_window", window)
    frame = UPyPiManagerView(window)
    frame.pack(fill="both", expand=True)
    frame.focus_search()


def _show_manager(workbench: object) -> None:
    try:
        workbench.show_view(VIEW_ID)
    except Exception:
        _open_fallback_window(workbench)


def _toggle_manager(workbench: object) -> None:
    if _toggle_registered_view(workbench):
        return

    existing = getattr(workbench, "_upypi_manager_window", None)
    if existing is not None and existing.winfo_exists():
        if str(existing.state()) == "withdrawn":
            existing.deiconify()
            existing.lift()
            existing.focus_force()
        else:
            existing.withdraw()
        return

    _open_fallback_window(workbench)


def _toggle_registered_view(workbench: object) -> bool:
    get_view = getattr(workbench, "get_view", None)
    hide_view = getattr(workbench, "hide_view", None)
    show_view = getattr(workbench, "show_view", None)
    if get_view is None or hide_view is None or show_view is None:
        return False

    try:
        view = get_view(VIEW_ID, False)
    except Exception:
        try:
            show_view(VIEW_ID)
            return True
        except Exception:
            return False

    if getattr(view, "hidden", False):
        show_view(VIEW_ID)
    else:
        hide_view(VIEW_ID)

    return True
