def load_plugin() -> None:
    from .plugin import load_plugin as _load_plugin

    _load_plugin()


__all__ = ["load_plugin"]
