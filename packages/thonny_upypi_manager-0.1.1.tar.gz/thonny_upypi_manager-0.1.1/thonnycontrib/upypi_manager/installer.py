from __future__ import annotations

import os
import shutil
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Callable

from .client import PackageDetails, UPyPiClient


class InstallError(Exception):
    pass


LogFn = Callable[[str], None]


@dataclass(frozen=True)
class DeviceInfo:
    port: str
    label: str


@dataclass(frozen=True)
class DownloadedPackage:
    details: PackageDetails
    root_dir: Path
    files: list[Path]


class PackageInstaller:
    MPREMOTE_REQUIRED_MESSAGE = (
        "Installing packages to a board requires mpremote, but it was not found on your system PATH. "
        "Install mpremote and try again. See "
        "https://docs.micropython.org/en/latest/reference/mpremote.html"
    )

    def __init__(self, client: UPyPiClient | None = None, mpremote_cmd: str = "mpremote") -> None:
        self.client = client or UPyPiClient()
        self.mpremote_cmd = mpremote_cmd

    def _resolve_mpremote_cmd(self) -> str:
        candidates = [
            self.mpremote_cmd,
            str(Path.home() / ".local" / "bin" / "mpremote"),
            "/opt/homebrew/bin/mpremote",
            "/usr/local/bin/mpremote",
        ]

        for candidate in candidates:
            if os.path.sep in candidate:
                if Path(candidate).exists():
                    return candidate
            else:
                resolved = shutil.which(candidate)
                if resolved:
                    return resolved

        return self.mpremote_cmd

    def download_package(
        self,
        details: PackageDetails,
        log: LogFn | None = None,
        cache_root: Path | None = None,
    ) -> DownloadedPackage:
        root_base = cache_root or Path(tempfile.gettempdir()) / "thonny-upypi-manager"
        package_root = root_base / details.name / details.version
        package_root.mkdir(parents=True, exist_ok=True)
        downloaded_files: list[Path] = []

        if not details.files:
            raise InstallError("Package metadata does not contain any downloadable files.")

        for package_file in details.files:
            local_path = package_root / package_file.target_path
            if log:
                log(f"Downloading {package_file.target_path}")
            self.client.download_file(package_file.download_url, local_path)
            downloaded_files.append(local_path)

        return DownloadedPackage(details=details, root_dir=package_root, files=downloaded_files)

    def list_devices(self, log: LogFn | None = None) -> list[DeviceInfo]:
        self.ensure_mpremote_available()
        output = self._run_mpremote(["devs"], log=log, capture=True)
        devices: list[DeviceInfo] = []
        for raw_line in output.splitlines():
            line = raw_line.strip()
            if not line or not (line.startswith("/dev/") or line.upper().startswith("COM")):
                continue
            parts = line.split()
            port = parts[0]
            label_parts = parts[1:]
            if label_parts and label_parts[-1] == "None":
                label_parts = label_parts[:-1]
            label = " ".join(label_parts).strip() or port
            devices.append(DeviceInfo(port=port, label=f"{label} ({port})"))

        filtered = [
            device
            for device in devices
            if "bluetooth" not in device.port.lower()
            and "debug-console" not in device.port.lower()
            and device.label.split(" (", 1)[0].strip().lower() not in {"none", ""}
        ]

        preferred = filtered or [
            device
            for device in devices
            if "bluetooth" not in device.port.lower() and "debug-console" not in device.port.lower()
        ]

        return sorted(
            preferred or devices,
            key=lambda device: (
                "usbmodem" not in device.port.lower() and not device.port.upper().startswith("COM"),
                "espressif" not in device.label.lower() and "micropython" not in device.label.lower(),
                device.port.lower(),
            ),
        )

    def install_downloaded_package(
        self,
        package: DownloadedPackage,
        device_port: str,
        log: LogFn | None = None,
    ) -> None:
        self.ensure_mpremote_available()
        self._run_mpremote(
            ["connect", device_port, "fs", "mkdir", "/lib"],
            log,
            ignore_errors_containing=("file exists",),
        )

        for local_path in package.files:
            relative_path = local_path.relative_to(package.root_dir)
            remote_path = PurePosixPath("/lib") / PurePosixPath(relative_path.as_posix())
            parent_dir = remote_path.parent

            if str(parent_dir) != "/lib":
                self._run_mpremote(
                    ["connect", device_port, "fs", "mkdir", str(parent_dir)],
                    log,
                    ignore_errors_containing=("file exists",),
                )

            self._run_mpremote(
                ["connect", device_port, "fs", "cp", str(local_path), f":{remote_path}"],
                log,
            )

    def download_and_install(
        self,
        details: PackageDetails,
        device_port: str,
        log: LogFn | None = None,
        cache_root: Path | None = None,
        _installed: set[str] | None = None,
    ) -> DownloadedPackage:
        if _installed is None:
            _installed = set()
        if details.name in _installed:
            return None
        _installed.add(details.name)

        for dep_url in details.dependencies:
            if log:
                log(f"Installing dependency: {dep_url}")
            dep_details = self.client.fetch_details(dep_url)
            self.download_and_install(dep_details, device_port, log=log, cache_root=cache_root, _installed=_installed)

        package = self.download_package(details, log=log, cache_root=cache_root)
        self.install_downloaded_package(package, device_port=device_port, log=log)
        return package

    def ensure_ready_for_install(self, log: LogFn | None = None) -> None:
        self.ensure_mpremote_available()
 
    def ensure_mpremote_available(self) -> None:
        resolved = self._resolve_mpremote_cmd()
        if resolved == self.mpremote_cmd and shutil.which(self.mpremote_cmd) is None:
            raise InstallError(self.MPREMOTE_REQUIRED_MESSAGE)
        self.mpremote_cmd = resolved

    def _run_mpremote(
        self,
        args: list[str],
        log: LogFn | None = None,
        capture: bool = False,
        ignore_errors_containing: tuple[str, ...] = (),
    ) -> str:
        command = [self.mpremote_cmd, *args]
        if log:
            log("$ " + " ".join(command))

        try:
            process = subprocess.run(
                command,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                check=False,
            )
        except OSError as exc:
            raise InstallError(f"Failed to start mpremote: {exc}") from exc

        output_lines = [line.rstrip() for line in process.stdout.splitlines()]
        return_code = process.returncode
        if return_code != 0:
            joined = "\n".join(output_lines).strip()
            normalized = joined.lower()
            if ignore_errors_containing and any(token.lower() in normalized for token in ignore_errors_containing):
                return joined if capture else ""
            if "could not enter raw repl" in normalized:
                raise InstallError(
                    "Could not access the board via raw REPL. Close other connections to the device, "
                    "restart the board, and try again."
                )
            for cleaned in output_lines:
                if cleaned and log:
                    log(cleaned)
            if joined:
                raise InstallError(joined)
            raise InstallError(f"mpremote exited with status {return_code}")

        for cleaned in output_lines:
            if cleaned and log:
                log(cleaned)

        return "\n".join(output_lines).strip() if capture else ""
