"""
MundiX CLI - AI Provider v2.0 (Compatibility Wrapper)
Now uses src.ai.mundix_provider for the MundiXAIProvider class.
Keeps all module-level variables and functions for backward compatibility.
"""

import os
import time
import sys
import json
import hashlib
import uuid
import platform
import socket
import requests
from pathlib import Path

# Import the main class from the new module
from src.ai.mundix_provider import MundiXAIProvider as AIProvider

# Re-export from the new module
from src.ai.mundix_provider import (
    MODELS,
    DEFAULT_MODEL,
    FALLBACK_ORDER,
    BACKEND_URL,
    TIER_MODELS,
)

# ─── Configuration ──────────────────────────────────────────

CONFIG_DIR = Path.home() / ".mundix"
CONFIG_FILE = CONFIG_DIR / "config.json"
BACKEND_URL = os.environ.get("MUNDIX_BACKEND_URL", "https://chat.mundix.dev/api")

# ─── Model Registry (Public Codenames Only) ─────────────────

MODELS = {
    # ── T1 — Brain (planning, analysis, skill decisions) ──
    "mx-strategist-72b": {
        "name": "MX-Strategist 72B",
        "description": "Strategic planner — pentest orchestration & deep analysis (72B)",
        "context_length": 131072,
        "tier": "brain",
    },
    # ── T2 — Specialist (commands, exploits, interpretation) ──
    "mx-deephat-7b": {
        "name": "MX-DeepHat 7B",
        "description": "Offensive specialist — exploit generation & attack chains (7.6B)",
        "context_length": 131072,
        "tier": "specialist",
    },
    # ── T3 — Executor (quick parsing, simple decisions) ──
    "mx-swift-3b": {
        "name": "MX-Swift 3B",
        "description": "Fast executor — parsing, formatting & quick decisions (3B)",
        "context_length": 32768,
        "tier": "executor",
    },
    # ── Backup ──
    "mx-minitron-8b": {
        "name": "MX-Minitron 8B",
        "description": "Backup — 92% Red Team Benchmark, zero censorship (8B)",
        "context_length": 8192,
        "tier": "backup",
    },
    # ── Legacy models (backward compatible) ──
    "mx-redhawk-7b": {
        "name": "MX-RedHawk 7B",
        "description": "Offensive pentest specialist — legacy alias for DeepHat",
        "context_length": 131072,
        "tier": "specialist",
    },
    "mx-phantom-7b": {
        "name": "MX-Phantom 7B",
        "description": "Advanced offensive/defensive — red & blue team operations",
        "context_length": 32768,
        "tier": "specialist",
    },
    "mx-spectre-7b": {
        "name": "MX-Spectre 7B",
        "description": "General cybersecurity — vulnerability analysis & hardening",
        "context_length": 32768,
        "tier": "specialist",
    },
    "mx-venom-8b": {
        "name": "MX-Venom 8B",
        "description": "Security assistant — recon, OSINT & threat intelligence",
        "context_length": 8192,
        "tier": "backup",
    },
    "mx-cipher-7b": {
        "name": "MX-Cipher 7B",
        "description": "Code analysis & scripting — exploit dev & automation",
        "context_length": 131072,
        "tier": "executor",
    },
}

# Tier-to-model mapping for automatic selection
TIER_MODELS = {
    "brain": "mx-strategist-72b",
    "specialist": "mx-deephat-7b",
    "executor": "mx-swift-3b",
    "backup": "mx-minitron-8b",
}

FALLBACK_ORDER = [
    "mx-deephat-7b", "mx-strategist-72b", "mx-minitron-8b", "mx-swift-3b",
    "mx-redhawk-7b", "mx-phantom-7b", "mx-spectre-7b", "mx-venom-8b", "mx-cipher-7b",
]

DEFAULT_MODEL = "mx-deephat-7b"

# ─── Config Management ──────────────────────────────────────────

def get_machine_id() -> str:
    """Generate a unique machine ID for identification."""
    parts = [
        platform.node(),
        platform.machine(),
        platform.system(),
        str(uuid.getnode()),  # MAC address
    ]
    raw = "|".join(parts)
    return hashlib.sha256(raw.encode()).hexdigest()[:32]


def get_device_info() -> dict:
    """Gather device info for auto-registration."""
    try:
        hostname = socket.gethostname()
    except Exception:
        hostname = platform.node()

    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip_address = s.getsockname()[0]
        s.close()
    except Exception:
        ip_address = "unknown"

    os_info = f"{platform.system()} {platform.release()} {platform.machine()}"

    return {
        "machine_id": get_machine_id(),
        "ip_address": ip_address,
        "hostname": hostname,
        "os_info": os_info,
    }


def load_config() -> dict:
    """Load config from ~/.mundix/config.json"""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE) as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            pass
    return {}


def save_config(config: dict):
    """Save config to ~/.mundix/config.json"""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=2)


# ─── Device Auto-Registration ──────────────────────────────────────

def auto_register_device() -> dict:
    """Auto-register this device on first run. Zero friction."""
    config = load_config()

    # If already has api_key, just return it
    if config.get("api_key"):
        return {
            "api_key": config["api_key"],
            "status": config.get("status", "unknown"),
            "credits": config.get("credits", 0),
            "total_queries": config.get("total_queries", 0),
            "max_free_queries": config.get("max_free_queries", 3),
            "is_new": False,
        }

    # Auto-register with the backend
    device_info = get_device_info()
    try:
        resp = requests.post(
            f"{BACKEND_URL}/auth/device/register",
            json=device_info,
            timeout=15,
        )
        if resp.status_code == 200:
            data = resp.json()
            # Save to config
            config["api_key"] = data["api_key"]
            config["machine_id"] = device_info["machine_id"]
            config["status"] = data.get("status", "anonymous")
            config["credits"] = data.get("credits", 0)
            config["total_queries"] = data.get("total_queries", 0)
            config["max_free_queries"] = data.get("max_free_queries", 3)
            config["mode"] = "cloud"
            save_config(config)
            return data
        else:
            return {"error": f"Server returned {resp.status_code}: {resp.text[:200]}"}
    except requests.exceptions.ConnectionError:
        return {"error": "Cannot connect to MundiX server. Check your internet connection."}
    except Exception as e:
        return {"error": str(e)}


def get_device_status(api_key: str) -> dict:
    """Check device status from backend."""
    try:
        resp = requests.get(
            f"{BACKEND_URL}/auth/device/status",
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=10,
        )
        if resp.status_code == 200:
            return resp.json()
        return {"error": f"Status {resp.status_code}"}
    except Exception as e:
        return {"error": str(e)}


# ─── Device Activation (link to user account) ──────────────────────

def request_device_activation() -> dict:
    """Request a device code to link this device to a user account."""
    device_info = get_device_info()
    try:
        resp = requests.post(
            f"{BACKEND_URL}/auth/device/request",
            json=device_info,
            timeout=15,
        )
        if resp.status_code == 200:
            data = resp.json()
            config = load_config()
            config["device_code"] = data.get("device_code")
            config["mode"] = "activating"
            save_config(config)
            return data
        else:
            return {"error": f"Server returned {resp.status_code}: {resp.text[:200]}"}
    except requests.exceptions.ConnectionError:
        return {"error": "Cannot connect to MundiX server."}
    except Exception as e:
        return {"error": str(e)}


def check_activation(device_code: str) -> dict:
    """Check if the device has been activated on the website."""
    machine_id = get_machine_id()
    try:
        resp = requests.post(
            f"{BACKEND_URL}/auth/device/poll",
            json={"device_code": device_code, "machine_id": machine_id},
            timeout=10,
        )
        if resp.status_code == 200:
            data = resp.json()
            if data.get("status") == "activated":
                config = load_config()
                if data.get("api_key"):
                    config["api_key"] = data["api_key"]
                config["status"] = "registered"
                config["mode"] = "cloud"
                config["credits"] = data.get("credits", config.get("credits", 0))
                if "device_code" in config:
                    del config["device_code"]
                save_config(config)
            return data
        return {"status": "pending"}
    except Exception:
        return {"status": "error"}


def check_credits(api_key: str) -> dict:
    """Check remaining credits for a device."""
    try:
        resp = requests.get(
            f"{BACKEND_URL}/billing/credits",
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=10,
        )
        if resp.status_code == 200:
            return resp.json()
        return {"error": f"Status {resp.status_code}"}
    except Exception as e:
        return {"error": str(e)}


def get_billing_packages() -> dict:
    """Fetch available billing packages from the backend."""
    try:
        resp = requests.get(
            f"{BACKEND_URL}/billing/packages",
            timeout=10,
        )
        if resp.status_code == 200:
            return resp.json()
        return {"error": f"Status {resp.status_code}"}
    except Exception as e:
        return {"error": str(e)}


__all__ = [
    "AIProvider", "MODELS", "DEFAULT_MODEL", "FALLBACK_ORDER", "BACKEND_URL",
    "TIER_MODELS", "auto_register_device", "request_device_activation",
    "check_activation", "check_credits", "load_config", "save_config",
    "get_device_info", "get_device_status", "get_billing_packages",
]
