"""
MundiX CLI - Basic Tests for New Architecture

Tests the core interfaces and engine initialization.
"""

import pytest
import asyncio
from pathlib import Path

# ─── Config Tests ───────────────────────────────────────────────────

class TestConfig:
    def test_default_config(self):
        from src.core.config import MundiXConfig
        config = MundiXConfig()
        assert config.default_model == "mx-deephat-7b"
        assert config.autopilot_level == 1
        assert config.command_timeout == 300
    
    def test_config_from_dict(self):
        from src.core.config import MundiXConfig
        data = {"default_model": "test-model", "autopilot_level": 3}
        config = MundiXConfig.from_dict(data)
        assert config.default_model == "test-model"
        assert config.autopilot_level == 3
    
    def test_config_env_override(self, monkeypatch):
        from src.core.config import MundiXConfig
        monkeypatch.setenv("MUNDIX_DEFAULT_MODEL", "env-model")
        config = MundiXConfig()
        config.apply_env_overrides()
        assert config.default_model == "env-model"


# ─── AI Base Tests ──────────────────────────────────────────────────

class TestAIBase:
    def test_model_info(self):
        from src.ai.base import ModelInfo, ModelTier
        model = ModelInfo(
            id="test-7b",
            name="Test 7B",
            description="Test model",
            context_length=8192,
            tier=ModelTier.SPECIALIST,
        )
        assert model.id == "test-7b"
        assert model.tier == ModelTier.SPECIALIST
    
    def test_chat_message(self):
        from src.ai.base import ChatMessage
        msg = ChatMessage(role="user", content="Hello")
        assert msg.role == "user"
        assert msg.content == "Hello"


# ─── Memory Base Tests ──────────────────────────────────────────────

class TestMemoryBase:
    def test_memory_entry(self):
        from src.memory.base import MemoryEntry, MemoryType
        entry = MemoryEntry(
            type=MemoryType.QUERY,
            query="test query",
            response="test response",
        )
        assert entry.type == MemoryType.QUERY
        assert entry.query == "test query"
        assert entry.id is not None
    
    def test_memory_entry_serialization(self):
        from src.memory.base import MemoryEntry, MemoryType
        entry = MemoryEntry(type=MemoryType.QUERY, content="test")
        data = entry.to_dict()
        assert data["type"] == "query"
        assert data["content"] == "test"
        
        restored = MemoryEntry.from_dict(data)
        assert restored.content == "test"


# ─── Skills Tests ───────────────────────────────────────────────────

class TestSkills:
    def test_skill_command_render(self):
        from src.skills.models import SkillCommand
        cmd = SkillCommand(
            step=1,
            title="Test",
            command="nmap {{target}}",
        )
        rendered = cmd.render({"target": "10.0.0.1"})
        assert rendered == "nmap 10.0.0.1"
    
    def test_skill_command_placeholders(self):
        from src.skills.models import SkillCommand
        cmd = SkillCommand(
            step=1,
            title="Test",
            command="nmap {{target}} -p {{ports}}",
        )
        placeholders = cmd.get_placeholders()
        assert "target" in placeholders
        assert "ports" in placeholders
    
    def test_skill_validation(self):
        from src.skills.models import Skill, SkillPhase, SkillCommand
        skill = Skill(
            name="Test Skill",
            phase=SkillPhase.RECONNAISSANCE,
            description="A test skill",
            commands=[
                SkillCommand(step=1, title="Step 1", command="echo hello"),
            ],
        )
        errors = skill.validate()
        assert len(errors) == 0


# ─── Safety Tests ───────────────────────────────────────────────────

class TestSafety:
    def test_safe_command(self):
        from src.system.safety import SafetyChecker, RiskLevel
        checker = SafetyChecker()
        result = checker.check("nmap -sV 10.0.0.1")
        assert result.risk_level in (RiskLevel.SAFE, RiskLevel.LOW)
        assert not result.blocked
    
    def test_dangerous_command(self):
        from src.system.safety import SafetyChecker, RiskLevel
        checker = SafetyChecker()
        result = checker.check("rm -rf /")
        assert result.risk_level == RiskLevel.CRITICAL
        assert result.blocked
    
    def test_pentest_tool_detection(self):
        from src.system.safety import SafetyChecker
        checker = SafetyChecker()
        result = checker.check("nmap -sC -sV target")
        assert any("scanner" in w.lower() or "Nmap" in w for w in result.warnings)


# ─── Session Tests ──────────────────────────────────────────────────

class TestSession:
    def test_session_context(self):
        from src.core.session import SessionContext
        ctx = SessionContext()
        assert ctx.session_id is not None
        assert ctx.target_host is None
    
    def test_session_variables(self):
        from src.core.session import SessionContext
        ctx = SessionContext()
        ctx.update_variable("target", "10.0.0.1")
        assert ctx.get_variable("target") == "10.0.0.1"
    
    def test_session_manager(self):
        from src.core.session import SessionManager
        mgr = SessionManager()
        session = mgr.create_session()
        assert mgr.get_session() is session
        mgr.end_session()
        assert mgr.get_session() is None


# ─── Engine Tests ───────────────────────────────────────────────────

class TestEngine:
    @pytest.mark.asyncio
    async def test_engine_initial_state(self):
        from src.core.engine import MundiXEngine
        engine = MundiXEngine()
        assert not engine.state.is_running
    
    @pytest.mark.asyncio
    async def test_engine_initialize_no_ai(self):
        from src.core.engine import MundiXEngine
        engine = MundiXEngine()
        # Should work without AI provider (just session and config)
        success = await engine.initialize()
        assert success is True
        assert engine.state.is_running
        await engine.shutdown()


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
