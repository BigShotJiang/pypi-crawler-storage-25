"""
MundiX Multi-Agent System (Compatibility Shim)
Now imports from src.agent.multi_agent for the actual implementation.
Backward compatibility layer.
"""

from src.agent.multi_agent import (
    AgentCoordinator,
    AgentRole,
    AgentTask,
    AgentResult,
    SpecialistAgent,
)

__all__ = ["AgentCoordinator", "AgentRole", "AgentTask", "AgentResult", "SpecialistAgent"]
