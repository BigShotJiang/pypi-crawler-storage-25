"""
MundiX CLI - Collective Memory System (Compatibility Shim)
Now imports from src.memory.local for the actual implementation.
Backward compatibility layer.
"""

from src.memory.local import LocalMemoryBackend as Memory

__all__ = ["Memory"]
