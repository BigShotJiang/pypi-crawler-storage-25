"""
MundiX CLI - AutoPilot System (Compatibility Shim)
Now imports from src.autopilot.controller for the actual implementation.
Backward compatibility layer.
"""

from src.autopilot.controller import (
    AutopilotController as AutoPilot,
    AutopilotLevel as LEVELS,
    diagnose_error,
    COMMAND_TO_PACKAGE,
    PIP_COMMAND_MAP,
    resolve_install,
)

__all__ = ["AutoPilot", "LEVELS", "diagnose_error", "COMMAND_TO_PACKAGE", "PIP_COMMAND_MAP", "resolve_install"]
