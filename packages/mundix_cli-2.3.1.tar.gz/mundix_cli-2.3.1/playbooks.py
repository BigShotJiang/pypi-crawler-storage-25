"""
MundiX CLI - Pentest Playbooks (Compatibility Shim)
Now imports from src.agent.playbooks for the actual implementation.
Backward compatibility layer.
"""

from src.agent.playbooks import (
    PlaybookRunner,
    PLAYBOOKS,
)

__all__ = ["PlaybookRunner", "PLAYBOOKS"]
