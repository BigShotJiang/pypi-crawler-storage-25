"""
MundiX Skill Loader (Compatibility Shim)
Now imports from src.skills.loader for the actual implementation.
Backward compatibility layer.
"""

# Import SkillLoader and alias it as SkillRegistry
import sys
from src.skills.loader import SkillLoader
SkillRegistry = SkillLoader

# Also import Skill from models
from src.skills.models import Skill

# Backward compatibility
__all__ = ["SkillRegistry", "Skill"]
