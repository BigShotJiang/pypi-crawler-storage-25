"""
MundiX CLI - Memory Base Interface

Abstract base class for memory backends (local SQLite, vector embeddings, etc.).
Defines the contract for storing and retrieving past interactions.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional
import uuid


class MemoryType(str, Enum):
    """Type of memory entry."""
    QUERY = "query"           # User query and AI response
    COMMAND = "command"       # Executed command and output
    FINDING = "finding"       # Security finding
    NOTE = "note"             # User note
    SYSTEM = "system"         # System event


@dataclass
class MemoryEntry:
    """A single memory entry."""
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    type: MemoryType = MemoryType.QUERY
    content: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)
    tags: List[str] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: Optional[datetime] = None
    upvotes: int = 0
    project_id: Optional[str] = None  # Associated project (None = global)
    
    # For query/response pairs
    query: Optional[str] = None
    response: Optional[str] = None
    commands: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "id": self.id,
            "type": self.type.value,
            "content": self.content,
            "metadata": self.metadata,
            "tags": self.tags,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "upvotes": self.upvotes,
            "project_id": self.project_id,
            "query": self.query,
            "response": self.response,
            "commands": self.commands,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "MemoryEntry":
        """Deserialize from dictionary."""
        entry = cls(
            id=data.get("id", str(uuid.uuid4())),
            type=MemoryType(data.get("type", "query")),
            content=data.get("content", ""),
            metadata=data.get("metadata", {}),
            tags=data.get("tags", []),
            created_at=datetime.fromisoformat(data["created_at"]) if data.get("created_at") else datetime.now(),
            updated_at=datetime.fromisoformat(data["updated_at"]) if data.get("updated_at") else None,
            upvotes=data.get("upvotes", 0),
            project_id=data.get("project_id"),
            query=data.get("query"),
            response=data.get("response"),
            commands=data.get("commands", []),
        )
        return entry


@dataclass
class MemorySearchResult:
    """Result of a memory search."""
    entry: MemoryEntry
    score: float  # 0.0-1.0 relevance
    source: str   # "local", "vector", "collective"


class MemoryBackend(ABC):
    """
    Abstract base class for memory backends.
    
    Implementations can use SQLite, vector databases, or other storage.
    """
    
    @abstractmethod
    async def initialize(self) -> bool:
        """Initialize the memory backend (create tables, load indexes, etc.)."""
        pass
    
    @abstractmethod
    async def store(self, entry: MemoryEntry) -> str:
        """
        Store a memory entry.
        
        Args:
            entry: The memory entry to store
        
        Returns:
            Entry ID
        """
        pass
    
    @abstractmethod
    async def get(self, entry_id: str) -> Optional[MemoryEntry]:
        """
        Retrieve a memory entry by ID.
        
        Args:
            entry_id: The entry ID
        
        Returns:
            MemoryEntry or None if not found
        """
        pass
    
    @abstractmethod
    async def search(
        self,
        query: str,
        limit: int = 5,
        min_score: float = 0.5,
        project_id: Optional[str] = None,
        tags: Optional[List[str]] = None,
        entry_type: Optional[MemoryType] = None,
    ) -> List[MemorySearchResult]:
        """
        Search for relevant memory entries.
        
        Args:
            query: Search query
            limit: Maximum results to return
            min_score: Minimum relevance score
            project_id: Filter by project
            tags: Filter by tags
            entry_type: Filter by type
        
        Returns:
            List of search results sorted by relevance
        """
        pass
    
    @abstractmethod
    async def delete(self, entry_id: str) -> bool:
        """
        Delete a memory entry.
        
        Args:
            entry_id: The entry ID
        
        Returns:
            True if deleted
        """
        pass
    
    @abstractmethod
    async def upvote(self, entry_id: str) -> bool:
        """
        Upvote a memory entry (mark as useful).
        
        Args:
            entry_id: The entry ID
        
        Returns:
            True if upvoted
        """
        pass
    
    @abstractmethod
    async def get_stats(self) -> Dict[str, Any]:
        """
        Get memory statistics.
        
        Returns:
            Dictionary with entry counts, types, etc.
        """
        pass
    
    @abstractmethod
    async def clear(self, project_id: Optional[str] = None):
        """
        Clear all memory entries (optionally for a specific project).
        
        Args:
            project_id: If provided, only clear entries for this project
        """
        pass
    
    @property
    @abstractmethod
    def name(self) -> str:
        """Human-readable backend name."""
        pass
