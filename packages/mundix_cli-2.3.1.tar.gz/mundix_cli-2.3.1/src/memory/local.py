"""
MundiX CLI - Local Memory Backend (SQLite)

SQLite-based memory storage with full-text search support.
"""

import json
import sqlite3
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from src.core.logging import get_logger
from src.memory.base import MemoryBackend, MemoryEntry, MemoryType, MemorySearchResult

logger = get_logger("memory.local")

# ─── Database Schema ────────────────────────────────────────────────

SCHEMA = """
CREATE TABLE IF NOT EXISTS memory_entries (
    id TEXT PRIMARY KEY,
    type TEXT NOT NULL,
    content TEXT,
    metadata TEXT DEFAULT '{}',
    tags TEXT DEFAULT '[]',
    created_at TEXT NOT NULL,
    updated_at TEXT,
    upvotes INTEGER DEFAULT 0,
    project_id TEXT,
    query TEXT,
    response TEXT,
    commands TEXT DEFAULT '[]'
);

CREATE INDEX IF NOT EXISTS idx_type ON memory_entries(type);
CREATE INDEX IF NOT EXISTS idx_project ON memory_entries(project_id);
CREATE INDEX IF NOT EXISTS idx_created ON memory_entries(created_at);
CREATE INDEX IF NOT EXISTS idx_upvotes ON memory_entries(upvotes);

-- Full-text search virtual table
CREATE VIRTUAL TABLE IF NOT EXISTS memory_fts USING fts5(
    content, query, response,
    content='memory_entries',
    content_rowid='rowid'
);
"""


class LocalMemoryBackend(MemoryBackend):
    """
    SQLite-based memory backend with full-text search.
    
    Provides persistent storage and basic text similarity search.
    """
    
    def __init__(self, db_path: Optional[str] = None):
        self.db_path = Path(db_path) if db_path else Path.home() / ".mundix" / "memory.db"
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn: Optional[sqlite3.Connection] = None
    
    @property
    def name(self) -> str:
        return "SQLite Local Memory"
    
    async def initialize(self) -> bool:
        """Initialize database and create tables."""
        try:
            self._conn = sqlite3.connect(str(self.db_path))
            self._conn.row_factory = sqlite3.Row
            self._conn.executescript(SCHEMA)
            self._conn.commit()
            logger.info(f"Local memory initialized: {self.db_path}")
            return True
        except Exception as e:
            logger.error(f"Failed to initialize local memory: {e}")
            return False
    
    async def store(self, entry: MemoryEntry) -> str:
        """Store a memory entry."""
        try:
            self._conn.execute(
                """INSERT OR REPLACE INTO memory_entries 
                   (id, type, content, metadata, tags, created_at, updated_at, 
                    upvotes, project_id, query, response, commands)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    entry.id,
                    entry.type.value,
                    entry.content,
                    json.dumps(entry.metadata),
                    json.dumps(entry.tags),
                    entry.created_at.isoformat(),
                    entry.updated_at.isoformat() if entry.updated_at else None,
                    entry.upvotes,
                    entry.project_id,
                    entry.query,
                    entry.response,
                    json.dumps(entry.commands),
                ),
            )
            self._conn.commit()
            return entry.id
        except Exception as e:
            logger.error(f"Failed to store memory entry: {e}")
            return entry.id
    
    async def get(self, entry_id: str) -> Optional[MemoryEntry]:
        """Retrieve a memory entry by ID."""
        try:
            row = self._conn.execute(
                "SELECT * FROM memory_entries WHERE id = ?", (entry_id,)
            ).fetchone()
            
            if row:
                return self._row_to_entry(row)
            return None
        except Exception as e:
            logger.error(f"Failed to get memory entry: {e}")
            return None
    
    async def search(
        self,
        query: str,
        limit: int = 5,
        min_score: float = 0.5,
        project_id: Optional[str] = None,
        tags: Optional[List[str]] = None,
        entry_type: Optional[MemoryType] = None,
    ) -> List[MemorySearchResult]:
        """Search for relevant memory entries using full-text search."""
        try:
            sql = """
                SELECT *, 
                    CASE 
                        WHEN query IS NOT NULL AND query != '' THEN 1.0
                        WHEN content IS NOT NULL AND content != '' THEN 0.7
                        ELSE 0.3
                    END as relevance
                FROM memory_entries
                WHERE (query LIKE ? OR content LIKE ? OR response LIKE ?)
            """
            params = [f"%{query}%", f"%{query}%", f"%{query}%"]
            
            if project_id:
                sql += " AND project_id = ?"
                params.append(project_id)
            
            if entry_type:
                sql += " AND type = ?"
                params.append(entry_type.value)
            
            sql += " ORDER BY upvotes DESC, created_at DESC LIMIT ?"
            params.append(limit)
            
            rows = self._conn.execute(sql, params).fetchall()
            
            results = []
            for row in rows:
                entry = self._row_to_entry(row)
                score = row["relevance"]
                if score >= min_score:
                    results.append(MemorySearchResult(
                        entry=entry,
                        score=score,
                        source="local",
                    ))
            
            return results
        except Exception as e:
            logger.error(f"Failed to search memory: {e}")
            return []
    
    async def delete(self, entry_id: str) -> bool:
        """Delete a memory entry."""
        try:
            self._conn.execute("DELETE FROM memory_entries WHERE id = ?", (entry_id,))
            self._conn.commit()
            return True
        except Exception as e:
            logger.error(f"Failed to delete memory entry: {e}")
            return False
    
    async def upvote(self, entry_id: str) -> bool:
        """Upvote a memory entry."""
        try:
            self._conn.execute(
                "UPDATE memory_entries SET upvotes = upvotes + 1 WHERE id = ?",
                (entry_id,),
            )
            self._conn.commit()
            return True
        except Exception as e:
            logger.error(f"Failed to upvote memory entry: {e}")
            return False
    
    async def get_stats(self) -> Dict[str, Any]:
        """Get memory statistics."""
        try:
            total = self._conn.execute("SELECT COUNT(*) FROM memory_entries").fetchone()[0]
            by_type = {}
            for row in self._conn.execute("SELECT type, COUNT(*) as cnt FROM memory_entries GROUP BY type"):
                by_type[row["type"]] = row["cnt"]
            
            total_upvotes = self._conn.execute("SELECT SUM(upvotes) FROM memory_entries").fetchone()[0] or 0
            
            return {
                "total_entries": total,
                "by_type": by_type,
                "total_upvotes": total_upvotes,
                "db_path": str(self.db_path),
            }
        except Exception as e:
            logger.error(f"Failed to get memory stats: {e}")
            return {}
    
    async def clear(self, project_id: Optional[str] = None):
        """Clear all memory entries."""
        try:
            if project_id:
                self._conn.execute("DELETE FROM memory_entries WHERE project_id = ?", (project_id,))
            else:
                self._conn.execute("DELETE FROM memory_entries")
            self._conn.commit()
            logger.info(f"Cleared memory entries{' for project ' + project_id if project_id else ''}")
        except Exception as e:
            logger.error(f"Failed to clear memory: {e}")
    
    def _row_to_entry(self, row: sqlite3.Row) -> MemoryEntry:
        """Convert a database row to MemoryEntry."""
        return MemoryEntry(
            id=row["id"],
            type=MemoryType(row["type"]),
            content=row["content"] or "",
            metadata=json.loads(row["metadata"] or "{}"),
            tags=json.loads(row["tags"] or "[]"),
            created_at=datetime.fromisoformat(row["created_at"]),
            updated_at=datetime.fromisoformat(row["updated_at"]) if row["updated_at"] else None,
            upvotes=row["upvotes"] or 0,
            project_id=row["project_id"],
            query=row["query"],
            response=row["response"],
            commands=json.loads(row["commands"] or "[]"),
        )


# Backward compatibility
Memory = LocalMemoryBackend
