"""MundiX CLI - Memory backends (local, vector)."""
