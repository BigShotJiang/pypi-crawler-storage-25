"""
MundiX CLI v2.0 - Project Manager

Manages pentest projects with workspaces, targets, and findings.
"""

import json
import os
import shutil
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from src.core.logging import get_logger

logger = get_logger("project.manager")


@dataclass
class Project:
    """A pentest project."""
    name: str
    target: str = ""
    target_type: str = "web"  # web, internal, app
    description: str = ""
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat())
    workspace_dir: str = ""
    findings: List[Dict[str, Any]] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)
    tags: List[str] = field(default_factory=list)
    status: str = "active"  # active, completed, archived
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "target": self.target,
            "target_type": self.target_type,
            "description": self.description,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "workspace_dir": self.workspace_dir,
            "findings": self.findings,
            "notes": self.notes,
            "tags": self.tags,
            "status": self.status,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Project':
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})


class ProjectManager:
    """
    Manages pentest projects.
    
    Each project has:
    - A workspace directory for output files
    - A list of findings
    - Notes and tags
    - Engagement state
    """
    
    def __init__(self, projects_dir: Optional[str] = None):
        self.projects_dir = Path(projects_dir) if projects_dir else Path.home() / ".mundix" / "projects"
        self.projects_dir.mkdir(parents=True, exist_ok=True)
        self._projects: Dict[str, Project] = {}
        self._current_project: Optional[Project] = None
        self._load_all()
    
    def _load_all(self):
        """Load all projects from disk."""
        for project_file in self.projects_dir.glob("*/project.json"):
            try:
                with open(project_file) as f:
                    data = json.load(f)
                project = Project.from_dict(data)
                self._projects[project.name] = project
            except Exception as e:
                logger.error(f"Failed to load project {project_file}: {e}")
        logger.info(f"Loaded {len(self._projects)} projects")
    
    def create(self, name: str, target: str = "", target_type: str = "web", description: str = "") -> Project:
        """Create a new project."""
        if name in self._projects:
            raise ValueError(f"Project '{name}' already exists")
        
        workspace = str(self.projects_dir / name)
        Path(workspace).mkdir(parents=True, exist_ok=True)
        
        project = Project(
            name=name,
            target=target,
            target_type=target_type,
            description=description,
            workspace_dir=workspace,
        )
        
        self._projects[name] = project
        self._save_project(project)
        self._current_project = project
        
        logger.info(f"Project created: {name}")
        return project
    
    def open(self, name: str) -> Optional[Project]:
        """Open an existing project."""
        project = self._projects.get(name)
        if project:
            self._current_project = project
            logger.info(f"Project opened: {name}")
        return project
    
    def close(self):
        """Close the current project."""
        if self._current_project:
            logger.info(f"Project closed: {self._current_project.name}")
            self._current_project = None
    
    def delete(self, name: str, include_workspace: bool = False) -> bool:
        """Delete a project."""
        project = self._projects.pop(name, None)
        if not project:
            return False
        
        project_file = self.projects_dir / name / "project.json"
        if project_file.exists():
            project_file.unlink()
        
        if include_workspace and project.workspace_dir:
            shutil.rmtree(project.workspace_dir, ignore_errors=True)
        
        if self._current_project and self._current_project.name == name:
            self._current_project = None
        
        logger.info(f"Project deleted: {name}")
        return True
    
    def list_projects(self) -> List[Project]:
        """List all projects."""
        return list(self._projects.values())
    
    def get_current(self) -> Optional[Project]:
        """Get the current project."""
        return self._current_project
    
    def add_finding(self, finding: Dict[str, Any]):
        """Add a finding to the current project."""
        if not self._current_project:
            raise RuntimeError("No project open")
        
        finding["created_at"] = datetime.now().isoformat()
        self._current_project.findings.append(finding)
        self._current_project.updated_at = datetime.now().isoformat()
        self._save_project(self._current_project)
        logger.info(f"Finding added to {self._current_project.name}")
    
    def add_note(self, note: str):
        """Add a note to the current project."""
        if not self._current_project:
            raise RuntimeError("No project open")
        
        self._current_project.notes.append(note)
        self._current_project.updated_at = datetime.now().isoformat()
        self._save_project(self._current_project)
    
    def get_findings(self, severity: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get findings, optionally filtered by severity."""
        if not self._current_project:
            return []
        
        findings = self._current_project.findings
        if severity:
            findings = [f for f in findings if f.get("severity", "").lower() == severity.lower()]
        return findings
    
    def _save_project(self, project: Project):
        """Save a project to disk."""
        project_dir = Path(project.workspace_dir) if project.workspace_dir else self.projects_dir / project.name
        project_dir.mkdir(parents=True, exist_ok=True)
        
        project_file = project_dir / "project.json"
        with open(project_file, 'w') as f:
            json.dump(project.to_dict(), f, indent=2, default=str)
