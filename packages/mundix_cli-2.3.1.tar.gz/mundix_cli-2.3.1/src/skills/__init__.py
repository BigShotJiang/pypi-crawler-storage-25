"""MundiX CLI - Skill system with validation and execution."""
