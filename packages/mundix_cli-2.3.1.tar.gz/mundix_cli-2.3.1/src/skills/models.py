"""
MundiX CLI - Skill System Models

Data models for skills, commands, and execution results.
Skills are defined in YAML format with validation.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional
from pathlib import Path


class SkillPhase(str, Enum):
    """PTES-aligned skill phase."""
    RECONNAISSANCE = "1_reconnaissance"
    SCANNING = "2_scanning"
    VULNERABILITY_ANALYSIS = "3_vulnerability_analysis"
    EXPLOITATION = "4_exploitation"
    POST_EXPLOITATION = "5_post_exploitation"
    REPORTING = "6_reporting"


class SkillStatus(str, Enum):
    """Status of a skill execution."""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"


class CommandStatus(str, Enum):
    """Status of a command execution."""
    PENDING = "pending"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"
    TIMEOUT = "timeout"
    SKIPPED = "skipped"


@dataclass
class MitreTactic:
    """MITRE ATT&CK tactic reference."""
    id: str
    name: str


@dataclass
class SkillVariable:
    """A variable that a skill accepts."""
    name: str
    type: str  # string, int, enum, bool
    required: bool = False
    default: Any = None
    options: Optional[List[str]] = None  # For enum type
    description: str = ""


@dataclass
class SkillCommand:
    """A single command within a skill."""
    step: int
    title: str
    command: str
    description: str = ""
    timeout: int = 300  # seconds
    parse_output: bool = False
    on_failure: str = "abort"  # abort, retry, continue
    required_tools: List[str] = field(default_factory=list)
    
    def render(self, variables: Dict[str, str]) -> str:
        """Render command with variable substitution."""
        result = self.command
        for key, value in variables.items():
            placeholder = f"{{{{{key}}}}}"
            if placeholder in result:
                result = result.replace(placeholder, str(value))
        return result
    
    def get_placeholders(self) -> List[str]:
        """Extract all placeholders from the command."""
        import re
        return re.findall(r'\{\{(\w+)\}\}', self.command)


@dataclass
class Skill:
    """
    A MundiX skill - a reusable pentest procedure.
    
    Skills are defined in YAML files and loaded by the SkillRegistry.
    """
    name: str
    phase: SkillPhase
    description: str
    version: str = "1.0.0"
    
    # Requirements
    required_tools: List[str] = field(default_factory=list)
    required_skills: List[str] = field(default_factory=list)  # Dependencies
    required_variables: List[SkillVariable] = field(default_factory=list)
    
    # Commands
    commands: List[SkillCommand] = field(default_factory=list)
    
    # Documentation
    analysis_guide: str = ""
    next_steps: str = ""
    conditions: str = ""
    
    # MITRE
    mitre_tactics: List[MitreTactic] = field(default_factory=list)
    
    # Metadata
    source_file: Optional[Path] = None
    tags: List[str] = field(default_factory=list)
    
    @property
    def phase_number(self) -> int:
        """Get the numeric phase (1-6)."""
        try:
            return int(self.phase.value.split("_")[0])
        except (ValueError, IndexError):
            return 0
    
    def get_all_placeholders(self) -> List[str]:
        """Get all unique placeholders across all commands."""
        placeholders = set()
        for cmd in self.commands:
            placeholders.update(cmd.get_placeholders())
        return sorted(placeholders)
    
    def validate(self) -> List[str]:
        """
        Validate the skill definition.
        
        Returns:
            List of validation errors (empty if valid)
        """
        errors = []
        
        if not self.name:
            errors.append("Skill name is required")
        
        if not self.description:
            errors.append("Skill description is required")
        
        if not self.commands:
            errors.append("Skill must have at least one command")
        
        # Check for duplicate step numbers
        step_numbers = [cmd.step for cmd in self.commands]
        if len(step_numbers) != len(set(step_numbers)):
            errors.append("Duplicate step numbers found")
        
        # Check variable requirements
        required_vars = {v.name for v in self.required_variables if v.required}
        all_placeholders = set(self.get_all_placeholders())
        missing_vars = required_vars - all_placeholders
        if missing_vars:
            errors.append(f"Required variables not used in commands: {missing_vars}")
        
        return errors


@dataclass
class CommandResult:
    """Result of executing a single command."""
    command: str
    status: CommandStatus
    stdout: str = ""
    stderr: str = ""
    exit_code: int = -1
    duration: float = 0.0
    error: Optional[str] = None
    parsed_output: Optional[Dict[str, Any]] = None


@dataclass
class SkillResult:
    """Result of executing a skill."""
    skill: Skill
    status: SkillStatus
    command_results: List[CommandResult] = field(default_factory=list)
    findings: List[Dict[str, Any]] = field(default_factory=list)
    duration: float = 0.0
    error: Optional[str] = None
    variables_used: Dict[str, str] = field(default_factory=dict)
    
    @property
    def success(self) -> bool:
        return self.status == SkillStatus.COMPLETED
    
    @property
    def failed_commands(self) -> List[CommandResult]:
        return [r for r in self.command_results if r.status in (CommandStatus.FAILED, CommandStatus.TIMEOUT)]
