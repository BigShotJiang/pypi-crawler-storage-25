"""MundiX CLI - Skill definitions in YAML format."""
