"""
MundiX CLI - Skill Loader

Loads skill definitions from YAML files and validates them.
"""

import os
import yaml
from pathlib import Path
from typing import Dict, List, Optional

from src.core.logging import get_logger
from src.skills.models import (
    Skill, SkillPhase, SkillCommand, SkillVariable, MitreTactic
)

logger = get_logger("skills.loader")


class SkillLoader:
    """
    Loads skill definitions from YAML files.
    
    Supports both the new YAML format and legacy markdown format.
    """
    
    def __init__(self, skills_dir: Optional[str] = None):
        self.skills_dir = Path(skills_dir) if skills_dir else self._find_skills_dir()
        self._skills_cache: Dict[str, Skill] = {}
    
    def _find_skills_dir(self) -> Path:
        """Auto-detect skills directory."""
        candidates = [
            Path(__file__).parent.parent.parent / "skills",  # Git repo
            Path("/opt/mundix-cli/skills"),  # Default install
            Path.home() / ".mundix" / "skills",  # User skills
        ]
        for c in candidates:
            if c.is_dir():
                return c
        return candidates[0]  # Return first even if missing
    
    def load_all(self) -> Dict[str, Skill]:
        """
        Load all skill definitions from the skills directory.
        
        Returns:
            Dictionary mapping skill name to Skill object
        """
        if not self.skills_dir.exists():
            logger.warning(f"Skills directory not found: {self.skills_dir}")
            return {}
        
        skills = {}
        
        # Load YAML files
        for yaml_file in self.skills_dir.glob("*.yaml"):
            try:
                skill = self._load_yaml_skill(yaml_file)
                if skill:
                    skills[skill.name] = skill
                    logger.debug(f"Loaded skill: {skill.name}")
            except Exception as e:
                logger.error(f"Failed to load {yaml_file}: {e}")
        
        # Load legacy markdown files
        for md_file in self.skills_dir.glob("*.md"):
            try:
                skill = self._load_markdown_skill(md_file)
                if skill:
                    skills[skill.name] = skill
                    logger.debug(f"Loaded legacy skill: {skill.name}")
            except Exception as e:
                logger.error(f"Failed to load {md_file}: {e}")
        
        self._skills_cache = skills
        logger.info(f"Loaded {len(skills)} skills from {self.skills_dir}")
        return skills
    
    def get_skill(self, name: str) -> Optional[Skill]:
        """Get a skill by name."""
        if not self._skills_cache:
            self.load_all()
        return self._skills_cache.get(name)
    
    def get_skills_by_phase(self, phase: SkillPhase) -> List[Skill]:
        """Get all skills for a specific phase."""
        if not self._skills_cache:
            self.load_all()
        return [s for s in self._skills_cache.values() if s.phase == phase]
    
    def _load_yaml_skill(self, file_path: Path) -> Optional[Skill]:
        """Load a skill from YAML format."""
        with open(file_path, "r") as f:
            data = yaml.safe_load(f)
        
        if not data:
            return None
        
        # Parse phase
        phase_str = data.get("phase", "1_reconnaissance")
        try:
            phase = SkillPhase(phase_str)
        except ValueError:
            phase = SkillPhase.RECONNAISSANCE
        
        # Parse variables
        variables = []
        for var_data in data.get("variables", []):
            variables.append(SkillVariable(
                name=var_data.get("name", ""),
                type=var_data.get("type", "string"),
                required=var_data.get("required", False),
                default=var_data.get("default"),
                options=var_data.get("options"),
                description=var_data.get("description", ""),
            ))
        
        # Parse commands
        commands = []
        for cmd_data in data.get("commands", []):
            commands.append(SkillCommand(
                step=cmd_data.get("step", 0),
                title=cmd_data.get("title", ""),
                command=cmd_data.get("command", ""),
                description=cmd_data.get("description", ""),
                timeout=cmd_data.get("timeout", 300),
                parse_output=cmd_data.get("parse", False),
                on_failure=cmd_data.get("on_failure", "abort"),
                required_tools=cmd_data.get("tools", []),
            ))
        
        # Parse MITRE tactics
        mitre = []
        for tactic in data.get("mitre_tactics", []):
            mitre.append(MitreTactic(
                id=tactic.get("id", ""),
                name=tactic.get("name", ""),
            ))
        
        return Skill(
            name=data.get("name", file_path.stem),
            phase=phase,
            description=data.get("description", ""),
            version=data.get("version", "1.0.0"),
            required_tools=data.get("requires", {}).get("tools", []),
            required_skills=data.get("requires", {}).get("skills", []),
            required_variables=variables,
            commands=commands,
            analysis_guide=data.get("analysis", ""),
            next_steps=data.get("next_steps", ""),
            conditions=data.get("conditions", ""),
            mitre_tactics=mitre,
            source_file=file_path,
            tags=data.get("tags", []),
        )
    
    def _load_markdown_skill(self, file_path: Path) -> Optional[Skill]:
        """
        Load a skill from legacy markdown format.
        
        This is a compatibility layer for existing skills.
        New skills should use YAML format.
        """
        # Simple parser for legacy format
        with open(file_path, "r") as f:
            content = f.read()
        
        # Extract metadata from first lines
        lines = content.splitlines()
        name = file_path.stem.replace("_", " ").title()
        description = ""
        phase = SkillPhase.RECONNAISSANCE
        
        for line in lines[:10]:
            if line.startswith("# "):
                name = line[2:].strip()
            elif line.startswith("**Phase:**"):
                phase_str = line.split(":")[1].strip().lower()
                for p in SkillPhase:
                    if p.value.lower() == phase_str or p.name.lower() == phase_str:
                        phase = p
                        break
        
        # Extract commands from bash blocks
        import re
        commands = []
        bash_blocks = re.findall(r'```bash\n(.*?)\n```', content, re.DOTALL)
        
        for i, block in enumerate(bash_blocks):
            commands.append(SkillCommand(
                step=i + 1,
                title=f"Step {i + 1}",
                command=block.strip(),
                description="",
            ))
        
        return Skill(
            name=name,
            phase=phase,
            description=description or f"Legacy skill from {file_path.name}",
            commands=commands,
            source_file=file_path,
        )
