"""MundiX CLI - Autonomy control and error recovery."""
