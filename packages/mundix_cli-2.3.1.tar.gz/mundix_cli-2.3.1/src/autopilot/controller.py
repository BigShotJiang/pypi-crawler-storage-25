"""
MundiX CLI v2.0 - Autopilot Controller

Controls the level of autonomy for command execution.
Levels 1-5 from fully manual to fully autonomous.
"""

from dataclasses import dataclass
from enum import Enum
from typing import Optional

from src.core.logging import get_logger
from src.system.safety import RiskLevel

logger = get_logger("autopilot.controller")


class AutopilotLevel(int, Enum):
    MANUAL = 1
    GUIDED = 2
    SEMI_AUTO = 3
    AGGRESSIVE = 4
    FULL_AUTO = 5


LEVEL_DESCRIPTIONS = {
    AutopilotLevel.MANUAL: "Manual — Every command requires confirmation",
    AutopilotLevel.GUIDED: "Guided — Safe commands auto-executed, installs asked",
    AutopilotLevel.SEMI_AUTO: "Semi-Auto — Most commands auto, dangerous asked",
    AutopilotLevel.AGGRESSIVE: "Aggressive — Only truly destructive commands asked",
    AutopilotLevel.FULL_AUTO: "Full Autonomy — No questions asked (YOLO)",
}


@dataclass
class AutopilotSettings:
    """Current autopilot settings."""
    level: AutopilotLevel = AutopilotLevel.MANUAL
    auto_execute_safe: bool = False
    auto_install_tools: bool = False
    skip_dangerous_confirm: bool = False
    
    @property
    def name(self) -> str:
        return LEVEL_DESCRIPTIONS.get(self.level, "Unknown")
    
    @property
    def display(self) -> str:
        return f"AP:{self.level.value} ({self.level.name})"


class AutopilotController:
    """
    Controls command execution autonomy.
    
    Decides whether to:
    - Auto-execute a command
    - Ask for user confirmation
    - Block a command entirely
    """
    
    def __init__(self, level: AutopilotLevel = AutopilotLevel.MANUAL):
        self.settings = AutopilotSettings(level=level)
        self._update_settings()
    
    def set_level(self, level: int) -> bool:
        """Set autopilot level (1-5)."""
        try:
            new_level = AutopilotLevel(level)
            self.settings.level = new_level
            self._update_settings()
            logger.info(f"Autopilot level set to {level}: {self.settings.name}")
            return True
        except ValueError:
            logger.error(f"Invalid autopilot level: {level}")
            return False
    
    def should_execute(
        self,
        command: str,
        risk_level: RiskLevel = RiskLevel.SAFE,
        is_tool_install: bool = False,
    ) -> tuple[bool, str]:
        """
        Determine if a command should be executed.
        
        Returns:
            (should_execute, reason)
        """
        level = self.settings.level
        
        # Level 5: Full autonomy — always execute
        if level == AutopilotLevel.FULL_AUTO:
            return True, "FULL_AUTO: no questions asked"
        
        # Hard block: critical destructive commands (unless level 5)
        if risk_level == RiskLevel.CRITICAL:
            return False, "CRITICAL: destructive command blocked"
        
        # Level 4: Aggressive — only block critical
        if level == AutopilotLevel.AGGRESSIVE:
            return True, "AGGRESSIVE: auto-approved"
        
        # Level 3: Semi-auto — ask for high risk
        if level == AutopilotLevel.SEMI_AUTO:
            if risk_level in (RiskLevel.HIGH,):
                return False, "SEMI_AUTO: high risk requires confirmation"
            return True, "SEMI_AUTO: auto-approved"
        
        # Level 2: Guided — ask for installs and medium+ risk
        if level == AutopilotLevel.GUIDED:
            if is_tool_install and not self.settings.auto_install_tools:
                return False, "GUIDED: tool install requires confirmation"
            if risk_level in (RiskLevel.MEDIUM, RiskLevel.HIGH):
                return False, "GUIDED: requires confirmation"
            return True, "GUIDED: safe command auto-executed"
        
        # Level 1: Manual — always ask
        return False, "MANUAL: requires confirmation"
    
    def should_auto_install(self) -> bool:
        """Should missing tools be auto-installed?"""
        return self.settings.auto_install_tools
    
    def _update_settings(self):
        """Update derived settings based on level."""
        level = self.settings.level
        self.settings.auto_execute_safe = level >= AutopilotLevel.GUIDED
        self.settings.auto_install_tools = level >= AutopilotLevel.SEMI_AUTO
        self.settings.skip_dangerous_confirm = level >= AutopilotLevel.AGGRESSIVE


# Map of common commands to their package names (Kali/Debian)
COMMAND_TO_PACKAGE = {
    "nmap": "nmap",
    "sqlmap": "sqlmap",
    "gobuster": "gobuster",
    "dirb": "dirb",
    "nikto": "nikto",
    "hydra": "hydra",
    "john": "john",
    "hashcat": "hashcat",
    "wpscan": "wpscan",
    "nuclei": "nuclei",
    "feroxbuster": "feroxbuster",
    "ffuf": "ffuf",
    "masscan": "masscan",
    "rustscan": "rustscan",
    "responder": "responder",
    "enum4linux": "enum4linux",
    "smbclient": "samba-common-bin",
    "rpcclient": "samba-common-bin",
    "crackmapexec": "crackmapexec",
    "netexec": "netexec",
    "bloodhound": "bloodhound",
    "chisel": "chisel",
    "socat": "socat",
    "tcpdump": "tcpdump",
    "tshark": "tshark",
    "wireshark": "wireshark",
    "aircrack-ng": "aircrack-ng",
    "wifite": "wifite",
    "curl": "curl",
    "wget": "wget",
    "git": "git",
    "python3": "python3",
    "pip3": "python3-pip",
    "ruby": "ruby",
    "perl": "perl",
    "gcc": "gcc",
    "make": "make",
    "nc": "netcat-openbsd",
    "ncat": "ncat",
    "whois": "whois",
    "dig": "dnsutils",
    "host": "dnsutils",
    "traceroute": "traceroute",
    "nbtscan": "nbtscan",
    "onesixtyone": "onesixtyone",
    "snmpwalk": "snmp",
    "snmpcheck": "snmpcheck",
    "unicornscan": "unicornscan",
    "dnsrecon": "dnsrecon",
    "fierce": "fierce",
    "nslookup": "dnsutils",
    "netstat": "net-tools",
    "ifconfig": "net-tools",
    "ss": "iproute2",
    "ip": "iproute2",
    "enum4linux-ng": "enum4linux-ng",
    "smbmap": "smbmap",
    "ldapsearch": "ldap-utils",
    "evil-winrm": "evil-winrm",
    "impacket-secretsdump": "impacket-scripts",
    "impacket-psexec": "impacket-scripts",
    "impacket-wmiexec": "impacket-scripts",
    "impacket-smbexec": "impacket-scripts",
    "impacket-atexec": "impacket-scripts",
    "impacket-getTGT": "impacket-scripts",
    "impacket-getST": "impacket-scripts",
    "kerbrute": "kerbrute",
    "airmon-ng": "aircrack-ng",
    "airodump-ng": "aircrack-ng",
    "aireplay-ng": "aircrack-ng",
    "reaver": "reaver",
    "bully": "bully",
    "pixiewps": "pixiewps",
    "setoolkit": "set",
    "gophish": "gophish",
    "proxychains": "proxychains4",
    "proxychains4": "proxychains4",
    "sshuttle": "sshuttle",
    "tor": "tor",
    "docker": "docker.io",
    "trivy": "trivy",
    "theharvester": "theharvester",
    "recon-ng": "recon-ng",
    "maltego": "maltego",
    "sherlock": "sherlock",
    "subfinder": "subfinder",
    "amass": "amass",
    "whatweb": "whatweb",
    "wafw00f": "wafw00f",
    "wfuzz": "wfuzz",
    "dirsearch": "dirsearch",
    "arjun": "arjun",
    "searchsploit": "exploitdb",
    "msfconsole": "metasploit-framework",
    "msfvenom": "metasploit-framework",
    "msfdb": "metasploit-framework",
    "binwalk": "binwalk",
    "foremost": "foremost",
    "volatility": "volatility",
    "steghide": "steghide",
    "exiftool": "libimage-exiftool-perl",
    "strings": "binutils",
    "objdump": "binutils",
    "strace": "strace",
    "ltrace": "ltrace",
    "gdb": "gdb",
    "radare2": "radare2",
    "tcpdump": "tcpdump",
    "bettercap": "bettercap",
    "ettercap": "ettercap-text-only",
    "mitmproxy": "mitmproxy",
    "xfreerdp": "freerdp2-x11",
    "rdesktop": "rdesktop",
    "telnet": "telnet",
    "ftp": "ftp",
    "xxd": "xxd",
    "base64": "coreutils",
}

# Map of commands installable via pip (Python-based tools — curated allowlist)
PIP_COMMAND_MAP = {
    "sqlmap": "sqlmap",
    "wpscan": "wpscan",
    "theharvester": "theharvester",
    "subfinder": "subfinder",
    "amass": "amass",
    "httpx": "httpx-project",
    "nuclei": "nuclei",
    "gau": "gau",
    "waybackurls": "waybackurls",
    "fffuf": "fffuf",
    "gobuster": "gobuster",
    "feroxbuster": "feroxbuster",
    "dirsearch": "dirsearch",
    "arjun": "arjun",
    "wafw00f": "wafw00f",
    "whatweb": "whatweb",
    "dalfox": "dalfox",
    "xsstrike": "xsstrike",
    "commix": "commix",
    "weevely": "weevely",
    "wifite": "wifite",
    "aircrack-ng": "aircrack-ng",
    "mitmproxy": "mitmproxy",
    "trivy": "trivy",
    "shodan": "shodan",
    "censys": "censys",
    "impacket": "impacket",
    "pwntools": "pwntools",
    "ropgadget": "ropgadget",
    "angr": "angr",
    "zsteg": "zsteg",
    "stegcracker": "stegcracker",
    "pyinstxtractor": "pyinstxtractor",
}


def resolve_install(cmd_name: str) -> dict | None:
    """
    Resolve how to install a missing command.
    
    Returns:
        dict with keys:
            - method: "apt" or "pip"
            - package: package name
            - install_cmd: full install command
    """
    import re
    
    # Normalize command name (strip path, flags, etc.)
    cmd_clean = cmd_name.split("/")[-1].strip("-").strip()
    
    # Check apt first (most Kali tools)
    apt_pkg = COMMAND_TO_PACKAGE.get(cmd_clean) or COMMAND_TO_PACKAGE.get(cmd_clean.lower())
    if apt_pkg:
        return {
            "method": "apt",
            "package": apt_pkg,
            "install_cmd": f"apt-get install -y {apt_pkg}",
        }
    
    # Check pip (Python tools)
    pip_pkg = PIP_COMMAND_MAP.get(cmd_clean) or PIP_COMMAND_MAP.get(cmd_clean.lower())
    if pip_pkg:
        return {
            "method": "pip",
            "package": pip_pkg,
            "install_cmd": f"pip3 install --break-system-packages {pip_pkg}",
        }
    
    return None


def diagnose_error(command: str, stderr: str, returncode: int) -> dict:
    """
    Analyze a command error and return a diagnosis with suggested fix.
    
    Returns:
        dict with keys:
            - error_type: str (category of error)
            - fix_strategy: str (how to fix)
            - fix_command: str or None (specific command to run)
            - description: str (human-readable explanation)
            - needs_ai: bool (whether AI should be consulted)
    """
    error_text = stderr.strip().lower() if stderr else ""
    original_stderr = stderr.strip() if stderr else ""

    # ── PRIORITY 1: sudo itself not found ──
    # Only matches when sudo BINARY is missing: "/bin/sh: 1: sudo: not found"
    # Does NOT match "sudo: <tool>: command not found" (that's a missing subcommand)
    import re as _re
    sudo_itself_missing = (
        "sudo: not found" in error_text
        or _re.search(r'/bin/sh:.*sudo:.*not found', error_text)
    ) and not _re.search(r'sudo:.*command not found', error_text)
    
    if command.strip().startswith("sudo ") and sudo_itself_missing:
        fixed_cmd = command.strip()[5:].strip()
        return {
            "error_type": "no_sudo",
            "fix_strategy": "remove_sudo",
            "fix_command": fixed_cmd,
            "description": "sudo binary not available. Retrying without sudo (likely already root).",
            "needs_ai": False,
        }

    # ── PRIORITY 2: Missing file / No such file or directory ──
    # Must come BEFORE "command not found" since "not found" substring matches both
    missing_file_patterns = [
        "no such file or directory",
        "não foi possível acessar",
        "cannot access",
        "cannot stat",
    ]
    if any(p in error_text for p in missing_file_patterns) and returncode != 127:
        # This is a file-not-found, NOT a command-not-found
        return {
            "error_type": "missing_file",
            "fix_strategy": "ai_diagnose",
            "fix_command": None,
            "description": f"File or path not found. The target file may not exist.",
            "needs_ai": True,
        }

    # ── PRIORITY 3: Command not found (return code 127 or explicit message) ──
    # But first check for API key / authentication errors (these contain "not found" in key name)
    api_key_patterns = [
        "missing api key", "api key", "invalid api", "incorrect api",
        "authentication", "unauthorized", "api requires", "access token",
        "missing key error", "api_key", "apikey",
    ]
    if any(p in error_text for p in api_key_patterns) and returncode != 127:
        return {
            "error_type": "missing_api_key",
            "fix_strategy": "skip_or_use_free",
            "fix_command": None,
            "description": "Tool requires API keys that are not configured. Use free/no-key alternatives.",
            "needs_ai": True,
        }

    if returncode == 127 or "command not found" in error_text or "not found" in error_text:
        # Extract the missing command name robustly
        import shlex as _shlex
        try:
            parts = _shlex.split(command)
        except ValueError:
            parts = command.split()
        
        # Strip common wrappers: sudo, timeout, proxychains, env vars, bash -c
        skip_prefixes = {"sudo", "timeout", "proxychains", "proxychains4", "nice", "ionice", "strace", "ltrace"}
        cmd_name = None
        for p in parts:
            if "=" in p:  # env var like FOO=bar
                continue
            if p in skip_prefixes:
                continue
            if p.lstrip("-").isdigit():  # numeric arg for timeout etc
                continue
            cmd_name = p
            break
        if not cmd_name:
            cmd_name = parts[0] if parts else command.split()[0]
        
        # Also try to extract from stderr: "foo: command not found" or "foo: not found"
        import re as _re_cmd
        stderr_match = _re_cmd.search(r'(?:^|:\s*)(\S+):\s*(?:command )?not found', error_text)
        if stderr_match:
            cmd_name = stderr_match.group(1).strip('"\'')
        
        # Use central resolver (apt → pip)
        from src.autopilot.controller import resolve_install
        install_info = resolve_install(cmd_name)
        if install_info:
            return {
                "error_type": "missing_command",
                "fix_strategy": "install_and_retry",
                "fix_command": install_info["install_cmd"],
                "install_method": install_info["method"],
                "description": f"'{cmd_name}' not installed. Auto-installing via {install_info['method']}: {install_info['package']}",
                "needs_ai": False,
            }
        else:
            # Unknown tool — try apt-get install by guessing
            return {
                "error_type": "missing_command",
                "fix_strategy": "install_and_retry",
                "fix_command": f"apt-get install -y {cmd_name}",
                "install_method": "apt_guess",
                "description": f"'{cmd_name}' not found. Attempting apt install (best guess).",
                "needs_ai": False,
            }

    # ── PRIORITY 3: Permission denied -> try with sudo ──
    if "permission denied" in error_text:
        if not command.startswith("sudo "):
            return {
                "error_type": "permission",
                "fix_strategy": "try_sudo",
                "fix_command": f"sudo {command}",
                "description": "Permission denied. Retrying with sudo.",
                "needs_ai": False,
            }

    # Python module not found
    if "modulenotfounderror" in error_text or "importerror" in error_text:
        # Try to extract module name
        import re
        match = re.search(r"no module named ['\"]?(\w+)", error_text)
        if match:
            module = match.group(1)
            return {
                "error_type": "python_module",
                "fix_strategy": "pip_install",
                "fix_command": f"pip3 install {module}",
                "description": f"Python module '{module}' not installed.",
                "needs_ai": False,
            }

    # APT lock
    if "could not get lock" in error_text:
        return {
            "error_type": "apt_lock",
            "fix_strategy": "kill_apt",
            "fix_command": "killall -9 apt-get apt dpkg 2>/dev/null; dpkg --configure -a",
            "description": "APT is locked by another process.",
            "needs_ai": False,
        }

    # Unable to locate package
    if "unable to locate package" in error_text:
        return {
            "error_type": "package_not_found",
            "fix_strategy": "update_and_retry",
            "fix_command": f"apt-get update && {command}",
            "description": "Package not found. Updating package list and retrying.",
            "needs_ai": False,
        }

    # For any other error, let AI diagnose
    return {
        "error_type": "unknown",
        "fix_strategy": "ai_diagnose",
        "fix_command": None,
        "description": f"Error: {original_stderr[:200]}",
        "needs_ai": True,
    }
