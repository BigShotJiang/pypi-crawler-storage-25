"""
MundiX CLI - AI Provider Base Interface

Abstract base class for all AI providers (MundiX, OpenAI, Local, etc.).
Defines the contract that all providers must implement.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import AsyncIterator, Dict, List, Optional, Any


class ModelTier(str, Enum):
    """Model capability tier."""
    BRAIN = "brain"           # Strategic planning, complex analysis
    SPECIALIST = "specialist" # Domain-specific expertise
    EXECUTOR = "executor"     # Fast, simple tasks
    BACKUP = "backup"         # Fallback when others unavailable


@dataclass
class ModelInfo:
    """Information about an available model."""
    id: str
    name: str
    description: str
    context_length: int
    tier: ModelTier
    is_available: bool = True
    cost_per_token: float = 0.0


@dataclass
class ChatMessage:
    """A single message in a chat conversation."""
    role: str  # "system", "user", "assistant"
    content: str
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ChatResponse:
    """Response from an AI provider."""
    content: str
    model_used: str
    tokens_used: int = 0
    finish_reason: str = "stop"
    metadata: Dict[str, Any] = field(default_factory=dict)


class AIProvider(ABC):
    """
    Abstract base class for AI providers.
    
    All providers (MundiX, OpenAI, Ollama, etc.) must implement this interface.
    This ensures the rest of the codebase can swap providers without changes.
    """
    
    @abstractmethod
    async def initialize(self) -> bool:
        """
        Initialize the provider (authenticate, load models, etc.).
        Returns True if initialization was successful.
        """
        pass
    
    @abstractmethod
    async def shutdown(self):
        """Clean up resources (connections, caches, etc.)."""
        pass
    
    @abstractmethod
    async def chat(
        self,
        messages: List[ChatMessage],
        model: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        stream: bool = False,
        **kwargs
    ) -> ChatResponse:
        """
        Send messages and get a complete response.
        
        Args:
            messages: List of chat messages (conversation history)
            model: Model ID to use (None = default)
            temperature: Sampling temperature (0.0-1.0)
            max_tokens: Maximum tokens in response
            stream: If True, use stream() instead
            **kwargs: Provider-specific additional parameters
        
        Returns:
            ChatResponse with the AI's reply
        """
        pass
    
    @abstractmethod
    async def stream(
        self,
        messages: List[ChatMessage],
        model: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        **kwargs
    ) -> AsyncIterator[str]:
        """
        Stream response tokens as they are generated.
        
        Yields:
            Text chunks of the response
        """
        pass
    
    @abstractmethod
    async def get_models(self) -> List[ModelInfo]:
        """
        List all available models from this provider.
        
        Returns:
            List of ModelInfo objects
        """
        pass
    
    @abstractmethod
    async def get_default_model(self) -> str:
        """
        Get the default model ID for this provider.
        
        Returns:
            Model ID string
        """
        pass
    
    @abstractmethod
    async def is_available(self) -> bool:
        """
        Check if the provider is currently available and responsive.
        
        Returns:
            True if the provider can accept requests
        """
        pass
    
    @abstractmethod
    async def get_usage_stats(self) -> Dict[str, Any]:
        """
        Get usage statistics (tokens, credits, rate limits, etc.).
        
        Returns:
            Dictionary with provider-specific usage data
        """
        pass
    
    @property
    @abstractmethod
    def name(self) -> str:
        """Human-readable provider name."""
        pass
