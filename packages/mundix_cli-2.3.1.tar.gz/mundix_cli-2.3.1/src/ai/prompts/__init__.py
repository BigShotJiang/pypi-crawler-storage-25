"""MundiX CLI - Prompt templates for AI providers."""
