"""
MundiX CLI - Safety Checks

Validates commands for dangerous patterns and provides
risk assessment before execution.
"""

import re
from dataclasses import dataclass
from enum import Enum
from typing import List, Optional, Tuple


class RiskLevel(str, Enum):
    """Command risk level."""
    SAFE = "safe"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class SafetyCheck:
    """Result of a safety check on a command."""
    command: str
    risk_level: RiskLevel
    is_safe: bool
    warnings: List[str]
    blocked: bool = False


# ─── Dangerous Patterns ─────────────────────────────────────────────

DANGEROUS_PATTERNS = [
    # System destruction
    (r"rm\s+-rf\s+/", RiskLevel.CRITICAL, "Recursive root deletion"),
    (r"rm\s+-rf\s+\*", RiskLevel.CRITICAL, "Recursive wildcard deletion"),
    (r"dd\s+if=/dev/zero", RiskLevel.HIGH, "Disk zeroing"),
    (r"dd\s+if=.*of=/dev/sd", RiskLevel.CRITICAL, "Disk overwrite"),
    (r"mkfs\.", RiskLevel.HIGH, "Filesystem format"),
    (r">/dev/sd", RiskLevel.CRITICAL, "Device overwrite"),
    
    # Fork bombs
    (r":\(\)\{", RiskLevel.CRITICAL, "Fork bomb"),
    (r":\(\)\s*\{", RiskLevel.CRITICAL, "Fork bomb variant"),
    
    # Permission changes
    (r"chmod\s+-R\s+777\s+/", RiskLevel.CRITICAL, "World-writable root"),
    (r"chmod\s+777\s+/", RiskLevel.HIGH, "World-writable root"),
    (r"chown\s+-R\s+.*:/", RiskLevel.HIGH, "Recursive root ownership change"),
    
    # System control
    (r"shutdown\s+-[hP]", RiskLevel.MEDIUM, "System shutdown"),
    (r"init\s+0", RiskLevel.MEDIUM, "System halt"),
    (r"halt", RiskLevel.MEDIUM, "System halt"),
    (r"reboot", RiskLevel.MEDIUM, "System reboot"),
    (r"systemctl\s+(stop|restart)\s+ssh", RiskLevel.HIGH, "SSH service disruption"),
    
    # Network disruption
    (r"iptables\s+-F", RiskLevel.HIGH, "Firewall flush"),
    (r"iptables\s+--flush", RiskLevel.HIGH, "Firewall flush"),
    
    # Process killing
    (r"kill\s+-9\s+-?\d+", RiskLevel.MEDIUM, "Force kill processes"),
    (r"killall\s+", RiskLevel.MEDIUM, "Kill all matching processes"),
    
    # Data exfiltration (potential)
    (r"curl\s+.*\|.*bash", RiskLevel.HIGH, "Remote pipe to shell"),
    (r"wget\s+.*-O-\s*\|.*sh", RiskLevel.HIGH, "Remote pipe to shell"),
]

# ─── Pentest Tool Patterns (not dangerous, just flag for awareness) ─

PENTEST_TOOL_PATTERNS = [
    (r"nmap\s+", "Network scanner"),
    (r"masscan\s+", "Port scanner"),
    (r"sqlmap\s+", "SQL injection tool"),
    (r"hydra\s+", "Brute force tool"),
    (r"metasploit|msfconsole", "Exploitation framework"),
    (r"burpsuite|burp", "Web proxy"),
    (r"gobuster|dirb|dirbuster", "Directory brute forcer"),
    (r"hashcat|john", "Password cracker"),
    (r"aircrack|airodump", "WiFi auditing"),
    (r"responder", "LLMNR/NBT-NS poisoner"),
    (r"crackmapexec|netexec", "AD enumeration/exploitation"),
    (r"bloodhound", "AD attack path mapper"),
    (r"mimikatz", "Credential extraction"),
]


class SafetyChecker:
    """
    Checks commands for dangerous patterns.
    
    Provides risk assessment and warnings before execution.
    """
    
    def __init__(self, block_critical: bool = True):
        self.block_critical = block_critical
    
    def check(self, command: str) -> SafetyCheck:
        """
        Check a command for dangerous patterns.
        
        Args:
            command: The command to check
        
        Returns:
            SafetyCheck with risk level and warnings
        """
        warnings = []
        max_risk = RiskLevel.SAFE
        is_pentest_tool = False
        
        # Check dangerous patterns
        for pattern, risk, description in DANGEROUS_PATTERNS:
            if re.search(pattern, command, re.IGNORECASE):
                warnings.append(f"⚠️ {description}")
                if self._risk_value(risk) > self._risk_value(max_risk):
                    max_risk = risk
        
        # Check pentest tools (informational only)
        for pattern, tool_name in PENTEST_TOOL_PATTERNS:
            if re.search(pattern, command, re.IGNORECASE):
                is_pentest_tool = True
                warnings.append(f"🔧 Pentest tool: {tool_name}")
                break  # Only flag once
        
        # Determine if blocked
        blocked = self.block_critical and max_risk == RiskLevel.CRITICAL
        
        return SafetyCheck(
            command=command,
            risk_level=max_risk,
            is_safe=max_risk in (RiskLevel.SAFE, RiskLevel.LOW),
            warnings=warnings,
            blocked=blocked,
        )
    
    def is_safe(self, command: str) -> bool:
        """Quick check if a command is safe to execute."""
        return self.check(command).is_safe
    
    def should_ask_confirmation(self, command: str) -> bool:
        """Check if command requires user confirmation."""
        result = self.check(command)
        return result.risk_level in (RiskLevel.MEDIUM, RiskLevel.HIGH, RiskLevel.CRITICAL)
    
    @staticmethod
    def _risk_value(risk: RiskLevel) -> int:
        """Convert risk level to numeric value for comparison."""
        return {
            RiskLevel.SAFE: 0,
            RiskLevel.LOW: 1,
            RiskLevel.MEDIUM: 2,
            RiskLevel.HIGH: 3,
            RiskLevel.CRITICAL: 4,
        }.get(risk, 0)
