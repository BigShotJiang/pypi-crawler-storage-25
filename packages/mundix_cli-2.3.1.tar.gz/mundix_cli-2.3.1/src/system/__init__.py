"""MundiX CLI - System integration and safety."""
