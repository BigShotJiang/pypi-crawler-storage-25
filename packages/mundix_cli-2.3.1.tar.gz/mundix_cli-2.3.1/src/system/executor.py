"""
MundiX CLI - Command Executor

Safe execution of shell commands with timeout, output capture,
and automatic tool installation support.
"""

import asyncio
import shlex
import shutil
import signal
import subprocess
import time
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Tuple

from src.core.logging import get_logger

logger = get_logger("system.executor")


@dataclass
class ExecutionResult:
    """Result of a command execution."""
    command: str
    stdout: str
    stderr: str
    exit_code: int
    duration: float
    timed_out: bool = False
    killed: bool = False


class CommandExecutor:
    """
    Executes shell commands safely with timeout and output capture.
    
    Features:
    - Configurable timeout
    - Output streaming callback
    - Automatic process cleanup
    - Working directory control
    """
    
    def __init__(
        self,
        default_timeout: int = 300,
        max_output_lines: int = 2000,
        working_dir: Optional[str] = None,
        on_output: Optional[Callable[[str], None]] = None,
    ):
        self.default_timeout = default_timeout
        self.max_output_lines = max_output_lines
        self.working_dir = working_dir
        self.on_output = on_output
        self._active_processes: List[asyncio.subprocess.Process] = []
    
    async def execute(
        self,
        command: str,
        timeout: Optional[int] = None,
        shell: bool = True,
        env: Optional[Dict[str, str]] = None,
        input_data: Optional[str] = None,
    ) -> ExecutionResult:
        """
        Execute a shell command and capture output.
        
        Args:
            command: The command to execute
            timeout: Timeout in seconds (None = default)
            shell: Use shell execution
            env: Environment variables
            input_data: Input to pipe to stdin
        
        Returns:
            ExecutionResult with stdout, stderr, exit code
        """
        timeout = timeout or self.default_timeout
        start_time = time.time()
        
        logger.info(f"EXEC: {command[:100]}{'...' if len(command) > 100 else ''}")
        
        try:
            # Build command
            if shell:
                cmd = command
            else:
                cmd = shlex.split(command)
            
            # Execute
            process = await asyncio.create_subprocess_shell(
                cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                stdin=asyncio.subprocess.PIPE if input_data else None,
                cwd=self.working_dir,
                env={**self._get_env(), **(env or {})},
            )
            
            self._active_processes.append(process)
            
            try:
                stdout_bytes, stderr_bytes = await asyncio.wait_for(
                    process.communicate(input=input_data.encode() if input_data else None),
                    timeout=timeout,
                )
                
                stdout = stdout_bytes.decode("utf-8", errors="replace")
                stderr = stderr_bytes.decode("utf-8", errors="replace")
                
                # Truncate output if too long
                stdout_lines = stdout.splitlines()
                if len(stdout_lines) > self.max_output_lines:
                    stdout = "\n".join(stdout_lines[:self.max_output_lines])
                    stdout += f"\n\n[Output truncated: {len(stdout_lines) - self.max_output_lines} lines removed]"
                
                duration = time.time() - start_time
                
                logger.info(
                    f"RESULT [{process.returncode}]: {command[:50]}... ({len(stdout_lines)} lines, {duration:.1f}s)"
                )
                
                return ExecutionResult(
                    command=command,
                    stdout=stdout,
                    stderr=stderr,
                    exit_code=process.returncode or 0,
                    duration=duration,
                )
                
            except asyncio.TimeoutError:
                logger.warning(f"TIMEOUT: {command[:50]}... ({timeout}s)")
                self._kill_process(process)
                duration = time.time() - start_time
                
                return ExecutionResult(
                    command=command,
                    stdout="",
                    stderr=f"Command timed out after {timeout}s",
                    exit_code=-1,
                    duration=duration,
                    timed_out=True,
                )
        
        except Exception as e:
            duration = time.time() - start_time
            logger.error(f"ERROR: {command[:50]}... - {e}")
            
            return ExecutionResult(
                command=command,
                stdout="",
                stderr=str(e),
                exit_code=-1,
                duration=duration,
            )
        
        finally:
            if process in self._active_processes:
                self._active_processes.remove(process)
    
    def execute_sync(
        self,
        command: str,
        timeout: Optional[int] = None,
    ) -> ExecutionResult:
        """Synchronous command execution (for non-async contexts)."""
        timeout = timeout or self.default_timeout
        start_time = time.time()
        
        logger.info(f"EXEC (sync): {command[:100]}")
        
        try:
            process = subprocess.Popen(
                command,
                shell=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                cwd=self.working_dir,
                env={**self._get_env()},
            )
            
            self._active_processes.append(process)
            
            try:
                stdout_bytes, stderr_bytes = process.communicate(timeout=timeout)
                stdout = stdout_bytes.decode("utf-8", errors="replace")
                stderr = stderr_bytes.decode("utf-8", errors="replace")
                
                duration = time.time() - start_time
                
                return ExecutionResult(
                    command=command,
                    stdout=stdout,
                    stderr=stderr,
                    exit_code=process.returncode or 0,
                    duration=duration,
                )
            
            except subprocess.TimeoutExpired:
                self._kill_process_sync(process)
                duration = time.time() - start_time
                
                return ExecutionResult(
                    command=command,
                    stdout="",
                    stderr=f"Command timed out after {timeout}s",
                    exit_code=-1,
                    duration=duration,
                    timed_out=True,
                )
        
        except Exception as e:
            duration = time.time() - start_time
            return ExecutionResult(
                command=command,
                stdout="",
                stderr=str(e),
                exit_code=-1,
                duration=duration,
            )
        
        finally:
            if process in self._active_processes:
                self._active_processes.remove(process)
    
    def _kill_process(self, process: asyncio.subprocess.Process):
        """Kill an async process."""
        try:
            process.kill()
        except Exception:
            pass
    
    def _kill_process_sync(self, process: subprocess.Popen):
        """Kill a sync process."""
        try:
            process.kill()
        except Exception:
            pass
    
    def _get_env(self) -> Dict[str, str]:
        """Get environment variables for execution."""
        import os
        env = os.environ.copy()
        # Add Kali-specific paths
        env["PATH"] = f"{env.get('PATH', '')}:/usr/share/kali-linux:/usr/local/sbin:/usr/sbin"
        return env
    
    async def cleanup(self):
        """Kill all active processes."""
        for process in self._active_processes:
            try:
                process.kill()
            except Exception:
                pass
        self._active_processes.clear()
        logger.info("Cleaned up active processes")
    
    def tool_exists(self, tool_name: str) -> bool:
        """Check if a tool is available on the system."""
        return shutil.which(tool_name) is not None
    
    def find_tool_path(self, tool_name: str) -> Optional[str]:
        """Find the full path of a tool."""
        return shutil.which(tool_name)
