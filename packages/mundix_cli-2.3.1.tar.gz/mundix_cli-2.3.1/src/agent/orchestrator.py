"""
MundiX CLI v2.0 - Agent Orchestrator

The autonomous decision loop for pentesting.
Refactored from the legacy 2893-line monolith into clean, testable modules.

Architecture:
    Orchestrator
    ├── Planner (generates pentest plan from engagement type)
    ├── Executor (runs skills and commands)
    ├── Analyzer (interprets results with AI)
    └── Reporter (generates final report)
"""

import json
import os
import re
import shlex
import signal
import subprocess
import tempfile
import time
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

from src.core.logging import get_logger, timer
from src.skills.models import Skill, SkillPhase, SkillCommand, SkillResult, SkillStatus, CommandResult, CommandStatus
from src.skills.loader import SkillLoader
from src.system.executor import CommandExecutor, ExecutionResult
from src.system.safety import SafetyChecker, RiskLevel

logger = get_logger("agent.orchestrator")


# ─── Engagement Profiles ────────────────────────────────────────────

ENGAGEMENT_PROFILES = {
    "web": {
        "description": "Web Application Penetration Test",
        "phases": [
            "1_reconnaissance",
            "2_scanning",
            "3_vulnerability_analysis",
            "4_exploitation",
            "5_post_exploitation",
            "6_reporting",
        ],
        "skip_skills": [],
        "required_vars": ["target_domain"],
    },
    "internal": {
        "description": "Internal Network Penetration Test",
        "phases": [
            "1_reconnaissance",
            "2_scanning",
            "3_vulnerability_analysis",
            "4_exploitation",
            "5_post_exploitation",
            "6_reporting",
        ],
        "skip_skills": ["osint_domain_enumeration", "osint_email_harvesting"],
        "required_vars": ["target_ip", "target_range"],
    },
    "app": {
        "description": "Application Security Assessment",
        "phases": [
            "1_reconnaissance",
            "2_scanning",
            "3_vulnerability_analysis",
            "4_exploitation",
            "6_reporting",
        ],
        "skip_skills": [
            "smb_rpc_enumeration", "dns_zone_transfer",
            "linux_privilege_escalation", "windows_privilege_escalation",
            "lateral_movement_psexec", "hash_dumping_and_cracking",
        ],
        "required_vars": ["target_domain"],
    },
}


# ─── Enums ──────────────────────────────────────────────────────────

class EngagementStatus(str, Enum):
    IDLE = "idle"
    PLANNING = "planning"
    RUNNING = "running"
    PAUSED = "paused"
    WAITING_INPUT = "waiting_input"
    COMPLETED = "completed"
    FAILED = "failed"
    ABORTED = "aborted"


# ─── Data Models ────────────────────────────────────────────────────

@dataclass
class SkillExecution:
    """Tracks the execution state of a single skill."""
    skill_name: str
    status: SkillStatus = SkillStatus.PENDING
    started_at: Optional[str] = None
    completed_at: Optional[str] = None
    commands_executed: List[Dict] = field(default_factory=list)
    findings: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    ai_decisions: List[str] = field(default_factory=list)
    output_files: List[str] = field(default_factory=list)
    skip_reason: Optional[str] = None

    def start(self):
        self.status = SkillStatus.RUNNING
        self.started_at = datetime.now().isoformat()

    def complete(self, findings: List[str] = None):
        self.status = SkillStatus.COMPLETED
        self.completed_at = datetime.now().isoformat()
        if findings:
            self.findings.extend(findings)

    def fail(self, error: str):
        self.status = SkillStatus.FAILED
        self.completed_at = datetime.now().isoformat()
        self.errors.append(error)

    def skip(self, reason: str):
        self.status = SkillStatus.SKIPPED
        self.skip_reason = reason


@dataclass
class EngagementState:
    """Full state of the current pentest engagement."""
    target: str
    engagement_type: str
    status: EngagementStatus = EngagementStatus.IDLE
    workspace: str = ""
    variables: Dict[str, str] = field(default_factory=dict)
    current_phase: str = ""
    current_skill: str = ""
    findings: Dict[str, bool] = field(default_factory=dict)
    discovered_hosts: List[str] = field(default_factory=list)
    discovered_ports: List[Dict] = field(default_factory=list)
    discovered_vulns: List[Dict] = field(default_factory=list)
    discovered_creds: List[Dict] = field(default_factory=list)
    timeline: List[Dict] = field(default_factory=list)
    skill_executions: Dict[str, SkillExecution] = field(default_factory=dict)
    started_at: Optional[str] = None
    completed_at: Optional[str] = None

    def start(self):
        self.status = EngagementStatus.RUNNING
        self.started_at = datetime.now().isoformat()

    def complete(self):
        self.status = EngagementStatus.COMPLETED
        self.completed_at = datetime.now().isoformat()

    def add_timeline_event(self, event_type: str, description: str, data: Dict = None):
        self.timeline.append({
            "timestamp": datetime.now().isoformat(),
            "type": event_type,
            "description": description,
            "data": data or {},
        })

    def get_completed_skills(self) -> List[str]:
        return [
            name for name, ex in self.skill_executions.items()
            if ex.status == SkillStatus.COMPLETED
        ]

    def get_progress(self) -> Dict:
        total = len(self.skill_executions)
        completed = len(self.get_completed_skills())
        failed = len([e for e in self.skill_executions.values() if e.status == SkillStatus.FAILED])
        skipped = len([e for e in self.skill_executions.values() if e.status == SkillStatus.SKIPPED])
        return {
            "total": total,
            "completed": completed,
            "failed": failed,
            "skipped": skipped,
            "remaining": total - completed - failed - skipped,
            "percent": round((completed / total) * 100, 1) if total > 0 else 0,
            "current_phase": self.current_phase,
            "current_skill": self.current_skill,
        }

    def get_context_summary(self) -> str:
        """Generate a context summary for the AI."""
        lines = [
            f"## Engagement State",
            f"**Target:** {self.target}",
            f"**Type:** {self.engagement_type}",
            f"**Phase:** {self.current_phase}",
            f"**Progress:** {self.get_progress()['percent']}%",
            "",
        ]
        if self.discovered_hosts:
            lines.append(f"**Discovered Hosts:** {', '.join(self.discovered_hosts[:20])}")
        if self.discovered_ports:
            lines.append(f"**Open Ports:** {len(self.discovered_ports)} found")
            for p in self.discovered_ports[:15]:
                lines.append(f"  - {p.get('host', '?')}:{p.get('port', '?')} ({p.get('service', 'unknown')})")
        if self.discovered_vulns:
            lines.append(f"**Vulnerabilities:** {len(self.discovered_vulns)} found")
            for v in self.discovered_vulns[:10]:
                lines.append(f"  - [{v.get('severity', '?')}] {v.get('name', 'unknown')}")
        if self.discovered_creds:
            lines.append(f"**Credentials:** {len(self.discovered_creds)} found")
        completed = self.get_completed_skills()
        if completed:
            lines.append(f"\n**Completed Skills:** {', '.join(completed[-5:])}")
        return '\n'.join(lines)

    def save(self, filepath: str):
        """Save engagement state to JSON."""
        data = {
            "target": self.target,
            "engagement_type": self.engagement_type,
            "status": self.status.value,
            "workspace": self.workspace,
            "variables": self.variables,
            "current_phase": self.current_phase,
            "current_skill": self.current_skill,
            "findings": self.findings,
            "discovered_hosts": self.discovered_hosts,
            "discovered_ports": self.discovered_ports,
            "discovered_vulns": self.discovered_vulns,
            "discovered_creds": self.discovered_creds,
            "timeline": self.timeline,
            "started_at": self.started_at,
            "completed_at": self.completed_at,
            "skill_executions": {k: v.__dict__ for k, v in self.skill_executions.items()},
            "progress": self.get_progress(),
        }
        Path(filepath).parent.mkdir(parents=True, exist_ok=True)
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2, default=str)

    @classmethod
    def load(cls, filepath: str) -> 'EngagementState':
        """Load engagement state from JSON."""
        with open(filepath) as f:
            data = json.load(f)
        state = cls(target=data["target"], engagement_type=data["engagement_type"])
        state.status = EngagementStatus(data.get("status", "idle"))
        state.workspace = data.get("workspace", "")
        state.variables = data.get("variables", {})
        state.current_phase = data.get("current_phase", "")
        state.current_skill = data.get("current_skill", "")
        state.findings = data.get("findings", {})
        state.discovered_hosts = data.get("discovered_hosts", [])
        state.discovered_ports = data.get("discovered_ports", [])
        state.discovered_vulns = data.get("discovered_vulns", [])
        state.discovered_creds = data.get("discovered_creds", [])
        state.timeline = data.get("timeline", [])
        state.started_at = data.get("started_at")
        state.completed_at = data.get("completed_at")
        return state


# ─── Agent Orchestrator ─────────────────────────────────────────────

class AgentOrchestrator:
    """
    The brain of MundiX autonomous pentesting.
    
    Plans, executes, and analyzes pentest engagements using skills
    and AI-driven decision making.
    """
    
    def __init__(
        self,
        ai_provider=None,
        skill_loader: Optional[SkillLoader] = None,
        executor: Optional[CommandExecutor] = None,
        safety_checker: Optional[SafetyChecker] = None,
        autopilot_level: int = 1,
        workspace: str = "",
        on_progress: Optional[Callable[[Dict], None]] = None,
        on_finding: Optional[Callable[[Dict], None]] = None,
    ):
        self.ai_provider = ai_provider
        self.skill_loader = skill_loader or SkillLoader()
        self.executor = executor or CommandExecutor()
        self.safety = safety_checker or SafetyChecker()
        self.autopilot_level = autopilot_level
        self.workspace = workspace
        self.on_progress = on_progress
        self.on_finding = on_finding
        
        self.state: Optional[EngagementState] = None
        self._skills_cache: Optional[Dict[str, Skill]] = None
        self._aborted = False
    
    def abort(self):
        """Signal the orchestrator to abort."""
        self._aborted = True
        logger.info("Abort signal received")
    
    # ─── Planning ────────────────────────────────────────────────────
    
    def create_engagement(self, target: str, engagement_type: str = "web") -> EngagementState:
        """Create a new engagement."""
        profile = ENGAGEMENT_PROFILES.get(engagement_type, ENGAGEMENT_PROFILES["web"])
        
        self.state = EngagementState(
            target=target,
            engagement_type=engagement_type,
            workspace=self.workspace or f"/tmp/mundix_{target.replace('.', '_')}",
        )
        self.state.variables["target"] = target
        if engagement_type == "web":
            self.state.variables["target_domain"] = target
        else:
            self.state.variables["target_ip"] = target
        
        # Create workspace
        Path(self.state.workspace).mkdir(parents=True, exist_ok=True)
        
        logger.info(f"Engagement created: {target} ({engagement_type})")
        return self.state
    
    def generate_plan(self) -> List[Dict]:
        """
        Generate a pentest plan based on engagement type.
        
        Returns:
            List of phase/skill dictionaries to execute
        """
        if not self.state:
            raise RuntimeError("No engagement. Call create_engagement() first.")
        
        profile = ENGAGEMENT_PROFILES.get(self.state.engagement_type, ENGAGEMENT_PROFILES["web"])
        skills = self.skill_loader.load_all()
        skip_skills = set(profile.get("skip_skills", []))
        
        plan = []
        for phase_str in profile["phases"]:
            phase_skills = []
            for name, skill in skills.items():
                if skill.phase.value == phase_str and name not in skip_skills:
                    phase_skills.append({
                        "skill_name": name,
                        "phase": phase_str,
                        "status": "pending",
                    })
            
            plan.append({
                "phase": phase_str,
                "skills": phase_skills,
            })
            
            # Create skill execution trackers
            for sk in phase_skills:
                self.state.skill_executions[sk["skill_name"]] = SkillExecution(skill_name=sk["skill_name"])
        
        logger.info(f"Plan generated: {len(plan)} phases, {sum(len(p['skills']) for p in plan)} skills")
        return plan
    
    # ─── Execution ───────────────────────────────────────────────────
    
    async def execute_plan(self, plan: List[Dict]) -> EngagementState:
        """
        Execute the full pentest plan.
        
        Args:
            plan: Plan from generate_plan()
        
        Returns:
            Final engagement state
        """
        if not self.state:
            raise RuntimeError("No engagement")
        
        self.state.start()
        self._aborted = False
        
        for phase_info in plan:
            if self._aborted:
                self.state.status = EngagementStatus.ABORTED
                break
            
            phase_str = phase_info["phase"]
            self.state.current_phase = phase_str
            self.state.add_timeline_event("phase_start", f"Starting phase: {phase_str}")
            logger.info(f"Phase: {phase_str}")
            
            for skill_info in phase_info["skills"]:
                if self._aborted:
                    break
                
                skill_name = skill_info["skill_name"]
                self.state.current_skill = skill_name
                
                skill = self.skill_loader.get_skill(skill_name)
                if not skill:
                    logger.warning(f"Skill not found: {skill_name}")
                    continue
                
                await self._execute_skill(skill)
                
                if self.on_progress:
                    self.on_progress(self.state.get_progress())
            
            self.state.add_timeline_event("phase_complete", f"Completed phase: {phase_str}")
        
        if not self._aborted:
            self.state.complete()
        
        # Save final state
        if self.state.workspace:
            self.state.save(os.path.join(self.state.workspace, "engagement.json"))
        
        return self.state
    
    async def _execute_skill(self, skill: Skill) -> SkillResult:
        """Execute a single skill."""
        exec_state = self.state.skill_executions.get(skill.name)
        if not exec_state:
            exec_state = SkillExecution(skill_name=skill.name)
            self.state.skill_executions[skill.name] = exec_state
        
        exec_state.start()
        logger.info(f"Executing skill: {skill.name}")
        
        result = SkillResult(skill=skill, status=SkillStatus.RUNNING)
        
        for cmd in skill.commands:
            if self._aborted:
                result.status = SkillStatus.FAILED
                result.error = "Aborted"
                exec_state.fail("Aborted")
                return result
            
            # Render command
            try:
                rendered = cmd.render(self.state.variables)
            except Exception as e:
                logger.warning(f"Failed to render command: {e}")
                rendered = cmd.command
            
            # Safety check
            safety = self.safety.check(rendered)
            if safety.blocked and self.autopilot_level < 5:
                logger.warning(f"Command blocked: {rendered[:50]}")
                exec_state.errors.append(f"Blocked: {rendered[:100]}")
                if cmd.on_failure == "abort":
                    result.status = SkillStatus.FAILED
                    result.error = "Command blocked by safety check"
                    exec_state.fail(result.error)
                    return result
                continue
            
            # Execute
            try:
                exec_result = await self.executor.execute(
                    rendered,
                    timeout=cmd.timeout,
                )
                
                cmd_result = CommandResult(
                    command=rendered,
                    status=CommandStatus.SUCCESS if exec_result.exit_code == 0 else CommandStatus.FAILED,
                    stdout=exec_result.stdout,
                    stderr=exec_result.stderr,
                    exit_code=exec_result.exit_code,
                    duration=exec_result.duration,
                )
                result.command_results.append(cmd_result)
                
                exec_state.commands_executed.append({
                    "command": rendered,
                    "exit_code": exec_result.exit_code,
                    "duration": exec_result.duration,
                })
                
                # Extract findings
                findings = self._extract_findings(rendered, exec_result.stdout, exec_result.stderr)
                if findings:
                    result.findings.extend(findings)
                    exec_state.findings.extend(findings)
                    for f in findings:
                        self.state.findings[f] = True
                        if self.on_finding:
                            self.on_finding({"skill": skill.name, "finding": f})
                
            except Exception as e:
                logger.error(f"Skill command failed: {e}")
                cmd_result = CommandResult(
                    command=rendered,
                    status=CommandStatus.FAILED,
                    stderr=str(e),
                )
                result.command_results.append(cmd_result)
                exec_state.errors.append(str(e))
                
                if cmd.on_failure == "abort":
                    result.status = SkillStatus.FAILED
                    result.error = str(e)
                    exec_state.fail(result.error)
                    return result
        
        result.status = SkillStatus.COMPLETED
        exec_state.complete(findings=result.findings)
        return result
    
    def _extract_findings(self, command: str, stdout: str, stderr: str) -> List[str]:
        """Extract security findings from command output."""
        findings = []
        
        # Common vulnerability patterns
        vuln_patterns = [
            (r'CVE-\d{4}-\d{4,}', "CVE"),
            (r'(?i)(vulnerability|vuln|exploit|weakness)', "Potential vulnerability"),
            (r'(?i)(injection|xss|csrf|ssrf|idor)', "Web vulnerability"),
            (r'(?i)(default.?password|anonymous.?login|empty.?password)', "Credential issue"),
            (r'(?i)(outdated|deprecated|end.?of.?life|EOL)', "Outdated software"),
            (r'(?i)(open\s+port|service\s+running|listening)', "Open service"),
        ]
        
        for pattern, label in vuln_patterns:
            matches = re.findall(pattern, stdout)
            for match in matches[:5]:  # Limit per pattern
                findings.append(f"{label}: {match}")
        
        return findings
    
    # ─── AI Analysis ─────────────────────────────────────────────────
    
    async def analyze_results(self) -> str:
        """Use AI to analyze current engagement results."""
        if not self.ai_provider or not self.state:
            return "No AI provider or engagement state available"
        
        from src.ai.base import ChatMessage
        
        context = self.state.get_context_summary()
        prompt = f"""Analyze the current pentest engagement and provide:
1. Summary of findings
2. Risk assessment
3. Recommended next steps
4. Critical vulnerabilities to prioritize

Context:
{context}"""
        
        messages = [
            ChatMessage(role="system", content="You are a senior penetration tester analyzing engagement results."),
            ChatMessage(role="user", content=prompt),
        ]
        
        try:
            response = await self.ai_provider.chat(messages)
            return response.content
        except Exception as e:
            logger.error(f"AI analysis failed: {e}")
            return f"Analysis failed: {e}"
