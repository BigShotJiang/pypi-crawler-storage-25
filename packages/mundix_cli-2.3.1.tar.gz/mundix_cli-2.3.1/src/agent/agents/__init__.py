"""MundiX CLI - Specialized agent implementations."""
