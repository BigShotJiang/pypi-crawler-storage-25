"""MundiX CLI - Report templates."""
