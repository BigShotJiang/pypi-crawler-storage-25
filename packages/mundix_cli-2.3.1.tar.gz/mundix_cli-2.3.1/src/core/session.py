"""
MundiX CLI - Session Management

Manages the lifecycle of a MundiX session including:
- Chat history with AI
- Active project context
- Execution state
- Memory references
"""

import uuid
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional

from src.ai.base import ChatMessage
from src.core.logging import get_logger

logger = get_logger("core.session")


@dataclass
class SessionContext:
    """
    Holds all context for the current session.
    
    This includes target information, discovered assets,
    execution state, and user preferences.
    """
    session_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    started_at: datetime = field(default_factory=datetime.now)
    
    # Target information
    target_host: Optional[str] = None
    target_domain: Optional[str] = None
    target_range: Optional[str] = None
    target_ports: List[int] = field(default_factory=list)
    
    # Engagement type
    engagement_type: str = "web"  # web, internal, app
    
    # Discovered assets
    discovered_hosts: List[Dict[str, Any]] = field(default_factory=list)
    open_services: List[Dict[str, Any]] = field(default_factory=list)
    vulnerabilities: List[Dict[str, Any]] = field(default_factory=list)
    
    # Execution state
    current_phase: str = ""
    current_skill: str = ""
    variables: Dict[str, str] = field(default_factory=dict)
    
    # Workspace
    workspace_dir: Optional[str] = None
    
    def update_variable(self, key: str, value: str):
        """Update a session variable."""
        self.variables[key] = value
        logger.debug(f"Variable updated: {key}={value}")
    
    def get_variable(self, key: str, default: str = "") -> str:
        """Get a session variable."""
        return self.variables.get(key, default)
    
    def add_discovered_host(self, host: Dict[str, Any]):
        """Add a discovered host to context."""
        self.discovered_hosts.append(host)
        logger.info(f"Discovered host: {host.get('ip', 'unknown')}")
    
    def add_open_service(self, service: Dict[str, Any]):
        """Add an open service to context."""
        self.open_services.append(service)
        logger.info(f"Open service: {service.get('host')}:{service.get('port')}")
    
    def add_vulnerability(self, vuln: Dict[str, Any]):
        """Add a vulnerability to context."""
        self.vulnerabilities.append(vuln)
        logger.warning(f"Vulnerability found: {vuln.get('id', 'unknown')}")
    
    def to_context_string(self) -> str:
        """Format context as a string for AI prompts."""
        parts = [
            f"Session: {self.session_id[:8]}",
            f"Target: {self.target_host or self.target_domain or 'Not set'}",
            f"Type: {self.engagement_type}",
            f"Phase: {self.current_phase or 'Not started'}",
        ]
        
        if self.discovered_hosts:
            parts.append(f"Hosts found: {len(self.discovered_hosts)}")
        if self.open_services:
            parts.append(f"Services found: {len(self.open_services)}")
        if self.vulnerabilities:
            parts.append(f"Vulnerabilities: {len(self.vulnerabilities)}")
        
        if self.variables:
            parts.append(f"Variables: {self.variables}")
        
        return " | ".join(parts)
    
    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "session_id": self.session_id,
            "started_at": self.started_at.isoformat(),
            "target_host": self.target_host,
            "target_domain": self.target_domain,
            "target_range": self.target_range,
            "target_ports": self.target_ports,
            "engagement_type": self.engagement_type,
            "discovered_hosts": self.discovered_hosts,
            "open_services": self.open_services,
            "vulnerabilities": self.vulnerabilities,
            "current_phase": self.current_phase,
            "current_skill": self.current_skill,
            "variables": self.variables,
            "workspace_dir": self.workspace_dir,
        }


class SessionManager:
    """
    Manages the current session lifecycle.
    """
    
    def __init__(self):
        self._current_session: Optional[SessionContext] = None
        self._chat_history: List[ChatMessage] = []
    
    def create_session(self, **kwargs) -> SessionContext:
        """Create a new session."""
        self._current_session = SessionContext(**kwargs)
        self._chat_history.clear()
        logger.info(f"New session created: {self._current_session.session_id[:8]}")
        return self._current_session
    
    def get_session(self) -> Optional[SessionContext]:
        """Get the current session."""
        return self._current_session
    
    def end_session(self):
        """End the current session."""
        if self._current_session:
            logger.info(f"Session ended: {self._current_session.session_id[:8]}")
            self._current_session = None
            self._chat_history.clear()
    
    def add_message(self, role: str, content: str, **metadata) -> ChatMessage:
        """Add a message to the chat history."""
        msg = ChatMessage(role=role, content=content, metadata=metadata)
        self._chat_history.append(msg)
        return msg
    
    def get_chat_history(self, max_messages: int = 50) -> List[ChatMessage]:
        """Get recent chat history."""
        return self._chat_history[-max_messages:]
    
    def clear_history(self):
        """Clear chat history."""
        self._chat_history.clear()
    
    def get_context_summary(self) -> str:
        """Get a summary of the current session context."""
        if not self._current_session:
            return "No active session"
        return self._current_session.to_context_string()
