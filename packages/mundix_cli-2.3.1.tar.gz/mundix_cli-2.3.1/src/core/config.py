"""
MundiX CLI - Configuration Management

Handles loading, saving, and validation of user configuration.
Supports environment variable overrides and provides typed access.
"""

import os
import json
from pathlib import Path
from typing import Any, Dict, Optional
from dataclasses import dataclass, field, asdict

# ─── Constants ──────────────────────────────────────────────────────

CONFIG_DIR = Path.home() / ".mundix"
CONFIG_FILE = CONFIG_DIR / "config.json"
DEFAULT_BACKEND_URL = "https://chat.mundix.dev/api"


# ─── Configuration Dataclass ────────────────────────────────────────

@dataclass
class MundiXConfig:
    """
    Centralized configuration for MundiX CLI.
    
    All settings are typed and have sensible defaults.
    Environment variables override file values (MUNDIX_* prefix).
    """
    
    # AI Provider
    backend_url: str = DEFAULT_BACKEND_URL
    api_key: str = ""
    default_model: str = "mx-deephat-7b"
    
    # Autopilot
    autopilot_level: int = 1  # 1-5
    
    # Project
    default_project_dir: str = str(Path.home() / ".mundix" / "projects")
    
    # Logging
    log_level: str = "INFO"  # DEBUG, INFO, WARNING, ERROR
    log_structured: bool = False
    
    # Skills
    skills_dir: str = ""  # Auto-detected if empty
    
    # Memory
    memory_enabled: bool = True
    memory_max_entries: int = 1000
    
    # System
    command_timeout: int = 300  # seconds
    max_output_lines: int = 200
    
    # UI
    theme: str = "mundix"
    show_animation: bool = True
    
    # Internal
    device_id: str = ""
    credits_remaining: int = 0
    last_update_check: str = ""
    
    def apply_env_overrides(self):
        """Apply environment variable overrides."""
        env_map = {
            "MUNDIX_BACKEND_URL": "backend_url",
            "MUNDIX_API_KEY": "api_key",
            "MUNDIX_DEFAULT_MODEL": "default_model",
            "MUNDIX_AUTOPILOT_LEVEL": "autopilot_level",
            "MUNDIX_LOG_LEVEL": "log_level",
            "MUNDIX_LOG_STRUCTURED": "log_structured",
            "MUNDIX_SKILLS_DIR": "skills_dir",
            "MUNDIX_MEMORY_ENABLED": "memory_enabled",
            "MUNDIX_COMMAND_TIMEOUT": "command_timeout",
            "MUNDIX_SHOW_ANIMATION": "show_animation",
        }
        for env_var, attr in env_map.items():
            value = os.environ.get(env_var)
            if value is not None:
                # Type conversion
                if isinstance(getattr(self, attr), bool):
                    value = value.lower() in ("true", "1", "yes")
                elif isinstance(getattr(self, attr), int):
                    value = int(value)
                setattr(self, attr, value)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return asdict(self)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "MundiXConfig":
        """Create from dictionary (ignores unknown keys)."""
        known_keys = {f.name for f in cls.__dataclass_fields__.values()}
        filtered = {k: v for k, v in data.items() if k in known_keys}
        return cls(**filtered)


# ─── Config Manager ─────────────────────────────────────────────────

class ConfigManager:
    """Manages loading and saving of MundiX configuration."""
    
    def __init__(self, config_file: Optional[Path] = None):
        self.config_file = config_file or CONFIG_FILE
        self._config: Optional[MundiXConfig] = None
    
    def load(self) -> MundiXConfig:
        """Load configuration from file, with defaults as fallback."""
        if self._config is not None:
            return self._config
        
        if self.config_file.exists():
            try:
                with open(self.config_file, "r") as f:
                    data = json.load(f)
                self._config = MundiXConfig.from_dict(data)
            except (json.JSONDecodeError, IOError) as e:
                print(f"Warning: Failed to load config: {e}. Using defaults.")
                self._config = MundiXConfig()
        else:
            self._config = MundiXConfig()
        
        # Apply environment variable overrides
        self._config.apply_env_overrides()
        return self._config
    
    def save(self, config: Optional[MundiXConfig] = None):
        """Save configuration to file."""
        config = config or self._config
        if config is None:
            return
        
        self.config_file.parent.mkdir(parents=True, exist_ok=True)
        try:
            with open(self.config_file, "w") as f:
                json.dump(config.to_dict(), f, indent=2)
        except IOError as e:
            print(f"Warning: Failed to save config: {e}")
    
    def update(self, **kwargs) -> MundiXConfig:
        """Update specific settings and save."""
        config = self.load()
        for key, value in kwargs.items():
            if hasattr(config, key):
                setattr(config, key, value)
        self.save(config)
        return config
    
    def get(self) -> MundiXConfig:
        """Get current configuration (loads if needed)."""
        return self.load()


# ─── Global Config Instance ─────────────────────────────────────────

_config_manager = ConfigManager()

def get_config() -> MundiXConfig:
    """Get the global configuration instance."""
    return _config_manager.get()

def update_config(**kwargs) -> MundiXConfig:
    """Update global configuration."""
    return _config_manager.update(**kwargs)
