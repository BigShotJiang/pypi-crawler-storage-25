"""
MundiX CLI - Structured Logging System

Provides consistent logging across all modules with:
- Log levels (DEBUG, INFO, WARNING, ERROR, CRITICAL)
- Structured log entries with context
- File and console handlers
- Performance timing utilities
"""

import logging
import sys
import time
import json
from pathlib import Path
from typing import Optional, Any, Dict
from contextlib import contextmanager
from datetime import datetime

# ─── Log Configuration ──────────────────────────────────────────────

LOG_DIR = Path.home() / ".mundix" / "logs"
LOG_FILE = LOG_DIR / "mundix.log"
LOG_FORMAT = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
LOG_DATE_FORMAT = "%Y-%m-%d %H:%M:%S"


class StructuredFormatter(logging.Formatter):
    """JSON-like structured formatter for machine-readable logs."""

    def format(self, record: logging.LogRecord) -> str:
        log_entry = {
            "timestamp": self.formatTime(record, self.datefmt),
            "level": record.levelname,
            "module": record.name,
            "message": record.getMessage(),
        }
        if hasattr(record, "context"):
            log_entry["context"] = record.context
        if record.exc_info and record.exc_info[0] is not None:
            log_entry["exception"] = self.formatException(record.exc_info)
        return json.dumps(log_entry, ensure_ascii=False)


class ColorFormatter(logging.Formatter):
    """Colored console formatter for human-readable output."""

    COLORS = {
        "DEBUG": "\033[36m",      # Cyan
        "INFO": "\033[32m",       # Green
        "WARNING": "\033[33m",    # Yellow
        "ERROR": "\033[31m",      # Red
        "CRITICAL": "\033[35m",   # Magenta
    }
    RESET = "\033[0m"

    def format(self, record: logging.LogRecord) -> str:
        color = self.COLORS.get(record.levelname, self.RESET)
        record.levelname = f"{color}{record.levelname}{self.RESET}"
        return super().format(record)


# ─── Logger Setup ───────────────────────────────────────────────────

def setup_logging(
    level: int = logging.INFO,
    log_file: Optional[Path] = None,
    structured: bool = False,
    console: bool = True,
) -> logging.Logger:
    """
    Configure the root MundiX logger with file and console handlers.

    Args:
        level: Minimum log level to record
        log_file: Path to log file (default: ~/.mundix/logs/mundix.log)
        structured: Use JSON structured format for file logs
        console: Enable console output handler

    Returns:
        Configured logger instance
    """
    log_file = log_file or LOG_FILE
    log_file.parent.mkdir(parents=True, exist_ok=True)

    root_logger = logging.getLogger("mundix")
    root_logger.setLevel(level)

    # Clear existing handlers
    root_logger.handlers.clear()

    # File handler (always structured for machine parsing)
    file_handler = logging.FileHandler(log_file)
    file_handler.setLevel(logging.DEBUG)  # Capture everything to file
    file_format = StructuredFormatter() if structured else logging.Formatter(LOG_FORMAT, LOG_DATE_FORMAT)
    file_handler.setFormatter(file_format)
    root_logger.addHandler(file_handler)

    # Console handler (colored for humans)
    if console:
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(level)
        console_format = ColorFormatter(LOG_FORMAT, LOG_DATE_FORMAT)
        console_handler.setFormatter(console_format)
        root_logger.addHandler(console_handler)

    root_logger.info("Logging system initialized")
    return root_logger


def get_logger(name: str) -> logging.Logger:
    """Get a child logger under the mundix namespace."""
    return logging.getLogger(f"mundix.{name}")


# ─── Performance Timing ─────────────────────────────────────────────

@contextmanager
def timer(logger: logging.Logger, operation: str, context: Optional[Dict[str, Any]] = None):
    """
    Context manager for timing operations.

    Usage:
        with timer(logger, "scan_target", {"target": "10.0.0.1"}):
            run_scan()
    """
    start = time.time()
    logger.info(f"Starting: {operation}", extra={"context": context or {}})
    try:
        yield
        elapsed = time.time() - start
        logger.info(f"Completed: {operation} ({elapsed:.2f}s)", extra={"context": context or {}})
    except Exception as e:
        elapsed = time.time() - start
        logger.error(f"Failed: {operation} ({elapsed:.2f}s): {e}", extra={"context": context or {}})
        raise


# ─── Convenience Functions ──────────────────────────────────────────

def log_command(logger: logging.Logger, command: str, **kwargs):
    """Log a command being executed."""
    logger.info(f"EXEC: {command}", extra={"context": {"command": command, **kwargs}})


def log_result(logger: logging.Logger, command: str, success: bool, output_lines: int = 0, **kwargs):
    """Log command execution result."""
    status = "OK" if success else "FAIL"
    logger.info(
        f"RESULT [{status}]: {command} ({output_lines} lines)",
        extra={"context": {"command": command, "success": success, "output_lines": output_lines, **kwargs}}
    )


def log_agent_decision(logger: logging.Logger, agent: str, decision: str, reason: str, **kwargs):
    """Log an agent's decision for audit trail."""
    logger.info(
        f"AGENT [{agent}]: {decision}",
        extra={"context": {"agent": agent, "decision": decision, "reason": reason, **kwargs}}
    )


def log_skill_execution(logger: logging.Logger, skill: str, status: str, **kwargs):
    """Log skill execution status."""
    logger.info(
        f"SKILL [{skill}]: {status}",
        extra={"context": {"skill": skill, "status": status, **kwargs}}
    )
