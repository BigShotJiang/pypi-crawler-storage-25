"""
MundiX CLI v2.0 - Core Engine

The main orchestrator that ties all modules together:
- AI Provider management
- Session management
- Skill execution via Agent Orchestrator
- Memory integration
- System execution
- Project management
- Report generation
"""

import asyncio
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, AsyncIterator, Callable, Dict, List, Optional

from src.ai.base import AIProvider, ChatMessage, ChatResponse
from src.core.config import MundiXConfig, get_config
from src.core.logging import get_logger, timer
from src.core.session import SessionContext, SessionManager
from src.memory.base import MemoryBackend, MemoryEntry, MemoryType
from src.skills.models import Skill, SkillResult, SkillStatus
from src.system.executor import CommandExecutor, ExecutionResult
from src.system.safety import SafetyChecker, RiskLevel

logger = get_logger("core.engine")


@dataclass
class EngineState:
    """Current state of the MundiX engine."""
    is_running: bool = False
    is_processing: bool = False
    current_operation: str = ""
    last_error: Optional[str] = None
    started_at: Optional[datetime] = None
    commands_executed: int = 0
    skills_executed: int = 0


class MundiXEngine:
    """
    Core engine that orchestrates all MundiX components.
    
    This is the main entry point for:
    - Processing user queries
    - Executing skills via Agent Orchestrator
    - Managing sessions and projects
    - Integrating AI, memory, and system execution
    - Generating reports
    """
    
    def __init__(
        self,
        ai_provider: Optional[AIProvider] = None,
        memory_backend: Optional[MemoryBackend] = None,
        config: Optional[MundiXConfig] = None,
    ):
        self.config = config or get_config()
        self.ai_provider = ai_provider
        self.memory = memory_backend
        self.session_manager = SessionManager()
        self.executor = CommandExecutor(
            default_timeout=self.config.command_timeout,
            max_output_lines=self.config.max_output_lines,
        )
        self.safety_checker = SafetyChecker()
        self.state = EngineState()
        
        # Lazy-loaded components
        self._orchestrator = None
        self._project_manager = None
        self._autopilot = None
        
        # Callbacks
        self.on_command_output: Optional[Callable[[str], None]] = None
        self.on_skill_complete: Optional[Callable[[SkillResult], None]] = None
        self.on_error: Optional[Callable[[str], None]] = None
    
    async def initialize(self) -> bool:
        """Initialize all engine components."""
        logger.info("Initializing MundiX Engine...")
        
        try:
            if self.ai_provider:
                success = await self.ai_provider.initialize()
                if not success:
                    logger.warning("AI provider initialization failed")
            
            if self.memory:
                await self.memory.initialize()
                logger.info("Memory backend initialized")
            
            self.session_manager.create_session()
            logger.info("Session created")
            
            self.state.is_running = True
            self.state.started_at = datetime.now()
            logger.info("MundiX Engine initialized successfully")
            return True
            
        except Exception as e:
            logger.error(f"Engine initialization failed: {e}")
            self.state.last_error = str(e)
            return False
    
    async def shutdown(self):
        """Shutdown all engine components."""
        logger.info("Shutting down MundiX Engine...")
        self.state.is_running = False
        
        if self.ai_provider:
            await self.ai_provider.shutdown()
        
        await self.executor.cleanup()
        
        if self._orchestrator:
            self._orchestrator.abort()
        
        self.session_manager.end_session()
        logger.info("MundiX Engine shut down")
    
    async def process_query(self, query: str, stream: bool = False) -> AsyncIterator[str]:
        """Process a user query through the AI provider."""
        if not self.state.is_running:
            raise RuntimeError("Engine is not running. Call initialize() first.")
        
        self.state.is_processing = True
        self.state.current_operation = f"Processing: {query[:50]}..."
        
        try:
            if self.memory:
                await self.memory.store(MemoryEntry(
                    type=MemoryType.QUERY,
                    query=query,
                ))
            
            messages = self._build_messages(query)
            
            if self.ai_provider:
                if stream:
                    full_response = ""
                    async for token in self.ai_provider.stream(messages):
                        full_response += token
                        yield token
                    
                    if self.memory:
                        await self.memory.store(MemoryEntry(
                            type=MemoryType.QUERY,
                            query=query,
                            response=full_response,
                        ))
                else:
                    response = await self.ai_provider.chat(messages)
                    yield response.content
                    
                    if self.memory:
                        await self.memory.store(MemoryEntry(
                            type=MemoryType.QUERY,
                            query=query,
                            response=response.content,
                        ))
            
            self.session_manager.add_message("user", query)
            
        except Exception as e:
            error_msg = f"Query processing failed: {e}"
            logger.error(error_msg)
            self.state.last_error = error_msg
            if self.on_error:
                self.on_error(error_msg)
            yield f"Error: {e}"
        
        finally:
            self.state.is_processing = False
            self.state.current_operation = ""
    
    async def execute_command(self, command: str, auto_confirm: bool = False) -> ExecutionResult:
        """Execute a shell command with safety checks."""
        safety = self.safety_checker.check(command)
        
        if safety.blocked and not auto_confirm:
            logger.warning(f"Command blocked by safety: {command}")
            return ExecutionResult(
                command=command,
                stdout="",
                stderr=f"Command blocked: {', '.join(safety.warnings)}",
                exit_code=-1,
                duration=0,
            )
        
        async with timer(logger, f"exec:{command[:30]}", {"command": command}):
            result = await self.executor.execute(command)
        
        self.state.commands_executed += 1
        
        if self.memory:
            await self.memory.store(MemoryEntry(
                type=MemoryType.COMMAND,
                content=command,
                metadata={
                    "exit_code": result.exit_code,
                    "duration": result.duration,
                    "output_lines": len(result.stdout.splitlines()),
                },
            ))
        
        if self.on_command_output and result.stdout:
            self.on_command_output(result.stdout)
        
        return result
    
    def _build_messages(self, query: str) -> List[ChatMessage]:
        """Build message list with system prompt and context."""
        from src.ai.prompts.system import SYSTEM_PROMPT
        
        messages = [
            ChatMessage(role="system", content=SYSTEM_PROMPT),
        ]
        
        session = self.session_manager.get_session()
        if session:
            context_info = session.to_context_string()
            messages.append(ChatMessage(
                role="system",
                content=f"Current session context: {context_info}",
            ))
        
        if self._orchestrator and self._orchestrator.state:
            engagement_context = self._orchestrator.state.get_context_summary()
            messages.append(ChatMessage(
                role="system",
                content=f"Engagement context:\n{engagement_context}",
            ))
        
        history = self.session_manager.get_chat_history(max_messages=10)
        messages.extend(history)
        
        messages.append(ChatMessage(role="user", content=query))
        
        return messages
    
    # ─── Agent Orchestrator ──────────────────────────────────────────
    
    @property
    def orchestrator(self):
        """Lazy-load the agent orchestrator."""
        if self._orchestrator is None:
            from src.agent.orchestrator import AgentOrchestrator
            from src.skills.loader import SkillLoader
            self._orchestrator = AgentOrchestrator(
                ai_provider=self.ai_provider,
                skill_loader=SkillLoader(),
                executor=self.executor,
                safety_checker=self.safety_checker,
                autopilot_level=self.config.autopilot_level,
                on_progress=self._on_orchestrator_progress,
                on_finding=self._on_orchestrator_finding,
            )
        return self._orchestrator
    
    async def start_engagement(self, target: str, engagement_type: str = "web") -> Dict:
        """Start a pentest engagement."""
        eng = self.orchestrator.create_engagement(target, engagement_type)
        plan = self.orchestrator.generate_plan()
        
        session = self.session_manager.get_session()
        if session:
            session.target_host = target
            session.engagement_type = engagement_type
            session.update_variable("target", target)
        
        return {
            "target": target,
            "type": engagement_type,
            "phases": len(plan),
            "total_skills": sum(len(p["skills"]) for p in plan),
        }
    
    async def run_engagement(self) -> Dict:
        """Run the current engagement plan."""
        plan = self.orchestrator.generate_plan()
        result = await self.orchestrator.execute_plan(plan)
        return result.get_progress()
    
    def _on_orchestrator_progress(self, progress: Dict):
        """Handle orchestrator progress updates."""
        logger.info(f"Engagement progress: {progress['percent']}%")
    
    def _on_orchestrator_finding(self, finding: Dict):
        """Handle new findings."""
        logger.info(f"New finding: {finding.get('finding', '')[:50]}")
        if self._project_manager and self._project_manager.get_current():
            self._project_manager.add_finding(finding)
    
    # ─── Project Management ──────────────────────────────────────────
    
    @property
    def project_manager(self):
        """Lazy-load the project manager."""
        if self._project_manager is None:
            from src.project.manager import ProjectManager
            self._project_manager = ProjectManager()
        return self._project_manager
    
    def create_project(self, name: str, target: str = "", target_type: str = "web") -> Dict:
        """Create a new project."""
        project = self.project_manager.create(name, target, target_type)
        return {"name": project.name, "workspace": project.workspace_dir}
    
    def open_project(self, name: str) -> Optional[Dict]:
        """Open an existing project."""
        project = self.project_manager.open(name)
        if project:
            return {"name": project.name, "target": project.target, "status": project.status}
        return None
    
    def list_projects(self) -> List[Dict]:
        """List all projects."""
        return [
            {"name": p.name, "target": p.target, "status": p.status}
            for p in self.project_manager.list_projects()
        ]
    
    # ─── Reporting ───────────────────────────────────────────────────
    
    def generate_report(self, output_dir: str, formats: List[str] = None) -> List[str]:
        """Generate a pentest report."""
        from src.reporting.generator import ReportGenerator, ReportData
        
        data = ReportData()
        
        if self._orchestrator and self._orchestrator.state:
            state = self._orchestrator.state
            data.target = state.target
            data.engagement_type = state.engagement_type
            data.discovered_hosts = state.discovered_hosts
            data.discovered_services = state.discovered_ports
            data.findings = state.discovered_vulns
            data.timeline = state.timeline
        
        if self._project_manager and self._project_manager.get_current():
            project = self._project_manager.get_current()
            data.title = f"MundiX Report - {project.name}"
            data.findings.extend(project.findings)
        
        generator = ReportGenerator(data)
        return generator.save(output_dir, formats)
    
    # ─── Autopilot ───────────────────────────────────────────────────
    
    @property
    def autopilot(self):
        """Lazy-load the autopilot controller."""
        if self._autopilot is None:
            from src.autopilot.controller import AutopilotController, AutopilotLevel
            self._autopilot = AutopilotController(AutopilotLevel(self.config.autopilot_level))
        return self._autopilot
    
    def set_autopilot_level(self, level: int) -> bool:
        """Set the autopilot level."""
        return self.autopilot.set_level(level)
