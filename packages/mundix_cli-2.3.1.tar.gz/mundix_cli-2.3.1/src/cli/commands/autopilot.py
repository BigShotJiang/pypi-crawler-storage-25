"""
MundiX CLI - Autopilot Command

Set and display autopilot level.
"""

from src.cli.commands.base import BaseCommand, CommandResult


class AutopilotCommand(BaseCommand):
    """Set or display autopilot level."""
    
    name = "autopilot"
    description = "Set autopilot level (1-5)"
    usage = "/autopilot <1-5>"
    aliases = ["ap"]
    
    def __init__(self, engine=None):
        super().__init__()
        self.engine = engine
    
    async def execute(self, **kwargs) -> CommandResult:
        args = self.get_args()
        
        if not args:
            from src.core.config import get_config
            config = get_config()
            return CommandResult(
                success=True,
                output=f"Current autopilot level: **{config.autopilot_level}**"
            )
        
        try:
            level = int(args[0])
            if not 1 <= level <= 5:
                raise ValueError
        except ValueError:
            return CommandResult(
                success=False,
                error="Level must be between 1 and 5"
            )
        
        from src.core.config import update_config
        update_config(autopilot_level=level)
        
        level_names = {
            1: "Manual",
            2: "Guided",
            3: "Semi-Auto",
            4: "Aggressive",
            5: "Full Autonomy",
        }
        
        return CommandResult(
            success=True,
            output=f"✅ Autopilot set to level **{level}** ({level_names[level]})"
        )
