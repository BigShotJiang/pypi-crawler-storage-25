"""
MundiX CLI - Command Registry

Registers and dispatches slash commands.
"""

from typing import Dict, List, Optional, Type

from src.cli.commands.base import BaseCommand, CommandResult
from src.core.logging import get_logger

logger = get_logger("cli.registry")


class CommandRegistry:
    """
    Registry for slash commands.
    
    Commands are registered and then dispatched based on user input.
    """
    
    def __init__(self):
        self._commands: Dict[str, BaseCommand] = {}
    
    def register(self, command: BaseCommand):
        """Register a command."""
        self._commands[command.name] = command
        for alias in command.aliases:
            self._commands[alias] = command
        logger.debug(f"Registered command: /{command.name}")
    
    def register_all(self, commands: List[BaseCommand]):
        """Register multiple commands."""
        for cmd in commands:
            self.register(cmd)
    
    def get_command(self, name: str) -> Optional[BaseCommand]:
        """Get a command by name or alias."""
        return self._commands.get(name.lstrip("/"))
    
    def get_all_commands(self) -> List[BaseCommand]:
        """Get all registered commands (deduplicated)."""
        seen = set()
        result = []
        for cmd in self._commands.values():
            if cmd.name not in seen:
                seen.add(cmd.name)
                result.append(cmd)
        return sorted(result, key=lambda c: c.name)
    
    async def dispatch(self, input_text: str, **kwargs) -> CommandResult:
        """
        Dispatch a command based on user input.
        
        Args:
            input_text: User input (e.g., "/help", "/model mx-deephat-7b")
            **kwargs: Context to pass to command execution
        
        Returns:
            CommandResult
        """
        parts = input_text.strip().split()
        cmd_name = parts[0].lstrip("/")
        args = parts[1:]
        
        command = self.get_command(cmd_name)
        if not command:
            return CommandResult(
                success=False,
                error=f"Unknown command: /{cmd_name}. Type /help for available commands."
            )
        
        command.parse_args(args)
        
        try:
            return await command.execute(**kwargs)
        except Exception as e:
            logger.exception(f"Command /{cmd_name} failed")
            return CommandResult(
                success=False,
                error=f"Command failed: {e}"
            )
    
    def is_command(self, input_text: str) -> bool:
        """Check if input is a slash command."""
        if not input_text.startswith("/"):
            return False
        parts = input_text.strip().split()
        cmd_name = parts[0].lstrip("/")
        return cmd_name in self._commands
