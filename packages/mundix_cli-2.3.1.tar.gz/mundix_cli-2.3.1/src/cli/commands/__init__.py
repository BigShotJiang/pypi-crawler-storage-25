"""MundiX CLI - Slash command implementations."""
