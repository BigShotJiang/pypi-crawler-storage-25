"""
MundiX CLI - Help Command

Displays help information for all available commands.
"""

from typing import List
from src.cli.commands.base import BaseCommand, CommandResult


class HelpCommand(BaseCommand):
    """Display help information."""
    
    name = "help"
    description = "Show available commands and help"
    usage = "/help [command]"
    aliases = ["h", "?"]
    
    def __init__(self, command_registry: List[BaseCommand] = None):
        super().__init__()
        self.command_registry = command_registry or []
    
    async def execute(self, **kwargs) -> CommandResult:
        args = self.get_args()
        
        if args:
            # Show help for specific command
            cmd_name = args[0].lstrip("/")
            for cmd in self.command_registry:
                if cmd.name == cmd_name or cmd_name in cmd.aliases:
                    return CommandResult(
                        success=True,
                        output=f"**{cmd.name}**: {cmd.description}\nUsage: {cmd.get_usage()}"
                    )
            return CommandResult(
                success=False,
                error=f"Command '{cmd_name}' not found"
            )
        
        # Show all commands
        lines = ["## MundiX CLI Commands\n"]
        for cmd in sorted(self.command_registry, key=lambda c: c.name):
            lines.append(f"- `/{cmd.name}` — {cmd.description}")
        
        lines.append("\nType `/help <command>` for detailed help on a specific command.")
        
        return CommandResult(
            success=True,
            output="\n".join(lines)
        )
