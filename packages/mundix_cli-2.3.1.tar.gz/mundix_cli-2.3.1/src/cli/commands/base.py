"""
MundiX CLI - Base Command Class

Abstract base class for all slash commands.
Each command implements a consistent interface for registration and execution.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class CommandResult:
    """Result of a command execution."""
    success: bool
    output: str = ""
    error: str = ""
    data: Optional[Dict[str, Any]] = None


class BaseCommand(ABC):
    """
    Base class for all CLI slash commands.
    
    Commands are registered with the CLI and executed when the user
    types the corresponding slash command.
    """
    
    # Command metadata (override in subclasses)
    name: str = ""
    description: str = ""
    usage: str = ""
    aliases: List[str] = []
    
    def __init__(self):
        self._args: List[str] = []
    
    def parse_args(self, args: List[str]):
        """Parse command arguments."""
        self._args = args
    
    @abstractmethod
    async def execute(self, **kwargs) -> CommandResult:
        """
        Execute the command.
        
        Args:
            **kwargs: Additional context (engine, session, console, etc.)
        
        Returns:
            CommandResult with output
        """
        pass
    
    def get_usage(self) -> str:
        """Get usage string for help display."""
        return self.usage or f"/{self.name}"
    
    def matches(self, input_text: str) -> bool:
        """Check if input matches this command."""
        text = input_text.strip().lower()
        if text == f"/{self.name}":
            return True
        for alias in self.aliases:
            if text == f"/{alias}":
                return True
        if text.startswith(f"/{self.name} "):
            return True
        for alias in self.aliases:
            if text.startswith(f"/{alias} "):
                return True
        return False
    
    def get_args(self) -> List[str]:
        """Get parsed arguments."""
        return self._args
