"""
MundiX CLI - Model Command

Switch between AI models and list available models.
"""

from src.cli.commands.base import BaseCommand, CommandResult
from src.core.logging import get_logger

logger = get_logger("cli.commands.model")


class ModelCommand(BaseCommand):
    """Switch or list AI models."""
    
    name = "model"
    description = "Switch AI model or list available models"
    usage = "/model [model_name] or /models"
    aliases = ["models"]
    
    def __init__(self, engine=None):
        super().__init__()
        self.engine = engine
    
    async def execute(self, **kwargs) -> CommandResult:
        args = self.get_args()
        
        if not self.engine or not self.engine.ai_provider:
            return CommandResult(success=False, error="AI provider not available")
        
        if not args or args[0] == "list":
            # List available models
            try:
                models = await self.engine.ai_provider.get_models()
                default = await self.engine.ai_provider.get_default_model()
                
                lines = ["## Available Models\n"]
                for m in models:
                    marker = " ← **default**" if m.id == default else ""
                    lines.append(f"- `{m.id}` — {m.name}{marker}")
                    lines.append(f"  {m.description}")
                
                return CommandResult(success=True, output="\n".join(lines))
            except Exception as e:
                return CommandResult(success=False, error=f"Failed to list models: {e}")
        
        # Switch model
        model_name = args[0]
        try:
            # Update config
            from src.core.config import update_config
            update_config(default_model=model_name)
            logger.info(f"Model switched to: {model_name}")
            return CommandResult(
                success=True,
                output=f"✅ Model switched to `{model_name}`"
            )
        except Exception as e:
            return CommandResult(success=False, error=f"Failed to switch model: {e}")
