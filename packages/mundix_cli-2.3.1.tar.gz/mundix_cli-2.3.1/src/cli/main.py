"""
MundiX CLI v2.0 - Main Entry Point

Refactored entry point with modular architecture.
Maintains backward compatibility with legacy modules during migration.
"""

import sys
import os
import asyncio

# Ensure local modules are importable regardless of cwd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import argparse
from rich.console import Console
from rich.panel import Panel
from rich.markdown import Markdown

from src import __version__
from src.core.config import get_config, update_config
from src.core.logging import setup_logging, get_logger
from src.core.engine import MundiXEngine
from src.cli.ui.theme import MUNDIX_THEME

# ─── Console Setup ──────────────────────────────────────────────────

console = Console(theme=MUNDIX_THEME)
logger = get_logger("main")


# ─── Banner ─────────────────────────────────────────────────────────

BANNER = """
[bold red]╔══════════════════════════════════════════════════════════╗[/bold red]
[bold red]║[/bold red]  [bold white]MundiX CLI v{version}[/bold white] - AI-Powered Cybersecurity Copilot  [bold red]║[/bold red]
[bold red]║[/bold red]  [dim]mundix.com.br | github.com/k0k4/mundix-cli[/dim]        [bold red]║[/bold red]
[bold red]╚══════════════════════════════════════════════════════════╝[/bold red]
""".format(version=__version__)


# ─── Argument Parser ────────────────────────────────────────────────

def parse_args():
    """Parse command-line arguments."""
    parser = argparse.ArgumentParser(
        description="MundiX CLI - AI-Powered Cybersecurity Copilot",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=BANNER,
    )
    
    parser.add_argument(
        "query",
        nargs="?",
        default=None,
        help="One-shot query to process",
    )
    
    parser.add_argument(
        "--model",
        default=None,
        help="AI model to use",
    )
    
    parser.add_argument(
        "--autopilot",
        type=int,
        default=None,
        choices=[1, 2, 3, 4, 5],
        help="Autopilot level (1-5)",
    )
    
    parser.add_argument(
        "--project",
        default=None,
        help="Project name to open",
    )
    
    parser.add_argument(
        "--target",
        default=None,
        help="Target host or domain",
    )
    
    parser.add_argument(
        "--update",
        action="store_true",
        help="Check for updates",
    )
    
    parser.add_argument(
        "--no-animation",
        action="store_true",
        help="Disable loading animation",
    )
    
    parser.add_argument(
        "--debug",
        action="store_true",
        help="Enable debug logging",
    )
    
    return parser.parse_args()


# ─── Main Entry ─────────────────────────────────────────────────────

async def async_main():
    """Async main function."""
    args = parse_args()
    
    # Setup logging
    log_level = "DEBUG" if args.debug else "INFO"
    setup_logging(level=getattr(__import__("logging").logging, log_level))
    logger.info("MundiX CLI starting...")
    
    # Load config
    config = get_config()
    
    # Apply CLI overrides
    if args.model:
        update_config(default_model=args.model)
    if args.autopilot:
        update_config(autopilot_level=args.autopilot)
    if args.no_animation:
        update_config(show_animation=False)
    
    # Show banner
    console.print(BANNER)
    
    # Check for update request
    if args.update:
        console.print("[info]Checking for updates...[/info]")
        # TODO: Implement update check
        console.print("[success]You are running the latest version.[/success]")
        return
    
    # Initialize engine
    engine = MundiXEngine(config=config)
    success = await engine.initialize()
    
    if not success:
        console.print("[danger]Failed to initialize MundiX Engine[/danger]")
        return
    
    try:
        # Set target if provided
        if args.target:
            session = engine.session_manager.get_session()
            if session:
                session.target_host = args.target
                session.update_variable("target", args.target)
        
        # Process one-shot query
        if args.query:
            console.print(f"\n[command]Query:[/command] {args.query}")
            console.print("[dim]Processing...[/dim]\n")
            
            full_response = ""
            async for token in engine.process_query(args.query, stream=True):
                full_response += token
                console.print(token, end="")
            
            console.print()
            return
        
        # Interactive mode
        console.print("\n[success]MundiX CLI ready. Type /help for commands.[/success]\n")
        await interactive_loop(engine)
    
    finally:
        await engine.shutdown()


async def interactive_loop(engine: MundiXEngine):
    """Interactive command loop with command registry."""
    from prompt_toolkit import PromptSession
    from prompt_toolkit.history import FileHistory
    from prompt_toolkit.auto_suggest import AutoSuggestFromHistory
    from rich.markdown import Markdown
    
    # Setup command registry
    from src.cli.commands.registry import CommandRegistry
    from src.cli.commands.help import HelpCommand
    from src.cli.commands.model import ModelCommand
    from src.cli.commands.autopilot import AutopilotCommand
    
    registry = CommandRegistry()
    registry.register(HelpCommand(command_registry=[]))
    registry.register(ModelCommand(engine=engine))
    registry.register(AutopilotCommand(engine=engine))
    
    # Update help command with registry
    help_cmd = registry.get_command("help")
    if help_cmd:
        help_cmd.command_registry = registry.get_all_commands()
    
    history_file = os.path.expanduser("~/.mundix/history")
    os.makedirs(os.path.dirname(history_file), exist_ok=True)
    
    session = PromptSession(
        history=FileHistory(history_file),
        auto_suggest=AutoSuggestFromHistory(),
    )
    
    while True:
        try:
            # Build prompt
            session_ctx = engine.session_manager.get_session()
            target = session_ctx.target_host if session_ctx else None
            prompt_text = f"mundix{'@' + target if target else ''}> "
            
            user_input = await session.prompt_async(message=prompt_text)
            user_input = user_input.strip()
            
            if not user_input:
                continue
            
            # Handle exit commands
            if user_input.lower() in ("/exit", "/quit", "/q", "exit", "quit"):
                console.print("[dim]Goodbye![/dim]")
                break
            
            # Check if it's a slash command
            if registry.is_command(user_input):
                result = await registry.dispatch(user_input, engine=engine, console=console)
                if result.success:
                    console.print(Markdown(result.output))
                else:
                    console.print(f"[danger]Error:[/danger] {result.error}")
                continue
            
            # Process as AI query
            console.print()
            async for token in engine.process_query(user_input, stream=True):
                console.print(token, end="")
            console.print()
        
        except KeyboardInterrupt:
            continue
        except EOFError:
            console.print("\n[dim]Goodbye![/dim]")
            break
        except Exception as e:
            console.print(f"[danger]Error:[/danger] {e}")
            logger.exception("Error in interactive loop")


def main():
    """Synchronous entry point."""
    try:
        asyncio.run(async_main())
    except KeyboardInterrupt:
        console.print("\n[dim]Interrupted. Goodbye![/dim]")
    except Exception as e:
        console.print(f"[danger]Fatal error:[/danger] {e}")
        logger.exception("Fatal error")
        sys.exit(1)


if __name__ == "__main__":
    main()
