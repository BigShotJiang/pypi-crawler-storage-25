"""MundiX CLI - UI components (theme, panels, progress)."""
