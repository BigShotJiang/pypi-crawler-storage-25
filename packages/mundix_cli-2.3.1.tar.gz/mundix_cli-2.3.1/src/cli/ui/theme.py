"""
MundiX CLI - UI Theme

Rich theme configuration for consistent visual styling.
"""

from rich.theme import Theme

MUNDIX_THEME = Theme({
    "info": "cyan",
    "warning": "yellow",
    "danger": "bold red",
    "success": "bold green",
    "mundix": "bold red",
    "command": "bold yellow",
    "output": "dim white",
    "hacker": "green",
    "dim": "dim white",
    "fix": "bold cyan",
    "project": "bold magenta",
    "phase": "bold blue",
    "skill": "magenta",
    "finding": "bold yellow",
})
