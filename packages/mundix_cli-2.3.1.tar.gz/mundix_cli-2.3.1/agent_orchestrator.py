"""
MundiX Agent Orchestrator (Compatibility Shim)
Now imports from src.agent.orchestrator for the actual implementation.
Backward compatibility layer.
"""

from src.agent.orchestrator import (
    AgentOrchestrator,
    ENGAGEMENT_PROFILES,
)

__all__ = ["AgentOrchestrator", "ENGAGEMENT_PROFILES"]
