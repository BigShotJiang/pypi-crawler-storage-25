"""
MundiX CLI - System Integrator (Compatibility Shim)
Now imports from src.system.executor for the actual implementation.
Backward compatibility layer.
"""

from src.system.executor import CommandExecutor as SystemIntegrator

__all__ = ["SystemIntegrator"]
