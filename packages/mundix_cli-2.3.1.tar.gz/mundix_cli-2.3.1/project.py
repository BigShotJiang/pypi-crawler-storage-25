"""
MundiX CLI - Project Management (Compatibility Shim)
Now imports from src.project.manager for the actual implementation.
Backward compatibility layer.
"""

from src.project.manager import ProjectManager as Project

__all__ = ["Project"]
