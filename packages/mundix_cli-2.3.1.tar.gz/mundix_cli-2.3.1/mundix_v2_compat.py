"""
MundiX CLI - Legacy Compatibility Layer

This module provides backward compatibility for the legacy modules.
It re-exports the new architecture under the old module names so that
existing code continues to work during the migration period.

Usage:
    # Old code that does: from ai_provider import AIProvider
    # Will now get the new interface through this compatibility layer
"""

import sys
import os

# Add src to path so new modules are importable
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "src"))

# ─── Re-export new architecture under legacy names ──────────────────

# Config
try:
    from src.core.config import MundiXConfig, get_config, update_config, CONFIG_DIR, CONFIG_FILE
except ImportError:
    pass

# AI Provider
try:
    from src.ai.base import AIProvider, ChatMessage, ChatResponse, ModelInfo, ModelTier
except ImportError:
    pass

# Memory
try:
    from src.memory.base import MemoryBackend, MemoryEntry, MemoryType, MemorySearchResult
except ImportError:
    pass

# Skills
try:
    from src.skills.models import Skill, SkillCommand, SkillPhase, SkillResult, SkillStatus
    from src.skills.loader import SkillLoader
except ImportError:
    pass

# System
try:
    from src.system.executor import CommandExecutor, ExecutionResult
    from src.system.safety import SafetyChecker, RiskLevel
except ImportError:
    pass

# Core
try:
    from src.core.engine import MundiXEngine, EngineState
    from src.core.session import SessionContext, SessionManager
    from src.core.logging import setup_logging, get_logger, timer
except ImportError:
    pass

# CLI
try:
    from src.cli.commands.base import BaseCommand, CommandResult
    from src.cli.ui.theme import MUNDIX_THEME
except ImportError:
    pass

print("[MundiX v2.0] Legacy compatibility layer loaded. Consider migrating to new imports.")
