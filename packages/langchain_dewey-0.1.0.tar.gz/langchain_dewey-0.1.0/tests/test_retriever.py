"""Tests for DeweyRetriever."""

from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import pytest

from langchain_dewey import DeweyRetriever


def _make_result(content: str, filename: str, score: float = 0.9) -> SimpleNamespace:
    return SimpleNamespace(
        score=score,
        chunk=SimpleNamespace(id="c-1", content=content, position=0, tokenCount=50),
        section=SimpleNamespace(id="s-1", title="Section A", level=2),
        document=SimpleNamespace(id="d-1", filename=filename),
    )


@pytest.fixture()
def mock_client():
    with patch("dewey.DeweyClient") as cls:
        client = MagicMock()
        cls.return_value = client
        yield client


def test_returns_documents(mock_client):
    mock_client.retrieval.query.return_value = [
        _make_result("Backprop computes gradients.", "neural.txt", score=0.95),
        _make_result("Adam optimizer adapts learning rates.", "neural.txt", score=0.82),
    ]

    retriever = DeweyRetriever(api_key="dwy_test_key", collection_id="col-1")
    docs = retriever.invoke("how does backpropagation work")

    assert len(docs) == 2
    assert docs[0].page_content == "Backprop computes gradients."
    assert docs[1].page_content == "Adam optimizer adapts learning rates."


def test_metadata_mapping(mock_client):
    mock_client.retrieval.query.return_value = [
        _make_result("Some content.", "report.pdf", score=0.77),
    ]

    retriever = DeweyRetriever(api_key="dwy_test_key", collection_id="col-1")
    docs = retriever.invoke("query")

    meta = docs[0].metadata
    assert meta["score"] == pytest.approx(0.77)
    assert meta["filename"] == "report.pdf"
    assert meta["document_id"] == "d-1"
    assert meta["section_title"] == "Section A"
    assert meta["section_id"] == "s-1"
    assert meta["section_level"] == 2


def test_passes_k_to_query(mock_client):
    mock_client.retrieval.query.return_value = []

    retriever = DeweyRetriever(api_key="dwy_test_key", collection_id="col-1", k=5)
    retriever.invoke("anything")

    mock_client.retrieval.query.assert_called_once_with("col-1", "anything", limit=5)


def test_empty_results(mock_client):
    mock_client.retrieval.query.return_value = []

    retriever = DeweyRetriever(api_key="dwy_test_key", collection_id="col-1")
    docs = retriever.invoke("obscure query")

    assert docs == []
