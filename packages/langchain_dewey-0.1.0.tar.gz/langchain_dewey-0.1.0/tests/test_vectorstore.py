"""Tests for DeweyVectorStore."""

from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import MagicMock, call, patch

import pytest

from langchain_dewey import DeweyVectorStore


def _make_result(content: str, filename: str, score: float = 0.9) -> SimpleNamespace:
    return SimpleNamespace(
        score=score,
        chunk=SimpleNamespace(id="c-1", content=content, position=0, tokenCount=50),
        section=SimpleNamespace(id="s-1", title="Section A", level=2),
        document=SimpleNamespace(id="d-1", filename=filename),
    )


def _make_doc(doc_id: str, status: str = "ready") -> SimpleNamespace:
    return SimpleNamespace(id=doc_id, status=status, errorMessage=None)


@pytest.fixture()
def mock_client():
    with patch("dewey.DeweyClient") as cls:
        client = MagicMock()
        cls.return_value = client
        yield client


# ── similarity_search ─────────────────────────────────────────────────────────


def test_similarity_search_returns_documents(mock_client):
    mock_client.retrieval.query.return_value = [
        _make_result("Backprop computes gradients.", "neural.txt", score=0.95),
        _make_result("Adam optimizer adapts learning rates.", "neural.txt", score=0.82),
    ]

    store = DeweyVectorStore(api_key="dwy_test_key", collection_id="col-1")
    docs = store.similarity_search("how does training work?")

    assert len(docs) == 2
    assert docs[0].page_content == "Backprop computes gradients."
    assert docs[1].page_content == "Adam optimizer adapts learning rates."


def test_similarity_search_passes_k(mock_client):
    mock_client.retrieval.query.return_value = []

    store = DeweyVectorStore(api_key="dwy_test_key", collection_id="col-1")
    store.similarity_search("query", k=7)

    mock_client.retrieval.query.assert_called_once_with("col-1", "query", limit=7)


def test_similarity_search_metadata(mock_client):
    mock_client.retrieval.query.return_value = [
        _make_result("Some content.", "report.pdf", score=0.77),
    ]

    store = DeweyVectorStore(api_key="dwy_test_key", collection_id="col-1")
    docs = store.similarity_search("query")

    meta = docs[0].metadata
    assert meta["score"] == pytest.approx(0.77)
    assert meta["filename"] == "report.pdf"
    assert meta["document_id"] == "d-1"
    assert meta["section_title"] == "Section A"
    assert meta["section_id"] == "s-1"
    assert meta["section_level"] == 2


# ── similarity_search_with_score ──────────────────────────────────────────────


def test_similarity_search_with_score(mock_client):
    mock_client.retrieval.query.return_value = [
        _make_result("Content A", "a.txt", score=0.9),
        _make_result("Content B", "b.txt", score=0.6),
    ]

    store = DeweyVectorStore(api_key="dwy_test_key", collection_id="col-1")
    pairs = store.similarity_search_with_score("query")

    assert len(pairs) == 2
    doc0, score0 = pairs[0]
    doc1, score1 = pairs[1]
    assert doc0.page_content == "Content A"
    assert score0 == pytest.approx(0.9)
    assert doc1.page_content == "Content B"
    assert score1 == pytest.approx(0.6)


# ── add_texts / _wait_for_ready ───────────────────────────────────────────────


def test_add_texts_uploads_and_returns_ids(mock_client):
    mock_client.documents.upload.side_effect = [
        SimpleNamespace(id="doc-1"),
        SimpleNamespace(id="doc-2"),
    ]
    mock_client.documents.get.side_effect = [
        _make_doc("doc-1", "ready"),
        _make_doc("doc-2", "ready"),
    ]

    store = DeweyVectorStore(api_key="dwy_test_key", collection_id="col-1")
    ids = store.add_texts(["Text one.", "Text two."])

    assert ids == ["doc-1", "doc-2"]
    assert mock_client.documents.upload.call_count == 2


def test_add_texts_uses_source_metadata(mock_client):
    mock_client.documents.upload.return_value = SimpleNamespace(id="doc-1")
    mock_client.documents.get.return_value = _make_doc("doc-1", "ready")

    store = DeweyVectorStore(api_key="dwy_test_key", collection_id="col-1")
    store.add_texts(["Hello"], metadatas=[{"source": "my_doc.txt"}])

    upload_call = mock_client.documents.upload.call_args
    assert upload_call.kwargs["filename"] == "my_doc.txt"


def test_add_texts_appends_txt_extension(mock_client):
    mock_client.documents.upload.return_value = SimpleNamespace(id="doc-1")
    mock_client.documents.get.return_value = _make_doc("doc-1", "ready")

    store = DeweyVectorStore(api_key="dwy_test_key", collection_id="col-1")
    store.add_texts(["Hello"], metadatas=[{"source": "my_doc"}])

    upload_call = mock_client.documents.upload.call_args
    assert upload_call.kwargs["filename"] == "my_doc.txt"


def test_add_texts_raises_on_document_error(mock_client):
    mock_client.documents.upload.return_value = SimpleNamespace(id="doc-1")
    mock_client.documents.get.return_value = SimpleNamespace(
        id="doc-1", status="error", errorMessage="parse failed"
    )

    store = DeweyVectorStore(api_key="dwy_test_key", collection_id="col-1")
    with pytest.raises(RuntimeError, match="parse failed"):
        store.add_texts(["Bad content."])


def test_add_texts_polls_until_ready(mock_client):
    mock_client.documents.upload.return_value = SimpleNamespace(id="doc-1")
    # First call: processing; second call: ready
    mock_client.documents.get.side_effect = [
        _make_doc("doc-1", "processing"),
        _make_doc("doc-1", "ready"),
    ]

    store = DeweyVectorStore(
        api_key="dwy_test_key",
        collection_id="col-1",
        poll_interval=0,  # no real sleep in tests
    )
    with patch("time.sleep"):
        ids = store.add_texts(["Some text."])

    assert ids == ["doc-1"]
    assert mock_client.documents.get.call_count == 2


def test_add_texts_raises_on_timeout(mock_client):
    mock_client.documents.upload.return_value = SimpleNamespace(id="doc-1")
    # Always returns processing — never ready
    mock_client.documents.get.return_value = _make_doc("doc-1", "processing")

    store = DeweyVectorStore(
        api_key="dwy_test_key",
        collection_id="col-1",
        poll_interval=0,
        poll_timeout=0,  # expire immediately
    )
    with pytest.raises(TimeoutError, match="not ready after"):
        store.add_texts(["Some text."])


# ── delete ────────────────────────────────────────────────────────────────────


def test_delete_calls_documents_delete(mock_client):
    store = DeweyVectorStore(api_key="dwy_test_key", collection_id="col-1")
    result = store.delete(["doc-1", "doc-2"])

    assert result is True
    assert mock_client.documents.delete.call_count == 2
    mock_client.documents.delete.assert_any_call("col-1", "doc-1")
    mock_client.documents.delete.assert_any_call("col-1", "doc-2")


def test_delete_empty_ids_is_noop(mock_client):
    store = DeweyVectorStore(api_key="dwy_test_key", collection_id="col-1")
    result = store.delete([])

    assert result is True
    mock_client.documents.delete.assert_not_called()


# ── from_texts ────────────────────────────────────────────────────────────────


def test_from_texts_creates_collection_when_no_id(mock_client):
    with patch("dewey.DeweyClient") as cls:
        client = MagicMock()
        cls.return_value = client
        client.collections.create.return_value = SimpleNamespace(id="new-col")
        client.documents.upload.return_value = SimpleNamespace(id="doc-1")
        client.documents.get.return_value = _make_doc("doc-1", "ready")

        store = DeweyVectorStore.from_texts(
            texts=["Hello world."],
            embedding=None,
            api_key="dwy_test_key",
            collection_name="my-collection",
        )

    client.collections.create.assert_called_once_with(name="my-collection")
    assert store._collection_id == "new-col"


def test_from_texts_uses_existing_collection(mock_client):
    with patch("dewey.DeweyClient") as cls:
        client = MagicMock()
        cls.return_value = client
        client.documents.upload.return_value = SimpleNamespace(id="doc-1")
        client.documents.get.return_value = _make_doc("doc-1", "ready")

        store = DeweyVectorStore.from_texts(
            texts=["Hello world."],
            embedding=None,
            api_key="dwy_test_key",
            collection_id="existing-col",
        )

    client.collections.create.assert_not_called()
    assert store._collection_id == "existing-col"
