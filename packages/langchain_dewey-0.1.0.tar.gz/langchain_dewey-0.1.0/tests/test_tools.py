"""Tests for create_research_tool."""

from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import pytest

from langchain_dewey import create_research_tool


@pytest.fixture()
def mock_client():
    with patch("dewey.DeweyClient") as cls:
        client = MagicMock()
        cls.return_value = client
        yield client


def _chunk(content: str) -> SimpleNamespace:
    return SimpleNamespace(type="chunk", content=content)


def _error(message: str) -> SimpleNamespace:
    return SimpleNamespace(type="error", message=message)


def _other() -> SimpleNamespace:
    return SimpleNamespace(type="done")


def test_returns_concatenated_chunks(mock_client):
    mock_client.research.stream.return_value = [
        _chunk("Neural "),
        _chunk("networks "),
        _chunk("learn."),
    ]

    tool = create_research_tool(api_key="dwy_test_key", collection_id="col-1")
    result = tool.invoke("how do neural networks learn?")

    assert result == "Neural networks learn."


def test_raises_on_error_event(mock_client):
    mock_client.research.stream.return_value = [
        _chunk("Partial answer..."),
        _error("upstream timeout"),
    ]

    tool = create_research_tool(api_key="dwy_test_key", collection_id="col-1")
    with pytest.raises(RuntimeError, match="upstream timeout"):
        tool.invoke("any question")


def test_ignores_unknown_event_types(mock_client):
    mock_client.research.stream.return_value = [
        _other(),
        _chunk("Answer."),
        _other(),
    ]

    tool = create_research_tool(api_key="dwy_test_key", collection_id="col-1")
    result = tool.invoke("question")

    assert result == "Answer."


def test_passes_depth_to_stream(mock_client):
    mock_client.research.stream.return_value = []

    tool = create_research_tool(
        api_key="dwy_test_key", collection_id="col-1", depth="deep"
    )
    tool.invoke("question")

    mock_client.research.stream.assert_called_once_with("col-1", "question", depth="deep")


def test_passes_collection_id_to_stream(mock_client):
    mock_client.research.stream.return_value = []

    tool = create_research_tool(api_key="dwy_test_key", collection_id="my-col")
    tool.invoke("question")

    call_args = mock_client.research.stream.call_args
    assert call_args.args[0] == "my-col"


def test_empty_stream_returns_empty_string(mock_client):
    mock_client.research.stream.return_value = []

    tool = create_research_tool(api_key="dwy_test_key", collection_id="col-1")
    result = tool.invoke("question")

    assert result == ""
