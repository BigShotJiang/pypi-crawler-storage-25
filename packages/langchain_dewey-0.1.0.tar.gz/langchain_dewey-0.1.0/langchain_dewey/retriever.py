"""DeweyRetriever — LangChain retriever backed by Dewey hybrid search."""

from __future__ import annotations

from typing import Any, List

from langchain_core.callbacks import CallbackManagerForRetrieverRun
from langchain_core.documents import Document
from langchain_core.retrievers import BaseRetriever
from pydantic import PrivateAttr


class DeweyRetriever(BaseRetriever):
    """LangChain retriever that queries a Dewey collection.

    Uses Dewey's hybrid semantic + BM25 search and returns chunks with
    full citation metadata (document, section, relevance score).

    Example::

        from langchain_dewey import DeweyRetriever
        from langchain_openai import ChatOpenAI
        from langchain.chains import RetrievalQA

        retriever = DeweyRetriever(
            api_key="dwy_live_...",
            collection_id="3f7a1b2c-...",
            k=8,
        )

        qa = RetrievalQA.from_chain_type(llm=ChatOpenAI(), retriever=retriever)
        answer = qa.invoke("What are the main findings?")
    """

    api_key: str
    """Dewey project API key (dwy_live_... or dwy_test_...)."""

    collection_id: str
    """ID of the collection to search."""

    k: int = 10
    """Maximum number of chunks to retrieve (1–50)."""

    base_url: str = "https://api.meetdewey.com/v1"
    """Dewey API base URL. Override for local development."""

    _client: Any = PrivateAttr()

    def model_post_init(self, __context: Any) -> None:
        from dewey import DeweyClient

        self._client = DeweyClient(api_key=self.api_key, base_url=self.base_url)

    def _get_relevant_documents(
        self,
        query: str,
        *,
        run_manager: CallbackManagerForRetrieverRun,
    ) -> List[Document]:
        results = self._client.retrieval.query(
            self.collection_id, query, limit=self.k
        )
        return [
            Document(
                page_content=r.chunk.content,
                metadata={
                    "score": r.score,
                    "document_id": r.document.id,
                    "filename": r.document.filename,
                    "section_id": r.section.id,
                    "section_title": r.section.title,
                    "section_level": r.section.level,
                },
            )
            for r in results
        ]
