"""Dewey LangChain tools for use with agents."""

from __future__ import annotations

from typing import Any

from langchain_core.tools import tool


def create_research_tool(
    api_key: str,
    collection_id: str,
    *,
    depth: str = "balanced",
    base_url: str = "https://api.meetdewey.com/v1",
) -> Any:
    """Create a LangChain tool that runs a Dewey research query.

    The returned tool is suitable for use with any LangChain agent that accepts
    a list of tools (e.g. ``create_openai_tools_agent``). It streams the
    research SSE internally and returns the completed answer as a string.

    Args:
        api_key: Dewey project API key.
        collection_id: Collection to research against.
        depth: Research depth — ``"quick"``, ``"balanced"`` (default),
            ``"deep"``, or ``"exhaustive"``.
        base_url: Dewey API base URL.

    Example::

        from langchain_dewey import create_research_tool
        from langchain_openai import ChatOpenAI
        from langchain.agents import AgentExecutor, create_openai_tools_agent
        from langchain_core.prompts import ChatPromptTemplate

        research = create_research_tool(
            api_key="dwy_live_...",
            collection_id="3f7a1b2c-...",
            depth="balanced",
        )

        llm = ChatOpenAI(model="gpt-4o")
        prompt = ChatPromptTemplate.from_messages([
            ("system", "You are a helpful research assistant."),
            ("human", "{input}"),
            ("placeholder", "{agent_scratchpad}"),
        ])
        agent = create_openai_tools_agent(llm, [research], prompt)
        executor = AgentExecutor(agent=agent, tools=[research])
        executor.invoke({"input": "Summarise the key findings across all documents."})
    """
    from dewey import DeweyClient

    client = DeweyClient(api_key=api_key, base_url=base_url)
    _collection_id = collection_id
    _depth = depth

    @tool
    def research_documents(question: str) -> str:
        """Run a deep research query over the document collection.

        Searches, reads, and synthesises content from multiple documents to
        produce a grounded, cited answer in Markdown. Use this tool when the
        question requires information that may span several documents or sections.
        """
        answer = ""
        for event in client.research.stream(_collection_id, question, depth=_depth):
            if event.type == "chunk":
                answer += event.content
            elif event.type == "error":
                raise RuntimeError(f"Research error: {event.message}")
        return answer

    return research_documents
