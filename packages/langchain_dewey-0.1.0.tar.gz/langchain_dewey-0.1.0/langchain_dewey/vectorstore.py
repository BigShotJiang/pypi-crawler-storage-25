"""DeweyVectorStore — LangChain VectorStore backed by a Dewey collection."""

from __future__ import annotations

import io
import time
from typing import Any, Iterable, List, Optional, Tuple

from langchain_core.documents import Document
from langchain_core.embeddings import Embeddings
from langchain_core.vectorstores import VectorStore


class DeweyVectorStore(VectorStore):
    """LangChain VectorStore backed by a Dewey collection.

    Dewey manages its own embeddings, so the ``embedding`` argument accepted
    by ``from_texts`` is unused — pass ``None`` or omit it.

    Example — build from documents::

        from langchain_dewey import DeweyVectorStore

        store = DeweyVectorStore.from_texts(
            texts=["Neural networks learn via backpropagation.", "..."],
            embedding=None,
            api_key="dwy_live_...",
            collection_name="my-docs",
        )
        results = store.similarity_search("how does training work?", k=5)

    Example — wrap an existing collection::

        store = DeweyVectorStore(
            api_key="dwy_live_...",
            collection_id="3f7a1b2c-...",
        )
        results = store.similarity_search("retrieval augmented generation")
    """

    def __init__(
        self,
        api_key: str,
        collection_id: str,
        *,
        base_url: str = "https://api.meetdewey.com/v1",
        poll_interval: float = 2.0,
        poll_timeout: float = 300.0,
    ) -> None:
        """
        Args:
            api_key: Dewey project API key.
            collection_id: ID of the collection to use.
            base_url: Dewey API base URL.
            poll_interval: Seconds between status polls in ``add_texts``.
            poll_timeout: Maximum seconds to wait for documents to become ready.
        """
        from dewey import DeweyClient

        self._api_key = api_key
        self._base_url = base_url
        self._collection_id = collection_id
        self._poll_interval = poll_interval
        self._poll_timeout = poll_timeout
        self._client = DeweyClient(api_key=api_key, base_url=base_url)

    # ── Core VectorStore interface ────────────────────────────────────────────

    def add_texts(
        self,
        texts: Iterable[str],
        metadatas: Optional[List[dict]] = None,
        **kwargs: Any,
    ) -> List[str]:
        """Upload texts as plain-text documents and wait for them to be ready.

        Each text is uploaded as a separate ``.txt`` document. If the
        corresponding metadata entry contains a ``"source"`` key its value is
        used as the filename; otherwise the document is named ``text-{i}.txt``.

        Returns:
            List of Dewey document IDs, in the same order as ``texts``.
        """
        ids: List[str] = []
        for i, text in enumerate(texts):
            meta = (metadatas or [])[i] if metadatas else {}
            source = meta.get("source", f"text-{i}.txt")
            # Ensure the filename ends with a text extension
            if "." not in source.split("/")[-1]:
                source = f"{source}.txt"
            doc = self._client.documents.upload(
                self._collection_id,
                io.BytesIO(text.encode("utf-8")),
                filename=source,
                content_type="text/plain",
            )
            ids.append(doc.id)

        self._wait_for_ready(ids)
        return ids

    def similarity_search(
        self,
        query: str,
        k: int = 4,
        **kwargs: Any,
    ) -> List[Document]:
        """Return the top-k chunks most relevant to ``query``."""
        results = self._client.retrieval.query(self._collection_id, query, limit=k)
        return [_result_to_document(r) for r in results]

    def similarity_search_with_score(
        self,
        query: str,
        k: int = 4,
        **kwargs: Any,
    ) -> List[Tuple[Document, float]]:
        """Return (Document, relevance_score) pairs for the top-k results."""
        results = self._client.retrieval.query(self._collection_id, query, limit=k)
        return [(_result_to_document(r), r.score) for r in results]

    def delete(self, ids: Optional[List[str]] = None, **kwargs: Any) -> Optional[bool]:
        """Delete documents by their Dewey document IDs."""
        if not ids:
            return True
        for doc_id in ids:
            self._client.documents.delete(self._collection_id, doc_id)
        return True

    @classmethod
    def from_texts(
        cls,
        texts: List[str],
        embedding: Optional[Embeddings] = None,
        metadatas: Optional[List[dict]] = None,
        *,
        api_key: str,
        collection_id: Optional[str] = None,
        collection_name: str = "langchain",
        base_url: str = "https://api.meetdewey.com/v1",
        poll_interval: float = 2.0,
        poll_timeout: float = 300.0,
        **kwargs: Any,
    ) -> "DeweyVectorStore":
        """Create a store, upload texts, and wait for them to be ready.

        If ``collection_id`` is provided the texts are added to that existing
        collection. Otherwise a new collection named ``collection_name`` is
        created first.

        The ``embedding`` argument is accepted for interface compatibility but
        is ignored — Dewey manages its own embeddings.
        """
        from dewey import DeweyClient

        client = DeweyClient(api_key=api_key, base_url=base_url)

        if collection_id is None:
            col = client.collections.create(name=collection_name)
            collection_id = col.id

        store = cls(
            api_key=api_key,
            collection_id=collection_id,
            base_url=base_url,
            poll_interval=poll_interval,
            poll_timeout=poll_timeout,
        )
        store.add_texts(texts, metadatas=metadatas)
        return store

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _wait_for_ready(self, ids: List[str]) -> None:
        """Poll until all documents in ``ids`` reach ``ready`` status."""
        pending = set(ids)
        deadline = time.monotonic() + self._poll_timeout

        while pending and time.monotonic() < deadline:
            still_pending: set[str] = set()
            for doc_id in pending:
                doc = self._client.documents.get(self._collection_id, doc_id)
                if doc.status == "error":
                    raise RuntimeError(
                        f"Document {doc_id} failed to process: {doc.errorMessage}"
                    )
                if doc.status != "ready":
                    still_pending.add(doc_id)
            pending = still_pending
            if pending:
                time.sleep(self._poll_interval)

        if pending:
            raise TimeoutError(
                f"{len(pending)} document(s) not ready after {self._poll_timeout}s"
            )


# ── Private helpers ───────────────────────────────────────────────────────────


def _result_to_document(r: Any) -> Document:
    return Document(
        page_content=r.chunk.content,
        metadata={
            "score": r.score,
            "document_id": r.document.id,
            "filename": r.document.filename,
            "section_id": r.section.id,
            "section_title": r.section.title,
            "section_level": r.section.level,
        },
    )
