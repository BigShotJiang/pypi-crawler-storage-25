"""Setup script for navegador-automate."""

from setuptools import setup

setup()
