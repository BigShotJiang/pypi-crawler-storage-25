# rye:signed:2026-04-08T05:48:58Z:1ba9b2b1b656d5801c7af2646727e4bff8ff17acd349a033b04057cd6593960e:riC0w4ELQq8cmUr48SfHrSK8Vtz5x0gusJCYotBmpy107fXvE2T58j9bkBdx1Mgt58GaWdlfYyPJ9vBSaAVKDA:6ea18199041a1ea8
"""Template interpolation — re-exports from rye/core/runtimes/python/lib/.

Canonical implementation lives in core. This module re-exports
so relative imports (from .interpolation import ...) keep working.
"""

__version__ = "1.0.0"
__tool_type__ = "python"
__category__ = "rye/agent/threads/loaders"
__tool_description__ = "Template interpolation for hook actions"

from interpolation import interpolate, interpolate_action  # noqa: F401
