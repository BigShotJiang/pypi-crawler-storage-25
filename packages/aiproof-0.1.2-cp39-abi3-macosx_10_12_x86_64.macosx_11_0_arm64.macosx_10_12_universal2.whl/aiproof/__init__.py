from .aiproof import *

__doc__ = aiproof.__doc__
if hasattr(aiproof, "__all__"):
    __all__ = aiproof.__all__