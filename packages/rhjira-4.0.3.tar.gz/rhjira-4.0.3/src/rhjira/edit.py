import argparse
import sys
from typing import Any, Dict, List, Optional, Sequence

from jira import Issue, JIRA, JIRAError
from jira.resources import Resource

from rhjira import info as rhjira_info, util


def transitionissue(jira: JIRA, issue: Issue, newstatus: str, resolution: str) -> None:
    if issue.fields.status.name == newstatus and newstatus != "Closed":
        print(f"issue {issue.key} is already {newstatus}")
        sys.exit(0)

    try:
        transitions = util.gettransitions(jira, issue)
    except Exception as e:
        util.handle_jira_error(e, f"lookup transitions for {issue.key}")
        sys.exit(1)

    for transition in transitions:
        # according to Jira documentation, the newstatus status must exist.
        if transition["name"] == newstatus:
            try:
                util.transitionissue(jira, issue, transition["id"], resolution)
                # note, rhjiratax must be handled on caller side
                return
            except Exception as e:
                util.handle_jira_error(e, f"transition to {newstatus} for {issue.key}")
                sys.exit(1)
    print(f"Failed to find status '{newstatus}' for project {issue.fields.project.key}")
    sys.exit(1)


def string2entries(data: str) -> Optional[List[Dict[str, str]]]:
    if data.strip() == "":
        return None

    entries = []
    for item in data.split(","):
        entry = {"name": item.strip()}
        entries.append(entry)
    return entries


def _item_display(item: Resource) -> str:
    """String for one list entry (Component/Version .name; User email or displayName)."""
    return (
        getattr(item, "name", None)
        or getattr(item, "emailAddress", None)
        or getattr(item, "displayName", None)
        or str(item)
    ) or ""


def entries2string(data: Optional[Sequence[Resource]]) -> str:
    retstr = ""

    if data is None:
        return retstr

    count = 0
    for item in data:
        count += 1
        retstr = retstr + _item_display(item)
        if count < len(data):
            retstr = retstr + ", "
    return retstr


def edit(jira: JIRA) -> None:
    # handle arguments
    closejira = False
    if "close" in sys.argv:
        closejira = True
        sys.argv.remove("close")
        # Provide custom help for close command
        if "--help" in sys.argv or "-h" in sys.argv:
            print("Usage: rhjira close [--resolution RESOLUTION] TICKET_ID")
            print("")
            print("Close a jira ticket on https://redhat.atlassian.net")
            print("")
            print("positional arguments:")
            print("  TICKET_ID             The ticket ID to close (e.g., RHEL-12345)")
            print("")
            print("options:")
            print("  -h, --help            show this help message and exit")
            print("  --resolution RESOLUTION")
            print("                        why the issue was marked Closed (default: Done)")
            sys.exit(0)

    if "edit" in sys.argv:
        sys.argv.remove("edit")

    parser = argparse.ArgumentParser(
        description="Edit a jira ticket on https://redhat.atlassian.net"
    )
    parser.add_argument(
        "--affectsversion", type=str, default=None, help="Affected Version."
    )
    parser.add_argument(
        "--assignee",
        type=str,
        default=None,
        help="Assignee email address used in RH Jira.",
    )
    parser.add_argument(
        "--close", action="store_true", help="Close Ticket/Set status to 'Closed'"
    )
    parser.add_argument(
        "--components", type=str, default=None, help="Components (must be specified)."
    )
    parser.add_argument(
        "--contributors",
        type=str,
        default=None,
        help="Contributors (comma separated list of email addresses).",
    )
    parser.add_argument(
        "--description", type=str, default=None, help="Description for the ticket."
    )
    parser.add_argument("--epiclink", type=str, default=None, help="Epic Link")
    parser.add_argument("--epicname", type=str, default=None, help="Epic Name")
    parser.add_argument("--fixversion", type=str, default=None, help="Fix/Versions.")
    parser.add_argument(
        "--gitpullrequest", type=str, default=None, help="Git Pull Request"
    )
    parser.add_argument(
        "--noeditor",
        action="store_true",
        help="when set the editor will not be invoked",
    )
    parser.add_argument("--parentlink", type=str, default=None, help="Parent Link")
    parser.add_argument(
        "--priority", type=str, default=None, help="Priority, Normal by default."
    )
    parser.add_argument(
        "--releaseblocker", type=str, default=None, help="Release Blocker Status."
    )
    parser.add_argument(
        "--securitylevel", type=str, default=None, help="Security Level."
    )
    parser.add_argument(
        "--status",
        type=str,
        default=None,
        help="Status (New, In Progress, Review, Closed, etc.)",
    )
    parser.add_argument("--severity", type=str, default=None, help="Severity Level.")
    parser.add_argument(
        "--vexjustification", type=str, default=None,
        help="VEX Justification (Component not Present, Vulnerable Code not Present, etc.)."
    )
    parser.add_argument(
        "--summary",
        type=str,
        default=None,
        help="Summary for the ticket.  Cannot exceed more than one line.",
    )
    parser.add_argument(
        "--isblockedby", type=str, default=None, help="issue which blocks this issue"
    )
    parser.add_argument(
        "--blocks", type=str, default=None, help="issue that is blocked by this issue"
    )
    parser.add_argument(
        "--resolution", type=str, default=None, help="why the issue was marked Closed"
    )
    parser.add_argument(
        "--summarystatus", type=str, default=None, help="Status Summary field"
    )
    parser.add_argument(
        "--sprint", type=str, default=None,
        help="Sprint name or id (optional; may not exist for project)."
    )
    args, ticketIDs = parser.parse_known_args()

    if len(ticketIDs) != 1:
        print(f"Error: ticketID not clear or found: {ticketIDs}")
        sys.exit(1)
    ticketID = ticketIDs[0]

    try:
        issue = util.getissue(jira, ticketID)
    except Exception as e:
        util.handle_jira_error(e, f"lookup ticket {ticketID}")
        sys.exit(1)

    # Check if ticket is closed and user is trying to change security level
    if issue.fields.status.name == "Closed" and args.securitylevel is not None:
        print(f"Error: Cannot change security level on closed ticket {ticketID}")
        print("Please reopen the ticket before changing the security level.")
        sys.exit(1)

    # if 'close' is specified, just close the Jira and return
    if closejira:
        transitionissue(jira, issue, "Closed", args.resolution)
        print(f"Closed https://redhat.atlassian.net/browse/{ticketID}")
        sys.exit(0)

    # clear unset vars
    # for arg in vars(args):
    #    if getattr(args, arg) is None:
    #        setattr(args, arg, "")

    epicname = ""
    if issue.fields.issuetype.name == "Epic":
        epicname = issue.fields.customfield_10011
    if args.epicname is not None:
        epicname = args.epicname

    summary = issue.fields.summary
    if args.summary is not None:
        summary = args.summary

    description = issue.fields.description
    if args.description is not None:
        description = args.description

    assignee = util.user_display_name(issue.fields.assignee)
    if args.assignee is not None:
        assignee = args.assignee

    components = entries2string(issue.fields.components)
    if args.components is not None:
        components = args.components

    affectsversion = entries2string(issue.fields.versions)
    if args.affectsversion is not None:
        affectsversion = args.affectsversion

    fixversion = entries2string(issue.fields.fixVersions)
    if args.fixversion is not None:
        fixversion = args.fixversion

    priority = issue.fields.priority.name
    if args.priority is not None:
        priority = args.priority

    contributors = entries2string(getattr(issue.fields, "customfield_10466", None))
    if args.contributors is not None:
        contributors = args.contributors

    releaseblocker = ""
    cf10847 = getattr(issue.fields, "customfield_10847", None)
    if cf10847 is not None:
        releaseblocker = str(getattr(cf10847, "value", cf10847) or cf10847)
    if args.releaseblocker is not None:
        releaseblocker = args.releaseblocker

    severity = ""
    if issue.fields.customfield_10840 is not None:
        severity = issue.fields.customfield_10840
    if args.severity is not None:
        severity = args.severity

    securitylevel = ""
    if hasattr(issue.fields, 'security') and issue.fields.security is not None:
        securitylevel = issue.fields.security.name
    if args.securitylevel is not None:
        securitylevel = args.securitylevel

    has_vexjustification = "customfield_10873" in issue.raw.get("fields", {})
    vexjustification = ""
    if has_vexjustification:
        cf10873 = getattr(issue.fields, "customfield_10873", None)
        if cf10873 is not None:
            vexjustification = str(getattr(cf10873, "value", cf10873) or cf10873)
    if args.vexjustification is not None:
        vexjustification = args.vexjustification

    summarystatus = ""
    if issue.fields.issuetype.name in ["Feature", "Epic"]:
        if (hasattr(issue.fields, 'customfield_10814') and
            issue.fields.customfield_10814 is not None):
            summarystatus = issue.fields.customfield_10814
        if args.summarystatus is not None:
            summarystatus = args.summarystatus

    isblockedby = ""
    if args.isblockedby is not None:
        isblockedby = args.isblockedby

    blocks = ""
    if args.blocks is not None:
        blocks = args.blocks

    epiclink = ""
    original_epiclink = ""
    if (
        issue.fields.issuetype.name != "Epic"
        and issue.fields.customfield_10014 is not None
    ):
        epiclink = issue.fields.customfield_10014
        original_epiclink = epiclink
    if args.epiclink is not None:
        epiclink = args.epiclink

    parentlink = ""
    if issue.fields.issuetype.name == "Epic":
        parent_obj = getattr(issue.fields, "parent", None)
        if parent_obj is not None and getattr(parent_obj, "key", None):
            parentlink = parent_obj.key
        else:
            parentlink_field = getattr(issue.fields, "customfield_10018", None)
            if parentlink_field is not None:
                parentlink = parentlink_field
    if args.parentlink is not None:
        parentlink = args.parentlink

    gitpullrequest = ""
    if issue.fields.issuetype.name in ["Bug", "Story"]:
        gpr_field = getattr(issue.fields, "customfield_10875", None)
        if gpr_field is not None:
            if isinstance(gpr_field, list):
                gitpullrequest = ",".join(str(u) for u in gpr_field)
            else:
                gitpullrequest = str(gpr_field)
    if args.gitpullrequest is not None:
        gitpullrequest = args.gitpullrequest

    status = issue.fields.status.name
    if args.status is not None:
        status = args.status

    sprint = ""
    sprint_field = getattr(issue.fields, "customfield_10020", None)
    if sprint_field is not None:
        if hasattr(sprint_field, "name"):
            sprint = sprint_field.name or ""
        elif isinstance(sprint_field, list) and sprint_field:
            sprint = getattr(sprint_field[0], "name", "") or ""
    if args.sprint is not None:
        sprint = args.sprint

    resolution = args.resolution
    if resolution is None and issue.fields.resolution is not None:
        resolution = issue.fields.resolution.name

    # Due to the complexities of doing so, tickettype cannot be changed in the CLI.
    # This value is referenced while configuring fields.
    issuetype = issue.fields.issuetype.name

    # Build the Status Summary line only for Features and Epics
    summarystatus_line = ""
    if issuetype in ["Feature", "Epic"]:
        summarystatus_line = f"# Status Summary\nStatus Summary: {summarystatus}\n"

    vexjustification_line = ""
    if has_vexjustification:
        vexjustification_line = (
            "# VEX Justification (Component not Present, Vulnerability Code cannot\n"
            "# be Controlled by Adversary, Inline Mitigations already Exist,\n"
            "# Vulnerable Code not in Execute Path, Vulnerable Code not Present)\n"
            f"VEX Justification: {vexjustification}\n"
        )

    defaultEditText = f"""# Edit {issuetype} {ticketID}. The following fields can be modified.
# Epic Name (required if Ticket Type is Epic, o/w ignored)
Epic Name: {epicname}
# Summary (one line only)
Summary: {summary}
# Status (New, In Progress, Closed, etc.)
Status: {status}
# Description (multi line accepted)
# Note: all 'free' lines in text file will be accepted as part of the Description
Description: {description}
# Assignee (email address)
Assignee: {assignee}
# Components (case sensitive)
Components: {components}
# Affects Versions
Affects Versions: {affectsversion}
# Fix Version
Fix Version: {fixversion}
# Priority
Priority: {priority}
#
# The fields below may not be available on all projects.
#
# Contributors (comma separated list of email addresses)
Contributors: {contributors}
# Release Blocker (default to None)
Release Blocker: {releaseblocker}
# Severity
Severity: {severity}
# Security Level
Security Level: {securitylevel}
{vexjustification_line}{summarystatus_line}# Epic Link
Epic Link: {epiclink}
# Parent Link
Parent Link: {parentlink}
# Git Pull Request
Git Pull Request: {gitpullrequest}
# Is Blocked By
Is Blocked By: {isblockedby}
# Blocks
Blocks: {blocks}
# Resolution (only valid when transitioning to Closed)
Resolution: {resolution}
# Sprint (name or id; leave empty if not applicable)
Sprint: {sprint}
"""

    edittext = ""
    if args.noeditor:
        edittext = util.removecomments(defaultEditText)
    else:
        origtext = util.removecomments(defaultEditText)
        edittext = util.editFile("rhjira", defaultEditText)

        user_set_args = [
            v for k, v in vars(args).items()
            if k not in ("noeditor",) and v not in (None, False, "", [])
        ]

        if origtext == edittext and not user_set_args:
            print("No changes made in editor.... aborting.")
            sys.exit(0)

    fields: Dict[str, Any] = {}
    description = ""
    for line in edittext.splitlines():
        token = line.split(":")[0] + ":"
        data = line[len(token) + 1 :].strip()

        match token:
            case "Project:":
                fields["project"] = {"key": data.strip()}
            case "Ticket Type:":
                fields["issuetype"] = {"name": data.strip()}
            case "Epic Name:":
                if issuetype == "Epic":
                    fields["customfield_10011"] = data.strip()
            case "Summary:":
                fields["summary"] = data.strip()
            case "Description:":
                description = data.strip()
            case "Assignee:":
                # this requires different permissions than editing so it's a separate
                # jira call
                assignee = data.strip()
                if issue.fields.assignee is not None:
                    if assignee != util.user_display_name(issue.fields.assignee):
                        assignee = data.strip()

                if assignee == "":
                    assignee = None  # type: ignore
                try:
                    util.assignissue(jira, issue, assignee)
                    util.rhjiratax(jira)
                except Exception as e:
                    util.handle_jira_error(e, "assign issue")
                    sys.exit(1)
            case "Components:":
                if issuetype == "Epic":
                    continue
                if data == "":
                    fields["components"] = []
                if data != "":
                    fields["components"] = string2entries(data)
            case "Affects Versions:":
                fields["versions"] = []
                if data != "":
                    fields["versions"] = string2entries(data)
            case "Fix Version:":
                fields["fixVersions"] = []
                if data != "":
                    fields["fixVersions"] = string2entries(data)
            case "Priority:":
                if data != "":
                    fields["priority"] = {"name": data.strip()}
            case "Contributors:":
                if data == "":
                    fields["customfield_10466"] = []
                else:
                    entries = util.contributors_entries_for_api(jira, data)
                    if entries:
                        fields["customfield_10466"] = entries
                    # If resolution returned no accountIds, leave field unchanged
            case "Release Blocker:":
                if data == "" and getattr(issue.fields, "customfield_10847", None) is None:
                    continue
                if data != "":
                    fields["customfield_10847"] = {"value": data}
                else:
                    fields["customfield_10847"] = None
            case "Severity:":
                if issuetype == "Epic":
                    continue
                if data != "":
                    fields["customfield_10840"] = {"value": data}
            case "Security Level:":
                if issuetype == "Epic":
                    continue
                # Check if ticket is closed and security level is being changed
                current_security = ""
                if hasattr(issue.fields, 'security') and issue.fields.security:
                    current_security = issue.fields.security.name
                new_security = data.strip()
                if issue.fields.status.name == "Closed" and new_security != current_security:
                    print(f"Error: Cannot change security level on closed ticket {issue.key}")
                    print("Please reopen the ticket before changing the security level.")
                    sys.exit(1)
                if data != "":
                    fields["security"] = {"name": data.strip()}
                else:
                    fields["security"] = None
            case "VEX Justification:":
                if not has_vexjustification:
                    continue
                if data == "" and getattr(issue.fields, "customfield_10873", None) is None:
                    continue
                if data != "":
                    fields["customfield_10873"] = {"value": data}
                else:
                    fields["customfield_10873"] = None
            case "Status Summary:":
                # Only send Status Summary when user explicitly set it; many Epics
                # on Jira Cloud do not have this field.
                if issuetype == "Feature" and args.summarystatus is not None:
                    if data != "":
                        fields["customfield_10814"] = data
                    else:
                        fields["customfield_10814"] = None
            case "Is Blocked By:":
                if data != "":
                    isblockedby = data.strip()
            case "Blocks:":
                if data != "":
                    blocks = data.strip()
            case "Epic Link:":
                if issuetype in ["Epic", "Feature"]:
                    continue
                # Only update if there's actual data or if user explicitly set it via args
                if data != "" and data != original_epiclink:
                    fields["customfield_10014"] = data.strip()
                elif data == "" and original_epiclink != "" and args.epiclink is not None:
                    # Only clear if user explicitly wanted to clear it
                    fields["customfield_10014"] = None
            case "Parent Link:":
                if issuetype != "Epic":
                    continue
                # Jira Cloud: parent = {"key": "KEY"}; DC may use customfield_10018
                if data != "":
                    fields["parent"] = {"key": data.strip()}
            case "Git Pull Request:":
                if issuetype in ["Bug", "Story"]:
                    fields["customfield_10875"] = ""
                    if data != "":
                        fields["customfield_10875"] = f"{data}"
                    else:
                        fields["customfield_10875"] = None
            case "Status:":
                status = data.strip()
            case "Resolution:":
                resolution = None
                if status == "Closed":
                    resolution = data.strip()
                    if resolution == "None":
                        resolution = "Done"
            case "Sprint:":
                project_key = issue.fields.project.key
                if data == "":
                    fields["customfield_10020"] = None
                else:
                    sprint_id = rhjira_info.get_sprint_id(jira, project_key, data)
                    if sprint_id is not None:
                        fields["customfield_10020"] = sprint_id
            case _:
                # this means every 'uncommented' line not in the case statements is
                # part of the description
                description = description + "\n" + line

    # The description is a special case.  If it's been passed on the command line with a \n,
    # then we need to parse this so it looks like real text.
    description = util.convertdescription(description)

    fields["description"] = description

    if issue.fields.status.name != status or status == "Closed":
        transitionissue(jira, issue, status, resolution)

    try:
        issue.update(fields=fields)
        # Create issue links if specified
        if isblockedby:
            util.createissuelink(
                jira,
                'Blocks',  # Link type is always "Blocks"
                isblockedby,  # The blocking issue is the inward issue
                issue.key  # The blocked issue is the outward issue
            )
        if blocks:
            util.createissuelink(
                jira,
                'Blocks',  # Link type is always "Blocks"
                issue.key,  # The blocking issue is the inward issue
                blocks  # The blocked issue is the outward issue
            )
        print(f"https://redhat.atlassian.net/browse/{ticketID}")
    except JIRAError as e:
        util.handle_jira_error(e, "update issue", issue.fields.project.key)
        sys.exit(1)
