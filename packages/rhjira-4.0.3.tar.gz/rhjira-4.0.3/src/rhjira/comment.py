import argparse
import sys

from jira import JIRA

from rhjira import util


def comment(jira: JIRA) -> None:
    # handle arguments
    sys.argv.remove("comment")
    parser = argparse.ArgumentParser(description="Comment on an RH jira ticket")
    parser.add_argument("-f", "--file", type=str, help="file containing comment")
    parser.add_argument(
        "--noeditor",
        action="store_true",
        help="when set the editor will not be invoked",
    )
    parser.add_argument("-v", "--visibility",
        type=str,
        help="visibility restriction for comment (format: 'role:Developers' or 'group:jira-users')",
    )
    args, ticketIDs = parser.parse_known_args()

    if len(ticketIDs) != 1:
        print(f"Error: ticketID not clear or found: {ticketIDs}")
        sys.exit(1)
    ticketID = ticketIDs[0]

    filename = args.file

    try:
        util.getissue(jira, ticketID)
    except Exception as e:
        util.handle_jira_error(e, f"lookup ticket {ticketID}")
        sys.exit(1)

    editorText = "# Lines beginning with '#' will be ignored"
    if filename:
        # read the saved contents of $filename
        try:
            with open(filename, "r") as file:
                editorText = file.read()
        except Exception as error:
            print(f"Unable to open {args.template}: {error}")
            sys.exit(1)

    savedText = editorText
    if not args.noeditor:
        savedText = util.editFile("rhjira", editorText)
        if len(savedText) == 0:
            print("Empty comment buffer ... aborting.")
            sys.exit(1)

    # Parse visibility option
    visibility = None
    if args.visibility:
        if ":" not in args.visibility:
            print("Error: visibility must be in format 'role:RoleName' or 'group:GroupName'")
            sys.exit(1)
        vis_type, vis_value = args.visibility.split(":", 1)
        vis_type = vis_type.strip()
        vis_value = vis_value.strip()
        if vis_type not in ["role", "group"]:
            print("Error: visibility type must be 'role' or 'group'")
            sys.exit(1)
        visibility = {"type": vis_type, "value": vis_value}

    try:
        util.addcomment(jira, ticketID, savedText, visibility)
    except Exception as e:
        util.handle_jira_error(e, f"add comment to {ticketID}")
        print("")
        print("Comment text:")
        print(savedText)
        sys.exit(1)

    print(f"https://redhat.atlassian.net/browse/{ticketID}")
