#!/usr/bin/env bats

check_status() {
	if [ -z "$status" ]; then
		echo -e "\n\n\n Error no 'run' command detected!\n\n\n"
		exit 1
	fi
	if [ "$status" -eq 0 ]; then
		return 0
	fi

	echo "ERROR ERROR ERROR ERROR (see Last output below...)"
	exit 1
}

grepdumpdata() {
	local grepstr=$1
	local issue="${RHJIRA_DUMP_ISSUE:-RHEL-56971}"

	field=$(echo "$grepstr" | cut -d "|" -f2 | cut -d "\\" -f1)
	echo "grepdumpdata field = |$field|"
	[ "$field" != "" ] || return 1

	fieldout=$(./rhjira dump --showcustomfields --showemptyfields --fields "$field" "$issue")

	echo "grepdumpdata command = ./rhjira dump --showcustomfields --showemptyfields --fields \"$field\" $issue"
	echo "grepdumpdata grpstr = |$grepstr|"
	echo "grepdumpdata fieldout: $fieldout"

	echo "test 1: TESTOUTPUT ..."
	grep "$grepstr" $TESTOUTPUT || return 1
	echo "test 2: fieldout ..."
	grep "$grepstr" <<< "$fieldout" || return 1

	return 0
}

getDescription() {
	local output
	local lines
	local first
	local second
	output="$1"
	lines=$(echo "$output" | grep -n "^=")
	first=$(echo "$lines" | head -1 | cut -d":" -f1)
	second=$(echo "$lines" | head -2 | tail -1 | cut -d":" -f1)
	if [ -z "$first" ] || [ -z "$second" ]; then
		echo ""
		return
	fi
	echo "$output" | sed -n "${first},${second}p"
}

removeShowLinks() {
	./rhjira show $1 | sed 's/\x1b\[[0-9;]*m//g' | sed 's/\x1b\]8;;[^\a]*\a//g'
}
