load ./library.bats

# Issue key for show tests. Set RHJIRA_SHOW_ISSUE to an issue that exists on your
# Jira instance (e.g. when using JIRA_SERVER=https://redhat.atlassian.net).
export RHJIRA_SHOW_ISSUE="${RHJIRA_SHOW_ISSUE:-TP-62}"

setup_file() {
	echo "********************************************" >&3
	echo "Running tests in $BATS_TEST_FILENAME" >&3
	echo "********************************************" >&3

	[ -e ./rhjira ] && rm -f ./rhjira
	cp ../bin/rhjira .

	# storyoutput is available as a global variable in this file
	export STORYOUTPUT=$(removeShowLinks "$RHJIRA_SHOW_ISSUE")
	if [ -z "$STORYOUTPUT" ]; then
		export SHOW_SKIP_REASON="$RHJIRA_SHOW_ISSUE not found or inaccessible (show returned no output)"
		# Log stderr so user can see traceback if show crashed
		show_stderr=$(./rhjira show "$RHJIRA_SHOW_ISSUE" 2>&1 >/dev/null) || true
		[ -n "$show_stderr" ] && echo "$show_stderr" >&3 || true
	fi
}

@test "IDandSummary" {
	[ -n "$SHOW_SKIP_REASON" ] && skip "$SHOW_SKIP_REASON"
	# the first line of output is the ID: Summary
	line=$(echo "$STORYOUTPUT" | head -1)
	prefix="${RHJIRA_SHOW_ISSUE}: "
	run [ "${line#$prefix}" != "$line" ]
	check_status
}

@test "description" {
	[ -n "$SHOW_SKIP_REASON" ] && skip "$SHOW_SKIP_REASON"
	# Expected description: body plus create/edit template that may be stored in Jira
	text="===================================
story test test
line 1
line 2
line 3
line 4
# Assignee (email address)
# Components (case sensitive)
# Affects Versions
# Fix Version
# Priority
#
# The fields below may not be available on all projects.
#
# Contributors (comma separated list of email addresses)
# Release Blocker (default to None)
# Severity
# Security Level
# Epic Link
# Parent Link
# Is Blocked By
# Blocks
# Sprint (name or id; leave empty if not applicable)
==================================="
	testtext=$(getDescription "$STORYOUTPUT")
	run [ "$testtext" == "$text" ]
	check_status
}

@test "tickettype" {
	[ -n "$SHOW_SKIP_REASON" ] && skip "$SHOW_SKIP_REASON"
	line=$(echo "$STORYOUTPUT" | grep "Ticket Type:")
	run [ "$line" == "Ticket Type: Story" ]
	check_status
}

@test "status" {
	[ -n "$SHOW_SKIP_REASON" ] && skip "$SHOW_SKIP_REASON"
	line=$(echo "$STORYOUTPUT" | grep "Status:")
	run [ "$line" == "Status: Closed (Done)" ]
	check_status
}

@test "creator" {
	[ -n "$SHOW_SKIP_REASON" ] && skip "$SHOW_SKIP_REASON"
	line=$(echo "$STORYOUTPUT" | grep "Creator:")
	# Jira Cloud may show display name only or "Display Name <email>"; Data Center may show email
	run sh -c 'echo "$1" | grep -qE "Creator:.*(prarit@redhat.com|Prarit Bhargava)"' _ "$line"
	check_status
}

@test "assignee" {
	[ -n "$SHOW_SKIP_REASON" ] && skip "$SHOW_SKIP_REASON"
	line=$(echo "$STORYOUTPUT" | grep "Assignee:")
	# Jira Cloud may show display name only or "Display Name <email>"; Data Center may show email
	run sh -c 'echo "$1" | grep -qE "Assignee:.*(prarit@redhat.com|Prarit Bhargava)"' _ "$line"
	check_status
}

@test "component" {
	[ -n "$SHOW_SKIP_REASON" ] && skip "$SHOW_SKIP_REASON"
	line=$(echo "$STORYOUTPUT" | grep "Components:")
	run [ "$line" == "Components: " ]
	check_status
}

@test "affectsversion" {
	[ -n "$SHOW_SKIP_REASON" ] && skip "$SHOW_SKIP_REASON"
	line=$(echo "$STORYOUTPUT" | grep "Affects Versions:")
	run [ "$line" == "Affects Versions: 3.0" ]
	check_status
}

@test "fixversion" {
	[ -n "$SHOW_SKIP_REASON" ] && skip "$SHOW_SKIP_REASON"
	line=$(echo "$STORYOUTPUT" | grep "Fix Versions:")
	run [ "$line" == "Fix Versions: 3.0" ]
	check_status
}

@test "priority" {
	[ -n "$SHOW_SKIP_REASON" ] && skip "$SHOW_SKIP_REASON"
	line=$(echo "$STORYOUTPUT" | grep "Priority:")
	run [ "$line" == "Priority: Normal" ]
	check_status
}

@test "contributors" {
	[ -n "$SHOW_SKIP_REASON" ] && skip "$SHOW_SKIP_REASON"
	line=$(echo "$STORYOUTPUT" | grep "Contributors:")
	run [ "$line" == "Contributors: " ]
	check_status
}

@test "releaseblocker" {
	[ -n "$SHOW_SKIP_REASON" ] && skip "$SHOW_SKIP_REASON"
	line=$(echo "$STORYOUTPUT" | grep "Release Blocker:")
	run [ "$line" == "Release Blocker: " ]
	check_status
}

@test "severity" {
	[ -n "$SHOW_SKIP_REASON" ] && skip "$SHOW_SKIP_REASON"
	line=$(echo "$STORYOUTPUT" | grep "Severity:")
	run [ "$line" == "Severity: " ]
	check_status
}

@test "epiclink" {
	[ -n "$SHOW_SKIP_REASON" ] && skip "$SHOW_SKIP_REASON"
	line=$(echo "$STORYOUTPUT" | grep "Epic Link:")
	run [ "$line" == "Epic Link: TP-61 rhjira test Epic (Closed)" ]
	check_status
}

# This is a story, so there's only an epic link
#@test "parentlink" {
#	line=$(echo "$STORYOUTPUT" | grep "Parent Link:")
#	echo "|$line|"
#	run [ "$line" == "Parent Link: " ]
#	check_status
#}

@test "gitpullrequest" {
	[ -n "$SHOW_SKIP_REASON" ] && skip "$SHOW_SKIP_REASON"
	line=$(echo "$STORYOUTPUT" | grep "Git Pull Request:")
	run [ "$line" == "Git Pull Request: " ]
	check_status
}

@test "nocomments flag" {
	# Use same issue as other show tests (must exist and have comments for full test)
	output=$(removeShowLinks "$RHJIRA_SHOW_ISSUE")
	run sh -c 'echo "$1" | grep -q "Comments"' _ "$output"
	check_status

	# Test that --nocomments flag suppresses comments
	nocomments_output=$(./rhjira show --nocomments "$RHJIRA_SHOW_ISSUE" | sed 's/\x1b\[[0-9;]*m//g' | sed 's/\x1b\]8;;[^\a]*\a//g')
	run sh -c '! echo "$1" | grep -q "Comments"' _ "$nocomments_output"
	check_status
}
