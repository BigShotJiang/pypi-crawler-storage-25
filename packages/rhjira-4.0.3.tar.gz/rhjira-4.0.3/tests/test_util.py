import json
from unittest import TestCase
from unittest.mock import MagicMock, patch

from jira import JIRA, JIRAError

from rhjira.util import _search_issues, handle_jira_error, retry_jira_operation


class TestRetryJiraOperation(TestCase):
    def setUp(self) -> None:
        self.mock_jira = MagicMock(spec=JIRA)
        self.mock_operation = MagicMock()

    def test_successful_operation(self) -> None:
        """Test that a successful operation returns the expected result."""
        expected_result = "success"
        self.mock_operation.return_value = expected_result

        result = retry_jira_operation(self.mock_operation, self.mock_jira, "arg1", "arg2")

        self.assertEqual(result, expected_result)
        self.mock_operation.assert_called_once_with(self.mock_jira, "arg1", "arg2")

    @patch('rhjira.util.login.login')
    def test_auth_error_with_successful_retry(self, mock_login: MagicMock) -> None:
        """Test that an auth error is handled and retried successfully."""
        # First call fails with auth error, second succeeds
        mock_response = MagicMock()
        mock_response.text = json.dumps({"errorMessages": ["Authentication failed"]})
        jira_error = JIRAError(status_code=401, response=mock_response)
        exception = Exception("Test error")
        exception.__cause__ = jira_error

        self.mock_operation.side_effect = [exception, "success"]
        mock_login.return_value = self.mock_jira

        result = retry_jira_operation(self.mock_operation, self.mock_jira, "arg1", "arg2")

        self.assertEqual(result, "success")
        self.assertEqual(self.mock_operation.call_count, 2)
        mock_login.assert_called_once()

    @patch('rhjira.util.login.login')
    def test_auth_error_max_retries_exceeded(self, mock_login: MagicMock) -> None:
        """Test that max retries are enforced for auth errors."""
        # All calls fail with auth error
        mock_response = MagicMock()
        mock_response.text = json.dumps({"errorMessages": ["Authentication failed"]})
        jira_error = JIRAError(status_code=401, response=mock_response)
        exception = Exception("Test error")
        exception.__cause__ = jira_error

        self.mock_operation.side_effect = exception
        mock_login.return_value = self.mock_jira

        with self.assertRaises(Exception): # noqa B017
            retry_jira_operation(self.mock_operation, self.mock_jira, "arg1", "arg2")

        self.assertEqual(self.mock_operation.call_count, 3)  # Max retries
        self.assertEqual(mock_login.call_count, 2)  # Called twice for retries

    def test_non_auth_error(self) -> None:
        """Test that non-auth errors are not retried."""
        self.mock_operation.side_effect = JIRAError(status_code=404, text="Not found")

        with self.assertRaises(JIRAError):
            retry_jira_operation(self.mock_operation, self.mock_jira, "arg1", "arg2")

        self.mock_operation.assert_called_once()


class TestHandleJiraError(TestCase):
    def setUp(self) -> None:
        self.mock_response = MagicMock()

    def test_jira_error_with_error_messages(self) -> None:
        """Test handling of JIRAError with errorMessages."""
        error_messages = ["Error 1", "Error 2"]
        self.mock_response.text = json.dumps({"errorMessages": error_messages})
        jira_error = JIRAError(status_code=400, response=self.mock_response)
        exception = Exception("Test error")
        exception.__cause__ = jira_error

        result = handle_jira_error(exception, "test operation")

        self.assertFalse(result)  # Not an auth error
        # Note: We can't easily test the print output, but we can verify the function returns False

    def test_jira_error_with_errors(self) -> None:
        """Test handling of JIRAError with errors field."""
        errors = {
            "components": "is not valid",
            "versions": "is not valid",
            "fixVersions": "is not valid"
        }
        self.mock_response.text = json.dumps({"errors": errors})
        jira_error = JIRAError(status_code=400, response=self.mock_response)
        exception = Exception("Test error")
        exception.__cause__ = jira_error

        result = handle_jira_error(exception, "test operation", "TEST-PROJ")

        self.assertFalse(result)  # Not an auth error

    def test_jira_error_json_decode_error(self) -> None:
        """Test handling of JIRAError with invalid JSON response."""
        self.mock_response.text = "invalid json"
        jira_error = JIRAError(status_code=400, response=self.mock_response)
        exception = Exception("Test error")
        exception.__cause__ = jira_error

        result = handle_jira_error(exception, "test operation")

        self.assertFalse(result)  # Not an auth error

    def test_non_jira_error(self) -> None:
        """Test handling of non-JIRAError exception."""
        exception = Exception("Test error")

        result = handle_jira_error(exception, "test operation")

        self.assertFalse(result)  # Not an auth error

    def test_auth_error(self) -> None:
        """Test handling of authentication error (401)."""
        self.mock_response.text = json.dumps({"errorMessages": ["Authentication failed"]})
        jira_error = JIRAError(status_code=401, response=self.mock_response)
        exception = Exception("Test error")
        exception.__cause__ = jira_error

        result = handle_jira_error(exception, "test operation")

        self.assertTrue(result)  # Is an auth error


def _make_result_batch(issues: list, next_page_token: str | None = None) -> MagicMock:
    """Create a mock that behaves like a jira.client.ResultList."""
    batch = MagicMock()
    batch.__iter__ = MagicMock(return_value=iter(issues))
    batch.__len__ = MagicMock(return_value=len(issues))
    batch.__bool__ = MagicMock(return_value=bool(issues))
    batch.nextPageToken = next_page_token
    return batch


class TestSearchIssues(TestCase):
    def setUp(self) -> None:
        self.mock_jira = MagicMock(spec=JIRA)
        self.patcher = patch("rhjira.util.rhjiratax")
        self.patcher.start()

    def tearDown(self) -> None:
        self.patcher.stop()

    def test_single_page(self) -> None:
        """Results fit in one page, no pagination needed."""
        issues = [MagicMock() for _ in range(30)]
        self.mock_jira.enhanced_search_issues.return_value = _make_result_batch(issues)

        result = _search_issues(self.mock_jira, "project = TEST", 50)

        self.assertEqual(len(result), 30)
        self.mock_jira.enhanced_search_issues.assert_called_once_with(
            "project = TEST", nextPageToken=None, maxResults=50
        )

    def test_multiple_pages(self) -> None:
        """Results span multiple pages and are fetched via nextPageToken."""
        page1_issues = [MagicMock() for _ in range(100)]
        page2_issues = [MagicMock() for _ in range(100)]
        page3_issues = [MagicMock() for _ in range(50)]
        self.mock_jira.enhanced_search_issues.side_effect = [
            _make_result_batch(page1_issues, next_page_token="token_page2"),
            _make_result_batch(page2_issues, next_page_token="token_page3"),
            _make_result_batch(page3_issues),
        ]

        result = _search_issues(self.mock_jira, "project = TEST", 300)

        self.assertEqual(len(result), 250)
        self.assertEqual(self.mock_jira.enhanced_search_issues.call_count, 3)
        calls = self.mock_jira.enhanced_search_issues.call_args_list
        self.assertIsNone(calls[0].kwargs["nextPageToken"])
        self.assertEqual(calls[1].kwargs["nextPageToken"], "token_page2")
        self.assertEqual(calls[2].kwargs["nextPageToken"], "token_page3")

    def test_stops_at_maxentries(self) -> None:
        """Pagination stops once maxentries is collected, even if more pages exist."""
        page1_issues = [MagicMock() for _ in range(100)]
        page2_issues = [MagicMock() for _ in range(100)]
        self.mock_jira.enhanced_search_issues.side_effect = [
            _make_result_batch(page1_issues, next_page_token="token_page2"),
            _make_result_batch(page2_issues, next_page_token="token_page3"),
        ]

        result = _search_issues(self.mock_jira, "project = TEST", 150)

        self.assertEqual(len(result), 150)
        self.assertEqual(self.mock_jira.enhanced_search_issues.call_count, 2)
        calls = self.mock_jira.enhanced_search_issues.call_args_list
        self.assertEqual(calls[1].kwargs["maxResults"], 50)

    def test_empty_result(self) -> None:
        """No issues match the query."""
        self.mock_jira.enhanced_search_issues.return_value = _make_result_batch([])

        result = _search_issues(self.mock_jira, "project = EMPTY", 50)

        self.assertEqual(len(result), 0)
        self.mock_jira.enhanced_search_issues.assert_called_once()

    def test_retries_on_jira_error(self) -> None:
        """Transient JIRAError on a page is retried before raising."""
        issues = [MagicMock() for _ in range(10)]
        self.mock_jira.enhanced_search_issues.side_effect = [
            JIRAError(status_code=500, text="Server error"),
            _make_result_batch(issues),
        ]

        result = _search_issues(self.mock_jira, "project = TEST", 50)

        self.assertEqual(len(result), 10)
        self.assertEqual(self.mock_jira.enhanced_search_issues.call_count, 2)

    def test_raises_after_max_retries(self) -> None:
        """Persistent JIRAError exhausts retries and raises RHJiraFetchError."""
        from rhjira.util import RHJiraFetchError

        self.mock_jira.enhanced_search_issues.side_effect = JIRAError(
            status_code=500, text="Server error"
        )

        with self.assertRaises(RHJiraFetchError):
            _search_issues(self.mock_jira, "project = TEST", 50)


class TestSearchIssuesLive(TestCase):
    """Live integration tests that hit the real Jira API.

    These require a valid JIRA_TOKEN and network access.
    Run with: pytest -k TestSearchIssuesLive
    """

    def setUp(self) -> None:
        import rhjira
        self.jira = rhjira.login()

    def test_pagination_returns_more_than_200(self) -> None:
        """Verify pagination fetches more than the 100-per-page API limit."""
        requested = 201
        issues = _search_issues(self.jira, "project = TP", requested)

        self.assertEqual(len(issues), requested)
        # Verify all entries are unique
        keys = [issue.key for issue in issues]
        self.assertEqual(len(keys), len(set(keys)))
