"""Tests for rhjira info module (sprints, get_sprint_id, display_sprints). No Jira modifications."""

from typing import Any
from unittest.mock import MagicMock, patch

from jira import JIRA

from rhjira.info import (
    _fetch_sprints_for_project,
    display_sprints,
    get_sprint_id,
)


def test_get_sprint_id_empty() -> None:
    """Empty or whitespace value returns None."""
    mock_jira = MagicMock(spec=JIRA)
    assert get_sprint_id(mock_jira, "HUM", "") is None
    assert get_sprint_id(mock_jira, "HUM", "   ") is None


def test_get_sprint_id_digit() -> None:
    """Numeric string is returned as int (sprint id)."""
    mock_jira = MagicMock(spec=JIRA)
    assert get_sprint_id(mock_jira, "HUM", "82608") == 82608
    assert get_sprint_id(mock_jira, "HUM", "  123  ") == 123


@patch("rhjira.info._fetch_sprints_for_project")
def test_get_sprint_id_by_name(mock_fetch: MagicMock) -> None:
    """Sprint name resolves to sprint id from fetched sprints."""
    mock_jira = MagicMock(spec=JIRA)
    mock_fetch.return_value = [
        {"id": 82608, "name": "Hum Sprint 7", "state": "active"},
        {"id": 82006, "name": "Hum Sprint 6", "state": "closed"},
    ]
    assert get_sprint_id(mock_jira, "HUM", "Hum Sprint 7") == 82608
    assert get_sprint_id(mock_jira, "HUM", "Hum Sprint 6") == 82006
    mock_fetch.assert_called_with(mock_jira, "HUM")


@patch("rhjira.info._fetch_sprints_for_project")
def test_get_sprint_id_not_found(mock_fetch: MagicMock) -> None:
    """Unknown sprint name returns None."""
    mock_jira = MagicMock(spec=JIRA)
    mock_fetch.return_value = [{"id": 82608, "name": "Hum Sprint 7", "state": "active"}]
    assert get_sprint_id(mock_jira, "HUM", "No Such Sprint") is None


def test_display_sprints_current_and_closed(capsys: Any) -> None:
    """display_sprints shows (current) and (closed) labels."""
    sprints = [
        {"name": "Hum Sprint 7", "state": "active"},
        {"name": "Hum Sprint 6", "state": "closed"},
    ]
    display_sprints(sprints)
    out, _ = capsys.readouterr()
    assert "Hum Sprint 7 (current)" in out
    assert "Hum Sprint 6 (closed)" in out


def test_display_sprints_empty(capsys: Any) -> None:
    """display_sprints with no sprints prints message."""
    display_sprints([])
    out, _ = capsys.readouterr()
    assert "No sprints found" in out


def test_fetch_sprints_sort_order() -> None:
    """_fetch_sprints_for_project returns sprints ordered: active, then closed (recent first)."""
    jira = MagicMock(spec=JIRA)
    jira._options = {"server": "https://redhat.atlassian.net/"}
    session = MagicMock()
    jira._session = session

    resp1 = MagicMock()
    resp1.ok = True
    resp1.json.return_value = {"values": [{"id": 1, "name": "Board 1", "type": "scrum"}]}
    resp2 = MagicMock()
    resp2.ok = True
    resp2.json.return_value = {
        "values": [
            {"id": 82608, "name": "Hum Sprint 7", "state": "active",
             "startDate": "2026-02-05T14:26:00.000Z", "endDate": "2026-02-19T14:26:00.000Z"},
            {"id": 82006, "name": "Hum Sprint 6", "state": "closed",
             "startDate": "2026-01-22T14:48:00.000Z", "endDate": "2026-02-05T14:48:00.000Z"},
            {"id": 81316, "name": "Hum Sprint 5", "state": "closed",
             "startDate": "2026-01-08T14:08:00.000Z", "endDate": "2026-01-22T14:08:00.000Z"},
        ],
        "isLast": True,
    }
    session.get.side_effect = [resp1, resp2]

    result = _fetch_sprints_for_project(jira, "HUM")
    names = [s["name"] for s in result]
    assert names[0] == "Hum Sprint 7"
    assert names[1] == "Hum Sprint 6"
    assert names[2] == "Hum Sprint 5"
