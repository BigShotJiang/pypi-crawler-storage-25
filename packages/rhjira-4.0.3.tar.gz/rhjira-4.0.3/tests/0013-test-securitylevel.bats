#!/usr/bin/env bats

load ./library.bats

setup_file() {
    echo "********************************************" >&3
    echo "Running tests in $BATS_TEST_FILENAME" >&3
    echo "********************************************" >&3

    [ -e ./rhjira ] && rm -f ./rhjira
    cp ../bin/rhjira .

    export JIRAPROJECT=TP

    # Create open ticket for security level edit tests
    url=$(./rhjira create --project TP --tickettype Bug --summary "Security level test -- do not track or use" --description "securitylevel test" --noeditor)
    export testticket=$(echo "$url" | rev | cut -d "/" -f1 | rev)
    export ticket_was_closed="false"

    # Create and close a ticket for "closed ticket" error test
    url=$(./rhjira create --project TP --tickettype Bug --summary "Security level closed test -- do not track or use" --description "closed test" --noeditor)
    export closedticket=$(echo "$url" | rev | cut -d "/" -f1 | rev)
    ./rhjira close "$closedticket"

    echo "Open test ticket: $testticket" >&3
    echo "Closed test ticket: $closedticket" >&3
}

teardown_file() {
    # No need to restore ticket state; we created them for this run
    :
}

@test "test info securitylevels command" {
    # Test that we can list security levels for a project
    echo "Testing info command for security levels" >&3
    
    run ./rhjira info --project ${JIRAPROJECT} securitylevels
    check_status
    
    # Should contain at least one of the common security levels
    [[ "${output}" =~ "Red Hat Employee" ]]
}

@test "test securitylevel show" {
    # Test that show command displays security level
    echo "Testing show command displays security level" >&3
    
    showoutput=$(./rhjira show $testticket --nocomments)
    run grep -q "Security Level:" <<< "$showoutput"
    check_status
}

@test "test securitylevel edit and verify" {
    # Save current security level
    echo "Testing security level edit functionality" >&3
    
    showoutput=$(./rhjira show $testticket --nocomments)
    original_security=$(grep "Security Level:" <<< "$showoutput" | cut -d: -f2- | xargs)
    echo "Original security level: $original_security" >&3
    
    # Change to Red Hat Engineering Authorized
    ./rhjira edit --securitylevel "Red Hat Engineering Authorized" --noeditor $testticket
    
    # Verify the change
    showoutput=$(./rhjira show $testticket --nocomments)
    run grep -q "Security Level: Red Hat Engineering Authorized" <<< "$showoutput"
    check_status
    
    # Change back to original
    if [ -n "$original_security" ]; then
        echo "Restoring original security level: $original_security" >&3
        ./rhjira edit --securitylevel "$original_security" --noeditor $testticket
        
        # Wait for rate limiting
        sleep 1
        
        # Verify restored
        showoutput=$(./rhjira show $testticket --nocomments)
        run grep -q "Security Level: $original_security" <<< "$showoutput"
        check_status
    fi
}

@test "test securitylevel in dump output" {
    # Test that dump command includes security level
    echo "Testing security level in dump output" >&3
    
    # Wait for rate limiting
    sleep 1
    
    dumpoutput=$(./rhjira dump $testticket)
    run grep -q "FIELD\[Security Level\]:" <<< "$dumpoutput"
    check_status
}

@test "test securitylevel on closed ticket returns error" {
    # Test that trying to change security level on a closed ticket returns an error
    echo "Testing security level change on closed ticket returns error" >&3
    
    # closedticket created and closed in setup_file
    
    # Verify ticket is closed
    showoutput=$(./rhjira show $closedticket --nocomments)
    ticket_status=$(grep "^Status:" <<< "$showoutput")
    echo "Closed ticket status: $ticket_status" >&3
    
    # Try to change security level - should fail
    erroroutput=$(./rhjira edit --securitylevel "Red Hat Employee" --noeditor $closedticket 2>&1) || true
    
    echo "Error output: $erroroutput" >&3
    
    # Should contain error message about closed ticket
    run grep -q "Cannot change security level on closed ticket" <<< "$erroroutput"
    check_status
    
    run grep -q "Please reopen the ticket" <<< "$erroroutput"
    check_status
}

