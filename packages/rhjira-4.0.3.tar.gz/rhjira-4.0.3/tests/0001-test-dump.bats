load ./library.bats

# Issue key used for dump tests. Set RHJIRA_DUMP_ISSUE to an issue that exists
# on your Jira instance (e.g. when using JIRA_SERVER=https://redhat.atlassian.net).
export RHJIRA_DUMP_ISSUE="${RHJIRA_DUMP_ISSUE:-RHEL-56971}"

setup_file() {
	echo "********************************************" >&3
	echo "Running tests in $BATS_TEST_FILENAME" >&3
	echo "********************************************" >&3

	[ -e ./rhjira ] && rm -f ./rhjira
	cp ../bin/rhjira .

	export TESTOUTPUT=${BATS_FILE_TMPDIR}/full.out
	./rhjira dump --showcustomfields --showemptyfields "$RHJIRA_DUMP_ISSUE" >& $TESTOUTPUT
}

@test "Release Date_customfield_10929" {
	run grepdumpdata "FIELD\[Release\ Date\|customfield_10929\]:"
	check_status
}

@test "PX Impact Score_customfield_11003" {
	run grepdumpdata "FIELD\[PX\ Impact\ Score\|customfield_11003\]:"
	check_status
}

@test "SFDC Cases Open_customfield_10980" {
	run grepdumpdata "FIELD\[SFDC\ Cases\ Open\|customfield_10980\]:"
	check_status
}

@test "Staffing_customfield_10869" {
	run grepdumpdata "FIELD\[Staffing\|customfield_10869\]:"
	check_status
}

@test "Gating Tests_customfield_10930" {
	run grepdumpdata "FIELD\[Gating\ Tests\|customfield_10930\]:"
	check_status
}

@test "Resolution_resolution" {
	run grepdumpdata "FIELD\[Resolution\|resolution\]:"
	check_status
}

@test "SVN / CVS Isolated Branch_customfield_10808" {
	run grepdumpdata "FIELD\[SVN\ /\ CVS\ Isolated\ Branch\|customfield_10808\]:"
	check_status
}

@test "Support Case Reference_customfield_10816" {
	run grepdumpdata "FIELD\[Support\ Case\ Reference\|customfield_10816\]:"
	check_status
}

@test "Percent complete_customfield_10792" {
	run grepdumpdata "FIELD\[Percent\ complete\|customfield_10792\]:"
	check_status
}

@test "Development_customfield_10000" {
	run grepdumpdata "FIELD\[Development\|customfield_10000\]:"
	check_status
}

@test "Fix Build_customfield_10528" {
	run grepdumpdata "FIELD\[Fix\ Build\|customfield_10528\]:"
	check_status
}

@test "Contributors_customfield_10466" {
	run grepdumpdata "FIELD\[Contributors\|customfield_10466\]:"
	check_status
}

@test "Last Viewed_lastViewed" {
	run grepdumpdata "FIELD\[Last\ Viewed\|lastViewed\]:"
	check_status
}

@test "Business justification_customfield_10674" {
	run grepdumpdata "FIELD\[Business\ justification\|customfield_10674\]:"
	check_status
}

@test "Internal Target Milestone_customfield_10825" {
	run grepdumpdata "FIELD\[Internal\ Target\ Milestone\|customfield_10825\]:"
	check_status
}

@test "Keywords_customfield_10624" {
	run grepdumpdata "FIELD\[Keywords\|customfield_10624\]:"
	check_status
}

@test "CDW qa_ack_customfield_10883" {
	run grepdumpdata "FIELD\[CDW\ qa_ack\|customfield_10883\]:"
	check_status
}

@test "CDW blocker_customfield_10882" {
	run grepdumpdata "FIELD\[CDW\ blocker\|customfield_10882\]:"
	check_status
}

@test "CDW pm_ack_customfield_10884" {
	run grepdumpdata "FIELD\[CDW\ pm_ack\|customfield_10884\]:"
	check_status
}

@test "CDW devel_ack_customfield_10887" {
	run grepdumpdata "FIELD\[CDW\ devel_ack\|customfield_10887\]:"
	check_status
}

@test "Epic Type_customfield_10573" {
	run grepdumpdata "FIELD\[Epic\ Type\|customfield_10573\]:"
	check_status
}

@test "Σ Original Estimate_aggregatetimeoriginalestimate" {
	run grepdumpdata "FIELD\[Σ\ Original\ Estimate\|aggregatetimeoriginalestimate\]:"
	check_status
}

@test "Target Release_customfield_10886" {
	run grepdumpdata "FIELD\[Target\ Release\|customfield_10886\]:"
	check_status
}

@test "CDW release_customfield_10881" {
	run grepdumpdata "FIELD\[CDW\ release\|customfield_10881\]:"
	check_status
}

@test "Affects_customfield_10488" {
	run grepdumpdata "FIELD\[Affects\|customfield_10488\]:"
	check_status
}

@test "Affects Build_customfield_10723" {
	run grepdumpdata "FIELD\[Affects\ Build\|customfield_10723\]:"
	check_status
}

@test "Linked Issues_issuelinks" {
	run grepdumpdata "FIELD\[Linked\ Issues\|issuelinks\]:"
	check_status
}

@test "Assignee_assignee" {
	run grepdumpdata "FIELD\[Assignee\|assignee\]:"
	check_status
}

@test "CDW exception_customfield_10931" {
	run grepdumpdata "FIELD\[CDW\ exception\|customfield_10931\]:"
	check_status
}

@test "Annual Time Savings_customfield_11002" {
	run grepdumpdata "FIELD\[Annual\ Time\ Savings\|customfield_11002\]:"
	check_status
}

@test "QE Priority_customfield_10619" {
	run grepdumpdata "FIELD\[QE\ Priority\|customfield_10619\]:"
	check_status
}

@test "Affected Groups_customfield_10688" {
	run grepdumpdata "FIELD\[Affected\ Groups\|customfield_10688\]:"
	check_status
}

@test "CMDB ID_customfield_10857" {
	run grepdumpdata "FIELD\[CMDB\ ID\|customfield_10857\]:"
	check_status
}

@test "Work Type_customfield_10464" {
	run grepdumpdata "FIELD\[Work\ Type\|customfield_10464\]:"
	check_status
}

@test "ProdDocsReview-CCS_customfield_10888" {
	run grepdumpdata "FIELD\[ProdDocsReview\-CCS\|customfield_10888\]:"
	check_status
}

@test "ProdDocsReview-QE_customfield_10896" {
	run grepdumpdata "FIELD\[ProdDocsReview\-QE\|customfield_10896\]:"
	check_status
}

@test "Strategic Relationship_customfield_10801" {
	run grepdumpdata "FIELD\[Strategic\ Relationship\|customfield_10801\]:"
	check_status
}

@test "ProdDocsReview-Dev_customfield_10890" {
	run grepdumpdata "FIELD\[ProdDocsReview\-Dev\|customfield_10890\]:"
	check_status
}

@test "SME_customfield_10475" {
	run grepdumpdata "FIELD\[SME\|customfield_10475\]:"
	check_status
}

@test "Training Opportunity_customfield_10826" {
	run grepdumpdata "FIELD\[Training\ Opportunity\|customfield_10826\]:"
	check_status
}

@test "Testing Instructions_customfield_10643" {
	run grepdumpdata "FIELD\[Testing\ Instructions\|customfield_10643\]:"
	check_status
}

@test "Training Opportunity Notes_customfield_10597" {
	run grepdumpdata "FIELD\[Training\ Opportunity\ Notes\|customfield_10597\]:"
	check_status
}

@test "Help Desk Ticket Reference_customfield_11009" {
	run grepdumpdata "FIELD\[Help\ Desk\ Ticket\ Reference\|customfield_11009\]:"
	check_status
}

@test "Doc Version/s_customfield_10758" {
	run grepdumpdata "FIELD\[Doc\ Version/s\|customfield_10758\]:"
	check_status
}

@test "Story Points_customfield_10028" {
	run grepdumpdata "FIELD\[Story\ Points\|customfield_10028\]:"
	check_status
}

@test "PX Technical Impact Notes_customfield_11006" {
	run grepdumpdata "FIELD\[PX\ Technical\ Impact\ Notes\|customfield_11006\]:"
	check_status
}

@test "Sub-tasks_subtasks" {
	run grepdumpdata "FIELD\[Sub-tasks\|subtasks\]:"
	check_status
}

@test "GtmhubObjectID_customfield_10940" {
	run grepdumpdata "FIELD\[GtmhubObjectID\|customfield_10940\]:"
	check_status
}

@test "Onsite Date_customfield_10622" {
	run grepdumpdata "FIELD\[Onsite\ Date\|customfield_10622\]:"
	check_status
}

@test "Escape Impact_customfield_10982" {
	run grepdumpdata "FIELD\[Escape\ Impact\|customfield_10982\]:"
	check_status
}

@test "Portfolio Solutions_customfield_10998" {
	run grepdumpdata "FIELD\[Portfolio\ Solutions\|customfield_10998\]:"
	check_status
}

@test "Corrective Measures_customfield_10994" {
	run grepdumpdata "FIELD\[Corrective\ Measures\|customfield_10994\]:"
	check_status
}

@test "Ready-Ready_customfield_10781" {
	run grepdumpdata "FIELD\[Ready\-Ready\|customfield_10781\]:"
	check_status
}

@test "Forum Reference_customfield_10874" {
	run grepdumpdata "FIELD\[Forum\ Reference\|customfield_10874\]:"
	check_status
}

@test "Planned End_customfield_10618" {
	run grepdumpdata "FIELD\[Planned\ End\|customfield_10618\]:"
	check_status
}

@test "QA Contact_customfield_10470" {
	run grepdumpdata "FIELD\[QA\ Contact\|customfield_10470\]:"
	check_status
}

@test "Product_customfield_10608" {
	run grepdumpdata "FIELD\[Product\|customfield_10608\]:"
	check_status
}

@test "Votes_votes" {
	run grepdumpdata "FIELD\[Votes\|votes\]:"
	check_status
}

@test "Log Work_worklog" {
	run grepdumpdata "FIELD\[Log\ Work\|worklog\]:"
	check_status
}

@test "Acceptance Criteria_customfield_10718" {
	run grepdumpdata "FIELD\[Acceptance\ Criteria\|customfield_10718\]:"
	check_status
}

@test "Backlogs_customfield_10531" {
	run grepdumpdata "FIELD\[Backlogs\|customfield_10531\]:"
	check_status
}

@test "Penetration Testing Maturity Level_customfield_10871" {
	run grepdumpdata "FIELD\[Penetration\ Testing\ Maturity\ Level\|customfield_10871\]:"
	check_status
}

@test "Issue Type_issuetype" {
	run grepdumpdata "FIELD\[Issue\ Type\|issuetype\]:"
	check_status
}

@test "SDLC stage when should've been found_customfield_10992" {
	run grepdumpdata "FIELD\[SDLC\ stage\ when\ should've\ been\ found\|customfield_10992\]:"
	check_status
}

@test "SOA Maturity Level_customfield_10657" {
	run grepdumpdata "FIELD\[SOA\ Maturity\ Level\|customfield_10657\]:"
	check_status
}

@test "Threat Model Maturity Level_customfield_10662" {
	run grepdumpdata "FIELD\[Threat\ Model\ Maturity\ Level\|customfield_10662\]:"
	check_status
}

@test "Security Architecture Review Maturity Level_customfield_10660" {
	run grepdumpdata "FIELD\[Security\ Architecture\ Review\ Maturity\ Level\|customfield_10660\]:"
	check_status
}

@test "Escape Reason_customfield_10983" {
	run grepdumpdata "FIELD\[Escape\ Reason\|customfield_10983\]:"
	check_status
}

@test "Internal Whiteboard_customfield_11004" {
	run grepdumpdata "FIELD\[Internal\ Whiteboard\|customfield_11004\]:"
	check_status
}

@test "SAST Maturity Level_customfield_10856" {
	run grepdumpdata "FIELD\[SAST\ Maturity\ Level\|customfield_10856\]:"
	check_status
}

@test "DAST Maturity Level_customfield_10870" {
	run grepdumpdata "FIELD\[DAST\ Maturity\ Level\|customfield_10870\]:"
	check_status
}

@test "SDLC stage when introduced_customfield_10991" {
	run grepdumpdata "FIELD\[SDLC\ stage\ when\ introduced\|customfield_10991\]:"
	check_status
}

@test "SDLC stage when found_customfield_10990" {
	run grepdumpdata "FIELD\[SDLC\ stage\ when\ found\|customfield_10990\]:"
	check_status
}

@test "Engineering Response_customfield_10739" {
	run grepdumpdata "FIELD\[Engineering\ Response\|customfield_10739\]:"
	check_status
}

@test "Patch Visibility_customfield_10562" {
	run grepdumpdata "FIELD\[Patch\ Visibility\|customfield_10562\]:"
	check_status
}

@test "Background and Context_customfield_10500" {
	run grepdumpdata "FIELD\[Background\ and\ Context\|customfield_10500\]:"
	check_status
}

@test "Secure Distribution Maturity Level_customfield_10872" {
	run grepdumpdata "FIELD\[Secure\ Distribution\ Maturity\ Level\|customfield_10872\]:"
	check_status
}

@test "Secure Signing Maturity Level_customfield_10658" {
	run grepdumpdata "FIELD\[Secure\ Signing\ Maturity\ Level\|customfield_10658\]:"
	check_status
}

@test "5-Acks Check_customfield_10486" {
	run grepdumpdata "FIELD\[5\-Acks\ Check\|customfield_10486\]:"
	check_status
}

@test "GitHub Issue_customfield_10747" {
	run grepdumpdata "FIELD\[GitHub\ Issue\|customfield_10747\]:"
	check_status
}

@test "Developer Comment_customfield_10512" {
	run grepdumpdata "FIELD\[Developer\ Comment\|customfield_10512\]:"
	check_status
}

@test "Steps to Reproduce_customfield_10821" {
	run grepdumpdata "FIELD\[Steps\ to\ Reproduce\|customfield_10821\]:"
	check_status
}

@test "Product Management Response_customfield_10775" {
	run grepdumpdata "FIELD\[Product\ Management\ Response\|customfield_10775\]:"
	check_status
}

@test "QE Status_customfield_10802" {
	run grepdumpdata "FIELD\[QE\ Status\|customfield_10802\]:"
	check_status
}

@test "Bugzilla Bug_customfield_10877" {
	run grepdumpdata "FIELD\[Bugzilla\ Bug\|customfield_10877\]:"
	check_status
}

@test "Sync Failure Flag_customfield_10656" {
	run grepdumpdata "FIELD\[Sync\ Failure\ Flag\|customfield_10656\]:"
	check_status
}

@test "Sync Failure Message_customfield_10592" {
	run grepdumpdata "FIELD\[Sync\ Failure\ Message\|customfield_10592\]:"
	check_status
}

@test "Whiteboard_customfield_10841" {
	run grepdumpdata "FIELD\[Whiteboard\|customfield_10841\]:"
	check_status
}

@test "Time to resolution_customfield_10323" {
	run grepdumpdata "FIELD\[Time\ to\ resolution\|customfield_10323\]:"
	check_status
}

@test "Time to first response_customfield_10324" {
	run grepdumpdata "FIELD\[Time\ to\ first\ response\|customfield_10324\]:"
	check_status
}

@test "Approvers (migrated)_customfield_10956" {
	run grepdumpdata "FIELD\[Approvers\ (migrated)\|customfield_10956\]:"
	check_status
}

@test "Patch Repository Link_customfield_10767" {
	run grepdumpdata "FIELD\[Patch\ Repository\ Link\|customfield_10767\]:"
	check_status
}

@test "Patch Instructions_customfield_10602" {
	run grepdumpdata "FIELD\[Patch\ Instructions\|customfield_10602\]:"
	check_status
}

@test "Doc Required_customfield_10756" {
	run grepdumpdata "FIELD\[Doc\ Required\|customfield_10756\]:"
	check_status
}

@test "Stackoverflow ID_customfield_10797" {
	run grepdumpdata "FIELD\[Stackoverflow\ ID\|customfield_10797\]:"
	check_status
}

@test "Funding State_customfield_10745" {
	run grepdumpdata "FIELD\[Funding\ State\|customfield_10745\]:"
	check_status
}

@test "Funding Strategy_customfield_10770" {
	run grepdumpdata "FIELD\[Funding\ Strategy\|customfield_10770\]:"
	check_status
}

@test "Jira Link_customfield_10628" {
	run grepdumpdata "FIELD\[Jira\ Link\|customfield_10628\]:"
	check_status
}

@test "PX Impact Range_customfield_10996" {
	run grepdumpdata "FIELD\[PX\ Impact\ Range\|customfield_10996\]:"
	check_status
}

@test "Other Savings_customfield_11005" {
	run grepdumpdata "FIELD\[Other\ Savings\|customfield_11005\]:"
	check_status
}

@test "Risk Identified Date_customfield_10943" {
	run grepdumpdata "FIELD\[Risk\ Identified\ Date\|customfield_10943\]:"
	check_status
}

@test "Additional Approvers_customfield_10505" {
	run grepdumpdata "FIELD\[Additional\ Approvers\|customfield_10505\]:"
	check_status
}

@test "Security Approvals_customfield_10953" {
	run grepdumpdata "FIELD\[Security\ Approvals\|customfield_10953\]:"
	check_status
}

@test "PX Review Complete_customfield_10987" {
	run grepdumpdata "FIELD\[PX\ Review\ Complete\|customfield_10987\]:"
	check_status
}

@test "SLA Date_customfield_11000" {
	run grepdumpdata "FIELD\[SLA\ Date\|customfield_11000\]:"
	check_status
}

@test "Annual Cost Savings/Avoidance_customfield_11001" {
	run grepdumpdata "FIELD\[Annual\ Cost\ Savings/Avoidance\|customfield_11001\]:"
	check_status
}

@test "PX Technical Impact_customfield_10988" {
	run grepdumpdata "FIELD\[PX\ Technical\ Impact\|customfield_10988\]:"
	check_status
}

@test "PX Priority Data_customfield_10997" {
	run grepdumpdata "FIELD\[PX\ Priority\ Data\|customfield_10997\]:"
	check_status
}

@test "Dev Target end_customfield_10939" {
	run grepdumpdata "FIELD\[Dev\ Target\ end\|customfield_10939\]:"
	check_status
}

@test "Time tracking_timetracking" {
	run grepdumpdata "FIELD\[Time\ tracking\|timetracking\]:"
	check_status
}

@test "GSS Priority_customfield_10985" {
	run grepdumpdata "FIELD\[GSS\ Priority\|customfield_10985\]:"
	check_status
}

@test "Upstream Jira_customfield_10603" {
	run grepdumpdata "FIELD\[Upstream\ Jira\|customfield_10603\]:"
	check_status
}

@test "Customer Name_customfield_10746" {
	run grepdumpdata "FIELD\[Customer\ Name\|customfield_10746\]:"
	check_status
}

@test "Team Confidence_customfield_10811" {
	run grepdumpdata "FIELD\[Team\ Confidence\|customfield_10811\]:"
	check_status
}

@test "QE Confidence_customfield_10613" {
	run grepdumpdata "FIELD\[QE\ Confidence\|customfield_10613\]:"
	check_status
}

@test "Doc Confidence_customfield_10514" {
	run grepdumpdata "FIELD\[Doc\ Confidence\|customfield_10514\]:"
	check_status
}

@test "Business Value_customfield_10834" {
	run grepdumpdata "FIELD\[Business\ Value\|customfield_10834\]:"
	check_status
}

@test "Anomaly_customfield_10893" {
	run grepdumpdata "FIELD\[Anomaly\|customfield_10893\]:"
	check_status
}

@test "Exception Count_customfield_10954" {
	run grepdumpdata "FIELD\[Exception\ Count\|customfield_10954\]:"
	check_status
}

@test "Product/Service_customfield_10655" {
	run grepdumpdata "FIELD\[Product/Service\|customfield_10655\]:"
	check_status
}

@test "Security Controls_customfield_10946" {
	run grepdumpdata "FIELD\[Security\ Controls\|customfield_10946\]:"
	check_status
}

@test "Blocked by Bugzilla Bug_customfield_10880" {
	run grepdumpdata "FIELD\[Blocked\ by\ Bugzilla\ Bug\|customfield_10880\]:"
	check_status
}

@test "Request Clones_customfield_10941" {
	run grepdumpdata "FIELD\[Request\ Clones\|customfield_10941\]:"
	check_status
}

@test "Anomaly Criticality_customfield_10892" {
	run grepdumpdata "FIELD\[Anomaly\ Criticality\|customfield_10892\]:"
	check_status
}

@test "Affects Testing_customfield_10489" {
	run grepdumpdata "FIELD\[Affects\ Testing\|customfield_10489\]:"
	check_status
}

@test "Environment_environment" {
	run grepdumpdata "FIELD\[Environment\|environment\]:"
	check_status
}

@test "Affected Jars_customfield_10691" {
	run grepdumpdata "FIELD\[Affected\ Jars\|customfield_10691\]:"
	check_status
}

@test "Epic Colour_customfield_10013" {
	run grepdumpdata "FIELD\[Epic\ Colour\|customfield_10013\]:"
	check_status
}

@test "PDD Priority_customfield_10757" {
	run grepdumpdata "FIELD\[PDD\ Priority\|customfield_10757\]:"
	check_status
}

@test "Epic Name_customfield_10011" {
	run grepdumpdata "FIELD\[Epic\ Name\|customfield_10011\]:"
	check_status
}

@test "SFDC Cases Links_customfield_10979" {
	run grepdumpdata "FIELD\[SFDC\ Cases\ Links\|customfield_10979\]:"
	check_status
}

@test "Epic Status_customfield_10012" {
	run grepdumpdata "FIELD\[Epic\ Status\|customfield_10012\]:"
	check_status
}

@test "SFDC Cases Counter_customfield_10978" {
	run grepdumpdata "FIELD\[SFDC\ Cases\ Counter\|customfield_10978\]:"
	check_status
}

@test "Due date_duedate" {
	run grepdumpdata "FIELD\[Due\ date\|duedate\]:"
	check_status
}

@test "Component Fix Version(s)_customfield_10742" {
	run grepdumpdata "FIELD\[Component\ Fix\ Version\(s\)\|customfield_10742\]:"
	check_status
}

@test "Epic Link_customfield_10014" {
	run grepdumpdata "FIELD\[Epic\ Link\|customfield_10014\]:"
	check_status
}

@test "EBS Account Number_customfield_11007" {
	run grepdumpdata "FIELD\[EBS\ Account\ Number\|customfield_11007\]:"
	check_status
}

@test "MDM Account Reference_customfield_11008" {
	run grepdumpdata "FIELD\[MDM\ Account\ Reference\|customfield_11008\]:"
	check_status
}

@test "Work Category_customfield_10682" {
	run grepdumpdata "FIELD\[Work\ Category\|customfield_10682\]:"
	check_status
}

@test "Request participants_customfield_10317" {
	run grepdumpdata "FIELD\[Request\ participants\|customfield_10317\]:"
	check_status
}

@test "Approvals_customfield_10316" {
	run grepdumpdata "FIELD\[Approvals\|customfield_10316\]:"
	check_status
}

@test "Satisfaction_customfield_10318" {
	run grepdumpdata "FIELD\[Satisfaction\|customfield_10318\]:"
	check_status
}

@test "Parent Link_customfield_10018" {
	run grepdumpdata "FIELD\[Parent\ Link\|customfield_10018\]:"
	check_status
}

@test "QE Estimate_customfield_10617" {
	run grepdumpdata "FIELD\[QE\ Estimate\|customfield_10617\]:"
	check_status
}

@test "Remaining Estimate_timeestimate" {
	run grepdumpdata "FIELD\[Remaining\ Estimate\|timeestimate\]:"
	check_status
}

@test "EAP PT Community Docs (CD)_customfield_10760" {
	run grepdumpdata "FIELD\[EAP\ PT\ Community\ Docs\ \(CD\)\|customfield_10760\]:"
	check_status
}

@test "EAP PT Test Dev (TD)_customfield_10733" {
	run grepdumpdata "FIELD\[EAP\ PT\ Test\ Dev\ \(TD\)\|customfield_10733\]:"
	check_status
}

@test "Planning Status_customfield_10773" {
	run grepdumpdata "FIELD\[Planning\ Status\|customfield_10773\]:"
	check_status
}

@test "Status_status" {
	run grepdumpdata "FIELD\[Status\|status\]:"
	check_status
}

@test "Status Category_statusCategory" {
	run grepdumpdata "FIELD\[Status\ Category\|statusCategory\]:"
	check_status
}

@test "Parent_parent" {
	run grepdumpdata "FIELD\[Parent\|parent\]:"
	check_status
}

@test "SRE Contact_customfield_10507" {
	run grepdumpdata "FIELD\[SRE\ Contact\|customfield_10507\]:"
	check_status
}

@test "AssignedTeam_customfield_10606" {
	run grepdumpdata "FIELD\[AssignedTeam\|customfield_10606\]:"
	check_status
}

@test "Tester_customfield_10678" {
	run grepdumpdata "FIELD\[Tester\|customfield_10678\]:"
	check_status
}

@test "Account Number_customfield_10806" {
	run grepdumpdata "FIELD\[Account\ Number\|customfield_10806\]:"
	check_status
}

@test "Architect_customfield_10467" {
	run grepdumpdata "FIELD\[Architect\|customfield_10467\]:"
	check_status
}

@test "Σ Remaining Estimate_aggregatetimeestimate" {
	run grepdumpdata "FIELD\[Σ\ Remaining\ Estimate\|aggregatetimeestimate\]:"
	check_status
}

@test "Class of work_customfield_10738" {
	run grepdumpdata "FIELD\[Class\ of\ work\|customfield_10738\]:"
	check_status
}

@test "Prod build version_customfield_10566" {
	run grepdumpdata "FIELD\[Prod\ build\ version\|customfield_10566\]:"
	check_status
}

@test "QE ACK_customfield_10798" {
	run grepdumpdata "FIELD\[QE\ ACK\|customfield_10798\]:"
	check_status
}

@test "Creator_creator" {
	run grepdumpdata "FIELD\[Creator\|creator\]:"
	check_status
}

@test "Satisfaction date_customfield_10319" {
	run grepdumpdata "FIELD\[Satisfaction\ date\|customfield_10319\]:"
	check_status
}

@test "Request Type_customfield_10010" {
	run grepdumpdata "FIELD\[Request\ Type\|customfield_10010\]:"
	check_status
}

@test "Organizations_customfield_10631" {
	run grepdumpdata "FIELD\[Organizations\|customfield_10631\]:"
	check_status
}

@test "Workaround Description_customfield_10843" {
	run grepdumpdata "FIELD\[Workaround\ Description\|customfield_10843\]:"
	check_status
}

@test "Workaround_customfield_10651" {
	run grepdumpdata "FIELD\[Workaround\|customfield_10651\]:"
	check_status
}

@test "Estimated Difficulty_customfield_10741" {
	run grepdumpdata "FIELD\[Estimated\ Difficulty\|customfield_10741\]:"
	check_status
}

@test "Flagged_customfield_10021" {
	run grepdumpdata "FIELD\[Flagged\|customfield_10021\]:"
	check_status
}

@test "Regression Test_customfield_10580" {
	run grepdumpdata "FIELD\[Regression\ Test\|customfield_10580\]:"
	check_status
}

@test "EAP Docs SME_customfield_10561" {
	run grepdumpdata "FIELD\[EAP\ Docs\ SME\|customfield_10561\]:"
	check_status
}

@test "Team_customfield_10001" {
	run grepdumpdata "FIELD\[Team\|customfield_10001\]:"
	check_status
}

@test "Technical Lead_customfield_10675" {
	run grepdumpdata "FIELD\[Technical\ Lead\|customfield_10675\]:"
	check_status
}

@test "Designer_customfield_10499" {
	run grepdumpdata "FIELD\[Designer\|customfield_10499\]:"
	check_status
}

@test "PX Scheduling Request_customfield_11012" {
	run grepdumpdata "FIELD\[PX\ Scheduling\ Request\|customfield_11012\]:"
	check_status
}

@test "Product Manager_customfield_10469" {
	run grepdumpdata "FIELD\[Product\ Manager\|customfield_10469\]:"
	check_status
}

@test "Manager_customfield_10677" {
	run grepdumpdata "FIELD\[Manager\|customfield_10677\]:"
	check_status
}

@test "BZ Partner_customfield_10697" {
	run grepdumpdata "FIELD\[BZ\ Partner\|customfield_10697\]:"
	check_status
}

@test "Time Spent_timespent" {
	run grepdumpdata "FIELD\[Time\ Spent\|timespent\]:"
	check_status
}

@test "RICE Score_customfield_10864" {
	run grepdumpdata "FIELD\[RICE\ Score\|customfield_10864\]:"
	check_status
}

@test "Test Coverage_customfield_10638" {
	run grepdumpdata "FIELD\[Test\ Coverage\|customfield_10638\]:"
	check_status
}

@test "Σ Time Spent_aggregatetimespent" {
	run grepdumpdata "FIELD\[Σ\ Time\ Spent\|aggregatetimespent\]:"
	check_status
}

@test "Pervasiveness_customfield_10989" {
	run grepdumpdata "FIELD\[Pervasiveness\|customfield_10989\]:"
	check_status
}

@test "Willingness to Pay_customfield_10993" {
	run grepdumpdata "FIELD\[Willingness\ to\ Pay\|customfield_10993\]:"
	check_status
}

@test "Cost of Delay_customfield_10635" {
	run grepdumpdata "FIELD\[Cost\ of\ Delay\|customfield_10635\]:"
	check_status
}

@test "Work Source_customfield_10607" {
	run grepdumpdata "FIELD\[Work\ Source\|customfield_10607\]:"
	check_status
}

@test "Work Ratio_workratio" {
	run grepdumpdata "FIELD\[Work\ Ratio\|workratio\]:"
	check_status
}

@test "Customer Cloud Subscription (CCS)_customfield_10696" {
	run grepdumpdata "FIELD\[Customer\ Cloud\ Subscription\ \(CCS\)\|customfield_10696\]:"
	check_status
}

@test "WSJF_customfield_10639" {
	run grepdumpdata "FIELD\[WSJF\|customfield_10639\]:"
	check_status
}

@test "Cluster Admin Enabled_customfield_10699" {
	run grepdumpdata "FIELD\[Cluster\ Admin\ Enabled\|customfield_10699\]:"
	check_status
}

@test "Cloud Platform_customfield_10653" {
	run grepdumpdata "FIELD\[Cloud\ Platform\|customfield_10653\]:"
	check_status
}

@test "Support Scope_customfield_10818" {
	run grepdumpdata "FIELD\[Support\ Scope\|customfield_10818\]:"
	check_status
}

@test "EAP Testing By_customfield_10762" {
	run grepdumpdata "FIELD\[EAP\ Testing\ By\|customfield_10762\]:"
	check_status
}

@test "Experience_customfield_10984" {
	run grepdumpdata "FIELD\[Experience\|customfield_10984\]:"
	check_status
}

@test "Original Estimate_customfield_10556" {
	run grepdumpdata "FIELD\[Original\ Estimate\|customfield_10556\]:"
	check_status
}

@test "Market_customfield_10995" {
	run grepdumpdata "FIELD\[Market\|customfield_10995\]:"
	check_status
}

@test "BZ URL_customfield_10496" {
	run grepdumpdata "FIELD\[BZ\ URL\|customfield_10496\]:"
	check_status
}

@test "Intelligence Requested_customfield_10986" {
	run grepdumpdata "FIELD\[Intelligence\ Requested\|customfield_10986\]:"
	check_status
}

@test "Risk Category_customfield_10679" {
	run grepdumpdata "FIELD\[Risk\ Category\|customfield_10679\]:"
	check_status
}

@test "External issue ID_customfield_10764" {
	run grepdumpdata "FIELD\[External\ issue\ ID\|customfield_10764\]:"
	check_status
}

@test "Risk Type_customfield_10683" {
	run grepdumpdata "FIELD\[Risk\ Type\|customfield_10683\]:"
	check_status
}

@test "Risk Probability_customfield_10642" {
	run grepdumpdata "FIELD\[Risk\ Probability\|customfield_10642\]:"
	check_status
}

@test "Risk Proximity_customfield_10645" {
	run grepdumpdata "FIELD\[Risk\ Proximity\|customfield_10645\]:"
	check_status
}

@test "Risk Impact Level_customfield_10844" {
	run grepdumpdata "FIELD\[Risk\ Impact\ Level\|customfield_10844\]:"
	check_status
}

@test "Risk impact description_customfield_10684" {
	run grepdumpdata "FIELD\[Risk\ impact\ description\|customfield_10684\]:"
	check_status
}

@test "Risk mitigation/contingency_customfield_10686" {
	run grepdumpdata "FIELD\[Risk\ mitigation/contingency\|customfield_10686\]:"
	check_status
}

@test "Operating System_Lab_customfield_10829" {
	run grepdumpdata "FIELD\[Operating\ System_Lab\|customfield_10829\]:"
	check_status
}

@test "Actual Effort_customfield_10676" {
	run grepdumpdata "FIELD\[Actual\ Effort\|customfield_10676\]:"
	check_status
}

@test "Chapter_customfield_10709" {
	run grepdumpdata "FIELD\[Chapter\|customfield_10709\]:"
	check_status
}

@test "EAP PT Pre-Checked (PC)_customfield_10522" {
	run grepdumpdata "FIELD\[EAP\ PT\ Pre\-Checked\ \(PC\)\|customfield_10522\]:"
	check_status
}

@test "EAP PT Product Docs (PD)_customfield_10730" {
	run grepdumpdata "FIELD\[EAP\ PT\ Product\ Docs\ \(PD\)\|customfield_10730\]:"
	check_status
}

@test "EAP PT Docs Analysis (DA)_customfield_10565" {
	run grepdumpdata "FIELD\[EAP\ PT\ Docs\ Analysis\ \(DA\)\|customfield_10565\]:"
	check_status
}

@test "EAP PT Test Plan (TP)_customfield_10735" {
	run grepdumpdata "FIELD\[EAP\ PT\ Test\ Plan\ \(TP\)\|customfield_10735\]:"
	check_status
}

@test "EAP PT Analysis Document (AD)_customfield_10728" {
	run grepdumpdata "FIELD\[EAP\ PT\ Analysis\ Document\ \(AD\)\|customfield_10728\]:"
	check_status
}

@test "Marketing Info_customfield_10661" {
	run grepdumpdata "FIELD\[Marketing\ Info\|customfield_10661\]:"
	check_status
}

@test "Reviewer_customfield_10671" {
	run grepdumpdata "FIELD\[Reviewer\|customfield_10671\]:"
	check_status
}

@test "T-Shirt Size_customfield_10809" {
	run grepdumpdata "FIELD\[T\-Shirt\ Size\|customfield_10809\]:"
	check_status
}

@test "Commit Hashes_customfield_10945" {
	run grepdumpdata "FIELD\[Commit\ Hashes\|customfield_10945\]:"
	check_status
}

@test "Ready_customfield_10484" {
	run grepdumpdata "FIELD\[Ready\|customfield_10484\]:"
	check_status
}

@test "Blocked_customfield_10517" {
	run grepdumpdata "FIELD\[Blocked\|customfield_10517\]:"
	check_status
}

@test "Marketing Info Ready_customfield_10827" {
	run grepdumpdata "FIELD\[Marketing\ Info\ Ready\|customfield_10827\]:"
	check_status
}

@test "Product Documentation Required_customfield_10665" {
	run grepdumpdata "FIELD\[Product\ Documentation\ Required\|customfield_10665\]:"
	check_status
}

@test "Blocked Reason_customfield_10483" {
	run grepdumpdata "FIELD\[Blocked\ Reason\|customfield_10483\]:"
	check_status
}

@test "Owner_customfield_10713" {
	run grepdumpdata "FIELD\[Owner\|customfield_10713\]:"
	check_status
}

@test "Evidence Score_customfield_10526" {
	run grepdumpdata "FIELD\[Evidence\ Score\|customfield_10526\]:"
	check_status
}

@test "Discussed with Team_customfield_10754" {
	run grepdumpdata "FIELD\[Discussed\ with\ Team\|customfield_10754\]:"
	check_status
}

@test "Test Plan_customfield_10935" {
	run grepdumpdata "FIELD\[Test\ Plan\|customfield_10935\]:"
	check_status
}

@test "Analysis Document_customfield_10966" {
	run grepdumpdata "FIELD\[Analysis\ Document\|customfield_10966\]:"
	check_status
}

@test "Microrelease version_customfield_10596" {
	run grepdumpdata "FIELD\[Microrelease\ version\|customfield_10596\]:"
	check_status
}

@test "DevTestDoc_customfield_10722" {
	run grepdumpdata "FIELD\[DevTestDoc\|customfield_10722\]:"
	check_status
}

@test "Target Version_customfield_10855" {
	run grepdumpdata "FIELD\[Target\ Version\|customfield_10855\]:"
	check_status
}

@test "Functional Safety Justification_customfield_10895" {
	run grepdumpdata "FIELD\[Functional\ Safety\ Justification\|customfield_10895\]:"
	check_status
}

@test "EXD-Service_customfield_10524" {
	run grepdumpdata "FIELD\[EXD\-Service\|customfield_10524\]:"
	check_status
}

@test "Functional Safety Triage_customfield_10889" {
	run grepdumpdata "FIELD\[Functional\ Safety\ Triage\|customfield_10889\]:"
	check_status
}

@test "EXD-WorkType_customfield_10569" {
	run grepdumpdata "FIELD\[EXD\-WorkType\|customfield_10569\]:"
	check_status
}

@test "Commitment_customfield_10545" {
	run grepdumpdata "FIELD\[Commitment\|customfield_10545\]:"
	check_status
}

@test "Requesting Teams_customfield_10789" {
	run grepdumpdata "FIELD\[Requesting\ Teams\|customfield_10789\]:"
	check_status
}

@test "Planning_customfield_10553" {
	run grepdumpdata "FIELD\[Planning\|customfield_10553\]:"
	check_status
}

@test "BZ needinfo_customfield_10700" {
	run grepdumpdata "FIELD\[BZ\ needinfo\|customfield_10700\]:"
	check_status
}

@test "Design Doc_customfield_10554" {
	run grepdumpdata "FIELD\[Design\ Doc\|customfield_10554\]:"
	check_status
}

@test "Risk Score_customfield_10976" {
	run grepdumpdata "FIELD\[Risk\ Score\|customfield_10976\]:"
	check_status
}

@test "BZ rhel-8.0.z_customfield_10704" {
	run grepdumpdata "FIELD\[BZ\ rhel\-8\.0\.z\|customfield_10704\]:"
	check_status
}

@test "QEStatus_customfield_10777" {
	run grepdumpdata "FIELD\[QEStatus\|customfield_10777\]:"
	check_status
}

@test "Urgency_customfield_10863" {
	run grepdumpdata "FIELD\[Urgency\|customfield_10863\]:"
	check_status
}

@test "Impact (migrated)_customfield_10836" {
	run grepdumpdata "FIELD\[Impact\ (migrated)\|customfield_10836\]:"
	check_status
}

@test "ZStream Target Release_customfield_10813" {
	run grepdumpdata "FIELD\[ZStream\ Target\ Release\|customfield_10813\]:"
	check_status
}

@test "BZ blocker_customfield_10498" {
	run grepdumpdata "FIELD\[BZ\ blocker\|customfield_10498\]:"
	check_status
}

@test "Needs Product Docs_customfield_10600" {
	run grepdumpdata "FIELD\[Needs\ Product\ Docs\|customfield_10600\]:"
	check_status
}

@test "zstream_customfield_10654" {
	run grepdumpdata "FIELD\[zstream\|customfield_10654\]:"
	check_status
}

@test "BZ Version_customfield_10529" {
	run grepdumpdata "FIELD\[BZ\ Version\|customfield_10529\]:"
	check_status
}

@test "BZ Docs Contact_customfield_10707" {
	run grepdumpdata "FIELD\[BZ\ Docs\ Contact\|customfield_10707\]:"
	check_status
}

@test "BZ requires_doc_text_customfield_10702" {
	run grepdumpdata "FIELD\[BZ\ requires_doc_text\|customfield_10702\]:"
	check_status
}

@test "Doc Commitment_customfield_10817" {
	run grepdumpdata "FIELD\[Doc\ Commitment\|customfield_10817\]:"
	check_status
}

@test "Sprint_customfield_10020" {
	run grepdumpdata "FIELD\[Sprint\|customfield_10020\]:"
	check_status
}

@test "Link to documentation_customfield_10538" {
	run grepdumpdata "FIELD\[Link\ to\ documentation\|customfield_10538\]:"
	check_status
}

@test "OS_customfield_10552" {
	run grepdumpdata "FIELD\[OS\|customfield_10552\]:"
	check_status
}

@test "Public Target Launch Date_customfield_10570" {
	run grepdumpdata "FIELD\[Public\ Target\ Launch\ Date\|customfield_10570\]:"
	check_status
}

@test "Contributing Groups_customfield_10479" {
	run grepdumpdata "FIELD\[Contributing\ Groups\|customfield_10479\]:"
	check_status
}

@test "3scale PT Verified Product_customfield_10717" {
	run grepdumpdata "FIELD\[3scale\ PT\ Verified\ Product\|customfield_10717\]:"
	check_status
}

@test "3scale PT Released In Saas_customfield_10523" {
	run grepdumpdata "FIELD\[3scale\ PT\ Released\ In\ Saas\|customfield_10523\]:"
	check_status
}

@test "3scale PT Docs_customfield_10485" {
	run grepdumpdata "FIELD\[3scale\ PT\ Docs\|customfield_10485\]:"
	check_status
}

@test "3scale PT Product Specs_customfield_10685" {
	run grepdumpdata "FIELD\[3scale\ PT\ Product\ Specs\|customfield_10685\]:"
	check_status
}

@test "Supply Chain STI_customfield_10949" {
	run grepdumpdata "FIELD\[Supply\ Chain\ STI\|customfield_10949\]:"
	check_status
}

@test "Labels_labels" {
	run grepdumpdata "FIELD\[Labels\|labels\]:"
	check_status
}

@test "3scale PT Product Update Ready_customfield_10521" {
	run grepdumpdata "FIELD\[3scale\ PT\ Product\ Update\ Ready\|customfield_10521\]:"
	check_status
}

@test "Target Upstream Version_customfield_10820" {
	run grepdumpdata "FIELD\[Target\ Upstream\ Version\|customfield_10820\]:"
	check_status
}

@test "Close Duplicate Candidate_customfield_10740" {
	run grepdumpdata "FIELD\[Close\ Duplicate\ Candidate\|customfield_10740\]:"
	check_status
}

@test "Partner Requirement State_customfield_10769" {
	run grepdumpdata "FIELD\[Partner\ Requirement\ State\|customfield_10769\]:"
	check_status
}

@test "BZ Target Release_customfield_10495" {
	run grepdumpdata "FIELD\[BZ\ Target\ Release\|customfield_10495\]:"
	check_status
}

@test "Upstream Kernel Target_customfield_10833" {
	run grepdumpdata "FIELD\[Upstream\ Kernel\ Target\|customfield_10833\]:"
	check_status
}

@test "EPM priority_customfield_10567" {
	run grepdumpdata "FIELD\[EPM\ priority\|customfield_10567\]:"
	check_status
}

@test "Case Link_customfield_10501" {
	run grepdumpdata "FIELD\[Case\ Link\|customfield_10501\]:"
	check_status
}

@test "Components_components" {
	run grepdumpdata "FIELD\[Components\|components\]:"
	check_status
}

@test "BZ Flags_customfield_10525" {
	run grepdumpdata "FIELD\[BZ\ Flags\|customfield_10525\]:"
	check_status
}

@test "Service / (sub)product_customfield_10629" {
	run grepdumpdata "FIELD\[Service\ /\ \(sub\)product\|customfield_10629\]:"
	check_status
}

@test "Department_customfield_10551" {
	run grepdumpdata "FIELD\[Department\|customfield_10551\]:"
	check_status
}

@test "Status Summary_customfield_10814" {
	run grepdumpdata "FIELD\[Status\ Summary\|customfield_10814\]:"
	check_status
}

@test "Release Type_customfield_10851" {
	run grepdumpdata "FIELD\[Release\ Type\|customfield_10851\]:"
	check_status
}

@test "Original story points_customfield_10977" {
	run grepdumpdata "FIELD\[Original\ story\ points\|customfield_10977\]:"
	check_status
}

@test "Color Status_customfield_10712" {
	run grepdumpdata "FIELD\[Color\ Status\|customfield_10712\]:"
	check_status
}

@test "Customer Impact_customfield_10689" {
	run grepdumpdata "FIELD\[Customer\ Impact\|customfield_10689\]:"
	check_status
}

@test "UX or UI Contact_customfield_10504" {
	run grepdumpdata "FIELD\[UX\ or\ UI\ Contact\|customfield_10504\]:"
	check_status
}

@test "Documentation Type_customfield_10659" {
	run grepdumpdata "FIELD\[Documentation\ Type\|customfield_10659\]:"
	check_status
}

@test "BZ Keywords_customfield_10615" {
	run grepdumpdata "FIELD\[BZ\ Keywords\|customfield_10615\]:"
	check_status
}

@test "BZ exception_customfield_10734" {
	run grepdumpdata "FIELD\[BZ\ exception\|customfield_10734\]:"
	check_status
}

@test "Additional Assignees_customfield_10465" {
	run grepdumpdata "FIELD\[Additional\ Assignees\|customfield_10465\]:"
	check_status
}

@test "BZ Doc Type_customfield_10729" {
	run grepdumpdata "FIELD\[BZ\ Doc\ Type\|customfield_10729\]:"
	check_status
}

@test "BZ QA Whiteboard_customfield_10732" {
	run grepdumpdata "FIELD\[BZ\ QA\ Whiteboard\|customfield_10732\]:"
	check_status
}

@test "OpenShift Planning Ack_customfield_10761" {
	run grepdumpdata "FIELD\[OpenShift\ Planning\ Ack\|customfield_10761\]:"
	check_status
}

@test "BZ Internal Whiteboard_customfield_10527" {
	run grepdumpdata "FIELD\[BZ\ Internal\ Whiteboard\|customfield_10527\]:"
	check_status
}

@test "Exception Type_customfield_10970" {
	run grepdumpdata "FIELD\[Exception\ Type\|customfield_10970\]:"
	check_status
}

@test "Release Note Text_customfield_10783" {
	run grepdumpdata "FIELD\[Release\ Note\ Text\|customfield_10783\]:"
	check_status
}

@test "Quarter_customfield_10779" {
	run grepdumpdata "FIELD\[Quarter\|customfield_10779\]:"
	check_status
}

@test "release_customfield_10610" {
	run grepdumpdata "FIELD\[release\|customfield_10610\]:"
	check_status
}

@test "Architecture_customfield_10772" {
	run grepdumpdata "FIELD\[Architecture\|customfield_10772\]:"
	check_status
}

@test "BZ Target Milestone_customfield_10494" {
	run grepdumpdata "FIELD\[BZ\ Target\ Milestone\|customfield_10494\]:"
	check_status
}

@test "Cluster ID_customfield_10852" {
	run grepdumpdata "FIELD\[Cluster\ ID\|customfield_10852\]:"
	check_status
}

@test "Aha! URL_customfield_10725" {
	run grepdumpdata "FIELD\[Aha!\ URL\|customfield_10725\]:"
	check_status
}

@test "Approved_customfield_10519" {
	run grepdumpdata "FIELD\[Approved\|customfield_10519\]:"
	check_status
}

@test "Current Status_customfield_10744" {
	run grepdumpdata "FIELD\[Current\ Status\|customfield_10744\]:"
	check_status
}

@test "Size_customfield_10795" {
	run grepdumpdata "FIELD\[Size\|customfield_10795\]:"
	check_status
}

@test "Developer_customfield_10468" {
	run grepdumpdata "FIELD\[Developer\|customfield_10468\]:"
	check_status
}

@test "Sub-System Group_customfield_10620" {
	run grepdumpdata "FIELD\[Sub\-System\ Group\|customfield_10620\]:"
	check_status
}

@test "Reporter_reporter" {
	run grepdumpdata "FIELD\[Reporter\|reporter\]:"
	check_status
}

@test "3Scale PT Tested upstream_customfield_10714" {
	run grepdumpdata "FIELD\[3Scale\ PT\ Tested\ upstream\|customfield_10714\]:"
	check_status
}

@test "Release Note Type_customfield_10785" {
	run grepdumpdata "FIELD\[Release\ Note\ Type\|customfield_10785\]:"
	check_status
}

@test "Supply Chain Program_customfield_10950" {
	run grepdumpdata "FIELD\[Supply\ Chain\ Program\|customfield_10950\]:"
	check_status
}

@test "PM Score_customfield_10790" {
	run grepdumpdata "FIELD\[PM\ Score\|customfield_10790\]:"
	check_status
}

@test "Effort_customfield_10637" {
	run grepdumpdata "FIELD\[Effort\|customfield_10637\]:"
	check_status
}

@test "Confidence_customfield_10838" {
	run grepdumpdata "FIELD\[Confidence\|customfield_10838\]:"
	check_status
}

@test "Reach_customfield_10862" {
	run grepdumpdata "FIELD\[Reach\|customfield_10862\]:"
	check_status
}

@test "BZ Assignee_customfield_10727" {
	run grepdumpdata "FIELD\[BZ\ Assignee\|customfield_10727\]:"
	check_status
}

@test "Release Commit Exception_customfield_10849" {
	run grepdumpdata "FIELD\[Release\ Commit\ Exception\|customfield_10849\]:"
	check_status
}

@test "Upstream Discussion_customfield_10601" {
	run grepdumpdata "FIELD\[Upstream\ Discussion\|customfield_10601\]:"
	check_status
}

@test "Progress_progress" {
	run grepdumpdata "FIELD\[Progress\|progress\]:"
	check_status
}

@test "BZ Doc Text_customfield_10492" {
	run grepdumpdata "FIELD\[BZ\ Doc\ Text\|customfield_10492\]:"
	check_status
}

@test "Market Intelligence Score_customfield_10616" {
	run grepdumpdata "FIELD\[Market\ Intelligence\ Score\|customfield_10616\]:"
	check_status
}

@test "Responsible_customfield_10867" {
	run grepdumpdata "FIELD\[Responsible\|customfield_10867\]:"
	check_status
}

@test "BZ Product_customfield_10731" {
	run grepdumpdata "FIELD\[BZ\ Product\|customfield_10731\]:"
	check_status
}

@test "Release Blocker_customfield_10847" {
	run grepdumpdata "FIELD\[Release\ Blocker\|customfield_10847\]:"
	check_status
}

@test "Risk Response_customfield_10846" {
	run grepdumpdata "FIELD\[Risk\ Response\|customfield_10846\]:"
	check_status
}

@test "Hold_customfield_10774" {
	run grepdumpdata "FIELD\[Hold\|customfield_10774\]:"
	check_status
}

@test "Watch List_customfield_10693" {
	run grepdumpdata "FIELD\[Watch\ List\|customfield_10693\]:"
	check_status
}

@test "RHEL Sub Components_customfield_10579" {
	run grepdumpdata "FIELD\[RHEL\ Sub\ Components\|customfield_10579\]:"
	check_status
}

@test "BZ Whiteboard_customfield_10497" {
	run grepdumpdata "FIELD\[BZ\ Whiteboard\|customfield_10497\]:"
	check_status
}

@test "Need Info Requestees_customfield_10548" {
	run grepdumpdata "FIELD\[Need\ Info\ Requestees\|customfield_10548\]:"
	check_status
}

@test "Product Affects Version_customfield_10568" {
	run grepdumpdata "FIELD\[Product\ Affects\ Version\|customfield_10568\]:"
	check_status
}

@test "Git Commit_customfield_10583" {
	run grepdumpdata "FIELD\[Git\ Commit\|customfield_10583\]:"
	check_status
}

@test "Major Project_customfield_10594" {
	run grepdumpdata "FIELD\[Major\ Project\|customfield_10594\]:"
	check_status
}

@test "Target Milestone_customfield_10595" {
	run grepdumpdata "FIELD\[Target\ Milestone\|customfield_10595\]:"
	check_status
}

@test "Cross Team Epic_customfield_10549" {
	run grepdumpdata "FIELD\[Cross\ Team\ Epic\|customfield_10549\]:"
	check_status
}

@test "In Portfolio_customfield_10751" {
	run grepdumpdata "FIELD\[In\ Portfolio\|customfield_10751\]:"
	check_status
}

@test "MoSCoW_customfield_10544" {
	run grepdumpdata "FIELD\[MoSCoW\|customfield_10544\]:"
	check_status
}

@test "Ack'd Status_customfield_10687" {
	run grepdumpdata "FIELD\[Ack'd\ Status\|customfield_10687\]:"
	check_status
}

@test "Brief_customfield_10537" {
	run grepdumpdata "FIELD\[Brief\|customfield_10537\]:"
	check_status
}

@test "SP-Watchlist_customfield_10737" {
	run grepdumpdata "FIELD\[SP\-Watchlist\|customfield_10737\]:"
	check_status
}

@test "Block/Fail - Additional Details_customfield_10535" {
	run grepdumpdata "FIELD\[Block/Fail\ \-\ Additional\ Details\|customfield_10535\]:"
	check_status
}

@test "Watchlist Proposed Solution_customfield_10649" {
	run grepdumpdata "FIELD\[Watchlist\ Proposed\ Solution\|customfield_10649\]:"
	check_status
}

@test "Shepherd_customfield_10711" {
	run grepdumpdata "FIELD\[Shepherd\|customfield_10711\]:"
	check_status
}

@test "Project_project" {
	run grepdumpdata "FIELD\[Project\|project\]:"
	check_status
}

@test "Automated Test_customfield_10490" {
	run grepdumpdata "FIELD\[Automated\ Test\|customfield_10490\]:"
	check_status
}

@test "Test Plan Created_customfield_10640" {
	run grepdumpdata "FIELD\[Test\ Plan\ Created\|customfield_10640\]:"
	check_status
}

@test "Design Doc Created_customfield_10721" {
	run grepdumpdata "FIELD\[Design\ Doc\ Created\|customfield_10721\]:"
	check_status
}

@test "Committed Version_customfield_10547" {
	run grepdumpdata "FIELD\[Committed\ Version\|customfield_10547\]:"
	check_status
}

@test "Product Lead_customfield_10478" {
	run grepdumpdata "FIELD\[Product\ Lead\|customfield_10478\]:"
	check_status
}

@test "Level of Effort_customfield_10536" {
	run grepdumpdata "FIELD\[Level\ of\ Effort\|customfield_10536\]:"
	check_status
}

@test "Resolved_resolutiondate" {
	run grepdumpdata "FIELD\[Resolved\|resolutiondate\]:"
	check_status
}

@test "Interop Bug ID_customfield_10534" {
	run grepdumpdata "FIELD\[Interop\ Bug\ ID\|customfield_10534\]:"
	check_status
}

@test "Watchlist Impact_customfield_10839" {
	run grepdumpdata "FIELD\[Watchlist\ Impact\|customfield_10839\]:"
	check_status
}

@test "PM Business Priority_customfield_10788" {
	run grepdumpdata "FIELD\[PM\ Business\ Priority\|customfield_10788\]:"
	check_status
}

@test "Request Description_customfield_10582" {
	run grepdumpdata "FIELD\[Request\ Description\|customfield_10582\]:"
	check_status
}

@test "Customers_customfield_10716" {
	run grepdumpdata "FIELD\[Customers\|customfield_10716\]:"
	check_status
}

@test "Resolved Date_customfield_10584" {
	run grepdumpdata "FIELD\[Resolved\ Date\|customfield_10584\]:"
	check_status
}

@test "Watchers_watches" {
	run grepdumpdata "FIELD\[Watchers\|watches\]:"
	check_status
}

@test "Triage Status_customfield_10828" {
	run grepdumpdata "FIELD\[Triage\ Status\|customfield_10828\]:"
	check_status
}

@test "BZ Status_customfield_10698" {
	run grepdumpdata "FIELD\[BZ\ Status\|customfield_10698\]:"
	check_status
}

@test "Dev Approval_customfield_10555" {
	run grepdumpdata "FIELD\[Dev\ Approval\|customfield_10555\]:"
	check_status
}

@test "Docs Approval_customfield_10518" {
	run grepdumpdata "FIELD\[Docs\ Approval\|customfield_10518\]:"
	check_status
}

@test "PX Approval_customfield_10539" {
	run grepdumpdata "FIELD\[PX\ Approval\|customfield_10539\]:"
	check_status
}

@test "Test Failure Category_customfield_10823" {
	run grepdumpdata "FIELD\[Test\ Failure\ Category\|customfield_10823\]:"
	check_status
}

@test "PM Approval_customfield_10560" {
	run grepdumpdata "FIELD\[PM\ Approval\|customfield_10560\]:"
	check_status
}

@test "Planning Target_customfield_10641" {
	run grepdumpdata "FIELD\[Planning\ Target\|customfield_10641\]:"
	check_status
}

@test "Requires_doc_text_customfield_10627" {
	run grepdumpdata "FIELD\[Requires_doc_text\|customfield_10627\]:"
	check_status
}

@test "QE Approval_customfield_10800" {
	run grepdumpdata "FIELD\[QE\ Approval\|customfield_10800\]:"
	check_status
}

@test "Start Date (migrated)_customfield_10799" {
	run grepdumpdata "FIELD\[Start\ Date\ (migrated)\|customfield_10799\]:"
	check_status
}

@test "Operating System_customfield_10763" {
	run grepdumpdata "FIELD\[Operating\ System\|customfield_10763\]:"
	check_status
}

@test "Orchestrator Version_customfield_10786" {
	run grepdumpdata "FIELD\[Orchestrator\ Version\|customfield_10786\]:"
	check_status
}

@test "Orchestrator_customfield_10765" {
	run grepdumpdata "FIELD\[Orchestrator\|customfield_10765\]:"
	check_status
}

@test "Cluster Flavor_customfield_10710" {
	run grepdumpdata "FIELD\[Cluster\ Flavor\|customfield_10710\]:"
	check_status
}

@test "Closed_customfield_10944" {
	run grepdumpdata "FIELD\[Closed\|customfield_10944\]:"
	check_status
}

@test "Release Delivery_customfield_10805" {
	run grepdumpdata "FIELD\[Release\ Delivery\|customfield_10805\]:"
	check_status
}

@test "Target Backport Versions_customfield_10878" {
	run grepdumpdata "FIELD\[Target\ Backport\ Versions\|customfield_10878\]:"
	check_status
}

@test "Docker Version_customfield_10516" {
	run grepdumpdata "FIELD\[Docker\ Version\|customfield_10516\]:"
	check_status
}

@test "Partner Team_customfield_10493" {
	run grepdumpdata "FIELD\[Partner\ Team\|customfield_10493\]:"
	check_status
}

@test "BZ Devel Whiteboard_customfield_10491" {
	run grepdumpdata "FIELD\[BZ\ Devel\ Whiteboard\|customfield_10491\]:"
	check_status
}

@test "Updated_updated" {
	run grepdumpdata "FIELD\[Updated\|updated\]:"
	check_status
}

@test "Need Info From_customfield_10482" {
	run grepdumpdata "FIELD\[Need\ Info\ From\|customfield_10482\]:"
	check_status
}

@test "Organization Sponsor_customfield_10558" {
	run grepdumpdata "FIELD\[Organization\ Sponsor\|customfield_10558\]:"
	check_status
}

@test "Sponsor_customfield_10509" {
	run grepdumpdata "FIELD\[Sponsor\|customfield_10509\]:"
	check_status
}

@test "Product Sponsor_customfield_10612" {
	run grepdumpdata "FIELD\[Product\ Sponsor\|customfield_10612\]:"
	check_status
}

@test "Review Deadline_customfield_10780" {
	run grepdumpdata "FIELD\[Review\ Deadline\|customfield_10780\]:"
	check_status
}

@test "Severity_customfield_10840" {
	run grepdumpdata "FIELD\[Severity\|customfield_10840\]:"
	check_status
}

@test "Strategy Approved_customfield_10634" {
	run grepdumpdata "FIELD\[Strategy\ Approved\|customfield_10634\]:"
	check_status
}

@test "Original estimate_timeoriginalestimate" {
	run grepdumpdata "FIELD\[Original\ estimate\|timeoriginalestimate\]:"
	check_status
}

@test "Description_description" {
	run grepdumpdata "FIELD\[Description\|description\]:"
	check_status
}

@test "DEV Story Points_customfield_10506" {
	run grepdumpdata "FIELD\[DEV\ Story\ Points\|customfield_10506\]:"
	check_status
}

@test "QE Story Points_customfield_10572" {
	run grepdumpdata "FIELD\[QE\ Story\ Points\|customfield_10572\]:"
	check_status
}

@test "Regression_customfield_10623" {
	run grepdumpdata "FIELD\[Regression\|customfield_10623\]:"
	check_status
}

@test "DOC Story Points_customfield_10510" {
	run grepdumpdata "FIELD\[DOC\ Story\ Points\|customfield_10510\]:"
	check_status
}

@test "Market Intelligence_customfield_10480" {
	run grepdumpdata "FIELD\[Market\ Intelligence\|customfield_10480\]:"
	check_status
}

@test "Function Impact_customfield_10768" {
	run grepdumpdata "FIELD\[Function\ Impact\|customfield_10768\]:"
	check_status
}

@test "Test Blocker_customfield_10822" {
	run grepdumpdata "FIELD\[Test\ Blocker\|customfield_10822\]:"
	check_status
}

@test "Automated_customfield_10692" {
	run grepdumpdata "FIELD\[Automated\|customfield_10692\]:"
	check_status
}

@test "oVirt Team_customfield_10845" {
	run grepdumpdata "FIELD\[oVirt\ Team\|customfield_10845\]:"
	check_status
}

@test "CDW support_ack_customfield_10961" {
	run grepdumpdata "FIELD\[CDW\ support_ack\|customfield_10961\]:"
	check_status
}

@test "Summary_summary" {
	run grepdumpdata "FIELD\[Summary\|summary\]:"
	check_status
}

@test "Doc Contact_customfield_10473" {
	run grepdumpdata "FIELD\[Doc\ Contact\|customfield_10473\]:"
	check_status
}

@test "Deployment Environment_customfield_10854" {
	run grepdumpdata "FIELD\[Deployment\ Environment\|customfield_10854\]:"
	check_status
}

@test "Involved teams_customfield_10753" {
	run grepdumpdata "FIELD\[Involved\ teams\|customfield_10753\]:"
	check_status
}

@test "Additional watchers_customfield_10705" {
	run grepdumpdata "FIELD\[Additional\ watchers\|customfield_10705\]:"
	check_status
}

@test "Fixed in Build_customfield_10578" {
	run grepdumpdata "FIELD\[Fixed\ in\ Build\|customfield_10578\]:"
	check_status
}

@test "External issue URL_customfield_10766" {
	run grepdumpdata "FIELD\[External\ issue\ URL\|customfield_10766\]:"
	check_status
}

@test "Fixed In Version_customfield_10743" {
	run grepdumpdata "FIELD\[Fixed\ In\ Version\|customfield_10743\]:"
	check_status
}

@test "ServiceNow ID_customfield_10793" {
	run grepdumpdata "FIELD\[ServiceNow\ ID\|customfield_10793\]:"
	check_status
}

@test "Testable Builds_customfield_10894" {
	run grepdumpdata "FIELD\[Testable\ Builds\|customfield_10894\]:"
	check_status
}

@test "SourceForge Reference_customfield_10631" {
	run grepdumpdata "FIELD\[SourceForge\ Reference\|customfield_10631\]:"
	check_status
}

@test "Gerrit Link_customfield_10530" {
	run grepdumpdata "FIELD\[Gerrit\ Link\|customfield_10530\]:"
	check_status
}

@test "ACKs Check_customfield_10487" {
	run grepdumpdata "FIELD\[ACKs\ Check\|customfield_10487\]:"
	check_status
}

@test "Mojo Link_customfield_10546" {
	run grepdumpdata "FIELD\[Mojo\ Link\|customfield_10546\]:"
	check_status
}

@test "Comment_comment" {
	run grepdumpdata "FIELD\[Comment\|comment\]:"
	check_status
}

@test "Needs Info_customfield_10673" {
	run grepdumpdata "FIELD\[Needs\ Info\|customfield_10673\]:"
	check_status
}

@test "[QE] How to address?_customfield_10614" {
	run grepdumpdata "FIELD\[\[QE\]\ How\ to\ address\?\|customfield_10614\]:"
	check_status
}

@test "Discussion Needed_customfield_10848" {
	run grepdumpdata "FIELD\[Discussion\ Needed\|customfield_10848\]:"
	check_status
}

@test "[QE] Why QE missed?_customfield_10824" {
	run grepdumpdata "FIELD\[\[QE\]\ Why\ QE\ missed\?\|customfield_10824\]:"
	check_status
}

@test "CDW docs_ack_customfield_10885" {
	run grepdumpdata "FIELD\[CDW\ docs_ack\|customfield_10885\]:"
	check_status
}

@test "Discussion Occurred_customfield_10690" {
	run grepdumpdata "FIELD\[Discussion\ Occurred\|customfield_10690\]:"
	check_status
}

@test "RCA Description_customfield_10577" {
	run grepdumpdata "FIELD\[RCA\ Description\|customfield_10577\]:"
	check_status
}

@test "Contributing Teams_customfield_10502" {
	run grepdumpdata "FIELD\[Contributing\ Teams\|customfield_10502\]:"
	check_status
}

@test "Rank_customfield_10019" {
	run grepdumpdata "FIELD\[Rank\|customfield_10019\]:"
	check_status
}

@test "Action_customfield_10720" {
	run grepdumpdata "FIELD\[Action\|customfield_10720\]:"
	check_status
}

@test "Dev Target Milestone_customfield_10557" {
	run grepdumpdata "FIELD\[Dev\ Target\ Milestone\|customfield_10557\]:"
	check_status
}

@test "Reset contact to default_customfield_10937" {
	run grepdumpdata "FIELD\[Reset\ contact\ to\ default\|customfield_10937\]:"
	check_status
}

@test "prev_assignee_customfield_10708" {
	run grepdumpdata "FIELD\[prev_assignee\|customfield_10708\]:"
	check_status
}

@test "Biz Program Manager_customfield_10515" {
	run grepdumpdata "FIELD\[Biz\ Program\ Manager\|customfield_10515\]:"
	check_status
}

@test "PLM  Technical Lead_customfield_10481" {
	run grepdumpdata "FIELD\[PLM\ \ Technical\ Lead\|customfield_10481\]:"
	check_status
}

@test "Planned Start_customfield_10771" {
	run grepdumpdata "FIELD\[Planned\ Start\|customfield_10771\]:"
	check_status
}

@test "Product Page link_customfield_10794" {
	run grepdumpdata "FIELD\[Product\ Page\ link\|customfield_10794\]:"
	check_status
}

@test "Solution_customfield_10590" {
	run grepdumpdata "FIELD\[Solution\|customfield_10590\]:"
	check_status
}

@test "Tech Program Manager_customfield_10474" {
	run grepdumpdata "FIELD\[Tech\ Program\ Manager\|customfield_10474\]:"
	check_status
}

@test "Fix versions_fixVersions" {
	run grepdumpdata "FIELD\[Fix\ versions\|fixVersions\]:"
	check_status
}

@test "Reminder Date_customfield_10787" {
	run grepdumpdata "FIELD\[Reminder\ Date\|customfield_10787\]:"
	check_status
}

@test "Test Work Items_customfield_11011" {
	run grepdumpdata "FIELD\[Test\ Work\ Items\|customfield_11011\]:"
	check_status
}

@test "Internal Product/Project names_customfield_10589" {
	run grepdumpdata "FIELD\[Internal\ Product/Project\ names\|customfield_10589\]:"
	check_status
}

@test "Latest Status Summary_customfield_10778" {
	run grepdumpdata "FIELD\[Latest\ Status\ Summary\|customfield_10778\]:"
	check_status
}

@test "Portal Product Name_customfield_10564" {
	run grepdumpdata "FIELD\[Portal\ Product\ Name\|customfield_10564\]:"
	check_status
}

@test "QE Test Coverage_customfield_10574" {
	run grepdumpdata "FIELD\[QE\ Test\ Coverage\|customfield_10574\]:"
	check_status
}

@test "Stale Date_customfield_10812" {
	run grepdumpdata "FIELD\[Stale\ Date\|customfield_10812\]:"
	check_status
}

@test "Approver_customfield_10664" {
	run grepdumpdata "FIELD\[Approver\|customfield_10664\]:"
	check_status
}

@test "Internal Target Milestone numeric_customfield_10948" {
	run grepdumpdata "FIELD\[Internal\ Target\ Milestone\ numeric\|customfield_10948\]:"
	check_status
}

@test "DevOps Discussion Occurred_customfield_10752" {
	run grepdumpdata "FIELD\[DevOps\ Discussion\ Occurred\|customfield_10752\]:"
	check_status
}

@test "EAP PT Cross Product Agreement (CPA)_customfield_10563" {
	run grepdumpdata "FIELD\[EAP\ PT\ Cross\ Product\ Agreement\ \(CPA\)\|customfield_10563\]:"
	check_status
}

@test "MVP Status_customfield_10593" {
	run grepdumpdata "FIELD\[MVP\ Status\|customfield_10593\]:"
	check_status
}

@test "MTTA_customfield_10962" {
	run grepdumpdata "FIELD\[MTTA\|customfield_10962\]:"
	check_status
}

@test "MTTR_customfield_10963" {
	run grepdumpdata "FIELD\[MTTR\|customfield_10963\]:"
	check_status
}

@test "Organization ID_customfield_10853" {
	run grepdumpdata "FIELD\[Organization\ ID\|customfield_10853\]:"
	check_status
}

@test "Software_customfield_10969" {
	run grepdumpdata "FIELD\[Software\|customfield_10969\]:"
	check_status
}

@test "Design Review Sign-off_customfield_10508" {
	run grepdumpdata "FIELD\[Design\ Review\ Sign\-off\|customfield_10508\]:"
	check_status
}

@test "Risk Impact_customfield_10842" {
	run grepdumpdata "FIELD\[Risk\ Impact\|customfield_10842\]:"
	check_status
}

@test "Risk Likelihood_customfield_10646" {
	run grepdumpdata "FIELD\[Risk\ Likelihood\|customfield_10646\]:"
	check_status
}

@test "Priority_priority" {
	run grepdumpdata "FIELD\[Priority\|priority\]:"
	check_status
}

@test "Impacts_customfield_10749" {
	run grepdumpdata "FIELD\[Impacts\|customfield_10749\]:"
	check_status
}

@test "Involved_customfield_10472" {
	run grepdumpdata "FIELD\[Involved\|customfield_10472\]:"
	check_status
}

@test "Affects versions_versions" {
	run grepdumpdata "FIELD\[Affects\ versions\|versions\]:"
	check_status
}

@test "Next Planned Release Date_customfield_10759" {
	run grepdumpdata "FIELD\[Next\ Planned\ Release\ Date\|customfield_10759\]:"
	check_status
}

@test "Risk Mitigation Strategy_customfield_10680" {
	run grepdumpdata "FIELD\[Risk\ Mitigation\ Strategy\|customfield_10680\]:"
	check_status
}

@test "Risk Score Assessment_customfield_10974" {
	run grepdumpdata "FIELD\[Risk\ Score\ Assessment\|customfield_10974\]:"
	check_status
}

@test "Avoidable_customfield_10866" {
	run grepdumpdata "FIELD\[Avoidable\|customfield_10866\]:"
	check_status
}

@test "Target end_customfield_10023" {
	run grepdumpdata "FIELD\[Target\ end\|customfield_10023\]:"
	check_status
}

@test "Target start_customfield_10022" {
	run grepdumpdata "FIELD\[Target\ start\|customfield_10022\]:"
	check_status
}

@test "BZ Devel Conditional NAK_customfield_10694" {
	run grepdumpdata "FIELD\[BZ\ Devel\ Conditional\ NAK\|customfield_10694\]:"
	check_status
}

@test "CDW Resolution_customfield_10706" {
	run grepdumpdata "FIELD\[CDW\ Resolution\|customfield_10706\]:"
	check_status
}

@test "mvp_customfield_10819" {
	run grepdumpdata "FIELD\[mvp\|customfield_10819\]:"
	check_status
}

@test "Key_issuekey" {
	run grepdumpdata "FIELD\[Key\|issuekey\]:"
	check_status
}

@test "rpl_customfield_10652" {
	run grepdumpdata "FIELD\[rpl\|customfield_10652\]:"
	check_status
}

@test "Verified_customfield_10647" {
	run grepdumpdata "FIELD\[Verified\|customfield_10647\]:"
	check_status
}

@test "Documenter_customfield_10668" {
	run grepdumpdata "FIELD\[Documenter\|customfield_10668\]:"
	check_status
}

@test "ITR-ITM_customfield_10587" {
	run grepdumpdata "FIELD\[ITR\-ITM\|customfield_10587\]:"
	check_status
}

@test "Analyst_customfield_10477" {
	run grepdumpdata "FIELD\[Analyst\|customfield_10477\]:"
	check_status
}

@test "Internal Target Release and Milestone_customfield_10776" {
	run grepdumpdata "FIELD\[Internal\ Target\ Release\ and\ Milestone\|customfield_10776\]:"
	check_status
}

@test "Current Deadline_customfield_10503" {
	run grepdumpdata "FIELD\[Current\ Deadline\|customfield_10503\]:"
	check_status
}

@test "Global Practices Lead_customfield_10513" {
	run grepdumpdata "FIELD\[Global\ Practices\ Lead\|customfield_10513\]:"
	check_status
}

@test "Current Deadline Type_customfield_10715" {
	run grepdumpdata "FIELD\[Current\ Deadline\ Type\|customfield_10715\]:"
	check_status
}

@test "Eng. priority_customfield_10571" {
	run grepdumpdata "FIELD\[Eng\.\ priority\|customfield_10571\]:"
	check_status
}

@test "Embargo Override_customfield_10476" {
	run grepdumpdata "FIELD\[Embargo\ Override\|customfield_10476\]:"
	check_status
}

@test "Baseline Start_customfield_10736" {
	run grepdumpdata "FIELD\[Baseline\ Start\|customfield_10736\]:"
	check_status
}

@test "Preliminary Testing_customfield_10879" {
	run grepdumpdata "FIELD\[Preliminary\ Testing\|customfield_10879\]:"
	check_status
}

@test "Watchers Groups_customfield_10471" {
	run grepdumpdata "FIELD\[Watchers\ Groups\|customfield_10471\]:"
	check_status
}

@test "Baseline End_customfield_10533" {
	run grepdumpdata "FIELD\[Baseline\ End\|customfield_10533\]:"
	check_status
}

@test "EAP PT Feature Implementation (FI)_customfield_10520" {
	run grepdumpdata "FIELD\[EAP\ PT\ Feature\ Implementation\ \(FI\)\|customfield_10520\]:"
	check_status
}

@test "Errata Link_customfield_10626" {
	run grepdumpdata "FIELD\[Errata\ Link\|customfield_10626\]:"
	check_status
}

@test "Docs Analysis_customfield_10959" {
	run grepdumpdata "FIELD\[Docs\ Analysis\|customfield_10959\]:"
	check_status
}

@test "Subproject_customfield_10636" {
	run grepdumpdata "FIELD\[Subproject\|customfield_10636\]:"
	check_status
}

@test "Root Cause_customfield_10650" {
	run grepdumpdata "FIELD\[Root\ Cause\|customfield_10650\]:"
	check_status
}

@test "Stage Links_customfield_10960" {
	run grepdumpdata "FIELD\[Stage\ Links\|customfield_10960\]:"
	check_status
}

@test "Docs Pull Request_customfield_10964" {
	run grepdumpdata "FIELD\[Docs\ Pull\ Request\|customfield_10964\]:"
	check_status
}

@test "Project/s_customfield_10796" {
	run grepdumpdata "FIELD\[Project/s\|customfield_10796\]:"
	check_status
}

@test "Σ Progress_aggregateprogress" {
	run grepdumpdata "FIELD\[Σ\ Progress\|aggregateprogress\]:"
	check_status
}

@test "Authorized Party_customfield_10938" {
	run grepdumpdata "FIELD\[Authorized\ Party\|customfield_10938\]:"
	check_status
}

@test "User Story_customfield_10605" {
	run grepdumpdata "FIELD\[User\ Story\|customfield_10605\]:"
	check_status
}

@test "Reminder Frequency_customfield_10625" {
	run grepdumpdata "FIELD\[Reminder\ Frequency\|customfield_10625\]:"
	check_status
}

@test "QE Acceptance Test Link_customfield_10965" {
	run grepdumpdata "FIELD\[QE\ Acceptance\ Test\ Link\|customfield_10965\]:"
	check_status
}

@test "Partner Fixed Version_customfield_10891" {
	run grepdumpdata "FIELD\[Partner\ Fixed\ Version\|customfield_10891\]:"
	check_status
}

@test "Scoping Status_customfield_10586" {
	run grepdumpdata "FIELD\[Scoping\ Status\|customfield_10586\]:"
	check_status
}

@test "QE_AUTO_Coverage_customfield_10803" {
	run grepdumpdata "FIELD\[QE_AUTO_Coverage\|customfield_10803\]:"
	check_status
}

@test "Function_customfield_10581" {
	run grepdumpdata "FIELD\[Function\|customfield_10581\]:"
	check_status
}

@test "Stakeholders_customfield_10633" {
	run grepdumpdata "FIELD\[Stakeholders\|customfield_10633\]:"
	check_status
}

@test "Workstream_customfield_10681" {
	run grepdumpdata "FIELD\[Workstream\|customfield_10681\]:"
	check_status
}

@test "Version_customfield_10837" {
	run grepdumpdata "FIELD\[Version\|customfield_10837\]:"
	check_status
}

@test "CVSS Score_customfield_10859" {
	run grepdumpdata "FIELD\[CVSS\ Score\|customfield_10859\]:"
	check_status
}

@test "CWE ID_customfield_10630" {
	run grepdumpdata "FIELD\[CWE\ ID\|customfield_10630\]:"
	check_status
}

@test "CVE ID_customfield_10667" {
	run grepdumpdata "FIELD\[CVE\ ID\|customfield_10667\]:"
	check_status
}

@test "End Date_customfield_10701" {
	run grepdumpdata "FIELD\[End\ Date\|customfield_10701\]:"
	check_status
}

@test "Security Documentation Type_customfield_10810" {
	run grepdumpdata "FIELD\[Security\ Documentation\ Type\|customfield_10810\]:"
	check_status
}

@test "Source_customfield_10830" {
	run grepdumpdata "FIELD\[Source\|customfield_10830\]:"
	check_status
}

@test "Git Pull Request_customfield_10875" {
	run grepdumpdata "FIELD\[Git\ Pull\ Request\|customfield_10875\]:"
	check_status
}

@test "ID_customfield_10591" {
	run grepdumpdata "FIELD\[ID\|customfield_10591\]:"
	check_status
}

@test "Upstream Affected Component_customfield_10632" {
	run grepdumpdata "FIELD\[Upstream\ Affected\ Component\|customfield_10632\]:"
	check_status
}

@test "Embargo Status_customfield_10860" {
	run grepdumpdata "FIELD\[Embargo\ Status\|customfield_10860\]:"
	check_status
}

@test "Products_customfield_10868" {
	run grepdumpdata "FIELD\[Products\|customfield_10868\]:"
	check_status
}

@test "Images_thumbnail" {
	run grepdumpdata "FIELD\[Images\|thumbnail\]:"
	check_status
}

@test "Special Handling_customfield_10670" {
	run grepdumpdata "FIELD\[Special\ Handling\|customfield_10670\]:"
	check_status
}

@test "Downstream Component Name_customfield_10669" {
	run grepdumpdata "FIELD\[Downstream\ Component\ Name\|customfield_10669\]:"
	check_status
}

@test "Test Link_customfield_11010" {
	run grepdumpdata "FIELD\[Test\ Link\|customfield_11010\]:"
	check_status
}

@test "Docs Impact Notes_customfield_10726" {
	run grepdumpdata "FIELD\[Docs\ Impact\ Notes\|customfield_10726\]:"
	check_status
}

@test "Docs Impact_customfield_10724" {
	run grepdumpdata "FIELD\[Docs\ Impact\|customfield_10724\]:"
	check_status
}

@test "Created_created" {
	run grepdumpdata "FIELD\[Created\|created\]:"
	check_status
}

@test "Marketing Impact Notes_customfield_10542" {
	run grepdumpdata "FIELD\[Marketing\ Impact\ Notes\|customfield_10542\]:"
	check_status
}

@test "GtmhubTaskParentType_customfield_10947" {
	run grepdumpdata "FIELD\[GtmhubTaskParentType\|customfield_10947\]:"
	check_status
}

@test "Marketing Impact_customfield_10540" {
	run grepdumpdata "FIELD\[Marketing\ Impact\|customfield_10540\]:"
	check_status
}

@test "Impact Rating_customfield_10861" {
	run grepdumpdata "FIELD\[Impact\ Rating\|customfield_10861\]:"
	check_status
}

@test "Errata ID_customfield_10672" {
	run grepdumpdata "FIELD\[Errata\ ID\|customfield_10672\]:"
	check_status
}

@test "Docs QE Status_customfield_10559" {
	run grepdumpdata "FIELD\[Docs\ QE\ Status\|customfield_10559\]:"
	check_status
}

@test "Migration Text_customfield_10599" {
	run grepdumpdata "FIELD\[Migration\ Text\|customfield_10599\]:"
	check_status
}

@test "Communication Breakdown_customfield_10865" {
	run grepdumpdata "FIELD\[Communication\ Breakdown\|customfield_10865\]:"
	check_status
}

@test "affectsRHMIVersion_customfield_10609" {
	run grepdumpdata "FIELD\[affectsRHMIVersion\|customfield_10609\]:"
	check_status
}

@test "Product Operations Engineering Contact_customfield_10666" {
	run grepdumpdata "FIELD\[Product\ Operations\ Engineering\ Contact\|customfield_10666\]:"
	check_status
}

@test "Release Milestone_customfield_10648" {
	run grepdumpdata "FIELD\[Release\ Milestone\|customfield_10648\]:"
	check_status
}

@test "QE Properly Involved_customfield_10850" {
	run grepdumpdata "FIELD\[QE\ Properly\ Involved\|customfield_10850\]:"
	check_status
}

@test "Strategic Alignment_customfield_10971" {
	run grepdumpdata "FIELD\[Strategic\ Alignment\|customfield_10971\]:"
	check_status
}

@test "affectsRHOAMVersion_customfield_10815" {
	run grepdumpdata "FIELD\[affectsRHOAMVersion\|customfield_10815\]:"
	check_status
}

@test "Bugzilla References_customfield_10876" {
	run grepdumpdata "FIELD\[Bugzilla\ References\|customfield_10876\]:"
	check_status
}

@test "Security Level_security" {
	run grepdumpdata "FIELD\[Security\ Level\|security\]:"
	check_status
}

@test "Attachment_attachment" {
	run grepdumpdata "FIELD\[Attachment\|attachment\]:"
	check_status
}

@test "Delivery Mode_customfield_10951" {
	run grepdumpdata "FIELD\[Delivery\ Mode\|customfield_10951\]:"
	check_status
}

@test "VEX Justification_customfield_10873" {
	run grepdumpdata "FIELD\[VEX\ Justification\|customfield_10873\]:"
	check_status
}

@test "Chapter #_customfield_10955" {
	run grepdumpdata "FIELD\[Chapter\ \#\|customfield_10955\]:"
	check_status
}

@test "Proposed Initiative_customfield_10611" {
	run grepdumpdata "FIELD\[Proposed\ Initiative\|customfield_10611\]:"
	check_status
}

@test "Keyword_customfield_10755" {
	run grepdumpdata "FIELD\[Keyword\|customfield_10755\]:"
	check_status
}

@test "Workaround (migrated)_customfield_10932" {
	run grepdumpdata "FIELD\[Workaround\ (migrated)\|customfield_10932\]:"
	check_status
}

@test "Immutable Due Date_customfield_10532" {
	run grepdumpdata "FIELD\[Immutable\ Due\ Date\|customfield_10532\]:"
	check_status
}

@test "Failure Category_customfield_10695" {
	run grepdumpdata "FIELD\[Failure\ Category\|customfield_10695\]:"
	check_status
}

@test "Epic Color_customfield_10013" {
	run grepdumpdata "FIELD\[Epic\ Color\|customfield_10013\]:"
	check_status
}

@test "Language_customfield_10663" {
	run grepdumpdata "FIELD\[Language\|customfield_10663\]:"
	check_status
}

@test "RH Private Keywords_customfield_10999" {
	run grepdumpdata "FIELD\[RH\ Private\ Keywords\|customfield_10999\]:"
	check_status
}

@test "Section ID_customfield_10942" {
	run grepdumpdata "FIELD\[Section\ ID\|customfield_10942\]:"
	check_status
}

@test "Section Title_customfield_10934" {
	run grepdumpdata "FIELD\[Section\ Title\|customfield_10934\]:"
	check_status
}

@test "URL_customfield_10933" {
	run grepdumpdata "FIELD\[URL\|customfield_10933\]:"
	check_status
}

@test "Reporter RHN ID_customfield_10952" {
	run grepdumpdata "FIELD\[Reporter\ RHN\ ID\|customfield_10952\]:"
	check_status
}

@test "Notes_customfield_10550" {
	run grepdumpdata "FIELD\[Notes\|customfield_10550\]:"
	check_status
}

@test "sprint_count_customfield_10975" {
	run grepdumpdata "FIELD\[sprint_count\|customfield_10975\]:"
	check_status
}

@test "QE portion_customfield_10621" {
	run grepdumpdata "FIELD\[QE\ portion\|customfield_10621\]:"
	check_status
}

@test "Release Note Status_customfield_10807" {
	run grepdumpdata "FIELD\[Release\ Note\ Status\|customfield_10807\]:"
	check_status
}

@test "Writer_customfield_10511" {
	run grepdumpdata "FIELD\[Writer\|customfield_10511\]:"
	check_status
}

@test "Activity Category_customfield_10682" {
	run grepdumpdata "FIELD\[Activity\ Category\|customfield_10682\]:"
	check_status
}

@test "Activity Type_customfield_10464" {
	run grepdumpdata "FIELD\[Activity\ Type\|customfield_10464\]:"
	check_status
}

@test "Actual end_customfield_10009" {
	run grepdumpdata "FIELD\[Actual\ end\|customfield_10009\]:"
	check_status
}

@test "Actual start_customfield_10008" {
	run grepdumpdata "FIELD\[Actual\ start\|customfield_10008\]:"
	check_status
}

@test "Affected services_customfield_10322" {
	run grepdumpdata "FIELD\[Affected\ services\|customfield_10322\]:"
	check_status
}

@test "Approvals (migrated)_customfield_10967" {
	run grepdumpdata "FIELD\[Approvals\ \(migrated\)\|customfield_10967\]:"
	check_status
}

@test "Approver groups_customfield_10321" {
	run grepdumpdata "FIELD\[Approver\ groups\|customfield_10321\]:"
	check_status
}

@test "Approvers_customfield_10003" {
	run grepdumpdata "FIELD\[Approvers\|customfield_10003\]:"
	check_status
}

@test "Atlassian project status_customfield_10286" {
	run grepdumpdata "FIELD\[Atlassian\ project\ status\|customfield_10286\]:"
	check_status
}

@test "Atlassian project_customfield_10285" {
	run grepdumpdata "FIELD\[Atlassian\ project\|customfield_10285\]:"
	check_status
}

@test "Attachment count_customfield_10431" {
	run grepdumpdata "FIELD\[Attachment\ count\|customfield_10431\]:"
	check_status
}

@test "Bugs of Epic count_customfield_10425" {
	run grepdumpdata "FIELD\[Bugs\ of\ Epic\ count\|customfield_10425\]:"
	check_status
}

@test "Bugs of Epic in Done status category count_customfield_10415" {
	run grepdumpdata "FIELD\[Bugs\ of\ Epic\ in\ Done\ status\ category\ count\|customfield_10415\]:"
	check_status
}

@test "Bugs of Epic in In Progress status category count_customfield_10416" {
	run grepdumpdata "FIELD\[Bugs\ of\ Epic\ in\ In\ Progress\ status\ category\ count\|customfield_10416\]:"
	check_status
}

@test "Bugs of Epic in To Do status category count_customfield_10417" {
	run grepdumpdata "FIELD\[Bugs\ of\ Epic\ in\ To\ Do\ status\ category\ count\|customfield_10417\]:"
	check_status
}

@test "CRT Acceptance Critera_customfield_10968" {
	run grepdumpdata "FIELD\[CRT\ Acceptance\ Critera\|customfield_10968\]:"
	check_status
}

@test "Category_customfield_10033" {
	run grepdumpdata "FIELD\[Category\|customfield_10033\]:"
	check_status
}

@test "Change reason_customfield_10007" {
	run grepdumpdata "FIELD\[Change\ reason\|customfield_10007\]:"
	check_status
}

@test "Change risk_customfield_10006" {
	run grepdumpdata "FIELD\[Change\ risk\|customfield_10006\]:"
	check_status
}

@test "Change type_customfield_10005" {
	run grepdumpdata "FIELD\[Change\ type\|customfield_10005\]:"
	check_status
}

@test "Children count_customfield_10414" {
	run grepdumpdata "FIELD\[Children\ count\|customfield_10414\]:"
	check_status
}

@test "Children of Epic count_customfield_10426" {
	run grepdumpdata "FIELD\[Children\ of\ Epic\ count\|customfield_10426\]:"
	check_status
}

@test "Children of Epic in Done status category count_customfield_10421" {
	run grepdumpdata "FIELD\[Children\ of\ Epic\ in\ Done\ status\ category\ count\|customfield_10421\]:"
	check_status
}

@test "Children of Epic in In Progress status category count_customfield_10422" {
	run grepdumpdata "FIELD\[Children\ of\ Epic\ in\ In\ Progress\ status\ category\ count\|customfield_10422\]:"
	check_status
}

@test "Children of Epic in To Do status category count_customfield_10423" {
	run grepdumpdata "FIELD\[Children\ of\ Epic\ in\ To\ Do\ status\ category\ count\|customfield_10423\]:"
	check_status
}

@test "Classification Level_dataclassification" {
	run grepdumpdata "FIELD\[Classification\ Level\|dataclassification\]:"
	check_status
}

@test "Code Sample_customfield_10543" {
	run grepdumpdata "FIELD\[Code\ Sample\|customfield_10543\]:"
	check_status
}

@test "Comment count_customfield_10430" {
	run grepdumpdata "FIELD\[Comment\ count\|customfield_10430\]:"
	check_status
}

@test "Comments_customfield_10288" {
	run grepdumpdata "FIELD\[Comments\|customfield_10288\]:"
	check_status
}

@test "Completion Steps_customfield_10541" {
	run grepdumpdata "FIELD\[Completion\ Steps\|customfield_10541\]:"
	check_status
}

@test "Contributing Groups Limited Access_customfield_10703" {
	run grepdumpdata "FIELD\[Contributing\ Groups\ Limited\ Access\|customfield_10703\]:"
	check_status
}

@test "Customer Affects Version_customfield_10972" {
	run grepdumpdata "FIELD\[Customer\ Affects\ Version\|customfield_10972\]:"
	check_status
}

@test "Defect Tracker URL_customfield_10748" {
	run grepdumpdata "FIELD\[Defect\ Tracker\ URL\|customfield_10748\]:"
	check_status
}

@test "Delivery progress_customfield_10290" {
	run grepdumpdata "FIELD\[Delivery\ progress\|customfield_10290\]:"
	check_status
}

@test "Delivery status_customfield_10291" {
	run grepdumpdata "FIELD\[Delivery\ status\|customfield_10291\]:"
	check_status
}

@test "Design_customfield_10254" {
	run grepdumpdata "FIELD\[Design\|customfield_10254\]:"
	check_status
}

@test "External issue ID_customfield_11013" {
	run grepdumpdata "FIELD\[External\ issue\ ID\|customfield_11013\]:"
	check_status
}

@test "Failed In_customfield_10575" {
	run grepdumpdata "FIELD\[Failed\ In\|customfield_10575\]:"
	check_status
}

@test "Failure Count_customfield_10576" {
	run grepdumpdata "FIELD\[Failure\ Count\|customfield_10576\]:"
	check_status
}

@test "Focus Areas_customfield_10348" {
	run grepdumpdata "FIELD\[Focus\ Areas\|customfield_10348\]:"
	check_status
}

@test "Goals_customfield_10281" {
	run grepdumpdata "FIELD\[Goals\|customfield_10281\]:"
	check_status
}

@test "Idea archived by_customfield_10283" {
	run grepdumpdata "FIELD\[Idea\ archived\ by\|customfield_10283\]:"
	check_status
}

@test "Idea archived on_customfield_10284" {
	run grepdumpdata "FIELD\[Idea\ archived\ on\|customfield_10284\]:"
	check_status
}

@test "Idea archived_customfield_10282" {
	run grepdumpdata "FIELD\[Idea\ archived\|customfield_10282\]:"
	check_status
}

@test "Impact_customfield_10004" {
	run grepdumpdata "FIELD\[Impact\|customfield_10004\]:"
	check_status
}

@test "Insights_customfield_10287" {
	run grepdumpdata "FIELD\[Insights\|customfield_10287\]:"
	check_status
}

@test "Issue color_customfield_10017" {
	run grepdumpdata "FIELD\[Issue\ color\|customfield_10017\]:"
	check_status
}

@test "Issue link count_customfield_10428" {
	run grepdumpdata "FIELD\[Issue\ link\ count\|customfield_10428\]:"
	check_status
}

@test "Linked items_customfield_10289" {
	run grepdumpdata "FIELD\[Linked\ items\|customfield_10289\]:"
	check_status
}

@test "Locked forms_customfield_10031" {
	run grepdumpdata "FIELD\[Locked\ forms\|customfield_10031\]:"
	check_status
}

@test "ODC Planning Ack_customfield_10784" {
	run grepdumpdata "FIELD\[ODC\ Planning\ Ack\|customfield_10784\]:"
	check_status
}

@test "ODC Planning_customfield_10782" {
	run grepdumpdata "FIELD\[ODC\ Planning\|customfield_10782\]:"
	check_status
}

@test "Open forms_customfield_10029" {
	run grepdumpdata "FIELD\[Open\ forms\|customfield_10029\]:"
	check_status
}

@test "Organizations_customfield_10002" {
	run grepdumpdata "FIELD\[Organizations\|customfield_10002\]:"
	check_status
}

@test "Package NVR_customfield_10786" {
	run grepdumpdata "FIELD\[Package\ NVR\|customfield_10786\]:"
	check_status
}

@test "Partner Affects Version_customfield_10973" {
	run grepdumpdata "FIELD\[Partner\ Affects\ Version\|customfield_10973\]:"
	check_status
}

@test "Percent confident_customfield_10604" {
	run grepdumpdata "FIELD\[Percent\ confident\|customfield_10604\]:"
	check_status
}

@test "Project overview key_customfield_10035" {
	run grepdumpdata "FIELD\[Project\ overview\ key\|customfield_10035\]:"
	check_status
}

@test "Project overview status_customfield_10036" {
	run grepdumpdata "FIELD\[Project\ overview\ status\|customfield_10036\]:"
	check_status
}

@test "RedHat Privacy Banner_customfield_10981" {
	run grepdumpdata "FIELD\[RedHat\ Privacy\ Banner\|customfield_10981\]:"
	check_status
}

@test "Request language_customfield_10320" {
	run grepdumpdata "FIELD\[Request\ language\|customfield_10320\]:"
	check_status
}

@test "Responders_customfield_10381" {
	run grepdumpdata "FIELD\[Responders\|customfield_10381\]:"
	check_status
}

@test "Restrict to_issuerestriction" {
	run grepdumpdata "FIELD\[Restrict\ to\|issuerestriction\]:"
	check_status
}

@test "Sentiment_customfield_10280" {
	run grepdumpdata "FIELD\[Sentiment\|customfield_10280\]:"
	check_status
}

@test "Service Delivery Planning ACK_customfield_10588" {
	run grepdumpdata "FIELD\[Service\ Delivery\ Planning\ ACK\|customfield_10588\]:"
	check_status
}

@test "Start date_customfield_10015" {
	run grepdumpdata "FIELD\[Start\ date\|customfield_10015\]:"
	check_status
}

@test "Status Category Changed_statuscategorychangedate" {
	run grepdumpdata "FIELD\[Status\ Category\ Changed\|statuscategorychangedate\]:"
	check_status
}

@test "Stories of Epic count_customfield_10424" {
	run grepdumpdata "FIELD\[Stories\ of\ Epic\ count\|customfield_10424\]:"
	check_status
}

@test "Stories of Epic in Done status category count_customfield_10418" {
	run grepdumpdata "FIELD\[Stories\ of\ Epic\ in\ Done\ status\ category\ count\|customfield_10418\]:"
	check_status
}

@test "Stories of Epic in In Progress status category count_customfield_10419" {
	run grepdumpdata "FIELD\[Stories\ of\ Epic\ in\ In\ Progress\ status\ category\ count\|customfield_10419\]:"
	check_status
}

@test "Stories of Epic in To Do status category count_customfield_10420" {
	run grepdumpdata "FIELD\[Stories\ of\ Epic\ in\ To\ Do\ status\ category\ count\|customfield_10420\]:"
	check_status
}

@test "Story point estimate_customfield_10016" {
	run grepdumpdata "FIELD\[Story\ point\ estimate\|customfield_10016\]:"
	check_status
}

@test "Subcomponent_customfield_10804" {
	run grepdumpdata "FIELD\[Subcomponent\|customfield_10804\]:"
	check_status
}

@test "Submitted forms_customfield_10030" {
	run grepdumpdata "FIELD\[Submitted\ forms\|customfield_10030\]:"
	check_status
}

@test "Subtask count_customfield_10429" {
	run grepdumpdata "FIELD\[Subtask\ count\|customfield_10429\]:"
	check_status
}

@test "Total forms_customfield_10032" {
	run grepdumpdata "FIELD\[Total\ forms\|customfield_10032\]:"
	check_status
}

@test "UXD Engagement Level_customfield_10831" {
	run grepdumpdata "FIELD\[UXD\ Engagement\ Level\|customfield_10831\]:"
	check_status
}

@test "Update Stream_customfield_10832" {
	run grepdumpdata "FIELD\[Update\ Stream\|customfield_10832\]:"
	check_status
}

@test "Updated by users count_customfield_10427" {
	run grepdumpdata "FIELD\[Updated\ by\ users\ count\|customfield_10427\]:"
	check_status
}

@test "Vulnerability_customfield_10255" {
	run grepdumpdata "FIELD\[Vulnerability\|customfield_10255\]:"
	check_status
}

@test "Work category_customfield_10315" {
	run grepdumpdata "FIELD\[Work\ category\|customfield_10315\]:"
	check_status
}

@test "[CHART] Date of First Response_customfield_10024" {
	run grepdumpdata "FIELD\[\[CHART\]\ Date\ of\ First\ Response\|customfield_10024\]:"
	check_status
}

@test "[CHART] Time in Status_customfield_10025" {
	run grepdumpdata "FIELD\[\[CHART\]\ Time\ in\ Status\|customfield_10025\]:"
	check_status
}

