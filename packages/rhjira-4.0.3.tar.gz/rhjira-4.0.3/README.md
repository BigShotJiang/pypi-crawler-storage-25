rhjira-python is a utility and library that provides functionality to interact with Red Hat's Jira (https://redhat.atlassian.net).  The functionality in this project currently supports creating, editing, commenting on, and the displaying of jiras.

Configuration

Token Configuration

rhjira-python requires a Jira Token (from your Atlassian account security settings).  The token can be exported as JIRA_TOKEN, however it is recommended users execute 'rhjira settoken' to store their token in their keyring.  This is more secure than keeping the token in clear text and using JIRA_TOKEN.

When running 'rhjira settoken', you will be prompted for the Jira server URL (default https://redhat.atlassian.net), then an optional email address. The email is required for Atlassian Cloud instances (see below). Both server and email are stored in the keyring alongside your token.

Tokens can be removed from the keyring by simply removing the 'rhjira' entry.  In the commonly used seahorse application, this can be done by removing the 'Password for '{username}' on 'rhjira'' entry. Similarly, the stored email can be removed by deleting the 'rhjira-email' entry, and the stored server by deleting the 'rhjira-server' entry.

Server Configuration

By default, rhjira connects to https://redhat.atlassian.net. To connect to a different Jira instance, set the JIRA_SERVER environment variable or run 'rhjira settoken' and enter the server URL when prompted (it is saved in the keyring):

```bash
export JIRA_SERVER="https://your-jira-instance.atlassian.net"
```

Atlassian Cloud instances require an email address for authentication. You can provide this in two ways:

1. When running 'rhjira settoken' (recommended - stores in keyring)
2. Via the JIRA_EMAIL environment variable:

```bash
export JIRA_EMAIL="your.email@example.com"
```

Environment Variable Priority

Environment variables take priority over keyring values, allowing for easy testing and per-session overrides:
- JIRA_TOKEN overrides the keyring token
- JIRA_EMAIL overrides the keyring email
- JIRA_SERVER overrides the keyring server and default server URL

Help

All commands are supported via --help.  For example, to get help on the comment command, execute "rhjira comment --help".

Problems found with rhjira-python can be reported at https://gitlab.com/prarit/rhjira-python/-/issues.  As with all my projects, merge requests are welcomed!

Bugs with rhjira should include the version of rhjira you are running and the exact executed command that failed.
