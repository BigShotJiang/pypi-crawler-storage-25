from __future__ import annotations

from dataclasses import dataclass
from typing import Any
from ..annexures import Exchange,Segment
from ...utils.validators import require_non_empty


@dataclass(frozen=True, slots=True)
class HistoricalCandleDataRequest:
    trading_symbol : str
    exchange : Exchange
    segment : Segment
    start_time : str
    end_time : str
    interval_in_minutes : str | None = None

    def __post_init__(self) -> None:
        require_non_empty(self.trading_symbol, 'trading_symbol')

    def to_payload(self) -> dict[str, Any]:
        payload = {
            'trading_symbol' : self.trading_symbol,
            'exchange' : self.exchange.value,
            'segment' : self.segment.value,
            'start_time' : self.start_time,
            'end_time' : self.end_time,
        }

        if self.interval_in_minutes is not None:
            payload['interval_in_minutes'] = self.interval_in_minutes

        return payload