import json
from dataclasses import dataclass
from datetime import datetime
from typing import List
from ...exceptions import ValidationError


@dataclass(frozen=True, slots=True)
class Candle:
    timestamp: int
    open: float
    high: float
    low: float
    close: float
    volume: int

    def __post_init__(self) -> None:
        if self.high < self.low:
            raise ValidationError(
                'High price cannot be less than low price',
                status_code=400,
                details={'reason': 'Invalid OHLC values'},
            )
        if self.volume < 0:
            raise ValidationError(
                'Volume cannot be negative',
                status_code=400,
                details={'reason': 'Invalid volume'},
            )
        if min(self.open, self.high, self.low, self.close) < 0:
            raise ValidationError(
                'Prices cannot be negative',
                status_code=400,
                details={'reason': 'Invalid price values'},
            )

    def to_dict(self) -> dict:
        return {
            'timestamp': self.timestamp,
            'open': self.open,
            'high': self.high,
            'low': self.low,
            'close': self.close,
            'volume': self.volume,
        }


@dataclass(frozen=True, slots=True)
class HistoricalCandleDataResponse:
    candles: List[Candle]
    start_time: str
    end_time: str
    interval_in_minutes: int

    def __post_init__(self) -> None:
        try:
            datetime.strptime(self.start_time, '%Y-%m-%d %H:%M:%S')
            datetime.strptime(self.end_time, '%Y-%m-%d %H:%M:%S')
        except ValueError:
            raise ValidationError(
                'Invalid datetime format',
                status_code=400,
                details={'reason': 'Datetime must be in yyyy-MM-dd HH:mm:ss'},
            )

        if self.interval_in_minutes <= 0:
            raise ValidationError(
                'Interval must be greater than 0',
                status_code=400,
                details={'reason': 'Invalid interval'},
            )
        
        
    @staticmethod
    def from_api_response(data: dict) -> 'HistoricalCandleDataResponse':
        candles = []
        for c in data['candles']:
            if not isinstance(c, list) or len(c) != 6:
                raise ValidationError(
                    'Each candle must be an array of 6 elements',
                    status_code=400,
                    details={'reason': 'Invalid candle format'},
                )
        

            candles.append(
                Candle(
                    timestamp=c[0],
                    open=c[1],
                    high=c[2],
                    low=c[3],
                    close=c[4],
                    volume=c[5],
                )
            )

        return HistoricalCandleDataResponse(
            candles=candles,
            start_time=data['start_time'],
            end_time=data['end_time'],
            interval_in_minutes=data['interval_in_minutes'],
        )

    def to_dict(self) -> dict:
        return {
            'candles': [candle.to_dict() for candle in self.candles],
            'start_time': self.start_time,
            'end_time': self.end_time,
            'interval_in_minutes': self.interval_in_minutes,
        }

    def to_json(self) -> str:
        return json.dumps(self.to_dict())