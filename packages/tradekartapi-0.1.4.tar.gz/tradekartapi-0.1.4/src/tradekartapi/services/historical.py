from typing import Any

from ..models.historical_data import HistoricalCandleDataRequest,HistoricalCandleDataResponse
from ..exceptions import ServiceError, ValidationError

class HistoricalCandleDataService:
    def __init__(self, sdk: Any) -> None:
        self._sdk = sdk.client

    def historical_candle_data(self, request: HistoricalCandleDataRequest) -> HistoricalCandleDataResponse:
        try:
            response = self._sdk.get_historical_candle_data(**request.to_payload())
            return HistoricalCandleDataResponse.from_api_response(response)
        except ValidationError:
            raise
        except Exception as exc:
            raise ServiceError(
                'Error in  fetching historical candle data',
                status_code=500,
                operation='HISTORICALCANDLEDATA',
                details={'reason': str(exc)},
            )