from typing import Any

from ..models.livedata import (
    GetQuoteRequest, 
    GetQuoteResponse, 
    GetLTPRequest, 
    GetLTPResponse, 
    GetOHLCRequest, 
    GetOHLCResponse, 
    GetOptionChainRequest, 
    GetOptionChainResponse,
    GetGreeksRequest,
    GetGreeksResponse,
)
from ..exceptions import ServiceError

class LiveDataService:
    def __init__(self, sdk: Any) -> None:
        self._sdk = sdk.client

    def get_quote(self, request: GetQuoteRequest) -> GetQuoteResponse:
        try:
            response = self._sdk.get_quote(**request.to_payload())
            return GetQuoteResponse(raw=response)
        except Exception as exc:
            raise ServiceError(
                'Error in getting quote',
                status_code=500,
                operation='GET_QUOTE',
                details={'reason': 'Error in get quote method of live data service'},
            ) from exc

    def get_ltp(self, request: GetLTPRequest) -> GetLTPResponse:
        try:
            response = self._sdk.get_ltp(**request.to_payload())
            return GetLTPResponse(raw=response)
        except Exception as exc:
            raise ServiceError(
                'Error in getting ltp',
                status_code=500,
                operation='GET_LTP',
                details={'reason': 'Error in get ltp method of live data service'},
            ) from exc

    def get_ohlc(self, request: GetOHLCRequest) -> GetOHLCResponse:
        try:
            response = self._sdk.get_ohlc(**request.to_payload())
            return GetOHLCResponse(raw=response)
        except Exception as exc:
            raise ServiceError(
                'Error in getting ohlc',
                status_code=500,
                operation='GET_OHLC',
                details={'reason': 'Error in get ohlc method of live data service'},
            ) from exc

    def get_option_chain(self, request: GetOptionChainRequest) -> GetOptionChainResponse:
        try:
            response = self._sdk.get_option_chain(**request.to_payload())
            return GetOptionChainResponse(raw=response)
        except Exception as exc:
            raise ServiceError(
                'Error in getting option chain',
                status_code=500,
                operation='GET_OPTION_CHAIN',
                details={'reason': 'Error in get option chain method of live data service'},
            ) from exc

    def get_greeks(self, request: GetGreeksRequest) -> GetGreeksResponse:
        try:
            response = self._sdk.get_greeks(**request.to_payload())
            return GetGreeksResponse(raw=response)
        except Exception as exc:
            raise ServiceError(
                'Error in getting greeks',
                status_code=500,
                operation='GET_GREEKS',
                details={'reason': 'Error in get greeks method of live data service'},
            ) from exc