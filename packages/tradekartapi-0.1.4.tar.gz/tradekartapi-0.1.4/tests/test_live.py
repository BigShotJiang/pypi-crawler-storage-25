import pytest

from tradekartapi.services.live_data import LiveDataService
from tradekartapi.exceptions import ServiceError
from tradekartapi.models.annexures import Exchange, Segment
from tradekartapi.models.livedata import (
    GetQuoteRequest,
    GetQuoteResponse,
    GetLTPRequest,
    GetLTPResponse,
    GetOHLCRequest,
    GetOHLCResponse,
    GetOptionChainRequest,
    GetOptionChainResponse,
    GetGreeksRequest,
    GetGreeksResponse,
)


# ---------------------------------------------------------------------------
# Fake SDK & Adapter
# ---------------------------------------------------------------------------

class FakeSDK:
    def __init__(self):
        self.called = {}

    def get_quote(self, exchange, segment, trading_symbol):
        self.called['get_quote'] = {
            'exchange': exchange,
            'segment': segment,
            'trading_symbol': trading_symbol,
        }
        return {
            'last_price': 23775.1,
            'day_change': -222.25,
            'day_change_perc': -0.9261439283920934,
            'ohlc': {'open': 23909.05, 'high': 23990.75, 'low': 23682.8, 'close': 23997.35},
            'week_52_high': 26373.2,
            'week_52_low': 22182.55,
        }

    def get_ltp(self, segment, exchange_trading_symbols):
        self.called['get_ltp'] = {
            'segment': segment,
            'exchange_trading_symbols': exchange_trading_symbols,
        }
        return {
            'NSE_NIFTY': {'last_price': 23775.1},
        }

    def get_ohlc(self, segment, exchange_trading_symbols):
        self.called['get_ohlc'] = {
            'segment': segment,
            'exchange_trading_symbols': exchange_trading_symbols,
        }
        return {
            'NSE_NIFTY': {
                'ohlc': {'open': 23909.05, 'high': 23990.75, 'low': 23682.8, 'close': 23997.35},
            },
        }

    def get_option_chain(self, exchange, underlying, expiry_date):
        self.called['get_option_chain'] = {
            'exchange': exchange,
            'underlying': underlying,
            'expiry_date': expiry_date,
        }
        return {
            'calls': [{'strike': 24000, 'last_price': 100.0}],
            'puts': [{'strike': 24000, 'last_price': 95.0}],
        }

    def get_greeks(self, exchange, underlying, trading_symbol, expiry):
        self.called['get_greeks'] = {
            'exchange': exchange,
            'underlying': underlying,
            'trading_symbol': trading_symbol,
            'expiry': expiry,
        }
        return {
            'delta': 0.5,
            'gamma': 0.02,
            'theta': -10.5,
            'vega': 12.0,
        }


class FakeAdapter:
    def __init__(self, sdk):
        self.client = sdk


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def sdk():
    return FakeSDK()


@pytest.fixture
def service(sdk):
    return LiveDataService(FakeAdapter(sdk))


# ---------------------------------------------------------------------------
# get_quote
# ---------------------------------------------------------------------------

def test_get_quote_returns_response(service, sdk):
    req = GetQuoteRequest(
        exchange=Exchange.NSE,
        segment=Segment.CASH,
        trading_symbol='NIFTY',
    )
    result = service.get_quote(req)

    assert isinstance(result, GetQuoteResponse)
    assert hasattr(result, 'raw')
    assert result.raw['last_price'] == 23775.1
    assert sdk.called['get_quote']['trading_symbol'] == 'NIFTY'
    assert sdk.called['get_quote']['exchange'] == Exchange.NSE
    assert sdk.called['get_quote']['segment'] == Segment.CASH


def test_get_quote_wraps_exception():
    class BrokenSDK(FakeSDK):
        def get_quote(self, **kwargs):
            raise RuntimeError('sdk down')

    service = LiveDataService(FakeAdapter(BrokenSDK()))
    req = GetQuoteRequest(
        exchange=Exchange.NSE,
        segment=Segment.CASH,
        trading_symbol='NIFTY',
    )
    with pytest.raises(ServiceError) as exc:
        service.get_quote(req)

    assert 'Error in getting quote' in str(exc.value)
    assert 'GET_QUOTE' in str(exc.value)


# ---------------------------------------------------------------------------
# get_ltp
# ---------------------------------------------------------------------------

def test_get_ltp_returns_response(service, sdk):
    req = GetLTPRequest(
        segment=Segment.CASH,
        exchange_trading_symbols=('NSE_NIFTY',),
    )
    result = service.get_ltp(req)

    assert isinstance(result, GetLTPResponse)
    assert hasattr(result, 'raw')
    assert 'NSE_NIFTY' in result.raw
    assert sdk.called['get_ltp']['exchange_trading_symbols'] == ('NSE_NIFTY',)


def test_get_ltp_wraps_exception():
    class BrokenSDK(FakeSDK):
        def get_ltp(self, **kwargs):
            raise RuntimeError('sdk down')

    service = LiveDataService(FakeAdapter(BrokenSDK()))
    req = GetLTPRequest(
        segment=Segment.CASH,
        exchange_trading_symbols=('NSE_NIFTY',),
    )
    with pytest.raises(ServiceError) as exc:
        service.get_ltp(req)

    assert 'Error in getting ltp' in str(exc.value)
    assert 'GET_LTP' in str(exc.value)


# ---------------------------------------------------------------------------
# get_ohlc
# ---------------------------------------------------------------------------

def test_get_ohlc_returns_response(service, sdk):
    req = GetOHLCRequest(
        segment=Segment.CASH,
        exchange_trading_symbols=('NSE_NIFTY',),
    )
    result = service.get_ohlc(req)

    assert isinstance(result, GetOHLCResponse)
    assert hasattr(result, 'raw')
    assert 'NSE_NIFTY' in result.raw
    assert result.raw['NSE_NIFTY']['ohlc']['open'] == 23909.05
    assert sdk.called['get_ohlc']['segment'] == Segment.CASH


def test_get_ohlc_wraps_exception():
    class BrokenSDK(FakeSDK):
        def get_ohlc(self, **kwargs):
            raise RuntimeError('sdk down')

    service = LiveDataService(FakeAdapter(BrokenSDK()))
    req = GetOHLCRequest(
        segment=Segment.CASH,
        exchange_trading_symbols=('NSE_NIFTY',),
    )
    with pytest.raises(ServiceError) as exc:
        service.get_ohlc(req)

    assert 'Error in getting ohlc' in str(exc.value)
    assert 'GET_OHLC' in str(exc.value)


# ---------------------------------------------------------------------------
# get_option_chain
# ---------------------------------------------------------------------------

def test_get_option_chain_returns_response(service, sdk):
    req = GetOptionChainRequest(
        exchange=Exchange.NSE,
        underlying='NIFTY',
        expiry_date='2025-04-24',
    )
    result = service.get_option_chain(req)

    assert isinstance(result, GetOptionChainResponse)
    assert hasattr(result, 'raw')
    assert 'calls' in result.raw
    assert 'puts' in result.raw
    assert sdk.called['get_option_chain']['underlying'] == 'NIFTY'
    assert sdk.called['get_option_chain']['expiry_date'] == '2025-04-24'


def test_get_option_chain_wraps_exception():
    class BrokenSDK(FakeSDK):
        def get_option_chain(self, **kwargs):
            raise RuntimeError('sdk down')

    service = LiveDataService(FakeAdapter(BrokenSDK()))
    req = GetOptionChainRequest(
        exchange=Exchange.NSE,
        underlying='NIFTY',
        expiry_date='2025-04-24',
    )
    with pytest.raises(ServiceError) as exc:
        service.get_option_chain(req)

    assert 'Error in getting option chain' in str(exc.value)
    assert 'GET_OPTION_CHAIN' in str(exc.value)


# ---------------------------------------------------------------------------
# get_greeks
# ---------------------------------------------------------------------------

def test_get_greeks_returns_response(service, sdk):
    req = GetGreeksRequest(
        exchange=Exchange.NSE,
        underlying='NIFTY',
        trading_symbol='NIFTY24APR24000CE',
        expiry='2025-04-24',
    )
    result = service.get_greeks(req)

    assert isinstance(result, GetGreeksResponse)
    assert hasattr(result, 'raw')
    assert result.raw['delta'] == 0.5
    assert result.raw['gamma'] == 0.02
    assert sdk.called['get_greeks']['trading_symbol'] == 'NIFTY24APR24000CE'
    assert sdk.called['get_greeks']['expiry'] == '2025-04-24'


def test_get_greeks_wraps_exception():
    class BrokenSDK(FakeSDK):
        def get_greeks(self, **kwargs):
            raise RuntimeError('sdk down')

    service = LiveDataService(FakeAdapter(BrokenSDK()))
    req = GetGreeksRequest(
        exchange=Exchange.NSE,
        underlying='NIFTY',
        trading_symbol='NIFTY24APR24000CE',
        expiry='2025-04-24',
    )
    with pytest.raises(ServiceError) as exc:
        service.get_greeks(req)

    assert 'Error in getting greeks' in str(exc.value)
    assert 'GET_GREEKS' in str(exc.value)
