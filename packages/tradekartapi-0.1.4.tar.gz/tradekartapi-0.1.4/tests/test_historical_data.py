import pytest

from tradekartapi.services import HistoricalCandleDataService
from tradekartapi.exceptions import ServiceError, ValidationError


# ---- Fake Request ----
class FakeHistoricalRequest:
    def to_payload(self):
        return {
            'trading_symbol': 'INFY',
            'interval_in_minutes': 5,
        }


# ---- Fake SDK ----
class FakeSDK:
    def get_historical_candle_data(self, **kwargs):
        return {
            'candles': [
                [1633072800, 150, 155, 145, 152, 10000],
                [1633073100, 152, 156, 151, 155, 12000],
            ],
            'start_time': '2025-01-01 15:30:00',
            'end_time': '2025-01-01 15:35:00',
            'interval_in_minutes': 5,
        }


class FakeAdapter:
    def __init__(self, sdk):
        self.client = sdk


# ---- Fixtures ----
@pytest.fixture
def sdk():
    return FakeSDK()


@pytest.fixture
def service(sdk):
    return HistoricalCandleDataService(FakeAdapter(sdk))


# ---- Tests ----

def test_historical_candle_data_success(service):
    req = FakeHistoricalRequest()
    result = service.historical_candle_data(req)

    assert len(result.candles) == 2
    assert result.candles[0].close == 152
    assert result.candles[1].high == 156
    assert result.interval_in_minutes == 5


def test_historical_candle_data_invalid_candle(service):
    class BadSDK(FakeSDK):
        def get_historical_candle_data(self, **kwargs):
            return {
                'candles': [
                    [1633072800, 150, 155],  # ❌ invalid
                ],
                'start_time': '2025-01-01 15:30:00',
                'end_time': '2025-01-01 15:35:00',
                'interval_in_minutes': 5,
            }

    service = HistoricalCandleDataService(FakeAdapter(BadSDK()))

    with pytest.raises(ValidationError):
        service.historical_candle_data(FakeHistoricalRequest())


def test_historical_candle_data_service_exception():
    class BrokenSDK(FakeSDK):
        def get_historical_candle_data(self, **kwargs):
            raise RuntimeError('SDK failure')

    service = HistoricalCandleDataService(FakeAdapter(BrokenSDK()))

    with pytest.raises(ServiceError) as exc:
        service.historical_candle_data(FakeHistoricalRequest())

    assert exc.value.operation == 'HISTORICALCANDLEDATA'
    assert 'SDK failure' in str(exc.value.details['reason'])