"""
QuickVibeAI Local AI Panel & Relayer
Runs a FastAPI local gateway on port 7891. Provides a beautiful UI strictly for managing API configurations,
and dynamically proxies local agent traffic out to OpenRouter, Groq, or Native Gemini depending on frontend selections!

Cross-platform: Works on Windows, Linux, macOS, and Termux (Android).
"""

import json
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, StreamingResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
import httpx
from pydantic import BaseModel

from quickvibeai.config import load_config, save_config, AVAILABLE_MODELS

app = FastAPI(title="QuickVibeAI Gateway Panel")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:7891", "http://127.0.0.1:7891"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class UpdateKeyModel(BaseModel):
    provider: str
    api_key: str

class SelectAgentModel(BaseModel):
    provider: str
    model: str


def ensure_config_schema():
    c = load_config()
    changed = False

    if "agent_keys" not in c:
        c["agent_keys"] = {"openrouter": "", "groq": "", "gemini": ""}
        changed = True
    if "active_provider" not in c:
        c["active_provider"] = "openrouter"
        changed = True

    # Migrate old key into agent_keys if missing
    if c.get("api_key") and not c["agent_keys"].get("openrouter"):
        c["agent_keys"]["openrouter"] = c["api_key"]
        changed = True

    if changed:
        save_config(c)
    return c


def _build_free_model_options():
    """Dynamically build <option> tags for free models from the config."""
    options = []
    for model_id, info in AVAILABLE_MODELS.items():
        if info.get("tier") == "free":
            options.append(f'<option value="{model_id}">{info["name"]} — {info["provider"]} (ctx:{info["context"]:,})</option>')
    return "\n".join(options)


def _build_paid_model_options():
    """Dynamically build <option> tags for paid models from the config."""
    options = []
    for model_id, info in AVAILABLE_MODELS.items():
        if info.get("tier") == "paid":
            options.append(f'<option value="{model_id}">{info["name"]} — {info["provider"]} ({info["cost"]})</option>')
    return "\n".join(options)


@app.get("/")
def ai_panel():
    """Beautiful local UI control panel."""
    c = ensure_config_schema()

    free_opts = _build_free_model_options()
    paid_opts = _build_paid_model_options()

    html = f"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>QuickVibeAI - Local AI Panel</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
        <style>
            body {{ background-color: #0d1117; color: #c9d1d9; }}
            .glass {{ background: rgba(30, 41, 59, 0.7); backdrop-filter: blur(16px); border: 1px solid rgba(255, 255, 255, 0.1); }}
        </style>
    </head>
    <body class="min-h-screen p-8 flex justify-center" x-data="panelApp()">
        <div class="w-full max-w-4xl space-y-8">
            <h1 class="text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-500">
                ⚡ QuickVibeAI Control Panel
            </h1>
            <p class="text-sm text-gray-400">v0.0.1 — Updated free model list (April 2026)</p>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <!-- API Keys Card -->
                <div class="glass p-6 rounded-2xl shadow-xl space-y-4">
                    <h2 class="text-xl font-bold flex items-center space-x-2"><span class="text-indigo-400">🔑</span> <span>Provider API Keys</span></h2>
                    <p class="text-sm text-gray-400 mb-4">Set your secret keys securely. Stored strictly offline in ~/.quickvibeai/config.json</p>

                    <template x-for="provider in ['openrouter', 'groq', 'gemini']">
                        <div class="flex flex-col space-y-1 mt-4">
                            <label class="text-sm font-semibold text-gray-300 capitalize" x-text="provider"></label>
                            <div class="flex space-x-2">
                                <input type="password" x-model="keys[provider]" class="flex-1 bg-gray-900 border border-gray-700 rounded-lg p-2 focus:ring-2 focus:ring-purple-500 outline-none text-white transition-all shadow-inner" placeholder="sk-...">
                                <button @click="saveKey(provider)" class="bg-indigo-600 hover:bg-indigo-500 px-4 rounded-lg font-medium transition-colors shadow-lg shadow-indigo-500/30">Save</button>
                            </div>
                        </div>
                    </template>
                </div>

                <!-- Active Agent Selection -->
                <div class="glass p-6 rounded-2xl shadow-xl flex flex-col space-y-4">
                    <h2 class="text-xl font-bold flex items-center space-x-2"><span class="text-emerald-400">🤖</span> <span>Active AI Agent</span></h2>
                    <p class="text-sm text-gray-400 mb-4">Select which intelligence powers your CLI.</p>

                    <div class="flex-1 space-y-4 flex flex-col justify-center">
                        <div>
                            <label class="block text-sm font-semibold text-gray-300 mb-1">Provider Engine</label>
                            <select x-model="active_provider" @change="updateModels()" class="w-full bg-gray-900 border border-gray-700 rounded-lg p-2 focus:ring-2 focus:ring-emerald-500 outline-none capitalize">
                                <option value="openrouter">OpenRouter (Massive Selection)</option>
                                <option value="groq">Groq (Ultra-Fast LPUs)</option>
                                <option value="gemini">Google Gemini (Native API)</option>
                            </select>
                        </div>

                        <div>
                            <label class="block text-sm font-semibold text-gray-300 mb-1">Target Model ID</label>

                            <!-- OpenRouter Models -->
                            <select x-show="active_provider === 'openrouter'" x-model="active_model" class="w-full bg-gray-900 border border-gray-700 rounded-lg p-2 focus:ring-2 focus:ring-emerald-500 outline-none text-white text-sm">
                                <optgroup label="⚡ Free Tier (April 2026)">
                                    {free_opts}
                                </optgroup>
                                <optgroup label="🚀 Paid High-Performance">
                                    {paid_opts}
                                </optgroup>
                            </select>

                            <!-- Groq Models -->
                            <select x-show="active_provider === 'groq'" x-model="active_model" class="w-full bg-gray-900 border border-gray-700 rounded-lg p-2 focus:ring-2 focus:ring-emerald-500 outline-none text-white text-sm">
                                <optgroup label="🚀 High Speed Meta LPUs">
                                    <option value="llama-3.3-70b-versatile">Llama 3.3 70B (Most Stable)</option>
                                    <option value="llama-3.1-8b-instant">Llama 3.1 8B (Instant Speed)</option>
                                </optgroup>
                                <optgroup label="🧪 Experimental 2026 Models">
                                    <option value="openai/gpt-oss-120b">GPT OSS 120B (Reasoning)</option>
                                    <option value="openai/gpt-oss-20b">GPT OSS 20B (Standard)</option>
                                </optgroup>
                            </select>

                            <!-- Gemini Native Models -->
                            <select x-show="active_provider === 'gemini'" x-model="active_model" class="w-full bg-gray-900 border border-gray-700 rounded-lg p-2 focus:ring-2 focus:ring-emerald-500 outline-none text-white text-sm">
                                <optgroup label="🚀 High-Performance Native">
                                    <option value="gemini-2.5-flash">Gemini 2.5 Flash</option>
                                    <option value="gemini-2.5-pro">Gemini 2.5 Pro</option>
                                    <option value="gemini-2.0-flash-lite">Gemini 2.0 Flash Lite</option>
                                    <option value="gemini-1.5-pro-latest">Gemini 1.5 Pro</option>
                                </optgroup>
                            </select>

                            <p class="text-xs text-gray-500 mt-2">Select the desired intelligence node.</p>
                        </div>
                    </div>

                    <button @click="saveAgent()" class="w-full bg-emerald-600 hover:bg-emerald-500 py-3 mt-[auto] rounded-lg font-bold text-lg transition-colors shadow-lg shadow-emerald-500/30">
                        Map Active Agent
                    </button>
                    <p x-show="msg" x-text="msg" x-transition class="text-center text-sm font-bold text-green-400"></p>
                </div>
            </div>
        </div>

        <script>
            function panelApp() {{
                return {{
                    keys: {json.dumps(c.get('agent_keys', {}))},
                    active_provider: "{c.get('active_provider', 'openrouter')}",
                    active_model: "{c.get('default_model', 'openrouter/free')}",
                    msg: "",

                    updateModels() {{
                        // Set strong defaults on tab switch
                        if(this.active_provider === 'groq') this.active_model = 'llama-3.3-70b-versatile';
                        else if(this.active_provider === 'gemini') this.active_model = 'gemini-2.5-flash';
                        else this.active_model = 'openrouter/free';
                    }},

                    async saveKey(provider) {{
                        let res = await fetch('/api/keys', {{
                            method: 'POST',
                            headers: {{'Content-Type': 'application/json'}},
                            body: JSON.stringify({{provider: provider, api_key: this.keys[provider]}})
                        }});
                        this.showMsg("Key Saved!");
                    }},

                    async saveAgent() {{
                        let res = await fetch('/api/select_agent', {{
                            method: 'POST',
                            headers: {{'Content-Type': 'application/json'}},
                            body: JSON.stringify({{provider: this.active_provider, model: this.active_model}})
                        }});
                        this.showMsg("Agent Mapped Successfully to CLI Engine!");
                    }},

                    showMsg(text) {{
                        this.msg = text;
                        setTimeout(() => this.msg = '', 3000);
                    }}
                }}
            }}
        </script>
    </body>
    </html>
    """
    return HTMLResponse(content=html)


@app.post("/api/keys")
def update_key(data: UpdateKeyModel):
    c = ensure_config_schema()
    c["agent_keys"][data.provider] = data.api_key
    save_config(c)
    return {"status": "ok"}

@app.post("/api/select_agent")
def select_agent(data: SelectAgentModel):
    c = ensure_config_schema()
    c["active_provider"] = data.provider
    c["default_model"] = data.model
    save_config(c)
    return {"status": "ok"}


from sse_starlette.sse import EventSourceResponse
import asyncio
import random
import logging

logger = logging.getLogger("quickvibeai.gateway")

# Fallback free models — ordered by quality/reliability (best first)
FREE_FALLBACK_MODELS = [
    "openrouter/free",
    "openai/gpt-oss-120b:free",
    "qwen/qwen3-coder:free",
    "google/gemma-4-31b-it:free",
    "nvidia/nemotron-3-super-120b-a12b:free",
    "meta-llama/llama-3.3-70b-instruct:free",
    "qwen/qwen3-next-80b-a3b-instruct:free",
    "minimax/minimax-m2.5:free",
    "google/gemma-4-26b-a4b-it:free",
    "nousresearch/hermes-3-llama-3.1-405b:free",
    "openai/gpt-oss-20b:free",
    "z-ai/glm-4.5-air:free",
    "nvidia/nemotron-3-nano-30b-a3b:free",
    "arcee-ai/trinity-large-preview:free",
    "google/gemma-3-27b-it:free",
]

MAX_RETRIES = 3


def _get_provider_config(provider: str, config: dict):
    """Returns (base_url, api_key) for the given provider."""
    if provider == "groq":
        return "https://api.groq.com/openai/v1/chat/completions", config["agent_keys"].get("groq", "")
    elif provider == "gemini":
        return "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions", config["agent_keys"].get("gemini", "")
    else:
        return "https://openrouter.ai/api/v1/chat/completions", config["agent_keys"].get("openrouter", "")


def _pick_fallback_model(failed_model: str, already_tried: set) -> str:
    """Pick the next best fallback free model, skipping ones we already tried."""
    for model in FREE_FALLBACK_MODELS:
        if model not in already_tried and model != failed_model:
            return model
    # If all from priority list tried, pick a random one from AVAILABLE_MODELS
    all_free = [mid for mid, info in AVAILABLE_MODELS.items() if info.get("tier") == "free" and mid not in already_tried]
    return random.choice(all_free) if all_free else "openrouter/free"


@app.post("/v1/chat/completions")
async def chat_proxy(request: Request):
    """
    Acts as an OpenAI proxy relay. Takes the QuickVibeAI CLI request and dynamically routes it
    to OpenRouter, Groq, or Gemini dynamically based on local UI configuration.
    
    SMART RETRY: If a free model returns 429 (rate limited), automatically retries
    with a different free model up to MAX_RETRIES times.
    """
    c = ensure_config_schema()
    payload = await request.json()

    provider = c.get("active_provider", "openrouter")
    base_url, api_key = _get_provider_config(provider, c)

    if not api_key:
        return JSONResponse({"error": {"message": f"API Key for {provider} not set! Open http://127.0.0.1:7891 to configure."}}, status_code=401)

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
        "HTTP-Referer": "https://quickvibeai.dev",
        "X-Title": "QuickVibeAI Local Node"
    }

    # We dynamically override the model from payload with the configured one
    current_model = c.get("default_model", payload.get("model"))
    payload["model"] = current_model

    is_stream = payload.get("stream", False)
    is_free_model = ":free" in current_model or current_model == "openrouter/free"

    tried_models = {current_model}
    last_error = None

    for attempt in range(MAX_RETRIES + 1):
        if is_stream:
            client = httpx.AsyncClient(timeout=120.0)
            try:
                req = client.build_request("POST", base_url, json=payload, headers=headers)
                response = await client.send(req, stream=True)
            except Exception as e:
                await client.aclose()
                last_error = str(e)
                # Only retry connection errors for free models
                if is_free_model and attempt < MAX_RETRIES:
                    fallback = _pick_fallback_model(payload["model"], tried_models)
                    tried_models.add(fallback)
                    payload["model"] = fallback
                    logger.info(f"Connection error on {current_model}, falling back to {fallback}")
                    await asyncio.sleep(0.5)
                    continue
                return JSONResponse({"error": {"message": last_error}}, status_code=500)

            if response.status_code == 429 and is_free_model and attempt < MAX_RETRIES:
                # Rate limited — auto-fallback to another free model
                err_txt = await response.aread()
                await response.aclose()
                await client.aclose()
                
                fallback = _pick_fallback_model(payload["model"], tried_models)
                tried_models.add(fallback)
                logger.info(f"429 rate limit on {payload['model']}, auto-switching to {fallback} (attempt {attempt+2}/{MAX_RETRIES+1})")
                payload["model"] = fallback
                await asyncio.sleep(0.3)
                continue

            if response.status_code != 200:
                err_txt = await response.aread()
                await response.aclose()
                await client.aclose()
                try:
                    err_dict = json.loads(err_txt)
                except:
                    err_dict = {"error": {"message": err_txt.decode()}}
                
                # For 429 on non-free or exhausted retries, add helpful message
                if response.status_code == 429:
                    tried_list = ", ".join(tried_models)
                    err_dict["error"]["message"] = (
                        f"All tried models are rate-limited ({tried_list}). "
                        f"Try again in a minute, or switch to 'openrouter/free' which auto-routes to available models. "
                        f"Go to http://127.0.0.1:7891 to change your model."
                    )
                return JSONResponse(err_dict, status_code=response.status_code)

            # Success — if we fell back, log which model actually worked
            actual_model = payload["model"]
            if actual_model != current_model:
                logger.info(f"Successfully fell back from {current_model} to {actual_model}")

            async def event_generator():
                try:
                    async for line in response.aiter_lines():
                        if line.startswith("data: "):
                            yield {"data": line[6:]}
                finally:
                    await response.aclose()
                    await client.aclose()

            return EventSourceResponse(event_generator())
        else:
            # Non-streaming path
            async with httpx.AsyncClient(timeout=120.0) as client:
                try:
                    resp = await client.post(base_url, json=payload, headers=headers)
                    
                    if resp.status_code == 429 and is_free_model and attempt < MAX_RETRIES:
                        fallback = _pick_fallback_model(payload["model"], tried_models)
                        tried_models.add(fallback)
                        payload["model"] = fallback
                        await asyncio.sleep(0.3)
                        continue
                    
                    return JSONResponse(resp.json(), status_code=resp.status_code)
                except Exception as e:
                    if is_free_model and attempt < MAX_RETRIES:
                        fallback = _pick_fallback_model(payload["model"], tried_models)
                        tried_models.add(fallback)
                        payload["model"] = fallback
                        await asyncio.sleep(0.5)
                        continue
                    return JSONResponse({"error": {"message": str(e)}}, status_code=500)

    # Should never reach here, but safety net
    return JSONResponse({"error": {"message": f"All {MAX_RETRIES+1} attempts failed. Last error: {last_error}"}}, status_code=500)
