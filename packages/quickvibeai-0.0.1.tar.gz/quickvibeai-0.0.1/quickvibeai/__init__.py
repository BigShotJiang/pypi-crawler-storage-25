"""
QuickVibeAI - The Ultimate AI Coding Assistant.
A powerful CLI-based coding assistant powered by OpenRouter, Groq, and Gemini.
"""

__version__ = "0.0.1"
__author__ = "QuickVibeAI"
__description__ = "The ultimate AI coding assistant — multi-provider, cross-platform, terminal-native."
