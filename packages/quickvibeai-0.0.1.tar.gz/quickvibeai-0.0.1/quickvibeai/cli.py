"""
QuickVibeAI CLI application.
The main entry point for the powerful AI coding assistant.

Cross-platform: Works on Windows, Linux, macOS, and Termux (Android).
"""

import sys
import os
import json
import asyncio
import platform
from pathlib import Path

# ── Cross-platform UTF-8 safety ──────────────────────────────────────
# Windows terminals (cmd/PowerShell) default to cp1252; Termux defaults to UTF-8.
# This ensures emoji/unicode output never crashes the CLI.
try:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
        sys.stderr.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass  # Some environments (e.g. piped output) don't support reconfigure

import click
from prompt_toolkit import PromptSession
from prompt_toolkit.styles import Style as PTStyle
from prompt_toolkit.formatted_text import HTML
from prompt_toolkit.key_binding import KeyBindings
from prompt_toolkit.lexers import PygmentsLexer
from pygments.lexers.python import PythonLexer

from rich.console import Console
from rich.panel import Panel
from rich.markdown import Markdown
from rich.syntax import Syntax
from rich.live import Live
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table

from quickvibeai.config import (
    load_config, save_config, get_api_key, set_api_key, set_model,
    AVAILABLE_MODELS, ensure_config_dir
)
from quickvibeai.streaming import OpenRouterStream, StreamingError
from quickvibeai.file_manager import FileManager, parse_file_blocks
from quickvibeai.templates import get_system_prompt, get_context_for_prompt
from quickvibeai import __version__

console = Console()
fm = FileManager()


def _is_termux() -> bool:
    """Detect if running inside Termux on Android."""
    return "com.termux" in os.environ.get("PREFIX", "")


def _get_shell_cmd():
    """Return the correct shell wrapper for the current platform."""
    if os.name == "nt":
        return "powershell"
    return "bash"


class QuickVibeSession:
    def __init__(self):
        self.config = load_config()
        self.messages = [
            {"role": "system", "content": get_system_prompt() + "\n\n" + get_context_for_prompt()}
        ]

        try:
            self.streamer = OpenRouterStream()
        except StreamingError as e:
            self.streamer = None

    def trim_messages(self, max_messages=20):
        """Keep the system prompt and the last N messages to manage context window."""
        if len(self.messages) > max_messages:
            system_msg = self.messages[0]
            # Keep last N conversation turns (user/assistant pairs)
            self.messages = [system_msg] + self.messages[-(max_messages-1):]

    def init_streamer(self):
        """Try to initialize the streamer. If it fails, we keep going but warn the user."""
        if not self.streamer:
            try:
                self.streamer = OpenRouterStream()
            except StreamingError:
                # Keep it None, the chat logic will handle the warning
                pass


def interactive_setup():
    """Interactive setup for API key and model selection."""
    console.print(Panel.fit(f"[bold blue]⚡ Welcome to QuickVibeAI v{__version__} Setup[/bold blue]"))

    current_key = get_api_key()
    if current_key:
        console.print(f"Current API Key: [green]{current_key[:8]}...{current_key[-4:]}[/green]")
        update = click.confirm("Do you want to update it?")
        if not update:
            api_key = current_key
        else:
             api_key = click.prompt("Enter your OpenRouter API Key", hide_input=True)
    else:
        console.print("You need an OpenRouter API key to use QuickVibeAI.")
        console.print("Get one at: [link=https://openrouter.ai/keys]https://openrouter.ai/keys[/link]")
        api_key = click.prompt("Enter your OpenRouter API Key", hide_input=True)

    set_api_key(api_key)

    # Model Selection — split into Free and Paid tiers
    table = Table(title="Available Models")
    table.add_column("#", justify="right", style="dim")
    table.add_column("Model", style="magenta")
    table.add_column("Provider", style="cyan")
    table.add_column("Context", justify="right", style="green")
    table.add_column("Speed/Cost", justify="right", style="yellow")

    model_ids = list(AVAILABLE_MODELS.keys())
    free_models = [(i, mid) for i, mid in enumerate(model_ids) if AVAILABLE_MODELS[mid].get("tier") == "free"]
    paid_models = [(i, mid) for i, mid in enumerate(model_ids) if AVAILABLE_MODELS[mid].get("tier") == "paid"]

    table.add_row("", "[bold green]── FREE TIER ──[/bold green]", "", "", "")
    for i, mid in free_models:
        info = AVAILABLE_MODELS[mid]
        table.add_row(str(i+1), info["name"], info["provider"], f"{info['context']:,}", f"{info['speed']} | {info['cost']}")

    table.add_row("", "[bold yellow]── PAID TIER ──[/bold yellow]", "", "", "")
    for i, mid in paid_models:
        info = AVAILABLE_MODELS[mid]
        table.add_row(str(i+1), info["name"], info["provider"], f"{info['context']:,}", f"{info['speed']} | {info['cost']}")

    console.print(table)

    choice = click.prompt(
        "Select a model number",
        type=click.IntRange(1, len(model_ids)),
        default=1
    )

    selected_model = model_ids[choice - 1]
    set_model(selected_model)

    console.print(f"\n[bold green]✅ Setup complete![/bold green] You are using [bold cyan]{AVAILABLE_MODELS[selected_model]['name']}[/bold cyan].")

def process_file_actions(response_text: str) -> str:
    """Parses response for files and writes them automatically, and runs commands."""
    files = parse_file_blocks(response_text)
    if files:
        console.print("\n" + "="*50)
        console.print(f"📦 [bold cyan]QuickVibeAI auto-generating {len(files)} file(s)[/bold cyan]")

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            transient=True,
        ) as progress:
            task = progress.add_task("Writing files...", total=len(files))

            for f in files:
                filepath = f['path']
                content = f['content']
                success = fm.write_file(filepath, content)
                if success:
                    console.print(f"[green]✓[/green] Created: {filepath}")
                else:
                    console.print(f"[red]✗[/red] Failed: {filepath}")
                progress.advance(task)

        console.print("[bold green]✨ All files written successfully![/bold green]")

    # Also automatically execute any terminal commands generated
    import re
    import subprocess
    cmd_outputs = ""
    bash_blocks = re.findall(r'```(?:bash|sh|powershell|cmd)\n(.*?)\n```', response_text, re.DOTALL)

    for cmd in bash_blocks:
        cmd = cmd.strip()
        if not cmd or "--- READ:" in cmd or "--- FILE:" in cmd:
            continue

        console.print(f"\n[bold yellow]⚡ AI wants to execute:[/bold yellow] {cmd}")
        if not click.confirm("Do you want to run this command?"):
            console.print("[red]Command skipped by user.[/red]")
            cmd_outputs += f"\n$ {cmd}\nSTATUS: Skipped by user.\n"
            continue

        try:
            # Cross-platform command execution
            if os.name == "nt":
                # Windows: wrap in PowerShell
                full_cmd = f'powershell -ExecutionPolicy Bypass -Command "{cmd.replace(chr(34), chr(39))}"'
            elif _is_termux():
                # Termux: use bash directly, no sudo
                full_cmd = f'bash -c "{cmd}"'
            else:
                # Linux/macOS: use bash
                full_cmd = cmd

            proc = subprocess.Popen(
                full_cmd, shell=True, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, cwd=fm.get_project_root()
            )
            try:
                is_server = any(srv in cmd.lower() for srv in ["php -s", "npm run", "npm start", "python -m http.server", "uvicorn"])
                wait_time = 1 if is_server else 2

                out, err = proc.communicate(timeout=wait_time)
                out = out.strip() if out else ""
                err = err.strip() if err else ""

                if out:
                    console.print(f"[dim]{out}[/dim]")
                    cmd_outputs += f"\n$ {cmd}\nSTDOUT:\n{out}\n"
                if err:
                    console.print(f"[red]{err}[/red]")
                    cmd_outputs += f"\n$ {cmd}\nSTDERR:\n{err}\n"
            except subprocess.TimeoutExpired:
                console.print(f"[bold green]Command `{cmd}` is now running in the background.[/bold green]")
                cmd_outputs += f"\n$ {cmd}\nSTATUS: Started successfully and is running in the background.\n"


        except Exception as e:
            console.print(f"[red]Failed to run command:[/red] {e}")
            cmd_outputs += f"\n$ {cmd}\nERROR:\n{e}\n"

    # Process DELETE blocks
    import re as re2
    delete_blocks = re2.findall(r'---\s*DELETE:\s*(.+?)\s*---', response_text)
    for filepath in delete_blocks:
        filepath = filepath.strip()
        console.print(f"🗑️ [bold red]QuickVibeAI natively deleting File:[/bold red] {filepath}")
        if fm.delete_file(filepath):
            cmd_outputs += f"\nFile `{filepath}` successfully deleted.\n"
        else:
            cmd_outputs += f"\nCould not delete file `{filepath}` (might be locked or missing).\n"

    # Process READ blocks
    read_blocks = re2.findall(r'---\s*READ:\s*(.+?)\s*---', response_text)
    for filepath in read_blocks:
        filepath = filepath.strip()
        console.print(f"📄 [bold blue]QuickVibeAI natively reading File:[/bold blue] {filepath}")
        content = fm.read_file(filepath)
        if content is not None:
            cmd_outputs += f"\nFile Read Result for `{filepath}`:\n```\n{content}\n```\n"
        else:
            cmd_outputs += f"\nCould not read file `{filepath}` (File not found).\n"
            console.print(f"[red]File Not Found:[/red] {filepath}")


    return cmd_outputs


async def main_loop():
    session = QuickVibeSession()
    session.init_streamer()

    console.print(Panel.fit(
        f"[bold blue]⚡ QuickVibeAI v{__version__} CLI Gateway[/bold blue]\n"
        f"Type [bold]exit[/bold] to quit, [bold]/clear[/bold] to clear history, [bold]/tree[/bold] for project tree.",
        border_style="blue"
    ))

    # Setting up beautiful prompt
    style = PTStyle.from_dict({
        'prompt': 'bg:#6366f1 #ffffff bold',
        'bottom-toolbar': '#ffffff bg:#333333',
    })

    bindings = KeyBindings()
    @bindings.add('c-c')
    def _(event):
        event.app.exit()

    prompt_session = PromptSession(
        style=style,
        key_bindings=bindings,
    )

    while True:
        try:
            # Dynamically read the config once per chat turn to instantly reflect Web UI changes
            config = load_config()
            current_model = config.get("default_model", "Unknown").split("/")[-1].replace(":free", "")
            current_provider = config.get("active_provider", "Unknown").capitalize()

            prompt_session.bottom_toolbar = HTML(
                f' Project: <ansiblue>{fm.get_project_root().name}</ansiblue> | '
                f' Provider: <ansigreen>{current_provider}</ansigreen> | '
                f' Model: <ansicyan>{current_model}</ansicyan> '
            )

            # Need to run prompt toolkit in executor to not block asyncio
            user_input = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: prompt_session.prompt(" ⚡ QuickVibeAI > ")
            )

            user_input = user_input.strip()

            if not user_input:
                continue

            if user_input.lower() in ['exit', 'quit']:
                break

            if user_input.lower() == '/clear':
                session.messages = [{"role": "system", "content": get_system_prompt() + "\n\n" + get_context_for_prompt()}]
                console.print("[green]Chat history cleared.[/green]")
                continue

            if user_input.lower() == '/tree':
                console.print(fm.get_project_tree())
                continue

            if user_input.lower() == '/models':
                table = Table(title="Available Free Models")
                table.add_column("Model ID", style="cyan")
                table.add_column("Name", style="magenta")
                table.add_column("Context", justify="right", style="green")
                for mid, info in AVAILABLE_MODELS.items():
                    if info.get("tier") == "free":
                        table.add_row(mid, info["name"], f"{info['context']:,}")
                console.print(table)
                continue

            # Add context about current directory if asking about files
            ctx_msg = user_input
            if "file" in user_input.lower() or "project" in user_input.lower():
                 tree = fm.get_project_tree(max_depth=3)
                 ctx_msg = f"User Request: {user_input}\n\nCurrent Project Structure:\n{tree}"

            session.messages.append({"role": "user", "content": ctx_msg})

            console.print()

            # Streaming response wrapper
            full_response = ""

            with Live(console=console, refresh_per_second=15, vertical_overflow="visible") as live:
                md_content = ""
                def update_display(token):
                    nonlocal md_content, full_response
                    md_content += token
                    if len(md_content) % 5 == 0 or token.endswith('\n'): # Throttle updates slightly for performance
                        live.update(Markdown(md_content))

                try:
                    # Initialize if needed
                    session.init_streamer()
                    if not session.streamer:
                         raise StreamingError("No API Key configured. Please go to http://127.0.0.1:7891 and enter your API key.")

                    # Run stream_chat in executor to keep UI responsive
                    full_response = await asyncio.get_event_loop().run_in_executor(
                        None,
                        lambda: session.streamer.stream_chat(session.messages, on_token=update_display)
                    )

                    # Final update
                    live.update(Markdown(full_response))

                except StreamingError as e:
                    live.update(Panel(f"[red]Error:[/red] {e}"))
                    session.messages.pop() # Remove failed user message
                    continue

            session.messages.append({"role": "assistant", "content": full_response})
            session.trim_messages() # Manage context window
            console.print() # Newline after response

            # Post-processing: Check for file generations and run commands
            cmd_outputs = process_file_actions(full_response)

            if cmd_outputs:
                session.messages.append({
                    "role": "user",
                    "content": f"Terminal output from previous commands executed:\n{cmd_outputs}\nPlease proceed naturally based on this output."
                })

        except (KeyboardInterrupt, EOFError):
            continue
        except Exception as e:
            console.print(f"[red]Unexpected error:[/red] {e}")


@click.group(invoke_without_command=True)
@click.option('--version', is_flag=True, help='Show version and exit.')
@click.option('--dir', default='.', help='Project directory to work in.')
@click.option('--setup', is_flag=True, help='Run interactive setup (same as: quickvibeai setup).')
@click.pass_context
def main_entry(ctx, version, dir, setup):
    """QuickVibeAI — The ultimate AI coding assistant. Multi-provider, cross-platform, terminal-native."""
    if version:
        console.print(f"[bold cyan]QuickVibeAI[/bold cyan] v{__version__}")
        return

    # --setup flag for backward compatibility
    if setup:
        interactive_setup()
        return

    # If a subcommand was invoked, let it handle things
    if ctx.invoked_subcommand is not None:
        return

    # Default: launch the interactive CLI
    _launch_cli(dir)


@main_entry.command()
def setup():
    """Run interactive setup — configure API key and select a model."""
    interactive_setup()


@main_entry.command()
@click.option('--dir', default='.', help='Project directory to work in.')
def chat(dir):
    """Launch the interactive AI chat (default behavior)."""
    _launch_cli(dir)


def _launch_cli(dir='.'):
    """Core launcher for the interactive CLI + gateway server."""
    fm.set_project_root(dir)
    ensure_config_dir()

    # Start Local FastAPI Proxy Server in the background silently
    import subprocess
    import atexit

    server_proc = subprocess.Popen(
        [sys.executable, "-m", "uvicorn", "quickvibeai.server:app", "--port", "7891", "--host", "127.0.0.1", "--log-level", "critical"],
        cwd=os.getcwd(),
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL
    )

    def kill_server():
        try:
            server_proc.terminate()
        except Exception:
            pass

    atexit.register(kill_server)

    console.print(Panel(
        f"[bold green]🌟 QuickVibeAI v{__version__} Local Node running at http://127.0.0.1:7891[/bold green]\n"
        "[dim]Use the beautiful Web UI to manage your Groq, OpenRouter, and Gemini Keys dynamically![/dim]",
        border_style="green"
    ))

    try:
        asyncio.run(main_loop())
    except KeyboardInterrupt:
         console.print("\n[dim]Goodbye![/dim]")

if __name__ == '__main__':
    main_entry()
