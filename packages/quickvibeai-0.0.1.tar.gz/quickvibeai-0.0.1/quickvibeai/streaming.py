"""
QuickVibeAI Streaming Engine
Handles SSE (Server-Sent Events) streaming from OpenRouter API using the official OpenAI standard client.
Provides real-time token-by-token output for a live coding experience.

Cross-platform: Works on Windows, Linux, macOS, and Termux (Android).
"""

from typing import List, Dict, Optional, Callable
from openai import OpenAI

from quickvibeai.config import get_api_key, get_base_url, get_model, load_config


class StreamingError(Exception):
    """Custom exception for streaming errors."""
    pass


class OpenRouterStream:
    """
    Handles streaming chat completions using the official OpenAI Client structure.
    """

    def __init__(self, model: Optional[str] = None):
        # We explicitly lock routing to the internal AI Gateway Server
        self.base_url = "http://127.0.0.1:7891/v1"
        self.api_key = "local_node_relay"
        self.model = model or get_model()
        self.config = load_config()

        # Initialize official OpenAI client mapped strictly to our local Gateway
        self.client = OpenAI(
            base_url=self.base_url,
            api_key=self.api_key,
            default_headers={
                "HTTP-Referer": "https://quickvibeai.dev",
                "X-Title": "QuickVibeAI CLI Node"
            }
        )

    def stream_chat(
        self,
        messages: List[Dict[str, str]],
        on_token: Optional[Callable[[str], None]] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
    ) -> str:
        """
        Stream a chat completion natively. Returns the full response text.
        Calls on_token callback for each token received (for live display).
        """
        full_response = []

        try:
            stream = self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                stream=True,
                temperature=temperature or self.config.get("temperature", 0.7),
                max_tokens=max_tokens or self.config.get("max_tokens", 16384),
            )

            for chunk in stream:
                if chunk.choices and chunk.choices[0].delta.content:
                    content = chunk.choices[0].delta.content
                    full_response.append(content)
                    if on_token:
                        on_token(content)

        except Exception as e:
            raise StreamingError(f"API Error: {str(e)}")

        return "".join(full_response)

    def chat(
        self,
        messages: List[Dict[str, str]],
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
    ) -> str:
        """Non-streaming chat completion using OpenAI client."""
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                stream=False,
                temperature=temperature or self.config.get("temperature", 0.7),
                max_tokens=max_tokens or self.config.get("max_tokens", 16384),
            )
            return response.choices[0].message.content
        except Exception as e:
            raise StreamingError(f"API Error: {str(e)}")
