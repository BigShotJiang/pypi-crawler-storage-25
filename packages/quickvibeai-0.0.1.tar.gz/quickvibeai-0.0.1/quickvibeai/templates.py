"""
QuickVibeAI Knowledge Base & Templates
Contains design patterns and system prompt configuration.
Cross-platform: Works on Windows, Linux, macOS, and Termux (Android).
"""

import platform


def get_system_prompt():
    os_name = platform.system()
    # Termux on Android reports "Linux"
    is_termux = "com.termux" in os.environ.get("PREFIX", "")  if os_name == "Linux" else False
    
    if is_termux:
        shell_name = "Bash (Termux)"
        os_context = f"**ANDROID/TERMUX** using **{shell_name}**"
    elif os_name == "Windows":
        shell_name = "PowerShell"
        os_context = f"**WINDOWS** using **{shell_name}**"
    elif os_name == "Darwin":
        shell_name = "Zsh"
        os_context = f"**macOS** using **{shell_name}**"
    else:
        shell_name = "Bash"
        os_context = f"**LINUX** using **{shell_name}**"

    return f"""You are QuickVibeAI, a powerful AI coding assistant.
You are running on a {os_context}.

ENVIRONMENT RULES:
1. **FILES**: 
   - Use `--- FILE: path ---` to create/edit files.
   - Use `--- READ: path ---` to inspect files.
   - Use `--- DELETE: path ---` to remove corrupt or unnecessary files.
   The CLI handles these automatically. NEVER use shell commands like `del`, `rm`, or `touch`.
4. **OS**: Use {shell_name} for native tasks (e.g. `ls`, `ps`).

STRICT FORMATTING:
1. NO REPETITION. Do not repeat your thoughts or instructions.
2. NO PREAMBLE. Don't say "I'm running on X, not Y". Just do the task.
3. Use the following for files:
   --- FILE: path/to/file.ext ---
   ```extension
   // code
   ```
4. Use the following for commands:
   ```bash
   command
   ```

BEHAVIOR:
Be concise. Do not repeat your instructions or environmental context back to the user. Just act on the request.
"""


import os

BASE_HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en" class="antialiased text-slate-500 bg-slate-50 dark:bg-slate-900 dark:text-slate-400">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QuickVibeAI Application</title>
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        primary: '#6366f1',
                    }
                }
            }
        }
    </script>
    <!-- HTMX -->
    <script src="https://unpkg.com/htmx.org@1.9.10"></script>
    <!-- Alpine.js -->
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <!-- Phosphor Icons -->
    <script src="https://unpkg.com/@phosphor-icons/web"></script>
    <style>
        .htmx-indicator{
            opacity:0;
            transition: opacity 200ms ease-in;
        }
        .htmx-request .htmx-indicator{
            opacity:1
        }
        .htmx-request.htmx-indicator{
            opacity:1
        }
    </style>
</head>
<body class="min-h-screen flex flex-col font-sans transition-colors duration-300" x-data="{ darkMode: false }" :class="{ 'dark': darkMode }">
    <!-- Navbar -->
    <nav class="sticky top-0 z-50 backdrop-blur-lg bg-white/70 dark:bg-slate-900/70 border-b border-slate-200 dark:border-slate-800">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16 items-center">
                <div class="flex items-center gap-2">
                    <div class="w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white font-bold shadow-lg shadow-indigo-500/30">
                        <i class="ph ph-lightning text-xl"></i>
                    </div>
                    <span class="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-indigo-600 to-purple-600 dark:from-indigo-400 dark:to-purple-400">
                        App Name
                    </span>
                </div>
                <div>
                   <button @click="darkMode = !darkMode" class="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
                       <i class="ph ph-moon text-xl" x-show="!darkMode"></i>
                       <i class="ph ph-sun text-xl text-yellow-500" x-show="darkMode" x-cloak></i>
                   </button>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <main class="flex-grow w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8" id="main-content">
        <!-- Content gets swapped here by HTMX -->
    </main>

</body>
</html>
"""

# A massive dictionary mapping keywords to design patterns and code structures.
# In a real scalable system, this would be a vector DB, but for the CLI tool we embed it.
KNOWLEDGE_BASE = {
    "dashboard": {
        "description": "A stunning admin dashboard with sidebar, topbar, and animated stat cards.",
        "html_structure": "Grid layout (sidebar + main area). Cards with hover effects (hover:-translate-y-1 hover:shadow-xl).",
        "alpine_state": "sidebarOpen: true, activeTab: 'overview'",
        "htmx_endpoints": ["/api/stats.php", "/api/chart-data.php"]
    },
    "authentication": {
        "description": "Glassmorphism login/signup form with smooth transitions.",
        "html_structure": "Centered flex container. Form wrapped in backdrop-blur-xl bg-white/10 border border-white/20.",
        "alpine_state": "isLogin: true, loading: false",
        "htmx_endpoints": ["/api/login.php", "/api/register.php"]
    },
    "datatable": {
        "description": "Real-time searchable, sortable, paginated data table.",
        "html_structure": "w-full text-left border-collapse. th with cursor-pointer. Rows with hover:bg-slate-50 dark:hover:bg-slate-800/50.",
        "alpine_state": "search: '', sortCol: 'id', sortAsc: true",
        "htmx_endpoints": ["/api/data.php?search={search}&sort={sortCol}"]
    },
    "kanban": {
        "description": "Drag-and-drop kanban board using Alpine.js and HTMX for persistence.",
        "html_structure": "Flex container with horizontal scroll. Columns with flex-col shrink-0. Cards with cursor-grab.",
        "alpine_state": "dragging: null",
        "htmx_endpoints": ["/api/update-task.php"]
    },
     "hero": {
        "description": "A visually striking hero section with a gradient text headline, animated blobs in the background, and a prominent call-to-action.",
        "html_structure": "Relative container, overflow-hidden. Absolute positioned blurred circles.",
        "alpine_state": "loaded: false",
        "htmx_endpoints": []
    }
}

def get_context_for_prompt() -> str:
    """Prepares the knowledge base context to inject into the system prompt."""
    context = "Available Design Patterns (Use these if relevant):\n"
    for name, data in KNOWLEDGE_BASE.items():
        context += f"- {name.upper()}: {data['description']}\n"
    return context
