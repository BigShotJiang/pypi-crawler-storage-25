"""
QuickVibeAI Configuration Manager
Handles API key storage, model preferences, and project settings.
All config stored in ~/.quickvibeai/config.json

Cross-platform: Works on Windows, Linux, macOS, and Termux (Android).
"""

import json
import os
import sys
from pathlib import Path
from typing import Optional, Dict, Any

CONFIG_DIR = Path.home() / ".quickvibeai"
CONFIG_FILE = CONFIG_DIR / "config.json"
HISTORY_FILE = CONFIG_DIR / "history.json"

DEFAULT_CONFIG = {
    "api_key": "",
    "base_url": "https://openrouter.ai/api/v1",
    "default_model": "openrouter/free",
    "temperature": 0.7,
    "max_tokens": 16384,
    "stream": True,
    "theme": "dark",
    "auto_save": True,
    "project_root": ".",
}

# ─────────────────────────────────────────────────────────────────────
# UPDATED MODEL LIST — Fetched from OpenRouter API on April 2026
# Split into FREE and PAID tiers for clear presentation.
# ─────────────────────────────────────────────────────────────────────

AVAILABLE_MODELS = {
    # ── FREE ROUTER (auto-picks best free model) ─────────────────────
    "openrouter/free": {
        "name": "🎰 Free Models Router (Auto)",
        "provider": "OpenRouter",
        "context": 200000,
        "speed": "⚡ Varies",
        "cost": "FREE",
        "tier": "free",
    },

    # ── FREE: OpenAI ──────────────────────────────────────────────────
    "openai/gpt-oss-120b:free": {
        "name": "GPT OSS 120B",
        "provider": "OpenAI",
        "context": 131072,
        "speed": "🚀 Fast",
        "cost": "FREE",
        "tier": "free",
    },
    "openai/gpt-oss-20b:free": {
        "name": "GPT OSS 20B",
        "provider": "OpenAI",
        "context": 131072,
        "speed": "⚡ Ultra Fast",
        "cost": "FREE",
        "tier": "free",
    },

    # ── FREE: Google ──────────────────────────────────────────────────
    "google/gemma-4-31b-it:free": {
        "name": "Gemma 4 31B",
        "provider": "Google",
        "context": 262144,
        "speed": "🚀 Fast",
        "cost": "FREE",
        "tier": "free",
    },
    "google/gemma-4-26b-a4b-it:free": {
        "name": "Gemma 4 26B A4B",
        "provider": "Google",
        "context": 262144,
        "speed": "🚀 Fast",
        "cost": "FREE",
        "tier": "free",
    },
    "google/gemma-3-27b-it:free": {
        "name": "Gemma 3 27B",
        "provider": "Google",
        "context": 131072,
        "speed": "🚀 Fast",
        "cost": "FREE",
        "tier": "free",
    },
    "google/gemma-3-12b-it:free": {
        "name": "Gemma 3 12B",
        "provider": "Google",
        "context": 32768,
        "speed": "⚡ Ultra Fast",
        "cost": "FREE",
        "tier": "free",
    },
    "google/gemma-3-4b-it:free": {
        "name": "Gemma 3 4B",
        "provider": "Google",
        "context": 32768,
        "speed": "⚡ Ultra Fast",
        "cost": "FREE",
        "tier": "free",
    },
    "google/gemma-3n-e4b-it:free": {
        "name": "Gemma 3n 4B",
        "provider": "Google",
        "context": 8192,
        "speed": "⚡ Ultra Fast",
        "cost": "FREE",
        "tier": "free",
    },

    # ── FREE: Meta ────────────────────────────────────────────────────
    "meta-llama/llama-3.3-70b-instruct:free": {
        "name": "Llama 3.3 70B",
        "provider": "Meta",
        "context": 65536,
        "speed": "🚀 Fast",
        "cost": "FREE",
        "tier": "free",
    },
    "meta-llama/llama-3.2-3b-instruct:free": {
        "name": "Llama 3.2 3B",
        "provider": "Meta",
        "context": 131072,
        "speed": "⚡ Ultra Fast",
        "cost": "FREE",
        "tier": "free",
    },

    # ── FREE: NVIDIA ──────────────────────────────────────────────────
    "nvidia/nemotron-3-super-120b-a12b:free": {
        "name": "Nemotron 3 Super 120B",
        "provider": "NVIDIA",
        "context": 262144,
        "speed": "🚀 Fast",
        "cost": "FREE",
        "tier": "free",
    },
    "nvidia/nemotron-3-nano-30b-a3b:free": {
        "name": "Nemotron 3 Nano 30B",
        "provider": "NVIDIA",
        "context": 256000,
        "speed": "⚡ Ultra Fast",
        "cost": "FREE",
        "tier": "free",
    },
    "nvidia/nemotron-nano-12b-v2-vl:free": {
        "name": "Nemotron Nano 12B V2 (Vision)",
        "provider": "NVIDIA",
        "context": 128000,
        "speed": "⚡ Ultra Fast",
        "cost": "FREE",
        "tier": "free",
    },
    "nvidia/nemotron-nano-9b-v2:free": {
        "name": "Nemotron Nano 9B V2",
        "provider": "NVIDIA",
        "context": 128000,
        "speed": "⚡ Ultra Fast",
        "cost": "FREE",
        "tier": "free",
    },

    # ── FREE: Qwen ────────────────────────────────────────────────────
    "qwen/qwen3-coder:free": {
        "name": "Qwen3 Coder 480B A35B",
        "provider": "Qwen",
        "context": 262000,
        "speed": "🚀 Fast",
        "cost": "FREE",
        "tier": "free",
    },
    "qwen/qwen3-next-80b-a3b-instruct:free": {
        "name": "Qwen3 Next 80B A3B",
        "provider": "Qwen",
        "context": 262144,
        "speed": "🚀 Fast",
        "cost": "FREE",
        "tier": "free",
    },

    # ── FREE: Others ──────────────────────────────────────────────────
    "minimax/minimax-m2.5:free": {
        "name": "MiniMax M2.5",
        "provider": "MiniMax",
        "context": 196608,
        "speed": "🚀 Fast",
        "cost": "FREE",
        "tier": "free",
    },
    "z-ai/glm-4.5-air:free": {
        "name": "GLM 4.5 Air",
        "provider": "Z.ai",
        "context": 131072,
        "speed": "🚀 Fast",
        "cost": "FREE",
        "tier": "free",
    },
    "nousresearch/hermes-3-llama-3.1-405b:free": {
        "name": "Hermes 3 (405B)",
        "provider": "NousResearch",
        "context": 131072,
        "speed": "🐢 Medium",
        "cost": "FREE",
        "tier": "free",
    },
    "arcee-ai/trinity-large-preview:free": {
        "name": "Trinity Large Preview",
        "provider": "Arcee AI",
        "context": 131000,
        "speed": "🚀 Fast",
        "cost": "FREE",
        "tier": "free",
    },
    "cognitivecomputations/dolphin-mistral-24b-venice-edition:free": {
        "name": "Dolphin Mistral 24B (Uncensored)",
        "provider": "Venice",
        "context": 32768,
        "speed": "🚀 Fast",
        "cost": "FREE",
        "tier": "free",
    },

    # ── PAID: Premium Models ──────────────────────────────────────────
    "google/gemini-2.5-flash": {
        "name": "Gemini 2.5 Flash",
        "provider": "Google",
        "context": 1048576,
        "speed": "⚡ Ultra Fast",
        "cost": "$",
        "tier": "paid",
    },
    "google/gemini-2.5-pro": {
        "name": "Gemini 2.5 Pro",
        "provider": "Google",
        "context": 1048576,
        "speed": "🚀 Fast",
        "cost": "$$",
        "tier": "paid",
    },
    "anthropic/claude-sonnet-4": {
        "name": "Claude Sonnet 4",
        "provider": "Anthropic",
        "context": 200000,
        "speed": "🚀 Fast",
        "cost": "$$$",
        "tier": "paid",
    },
    "anthropic/claude-3.5-sonnet": {
        "name": "Claude 3.5 Sonnet",
        "provider": "Anthropic",
        "context": 200000,
        "speed": "🚀 Fast",
        "cost": "$$",
        "tier": "paid",
    },
    "openai/gpt-4o": {
        "name": "GPT-4o",
        "provider": "OpenAI",
        "context": 128000,
        "speed": "🚀 Fast",
        "cost": "$$",
        "tier": "paid",
    },
    "openai/gpt-4o-mini": {
        "name": "GPT-4o Mini",
        "provider": "OpenAI",
        "context": 128000,
        "speed": "⚡ Ultra Fast",
        "cost": "$",
        "tier": "paid",
    },
    "deepseek/deepseek-chat": {
        "name": "DeepSeek Chat V3",
        "provider": "DeepSeek",
        "context": 65536,
        "speed": "⚡ Ultra Fast",
        "cost": "$",
        "tier": "paid",
    },
    "deepseek/deepseek-coder": {
        "name": "DeepSeek Coder V2",
        "provider": "DeepSeek",
        "context": 65536,
        "speed": "⚡ Ultra Fast",
        "cost": "$",
        "tier": "paid",
    },
    "mistralai/mistral-large": {
        "name": "Mistral Large",
        "provider": "Mistral",
        "context": 128000,
        "speed": "🚀 Fast",
        "cost": "$$",
        "tier": "paid",
    },
    "qwen/qwen-2.5-coder-32b-instruct": {
        "name": "Qwen 2.5 Coder 32B",
        "provider": "Alibaba",
        "context": 131072,
        "speed": "🚀 Fast",
        "cost": "$",
        "tier": "paid",
    },
}


def ensure_config_dir():
    """Create config directory if it doesn't exist."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)


def load_config() -> Dict[str, Any]:
    """Load configuration from JSON file."""
    ensure_config_dir()
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, "r") as f:
                saved = json.load(f)
            # Merge with defaults to pick up new keys
            config = {**DEFAULT_CONFIG, **saved}
            return config
        except (json.JSONDecodeError, IOError):
            return DEFAULT_CONFIG.copy()
    return DEFAULT_CONFIG.copy()


def save_config(config: Dict[str, Any]):
    """Save configuration to JSON file with restricted permissions."""
    ensure_config_dir()
    content = json.dumps(config, indent=2)

    # Create/Open file with specific permissions: 0600 (Owner read/write only)
    mode = 0o600
    if os.path.exists(CONFIG_FILE):
        try:
            os.chmod(CONFIG_FILE, mode)
        except OSError:
            pass  # Windows/Termux may not support chmod the same way

    with open(CONFIG_FILE, "w") as f:
        f.write(content)

    # Ensure permissions are set immediately after creation
    try:
        os.chmod(CONFIG_FILE, mode)
    except OSError:
        pass  # Some environments handle permissions via ACLs


def get_api_key() -> Optional[str]:
    """Get the OpenRouter API key."""
    config = load_config()
    key = config.get("api_key", "")
    if not key:
        key = os.environ.get("OPENROUTER_API_KEY", "")
    return key if key else None


def set_api_key(key: str):
    """Set the OpenRouter API key."""
    config = load_config()
    config["api_key"] = key
    save_config(config)


def get_model() -> str:
    """Get the current model."""
    config = load_config()
    return config.get("default_model", DEFAULT_CONFIG["default_model"])


def set_model(model: str):
    """Set the default model."""
    config = load_config()
    config["default_model"] = model
    save_config(config)


def get_base_url() -> str:
    """Get the OpenRouter base URL."""
    config = load_config()
    return config.get("base_url", DEFAULT_CONFIG["base_url"])


def save_conversation_history(history: list):
    """Save conversation history."""
    ensure_config_dir()
    with open(HISTORY_FILE, "w") as f:
        json.dump(history, f, indent=2)


def load_conversation_history() -> list:
    """Load conversation history."""
    if HISTORY_FILE.exists():
        try:
            with open(HISTORY_FILE, "r") as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            return []
    return []
