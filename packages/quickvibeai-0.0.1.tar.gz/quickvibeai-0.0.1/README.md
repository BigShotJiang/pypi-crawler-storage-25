# ⚡ QuickVibeAI

**The Ultimate AI Coding Assistant — Multi-Provider, Cross-Platform, Terminal-Native.**

QuickVibeAI is a powerful CLI-based AI coding assistant that helps you build modern web applications. It understands your project structure, reads your files, generates code, and executes commands — all while keeping you in total control.

## 🚀 Features

- **27+ Free Models**: Updated free model list from OpenRouter (GPT OSS 120B, Gemma 4, Qwen3 Coder, Nemotron, Llama 3.3, and more).
- **Multi-Provider Support**: Switch between OpenRouter, Groq, and Native Gemini via a beautiful local control panel.
- **Cross-Platform**: Works on **Windows**, **Linux**, **macOS**, and **Termux (Android)**.
- **Project Aware**: Automatically maps your directory tree to provide full context to the AI.
- **Native File Operations**: Creates, reads, and deletes files directly within your project.
- **Smart Command Execution**: Runs dev servers, installs dependencies, and manages builds with user confirmation.
- **Beautiful UI**: Powered by `Rich` and `Prompt-Toolkit` for a premium terminal experience.

## 🛠️ Installation

### From PyPI (Recommended)

```bash
pip install quickvibeai
```

### From Source

```bash
git clone https://github.com/devnathani16/QuickVibeAI.git
cd QuickVibeAI
pip install -e .
```

### Termux (Android)

```bash
pkg install python rust
pip install quickvibeai
```

## ⌨️ Usage

Launch QuickVibeAI from any project directory:

```bash
quickvibeai
```

### First-Time Setup

```bash
quickvibeai --setup
```

This will guide you through API key configuration and model selection.

### Options

| Flag | Description |
|------|-------------|
| `--setup` | Run interactive setup (API key + model) |
| `--dir PATH` | Set project directory |
| `--version` | Show version |

### Commands Inside QuickVibeAI

| Command | Description |
|---------|-------------|
| `/tree` | View the full project file structure |
| `/models` | List all available free models |
| `/clear` | Clear the local chat history |
| `exit` | Quit the application |

## 🌐 Web Control Panel

When QuickVibeAI starts, it launches a local web panel at `http://127.0.0.1:7891` where you can:

- Set API keys for OpenRouter, Groq, and Gemini
- Switch models on-the-fly (changes reflect instantly in the CLI)
- Browse all 27+ free models and premium paid options

## 🤖 Supported Free Models (April 2026)

| Provider | Model | Context |
|----------|-------|---------|
| OpenRouter | Free Models Router (Auto) | 200K |
| OpenAI | GPT OSS 120B | 131K |
| OpenAI | GPT OSS 20B | 131K |
| Google | Gemma 4 31B | 262K |
| Google | Gemma 4 26B A4B | 262K |
| Google | Gemma 3 27B | 131K |
| Meta | Llama 3.3 70B | 65K |
| NVIDIA | Nemotron 3 Super 120B | 262K |
| NVIDIA | Nemotron 3 Nano 30B | 256K |
| Qwen | Qwen3 Coder 480B A35B | 262K |
| Qwen | Qwen3 Next 80B A3B | 262K |
| MiniMax | MiniMax M2.5 | 196K |
| NousResearch | Hermes 3 (405B) | 131K |
| ...and more | See `/models` in CLI | — |

## 🛡️ Security Warning

> [!CAUTION]
> **QuickVibeAI executes AI-suggested shell commands directly on your machine.**
> *   **Always review commands** before confirming execution.
> *   **Never run as root/administrator.**
> *   AI models can occasionally suggest destructive commands. Use at your own risk.

## ⚖️ License

MIT License. See [LICENSE](LICENSE) for details.
