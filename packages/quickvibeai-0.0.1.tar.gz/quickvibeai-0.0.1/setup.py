from setuptools import setup, find_packages
from pathlib import Path

# Read long description from README
this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding="utf-8")

setup(
    name="quickvibeai",
    version="0.0.1",
    author="QuickVibeAI",
    author_email="quickvibeai@proton.me",
    description="The ultimate AI coding assistant — multi-provider, cross-platform, terminal-native.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/devnathani16/QuickVibeAI",
    packages=find_packages(),
    python_requires=">=3.9",
    install_requires=[
        "httpx>=0.27.0",
        "rich>=13.7.0",
        "prompt_toolkit>=3.0.43",
        "click>=8.1.7",
        "pygments>=2.17.0",
        "openai>=1.52.0",
        "fastapi>=0.104.0",
        "uvicorn>=0.23.0",
        "sse-starlette>=2.0.0",
        "pydantic>=2.0.0",
    ],
    entry_points={
        "console_scripts": [
            "quickvibeai=quickvibeai.cli:main_entry",
        ],
    },
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Topic :: Software Development :: Code Generators",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Environment :: Console",
    ],
    keywords="ai coding assistant openrouter gemini groq terminal cli quickvibeai",
    project_urls={
        "Bug Tracker": "https://github.com/devnathani16/QuickVibeAI/issues",
        "Source": "https://github.com/devnathani16/QuickVibeAI",
    },
)
