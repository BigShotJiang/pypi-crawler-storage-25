"""Cluster profile registry — single source of site-specific knowledge.

Adding a new cluster = adding one ``_register()`` call below.
Nothing else in the codebase needs to change.
"""

# --------------------------------------------------
# import necessary modules
# --------------------------------------------------
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


# --------------------------------------------------
# scheduler enum (moved here from the old scheduler.py)
# --------------------------------------------------
class Scheduler(Enum):
    """Supported job-scheduler types."""

    SLURM = "slurm"
    PBS = "pbs"
    UNKNOWN = "unknown"

    def __str__(self) -> str:  # noqa: D105
        return self.value


# --------------------------------------------------
# cluster profile dataclass
# --------------------------------------------------
@dataclass(frozen=True)
class ClusterProfile:
    """Everything we know about a specific HPC cluster."""

    name: str
    login_aliases: tuple[str, ...] = ()
    scheduler: Scheduler = Scheduler.UNKNOWN
    cpus_per_node: int = 1
    default_partition: str = "standard"
    # site-specific override applied when the project/account number ends in "FX"
    # (e.g. ERDC AFOSR allocations route to the 'frontier' queue on Carpenter).
    # leave as None on clusters that don't have such a rule.
    fx_partition: str | None = None
    preferred_launcher: str = "mpirun"
    resource_cmd: str | None = None
    modules: tuple[str, ...] = ()
    mem_per_cpu: str | None = None
    extra_sbatch: tuple[str, ...] = ()
    extra_pbs: tuple[str, ...] = ()


# --------------------------------------------------
# cluster profile registry
# maps the raw hostname (or login alias) to a ClusterProfile
# --------------------------------------------------
_PROFILES: dict[str, ClusterProfile] = {}

# helper to register a profile under its name and login aliases
def _register(p: ClusterProfile) -> None:
    """Register *p* under its ``name`` and every ``login_alias``."""
    _PROFILES[p.name] = p
    for alias in p.login_aliases:
        _PROFILES[alias] = p

# helper to look up a profile by hostname
def lookup(hostname: str) -> ClusterProfile | None:
    """Return the profile for *hostname*, or ``None`` for unknown clusters."""
    return _PROFILES.get(hostname)


# --------------------------------------------------
# known clusters
# --------------------------------------------------

# puma
_register(
    ClusterProfile(
        name="puma",
        login_aliases=("junonia", "wentletrap"),
        scheduler=Scheduler.SLURM,
        cpus_per_node=94,
        default_partition="standard",
        preferred_launcher="mpirun",
        resource_cmd="va",
        modules=(
            "gnu13/13.2.0",
            "openmpi5/5.0.5",
            "openblas/0.3.21",
        ),
        mem_per_cpu="1gb",
    )
)

# carpenter
# ERDC HPE Cray EX4000, AMD EPYC 9654 Genoa: 192 cores per node (96 × 2 sockets)
_register(
    ClusterProfile(
        name="carpenter",
        login_aliases=(),
        scheduler=Scheduler.PBS,
        cpus_per_node=192,
        default_partition="standard",
        # ERDC routes AFOSR (project ends in 'FX') jobs to the frontier queue
        fx_partition="frontier",
        preferred_launcher="aprun",
        resource_cmd="show_usage",
        modules=(),
        mem_per_cpu=None,
        extra_pbs=(
            # Slingshot 11 fabric: hybrid match mode keeps message rate up
            # for jobs with many small messages.
            "setenv FI_CXI_RX_MATCH_MODE hybrid",
        ),
    )
)

# nautilus
# NAVY Penguin Computing TrueHPC, AMD 7713 Milan: 128 cores/node, Slurm.
_register(
    ClusterProfile(
        name="nautilus",
        login_aliases=(),
        scheduler=Scheduler.SLURM,
        cpus_per_node=128,
        default_partition="standard",
        preferred_launcher="srun",
        resource_cmd="show_usage",
        modules=(),
        mem_per_cpu=None,
    )
)

# warhawk
_register(
    ClusterProfile(
        name="warhawk",
        login_aliases=(),
        scheduler=Scheduler.PBS,
        cpus_per_node=128,
        default_partition="standard",
        # ERDC routes AFOSR (project ends in 'FX') jobs to the frontier queue
        fx_partition="frontier",
        preferred_launcher="aprun",
        resource_cmd="show_usage",
        modules=(),
        mem_per_cpu=None,
        extra_pbs=(
            'setenv LD_LIBRARY_PATH "$HOME/lib:$LD_LIBRARY_PATH"',
            "setenv UCX_WARN_UNUSED_ENV_VARS n",
            "module swap cray-mpich cray-mpich-ucx",
        ),
    )
)
