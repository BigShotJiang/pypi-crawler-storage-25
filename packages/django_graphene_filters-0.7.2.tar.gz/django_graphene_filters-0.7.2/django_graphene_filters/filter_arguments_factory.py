"""Module for converting a AdvancedFilterSet class to filter arguments."""

import warnings
from collections.abc import Callable, Sequence
from typing import cast

import graphene
from anytree import Node
from django.db.models.constants import LOOKUP_SEP
from django_filters import Filter
from django_filters.conf import settings as django_settings
from graphene_django.filter.utils import get_model_field
from graphene_django.forms.converter import convert_form_field
from stringcase import pascalcase

from .conf import settings
from .filters import SearchQueryFilter, SearchRankFilter, TrigramFilter
from .filterset import AdvancedFilterSet
from .input_types import (
    SearchQueryFilterInputType,
    SearchRankFilterInputType,
    TrigramFilterInputType,
)
from .mixins import InputObjectTypeFactoryMixin


class FilterArgumentsFactory(InputObjectTypeFactoryMixin):
    """Factory for creating filter arguments in GraphQL from a given `AdvancedFilterSet` class."""

    # Special GraphQL filter input types and their associated factories
    SPECIAL_FILTER_INPUT_TYPES_FACTORIES: dict[str, Callable[[], graphene.InputField]] = {
        SearchQueryFilter.postfix: lambda: graphene.InputField(
            SearchQueryFilterInputType,
            description="Field for the full-text search using `SearchVector` and `SearchQuery` objects.",
        ),
        SearchRankFilter.postfix: lambda: graphene.InputField(
            SearchRankFilterInputType,
            description="Field for the full-text search using the `SearchRank` object.",
        ),
        TrigramFilter.postfix: lambda: graphene.InputField(
            TrigramFilterInputType,
            description="Field for the full-text search using trigram similarity or trigram distance.",
        ),
    }

    # Cache for storing input object types
    input_object_types: dict[str, type[graphene.InputObjectType]] = {}

    # Tracks which filterset class built each cached type name; used to detect collisions
    _type_filterset_registry: dict[str, type] = {}

    def __init__(
        self,
        filterset_class: type[AdvancedFilterSet],
        input_type_prefix: str,
    ) -> None:
        """Initialize the factory with a filterset class and an input type prefix.

        Args:
            filterset_class: The AdvancedFilterSet class to convert.
            input_type_prefix: Prefix to use for GraphQL types.
        """
        self.filterset_class = filterset_class
        self.input_type_prefix = input_type_prefix
        self.filter_input_type_name = f"{self.input_type_prefix}FilterInputType"

    @property
    def arguments(self) -> dict[str, graphene.Argument]:
        """Create and return the GraphQL arguments for filtering.

        Inspect a FilterSet and produce the arguments to pass to a Graphene Field.
        These arguments will be available to filter against in the GraphQL.

        Returns:
            A dictionary mapping from argument names to graphene.Argument objects.
        """
        input_object_type = self.input_object_types.get(
            self.filter_input_type_name,
            self.create_filter_input_type(
                self.filterset_to_trees(self.filterset_class),
            ),
        )
        return {
            settings.FILTER_KEY: graphene.Argument(
                input_object_type,
                description="Advanced filter field",
            ),
        }

    def create_filter_input_type(self, roots: list[Node]) -> type[graphene.InputObjectType]:
        """Generate a GraphQL filter InputObjectType for filtering based on the filter set trees.

        Args:
            roots: List of root nodes for each filter tree.

        Returns:
            A graphene.InputObjectType for filtering.
        """
        # Create GraphQL input fields based on the filter tree
        input_fields = {
            root.name: self.create_filter_input_subfield(
                root,
                self.input_type_prefix,
                f"`{pascalcase(root.name)}` field",
            )
            for root in roots
        }

        # Add special fields for AND, OR, and NOT fields for logical combination of filters
        logic_fields = {
            settings.AND_KEY: graphene.InputField(
                graphene.List(lambda: self.input_object_types[self.filter_input_type_name]),
                description="`And` field",
            ),
            settings.OR_KEY: graphene.InputField(
                graphene.List(lambda: self.input_object_types[self.filter_input_type_name]),
                description="`Or` field",
            ),
            settings.NOT_KEY: graphene.InputField(
                lambda: self.input_object_types[self.filter_input_type_name],
                description="`Not` field",
            ),
        }

        # Detect collisions: same type name registered for a different filterset class.
        # This causes silent incorrect behaviour — the second filterset silently replaces
        # the first in the schema — so we warn loudly instead of failing silently.
        prior = self._type_filterset_registry.get(self.filter_input_type_name)
        if prior is not None and prior is not self.filterset_class:
            warnings.warn(
                f"InputObjectType '{self.filter_input_type_name}' was previously built for "
                f"'{prior.__name__}' but is now being overwritten for "
                f"'{self.filterset_class.__name__}'. "
                "Queries using the first field will silently use the wrong filter schema. "
                "Set unique `filter_input_type_prefix` values on each "
                "AdvancedDjangoFilterConnectionField to fix this.",
                stacklevel=4,
            )

        # Combine all fields and create the InputObjectType
        self.input_object_types[self.filter_input_type_name] = cast(
            type[graphene.InputObjectType],
            type(
                self.filter_input_type_name,
                (graphene.InputObjectType,),
                {**input_fields, **logic_fields},
            ),
        )
        self._type_filterset_registry[self.filter_input_type_name] = self.filterset_class
        return self.input_object_types[self.filter_input_type_name]

    def create_filter_input_subfield(
        self,
        root: Node,
        prefix: str,
        description: str,
    ) -> graphene.InputField:
        """Create a filter input subfield from a filter set subtree."""
        if root.name in self.SPECIAL_FILTER_INPUT_TYPES_FACTORIES:
            return self.SPECIAL_FILTER_INPUT_TYPES_FACTORIES[root.name]()

        fields: dict[str, graphene.InputField] = {}

        # get_filters() returns the class-level cached expansion — no repeated work.
        all_filters = self.filterset_class.get_filters()

        for child in root.children:
            if child.height == 0:
                filter_name = f"{LOOKUP_SEP}".join(
                    node.name for node in child.path if node.name != django_settings.DEFAULT_LOOKUP_EXPR
                )
                fields[child.name] = self.get_field(filter_name, all_filters[filter_name])
            else:
                fields[child.name] = self.create_filter_input_subfield(
                    child,
                    prefix + pascalcase(root.name),
                    f"`{pascalcase(child.name)}` subfield",
                )

        return graphene.InputField(
            self.create_input_object_type(f"{prefix}{pascalcase(root.name)}FilterInputType", fields),
            description=description,
        )

    def get_field(self, name: str, filter_obj: Filter) -> graphene.InputField:
        """Create and return a Graphene input field from a Django Filter field.

        Parameters:
        - name (str): The name of the field.
        - filter_obj (Filter): The Django Filter field.

        Returns:
        - graphene.InputField: The created Graphene input field.
        """
        model = self.filterset_class._meta.model
        filter_type: str = filter_obj.lookup_expr

        # Initialize form field directly from the filter_obj filter
        form_field = filter_obj.field

        # Handle special case when the filter_obj filter type is not 'isnull' and the name is not declared
        if filter_type != "isnull" and name not in self.filterset_class.declared_filters:
            model_field = get_model_field(model, filter_obj.field_name)
            if hasattr(model_field, "formfield"):
                form_field = model_field.formfield(required=filter_obj.extra.get("required", False))

        # Convert Django form field to Graphene field
        graphene_field = convert_form_field(form_field)

        if filter_type in ("in", "range"):
            graphene_field = graphene.List(graphene_field.get_type())

        field_type = graphene_field.InputField()
        field_type.description = getattr(
            filter_obj, "label", f"`{pascalcase(filter_obj.lookup_expr)}` lookup"
        )
        return field_type

    # THIS IS THE MAGIC
    @classmethod
    def filterset_to_trees(cls, filterset_class: type[AdvancedFilterSet]) -> list[Node]:
        """Convert a FilterSet class to a list of trees.

        where each tree represents a set of chained lookups for a filter.

        Parameters:
        - filterset_class (Type[AdvancedFilterSet]): The FilterSet class to be converted.

        Returns:
        - List[Node]: A list of root nodes for each tree, each representing a filter.
        """
        # Initialize an empty list to hold the root nodes of the trees.
        trees: list[Node] = []

        # Use .get_filters().values() instead of .base_filters.values()
        # This ensures we get the expanded related filters.
        all_filters = filterset_class.get_filters()

        # Iterate through each filter in the FilterSet's base_filters.
        for filter_value in all_filters.values():
            # Split the filter's field_name and lookup_expr into a sequence of values.
            values = (
                *filter_value.field_name.split(LOOKUP_SEP),
                filter_value.lookup_expr,
            )

            # Check if any existing tree can accommodate the new sequence of values.
            # If not, create a new tree for it.
            if not trees or not any(cls.try_add_sequence(tree, values) for tree in trees):
                trees.append(cls.sequence_to_tree(values))

        return trees

    @classmethod
    def try_add_sequence(cls, root: Node, values: Sequence[str]) -> bool:
        """Attempt to add a sequence of values to an existing tree rooted at `root`.

        Return a flag indicating whether the mutation was made.

        Parameters:
        - root (Node): The root node of the tree.
        - values (Sequence[str]): The sequence of values to add.

        Returns:
        - bool: True if the sequence was successfully added, otherwise False.
        """
        if root.name != values[0]:
            return False

        for child in root.children:
            # is mutated?
            if cls.try_add_sequence(child, values[1:]):
                return True
        # Add a new subtree rooted at `root` if the sequence could not be added to any child
        root.children = (*root.children, cls.sequence_to_tree(values[1:]))
        return True

    @staticmethod
    def sequence_to_tree(values: Sequence[str]) -> Node:
        """Convert a sequence of values into a tree, where each value becomes a node.

        Parameters:
        - values (Sequence[str]): The sequence of values.

        Returns:
        - Node: The root node of the generated tree.
        """
        if not values:
            return Node(name="")

        node: Node | None = None

        for value in values:
            node = Node(name=value, parent=node)

        return node.root
