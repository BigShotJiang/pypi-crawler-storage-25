from __future__ import annotations
import typing
from underautomation.fanuc.common.files.variables.generic_variable_type import GenericVariableType
from UnderAutomation.Fanuc.Common.Files.Variables import SystemTimerVariableType as system_timer_variable_type

class SystemTimerVariableType(GenericVariableType):
	'''Describes the Fanuc type SYSTEM_TIMER'''
	def __init__(self, _internal = 0):
		if(_internal == 0):
			self._instance = system_timer_variable_type()
		else:
			self._instance = _internal

	@property
	def pwr_tot(self) -> int:
		'''Value of variable PWR_TOT'''
		return self._instance.PwrTot

	@property
	def pwr_lap(self) -> int:
		'''Value of variable PWR_LAP'''
		return self._instance.PwrLap

	@property
	def srv_tot(self) -> int:
		'''Value of variable SRV_TOT'''
		return self._instance.SrvTot

	@property
	def srv_lap(self) -> int:
		'''Value of variable SRV_LAP'''
		return self._instance.SrvLap

	@property
	def run_flg(self) -> int:
		'''Value of variable RUN_FLG'''
		return self._instance.RunFlg

	@property
	def run_tot(self) -> int:
		'''Value of variable RUN_TOT'''
		return self._instance.RunTot

	@property
	def run_lap(self) -> int:
		'''Value of variable RUN_LAP'''
		return self._instance.RunLap

	@property
	def wit_flg(self) -> int:
		'''Value of variable WIT_FLG'''
		return self._instance.WitFlg

	@property
	def wit_tot(self) -> int:
		'''Value of variable WIT_TOT'''
		return self._instance.WitTot

	@property
	def wit_lap(self) -> int:
		'''Value of variable WIT_LAP'''
		return self._instance.WitLap

	@property
	def shm_tot(self) -> int:
		'''Value of variable SHM_TOT'''
		return self._instance.ShmTot

	@property
	def shm_lap(self) -> int:
		'''Value of variable SHM_LAP'''
		return self._instance.ShmLap

	@property
	def fanuc_internal_type_name(self) -> str:
		'''Type Name on the robot'''
		return self._instance.FanucInternalTypeName

	def __str__(self):
		return self._instance.ToString() if self._instance is not None else ""

	def __repr__(self):
		return self.__str__()

	def __eq__(self, other) -> bool:
		if not isinstance(other, SystemTimerVariableType):
			NotImplemented
		return self._instance.Equals(other._instance)

	def __hash__(self) -> int:
		return self._instance.GetHashCode() if self._instance is not None else 0
