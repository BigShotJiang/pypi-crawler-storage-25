from __future__ import annotations
import typing
from underautomation.fanuc.common.files.variables.generic_variable_file import GenericVariableFile
from UnderAutomation.Fanuc.Common.Files.Variables import CbparamFile as cbparam_file

class CbparamFile(GenericVariableFile):
	'''Describes the Fanuc variable file cbparam.va'''
	def __init__(self, _internal = 0):
		if(_internal == 0):
			self._instance = cbparam_file()
		else:
			self._instance = _internal

	@property
	def payload1(self) -> float:
		'''Value of variable PAYLOAD1'''
		return self._instance.Payload1

	@property
	def payload1_x(self) -> float:
		'''Value of variable PAYLOAD1_X'''
		return self._instance.Payload1X

	@property
	def payload1_y(self) -> float:
		'''Value of variable PAYLOAD1_Y'''
		return self._instance.Payload1Y

	@property
	def payload1_z(self) -> float:
		'''Value of variable PAYLOAD1_Z'''
		return self._instance.Payload1Z

	@property
	def payload1_ix(self) -> float:
		'''Value of variable PAYLOAD1_IX'''
		return self._instance.Payload1Ix

	@property
	def payload1_iy(self) -> float:
		'''Value of variable PAYLOAD1_IY'''
		return self._instance.Payload1Iy

	@property
	def payload1_iz(self) -> float:
		'''Value of variable PAYLOAD1_IZ'''
		return self._instance.Payload1Iz

	@property
	def payload2(self) -> float:
		'''Value of variable PAYLOAD2'''
		return self._instance.Payload2

	@property
	def payload2_x(self) -> float:
		'''Value of variable PAYLOAD2_X'''
		return self._instance.Payload2X

	@property
	def payload2_y(self) -> float:
		'''Value of variable PAYLOAD2_Y'''
		return self._instance.Payload2Y

	@property
	def payload2_z(self) -> float:
		'''Value of variable PAYLOAD2_Z'''
		return self._instance.Payload2Z

	@property
	def payload2_ix(self) -> float:
		'''Value of variable PAYLOAD2_IX'''
		return self._instance.Payload2Ix

	@property
	def payload2_iy(self) -> float:
		'''Value of variable PAYLOAD2_IY'''
		return self._instance.Payload2Iy

	@property
	def payload2_iz(self) -> float:
		'''Value of variable PAYLOAD2_IZ'''
		return self._instance.Payload2Iz

	@property
	def tframe_x(self) -> typing.List[float]:
		'''Value of variable TFRAME_X'''
		return self._instance.TframeX

	@property
	def tframe_y(self) -> typing.List[float]:
		'''Value of variable TFRAME_Y'''
		return self._instance.TframeY

	@property
	def tframe_z(self) -> typing.List[float]:
		'''Value of variable TFRAME_Z'''
		return self._instance.TframeZ

	@property
	def se_ctrlmode(self) -> int:
		'''Value of variable SE_CTRLMODE'''
		return self._instance.SeCtrlmode

	@property
	def data_c1(self) -> typing.List[float]:
		'''Value of variable DATA_C1'''
		return self._instance.DataC1

	@property
	def data_c2(self) -> typing.List[float]:
		'''Value of variable DATA_C2'''
		return self._instance.DataC2

	@property
	def data_c3(self) -> typing.List[float]:
		'''Value of variable DATA_C3'''
		return self._instance.DataC3

	@property
	def data_c4(self) -> typing.List[float]:
		'''Value of variable DATA_C4'''
		return self._instance.DataC4

	@property
	def data_c5(self) -> typing.List[float]:
		'''Value of variable DATA_C5'''
		return self._instance.DataC5

	@property
	def data_c6(self) -> typing.List[float]:
		'''Value of variable DATA_C6'''
		return self._instance.DataC6

	@property
	def data_c7(self) -> typing.List[float]:
		'''Value of variable DATA_C7'''
		return self._instance.DataC7

	@property
	def data_c8(self) -> typing.List[float]:
		'''Value of variable DATA_C8'''
		return self._instance.DataC8

	@property
	def data_c9(self) -> typing.List[float]:
		'''Value of variable DATA_C9'''
		return self._instance.DataC9

	@property
	def data_c10(self) -> typing.List[float]:
		'''Value of variable DATA_C10'''
		return self._instance.DataC10

	def __str__(self):
		return self._instance.ToString() if self._instance is not None else ""

	def __repr__(self):
		return self.__str__()

	def __eq__(self, other) -> bool:
		if not isinstance(other, CbparamFile):
			NotImplemented
		return self._instance.Equals(other._instance)

	def __hash__(self) -> int:
		return self._instance.GetHashCode() if self._instance is not None else 0
