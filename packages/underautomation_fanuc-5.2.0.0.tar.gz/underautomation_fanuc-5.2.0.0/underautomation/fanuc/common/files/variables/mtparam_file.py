from __future__ import annotations
import typing
from underautomation.fanuc.common.files.variables.generic_variable_file import GenericVariableFile
from UnderAutomation.Fanuc.Common.Files.Variables import MtparamFile as mtparam_file

class MtparamFile(GenericVariableFile):
	'''Describes the Fanuc variable file mtparam.va'''
	def __init__(self, _internal = 0):
		if(_internal == 0):
			self._instance = mtparam_file()
		else:
			self._instance = _internal

	@property
	def def_itm(self) -> typing.List[int]:
		'''Value of variable DEF_ITM'''
		return self._instance.DefItm

	@property
	def intl_act(self) -> typing.List[int]:
		'''Value of variable INTL_ACT'''
		return self._instance.IntlAct

	@property
	def intl_run(self) -> typing.List[int]:
		'''Value of variable INTL_RUN'''
		return self._instance.IntlRun

	@property
	def due_once(self) -> typing.List[int]:
		'''Value of variable DUE_ONCE'''
		return self._instance.DueOnce

	@property
	def def_itm2(self) -> typing.List[int]:
		'''Value of variable DEF_ITM2'''
		return self._instance.DefItm2

	@property
	def intl_act2(self) -> typing.List[int]:
		'''Value of variable INTL_ACT2'''
		return self._instance.IntlAct2

	@property
	def intl_run2(self) -> typing.List[int]:
		'''Value of variable INTL_RUN2'''
		return self._instance.IntlRun2

	@property
	def due_once2(self) -> typing.List[int]:
		'''Value of variable DUE_ONCE2'''
		return self._instance.DueOnce2

	@property
	def def_itm_i(self) -> typing.List[int]:
		'''Value of variable DEF_ITM_I'''
		return self._instance.DefItmI

	@property
	def intl_act_i(self) -> typing.List[int]:
		'''Value of variable INTL_ACT_I'''
		return self._instance.IntlActI

	@property
	def intl_run_i(self) -> typing.List[int]:
		'''Value of variable INTL_RUN_I'''
		return self._instance.IntlRunI

	@property
	def due_once_i(self) -> typing.List[int]:
		'''Value of variable DUE_ONCE_I'''
		return self._instance.DueOnceI

	@property
	def intell_grs(self) -> int:
		'''Value of variable INTELL_GRS'''
		return self._instance.IntellGrs

	@property
	def coulomb_n(self) -> typing.List[float]:
		'''Value of variable COULOMB_N'''
		return self._instance.CoulombN

	@property
	def coulomb_n0(self) -> typing.List[float]:
		'''Value of variable COULOMB_N0'''
		return self._instance.CoulombN0

	@property
	def viscosity(self) -> typing.List[float]:
		'''Value of variable VISCOSITY'''
		return self._instance.Viscosity

	@property
	def a_motor(self) -> typing.List[float]:
		'''Value of variable A_MOTOR'''
		return self._instance.AMotor

	@property
	def a_friction(self) -> typing.List[float]:
		'''Value of variable A_FRICTION'''
		return self._instance.AFriction

	@property
	def a_dissip(self) -> typing.List[float]:
		'''Value of variable A_DISSIP'''
		return self._instance.ADissip

	@property
	def a_other1(self) -> typing.List[float]:
		'''Value of variable A_OTHER1'''
		return self._instance.AOther1

	@property
	def a_other2(self) -> typing.List[float]:
		'''Value of variable A_OTHER2'''
		return self._instance.AOther2

	@property
	def a_other3(self) -> typing.List[float]:
		'''Value of variable A_OTHER3'''
		return self._instance.AOther3

	@property
	def a_other4(self) -> typing.List[float]:
		'''Value of variable A_OTHER4'''
		return self._instance.AOther4

	@property
	def a_other5(self) -> typing.List[float]:
		'''Value of variable A_OTHER5'''
		return self._instance.AOther5

	@property
	def a_other6(self) -> typing.List[float]:
		'''Value of variable A_OTHER6'''
		return self._instance.AOther6

	@property
	def a_exponent(self) -> typing.List[float]:
		'''Value of variable A_EXPONENT'''
		return self._instance.AExponent

	@property
	def distance(self) -> typing.List[float]:
		'''Value of variable DISTANCE'''
		return self._instance.Distance

	@property
	def max_v_motor(self) -> typing.List[float]:
		'''Value of variable MAX_V_MOTOR'''
		return self._instance.MaxVMotor

	@property
	def coeff_off(self) -> typing.List[float]:
		'''Value of variable COEFF_OFF'''
		return self._instance.CoeffOff

	@property
	def sg_rate(self) -> typing.List[float]:
		'''Value of variable SG_RATE'''
		return self._instance.SgRate

	@property
	def t_grs_lim(self) -> typing.List[float]:
		'''Value of variable T_GRS_LIM'''
		return self._instance.TGrsLim

	@property
	def formula_id(self) -> typing.List[int]:
		'''Value of variable FORMULA_ID'''
		return self._instance.FormulaId

	@property
	def t_grs_thre(self) -> typing.List[float]:
		'''Value of variable T_GRS_THRE'''
		return self._instance.TGrsThre

	@property
	def grs_life(self) -> typing.List[float]:
		'''Value of variable GRS_LIFE'''
		return self._instance.GrsLife

	@property
	def weight1(self) -> typing.List[float]:
		'''Value of variable WEIGHT_1'''
		return self._instance.Weight1

	@property
	def weight2(self) -> typing.List[float]:
		'''Value of variable WEIGHT_2'''
		return self._instance.Weight2

	@property
	def weight3(self) -> typing.List[float]:
		'''Value of variable WEIGHT_3'''
		return self._instance.Weight3

	@property
	def weight4(self) -> typing.List[float]:
		'''Value of variable WEIGHT_4'''
		return self._instance.Weight4

	@property
	def weight5(self) -> typing.List[float]:
		'''Value of variable WEIGHT_5'''
		return self._instance.Weight5

	@property
	def theta1(self) -> typing.List[float]:
		'''Value of variable THETA_1'''
		return self._instance.Theta1

	@property
	def theta2(self) -> typing.List[float]:
		'''Value of variable THETA_2'''
		return self._instance.Theta2

	@property
	def theta3(self) -> typing.List[float]:
		'''Value of variable THETA_3'''
		return self._instance.Theta3

	@property
	def theta4(self) -> typing.List[float]:
		'''Value of variable THETA_4'''
		return self._instance.Theta4

	@property
	def theta5(self) -> typing.List[float]:
		'''Value of variable THETA_5'''
		return self._instance.Theta5

	@property
	def limit(self) -> typing.List[float]:
		'''Value of variable LIMIT'''
		return self._instance.Limit

	def __str__(self):
		return self._instance.ToString() if self._instance is not None else ""

	def __repr__(self):
		return self.__str__()

	def __eq__(self, other) -> bool:
		if not isinstance(other, MtparamFile):
			NotImplemented
		return self._instance.Equals(other._instance)

	def __hash__(self) -> int:
		return self._instance.GetHashCode() if self._instance is not None else 0
