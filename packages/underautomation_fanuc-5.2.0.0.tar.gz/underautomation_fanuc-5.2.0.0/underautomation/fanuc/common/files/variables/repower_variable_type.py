from __future__ import annotations
import typing
from underautomation.fanuc.common.files.variables.generic_variable_type import GenericVariableType
from UnderAutomation.Fanuc.Common.Files.Variables import RepowerVariableType as repower_variable_type

class RepowerVariableType(GenericVariableType):
	'''Describes the Fanuc type REPOWER_T'''
	def __init__(self, _internal = 0):
		if(_internal == 0):
			self._instance = repower_variable_type()
		else:
			self._instance = _internal

	@property
	def flag(self) -> bool:
		'''Value of variable $FLAG'''
		return self._instance.Flag

	@property
	def fanuc_internal_type_name(self) -> str:
		'''Type Name on the robot'''
		return self._instance.FanucInternalTypeName

	def __str__(self):
		return self._instance.ToString() if self._instance is not None else ""

	def __repr__(self):
		return self.__str__()

	def __eq__(self, other) -> bool:
		if not isinstance(other, RepowerVariableType):
			NotImplemented
		return self._instance.Equals(other._instance)

	def __hash__(self) -> int:
		return self._instance.GetHashCode() if self._instance is not None else 0
