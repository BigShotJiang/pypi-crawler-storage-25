from __future__ import annotations
import typing
from underautomation.fanuc.common.files.i_file_reader import IFileReader
from UnderAutomation.Fanuc.Common.Files import FileReader as file_reader

class FileReader(IFileReader):
	'''Read and decode fanuc files'''
	def __init__(self, _internal = 0):
		if(_internal == 0):
			self._instance = file_reader()
		else:
			self._instance = _internal

	@property
	def file_name(self) -> str:
		'''File name'''
		return self._instance.FileName

	def __str__(self):
		return self._instance.ToString() if self._instance is not None else ""

	def __repr__(self):
		return self.__str__()

	def __eq__(self, other) -> bool:
		if not isinstance(other, FileReader):
			NotImplemented
		return self._instance.Equals(other._instance)

	def __hash__(self) -> int:
		return self._instance.GetHashCode() if self._instance is not None else 0
