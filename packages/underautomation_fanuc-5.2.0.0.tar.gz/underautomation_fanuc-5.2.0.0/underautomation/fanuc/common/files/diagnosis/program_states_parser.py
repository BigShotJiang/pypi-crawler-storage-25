from __future__ import annotations
import typing
from underautomation.fanuc.common.files.section_parser_1 import SectionParser1
from underautomation.fanuc.common.files.diagnosis.program_states import ProgramStates
from UnderAutomation.Fanuc.Common.Files.Diagnosis import ProgramStatesParser as program_states_parser

class ProgramStatesParser(SectionParser1[ProgramStates]):
	'''Parser for the "TASK STATES" section, renamed from ProgramStatesReader to ProgramStatesParser. Uses compiled Regex for efficiency.'''
	def __init__(self, _internal = 0):
		if(_internal == 0):
			self._instance = program_states_parser()
		else:
			self._instance = _internal

	def parse_line(self, line: str) -> None:
		self._instance.ParseLine(line)

	def after_parse(self) -> None:
		self._instance.AfterParse()

	@property
	def section_start(self) -> typing.List[str]:
		return self._instance.SectionStart

	def __str__(self):
		return self._instance.ToString() if self._instance is not None else ""

	def __repr__(self):
		return self.__str__()

	def __eq__(self, other) -> bool:
		if not isinstance(other, ProgramStatesParser):
			NotImplemented
		return self._instance.Equals(other._instance)

	def __hash__(self) -> int:
		return self._instance.GetHashCode() if self._instance is not None else 0
