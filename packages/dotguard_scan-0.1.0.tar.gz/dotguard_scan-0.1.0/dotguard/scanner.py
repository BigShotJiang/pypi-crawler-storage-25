"""Walks project files and finds environment variable usage with regex."""

import os
import re

SUPPORTED = [".py", ".js", ".ts", ".env", ".yml", ".yaml", ".toml", ".sh"]

IGNORED = [".git", "node_modules", "__pycache__", ".venv", "dist", "venv", ".tox", ".eggs"]

PATTERNS = [
    re.compile(r'os\.getenv\(["\'](\w+)["\']'),            # os.getenv("KEY")
    re.compile(r'os\.environ\[["\'](\w+)["\']'),            # os.environ["KEY"]
    re.compile(r'os\.environ\.get\(["\'](\w+)["\']'),       # os.environ.get("KEY")
    re.compile(r'process\.env\.([A-Z_][A-Z0-9_]+)'),        # JS: process.env.KEY
    re.compile(r'\$\{?([A-Z_][A-Z0-9_]+)\}?'),              # Shell: $KEY or ${KEY}
    re.compile(r'(?i)getenv\(["\'](\w+)["\']'),              # generic getenv
]


def _should_scan(path, ignored):
    """Check if a path should be scanned (not inside an ignored directory)."""
    parts = path.split(os.sep)
    return not any(part in ignored for part in parts)


def _scan_file(filepath):
    """Scan a single file for environment variable references."""
    findings = []
    try:
        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
            for line_num, line in enumerate(f, start=1):
                for pattern in PATTERNS:
                    for match in pattern.finditer(line):
                        var_name = match.group(1)
                        findings.append({
                            "var": var_name,
                            "file": filepath,
                            "line": line_num,
                        })
    except (OSError, PermissionError):
        pass
    return findings


def scan(root=".", ignored=None):
    """Walk the project tree and return all env var references found.

    Args:
        root: Root directory to scan.
        ignored: Optional list of directory names to skip.

    Returns:
        List of dicts with keys: var, file, line.
    """
    if ignored is None:
        ignored = IGNORED

    root = os.path.abspath(root)
    findings = []

    for dirpath, dirnames, filenames in os.walk(root):
        # Prune ignored directories in-place so os.walk skips them
        dirnames[:] = [d for d in dirnames if d not in ignored]

        for filename in filenames:
            ext = os.path.splitext(filename)[1]
            if ext not in SUPPORTED:
                continue

            filepath = os.path.join(dirpath, filename)
            rel_path = os.path.relpath(filepath, root)

            for finding in _scan_file(filepath):
                finding["file"] = rel_path
                findings.append(finding)

    return findings
