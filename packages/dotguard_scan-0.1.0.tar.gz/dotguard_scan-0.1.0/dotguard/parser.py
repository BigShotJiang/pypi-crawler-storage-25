"""Extracts variable names, guesses context/type, and enriches findings."""

import re
from collections import defaultdict

TYPE_HINTS = [
    (re.compile(r'.*_URL$'),      "url"),
    (re.compile(r'.*_HOST$'),     "hostname"),
    (re.compile(r'.*_PORT$'),     "number"),
    (re.compile(r'.*_KEY$'),      "secret"),
    (re.compile(r'.*_SECRET$'),   "secret"),
    (re.compile(r'.*_PASSWORD$'), "secret"),
    (re.compile(r'.*_TOKEN$'),    "secret"),
    (re.compile(r'DEBUG$'),       "boolean"),
    (re.compile(r'.*_DEBUG$'),    "boolean"),
    (re.compile(r'.*_ENABLED$'),  "boolean"),
    (re.compile(r'.*_PATH$'),     "filepath"),
    (re.compile(r'.*_DIR$'),      "filepath"),
    (re.compile(r'.*_EMAIL$'),    "email"),
]

EXAMPLES = {
    "url":      "postgresql://user:password@localhost:5432/dbname",
    "hostname": "localhost",
    "number":   "5432",
    "secret":   "your-secret-here",
    "boolean":  "true",
    "filepath": "/path/to/file",
    "email":    "admin@example.com",
    "string":   "",
}

SECRET_TYPES = {"secret"}


def _guess_type(var_name):
    """Guess the type of an environment variable from its name."""
    for pattern, type_name in TYPE_HINTS:
        if pattern.match(var_name):
            return type_name
    return "string"


def _guess_group(var_name):
    """Guess a grouping category for the variable based on its prefix."""
    # Known group prefixes
    prefixes = [
        "DATABASE", "DB", "REDIS", "SMTP", "MAIL", "EMAIL",
        "AWS", "S3", "GCP", "AZURE", "DOCKER",
        "LOG", "SENTRY", "CELERY", "RABBIT", "KAFKA",
        "AUTH", "JWT", "OAUTH", "SESSION",
    ]
    upper = var_name.upper()
    for prefix in prefixes:
        if upper.startswith(prefix + "_") or upper == prefix:
            return prefix

    # Fall back to first segment before underscore
    parts = upper.split("_")
    if len(parts) > 1:
        return parts[0]
    return "APP"


def parse(findings):
    """Enrich raw scanner findings with type, example, grouping, and secret flag.

    Args:
        findings: List of dicts from scanner.scan().

    Returns:
        List of enriched variable dicts, deduplicated by variable name.
    """
    var_map = defaultdict(lambda: {"files": []})

    for finding in findings:
        var = finding["var"]
        location = "{}:{}".format(finding["file"], finding["line"])

        entry = var_map[var]
        entry["var"] = var
        if location not in entry["files"]:
            entry["files"].append(location)

    result = []
    for var, entry in var_map.items():
        var_type = _guess_type(var)
        entry["type"] = var_type
        entry["example"] = EXAMPLES.get(var_type, "")
        entry["group"] = _guess_group(var)
        entry["secret"] = var_type in SECRET_TYPES
        result.append(entry)

    # Sort: secrets first, then alphabetically
    result.sort(key=lambda e: (not e["secret"], e["group"], e["var"]))
    return result
