"""dotguard — Automatically generate documented .env.example files."""

__version__ = "0.1.0"
