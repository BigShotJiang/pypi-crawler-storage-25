"""Writes the .env.example file with comments and grouping."""

import os
from collections import OrderedDict


SEPARATOR = "# " + "\u2500" * 37


def _group_vars(variables):
    """Group variables into ordered sections. Secrets always come first."""
    secrets = []
    groups = OrderedDict()

    for var in variables:
        if var["secret"]:
            secrets.append(var)
        else:
            group_name = var["group"]
            if group_name not in groups:
                groups[group_name] = []
            groups[group_name].append(var)

    return secrets, groups


def _write_var_block(var):
    """Return lines for a single variable entry."""
    lines = []
    files_str = ", ".join(var["files"])
    lines.append("# Used in: {}".format(files_str))
    lines.append("{}={}".format(var["var"], var["example"]))
    return lines


def generate(variables, output_path=".env.example"):
    """Write a formatted .env.example file.

    Args:
        variables: Enriched variable list from parser.parse().
        output_path: Path to write the output file.

    Returns:
        The full text content that was written.
    """
    secrets, groups = _group_vars(variables)
    lines = []

    # Secrets section
    if secrets:
        lines.append(SEPARATOR)
        lines.append("# SECRETS  \u26a0\ufe0f  Never commit real values")
        lines.append(SEPARATOR)
        lines.append("")
        for var in secrets:
            lines.extend(_write_var_block(var))
            lines.append("")

    # Remaining groups
    for group_name, group_vars in groups.items():
        lines.append("")
        lines.append(SEPARATOR)
        lines.append("# {}".format(group_name.upper()))
        lines.append(SEPARATOR)
        lines.append("")
        for var in group_vars:
            lines.extend(_write_var_block(var))
            lines.append("")

    content = "\n".join(lines).rstrip() + "\n"

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(content)

    return content


def diff_env(env_path=".env", example_path=".env.example"):
    """Compare .env against .env.example and return missing/extra keys.

    Returns:
        Tuple of (missing_from_env, extra_in_env) — each a sorted list of var names.
    """
    def _read_keys(path):
        keys = set()
        if not os.path.isfile(path):
            return keys
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key = line.split("=", 1)[0].strip()
                    keys.add(key)
        return keys

    env_keys = _read_keys(env_path)
    example_keys = _read_keys(example_path)

    missing = sorted(example_keys - env_keys)
    extra = sorted(env_keys - example_keys)
    return missing, extra
