"""Command-line interface for dotguard."""

import argparse
import os
import sys

from dotguard.scanner import scan
from dotguard.parser import parse
from dotguard.writer import generate, diff_env


def _print_scan_summary(findings, variables, output_path):
    """Print a summary of the scan results."""
    # Count files scanned (unique files from findings)
    scanned_files = set()
    for f in findings:
        scanned_files.add(f["file"])

    secrets = [v for v in variables if v["secret"]]

    # Group counts
    from collections import Counter
    group_counts = Counter(v["group"] for v in variables if not v["secret"])

    print("")
    print("  \u2714 {} files contained env vars".format(len(scanned_files)))
    print("  \u2714 {} environment variables found".format(len(variables)))
    if secrets:
        secret_names = ", ".join(v["var"] for v in secrets)
        print("  \u26a0  {} secrets detected ({})".format(len(secrets), secret_names))
    print("  \u2714 {} written".format(output_path))
    print("")

    if group_counts or secrets:
        print("  Variables by group:")
        if secrets:
            bar = "\u2588" * min(len(secrets), 20)
            print("  SECRETS   {}  {} vars  \u26a0".format(bar, len(secrets)))
        for group, count in sorted(group_counts.items()):
            bar = "\u2588" * min(count, 20)
            print("  {:<9} {}  {} vars".format(group, bar, count))
        print("")


def cmd_scan(args):
    """Handle the 'scan' subcommand."""
    root = args.path
    output = args.output
    check_mode = args.check

    if not os.path.isdir(root):
        print("Error: '{}' is not a directory.".format(root), file=sys.stderr)
        return 1

    print("\U0001f50d Scanning {}...".format(os.path.abspath(root)))

    findings = scan(root)
    if not findings:
        print("\n  No environment variables found.")
        return 0

    variables = parse(findings)

    if check_mode:
        # CI mode: compare against existing .env.example
        example_path = os.path.join(root, ".env.example")
        if not os.path.isfile(example_path):
            print("\n  \u2717 No .env.example found — run 'dotguard scan' to generate one.")
            return 1

        # Read existing keys from .env.example
        existing_keys = set()
        with open(example_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    existing_keys.add(line.split("=", 1)[0].strip())

        found_keys = {v["var"] for v in variables}
        undocumented = sorted(found_keys - existing_keys)

        if undocumented:
            print("\n  \u2717 Undocumented environment variables found:")
            for var in undocumented:
                print("    - {}".format(var))
            print("\n  Run 'dotguard scan' to update .env.example.")
            return 1
        else:
            print("\n  \u2714 All environment variables are documented.")
            return 0

    # Normal mode: generate .env.example
    if not os.path.isabs(output):
        output = os.path.join(root, output)

    generate(variables, output_path=output)
    _print_scan_summary(findings, variables, output)
    return 0


def cmd_diff(args):
    """Handle the 'diff' subcommand."""
    root = args.path
    env_path = os.path.join(root, ".env")
    example_path = os.path.join(root, ".env.example")

    if not os.path.isfile(example_path):
        print("No .env.example found. Run 'dotguard scan' first.", file=sys.stderr)
        return 1

    missing, extra = diff_env(env_path, example_path)

    if not missing and not extra:
        print("\u2714 .env is in sync with .env.example")
        return 0

    if missing:
        print("\nMissing from .env (defined in .env.example):")
        for var in missing:
            print("  - {}".format(var))

    if extra:
        print("\nExtra in .env (not in .env.example):")
        for var in extra:
            print("  + {}".format(var))

    print("")
    return 1


def cmd_audit(args):
    """Handle the 'audit' subcommand."""
    root = args.path

    if not os.path.isdir(root):
        print("Error: '{}' is not a directory.".format(root), file=sys.stderr)
        return 1

    findings = scan(root)
    if not findings:
        print("No environment variables found.")
        return 0

    variables = parse(findings)

    print("\nEnvironment Variable Audit")
    print("=" * 50)

    for var in variables:
        flag = " \u26a0 SECRET" if var["secret"] else ""
        print("\n{} [{}]{}".format(var["var"], var["type"], flag))
        print("  Example: {}".format(var["example"] or "(none)"))
        print("  Used in:")
        for loc in var["files"]:
            print("    - {}".format(loc))

    print("\n{} variables total, {} secrets.\n".format(
        len(variables),
        sum(1 for v in variables if v["secret"]),
    ))
    return 0


def main():
    """Main entry point for the dotguard CLI."""
    parser = argparse.ArgumentParser(
        prog="dotguard",
        description="Automatically generate documented .env.example files.",
    )
    subparsers = parser.add_subparsers(dest="command")

    # scan
    scan_parser = subparsers.add_parser("scan", help="Scan project for env vars and generate .env.example")
    scan_parser.add_argument("path", nargs="?", default=".", help="Directory to scan (default: current directory)")
    scan_parser.add_argument("--output", "-o", default=".env.example", help="Output filename (default: .env.example)")
    scan_parser.add_argument("--check", action="store_true", help="CI mode: exit 1 if undocumented vars exist")

    # diff
    diff_parser = subparsers.add_parser("diff", help="Compare .env vs .env.example")
    diff_parser.add_argument("path", nargs="?", default=".", help="Project directory (default: current directory)")

    # audit
    audit_parser = subparsers.add_parser("audit", help="Show all vars, files, and flag secrets")
    audit_parser.add_argument("path", nargs="?", default=".", help="Directory to audit (default: current directory)")

    args = parser.parse_args()

    if args.command is None:
        parser.print_help()
        return 0

    commands = {
        "scan": cmd_scan,
        "diff": cmd_diff,
        "audit": cmd_audit,
    }

    return commands[args.command](args)


if __name__ == "__main__":
    sys.exit(main())
