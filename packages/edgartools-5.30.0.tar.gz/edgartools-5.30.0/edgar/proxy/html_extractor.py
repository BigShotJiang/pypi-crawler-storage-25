"""
HTML extraction from DEF 14A proxy statements.

Extracts structured data from proxy statement HTML where XBRL is not available.
Text-based extractors (proposals, pay ratio) use regex scanning on filing text.
Table-based extractors (SCT, ownership, director comp) use lxml DOM parsing on
a pre-parsed HTML tree shared via ProxyStatement._html_tree.

Lessons from edgartools-workers implementation (20-company eval):
- Proposals: 90% success rate (highest reliability)
- Section headers are NOT reliable DOM anchors alone — use two-pass heading finder
- Non-breaking spaces (\\u00a0) break regex — normalize first
- First occurrence of proposal text is often in TOC — retry later occurrences
"""

import logging
import re
from dataclasses import dataclass
from typing import Callable, List, Literal, Optional, Tuple

log = logging.getLogger(__name__)

__all__ = [
    'extract_voting_proposals', 'VotingProposal',
    'extract_ceo_pay_ratio', 'CEOPayRatio',
    'extract_summary_compensation', 'ExecutiveCompEntry',
    'extract_beneficial_ownership', 'BeneficialOwner',
    'extract_director_compensation', 'DirectorCompEntry',
    'extract_audit_fees', 'AuditFees',
]

# ── Types ────────────────────────────────────────────────────────────

ProposalType = Literal[
    'director_election',
    'say_on_pay',
    'say_on_pay_frequency',
    'auditor_ratification',
    'equity_plan',
    'shareholder_proposal',
    'company_proposal',
]


@dataclass(frozen=True)
class VotingProposal:
    """A single voting proposal from a proxy statement."""
    number: int
    description: str
    board_recommendation: Optional[str] = None  # 'FOR', 'AGAINST', 'ABSTAIN', or None
    proposal_type: ProposalType = 'company_proposal'


# ── Proposal type classification ─────────────────────────────────────

_PROPOSAL_TYPE_PATTERNS: list[tuple[re.Pattern, ProposalType]] = [
    (re.compile(r'elect(?:ion)?\s+(?:of\s+)?(?:\d+\s+)?director', re.I), 'director_election'),
    (re.compile(r'say[- ]on[- ]pay\s+frequency|frequency\s+of.*advisory\s+vote', re.I), 'say_on_pay_frequency'),
    (re.compile(r'say[- ]on[- ]pay|advisory\s+vote.*(?:executive\s+)?compensation|approve.*(?:executive\s+)?compensation', re.I), 'say_on_pay'),
    (re.compile(r'ratif(?:y|ication)\s+.*(?:account|audit|appoint)|appoint.*(?:account|audit)', re.I), 'auditor_ratification'),
    (re.compile(r'equity\s+(?:incentive\s+)?plan|stock\s+(?:incentive\s+)?plan|omnibus\s+incentive', re.I), 'equity_plan'),
    (re.compile(r'shareholder\s+proposal|stockholder\s+proposal', re.I), 'shareholder_proposal'),
]


def _classify_proposal(description: str) -> ProposalType:
    """Classify a proposal description into a type. Most specific patterns first."""
    for pattern, proposal_type in _PROPOSAL_TYPE_PATTERNS:
        if pattern.search(description):
            return proposal_type
    return 'company_proposal'


# ── Board recommendation extraction ──────────────────────────────────

_RECOMMENDATION_PATTERNS = [
    re.compile(r'board\s+(?:of\s+directors\s+)?recommends\s+(?:that\s+(?:you|shareholders?|stockholders?)\s+vote\s+|a\s+vote\s+)?["\u201c]?(FOR|AGAINST|ABSTAIN)\b', re.I),
    re.compile(r'(?:our|the)\s+board\s+recommends\s+["\u201c]?(FOR|AGAINST|ABSTAIN)\b', re.I),
    re.compile(r'recommendation[:\s]+["\u201c]?(FOR|AGAINST|ABSTAIN)\b', re.I),
    re.compile(r'vote\s+["\u201c]?(FOR|AGAINST|ABSTAIN)["\u201d]?\s+(?:this|the|each)\s+(?:proposal|nominee|director)', re.I),
    # Proxy card patterns — "FOR  Against  Abstain" column header followed by checkbox-like layout
    re.compile(r'\b(FOR)\s+Against\s+Abstain\b', re.I),
]


def _extract_recommendation(text: str) -> Optional[str]:
    """Extract board recommendation from text near a proposal heading."""
    # Normalize non-breaking spaces so \\s patterns match
    normalized = text.replace('\u00a0', ' ')
    for pattern in _RECOMMENDATION_PATTERNS:
        m = pattern.search(normalized)
        if m:
            return m.group(1).upper()
    return None


# ── Description cleaning ─────────────────────────────────────────────

def _clean_description(desc: str) -> str:
    """Clean raw proposal description text."""
    # Collapse multiple spaces
    desc = re.sub(r'\s{2,}', ' ', desc)
    # Remove trailing page numbers
    desc = re.sub(r'\s+\d{1,3}\s*$', '', desc)
    # Remove TOC dot leaders ("...... 42")
    desc = re.sub(r'\s*\.{2,}\s*\d+\s*$', '', desc)
    # Remove concatenated section numbers from TOC ("12Proposal", "38Executive")
    desc = re.sub(r'\d+Proposal\s+', '', desc, flags=re.I)
    # Clean concatenated page-number+word boundaries ("38Executive" → "Executive")
    desc = re.sub(r'\d+([A-Z][a-z])', r'\1', desc)

    desc = desc.strip()

    # Truncate at first natural sentence boundary if reasonable
    sentence_end = re.search(r'\.\s+[A-Z]', desc)
    if sentence_end and 20 < sentence_end.start() < 150:
        desc = desc[:sentence_end.start() + 1]

    # Hard truncate if still too long
    if len(desc) > 120:
        space_idx = desc.rfind(' ', 0, 120)
        desc = desc[:space_idx if space_idx > 40 else 120]

    return desc.strip()


# ── Main extraction function ─────────────────────────────────────────

# "Proposal 1", "Proposal No. 1", "PROPOSAL 1:", "Item 1", etc.
_PROPOSAL_PATTERN = re.compile(
    r'(?:proposal\s+(?:no\.?\s*)?|item\s+)(\d+)\s*[:\-\u2014\u2013.\s]+([^\n]{10,200})',
    re.I
)


def extract_voting_proposals(text: str) -> List[VotingProposal]:
    """
    Extract voting proposals from proxy statement text.

    Scans the full document text for "Proposal N" headings, extracts the
    description and board recommendation from surrounding context.
    Handles TOC vs body duplicates by retrying recommendation search
    across later occurrences of the same proposal.

    Args:
        text: Full text content of the proxy statement (from filing.text()
              or filing.markdown() or similar).

    Returns:
        List of VotingProposal, sorted by proposal number.
    """
    if not text:
        return []

    # Normalize whitespace: non-breaking spaces, zero-width spaces, and collapse runs
    text_normalized = text.replace('\u00a0', ' ').replace('\u200b', '').replace('\u200e', '')
    text_normalized = re.sub(r' {2,}', ' ', text_normalized)
    text_lower = text_normalized.lower()

    proposals: list[VotingProposal] = []
    seen_numbers: set[int] = set()
    seen_descriptions: set[str] = set()

    for match in _PROPOSAL_PATTERN.finditer(text_normalized):
        num = int(match.group(1))
        # Skip invalid: 0, already seen, or unreasonably high (page numbers in TOC)
        if not num or num in seen_numbers or num > 30:
            continue

        description = _clean_description(match.group(2))

        # Skip very short descriptions (likely TOC fragments)
        if len(description) < 15:
            continue

        # Skip descriptions that start with lowercase or connective words
        # (indicates mid-sentence match, not a heading)
        if description[0].islower() or re.match(r'^(?:was|is|are|has|the|a|an|and|or|but|requires?|shall|will|may)\s', description, re.I):
            # Try to find a better description from a later occurrence
            later_match = re.search(
                rf'proposal\s+(?:no\.?\s*)?{num}\s*[:\-\u2014\u2013.\s]+([^\n]{{15,200}})',
                text_normalized[match.end():],
                re.I
            )
            if later_match:
                description = _clean_description(later_match.group(1))
                if len(description) < 15 or description[0].islower():
                    continue
            else:
                continue

        # Skip duplicate descriptions (TOC + body both match)
        desc_key = description.lower()[:40]
        if desc_key in seen_descriptions:
            continue

        # Extract recommendation: search context after this match, and retry
        # at later occurrences (first match is often in TOC where recommendation
        # is absent — the actual recommendation is near the body section)
        recommendation = None
        search_pos = match.start()
        search_terms = [
            f'proposal {num}',
            f'proposal no. {num}',
            description.lower()[:30],
        ]

        for _attempt in range(4):
            context_end = min(len(text_normalized), search_pos + 5000)
            context = text_normalized[search_pos:context_end]
            recommendation = _extract_recommendation(context)
            if recommendation is not None:
                break

            # Find next occurrence for retry
            next_idx = -1
            for term in search_terms:
                idx = text_lower.find(term, search_pos + max(len(term), 10))
                if idx >= 0 and (next_idx < 0 or idx < next_idx):
                    next_idx = idx
            if next_idx < 0:
                break
            search_pos = next_idx

        seen_numbers.add(num)
        seen_descriptions.add(desc_key)
        proposals.append(VotingProposal(
            number=num,
            description=description,
            board_recommendation=recommendation,
            proposal_type=_classify_proposal(description),
        ))

    proposals.sort(key=lambda p: p.number)
    return proposals


# ══════════════════════════════════════════════════════════════════════
# CEO Pay Ratio Extractor
# ══════════════════════════════════════════════════════════════════════

@dataclass(frozen=True)
class CEOPayRatio:
    """CEO pay ratio disclosure data."""
    ceo_compensation: Optional[int] = None
    median_employee_compensation: Optional[int] = None
    ratio: Optional[int] = None


def _parse_dollar_amount(text: str) -> Optional[int]:
    """Parse a dollar amount, stripping trailing footnote superscripts.

    SEC filings often embed footnote references directly after numbers
    (e.g., "$40,644,7231" where the trailing "1" is a footnote).
    We detect this by checking if the last digits make the number
    implausibly large relative to the magnitude.
    """
    # Remove dollar sign, commas, spaces
    cleaned = text.replace('$', '').replace(',', '').replace(' ', '').strip()
    if not cleaned or not cleaned[0].isdigit():
        return None
    try:
        value = int(cleaned)
    except ValueError:
        return None

    # Heuristic for footnote superscripts: SEC filings embed footnote references
    # directly after numbers (e.g., "$40,644,7231" where trailing "1" is a footnote).
    # Individual compensation is virtually never above $200M, so if stripping
    # the last digit brings us into a reasonable range, do it.
    if value > 200_000_000 and len(cleaned) > 7:
        stripped = int(cleaned[:-1])
        if stripped < 200_000_000:
            return stripped

    return value


def _find_pay_ratio_section(text: str) -> Optional[str]:
    """Find the pay ratio section, skipping TOC entries.

    The first occurrence of "pay ratio" is usually in the Table of Contents.
    The real section has "median" nearby. We scan forward until we find one
    with substantive content.
    """
    text_lower = text.lower()
    pos = 0
    while True:
        idx = text_lower.find('pay ratio', pos)
        if idx < 0:
            return None
        section = text[idx:idx + 3000]
        if 'median' in section.lower():
            return section
        pos = idx + 10


# ── Ratio patterns ──────────────────────────────────────────────────

_RATIO_PATTERNS = [
    # "ratio of these amounts is 533 to 1", "ratio was approximately 480 to 1"
    re.compile(r'ratio\s+(?:of\s+(?:those|these)\s+amounts\s+)?(?:is|was)\s+(?:approximately\s+)?(\d[\d,]*)\s*(?:to|:)\s*1', re.I),
    # "ratio...480 to 1" (broader)
    re.compile(r'ratio\s+.*?(\d[\d,]*)\s*(?:to|:)\s*1', re.I),
    # "125:1" standalone
    re.compile(r'(\d[\d,]*)\s*:\s*1(?=[\s.,;)]|$)', re.I),
    # "588 times that of" (CBRL style)
    re.compile(r'(\d[\d,]*)\s+times\s+that\s+of', re.I),
    # AMZN inverted: "1-to-51", "ratio of those amounts of 1-to-51"
    re.compile(r'1\s*-\s*to\s*-?\s*(\d[\d,]*)', re.I),
]

# ── CEO compensation patterns ───────────────────────────────────────

_CEO_COMP_PATTERNS = [
    # "compensation of our CEO was $X", "compensation of Mr. Dimon was $X"
    re.compile(r'compensation\s+of\s+(?:our\s+)?(?:CEO|Mr\.\s+\w+|Ms\.\s+\w+)\s+was\s+\$([\d,]+)', re.I),
    # "annual total compensation of the CEO was $X" (PG style)
    re.compile(r'(?:annual\s+total\s+)?compensation\s+of\s+(?:the\s+|our\s+)?CEO\s+was\s+\$([\d,]+)', re.I),
    # "annual total CEO compensation...was $X" / "is $X"
    re.compile(r'(?:annual\s+total\s+)?CEO\s+compensation\s+.*?(?:was|is)\s+\$([\d,]+)', re.I),
    # "CEO total compensation  $X" (table format, PBPB style)
    re.compile(r'CEO\s+total\s+compensation\s+\$([\d,]+)', re.I),
    # "total compensation of our CEO was $X"
    re.compile(r'total\s+compensation\s+of\s+(?:our\s+)?(?:CEO|Chief\s+Executive\s+Officer)\s+was\s+\$([\d,]+)', re.I),
    # "Mr./Ms. Name's annual total compensation...was $X" (KO/ETSY/AMZN style)
    re.compile(r'(?:Mr\.|Ms\.)\s+\w+[\u2019\']?s?\s+(?:\d{4}\s+)?(?:annual\s+)?total\s+compensation.*?(?:was|is)\s+\$([\d,]+)', re.I),
    # "compensation of our CEO...was $X" (with intervening text)
    re.compile(r'compensation\s+of\s+(?:our\s+)?CEO.*?was\s+\$([\d,]+)', re.I),
    # "Chief Executive Officer...was $X"
    re.compile(r'Chief\s+Executive\s+Officer.*?(?:was|is)\s+\$([\d,]+)', re.I),
]

# ── Median employee compensation patterns ────────────────────────────

_MEDIAN_COMP_PATTERNS = [
    # "median compensated employee...was $X" — constrain gap to avoid matching CEO line
    re.compile(r'median\s+(?:compensated\s+)?employee\s+(?:\([^)]*\)\s+)?was\s+\$([\d,]+)', re.I),
    # "compensation of our median compensated employee was $X"
    re.compile(r'compensation\s+of\s+(?:our\s+)?(?:estimated\s+)?median\s+(?:compensated\s+)?employee\s+was\s+\$([\d,]+)', re.I),
    # "median of the annual total compensation of all employees...was $X"
    re.compile(r'median\s+(?:of\s+the\s+)?(?:annual\s+total\s+)?compensation\s+of\s+all\s+(?:other\s+)?employees.*?was\s+\$([\d,]+)', re.I),
    # "median annual total compensation of all employees...was $X"
    re.compile(r'median\s+annual\s+total\s+compensation\s+of\s+all\s+employees.*?was\s+\$([\d,]+)', re.I),
    # "Median employee total compensation $X" (table format)
    re.compile(r'[Mm]edian\s+employee\s+total\s+compensation\s+\$([\d,]+)', re.I),
    # "median-paid employee...was $X" (JNJ style)
    re.compile(r'median[- ]paid\s+employee.*?was\s+\$([\d,]+)', re.I),
    # "median crew member...was $X" (FIVE style)
    re.compile(r'median\s+crew\s+member.*?was\s+\$([\d,]+)', re.I),
    # Fallback: "median" near "$X" within ~100 chars
    re.compile(r'median\s+(?:\w+\s+){0,10}?\$([\d,]+)', re.I),
]


def extract_ceo_pay_ratio(text: str) -> Optional[CEOPayRatio]:
    """
    Extract CEO pay ratio from proxy statement text.

    Finds the pay ratio section (skipping TOC), then extracts:
    - CEO annual total compensation
    - Median employee annual total compensation
    - The ratio (e.g., 533 to 1)

    Returns None if no pay ratio section found. Returns CEOPayRatio
    with None fields for any values that couldn't be extracted.

    Args:
        text: Full text content of the proxy statement.
    """
    if not text:
        return None

    # Normalize whitespace
    text = text.replace('\u00a0', ' ').replace('\u200b', '')

    section = _find_pay_ratio_section(text)
    if not section:
        return None

    # Collapse whitespace to handle line breaks in mid-sentence
    section = ' '.join(section.split())

    # Extract ratio
    ratio = None
    for pattern in _RATIO_PATTERNS:
        m = pattern.search(section)
        if m:
            ratio = int(m.group(1).replace(',', ''))
            break

    # Extract CEO compensation
    ceo_comp = None
    for pattern in _CEO_COMP_PATTERNS:
        m = pattern.search(section)
        if m:
            ceo_comp = _parse_dollar_amount(m.group(1))
            break

    # Extract median employee compensation
    median_comp = None
    for pattern in _MEDIAN_COMP_PATTERNS:
        m = pattern.search(section)
        if m:
            median_comp = _parse_dollar_amount(m.group(1))
            break

    # Sanity check: CEO comp should always be larger than median employee comp.
    # If they're swapped or equal, fix the assignment.
    if ceo_comp is not None and median_comp is not None:
        if ceo_comp < median_comp:
            ceo_comp, median_comp = median_comp, ceo_comp
        elif ceo_comp == median_comp:
            # Both patterns matched the same value — try to find the other
            # by looking for all dollar amounts in the section
            amounts = sorted(set(
                int(m.replace(',', ''))
                for m in re.findall(r'\$([\d,]+)', section)
                if int(m.replace(',', '')) > 0
            ), reverse=True)
            if len(amounts) >= 2:
                ceo_comp = amounts[0]
                median_comp = amounts[1]

    # Cross-check against ratio to detect footnote contamination.
    # If ceo_comp / median_comp is ~10x the stated ratio, the median
    # likely has an embedded footnote digit (e.g., $111,9052 → $1,119,052
    # when it should be $111,905).
    if ratio and ceo_comp and median_comp and median_comp > 0:
        computed_ratio = ceo_comp / median_comp
        if computed_ratio > 0 and (computed_ratio / ratio > 5 or ratio / computed_ratio > 5):
            # The ratio is way off — try stripping last digit from median
            median_stripped = int(str(median_comp)[:-1]) if median_comp > 10 else median_comp
            if median_stripped > 0:
                stripped_ratio = ceo_comp / median_stripped
                if 0.5 < stripped_ratio / ratio < 2.0:
                    median_comp = median_stripped

    return CEOPayRatio(
        ceo_compensation=ceo_comp,
        median_employee_compensation=median_comp,
        ratio=ratio,
    )


# ══════════════════════════════════════════════════════════════════════
# Summary Compensation Table Extractor
# ══════════════════════════════════════════════════════════════════════

@dataclass(frozen=True)
class ExecutiveCompEntry:
    """One row of the Summary Compensation Table (one executive, one year)."""
    name: str
    title: str
    year: int
    salary: Optional[int] = None
    bonus: Optional[int] = None
    stock_awards: Optional[int] = None
    option_awards: Optional[int] = None
    non_equity_incentive: Optional[int] = None
    pension_change: Optional[int] = None
    other_compensation: Optional[int] = None
    total: Optional[int] = None


# ── Column classification ────────────────────────────────────────────

_SCT_COLUMN_PATTERNS: list[tuple[str, re.Pattern]] = [
    ('name', re.compile(r'name|principal\s+position', re.I)),
    ('year', re.compile(r'\byear\b', re.I)),
    ('stock_awards', re.compile(r'stock\s+award', re.I)),
    ('option_awards', re.compile(r'option\s+award', re.I)),
    ('non_equity_incentive', re.compile(r'non[- ]equity|incentive\s+plan', re.I)),
    ('pension_change', re.compile(r'pension|nqdc|nonqualified\s+deferred|change\s+in\s+pension', re.I)),
    ('other_compensation', re.compile(r'all\s+other|other\s+comp', re.I)),
    ('total', re.compile(r'\btotal\b', re.I)),
    ('salary', re.compile(r'\bsalary\b', re.I)),
    ('bonus', re.compile(r'\bbonus\b', re.I)),
]


def _classify_sct_column(header: str) -> Optional[str]:
    """Classify a column header to a compensation field. Most specific first."""
    for col_name, pattern in _SCT_COLUMN_PATTERNS:
        if pattern.search(header):
            return col_name
    return None


# ── Dollar parsing for table cells ───────────────────────────────────

_FOOTNOTE_RE = re.compile(r'(?:\(\d+\))+\s*$')
_STAR_RE = re.compile(r'\*+\s*$')
_DASH_RE = re.compile(r'^[\s\u2014\u2013\u2015\u2012\u2212\-]+$')
_ZERO_WIDTH_RE = re.compile(r'[\u200b\u00ad\ufeff]')


def _parse_comp_dollar(text: str) -> Optional[int]:
    """Parse a dollar amount from an SCT cell. Returns None for dashes/empty."""
    # Strip footnotes and zero-width chars
    cleaned = _FOOTNOTE_RE.sub('', text)
    cleaned = _STAR_RE.sub('', cleaned)
    cleaned = _ZERO_WIDTH_RE.sub('', cleaned).strip()
    if not cleaned or _DASH_RE.match(cleaned):
        return None

    # Handle accounting negatives: (1,234)
    negative = False
    if cleaned.startswith('(') and cleaned.endswith(')'):
        cleaned = cleaned[1:-1]
        negative = True

    # Remove $, commas, spaces
    cleaned = cleaned.replace('$', '').replace(',', '').replace(' ', '').strip()
    if not cleaned:
        return None

    try:
        value = round(float(cleaned))
        return -value if negative else value
    except ValueError:
        return None


# ── Name/title splitting ─────────────────────────────────────────────

_TITLE_KEYWORDS = [
    'officer', 'president', 'chairman', 'director', 'counsel', 'secretary',
    'treasurer', 'controller', 'ceo', 'cfo', 'coo', 'cto', 'clo', 'svp', 'evp',
    'vice president', 'general counsel', 'chief',
]

_TITLE_ABBREVIATIONS = {
    'chief executive officer': 'CEO',
    'chief financial officer': 'CFO',
    'chief operating officer': 'COO',
    'chief technology officer': 'CTO',
    'president and chief executive officer': 'President & CEO',
    'executive vice president': 'EVP',
    'senior vice president': 'SVP',
    'general counsel': 'General Counsel',
    'principal executive officer': 'PEO',
    'principal financial officer': 'PFO',
}


def _split_name_title(cell: str) -> tuple[str, str]:
    """Split 'Tim Cook, Chief Executive Officer' → ('Tim Cook', 'CEO')."""
    # Normalize whitespace
    cell = cell.replace('\xa0', ' ').replace('\u200b', '').strip()
    cell = re.sub(r'\s+', ' ', cell)

    # Try splitting on comma or newline
    for sep in [',', '\n']:
        idx = cell.find(sep)
        if idx == -1:
            continue
        before = cell[:idx].strip()
        after = cell[idx + 1:].strip()
        after_lower = after.lower()
        if any(kw in after_lower for kw in _TITLE_KEYWORDS) and before:
            # Abbreviate title
            for full, abbrev in sorted(_TITLE_ABBREVIATIONS.items(), key=lambda x: -len(x[0])):
                if full in after_lower:
                    return before, abbrev
            return before, after

    # No separator — check if title is concatenated (common in SEC filings)
    # "Tim CookChief Executive Officer" → split at case boundary before title keyword
    for kw in ['Chief ', 'President', 'Senior Vice', 'Executive Vice', 'General Counsel']:
        idx = cell.find(kw)
        if idx > 3:
            name = cell[:idx].strip()
            title_text = cell[idx:].strip()
            title_lower = title_text.lower()
            for full, abbrev in sorted(_TITLE_ABBREVIATIONS.items(), key=lambda x: -len(x[0])):
                if full in title_lower:
                    return name, abbrev
            return name, title_text

    return cell, ''




# ══════════════════════════════════════════════════════════════════════
# Shared lxml-based table extraction utilities
# ══════════════════════════════════════════════════════════════════════

_HEADING_TAGS = {'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p', 'div', 'span'}


def _is_inside_table(el) -> bool:
    """Check if an lxml element is inside a <table>."""
    parent = el.getparent()
    while parent is not None:
        if parent.tag == 'table':
            return True
        parent = parent.getparent()
    return False


def _is_inside_link(el) -> bool:
    """Check if an lxml element is inside an <a> tag."""
    if el.tag == 'a':
        return True
    parent = el.getparent()
    while parent is not None:
        if parent.tag == 'a':
            return True
        parent = parent.getparent()
    return False


def _iter_following_tables(el, limit: int = 10):
    """Yield up to `limit` <table> elements following `el` in document order.

    Uses XPath following::table to find tables anywhere after the element,
    regardless of nesting level.
    """
    try:
        tables = el.xpath('following::table')
        for table in tables[:limit]:
            yield table
    except Exception:
        # Fallback: walk siblings and their descendants
        count = 0
        for following in el.itersiblings():
            if following.tag == 'table':
                yield following
                count += 1
                if count >= limit:
                    return
            for desc in following.iter('table'):
                yield desc
                count += 1
                if count >= limit:
                    return


def _extract_table_grid(table_el) -> list[list[str]]:
    """Extract a 2D text grid from an lxml <table>, expanding colspan."""
    grid = []
    for tr in table_el.iter('tr'):
        row_data = []
        for cell in tr:
            if cell.tag not in ('td', 'th'):
                continue
            text = (cell.text_content() or '').strip()
            text = _ZERO_WIDTH_RE.sub('', text).strip()
            colspan_str = cell.get('colspan', '1') or '1'
            colspan = int(colspan_str) if colspan_str.isdigit() else 1
            row_data.append(text)
            for _ in range(colspan - 1):
                row_data.append('')
        grid.append(row_data)
    return grid


def _split_header_data(
    grid: list[list[str]],
    header_keywords: Optional[list[str]] = None,
) -> Tuple[list[str], list[list[str]]]:
    """Split a grid into header row and data rows."""
    if not grid:
        return [], []

    header_row_idx = -1
    if header_keywords:
        for i, row in enumerate(grid[:4]):
            row_text = ' '.join(row).lower()
            matches = sum(1 for kw in header_keywords if kw in row_text)
            if matches >= 2:
                header_row_idx = i
                break

    if header_row_idx < 0:
        for i, row in enumerate(grid[:4]):
            non_empty = [c for c in row if c]
            if len(non_empty) >= 3:
                header_row_idx = i
                break

    if header_row_idx < 0:
        return [], grid

    return grid[header_row_idx], grid[header_row_idx + 1:]


def _find_section_table(
    tree,
    heading_anchors: list[str],
    heading_rejects: list[str],
    table_scorer: Callable[[str], Tuple[int, bool]],
    max_tables: int = 10,
):
    """Find a table in a named section of a proxy statement using lxml.

    Two-pass heading finder: pass 1 outside tables, pass 2 inside tables.
    Then scores subsequent tables using the provided scorer function.

    Args:
        tree: Pre-parsed lxml HTML tree (from ProxyStatement._html_tree).
        heading_anchors: Anchor strings to match in heading text (lowercase).
        heading_rejects: Reject strings — skip headings containing these.
        table_scorer: Function(header_text) -> (score, is_valid).
        max_tables: Maximum tables to examine after heading.

    Returns:
        lxml table element, or None.
    """
    if tree is None:
        return None

    heading_el = None
    for allow_in_table in [False, True]:
        for el in tree.iter():
            if el.tag not in _HEADING_TAGS:
                continue
            text = (el.text_content() or '').strip()
            if not text or len(text) > 150:
                continue
            text_lower = text.lower()

            if not any(anchor in text_lower for anchor in heading_anchors):
                continue
            if any(reject in text_lower for reject in heading_rejects):
                continue
            if _is_inside_link(el):
                continue

            in_table = _is_inside_table(el)
            if not allow_in_table and in_table:
                continue
            if allow_in_table and in_table:
                if re.search(r'\d{2,3}\s*$', text):
                    continue
                if '.....' in text:
                    continue

            heading_el = el
            break
        if heading_el is not None:
            break

    if heading_el is None:
        return None

    candidates = []
    for table_el in _iter_following_tables(heading_el, limit=max_tables):
        trs = list(table_el.iter('tr'))
        if len(trs) < 3:
            continue

        all_cells = []
        for tr in trs[:3]:
            for cell in tr:
                if cell.tag in ('td', 'th'):
                    text = (cell.text_content() or '').strip()
                    if text and len(text) > 1:
                        all_cells.append(text)

        header_text = ' '.join(all_cells).lower()
        score, is_valid = table_scorer(header_text)
        if is_valid:
            candidates.append((table_el, score, len(trs)))

    if not candidates:
        return None

    candidates.sort(key=lambda x: (x[1], x[2]), reverse=True)
    return candidates[0][0]


def _build_column_map(
    headers: list[str],
    data_rows: list[list[str]],
    classifier: Callable[[str], Optional[str]],
    min_columns: int = 3,
) -> dict[str, int]:
    """Build a column index map from headers, with data-row fallback."""
    col_map: dict[str, int] = {}
    for i, header in enumerate(headers):
        col_type = classifier(header)
        if col_type:
            col_map[col_type] = i

    if len(col_map) < min_columns:
        for row in data_rows[:2]:
            for i, cell in enumerate(row):
                col_type = classifier(cell)
                if col_type and col_type not in col_map:
                    col_map[col_type] = i

    return col_map


def _get_dollar_from_row(row: list[str], col_map: dict[str, int], col_name: str) -> Optional[int]:
    """Get a dollar value from a row, handling split-cell patterns."""
    idx = col_map.get(col_name, -1)
    if idx < 0 or idx >= len(row):
        return None
    val = _parse_comp_dollar(row[idx])
    if val is not None:
        return val
    if row[idx].strip() == '$' and idx + 1 < len(row):
        return _parse_comp_dollar('$' + row[idx + 1])
    if not row[idx].strip() and idx + 1 < len(row):
        return _parse_comp_dollar(row[idx + 1])
    return None


# ── SCT table scorer ────────────────────────────────────────────────

def _score_sct_table(header_text: str) -> Tuple[int, bool]:
    score = 0
    has_salary = 'salary' in header_text
    if has_salary: score += 3
    if 'total' in header_text: score += 2
    if 'year' in header_text: score += 1
    if 'stock' in header_text and 'award' in header_text: score += 2
    if 'name' in header_text or 'principal' in header_text: score += 1
    if 'bonus' in header_text: score += 1
    if 'option' in header_text: score += 1
    if 'fees earned' in header_text or 'fees paid' in header_text:
        score = 0; has_salary = False
    return score, (score >= 4 and has_salary)


def extract_summary_compensation(tree) -> Optional[List[ExecutiveCompEntry]]:
    """Extract Summary Compensation Table from a pre-parsed lxml HTML tree."""
    if tree is None:
        return None

    table_el = _find_section_table(
        tree, ['summary compensation table'], [], _score_sct_table)
    if table_el is None:
        return None

    grid = _extract_table_grid(table_el)
    headers, data_rows = _split_header_data(
        grid, header_keywords=['salary', 'total', 'year', 'name'])
    if not data_rows:
        return None

    col_map = _build_column_map(headers, data_rows, _classify_sct_column, min_columns=4)
    if len(col_map) < 4:
        return None

    name_col = col_map.get('name', 0)
    year_col = col_map.get('year', -1)

    entries: list[ExecutiveCompEntry] = []
    current_name = ''
    current_title = ''

    for row in data_rows:
        if name_col < len(row) and row[name_col]:
            cell_text = row[name_col]
            if cell_text and not cell_text.startswith('(') and len(cell_text) > 2:
                name, title = _split_name_title(cell_text)
                if name and not any(kw in name.lower() for kw in ['total', 'footnote', 'note']):
                    current_name = name
                    current_title = title

        year = 0
        if 0 <= year_col < len(row):
            try:
                year = int(re.sub(r'[^\d]', '', row[year_col])[:4])
            except (ValueError, IndexError):
                pass
            if (not year or year < 2000) and year_col + 1 < len(row):
                try:
                    year = int(re.sub(r'[^\d]', '', row[year_col + 1])[:4])
                except (ValueError, IndexError):
                    pass

        if not year or year < 2000 or year > 2100:
            continue
        if not current_name:
            continue

        entries.append(ExecutiveCompEntry(
            name=current_name, title=current_title, year=year,
            salary=_get_dollar_from_row(row, col_map, 'salary'),
            bonus=_get_dollar_from_row(row, col_map, 'bonus'),
            stock_awards=_get_dollar_from_row(row, col_map, 'stock_awards'),
            option_awards=_get_dollar_from_row(row, col_map, 'option_awards'),
            non_equity_incentive=_get_dollar_from_row(row, col_map, 'non_equity_incentive'),
            pension_change=_get_dollar_from_row(row, col_map, 'pension_change'),
            other_compensation=_get_dollar_from_row(row, col_map, 'other_compensation'),
            total=_get_dollar_from_row(row, col_map, 'total'),
        ))

    return entries if entries else None


# ══════════════════════════════════════════════════════════════════════
# Beneficial Ownership Table Extractor
# ══════════════════════════════════════════════════════════════════════

@dataclass(frozen=True)
class BeneficialOwner:
    """One row of the beneficial ownership table."""
    name: str
    holder_type: str  # '5pct_holder', 'director_officer', or 'group'
    shares: Optional[int] = None
    percent_of_class: Optional[float] = None


_OWNERSHIP_COLUMN_PATTERNS: list[tuple[str, re.Pattern]] = [
    ('name', re.compile(r'name|beneficial\s+owner', re.I)),
    ('shares', re.compile(r'\bshare|\bnumber\b|\bamount\b', re.I)),
    ('percent', re.compile(r'percent|%\s*of|of\s+class', re.I)),
]

def _classify_ownership_column(header: str) -> Optional[str]:
    for col_name, pattern in _OWNERSHIP_COLUMN_PATTERNS:
        if pattern.search(header):
            return col_name
    return None

def _parse_shares(text: str) -> Optional[int]:
    cleaned = _FOOTNOTE_RE.sub('', text)
    cleaned = _STAR_RE.sub('', cleaned)
    cleaned = _ZERO_WIDTH_RE.sub('', cleaned).strip()
    if not cleaned or _DASH_RE.match(cleaned):
        return None
    cleaned = cleaned.replace(',', '').replace('$', '').replace(' ', '')
    try:
        return int(cleaned)
    except ValueError:
        return None

def _parse_percent(text: str) -> Optional[float]:
    raw = text.strip()
    if not raw or _DASH_RE.match(raw):
        return None
    if re.search(r'less\s+than\s+1\s*%', raw, re.I) or raw == '*':
        return 0.5
    cleaned = _FOOTNOTE_RE.sub('', raw)
    cleaned = _ZERO_WIDTH_RE.sub('', cleaned).strip()
    if not cleaned:
        return None
    cleaned = cleaned.replace('%', '').replace(',', '').strip()
    try:
        return float(cleaned)
    except ValueError:
        return None

_GROUP_RE = re.compile(
    r'directors?\s+and\s+(?:executive\s+)?officers?|'
    r'all\s+(?:named\s+)?executive\s+officers?\s+and\s+directors?|'
    r'as\s+a\s+group', re.I)

_SECTION_HEADER_RE = re.compile(
    r'^(?:named\s+executive\s+officers?|'
    r'directors?\s+(?:and|&)\s+(?:director\s+)?nominees?|'
    r'5%\s+(?:stock)?holders?|'
    r'beneficial\s+owners?\s+of\s+5%|'
    r'principal\s+(?:stock)?holders?)', re.I)

_OWNERSHIP_HEADING_ANCHORS = [
    'security ownership of certain beneficial owners',
    'security ownership of certain',
    'stock ownership of certain beneficial owners',
    'beneficial ownership of common stock',
    'beneficial ownership of shares',
    'principal shareholders', 'principal shareowners',
    'stock ownership information',
    'director and executive officer stock ownership',
    'security ownership of management',
    'beneficial ownership',
]
_OWNERSHIP_HEADING_REJECTS = ['guidelines', 'requirements', 'policy', 'robust']

def _score_ownership_table(header_text: str) -> Tuple[int, bool]:
    score = 0
    if 'name' in header_text or 'beneficial owner' in header_text: score += 2
    if 'share' in header_text or 'amount' in header_text or 'number' in header_text: score += 2
    if 'percent' in header_text or '% of' in header_text or 'of class' in header_text: score += 2
    if 'beneficially owned' in header_text: score += 1
    return score, score >= 3

def _parse_with_adjacent(row: list[str], col: int, parser) -> Optional:
    if col < 0 or col >= len(row):
        return None
    val = parser(row[col])
    if val is not None:
        return val
    if col + 1 < len(row):
        return parser(row[col + 1])
    return None


def extract_beneficial_ownership(tree) -> Optional[List[BeneficialOwner]]:
    """Extract beneficial ownership table from a pre-parsed lxml HTML tree."""
    if tree is None:
        return None

    table_el = _find_section_table(
        tree, _OWNERSHIP_HEADING_ANCHORS, _OWNERSHIP_HEADING_REJECTS, _score_ownership_table)
    if table_el is None:
        return None

    grid = _extract_table_grid(table_el)
    headers, data_rows = _split_header_data(grid)
    if not data_rows:
        return None

    col_map = _build_column_map(headers, data_rows, _classify_ownership_column, min_columns=2)
    name_col = col_map.get('name', 0)
    shares_col = col_map.get('shares', -1)
    percent_col = col_map.get('percent', -1)

    if shares_col < 0 and percent_col < 0:
        return None

    owners: list[BeneficialOwner] = []
    current_section = '5pct'

    for row in data_rows:
        if name_col >= len(row):
            continue
        name_cell = _ZERO_WIDTH_RE.sub('', row[name_col]).strip()
        name_cell = _FOOTNOTE_RE.sub('', name_cell).strip()
        if not name_cell or len(name_cell) < 2:
            continue

        if _SECTION_HEADER_RE.match(name_cell):
            if re.search(r'director|officer|nominee|executive', name_cell, re.I):
                current_section = 'insider'
            continue

        if _GROUP_RE.search(name_cell):
            shares = _parse_with_adjacent(row, shares_col, _parse_shares) if shares_col >= 0 else None
            pct = _parse_with_adjacent(row, percent_col, _parse_percent) if percent_col >= 0 else None
            if shares is not None or pct is not None:
                owners.append(BeneficialOwner(name=name_cell, holder_type='group', shares=shares, percent_of_class=pct))
            continue

        shares = _parse_with_adjacent(row, shares_col, _parse_shares) if shares_col >= 0 else None
        pct = _parse_with_adjacent(row, percent_col, _parse_percent) if percent_col >= 0 else None
        if shares is None and pct is None:
            continue

        if current_section == '5pct' and pct is not None and pct >= 5:
            holder_type = '5pct_holder'
        elif current_section == 'insider':
            holder_type = 'director_officer'
        elif pct is not None and pct < 5:
            holder_type = 'director_officer'
            current_section = 'insider'
        elif pct is None and any(o.holder_type == '5pct_holder' for o in owners):
            holder_type = 'director_officer'
            current_section = 'insider'
        else:
            holder_type = '5pct_holder'

        owners.append(BeneficialOwner(name=name_cell, holder_type=holder_type, shares=shares, percent_of_class=pct))

    return owners if owners else None


# ══════════════════════════════════════════════════════════════════════
# Director Compensation Table Extractor
# ══════════════════════════════════════════════════════════════════════

@dataclass(frozen=True)
class DirectorCompEntry:
    """One row of the Director Compensation Table (one non-employee director)."""
    name: str
    fees_earned: Optional[int] = None
    stock_awards: Optional[int] = None
    option_awards: Optional[int] = None
    non_equity_incentive: Optional[int] = None
    pension_change: Optional[int] = None
    other_compensation: Optional[int] = None
    total: Optional[int] = None


_DIR_COMP_COLUMN_PATTERNS: list[tuple[str, re.Pattern]] = [
    ('name', re.compile(r'name|director', re.I)),
    ('stock_awards', re.compile(r'stock\s+award', re.I)),
    ('option_awards', re.compile(r'option\s+award', re.I)),
    ('non_equity_incentive', re.compile(r'non[- ]equity|incentive\s+plan', re.I)),
    ('pension_change', re.compile(r'pension|nqdc|nonqualified\s+deferred|change\s+in\s+pension', re.I)),
    ('other_compensation', re.compile(r'all\s+other|other\s+comp', re.I)),
    ('total', re.compile(r'\btotal\b', re.I)),
    ('fees_earned', re.compile(r'fees?\s+earned|fees?\s+paid|retainer', re.I)),
]

def _classify_dir_comp_column(header: str) -> Optional[str]:
    for col_name, pattern in _DIR_COMP_COLUMN_PATTERNS:
        if pattern.search(header):
            return col_name
    return None

_DIR_COMP_HEADING_ANCHORS = [
    'director compensation table',
    'director compensation\u2014',
    'director compensation -',
    'director compensation for',
    'director compensation',
]
_DIR_COMP_HEADING_REJECTS = [
    'discussion', 'analysis', 'committee', 'program', 'philosophy',
    'process', 'overview', 'policy', 'guidelines',
]

def _score_dir_comp_table(header_text: str) -> Tuple[int, bool]:
    score = 0
    has_fees = 'fees' in header_text or 'retainer' in header_text
    if has_fees: score += 3
    if 'total' in header_text: score += 2
    if 'stock' in header_text and 'award' in header_text: score += 2
    if 'name' in header_text: score += 1
    if 'option' in header_text: score += 1
    if 'salary' in header_text:
        score = 0; has_fees = False
    return score, (score >= 3 and has_fees)


def extract_director_compensation(tree) -> Optional[List[DirectorCompEntry]]:
    """Extract Director Compensation Table from a pre-parsed lxml HTML tree."""
    if tree is None:
        return None

    table_el = _find_section_table(
        tree, _DIR_COMP_HEADING_ANCHORS, _DIR_COMP_HEADING_REJECTS, _score_dir_comp_table)
    if table_el is None:
        return None

    grid = _extract_table_grid(table_el)
    headers, data_rows = _split_header_data(grid)
    if not data_rows:
        return None

    col_map = _build_column_map(headers, data_rows, _classify_dir_comp_column, min_columns=3)
    if len(col_map) < 3:
        return None

    name_col = col_map.get('name', 0)
    entries: list[DirectorCompEntry] = []

    for row in data_rows:
        if name_col >= len(row):
            continue
        name_cell = _ZERO_WIDTH_RE.sub('', row[name_col]).replace('\xa0', ' ').strip()
        name_cell = _FOOTNOTE_RE.sub('', name_cell).strip()
        if not name_cell or len(name_cell) < 2:
            continue
        if any(kw in name_cell.lower() for kw in ['total', 'footnote', 'note', '(1)', '(2)']):
            continue

        fees = _get_dollar_from_row(row, col_map, 'fees_earned')
        stock = _get_dollar_from_row(row, col_map, 'stock_awards')
        total = _get_dollar_from_row(row, col_map, 'total')
        if fees is None and stock is None and total is None:
            continue

        entries.append(DirectorCompEntry(
            name=name_cell, fees_earned=fees, stock_awards=stock,
            option_awards=_get_dollar_from_row(row, col_map, 'option_awards'),
            non_equity_incentive=_get_dollar_from_row(row, col_map, 'non_equity_incentive'),
            pension_change=_get_dollar_from_row(row, col_map, 'pension_change'),
            other_compensation=_get_dollar_from_row(row, col_map, 'other_compensation'),
            total=total,
        ))

    return entries if entries else None


# ══════════════════════════════════════════════════════════════════════
# Audit Fees Extractor
# ══════════════════════════════════════════════════════════════════════

@dataclass(frozen=True)
class AuditFees:
    """Audit fee disclosure data."""
    auditor_name: str = ''
    current_year: int = 0
    prior_year: int = 0
    audit_fees_current: Optional[int] = None
    audit_fees_prior: Optional[int] = None
    audit_related_current: Optional[int] = None
    audit_related_prior: Optional[int] = None
    tax_fees_current: Optional[int] = None
    tax_fees_prior: Optional[int] = None
    other_fees_current: Optional[int] = None
    other_fees_prior: Optional[int] = None
    total_current: Optional[int] = None
    total_prior: Optional[int] = None


def _classify_fee_row(label: str) -> Optional[str]:
    """Classify a fee table row label. Most specific first."""
    lc = label.lower()
    if re.search(r'audit[- ]related', lc):
        return 'audit_related'
    if re.search(r'total|aggregate', lc):
        return 'total'
    if 'tax' in lc:
        return 'tax'
    if re.search(r'(?:all\s+)?other', lc) and 'audit' not in lc:
        return 'other'
    if 'audit' in lc and 'non-audit' not in lc:
        return 'audit'
    return None


_YEAR_RE = re.compile(r'\b(20\d{2})\b')


def _detect_year_columns(grid: list[list[str]]) -> Optional[tuple[int, int, int, int]]:
    """Detect year columns. Returns (current_col, prior_col, current_year, prior_year)."""
    for row in grid[:3]:
        year_map: dict[int, int] = {}
        for i, cell in enumerate(row):
            m = _YEAR_RE.search(cell)
            if m:
                year = int(m.group(1))
                if year not in year_map:
                    year_map[year] = i
        if len(year_map) >= 2:
            sorted_years = sorted(year_map.items(), key=lambda x: -x[0])
            current_year, current_col = sorted_years[0]
            prior_year, prior_col = sorted_years[1]
            current_col = _find_data_col(current_col, grid)
            prior_col = _find_data_col(prior_col, grid)
            return current_col, prior_col, current_year, prior_year
    return None


def _find_data_col(year_col: int, grid: list[list[str]]) -> int:
    """Find the column with actual numeric data near a year header column."""
    for offset in [0, 1, 2, -1, 3]:
        col = year_col + offset
        if col < 0:
            continue
        for row in grid:
            if col < len(row):
                val = row[col].strip()
                if val and val not in ('\u200b', '$') and _parse_comp_dollar(val) is not None:
                    return col
    return year_col


_THOUSANDS_RE = re.compile(r'\bin\s+thousands\b', re.I)
_MILLIONS_RE = re.compile(r'\bin\s+millions\b', re.I)


def _detect_multiplier(text: str) -> int:
    if _THOUSANDS_RE.search(text):
        return 1000
    if _MILLIONS_RE.search(text):
        return 1_000_000
    return 1


_AUDITOR_PATTERNS = [
    re.compile(r'fees\s+(?:billed|paid|charged)\s+(?:by|to)\s+([A-Z][A-Za-z &,.\']+?(?:LLP|LLC|Inc\.|P\.?C\.?|PLLC|LP))', re.I),
    re.compile(r'(?:appointed|engaged|retained|selected)\s+([A-Z][A-Za-z &,.\']+?(?:LLP|LLC|Inc\.|P\.?C\.?|PLLC|LP))', re.I),
    re.compile(r'([A-Z][A-Za-z &,.\']+?(?:LLP|LLC|Inc\.|P\.?C\.?|PLLC|LP))\s*,?\s*(?:our|the|has|was|is)\s+(?:independent|principal)', re.I),
]


def _extract_auditor_name(text: str) -> str:
    for pattern in _AUDITOR_PATTERNS:
        m = pattern.search(text)
        if m:
            return m.group(1).strip()
    return ''


_AUDIT_HEADING_ANCHORS = [
    'audit fees',
    'fees paid to auditor',
    'fees billed by',
    'fees paid to',
    'principal accountant fees',
    'audit and non-audit fees',
]
_AUDIT_HEADING_REJECTS = ['pre-approval', 'committee report']


def _score_audit_table(header_text: str) -> Tuple[int, bool]:
    score = 0
    if bool(_YEAR_RE.search(header_text)):
        score += 3
    if 'audit' in header_text:
        score += 2
    if 'total' in header_text:
        score += 1
    if 'tax' in header_text:
        score += 1
    return score, score >= 3


def extract_audit_fees(tree) -> Optional[AuditFees]:
    """Extract audit fees from a pre-parsed lxml HTML tree."""
    if tree is None:
        return None

    table_el = _find_section_table(
        tree, _AUDIT_HEADING_ANCHORS, _AUDIT_HEADING_REJECTS, _score_audit_table)
    if table_el is None:
        return None

    grid = _extract_table_grid(table_el)
    if not grid or len(grid) < 3:
        return None

    year_info = _detect_year_columns(grid)
    if year_info is None:
        return None

    current_col, prior_col, current_year, prior_year = year_info

    # Detect multiplier from surrounding text
    parent = table_el.getparent()
    context_text = (parent.text_content() or '') if parent is not None else ''
    multiplier = _detect_multiplier(context_text[:2000])

    fees: dict[str, tuple[Optional[int], Optional[int]]] = {}
    for row in grid:
        if not row:
            continue
        label = row[0] if row else ''
        category = _classify_fee_row(label)
        if not category:
            continue

        current_val = _parse_comp_dollar(row[current_col]) if current_col < len(row) else None
        prior_val = _parse_comp_dollar(row[prior_col]) if prior_col < len(row) else None

        if multiplier != 1:
            if current_val is not None:
                current_val = round(current_val * multiplier)
            if prior_val is not None:
                prior_val = round(prior_val * multiplier)

        fees[category] = (current_val, prior_val)

    if not fees:
        return None

    auditor_name = _extract_auditor_name(context_text[:3000])

    return AuditFees(
        auditor_name=auditor_name,
        current_year=current_year, prior_year=prior_year,
        audit_fees_current=fees.get('audit', (None, None))[0],
        audit_fees_prior=fees.get('audit', (None, None))[1],
        audit_related_current=fees.get('audit_related', (None, None))[0],
        audit_related_prior=fees.get('audit_related', (None, None))[1],
        tax_fees_current=fees.get('tax', (None, None))[0],
        tax_fees_prior=fees.get('tax', (None, None))[1],
        other_fees_current=fees.get('other', (None, None))[0],
        other_fees_prior=fees.get('other', (None, None))[1],
        total_current=fees.get('total', (None, None))[0],
        total_prior=fees.get('total', (None, None))[1],
    )
