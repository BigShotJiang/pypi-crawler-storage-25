"""
Data classes for the Entity package.

This module contains classes for working with entity data, including
addresses, facts, and other structured data from SEC filings.
"""
import re
from functools import cached_property
from typing import Any, Dict, List, Optional, Tuple, Union

import pyarrow as pa
import pyarrow.compute as pc

from edgar.core import listify, log
from edgar.dates import InvalidDateException
from edgar.entity.filings import EntityFilings, empty_company_filings
from edgar.filtering import filter_by_date, filter_by_form, filter_by_year_quarter
from edgar.display.formatting import reverse_name

# Module-level import cache for lazy imports
_IMPORT_CACHE = {}


def lazy_import(module_path):
    """
    Lazily import a module or attribute and cache the result to avoid repeated imports.

    Args:
        module_path: String path to the module or attribute

    Returns:
        The imported module or attribute
    """
    if module_path not in _IMPORT_CACHE:
        parts = module_path.split('.')
        if len(parts) == 1:
            # Simple module import
            _IMPORT_CACHE[module_path] = __import__(module_path)
        else:
            # Import from module (potentially nested)
            module_name = '.'.join(parts[:-1])
            attr_name = parts[-1]

            module = __import__(module_name, fromlist=[attr_name])
            _IMPORT_CACHE[module_path] = getattr(module, attr_name)

    return _IMPORT_CACHE[module_path]


__all__ = [
    'Address',
    'EntityData',
    'CompanyData',
    'preprocess_company',
    'parse_entity_submissions',
    'extract_company_filings_table',
    'create_company_filings',
    'create_default_entity_data'
]


def extract_company_filings_table(filings_json: Dict[str, Any]) -> pa.Table:
    """
    Extract company filings from the json response.

    Args:
        filings_json: The JSON data containing filings

    Returns:
        A PyArrow Table containing the filings data
    """
    # Import this here to avoid circular imports
    from edgar.core import parse_acceptance_datetime

    # Handle case of no data
    if not filings_json.get('accessionNumber'):
        # Create an empty table with the right schema
        schema = pa.schema([
            ('accession_number', pa.string()),
            ('filing_date', pa.date32()),
            ('reportDate', pa.string()),
            ('acceptanceDateTime', pa.timestamp('us')),
            ('act', pa.string()),
            ('form', pa.string()),
            ('fileNumber', pa.string()),
            ('items', pa.string()),
            ('size', pa.string()),
            ('isXBRL', pa.string()),
            ('isInlineXBRL', pa.string()),
            ('primaryDocument', pa.string()),
            ('primaryDocDescription', pa.string())
        ])
        return pa.Table.from_arrays([[] for _ in range(13)], schema=schema)
    else:
        # Convert acceptanceDateTime string to datetime
        acceptance_datetimes = [
            parse_acceptance_datetime(dt) for dt in filings_json['acceptanceDateTime']
        ]

        fields = {
            'accession_number': filings_json['accessionNumber'],
            'filing_date': pc.cast(pc.strptime(pa.array(filings_json['filingDate']), '%Y-%m-%d', 'us'), pa.date32()),
            'reportDate': filings_json['reportDate'],
            'acceptanceDateTime': acceptance_datetimes,
            'act': filings_json['act'],
            'form': filings_json['form'],
            'fileNumber': filings_json['fileNumber'],
            'items': filings_json['items'],
            'size': filings_json['size'],
            'isXBRL': filings_json['isXBRL'],
            'isInlineXBRL': filings_json['isInlineXBRL'],
            'primaryDocument': filings_json['primaryDocument'],
            'primaryDocDescription': filings_json['primaryDocDescription']
        }

        # Create table using dictionary
        return pa.Table.from_arrays(
            arrays=[pa.array(v) if k not in ['filing_date', 'acceptanceDateTime']
                    else v for k, v in fields.items()],
            names=list(fields.keys())
        )


def create_company_filings(filings_json: Dict[str, Any], cik: int, company_name: str) -> EntityFilings:
    """
    Extract company filings from the json response.

    Args:
        filings_json: The JSON data containing filings
        cik: The company CIK
        company_name: The company name

    Returns:
        An EntityFilings object containing the filings
    """
    recent_filings = extract_company_filings_table(filings_json['recent'])
    return EntityFilings(recent_filings, cik=cik, company_name=company_name)


def parse_entity_submissions(cjson: Dict[str, Any]) -> 'CompanyData':
    """
    Parse entity submissions from the SEC API.

    Args:
        cjson: The JSON data from the SEC submissions API

    Returns:
        A CompanyData object representing the entity
    """
    mailing_addr = cjson['addresses']['mailing']
    business_addr = cjson['addresses']['business']
    cik = cjson['cik']
    company_name = cjson["name"]
    former_names = cjson.get('formerNames', [])

    for former_name in former_names:
        former_name['from'] = former_name['from'][:10] if former_name['from'] else former_name['from']
        former_name['to'] = former_name['to'][:10] if former_name['to'] else former_name['to']

    return CompanyData(
        cik=int(cik),
        name=company_name,
        tickers=cjson['tickers'],
        exchanges=cjson['exchanges'],
        sic=cjson['sic'],
        sic_description=cjson['sicDescription'],
        category=cjson['category'].replace("<br>", " | ") if cjson['category'] else None,
        fiscal_year_end=cjson['fiscalYearEnd'],
        entity_type=cjson['entityType'],
        phone=cjson['phone'],
        flags=cjson['flags'],
        mailing_address=Address(
            street1=mailing_addr['street1'],
            street2=mailing_addr['street2'],
            city=mailing_addr['city'],
            state_or_country_desc=mailing_addr['stateOrCountryDescription'],
            state_or_country=mailing_addr['stateOrCountry'],
            zipcode=mailing_addr['zipCode'],
        ),
        business_address=Address(
            street1=business_addr['street1'],
            street2=business_addr['street2'],
            city=business_addr['city'],
            state_or_country_desc=business_addr['stateOrCountryDescription'],
            state_or_country=business_addr['stateOrCountry'],
            zipcode=business_addr['zipCode'],
        ),
        filings=create_company_filings(cjson['filings'], cik=cik, company_name=company_name),
        insider_transaction_for_owner_exists=bool(cjson['insiderTransactionForOwnerExists']),
        insider_transaction_for_issuer_exists=bool(cjson['insiderTransactionForIssuerExists']),
        ein=cjson['ein'],
        description=cjson['description'],
        website=cjson['website'],
        investor_website=cjson['investorWebsite'],
        state_of_incorporation=cjson['stateOfIncorporation'],
        state_of_incorporation_description=cjson['stateOfIncorporationDescription'],
        former_names=former_names,
        files=cjson['filings']['files']
    )


class Address:
    """
    Represents a physical address.

    This class is optimized for memory usage and performance.
    """
    __slots__ = ('street1', 'street2', 'city', 'state_or_country', 'zipcode', 'state_or_country_desc', '_str_cache')

    def __init__(self,
                 street1: str,
                 street2: Optional[str],
                 city: str,
                 state_or_country: str,
                 zipcode: str,
                 state_or_country_desc: str
                 ):
        """
        Initialize an Address object.

        Args:
            street1: First line of street address
            street2: Second line of street address (optional)
            city: City name
            state_or_country: State or country code
            zipcode: Postal/ZIP code
            state_or_country_desc: Human-readable state or country name
        """
        # Store empty strings instead of None to avoid type checks later
        self.street1: str = street1 or ""
        self.street2: Optional[str] = street2 or ""
        self.city: str = city or ""
        self.state_or_country: str = state_or_country or ""
        self.zipcode: str = zipcode or ""
        self.state_or_country_desc: str = state_or_country_desc or ""
        self._str_cache = None

    @property
    def empty(self) -> bool:
        """Check if the address is empty. Optimized to avoid multiple attribute checks when possible."""
        # Short-circuit on common empty case
        if not self.street1:
            if not self.city and not self.zipcode:
                return True

        # Full check
        return not (self.street1 or self.street2 or self.city or self.state_or_country or self.zipcode)

    def __str__(self):
        """
        Generate a formatted string representation of the address.
        Caches result for repeated calls.
        """
        if self._str_cache is not None:
            return self._str_cache

        if not self.street1:
            self._str_cache = ""
            return ""

        # Build string only once and cache it
        parts = []
        parts.append(self.street1)

        if self.street2:
            parts.append(self.street2)

        parts.append(f"{self.city}, {self.state_or_country_desc} {self.zipcode}")

        self._str_cache = "\n".join(parts)
        return self._str_cache

    def __repr__(self):
        """Generate a string representation suitable for debugging."""
        # Simplified representation that avoids unnecessary string operations
        return f'Address(street1="{self.street1}", street2="{self.street2}", city="{self.city}", zipcode="{self.zipcode}")'

    def to_json(self) -> Dict[str, Optional[str]]:
        """Convert the address to a JSON-serializable dict."""
        # Direct dictionary creation is faster than multiple assignments
        return {
            'street1': self.street1,
            'street2': self.street2,
            'city': self.city,
            'state_or_country': self.state_or_country,
            'zipcode': self.zipcode,
            'state_or_country_desc': self.state_or_country_desc
        }


class EntityData:
    """
    Container for entity data loaded from SEC submissions API.

    This class provides access to entity metadata and filings.
    """

    def __init__(self,
                 cik: int,
                 name: str,
                 tickers: List[str],
                 exchanges: List[str],
                 sic: str,
                 sic_description: str,
                 ein: str,
                 entity_type: str,
                 fiscal_year_end: str,
                 filings: EntityFilings,
                 business_address: Address,
                 mailing_address: Address,
                 state_of_incorporation: str,
                 **kwargs):
        """
        Initialize a new EntityData instance.

        Args:
            cik: The CIK number
            name: The entity name
            sic: The Standard Industrial Classification code
            ein: The Employer Identification Number
            fiscal_year_end: The fiscal year end date
            tickers: List of ticker symbols
            exchanges: List of exchanges
            entity_type: The entity type
            filings: The entity's filings
            business_address: The business address
            mailing_address: The mailing address
            state_of_incorporation: The state of incorporation
            **kwargs: Additional attributes
        """
        self.cik: int = cik
        self.name: str = name
        self.sic = sic
        self.sic_description: str = sic_description
        self.ein: str = ein
        self.fiscal_year_end: str = fiscal_year_end
        self.tickers: List[str] = tickers
        self.exchanges: List[str] = exchanges
        self.filings: EntityFilings = filings
        self.entity_type = entity_type
        self.business_address: Address = business_address
        self.mailing_address: Address = mailing_address
        self.state_of_incorporation: str = state_of_incorporation

        # Store all other attributes
        for key, value in kwargs.items():
            setattr(self, key, value)

        # Initialize lazy loading flag
        self._loaded_all_filings: bool = False
        self._files = kwargs.get('files', [])

    def _load_older_filings(self):
        """
        Load older filings that were not included in the initial data.

        This method implements the lazy loading behavior of filings.
        When first creating an entity, only the most recent filings are loaded
        to keep API response times fast. When more filings are needed, this
        method will load additional filings from the SEC.
        """
        # If we have no files to load, we're done
        if not self._files:
            return

        # Import locally to avoid circular imports using the lazy import cache
        download_json = lazy_import('edgar.httprequests.download_json')

        # Load additional filings from the SEC
        from edgar.config import SEC_DATA_URL
        filing_tables = [self.filings.data]
        for file in self._files:
            submissions = download_json(f"{SEC_DATA_URL}/submissions/" + file['name'])
            filing_table = extract_company_filings_table(submissions)
            filing_tables.append(filing_table)

        # Combine all filing tables
        combined_tables = pa.concat_tables(filing_tables)

        # Update filings
        EntityFilings = lazy_import('edgar.entity.filings.EntityFilings')
        self.filings = EntityFilings(combined_tables, cik=self.cik, company_name=self.name)

    def get_filings(self,
                    year: Optional[Union[int, List[int]]] = None,
                    quarter: Optional[Union[int, List[int]]] = None,
                    form: Optional[Union[str, List]] = None,
                    accession_number: Optional[Union[str, List]] = None,
                    file_number: Optional[Union[str, List]] = None,
                    filing_date: Optional[Union[str, Tuple[str, str]]] = None,
                    date: Optional[Union[str, Tuple[str, str]]] = None,
                    amendments: bool = True,
                    is_xbrl: Optional[bool] = None,
                    is_inline_xbrl: Optional[bool] = None,
                    sort_by: Optional[Union[str, List[Tuple[str, str]]]] = None,
                    trigger_full_load: bool = True
                    ) -> Optional[EntityFilings]:
        """
        Get entity filings with lazy loading behavior.

        Args:
            year: Filter by year(s) (e.g. 2023, [2022, 2023])
            quarter: Filter by quarter(s) (1-4, e.g. 4, [3, 4])
            form: Filter by form type(s)
            accession_number: Filter by accession number(s)
            file_number: Filter by file number(s)
            filing_date: Filter by filing date (YYYY-MM-DD or range)
            date: Alias for filing_date
            amendments: Whether to include amendments (default: True)
            is_xbrl: Filter by XBRL status
            is_inline_xbrl: Filter by inline XBRL status
            sort_by: Sort criteria
            trigger_full_load: Whether to load all historical filings if not already loaded

        Returns:
            Filtered filings
        """

        # Lazy loading behavior
        # Note: we don't gate on is_using_local_storage() here because when bulk
        # submissions were downloaded, _merge_additional_local_filings() already
        # cleared self._files — so _load_older_filings() is a no-op.  When the
        # pagination files are *not* present locally, we still need to fetch them.
        if not self._loaded_all_filings and trigger_full_load:
            self._load_older_filings()
            self._loaded_all_filings = True

        # Get filings data
        company_filings = self.filings.data

        # Filter by year/quarter first (most selective)
        if year is not None:
            company_filings = filter_by_year_quarter(company_filings, year, quarter)

        # Filter by accession number
        if accession_number:
            company_filings = company_filings.filter(
                pc.is_in(company_filings['accession_number'], pa.array(listify(accession_number))))
            if len(company_filings) >= 1:
                # We found the filing(s)
                return EntityFilings(company_filings, cik=self.cik, company_name=self.name)

        # Filter by form (with amendments support)
        if form:
            company_filings = filter_by_form(company_filings, form, amendments)

        # Filter by file number
        if file_number:
            company_filings = company_filings.filter(
                pc.is_in(company_filings['fileNumber'], pa.array(listify(file_number))))

        # Filter by XBRL status
        if is_xbrl is not None:
            company_filings = company_filings.filter(pc.equal(company_filings['isXBRL'], int(is_xbrl)))

        # Filter by inline XBRL status
        if is_inline_xbrl is not None:
            company_filings = company_filings.filter(pc.equal(company_filings['isInlineXBRL'], int(is_inline_xbrl)))

        # Filter by filing date
        filing_date = filing_date or date
        if filing_date:
            try:
                company_filings = filter_by_date(company_filings, filing_date, 'filing_date')
            except InvalidDateException as e:
                log.error(e)
                return None

        # Sort filings
        if sort_by:
            company_filings = company_filings.sort_by(sort_by)

        # Return filtered filings
        return EntityFilings(company_filings, cik=self.cik, company_name=self.name)

    @property
    def is_company(self) -> bool:
        """Determine if this entity is a company."""
        return not self.is_individual

    @cached_property
    def is_individual(self) -> bool:
        """
        Determine if this entity is an individual person rather than a company.

        Uses a priority-based signal system with 9 checks. Stronger signals
        (insider issuer flag, tickers, entity type) take precedence over
        weaker ones (name keywords, owner flag).
        """
        from edgar.entity.constants import _classify_is_individual, COMPANY_FORMS

        # Extract forms from filing history for the company-forms check
        forms = None
        try:
            form_array = self.filings.data['form']
            # Check first 50 forms for performance
            n = min(50, len(form_array))
            forms = [form_array[i].as_py() for i in range(n)]
        except Exception:
            forms = []

        return _classify_is_individual(
            name=self.name,
            tickers=self.tickers,
            exchanges=self.exchanges,
            state_of_incorporation=getattr(self, 'state_of_incorporation', None),
            entity_type=getattr(self, 'entity_type', ''),
            forms=forms,
            ein=getattr(self, 'ein', None),
            cik=self.cik,
            insider_transaction_for_issuer_exists=getattr(self, 'insider_transaction_for_issuer_exists', None),
            insider_transaction_for_owner_exists=getattr(self, 'insider_transaction_for_owner_exists', None),
        )

    @cached_property
    def is_bdc(self) -> bool:
        """
        Check if this entity is a Business Development Company.

        BDCs are identified by having an 814-* file number in their filings.
        The 814- prefix indicates registration under the Investment Company
        Act of 1940 as a BDC.

        Returns:
            True if any filing has an 814-* file number, False otherwise.
        """
        file_numbers = self.filings.data['fileNumber']
        for fn in file_numbers:
            fn_str = fn.as_py()
            if fn_str and fn_str.startswith('814-'):
                return True
        return False

    def __str__(self):
        return f"EntityData({self.name} [{self.cik}])"

    def __repr__(self):
        repr_rich = lazy_import('edgar.richtools.repr_rich')
        return repr_rich(self.__rich__())

    def __rich__(self):
        """Creates a rich representation of the entity.

        Design follows the EdgarTools display language:
        - Single outer border (card-based) with box.ROUNDED
        - No emojis - uses unicode symbols from SYMBOLS
        - Semantic colors from edgar.display.styles
        - Compact layout with whitespace section separation
        """
        box = lazy_import('rich.box')
        Group = lazy_import('rich.console.Group')
        Panel = lazy_import('rich.panel.Panel')
        Table = lazy_import('rich.table.Table')
        Text = lazy_import('rich.text.Text')
        get_style = lazy_import('edgar.display.styles.get_style')
        SYMBOLS = lazy_import('edgar.display.styles.SYMBOLS')
        cik_text = lazy_import('edgar.display.formatting.cik_text')
        datefmt = lazy_import('edgar.display.formatting.datefmt')
        find_ticker = lazy_import('edgar.reference.tickers.find_ticker')

        # Build header line: Entity Name + Ticker(s) if company
        if self.is_company:
            tickers = self.tickers or []
            if tickers:
                if len(tickers) == 1:
                    ticker_text = Text(tickers[0], style=get_style("ticker"))
                elif len(tickers) == 2:
                    ticker_text = Text.assemble(
                        (tickers[0], get_style("ticker")),
                        (" / ", get_style("metadata")),
                        (tickers[1], get_style("ticker"))
                    )
                else:
                    ticker_text = Text.assemble(
                        (tickers[0], get_style("ticker")),
                        (" / ", get_style("metadata")),
                        (tickers[1], get_style("ticker")),
                        (f" +{len(tickers) - 2}", get_style("metadata"))
                    )
                header = Text.assemble(
                    (self.display_name, get_style("company_name")),
                    "  ",
                    ticker_text
                )
            else:
                header = Text(self.display_name, style=get_style("company_name"))
        else:
            header = Text(self.display_name, style=get_style("company_name"))

        # Build subtitle line: CIK + type/exchange/category
        subtitle_parts = [cik_text(self.cik)]

        if self.is_individual:
            subtitle_parts.append(Text("Individual", style=get_style("ticker")))
        elif hasattr(self, 'entity_type') and self.entity_type:
            subtitle_parts.append(Text(self.entity_type.title(), style=get_style("value")))

        # Add exchange if available (companies)
        if self.is_company and self.exchanges and self.exchanges[0]:
            subtitle_parts.append(Text(self.exchanges[0], style=get_style("value")))

        # Add category if available (companies)
        if self.is_company:
            category = getattr(self, 'category', None)
            if category:
                if 'Emerging growth' in category:
                    category = 'Emerging Growth'
                elif 'Large accelerated' in category:
                    category = 'Large Accelerated Filer'
                elif 'accelerated' in category.lower():
                    category = 'Accelerated Filer'
                elif 'Non-accelerated' in category:
                    category = 'Non-accelerated Filer'
                subtitle_parts.append(Text(category, style=get_style("metadata")))

        subtitle = Text(f" {SYMBOLS['bullet']} ").join(subtitle_parts)

        # Build content sections
        content_lines = []

        if self.is_company:
            # Key-value details table for companies
            details_table = Table(box=None, show_header=False, padding=(0, 2), expand=False)
            details_table.add_column("Label", style=get_style("label"), width=14)
            details_table.add_column("Value", style=get_style("value_highlight"))

            # Industry
            if hasattr(self, 'sic') and self.sic:
                sic_desc = getattr(self, 'sic_description', '') or ''
                details_table.add_row("Industry", f"{self.sic}: {sic_desc}")

            # Fiscal Year End
            if hasattr(self, 'fiscal_year_end') and self.fiscal_year_end:
                fy_end = self._format_fiscal_year_date(self.fiscal_year_end)
                details_table.add_row("Fiscal Year", fy_end)

            # State of Incorporation
            if hasattr(self, 'state_of_incorporation') and self.state_of_incorporation:
                from edgar.reference._codes import get_place_name
                code = self.state_of_incorporation
                state_name = get_place_name(code)
                if not state_name:
                    state_name = code
                details_table.add_row("Incorporated", state_name)

            # Phone
            if hasattr(self, 'phone') and self.phone:
                details_table.add_row("Phone", self.phone)

            # Website
            if hasattr(self, 'website') and self.website:
                details_table.add_row("Website", self.website)

            # Address (single line, business address preferred)
            address = None
            if hasattr(self, 'business_address') and not self.business_address.empty:
                address = self.business_address
            elif hasattr(self, 'mailing_address') and not self.mailing_address.empty:
                address = self.mailing_address

            if address:
                addr_parts = []
                if address.street1:
                    addr_parts.append(address.street1)
                if address.street2:
                    addr_parts.append(address.street2)
                city_state = []
                if address.city:
                    city_state.append(address.city)
                if address.state_or_country:
                    city_state.append(address.state_or_country)
                if city_state:
                    addr_parts.append(", ".join(city_state))
                if address.zipcode and addr_parts:
                    addr_parts[-1] = addr_parts[-1] + " " + address.zipcode

                if addr_parts:
                    details_table.add_row("Address", ", ".join(addr_parts[:2]) if len(addr_parts) > 2 else ", ".join(addr_parts))

            content_lines.append(details_table)

            # Former Names (only recent, max 3 — same treatment as Company)
            if hasattr(self, 'former_names') and self.former_names:
                from datetime import date, timedelta
                most_recent = self.former_names[0]
                two_years_ago = date.today() - timedelta(days=730)
                most_recent_date_str = most_recent.get('to')
                most_recent_date = date.fromisoformat(most_recent_date_str) if most_recent_date_str else None
                if most_recent_date and most_recent_date >= two_years_ago:
                    content_lines.append(Text(""))
                    content_lines.append(Text("Former Names", style=get_style("section_header")))
                    for former_name in self.former_names[:3]:
                        from_date = datefmt(former_name['from'], '%b %Y')
                        to_date = datefmt(former_name['to'], '%b %Y')
                        content_lines.append(Text.assemble(
                            ("  ", ""),
                            (former_name['name'], "italic"),
                            (" (", get_style("metadata")),
                            (f"{from_date} {SYMBOLS['arrow_right']} {to_date}", get_style("metadata")),
                            (")", get_style("metadata"))
                        ))
                    if len(self.former_names) > 3:
                        remaining = len(self.former_names) - 3
                        content_lines.append(Text(f"  {SYMBOLS['ellipsis']} and {remaining} more", style=get_style("metadata")))

        content = Group(
            header,
            subtitle,
            Text(""),
            *content_lines
        )

        return Panel(
            content,
            border_style=get_style("border"),
            box=box.ROUNDED,
            padding=(0, 1),
            width=85,
            subtitle=Text("SEC Entity Data", style=get_style("metadata")),
            subtitle_align="right"
        )

    @property
    def display_name(self) -> str:
        """Reverse the name if it is a company"""
        if self.is_company:
            return self.name

        return reverse_name(self.name)

    @staticmethod
    def _get_operating_type_emoticon(entity_type: str) -> str:
        """
        Generate a meaningful single-width symbol based on the SEC entity type.
        All symbols are chosen to be single-width to work well with rich borders.

        Args:
            entity_type (str): The SEC entity type (case-insensitive)

        Returns:
            str: A single-width symbol representing the entity type
        """
        symbols = {
            "operating": "○",  # Circle for active operations
            "subsidiary": "→",  # Arrow showing connection to parent
            "inactive": "×",  # Cross for inactive
            "holding company": "■",  # Square for solid corporate structure
            "investment company": "$",  # Dollar for investment focus
            "investment trust": "$",  # Dollar for investment focus
            "shell": "□",  # Empty square for shell
            "development stage": "∆",  # Triangle for growth/development
            "financial services": "¢",  # Cent sign for financial services
            "reit": "⌂",  # House symbol
            "spv": "◊",  # Diamond for special purpose
            "joint venture": "∞"  # Infinity for partnership
        }

        # Clean input: convert to lowercase and strip whitespace
        cleaned_type = entity_type.lower().strip()

        # Handle some common variations
        if "investment" in cleaned_type:
            return symbols["investment company"]
        if "real estate" in cleaned_type or "reit" in cleaned_type:
            return symbols["reit"]

        # Return default question mark if type not found
        return symbols.get(cleaned_type, "")

    @staticmethod
    def _format_fiscal_year_date(date_str):
        """Format fiscal year end date in a human-readable format."""
        if not date_str:
            return "-"

        # Dictionary of months
        months = {
            "01": "Jan", "02": "Feb", "03": "Mar",
            "04": "Apr", "05": "May", "06": "Jun",
            "07": "Jul", "08": "Aug", "09": "Sep",
            "10": "Oct", "11": "Nov", "12": "Dec"
        }

        # Extract month and day
        month = date_str[:2]
        if month not in months:
            return date_str

        try:
            day = str(int(date_str[2:]))  # Remove leading zero
            return f"{months[month]} {day}"
        except (ValueError, IndexError):
            return date_str


class CompanyData(EntityData):
    """
    Specialized container for company data loaded from SEC submissions API.

    This is a specialized version of EntityData specifically for companies.
    It adds company-specific methods and properties.
    """

    def __init__(self, **kwargs):
        """Construct a new CompanyData object."""
        super().__init__(**kwargs)

    @property
    def industry(self) -> str:
        """Get the industry description for this company."""
        return getattr(self, 'sic_description', '')

    def get_ticker(self) -> Optional[str]:
        """Get the primary ticker for this company."""
        if self.tickers and len(self.tickers) > 0:
            return self.tickers[0]
        return None

    def __str__(self):
        ticker = self.get_ticker()
        ticker_str = f" - {ticker}" if ticker else ""
        return f"CompanyData({self.name} [{self.cik}]{ticker_str})"


# Compile regex patterns for better performance
_COMPANY_TYPES_PATTERN = re.compile(r"(L\.?L\.?C\.?|Inc\.?|Ltd\.?|L\.?P\.?|/[A-Za-z]{2,3}/?| CORP(ORATION)?|PLC| AG)$",
                                    re.IGNORECASE)
_PUNCTUATION_PATTERN = re.compile(r"\.|,")


def preprocess_company(company: str) -> str:
    """preprocess the company name for storing in the search index"""
    comp = _COMPANY_TYPES_PATTERN.sub("", company.lower())
    comp = _PUNCTUATION_PATTERN.sub("", comp)
    return comp.strip()


def create_default_entity_data(cik: int) -> 'EntityData':
    """
    Create a default EntityData instance for when entity data cannot be found.

    Args:
        cik: The CIK number to use for the entity

    Returns:
        A minimal EntityData instance with default values
    """
    # Create a minimal EntityData with blank/empty values
    empty_address = Address(
        street1="",
        street2="",
        city="",
        state_or_country="",
        zipcode="",
        state_or_country_desc=""
    )

    # Use the CIK as the name since we don't know the real name
    name = f"Entity {cik}"

    # Create a minimal entity data
    return EntityData(
        cik=cik,
        name=name,
        tickers=[],
        exchanges=[],
        filings=empty_company_filings(cik, name),
        business_address=empty_address,
        mailing_address=empty_address,
        category="",
        sic=None,
        sic_description="",
        fiscal_year_end="",
        entity_type="",
        phone="",
        flags="",
        insider_transaction_for_owner_exists=False,
        insider_transaction_for_issuer_exists=False,
        ein="",
        description="",
        website="",
        investor_website="",
        state_of_incorporation="",
        state_of_incorporation_description="",
        former_names=[],
        files=[]
    )
