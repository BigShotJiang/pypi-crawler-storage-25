# privacy-dsar-mcp-server

MCP server for GDPR privacy compliance and DSAR management — open-source alternative to Transcend.

[![PyPI version](https://badge.fury.io/py/privacy-dsar-mcp-server.svg)](https://badge.fury.io/py/privacy-dsar-mcp-server)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## Overview

Manage Data Subject Access Requests (DSAR), check GDPR compliance, and maintain your Article 30 data processing inventory — all through MCP tools.

Built as an open-source alternative to enterprise solutions like Transcend MCP.

## Tools

| Tool | Description |
|------|-------------|
| `tool_create_dsar` | Create a DSAR with automatic 30-day deadline tracking (GDPR Art. 12) |
| `tool_list_dsars` | List all DSARs sorted by urgency — overdue and critical first |
| `tool_get_dsar_status` | Get detailed DSAR status with GDPR article reference and deadline warnings |
| `tool_update_dsar` | Update DSAR status or add processing notes |
| `tool_check_gdpr_compliance` | Analyze data processing descriptions for GDPR compliance issues (15 rules, score A-F) |
| `tool_get_privacy_dashboard` | Privacy officer dashboard: open DSARs, overdue, compliance score, action items |
| `tool_data_inventory` | Register and list data processing activities (Article 30 GDPR) |

## DSAR Types

- `access` — Article 15: Right of access
- `deletion` — Article 17: Right to erasure
- `rectification` — Article 16: Right to rectification
- `portability` — Article 20: Right to data portability
- `objection` — Article 21: Right to object
- `restriction` — Article 18: Right to restriction of processing

## Installation

```bash
pip install privacy-dsar-mcp-server
```

## Claude Desktop Configuration

```json
{
  "mcpServers": {
    "privacy-dsar": {
      "command": "privacy-dsar-mcp-server"
    }
  }
}
```

## Usage Examples

```
# Create a new DSAR
tool_create_dsar(
    subject_name="Jane Smith",
    subject_email="jane@example.com",
    request_type="deletion",
    description="Please delete all my personal data from your systems."
)

# Check GDPR compliance
tool_check_gdpr_compliance(
    description="We collect user email addresses and phone numbers for marketing purposes
    using consent. Data is stored on AWS servers in the US indefinitely."
)

# Get privacy dashboard
tool_get_privacy_dashboard()
```

## Data Storage

Data is stored locally at `~/.privacy_dsar_store.json` — no external services required.

## License

MIT License — see [LICENSE](LICENSE)

## Related MCP Servers

- [agent-audit-trail-mcp](https://github.com/AiAgentKarl/agent-audit-trail-mcp) — Audit logging for AI agents
- [fraud-prevention-mcp-server](https://github.com/AiAgentKarl/fraud-prevention-mcp-server) — Fraud detection and risk scoring
