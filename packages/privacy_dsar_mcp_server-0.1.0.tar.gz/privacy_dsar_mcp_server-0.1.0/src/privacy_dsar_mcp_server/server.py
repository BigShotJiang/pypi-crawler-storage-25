"""
Privacy DSAR MCP Server — Open-Source GDPR/DSGVO-Compliance.

Verwaltet Data Subject Access Requests, prueft GDPR-Konformitaet
und pflegt das Verarbeitungsverzeichnis (Art. 30 DSGVO).
"""

from mcp.server.fastmcp import FastMCP

from privacy_dsar_mcp_server.tools.dsar import (
    create_dsar,
    list_dsars,
    get_dsar_status,
    update_dsar,
)
from privacy_dsar_mcp_server.tools.compliance import check_gdpr_compliance
from privacy_dsar_mcp_server.tools.inventory import (
    data_inventory,
    get_privacy_dashboard,
)

# MCP-Server initialisieren
mcp = FastMCP(
    "privacy-dsar-mcp-server",
    instructions=(
        "MCP server for GDPR privacy compliance and DSAR management. "
        "Open-source alternative to Transcend MCP. Tools: create_dsar, list_dsars, "
        "get_dsar_status, update_dsar, check_gdpr_compliance, get_privacy_dashboard, data_inventory. "
        "Manages data subject access requests with 30-day deadline tracking, "
        "analyzes data processing for GDPR compliance issues, "
        "and maintains Article 30 data processing inventories."
    ),
)


@mcp.tool()
def tool_create_dsar(
    subject_name: str,
    subject_email: str,
    request_type: str,
    description: str,
    deadline_days: int = 30,
) -> dict:
    """
    Create a new Data Subject Access Request (DSAR).

    Registers a GDPR request with automatic 30-day deadline tracking.
    Types: access (Art. 15), deletion (Art. 17), rectification (Art. 16),
    portability (Art. 20), objection (Art. 21), restriction (Art. 18).

    Args:
        subject_name: Full name of the data subject making the request
        subject_email: Email address of the data subject
        request_type: Type of DSAR — one of: access, deletion, rectification, portability, objection, restriction
        description: Detailed description of the request
        deadline_days: Days until deadline (default: 30, per GDPR Article 12)
    """
    return create_dsar(subject_name, subject_email, request_type, description, deadline_days)


@mcp.tool()
def tool_list_dsars(
    status: str | None = None,
    request_type: str | None = None,
    urgency: str | None = None,
) -> dict:
    """
    List all DSARs with optional filters, sorted by urgency.

    Overdue and critical requests appear first. Filter by status
    (received, verified, in_progress, completed, rejected),
    type (access, deletion, etc.), or urgency (overdue, critical, high, medium, low).

    Args:
        status: Filter by DSAR status (optional)
        request_type: Filter by request type (optional)
        urgency: Filter by urgency level (optional)
    """
    return list_dsars(status=status, request_type=request_type, urgency=urgency)


@mcp.tool()
def tool_get_dsar_status(dsar_id: str) -> dict:
    """
    Get detailed status of a specific DSAR including deadline warnings.

    Returns the DSAR details, applicable GDPR article, urgency level,
    days remaining, and deadline warnings.

    Args:
        dsar_id: The DSAR identifier (e.g. DSAR-A1B2C3D4)
    """
    return get_dsar_status(dsar_id)


@mcp.tool()
def tool_update_dsar(
    dsar_id: str,
    status: str | None = None,
    note: str | None = None,
) -> dict:
    """
    Update a DSAR's status or add a processing note.

    Status transitions: received → verified → in_progress → completed/rejected.
    Notes are timestamped and appended to the DSAR history.

    Args:
        dsar_id: The DSAR identifier to update
        status: New status — one of: received, verified, in_progress, completed, rejected (optional)
        note: Note to add to the DSAR processing history (optional)
    """
    return update_dsar(dsar_id, status=status, note=note)


@mcp.tool()
def tool_check_gdpr_compliance(description: str) -> dict:
    """
    Analyze a data processing description for GDPR compliance issues.

    Checks against 15 real GDPR rules (Articles 5-35) and returns a compliance
    score (0-100), grade (A-F), specific issues with severity levels,
    and actionable recommendations.

    Args:
        description: Description of the data processing activity to analyze (be detailed for best results)
    """
    return check_gdpr_compliance(description)


@mcp.tool()
def tool_get_privacy_dashboard() -> dict:
    """
    Get a comprehensive privacy compliance dashboard.

    Overview of: open DSARs, overdue requests, upcoming deadlines,
    compliance score, data inventory stats, and prioritized action items.
    Perfect for daily privacy officer briefings.
    """
    return get_privacy_dashboard()


@mcp.tool()
def tool_data_inventory(
    action: str = "list",
    name: str | None = None,
    purpose: str | None = None,
    legal_basis: str | None = None,
    data_categories: list[str] | None = None,
    data_subjects: list[str] | None = None,
    recipients: list[str] | None = None,
    retention_period: str = "not specified",
    third_country_transfer: bool = False,
    dpia_required: bool = False,
) -> dict:
    """
    Register or list data processing activities (Article 30 GDPR).

    Action 'list': Show all registered processing activities.
    Action 'add': Register a new processing activity with required fields.
    Legal bases: consent, contract, legal_obligation, vital_interests, public_interest, legitimate_interest.

    Args:
        action: 'list' to show activities, 'add' to register a new one
        name: Name of the processing activity (required for 'add')
        purpose: Purpose of the data processing (required for 'add')
        legal_basis: Legal basis per Article 6 GDPR (required for 'add')
        data_categories: Types of personal data processed, e.g. ["name", "email", "address"] (required for 'add')
        data_subjects: Categories of data subjects, e.g. ["customers", "employees"] (required for 'add')
        recipients: Who receives the data, e.g. ["payment provider", "email service"]
        retention_period: How long data is stored, e.g. "2 years after contract end"
        third_country_transfer: Whether data is transferred outside EU/EEA
        dpia_required: Whether a Data Protection Impact Assessment is needed
    """
    return data_inventory(
        action=action,
        name=name,
        purpose=purpose,
        legal_basis=legal_basis,
        data_categories=data_categories,
        data_subjects=data_subjects,
        recipients=recipients,
        retention_period=retention_period,
        third_country_transfer=third_country_transfer,
        dpia_required=dpia_required,
    )


def main():
    """Startet den MCP-Server ueber stdio-Transport."""
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
