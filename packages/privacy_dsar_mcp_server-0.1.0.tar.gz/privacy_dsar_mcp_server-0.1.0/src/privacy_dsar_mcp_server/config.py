"""
Konfiguration fuer den Privacy DSAR MCP Server.
Laedt Umgebungsvariablen und stellt Defaults bereit.
"""

from pathlib import Path

# Persistente JSON-Datei im Home-Verzeichnis
DATA_FILE = Path.home() / ".privacy_dsar_store.json"

# DSAR-Fristen (in Tagen) gemaess DSGVO
DSAR_DEADLINE_DAYS = 30  # Artikel 12 Abs. 3 DSGVO: 1 Monat
DSAR_EXTENSION_DAYS = 60  # Maximal 2 weitere Monate bei Komplexitaet

# Dringlichkeitsstufen (Tage bis Frist)
URGENCY_CRITICAL = 3   # Weniger als 3 Tage: KRITISCH
URGENCY_HIGH = 7        # Weniger als 7 Tage: HOCH
URGENCY_MEDIUM = 14     # Weniger als 14 Tage: MITTEL
URGENCY_LOW = 30        # Mehr als 14 Tage: NIEDRIG

# DSAR-Typen gemaess DSGVO
DSAR_TYPES = [
    "access",         # Art. 15 — Auskunftsrecht
    "deletion",       # Art. 17 — Recht auf Loeschung
    "rectification",  # Art. 16 — Recht auf Berichtigung
    "portability",    # Art. 20 — Recht auf Datenuebertragbarkeit
    "objection",      # Art. 21 — Widerspruchsrecht
    "restriction",    # Art. 18 — Recht auf Einschraenkung
]

# DSAR-Status-Werte
DSAR_STATUSES = [
    "received",       # Eingegangen
    "verified",       # Identitaet geprueft
    "in_progress",    # In Bearbeitung
    "completed",      # Abgeschlossen
    "rejected",       # Abgelehnt (mit Begruendung)
    "overdue",        # Frist ueberschritten
]

# Rechtsgrundlagen gemaess Art. 6 DSGVO
LEGAL_BASES = [
    "consent",             # Art. 6 Abs. 1 lit. a — Einwilligung
    "contract",            # Art. 6 Abs. 1 lit. b — Vertragserfullung
    "legal_obligation",    # Art. 6 Abs. 1 lit. c — Rechtliche Verpflichtung
    "vital_interests",     # Art. 6 Abs. 1 lit. d — Lebenswichtige Interessen
    "public_interest",     # Art. 6 Abs. 1 lit. e — Oeffentliches Interesse
    "legitimate_interest", # Art. 6 Abs. 1 lit. f — Berechtigtes Interesse
]
