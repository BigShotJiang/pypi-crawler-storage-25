"""
Persistenter JSON-Store fuer DSAR- und Privacy-Daten.
Speichert in ~/.privacy_dsar_store.json
"""

import json
import time
import uuid
from pathlib import Path
from typing import Any

from privacy_dsar_mcp_server.config import (
    DATA_FILE,
    DSAR_DEADLINE_DAYS,
    URGENCY_CRITICAL,
    URGENCY_HIGH,
    URGENCY_MEDIUM,
)

# Leere Store-Struktur
EMPTY_STORE = {
    "dsars": {},
    "data_inventory": {},
    "stats": {
        "total_created": 0,
        "total_completed": 0,
        "total_rejected": 0,
        "total_overdue": 0,
    },
}


def _load() -> dict[str, Any]:
    """Laedt den Store von der JSON-Datei."""
    if DATA_FILE.exists():
        try:
            with open(DATA_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                # Sicherstellen, dass alle Keys existieren
                for key in EMPTY_STORE:
                    if key not in data:
                        data[key] = EMPTY_STORE[key]
                return data
        except Exception:
            pass
    return json.loads(json.dumps(EMPTY_STORE))


def _save(data: dict[str, Any]) -> None:
    """Speichert den Store in die JSON-Datei."""
    try:
        with open(DATA_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    except Exception:
        pass


def get_store() -> dict[str, Any]:
    """Gibt den gesamten Store zurueck."""
    return _load()


def _generate_id(prefix: str = "DSAR") -> str:
    """Erzeugt eine eindeutige ID mit Prefix."""
    short_uuid = uuid.uuid4().hex[:8].upper()
    return f"{prefix}-{short_uuid}"


def _calculate_deadline(created_at: float, deadline_days: int = DSAR_DEADLINE_DAYS) -> float:
    """Berechnet die Frist als Unix-Timestamp."""
    return created_at + (deadline_days * 86400)


def _get_urgency(deadline: float) -> str:
    """Berechnet die Dringlichkeitsstufe basierend auf verbleibenden Tagen."""
    days_remaining = (deadline - time.time()) / 86400
    if days_remaining < 0:
        return "overdue"
    elif days_remaining < URGENCY_CRITICAL:
        return "critical"
    elif days_remaining < URGENCY_HIGH:
        return "high"
    elif days_remaining < URGENCY_MEDIUM:
        return "medium"
    else:
        return "low"


def _days_remaining(deadline: float) -> float:
    """Berechnet verbleibende Tage bis zur Frist."""
    return round((deadline - time.time()) / 86400, 1)


# --- DSAR-Funktionen ---

def create_dsar(
    subject_name: str,
    subject_email: str,
    request_type: str,
    description: str,
    deadline_days: int = DSAR_DEADLINE_DAYS,
) -> dict[str, Any]:
    """Erstellt einen neuen DSAR-Antrag."""
    data = _load()
    dsar_id = _generate_id("DSAR")
    now = time.time()
    deadline = _calculate_deadline(now, deadline_days)

    dsar = {
        "id": dsar_id,
        "subject_name": subject_name,
        "subject_email": subject_email,
        "request_type": request_type,
        "description": description,
        "status": "received",
        "notes": [],
        "created_at": now,
        "updated_at": now,
        "deadline": deadline,
        "deadline_days": deadline_days,
        "completed_at": None,
    }

    data["dsars"][dsar_id] = dsar
    data["stats"]["total_created"] += 1
    _save(data)

    return {
        **dsar,
        "urgency": _get_urgency(deadline),
        "days_remaining": _days_remaining(deadline),
    }


def list_dsars(
    status: str | None = None,
    request_type: str | None = None,
    urgency: str | None = None,
) -> list[dict[str, Any]]:
    """Listet DSARs mit optionalen Filtern auf."""
    data = _load()
    results = []

    for dsar in data["dsars"].values():
        # Status-Filter
        if status and dsar["status"] != status:
            continue
        # Typ-Filter
        if request_type and dsar["request_type"] != request_type:
            continue

        dsar_urgency = _get_urgency(dsar["deadline"])

        # Dringlichkeits-Filter
        if urgency and dsar_urgency != urgency:
            continue

        results.append({
            **dsar,
            "urgency": dsar_urgency,
            "days_remaining": _days_remaining(dsar["deadline"]),
        })

    # Nach Dringlichkeit sortieren (ueberfaellig zuerst, dann nach Frist)
    urgency_order = {"overdue": 0, "critical": 1, "high": 2, "medium": 3, "low": 4}
    results.sort(key=lambda x: (urgency_order.get(x["urgency"], 5), x["deadline"]))

    return results


def get_dsar(dsar_id: str) -> dict[str, Any] | None:
    """Gibt einen einzelnen DSAR zurueck."""
    data = _load()
    dsar = data["dsars"].get(dsar_id)
    if dsar:
        return {
            **dsar,
            "urgency": _get_urgency(dsar["deadline"]),
            "days_remaining": _days_remaining(dsar["deadline"]),
        }
    return None


def update_dsar(
    dsar_id: str,
    status: str | None = None,
    note: str | None = None,
) -> dict[str, Any] | None:
    """Aktualisiert Status und/oder fuegt eine Notiz hinzu."""
    data = _load()
    dsar = data["dsars"].get(dsar_id)
    if not dsar:
        return None

    now = time.time()
    dsar["updated_at"] = now

    if status:
        old_status = dsar["status"]
        dsar["status"] = status

        # Statistiken aktualisieren
        if status == "completed" and old_status != "completed":
            dsar["completed_at"] = now
            data["stats"]["total_completed"] += 1
        elif status == "rejected" and old_status != "rejected":
            data["stats"]["total_rejected"] += 1

    if note:
        dsar["notes"].append({
            "text": note,
            "timestamp": now,
        })

    _save(data)
    return {
        **dsar,
        "urgency": _get_urgency(dsar["deadline"]),
        "days_remaining": _days_remaining(dsar["deadline"]),
    }


# --- Data Inventory (Art. 30 DSGVO) ---

def add_processing_activity(
    name: str,
    purpose: str,
    legal_basis: str,
    data_categories: list[str],
    data_subjects: list[str],
    recipients: list[str] | None = None,
    retention_period: str = "not specified",
    third_country_transfer: bool = False,
    dpia_required: bool = False,
) -> dict[str, Any]:
    """Registriert eine Datenverarbeitungstaetigkeit (Art. 30 DSGVO)."""
    data = _load()
    activity_id = _generate_id("ACT")
    now = time.time()

    activity = {
        "id": activity_id,
        "name": name,
        "purpose": purpose,
        "legal_basis": legal_basis,
        "data_categories": data_categories,
        "data_subjects": data_subjects,
        "recipients": recipients or [],
        "retention_period": retention_period,
        "third_country_transfer": third_country_transfer,
        "dpia_required": dpia_required,
        "created_at": now,
        "updated_at": now,
    }

    data["data_inventory"][activity_id] = activity
    _save(data)
    return activity


def list_processing_activities() -> list[dict[str, Any]]:
    """Listet alle registrierten Verarbeitungstaetigkeiten auf."""
    data = _load()
    return list(data["data_inventory"].values())


def get_processing_activity(activity_id: str) -> dict[str, Any] | None:
    """Gibt eine einzelne Verarbeitungstaetigkeit zurueck."""
    data = _load()
    return data["data_inventory"].get(activity_id)


# --- Dashboard / Statistiken ---

def get_dashboard() -> dict[str, Any]:
    """Erstellt eine Uebersicht ueber den Datenschutz-Status."""
    data = _load()
    dsars = data["dsars"]
    inventory = data["data_inventory"]
    stats = data["stats"]

    # Offene DSARs zaehlen
    open_dsars = [d for d in dsars.values() if d["status"] not in ("completed", "rejected")]
    overdue_dsars = [d for d in open_dsars if _get_urgency(d["deadline"]) == "overdue"]
    critical_dsars = [d for d in open_dsars if _get_urgency(d["deadline"]) == "critical"]

    # DSARs nach Typ zaehlen
    type_counts = {}
    for d in dsars.values():
        rtype = d["request_type"]
        type_counts[rtype] = type_counts.get(rtype, 0) + 1

    # DSARs nach Status zaehlen
    status_counts = {}
    for d in dsars.values():
        s = d["status"]
        status_counts[s] = status_counts.get(s, 0) + 1

    # Compliance-Score berechnen
    total = len(dsars)
    if total > 0:
        completed_on_time = sum(
            1 for d in dsars.values()
            if d["status"] == "completed"
            and d.get("completed_at")
            and d["completed_at"] <= d["deadline"]
        )
        overdue_count = len(overdue_dsars)
        # Score: 100% wenn alles rechtzeitig, Abzug fuer ueberfaellige
        compliance_score = max(0, round(100 - (overdue_count / max(total, 1) * 100)))
    else:
        completed_on_time = 0
        compliance_score = 100  # Keine DSARs = kein Risiko

    # Naechste Frist
    next_deadline = None
    if open_dsars:
        soonest = min(open_dsars, key=lambda d: d["deadline"])
        next_deadline = {
            "dsar_id": soonest["id"],
            "subject_name": soonest["subject_name"],
            "days_remaining": _days_remaining(soonest["deadline"]),
            "urgency": _get_urgency(soonest["deadline"]),
        }

    # Inventory-Stats
    activities_with_dpia = sum(1 for a in inventory.values() if a.get("dpia_required"))
    activities_with_transfer = sum(1 for a in inventory.values() if a.get("third_country_transfer"))

    return {
        "summary": {
            "total_dsars": total,
            "open_dsars": len(open_dsars),
            "overdue_dsars": len(overdue_dsars),
            "critical_dsars": len(critical_dsars),
            "compliance_score": compliance_score,
            "completed_on_time": completed_on_time,
        },
        "next_deadline": next_deadline,
        "dsars_by_type": type_counts,
        "dsars_by_status": status_counts,
        "data_inventory": {
            "total_activities": len(inventory),
            "dpia_required": activities_with_dpia,
            "third_country_transfers": activities_with_transfer,
        },
        "stats": stats,
    }
