# Privacy DSAR MCP Server — Tools
