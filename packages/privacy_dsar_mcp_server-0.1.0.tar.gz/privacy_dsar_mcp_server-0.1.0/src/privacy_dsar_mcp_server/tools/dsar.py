"""
DSAR-Tools: Erstellen, Auflisten, Status pruefen und Aktualisieren
von Betroffenenrechte-Anfragen (Data Subject Access Requests).
"""

from privacy_dsar_mcp_server.config import DSAR_TYPES, DSAR_STATUSES
from privacy_dsar_mcp_server.store import (
    create_dsar as store_create_dsar,
    list_dsars as store_list_dsars,
    get_dsar as store_get_dsar,
    update_dsar as store_update_dsar,
)


def create_dsar(
    subject_name: str,
    subject_email: str,
    request_type: str,
    description: str,
    deadline_days: int = 30,
) -> dict:
    """Erstellt einen neuen DSAR-Antrag mit Validierung."""

    # Typ validieren
    if request_type not in DSAR_TYPES:
        return {
            "error": f"Invalid request type: {request_type}",
            "valid_types": DSAR_TYPES,
        }

    # Pflichtfelder pruefen
    if not subject_name or not subject_name.strip():
        return {"error": "subject_name is required"}
    if not subject_email or not subject_email.strip():
        return {"error": "subject_email is required"}
    if not description or not description.strip():
        return {"error": "description is required"}

    # Frist validieren
    if deadline_days < 1 or deadline_days > 90:
        return {"error": "deadline_days must be between 1 and 90"}

    result = store_create_dsar(
        subject_name=subject_name.strip(),
        subject_email=subject_email.strip(),
        request_type=request_type,
        description=description.strip(),
        deadline_days=deadline_days,
    )

    return {
        "status": "created",
        "message": f"DSAR {result['id']} created — deadline in {result['days_remaining']} days",
        "dsar": result,
    }


def list_dsars(
    status: str | None = None,
    request_type: str | None = None,
    urgency: str | None = None,
) -> dict:
    """Listet DSARs mit optionalen Filtern auf."""

    # Filter validieren
    if status and status not in DSAR_STATUSES:
        return {
            "error": f"Invalid status filter: {status}",
            "valid_statuses": DSAR_STATUSES,
        }
    if request_type and request_type not in DSAR_TYPES:
        return {
            "error": f"Invalid type filter: {request_type}",
            "valid_types": DSAR_TYPES,
        }
    valid_urgencies = ["overdue", "critical", "high", "medium", "low"]
    if urgency and urgency not in valid_urgencies:
        return {
            "error": f"Invalid urgency filter: {urgency}",
            "valid_urgencies": valid_urgencies,
        }

    results = store_list_dsars(status=status, request_type=request_type, urgency=urgency)

    # Zusammenfassung
    overdue_count = sum(1 for d in results if d.get("urgency") == "overdue")
    critical_count = sum(1 for d in results if d.get("urgency") == "critical")

    return {
        "total": len(results),
        "overdue": overdue_count,
        "critical": critical_count,
        "dsars": results,
    }


def get_dsar_status(dsar_id: str) -> dict:
    """Gibt den detaillierten Status eines einzelnen DSARs zurueck."""

    if not dsar_id or not dsar_id.strip():
        return {"error": "dsar_id is required"}

    result = store_get_dsar(dsar_id.strip())
    if not result:
        return {"error": f"DSAR not found: {dsar_id}"}

    # GDPR-Artikel basierend auf Typ hinzufuegen
    article_map = {
        "access": "Article 15 GDPR — Right of access",
        "deletion": "Article 17 GDPR — Right to erasure",
        "rectification": "Article 16 GDPR — Right to rectification",
        "portability": "Article 20 GDPR — Right to data portability",
        "objection": "Article 21 GDPR — Right to object",
        "restriction": "Article 18 GDPR — Right to restriction of processing",
    }

    return {
        "dsar": result,
        "gdpr_article": article_map.get(result["request_type"], "Unknown"),
        "deadline_warning": _get_deadline_warning(result),
    }


def update_dsar(
    dsar_id: str,
    status: str | None = None,
    note: str | None = None,
) -> dict:
    """Aktualisiert den Status oder fuegt eine Notiz hinzu."""

    if not dsar_id or not dsar_id.strip():
        return {"error": "dsar_id is required"}

    # Status validieren
    if status and status not in DSAR_STATUSES:
        return {
            "error": f"Invalid status: {status}",
            "valid_statuses": DSAR_STATUSES,
        }

    # Mindestens ein Update erforderlich
    if not status and not note:
        return {"error": "Provide at least one of: status, note"}

    result = store_update_dsar(
        dsar_id=dsar_id.strip(),
        status=status,
        note=note,
    )

    if not result:
        return {"error": f"DSAR not found: {dsar_id}"}

    return {
        "status": "updated",
        "message": f"DSAR {dsar_id} updated successfully",
        "dsar": result,
    }


def _get_deadline_warning(dsar: dict) -> str | None:
    """Erzeugt eine Warnung basierend auf der Dringlichkeit."""
    urgency = dsar.get("urgency")
    days = dsar.get("days_remaining", 0)

    if dsar.get("status") in ("completed", "rejected"):
        return None

    warnings = {
        "overdue": f"OVERDUE by {abs(days)} days! GDPR violation risk — respond immediately.",
        "critical": f"CRITICAL: Only {days} days remaining. Immediate action required.",
        "high": f"HIGH priority: {days} days remaining until GDPR deadline.",
        "medium": f"MEDIUM priority: {days} days remaining.",
        "low": None,
    }
    return warnings.get(urgency)
