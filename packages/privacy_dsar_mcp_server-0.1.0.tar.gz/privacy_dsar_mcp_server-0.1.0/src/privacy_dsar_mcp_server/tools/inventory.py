"""
Data Inventory (Art. 30 DSGVO) und Privacy Dashboard.
Verwaltet das Verzeichnis der Verarbeitungstaetigkeiten
und erstellt eine Datenschutz-Uebersicht.
"""

from privacy_dsar_mcp_server.config import LEGAL_BASES
from privacy_dsar_mcp_server.store import (
    add_processing_activity as store_add_activity,
    list_processing_activities as store_list_activities,
    get_dashboard as store_get_dashboard,
)


def data_inventory(
    action: str = "list",
    name: str | None = None,
    purpose: str | None = None,
    legal_basis: str | None = None,
    data_categories: list[str] | None = None,
    data_subjects: list[str] | None = None,
    recipients: list[str] | None = None,
    retention_period: str = "not specified",
    third_country_transfer: bool = False,
    dpia_required: bool = False,
) -> dict:
    """Verwaltet das Verarbeitungsverzeichnis (Art. 30 DSGVO)."""

    if action == "list":
        activities = store_list_activities()
        return {
            "total": len(activities),
            "activities": activities,
            "note": "Article 30 GDPR requires controllers to maintain a record of processing activities.",
        }

    elif action == "add":
        # Pflichtfelder pruefen
        if not name or not name.strip():
            return {"error": "name is required for adding a processing activity"}
        if not purpose or not purpose.strip():
            return {"error": "purpose is required (Article 5(1)(b) — purpose limitation)"}
        if not legal_basis:
            return {
                "error": "legal_basis is required (Article 6 GDPR)",
                "valid_bases": LEGAL_BASES,
            }
        if legal_basis not in LEGAL_BASES:
            return {
                "error": f"Invalid legal_basis: {legal_basis}",
                "valid_bases": LEGAL_BASES,
            }
        if not data_categories:
            return {"error": "data_categories is required — list the types of personal data processed"}
        if not data_subjects:
            return {"error": "data_subjects is required — list the categories of data subjects"}

        result = store_add_activity(
            name=name.strip(),
            purpose=purpose.strip(),
            legal_basis=legal_basis,
            data_categories=data_categories,
            data_subjects=data_subjects,
            recipients=recipients,
            retention_period=retention_period,
            third_country_transfer=third_country_transfer,
            dpia_required=dpia_required,
        )

        return {
            "status": "added",
            "message": f"Processing activity '{name}' registered in data inventory",
            "activity": result,
        }

    else:
        return {
            "error": f"Invalid action: {action}",
            "valid_actions": ["list", "add"],
        }


def get_privacy_dashboard() -> dict:
    """Erstellt eine umfassende Datenschutz-Uebersicht."""

    dashboard = store_get_dashboard()

    # Handlungsempfehlungen generieren
    action_items = []

    summary = dashboard["summary"]
    if summary["overdue_dsars"] > 0:
        action_items.append({
            "priority": "critical",
            "action": f"URGENT: {summary['overdue_dsars']} overdue DSAR(s) — GDPR violation risk! Respond immediately.",
        })
    if summary["critical_dsars"] > 0:
        action_items.append({
            "priority": "high",
            "action": f"{summary['critical_dsars']} DSAR(s) due within 3 days — prioritize these.",
        })
    if summary["open_dsars"] > 5:
        action_items.append({
            "priority": "medium",
            "action": f"{summary['open_dsars']} open DSARs — consider additional resources for processing.",
        })
    if dashboard["data_inventory"]["total_activities"] == 0:
        action_items.append({
            "priority": "high",
            "action": "No processing activities registered — Article 30 GDPR requires a record of processing activities.",
        })
    if dashboard["data_inventory"]["dpia_required"] > 0:
        action_items.append({
            "priority": "medium",
            "action": f"{dashboard['data_inventory']['dpia_required']} processing activit(ies) flagged for DPIA — ensure assessments are conducted (Article 35 GDPR).",
        })
    if dashboard["data_inventory"]["third_country_transfers"] > 0:
        action_items.append({
            "priority": "medium",
            "action": f"{dashboard['data_inventory']['third_country_transfers']} third-country transfer(s) — verify appropriate safeguards (Articles 44-49 GDPR).",
        })

    if not action_items:
        action_items.append({
            "priority": "info",
            "action": "No immediate action items — privacy compliance looks good.",
        })

    return {
        **dashboard,
        "action_items": action_items,
    }
