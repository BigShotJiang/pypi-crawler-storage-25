"""
GDPR-Compliance-Checker: Analysiert Beschreibungen von Datenverarbeitungen
auf GDPR-Konformitaet und gibt konkrete Hinweise.
"""

import re


# Echte GDPR-Regeln fuer den Compliance-Check
GDPR_RULES = [
    {
        "id": "GDPR-01",
        "name": "Legal basis required",
        "article": "Article 6",
        "description": "Every data processing activity must have a legal basis (consent, contract, legal obligation, vital interests, public interest, or legitimate interest).",
        "keywords": ["legal basis", "consent", "contract", "legitimate interest", "legal obligation"],
        "check": "negative",  # Fehlende Erwaehnung = Problem
        "severity": "critical",
    },
    {
        "id": "GDPR-02",
        "name": "Purpose limitation",
        "article": "Article 5(1)(b)",
        "description": "Data must be collected for specified, explicit and legitimate purposes and not further processed in a manner incompatible with those purposes.",
        "keywords": ["purpose", "reason", "goal", "objective", "use case"],
        "check": "negative",
        "severity": "high",
    },
    {
        "id": "GDPR-03",
        "name": "Data minimization",
        "article": "Article 5(1)(c)",
        "description": "Data collected must be adequate, relevant and limited to what is necessary.",
        "keywords": ["all data", "everything", "as much as possible", "comprehensive collection", "collect all"],
        "check": "positive",  # Erwaehnung = Problem
        "severity": "high",
    },
    {
        "id": "GDPR-04",
        "name": "Storage limitation",
        "article": "Article 5(1)(e)",
        "description": "Data must not be kept longer than necessary. A retention period must be defined.",
        "keywords": ["retention", "storage period", "deletion", "keep forever", "indefinitely", "no expiry"],
        "check": "mixed",
        "severity": "high",
    },
    {
        "id": "GDPR-05",
        "name": "Special categories of data",
        "article": "Article 9",
        "description": "Processing of sensitive data (health, biometric, genetic, racial, political, religious, sexual orientation, trade union) requires explicit consent or another Article 9(2) exemption.",
        "keywords": ["health", "biometric", "genetic", "racial", "ethnic", "political", "religious", "sexual", "trade union", "medical", "diagnosis", "patient"],
        "check": "positive",
        "severity": "critical",
    },
    {
        "id": "GDPR-06",
        "name": "Third-country transfer safeguards",
        "article": "Articles 44-49",
        "description": "Transfers of personal data to countries outside the EU/EEA require appropriate safeguards (adequacy decision, SCCs, BCRs).",
        "keywords": ["transfer", "third country", "outside eu", "us server", "cloud", "aws", "azure", "google cloud", "non-eu", "international"],
        "check": "positive",
        "severity": "high",
    },
    {
        "id": "GDPR-07",
        "name": "Data subject rights",
        "article": "Articles 15-22",
        "description": "Data subjects must be able to exercise their rights (access, rectification, erasure, portability, objection, restriction).",
        "keywords": ["no access", "cannot delete", "no opt-out", "no way to", "unable to request"],
        "check": "positive",
        "severity": "critical",
    },
    {
        "id": "GDPR-08",
        "name": "Privacy by design",
        "article": "Article 25",
        "description": "Data protection must be integrated into processing activities from the design stage (privacy by design and by default).",
        "keywords": ["privacy by design", "by default", "built-in", "from the start"],
        "check": "negative",
        "severity": "medium",
    },
    {
        "id": "GDPR-09",
        "name": "Data breach notification",
        "article": "Article 33-34",
        "description": "Data breaches must be reported to the supervisory authority within 72 hours. If there is a high risk to data subjects, they must also be notified.",
        "keywords": ["breach", "incident", "leak", "unauthorized access", "security incident"],
        "check": "awareness",
        "severity": "high",
    },
    {
        "id": "GDPR-10",
        "name": "Data Protection Impact Assessment (DPIA)",
        "article": "Article 35",
        "description": "A DPIA is required when processing is likely to result in a high risk to the rights and freedoms of data subjects (profiling, large-scale processing, systematic monitoring).",
        "keywords": ["profiling", "scoring", "automated decision", "large scale", "systematic monitoring", "surveillance", "tracking"],
        "check": "positive",
        "severity": "high",
    },
    {
        "id": "GDPR-11",
        "name": "Consent requirements",
        "article": "Article 7",
        "description": "Consent must be freely given, specific, informed and unambiguous. Pre-ticked boxes or inactivity do not constitute consent.",
        "keywords": ["pre-ticked", "pre-checked", "implied consent", "assumed consent", "opt-out only", "passive consent"],
        "check": "positive",
        "severity": "critical",
    },
    {
        "id": "GDPR-12",
        "name": "Children's data",
        "article": "Article 8",
        "description": "Processing children's data (under 16, or under 13-16 depending on member state) requires parental consent for information society services.",
        "keywords": ["children", "minors", "kids", "under 16", "under 13", "young people", "school", "student"],
        "check": "positive",
        "severity": "critical",
    },
    {
        "id": "GDPR-13",
        "name": "Transparency and information",
        "article": "Articles 13-14",
        "description": "Data subjects must be informed about who processes their data, for what purpose, and their rights — in clear and plain language.",
        "keywords": ["privacy notice", "privacy policy", "information", "transparency", "informed"],
        "check": "negative",
        "severity": "medium",
    },
    {
        "id": "GDPR-14",
        "name": "Security of processing",
        "article": "Article 32",
        "description": "Appropriate technical and organizational measures must be implemented to ensure data security (encryption, pseudonymization, access controls).",
        "keywords": ["unencrypted", "plain text", "no encryption", "no security", "publicly accessible", "no access control", "shared password"],
        "check": "positive",
        "severity": "critical",
    },
    {
        "id": "GDPR-15",
        "name": "Processor agreements",
        "article": "Article 28",
        "description": "When using data processors (third-party service providers), a data processing agreement (DPA) must be in place.",
        "keywords": ["processor", "third party", "service provider", "subcontractor", "vendor", "outsource"],
        "check": "awareness",
        "severity": "medium",
    },
]


def check_gdpr_compliance(description: str) -> dict:
    """
    Analysiert eine Beschreibung der Datenverarbeitung auf GDPR-Konformitaet.
    Gibt gefundene Probleme, Warnungen und Empfehlungen zurueck.
    """

    if not description or not description.strip():
        return {"error": "description is required — describe the data processing activity to analyze"}

    text = description.lower().strip()
    issues = []
    warnings = []
    recommendations = []
    passed = []

    for rule in GDPR_RULES:
        matched_keywords = [kw for kw in rule["keywords"] if kw.lower() in text]

        if rule["check"] == "negative":
            # Fehlende Erwaehnung = Problem
            if not matched_keywords:
                issues.append({
                    "rule_id": rule["id"],
                    "rule": rule["name"],
                    "article": rule["article"],
                    "severity": rule["severity"],
                    "issue": f"Not mentioned: {rule['description']}",
                    "recommendation": f"Ensure your processing addresses {rule['name']} ({rule['article']}).",
                })
            else:
                passed.append({
                    "rule_id": rule["id"],
                    "rule": rule["name"],
                    "article": rule["article"],
                    "matched": matched_keywords,
                })

        elif rule["check"] == "positive":
            # Erwaehnung = potentielles Problem / besondere Aufmerksamkeit
            if matched_keywords:
                if rule["severity"] == "critical":
                    issues.append({
                        "rule_id": rule["id"],
                        "rule": rule["name"],
                        "article": rule["article"],
                        "severity": rule["severity"],
                        "issue": f"Potential concern detected ({', '.join(matched_keywords)}): {rule['description']}",
                        "recommendation": f"Review compliance with {rule['article']} — this requires special attention.",
                    })
                else:
                    warnings.append({
                        "rule_id": rule["id"],
                        "rule": rule["name"],
                        "article": rule["article"],
                        "severity": rule["severity"],
                        "warning": f"Detected keywords ({', '.join(matched_keywords)}): {rule['description']}",
                        "recommendation": f"Verify compliance with {rule['article']}.",
                    })

        elif rule["check"] == "mixed":
            # Spezialbehandlung fuer Storage Limitation
            bad_keywords = ["keep forever", "indefinitely", "no expiry", "no deletion"]
            good_keywords = ["retention", "storage period", "deletion"]
            bad_matches = [kw for kw in bad_keywords if kw in text]
            good_matches = [kw for kw in good_keywords if kw in text]

            if bad_matches:
                issues.append({
                    "rule_id": rule["id"],
                    "rule": rule["name"],
                    "article": rule["article"],
                    "severity": rule["severity"],
                    "issue": f"Problematic storage practice detected ({', '.join(bad_matches)}): {rule['description']}",
                    "recommendation": "Define a clear retention period and implement automatic deletion.",
                })
            elif not good_matches:
                recommendations.append({
                    "rule_id": rule["id"],
                    "rule": rule["name"],
                    "article": rule["article"],
                    "recommendation": f"Consider defining a retention period ({rule['article']}).",
                })

        elif rule["check"] == "awareness":
            # Nur Hinweis wenn Keywords gefunden
            if matched_keywords:
                recommendations.append({
                    "rule_id": rule["id"],
                    "rule": rule["name"],
                    "article": rule["article"],
                    "recommendation": f"Relevant topic detected ({', '.join(matched_keywords)}): {rule['description']}",
                })

    # Compliance-Score berechnen
    total_rules = len(GDPR_RULES)
    critical_issues = [i for i in issues if i["severity"] == "critical"]
    high_issues = [i for i in issues if i["severity"] == "high"]
    medium_issues = [i for i in issues if i["severity"] == "medium"]

    # Punktabzug: kritisch = -15, hoch = -10, mittel = -5
    deductions = (len(critical_issues) * 15) + (len(high_issues) * 10) + (len(medium_issues) * 5)
    score = max(0, 100 - deductions)

    # Bewertung
    if score >= 90:
        grade = "A"
        verdict = "Excellent — minimal compliance concerns detected."
    elif score >= 75:
        grade = "B"
        verdict = "Good — some areas need attention."
    elif score >= 60:
        grade = "C"
        verdict = "Fair — several compliance issues to address."
    elif score >= 40:
        grade = "D"
        verdict = "Poor — significant compliance gaps detected."
    else:
        grade = "F"
        verdict = "Critical — major GDPR violations likely. Immediate action required."

    return {
        "compliance_score": score,
        "grade": grade,
        "verdict": verdict,
        "issues": issues,
        "warnings": warnings,
        "recommendations": recommendations,
        "passed_checks": passed,
        "summary": {
            "total_rules_checked": total_rules,
            "critical_issues": len(critical_issues),
            "high_issues": len(high_issues),
            "medium_issues": len(medium_issues),
            "warnings": len(warnings),
            "passed": len(passed),
        },
    }
