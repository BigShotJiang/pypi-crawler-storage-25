from monday.graphqlclient.client import GraphQLClient

_URLS = {
    'prod': 'https://api.monday.com/v2',
    'file': 'https://api.monday.com/v2/file'
}


class BaseResource:
    def __init__(self, token, headers, timeout=None):
        self._token = token
        kwargs = {}
        if timeout is not None:
            kwargs['timeout'] = timeout
        self.client = GraphQLClient(_URLS['prod'], **kwargs)
        self.file_upload_client = GraphQLClient(_URLS['file'], **kwargs)
        self.client.inject_token(token)
        self.client.inject_headers(headers)
        self.file_upload_client.inject_token(token)

    def _query(self, query):
        result = self.client.execute(query)

        if result:
            return result

    def __str__(self):
        return self.__class__.__name__

    def __repr__(self):
        return self.__class__.__name__
