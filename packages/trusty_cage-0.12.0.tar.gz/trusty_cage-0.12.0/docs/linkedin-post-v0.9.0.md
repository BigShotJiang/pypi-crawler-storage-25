A few weeks ago I shared trusty-cage — a CLI that creates isolated Docker containers for AI coding agents. The idea is simple: let Claude Code go wild without risking your host machine.

I've made some improvements since then. It's gone from "nice sandbox" to something closer to an orchestration platform.

Here's what's new:

**Autonomous mode (`tc launch`)**
Give the cage a prompt, walk away. Claude runs headless inside the container. When it's done, export the work, review the diff, push on your terms.

**Live observability (`tc logs`)**
Stream Claude's reasoning from outside the cage in real time. Color-coded output — thinking, tool calls, results, responses — so you can watch without interrupting.

**Container messaging (`tc inbox` / `tc outbox`)**
Two-way communication with the inner agent. Send instructions mid-task, receive progress updates, get notified when it's done. The agent posts structured messages (progress, errors, task complete) and you read them from the host.

**Multi-directory support (`tc add-dir`)**
Ship multiple local directories into a cage alongside the main project. Each gets its own volume and host clone. Great for monorepos or when the agent needs access to shared libraries.

**Bidirectional sync**
`tc export` brings work out. `tc sync` pushes files in. `tc diff` previews what either would change. Built-in protections: `.cageprotect` files, venv exclusion, cache artifact filtering, `.gitignore` backup on conflicts.

**Quality of life**

- Auto-rebuild when Dockerfile changes
- PyPI version checks on startup
- Post-export file-change summaries (N added, N modified, N deleted)
- `--stats` flag for lines-of-code diffs
- Custom Dockerfile support
- Create cages from local directories, not just git URLs

It's at v0.9.0 now. Still macOS-first (OrbStack/Docker Desktop), should work anywhere Docker runs.

I also built a complementary Claude Code skill — **cage-orchestrator** — that automates the entire workflow end-to-end. You describe a task, and the orchestrator creates the cage, launches an inner Claude with your prompt, monitors progress via structured messages, exports the results back to your repo, and lets you send revision feedback without restarting. It turns trusty-cage from a tool you drive manually into something closer to "dispatch and review."

The bigger picture: I've been using this to let Claude Code work autonomously on real projects — including improving trusty-cage itself. The container holds, the messaging works, and the iteration loop of "dispatch task → monitor → export → review → merge" is getting tighter every week.

If you tried v0.2 and bounced off it, give it another look. If you haven't tried it, `pip install trusty-cage` and let me know what breaks.

GitHub: https://lnkd.in/gu_WdN3K
PyPI: https://lnkd.in/gC5qiZwg

#opensource #ai #claudecode #devtools #python #docker
