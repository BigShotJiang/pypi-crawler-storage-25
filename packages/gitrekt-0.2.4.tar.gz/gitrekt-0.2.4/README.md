![GitRekt Banner](media/gitrekt_banner.svg)

# GitRekt

**Your codebase has a secret language. GitRekt translates it.**

GitRekt is a VS Code extension that does two things: it finds places in your code where the explanations are missing or out of date, and it lets you ask plain-English questions about your entire project and get instant, accurate answers with clickable links to the exact file and line.

---

## What can you ask GitRekt?

> *"Where is the database password stored?"*
> *"Which functions have no explanation?"*
> *"How does the login flow work?"*
> *"Where are HTTP requests made?"*
> *"What does the `parseRetryAfterMs` function do?"*
> *"Which files handle user authentication?"*
> *"Where is the API key set?"*
> *"How does error handling work in this project?"*

---

## Installation

### Step 1 — Install Python
Download Python from [python.org](https://www.python.org/downloads/).
**Important:** During installation, tick the box that says **"Add Python to PATH"**.

### Step 2 — Install GitRekt (backend + extension in one go)
Open a terminal and run both commands:
```
pip install gitrekt
gitrekt install-extension
```

The first command installs the Python backend. The second auto-installs the VS Code extension using the `code` CLI.

> **Alternative:** If `gitrekt install-extension` doesn't work, install manually:
> 1. Open VS Code → Press `Ctrl+Shift+X`
> 2. Search for **"GitRekt - Codebase Assistant"**
> 3. Click **Install**

### Step 3 — Reload VS Code
Press `Ctrl+Shift+P` → type **"Reload Window"** → press Enter. GitRekt will start automatically.

---

## AI Setup (Optional but Recommended)

GitRekt's scan and drift detection work **100% offline with no AI needed**. But for the chat feature to give plain-English answers, you need at least one of these:

### Option A — Free offline AI (Ollama)
Best for privacy. Works with no internet connection after setup.
1. Download [Ollama](https://ollama.com) and install it
2. Open a terminal and run:
```
ollama pull llama3
```
3. GitRekt automatically detects and uses it — no config needed

### Option B — Cloud AI (Groq, NVIDIA, Custom)
Faster responses. Requires an API key.
1. Open GitRekt chat in VS Code (`Ctrl+Shift+G`)
2. Click the **⚙️ (Settings)** icon at the top right
3. Paste your Groq, NVIDIA, or Custom API URL
4. Click **Save**

Keys are stored securely in VS Code's encrypted secret storage and never saved to a file or shared anywhere.

> **No AI configured?** GitRekt will show a banner in the chat with exact instructions. The core scan feature always works offline regardless.

---

## How it works

- **Scans your project** using real code analysis (no internet required, no AI needed for scanning)
- **Builds a searchable map** of every function, class, and file in your project
- **Answers questions** by finding the relevant code and explaining it in plain English

---

## What GitRekt will never do

- **Never sends your code to the internet for scanning** — the drift scan runs 100% on your machine
- **Never requires a paid subscription** — the core features are completely free
- **Never stores your code anywhere** — everything stays on your computer

---

## Usage

| Action | How |
|--------|-----|
| Open chat | Press `Ctrl+Shift+G` |
| Run a scan | Click the search icon in the GitRekt sidebar |
| Ignore an issue | Hover over it and click the 👁 button |
| Fix a missing comment | Hover over it and click the ✨ button |
| Undo a fix | Press `Ctrl+Z` in the file |
| Install extension from terminal | Run `gitrekt install-extension` |

---

## Contributing

GitRekt is open source (MIT). Pull requests welcome.

```
git clone https://github.com/Gauravguddeti/gitrekt
pip install -e .
```

---

*Built to make every developer's codebase feel like home.*
