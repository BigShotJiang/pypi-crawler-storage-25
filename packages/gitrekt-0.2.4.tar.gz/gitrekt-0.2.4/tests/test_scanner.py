"""
tests/test_scanner.py

Phase 1 verification test — scans the fixture files and confirms
that specific expected drift findings are detected.
"""

import sys
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from gitrekt.scanner.extractor import extract_functions
from gitrekt.scanner.detector import detect_drift, DriftType, scan_project


FIXTURES = Path(__file__).parent / "fixtures"


def test_python_fixture():
    """Verify drift detection on the Python fixture file."""
    path = FIXTURES / "sample_drift.py"
    assert path.exists(), f"Fixture not found: {path}"

    funcs = extract_functions(path)
    assert funcs, "No functions extracted from Python fixture"

    print(f"\n  Extracted {len(funcs)} functions from {path.name}:")
    for f in funcs:
        print(f"    - {f.name}() at line {f.start_line}, params={[p.name for p in f.params]}, doc={'YES' if f.docstring else 'NO'}")

    all_findings = []
    for func in funcs:
        findings = detect_drift(func)
        all_findings.extend(findings)

    print(f"\n  Found {len(all_findings)} drift issue(s):")
    for d in all_findings:
        print(f"    [{d.severity}] {d.drift_type.value} in `{d.function_name}` (line {d.line}): {d.message}")

    # Assertions — things we KNOW should be flagged
    drift_types = [d.drift_type for d in all_findings]
    func_names  = [d.function_name for d in all_findings]

    assert DriftType.PARAM_EXTRA_IN_DOC in drift_types, \
        "Expected PARAM_EXTRA_IN_DOC (email in process_user doc)"
    assert DriftType.PARAM_MISSING_IN_DOC in drift_types, \
        "Expected PARAM_MISSING_IN_DOC (role in process_user)"
    assert DriftType.RETURN_TYPE_MISMATCH in drift_types, \
        "Expected RETURN_TYPE_MISMATCH (str vs dict in process_user)"
    assert "fetch_data" in func_names or any(d.drift_type == DriftType.NO_DOCSTRING for d in all_findings), \
        "Expected NO_DOCSTRING for fetch_data"

    print("\n  ✅ All Python assertions passed.")
    return all_findings


def test_js_fixture():
    """Verify drift detection on the JavaScript fixture file."""
    path = FIXTURES / "sample_drift.js"
    assert path.exists(), f"Fixture not found: {path}"

    funcs = extract_functions(path)
    assert funcs, "No functions extracted from JS fixture"

    print(f"\n  Extracted {len(funcs)} functions from {path.name}:")
    for f in funcs:
        print(f"    - {f.name}() at line {f.start_line}, params={[p.name for p in f.params]}, doc={'YES' if f.docstring else 'NO'}")

    all_findings = []
    for func in funcs:
        findings = detect_drift(func)
        all_findings.extend(findings)

    print(f"\n  Found {len(all_findings)} drift issue(s):")
    for d in all_findings:
        print(f"    [{d.severity}] {d.drift_type.value} in `{d.function_name}` (line {d.line}): {d.message}")

    drift_types = [d.drift_type for d in all_findings]

    assert DriftType.PARAM_EXTRA_IN_DOC in drift_types, \
        "Expected PARAM_EXTRA_IN_DOC (carrier in calculateShipping doc)"
    assert DriftType.PARAM_MISSING_IN_DOC in drift_types or DriftType.NO_DOCSTRING in drift_types, \
        "Expected missing param or missing doc findings"

    print("\n  ✅ All JavaScript assertions passed.")
    return all_findings


def test_full_project_scan():
    """Verify the project-level scan entry point."""
    root = Path(__file__).parent.parent
    findings = scan_project(root)

    print(f"\n  Full project scan: {len(findings)} total finding(s) across all files")
    by_file = {}
    for f in findings:
        by_file.setdefault(Path(f.file).name, []).append(f)
    for fname, items in sorted(by_file.items()):
        print(f"    {fname}: {len(items)} issue(s)")

    print("\n  ✅ Project scan completed.")
    return findings


if __name__ == "__main__":
    print("=" * 60)
    print("gitrekt Phase 1 — Scanner Test")
    print("=" * 60)

    print("\n[1/3] Testing Python fixture...")
    py_findings = test_python_fixture()

    print("\n[2/3] Testing JavaScript fixture...")
    js_findings = test_js_fixture()

    print("\n[3/3] Full project scan...")
    all_findings = test_full_project_scan()

    print("\n" + "=" * 60)
    print(f"TOTAL FINDINGS: {len(all_findings)}")
    print("Phase 1 scanner: ALL TESTS PASSED ✅")
    print("=" * 60)
