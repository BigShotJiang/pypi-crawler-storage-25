"""
tests/test_git_analyzer.py

Phase 2 verification — enriches scan findings with git history and
confirms severity upgrades and staleness metadata are attached correctly.
"""

import sys
from pathlib import Path
from datetime import datetime, timezone

sys.path.insert(0, str(Path(__file__).parent.parent))

from gitrekt.scanner.detector import scan_project
from gitrekt.git_analyzer import enrich_findings, get_repo_info

ROOT = Path(__file__).parent.parent


def test_repo_info():
    """Confirm git repo is detected and has commits."""
    info = get_repo_info(ROOT)
    print(f"\n  Git repo info:")
    for k, v in info.items():
        print(f"    {k}: {v}")

    assert info["has_git"], "Expected a git repo at project root"
    assert info["commit_count"] >= 2, f"Expected >= 2 commits, got {info['commit_count']}"
    print("\n  [OK] Repo info looks good.")


def test_enriched_findings():
    """Run scan + git enrichment and verify metadata is attached."""
    findings = scan_project(ROOT)
    assert findings, "Expected drift findings before enrichment"

    print(f"\n  Raw findings (pre-git): {len(findings)}")

    enriched = enrich_findings(findings, ROOT)
    print(f"  Enriched findings: {len(enriched)}")

    # Verify metadata is attached
    with_git_data = [
        f for f in enriched
        if getattr(f, "git_code_changed_at", None) is not None
    ]
    print(f"  Findings with git commit data: {len(with_git_data)}")

    # Group by severity
    by_sev = {"LOW": [], "MEDIUM": [], "HIGH": []}
    for f in enriched:
        by_sev.setdefault(f.severity, []).append(f)

    print(f"\n  Severity breakdown:")
    for sev, items in by_sev.items():
        print(f"    {sev}: {len(items)} finding(s)")

    # Print top findings with dates
    print(f"\n  Sample enriched findings:")
    shown = 0
    for f in enriched:
        if shown >= 10:
            break
        code_dt = getattr(f, "git_code_changed_at", None)
        doc_dt  = getattr(f, "git_doc_changed_at",  None)
        days    = getattr(f, "git_staleness_days",   None)

        code_str = code_dt.strftime("%Y-%m-%d") if code_dt else "unknown"
        doc_str  = doc_dt.strftime("%Y-%m-%d")  if doc_dt  else "unknown"
        days_str = f"{days}d stale" if days is not None else "n/a"

        print(
            f"    [{f.severity}] {Path(f.file).name}:{f.line} "
            f"`{f.function_name}` — {f.drift_type.value}\n"
            f"           code last changed: {code_str} | doc last changed: {doc_str} | {days_str}"
        )
        shown += 1

    # Assertions
    assert len(enriched) > 0, "Expected findings after enrichment"
    assert any(hasattr(f, "git_staleness_days") for f in enriched), \
        "Expected git_staleness_days attribute on findings"
    assert any(f.severity in ("LOW", "MEDIUM", "HIGH") for f in enriched), \
        "Expected severity levels on all findings"

    print("\n  [OK] All enrichment assertions passed.")
    return enriched


def test_severity_distribution():
    """Confirm we get a non-trivial spread of severity levels."""
    findings  = scan_project(ROOT)
    enriched  = enrich_findings(findings, ROOT)

    sevs = {f.severity for f in enriched}
    print(f"\n  Severity levels present: {sevs}")

    # We should have at least LOW and HIGH present given our fixtures
    assert "LOW"  in sevs or "MEDIUM" in sevs, "Expected at least LOW or MEDIUM findings"
    print("  [OK] Severity distribution looks good.")


if __name__ == "__main__":
    print("=" * 60)
    print("gitrekt Phase 2 — Git-Aware Staleness Test")
    print("=" * 60)

    print("\n[1/3] Checking git repo info...")
    test_repo_info()

    print("\n[2/3] Testing enriched findings...")
    enriched = test_enriched_findings()

    print("\n[3/3] Checking severity distribution...")
    test_severity_distribution()

    print("\n" + "=" * 60)
    print("Phase 2 git analyzer: ALL TESTS PASSED")
    print("=" * 60)
