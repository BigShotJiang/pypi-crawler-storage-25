"""
gitrekt/chat_engine.py

GitRekt chat engine — indexes the codebase, retrieves relevant code snippets,
and answers natural-language questions via the configured LLM.

LLM chain:
  1. NVIDIA NIM (meta/llama-3.2-3b-instruct) — primary, fast (~2s)
  2. Groq (llama-3.3-70b-versatile)           — fallback if Groq key present
  3. Raw snippets only                         — no LLM available

Multi-turn: accepts history as list[{role, content}], keeps last 6 turns.
"""

from __future__ import annotations

import json
import urllib.request
import urllib.error
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from .indexer import CodebaseIndex, CodeChunk

# ── Singleton index cache (root → CodebaseIndex) ─────────────────────────────
_index_cache: dict[str, CodebaseIndex] = {}


def get_or_build_index(root: str, force: bool = False) -> CodebaseIndex:
    """Return cached index for root, building it if needed."""
    if root not in _index_cache or force:
        _index_cache[root] = CodebaseIndex.build(Path(root), embed=False)
    return _index_cache[root]


# ── Response model ────────────────────────────────────────────────────────────

@dataclass
class ChatReference:
    file:    str   # absolute path
    rel_file: str  # relative path for display
    line:    int
    label:   str   # e.g. "groqClient.js:18 — getAvailableKey"


@dataclass
class ChatResponse:
    answer:     str
    references: list[ChatReference] = field(default_factory=list)
    model_used: str = "none"
    error:      Optional[str] = None


# ── Context builder ───────────────────────────────────────────────────────────

MAX_CONTEXT_CHARS = 2500  # ~625 tokens — fast + focused, reduces hallucination risk


def build_context(chunks: list[CodeChunk], query: str) -> str:
    """
    Build an LLM-ready context string from ranked code chunks.
    Caps total chars at MAX_CONTEXT_CHARS.
    """
    lines = [
        "CODEBASE CONTEXT (relevant code snippets, ranked by relevance):",
        f"User question: {query}",
        "",
    ]
    used = 0
    for chunk in chunks:
        header = f"### [{chunk.rel_file}:{chunk.line}] {chunk.kind} `{chunk.name}`"
        body   = chunk.content[:500]
        entry  = f"{header}\n{body}\n"
        if used + len(entry) > MAX_CONTEXT_CHARS:
            break
        lines.append(entry)
        used += len(entry)

    return "\n".join(lines)


def extract_references(chunks: list[CodeChunk]) -> list[ChatReference]:
    """Convert chunks to ChatReference objects for the response."""
    seen = set()
    refs = []
    for chunk in chunks:
        key = (chunk.abs_file, chunk.line)
        if key in seen:
            continue
        seen.add(key)
        refs.append(ChatReference(
            file=chunk.abs_file,
            rel_file=chunk.rel_file,
            line=chunk.line,
            label=f"{chunk.rel_file}:{chunk.line} — {chunk.name}",
        ))
    return refs


# ── System prompt ─────────────────────────────────────────────────────────────

SYSTEM_PROMPT = """You are GitRekt, a codebase Q&A assistant in VS Code.
The user message contains real code snippets indexed from their project. Use them to answer.

RULES:
- Answer ONLY based on what is shown in the code snippets. Do not invent code.
- Cite files inline like: [groqClient.js:18]
- If the snippets don't contain the answer, say exactly: "That wasn't found in the indexed snippets — try asking about a specific file or function name."
- Be concise. Bullet points for multiple items.
- You may explain what the code does in plain English."""


# ── LLM clients ───────────────────────────────────────────────────────────────

def _call_litellm(
    messages: list[dict],
    api_key: str,
    model: str,
    base_url: Optional[str] = None,
    max_tokens: int = 1024,
) -> Optional[str]:
    """Call any LLM provider via LiteLLM. Returns response text or None."""
    try:
        import litellm
        
        # Auto-detect model if missing but we know the key format
        if not model:
            if api_key.startswith("gsk_"):
                model = "groq/llama-3.3-70b-versatile"
            elif api_key.startswith("nvapi-"):
                model = "nvidia/meta/llama-3.2-3b-instruct"
            elif api_key.startswith("sk-ant-"):
                model = "anthropic/claude-3-5-sonnet-20241022"
            else:
                model = "openai/gpt-4o-mini" # Generic fallback if user left it blank
                
        # Litellm kwargs
        kwargs = {
            "model": model,
            "messages": messages,
            "api_key": api_key,
            "temperature": 0.2,
            "max_tokens": max_tokens,
        }
        if base_url:
            kwargs["api_base"] = base_url
            
        # Optional: Disable litellm telemetry and logging for privacy
        litellm.telemetry = False

        resp = litellm.completion(**kwargs)
        return resp.choices[0].message.content.strip()
    except Exception as e:
        print(f"LiteLLM Error: {e}")
        return None


# Embedding model name fragments to exclude from auto-selection
_EMBED_KEYWORDS = ("embed", "nomic", "bge", "e5", "minilm", "rerank")


def _pick_best_ollama_model(ollama_url: str = "http://localhost:11434") -> Optional[str]:
    """
    Query Ollama's /api/tags, filter out embedding models, sort by size
    (largest first), return the best model name. Returns None if Ollama
    is not running or has no usable models.
    """
    try:
        req = urllib.request.Request(
            f"{ollama_url.rstrip('/')}/api/tags",
            headers={"Accept": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=3) as resp:
            data = json.loads(resp.read().decode())
    except Exception:
        return None

    models = data.get("models", [])
    usable = [
        m for m in models
        if not any(kw in m.get("name", "").lower() for kw in _EMBED_KEYWORDS)
    ]
    if not usable:
        return None

    # Sort by size (bytes) descending — pick the most capable one
    usable.sort(key=lambda m: m.get("size", 0), reverse=True)
    return usable[0]["name"]


def _call_ollama(
    messages: list[dict],
    model: str,
    ollama_url: str = "http://localhost:11434",
) -> Optional[str]:
    """Call Ollama chat API. Returns response text or None on failure."""
    payload = json.dumps({
        "model":    model,
        "messages": messages,
        "stream":   False,
        "options":  {"temperature": 0.2},
    }).encode()
    req = urllib.request.Request(
        f"{ollama_url.rstrip('/')}/api/chat",
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            data = json.loads(resp.read().decode())
            return data["message"]["content"].strip()
    except Exception:
        return None


# ── Main chat function ────────────────────────────────────────────────────────

def chat(
    query:   str,
    root:    str,
    history: list[dict] | None = None,
    api_key: str = "",
    model: str = "",
    base_url: str = "",
    # Legacy params kept for back-compat
    groq_api_key: str = "",
    custom_url: str = "",
    ollama_url:   str = "",
    ollama_model: str = "",
) -> ChatResponse:
    """
    Answer a user query about the codebase.

    Args:
        query:   The user's question.
        root:    Absolute path to the project root.
        history: Prior conversation turns [{role, content}, ...].
                 Last 6 turns kept for context.
        api_key: LLM API key.

    Returns:
        ChatResponse with answer text and file references.
    """
    # Resolve key — new api_key param takes priority over legacy params
    resolved_key = api_key or groq_api_key
    resolved_url = base_url or custom_url
    # ── 1. Get/build index ───────────────────────────────────────────────
    try:
        idx = get_or_build_index(root)
    except Exception as e:
        return ChatResponse(answer="", error=f"Failed to build index: {e}")

    # ── 2. Search index for relevant chunks ──────────────────────────────
    chunks = idx.search(query, top_n=10)
    references = extract_references(chunks[:6])  # show top 6 refs in UI

    if not chunks:
        return ChatResponse(
            answer="I couldn't find any relevant code for your question. "
                   "Try rephrasing or check that the project path is correct.",
            references=[],
            model_used="none",
        )

    # ── 3. Build context + messages ──────────────────────────────────────
    context = build_context(chunks, query)
    history = (history or [])[-6:]  # keep last 6 turns

    messages: list[dict] = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user",   "content": context},
        {"role": "assistant", "content": "Understood. I have reviewed the codebase context. What is your question?"},
    ]
    messages.extend(history)
    messages.append({"role": "user", "content": query})

    # ── 4. LLM chain ─────────────────────────────────────────────────────
    answer = None
    model_used = "none"

    # 1. Cloud LLM via LiteLLM
    if resolved_key or resolved_url:
        answer = _call_litellm(messages, resolved_key, model, resolved_url)
        if answer:
            model_used = model if model else "cloud_llm"

    # 4. Ollama — auto-pick the largest locally installed model
    if not answer:
        best_model = _pick_best_ollama_model()
        if best_model:
            answer = _call_ollama(messages, best_model)
            if answer:
                model_used = f"ollama/{best_model}"

    # Final fallback: just show raw snippets
    if not answer:
        lines = [
            "1. Add an API key in the VS Code Settings ⚙️ menu (e.g. OpenAI, Anthropic, Gemini, Groq)\n",
            "2. Or install Ollama and run `ollama pull llama3` in your terminal for offline AI.\n\n",
            "Here are the most relevant code snippets I found:\n"
        ]
        for chunk in chunks[:5]:
            lines.append(f"**[{chunk.rel_file}:{chunk.line}]** `{chunk.name}`")
            lines.append(f"```\n{chunk.content[:300]}\n```\n")
        answer = "\n".join(lines)
        model_used = "snippets_only"

    return ChatResponse(
        answer=answer,
        references=references,
        model_used=model_used,
    )
