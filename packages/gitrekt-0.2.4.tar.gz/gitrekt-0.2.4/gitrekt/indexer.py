"""
gitrekt/indexer.py

Lightweight in-memory codebase index for GitRekt chat.

Design goals
------------
- Zero new heavy dependencies (uses existing Tree-sitter + Python stdlib)
- Builds in < 2s for projects up to ~5000 functions
- Two-tier search:
    1. Keyword index (instant, exact/partial term matching)
    2. Semantic reranking via nomic-embed-text (Ollama) if available
- Exposes a clean search(query) → list[CodeChunk] API

Index structure
---------------
Every function, class, and top-level comment block becomes a CodeChunk.
Each chunk stores: file path, line range, kind, name, raw text, keywords.
A keyword → [chunk_idx, ...] inverted index allows O(k) lookup.
"""

from __future__ import annotations

import re
import math
import json
import time
import urllib.request
import urllib.error
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional
from collections import defaultdict

from .scanner.parser import walk_project, parse_file, SUPPORTED_EXTENSIONS
from .scanner.extractor import extract_functions


# ── Stop words (excluded from keyword index) ──────────────────────────────────
_STOP = frozenset(
    "a an the is are was were be been being have has had do does did "
    "will would could should may might must shall can this that these "
    "those it its and or not in of to for with from at by on as if "
    "return def class import from pass self true false none null "
    "undefined var let const function async await export default".split()
)


# ── Data structures ───────────────────────────────────────────────────────────

@dataclass
class CodeChunk:
    """A single indexable unit — function, class body, or comment block."""
    abs_file:  str         # absolute path
    rel_file:  str         # relative to project root
    line:      int         # start line (1-indexed)
    end_line:  int         # end line (1-indexed)
    kind:      str         # "function" | "class" | "file"
    name:      str         # function/class name or filename stem
    content:   str         # raw source text (may be truncated to 300 chars for index)
    summary:   str         # docstring or first meaningful comment
    keywords:  frozenset   # lowercased tokens for keyword matching
    score:     float = 0.0 # filled in during search


@dataclass
class IndexStats:
    file_count:     int = 0
    chunk_count:    int = 0
    build_time_ms:  int = 0
    has_embeddings: bool = False


class CodebaseIndex:
    """
    In-memory codebase index.

    Usage
    -----
    idx = CodebaseIndex.build(Path("d:/projects/myproject"))
    results = idx.search("where is the Groq API key set", top_n=8)
    for chunk, score in results:
        print(f"{chunk.rel_file}:{chunk.line}  [{score:.2f}]  {chunk.name}")
    """

    def __init__(self) -> None:
        self.chunks:   list[CodeChunk]        = []
        self._inv:     dict[str, list[int]]   = defaultdict(list)  # keyword → chunk indices
        self._embeds:  Optional[list]         = None  # list of embedding vectors (numpy-free)
        self.stats:    IndexStats             = IndexStats()
        self.root:     str                    = ""

    # ── Build ─────────────────────────────────────────────────────────────────

    @classmethod
    def build(
        cls,
        root: Path,
        ignored_dirs: set[str] | None = None,
        embed: bool = True,
    ) -> "CodebaseIndex":
        """
        Build a full index of the project.

        Args:
            root:        Project root directory.
            ignored_dirs: Directories to skip.
            embed:       Attempt to embed chunks via nomic-embed-text (Ollama).

        Returns:
            A fully built CodebaseIndex ready for search.
        """
        t0 = time.perf_counter()
        idx = cls()
        idx.root = str(root)

        if ignored_dirs is None:
            ignored_dirs = {
                ".git", "node_modules", "__pycache__", ".venv",
                "venv", "env", "dist", "build", ".next",
            }

        files = walk_project(root, ignored_dirs)
        idx.stats.file_count = len(files)

        for file_path in files:
            idx._index_file(file_path, root)

        # Build inverted index
        for i, chunk in enumerate(idx.chunks):
            for kw in chunk.keywords:
                idx._inv[kw].append(i)

        idx.stats.chunk_count = len(idx.chunks)
        idx.stats.build_time_ms = int((time.perf_counter() - t0) * 1000)

        # Optionally build embeddings (non-blocking — skip if Ollama down)
        if embed:
            try:
                idx._build_embeddings()
                idx.stats.has_embeddings = True
            except Exception:
                pass  # Embeddings are a nice-to-have; keyword search still works

        return idx

    def _index_file(self, file_path: Path, root: Path) -> None:
        """Extract chunks from a single file and add to self.chunks."""
        try:
            rel = str(file_path.relative_to(root)).replace("\\", "/")
        except ValueError:
            rel = str(file_path).replace("\\", "/")

        # ── Function-level chunks (via existing extractor) ─────────────────
        try:
            funcs = extract_functions(file_path)
        except Exception:
            funcs = []

        for func in funcs:
            # Skip tiny or private helpers (optional noise reduction)
            # Keep private functions — users may ask about them
            body = func.body_text or ""
            # Truncate very long bodies to 400 chars for the index
            preview = body[:400] if len(body) > 400 else body
            summary = func.docstring[:200] if func.docstring else _first_comment(body)

            param_names = " ".join(
                p.name if hasattr(p, "name") else str(p) for p in func.params
            )
            kws = _keywords(
                f"{func.name} {summary} {param_names} {file_path.stem}"
            )

            chunk = CodeChunk(
                abs_file=str(file_path),
                rel_file=rel,
                line=func.start_line,
                end_line=func.end_line,
                kind="function",
                name=func.name,
                content=preview,
                summary=summary,
                keywords=frozenset(kws),
            )
            self.chunks.append(chunk)

        # ── File-level chunk (whole file summary if < 100 lines) ──────────
        try:
            source = file_path.read_text(encoding="utf-8", errors="ignore")
            lines  = source.splitlines()
            if len(lines) <= 100:
                preview = source[:600]
            else:
                # First 20 lines as file-level summary
                preview = "\n".join(lines[:20])

            kws = _keywords(f"{file_path.stem} {file_path.name} {preview}")
            chunk = CodeChunk(
                abs_file=str(file_path),
                rel_file=rel,
                line=1,
                end_line=len(lines),
                kind="file",
                name=file_path.name,
                content=preview,
                summary=_first_comment(source),
                keywords=frozenset(kws),
            )
            self.chunks.append(chunk)
        except Exception:
            pass

    # ── Embeddings (nomic-embed-text via Ollama) ──────────────────────────────

    def _build_embeddings(self, ollama_url: str = "http://localhost:11434") -> None:
        """
        Embed each chunk's name+summary using nomic-embed-text.
        Stores as plain Python lists (no numpy required).
        """
        texts = [f"{c.name}: {c.summary or c.content[:100]}" for c in self.chunks]
        self._embeds = []
        for text in texts:
            vec = _embed(text, ollama_url)
            self._embeds.append(vec)

    def _embed_query(self, query: str, ollama_url: str = "http://localhost:11434"):
        """Embed a single query string."""
        return _embed(query, ollama_url)

    # ── Search ────────────────────────────────────────────────────────────────

    def search(
        self,
        query: str,
        top_n: int = 10,
        ollama_url: str = "http://localhost:11434",
    ) -> list[CodeChunk]:
        """
        Search the index for chunks relevant to query.

        Args:
            query:    Natural language question or keyword string.
            top_n:    Number of top results to return.
            ollama_url: Ollama base URL for embedding the query.

        Returns:
            List of CodeChunk objects sorted by relevance (highest first).
        """
        query_kws = _keywords(query)
        if not query_kws:
            return []

        # ── Keyword scoring ───────────────────────────────────────────────
        scores: dict[int, float] = defaultdict(float)

        total_chunks = len(self.chunks)
        for kw in query_kws:
            # Exact match
            for idx in self._inv.get(kw, []):
                # TF-IDF-like: rare keywords score higher
                df = len(self._inv.get(kw, []))
                idf = math.log((total_chunks + 1) / (df + 1)) + 1.0
                scores[idx] += idf

            # Prefix match (e.g. "gro" matches "groq")
            for indexed_kw, idxs in self._inv.items():
                if len(kw) >= 3 and indexed_kw.startswith(kw) and indexed_kw != kw:
                    for idx in idxs:
                        scores[idx] += 0.5

        # Bonus: function name or file name exactly matches a query keyword
        for idx, chunk in enumerate(self.chunks):
            name_kws = _keywords(chunk.name)
            overlap = query_kws & name_kws
            if overlap:
                scores[idx] += len(overlap) * 2.0  # strong bonus for name match

        # ── Semantic reranking (if embeddings available) ───────────────────
        if self._embeds:
            try:
                q_vec = self._embed_query(query, ollama_url)
                for idx, chunk_vec in enumerate(self._embeds):
                    if chunk_vec and q_vec:
                        sim = _cosine(q_vec, chunk_vec)
                        scores[idx] = scores.get(idx, 0.0) + sim * 3.0  # weight semantic heavily
            except Exception:
                pass  # fall back to pure keyword score

        # ── Rank + return top_n ───────────────────────────────────────────
        ranked = sorted(scores.items(), key=lambda x: x[1], reverse=True)[:top_n]
        results = []
        for idx, score in ranked:
            chunk = self.chunks[idx]
            chunk.score = score
            results.append(chunk)

        return results

    def rebuild(self, root: Path, ignored_dirs: set[str] | None = None) -> None:
        """Clear and rebuild the index in-place (called on file save)."""
        new = CodebaseIndex.build(root, ignored_dirs)
        self.chunks  = new.chunks
        self._inv    = new._inv
        self._embeds = new._embeds
        self.stats   = new.stats
        self.root    = new.root


# ── Helpers ───────────────────────────────────────────────────────────────────

def _keywords(text: str) -> frozenset:
    """Tokenize text into lowercase keyword tokens, removing stop words."""
    tokens = re.findall(r"[a-zA-Z_][a-zA-Z0-9_]*", text.lower())
    # Also split camelCase: "getUserById" → ["get", "user", "by", "id"]
    expanded = []
    for tok in tokens:
        parts = re.sub(r"([a-z])([A-Z])", r"\1 \2", tok).lower().split()
        expanded.extend(parts)
        expanded.append(tok)
    return frozenset(t for t in expanded if t not in _STOP and len(t) >= 2)


def _first_comment(source: str) -> str:
    """Extract the first comment or docstring from source text."""
    # Python docstring
    m = re.search(r'"""(.*?)"""', source, re.DOTALL)
    if m:
        return m.group(1).strip()[:200]
    # JS/Python single-line comment
    m = re.search(r"#\s*(.+)|//\s*(.+)", source)
    if m:
        return (m.group(1) or m.group(2) or "").strip()[:200]
    return ""


def _embed(text: str, ollama_url: str) -> list[float] | None:
    """Call nomic-embed-text via Ollama to get a float embedding vector."""
    payload = json.dumps({"model": "nomic-embed-text:latest", "prompt": text}).encode()
    req = urllib.request.Request(
        f"{ollama_url}/api/embeddings",
        data=payload,
        headers={"Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read().decode())
            return data.get("embedding")
    except Exception:
        return None


def _cosine(a: list[float], b: list[float]) -> float:
    """Cosine similarity between two float vectors (no numpy)."""
    if not a or not b or len(a) != len(b):
        return 0.0
    dot  = sum(x * y for x, y in zip(a, b))
    na   = math.sqrt(sum(x * x for x in a))
    nb   = math.sqrt(sum(x * x for x in b))
    if na == 0 or nb == 0:
        return 0.0
    return dot / (na * nb)


# ── CLI test entrypoint ────────────────────────────────────────────────────────

if __name__ == "__main__":
    import sys

    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    query = " ".join(sys.argv[2:]) if len(sys.argv) > 2 else "where is the API key set"

    print(f"Building index for: {root}")
    idx = CodebaseIndex.build(root)
    print(
        f"Indexed {idx.stats.chunk_count} chunks from {idx.stats.file_count} files "
        f"in {idx.stats.build_time_ms}ms "
        f"({'with' if idx.stats.has_embeddings else 'without'} embeddings)"
    )
    print(f"\nQuery: '{query}'\n{'-'*60}")

    results = idx.search(query, top_n=8)
    if not results:
        print("No results found.")
    else:
        for chunk in results:
            print(
                f"[{chunk.score:.2f}] {chunk.rel_file}:{chunk.line}"
                f"  ({chunk.kind})  {chunk.name}"
            )
            if chunk.summary:
                print(f"       {chunk.summary[:100]}")
            print()
