"""
gitrekt/cli.py

Terminal CLI for gitrekt — powered by Click + Rich.

Commands
--------
  gitrekt scan    Full scan, prints rich report to terminal
  gitrekt watch   Re-scans on every file save (Watchdog)
  gitrekt report  Exports findings as a markdown file
  gitrekt init    Interactive config setup wizard
"""

from __future__ import annotations

import json
import sys
import time
from pathlib import Path
from datetime import datetime
from typing import Optional

import click
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.text import Text
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich import box
from rich.rule import Rule
from rich.markdown import Markdown

from .scanner.detector import scan_project, DriftFinding, DriftType
from .git_analyzer import enrich_findings, get_repo_info
from .llm import groq_client, ollama_client

console = Console()

# ── Severity colours ─────────────────────────────────────────────────────────
SEV_STYLE = {
    "LOW":    "bold yellow",
    "MEDIUM": "bold orange1",
    "HIGH":   "bold red",
}

use_ascii = (sys.stdout.encoding or "utf-8").lower() not in ("utf-8", "utf8")

if use_ascii:
    SEV_ICON = {
        "LOW":    "[L]",
        "MEDIUM": "[M]",
        "HIGH":   "[H]",
    }
    DRIFT_ICON = {
        DriftType.PARAM_MISSING_IN_DOC:  "*",
        DriftType.PARAM_EXTRA_IN_DOC:    "*",
        DriftType.PARAM_TYPE_MISMATCH:   "*",
        DriftType.RETURN_TYPE_MISMATCH:  "*",
        DriftType.NO_DOCSTRING:          "*",
        DriftType.EMPTY_DOCSTRING:       "*",
        DriftType.RAISES_UNDOCUMENTED:   "*",
    }
else:
    SEV_ICON = {
        "LOW":    "●",
        "MEDIUM": "◆",
        "HIGH":   "■",
    }

    DRIFT_ICON = {
        DriftType.PARAM_MISSING_IN_DOC:  "📭",
        DriftType.PARAM_EXTRA_IN_DOC:    "👻",
        DriftType.PARAM_TYPE_MISMATCH:   "🔀",
        DriftType.RETURN_TYPE_MISMATCH:  "↩️ ",
        DriftType.NO_DOCSTRING:          "📋",
        DriftType.EMPTY_DOCSTRING:       "🈳",
        DriftType.RAISES_UNDOCUMENTED:   "💥",
    }


# ── Config helpers ────────────────────────────────────────────────────────────

def _config_path(root: Path) -> Optional[Path]:
    current = root.resolve()
    while current != current.parent:
        cfg = current / ".gitrekt" / "config.json"
        if cfg.exists():
            return cfg
        current = current.parent
    return None


def _load_config(root: Path) -> dict:
    cfg = _config_path(root)
    if cfg and cfg.exists():
        try:
            return json.loads(cfg.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {}


def _default_ignored() -> list[str]:
    return [
        ".git", "node_modules", "__pycache__", ".venv",
        "venv", "env", "dist", "build", ".next",
    ]


# ── Rendering helpers ─────────────────────────────────────────────────────────

def _render_findings(findings: list[DriftFinding], root: Path, show_git: bool = True) -> None:
    """Print a rich formatted table of findings grouped by file."""
    if not findings:
        console.print(
            Panel("[bold green]No drift detected![/bold green] Documentation looks up to date.",
                  title="gitrekt", border_style="green")
        )
        return

    # Group by file
    by_file: dict[str, list[DriftFinding]] = {}
    for f in findings:
        key = str(Path(f.file).relative_to(root)) if Path(f.file).is_absolute() else f.file
        by_file.setdefault(key, []).append(f)

    total = len(findings)
    high  = sum(1 for f in findings if f.severity == "HIGH")
    med   = sum(1 for f in findings if f.severity == "MEDIUM")
    low   = sum(1 for f in findings if f.severity == "LOW")

    console.print()
    if use_ascii:
        console.print(Rule("[bold cyan]GitRekt - Scan Results[/bold cyan]", style="cyan", characters="-"))
    else:
        console.print(Rule("[bold cyan]gitrekt — Scan Results[/bold cyan]", style="cyan"))
    console.print(
        f"  Found [bold]{total}[/bold] issue(s) across "
        f"[bold]{len(by_file)}[/bold] file(s):  "
        f"[bold red]{high} HIGH[/bold red]  "
        f"[bold orange1]{med} MEDIUM[/bold orange1]  "
        f"[bold yellow]{low} LOW[/bold yellow]"
    )
    console.print()

    for rel_path, items in sorted(by_file.items()):
        # File header
        file_high = sum(1 for i in items if i.severity == "HIGH")
        badge = f"[bold red]{file_high}H[/bold red] " if file_high else ""
        console.print(f"  [bold cyan]{rel_path}[/bold cyan]  {badge}({len(items)} issue(s))")

        table = Table(
            show_header=True,
            header_style="bold dim",
            box=box.ASCII if use_ascii else box.SIMPLE_HEAD,
            padding=(0, 1),
            expand=True,
        )
        table.add_column("Line",    style="dim",        width=6,  no_wrap=True)
        table.add_column("Sev",     width=8,  no_wrap=True)
        table.add_column("Function", style="bold",      width=20, no_wrap=True)
        table.add_column("Type",    style="dim cyan",   width=22, no_wrap=True)
        table.add_column("Message", no_wrap=False)
        if show_git:
            table.add_column("Stale",   style="dim",   width=10, no_wrap=True)

        for item in sorted(items, key=lambda x: x.line):
            sev_text = Text(
                f"{SEV_ICON[item.severity]} {item.severity}",
                style=SEV_STYLE[item.severity],
            )
            icon = DRIFT_ICON.get(item.drift_type, "?")
            dtype = item.drift_type.value.replace("_", " ").title()

            row = [
                str(item.line),
                sev_text,
                item.function_name[:20],
                f"{icon} {dtype}",
                item.message,
            ]
            if show_git:
                days = getattr(item, "git_staleness_days", None)
                fallback = "-" if use_ascii else "—"
                stale_str = f"{days}d" if days is not None else fallback
                row.append(stale_str)

            table.add_row(*row)

            # If there's a suggested fix, show it in a sub-row spanning columns
            suggestion = getattr(item, "suggested_fix", None)
            if suggestion:
                cols = 6 if show_git else 5
                # Simple sub-row just under the message
                table.add_row("", "", "", "", Panel(Markdown(suggestion), title="[bold green]Suggested Fix[/bold green]", border_style="green"), "")

        console.print(table)

    if use_ascii:
        console.print(Rule(style="dim", characters="-"))
    else:
        console.print(Rule(style="dim"))


def _render_markdown(findings: list[DriftFinding], root: Path) -> str:
    """Render findings as a markdown report string."""
    lines: list[str] = []
    lines.append("# gitrekt — Drift Report")
    lines.append(f"\n**Generated**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    lines.append(f"**Project**: `{root}`")
    lines.append(f"**Total findings**: {len(findings)}")

    high   = sum(1 for f in findings if f.severity == "HIGH")
    medium = sum(1 for f in findings if f.severity == "MEDIUM")
    low    = sum(1 for f in findings if f.severity == "LOW")
    lines.append(f"\n| Severity | Count |\n|----------|-------|")
    lines.append(f"| 🔴 HIGH   | {high}     |")
    lines.append(f"| 🟠 MEDIUM | {medium}     |")
    lines.append(f"| 🟡 LOW    | {low}     |")

    by_file: dict[str, list[DriftFinding]] = {}
    for f in findings:
        key = str(Path(f.file).relative_to(root)) if Path(f.file).is_absolute() else f.file
        by_file.setdefault(key, []).append(f)

    lines.append("\n---\n")

    for rel_path, items in sorted(by_file.items()):
        lines.append(f"\n## `{rel_path}`\n")
        lines.append("| Line | Severity | Function | Type | Message | Stale |")
        lines.append("|------|----------|----------|------|---------|-------|")
        for item in sorted(items, key=lambda x: x.line):
            days = getattr(item, "git_staleness_days", None)
            stale = f"{days}d" if days is not None else "—"
            dtype = item.drift_type.value.replace("_", " ").title()
            lines.append(
                f"| {item.line} | {item.severity} | `{item.function_name}` "
                f"| {dtype} | {item.message} | {stale} |"
            )

    lines.append("\n---\n*Generated by [gitrekt](https://github.com/gitrekt/gitrekt)*")
    return "\n".join(lines)


# ── CLI entry point ───────────────────────────────────────────────────────────

@click.group()
@click.version_option("0.1.0", prog_name="gitrekt")
def cli():
    """
    gitrekt — detects when comments, docstrings, and docs go stale
    compared to actual code. Like a spell-checker for documentation accuracy.
    """
    pass


# ── gitrekt scan ─────────────────────────────────────────────────────────────

@cli.command()
@click.argument("path", default=".", type=click.Path(exists=True))
@click.option("--no-git",    is_flag=True, default=False, help="Skip git history enrichment.")
@click.option("--severity",  default="LOW", type=click.Choice(["LOW","MEDIUM","HIGH"]),
              help="Minimum severity to show (default: LOW).")
@click.option("--output",    default=None, type=click.Path(), help="Write markdown report to this file.")
@click.option("--suggest",   is_flag=True, default=False, help="Request LLM fix suggestions (Phase 4).")
@click.option("--json",      "as_json", is_flag=True, default=False, help="Output as JSON.")
def scan(path: str, no_git: bool, severity: str, output: Optional[str], suggest: bool, as_json: bool):
    """
    Scan a project directory for stale documentation.

    PATH defaults to the current directory.
    """
    root = Path(path).resolve()
    cfg  = _load_config(root)
    ignored = set(cfg.get("ignored_dirs", _default_ignored()))

    sev_rank = {"LOW": 0, "MEDIUM": 1, "HIGH": 2}
    min_rank = sev_rank[severity]

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        transient=True,
        console=console,
    ) as progress:
        task = progress.add_task("Scanning files...", total=None)

        findings = scan_project(root, ignored)
        progress.update(task, description="Analysing git history...")

        if not no_git:
            findings = enrich_findings(findings, root)

    # Filter by minimum severity
    findings = [f for f in findings if sev_rank.get(f.severity, 0) >= min_rank]

    if suggest and findings:
        api_key = cfg.get("groq_api_key", "")
        use_ollama = cfg.get("use_ollama", False)
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            transient=True,
            console=console,
        ) as progress:
            task = progress.add_task("Generating fix suggestions via LLM...", total=len(findings))
            for f in findings:
                if not f.func_info:
                    progress.advance(task)
                    continue
                
                suggestion = None
                if api_key:
                    suggestion = groq_client.suggest_fix(f, f.func_info, api_key)
                if not suggestion and use_ollama:
                    url = cfg.get("ollama_url", "http://localhost:11434")
                    model = cfg.get("ollama_model", "llama3")
                    suggestion = ollama_client.suggest_fix(f, f.func_info, model, url)
                
                if suggestion:
                    f.suggested_fix = suggestion
                
                progress.advance(task)

    if as_json:
        import json as _json
        out = []
        for f in findings:
            out.append({
                "file":          f.file,
                "line":          f.line,
                "function":      f.function_name,
                "drift_type":    f.drift_type.value,
                "severity":      f.severity,
                "message":       f.message,
                "staleness_days": getattr(f, "git_staleness_days", None),
            })
        click.echo(_json.dumps(out, indent=2))
        return

    _render_findings(findings, root, show_git=not no_git)

    if output:
        md = _render_markdown(findings, root)
        out_path = Path(output)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(md, encoding="utf-8")
        console.print(f"  [green]Report written to[/green] [bold]{output}[/bold]")

    # Exit code: 1 if HIGH findings, 0 otherwise (useful for CI)
    if any(f.severity == "HIGH" for f in findings):
        sys.exit(1)


# ── gitrekt report ───────────────────────────────────────────────────────────

@cli.command()
@click.argument("path", default=".", type=click.Path(exists=True, file_okay=False))
@click.option("--output", "-o", default="gitrekt-report.md", show_default=True,
              help="Output file path.")
@click.option("--no-git", is_flag=True, default=False)
def report(path: str, output: str, no_git: bool):
    """Export a full drift report to a markdown file."""
    root = Path(path).resolve()
    cfg  = _load_config(root)
    ignored = set(cfg.get("ignored_dirs", _default_ignored()))

    with Progress(SpinnerColumn(), TextColumn("{task.description}"), transient=True, console=console) as p:
        t = p.add_task("Scanning...", total=None)
        findings = scan_project(root, ignored)
        p.update(t, description="Git enrichment...")
        if not no_git:
            findings = enrich_findings(findings, root)

    md = _render_markdown(findings, root)
    out_path = Path(output)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(md, encoding="utf-8")

    console.print(
        Panel(
            f"[bold green]Report saved![/bold green]\n"
            f"[dim]{out_path.resolve()}[/dim]\n"
            f"[bold]{len(findings)}[/bold] finding(s) documented.",
            title="gitrekt Report",
            border_style="green",
        )
    )


# ── gitrekt watch ────────────────────────────────────────────────────────────

@cli.command()
@click.argument("path", default=".", type=click.Path(exists=True, file_okay=False))
@click.option("--no-git", is_flag=True, default=False)
@click.option("--severity", default="LOW", type=click.Choice(["LOW","MEDIUM","HIGH"]))
def watch(path: str, no_git: bool, severity: str):
    """
    Watch a directory and re-scan on every file save.

    Press Ctrl+C to stop.
    """
    try:
        from watchdog.observers import Observer
        from watchdog.events import FileSystemEventHandler
    except ImportError:
        console.print("[red]watchdog is not installed. Run: pip install watchdog[/red]")
        sys.exit(1)

    root = Path(path).resolve()
    cfg  = _load_config(root)
    ignored = set(cfg.get("ignored_dirs", _default_ignored()))
    sev_rank = {"LOW": 0, "MEDIUM": 1, "HIGH": 2}
    min_rank  = sev_rank[severity]

    SUPPORTED = {".py", ".js", ".ts", ".tsx", ".mjs", ".cjs"}

    def _do_scan():
        findings = scan_project(root, ignored)
        if not no_git:
            findings = enrich_findings(findings, root)
        findings = [f for f in findings if sev_rank.get(f.severity, 0) >= min_rank]
        console.clear()
        console.print(f"\n[dim]{datetime.now().strftime('%H:%M:%S')}[/dim] [bold cyan]gitrekt Watch[/bold cyan]  "
                      f"(watching [bold]{root}[/bold]) — Ctrl+C to stop")
        _render_findings(findings, root, show_git=not no_git)

    class ChangeHandler(FileSystemEventHandler):
        def __init__(self):
            self._last = 0.0

        def on_modified(self, event):
            if event.is_directory:
                return
            if Path(event.src_path).suffix not in SUPPORTED:
                return
            now = time.time()
            if now - self._last < 1.0:   # debounce 1s
                return
            self._last = now
            _do_scan()

    _do_scan()

    observer = Observer()
    observer.schedule(ChangeHandler(), str(root), recursive=True)
    observer.start()
    console.print(f"  [dim]Watching for changes...[/dim]")

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()
        console.print("\n[dim]Watch stopped.[/dim]")
    observer.join()


# ── gitrekt init ─────────────────────────────────────────────────────────────

@cli.command()
@click.argument("path", default=".", type=click.Path(exists=True, file_okay=False))
def init(path: str):
    """
    Interactive setup wizard — creates .gitrekt/config.json.
    """
    root    = Path(path).resolve()
    cfg_dir = root / ".gitrekt"
    cfg_file = cfg_dir / "config.json"

    console.print(
        Panel(
            "[bold cyan]gitrekt Init[/bold cyan]\n"
            "[dim]Let's set up your project configuration.[/dim]",
            border_style="cyan",
        )
    )

    existing = {}
    if cfg_file.exists():
        existing = json.loads(cfg_file.read_text(encoding="utf-8"))
        console.print(f"[yellow]Config already exists at {cfg_file}. Updating...[/yellow]")

    # Groq API key
    current_key = existing.get("groq_api_key", "")
    masked = f"...{current_key[-6:]}" if current_key else "(not set)"
    groq_key = click.prompt(
        f"  Groq API key [{masked}]",
        default=current_key,
        show_default=False,
    ).strip()

    # Ignored dirs
    current_ignored = existing.get("ignored_dirs", _default_ignored())
    console.print(f"  Default ignored dirs: [dim]{', '.join(current_ignored)}[/dim]")
    extra = click.prompt(
        "  Additional dirs to ignore (comma-separated, or leave blank)",
        default="",
    ).strip()
    ignored = current_ignored[:]
    if extra:
        ignored += [d.strip() for d in extra.split(",") if d.strip()]

    # Severity threshold
    threshold = click.prompt(
        "  Minimum severity to report",
        type=click.Choice(["LOW", "MEDIUM", "HIGH"]),
        default=existing.get("min_severity", "LOW"),
    )

    # Ollama fallback
    use_ollama = click.confirm(
        "  Enable Ollama as LLM fallback?",
        default=existing.get("use_ollama", False),
    )

    config = {
        "groq_api_key":  groq_key,
        "ignored_dirs":  ignored,
        "min_severity":  threshold,
        "use_ollama":    use_ollama,
        "ollama_model":  existing.get("ollama_model", "llama3"),
        "ollama_url":    existing.get("ollama_url",   "http://localhost:11434"),
    }

    cfg_dir.mkdir(parents=True, exist_ok=True)
    cfg_file.write_text(json.dumps(config, indent=2), encoding="utf-8")

    console.print(
        Panel(
            f"[bold green]Config saved![/bold green]\n"
            f"[dim]{cfg_file}[/dim]\n\n"
            f"Run [bold cyan]gitrekt scan[/bold cyan] to start detecting drift.",
            border_style="green",
        )
    )


# ── gitrekt install-extension ────────────────────────────────────────────────

@cli.command("install-extension")
def install_extension():
    """
    Install the GitRekt VS Code extension automatically.

    Requires the 'code' CLI to be available (VS Code must be installed).
    On Windows, you may need to add VS Code to your PATH first.
    """
    import subprocess

    console.print(Panel(
        "[bold cyan]GitRekt: Installing VS Code Extension[/bold cyan]\n"
        "[dim]Requires VS Code with the 'code' CLI available in PATH.[/dim]",
        border_style="cyan",
    ))

    # Try 'code' CLI first, then 'code-insiders' for VS Code Insiders
    for cmd in ("code", "code-insiders"):
        try:
            result = subprocess.run(
                [cmd, "--install-extension", "gitrekt.gitrekt-vscode", "--force"],
                capture_output=True, text=True, timeout=60,
            )
            if result.returncode == 0:
                console.print(Panel(
                    "[bold green]Extension installed successfully![/bold green]\n"
                    "Reload VS Code (Ctrl+Shift+P → 'Reload Window') to activate GitRekt.",
                    border_style="green",
                ))
                return
        except FileNotFoundError:
            continue
        except Exception as e:
            console.print(f"[yellow]Warning: {cmd} failed — {e}[/yellow]")

    # Neither worked — guide the user to install manually
    console.print(Panel(
        "[bold yellow]Could not find 'code' CLI.[/bold yellow]\n\n"
        "To install manually:\n"
        "  1. Open VS Code\n"
        "  2. Press [bold]Ctrl+Shift+X[/bold] to open Extensions\n"
        "  3. Search for [bold]GitRekt - Codebase Assistant[/bold]\n"
        "  4. Click Install\n\n"
        "[dim]Or enable the 'code' CLI: VS Code → Ctrl+Shift+P → "
        "'Shell Command: Install code command in PATH'[/dim]",
        border_style="yellow",
    ))


if __name__ == "__main__":
    cli()
