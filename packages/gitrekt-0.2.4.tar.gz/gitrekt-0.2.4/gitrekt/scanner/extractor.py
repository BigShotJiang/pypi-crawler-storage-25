"""
gitrekt/scanner/extractor.py

Walks a Tree-sitter syntax tree and extracts structured information about
every function/method, including:
  - name, file, start/end lines
  - parameters (names + declared types where present)
  - declared return type (where present)
  - docstring / leading block comment
  - raw body text
"""

from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional
import re

from tree_sitter import Node

from .parser import parse_file, get_language, PY_LANGUAGE, JS_LANGUAGE, TS_LANGUAGE, TSX_LANGUAGE


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class ParamInfo:
    name: str
    declared_type: Optional[str] = None   # from type annotation / JSDoc

@dataclass
class FunctionInfo:
    name: str
    file: Path
    start_line: int          # 1-indexed
    end_line: int            # 1-indexed
    params: list[ParamInfo] = field(default_factory=list)
    declared_return_type: Optional[str] = None
    docstring: Optional[str] = None       # extracted doc text (cleaned)
    raw_doc_node_lines: tuple[int, int] = (0, 0)  # (start, end) 1-indexed of the doc block
    body_text: str = ""
    language: str = "unknown"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _node_text(node: Node, src: bytes) -> str:
    return src[node.start_byte:node.end_byte].decode("utf-8", errors="replace")


def _clean_docstring(raw: str) -> str:
    """Strip comment markers and normalize whitespace from a raw docstring."""
    # Remove triple-quote Python docstrings
    raw = re.sub(r'^"""', "", raw)
    raw = re.sub(r'"""$', "", raw)
    raw = re.sub(r"^'''", "", raw)
    raw = re.sub(r"'''$", "", raw)
    # Remove JS/TS block comment markers
    raw = re.sub(r"^/\*+", "", raw)
    raw = re.sub(r"\*+/$", "", raw)
    raw = re.sub(r"^\s*\*\s?", "", raw, flags=re.MULTILINE)
    # Remove single-line comment markers
    raw = re.sub(r"^#\s?", "", raw, flags=re.MULTILINE)
    raw = re.sub(r"^//\s?", "", raw, flags=re.MULTILINE)
    return raw.strip()


# ---------------------------------------------------------------------------
# Python extractor
# ---------------------------------------------------------------------------

def _extract_python_params(func_node: Node, src: bytes) -> list[ParamInfo]:
    params: list[ParamInfo] = []
    params_node = next((c for c in func_node.children if c.type == "parameters"), None)
    if params_node is None:
        return params

    skip_types = {"(", ")", ",", "*", "**"}
    for child in params_node.children:
        if child.type in skip_types:
            continue
        if child.type == "identifier":
            name = _node_text(child, src)
            if name == "self" or name == "cls":
                continue
            params.append(ParamInfo(name=name))
        elif child.type in ("typed_parameter", "typed_default_parameter"):
            # e.g.  x: int = 5
            id_node = next((c for c in child.children if c.type == "identifier"), None)
            type_node = next((c for c in child.children if c.type == "type"), None)
            if id_node:
                name = _node_text(id_node, src)
                if name in ("self", "cls"):
                    continue
                typ = _node_text(type_node, src) if type_node else None
                params.append(ParamInfo(name=name, declared_type=typ))
        elif child.type in ("default_parameter",):
            id_node = next((c for c in child.children if c.type == "identifier"), None)
            if id_node:
                name = _node_text(id_node, src)
                if name not in ("self", "cls"):
                    params.append(ParamInfo(name=name))
    return params


def _extract_python_return_type(func_node: Node, src: bytes) -> Optional[str]:
    ret_node = next((c for c in func_node.children if c.type == "type"), None)
    return _node_text(ret_node, src) if ret_node else None


def _extract_python_docstring(func_node: Node, src: bytes) -> tuple[Optional[str], tuple[int, int]]:
    """Return (cleaned_docstring, (start_line, end_line)) or (None, (0,0))."""
    body = next((c for c in func_node.children if c.type == "block"), None)
    if body is None:
        return None, (0, 0)

    # First statement in the block — is it an expression_statement with string?
    for stmt in body.children:
        if stmt.type == "expression_statement":
            str_node = stmt.children[0] if stmt.children else None
            if str_node and str_node.type == "string":
                raw = _node_text(str_node, src)
                cleaned = _clean_docstring(raw)
                start = str_node.start_point[0] + 1  # 1-indexed
                end   = str_node.end_point[0] + 1
                return cleaned, (start, end)
        break  # only check first non-empty statement
    return None, (0, 0)


def _extract_python_functions(tree, src: bytes, path: Path) -> list[FunctionInfo]:
    results: list[FunctionInfo] = []
    cursor = tree.walk()

    def visit(node: Node):
        if node.type in ("function_definition", "decorated_definition"):
            target = node
            if node.type == "decorated_definition":
                # find the actual function inside
                target = next((c for c in node.children if c.type == "function_definition"), None)
                if target is None:
                    for child in node.children:
                        visit(child)
                    return

            name_node = next((c for c in target.children if c.type == "identifier"), None)
            name = _node_text(name_node, src) if name_node else "<anonymous>"

            params  = _extract_python_params(target, src)
            ret     = _extract_python_return_type(target, src)
            doc, doc_lines = _extract_python_docstring(target, src)

            body_node = next((c for c in target.children if c.type == "block"), None)
            body_text = _node_text(body_node, src) if body_node else ""

            fi = FunctionInfo(
                name=name,
                file=path,
                start_line=node.start_point[0] + 1,
                end_line=node.end_point[0] + 1,
                params=params,
                declared_return_type=ret,
                docstring=doc,
                raw_doc_node_lines=doc_lines,
                body_text=body_text,
                language="python",
            )
            results.append(fi)

            # Recurse into nested functions
            for child in target.children:
                visit(child)

        else:
            for child in node.children:
                visit(child)

    visit(tree.root_node)
    return results


# ---------------------------------------------------------------------------
# JavaScript / TypeScript extractor
# ---------------------------------------------------------------------------

def _extract_js_params(func_node: Node, src: bytes) -> list[ParamInfo]:
    params: list[ParamInfo] = []
    # formal_parameters for JS, required_parameter / optional_parameter for TS
    params_node = next(
        (c for c in func_node.children if c.type in ("formal_parameters", "parameters")),
        None
    )
    if params_node is None:
        return params

    for child in params_node.children:
        if child.type == "identifier":
            params.append(ParamInfo(name=_node_text(child, src)))
        elif child.type in ("required_parameter", "optional_parameter"):
            id_node = next((c for c in child.children if c.type == "identifier"), None)
            type_ann = next((c for c in child.children if c.type == "type_annotation"), None)
            if id_node:
                typ = None
                if type_ann:
                    # strip the leading ':'
                    typ = _node_text(type_ann, src).lstrip(": ").strip()
                params.append(ParamInfo(name=_node_text(id_node, src), declared_type=typ))
        elif child.type == "assignment_pattern":
            id_node = next((c for c in child.children if c.type == "identifier"), None)
            if id_node:
                params.append(ParamInfo(name=_node_text(id_node, src)))
    return params


def _extract_js_return_type(func_node: Node, src: bytes) -> Optional[str]:
    ret = next((c for c in func_node.children if c.type == "type_annotation"), None)
    return _node_text(ret, src).lstrip(": ").strip() if ret else None


def _extract_js_jsdoc(func_node: Node, src: bytes) -> tuple[Optional[str], tuple[int, int]]:
    """
    Look for a JSDoc block comment immediately preceding the function node.
    Tree-sitter does not attach comments to nodes, so we search the raw source
    backwards from the function start byte.
    """
    func_start = func_node.start_byte
    preceding = src[:func_start].decode("utf-8", errors="replace")
    lines = preceding.split("\n")

    doc_lines_reversed = []
    in_block = False

    for line in reversed(lines):
        stripped = line.strip()
        if not in_block:
            if stripped.endswith("*/"):
                in_block = True
                doc_lines_reversed.append(stripped)
            elif stripped == "" or stripped.startswith("//"):
                # single-line comment or blank — acceptable before the func
                if stripped.startswith("//"):
                    doc_lines_reversed.append(stripped)
                continue
            else:
                break
        else:
            doc_lines_reversed.append(stripped)
            if stripped.startswith("/*"):
                break

    if not doc_lines_reversed:
        return None, (0, 0)

    raw = "\n".join(reversed(doc_lines_reversed))
    cleaned = _clean_docstring(raw)

    # Approximate line numbers
    total_lines_before = len(lines)
    doc_end_line   = total_lines_before       # 1-indexed (approx)
    doc_start_line = doc_end_line - len(doc_lines_reversed) + 1

    return cleaned, (max(1, doc_start_line), doc_end_line)


def _extract_js_functions(tree, src: bytes, path: Path, lang_name: str) -> list[FunctionInfo]:
    results: list[FunctionInfo] = []

    func_types = {
        "function_declaration",
        "function",
        "arrow_function",
        "method_definition",
        "function_expression",
    }

    def visit(node: Node):
        if node.type in func_types:
            # Name resolution
            name = "<anonymous>"
            # function_declaration / method_definition have a 'name' child
            name_node = next((c for c in node.children if c.type in ("identifier", "property_identifier")), None)
            if name_node:
                name = _node_text(name_node, src)
            # arrow / expression assigned to variable: parent might be variable_declarator
            elif node.parent and node.parent.type == "variable_declarator":
                id_node = next((c for c in node.parent.children if c.type == "identifier"), None)
                if id_node:
                    name = _node_text(id_node, src)

            params = _extract_js_params(node, src)
            ret    = _extract_js_return_type(node, src)
            doc, doc_lines = _extract_js_jsdoc(node, src)

            body_node = next((c for c in node.children if c.type in ("statement_block", "expression")), None)
            body_text = _node_text(body_node, src) if body_node else ""

            results.append(FunctionInfo(
                name=name,
                file=path,
                start_line=node.start_point[0] + 1,
                end_line=node.end_point[0] + 1,
                params=params,
                declared_return_type=ret,
                docstring=doc,
                raw_doc_node_lines=doc_lines,
                body_text=body_text,
                language=lang_name,
            ))

        for child in node.children:
            visit(child)

    visit(tree.root_node)
    return results


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def extract_functions(path: Path) -> list[FunctionInfo]:
    """
    Parse a source file and return a list of FunctionInfo objects.

    Args:
        path: Absolute path to the source file.

    Returns:
        List of extracted function metadata. Empty if file is unsupported.
    """
    result = parse_file(path)
    if result is None:
        return []

    tree, src, language = result

    if language == PY_LANGUAGE:
        return _extract_python_functions(tree, src, path)
    elif language in (JS_LANGUAGE,):
        return _extract_js_functions(tree, src, path, "javascript")
    elif language in (TS_LANGUAGE, TSX_LANGUAGE):
        return _extract_js_functions(tree, src, path, "typescript")

    return []
