"""
gitrekt/scanner/detector.py

Drift detection engine.  Given a FunctionInfo, applies a set of heuristic
rules to detect mismatches between the documented description and the
actual code.  No LLM involved — fully offline.

Drift types detected
--------------------
PARAM_MISSING_IN_DOC   : A code parameter has no mention in the docstring.
PARAM_EXTRA_IN_DOC     : Docstring mentions a parameter not in the code.
PARAM_TYPE_MISMATCH    : Documented type differs from the annotated type.
RETURN_TYPE_MISMATCH   : Docstring return type differs from annotation.
NO_DOCSTRING           : Public function has no docstring at all.
EMPTY_DOCSTRING        : Docstring exists but contains only whitespace.
RAISES_UNDOCUMENTED    : Code raises an exception not mentioned in the doc.
"""

from __future__ import annotations
import re
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Optional

from .extractor import FunctionInfo, ParamInfo


# ---------------------------------------------------------------------------
# Drift type enum
# ---------------------------------------------------------------------------

class DriftType(str, Enum):
    PARAM_MISSING_IN_DOC  = "PARAM_MISSING_IN_DOC"
    PARAM_EXTRA_IN_DOC    = "PARAM_EXTRA_IN_DOC"
    PARAM_TYPE_MISMATCH   = "PARAM_TYPE_MISMATCH"
    RETURN_TYPE_MISMATCH  = "RETURN_TYPE_MISMATCH"
    NO_DOCSTRING          = "NO_DOCSTRING"
    EMPTY_DOCSTRING       = "EMPTY_DOCSTRING"
    RAISES_UNDOCUMENTED   = "RAISES_UNDOCUMENTED"


# ---------------------------------------------------------------------------
# Drift finding dataclass
# ---------------------------------------------------------------------------

@dataclass
class DriftFinding:
    drift_type: DriftType
    function_name: str
    file: str                          # relative or absolute path string
    line: int                          # line where the function starts
    doc_line_start: int                # line where the doc block starts (0 if no doc)
    doc_line_end: int                  # line where the doc block ends (0 if no doc)
    message: str                       # human-readable description
    context: Optional[str] = None      # snippet of the offending text
    severity: str = "MEDIUM"           # LOW / MEDIUM / HIGH — updated by git_analyzer
    func_info: Optional[FunctionInfo] = field(default=None, repr=False)  # full function context for LLM


# ---------------------------------------------------------------------------
# Helper: parse documented params out of a docstring
# ---------------------------------------------------------------------------

# Patterns that match parameter mentions in common docstring styles:
#   :param foo:         (Sphinx / reStructuredText)
#   Args:\n  foo (type): (Google style)
#   @param {type} foo   (JSDoc)
#   * `foo`             (GitHub markdown)

_SPHINX_PARAM_RE   = re.compile(r":param\s+(?:\w+\s+)?(\w+)\s*:", re.IGNORECASE)
_SPHINX_TYPE_RE    = re.compile(r":type\s+(\w+)\s*:\s*(.+)", re.IGNORECASE)
_SPHINX_RETURNS_RE = re.compile(r":returns?:\s*(.+)", re.IGNORECASE)
_SPHINX_RTYPE_RE   = re.compile(r":rtype:\s*(.+)", re.IGNORECASE)

_GOOGLE_PARAM_RE   = re.compile(r"^\s{2,}(\w+)\s*(?:\(([^)]+)\))?\s*:", re.MULTILINE)
_GOOGLE_RETURNS_RE = re.compile(r"Returns:\s*\n\s+(\w+)", re.IGNORECASE | re.MULTILINE)

_JSDOC_PARAM_RE    = re.compile(r"@param\s+(?:\{([^}]+)\}\s+)?(\w+)", re.IGNORECASE)
_JSDOC_RETURNS_RE  = re.compile(r"@returns?\s+\{([^}]+)\}", re.IGNORECASE)


def _parse_doc_params(doc: str) -> dict[str, Optional[str]]:
    """
    Extract {param_name: declared_type_or_None} from a docstring.
    Handles Sphinx, Google, and JSDoc styles.
    """
    found: dict[str, Optional[str]] = {}

    # Sphinx
    for m in _SPHINX_PARAM_RE.finditer(doc):
        found[m.group(1)] = None
    for m in _SPHINX_TYPE_RE.finditer(doc):
        found.setdefault(m.group(1), m.group(2).strip())
        found[m.group(1)] = m.group(2).strip()

    # JSDoc
    for m in _JSDOC_PARAM_RE.finditer(doc):
        typ  = m.group(1)  # may be None if no {type}
        name = m.group(2)
        found[name] = typ

    # Google-style (heuristic — only under Args: section)
    in_args = False
    for line in doc.splitlines():
        if re.match(r"^\s*Args\s*:", line):
            in_args = True
            continue
        if in_args:
            if re.match(r"^\s{2,}\S", line):
                m = re.match(r"^\s+(\w+)\s*(?:\(([^)]+)\))?", line)
                if m:
                    found[m.group(1)] = m.group(2)
            elif line.strip() and not line.startswith(" " * 2):
                in_args = False  # left Args section

    return found


def _parse_doc_return_type(doc: str) -> Optional[str]:
    """Extract the documented return type from a docstring."""
    m = _SPHINX_RTYPE_RE.search(doc)
    if m:
        return m.group(1).strip()
    m = _JSDOC_RETURNS_RE.search(doc)
    if m:
        return m.group(1).strip()
    return None


def _parse_doc_raises(doc: str) -> set[str]:
    """Extract exception names documented with :raises ExcType: or @throws."""
    found: set[str] = set()
    for m in re.finditer(r":raises?\s+(\w+)\s*:", doc, re.IGNORECASE):
        found.add(m.group(1))
    for m in re.finditer(r"@throws?\s+\{?(\w+)\}?", doc, re.IGNORECASE):
        found.add(m.group(1))
    return found


def _code_raises(body: str) -> set[str]:
    """Find exception names that appear in raise statements in the body."""
    found: set[str] = set()
    # Python: raise SomeError(...)  or  raise SomeError
    for m in re.finditer(r"\braise\s+(\w+)", body):
        found.add(m.group(1))
    # JS/TS: throw new SomeError(...)
    for m in re.finditer(r"\bthrow\s+new\s+(\w+)", body):
        found.add(m.group(1))
    return found


def _is_private(name: str, language: str) -> bool:
    """Heuristic: private functions don't need docs."""
    if language == "python":
        return name.startswith("_")
    # JS/TS: leading underscore or starting with lowercase (for methods)
    return name.startswith("_")


# ---------------------------------------------------------------------------
# Main detection function
# ---------------------------------------------------------------------------

def detect_drift(func: FunctionInfo, require_docs_for_private: bool = False) -> list[DriftFinding]:
    """
    Apply all drift heuristics to a single FunctionInfo.

    Args:
        func: The extracted function metadata.
        require_docs_for_private: If True, also flag undocumented private functions.

    Returns:
        List of DriftFinding objects. Empty if no drift detected.
    """
    findings: list[DriftFinding] = []
    is_private = _is_private(func.name, func.language)

    file_str = str(func.file)
    doc_start, doc_end = func.raw_doc_node_lines

    def _finding(dt: DriftType, msg: str, ctx: str | None = None, severity: str = "MEDIUM") -> DriftFinding:
        return DriftFinding(
            drift_type=dt,
            function_name=func.name,
            file=file_str,
            line=func.start_line,
            doc_line_start=doc_start,
            doc_line_end=doc_end,
            message=msg,
            context=ctx,
            severity=severity,
            func_info=func,
        )

    # ── Rule 1: No docstring ──────────────────────────────────────────────
    if func.docstring is None:
        if not is_private or require_docs_for_private:
            if func.params:  # only flag if there are params to document
                findings.append(_finding(
                    DriftType.NO_DOCSTRING,
                    f"Function `{func.name}` has {len(func.params)} parameter(s) but no docstring.",
                    severity="LOW",
                ))
        return findings  # no point checking further without a doc

    # ── Rule 2: Empty docstring ──────────────────────────────────────────
    if not func.docstring.strip():
        findings.append(_finding(
            DriftType.EMPTY_DOCSTRING,
            f"Function `{func.name}` has an empty docstring.",
            severity="LOW",
        ))
        return findings

    doc = func.docstring
    doc_params  = _parse_doc_params(doc)
    code_params = {p.name: p for p in func.params}

    # ── Rule 3: Parameters in code not mentioned in doc ──────────────────
    for pname, pinfo in code_params.items():
        if doc_params and pname not in doc_params:
            # Check if the param name even appears anywhere in the doc text
            if pname not in doc:
                findings.append(_finding(
                    DriftType.PARAM_MISSING_IN_DOC,
                    f"Parameter `{pname}` exists in code but is not documented.",
                    ctx=f"Code params: {[p.name for p in func.params]}",
                    severity="MEDIUM",
                ))

    # ── Rule 4: Parameters in doc not in code ───────────────────────────
    if doc_params:
        for dname in doc_params:
            if dname not in code_params:
                findings.append(_finding(
                    DriftType.PARAM_EXTRA_IN_DOC,
                    f"Docstring mentions parameter `{dname}` but it doesn't exist in code.",
                    ctx=f"Doc params: {list(doc_params.keys())}",
                    severity="HIGH",
                ))

    # ── Rule 5: Type annotation mismatch ────────────────────────────────
    for pname, pinfo in code_params.items():
        doc_type  = doc_params.get(pname)
        code_type = pinfo.declared_type
        if doc_type and code_type:
            # Normalise for comparison (strip whitespace, lowercase)
            if doc_type.strip().lower() != code_type.strip().lower():
                findings.append(_finding(
                    DriftType.PARAM_TYPE_MISMATCH,
                    f"Parameter `{pname}`: doc says `{doc_type}` but code annotation is `{code_type}`.",
                    severity="HIGH",
                ))

    # ── Rule 6: Return type mismatch ────────────────────────────────────
    doc_ret  = _parse_doc_return_type(doc)
    code_ret = func.declared_return_type
    if doc_ret and code_ret:
        if doc_ret.strip().lower() != code_ret.strip().lower():
            findings.append(_finding(
                DriftType.RETURN_TYPE_MISMATCH,
                f"Return type: doc says `{doc_ret}` but code annotation is `{code_ret}`.",
                severity="HIGH",
            ))

    # ── Rule 7: Undocumented raises ─────────────────────────────────────
    code_exc = _code_raises(func.body_text)
    doc_exc  = _parse_doc_raises(doc)
    undoc = code_exc - doc_exc - {"Exception", "Error", "BaseException"}
    if undoc and len(func.body_text) > 50:  # only for non-trivial functions
        findings.append(_finding(
            DriftType.RAISES_UNDOCUMENTED,
            f"Function raises {undoc} but docstring doesn't document it.",
            severity="LOW",
        ))

    return findings


# ---------------------------------------------------------------------------
# Project-level scan
# ---------------------------------------------------------------------------

def scan_project(root, ignored_dirs: set[str] | None = None) -> list[DriftFinding]:
    """
    Scan all supported files under root and return all drift findings.

    Args:
        root: Path to the project root directory.
        ignored_dirs: Optional set of directory names to skip.

    Returns:
        List of all DriftFinding objects found across the project.
    """
    from pathlib import Path
    from .parser import walk_project
    from .extractor import extract_functions

    root = Path(root)
    files = walk_project(root, ignored_dirs)
    all_findings: list[DriftFinding] = []

    for f in files:
        funcs = extract_functions(f)
        for func in funcs:
            findings = detect_drift(func)
            all_findings.extend(findings)

    return all_findings
