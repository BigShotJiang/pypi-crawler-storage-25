"""
gitrekt/scanner/parser.py

Loads Tree-sitter language grammars and parses source files into
syntax trees. Supports Python, JavaScript, and TypeScript.

Compatible with tree-sitter 0.22+ / 0.25.x API:
  - Language(capsule)  — no name arg needed
  - Parser(language)   — language passed in constructor
"""

from pathlib import Path
from typing import Optional

import tree_sitter_python       as _tspy
import tree_sitter_javascript   as _tsjs
import tree_sitter_typescript   as _tsts
from tree_sitter import Language, Parser

# ---------------------------------------------------------------------------
# Build language objects once at import time
# tree-sitter 0.25: Language(capsule) — single argument
# ---------------------------------------------------------------------------
PY_LANGUAGE  = Language(_tspy.language())
JS_LANGUAGE  = Language(_tsjs.language())
TS_LANGUAGE  = Language(_tsts.language_typescript())
TSX_LANGUAGE = Language(_tsts.language_tsx())

EXTENSION_MAP: dict[str, Language] = {
    ".py":   PY_LANGUAGE,
    ".js":   JS_LANGUAGE,
    ".mjs":  JS_LANGUAGE,
    ".cjs":  JS_LANGUAGE,
    ".ts":   TS_LANGUAGE,
    ".tsx":  TSX_LANGUAGE,
}

SUPPORTED_EXTENSIONS = set(EXTENSION_MAP.keys())


def get_language(path: Path) -> Optional[Language]:
    """Return the Tree-sitter Language for a given file path, or None."""
    return EXTENSION_MAP.get(path.suffix.lower())


def parse_file(path: Path) -> Optional[tuple]:
    """
    Parse a source file with Tree-sitter.

    Args:
        path: Absolute or relative path to the source file.

    Returns:
        (tree, source_bytes, language) if the file is supported and parseable.
        None if the file type is unsupported or unreadable.
    """
    language = get_language(path)
    if language is None:
        return None

    try:
        source_bytes = path.read_bytes()
    except (OSError, PermissionError):
        return None

    # tree-sitter 0.25: Parser(language) — language in constructor
    parser = Parser(language)
    tree   = parser.parse(source_bytes)
    return tree, source_bytes, language


def walk_project(root: Path, ignored_dirs: set[str] | None = None) -> list[Path]:
    """
    Recursively collect all supported source files under root.
    If root is a file, return a list containing just that file.

    Args:
        root: Project root directory or a single file.
        ignored_dirs: Directory names to skip.

    Returns:
        Sorted list of Path objects for supported source files.
    """
    if root.is_file() and root.suffix.lower() in SUPPORTED_EXTENSIONS:
        return [root]
    
    if ignored_dirs is None:
        ignored_dirs = {
            ".git", ".hg", ".svn",
            "node_modules", "__pycache__", ".venv", "venv", "env",
            "dist", "build", ".next", ".nuxt", "coverage",
            ".mypy_cache", ".pytest_cache", ".ruff_cache",
        }

    results: list[Path] = []
    for item in root.rglob("*"):
        if any(part in ignored_dirs for part in item.parts):
            continue
        if item.is_file() and item.suffix.lower() in SUPPORTED_EXTENSIONS:
            results.append(item)

    return sorted(results)
