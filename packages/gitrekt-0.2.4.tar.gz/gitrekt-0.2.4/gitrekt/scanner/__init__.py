"""
gitrekt/scanner/__init__.py
"""
