"""
gitrekt/git_analyzer.py

Uses GitPython to enrich DriftFindings with git history metadata:
  - When was the code (function body) last changed?
  - When was the docstring last changed?
  - If code changed AFTER doc → staleness confirmed; severity upgraded accordingly.

How it works
------------
For each finding we run `git log -L <start>,<end>:<file>` which returns the
commits that touched specific line ranges. This gives us per-line blame history
without needing to walk the entire diff manually.

We use the simpler `git log --follow -p -- <file>` + line-range heuristic as
the primary method because `-L` can be slow on large repos.  A fast fallback
uses `git log --pretty --follow -- <file>` to get the most recent commit date
for the whole file when line-level data is unavailable.
"""

from __future__ import annotations

import re
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

try:
    from git import Repo, InvalidGitRepositoryError, GitCommandError
    GIT_AVAILABLE = True
except ImportError:
    GIT_AVAILABLE = False

from .scanner.detector import DriftFinding
from .severity import staleness_severity, merge_severity


# ---------------------------------------------------------------------------
# Repository loader (cached per-root)
# ---------------------------------------------------------------------------

_repo_cache: dict[str, "Repo"] = {}


def _get_repo(root: Path) -> Optional["Repo"]:
    """Return a cached Repo object for the given root, or None if not a git repo."""
    if not GIT_AVAILABLE:
        return None
    key = str(root)
    if key not in _repo_cache:
        try:
            _repo_cache[key] = Repo(root, search_parent_directories=True)
        except (InvalidGitRepositoryError, Exception):
            _repo_cache[key] = None  # type: ignore
    return _repo_cache[key]


# ---------------------------------------------------------------------------
# Per-file line-history helpers
# ---------------------------------------------------------------------------

GIT_ENRICH_CAP  = 30   # max findings to git-enrich (keeps scan fast on big repos)
GIT_LOG_DEPTH   = 20   # only look at last N commits per query
GIT_CALL_TIMEOUT = 3.0  # seconds per git log call


def _run_with_timeout(fn, timeout: float, default=None):
    """Run fn() in a thread; return default if it takes longer than timeout seconds."""
    result = [default]
    exc    = [None]

    def target():
        try:
            result[0] = fn()
        except Exception as e:
            exc[0] = e

    t = threading.Thread(target=target, daemon=True)
    t.start()
    t.join(timeout)
    if t.is_alive():
        return default  # timed out
    if exc[0]:
        return default  # git error
    return result[0]


def _commits_touching_lines(repo, rel_path: str, start_line: int, end_line: int) -> list[datetime]:
    """
    Return commit datetimes for commits touching [start_line, end_line] in rel_path.
    Capped to GIT_LOG_DEPTH commits and GIT_CALL_TIMEOUT seconds.
    """
    def _do():
        dates: list[datetime] = []
        try:
            output = repo.git.log(
                f"-L{start_line},{end_line}:{rel_path}",
                "--pretty=format:%ci",
                "--no-patch",
                f"-n{GIT_LOG_DEPTH}",
            )
            for line in output.splitlines():
                line = line.strip()
                if not line or line.startswith("diff") or line.startswith("@@"):
                    continue
                try:
                    dt = datetime.fromisoformat(line)
                    if dt.tzinfo is None:
                        dt = dt.replace(tzinfo=timezone.utc)
                    dates.append(dt)
                except ValueError:
                    continue
        except Exception:
            dates = _commits_touching_file(repo, rel_path)
        return dates

    result = _run_with_timeout(_do, GIT_CALL_TIMEOUT, default=[])
    return result or []


def _commits_touching_file(repo, rel_path: str) -> list[datetime]:
    """Return commit datetimes for the last GIT_LOG_DEPTH commits touching rel_path."""
    def _do():
        dates: list[datetime] = []
        try:
            output = repo.git.log(
                "--follow",
                "--pretty=format:%ci",
                f"-n{GIT_LOG_DEPTH}",
                "--",
                rel_path,
            )
            for line in output.splitlines():
                line = line.strip()
                if not line:
                    continue
                try:
                    dt = datetime.fromisoformat(line)
                    if dt.tzinfo is None:
                        dt = dt.replace(tzinfo=timezone.utc)
                    dates.append(dt)
                except ValueError:
                    continue
        except Exception:
            pass
        return dates
    return _run_with_timeout(_do, GIT_CALL_TIMEOUT, default=[]) or []


def _most_recent(dates: list[datetime]) -> Optional[datetime]:
    return max(dates) if dates else None


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def enrich_findings(findings: list[DriftFinding], root: Path) -> list[DriftFinding]:
    """
    Enrich DriftFindings with git staleness data. Capped to GIT_ENRICH_CAP
    findings to keep scan fast on large repos.
    """
    repo = _get_repo(root)

    if repo is None:
        for f in findings:
            f.git_code_changed_at = None  # type: ignore[attr-defined]
            f.git_doc_changed_at  = None  # type: ignore[attr-defined]
            f.git_staleness_days  = None  # type: ignore[attr-defined]
        return findings

    repo_root = Path(repo.working_dir)

    # Cap to avoid slow scans on huge repos
    to_enrich = findings[:GIT_ENRICH_CAP]
    skipped   = findings[GIT_ENRICH_CAP:]

    for finding in to_enrich:
        file_path = Path(finding.file)
        try:
            rel_path = str(file_path.relative_to(repo_root)).replace("\\", "/")
        except ValueError:
            rel_path = str(file_path).replace("\\", "/")

        code_start = finding.line
        code_end   = finding.line + 5

        code_dates      = _commits_touching_lines(repo, rel_path, code_start, code_end)
        code_changed_at = _most_recent(code_dates)

        doc_start, doc_end = finding.doc_line_start, finding.doc_line_end
        if doc_start > 0 and doc_end >= doc_start:
            doc_dates = _commits_touching_lines(repo, rel_path, doc_start, doc_end)
        else:
            doc_dates = _commits_touching_file(repo, rel_path)
        doc_changed_at = _most_recent(doc_dates)

        git_sev = staleness_severity(code_changed_at, doc_changed_at)
        finding.severity = merge_severity(finding.severity, git_sev)

        finding.git_code_changed_at = code_changed_at  # type: ignore[attr-defined]
        finding.git_doc_changed_at  = doc_changed_at   # type: ignore[attr-defined]

        if code_changed_at and doc_changed_at:
            delta = code_changed_at - doc_changed_at
            finding.git_staleness_days = max(0, delta.days)  # type: ignore[attr-defined]
        else:
            finding.git_staleness_days = None  # type: ignore[attr-defined]

    return findings


def get_repo_info(root: Path) -> dict:
    """
    Return basic info about the git repo at root.

    Returns:
        Dict with keys: has_git, branch, commit_count, last_commit.
    """
    repo = _get_repo(root)
    if repo is None:
        return {"has_git": False}

    try:
        branch = repo.active_branch.name
    except TypeError:
        branch = "HEAD (detached)"

    try:
        commits = list(repo.iter_commits(max_count=100))
        commit_count = len(commits)
        last_commit  = commits[0].committed_datetime.isoformat() if commits else None
    except Exception:
        commit_count = 0
        last_commit  = None

    return {
        "has_git":      True,
        "branch":       branch,
        "commit_count": commit_count,
        "last_commit":  last_commit,
        "root":         str(repo.working_dir),
    }
