"""
gitrekt/server.py  (GitRekt backend)

FastAPI local server — bridges the GitRekt engine to the VS Code extension.

Endpoints
---------
GET  /health              — liveness check
POST /scan                — drift scan, return JSON findings (fully offline, no LLM)
POST /suggest             — LLM docstring fix for a single finding
GET  /suggest-questions   — generate 4 real questions from the codebase index
POST /chat                — whole-codebase chat Q&A
POST /reindex             — rebuild the codebase index
POST /ignore              — add a finding to the project's ignore list
DELETE /ignore            — remove a finding from the ignore list
GET  /ignored             — list all ignored findings for a project
POST /proxy/llm           — CORS proxy for browser → LLM API calls
GET  /info                — repo + config info
"""

from __future__ import annotations

import json
import random
import sys
import urllib.request
import urllib.error
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from .scanner.detector import scan_project, DriftFinding
from .git_analyzer import enrich_findings, get_repo_info
from .chat_engine import (
    chat as engine_chat,
    get_or_build_index,
    _pick_best_ollama_model,
    _call_ollama,
)


app = FastAPI(title="GitRekt Server", version="0.2.1")

# Allow VS Code extension (localhost) to call us
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


# ── Human-readable drift labels ───────────────────────────────────────────────

DRIFT_LABELS: dict[str, str] = {
    "NO_DOCSTRING":         "Missing comment",
    "EMPTY_DOCSTRING":      "Comment is empty",
    "STALE_DOCSTRING":      "Comment may be outdated",
    "PARAM_MISSING_IN_DOC": "Parameter not documented",
    "PARAM_EXTRA_IN_DOC":   "Extra parameter in comment",
    "PARAM_TYPE_MISMATCH":  "Parameter type mismatch in comment",
    "RETURN_TYPE_MISMATCH": "Return type mismatch in comment",
    "RAISES_UNDOCUMENTED":  "Exception not documented",
}

# Drift types that the LLM can safely auto-fix (comment generation only)
FIXABLE_DRIFT_TYPES = {"NO_DOCSTRING", "EMPTY_DOCSTRING", "PARAM_MISSING_IN_DOC", "RAISES_UNDOCUMENTED"}


def _drift_display(drift_type: str, staleness_days: Optional[int] = None) -> str:
    """Return a human-friendly label for a drift type."""
    base = DRIFT_LABELS.get(drift_type, drift_type.replace("_", " ").title())
    if drift_type == "STALE_DOCSTRING" and staleness_days:
        return f"{base} (last changed {staleness_days}d ago)"
    return base


# ── Request / Response models ─────────────────────────────────────────────────

class ScanRequest(BaseModel):
    root:         str           # absolute path to project root
    no_git:       bool = False
    min_severity: str  = "LOW"
    ignored_dirs: Optional[list[str]] = None


class SuggestRequest(BaseModel):
    root:         str
    file:         str
    line:         int
    function_name: str
    drift_type:   str
    message:      str
    api_key:      Optional[str] = None
    model:        Optional[str] = None
    base_url:     Optional[str] = None


class FindingOut(BaseModel):
    file:             str
    line:             int
    doc_line_start:   int
    doc_line_end:     int
    function_name:    str
    drift_type:       str
    display_message:  str          # human-friendly label (C3)
    is_fixable:       bool         # True if LLM can auto-fix this (C6)
    severity:         str
    message:          str
    context:          Optional[str] = None
    git_staleness_days: Optional[int] = None


class IgnoreEntry(BaseModel):
    root:       str
    file:       str
    line:       int
    drift_type: str


# ── Helpers ───────────────────────────────────────────────────────────────────


def _load_config(root: Path) -> dict:
    """Load project config for ignored_dirs and min_severity."""
    cfg = {}
    project_cfg_path = root / ".gitrekt" / "config.json"
    if project_cfg_path.exists():
        try:
            cfg.update(json.loads(project_cfg_path.read_text(encoding="utf-8")))
        except Exception:
            pass
    return cfg


_DEFAULT_IGNORED = {
    ".git", "node_modules", "__pycache__", ".venv",
    "venv", "env", "dist", "build", ".next",
}


def _gitrekt_dir(root: Path) -> Path:
    """Return (and create if needed) the .gitrekt directory for a project."""
    d = root / ".gitrekt"
    d.mkdir(exist_ok=True)
    return d


def _ignored_path(root: Path) -> Path:
    return _gitrekt_dir(root) / "ignored.json"


def _load_ignored(root: Path) -> list[dict]:
    p = _ignored_path(root)
    if p.exists():
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            pass
    return []


def _save_ignored(root: Path, entries: list[dict]) -> None:
    _ignored_path(root).write_text(
        json.dumps(entries, indent=2), encoding="utf-8"
    )


def _is_ignored(finding: "DriftFinding", ignored: list[dict]) -> bool:
    for e in ignored:
        if (e.get("file") == finding.file
                and e.get("line") == finding.line
                and e.get("drift_type") == finding.drift_type.value
                if hasattr(finding.drift_type, "value")
                else finding.drift_type):
            return True
    return False


def _finding_to_out(f: "DriftFinding") -> FindingOut:
    drift_str = f.drift_type.value if hasattr(f.drift_type, "value") else str(f.drift_type)
    staleness = getattr(f, "git_staleness_days", None)
    return FindingOut(
        file=f.file,
        line=f.line,
        doc_line_start=f.doc_line_start,
        doc_line_end=f.doc_line_end,
        function_name=f.function_name,
        drift_type=drift_str,
        display_message=_drift_display(drift_str, staleness),
        is_fixable=drift_str in FIXABLE_DRIFT_TYPES,
        severity=f.severity,
        message=f.message,
        context=f.context,
        git_staleness_days=staleness,
    )


# ── Routes ────────────────────────────────────────────────────────────────────

@app.get("/health")
def health():
    """Liveness check — VS Code extension polls this to confirm server is up."""
    return {"status": "ok", "version": "0.2.2", "name": "GitRekt"}


class HealthLlmRequest(BaseModel):
    root: str = "."
    api_key: Optional[str] = None
    model:   Optional[str] = None
    base_url: Optional[str] = None

@app.post("/health/llm")
def health_llm(req: HealthLlmRequest):
    """
    Probe all LLM backends and report which are available.
    Called by the chat panel to show a setup banner when no LLM is configured.
    """
    cloud_available = bool(req.api_key or req.base_url)

    # Check Ollama — actually probe the local service (fast, local, no quota)
    ollama_model = _pick_best_ollama_model()
    ollama_available = ollama_model is not None

    any_available = cloud_available or ollama_available

    return {
        "any_available":   any_available,
        "cloud":           cloud_available,
        "ollama":          ollama_available,
        "ollama_model":    ollama_model,
        "setup_hint": (
            None if any_available else
            "No AI model available. Click the ⚙️ icon to add an API key, or install Ollama for offline AI."
        ),
    }


@app.post("/scan", response_model=list[FindingOut])
def scan(req: ScanRequest):
    """
    Scan a project for drift findings. 100% offline — no LLM involved.
    Pre-filters findings that the user has ignored via POST /ignore.
    """
    root = Path(req.root)
    if not root.exists():
        raise HTTPException(status_code=404, detail=f"Path not found: {req.root}")

    cfg     = _load_config(root)
    ignored = set(req.ignored_dirs or cfg.get("ignored_dirs", list(_DEFAULT_IGNORED)))

    findings = scan_project(root, ignored)

    if not req.no_git:
        findings = enrich_findings(findings, root)

    # Severity filter
    sev_rank = {"LOW": 0, "MEDIUM": 1, "HIGH": 2}
    min_rank  = sev_rank.get(req.min_severity, 0)
    findings  = [f for f in findings if sev_rank.get(f.severity, 0) >= min_rank]

    # Filter out user-ignored findings
    ignored_list = _load_ignored(root)
    if ignored_list:
        findings = [f for f in findings if not _is_ignored(f, ignored_list)]

    return [_finding_to_out(f) for f in findings]


@app.post("/suggest")
def suggest(req: SuggestRequest):
    """
    Request an LLM-generated comment fix for a single finding.
    Only works for fixable drift types (missing/empty comments).
    Uses NVIDIA NIM key from global config automatically.
    """
    root = Path(req.root)
    cfg  = _load_config(root)

    # 1. First try NVIDIA if available
    api_key = req.nvidia_api_key or req.groq_api_key or ""

    if req.drift_type not in FIXABLE_DRIFT_TYPES:
        return {"suggestion": None, "reason": f"{req.drift_type} is not auto-fixable"}

    file_path = Path(req.file)
    if not file_path.is_absolute():
        file_path = root / req.file

    from .scanner.extractor import extract_functions
    funcs  = extract_functions(file_path)
    target = next(
        (f for f in funcs if f.name == req.function_name and f.start_line == req.line),
        None
    )

    if target is None:
        return {"suggestion": None, "reason": "Function not found in file"}

    # Detect language for comment style
    ext  = file_path.suffix.lower()
    lang = "python" if ext == ".py" else "javascript/typescript"

    # Build prompt
    func_snippet = "\n".join(target.source_lines[:20]) if hasattr(target, "source_lines") else f"function {target.name}(...)"
    prompt = (
        f"Write a concise {lang} docstring/JSDoc comment for this function. "
        f"Output ONLY the comment block, nothing else.\n\n"
        f"```{lang}\n{func_snippet}\n```"
    )

    messages = [
        {"role": "system", "content": "You are a code documentation assistant. Output only the comment block, no explanation."},
        {"role": "user",   "content": prompt},
    ]

    suggestion = None

    # Try Cloud LLM first via litellm
    api_key = req.api_key or ""
    model   = req.model or ""
    base_url = req.base_url or ""

    if api_key or base_url:
        try:
            from .chat_engine import _call_litellm
            suggestion = _call_litellm(messages, api_key, model, base_url, max_tokens=256)
        except Exception:
            pass

    # Try NVIDIA NIM first


    # 3. Ollama fallback
    if not suggestion:
        try:
            url = cfg.get("ollama_url", "http://localhost:11434")
            best_model = _pick_best_ollama_model(url)
            if best_model:
                suggestion = _call_ollama(messages, best_model, url)
        except Exception:
            pass
            
    if not suggestion:
        return {"suggestion": None, "reason": "No LLM available — add a Groq key or install Ollama."}

    return {"suggestion": suggestion}


@app.get("/info")
def info(root: str = "."):
    """Return git repo info and config. API keys are never exposed."""
    root_path = Path(root)
    cfg       = _load_config(root_path)
    repo_info = get_repo_info(root_path)
    safe_cfg  = {k: v for k, v in cfg.items()
                 if not any(s in k.lower() for s in ("key", "token", "secret", "password"))}
    return {"repo": repo_info, "config": safe_cfg}


# ── Ignore system (C4) ────────────────────────────────────────────────────────

@app.post("/ignore")
def add_ignore(entry: IgnoreEntry):
    """Add a finding to the project's ignore list (.gitrekt/ignored.json)."""
    root    = Path(entry.root)
    ignored = _load_ignored(root)
    new_entry = {"file": entry.file, "line": entry.line, "drift_type": entry.drift_type}
    # Avoid duplicates
    for e in ignored:
        if e == new_entry:
            return {"status": "already_ignored"}
    ignored.append(new_entry)
    _save_ignored(root, ignored)
    return {"status": "ignored", "count": len(ignored)}


@app.delete("/ignore")
def remove_ignore(entry: IgnoreEntry):
    """Remove a finding from the ignore list (un-ignore)."""
    root    = Path(entry.root)
    ignored = _load_ignored(root)
    before  = len(ignored)
    ignored = [
        e for e in ignored
        if not (e.get("file") == entry.file
                and e.get("line") == entry.line
                and e.get("drift_type") == entry.drift_type)
    ]
    _save_ignored(root, ignored)
    return {"status": "removed", "removed": before - len(ignored)}


@app.get("/ignored")
def list_ignored(root: str = Query(..., description="Project root path")):
    """Return all ignored findings for a project."""
    return _load_ignored(Path(root))


# ── Chat endpoints ────────────────────────────────────────────────────────────

class ChatRequest(BaseModel):
    root:         str
    query:        str
    history:      Optional[list[dict]] = None
    api_key:      Optional[str] = None
    model:        Optional[str] = None
    base_url:     Optional[str] = None


class ReferenceOut(BaseModel):
    file:     str
    rel_file: str
    line:     int
    label:    str


class ChatResponseOut(BaseModel):
    answer:     str
    references: list[ReferenceOut]
    model_used: str
    error:      Optional[str] = None


@app.post("/chat", response_model=ChatResponseOut)
def chat(req: ChatRequest):
    """Answer a natural-language question about the codebase."""
    root = Path(req.root)
    if not root.exists():
        raise HTTPException(status_code=404, detail=f"Path not found: {req.root}")

    cfg = _load_config(root)
    api_key = req.api_key or ""

    result = engine_chat(
        query=req.query,
        root=str(root),
        history=req.history,
        api_key=api_key,
        model=req.model or "",
        base_url=req.base_url or "",
    )

    refs = [
        ReferenceOut(file=r.file, rel_file=r.rel_file, line=r.line, label=r.label)
        for r in result.references
    ]

    return ChatResponseOut(
        answer=result.answer,
        references=refs,
        model_used=result.model_used,
        error=result.error,
    )


@app.get("/suggest-questions")
def suggest_questions(root: str = Query(..., description="Project root path")):
    """
    Generate 4 real questions based on what's actually in the codebase.
    Used to populate the chat panel's empty-state example pills.
    """
    root_path = Path(root)
    if not root_path.exists():
        return {"questions": []}

    try:
        idx = get_or_build_index(str(root_path))
    except Exception:
        return {"questions": []}

    chunks = idx.search("function class module", top_n=40)
    if not chunks:
        return {"questions": []}

    # Collect unique names + files
    functions = [c for c in chunks if c.kind in ("function", "method") and c.name and not c.name.startswith("<")]
    classes   = [c for c in chunks if c.kind == "class" and c.name]
    files     = list({c.rel_file for c in chunks})

    random.shuffle(functions)
    random.shuffle(classes)
    random.shuffle(files)

    questions: list[str] = []

    if functions:
        questions.append(f"What does `{functions[0].name}` do?")
    if len(functions) > 1:
        questions.append(f"Where is `{functions[1].name}` called?")
    if classes:
        questions.append(f"How does `{classes[0].name}` work?")
    if files:
        fname = files[0].replace("\\", "/").split("/")[-1]
        questions.append(f"What is {fname} responsible for?")

    # Fill remaining slots with useful generics
    generics = [
        "Which functions have no documentation?",
        "Where are API calls made?",
        "How does error handling work?",
        "Where is configuration loaded?",
    ]
    for g in generics:
        if len(questions) >= 4:
            break
        if g not in questions:
            questions.append(g)

    return {"questions": questions[:4]}


class ReindexRequest(BaseModel):
    root:         str
    ignored_dirs: Optional[list[str]] = None


@app.post("/reindex")
def reindex(req: ReindexRequest):
    """Force a rebuild of the codebase index for the given root."""
    root = Path(req.root)
    if not root.exists():
        raise HTTPException(status_code=404, detail=f"Path not found: {req.root}")

    idx = get_or_build_index(str(root), force=True)
    return {
        "file_count":    idx.stats.file_count,
        "chunk_count":   idx.stats.chunk_count,
        "build_time_ms": idx.stats.build_time_ms,
        "has_embeddings": idx.stats.has_embeddings,
    }


# ── LLM Proxy (CORS bypass for browser) ──────────────────────────────────────

_ALLOWED_LLM_DOMAINS = {
    "integrate.api.nvidia.com",
    "api.groq.com",
    "api.openai.com",
    "api.anthropic.com",
}


class ProxyRequest(BaseModel):
    base_url:    str
    api_key:     str
    model:       str
    messages:    list[dict]
    temperature: float = 0.7
    max_tokens:  int   = 1024


@app.post("/proxy/llm")
def proxy_llm(req: ProxyRequest):
    """CORS-safe proxy — forwards browser LLM requests. Domain-whitelisted."""
    import urllib.parse
    parsed = urllib.parse.urlparse(req.base_url)
    if parsed.netloc not in _ALLOWED_LLM_DOMAINS:
        raise HTTPException(
            status_code=400,
            detail=f"Domain not allowed: {parsed.netloc}"
        )

    url     = req.base_url.rstrip("/") + "/chat/completions"
    payload = json.dumps({
        "model":       req.model,
        "messages":    req.messages,
        "temperature": req.temperature,
        "max_tokens":  req.max_tokens,
    }).encode("utf-8")

    http_req = urllib.request.Request(
        url, data=payload,
        headers={
            "Content-Type":  "application/json",
            "Authorization": f"Bearer {req.api_key}",
        },
        method="POST",
    )

    try:
        with urllib.request.urlopen(http_req, timeout=60) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        try:
            err_data = json.loads(body)
        except Exception:
            err_data = {"raw": body}
        raise HTTPException(status_code=e.code, detail=err_data)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ── Entrypoint (python -m gitrekt.server) ────────────────────────────────────

if __name__ == "__main__":
    import uvicorn
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 5001
    uvicorn.run(app, host="127.0.0.1", port=port, log_level="warning")
