"""
gitrekt/llm/ollama_client.py

Handles fallback requests to a local Ollama instance.
"""
from typing import Optional
import json
import urllib.request
import urllib.error

from ..scanner.detector import DriftFinding
from ..scanner.extractor import FunctionInfo


def suggest_fix(finding: DriftFinding, func: FunctionInfo, model: str = "llama3", url: str = "http://localhost:11434") -> Optional[str]:
    """
    Call Ollama to suggest a corrected docstring.
    """
    prompt = f"""
You are an expert developer. The following function's documentation is stale and no longer matches the code.
The drift detector found the following issue:
{finding.drift_type.value}: {finding.message}

Original Docstring:
{func.docstring if func.docstring else "(None)"}

Current Code:
```
{func.body_text}
```

Please rewrite the docstring to be accurate based on the current code. 
Only return the updated docstring (no markdown code blocks, just the raw text).
Keep the original style (e.g., Sphinx, Google, JSDoc).
"""
    
    data = json.dumps({
        "model": model,
        "messages": [
            {
                "role": "user",
                "content": prompt
            }
        ],
        "stream": False,
        "options": {
            "temperature": 0.2
        }
    }).encode("utf-8")

    req = urllib.request.Request(f"{url}/api/chat", data=data, headers={"Content-Type": "application/json"})
    
    try:
        with urllib.request.urlopen(req, timeout=30) as response:
            result = json.loads(response.read().decode("utf-8"))
            return result.get("message", {}).get("content", "").strip()
    except Exception as e:
        print(f"  [red]Ollama API Error: {e}[/red]")
        return None
