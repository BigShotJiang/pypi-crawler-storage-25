"""
gitrekt/llm/groq_client.py

Handles requests to the Groq API to generate corrected docstrings.
"""
from typing import Optional
from groq import Groq
import os

from ..scanner.detector import DriftFinding
from ..scanner.extractor import FunctionInfo


def suggest_fix(finding: DriftFinding, func: FunctionInfo, api_key: str) -> Optional[str]:
    """
    Call Groq to suggest a corrected docstring.
    """
    if not api_key:
        return None

    try:
        client = Groq(api_key=api_key)
        
        prompt = f"""
You are an expert developer. The following function's documentation is stale and no longer matches the code.
The drift detector found the following issue:
{finding.drift_type.value}: {finding.message}

Original Docstring:
{func.docstring if func.docstring else "(None)"}

Current Code:
```
{func.body_text}
```

Please rewrite the docstring to be accurate based on the current code. 
Only return the updated docstring (no markdown code blocks, just the raw text).
Keep the original style (e.g., Sphinx, Google, JSDoc).
"""
        response = client.chat.completions.create(
            messages=[
                {
                    "role": "user",
                    "content": prompt,
                }
            ],
            model="llama3-8b-8192",
            temperature=0.2,
            max_tokens=500,
        )
        return response.choices[0].message.content.strip()
    except Exception as e:
        print(f"  [red]Groq API Error: {e}[/red]")
        return None
