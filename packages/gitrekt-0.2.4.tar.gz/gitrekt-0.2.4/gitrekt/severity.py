"""
gitrekt/severity.py

Severity scoring for drift findings.
Combines structural drift type with git staleness age.

Severity levels
---------------
LOW    : Doc is <7 days stale, or a minor cosmetic issue (empty doc, undocumented raise).
MEDIUM : Doc is 7-30 days stale, or a parameter is missing from the doc.
HIGH   : Doc is >30 days stale, OR a type mismatch, OR a ghost parameter documented that doesn't exist.

The git_analyzer upgrades severity based on staleness age.
The base severity set by detector.py is the minimum floor.
"""

from __future__ import annotations
from datetime import datetime, timezone


# Staleness thresholds in days
LOW_DAYS    = 7
MEDIUM_DAYS = 30


SEVERITY_RANK = {"LOW": 0, "MEDIUM": 1, "HIGH": 2}


def staleness_severity(code_changed_at: datetime | None, doc_changed_at: datetime | None) -> str:
    """
    Return a severity string based on how long the doc has been stale.

    If code changed AFTER doc (or doc was never touched), calculate age.

    Args:
        code_changed_at: When the relevant code lines were last committed.
        doc_changed_at:  When the doc lines were last committed (None = never in git).

    Returns:
        'LOW', 'MEDIUM', or 'HIGH'
    """
    if code_changed_at is None:
        return "LOW"

    now = datetime.now(timezone.utc)

    # If doc was never committed (new file or untracked), use code age
    reference = doc_changed_at if doc_changed_at else code_changed_at

    # Ensure timezone-aware comparison
    if reference.tzinfo is None:
        reference = reference.replace(tzinfo=timezone.utc)
    if code_changed_at.tzinfo is None:
        code_changed_at = code_changed_at.replace(tzinfo=timezone.utc)

    # Code changed after doc → staleness age = time since code changed
    if doc_changed_at is None or code_changed_at > doc_changed_at:
        age_days = (now - code_changed_at).days
    else:
        # Doc is up to date or newer — minimal concern
        return "LOW"

    if age_days < LOW_DAYS:
        return "LOW"
    elif age_days < MEDIUM_DAYS:
        return "MEDIUM"
    else:
        return "HIGH"


def merge_severity(base: str, git_severity: str) -> str:
    """
    Take the higher of the base (structural) and git (staleness) severity.

    Args:
        base:         Severity from detector.py rules (structural drift type).
        git_severity: Severity from git staleness age.

    Returns:
        The higher severity of the two.
    """
    if SEVERITY_RANK.get(git_severity, 0) > SEVERITY_RANK.get(base, 0):
        return git_severity
    return base
