"""
gitrekt/__init__.py
gitrekt — Detects stale documentation vs. actual code.
"""
__version__ = "0.1.0"
__author__ = "gitrekt"
