# upvertex-official

Namespace reservation for UpVertex Inc. (www.upvertex.com)