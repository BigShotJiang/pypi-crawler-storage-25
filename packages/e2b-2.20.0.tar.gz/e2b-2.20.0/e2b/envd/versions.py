from packaging.version import Version

ENVD_VERSION_RECURSIVE_WATCH = Version("0.1.4")
ENVD_DEBUG_FALLBACK = Version("99.99.99")
ENVD_COMMANDS_STDIN = Version("0.3.0")
ENVD_DEFAULT_USER = Version("0.4.0")
ENVD_ENVD_CLOSE = Version("0.5.2")
ENVD_OCTET_STREAM_UPLOAD = Version("0.5.7")
